# Visualization

This chapter covers Yohou's 30+ Plotly-based plotting functions for exploring, diagnosing, and evaluating time series and forecasts.

!!! info "Under Development"
    This chapter is being written. Section headings show the planned structure.

**API Reference**: [`yohou.plotting`](../api/plotting.md)
**Examples**: [Plotting](../examples/plotting.md)

## Overview

### Common Parameters

### Panel Data Support

### Customization and Theming

## Exploration

### plot_time_series

### plot_rolling_statistics

### plot_boxplot

### plot_missing_data

## Diagnostics

### Autocorrelation (ACF & PACF)

### Correlation Diagnostics

### Seasonality Analysis

### Lag Scatter

### Spectrum and Frequency Analysis

### Cross-Correlation

### Calendar Heatmap

### Scatter Matrix

### STL Components

### Subseasonality

## Forecasting Plots

### plot_forecast

### plot_prediction_interval

### plot_comparison

### plot_components

### plot_time_weight

### plot_similarity_heatmap

## Evaluation Plots

### plot_residuals

### plot_calibration

### plot_score_time_series

### plot_model_comparison_bar

### plot_score_distribution

### plot_score_per_horizon

## Model Selection Plots

### plot_splits

### plot_cv_results_scatter

## Signal Plots

### plot_phase
