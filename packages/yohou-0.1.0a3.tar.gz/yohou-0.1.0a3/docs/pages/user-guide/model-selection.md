# Model Selection

This chapter covers time series cross-validation and hyperparameter search, adapted for temporal data where observations cannot be shuffled.

!!! info "Under Development"
    This chapter is being written. Section headings show the planned structure.

**API Reference**: [`yohou.model_selection`](../api/model_selection.md) · [`yohou.metrics`](../api/metrics.md)
**Examples**: [Model Selection](../examples/model-selection.md) · [Metrics](../examples/metrics.md)

## Cross-Validation Splitters

### ExpandingWindowSplitter

### SlidingWindowSplitter

### Visualizing Splits

## Hyperparameter Search

### GridSearchCV

### RandomizedSearchCV

### Parameter Grids and Distributions

## Scoring

### Point Scorers

### Interval Scorers

### Multi-Metric Scoring

## Time-Weighted Evaluation

### Weighting Functions

### Applying Weights to Scoring
