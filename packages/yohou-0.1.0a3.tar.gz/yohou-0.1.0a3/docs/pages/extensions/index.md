# Extensions

Like Scikit-Learn, Yohou is designed to be extended. Whether it is to develop new models or integrate with other libraries, extensions allow you to enhance Yohou's capabilities. Below are the current official and community extensions.

## Official extensions

### Yohou-Optuna

Hyperparameter optimization via [Optuna](https://optuna.org/).

- **Package**: `Yohou-Optuna`
- **Install**: `uv add yohou-optuna`
- **Source**: [`stateful-y/yohou-optuna`](https://github.com/stateful-y/yohou/tree/main/packages/yohou-optuna)

## Yohou-Nixtla

Integration with [Nixtla](https://nixtla.io/)'s forecasting libraries.

- **Package**: `Yohou-Nixtla`
- **Install**: `uv add yohou-nixtla`
- **Source**: [`stateful-y/yohou-nixtla`](https://github.com/stateful-y/yohou/tree/main/packages/yohou-nixtla)

## Community extensions

There are no community extensions at this time. Want to add yours to this list? You can open an [issue](https://github.com/stateful-y/yohou/issues/new).
