# Contributing

Please see the [contributing guidelines](docs/pages/development/contributing.md) for details.
