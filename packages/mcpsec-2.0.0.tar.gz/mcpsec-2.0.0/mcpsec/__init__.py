"""mcpsec — Security scanner for MCP server implementations."""

__version__ = "2.0.0"
