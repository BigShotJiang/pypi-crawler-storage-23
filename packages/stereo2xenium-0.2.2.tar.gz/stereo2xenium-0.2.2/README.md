## install



```
conda activate 
pip install stereo2xenium
```

## usage

```bash
inDir="/media/dell/data2/Stereo/eyeball/mmEyeBall/outs/feature_expression"
outDir="/media/dell/data2/Stereo/eyeball/toXenium"
SN=C04687E314
stereo2xenium convert --input ${inDir} --output ${outDir} --sample ${SN} --genome GRCm39 --cellbin_gem
stereo2xenium viewh5 --h5file ${inDir}/C04687E314.adjusted.cellbin.gef
```

## rotate and flip

```bash
# determine the rotation angle 调整旋转角度
file="/media/dell/scRNA/spatial/Stereo/brainC04042E3/outs/visualization/C04042E3.adjusted.cellbin.gef"
outDir="/media/dell/scRNA/spatial/Stereo/brainC04042E3/toXenium"
# plot cell centroids without rotation
stereo2xenium plotRotation --file ${file} --output ${outDir} 
# try different theta value to rotate the image clockwisely or anticlockwisely.
stereo2xenium plotRotation --file ${file} --output ${outDir} --theta 138 --anticlockwise 

# Run stereo2xenium with proper theta values. 
# All of the coordination, including cell centroids, cell boundaries, and transcripts, will be rotated.
inDir="/media/dell/scRNA/spatial/Stereo/brainC04042E3/outs/visualization"   
outDir="/media/dell/scRNA/spatial/Stereo/brainC04042E3/toXenium"   
SN="C04042E3"  

stereo2xenium convert --input ${inDir} --output ${outDir} --sample ${SN} --segmentation 'HE' --genome mm10 --anticlockwise --theta 130
```

![image-20260127061837591](https://typora-1329573677.cos.ap-shanghai.myqcloud.com/img/image-20260127061837591.png)

![image-20260127061951636](https://typora-1329573677.cos.ap-shanghai.myqcloud.com/img/image-20260127061951636.png)

## Mapping molecules to cells

1. The stereo-seq output data typically does not include the cellbin.gem file, which is required for mapping molecules to cells. 

2. To generate this file, first run `saw convert` to retrieve the cellbin.gem. Then, run `stereo2xenium convert` to process the data. 

3. If `stereo2xenium convert` has already been executed, you can run `stereo2xenium getTranscripts` separately to complete the mapping of molecules to cells.

4. **Warning**: 

   Mapping molecules to cells is time- and memory-intensive and is not required for downstream analysis.

   You can skip it by running `stereo2xenium convert` without `--cellbin_gem`.

```bash
inDir=/media/dell/scRNA/spatial/Stereo/brainC04042E3/outs/visualization
SN=C04042E3

saw convert --threads-num 16 gef2gem --bin-size 1 \
--gef ${inDir}/${SN}.tissue.gef \
--cellbin-gef ${inDir}/${SN}.adjusted.cellbin.gef \
--cellbin-gem ${inDir}/${SN}.adjusted.cellbin.gem 

gzip ${inDir}/${SN}.adjusted.cellbin.gem

stereo2xenium convert --input ${inDir} --output ${outDir} --sample ${SN} --segmentation 'HE' --genome mm10 --cellbin_gem --anticlockwise --theta 130

stereo2xenium getTranscripts --input ${inDir} --sample ${SN} --output ${outDir} --cellbin_gem --theta 130 --anticlockwise
```



