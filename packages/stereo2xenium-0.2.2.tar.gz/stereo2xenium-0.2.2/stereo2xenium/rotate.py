import math
import numpy as np
import pandas as pd
import h5py


def rotateXY(df, theta=0, anticlockwise=False, center=(0, 0), x_col='x', y_col='y', decimals=2):
    # 提取坐标
    if isinstance(df, pd.DataFrame):
        x = df[x_col].values
        y = df[y_col].values
    else:
        x = df[:, 0] if df.shape[1] >= 1 else None
        y = df[:, 1] if df.shape[1] >= 2 else None

    # 平移到旋转中心
    cx, cy = center
    x_centered = x - cx
    y_centered = y - cy

    # 角度和旋转矩阵
    rad = math.radians(theta)
    cos_a, sin_a = math.cos(rad), math.sin(rad)

    if anticlockwise:
        x_new = x_centered * cos_a - y_centered * sin_a
        y_new = x_centered * sin_a + y_centered * cos_a
    else:
        x_new = x_centered * cos_a + y_centered * sin_a
        y_new = -x_centered * sin_a + y_centered * cos_a

    # 平移回
    x_rotated = x_new + cx
    y_rotated = y_new + cy

    # 舍入
    x_rotated = np.round(x_rotated, decimals)
    y_rotated = np.round(y_rotated, decimals)

    # 返回结果
    if isinstance(df, pd.DataFrame):
        result = df.copy()
        result[x_col] = x_rotated
        result[y_col] = y_rotated
        return result
    else:
        result = df.copy()
        result[:, 0] = x_rotated
        if result.shape[1] > 1:
            result[:, 1] = y_rotated
        return result


def plotCell(cellbin_gef, outDir, theta=0, anticlockwise=False, center=(0, 0), flip='none', flip_offset=30000, x_col='x', y_col='y', decimals=2, figsize=(10,10), dpi=144):
    import matplotlib.pyplot as plt
    import os
    os.makedirs(outDir, exist_ok=True)
    cells = h5py.File(cellbin_gef, 'r')['cellBin/cell'][:]   ###
    cells = pd.DataFrame(cells)
    cells = rotateXY(df=cells, theta=theta, anticlockwise=anticlockwise, center=center, x_col='x', y_col='y', decimals=decimals)
    if flip=='lr':
        cells[x_col]=flip_offset - cells[x_col]
    if flip=='ud':
        cells[y_col]=flip_offset - cells[y_col]

    # 确定方向标记
    direction = '-' if anticlockwise else '+'

    plt.figure(figsize=figsize)
    plt.scatter(x=cells[x_col], y=cells[y_col], s=0.1, linewidth=0.5)
    # plt.show()
    plt.savefig(f"{outDir}/rotation_{direction}{theta}.png", dpi=dpi, format='png')
    plt.close()


if __name__ == "__main__":
    # 设置参数
    inDir = "/media/dell/scRNA/spatial/Stereo/embryo/E18/outs"  # 替换为您的输入目录
    SN = "D05103C4D4"
    outDir = "/media/dell/scRNA/spatial/Stereo/embryo/E18/test" # 替换为您的输出目录
    cellbin_gef = inDir + "/"+ SN+ ".adjusted.cellbin.gef"  #  adjusted.cellbin.gef

    plotCell(cellbin_gef=inDir + "/" + SN + ".adjusted.cellbin.gef", outDir=outDir, theta=0, anticlockwise=False, figsize=(5, 10))
    plotCell(cellbin_gef=inDir + "/" + SN + ".adjusted.cellbin.gef", outDir=outDir, theta=0, anticlockwise=True, figsize=(5, 10), flip='lr', flip_scale=30000)

