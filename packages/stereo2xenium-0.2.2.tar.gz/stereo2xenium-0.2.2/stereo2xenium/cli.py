import argparse
import sys
from .stereo2xenium import get_cells, get_transcripts, h5_view
from .rotate import rotateXY, plotCell


def main():
    parser = argparse.ArgumentParser(description='Convert Stereo-seq data to 10X Genomics Xenium format for Seurat compatibility.')
    subparsers = parser.add_subparsers(dest='command', required=True)

    # getTranscripts
    getTranscripts = subparsers.add_parser('getTranscripts', help='Get Transcripts from Stereo-seq data')

    getTranscripts.add_argument('--input', required=True,
                                help='Input directory for Stereo-seq data, including:'
                                     'sample.tissue.gef, sample.adjusted.cellbin.gem (optional)')
    getTranscripts.add_argument('--output', required=True,
                                help='Output directory for converted Xenium format files')
    getTranscripts.add_argument('--sample', required=True, help='Sample ID/series number of the Stereo-seq chip. ')
    getTranscripts.add_argument('--cellbin_gem', action='store_true', default=False,
                                help='Enable mapping molecules to cell IDs. Requires *.adjusted.cellbin.gem file in input directory.')
    getTranscripts.add_argument('--theta', default=0, type=float, help='Rotation angle in degrees. Default is 0.')
    getTranscripts.add_argument('--anticlockwise', action='store_true', default=False,
                                help='Rotate in anticlockwise direction. Default is False.')
    getTranscripts.add_argument('--center', default=[0, 0], type=float, nargs=2, metavar=('x', 'y'), # 期望两个参数
                                help='Center of rotation. Default is (0, 0).'
                                    'Tip: Use the original image center as the rotation point to ensure all coordinates remain positive.')
    getTranscripts.add_argument('--flip', default='none',
                              help='Flip the coordinate. Options: [none, lr, ud]. '
                                   'none: not flip; lr: left-right flip; ud: up-down flip'  )
    getTranscripts.add_argument('--flip_offset', default=30000, type=int,
                                help='Offset value added to coordinates to prevent negative values after flipping. Default is 30000.')
    getTranscripts.add_argument('--decimals', default=2, type=int, help='Number of decimal to keep')

    # convert
    convert = subparsers.add_parser('convert', help='Convert Stereo-seq data to 10X Genomics Xenium format')

    convert.add_argument('--input', required=True,
                         help='Input directory containing the SWA output files:'
                              'sample.adjusted.cellbin.gef, sample.tissue.gef, sample.adjusted.cellbin.gem (optional)'
                              'Example directory: .../outs/feature_expression')
    convert.add_argument('--output', required=True,
                         help='Output directory for converted Xenium format files')
    convert.add_argument('--sample', required=True,
                         help='Sample ID/series number of the Stereo-seq chip. '
                              'Usually matches the prefix of Stereo-seq data files.')
    convert.add_argument('--cellbin_gem', action='store_true',
                         help='Enable mapping molecules to cell IDs. '
                              'Requires SN*.adjusted.cellbin.gem file in input directory.')
    convert.add_argument('--segmentation', required=True, default='ssDNA',
                         help='Cell segmentation method. eg: HE, ssDNA')
    convert.add_argument('--genome', default='unknown',
                         help='Reference genome name, e.g., GRCm39, GRCh38')
    convert.add_argument('--theta', default=0, type=float,
                         help='Rotation angle in degrees. Default is 0.')
    convert.add_argument('--anticlockwise', action='store_true', default=False,
                         help='Rotate in anticlockwise direction, rotate in clockwise.' )
    convert.add_argument('--center', default=[0, 0], type=float, nargs=2, metavar=('x', 'y'), # 期望两个参数
                         help='Center of rotation. Default is (0, 0).'
                              'Tip: Use the original image center as the rotation point to ensure all coordinates remain positive.' )
    convert.add_argument('--flip', default='none',
                              help='Flip the coordinate. Options: [none, lr, ud]. '
                                   'none: not flip; lr: left-right flip; ud: up-down flip' )
    convert.add_argument('--flip_offset', default=30000, type=int,
                         help='Offset value added to coordinates to prevent negative values after flipping. Default is 30000.' )
    convert.add_argument('--decimals', default=2, type=int, help='Number of decimal to keep')


    # viewh5
    viewh5 = subparsers.add_parser('viewh5', help='Browse HDF5 file contents as a tree-like structure')

    viewh5.add_argument('--h5file', required=True, help='h5 file path')


    # plotRotation
    plotRotation = subparsers.add_parser('plotRotation', help='Plot rotation cell positions')

    plotRotation.add_argument('--cellbin_gef', required=True,
                              help='Input file directory, ".adjusted.cellbin.gef" or ".cellbin.gef". '  )
    plotRotation.add_argument('--output', required=True,
                              help='Output directory for saving images.')
    plotRotation.add_argument('--theta', default=0, type=float,
                              help='Rotation angle in degrees. Default is 0.')
    plotRotation.add_argument('--anticlockwise', action='store_true', default=False,
                              help='rotate in anticlockwise direction, rotate in clockwise.' )
    plotRotation.add_argument('--x_col', default='x', help="Column name for x-axis")
    plotRotation.add_argument('--y_col', default='y', help="Column name for y-axis")
    plotRotation.add_argument('--center', default=[0, 0], type=float, nargs=2, metavar=('x', 'y'), # 期望两个参数
                              help='Center of rotation. Default is (0, 0).'
                                   'Tip: Use the original image center as the rotation point to ensure all coordinates remain positive.')
    plotRotation.add_argument('--decimals', default=2, type=int, help= 'Number of decimal to keep')
    plotRotation.add_argument('--figsize', default=[10, 10], type=float, nargs=2, metavar=('x', 'y'), # 期望两个参数
                              help='Figure size. Default is (10, 10) ' )
    plotRotation.add_argument('--dpi',  default=144, type=int, help= 'DPI of plot')
    plotRotation.add_argument('--flip', default='none',
                              help= 'Flip the coordinate. Options: [none, lr, ud]. '
                                    'none: not flip; lr: left-right flip; ud: up-down flip')
    plotRotation.add_argument('--flip_offset', default=30000, type=int, help='Offset value added to coordinates to prevent negative values after flipping. Default is 30000.' )

    # 解析参数
    args = parser.parse_args()

    # 执行命令
    try:
        if args.command == 'convert':
            get_cells(
                inDir=args.input,
                SN=args.sample,
                outDir=args.output,
                segmentation=args.segmentation,
                genome=args.genome,
                theta=args.theta,
                anticlockwise=args.anticlockwise,
                center=args.center,
                flip=args.flip,
                flip_offset=args.flip_offset,
                decimals=args.decimals
            )

            get_transcripts(
                inDir=args.input,
                SN=args.sample,
                outDir=args.output,
                cellbin_gem=args.cellbin_gem,
                theta=args.theta,
                anticlockwise=args.anticlockwise,
                center=args.center,
                flip=args.flip,
                flip_offset=args.flip_offset,
                decimals=args.decimals
            )

        elif args.command == 'getTranscripts':
            get_transcripts(
                inDir=args.input,
                SN=args.sample,
                outDir=args.output,
                cellbin_gem=args.cellbin_gem,
                theta=args.theta,
                anticlockwise=args.anticlockwise,
                center=args.center,
                flip=args.flip,
                flip_offset=args.flip_offset,
                decimals=args.decimals
            )


        elif args.command == 'viewh5':
            h5_view(h5File=args.h5file)

        elif args.command == 'plotRotation':
            plotCell(
                cellbin_gef=args.cellbin_gef,
                outDir=args.output,
                theta=args.theta,
                anticlockwise=args.anticlockwise,
                x_col=args.x_col,
                y_col=args.y_col,
                center=args.center,
                flip=args.flip,
                flip_offset=args.flip_offset,
                decimals=args.decimals,
                figsize=args.figsize,
                dpi=args.dpi
            )

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    sys.exit(0)


