from graph_mcp.server import main

__all__ = ["main"]
