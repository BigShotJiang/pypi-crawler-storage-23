"""Allow running as: python -m proton_to_icloud"""

from proton_to_icloud.cli import main

main()
