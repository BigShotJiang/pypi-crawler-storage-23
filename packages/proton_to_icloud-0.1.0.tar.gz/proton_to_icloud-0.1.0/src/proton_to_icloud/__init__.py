"""proton-to-icloud: Migrate Proton Mail exports to iCloud Mail."""

__version__ = "0.1.0"
