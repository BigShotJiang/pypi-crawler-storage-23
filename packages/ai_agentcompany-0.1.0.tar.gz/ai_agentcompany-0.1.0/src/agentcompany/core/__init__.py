"""AgentCompany core - agents, company, tasks, and messaging."""
