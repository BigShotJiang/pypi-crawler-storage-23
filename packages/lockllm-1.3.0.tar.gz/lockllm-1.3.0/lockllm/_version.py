"""Single source of truth for the LockLLM SDK version."""

__version__ = "1.3.0"
