"""
FEC (Fichier des Écritures Comptables) CSV filter.

Reads a pipe-delimited (|) UTF-8 CSV file with CR LF line endings and filters
out rows matching any of these exclusion rules:
  1. JournalCode == "CSH"
  2. JournalCode == "POS" AND EcritureDate between 2025-07-01 and 2025-12-31
  3. JournalCode == "BCI" AND PieceRef contains "PBCI"

Usage:
    python main.py <input_file> [output_file]

If no output file is given, the result is written to <input_file>_filtered.csv
"""

import csv
import sys
import os
from datetime import date


DELIMITER = "|"
DATE_START = date(2025, 7, 1)
DATE_END = date(2025, 11, 30)


def parse_date(value: str) -> date | None:
    """Parse a date string in YYYY-MM-DD or YYYYMMDD format."""
    value = value.strip()
    for fmt in ("%Y-%m-%d", "%Y%m%d"):
        try:
            return date(*map(int, (value[:4], value[5:7] if fmt == "%Y-%m-%d" else value[4:6],
                                    value[8:10] if fmt == "%Y-%m-%d" else value[6:8])))
        except (ValueError, IndexError):
            continue
    return None


def should_keep(row: dict) -> bool:
    """Return True if the row should be kept (does NOT match any exclusion rule)."""
    journal = row.get("JournalCode", "").strip()
    ecriture_num = row.get("EcritureNum", "").strip()
    compte_num = row.get("CompteNum", "").strip()
    piece_ref = row.get("PieceRef", "").strip()
    ecriture_date_str = row.get("EcritureDate", "").strip()

    # Rule 1: exclude JournalCode == "CSH"
    if journal == "CSH1":
        return False

    # Rule 2: exclude JournalCode == "POS" with EcritureDate between a range
    if journal == "POSS":
        d = parse_date(ecriture_date_str)
        if d is not None and DATE_START <= d <= DATE_END:
            return False

    # Rule 3: exclude JournalCode == "BCI" with PieceRef containing "PBCI" with EcritureDate between a range
    # ["401000", "512002", "512003"] are PBCI fournisseurs, so we keep those
    # PBCI in ecriture_num for journal entry and in piece_ref for reversal journal entry
    if journal == "BCI" and ("PBCI" in piece_ref or "PBCI" in ecriture_num) and compte_num not in ["401000", "512002", "512003"]:
        d = parse_date(ecriture_date_str)
        if d is not None and DATE_START <= d <= DATE_END:
            return False

    return True


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__.strip())
        sys.exit(1)

    input_path = sys.argv[1]
    if len(sys.argv) >= 3:
        output_path = sys.argv[2]
    else:
        base, ext = os.path.splitext(input_path)
        output_path = f"{base}_FILTRE{ext}"

    # Read ----------------------------------------------------------------
    with open(input_path, mode="r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=DELIMITER)
        if reader.fieldnames is None:
            print("Error: could not read header from input file.", file=sys.stderr)
            sys.exit(1)
        fieldnames = reader.fieldnames
        rows_in = list(reader)

    # Filter --------------------------------------------------------------
    rows_out = [row for row in rows_in if should_keep(row)]

    # Write ---------------------------------------------------------------
    with open(output_path, mode="w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=DELIMITER,
                                lineterminator="\r\n")
        writer.writeheader()
        writer.writerows(rows_out)

    removed = len(rows_in) - len(rows_out)
    print(f"Done.  {len(rows_in)} rows read, {removed} removed, "
          f"{len(rows_out)} written to {output_path}")


if __name__ == "__main__":
    main()
