# pga.csv.filter

## Introduction

Cet outil a été créé initialement pour retirer des écritures d'un fichier FEC en vue d'importer l'édition filtrée.

Les filtres sont actuellement "en dur" dans le code.

## Utilisation

uv run main.py ./data/FEC20260210.csv
Ou
uvx pga-csv-filter ./data/FEC20260210.csv

## Publication

uv build
uv publish