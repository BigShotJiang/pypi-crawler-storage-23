"""Source fetcher registry."""

from platoon.sources.hacker_news import fetch_hacker_news
from platoon.sources.arxiv import fetch_arxiv
from platoon.sources.lobsters import fetch_lobsters
from platoon.sources.papers_with_code import fetch_papers_with_code
from platoon.sources.semantic_scholar import fetch_semantic_scholar
from platoon.sources.openalex import fetch_openalex
from platoon.sources.reddit import fetch_reddit
from platoon.sources.github_trending import fetch_github_trending
from platoon.sources.hn_algolia import fetch_hn_algolia
from platoon.sources.rss_feeds import fetch_rss_feeds
from platoon.sources.google_news import fetch_google_news
from platoon.sources.flipboard import fetch_flipboard
from platoon.sources.trivia import fetch_trivia

SOURCE_FETCHERS = {
    "hacker_news": fetch_hacker_news,
    "arxiv": fetch_arxiv,
    "lobsters": fetch_lobsters,
    "papers_with_code": fetch_papers_with_code,
    "semantic_scholar": fetch_semantic_scholar,
    "openalex": fetch_openalex,
    "reddit": fetch_reddit,
    "github_trending": fetch_github_trending,
    "hn_algolia": fetch_hn_algolia,
    "rss_feeds": fetch_rss_feeds,
    "google_news": fetch_google_news,
    "flipboard": fetch_flipboard,
    "trivia": fetch_trivia,
}
