#!/usr/bin/env python3
"""
Test for omnitool
"""
import os
import sys

# Ensure project root on PYTHONPATH if not set externally
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if root not in sys.path:
    sys.path.insert(0, root)

from computer_use_demo.tools.utils.omnitool import omnitool

def main():
    result = omnitool('test_tool', message='hello via omnitool')
    print('OmniTool test result:', result)

if __name__ == '__main__':
    main()
#!/usr/bin/env python3
import os
import sys

# Ensure project root on PYTHONPATH if not set externally
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if root not in sys.path:
    sys.path.insert(0, root)

from computer_use_demo.tools.utils.omnitool import omnitool

def main():
    result = omnitool('test_tool', message='hello via omnitool')
    print('OmniTool test result:', result)

if __name__ == '__main__':
    main()
import sys
import os
# Add project root to path
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
sys.path.append(root)
# Add tools base path
sys.path.append(os.path.join(root, 'core', 'computer_use_demo', 'tools', 'base', 'tools'))
# Add utils directory to path
utils_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(utils_dir)
import os
# Add project root to path
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
sys.path.append(root)
# Add utils directory to path
utils_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
sys.path.append(utils_dir)
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
    # Ensure core on path
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))) 
# Also need tools path
sys.path.append('/home/GOD/core/computer_use_demo/tools/base/tools')
from utils.omnitool import omnitool

def main():
    result = omnitool('test_tool', message='hello via omnitool')
    print('OmniTool test result:', result)

if __name__ == '__main__':
    main()