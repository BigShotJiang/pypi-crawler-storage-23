#!/usr/bin/env python3
"""
Neo4jTool sanity-check via OmniTool.
Creates a simple node then reads it back.
Run path: /home/GOD/core/computer_use_demo/tools/utils/test_neo4jtool_real.py
"""
import os, sys

# add project root to PYTHONPATH
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
if root not in sys.path:
    sys.path.insert(0, root)

from computer_use_demo.tools.utils.omnitool import omnitool

CREATE_Q = "CREATE (:Hello {msg:'world'}) RETURN 'node_created' AS confirm"
READ_Q   = "MATCH (n:Hello) RETURN n.msg AS msg LIMIT 1"


def main():
    # write a node
    create_res = omnitool('Neo4jTool', query=CREATE_Q, visualize=False)
    print('Create result:', create_res)

    # read it back
    read_res = omnitool('Neo4jTool', query=READ_Q, visualize=False)
    print('Read result:', read_res)


if __name__ == '__main__':
    main()
