#!/usr/bin/env python3
# /home/GOD/core/computer_use_demo/tools/utils/test_omnitool_real.py

"""
Test for omnitool (real)
"""
import os
import sys

# Ensure project root on PYTHONPATH if not set externally
# Ensure project root on PYTHONPATH (one level above computer_use_demo)
root = os.path.abspath(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..')))
if root not in sys.path:
    sys.path.insert(0, root)

from computer_use_demo.tools.utils.omnitool import omnitool

def main():
    result = omnitool('test_tool', message='hello via omnitool (real)')
    print('OmniTool test result:', result)

if __name__ == '__main__':
    main()