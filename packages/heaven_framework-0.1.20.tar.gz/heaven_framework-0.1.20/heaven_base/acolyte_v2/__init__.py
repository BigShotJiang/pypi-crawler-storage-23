"""
HEAVEN Acolyte V2 - Proper Agent Implementation

The acolyte is an actual AGENT that generates scripts and HermesConfigs.
"""

from .acolyte_agent_config import acolyte_agent_config

__all__ = ["acolyte_agent_config"]