#!/usr/bin/env python3
"""
Test complete auto_summarize pipeline.
"""

import sys
sys.path.insert(0, '/home/GOD/heaven-base')
import asyncio
from heaven_base.utils.auto_summarize import auto_summarize
from heaven_base.memory.history import History
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

async def test_auto_summarize_pipeline():
    print("=== Testing Complete auto_summarize Pipeline ===")
    
    # Use existing test history file (created once)
    test_history_id = "2025_07_30_18_00_41_test_pipeline_agent"
    
    print(f"Using test history ID: {test_history_id}")
    
    # Test the full auto_summarize pipeline
    print("\nRunning auto_summarize pipeline...")
    summary = await auto_summarize(test_history_id)
    
    print(f"Pipeline completed!")
    print(f"Summary type: {type(summary)}")
    print(f"Summary length: {len(summary) if summary else 0}")
    
    if summary and summary != "Failed to create aggregated summary":
        print(f"Summary: {summary}...")
        return summary
    else:
        print("Pipeline failed or returned empty summary")
        return None

if __name__ == "__main__":
    result = asyncio.run(test_auto_summarize_pipeline())