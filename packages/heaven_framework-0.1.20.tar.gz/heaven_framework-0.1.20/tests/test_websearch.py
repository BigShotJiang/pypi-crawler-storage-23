#!/usr/bin/env python3
"""
Test the WebsearchTool to make sure it works correctly.
"""

import asyncio
import sys
sys.path.insert(0, '/home/GOD/heaven-base')

from heaven_base.tools.websearch_tool import _perform_websearch


async def test_websearch():
    """Test basic websearch functionality."""
    
    print("🔍 Testing WebsearchTool")
    print("=" * 40)
    
    # Test a simple search
    test_query = "Python asyncio tutorial"
    
    print(f"Testing search query: '{test_query}'")
    print("Performing search...")
    
    try:
        # Use the websearch function directly
        result = await _perform_websearch(search_goal=test_query)
        
        print("✅ Websearch completed successfully!")
        print(f"Result type: {type(result)}")
        
        if hasattr(result, 'output') and result.output:
            print(f"Search result preview: {result.output[:200]}...")
        elif isinstance(result, str):
            print(f"Search result preview: {result[:200]}...")
        else:
            print(f"Result: {result}")
            
        return True
        
    except Exception as e:
        print(f"❌ Websearch failed: {type(e).__name__}: {e}")
        
        # Print more debug info
        import traceback
        print(f"\nFull traceback:")
        traceback.print_exc()
        
        return False


async def main():
    """Run websearch test."""
    print("🧪 Testing WebsearchTool in heaven-base")
    print()
    
    success = await test_websearch()
    
    print("\n" + "=" * 40)
    if success:
        print("🎉 SUCCESS: WebsearchTool is working correctly!")
    else:
        print("❌ FAILED: WebsearchTool has issues")
        print("This could be due to:")
        print("  - Missing OpenAI API key")
        print("  - Network connectivity issues")
        print("  - LangChain dependency problems")


if __name__ == "__main__":
    asyncio.run(main())