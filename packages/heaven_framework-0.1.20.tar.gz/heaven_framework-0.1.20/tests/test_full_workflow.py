#!/usr/bin/env python3
"""
Test the complete get_summary_reasoning_and_concept workflow.
"""

import sys
sys.path.insert(0, '/home/GOD/heaven-base')
import asyncio
from heaven_base.utils.auto_summarize import get_summary_reasoning_and_concept
from heaven_base.memory.history import History
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

async def test_full_workflow():
    print("=== Testing Full get_summary_reasoning_and_concept Workflow ===")
    
    # Create a mock history
    history = History(messages=[
        SystemMessage(content="You are a helpful assistant."),
        HumanMessage(content="Help me implement a codebase analyzer"),
        AIMessage(content="I'll help you build a 4-layer analysis system with ingestion, summarization, overview, and idea generation."),
        HumanMessage(content="Fix the tool capture for OpenAI format"),
        AIMessage(content="I've updated the look_for_particular_tool_calls method to handle both Anthropic and OpenAI formats correctly.")
    ])
    history.history_id = "test_full_workflow"
    
    print(f"Created test history with {len(history.messages)} messages")
    
    try:
        print("\nRunning full workflow...")
        result = await get_summary_reasoning_and_concept(history)
        
        print(f"Workflow completed!")
        print(f"Result keys: {list(result.keys())}")
        
        if 'summary_and_reasoning' in result:
            sr = result['summary_and_reasoning']
            print(f"Has summary: {'summary' in sr}")
            print(f"Has reasoning: {'reasoning' in sr}")
            
        if 'concept' in result:
            print(f"Has concept: {result['concept'] is not None}")
            if result['concept']:
                print(f"Concept preview: {result['concept'][:200]}...")
        
        return result
        
    except Exception as e:
        print(f"Workflow failed with error: {e}")
        print("This is expected due to the intermittent 400 error issue we identified")
        return None

if __name__ == "__main__":
    result = asyncio.run(test_full_workflow())