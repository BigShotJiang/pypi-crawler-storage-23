#!/usr/bin/env bash
set -euo pipefail

PROFILE="${1:-local}"

python - <<'PY' "${PROFILE}"
import json
import sys
from pathlib import Path

profile_name = sys.argv[1]
config = json.loads(Path("docs/open-core/deployment-profile-lock.json").read_text(encoding="utf-8"))
profiles = config["profiles"]
if profile_name not in profiles:
    raise SystemExit(f"unknown profile: {profile_name}")
profile = profiles[profile_name]

print(f"profile={profile_name}")
print(f"api_base_url={profile['api_base_url']}")
print(f"web_base_url={profile['web_base_url']}")
print(f"cors_origins={','.join(profile['cors_origins'])}")
print(f"oauth_callbacks={','.join(profile['oauth_callbacks'])}")
PY

echo "Environment contract check passed for profile=${PROFILE}"
