#!/usr/bin/env bash
set -euo pipefail

WEB_BASE="${WEB_BASE:-http://127.0.0.1:3000}"

for path in / /pricing /features /docs /contact /privacy /terms; do
  status_code="$(curl -L -s -o /tmp/skillgate-web-smoke.out -w '%{http_code}' "${WEB_BASE}${path}")"
  if [[ "${status_code}" != "200" ]]; then
    echo "Web smoke failed for ${path} status=${status_code}"
    exit 1
  fi
done

echo "Web smoke passed"
