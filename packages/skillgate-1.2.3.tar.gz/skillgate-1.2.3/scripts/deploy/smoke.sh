#!/usr/bin/env bash
set -euo pipefail

PROFILE="${1:-local}"

read -r API_BASE WEB_BASE < <(python - <<'PY' "${PROFILE}"
import json
import sys
from pathlib import Path

profile_name = sys.argv[1]
config = json.loads(Path("docs/open-core/deployment-profile-lock.json").read_text(encoding="utf-8"))
profile = config["profiles"].get(profile_name)
if profile is None:
    raise SystemExit(f"unknown profile: {profile_name}")
print(profile["api_base_url"], profile["web_base_url"])
PY
)

API_BASE="${API_BASE_OVERRIDE:-$API_BASE}" WEB_BASE="${WEB_BASE_OVERRIDE:-$WEB_BASE}" \
  ./scripts/deploy/smoke_api.sh

API_BASE="${API_BASE_OVERRIDE:-$API_BASE}" WEB_BASE="${WEB_BASE_OVERRIDE:-$WEB_BASE}" \
  ./scripts/deploy/smoke_web.sh

echo "Smoke checks passed for profile=${PROFILE}"
