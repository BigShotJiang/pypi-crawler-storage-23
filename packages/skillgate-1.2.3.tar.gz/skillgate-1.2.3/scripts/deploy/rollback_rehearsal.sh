#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${SKILLGATE_DATABASE_URL:-}" ]]; then
  echo "SKILLGATE_DATABASE_URL is required for rollback rehearsal"
  exit 1
fi

if [[ "${SKIP_DOWNGRADE:-false}" == "true" ]]; then
  echo "Skipping downgrade rehearsal due to SKIP_DOWNGRADE=true"
  exit 0
fi

echo "[rollback] upgrading to head"
alembic upgrade head

echo "[rollback] downgrading by one revision"
alembic downgrade -1

echo "[rollback] restoring to head"
alembic upgrade head

echo "[rollback] rehearsal complete"
