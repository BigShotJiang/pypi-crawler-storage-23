#!/usr/bin/env bash
set -euo pipefail

API_BASE="${API_BASE:-http://127.0.0.1:8000/api/v1}"

curl -fsS "${API_BASE}/health" >/tmp/skillgate-api-health.json

if ! rg -q '"status"\s*:\s*"ok"' /tmp/skillgate-api-health.json; then
  echo "API health smoke failed"
  cat /tmp/skillgate-api-health.json
  exit 1
fi

echo "API smoke passed"
