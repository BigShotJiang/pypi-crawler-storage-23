#!/usr/bin/env bash
set -euo pipefail

CANARY_API_BASE="${CANARY_API_BASE:-}"
STABLE_API_BASE="${STABLE_API_BASE:-}"
CANARY_WEB_BASE="${CANARY_WEB_BASE:-}"
STABLE_WEB_BASE="${STABLE_WEB_BASE:-}"

if [[ -z "${CANARY_API_BASE}" || -z "${STABLE_API_BASE}" ]]; then
  echo "CANARY_API_BASE and STABLE_API_BASE are required"
  exit 1
fi

if [[ -z "${CANARY_WEB_BASE}" || -z "${STABLE_WEB_BASE}" ]]; then
  echo "CANARY_WEB_BASE and STABLE_WEB_BASE are required"
  exit 1
fi

check_json_health() {
  local base="$1"
  local out
  out="$(curl -fsS "${base%/}/api/v1/health")"
  echo "${out}" | rg -q '"status"\s*:\s*"ok"'
}

check_web() {
  local base="$1"
  local path="$2"
  local code
  code="$(curl -L -s -o /tmp/sg-canary-web.out -w '%{http_code}' "${base%/}${path}")"
  [[ "${code}" == "200" ]]
}

check_json_health "${CANARY_API_BASE}"
check_json_health "${STABLE_API_BASE}"

for path in / /pricing /features /docs; do
  check_web "${CANARY_WEB_BASE}" "${path}"
  check_web "${STABLE_WEB_BASE}" "${path}"
done

echo "Canary gate passed"
