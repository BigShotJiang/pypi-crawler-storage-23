#!/usr/bin/env bash
set -euo pipefail

RELEASE_ID="${RELEASE_ID:-unknown}"
ROLLBACK_TARGET="${ROLLBACK_TARGET:-previous}"
DRY_RUN="${DRY_RUN:-true}"

if [[ "${DRY_RUN}" == "true" ]]; then
  echo "[rollback] dry-run release=${RELEASE_ID} target=${ROLLBACK_TARGET}"
  exit 0
fi

echo "[rollback] release=${RELEASE_ID} target=${ROLLBACK_TARGET}"
echo "Implement platform-specific rollback command in deployment environment."
