"""Generate docs-facing rule catalog JSON from the canonical rule registry."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from skillgate.core.analyzer.rules import get_all_rules

REPO_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_PATH = REPO_ROOT / "skillgate-docs" / "src" / "lib" / "generated" / "rule-catalog.json"


def _serialize_rule(rule: Any) -> dict[str, Any]:
    rule_id = str(rule.id)
    parts = rule_id.split("-")
    category = parts[1] if len(parts) > 1 else "UNKNOWN"
    severity = str(getattr(rule.severity, "value", rule.severity)).upper()
    return {
        "id": rule_id,
        "name": str(rule.name),
        "description": str(rule.description),
        "severity": severity,
        "weight": int(rule.weight),
        "category": category,
    }


def main() -> None:
    rules = sorted(get_all_rules(), key=lambda rule: str(rule.id))
    payload = {
        "generated_at": "2026-02-28",
        "total_rules": len(rules),
        "rules": [_serialize_rule(rule) for rule in rules],
    }
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(rules)} rules to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
