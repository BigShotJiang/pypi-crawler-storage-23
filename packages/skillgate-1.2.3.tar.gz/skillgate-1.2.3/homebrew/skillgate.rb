# Homebrew formula for SkillGate
#
# To install from this tap:
#   brew tap skillgate/tap
#   brew install skillgate
#
# Or directly:
#   brew install skillgate/tap/skillgate

class Skillgate < Formula
  include Language::Python::Virtualenv

  desc "CLI-first CI/CD policy enforcement tool for agent skill security"
  homepage "https://skillgate.io"
  url "https://files.pythonhosted.org/packages/source/s/skillgate/skillgate-1.0.0.tar.gz"
  sha256 "PLACEHOLDER_SHA256"
  license "Proprietary"

  depends_on "python@3.12"

  resource "typer" do
    url "https://files.pythonhosted.org/packages/source/t/typer/typer-0.15.0.tar.gz"
    sha256 "PLACEHOLDER"
  end

  resource "rich" do
    url "https://files.pythonhosted.org/packages/source/r/rich/rich-13.9.0.tar.gz"
    sha256 "PLACEHOLDER"
  end

  resource "pydantic" do
    url "https://files.pythonhosted.org/packages/source/p/pydantic/pydantic-2.10.0.tar.gz"
    sha256 "PLACEHOLDER"
  end

  resource "pyyaml" do
    url "https://files.pythonhosted.org/packages/source/P/PyYAML/pyyaml-6.0.2.tar.gz"
    sha256 "PLACEHOLDER"
  end

  resource "pynacl" do
    url "https://files.pythonhosted.org/packages/source/P/PyNaCl/pynacl-1.5.0.tar.gz"
    sha256 "PLACEHOLDER"
  end

  resource "httpx" do
    url "https://files.pythonhosted.org/packages/source/h/httpx/httpx-0.28.0.tar.gz"
    sha256 "PLACEHOLDER"
  end

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match "skillgate", shell_output("#{bin}/skillgate version")
    assert_match "SG-SHELL", shell_output("#{bin}/skillgate rules --output json")
  end
end
