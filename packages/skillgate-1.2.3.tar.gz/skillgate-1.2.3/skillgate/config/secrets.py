"""Secure secret storage and redaction utilities."""

from __future__ import annotations

import importlib
import logging
import os
import re
from typing import Any, Final

logger = logging.getLogger(__name__)

# Optional keyring dependency
keyring: Any | None
try:
    keyring = importlib.import_module("keyring")
except ImportError:
    keyring = None

KEYRING_AVAILABLE: Final[bool] = keyring is not None

# Pattern to match SkillGate API keys (sg_{tier}_{32 hex chars})
API_KEY_PATTERN = re.compile(r"sg_[a-z]+_[a-f0-9]{32}", re.IGNORECASE)

# Environment variable names
ENV_VAR_API_KEY = "SKILLGATE_API_KEY"


class SecretStore:
    """Secure secret storage with keychain > env var > none fallback."""

    def __init__(self) -> None:
        self._keyring_available = KEYRING_AVAILABLE

    def get_api_key(self) -> str | None:
        """Get API key from keychain, then env var, then None.

        Priority:
        1. System keychain (via keyring package)
        2. SKILLGATE_API_KEY environment variable
        3. None

        Returns:
            API key string or None
        """
        # Try keychain first
        if self._keyring_available and keyring is not None:
            try:
                key = keyring.get_password("skillgate", "api_key")
                if key:
                    logger.debug("API key loaded from system keychain")
                    return str(key)
            except Exception as e:
                logger.debug(f"Keyring access failed: {e}")

        # Fallback to environment variable
        env_key = os.environ.get(ENV_VAR_API_KEY)
        if env_key:
            logger.debug("API key loaded from environment variable")
            return env_key

        return None

    def set_api_key(self, key: str) -> None:
        """Store API key in keychain if available, otherwise env var.

        Args:
            key: API key to store
        """
        if self._keyring_available and keyring is not None:
            try:
                keyring.set_password("skillgate", "api_key", key)
                logger.info("API key stored in system keychain")
                return
            except Exception as e:
                logger.warning(f"Failed to store key in keychain: {e}")

        # Fallback to environment variable (not persistent)
        os.environ[ENV_VAR_API_KEY] = key
        logger.warning("Keychain unavailable; API key stored in environment (not persistent)")

    def delete_api_key(self) -> None:
        """Delete API key from keychain and env var."""
        if self._keyring_available and keyring is not None:
            try:
                keyring.delete_password("skillgate", "api_key")
                logger.info("API key deleted from system keychain")
            except Exception as e:
                logger.debug(f"Keyring deletion failed: {e}")

        os.environ.pop(ENV_VAR_API_KEY, None)


def redact_secrets(text: str) -> str:
    """Redact SkillGate API keys from text.

    Args:
        text: Text that may contain API keys

    Returns:
        Text with API keys replaced by [REDACTED]

    Examples:
        >>> redact_secrets("Key: sg_pro_a1b2c3d4e5f6...")
        'Key: [REDACTED]'
    """
    return API_KEY_PATTERN.sub("[REDACTED]", text)
