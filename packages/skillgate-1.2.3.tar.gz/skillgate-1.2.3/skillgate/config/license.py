"""License validation for SkillGate API key tiers."""

from __future__ import annotations

import re
from enum import Enum

from skillgate.core.errors import ConfigError


class Tier(str, Enum):
    """License tier levels."""

    FREE = "free"
    PRO = "pro"
    TEAM = "team"
    ENTERPRISE = "enterprise"


# Tier prefix mapping: sg_{tier}_{random}
TIER_PREFIXES: dict[str, Tier] = {
    "sg_free_": Tier.FREE,
    "sg_pro_": Tier.PRO,
    "sg_team_": Tier.TEAM,
    "sg_ent_": Tier.ENTERPRISE,
}

# Rate limits per tier (requests per minute)
RATE_LIMITS: dict[Tier, int] = {
    Tier.FREE: 10,
    Tier.PRO: 60,
    Tier.TEAM: 300,
    Tier.ENTERPRISE: 1000,
}

# API key format: sg_{tier}_{32 hex chars}
API_KEY_PATTERN = re.compile(r"^sg_(free|pro|team|ent)_[a-f0-9]{32}$")


def validate_api_key(key: str) -> Tier:
    """Validate an API key format and return its tier.

    This is local-only validation (format check, no network call).
    Server-side validation happens separately on hosted API calls.
    """
    if not API_KEY_PATTERN.match(key):
        raise ConfigError("Invalid API key")

    for prefix, tier in TIER_PREFIXES.items():
        if key.startswith(prefix):
            return tier

    raise ConfigError("Invalid API key")


def get_api_key() -> str | None:
    """Get API key using secure storage (keychain > env var > None)."""
    from skillgate.config.secrets import SecretStore

    return SecretStore().get_api_key()


def get_current_tier() -> Tier:
    """Get the current tier based on API key (defaults to FREE)."""
    key = get_api_key()
    if key is None:
        return Tier.FREE
    return validate_api_key(key)


def get_rate_limit(tier: Tier | None = None) -> int:
    """Get rate limit for a tier (requests per minute)."""
    if tier is None:
        tier = get_current_tier()
    return RATE_LIMITS[tier]
