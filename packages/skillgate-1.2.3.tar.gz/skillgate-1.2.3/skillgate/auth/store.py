"""Secure local SLT storage with keychain-first strategy."""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import platform
import subprocess
import uuid
from contextlib import suppress
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEYRING_SERVICE = "skillgate"
KEYRING_USERNAME = "slt"


class SecureSLTStore:
    """Store SLT in system keychain if possible, otherwise encrypted file."""

    def __init__(
        self,
        *,
        keychain_service: str = KEYRING_SERVICE,
        keychain_user: str = KEYRING_USERNAME,
        home: Path | None = None,
    ) -> None:
        self._service = keychain_service
        self._user = keychain_user
        self._home = home or Path.home()
        self._state_dir = self._home / ".skillgate"
        self._enc_file = self._state_dir / "slt.enc"
        self._salt_file = self._state_dir / "slt.salt"

    def store(self, token: str) -> str:
        """Store token and return storage backend used."""
        if self._store_keyring(token):
            return "keychain"
        self._store_encrypted_file(token)
        return "encrypted_file"

    def load(self) -> str | None:
        """Load token from keychain or encrypted file."""
        keyring_token = self._load_keyring()
        if keyring_token:
            return keyring_token
        if not self._enc_file.exists():
            return None
        return self._load_encrypted_file()

    def clear(self) -> None:
        """Delete token from all stores."""
        self._clear_keyring()
        if self._enc_file.exists():
            self._enc_file.unlink()

    def _store_keyring(self, token: str) -> bool:
        module = _load_keyring_module()
        if module is not None:
            try:
                module.set_password(self._service, self._user, token)
                return True
            except Exception:  # noqa: BLE001
                return False

        system = platform.system().lower()
        if system == "darwin":
            return _store_macos_keychain(self._service, self._user, token)
        return False

    def _load_keyring(self) -> str | None:
        module = _load_keyring_module()
        if module is not None:
            try:
                value = module.get_password(self._service, self._user)
                return str(value) if value else None
            except Exception:  # noqa: BLE001
                return None

        system = platform.system().lower()
        if system == "darwin":
            return _load_macos_keychain(self._service, self._user)
        return None

    def _clear_keyring(self) -> None:
        module = _load_keyring_module()
        if module is not None:
            with suppress(Exception):
                module.delete_password(self._service, self._user)
            return

        system = platform.system().lower()
        if system == "darwin":
            _delete_macos_keychain(self._service, self._user)

    def _store_encrypted_file(self, token: str) -> None:
        self._state_dir.mkdir(parents=True, exist_ok=True)
        self._state_dir.chmod(0o700)

        key = self._derive_key()
        nonce = os.urandom(12)
        ciphertext = AESGCM(key).encrypt(nonce, token.encode("utf-8"), b"skillgate-slt-v1")
        payload = {
            "nonce": nonce.hex(),
            "ciphertext": ciphertext.hex(),
        }
        self._enc_file.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
        self._enc_file.chmod(0o600)

    def _load_encrypted_file(self) -> str | None:
        try:
            payload = json.loads(self._enc_file.read_text(encoding="utf-8"))
            nonce = bytes.fromhex(str(payload["nonce"]))
            ciphertext = bytes.fromhex(str(payload["ciphertext"]))
            key = self._derive_key()
            plaintext = AESGCM(key).decrypt(nonce, ciphertext, b"skillgate-slt-v1")
            return plaintext.decode("utf-8")
        except Exception:  # noqa: BLE001
            return None

    def _derive_key(self) -> bytes:
        self._state_dir.mkdir(parents=True, exist_ok=True)
        if not self._salt_file.exists():
            self._salt_file.write_text(uuid.uuid4().hex, encoding="utf-8")
            self._salt_file.chmod(0o600)
        salt = self._salt_file.read_text(encoding="utf-8").strip()
        material = f"{platform.node()}:{self._user}:{salt}".encode()
        return hashlib.sha256(material).digest()


def _load_keyring_module() -> Any | None:
    try:
        return importlib.import_module("keyring")
    except ImportError:
        return None


def _store_macos_keychain(service: str, account: str, token: str) -> bool:
    result = subprocess.run(
        [
            "security",
            "add-generic-password",
            "-U",
            "-a",
            account,
            "-s",
            service,
            "-w",
            token,
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    return result.returncode == 0


def _load_macos_keychain(service: str, account: str) -> str | None:
    result = subprocess.run(
        ["security", "find-generic-password", "-a", account, "-s", service, "-w"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _delete_macos_keychain(service: str, account: str) -> None:
    subprocess.run(
        ["security", "delete-generic-password", "-a", account, "-s", service],
        capture_output=True,
        text=True,
        check=False,
    )
