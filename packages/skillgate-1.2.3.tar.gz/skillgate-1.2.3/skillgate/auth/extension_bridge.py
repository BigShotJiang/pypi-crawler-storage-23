"""VS Code extension-facing auth state models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

LicenseUiState = Literal["licensed", "limited", "needs-login"]


@dataclass(frozen=True)
class ExtensionAuthState:
    """State returned to extension UI without exposing secrets."""

    mode: LicenseUiState
    tier: str
    budget_remaining: dict[str, int]


def extension_state_from_entitlements(
    *,
    tier: str,
    mode: str,
    budget_remaining: dict[str, int],
) -> ExtensionAuthState:
    """Map entitlement payload to extension UI mode.

    ``mode`` values from sidecar:
    - ``normal`` -> ``licensed``
    - ``limited`` -> ``limited``
    - everything else -> ``needs-login``
    """
    if mode == "normal":
        ui_mode: LicenseUiState = "licensed"
    elif mode == "limited":
        ui_mode = "limited"
    else:
        ui_mode = "needs-login"
    return ExtensionAuthState(mode=ui_mode, tier=tier, budget_remaining=dict(budget_remaining))
