"""SkillGate Session License Token (SLT) auth primitives."""

from skillgate.auth.client import ExchangeResponse, exchange_api_key, request_anonymous_slt
from skillgate.auth.errors import AuthErrorDetail, get_auth_error
from skillgate.auth.extension_bridge import ExtensionAuthState, extension_state_from_entitlements
from skillgate.auth.keys import KeySet, SigningKey, choose_pem_for_token
from skillgate.auth.limits import load_rate_limit_configs
from skillgate.auth.offline import OfflineState, capability_allowed_in_mode, determine_offline_mode
from skillgate.auth.renewal import next_backoff_attempt, should_renew_slt
from skillgate.auth.slt import SLTClaims, TokenVerificationError, issue_slt, verify_slt
from skillgate.auth.store import SecureSLTStore

__all__ = [
    "AuthErrorDetail",
    "ExchangeResponse",
    "ExtensionAuthState",
    "KeySet",
    "OfflineState",
    "SLTClaims",
    "SecureSLTStore",
    "SigningKey",
    "TokenVerificationError",
    "capability_allowed_in_mode",
    "choose_pem_for_token",
    "determine_offline_mode",
    "exchange_api_key",
    "extension_state_from_entitlements",
    "get_auth_error",
    "issue_slt",
    "load_rate_limit_configs",
    "next_backoff_attempt",
    "request_anonymous_slt",
    "should_renew_slt",
    "verify_slt",
]
