"""Governance report generator for Sprint 15."""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class GovernanceReport:
    workspace_id: str
    period_days: int
    generated_at: datetime
    markdown: str


def _iter_audit_records(log_dir: Path, workspace_id: str) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    workspace_dir = log_dir / workspace_id
    for file in sorted(workspace_dir.glob("audit-log-*.ndjson")):
        for line in file.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                records.append(payload)
    return records


def generate_governance_report(
    *,
    log_dir: Path,
    workspace_id: str,
    period_days: int = 30,
    now: datetime | None = None,
) -> GovernanceReport:
    """Generate markdown governance report from audit logs."""
    ts = now or datetime.now(tz=timezone.utc)
    cutoff = ts - timedelta(days=period_days)
    records = _iter_audit_records(log_dir, workspace_id)
    in_scope = []
    for record in records:
        raw_ts = str(record.get("timestamp", ""))
        try:
            event_time = datetime.fromisoformat(raw_ts)
            if event_time.tzinfo is None:
                event_time = event_time.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if event_time >= cutoff:
            in_scope.append(record)

    capability_counter: Counter[str] = Counter()
    denied_counter: Counter[str] = Counter()
    annotation_counter: Counter[str] = Counter()
    anomaly_events = 0
    for record in in_scope:
        capability_counter.update(record.get("capabilities", []))
        if record.get("decision") == "DENY":
            denied_counter.update(record.get("reason_codes", []))
        annotation = record.get("compliance_annotations", {})
        if isinstance(annotation, dict):
            for key, values in annotation.items():
                if isinstance(values, list):
                    annotation_counter.update(f"{key}:{value}" for value in values)
        if record.get("event_type") == "anomaly.detected":
            anomaly_events += 1

    lines = [
        f"# Agent Capability Governance Report ({workspace_id})",
        "",
        f"Generated: {ts.isoformat()}",
        f"Period: last {period_days} days",
        "",
        "## Capability Inventory",
    ]
    if capability_counter:
        lines.extend([f"- {name}: {count}" for name, count in capability_counter.most_common()])
    else:
        lines.append("- No capability activity in period.")

    lines.extend(["", "## Denied Action Summary"])
    if denied_counter:
        lines.extend([f"- {name}: {count}" for name, count in denied_counter.most_common()])
    else:
        lines.append("- No denied actions in period.")

    lines.extend(
        [
            "",
            "## Anomaly Timeline",
            f"- anomaly.detected events: {anomaly_events}",
            "",
            "## Approval History",
            "- Review approval events via control-plane audit stream.",
            "",
            "## Risk Score Trends",
            "- Risk trends available via `/v1/risk/workspace/{workspace_id}` API.",
            "",
            "## Compliance Annotation Counts",
        ]
    )
    if annotation_counter:
        lines.extend([f"- {name}: {count}" for name, count in annotation_counter.most_common()])
    else:
        lines.append("- No compliance annotations found in period.")

    return GovernanceReport(
        workspace_id=workspace_id,
        period_days=period_days,
        generated_at=ts,
        markdown="\n".join(lines) + "\n",
    )
