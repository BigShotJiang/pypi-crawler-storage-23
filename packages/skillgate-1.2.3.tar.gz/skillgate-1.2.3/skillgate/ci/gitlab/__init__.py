"""GitLab CI integration — templates and CI configuration."""
