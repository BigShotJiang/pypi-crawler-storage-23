"""Sprint 15 control-plane package."""

from skillgate.control_plane.models import ApprovalRequest, Organization, PolicyVersion, Workspace
from skillgate.control_plane.service import ControlPlaneService


def create_control_plane_router(*args: object, **kwargs: object):
    """Lazy-import FastAPI router to avoid hard dependency at CLI import time."""
    from skillgate.control_plane.api import create_control_plane_router as _create_control_plane_router

    return _create_control_plane_router(*args, **kwargs)


__all__ = [
    "ApprovalRequest",
    "ControlPlaneService",
    "Organization",
    "PolicyVersion",
    "Workspace",
    "create_control_plane_router",
]
