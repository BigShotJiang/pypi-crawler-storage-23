"""In-memory control-plane service for Sprint 15 integration and tests."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone
from threading import RLock

from skillgate.control_plane.models import (
    Agent,
    ApprovalRequest,
    ApprovalStatus,
    AuditEvent,
    Organization,
    PolicyVersion,
    RetentionPolicy,
    Role,
    Workspace,
    make_id,
)

_ROLE_PERMISSIONS: dict[Role, set[str]] = {
    "org_admin": {
        "policy.read",
        "policy.write",
        "audit.read",
        "audit.delete",
        "approval.request",
        "approval.review",
        "team.manage",
    },
    "workspace_admin": {"policy.read", "policy.write", "audit.read", "approval.request"},
    "security_reviewer": {"audit.read", "approval.review", "approval.request"},
    "developer": {"policy.read", "approval.request"},
}

_RETENTION_DAYS: dict[RetentionPolicy, int] = {
    "7d": 7,
    "30d": 30,
    "90d": 90,
    "1y": 365,
}


class ControlPlaneError(Exception):
    """Base control-plane exception."""


class PermissionDeniedError(ControlPlaneError):
    """Raised when role cannot perform an action."""


class NotFoundError(ControlPlaneError):
    """Raised when entity is missing."""


class ValidationError(ControlPlaneError):
    """Raised when payload is invalid."""


class ControlPlaneService:
    """Thread-safe in-memory control plane with isolation and governance primitives."""

    def __init__(self) -> None:
        self._lock = RLock()
        self.organizations: dict[str, Organization] = {}
        self.workspaces: dict[str, Workspace] = {}
        self.agents: dict[str, Agent] = {}
        self.workspace_policies: dict[str, list[PolicyVersion]] = {}
        self.approvals: dict[str, ApprovalRequest] = {}
        self.audit_events: dict[str, list[AuditEvent]] = {}
        self.workspace_org: dict[str, str] = {}

    def has_permission(self, role: Role, permission: str) -> bool:
        """Check whether a role grants the permission."""
        return permission in _ROLE_PERMISSIONS.get(role, set())

    def require_permission(self, role: Role, permission: str) -> None:
        """Raise when permission is missing."""
        if not self.has_permission(role, permission):
            msg = f"Role '{role}' missing permission '{permission}'"
            raise PermissionDeniedError(msg)

    def create_organization(self, org_id: str, name: str) -> Organization:
        """Create or return an organization."""
        with self._lock:
            org = self.organizations.get(org_id)
            if org is not None:
                return org
            created = Organization(id=org_id, name=name)
            self.organizations[org_id] = created
            return created

    def create_workspace(
        self,
        org_id: str,
        workspace_id: str,
        name: str,
        retention: RetentionPolicy = "30d",
    ) -> Workspace:
        """Create workspace and initialize default policy version."""
        with self._lock:
            if org_id not in self.organizations:
                msg = f"Organization '{org_id}' not found"
                raise NotFoundError(msg)
            existing = self.workspaces.get(workspace_id)
            if existing is not None:
                return existing
            ws = Workspace(id=workspace_id, org_id=org_id, name=name, retention=retention)
            self.workspaces[workspace_id] = ws
            self.workspace_org[workspace_id] = org_id
            default_policy: dict[str, object] = {
                "trust_tier": "strict",
                "approval_requirements": [],
            }
            self.workspace_policies[workspace_id] = [
                PolicyVersion(
                    id=make_id("pol"),
                    workspace_id=workspace_id,
                    version=1,
                    policy=default_policy,
                    changed_by="system",
                    changed_at=datetime.now(tz=timezone.utc),
                    diff_keys=("trust_tier", "approval_requirements"),
                )
            ]
            self.audit_events.setdefault(workspace_id, [])
            return ws

    def register_agent(self, workspace_id: str, agent_id: str, display_name: str) -> Agent:
        """Register an agent in one workspace."""
        with self._lock:
            if workspace_id not in self.workspaces:
                msg = f"Workspace '{workspace_id}' not found"
                raise NotFoundError(msg)
            existing = self.agents.get(agent_id)
            if existing is not None:
                if existing.workspace_id != workspace_id:
                    msg = f"Agent '{agent_id}' already belongs to another workspace"
                    raise ValidationError(msg)
                return existing
            agent = Agent(id=agent_id, workspace_id=workspace_id, display_name=display_name)
            self.agents[agent_id] = agent
            return agent

    def read_workspace_data(
        self,
        request_workspace_id: str,
        target_workspace_id: str,
    ) -> dict[str, object]:
        """Return workspace data only for the same workspace."""
        if request_workspace_id != target_workspace_id:
            msg = "Cross-workspace reads are forbidden"
            raise PermissionDeniedError(msg)
        with self._lock:
            if target_workspace_id not in self.workspaces:
                msg = f"Workspace '{target_workspace_id}' not found"
                raise NotFoundError(msg)
            policy = self.current_policy_snapshot(target_workspace_id)
            return {
                "workspace": self.workspaces[target_workspace_id],
                "policy_snapshot": policy,
                "audit_events": list(self.audit_events.get(target_workspace_id, [])),
            }

    def request_approval(
        self,
        *,
        role: Role,
        capability: str,
        workspace_id: str,
        agent_id: str,
        justification: str,
        expires_in_minutes: int,
        requester_id: str,
    ) -> ApprovalRequest:
        """Create approval request."""
        self.require_permission(role, "approval.request")
        if workspace_id not in self.workspaces:
            msg = f"Workspace '{workspace_id}' not found"
            raise NotFoundError(msg)
        if agent_id not in self.agents:
            msg = f"Agent '{agent_id}' not found"
            raise NotFoundError(msg)
        now = datetime.now(tz=timezone.utc)
        approval = ApprovalRequest(
            id=make_id("apr"),
            capability=capability,
            workspace_id=workspace_id,
            agent_id=agent_id,
            justification=justification,
            created_at=now,
            expires_at=now + timedelta(minutes=max(1, expires_in_minutes)),
            status="pending",
        )
        with self._lock:
            self.approvals[approval.id] = approval
        self.append_audit_event(
            workspace_id=workspace_id,
            event_type="approval.requested",
            actor_id=requester_id,
            payload={"approval_id": approval.id, "capability": capability},
        )
        return approval

    def _check_expired(
        self,
        approval: ApprovalRequest,
        now: datetime | None = None,
    ) -> ApprovalRequest:
        ts = now or datetime.now(tz=timezone.utc)
        if approval.status == "pending" and approval.expires_at <= ts:
            updated = replace(
                approval,
                status="expired",
                reviewed_at=ts,
            )
            self.approvals[approval.id] = updated
            return updated
        return approval

    def set_approval_status(
        self,
        *,
        role: Role,
        approval_id: str,
        status: ApprovalStatus,
        approver_id: str,
    ) -> ApprovalRequest:
        """Approve or deny a pending request."""
        self.require_permission(role, "approval.review")
        if status not in {"approved", "denied"}:
            msg = "Status must be approved or denied"
            raise ValidationError(msg)
        with self._lock:
            approval = self.approvals.get(approval_id)
            if approval is None:
                msg = f"Approval '{approval_id}' not found"
                raise NotFoundError(msg)
            approval = self._check_expired(approval)
            if approval.status != "pending":
                return approval
            updated = replace(
                approval,
                status=status,
                approver_id=approver_id,
                reviewed_at=datetime.now(tz=timezone.utc),
            )
            self.approvals[approval_id] = updated
        self.append_audit_event(
            workspace_id=updated.workspace_id,
            event_type=f"approval.{status}",
            actor_id=approver_id,
            payload={"approval_id": approval_id},
        )
        return updated

    def list_pending_approvals(self, workspace_id: str | None = None) -> list[ApprovalRequest]:
        """Return non-expired pending approvals."""
        now = datetime.now(tz=timezone.utc)
        with self._lock:
            items = list(self.approvals.values())
            for item in items:
                self._check_expired(item, now)
            refreshed = list(self.approvals.values())
        pending = [a for a in refreshed if a.status == "pending"]
        if workspace_id is None:
            return pending
        return [a for a in pending if a.workspace_id == workspace_id]

    def current_policy_version(self, workspace_id: str) -> PolicyVersion:
        """Return latest immutable policy version."""
        versions = self.workspace_policies.get(workspace_id, [])
        if not versions:
            msg = f"No policy versions for workspace '{workspace_id}'"
            raise NotFoundError(msg)
        return versions[-1]

    def current_policy_snapshot(self, workspace_id: str) -> dict[str, object]:
        """Return policy snapshot with embedded approval state."""
        current = self.current_policy_version(workspace_id)
        pending = self.list_pending_approvals(workspace_id)
        approved = [
            a
            for a in self.approvals.values()
            if a.workspace_id == workspace_id and a.status == "approved"
        ]
        snapshot = dict(current.policy)
        snapshot["approvals"] = {
            "pending": [a.id for a in pending],
            "approved": [
                {
                    "id": a.id,
                    "capability": a.capability,
                    "agent_id": a.agent_id,
                    "expires_at": a.expires_at.isoformat(),
                }
                for a in approved
            ],
        }
        return snapshot

    def update_policy(
        self,
        *,
        role: Role,
        workspace_id: str,
        changed_by: str,
        policy: dict[str, object],
    ) -> PolicyVersion:
        """Create a new immutable policy version after diff validation."""
        self.require_permission(role, "policy.write")
        current = self.current_policy_version(workspace_id)
        diff_keys = tuple(
            sorted(
                k
                for k in (set(current.policy) | set(policy))
                if current.policy.get(k) != policy.get(k)
            )
        )
        if not diff_keys:
            msg = "No policy changes detected"
            raise ValidationError(msg)
        next_version = PolicyVersion(
            id=make_id("pol"),
            workspace_id=workspace_id,
            version=current.version + 1,
            policy=dict(policy),
            changed_by=changed_by,
            changed_at=datetime.now(tz=timezone.utc),
            diff_keys=diff_keys,
        )
        with self._lock:
            self.workspace_policies.setdefault(workspace_id, []).append(next_version)
        self.append_audit_event(
            workspace_id=workspace_id,
            event_type="policy.updated",
            actor_id=changed_by,
            payload={"version": next_version.version, "diff_keys": list(diff_keys)},
        )
        return next_version

    def rollback_policy(
        self,
        *,
        role: Role,
        workspace_id: str,
        target_version: int,
        actor_id: str,
    ) -> PolicyVersion:
        """Rollback to a previous policy by creating a new version equal to target."""
        self.require_permission(role, "policy.write")
        versions = self.workspace_policies.get(workspace_id, [])
        if not versions:
            msg = f"No policy history for workspace '{workspace_id}'"
            raise NotFoundError(msg)
        target = next((v for v in versions if v.version == target_version), None)
        if target is None:
            msg = f"Target version {target_version} not found"
            raise NotFoundError(msg)
        restored = self.update_policy(
            role=role,
            workspace_id=workspace_id,
            changed_by=actor_id,
            policy=dict(target.policy),
        )
        self.append_audit_event(
            workspace_id=workspace_id,
            event_type="policy.rolled_back",
            actor_id=actor_id,
            payload={"target_version": target_version, "new_version": restored.version},
        )
        return restored

    def append_audit_event(
        self, *, workspace_id: str, event_type: str, actor_id: str, payload: dict[str, object]
    ) -> AuditEvent:
        """Append control-plane audit event."""
        event = AuditEvent(
            id=make_id("evt"),
            workspace_id=workspace_id,
            event_type=event_type,
            actor_id=actor_id,
            created_at=datetime.now(tz=timezone.utc),
            payload=payload,
        )
        with self._lock:
            self.audit_events.setdefault(workspace_id, []).append(event)
        return event

    def set_retention(
        self,
        *,
        role: Role,
        workspace_id: str,
        retention: RetentionPolicy,
        actor_id: str,
    ) -> Workspace:
        """Set workspace retention policy."""
        self.require_permission(role, "policy.write")
        ws = self.workspaces.get(workspace_id)
        if ws is None:
            msg = f"Workspace '{workspace_id}' not found"
            raise NotFoundError(msg)
        updated = Workspace(
            id=ws.id,
            org_id=ws.org_id,
            name=ws.name,
            retention=retention,
            created_at=ws.created_at,
        )
        self.workspaces[workspace_id] = updated
        self.append_audit_event(
            workspace_id=workspace_id,
            event_type="audit.retention.updated",
            actor_id=actor_id,
            payload={"retention": retention},
        )
        return updated

    def delete_audit_before(
        self,
        *,
        role: Role,
        workspace_id: str,
        before: datetime,
        actor_id: str,
    ) -> int:
        """Delete control-plane audit events before timestamp and audit deletion itself."""
        self.require_permission(role, "audit.delete")
        with self._lock:
            events = self.audit_events.get(workspace_id, [])
            kept = [evt for evt in events if evt.created_at >= before]
            deleted = len(events) - len(kept)
            self.audit_events[workspace_id] = kept
        self.append_audit_event(
            workspace_id=workspace_id,
            event_type="audit.deleted",
            actor_id=actor_id,
            payload={"deleted_count": deleted, "before": before.isoformat()},
        )
        return deleted

    def enforce_retention(self, workspace_id: str, now: datetime | None = None) -> int:
        """Apply workspace retention and delete expired events."""
        ws = self.workspaces.get(workspace_id)
        if ws is None:
            return 0
        cutoff = (now or datetime.now(tz=timezone.utc)) - timedelta(
            days=_RETENTION_DAYS[ws.retention]
        )
        with self._lock:
            events = self.audit_events.get(workspace_id, [])
            kept = [evt for evt in events if evt.created_at >= cutoff]
            deleted = len(events) - len(kept)
            self.audit_events[workspace_id] = kept
        return deleted
