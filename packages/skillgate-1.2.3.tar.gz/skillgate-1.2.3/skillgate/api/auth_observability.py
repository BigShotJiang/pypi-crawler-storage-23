"""Auth-provider observability helpers for Section 17.187.

Provides provider-path metrics and structured failure triage logging while
ensuring token/secrets are never emitted.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx
from fastapi import HTTPException

from skillgate.api.errors import AuthError
from skillgate.api.telemetry import get_meter

logger = logging.getLogger(__name__)
meter = get_meter("skillgate.api.auth_observability")
provider_decisions_counter = meter.create_counter("auth_provider_decisions_total")
provider_failures_counter = meter.create_counter("auth_provider_failures_total")

_SENSITIVE_KEYS = frozenset(
    {
        "token",
        "access_token",
        "refresh_token",
        "authorization",
        "password",
        "secret",
        "api_key",
        "service_role_key",
        "anon_key",
        "jwt_secret",
    }
)


def sanitize_context(payload: dict[str, Any] | None) -> dict[str, Any]:
    """Return log-safe context by redacting sensitive keys recursively."""

    if payload is None:
        return {}

    safe: dict[str, Any] = {}
    for key, value in payload.items():
        key_norm = key.lower()
        if any(secret_key in key_norm for secret_key in _SENSITIVE_KEYS):
            safe[key] = "[REDACTED]"
            continue

        if isinstance(value, dict):
            safe[key] = sanitize_context(value)
            continue

        safe[key] = value
    return safe


def failure_class_from_exception(exc: Exception) -> str:
    """Map exception classes to stable triage buckets."""

    if isinstance(exc, HTTPException):
        status_code = exc.status_code
        if status_code == 400:
            return "bad_request"
        if status_code == 401:
            return "unauthorized"
        if status_code == 403:
            return "forbidden"
        if status_code == 404:
            return "not_found"
        if status_code == 409:
            return "conflict"
        if status_code == 423:
            return "locked"
        if status_code == 429:
            return "rate_limited"
        if status_code >= 500:
            return "upstream_or_internal"
        return f"http_{status_code}"

    if isinstance(exc, AuthError):
        return "auth_error"
    if isinstance(exc, httpx.HTTPError):
        return "http_transport_error"
    if isinstance(exc, ValueError):
        return "validation_error"
    return "internal_error"


def record_auth_decision(
    *,
    endpoint: str,
    provider: str,
    outcome: str,
    failure_class: str | None = None,
    status_code: int | None = None,
    context: dict[str, Any] | None = None,
) -> None:
    """Emit counters and a structured log line for auth provider decisions."""

    attributes = {
        "endpoint": endpoint,
        "provider": provider,
        "outcome": outcome,
    }
    provider_decisions_counter.add(1, attributes)

    safe_context = sanitize_context(context)
    if outcome == "success":
        logger.info(
            "auth_provider.decision endpoint=%s provider=%s outcome=%s context=%s",
            endpoint,
            provider,
            outcome,
            safe_context,
        )
        return

    failure_bucket = failure_class or "unknown_failure"
    provider_failures_counter.add(
        1,
        {
            "endpoint": endpoint,
            "provider": provider,
            "failure_class": failure_bucket,
        },
    )
    logger.warning(
        (
            "auth_provider.failure endpoint=%s provider=%s outcome=%s "
            "failure_class=%s status=%s context=%s"
        ),
        endpoint,
        provider,
        outcome,
        failure_bucket,
        status_code,
        safe_context,
    )
