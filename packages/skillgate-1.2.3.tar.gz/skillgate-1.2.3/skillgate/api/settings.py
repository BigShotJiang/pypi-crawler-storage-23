"""Runtime settings for hosted API deployment profiles."""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


def _parse_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_origins(raw: str | None) -> list[str]:
    default_origins = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
    ]
    if raw is None:
        return default_origins
    origins = [origin.strip() for origin in raw.split(",") if origin.strip()]
    return origins or default_origins


def _required_env(name: str) -> str:
    value = os.environ.get(name)
    if value is None or not value.strip():
        raise RuntimeError(f"{name} must be set.")
    return value


VALID_AUTH_PROVIDERS = frozenset({"local", "supabase"})


@dataclass(frozen=True)
class AppSettings:
    """Configuration values for API runtime behavior."""

    environment: str
    cors_origins: list[str]
    cors_allow_credentials: bool
    oauth_enabled: bool
    enable_hsts: bool
    redis_url: str
    database_url: str
    auth_provider: str = "local"
    supabase_url: str | None = None
    supabase_anon_key: str | None = None
    supabase_service_role_key: str | None = None
    supabase_jwt_secret: str | None = None
    supabase_jwks_url: str | None = None
    resend_api_key: str | None = None
    resend_from_email: str | None = None
    web_base_url: str = "http://localhost:3000"
    onprem_entitlement_url: str | None = None
    onprem_entitlement_token: str | None = None
    onprem_timeout_seconds: float = 3.0
    onprem_fail_open: bool = True

    @property
    def is_supabase(self) -> bool:
        """True when Supabase is selected as the auth provider."""
        return self.auth_provider == "supabase"

    @property
    def is_production(self) -> bool:
        return self.environment in {"production", "staging"}

    def validate_startup(self) -> None:
        """Fail fast when secure defaults are missing in production-like envs."""
        if self.auth_provider not in VALID_AUTH_PROVIDERS:
            raise RuntimeError(
                f"SKILLGATE_AUTH_PROVIDER must be one of {sorted(VALID_AUTH_PROVIDERS)}, "
                f"got '{self.auth_provider}'."
            )

        if not self.is_production:
            return

        if self.auth_provider == "local":
            jwt_secret = os.environ.get("SKILLGATE_JWT_SECRET", "")
            if len(jwt_secret) < 32:
                raise RuntimeError(
                    "SKILLGATE_JWT_SECRET must be set with length >= 32 in production/staging."
                )

        if self.auth_provider == "supabase":
            missing = [
                name
                for name, val in [
                    ("SUPABASE_URL", self.supabase_url),
                    ("SUPABASE_ANON_KEY", self.supabase_anon_key),
                    ("SUPABASE_SERVICE_ROLE_KEY", self.supabase_service_role_key),
                ]
                if not val
            ]
            if missing:
                raise RuntimeError(
                    f"Supabase auth provider requires env vars: {', '.join(missing)}"
                )
            if not self.supabase_jwt_secret and not self.supabase_jwks_url:
                raise RuntimeError(
                    "Supabase auth provider requires either SUPABASE_JWT_SECRET "
                    "or SUPABASE_JWKS_URL in production/staging."
                )

        pepper = os.environ.get("SKILLGATE_API_KEY_PEPPER", "")
        if len(pepper) < 32:
            raise RuntimeError(
                "SKILLGATE_API_KEY_PEPPER must be set with length >= 32 in production/staging."
            )
        if "*" in self.cors_origins and self.cors_allow_credentials:
            raise RuntimeError(
                "Wildcard CORS origins cannot be used with credentials in production/staging."
            )


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    """Load and cache runtime settings from environment."""
    environment = _required_env("SKILLGATE_ENV").strip().lower()
    cors_origins = _parse_origins(_required_env("SKILLGATE_CORS_ORIGINS"))
    allow_credentials_default = "*" not in cors_origins
    cors_allow_credentials = _parse_bool(
        os.environ.get("SKILLGATE_CORS_ALLOW_CREDENTIALS"),
        allow_credentials_default,
    )
    raw_auth_provider = _required_env("SKILLGATE_AUTH_PROVIDER").strip().lower()
    supabase_url = os.environ.get("SUPABASE_URL") or None
    # Derive canonical JWKS URL from Supabase project URL when not explicitly overridden.
    default_jwks_url = (
        f"{supabase_url.rstrip('/')}/auth/v1/.well-known/jwks.json" if supabase_url else None
    )
    return AppSettings(
        environment=environment,
        cors_origins=cors_origins,
        cors_allow_credentials=cors_allow_credentials,
        oauth_enabled=_parse_bool(os.environ.get("SKILLGATE_ENABLE_OAUTH"), False),
        enable_hsts=_parse_bool(
            os.environ.get("SKILLGATE_ENABLE_HSTS"),
            environment in {"production", "staging"},
        ),
        redis_url=_required_env("SKILLGATE_REDIS_URL"),
        database_url=_required_env("SKILLGATE_DATABASE_URL"),
        auth_provider=raw_auth_provider,
        supabase_url=supabase_url,
        supabase_anon_key=os.environ.get("SUPABASE_ANON_KEY") or None,
        supabase_service_role_key=os.environ.get("SUPABASE_SERVICE_ROLE_KEY") or None,
        supabase_jwt_secret=os.environ.get("SUPABASE_JWT_SECRET") or None,
        supabase_jwks_url=os.environ.get("SUPABASE_JWKS_URL") or default_jwks_url,
        resend_api_key=os.environ.get("RESEND_API_KEY"),
        resend_from_email=os.environ.get("SKILLGATE_EMAIL_FROM"),
        web_base_url=(os.environ.get("SKILLGATE_WEB_BASE_URL") or "http://localhost:3000").rstrip(
            "/"
        ),
        onprem_entitlement_url=os.environ.get("SKILLGATE_ONPREM_ENTITLEMENT_URL"),
        onprem_entitlement_token=os.environ.get("SKILLGATE_ONPREM_ENTITLEMENT_TOKEN"),
        onprem_timeout_seconds=float(os.environ.get("SKILLGATE_ONPREM_ENTITLEMENT_TIMEOUT", "3.0")),
        onprem_fail_open=_parse_bool(os.environ.get("SKILLGATE_ONPREM_FAIL_OPEN"), True),
    )
