"""Shared rate-limit helpers for auth and payment abuse controls."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.models import AuthRateLimit


def utcnow_naive() -> datetime:
    """Return current UTC datetime in naive form for DB consistency."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


async def enforce_rate_limit(
    *,
    session: AsyncSession,
    scope: str,
    bucket_key: str,
    limit: int,
    window_seconds: int,
    block_seconds: int,
    now_fn: Callable[[], datetime] = utcnow_naive,
) -> None:
    """Apply fixed-window per-bucket throttling with temporary blocking."""
    now = now_fn()
    row = await session.scalar(
        select(AuthRateLimit).where(
            AuthRateLimit.scope == scope,
            AuthRateLimit.bucket_key == bucket_key,
        )
    )

    if row is None:
        row = AuthRateLimit(
            id=str(uuid4()),
            scope=scope,
            bucket_key=bucket_key,
            count=1,
            window_started_at=now,
            blocked_until=None,
        )
        session.add(row)
        await session.commit()
        return

    if row.blocked_until and row.blocked_until > now:
        raise HTTPException(status_code=429, detail="Too many requests. Try again later.")

    elapsed = (now - row.window_started_at).total_seconds()
    if elapsed > window_seconds:
        row.count = 0
        row.window_started_at = now
        row.blocked_until = None

    row.count += 1
    if row.count > limit:
        row.blocked_until = now + timedelta(seconds=block_seconds)
        await session.commit()
        raise HTTPException(status_code=429, detail="Too many requests. Try again later.")

    await session.commit()
