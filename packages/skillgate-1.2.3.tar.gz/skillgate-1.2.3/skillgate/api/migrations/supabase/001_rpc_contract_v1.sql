-- Task 17.189: Supabase RPC Contract v1
-- Versioned, idempotent server-side functions.

create schema if not exists skillgate_rpc;

create or replace function skillgate_rpc.sg_upsert_user_session_v1(
  p_session_id text,
  p_user_id text,
  p_refresh_token_hash text,
  p_expires_at timestamptz,
  p_user_agent text,
  p_ip_address text
) returns jsonb
language plpgsql
security definer
as $$
begin
  if p_session_id is null or p_user_id is null or p_refresh_token_hash is null then
    raise exception 'invalid input' using errcode = '22023';
  end if;

  insert into user_sessions (id, user_id, refresh_token_hash, expires_at, user_agent, ip_address, revoked)
  values (p_session_id, p_user_id, p_refresh_token_hash, p_expires_at, p_user_agent, p_ip_address, false)
  on conflict (id) do update
    set refresh_token_hash = excluded.refresh_token_hash,
        expires_at = excluded.expires_at,
        user_agent = excluded.user_agent,
        ip_address = excluded.ip_address;

  return jsonb_build_object('status', 'ok', 'session_id', p_session_id, 'user_id', p_user_id);
end;
$$;

create or replace function skillgate_rpc.sg_revoke_user_sessions_v1(
  p_user_id text,
  p_reason text default 'manual_revoke'
) returns jsonb
language plpgsql
security definer
as $$
declare
  revoked_count bigint;
begin
  if p_user_id is null then
    raise exception 'invalid input' using errcode = '22023';
  end if;

  update user_sessions
     set revoked = true,
         revoked_at = coalesce(revoked_at, now())
   where user_id = p_user_id
     and revoked = false;

  get diagnostics revoked_count = row_count;

  return jsonb_build_object(
    'status', 'ok',
    'user_id', p_user_id,
    'reason', p_reason,
    'revoked_count', revoked_count
  );
end;
$$;

create or replace function skillgate_rpc.sg_upsert_oauth_identity_v1(
  p_provider text,
  p_provider_user_id text,
  p_user_id text,
  p_email text
) returns jsonb
language plpgsql
security definer
as $$
declare
  v_identity_id text;
begin
  if p_provider is null or p_provider_user_id is null or p_user_id is null then
    raise exception 'invalid input' using errcode = '22023';
  end if;

  insert into oauth_identities (id, provider, provider_user_id, user_id, email)
  values (gen_random_uuid()::text, p_provider, p_provider_user_id, p_user_id, p_email)
  on conflict (provider, provider_user_id) do update
    set user_id = excluded.user_id,
        email = excluded.email,
        updated_at = now()
  returning id into v_identity_id;

  return jsonb_build_object('status', 'ok', 'identity_id', v_identity_id, 'user_id', p_user_id);
end;
$$;

-- Execution hardening: service role only.
revoke all on function skillgate_rpc.sg_upsert_user_session_v1(text, text, text, timestamptz, text, text) from public;
revoke all on function skillgate_rpc.sg_revoke_user_sessions_v1(text, text) from public;
revoke all on function skillgate_rpc.sg_upsert_oauth_identity_v1(text, text, text, text) from public;