-- Task 17.190: RLS Policy Catalog v1

alter table users enable row level security;
alter table user_sessions enable row level security;
alter table oauth_identities enable row level security;
alter table subscriptions enable row level security;

-- Deny-by-default: no broad public grants.
revoke all on table users from public;
revoke all on table user_sessions from public;
revoke all on table oauth_identities from public;
revoke all on table subscriptions from public;

-- users
create policy users_select_own_v1 on users
for select
using (id = auth.uid()::text);

create policy users_update_own_v1 on users
for update
using (id = auth.uid()::text)
with check (id = auth.uid()::text);

-- user_sessions
create policy user_sessions_select_own_v1 on user_sessions
for select
using (user_id = auth.uid()::text);

create policy user_sessions_update_own_v1 on user_sessions
for update
using (user_id = auth.uid()::text)
with check (user_id = auth.uid()::text);

-- oauth_identities
create policy oauth_identities_select_own_v1 on oauth_identities
for select
using (user_id = auth.uid()::text);

-- subscriptions
create policy subscriptions_select_own_v1 on subscriptions
for select
using (user_id = auth.uid()::text);

-- service-role policies (audited exception path)
create policy users_service_role_all_v1 on users
for all
using (auth.role() = 'service_role')
with check (auth.role() = 'service_role');

create policy user_sessions_service_role_all_v1 on user_sessions
for all
using (auth.role() = 'service_role')
with check (auth.role() = 'service_role');

create policy oauth_identities_service_role_all_v1 on oauth_identities
for all
using (auth.role() = 'service_role')
with check (auth.role() = 'service_role');

create policy subscriptions_service_role_all_v1 on subscriptions
for all
using (auth.role() = 'service_role')
with check (auth.role() = 'service_role');