"""SkillGate hosted API — optional FastAPI backend."""
