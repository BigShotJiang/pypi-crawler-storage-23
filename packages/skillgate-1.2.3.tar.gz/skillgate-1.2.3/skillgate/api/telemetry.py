"""Optional OpenTelemetry instrumentation for the SkillGate API.

Gracefully degrades when opentelemetry packages are not installed.
Enable by setting ``SKILLGATE_OTEL_ENABLED=true`` and installing the
``skillgate[otel]`` extra.

Exports:
    instrument_app: Attach OTel middleware to a FastAPI app.
    get_meter: Return a named OTel Meter (or no-op stub).
    get_tracer: Return a named OTel Tracer (or no-op stub).
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

from skillgate.version import __version__

if TYPE_CHECKING:
    from fastapi import FastAPI

logger = logging.getLogger(__name__)

_OTEL_AVAILABLE = False


def _otel_enabled() -> bool:
    return os.environ.get("SKILLGATE_OTEL_ENABLED", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _check_otel() -> bool:
    global _OTEL_AVAILABLE  # noqa: PLW0603
    try:
        import opentelemetry  # noqa: F401

        _OTEL_AVAILABLE = True
    except ImportError:
        _OTEL_AVAILABLE = False
    return _OTEL_AVAILABLE


class _NoOpSpan:
    """Span stub for no-op tracer."""

    def __enter__(self) -> _NoOpSpan:
        return self

    def __exit__(self, *args: Any) -> None:
        pass

    def set_attribute(self, key: str, value: Any) -> None:
        pass


class _NoOpTracer:
    """Tracer stub that returns no-op spans."""

    def start_as_current_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()


class _NoOpMeter:
    """Meter stub that returns no-op instruments."""

    def create_counter(self, name: str, **kwargs: Any) -> _NoOpCounter:
        return _NoOpCounter()

    def create_histogram(self, name: str, **kwargs: Any) -> _NoOpHistogram:
        return _NoOpHistogram()


class _NoOpCounter:
    def add(self, amount: int | float, attributes: dict[str, str] | None = None) -> None:
        pass


class _NoOpHistogram:
    def record(self, amount: int | float, attributes: dict[str, str] | None = None) -> None:
        pass


def instrument_app(app: FastAPI) -> None:
    """Attach OpenTelemetry auto-instrumentation to the FastAPI app.

    No-op when OTel is disabled or packages are missing.
    """
    if not _otel_enabled():
        logger.debug("OpenTelemetry disabled (SKILLGATE_OTEL_ENABLED not set)")
        return

    if not _check_otel():
        logger.warning(
            "SKILLGATE_OTEL_ENABLED=true but opentelemetry packages not installed. "
            "Install with: pip install skillgate[otel]"
        )
        return

    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter,
        )
        from opentelemetry.instrumentation.fastapi import (
            FastAPIInstrumentor,
        )
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import (
            BatchSpanProcessor,
        )

        resource = Resource.create(
            {
                "service.name": "skillgate-api",
                "service.version": __version__,
            }
        )
        provider = TracerProvider(resource=resource)
        processor = BatchSpanProcessor(OTLPSpanExporter())
        provider.add_span_processor(processor)
        trace.set_tracer_provider(provider)

        FastAPIInstrumentor.instrument_app(app)
        logger.info("OpenTelemetry tracing enabled for skillgate-api")
    except Exception:  # noqa: BLE001
        logger.warning("Failed to initialize OpenTelemetry", exc_info=True)


def get_meter(name: str = "skillgate") -> Any:
    """Return an OpenTelemetry Meter, or a no-op stub if unavailable."""
    if not _otel_enabled() or not _check_otel():
        return _NoOpMeter()

    from opentelemetry import metrics

    return metrics.get_meter(name)


def get_tracer(name: str = "skillgate") -> Any:
    """Return an OpenTelemetry Tracer, or a no-op stub if unavailable."""
    if not _otel_enabled() or not _check_otel():
        return _NoOpTracer()

    from opentelemetry import trace

    return trace.get_tracer(name)
