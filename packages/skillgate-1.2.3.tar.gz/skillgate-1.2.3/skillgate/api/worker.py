"""ARQ-compatible background task definitions for async processing."""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx
from arq.connections import RedisSettings

logger = logging.getLogger(__name__)


async def send_slack_notification(ctx: dict[str, Any], payload: dict[str, Any]) -> bool:
    """Background task: deliver Slack webhook notification."""
    webhook_url = payload.get("webhook_url", "")
    message = payload.get("message", {})

    if not webhook_url:
        logger.error("Slack notification missing webhook_url")
        return False

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(webhook_url, json=message, timeout=10.0)
            response.raise_for_status()
            logger.info("Slack notification delivered successfully")
            return True
    except httpx.HTTPError as e:
        logger.warning("Slack notification failed: %s", e)
        raise  # ARQ will retry


async def process_stripe_webhook(ctx: dict[str, Any], event_data: dict[str, Any]) -> bool:
    """Background task: process Stripe webhook event asynchronously."""
    event_type = event_data.get("type", "unknown")
    logger.info("Processing Stripe webhook: %s", event_type)
    # Actual processing is handled by the payments route;
    # this enables deferred processing for high-throughput scenarios.
    return True


async def send_email_notification(ctx: dict[str, Any], to: str, subject: str, body: str) -> bool:
    """Background task: send email notification (placeholder for SMTP/SES)."""
    logger.info("Email notification queued: to=%s subject=%s", to, subject)
    return True


async def startup(ctx: dict[str, Any]) -> None:
    """ARQ worker startup hook."""
    logger.info("ARQ worker started")


async def shutdown(ctx: dict[str, Any]) -> None:
    """ARQ worker shutdown hook."""
    logger.info("ARQ worker shutting down")


class WorkerSettings:
    """ARQ worker configuration — used by `arq skillgate.api.worker.WorkerSettings`."""

    redis_settings = RedisSettings.from_dsn(
        os.environ.get("SKILLGATE_REDIS_URL", "redis://localhost:6379")
    )
    functions = [send_slack_notification, process_stripe_webhook, send_email_notification]
    on_startup = startup
    on_shutdown = shutdown
    max_jobs = 10
    job_timeout = 30
    max_tries = 3
    retry_defer_seconds = 5
