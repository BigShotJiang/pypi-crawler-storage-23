"""Redis-backed rate limiting for horizontally-scaled API deployments."""

from __future__ import annotations

from typing import Any, cast

from fastapi import HTTPException

try:
    from redis.asyncio import Redis
except ImportError:  # pragma: no cover
    Redis = None  # type: ignore[assignment,misc]

# Lua script: atomic fixed-window rate limit
# Keys[1] = bucket key, ARGV[1] = limit, ARGV[2] = window_seconds, ARGV[3] = block_seconds
_RATE_LIMIT_LUA = """
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local block = tonumber(ARGV[3])

local block_key = key .. ":blocked"
local blocked = redis.call("GET", block_key)
if blocked then
    return {1, tonumber(blocked)}
end

local current = redis.call("INCR", key)
if current == 1 then
    redis.call("EXPIRE", key, window)
end

if current > limit then
    redis.call("SET", block_key, block, "EX", block)
    return {1, block}
end

return {0, limit - current}
"""


async def enforce_redis_rate_limit(
    *,
    redis: Redis,
    scope: str,
    bucket_key: str,
    limit: int,
    window_seconds: int,
    block_seconds: int,
) -> None:
    """Atomic Redis rate limit with temporary blocking on threshold breach."""
    key = f"rl:{scope}:{bucket_key}"
    result = await cast(Any, redis.eval)(
        _RATE_LIMIT_LUA,
        1,
        [key],
        [str(limit), str(window_seconds), str(block_seconds)],
    )
    blocked, _remaining = result
    if blocked:
        raise HTTPException(status_code=429, detail="Too many requests. Try again later.")
