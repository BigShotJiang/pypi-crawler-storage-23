"""Audit export API routes."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.entitlement import resolve_user_entitlement
from skillgate.api.routes.auth import get_current_user
from skillgate.core.entitlement.enterprise import AuditExporter
from skillgate.core.entitlement.models import Capability
from skillgate.ecosystem.subagents import LineageStore

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("/export")
async def export_audit_log(
    export_format: str = Query(  # noqa: B008
        default="jsonl", description="Export format: jsonl or csv", alias="format"
    ),
    start_date: datetime | None = Query(default=None, description="Start date filter"),  # noqa: B008
    end_date: datetime | None = Query(default=None, description="End date filter"),  # noqa: B008
    user: Any = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, Any]:
    """Export audit log entries.

    Requires AUDIT_EXPORT capability (Enterprise tier).

    Returns:
        Export data with metadata
    """
    from skillgate.api.models import ScanRecord

    user = await get_current_user(user, session)

    # Check entitlement
    entitlement = await resolve_user_entitlement(user, session)
    if not entitlement.has_capability(Capability.AUDIT_EXPORT):
        raise HTTPException(
            status_code=403,
            detail="Audit export requires Enterprise tier. "
            "Contact sales at https://skillgate.io/enterprise",
        )

    # Build query
    stmt = select(ScanRecord).where(ScanRecord.user_id == user.id)

    if start_date:
        stmt = stmt.where(ScanRecord.created_at >= start_date)
    if end_date:
        stmt = stmt.where(ScanRecord.created_at <= end_date)

    stmt = stmt.order_by(ScanRecord.created_at.desc()).limit(10000)

    result = await session.execute(stmt)
    records = result.scalars().all()

    # Convert to export format - parse report_json
    import json

    export_records = []
    for r in records:
        try:
            report_data = json.loads(r.report_json) if r.report_json else {}
        except json.JSONDecodeError:
            report_data = {}

        export_records.append(
            {
                "id": str(r.id),
                "bundle_name": report_data.get("bundle_name", "unknown"),
                "risk_score": report_data.get("risk_score", {}).get("total", 0),
                "findings_count": len(report_data.get("findings", [])),
                "created_at": r.created_at.isoformat() if r.created_at else None,
                "policy_passed": report_data.get("policy", {}).get("passed", None),
            }
        )

    exporter = AuditExporter(export_records)

    if export_format == "csv":
        content = exporter.export_csv()
        media_type = "text/csv"
    else:
        content = exporter.export_jsonl()
        media_type = "application/x-jsonlines"

    return {
        "format": export_format,
        "record_count": len(export_records),
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "content": content,
        "media_type": media_type,
    }


@router.get("/lineage/{invocation_id}")
async def get_audit_lineage(
    invocation_id: str,
    user: Any = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, Any]:
    """Return stored sub-agent lineage tree for one invocation id."""
    _ = await get_current_user(user, session)
    store_path = Path(os.environ.get("SKILLGATE_LINEAGE_STORE", ".skillgate/claude-lineage.json"))
    tree = LineageStore(store_path).lineage_tree(invocation_id)
    if bool(tree.get("orphan", False)):
        raise HTTPException(status_code=404, detail="Lineage invocation not found")
    return tree
