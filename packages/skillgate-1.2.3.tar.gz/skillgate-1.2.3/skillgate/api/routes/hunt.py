"""Hunt query API endpoints."""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.entitlement import resolve_user_entitlement
from skillgate.api.models import ScanRecord, User
from skillgate.api.routes.auth import get_current_user
from skillgate.core.entitlement.models import Capability
from skillgate.core.hunt.engine import execute_hunt
from skillgate.core.hunt.models import (
    HuntFilter,
    HuntMatch,
    HuntQuery,
    HuntSortField,
    HuntSortOrder,
)

router = APIRouter(prefix="/hunt", tags=["hunt"])
logger = logging.getLogger(__name__)


class HuntRequest(BaseModel):
    """Hunt query request body."""

    filters: HuntFilter = Field(default_factory=HuntFilter)
    sort_by: HuntSortField = Field(default=HuntSortField.CREATED_AT)
    sort_order: HuntSortOrder = Field(default=HuntSortOrder.DESC)
    limit: int = Field(default=50, ge=1, le=500)
    offset: int = Field(default=0, ge=0)


class HuntResponse(BaseModel):
    """Hunt query response."""

    matches: list[HuntMatch]
    total: int
    limit: int
    offset: int


@router.post("")
async def hunt_scans(
    req: HuntRequest,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> HuntResponse:
    """Execute a hunt query against stored scan history.

    Searches the user's stored scan reports for findings matching
    the specified filters.
    """
    entitlement = await resolve_user_entitlement(user, session)
    if not entitlement.has_capability(Capability.HUNT):
        raise HTTPException(
            status_code=403,
            detail="Hunt requires Team or Enterprise tier.",
        )

    # Load user's scan reports
    rows = await session.scalars(
        select(ScanRecord)
        .where(ScanRecord.user_id == user.id)
        .order_by(ScanRecord.created_at.desc())
        .limit(1000)  # Cap for performance
    )
    scan_reports: list[dict[str, object]] = []
    for row in rows.all():
        try:
            report = json.loads(row.report_json)
            if isinstance(report, dict):
                report["scan_id"] = row.id
                report["created_at"] = row.created_at.isoformat() if row.created_at else ""
                scan_reports.append(report)
        except (json.JSONDecodeError, AttributeError):
            logger.warning("Skipping malformed scan record %s", row.id)
            continue

    if not scan_reports:
        return HuntResponse(
            matches=[],
            total=0,
            limit=req.limit,
            offset=req.offset,
        )

    query = HuntQuery(
        filters=req.filters,
        sort_by=req.sort_by,
        sort_order=req.sort_order,
        limit=req.limit,
        offset=req.offset,
    )

    try:
        result = execute_hunt(query, scan_reports)
    except Exception as exc:
        logger.exception("Hunt query execution failed")
        raise HTTPException(
            status_code=500,
            detail=f"Hunt query failed: {exc}",
        ) from exc

    return HuntResponse(
        matches=result.matches,
        total=result.total,
        limit=result.limit,
        offset=result.offset,
    )
