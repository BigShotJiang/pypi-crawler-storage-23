"""Usage metrics endpoint for dashboard consumption."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.models import APIKey, ScanRecord, Subscription, User
from skillgate.api.routes.auth import get_current_user

router = APIRouter(prefix="/usage", tags=["usage"])

TIER_SCAN_LIMITS: dict[str, int | None] = {
    "free": 3,
    "pro": None,
    "team": None,
    "enterprise": None,
}

TIER_RATE_LIMITS: dict[str, int] = {
    "free": 10,
    "pro": 60,
    "team": 300,
    "enterprise": 1000,
}


class UsageMetricsResponse(BaseModel):
    """Aggregated usage metrics for the authenticated user."""

    tier: str
    scan_count_total: int
    scan_count_30d: int
    scan_count_7d: int
    scan_count_today: int
    api_key_count: int
    api_key_active_count: int
    scan_limit_per_day: int | None
    api_rate_limit_per_min: int
    last_scan_at: str | None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


@router.get("/metrics", response_model=UsageMetricsResponse)
async def get_usage_metrics(
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> UsageMetricsResponse:
    """Return usage metrics for the authenticated user."""
    now = _utc_now()
    day_ago = now - timedelta(days=1)
    week_ago = now - timedelta(days=7)
    month_ago = now - timedelta(days=30)

    # Resolve tier
    sub = await session.scalar(
        select(Subscription)
        .where(Subscription.user_id == user.id, Subscription.status == "active")
        .order_by(Subscription.created_at.desc())
        .limit(1)
    )
    tier = sub.tier if sub else "free"

    # Scan counts
    scan_total = (
        await session.scalar(
            select(func.count()).select_from(ScanRecord).where(ScanRecord.user_id == user.id)
        )
        or 0
    )
    scan_30d = (
        await session.scalar(
            select(func.count())
            .select_from(ScanRecord)
            .where(ScanRecord.user_id == user.id, ScanRecord.created_at >= month_ago)
        )
        or 0
    )
    scan_7d = (
        await session.scalar(
            select(func.count())
            .select_from(ScanRecord)
            .where(ScanRecord.user_id == user.id, ScanRecord.created_at >= week_ago)
        )
        or 0
    )
    scan_today = (
        await session.scalar(
            select(func.count())
            .select_from(ScanRecord)
            .where(ScanRecord.user_id == user.id, ScanRecord.created_at >= day_ago)
        )
        or 0
    )

    # API key counts
    key_total = (
        await session.scalar(
            select(func.count()).select_from(APIKey).where(APIKey.user_id == user.id)
        )
        or 0
    )
    key_active = (
        await session.scalar(
            select(func.count())
            .select_from(APIKey)
            .where(APIKey.user_id == user.id, APIKey.revoked.is_(False))
        )
        or 0
    )

    # Last scan
    last_scan = await session.scalar(
        select(ScanRecord.created_at)
        .where(ScanRecord.user_id == user.id)
        .order_by(ScanRecord.created_at.desc())
        .limit(1)
    )

    return UsageMetricsResponse(
        tier=tier,
        scan_count_total=scan_total,
        scan_count_30d=scan_30d,
        scan_count_7d=scan_7d,
        scan_count_today=scan_today,
        api_key_count=key_total,
        api_key_active_count=key_active,
        scan_limit_per_day=TIER_SCAN_LIMITS.get(tier),
        api_rate_limit_per_min=TIER_RATE_LIMITS.get(tier, 10),
        last_scan_at=last_scan.isoformat() if last_scan else None,
    )
