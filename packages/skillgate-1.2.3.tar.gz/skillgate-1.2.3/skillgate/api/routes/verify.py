"""Signature verification API endpoint."""

from __future__ import annotations

import json

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from skillgate.core.signer.engine import verify_report, verify_report_with_key

router = APIRouter(prefix="/verify", tags=["verify"])

# SECURITY FIX 16.35: Limit report size for verification
MAX_VERIFY_PAYLOAD_BYTES = 10 * 1024 * 1024  # 10MB


class VerifyRequest(BaseModel):
    """Request to verify a signed report."""

    report: dict[str, object] = Field(description="The signed scan report JSON")
    public_key: str | None = Field(
        default=None, description="Optional hex-encoded public key for verification"
    )


class VerifyResponse(BaseModel):
    """Response from signature verification."""

    valid: bool
    error: str | None = None


@router.post("")
async def verify_signature(req: VerifyRequest) -> VerifyResponse:
    """Verify a signed scan report.

    SECURITY FIX 16.35: Enforce payload size limits to prevent DoS.
    """
    # SECURITY FIX 16.35: Validate payload size
    payload_size = len(json.dumps(req.report))
    if payload_size > MAX_VERIFY_PAYLOAD_BYTES:
        raise HTTPException(
            status_code=413, detail=f"Report size exceeds limit of {MAX_VERIFY_PAYLOAD_BYTES} bytes"
        )

    try:
        if req.public_key:
            valid = verify_report_with_key(req.report, req.public_key)
        else:
            valid = verify_report(req.report)
        return VerifyResponse(valid=valid)
    except Exception as e:
        return VerifyResponse(valid=False, error=str(e))
