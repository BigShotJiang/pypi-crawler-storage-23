"""Authentication endpoints for hosted account access."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Any, Literal

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.auth_observability import (
    failure_class_from_exception,
    record_auth_decision,
)
from skillgate.api.db import get_session
from skillgate.api.device_codes import (
    complete_device_code,
    delete_device_code,
    get_device_code,
    get_device_code_by_user_code,
    store_device_code,
)
from skillgate.api.errors import AuthError
from skillgate.api.models import (
    APIKey,
    EmailVerificationToken,
    OAuthIdentity,
    PasswordResetToken,
    Subscription,
    User,
    UserSession,
)
from skillgate.api.rate_limit import enforce_rate_limit
from skillgate.api.security import (
    create_access_token,
    decode_access_token,
    generate_refresh_token,
    hash_password,
    hash_refresh_token,
    refresh_token_expiry,
    verify_password,
)
from skillgate.api.settings import get_settings
from skillgate.api.supabase_client import SupabaseAuthClient
from skillgate.api.telemetry import get_meter
from skillgate.auth import KeySet, issue_slt
from skillgate.config.license import API_KEY_PATTERN, Tier, validate_api_key

router = APIRouter(prefix="/auth", tags=["auth"])
logger = logging.getLogger(__name__)
bearer_scheme = HTTPBearer(auto_error=False)
meter = get_meter("skillgate.api.auth")
auth_attempts_counter = meter.create_counter("auth_login_attempts")
auth_failures_counter = meter.create_counter("auth_login_failures")
auth_rate_limited_counter = meter.create_counter("auth_rate_limited")

LOGIN_IP_LIMIT = 20
LOGIN_ACCOUNT_LIMIT = 10
SIGNUP_IP_LIMIT = 10
RESET_IP_LIMIT = 8
RATE_WINDOW_SECONDS = 300
RATE_BLOCK_SECONDS = 900
MAX_FAILED_LOGINS = 5
LOCKOUT_MINUTES = 15
VERIFY_TOKEN_TTL_HOURS = 24
VERIFY_EMAIL_IP_LIMIT = 10
VERIFY_EMAIL_ADDRESS_LIMIT = 5
_KEYSET = KeySet()
_ANON_BY_DEVICE: dict[str, datetime] = {}
_ANON_LOCK = Lock()

_TIER_ENTITLEMENTS: dict[Tier, dict[str, int]] = {
    Tier.FREE: {"max_scans_per_day": 20, "max_shell_exec_per_day": 10},
    Tier.PRO: {"max_scans_per_day": 500, "max_shell_exec_per_day": 200},
    Tier.TEAM: {"max_scans_per_day": 5_000, "max_shell_exec_per_day": 2_000},
    Tier.ENTERPRISE: {"max_scans_per_day": 50_000, "max_shell_exec_per_day": 20_000},
}

_TIER_RATE_LIMITS: dict[Tier, dict[str, dict[str, int]]] = {
    Tier.FREE: {
        "shell.exec": {"per_minute": 5, "burst": 5},
        "net.http": {"per_minute": 20, "burst": 20},
        "fs.write": {"per_minute": 10, "burst": 10},
    },
    Tier.PRO: {
        "shell.exec": {"per_minute": 30, "burst": 30},
        "net.http": {"per_minute": 120, "burst": 120},
        "fs.write": {"per_minute": 60, "burst": 60},
    },
    Tier.TEAM: {
        "shell.exec": {"per_minute": 120, "burst": 120},
        "net.http": {"per_minute": 360, "burst": 360},
        "fs.write": {"per_minute": 180, "burst": 180},
    },
    Tier.ENTERPRISE: {
        "shell.exec": {"per_minute": 600, "burst": 600},
        "net.http": {"per_minute": 1_200, "burst": 1_200},
        "fs.write": {"per_minute": 900, "burst": 900},
    },
}

_ANON_ENTITLEMENTS: dict[str, int] = {"max_scans_per_day": 5, "max_shell_exec_per_day": 2}
_ANON_RATE_LIMITS: dict[str, dict[str, int]] = {
    "shell.exec": {"per_minute": 1, "burst": 1},
    "net.http": {"per_minute": 5, "burst": 5},
    "fs.write": {"per_minute": 2, "burst": 2},
}


class SignupRequest(BaseModel):
    """User signup payload."""

    email: str = Field(min_length=5, max_length=320)
    password: str = Field(min_length=12, max_length=128)
    full_name: str | None = Field(default=None, max_length=120)


class SignupResponse(BaseModel):
    """Signup response for strict email verification flow."""

    status: str
    verification_required: bool = True
    verification_token: str | None = None


class LoginRequest(BaseModel):
    """Login payload."""

    email: str = Field(min_length=5, max_length=320)
    password: str = Field(min_length=1, max_length=128)


class RefreshRequest(BaseModel):
    """Refresh token payload."""

    refresh_token: str = Field(min_length=20, max_length=512)


class PasswordResetRequest(BaseModel):
    """Password reset request payload."""

    email: str = Field(min_length=5, max_length=320)


class PasswordResetConfirmRequest(BaseModel):
    """Password reset confirmation payload."""

    token: str = Field(min_length=20, max_length=512)
    new_password: str = Field(min_length=12, max_length=128)


class OAuthCallbackRequest(BaseModel):
    """OAuth callback payload (provider-specific auth code)."""

    code: str = Field(min_length=6, max_length=1024)


class ExchangeRequest(BaseModel):
    """API key exchange request for SLT issuance."""

    api_key: str = Field(min_length=1, max_length=256)
    device_id: str = Field(min_length=1, max_length=128)
    session_info: dict[str, Any] = Field(default_factory=dict)


class AnonymousExchangeRequest(BaseModel):
    """Anonymous trial request for SLT issuance."""

    device_id: str = Field(min_length=1, max_length=128)


class ExchangeResponsePayload(BaseModel):
    """SLT exchange response payload."""

    slt: str
    entitlements: dict[str, int]
    rate_limit_policy: dict[str, dict[str, int]]
    expires_at: str
    anonymous: bool = False


class AuthResponse(BaseModel):
    """Standard auth response with access + refresh tokens."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    session_id: str
    user_id: str
    email: str


class UserResponse(BaseModel):
    """Current user profile response with tier and subscription info."""

    user_id: str
    email: str
    full_name: str | None = None
    email_verified: bool
    tier: str = "free"
    subscription_status: str | None = None
    billing_interval: str | None = None
    current_period_end: str | None = None
    cancel_at_period_end: bool = False


class PasswordResetRequestResponse(BaseModel):
    """Password reset request response."""

    status: str
    reset_token: str | None = None


class OAuthProvidersResponse(BaseModel):
    """Supported OAuth providers list."""

    providers: list[str]


class ProfileUpdateRequest(BaseModel):
    """Profile update payload."""

    full_name: str | None = Field(default=None, max_length=120)
    email: str | None = Field(default=None, min_length=5, max_length=320)


class AccountDeleteRequest(BaseModel):
    """Account deletion payload. Requires password and explicit confirmation."""

    password: str = Field(min_length=1, max_length=128)
    confirmation: Literal["DELETE"]


class EmailVerificationRequestResponse(BaseModel):
    """Email verification token issuance response."""

    status: str
    verification_token: str | None = None


class EmailVerificationConfirmRequest(BaseModel):
    """Email verification token confirmation payload."""

    token: str = Field(min_length=20, max_length=512)


class EmailVerificationRequest(BaseModel):
    """Email verification resend request payload."""

    email: str = Field(min_length=5, max_length=320)


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _client_ip(request: Request) -> str:
    """Get client IP with trusted proxy support.

    Only trust x-forwarded-for if request comes from known proxy.
    Otherwise use direct socket IP to prevent spoofing.
    """
    # In production, check if request is from trusted proxy
    # For now, we use socket IP which cannot be spoofed
    client = request.client
    if client is None:
        return "unknown"
    return client.host


def _tier_payload_for_api_key(
    api_key: str,
) -> tuple[Tier, dict[str, int], dict[str, dict[str, int]]]:
    """Validate API key shape/tier and return entitlement payload."""
    if not isinstance(api_key, str) or not api_key.strip():
        raise HTTPException(status_code=400, detail="API key is required")
    if not API_KEY_PATTERN.match(api_key):
        if api_key.startswith("sg_"):
            raise HTTPException(status_code=401, detail="Invalid API key")
        raise HTTPException(status_code=400, detail="Malformed API key")
    try:
        tier = validate_api_key(api_key)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=401, detail="Invalid API key") from exc
    return tier, dict(_TIER_ENTITLEMENTS[tier]), dict(_TIER_RATE_LIMITS[tier])


def _issue_exchange_payload(
    *,
    org_id: str,
    device_id: str,
    tier: Tier,
    entitlements: dict[str, int],
    rate_limits: dict[str, dict[str, int]],
    anonymous: bool,
    ttl_hours: int,
) -> ExchangeResponsePayload:
    active_key = _KEYSET.active
    token_id = uuid.uuid4().hex
    token = issue_slt(
        private_key_pem=active_key.private_pem,
        kid=active_key.kid,
        org_id=org_id,
        device_id=device_id,
        tier=tier.value,
        entitlements=entitlements,
        rate_limits=rate_limits,
        anonymous=anonymous,
        issuer=_KEYSET.issuer,
        audience=_KEYSET.audience,
        token_id=token_id,
        ttl_hours=ttl_hours,
    )
    expires_at = datetime.now(tz=timezone.utc) + timedelta(hours=ttl_hours)
    return ExchangeResponsePayload(
        slt=token,
        entitlements=entitlements,
        rate_limit_policy=rate_limits,
        expires_at=expires_at.replace(microsecond=0).isoformat(),
        anonymous=anonymous,
    )


async def _create_email_verification_token(*, session: AsyncSession, user: User) -> str:
    """Create and persist single-use email verification token."""
    token_plain = "sg_verify_" + uuid.uuid4().hex + uuid.uuid4().hex
    token = EmailVerificationToken(
        id=str(uuid.uuid4()),
        user_id=user.id,
        token_hash=hash_refresh_token(token_plain),
        expires_at=_now() + timedelta(hours=VERIFY_TOKEN_TTL_HOURS),
    )
    session.add(token)
    await session.commit()
    return token_plain


async def _send_verification_email(*, email: str, token_plain: str) -> bool:
    """Send email verification link via Resend when configured."""
    settings = get_settings()
    if not settings.resend_api_key or not settings.resend_from_email:
        logger.info("resend.not_configured email=%s", email)
        return False

    verify_url = f"{settings.web_base_url}/verify-email?token={token_plain}"
    logo_url = f"{settings.web_base_url}/images/brandname.jpg"
    html = "\n".join(
        [
            "<!doctype html>",
            "<html>",
            "  <body style='margin:0;padding:0;background:#f4f6fb;font-family:Arial,sans-serif;'>",
            "    <table role='presentation' width='100%' cellspacing='0' cellpadding='0'",
            "      style='padding:24px 0;'>",
            "      <tr><td align='center'>",
            "        <table role='presentation' width='600' cellspacing='0' cellpadding='0'",
            "          style='background:#fff;border:1px solid #e5e7eb;border-radius:12px;",
            "            overflow:hidden;'>",
            "          <tr><td style='background:#0b1220;padding:24px 28px;text-align:center;'>",
            f"            <img src='{logo_url}' alt='SkillGate' width='160'",
            "              style='display:block;margin:0 auto 12px;border:0;outline:none;'>",
            "            <div style='color:#cbd5e1;font-size:12px;letter-spacing:0.08em;",
            "              text-transform:uppercase;'>Security Verification</div>",
            "          </td></tr>",
            "          <tr><td style='padding:28px;'>",
            "            <h1 style='margin:0 0 12px;font-size:24px;",
            "              line-height:1.3;color:#111827;'>",
            "              Verify your email address",
            "            </h1>",
            "            <p style='margin:0 0 16px;color:#374151;font-size:15px;line-height:1.7;'>",
            "              Welcome to SkillGate. Please verify your email",
            "              to activate dashboard access.",
            "            </p>",
            "            <table role='presentation' cellspacing='0' cellpadding='0'",
            "              style='margin:20px 0 24px;'><tr>",
            "              <td style='border-radius:8px;background:#2563eb;'>",
            f"                <a href='{verify_url}'",
            "                  style='display:inline-block;padding:12px 20px;'",
            "                  color:#fff;text-decoration:none;font-weight:600;font-size:14px;'>",
            "                  Verify Email",
            "                </a>",
            "              </td></tr></table>",
            "            <p style='margin:0 0 10px;color:#6b7280;font-size:13px;line-height:1.6;'>",
            f"              This link expires in {VERIFY_TOKEN_TTL_HOURS} hours.",
            "            </p>",
            "            <p style='margin:0;color:#6b7280;font-size:13px;line-height:1.6;'>",
            "              If you did not create this account, you can safely ignore this email.",
            "            </p>",
            "          </td></tr>",
            "          <tr><td style='background:#f9fafb;padding:16px 28px;color:#6b7280;",
            "            font-size:12px;line-height:1.6;'>",
            "            SkillGate - CI gatekeeper for agent skills",
            "          </td></tr>",
            "        </table>",
            "      </td></tr>",
            "    </table>",
            "  </body>",
            "</html>",
        ]
    )
    text = (
        "SkillGate email verification\n\n"
        "Verify your email to activate dashboard access:\n"
        f"{verify_url}\n\n"
        f"This link expires in {VERIFY_TOKEN_TTL_HOURS} hours.\n"
        "If you did not create this account, ignore this email."
    )
    payload = {
        "from": settings.resend_from_email,
        "to": [email],
        "subject": "Verify your SkillGate email",
        "html": html,
        "text": text,
    }
    headers = {
        "Authorization": f"Bearer {settings.resend_api_key}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                "https://api.resend.com/emails",
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
            return True
    except httpx.HTTPError as exc:
        logger.warning("resend.send_failed email=%s error=%s", email, exc)
        return False


def _get_supabase_client() -> SupabaseAuthClient:
    """Instantiate a Supabase auth client from settings.

    Raises ``RuntimeError`` if called when Supabase is not configured.
    """
    settings = get_settings()
    if not settings.supabase_url or not settings.supabase_service_role_key:
        raise RuntimeError("Supabase auth provider is not configured")
    return SupabaseAuthClient(
        base_url=settings.supabase_url,
        service_role_key=settings.supabase_service_role_key,
    )


async def _issue_session_tokens(
    *,
    user: User,
    session: AsyncSession,
    request: Request,
    parent_session_id: str | None = None,
) -> AuthResponse:
    refresh_token = generate_refresh_token()
    session_id = str(uuid.uuid4())
    refresh_hash = hash_refresh_token(refresh_token)
    db_session = UserSession(
        id=session_id,
        user_id=user.id,
        refresh_token_hash=refresh_hash,
        user_agent=request.headers.get("user-agent"),
        ip_address=_client_ip(request),
        parent_session_id=parent_session_id,
        expires_at=refresh_token_expiry().replace(tzinfo=None),
    )
    session.add(db_session)
    await session.commit()

    access_token = create_access_token(subject=user.id, session_id=session_id)
    return AuthResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        session_id=session_id,
        user_id=user.id,
        email=user.email,
    )


@router.post("/signup", response_model=SignupResponse)
async def signup(
    req: SignupRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> SignupResponse:
    """Create a user account and send verification email (strict mode)."""
    provider = "supabase" if get_settings().is_supabase else "local"
    try:
        if get_settings().is_supabase:
            from skillgate.api.supabase_auth_provider import supabase_signup

            sb_client = _get_supabase_client()
            try:
                result = await supabase_signup(
                    auth_client=sb_client,
                    email=req.email,
                    password=req.password,
                    full_name=req.full_name,
                    db=session,
                    request=request,
                )
            finally:
                await sb_client.aclose()
            response = SignupResponse(**result)
            record_auth_decision(endpoint="signup", provider=provider, outcome="success")
            return response

        # --- local provider path (unchanged) ---
        try:
            await enforce_rate_limit(
                session=session,
                scope="signup_ip",
                bucket_key=_client_ip(request),
                limit=SIGNUP_IP_LIMIT,
                window_seconds=RATE_WINDOW_SECONDS,
                block_seconds=RATE_BLOCK_SECONDS,
            )
        except HTTPException as exc:
            if exc.status_code == 429:
                auth_rate_limited_counter.add(1, {"endpoint": "signup"})
            raise

        existing = await session.scalar(select(User).where(User.email == req.email))
        if existing is not None:
            raise HTTPException(status_code=409, detail="Email is already registered")

        user = User(
            id=str(uuid.uuid4()),
            email=req.email,
            password_hash=hash_password(req.password),
            full_name=req.full_name,
        )
        session.add(user)
        await session.commit()

        verify_token = await _create_email_verification_token(session=session, user=user)
        await _send_verification_email(email=user.email, token_plain=verify_token)
        if get_settings().is_production:
            response = SignupResponse(status="verification_pending", verification_required=True)
        else:
            response = SignupResponse(
                status="verification_pending",
                verification_required=True,
                verification_token=verify_token,
            )
        record_auth_decision(endpoint="signup", provider=provider, outcome="success")
        return response
    except HTTPException as exc:
        record_auth_decision(
            endpoint="signup",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            status_code=exc.status_code,
        )
        raise
    except Exception as exc:
        record_auth_decision(
            endpoint="signup",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
        )
        raise


@router.post("/login", response_model=AuthResponse)
async def login(
    req: LoginRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> AuthResponse:
    """Authenticate user and return rotated session tokens."""
    auth_attempts_counter.add(1, {"endpoint": "login"})
    provider = "supabase" if get_settings().is_supabase else "local"

    try:
        if get_settings().is_supabase:
            from skillgate.api.supabase_auth_provider import supabase_login

            sb_client = _get_supabase_client()
            try:
                response = await supabase_login(
                    auth_client=sb_client,
                    email=req.email,
                    password=req.password,
                    db=session,
                    request=request,
                )
            finally:
                await sb_client.aclose()
            record_auth_decision(endpoint="login", provider=provider, outcome="success")
            return response

        # --- local provider path (unchanged) ---
        client_ip = _client_ip(request)
        try:
            await enforce_rate_limit(
                session=session,
                scope="login_ip",
                bucket_key=client_ip,
                limit=LOGIN_IP_LIMIT,
                window_seconds=RATE_WINDOW_SECONDS,
                block_seconds=RATE_BLOCK_SECONDS,
            )
            await enforce_rate_limit(
                session=session,
                scope="login_email",
                bucket_key=req.email.lower(),
                limit=LOGIN_ACCOUNT_LIMIT,
                window_seconds=RATE_WINDOW_SECONDS,
                block_seconds=RATE_BLOCK_SECONDS,
            )
        except HTTPException as exc:
            if exc.status_code == 429:
                auth_rate_limited_counter.add(1, {"endpoint": "login"})
            raise

        user = await session.scalar(select(User).where(User.email == req.email))
        if user is None:
            auth_failures_counter.add(1, {"reason": "invalid_credentials"})
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials",
            )

        now = _now()
        if user.lockout_until and user.lockout_until > now:
            auth_failures_counter.add(1, {"reason": "account_locked"})
            raise HTTPException(
                status_code=423,
                detail="Account temporarily locked due to failed logins",
            )

        if not verify_password(req.password, user.password_hash):
            auth_failures_counter.add(1, {"reason": "invalid_password"})
            user.failed_login_attempts += 1
            if user.failed_login_attempts >= MAX_FAILED_LOGINS:
                user.lockout_until = now + timedelta(minutes=LOCKOUT_MINUTES)
                user.failed_login_attempts = 0
            await session.commit()
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials",
            )

        if not user.email_verified:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Email verification required",
            )

        user.failed_login_attempts = 0
        user.lockout_until = None
        await session.commit()
        response = await _issue_session_tokens(user=user, session=session, request=request)
        record_auth_decision(endpoint="login", provider=provider, outcome="success")
        return response
    except HTTPException as exc:
        record_auth_decision(
            endpoint="login",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            status_code=exc.status_code,
        )
        raise
    except Exception as exc:
        record_auth_decision(
            endpoint="login",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
        )
        raise


@router.post("/refresh", response_model=AuthResponse)
async def refresh(
    req: RefreshRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> AuthResponse:
    """Rotate refresh token and issue a new access token/session."""
    provider = "supabase" if get_settings().is_supabase else "local"
    try:
        if get_settings().is_supabase:
            from skillgate.api.supabase_auth_provider import supabase_refresh

            sb_client = _get_supabase_client()
            try:
                response = await supabase_refresh(
                    auth_client=sb_client,
                    refresh_token=req.refresh_token,
                    db=session,
                    request=request,
                )
            finally:
                await sb_client.aclose()
            record_auth_decision(endpoint="refresh", provider=provider, outcome="success")
            return response

        # --- local provider path (unchanged) ---
        token_hash = hash_refresh_token(req.refresh_token)
        db_session = await session.scalar(
            select(UserSession).where(UserSession.refresh_token_hash == token_hash)
        )
        if db_session is None or db_session.revoked:
            raise HTTPException(status_code=401, detail="Invalid refresh token")

        now = _now()
        if db_session.expires_at <= now:
            db_session.revoked = True
            db_session.revoked_at = now
            await session.commit()
            raise HTTPException(status_code=401, detail="Refresh token expired")

        user = await session.get(User, db_session.user_id)
        if user is None or not user.is_active:
            raise HTTPException(status_code=401, detail="Inactive account")

        db_session.revoked = True
        db_session.revoked_at = now
        await session.commit()

        next_tokens = await _issue_session_tokens(
            user=user,
            session=session,
            request=request,
            parent_session_id=db_session.id,
        )
        db_session.rotated_to_session_id = next_tokens.session_id
        await session.commit()
        record_auth_decision(endpoint="refresh", provider=provider, outcome="success")
        return next_tokens
    except HTTPException as exc:
        record_auth_decision(
            endpoint="refresh",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            status_code=exc.status_code,
        )
        raise
    except Exception as exc:
        record_auth_decision(
            endpoint="refresh",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
        )
        raise


@router.post("/logout")
async def logout(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, str]:
    """Logout current session by revoking the active session row."""
    provider = "supabase" if get_settings().is_supabase else "local"
    try:
        if credentials is None:
            raise HTTPException(status_code=401, detail="Missing bearer token")

        if get_settings().is_supabase:
            from skillgate.api.supabase_auth_provider import supabase_logout

            sb_client = _get_supabase_client()
            try:
                await supabase_logout(
                    auth_client=sb_client,
                    access_token=credentials.credentials,
                    db=session,
                )
            finally:
                await sb_client.aclose()
            record_auth_decision(endpoint="logout", provider=provider, outcome="success")
            return {"status": "logged_out"}

        # --- local provider path (unchanged) ---
        try:
            claims = decode_access_token(credentials.credentials)
        except ValueError as exc:
            raise HTTPException(status_code=401, detail="Invalid token") from exc

        session_id = claims.get("sid")
        if not session_id:
            record_auth_decision(endpoint="logout", provider=provider, outcome="success")
            return {"status": "logged_out"}

        db_session = await session.get(UserSession, session_id)
        if db_session is not None and not db_session.revoked:
            db_session.revoked = True
            db_session.revoked_at = _now()
            await session.commit()
        record_auth_decision(endpoint="logout", provider=provider, outcome="success")
        return {"status": "logged_out"}
    except HTTPException as exc:
        record_auth_decision(
            endpoint="logout",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            status_code=exc.status_code,
        )
        raise
    except Exception as exc:
        record_auth_decision(
            endpoint="logout",
            provider=provider,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
        )
        raise


@router.post("/password-reset/request", response_model=PasswordResetRequestResponse)
async def password_reset_request(
    req: PasswordResetRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> PasswordResetRequestResponse:
    """Issue password reset token without revealing account existence."""
    try:
        await enforce_rate_limit(
            session=session,
            scope="reset_ip",
            bucket_key=_client_ip(request),
            limit=RESET_IP_LIMIT,
            window_seconds=RATE_WINDOW_SECONDS,
            block_seconds=RATE_BLOCK_SECONDS,
        )
    except HTTPException as exc:
        if exc.status_code == 429:
            auth_rate_limited_counter.add(1, {"endpoint": "password_reset"})
        raise

    user = await session.scalar(select(User).where(User.email == req.email))
    if user is None:
        return PasswordResetRequestResponse(status="sent")

    token_plain = "sg_reset_" + uuid.uuid4().hex + uuid.uuid4().hex
    token = PasswordResetToken(
        id=str(uuid.uuid4()),
        user_id=user.id,
        token_hash=hash_refresh_token(token_plain),
        expires_at=(_now() + timedelta(minutes=30)),
    )
    session.add(token)
    await session.commit()

    if get_settings().is_production:
        return PasswordResetRequestResponse(status="sent")
    return PasswordResetRequestResponse(status="sent", reset_token=token_plain)


@router.post("/password-reset/confirm")
async def password_reset_confirm(
    req: PasswordResetConfirmRequest,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, str]:
    """Confirm password reset token and rotate account sessions."""
    token_hash = hash_refresh_token(req.token)
    token = await session.scalar(
        select(PasswordResetToken).where(PasswordResetToken.token_hash == token_hash)
    )
    now = _now()
    if token is None or token.used_at is not None or token.expires_at <= now:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")

    user = await session.get(User, token.user_id)
    if user is None:
        raise HTTPException(status_code=400, detail="Invalid reset token")

    user.password_hash = hash_password(req.new_password)
    token.used_at = now

    active = await session.scalars(
        select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked.is_(False))
    )
    for item in active.all():
        item.revoked = True
        item.revoked_at = now

    await session.commit()
    return {"status": "password_updated"}


@router.get("/oauth/providers", response_model=OAuthProvidersResponse)
async def oauth_providers() -> OAuthProvidersResponse:
    """List currently supported OAuth providers."""
    if not get_settings().oauth_enabled:
        return OAuthProvidersResponse(providers=[])
    return OAuthProvidersResponse(providers=["google", "github"])


@router.post("/oauth/{provider}/callback", response_model=AuthResponse)
async def oauth_callback(
    provider: str,
    req: OAuthCallbackRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> AuthResponse:
    """Handle OAuth callback after provider authorization."""
    provider_name = "supabase" if get_settings().is_supabase else "local"
    try:
        if not get_settings().oauth_enabled:
            raise HTTPException(status_code=404, detail="OAuth is disabled")

        if get_settings().is_supabase:
            from skillgate.api.supabase_auth_provider import supabase_oauth_callback

            sb_client = _get_supabase_client()
            try:
                response = await supabase_oauth_callback(
                    auth_client=sb_client,
                    provider=provider,
                    code=req.code,
                    db=session,
                    request=request,
                )
            finally:
                await sb_client.aclose()
            record_auth_decision(
                endpoint="oauth_callback",
                provider=provider_name,
                outcome="success",
            )
            return response

        # --- local provider path ---
        provider_norm = provider.lower()
        if provider_norm not in {"google", "github"}:
            raise HTTPException(status_code=400, detail="Unsupported OAuth provider")

        # SECURITY FIX 16.30: Block demo mode in production/staging
        if req.code.startswith("demo:"):
            if get_settings().is_production:
                raise HTTPException(
                    status_code=400,
                    detail="Demo OAuth is not available in production",
                )
            # Demo mode only for development
            parts = req.code.split(":", 3)
            if len(parts) < 3:
                raise HTTPException(status_code=400, detail="Invalid OAuth callback payload")

            email = parts[1].strip().lower()
            provider_user_id = parts[2].strip()
            full_name = parts[3].strip() if len(parts) == 4 else None
            if not email or not provider_user_id:
                raise HTTPException(status_code=400, detail="Invalid OAuth callback payload")
        else:
            # Real OAuth: must integrate with provider
            raise HTTPException(
                status_code=501,
                detail="OAuth provider integration not yet implemented",
            )

        identity = await session.scalar(
            select(OAuthIdentity).where(
                OAuthIdentity.provider == provider_norm,
                OAuthIdentity.provider_user_id == provider_user_id,
            )
        )

        user: User | None = None
        if identity is not None:
            user = await session.get(User, identity.user_id)

        if user is None:
            user = await session.scalar(select(User).where(User.email == email))

        if user is None:
            user = User(
                id=str(uuid.uuid4()),
                email=email,
                password_hash=hash_password(str(uuid.uuid4())),
                full_name=full_name,
                email_verified=True,
            )
            session.add(user)
            await session.commit()

        if identity is None:
            identity = OAuthIdentity(
                id=str(uuid.uuid4()),
                user_id=user.id,
                provider=provider_norm,
                provider_user_id=provider_user_id,
                email=email,
            )
            session.add(identity)
        else:
            identity.user_id = user.id
            identity.email = email
        await session.commit()

        response = await _issue_session_tokens(user=user, session=session, request=request)
        record_auth_decision(
            endpoint="oauth_callback",
            provider=provider_name,
            outcome="success",
        )
        return response
    except HTTPException as exc:
        record_auth_decision(
            endpoint="oauth_callback",
            provider=provider_name,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            status_code=exc.status_code,
            context={"oauth_provider": provider.lower()},
        )
        raise
    except Exception as exc:
        record_auth_decision(
            endpoint="oauth_callback",
            provider=provider_name,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            context={"oauth_provider": provider.lower()},
        )
        raise


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> User:
    """Resolve authenticated user from bearer JWT token + active session."""
    settings = get_settings()
    provider_name = "supabase" if settings.is_supabase else "local"

    try:
        if credentials is None:
            raise HTTPException(status_code=401, detail="Missing bearer token")

        if settings.is_supabase:
            from skillgate.api.supabase_jwt import verify_supabase_token

            try:
                claims = await verify_supabase_token(
                    credentials.credentials,
                    jwks_url=settings.supabase_jwks_url,
                    jwt_secret=settings.supabase_jwt_secret,
                    issuer=f"{settings.supabase_url}/auth/v1" if settings.supabase_url else None,
                    apikey=settings.supabase_anon_key,
                )
            except AuthError as exc:
                raise HTTPException(status_code=401, detail="Invalid token") from exc

            user_id: str = claims.get("sub", "")
            if not user_id:
                raise HTTPException(status_code=401, detail="Invalid token subject")

            # Try by PK first (native Supabase user: users.id = Supabase UUID).
            user = await session.get(User, user_id)
            # Fallback: migrated local user where supabase_user_id links to JWT sub.
            if user is None:
                user = await session.scalar(select(User).where(User.supabase_user_id == user_id))
            if user is None or not user.is_active:
                raise HTTPException(status_code=401, detail="Inactive account")

            record_auth_decision(
                endpoint="get_current_user",
                provider=provider_name,
                outcome="success",
            )
            return user

        # --- local provider path (unchanged) ---
        try:
            claims = decode_access_token(credentials.credentials)
        except ValueError as exc:
            raise HTTPException(status_code=401, detail="Invalid token") from exc

        user = await session.get(User, claims["sub"])
        if user is None or not user.is_active:
            raise HTTPException(status_code=401, detail="Inactive account")

        sid = claims.get("sid")
        if sid:
            db_session = await session.get(UserSession, sid)
            now = _now()
            if (
                db_session is None
                or db_session.user_id != user.id
                or db_session.revoked
                or db_session.expires_at <= now
            ):
                raise HTTPException(status_code=401, detail="Session revoked or expired")

        record_auth_decision(
            endpoint="get_current_user",
            provider=provider_name,
            outcome="success",
        )
        return user
    except HTTPException as exc:
        record_auth_decision(
            endpoint="get_current_user",
            provider=provider_name,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
            status_code=exc.status_code,
        )
        raise
    except Exception as exc:
        record_auth_decision(
            endpoint="get_current_user",
            provider=provider_name,
            outcome="failure",
            failure_class=failure_class_from_exception(exc),
        )
        raise


@router.post("/verify-email/request", response_model=EmailVerificationRequestResponse)
async def request_email_verification(
    req: EmailVerificationRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> EmailVerificationRequestResponse:
    """Issue a verification token and send verification email."""
    try:
        await enforce_rate_limit(
            session=session,
            scope="verify_email_ip",
            bucket_key=_client_ip(request),
            limit=VERIFY_EMAIL_IP_LIMIT,
            window_seconds=RATE_WINDOW_SECONDS,
            block_seconds=RATE_BLOCK_SECONDS,
        )
        await enforce_rate_limit(
            session=session,
            scope="verify_email_email",
            bucket_key=req.email.lower(),
            limit=VERIFY_EMAIL_ADDRESS_LIMIT,
            window_seconds=RATE_WINDOW_SECONDS,
            block_seconds=RATE_BLOCK_SECONDS,
        )
    except HTTPException as exc:
        if exc.status_code == 429:
            auth_rate_limited_counter.add(1, {"endpoint": "verify_email_request"})
        raise

    user = await session.scalar(select(User).where(User.email == req.email))
    if user is None or user.email_verified:
        return EmailVerificationRequestResponse(status="sent")

    token_plain = await _create_email_verification_token(session=session, user=user)
    sent = await _send_verification_email(email=user.email, token_plain=token_plain)
    if sent:
        return EmailVerificationRequestResponse(status="sent")

    if not get_settings().is_production:
        return EmailVerificationRequestResponse(status="sent", verification_token=token_plain)

    raise HTTPException(status_code=503, detail="Email provider unavailable")


@router.post("/verify-email/confirm")
async def confirm_email_verification(
    req: EmailVerificationConfirmRequest,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, str]:
    """Consume verification token and mark user email as verified."""
    token_hash = hash_refresh_token(req.token)
    row = await session.scalar(
        select(EmailVerificationToken).where(EmailVerificationToken.token_hash == token_hash)
    )
    now = _now()
    if row is None or row.used_at is not None or row.expires_at <= now:
        raise HTTPException(status_code=400, detail="Invalid or expired verification token")

    user = await session.get(User, row.user_id)
    if user is None:
        raise HTTPException(status_code=400, detail="Invalid verification token")

    user.email_verified = True
    row.used_at = now
    await session.commit()
    return {"status": "verified"}


@router.post("/logout-all")
async def logout_all(
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, int]:
    """Revoke every active session for current user."""
    rows = await session.scalars(
        select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked.is_(False))
    )
    now = _now()
    count = 0
    for item in rows.all():
        item.revoked = True
        item.revoked_at = now
        count += 1
    await session.commit()
    return {"revoked_sessions": count}


async def _build_user_response(user: User, session: AsyncSession) -> UserResponse:
    """Build UserResponse with tier resolved from active subscription."""
    sub = await session.scalar(
        select(Subscription)
        .where(Subscription.user_id == user.id, Subscription.status == "active")
        .order_by(Subscription.created_at.desc())
        .limit(1)
    )
    tier = "free"
    sub_status: str | None = None
    billing_interval: str | None = None
    period_end: str | None = None
    cancel_at: bool = False
    if sub is not None:
        tier = sub.tier
        sub_status = sub.status
        billing_interval = sub.billing_interval
        if sub.current_period_end is not None:
            period_end = sub.current_period_end.isoformat()
        cancel_at = sub.cancel_at_period_end
    return UserResponse(
        user_id=user.id,
        email=user.email,
        full_name=user.full_name,
        email_verified=user.email_verified,
        tier=tier,
        subscription_status=sub_status,
        billing_interval=billing_interval,
        current_period_end=period_end,
        cancel_at_period_end=cancel_at,
    )


@router.get("/me", response_model=UserResponse)
async def me(
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> UserResponse:
    """Return current authenticated user profile with subscription tier."""
    return await _build_user_response(user, session)


@router.patch("/profile", response_model=UserResponse)
async def update_profile(
    req: ProfileUpdateRequest,
    request: Request,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> UserResponse:
    """Update user profile fields (name, email)."""
    await enforce_rate_limit(
        session=session,
        scope="profile_update",
        bucket_key=user.id,
        limit=10,
        window_seconds=RATE_WINDOW_SECONDS,
        block_seconds=RATE_BLOCK_SECONDS,
    )

    if req.email is not None and req.email != user.email:
        existing = await session.scalar(select(User).where(User.email == req.email))
        if existing is not None:
            raise HTTPException(status_code=409, detail="Email is already registered")
        user.email = req.email
        user.email_verified = False

    if req.full_name is not None:
        user.full_name = req.full_name

    await session.commit()
    return await _build_user_response(user, session)


@router.delete("/account")
async def delete_account(
    req: AccountDeleteRequest,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, str]:
    """Soft-delete user account. Requires password + 'DELETE' confirmation.

    Anonymizes email, deactivates account, revokes all sessions and API keys.
    """
    if not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=403, detail="Incorrect password")

    now = _now()

    # Soft-delete: deactivate and anonymize
    user.is_active = False
    user.email = f"deleted_{uuid.uuid4().hex[:12]}@redacted"
    user.full_name = None

    # Revoke all sessions
    active_sessions = await session.scalars(
        select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked.is_(False))
    )
    for s in active_sessions.all():
        s.revoked = True
        s.revoked_at = now

    # Revoke all API keys
    await session.execute(
        update(APIKey)
        .where(APIKey.user_id == user.id, APIKey.revoked.is_(False))
        .values(revoked=True)
    )

    await session.commit()
    return {"status": "account_deleted"}


# ============================================================================
# Session License Token (SLT) exchange
# ============================================================================


@router.post("/exchange", response_model=ExchangeResponsePayload)
async def exchange_api_key_for_slt(req: ExchangeRequest) -> ExchangeResponsePayload:
    """Exchange API key for Session License Token."""
    tier, entitlements, rate_limits = _tier_payload_for_api_key(req.api_key)
    org_id = f"org:{req.api_key[:16]}"
    return _issue_exchange_payload(
        org_id=org_id,
        device_id=req.device_id,
        tier=tier,
        entitlements=entitlements,
        rate_limits=rate_limits,
        anonymous=False,
        ttl_hours=12,
    )


@router.post("/anonymous", response_model=ExchangeResponsePayload)
async def issue_anonymous_slt(req: AnonymousExchangeRequest) -> ExchangeResponsePayload:
    """Issue one anonymous trial SLT per device per 24h."""
    now = datetime.now(tz=timezone.utc)
    with _ANON_LOCK:
        previous = _ANON_BY_DEVICE.get(req.device_id)
        if previous is not None and now - previous < timedelta(hours=24):
            raise HTTPException(status_code=429, detail="Anonymous trial already issued for device")
        _ANON_BY_DEVICE[req.device_id] = now

    return _issue_exchange_payload(
        org_id=f"anon:{req.device_id}",
        device_id=req.device_id,
        tier=Tier.FREE,
        entitlements=dict(_ANON_ENTITLEMENTS),
        rate_limits=dict(_ANON_RATE_LIMITS),
        anonymous=True,
        ttl_hours=24,
    )


@router.get("/.well-known/jwks.json")
async def auth_jwks() -> dict[str, Any]:
    """Return JWKS for SLT verification clients."""
    return _KEYSET.jwks()


# ============================================================================
# Device Code OAuth Flow (for CLI authentication)
# ============================================================================


class DeviceCodeRequest(BaseModel):
    """Device code initiation request."""

    client_id: str = "skillgate-cli"


class DeviceCodeResponse(BaseModel):
    """Device code response."""

    device_code: str
    user_code: str
    verification_uri: str
    expires_in: int = 300
    interval: int = 5


class DeviceTokenRequest(BaseModel):
    """Device token poll request."""

    device_code: str


class DeviceTokenResponse(BaseModel):
    """Device token response (on success)."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    tier: str
    email: str


class DeviceTokenErrorResponse(BaseModel):
    """Device token error response."""

    error: str
    error_description: str | None = None


class DeviceVerifyRequest(BaseModel):
    """Device code verification request (user submits code)."""

    user_code: str
    provider: str
    email: str
    provider_user_id: str
    full_name: str | None = None


@router.post("/device/code", response_model=DeviceCodeResponse)
async def device_code_start(
    req: DeviceCodeRequest,
) -> DeviceCodeResponse:
    """Start device code flow for CLI authentication."""
    import random
    import string

    # Generate user code (4-4 format, easy to type)
    def _gen_code(length: int) -> str:
        return "".join(random.choices(string.ascii_uppercase + string.digits, k=length))

    user_code = f"{_gen_code(4)}-{_gen_code(4)}"
    device_code = uuid.uuid4().hex + uuid.uuid4().hex

    # Store in Redis (production) or memory (dev/test)
    await store_device_code(
        device_code=device_code,
        user_code=user_code,
        client_id=req.client_id,
        expires_in_seconds=300,
    )

    return DeviceCodeResponse(
        device_code=device_code,
        user_code=user_code,
        verification_uri="https://skillgate.io/activate",
        expires_in=300,
        interval=5,
    )


@router.post("/device/token")
async def device_token_poll(
    req: DeviceTokenRequest,
) -> DeviceTokenResponse | DeviceTokenErrorResponse:
    """Poll for device token completion (CLI polls this)."""
    device_info = await get_device_code(req.device_code)

    if not device_info:
        return DeviceTokenErrorResponse(error="invalid_device_code")

    if not device_info.get("completed"):
        return DeviceTokenErrorResponse(error="authorization_pending")

    # Completed - return tokens and cleanup
    tokens = device_info["tokens"]
    await delete_device_code(req.device_code)

    return DeviceTokenResponse(
        access_token=tokens["access_token"],
        refresh_token=tokens["refresh_token"],
        tier=tokens.get("tier", "free"),
        email=tokens["email"],
    )


@router.post("/device/verify")
async def device_verify(
    req: DeviceVerifyRequest,
    request: Request,
    user: User = Depends(get_current_user),  # noqa: B008 - SECURITY FIX 16.29: Require auth
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, str]:
    """Verify device code (called by web UI after user logs in).

    SECURITY FIX 16.29: This endpoint NOW REQUIRES authentication.
    User must be logged in via web session before verifying device code.
    This prevents forged identity binding attacks.
    """
    # Find device code by user_code
    result = await get_device_code_by_user_code(req.user_code)

    if not result:
        raise HTTPException(status_code=400, detail="Invalid user code")

    device_code, device_info = result

    # SECURITY FIX 16.29: Check if code was already used (replay protection)
    if device_info.get("completed"):
        raise HTTPException(status_code=400, detail="Device code already used")

    # SECURITY FIX 16.29: Use authenticated user, reject caller-asserted identity
    # The user is already authenticated via get_current_user dependency
    # We ignore req.email, req.provider_user_id, req.provider from request
    # and use the actual authenticated user instead

    # Issue tokens for the AUTHENTICATED user (not the claimed one)
    tokens = await _issue_session_tokens(user=user, session=session, request=request)

    # Mark device code as completed with one-time consumption
    await complete_device_code(
        device_code,
        {
            "access_token": tokens.access_token,
            "refresh_token": tokens.refresh_token,
            "tier": "pro",  # TODO: Get from user's subscription
            "email": user.email,
        },
    )

    return {"status": "verified", "email": user.email}


@router.get("/verify")
async def verify_api_key(
    user: User = Depends(get_current_user),  # noqa: B008
) -> dict[str, object]:
    """Verify API key and return user info.

    Used by CLI to validate stored credentials.
    """
    return {
        "user_id": user.id,
        "email": user.email,
        "full_name": user.full_name,
        "email_verified": user.email_verified,
    }
