"""API key lifecycle endpoints: create, list, revoke, rotate, and verify."""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.models import APIKey, Subscription, User
from skillgate.api.routes.auth import get_current_user
from skillgate.api.security import (
    api_key_prefix,
    generate_api_key,
    generate_tier_api_key,
    hash_api_key,
)

router = APIRouter(prefix="/api-keys", tags=["api-keys"])
ALLOWED_SCOPES = {"scan:read", "scan:write", "team:read", "team:write", "billing:read"}


class APIKeyCreateRequest(BaseModel):
    """Request payload for API key creation."""

    name: str = Field(default="default", min_length=1, max_length=80)
    scopes: list[str] = Field(default_factory=lambda: ["scan:write", "scan:read"])


class APIKeyCreateResponse(BaseModel):
    """Response containing one-time plaintext API key."""

    key_id: str
    api_key: str
    key_prefix: str
    name: str
    scopes: list[str]
    created_at: str


class APIKeyVerifyRequest(BaseModel):
    """Request payload to verify a plaintext API key."""

    api_key: str = Field(min_length=16, max_length=256)
    required_scope: str | None = Field(default=None, max_length=64)


class APIKeyVerifyResponse(BaseModel):
    """Response for key verification and scope authorization."""

    valid: bool
    key_id: str
    key_prefix: str
    scopes: list[str]
    last_used_at: str


class APIKeyInfo(BaseModel):
    """Non-sensitive API key metadata."""

    key_id: str
    key_prefix: str
    name: str
    scopes: list[str]
    revoked: bool
    created_at: str
    last_used_at: str | None = None


class APIKeyListResponse(BaseModel):
    """List response for user API keys."""

    keys: list[APIKeyInfo]


def _normalize_scopes(scopes: list[str]) -> list[str]:
    seen: set[str] = set()
    normalized: list[str] = []
    for scope in scopes:
        value = scope.strip()
        if not value:
            continue
        if value not in ALLOWED_SCOPES:
            raise HTTPException(status_code=400, detail=f"Unknown API key scope: {value}")
        if value in seen:
            continue
        seen.add(value)
        normalized.append(value)
    if not normalized:
        raise HTTPException(status_code=400, detail="At least one valid scope is required")
    return normalized


def _use_local_tier_api_key_format() -> bool:
    enabled = os.environ.get("SKILLGATE_LOCAL_UI_TIER_KEYS", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    env = os.environ.get("SKILLGATE_ENV", "").strip().lower()
    return enabled and env in {"development", "dev", "local"}


async def _resolve_user_tier_for_key(*, user: User, session: AsyncSession) -> str:
    subscription = await session.scalar(
        select(Subscription)
        .where(Subscription.user_id == user.id)
        .order_by(Subscription.updated_at.desc())
    )
    if subscription is not None and subscription.tier:
        return subscription.tier
    return os.environ.get("SKILLGATE_LOCAL_UI_DEFAULT_TIER", "free")


async def _generate_ui_api_key(*, user: User, session: AsyncSession) -> str:
    if _use_local_tier_api_key_format():
        tier = await _resolve_user_tier_for_key(user=user, session=session)
        return generate_tier_api_key(tier)
    return generate_api_key()


@router.post("", response_model=APIKeyCreateResponse)
async def create_api_key(
    req: APIKeyCreateRequest,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> APIKeyCreateResponse:
    """Create and persist a new API key for the authenticated user."""
    normalized_scopes = _normalize_scopes(req.scopes)
    plaintext = await _generate_ui_api_key(user=user, session=session)
    record = APIKey(
        id=str(uuid.uuid4()),
        user_id=user.id,
        name=req.name,
        key_prefix=api_key_prefix(plaintext),
        key_hash=hash_api_key(plaintext),
        scopes=",".join(normalized_scopes),
    )
    session.add(record)
    await session.commit()
    return APIKeyCreateResponse(
        key_id=record.id,
        api_key=plaintext,
        key_prefix=record.key_prefix,
        name=record.name,
        scopes=normalized_scopes,
        created_at=record.created_at.isoformat(),
    )


@router.get("", response_model=APIKeyListResponse)
async def list_api_keys(
    include_revoked: bool = False,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> APIKeyListResponse:
    """List API key metadata for current user."""
    query = select(APIKey).where(APIKey.user_id == user.id)
    if not include_revoked:
        query = query.where(APIKey.revoked.is_(False))
    results = await session.scalars(query)
    keys = [
        APIKeyInfo(
            key_id=row.id,
            key_prefix=row.key_prefix,
            name=row.name,
            scopes=[scope for scope in row.scopes.split(",") if scope],
            revoked=row.revoked,
            created_at=row.created_at.isoformat(),
            last_used_at=row.last_used_at.isoformat() if row.last_used_at else None,
        )
        for row in results.all()
    ]
    return APIKeyListResponse(keys=keys)


@router.post("/{key_id}/revoke")
async def revoke_api_key(
    key_id: str,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> dict[str, str]:
    """Revoke an API key by id for current user."""
    record = await session.scalar(
        select(APIKey).where(APIKey.id == key_id, APIKey.user_id == user.id)
    )
    if record is None:
        raise HTTPException(status_code=404, detail="API key not found")
    if record.revoked:
        raise HTTPException(status_code=409, detail="API key is already revoked")
    record.revoked = True
    record.revoked_at = datetime.now(timezone.utc).replace(tzinfo=None)
    await session.commit()
    return {"status": "revoked", "key_id": key_id}


@router.post("/{key_id}/rotate", response_model=APIKeyCreateResponse)
async def rotate_api_key(
    key_id: str,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> APIKeyCreateResponse:
    """Rotate an API key by revoking old key and issuing a replacement."""
    record = await session.scalar(
        select(APIKey).where(APIKey.id == key_id, APIKey.user_id == user.id)
    )
    if record is None:
        raise HTTPException(status_code=404, detail="API key not found")
    if record.revoked:
        raise HTTPException(status_code=409, detail="API key is already revoked")

    record.revoked = True
    record.revoked_at = datetime.now(timezone.utc).replace(tzinfo=None)

    plaintext = await _generate_ui_api_key(user=user, session=session)
    replacement = APIKey(
        id=str(uuid.uuid4()),
        user_id=user.id,
        name=f"{record.name} (rotated)",
        key_prefix=api_key_prefix(plaintext),
        key_hash=hash_api_key(plaintext),
        scopes=record.scopes,
    )
    session.add(replacement)
    await session.commit()
    return APIKeyCreateResponse(
        key_id=replacement.id,
        api_key=plaintext,
        key_prefix=replacement.key_prefix,
        name=replacement.name,
        scopes=[scope for scope in replacement.scopes.split(",") if scope],
        created_at=replacement.created_at.isoformat(),
    )


@router.post("/verify", response_model=APIKeyVerifyResponse)
async def verify_api_key(
    req: APIKeyVerifyRequest,
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> APIKeyVerifyResponse:
    """Verify a plaintext API key, enforce optional scope, and update last-used metadata."""
    record = await session.scalar(
        select(APIKey).where(APIKey.key_hash == hash_api_key(req.api_key))
    )
    if record is None or record.revoked:
        raise HTTPException(status_code=401, detail="Invalid API key")

    scopes = [scope for scope in record.scopes.split(",") if scope]
    if req.required_scope and req.required_scope not in scopes:
        raise HTTPException(status_code=403, detail="API key scope is not authorized")

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    record.last_used_at = now
    await session.commit()
    return APIKeyVerifyResponse(
        valid=True,
        key_id=record.id,
        key_prefix=record.key_prefix,
        scopes=scopes,
        last_used_at=now.isoformat(),
    )
