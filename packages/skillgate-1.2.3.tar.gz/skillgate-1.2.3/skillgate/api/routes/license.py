"""License validation API endpoints."""

from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel, Field

from skillgate.config.license import Tier, validate_api_key
from skillgate.core.errors import ConfigError

router = APIRouter(prefix="/license", tags=["license"])


class LicenseValidateRequest(BaseModel):
    """Request to validate an API key."""

    api_key: str = Field(min_length=1)


class LicenseValidateResponse(BaseModel):
    """Response from license validation."""

    valid: bool
    tier: str | None = None
    rate_limit: int | None = None


class LicenseInfoResponse(BaseModel):
    """Response with tier information."""

    tiers: list[dict[str, object]]


@router.post("/validate")
async def validate_license(req: LicenseValidateRequest) -> LicenseValidateResponse:
    """Validate an API key and return tier information."""
    try:
        tier = validate_api_key(req.api_key)
    except ConfigError:
        return LicenseValidateResponse(valid=False)

    from skillgate.config.license import get_rate_limit

    return LicenseValidateResponse(
        valid=True,
        tier=tier.value,
        rate_limit=get_rate_limit(tier),
    )


@router.get("/tiers")
async def list_tiers() -> LicenseInfoResponse:
    """List available license tiers and their rate limits."""
    from skillgate.config.license import RATE_LIMITS

    tiers: list[dict[str, object]] = [{"name": t.value, "rate_limit": RATE_LIMITS[t]} for t in Tier]
    return LicenseInfoResponse(tiers=tiers)
