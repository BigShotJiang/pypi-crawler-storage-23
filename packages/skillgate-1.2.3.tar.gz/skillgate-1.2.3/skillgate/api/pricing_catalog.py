"""Backend-managed pricing catalog for web UI consumption."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, Field

PlanAvailability = Literal["yes", "partial", "no"]
TierId = Literal["free", "pro", "team", "enterprise"]
ControlStackLayerId = Literal[
    "static_scan",
    "policy_engine",
    "ci_enforcement",
    "runtime_gateway",
    "capability_budgets",
    "trust_propagation",
    "intelligence_graph",
]


class PricingTier(BaseModel):
    """Pricing tier contract rendered by web UI."""

    id: TierId
    name: str = Field(min_length=1, max_length=32)
    monthly_price: int = Field(ge=0)
    yearly_price: int = Field(ge=0)
    description: str = Field(min_length=1, max_length=180)
    cta: str = Field(min_length=1, max_length=32)
    highlighted: bool
    strategic_label: str | None = Field(default=None, max_length=64)
    narrative: str = Field(min_length=1, max_length=64)
    control_layer_summary: str = Field(min_length=1, max_length=120)
    stack_coverage: list[ControlStackLayerId]
    features: list[str]
    limits: list[str]
    claim_ids: list[str] = Field(default_factory=list)
    annual_contract_only: bool = False


class ControlStackLayer(BaseModel):
    """Control stack layer shown above pricing."""

    id: ControlStackLayerId
    title: str
    description: str


class ComparisonRow(BaseModel):
    """Deep comparison matrix row."""

    id: str
    claim_id: str = Field(min_length=1, max_length=96)
    category: Literal["Static Governance", "CI & Fleet Governance", "Runtime & Org Control Plane"]
    capability: str
    free: PlanAvailability
    pro: PlanAvailability
    team: PlanAvailability
    enterprise: PlanAvailability


class PricingCatalog(BaseModel):
    """Versioned pricing catalog payload."""

    version: str
    updated_at: str
    narrative_variant_default: Literal["control-layer-led", "feature-led"] = "control-layer-led"
    annual_discount_percent: int = Field(default=17, ge=0, le=100)
    beta_free_onboarding_enabled: bool = False
    tiers: list[PricingTier]
    control_stack_layers: list[ControlStackLayer]
    comparison_rows: list[ComparisonRow]


def _flag_enabled(raw: str | None) -> bool:
    if raw is None:
        return False
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def pricing_catalog_payload() -> PricingCatalog:
    """Return canonical backend-managed pricing payload."""
    beta_free_onboarding_enabled = _flag_enabled(os.environ.get("SKILLGATE_PRICING_BETA_FREE_CTA"))
    pro_cta = "Get Started Free" if beta_free_onboarding_enabled else "Start Pro"
    team_cta = "Get Started Free" if beta_free_onboarding_enabled else "Start Team"
    enterprise_cta = "Get Started Free" if beta_free_onboarding_enabled else "Contact Sales"

    return PricingCatalog(
        version="2026-02-19",
        updated_at=datetime.now(timezone.utc).isoformat(),
        beta_free_onboarding_enabled=beta_free_onboarding_enabled,
        tiers=[
            PricingTier(
                id="free",
                name="Free",
                monthly_price=0,
                yearly_price=0,
                description="Get started scanning agent skills for security risks.",
                cta="Get Started Free",
                highlighted=False,
                narrative="Developer visibility",
                control_layer_summary="Static Governance",
                stack_coverage=["static_scan"],
                features=[
                    "3 scans per day",
                    "Basic risk scoring",
                    "Top 5 findings per scan",
                    "Python, JS, TS, Shell analysis",
                    "CLI output (human-readable)",
                ],
                limits=[
                    "No policy enforcement",
                    "No signed attestations",
                    "No CI/CD integration",
                ],
                claim_ids=["CLAIM-FREE-SCAN-QUOTA", "CLAIM-FREE-FINDINGS-CAP"],
            ),
            PricingTier(
                id="pro",
                name="Pro",
                monthly_price=49,
                yearly_price=490,
                description="Full static governance for individual developers and freelancers.",
                cta=pro_cta,
                highlighted=True,
                narrative="Full static governance",
                control_layer_summary="Static Governance + Policy Engine",
                stack_coverage=["static_scan", "policy_engine"],
                features=[
                    "Unlimited scans",
                    "All 7 languages (+ Go, Rust, Ruby)",
                    "119 detection rules",
                    "Markdown-first and multi-artifact detection",
                    "Full risk scoring with severity + confidence breakdown",
                    "Policy customization (YAML)",
                    "Ed25519 signed attestation reports",
                    "Static capability modeling and simulation",
                    "JSON + SARIF output formats",
                    "Email support",
                ],
                limits=["No CI/CD PR blocking"],
                claim_ids=["CLAIM-PRO-POLICY-ENFORCEMENT", "CLAIM-PRO-SIGNED-ATTESTATIONS"],
            ),
            PricingTier(
                id="team",
                name="Team",
                monthly_price=99,
                yearly_price=990,
                description="CI enforcement and fleet governance for engineering teams.",
                cta=team_cta,
                highlighted=False,
                narrative="Engineering team governance",
                control_layer_summary="Static + Policy + CI + Fleet Governance",
                stack_coverage=["static_scan", "policy_engine", "ci_enforcement"],
                features=[
                    "Everything in Pro",
                    "Fleet-wide scan governance",
                    "Multi-skill governance with deterministic summaries",
                    "GitHub Action PR blocking",
                    "GitLab CI / Bitbucket Pipelines",
                    "Low-noise deterministic PR annotations",
                    "SARIF upload to GitHub Security tab",
                    "Org policy presets and drift detection",
                    "Central team dashboard",
                    "Slack/webhook alerts",
                    "Org risk posture summary",
                    "Up to 15 seats",
                    "Priority support",
                ],
                limits=["No dedicated signing keys"],
                claim_ids=["CLAIM-TEAM-SEAT-LIMIT", "CLAIM-TEAM-CI-BLOCKING", "CLAIM-TEAM-FLEET"],
            ),
            PricingTier(
                id="enterprise",
                name="Enterprise",
                monthly_price=0,
                yearly_price=10000,
                description="AI agent control plane for regulated enterprise execution.",
                cta=enterprise_cta,
                highlighted=False,
                strategic_label="AI Agent Control Plane",
                narrative="Foundational governance infrastructure",
                control_layer_summary="Full Control Stack",
                stack_coverage=[
                    "static_scan",
                    "policy_engine",
                    "ci_enforcement",
                    "runtime_gateway",
                    "capability_budgets",
                    "trust_propagation",
                    "intelligence_graph",
                ],
                features=[
                    "Everything in Team + regulated runtime governance controls",
                    "Runtime capability budgets",
                    "Transitive risk & trust propagation graph",
                    "Signed AI-BOM with cryptographic provenance",
                    "Org-wide policy simulation and rollout modeling",
                    "Private relay and air-gapped deployment modes",
                    "Signed reputation graph integration",
                    "Authoritative entitlement APIs and decision logs",
                    "Audit-grade export bundles",
                    "Control-mapping evidence (EU AI Act, SOC 2, internal controls)",
                    "Unlimited seats",
                    "On-prem and hybrid entitlement enforcement",
                    "Dedicated support engineer",
                    "Custom SLAs",
                ],
                limits=[],
                claim_ids=["CLAIM-ENTERPRISE-AUDIT-EXPORT", "CLAIM-ENTERPRISE-AIRGAP-RELAY"],
                annual_contract_only=True,
            ),
        ],
        control_stack_layers=[
            ControlStackLayer(
                id="static_scan",
                title="Static Scan",
                description=(
                    "Deterministic static risk detection across skills, code, and "
                    "markdown artifacts."
                ),
            ),
            ControlStackLayer(
                id="policy_engine",
                title="Policy Engine",
                description="Policy-as-code thresholds and configurable governance gates.",
            ),
            ControlStackLayer(
                id="ci_enforcement",
                title="CI Enforcement",
                description="PR blocking and low-noise annotations in CI/CD workflows.",
            ),
            ControlStackLayer(
                id="runtime_gateway",
                title="Runtime Gateway",
                description="Pre-execution runtime controls for agent tool invocations.",
            ),
            ControlStackLayer(
                id="capability_budgets",
                title="Capability Budgets",
                description="Hard budgets for shell, network, filesystem, and external domain use.",
            ),
            ControlStackLayer(
                id="trust_propagation",
                title="Trust Propagation",
                description="Signed lineage DAG and transitive privilege/risk modeling.",
            ),
            ControlStackLayer(
                id="intelligence_graph",
                title="Intelligence Graph",
                description=(
                    "Signed reputation graph integration and organization-level intelligence."
                ),
            ),
        ],
        comparison_rows=[
            ComparisonRow(
                id="static-baseline",
                claim_id="CLAIM-STATIC-BASELINE",
                category="Static Governance",
                capability="Static governance baseline scans",
                free="yes",
                pro="yes",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="policy-customization",
                claim_id="CLAIM-POLICY-CUSTOMIZATION",
                category="Static Governance",
                capability="Policy-as-code customization",
                free="no",
                pro="yes",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="signed-attestations",
                claim_id="CLAIM-SIGNED-ATTESTATIONS",
                category="Static Governance",
                capability="Signed attestations and verification",
                free="no",
                pro="yes",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="fleet-scan",
                claim_id="CLAIM-FLEET-SCAN",
                category="CI & Fleet Governance",
                capability="Fleet-wide scan governance across multiple skills and repositories",
                free="no",
                pro="no",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="ci-pr-blocking",
                claim_id="CLAIM-CI-PR-BLOCKING",
                category="CI & Fleet Governance",
                capability="CI/CD PR blocking and deterministic annotations",
                free="no",
                pro="no",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="org-risk-posture",
                claim_id="CLAIM-ORG-RISK-POSTURE",
                category="CI & Fleet Governance",
                capability="Org risk posture summaries and drift controls",
                free="no",
                pro="no",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="runtime-capability-budgets",
                claim_id="CLAIM-RUNTIME-CAPABILITY-BUDGETS",
                category="Runtime & Org Control Plane",
                capability="Runtime capability budgets",
                free="no",
                pro="no",
                team="no",
                enterprise="yes",
            ),
            ComparisonRow(
                id="transitive-risk-graph",
                claim_id="CLAIM-TRANSITIVE-RISK-GRAPH",
                category="Runtime & Org Control Plane",
                capability="Transitive risk and trust propagation graph",
                free="no",
                pro="no",
                team="no",
                enterprise="yes",
            ),
            ComparisonRow(
                id="policy-simulation",
                claim_id="CLAIM-POLICY-SIMULATION",
                category="Runtime & Org Control Plane",
                capability="Org-scale policy simulation and rollout modeling",
                free="no",
                pro="no",
                team="yes",
                enterprise="yes",
            ),
            ComparisonRow(
                id="airgap-private-relay",
                claim_id="CLAIM-AIRGAP-PRIVATE-RELAY",
                category="Runtime & Org Control Plane",
                capability="Private relay and air-gapped enforcement modes",
                free="no",
                pro="no",
                team="no",
                enterprise="yes",
            ),
            ComparisonRow(
                id="governance-api-audit",
                claim_id="CLAIM-GOVERNANCE-API-AUDIT",
                category="Runtime & Org Control Plane",
                capability="Audit-grade export bundles and control-mapping evidence workflows",
                free="no",
                pro="no",
                team="no",
                enterprise="yes",
            ),
        ],
    )
