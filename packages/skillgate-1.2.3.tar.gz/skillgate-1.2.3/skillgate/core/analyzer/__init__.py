"""Static analysis engine."""

from skillgate.core.analyzer.correlation import CorrelationResult, correlate_manifest_vs_content
from skillgate.core.analyzer.engine import analyze_bundle, deduplicate_findings
from skillgate.core.analyzer.perf_guard import (
    MAX_ANALYSIS_FILE_BYTES,
    ExtractionBudget,
    ScanTimer,
    should_skip_large_file,
    truncate_lines_for_analysis,
)
from skillgate.core.analyzer.unicode_normalizer import (
    NormalisationResult,
    fold_confusables,
    has_bidi_overrides,
    normalise_for_analysis,
)

__all__ = [
    "analyze_bundle",
    "deduplicate_findings",
    "CorrelationResult",
    "correlate_manifest_vs_content",
    "ExtractionBudget",
    "MAX_ANALYSIS_FILE_BYTES",
    "ScanTimer",
    "should_skip_large_file",
    "truncate_lines_for_analysis",
    "NormalisationResult",
    "fold_confusables",
    "has_bidi_overrides",
    "normalise_for_analysis",
]
