"""Cross-artifact correlation engine for permission mismatch detection.

Correlates declared manifest permissions with behaviors found in markdown
instructions, fenced code snippets, and config artifacts. Emits
CorrelationFinding entries when behaviors exceed declared permissions or
policy constraints.

This is deterministic and offline — no network calls.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field

from skillgate.core.models.artifact import ArtifactProvenance
from skillgate.core.models.bundle import SkillManifest, SourceFile
from skillgate.core.models.enums import Category, Severity
from skillgate.core.models.finding import Finding

# ---------------------------------------------------------------------------
# Correlation rules: patterns that indicate a specific permission is needed
# ---------------------------------------------------------------------------
_SHELL_PATTERNS = [
    re.compile(r"\bsubprocess\b|\bos\.system\b|\bos\.popen\b|\bpexpect\b", re.IGNORECASE),
    re.compile(r"\bcurl\b|\bwget\b|\bnc\b|\bnetcat\b", re.IGNORECASE),
    re.compile(r"\bchmod\b|\bchown\b|\bsudo\b|\bsu\b", re.IGNORECASE),
    re.compile(r"run the following command|execute this command", re.IGNORECASE),
]

_EVAL_PATTERNS = [
    re.compile(r"\beval\b|\bexec\b|\bFunction\(|new Function", re.IGNORECASE),
    re.compile(r"\bimportlib\b|\b__import__\b|\bplugin\.Open\b", re.IGNORECASE),
]

_NETWORK_PATTERNS = [
    re.compile(r"https?://|socket\.connect|net\.Dial|TcpStream|fetch\(", re.IGNORECASE),
    re.compile(r"\bhttpx\b|\brequests\b|\baiohttp\b|\burllib\b", re.IGNORECASE),
    re.compile(r"\bSMTP\b|\bFTP\b|\btelnet\b|\bWebSocket\b", re.IGNORECASE),
]

_FILE_WRITE_PATTERNS = [
    re.compile(r"open\(.+['\"]w['\"]|\bwrite_text\b|\bwritelines\b", re.IGNORECASE),
    re.compile(r"\bshutil\.copy\b|\bshutil\.move\b|\bos\.rename\b", re.IGNORECASE),
    re.compile(r"\bFile\.write\b|\bFile\.open\b|\bfs\.write\b", re.IGNORECASE),
]

_CREDENTIAL_PATTERNS = [
    re.compile(
        r"\bapi[_-]?key\b|\bpassword\b|\btoken\b|\bsecret\b|credentials",
        re.IGNORECASE,
    ),
    re.compile(r"\bAKIA[A-Z0-9]{16}\b|\bsk_live_\w+\b|\bghp_\w+\b"),
]


@dataclass
class CorrelationResult:
    """Results from cross-artifact correlation analysis."""

    findings: list[Finding] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _check_permission_declared(
    declared: list[str],
    permission_key: str,
    alternative_keys: Sequence[str] = (),
) -> bool:
    """Check if a permission keyword is declared in the manifest.

    Args:
        declared: List of declared permission strings.
        permission_key: Primary key to look for.
        alternative_keys: Alternative/synonym keys.

    Returns:
        True if any matching permission was declared.
    """
    all_keys = [permission_key, *alternative_keys]
    for perm in declared:
        perm_lower = perm.lower()
        if any(key in perm_lower for key in all_keys):
            return True
    return False


def _make_correlation_finding(
    file: str,
    line: int,
    snippet: str,
    rule_id: str,
    rule_name: str,
    severity: Severity,
    message: str,
    provenance: ArtifactProvenance | None = None,
) -> Finding:
    """Create a correlation finding."""
    return Finding(
        rule_id=rule_id,
        rule_name=rule_name,
        severity=severity,
        category=Category.CONFIG,  # Correlation findings belong to config governance
        message=message,
        file=file,
        line=line,
        column=None,
        snippet=snippet,
        weight=12,
        remediation="Declare the required permission in SKILL.md or skill.json manifest.",
        provenance=provenance,
    )


def correlate_manifest_vs_content(
    manifest: SkillManifest,
    source_files: list[SourceFile],
) -> CorrelationResult:
    """Correlate manifest permissions against observed behaviors in source files.

    Detects permission mismatches — behaviors in code/prose/config that aren't
    declared in the manifest. This is a best-effort heuristic scan.

    Args:
        manifest: Parsed skill manifest with declared_permissions.
        source_files: All source files to analyze.

    Returns:
        CorrelationResult with permission-mismatch findings.
    """
    result = CorrelationResult()
    declared = [p.lower() for p in manifest.declared_permissions]

    # Track which correlations we've already flagged per file to avoid flooding
    flagged: set[tuple[str, str]] = set()

    for source in source_files:
        _correlate_file(source, declared, result, flagged)

    return result


def _correlate_file(
    source: SourceFile,
    declared: list[str],
    result: CorrelationResult,
    flagged: set[tuple[str, str]],
) -> None:
    """Correlate a single source file against declared permissions.

    Args:
        source: The source file to check.
        declared: Lowercase declared permissions from manifest.
        result: Accumulates findings.
        flagged: Set of (file, permission) pairs already flagged.
    """
    shell_declared = _check_permission_declared(
        declared, "shell", ["exec", "subprocess", "command"]
    )
    eval_declared = _check_permission_declared(declared, "eval", ["exec", "dynamic"])
    network_declared = _check_permission_declared(declared, "network", ["http", "internet", "web"])
    fs_write_declared = _check_permission_declared(
        declared, "filesystem", ["file", "write", "disk"]
    )
    cred_declared = _check_permission_declared(declared, "credential", ["secret", "api", "token"])

    checks = [
        (
            _SHELL_PATTERNS,
            shell_declared,
            "shell",
            "SG-CORR-001",
            "Undeclared Shell Access",
            Severity.HIGH,
            "File contains shell/command execution patterns but 'shell' is not declared "
            "in manifest.permissions.",
        ),
        (
            _EVAL_PATTERNS,
            eval_declared,
            "eval",
            "SG-CORR-002",
            "Undeclared Code Evaluation",
            Severity.HIGH,
            "File contains eval/exec patterns but 'eval' is not declared in manifest.permissions.",
        ),
        (
            _NETWORK_PATTERNS,
            network_declared,
            "network",
            "SG-CORR-003",
            "Undeclared Network Access",
            Severity.MEDIUM,
            "File contains network access patterns but 'network' is not declared "
            "in manifest.permissions.",
        ),
        (
            _FILE_WRITE_PATTERNS,
            fs_write_declared,
            "filesystem",
            "SG-CORR-004",
            "Undeclared Filesystem Write",
            Severity.MEDIUM,
            "File contains file write patterns but 'filesystem' is not declared "
            "in manifest.permissions.",
        ),
        (
            _CREDENTIAL_PATTERNS,
            cred_declared,
            "credential",
            "SG-CORR-005",
            "Undeclared Credential Access",
            Severity.MEDIUM,
            "File contains credential/secret patterns but 'credential' is not declared "
            "in manifest.permissions.",
        ),
    ]

    for patterns, is_declared, perm_key, rule_id, rule_name, severity, base_message in checks:
        if is_declared:
            continue  # Permission is declared; no mismatch

        flag_key = (source.path, perm_key)
        if flag_key in flagged:
            continue

        for line_num, line_text in enumerate(source.lines, start=1):
            stripped = line_text.strip()
            # Skip comment lines
            if stripped.startswith("#") or stripped.startswith("//"):
                continue

            match_found = any(p.search(line_text) for p in patterns)
            if match_found:
                flagged.add(flag_key)
                result.findings.append(
                    _make_correlation_finding(
                        file=source.path,
                        line=line_num,
                        snippet=line_text,
                        rule_id=rule_id,
                        rule_name=rule_name,
                        severity=severity,
                        message=base_message,
                    )
                )
                break  # One finding per file per permission category
