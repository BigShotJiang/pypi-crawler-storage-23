"""Detection rule registry."""

from __future__ import annotations

from skillgate.core.analyzer.rules.base import Rule
from skillgate.core.analyzer.rules.command import ALL_COMMAND_RULES
from skillgate.core.analyzer.rules.config import ALL_CONFIG_RULES
from skillgate.core.analyzer.rules.credential import CREDENTIAL_RULES
from skillgate.core.analyzer.rules.eval import EVAL_RULES
from skillgate.core.analyzer.rules.filesystem import FILESYSTEM_RULES
from skillgate.core.analyzer.rules.go import GO_RULES
from skillgate.core.analyzer.rules.injection import INJECTION_RULES
from skillgate.core.analyzer.rules.js_ast import JS_AST_RULES
from skillgate.core.analyzer.rules.network import NETWORK_RULES
from skillgate.core.analyzer.rules.obfuscation import OBFUSCATION_RULES
from skillgate.core.analyzer.rules.prompt import ALL_PROMPT_RULES
from skillgate.core.analyzer.rules.ruby import RUBY_RULES
from skillgate.core.analyzer.rules.rust import RUST_RULES
from skillgate.core.analyzer.rules.shell import SHELL_RULES
from skillgate.core.analyzer.rules.shell_ast import SHELL_AST_RULES

ALL_RULE_CLASSES: list[type[Rule]] = [
    *SHELL_RULES,
    *NETWORK_RULES,
    *FILESYSTEM_RULES,
    *EVAL_RULES,
    *CREDENTIAL_RULES,
    *INJECTION_RULES,
    *OBFUSCATION_RULES,
    *GO_RULES,
    *RUST_RULES,
    *RUBY_RULES,
    *JS_AST_RULES,
    *SHELL_AST_RULES,
    *ALL_PROMPT_RULES,
    *ALL_COMMAND_RULES,
    *ALL_CONFIG_RULES,
]


def get_all_rules(disabled: list[str] | None = None) -> list[Rule]:
    """Instantiate all registered rules, excluding disabled ones.

    Args:
        disabled: List of rule IDs to exclude.

    Returns:
        List of instantiated Rule objects.
    """
    disabled_set = set(disabled) if disabled else set()
    rules: list[Rule] = []
    for rule_cls in ALL_RULE_CLASSES:
        instance = rule_cls()
        if instance.id not in disabled_set:
            rules.append(instance)
    return rules


__all__ = ["ALL_RULE_CLASSES", "Rule", "get_all_rules"]
