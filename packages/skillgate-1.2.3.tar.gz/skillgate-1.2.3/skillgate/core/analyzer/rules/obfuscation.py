"""Obfuscation detection rules (SG-OBF-001 through SG-OBF-005)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule, Rule
from skillgate.core.models.bundle import SourceFile
from skillgate.core.models.enums import Category, Severity
from skillgate.core.models.finding import Finding


class Base64PayloadRule(RegexRule):
    """SG-OBF-001: Detect base64-encoded payloads >50 chars."""

    id = "SG-OBF-001"
    name = "base64_payload"
    description = "Possible base64-encoded payload detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.OBFUSCATION
    patterns = [
        (
            re.compile(
                r"""\b(atob|btoa|base64\.(b64decode|b64encode|decodebytes)|"""
                r"""Buffer\.from)\s*\("""
            ),
            "Base64 encoding/decoding operation detected: {match}",
            "Review base64 operations for hidden payloads. Encoded content should be documented.",
        ),
        (
            re.compile(r"""['"][A-Za-z0-9+/]{50,}={0,2}['"]"""),
            "Long base64-like string detected: {match}",
            "Long encoded strings may hide malicious payloads. Document their purpose.",
        ),
    ]


class CharCodeConcatRule(RegexRule):
    """SG-OBF-002: Detect character code obfuscation."""

    id = "SG-OBF-002"
    name = "char_code_concat"
    description = "Character code obfuscation detected"
    severity = Severity.HIGH
    weight = 45
    category = Category.OBFUSCATION
    patterns = [
        (
            re.compile(r"""(?:chr\s*\(\s*\d+\s*\)\s*\+?\s*){3,}"""),
            "Python chr() chain detected: {match}",
            "Avoid chr() chains for string construction. Use plain strings.",
        ),
        (
            re.compile(r"""(?:String\.fromCharCode\s*\(\s*\d+\s*\)\s*\+?\s*){3,}"""),
            "JavaScript String.fromCharCode() chain detected: {match}",
            "Avoid fromCharCode() chains. Use plain strings.",
        ),
    ]


class HexEncodingRule(RegexRule):
    """SG-OBF-003: Detect hex-encoded string sequences."""

    id = "SG-OBF-003"
    name = "hex_encoding"
    description = "Hex-encoded content detected"
    severity = Severity.MEDIUM
    weight = 30
    category = Category.OBFUSCATION
    patterns = [
        (
            re.compile(r"""(?:\\x[0-9a-fA-F]{2}){8,}"""),
            "Long hex-encoded sequence detected: {match}",
            "Review hex-encoded content. It may hide malicious payloads.",
        ),
        (
            re.compile(r"""\bbytes\.fromhex\s*\(\s*['"][0-9a-fA-F]{16,}"""),
            "Hex bytes conversion detected: {match}",
            "Review hex-to-bytes conversion for hidden payloads.",
        ),
    ]


class StringReversalRule(RegexRule):
    """SG-OBF-004: Detect string reversal obfuscation."""

    id = "SG-OBF-004"
    name = "string_reversal"
    description = "String reversal obfuscation detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.OBFUSCATION
    patterns = [
        (
            re.compile(r"""\[::\s*-1\s*\]"""),
            "String reversal pattern detected: {match}",
            "Review reversed strings. They may decode to malicious commands.",
        ),
        (
            re.compile(r"""\.split\s*\(\s*['"]['"]?\s*\)\s*\.reverse\s*\(\s*\)\s*\.join"""),
            "JavaScript string reversal detected: {match}",
            "Review reversed strings for hidden commands.",
        ),
    ]


class MinifiedPayloadRule(Rule):
    """SG-OBF-005: Detect suspiciously minified single-line code."""

    id = "SG-OBF-005"
    name = "minified_payload"
    description = "Possible minified malicious code detected"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.OBFUSCATION

    def analyze(self, source: SourceFile) -> list[Finding]:
        """Detect lines >500 chars with no whitespace (excluding imports/comments)."""
        findings: list[Finding] = []
        for line_num, line in enumerate(source.lines, start=1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("//"):
                continue
            if stripped.startswith("import ") or stripped.startswith("from "):
                continue
            if len(stripped) > 500 and stripped.count(" ") < 5:
                findings.append(
                    self._make_finding(
                        source,
                        line_num,
                        f"Suspiciously long line ({len(stripped)} chars) with minimal whitespace",
                        remediation="Minified code is suspicious in skill bundles. "
                        "Format the code for readability.",
                    )
                )
        return findings


OBFUSCATION_RULES: list[type[Rule]] = [
    Base64PayloadRule,
    CharCodeConcatRule,
    HexEncodingRule,
    StringReversalRule,
    MinifiedPayloadRule,
]
