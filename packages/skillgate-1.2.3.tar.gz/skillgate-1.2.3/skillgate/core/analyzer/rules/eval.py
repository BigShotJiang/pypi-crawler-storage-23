"""Dynamic evaluation detection rules (SG-EVAL-001 through SG-EVAL-006)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class PythonEvalRule(RegexRule):
    """SG-EVAL-001: Detect Python eval() usage."""

    id = "SG-EVAL-001"
    name = "python_eval"
    description = "Python eval() detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    patterns = [
        (
            re.compile(r"\beval\s*\("),
            "Python eval() detected: {match}",
            "Never use eval() with untrusted input. Use ast.literal_eval() for safe parsing.",
        ),
    ]


class PythonExecRule(RegexRule):
    """SG-EVAL-002: Detect Python exec() usage."""

    id = "SG-EVAL-002"
    name = "python_exec"
    description = "Python exec() detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    patterns = [
        (
            re.compile(r"\bexec\s*\("),
            "Python exec() detected: {match}",
            "Never use exec() with untrusted input. Find a safer alternative.",
        ),
    ]


class JsEvalRule(RegexRule):
    """SG-EVAL-003: Detect JavaScript eval() usage."""

    id = "SG-EVAL-003"
    name = "js_eval"
    description = "JavaScript eval() detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    patterns = [
        (
            re.compile(r"\beval\s*\("),
            "JavaScript eval() detected: {match}",
            "Never use eval(). Use JSON.parse() for data or safer alternatives.",
        ),
    ]


class JsFunctionRule(RegexRule):
    """SG-EVAL-004: Detect dynamic Function() constructor."""

    id = "SG-EVAL-004"
    name = "js_function"
    description = "Dynamic function creation via new Function()"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    patterns = [
        (
            re.compile(r"\bnew\s+Function\s*\("),
            "Dynamic Function constructor detected: {match}",
            "Avoid new Function(). It is equivalent to eval() and executes arbitrary code.",
        ),
    ]


class CompileRule(RegexRule):
    """SG-EVAL-005: Detect Python compile() usage."""

    id = "SG-EVAL-005"
    name = "compile"
    description = "Python compile() detected"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    patterns = [
        (
            re.compile(r"\bcompile\s*\(\s*['\"]"),
            "Python compile() with string argument detected: {match}",
            "Avoid compile() with dynamic strings. It can be used to execute arbitrary code.",
        ),
    ]


class ImportlibRule(RegexRule):
    """SG-EVAL-006: Detect dynamic imports via importlib."""

    id = "SG-EVAL-006"
    name = "importlib"
    description = "Dynamic import via importlib detected"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.EVAL
    patterns = [
        (
            re.compile(r"\bimportlib\.import_module\s*\("),
            "Dynamic import detected: {match}",
            "Avoid dynamic imports. Use static imports to make dependencies explicit.",
        ),
        (
            re.compile(r"\b__import__\s*\("),
            "Dynamic import via __import__() detected: {match}",
            "Avoid __import__(). Use static imports instead.",
        ),
    ]


EVAL_RULES: list[type[RegexRule]] = [
    PythonEvalRule,
    PythonExecRule,
    JsEvalRule,
    JsFunctionRule,
    CompileRule,
    ImportlibRule,
]
