"""Injection detection rules (SG-INJ-001 through SG-INJ-004)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class PromptOverrideRule(RegexRule):
    """SG-INJ-001: Detect prompt injection/override patterns."""

    id = "SG-INJ-001"
    name = "prompt_override"
    description = "Prompt injection attempt detected"
    severity = Severity.HIGH
    weight = 30
    category = Category.INJECTION
    patterns = [
        (
            re.compile(
                r"""(ignore\s+(previous|all)\s+instructions|"""
                r"""system\s*:\s*you\s+are|"""
                r"""<\|im_start\|>system|"""
                r"""OVERRIDE_SYSTEM_PROMPT)""",
                re.IGNORECASE,
            ),
            "Prompt injection pattern detected: {match}",
            "Remove prompt manipulation strings. Skills should not override system prompts.",
        ),
    ]


class CommandInjectionRule(RegexRule):
    """SG-INJ-002: Detect command injection via string concatenation."""

    id = "SG-INJ-002"
    name = "command_injection"
    description = "Command injection vector detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.INJECTION
    patterns = [
        (
            re.compile(r"""\bos\.system\s*\(\s*['"].*\+"""),
            "Command injection via string concatenation in os.system(): {match}",
            "Never concatenate strings into shell commands. Use subprocess with argument lists.",
        ),
        (
            re.compile(r"""\bos\.system\s*\(\s*f['"]"""),
            "Command injection via f-string in os.system(): {match}",
            "Never use f-strings in shell commands. Use subprocess with argument lists.",
        ),
        (
            re.compile(r"""\bsubprocess\.\w+\s*\(\s*f['"]"""),
            "Command injection via f-string in subprocess: {match}",
            "Never use f-strings as subprocess commands. Pass arguments as a list.",
        ),
    ]


class SqlInjectionRule(RegexRule):
    """SG-INJ-003: Detect SQL injection via string concatenation."""

    id = "SG-INJ-003"
    name = "sql_injection"
    description = "SQL injection vector detected"
    severity = Severity.HIGH
    weight = 35
    category = Category.INJECTION
    patterns = [
        (
            re.compile(
                r"""(?:execute|cursor\.execute)\s*\(\s*f['"].*(?:SELECT|INSERT|UPDATE|DELETE|DROP)""",
                re.IGNORECASE,
            ),
            "SQL injection via f-string detected: {match}",
            "Use parameterized queries. Never concatenate user input into SQL strings.",
        ),
        (
            re.compile(
                r"""(?:execute|cursor\.execute)\s*\(\s*['"].*%s.*['"].*%""",
            ),
            "Unsafe SQL string formatting detected: {match}",
            "Use parameterized queries with ? or :param placeholders.",
        ),
    ]


class TemplateInjectionRule(RegexRule):
    """SG-INJ-004: Detect template injection patterns."""

    id = "SG-INJ-004"
    name = "template_injection"
    description = "Template injection vector detected"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.INJECTION
    patterns = [
        (
            re.compile(r"""\brender_template_string\s*\("""),
            "Server-side template injection vector detected: {match}",
            "Avoid render_template_string() with user input. Use render_template() with files.",
        ),
        (
            re.compile(r"""\bTemplate\s*\(\s*[^'"]"""),
            "Dynamic template creation detected: {match}",
            "Avoid creating templates from dynamic strings. Use pre-defined template files.",
        ),
    ]


INJECTION_RULES: list[type[RegexRule]] = [
    PromptOverrideRule,
    CommandInjectionRule,
    SqlInjectionRule,
    TemplateInjectionRule,
]
