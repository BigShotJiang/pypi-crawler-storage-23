"""Configuration file security detection rules."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class ConfigHardcodedSecret(RegexRule):
    """SG-CONFIG-001: Hardcoded secrets in config files."""

    id = "SG-CONFIG-001"
    name = "Hardcoded Secret in Config"
    description = "Hardcoded API key, password, or token in configuration"
    severity = Severity.CRITICAL
    weight = 20
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(password|passwd|pwd|secret|api[_-]?key|auth[_-]?token|private[_-]?key)"
                r"['\"]*\s*[:=]\s*['\"]*[a-zA-Z0-9_\-]{8,}",
                re.IGNORECASE,
            ),
            "Hardcoded secret detected: '{match}'",
            "Use environment variables or secret management for credentials.",
        ),
        (
            re.compile(
                r"(aws[_-]?secret|stripe[_-]?key|openai[_-]?key|github[_-]?token)"
                r"['\"]*\s*[:=]\s*['\"]*[a-zA-Z0-9_\-]{16,}",
                re.IGNORECASE,
            ),
            "Hardcoded vendor credential: '{match}'",
            "Store vendor credentials in secure vaults or environment variables.",
        ),
    ]


class ConfigInsecureDefaults(RegexRule):
    """SG-CONFIG-002: Insecure default configurations."""

    id = "SG-CONFIG-002"
    name = "Insecure Default Configuration"
    description = "Insecure default setting (debug mode, weak encryption, public access)"
    severity = Severity.HIGH
    weight = 15
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(debug|DEBUG)\s*[:=]\s*(true|True|1|yes)",
                re.IGNORECASE,
            ),
            "Debug mode enabled by default: '{match}'",
            "Debug mode should be disabled in production; use env-based toggle.",
        ),
        (
            re.compile(
                r"(verify[_-]?ssl|ssl[_-]?verify|tls[_-]?verify)\s*[:=]\s*(false|False|0|no)",
                re.IGNORECASE,
            ),
            "SSL/TLS verification disabled: '{match}'",
            "Disabling SSL verification is insecure; enable certificate validation.",
        ),
        (
            re.compile(
                r"(allow[_-]?all|public[_-]?access)\s*[:=]\s*(true|True|1|yes)",
                re.IGNORECASE,
            ),
            "Public access enabled by default: '{match}'",
            "Default to restricted access; enable public access explicitly if needed.",
        ),
    ]


class ConfigWeakEncryption(RegexRule):
    """SG-CONFIG-003: Weak encryption algorithms or key sizes."""

    id = "SG-CONFIG-003"
    name = "Weak Encryption Configuration"
    description = "Weak encryption algorithm or key size configured"
    severity = Severity.HIGH
    weight = 14
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(algorithm|cipher|encryption)\s*[:=]\s*['\"]?(MD5|SHA1|DES|RC4)['\"]?",
                re.IGNORECASE,
            ),
            "Weak encryption algorithm: '{match}'",
            "Use modern algorithms: SHA-256+, AES-256, ChaCha20, etc.",
        ),
        (
            re.compile(
                r"(key[_-]?size|keysize)\s*[:=]\s*(512|1024)",
            ),
            "Weak encryption key size: '{match}'",
            "Use minimum 2048-bit keys for RSA; prefer 4096-bit or modern curves like Ed25519.",
        ),
    ]


class ConfigUnrestrictedCORS(RegexRule):
    """SG-CONFIG-004: Unrestricted CORS configuration."""

    id = "SG-CONFIG-004"
    name = "Unrestricted CORS"
    description = "CORS configured with wildcard origin or credentials allowed from any origin"
    severity = Severity.HIGH
    weight = 15
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(Access-Control-Allow-Origin|allow[_-]?origin)\s*[:=]\s*['\"]?\*['\"]?",
            ),
            "CORS wildcard origin: '{match}'",
            "Scope CORS to specific trusted origins; avoid wildcard (*).",
        ),
        (
            re.compile(
                r"(Access-Control-Allow-Credentials|allow[_-]?credentials)\s*[:=]\s*(true|True)",
            ),
            "CORS credentials allowed: '{match}'",
            "Allowing credentials with wildcards is unsafe; restrict origins.",
        ),
    ]


class ConfigDatabasePublicExpose(RegexRule):
    """SG-CONFIG-005: Database exposed on public interface."""

    id = "SG-CONFIG-005"
    name = "Database Public Exposure"
    description = "Database configured to listen on public interface (0.0.0.0 or external IP)"
    severity = Severity.CRITICAL
    weight = 18
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(bind|host|listen)[_a-z]*\s*[:=]\s*['\"]?(0\.0\.0\.0|::)['\"]?",
            ),
            "Database bound to public interface: '{match}'",
            "Bind databases to localhost (127.0.0.1) or private network only.",
        )
    ]


class ConfigDefaultCredentials(RegexRule):
    """SG-CONFIG-006: Default or placeholder credentials."""

    id = "SG-CONFIG-006"
    name = "Default Credentials"
    description = "Default or placeholder username/password in config"
    severity = Severity.CRITICAL
    weight = 18
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(username|user)\s*[:=]\s*['\"]?(admin|root|administrator|user)['\"]?",
                re.IGNORECASE,
            ),
            "Default username: '{match}'",
            "Avoid default usernames like 'admin' or 'root'; use unique identifiers.",
        ),
        (
            re.compile(
                r"(password|passwd)\s*[:=]\s*['\"]?(password|admin|123456|changeme|secret)['\"]?",
                re.IGNORECASE,
            ),
            "Default/weak password: '{match}'",
            "Never use default passwords; generate strong unique credentials.",
        ),
    ]


class ConfigLoggingSensitiveData(RegexRule):
    """SG-CONFIG-007: Logging sensitive data enabled."""

    id = "SG-CONFIG-007"
    name = "Sensitive Data Logging"
    description = "Configuration enables logging of sensitive data (passwords, tokens, PII)"
    severity = Severity.MEDIUM
    weight = 10
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(log[_-]?(passwords?|secrets?|tokens?|keys?)|include[_-]?sensitive)\s*[:=]\s*(true|True|1|yes)",
                re.IGNORECASE,
            ),
            "Sensitive data logging enabled: '{match}'",
            "Disable logging of passwords, tokens, and PII; redact sensitive fields.",
        )
    ]


class ConfigRateLimitDisabled(RegexRule):
    """SG-CONFIG-008: Rate limiting disabled or set too high."""

    id = "SG-CONFIG-008"
    name = "Rate Limiting Disabled"
    description = "Rate limiting disabled or set to unsafe high value"
    severity = Severity.MEDIUM
    weight = 10
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(rate[_-]?limit|request[_-]?limit)\s*[:=]\s*(false|False|0|disabled)",
                re.IGNORECASE,
            ),
            "Rate limiting disabled: '{match}'",
            "Enable rate limiting to prevent abuse and DoS attacks.",
        ),
        (
            re.compile(
                r"(rate[_-]?limit|request[_-]?limit)\s*[:=]\s*([1-9]\d{4,})",  # >= 10000
            ),
            "Rate limit set very high: '{match}'",
            "Review rate limit value; extremely high limits may not prevent abuse.",
        ),
    ]


class ConfigSessionTimeoutInsecure(RegexRule):
    """SG-CONFIG-009: Insecure session timeout (too long or disabled)."""

    id = "SG-CONFIG-009"
    name = "Insecure Session Timeout"
    description = "Session timeout disabled or set too long (security risk)"
    severity = Severity.MEDIUM
    weight = 8
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(session[_-]?timeout|idle[_-]?timeout)\s*[:=]\s*0",
            ),
            "Session timeout disabled: '{match}'",
            "Always set session timeouts; use 15-30 minutes for sensitive apps.",
        ),
        (
            # >= 50000 seconds (~14 hours)
            re.compile(
                r"(session[_-]?timeout|idle[_-]?timeout)\s*[:=]\s*([5-9]\d{4,})",
            ),
            "Session timeout very long: '{match}'",
            "Session timeouts over 1-2 hours increase session hijack risk.",
        ),
    ]


class ConfigUnsafeFilePermissions(RegexRule):
    """SG-CONFIG-010: Unsafe file permission settings."""

    id = "SG-CONFIG-010"
    name = "Unsafe File Permissions"
    description = "File permissions set to world-readable/writable"
    severity = Severity.HIGH
    weight = 12
    category = Category.CONFIG
    patterns = [
        (
            re.compile(
                r"(permissions?|mode|chmod)\s+['\"]?(777|666|755)['\"]?",
            ),
            "Overly permissive file mode: '{match}'",
            "Restrict file permissions; avoid world-writable (777/666).",
        ),
        (
            re.compile(
                r"(permissions?|mode)\s*[:=]\s*['\"]?(777|666|755)['\"]?",
            ),
            "Overly permissive file mode: '{match}'",
            "Restrict file permissions; avoid world-writable (777/666).",
        ),
    ]


# Export all config rules
ALL_CONFIG_RULES = [
    ConfigHardcodedSecret,
    ConfigInsecureDefaults,
    ConfigWeakEncryption,
    ConfigUnrestrictedCORS,
    ConfigDatabasePublicExpose,
    ConfigDefaultCredentials,
    ConfigLoggingSensitiveData,
    ConfigRateLimitDisabled,
    ConfigSessionTimeoutInsecure,
    ConfigUnsafeFilePermissions,
]
