"""Base rule interface for detection rules."""

from __future__ import annotations

import re
from abc import ABC, abstractmethod

from skillgate.core.models.bundle import SourceFile
from skillgate.core.models.enums import Category, Language, Severity
from skillgate.core.models.finding import Finding


class Rule(ABC):
    """Abstract base class for all detection rules.

    Each rule has a unique ID, metadata, and an analyze method that scans
    source files for dangerous patterns.
    """

    id: str
    name: str
    description: str
    severity: Severity
    weight: int
    category: Category

    @abstractmethod
    def analyze(self, source: SourceFile) -> list[Finding]:
        """Analyze a source file and return findings.

        Args:
            source: The source file to analyze.

        Returns:
            List of findings detected in the file.
        """
        ...

    def _make_finding(
        self,
        source: SourceFile,
        line_number: int,
        message: str,
        column: int | None = None,
        remediation: str | None = None,
    ) -> Finding:
        """Create a Finding from this rule's metadata."""
        snippet = ""
        if 0 < line_number <= len(source.lines):
            snippet = source.lines[line_number - 1]
        return Finding(
            rule_id=self.id,
            rule_name=self.name,
            severity=self.severity,
            category=self.category,
            message=message,
            file=source.path,
            line=line_number,
            column=column,
            snippet=snippet,
            weight=self.weight,
            remediation=remediation,
        )


class RegexRule(Rule):
    """Base class for rules that use regex pattern matching.

    Subclasses define `patterns` — a list of (compiled_regex, message_template, remediation).
    The base analyze method scans each line against all patterns.
    """

    patterns: list[tuple[re.Pattern[str], str, str]]

    def analyze(self, source: SourceFile) -> list[Finding]:
        """Scan source lines against regex patterns."""
        findings: list[Finding] = []
        for line_num, line in enumerate(source.lines, start=1):
            stripped = line.strip()
            # Skip comments
            if stripped.startswith("#") or stripped.startswith("//"):
                continue
            for pattern, message_template, remediation in self.patterns:
                for match in pattern.finditer(line):
                    message = message_template.format(match=match.group(0))
                    findings.append(
                        self._make_finding(
                            source,
                            line_num,
                            message,
                            column=match.start() + 1,
                            remediation=remediation,
                        )
                    )
        return findings


class LanguageRegexRule(RegexRule):
    """Regex rule scoped to specific programming languages.

    Subclasses set `languages` to restrict which file types this rule applies to.
    Files with non-matching languages are silently skipped.
    """

    languages: frozenset[Language]

    def analyze(self, source: SourceFile) -> list[Finding]:
        """Scan source only if its language matches."""
        if source.language not in self.languages:
            return []
        return super().analyze(source)


class AstRule(Rule):
    """Base class for rules that use tree-sitter AST queries.

    Provides graceful degradation: if tree-sitter is not installed, the rule
    returns no findings (falls back silently). Install with `pip install skillgate[ast]`.
    """

    languages: frozenset[Language]
    query: str  # tree-sitter S-expression query

    def analyze(self, source: SourceFile) -> list[Finding]:
        """Run tree-sitter query if available, else return empty."""
        if source.language not in self.languages:
            return []
        from skillgate.core.analyzer import treesitter

        if not treesitter.is_available(source.language):
            return []
        matches = treesitter.run_query(source.language, source.content, self.query)
        return self._process_matches(source, matches)

    def _process_matches(
        self,
        source: SourceFile,
        matches: list[tuple[int, int, str]],
    ) -> list[Finding]:
        """Convert tree-sitter matches to findings.

        Args:
            source: The source file.
            matches: List of (start_line, start_col, matched_text) from tree-sitter.

        Returns:
            List of findings.
        """
        findings: list[Finding] = []
        for line, col, text in matches:
            findings.append(
                self._make_finding(
                    source,
                    line,
                    f"{self.description}: {text}",
                    column=col,
                )
            )
        return findings
