"""Connector manager — orchestrates connectors with fail-open semantics.

The manager:
1. Instantiates connectors from config via the registry.
2. Runs each connector with a timeout guard.
3. On failure/timeout, produces an empty result (fail-open) if configured.
4. Merges results into an AggregatedConnectorResult.
"""

from __future__ import annotations

import logging
import signal
import time
from typing import TYPE_CHECKING

from skillgate.core.connectors.models import (
    AggregatedConnectorResult,
    ConnectorConfig,
    ConnectorResult,
    ConnectorStatus,
)
from skillgate.core.connectors.registry import get_connector

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class _TimeoutError(Exception):
    """Internal timeout signal."""


def _timeout_handler(signum: int, frame: object) -> None:
    """Signal handler for SIGALRM timeout."""
    raise _TimeoutError("Connector timed out")


def _run_with_timeout(
    config: ConnectorConfig,
    rule_ids: list[str],
) -> ConnectorResult:
    """Run a single connector with timeout enforcement.

    Uses SIGALRM on Unix for timeout. Falls back to no-timeout on
    platforms without SIGALRM (Windows).
    """
    connector = get_connector(config)

    # Validate config first
    errors = connector.validate_config()
    if errors:
        return ConnectorResult(
            connector_name=config.name,
            status=ConnectorStatus.ERROR,
            error_message=f"Config validation failed: {'; '.join(errors)}",
        )

    has_alarm = hasattr(signal, "SIGALRM")
    timeout_secs = int(config.timeout_seconds) or 1

    if has_alarm:
        old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
        signal.alarm(timeout_secs)

    try:
        result = connector.fetch(rule_ids)
    except _TimeoutError:
        return ConnectorResult(
            connector_name=config.name,
            status=ConnectorStatus.TIMEOUT,
            error_message=f"Timed out after {config.timeout_seconds}s",
        )
    except Exception as exc:
        return ConnectorResult(
            connector_name=config.name,
            status=ConnectorStatus.ERROR,
            error_message=str(exc),
        )
    finally:
        if has_alarm:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

    return result


def fetch_all(
    configs: list[ConnectorConfig],
    rule_ids: list[str],
) -> AggregatedConnectorResult:
    """Run all enabled connectors and merge results.

    Fail-open: connector failures produce empty results and a log warning
    but never raise exceptions or block the scan pipeline.

    Args:
        configs: List of connector configurations.
        rule_ids: Rule IDs to enrich.

    Returns:
        Aggregated result with merged enrichments.
    """
    results: list[ConnectorResult] = []
    merged: dict[str, dict[str, object]] = {}
    total_start = time.monotonic()

    for config in configs:
        if not config.enabled:
            results.append(
                ConnectorResult(
                    connector_name=config.name,
                    status=ConnectorStatus.DISABLED,
                )
            )
            continue

        start = time.monotonic()
        try:
            result = _run_with_timeout(config, rule_ids)
        except KeyError as exc:
            # Unknown connector type
            result = ConnectorResult(
                connector_name=config.name,
                status=ConnectorStatus.ERROR,
                error_message=str(exc),
            )

        result.elapsed_seconds = round(time.monotonic() - start, 4)

        if result.status != ConnectorStatus.SUCCESS:
            if config.fail_open:
                logger.warning(
                    "Connector '%s' failed (%s): %s — fail-open, continuing",
                    config.name,
                    result.status.value,
                    result.error_message,
                )
            else:
                logger.error(
                    "Connector '%s' failed (%s): %s — fail_open=False",
                    config.name,
                    result.status.value,
                    result.error_message,
                )

        # Merge enrichments — later connectors override earlier ones per rule_id
        for rule_id, enrichment in result.enrichments.items():
            merged[rule_id] = enrichment

        results.append(result)

    total_elapsed = round(time.monotonic() - total_start, 4)
    return AggregatedConnectorResult(
        results=results,
        enrichments=merged,
        total_elapsed_seconds=total_elapsed,
    )
