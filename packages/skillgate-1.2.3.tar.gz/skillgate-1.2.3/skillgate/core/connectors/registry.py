"""Connector registry — maps type identifiers to connector classes."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from skillgate.core.connectors.base import BaseConnector
    from skillgate.core.connectors.models import ConnectorConfig

logger = logging.getLogger(__name__)

# Type alias for connector factory
ConnectorFactory = type["BaseConnector"]

_REGISTRY: dict[str, ConnectorFactory] = {}


def register_connector(
    connector_type: str,
    cls: ConnectorFactory,
) -> None:
    """Register a connector class for a given type identifier.

    Args:
        connector_type: Unique type identifier (e.g. ``"file_tip"``).
        cls: Connector class to instantiate for this type.
    """
    if connector_type in _REGISTRY:
        logger.warning(
            "Overwriting connector type '%s' (was %s, now %s)",
            connector_type,
            _REGISTRY[connector_type].__name__,
            cls.__name__,
        )
    _REGISTRY[connector_type] = cls


def get_connector(config: ConnectorConfig) -> BaseConnector:
    """Instantiate a connector from config.

    Args:
        config: Connector configuration with ``connector_type`` set.

    Returns:
        Instantiated connector.

    Raises:
        KeyError: If connector_type is not registered.
    """
    cls = _REGISTRY.get(config.connector_type)
    if cls is None:
        msg = (
            f"Unknown connector type '{config.connector_type}'. "
            f"Registered types: {sorted(_REGISTRY.keys())}"
        )
        raise KeyError(msg)
    return cls(config)


def registered_types() -> list[str]:
    """Return sorted list of registered connector type identifiers."""
    return sorted(_REGISTRY.keys())


def clear_registry() -> None:
    """Clear all registered connectors. For testing only."""
    _REGISTRY.clear()
