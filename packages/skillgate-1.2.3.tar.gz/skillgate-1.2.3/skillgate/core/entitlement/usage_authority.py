"""Authoritative usage checks for entitlement enforcement."""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from ipaddress import ip_address
from urllib.parse import urlparse

import httpx

from skillgate.core.entitlement.airgap import (
    consume_airgap_pack_scan,
    enforce_pack_window,
    load_airgap_pack,
)
from skillgate.core.entitlement.mode import EntitlementEnforcementMode
from skillgate.core.entitlement.models import Entitlement
from skillgate.core.errors import EntitlementError

DEFAULT_SAAS_AUTHORITY_URL = "https://api.skillgate.io"


def _build_quota_error(used: int, limit: int, reason: str | None = None) -> EntitlementError:
    suffix = f" ({used}/{limit})" if limit > 0 else ""
    extra = f" Reason: {reason}." if reason else ""
    return EntitlementError(
        f"Daily scan quota exceeded{suffix}. Upgrade to Pro for unlimited scans at "
        f"https://skillgate.io/pricing{extra}",
        tier="FREE",
    )


def consume_scan_authoritatively(
    *,
    mode: EntitlementEnforcementMode,
    api_key: str | None,
    entitlement: Entitlement,
) -> None:
    """Consume one scan from the authoritative usage source.

    LOCAL mode is intentionally not handled here; callers should use local quota tracker.
    """
    if entitlement.limits.scans_per_day <= 0:
        return

    if mode == EntitlementEnforcementMode.AIRGAP:
        _consume_airgap_scan(entitlement)
        return

    _consume_http_authority_scan(
        mode=mode,
        api_key=api_key,
        subject_id=entitlement.subject_id,
        entitlement=entitlement,
    )


def _consume_airgap_scan(entitlement: Entitlement) -> None:
    pack_path = os.environ.get("SKILLGATE_AIRGAP_PACK_PATH", "").strip()
    if pack_path:
        pack = load_airgap_pack()
        enforce_pack_window(pack)
        consume_airgap_pack_scan(pack)
        return

    remaining_raw = os.environ.get("SKILLGATE_AIRGAP_SCANS_REMAINING_TODAY")
    if remaining_raw is None:
        raise EntitlementError(
            "Air-gap entitlement mode requires SKILLGATE_AIRGAP_SCANS_REMAINING_TODAY.",
            tier=entitlement.tier.value.upper(),
        )

    try:
        remaining = int(remaining_raw)
    except ValueError as exc:
        raise EntitlementError(
            "Invalid SKILLGATE_AIRGAP_SCANS_REMAINING_TODAY; expected integer.",
            tier=entitlement.tier.value.upper(),
        ) from exc

    if remaining <= 0:
        limit = entitlement.limits.scans_per_day
        raise _build_quota_error(limit, limit, reason="airgap quota exhausted")

    # Process-local decrement; true authority is the signed offline pack rotation process.
    os.environ["SKILLGATE_AIRGAP_SCANS_REMAINING_TODAY"] = str(remaining - 1)


def _consume_http_authority_scan(
    *,
    mode: EntitlementEnforcementMode,
    api_key: str | None,
    subject_id: str | None,
    entitlement: Entitlement,
) -> None:
    if not subject_id:
        raise EntitlementError(
            "Signed entitlement subject is required for authoritative usage tracking.",
            tier=entitlement.tier.value.upper(),
        )

    base_url = _resolve_authority_url(mode)
    _enforce_authority_url_lock(base_url, entitlement)

    if mode == EntitlementEnforcementMode.PRIVATE_RELAY and not _is_internal_authority(base_url):
        raise EntitlementError(
            "Private relay mode requires an internal SKILLGATE_ENTITLEMENT_AUTHORITY_URL.",
            tier=entitlement.tier.value.upper(),
        )
    _enforce_transport_policy(mode, base_url, entitlement)

    timeout_s_raw = os.environ.get("SKILLGATE_ENTITLEMENT_AUTHORITY_TIMEOUT_SECONDS", "3")
    try:
        timeout_s = float(timeout_s_raw)
    except ValueError:
        timeout_s = 3.0

    payload = {
        "mode": mode.value,
        "tier": entitlement.tier.value,
        "scans_per_day_limit": entitlement.limits.scans_per_day,
        "provenance": {
            "source": "skillgate-cli",
            "decision_at": datetime.now(timezone.utc).isoformat(),
        },
    }
    if api_key:
        payload["api_key"] = api_key
    if subject_id:
        payload["subject_id"] = subject_id

    endpoint = f"{base_url.rstrip('/')}/v1/entitlements/consume-scan"
    token = os.environ.get("SKILLGATE_ENTITLEMENT_AUTHORITY_TOKEN", "").strip()
    signed_entitlement_token = os.environ.get("SKILLGATE_ENTITLEMENT_TOKEN", "").strip()
    if not signed_entitlement_token:
        raise EntitlementError(
            "Non-local entitlement mode requires SKILLGATE_ENTITLEMENT_TOKEN.",
            tier=entitlement.tier.value.upper(),
        )
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    headers["X-SkillGate-Entitlement-Token"] = signed_entitlement_token
    entitlement_public_key = os.environ.get("SKILLGATE_ENTITLEMENT_PUBLIC_KEY", "").strip()
    if entitlement_public_key:
        headers["X-SkillGate-Entitlement-Public-Key"] = entitlement_public_key
    headers["X-Entitlement-Nonce"] = uuid.uuid4().hex
    try:
        response = httpx.post(endpoint, json=payload, headers=headers, timeout=timeout_s)
        response.raise_for_status()
        data_obj = response.json()
    except Exception as exc:
        raise EntitlementError(
            "Failed to consume scan from authoritative entitlement service.",
            tier=entitlement.tier.value.upper(),
        ) from exc

    data = data_obj if isinstance(data_obj, dict) else {}
    allowed = bool(data.get("allowed", False))
    used = int(data.get("used", entitlement.limits.scans_per_day))
    limit = int(data.get("limit", entitlement.limits.scans_per_day))
    reason_obj = data.get("reason")
    reason = str(reason_obj) if reason_obj is not None else None

    if not allowed:
        raise _build_quota_error(used, limit, reason=reason)


def _is_internal_authority(base_url: str) -> bool:
    parsed = urlparse(base_url)
    host = (parsed.hostname or "").lower()
    if not host:
        return False
    if host in {"localhost", "127.0.0.1"}:
        return True
    if host.endswith(".local") or host.endswith(".internal"):
        return True
    try:
        return ip_address(host).is_private
    except ValueError:
        return False


def _resolve_authority_url(mode: EntitlementEnforcementMode) -> str:
    configured = os.environ.get("SKILLGATE_ENTITLEMENT_AUTHORITY_URL", "").strip()
    if configured:
        return configured
    if mode == EntitlementEnforcementMode.SAAS:
        return DEFAULT_SAAS_AUTHORITY_URL
    raise EntitlementError(
        "Authoritative entitlement mode requires SKILLGATE_ENTITLEMENT_AUTHORITY_URL.",
        tier="UNKNOWN",
    )


def _normalize_url(raw: str) -> str:
    return raw.strip().rstrip("/")


def _enforce_authority_url_lock(base_url: str, entitlement: Entitlement) -> None:
    locked = os.environ.get("SKILLGATE_ENTITLEMENT_AUTHORITY_URL_LOCK", "").strip()
    if not locked:
        return
    if _normalize_url(base_url) != _normalize_url(locked):
        raise EntitlementError(
            "Entitlement authority URL does not match locked deployment contract.",
            tier=entitlement.tier.value.upper(),
        )


def _enforce_transport_policy(
    mode: EntitlementEnforcementMode,
    base_url: str,
    entitlement: Entitlement,
) -> None:
    env = os.environ.get("SKILLGATE_ENV", "development").strip().lower()
    parsed = urlparse(base_url)
    if (
        mode == EntitlementEnforcementMode.SAAS
        and env in {"production", "staging"}
        and parsed.scheme != "https"
    ):
        raise EntitlementError(
            "SaaS entitlement authority must use HTTPS in production/staging.",
            tier=entitlement.tier.value.upper(),
        )
