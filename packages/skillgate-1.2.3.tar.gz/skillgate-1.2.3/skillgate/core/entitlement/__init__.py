"""Entitlement module for tier-based capability gating."""

from skillgate.core.entitlement.airgap import (
    AirgapPack,
    consume_airgap_pack_scan,
    enforce_pack_window,
    load_airgap_pack,
)
from skillgate.core.entitlement.cache import EntitlementCache, get_entitlement_cache
from skillgate.core.entitlement.enterprise_adapter import (
    EnterpriseValidationAdapter,
    EnterpriseValidationResult,
    HttpEnterpriseValidationAdapter,
    NoOpEnterpriseValidationAdapter,
    build_enterprise_validation_adapter,
)
from skillgate.core.entitlement.gates import cap_findings, check_capability, check_seat_limit
from skillgate.core.entitlement.mode import EntitlementEnforcementMode, get_enforcement_mode
from skillgate.core.entitlement.models import (
    TIER_ENTITLEMENTS,
    Capability,
    Entitlement,
    EntitlementLimits,
    EntitlementSource,
)
from skillgate.core.entitlement.quota import ScanQuotaTracker
from skillgate.core.entitlement.resolver import (
    resolve_entitlement_safe,
    resolve_from_api_key,
    resolve_from_signed_payload,
    resolve_from_tier,
    resolve_runtime_entitlement,
)
from skillgate.core.entitlement.usage_authority import consume_scan_authoritatively

__all__ = [
    "Capability",
    "consume_scan_authoritatively",
    "consume_airgap_pack_scan",
    "enforce_pack_window",
    "Entitlement",
    "EntitlementCache",
    "EntitlementEnforcementMode",
    "EntitlementLimits",
    "EntitlementSource",
    "EnterpriseValidationAdapter",
    "EnterpriseValidationResult",
    "HttpEnterpriseValidationAdapter",
    "NoOpEnterpriseValidationAdapter",
    "TIER_ENTITLEMENTS",
    "ScanQuotaTracker",
    "build_enterprise_validation_adapter",
    "cap_findings",
    "check_capability",
    "check_seat_limit",
    "get_entitlement_cache",
    "get_enforcement_mode",
    "load_airgap_pack",
    "resolve_entitlement_safe",
    "resolve_from_api_key",
    "resolve_from_signed_payload",
    "resolve_from_tier",
    "resolve_runtime_entitlement",
    "AirgapPack",
]
