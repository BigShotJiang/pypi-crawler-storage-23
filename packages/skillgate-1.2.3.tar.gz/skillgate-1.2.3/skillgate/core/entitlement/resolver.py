"""Entitlement resolution logic."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
from collections import OrderedDict
from datetime import datetime, timedelta, timezone

from nacl.exceptions import BadSignatureError
from nacl.signing import VerifyKey

from skillgate.config.license import Tier, validate_api_key
from skillgate.core.entitlement.airgap import enforce_pack_window, load_airgap_pack
from skillgate.core.entitlement.mode import EntitlementEnforcementMode, get_enforcement_mode
from skillgate.core.entitlement.models import (
    TIER_ENTITLEMENTS,
    Capability,
    Entitlement,
    EntitlementLimits,
    EntitlementSource,
)
from skillgate.core.entitlement.resilience import resolve_with_fail_open
from skillgate.core.errors import ConfigError, EntitlementError

logger = logging.getLogger(__name__)
_NONCE_CACHE: OrderedDict[str, datetime] = OrderedDict()


def resolve_from_tier(tier: Tier) -> Entitlement:
    """Resolve entitlement from a known tier (pure function, no I/O)."""
    factory = TIER_ENTITLEMENTS.get(tier)
    if factory is None:
        raise ValueError(f"Unknown tier: {tier}")
    return factory()


def resolve_from_api_key(api_key: str | None) -> Entitlement:
    """Resolve entitlement from an API key (validates format, no network call)."""
    effective_api_key = _effective_api_key(api_key)
    if not effective_api_key:
        raise EntitlementError(
            "SKILLGATE_API_KEY is required. Generate a key from the dashboard and configure it "
            "before running SkillGate CLI commands.",
            tier="UNKNOWN",
        )

    try:
        tier = validate_api_key(effective_api_key)
    except ConfigError as exc:
        raise EntitlementError(
            "Invalid SKILLGATE_API_KEY format.",
            tier="UNKNOWN",
        ) from exc

    if tier is None:
        raise EntitlementError(
            "Invalid SKILLGATE_API_KEY format.",
            tier="UNKNOWN",
        )

    entitlement = TIER_ENTITLEMENTS[tier]()
    return Entitlement(
        tier=entitlement.tier,
        capabilities=entitlement.capabilities,
        limits=entitlement.limits,
        source=EntitlementSource.API_KEY,
        expires_at=entitlement.expires_at,
    )


def resolve_runtime_entitlement(api_key: str | None) -> Entitlement:
    """Resolve entitlement according to configured enforcement mode contract.

    Contracts:
    - local: API key format-derived entitlement
    - saas/private_relay/airgap: require signed entitlement payload
      via environment (`SKILLGATE_ENTITLEMENT_TOKEN` + `SKILLGATE_ENTITLEMENT_PUBLIC_KEY`)
      or airgap pack when mode=airgap.
    """
    effective_api_key = _effective_api_key(api_key)
    if not effective_api_key:
        raise EntitlementError(
            "SKILLGATE_API_KEY is required. Generate a key from the dashboard and configure it "
            "before running SkillGate CLI commands.",
            tier="UNKNOWN",
        )

    try:
        validate_api_key(effective_api_key)
    except ConfigError as exc:
        raise EntitlementError("Invalid SKILLGATE_API_KEY format.", tier="UNKNOWN") from exc

    mode = get_enforcement_mode()
    if mode == EntitlementEnforcementMode.LOCAL:
        return resolve_from_api_key(effective_api_key)

    token = os.environ.get("SKILLGATE_ENTITLEMENT_TOKEN")
    public_key_hex = os.environ.get("SKILLGATE_ENTITLEMENT_PUBLIC_KEY")
    if mode == EntitlementEnforcementMode.AIRGAP and (not token or not public_key_hex):
        pack_path = os.environ.get("SKILLGATE_AIRGAP_PACK_PATH", "").strip()
        if pack_path:
            pack = load_airgap_pack()
            enforce_pack_window(pack)
            token = pack.token
            public_key_hex = pack.public_key

    if not token or not public_key_hex:
        raise EntitlementError(
            f"{mode.value} entitlement mode requires signed entitlement token and public key.",
            tier="UNKNOWN",
        )

    entitlement = resolve_from_signed_payload(token, public_key_hex)
    _enforce_mode_tier_contract(mode, entitlement)
    return entitlement


def _effective_api_key(api_key: str | None) -> str | None:
    if api_key is not None and api_key.strip():
        return api_key.strip()

    env_key = os.environ.get("SKILLGATE_API_KEY", "").strip()
    if env_key:
        return env_key
    return None


def _enforce_mode_tier_contract(
    mode: EntitlementEnforcementMode,
    entitlement: Entitlement,
) -> None:
    """Enforce deployment-mode tier contract for enterprise-only modes."""
    if (
        mode in {EntitlementEnforcementMode.PRIVATE_RELAY, EntitlementEnforcementMode.AIRGAP}
        and entitlement.tier != Tier.ENTERPRISE
    ):
        raise EntitlementError(
            f"{mode.value} entitlement mode requires Enterprise tier.",
            tier=entitlement.tier.value.upper(),
        )


def resolve_from_signed_payload(token: str, public_key_hex: str) -> Entitlement:
    """Resolve entitlement from a server-issued signed token.

    Token format: ``{base64url_payload}.{signature_hex}``

    The payload is canonical JSON (sorted keys, no whitespace) of::

        {
            "capabilities": [...],
            "expires_at": "<ISO 8601 UTC or null>",
            "issued_at": "<ISO 8601 UTC>",
            "limits": {"max_findings_returned": int, "scans_per_day": int},
            "tier": "<tier name>"
        }

    The signature is Ed25519 over ``SHA-256(canonical_json(payload)).encode("utf-8")``.

    Args:
        token: Signed entitlement token.
        public_key_hex: Hex-encoded Ed25519 public key of the issuing server.

    Returns:
        Verified ``Entitlement`` with source ``SIGNED_PAYLOAD``.

    Raises:
        EntitlementError: On malformed token, invalid signature, or expired payload.
    """
    # --- split token ---
    parts = token.split(".", 1)
    if len(parts) != 2:
        raise EntitlementError("Malformed signed entitlement token: expected 'payload.signature'")
    payload_b64, signature_hex = parts

    # --- decode payload ---
    try:
        padding = 4 - len(payload_b64) % 4
        payload_bytes = base64.urlsafe_b64decode(payload_b64 + "=" * (padding % 4))
        payload: dict[str, object] = json.loads(payload_bytes.decode("utf-8"))
    except Exception as exc:
        raise EntitlementError(f"Malformed signed entitlement token: {exc}") from exc

    # --- verify signature ---
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    payload_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    try:
        sig_bytes = bytes.fromhex(signature_hex)
    except ValueError as exc:
        raise EntitlementError(f"Malformed signed entitlement token: {exc}") from exc

    try:
        key_candidates = _resolve_key_candidates(
            payload=payload,
            fallback_public_key=public_key_hex,
        )
    except ValueError as exc:
        raise EntitlementError(f"Malformed signed entitlement token: {exc}") from exc
    if not _verify_signature_with_any_key(
        payload_hash=payload_hash,
        signature=sig_bytes,
        keys=key_candidates,
    ):
        raise EntitlementError("Invalid entitlement token signature")

    _validate_claims(payload)

    # --- build entitlement ---
    try:
        tier = Tier(str(payload["tier"]))
    except (KeyError, ValueError) as exc:
        raise EntitlementError(f"Unknown tier in entitlement token: {exc}") from exc

    raw_caps = payload.get("capabilities", [])
    try:
        capabilities: frozenset[Capability] = frozenset(
            Capability(c) for c in (raw_caps if isinstance(raw_caps, list) else [])
        )
    except ValueError as exc:
        raise EntitlementError(f"Unknown capability in entitlement token: {exc}") from exc

    _limits_raw = payload.get("limits")
    raw_limits: dict[str, object] = _limits_raw if isinstance(_limits_raw, dict) else {}
    _spd = raw_limits.get("scans_per_day", 0)
    _mfr = raw_limits.get("max_findings_returned", 0)
    limits = EntitlementLimits(
        scans_per_day=int(_spd) if isinstance(_spd, (int, float, str)) else 0,
        max_findings_returned=int(_mfr) if isinstance(_mfr, (int, float, str)) else 0,
    )

    expires_dt = _parse_optional_timestamp(payload.get("exp"))
    if expires_dt is None:
        expires_dt = _parse_optional_timestamp(payload.get("expires_at"))

    return Entitlement(
        tier=tier,
        capabilities=capabilities,
        limits=limits,
        source=EntitlementSource.SIGNED_PAYLOAD,
        expires_at=expires_dt,
        subject_id=_extract_subject_id(payload),
    )


def _resolve_key_candidates(
    *,
    payload: dict[str, object],
    fallback_public_key: str,
) -> list[bytes]:
    keys_raw = os.environ.get("SKILLGATE_ENTITLEMENT_PUBLIC_KEYS", "").strip()
    if not keys_raw:
        return [bytes.fromhex(fallback_public_key)]

    key_id_obj = payload.get("kid")
    key_id = str(key_id_obj) if key_id_obj is not None else ""
    try:
        parsed = json.loads(keys_raw)
        if isinstance(parsed, dict):
            if key_id:
                selected = parsed.get(key_id)
                if isinstance(selected, str):
                    return [bytes.fromhex(selected)]
                raise EntitlementError(f"Unknown entitlement key id: {key_id}")
            return [bytes.fromhex(str(v)) for v in parsed.values() if isinstance(v, str)]
        if isinstance(parsed, list):
            return [bytes.fromhex(str(v)) for v in parsed if isinstance(v, str)]
    except json.JSONDecodeError:
        pass

    pieces = [p.strip() for p in keys_raw.split(",") if p.strip()]
    return [bytes.fromhex(piece) for piece in pieces]


def _verify_signature_with_any_key(
    *,
    payload_hash: str,
    signature: bytes,
    keys: list[bytes],
) -> bool:
    for key in keys:
        verify_key = VerifyKey(key)
        try:
            verify_key.verify(payload_hash.encode("utf-8"), signature)
            return True
        except BadSignatureError:
            continue
    return False


def _parse_optional_timestamp(raw: object) -> datetime | None:
    if raw is None:
        return None
    with_value = str(raw).replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(with_value)
    except ValueError as exc:
        raise EntitlementError(f"Malformed timestamp in entitlement token: {exc}") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _extract_subject_id(payload: dict[str, object]) -> str:
    raw = payload.get("sub")
    if raw is None:
        raise EntitlementError("Missing entitlement token subject")
    subject_id = str(raw).strip()
    if not subject_id:
        raise EntitlementError("Missing entitlement token subject")
    # Keep subject identifiers bounded for transport and storage safety.
    if len(subject_id) > 128:
        raise EntitlementError("Entitlement token subject too long")
    return subject_id


def _clock_skew_seconds() -> int:
    raw = os.environ.get("SKILLGATE_ENTITLEMENT_CLOCK_SKEW_SECONDS", "120")
    try:
        return max(0, int(raw))
    except ValueError:
        return 120


def _nonce_ttl_seconds() -> int:
    raw = os.environ.get("SKILLGATE_ENTITLEMENT_NONCE_TTL_SECONDS", "900")
    try:
        return max(1, int(raw))
    except ValueError:
        return 900


def _nonce_cache_limit() -> int:
    raw = os.environ.get("SKILLGATE_ENTITLEMENT_NONCE_CACHE_SIZE", "10000")
    try:
        return max(100, int(raw))
    except ValueError:
        return 10000


def _validate_claims(payload: dict[str, object]) -> None:
    expected_issuer = os.environ.get("SKILLGATE_ENTITLEMENT_ISSUER", "skillgate-authority")
    expected_audience = os.environ.get("SKILLGATE_ENTITLEMENT_AUDIENCE", "skillgate-cli")
    skew = _clock_skew_seconds()
    now = datetime.now(timezone.utc)

    issuer = payload.get("iss")
    if issuer != expected_issuer:
        raise EntitlementError("Invalid entitlement token issuer")

    audience = payload.get("aud")
    if audience != expected_audience:
        raise EntitlementError("Invalid entitlement token audience")

    nonce_obj = payload.get("nonce")
    if not isinstance(nonce_obj, str) or not nonce_obj.strip():
        raise EntitlementError("Missing entitlement token nonce")
    _assert_nonce_not_replayed(nonce_obj.strip(), now)

    exp = _parse_optional_timestamp(payload.get("exp"))
    if exp is None:
        exp = _parse_optional_timestamp(payload.get("expires_at"))
    if exp is not None and now > exp + _seconds_delta(skew):
        raise EntitlementError("Signed entitlement token has expired")

    iat = _parse_optional_timestamp(payload.get("iat"))
    if iat is not None and iat > now + _seconds_delta(skew):
        raise EntitlementError("Entitlement token iat is in the future beyond allowed skew")

    nbf = _parse_optional_timestamp(payload.get("nbf"))
    if nbf is not None and nbf > now + _seconds_delta(skew):
        raise EntitlementError("Entitlement token is not active yet")


def _seconds_delta(seconds: int) -> timedelta:
    return timedelta(seconds=seconds)


def _assert_nonce_not_replayed(nonce: str, now: datetime) -> None:
    ttl = _nonce_ttl_seconds()
    cache_limit = _nonce_cache_limit()
    cutoff = now - _seconds_delta(ttl)

    expired_keys = [key for key, seen_at in _NONCE_CACHE.items() if seen_at < cutoff]
    for key in expired_keys:
        _NONCE_CACHE.pop(key, None)

    if nonce in _NONCE_CACHE:
        raise EntitlementError("Entitlement token replay detected")

    _NONCE_CACHE[nonce] = now
    while len(_NONCE_CACHE) > cache_limit:
        _NONCE_CACHE.popitem(last=False)


def resolve_entitlement_safe(api_key: str | None) -> Entitlement:
    """Resolve entitlement with fail-open policy (returns FREE on error)."""
    return resolve_with_fail_open(lambda: resolve_from_api_key(api_key))
