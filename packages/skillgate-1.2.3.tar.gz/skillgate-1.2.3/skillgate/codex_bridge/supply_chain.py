"""Supply-chain checksum locking for Codex provider binaries."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from skillgate.codex_bridge.models import SupplyChainResult


def verify_provider_checksums(
    lock_path: Path, provider_binaries: dict[str, Path]
) -> SupplyChainResult:
    """Verify checksums and require re-approval if provider binaries drift."""
    checksums = {
        provider_id: _hash_file(path)
        for provider_id, path in sorted(provider_binaries.items(), key=lambda item: item[0])
    }

    if not lock_path.exists():
        _write_lock(lock_path, checksums)
        return SupplyChainResult(
            allowed=True,
            decision_code="SG_ALLOW",
            reason="Checksum lock created.",
        )

    loaded = json.loads(lock_path.read_text(encoding="utf-8"))
    existing = loaded if isinstance(loaded, dict) else {}

    changed = tuple(
        provider_id
        for provider_id, digest in checksums.items()
        if existing.get(provider_id) != digest
    )
    if changed:
        return SupplyChainResult(
            allowed=False,
            decision_code="SG_DENY_UNTRUSTED_TOOL_PROVIDER",
            reason="Provider binary checksum drift detected; re-approval required.",
            changed_providers=changed,
        )

    return SupplyChainResult(
        allowed=True,
        decision_code="SG_ALLOW",
        reason="Checksums verified.",
    )


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(65536)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _write_lock(path: Path, checksums: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(checksums, sort_keys=True, separators=(",", ":")),
        encoding="utf-8",
    )
