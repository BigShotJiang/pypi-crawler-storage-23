"""Models for Codex bridge governance and wrapper decisions."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

Severity = Literal["low", "medium", "high", "critical"]


@dataclass(frozen=True, slots=True)
class CodexFinding:
    """One Codex governance finding."""

    decision_code: str
    message: str
    file_path: str
    surface: Literal["instruction", "settings", "config", "supply-chain"]
    severity: Severity
    pattern: str | None = None

    def to_dict(self) -> dict[str, object]:
        """Serialize finding as a JSON-compatible mapping."""
        payload: dict[str, object] = {
            "decision_code": self.decision_code,
            "message": self.message,
            "file": self.file_path,
            "surface": self.surface,
            "severity": self.severity,
        }
        if self.pattern is not None:
            payload["pattern"] = self.pattern
        return payload


@dataclass(frozen=True, slots=True)
class CodexScanSummary:
    """Aggregate Codex preflight scan summary."""

    project_root: Path
    findings: tuple[CodexFinding, ...]

    @property
    def blocked(self) -> bool:
        """Return True when findings contain deny/fail decisions."""
        return any(
            item.decision_code.startswith("SG_DENY") or item.decision_code.startswith("SG_FAIL")
            for item in self.findings
        )

    def to_dict(self) -> dict[str, object]:
        """Serialize scan summary payload."""
        return {
            "project_root": str(self.project_root),
            "blocked": self.blocked,
            "findings": [finding.to_dict() for finding in self.findings],
            "findings_count": len(self.findings),
        }


@dataclass(frozen=True, slots=True)
class CodexSettingsResult:
    """Result for Codex settings drift checks."""

    allowed: bool
    decision_code: str
    reason: str
    added_allowed_commands: tuple[str, ...] = ()
    added_trusted_providers: tuple[str, ...] = ()
    shell_access_expanded: bool = False


@dataclass(frozen=True, slots=True)
class ProviderDefinition:
    """Provider definition discovered from repo-local config files."""

    provider_id: str
    permissions: tuple[str, ...]
    source_file: str


@dataclass(frozen=True, slots=True)
class ToolProxyDecision:
    """Tool interception decision for the wrapper tool proxy."""

    allowed: bool
    decision_code: str
    reason: str


@dataclass(frozen=True, slots=True)
class SupplyChainResult:
    """Result for provider checksum lock validation."""

    allowed: bool
    decision_code: str
    reason: str
    changed_providers: tuple[str, ...] = ()
