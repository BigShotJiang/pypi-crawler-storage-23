"""AGENTS.md and Codex instruction-injection governance."""

from __future__ import annotations

import json
import re
from pathlib import Path

from skillgate.codex_bridge.models import CodexFinding

# 25+ patterns; includes Codex-specific variants required by Sprint 11.
CODEX_INJECTION_PATTERNS: tuple[tuple[str, str], ...] = (
    (
        "ignore previous instructions",
        r"\bignore\s+(all\s+)?(previous|prior|above|earlier)\s+instructions?\b",
    ),
    (
        "disregard prior guidance",
        r"\bdisregard\s+(all\s+)?(previous|prior|above|earlier)\s+instructions?\b",
    ),
    ("ignore system prompt", r"\bignore\s+system\s+prompt\b"),
    ("you are now", r"\byou\s+are\s+now\b"),
    ("developer mode jailbreak", r"\bdeveloper\s+mode\b"),
    ("dan jailbreak", r"\bDAN\b"),
    ("do anything now", r"\bdo\s+anything\s+now\b"),
    ("bypass safety", r"\bbypass\s+(all\s+)?safety\b"),
    ("disable guardrails", r"\bdisable\s+guardrails?\b"),
    ("execute unrestricted", r"\bexecute\s+unrestricted\b"),
    ("execute without restrictions", r"\bexecute\s+without\s+restrictions\b"),
    ("ignore safety filters", r"\bignore\s+safety\s+filters?\b"),
    ("full shell access granted", r"\bfull\s+shell\s+access\s+granted\b"),
    ("all tools granted", r"\b(access|use)\s+to\s+all\s+tools\b"),
    ("root access", r"\broot\s+access\b"),
    ("operator approved", r"\b(operator|user)\s+approved\b"),
    ("always allow", r"\balways\s+allow\b"),
    ("override restrictions", r"\boverride\s+restrictions?\b"),
    ("disable policy", r"\bdisable\s+policy\b"),
    ("ignore rate limits", r"\bignore\s+rate\s+limits?\b"),
    ("skip budget checks", r"\bskip\s+budget\s+checks?\b"),
    ("exfiltrate", r"\bexfiltrat(e|ion)\b"),
    ("send all file contents", r"\bsend\s+all\s+file\s+contents\s+to\b"),
    ("upload secrets", r"\bupload\s+(all\s+)?secrets\b"),
    ("curl with secret", r"\bcurl\b.*\b(token|secret|key)\b"),
    ("wget with secret", r"\bwget\b.*\b(token|secret|key)\b"),
    ("post to webhook", r"\b(post|send)\s+to\s+https?://"),
    ("true purpose", r"\byour\s+true\s+purpose\s+is\b"),
)


def scan_instruction_files(
    project_root: Path, baseline_path: Path | None = None
) -> list[CodexFinding]:
    """Scan AGENTS.md/Codex instruction files for injection and baseline drift."""
    findings: list[CodexFinding] = []
    candidates = (
        project_root / "AGENTS.md",
        project_root / "codex.md",
        project_root / ".codex" / "instructions.md",
    )

    baseline_payload: dict[str, str] = {}
    if baseline_path is not None and baseline_path.exists():
        loaded = json.loads(baseline_path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            baseline_payload = {str(k): str(v) for k, v in loaded.items()}

    current_payload: dict[str, str] = {}
    for path in candidates:
        if not path.exists():
            continue
        rel = str(path.relative_to(project_root))
        text = path.read_text(encoding="utf-8")
        current_payload[rel] = text

        for label, pattern in CODEX_INJECTION_PATTERNS:
            matched = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
            if matched is None:
                continue
            findings.append(
                CodexFinding(
                    decision_code="SG_DENY_INSTRUCTION_FILE_INJECTION",
                    message=f"Instruction file contains injection pattern: {label}.",
                    file_path=rel,
                    surface="instruction",
                    severity="critical",
                    pattern=matched.group(0)[:120],
                )
            )

        previous = baseline_payload.get(rel)
        if previous is None:
            continue
        for label, pattern in CODEX_INJECTION_PATTERNS:
            old_match = re.search(pattern, previous, re.IGNORECASE | re.MULTILINE)
            new_match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
            if old_match is None and new_match is not None:
                findings.append(
                    CodexFinding(
                        decision_code="SG_DENY_INSTRUCTION_FILE_INJECTION",
                        message=f"New injection pattern introduced since baseline: {label}.",
                        file_path=rel,
                        surface="instruction",
                        severity="critical",
                        pattern=new_match.group(0)[:120],
                    )
                )

    if baseline_path is not None and not baseline_path.exists():
        baseline_path.parent.mkdir(parents=True, exist_ok=True)
        baseline_path.write_text(
            json.dumps(current_payload, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )

    return findings
