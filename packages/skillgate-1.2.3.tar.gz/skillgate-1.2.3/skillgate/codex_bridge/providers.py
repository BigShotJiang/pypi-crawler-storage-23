"""Provider approval registry for Codex config poisoning control."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ProviderRegistry:
    """Persist approved provider permissions for Codex bridge startup checks."""

    def __init__(self, store_path: Path) -> None:
        self._store_path = store_path

    def approve(self, provider_id: str, permissions: tuple[str, ...]) -> None:
        """Approve provider with explicit permission set."""
        payload = self._load()
        payload[provider_id] = {
            "permissions": list(sorted(set(permissions))),
            "approved_at": datetime.now(timezone.utc).isoformat(),
        }
        self._save(payload)

    def revoke(self, provider_id: str) -> bool:
        """Revoke provider approval."""
        payload = self._load()
        if provider_id not in payload:
            return False
        payload.pop(provider_id)
        self._save(payload)
        return True

    def evaluate(
        self, provider_id: str, requested_permissions: tuple[str, ...]
    ) -> tuple[bool, str]:
        """Return allow flag and reason for requested provider permissions."""
        payload = self._load()
        approved = payload.get(provider_id)
        if not isinstance(approved, dict):
            return (False, "Provider is not approved.")

        current = set(requested_permissions)
        allowed = set(_coerce_str_list(approved.get("permissions")))
        expansion = sorted(current - allowed)
        if expansion:
            return (
                False,
                "Provider permission expansion detected: " + ", ".join(expansion),
            )
        return (True, "Provider approved.")

    def list_entries(self) -> dict[str, dict[str, Any]]:
        """Return all provider approvals."""
        return self._load()

    def _load(self) -> dict[str, dict[str, Any]]:
        if not self._store_path.exists():
            return {}
        loaded = json.loads(self._store_path.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict):
            return {}
        result: dict[str, dict[str, Any]] = {}
        for key, value in loaded.items():
            if isinstance(key, str) and isinstance(value, dict):
                result[key] = value
        return result

    def _save(self, payload: dict[str, dict[str, Any]]) -> None:
        self._store_path.parent.mkdir(parents=True, exist_ok=True)
        self._store_path.write_text(
            json.dumps(payload, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )


def _coerce_str_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, str):
            result.append(item)
    return result
