"""Codex settings governance for allowedCommands/trustedProviders/shellAccess drift."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from skillgate.codex_bridge.models import CodexSettingsResult


class CodexSettingsGovernance:
    """Detect permission expansion in Codex config files."""

    def __init__(self, baseline_path: Path, ci_mode: bool = False) -> None:
        self._baseline_path = baseline_path
        self._ci_mode = ci_mode

    def check(self, project_settings: Path, global_settings: Path) -> CodexSettingsResult:
        """Compare merged settings with baseline and deny expansion."""
        merged = self._normalize(self._merge_settings(project_settings, global_settings))

        if not self._baseline_path.exists():
            self._baseline_path.parent.mkdir(parents=True, exist_ok=True)
            self._baseline_path.write_text(
                json.dumps(merged, sort_keys=True, separators=(",", ":")),
                encoding="utf-8",
            )
            return CodexSettingsResult(
                allowed=True,
                decision_code="SG_ALLOW",
                reason="Codex settings baseline created.",
            )

        baseline_raw = json.loads(self._baseline_path.read_text(encoding="utf-8"))
        baseline = self._normalize(baseline_raw if isinstance(baseline_raw, dict) else {})

        baseline_commands = set(baseline["allowedCommands"])
        current_commands = set(merged["allowedCommands"])
        added_commands = tuple(sorted(current_commands - baseline_commands))

        baseline_providers = set(baseline["trustedProviders"])
        current_providers = set(merged["trustedProviders"])
        added_providers = tuple(sorted(current_providers - baseline_providers))

        shell_access_expanded = (not bool(baseline["shellAccess"])) and bool(merged["shellAccess"])

        if added_commands or added_providers or shell_access_expanded:
            return CodexSettingsResult(
                allowed=False,
                decision_code="SG_DENY_SETTINGS_PERMISSION_EXPANSION",
                reason=(
                    "Detected Codex settings expansion in allowedCommands, "
                    "trustedProviders, or shellAccess."
                ),
                added_allowed_commands=added_commands,
                added_trusted_providers=added_providers,
                shell_access_expanded=shell_access_expanded,
            )

        return CodexSettingsResult(
            allowed=True,
            decision_code="SG_ALLOW",
            reason="No Codex settings expansion detected.",
        )

    @staticmethod
    def _merge_settings(project_settings: Path, global_settings: Path) -> dict[str, Any]:
        result: dict[str, Any] = {
            "allowedCommands": [],
            "trustedProviders": [],
            "shellAccess": False,
        }

        for candidate in (global_settings, project_settings):
            if not candidate.exists():
                continue
            payload = json.loads(candidate.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                continue

            allowed_commands = payload.get("allowedCommands")
            if isinstance(allowed_commands, list):
                for command in allowed_commands:
                    if isinstance(command, str) and command not in result["allowedCommands"]:
                        result["allowedCommands"].append(command)

            trusted_providers = payload.get("trustedProviders")
            if isinstance(trusted_providers, list):
                for provider in trusted_providers:
                    if isinstance(provider, str) and provider not in result["trustedProviders"]:
                        result["trustedProviders"].append(provider)

            shell_access = payload.get("shellAccess")
            if isinstance(shell_access, bool):
                result["shellAccess"] = shell_access

        return result

    @staticmethod
    def _normalize(payload: dict[str, Any]) -> dict[str, Any]:
        commands = payload.get("allowedCommands", [])
        providers = payload.get("trustedProviders", [])

        normalized_commands = sorted(
            {item.strip() for item in commands if isinstance(item, str) and item.strip()}
        )
        normalized_providers = sorted(
            {item.strip() for item in providers if isinstance(item, str) and item.strip()}
        )

        shell_access = bool(payload.get("shellAccess", False))

        return {
            "allowedCommands": normalized_commands,
            "trustedProviders": normalized_providers,
            "shellAccess": shell_access,
        }
