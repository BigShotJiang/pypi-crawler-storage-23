# CTA Hierarchy Recommendation Diff (2026-02-21)

## Goal

Standardize conversion intent so users always get:
- Primary CTA: start onboarding (`/signup`)
- Secondary CTA: learn setup steps (`/docs/get-started`)

## Before -> After

### Header (desktop/mobile)
- Before: `Get Started` -> `/signup`
- After: `Start Free` -> `/signup`

### Hero
- Before: `Start Free` -> `/signup`, `Scan a Skill` -> `/docs/get-started`
- After: `Start Free` -> `/signup`, `See Setup Steps` -> `/docs/get-started`

### Bottom CTA section
- Before: `Run Your First Gate` -> `/pricing`, `Read the Docs` -> `/docs`
- After: `Start Free` -> `/signup`, `See Setup Steps` -> `/docs/get-started`

### Pricing cards
- Free/Pro/Team:
  - Preserved intent: onboarding or checkout starts
- Enterprise:
  - Preserved intent: `/contact?plan=enterprise&source=pricing`

### Contact (enterprise)
- Before: primary `mailto` handoff
- After: in-page qualification form -> `/signup` with enterprise context; `mailto` as fallback

## Why This Improves Conversion

1. Reduces choice ambiguity:
- Visitors see one clear primary action across core surfaces.

2. Improves funnel continuity:
- Learning path points to one actionable setup page, not mixed docs destinations.

3. Preserves enterprise split:
- Enterprise buyers keep a dedicated qualification path without forcing email-client context switch.

## Copy Notes Applied

- Marketing language now focuses on outcomes:
  - block risky changes
  - enforce approvals
  - export signed audit evidence
- Reduced architecture-heavy jargon in hero/features/pricing headline layers.
