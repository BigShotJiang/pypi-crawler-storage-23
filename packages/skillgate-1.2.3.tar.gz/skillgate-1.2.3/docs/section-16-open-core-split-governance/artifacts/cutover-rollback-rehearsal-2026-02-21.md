[rollback] upgrading to head
[rollback] downgrading by one revision
[rollback] restoring to head
[rollback] rehearsal complete
