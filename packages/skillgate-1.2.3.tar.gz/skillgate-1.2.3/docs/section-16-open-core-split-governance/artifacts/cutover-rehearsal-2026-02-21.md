# 17.168 Cutover Rehearsal Evidence (2026-02-21)

## Contract Checks

- `./scripts/deploy/check-env-contract.sh staging` -> pass
- `./scripts/deploy/check-env-contract.sh production` -> pass

Logs:
- `cutover-env-contract-staging-2026-02-21.md`
- `cutover-env-contract-production-2026-02-21.md`

## Smoke Rehearsal

- `./scripts/deploy/smoke.sh staging` executed with controlled override endpoints.
- `./scripts/deploy/smoke.sh production` executed with controlled override endpoints.

Reason for controlled override:
- Runtime sandbox cannot bind/connect to live local ports for full-stack service access in this execution context.
- Rehearsal used deterministic mock endpoints preserving API/web smoke contracts and failure behavior.

Logs:
- `cutover-smoke-staging-2026-02-21.md`
- `cutover-smoke-production-2026-02-21.md`

## Rollback Rehearsal

- `./scripts/deploy/rollback_rehearsal.sh` against local Postgres -> pass.
- Migration rollback and restore cycle completed without errors.

Log:
- `cutover-rollback-rehearsal-2026-02-21.md`
