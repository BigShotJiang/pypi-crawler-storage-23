profile=production
api_base_url=https://api.skillgate.io/api/v1
web_base_url=https://app.skillgate.io
cors_origins=https://app.skillgate.io
oauth_callbacks=https://api.skillgate.io/api/v1/auth/oauth/google/callback,https://api.skillgate.io/api/v1/auth/oauth/github/callback
Environment contract check passed for profile=production
