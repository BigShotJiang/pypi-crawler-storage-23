# 17.171 Deployment Profile Lock Evidence (2026-02-21)

Locked profile source:
- `docs/open-core/deployment-profile-lock.json`

Validator output:
- `deployment-profile-lock-validation-2026-02-21.json`

Validated invariants:
- Local/staging/production profiles are present.
- Staging/production use HTTPS for API/web base URLs.
- Staging/production CORS excludes localhost and includes exact web base URL.
- OAuth callback URLs are bound to API base URL per profile.
- Deploy target matrix is explicit for API/worker/web.
