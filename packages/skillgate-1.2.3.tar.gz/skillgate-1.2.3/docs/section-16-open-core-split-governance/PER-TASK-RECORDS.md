# Per-Task Records (Section 16)

This ledger is mandatory for claiming `Complete` status.

## Template

- Task: `17.xxx`
- Scope implemented:
- Tests run:
- Artifacts linked:
- Backward compatibility impact:
- Rollback/recovery:
- Security/policy invariants:
- Status:

## Current Records

### 17.167 (Dual-repo release contract)

- Scope implemented: source-of-truth release contract (`docs/open-core/dual-repo-release-contract.json`) + validator (`scripts/quality/check_dual_repo_release_contract.py`) + CI job wiring.
- Tests run: `tests/unit/test_quality/test_dual_repo_release_contract.py`; `python scripts/quality/check_dual_repo_release_contract.py`.
- Artifacts linked:
  - `docs/open-core/dual-repo-release-contract.json`
  - `artifacts/dual-repo-release-contract-validation-2026-02-21.json`
  - `artifacts/dual-repo-release-contract-2026-02-21.md`
- Backward compatibility impact: additive governance checks only; runtime behavior unchanged.
- Rollback/recovery: remove `dual-repo-release-contract` CI job and validator if governance contract superseded.
- Security/policy invariants: deterministic CE->EE->npm->web sequence enforced; rollback must be reverse order with explicit state checks.
- Status: Complete.

### 17.166 (Public export gate)

- Scope implemented: include-glob scoped export policy + strict checker + CI enforcement job.
- Tests run: `tests/unit/test_quality/test_public_export_gate.py`; strict gate run.
- Artifacts linked:
  - `artifacts/public-export-gate-2026-02-21.json`
  - `artifacts/public-export-negative-fixture-2026-02-21.json`
- Backward compatibility impact: none for runtime behavior; release governance tightened.
- Rollback/recovery: revert `docs/open-core/public-export-policy.json` and CI `public-export-gate` job.
- Security/policy invariants: denylist paths blocked in strict mode with fixture evidence.
- Status: Complete.

### 17.168 (Cutover contract)

- Scope implemented: `scripts/deploy/check-env-contract.sh` + `scripts/deploy/smoke.sh` + rollback rehearsal evidence.
- Tests run: env-contract checks for local/staging/production + smoke rehearsals + rollback rehearsal.
- Artifacts linked:
  - `artifacts/cutover-rehearsal-2026-02-21.md`
  - `artifacts/cutover-env-contract-staging-2026-02-21.log`
  - `artifacts/cutover-env-contract-production-2026-02-21.log`
  - `artifacts/cutover-smoke-staging-2026-02-21.log`
  - `artifacts/cutover-smoke-production-2026-02-21.log`
  - `artifacts/cutover-rollback-rehearsal-2026-02-21.log`
- Backward compatibility impact: additive scripts only.
- Rollback/recovery: retain previous `smoke_api.sh`/`smoke_web.sh`; new wrapper scripts removable.
- Security/policy invariants: smoke and rollback gates remain fail-closed.
- Status: Complete.

### 17.169 (CI parity matrix)

- Scope implemented: parity matrix contract + validator script + CI job wiring.
- Tests run: `tests/unit/test_quality/test_split_ci_parity.py`.
- Artifacts linked:
  - `artifacts/ci-parity-validation-2026-02-21.json`
  - `artifacts/ci-parity-matrix-2026-02-21.md`
- Backward compatibility impact: additive governance check.
- Rollback/recovery: remove `split-ci-parity` job and validator script if needed.
- Security/policy invariants: required gates must map across split contract.
- Status: Complete.

### 17.170 (Legal hardening)

- Scope implemented: terms/privacy/security-addendum/DPA anti-abuse and enforcement language shipped.
- Tests run: web-ui lint + type-check + legal keyword checks.
- Artifacts linked:
  - `web-ui/src/app/terms/page.tsx`
  - `web-ui/src/app/privacy/page.tsx`
  - `web-ui/src/app/legal/security-addendum-template/page.tsx`
  - `web-ui/src/app/legal/dpa-template/page.tsx`
- Backward compatibility impact: low (legal content updates only).
- Rollback/recovery: revert legal page copy.
- Security/policy invariants: explicit unauthorized access, bypass, exploit/malware, suspension/termination language.
- Status: Complete.

### 17.171 (Deployment profile lock)

- Scope implemented: locked deployment profile matrix + validator + CI job wiring.
- Tests run: `tests/unit/test_quality/test_deployment_profile_lock.py`.
- Artifacts linked:
  - `docs/open-core/deployment-profile-lock.json`
  - `artifacts/deployment-profile-lock-validation-2026-02-21.json`
  - `artifacts/deployment-profile-lock-2026-02-21.md`
- Backward compatibility impact: additive governance controls.
- Rollback/recovery: remove validator and profile file if contract changes.
- Security/policy invariants: HTTPS/non-localhost constraints for staging/production; callback and CORS binding checks.
- Status: Complete.

### 17.172 (Split readiness GO artifact)

- Scope implemented: signed split-readiness manifest + verification + release decision update.
- Tests run: manifest generation + verification scripts.
- Artifacts linked:
  - `artifacts/split-readiness-manifest-2026-02-21.json`
  - `artifacts/split-readiness-manifest-verify-2026-02-21.json`
  - `artifacts/split-readiness-report-2026-02-21.md`
- Backward compatibility impact: none.
- Rollback/recovery: set release decision back to `NO-GO` if any gate regresses.
- Security/policy invariants: only verified artifacts included in signed readiness pack.
- Status: Complete.
