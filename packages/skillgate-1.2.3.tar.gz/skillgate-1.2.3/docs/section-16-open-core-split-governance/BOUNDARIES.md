# Boundaries and Non-Goals

## Hard Boundaries

1. Public export is deny-by-default for private ops internals, enterprise-only code,
   private keys, internal runbooks, and customer-specific artifacts.
2. Public repo release cannot proceed unless export checks pass in CI on release paths.
3. Railway and Netlify deployment must follow a scripted cutover/rollback sequence;
   no ad-hoc production mutation.
4. Legal terms/privacy templates must explicitly prohibit unauthorized system access,
   exploit attempts, safeguard bypass, malware delivery, and abusive automation.

## Non-Goals (Current Slice)

- No broad product feature expansion unrelated to split/cutover governance.
- No weakening of existing quality/security gates for speed.
- No manual one-off deployment runbooks without machine-checkable steps.

## Fail-Closed Rules

- If boundary ownership is ambiguous, the path is treated as private.
- If cutover smoke checks fail, rollback is mandatory.
- If legal hardening text is missing required clauses, release is NO-GO.
