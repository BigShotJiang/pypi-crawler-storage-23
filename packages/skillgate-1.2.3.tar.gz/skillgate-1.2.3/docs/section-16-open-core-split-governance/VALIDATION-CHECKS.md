# Validation Checks

Run from `/Users/spy/Documents/PY/AI/skillgate`.

## Core Checks

```bash
./venv/bin/ruff check .
./venv/bin/mypy --strict skillgate/
./venv/bin/pytest -q
python scripts/release/check_public_export.py --strict
python scripts/quality/check_dual_repo_release_contract.py
```

## Deployment/Cutover Checks

```bash
./scripts/deploy/check-env-contract.sh
./scripts/deploy/smoke.sh staging
./scripts/deploy/smoke.sh production
./scripts/deploy/rollback_rehearsal.sh
```

If staging/production endpoints are not reachable in the current runtime, use controlled rehearsal overrides:

```bash
API_BASE_OVERRIDE=http://127.0.0.1:18000/api/v1 WEB_BASE_OVERRIDE=http://127.0.0.1:18000 ./scripts/deploy/smoke.sh staging
API_BASE_OVERRIDE=http://127.0.0.1:18000/api/v1 WEB_BASE_OVERRIDE=http://127.0.0.1:18000 ./scripts/deploy/smoke.sh production
```

## Legal Content Checks

```bash
rg -n "unauthorized|bypass|circumvent|exploit|malware|suspend|terminate" web-ui/src/app/terms/page.tsx web-ui/src/app/privacy/page.tsx web-ui/src/app/legal/security-addendum-template/page.tsx web-ui/src/app/legal/dpa-template/page.tsx
```

## Evidence Location

Store gate evidence in:

- `docs/section-16-open-core-split-governance/artifacts/`
