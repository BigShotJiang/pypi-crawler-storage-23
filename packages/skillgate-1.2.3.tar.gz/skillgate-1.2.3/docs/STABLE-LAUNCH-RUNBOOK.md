# Stable Launch Runbook

This runbook is the single checklist to launch SkillGate stably with:
- Web UI on Netlify
- API + Worker on Railway
- Transactional email via Resend (`no-reply@skillgate.io`)
- Human inboxes on Namecheap (`contact@`, `support@`, `legal@`)

## Recommendation: Phased, Not Big-Bang

Use phased rollout:
1. DNS + email auth records first
2. Deploy API/worker and verify health + auth
3. Deploy web and verify signup/login/verification flow
4. Cut over production domain

Big-bang is possible, but rollback/debugging is harder when DNS, API, web, and email change together.

## 1) Do This Now (Order Matters)

1. Identify authoritative DNS provider for `skillgate.io` (Namecheap vs Cloudflare).
2. Add Resend DNS records there (SPF/DKIM/domain verification).
3. Add Namecheap mailbox DNS records (MX/TXT/CNAME as required).
4. Add `DMARC` record (`_dmarc.skillgate.io`) with monitoring policy first (`p=none`).
5. Configure Railway env vars (API + Worker).
6. Run Railway migration to head.
7. Deploy API and Worker.
8. Configure Netlify env vars and deploy web UI.
9. Run smoke tests against deployed API + web.

## 2) DNS Records Checklist

Add all provider records in the authoritative DNS zone:
- Netlify records (`www`/apex as required by Netlify)
- Railway record for API host (for example `api.skillgate.io`)
- Resend verification + DKIM + SPF records
- Namecheap mailbox records (MX + any required host records)
- DMARC TXT record

Notes:
- If using Cloudflare, mail auth records must be DNS-only (not proxied).
- Keep one SPF policy; do not publish multiple SPF TXT records.

## 3) Railway Required Vars (API)

```bash
SKILLGATE_ENV=production
SKILLGATE_DATABASE_URL=postgresql+asyncpg://<user>:<pass>@<host>:<port>/<db>
SKILLGATE_REDIS_URL=redis://default:<pass>@<host>:<port>
SKILLGATE_JWT_SECRET=<>=32 chars
SKILLGATE_API_KEY_PEPPER=<>=32 chars
SKILLGATE_CORS_ORIGINS=https://<your-netlify-domain>
SKILLGATE_ENABLE_HSTS=true
RESEND_API_KEY=re_...
SKILLGATE_EMAIL_FROM=no-reply@skillgate.io
SKILLGATE_WEB_BASE_URL=https://<your-netlify-domain>
```

Worker service vars:
- same `SKILLGATE_DATABASE_URL`, `SKILLGATE_REDIS_URL`, and env baseline

## 4) Netlify Required Vars (Web)

```bash
NEXT_PUBLIC_API_URL=https://api.skillgate.io/api/v1
NEXT_PUBLIC_ANALYTICS_ENDPOINT=<optional>
```

## 5) Database Migration

Run on Railway after env vars are set:

```bash
railway run alembic upgrade head
```

## 6) Critical User Flow Gate (Must Pass)

1. Signup with new email.
2. Confirm no dashboard access before verification.
3. Receive verification email from `no-reply@skillgate.io`.
4. Open verification link.
5. Login succeeds only after verification.
6. Dashboard access succeeds.

## 7) Smoke Commands

```bash
cd /Users/spy/Documents/PY/AI/skillgate
API_BASE="https://api.skillgate.io/api/v1" ./scripts/deploy/smoke_api.sh
WEB_BASE="https://<your-netlify-domain>" ./scripts/deploy/smoke_web.sh
```

## 8) Launch-Day Rollback Trigger

Rollback if any of these occur:
- Verification emails not delivered or delayed beyond acceptable window
- Signup/login error spike
- API health check instability
- CORS failures for web auth calls

Rollback actions:
1. Revert Netlify deploy to previous successful release.
2. Revert Railway API/worker to previous release.
3. Keep DB at current schema unless rollback migration is explicitly rehearsed.

## 9) Post-Launch Hardening

After stable operation:
1. Move DMARC from `p=none` to `p=quarantine`/`p=reject`.
2. Add Cloudflare in front (if desired) after baseline stability.
3. Enable release canary gate from `docs/RELEASE-SAFETY.md`.

## 10) Production GO Gate (Before Any Publish)

Proceed only if all are green:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
./scripts/deploy/local_production_go_deploy.sh --profile production --skip-pypi --skip-npm
```

GitHub CI gates are disabled for release decisions; production GO is local gate only.

## 11) Exact Production Deployment Order (Strict)

Use this order:

1. Backend/API + DB migrations + Worker (Railway)
2. Web UI (Netlify)
3. Python package publish (PyPI)
4. npm wrapper publish (`@skillgate-io/cli`)

Reason: `@skillgate-io/cli` is a wrapper channel that delegates to Python runtime; publishing npm before PyPI can cause avoidable user failures.

## 12) Exact Command Sequence (Copy/Paste)

### Step 1 — Railway (API + migrations + worker)

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate

# verify deploy contract and cutover smoke first
./scripts/deploy/check-env-contract.sh production

# migrate database on production target
railway run alembic upgrade head

# smoke checks (use production hosts)
API_BASE="https://api.skillgate.io/api/v1" ./scripts/deploy/smoke_api.sh
```

Optional: run Railway + Netlify deploy from local gate script via CLI wrappers.

```bash
cd /Users/spy/Documents/PY/AI/skillgate
set -a
source scripts/deploy/.env.cloud-cli.local
set +a

./scripts/deploy/local_production_go_deploy.sh --profile production --cloud-cli-deploy --skip-smoke
```

Use `scripts/deploy/.env.cloud-cli.example` as the template for required command variables.

### Step 2 — Netlify (web-ui)

```bash
cd /Users/spy/Documents/PY/AI/skillgate/web-ui
npm ci
npm run check
npm run build

# deploy via your Netlify production pipeline
```

Then validate live web:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
WEB_BASE="https://<your-netlify-domain>" ./scripts/deploy/smoke_web.sh
```

### Step 3 — PyPI publish (`skillgate`)

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate

./scripts/test_package_release.sh
python -m build --sdist --wheel --no-isolation --outdir /tmp/skillgate-dist
python -m twine check /tmp/skillgate-dist/*
pytest -m slow tests/e2e/test_packaging_release.py -v

# optional test publish first
python -m twine upload --repository testpypi /tmp/skillgate-dist/*

# production publish
python -m twine upload /tmp/skillgate-dist/*
```

### Step 4 — npm publish (`@skillgate-io/cli`)

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
pytest -m slow tests/e2e/test_npm_shim_wrapper.py -v

cd npm-shim
npm pkg get name version files bin.skillgate engines.node
npm pack --json > /tmp/npm-shim-pack.json
npm publish --access public --provenance --dry-run
npm publish --access public --provenance
```

## 13) Post-Publish Verification

```bash
# registry visibility
python3 -m pip index versions skillgate | head -20
npm view @skillgate-io/cli version

# runtime sanity
pipx install skillgate
skillgate version
npx @skillgate-io/cli version
```
