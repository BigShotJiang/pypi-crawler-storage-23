# Enterprise Private Deployment

This compatibility guide preserves the historical top-level path used by contract tests.
The canonical detailed document is `docs/phase1/ENTERPRISE-PRIVATE-DEPLOYMENT.md`.

## Private Mirror Workflow

Operate package and image promotion through an internal mirror, with signed artifact verification at each promotion stage.

## Restricted Egress Model

Production nodes should run with restricted outbound access and policy-controlled allowlists only.

## Airgap-Aligned Path

For airgapped environments, mirror all dependencies into approved internal registries and disable runtime external fetches.

## Verification Script

Use `verify_release_manifest.py` during release intake and during offline promotion checks.
