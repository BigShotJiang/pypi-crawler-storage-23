# SkillGate — Implementation Plan

**Product:** SkillGate  
**Version:** 1.0.0  
**Status:** Sprints 1–6 Complete, Sprint 7 In Progress; Section 14 GO (Production Ready, 2026-02-21)
**Last Updated:** 2026-02-21
**Classification:** Internal — Confidential  

---

## Table of Contents

1. [Plan Overview](#1-plan-overview)
2. [Sprint 1: Core Engine (Days 1–10)](#2-sprint-1-core-engine-days-110)
3. [Sprint 2: Policy Engine (Days 11–17)](#3-sprint-2-policy-engine-days-1117)
4. [Sprint 3: CI/CD Integration (Days 18–24)](#4-sprint-3-cicd-integration-days-1824)
5. [Sprint 4: Attestations & Launch (Days 25–30)](#5-sprint-4-attestations--launch-days-2530)
5.1. [Sprint 4.1: Universal Language Governance (Days 31–35)](#51-sprint-41-universal-language-governance-days-3135)
6. [Sprint 5: Polish & Expand (Days 36–45)](#6-sprint-5-polish--expand-days-3645)
7. [Sprint 6: Hosted Layer, LLM, Agent-Output Gating & Product Website (Days 46–55)](#7-sprint-6-hosted-layer-llm-agent-output-gating--product-website-days-4655)
8. [Sprint 7: Standout Intelligence + Docs Platform (Days 56–70)](#8-sprint-7-standout-intelligence--docs-platform-days-5670)
9. [Definition of Done](#9-definition-of-done)
10. [Revenue Milestones](#10-revenue-milestones)
11. [Risk Mitigation Timeline](#11-risk-mitigation-timeline)
11.1. [Section 11 Mandatory Execution Pack](#111-mandatory-execution-pack)
12. [Addendum (2026-02-20): Explanation CLI Naming + LLM Provider Extensibility](#12-addendum-2026-02-20-explanation-cli-naming--llm-provider-extensibility)
12.5. [Section 12 Mandatory Execution Pack](#125-mandatory-execution-pack)
13. [Addendum (2026-02-20): Installation + Docs/Web UX Modernization (Claude/Codex-Inspired)](#13-addendum-2026-02-20-installation--docsweb-ux-modernization-claudecodex-inspired)
13.4. [Section 13 Mandatory Execution Pack](#134-mandatory-execution-pack)
14. [Addendum (2026-02-21): Governance + Enforcement + Evidence Strategy Revision](#14-addendum-2026-02-21-governance--enforcement--evidence-strategy-revision)
15. [Addendum (2026-02-21): Open-Core Repo Split + Deployment Cutover Governance](#15-addendum-2026-02-21-open-core-repo-split--deployment-cutover-governance)
16. [Addendum (2026-02-21): Supabase Auth + Data Platform Migration](#16-addendum-2026-02-21-supabase-auth--data-platform-migration)
16.1. [Addendum (2026-02-22): API Key Required Entitlement Contract](#161-addendum-2026-02-22-api-key-required-entitlement-contract)

---

## 1. Plan Overview

### 1.5 Entitlement Contract Update (2026-02-22)

- CLI entitlement-resolved flows require a valid `SKILLGATE_API_KEY` across all tiers, including Free tier usage.
- Free tier remains available through valid `sg_free_*` keys with existing limits (for example scan/day and findings caps).
- Entitlement behavior remains capability-driven by tier after key validation.
- Non-local entitlement modes (`saas`, `private_relay`, `airgap`) continue to require signed entitlement payload contracts.

### 1.1 Timeline Summary

```
Sprint 1   (Days  1–10)  ██████████░░░░░░░░░░░░░░░░░░░░░░░  Core Engine
Sprint 2   (Days 11–17)  ░░░░░░░░░░███████░░░░░░░░░░░░░░░░  Policy Engine
Sprint 3   (Days 18–24)  ░░░░░░░░░░░░░░░░░███████░░░░░░░░░░  CI/CD Integration
Sprint 4   (Days 25–30)  ░░░░░░░░░░░░░░░░░░░░░░░░██████░░░░  Attestations + LAUNCH
Sprint 4.1 (Days 31–35)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████  7-Lang Governance
Sprint 5   (Days 36–45)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Polish & Expand
Sprint 6   (Days 46–55)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Hosted Layer
Sprint 7   (Days 56–70)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Standout + Docs
```

### 1.2 Guiding Constraints

- **No feature without tests.** Every task includes its test implementation.
- **No merge without green CI.** lint + type check + tests must pass.
- **Production-ready at every sprint.** Each sprint produces a deployable, chargeable product.
- **CLI-first.** Web UI and hosted services come late, if at all.
- **Charge at Sprint 4.** Revenue begins the moment attestations ship.

### 1.3 Sprint Cadence

- Each sprint has a **hard deadline** and a **ship gate**
- Ship gate = all DoD items pass (see Section 9)
- If a task isn't done, it's cut — not delayed

### 1.4 Strategic Positioning Lock (Category Definition)

- **Category statement (locked):** SkillGate is the control plane for AI agent execution, not a generic scanner.
- **Brand statement (locked):** Keep `SkillGate` name; expand narrative scope from "skills scanner" to "deterministic governance + runtime control."
- **Homepage and pricing rule:** Every tier and section must map to control layers, not isolated feature bullets.
- **Enterprise rule:** Enterprise is sold as governance infrastructure (runtime, lineage, trust, compliance, API control), never as "Team plus add-ons."

---

## 2. Sprint 1: Core Engine (Days 1–10)

**Goal:** `skillgate scan ./skill` produces structured findings with risk score.

### Day 1–2: Project Bootstrap & Parser Module

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 1.1 | Project scaffolding: pyproject.toml, directory structure, CI workflow, dev dependencies | CI pipeline runs green on empty project | Green CI |
| 1.2 | `SkillBundle` and `SkillManifest` data models (pydantic) | `test_models/test_finding.py`, `test_models/test_report.py` — model validation, serialization | Models pass validation tests |
| 1.3 | Bundle discovery: find bundle root from path | `test_bundle.py::TestBundleDiscovery` — discovers bundles, rejects empty dirs | All discovery tests pass |
| 1.4 | Manifest parser: SKILL.md, skill.json, package.json | `test_manifest.py::TestManifestParsing` — parses all formats, handles missing fields | All manifest tests pass |
| 1.5 | Source file extractor: detect languages, read files | `test_source.py::TestSourceFileExtraction` — language detection, binary skip, encoding | All extraction tests pass |
| 1.6 | SHA-256 bundle hashing | `test_bundle.py` — hash consistency, hash changes with content | Hash tests pass |

**Ship gate:** Can parse any skill bundle from `tests/fixtures/skills/` and produce a `SkillBundle` object.

### Day 3–5: Static Analysis Engine

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 2.1 | `Rule` base class and rule registry | `test_engine.py::TestAnalysisEngine` — runs all rules, respects disabled rules | Base rule system works |
| 2.2 | AST analyzer: Python AST traversal | `test_ast_analyzer.py` — parses valid Python, falls back on syntax errors | AST analysis functional |
| 2.3 | Regex pattern engine | `test_pattern.py` — matches patterns, respects boundaries | Pattern engine functional |
| 2.4 | Shell execution rules (SG-SHELL-001–007) | `test_rules/test_shell.py` — all rules detect, ignore comments/strings, correct metadata | All shell rule tests pass |
| 2.5 | Network access rules (SG-NET-001–006) | `test_rules/test_network.py` — all rules detect, correct metadata | All network rule tests pass |
| 2.6 | File system rules (SG-FS-001–006) | `test_rules/test_filesystem.py` — all rules detect, correct metadata | All FS rule tests pass |
| 2.7 | Dynamic eval rules (SG-EVAL-001–006) | `test_rules/test_eval.py` — all rules detect, correct metadata | All eval rule tests pass |
| 2.8 | Credential access rules (SG-CRED-001–006) | `test_rules/test_credential.py` — all rules detect, correct metadata | All cred rule tests pass |
| 2.9 | Injection rules (SG-INJ-001–004) | `test_rules/test_injection.py` — all rules detect, correct metadata | All injection rule tests pass |
| 2.10 | Obfuscation rules (SG-OBF-001–005) | `test_rules/test_obfuscation.py` — all rules detect, correct metadata | All obfuscation rule tests pass |
| 2.11 | Finding deduplication | `test_engine.py` — deduplicate AST + regex overlap | Dedup works correctly |

**Ship gate:** Can analyze `tests/fixtures/skills/malicious/*` and produce correct findings.

### Day 6–7: Risk Scoring Engine

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 3.1 | Scoring calculator: weighted sum with severity multipliers | `test_scorer/test_engine.py` — empty → 0, single finding, multiple findings, deterministic | Scoring algorithm works |
| 3.2 | Severity classification: Low/Medium/High/Critical | `test_scorer/test_severity.py` — all thresholds, boundary values | Classification correct |
| 3.3 | Score breakdown by category | `test_scorer/test_engine.py` — breakdown groups correctly | Breakdown accurate |
| 3.4 | Default weight configuration | `test_scorer/test_weights.py` — all default weights match spec | Weights match spec |

**Ship gate:** `tests/fixtures/skills/safe/*` → score 0, `malicious/*` → score 60+.

### Day 8–10: CLI & Output Formatters

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 4.1 | CLI framework: Typer app with `scan` command | `test_cli/test_scan_command.py` — arg parsing, help output, version | CLI boots and runs |
| 4.2 | Human-readable output formatter | `test_cli/test_formatters/test_human.py` — colored output, findings table | Human output readable |
| 4.3 | JSON output formatter | `test_cli/test_formatters/test_json.py` — valid JSON, schema compliance | JSON output valid |
| 4.4 | `--output` flag | `test_scan_command.py` — human/json modes switch correctly | Flag works |
| 4.5 | Error handling and exit codes (0, 2, 3) | `test_scan_command.py` — correct exit codes for all scenarios | Exit codes correct |
| 4.6 | **Integration tests:** full scan pipeline | `integration/test_scan_pipeline.py` — safe/malicious/mixed bundles | Pipeline end-to-end works |
| 4.7 | **E2E tests:** CLI invocation | `e2e/test_cli_scan.py` — real CLI execution against fixtures | E2E passes |

**Sprint 1 Ship Gate:**
- [x] `skillgate scan ./skill` works from command line
- [x] Produces findings with file, line, rule ID, severity
- [x] Risk score calculated correctly
- [x] JSON output works
- [x] Human-readable output works
- [x] All unit tests pass
- [x] All integration tests pass
- [x] All E2E tests pass
- [x] Coverage ≥90% on core modules
- [x] `ruff` + `mypy` clean

---

## 3. Sprint 2: Policy Engine (Days 11–17)

**Goal:** `skillgate scan --enforce` blocks based on policy; `skillgate init` creates policy files.

### Day 11–13: Policy Schema & Loader

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 5.1 | Policy data model (pydantic) with validation | `test_policy/test_schema.py` — valid/invalid schemas, range validation | Schema validates correctly |
| 5.2 | YAML policy loader | `test_policy/test_loader.py` — loads valid YAML, rejects invalid | Loader works |
| 5.3 | Built-in presets: development, staging, production, strict | `test_policy/test_presets.py` — all presets load and validate | Presets available |
| 5.4 | Policy resolution: defaults → preset → file → CLI flags | `test_policy/test_loader.py` — priority order respected | Resolution order correct |

**Ship gate:** Can load and validate any `tests/fixtures/policies/*.yml`.

### Day 14–15: Policy Evaluation Engine

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 6.1 | Max score threshold evaluation | `test_policy/test_engine.py` — pass below, fail above | Threshold works |
| 6.2 | Finding count thresholds (critical, high, medium) | `test_policy/test_engine.py` — count checks | Count checks work |
| 6.3 | Permission evaluation (shell, eval, network, filesystem) | `test_policy/test_engine.py` — allow/deny per category | Permissions enforced |
| 6.4 | Domain whitelist evaluation | `test_policy/test_engine.py` — allow listed, block unlisted | Whitelist works |
| 6.5 | Path whitelist evaluation | `test_policy/test_engine.py` — allow listed, block unlisted | Whitelist works |
| 6.6 | Disabled rules exclusion | `test_policy/test_engine.py` — disabled rules ignored | Exclusion works |
| 6.7 | Severity/weight overrides | `test_policy/test_engine.py` — overrides applied | Overrides work |
| 6.8 | Warn vs enforce mode | `test_policy/test_engine.py` — warn=always pass, enforce=may fail | Modes work |
| 6.9 | Multiple violations reporting | `test_policy/test_engine.py` — all violations, not just first | All reported |

**Ship gate:** Policy evaluation produces correct pass/fail for all test scenarios.

### Day 16–17: CLI Integration & `init` Command

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 7.1 | `--enforce` flag on scan command | `test_scan_command.py` — enforces policy, exit code 1 on fail | Flag works |
| 7.2 | `--policy` flag on scan command | `test_scan_command.py` — loads custom policy | Flag works |
| 7.3 | Exit code 1 for policy violations | `e2e/test_exit_codes.py` — all exit code scenarios | Exit codes correct |
| 7.4 | `skillgate init` command | `test_init_command.py`, `e2e/test_cli_init.py` — creates file, preset option | Init works |
| 7.5 | `skillgate rules` command | `test_rules_command.py` — lists all rules with metadata | Rules listed |
| 7.6 | **Integration tests:** Policy enforcement | `integration/test_policy_enforcement.py` | All pass |
| 7.7 | **E2E tests:** Full enforce flow | `e2e/test_exit_codes.py` | All pass |

**Sprint 2 Ship Gate:**
- [x] `skillgate scan --enforce --policy production ./skill` works
- [x] Exit code 0 on pass, 1 on violation
- [x] `skillgate init` creates valid policy file
- [x] `skillgate rules` lists all detection rules
- [x] All policy unit tests pass
- [x] All integration tests pass
- [x] All E2E tests pass
- [x] Coverage ≥90%
- [x] `ruff` + `mypy` clean

**At this point, you have a sellable product:** CLI with policy enforcement.

---

## 4. Sprint 3: CI/CD Integration (Days 18–24)

**Goal:** GitHub Action blocks PRs; SARIF appears in GitHub Security tab.

### Day 18–19: SARIF Output

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 8.1 | SARIF 2.1.0 formatter | `test_formatters/test_sarif.py` — valid SARIF schema, correct mappings | SARIF validates |
| 8.2 | Rule metadata in SARIF driver | `test_sarif.py` — all rules present with correct IDs, descriptions | Rules mapped |
| 8.3 | Finding → SARIF result mapping | `test_sarif.py` — locations, levels, messages correct | Findings mapped |
| 8.4 | `--output sarif` flag | `test_scan_command.py` — produces SARIF file | Flag works |

### Day 20–22: GitHub Action

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 9.1 | `action.yml` definition | Manual validation — inputs/outputs correct | Action definition valid |
| 9.2 | Composite action: install + scan + output | `e2e/test_github_action.py` — simulated action execution | Action runs correctly |
| 9.3 | PR status check integration | Integration test — status check output format | Status check works |
| 9.4 | PR annotation generation | `integration/test_ci_output.py` — annotation payload format | Annotations generated |
| 9.5 | SARIF upload step in action | Manual test — SARIF appears in GitHub Security tab | Upload works |
| 9.6 | Action README and usage docs | Documentation review | Docs complete |

### Day 23–24: GitLab CI & Polish

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 10.1 | GitLab CI template YAML | Manual validation — template is valid CI config | Template valid |
| 10.2 | Generic CI documentation | Documentation review | Docs complete |
| 10.3 | **Integration tests:** CI output formats | `integration/test_ci_output.py` — all formats, annotations | All pass |
| 10.4 | **E2E tests:** GitHub Action simulation | `e2e/test_github_action.py` | All pass |

**Sprint 3 Ship Gate:**
- [x] GitHub Action works: `uses: skillgate/scan-action@v1`
- [x] PR blocked on policy violation
- [x] SARIF uploaded to GitHub Security tab
- [x] PR annotations on risky lines
- [x] GitLab CI template available
- [x] All tests pass, coverage ≥90%

**At this point, you have CI lock-in.** This is your moat.

---

## 5. Sprint 4: Attestations & Launch (Days 25–30)

**Goal:** Signed reports, verification command, PyPI publish, public launch.

### Day 25–27: Ed25519 Signing

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 11.1 | Ed25519 key generation | `test_signer/test_keys.py` — generates valid pair, file permissions | Keys generated |
| 11.2 | Ed25519 signing engine | `test_signer/test_ed25519.py` — signs, verifies, rejects tampered | Signing works |
| 11.3 | Canonical JSON serialization | `test_signer/test_engine.py` — sorted keys, deterministic | Canonical form correct |
| 11.4 | Attestation block generation | `test_signer/test_engine.py` — hash, timestamp, public key | Attestation complete |
| 11.5 | `--sign` flag on scan command | `test_scan_command.py` — produces signed report | Flag works |
| 11.6 | `skillgate verify` command | `test_verify_command.py`, `e2e/test_cli_verify.py` — pass/fail verification | Verify works |
| 11.7 | `skillgate keys generate` command | Manual test + unit tests | Key management works |
| 11.8 | **Integration tests:** sign + verify roundtrip | `integration/test_signed_reports.py` | All pass |
| 11.9 | **E2E tests:** full sign+verify | `e2e/test_cli_verify.py` | All pass |

### Day 28–29: Launch Preparation

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 12.1 | PyPI package configuration | Dry-run publish to TestPyPI | Package installs correctly |
| 12.2 | Docker image (multi-stage build) | Build + run test scan in container | Container scan works |
| 12.3 | License validation (basic API key check) | `test_config/test_license.py` — valid/invalid keys | License gate works |
| 12.4 | README.md with quick-start guide | Documentation review | README complete |
| 12.5 | CHANGELOG.md for v1.0.0 | Documentation review | Changelog complete |
| 12.6 | GitHub Action published to Marketplace | Manual validation | Action discoverable |

### Day 30: LAUNCH

| Task | Description |
|---|---|
| 13.1 | Publish to PyPI: `pip install skillgate` |
| 13.2 | Publish Docker image |
| 13.3 | Publish GitHub Action to Marketplace |
| 13.4 | skillgate.io landing page live |
| 13.5 | Blog post: "Block Unsafe Agent Skills in CI in 5 Minutes" |
| 13.6 | Post on Hacker News, Reddit r/netsec, Twitter/X |

**Sprint 4 Ship Gate:**
- [x] Signed attestation reports work end-to-end
- [x] `skillgate verify` command works
- [x] Published to PyPI, Docker Hub, GitHub Marketplace
- [x] All tests pass, coverage ≥90%
- [x] Landing page live at skillgate.io
- [x] Can accept Pro tier payments

**Revenue starts here.**

---

## 5.1. Sprint 4.1: Universal Language Governance (Days 31–35)

**Goal:** 7-language coverage (Python, JS, TS, Shell, Go, Rust, Ruby), 119 detection rules, optional tree-sitter AST layer. No competitor offers this breadth for agent skill governance.

### Day 31: Foundation & Tree-sitter Integration

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 14A.1 | Add GO, RUST, RUBY to `Language` enum and `EXTENSION_MAP` | `test_source.py` — extension detection for .go, .rs, .rb | New langs detected |
| 14A.2 | `LanguageRegexRule` base class (regex scoped to specific languages) | `test_base_language_filter.py` — filters by language correctly | Language filtering works |
| 14A.3 | `AstRule` base class for tree-sitter S-expression queries | `test_ast_rules.py` — graceful degradation when tree-sitter absent | AST rules degrade safely |
| 14A.4 | `treesitter.py` module: `is_available()`, `parse()`, `run_query()` with lazy imports | `test_treesitter.py` — feature detection, parse, query, degradation | Module works with/without tree-sitter |
| 14A.5 | Optional `[ast]` dependency group in `pyproject.toml` (tree-sitter + 6 grammars) | `pip install -e ".[ast]"` succeeds | Deps install cleanly |
| 14A.6 | Update pre-filter regex in `engine.py` for Go/Rust/Ruby keywords | `test_engine.py` — Go/Rust/Ruby files enter analysis pipeline | Pre-filter extended |

**Ship gate:** `Language.GO`, `.RUST`, `.RUBY` detected; `LanguageRegexRule` filters correctly; tree-sitter optional.

### Day 32–33: Go Rules (13 rules)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 14A.7 | SG-SHELL-010: `exec.Command()` detection | `test_go.py` — detect + ignore comments + ignore non-Go | Rule works |
| 14A.8 | SG-SHELL-011: `exec.Command().Run/Output/CombinedOutput()` | `test_go.py` — output capture patterns | Rule works |
| 14A.9 | SG-NET-010: `http.Get/Post/Head/NewRequest()` | `test_go.py` — HTTP client patterns | Rule works |
| 14A.10 | SG-NET-011: `net.Dial/DialTimeout()` | `test_go.py` — raw socket dial | Rule works |
| 14A.11 | SG-NET-012: `http.ListenAndServe()` | `test_go.py` — HTTP server listener | Rule works |
| 14A.12 | SG-FS-010: `os.Create/OpenFile/WriteFile()` | `test_go.py` — file write ops | Rule works |
| 14A.13 | SG-FS-011: `os.Remove/RemoveAll()` | `test_go.py` — file/dir deletion | Rule works |
| 14A.14 | SG-FS-012: Path traversal via `filepath.Join("../")` | `test_go.py` — traversal detection | Rule works |
| 14A.15 | SG-EVAL-010: `reflect.Value.Call()` | `test_go.py` — reflection calls | Rule works |
| 14A.16 | SG-EVAL-011: `plugin.Open()` | `test_go.py` — dynamic plugin loading | Rule works |
| 14A.17 | SG-CRED-010: `os.Getenv/LookupEnv/Setenv()` | `test_go.py` — env var access | Rule works |
| 14A.18 | SG-CRED-011: Hardcoded API keys in Go strings | `test_go.py` — key pattern detection | Rule works |
| 14A.19 | SG-INJ-010: SQL injection via `fmt.Sprintf()` | `test_go.py` — SQL concat patterns | Rule works |
| 14A.20 | Go test fixtures: safe + malicious bundles | Fixtures in `tests/fixtures/skills/` | Fixtures valid |

**Ship gate:** 13 Go rules pass all tests; `skillgate scan` detects Go patterns; rules don't fire on non-Go files.

### Day 33–34: Rust Rules (13 rules)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 14A.21 | SG-SHELL-020: `Command::new()` | `test_rust.py` — process execution | Rule works |
| 14A.22 | SG-SHELL-021: `.output()/.spawn()/.status()` | `test_rust.py` — command output capture | Rule works |
| 14A.23 | SG-NET-020: `reqwest/hyper/ureq` HTTP clients | `test_rust.py` — HTTP patterns | Rule works |
| 14A.24 | SG-NET-021: `TcpStream::connect()` | `test_rust.py` — raw TCP | Rule works |
| 14A.25 | SG-NET-022: `TcpListener::bind()` | `test_rust.py` — TCP server | Rule works |
| 14A.26 | SG-FS-020: `File::create()/fs::write()` | `test_rust.py` — file writes | Rule works |
| 14A.27 | SG-FS-021: `fs::remove_file/remove_dir_all()` | `test_rust.py` — file deletion | Rule works |
| 14A.28 | SG-FS-022: Path traversal in `Path::new("..")` | `test_rust.py` — traversal detection | Rule works |
| 14A.29 | SG-EVAL-020: `unsafe {}` blocks | `test_rust.py` — unsafe detection | Rule works |
| 14A.30 | SG-EVAL-021: `libloading::Library/dlopen` | `test_rust.py` — dynamic loading | Rule works |
| 14A.31 | SG-CRED-020: `env::var/set_var()` | `test_rust.py` — env var access | Rule works |
| 14A.32 | SG-CRED-021: Hardcoded API keys in Rust strings | `test_rust.py` — key patterns | Rule works |
| 14A.33 | SG-INJ-020: SQL injection via `format!()` macro | `test_rust.py` — SQL concat | Rule works |
| 14A.34 | Rust test fixtures: safe + malicious bundles | Fixtures in `tests/fixtures/skills/` | Fixtures valid |

**Ship gate:** 13 Rust rules pass all tests; `unsafe` blocks and `Command::new` detected correctly.

### Day 34–35: Ruby Rules (15 rules)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 14A.35 | SG-SHELL-030: `system()/Kernel.system` | `test_ruby.py` — system call detection | Rule works |
| 14A.36 | SG-SHELL-031: Ruby `exec()` | `test_ruby.py` — exec detection | Rule works |
| 14A.37 | SG-SHELL-032: Backtick command execution | `test_ruby.py` — backtick patterns | Rule works |
| 14A.38 | SG-SHELL-033: `IO.popen/Open3` | `test_ruby.py` — pipe execution | Rule works |
| 14A.39 | SG-SHELL-034: `Process.spawn/spawn()` | `test_ruby.py` — process spawning | Rule works |
| 14A.40 | SG-NET-030: `Net::HTTP/HTTParty/Faraday/RestClient` | `test_ruby.py` — HTTP clients | Rule works |
| 14A.41 | SG-NET-031: `TCPSocket/UDPSocket/Socket` | `test_ruby.py` — raw sockets | Rule works |
| 14A.42 | SG-FS-030: `File.write/File.open('w')` | `test_ruby.py` — file writes | Rule works |
| 14A.43 | SG-FS-031: `FileUtils.rm/File.delete` | `test_ruby.py` — file deletion | Rule works |
| 14A.44 | SG-FS-032: Path traversal in Ruby | `test_ruby.py` — traversal patterns | Rule works |
| 14A.45 | SG-EVAL-030: `eval/instance_eval/class_eval` | `test_ruby.py` — eval detection | Rule works |
| 14A.46 | SG-EVAL-031: `send/public_send` dynamic dispatch | `test_ruby.py` — dynamic calls | Rule works |
| 14A.47 | SG-EVAL-032: `const_get()` | `test_ruby.py` — dynamic constants | Rule works |
| 14A.48 | SG-CRED-030: `ENV[]` access | `test_ruby.py` — env var reads | Rule works |
| 14A.49 | SG-INJ-030: SQL via string interpolation | `test_ruby.py` — SQL injection | Rule works |
| 14A.50 | Ruby test fixtures: safe + malicious bundles | Fixtures in `tests/fixtures/skills/` | Fixtures valid |

**Ship gate:** 15 Ruby rules pass all tests; backtick/system/eval detected; language-scoped to .rb only.

### Day 35: AST Rules, Integration & Quality Gates

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 14A.51 | Initial AST rules for JS and Go using tree-sitter queries | `test_ast_rules.py` — AST detection with/without tree-sitter | AST rules work when available |
| 14A.52 | Register all new rules in `rules/__init__.py` | `test_engine.py` — rule count is 119 | All rules registered |
| 14A.53 | Integration tests: end-to-end scan of Go/Rust/Ruby bundles | `integration/test_multilang_pipeline.py` | Pipeline works for all 7 langs |
| 14A.54 | Full quality gates: `ruff check . && mypy --strict && pytest --cov >=90%` | All pass | Sprint complete |

**Sprint 4.1 Ship Gate:** ✅ COMPLETE
- [x] 119 detection rules across 7 languages and multi-artifact categories
- [x] Go, Rust, Ruby rules language-scoped (no cross-language false positives)
- [x] Tree-sitter optional: `pip install skillgate[ast]` for AST support
- [x] `skillgate scan` detects Go/Rust/Ruby patterns in test fixtures
- [x] All unit tests pass (533 total)
- [x] All integration tests pass
- [x] Coverage >=90% (90.68%)
- [x] `ruff` + `mypy` clean

**At this point, you can market "7-language universal agent governance" — no competitor matches this.**

---

## 6. Sprint 5: Polish & Expand (Days 36–45)

**Goal:** Improve UX, remote URL scanning, GitLab CI coverage, performance hardening.

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 15.1 | Remote URL scanning (ClawHub links) | Unit + E2E tests for URL input | URL scanning works |
| 15.2 | Additional AST rules for JS/TS/Shell/Go/Rust/Ruby via tree-sitter | Rule tests per language | AST coverage expanded |
| 15.3 | Improved human output (Rich tables, colors) | Snapshot tests | Output looks professional |
| 15.4 | GitLab CI full integration testing | Integration tests | GitLab CI works |
| 15.5 | Bitbucket Pipelines template | Template validation | Template valid |
| 15.6 | `skillgate scan --watch` (re-scan on file change) | Manual test | Watch mode works |
| 15.7 | Homebrew tap for macOS | Manual test | `brew install skillgate` works |
| 15.8 | Performance optimization pass | Performance benchmark tests | Budgets met |
| 15.9 | Security audit of own codebase | Security tests pass | No issues found |

---

## 7. Sprint 6: Hosted Layer, LLM, Agent-Output Gating & Product Website (Days 46–55)

**Goal:** Optional hosted backend for license management, dashboard, LLM explanations, AI-generated code gating mode, and public-facing product marketing website.

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 16.1 | FastAPI backend scaffold | API endpoint tests | Health check responds |
| 16.2 | License validation API | API tests — valid/invalid keys | License checks work |
| 16.3 | Scan result storage API | API tests — store/retrieve scans | Storage works |
| 16.4 | Signature verification endpoint | API tests — verify signed reports | Verification works |
| 16.5 | Minimal dashboard (scan history) | Manual test | Dashboard renders |
| 16.6 | Stripe payment integration | Manual test | Payments process |
| 16.7 | LLM explanation module (opt-in) | Unit tests — explanation generation | Explanations readable |
| 16.8 | `--explain` flag for CLI | CLI tests — flag works, degrades without LLM | Flag works |
| 16.9 | Team management (invite, seats) | API tests | Team management works |
| 16.10 | Slack alerts integration | Integration tests | Alerts fire |
| 16.11 | `--mode agent-output` flag: strict default policy (no shell, no eval, no network, no credential access) tuned for AI-generated code review (Claude, Codex, Copilot, Devin output). Blue ocean positioning as "the CI gate for AI coding agents" — unclaimed by Snyk/Semgrep | `test_scan_command.py` — agent-output mode applies strict policy; `e2e/test_agent_mode.py` — full pipeline with agent-output preset | Flag works, strict policy applied, exit codes correct |
| 16.12 | Product marketing website (`web-ui/`): Next.js/Astro static site with hero, feature breakdown (7-language governance, signed attestations, CI/CD integration), pricing tiers (Free/Pro/Team/Enterprise), docs links, GitHub CTA, and SEO-optimized landing pages. Deployed via Vercel/Netlify. Not a CLI dashboard — this is the public-facing product site at skillgate.io | Manual test — all pages render, responsive, Lighthouse ≥90, links valid | Site live, pricing accurate, mobile-responsive, CTA buttons work |
| 16.13 | Marketing site production hardening: static export, image/font optimization, bundle splitting, route-level code splitting, edge caching headers, Brotli/Gzip, critical CSS, prefetch strategy, Lighthouse budgets (Performance/SEO/Best Practices/Accessibility) | CI Lighthouse + bundle-size checks + Web Vitals smoke tests | p95 page load target met, Lighthouse thresholds enforced in CI, no regressions |
| 16.14 | Frontend resilience and error UX: global error boundaries, typed API client, retry/backoff for checkout call, graceful fallback UI, request timeout handling, offline-safe messaging, idempotent subscribe button state | Unit tests + Playwright E2E for failure paths (timeout/5xx/network loss) | No uncaught frontend errors on tested paths; user always sees actionable error state |
| 16.15 | Frontend security baseline: strict CSP, HSTS, X-Frame-Options, Referrer-Policy, Subresource Integrity where applicable, dependency scanning, no secrets in client bundle | Security header tests + dependency audit + static secret scan | Security headers present; zero leaked secrets; no high/critical client vulns |
| 16.16 | SEO + discoverability hardening: metadata templates, OpenGraph/Twitter cards, canonical tags, sitemap.xml, robots.txt, structured data (SoftwareApplication/Product/FAQ) | Automated SEO checks + schema validation | Pages indexable with valid metadata/schema and no canonical conflicts |
| 16.17 | Analytics/observability for marketing funnel: privacy-aware event tracking for pricing CTA, checkout starts, checkout returns, failures; dashboard-ready metrics | Unit tests for event emission + integration test for event payload contracts | Funnel metrics emitted reliably with no PII leakage |
| 16.18 | Accessibility and UX robustness: WCAG 2.2 AA checks, keyboard navigation, focus management, reduced motion support, high-contrast compatibility, mobile nav resilience | axe/pa11y automation + Playwright keyboard tests | Critical accessibility issues = 0; responsive flows validated across breakpoints |
| 16.19 | API auth foundation: user registration, login, logout/session, password reset, optional OAuth provider support, JWT/session token issuance with rotation | API unit/integration tests + auth abuse tests (brute force, lockout) | Auth flows stable; secure token/session lifecycle; no auth bypass findings |
| 16.20 | Persistence layer rollout: SQLAlchemy models (`users`, `api_keys`, `subscriptions`, `teams`, `team_members`), async DB session management, Alembic migrations, seed/bootstrap scripts | Migration tests + repository tests + rollback tests | Stateless API with durable persistence; zero in-memory store usage in prod paths |
| 16.21 | API key issuance and lifecycle: generate/revoke/rotate/list keys, one-way hashed storage, prefix display, scoped permissions, last-used metadata | Unit/integration tests for key lifecycle + authz tests | Keys are never retrievable in plaintext after creation; lifecycle operations auditable |
| 16.22 | Stripe subscription lifecycle completion: webhook-driven provisioning for `checkout.session.completed`, updates/cancellations/resume, plan changes, invoice failures, trial transitions | Stripe webhook integration tests (signature-valid/invalid, duplicate delivery, out-of-order events) | Subscription state always converges to Stripe source-of-truth |
| 16.23 | Stripe edge-case and money-flow correctness: refund processing (full/partial), proration handling, failed refund compensation path, dispute/chargeback event handling, customer portal sync | Integration tests with mocked Stripe event matrix + reconciliation tests | Financial state remains consistent under retries, partial failures, and disputes |
| 16.24 | Webhook reliability controls: idempotency keys/event store, dead-letter queue, replay tooling, exponential retry policy, alerting for failed processing | Integration tests for duplicate/replay semantics + chaos tests | At-least-once delivery handled safely; no duplicate provisioning |
| 16.25 | Backend resilience and exception policy: centralized exception middleware, typed error envelopes, correlation IDs, timeout/circuit-breaker strategy for external calls, zero unhandled exception policy | Negative-path API tests + fault-injection tests | No uncaught exceptions in tested endpoints; deterministic error responses |
| 16.26 | Rate limiting and abuse protection: per-IP and per-account throttles, signup/login abuse controls, bot mitigation on auth/payment endpoints | Abuse simulation tests + load tests | Service remains stable under abuse patterns without blocking legitimate traffic |
| 16.27 | Production observability and SLOs: structured logs, metrics, traces, Stripe webhook lag metrics, auth failures, checkout conversion, alert runbooks | Observability integration tests + runbook drill | On-call can detect and triage payment/auth incidents within SLA |
| 16.28 | Deployment and release safety: blue/green or canary deploy for API and web, migration safety checks, rollback automation, post-deploy smoke tests | Staging E2E + rollback rehearsal | Zero-downtime release path validated for frontend + backend |

### 7.1 Sprint 6 Extension Ship Gate (Production Web + Billing + Auth)

- [x] `web-ui/` deployed with CI-enforced Lighthouse and accessibility budgets
- [x] No in-memory API stores on production code paths (`_scan_store`, `_team_store`, `_member_store` removed/disabled)
- [x] Auth + API key lifecycle fully implemented and audited
- [x] Stripe webhook handlers are idempotent, replay-safe, and cover refund/dispute paths
- [x] No unhandled exceptions in API integration + negative-path suites
- [x] End-to-end flow passes: pricing CTA -> checkout -> webhook -> account provisioned -> API key issued

### 7.2 Sprint 6 Extension Execution Order (Dependency-Driven)

Implement in this sequence. Do not start a later phase until the prior phase gate is green.

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Reliability Baseline | 16.25, 16.27 | Establish deterministic error handling, observability, and incident visibility before adding auth/billing complexity | Centralized error envelope active; traces/logs/metrics emitted for all existing API routes |
| B. Data Foundation | 16.20 | Durable storage is required before auth, API keys, and Stripe provisioning can be trusted | Alembic migrations apply/rollback cleanly in CI; in-memory stores removed from prod paths |
| C. Access Control Core | 16.19, 16.26 | Auth and abuse controls must exist before exposing account, key, and billing operations | Signup/login/reset flows pass + brute-force/rate-limit tests green |
| D. API Key Lifecycle | 16.21 | Frontend/dashboard and paid-tier workflows depend on safe key issuance and revocation | Create/revoke/rotate/list fully tested; plaintext key never retrievable after create |
| E. Billing Correctness Core | 16.22, 16.24 | Stripe events must be idempotent and replay-safe before edge-case money operations | `checkout.session.completed` provisions account; duplicate/out-of-order webhook tests green |
| F. Billing Edge/Finance Integrity | 16.23 | Refunds/disputes/proration are production-critical money paths that must reconcile correctly | Reconciliation tests green for full/partial refund + dispute scenarios |
| G. Frontend Foundation | 16.12, 16.14 | Build site and resilient API interaction patterns once backend contracts are stable | Marketing pages + checkout redirect + failure UX all pass E2E |
| H. Frontend Hardening | 16.13, 16.15, 16.16, 16.18 | Performance, security, SEO, accessibility enforce production quality gates | Lighthouse/accessibility/security/SEO checks enforced in CI and green |
| I. Funnel Visibility + Release Safety | 16.17, 16.28 | Add conversion telemetry and safe rollout controls immediately before launch | Staging end-to-end smoke + rollback rehearsal + funnel events verified |

### 7.3 Frontend/Backend Contract Gates (Must Hold Before Launch)

- `POST /api/v1/payments/checkout` remains frontend entrypoint and returns Stripe-hosted URL only.
- Webhook is source-of-truth for provisioning; frontend success page is non-authoritative.
- All frontend payment actions are idempotent at UX and API levels.
- Authenticated routes require token/session validation with clear 401/403 envelopes.
- Every user-visible error maps to a typed backend error code and actionable UI state.
- Launch blocked if any critical path lacks integration test coverage.

### 7.4 Recommended Parallelization (Team Throughput)

- Track 1 (Backend Platform): 16.25 -> 16.27 -> 16.20
- Track 2 (Auth/Security): 16.19 -> 16.26 -> 16.21
- Track 3 (Billing): 16.22 -> 16.24 -> 16.23
- Track 4 (Frontend): start 16.12 after 16.22 API contract freeze, then 16.14 -> 16.13/16.15/16.16/16.18 -> 16.17
- Final merge gate: 16.28 only after all prior track gates are green in staging

### 7.5 High-Critical Security Remediation Backlog (Immediate Blockers)

These are exploitable paths identified in the current codebase and must be treated as **release-blocking**.

| ID | Severity | Gap (Exploit Path) | Evidence | Required Fix | Tests Required |
|---|---|---|---|---|---|
| 16.29 | **Critical** | **Device verification auth bypass/account takeover**: `/auth/device/verify` trusts caller-supplied `email` and `provider_user_id` without proving the user completed OAuth, allowing forged identity binding and token issuance. | `skillgate/api/routes/auth.py:659`, `skillgate/api/routes/auth.py:695`, `skillgate/api/routes/auth.py:723` | Require authenticated web session for device verification, bind device code to authenticated principal, perform real OAuth provider token/code exchange, reject caller-asserted identity fields, one-time consume `user_code` with replay protection. | Integration tests for forged `email/provider_user_id` rejection, replay attempts, and code binding to authenticated session. |
| 16.30 | **Critical** | **OAuth callback trust bypass in demo mode**: `/auth/oauth/{provider}/callback` accepts `demo:` payload as identity source in runtime when OAuth is enabled, permitting arbitrary account creation/login by crafted code strings. | `skillgate/api/routes/auth.py:423`, `skillgate/api/routes/auth.py:432`, `skillgate/api/routes/auth.py:460` | Remove `demo:` flow from production/staging; gate behind explicit development-only flag + hard fail in non-dev. Enforce real provider verification and signed state/nonce checks. | Environment matrix tests (dev vs staging/prod), callback forgery tests, state/nonce validation tests. |
| 16.31 | **Critical** | **Billing IDOR / unauthorized portal access**: `/payments/portal` and `/payments/subscription/{subscription_id}` are unauthenticated and do not check ownership, enabling retrieval of other customers’ portal links and subscription metadata. | `skillgate/api/routes/payments.py:766`, `skillgate/api/routes/payments.py:789` | Require authenticated user, resolve Stripe customer/subscription from server-side user mapping, deny direct user-supplied customer IDs, add authorization checks for every billing object access. | API authz tests for cross-account access denial, regression tests for owner-only billing access. |
| 16.32 | **Critical** | **Unauthenticated SSRF primitive in alerts endpoint**: `/alerts/slack` posts to attacker-controlled `webhook_url`, allowing internal network probing/exfil attempts and outbound abuse. | `skillgate/api/routes/alerts.py:69`, `skillgate/api/routes/alerts.py:84` | Require auth + scope for alert actions, remove arbitrary URL input (use stored allowlisted destinations), enforce egress allowlist + DNS/IP deny rules for RFC1918/link-local/metadata IPs, add request signing and per-user quotas. | SSRF blocklist/allowlist tests, authz tests, and abuse/rate-limit tests on alerts endpoint. |
| 16.33 | **Critical** | **License/tier bypass by forged key prefix**: tier resolution relies on regex/prefix format only (`sg_pro_...`, `sg_ent_...`), enabling offline fabrication of higher-tier keys and feature bypass. | `skillgate/config/license.py:37`, `skillgate/config/license.py:40`, `skillgate/config/license.py:63` | Replace format-only validation with cryptographic license tokens (signed/JWS) or server-validated entitlements, include expiry/revocation checks, cache signed entitlement responses with TTL and fail-safe rules. | Negative tests with forged keys, revoked-key tests, expired-token tests, offline cache integrity tests. |
| 16.34 | **Critical** | **Rate-limit bypass via spoofed client IP**: auth and payments rate limits trust raw `x-forwarded-for` from client, enabling attacker-controlled bucket rotation for brute force and request flooding. | `skillgate/api/routes/auth.py:130`, `skillgate/api/routes/payments.py:238` | Trust proxy headers only from known ingress; otherwise use socket IP. Parse standardized forwarded chain safely, enforce canonical client identity, add WAF/edge rate limits before app. | Header spoofing tests, trusted-proxy boundary tests, brute-force simulation with spoofed headers. |
| 16.35 | **Critical** | **Memory/CPU DoS via unbounded payload and pagination**: scan storage and verification endpoints accept large JSON bodies, and scan listing accepts unbounded `limit`, enabling resource exhaustion. | `skillgate/api/routes/scans.py:26`, `skillgate/api/routes/scans.py:67`, `skillgate/api/routes/scans.py:97`, `skillgate/api/routes/verify.py:16` | Add strict body-size limits at ASGI/proxy, enforce schema max sizes/depth, cap pagination (`limit` upper bound), add request timeout + concurrency controls, and per-endpoint cost-aware throttles. | Load/soak tests with oversized payloads, pagination abuse tests, timeout/circuit-breaker regression tests. |

#### 7.5.1 Ship Gate (Must Pass Before Next Public Release)

- [ ] All critical findings `16.29`–`16.35` fixed with merged tests.
- [ ] Red-team regression suite added for auth bypass, IDOR, SSRF, forged license, IP spoofing, and DoS abuse.
- [ ] No unauthenticated payment/account-mutating endpoints remain.
- [ ] Tier/entitlement checks use cryptographic or server-attested validation only.
- [ ] Security review sign-off required before launch promotion.

---

## 8. Sprint 7: Standout Intelligence + Docs Platform (Days 56–70)

**Goal:** Build decisive post-launch differentiation with intelligence-assisted CI gating and a full enterprise docs platform (beyond single-page marketing).

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.1 | Threat intel enrichment layer (`SG-INT-1`): augment findings with reputation metadata, first-seen/last-seen, confidence bands, actor/campaign tags | Unit tests for enrichment mapper + integration tests for deterministic merge into report payload | `scan --json` includes enrichment block with deterministic ordering and no parser regressions |
| 17.2 | Skill reputation registry (`SG-INT-2`): signed known-safe/known-malicious metadata, local cache verification, offline validation path | Signature verification tests + cache consistency tests + stale-cache tests | Reputation data verifiable offline; tampered metadata rejected |
| 17.3 | Confidence-aware policy controls (`SG-INT-3`): policy schema extensions that combine severity and confidence for block/warn behavior | Policy parser tests + policy engine matrix tests + backward-compat tests | Existing policies remain valid; new confidence thresholds enforced deterministically |
| 17.4 | Private intel connector framework (`SG-INT-4`): read-only enrichment adapters for SIEM/TIP sources with strict timeout/fail-open semantics | Connector contract tests + fault/timeout tests + authz tests | Connector failures never break baseline local scan or CI gate |
| 17.5 | Hunt query API + CLI DSL (`SG-HUNT-1`): query historical corpus by rule, repo, maintainer, domain, IOC, confidence, and time windows | Unit tests for query parser + integration tests for API/CLI parity + pagination/auth tests | Hunt queries reproducible and permission-scoped with stable pagination |
| 17.6 | Retro-scan engine (`SG-HUNT-2`): re-run historical scans on rule updates and emit impact diffs | Job orchestration tests + idempotency tests + notification tests | Rule updates trigger replay safely; impacted assets identified without duplicates |
| 17.7 | Multi-page docs platform foundation (`DOC-T1`, `DOC-T2`): docs app shell, versioned IA, MDX conventions, navigation, search, and content ownership model | Web unit tests + routing tests + snapshot tests for nav/search + content lint checks | Docs is no longer single-page; all primary sections discoverable in <=2 clicks |
| 17.8 | Docs CI quality gates (`DOC-T3`): link check, markdown lint, snippet validation, and Lighthouse/accessibility thresholds | CI workflow tests + broken-link failure tests + Lighthouse threshold tests | Docs PR fails on broken links/snippets or Lighthouse budget regression |
| 17.9 | Legal/security docs center (`DOC-T6`): production pages for DPA/security addendum, subprocessors, incident notice templates, security controls index | Content schema tests + route/render tests + link integrity tests | Legal/security pages public, cross-linked, and versioned with changelog anchors |
| 17.10 | Docs/API sync automation (`DOC-T4` kickoff): generated API reference seeded from OpenAPI artifacts and update workflow | Generation script tests + drift detection tests + CI artifact checks | API docs update automatically when OpenAPI contract changes |

### 8.1 Sprint 7 Execution Order (Dependency-Driven)

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Intel Data Plane | 17.1, 17.2 | Enrichment and trust metadata are prerequisites for confidence policy and hunts | Enrichment + signed reputation payloads available in scan/report outputs |
| B. Policy + Connectors | 17.3, 17.4 | Policy decisions must consume enrichment safely and predictably | Confidence-aware policy tests green; connector failures isolated |
| C. Hunt + Retro | 17.5, 17.6 | Historical analysis and campaign tracking depend on normalized enrichment data | Hunt queries and retro-scan jobs stable under load/retries |
| D. Docs Platform Core | 17.7, 17.8 | Docs foundation and CI quality gates prevent content debt from day one | Multi-page docs live; CI blocks regressions |
| E. Trust/Legal Docs | 17.9, 17.10 | Enterprise buyers require legal/security confidence + up-to-date API docs | Legal center + API docs sync live and validated |

### 8.2 Sprint 7 Ship Gate (Standout + Docs Readiness)

- [x] Enriched finding model is available in CLI/API outputs and validated in CI.
- [x] Reputation registry data is signed, cacheable, and tamper-evident.
- [x] Confidence-aware policy decisions are deterministic and backward compatible.
- [ ] Hunt + retro-scan workflows operate with idempotent jobs and audited event trails.
- [ ] Docs platform is multi-page, searchable, and versioned (no single-page dependency).
- [x] Docs CI blocks broken links, invalid snippets, and Lighthouse/accessibility regressions.
- [x] Legal/security trust center pages are publicly routable and internally cross-linked.

### 8.3 Sprint 7 Frontend/Backend Contract Gates

- Enrichment payload contracts are versioned and documented in generated API docs.
- Policy decision responses include machine-readable reasoning fields for CI annotations.
- Hunt endpoints enforce tenant scope and return deterministic sort keys/cursors.
- Docs pages for pricing/security/legal never expose secrets or internal-only URLs.
- Any feature adding network enrichment must degrade gracefully to local deterministic scan.

### 8.4 Sprint 7.1: Monetization Enforcement + Enterprise Trust Hardening (Days 71–85)

**Goal:** Close PRD gaps with enforceable tier entitlements, low-noise deterministic CI outcomes, enterprise audit workflows, and explicit production-readiness for scale and resilience.

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.11 | Tier entitlement model (`Entitlement`): tier, capabilities, limits, source, expiry, grace windows | Unit tests for schema, defaults, serialization, backward compatibility | Entitlement object is canonical source for all tier checks |
| 17.12 | Entitlement resolver service: API key lookup + signed payload verification + local cache with TTL | Unit tests for signature validation + integration tests for cache refresh/expiry/offline fallback | Resolver deterministic under online/offline and stale-cache conditions |
| 17.13 | Free tier scan quota enforcement (3/day): pre-scan gate with deterministic reset window | Unit tests for quota counters + integration tests for day rollover/timezone boundaries + concurrency tests | Free tier cannot exceed configured quota without explicit override path |
| 17.14 | Free findings cap (top 5): post-analysis truncation with stable sorting and deterministic ties | Unit tests for ordering/tie-break + snapshot tests for human/json/sarif output parity | Free output always capped to 5 findings in all output formats |
| 17.15 | Tier capability gates at command boundaries: `--enforce` and `--sign` (Pro+), CI blocking/annotations (Team+) | CLI unit tests + E2E tests for blocked/allowed matrix by tier | Commands fail with deterministic error codes/messages when tier disallows feature |
| 17.16 | Team/Enterprise entitlement controls: seat-aware Team checks, optional Enterprise on-prem validation adapter | API integration tests for seat assignment/revocation + contract tests for on-prem validation adapter | Team seat limits enforced; enterprise validation path works without SaaS dependency |
| 17.17 | Enterprise feature pack: custom policy packs, audit export bundles, dedicated signing key namespaces | Integration tests for policy-pack loading + export integrity tests + signing key isolation tests | Enterprise-only features enforceable and auditable end-to-end |
| 17.18 | CI low-noise controls: deterministic annotation grouping, dedup windows, severity/confidence thresholds, baseline suppression with audit trail | Integration tests for annotation dedup/grouping + regression tests for stable output across reruns | PR noise reduced without suppressing critical findings; behavior fully auditable |
| 17.19 | False-negative defense harness: curated malicious corpus + critical pattern mutation tests (shell/eval/credential exfil) | Corpus regression tests + mutation/fuzz tests + per-rule recall reporting | Critical-pattern recall gate enforced in CI with no silent regressions |
| 17.20 | Reliability SLO gates: false-positive KPI (<5% corpus target), scan latency budgets, CLI cold-start budget | Benchmark tests + corpus evaluation jobs + trend assertions in CI | NFR dashboards and CI gates block merges on reliability/performance regressions |
| 17.21 | API/CLI resilience controls: circuit breaker for hosted entitlement/intel calls, retries with jitter, bounded timeouts, fail-open/fail-closed matrix by feature | Fault-injection tests + chaos tests + timeout/circuit-breaker state transition tests | External outages never break deterministic local scan path; policy documented and tested |
| 17.22 | Abuse and scalability hardening: per-IP and per-key rate limits for entitlement/license endpoints, token bucket tuning, hot-path caching, backpressure | Load tests (p50/p95/p99) + abuse simulation + cache hit-rate assertions | Service sustains target throughput under abuse without unacceptable false throttling |
| 17.23 | Secure secret handling for CLI/API keys: OS keychain integration (when available) + env var fallback + secret redaction in logs | Unit tests for keychain adapters + integration tests for fallback behavior + log redaction tests | Keys never printed/stored insecurely in normal flows; PRD storage requirement met |
| 17.24 | Platform/release governance hardening: Windows/macOS/Linux compatibility matrix, GitHub runner matrix, SemVer/tag/sign release pipeline | CI matrix tests + signed release dry-runs + rollback rehearsal | Cross-platform support and signed releases are enforced by release automation |
| 17.25 | Documentation completion gate: policy reference, rule catalog with examples, contributing guide, entitlement/tier behavior spec | Docs lint/link/snippet tests + doc-code contract checks | PRD documentation requirements complete and continuously validated |

### 8.5 Sprint 7.1 Execution Order (Dependency-Driven)

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Entitlement Core | 17.11, 17.12 | All monetization gates depend on canonical tier resolution | Resolver returns signed, cached entitlements deterministically |
| B. Core Monetization Gates | 17.13, 17.14, 17.15 | Enforce pricing truth directly in scan and command paths | Free quota/cap + Pro/Team feature gates green across outputs |
| C. Enterprise Capability Layer | 17.16, 17.17 | Adds enterprise value after baseline enforcement is stable | Seats, on-prem validation, policy packs, export/signing isolation validated |
| D. Signal Quality + CI Trust | 17.18, 17.19, 17.20 | Low-noise and low-FN are required for buyer trust and CI adoption | CI output stable/noise-controlled; FN/FP/perf SLO gates active |
| E. Resilience + Scale | 17.21, 17.22, 17.23 | Production behavior under failure/load must be explicit and tested | Circuit breaker/rate limit/key security controls pass fault and load suites |
| F. Compatibility + Release + Docs | 17.24, 17.25 | Finalize enterprise-ready shipping and buyer-proof documentation | Signed cross-platform release pipeline and docs gates green |

### 8.6 Sprint 7.1 Ship Gate (Production Readiness)

- [x] Tier entitlement checks are enforced at scan/policy/sign/CI boundaries with deterministic behavior.
- [x] Free tier limits are technically enforced (3/day scans, top-5 findings) across all output formats.
- [x] Enterprise-only capabilities (custom policy packs, audit exports, dedicated signing keys) are implemented and gated.
- [x] CI annotations are low-noise, deterministic, and auditable across reruns.
- [x] Critical-pattern false-negative regression gate is active and blocking.
- [x] Reliability/performance NFR gates (false-positive target, latency, startup) are enforced in CI.
- [x] Circuit breaker, retry/timeout, and rate-limiting controls are verified with fault/load tests.
- [x] API key handling meets secure storage/redaction requirements.
- [x] Cross-platform support and signed release automation are validated in CI.
- [x] Documentation requirements (policy reference, rule catalog, contributing, entitlement spec) are complete and tested.

### 8.7 Implementation Status Overlay (As of 2026-02-18)

Use this section to track actual codebase progress against Sprint 7/Sprint 7.1 tasks.

**Status legend:** `Implemented` | `Mostly Implemented` | `Partially Implemented` | `To Be Implemented`

#### Sprint 7 (`17.1`–`17.10`)

| Task | Status | Remaining Work to Close DoD |
|---|---|---|
| 17.1 Threat intel enrichment layer | Implemented | Keep CI regression checks for deterministic ordering and payload stability. |
| 17.2 Skill reputation registry | Implemented | Reputation verdicts integrated into scan/report/runtime paths; keep contract tests in CI. |
| 17.3 Confidence-aware policy controls | Implemented | Maintain backward-compatibility tests as schema evolves. |
| 17.4 Private intel connector framework | Implemented | Continue validating fail-open timeout behavior under fault injection. |
| 17.5 Hunt query API + CLI DSL | Mostly Implemented | Add deterministic cursor pagination and contract coverage beyond offset model. |
| 17.6 Retro-scan engine | Partially Implemented | Add durable audited event trail + notification path for production workflows. |
| 17.7 Multi-page docs platform foundation | Mostly Implemented | Keep explicit versioning/version-switcher rollout on docs roadmap. |
| 17.8 Docs CI quality gates | Mostly Implemented | Ensure all declared docs quality gates remain enforced in CI over time. |
| 17.9 Legal/security docs center | Implemented | Maintain versioned changelog anchors and link integrity as content grows. |
| 17.10 Docs/API sync automation | Mostly Implemented | Maintain endpoint-surface coverage checks as API expands. |

#### Sprint 7.1 (`17.11`–`17.25`) — Parallel Implementation Stream

Note: Parallel implementation has started. Track progress here; promote statuses only when tests + DoD pass.

| Task | Status | Remaining Work to Close DoD |
|---|---|---|
| 17.11 Tier entitlement model | Implemented | Keep schema compatibility tests in CI for future changes. |
| 17.12 Entitlement resolver service | Implemented | Keep signed payload/cache/offline fallback contract tests in CI. |
| 17.13 Free tier scan quota enforcement | Implemented | Keep day-rollover/concurrency tests in CI. |
| 17.14 Free findings cap (top 5) | Implemented | Keep output parity snapshots (human/json/sarif) in CI. |
| 17.15 Tier capability gates at command boundaries | Implemented | Keep CLI/API/CI blocked/allowed matrix coverage in CI. |
| 17.16 Team/Enterprise entitlement controls | Implemented | Keep seat revocation and adapter contract tests in CI. |
| 17.17 Enterprise feature pack | Implemented | Keep policy-pack/export/signing-namespace integration tests in CI. |
| 17.18 CI low-noise controls | Implemented | Keep deterministic dedup/grouping/suppression tests in CI. |
| 17.19 False-negative defense harness | Implemented | Keep mutation + corpus recall gates as blocking CI checks. |
| 17.20 Reliability SLO gates | Implemented | Keep FP/latency/cold-start gates blocking in CI. |
| 17.21 API/CLI resilience controls | Implemented | Keep fault-injection and timeout/circuit-breaker suites in CI. |
| 17.22 Abuse and scalability hardening | Implemented | Keep abuse/load threshold assertions and tuning in CI. |
| 17.23 Secure secret handling for CLI/API keys | Implemented | Keep key redaction/fallback behavior tests in CI. |
| 17.24 Platform/release governance hardening | Implemented | Keep matrix and release-governance checks enforced in CI. |
| 17.25 Documentation completion gate | Implemented | Keep docs lint/link/snippet checks enforced in CI. |

#### 8.7.1 Validation Snapshot (2026-02-19)

Evidence-backed checks run against current branch:

- `tests/docs/test_docs_exist.py`: passing.
- `tests/unit/test_entitlement/test_enterprise_adapter.py`: passing.
- `tests/unit/test_api/test_entitlement_api.py`: passing.
- `tests/slo/test_false_positive_rate.py`: failing in current release-candidate state (Pre-GA blocker).
- `tests/slo/test_latency_budget.py`: passing.
- Full suite: historical run passed; current branch is treated as blocked until SLO gate is green again.

Conclusion: Sprint 7.1 remains functionally strong, but GA readiness is blocked by reliability gate status.

### 8.8 Sprint 7.2: Markdown-First + Multi-Artifact Security Coverage (Days 86–100)

**Goal:** Enterprise-grade detection and enforcement for markdown-first skill bundles (Claude/Codex style), including prompt-injection/jailbreak coverage and non-code artifacts (txt/pdf/docx/configs/command snippets).

#### 8.8.1 Mandatory Requirements (Implementation Contract)

1. Markdown-first ingestion
- MUST treat `SKILL.md`, `.md`, `.markdown`, `.txt`, `.rst` as analyzable artifacts.
- MUST extract fenced code blocks into virtual source units with language mapping.
- MUST preserve source provenance (`file`, `section`, `line_start`, `line_end`, `origin_type`).

2. Structured markdown parsing
- MUST parse frontmatter and recognized sections: `Permissions`, `Capabilities`, `Commands`, `Resources`, `Templates`.
- MUST handle malformed markdown safely (partial parse with warnings, not silent skip).
- MUST be deterministic: identical input produces identical extraction order and offsets.

3. Threat coverage expansion
- MUST detect prompt injection patterns in prose and extracted blocks.
- MUST detect jailbreak/policy-bypass instructions (including obfuscated variants).
- MUST detect risky shell/network/eval/credential behaviors in fenced snippets.
- MUST detect suspicious command chains (`curl|bash`, `wget|sh`, inline `python -c`, PowerShell download/exec).
- MUST detect unsafe config defaults in `.json/.yaml/.yml/.toml/.env`.

4. Multi-artifact support
- MUST support text extraction scan path for `.pdf` and `.docx` (no macro execution).
- MUST support scan-safe handling of nested archives/artifacts with strict extraction limits.
- MUST never execute any artifact content or fetch remote resources during local scan.

5. Correlation and policy enforcement
- MUST correlate manifest permissions with markdown instructions and resource snippets.
- MUST raise findings when instructions exceed declared permissions or policy constraints.
- MUST include markdown/multi-artifact findings in scoring, policy, CI annotations, and exit codes.
- MUST support policy toggles by artifact/origin class (`code`, `markdown_prose`, `markdown_codeblock`, `document_text`, `config`).

6. Attestation and evidence integrity
- MUST include markdown/document-derived artifacts in bundle hash/signing scope.
- MUST include extraction manifest in signed report: source file, section/page, language, line/page ranges, normalized snippet hash.
- MUST keep verification offline-reproducible and deterministic.

7. Scalability and resilience
- MUST enforce bounded parsing limits (file size, pages, blocks, archive depth, total extracted bytes).
- MUST use timeout/circuit-breaker/fail-safe behavior for optional extractors.
- MUST keep latency and memory budgets within NFR targets.

8. Security hardening
- MUST normalize unicode/confusables/zero-width controls before rule matching.
- MUST defend against regex/backtracking DoS in parser/rules (bounded or streaming patterns).
- MUST produce explicit warnings for unsupported or partially parsed artifact types.

#### 8.8.2 Task Plan (`17.26`–`17.40`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.26 | Add artifact model + provenance schema (origin type, section/page, offsets, extraction hash) | Unit tests for model validation/serialization | Canonical provenance schema used across parser/analyzer/report |
| 17.27 | Markdown/text ingestion pipeline with deterministic fenced-block extraction | Unit tests (nested/malformed fences) + determinism regression tests | Stable virtual-source extraction with exact line mapping |
| 17.28 | Markdown prose scanner for prompt injection/jailbreak patterns | Rule unit tests + adversarial phrase corpus tests | Prose risks detected with low false negatives |
| 17.29 | Command snippet detector (`curl/wget/powershell/python -c` and pipe-to-shell chains) | Unit + integration tests with obfuscated variants | Dangerous command chains detected in markdown/text/docs |
| 17.30 | Config artifact scanner (`json/yaml/toml/env`) for insecure defaults/secrets/endpoints | Schema/rule tests + corpus tests | Config anti-patterns produce deterministic findings |
| 17.31 | PDF/DOCX text extraction adapter (safe text-only mode) | Extraction tests + malformed file tests + timeout tests | Document text enters analyzer with page/offset provenance |
| 17.32 | Archive/nested artifact traversal with depth/size guards | Fuzz tests + bomb/zip-slip safety tests | Safe bounded traversal with explicit skip reasons |
| 17.33 | Cross-artifact correlation engine (manifest vs markdown vs resources) | Integration tests for permission mismatch scenarios | Correlated violations emitted with traceable rationale |
| 17.34 | Policy schema extension by origin class + enforcement controls | Policy parser/backward-compat tests + engine matrix tests | Policy can block/warn by artifact origin deterministically |
| 17.35 | Hash/signing scope update for extracted artifacts + extraction manifest in reports | Sign/verify regression tests + determinism tests | Signed evidence covers markdown/docs/config-derived content |
| 17.36 | SARIF/human/JSON output enrichment with provenance fields | Formatter tests + snapshot tests | Findings include origin, section/page, and source mapping |
| 17.37 | Performance and resilience hardening (limits, timeouts, circuit breaker for optional extractors) | Load/fault tests + latency/memory benchmarks | NFR budgets met under mixed-artifact workloads |
| 17.38 | FN/FP quality harness for markdown/multi-artifact corpus + mutation tests | Corpus CI jobs + mutation detection tests | CI blocks FN regressions; FP KPI tracked by artifact class |
| 17.39 | Security hardening for unicode/confusable normalization and parser safety | Unit + fuzz tests + red-team fixtures | Evasion edge cases covered with deterministic outcomes |
| 17.40 | Documentation + enterprise runbook for artifact coverage and risk interpretation | Docs lint/snippet/link checks | Public/internal docs updated with policy and operational guidance |

#### 8.8.3 Execution Order (Dependency-Driven)

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Data/Provenance Foundation | 17.26, 17.27 | All downstream policy/evidence depends on canonical extraction model | Provenance schema + deterministic markdown extraction validated |
| B. Core Detection Expansion | 17.28, 17.29, 17.30 | Prompt/jailbreak/command/config risks are highest immediate gap | New rule families produce stable findings across fixtures |
| C. Artifact Breadth | 17.31, 17.32 | Document/archive support expands real-world skill coverage | Safe bounded extraction for docs/archives in CI |
| D. Governance & Evidence | 17.33, 17.34, 17.35, 17.36 | Must integrate findings into policy, attestation, and CI outputs | Policy + signed evidence + SARIF include artifact provenance |
| E. Production Hardening | 17.37, 17.38, 17.39, 17.40 | Finalize SLOs, quality gates, and operational clarity | NFR/FN/FP/security gates green and documented |

#### 8.8.4 Production Readiness Gate

- [x] Markdown-first artifacts are scanned by default with deterministic extraction and line mapping.
- [x] Prompt injection/jailbreak detection is active for prose and extracted blocks.
- [x] Document/config/archive coverage is enabled with explicit safe limits and no content execution.
- [x] Cross-artifact permission mismatch detection is enforced and visible in policy results.
- [x] Signed attestations include extraction manifest and artifact-derived evidence scope.
- [x] SARIF/JSON/human outputs expose provenance fields required for triage and audit.
- [x] Mixed-artifact performance budgets and memory limits pass CI benchmarks.
- [x] FN regression gates and FP KPI tracking are active per artifact class.
- [x] Parser/rule evasion edge cases (unicode/confusables/obfuscation/malformed docs) are covered by tests.
- [x] Operational docs/runbooks and customer-facing policy guidance are complete.

#### 8.8.5 Definition of Done (Section-Specific)

1. Implementation
- All tasks `17.26`–`17.40` merged with no TODO/FIXME debt.

2. Quality
- Unit + integration + E2E + fuzz tests pass.
- Coverage >=90% on changed modules.
- `ruff check`, `mypy --strict`, and CI workflow matrix pass.

3. Security
- No artifact execution path exists in parser/analyzer.
- Parser safety tests pass for malformed/bomb-style artifacts.
- Secret-redaction and unsafe-link handling tests pass.

4. Performance
- Latency/memory budgets met on mixed-artifact corpus.
- No regression beyond agreed tolerance vs prior release.

5. Auditability
- Reports include deterministic provenance and extraction manifest.
- Sign/verify flow validates full evidence scope offline.

6. Documentation
- Policy schema changes documented with migration guidance.
- Rule catalog updated for markdown/prompt/jailbreak/document/config rules.
- Enterprise operations runbook updated with triage and incident response guidance.

#### 8.8.6 Tier Placement and Entitlements (Sprint 7.2 Capabilities)

Apply this matrix as the commercialization and enforcement contract for `17.26`–`17.40`.

| Capability | Free | Pro | Team | Enterprise |
|---|---|---|---|---|
| Markdown/text scan baseline (`SKILL.md`, `.md`, `.txt`, `.rst`) for prompt-injection + dangerous command indicators | Yes (limited findings output per tier policy) | Yes | Yes | Yes |
| Fenced code extraction with provenance mapping (section + line offsets) | Yes | Yes | Yes | Yes |
| Advanced jailbreak and obfuscation heuristics | No | Yes | Yes | Yes |
| Config artifact scanning (`json/yaml/toml/env`) | Basic | Full | Full | Full + custom policy packs |
| PDF/DOCX text extraction scanning | No | Yes (bounded limits) | Yes | Yes (policy-controlled limits) |
| Archive and nested artifact traversal | No | Limited depth/size | Extended depth/size | Full policy-controlled depth/size |
| Cross-artifact correlation (manifest permissions vs docs/resources/snippets) | No | Yes | Yes | Yes |
| Policy enforcement (`--enforce`) on markdown/multi-artifact findings | No | Yes | Yes | Yes |
| CI blocking and PR annotations for markdown/multi-artifact findings | No | No | Yes | Yes |
| Signed extraction manifest and artifact evidence in attestations | No | Yes | Yes | Yes |
| Audit export bundles for artifact-derived evidence | No | No | No | Yes |
| Dedicated signing-key namespaces for artifact evidence | No | No | No | Yes |

Enforcement notes:
- Free tier must retain meaningful baseline safety scanning, even when workflow enforcement is gated.
- Team/Enterprise CI gates must include markdown/multi-artifact findings in blocking and annotations.
- Enterprise-only governance outputs (audit bundles, dedicated keys, custom policy packs) remain hard-gated.

#### 8.8.7 Commercialization and Pricing Rollout Tasks (`17.41`–`17.50`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.41 | Finalize paid-tier packaging contract for Sprint 7.2 capabilities (Pro/Team/Enterprise boundaries) | Product QA checklist + entitlement matrix review tests | Single canonical pricing-to-entitlement matrix approved by Product/Eng |
| 17.42 | Update PRD and public pricing copy to reflect final paid-tier packaging and Enterprise qualification criteria | Docs diff review + pricing consistency checks | PRD, web pricing, and implementation plan are fully consistent |
| 17.43 | Implement entitlement mapping for Sprint 7.2 capabilities in API/CLI contracts | Unit tests for tier capability map + integration tests for blocked/allowed matrix | Every Sprint 7.2 capability has deterministic tier gate behavior |
| 17.44 | Add billing/checkout plan mapping for revised Pro/Team/Enterprise model (including Team minimum and Enterprise floor) | API tests for checkout payload mapping + webhook provisioning tests | Stripe plan mapping aligns with entitlement resolver and docs |
| 17.45 | Add UI pricing instrumentation and conversion funnel metrics by tier boundary (view -> click -> checkout -> activation) | Analytics payload contract tests + E2E event tests | Tier-level funnel metrics are emitted reliably with no PII leakage |
| 17.46 | Add Enterprise readiness checklist in pricing/docs (SSO, audit exports, dedicated keys, custom policy packs, SLA) | Content lint/link tests + docs acceptance checklist | Enterprise qualification path is explicit and procurement-ready |
| 17.47 | Add migration path for existing Team/Pro customers to revised packaging (grandfathering, transition windows, messaging) | Integration tests for subscription transition states + rollback tests | No broken subscriptions during pricing transition |
| 17.48 | Add abuse/edge-case pricing tests: entitlement drift, stale cache, webhook lag, downgrade/upgrade race conditions | Fault-injection tests + reconciliation tests | Tier enforcement remains correct under async/billing failure modes |
| 17.49 | Add revenue guardrails and launch gates (minimum conversion thresholds + support capacity + incident rollback criteria) | Release-safety checklist tests + dry-run launch rehearsal | Pricing launch has measurable go/no-go criteria and rollback plan |
| 17.50 | Run pricing validation loop (design-partner interviews + pilot offers) and feed outcomes into final price book | Structured interview rubric + decision log review | Pricing decision log complete with approved final price book |

Commercial rollout gate:
- [ ] Canonical paid-tier matrix is approved and implemented in entitlement code paths.
- [ ] Pricing/PRD/UI copy are in sync and verified by automated checks.
- [ ] Billing plan IDs, entitlement gates, and webhook provisioning are contract-tested.
- [ ] Enterprise qualification and legal/security buyer path are clearly documented.
- [ ] Migration and rollback plans are tested before pricing launch.

### 8.9 Sprint 7.3: Hybrid Entitlement Enforcement (Days 101–110)

**Goal:** Close local-abuse loopholes while supporting Enterprise no-egress CI/CD with SaaS, private relay, and air-gapped enforcement modes.

#### 8.9.1 Mandatory Requirements (Implementation Contract)

1. Source-of-truth enforcement
- MUST treat local quota cache as non-authoritative UX state only.
- MUST enforce paid/free limits from server-attested or enterprise-attested entitlements.
- MUST support offline grace windows with explicit expiry and fail-open/fail-closed policy.

2. Multi-mode deployment
- MUST support `saas`, `private_relay`, and `airgap` entitlement modes.
- MUST avoid direct external API calls from CI in private/airgap mode.
- MUST allow enterprise on-prem validation endpoints and signed entitlement packs.

3. Cryptographic integrity
- MUST sign entitlement payloads (Ed25519) with key rotation support.
- MUST verify signature, issuer, audience, expiry, nonce/replay protections.
- MUST reject stale/tampered claims deterministically with auditable reasons.

4. Usage accounting and audit
- MUST maintain authoritative server-side usage ledger for hosted tiers.
- MUST support deferred usage/event export for private/airgap customers.
- MUST provide reconciliation tooling to detect drift between client cache and authority.

5. Tier and seat correctness
- MUST enforce Team seat limits and Enterprise contract limits in all modes.
- MUST prevent quota bypass via local file deletion/tampering.
- MUST include deterministic fallback behavior when authority is unavailable.

#### 8.9.2 Task Plan (`17.51`–`17.60`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.51 | Introduce entitlement enforcement modes (`saas`, `private_relay`, `airgap`) in API/CLI settings and contracts | Unit tests for mode parsing + integration tests per mode | Mode selection is explicit, validated, and backward-compatible |
| 17.52 | Replace local quota authority with server-attested entitlement/usage checks for hosted tiers | API + CLI integration tests proving local quota tamper does not bypass limits | Free/paid limits cannot be bypassed by deleting local files |
| 17.53 | Add signed entitlement token format (issuer/audience/exp/nonce) with Ed25519 verification + key rotation | Crypto unit tests + replay/expiry negative tests | Entitlement verification is deterministic and tamper-evident |
| 17.54 | Add usage ledger service + reconciliation endpoint (authoritative count, drift detection) | Contract tests + reconciliation correctness tests | Usage authority is centralized and drift is detected/repaired |
| 17.55 | Build private relay mode for enterprise CI (internal verifier proxy, no external egress from pipeline) | E2E test with mocked internal relay + no-egress assertion tests | Enterprise CI can enforce tiers without internet egress |
| 17.56 | Build air-gap entitlement pack flow (signed offline bundle + expiry + grace behavior) | Offline pack sign/verify tests + expiry/fail-open/fail-closed tests | Air-gapped enforcement works with explicit operational boundaries |
| 17.57 | Enforce Team/Enterprise seat + contract limits across all execution paths (CLI/API/CI) | Integration tests for seat assignment/revocation and overage handling | Seat/contract controls are consistent and deterministic |
| 17.58 | Add anti-replay and clock-skew handling for entitlement validation | Unit tests for nonce replay, skew windows, and deterministic errors | Replay and skew abuse are blocked with stable error semantics |
| 17.59 | Add hybrid-mode observability and audit exports (entitlement decision logs, usage provenance, reconciliation reports) | Telemetry contract tests + redaction tests + export snapshot tests | Security/compliance teams can audit every enforcement decision |
| 17.60 | Documentation + rollout runbook for hybrid enforcement migration (self-serve to enterprise private/airgap) | Docs link/snippet tests + migration dry-run checklist tests | Migration path is production-ready and supportable |

#### 8.9.3 Execution Order (Dependency-Driven)

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Enforcement Contract | 17.51, 17.52 | Define authority model and remove local tamper path first | Hosted tiers enforced by authority, not local cache |
| B. Crypto and Accounting Core | 17.53, 17.54, 17.58 | Integrity + replay safety + authoritative usage are foundation | Signed, replay-safe claims and reconciled usage ledger live |
| C. Enterprise No-Egress Modes | 17.55, 17.56, 17.57 | Deliver private/airgap paths and seat/contract correctness | Enterprise CI works without outbound internet calls |
| D. Operability and Rollout | 17.59, 17.60 | Ensure auditability and safe migration to new model | Hybrid rollout can be operated and audited in production |

#### 8.9.4 Production Readiness Gate (Hybrid Enforcement)

- [x] Local quota file is non-authoritative and cannot unlock additional hosted scans.
- [x] Hosted tiers enforce server-attested usage/entitlements with deterministic errors.
- [x] Signed entitlement tokens are validated (signature, issuer, audience, expiry, replay).
- [x] Team/Enterprise seat and contract limits are enforced across CLI/API/CI paths.
- [x] Private relay mode supports no-egress enterprise CI/CD pipelines.
- [x] Air-gap entitlement pack flow works with explicit expiry and documented grace policy.
- [x] Reconciliation detects and resolves usage drift; audit trail is exportable.
- [x] Rollout/migration runbook is tested and approved by Security + Platform + Support.

---

### 8.10 Runtime Moat Completion (`17.61`–`17.66`)

**Goal:** Promote runtime gateway from foundational wrapper to enforceable moat with constrained execution, cryptographic runtime provenance, trust propagation lineage, and CI wrapper governance.

#### 8.10.1 Task Plan (`17.61`–`17.66`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.61 | Runtime policy engine for `run/gateway`: unified pre-exec checks (risk + entitlement + allowlist + sandbox decision) | Unit tests for decision matrix + CLI integration tests for allow/block paths | Runtime decisions are deterministic and signed before execution |
| 17.62 | Constrained runtime execution controls: command-class allowlist + hardened sandbox backend requirement for `ci/prod/strict` | Unit tests for class detection/allowlist + strict-mode backend enforcement tests | Unapproved tool classes blocked; hardened modes fail when sandbox unavailable |
| 17.63 | AI-BOM attestation hardening: signed runtime attestation token verification replacing marker-only checks | Unit tests for valid/invalid signatures + integration tests through `bom validate` and `run` | Runtime BOM gate validates cryptographic skill attestation and hash binding |
| 17.64 | Trust propagation and lineage DAG v2: verify inbound scope token, capture parent-child lineage edges, sign artifact chain | Unit tests for token verification errors + DAG artifact signature/integrity tests | Child invocations without valid scope chain are blocked; lineage reconstructable |
| 17.65 | Wrapper-only CI governance: runtime hook support in CI templates + automated bypass detector | CI template tests + unit tests for bypass detector script | Direct agent CLI execution outside `skillgate run` is detectable and gateable |
| 17.66 | TOP guard hardening: structural injection detection beyond regex baseline | Unit tests for structural signals + integration tests for block/annotate behavior | TOP guard catches adversarial role/override/imperative structures deterministically |

#### 8.10.2 Execution Status

| Task | Status | Evidence |
|---|---|---|
| 17.61 | Implemented | `skillgate/core/gateway/runtime_engine.py`, runtime command wiring in `run.py` and `gateway.py` |
| 17.62 | Implemented | `skillgate/core/gateway/allowlist.py`, `skillgate/core/gateway/sandbox.py` |
| 17.63 | Implemented | Signed attestation token creation/verification in `skillgate/core/gateway/bom_gate.py` |
| 17.64 | Implemented | Scope-token verification + lineage edge recording in session artifacts (`session.py`, `run.py`, `gateway.py`) |
| 17.65 | Implemented | CI template runtime wrapper hooks + `scripts/quality/check_wrapper_enforcement.py` |
| 17.66 | Implemented | Structural TOP signals added in `skillgate/core/gateway/top_guard.py` |

#### 8.10.3 Production Readiness Gate (Runtime Moat)

- [x] Runtime precheck flow is centralized and deterministic.
- [x] Command-class allowlist enforced before execution.
- [x] Hardened environments enforce sandbox backend presence.
- [x] AI-BOM runtime gate supports cryptographic attestation validation.
- [x] Scope-token chain is validated for parent-child trust propagation.
- [x] Session artifact includes lineage edges and remains signature-verifiable.
- [x] CI templates support wrapper-only runtime invocation path.
- [x] Wrapper bypass detector script is available for CI gating.
- [x] TOP guard includes structural injection detection.

---

### 8.11 Category-Defining Moat Expansion (`17.67`–`17.70`)

**Goal:** Add difficult-to-copy control-plane differentiators: org-scale simulation, transitive lineage scoring, global skill intelligence, and capability budgeting.

#### 8.11.1 Task Plan (`17.67`–`17.70`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.67 | Policy simulation mode (`skillgate simulate`) for org/repo dry-runs (`what breaks if strict policy is enabled`) with fail-rate and top-violation summaries | CLI unit tests for human/json output + exit-code behavior + policy-path handling | Teams can estimate rollout impact before enforcement without executing runtime controls |
| 17.68 | Transitive agent privilege/risk graph over lineage edges: compute depth, high-risk path count, and blast radius from signed DAG artifacts | Unit tests for DAG risk calculator + fixture-based path-depth assertions | Signed lineage artifacts produce deterministic transitive risk metrics |
| 17.69 | Global skill reputation graph foundation (opt-in anonymized telemetry schema + signed reputation ingest/export contracts) | Schema validation tests + signature verification tests + redaction tests | Reputation signals are privacy-safe, signed, and ready for network effects |
| 17.70 | Agent capability budget model (network/shell/filesystem budgets per session/org) with deterministic over-budget block semantics | Unit tests for budget accounting + integration tests on runtime wrapper paths | Runtime can enforce capability budgets as first-class policy controls |

#### 8.11.2 Execution Status

| Task | Status | Evidence |
|---|---|---|
| 17.67 | Implemented | `skillgate/cli/commands/simulate.py` + CLI tests for preset/file-path policies and fail-on-failures |
| 17.68 | Implemented | `skillgate/core/gateway/lineage.py` computes high-risk path count; `skillgate dag risk` enforces signed-artifact verification by default |
| 17.69 | Implemented | Runtime reputation policy with redacted bundle-hash output (`skillgate/core/reputation/policy.py`) + signed graph CLI (`skillgate reputation verify/check`) |
| 17.70 | Implemented | Scoped capability budgets (`global`, `org`, `session`) in `skillgate/core/gateway/budget.py` + runtime wrapper integration (`run`, `gateway check`) |

#### 8.11.3 Production Readiness Gate (Category Moat)

- [x] `skillgate simulate` returns deterministic policy impact metrics and supports CI-style fail exit.
- [x] `skillgate dag risk` verifies artifact signatures before risk scoring and computes high-risk path count, depth, and blast radius.
- [x] Runtime gateway enforces signed reputation verdicts for skill hashes in hardened environments.
- [x] `skillgate reputation verify/check` supports signed graph integrity checks and deterministic policy outcomes.
- [x] Capability budgets enforce deterministic over-budget blocks in hardened environments.

---

### 8.12 Control Plane Dominance Expansion (`17.71`–`17.77`)

**Goal:** Extend SkillGate from strong gateway foundation to category-defining control plane with org-scale simulation, intelligence network ingestion, executive narratives, approval governance, and drift control.

#### 8.12.1 Task Plan (`17.71`–`17.77`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.71 | Transitive risk graph v2: add lateral movement potential and secret exposure radius to signed DAG risk output | Unit tests for graph metrics + CLI JSON snapshot tests | `dag risk` reports depth, high-risk path count, blast radius, lateral movement, secret exposure radius |
| 17.72 | Capability budget model v2: add external domain budget and deterministic domain-chain accounting | Unit tests for domain accounting + wrapper integration tests | Runtime blocks on domain budget overrun with signed decision evidence |
| 17.73 | Global skill reputation graph ingest: opt-in signed anonymized `reputation submit` outbox flow and contract | CLI unit tests + signature verification tests + redaction tests | Signed anonymized submissions are generated locally and export-ready for intel backend ingestion |
| 17.74 | Org-scale policy simulation: support `simulate --org <selector>` with fail-rate/top-violation/noise summaries | CLI unit tests for selector resolution + summary contract tests | Security teams can estimate org rollout impact from one command |
| 17.75 | Executive explanation mode: CISO-ready explanation profile (`Risk / Impact / Likelihood / Control`) | Unit tests for template/engine + CLI tests for scan JSON output | `scan --explain --explain-mode executive` emits deterministic executive summaries |
| 17.76 | Agent approval workflow foundations: require signed skill + reviewer quorum metadata in hardened release paths | Policy + runtime integration tests + negative tests for unsigned/unapproved artifacts | Production enforcement blocks unapproved skill promotions deterministically |
| 17.77 | Skill drift detection: baseline capture + drift report for new permissions/domains/transitive paths/unsigned artifacts | Unit tests for baseline diff engine + CLI integration tests | Teams can detect and gate drift between approved baseline and current fleet state |

#### 8.12.2 Execution Status

| Task | Status | Evidence |
|---|---|---|
| 17.71 | Implemented | Lineage v2 metrics in `skillgate/core/gateway/lineage.py` + `dag risk` output fields |
| 17.72 | Implemented | External domain/domain-chain budgets in `skillgate/core/gateway/budget.py` + runtime integration |
| 17.73 | Implemented | `skillgate reputation submit --anonymized` signed outbox flow in `skillgate/cli/commands/reputation.py` |
| 17.74 | Implemented | Org selector support in `skillgate simulate --org ...` (`skillgate/cli/commands/simulate.py`) |
| 17.75 | Implemented | `scan --explain-mode executive` with deterministic executive templates |
| 17.76 | Implemented | Signed approval workflow (`approval sign/verify`) + hardened runtime quorum enforcement (`run`/`gateway check`) |
| 17.77 | Implemented | Drift baseline/check commands (`skillgate drift baseline/check`) with CI-style fail semantics |

#### 8.12.3 Production Readiness Gate (Control Plane Expansion)

- [x] `dag risk` includes transitive lateral movement and secret exposure radius metrics.
- [x] Runtime budgets can enforce external domain budgets in hardened environments.
- [x] `reputation submit --anonymized` creates signed local submission events for intel ingestion.
- [x] `simulate --org` supports deterministic org-scale selectors.
- [x] `scan --explain --explain-mode executive` outputs deterministic CISO-ready summaries.
- [x] Approval workflow gates block unsigned/unapproved production promotions.
- [x] Drift command can diff approved baseline vs current state with CI-usable exit semantics.

---

### 8.13 Fleet Governance Expansion (`17.78`–`17.84`)

**Goal:** Evolve from single-bundle scanning to repository/org-level agent fleet governance with deterministic per-skill isolation, fleet summaries, and CI-grade rollout controls.

#### 8.13.1 Task Plan (`17.78`–`17.84`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.78 | Introduce explicit fleet mode: `skillgate scan --fleet <path>` that discovers skill bundles under directory roots and scans each bundle independently | CLI unit tests for discovery + ordering + per-bundle isolation + malformed-bundle handling | Fleet mode scans folder-of-skills deterministically without collapsing all code into one pseudo-bundle |
| 17.79 | Fleet discovery model: recognize bundle roots via `SKILL.md` OR supported manifest OR policy-configured roots; add strict mode `--require-skill-manifest` | Unit tests for discovery heuristics + strict-mode negative cases + policy selector tests | Fleet discovery is flexible by default and enforceable in hardened environments |
| 17.80 | Fleet output contract: per-skill results + fleet summary (pass/fail counts, fail-rate, critical count, unsigned/stale attestation counts) in human/json modes | CLI snapshot tests for human/json schema + exit-code behavior (`--fail-on-any`, `--fail-on-threshold`) | CI and dashboards can consume deterministic fleet-level and skill-level outcomes |
| 17.81 | Fleet policy extensions: add `fleet.skill_roots`, `fleet.exclude`, `fleet.require_manifest`, and fail-threshold controls to policy schema | Policy schema/loader tests + backward compatibility tests + docs contract tests | Fleet behavior is policy-driven and versioned without breaking existing single-bundle usage |
| 17.82 | Fleet performance architecture: parallelize at bundle level with bounded workers, per-bundle failure isolation, and deterministic output ordering | Integration tests for parallel determinism + latency benchmarks on 50/100 skill fixtures + memory guard tests | Fleet scans are production-viable for large repos and remain deterministic |
| 17.83 | Fleet baseline and drift integration: support `drift baseline/check --fleet` using per-skill keys and fleet delta summaries | Unit tests for fleet baseline schema + diff assertions + CLI integration tests | Teams can detect and gate fleet drift (new risky skills, permission/domain deltas, unsigned/stale artifacts) |
| 17.84 | Registry/ecosystem intake foundations: unify URL/archive intake into fleet model (`github:org/repo`, archive bundles) with hardened extraction guards | Ingestion tests for URL/archive selectors + extraction safety regression tests | SkillGate can scan external skill ecosystems as fleet inputs with secure extraction boundaries |

#### 8.13.2 Execution Status

| Task | Status | Evidence |
|---|---|---|
| 17.78 | Implemented | Explicit fleet mode in `skillgate/cli/commands/scan.py` (`--fleet`) with per-bundle isolation via `skillgate/core/parser/fleet.py` |
| 17.79 | Implemented | Fleet discovery heuristics + strict mode in `skillgate/core/parser/fleet.py` and scan flags (`--require-skill-manifest`) |
| 17.80 | Implemented | Fleet output contract in `skillgate/core/models/report.py` (`fleet_summary`, `fleet_results`) and human/json formatters/tests |
| 17.81 | Implemented | `fleet.*` policy schema in `skillgate/core/policy/schema.py` (`FleetConfig`) with loader/schema tests |
| 17.82 | Implemented | Bundle-level parallel scanning (`ThreadPoolExecutor`) with deterministic ordering in `skillgate/cli/commands/scan.py` |
| 17.83 | Implemented | Fleet drift flows in `skillgate/cli/commands/drift.py` (`drift baseline/check --fleet`) with CLI tests |
| 17.84 | Implemented | URL/provider/archive intake (`github:`, `gitlab:`, `forge:`) + hardened extraction guards in `skillgate/cli/remote.py`, integrated with fleet scan path |

#### 8.13.3 Production Readiness Gate (Fleet Governance)

- [x] `scan --fleet` performs deterministic per-skill isolation and never merges unrelated skill roots into one result.
- [x] Fleet JSON output includes both `fleet_summary` and per-skill records with stable schema/versioning.
- [x] Policy schema supports fleet selectors/thresholds with full backward compatibility for existing policies.
- [x] Fleet scanning is parallelized with deterministic ordering and bounded resource usage.
- [x] Fleet drift workflows support baseline/check with CI-usable fail semantics.
- [x] URL/archive ingestion into fleet mode enforces extraction safety limits (size/depth/path traversal/symlink/file-count guards).

---

### 8.14 Control Plane Narrative + Pricing Conversion Architecture (`17.85`–`17.97`)

**Goal:** Align product narrative, homepage information architecture, and pricing psychology to communicate SkillGate as AI agent governance infrastructure and increase Pro/Team conversion while justifying Enterprise ($10K+).

#### 8.14.1 Positioning Contract (Must Be Reflected in UI + Copy + Entitlements)

1. Global narrative
- Replace scanner-led framing with: "Deterministic governance and runtime control for AI agents."
- Primary tagline candidates to test:
  - `SkillGate — The Control Plane for AI Agent Execution`
  - `SkillGate — Deterministic Governance for AI Skills and Agents`

2. Control stack framing (required block above pricing)
- Visual stack order:
  - `Static Scan`
  - `Policy Engine`
  - `CI Enforcement`
  - `Runtime Gateway`
  - `Capability Budgets`
  - `Trust Propagation`
  - `Intelligence Graph`
- Tier mapping contract:
  - Free = `Static Scan`
  - Pro = `Static Scan + Policy Engine`
  - Team = `Static + Policy + CI Enforcement + Fleet Governance`
  - Enterprise = `Full Control Stack`

3. Tier narrative contract
- Free: individual developer visibility.
- Pro: full static governance, explicit "no CI blocking" boundary.
- Team: engineering team governance, fleet scanning and PR enforcement.
- Enterprise: AI agent control plane, org-wide runtime and trust infrastructure.

4. Enterprise value anchors (must be visible in Enterprise card + deep compare matrix)
- Runtime capability budgets
- Transitive risk graph
- Trust propagation lineage DAG
- Signed AI-BOM with cryptographic provenance
- Private relay and air-gapped enforcement modes
- Signed reputation graph integration
- Org-scale policy simulation
- Dedicated signing namespaces
- Audit-grade export bundles
- Compliance modes (EU AI Act, SOC 2 alignment)
- Governance APIs

#### 8.14.2 Task Plan (`17.85`–`17.97`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.85 | Homepage narrative rewrite: shift hero/value proposition from scanner framing to control-plane framing | Marketing copy review + snapshot tests for hero/section rendering | Homepage consistently communicates control-plane category from first viewport |
| 17.86 | Add "SkillGate Control Stack" visual module above pricing with 7-layer stack and tier mapping | Component tests + visual regression snapshots | Control stack block is live, responsive, and accessible |
| 17.87 | Re-architect pricing table information hierarchy by governance layer (Static, CI, Runtime/Org Control) | Unit tests for pricing data schema + rendering tests | Table reads as layered control maturity, not feature checklist |
| 17.88 | Tier copy refactor: Free visibility, Pro static governance, Team CI/fleet governance, Enterprise control plane | Content contract tests + snapshot tests | Tier intent is explicit and non-overlapping |
| 17.89 | Add Team+ fleet governance surfacing: `--fleet`, multi-skill governance, org risk posture summary | Pricing data tests + docs-link tests | Fleet governance is visible and consistent with product capabilities |
| 17.90 | Enterprise column redesign: "AI Agent Control Plane" label + infrastructure-first feature anchors + strategic badge treatment | Visual regression + a11y contrast checks + mobile layout tests | Enterprise card is visually and semantically differentiated as infrastructure tier |
| 17.91 | Add expandable deep compare matrix under pricing with control-plane capabilities and compliance/governance rows | Interaction tests + keyboard navigation tests | Buyers can inspect full capability matrix without leaving pricing page |
| 17.92 | Pricing/entitlement consistency pass: ensure UI claims exactly match tier gates in CLI/API resolver | Contract tests between `docs/CLAIM-LEDGER.yaml`, backend pricing catalog claim IDs, entitlement capability/limit map, proof paths, and test references (`scripts/quality/check_claim_ledger.py` in CI) | Zero drift between marketed features and enforced capabilities |
| 17.93 | Enterprise procurement path hardening: add governance API, audit bundle, compliance mode, and deployment model callouts in docs/pricing links | Link integrity + docs rendering tests | Enterprise buyer path is explicit and procurement-ready |
| 17.94 | Conversion psychology instrumentation: measure control-stack interactions, tier CTA funnel, matrix expansion, sales-contact conversion | Analytics payload tests + E2E event tests | Pricing funnel exposes tier-level behavior with no PII leakage |
| 17.95 | A/B experiment framework for pricing narrative order (feature-led vs control-layer-led) and Enterprise emphasis | Experiment assignment tests + analytics integrity checks | Experiments can run safely with deterministic event attribution |
| 17.96 | Sales enablement package: one-page "Why Enterprise = Control Plane Infrastructure" and objection-handling playbook | Content lint checks + internal review checklist | Sales and founder narrative is aligned with UI/plan positioning |
| 17.97 | Launch gate for pricing repositioning: legal/compliance review + support readiness + rollback criteria for copy/pricing IA | Launch checklist tests + staged rollout rehearsal | Pricing narrative release has explicit go/no-go and rollback path |

#### 8.14.3 Execution Order (Dependency-Driven)

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Narrative Foundation | 17.85, 17.88 | Core message and tier intent must stabilize before UI rearrangement | Messaging approved and reflected in all tier summaries |
| B. Pricing IA + Control Stack | 17.86, 17.87, 17.90 | Build visual model that makes control-plane progression intuitive | Control stack + pricing hierarchy render consistently on desktop/mobile |
| C. Capability Proof Layer | 17.89, 17.91, 17.92, 17.93 | Surface real moat capabilities and prove entitlement truth | Deep matrix and enterprise anchors are live and contract-tested |
| D. Conversion + GTM Hardening | 17.94, 17.95, 17.96, 17.97 | Instrument, optimize, and operationalize before broad rollout | Funnel telemetry and rollout safeguards active with documented sales playbook |

#### 8.14.4 Production Readiness Gate (Narrative + Conversion)

- [x] Control-plane framing is first-class on homepage and pricing entrypoints.
- [x] Pricing visually maps tiers to control layers and product maturity.
- [x] Team tier clearly includes fleet governance in both UI and entitlement contract.
- [x] Enterprise card and deep matrix position Enterprise as governance infrastructure.
- [x] No pricing claim exists without enforceable API/CLI entitlement backing.
- [x] Funnel analytics covers view -> CTA -> checkout/contact -> activation by tier.
- [x] Rollback plan is rehearsed for messaging/IA regression or conversion drop.

Pre-GA blocker note (2026-02-19):
- Pricing narrative gate closes only when CI remains green for `17.86`, `17.87`, `17.90`, `17.91`, `17.94`, and `17.97` contracts (component/data/docs tests).
- Release messaging remains truth-first; any claim drift re-opens this gate immediately.

### 8.15 Truth-First Claim Restoration Backlog (Post-17.97)

**Goal:** Keep public pricing truth-safe today while restoring moat claims only after enforceable implementation ships.

#### 8.15.1 Claim Ledger Anti-Drift Control

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.98 | Create versioned Claim Ledger source of truth (`UI sentence -> entitlement key -> proof surface -> test -> owner`) | Schema validation tests + duplicate-id checks | Ledger exists, versioned, and covers all pricing/homepage claims |
| 17.99 | Add CI claim-ledger gate (fail build when active UI claim has no ledger row or no enforceable proof) | CI job + fixture tests against sample claim set | Drift from UI-to-contract is blocked pre-merge |
| 17.100 | Add claim status lifecycle (`safe`, `needs_qualifier`, `remove`) and release policy | Unit tests for status parser + policy checks | Release blocks claims marked `remove` or missing qualifier |

#### 8.15.2 Removed-Claim Restoration (Tiered)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.101 | SSO/SAML implementation path: provider config, auth flow, entitlement gate, UI contract | API auth integration tests + entitlement gate tests + docs acceptance tests | SSO/SAML can return to Enterprise copy with enforceable proof |
| 17.102 | Custom policy packs enforcement path (CLI/API) with explicit tier gating and audit log trail | CLI gating tests + API policy-pack tests + audit export tests | Custom policy pack claims are enforceable and traceable |
| 17.103 | Dedicated signing namespaces controls with policy-surface enforcement and key ownership isolation | Signing namespace unit tests + integration tests + negative-path tests | Namespace claim is enforceable, not copy-only |
| 17.104 | Runtime capability budgets hardening in gateway with policy decision evidence | Runtime gateway tests + denied-action tests + evidence bundle tests | Runtime budget claim is safely marketable as Enterprise control |
| 17.105 | Transitive trust/risk graph API exposure and entitlement-safe UI surfacing | Graph API tests + entitlement tests + snapshot tests | Trust graph claim can be restored with measurable proof |

#### 8.15.3 Backend-Driven Marketing Roadmap

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.106 | Backend roadmap endpoint for current removals + restoration backlog consumed by `web-ui` | API contract tests + UI rendering tests | Roadmap content updates from backend without page-level code edits |
| 17.107 | Add product ops workflow: every restored claim requires ledger update + proof link + test reference | Process checklist tests + release template checks | No restored claim ships without evidence chain |

#### 8.15.4 Current State

- [x] Backend-driven roadmap endpoint and roadmap page are live.
- [x] Truth-first copy patch is live for high-risk claims.
- [x] Claim Ledger CI gate is fully enforced for all homepage/pricing claims.
- [ ] Removed claims are restored only after proof-complete implementation.
- [ ] Reliability gate `tests/slo/test_false_positive_rate.py` is green for GA sign-off.

---

### 8.16 Agent Orchestration Platform (Feature 1) (`17.108`–`17.121`)

**Goal:** Add enterprise-safe background agents as durable, auditable workflows while keeping local CLI deterministic and policy-first.

#### 8.16.1 Current-State Audit (2026-02-20)

- `skillgate` currently exposes command/subcommand workflows (`scan`, `run`, `hunt`, `retroscan`, `gateway`, etc.) with no `agent` job orchestration surface.
- Runtime gateway controls, signed artifacts, capability budgets, and approval primitives already exist and should be reused as the policy guard layer.
- Existing hosted API and worker infrastructure can host orchestrator queues/jobs; do not run long-lived agents inside CLI process.

#### 8.16.2 Requirements Contract

1. Functional requirements
- Add thin-client CLI agent surface: `skillgate agent run|ls|logs|approve|pause|cancel`.
- Implement backend orchestrator lifecycle: `queued -> running -> paused -> awaiting_approval -> completed|failed|canceled`.
- Support initial agent archetypes: PR triage, remediation proposal, policy migration recommendation, compliance evidence pack generation.
- Enforce artifact-first writes: code changes must be patch/PR based; never direct push to protected branches.
- Require explicit approval boundaries for repo writes, policy changes, secret access, and high-risk commands.

2. Security and governance requirements
- Capability-based tool permissions per job and per sub-agent; default-deny network and secrets.
- Every tool invocation must be policy-checked by SkillGate before execution.
- Immutable audit ledger with actor, input, rationale summary, tool call metadata, outputs, and signed artifact references.
- Per-job kill switch, pause/resume, and deterministic budget caps (agents, tool calls, tokens/time).

3. Non-functional requirements
- Durable retries with idempotency keys for orchestrator actions and webhook callbacks.
- Deterministic replay of completed jobs from stored state snapshots and artifact pointers.
- Multi-tenant isolation with RBAC and tier-aware capability limits.

#### 8.16.3 Task Plan (`17.108`–`17.121`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.108 | Add `agent` CLI command group (`run`, `ls`, `logs`, `approve`, `pause`, `cancel`) as thin client to orchestrator APIs | CLI command tests + API contract tests | CLI submits and streams jobs without local long-running execution |
| 17.109 | Orchestrator service: durable job state machine + queue + retries + timeout handling | Unit tests for lifecycle transitions + idempotency tests | State transitions are deterministic and auditable |
| 17.110 | Tool runtime contract: repo-read, patch-generate (temp branch), test-runner, constrained network, constrained secrets | Tool authz tests + sandbox tests | Tools enforce capability scopes and cannot exceed job grants |
| 17.111 | Policy-in-the-loop enforcement on plan steps, file mutations, command execution, and outbound requests | Integration tests for allow/deny matrix + regression tests | Every tool step passes through SkillGate policy gate |
| 17.112 | Approval checkpoint engine with signed approvals and segregation-of-duties support | Approval workflow tests + signature verification tests | Blocking checkpoints require valid approval artifacts |
| 17.113 | Audit ledger + evidence artifact model (diffs, SARIF, run logs, sign-offs, rationale summaries) | Ledger integrity tests + export tests | Full provenance available for each job and step |
| 17.114 | PR Triage Agent v1 (read-only): run checks, summarize risk, propose remediations, optional issue/comment outputs | E2E tests on sample PR fixtures | Agent generates deterministic triage artifacts |
| 17.115 | Remediation PR Agent v2: generate patch + tests/docs updates + open PR workflow with validations | E2E tests for branch/PR flow + policy checks | Agent can open remediation PRs without direct main writes |
| 17.116 | Policy Copilot v2: policy migration suggestions and incident-driven guardrail recommendations | Policy suggestion quality tests + backward-compat tests | Suggestions are explainable, versioned, and non-destructive |
| 17.117 | Compliance Agent v2: scheduled evidence pack and audit export pipeline | Schedule/job tests + export contract tests | Compliance artifacts are export-ready and reproducible |
| 17.118 | Sub-agent decomposition runtime with quota model (max agents/tool calls/time/tokens) | Budget accounting tests + abuse tests | Sub-agents cannot spawn beyond configured limits |
| 17.119 | RBAC + enterprise controls (SSO-bound actor identity, role-scoped approvals, retention settings) | Authz integration tests + retention tests | Enterprise governance controls are enforceable |
| 17.120 | Kill switch + emergency pause controls at org/job level | Chaos tests + operator runbook drill tests | Operators can stop active jobs deterministically |
| 17.121 | Agent evaluation harness (red-team + jailbreak/bypass scenarios + false-action metrics) | Security evaluation suite + mutation tests | Agent release blocked on red-team quality gates |

#### 8.16.4 Phased Delivery Blueprint

- v1 (minimal enterprise shape): `17.108`–`17.114`
- v2 (safe remediation + policy/compliance automation): `17.115`–`17.117`
- v3 (sub-agents + enterprise hardening): `17.118`–`17.121`

#### 8.16.5 Ship Gate

- [ ] Agent orchestration runs server-side with durable state and auditable provenance.
- [ ] CLI is thin-client only for background jobs (submit, stream, approve, inspect).
- [ ] All write actions are artifact-first and approval-gated.
- [ ] Policy gate evaluates every tool invocation.
- [ ] Kill switch, pause/resume, and quota controls are enforced and tested.

---

### 8.17 Dual-Mode CLI (Session + One-Shot) (Feature 2) (`17.122`–`17.132`)

**Goal:** Support both interactive session workflows and deterministic one-shot execution without fragmenting existing `scan`/policy semantics.

#### 8.17.1 Current-State Audit (2026-02-20)

- Root CLI currently prints branding/help when no subcommand is provided; no REPL/session runtime exists.
- Deterministic one-shot usage already exists via explicit subcommands (`scan`, `run`, etc.) but there is no prompt-first entrypoint (`skillgate -p "..."`).
- Existing output formats (`human|json|sarif`) and exit behavior can be reused as baseline for one-shot contracts.

#### 8.17.2 Requirements Contract

1. UX and command surface
- `skillgate` -> open REPL session.
- `skillgate "<prompt>"` -> open session seeded with first prompt.
- `skillgate -p "<prompt>"` -> one-shot mode, non-interactive, deterministic output.
- Add `.skillgate/` convention autoload:
  - `.skillgate/instructions.md` (behavior/instruction context)
  - `.skillgate/policy.yaml` (policy-as-code defaults)
- Add user-scope defaults:
  - `~/.skillgate/instructions.md`
  - `~/.skillgate/policy.yaml`
- Precedence (highest -> lowest):
  - explicit CLI flags
  - repo-local `.skillgate/*`
  - user-scope `~/.skillgate/*`
  - built-in defaults
- Keep agent execution explicit under `skillgate agent ...`; do not overload one-shot prompt mode.

2. Output and automation contract
- One-shot must support `--format text|json|sarif` and `--out <file>`.
- One-shot stdout must be machine-stable in `json|sarif` modes (no banner/UI noise).
- Session mode remains suggest-first unless user explicitly invokes apply/run actions.

3. Exit code contract
- Preserve existing deterministic core: `0` pass, `1` policy/entitlement fail, `2` internal error, `3` invalid input/config.
- Add optional `4` for partial results/timeouts where output is produced but incomplete.
- Provide explicit compatibility notes in docs and CI templates for new code `4`.

#### 8.17.3 Task Plan (`17.122`–`17.132`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.122 | Add root session runtime (REPL loop, command history, interrupt handling, prompt routing) | REPL unit tests + interaction E2E tests | `skillgate` opens stable interactive session |
| 17.123 | Add prompt-seeded session mode (`skillgate "<prompt>"`) | CLI parsing tests + session start tests | Prompt argument starts session with first turn |
| 17.124 | Add one-shot prompt mode (`-p/--prompt`) with non-interactive execution | CLI/E2E tests for non-interactive behavior | One-shot runs and exits without REPL |
| 17.125 | Implement `--interactive/--no-interactive` override semantics | CLI flag matrix tests | Invocation mode selection is deterministic |
| 17.126 | Add auto-load + explicit flags for instruction/policy files (`--instructions-file`, `--policy-file`) including repo-local and user-scope defaults | Loader tests + precedence tests | Repo + user defaults and overrides work predictably with deterministic precedence |
| 17.127 | Add one-shot output controls (`--format`, `--out`) with schema stability checks | Formatter tests + schema contract tests | JSON/SARIF outputs are stable and CI-safe |
| 17.128 | Implement partial-result signaling and exit code `4` semantics for timeout/interruption cases | Timeout/interruption tests + backward-compat tests | Partial outputs are marked and exit with code `4` |
| 17.129 | Update CI docs/templates to support prompt one-shot mode and new exit code handling | Docs tests + template tests | CI examples are accurate and deterministic |
| 17.130 | Add telemetry for mode usage and failure classes (no prompt content logging) | Telemetry payload tests + privacy tests | Product can measure adoption without sensitive leakage |
| 17.131 | Harden UX guardrails: no implicit side effects in session mode unless explicit user action | Safety regression tests | Session interactions are non-destructive by default |
| 17.132 | Add migration guide from subcommand-only flows to dual-mode CLI | Docs lint/link tests + copy review | Existing users can adopt new modes without breakage |

#### 8.17.4 Ship Gate

- [ ] `skillgate`, `skillgate "<prompt>"`, and `skillgate -p "<prompt>"` all work with deterministic mode behavior.
- [ ] One-shot mode supports stable `json|sarif` outputs and file output contract.
- [ ] Repo-local and user-scope autoload works with documented precedence (`./.skillgate/*` over `~/.skillgate/*`).
- [ ] Exit code behavior is documented, tested, and CI-template compatible.
- [ ] Session mode remains suggest-first and does not execute risky actions implicitly.

---

## 9. Definition of Done

### 9.1 Per-Task DoD

Every task is done when:

- [ ] Implementation complete
- [ ] Unit tests written and passing
- [ ] Integration tests updated if cross-module
- [ ] E2E tests updated if user-facing
- [ ] `ruff check` passes (zero errors)
- [ ] `mypy --strict` passes (zero errors)
- [ ] Coverage ≥90% on changed modules
- [ ] Code reviewed (or self-reviewed with checklist)
- [ ] Documentation updated if public API changed
- [ ] No TODO/FIXME left without tracking issue

### 9.2 Per-Sprint DoD

Every sprint is done when:

- [ ] All sprint tasks meet per-task DoD
- [ ] Full test suite passes (`pytest` green)
- [ ] CI pipeline green on main branch
- [ ] Sprint ship gate checklist complete
- [ ] CHANGELOG updated
- [ ] Version bumped if releasing

### 9.3 Production-Readiness Checklist

Before any feature is considered production-ready:

- [ ] Happy path tested (unit + integration + E2E)
- [ ] Error paths tested (invalid input, missing files, malformed data)
- [ ] Edge cases tested (empty input, huge input, unicode, binary)
- [ ] Performance budget met
- [ ] Security implications reviewed
- [ ] Backward compatibility preserved (or documented breaking change)
- [ ] Rollback plan exists (version pinning, previous release available)

---

## 10. Revenue Milestones

| Milestone | Timeline | Trigger | Target |
|---|---|---|---|
| **First charge** | Day 30 | Sprint 4 complete, Pro tier live | 5–10 Pro users |
| **$1K MRR** | Day 60 | Content marketing + GitHub Action adoption | 20 Pro + 5 Team |
| **$5K MRR** | Day 120 | CI lock-in + word of mouth | 50 Pro + 20 Team |
| **$10K MRR** | Day 180 | Enterprise pilots begin | 80 Pro + 30 Team + 2 Enterprise |
| **$25K MRR** | Day 365 | Enterprise motion + expansion | 150 Pro + 60 Team + 5 Enterprise |
| **$80K MRR** | Day 545 | Market leadership + MCP expansion | 300 Pro + 120 Team + 15 Enterprise |

---

## 11. Risk Mitigation Timeline

| Risk | When Critical | Mitigation Action | Deadline |
|---|---|---|---|
| Overbuilding before revenue | Sprint 1–3 | Strict sprint gates, no scope creep | Day 17 |
| Detection layer commoditized by major vendor launches (e.g., Claude Code Security) | Immediate (Month 0–3) | Reposition around governance/enforcement/evidence, fast-track orchestration v1, and publish measurable reliability proof | Day 45 |
| High false positive rate | Sprint 1–2 | Invest in test corpus, tune rules | Day 14 |
| Low adoption of GitHub Action | Sprint 3–4 | Content marketing, direct outreach, free tier | Day 40 |
| Enterprise sales cycle too long | Month 3–6 | Focus on self-serve Pro/Team first | Day 90 |
| Burnout from solo execution | Ongoing | Hire first contractor at $5K MRR | Day 120 |

### 11.1 Mandatory Execution Pack

Before implementing risk mitigation controls or marking risk status as mitigated, use the execution pack in:

- `docs/section-11-risk-mitigation/README.md`
- `docs/section-11-risk-mitigation/BOUNDARIES.md`
- `docs/section-11-risk-mitigation/SPECS.md`
- `docs/section-11-risk-mitigation/TASKS.md`
- `docs/section-11-risk-mitigation/RALPH-LOOP.md`
- `docs/section-11-risk-mitigation/READINESS-GATES.md`
- `docs/section-11-risk-mitigation/VALIDATION-CHECKS.md`
- `docs/section-11-risk-mitigation/AGENT-SKILLS-MANDATORY.md`

These documents are fail-closed governance for Section 11 risk execution and release-risk claims.

---

## 12. Addendum (2026-02-20): Explanation CLI Naming + LLM Provider Extensibility

**Context:** Enterprise users should not be exposed to implementation-centric flag names such as `--explain-backend`. The CLI contract should be intent-first, while provider-specific selection remains explicit and extensible.

### 12.1 CLI Contract Correction

1. User-facing explanation controls (stable)
- `--explain`
- `--explain-mode technical|executive`
- `--explain-source auto|offline|ai`

2. Provider selection controls (advanced)
- `--llm-provider openai|anthropic|custom`
- `--llm-provider custom` activates provider-specific adapters via explicit config/env.

3. Backward compatibility
- Keep `--explain-backend` as deprecated alias for one major release.
- Emit deprecation warning with migration guidance.
- Remove from help text before removal from runtime parser.

### 12.2 `custom` Provider Requirements

- Provider adapters must support:
  - Azure OpenAI
  - Groq
  - Local runtimes (for example Ollama)
- Contract for custom adapter:
  - deterministic request/response schema for explanations
  - bounded timeout/retry policy
  - redaction-safe logging (no prompt content in telemetry by default)
  - fail-safe fallback to template explanations
- Policy/security constraints:
  - default deny outbound network unless explicitly enabled
  - explicit endpoint allowlist for hosted/custom providers
  - API key/secret handling follows secure storage + redaction standards already defined in Sprint 7.1 (`17.23`)

### 12.3 Task Additions

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.133 | Introduce new explanation flags (`--explain-source`, `--llm-provider`) and keep `--explain-backend` as deprecated alias | CLI parsing tests + backward-compat tests + help snapshot tests | New flags are primary; old flag works with warning |
| 17.134 | Implement provider abstraction for `openai`, `anthropic`, and `custom` adapter registry | Unit tests for provider resolution + adapter contract tests | Providers resolved deterministically from flags/config |
| 17.135 | Add built-in custom adapters: Azure OpenAI, Groq, Ollama | Integration tests with mocked clients + timeout/failure tests | All three adapters return explanation payloads via common contract |
| 17.136 | Add endpoint allowlist + network policy controls for explanation providers | Security tests for allow/deny matrix + config validation tests | Provider egress is policy-controlled and auditable |
| 17.137 | Add migration docs and enterprise operator guide for provider configuration | Docs lint/link tests + command examples validation | Upgrade path is clear with zero ambiguity |

### 12.4 Acceptance Gate

- [x] End-user help surface is intent-first (`source/provider`) and avoids backend jargon.
- [x] `--llm-provider custom` supports Azure OpenAI, Groq, and Ollama through a stable adapter contract.
- [x] Deprecated `--explain-backend` path is compatible and warning-gated.
- [x] All provider failures degrade to template explanations without scan failure.
- [x] Provider network access is explicit, restricted, and auditable.

### 12.5 Mandatory Execution Pack

Before implementing any Section 12 feature, use the execution pack in:

- `docs/section-12-explanation-provider-extensibility/README.md`
- `docs/section-12-explanation-provider-extensibility/BOUNDARIES.md`
- `docs/section-12-explanation-provider-extensibility/SPECS.md`
- `docs/section-12-explanation-provider-extensibility/TASKS.md`
- `docs/section-12-explanation-provider-extensibility/RALPH-LOOP.md`
- `docs/section-12-explanation-provider-extensibility/READINESS-GATES.md`
- `docs/section-12-explanation-provider-extensibility/VALIDATION-CHECKS.md`
- `docs/section-12-explanation-provider-extensibility/AGENT-SKILLS-MANDATORY.md`

These documents are fail-closed governance for Section 12 execution and release claims.

---

## 13. Addendum (2026-02-20): Installation + Docs/Web UX Modernization (Claude/Codex-Inspired)

**Audit sources:**
- Claude setup docs: https://code.claude.com/docs/en/setup
- Codex CLI docs: https://developers.openai.com/codex/cli/

**Audit summary (what to adopt):**
- Claude pattern: native installers as primary, npm deprecated, platform-specific install/update/uninstall guidance, install specific version and release channels, checksum/code-signing trust, explicit team/org setup paths.
- Codex pattern: fast package-manager onboarding, clear run/upgrade flow, account/API-key auth path, interactive and automation-oriented CLI discoverability.
- SkillGate gap: packaging and docs are still primarily static and Python-centric; install UX and enterprise rollout guidance are not yet first-class in web/docs product surfaces.

### 13.1 Requirements Contract

1. Installation distribution model
- Keep PyPI as canonical distribution for Python ecosystem.
- Add first-class multi-channel install surface:
  - `pipx`/PyPI (canonical)
  - Homebrew
  - WinGet
  - Optional npm shim/wrapper (not canonical engine)
- Prefer native OS-friendly install commands in docs and web UI; avoid forcing users into Python tooling if not needed for their environment.

2. Versioning and update model
- Support install targets: `latest`, `stable`, and explicit version pin.
- Publish machine-readable release manifest with checksums/signature metadata.
- Document upgrade and rollback paths per package manager.

3. Enterprise/team rollout model
- Add explicit "For individuals" vs "For teams and organizations" installation/auth/deployment paths.
- Add managed settings and policy bootstrap patterns for org-wide consistency.
- Add private/offline install guidance (artifact mirrors, airgap workflows where applicable).

4. Docs/web product UX model
- Convert static install docs to interactive, platform-aware install experience:
  - OS selector (macOS/Linux/Windows/WSL)
  - package-manager selector
  - one-click copy commands
  - version/channel selector
- Ensure docs content is generated from a single install-spec source-of-truth consumed by both docs and web UI.

### 13.2 Task Additions

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.138 | Define canonical install strategy matrix (PyPI canonical + Homebrew + WinGet + optional npm shim) with support policy by platform | Product/eng contract tests + docs lint checks | Single published install support matrix with no ambiguity |
| 17.139 | Build install-spec source-of-truth (structured config) driving docs/web install command rendering | Schema validation tests + snapshot tests | Docs/web commands generated from one source, no hardcoded drift |
| 17.140 | Add platform/package-manager install sections to docs with run/verify/uninstall flows | Docs link/snippet tests + command smoke checks | Docs provide complete install lifecycle by platform |
| 17.141 | Implement version-targeted install UX (`latest`, `stable`, pinned) for supported channels | CLI/package install tests + version-resolution tests | Users can deterministically install a specific version/channel |
| 17.142 | Add upgrade + rollback guidance and commands for each installer path (pipx, brew, winget, optional npm shim) | Docs snippet tests + rollback procedure validation | Upgrade/rollback docs are executable and verified |
| 17.143 | Publish signed release manifest (checksums + signature metadata) and verification docs | Manifest integrity tests + signature verification tests | Every release has verifiable integrity metadata |
| 17.144 | Add `skillgate doctor` installation diagnostics command (install type, version, path, env checks) | CLI unit tests + E2E tests | Users can self-diagnose install/auth/environment issues |
| 17.145 | Add docs/web "For individuals" and "For teams and organizations" install/auth tracks | IA tests + route/render tests | Distinct guided paths exist for solo vs enterprise rollout |
| 17.146 | Add org-managed settings bootstrap docs and starter templates (team policy, update channel, defaults) | Template validation tests + docs contract tests | Teams can enforce consistent baseline configuration |
| 17.147 | Add enterprise private deployment guide (artifact mirrors, restricted egress, airgap-aligned installation) | Docs tests + architecture review checklist | Enterprise deployment path is procurement/security ready |
| 17.148 | Modernize web-ui docs installation page from static blocks to interactive install wizard components | Component tests + Playwright flows + accessibility tests | Install UX is dynamic, copy-ready, and mobile-safe |
| 17.149 | Add analytics for install funnel (platform, package manager, copy actions, docs-to-install conversion) with no PII | Telemetry contract tests + privacy checks | Install UX conversion is measurable without sensitive leakage |
| 17.150 | Add CI guardrails for docs freshness against release metadata (version drift checks) | CI contract tests + failing fixture tests | Docs cannot ship stale install/version instructions |
| 17.151 | Add launch checklist for installer/documentation rollout (support, security, rollback, comms) | Checklist tests + staged dry-run review | Installation UX rollout has explicit go/no-go governance |

### 13.3 Acceptance Gate

- [ ] Installation docs and web UI support platform-aware, package-manager-aware, copy-ready flows.
- [ ] Users can install `latest`, `stable`, or pinned versions with documented deterministic behavior.
- [ ] Individuals and teams/enterprise have distinct setup guides with policy/bootstrap guidance.
- [ ] Release integrity is verifiable via published checksums/signature metadata.
- [ ] Install/docs instructions are generated from one source-of-truth and protected by CI drift checks.

### 13.4 Mandatory Execution Pack

Before implementing any Section 13 feature, use the execution pack in:

- `docs/section-13-installation-ux/README.md`
- `docs/section-13-installation-ux/BOUNDARIES.md`
- `docs/section-13-installation-ux/SPECS.md`
- `docs/section-13-installation-ux/TASKS.md`
- `docs/section-13-installation-ux/RALPH-LOOP.md`
- `docs/section-13-installation-ux/READINESS-GATES.md`
- `docs/section-13-installation-ux/VALIDATION-CHECKS.md`
- `docs/section-13-installation-ux/AGENT-SKILLS-MANDATORY.md`

These documents are fail-closed governance for Section 13 execution and release claims.

### 13.5 Shipped Evidence Pointer (2026-02-21)

- Optional npm shim channel is now shipped as wrapper distribution:
  - `npm-shim/package.json`
  - `npm-shim/bin/skillgate.js`
  - `npm-shim/README.md`
- Contract and behavior evidence:
  - `tests/docs/test_npm_shim_contract.py`
  - `tests/e2e/test_npm_shim_wrapper.py`
- CI/release provenance path:
  - `.github/workflows/ci.yml` (`npm-shim` job with `npm publish --provenance --dry-run`)
  - `.github/workflows/npm-shim-release.yml` (tag/manual publish pipeline + GitHub provenance attestation)
- Section 13 artifact ledger:
  - `docs/section-13-installation-ux/artifacts/section13-gate-run.md`

---

## 14. Addendum (2026-02-21): Governance + Enforcement + Evidence Strategy Revision

**Decision:** Proceed. Do not stop product execution.  
**Reason:** Detection-only value is compressing; SkillGate must win on deterministic governance, runtime enforcement, and cryptographic evidence.

### 14.1 Strategic Lock (Immediate)

1. Keep "not a scanner" positioning as a hard product constraint across docs/web/pricing.
2. Prioritize orchestration capabilities that enforce policy on every action over broad "assistant" UX.
3. Ship evidence-first workflows (signed decisions, approvals, replayable audit artifacts) before aggressive autonomous remediation.
4. Treat reliability proof (false-negative and false-positive evidence) as a customer-facing contract, not an internal metric.

### 14.2 Brutal Re-Prioritization (Do This, Freeze the Rest)

| Priority | Scope | Rationale |
|---|---|---|
| P0 (must ship now) | `17.109`, `17.111`, `17.112`, `17.113`, `17.152`, `17.153`, `17.154`, `17.157`, `17.161`, `17.162`, `17.163` | This is the minimum viable control plane: orchestrator core, policy-in-the-loop, approvals, evidence pack, reliability proof, canonical schema, deterministic risk contract, and one end-to-end governed flow |
| P1 (only after P0 green) | `17.114`, `17.156`, `17.158` | Adds practical triage value and remediation safety boundaries without expanding autonomy scope |
| P2 (explicitly deferred) | `17.115`–`17.120`, `17.122`–`17.132`, `17.155`, `17.159`, `17.160` | Valuable, but not required for immediate market proof; shipping these now increases risk and slows core delivery |
| Always-on guardrails | `17.19`, `17.20`, `17.25`, `17.92`, `17.97` | Reliability and truth-in-claims cannot regress while accelerating execution |

### 14.3 Task Additions (`17.161`–`17.164`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.161 | Canonical unified finding schema (`FindingV1`) across deterministic, enrichment, and LLM reasoning outputs: `engine_source`, `reasoning_summary`, `exploit_scenario`, strict provenance refs, policy reference | Schema validation tests + adapter contract tests + backward-compat tests + SARIF/JSON parity tests | All finding producers emit one contract; no per-engine drift |
| 17.162 | Deterministic risk model versioning (`risk_model_version`) with locked formula inputs (severity, confidence, exploitability_factor, repo_sensitivity) and deterministic fallback to existing scorer | Scorer determinism tests + version migration tests + replay consistency tests | Any score is reproducible by model version and input snapshot |
| 17.163 | Minimum governed vertical slice: PR trigger -> multi-engine findings -> policy decision -> approval checkpoint (if required) -> signed proof pack export | End-to-end integration test + failure-path tests + artifact verification tests | One enterprise-credible flow works end-to-end without manual stitching |
| 17.164 | Scope-freeze gate: CI check that blocks merging P2 features until all P0 acceptance gates are green | CI policy tests + failing fixture tests | Team cannot accidentally re-expand scope before core ship criteria are met |

### 14.4 Hard 7-Day 24/7 Execution Board

Execution model:

- Three shifts daily (00:00-08:00, 08:00-16:00, 16:00-24:00 local).
- One task owner role per deliverable, one validator role per gate.
- No new scope accepted during this window.

Owner roles:

- `Runtime Owner`: orchestrator and enforcement code paths.
- `Evidence Owner`: proof pack, reliability, and claim artifacts.
- `DX/Growth Owner`: PRD/docs/web CTA and SEO-aligned messaging.
- `Gate Owner`: CI gates, quality scripts, and release controls.

| Day | Shift Focus | Owner-Ready Tasks | Measurable Gate (must be green by 24:00) |
|---|---|---|---|
| Day 1 | Lock product surface | Freeze scope to Section 14 tasks; map all task->spec->test->artifact links; reject any P2 work | 100% Section 14 tasks mapped in `TASKS.md` + `PER-TASK-RECORDS.md`; governance scope gate passes |
| Day 2 | Enforcement hardening | Make write-path approval enforcement default for strict/prod execution paths; keep explicit rollback switch documented | 0 unapproved write-path executions in strict/prod tests; mandatory approval tests all pass |
| Day 3 | Evidence hardening | Rebuild governed proof pack and reliability artifacts from clean run; ensure replayability and signature verification | 100% proof-pack verification pass; reliability scorecard generated with no failing threshold |
| Day 4 | Triage-to-remediation trust flow | Validate read-only triage determinism and governed vertical slice outputs across repeated runs | 0 digest drift across repeated triage runs; governed vertical slice tests pass |
| Day 5 | Market proof surface | Update positioning, claims, CTA copy, and proof links across PRD/docs/web-facing artifacts with no unbacked claims | claim-ledger gate passes; every product claim has linked artifact evidence |
| Day 6 | Conversion path integrity | Validate first-run path: scan -> decision -> approval -> evidence export; ensure CTA points to runnable proof flow | 1-command proof flow documented and test-reproduced end-to-end; no broken CTA links |
| Day 7 | Ship/no-ship adjudication | Run full gate pack, produce GO/NO-GO report, publish rollback + recovery runbook for all shipped tasks | `ruff`, `mypy --strict`, required tests, claim ledger, governance scope gate, reliability gate all green |

Daily mandatory artifacts:

- Updated gate log: `docs/section-14-governed-pipeline/artifacts/section14-gate-run.log`
- Current scorecard: `docs/section-14-governed-pipeline/artifacts/reliability-scorecard.json`
- Updated task evidence: `docs/section-14-governed-pipeline/PER-TASK-RECORDS.md`

Hard stop rules (fail-closed):

- If any gate fails, freeze feature work and spend next shift on root-cause fix only.
- If claim-ledger or governance-scope gate fails, release status is automatically `NO-GO`.
- If rollback steps are missing for any shipped task, task status cannot remain `Complete`.

### 14.5 Acceptance Gate (Hard Go/No-Go)

- [x] One governed enterprise flow (`17.163`) is shippable end-to-end with signed evidence.
- [x] No remediation write path can execute without approval artifact verification (`17.112`, `17.156`).
- [x] Findings and risk outputs are schema/version stable and reproducible (`17.161`, `17.162`).
- [x] Reliability evidence (FN/FP/perf) is published and enforced by CI (`17.154` + existing gates).
- [x] Scope freeze is active; deferred autonomy scope cannot merge early (`17.164`).

### 14.6 Explicit Cuts (For Speed)

1. Do not ship autonomous remediation PR generation (`17.115`) in this cycle.
2. Do not ship sub-agent expansion (`17.118`) in this cycle.
3. Do not ship full RBAC/retention enterprise surface (`17.119`) in this cycle.
4. Do not ship dual-mode CLI/session UX (`17.122`–`17.132`) in this cycle.
5. Do not build dashboard analytics UX (`17.155`, `17.159`) until core governed flow is proven.

### 14.7 Mandatory Execution Pack

Before implementing any Section 14 production feature, use the execution pack in:

- `docs/section-14-governed-pipeline/README.md`
- `docs/section-14-governed-pipeline/BOUNDARIES.md`
- `docs/section-14-governed-pipeline/SPECS.md`
- `docs/section-14-governed-pipeline/TASKS.md`
- `docs/section-14-governed-pipeline/RALPH-LOOP.md`
- `docs/section-14-governed-pipeline/READINESS-GATES.md`
- `docs/section-14-governed-pipeline/VALIDATION-CHECKS.md`
- `docs/section-14-governed-pipeline/AGENT-SKILLS-MANDATORY.md`

These documents are fail-closed governance for execution and release claims.

### 14.8 Current Status Discipline (Do Not Over-Claim)

As of 2026-02-21, Section 14 tasks are complete only when the six-point DoD is recorded per task.

The canonical status source is:

- `docs/section-14-governed-pipeline/TASKS.md`
- `docs/section-14-governed-pipeline/PER-TASK-RECORDS.md`
- `docs/section-14-governed-pipeline/PR-DESCRIPTION-SECTION14.md`
- `docs/section-14-governed-pipeline/RELEASE-DECISION.md`

Status semantics are strict:

- `Ready for Gate` = implementation and baseline gates passed.
- `Complete` = all per-task DoD checks are satisfied and recorded.

Per-task completion requires all of the following (from `TASKS.md`):

1. Scope implemented exactly as spec in `SPECS.md`.
2. Required tests pass in CI and local reproduction.
3. Evidence artifacts generated and linked in PR description.
4. Backward compatibility impact documented.
5. Rollback/recovery path documented.
6. Security and policy invariants validated (no bypass introduced).

### 14.9 Product Outcome Gates (Attention -> Trust -> Revenue)

Section 14 execution is only successful if product outcomes move, not just technical completion.

Mandatory product gates:

- `Attention Gate`: homepage/docs messaging must clearly differentiate SkillGate as governance control plane, not scanner clone.
- `Trust Gate`: every major claim links to verifiable proof artifact.
- `Conversion Gate`: primary CTA leads to a runnable first proof flow (scan -> enforce -> evidence export).
- `Retention Gate`: weekly re-use path is explicit (policy gate + approvals + evidence replay).

Weekly scoreboard (required in release note or PR body):

- `% first-run users who generate proof pack`
- `% high-risk actions blocked before write`
- `% runs with signed approval artifacts on write paths`
- `% claims with linked evidence artifacts`
- `% failed gates resolved within same day`

Fail-closed market rule:

- If trust/claim evidence is incomplete, do not expand feature scope even if tests are green.

---

## 15. Addendum (2026-02-21): Open-Core Repo Split + Deployment Cutover Governance

**Decision:** Proceed with repo split only after boundary, legal, and deployment gates are explicit and test-enforced.

### 15.1 External Pattern Alignment (OpenAI + Claude)

Observed public patterns to mirror:

1. Distribution split by interface/repo:
- OpenAI publishes separate SDK repos by language (`openai-python`, `openai-node`) and keeps SDK contracts generated from OpenAPI.
- Claude Code distributes via native installers/npm with explicit install verification (`doctor`) and update behavior docs.

2. Public boundary hygiene:
- Public repos include clear `SECURITY.md`, `CONTRIBUTING.md`, changelog/release metadata, and tested examples.
- Operational internals, abuse detection internals, and security-hardening internals are not treated as public product docs.

3. Terms/policy posture:
- Explicit prohibitions on abuse, unauthorized access, bypassing safeguards/rate limits, reverse engineering, and harmful/illegal activity.
- Explicit enforcement rights: suspend/restrict/terminate access for policy or legal violations.

### 15.2 Repo Split Contract (`17.165`–`17.172`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.165 | Freeze public/private boundary matrix for split (`public-ce`, `private-ee`) and map every top-level path to ownership | Boundary policy tests + denylist fixture tests | No ambiguous ownership for code/docs/scripts/workflows |
| 17.166 | Enforce public export gate in CI (`check_public_export.py --strict`) for public-release branches/tags | CI workflow tests + failing fixture branch | Public export cannot include denylisted private assets |
| 17.167 | Define dual-repo release contract (version, tag, changelog, rollback ordering across CE/EE + npm shim + web-ui) | Release rehearsal tests + manifest checks | Release/rollback sequence is deterministic and auditable |
| 17.168 | Deployment cutover contract for Netlify (web-ui) + Railway (api/worker): env vars, migration sequence, smoke checks, rollback | End-to-end cutover checklist rehearsal + smoke scripts | Cutover can be executed and rolled back without ad-hoc decisions |
| 17.169 | CI parity matrix after split: lint/type/test/security/export gates preserved across public/private repos | CI matrix contract tests | No critical gate regression during monorepo -> multi-repo transition |
| 17.170 | Legal and policy hardening pass across Terms/Privacy/Legal templates for anti-abuse and unauthorized access prohibitions | Docs/legal content contract tests | Legal posture explicitly covers abuse, unauthorized hacking, safeguard bypass |
| 17.171 | Enterprise deployment profile lock for Railway API/worker + Netlify UI, including CORS/auth callback domain matrix | Config validation + deployment smoke tests | Production domains and auth flows are explicit and fail-closed |
| 17.172 | Go/No-Go artifact for split (`split-readiness-report`) with risk ledger and rollback commitments | Gate pack + release decision check | Split does not proceed without signed GO artifact |

### 15.3 Acceptance Gate (Hard Go/No-Go)

- [ ] Public/private boundary enforcement is active in CI and validated by failing fixtures.
- [ ] Legal terms explicitly prohibit abuse, unauthorized system access, exploit/hacking behavior, and safeguard bypass.
- [ ] Netlify + Railway production cutover is rehearsed with migration/smoke/rollback artifacts.
- [ ] Multi-repo CI parity proves no lost gate relative to current monorepo.
- [ ] Final split readiness report exists with owner sign-off and rollback path.

### 15.4 Mandatory Execution Pack

Before implementing Section 15 tasks, use:

- `docs/section-16-open-core-split-governance/README.md`
- `docs/section-16-open-core-split-governance/BOUNDARIES.md`
- `docs/section-16-open-core-split-governance/SPECS.md`
- `docs/section-16-open-core-split-governance/TASKS.md`
- `docs/section-16-open-core-split-governance/READINESS-GATES.md`
- `docs/section-16-open-core-split-governance/VALIDATION-CHECKS.md`
- `docs/section-16-open-core-split-governance/PER-TASK-RECORDS.md`
- `docs/section-16-open-core-split-governance/RELEASE-DECISION.md`
- `docs/section-16-open-core-split-governance/AGENT-SKILLS-MANDATORY.md`

These documents are fail-closed governance for repo split and deployment cutover claims.

### 15.5 Current Execution Status (2026-02-21)

- Section 16 execution pack is now created and active at:
  - `docs/section-16-open-core-split-governance/README.md`
  - `docs/section-16-open-core-split-governance/TASKS.md`
  - `docs/section-16-open-core-split-governance/READINESS-GATES.md`
  - `docs/section-16-open-core-split-governance/RELEASE-DECISION.md`
- Legal hardening baseline for `17.170` is now implemented in:
  - `web-ui/src/app/terms/page.tsx`
  - `web-ui/src/app/privacy/page.tsx`
  - `web-ui/src/app/legal/security-addendum-template/page.tsx`
  - `web-ui/src/app/legal/dpa-template/page.tsx`
- Section 16 blocker closure is now evidenced:
  - `17.166` strict public export gate + CI wiring + negative fixture proof
  - `17.168` cutover rehearsal artifacts (env-contract, smoke, rollback)
  - `17.169` split CI parity matrix validation
  - `17.171` deployment profile lock validation
  - `17.172` signed split readiness GO artifact
- Current Section 16 technical decision:
  - `GO` recorded in `docs/section-16-open-core-split-governance/RELEASE-DECISION.md`

---

## 16. Addendum (2026-02-21): Supabase Auth + Data Platform Migration

## 16.1 Addendum (2026-02-22): API Key Required Entitlement Contract

### Objective

Align CLI entitlement behavior with control-plane source of truth and account-backed subscription tracking by requiring keys for entitlement-resolved CLI paths.

### Behavioral Contract

- No-key fallback to Free entitlement is removed from entitlement resolver paths.
- Invalid key formats fail entitlement resolution.
- Free tier usage is explicitly key-backed (`sg_free_*`) and still limited.

### Validation Scope

- Updated entitlement unit/e2e coverage verifies:
  - scan without key fails with entitlement error,
  - free key paths succeed with free limits,
  - invalid key format fails entitlement resolution,
  - existing tier capability gates continue to behave deterministically.

**Decision:** Proceed with a phased migration to Supabase for hosted auth and managed Postgres, with strict compatibility gates and rollback.

### 16.1 Why This Addendum Exists (Audit Findings)

Current SkillGate hosted backend has deep custom auth/session persistence on local SQLAlchemy models and Alembic:

- Auth/session logic is local-first in `skillgate/api/routes/auth.py` with custom signup/login/refresh/logout/password-reset/email-verify/device flows.
- JWT and password primitives are custom in `skillgate/api/security.py` (HS256 access tokens, PBKDF2 password hashes, opaque refresh tokens).
- Persistence is strongly coupled to local models in `skillgate/api/models.py` (`User`, `UserSession`, `PasswordResetToken`, `EmailVerificationToken`, `OAuthIdentity`, `AuthRateLimit`).
- Database engine and migration flow are SQLAlchemy + Alembic (`skillgate/api/db.py`, `alembic/env.py`, `alembic/versions/*`).
- Resend email verification is already integrated in auth routes and can be preserved during migration.

Reference implementation patterns from `/Users/spy/Documents/PY/AI/repurposely-app/backend` show practical Supabase usage:

- JWT verification against Supabase-issued tokens and JWKS (`src/services/supabase-jwt.service.ts`).
- Service-role backed REST data access abstraction (`src/services/supabase-rest.service.ts`).
- Auth middleware pattern that validates Supabase JWT first, then loads profile/entitlement context.

### 16.2 Migration Strategy (Hard Constraints)

1. **Supabase becomes auth source-of-truth** for hosted mode (email/password and OAuth).
2. **Managed Postgres remains relational source-of-truth** for application data; Supabase Postgres replaces ad-hoc local PostgreSQL operations for hosted deployments.
3. **Resend remains supported** for verification and transactional email, either via:
  - Supabase Auth SMTP path with Resend provider configuration, or
  - Existing app-driven verification flow with Supabase Admin API controls.
4. **No hard cutover without compatibility mode**: local auth/session contract must remain testable behind feature flags until parity gates are green.
5. **CLI/local deterministic workflows must not regress**; hosted auth migration cannot affect core scanner determinism or offline behavior.

### 16.3 Task Plan (`17.173`–`17.188`)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.173 | Add auth provider abstraction (`local`, `supabase`) for hosted API with runtime config gate | Unit tests for provider resolution + startup config validation | Auth backend can be switched deterministically via config |
| 17.174 | Implement Supabase JWT verifier in Python (JWKS cache, alg allowlist, exp/aud/iss checks) | Unit tests for valid/invalid/expired/replay-safe claims + offline-key cache tests | Supabase JWT verification is deterministic and secure |
| 17.175 | Introduce Supabase auth client service (signup/login/refresh/logout/password reset/email verify hooks) | Integration tests with mocked Supabase endpoints + failure-path tests | Hosted auth flows routed through provider contract |
| 17.176 | Add profile mapping layer from Supabase `auth.users` + app profile table to existing `UserResponse` contract | Contract tests for response parity (`/auth/me`, tier/subscription fields) | Existing API response schema remains backward-compatible |
| 17.177 | Preserve Resend verification path for migration window (dual path: Supabase SMTP vs app-driven verify) | Integration tests for both verification modes + outage fallback tests | Verification flow is explicit, observable, and fail-safe |
| 17.178 | Migrate/bridge session model: map local `UserSession` semantics to Supabase session/refresh model with revocation policy | Integration tests for login/refresh/logout rotation semantics + revocation tests | No session bypass/regression in strict security tests |
| 17.179 | Migrate OAuth callback flow from demo/local stub to Supabase-native provider exchange in non-dev envs | Security regression tests for forged callback/state/nonce + provider matrix tests | Demo-only flow is isolated to dev; production uses verified Supabase flow |
| 17.180 | Define data ownership split: Supabase-owned auth tables vs SkillGate-owned domain tables (subscriptions, teams, scan_records, entitlement logs) | Schema contract tests + migration drift tests | No ambiguous ownership or duplicate-writer paths |
| 17.181 | Update DB/migration posture: keep Alembic only for SkillGate domain tables; remove local-auth-table dependency from forward migrations | Alembic migration tests + downgrade/rollback tests | Migration pipeline remains deterministic post-split |
| 17.182 | Add RLS and service-role policy model for app tables accessed via Supabase | Policy tests (user-scoped reads/writes, service-role admin paths) + negative authorization tests | Least-privilege access controls are enforced and audited |
| 17.183 | Add hosted-mode env contract and secrets rotation docs (`SUPABASE_URL`, keys, JWT settings, Resend mode) | Docs contract tests + startup validation tests | Misconfiguration fails closed in staging/prod |
| 17.184 | Add compatibility migration scripts for existing local users/sessions/tokens into Supabase identities/profile rows | Migration rehearsal tests + idempotency/replay tests | Existing accounts can migrate without auth lockout |
| 17.185 | Refactor auth test harness to provider-agnostic fixtures; keep current suite passing in `local` mode and add `supabase` mode matrix | Test matrix CI (`local` + `supabase-mocked`) + contract snapshots | Auth tests no longer assume one backend implementation |
| 17.186 | Execute security hardening pass for Supabase path (token verification, webhook trust, key handling, rate-limit continuity) | Defense regression suite + abuse tests | No reopening of fixes `16.29`–`16.35` |
| 17.187 | Add observability for auth provider path (provider choice, failure class, token verification errors, email verification outcomes) | Telemetry contract tests + privacy/redaction tests | On-call can debug provider-specific failures quickly |
| 17.188 | Production cutover + rollback runbook (staged rollout, traffic switching, rollback triggers) | Staging rehearsal + smoke checks + rollback drill | Go-live is reversible and operationally clear |

### 16.4 Expected Complications (From Current Code + Test Surface)

1. **Large auth test blast radius:** `tests/unit/test_api/test_auth_api_keys.py`, `tests/unit/test_api/test_auth_edges.py`, and defense tests currently assert local password/hash/session/token behavior.
2. **Refresh/session semantics mismatch:** local `UserSession` rotation and token revocation are DB-row driven; Supabase session model differs and needs explicit compatibility rules.
3. **Email verification contract differences:** current tests expect `verification_token` in non-production flows; Supabase-native verification may not expose this token directly.
4. **JWT contract differences:** existing code expects local HS256 claims (`sub`, optional `sid`); Supabase may issue RS256/ES256 tokens and distinct claim structure.
5. **OAuth path replacement:** current production path is intentionally disabled/stubbed beyond demo; Supabase provider exchange changes both runtime and test fixtures.
6. **Migration ownership complexity:** existing `users` table and related foreign keys are currently app-owned; migration must avoid orphaned references and duplicate identity sources.

### 16.5 Execution Order (Dependency-Driven)

| Phase | Tasks | Why First | Phase Gate |
|---|---|---|---|
| A. Provider Foundations | 17.173, 17.174, 17.183 | Must establish secure provider abstraction + configuration boundaries before behavior changes | Provider selected deterministically; misconfig fails closed |
| B. Auth Path Integration | 17.175, 17.176, 17.177, 17.178, 17.179 | Replace auth runtime while preserving API contracts and security semantics | Core auth endpoints pass compatibility matrix |
| C. Data and Migration Split | 17.180, 17.181, 17.182, 17.184 | Clarify ownership and run migration safely before cutover | Data split and migration rehearsals are green |
| D. Test/Security/Ops Hardening | 17.185, 17.186, 17.187, 17.188 | Finalize confidence and operational readiness before production | CI matrix + defense gates + cutover rehearsal all green |

### 16.6 Acceptance Gate (Supabase Migration)

- [ ] Hosted auth supports `local` and `supabase` providers with deterministic config precedence.
- [ ] Supabase JWT verification is cryptographically validated (issuer/audience/expiry/alg constraints) and tested.
- [ ] Signup/login/refresh/logout/password-reset/email-verify flows pass in compatibility matrix without API contract drift.
- [ ] Existing security fixes and abuse controls (`16.29`–`16.35`) remain green after migration.
- [ ] Alembic and schema ownership are cleanly split between auth-managed and app-managed data.
- [ ] Production cutover and rollback runbook is rehearsed with artifacts.

### 16.7 Initial Test Impact Map (Must Be Tracked During Execution)

High-impact suites likely requiring fixture refactor or dual-mode assertions:

- `tests/unit/test_api/test_auth_api_keys.py`
- `tests/unit/test_api/test_auth_edges.py`
- `tests/unit/test_api/test_security_utils.py`
- `tests/unit/test_api/test_rate_limit.py`
- `tests/defense/test_security_fixes_16_29_35.py`
- `tests/unit/test_api/test_payments_resilience.py` (auth bootstrap dependency)
- `tests/unit/test_api/test_hunt_api.py`, `test_retroscan_api.py`, `test_scan_rate_limit.py`, `test_teams_api.py`, `test_scans_api.py` (signup/login setup fixtures)

Rule for this addendum: no migration task is marked complete unless both provider modes are either green or explicitly declared deprecated with approved removal gate.

### 16.8 Advanced Supabase Scope (RLS, Functions, Egress, Performance, Frontend)

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 17.189 | Define Supabase SQL/RPC function contract for transactional operations and versioned schema | Function contract tests + error-path tests + idempotency tests | RPC/function surface is versioned, deterministic, and auditable |
| 17.190 | Define and enforce RLS policy catalog for protected app tables | Positive/negative authz tests + policy drift checks | Deny-by-default model enforced; no cross-user data leakage |
| 17.191 | Add Supabase egress governance (allowlist, timeout, retry, circuit-breaker, fail modes) | Fault-injection tests + timeout/retry policy tests | Outbound behavior is controlled and resilient |
| 17.192 | Add auth/profile performance plan with explicit p50/p95/p99 SLO budgets | SLO benchmark tests + load tests | Auth-critical paths meet SLO targets in CI/staging |
| 17.193 | Add cache strategy for JWKS/profile/auth metadata with TTL/invalidation safety controls | Cache consistency tests + stale/revocation tests | Cache improves latency without breaking security semantics |
| 17.194 | Define frontend React Query hook contract for auth/profile/session lifecycle | Frontend contract tests + mutation/invalidation tests | Frontend state model is deterministic across provider modes |
| 17.195 | Add frontend-backend auth contract tests for migration compatibility | End-to-end auth contract tests + schema parity tests | UI behavior remains stable during `local` -> `supabase` transition |

### 16.9 Extended Acceptance Gate (Additional Scope)

- [ ] RLS policy catalog is published and negative-access tests are green.
- [ ] Supabase SQL/RPC functions are versioned and contract-tested.
- [ ] Egress controls are explicitly enforced (allowlist, timeout, retry, breaker).
- [ ] Auth/profile SLOs meet performance budgets in staging validation.
- [ ] Cache behavior preserves revocation and security invariants.
- [ ] Frontend React Query auth hooks are contract-tested and migration-safe.

### 16.10 Mandatory Execution Pack

Before implementing Section 16 migration tasks, use:

- `docs/section-17-supabase-auth-migration/README.md`
- `docs/section-17-supabase-auth-migration/BOUNDARIES.md`
- `docs/section-17-supabase-auth-migration/SPECS.md`
- `docs/section-17-supabase-auth-migration/TASKS.md`
- `docs/section-17-supabase-auth-migration/READINESS-GATES.md`
- `docs/section-17-supabase-auth-migration/VALIDATION-CHECKS.md`
- `docs/section-17-supabase-auth-migration/PER-TASK-RECORDS.md`
- `docs/section-17-supabase-auth-migration/RELEASE-DECISION.md`
- `docs/section-17-supabase-auth-migration/AGENT-SKILLS-MANDATORY.md`

These documents are fail-closed governance for Supabase migration execution and release claims.

---

*End of Implementation Plan — Version 1.0.0*
