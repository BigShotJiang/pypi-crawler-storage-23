# Enterprise Readiness Checklist

**Version:** 1.0.0  
**Last Updated:** 2026-02-18

## Scope

Procurement and rollout checklist for Enterprise plan qualification.

## Current State (2026-02-18)

- Code-level enterprise foundations are present (seat-aware entitlement handling, on-prem validation adapter contract, enterprise docs pages).
- This checklist tracks operational/commercial sign-off for production rollout and is intentionally strict.
- Status today: **not launch-ready for enterprise** until all required sign-offs below are complete.

## Implementation Evidence (Code/CI)

- [x] Enterprise on-prem validation adapter contract exists and is test-covered.
- [x] Entitlement API tests cover fail-open/fail-closed on-prem validation behavior.
- [x] Enterprise and artifact coverage docs are published in docs/web-ui.
- [ ] Reliability SLO gate is green on current branch.

## Security and Identity

- [ ] SSO model selected (SAML or OIDC) and owner assigned.
- [ ] MFA enforced for admin identities.
- [ ] Key namespace strategy defined for signing isolation.
- [ ] Data retention/deletion policy approved.

## Governance Outputs

- [ ] Custom policy pack requirements documented.
- [ ] Audit export format agreed (JSONL/CSV) and cadence set.
- [ ] Evidence consumers identified (Security, Compliance, Platform).

## Reliability and Support

- [ ] SLA target agreed (availability, response, restore targets).
- [ ] Incident escalation path documented (on-call + escalation contacts).
- [ ] Rollback drill completed in the last 30 days.

## Commercial and Legal

- [ ] DPA and security addendum reviewed.
- [ ] Subprocessor review completed.
- [ ] Billing model validated (monthly/yearly, seat assumptions).

## Launch Decision

- [ ] Pilot repo passed policy gate with zero critical bypass.
- [ ] CI annotations and blocking behavior validated.
- [ ] Sign-off from Security, Platform, and Procurement.
