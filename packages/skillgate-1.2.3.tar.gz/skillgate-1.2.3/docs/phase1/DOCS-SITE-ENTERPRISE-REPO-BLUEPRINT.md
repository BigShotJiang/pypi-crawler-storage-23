# Docs Site Enterprise Repo Blueprint (`docs.skillgate.io`)

Goal: run docs as a dedicated, production-grade repository and deploy to `docs.skillgate.io` with CI/CD, security gates, and controlled releases.

## Recommended Repo

- Repository name: `skillgate-docs`
- Visibility: private initially, public when launch-ready
- Default branch: `main`
- Protection: required PR reviews (2), required status checks, signed commits, linear history

## Stack (pragmatic)

- Framework: Next.js (App Router) + MDX content pages
- Hosting: GitHub + Vercel (or Cloudflare Pages) on `docs.skillgate.io`
- Search: Algolia DocSearch (or self-hosted later)
- Monitoring: uptime checks + synthetic checks for `/rules` and `/policy`

## Enterprise Baseline Structure

```text
skillgate-docs/
  .github/
    CODEOWNERS
    workflows/
      ci.yml
      deploy.yml
      link-check.yml
      security.yml
  docs/
    rules/
      index.mdx
    policy/
      index.mdx
    cli/
    governance/
    enterprise/
  src/
    app/
      (docs routes)
    components/
    lib/
  public/
  tests/
    e2e/
  next.config.js
  package.json
  SECURITY.md
  CONTRIBUTING.md
  README.md
```

## Required Quality Gates

- Lint: `npm run lint`
- Type check: `npm run type-check`
- Unit tests: `npm run test`
- Link check: verify internal + external docs links
- E2E smoke: home, `/rules`, `/policy`, critical doc pages
- Security: dependency scan + CodeQL

## URL Contract (first-class)

These URLs must always resolve and remain stable:

- `https://docs.skillgate.io/rules`
- `https://docs.skillgate.io/policy`

If internal routes move, preserve contract using permanent redirects.

## DNS and Hosting Setup

1. Create DNS record for `docs.skillgate.io`:
   - CNAME to hosting target (Vercel/Cloudflare)
2. Attach custom domain in hosting provider
3. Enforce HTTPS + HSTS
4. Add uptime monitors (1m checks) for `/rules` and `/policy`

## GitHub Enterprise Controls

- CODEOWNERS for docs sections (`security`, `policy`, `cli`)
- Branch protection with required checks
- Environments:
  - `preview` for PRs
  - `production` for main
- Deploy tokens scoped minimally
- Signed tags for releases

## Rollout Plan

1. Bootstrap `skillgate-docs` with two canonical pages: `/rules`, `/policy`
2. Configure DNS and verify TLS
3. Enable CI + preview deployments
4. Migrate current `web-ui/src/app/docs` content in waves
5. Cut over all product links to `https://docs.skillgate.io`

## Migration Source

Current source content lives in:

- `web-ui/src/app/docs`

Use that as initial import source for the dedicated docs repository.
