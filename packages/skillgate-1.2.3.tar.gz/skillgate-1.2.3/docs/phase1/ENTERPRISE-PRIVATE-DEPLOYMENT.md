# Enterprise Private And Offline Deployment Guide

This guide covers procurement/security-ready deployment patterns for restricted environments.

## Scope

- Private artifact mirrors
- Restricted egress policy
- Airgap-aligned install and verification
- Rollback and integrity validation

## Private Mirror Workflow

1. Mirror release artifacts (`wheel`, `sdist`, docs integrity bundle) into approved internal registry.
2. Verify release manifest before promotion:

```bash
python scripts/quality/verify_release_manifest.py \
  --manifest docs/section-13-installation-ux/artifacts/release-manifest.json
```

3. Install from mirror with pinned version:

```bash
python -m pip install --index-url https://mirror.example/internal/simple skillgate=={version}
```

## Restricted Egress Model

- Allow outbound only to approved mirror and auth endpoints.
- Use offline explanation mode where no external LLM access is allowed:

```bash
skillgate scan . --explain --explain-source offline
```

## Airgap-Aligned Path

1. Transfer signed release bundle and install spec into offline environment.
2. Validate checksums/signature offline.
3. Install pinned package from local artifact store.
4. Run deterministic smoke check:

```bash
skillgate version
skillgate scan . --policy production --enforce
```

## Rollback

- Keep one approved previous version in local mirror.
- Reinstall previous pinned version and re-run smoke check.

## Evidence For Procurement/Security Review

- `docs/section-13-installation-ux/artifacts/release-manifest.json`
- `docs/section-13-installation-ux/artifacts/release-manifest-verification.json`
- `docs/section-13-installation-ux/artifacts/docs-version-drift-check.json`
- `docs/install-spec.json`
