# Sprint 7.2 Enterprise Runbook

Multi-Artifact Security Coverage — Days 86-100

---

## Overview

Sprint 7.2 adds multi-artifact scanning to SkillGate: PDF/DOCX/ZIP extraction, per-origin policy enforcement, cross-artifact correlation, confusable-character hardening, and signed provenance attestation. This runbook covers deployment and configuration for enterprise environments.

---

## 1. Multi-Artifact Scanning

### Supported Artifact Types

| Type | Extension | Extractor | Max Depth |
|------|-----------|-----------|-----------|
| PDF  | `.pdf`    | `pypdf` (text) | 1 |
| DOCX | `.docx`   | `python-docx` | 1 |
| ZIP  | `.zip`    | stdlib `zipfile` | 3 |

Extraction is triggered automatically during bundle discovery. Control enforcement using `artifact_origins` policy settings (for example disable `archive_member` or `document_text`).

### Extraction Budget

By default SkillGate aborts extraction when cumulative artifact size exceeds **50 MB**. Configure:

```yaml
# skillgate.yml
extraction:
  max_budget_bytes: 26214400   # 25 MB for tighter environments
  archive_max_depth: 2
  skip_binary_extensions: [".dll", ".so", ".dylib", ".pyc"]
```

### Large-File Skip

Files larger than **100 KB** are skipped with a warning — they are included in the `extraction_manifest.extraction_warnings` list. Override:

```yaml
extraction:
  max_file_bytes: 204800   # 200 KB
```

---

## 2. Policy Configuration for Artifact Origins

Findings are tagged by origin type. Apply per-origin rules in `skillgate.yml`:

```yaml
version: "1"
preset: production
artifact_origins:
  document_text:
    enabled: true
    severity_floor: medium
    blocked_categories: []
  archive_member:
    enabled: true
    severity_floor: high
    blocked_categories: ["SG-SHELL", "SG-NET"]
  markdown_codeblock:
    enabled: true
    severity_floor: low
    blocked_categories: []
  config:
    enabled: true
    severity_floor: medium
    blocked_categories: ["SG-CRED"]
```

**Origin type keys** (case-insensitive in policy lookup):

| Key | Source |
|-----|--------|
| `code` | Python/JS/TS/shell source files |
| `markdown_prose` | Narrative text in `.md` files |
| `markdown_codeblock` | Fenced code blocks in `.md` files |
| `document_text` | Extracted PDF/DOCX body text |
| `config` | YAML/JSON/TOML config files |
| `archive_member` | Files extracted from ZIP archives |
| `unknown` | Unclassified sources |

### `severity_floor`

Findings below this severity are **suppressed** for the given origin. Example: set `severity_floor: high` for `archive_member` to surface only high/critical issues from bundled ZIPs.

### `blocked_categories`

Rule ID prefixes to always block regardless of severity. E.g. `"SG-SHELL"` blocks all shell-injection rules for that origin.

---

## 3. Cross-Artifact Correlation

SkillGate compares declared manifest permissions against actual behaviors found in source files. Five correlation rules fire when usage exceeds declarations:

| Rule ID | Check |
|---------|-------|
| `SG-CORR-001` | Shell commands without `shell: execution` or `exec` permission |
| `SG-CORR-002` | Dynamic eval without `eval` or `dynamic_code` permission |
| `SG-CORR-003` | Network calls without `network`, `http`, or `internet` permission |
| `SG-CORR-004` | Filesystem writes without `filesystem` or `file` permission |
| `SG-CORR-005` | Credential access without `credential`, `secret`, or `api` permission |

### Declaring permissions in `SKILL.md`

```markdown
## Permissions

- shell: execution
- network: http
- filesystem: read
```

Or in `skill.json`:

```json
{
  "permissions": ["shell:execution", "network:http"]
}
```

Correlation findings appear in the report under category `correlation` with severity `high` or `critical`. They are included in the risk score and subject to policy max-score thresholds.

---

## 4. Attestation and Signing Scope

Attestations are Ed25519-signed using a **canonical signing scope** that includes:

- All `findings` (sorted by file + rule_id)
- `risk_score` breakdown
- `extraction_manifest` (artifact count, warnings)
- `provenance` metadata for each finding
- `policy_result` decision

The `attestation` field itself is excluded from the signed payload (it contains the signature). This ensures the scope is stable across re-serialisations.

### Generating and Verifying Attestations

```bash
# Sign after scan
skillgate scan ./my-skill --sign --key-id default --output report.json

# Verify
skillgate verify report.json
```

### Key Management

Keys are stored in `~/.skillgate/keys/`. Generate a new key pair:

```bash
skillgate keys generate --name ci-signing-key
```

For CI pipelines, use environment variable injection:

```bash
export SKILLGATE_SIGNING_KEY_B64="<base64-encoded-private-key>"
skillgate scan . --sign
```

---

## 5. Unicode Hardening

SkillGate normalises all content before analysis to prevent confusable-character evasion:

1. **NFKC normalisation** — Decomposes and recomposes Unicode (handles ligatures, fullwidth ASCII)
2. **Bidi override stripping** — Removes U+202A–U+202E, U+2066–U+2069, U+200E/F, U+061C (invisible direction controls used to disguise malicious code in code review)
3. **Control character stripping** — Removes null bytes and other non-printable controls
4. **Confusable folding** — Maps ~50 Cyrillic/Greek/mathematical lookalikes to their ASCII equivalents (e.g. `\u0435` → `e`, `\u03bf` → `o`)

Normalisation warnings appear in `extraction_warnings` and are surfaced in human-readable reports.

**What this prevents:** An attacker using `\u0435val(user_input)` (Cyrillic `е` instead of ASCII `e`) to write `eval` while bypassing regex rules. After normalisation, the pattern is `eval(user_input)` and fires `SG-EVAL-001`.

---

## 6. Output Formats

### JSON — Provenance Fields

Each finding in the JSON report includes:

```json
{
  "rule_id": "SG-EVAL-001",
  "file": "analysis.pdf",
  "line": 12,
  "provenance": {
    "origin_type": "document_text",
    "section": "Section 3: Analysis",
    "page_start": 12
  }
}
```

### SARIF — extractionManifest Properties

```json
{
  "runs": [{
    "properties": {
      "extractionManifest": {
        "totalArtifacts": 5,
        "warnings": 1
      }
    },
    "results": [{
      "locations": [{
        "physicalLocation": {
          "artifactLocation": {
            "uri": "analysis.pdf",
            "uriBaseId": "%DOCUMENT_TEXT%",
            "properties": {
              "originType": "document_text",
              "section": "Section 3: Analysis",
              "pageStart": 12
            }
          }
        }
      }]
    }]
  }]
}
```

Import the SARIF output into GitHub Advanced Security or any SARIF-compatible viewer for provenance-enriched findings with document section context.

### Human (terminal)

- **Origin column** in findings table when any finding has provenance
- **Extraction Manifest summary** at the end of the report showing artifact count, per-origin breakdown, and any extraction warnings

---

## 7. Performance SLOs

| Metric | Target |
|--------|--------|
| Cold start | < 2 s |
| Scan 10 files | < 3 s |
| Scan 100 files | < 10 s |
| Memory | < 256 MB |

SkillGate enforces these internally via `ScanTimer.check_slo()`. Violations are logged as warnings but do not abort the scan. Set `SKILLGATE_STRICT_SLO=1` to fail on SLO breach (useful in CI performance regression gates).

---

## 8. CI/CD Integration

### GitHub Actions

```yaml
- uses: skillgate/skillgate-action@v1
  with:
    policy: production
    sign: true
    fail-on-violation: true
    sarif-output: results.sarif

- uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: results.sarif
```

### GitLab CI

```yaml
skillgate:
  image: skillgate/skillgate:latest
  script:
    - skillgate scan . --policy production --format sarif -o gl-sast-report.json
  artifacts:
    reports:
      sast: gl-sast-report.json
```

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Scan passed — no policy violations |
| 1 | Policy violation — score or severity threshold exceeded |
| 2 | Internal error |
| 3 | Invalid input (bad path, unreadable manifest) |

---

## 9. Configuration Reference

Complete `skillgate.yml` with all Sprint 7.2 options:

```yaml
version: "1"
preset: production           # development | staging | production | strict

thresholds:
  max_score: 80
  max_severity: high         # low | medium | high | critical
  blocked_rule_ids: []

artifact_origins:
  document_text:
    enabled: true
    severity_floor: medium
    blocked_categories: []
  archive_member:
    enabled: true
    severity_floor: high
    blocked_categories: ["SG-SHELL", "SG-NET"]

extraction:
  max_budget_bytes: 52428800  # 50 MB
  max_file_bytes: 102400      # 100 KB
  archive_max_depth: 3
  skip_binary_extensions: []

signing:
  key_id: default
  auto_sign: false

performance:
  strict_slo: false
  scan_timeout_seconds: 30
```

---

## 10. Troubleshooting

**"Extraction budget exhausted"** — Reduce `max_budget_bytes` or exclude large archives via `.skillgateignore`.

**"Unicode normalization warnings in report"** — The scanned file contains bidi overrides or confusable characters. Review the file for potential obfuscation. The finding that caused the flag is still reported post-normalisation.

**SARIF upload shows no locations** — Ensure `extraction_manifest` is populated; it is only set if at least one artifact was extracted. Code-only scans do not populate it.

**Correlation rule fires unexpectedly** — Check `SKILL.md` permissions section. SkillGate uses substring matching (e.g. `"network"` in any permission string counts as network permission). Add the relevant permission to suppress correlation findings.
