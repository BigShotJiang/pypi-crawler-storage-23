# Implementation Specs (Section 13)

## 1) Install Strategy Matrix - `17.138`

Publish one canonical matrix with:

- channel (`pipx/pypi`, `homebrew`, `winget`, optional `npm shim`)
- supported platforms
- support tier (`ga`, `beta`, `experimental`)
- owner and escalation path

Rule: matrix is single source referenced by docs and release checklist.

## 2) Install-Spec Source of Truth - `17.139`

Define machine-readable install-spec containing:

- install commands by platform and channel
- verify command
- uninstall command
- upgrade/rollback command pointers
- version selectors (`latest`, `stable`, pinned)

Rule: docs/web renderers consume spec output; no hardcoded duplicate commands.

## 3) Install Lifecycle Docs - `17.140`

For each supported path provide deterministic:

- install
- verify
- uninstall
- failure troubleshooting starter steps

Rule: snippets must be executable and validated by docs tests/smoke checks.

## 4) Versioned Install UX Contract - `17.141`

Expose install target semantics:

- `latest`: newest available release
- `stable`: current stable channel
- pinned version: explicit immutable version

Rule: selection behavior must be deterministic and documented.

## 5) Upgrade + Rollback Contract - `17.142`

Each installer path must define:

- upgrade command
- rollback command/process
- rollback safety note (cache/source requirements)

Rule: rollback path required before task completion.

## 6) Signed Release Manifest - `17.143`

Release manifest must include:

- artifact name/path
- sha256 checksum
- signature metadata
- manifest version

Rule: verification works offline and fails on tamper.

## 7) Audience Tracks + Freshness Gates - `17.145`, `17.150`, `17.151`

Required:

- docs/web split for individuals vs teams/orgs
- CI guard for install version/spec drift
- launch checklist with explicit GO/NO-GO criteria

Rule: no launch without checklist completion and green drift checks.

## 8) Deferred Specs - `17.144`, `17.146`, `17.147`, `17.148`, `17.149`

Implement only after must-ship scope is green.
