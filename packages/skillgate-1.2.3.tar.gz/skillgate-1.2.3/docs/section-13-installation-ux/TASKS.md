# Task Registry, DoD, and Delivery Order

## Status Board (Section 13)

| Task | Name | Priority | Status | Owner | Notes |
|---|---|---|---|---|---|
| 17.138 | Canonical install strategy matrix | P0 | Complete | DX/Growth Owner | Support matrix shipped in `docs/INSTALLATION-GUIDE.md` + matrix artifact + optional `npm-shim/` package contract |
| 17.139 | Install-spec source-of-truth | P0 | Complete | DX/Growth Owner | Canonical install-spec shipped in `docs/install-spec.json` |
| 17.140 | Platform/package-manager install docs | P0 | Complete | DX/Growth Owner | Install/verify/uninstall lifecycle docs shipped per channel |
| 17.141 | Version-targeted install UX | P0 | Complete | DX/Growth Owner | Deterministic `latest`/`stable`/pinned contract shipped in spec + docs tests |
| 17.142 | Upgrade + rollback guidance | P0 | Complete | DX/Growth Owner | Upgrade/rollback contract and safety notes shipped per channel, including fail-closed npm wrapper prerequisites |
| 17.143 | Signed release manifest + verify docs | P0 | Complete | DX/Growth Owner | Signed release-manifest generation + verification tooling shipped with tests |
| 17.145 | Individuals vs teams/org tracks | P0 | Complete | DX/Growth Owner | Dedicated install tracks shipped for solo and org rollout |
| 17.150 | CI docs freshness guardrails | P0 | Complete | DX/Growth Owner | Drift checker shipped and enforced in CI lint gate |
| 17.151 | Installer/docs launch checklist | P0 | Complete | DX/Growth Owner | Launch checklist/governance contract shipped |
| 17.144 | `skillgate doctor` diagnostics command | P1 | Complete | DX/Growth Owner | CLI diagnostics for install/auth/env shipped with unit + e2e coverage |
| 17.146 | Org-managed settings bootstrap docs/templates | P1 | Complete | DX/Growth Owner | Team bootstrap guide + starter templates shipped |
| 17.147 | Enterprise private/offline deployment guide | P1 | Complete | DX/Growth Owner | Private mirror/restricted-egress/airgap guide shipped |
| 17.148 | Interactive web install wizard | P1 | Complete | DX/Growth Owner | Dynamic install wizard rendered from install-spec with tests |
| 17.149 | Install funnel analytics (no PII) | P2 | Complete | DX/Growth Owner | Install funnel events instrumented with privacy-safe analytics tests |

## Definition of Done (Per Task)

A task can be set to `Complete` only if all are true:

1. Scope implemented exactly as spec in `SPECS.md`.
2. Required tests/checks pass in CI and local reproduction.
3. Evidence artifacts generated and linked in `PER-TASK-RECORDS.md`.
4. Backward compatibility impact documented.
5. Rollback/recovery path documented.
6. Security/privacy invariants validated.

## 21-Day Delivery Sequence

### Phase A (Days 1-5)

- `17.138` canonical install matrix
- `17.139` install-spec source-of-truth
- `17.140` install lifecycle docs

### Phase B (Days 6-10)

- `17.141` version-targeted install behavior
- `17.142` upgrade + rollback contracts
- `17.143` signed release manifest

### Phase C (Days 11-15)

- `17.145` individuals vs teams/org tracks
- `17.150` CI docs freshness/drift gates
- `17.151` launch checklist and release controls

### Phase D (Days 16-21)

- P0 hardening and defect closure
- Optional: start `17.144` only if all P0 gates are green

## Completion Promise

- "Done" means gate-backed evidence, not calendar completion.
- Any missing gate means `In Progress` or `Blocked`.

## Per-Task Completion Ledger

Legend: `Y` = satisfied and linked, `N` = not yet satisfied.

| Task | Spec match | CI + local tests | Evidence links | Backward compatibility note | Rollback/recovery note | Security/privacy validation | Status |
|---|---|---|---|---|---|---|---|
| 17.138 | Y | Y | Y | Y | Y | Y | Complete |
| 17.139 | Y | Y | Y | Y | Y | Y | Complete |
| 17.140 | Y | Y | Y | Y | Y | Y | Complete |
| 17.141 | Y | Y | Y | Y | Y | Y | Complete |
| 17.142 | Y | Y | Y | Y | Y | Y | Complete |
| 17.143 | Y | Y | Y | Y | Y | Y | Complete |
| 17.145 | Y | Y | Y | Y | Y | Y | Complete |
| 17.150 | Y | Y | Y | Y | Y | Y | Complete |
| 17.151 | Y | Y | Y | Y | Y | Y | Complete |
| 17.144 | Y | Y | Y | Y | Y | Y | Complete |
| 17.146 | Y | Y | Y | Y | Y | Y | Complete |
| 17.147 | Y | Y | Y | Y | Y | Y | Complete |
| 17.148 | Y | Y | Y | Y | Y | Y | Complete |
| 17.149 | Y | Y | Y | Y | Y | Y | Complete |
