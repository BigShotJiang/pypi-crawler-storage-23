# Boundaries (Fail-Closed)

## Must-Ship Scope (Now)

- Canonical install strategy matrix and support policy (`17.138`).
- Install-spec source-of-truth contract for docs/web rendering (`17.139`).
- Platform/package-manager docs with run/verify/uninstall flows (`17.140`).
- Version-targeted install UX contract (`17.141`).
- Upgrade and rollback flows for each supported installer (`17.142`).
- Signed release manifest + verification documentation (`17.143`).
- Individuals vs teams/org setup tracks (`17.145`).
- CI docs freshness/version drift guardrails (`17.150`).
- Launch checklist and go/no-go controls (`17.151`).

## Deferred Scope (Only After Must-Ship Is Green)

- `skillgate doctor` diagnostics command (`17.144`).
- Org-managed settings starter templates (`17.146`).
- Enterprise private/offline deployment guide expansion (`17.147`).
- Interactive web install wizard implementation (`17.148`).
- Install funnel analytics (`17.149`).

## Non-Negotiable Constraints

- One install-spec source drives docs and web install commands.
- No stale install/version docs may ship.
- Release integrity must be independently verifiable.
- Team rollout path must be explicit and actionable.
- No unsupported platform/installer claims.

## Freeze Rule

If any must-ship task is `Blocked` for >24h:

1. Stop deferred scope.
2. Resolve blocker or descoped alternative.
3. Record risk and mitigation in `TASKS.md` before resuming.
