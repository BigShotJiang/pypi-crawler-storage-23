# Ralph Loop (Fail-Closed Execution)

## Loop Steps (Per Task)

1. Read scope from `SPECS.md` and mark task `In Progress`.
2. Implement smallest valid slice with tests first/alongside code.
3. Run validation checks in `VALIDATION-CHECKS.md`.
4. Produce artifacts and update `PER-TASK-RECORDS.md`.
5. If any gate fails, set `Blocked`, capture root cause, and fix before new scope.
6. Move to `Ready for Gate` only when all DoD items are satisfied.
7. Mark `Complete` only after gate owner verification.

## Fail-Closed Rule

Any missing test, artifact, rollback note, or privacy/security validation blocks completion.
