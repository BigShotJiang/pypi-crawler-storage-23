# Section 13 Execution Pack: Installation + Docs/Web UX Modernization

## Purpose

This folder is the mandatory execution contract for Section 13:
`Installation + Docs/Web UX Modernization`.

It prevents install/docs drift and forces evidence-backed delivery.

## Scope

- Defines must-ship installation/distribution features and frozen scope.
- Defines technical contracts, tasks, and Definition of Done.
- Defines validation and release readiness gates.
- Defines required agent skills for implementation and release checks.

## Completion Promise (Mandatory)

No task is marked `Complete` unless:

1. Scope matches `SPECS.md`.
2. Required tests and checks pass.
3. Evidence artifacts are linked in task records.
4. Backward compatibility and rollback path are documented.

## Document Map

- `BOUNDARIES.md` - hard scope boundaries and non-goals.
- `SPECS.md` - implementation-focused contracts.
- `TASKS.md` - status board, delivery sequence, and DoD.
- `RALPH-LOOP.md` - fail-closed task execution workflow.
- `READINESS-GATES.md` - release gate criteria.
- `VALIDATION-CHECKS.md` - required commands and artifact checks.
- `AGENT-SKILLS-MANDATORY.md` - required skills by phase.
- `PER-TASK-RECORDS.md` - evidence ledger per task.
- `PR-DESCRIPTION-SECTION13.md` - release PR evidence template.
- `RELEASE-DECISION.md` - GO/NO-GO decision record.

## Status Model

- `Not Started`
- `In Progress`
- `Blocked`
- `Ready for Gate`
- `Complete`

`Complete` requires all readiness gates green.
