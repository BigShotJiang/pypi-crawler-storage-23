# SkillGate — IMPLEMENTATION-PLAN.md
> **Objective:** Make SkillGate the **Agent Capability Firewall** embedded in (1) Claude Code/MCP, (2) Codex CLI + CLI agents, and (3) agent frameworks — with a first-class **VS Code** developer experience.
>
> This plan is written so that a coding agent can implement it with minimal ambiguity. It defines **scope boundaries**, **architecture**, **interfaces**, **non-functional requirements**, and **phased deliverables**.

---

## 0) Competitive context (why these moats)
The market is consolidating into **platforms** that provide runtime protection, monitoring, and governance for LLM apps and agents (e.g., “AI guardrails” / “runtime security” offerings). Examples include:
- Lakera Guard (API-first runtime protection “control layer” for models/assistants/agents) and related docs emphasizing minimal-latency runtime screening.  
  Reference: https://www.lakera.ai/lakera-guard and https://docs.lakera.ai/docs/integration
- F5 AI Guardrails + AI Red Team positioning “runtime security controls” for models and agents.  
  Reference: https://www.f5.com/go/solution/f5-ai-security-with-guardrails and https://www.f5.com/products/ai-guardrails
- HiddenLayer AI Runtime Security positioning “prompt attacks, jailbreaks… malicious tool use.”  
  Reference: https://www.hiddenlayer.com/platform/ai-runtime-security
- Protect AI as a platform covering model testing to runtime.  
  Reference: https://protectai.com/ and https://protectai.com/layer

Meanwhile, **MCP is becoming the default tool-connection standard** for agents, including Claude Code (and broader industry initiatives).  
References: https://www.anthropic.com/news/model-context-protocol, https://code.claude.com/docs/en/mcp, https://modelcontextprotocol.io/

Recent real-world security incidents show that **tool integrations + local configuration** can become an exploit vector (e.g., command injection / unsafe MCP server loading patterns) and that official MCP servers have had critical vulnerabilities in the wild.  
References:
- https://www.techradar.com/pro/security/anthropics-official-git-mcp-server-had-some-worrying-security-flaws-this-is-what-happened-next
- https://developers.openai.com/codex/cli/ (Codex CLI uses tools & supports MCP concepts)
- (example reporting) https://cyberpress.org/openai-codex-cli-command-injection-vulnerability/

**Implication:** SkillGate must be *runtime-embedded* (not only CI scanning) and must deliver **hard guarantees**: deterministic enforcement, low latency, and audit-grade evidence.

---

## 1) Product wedge and scope boundaries
### 1.1 What SkillGate is (in this plan)
SkillGate is an **Agent Capability Firewall**:
- Governs **tool invocations** (what agents *do*), not only prompts/outputs (what agents *say*).
- Enforces **capability boundaries**: filesystem, network, shell, git, process execution, secrets access, and “dangerous APIs”.
- Provides **deterministic decisions** with machine-readable outcomes.
- Produces **tamper-evident audit records** (signed).
- Ships as:
  1) **Runtime policy engine** (library + sidecar service)
  2) **MCP enforcement gateway** for Claude Code + MCP servers
  3) **Codex/CLI agent wrapper** for tool execution
  4) **VS Code extension** for shift-left policy + skill changes

### 1.2 What SkillGate is NOT (explicitly out of scope)
- Not a full GRC risk registry (questionnaires, bias/fairness workflows, model cards management).
- Not a generic “prompt firewall” that competes head-on with text-only filters.
- Not a SIEM replacement; SkillGate **exports** events to SIEM/SOAR.
- Not a marketplace business in the first 12 months (we build a registry spec, not monetization).

### 1.3 Target user personas
- **Platform/Security Engineering:** wants runtime control, auditability, and SIEM integration.
- **Agent Developers:** want simple middleware + DX in VS Code and CI checks.
- **Claude/Codex power users:** want safe defaults for tools and plugins.

---

## 2) Architecture overview (control plane + data plane)
### 2.1 High-level topology

**Data plane (latency-sensitive)**
- `skillgate-enforcer` library (in-process) OR `skillgate-enforcer-sidecar` (local/cluster service)
- `skillgate-mcp-gateway` (proxy/gateway for MCP servers)
- `skillgate-cli-wrapper` (Codex/agent CLI integration to mediate shell/git/fs/net tools)

**Control plane (state + UX)**
- `skillgate-control` API (policies, org/workspaces, approvals, integration config)
- `skillgate-audit` (append-only evidence store + signatures)
- `skillgate-observability` (metrics, traces, dashboards, export connectors)
- `skillgate-registry` (integration manifests; OSS registry + validation)

### 2.2 Core design principle: deterministic enforcement
Every tool invocation is classified and evaluated against a **policy snapshot**.
- Inputs: tool metadata + request context + policy snapshot + budgets + approvals.
- Output: `ALLOW | DENY | REQUIRE_APPROVAL | MODIFY` (optional “sanitize/patch” step for low-risk transformations)
- Every decision returns:
  - `decision_code` (stable enum)
  - `reason_codes[]` (stable enums)
  - `policy_version`
  - `evidence_hash` and `signature` (optional in ultra-low-latency mode; see §6)

### 2.3 Reference flows

#### A) Claude Code / MCP
Claude Code uses MCP tools and plugins (MCP servers). SkillGate must sit between Claude Code and MCP servers.

**Flow:**
1. Claude Code → MCP tool call request
2. SkillGate MCP Gateway intercepts tool call:
   - normalizes tool call into canonical `ToolInvocation`
   - evaluates policy
3. If allowed:
   - forwards to MCP server
   - captures response metadata
4. Emits signed audit record + optional async telemetry

#### B) Codex CLI + CLI agents
Codex CLI uses tools including shell, apply-patch, file operations, etc. (see OpenAI docs). SkillGate must mediate high-risk operations.

**Flow options:**
- **Wrapper Mode:** `skillgate codex ...` starts Codex with environment variables that route tool calls via SkillGate.
- **Tool Provider Mode:** SkillGate supplies the “shell” tool provider that enforces budgets and safe execution.
- **CI Guard Mode:** when Codex runs in CI on checked-out repos, SkillGate blocks “unsafe config loading” patterns and restricts local MCP server auto-loading.

#### C) Developer workflow (VS Code)
1. VS Code extension lints policy and skill manifests
2. Inline warnings for capability expansions (e.g., new `net: outbound:*`)
3. “Simulate invocation” locally using policy engine
4. Optionally triggers PR checks via GitHub Action template

---

## 3) Canonical data model & policy schema
### 3.1 Canonical ToolInvocation (JSON)
This is the universal interface across MCP/Codex/frameworks.

```json
{
  "invocation_id": "uuid",
  "timestamp": "RFC3339",
  "actor": {
    "type": "agent|human|service",
    "id": "string",
    "workspace_id": "string",
    "session_id": "string"
  },
  "agent": {
    "name": "string",
    "version": "string",
    "framework": "claude-code|mcp|codex|langchain|pydanticai|custom",
    "trust_tier": "low|medium|high"
  },
  "tool": {
    "name": "string",
    "provider": "mcp|local|remote",
    "capabilities": ["fs.read", "fs.write", "net.outbound", "shell.exec", "git.diff", "secrets.read"],
    "risk_class": "low|med|high|critical"
  },
  "request": {
    "params": { "any": "json" },
    "resource_refs": [
      {"type":"file","path":"/repo/README.md"},
      {"type":"url","value":"https://..."}
    ]
  },
  "context": {
    "repo": {"url":"", "commit":"", "dirty": true},
    "environment": {"ci": false, "hostname": "", "os": ""},
    "data_classification": "public|internal|confidential|restricted",
    "network_zone": "dev|staging|prod"
  }
}
```

### 3.2 Policy schema (YAML, versioned)
Key: *capability budgets* + *boundaries* + *approvals* + *exceptions*.

```yaml
apiVersion: skillgate.io/v1
kind: CapabilityPolicy
metadata:
  name: default-dev
  policyVersion: 12
  owner: platform-security
spec:
  trustTiers:
    low:
      budgets:
        shell.exec.perMinute: 5
        net.outbound.requestsPerMinute: 30
        fs.write.bytesPerMinute: 200000
      allow:
        - fs.read: ["./**"]
        - fs.write: ["./tmp/**"]
        - git.diff: ["*"]
      deny:
        - fs.write: ["/", "/etc/**", "~/.ssh/**"]
        - shell.exec: ["rm -rf *", "curl | sh", "powershell -enc *"]
      approvals:
        require:
          - capability: net.outbound
            when: context.network_zone == "prod"
          - capability: fs.write
            when: request.params.path matches "/infra/**"
    high:
      inherit: low
      budgets:
        shell.exec.perMinute: 20
exceptions:
  - id: EX-2026-001
    scope: repo
    match: context.repo.url == "git@github.com:org/legacy.git"
    expiresAt: "2026-05-01"
    allow:
      - fs.write: ["./vendor/**"]
```

### 3.3 Stable decision codes (must be documented)
- `SG_ALLOW`
- `SG_DENY_CAPABILITY_NOT_ALLOWED`
- `SG_DENY_BUDGET_EXCEEDED`
- `SG_DENY_POLICY_VIOLATION_PATTERN`
- `SG_APPROVAL_REQUIRED`
- `SG_FAIL_CIRCUIT_OPEN`
- `SG_FAIL_POLICY_UNAVAILABLE`
- `SG_ALLOW_DEGRADED_AUDIT_ASYNC` (degraded mode)

---

## 4) Enforcement engines
### 4.1 Policy evaluation pipeline
1. **Normalize** invocation → canonical form
2. **Enrich**:
   - tool capability inference (if missing)
   - repo path normalization (anti-path traversal)
   - command parsing classification for shell/git
3. **Authorize**:
   - actor/workspace RBAC
   - tool provider trust
4. **Evaluate**:
   - allow/deny rules (deterministic)
   - budgets (token bucket / leaky bucket)
   - approvals (state lookup; can be async)
5. **Decide**
6. **Record evidence** (sync or async depending on latency mode)
7. **Emit telemetry** (async)

### 4.2 Execution boundary design
**Never** execute tool actions inside the same trust boundary as the model runtime without mediation.

- For local execution: prefer **sidecar** that runs with constrained OS permissions (seccomp/AppArmor on Linux).
- For remote MCP: gateway runs as a distinct service with its own IAM and audit keys.
- For filesystem: enforce a **chroot-like virtual root** (path allowlists + canonicalization + symlink escape protection).

### 4.3 Shell & git enforcement specifics
- Parse commands to:
  - detect banned patterns
  - restrict executables list (allow `git`, `python`, `npm` but deny `curl | sh`, `dd`, `mkfs`, etc.)
- **Argument injection defense**:
  - never build shell strings; always use argv arrays
  - escape/validate all inputs
  - disallow `--config` for git if policy denies
- Maintain `command_risk_score` and map to approval requirements.

### 4.4 Network enforcement specifics
- DNS allowlist/denylist + IP range blocks (RFC1918 control configurable)
- Egress policy by:
  - domain suffix
  - port
  - protocol
  - destination classification (internal/external)
- Rate limit per agent + per workspace + per tool.

---

## 5) Integrations (the moats)
## 5.1 Claude Code + MCP
Claude Code integrates tools via MCP, including plugins whose MCP servers start automatically when enabled (per Claude Code docs).  
References: https://code.claude.com/docs/en/mcp and https://code.claude.com/docs/en/plugins-reference

### 5.1.1 `skillgate-mcp-gateway`
**Role:** local/remote proxy that sits between Claude Code (client) and MCP servers (tools).

**Requirements:**
- Supports MCP transports used by Claude Code (start with HTTP; add stdio if needed).
- Discovers tool schemas from MCP servers, but exposes them to Claude only after policy validation (“tool registry allowlist”).
- Intercepts every `tool.call` and enforces:
  - capability budgets
  - path/network boundaries
  - approval requirements
- Produces **signed audit records**.

**Security hardening:**
- Validate MCP server manifests; forbid auto-loading from untrusted repo-local configs by default.
- Sandbox untrusted MCP servers (separate process, constrained permissions).
- Deny “filesystem + git server combined escalation” patterns by default (motivated by public reports of MCP server vulnerabilities).

### 5.1.2 Tool registry governance
- Maintain an **AI-BOM** for each MCP server/tool:
  - name, version, publisher, checksum, permissions requested
- CI rule: if permissions increase, require approval.

## 5.2 Codex CLI + CLI agents
OpenAI documents Codex CLI tooling including shell and patch tools.  
Reference: https://developers.openai.com/codex/cli/

### 5.2.1 `skillgate-codex-bridge`
**Goal:** ensure every high-risk tool action is mediated.
Deliverables:
- Wrapper command: `skillgate codex <args...>`
- Tool-proxy environment injection so tool calls are routed to `skillgate-enforcer-sidecar`
- Safe defaults:
  - deny running with repo-local config that adds/changes MCP servers unless explicitly allowed
  - enforce budgets for shell/network/fs
- CI mode: `skillgate codex --ci` hardens defaults and produces machine-readable policy reports.

### 5.2.2 Hardening against config poisoning
Codex/agent CLIs often read local configs from the repo; this is a supply-chain attack vector.  
SkillGate must:
- require explicit user confirmation / approval state for “new tool providers”
- block execution when untrusted tool providers appear in CI (fail closed)

## 5.3 VS Code extension (shift-left moat)
### 5.3.1 Capabilities
- Policy/manifest linting:
  - schema validation, unknown fields, deprecated patterns
  - diff-based warnings (capability expansion)
- Inline risk hints:
  - “This change adds net.outbound:* in prod → approval required”
- Local simulation:
  - “simulate tool invocation” panel that sends a sample ToolInvocation to local engine
- Workflows:
  - “Generate PR checklist” (policy changes) and “Open approval request”

### 5.3.2 Architecture
- Extension communicates with local `skillgate` binary via:
  - local HTTP (`localhost`) or stdio RPC
- No secrets stored in extension; rely on OS keychain for auth tokens if needed.

---

## 6) Non-functional requirements (NFRs)
### 6.1 Latency & performance targets
**Data plane enforcement budgets:**
- P50 decision latency: **≤ 5 ms** (in-process)
- P95 decision latency: **≤ 20 ms** (sidecar on same host)
- P99 decision latency: **≤ 50 ms** (worst-case with cache miss but no network dependency)

**MCP gateway overhead target:**
- Added overhead per tool call: **≤ 25 ms P95** (excluding tool execution time)

**Codex/CLI wrapper overhead target:**
- Added overhead per tool call: **≤ 30 ms P95** (excluding tool execution time)

### 6.2 Availability targets
- Sidecar: 99.9% local availability; must fail safe (see §6.5)
- Control plane: 99.5% early, 99.9% later

### 6.3 Scalability targets (initial)
- 1 workspace: 100 agents
- 10k tool invocations / minute sustained (burst 50k/min)
- Storage: 30 days hot audit logs + configurable retention

### 6.4 Rate limiting strategy
Use multi-dimensional rate limits:
- Per (workspace, agent) token buckets for:
  - `shell.exec`
  - `net.outbound`
  - `fs.write`
- Global per workspace cap (protects against runaway agent loops)
- Per tool provider cap (prevents one MCP server from dominating)

Implementation notes:
- In-process: local token buckets
- Sidecar/cluster: Redis-backed token buckets (or in-memory + gossip for small scale)

### 6.5 Circuit breakers & degraded modes
**Goal:** avoid cascading failures while staying safe.

Rules:
- If control plane is unreachable, **data plane must continue with cached policy snapshots** (TTL configurable, default 24h).
- If policy snapshot is missing/expired:
  - Default behavior: **fail closed** for critical capabilities; allow low-risk read-only actions if configured.
- If audit store is unavailable:
  - Option A (secure default): fail closed for high-risk capabilities.
  - Option B (degraded): allow but tag decisions `SG_ALLOW_DEGRADED_AUDIT_ASYNC`, buffer audit events locally (encrypted), and flush later.

Circuit breaker states:
- CLOSED: normal
- OPEN: external dependency failing (control plane/audit)
- HALF_OPEN: periodic probes

### 6.6 Consistency model
- Enforcement uses **policy snapshot** with a version number.
- Approvals may be eventually consistent; enforcement must embed `approval_state_version` in decision records.

### 6.7 Security requirements
- Mutual auth between components (mTLS in cluster; local token auth on dev)
- Signed evidence:
  - Ed25519 signatures (fast) over canonical JSON representation
  - Key rotation with KMS support (SaaS) or local key ring (OSS)
- Tamper-evident audit store:
  - append-only log with hash chaining per workspace (Merkle or simple rolling hash)
- Strict input validation:
  - path normalization, no symlink escapes
  - no shell string concatenation
  - no untrusted config auto-loading in CI mode
- Secrets:
  - never log secrets; redact by default with allowlist exceptions

### 6.8 Privacy & data minimization
- Store tool parameters only when needed; support “param hashing” mode.
- Support PII redaction for logs.
- Allow “metadata only” logging for regulated customers.

---

## 7) Observability, telemetry, and exports
### 7.1 Metrics (Prometheus/OpenTelemetry)
- `skillgate_decisions_total{decision_code, tool, workspace}`
- `skillgate_decision_latency_ms_bucket`
- `skillgate_budget_exceeded_total{capability}`
- `skillgate_circuit_state{component}`

### 7.2 Tracing
- Trace each invocation through:
  - gateway → enforcer → tool provider → response
- Include `invocation_id` for correlation.

### 7.3 Exports
- Webhooks:
  - decision events
  - approval events
  - anomaly alerts (Phase 4)
- SIEM connectors (Phase 3+):
  - Splunk HEC, Datadog, Elastic, Sentinel

---

## 8) Testing strategy (must-have)
### 8.1 Policy unit tests
- Deterministic evaluation test vectors:
  - same input → same decision
  - policy version changes → expected diffs
- Fuzz tests for:
  - path traversal
  - command parsing
  - JSON normalization

### 8.2 Integration tests
- MCP:
  - run a fake MCP server and validate gateway enforcement
- Codex wrapper:
  - simulate tool calls; ensure budgets and denials work
- VS Code extension:
  - golden snapshot tests for lint warnings

### 8.3 Performance tests
- Load test harness:
  - 10k/min steady, 50k/min bursts
  - p95 latency SLO checks
- Regression gate in CI: fail build if latency regresses >20%

### 8.4 Security tests
- Prompt injection scenarios that attempt:
  - tool escalation
  - config poisoning
  - argument injection
- “combo tool” tests (filesystem + git + shell) to validate defense-in-depth.

---

## 9) Phased execution plan (deliverables + acceptance criteria)
## Phase 1 (0–3 months): Capability Firewall Core
**Deliverables**
1. Canonical `ToolInvocation` + policy schema v1
2. `skillgate-enforcer` library (in-process)
3. `skillgate-enforcer-sidecar` (HTTP API)
4. Budgets + deterministic decision codes
5. Signed decision records (optional sync, default async)
6. CI policy test runner: `skillgate test-policy`

**Acceptance criteria**
- Determinism: 100% stable decisions across runs
- Latency: P95 ≤ 20ms (sidecar) under 10k/min
- Security: path traversal & argument injection tests pass

## Phase 2 (3–6 months): Claude/MCP + Codex embed
**Deliverables**
1. `skillgate-mcp-gateway` (Claude Code compatible)
2. MCP tool registry allowlisting + AI-BOM
3. `skillgate codex` wrapper + CI hardening mode
4. Repo templates:
   - “Secure Claude Code via MCP + SkillGate”
   - “Secure Codex CLI + SkillGate in CI”

**Acceptance criteria**
- Claude Code can use MCP tools through gateway with enforced policies
- Codex wrapper blocks untrusted tool provider configs by default in CI mode
- Gateway overhead P95 ≤ 25ms excluding tool runtime

## Phase 3 (6–9 months): VS Code + observability + workflow glue
**Deliverables**
1. VS Code extension v0:
   - lint + diff warnings + simulate
2. GitHub Action template: policy gate on PR
3. Telemetry exports + SIEM webhooks
4. Minimal dashboard (optional): decisions over time, top denied capabilities

**Acceptance criteria**
- Devs see inline warnings on capability expansions
- PR gates prevent unsafe policy/tool changes
- SIEM export works with at least one connector end-to-end

## Phase 4 (9–15 months): SaaS control plane + RBAC + intelligence v1
**Deliverables**
1. Control plane service (multi-tenant) + RBAC
2. Approval workflows (who can approve what)
3. Risk scoring v1 (rule-based → simple ML later)
4. Anomaly detection v1 (spike detection, new capability usage)

**Acceptance criteria**
- Workspace isolation verified
- Audit log retention policies honored
- Alerts produce low noise with tunable thresholds

## Phase 5 (15–18 months): Standardization + ecosystem
**Deliverables**
1. Public “SkillGate Capability Policy Spec” (v1.0)
2. Integration registry spec + community contributions flow
3. Hardening packs for common environments (dev/staging/prod templates)

**Acceptance criteria**
- At least one external integration PR merged
- Spec stable and used by 2+ integration surfaces (MCP + Codex + framework)

---

## 10) Implementation guardrails (to keep the project on track)
- **No UI-first detours:** UI only when it unlocks adoption (VS Code first, dashboard later).
- **Two deep integrations > ten shallow:** MCP + Codex are mandatory; add one agent framework only after they are stable.
- **Fail-safe defaults:** CI mode must fail closed for high-risk operations.
- **Backwards compatibility:** policy schema must remain versioned; never silently change semantics.
- **Performance is a feature:** enforcement must be boringly fast; treat latency regressions as bugs.

---

## 11) Appendix: Interfaces
### 11.1 Sidecar API (HTTP)
- `POST /v1/decide` → returns decision object
- `POST /v1/audit` (optional; async collector)
- `GET /v1/health`
- `GET /v1/policy/{name}` (cached snapshot)

### 11.2 Decision response (JSON)
```json
{
  "invocation_id": "uuid",
  "decision": "ALLOW|DENY|REQUIRE_APPROVAL",
  "decision_code": "SG_ALLOW",
  "reason_codes": ["RC_CAP_ALLOWED", "RC_BUDGET_OK"],
  "policy_version": 12,
  "budgets": {
    "shell.exec.perMinute": {"remaining": 3, "limit": 5}
  },
  "evidence": {
    "hash": "sha256:...",
    "signature": "ed25519:...",
    "signing_key_id": "key-2026-01"
  },
  "degraded": false
}
```

---

## 12) Appendix: Suggested tech choices (pragmatic defaults)
- Language: Go or Rust for gateway/sidecar (latency + single binary), Python SDK for framework integration.
- Policy evaluation: custom deterministic engine (avoid Turing-complete policies); optionally embed CEL for conditions.
- Storage:
  - audit hot store: Postgres + partitioning
  - append-only integrity: hash chaining per workspace
  - metrics: Prometheus + OTEL
- Rate limiting:
  - in-memory token buckets + optional Redis for shared quotas

---

## 13) References (primary)
- MCP overview (Anthropic): https://www.anthropic.com/news/model-context-protocol
- Claude Code MCP docs: https://code.claude.com/docs/en/mcp
- Claude Code plugins reference: https://code.claude.com/docs/en/plugins-reference
- MCP community hub: https://modelcontextprotocol.io/
- Codex CLI docs: https://developers.openai.com/codex/cli/
- F5 AI Guardrails: https://www.f5.com/go/solution/f5-ai-security-with-guardrails
- Lakera Guard: https://www.lakera.ai/lakera-guard and https://docs.lakera.ai/docs/integration
- HiddenLayer AI Runtime Security: https://www.hiddenlayer.com/platform/ai-runtime-security
- Protect AI platform: https://protectai.com/
