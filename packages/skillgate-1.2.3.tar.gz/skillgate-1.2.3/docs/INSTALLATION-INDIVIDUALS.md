# SkillGate Installation For Individuals

## Goal

Get SkillGate installed and producing a first policy-checked scan in under 5 minutes.

## Recommended Path

Use `pipx` as canonical install path.

Install:

```bash
pipx install skillgate
```

Verify:

```bash
skillgate version
```

First scan:

```bash
skillgate scan . --enforce --policy production
```

## Alternate Paths

- `pypi`: `python -m pip install --upgrade skillgate`
- `homebrew` (macOS): `brew install skillgate`
- `winget` (Windows): `winget install SkillGate.SkillGate`
- `npm_shim` (experimental): `npm install -g @skillgate-io/cli`
- `npm_shim` (no global install): `npx @skillgate-io/cli version`

## Upgrade

- `pipx upgrade skillgate`

## Rollback

Pin known-good version:

```bash
pipx install skillgate=={version}
```

## Support

- If install fails, use the fallback channel in `docs/INSTALLATION-GUIDE.md`.
- For strict/no-egress environments, use offline explanation mode:

```bash
skillgate scan . --explain --explain-source offline
```
