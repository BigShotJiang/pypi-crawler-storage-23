# SkillGate — Security & Compliance Document

**Product:** SkillGate  
**Version:** 1.0.0  
**Status:** Planning  
**Last Updated:** 2026-02-15  
**Classification:** Internal — Confidential  

---

## Table of Contents

1. [Security Posture Overview](#1-security-posture-overview)
2. [Threat Model](#2-threat-model)
3. [Security Architecture](#3-security-architecture)
4. [Data Handling & Privacy](#4-data-handling--privacy)
5. [Supply Chain Security](#5-supply-chain-security)
6. [Cryptographic Standards](#6-cryptographic-standards)
7. [Operational Security](#7-operational-security)
8. [Compliance Readiness](#8-compliance-readiness)
9. [Incident Response Plan](#9-incident-response-plan)
10. [Security Testing Requirements](#10-security-testing-requirements)

---

## 1. Security Posture Overview

SkillGate is a **security product** — it must hold itself to higher standards than the software it evaluates. Customers trust SkillGate with access to their source code and CI pipelines. A breach of SkillGate itself would be catastrophic to brand and revenue.

### 1.1 Security Principles

| Principle | Implementation |
|---|---|
| **Zero trust by default** | No network calls during local scan. No implicit permissions. |
| **Minimal data exposure** | Skill code never leaves the local machine unless user explicitly opts in. |
| **Defense in depth** | Multiple layers: input validation, sandboxed parsing, signed releases, dependency pinning. |
| **Transparency** | All detection rules are documented. Scoring is deterministic and explainable. |
| **Fail secure** | On error, SkillGate blocks (exit code 2) rather than silently passing. |

---

## 2. Threat Model

### 2.1 Threat Actors

| Actor | Motivation | Capability |
|---|---|---|
| Malicious skill author | Evade SkillGate detection | Custom obfuscation, social engineering |
| Supply chain attacker | Compromise SkillGate itself | Dependency poisoning, typosquatting |
| Competitor | Discredit product | Find and publicize bypasses |
| Insider (customer employee) | Bypass policy for convenience | Policy file manipulation |

### 2.2 Threat Scenarios

#### T1: Malicious Skill Evades Detection

**Scenario:** Attacker crafts a skill that bypasses SkillGate's static analysis.

**Mitigations:**
- Multi-layer detection (AST + regex + semantic)
- Obfuscation detection rules (SG-OBF-*)
- Continuous rule updates based on new malware samples
- Signed reports capture what version of rules was used (for non-repudiation)

**Residual risk:** Medium — static analysis will always have blind spots. Communicated honestly in docs.

#### T2: Supply Chain Attack on SkillGate Package

**Scenario:** Attacker publishes a malicious version of `skillgate` on PyPI or compromises a dependency.

**Mitigations:**
- All releases signed with project signing key
- Dependencies pinned with hashes in `requirements.txt` / `pyproject.toml`
- SBOM published per release
- Dependabot/Renovate for dependency monitoring
- Two-factor auth on PyPI publisher account
- GitHub Actions publishing (no manual uploads)

**Residual risk:** Low — standard open-source supply chain hygiene.

#### T3: SkillGate Parser Exploited by Malicious Skill

**Scenario:** A crafted skill bundle exploits a vulnerability in SkillGate's parser (e.g., zip bomb, path traversal, AST parser crash).

**Mitigations:**
- SkillGate never executes skill code (static analysis only)
- File size limits enforced (>100KB skipped)
- Path traversal blocked (all paths resolved relative to bundle root)
- Symlinks outside bundle root rejected
- Binary files skipped
- AST parsing errors handled gracefully (fallback to regex)

**Residual risk:** Low — but requires ongoing fuzzing.

#### T4: Tampered Attestation Report

**Scenario:** Someone modifies a signed report to show a false passing result.

**Mitigations:**
- Ed25519 signature verification
- SHA-256 hash of report contents
- `skillgate verify` command for independent verification
- Hosted verification endpoint (Phase 2)

**Residual risk:** Very low — Ed25519 is cryptographically strong.

#### T5: API Key Leakage

**Scenario:** Customer's SkillGate API key appears in logs, screenshots, or code.

**Mitigations:**
- API keys never appear in scan reports
- API keys never logged by SkillGate
- Keys stored via OS keychain or env var (not config file)
- Key rotation supported
- Keys prefixed with `sg_live_` / `sg_test_` for easy identification in secret scanners

**Residual risk:** Low — standard secret management practices.

#### T6: Denial of Service on Hosted API

**Scenario:** Attacker floods hosted API.

**Mitigations:**
- Rate limiting per API key and IP
- Tier-based limits (Free: 10/min, Pro: 60/min, Team: 300/min)
- WAF / DDoS protection via Cloudflare
- Hosted API is optional — CLI works fully offline

**Residual risk:** Low — hosted layer is thin and optional.

---

## 3. Security Architecture

### 3.1 Security Boundaries

```
┌─────────────────────────────────────────────────────────┐
│                   TRUST BOUNDARY                        │
│                                                         │
│  ┌─────────┐    ┌──────────┐    ┌──────────────┐       │
│  │ Skill   │ →  │ Parser   │ →  │ Analyzer     │       │
│  │ Bundle  │    │ (no exec)│    │ (static only)│       │
│  │ (untrusted)  └──────────┘    └──────────────┘       │
│  └─────────┘                                            │
│                                                         │
│  INPUT IS NEVER TRUSTED.                                │
│  CODE IS NEVER EXECUTED.                                │
│  NO NETWORK CALLS DURING ANALYSIS.                      │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 3.2 Hardening Measures

| Area | Measure |
|---|---|
| Input validation | All file paths resolved and sandboxed to bundle root |
| File handling | Binary detection, size limits, encoding validation |
| AST parsing | try/except around all AST operations, graceful fallback |
| Memory | No unbounded data structures; streaming where possible |
| Dependencies | Minimal dependency tree; well-established libraries only |
| Secrets | No hardcoded secrets; all config via env vars or keychain |
| Logging | No PII, no secrets, no skill source code in logs |

---

## 4. Data Handling & Privacy

### 4.1 Data Classification

| Data | Classification | Storage | Transmission |
|---|---|---|---|
| Scanned skill source code | **Customer Confidential** | Never stored by SkillGate | Never transmitted (local-only) |
| Scan results (findings) | **Internal** | Local only (unless opted to hosted) | HTTPS only to hosted API |
| Signed attestation reports | **Internal** | Local file system | Shareable by customer |
| API keys | **Secret** | OS keychain / env var | HTTPS only |
| Signing keys (private) | **Secret** | Local file system (600 perms) | Never transmitted |
| Signing keys (public) | **Public** | Local + optionally hosted | Shareable |

### 4.2 Privacy Guarantees

1. **Skill source code never leaves the machine.** SkillGate performs all analysis locally.
2. **No telemetry by default.** Opt-in only.
3. **Scan results are not sent to SkillGate servers** unless the user explicitly uploads them (Phase 2 hosted feature).
4. **No customer data is used for training, analytics, or any purpose** beyond the customer's own scan results.

### 4.3 Data Retention (Hosted, Phase 2)

| Data | Retention |
|---|---|
| Scan metadata | 90 days (configurable per tier) |
| Full scan reports | 30 days |
| Audit logs | 1 year |
| Account data | Duration of subscription + 30 days |
| Payment data | Handled by Stripe — SkillGate never stores card data |

---

## 5. Supply Chain Security

### 5.1 Dependency Management

- All dependencies explicitly declared in `pyproject.toml`
- All dependency versions pinned (exact version, not ranges)
- Hash verification for all installed packages
- Maximum of ~15 direct dependencies (minimize attack surface)

### 5.2 Approved Dependencies

| Dependency | Purpose | Vetted |
|---|---|---|
| `typer` | CLI framework | ✅ Well-maintained, PSF-aligned |
| `rich` | Terminal formatting | ✅ Widely used, maintained |
| `pydantic` | Data validation | ✅ Industry standard |
| `pyyaml` | YAML parsing | ✅ PSF, widely used |
| `pynacl` | Ed25519 crypto (libsodium) | ✅ Audited cryptography |
| `httpx` | HTTP client (for URL scanning) | ✅ Modern, well-maintained |
| `tree-sitter` | Multi-language AST | ✅ GitHub-maintained |

### 5.3 Release Integrity

- All releases built via GitHub Actions (reproducible)
- Release artifacts signed with project key
- SBOM (Software Bill of Materials) generated per release
- Provenance attestation via GitHub Artifact Attestations (sigstore)
- SHA-256 checksums published for all release artifacts

### 5.4 Dependency Update Process

1. Dependabot/Renovate opens PR for new dependency version
2. CI runs full test suite against new version
3. Security review if dependency is security-critical (crypto, parsing)
4. Merge only if all tests pass and no CVEs introduced

---

## 6. Cryptographic Standards

### 6.1 Signing

| Parameter | Value |
|---|---|
| Algorithm | Ed25519 (RFC 8032) |
| Library | PyNaCl (libsodium binding) |
| Key size | 256-bit (Ed25519 standard) |
| Signature size | 64 bytes |
| Key storage | PEM format (PKCS8 private, SubjectPublicKeyInfo public) |
| Key generation | OS entropy source (os.urandom / libsodium randombytes) |

### 6.2 Hashing

| Parameter | Value |
|---|---|
| Algorithm | SHA-256 |
| Usage | Bundle integrity, report canonical form |
| Library | hashlib (stdlib) |

### 6.3 Transport (Hosted API)

| Parameter | Value |
|---|---|
| Protocol | TLS 1.3 (minimum TLS 1.2) |
| Certificate | Let's Encrypt (auto-renewed) |
| HSTS | Enabled |
| Certificate pinning | Not required (standard CA trust) |

### 6.4 API Key Format

```
sg_{environment}_{random}

Environment: live | test
Random: 32 chars, base62 (a-z, A-Z, 0-9)

Example: sg_live_aB3cD4eF5gH6iJ7kL8mN9oP0qR1sT2u
```

Designed to be easily identified by secret scanners (GitHub, GitGuardian, etc.).

---

## 7. Operational Security

### 7.1 Infrastructure Security (Hosted, Phase 2)

| Area | Measure |
|---|---|
| Hosting | Managed platform (Railway/Fly.io) — no raw server management |
| Database | Managed PostgreSQL with encryption at rest |
| Secrets | Platform secret management (never in code) |
| Access | SSO + MFA for infrastructure access |
| Monitoring | Sentry for error tracking, uptime monitoring |
| Backup | Daily automated database backups, 30-day retention |
| Network | No public database endpoints; internal networking only |

### 7.2 Development Security

| Area | Measure |
|---|---|
| Source control | GitHub with branch protection (require PR + review) |
| CI/CD | GitHub Actions with least-privilege secrets |
| PyPI | MFA + trusted publisher (OIDC) for uploads |
| Code review | All security-sensitive changes require review |
| Secret scanning | GitHub secret scanning enabled on repository |
| Dependency scanning | Dependabot alerts enabled |

---

## 8. Compliance Readiness

### 8.1 Standards Alignment

SkillGate is designed to support customers' compliance requirements, not to hold certifications itself initially. The product architecture enables customers to meet:

| Standard | How SkillGate Supports |
|---|---|
| SOC 2 Type II | Signed attestation reports, audit logs, policy enforcement evidence |
| ISO 27001 | Risk scoring, policy controls, change traceability |
| NIST CSF | Identify (risk scoring), Protect (policy enforcement), Detect (scanning) |
| GDPR | No customer data stored by default; privacy-by-design |

### 8.2 Audit Evidence

SkillGate produces artifacts useful for audits:

1. **Signed attestation reports** — cryptographic proof that a specific skill was scanned with specific rules at a specific time
2. **Policy files** — versioned, reviewable policy configurations
3. **SARIF reports** — standardized format consumable by enterprise security tooling
4. **CI/CD logs** — integration with existing CI audit trails

### 8.3 Future Compliance Path

When pursuing formal compliance (post-$5K MRR):

1. SOC 2 Type I → Type II for hosted service
2. GDPR Data Processing Agreement (DPA) for Enterprise tier
3. Penetration test by third party (annual)

---

## 9. Incident Response Plan

### 9.1 Severity Levels

| Level | Definition | Response Time | Examples |
|---|---|---|---|
| P0 (Critical) | Product compromise, data breach | <1 hour | Supply chain attack, key compromise |
| P1 (High) | Security bypass, detection failure | <4 hours | Rule bypass for known malware |
| P2 (Medium) | Vulnerability, non-exploited | <24 hours | Dependency CVE, edge case crash |
| P3 (Low) | Minor issue, not exploitable | <72 hours | False positive rate increase |

### 9.2 Response Procedures

#### P0: Critical

1. Revoke compromised credentials immediately
2. Pull affected release from PyPI
3. Publish security advisory (GitHub Security Advisory)
4. Contact affected customers directly
5. Release patched version within 4 hours
6. Post-incident review within 48 hours

#### P1: High

1. Assess scope and impact
2. Develop and test fix
3. Release patched version within 24 hours
4. Publish security advisory
5. Post-incident review within 1 week

#### P2–P3: Medium/Low

1. Track in issue tracker
2. Fix in next regular release
3. Update CHANGELOG with security note

### 9.3 Security Contact

```
support@skillgate.io
```

GPG key for encrypted reports available at: `https://skillgate.io/.well-known/security.txt`

---

## 10. Security Testing Requirements

### 10.1 Automated Security Tests

Run as part of every CI pipeline:

| Test | Scope | Tool |
|---|---|---|
| Dependency vulnerability scan | All dependencies | `pip-audit` / `safety` |
| Secret detection | All source files | `detect-secrets` |
| SAST | Python source | `bandit` |
| License compliance | Dependencies | `liccheck` |
| Type safety | All source | `mypy --strict` |

### 10.2 Manual Security Reviews

Required for:
- Any changes to `core/signer/` (cryptography)
- Any changes to `core/parser/` (untrusted input handling)
- Any changes to authentication/license validation
- Any new dependency addition
- Any release to PyPI

### 10.3 Fuzzing (Post-Launch)

Target: `core/parser/` module

Tool: `atheris` (Python fuzzing framework)

Objective: Find parser crashes or unexpected behavior with malformed skill bundles.

### 10.4 Penetration Testing (Post-$5K MRR)

Scope: Hosted API and web dashboard

Frequency: Annually

Provider: Independent third-party security firm

---

*End of Security & Compliance Document — Version 1.0.0*
