# Production Setup: Netlify (Web UI) + Railway (API + Worker)

This guide covers production deployment with:
- Web UI on Netlify
- API on Railway
- Worker on Railway
- CLI distribution via PyPI (and optional npm wrapper/scripts)

## 1) Architecture

- Netlify site serves `web-ui`
- Railway API service runs FastAPI (`uvicorn`)
- Railway Worker service runs ARQ (`arq`)
- Railway Postgres + Redis plugins back API/worker

## 2) Railway services

Create these in Railway:
- `skillgate-api` (service from repo)
- `skillgate-worker` (service from repo)
- Postgres plugin
- Redis plugin

Use the same repo for API and Worker, with different start commands.

## 3) Railway build/start commands

For both API and Worker services:

Build command:

```bash
pip install -e ".[api,otel,worker]"
```

API start command:

```bash
uvicorn skillgate.api.app:create_app --factory --host 0.0.0.0 --port $PORT
```

Worker start command:

```bash
arq skillgate.api.worker.WorkerSettings
```

## 4) Railway environment variables

Set these on both API and Worker unless noted:

```bash
SKILLGATE_ENV=production
SKILLGATE_DATABASE_URL=postgresql+asyncpg://<user>:<pass>@<host>:<port>/<db>
SKILLGATE_REDIS_URL=redis://default:<pass>@<host>:<port>
SKILLGATE_JWT_SECRET=<secure-random-at-least-32-chars>
SKILLGATE_API_KEY_PEPPER=<secure-random-at-least-32-chars>
SKILLGATE_CORS_ORIGINS=https://<your-netlify-domain>
SKILLGATE_ENABLE_HSTS=true
```

Stripe (API service):

```bash
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_PRO_MONTHLY=price_...
STRIPE_PRICE_PRO_YEARLY=price_...
STRIPE_PRICE_TEAM_MONTHLY=price_...
STRIPE_PRICE_TEAM_YEARLY=price_...
STRIPE_PRICE_ENT_MONTHLY=price_...
STRIPE_PRICE_ENT_YEARLY=price_...
```

Email verification (API service, Resend):

```bash
RESEND_API_KEY=re_...
SKILLGATE_EMAIL_FROM=no-reply@yourdomain.com
SKILLGATE_WEB_BASE_URL=https://<your-netlify-domain>
```

Important: if Railway gives `postgres://...`, convert it to `postgresql+asyncpg://...` for `SKILLGATE_DATABASE_URL`.

## 5) Run migrations on Railway

Run once after env vars are set, and on each schema release:

```bash
railway run alembic upgrade head
```

## 6) Netlify setup (web-ui)

Netlify site settings:
- Base directory: `web-ui`
- Build command: `npm ci && npm run build`
- Next.js runtime: use Netlify's Next.js support (do not force static export unless intended)

Netlify environment variables:

```bash
NEXT_PUBLIC_API_URL=https://<your-railway-api-domain>/api/v1
NEXT_PUBLIC_ANALYTICS_ENDPOINT=<optional>
```

Make sure your Railway `SKILLGATE_CORS_ORIGINS` includes the final Netlify domain.

## 7) Production verification checklist

API health:

```bash
curl -fsS https://<your-railway-api-domain>/api/v1/health
```

Local smoke against deployed API:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
API_BASE="https://<your-railway-api-domain>/api/v1" ./scripts/deploy/smoke_api.sh
```

Local smoke against deployed web:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
WEB_BASE="https://<your-netlify-domain>" ./scripts/deploy/smoke_web.sh
```

Canary gate (if you maintain canary + stable URLs):

```bash
cd /Users/spy/Documents/PY/AI/skillgate
CANARY_API_BASE=https://canary-api.example.com \
STABLE_API_BASE=https://api.example.com \
CANARY_WEB_BASE=https://canary.example.com \
STABLE_WEB_BASE=https://www.example.com \
./scripts/deploy/canary_gate.sh
```

## 8) CLI release paths

Python package (primary):

```bash
pip install skillgate
skillgate --version
```

Source install for internal testing:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
pip install -e ".[dev]"
skillgate --version
```

If you maintain npm wrappers/scripts, publish those separately and keep them thin wrappers around the Python CLI.

## 9) Common failure points

- Alembic runs against SQLite: Railway vars not loaded in that shell/context.
- API boot fails in production: weak/missing `SKILLGATE_JWT_SECRET` or `SKILLGATE_API_KEY_PEPPER`.
- Web checkout errors locally: missing/incorrect `NEXT_PUBLIC_API_URL`.
- Browser CORS failures: Netlify domain missing from `SKILLGATE_CORS_ORIGINS`.
