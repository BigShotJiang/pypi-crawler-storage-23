# SkillGate Release Docs

This folder is the source of truth for repeatable release execution.

## Contents

- `RELEASE-CHECKLIST-TEMPLATE.md` - copy this for every new release.
- `RELEASE-1.2.0-CHECKLIST.md` - current release checklist instance.
- `PUBLISH-PYTHON.md` - PyPI release runbook for `skillgate`.
- `PUBLISH-NPM.md` - npm release runbook for `@skillgate-io/cli`.
- `PUBLISH-DOTNET.md` - NuGet release runbook for `SkillGate.Client`.

## Policy

For every release:

1. Copy the checklist template into a versioned file (`RELEASE-X.Y.Z-CHECKLIST.md`).
2. Execute all gates and record operator initials + UTC timestamps.
3. Do not publish unless all required checks are green.
4. Link the checklist in the release PR and release notes.
