# Enterprise Readiness Checklist (Index)

This compatibility document preserves the historical top-level path for enterprise readiness guidance.

Canonical checklist:

- `docs/phase1/ENTERPRISE-READINESS-CHECKLIST.md`

Related readiness gates:

- `docs/section-11-risk-mitigation/READINESS-GATES.md`
- `docs/section-16-open-core-split-governance/READINESS-GATES.md`
- `docs/section-17-supabase-auth-migration/READINESS-GATES.md`
