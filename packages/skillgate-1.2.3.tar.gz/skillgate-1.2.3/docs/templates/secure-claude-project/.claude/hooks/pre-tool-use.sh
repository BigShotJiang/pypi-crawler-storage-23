#!/usr/bin/env sh
set -eu

# Gate tool invocation context through SkillGate.
printf '%s' "${1:-}" | skillgate gateway check --stdin || true
