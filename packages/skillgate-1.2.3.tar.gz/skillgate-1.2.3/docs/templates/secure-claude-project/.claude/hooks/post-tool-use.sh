#!/usr/bin/env sh
set -eu

# Scan tool output for poisoning/injection payloads.
printf '%s' "${1:-}" | skillgate gateway scan-output --stdin || true
