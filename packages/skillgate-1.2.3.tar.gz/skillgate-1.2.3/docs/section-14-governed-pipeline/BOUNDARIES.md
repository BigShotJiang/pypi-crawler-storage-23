# Boundaries (Fail-Closed)

## Must-Ship Scope (Now)

These areas are mandatory for the first production-ready Section 14 release:

- Orchestrator core + deterministic lifecycle (`17.109`).
- Policy-in-the-loop at every action boundary (`17.111`).
- Approval checkpoint engine + signed verification (`17.112`).
- Audit/evidence artifact model and proof export (`17.113`, `17.153`).
- Canonical finding schema across engines (`17.161`).
- Deterministic risk model versioning (`17.162`).
- End-to-end governed vertical slice (`17.163`).
- Reliability evidence pipeline (`17.154`).
- Governance-before-autonomy gate (`17.157`).
- Scope-freeze enforcement gate (`17.164`).

## Explicitly Deferred Scope

Do not implement in this cycle:

- Autonomous remediation PR generation (`17.115`).
- Sub-agent expansion (`17.118`).
- Full enterprise RBAC/retention expansion (`17.119`).
- Dual-mode CLI/session UX (`17.122`–`17.132`).
- Dashboard analytics UX for governance metrics (`17.155`, `17.159`).

## Non-Negotiable Engineering Constraints

- Deterministic behavior required for risk decisions and policy outcomes.
- No direct write path without approval verification.
- No external dependency failure can break local deterministic gate path.
- No production claim without linked proof artifact and passing tests.
- No hidden/manual exceptions in CI gates.

## Freeze Rule

If any P0 task is `Blocked` for >24h:

1. Stop P1/P2 work.
2. Resolve blocker or descoped alternative.
3. Update `TASKS.md` risk note and mitigation before continuing.
