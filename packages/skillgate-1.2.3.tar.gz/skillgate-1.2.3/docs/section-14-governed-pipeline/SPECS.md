# Implementation Specs (Section 14)

## 1) Canonical Finding Contract (`FindingV1`) — `17.161`

All finding producers (deterministic analyzer, enrichment, LLM reasoner) must emit one schema:

- `finding_id`: stable ID string.
- `type`: normalized taxonomy key.
- `severity`: `low|medium|high|critical`.
- `confidence`: `0.0..1.0`.
- `files[]`: `{ path, line_start, line_end }`.
- `reasoning_summary`: concise, non-CoT explanation.
- `exploit_scenario`: concise impact scenario.
- `policy_reference`: policy path or rule ID.
- `engine_source`: producer ID (`deterministic_v*`, `llm_reasoner_v*`, etc.).
- `provenance`: source artifact/file/hash offsets.
- `created_at`: UTC timestamp.

Rules:

- No chain-of-thought storage.
- Engine-specific fields must be attached in extension metadata, not top-level drift.
- JSON and SARIF emitters must map from the same canonical object.

## 2) Deterministic Risk Model Versioning — `17.162`

Risk decisions must be reproducible by versioned formula:

- `risk_model_version` required on every score output.
- Inputs locked and persisted:
  - severity_weight
  - confidence
  - exploitability_factor
  - repo_sensitivity
- Fallback path to existing deterministic scorer retained for compatibility.

Rules:

- Any formula change requires version bump.
- Same input snapshot must produce same score.
- Historical replay uses original `risk_model_version`.

## 3) Policy-in-the-Loop Orchestrator Boundaries — `17.109`, `17.111`, `17.112`

Required lifecycle:

`queued -> running -> paused -> awaiting_approval -> completed|failed|canceled`

Required control points:

- Plan step execution.
- File mutation operations.
- Command execution.
- Outbound network requests.

Rules:

- Every control point calls policy engine first.
- Deny result blocks action and logs evidence event.
- Approval-required actions must verify signed artifact before execution.

## 4) Proof Pack Export Contract — `17.113`, `17.153`

Proof pack must be deterministic and exportable:

- Policy decisions (allow/deny + reason).
- Signed attestations.
- Approval records (who/when/what scope).
- Runtime/session lineage summary.
- Hash manifest for all included files.

Rules:

- Pack must verify offline.
- Tampered file must fail pack verification.
- Export format must be versioned.

## 5) Governed Vertical Slice — `17.163`

Minimum shippable flow:

1. Trigger (PR/CLI/orchestrator job).
2. Multi-engine findings generation.
3. Canonical finding normalization.
4. Versioned risk scoring.
5. Policy decision.
6. Approval checkpoint (if required).
7. Signed proof pack export.

## 6) PR Triage Agent v1 (Read-Only) — `17.114`

Scope:

- Add deterministic read-only triage artifact generation from `ScanReport`.
- Include top-finding selection, remediation suggestions, and deterministic digest.
- Add deterministic markdown renderer for PR comment/issue output.
- No repo write actions; output is artifact/comment text only.

Contract:

- Sorting deterministic across finding order permutations.
- Triage artifact includes bundle, risk summary, top findings, remediations, digest.
- Output has no direct mutation side effects.

Required validation:

- Unit tests for deterministic digest and ordering.
- Unit tests for triage comment rendering content.

## 7) Mandatory Write Approval Path — `17.156`

Scope:

- Add explicit write-path enforcement API for orchestrator actions.
- Require signed approval artifact for write actions before execution continuation.
- Preserve policy-in-loop checks before approval verification.

Contract:

- Missing approval artifact blocks write path and sets `awaiting_approval`.
- Invalid approval artifact blocks write path.
- Valid signed artifact allows write path continuation.
- Default mode is fail-closed for strict/prod filesystem-class actions (approval required unless explicitly overridden).

Required validation:

- Unit tests for missing-approval block behavior.
- Unit tests for signed-approval allow behavior.
- Unit tests for policy-block precedence.

## 8) Runtime Enforcement Efficacy Corpus — `17.158`

Scope:

- Add fixture-driven adversarial runtime corpus with expected allow/block outcomes.
- Add parameterized integration test harness against runtime prechecks.
- Persist corpus and deterministic result artifact for audit replay.

Contract:

- Corpus cases are deterministic and reproducible.
- Each case asserts expected decision (`allowed`, `code`) against runtime engine.
- Adversarial and benign paths are both represented.

Required validation:

- Integration tests loading corpus fixtures and validating expected outcomes.

Rules:

- All failure paths produce deterministic exit/status and audit events.
- Flow must be testable end-to-end in CI.
