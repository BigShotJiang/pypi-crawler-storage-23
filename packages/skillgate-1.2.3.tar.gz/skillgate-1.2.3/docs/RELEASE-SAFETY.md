# Release Safety (16.28)

This runbook defines the zero-downtime release safeguards for API + web.

## Controls

1. Migration safety rehearsal
- Run `alembic upgrade head`.
- Rehearse rollback one revision and restore using `scripts/deploy/rollback_rehearsal.sh`.

2. API canary smoke
- Start API in canary mode.
- Validate `/api/v1/health` through `scripts/deploy/smoke_api.sh`.

3. Web canary smoke
- Build/start web app.
- Validate critical routes (`/`, `/pricing`, `/features`, `/docs`, `/contact`, `/privacy`, `/terms`) with `scripts/deploy/smoke_web.sh`.

4. Canary-vs-stable gate (deployed envs)
- Run `scripts/deploy/canary_gate.sh` with deployed canary/stable base URLs.
- Promotion is blocked if either canary or stable health checks fail.

5. Rollback readiness gate
- Release is blocked until migration rehearsal and canary smokes pass.
- Execute rollback drill via `scripts/deploy/rollback_trigger.sh` (dry-run in CI).

## CI Automation

- Workflow: `.github/workflows/release-safety.yml`
- Trigger: push to `main` and manual `workflow_dispatch`
- Manual deploy gate inputs:
  - `canary_api_base`
  - `stable_api_base`
  - `canary_web_base`
  - `stable_web_base`

## Local Rehearsal

```bash
export SKILLGATE_DATABASE_URL="postgresql+asyncpg://skillgate:skillgate@localhost:5432/skillgate"
pip install -e ".[dev,api]"
alembic upgrade head
./scripts/deploy/rollback_rehearsal.sh
./scripts/deploy/smoke_api.sh
RELEASE_ID=local DRY_RUN=true ./scripts/deploy/rollback_trigger.sh
```

```bash
cd web-ui
npm ci
npm run build
npm run start
../scripts/deploy/smoke_web.sh
```

```bash
CANARY_API_BASE=https://canary-api.example.com \
STABLE_API_BASE=https://api.example.com \
CANARY_WEB_BASE=https://canary.example.com \
STABLE_WEB_BASE=https://www.example.com \
./scripts/deploy/canary_gate.sh
```
