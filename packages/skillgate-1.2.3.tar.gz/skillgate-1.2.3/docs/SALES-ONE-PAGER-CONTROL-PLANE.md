# SkillGate Enterprise One-Pager

## Why Enterprise = Control Plane Infrastructure

SkillGate Enterprise is governance infrastructure for AI agent execution in regulated and high-assurance environments.

## Problem

- Static scanning alone does not control runtime execution risk.
- CI blocking without runtime governance leaves privilege drift and tool abuse gaps.
- Audit programs need deterministic evidence, not best-effort narratives.

## Enterprise Outcome

- Deterministic runtime governance through capability budgets and policy gates.
- Organization-wide trust propagation with signed provenance and lineage.
- Procurement-ready compliance evidence with control mappings and audit bundles.

## Capability Anchors

1. Runtime capability budgets and pre-execution policy checks.
2. Transitive risk and trust propagation graph.
3. Signed AI-BOM and cryptographic provenance evidence.
4. Governance APIs and decision-log export surfaces.
5. Private relay and air-gapped enforcement modes.

## Buyer Signals

- Regulated operations, internal control requirements, or external audits.
- Need to enforce policy at runtime, not only report findings.
- Need predictable go/no-go gates for agent-assisted execution.

## Decision Framing

Enterprise should be evaluated as security and governance infrastructure, not as a premium scanner tier.
