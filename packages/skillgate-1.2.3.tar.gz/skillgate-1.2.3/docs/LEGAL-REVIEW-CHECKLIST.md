# SkillGate Legal Review Checklist

**Purpose:** Reduce legal and compliance risk before launch and on each material release.  
**Scope:** Website copy, contracts, billing flows, data handling, security commitments, and enterprise sales documents.  
**Owner:** Product + Legal + Security  
**Cadence:** Pre-launch, quarterly, and before any high-impact change.

> This checklist is an operational aid, not legal advice.

## 1. Corporate and Contract Baseline

- [ ] Entity name, address, and governing law are consistent across website, terms, invoices, and order forms.
- [ ] Terms of Service and Privacy Policy show correct effective date and version history.
- [ ] Contract hierarchy is explicit: Order Form -> DPA -> Security Addendum -> Terms (or equivalent).
- [ ] Public promises do not exceed contractual commitments.
- [ ] Limitation of liability, indemnity, and warranty disclaimers are reviewed by counsel.

## 2. Data Protection and Privacy

- [ ] Data inventory exists for account, billing, telemetry, and support data.
- [ ] Data categories are mapped to purpose, legal basis, retention period, and deletion path.
- [ ] DPA includes controller/processor roles, subprocessors, SCCs/transfer mechanism, and audit rights.
- [ ] DSAR process exists (access, deletion, correction, portability, objection).
- [ ] Privacy notices match real product behavior (no mismatch between docs and implementation).

## 3. Security Representations

- [ ] Security commitments in docs/sales collateral are evidence-backed.
- [ ] Incident response terms define timeline, channels, and required notice content.
- [ ] Vulnerability disclosure policy and intake mailbox are active.
- [ ] Encryption at rest/in transit claims are accurate and environment-specific.
- [ ] Access control, key management, and logging controls are documented and implemented.

## 4. Billing and Commercial Risk

- [ ] Auto-renewal, cancellation, refund, and dispute language is clear and jurisdiction-safe.
- [ ] Stripe webhook states drive entitlement changes; UI success pages are non-authoritative.
- [ ] Refund and proration behavior is defined contractually and implemented consistently.
- [ ] Tax/VAT handling and invoice requirements are reviewed.
- [ ] Trial terms and conversion terms are explicit.

## 5. Product and Marketing Claims

- [ ] Absolute guarantees (e.g., "never", "always") are removed unless legally supportable.
- [ ] Security/compliance claims reference scope and limitations.
- [ ] SLA/SLO references match signed commitments.
- [ ] Open-source license attributions and third-party notices are complete.
- [ ] No misleading comparison claims against named competitors without substantiation.

## 6. Enterprise Procurement Readiness

- [ ] DPA template current and approved.
- [ ] Security addendum template current and approved.
- [ ] Subprocessor list and change-notice process documented.
- [ ] Business continuity and backup statements are accurate.
- [ ] Export controls/sanctions language present where required.

## 7. Operational Controls

- [ ] Legal owner and backup owner assigned for contract redlines.
- [ ] Security owner assigned for questionnaire responses.
- [ ] Incident escalation runbook includes legal/comms decision tree.
- [ ] Versioned policy repository maintained.
- [ ] Audit trail retained for legal text changes and approvals.

## 8. Release Gate (Go/No-Go)

- [ ] All critical legal blockers resolved.
- [ ] Redline review complete for net-new enterprise clauses.
- [ ] Website legal links resolve and match current versions.
- [ ] Backend behavior aligns with legal commitments (auth, retention, webhook idempotency, access control).
- [ ] Counsel sign-off recorded for release package.

## Evidence Attachments (Per Release)

- [ ] Terms version diff
- [ ] Privacy version diff
- [ ] DPA template version
- [ ] Security addendum template version
- [ ] Subprocessor list snapshot
- [ ] Security controls evidence references
