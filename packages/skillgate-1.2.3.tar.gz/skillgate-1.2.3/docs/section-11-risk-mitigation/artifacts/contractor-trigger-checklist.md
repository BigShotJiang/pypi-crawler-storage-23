# Contractor Trigger Checklist

Date: 2026-02-21

## Trigger Threshold

Start contractor onboarding when at least one is true:

- Sustained backlog > 2 active sections for > 10 days
- Weekly execution load repeatedly misses corrective action due dates
- MRR reaches operational trigger defined by product owner

## Readiness Checklist

- [x] Section execution packs exist (11/12/13/14)
- [x] Task boards include owner + status + evidence fields
- [x] Gate commands and artifact paths are documented
- [x] Current top corrective actions are explicit and dated
- [ ] Candidate role brief published
- [ ] Trial task packet prepared

## First Delegable Work Package

- Section 13 docs/web install conversion hardening (`17.141`, `17.142`, `17.150`, `17.151`)
