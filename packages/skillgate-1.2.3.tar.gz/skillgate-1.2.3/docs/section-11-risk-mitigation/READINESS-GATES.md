# Readiness Gates (Section 11)

## Gate A: Risk Register Integrity

- All six risks have owner, deadline, and current status.
- Every mitigation claim has linked evidence.

## Gate B: Control Effectiveness

- Mitigations materially reduce risk likelihood/impact.
- `at_risk` items have corrective actions and due dates.

## Gate C: Execution Discipline

- Weekly review cadence is current.
- Scope freeze triggers are respected for P0 risks.

## Release Decision

- `GO`: no P0 risk is `at_risk` without active corrective plan.
- `NO-GO`: any uncontrolled P0 risk.
