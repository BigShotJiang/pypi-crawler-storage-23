# Ralph Loop (Fail-Closed Risk Execution)

1. Select highest-priority active risk.
2. Execute next mitigation slice.
3. Run required validation checks.
4. Attach evidence in `PER-TASK-RECORDS.md`.
5. If mitigation fails gates, mark `At Risk` and escalate.
6. Move to `Mitigated` only after evidence and owner verification.
