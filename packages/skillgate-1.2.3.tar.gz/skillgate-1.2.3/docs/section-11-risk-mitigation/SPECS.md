# Implementation Specs (Section 11)

## Risk Register Contract

Each risk entry must include:

- `risk_id`
- `risk_name`
- `when_critical`
- `deadline`
- `owner`
- `mitigation_actions[]`
- `evidence_links[]`
- `status` (`not_started|in_progress|at_risk|mitigated|accepted`)

## Risk IDs (Mapped from Section 11)

- `R11-001`: Overbuilding before revenue
- `R11-002`: Detection commoditization risk
- `R11-003`: High false positive rate
- `R11-004`: Low GitHub Action adoption
- `R11-005`: Enterprise sales cycle length
- `R11-006`: Solo-execution burnout risk

## Required Controls

- Clear mitigation owner and timeline per risk.
- Evidence artifacts for each mitigation claim.
- Weekly review cadence and status delta logging.
- Escalation path if any risk enters `at_risk`.
