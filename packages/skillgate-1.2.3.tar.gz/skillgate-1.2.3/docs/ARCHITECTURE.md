# SkillGate — System Architecture Document

**Product:** SkillGate  
**Version:** 1.0.0  
**Status:** Planning  
**Last Updated:** 2026-02-15  
**Classification:** Internal — Confidential  

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Design Principles](#2-design-principles)
3. [System Components](#3-system-components)
4. [Module Architecture](#4-module-architecture)
5. [Data Flow](#5-data-flow)
6. [Data Models](#6-data-models)
7. [CI/CD Integration Architecture](#7-cicd-integration-architecture)
8. [Hosted Service Architecture (Phase 2)](#8-hosted-service-architecture-phase-2)
9. [Security Architecture](#9-security-architecture)
10. [Deployment Architecture](#10-deployment-architecture)
11. [Technology Stack](#11-technology-stack)
12. [Extension Points](#12-extension-points)

---

## 1. Architecture Overview

SkillGate follows a **CLI-first, local-first** architecture. The core engine runs entirely on the user's machine or CI runner. An optional hosted service layer is introduced in Phase 2 for license validation, signature verification, and dashboard functionality.

### 1.1 High-Level System Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                        USER LAYER                           │
│                                                             │
│  ┌───────────┐  ┌──────────────┐  ┌───────────────────┐    │
│  │    CLI     │  │ GitHub Action │  │  GitLab CI Job    │    │
│  └─────┬─────┘  └──────┬───────┘  └────────┬──────────┘    │
│        │               │                    │               │
│        └───────────────┼────────────────────┘               │
│                        ▼                                    │
├─────────────────────────────────────────────────────────────┤
│                     CORE ENGINE                             │
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌─────────┐  ┌────────────┐  │
│  │  Parser   │  │ Analyzer │  │ Scorer  │  │  Policy    │  │
│  │  Module   │──│  Module  │──│ Module  │──│  Engine    │  │
│  └──────────┘  └──────────┘  └─────────┘  └────────────┘  │
│                                                │            │
│                                                ▼            │
│  ┌──────────────┐  ┌─────────────┐  ┌──────────────────┐   │
│  │  Reporter    │  │  Signer     │  │   Output         │   │
│  │  Module      │──│  Module     │──│   Formatter      │   │
│  └──────────────┘  └─────────────┘  └──────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                  OPTIONAL HOSTED LAYER (Phase 2)            │
│                                                             │
│  ┌──────────┐  ┌───────────┐  ┌────────────┐              │
│  │ License  │  │ Signature │  │ Dashboard  │              │
│  │ Service  │  │ Verifier  │  │    API     │              │
│  └──────────┘  └───────────┘  └────────────┘              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Architecture Style

- **Modular monolith** — single deployable package with clean internal module boundaries
- **Pipeline architecture** — data flows through a sequence of processing stages
- **Plugin-based extensibility** — rules, policies, and output formats are pluggable

---

## 2. Design Principles

| Principle | Description |
|---|---|
| **Local-first** | Core engine runs entirely locally. No network dependency for scanning. |
| **Deterministic** | Detection and scoring are rule-based and reproducible. Same input = same output. |
| **Transparent** | Every risk score is explainable with specific rule IDs, line numbers, and weights. |
| **Extensible** | Rules, policies, output formats, and language parsers can be added without core changes. |
| **CI-native** | Designed primarily for CI/CD pipeline execution with proper exit codes and machine-readable output. |
| **Secure** | No skill code leaves the machine unless explicitly opted into a hosted feature. |
| **Testable** | Every module is independently testable. All public interfaces have comprehensive test coverage. |

---

## 3. System Components

### 3.1 Component Overview

```
skillgate/
├── cli/                    # CLI application layer
│   ├── app.py              # CLI entry point (Click/Typer)
│   ├── commands/           # Command implementations
│   │   ├── scan.py         # scan command
│   │   ├── verify.py       # verify command
│   │   ├── init.py         # init command
│   │   └── rules.py        # rules listing command
│   └── formatters/         # Output formatters
│       ├── human.py        # Human-readable output
│       ├── json.py         # JSON output
│       └── sarif.py        # SARIF format output
│
├── core/                   # Core engine (no I/O dependencies)
│   ├── parser/             # Skill bundle parsing
│   │   ├── bundle.py       # Bundle discovery and loading
│   │   ├── manifest.py     # Manifest file parsing
│   │   └── source.py       # Source file extraction
│   │
│   ├── analyzer/           # Static analysis engine
│   │   ├── engine.py       # Analysis orchestrator
│   │   ├── ast_analyzer.py # AST-based analysis
│   │   ├── pattern.py      # Regex pattern matching
│   │   └── rules/          # Detection rule definitions
│   │       ├── base.py     # Base rule interface
│   │       ├── shell.py    # Shell execution rules
│   │       ├── network.py  # Network access rules
│   │       ├── filesystem.py # File system rules
│   │       ├── eval.py     # Dynamic eval rules
│   │       ├── credential.py # Credential access rules
│   │       ├── injection.py  # Prompt injection rules
│   │       └── obfuscation.py # Obfuscation rules
│   │
│   ├── scorer/             # Risk scoring engine
│   │   ├── engine.py       # Scoring calculation
│   │   ├── weights.py      # Default weight configuration
│   │   └── severity.py     # Severity classification
│   │
│   ├── policy/             # Policy enforcement engine
│   │   ├── engine.py       # Policy evaluation
│   │   ├── loader.py       # Policy file loading + validation
│   │   ├── presets.py      # Built-in policy presets
│   │   └── schema.py       # Policy schema definition
│   │
│   ├── signer/             # Cryptographic signing
│   │   ├── engine.py       # Signing orchestrator
│   │   ├── ed25519.py      # Ed25519 implementation
│   │   └── keys.py         # Key management
│   │
│   └── models/             # Shared data models
│       ├── finding.py      # Finding data class
│       ├── report.py       # Report data class
│       ├── policy.py       # Policy data class
│       └── bundle.py       # Bundle data class
│
├── ci/                     # CI/CD integration layer
│   ├── github/             # GitHub-specific integration
│   │   ├── action.yml      # GitHub Action definition
│   │   ├── annotations.py  # PR annotation generation
│   │   └── status.py       # Check status management
│   └── gitlab/             # GitLab-specific integration
│       └── template.yml    # GitLab CI template
│
├── config/                 # Configuration management
│   ├── settings.py         # Application settings
│   ├── defaults.py         # Default configuration values
│   └── license.py          # License validation
│
└── tests/                  # Comprehensive test suite
    ├── unit/               # Unit tests (per module)
    ├── integration/        # Integration tests (cross-module)
    ├── e2e/                # End-to-end tests (full pipeline)
    ├── fixtures/           # Test fixtures and sample skills
    │   ├── safe/           # Known-safe skill samples
    │   ├── malicious/      # Known-malicious skill samples
    │   └── policies/       # Test policy files
    └── conftest.py         # Shared test configuration
```

### 3.2 Component Dependency Graph

```
CLI Layer ──────► Core Engine ──────► Models
    │                 │
    │                 ├── Parser
    │                 ├── Analyzer ──── Rules (pluggable)
    │                 ├── Scorer
    │                 ├── Policy Engine
    │                 ├── Signer
    │                 └── Reporter
    │
    ├── Formatters
    └── CI Adapters
```

**Key rule:** Core engine has zero dependencies on CLI or CI layers. It is a pure library.

---

## 4. Module Architecture

### 4.1 Parser Module

**Responsibility:** Load and normalize skill bundles from various sources.

```
Input: Path (local dir) or URL (ClawHub)
Output: SkillBundle model

SkillBundle:
  ├── manifest: SkillManifest
  ├── source_files: List[SourceFile]
  ├── metadata: BundleMetadata
  └── hash: str (SHA-256 of bundle)
```

**Supported manifest formats:**
- `SKILL.md` (OpenClaw format)
- `skill.json`
- `package.json` (with skill metadata)
- `pyproject.toml` (with skill metadata)

**Parser pipeline:**
1. Discover bundle root
2. Parse manifest → extract declared permissions, metadata
3. Enumerate source files → filter by language support
4. Compute bundle hash (for attestation)

### 4.2 Analyzer Module

**Responsibility:** Detect dangerous patterns in skill source code.

```
Input: SkillBundle
Output: List[Finding]
```

**Analysis pipeline:**
```
Source File ─┬─► AST Parser ──► AST Rule Matching ──► Findings
             │
             └─► Pattern Engine ──► Regex Matching ──► Findings
                                         │
                                         ▼
                                   Deduplication
                                         │
                                         ▼
                                  List[Finding]
```

**Rule interface:**

```python
class Rule(ABC):
    id: str              # Unique rule ID (e.g., "SG-SHELL-001")
    name: str            # Human-readable name
    description: str     # What this rule detects
    severity: Severity   # low | medium | high | critical
    weight: int          # Default risk weight
    category: Category   # shell | network | filesystem | eval | credential | injection | obfuscation

    @abstractmethod
    def analyze(self, source: SourceFile) -> list[Finding]:
        """Analyze a source file and return findings."""
        ...
```

**Rule categories and IDs:**

| Category | Rule ID Range | Examples |
|---|---|---|
| Shell Execution | SG-SHELL-001–099 | subprocess, os.system, exec patterns |
| Network Access | SG-NET-001–099 | HTTP requests, socket, DNS |
| File System | SG-FS-001–099 | File writes, path traversal |
| Dynamic Eval | SG-EVAL-001–099 | eval(), exec(), Function() |
| Credentials | SG-CRED-001–099 | Env var reads, key files, token patterns |
| Injection | SG-INJ-001–099 | Prompt injection, command injection |
| Obfuscation | SG-OBF-001–099 | Base64 payloads, char code tricks |

### 4.3 Scorer Module

**Responsibility:** Calculate aggregate risk score from findings.

```
Input: List[Finding]
Output: RiskScore

RiskScore:
  ├── total: int
  ├── severity: Severity (Low/Medium/High/Critical)
  ├── breakdown: dict[Category, int]
  └── findings_count: int
```

**Scoring algorithm:**
```python
total_score = sum(finding.rule.weight * severity_multiplier(finding) for finding in findings)
```

**Severity multipliers:**
| Severity | Multiplier |
|---|---|
| Low | 0.5 |
| Medium | 1.0 |
| High | 1.5 |
| Critical | 2.0 |

### 4.4 Policy Engine

**Responsibility:** Evaluate findings and score against organizational policy. Produce pass/fail decision.

```
Input: List[Finding], RiskScore, Policy
Output: PolicyResult

PolicyResult:
  ├── passed: bool
  ├── violations: List[PolicyViolation]
  ├── policy_name: str
  ├── policy_version: str
  └── enforcement_mode: str
```

**Policy schema (`skillgate.yml`):**

```yaml
version: "1"
name: "production"
description: "Production deployment policy"

thresholds:
  max_score: 60
  max_critical_findings: 0
  max_high_findings: 2

permissions:
  allow_shell: false
  allow_eval: false
  allow_network: true
  allowed_domains:
    - "api.example.com"
    - "cdn.example.com"
  allow_filesystem_write: false
  allowed_paths:
    - "/tmp/skillgate-*"

rules:
  disabled:
    - "SG-NET-003"  # Allow specific pattern
  severity_overrides:
    "SG-FS-002": "critical"  # Escalate specific rule
```

**Preset policies:**

| Preset | Max Score | Shell | Eval | Network | Description |
|---|---|---|---|---|---|
| `development` | 100 | ✅ | ✅ | ✅ | Permissive, warnings only |
| `staging` | 70 | ❌ | ❌ | ✅ | Moderate enforcement |
| `production` | 50 | ❌ | ❌ | Whitelist | Strict enforcement |
| `strict` | 30 | ❌ | ❌ | ❌ | Maximum restriction |

### 4.5 Signer Module

**Responsibility:** Generate and verify Ed25519-signed attestation reports.

```
Sign Flow:
  Report JSON ──► SHA-256 Hash ──► Ed25519 Sign ──► Signed Report

Verify Flow:
  Signed Report ──► Extract Signature ──► Ed25519 Verify ──► Pass/Fail
```

**Key management:**
- Keys generated locally: `~/.skillgate/keys/`
- Private key: `signing_key.pem` (Ed25519 private key)
- Public key: `signing_key.pub` (Ed25519 public key)
- Key generation: `skillgate keys generate`

**Signed report structure:**

```json
{
  "report": {
    "version": "1.0.0",
    "timestamp": "2026-02-15T10:30:00Z",
    "scanner_version": "1.0.0",
    "bundle_hash": "sha256:abc123...",
    "bundle_name": "example-skill",
    "risk_score": 45,
    "severity": "medium",
    "policy_applied": "production",
    "policy_passed": true,
    "findings_count": 3,
    "findings": [...]
  },
  "attestation": {
    "signer_public_key": "ed25519:xyz789...",
    "signature": "base64:signature...",
    "signed_at": "2026-02-15T10:30:01Z"
  }
}
```

### 4.6 Reporter Module

**Responsibility:** Generate output in multiple formats.

| Format | Use Case | Standard |
|---|---|---|
| Human-readable | CLI terminal output | Custom |
| JSON | Machine processing, storage | Custom schema |
| SARIF | GitHub Security tab, IDE integration | SARIF 2.1.0 |

---

## 5. Data Flow

### 5.1 Core Scan Pipeline

```
                    ┌──────────────────────────────────────────────────┐
                    │                SCAN PIPELINE                     │
                    │                                                  │
  Path/URL ────►   │  Parse ──► Analyze ──► Score ──► Enforce ──► Report
                    │    │          │          │          │          │  │
                    │    ▼          ▼          ▼          ▼          ▼  │
                    │ Bundle    Findings    Score     Decision    Output │
                    │                                                  │
                    └──────────────────────────────────────────────────┘
                                                          │
                                                          ▼
                                                    Exit Code (0/1/2)
```

### 5.2 CI/CD Pipeline Flow

```
Developer pushes PR
        │
        ▼
GitHub Action triggers
        │
        ▼
┌───────────────────┐
│  skillgate scan   │
│  --enforce        │
│  --policy prod    │
│  --output sarif   │
│  --sign           │
└────────┬──────────┘
         │
    ┌────┴────┐
    │         │
  Pass      Fail
    │         │
    ▼         ▼
 ✅ Merge   ❌ Block
 allowed    + annotations
            + findings in PR
```

### 5.3 Data Flow Invariants

1. **No skill code leaves the local environment** unless the user explicitly opts into a hosted feature
2. **Analysis is stateless** — no data persists between scan runs (unless signed report is saved)
3. **Pipeline is fail-fast** — parse errors abort before analysis begins
4. **Exit codes are deterministic** — same input + same policy = same exit code

---

## 6. Data Models

### 6.1 Core Models

```python
@dataclass
class SourceFile:
    path: Path              # Relative path within bundle
    language: Language       # python | javascript | typescript | shell | unknown
    content: str            # Raw file content
    lines: list[str]        # Split lines for annotation

@dataclass
class SkillManifest:
    name: str
    version: str | None
    author: str | None
    description: str | None
    declared_permissions: list[str]
    dependencies: list[str]

@dataclass
class SkillBundle:
    root: Path
    manifest: SkillManifest
    source_files: list[SourceFile]
    hash: str               # SHA-256 of bundle contents

@dataclass
class Finding:
    rule_id: str            # e.g., "SG-SHELL-001"
    rule_name: str
    severity: Severity      # low | medium | high | critical
    category: Category
    message: str            # Human-readable description
    file: str               # Relative file path
    line: int               # 1-based line number
    column: int | None      # 1-based column number
    snippet: str            # Code snippet containing the finding
    weight: int             # Risk weight for scoring
    remediation: str | None # Suggested fix

@dataclass
class RiskScore:
    total: int
    severity: Severity
    breakdown: dict[Category, int]
    findings_count: int

@dataclass
class PolicyResult:
    passed: bool
    violations: list[PolicyViolation]
    policy_name: str
    policy_version: str
    enforcement_mode: str   # "enforce" | "warn"

@dataclass
class PolicyViolation:
    rule: str               # Policy rule violated
    reason: str             # Human-readable reason
    finding: Finding | None # Related finding, if applicable

@dataclass
class ScanReport:
    version: str
    timestamp: str
    scanner_version: str
    bundle: SkillBundle
    findings: list[Finding]
    risk_score: RiskScore
    policy_result: PolicyResult | None
    attestation: Attestation | None

@dataclass
class Attestation:
    signer_public_key: str
    signature: str
    signed_at: str

class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class Category(str, Enum):
    SHELL = "shell"
    NETWORK = "network"
    FILESYSTEM = "filesystem"
    EVAL = "eval"
    CREDENTIAL = "credential"
    INJECTION = "injection"
    OBFUSCATION = "obfuscation"
```

### 6.2 Configuration Models

```python
@dataclass
class SkillGateConfig:
    """Top-level configuration from skillgate.yml"""
    version: str
    name: str
    description: str | None
    thresholds: ThresholdConfig
    permissions: PermissionConfig
    rules: RuleConfig

@dataclass
class ThresholdConfig:
    max_score: int = 60
    max_critical_findings: int = 0
    max_high_findings: int = 2

@dataclass
class PermissionConfig:
    allow_shell: bool = False
    allow_eval: bool = False
    allow_network: bool = True
    allowed_domains: list[str] = field(default_factory=list)
    allow_filesystem_write: bool = False
    allowed_paths: list[str] = field(default_factory=list)

@dataclass
class RuleConfig:
    disabled: list[str] = field(default_factory=list)
    severity_overrides: dict[str, str] = field(default_factory=dict)
```

---

## 7. CI/CD Integration Architecture

### 7.1 GitHub Action

**Action definition (`action.yml`):**

```yaml
name: "SkillGate Scan"
description: "Scan agent skills for security risks and enforce policy"
inputs:
  path:
    description: "Path to skill bundle"
    required: true
  policy:
    description: "Policy file path or preset name"
    required: false
    default: "production"
  fail-on-violation:
    description: "Fail the check if policy is violated"
    required: false
    default: "true"
  output-format:
    description: "Output format (human, json, sarif)"
    required: false
    default: "sarif"
  sign:
    description: "Generate signed attestation report"
    required: false
    default: "false"
  api-key:
    description: "SkillGate API key (for Pro/Team features)"
    required: false

outputs:
  risk-score:
    description: "Numeric risk score"
  severity:
    description: "Risk severity level"
  passed:
    description: "Whether policy check passed"
  findings-count:
    description: "Number of findings detected"
  report-path:
    description: "Path to generated report file"

runs:
  using: "composite"
  steps:
    - name: Install SkillGate
      run: pip install skillgate
    - name: Run Scan
      run: |
        skillgate scan ${{ inputs.path }} \
          --policy ${{ inputs.policy }} \
          --output ${{ inputs.output-format }} \
          ${{ inputs.sign == 'true' && '--sign' || '' }} \
          ${{ inputs.fail-on-violation == 'true' && '--enforce' || '' }}
```

**Usage example in workflow:**

```yaml
name: Skill Security Check
on: [pull_request]

jobs:
  skillgate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: skillgate/scan-action@v1
        with:
          path: ./skills/
          policy: production
          fail-on-violation: true
          output-format: sarif
        env:
          SKILLGATE_API_KEY: ${{ secrets.SKILLGATE_API_KEY }}
      - uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: skillgate-results.sarif
```

### 7.2 PR Annotation Architecture

```
Scan Result ──► Finding with file + line ──► GitHub Annotation API
                                               │
                                               ▼
                                          PR inline comment
                                          with finding details
```

**Annotation payload:**
```json
{
  "path": "skills/my-skill/handler.py",
  "start_line": 42,
  "end_line": 42,
  "annotation_level": "warning",
  "message": "[SG-SHELL-001] Shell execution detected: subprocess.run() call with user-controlled input. Risk weight: 40.",
  "title": "SkillGate: Shell Execution Risk"
}
```

### 7.3 GitLab CI Integration

```yaml
# .gitlab-ci.yml include
include:
  - remote: "https://skillgate.io/ci/gitlab-template.yml"

skillgate_scan:
  extends: .skillgate-scan
  variables:
    SKILLGATE_PATH: "./skills/"
    SKILLGATE_POLICY: "production"
    SKILLGATE_FAIL_ON_VIOLATION: "true"
```

---

## 8. Hosted Service Architecture (Phase 2)

### 8.1 Overview

The hosted layer is thin and optional. It provides:
1. License validation
2. Signature verification (public endpoint)
3. Scan history dashboard
4. Team management

### 8.2 Hosted Components

```
┌──────────────────────────────────────────────────────┐
│                   HOSTED SERVICE                      │
│                                                      │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │   API        │  │   Dashboard  │  │  License   │  │
│  │   Gateway    │  │   (SPA)      │  │  Service   │  │
│  │   (FastAPI)  │  │   (Next.js)  │  │            │  │
│  └──────┬──────┘  └──────┬───────┘  └──────┬─────┘  │
│         │                │                  │        │
│         └────────────────┼──────────────────┘        │
│                          │                           │
│                   ┌──────▼──────┐                    │
│                   │  PostgreSQL │                    │
│                   └─────────────┘                    │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### 8.3 API Endpoints (Phase 2)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/verify` | Verify a signed attestation report |
| POST | `/api/v1/scans` | Store scan result (authenticated) |
| GET | `/api/v1/scans` | List scan history (authenticated) |
| GET | `/api/v1/scans/{id}` | Get scan details (authenticated) |
| POST | `/api/v1/license/validate` | Validate license key |
| GET | `/api/v1/health` | Health check |

### 8.4 Infrastructure (Phase 2)

- **Hosting:** Railway / Fly.io / AWS ECS (cost-effective, auto-scaling)
- **Database:** PostgreSQL (managed — Supabase or RDS)
- **CDN:** Cloudflare (for skillgate.io)
- **Monitoring:** Sentry (errors) + PostHog (product analytics)
- **CI/CD:** GitHub Actions (dogfooding)

---

## 9. Security Architecture

### 9.1 Threat Model (for SkillGate Itself)

| Threat | Mitigation |
|---|---|
| Malicious skill exploits SkillGate parser | Sandboxed parsing, no dynamic code execution during analysis |
| Tampered attestation report | Ed25519 signature verification |
| API key leakage | Keys stored via OS keychain, env var support, never logged |
| Supply chain attack on SkillGate | Signed releases, dependency pinning, SBOM |
| Man-in-the-middle on hosted API | HTTPS only, certificate pinning |

### 9.2 Security Invariants

1. **SkillGate never executes skill code** — analysis is purely static
2. **No outbound network calls during scan** (local-only mode)
3. **Private signing keys never leave local machine**
4. **API keys are never included in scan reports**
5. **All hosted API communication is HTTPS with TLS 1.3**

### 9.3 Dependency Security

- All dependencies pinned with hashes
- Dependabot / Renovate for automated updates
- No transitive dependency with known CVEs at release time
- SBOM generated per release

---

## 10. Deployment Architecture

### 10.1 Distribution Channels

| Channel | Artifact | Update Mechanism |
|---|---|---|
| PyPI | `skillgate` package | `pip install --upgrade skillgate` |
| GitHub Releases | Binary + SBOM + signature | GitHub release assets |
| GitHub Marketplace | `skillgate/scan-action` | Action version tags |
| Docker Hub / GHCR | `skillgate/skillgate:latest` | Docker pull |
| Homebrew (future) | `brew install skillgate` | Homebrew tap |

### 10.2 Release Process

```
Feature branch ──► PR ──► CI (lint + test + type check)
                                    │
                                    ▼
                              Main branch
                                    │
                                    ▼
                            Tag (v1.x.x)
                                    │
                          ┌─────────┼─────────┐
                          ▼         ▼         ▼
                       PyPI     Docker     GitHub
                      Publish   Build     Release
                                          + SBOM
                                          + Signature
```

### 10.3 Version Strategy

- **SemVer 2.0** — `MAJOR.MINOR.PATCH`
- **MAJOR:** Breaking changes to CLI interface, policy schema, or report format
- **MINOR:** New features, new rules, new policy options
- **PATCH:** Bug fixes, rule improvements, documentation

---

## 11. Technology Stack

### 11.1 Core Stack

| Component | Technology | Rationale |
|---|---|---|
| Language | Python 3.10+ | Ecosystem alignment (OpenClaw), rich AST/parsing libs, rapid development |
| CLI Framework | Typer + Rich | Modern CLI UX, auto-help, colored output |
| AST Parsing | `ast` (Python), `tree-sitter` (multi-lang) | Reliable AST traversal across languages |
| Pattern Matching | `re` (stdlib) | No external dependency for core regex rules |
| Cryptography | `PyNaCl` (libsodium) | Industry-standard Ed25519 implementation |
| YAML Parsing | `PyYAML` + `pydantic` | Schema validation for policy files |
| Data Models | `pydantic` | Validation, serialization, schema generation |
| HTTP Client | `httpx` | Modern async HTTP (for URL scanning, hosted API) |
| Testing | `pytest` + `pytest-cov` + `pytest-xdist` | Standard Python testing, parallel execution |
| Linting | `ruff` | Fast, comprehensive Python linting |
| Type Checking | `mypy` (strict mode) | Static type safety |
| Packaging | `hatch` / `setuptools` | PyPI packaging and distribution |

### 11.2 CI/CD Stack

| Component | Technology |
|---|---|
| CI | GitHub Actions |
| Container | Docker (multi-stage build) |
| Registry | PyPI, GHCR, Docker Hub |

### 11.3 Hosted Service Stack (Phase 2)

| Component | Technology |
|---|---|
| API | FastAPI |
| Database | PostgreSQL |
| ORM | SQLAlchemy + Alembic |
| Auth | API key-based (Phase 2), JWT (Phase 3) |
| Hosting | Railway / Fly.io |
| Dashboard | Next.js (if needed) or server-rendered templates |

---

## 12. Extension Points

### 12.1 Custom Rules

Third-party or organization-specific rules can be added:

```python
# custom_rules/internal_policy.py
from skillgate.core.analyzer.rules.base import Rule, Finding

class InternalAPIBlockRule(Rule):
    id = "CUSTOM-001"
    name = "Internal API Usage"
    description = "Blocks usage of deprecated internal APIs"
    severity = Severity.HIGH
    weight = 30
    category = Category.NETWORK

    def analyze(self, source: SourceFile) -> list[Finding]:
        # Custom detection logic
        ...
```

**Loading custom rules:**
```yaml
# skillgate.yml
rules:
  custom_paths:
    - "./custom_rules/"
```

### 12.2 Custom Output Formats

New output formatters can be registered:

```python
from skillgate.cli.formatters.base import OutputFormatter

class JUnitFormatter(OutputFormatter):
    format_name = "junit"

    def format(self, report: ScanReport) -> str:
        # Generate JUnit XML
        ...
```

### 12.3 Language Parsers

New language support can be added:

```python
from skillgate.core.parser.source import LanguageParser

class RubyParser(LanguageParser):
    language = Language.RUBY
    extensions = [".rb"]

    def parse_ast(self, content: str) -> AST:
        # Ruby AST parsing via tree-sitter
        ...
```

---

*End of Architecture Document — Version 1.0.0*
