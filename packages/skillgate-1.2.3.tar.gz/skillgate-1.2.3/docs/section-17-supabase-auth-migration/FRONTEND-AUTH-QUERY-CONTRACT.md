# Frontend Auth Query Contract (Task 17.194)

Version: `v1`
Date: 2026-02-22

## Query Keys

- User/session state: `['auth', 'user']`
- Auth verification state: `['auth', 'verification']`

## Mutation Contract

- `signup`: no token persistence; invalidate `['auth','user']` to `null`.
- `login`: set tokens, then hydrate `['auth','user']` from `/auth/me`.
- `logout`: clear tokens, clear query cache, set `['auth','user']=null`.
- `requestPasswordReset`: no auth cache mutation.
- `confirmPasswordReset`: clear `['auth','user']` (session becomes stale).
- `requestEmailVerification`: no cache mutation.
- `confirmEmailVerification`: invalidate `['auth','user']`.

## Error Mapping

Frontend uses backend envelope mapping in `api-client.ts`:

- `401 -> UNAUTHORIZED`
- `403 -> FORBIDDEN`
- `409 -> CONFLICT`
- `429 -> RATE_LIMITED`
- `5xx -> SERVER_ERROR / SERVICE_UNAVAILABLE`

## Retry Policy (Auth Sensitive)

- `login`, `signup`, `logout`, `password-reset`, `verify-email`: `retry=false`
- `refresh` and `me`: bounded retry with max 1

## Contract Source

- Provider implementation: `web-ui/src/components/providers/AuthProvider.tsx`
- Hook contract module: `web-ui/src/lib/hooks/use-auth-contract.ts`
