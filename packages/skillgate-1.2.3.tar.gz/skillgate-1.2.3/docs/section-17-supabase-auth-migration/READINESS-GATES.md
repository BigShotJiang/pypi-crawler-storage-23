# Readiness Gates: Supabase Migration

## Hard GO/NO-GO Gate

Release state is `NO-GO` unless all conditions below are satisfied.

1. Provider abstraction (`local`, `supabase`) is implemented and validated.
2. Supabase JWT verification and claim checks are green with security tests.
3. Auth endpoint parity is validated (signup/login/refresh/logout/reset/verify/me).
4. Session revocation and abuse/rate-limit controls are validated in both provider modes.
5. Data ownership split is documented and enforced (no dual-writer ambiguity).
6. Alembic migration path remains deterministic for domain tables.
7. Existing critical security fixes (`16.29`–`16.35`) remain green.
8. Cutover and rollback rehearsals produce artifacts in `artifacts/`.
9. RLS policy catalog and enforcement tests are green for protected tables.
10. Supabase RPC/function contract tests are green and versioned.
11. Supabase egress allowlist, timeout, and retry policies are validated.
12. Performance and cache gates meet agreed auth/profile SLO budgets.
13. Frontend React Query hooks and backend auth envelope contracts are green.

## Mandatory Artifact Set

Required in `docs/section-17-supabase-auth-migration/artifacts/`:

1. Provider matrix test summary.
2. JWT verifier validation report.
3. Data ownership matrix and migration dry-run report.
4. Security regression summary (`16.29`–`16.35` coverage).
5. Staging cutover rehearsal log.
6. Rollback drill log.
7. RLS policy matrix and negative-access test report.
8. RPC function contract report.
9. Egress policy validation report.
10. Performance benchmark report.
11. Cache strategy verification report.
12. Frontend auth hook contract test report.

## Automatic NO-GO Triggers

- Any unresolved auth contract drift in protected endpoints.
- Any failing defense test related to auth, device flow, OAuth, or rate limits.
- Missing rollback steps for any completed task.
- Missing evidence artifact for any task marked `Ready for Gate` or `Complete`.
