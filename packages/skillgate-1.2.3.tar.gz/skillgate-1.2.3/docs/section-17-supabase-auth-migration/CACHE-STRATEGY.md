# Cache Strategy (Task 17.193)

Version: `v1`
Date: 2026-02-22

## Cache Layers and Authority

1. In-memory JWKS cache (authoritative source: Supabase JWKS endpoint).
2. In-memory per-request auth/profile memoization (authoritative source: DB/Supabase token claims).
3. Optional Redis for shared profile/session metadata (authoritative source remains DB).

## Object TTL / Invalidation Rules

### JWKS (`supabase_jwt._JWKS_TTL = 300s`)

- TTL: 5 minutes.
- Invalidate on:
  - explicit key-rotation event
  - signature/key lookup failure
  - operator manual invalidate call

### Profile cache

- TTL: 60 seconds (if enabled).
- Invalidate on:
  - profile update
  - email verification change
  - subscription status update

### Session/auth metadata cache

- TTL: 30 seconds (if enabled).
- Invalidate on:
  - logout
  - logout-all
  - refresh rotation
  - lockout/revocation mutations

## Safety Invariants

- Cache reads must never bypass:
  - `UserSession.revoked`
  - `User.is_active`
  - lockout windows
- Stale reads are allowed only for non-security profile decorations, never for authz decisions.
- Missing cache entries must fail open to authoritative source, not to permissive auth.

## Verification

- Existing JWT cache tests in `test_supabase_jwt.py`.
- Session revocation safety tests in `test_auth_edges.py`.
- Required artifact: `artifacts/cache-verification-report.md`.
