# Section 17 Execution Pack: Supabase Auth + Data Platform Migration

## Purpose

This folder is the mandatory execution contract for Section 16 in
`docs/IMPLEMENTATION-PLAN.md`.

It exists to make Supabase migration decisions test-enforced, reversible,
and security-auditable.

## Scope

- Introduce hosted auth provider abstraction (`local`, `supabase`).
- Migrate hosted auth and session flows to Supabase with compatibility mode.
- Define data ownership split between Supabase-managed auth data and SkillGate domain data.
- Define RLS policy catalog and Supabase SQL/RPC function contracts.
- Define egress controls, performance/SLO budgets, and cache strategy.
- Define frontend React Query auth/session hook contracts and parity checks.
- Preserve deterministic API contracts and security controls during migration.
- Add production cutover and rollback governance.

## Completion Promise (Mandatory)

No task is `Complete` unless:

1. Scope is implemented as specified.
2. Required tests and gates pass in CI and local reproduction.
3. Evidence artifacts exist and are linked in task records.
4. Backward-compatibility and rollback notes are recorded.

Any missing item means status cannot exceed `Ready for Gate`.

## Document Map

- `BOUNDARIES.md` - scope boundaries, non-goals, and fail-closed constraints.
- `SPECS.md` - technical specs for `17.173`–`17.195`.
- `TASKS.md` - task board, DoD, and evidence ledger.
- `READINESS-GATES.md` - hard GO/NO-GO criteria.
- `VALIDATION-CHECKS.md` - required validation commands and artifact checks.
- `PER-TASK-RECORDS.md` - per-task execution evidence.
- `RELEASE-DECISION.md` - final GO/NO-GO decision record.
- `CUTOVER-ROLLBACK-RUNBOOK.md` - staged rollout and objective rollback procedure.
- `AGENT-SKILLS-MANDATORY.md` - required skills and sequencing.

## Status Model

- `Not Started`
- `In Progress`
- `Blocked`
- `Ready for Gate`
- `Complete`

`Complete` is allowed only when all checks in `READINESS-GATES.md` pass.
