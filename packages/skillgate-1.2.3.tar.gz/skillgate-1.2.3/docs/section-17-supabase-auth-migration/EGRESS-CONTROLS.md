# Supabase Egress Controls (Task 17.191)

Version: `v1`
Date: 2026-02-22

## Allowed Destinations

Primary outbound host:
- Supabase project host derived from `SUPABASE_URL`

Optional explicit allowlist:
- `SKILLGATE_SUPABASE_EGRESS_ALLOWLIST` (comma-separated hosts)

Fail-closed behavior:
- Any destination host not in allowlist is blocked before request dispatch.

## Timeout, Retry, and Circuit Breaker Policy

- Timeout budget (existing client):
  - connect: 3s
  - read: 8s
  - write: 5s
  - pool: 2s
- Retry policy:
  - max retries: 2
  - exponential backoff with jitter (`retry_backoff_seconds`)
- Circuit breaker:
  - opens after 5 consecutive failures
  - open window: 30s
  - open state is non-retryable fail-fast

## Enforcement Source

- `skillgate/api/supabase_egress.py`
- `skillgate/api/supabase_client.py`
- `tests/unit/test_api/test_supabase_egress.py`

## Verification Artifact

- `artifacts/egress-policy-validation-report.md`
