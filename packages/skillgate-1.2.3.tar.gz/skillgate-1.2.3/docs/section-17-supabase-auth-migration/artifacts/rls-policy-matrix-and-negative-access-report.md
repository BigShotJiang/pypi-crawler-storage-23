# RLS Policy Matrix and Negative Access Report

Date: 2026-02-22

## Artifacts

- SQL catalog: `skillgate/api/migrations/supabase/002_rls_policies_v1.sql`
- Policy documentation: `RLS-POLICY-CATALOG.md`

## Validation Commands

- `./venv/bin/pytest -q tests/unit/test_quality/test_supabase_sql_contracts.py`

## Result

- `3 passed`
- Confirms deny-by-default grants revocation and subject/service-role policy clauses are present.
