# SkillGate Entitlement Guide

**Version:** 1.1.0  
**Last Updated:** 2026-02-18

Complete guide to tier-based entitlements, capability gating, and feature access in SkillGate.

---

## Table of Contents

1. [Overview](#overview)
2. [Pricing Tiers](#pricing-tiers)
3. [Capability Matrix](#capability-matrix)
4. [Free Tier Limits](#free-tier-limits)
5. [Pro Tier Features](#pro-tier-features)
6. [Team Tier Features](#team-tier-features)
7. [Enterprise Tier Features](#enterprise-tier-features)
8. [API Key Management](#api-key-management)
9. [Entitlement Enforcement Modes](#entitlement-enforcement-modes)
10. [Quota Management](#quota-management)
11. [Upgrade Paths](#upgrade-paths)

---

## Overview

SkillGate uses a **tier-based entitlement system** to control access to features and enforce usage limits. All tiers include the full 119-rule detection engine across 7 languages.

**Core Principles:**
- **CLI-first** — All tiers work offline; hosted services optional
- **Deterministic gating** — Entitlements checked via configured authority mode
- **Graceful degradation** — Features fail cleanly with upgrade prompts
- **No hidden limits** — All quotas and capabilities documented

**Monetization Enforcement (Sprint 7.1):**
- Free tier: 3 scans/day, max 5 findings returned
- Pro+: Unlimited scans, unlimited findings
- Team+: CI annotations, retroscan, hunt modes
- Enterprise: Custom policies, audit exports, key namespaces

---

## Pricing Tiers

| Tier | Monthly | Yearly | Use Case | API Key Prefix |
|------|---------|--------|----------|----------------|
| **FREE** | $0 | $0 | Individual developers, open-source projects | `sg_free_*` |
| **PRO** | $49 | $490 (save $98) | Professional developers, small teams | `sg_pro_*` |
| **TEAM** | $99 | $990 (save $198) | Development teams, CI/CD integration (5 seats) | `sg_team_*` |
| **ENTERPRISE** | Custom | Custom | Large organizations, compliance requirements | `sg_ent_*` |

**Billing:**
- Monthly or annual subscriptions via Stripe
- Annual billing saves ~17% (2 months free)
- All tiers support both monthly and yearly billing
- Open-source discount: 50% off Pro tier (verification required)
- Academic pricing: Free Team tier for .edu emails

---

## Capability Matrix

| Capability | Free | Pro | Team | Enterprise |
|------------|------|-----|------|------------|
| **Scan** | ✅ (3/day) | ✅ Unlimited | ✅ Unlimited | ✅ Unlimited |
| **Enforce** | ❌ | ✅ | ✅ | ✅ |
| **Sign** | ❌ | ✅ | ✅ | ✅ |
| **Explain** | ❌ | ✅ | ✅ | ✅ |
| **CI Annotations** | ❌ | ❌ | ✅ | ✅ |
| **CI Blocking** | ❌ | ❌ | ✅ | ✅ |
| **Custom Policy** | ❌ | ❌ | ❌ | ✅ |
| **Audit Export** | ❌ | ❌ | ❌ | ✅ |
| **Key Namespaces** | ❌ | ❌ | ❌ | ✅ |
| **Retroscan** | ❌ | ❌ | ✅ | ✅ |
| **Hunt Mode** | ❌ | ❌ | ✅ | ✅ |

**Capability Definitions:**

- **SCAN** — Run static analysis and generate findings
- **ENFORCE** — Block deployments based on policy violations
- **SIGN** — Generate cryptographic attestations (Ed25519)
- **EXPLAIN** — LLM-powered finding explanations and remediation guidance
- **CI_ANNOTATIONS** — GitHub PR annotations, SARIF upload
- **CI_BLOCKING** — Fail CI builds on policy violations
- **CUSTOM_POLICY** — Upload and distribute custom policy packs
- **AUDIT_EXPORT** — Export scan history as JSONL/CSV for compliance
- **KEY_NAMESPACES** — Team-specific signing key isolation
- **RETROSCAN** — Scan historical commits in bulk
- **HUNT** — Threat hunting mode with custom YARA-style rules

---

## Free Tier Limits

### Scan Quota

**Limit:** 3 scans per day (resets at midnight UTC)

```bash
$ skillgate scan ./skill
SkillGate v1.1.0 — Scan 1/3 today

[... findings ...]

$ skillgate scan ./skill  # 4th scan
ERROR: Daily scan quota exceeded (3/3 used)

Upgrade to Pro for unlimited scans:
  https://skillgate.io/pricing
```

**Quota Tracking:**
- Persisted to `~/.skillgate/quota.json`
- Reset happens at midnight UTC (deterministic, no clock drift)
- Quota bypassed for `--dry-run` mode

### Findings Cap

**Limit:** Top 5 findings returned (sorted by severity + weight)

```json
{
  "findings": [
    {"rule_id": "SG-SHELL-004", "severity": "critical", ...},
    {"rule_id": "SG-EVAL-001", "severity": "critical", ...},
    {"rule_id": "SG-NET-002", "severity": "high", ...},
    {"rule_id": "SG-FS-002", "severity": "high", ...},
    {"rule_id": "SG-INJ-001", "severity": "high", ...}
  ],
  "findings_total": 12,
  "findings_capped": true
}
```

**Sorting Order:**
1. Severity: `CRITICAL > HIGH > MEDIUM > LOW`
2. Weight: Higher weight first (50 > 40 > 30...)
3. Rule ID: Alphabetical tie-breaker

### Feature Restrictions

**Blocked Commands:**

```bash
$ skillgate scan --enforce ./skill
ERROR: Policy enforcement requires Pro tier

$ skillgate scan --sign ./skill
ERROR: Attestation signing requires Pro tier

$ skillgate scan --explain ./skill
ERROR: LLM explanations require Pro tier
```

**Exit Codes:**
- Entitlement errors exit with code `1` (same as policy violation)
- Upgrade CTA always displayed

---

## Pro Tier Features

**Unlocked at $49/month ($490/year):**

### Unlimited Everything

- ✅ **No scan quota** — Run as many scans as needed
- ✅ **No findings cap** — Get all findings, not just top 5
- ✅ **All rules** — Full 119-rule catalog across 7 languages

### Policy Enforcement

```bash
$ skillgate scan --enforce --policy production ./skill
✓ Policy passed — Risk score: 15/50

$ skillgate scan --enforce --policy strict ./skill
✗ Policy failed — Risk score: 45/30
  - max_score: Risk score 45 exceeds maximum allowed score 30
  - allow_shell: Shell execution is not permitted under this policy

Exit code: 1
```

### Signed Attestations

```bash
$ skillgate keys generate
Generated Ed25519 key pair:
  Public key: ~/.skillgate/keys/default.pub
  Private key: ~/.skillgate/keys/default.key (never share)

$ skillgate scan --sign --output json ./skill > report.json
Signed attestation:
  Bundle hash: sha256:a3f2e1...
  Timestamp: 2026-02-18T14:32:10Z
  Risk score: 15
  Signature: ed25519:9f32a1...

$ skillgate verify report.json
✓ Signature valid — Public key: fc8d2e...
```

**Attestation Use Cases:**
- Compliance audits — cryptographic proof of scan results
- Supply chain security — verify skill bundles before deployment
- CI/CD gating — only deploy signed + verified skills

### LLM Explanations (Opt-In)

```bash
$ skillgate scan --explain ./skill
Finding SG-SHELL-004: Shell injection vector: shell=True parameter
  File: scripts/deploy.py:15

Why this matters:
  The shell=True parameter allows shell metacharacters like `;`, `|`, `&&` to execute
  arbitrary commands. An attacker can exploit this by injecting malicious input.

How to fix:
  Use subprocess.run() with a list of arguments and shell=False (default):
  
  # BAD
  subprocess.run(f"git clone {repo}", shell=True)
  
  # GOOD
  subprocess.run(["git", "clone", repo], shell=False)

References:
  - OWASP Command Injection: https://owasp.org/...
  - CWE-78: https://cwe.mitre.org/data/definitions/78.html
```

**Privacy:**
- Explanations are **opt-in** via `--explain` flag
- Code snippets sent to hosted LLM (Claude/GPT-4)
- No code sent without explicit flag
- Can be disabled via `SKILLGATE_DISABLE_LLM=1`

### Pro Tier Rate Limits

| Resource | Limit |
|----------|-------|
| CLI scans | Unlimited (local) |
| Hosted API scans | 60/minute |
| LLM explanations | 60/hour |
| Signing operations | Unlimited (local) |

---

## Team Tier Features

**Unlocked at $99/month or $990/year (5 seats):**

### Team Management

```bash
$ skillgate teams create my-team
Team created: my-team (ID: team_a1b2c3...)

$ skillgate teams invite alice@company.com
Invitation sent to alice@company.com

$ skillgate teams list
╭────────────────┬───────────┬─────────╮
│ Team           │ Members   │ Scans   │
├────────────────┼───────────┼─────────┤
│ my-team        │ 3/5       │ 1,243   │
╰────────────────┴───────────┴─────────╯
```

**Seat Limits:**
- Team tier: 5 seats included
- Additional seats: $15/month each
- Seat enforcement: Team creation/invite gated on quota

### CI Annotations

**GitHub PR Annotations:**

```yaml
name: SkillGate Scan
on: pull_request

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: skillgate/scan-action@v1
        with:
          api-key: ${{ secrets.SKILLGATE_API_KEY }}
          policy: production
          annotate: true  # Team+ only
```

**Result:**
- Inline annotations on changed files
- SARIF upload to GitHub Security tab
- PR status check (pass/fail)
- Comment with risk score summary

**GitLab CI:**

```yaml
skillgate:
  stage: test
  script:
    - skillgate scan --policy production --ci-annotations .
  artifacts:
    reports:
      sast: skillgate-report.sarif  # Team+ only
```

### Retroscan Mode

Scan historical commits in bulk:

```bash
$ skillgate retroscan --since "2024-01-01" --branch main
Scanning 120 commits since 2024-01-01...

╭──────────┬──────────────┬───────────────┬────────╮
│ Commit   │ Date         │ Risk Score    │ Status │
├──────────┼──────────────┼───────────────┼────────┤
│ a3f2e1   │ 2024-02-15   │ 15            │ ✓      │
│ 9d4c2a   │ 2024-02-10   │ 55            │ ✗      │
│ 7b8f3e   │ 2024-02-05   │ 20            │ ✓      │
╰──────────┴──────────────┴───────────────┴────────╯

Export findings: skillgate retroscan --export findings.jsonl
```

**Use Cases:**
- Audit historical code for compliance
- Identify when risky patterns were introduced
- Retroactive policy enforcement

### Hunt Mode

Custom threat detection with YARA-style rules:

```bash
$ cat hunt-rules.yml
rules:
  - id: CUSTOM-001
    name: production_db_access
    pattern: 'postgresql://.*@prod-db'
    severity: critical
    message: "Production database access detected in skill"

$ skillgate hunt --rules hunt-rules.yml ./skills/
Found 3 matches for CUSTOM-001:
  - skill-a/db.py:42
  - skill-b/config.json:15
  - skill-c/deploy.sh:98
```

### Team Tier Rate Limits

| Resource | Limit |
|----------|-------|
| CLI scans | Unlimited (local) |
| Hosted API scans | 300/minute |
| Retroscan commits | 1,000/day |
| Hunt rule executions | 100/day |

---

## Enterprise Tier Features

**Custom pricing — Contact contact@skillgate.io**

### Custom Policy Packs

Upload and distribute custom policies:

```bash
$ skillgate policies upload ./custom-policy-pack.yml
Policy pack uploaded: pkg_a1b2c3...

$ skillgate policies list
╭─────────────────────────┬──────────┬──────────────╮
│ Policy Pack             │ Version  │ Distributed  │
├─────────────────────────┼──────────┼──────────────┤
│ fintech-compliance      │ 2.1.0    │ 45 teams     │
│ hipaa-strict            │ 1.5.0    │ 12 teams     │
╰─────────────────────────┴──────────┴──────────────╯
```

**Features:**
- Centralized policy distribution
- Version control for policies
- Compliance preset templates (SOC 2, HIPAA, PCI-DSS)
- Policy inheritance and composition

### Audit Export

Export scan history for compliance audits:

```bash
$ skillgate audit export --since "2025-01-01" --format jsonl
Exported 10,243 scans to audit-export.jsonl

$ skillgate audit export --format csv --include-findings
Exported 10,243 scans with 45,678 findings to audit-export.csv
```

**Export Formats:**
- **JSONL** — One scan per line, parseable by log aggregators
- **CSV** — Spreadsheet-compatible for compliance review
- **SARIF** — Static Analysis Results Interchange Format

**Compliance:**
- SOC 2 audit trail
- GDPR data retention compliance
- Immutable audit logs (append-only)

### Key Namespaces

Team-specific signing key isolation:

```bash
$ skillgate keys generate --namespace team-a
Generated key pair for namespace: team-a
  Public key: ~/.skillgate/keys/team-a.pub

$ skillgate scan --sign --namespace team-a ./skill
Signed with team-a key: ed25519:fc8d2e...
```

**Use Cases:**
- Separate keys per team/project
- Key rotation without global impact
- Multi-tenant key management

### On-Premise Validation

Validate scans against internal compliance API:

```yaml
# skillgate.yml
entitlement:
  on_prem_validation_url: "https://compliance.internal.company.com/validate"
```

**Flow:**
1. SkillGate scans skill locally
2. Sends hash + metadata to internal API
3. Internal API validates against company policies
4. Returns pass/fail with custom violations

### Enterprise Rate Limits

| Resource | Limit |
|----------|-------|
| CLI scans | Unlimited (local) |
| Hosted API scans | 1,000/minute (negotiable) |
| Audit exports | Unlimited |
| Custom policy deployments | Unlimited |

---

## API Key Management

### Local Storage

API keys are stored securely using the `SecretStore`:

**Priority:**
1. **Keychain** (macOS Keychain, Windows Credential Manager, Linux Secret Service)
2. **Environment variable** (`SKILLGATE_API_KEY`)
3. **None** (defaults to Free tier)

### Setting Your API Key

**Recommended (Keychain):**

```bash
$ skillgate auth login
Enter your API key: sg_pro_a1b2c3d4e5f6...
✓ Authenticated as Pro tier
```

**Environment Variable:**

```bash
export SKILLGATE_API_KEY=sg_pro_a1b2c3d4e5f6...
```

**CI/CD (GitHub Actions):**

```yaml
env:
  SKILLGATE_API_KEY: ${{ secrets.SKILLGATE_API_KEY }}
```

### Revoking Keys

```bash
$ skillgate keys revoke sg_pro_a1b2c3...
✓ Key revoked — generate a new key at https://skillgate.io/keys

$ skillgate auth logout
✓ Logged out — API key removed from keychain
```

---

## Entitlement Enforcement Modes

SkillGate supports four enforcement modes selected with `SKILLGATE_ENTITLEMENT_MODE`.

| Mode | Authority | Best For | Network Requirement |
|------|-----------|----------|---------------------|
| `local` | Local API key tier + local quota cache | Developer laptops, local testing | None |
| `saas` | SkillGate hosted entitlement/usage authority | Standard cloud production | Outbound access to SkillGate API |
| `private_relay` | Customer-hosted internal relay | Enterprise restricted CI/CD | Internal-only access to relay |
| `airgap` | Signed offline entitlement pack + local counter | Fully disconnected environments | None |

### 1) Local Mode

```bash
SKILLGATE_ENTITLEMENT_MODE=local
```

- Fastest setup, no external dependency.
- Local quota cache is convenience state and can be tampered with.
- Recommended for local development only.

### 2) SaaS Mode

```bash
SKILLGATE_ENTITLEMENT_MODE=saas
SKILLGATE_ENTITLEMENT_AUTHORITY_URL=https://api.skillgate.io
SKILLGATE_ENTITLEMENT_AUTHORITY_TIMEOUT_SECONDS=3
```

- Hosted service is authoritative for usage and entitlements.
- Local `quota.json` is non-authoritative in this mode.
- Optional signed entitlement preference:
  - `SKILLGATE_ENTITLEMENT_TOKEN`
  - `SKILLGATE_ENTITLEMENT_PUBLIC_KEY`

### 3) Private Relay Mode

```bash
SKILLGATE_ENTITLEMENT_MODE=private_relay
SKILLGATE_ENTITLEMENT_AUTHORITY_URL=http://skillgate-relay.internal
```

- CI calls only an internal relay inside customer infrastructure.
- No direct public internet calls required from CI runners.
- Relay enforces quota/seat decisions and returns authoritative allow/deny responses.

### 4) Air-Gap Mode

```bash
SKILLGATE_ENTITLEMENT_MODE=airgap
SKILLGATE_AIRGAP_PACK_PATH=.skillgate/airgap-pack.json
SKILLGATE_AIRGAP_EVENT_LOG=.skillgate/airgap-events.jsonl
```

- Designed for fully disconnected environments.
- Usage is enforced from signed offline entitlement packs and local counters.
- Pack lifecycle fields:
  - `token`, `public_key`, `expires_at`, `fail_policy`, `usage`
  - Optional: `grace_expires_at`
- Fail behavior:
  - `fail_policy=closed`: deny scans after expiry
  - `fail_policy=open`: allow only during explicit grace window (if configured)
- Requires operational rotation of signed entitlement packs before expiry.

### Scenario Selection Guide

- Local development and debugging: `local`
- Startup/SMB production on hosted stack: `saas`
- Enterprise CI with restricted egress: `private_relay`
- Classified/isolated deployments: `airgap`

---

## Quota Management

### Checking Quota

```bash
$ skillgate quota status
╭──────────────────┬─────────────╮
│ Metric           │ Status      │
├──────────────────┼─────────────┤
│ Scans today      │ 2/3         │
│ Last reset       │ 00:00 UTC   │
│ Next reset       │ 8h 15m      │
│ Tier             │ Free        │
╰──────────────────┴─────────────╯
```

### Reset Behavior

**Free Tier:**
- Resets at **midnight UTC** (deterministic)
- No roll-over of unused scans
- Quota file: `~/.skillgate/quota.json` (authoritative only in `local` mode)

**Pro+ Tiers:**
- No quota tracking (unlimited scans)
- Quota file not created

**Non-local authority modes (`saas`, `private_relay`, `airgap`):**
- Local `quota.json` is not used as source of truth for hosted enforcement.
- Authoritative checks happen through configured authority contract.
- Reconciliation endpoint: `POST /api/v1/entitlements/reconcile-usage`
- Decision log export: `GET /api/v1/entitlements/decision-logs`

### Hybrid Migration Runbook

Follow `/docs/sprint-7.3-hybrid-enforcement-runbook.md` for staged rollout:
- `local` -> `saas` (hosted authority)
- `saas` -> `private_relay` (internal-only CI authority)
- `private_relay` -> `airgap` (signed offline pack flow)

### Bypassing Quota (Pro+)

Pro+ users can scan without quota checks:

```bash
$ echo $SKILLGATE_API_KEY
sg_pro_a1b2c3d4e5f6...

$ skillgate scan ./skill
# No quota check — runs immediately
```

---

## Upgrade Paths

### Free → Pro

**Why upgrade:**
- Remove 3/day scan limit
- Unlock policy enforcement (`--enforce`)
- Enable signed attestations (`--sign`)
- Get LLM explanations (`--explain`)

**How to upgrade:**

```bash
$ skillgate upgrade pro
Redirecting to: https://skillgate.io/upgrade?tier=pro

# Complete checkout, get API key
$ skillgate auth login
Enter your API key: sg_pro_...
✓ Upgraded to Pro tier
```

### Pro → Team

**Why upgrade:**
- Add team members (5 seats)
- Enable CI annotations and blocking
- Unlock retroscan and hunt modes
- Share policies across team

**How to upgrade:**

```bash
$ skillgate upgrade team
Redirecting to: https://skillgate.io/upgrade?tier=team

# Complete checkout
$ skillgate teams create my-team
$ skillgate teams invite teammate@company.com
```

### Team → Enterprise

**Why upgrade:**
- Custom policy packs
- Audit exports for compliance
- Key namespaces for teams
- On-premise validation
- Dedicated support + SLA

**How to upgrade:**

Contact contact@skillgate.io for custom pricing.

---

## See Also

- [Policy Reference](POLICY-REFERENCE.md) — Policy schema and presets
- [Rule Catalog](RULE-CATALOG.md) — All 91 detection rules
- [CLI API Spec](CLI-API-SPEC.md) — Command-line interface reference
- [Pricing](https://skillgate.io/pricing) — Compare all tiers
