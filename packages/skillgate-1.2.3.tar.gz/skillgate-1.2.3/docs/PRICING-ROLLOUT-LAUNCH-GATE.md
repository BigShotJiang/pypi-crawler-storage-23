# Pricing Repositioning Launch Gate

## Scope

Launch gate for control-plane pricing narrative rollout (`17.97`).

## Go/No-Go Checklist

- [ ] Legal review approved for all pricing and compliance claims.
- [ ] Entitlement contract tests pass for tier claim alignment.
- [ ] Claim Ledger CI gate is green on current commit.
- [ ] Tier-gating gap tests are green for CLI + API proof paths.
- [ ] Reliability SLO gates are green on current commit.
- [ ] Support and sales objection playbook is approved (`17.96`).
- [ ] Homepage and pricing copy are in sync with plan matrix.
- [ ] Enterprise procurement links and contact paths are functional.
- [ ] Support team has updated tier differentiation script.
- [ ] Funnel analytics receiving pricing variant, stack interaction, matrix expansion, and CTA events.
- [ ] Staging smoke test completed on desktop and mobile.

## Rollback Criteria

Rollback if any of the following occurs within first release window:

- Conversion drop beyond agreed threshold vs baseline.
- Support ticket spike caused by tier confusion.
- Any verified mismatch between marketed and enforced capabilities.
- Broken checkout/contact CTA path on core pages.

## Rollback Actions

1. Revert pricing narrative variant to control stable baseline.
2. Disable matrix and experiment flags if instrumentation is noisy.
3. Restore prior pricing copy package from previous release tag.
4. Re-run funnel and entitlement contract tests before re-release.

## Staged Rollout Rehearsal Evidence

- Canary gate rehearsal: `scripts/deploy/canary_gate.sh`
- Web smoke rehearsal (desktop/mobile critical routes): `scripts/deploy/smoke_web.sh`
- Rollback rehearsal: `scripts/deploy/rollback_rehearsal.sh`
- Rollback trigger dry-run: `scripts/deploy/rollback_trigger.sh`
