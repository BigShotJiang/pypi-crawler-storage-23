# skillgate-go shim

Go client for SkillGate sidecar runtime decisions.

<p>
  <img src="../web-ui/public/images/hero-shield.svg" alt="SkillGate shield" width="64" />
</p>

## Install

```bash
go get github.com/skillgate-io/skillgate/go-shim
```

## Quick start

```go
import skillgate "github.com/skillgate-io/skillgate/go-shim"

client := skillgate.New(skillgate.DefaultConfig())
```

## Environment

- `SKILLGATE_SIDECAR_URL` (default `http://localhost:8910`)
- `SKILLGATE_SLT` (Bearer token)

## Quality checks

```bash
cd go-shim
go test ./...
go build ./...
```

## Notes

- This shim is a sidecar API client, not a policy engine.
- Decision logic remains centralized in SkillGate sidecar.
