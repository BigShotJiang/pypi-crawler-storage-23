# CLAUDE.md

This file provides guidance to Codex or Copilot when working with code in this repository.

## Project Overview

SkillGate is a CLI-first, local-first CI/CD policy enforcement tool that scans agent skills (OpenClaw ecosystem) for security risks and blocks unsafe code before deployment. It provides deterministic gating, signed attestation evidence (Ed25519), and native CI/CD integration (GitHub Actions, GitLab CI).

**Status:** Pre-implementation (planning phase complete, all docs in `docs/`).

## Build & Development Commands

```bash
# Create virtual environment
python -m venv venv

# Install dependencies in virtual environment
pip install -e ".[dev]"

# Run all tests
pytest

# Run tests in parallel
pytest -n auto

# Run a single test file
pytest tests/unit/test_rules/test_shell.py

# Run a single test by name
pytest -k "test_subprocess_detection"

# Lint
ruff check .

# Type check (strict mode required)
mypy --strict skillgate/

# Format
ruff format .

# Full CI check (must pass before any merge)
ruff check . && mypy --strict skillgate/ && pytest --cov=skillgate --cov-fail-under=90
```

## Architecture

**Modular monolith with pipeline architecture.** Data flows: Parse → Analyze → Score → Enforce → Report.

```
skillgate/
├── cli/              # Typer+Rich CLI layer — commands, formatters (human/json/sarif)
├── core/             # Pure library, zero I/O dependencies
│   ├── parser/       # Bundle discovery, manifest parsing (SKILL.md/skill.json/package.json/pyproject.toml)
│   ├── analyzer/     # Static analysis engine — AST (Python stdlib ast, tree-sitter for JS/TS/Shell) + regex
│   │   └── rules/    # Pluggable detection rules (SG-SHELL-*, SG-NET-*, SG-FS-*, SG-EVAL-*, SG-CRED-*, SG-INJ-*, SG-OBF-*)
│   ├── scorer/       # Weighted risk scoring — score = Σ(weight × severity_multiplier)
│   ├── policy/       # YAML policy enforcement — presets: development/staging/production/strict
│   ├── signer/       # Ed25519 signing via PyNaCl — key management in ~/.skillgate/keys/
│   └── models/       # Pydantic data models (Finding, RiskScore, PolicyResult, ScanReport, etc.)
├── ci/               # CI adapters (GitHub Action action.yml, GitLab template, PR annotations)
├── config/           # Settings, defaults, license validation
└── tests/            # Pyramid: ~65% unit, ~25% integration, ~10% e2e
    └── fixtures/     # safe/, malicious/, policies/ — representative skill samples
```

**Key constraint:** `core/` has zero dependencies on `cli/` or `ci/`. It is a pure library.

## Tech Stack

- **Python 3.10+**, Typer+Rich (CLI), Pydantic (models/validation), PyNaCl (Ed25519), httpx (async HTTP), PyYAML
- **AST parsing:** stdlib `ast` for Python, `tree-sitter` for JS/TS/Shell
- **Testing:** pytest + pytest-cov + pytest-xdist
- **Linting:** ruff | **Type checking:** mypy (strict) | **Packaging:** hatch/setuptools

## Critical Rules

### Performance & Latency (Priority)
- All code must be performance-oriented with best latency as the primary goal
- Cold start <2s, scan 10 files <3s, scan 100 files <10s, memory <256MB
- AST parsing is lazy — only parse files matching initial regex pre-filter
- Rules evaluated in parallel per file; skip files >100KB with warning
- No network calls during local scan (zero network latency)

### Security & Rate Limiting
- SkillGate never executes skill code — analysis is purely static
- No skill code leaves the local environment unless user explicitly opts in
- Private signing keys never leave local machine; API keys never in reports
- Hosted API rate limits: Free 10/min, Pro 60/min, Team 300/min, Enterprise 1000/min
- All hosted communication HTTPS with TLS 1.3; dependencies pinned with hashes

### Resilience & Production Readiness
- Pipeline is fail-fast — parse errors abort before analysis begins
- Exit codes are deterministic: 0=success, 1=policy violation, 2=internal error, 3=invalid input
- Graceful degradation: if LLM unavailable, deterministic analysis still runs
- Every feature ships with tests; no merge without green CI (ruff + mypy + pytest)
- Coverage ≥90% on all core modules; zero false negatives for critical patterns

### Quality Gates (Definition of Done)
- `ruff check` passes (zero errors)
- `mypy --strict` passes (zero errors)
- Unit + integration + E2E tests pass
- Coverage ≥90% on changed modules
- Error paths, edge cases (empty input, huge input, unicode, binary) tested
- Self-review with checklist before marking done; no TODO/FIXME without tracking issue

### Documentation
- Every public API function must have docstrings
- Rule interface: id, name, description, severity, weight, category + `analyze()` method
- Rule IDs follow `SG-{CATEGORY}-{NUMBER}` convention (e.g., SG-SHELL-001)
- Policy schema documented in `skillgate.yml` — version "1" required

### Token-Efficient Coding (Follow `/token-efficient-coding` skill)
- Produce correct, minimal code changes with minimal tokens
- Prefer small targeted edits over full rewrites; no restating prompts
- Bug fix → `file:line` + 1-sentence root cause + unified diff
- Refactor → unified diff only (≤120 lines)
- Code review → exactly 8 bullets: 3 bugs, 3 improvements, 2 questions (≤14 words each)
- Keep reasoning implicit; surface only for concurrency, distributed systems, security, tricky invariants

## Key Design Decisions

- **Deterministic scoring:** `score = Σ(finding.weight × severity_multiplier)` — no ML, no probabilistic components
- **Severity multipliers:** Low=0.5, Medium=1.0, High=1.5, Critical=2.0; score capped at 200 for display
- **Policy resolution order:** Built-in defaults → preset → project skillgate.yml → CLI flags (highest priority)
- **Manifest priority:** SKILL.md > skill.json > package.json > pyproject.toml
- **SARIF 2.1.0** output for GitHub Security tab integration
- **Canonical JSON** (sorted keys, no whitespace) for signing — SHA-256 hash then Ed25519 sign

## Implementation Plan Reference

6-sprint plan in [docs/IMPLEMENTATION-PLAN.md](docs/IMPLEMENTATION-PLAN.md). Sprint 1 (Core Engine) → Sprint 2 (Policy) → Sprint 3 (CI/CD) → Sprint 4 (Attestations + Launch) → Sprint 5 (Polish) → Sprint 6 (Hosted Layer).
