"""Add email_verification_tokens table for signup verification flow.

Revision ID: 20260218_0004
Revises: 20260218_0003
Create Date: 2026-02-18 13:30:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision = "20260218_0004"
down_revision = "20260218_0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing_tables = set(inspector.get_table_names())
    if "email_verification_tokens" in existing_tables:
        existing_indexes = {
            idx["name"] for idx in inspector.get_indexes("email_verification_tokens")
        }
        if "ix_email_verification_tokens_user_id" not in existing_indexes:
            op.create_index(
                "ix_email_verification_tokens_user_id",
                "email_verification_tokens",
                ["user_id"],
                unique=False,
            )
        return

    op.create_table(
        "email_verification_tokens",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("user_id", sa.String(length=36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("token_hash", sa.String(length=128), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("token_hash", name="uq_email_verification_tokens_token_hash"),
    )
    op.create_index(
        "ix_email_verification_tokens_user_id",
        "email_verification_tokens",
        ["user_id"],
        unique=False,
    )


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing_tables = set(inspector.get_table_names())
    if "email_verification_tokens" not in existing_tables:
        return
    existing_indexes = {idx["name"] for idx in inspector.get_indexes("email_verification_tokens")}
    if "ix_email_verification_tokens_user_id" in existing_indexes:
        op.drop_index(
            "ix_email_verification_tokens_user_id",
            table_name="email_verification_tokens",
        )
    op.drop_table("email_verification_tokens")
