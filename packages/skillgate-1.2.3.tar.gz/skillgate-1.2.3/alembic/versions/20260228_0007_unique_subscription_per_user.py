"""Enforce one subscription row per user.

Revision ID: 20260228_0007
Revises: 20260222_0006
Create Date: 2026-02-28 00:00:00
"""

from __future__ import annotations

import sqlalchemy as sa

from alembic import op

revision = "20260228_0007"
down_revision = "20260222_0006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        # Keep the most recently updated row per user_id so unique index creation
        # cannot fail on existing duplicate subscriptions.
        op.execute(
            sa.text(
                """
                DELETE FROM subscriptions s
                USING (
                    SELECT ctid
                    FROM (
                        SELECT
                            ctid,
                            row_number() OVER (
                                PARTITION BY user_id
                                ORDER BY
                                    updated_at DESC NULLS LAST,
                                    created_at DESC NULLS LAST,
                                    id DESC
                            ) AS rn
                        FROM subscriptions
                    ) ranked
                    WHERE ranked.rn > 1
                ) dupes
                WHERE s.ctid = dupes.ctid
                """
            )
        )

    op.execute(sa.text("DROP INDEX IF EXISTS ix_subscriptions_user_id"))
    op.execute(
        sa.text(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_subscriptions_user_id_unique "
            "ON subscriptions (user_id)"
        )
    )


def downgrade() -> None:
    op.execute(sa.text("DROP INDEX IF EXISTS idx_subscriptions_user_id_unique"))
    op.create_index("ix_subscriptions_user_id", "subscriptions", ["user_id"], unique=False)
