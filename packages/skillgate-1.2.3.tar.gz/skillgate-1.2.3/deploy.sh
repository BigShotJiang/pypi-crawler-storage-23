#!/bin/bash

# Netlify Deployment Script for SkillGate Web UI (skillgate.io)
# Usage: ./deploy.sh [preview|prod]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$SCRIPT_DIR"
WEB_UI_DIR="$ROOT_DIR/web-ui"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo "=========================================="
echo "  SkillGate Web UI Deployment"
echo "=========================================="
echo ""

if [ "$#" -gt 1 ]; then
    echo "Usage: ./deploy.sh [preview|prod]"
    exit 1
fi

if [ ! -d "$WEB_UI_DIR" ]; then
    echo "Missing web-ui directory at: $WEB_UI_DIR"
    exit 1
fi

# Check if netlify CLI is installed
if ! command -v netlify &> /dev/null; then
    echo "Netlify CLI not found. Installing..."
    npm install -g netlify-cli
fi

# Check if logged in
if ! netlify api getCurrentUser &> /dev/null; then
    echo "Not logged in to Netlify. Please login:"
    netlify login
fi

# Determine deployment type
DEPLOY_TYPE="${1:-prod}"
if [ "$DEPLOY_TYPE" != "preview" ] && [ "$DEPLOY_TYPE" != "prod" ]; then
    echo "Invalid deploy type: $DEPLOY_TYPE"
    echo "Usage: ./deploy.sh [preview|prod]"
    exit 1
fi

# Resolve Netlify site id for web-ui (skillgate.io)
SITE_ID="${NETLIFY_WEB_UI_SITE_ID:-}"
if [ -z "$SITE_ID" ]; then
    SITE_ID="$(netlify sites:list --json | python3 -c 'import json,sys
sites=json.load(sys.stdin)
for s in sites:
    custom=(s.get("custom_domain") or "").strip().lower()
    url=(s.get("url") or "").strip().lower()
    name=(s.get("name") or "").strip().lower()
    if custom=="skillgate.io" or url=="https://skillgate.io" or name=="skillgate-web":
        print(s.get("site_id") or s.get("id") or "")
        break
')"
fi

if [ -z "$SITE_ID" ]; then
    echo "Unable to resolve Netlify site id for web-ui (skillgate.io)."
    echo "Set NETLIFY_WEB_UI_SITE_ID in scripts/deploy/.env.cloud-cli.local, for example:"
    echo "  NETLIFY_WEB_UI_SITE_ID='<your-web-ui-site-id>'"
    exit 1
fi

cd "$WEB_UI_DIR"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}Installing npm dependencies...${NC}"
    npm install
fi

echo -e "${YELLOW}Running web-ui quality gate...${NC}"
npm run check

# Build deploy trace metadata for Netlify deploy message
if command -v git &> /dev/null && git -C "$ROOT_DIR" rev-parse --is-inside-work-tree &> /dev/null; then
    GIT_BRANCH="$(git -C "$ROOT_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo unknown-branch)"
    GIT_SHA="$(git -C "$ROOT_DIR" rev-parse --short HEAD 2>/dev/null || echo unknown-sha)"
else
    GIT_BRANCH="no-git"
    GIT_SHA="no-sha"
fi
DEPLOY_MESSAGE="skillgate-web deploy branch=${GIT_BRANCH} sha=${GIT_SHA} target=${DEPLOY_TYPE}"
echo -e "${YELLOW}Deploy trace:${NC} ${DEPLOY_MESSAGE}"

echo -e "${YELLOW}Using Netlify site id:${NC} ${SITE_ID}"

if [ "$DEPLOY_TYPE" = "preview" ]; then
    echo -e "${YELLOW}Deploying PREVIEW build (web-ui, Netlify build)...${NC}"
    echo ""
    netlify deploy --site "$SITE_ID" --build --message "$DEPLOY_MESSAGE"
    echo ""
    echo -e "${GREEN}Preview deployed! Check the URL above.${NC}"
else
    echo -e "${YELLOW}Deploying to PRODUCTION (web-ui, Netlify build)...${NC}"
    echo ""
    netlify deploy --site "$SITE_ID" --build --prod --message "$DEPLOY_MESSAGE"
    echo ""
    echo -e "${GREEN}Production deploy complete. Verify https://skillgate.io.${NC}"
fi

echo ""
echo "=========================================="
echo "  Deployment Complete"
echo "=========================================="
