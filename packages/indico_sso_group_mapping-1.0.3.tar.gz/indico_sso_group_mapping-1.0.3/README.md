# indico-sso-group-mapping is now indico-plugin-sso-group-mapping

This package has been renamed. Use `pip install indico-plugin-sso-group-mapping` instead.

New package: https://pypi.org/project/indico-plugin-sso-group-mapping/
