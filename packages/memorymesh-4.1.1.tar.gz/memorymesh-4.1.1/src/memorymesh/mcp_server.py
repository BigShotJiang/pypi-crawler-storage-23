"""MemoryMesh MCP Server -- Model Context Protocol interface.

Exposes MemoryMesh as an MCP tool server over stdin/stdout JSON-RPC,
allowing any MCP-compatible AI tool (Claude Code, Cursor, Windsurf, etc.)
to use ``remember``, ``recall``, ``forget``, ``forget_all``,
``memory_stats``, and ``session_start`` as first-class tools.

This module uses **only the Python standard library** (json, sys, logging)
so it introduces zero additional dependencies.

Configuration via environment variables:

    MEMORYMESH_PATH        Path to the project SQLite database file.
    MEMORYMESH_GLOBAL_PATH Path to the global SQLite database file.
    MEMORYMESH_EMBEDDING   Embedding provider name (default: "none").
    MEMORYMESH_OLLAMA_MODEL  Ollama model name when using ollama embeddings.
    OPENAI_API_KEY         API key when using openai embeddings.

Usage::

    # Run directly:
    python -m memorymesh.mcp_server

    # Or via the installed entry point:
    memorymesh-mcp
"""

from __future__ import annotations

import json
import logging
import os
import sys
from typing import Any

from memorymesh import __version__

from .core import MemoryMesh
from .memory import GLOBAL_SCOPE, PROJECT_SCOPE
from .store import detect_project_root

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logger = logging.getLogger("memorymesh.mcp_server")

# ---------------------------------------------------------------------------
# Protocol constants
# ---------------------------------------------------------------------------

JSONRPC_VERSION = "2.0"
MCP_PROTOCOL_VERSION = "2024-11-05"

SERVER_INFO = {
    "name": "memorymesh",
    "version": __version__,
}

# ---------------------------------------------------------------------------
# Security limits
# ---------------------------------------------------------------------------

MAX_TEXT_LENGTH = 100_000  # Maximum characters for memory text
MAX_METADATA_SIZE = 10_000  # Maximum serialized metadata JSON size (bytes)
MAX_MESSAGE_SIZE = 1_000_000  # Maximum JSON-RPC message size (bytes)
MAX_BATCH_SIZE = 50  # Maximum messages in a JSON-RPC batch
MAX_MEMORY_COUNT = 100_000  # Maximum total memories allowed

# ---------------------------------------------------------------------------
# Prompt and tool definitions
# ---------------------------------------------------------------------------

PROMPTS: list[dict[str, Any]] = [
    {
        "name": "memory-context",
        "description": (
            "Retrieve relevant memories for the current conversation context. "
            "Provides persistent knowledge from previous sessions."
        ),
        "arguments": [
            {
                "name": "context",
                "description": (
                    "Brief description of what you're working on (used to find relevant memories)."
                ),
                "required": False,
            }
        ],
    },
]

TOOLS: list[dict[str, Any]] = [
    {
        "name": "remember",
        "description": (
            "Store a new memory in MemoryMesh. Use this to save facts, preferences, "
            "decisions, or any information that should persist across conversations. "
            "Returns the unique memory ID."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The text content to remember.",
                },
                "metadata": {
                    "type": "object",
                    "description": (
                        "Optional key-value metadata to attach to the memory "
                        '(e.g., {"source": "user", "topic": "preferences"}).'
                    ),
                    "additionalProperties": True,
                },
                "importance": {
                    "type": "number",
                    "description": (
                        "Importance score between 0.0 and 1.0. Higher values make "
                        "the memory more prominent during recall. Default: 0.5."
                    ),
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": (
                        "Where to store the memory. 'project' (default) stores in "
                        "the current project's database. 'global' stores in the "
                        "user-wide database for preferences and facts that apply "
                        "across all projects."
                    ),
                },
                "category": {
                    "type": "string",
                    "enum": [
                        "preference",
                        "guardrail",
                        "mistake",
                        "personality",
                        "question",
                        "decision",
                        "pattern",
                        "context",
                        "session_summary",
                    ],
                    "description": (
                        "Memory category. When set, scope is automatically "
                        "routed (e.g. 'preference' -> global, 'decision' -> project)."
                    ),
                },
                "auto_categorize": {
                    "type": "boolean",
                    "description": (
                        "If true, automatically detect category from the text. "
                        "Also enables auto-importance scoring. Default: false."
                    ),
                },
                "pin": {
                    "type": "boolean",
                    "description": (
                        "Pin this memory. Pinned memories have maximum importance (1.0), "
                        "never decay, and are always prominent in recall. Default: false."
                    ),
                },
                "redact_secrets": {
                    "type": "boolean",
                    "description": (
                        "If true, automatically redact detected secrets (API keys, tokens, "
                        "passwords) before storing. Default: false."
                    ),
                },
                "on_conflict": {
                    "type": "string",
                    "enum": ["keep_both", "update", "skip"],
                    "description": (
                        "How to handle contradictions with existing memories. "
                        "'keep_both' (default) stores both and flags the contradiction. "
                        "'update' replaces the most similar existing memory. "
                        "'skip' discards the new memory if a contradiction is found."
                    ),
                },
            },
            "required": ["text"],
        },
    },
    {
        "name": "recall",
        "description": (
            "Recall relevant memories from MemoryMesh. Searches stored memories "
            "using semantic similarity (when embeddings are enabled) and keyword "
            "matching. Returns the most relevant memories ranked by relevance."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language query describing what to recall.",
                },
                "k": {
                    "type": "integer",
                    "description": "Maximum number of memories to return. Default: 5.",
                    "minimum": 1,
                    "maximum": 100,
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": (
                        "Limit search to a specific scope. Omit to search both "
                        "project and global memories (default)."
                    ),
                },
                "category": {
                    "type": "string",
                    "description": "Filter by memory category.",
                },
                "min_importance": {
                    "type": "number",
                    "description": "Only return memories with importance >= this value.",
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "forget",
        "description": (
            "Forget (permanently delete) a specific memory by its ID. "
            "Use this when information is outdated or incorrect. "
            "Searches both project and global stores."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "The unique identifier of the memory to delete.",
                },
            },
            "required": ["memory_id"],
        },
    },
    {
        "name": "forget_all",
        "description": (
            "Forget ALL stored memories in the specified scope. This is a "
            "destructive operation. Defaults to project scope only -- global "
            "memories are protected unless explicitly targeted."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": (
                        "Which scope to clear. Default: 'project'. Only memories "
                        "in the specified scope will be deleted."
                    ),
                },
            },
        },
    },
    {
        "name": "memory_stats",
        "description": (
            "Get statistics about stored memories: total count, oldest memory "
            "timestamp, and newest memory timestamp. Optionally filter by scope."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": (
                        "Limit stats to a specific scope. Omit for combined "
                        "stats across both project and global stores."
                    ),
                },
            },
        },
    },
    {
        "name": "session_start",
        "description": (
            "Retrieve structured context for the start of a new AI session. "
            "Returns user profile, guardrails, common mistakes, and project "
            "context to help the AI understand the user and avoid past errors. "
            "Call this at the beginning of every conversation."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_context": {
                    "type": "string",
                    "description": ("Brief description of what the user is working on."),
                },
            },
        },
    },
    {
        "name": "update_memory",
        "description": (
            "Update an existing memory's text, importance, scope, or metadata "
            "in place. Only the provided fields are changed; omitted fields "
            "keep their current values."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "The ID of the memory to update.",
                },
                "text": {
                    "type": "string",
                    "description": "New text content (replaces existing).",
                },
                "importance": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                    "description": "New importance score.",
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": "Move memory to this scope.",
                },
                "metadata": {
                    "type": "object",
                    "description": "New metadata (replaces existing).",
                    "additionalProperties": True,
                },
            },
            "required": ["memory_id"],
        },
    },
    {
        "name": "review_memories",
        "description": (
            "Audit memories for quality issues (scope mismatches, verbosity, "
            "staleness, duplicates). Returns issues with suggestions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": (
                        "Limit review to a specific scope. Omit to review all memories."
                    ),
                },
            },
        },
    },
    {
        "name": "status",
        "description": (
            "Get MemoryMesh health status: project store, global store, "
            "embedding provider, and version. Use this to diagnose configuration "
            "issues. If project store is not configured, shows what detection "
            "was attempted and how to fix it."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "configure_project",
        "description": (
            "Set the project root at runtime without restarting the server. "
            "Use this when automatic project detection failed and you know "
            "the correct project path. Creates the project database at "
            "<path>/.memorymesh/memories.db."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": (
                        "Absolute path to the project root directory. "
                        "The project database will be stored at <path>/.memorymesh/memories.db."
                    ),
                },
            },
            "required": ["path"],
        },
    },
]

# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------


class MemoryMeshMCPServer:
    """MCP server that wraps a MemoryMesh instance.

    Reads JSON-RPC messages from stdin and writes responses to stdout,
    following the Model Context Protocol specification.

    Args:
        mesh: An existing :class:`MemoryMesh` instance to use. If ``None``,
            one will be created from environment variable configuration.
    """

    def __init__(self, mesh: MemoryMesh | None = None) -> None:
        # Lazy initialization: if no mesh is provided, it will be created
        # in _handle_initialize when the client connects.  This avoids
        # the old double-init pattern (create → close → recreate).
        self._mesh: MemoryMesh | None = mesh
        self._initialized = False
        self._project_root: str | None = None
        self._detection_diagnostics: list[str] = []
        self._client_name: str = "unknown"

        # Cached handler dispatch dicts -- built once, reused on every call.
        # Maps method/tool names to attribute names for getattr-based dispatch,
        # so that test mocking (patch.object) still works correctly.
        self._method_handlers: dict[str, str] = {
            "initialize": "_handle_initialize",
            "initialized": "_handle_initialized",
            "ping": "_handle_ping",
            "tools/list": "_handle_tools_list",
            "tools/call": "_handle_tools_call",
            "prompts/list": "_handle_prompts_list",
            "prompts/get": "_handle_prompts_get",
            "notifications/initialized": "_handle_initialized",
        }
        self._tool_handlers: dict[str, str] = {
            "remember": "_tool_remember",
            "recall": "_tool_recall",
            "forget": "_tool_forget",
            "forget_all": "_tool_forget_all",
            "memory_stats": "_tool_memory_stats",
            "session_start": "_tool_session_start",
            "update_memory": "_tool_update_memory",
            "review_memories": "_tool_review_memories",
            "status": "_tool_status",
            "configure_project": "_tool_configure_project",
        }

        logger.info("MemoryMeshMCPServer created (lazy init, mesh=%r)", self._mesh)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @staticmethod
    def _create_mesh_from_env(
        project_root: str | None = None,
    ) -> MemoryMesh:
        """Build a MemoryMesh instance from environment variables.

        Reads ``MEMORYMESH_PATH``, ``MEMORYMESH_GLOBAL_PATH``,
        ``MEMORYMESH_EMBEDDING``, ``MEMORYMESH_OLLAMA_MODEL``, and
        ``OPENAI_API_KEY`` from the environment and forwards them to the
        MemoryMesh constructor.

        Args:
            project_root: If provided, the project database will be
                stored at ``<project_root>/.memorymesh/memories.db``.

        Returns:
            A configured :class:`MemoryMesh` instance.
        """
        path = os.environ.get("MEMORYMESH_PATH")
        if path is None and project_root is not None:
            path = os.path.join(project_root, ".memorymesh", "memories.db")

        global_path = os.environ.get("MEMORYMESH_GLOBAL_PATH")
        embedding = os.environ.get("MEMORYMESH_EMBEDDING", "none")

        kwargs: dict[str, Any] = {}

        ollama_model = os.environ.get("MEMORYMESH_OLLAMA_MODEL")
        if ollama_model:
            kwargs["ollama_model"] = ollama_model

        openai_key = os.environ.get("OPENAI_API_KEY")
        if openai_key:
            kwargs["openai_api_key"] = openai_key

        logger.info(
            "Creating MemoryMesh from env: path=%r, global_path=%r, embedding=%r, project_root=%r",
            path,
            global_path,
            embedding,
            project_root,
        )
        # Read optional relevance weights from environment.
        from .relevance import RelevanceWeights

        weights = RelevanceWeights.from_env()
        return MemoryMesh(
            path=path,
            global_path=global_path,
            embedding=embedding,
            relevance_weights=weights,
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Message loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Run the server's main read-dispatch-write loop.

        Reads newline-delimited JSON-RPC messages from stdin until EOF,
        dispatches each to the appropriate handler, and writes the
        response to stdout.  Notifications (no ``id``) do not produce
        a response.
        """
        logger.info("MCP server starting, reading from stdin...")

        for raw_line in sys.stdin:
            line = raw_line.strip()
            if len(line) > MAX_MESSAGE_SIZE:
                self._send_error(None, -32600, "Message too large.")
                continue
            if not line:
                continue

            logger.debug("Received: %s", line[:200])

            try:
                message = json.loads(line)
            except json.JSONDecodeError as exc:
                self._send_error(None, -32700, f"Parse error: {exc}")
                continue

            # JSON-RPC batch is not required by MCP but handle gracefully.
            if isinstance(message, list):
                if len(message) > MAX_BATCH_SIZE:
                    self._send_error(
                        None,
                        -32600,
                        f"Batch too large (max {MAX_BATCH_SIZE} messages).",
                    )
                    continue
                for msg in message:
                    self._handle_message(msg)
            else:
                self._handle_message(message)

        logger.info("stdin closed, shutting down.")
        if self._mesh is not None:
            self._mesh.close()

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def _handle_message(self, message: dict[str, Any]) -> None:
        """Route a single JSON-RPC message to the correct handler.

        Args:
            message: A parsed JSON-RPC request or notification.
        """
        if not isinstance(message, dict):
            self._send_error(None, -32600, "Invalid request: expected a JSON object.")
            return

        method = message.get("method")
        msg_id = message.get("id")
        params = message.get("params", {})

        if method is None:
            self._send_error(msg_id, -32600, "Invalid request: missing 'method'.")
            return

        logger.debug("Dispatching method=%r id=%r", method, msg_id)

        handler = self._get_handler(method)
        if handler is None:
            # Notifications we don't handle can be silently ignored.
            if msg_id is not None:
                self._send_error(msg_id, -32601, f"Method not found: {method}")
            return

        try:
            result = handler(params)
        except Exception:
            logger.exception("Error handling %s", method)
            self._send_error(msg_id, -32603, "Internal server error.")
            return

        # Only send a response for requests (those with an id).
        if msg_id is not None:
            self._send_result(msg_id, result)

    def _get_handler(self, method: str) -> Any:
        """Look up the handler function for a given MCP method.

        Args:
            method: The JSON-RPC method name.

        Returns:
            A callable ``(params) -> result``, or ``None`` if the method
            is not supported.
        """
        attr_name = self._method_handlers.get(method)
        if attr_name is None:
            return None
        return getattr(self, attr_name)

    # ------------------------------------------------------------------
    # Protocol handlers
    # ------------------------------------------------------------------

    def _handle_initialize(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``initialize`` request.

        Detects the project root from MCP ``roots`` and creates the
        MemoryMesh instance with the correct project database path.

        Args:
            params: Client-provided initialization parameters.

        Returns:
            A dict with ``protocolVersion``, ``capabilities``, and
            ``serverInfo``.
        """
        self._initialized = True

        client_name = params.get("clientInfo", {}).get("name", "unknown")
        self._client_name = client_name
        logger.info("Client initialized: %s", client_name)

        # Detect project root from MCP roots list.
        roots = params.get("roots")
        diagnostics: list[str] = []
        project_root = detect_project_root(roots, diagnostics=diagnostics)
        self._project_root = project_root
        self._detection_diagnostics = diagnostics

        # Close any pre-existing mesh (e.g. one passed to __init__ for testing).
        if self._mesh is not None:
            self._mesh.close()

        # Create mesh with project-aware paths (single init, no double-create).
        self._mesh = self._create_mesh_from_env(project_root=project_root)

        if project_root is None:
            logger.warning(
                "No project root detected. Only global memories available. "
                "Detection attempted:\n%s",
                "\n".join(f"  - {d}" for d in diagnostics),
            )
        else:
            logger.info(
                "Project root: %s  project_db: %s  global_db: %s",
                project_root,
                self._mesh.project_path,
                self._mesh.global_path,
            )

        return {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {
                "tools": {},
                "prompts": {},
            },
            "serverInfo": SERVER_INFO,
        }

    def _handle_initialized(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``initialized`` notification.

        This is a no-op acknowledgement sent by the client after the
        initialize handshake completes.

        Args:
            params: Notification parameters (unused).

        Returns:
            An empty dict (notifications do not produce visible responses).
        """
        logger.debug("Client sent 'initialized' notification.")
        return {}

    def _handle_ping(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``ping`` request.

        Args:
            params: Ping parameters (unused).

        Returns:
            An empty dict as acknowledgement.
        """
        return {}

    def _handle_tools_list(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``tools/list`` request.

        Args:
            params: List parameters (unused).

        Returns:
            A dict with a ``tools`` key containing all tool definitions.
        """
        return {"tools": TOOLS}

    def _handle_tools_call(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``tools/call`` request.

        Dispatches to the appropriate tool handler based on the tool name,
        validates arguments, and returns the result in MCP content format.

        Args:
            params: Must contain ``name`` (tool name) and optionally
                ``arguments`` (tool parameters).

        Returns:
            A dict with a ``content`` list containing the tool result.

        Raises:
            ValueError: If the tool name is unknown or arguments are invalid.
        """
        if not self._initialized:
            return self._tool_error("Server not initialized. Send 'initialize' request first.")
        if self._mesh is None:
            return self._tool_error("MemoryMesh not available. Initialize failed.")
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        logger.info("Tool call: %s (keys: %s)", tool_name, list(arguments.keys()))

        attr_name = self._tool_handlers.get(tool_name)  # type: ignore[arg-type]
        if attr_name is None:
            return self._tool_error(f"Unknown tool: {tool_name}")

        handler = getattr(self, attr_name)
        try:
            return handler(arguments)  # type: ignore[no-any-return]
        except Exception:
            logger.exception("Tool %s raised an exception", tool_name)
            return self._tool_error(f"Tool '{tool_name}' encountered an error.")

    # ------------------------------------------------------------------
    # Prompt handlers
    # ------------------------------------------------------------------

    def _handle_prompts_list(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``prompts/list`` request.

        Args:
            params: List parameters (unused).

        Returns:
            A dict with a ``prompts`` key containing all prompt definitions.
        """
        return {"prompts": PROMPTS}

    def _handle_prompts_get(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``prompts/get`` request.

        Resolves a prompt template by name and returns rendered messages.
        Currently supports the ``memory-context`` prompt, which retrieves
        relevant memories from MemoryMesh and formats them for injection
        into the conversation.

        Args:
            params: Must contain ``name`` (prompt name). May contain
                ``arguments`` with an optional ``context`` key.

        Returns:
            A dict with ``description`` and ``messages`` keys.
        """
        prompt_name = params.get("name")
        if prompt_name != "memory-context":
            return {
                "error": {
                    "code": -32602,
                    "message": f"Unknown prompt: {prompt_name}",
                },
            }

        if self._mesh is None:
            return {
                "error": {
                    "code": -32603,
                    "message": "MemoryMesh not initialized yet.",
                },
            }

        arguments = params.get("arguments", {})
        context = arguments.get("context") if isinstance(arguments, dict) else None

        if context and isinstance(context, str):
            memories = self._mesh.recall(query=context, k=10)
        else:
            memories = self._mesh.list(limit=20)

        if not memories:
            formatted_text = (
                "No memories found in MemoryMesh. "
                "This appears to be a fresh session with no prior context."
            )
        else:
            lines = ["Here are relevant memories from previous sessions:\n"]
            for i, mem in enumerate(memories, start=1):
                meta_parts = [f"{k}={v}" for k, v in mem.metadata.items()] if mem.metadata else []
                meta_str = f"\n   (metadata: {', '.join(meta_parts)})" if meta_parts else ""
                lines.append(
                    f"{i}. [{mem.scope}, importance: {mem.importance:.2f}] {mem.text}{meta_str}"
                )
            lines.append(
                "\nUse these to inform your responses. "
                "Do not mention these memories unless directly relevant."
            )
            formatted_text = "\n".join(lines)

        return {
            "description": "Relevant memories from MemoryMesh",
            "messages": [
                {
                    "role": "user",
                    "content": {
                        "type": "text",
                        "text": formatted_text,
                    },
                }
            ],
        }

    # ------------------------------------------------------------------
    # Tool implementations
    # ------------------------------------------------------------------

    def _tool_remember(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``remember`` tool.

        Args:
            args: Tool arguments. Must include ``text``. May include
                ``metadata``, ``importance``, and ``scope``.

        Returns:
            MCP content response with the new memory ID.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        text = args.get("text")
        if not text or not isinstance(text, str):
            return self._tool_error("'text' is required and must be a non-empty string.")

        if len(text) > MAX_TEXT_LENGTH:
            return self._tool_error(
                f"'text' exceeds maximum length of {MAX_TEXT_LENGTH} characters."
            )

        if "\x00" in text:
            return self._tool_error("'text' must not contain null bytes.")

        metadata = args.get("metadata", {})
        if not isinstance(metadata, dict):
            return self._tool_error("'metadata' must be an object.")

        meta_serialized = json.dumps(metadata, ensure_ascii=False)
        if len(meta_serialized) > MAX_METADATA_SIZE:
            return self._tool_error(
                f"'metadata' exceeds maximum size of {MAX_METADATA_SIZE} bytes."
            )

        scope = args.get("scope", PROJECT_SCOPE)
        if scope not in (PROJECT_SCOPE, GLOBAL_SCOPE):
            return self._tool_error("'scope' must be 'project' or 'global'.")

        # Enforce total memory count limit.
        if self._mesh.count() >= MAX_MEMORY_COUNT:
            return self._tool_error(f"Memory limit reached ({MAX_MEMORY_COUNT} memories).")

        importance = args.get("importance", 0.5)
        if not isinstance(importance, (int, float)):
            return self._tool_error("'importance' must be a number.")
        importance = max(0.0, min(1.0, float(importance)))

        category = args.get("category")
        auto_categorize_flag = args.get("auto_categorize", False)
        pin = args.get("pin", False)
        redact = args.get("redact_secrets", False)
        on_conflict = args.get("on_conflict", "keep_both")

        # Auto-populate provenance metadata.
        metadata.setdefault("source", "mcp")
        if self._client_name:
            metadata.setdefault("tool", self._client_name)

        try:
            memory_id = self._mesh.remember(
                text=text,
                metadata=metadata,
                importance=importance,
                scope=scope,
                category=category,
                auto_categorize=auto_categorize_flag,
                pin=pin,
                redact=redact,
                on_conflict=on_conflict,
            )
        except RuntimeError as exc:
            return self._tool_error(str(exc))

        result: dict[str, Any] = {
            "memory_id": memory_id,
            "scope": scope,
            "message": f"Remembered: {text[:80]}{'...' if len(text) > 80 else ''}",
        }

        # Check if contradiction was flagged
        if memory_id:
            mem = self._mesh.get(memory_id)
            if mem and mem.metadata.get("contradicts"):
                contradiction_count = len(mem.metadata["contradicts"])
                result["contradictions"] = mem.metadata["contradicts"]
                result["message"] += (
                    f" (contradicts {contradiction_count} existing "
                    f"{'memory' if contradiction_count == 1 else 'memories'})"
                )
        elif on_conflict == "skip":
            result["message"] = "Memory skipped due to contradiction (on_conflict=skip)"

        return self._tool_success(json.dumps(result, indent=2))

    def _tool_recall(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``recall`` tool.

        Args:
            args: Tool arguments. Must include ``query``. May include
                ``k`` and ``scope``.

        Returns:
            MCP content response with a list of matching memories.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        query = args.get("query")
        if not query or not isinstance(query, str):
            return self._tool_error("'query' is required and must be a non-empty string.")

        k = args.get("k", 5)
        if not isinstance(k, int) or k < 1:
            return self._tool_error("'k' must be a positive integer.")
        k = min(k, 100)

        scope = args.get("scope")  # None means search both
        if scope is not None and scope not in (PROJECT_SCOPE, GLOBAL_SCOPE):
            return self._tool_error("'scope' must be 'project', 'global', or omitted.")

        category = args.get("category")
        min_importance = args.get("min_importance")
        if min_importance is not None:
            if not isinstance(min_importance, (int, float)):
                return self._tool_error("'min_importance' must be a number.")
            min_importance = max(0.0, min(1.0, float(min_importance)))

        memories = self._mesh.recall(
            query=query,
            k=k,
            scope=scope,
            category=category,
            min_importance=min_importance,
        )

        results = []
        for mem in memories:
            results.append(
                {
                    "id": mem.id,
                    "text": mem.text,
                    "metadata": mem.metadata,
                    "importance": round(mem.importance, 4),
                    "created_at": mem.created_at.isoformat(),
                    "access_count": mem.access_count,
                    "scope": mem.scope,
                }
            )

        output = {
            "query": query,
            "count": len(results),
            "memories": results,
        }
        return self._tool_success(json.dumps(output, indent=2))

    def _tool_forget(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``forget`` tool.

        Args:
            args: Tool arguments. Must include ``memory_id``.

        Returns:
            MCP content response indicating success or failure.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        memory_id = args.get("memory_id")
        if not memory_id or not isinstance(memory_id, str):
            return self._tool_error("'memory_id' is required and must be a string.")

        deleted = self._mesh.forget(memory_id)
        result = {
            "memory_id": memory_id,
            "deleted": deleted,
            "message": (
                f"Memory {memory_id} deleted." if deleted else f"Memory {memory_id} not found."
            ),
        }
        return self._tool_success(json.dumps(result, indent=2))

    def _tool_forget_all(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``forget_all`` tool.

        Args:
            args: Tool arguments. May include ``scope``.

        Returns:
            MCP content response with the count of deleted memories.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        scope = args.get("scope", PROJECT_SCOPE)
        if scope not in (PROJECT_SCOPE, GLOBAL_SCOPE):
            return self._tool_error("'scope' must be 'project' or 'global'.")

        count = self._mesh.forget_all(scope=scope)
        result = {
            "deleted_count": count,
            "scope": scope,
            "message": f"Deleted all {count} {scope} memories.",
        }
        return self._tool_success(json.dumps(result, indent=2))

    def _tool_memory_stats(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``memory_stats`` tool.

        Args:
            args: Tool arguments. May include ``scope``.

        Returns:
            MCP content response with memory statistics.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        scope = args.get("scope")  # None means combined
        if scope is not None and scope not in (PROJECT_SCOPE, GLOBAL_SCOPE):
            return self._tool_error("'scope' must be 'project', 'global', or omitted.")

        total = self._mesh.count(scope=scope)
        oldest_str, newest_str = self._mesh.get_time_range(scope=scope)

        result: dict[str, Any] = {
            "total_memories": total,
            "oldest_memory": oldest_str,
            "newest_memory": newest_str,
        }
        if scope is not None:
            result["scope"] = scope
        if self._project_root is not None:
            result["project_root"] = self._project_root
        return self._tool_success(json.dumps(result, indent=2))

    def _tool_session_start(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``session_start`` tool.

        Args:
            args: Tool arguments. May include ``project_context``.

        Returns:
            MCP content response with structured session context
            including store health information.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        project_context = args.get("project_context")
        if project_context is not None and not isinstance(project_context, str):
            return self._tool_error("'project_context' must be a string.")

        context = self._mesh.session_start(project_context=project_context)

        # Inject store health so the agent knows immediately if something
        # is misconfigured.
        store_health: dict[str, Any] = {
            "global_store": "ok",
        }
        if self._mesh.project_path:
            store_health["project_store"] = "ok"
            store_health["project_root"] = self._project_root
        else:
            store_health["project_store"] = "not_configured"
            store_health["warning"] = (
                "No project root detected. Project-scoped memories are unavailable. "
                "Use the 'configure_project' tool or set MEMORYMESH_PROJECT_ROOT."
            )
        context["store_health"] = store_health

        return self._tool_success(json.dumps(context, indent=2))

    def _tool_update_memory(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``update_memory`` tool.

        Args:
            args: Tool arguments. Must include ``memory_id``. May include
                ``text``, ``importance``, ``scope``, and ``metadata``.

        Returns:
            MCP content response with the updated memory info, or an
            error if the memory was not found.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        memory_id = args.get("memory_id")
        if not memory_id or not isinstance(memory_id, str):
            return self._tool_error("'memory_id' is required and must be a non-empty string.")

        text = args.get("text")
        if text is not None:
            if not isinstance(text, str) or not text:
                return self._tool_error("'text' must be a non-empty string.")
            if len(text) > MAX_TEXT_LENGTH:
                return self._tool_error(
                    f"'text' exceeds maximum length of {MAX_TEXT_LENGTH} characters."
                )

        importance = args.get("importance")
        if importance is not None:
            if not isinstance(importance, (int, float)):
                return self._tool_error("'importance' must be a number.")
            importance = max(0.0, min(1.0, float(importance)))

        scope = args.get("scope")
        if scope is not None and scope not in (PROJECT_SCOPE, GLOBAL_SCOPE):
            return self._tool_error("'scope' must be 'project' or 'global'.")

        metadata = args.get("metadata")
        if metadata is not None:
            if not isinstance(metadata, dict):
                return self._tool_error("'metadata' must be an object.")
            meta_serialized = json.dumps(metadata, ensure_ascii=False)
            if len(meta_serialized) > MAX_METADATA_SIZE:
                return self._tool_error(
                    f"'metadata' exceeds maximum size of {MAX_METADATA_SIZE} bytes."
                )

        try:
            updated = self._mesh.update(
                memory_id=memory_id,
                text=text,
                importance=importance,
                metadata=metadata,
                scope=scope,
            )
        except RuntimeError as exc:
            return self._tool_error(str(exc))

        if updated is None:
            return self._tool_error(f"Memory {memory_id} not found.")

        result = {
            "memory_id": updated.id,
            "text": updated.text[:80] + ("..." if len(updated.text) > 80 else ""),
            "importance": round(updated.importance, 4),
            "scope": updated.scope,
            "message": f"Memory {memory_id} updated successfully.",
        }
        return self._tool_success(json.dumps(result, indent=2))

    def _tool_review_memories(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``review_memories`` tool.

        Args:
            args: Tool arguments. May include ``scope``.

        Returns:
            MCP content response with review issues and quality score.
        """
        if self._mesh is None:
            return self._tool_error("MemoryMesh not initialized. Call initialize first.")
        from .review import review_memories

        scope = args.get("scope")
        if scope is not None and scope not in (PROJECT_SCOPE, GLOBAL_SCOPE):
            return self._tool_error("'scope' must be 'project', 'global', or omitted.")

        review_result = review_memories(self._mesh, scope=scope)

        issues_list = []
        for issue in review_result.issues:
            issues_list.append(
                {
                    "memory_id": issue.memory_id,
                    "issue_type": issue.issue_type,
                    "severity": issue.severity,
                    "description": issue.description,
                    "suggestion": issue.suggestion,
                    "auto_fixable": issue.auto_fixable,
                }
            )

        result: dict[str, Any] = {
            "quality_score": review_result.quality_score,
            "total_reviewed": review_result.total_reviewed,
            "scanned_scope": review_result.scanned_scope,
            "issue_count": len(issues_list),
            "issues": issues_list,
        }
        return self._tool_success(json.dumps(result, indent=2))

    def _tool_status(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``status`` tool.

        Args:
            args: Tool arguments (none required).

        Returns:
            MCP content response with health diagnostics.
        """
        embedding_name = os.environ.get("MEMORYMESH_EMBEDDING", "none")

        project_info: dict[str, Any]
        if self._mesh and self._mesh.project_path:
            project_info = {
                "status": "ok",
                "path": self._mesh.project_path,
                "count": self._mesh.count(scope=PROJECT_SCOPE),
            }
        else:
            project_info = {
                "status": "not_configured",
                "reason": "No project root detected",
                "detection_attempted": self._detection_diagnostics,
                "fix_options": [
                    "Use the 'configure_project' tool with path='/your/project/root'",
                    "Set MEMORYMESH_PROJECT_ROOT=/path/to/project in MCP server env config",
                    "Set MEMORYMESH_PATH=/path/to/project/.memorymesh/memories.db in env config",
                    "Launch your AI tool from within a project directory",
                ],
            }

        global_info: dict[str, Any] = {
            "status": "ok",
            "path": self._mesh.global_path if self._mesh else "unknown",
            "count": self._mesh.count(scope=GLOBAL_SCOPE) if self._mesh else 0,
        }

        result: dict[str, Any] = {
            "version": SERVER_INFO["version"],
            "project_root": self._project_root,
            "project_store": project_info,
            "global_store": global_info,
            "embedding": {
                "provider": embedding_name,
            },
        }
        return self._tool_success(json.dumps(result, indent=2))

    def _tool_configure_project(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute the ``configure_project`` tool.

        Dynamically sets the project root and creates the project database
        without requiring a server restart.

        Args:
            args: Tool arguments. Must include ``path``.

        Returns:
            MCP content response confirming the new configuration.
        """
        path = args.get("path")
        if not path or not isinstance(path, str):
            return self._tool_error("'path' is required and must be a non-empty string.")

        path = os.path.realpath(os.path.expanduser(path))
        if not os.path.isdir(path):
            return self._tool_error(f"Directory does not exist: {path}")

        # Update project root and recreate the mesh.
        self._project_root = path
        if self._mesh is not None:
            self._mesh.close()
        self._mesh = self._create_mesh_from_env(project_root=path)
        self._detection_diagnostics = [f"Manually configured via configure_project: {path}"]

        logger.info(
            "Project configured at runtime: root=%s  db=%s",
            path,
            self._mesh.project_path,
        )

        result = {
            "project_root": path,
            "project_db": self._mesh.project_path,
            "global_db": self._mesh.global_path,
            "message": f"Project configured successfully. Database at {self._mesh.project_path}",
        }
        return self._tool_success(json.dumps(result, indent=2))

    # ------------------------------------------------------------------
    # Response helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _tool_success(text: str) -> dict[str, Any]:
        """Build a successful MCP tool result.

        Args:
            text: The text content of the result.

        Returns:
            MCP-formatted content response.
        """
        return {
            "content": [
                {
                    "type": "text",
                    "text": text,
                }
            ],
        }

    @staticmethod
    def _tool_error(message: str) -> dict[str, Any]:
        """Build an error MCP tool result.

        Args:
            message: Human-readable error description.

        Returns:
            MCP-formatted error content response with ``isError`` flag.
        """
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({"error": message}),
                }
            ],
            "isError": True,
        }

    def _send_result(self, msg_id: Any, result: Any) -> None:
        """Write a JSON-RPC success response to stdout.

        Args:
            msg_id: The request ID to echo back.
            result: The result payload.
        """
        response = {
            "jsonrpc": JSONRPC_VERSION,
            "id": msg_id,
            "result": result,
        }
        self._write_message(response)

    def _send_error(
        self,
        msg_id: Any,
        code: int,
        message: str,
        data: Any = None,
    ) -> None:
        """Write a JSON-RPC error response to stdout.

        Args:
            msg_id: The request ID to echo back (may be ``None``).
            code: Numeric error code per JSON-RPC spec.
            message: Human-readable error description.
            data: Optional additional error data.
        """
        error_obj: dict[str, Any] = {
            "code": code,
            "message": message,
        }
        if data is not None:
            error_obj["data"] = data

        response: dict[str, Any] = {
            "jsonrpc": JSONRPC_VERSION,
            "id": msg_id,
            "error": error_obj,
        }
        self._write_message(response)

    @staticmethod
    def _write_message(message: dict[str, Any]) -> None:
        """Serialize and write a JSON-RPC message to stdout.

        Each message is written as a single line of JSON followed by a
        newline, which is the standard framing for MCP over stdio.

        Args:
            message: The JSON-RPC message dict to send.
        """
        line = json.dumps(message, ensure_ascii=False)
        sys.stdout.write(line + "\n")
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the MemoryMesh MCP server.

    This is the entry point used by the ``memorymesh-mcp`` console script
    and by ``python -m memorymesh.mcp_server``.
    """
    logging.basicConfig(
        level=logging.DEBUG if os.environ.get("MEMORYMESH_DEBUG") else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )
    logger.info("Starting MemoryMesh MCP server...")
    logger.info(
        "Config: MEMORYMESH_PATH=%r  MEMORYMESH_EMBEDDING=%r",
        os.environ.get("MEMORYMESH_PATH", "(default)"),
        os.environ.get("MEMORYMESH_EMBEDDING", "none"),
    )

    try:
        server = MemoryMeshMCPServer()
        server.run()
    except KeyboardInterrupt:
        logger.info("Server interrupted by user.")
        sys.exit(0)
    except Exception:
        logger.exception("Fatal error in MCP server.")
        sys.exit(1)


if __name__ == "__main__":
    main()
