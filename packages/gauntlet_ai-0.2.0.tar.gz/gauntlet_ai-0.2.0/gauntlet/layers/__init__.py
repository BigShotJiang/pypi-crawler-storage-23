"""Detection layers for Gauntlet."""
