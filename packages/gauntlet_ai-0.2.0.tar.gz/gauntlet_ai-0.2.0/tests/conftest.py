"""Pytest configuration and shared fixtures."""
