"""Gauntlet evaluation suite — adversarial dataset and benchmark."""
