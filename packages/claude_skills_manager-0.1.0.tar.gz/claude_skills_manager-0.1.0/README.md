# Claude Skills Manager (`csm`)

A CLI tool to manage [Claude Code](https://docs.anthropic.com/en/docs/claude-code) skills in `~/.claude/skills/`.

Skills are directories containing a `SKILL.md` file with YAML frontmatter. `csm` lets you list, enable/disable, create, link, and configure them without manually editing files.

## Installation

```bash
# With uv (recommended)
uv tool install claude-skills-manager

# With pipx
pipx install claude-skills-manager
```

The `csm` command will be available globally after installation.

## Usage

### List all skills

```bash
csm list
```

Shows a table with each skill's name, enabled status, description, and invocation settings.

### Show skill details

```bash
csm show <name>
```

Prints the full frontmatter and markdown content of a skill.

### Enable / Disable

```bash
csm disable <name>   # renames SKILL.md → SKILL.md.disabled
csm enable <name>    # renames SKILL.md.disabled → SKILL.md
```

### Create a new skill

```bash
csm create my-skill --desc "Does something useful"
```

Scaffolds a new skill directory with a template `SKILL.md` in `~/.claude/skills/`.

### Edit a skill

```bash
csm edit <name>
```

Opens the skill's `SKILL.md` in `$EDITOR` (defaults to `vi`).

### Link / Unlink external skills

```bash
# Symlink a skill from another directory (uses relative paths, compatible with GNU Stow)
csm link /path/to/my-skill

# Symlink with a custom name
csm link /path/to/my-skill --name custom-name

# Remove a symlink (does not delete the original directory)
csm unlink <name>
```

### Configure frontmatter

```bash
# Set a key
csm config <name> --key disable-model-invocation --value true

# Delete a key
csm config <name> --key some-key --delete
```

### Shell completion

```bash
csm --install-completion
```

Enables tab completion for commands and skill names in your shell.

## How it works

- Skills are discovered by scanning `~/.claude/skills/` for directories containing `SKILL.md` or `SKILL.md.disabled`
- Enable/disable toggles the file extension
- Frontmatter is parsed and written with [python-frontmatter](https://github.com/eyeseast/python-frontmatter) for safe YAML round-tripping
- Symlinked skill directories are fully supported

## Development

```bash
git clone https://github.com/danielmeint/skills-manager.git
cd claude-skills-manager
uv sync
uv run pytest
```

## License

MIT
