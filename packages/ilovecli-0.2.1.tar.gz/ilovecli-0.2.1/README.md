


# 🚀 ilovecli

> Compress smarter. From your terminal.


`ilovecli` is a fast, cross-platform command-line tool to compress **Images, PDFs, and Videos** directly from your terminal.

It supports smart auto-detection, target-size optimization, parallel processing, and Docker deployment.

---

## ✨ Features


- 🖼 Compress images (JPG, PNG, WEBP)
- 📄 Compress PDFs (Ghostscript powered)
- 🎬 Compress videos (FFmpeg powered)
- 🎯 Target-size compression (Images & PDFs)
- ⚡ Parallel folder image compression
- 📊 Original vs compressed size reporting
- 🐳 Docker support
- 📦 PyPI-ready package
- 🧠 Automatic file-type detection

---

## 📦 Installation

### Install from PyPI

```bash
pip install ilovecli
````

---

### Install from Source

```bash
git clone https://github.com/Dhabaldeep/ilovecli.git
cd ilovecli
pip install .
```

---

## 🔧 System Requirements

Make sure the following are installed:

* Python 3.8+
* FFmpeg (for video compression)
* Ghostscript (for PDF compression)

Verify installation:

```bash
ffmpeg -version
gs --version
```

---

## 🚀 Usage

### 🔹 Compress Any Supported File

```bash
ilovecli compress file.jpg
ilovecli compress document.pdf
ilovecli compress video.mp4
```

Automatic file-type detection included.

---

### 🎯 Compress to Target Size

#### Image

```bash
ilovecli target image.jpg 300
```

Compresses image to approximately **300 KB** while maintaining best possible quality.

#### PDF

```bash
ilovecli target document.pdf 500
```

Optimizes DPI dynamically to keep the file under **500 KB**.

---

### 📄 Control PDF Compression Level

Available levels:

* `screen` (maximum compression)
* `ebook` (default)
* `printer`
* `prepress` (highest quality)

Example:

```bash
ilovecli compress file.pdf --pdf-quality screen
```

---

### 🎬 Control Video Compression (CRF)

Lower CRF → Better quality
Higher CRF → Smaller file

```bash
ilovecli compress video.mp4 --crf 32
```

Recommended range: **18–35**

---

### 📁 Compress All Images in Folder

```bash
ilovecli folder ./images
```

Uses parallel processing for faster execution.

---

### 🔎 Show Version

```bash
ilovecli version
```

---

## 🐳 Docker Support

### Build Docker Image

```bash
docker build -t ilovecli .
```

---

### Run Inside Container

```bash
docker run --rm -v $(pwd):/data ilovecli compress /data/file.pdf --pdf-quality screen
```

No need to manually install Python, FFmpeg, or Ghostscript.

---

## 🏗 Project Structure

```
ilovecli/
│
├── cli.py
├── image_tools.py
├── pdf_tools.py
├── video_tools.py
├── utils.py
├── logger.py
└── __init__.py
```

---

## 🛠 Tech Stack

* Python
* Typer (CLI framework)
* Pillow (Image processing)
* FFmpeg (Video compression)
* Ghostscript (PDF compression)
* Rich (Styled console output)
* TQDM (Progress bars)
* Multiprocessing

---

## 📊 Example Output

```
Original: 10.4 MB
Compressed: 2.3 MB
Reduced: 77.8%
```

---

## 💼 Resume Description

> Developed a cross-platform CLI-based media compression toolkit using Python, Typer, multiprocessing, FFmpeg, and Ghostscript. Implemented dynamic target-size optimization via binary search, parallel processing, structured logging, and Docker containerization. Packaged for PyPI and Docker deployment.

---

## 📄 License

MIT License

---

## 🤝 Contributing

Contributions are welcome!

1. Fork the repository
2. Create your feature branch
3. Commit changes
4. Open a pull request

---

## ⭐ Support

If you find this project useful:

* ⭐ Star the repository
* 🐛 Report issues
* 🚀 Share with others

```
