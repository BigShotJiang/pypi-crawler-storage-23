import typer
from pathlib import Path
from rich.console import Console
from rich.progress import Spinner
from rich.panel import Panel
from ilovecli import (
    compress_image,
    compress_folder_parallel,
    compress_pdf,
    compress_video,
    convert_image,
    compress_to_target_size,
    compress_pdf_to_target_size,
    __version__,
)
from ilovecli.logger import logger

console = Console()
app = typer.Typer(help="🚀 ilovecli - Image, PDF & Video Compressor", add_completion=False)

SUPPORTED_IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp"]
SUPPORTED_VIDEO_EXTS = [".mp4", ".mkv", ".mov"]
SUPPORTED_PDF_EXTS = [".pdf"]

def show_banner():
    banner = r"""
 _ _                 _      _ _
(_) | _____   _____ | | ___| (_)
| | |/ _ \ \ / / _ \| |/ _ \ | |
| | | (_) \ V / (_) | |  __/ | |
|_|_|\___/ \_/ \___/|_|\___|_|_|
    """
    console.print(banner, style="bold cyan")

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", help="Show version", is_eager=True),
    author: bool = typer.Option(False, "--author", help="Show author info", is_eager=True),
    info: bool = typer.Option(False, "--info", help="Show project info", is_eager=True),
):
    if version:
        console.print(f"[bold cyan]ilovecli[/bold cyan] v{__version__}")
        raise typer.Exit()
    if author:
        console.print("👨‍💻 Author: Deep Dhabal")
        console.print("🎓 Computer Science Student | Cloud & Dev Enthusiast")
        raise typer.Exit()
    if info:
        show_banner()
        console.print("[bold cyan]ilovecli[/bold cyan] - Compress images, PDFs, and videos")
        console.print(f"📦 Version: {__version__}")
        console.print("⚡ Built with Typer & Rich")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        show_banner()
        console.print("Use [bold]ilovecli --help[/bold] to see available commands.")

@app.command()
def compress(
    file: Path,
    quality: int = typer.Option(60, help="Image quality (10-95)"),
    pdf_quality: str = typer.Option("ebook", help="PDF quality: screen, ebook, printer, prepress", case_sensitive=False, show_choices=True),
    crf: int = typer.Option(28, help="Video CRF (18-35)")
):
    """Auto-detect and compress file"""
    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    ext = file.suffix.lower()
    try:
        logger.info(f"Starting compression for {file.name}")
        with console.status(f"Compressing {file.name}...", spinner="dots"):
            if ext in SUPPORTED_IMAGE_EXTS:
                compress_image(str(file), quality)
            elif ext in SUPPORTED_PDF_EXTS:
                compress_pdf(str(file), pdf_quality)
            elif ext in SUPPORTED_VIDEO_EXTS:
                compress_video(str(file), crf)
            else:
                console.print("❌ Unsupported file type", style="red")
                raise typer.Exit()
        console.print(f"✅ Compression completed: {file.name}", style="green")
        logger.info("Compression completed successfully")
    except Exception as e:
        logger.exception("Error during compression")
        console.print(f"❌ Error: {e}", style="red")

@app.command()
def folder(
    path: Path,
    quality: int = typer.Option(60, help="Image quality (10-95)"),
    overwrite: bool = typer.Option(False, help="Overwrite existing compressed files")
):
    """Compress all images inside folder using parallel processing"""
    if not path.exists():
        console.print("❌ Folder not found", style="red")
        raise typer.Exit()

    logger.info(f"Starting folder compression: {path}")
    with console.status(f"Compressing folder {path}...", spinner="dots"):
        compress_folder_parallel(str(path), quality, overwrite=overwrite)
    console.print(f"✅ Folder compression completed: {path}", style="green")

@app.command()
def convert(input: Path, output: Path):
    """Convert image format"""
    logger.info(f"Converting {input.name} to {output.name}")
    with console.status(f"Converting {input.name}...", spinner="dots"):
        convert_image(str(input), str(output))
    console.print(f"✅ Conversion completed: {output.name}", style="green")

@app.command()
def target(
    file: Path,
    size_kb: int = typer.Argument(..., help="Target size in KB"),
    pdf_quality: str = typer.Option(
        "screen",
        "--quality",
        help="PDF compression quality: screen, ebook, printer, prepress",
        case_sensitive=False,
        show_choices=True,
    )
):
    """
    Compress file to target size in KB
    Works for images and PDFs
    Example:
        ilovecli target image.jpg 300
        ilovecli target file.pdf 500 --quality screen
    """
    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    ext = file.suffix.lower()
    logger.info(f"Starting target compression for {file.name} to {size_kb} KB")

    try:
        with console.status(f"Compressing {file.name} to {size_kb} KB...", spinner="dots"):
            if ext in [".jpg", ".jpeg", ".png", ".webp"]:
                compress_to_target_size(str(file), size_kb)
            elif ext == ".pdf":
                compress_pdf_to_target_size(str(file), size_kb, quality=pdf_quality)
            else:
                console.print("❌ Target compression only supported for images and PDFs", style="red")
                raise typer.Exit()

        final_size_kb = round(file.stat().st_size / 1024, 2)
        console.print(f"✅ Target compression completed: {file.name}", style="green")
        logger.info("Target compression completed successfully")
    except Exception:
        logger.exception("Error during target compression")
        console.print("❌ Target compression failed", style="red")

@app.command()
def about():
    """Show author and project information"""
    content = (
        "[bold cyan]ilovecli[/bold cyan]\n\n"
        "A powerful CLI tool to compress images, PDFs, and videos.\n\n"
        "👨‍💻 Author: Deep Dhabal\n"
        "🎓 Computer Science Student | Cloud & Dev Enthusiast\n"
        f"📦 Version: {__version__}"
    )
    console.print(Panel(content, title="About", expand=False))

if __name__ == "__main__":
    app()