# utils.py
def print_size_report(original, new):
    original_mb = original / (1024 * 1024)
    new_mb = new / (1024 * 1024)

    reduction = ((original - new) / original) * 100

    print(f"Original: {round(original_mb,2)} MB")
    print(f"Compressed: {round(new_mb,2)} MB")
    print(f"Reduced: {round(reduction,2)}%")