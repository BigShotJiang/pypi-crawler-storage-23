from .image_tools import (
    compress_image,
    compress_folder_parallel,
    convert_image,
    compress_to_target_size,
)

from .pdf_tools import (
    compress_pdf,
    compress_pdf_to_target_size,
)

from .video_tools import compress_video

__all__ = [
    "compress_image",
    "compress_folder_parallel",
    "convert_image",
    "compress_to_target_size",
    "compress_pdf",
    "compress_pdf_to_target_size",
    "compress_video",
]

__version__ = "0.2.1"