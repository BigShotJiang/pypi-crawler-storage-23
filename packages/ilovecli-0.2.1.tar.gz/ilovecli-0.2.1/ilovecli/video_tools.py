# video_tools.py
import subprocess
from rich.console import Console
from tqdm import tqdm
import os

console = Console()

def compress_video(input_path: str, crf: int = 28):
    output = "compressed_" + os.path.basename(input_path)

    try:
        subprocess.run([
            "ffmpeg",
            "-i", input_path,
            "-vcodec", "libx264",
            "-crf", str(crf),
            "-preset", "slow",          # better compression
            "-movflags", "+faststart",  # better for web streaming
            "-y",
            output
        ], check=True)

        console.print(f"✅ Saved as {output}", style="green")

    except subprocess.CalledProcessError:
        console.print("❌ FFmpeg failed", style="red")