from pathlib import Path
from multiprocessing import Pool, cpu_count
from PIL import Image
import logging
from typing import Tuple, List
from tqdm import tqdm
from .logger import logger

SUPPORTED_EXTENSIONS = ["*.jpg", "*.jpeg", "*.png", "*.webp"]

def compress_image(input_path: str, quality: int = 60, output_path: str = None):
    """Compress a single image and save."""
    try:
        input_path = Path(input_path)
        output_path = Path(output_path) if output_path else input_path.parent / f"compressed_{input_path.name}"

        original_size = input_path.stat().st_size

        with Image.open(input_path) as img:
            fmt = img.format.upper()
            if fmt in ["JPEG", "JPG"]:
                img.save(output_path, quality=quality, optimize=True)
            elif fmt == "PNG":
                compress_level = max(0, min(9, int((100 - quality) / 10)))
                img.save(output_path, optimize=True, compress_level=compress_level)
            elif fmt == "WEBP":
                img.save(output_path, format="WEBP", quality=quality, optimize=True)
            else:
                img.save(output_path)

        new_size = output_path.stat().st_size
        reduction = ((original_size - new_size) / original_size) * 100
        logger.info(f"Compressed {input_path.name} -> {output_path.name} | Reduced {reduction:.2f}%")
        return True

    except Exception:
        logger.exception(f"Failed to compress {input_path.name}")
        return False

def _compress_single(args: Tuple[str, int, str]):
    return compress_image(*args)

def compress_folder_parallel(folder_path: str, quality: int = 60, overwrite: bool = False):
    """Compress all supported images in a folder using multiprocessing."""
    folder = Path(folder_path)
    if not folder.is_dir():
        logger.error(f"Folder not found: {folder}")
        return

    files: List[Path] = []
    for ext in SUPPORTED_EXTENSIONS:
        files.extend(folder.glob(ext))
        files.extend(folder.glob(ext.upper()))

    if not files:
        logger.warning("No supported images found in folder")
        return

    output_folder = folder / "compressed_output"
    output_folder.mkdir(exist_ok=True)

    # Skip already compressed files if overwrite is False
    tasks = []
    for file in files:
        output_path = output_folder / f"compressed_{file.name}"
        if not overwrite and output_path.exists():
            logger.info(f"Skipping {file.name} (already compressed)")
            continue
        tasks.append((str(file), quality, str(output_folder)))

    if not tasks:
        logger.info("Nothing to compress after checking existing files")
        return

    workers = min(cpu_count(), len(tasks))
    logger.info(f"Using {workers} CPU cores for compressing {len(tasks)} images")

    with Pool(workers) as pool:
        for _ in tqdm(pool.imap_unordered(_compress_single, tasks), total=len(tasks)):
            pass

    logger.info("Parallel folder compression completed")

def convert_image(input_path: str, output_path: str):
    """Convert image format."""
    try:
        with Image.open(input_path) as img:
            img.save(output_path)
        logger.info(f"Image converted: {output_path}")
    except Exception:
        logger.exception(f"Failed converting {input_path}")

def compress_to_target_size(input_path: str, target_kb: int):
    """Compress image to fit within target size using binary search over quality."""
    try:
        input_path = Path(input_path)
        output = input_path.parent / f"target_{input_path.name}"
        target_bytes = target_kb * 1024

        with Image.open(input_path) as img:
            img = img.convert("RGB")

            low, high = 5, 95
            best_quality = None

            while low <= high:
                mid = (low + high) // 2
                img.save(output, format="JPEG", quality=mid, optimize=True)
                size = output.stat().st_size

                if size > target_bytes:
                    high = mid - 1
                else:
                    best_quality = mid
                    low = mid + 1

            if best_quality is None:
                logger.error("Could not compress to desired size")
                return

            img.save(output, format="JPEG", quality=best_quality, optimize=True)
            final_size_kb = output.stat().st_size / 1024
            logger.info(f"Target compression complete: {output.name} | Final size: {final_size_kb:.2f} KB | Quality: {best_quality}")

    except Exception:
        logger.exception(f"Failed target compression for {input_path.name}")