import os
from setuptools import setup, Extension

# Nếu có Cython → build từ .py, không có → build từ .c
try:
    from Cython.Build import cythonize
    USE_CYTHON = True
except ImportError:
    USE_CYTHON = False

if USE_CYTHON:
    ext_modules = cythonize(
        [Extension("altare_captcha", ["altare_captcha.py"])],
        compiler_directives={'language_level': "3"},
    )
else:
    # Linux users: build từ file .c đã generate sẵn
    ext_modules = [Extension("altare_captcha", ["altare_captcha.c"])]


# Custom build: xóa .py source khỏi wheel
from setuptools.command.build_ext import build_ext

class NoPySource(build_ext):
    def run(self):
        super().run()
        for root, dirs, files in os.walk(self.build_lib):
            for f in files:
                if f.endswith('.py') and f != '__init__.py':
                    os.remove(os.path.join(root, f))

setup(
    ext_modules=ext_modules,
    cmdclass={'build_ext': NoPySource},
    py_modules=[],
    packages=[],
)
