# altare-captcha

Cap.js PoW CAPTCHA solver.

## Install

```bash
pip install the-fuKing-altare-captcha
```

## Usage

```python
from the_fuKing_altare_captcha import CapSolver

solver = CapSolver("https://api.altare.sh/cap/bb402c6b75/")
cap_token = solver.solve()
```
