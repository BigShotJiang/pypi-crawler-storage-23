# BendBandBot

Проста бібліотека для створення Telegram ботів, спеціально розроблена для навчання школярів програмуванню.

## Особливості

- ✅ **Просто** - без декораторів, async/await, складних конструкцій
- ✅ **Зрозуміло** - коментарі українською, зрозумілі назви методів
- ✅ **Для початківців** - підходить для учнів 6-9 класів
- ✅ **Два режими** - прості команди з текстом або функції для складнішої логіки

## Встановлення

```bash
pip install bendbandbot
```

## Швидкий старт

```python
from simple_bot import SimpleBot

# Створюємо бота
bot = SimpleBot("ВАШ_ТОКЕН_ВІД_BOTFATHER")

# Додаємо команди (простий спосіб)
bot.on_command("start", "Привіт! 👋")
bot.on_command("help", "Я простий бот!")

# Запускаємо
bot.start()
```

## Приклад з функціями

```python
from simple_bot import SimpleBot

bot = SimpleBot("ВАШ_ТОКЕН")

def greeting(message):
    name = bot.get_name(message)
    bot.send(message, f"Привіт, {name}! 😊")

bot.on_command("start", greeting)
bot.start()
```

## Документація

Повний курс з 14 уроків: [bendband.net/bot-course](https://bendband.net/bot-course)

## API

### Створення бота
```python
bot = SimpleBot(token: str)
```

### Команди
```python
# Простий спосіб - тільки текст
bot.on_command("start", "Привіт!")

# Складніший - з функцією
def hello(message):
    bot.send(message, "Привіт!")
bot.on_command("start", hello)
```

### Отримання даних
```python
text = bot.get_text(message)  # Текст повідомлення
name = bot.get_name(message)  # Ім'я користувача
```

### Надсилання
```python
bot.send(message, "Текст")
bot.send_photo(message, "photo.jpg", "Підпис")
```

### Обробка повідомлень
```python
def echo(message):
    text = bot.get_text(message)
    bot.send(message, text)

bot.on_message(echo)
```

## Приклади

### Калькулятор
```python
def calculate(message):
    text = bot.get_text(message)
    parts = text.split()
    
    if len(parts) == 3:
        num1 = float(parts[0])
        op = parts[1]
        num2 = float(parts[2])
        
        if op == "+":
            result = num1 + num2
        elif op == "-":
            result = num1 - num2
        elif op == "*":
            result = num1 * num2
        elif op == "/":
            result = num1 / num2 if num2 != 0 else "Помилка"
        
        bot.send(message, f"= {result}")

bot.on_message(calculate)
```

### Випадковий вибір
```python
import random

jokes = ["Жарт 1", "Жарт 2", "Жарт 3"]

def joke(message):
    bot.send(message, random.choice(jokes))

bot.on_command("joke", joke)
```

## Ліцензія

MIT License - вільно для навчальних цілей

## Автор

Створено **bendband** для навчання школярів програмуванню

🌐 https://bendband.net
