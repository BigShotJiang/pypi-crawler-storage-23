# Code of Conduct

This project follows a simple standard:

- Be respectful and constructive.
- Focus on technical issues, not personal attacks.
- Assume good intent and ask clarifying questions before escalating.

Maintainers may remove comments or contributions that violate these expectations.
