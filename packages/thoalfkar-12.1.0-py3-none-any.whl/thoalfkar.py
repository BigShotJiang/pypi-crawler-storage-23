import asyncio
import aiohttp
import os
import time
import sys
from uuid import uuid4

class Thoalfkar:
    def __init__(self):
        self.version = "12.1.0"
        self.conn = None
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        
        self.apis = [
            "https://www.tikwm.com/api/?url={}", 
            "https://api.vkrdown.com/v1/fetch?url={}",
            "https://api.tik.fail/api/video?url={}",
            "https://api.puredownloader.com/v1/fetch?url={}",
            "https://api.allinonedownloader.com/v1/fetch?url={}",
            "https://ssstik.io/api/v1/fetch?url={}",
            "https://snaptik.app/api/v2/fetch?url={}",
            "https://lovetik.com/api/ajax_search?url={}",
            "https://toptik.pro/api/fetch?url={}",
            "https://api.savefrom.net/api/fetch?url={}",
            "https://api.downloadanyvideo.com/api/fetch?url={}",
            "https://y2mate.com/api/ajax_search?url={}",
            "https://keepv.id/api/fetch?url={}",
            "https://9nana.com/api/ajax?url={}",
            "https://save.tube/api/fetch?url={}",
            "https://en.savefrom.net/api/endpoint?url={}",
            "https://dl-video.com/api/fetch?url={}",
            "https://getvideo.pwn/api/fetch?url={}",
            "https://ddownr.com/api/fetch?url={}",
            "https://loader.to/api/fetch?url={}"
        ]

    def _get_conn(self):
        if self.conn is None or self.conn.closed:
          
            self.conn = aiohttp.TCPConnector(limit=500, limit_per_host=20, ttl_dns_cache=600)
        return self.conn

    async def _fetch_api(self, session, url, mode, quality):
        try:
         
            async with session.get(url, timeout=2.0) as r:
                if r.status == 200:
                    data = await r.json()
                    return self._parse(data, mode, quality)
        except: return None

    def _parse(self, data, mode, q):
        d = data.get('data') or data
        if mode == 'a': return d.get('music') or d.get('audio') or d.get('mp3') or d.get('music_url')
        if 'medias' in d:
            for m in d['medias']:
                if str(q) in str(m.get('quality', '')): return m['url']
        return d.get('play') or d.get('url') or d.get('video_url') or d.get('link')

    async def download(self, url, mode='v', quality='720'):
        start_time = time.time()
        filename = f"thul_{uuid4().hex[:5]}.{'mp3' if mode == 'a' else 'mp4'}"
        
    
        async with aiohttp.ClientSession(connector=self._get_conn(), headers=self.headers) as session:
            tasks = [self._fetch_api(session, api.format(url), mode, quality) for api in self.apis]
            
            direct_url = None
         
            for future in asyncio.as_completed(tasks):
                res = await future
                if res and "http" in res:
                    direct_url = res
                    break

            if direct_url:
         
                async with session.get(direct_url, timeout=10) as resp:
                    if resp.status == 200:
                        with open(filename, 'wb') as f:
                            async for chunk in resp.content.iter_chunked(512 * 1024): 
                                f.write(chunk)
                        return filename, round(time.time() - start_time, 2)
        return None, 0

_thul = Thoalfkar()
async def download(url, mode='v', quality='720'):
    return await _thul.download(url, mode, quality)
