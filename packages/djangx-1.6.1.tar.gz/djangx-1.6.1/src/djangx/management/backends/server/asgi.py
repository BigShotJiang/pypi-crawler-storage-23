"""ASGI configuration."""

from django.core.asgi import get_asgi_application

SERVER_APPLICATION = get_asgi_application()
