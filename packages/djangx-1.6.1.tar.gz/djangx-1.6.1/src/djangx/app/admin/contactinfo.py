"""Contact info admin."""

__all__: list[str] = []
