"""
MCP Service Constants - Protocol versions, client info, and default tool whitelists.
"""
from typing import Dict

MCP_PROTOCOL_VERSION = '2024-11-05'

MCP_CLIENT_INFO = {
    'name': 'signalpilot-ai-internal',
    'version': '0.10.1'
}

# Default port for signalpilot-mcp (fallback if dynamic port not available)
DEFAULT_MCP_PORT = 8235


def get_builtin_servers() -> Dict[str, Dict]:
    """Get built-in server configurations with dynamic port.

    Returns:
        Dictionary of built-in server configs
    """
    # Import here to avoid circular imports
    from signalpilot_ai_internal.mcp_server_manager import get_signalpilot_mcp_url

    url = get_signalpilot_mcp_url()
    if url is None:
        # Fallback to default port if server not yet configured
        url = f"http://127.0.0.1:{DEFAULT_MCP_PORT}/mcp"

    return {
        'signalpilot': {
            'name': 'signalpilot',
            'url': url,
            'type': 'http',
            'isBuiltin': True,
        }
    }


# Keep BUILTIN_SERVERS as a static fallback for backward compatibility
BUILTIN_SERVERS = {
    'signalpilot': {
        'name': 'signalpilot',
        'url': f'http://127.0.0.1:{DEFAULT_MCP_PORT}/mcp',
        'type': 'http',
        'isBuiltin': True,
    }
}

DEFAULT_WHITELISTED_TOOLS_BY_SERVER = {
    'Dbt': [
        'query_metrics',
        'get_metrics_compiled_sql',
        'get_all_models',
        'get_mart_models',
        'get_model_details',
        'get_model_parents',
        'get_model_children',
        'get_related_models',
        'list_metrics',
        'get_semantic_model_details',
    ],
    'Google': [
        'start_google_auth',
        'search_docs',
        'get_doc_content',
        'list_docs_in_folder',
        'inspect_doc_structure',
        'read_document_comments',
        'create_document_comment',
        'reply_to_document_comment',
        'resolve_document_comment',
        'search_drive_files',
        'list_drive_items',
        'get_drive_file_content',
        'get_drive_file_download_url',
        'list_drive_items_in_folder',
    ],
    'Slack': [
        'conversations_search_messages',
        'conversations_history',
        'conversations_replies',
        'channels_list',
    ],
    'Notion': [
        'API-post-search',
        'API-get-block-children',
        'API-retrieve-a-page',
        'API-retrieve-a-database',
        'API-post-database-query',
    ],
}

DEFAULT_WHITELISTED_TOOLS = [
    tool for tools in DEFAULT_WHITELISTED_TOOLS_BY_SERVER.values() for tool in tools
]
