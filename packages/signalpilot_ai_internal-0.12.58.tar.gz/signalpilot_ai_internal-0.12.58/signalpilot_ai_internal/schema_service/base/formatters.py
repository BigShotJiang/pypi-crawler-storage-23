"""Formatters for schema output."""

from typing import Any, Dict, Mapping


class MarkdownFormatter:
    """Format schema data as markdown."""

    @staticmethod
    def format_column(col: Dict[str, Any]) -> str:
        """Format a single column as markdown.

        Expected column format: {"name": str, "type": str, "nullable": bool, "default": str|None}
        """
        name = col.get("name", "unknown")
        data_type = col.get("type", "unknown")

        constraints = []
        if col.get("nullable") is False:
            constraints.append("NOT NULL")
        if col.get("default"):
            constraints.append(f"DEFAULT {col['default']}")

        constraint_text = f" ({', '.join(constraints)})" if constraints else ""
        return f"- **{name}**: {data_type}{constraint_text}"

    @staticmethod
    def format_table(
        table_name: str,
        schema: Mapping[str, Any],
        schema_prefix: str = "",
    ) -> str:
        """Format a single table as markdown."""
        full_name = f"{schema_prefix}.{table_name}" if schema_prefix else table_name
        lines = [f"## {full_name}\n"]

        # Columns
        columns = schema.get("columns") or []
        if columns:
            lines.append(f"### Columns ({len(columns)})\n")
            for col in columns:
                lines.append(MarkdownFormatter.format_column(col))
            lines.append("")

        # Primary keys
        pks = schema.get("primary_keys") or []
        if pks:
            lines.append("### Primary Keys\n")
            pk_str = ", ".join([f"**{pk}**" for pk in pks])
            lines.append(f"- {pk_str}")
            lines.append("")

        # Foreign keys
        fks = schema.get("foreign_keys") or []
        if fks:
            lines.append("### Foreign Keys\n")
            for fk in fks:
                cols = ", ".join(fk.get("constrained_columns", []))
                ref_table = fk.get("referred_table", "unknown")
                ref_cols = ", ".join(fk.get("referred_columns", []))
                lines.append(f"- **{cols}** → {ref_table}({ref_cols})")
            lines.append("")

        # Indices
        indices = schema.get("indices") or []
        if indices:
            lines.append("### Indices\n")
            for idx in indices:
                name = idx.get("name", "unnamed")
                cols = ", ".join(idx.get("columns", []))
                unique = "UNIQUE " if idx.get("unique") else ""
                lines.append(f"- **{name}**: {unique}({cols})")
            lines.append("")

        lines.append("---\n")
        return "\n".join(lines)

    @staticmethod
    def format_schemas(
        schemas: Mapping[str, Mapping[str, Any]],
        title: str,
        schema_prefix: str = "",
    ) -> str:
        """Format all schemas as markdown."""
        lines = [f"# {title} Database Schema\n"]
        lines.append(f"Found **{len(schemas)}** table(s)\n")

        for table_name, schema in schemas.items():
            lines.append(MarkdownFormatter.format_table(table_name, schema, schema_prefix))

        return "\n".join(lines).strip()


class ResponseFormatter:
    """Format API responses."""

    @staticmethod
    def build_table_schemas(
        schemas: Mapping[str, Mapping[str, Any]],
        schema_prefix: str = "",
    ) -> Dict[str, Dict[str, Any]]:
        """Build frontend-compatible table_schemas dict."""
        result = {}
        for table_name, schema in schemas.items():
            full_name = f"{schema_prefix}.{table_name}" if schema_prefix else table_name
            result[full_name] = {
                "schema": schema_prefix or "public",
                "table_name": table_name,
                "full_name": full_name,
                "columns": schema.get("columns") or [],
                "primary_keys": schema.get("primary_keys") or [],
                "foreign_keys": schema.get("foreign_keys") or [],
                "indices": schema.get("indices") or [],
            }
        return result

    @staticmethod
    def schema_response(
        schemas: Mapping[str, Mapping[str, Any]],
        title: str,
        schema_prefix: str = "",
    ) -> Dict[str, Any]:
        """Build complete schema response."""
        return {
            "result": MarkdownFormatter.format_schemas(schemas, title, schema_prefix),
            "table_schemas": ResponseFormatter.build_table_schemas(schemas, schema_prefix),
        }
