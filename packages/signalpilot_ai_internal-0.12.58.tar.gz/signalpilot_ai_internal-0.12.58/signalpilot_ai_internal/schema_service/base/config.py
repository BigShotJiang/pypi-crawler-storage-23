"""Configuration loading for schema services."""

import json
import os
from typing import Dict, Optional


class ConfigLoader:
    """Load database configurations from environment variables."""

    @staticmethod
    def get_config_by_type(db_type: str) -> Optional[Dict]:
        """Get first config matching database type from _CONNECTION_JSON env vars."""
        for key, value in os.environ.items():
            if not key.endswith("_CONNECTION_JSON"):
                continue
            try:
                config = json.loads(value)
                if config.get("type") == db_type:
                    return config
            except (json.JSONDecodeError, TypeError):
                continue
        return None

    @staticmethod
    def get_all_configs() -> Dict[str, Dict]:
        """Get all database configs from environment."""
        configs = {}
        for key, value in os.environ.items():
            if not key.endswith("_CONNECTION_JSON"):
                continue
            try:
                config = json.loads(value)
                db_name = key.replace("_CONNECTION_JSON", "")
                configs[db_name] = config
            except (json.JSONDecodeError, TypeError):
                continue
        return configs
