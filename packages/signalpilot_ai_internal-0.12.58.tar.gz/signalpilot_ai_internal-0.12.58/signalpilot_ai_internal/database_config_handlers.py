"""HTTP handlers for database configuration API."""

import asyncio
import json
import logging
import threading

import tornado
from jupyter_server.base.handlers import APIHandler

from signalpilot_ai_internal.db_config.storage import get_storage
from signalpilot_ai_internal.mcp_server_manager import restart_signalpilot_mcp
from signalpilot_ai_internal.signalpilot_home import get_signalpilot_home

logger = logging.getLogger(__name__)


def _trigger_mcp_restart():
    """Restart the signalpilot-mcp server in a background daemon thread.

    Captures the running asyncio event loop so that the background thread can
    schedule the async MCP service disconnect/reconnect on it.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None

    t = threading.Thread(
        target=restart_signalpilot_mcp, args=(loop,), daemon=True
    )
    t.start()
    logger.info("Triggered MCP server restart in background")


class DatabaseConfigsHandler(APIHandler):
    """Handler for database configuration CRUD operations."""

    @tornado.web.authenticated
    def get(self, db_type=None):
        """Get database configurations."""
        try:
            storage = get_storage()
            configs = storage.get_by_type(db_type) if db_type else storage.get_all()
            self.finish(json.dumps({"configurations": configs, "count": len(configs)}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))

    @tornado.web.authenticated
    def post(self, db_type=None):
        """Add a new database configuration."""
        if not db_type:
            self.set_status(400)
            self.finish(json.dumps({"error": "Database type required in URL path"}))
            return
        try:
            body = json.loads(self.request.body.decode("utf-8"))
            if get_storage().add(db_type, body):
                _trigger_mcp_restart()
                self.finish(json.dumps({"success": True, "message": f"Added {db_type} config"}))
            else:
                self.set_status(400)
                self.finish(json.dumps({"error": "Failed to add configuration"}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"error": f"Invalid JSON: {e}"}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))

    @tornado.web.authenticated
    def put(self, db_type=None):
        """Update a database configuration."""
        if not db_type:
            self.set_status(400)
            self.finish(json.dumps({"error": "Database type required in URL path"}))
            return
        try:
            body = json.loads(self.request.body.decode("utf-8"))
            name = body.pop("name", None)
            if not name:
                self.set_status(400)
                self.finish(json.dumps({"error": "'name' required in body"}))
                return
            if get_storage().update(db_type, name, body):
                _trigger_mcp_restart()
                self.finish(json.dumps({"success": True, "message": f"Updated {name}"}))
            else:
                self.set_status(404)
                self.finish(json.dumps({"error": f"Config '{name}' not found"}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"error": f"Invalid JSON: {e}"}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))

    @tornado.web.authenticated
    def delete(self, db_type=None):
        """Delete a database configuration."""
        if not db_type:
            self.set_status(400)
            self.finish(json.dumps({"error": "Database type required in URL path"}))
            return
        name = self.get_argument("name", None)
        if not name:
            self.set_status(400)
            self.finish(json.dumps({"error": "'name' required as query parameter"}))
            return
        try:
            if get_storage().remove(db_type, name):
                _trigger_mcp_restart()
                self.finish(json.dumps({"success": True, "message": f"Deleted {name}"}))
            else:
                self.set_status(404)
                self.finish(json.dumps({"error": f"Config '{name}' not found"}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))


class DatabaseDefaultsHandler(APIHandler):
    """Handler for database defaults."""

    @tornado.web.authenticated
    def get(self):
        """Get defaults."""
        try:
            self.finish(json.dumps({"defaults": get_storage().get_defaults()}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))

    @tornado.web.authenticated
    def post(self):
        """Set defaults."""
        try:
            body = json.loads(self.request.body.decode("utf-8"))
            if get_storage().set_defaults(body):
                _trigger_mcp_restart()
                self.finish(json.dumps({"success": True, "message": "Defaults updated"}))
            else:
                self.set_status(500)
                self.finish(json.dumps({"error": "Failed to set defaults"}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"error": f"Invalid JSON: {e}"}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))


class SignalPilotHomeInfoHandler(APIHandler):
    """Handler for SignalPilotHome directory info."""

    @tornado.web.authenticated
    def get(self):
        """Get SignalPilotHome information."""
        try:
            self.finish(json.dumps(get_signalpilot_home().get_info()))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))


class DatabaseConfigSyncHandler(APIHandler):
    """Handler for syncing all database configurations with frontend."""

    @tornado.web.authenticated
    def get(self):
        """Get all configurations in frontend format."""
        try:
            configs = get_storage().get_all_frontend_format()
            self.finish(json.dumps({"configurations": configs, "count": len(configs)}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))

    @tornado.web.authenticated
    def post(self):
        """Sync all configurations from frontend to db.toml."""
        try:
            body = json.loads(self.request.body.decode("utf-8"))
            configs = body.get("configurations", [])
            if get_storage().sync_all(configs):
                _trigger_mcp_restart()
                self.finish(json.dumps({"success": True, "count": len(configs)}))
            else:
                self.set_status(500)
                self.finish(json.dumps({"error": "Failed to sync configurations"}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"error": f"Invalid JSON: {e}"}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))
