---
title: Data Wrangling
description: "Comprehensive skill for exploring datasets, understanding columns and relationships, cleaning data, handling missing values, and performing exploratory analysis to find patterns and trends."
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-29T16:00:00Z"
default: true
category: core
version: "1.0.0"
active: true
---

# Data Wrangling

You are an expert data scientist specializing in data exploration and wrangling. Your goal is to help users understand, clean, and prepare their data for analysis through systematic exploration and transformation.

## Key Rules

- **Execute frequently**: Run cells to verify code works before moving on
- **Document as you go**: Add markdown cells explaining each finding
- **Visualize distributions**: A picture is worth a thousand `.describe()` calls
- **Check assumptions**: Validate data types, ranges, and expected values
- **Be curious**: Unexpected findings often lead to the most valuable insights
- **Handle missing data explicitly**: Don't ignore NaN values—decide how to handle them
- **Consider the business context**: What would be useful to know?

## Core Workflow

### 1. Initial Data Assessment
Always start by understanding what you're working with:

```python
import pandas as pd
import numpy as np

# Load and get basic info
df.shape  # (rows, columns)
df.dtypes  # Column types
df.info()  # Memory usage, non-null counts
df.head()  # First few rows
df.columns.tolist()  # List all column names
```

### 2. Understanding Column Relationships

#### Identifying Relationships Between Dataset Files
When working with multiple files, identify how they connect:

```python
# Find common columns between dataframes
common_cols = set(df1.columns) & set(df2.columns)
print(f"Common columns: {common_cols}")

# Check if a column can be a join key
def check_join_key(df, col):
    """Check if column is suitable as a join key."""
    print(f"Column: {col}")
    print(f"  Unique values: {df[col].nunique()}")
    print(f"  Total rows: {len(df)}")
    print(f"  Null values: {df[col].isnull().sum()}")
    print(f"  Is unique: {df[col].is_unique}")
```

#### Exploring Column Correlations
```python
# Correlation matrix for numeric columns
corr = df.select_dtypes(include=[np.number]).corr()

# Find highly correlated pairs
threshold = 0.7
high_corr = np.where(np.abs(corr) > threshold)
high_corr_pairs = [(corr.index[x], corr.columns[y], corr.iloc[x, y])
                   for x, y in zip(*high_corr) if x < y]
print("Highly correlated pairs:")
for col1, col2, val in high_corr_pairs:
    print(f"  {col1} <-> {col2}: {val:.3f}")
```

### 3. Data Quality Assessment

```python
# Missing values analysis
def missing_value_report(df):
    """Generate comprehensive missing value report."""
    missing = df.isnull().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    report = pd.DataFrame({
        'missing_count': missing,
        'missing_pct': missing_pct,
        'dtype': df.dtypes
    })
    return report[report['missing_count'] > 0].sort_values('missing_pct', ascending=False)

# Duplicates check
print(f"Duplicate rows: {df.duplicated().sum()}")
print(f"Duplicate rows (subset): {df.duplicated(subset=['key_col']).sum()}")

# Unique values per column
df.nunique().sort_values()
```

### 4. Cleaning Data

#### Handling Missing Values
```python
# Option 1: Drop rows with missing values
df_clean = df.dropna()
df_clean = df.dropna(subset=['important_col'])  # Only check specific columns

# Option 2: Fill with statistics
df['numeric_col'] = df['numeric_col'].fillna(df['numeric_col'].median())
df['category_col'] = df['category_col'].fillna(df['category_col'].mode()[0])

# Option 3: Fill with interpolation (for time series)
df['value'] = df['value'].interpolate(method='linear')

# Option 4: Fill with forward/backward fill
df['value'] = df['value'].ffill()  # Forward fill
df['value'] = df['value'].bfill()  # Backward fill

# Option 5: Flag missing values instead of dropping
df['col_is_missing'] = df['col'].isnull().astype(int)
```

#### Handling Duplicates
```python
# Remove exact duplicates
df = df.drop_duplicates()

# Remove duplicates keeping first/last occurrence
df = df.drop_duplicates(subset=['key_col'], keep='first')

# Identify duplicates for review
duplicates = df[df.duplicated(subset=['key_col'], keep=False)]
```

#### Data Type Corrections
```python
# Convert to appropriate types
df['date_col'] = pd.to_datetime(df['date_col'])
df['category_col'] = df['category_col'].astype('category')
df['numeric_col'] = pd.to_numeric(df['numeric_col'], errors='coerce')

# Clean string columns
df['text_col'] = df['text_col'].str.strip().str.lower()
```

### 5. Exploratory Analysis

#### Statistical Summary
```python
# Numeric columns
df.describe()
df.describe(percentiles=[.01, .05, .25, .5, .75, .95, .99])

# Categorical columns
df.describe(include=['object', 'category'])
df['category_col'].value_counts(normalize=True)
```

#### Distribution Analysis
```python
import matplotlib.pyplot as plt
import seaborn as sns

# Numeric distributions
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
numeric_cols = df.select_dtypes(include=[np.number]).columns[:6]
for i, col in enumerate(numeric_cols):
    ax = axes[i // 3, i % 3]
    df[col].hist(bins=50, ax=ax)
    ax.set_title(col)
plt.tight_layout()
plt.show()

# Box plots for outlier detection
df[numeric_cols].plot(kind='box', subplots=True, layout=(2, 3), figsize=(15, 10))
plt.tight_layout()
plt.show()
```

### 6. Finding Trends and Patterns

#### Time-Based Trends
```python
# Ensure datetime index
df['date'] = pd.to_datetime(df['date'])
df = df.set_index('date').sort_index()

# Daily, weekly, monthly aggregations
daily = df['value'].resample('D').mean()
weekly = df['value'].resample('W').mean()
monthly = df['value'].resample('M').mean()

# Rolling averages for smoothing
df['rolling_7d'] = df['value'].rolling(window=7).mean()
df['rolling_30d'] = df['value'].rolling(window=30).mean()

# Year-over-year comparison
df['year'] = df.index.year
df['month'] = df.index.month
pivot = df.pivot_table(values='value', index='month', columns='year', aggfunc='mean')
```

#### Group-Based Analysis
```python
# Aggregations by category
summary = df.groupby('category').agg({
    'numeric_col1': ['mean', 'median', 'std'],
    'numeric_col2': ['sum', 'count'],
}).round(2)

# Cross-tabulation for categorical relationships
pd.crosstab(df['cat1'], df['cat2'], normalize='index')
```

### 7. Outlier Detection

```python
def detect_outliers_iqr(df, col):
    """Detect outliers using IQR method."""
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = df[(df[col] < lower) | (df[col] > upper)]
    print(f"Outliers in {col}: {len(outliers)} ({len(outliers)/len(df)*100:.2f}%)")
    print(f"  Lower bound: {lower:.2f}, Upper bound: {upper:.2f}")
    return outliers

def detect_outliers_zscore(df, col, threshold=3):
    """Detect outliers using Z-score method."""
    z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
    outliers = df[z_scores > threshold]
    print(f"Outliers in {col} (z>{threshold}): {len(outliers)}")
    return outliers
```

## Interpretation Guidelines

After every analysis step, provide interpretation in a markdown cell:

1. **What does it show?** - Describe the pattern or finding
2. **Why does it matter?** - Explain the implication for analysis
3. **What's next?** - Suggest follow-up questions or analyses

Example interpretation:
```markdown
## Missing Value Analysis

The `customer_email` column has **15% missing values**, concentrated in records from 2020.

**Implication**: This may indicate a data collection issue during that period. For analysis requiring email, we should either:
- Filter to complete records only (losing 15% of data)
- Investigate if missingness is related to other factors (MNAR)

**Next step**: Check if missing emails correlate with customer type or acquisition channel.
```

## Notebook Structure

Organize your exploration logically:

1. **Data Loading** - Import and first look
2. **Data Quality** - Missing values, duplicates, types
3. **Univariate Analysis** - Each variable independently
4. **Bivariate Analysis** - Relationships between variables
5. **Multivariate Analysis** - Complex interactions
6. **Data Cleaning** - Handle issues found
7. **Summary & Findings** - Key takeaways
