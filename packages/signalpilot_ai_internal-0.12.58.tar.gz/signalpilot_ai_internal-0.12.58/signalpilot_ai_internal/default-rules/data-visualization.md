---
title: Data Visualization
description: Production-ready chart generation with consistent styling, professional formatting, and export capabilities. Use when the user needs polished visualizations for reports, presentations, or dashboards.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-02-23T00:00:00Z"
default: true
category: core
version: "1.2.0"
active: true
---

# Data Visualization

Charts should use the SignalPilot dark theme and brand palette defined below by default. These are sensible defaults that produce professional, consistent visualizations — apply them unless the user explicitly requests different styling.

## Style Guidelines

1. **Apply the SignalPilot style config below** before creating charts
2. **Default color is `COLORS['primary']` (#c4b5fd, light purple)** — use for single-series bars, histograms, scatter plots
3. **Multi-series charts use `CATEGORICAL_PALETTE`** — purple-first ordering
4. **Heatmaps use the custom `signalpilot` colormap** (dark → purple → pink) — preferred over built-in cmaps
5. **Dark backgrounds** — figure: `#08070e`, axes: `#12101e`
6. **Light text** — titles/labels `#FAFAFA`, ticks `#a4a7ae`
7. Avoid pie charts for more than 6 categories — prefer bar charts
8. Include units in axis labels when applicable
9. Start y-axis at zero for bar charts unless showing change
10. Avoid 3D effects and chartjunk
11. Prefer horizontal bars for long labels

## Standard Style Configuration

Always start with a consistent base style:

```python
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# SignalPilot dark theme style setup
plt.rcParams.update({
    'figure.figsize': (10, 6),
    'figure.dpi': 100,
    'savefig.dpi': 300,
    'font.size': 11,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.titlesize': 16,
    'axes.spines.top': False,
    'axes.spines.right': False,
    # Dark theme colors
    'figure.facecolor': '#08070e',
    'axes.facecolor': '#12101e',
    'axes.edgecolor': '#272336',
    'axes.labelcolor': '#e9eaeb',
    'text.color': '#FAFAFA',
    'xtick.color': '#a4a7ae',
    'ytick.color': '#a4a7ae',
    'grid.color': '#1d182b',
    'legend.facecolor': '#12101e',
    'legend.edgecolor': '#272336',
    'legend.labelcolor': '#e9eaeb',
    'savefig.facecolor': '#08070e',
})

# SignalPilot brand palette
COLORS = {
    'primary': '#c4b5fd',       # Brand Primary (light purple)
    'secondary': '#ff8dc4',     # Brand Secondary (pink)
    'tertiary': '#8b5cf6',      # Brand Primary Dark (medium purple)
    'blue': '#73acfb',          # Chart Blue
    'red': '#c45757',           # Chart Red
    'yellow': '#fec163',        # Chart Yellow
    'green': '#4ca86f',         # Chart Green
    'neutral': '#a4a7ae',       # Text Input Default (medium gray)
    'background': '#08070e',    # Background Base
    'elevated': '#12101e',      # Background Elevated
    'border': '#272336',        # Border Highlight
    'error': '#f04438',         # Error
    'success': '#16a34a',       # Success
}

# SignalPilot categorical palette (purple-first)
CATEGORICAL_PALETTE = ['#c4b5fd', '#ff8dc4', '#8b5cf6', '#73acfb', '#fec163', '#4ca86f']
```

## Chart Templates

### Line Chart (Time Series)

```python
def create_line_chart(df, x_col, y_cols, title, xlabel, ylabel):
    """Create a professional line chart."""
    fig, ax = plt.subplots(figsize=(12, 6))

    for i, col in enumerate(y_cols):
        ax.plot(df[x_col], df[col],
                color=CATEGORICAL_PALETTE[i % len(CATEGORICAL_PALETTE)],
                linewidth=2, label=col)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold', pad=20)
    ax.legend(loc='upper right', frameon=True, fancybox=True)

    # Format x-axis for dates
    if pd.api.types.is_datetime64_any_dtype(df[x_col]):
        fig.autofmt_xdate()

    plt.tight_layout()
    return fig, ax
```

### Bar Chart

```python
def create_bar_chart(categories, values, title, xlabel, ylabel, horizontal=False):
    """Create a professional bar chart."""
    fig, ax = plt.subplots(figsize=(10, 6))

    if horizontal:
        bars = ax.barh(categories, values, color=COLORS['primary'], height=0.6)
        ax.set_xlabel(ylabel)
        ax.set_ylabel(xlabel)
        # Add value labels
        for bar, val in zip(bars, values):
            ax.text(val + max(values)*0.01, bar.get_y() + bar.get_height()/2,
                   f'{val:,.0f}', va='center', fontsize=9)
    else:
        bars = ax.bar(categories, values, color=COLORS['primary'], width=0.6)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        # Add value labels
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width()/2, val + max(values)*0.01,
                   f'{val:,.0f}', ha='center', fontsize=9)

    ax.set_title(title, fontweight='bold', pad=20)
    plt.tight_layout()
    return fig, ax
```

### Scatter Plot

```python
def create_scatter_plot(df, x_col, y_col, title, xlabel, ylabel,
                        hue_col=None, size_col=None):
    """Create a professional scatter plot."""
    fig, ax = plt.subplots(figsize=(10, 8))

    scatter_kwargs = {
        'alpha': 0.7,
        'edgecolors': '#272336',
        'linewidths': 0.5
    }

    if hue_col and size_col:
        from matplotlib.colors import LinearSegmentedColormap
        sp_cmap = LinearSegmentedColormap.from_list(
            'signalpilot', ['#08070e', '#8b5cf6', '#c4b5fd', '#ff8dc4']
        )
        scatter = ax.scatter(df[x_col], df[y_col],
                            c=df[hue_col], s=df[size_col]*10,
                            cmap=sp_cmap, **scatter_kwargs)
        plt.colorbar(scatter, label=hue_col)
    elif hue_col:
        for i, cat in enumerate(df[hue_col].unique()):
            mask = df[hue_col] == cat
            ax.scatter(df.loc[mask, x_col], df.loc[mask, y_col],
                      color=CATEGORICAL_PALETTE[i], label=cat, **scatter_kwargs)
        ax.legend()
    else:
        ax.scatter(df[x_col], df[y_col], color=COLORS['primary'], **scatter_kwargs)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold', pad=20)

    plt.tight_layout()
    return fig, ax
```

### Heatmap

```python
def create_heatmap(data, title, xlabel='', ylabel='', annot=True, fmt='.2f'):
    """Create a professional heatmap."""
    fig, ax = plt.subplots(figsize=(12, 10))

    # Purple-based colormap matching SignalPilot brand
    from matplotlib.colors import LinearSegmentedColormap
    sp_cmap = LinearSegmentedColormap.from_list(
        'signalpilot', ['#08070e', '#8b5cf6', '#c4b5fd', '#ff8dc4']
    )

    sns.heatmap(data, annot=annot, fmt=fmt, cmap=sp_cmap,
                ax=ax, square=True,
                cbar_kws={'shrink': 0.8},
                annot_kws={'size': 9, 'color': '#FAFAFA'})

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold', pad=20)

    plt.tight_layout()
    return fig, ax
```

### Histogram with KDE

```python
def create_histogram(data, title, xlabel, ylabel='Frequency', bins=50, kde=True):
    """Create a histogram with optional KDE overlay."""
    fig, ax = plt.subplots(figsize=(10, 6))

    ax.hist(data, bins=bins, color=COLORS['primary'],
            alpha=0.7, edgecolor='#272336', density=kde)

    if kde:
        from scipy import stats
        kde_x = np.linspace(data.min(), data.max(), 200)
        kde_y = stats.gaussian_kde(data.dropna())(kde_x)
        ax.plot(kde_x, kde_y, color=COLORS['secondary'], linewidth=2, label='KDE')
        ax.legend()

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel if not kde else 'Density')
    ax.set_title(title, fontweight='bold', pad=20)

    # Add statistics annotation
    stats_text = f'Mean: {data.mean():.2f}\nMedian: {data.median():.2f}\nStd: {data.std():.2f}'
    ax.text(0.95, 0.95, stats_text, transform=ax.transAxes,
            verticalalignment='top', horizontalalignment='right',
            color='#FAFAFA',
            bbox=dict(boxstyle='round', facecolor='#12101e', edgecolor='#272336', alpha=0.9))

    plt.tight_layout()
    return fig, ax
```

## Chart Selection Guide

| Data Relationship | Recommended Chart |
|------------------|-------------------|
| Trend over time | Line chart |
| Comparison (few categories) | Bar chart |
| Comparison (many categories) | Horizontal bar chart |
| Distribution | Histogram, Box plot |
| Correlation | Scatter plot, Heatmap |
| Part of whole | Donut chart (max 6 parts) |
| Ranking | Horizontal bar chart |

## Export Options

```python
def save_chart(fig, filename, formats=['png', 'svg', 'pdf']):
    """Save chart in multiple formats."""
    for fmt in formats:
        fig.savefig(f'{filename}.{fmt}',
                   dpi=300, bbox_inches='tight',
                   facecolor='#08070e', edgecolor='none')
    print(f"Saved: {filename}.{', '.join(formats)}")
```
