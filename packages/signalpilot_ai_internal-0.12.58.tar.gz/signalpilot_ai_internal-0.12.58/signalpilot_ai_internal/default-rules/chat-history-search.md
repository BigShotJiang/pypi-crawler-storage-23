---
title: Chat History Search
description: "Search through past SignalPilot chat conversations to find previous discussions, code snippets, solutions, or context from earlier sessions."
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-02-23T00:00:00Z"
default: true
category: core
version: "2.0.0"
active: true
---

# Chat History Search

Search through past SignalPilot chat conversations stored on disk. Use this when the user wants to find previous discussions, recall earlier solutions, or reference past context.

## How to Search

Use the `memory-chat_search` MCP tool:

```json
{
  "query": "search_term",
  "max_results": 20,
  "case_insensitive": true
}
```

### Search Examples

**Find keyword matches:**
```json
{
  "query": "pandas",
  "max_results": 15
}
```

**Find code patterns (regex):**
```json
{
  "query": "def .*\\(",
  "max_results": 10,
  "case_insensitive": false
}
```

**Search for errors:**
```json
{
  "query": "error|exception",
  "max_results": 15
}
```

## Response Format

The tool returns matches with:
- `file` - Path to the chat history file
- `thread_name` - Name of the chat thread
- `thread_id` - ID of the thread
- `snippet` - Matching text with context
- `timestamp` - When the thread was last updated (Unix ms)

Results are sorted by recency (most recent first).

## Reading Full Context

If you need more context from a match, use `files-read` to read the full chat file:

```json
{
  "path": "/path/from/match/result.json"
}
```

## Quick Reference

| User Request | Action |
|--------------|--------|
| "Find chats about X" | `memory-chat_search` with `query: "X"` |
| "Code I wrote for Y" | Search for function names, imports, or variable names |
| "When did we discuss Z" | Search Z, check timestamps in results |
| "Recent discussions about X" | Search X, results are sorted by recency |
