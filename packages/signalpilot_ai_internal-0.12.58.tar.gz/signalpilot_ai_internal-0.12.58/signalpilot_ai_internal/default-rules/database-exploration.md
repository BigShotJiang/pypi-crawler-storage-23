---
title: Database Exploration
description: "Skill for discovering and exploring database schemas, listing available databases, finding tables, and understanding data structures before writing queries."
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-29T16:00:00Z"
default: true
category: core
version: "1.0.0"
active: true
---

# Database Exploration

You are an expert at exploring database schemas and structures. Your goal is to help users discover available databases, understand table schemas, and find the right data sources for their analysis.

## Key Rules

1. **Always list available databases first** - Use the `database-list` tool to see what's available
2. **Search schemas before querying** - Find the right tables and columns before writing queries
3. **Understand relationships** - Identify primary and foreign keys to join tables correctly
4. **Sample data before full queries** - Use LIMIT to preview data structure
5. **Document findings** - Note important tables, columns, and relationships for future reference

## Available Tools

### Discovering Databases
Use the `database-list` tool to list all available database connections:

```
database-list()
```

This returns all configured database connections that can be queried.

### Schema Search
Use schema search tools to find relevant tables and columns:

```
database-schema_search(query='customer', database='main')
```

This helps locate:
- Tables containing specific keywords
- Columns matching search terms
- Related tables and foreign keys

## Exploration Workflow

### Step 1: List Available Databases
```
database-list()
```

Identify which databases are available and their connection types (PostgreSQL, MySQL, Snowflake, etc.).

### Step 2: Explore Database Schema

#### List All Tables
```sql
-- PostgreSQL / MySQL
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

-- Snowflake
SHOW TABLES IN SCHEMA database_name.schema_name;

-- SQLite
SELECT name FROM sqlite_master WHERE type='table';
```

#### Search for Specific Tables
Use schema search to find tables related to your analysis:
```
database-schema_search(query='orders', database='sales_db')
```

### Step 3: Understand Table Structure

#### Get Column Details
```sql
-- PostgreSQL
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'customers'
ORDER BY ordinal_position;

-- MySQL
DESCRIBE customers;

-- Snowflake
DESC TABLE customers;
```

#### Sample Data
```sql
-- Always preview data structure
SELECT * FROM customers LIMIT 10;

-- Check value distributions
SELECT column_name, COUNT(*) as count
FROM table_name
GROUP BY column_name
ORDER BY count DESC
LIMIT 20;
```

### Step 4: Identify Relationships

#### Find Primary Keys
```sql
-- PostgreSQL
SELECT
    tc.table_name,
    kc.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kc
    ON tc.constraint_name = kc.constraint_name
WHERE tc.constraint_type = 'PRIMARY KEY'
    AND tc.table_schema = 'public';
```

#### Find Foreign Keys
```sql
-- PostgreSQL
SELECT
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS referenced_table,
    ccu.column_name AS referenced_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage ccu
    ON tc.constraint_name = ccu.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY';
```

## Common Exploration Patterns

### Pattern 1: Quick Database Overview
```python
# After connecting to database
def database_overview(conn):
    """Get a quick overview of database contents."""

    # List all tables
    tables = pd.read_sql("""
        SELECT table_name,
               (SELECT COUNT(*) FROM information_schema.columns
                WHERE table_name = t.table_name) as column_count
        FROM information_schema.tables t
        WHERE table_schema = 'public'
        ORDER BY table_name
    """, conn)

    print(f"Found {len(tables)} tables:")
    for _, row in tables.iterrows():
        print(f"  - {row['table_name']} ({row['column_count']} columns)")

    return tables
```

### Pattern 2: Table Profiling
```python
def profile_table(conn, table_name):
    """Profile a table's structure and contents."""

    # Get row count
    count = pd.read_sql(f"SELECT COUNT(*) as cnt FROM {table_name}", conn)
    print(f"Table: {table_name}")
    print(f"Row count: {count['cnt'].iloc[0]:,}")

    # Get column info
    columns = pd.read_sql(f"""
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_name = '{table_name}'
        ORDER BY ordinal_position
    """, conn)

    print(f"\nColumns ({len(columns)}):")
    for _, col in columns.iterrows():
        nullable = "NULL" if col['is_nullable'] == 'YES' else "NOT NULL"
        print(f"  - {col['column_name']}: {col['data_type']} ({nullable})")

    # Sample data
    sample = pd.read_sql(f"SELECT * FROM {table_name} LIMIT 5", conn)
    print(f"\nSample data:")
    return sample
```

### Pattern 3: Find Related Tables
```python
def find_related_tables(conn, table_name):
    """Find tables related through foreign keys."""

    # Tables this table references
    outgoing = pd.read_sql(f"""
        SELECT DISTINCT ccu.table_name as related_table
        FROM information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu
            ON tc.constraint_name = ccu.constraint_name
        WHERE tc.table_name = '{table_name}'
            AND tc.constraint_type = 'FOREIGN KEY'
    """, conn)

    # Tables that reference this table
    incoming = pd.read_sql(f"""
        SELECT DISTINCT tc.table_name as related_table
        FROM information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu
            ON tc.constraint_name = ccu.constraint_name
        WHERE ccu.table_name = '{table_name}'
            AND tc.constraint_type = 'FOREIGN KEY'
    """, conn)

    print(f"Tables {table_name} references: {outgoing['related_table'].tolist()}")
    print(f"Tables referencing {table_name}: {incoming['related_table'].tolist()}")
```

## Schema Documentation

When exploring a new database, document your findings:

```markdown
## Database Schema: sales_db

### Core Tables

| Table | Description | Row Count | Key Columns |
|-------|-------------|-----------|-------------|
| customers | Customer master data | 50,000 | customer_id (PK), email |
| orders | Sales transactions | 500,000 | order_id (PK), customer_id (FK) |
| products | Product catalog | 1,200 | product_id (PK), category |

### Key Relationships
- orders.customer_id → customers.customer_id
- order_items.product_id → products.product_id

### Notes
- Customer data includes PII (email, phone)
- Orders table partitioned by order_date
```
