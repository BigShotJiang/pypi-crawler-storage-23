"""
MCP Server Manager.

Handles automatic startup and management of MCP servers (like dbt-mcp) when SignalPilot AI starts.
"""
import asyncio
import atexit
import logging
import os
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from signalpilot_ai_internal.db_config.storage import get_mcp_env_vars

logger = logging.getLogger(__name__)

# Default port range for signalpilot-mcp server
MCP_DEFAULT_PORT = 8235
MCP_PORT_RANGE = 10  # Try ports 8235-8244


def find_available_port(start_port: int, port_range: int) -> int:
    """Find an available port starting from start_port.

    Args:
        start_port: First port to try
        port_range: Number of ports to try

    Returns:
        Available port number

    Raises:
        RuntimeError: If no available port found in range
    """
    for port in range(start_port, start_port + port_range):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', port))
                logger.info(f"Found available port: {port}")
                return port
        except OSError:
            logger.debug(f"Port {port} is in use, trying next")
            continue

    raise RuntimeError(
        f"No available port found in range {start_port}-{start_port + port_range - 1}"
    )


class MCPServerManager:
    """Manages MCP server processes."""

    def __init__(self):
        self._processes: Dict[str, subprocess.Popen] = {}
        self._server_configs: Dict[str, Dict] = {}
        self._server_ports: Dict[str, int] = {}  # Track actual ports used
        self._lock = threading.Lock()

        atexit.register(self.stop_all_servers)

    def add_server_config(
        self,
        name: str,
        command: List[str],
        cwd: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        transport: str = "stdio"
    ):
        """Add an MCP server configuration.

        Args:
            name: Server identifier
            command: Command to start the server (as list)
            cwd: Working directory for the server process (default: None)
            env: Environment variables for the server (default: None)
            transport: MCP transport type (default: "stdio")
        """
        self._server_configs[name] = {
            'name': name,
            'command': command,
            'cwd': cwd,
            'env': env or {},
            'transport': transport
        }
        logger.info(f"Added MCP server config: {name}")
    
    def start_server(self, name: str) -> bool:
        """Start a specific MCP server.

        Args:
            name: Server identifier

        Returns:
            True if server started successfully, False otherwise
        """
        config = self._server_configs.get(name)
        if not config:
            logger.error(f"No configuration found for server: {name}")
            return False

        if name in self._processes:
            if self._processes[name].poll() is None:
                logger.info(f"MCP server '{name}' is already running")
                return True
            del self._processes[name]

        try:
            logger.info(f"Starting MCP server '{name}' with command: {' '.join(config['command'])}")
            use_pipes = config['transport'] != 'http'
            process = self._create_process(config, use_pipes)
            self._processes[name] = process
            logger.info(f"MCP server '{name}' started with PID: {process.pid}")
            return True
        except Exception as e:
            logger.error(f"Failed to start MCP server '{name}': {e}")
            return False

    def _create_process(self, config: Dict, use_pipes: bool) -> subprocess.Popen:
        """Create subprocess with appropriate pipe configuration.

        Args:
            config: Server configuration dict
            use_pipes: True for stdio transport (needs pipes), False for HTTP

        Returns:
            Started subprocess
        """
        env = os.environ.copy()
        env.update(config['env'])
        env['MCP_TRANSPORT'] = config['transport']

        if use_pipes:
            return subprocess.Popen(
                config['command'],
                cwd=config['cwd'],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.PIPE,
                bufsize=0
            )
        return subprocess.Popen(
            config['command'],
            cwd=config['cwd'],
            env=env,
            stdout=None,
            stderr=None,
            stdin=subprocess.DEVNULL
        )
    
    def start_all_servers(self) -> Dict[str, bool]:
        """Start all configured MCP servers.

        Returns:
            Dictionary mapping server names to start success status
        """
        return {name: self.start_server(name) for name in self._server_configs}
    
    def stop_server(self, name: str) -> bool:
        """Stop a specific MCP server.

        Args:
            name: Server identifier

        Returns:
            True if server stopped successfully, False otherwise
        """
        if name not in self._processes:
            logger.warning(f"MCP server '{name}' is not running")
            return False

        try:
            process = self._processes[name]
            process.terminate()

            try:
                process.wait(timeout=5)
                logger.info(f"MCP server '{name}' terminated gracefully")
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                logger.warning(f"MCP server '{name}' was force killed")

            del self._processes[name]
            return True
        except Exception as e:
            logger.error(f"Failed to stop MCP server '{name}': {e}")
            return False

    def stop_all_servers(self):
        """Stop all running MCP servers."""
        for name in list(self._processes.keys()):
            self.stop_server(name)

    def update_server_env(self, name: str, env_updates: Dict[str, str]):
        """Replace DATABASE_*_URL env vars and merge new ones into the stored config.

        Non-DATABASE env vars (e.g. ROOT_DIR) are preserved.

        Args:
            name: Server identifier
            env_updates: New environment variable key/value pairs to merge in
        """
        config = self._server_configs.get(name)
        if not config:
            logger.error(f"No configuration found for server: {name}")
            return

        old_env = config["env"]
        preserved = {k: v for k, v in old_env.items() if not k.startswith("DATABASE_") or not k.endswith("_URL")}
        config["env"] = {**preserved, **env_updates}
        logger.info(f"Updated env vars for server '{name}'")

    def restart_server(self, name: str) -> bool:
        """Stop (if running) then start a server with its current config.

        Thread-safe: uses an internal lock so concurrent callers are serialised.

        Args:
            name: Server identifier

        Returns:
            True if the server restarted successfully, False otherwise
        """
        with self._lock:
            logger.info(f"Restarting MCP server '{name}'")
            if name in self._processes and self._processes[name].poll() is None:
                self.stop_server(name)
            return self.start_server(name)

    def get_server_status(self, name: str) -> Optional[str]:
        """Get the status of a specific server.

        Args:
            name: Server identifier

        Returns:
            'running', 'stopped', or None if not configured
        """
        if name not in self._server_configs:
            return None

        if name not in self._processes:
            return 'stopped'

        return 'running' if self._processes[name].poll() is None else 'stopped'

    def get_all_server_status(self) -> Dict[str, Optional[str]]:
        """Get status of all configured servers.

        Returns:
            Dictionary mapping server names to their status
        """
        return {name: self.get_server_status(name) for name in self._server_configs}

    def get_server_port(self, name: str) -> Optional[int]:
        """Get the actual port a server is running on.

        Args:
            name: Server identifier

        Returns:
            Port number or None if not running/not applicable
        """
        return self._server_ports.get(name)

    def set_server_port(self, name: str, port: int):
        """Store the port a server is running on.

        Args:
            name: Server identifier
            port: Port number
        """
        self._server_ports[name] = port
    
    def get_server_logs(self, name: str) -> Dict[str, str]:
        """Get recent stdout/stderr logs from a server.

        Args:
            name: Server identifier

        Returns:
            Dictionary with 'stdout' and 'stderr' keys containing log output
        """
        if name not in self._processes:
            return {"stdout": "", "stderr": "", "error": "Server not running"}

        process = self._processes[name]
        logs = {"stdout": "", "stderr": ""}

        try:
            import select

            logs["stdout"] = self._read_stream(process.stdout, select)
            logs["stderr"] = self._read_stream(process.stderr, select)
        except Exception as e:
            logs["error"] = f"Error reading logs: {e}"

        return logs

    def _read_stream(self, stream, select_module) -> str:
        """Read from a stream non-blocking.

        Args:
            stream: File stream to read from
            select_module: The select module for Unix systems

        Returns:
            String content or error message
        """
        if not stream:
            return ""

        if hasattr(select_module, 'select'):
            if select_module.select([stream], [], [], 0)[0]:
                return stream.read(4096).decode('utf-8', errors='ignore')
            return ""

        try:
            return stream.read(4096).decode('utf-8', errors='ignore')
        except Exception:
            return "(Unable to read - pipe may be blocking)"


# Global instance
_mcp_server_manager: Optional[MCPServerManager] = None


def get_mcp_server_manager() -> MCPServerManager:
    """Get the global MCP server manager instance"""
    global _mcp_server_manager
    if _mcp_server_manager is None:
        _mcp_server_manager = MCPServerManager()
    return _mcp_server_manager


def configure_default_servers(workspace_dir: str):
    """Configure default MCP servers for SignalPilot AI.

    Parameters
    ----------
    workspace_dir : str
        Jupyter workspace root directory (server_app.root_dir).
    """
    manager = get_mcp_server_manager()
    signalpilot_ai_internal_dir = Path(__file__).parent

    # Configure signalpilot MCP server (HTTP transport)
    mcp_server_dir = signalpilot_ai_internal_dir.parent / "mcp_server"
    if mcp_server_dir.exists():
        db_env_vars = get_mcp_env_vars()

        # Find an available port
        try:
            port = find_available_port(MCP_DEFAULT_PORT, MCP_PORT_RANGE)
        except RuntimeError as e:
            logger.error(f"Failed to find available port for signalpilot-mcp: {e}")
            return

        env = {
            **db_env_vars,
            "ROOT_DIR": workspace_dir,
        }

        manager.add_server_config(
            name="signalpilot-mcp",
            command=["uv", "run", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", str(port)],
            cwd=str(mcp_server_dir),
            env=env,
            transport="http"
        )
        manager.set_server_port("signalpilot-mcp", port)
        logger.info(f"Configured signalpilot-mcp server at {mcp_server_dir} on port {port}")
    else:
        logger.warning(f"mcp_server directory not found at {mcp_server_dir}")

    # Configure dbt-mcp server
    dbt_mcp_dir = signalpilot_ai_internal_dir / "dbt-mcp"

    if dbt_mcp_dir.exists():
        # Use the Python executable that's running this process
        python_executable = sys.executable

        # Command to run dbt-mcp using the main module
        dbt_mcp_command = [
            python_executable,
            "-m",
            "dbt_mcp.main"
        ]

        manager.add_server_config(
            name="dbt-mcp",
            command=dbt_mcp_command,
            cwd=str(dbt_mcp_dir),
            env={},
            transport="stdio"
        )
        logger.info(f"Configured dbt-mcp server at {dbt_mcp_dir}")
    else:
        logger.warning(f"dbt-mcp directory not found at {dbt_mcp_dir}")


def autostart_mcp_servers(workspace_dir: str):
    """Automatically start all configured MCP servers.

    Parameters
    ----------
    workspace_dir : str
        Jupyter workspace root directory (server_app.root_dir).
    """
    configure_default_servers(workspace_dir)
    manager = get_mcp_server_manager()
    results = manager.start_all_servers()

    for name, success in results.items():
        if success:
            logger.info(f"✓ MCP server '{name}' started successfully")
        else:
            logger.error(f"✗ MCP server '{name}' failed to start")

    return results


def get_signalpilot_mcp_port() -> Optional[int]:
    """Get the port the signalpilot-mcp server is running on.

    Returns:
        Port number or None if not configured
    """
    manager = get_mcp_server_manager()
    return manager.get_server_port("signalpilot-mcp")


def get_signalpilot_mcp_url() -> Optional[str]:
    """Get the full URL for the signalpilot-mcp server.

    Returns:
        URL string or None if not configured
    """
    port = get_signalpilot_mcp_port()
    if port is None:
        return None
    return f"http://127.0.0.1:{port}/mcp"


def restart_signalpilot_mcp(event_loop=None):
    """Re-read DB env vars, restart the signalpilot-mcp subprocess, and reconnect
    the MCP service layer so the session is fresh.

    Args:
        event_loop: The asyncio event loop to schedule the async disconnect/connect
            on. When called from a background thread, pass the main thread's loop
            so that ``asyncio.run_coroutine_threadsafe`` can be used. If *None*,
            only the subprocess is restarted (the service layer is not reconnected).
    """
    manager = get_mcp_server_manager()
    if "signalpilot-mcp" not in manager._server_configs:
        logger.warning("signalpilot-mcp not configured; skipping restart")
        return

    # 1. Disconnect the MCP service connection (clears stale session)
    _reconnect_mcp_service(event_loop, disconnect_only=True)

    # 2. Update env vars and restart the subprocess
    fresh_env = get_mcp_env_vars()
    manager.update_server_env("signalpilot-mcp", fresh_env)
    success = manager.restart_server("signalpilot-mcp")

    if not success:
        logger.error("Failed to restart signalpilot-mcp")
        return

    logger.info("signalpilot-mcp subprocess restarted with updated DB env vars")

    # 3. Give uvicorn a moment to bind the port, then reconnect the service
    time.sleep(2)
    _reconnect_mcp_service(event_loop, disconnect_only=False)


def _reconnect_mcp_service(event_loop, disconnect_only=False):
    """Disconnect (and optionally reconnect) the MCPConnectionService entry.

    Uses ``asyncio.run_coroutine_threadsafe`` so this is safe to call from a
    background thread as long as *event_loop* is the main thread's running loop.
    """
    if event_loop is None:
        return

    # Import here to avoid circular imports at module level
    from signalpilot_ai_internal.mcp_service.service import get_mcp_service

    service = get_mcp_service()
    mcp_server_id = "signalpilot"  # built-in server id in MCPConnectionService

    try:
        future = asyncio.run_coroutine_threadsafe(
            service.disconnect(mcp_server_id), event_loop
        )
        future.result(timeout=10)
        logger.info("Disconnected MCP service connection (stale session cleared)")
    except Exception as e:
        logger.warning(f"MCP service disconnect failed (may not have been connected): {e}")

    if disconnect_only:
        return

    try:
        future = asyncio.run_coroutine_threadsafe(
            service.connect(mcp_server_id), event_loop
        )
        future.result(timeout=15)
        logger.info("MCP service reconnected to signalpilot-mcp with fresh session")
    except Exception as e:
        logger.error(f"MCP service reconnect failed: {e}")
