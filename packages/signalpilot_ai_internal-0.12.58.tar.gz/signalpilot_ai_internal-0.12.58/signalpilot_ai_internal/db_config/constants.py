"""Constants for database configuration."""

SUPPORTED_TYPES = ["snowflake", "postgres", "mysql", "databricks"]

TYPE_MAPPING_TO_BACKEND = {
    "postgresql": "postgres",
    "postgres": "postgres",
    "mysql": "mysql",
    "snowflake": "snowflake",
    "databricks": "databricks",
}

TYPE_MAPPING_TO_FRONTEND = {
    "postgres": "postgresql",
    "postgresql": "postgresql",
    "mysql": "mysql",
    "snowflake": "snowflake",
    "databricks": "databricks",
}

AUTH_TYPE_PAT = "pat"
AUTH_TYPE_SERVICE_PRINCIPAL = "service_principal"
TOKEN_REFRESH_BUFFER_SECONDS = 60
DEFAULT_DATABRICKS_SCOPES = ["2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default"]
