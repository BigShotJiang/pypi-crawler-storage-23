"""Base classes for database configurations."""
