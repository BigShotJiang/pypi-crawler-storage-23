try:
    from ._version import __version__
except ImportError:
    import warnings
    warnings.warn("Importing 'signalpilot_ai_internal' outside a proper installation.")
    __version__ = "dev"

import json
import os
import subprocess
import traceback
from pathlib import Path

from .handlers import setup_handlers
from .mcp_server_manager import autostart_mcp_servers
from .signalpilot_home import get_signalpilot_home
from signalpilot_ai_internal.db_config.factory import build_kernel_env, normalize_db_name


def _get_database_env_vars():
    """Build environment variables dictionary from database configurations."""
    env_vars = {}
    try:
        home = get_signalpilot_home()
        for config in home.get_database_configs():
            db_name = config.get('name', '')
            if not db_name:
                continue
            prefix = normalize_db_name(db_name)
            env_vars.update(build_kernel_env(config, prefix))
    except Exception:
        pass
    return env_vars


def _setup_kernel_env_injection(server_app):
    """
    Hook into the kernel provisioner to inject database env vars at kernel start.

    This monkey-patches the LocalProvisioner's pre_launch method which is called
    before every kernel process launch, including restarts.
    """
    log = server_app.log

    try:
        from jupyter_client.provisioning import LocalProvisioner

        # Check if already patched
        if hasattr(LocalProvisioner, '_signalpilot_patched'):
            log.info("[signalpilot_ai_internal] LocalProvisioner already patched")
            return

        # Store the original method
        original_pre_launch = LocalProvisioner.pre_launch

        async def patched_pre_launch(self, **kwargs):
            """Wrapper that injects database env vars before launching kernel process."""
            # Get database env vars
            db_env_vars = _get_database_env_vars()

            if db_env_vars:
                # Get or create the env dict
                env = kwargs.get('env')
                if env is None:
                    env = os.environ.copy()
                else:
                    env = dict(env)

                # Inject database env vars
                env.update(db_env_vars)
                kwargs['env'] = env

            # Call original method
            return await original_pre_launch(self, **kwargs)

        # Patch at class level
        LocalProvisioner.pre_launch = patched_pre_launch
        LocalProvisioner._signalpilot_patched = True

        log.info("[signalpilot_ai_internal] Kernel env injection hook installed on LocalProvisioner.pre_launch")

    except Exception as e:
        log.warning(f"[signalpilot_ai_internal] Could not install kernel env injection hook: {e}")
        log.warning(traceback.format_exc())
        log.warning("[signalpilot_ai_internal] Database env vars will be set at runtime instead")


def _configure_kernel_env_vars(log):
    """
    Configure kernel specs with database environment variables.

    This directly adds env vars to kernel.json's 'env' field, which is
    simpler and more reliable than using a custom provisioner.
    """
    try:
        # Get database env vars
        db_env_vars = _get_database_env_vars()

        if not db_env_vars:
            log.info("[signalpilot_ai_internal] No database configurations found, skipping kernel env setup")
            return

        log.info(f"[signalpilot_ai_internal] Found {len(db_env_vars)} database env vars to inject")

        # Get list of kernel specs
        result = subprocess.run(
            ['jupyter', 'kernelspec', 'list', '--json'],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            log.warning(f"[signalpilot_ai_internal] Could not list kernel specs: {result.stderr}")
            return

        specs = json.loads(result.stdout)

        for name, info in specs.get('kernelspecs', {}).items():
            kernel_json_path = Path(info['resource_dir']) / 'kernel.json'

            if not kernel_json_path.exists():
                continue

            try:
                with open(kernel_json_path, 'r') as f:
                    kernel_json = json.load(f)

                # Get or create env dict
                if 'env' not in kernel_json:
                    kernel_json['env'] = {}

                # Check if env vars are already set (compare a sample key)
                sample_key = list(db_env_vars.keys())[0] if db_env_vars else None
                if sample_key and kernel_json['env'].get(sample_key) == db_env_vars.get(sample_key):
                    log.info(f"[signalpilot_ai_internal] Kernel '{name}' env vars already up to date")
                    continue

                # Add database env vars
                kernel_json['env'].update(db_env_vars)

                # Try to write back
                try:
                    with open(kernel_json_path, 'w') as f:
                        json.dump(kernel_json, f, indent=2)
                    log.info(f"[signalpilot_ai_internal] Updated kernel '{name}' with database env vars")

                except PermissionError:
                    log.warning(
                        f"[signalpilot_ai_internal] No permission to modify kernel '{name}'. "
                        "Database env vars will be set at runtime instead."
                    )

            except Exception as e:
                log.warning(f"[signalpilot_ai_internal] Could not configure kernel '{name}': {e}")

    except Exception as e:
        log.warning(f"[signalpilot_ai_internal] Error configuring kernel env vars: {e}")


def _jupyter_labextension_paths():
    return [{
        "src": "labextension",
        "dest": "signalpilot-ai-internal"
    }]


def _jupyter_server_extension_points():
    return [{
        "module": "signalpilot_ai_internal"
    }]


def _load_jupyter_server_extension(server_app):
    """Registers the API handler to receive HTTP requests from the frontend extension.

    Parameters
    ----------
    server_app: jupyterlab.labapp.LabApp
        JupyterLab application instance
    """
    setup_handlers(server_app.web_app)
    name = "signalpilot_ai_internal"
    server_app.log.info(f"Registered {name} server extension")

    # Hook into kernel manager to inject database env vars at kernel start
    _setup_kernel_env_injection(server_app)

    # Auto-start configured MCP servers (like signalpilot-mcp)
    try:
        autostart_mcp_servers(server_app.root_dir)
        server_app.log.info("MCP servers auto-start completed")
    except Exception as e:
        server_app.log.warning(f"Failed to auto-start MCP servers: {e}")
