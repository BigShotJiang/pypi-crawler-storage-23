# Sage Agent Complete UI Redesign Plan

> **Aggressive Timeline** | Total: ~18 days | Team: Fast-moving

---

## Executive Summary

Complete redesign of Sage Agent JupyterLab extension covering 81 existing widgets and integrating modern JupyterLab 4.x patterns.

---

## Phase 1: Foundation & Architecture (3 days)

### 1.1 Design System Setup (1 day)
- [ ] Create design tokens (colors, spacing, typography, shadows)
- [ ] Implement CSS custom properties for theming
- [ ] Set up dark/light theme variables synced with JupyterLab
- [ ] Create component documentation template
- [ ] Define animation/transition standards

### 1.2 State Management Refactor (1 day)
- [ ] Audit current Zustand stores for redundancy
- [ ] Implement proper Provider-Consumer pattern per JupyterLab guidelines
- [ ] Create shared token exports for service swapping
- [ ] Add proper TypeScript interfaces for all state shapes
- [ ] Implement IDisposable pattern for cleanup

### 1.3 Component Architecture (1 day)
- [ ] Set up component library structure
- [ ] Create shared hooks library
- [ ] Implement ContentFactory pattern for customizable widgets
- [ ] Set up proper message/signal communication patterns
- [ ] Create test harness for components

---

## Phase 2: Core Chat Interface (4 days)

### 2.1 ChatBox Container Redesign (0.5 days)
- [ ] `ChatBox` - Modernize root container with proper portal management
- [ ] Implement responsive layout system
- [ ] Add proper loading state animations
- [ ] Integrate with JupyterLab shell areas

### 2.2 Header & Navigation (0.5 days)
- [ ] `ChatToolbar` - Redesign with JupyterLab toolbar patterns
- [ ] `ThreadBanner` - Improve slide-out animation, add search
- [ ] `MoreOptionsPopover` - Convert to JupyterLab menu pattern
- [ ] Add keyboard navigation (Cmd+K style command palette)

### 2.3 Message Components (1.5 days)
- [ ] `AssistantMessage` - Improve markdown rendering, add reactions
- [ ] `StreamingMessage` - Optimize re-renders, smoother cursor animation
- [ ] `UserMessage` - Add edit capability, improve context display
- [ ] `ThinkingIndicator` - More engaging animation
- [ ] `LoadingIndicator` - Consistent with JupyterLab loading patterns
- [ ] `ErrorMessage` - Better error formatting, retry actions
- [ ] `SystemMessage` - Cleaner visual hierarchy
- [ ] `ToolCallDisplay` - Collapsible, better parameter display
- [ ] `ToolResultMessage` - Syntax highlighted outputs
- [ ] `WaitingUserReplyBox` - Smarter prompt suggestions

### 2.4 Authentication & Subscription (0.5 days)
- [ ] `AuthenticationCard` - Modern OAuth flow UI
- [ ] `SubscriptionCard` - Cleaner upgrade CTA
- [ ] `SessionTimerBanner` - Less intrusive design
- [ ] `TrialBanner` - Dismissible with persistence

### 2.5 Message List & History (1 day)
- [ ] `ChatMessagesPanel` - Virtual scrolling for performance
- [ ] `MessageList` - Optimized rendering with windowing
- [ ] `ChatBoxContent` - Smooth auto-scroll behavior
- [ ] `HistoryContainer` - Better history navigation
- [ ] Checkpoint restoration UI improvements
- [ ] Add message search functionality

---

## Phase 3: Input System (2 days)

### 3.1 Rich Text Input (1 day)
- [ ] `ChatInputContainer` - Responsive layout, better spacing
- [ ] `RichTextInput` - Improve contentEditable stability
- [ ] Add proper markdown preview mode
- [ ] Implement slash commands (`/` triggers)
- [ ] Better multi-line editing experience
- [ ] Add voice input option (stretch goal)

### 3.2 Context & Mentions (0.5 days)
- [ ] `MentionDropdown` - Faster rendering, fuzzy search
- [ ] `ContextRow` - Better visual for selected contexts
- [ ] `ContextItem` - Richer previews
- [ ] `CategoryItem` - Better icons and counts
- [ ] `SearchInput` - Debounced search
- [ ] Add recent mentions quick-access

### 3.3 Controls (0.5 days)
- [ ] `SendButton` - Better states (loading, disabled, cancel)
- [ ] `TokenProgressIndicator` - Cleaner progress visualization
- [ ] `ModeSelector` - Dropdown with descriptions
- [ ] Add keyboard shortcut hints

---

## Phase 4: Diff & Code Review (2 days)

### 4.1 Diff Visualization (1 day)
- [ ] `DiffMergeView` - Upgrade CodeMirror integration
- [ ] Add inline diff mode (not just split view)
- [ ] Syntax highlighting for all languages
- [ ] Line-by-line approval option
- [ ] Better collapse/expand for unchanged sections

### 4.2 Approval Workflow (1 day)
- [ ] `ActiveDiffApprovalDialog` - Cleaner action buttons
- [ ] `DiffCellItem` - Better cell metadata display
- [ ] `DiffActionButtons` - Confirmation for bulk actions
- [ ] `DiffApprovalMessage` - Inline in chat vs modal option
- [ ] `HistoricalDiffList` - Better history browsing
- [ ] `HistoricalDiffCell` - Timestamp and user context
- [ ] Add diff annotations/comments

---

## Phase 5: Plan & State Display (1 day)

### 5.1 Plan Execution UI (0.5 days)
- [ ] `PlanStateDisplay` - Better step visualization
- [ ] Animated progress indicators per step
- [ ] Collapsible nested task structure
- [ ] Add step timing information
- [ ] Error state per step with retry

### 5.2 Demo & Debug (0.5 days)
- [ ] `DemoControlPanel` - Cleaner replay controls
- [ ] `DemoOverlay` - Less intrusive
- [ ] `ReplayLoadingOverlay` - Progress indication
- [ ] Add recording indicator

---

## Phase 6: Settings & Configuration (1.5 days)

### 6.1 Settings Panel (0.5 days)
- [ ] `SettingsWidget` - Organized sections with search
- [ ] Better toggle/checkbox styling
- [ ] Add settings sync indicator
- [ ] Keyboard shortcut customization
- [ ] Export/import settings

### 6.2 Database Configuration (0.5 days)
- [ ] `DatabaseCreationModal` - Wizard-style flow
- [ ] `DatabaseManagerWidget` - Better schema browser
- [ ] `SnowflakeSchemaViewer` - Tree view improvements
- [ ] Connection testing with detailed feedback
- [ ] Add connection profiles/favorites

### 6.3 MCP Integration (0.5 days)
- [ ] `MCPManagerWidget` - Cleaner server list
- [ ] `MCPConnectionCard` - Status badges
- [ ] `IntegrationCard` - One-click setup
- [ ] Add MCP capability browser

---

## Phase 7: JupyterLab Native Integration (2 days)

### 7.1 Shell Integration (0.5 days)
- [ ] Proper sidebar panel registration
- [ ] Right sidebar option
- [ ] Floating/detached mode
- [ ] Split view with notebook
- [ ] Status bar integration

### 7.2 Notebook Integration (1 day)
- [ ] `NotebookChatContainer` - Better embedding
- [ ] Cell toolbar integration (JupyterLab native)
- [ ] Cell context menu items
- [ ] Inline cell comments/annotations
- [ ] Better cell highlighting for context
- [ ] Output area integration

### 7.3 Command Palette & Shortcuts (0.5 days)
- [ ] Register all commands with `package:verb-noun` format
- [ ] Add keyboard shortcut bindings
- [ ] Integrate with JupyterLab command palette
- [ ] Add contextual commands per cell type

---

## Phase 8: Utility Components (1 day)

### 8.1 Common Components (0.5 days)
- [ ] `ModernSpinner` - Consistent sizing variants
- [ ] `StatusBall` - Standardize status colors
- [ ] `JsonHighlight` - Better collapse/expand
- [ ] `CollapsibleSection` - Animation improvements
- [ ] `CellIdLabel` - Better click targets
- [ ] `TerminalOutputDisplay` - Proper ANSI support

### 8.2 Dialogs & Modals (0.5 days)
- [ ] `ConfirmationDialog` - JupyterLab dialog patterns
- [ ] `CheckpointRestorationModal` - Preview before restore
- [ ] `CodeConfirmationDialog` - Syntax highlighted preview
- [ ] `RejectionFeedbackDialog` - Quick feedback options
- [ ] `JWTAuthModal` - Better token handling
- [ ] `FirstRunModal` - Engaging onboarding
- [ ] `LoginSuccessModal` / `LoginSuccessToast` - Consistent feedback

---

## Phase 9: File & Data Management (1 day)

### 9.1 File Explorer (0.5 days)
- [ ] `FileExplorerWidget` - JupyterLab file browser integration
- [ ] `FolderItem` - Better icons, drag-drop support
- [ ] Add file preview on hover
- [ ] Search within files

### 9.2 Data Tools (0.5 days)
- [ ] `HTMLPreviewWidget` - Better sandboxing
- [ ] `InlineCompletionWidget` - VS Code style completions
- [ ] `NotebookDeploymentButton` - Cleaner share options

---

## Phase 10: Performance & Polish (0.5 days)

### 10.1 Performance
- [ ] Implement React.memo for expensive components
- [ ] Add virtualization to all lists
- [ ] Optimize re-renders with proper deps
- [ ] Lazy load non-critical components
- [ ] Bundle size optimization

### 10.2 Accessibility
- [ ] ARIA labels on all interactive elements
- [ ] Keyboard navigation throughout
- [ ] Focus management
- [ ] Screen reader testing
- [ ] Color contrast compliance

### 10.3 Final Polish
- [ ] Consistent animation curves
- [ ] Loading state skeletons
- [ ] Empty state illustrations
- [ ] Error boundary UI
- [ ] Responsive breakpoints

---

## JupyterLab Features Integration Checklist

### Native JupyterLab Features to Leverage
- [ ] **LabIcon** - Use 80+ built-in icons, create custom with theme sync
- [ ] **Toolbar** - Use native toolbar widget patterns
- [ ] **Command Registry** - Proper command registration
- [ ] **Settings Registry** - User preferences integration
- [ ] **Theme System** - Full dark/light theme support
- [ ] **Shell Areas** - Left sidebar, right sidebar, main area, down area
- [ ] **Document Registry** - File type associations
- [ ] **State Database** - Persist UI state across sessions
- [ ] **Notification System** - Use JupyterLab notifications
- [ ] **Dialog Service** - Native dialogs where appropriate
- [ ] **Status Bar** - Add status items

### Modern JupyterLab 4.x Features
- [ ] **Cell Toolbar** - Native cell toolbar extension
- [ ] **Real-time Collaboration** - RTC support readiness
- [ ] **Virtual Notebook** - contentVisibility windowing mode
- [ ] **Improved Accessibility** - WCAG compliance
- [ ] **Mobile Support** - Touch-friendly interactions
- [ ] **Custom CSS** - User stylesheet support

---

## Timeline Summary

| Phase | Description | Duration |
|-------|-------------|----------|
| 1 | Foundation & Architecture | 3 days |
| 2 | Core Chat Interface | 4 days |
| 3 | Input System | 2 days |
| 4 | Diff & Code Review | 2 days |
| 5 | Plan & State Display | 1 day |
| 6 | Settings & Configuration | 1.5 days |
| 7 | JupyterLab Native Integration | 2 days |
| 8 | Utility Components | 1 day |
| 9 | File & Data Management | 1 day |
| 10 | Performance & Polish | 0.5 days |
| **Total** | | **18 days** |

---

## Component Inventory (81 Total)

### Chat Interface (35)
1. ChatBox
2. ChatToolbar
3. ThreadBanner
4. MoreOptionsPopover
5. ChatBoxContent
6. ChatMessagesPanel
7. AssistantMessage
8. StreamingMessage
9. UserMessage
10. LoadingIndicator
11. ThinkingIndicator
12. AuthenticationCard
13. SubscriptionCard
14. ToolCallDisplay
15. ToolResultMessage
16. SystemMessage
17. ErrorMessage
18. WaitingUserReplyBox
19. MessageList
20. NewChatDisplay
21. HistoryContainer
22. NewPromptCTA
23. UpdateBanner
24. LoadingOverlay
25. PlanStateDisplay
26. DemoControlPanel
27. MCPToolDisplay
28. TerminalOutputDisplay
29. ToolSearchDisplay
30. JsonHighlight
31. CellIdLabel
32. CollapsibleSection
33. CategoryHeader
34. Separator
35. SearchInput (MentionDropdown)

### Input & Context (14)
36. ChatInputContainer
37. RichTextInput
38. MentionDropdown
39. ContextRow
40. SendButton
41. TokenProgressIndicator
42. ModeSelector
43. ContextItem
44. CategoryItem
45. LoadingIndicator (Mention)
46. NotebookChatContainer
47. NotebookDeploymentButton

### Diff & Code Review (7)
48. ActiveDiffApprovalDialog
49. DiffCellItem
50. DiffMergeView
51. DiffActionButtons
52. DiffApprovalMessage
53. HistoricalDiffList
54. HistoricalDiffCell

### Settings & Config (4)
55. SettingsWidget
56. DatabaseCreationModal
57. NotebookSettingsContainer
58. SnowflakeSchemaViewer

### MCP & Integration (3)
59. MCPManagerWidget
60. MCPConnectionCard
61. IntegrationCard

### Special Features (8)
62. SessionTimerBanner
63. TrialBanner
64. LoginSuccessModal
65. LoginSuccessToast
66. JWTAuthModal
67. FirstRunModal
68. WelcomeComponent
69. HTMLPreviewWidget

### Helper & Utility (9)
70. ModernSpinner
71. StatusBall
72. InlineCompletionWidget
73. DemoOverlay
74. ReplayLoadingOverlay
75. FileExplorerWidget
76. FolderItem
77. DatabaseManagerWidget
78. ConfirmationDialog

### Dialogs (3)
79. CheckpointRestorationModal
80. CodeConfirmationDialog
81. RejectionFeedbackDialog

---

## References

- [JupyterLab UI Components](https://jupyterlab.readthedocs.io/en/latest/extension/ui_components.html)
- [JupyterLab Design Patterns](https://jupyterlab.readthedocs.io/en/stable/developer/patterns.html)
- [JupyterLab Interface Guide](https://jupyterlab.readthedocs.io/en/stable/user/interface.html)
- [JupyterLab Extension Development](https://jupyterlab.readthedocs.io/en/stable/extension/extension_dev.html)
- [JupyterLab Changelog](https://jupyterlab.readthedocs.io/en/stable/getting_started/changelog.html)
- [Jupyter UI Toolkit](https://github.com/jupyterlab-contrib/jupyter-ui-toolkit)
- [best-of-jupyter Extensions](https://github.com/ml-tooling/best-of-jupyter)
