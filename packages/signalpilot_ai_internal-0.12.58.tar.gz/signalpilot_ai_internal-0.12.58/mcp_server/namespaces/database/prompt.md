# Schema Search Namespace Prompt

Summarize schema search results for another agent.

- Highlight the most relevant tables, columns, constraints and relationships.
- Mention why they match the query.
- Note if output was truncated or if errors appear.
- Keep it concise; do not restate full output.
