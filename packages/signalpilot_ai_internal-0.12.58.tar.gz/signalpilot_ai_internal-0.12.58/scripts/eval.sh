#!/bin/zsh
set -e

SCRIPT_DIR="$(cd "$(dirname "${0}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
UI_TESTS_DIR="$PROJECT_DIR/ui-tests"

CONDA_ENV="signaldev"
HEADED_FLAG=""
WORKERS=3
NOTEBOOKS=""

# Parse arguments
for arg in "$@"; do
    case $arg in
        --headed)
            HEADED_FLAG="--headed"
            echo "Running in headed mode (browser visible)"
            ;;
        --env=*)
            CONDA_ENV="${arg#*=}"
            ;;
        --workers=*)
            WORKERS="${arg#*=}"
            ;;
        --notebooks=*)
            NOTEBOOKS="${arg#*=}"
            ;;
    esac
done

# Build grep pattern for notebook filtering
GREP_FLAG=""
if [ -n "$NOTEBOOKS" ]; then
    # Convert comma-separated list to regex pattern: "8,9,10" -> "usecase-8|usecase-9|usecase-10"
    GREP_PATTERN=$(echo "$NOTEBOOKS" | sed 's/,/|usecase-/g' | sed 's/^/usecase-/')
    GREP_FLAG="--grep=\"$GREP_PATTERN\""
    echo "Filtering to notebooks: $NOTEBOOKS"
fi

REPO_ROOT="$(dirname "$PROJECT_DIR")"
ENV_FILE="$REPO_ROOT/.env.eval"

# Initialize conda for zsh and activate
source ~/opt/miniconda3/etc/profile.d/conda.sh
conda activate "$CONDA_ENV"

# Load JWT token from .env.eval file
if [ -f "$ENV_FILE" ]; then
    echo "Loading JWT token from $ENV_FILE"
    export $(grep -v '^#' "$ENV_FILE" | xargs)
fi

# Verify token is set
if [ -z "$SAGE_JWT_TOKEN" ]; then
    echo "ERROR: SAGE_JWT_TOKEN not found"
    echo "Create .env.eval in repo root with: SAGE_JWT_TOKEN=your_token"
    exit 1
fi

# Run eval tests with parallel workers
# CRITICAL: -x flag stops on first failure - DO NOT REMOVE THIS FLAG UNDER ANY CIRCUMSTANCES
echo "Running eval suite ($WORKERS notebooks in parallel) with conda env: $CONDA_ENV"
cd "$UI_TESTS_DIR"
eval npx playwright test --project=eval -x --workers=$WORKERS $HEADED_FLAG $GREP_FLAG

echo "Done! Notebooks saved to tests/eval/notebooks/"
