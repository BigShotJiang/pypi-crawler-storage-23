import React, {
  useCallback,
  useState,
  useRef,
  useEffect,
  useMemo,
  ReactNode
} from 'react';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { NotebookPanel, NotebookActions } from '@jupyterlab/notebook';
import { useToolbarState } from './useToolbarState';
import { CellTypeDropdown } from './CellTypeDropdown';
import {
  SaveIcon,
  AddCellIcon,
  CutIcon,
  CopyIcon,
  PasteIcon,
  RunIcon,
  StopIcon,
  RestartIcon,
  RestartRunAllIcon,
  BugIcon,
  EllipsisIcon,
  PreviewIcon,
  ReportIcon
} from './ToolbarIcons';

interface SPToolbarProps {
  panel: NotebookPanel;
  app: JupyterFrontEnd;
}

const STATUS_COLORS: Record<string, string> = {
  idle: 'var(--sp-chart-green, #4ca86f)',
  busy: 'var(--sp-chart-yellow, #fec163)',
  starting: 'var(--sp-chart-blue, #73acfb)',
  restarting: 'var(--sp-chart-blue, #73acfb)',
  dead: 'var(--sp-error, #f04438)',
  unknown: 'var(--sp-text-input-default, #a4a7ae)'
};

/** Item definition for the progressive collapse system */
interface ToolbarItem {
  key: string;
  group: 'left' | 'right';
  inline: () => ReactNode;
  overflow: () => ReactNode;
}

/**
 * Width breakpoints for progressive collapse.
 * Each entry is a width threshold. When the toolbar is narrower than
 * threshold[i], item at index (items.length - 1 - i) from the END is hidden.
 * Items collapse right-to-left (rightmost first).
 */
const COLLAPSE_THRESHOLDS = [
  850, // kernel name
  780, // debugger
  700, // build report
  620, // preview
  550, // cell type dropdown
  490, // restart+run-all
  440, // restart
  390, // stop
  350, // paste
  310, // copy
  280 // cut
];

export const SPToolbar: React.FC<SPToolbarProps> = ({ panel, app }) => {
  const { kernelName, kernelStatus, cellType } = useToolbarState(panel);
  const [toolbarWidth, setToolbarWidth] = useState(9999);
  const [overflowOpen, setOverflowOpen] = useState(false);
  const toolbarRef = useRef<HTMLDivElement>(null);
  const overflowRef = useRef<HTMLDivElement>(null);

  // Track toolbar width
  useEffect(() => {
    const el = toolbarRef.current;
    if (!el) return;
    const observer = new ResizeObserver(entries => {
      for (const entry of entries) {
        setToolbarWidth(entry.contentRect.width);
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Close overflow on outside click
  useEffect(() => {
    if (!overflowOpen) return;
    const handler = (e: MouseEvent) => {
      if (
        overflowRef.current &&
        !overflowRef.current.contains(e.target as Node)
      ) {
        setOverflowOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [overflowOpen]);

  const exec = useCallback(
    (commandId: string) => {
      if (app.commands.hasCommand(commandId)) {
        void app.commands.execute(commandId);
      } else {
        console.warn(`[SPToolbar] Command not registered: ${commandId}`);
      }
    },
    [app]
  );

  const handleSave = useCallback(() => exec('docmanager:save'), [exec]);
  const handleInsertCell = useCallback(
    () => NotebookActions.insertBelow(panel.content),
    [panel]
  );
  const handleCut = useCallback(
    () => NotebookActions.cut(panel.content),
    [panel]
  );
  const handleCopy = useCallback(
    () => NotebookActions.copy(panel.content),
    [panel]
  );
  const handlePaste = useCallback(
    () => NotebookActions.paste(panel.content),
    [panel]
  );
  const handleRun = useCallback(
    () =>
      void NotebookActions.runAndAdvance(panel.content, panel.sessionContext),
    [panel]
  );
  const handleStop = useCallback(
    () => void panel.sessionContext.session?.kernel?.interrupt(),
    [panel]
  );
  const handleRestart = useCallback(
    () => exec('kernelmenu:restart'),
    [exec]
  );
  const handleRestartRunAll = useCallback(
    () => exec('notebook:restart-run-all'),
    [exec]
  );
  const handleDebugger = useCallback(
    () => exec('debugger:show-panel'),
    [exec]
  );
  const handleKernelSelect = useCallback(() => {
    if (app.commands.hasCommand('notebook:change-kernel')) {
      void app.commands.execute('notebook:change-kernel');
    }
  }, [app]);
  const handlePreviewSnapshot = useCallback(
    () => exec('signalpilot-ai-internal:export-notebook-html'),
    [exec]
  );
  const handleBuildReport = useCallback(
    () => exec('signalpilot-ai-internal:publish-report'),
    [exec]
  );

  const statusColor =
    STATUS_COLORS[kernelStatus] || STATUS_COLORS['unknown'];

  // All items in display order (left to right).
  // The LAST item collapses FIRST (rightmost → leftmost).
  const items: ToolbarItem[] = useMemo(
    () => [
      // --- Left group ---
      {
        key: 'save',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleSave}
            title="Save (Ctrl+S)"
          >
            <SaveIcon />
          </button>
        ),
        overflow: () => (
          <button className="sp-toolbar-overflow-item" onClick={handleSave}>
            <span className="sp-toolbar-overflow-item-icon">
              <SaveIcon size={14} />
            </span>
            <span>Save</span>
          </button>
        )
      },
      {
        key: 'insert',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleInsertCell}
            title="Insert Cell Below"
          >
            <AddCellIcon />
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handleInsertCell}
          >
            <span className="sp-toolbar-overflow-item-icon">
              <AddCellIcon size={14} />
            </span>
            <span>Insert Cell</span>
          </button>
        )
      },
      {
        key: 'cut',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleCut}
            title="Cut Cell"
          >
            <CutIcon />
          </button>
        ),
        overflow: () => (
          <button className="sp-toolbar-overflow-item" onClick={handleCut}>
            <span className="sp-toolbar-overflow-item-icon">
              <CutIcon size={14} />
            </span>
            <span>Cut</span>
          </button>
        )
      },
      {
        key: 'copy',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleCopy}
            title="Copy Cell"
          >
            <CopyIcon />
          </button>
        ),
        overflow: () => (
          <button className="sp-toolbar-overflow-item" onClick={handleCopy}>
            <span className="sp-toolbar-overflow-item-icon">
              <CopyIcon size={14} />
            </span>
            <span>Copy</span>
          </button>
        )
      },
      {
        key: 'paste',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handlePaste}
            title="Paste Cell"
          >
            <PasteIcon />
          </button>
        ),
        overflow: () => (
          <button className="sp-toolbar-overflow-item" onClick={handlePaste}>
            <span className="sp-toolbar-overflow-item-icon">
              <PasteIcon size={14} />
            </span>
            <span>Paste</span>
          </button>
        )
      },
      {
        key: 'run',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleRun}
            title="Run Cell (Shift+Enter)"
          >
            <RunIcon />
          </button>
        ),
        overflow: () => (
          <button className="sp-toolbar-overflow-item" onClick={handleRun}>
            <span className="sp-toolbar-overflow-item-icon">
              <RunIcon size={14} />
            </span>
            <span>Run</span>
          </button>
        )
      },
      {
        key: 'stop',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleStop}
            title="Interrupt Kernel"
          >
            <StopIcon />
          </button>
        ),
        overflow: () => (
          <button className="sp-toolbar-overflow-item" onClick={handleStop}>
            <span className="sp-toolbar-overflow-item-icon">
              <StopIcon size={14} />
            </span>
            <span>Stop</span>
          </button>
        )
      },
      {
        key: 'restart',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleRestart}
            title="Restart Kernel"
          >
            <RestartIcon />
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handleRestart}
          >
            <span className="sp-toolbar-overflow-item-icon">
              <RestartIcon size={14} />
            </span>
            <span>Restart Kernel</span>
          </button>
        )
      },
      {
        key: 'restartRunAll',
        group: 'left',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleRestartRunAll}
            title="Restart Kernel & Run All"
          >
            <RestartRunAllIcon />
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handleRestartRunAll}
          >
            <span className="sp-toolbar-overflow-item-icon">
              <RestartRunAllIcon size={14} />
            </span>
            <span>Restart & Run All</span>
          </button>
        )
      },
      {
        key: 'cellType',
        group: 'left',
        inline: () => (
          <CellTypeDropdown panel={panel} cellType={cellType} />
        ),
        overflow: () => (
          <CellTypeDropdown panel={panel} cellType={cellType} />
        )
      },
      // --- Right group ---
      {
        key: 'preview',
        group: 'right',
        inline: () => (
          <button
            className="sp-toolbar-action-btn"
            onClick={handlePreviewSnapshot}
            title="Preview Snapshot"
          >
            <PreviewIcon size={14} />
            <span>Preview</span>
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handlePreviewSnapshot}
          >
            <span className="sp-toolbar-overflow-item-icon">
              <PreviewIcon size={14} />
            </span>
            <span>Preview Snapshot</span>
          </button>
        )
      },
      {
        key: 'report',
        group: 'right',
        inline: () => (
          <button
            className="sp-toolbar-action-btn"
            onClick={handleBuildReport}
            title="Build AI Report"
          >
            <ReportIcon size={14} />
            <span>Build Report</span>
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handleBuildReport}
          >
            <span className="sp-toolbar-overflow-item-icon">
              <ReportIcon size={14} />
            </span>
            <span>Build AI Report</span>
          </button>
        )
      },
      {
        key: 'debugger',
        group: 'right',
        inline: () => (
          <button
            className="sp-toolbar-btn"
            onClick={handleDebugger}
            title="Debugger Panel (Ctrl+Shift+E)"
          >
            <BugIcon />
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handleDebugger}
          >
            <span className="sp-toolbar-overflow-item-icon">
              <BugIcon size={14} />
            </span>
            <span>Debugger</span>
          </button>
        )
      },
      {
        key: 'kernel',
        group: 'right',
        inline: () => (
          <button
            className="sp-toolbar-kernel"
            onClick={handleKernelSelect}
            title={`Kernel: ${kernelStatus} — Click to change`}
          >
            <span
              className="sp-toolbar-kernel-dot"
              style={{ backgroundColor: statusColor }}
            />
            <span className="sp-toolbar-kernel-name">{kernelName}</span>
          </button>
        ),
        overflow: () => (
          <button
            className="sp-toolbar-overflow-item"
            onClick={handleKernelSelect}
          >
            <span
              className="sp-toolbar-kernel-dot"
              style={{ backgroundColor: statusColor }}
            />
            <span>{kernelName}</span>
          </button>
        )
      }
    ],
    [
      handleSave,
      handleInsertCell,
      handleCut,
      handleCopy,
      handlePaste,
      handleRun,
      handleStop,
      handleRestart,
      handleRestartRunAll,
      handleDebugger,
      handleKernelSelect,
      handlePreviewSnapshot,
      handleBuildReport,
      panel,
      cellType,
      kernelName,
      kernelStatus,
      statusColor
    ]
  );

  // Compute how many items are hidden (from the right end)
  const hiddenCount = useMemo(() => {
    let count = 0;
    for (const threshold of COLLAPSE_THRESHOLDS) {
      if (toolbarWidth < threshold) {
        count++;
      } else {
        break;
      }
    }
    return count;
  }, [toolbarWidth]);

  const visibleItems = items.slice(0, items.length - hiddenCount);
  const hiddenItems = items.slice(items.length - hiddenCount);

  const leftVisible = visibleItems.filter(i => i.group === 'left');
  const rightVisible = visibleItems.filter(i => i.group === 'right');
  const hasOverflow = hiddenItems.length > 0;

  return (
    <div className="sp-toolbar" ref={toolbarRef}>
      {/* Left group */}
      <div className="sp-toolbar-group">
        <div className="sp-toolbar-icons">
          {leftVisible.map(item => (
            <React.Fragment key={item.key}>
              {item.inline()}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Right group + overflow */}
      <div className="sp-toolbar-group">
        {rightVisible.length > 0 && (
          <div className="sp-toolbar-action-group">
            {rightVisible.map(item => (
              <React.Fragment key={item.key}>
                {item.inline()}
              </React.Fragment>
            ))}
          </div>
        )}
        {hasOverflow && (
          <div className="sp-toolbar-overflow-container" ref={overflowRef}>
            <button
              className="sp-toolbar-btn"
              onClick={() => setOverflowOpen(!overflowOpen)}
              title="More actions"
            >
              <EllipsisIcon />
            </button>
            {overflowOpen && (
              <div className="sp-toolbar-overflow-popover">
                {hiddenItems.map(item => (
                  <div
                    key={item.key}
                    onClick={() => setOverflowOpen(false)}
                  >
                    {item.overflow()}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
