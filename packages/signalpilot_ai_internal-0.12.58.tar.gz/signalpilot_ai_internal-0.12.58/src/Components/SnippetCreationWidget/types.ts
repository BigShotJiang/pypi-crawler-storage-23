import { ISnippet, RuleMode } from '../../stores/snippetStore';

/**
 * Interface for the SnippetCreation state
 */
export interface ISnippetCreationState {
  isVisible: boolean;
  snippets: ISnippet[];
  isCreating: boolean;
  editingSnippet: ISnippet | null;
  viewingSnippet: ISnippet | null;
  title: string;
  description: string;
  content: string;
  mode: RuleMode;
}

/**
 * Props for the main SnippetCreationContent component
 */
export interface ISnippetCreationContentProps {
  state: ISnippetCreationState;
  onCreateNew: () => void;
  onSave: () => void;
  onEdit: (snippet: ISnippet) => void;
  onView: (snippet: ISnippet) => void;
  onDelete: (snippetFilename: string) => void;
  onDuplicate: (snippet: ISnippet) => void;
  onClose: () => void;
  onEnable: (snippet: ISnippet) => void;
  onTitleChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onContentChange: (value: string) => void;
  onModeChange: (mode: RuleMode) => void;
  onToggleActive: (snippetFilename: string, active: boolean) => void;
}

/**
 * Props for the SnippetForm component
 */
export interface ISnippetFormProps {
  title: string;
  description: string;
  content: string;
  mode: RuleMode;
  isEditing: boolean;
  existingSnippets: ISnippet[];
  editingSnippetFilename?: string; // Current snippet being edited (to exclude from duplicate check)
  disableTitleEdit?: boolean; // Disable title editing for default rules and their overrides
  onSave: () => void;
  onClose: () => void;
  onTitleChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onContentChange: (value: string) => void;
  onModeChange: (mode: RuleMode) => void;
}

/**
 * Props for the SnippetViewer component
 */
export interface ISnippetViewerProps {
  snippet: ISnippet;
  onEdit: (snippet: ISnippet) => void;
  onEnable: (snippet: ISnippet) => void;
  onClose: () => void;
}

/**
 * Props for the SnippetList component
 */
export interface ISnippetListProps {
  snippets: ISnippet[];
  onView: (snippet: ISnippet) => void; // Now used for editing
  onDelete: (snippetFilename: string) => void;
  onDuplicate: (snippet: ISnippet) => void;
  onCreateNew: () => void;
  onToggleActive: (snippetFilename: string, active: boolean) => void;
}
