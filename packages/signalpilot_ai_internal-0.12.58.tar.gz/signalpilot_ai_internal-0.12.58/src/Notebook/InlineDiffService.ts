/**
 * @deprecated This file has been moved to src/Jupyter/Diff/InlineDiffService.ts
 * This re-export is maintained for backward compatibility.
 * Please update imports to use '@/Jupyter/Diff/InlineDiffService' or '@/Jupyter/Diff'
 */

export * from '../Jupyter/Diff/InlineDiffService';
