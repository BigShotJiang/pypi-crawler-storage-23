/**
 * useTokenBreakdown Hook
 *
 * Calculates detailed token breakdown for each context component
 * matching the same sources as LLM context assembly (AnthropicMessageCreator.prepareExtraSystemMessages()).
 *
 * Categories:
 * - System prompt: Mode-specific base prompt
 * - Tools: Built-in tools + MCP tools
 * - Rules: Always-apply (full) + intelligent (hints) + fetched (full) + inserted snippets
 * - Notebook state: Cell summaries + database configs (non-welcome modes)
 * - Kernel variables: Kernel state preview (non-welcome modes)
 * - Context cells: User-selected cell content
 * - Messages: Conversation history
 * - Free space: Remaining tokens
 * - Autocompact buffer: Reserved space (16.5%)
 */
import { useState, useCallback } from 'react';
import { estimateTokenCount } from '@/utils/tokenUtils';
import { useSnippetStore } from '@/stores/snippetStore';
import { useChatMessagesStore } from '@/stores/chatMessages';
import { getWorkspaceContext } from '@/stores/appStore';
import { useServicesStore } from '@/stores/servicesStore';
import { useNotebookEventsStore } from '@/stores/notebookEventsStore';
import { useChatStore } from '@/stores/chat/chatStore';
import { useChatModeStore } from '@/stores/chatModeStore';
import { ConfigService } from '@/Config/ConfigService';
import { MCPClientService } from '@/Services/MCPClientService';
import { KernelPreviewUtils } from '@/utils/kernelPreview';
import { DatabaseStateService, DatabaseType } from '@/stores/databaseStore';
import { getEnvVarPrefix } from '@/utils/databaseEnvVars';

export interface TokenBreakdownCategory {
  name: string;
  tokens: number;
  percentage: number;
  color: string;
}

export interface TokenBreakdown {
  totalUsed: number;
  maxTokens: number;
  percentageUsed: number;
  categories: TokenBreakdownCategory[];
  isCalculating: boolean;
}

export interface UseTokenBreakdownReturn {
  breakdown: TokenBreakdown;
  calculateBreakdown: () => Promise<void>;
}

// Category colors matching the plan
const CATEGORY_COLORS = {
  systemPrompt: '#4a90e2', // Blue
  tools: '#50c878', // Green
  rules: '#f39c12', // Orange
  notebookState: '#00bcd4', // Cyan
  kernelVariables: '#9b59b6', // Purple
  contextCells: '#e91e63', // Pink
  messages: '#009688', // Teal
  freeSpace: '#2d3748' // Dark gray
};

/**
 * Hook for calculating detailed token breakdown on hover.
 */
export function useTokenBreakdown(maxTokens: number): UseTokenBreakdownReturn {
  const [breakdown, setBreakdown] = useState<TokenBreakdown>({
    totalUsed: 0,
    maxTokens,
    percentageUsed: 0,
    categories: [],
    isCalculating: false
  });

  const calculateBreakdown = useCallback(async () => {
    // Prevent multiple simultaneous calculations
    if (breakdown.isCalculating) return;

    setBreakdown(prev => ({ ...prev, isCalculating: true }));

    try {
      const categories: TokenBreakdownCategory[] = [];

      // Get current mode using the chatModeStore
      const mode = useChatModeStore.getState().getEffectiveMode();
      const isWelcomeMode = mode === 'welcome';
      const notebookId =
        useNotebookEventsStore.getState().currentNotebookId || undefined;

      // 1. Calculate System Prompt tokens
      const systemPromptTokens = await calculateSystemPromptTokens(mode);
      categories.push({
        name: 'System prompt',
        tokens: systemPromptTokens,
        percentage: 0, // Will be calculated later
        color: CATEGORY_COLORS.systemPrompt
      });

      // 2. Calculate Tools tokens
      const toolsTokens = await calculateToolsTokens();
      categories.push({
        name: 'Tools',
        tokens: toolsTokens,
        percentage: 0,
        color: CATEGORY_COLORS.tools
      });

      // 3. Calculate Rules tokens
      const rulesTokens = calculateRulesTokens();
      categories.push({
        name: 'Rules',
        tokens: rulesTokens,
        percentage: 0,
        color: CATEGORY_COLORS.rules
      });

      // 4. Notebook state (non-welcome modes only)
      let notebookStateTokens = 0;
      if (!isWelcomeMode && notebookId) {
        notebookStateTokens = await calculateNotebookStateTokens(notebookId);
      }
      if (notebookStateTokens > 0) {
        categories.push({
          name: 'Notebook state',
          tokens: notebookStateTokens,
          percentage: 0,
          color: CATEGORY_COLORS.notebookState
        });
      }

      // 5. Kernel variables (non-welcome modes only)
      let kernelVariablesTokens = 0;
      if (!isWelcomeMode) {
        kernelVariablesTokens = await calculateKernelVariablesTokens();
      }
      if (kernelVariablesTokens > 0) {
        categories.push({
          name: 'Kernel variables',
          tokens: kernelVariablesTokens,
          percentage: 0,
          color: CATEGORY_COLORS.kernelVariables
        });
      }

      // 6. Context cells
      const contextCellsTokens = calculateContextCellsTokens(notebookId);
      if (contextCellsTokens > 0) {
        categories.push({
          name: 'Context cells',
          tokens: contextCellsTokens,
          percentage: 0,
          color: CATEGORY_COLORS.contextCells
        });
      }

      // 7. Welcome mode extras (workspace context, database configs)
      let welcomeExtrasTokens = 0;
      if (isWelcomeMode) {
        welcomeExtrasTokens = calculateWelcomeModeTokens();
        if (welcomeExtrasTokens > 0) {
          categories.push({
            name: 'Workspace context',
            tokens: welcomeExtrasTokens,
            percentage: 0,
            color: CATEGORY_COLORS.notebookState
          });
        }
      }

      // 8. Calculate Messages tokens
      const messagesTokens = calculateMessagesTokens();
      categories.push({
        name: 'Messages',
        tokens: messagesTokens,
        percentage: 0,
        color: CATEGORY_COLORS.messages
      });

      // Calculate total used tokens
      const totalUsed = categories.reduce((sum, cat) => sum + cat.tokens, 0);

      // Calculate free space
      const freeSpace = Math.max(0, maxTokens - totalUsed);

      // Add free space category
      categories.push({
        name: 'Free space',
        tokens: freeSpace,
        percentage: 0,
        color: CATEGORY_COLORS.freeSpace
      });

      // Calculate percentages
      for (const category of categories) {
        category.percentage = maxTokens > 0 ? Math.round((category.tokens / maxTokens) * 1000) / 10 : 0;
      }

      const percentageUsed = Math.round((totalUsed / maxTokens) * 100);

      setBreakdown({
        totalUsed,
        maxTokens,
        percentageUsed,
        categories,
        isCalculating: false
      });
    } catch (error) {
      console.error('[useTokenBreakdown] Error calculating breakdown:', error);
      setBreakdown(prev => ({ ...prev, isCalculating: false }));
    }
  }, [maxTokens, breakdown.isCalculating]);

  return {
    breakdown,
    calculateBreakdown
  };
}

/**
 * Calculate system prompt tokens based on mode
 */
async function calculateSystemPromptTokens(
  mode: 'agent' | 'ask' | 'fast' | 'welcome'
): Promise<number> {
  try {
    const config = await ConfigService.getConfig();
    let basePrompt = '';

    switch (mode) {
      case 'ask':
        basePrompt = config.claude_ask_mode?.system_prompt || '';
        break;
      case 'fast':
        basePrompt = config.fast_mode?.system_prompt || '';
        break;
      case 'welcome':
        basePrompt = config.welcome_mode?.system_prompt || '';
        break;
      default:
        basePrompt = config.claude?.system_prompt || '';
    }

    return estimateTokenCount(basePrompt);
  } catch (error) {
    console.warn('[useTokenBreakdown] Error getting system prompt:', error);
    return 0;
  }
}

/**
 * Calculate tools tokens (built-in + MCP tools)
 * Matches the logic in AnthropicService which:
 * 1. Adds tools as actual tool definitions (with defer_loading for MCP)
 * 2. Also appends MCP tools info to system prompt as text section
 */
async function calculateToolsTokens(): Promise<number> {
  try {
    const toolService = useServicesStore.getState().toolService;
    const tools = toolService?.getTools() || [];
    let toolsTokens = estimateTokenCount(JSON.stringify(tools));

    // Add MCP tools - both as tool definitions AND as system prompt text
    try {
      const mcpClient = MCPClientService.getInstance();
      const mcpTools = await mcpClient.getAllTools();
      if (mcpTools && mcpTools.length > 0) {
        // 1. Count MCP tools as tool definitions (with defer_loading format)
        const anthropicMCPTools = mcpClient.convertToAnthropicTools(mcpTools, true);
        toolsTokens += estimateTokenCount(JSON.stringify(anthropicMCPTools));

        // 2. Count MCP tools section appended to system prompt
        // Format: <$MCP_NAME>\n$tool_name - $tool_description
        const toolsByServer = new Map<string, Array<{ name: string; description: string }>>();
        for (const tool of mcpTools) {
          const serverName = tool.serverName || tool.serverId || 'unknown';
          if (!toolsByServer.has(serverName)) {
            toolsByServer.set(serverName, []);
          }
          toolsByServer.get(serverName)!.push({
            name: tool.name,
            description: tool.description || ''
          });
        }

        const mcpToolsSection: string[] = [];
        for (const [serverName, serverTools] of toolsByServer.entries()) {
          mcpToolsSection.push(`<${serverName}>`);
          for (const tool of serverTools) {
            mcpToolsSection.push(`${tool.name} - ${tool.description}\n`);
          }
        }
        toolsTokens += estimateTokenCount(mcpToolsSection.join('\n'));
      }
    } catch (err) {
      console.warn('[useTokenBreakdown] Error getting MCP tools:', err);
    }

    return toolsTokens;
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating tools tokens:', error);
    return 0;
  }
}

/**
 * Calculate rules tokens (always + intelligent hints + fetched + inserted)
 * Matches the logic in AnthropicMessageCreator.prepareExtraSystemMessages()
 */
function calculateRulesTokens(): number {
  try {
    const snippets = useSnippetStore.getState().snippets;
    let totalTokens = 0;

    // 1. Always-apply rules (full content)
    const alwaysRules = snippets.filter(r => r.mode === 'always' && r.active !== false);
    for (const rule of alwaysRules) {
      const ruleText = `=== Rule: ${rule.title} ===\n${rule.content}\n=== End ${rule.title} ===`;
      totalTokens += estimateTokenCount(ruleText);
    }

    // 2. Intelligent rules (hints only - filename + description)
    const intelligentRules = snippets.filter(r => r.mode === 'intelligent' && r.active !== false);
    if (intelligentRules.length > 0) {
      // Add the wrapper text that's included in the system message
      let hintsText = `<rules_available>\nYou can fetch additional context using the rules-get_rules tool.\n`;
      hintsText += `Available rules (use the quoted filename exactly):\n`;
      for (const rule of intelligentRules) {
        hintsText += `- "${rule.filename}": ${rule.description}\n`;
      }
      hintsText += `</rules_available>`;
      totalTokens += estimateTokenCount(hintsText);
    }

    // 3. Fetched rules (full content) - from both store AND message history
    // This matches AnthropicMessageCreator logic which scans both sources
    const storeRuleFilenames = useChatStore.getState().getFetchedRuleFilenames();

    // Also scan message history for rules-get_rules tool results
    const historyRuleFilenames: string[] = [];
    const llmHistory = useChatMessagesStore.getState().llmHistory || [];
    for (const msg of llmHistory) {
      if (msg.role === 'user' && Array.isArray(msg.content)) {
        for (const block of msg.content as any[]) {
          if (
            block.type === 'tool_result' &&
            typeof block.content === 'string'
          ) {
            try {
              const result = JSON.parse(block.content);
              if (result.success && result.loaded_rule_filenames) {
                historyRuleFilenames.push(...result.loaded_rule_filenames);
              } else if (result.success && result.loaded_rule_ids) {
                historyRuleFilenames.push(...result.loaded_rule_ids);
              }
            } catch {
              // Not JSON or not a rules result, skip
            }
          }
        }
      }
    }

    // Combine and deduplicate
    const allFetchedFilenames = [...new Set([...storeRuleFilenames, ...historyRuleFilenames])];
    const fetchedRules = snippets.filter(r => allFetchedFilenames.includes(r.filename));

    if (fetchedRules.length > 0) {
      let fetchedText = `<rules_fetched>\nThe following rules were fetched earlier in this conversation:\n\n`;
      for (const rule of fetchedRules) {
        fetchedText += `<rule filename="${rule.filename}" title="${rule.title}" description="${rule.description}">\n${rule.content}\n</rule>\n\n`;
      }
      fetchedText += `</rules_fetched>`;
      totalTokens += estimateTokenCount(fetchedText);
    }

    // 4. Inserted snippets (via @-mention)
    const insertedSnippets = useSnippetStore.getState().getInsertedSnippets();
    if (insertedSnippets.length > 0) {
      let snippetsText = `The user has inserted the following code snippets for context:\n\n`;
      for (const snippet of insertedSnippets) {
        snippetsText += `Snippet Title: ${snippet.title}\nSnippet Description: ${snippet.description || ''}\n=== Begin ${snippet.title} Content ===\n\n${snippet.content}\n\n=== END ${snippet.title} Content ===\n\n`;
      }
      totalTokens += estimateTokenCount(snippetsText);
    }

    return totalTokens;
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating rules tokens:', error);
    return 0;
  }
}

/**
 * Calculate notebook state tokens
 */
async function calculateNotebookStateTokens(notebookId: string): Promise<number> {
  try {
    const toolService = useServicesStore.getState().toolService;
    if (!toolService?.notebookTools) return 0;

    const summary = await toolService.notebookTools.getNotebookSummary(notebookId);
    if (!summary) return 0;

    // Format summary similar to LLMContext
    const summaryText = `This is the current notebook summary with edit history: ${JSON.stringify(summary)}`;
    return estimateTokenCount(summaryText);
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating notebook state tokens:', error);
    return 0;
  }
}

/**
 * Calculate kernel variables tokens
 */
async function calculateKernelVariablesTokens(): Promise<number> {
  try {
    const kernelPreview = await KernelPreviewUtils.getLimitedKernelPreview();
    if (!kernelPreview) return 0;

    const previewText = `Current Kernel Variables and Objects Preview:\n\n${kernelPreview}`;
    return estimateTokenCount(previewText);
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating kernel variables tokens:', error);
    return 0;
  }
}

/**
 * Calculate context cells tokens
 */
function calculateContextCellsTokens(notebookId: string | undefined): number {
  try {
    if (!notebookId) return 0;

    const notebookContextManager = useServicesStore.getState().notebookContextManager;
    if (!notebookContextManager) return 0;

    const contextText = notebookContextManager.formatContextAsMessage(notebookId);
    return estimateTokenCount(contextText);
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating context cells tokens:', error);
    return 0;
  }
}

/**
 * Calculate welcome mode specific tokens (workspace context + database configs)
 */
function calculateWelcomeModeTokens(): number {
  try {
    let totalTokens = 0;

    // Workspace context
    const workspaceContext = getWorkspaceContext();
    if (workspaceContext?.welcome_context) {
      const contextText = `Workspace Context (notebook list only — use terminal-glob to discover data files):\n\n${workspaceContext.welcome_context}`;
      totalTokens += estimateTokenCount(contextText);
    }

    // Database configs
    const dbConfigs = DatabaseStateService.getState().configurations;
    if (dbConfigs.length > 0) {
      let dbString = '=== AVAILABLE DATABASES ===\n';
      dbConfigs.forEach(db => {
        const prefix = getEnvVarPrefix(db.name);
        let line = `- ${db.name} (${db.type}) - env prefix: ${prefix}_`;
        if (db.type === DatabaseType.Databricks) {
          const creds = db.credentials as { authType?: string };
          const authType = creds?.authType || 'pat';
          line += ` [auth: ${authType}]`;
        }
        dbString += line + '\n';
      });
      dbString += '\nEnvironment variables are set in the kernel. ';
      dbString += 'Use `rules-get_rules` with the database type for connection patterns.\n';
      dbString += '=== END DATABASES ===\n';
      totalTokens += estimateTokenCount(dbString);
    }

    return totalTokens;
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating welcome mode tokens:', error);
    return 0;
  }
}

/**
 * Calculate messages tokens from LLM history
 */
function calculateMessagesTokens(): number {
  try {
    const llmHistory = useChatMessagesStore.getState().llmHistory || [];
    let totalTokens = 0;

    for (const message of llmHistory) {
      if (typeof message.content === 'string') {
        totalTokens += estimateTokenCount(message.content);
      } else if (Array.isArray(message.content)) {
        for (const block of message.content as any[]) {
          if (block.text) {
            totalTokens += estimateTokenCount(block.text);
          } else if (block.input) {
            totalTokens += estimateTokenCount(JSON.stringify(block.input));
          } else if (block.content) {
            totalTokens += estimateTokenCount(
              typeof block.content === 'string' ? block.content : JSON.stringify(block.content)
            );
          }
        }
      }
      // Message structure overhead
      totalTokens += 10;
    }

    return totalTokens;
  } catch (error) {
    console.warn('[useTokenBreakdown] Error calculating messages tokens:', error);
    return 0;
  }
}

export default useTokenBreakdown;
