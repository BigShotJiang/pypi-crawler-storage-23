"""Interface modules for amp."""
