"""python -m junos_ops で実行可能にする"""

import sys

from junos_ops.cli import main

sys.exit(main())
