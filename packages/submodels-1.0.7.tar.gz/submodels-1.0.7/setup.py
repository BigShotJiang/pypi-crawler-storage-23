"""
This algorithm applies a layer of abstraction over the “sapiens_submodels” module and simplifies the function calls of the original code,
making the development process faster and more productive. The conversion and packaging functions are absent in the current class,
but can still be invoked through the private variable “__sapiens_submodels”.

We do not authorize the copying, editing, customization, or sharing of this code or the original code;
public posts and comments are also not allowed, and any violation of these guidelines without prior authorization will be subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'SUBMODELS'
version = '1.0.7'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=['sapiens-submodels'],
    url='https://github.com/sapiens-technology/SUBMODELS',
    license='Proprietary Software'
)
"""
This algorithm applies a layer of abstraction over the “sapiens_submodels” module and simplifies the function calls of the original code,
making the development process faster and more productive. The conversion and packaging functions are absent in the current class,
but can still be invoked through the private variable “__sapiens_submodels”.

We do not authorize the copying, editing, customization, or sharing of this code or the original code;
public posts and comments are also not allowed, and any violation of these guidelines without prior authorization will be subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
