"""
This algorithm applies a layer of abstraction over the “sapiens_submodels” module and simplifies the function calls of the original code,
making the development process faster and more productive. The conversion and packaging functions are absent in the current class,
but can still be invoked through the private variable “__sapiens_submodels”.

We do not authorize the copying, editing, customization, or sharing of this code or the original code;
public posts and comments are also not allowed, and any violation of these guidelines without prior authorization will be subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
class SUBMODELS:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else False
			try:
				from warnings import filterwarnings
				from logging import getLogger, ERROR, disable, CRITICAL
				from os import environ
				from dotenv import load_dotenv
				filterwarnings('ignore')
				filterwarnings('ignore', category=UserWarning, module='torch.distributed')
				getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
				environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
				load_dotenv()
				disable(CRITICAL)
			except: pass
			from traceback import print_exc
			self.__print_exc = print_exc
			from sapiens_submodels import Submodels as SapiensSubmodels
			self.__sapiens_submodels = SapiensSubmodels(show_errors=self.__show_errors, display_error_point=self.__display_error_point)
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SUBMODELS.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
	def loadModel(self, model_path='', progress=True):
		try:
			loaded_model = model_path
			model_path = str(model_path).strip()
			progress = bool(progress) if type(progress) in (bool, int, float) else True
			from pathlib import Path
			from os.path import join
			priority_extensions_1 = ['.cpu', '.hurlm', '.scn01', '.scn02', '.scnet', '.scnnet', '.hurnet', '.mini']
			priority_extensions_2 = ['.submodel', '.SAPI', '.sapiens']
			def _is_existing_file(file_path=''): return Path(file_path).exists() and Path(file_path).is_file()
			def _get_file_extension(file_path=''): return Path(file_path).suffix
			def _get_model_name_from_directory(directory_path='', priority_extensions=[]):
				try:
					directory_path = str(directory_path).strip()
					from os import listdir
					from os.path import isfile
					from os.path import splitext
					files = [file_name for file_name in listdir(directory_path) if isfile(join(directory_path, file_name))]
					for extension in priority_extensions:
						for file_name in files:
							name, ext = splitext(file_name)
							if ext.lower() == extension: return name
					return ''
				except: return ''
			existing_file = _is_existing_file(file_path=model_path)
			if not existing_file and _is_existing_file(file_path=f'{model_path}.submodel'): model_path = f'{model_path}.submodel'
			elif not existing_file and _is_existing_file(file_path=f'{model_path}.SAPI'): model_path = f'{model_path}.SAPI'
			elif not existing_file and _is_existing_file(file_path=f'{model_path}.sapiens'): model_path = f'{model_path}.sapiens'
			elif not existing_file:
				model_file = _get_model_name_from_directory(directory_path=loaded_model, priority_extensions=priority_extensions_2)
				_model_path = join(model_path, model_file)
				if not existing_file and _is_existing_file(file_path=f'{_model_path}.submodel'): model_path = f'{_model_path}.submodel'
				elif not existing_file and _is_existing_file(file_path=f'{_model_path}.SAPI'): model_path = f'{_model_path}.SAPI'
				elif not existing_file and _is_existing_file(file_path=f'{_model_path}.sapiens'): model_path = f'{_model_path}.sapiens'				
			model_file = _get_model_name_from_directory(directory_path=loaded_model, priority_extensions=priority_extensions_1)
			if not _is_existing_file(file_path=model_path): return join(loaded_model, model_file) if model_file else loaded_model
			file_extension = _get_file_extension(file_path=model_path)
			if file_extension.endswith('.submodel'): loaded_model = self.__sapiens_submodels.unconvert(model_path=model_path, progress=progress)
			elif file_extension.endswith(('.SAPI', '.sapiens')): loaded_model = self.__sapiens_submodels.unpack(model_path=model_path, progress=progress)
			model_file = _get_model_name_from_directory(directory_path=loaded_model, priority_extensions=priority_extensions_1)
			if model_file: loaded_model = join(loaded_model, model_file)
			return loaded_model
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SUBMODELS.loadModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
				self.__is_submodel = False
			except: pass
			return model_path
	def deleteModel(self, model_path=''):
		try:
			deletion_result = False
			model_path = str(model_path).strip()
			deletion_result = self.__sapiens_submodels.deleteModel(model_path=model_path)
			return deletion_result
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SUBMODELS.deleteModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
			return False
"""
This algorithm applies a layer of abstraction over the “sapiens_submodels” module and simplifies the function calls of the original code,
making the development process faster and more productive. The conversion and packaging functions are absent in the current class,
but can still be invoked through the private variable “__sapiens_submodels”.

We do not authorize the copying, editing, customization, or sharing of this code or the original code;
public posts and comments are also not allowed, and any violation of these guidelines without prior authorization will be subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
