"""Fast regex-based DOT parser for large files.

Bypasses pydot/pyparsing which chokes on files with very long label
strings (common in compiler IR output where each node label contains
hundreds of instructions on a single line).

This parser handles the subset of DOT used by compiler CFG output:
  - digraph/graph declarations
  - Node declarations with attributes (especially long labels)
  - Edge declarations with attributes
  - Quoted node names and labels
  - Default node/edge attribute statements
  - Subgraph blocks (flattened)
  - Comments (// and /* */)
"""

from __future__ import annotations

import re
from pathlib import Path

from hotdot.parser import Edge, Node, ParsedGraph, _unescape_dot_label


def _strip_comments(text: str) -> str:
    """Remove C-style and C++-style comments from DOT source."""
    # Remove /* ... */ comments (non-greedy)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    # Remove // comments (to end of line)
    text = re.sub(r"//[^\n]*", "", text)
    return text


def _extract_quoted_string(text: str, pos: int) -> tuple[str, int]:
    """Extract a double-quoted string starting at pos, handling escapes.

    Returns (content_without_quotes, position_after_closing_quote).
    """
    assert text[pos] == '"'
    i = pos + 1
    parts: list[str] = []
    while i < len(text):
        ch = text[i]
        if ch == "\\":
            # Keep the escape sequence as-is for later processing
            if i + 1 < len(text):
                parts.append(text[i : i + 2])
                i += 2
            else:
                parts.append(ch)
                i += 1
        elif ch == '"':
            return "".join(parts), i + 1
        else:
            parts.append(ch)
            i += 1
    # Unterminated string — return what we have
    return "".join(parts), i


def _parse_attr_list(text: str) -> dict[str, str]:
    """Parse a DOT attribute list like [key=val, key="val", ...]."""
    attrs: dict[str, str] = {}
    # Match key=value pairs where value can be quoted or unquoted
    for m in re.finditer(
        r'(\w+)\s*=\s*(?:"((?:[^"\\]|\\.)*)"|<([^>]*)>|(\w[\w.]*))', text
    ):
        key = m.group(1)
        # Quoted value, HTML value, or bare value
        val = m.group(2) if m.group(2) is not None else (m.group(3) or m.group(4) or "")
        attrs[key] = val
    return attrs


def _find_attr_block(text: str, start: int) -> tuple[dict[str, str], int]:
    """Find and parse an attribute block [....] starting from start.

    Handles nested brackets inside quoted strings.
    Returns (attrs_dict, position_after_block).
    """
    i = start
    # Skip whitespace
    while i < len(text) and text[i] in " \t\n\r":
        i += 1

    if i >= len(text) or text[i] != "[":
        return {}, start

    depth = 0
    j = i
    while j < len(text):
        ch = text[j]
        if ch == '"':
            _, j = _extract_quoted_string(text, j)
            continue
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                block = text[i + 1 : j]
                return _parse_attr_list(block), j + 1
        j += 1
    return {}, start


_GRAPH_RE = re.compile(
    r"^\s*(strict\s+)?(digraph|graph)\s+(?:\"([^\"]*)\"|(\w+))?\s*\{",
    re.MULTILINE,
)

# Match node ID: quoted or bare identifier
_NODE_ID = r'(?:"(?:[^"\\]|\\.)*"|\w[\w.]*)'

# Edge statement: nodeA -> nodeB or nodeA -- nodeB
_EDGE_RE = re.compile(
    rf"({_NODE_ID})\s*(->|--)\s*({_NODE_ID})\s*(\[.*?\])?\s*;?",
)


def _unquote(s: str) -> str:
    """Remove surrounding quotes from a string."""
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s[1:-1]
    return s


def _skip_port(text: str, pos: int, end: int) -> int:
    """Skip DOT port/compass suffixes like :s, :port_id, :port_id:nw.

    DOT allows edges to specify ports:  "node":port:compass -> "node2"
    Compass points: n, ne, e, se, s, sw, w, nw, c, _
    """
    j = pos
    # Up to two colon-separated suffixes (:port and :compass)
    for _ in range(2):
        if j < end and text[j] == ":":
            # Check for a bare identifier after the colon
            port_m = re.match(r":(\w+)", text[j:])
            if port_m:
                j += port_m.end()
            else:
                break
    return j


def _fast_parse(text: str) -> ParsedGraph:
    """Parse DOT text using regex — fast even for very long labels."""
    text = _strip_comments(text)

    # Determine graph type and name
    m = _GRAPH_RE.search(text)
    if not m:
        raise ValueError("Could not find graph declaration in DOT input")

    is_directed = m.group(2) == "digraph"
    name = m.group(3) or m.group(4) or "unnamed"

    nodes_by_id: dict[str, Node] = {}
    edges: list[Edge] = []
    default_node_attrs: dict[str, str] = {}
    default_edge_attrs: dict[str, str] = {}

    # Find the body (everything inside the outermost braces)
    brace_start = text.index("{", m.start())
    body_start = brace_start + 1

    # Walk through the body, extracting statements
    i = body_start
    end = len(text)

    while i < end:
        # Skip whitespace
        while i < end and text[i] in " \t\n\r":
            i += 1
        if i >= end or text[i] == "}":
            break

        # Skip subgraph/cluster keywords (we flatten)
        sub_m = re.match(r"subgraph\s+(?:\"[^\"]*\"|\w+)\s*\{", text[i:])
        if sub_m:
            i += sub_m.end() - 1  # skip past the { which we'll skip naturally
            i += 1
            continue
        if text[i] == "{":
            i += 1
            continue

        # Try to read a node ID at the current position
        id_m = re.match(r'"(?:[^"\\]|\\.)*"|\w[\w.]*', text[i:])
        if not id_m:
            i += 1
            continue

        first_id = id_m.group(0)
        first_id_raw = _unquote(first_id)
        j = i + id_m.end()

        # Skip optional port/compass suffix like :s, :n, :port_id:nw
        # DOT syntax: node_id [:port_id] [:compass_point]
        j = _skip_port(text, j, end)

        # Skip whitespace
        while j < end and text[j] in " \t\n\r":
            j += 1

        # Check if this is an edge statement
        is_edge = False
        if j + 1 < end and text[j : j + 2] in ("->", "--"):
            is_edge = True
            j += 2
            # Skip whitespace
            while j < end and text[j] in " \t\n\r":
                j += 1
            # Read target node ID
            tgt_m = re.match(r'"(?:[^"\\]|\\.)*"|\w[\w.]*', text[j:])
            if tgt_m:
                second_id = _unquote(tgt_m.group(0))
                j += tgt_m.end()

                # Skip optional port/compass on target too
                j = _skip_port(text, j, end)

                # Parse edge attributes
                attrs, j = _find_attr_block(text, j)
                edge_attrs = dict(default_edge_attrs)
                edge_attrs.update(attrs)
                label = edge_attrs.pop("label", "")
                if label:
                    label = _unescape_dot_label(label)
                edges.append(Edge(
                    source=first_id_raw, target=second_id,
                    label=label, attributes=edge_attrs,
                ))

                # Ensure both nodes exist
                for nid in (first_id_raw, second_id):
                    if nid not in nodes_by_id:
                        nodes_by_id[nid] = Node(id=nid, label=nid, attributes={})

                # Skip to next statement
                while j < end and text[j] in " \t\n\r;":
                    j += 1
                i = j
                continue

        # Check if it's a default attribute statement (node [...] or edge [...])
        if first_id_raw in ("node", "edge", "graph"):
            attrs, j = _find_attr_block(text, j)
            if first_id_raw == "node":
                default_node_attrs.update(attrs)
            elif first_id_raw == "edge":
                default_edge_attrs.update(attrs)
            while j < end and text[j] in " \t\n\r;":
                j += 1
            i = j
            continue

        # It's a node declaration (possibly with attributes)
        attrs, j = _find_attr_block(text, j)
        node_attrs = dict(default_node_attrs)
        node_attrs.update(attrs)

        raw_label = node_attrs.pop("label", None)
        if raw_label is not None and raw_label != "":
            label = _unescape_dot_label(raw_label)
        elif raw_label == "":
            label = ""
        else:
            label = first_id_raw

        if first_id_raw not in nodes_by_id:
            nodes_by_id[first_id_raw] = Node(
                id=first_id_raw, label=label, attributes=node_attrs,
            )
        else:
            nodes_by_id[first_id_raw].label = label
            nodes_by_id[first_id_raw].attributes.update(node_attrs)

        # Skip to next statement
        while j < end and text[j] in " \t\n\r;":
            j += 1
        i = j

    return ParsedGraph(
        name=name,
        nodes=list(nodes_by_id.values()),
        edges=edges,
        is_directed=is_directed,
    )


def fast_parse_dot_file(path: str | Path) -> ParsedGraph:
    """Parse a DOT file using the fast regex-based parser.

    Args:
        path: Path to the DOT file.

    Returns:
        A ParsedGraph with all nodes and edges extracted.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file cannot be parsed.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"DOT file not found: {path}")

    text = path.read_text(encoding="utf-8", errors="replace")
    return _fast_parse(text)


def fast_parse_dot_string(dot_string: str) -> ParsedGraph:
    """Parse a DOT string using the fast regex-based parser.

    Args:
        dot_string: A string containing DOT graph notation.

    Returns:
        A ParsedGraph with all nodes and edges extracted.

    Raises:
        ValueError: If the string cannot be parsed.
    """
    return _fast_parse(dot_string)
