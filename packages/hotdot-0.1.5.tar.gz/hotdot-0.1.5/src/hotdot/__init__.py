"""HotDot — A DOT file visualizer for control-flow graphs."""

__version__ = "0.1.5"
