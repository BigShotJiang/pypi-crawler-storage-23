"""CLI entry point for hotdot."""

from __future__ import annotations

import argparse
import os
import sys
import threading
import time
import webbrowser
from pathlib import Path

from hotdot import __version__

_SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


def _human_size(nbytes: int) -> str:
    """Format a byte count as a human-readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if nbytes < 1024:
            return f"{nbytes:.1f} {unit}" if unit != "B" else f"{nbytes} {unit}"
        nbytes /= 1024  # type: ignore[assignment]
    return f"{nbytes:.1f} TB"


class _Spinner:
    """A terminal spinner that shows the current phase and elapsed time."""

    def __init__(self) -> None:
        self._message = ""
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._phase_start: float = 0.0

    def _run(self) -> None:
        idx = 0
        while not self._stop.is_set():
            elapsed = time.monotonic() - self._phase_start
            frame = _SPINNER_FRAMES[idx % len(_SPINNER_FRAMES)]
            sys.stderr.write(f"\r{frame} {self._message} ({elapsed:.1f}s)")
            sys.stderr.flush()
            idx += 1
            self._stop.wait(0.08)
        # Clear the spinner line
        sys.stderr.write("\r\033[2K")
        sys.stderr.flush()

    def start(self, message: str) -> None:
        """Start or update the spinner with a new message."""
        self._message = message
        self._phase_start = time.monotonic()
        if self._thread is None:
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def stop(self) -> None:
        """Stop the spinner and clear the line."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
            self._thread = None


def _print_file_stats(path: Path) -> None:
    """Print file statistics to help estimate processing time."""
    stat = path.stat()
    size = _human_size(stat.st_size)

    # Quick line/node/edge estimate by scanning the file
    line_count = 0
    node_hints = 0
    edge_hints = 0
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line_count += 1
            stripped = line.strip()
            if "->" in stripped:
                edge_hints += 1
            elif stripped and "[" in stripped and "label" in stripped:
                node_hints += 1

    sys.stderr.write(f"  File: {path.name} ({size}, {line_count:,} lines)\n")
    sys.stderr.write(f"  Estimated: ~{node_hints} nodes, ~{edge_hints} edges\n")
    sys.stderr.flush()


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="hotdot",
        description="Visualize DOT files as interactive control-flow graphs.",
    )
    parser.add_argument("input", nargs="?", help="Path to the DOT file to visualize")
    parser.add_argument("-o", "--output", help="Output HTML file path")
    parser.add_argument(
        "--open",
        action="store_true",
        help="Open the HTML file in the default browser",
    )
    parser.add_argument("--title", help="Override the graph title")
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    args = parser.parse_args()

    if args.input is None:
        parser.print_help()
        sys.exit(1)

    input_path = Path(args.input)

    # Validate input file exists
    if not input_path.exists():
        print(f"Error: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    # Warn on non-standard extension
    ext = input_path.suffix.lower()
    if ext not in (".dot", ".gv"):
        print(
            f"Warning: '{input_path.name}' does not have a .dot or .gv extension, proceeding anyway.",
            file=sys.stderr,
        )

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = Path(input_path.stem + ".html")

    # Print file stats before starting
    _print_file_stats(input_path)

    spinner = _Spinner()
    t_start = time.monotonic()

    # Parse and render
    try:
        from hotdot.parser import parse_dot_file
        from hotdot.renderer import render_html

        spinner.start(f"Parsing {input_path.name}")
        graph = parse_dot_file(str(input_path))
        t_parsed = time.monotonic()

        if args.title:
            graph.name = args.title

        spinner.start(
            f"Rendering {len(graph.nodes)} nodes, {len(graph.edges)} edges"
        )
        html = render_html(graph)
        t_rendered = time.monotonic()
    except (ValueError, FileNotFoundError) as exc:
        spinner.stop()
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        spinner.stop()
        print(f"Error: Failed to process '{input_path}': {exc}", file=sys.stderr)
        sys.exit(1)

    # Write output
    try:
        spinner.start(f"Writing {output_path}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html, encoding="utf-8")
        t_written = time.monotonic()
    except OSError as exc:
        spinner.stop()
        print(f"Error: Could not write output file: {exc}", file=sys.stderr)
        sys.exit(1)

    spinner.stop()

    node_count = len(graph.nodes)
    edge_count = len(graph.edges)
    total = t_written - t_start
    out_size = _human_size(output_path.stat().st_size)
    print(
        f"\u2728 Generated {output_path} ({node_count} nodes, {edge_count} edges, {out_size})"
    )
    print(
        f"   Parsed {t_parsed - t_start:.1f}s"
        f" \u2022 Rendered {t_rendered - t_parsed:.1f}s"
        f" \u2022 Written {t_written - t_rendered:.1f}s"
        f" \u2022 Total {total:.1f}s"
    )

    if args.open:
        webbrowser.open(str(output_path.resolve()))


if __name__ == "__main__":
    main()
