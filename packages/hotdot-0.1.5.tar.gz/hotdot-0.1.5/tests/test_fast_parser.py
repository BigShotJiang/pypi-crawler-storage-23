"""Tests for the fast regex-based DOT parser."""

from __future__ import annotations

import pytest

from hotdot.fast_parser import fast_parse_dot_string


class TestFastParserBasic:
    """Basic fast parser functionality."""

    def test_simple_digraph(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            node [shape=box];
            A [label="Block A:\\l  instr1\\l"];
            B [label="Block B:\\l  instr2\\l"];
            A -> B;
        }
        """)
        assert graph.name == "test"
        assert graph.is_directed is True
        assert len(graph.nodes) == 2
        assert len(graph.edges) == 1

    def test_undirected_graph(self) -> None:
        graph = fast_parse_dot_string("""
        graph test { A -- B; }
        """)
        assert graph.is_directed is False

    def test_quoted_node_names(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            "%B0" [label="%B0:\\l  v0 = add i32\\l"];
            "%B1" [label="%B1:\\l  v1 = sub i32\\l"];
            "%B0" -> "%B1";
        }
        """)
        ids = {n.id for n in graph.nodes}
        assert "%B0" in ids
        assert "%B1" in ids
        assert len(graph.edges) == 1
        assert graph.edges[0].source == "%B0"
        assert graph.edges[0].target == "%B1"

    def test_label_unescape(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            A [label="line1\\lline2\\lline3\\l"];
        }
        """)
        node = graph.nodes[0]
        assert "line1" in node.label
        assert "line2" in node.label
        assert "\n" in node.label

    def test_edge_labels(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            A -> B [label="true"];
            A -> C [label="false"];
        }
        """)
        labels = {e.label for e in graph.edges}
        assert "true" in labels
        assert "false" in labels

    def test_edge_attributes(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            A -> B [style=dashed, color=red, label="back"];
        }
        """)
        edge = graph.edges[0]
        assert edge.label == "back"
        assert edge.attributes.get("style") == "dashed"
        assert edge.attributes.get("color") == "red"

    def test_default_node_attrs(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            node [shape=box, fontname="Courier"];
            A [label="block A"];
        }
        """)
        node = graph.nodes[0]
        assert node.attributes.get("shape") == "box"
        assert node.attributes.get("fontname") == "Courier"

    def test_nodes_from_edges_only(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test { A -> B -> C; }
        """)
        # A -> B and B -> C should create 3 nodes
        # Note: chained edges may parse as two edges
        ids = {n.id for n in graph.nodes}
        assert "A" in ids
        assert "B" in ids

    def test_comments_stripped(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            // this is a comment
            A [label="test"];
            /* block comment */
            A -> B;
        }
        """)
        assert len(graph.nodes) >= 1

    def test_quoted_graph_name(self) -> None:
        graph = fast_parse_dot_string("""
        digraph "my graph name" {
            A -> B;
        }
        """)
        assert graph.name == "my graph name"

    def test_edge_with_ports(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            "%B0" [label="%B0:\\l  instr1\\l"];
            "%B1" [label="%B1:\\l  instr2\\l"];
            "%B2" [label="%B2:\\l  instr3\\l"];
            "%B0":s -> "%B1":n;
            "%B0":sw -> "%B2":n [label="true"];
        }
        """)
        assert len(graph.edges) == 2
        sources = {e.source for e in graph.edges}
        targets = {e.target for e in graph.edges}
        assert sources == {"%B0"}
        assert targets == {"%B1", "%B2"}
        # Port names should NOT appear as nodes
        ids = {n.id for n in graph.nodes}
        assert "s" not in ids
        assert "n" not in ids
        assert "sw" not in ids

    def test_edge_with_compass_only(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            A:n -> B:s;
            B:e -> C:w;
        }
        """)
        assert len(graph.edges) == 2
        assert graph.edges[0].source == "A"
        assert graph.edges[0].target == "B"
        assert graph.edges[1].source == "B"
        assert graph.edges[1].target == "C"
        ids = {n.id for n in graph.nodes}
        assert ids == {"A", "B", "C"}

    def test_edge_with_port_and_compass(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            A:port1:s -> B:port2:n;
        }
        """)
        assert len(graph.edges) == 1
        assert graph.edges[0].source == "A"
        assert graph.edges[0].target == "B"

    def test_subgraph_flattened(self) -> None:
        graph = fast_parse_dot_string("""
        digraph test {
            subgraph cluster_0 {
                A [label="node A"];
                B [label="node B"];
                A -> B;
            }
            B -> C;
        }
        """)
        ids = {n.id for n in graph.nodes}
        assert "A" in ids
        assert "B" in ids


class TestFastParserLongLabels:
    """Test with very long labels that would choke pyparsing."""

    def test_long_label(self) -> None:
        # Generate a label with 500 instructions
        instrs = "\\l".join(
            [f"  v{i} = s_load_dword v[{i}:{i+1}], s[0:1], offset:{i*4}"
             for i in range(500)]
        )
        dot = f'''digraph test {{
            "%B0" [label="%B0:\\l{instrs}\\l"];
            "%B1" [label="%B1:\\l  ret\\l"];
            "%B0" -> "%B1";
        }}'''
        graph = fast_parse_dot_string(dot)
        assert len(graph.nodes) == 2
        assert len(graph.edges) == 1
        node = next(n for n in graph.nodes if n.id == "%B0")
        assert "s_load_dword" in node.label
        assert len(node.label) > 1000

    def test_many_nodes_long_labels(self) -> None:
        lines = ['digraph gpu_cfg {', '  node [shape=box];']
        for i in range(100):
            instrs = "\\l".join(
                [f"  v{i}_{j} = op v[{j}:{j+1}]" for j in range(200)]
            )
            lines.append(f'  "%B{i}" [label="%B{i}:\\l{instrs}\\l"];')
        for i in range(99):
            lines.append(f'  "%B{i}" -> "%B{i+1}";')
        lines.append("}")
        dot = "\n".join(lines)

        graph = fast_parse_dot_string(dot)
        assert len(graph.nodes) == 100
        assert len(graph.edges) == 99
