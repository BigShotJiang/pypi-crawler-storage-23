# laguchori-latex

A small Python library to convert **LaTeX ↔ JSON** using a section/block structure.

## Install

### From PyPI (after you publish)
```bash
pip install laguchori-latex