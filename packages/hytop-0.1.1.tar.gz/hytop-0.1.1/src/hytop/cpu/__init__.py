"""CPU related commands."""
