from __future__ import annotations

import typer

app = typer.Typer(
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
    help="CPU monitoring commands.",
)


@app.command("watch")
def watch() -> None:
    """CPU watcher placeholder command."""
    typer.echo("cpu watch is not implemented yet")
