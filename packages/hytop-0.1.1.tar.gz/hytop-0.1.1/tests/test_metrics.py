"""Tests for hytop.gpu.metrics."""

from __future__ import annotations

from hytop.gpu.metrics import (
    hy_smi_args_for_show_flags,
    normalized_show_flags,
    render_columns_for_show_flags,
)


class TestNormalizedShowFlags:
    def test_none_returns_all_defaults(self):
        flags = normalized_show_flags(None)
        assert flags == ["showtemp", "showpower", "showsclk", "showmemuse", "showuse"]

    def test_empty_list_returns_all_defaults(self):
        assert normalized_show_flags([]) == normalized_show_flags(None)

    def test_single_flag_preserved(self):
        assert normalized_show_flags(["showtemp"]) == ["showtemp"]

    def test_order_preserved(self):
        assert normalized_show_flags(["showuse", "showtemp"]) == ["showuse", "showtemp"]

    def test_duplicates_deduplicated(self):
        assert normalized_show_flags(["showtemp", "showtemp"]) == ["showtemp"]

    def test_unknown_flag_ignored(self):
        result = normalized_show_flags(["unknown_flag"])
        # Falls back to defaults when nothing valid remains
        assert result == normalized_show_flags(None)

    def test_mix_valid_and_invalid(self):
        result = normalized_show_flags(["showtemp", "INVALID"])
        assert result == ["showtemp"]


class TestHySmiArgsForShowFlags:
    def test_includes_json_flag(self):
        args = hy_smi_args_for_show_flags(["showtemp"], wait_idle=False)
        assert "--json" in args

    def test_showtemp_maps_to_showtemp(self):
        args = hy_smi_args_for_show_flags(["showtemp"], wait_idle=False)
        assert "--showtemp" in args

    def test_showsclk_maps_to_showhcuclocks(self):
        # showsclk has hy_smi_flag override → should emit --showhcuclocks
        args = hy_smi_args_for_show_flags(["showsclk"], wait_idle=False)
        assert "--showhcuclocks" in args
        assert "--showsclk" not in args

    def test_wait_idle_injects_required_metrics(self):
        # Even if only showtemp requested, wait-idle needs showmemuse + showuse
        args = hy_smi_args_for_show_flags(["showtemp"], wait_idle=True)
        assert "--showmemuse" in args
        assert "--showuse" in args

    def test_wait_idle_no_duplication(self):
        # If showmemuse already requested, should not appear twice
        args = hy_smi_args_for_show_flags(["showmemuse", "showuse"], wait_idle=True)
        assert args.count("--showmemuse") == 1
        assert args.count("--showuse") == 1


class TestRenderColumnsForShowFlags:
    def test_showtemp_gives_temp_column(self):
        cols = render_columns_for_show_flags(["showtemp"])
        labels = [c.label for c in cols]
        assert "Temp" in labels

    def test_showuse_gives_avg_column(self):
        cols = render_columns_for_show_flags(["showuse"])
        # showuse has avg_label set → should have two columns (instant + avg)
        assert any(c.avg_label is not None for c in cols)

    def test_order_matches_input(self):
        cols = render_columns_for_show_flags(["showuse", "showtemp"])
        labels = [c.label for c in cols]
        # GPU% (avg) columns come before Temp
        gpu_idx = next(i for i, label in enumerate(labels) if label == "GPU%")
        temp_idx = next(i for i, label in enumerate(labels) if label == "Temp")
        assert gpu_idx < temp_idx
