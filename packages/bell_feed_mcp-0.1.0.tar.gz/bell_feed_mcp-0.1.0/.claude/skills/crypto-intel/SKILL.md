---
name: crypto-intel
description: Get crypto Twitter intelligence from Bell Feed — summaries, signals, trending tokens
user_invocable: true
---

# Crypto Intel — Bell Feed Intelligence

Provide crypto Twitter intelligence from Bell Feed data (data.degendar.com).

## Arguments

- No args or `latest` → Show latest summaries + trading signals
- `trending` → Show trending tokens ranked by mention frequency
- `search <query>` → Search summaries by keyword (e.g., `search SOL`)
- `tldr` → Show today's TL;DR summary

## Execution

### Step 1: Determine Mode

Parse the user's argument to determine which mode to use:
- Default/`latest` → latest summaries
- `trending` → trending tokens
- `search <query>` → keyword search
- `tldr` → daily TL;DR

### Step 2: Fetch Data

**If Bell Feed MCP tools are available** (check for `get_latest_summaries`, `get_trending_tokens`, `get_daily_tldr`, `search_summaries` tools):

- `latest` → call `get_latest_summaries(count=5)`
- `trending` → call `get_trending_tokens(hours=24)`
- `search <query>` → call `search_summaries(query="<query>", max_results=10)`
- `tldr` → call `get_daily_tldr()`

**If MCP tools are NOT available**, fallback to curl:

- `latest` → `curl -s https://data.degendar.com/summaries.json | python3 -c "import sys,json; d=json.load(sys.stdin)[:5]; print(json.dumps(d,ensure_ascii=False,indent=2))"`
- `trending` → `curl -s https://data.degendar.com/summaries.json | python3 -c "
import sys,json
from collections import Counter
from datetime import datetime,timezone
summaries=json.load(sys.stdin)
cutoff=datetime.now(timezone.utc).timestamp()-86400
counts=Counter()
for s in summaries:
    try:
        ts=datetime.fromisoformat(s['timestamp']).timestamp()
    except: continue
    if ts>=cutoff:
        counts.update(s.get('tokens',[]))
for t,c in counts.most_common(20):
    print(f'{t}: {c} mentions')
"`
- `search <query>` → `curl -s https://data.degendar.com/summaries.json | python3 -c "
import sys,json
q='<query>'.lower()
for s in json.load(sys.stdin):
    text=(s.get('summary_text','')+' '+s.get('signals','')+' '+' '.join(s.get('tokens',[]))).lower()
    if q in text:
        print(f\"[{s['id']}] {s.get('summary_text','')[:150]}\")
        if s.get('signals'): print(f'  Signals: {s[\"signals\"]}')
        print()
"`
- `tldr` → `curl -s https://data.degendar.com/daily_tldr.json`

### Step 3: Format Output

Present the results clearly in 繁體中文:

- **Latest**: Show each summary with timestamp, summary text, trading signals, and mentioned tokens
- **Trending**: Show a ranked table of tokens with mention counts
- **Search**: Show matching summaries with highlighted context
- **TL;DR**: Show the daily summary directly
