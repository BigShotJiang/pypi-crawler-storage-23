"""Entry point for running mcp-server-nucleus as a module."""
from mcp_server_nucleus import main

if __name__ == "__main__":
    main()
