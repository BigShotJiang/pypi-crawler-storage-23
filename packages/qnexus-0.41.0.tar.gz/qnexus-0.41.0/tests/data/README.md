# Test programs

This directory contains simple quantum programs used for testing.

The compiled HUGR is stored (alongside the guppy python program) with a `.hugr` extension.

Run `just recompile` in this directory (or `just recompile-test-files` on
the root) to recompile the `.hugr` files.
