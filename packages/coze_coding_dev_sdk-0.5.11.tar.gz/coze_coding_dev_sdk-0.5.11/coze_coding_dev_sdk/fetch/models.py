from typing import Optional, List, Literal
from pydantic import BaseModel, Field


class FetchImage(BaseModel):
    image_url: Optional[str] = Field(None, description="图片原始链接")
    display_url: Optional[str] = Field(None, description="重新签发的外网可见url")
    width: Optional[int] = Field(None, description="宽")
    height: Optional[int] = Field(None, description="高")
    thumbnail_display_url: Optional[str] = Field(None, description="压缩后的外网可见url")


class FetchContentItem(BaseModel):
    type: Literal["image", "link", "text"] = Field(..., description="内容类型")
    text: Optional[str] = Field(None, description="文本结果")
    url: Optional[str] = Field(None, description="type=link时，这里为超链的链接")
    image: Optional[FetchImage] = Field(None, description="图片信息")


class FetchDisplayInfo(BaseModel):
    no_display: Optional[bool] = Field(None, description="是否不可见")
    no_display_reason: Optional[str] = Field(None, description="不可见原因")


class FetchRequest(BaseModel):
    url: str = Field(..., description="要抓取的URL")


class FetchResponse(BaseModel):
    fetch_id: Optional[str] = Field(None, description="抓取ID")
    status_code: Optional[int] = Field(None, description="状态码")
    status_message: Optional[str] = Field(None, description="状态消息")
    url: Optional[str] = Field(None, description="目标或者重定向后的url")
    doc_id: Optional[str] = Field(None, description="文档ID")
    title: Optional[str] = Field(None, description="标题")
    publish_time: Optional[str] = Field(None, description="发布时间")
    filetype: Optional[str] = Field(None, description="文件类型")
    content: List[FetchContentItem] = Field(default_factory=list, description="翻页结果")
    display_info: Optional[FetchDisplayInfo] = Field(None, description="展现信息")
