from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class EdgeFunction:
    id: str
    slug: str
    name: str
    status: str
    version: int
    verify_jwt: bool
    entrypoint_path: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class FunctionFile:
    name: str
    content: str


@dataclass
class Bucket:
    id: str
    name: str
    public: bool
    owner: Optional[str] = None
    file_size_limit: Optional[int] = None
    allowed_mime_types: Optional[List[str]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class AuthEmailConfig:
    external_email_enabled: Optional[bool] = None
    disable_signup: Optional[bool] = None
    mailer_autoconfirm: Optional[bool] = None
    double_confirm_changes: Optional[bool] = None
    mailer_secure_email_change_enabled: Optional[bool] = None
    mailer_otp_exp: Optional[int] = None
    password_min_length: Optional[int] = None
    password_required_characters: Optional[str] = None
    site_url: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_user: Optional[str] = None
    smtp_pass: Optional[str] = None
    smtp_admin_email: Optional[str] = None
    smtp_sender_name: Optional[str] = None
    smtp_max_frequency: Optional[int] = None


@dataclass
class ListEdgeFunctionsResponse:
    functions: List[EdgeFunction] = field(default_factory=list)
    code: int = 0
    msg: str = ""


@dataclass
class GetEdgeFunctionResponse:
    function: Optional[EdgeFunction] = None
    files: List[FunctionFile] = field(default_factory=list)
    code: int = 0
    msg: str = ""


@dataclass
class DeployEdgeFunctionResponse:
    success: bool = False
    slug: Optional[str] = None
    version: Optional[int] = None
    code: int = 0
    msg: str = ""


@dataclass
class DeleteEdgeFunctionResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class ListBucketsResponse:
    buckets: List[Bucket] = field(default_factory=list)
    code: int = 0
    msg: str = ""


@dataclass
class GetBucketResponse:
    bucket: Optional[Bucket] = None
    code: int = 0
    msg: str = ""


@dataclass
class CreateBucketResponse:
    success: bool = False
    bucket_id: Optional[str] = None
    code: int = 0
    msg: str = ""


@dataclass
class UpdateBucketResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class DeleteBucketResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class GetAuthConfigResponse:
    config: Optional[AuthEmailConfig] = None
    code: int = 0
    msg: str = ""


@dataclass
class UpdateAuthConfigResponse:
    success: bool = False
    code: int = 0
    msg: str = ""
