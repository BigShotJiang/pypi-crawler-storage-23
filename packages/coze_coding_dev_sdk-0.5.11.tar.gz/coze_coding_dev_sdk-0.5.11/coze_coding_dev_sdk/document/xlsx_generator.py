import logging
import os
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils.dataframe import dataframe_to_rows

from .models import XLSXConfig
from ..s3 import S3SyncStorage

logger = logging.getLogger(__name__)


class XLSXGenerator:

    def __init__(self, config: Optional[XLSXConfig] = None):
        self.config = config or XLSXConfig()

    def _save_and_upload(self, wb: Workbook, title: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        uniq = uuid.uuid4().hex[:8]
        file_name = f"{title}_{timestamp}_{uniq}.xlsx"
        local_file_path = os.path.join("/tmp", file_name)

        wb.save(local_file_path)

        with open(local_file_path, 'rb') as f:
            xlsx_content = f.read()

        storage = S3SyncStorage()

        file_key = storage.upload_file(
            file_content=xlsx_content,
            file_name=file_name,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

        file_url = storage.generate_presigned_url(key=file_key, expire_time=86400)
        logger.info(f"Generated XLSX: {file_url}")
        return file_url

    def generate_from_dataframe(self, df, title: str, sheet_name: str = "Sheet1") -> str:
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name

        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), 1):
            for c_idx, value in enumerate(row, 1):
                cell = ws.cell(row=r_idx, column=c_idx, value=value)
                if r_idx == 1:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(
                        start_color=self.config.header_bg_color,
                        end_color=self.config.header_bg_color,
                        fill_type="solid",
                    )
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = Border(
                    left=Side(style="thin"),
                    right=Side(style="thin"),
                    top=Side(style="thin"),
                    bottom=Side(style="thin"),
                )

        for column_cells in ws.columns:
            max_length = 0
            column = column_cells[0].column_letter
            for cell in column_cells:
                try:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                except Exception:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column].width = adjusted_width

        return self._save_and_upload(wb, title)

    def generate_from_list_of_dicts(
        self,
        data: List[Dict[str, Any]],
        title: str,
        sheet_name: str = "Sheet1",
    ) -> str:
        if not data:
            wb = Workbook()
            ws = wb.active
            ws.title = sheet_name
            return self._save_and_upload(wb, title)

        headers = list(data[0].keys())

        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name

        for c_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=c_idx, value=header)
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color=self.config.header_bg_color,
                end_color=self.config.header_bg_color,
                fill_type="solid",
            )
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = Border(
                left=Side(style="thin"),
                right=Side(style="thin"),
                top=Side(style="thin"),
                bottom=Side(style="thin"),
            )

        for r_idx, row_data in enumerate(data, 2):
            for c_idx, header in enumerate(headers, 1):
                value = row_data.get(header, "")
                cell = ws.cell(row=r_idx, column=c_idx, value=value)
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = Border(
                    left=Side(style="thin"),
                    right=Side(style="thin"),
                    top=Side(style="thin"),
                    bottom=Side(style="thin"),
                )

        for column_cells in ws.columns:
            max_length = 0
            column = column_cells[0].column_letter
            for cell in column_cells:
                try:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                except Exception:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column].width = adjusted_width

        return self._save_and_upload(wb, title)

    def generate_from_2d_list(
        self,
        data: List[List[Any]],
        title: str,
        sheet_name: str = "Sheet1",
        has_header: bool = True,
    ) -> str:
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name

        for r_idx, row in enumerate(data, 1):
            for c_idx, value in enumerate(row, 1):
                cell = ws.cell(row=r_idx, column=c_idx, value=value)
                if has_header and r_idx == 1:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(
                        start_color=self.config.header_bg_color,
                        end_color=self.config.header_bg_color,
                        fill_type="solid",
                    )
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = Border(
                    left=Side(style="thin"),
                    right=Side(style="thin"),
                    top=Side(style="thin"),
                    bottom=Side(style="thin"),
                )

        for column_cells in ws.columns:
            max_length = 0
            column = column_cells[0].column_letter
            for cell in column_cells:
                try:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                except Exception:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column].width = adjusted_width

        return self._save_and_upload(wb, title)
