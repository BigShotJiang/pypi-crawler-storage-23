import logging
import os
import re
import uuid
from datetime import datetime
from io import BytesIO
from typing import Optional

import markdown
import requests
from bs4 import BeautifulSoup
from PIL import Image as PILImage
from PIL import ImageFile as PILImageFile
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    HRFlowable,
    Image as ReportLabImage,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from .models import DocumentConfig, PDFConfig
from ..s3 import S3SyncStorage

PILImageFile.LOAD_TRUNCATED_IMAGES = True

logger = logging.getLogger(__name__)


class PDFGenerator:

    def __init__(self, config: Optional[PDFConfig] = None):
        self.config = config or PDFConfig()
        self.font_name: Optional[str] = None
        self.alt_font_name: Optional[str] = None
        self._init_fonts()

    def _init_fonts(self) -> None:
        custom_font = DocumentConfig.get_cjk_font_path()
        if custom_font and os.path.exists(custom_font):
            try:
                pdfmetrics.registerFont(TTFont("CustomCJK", custom_font))
                self.font_name = "CustomCJK"
            except Exception:
                self.font_name = None
        else:
            self.font_name = None

        try:
            pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
            if not self.font_name:
                self.font_name = "STSong-Light"
        except Exception:
            pass

        candidates = [
            "/System/Library/Fonts/STHeiti Medium.ttc",
            "/System/Library/Fonts/PingFang.ttc",
            "/System/Library/Fonts/Songti.ttc",
            "/Library/Fonts/Arial Unicode.ttf",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf",
        ]
        for path in candidates:
            try:
                if os.path.exists(path):
                    pdfmetrics.registerFont(TTFont("ChineseFont", path))
                    self.alt_font_name = "ChineseFont"
                    if not self.font_name:
                        self.font_name = "ChineseFont"
            except Exception:
                continue

        if not self.font_name:
            self.font_name = "Helvetica"

    def _download_image(self, url: str) -> Optional[BytesIO]:
        try:
            if url.startswith("file://"):
                local_path = url[7:]
                with open(local_path, "rb") as f:
                    return BytesIO(f.read())

            if url.startswith("data:"):
                import base64

                try:
                    header, b64 = url.split(",", 1)
                    return BytesIO(base64.b64decode(b64))
                except Exception:
                    return None

            if os.path.exists(url):
                with open(url, "rb") as f:
                    return BytesIO(f.read())

            headers = {
                "User-Agent": "Mozilla/5.0 (ReportLab-PDF-Generator)",
                "Accept": "image/*,*/*;q=0.8",
            }
            try:
                response = requests.get(url, timeout=15, headers=headers)
            except requests.exceptions.SSLError:
                response = requests.get(url, timeout=15, headers=headers, verify=False)
            response.raise_for_status()
            return BytesIO(response.content)
        except Exception as e:
            logger.warning(f"Error downloading image {url}: {e}")
            return None

    def _to_raster_png(self, img_bytes: BytesIO) -> Optional[BytesIO]:
        try:
            img_bytes.seek(0)
            head = img_bytes.read(64)
            img_bytes.seek(0)

            if b"<svg" in head or b"<?xml" in head:
                try:
                    import cairosvg

                    out = BytesIO()
                    cairosvg.svg2png(bytestring=img_bytes.read(), write_to=out)
                    out.seek(0)
                    return out
                except Exception as e:
                    logger.warning(f"SVG to PNG conversion failed: {e}")
                    img_bytes.seek(0)

            img = PILImage.open(img_bytes)
            if img.mode not in ("RGB", "RGBA"):
                img = img.convert("RGBA" if "A" in img.getbands() else "RGB")
            out = BytesIO()
            img.save(out, format="PNG")
            out.seek(0)
            return out
        except Exception as e:
            logger.warning(f"Error rasterizing image: {e}")
            return None

    def _format_inline_html(self, element) -> str:
        safe_code_font = (
            self.font_name if self.font_name != "Helvetica" else "Courier"
        )
        soup = BeautifulSoup(
            "".join(str(c) for c in element.contents), "html.parser"
        )

        allowed = {"b", "strong", "i", "em", "code", "sup", "br"}
        for tag in soup.find_all(True):
            name = tag.name
            tag.attrs = {}
            if name in {"strong"}:
                tag.name = "b"
            elif name in {"em"}:
                tag.name = "i"
            elif name == "code":
                tag.name = "font"
                tag["name"] = safe_code_font
            elif name == "sup":
                tag.name = "super"
            elif name == "br":
                tag.name = "br"
            elif name in {"a", "span"}:
                tag.unwrap()
            elif name not in allowed:
                tag.unwrap()

        return "".join(str(c) for c in soup.contents)

    def _choose_font_for_element(self, el) -> Optional[str]:
        ff = None
        if el.has_attr("style"):
            m = re.search(
                r"font-family\s*:\s*([^;]+);?", el["style"], re.IGNORECASE
            )
            if m:
                ff = m.group(1).split(",")[0].strip().strip("\"'")
        if ff:
            if self.alt_font_name and ff:
                return self.alt_font_name
        return self.font_name

    def generate_from_markdown(self, markdown_content: str, title: str) -> str:
        html = markdown.markdown(
            markdown_content, extensions=["tables", "fenced_code", "footnotes"]
        )
        return self.generate_from_html(html, title)

    def generate_from_html(self, html_content: str, title: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        uniq = uuid.uuid4().hex[:8]
        file_name = f"{title}_{timestamp}_{uniq}.pdf"
        local_file_path = os.path.join("/tmp", file_name)

        page_size = A4 if self.config.page_size == "A4" else LETTER
        doc = SimpleDocTemplate(
            local_file_path,
            pagesize=page_size,
            rightMargin=self.config.right_margin,
            leftMargin=self.config.left_margin,
            topMargin=self.config.top_margin,
            bottomMargin=self.config.bottom_margin,
        )

        styles = getSampleStyleSheet()
        if self.font_name != "Helvetica":
            for style_name in styles.byName:
                styles[style_name].fontName = self.font_name

        try:
            styles.add(
                ParagraphStyle(
                    name="Code",
                    fontName=(
                        self.font_name if self.font_name != "Helvetica" else "Courier"
                    ),
                    fontSize=10,
                    backColor=colors.lightgrey,
                )
            )
        except KeyError:
            pass

        try:
            styles.add(
                ParagraphStyle(
                    name="Quote",
                    parent=styles["BodyText"],
                    leftIndent=20,
                    textColor=colors.gray,
                )
            )
        except KeyError:
            pass

        story = []
        soup = BeautifulSoup(
            f"<html><body>{html_content}</body></html>", "html.parser"
        )
        body = soup.body or soup

        for el in body.find_all(recursive=False):
            name = el.name
            if name in ["h1", "h2", "h3", "h4", "h5", "h6"]:
                lvl = int(name[1])
                txt = self._format_inline_html(el)
                style = styles.get(f"Heading{min(lvl, 3)}", styles["Heading3"])
                fn = self._choose_font_for_element(el)
                if fn:
                    txt = f'<font name="{fn}">{txt}</font>'
                story.append(Paragraph(txt, style))

            elif name in ["p", "div"]:
                imgs = el.find_all("img")
                for im in imgs:
                    src = im.get("src")
                    alt = im.get("alt", "")
                    if not src:
                        continue
                    data = self._download_image(src)
                    if data:
                        raster = self._to_raster_png(data)
                        if raster:
                            img = ReportLabImage(raster)
                            avail_width = doc.width
                            iw, ih = img.drawWidth, img.drawHeight
                            if iw > avail_width:
                                r = avail_width / iw
                                img.drawWidth = avail_width
                                img.drawHeight = ih * r
                            story.append(img)
                            story.append(Spacer(1, 6))
                            if alt:
                                story.append(
                                    Paragraph(f"<i>{alt}</i>", styles["BodyText"])
                                )
                                story.append(Spacer(1, 12))

                txt = self._format_inline_html(el)
                if txt.strip():
                    fn = self._choose_font_for_element(el)
                    if fn:
                        txt = f'<font name="{fn}">{txt}</font>'
                    story.append(Paragraph(txt, styles["BodyText"]))

            elif name in ["ul", "ol"]:
                ordered = name == "ol"
                items = el.find_all("li", recursive=False)
                for i, li in enumerate(items, start=1):
                    txt = self._format_inline_html(li)
                    if ordered:
                        fn = self._choose_font_for_element(li)
                        if fn:
                            txt = f'<font name="{fn}">{txt}</font>'
                        story.append(Paragraph(f"{i}. {txt}", styles["BodyText"]))
                    else:
                        fn = self._choose_font_for_element(li)
                        if fn:
                            txt = f'<font name="{fn}">{txt}</font>'
                        story.append(Paragraph(f"• {txt}", styles["Bullet"]))

            elif name == "blockquote":
                txt = self._format_inline_html(el)
                fn = self._choose_font_for_element(el)
                if fn:
                    txt = f'<font name="{fn}">{txt}</font>'
                tbl = Table(
                    [[Paragraph(txt, styles["Quote"])]], colWidths=[doc.width]
                )
                tbl.setStyle(
                    TableStyle(
                        [
                            ("LINEBEFORE", (0, 0), (0, 0), 2, colors.lightgrey),
                            ("LEFTPADDING", (0, 0), (0, 0), 12),
                            ("BACKGROUND", (0, 0), (0, 0), colors.whitesmoke),
                        ]
                    )
                )
                story.append(tbl)
                story.append(Spacer(1, 8))

            elif name == "hr":
                story.append(
                    HRFlowable(width="100%", thickness=1, color=colors.lightgrey)
                )
                story.append(Spacer(1, 8))

            elif name == "pre":
                code_el = el.find("code") or el
                code_text = code_el.get_text()
                fn = self._choose_font_for_element(code_el)
                pf = Preformatted(code_text, styles["Code"])
                if fn:
                    pf.style.fontName = fn
                story.append(pf)
                story.append(Spacer(1, 8))

            elif name == "table":
                rows = []
                for tr in el.find_all("tr"):
                    cells = [
                        self._format_inline_html(td)
                        for td in tr.find_all(["th", "td"])
                    ]
                    if cells:
                        rows.append(cells)
                if rows:
                    col_count = len(rows[0])
                    tbl = Table(rows, colWidths=[doc.width / col_count] * col_count)
                    ts = [
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.lightgrey),
                        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                        ("FONTNAME", (0, 0), (-1, -1), self.font_name or "Helvetica"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 6),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                        ("TOPPADDING", (0, 0), (-1, -1), 4),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ]
                    tbl.setStyle(TableStyle(ts))
                    story.append(tbl)
                    story.append(Spacer(1, 12))

            elif name == "img":
                src = el.get("src")
                alt = el.get("alt", "")
                data = self._download_image(src) if src else None
                if data:
                    raster = self._to_raster_png(data)
                    if raster:
                        img = ReportLabImage(raster)
                        avail_width = doc.width
                        iw, ih = img.drawWidth, img.drawHeight
                        if iw > avail_width:
                            r = avail_width / iw
                            img.drawWidth = avail_width
                            img.drawHeight = ih * r
                        story.append(img)
                        story.append(Spacer(1, 6))
                        if alt:
                            story.append(
                                Paragraph(f"<i>{alt}</i>", styles["BodyText"])
                            )
                            story.append(Spacer(1, 12))

        foot = body.find("div", class_="footnote")
        if foot:
            story.append(Paragraph("<b>参考</b>", styles["Heading2"]))
            ol = foot.find("ol")
            if ol:
                for i, li in enumerate(ol.find_all("li", recursive=False), start=1):
                    txt = self._format_inline_html(li)
                    fn = self._choose_font_for_element(li)
                    if fn:
                        txt = f'<font name="{fn}">{txt}</font>'
                    story.append(Paragraph(f"{i}. {txt}", styles["BodyText"]))

        doc.build(story)

        with open(local_file_path, 'rb') as f:
            pdf_content = f.read()

        storage = S3SyncStorage()

        file_key = storage.upload_file(
            file_content=pdf_content,
            file_name=file_name,
            content_type="application/pdf"
        )

        file_url = storage.generate_presigned_url(key=file_key, expire_time=86400)
        logger.info(f"Generated PDF: {file_url}")
        return file_url
