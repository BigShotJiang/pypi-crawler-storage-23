import logging
from typing import Any, Dict, List, Optional, Union

from .docx_generator import DOCXGenerator
from .models import DOCXConfig, DocumentFormat, PDFConfig, PPTXConfig, XLSXConfig
from .pdf_generator import PDFGenerator
from .pptx_generator import PPTXGenerator
from .xlsx_generator import XLSXGenerator

logger = logging.getLogger(__name__)


class DocumentGenerationClient:

    def __init__(
        self,
        pdf_config: Optional[PDFConfig] = None,
        docx_config: Optional[DOCXConfig] = None,
        pptx_config: Optional[PPTXConfig] = None,
        xlsx_config: Optional[XLSXConfig] = None,
    ):
        self._pdf_generator: Optional[PDFGenerator] = None
        self._docx_generator: Optional[DOCXGenerator] = None
        self._pptx_generator: Optional[PPTXGenerator] = None
        self._xlsx_generator: Optional[XLSXGenerator] = None
        self._pdf_config = pdf_config
        self._docx_config = docx_config
        self._pptx_config = pptx_config
        self._xlsx_config = xlsx_config

    @property
    def pdf_generator(self) -> PDFGenerator:
        if self._pdf_generator is None:
            self._pdf_generator = PDFGenerator(self._pdf_config)
        return self._pdf_generator

    @property
    def docx_generator(self) -> DOCXGenerator:
        if self._docx_generator is None:
            self._docx_generator = DOCXGenerator(self._docx_config)
        return self._docx_generator

    @property
    def pptx_generator(self) -> PPTXGenerator:
        if self._pptx_generator is None:
            self._pptx_generator = PPTXGenerator(self._pptx_config)
        return self._pptx_generator

    @property
    def xlsx_generator(self) -> XLSXGenerator:
        if self._xlsx_generator is None:
            self._xlsx_generator = XLSXGenerator(self._xlsx_config)
        return self._xlsx_generator

    def create_pdf_from_markdown(self, markdown_content: str, title: str) -> str:
        return self.pdf_generator.generate_from_markdown(markdown_content, title)

    def create_pdf_from_html(self, html_content: str, title: str) -> str:
        return self.pdf_generator.generate_from_html(html_content, title)

    def create_docx_from_markdown(self, markdown_content: str, title: str) -> str:
        return self.docx_generator.generate_from_markdown(markdown_content, title)

    def create_docx_from_html(self, html_content: str, title: str) -> str:
        return self.docx_generator.generate_from_html(html_content, title)

    def create_pptx_from_markdown(self, markdown_content: str, title: str) -> str:
        return self.pptx_generator.generate_from_markdown(markdown_content, title)

    def create_pptx_from_html_file(
        self, html_file_path: Union[str, List[str]], title: str
    ) -> str:
        return self.pptx_generator.generate_from_html(html_file_path, title)

    def create_pptx_from_html(
        self, html_content: Union[str, List[str]], title: str
    ) -> str:
        return self.pptx_generator.generate_from_html_content(html_content, title)

    def get_pptx_inventory(self, pptx_path: str, issues_only: bool = False) -> Dict[str, Any]:
        return self.pptx_generator.get_inventory_as_dict(pptx_path, issues_only=issues_only)

    def replace_pptx_text(
        self,
        pptx_path: str,
        replacements: Dict[str, Any],
        title: str,
        validate_overflow: bool = True,
    ) -> str:
        return self.pptx_generator.apply_replacements(
            pptx_path, replacements, title, validate_overflow=validate_overflow
        )

    def rearrange_pptx_slides(
        self,
        pptx_path: str,
        title: str,
        slide_sequence: List[int],
    ) -> str:
        return self.pptx_generator.rearrange_slides(pptx_path, title, slide_sequence)

    def create_xlsx_from_dataframe(self, df, title: str, sheet_name: str = "Sheet1") -> str:
        return self.xlsx_generator.generate_from_dataframe(df, title, sheet_name)

    def create_xlsx_from_list(
        self,
        data: List[Dict[str, Any]],
        title: str,
        sheet_name: str = "Sheet1",
    ) -> str:
        return self.xlsx_generator.generate_from_list_of_dicts(data, title, sheet_name)

    def create_xlsx_from_2d_list(
        self,
        data: List[List[Any]],
        title: str,
        sheet_name: str = "Sheet1",
        has_header: bool = True,
    ) -> str:
        return self.xlsx_generator.generate_from_2d_list(data, title, sheet_name, has_header)

    def create_xlsx(
        self,
        data: Union[List[Dict[str, Any]], List[List[Any]]],
        title: str,
        sheet_name: str = "Sheet1",
    ) -> str:
        if data and isinstance(data[0], dict):
            return self.create_xlsx_from_list(data, title, sheet_name)
        else:
            return self.create_xlsx_from_2d_list(data, title, sheet_name)

    def generate(
        self,
        content: str,
        title: str,
        format: DocumentFormat = DocumentFormat.PDF,
        content_type: str = "markdown",
    ) -> str:
        if format == DocumentFormat.PDF:
            if content_type == "markdown":
                return self.create_pdf_from_markdown(content, title)
            else:
                return self.create_pdf_from_html(content, title)
        elif format == DocumentFormat.DOCX:
            if content_type == "markdown":
                return self.create_docx_from_markdown(content, title)
            else:
                return self.create_docx_from_html(content, title)
        elif format == DocumentFormat.PPTX:
            if content_type == "markdown":
                return self.create_pptx_from_markdown(content, title)
            else:
                return self.create_pptx_from_html(content, title)
        else:
            raise ValueError(f"Unsupported format: {format}")
