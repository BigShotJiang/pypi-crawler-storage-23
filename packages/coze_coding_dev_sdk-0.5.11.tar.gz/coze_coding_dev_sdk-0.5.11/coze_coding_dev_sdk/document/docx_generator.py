import hashlib
import logging
import os
import re
import uuid
from datetime import datetime
from io import BytesIO
from typing import Optional

import markdown
import requests
from bs4 import BeautifulSoup
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt

from .models import DOCXConfig, DocumentConfig
from ..s3 import S3SyncStorage

logger = logging.getLogger(__name__)


class DOCXGenerator:

    def __init__(self, config: Optional[DOCXConfig] = None):
        self.config = config or DOCXConfig()
        self.doc: Optional[Document] = None
        self.font_name = self.config.font_name

    def _init_document(self) -> None:
        self.doc = Document()
        self._init_styles()
        sec = self.doc.sections[0]
        sec.top_margin = Inches(self.config.top_margin)
        sec.bottom_margin = Inches(self.config.bottom_margin)
        sec.left_margin = Inches(self.config.left_margin)
        sec.right_margin = Inches(self.config.right_margin)

    def _init_styles(self) -> None:
        if self.doc is None:
            return

        style = self.doc.styles["Normal"]
        font = style.font
        font.name = self.font_name
        font.size = Pt(self.config.font_size)

        for level in [1, 2, 3]:
            h = self.doc.styles[f"Heading {level}"]
            hf = h.font
            hf.name = self.font_name

        if "Code" not in self.doc.styles:
            self.doc.styles.add_style("Code", 1)
        self.doc.styles["Code"].font.name = "Courier New"
        self.doc.styles["Code"].font.size = Pt(10)

    def _download_image(self, url: str) -> Optional[BytesIO]:
        try:
            if url.startswith("file://"):
                p = url[7:]
                with open(p, "rb") as f:
                    return BytesIO(f.read())
            if os.path.exists(url):
                with open(url, "rb") as f:
                    return BytesIO(f.read())
            r = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            return BytesIO(r.content)
        except Exception as e:
            logger.warning(f"Error downloading image {url}: {e}")
            return None

    def generate_from_markdown(self, markdown_content: str, title: str) -> str:
        html = markdown.markdown(
            markdown_content, extensions=["tables", "fenced_code", "footnotes"]
        )
        return self.generate_from_html(html, title)

    def generate_from_html(self, html: str, title: str) -> str:
        self._init_document()
        if self.doc is None:
            raise RuntimeError("Document initialization failed")

        soup = BeautifulSoup(f"<html><body>{html}</body></html>", "html.parser")
        body = soup.body or soup

        for el in body.find_all(recursive=False):
            name = el.name
            if name in ["h1", "h2", "h3"]:
                level = int(name[1])
                p = self.doc.add_heading("", level=level)
                self._add_runs_from_element(p, el)
                p.paragraph_format.space_before = Pt(6)
                p.paragraph_format.space_after = Pt(6)

            elif name in ["p", "div"]:
                imgs = el.find_all("img")
                for im in imgs:
                    src = im.get("src")
                    if src:
                        data = self._download_image(src)
                        if data:
                            self.doc.add_picture(data, width=Inches(5.5))
                            self.doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

                if el.get_text().strip():
                    p = self.doc.add_paragraph()
                    p.style = self.doc.styles["Normal"]
                    self._add_runs_from_element(p, el)
                    p.paragraph_format.line_spacing = 1.5
                    p.paragraph_format.space_after = Pt(8)

            elif name in ["ul", "ol"]:
                ordered = name == "ol"
                for li in el.find_all("li", recursive=False):
                    p = self.doc.add_paragraph(
                        style=("List Number" if ordered else "List Bullet")
                    )
                    self._add_runs_from_element(p, li)
                    p.paragraph_format.line_spacing = 1.5
                    p.paragraph_format.space_after = Pt(2)

            elif name == "blockquote":
                p = self.doc.add_paragraph()
                p.paragraph_format.left_indent = Inches(0.3)
                self._add_runs_from_element(p, el)
                p.paragraph_format.line_spacing = 1.5
                p.paragraph_format.space_after = Pt(6)

            elif name == "pre":
                code_el = el.find("code") or el
                p = self.doc.add_paragraph()
                r = p.add_run(code_el.get_text())
                p.style = self.doc.styles["Code"]
                try:
                    r.font.name = "Courier New"
                    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Courier New")
                except Exception:
                    pass
                p.paragraph_format.space_before = Pt(4)
                p.paragraph_format.space_after = Pt(8)

            elif name == "table":
                rows = []
                for tr in el.find_all("tr"):
                    cells = [td.get_text() for td in tr.find_all(["th", "td"])]
                    if cells:
                        rows.append(cells)
                if rows:
                    t = self.doc.add_table(rows=len(rows), cols=len(rows[0]))
                    t.style = "Light Shading Accent 1"
                    t.autofit = True
                    header = True if el.find("thead") or el.find("th") else False
                    for r_i, row in enumerate(rows):
                        for c_i, cell in enumerate(row):
                            c = t.cell(r_i, c_i)
                            c.text = cell
                            if header and r_i == 0:
                                for pr in c.paragraphs:
                                    for run in pr.runs:
                                        run.bold = True
                            tcPr = c._tc.get_or_add_tcPr()
                            shd = OxmlElement("w:shd")
                            shd.set(qn("w:fill"), "FFFFFF")
                            tcPr.append(shd)

        # 生成唯一的文件名：使用时间戳和MD5
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        uniq = uuid.uuid4().hex[:8]
        file_name = f"{title}_{timestamp}_{uniq}.docx"
        local_file_path = os.path.join("/tmp", file_name)

        # 将文档保存到本地临时文件
        self.doc.save(local_file_path)

        # 读取文档内容
        with open(local_file_path, 'rb') as f:
            docx_content = f.read()

        # 初始化对象存储客户端
        storage = S3SyncStorage()

        # 上传到对象存储
        file_key = storage.upload_file(
            file_content=docx_content,
            file_name=file_name,
            content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

        # 生成签名URL（24小时有效期）
        file_url = storage.generate_presigned_url(key=file_key, expire_time=86400)
        logger.info(f"Generated DOCX: {file_url}")
        return file_url

    def _add_runs_from_element(self, paragraph, element) -> None:
        safe_code_font = "Courier New"

        def _clean_text(s):
            return re.sub(r"\s+", " ", s or "").strip()

        for node in element.contents:
            if getattr(node, "name", None) is None:
                txt = _clean_text(str(node))
                if txt:
                    r = paragraph.add_run(txt)
                    try:
                        r.font.name = self.font_name
                        r._element.rPr.rFonts.set(qn("w:eastAsia"), self.font_name)
                    except Exception:
                        pass
            else:
                tag = node.name.lower()
                if tag == "code":
                    txt = (node.get_text() or "").replace("\r", " ").replace("\n", " ")
                else:
                    txt = _clean_text(node.get_text())
                if not txt:
                    continue
                r = paragraph.add_run(txt)
                if tag in ["strong", "b"]:
                    r.bold = True
                elif tag in ["em", "i"]:
                    r.italic = True
                elif tag == "code":
                    r.font.name = safe_code_font
                    try:
                        r._element.rPr.rFonts.set(qn("w:eastAsia"), safe_code_font)
                    except Exception:
                        pass
                else:
                    try:
                        r.font.name = self.font_name
                        r._element.rPr.rFonts.set(qn("w:eastAsia"), self.font_name)
                    except Exception:
                        pass
