__version__ = "2.0.17"
__author__ = "Miu Lun Lau, Jeff Terry, Min Long"
__email__ = "andylau@u.boisestate.edu, jterry98@iit.edu, minlong@boisestate.edu"
