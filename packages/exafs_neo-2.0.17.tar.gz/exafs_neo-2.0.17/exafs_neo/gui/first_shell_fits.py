"""
1. Read atoms specific for feff
Reuqirements:
     - Absorbing Atoms (Hf, etc)
     - Absorbing Edge (K, L)
     - Scattering Atoms ( O, etc)
     - Distance (2.0 A )
     - Coordinate (4,6 coordinate, sqaure planar, octahedral, tetrahedral)

2. Calculate

"""
