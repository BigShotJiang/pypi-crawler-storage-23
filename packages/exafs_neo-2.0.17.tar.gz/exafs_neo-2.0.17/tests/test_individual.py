import unittest
from exafs_neo.individual import Individual


class TestIndividual(unittest.TestCase):

    def test_individual(self):
        pass

    def test_individual_return(self):
        pass

    def test_individual_verbose(self):
        pass

    def test_individual_verbose_ytotal(self):
        pass

    def test_individual_len(self):
        pass

    def test_individual_str(self):
        pass


class TestIndividualGet(unittest.TestCase):

    def test_individual_get(self):
        pass

    def test_individual_get_var(self):
        pass

    def test_individual_get_e0(self):
        pass

    def test_individual_get_path(self):
        pass


class TestIndividualSet(unittest.TestCase):

    def test_individual_set_path(self):
        pass

    def test_individual_set_all_path(self):
        pass

    def test_individual_set_e0(self):
        pass


class TestIndividualMutate(unittest.TestCase):

    def test_individual_mutate_path(self):
        pass


# add assertion here


if __name__ == '__main__':
    unittest.main()
