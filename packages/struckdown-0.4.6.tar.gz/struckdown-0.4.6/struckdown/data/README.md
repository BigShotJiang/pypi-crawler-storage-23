This directory contains sample text files for testing purposes only.
