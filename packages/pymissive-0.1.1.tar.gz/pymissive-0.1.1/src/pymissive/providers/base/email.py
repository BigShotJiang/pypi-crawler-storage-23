class EmailMixin:
    """Mixin for email."""
