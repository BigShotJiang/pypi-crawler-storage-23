class NotificationMixin:
    """Mixin for notifications."""
