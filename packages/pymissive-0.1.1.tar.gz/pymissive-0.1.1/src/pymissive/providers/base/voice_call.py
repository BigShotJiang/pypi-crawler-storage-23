class VoiceCallMixin:
    """Mixin for voice call."""
