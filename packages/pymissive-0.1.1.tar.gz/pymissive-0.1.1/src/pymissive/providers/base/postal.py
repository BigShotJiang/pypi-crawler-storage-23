class PostalMixin:
    """Mixin for postal."""
