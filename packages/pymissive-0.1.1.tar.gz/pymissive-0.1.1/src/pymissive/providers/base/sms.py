class SMSMixin:
    """Mixin for SMS."""
