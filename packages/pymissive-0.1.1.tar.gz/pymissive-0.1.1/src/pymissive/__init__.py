"""Python Missive - Framework-agnostic messaging library."""

__version__ = "0.1.1"
