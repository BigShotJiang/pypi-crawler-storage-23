class OMMXHighsAdapterError(Exception):
    pass
