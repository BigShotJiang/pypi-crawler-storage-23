# Legacy Instructions Relocated

> **⚠️ This file has been decommissioned for improved context window efficiency.**

## New Documentation Structure

SDK-specific instructions have been moved to:

**Primary Skill**: [`services/client/.claude/skills/sdk-delivery/SKILL.md`](../.claude/skills/sdk-delivery/SKILL.md)

This skill contains:

- Auto-generation boundaries (never edit api.py, client.py, models.py)
- Manager/Runner patterns
- Regeneration workflow
- Job dependency ordering
- Dual parameter systems (k vs open_dp_epsilon)
- Notebook development and testing
- Processor patterns

## Also Consult

- [`AGENTS.md`](../../../AGENTS.md) - Monorepo architecture and rules
- [`SKILLS_CATALOG.md`](../../../SKILLS_CATALOG.md) - Task→skill lookup
- [`.claude/skills/python-standards/SKILL.md`](../../../.claude/skills/python-standards/SKILL.md) - Coding standards
- [`.claude/skills/testing-strategy/SKILL.md`](../../../.claude/skills/testing-strategy/SKILL.md) - Testing patterns
