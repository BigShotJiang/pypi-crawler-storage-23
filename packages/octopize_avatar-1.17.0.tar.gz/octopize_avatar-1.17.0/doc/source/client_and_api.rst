.. This file has been deprecated and its content merged into api_reference.rst.
.. Kept as an empty placeholder to avoid broken links in older versions.
.. It is excluded via conf.py exclude_patterns.

Deprecated - use api_reference.rst instead
==========================================

This page has been superseded by the consolidated ``Detailed doc`` page.
