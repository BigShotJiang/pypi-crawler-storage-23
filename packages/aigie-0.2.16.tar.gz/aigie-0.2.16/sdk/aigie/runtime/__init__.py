"""
Aigie Runtime Module - Real-time span interception and remediation.

This module provides runtime capabilities for intercepting spans,
detecting issues, and applying remediation at the step level.
"""

from .remediation_loop import (
    OperationalMode,
    RemediationConfig,
    RemediationLoop,
    RemediationResult,
    RemediationStrategy,
    WorkflowPattern,
)
from .span_interceptor import (
    SpanDecision,
    SpanInterceptionResult,
    SpanInterceptor,
    SpanInterceptorConfig,
)

__all__ = [
    # Span Interceptor
    "SpanInterceptor",
    "SpanInterceptorConfig",
    "SpanDecision",
    "SpanInterceptionResult",
    # Remediation Loop
    "RemediationLoop",
    "RemediationConfig",
    "RemediationResult",
    "RemediationStrategy",
    "OperationalMode",
    "WorkflowPattern",
]
