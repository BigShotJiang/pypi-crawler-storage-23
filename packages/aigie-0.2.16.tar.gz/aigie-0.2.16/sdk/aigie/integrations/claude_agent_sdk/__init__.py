"""
Claude Agent SDK integration for Aigie.

This module provides automatic tracing for the official Anthropic Claude Agent SDK,
capturing query execution, tool usage, and conversation sessions.

Usage (Auto-Instrumentation - Recommended):
    from aigie.integrations.claude_agent_sdk import patch_claude_agent_sdk
    patch_claude_agent_sdk()  # Patches query(), ClaudeSDKClient, etc.

    from claude_agent_sdk import query
    result = await query("What is the capital of France?")  # Automatically traced!

Usage (Manual Handler):
    from aigie.integrations.claude_agent_sdk import ClaudeAgentSDKHandler

    handler = ClaudeAgentSDKHandler(trace_name="my-agent")
    # ... use with claude_agent_sdk

Usage (Session Management):
    from aigie.integrations.claude_agent_sdk import claude_session

    with claude_session("My Agent"):
        await query("First question")
        await query("Follow-up")  # Shares same trace

Usage (Error Detection):
    from aigie.integrations.claude_agent_sdk import get_error_detector

    detector = get_error_detector()
    print(detector.get_stats())

Usage (Drift Detection):
    from aigie.integrations.claude_agent_sdk import get_drift_detector

    detector = get_drift_detector()
    detector.capture_system_prompt("You are a helpful assistant...")
    # ... run queries ...
    print(detector.get_drift_report())
"""

from typing import TYPE_CHECKING, Any

__all__ = [
    # Handler
    "ClaudeAgentSDKHandler",
    # Configuration
    "ClaudeAgentSDKConfig",
    # Auto-instrumentation
    "patch_claude_agent_sdk",
    "unpatch_claude_agent_sdk",
    "is_claude_agent_sdk_patched",
    # Cost tracking
    "calculate_claude_cost",
    "CLAUDE_MODEL_PRICING",
    # Session management
    "ClaudeSessionContext",
    "claude_session",
    "get_session_context",
    "get_or_create_session_context",
    "clear_session_context",
    # Retry utilities
    "RetryContext",
    "RetryExhaustedError",
    "TimeoutExceededError",
    "AgentExecutionError",
    "retry_decorator",
    "with_timeout",
    "with_retry",
    # Error detection
    "ErrorDetector",
    "ErrorType",
    "ErrorSeverity",
    "DetectedError",
    "ErrorStats",
    "get_error_detector",
    "reset_error_detector",
    # Drift detection
    "DriftDetector",
    "DriftType",
    "DriftSeverity",
    "DetectedDrift",
    "AgentPlan",
    "ExecutionTrace",
    "get_drift_detector",
    "reset_drift_detector",
    # Utilities
    "mask_sensitive_data",
    "safe_str",
    "mask_dict_keys",
    "extract_text_from_content",
    "extract_tool_uses",
    "extract_tool_results",
    "serialize_message",
    "serialize_messages",
    "extract_usage",
    "is_result_message",
    "get_message_type",
    "truncate_text",
    "SENSITIVE_PATTERNS",
]


def __getattr__(name: str) -> Any:
    """Lazy imports for performance."""

    # Handler
    if name == "ClaudeAgentSDKHandler":
        from .handler import ClaudeAgentSDKHandler

        return ClaudeAgentSDKHandler

    # Configuration
    if name == "ClaudeAgentSDKConfig":
        from .config import ClaudeAgentSDKConfig

        return ClaudeAgentSDKConfig

    # Auto-instrumentation
    if name == "patch_claude_agent_sdk":
        from .auto_instrument import patch_claude_agent_sdk

        return patch_claude_agent_sdk

    if name == "unpatch_claude_agent_sdk":
        from .auto_instrument import unpatch_claude_agent_sdk

        return unpatch_claude_agent_sdk

    if name == "is_claude_agent_sdk_patched":
        from .auto_instrument import is_claude_agent_sdk_patched

        return is_claude_agent_sdk_patched

    # Cost tracking
    if name == "calculate_claude_cost":
        from .cost_tracking import calculate_claude_cost

        return calculate_claude_cost

    if name == "CLAUDE_MODEL_PRICING":
        from .cost_tracking import CLAUDE_MODEL_PRICING

        return CLAUDE_MODEL_PRICING

    # Session management
    if name == "ClaudeSessionContext":
        from .session_context import ClaudeSessionContext

        return ClaudeSessionContext

    if name == "claude_session":
        from .session_context import claude_session

        return claude_session

    if name == "get_session_context":
        from .session_context import get_session_context

        return get_session_context

    if name == "get_or_create_session_context":
        from .session_context import get_or_create_session_context

        return get_or_create_session_context

    if name == "clear_session_context":
        from .session_context import clear_session_context

        return clear_session_context

    # Retry utilities
    if name == "RetryContext":
        from .retry import RetryContext

        return RetryContext

    if name == "RetryExhaustedError":
        from .retry import RetryExhaustedError

        return RetryExhaustedError

    if name == "TimeoutExceededError":
        from .retry import TimeoutExceededError

        return TimeoutExceededError

    if name == "AgentExecutionError":
        from .retry import AgentExecutionError

        return AgentExecutionError

    if name == "retry_decorator":
        from .retry import retry_decorator

        return retry_decorator

    if name == "with_timeout":
        from .retry import with_timeout

        return with_timeout

    if name == "with_retry":
        from .retry import with_retry

        return with_retry

    # Error detection
    if name == "ErrorDetector":
        from .error_detection import ErrorDetector

        return ErrorDetector

    if name == "ErrorType":
        from .error_detection import ErrorType

        return ErrorType

    if name == "ErrorSeverity":
        from .error_detection import ErrorSeverity

        return ErrorSeverity

    if name == "DetectedError":
        from .error_detection import DetectedError

        return DetectedError

    if name == "ErrorStats":
        from .error_detection import ErrorStats

        return ErrorStats

    if name == "get_error_detector":
        from .error_detection import get_error_detector

        return get_error_detector

    if name == "reset_error_detector":
        from .error_detection import reset_error_detector

        return reset_error_detector

    # Drift detection
    if name == "DriftDetector":
        from .drift_detection import DriftDetector

        return DriftDetector

    if name == "DriftType":
        from .drift_detection import DriftType

        return DriftType

    if name == "DriftSeverity":
        from .drift_detection import DriftSeverity

        return DriftSeverity

    if name == "DetectedDrift":
        from .drift_detection import DetectedDrift

        return DetectedDrift

    if name == "AgentPlan":
        from .drift_detection import AgentPlan

        return AgentPlan

    if name == "ExecutionTrace":
        from .drift_detection import ExecutionTrace

        return ExecutionTrace

    if name == "get_drift_detector":
        from .drift_detection import get_drift_detector

        return get_drift_detector

    if name == "reset_drift_detector":
        from .drift_detection import reset_drift_detector

        return reset_drift_detector

    # Utilities
    if name == "mask_sensitive_data":
        from .utils import mask_sensitive_data

        return mask_sensitive_data

    if name == "safe_str":
        from .utils import safe_str

        return safe_str

    if name == "mask_dict_keys":
        from .utils import mask_dict_keys

        return mask_dict_keys

    if name == "extract_text_from_content":
        from .utils import extract_text_from_content

        return extract_text_from_content

    if name == "extract_tool_uses":
        from .utils import extract_tool_uses

        return extract_tool_uses

    if name == "extract_tool_results":
        from .utils import extract_tool_results

        return extract_tool_results

    if name == "serialize_message":
        from .utils import serialize_message

        return serialize_message

    if name == "serialize_messages":
        from .utils import serialize_messages

        return serialize_messages

    if name == "extract_usage":
        from .utils import extract_usage

        return extract_usage

    if name == "is_result_message":
        from .utils import is_result_message

        return is_result_message

    if name == "get_message_type":
        from .utils import get_message_type

        return get_message_type

    if name == "truncate_text":
        from .utils import truncate_text

        return truncate_text

    if name == "SENSITIVE_PATTERNS":
        from .utils import SENSITIVE_PATTERNS

        return SENSITIVE_PATTERNS

    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


if TYPE_CHECKING:
    from .auto_instrument import (
        is_claude_agent_sdk_patched,
        patch_claude_agent_sdk,
        unpatch_claude_agent_sdk,
    )
    from .config import ClaudeAgentSDKConfig
    from .cost_tracking import CLAUDE_MODEL_PRICING, calculate_claude_cost
    from .drift_detection import (
        AgentPlan,
        DetectedDrift,
        DriftDetector,
        DriftSeverity,
        DriftType,
        ExecutionTrace,
        get_drift_detector,
        reset_drift_detector,
    )
    from .error_detection import (
        DetectedError,
        ErrorDetector,
        ErrorSeverity,
        ErrorStats,
        ErrorType,
        get_error_detector,
        reset_error_detector,
    )
    from .handler import ClaudeAgentSDKHandler
    from .retry import (
        AgentExecutionError,
        RetryContext,
        RetryExhaustedError,
        TimeoutExceededError,
        retry_decorator,
        with_retry,
        with_timeout,
    )
    from .session_context import (
        ClaudeSessionContext,
        claude_session,
        clear_session_context,
        get_or_create_session_context,
        get_session_context,
    )
    from .utils import (
        SENSITIVE_PATTERNS,
        extract_text_from_content,
        extract_tool_results,
        extract_tool_uses,
        extract_usage,
        get_message_type,
        is_result_message,
        mask_dict_keys,
        mask_sensitive_data,
        safe_str,
        serialize_message,
        serialize_messages,
        truncate_text,
    )
