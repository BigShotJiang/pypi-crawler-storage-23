"""
Aigie Realtime Module - Backend connector for real-time interception.

This module provides WebSocket-based communication with the Aigie backend
for real-time consultation, fix application, and leveraging historical data.
"""

from .auto_fix import AutoFixApplicator, FixConfig, FixResult, FixStrategy
from .base_ws import BaseWebSocketClient, ConnectionState
from .connector import BackendConnector
from .remediation_engine import (
    ErrorClassifier,
    RemediationConfig,
    RemediationEngine,
    RemediationResult,
)

__all__ = [
    "AutoFixApplicator",
    "BackendConnector",
    "BaseWebSocketClient",
    "ConnectionState",
    "ErrorClassifier",
    "FixConfig",
    "FixResult",
    "FixStrategy",
    "RemediationConfig",
    "RemediationEngine",
    "RemediationResult",
]
