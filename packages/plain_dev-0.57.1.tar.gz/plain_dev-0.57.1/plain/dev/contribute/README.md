## FAQs

### What if the plain cli isn't working?

When working on packages locally you can sometimes end up in a weird state where Plain can't load. The `plain contrib` command is also available as `plain-contrib`, which won't go through any of the setup processes for Plain, so you can always run that directly if you need to.
