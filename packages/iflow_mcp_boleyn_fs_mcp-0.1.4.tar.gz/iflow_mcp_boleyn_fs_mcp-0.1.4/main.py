#!/usr/bin/env python
"""
简化的MCP服务器启动脚本
"""
import sys
import os
import logging

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 简单的日志配置
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# 设置环境变量
os.environ.setdefault('SAFE_DIRECTORY', os.path.dirname(os.path.abspath(__file__)))

try:
    from dotenv import load_dotenv
    load_dotenv()
    
    from fastmcp import FastMCP
    from src import UniversalFileReader, DocumentCache, FileConverter
    from src.dir_tree import get_dir_tree_markdown
    
    import asyncio
    from pathlib import Path
    
    mcp = FastMCP("简化文件读取 MCP 服务器")
    
    @mcp.tool("view_directory_tree")
    async def view_directory_tree(directory_path: str = ".", max_depth: int = 3, max_entries: int = 300) -> str:
        """查看目录树结构"""
        try:
            file_reader = UniversalFileReader()
            safe_directory = file_reader.validator.get_safe_directory()
            
            if os.path.isabs(directory_path):
                abs_path = str(Path(directory_path).resolve())
            else:
                safe_path = Path(safe_directory).resolve()
                target_path = safe_path / directory_path
                abs_path = str(target_path.resolve())
            
            if not os.path.exists(abs_path):
                return f"❌ 路径不存在: {abs_path}"
            if not os.path.isdir(abs_path):
                return f"❌ 不是目录: {abs_path}"
            
            safe_abs = Path(safe_directory).resolve()
            target_abs = Path(abs_path).resolve()
            try:
                target_abs.relative_to(safe_abs)
            except ValueError:
                return f"❌ 路径不在安全目录内"
            
            tree_content = await asyncio.get_event_loop().run_in_executor(
                None, lambda: get_dir_tree_markdown(abs_path, max_depth, max_entries)
            )
            return f"🌳 目录: {abs_path}\n\n{tree_content}"
        except Exception as e:
            return f"❌ 错误: {str(e)}"
    
    @mcp.tool("list_files")
    async def list_files(directory_path: str = ".", pattern: str = "*", include_size: bool = True) -> str:
        """列出目录中的文件"""
        try:
            file_reader = UniversalFileReader()
            safe_directory = file_reader.validator.get_safe_directory()
            
            if os.path.isabs(directory_path):
                abs_path = str(Path(directory_path).resolve())
            else:
                safe_path = Path(safe_directory).resolve()
                target_path = safe_path / directory_path
                abs_path = str(target_path.resolve())
            
            if not os.path.exists(abs_path):
                return f"❌ 路径不存在: {abs_path}"
            if not os.path.isdir(abs_path):
                return f"❌ 不是目录: {abs_path}"
            
            safe_abs = Path(safe_directory).resolve()
            target_abs = Path(abs_path).resolve()
            try:
                target_abs.relative_to(safe_abs)
            except ValueError:
                return f"❌ 路径不在安全目录内"
            
            import glob
            pattern_path = os.path.join(abs_path, pattern)
            files = glob.glob(pattern_path)
            files = [f for f in files if os.path.isfile(f)]
            files.sort()
            
            if not files:
                return f"📁 目录: {abs_path}\n无匹配的文件"
            
            result = f"📁 目录: {abs_path}\n📄 文件列表 ({len(files)}个文件):\n{'=' * 50}\n"
            for file_path in files:
                rel_path = os.path.relpath(file_path, abs_path)
                if include_size:
                    size = os.path.getsize(file_path)
                    result += f"📄 {rel_path} ({size:,} 字节)\n"
                else:
                    result += f"📄 {rel_path}\n"
            return result
        except Exception as e:
            return f"❌ 错误: {str(e)}"
    
    @mcp.tool("read_file_content")
    async def read_file_range(file_path: str, start_line: int = 1, end_line: int = None) -> str:
        """读取文件内容，支持指定行范围"""
        try:
            file_reader = UniversalFileReader()
            doc_cache = DocumentCache()
            safe_directory = file_reader.validator.get_safe_directory()
            
            if os.path.isabs(file_path):
                abs_path = str(Path(file_path).resolve())
            else:
                abs_path = str(Path(safe_directory) / file_path)
            
            file_reader.validator.validate_file_path(abs_path)
            
            if not os.path.exists(abs_path):
                return f"❌ 文件不存在: {file_path}"
            
            file_info = await asyncio.get_event_loop().run_in_executor(
                None, lambda: file_reader.get_file_info(abs_path)
            )
            
            if file_info.get('is_document_file', False):
                cached_content = doc_cache.get_cached_content(abs_path)
                if cached_content is not None:
                    content = cached_content
                else:
                    file_ext = Path(abs_path).suffix.lower()
                    converter = FileConverter.get_converter_for_extension(file_ext)
                    if converter is None:
                        return f"❌ 不支持的文档格式: {file_ext}"
                    content = await asyncio.get_event_loop().run_in_executor(None, lambda: converter(abs_path))
                    doc_cache.cache_content(abs_path, content)
            else:
                content = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: file_reader.read_file(abs_path, start_line, end_line)
                )
            
            if not file_info.get('is_document_file', False) and (start_line > 1 or end_line is not None):
                lines = content.split('\n')
                start_idx = max(0, start_line - 1)
                end_idx = min(len(lines), end_line) if end_line else len(lines)
                content = '\n'.join(lines[start_idx:end_idx])
            
            result = f"📄 文件读取成功\n{'=' * 50}\n📁 文件路径: {abs_path}\n📊 文件大小: {file_info['size']:,} 字节\n"
            result += f"📝 文件类型: {'文档文件' if file_info.get('is_document_file') else '文本文件'}\n"
            result += f"📋 内容长度: {len(content):,}字符\n\n{'=' * 50}\n📄 文件内容:\n\n{content}"
            return result
        except Exception as e:
            return f"❌ 文件读取失败: {e}"
    
    @mcp.tool("preview_file")
    async def preview_file(file_path: str, lines: int = 20) -> str:
        """快速预览文件前N行内容"""
        try:
            file_reader = UniversalFileReader()
            safe_directory = file_reader.validator.get_safe_directory()
            
            if os.path.isabs(file_path):
                abs_path = str(Path(file_path).resolve())
            else:
                abs_path = str(Path(safe_directory) / file_path)
            
            file_reader.validator.validate_file_path(abs_path)
            
            if not os.path.exists(abs_path):
                return f"❌ 文件不存在: {file_path}"
            
            content = await asyncio.get_event_loop().run_in_executor(
                None, lambda: file_reader.read_file(abs_path, 1, lines)
            )
            
            file_info = await asyncio.get_event_loop().run_in_executor(
                None, lambda: file_reader.get_file_info(abs_path)
            )
            
            total_lines = file_info.get('total_lines', 0)
            result = f"📄 文件预览: {abs_path}\n📊 前{lines}行 / 总{total_lines}行\n{'=' * 50}\n{content}"
            if total_lines > lines:
                result += f"\n... (还有{total_lines - lines}行)"
            return result
        except Exception as e:
            return f"❌ 文件预览失败: {e}"
    
    @mcp.tool("search_documents")
    async def search_codebase(query: str, search_type: str = "semantic", file_extensions: str = None, max_results: int = 10) -> str:
        """智能搜索文档知识库（需要先运行rebuild_document_index）"""
        try:
            return f"❌ 向量搜索功能需要先运行 rebuild_document_index 建立索引\n\n提示：此功能需要配置嵌入服务API，暂时不可用"
        except Exception as e:
            return f"❌ 文档搜索失败: {e}"
    
    @mcp.tool("rebuild_document_index")
    async def rebuild_codebase_index() -> str:
        """重建文档知识库向量索引"""
        try:
            return f"❌ 向量索引功能需要配置嵌入服务API\n\n提示：此功能需要配置OPENAI_EMBEDDINGS_API_KEY和OPENAI_EMBEDDINGS_BASE_URL环境变量，暂时不可用"
        except Exception as e:
            return f"❌ 向量索引重建失败: {e}"
    
    @mcp.tool("get_document_stats")
    async def get_codebase_stats() -> str:
        """获取文档知识库索引统计信息"""
        try:
            return f"❌ 向量索引功能需要配置嵌入服务API\n\n提示：此功能需要配置OPENAI_EMBEDDINGS_API_KEY和OPENAI_EMBEDDINGS_BASE_URL环境变量，暂时不可用"
        except Exception as e:
            return f"❌ 获取统计信息失败: {e}"
    
    def main():
        """Main entry point"""
        mcp.run(transport="stdio")
    
    if __name__ == "__main__":
        main()
    else:
        main()
    
except Exception as e:
    logging.error(f"服务器启动失败: {e}")
    sys.exit(1)
