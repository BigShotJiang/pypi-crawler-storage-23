"""Tests for openapi-mock."""
