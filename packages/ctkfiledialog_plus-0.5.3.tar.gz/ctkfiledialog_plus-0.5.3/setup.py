from setuptools import setup, find_packages

setup(
    name="CTkFileDialog-plus",
    version="0.5.3",                   # bump for each release
    author="abdelilah",
    description="A modern file dialog for CustomTkinter",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/hmidani-abdelilah/CTkFileDialog-plus",
    packages=find_packages(),
    install_requires=[
        "customtkinter", "Pillow", "opencv-python", "CTkMessagebox",
        "CTkToolTip", "typeguard"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)