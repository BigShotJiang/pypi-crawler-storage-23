supervisor_agent_params = {
    "llm": "openai/gpt-5-mini",
    "system": "mail.examples.supervisor.prompts:SYSPROMPT",
}
