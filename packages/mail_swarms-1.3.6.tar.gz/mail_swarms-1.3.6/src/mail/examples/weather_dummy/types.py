from mail.examples.weather_dummy.actions import get_weather_forecast

action_get_weather_forecast = get_weather_forecast

__all__ = ["action_get_weather_forecast"]
