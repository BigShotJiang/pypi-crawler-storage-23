"""
ZeroShot SDK — Response models.


Lightweight Pydantic models that represent API responses as seen by
SDK users.  These are *not* backend models — they only carry the
fields the public API exposes.
"""


from datetime import datetime
from typing import Dict, List, Optional


from pydantic import BaseModel, Field




class ScanResponse(BaseModel):
   """Returned when a scan is created or queried."""


   scan_id: str
   target: str
   status: str  # pending, running, completed, failed
   started_at: Optional[str] = None
   completed_at: Optional[str] = None
   total_attacks: int = 0
   vulnerabilities_found: int = 0
   vulnerability_rate: float = 0.0




class ScanDetailResponse(BaseModel):
   """Full scan detail including per-category breakdowns."""


   scan_id: str
   target: str
   status: str
   started_at: Optional[str] = None
   completed_at: Optional[str] = None
   total_attacks: int = 0
   successful_attacks: int = 0
   failed_attacks: int = 0
   vulnerability_rate: float = 0.0
   error: Optional[str] = None
   vulnerabilities_by_category: Dict[str, int] = Field(default_factory=dict)
   vulnerabilities_by_severity: Dict[str, int] = Field(default_factory=dict)
   compliance_findings: Dict[str, List[str]] = Field(default_factory=dict)
   results: list = Field(default_factory=list)




class ScanListResponse(BaseModel):
   """Paginated list of scans."""


   scans: List[ScanResponse]
   total: int




class ScanStatusResponse(BaseModel):
   """Lightweight status check (for polling)."""


   scan_id: str
   target: str
   status: str
   started_at: Optional[str] = None
   completed_at: Optional[str] = None
   total_attacks: int = 0
   vulnerabilities_found: int = 0
   vulnerability_rate: float = 0.0
   error: Optional[str] = None




class UsageInfo(BaseModel):
   """Current usage counters."""


   scans_today: int = 0
   scans_limit: int = 0
   scans_remaining: int = 0




class TierInfo(BaseModel):
   """Tier capabilities."""


   name: str
   attacks_per_scan: int = 0
   allowed_categories: List[str] = Field(default_factory=list)
   reports: List[str] = Field(default_factory=list)
   llm_judge: bool = False




class AccountInfo(BaseModel):
   """Account summary returned by ``GET /api/account``."""


   user_id: str
   email: Optional[str] = None
   tier: str
   usage: UsageInfo = Field(default_factory=UsageInfo)
   tier_info: TierInfo = Field(default_factory=TierInfo)




class AttackCategoryResponse(BaseModel):
   """Single attack category."""


   value: str
   name: str




class AttackResponse(BaseModel):
   """Single attack entry from the database."""


   id: str
   prompt: str
   category: str
   severity: str
   source: str