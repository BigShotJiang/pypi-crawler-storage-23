"""
ZeroShot SDK Configuration.


Default settings for connecting to the ZeroShot API.
"""


import os


# ==============================================================================
# API Configuration
# ==============================================================================


# Production API URL (hardcoded default)
API_URL = "https://api.0eroshot.com"


# API Key (must be set by user)
API_KEY = os.environ.get("ZEROSHOT_API_KEY", "")




def get_api_url() -> str:
   """Get the API URL."""
   return API_URL




def get_api_key() -> str:
   """Get the API key."""
   return API_KEY




def get_headers() -> dict:
   """Get headers for API requests."""
   headers = {"Content-Type": "application/json"}
   if API_KEY:
       headers["X-API-Key"] = API_KEY
   return headers



