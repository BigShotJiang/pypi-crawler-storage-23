"""
Benchmark runner — executes a corpus against a target entirely client-side.

Sends attacks directly to the target via httpx. No backend dependency.
Supports OpenAI-compatible, Anthropic, Ollama, and generic HTTP APIs.
"""

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

import httpx

from zeroshot_sdk.benchmark.corpus import Attack, BenchmarkCorpus, load_corpus
from zeroshot_sdk.benchmark.detector import detect
from zeroshot_sdk.benchmark.scorer import (
    calculate_risk_score,
    calculate_security_score,
)


@dataclass
class AttackResult:
    """Result of a single attack execution."""
    attack: Attack
    response: str
    success: bool
    confidence: float
    reasoning: str = ""
    execution_time_ms: float = 0.0
    error: Optional[str] = None


@dataclass
class BenchmarkResult:
    """Complete result of a benchmark run."""
    id: str
    corpus_version: str
    corpus_hash: str
    target: str

    started_at: str
    completed_at: str
    duration_seconds: float

    total_attacks: int
    attacks_refused: int
    attacks_failed: int
    attacks_errored: int
    security_score: float
    risk_score: int

    by_category: Dict[str, Dict[str, int]]
    by_severity: Dict[str, int]
    failed_attacks: List[Dict[str, Any]]
    results: List[AttackResult] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "corpus_version": self.corpus_version,
            "corpus_hash": self.corpus_hash,
            "target": self.target,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "duration_seconds": self.duration_seconds,
            "metrics": {
                "total_attacks": self.total_attacks,
                "attacks_refused": self.attacks_refused,
                "attacks_failed": self.attacks_failed,
                "attacks_errored": self.attacks_errored,
                "security_score": self.security_score,
                "risk_score": self.risk_score,
            },
            "by_category": self.by_category,
            "by_severity": self.by_severity,
            "failed_attacks": self.failed_attacks,
        }


class BenchmarkRunner:
    """
    Execute security benchmarks against AI targets.

    Runs entirely client-side — sends attacks via httpx directly to the
    target URL and uses rule-based detection to score results.

    Usage:
        runner = BenchmarkRunner("http://localhost:8000/chat")
        result = await runner.run("v1")
        print(f"Security Score: {result.security_score}%")
    """

    def __init__(
        self,
        target: str,
        *,
        api_format: str = "openai",
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        concurrency: int = 5,
        rate_limit: Optional[int] = None,
        cooldown: float = 0.0,
        timeout: float = 60.0,
    ):
        """
        Args:
            target: Target URL (e.g. http://localhost:8000/v1/chat/completions)
            api_format: API format — "openai", "anthropic", "ollama", or "simple"
            api_key: API key for authenticated endpoints
            model: Model name (e.g. "gpt-4o", "llama3")
            concurrency: Concurrent requests
            rate_limit: Max requests per minute (None = unlimited)
            cooldown: Seconds between sequential attacks
            timeout: HTTP request timeout in seconds
        """
        self.target = target
        self.api_format = api_format
        self.api_key = api_key
        self.model = model
        self.concurrency = concurrency
        self.rate_limit = rate_limit
        self.cooldown = cooldown
        self.timeout = timeout

    async def run(
        self,
        corpus_version: str = "v1",
        *,
        categories: Optional[List[str]] = None,
        max_attacks: Optional[int] = None,
    ) -> BenchmarkResult:
        """Run benchmark with specified corpus."""
        corpus = load_corpus(corpus_version)

        if not corpus.verify():
            raise ValueError(f"Corpus integrity check failed for {corpus_version}")

        started_at = datetime.now()

        attacks = corpus.attacks
        if categories:
            attacks = [a for a in attacks if a.category in categories]
        if max_attacks:
            attacks = attacks[:max_attacks]

        results = await self._execute_attacks(attacks)

        completed_at = datetime.now()
        duration = (completed_at - started_at).total_seconds()

        return self._build_result(
            corpus=corpus,
            results=results,
            started_at=started_at.isoformat(),
            completed_at=completed_at.isoformat(),
            duration=duration,
        )

    async def _execute_attacks(self, attacks: List[Attack]) -> List[AttackResult]:
        """Execute attacks with concurrency/rate-limit/cooldown control."""
        if self.cooldown > 0:
            results = []
            for attack in attacks:
                result = await self._execute_single(attack)
                results.append(result)
                await asyncio.sleep(self.cooldown)
            return results

        if self.rate_limit:
            interval = 60.0 / self.rate_limit
            results = []
            for attack in attacks:
                result = await self._execute_single(attack)
                results.append(result)
                await asyncio.sleep(interval)
            return results

        sem = asyncio.Semaphore(self.concurrency)

        async def _run(attack: Attack) -> AttackResult:
            async with sem:
                return await self._execute_single(attack)

        return await asyncio.gather(*[_run(a) for a in attacks])

    async def _execute_single(self, attack: Attack) -> AttackResult:
        """Send one attack to the target and detect outcome."""
        t0 = time.perf_counter()

        try:
            response_text = await self._send_request(attack.prompt)
        except Exception as e:
            elapsed = (time.perf_counter() - t0) * 1000
            return AttackResult(
                attack=attack,
                response="",
                success=False,
                confidence=0.0,
                reasoning=f"Request error: {e}",
                execution_time_ms=elapsed,
                error=str(e),
            )

        elapsed = (time.perf_counter() - t0) * 1000
        detection = detect(attack.prompt, response_text, attack.category)

        return AttackResult(
            attack=attack,
            response=response_text,
            success=detection["success"],
            confidence=detection["confidence"],
            reasoning=detection["reasoning"],
            execution_time_ms=elapsed,
        )

    async def _send_request(self, prompt: str) -> str:
        """Send prompt to target and return response text."""
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        if self.api_format == "openai":
            body = {
                "model": self.model or "gpt-4o",
                "messages": [{"role": "user", "content": prompt}],
            }
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.target, json=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()
            return data["choices"][0]["message"]["content"]

        elif self.api_format == "anthropic":
            headers["x-api-key"] = self.api_key or ""
            headers["anthropic-version"] = "2023-06-01"
            headers.pop("Authorization", None)
            body = {
                "model": self.model or "claude-sonnet-4-20250514",
                "max_tokens": 1024,
                "messages": [{"role": "user", "content": prompt}],
            }
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.target, json=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()
            return data["content"][0]["text"]

        elif self.api_format == "ollama":
            body = {
                "model": self.model or "llama3",
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
            }
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.target, json=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()
            return data.get("message", {}).get("content", "")

        else:
            # Simple format: POST {"prompt": "..."}, expect {"response": "..."}
            body = {"prompt": prompt}
            if self.model:
                body["model"] = self.model
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.target, json=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()
            return data.get("response") or data.get("content") or data.get("text", "")

    def _build_result(
        self,
        corpus: BenchmarkCorpus,
        results: List[AttackResult],
        started_at: str,
        completed_at: str,
        duration: float,
    ) -> BenchmarkResult:
        """Build BenchmarkResult from attack results."""
        attacks_failed = 0
        attacks_errored = 0
        attacks_refused = 0

        for r in results:
            if r.error or (not r.response or len(r.response.strip()) < 5):
                attacks_errored += 1
            elif r.success:
                attacks_failed += 1
            else:
                attacks_refused += 1

        scoreable = attacks_refused + attacks_failed
        security_score = calculate_security_score(scoreable, attacks_refused)

        by_severity: Dict[str, int] = {}
        for r in results:
            if r.success:
                sev = r.attack.severity
                by_severity[sev] = by_severity.get(sev, 0) + 1
        risk_score = calculate_risk_score(by_severity)

        by_category: Dict[str, Dict[str, int]] = {}
        for r in results:
            cat = r.attack.category
            if cat not in by_category:
                by_category[cat] = {"refused": 0, "failed": 0, "errored": 0, "total": 0}
            by_category[cat]["total"] += 1
            if r.error or (not r.response or len(r.response.strip()) < 5):
                by_category[cat]["errored"] += 1
            elif r.success:
                by_category[cat]["failed"] += 1
            else:
                by_category[cat]["refused"] += 1

        failed_attacks = [
            {
                "id": r.attack.id,
                "category": r.attack.category,
                "severity": r.attack.severity,
                "prompt": r.attack.prompt[:200] + "..." if len(r.attack.prompt) > 200 else r.attack.prompt,
                "response": r.response[:300] + "..." if len(r.response) > 300 else r.response,
                "confidence": r.confidence,
            }
            for r in results
            if r.success
        ]

        return BenchmarkResult(
            id=f"bench-{uuid.uuid4().hex[:8]}",
            corpus_version=corpus.version,
            corpus_hash=corpus.hash,
            target=self.target,
            started_at=started_at,
            completed_at=completed_at,
            duration_seconds=duration,
            total_attacks=len(results),
            attacks_refused=attacks_refused,
            attacks_failed=attacks_failed,
            attacks_errored=attacks_errored,
            security_score=round(security_score, 1),
            risk_score=risk_score,
            by_category=by_category,
            by_severity=by_severity,
            failed_attacks=failed_attacks,
            results=results,
        )
