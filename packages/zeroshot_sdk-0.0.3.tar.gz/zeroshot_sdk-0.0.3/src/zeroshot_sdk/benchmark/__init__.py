"""
ZeroShot SDK Benchmark Module.

Runs security benchmarks entirely client-side — no backend API needed.
Ships with a versioned attack corpus, rule-based detection, and reporting.
"""

from zeroshot_sdk.benchmark.corpus import (
    Attack,
    BenchmarkCorpus,
    load_corpus,
    list_corpus_versions,
)
from zeroshot_sdk.benchmark.runner import (
    BenchmarkRunner,
    BenchmarkResult,
    AttackResult,
)
from zeroshot_sdk.benchmark.scorer import (
    calculate_security_score,
    calculate_risk_score,
    get_risk_level,
    compare_to_baseline,
    compare_to_reference,
)
from zeroshot_sdk.benchmark.reporter import BenchmarkReport

__all__ = [
    "Attack",
    "BenchmarkCorpus",
    "load_corpus",
    "list_corpus_versions",
    "BenchmarkRunner",
    "BenchmarkResult",
    "AttackResult",
    "BenchmarkReport",
    "calculate_security_score",
    "calculate_risk_score",
    "get_risk_level",
    "compare_to_baseline",
    "compare_to_reference",
]
