"""
Benchmark corpus — versioned attack sets bundled with the SDK.

Loads corpus JSON files from the package data directory.
"""

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


CORPUS_DIR = Path(__file__).parent / "corpus"


@dataclass
class Attack:
    """A single benchmark attack."""
    id: str
    prompt: str
    category: str
    severity: str = "high"
    modality: str = "text"
    description: str = ""
    source: str = ""
    compliance: Dict[str, List[str]] = field(default_factory=dict)


@dataclass
class BenchmarkCorpus:
    """Versioned, frozen attack corpus for reproducible benchmarks."""
    version: str
    name: str
    description: str
    attacks: List[Attack]
    created_at: str
    hash: str = ""
    categories: List[str] = field(default_factory=list)
    total_count: int = 0

    def __post_init__(self):
        self.total_count = len(self.attacks)
        self.categories = sorted(set(a.category for a in self.attacks))
        if not self.hash:
            self.hash = self._compute_hash()

    def _compute_hash(self) -> str:
        content = json.dumps(
            [{"prompt": a.prompt, "category": a.category} for a in self.attacks],
            sort_keys=True,
        )
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def verify(self) -> bool:
        return self._compute_hash() == self.hash

    def get_by_category(self, category: str) -> List[Attack]:
        return [a for a in self.attacks if a.category == category]

    def summary(self) -> Dict[str, Any]:
        by_category: Dict[str, int] = {}
        for a in self.attacks:
            by_category[a.category] = by_category.get(a.category, 0) + 1
        return {
            "version": self.version,
            "name": self.name,
            "total_attacks": self.total_count,
            "categories": by_category,
            "hash": self.hash,
            "created_at": self.created_at,
        }


def load_corpus(version: str = "v1") -> BenchmarkCorpus:
    """Load a bundled corpus by version."""
    corpus_file = CORPUS_DIR / f"{version}.json"

    if not corpus_file.exists():
        raise FileNotFoundError(
            f"Corpus version '{version}' not found. "
            f"Available: {list_corpus_versions()}"
        )

    with open(corpus_file) as f:
        data = json.load(f)

    attacks = [
        Attack(
            id=item["id"],
            prompt=item["prompt"],
            category=item["category"],
            severity=item.get("severity", "high"),
            modality=item.get("modality", "text"),
            description=item.get("description", ""),
            source=item.get("source", f"corpus:{version}"),
            compliance=item.get("compliance", {}),
        )
        for item in data.get("attacks", [])
    ]

    return BenchmarkCorpus(
        version=data.get("version", version),
        name=data.get("name", f"Corpus {version}"),
        description=data.get("description", ""),
        attacks=attacks,
        created_at=data.get("created_at", ""),
        hash=data.get("hash", ""),
    )


def list_corpus_versions() -> List[str]:
    """List available corpus versions."""
    if not CORPUS_DIR.exists():
        return []
    return sorted(f.stem for f in CORPUS_DIR.glob("*.json"))
