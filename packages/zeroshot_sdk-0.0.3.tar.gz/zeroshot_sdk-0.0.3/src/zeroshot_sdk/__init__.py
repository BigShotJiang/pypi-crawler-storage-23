"""
ZeroShot SDK - AI Security Testing Client.


Install: pip install zeroshot-sdk
Usage: zeroshot auth login && zeroshot scan --target <url>


Benchmark (runs locally, no API key needed):
   zeroshot benchmark --target http://localhost:8000/chat
"""


from zeroshot_sdk.client import (
   ZeroShotClient,
   ZeroShotError,
   AuthenticationError,
   RateLimitError,
   APIError,
)
from zeroshot_sdk.auth import get_api_key, save_api_key
from zeroshot_sdk.benchmark import (
   BenchmarkRunner,
   BenchmarkResult,
   BenchmarkReport,
   load_corpus,
   list_corpus_versions,
)


__version__ = "0.1.0"
__all__ = [
   "ZeroShotClient",
   "ZeroShotError",
   "AuthenticationError",
   "RateLimitError",
   "APIError",
   "get_api_key",
   "save_api_key",
   "BenchmarkRunner",
   "BenchmarkResult",
   "BenchmarkReport",
   "load_corpus",
   "list_corpus_versions",
]
