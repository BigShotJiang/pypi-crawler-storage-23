"""Base module for the Nebius SDK, protobuf classes and constants."""
