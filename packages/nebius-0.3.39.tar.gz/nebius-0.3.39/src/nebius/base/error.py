"""Main Error class for the Nebius SDK."""


class SDKError(Exception):
    """Base class for all SDK errors."""

    pass
