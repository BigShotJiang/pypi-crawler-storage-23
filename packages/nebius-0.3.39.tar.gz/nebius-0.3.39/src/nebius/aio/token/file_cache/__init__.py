"""Cache management for file-based tokens."""
