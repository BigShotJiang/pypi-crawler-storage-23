"""Bitbucket MCP Server - Container optimized MCP server for Bitbucket API"""

__version__ = "1.5.0"
