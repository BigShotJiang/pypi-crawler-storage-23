"""PowerPoint COM automation modules for ppt-mcp."""
