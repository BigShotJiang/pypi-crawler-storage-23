import threading
import time
import logging
import os
import platform
import tempfile
from collections import deque
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import psutil

logger = logging.getLogger(__name__)

# Common download / staging directories — auto-registered in SystemMonitor
_DOWNLOAD_DIRS: list = [
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~/Desktop"),
    tempfile.gettempdir(),          # /tmp on Linux/macOS, %TEMP% on Windows
]
# /var/tmp is Linux-specific; only add when it exists
if platform.system() != "Windows" and os.path.isdir("/var/tmp"):
    _DOWNLOAD_DIRS.append("/var/tmp")

# Process names that may NEVER be suspended or killed by the suspicion tracker.
_PID_SUSPEND_BLOCKLIST: frozenset = frozenset({
    # Linux / macOS system processes
    "systemd", "init", "kthreadd", "kworker", "kernel",
    "sshd", "login", "sudo", "su", "dbus-daemon",
    "Xorg", "Xwayland", "wayland", "gnome-shell", "kwin_wayland",
    # Common interpreter / self
    "python", "python3", "leukquant",
    # Windows critical system processes
    "svchost.exe", "wininit.exe", "lsass.exe", "csrss.exe",
    "winlogon.exe", "explorer.exe", "smss.exe", "services.exe",
    "System", "Registry",
})


# ═══════════════════════════════════════════════════════════════════════════════
# PID resolution helper
# ═══════════════════════════════════════════════════════════════════════════════

def resolve_pid_for_path(path: str) -> int | None:
    """
    Scan all live processes for one that currently has *path* open.

    Called ~0.5 s after a file-creation event so the creating process
    usually still holds the file descriptor.  Returns the PID or None
    if no match is found (e.g. short-lived writers that already closed).
    """
    abs_path = os.path.abspath(path)
    try:
        for proc in psutil.process_iter(["pid", "open_files"]):
            try:
                for f in (proc.open_files() or []):
                    if f.path == abs_path:
                        return proc.pid
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception:
        pass
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Per-PID suspicion tracker
# ═══════════════════════════════════════════════════════════════════════════════

class PidSuspicionTracker:
    """
    Maintains a floating-point suspicion score for each live PID.

    Scores accumulate when a PID is implicated in suspicious file events
    (creating files in risky directories, bulk-deleting files, dropping
    double-extension binaries, triggering MALICIOUS scan results, etc.)
    and decay exponentially so transient noise does not permanently flag
    legitimate processes.

    Thresholds
    ----------
    WARN_THRESHOLD     → WARNING log entry only
    SUSPEND_THRESHOLD  → SIGSTOP (pause) the process via psutil.suspend()
    KILL_THRESHOLD     → SIGKILL (terminate) the process via psutil.kill()

    Increment constants (class-level, override via subclass or config)
    -------------------------------------------------------------------
    DELTA_DELETED             — one file deleted in a watched directory
    DELTA_CREATED_SUSPICIOUS  — file created inside a suspicious directory
    DELTA_DOUBLE_EXT          — file has a deceptive double extension
    DELTA_TYPE_MISMATCH       — magic bytes do not match declared extension
    DELTA_SCAN_SUSPICIOUS     — scan composite score > 40
    DELTA_SCAN_MALICIOUS      — scan verdict == MALICIOUS
    """

    WARN_THRESHOLD    = 5.0    # log WARNING
    SUSPEND_THRESHOLD = 10.0   # SIGSTOP
    KILL_THRESHOLD    = 20.0   # SIGKILL
    DECAY_HALF_LIFE   = 300.0  # seconds — score halves every 5 minutes

    # Per-event increment values
    DELTA_DELETED            = 0.5
    DELTA_CREATED_SUSPICIOUS = 1.0
    DELTA_DOUBLE_EXT         = 2.0
    DELTA_TYPE_MISMATCH      = 2.0
    DELTA_SCAN_SUSPICIOUS    = 3.0
    DELTA_SCAN_MALICIOUS     = 8.0

    def __init__(self):
        self._scores: dict[int, float]    = {}  # pid → cumulative score
        self._suspended: set[int]         = set()  # PIDs currently SIGSTOPped
        self._last_decay: float           = time.monotonic()
        self._lock                        = threading.Lock()

    # ─── public API ───────────────────────────────────────────────────────

    def increment(self, pid: int, delta: float, reason: str = "") -> float:
        """
        Add *delta* to the suspicion score for *pid*, apply decay, then
        evaluate thresholds.  Returns the updated score.
        """
        self._maybe_decay()
        with self._lock:
            old   = self._scores.get(pid, 0.0)
            new   = old + delta
            self._scores[pid] = new
        logger.debug(
            f"[PidSuspicion] pid={pid} score {old:.2f} → {new:.2f} "
            f"(+{delta:.2f}) {reason}"
        )
        self._check_threshold(pid, new)
        return new

    def get_score(self, pid: int) -> float:
        """Return the current suspicion score for *pid* (after decay)."""
        self._maybe_decay()
        with self._lock:
            return self._scores.get(pid, 0.0)

    def top_offenders(self, n: int = 5) -> list[tuple[int, float]]:
        """Return the top-n (pid, score) pairs sorted by score descending."""
        self._maybe_decay()
        with self._lock:
            return sorted(
                self._scores.items(), key=lambda kv: kv[1], reverse=True
            )[:n]

    def all_scores(self) -> dict[int, float]:
        """Snapshot of all current (pid, score) pairs."""
        self._maybe_decay()
        with self._lock:
            return dict(self._scores)

    def reset_pid(self, pid: int):
        """Clear the score for *pid* (call after it exits cleanly)."""
        with self._lock:
            self._scores.pop(pid, None)
            self._suspended.discard(pid)

    # ─── decay ────────────────────────────────────────────────────────────

    def _maybe_decay(self):
        """Apply exponential time-decay to all scores (at most every 10 s)."""
        now     = time.monotonic()
        elapsed = now - self._last_decay
        if elapsed < 10:
            return
        factor = 0.5 ** (elapsed / self.DECAY_HALF_LIFE)
        with self._lock:
            for pid in list(self._scores):
                self._scores[pid] *= factor
                if self._scores[pid] < 0.01:
                    del self._scores[pid]
            self._last_decay = now

    # ─── threshold enforcement ────────────────────────────────────────────

    def _check_threshold(self, pid: int, score: float):
        if score >= self.KILL_THRESHOLD:
            self._act_kill(pid, score)
        elif score >= self.SUSPEND_THRESHOLD:
            self._act_suspend(pid, score)
        elif score >= self.WARN_THRESHOLD:
            self._act_warn(pid, score)

    def _proc_label(self, pid: int) -> str:
        """Return a short human-readable label for logging."""
        try:
            p = psutil.Process(pid)
            return f"'{p.name()}' exe={p.exe()}"
        except Exception:
            return f"pid={pid}"

    def _act_warn(self, pid: int, score: float):
        logger.warning(
            f"[PidSuspicion] ⚠ WARNING  pid={pid} {self._proc_label(pid)} "
            f"score={score:.1f} ≥ WARN({self.WARN_THRESHOLD})"
        )

    def _act_suspend(self, pid: int, score: float):
        """Send SIGSTOP to pause the suspicious process."""
        with self._lock:
            if pid in self._suspended:
                return  # already paused — don't double-send
            self._suspended.add(pid)
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if name in _PID_SUSPEND_BLOCKLIST:
                logger.warning(
                    f"[PidSuspicion] SUSPEND blocked — '{name}' "
                    f"(pid={pid}) is in the system blocklist."
                )
                with self._lock:
                    self._suspended.discard(pid)
                return
            proc.suspend()   # SIGSTOP on Linux/macOS; suspend on Windows
            logger.warning(
                f"[PidSuspicion] ⏸ SUSPENDED pid={pid} '{name}' "
                f"score={score:.1f} ≥ SUSPEND({self.SUSPEND_THRESHOLD})"
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
            logger.warning(f"[PidSuspicion] Could not suspend pid={pid}: {exc}")
            with self._lock:
                self._suspended.discard(pid)

    def _act_kill(self, pid: int, score: float):
        """Send SIGKILL to terminate the suspicious process."""
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if name in _PID_SUSPEND_BLOCKLIST:
                logger.warning(
                    f"[PidSuspicion] KILL blocked — '{name}' "
                    f"(pid={pid}) is in the system blocklist."
                )
                return
            proc.kill()   # SIGKILL (unblockable termination)
            logger.warning(
                f"[PidSuspicion] ☠ KILLED pid={pid} '{name}' "
                f"score={score:.1f} ≥ KILL({self.KILL_THRESHOLD})"
            )
            with self._lock:
                self._scores.pop(pid, None)
                self._suspended.discard(pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
            logger.warning(f"[PidSuspicion] Could not kill pid={pid}: {exc}")


# ─── file-scan guard constants ───────────────────────────────────────────────

# Partial/in-progress download extensions produced by browsers and download
# managers.  Files with these suffixes are actively being written and must
# NEVER be scanned — we wait for the rename to a real extension instead.
_TEMP_EXTENSIONS: frozenset = frozenset({
    ".part",        # Firefox, wget
    ".crdownload",  # Chrome / Chromium
    ".download",    # Safari
    ".opdownload",  # Opera
    ".partial",     # generic
    ".incomplete",  # aria2, some managers
    ".tmp",
    ".temp",
    ".~tmp",
    ".swp",         # Vim swap
    ".swo",
    ".dtmp",        # Delta-copy temp
})

# Minimum seconds between successive scans of the *same canonical path*.
# Prevents duplicate alerts when the OS fires multiple create/modify events
# (e.g. browser rename + immediate modify) for the same file.
_SCAN_COOLDOWN_SECS: float = 30.0

# File-size stability polling: wait until the file stops growing before
# scanning.  The poll loop gives up after _STABILITY_MAX_WAIT seconds so
# a very large download doesn't block the thread forever.
_STABILITY_POLL_INTERVAL: float = 1.0   # seconds between size checks
_STABILITY_MAX_WAIT: float      = 15.0  # give up after this many seconds


def _is_temp_file(path: str) -> bool:
    """Return True if *path* has a known partial-download / temp extension."""
    # Check every suffix so double-extensions like '.zip.part' are caught
    name = os.path.basename(path).lower()
    for ext in _TEMP_EXTENSIONS:
        if name.endswith(ext):
            return True
    return False


class FileEventTracker(FileSystemEventHandler):
    """
    Tracks file system create/modify/delete events using a rolling time window.

    When *scan_callback* is provided it is called as ``scan_callback(path, pid)``
    for every newly created or moved-to file (~0.5 s after the event to allow
    the write to complete).  *pid* is the integer PID of the process that
    created the file, or ``None`` if it could not be resolved.

    When *pid_tracker* is provided every deletion event also resolves and
    penalises the offending PID's suspicion score.
    """

    def __init__(
        self,
        window_seconds: int = 60,
        scan_callback=None,
        pid_tracker: "PidSuspicionTracker | None" = None,
    ):
        super().__init__()
        self.window_seconds  = window_seconds
        self._events: deque  = deque()
        self._lock           = threading.Lock()
        self._scan_callback  = scan_callback   # callable(path, pid|None)
        self._pid_tracker    = pid_tracker
        # path → monotonic timestamp of last completed scan (dedup guard)
        self._scan_cooldown: dict[str, float] = {}
        self._cooldown_lock = threading.Lock()

    # ─── watchdog callbacks ───────────────────────────────────────────────

    def on_created(self, event):
        if not event.is_directory:
            self._record("created", event.src_path)
            self._dispatch_scan(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._record("modified", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            self._record("deleted", event.src_path)
            if self._pid_tracker:
                threading.Thread(
                    target=self._track_deletion_pid,
                    args=(event.src_path,),
                    daemon=True,
                    name=f"lq-del-{os.path.basename(event.src_path)[:20]}",
                ).start()

    def on_moved(self, event):
        """Treat a rename/move destination as a new creation."""
        if not event.is_directory:
            self._record("created", event.dest_path)
            self._dispatch_scan(event.dest_path)

    # ─── auto-scan dispatch ───────────────────────────────────────────────

    def _dispatch_scan(self, path: str):
        """
        Gate 1 — skip browser partial-download files immediately.
        This avoids spawning a thread at all for .part / .crdownload etc.
        The real file will arrive via an on_moved event once the download
        finishes, and that destination path will pass this check.
        """
        if not self._scan_callback:
            return
        if _is_temp_file(path):
            logger.debug(f"[AutoScan] Skipping temp/partial file: {path}")
            return
        threading.Thread(
            target=self._auto_scan,
            args=(path,),
            daemon=True,
            name=f"lq-autoscan-{os.path.basename(path)[:32]}",
        ).start()

    def _auto_scan(self, path: str):
        """
        Full scan pipeline with three guards:

        1. Temp-extension check (belt-and-suspenders, in case a rename races
           ahead of the dispatch check).
        2. Per-path cooldown — suppress re-scans of the same canonical file
           within _SCAN_COOLDOWN_SECS seconds.
        3. Size-stability poll — keep sampling getsize() until the file stops
           growing (download complete) before handing it to the scanner.
        """
        try:
            time.sleep(0.5)   # initial grace for the write to start

            if not os.path.isfile(path):
                return

            # ── Guard 1: skip if still a temp extension ───────────────────
            if _is_temp_file(path):
                logger.debug(f"[AutoScan] Skipping temp file (post-dispatch): {path}")
                return

            # ── Guard 2: per-path cooldown (dedup) ────────────────────────
            canon = os.path.realpath(path)
            now   = time.monotonic()
            with self._cooldown_lock:
                last = self._scan_cooldown.get(canon, 0.0)
                if now - last < _SCAN_COOLDOWN_SECS:
                    logger.debug(
                        f"[AutoScan] Cooldown ({_SCAN_COOLDOWN_SECS:.0f}s) active, "
                        f"skipping: {os.path.basename(path)}"
                    )
                    return
                # Reserve the slot before we start the stability wait so a
                # concurrent thread for the same path also backs off.
                self._scan_cooldown[canon] = now

            # ── Guard 3: wait for file size to stabilise ──────────────────
            # Polls every _STABILITY_POLL_INTERVAL seconds; stops as soon as
            # the size is unchanged across two consecutive readings.
            prev_size = -1
            deadline  = time.monotonic() + _STABILITY_MAX_WAIT
            while time.monotonic() < deadline:
                try:
                    cur_size = os.path.getsize(path)
                except OSError:
                    return   # file disappeared mid-poll (renamed again?)
                if cur_size == prev_size:
                    break    # stable — ready to scan
                prev_size = cur_size
                time.sleep(_STABILITY_POLL_INTERVAL)

            # Re-check after the wait — the browser may have renamed the file
            # (e.g. added/stripped an extension) while we were polling.
            if not os.path.isfile(path):
                return
            if _is_temp_file(path):
                logger.debug(f"[AutoScan] File became temp after stability wait: {path}")
                return

            # ── Resolve creator PID ───────────────────────────────────────
            pid: int | None = resolve_pid_for_path(path)

            logger.info(
                f"[AutoScan] Scanning stable file: {path} "
                f"(creator_pid={pid if pid else 'unknown'})"
            )
            if self._scan_callback:
                self._scan_callback(path, pid)

        except Exception as exc:
            logger.warning(f"[AutoScan] Error processing '{path}': {exc}")

    # ─── deletion PID tracking ────────────────────────────────────────────

    def _track_deletion_pid(self, path: str):
        """
        After a file is deleted find PIDs that were working in the same
        directory (via CWD or open file descriptors) and increment their
        suspicion score.  This is a heuristic — the deleting process may
        have moved on — but it catches rapid bulk-delete patterns well.
        """
        try:
            parent   = os.path.dirname(os.path.abspath(path))
            implicated: set[int] = set()

            for proc in psutil.process_iter(["pid", "cwd", "open_files"]):
                try:
                    cwd = proc.cwd()
                    if cwd and cwd.startswith(parent):
                        implicated.add(proc.pid)
                        continue
                    for f in (proc.open_files() or []):
                        if os.path.dirname(f.path) == parent:
                            implicated.add(proc.pid)
                            break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            for pid in implicated:
                self._pid_tracker.increment(
                    pid,
                    PidSuspicionTracker.DELTA_DELETED,
                    reason=f"file deleted in {parent}",
                )
        except Exception as exc:
            logger.debug(f"[PidTrack] Deletion PID tracking failed: {exc}")

    # ─── event recording ──────────────────────────────────────────────────

    def _record(self, kind: str, path: str):
        now = time.monotonic()
        with self._lock:
            self._events.append((now, kind, path))
            cutoff = now - self.window_seconds
            while self._events and self._events[0][0] < cutoff:
                self._events.popleft()

    # ─── rate helpers ─────────────────────────────────────────────────────

    def get_rate(self) -> float:
        """Total file events per minute in the current window (legacy compat)."""
        now    = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            recent = sum(1 for ts, _, _ in self._events if ts >= cutoff)
        return (recent / self.window_seconds) * 60

    def get_write_rate(self) -> float:
        """Create + modify events per minute (write-activity indicator)."""
        now    = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            recent = sum(
                1 for ts, kind, _ in self._events
                if ts >= cutoff and kind in ("created", "modified")
            )
        return (recent / self.window_seconds) * 60

    def get_delete_rate(self) -> float:
        """Delete events per minute — elevated rate is a ransomware indicator."""
        now    = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            recent = sum(
                1 for ts, kind, _ in self._events
                if ts >= cutoff and kind == "deleted"
            )
        return (recent / self.window_seconds) * 60

    def get_recent_created(self, seconds: int = 60) -> list:
        """Return file paths created within the last *seconds* seconds."""
        now    = time.monotonic()
        cutoff = now - seconds
        with self._lock:
            return [
                path for ts, kind, path in self._events
                if ts >= cutoff and kind == "created"
            ]


class SystemMonitor:
    """
    Aggregates real-time system metrics used by the BehaviorProfiler.

    File-system layer  (watchdog)
      file_write_rate   — create + modify events / min
      file_delete_rate  — delete events / min        (ransomware indicator)

    Process layer  (psutil)
      process_spawn_rate  — total live PID count
      cpu_usage_pct       — system-wide CPU %

    Network layer  (psutil)
      network_socket_count — active inet connections

    Memory layer   (psutil)
      memory_alloc_spikes  — virtual memory usage %

    Disk layer     (psutil)
      disk_read_kbps  — KB/s read  (sampled ~0.5 s)
      disk_write_kbps — KB/s write (sampled ~0.5 s)

    Pass *scan_callback* (callable accepting a file path) to auto-scan every
    new file created under *watch_path* and any paths added via add_watch_path().
    """

    def __init__(
        self,
        watch_path: str = None,
        window_seconds: int = 60,
        scan_callback=None,
        pid_tracker: "PidSuspicionTracker | None" = None,
    ):
        # Default to the OS temp dir (/tmp on Linux, %TEMP% on Windows)
        watch_path = watch_path or tempfile.gettempdir()
        self.watch_path  = watch_path
        self.pid_tracker = pid_tracker   # exposed for BehaviorProfiler
        self.file_tracker = FileEventTracker(
            window_seconds,
            scan_callback=scan_callback,
            pid_tracker=pid_tracker,
        )
        self._observer = Observer()
        self._observer.schedule(self.file_tracker, watch_path, recursive=True)
        self._running = False

    # ─── extra watch paths ────────────────────────────────────────────────

    def add_watch_path(self, path: str):
        """Register an additional directory for file-event tracking."""
        if os.path.isdir(path):
            self._observer.schedule(self.file_tracker, path, recursive=True)
            logger.info(f"SystemMonitor: registered watch path {path}")
        else:
            logger.debug(f"SystemMonitor: skipping non-existent path {path}")

    # ─── lifecycle ────────────────────────────────────────────────────────

    def start(self):
        if not self._running:
            try:
                self._observer.start()
                self._running = True
                logger.info(f"SystemMonitor started. Watching: {self.watch_path}")
            except Exception as e:
                logger.warning(f"Could not start file watcher: {e}")

    def stop(self):
        if self._running:
            self._observer.stop()
            self._observer.join()
            self._running = False
            logger.info("SystemMonitor stopped.")

    # ─── disk I/O helper ──────────────────────────────────────────────────

    def _disk_io_kbps(self) -> tuple:
        """Return (read_kbps, write_kbps) sampled over ~0.1 s.

        Note: reducing the sample sleep from 0.5s to 0.1s gives adequate
        measurement accuracy at a fraction of the overhead.
        """
        try:
            before = psutil.disk_io_counters()
            time.sleep(0.1)
            after = psutil.disk_io_counters()
            if before and after:
                elapsed = 0.1
                read_kbps  = max(0.0, (after.read_bytes  - before.read_bytes)  / 1024 / elapsed)
                write_kbps = max(0.0, (after.write_bytes - before.write_bytes) / 1024 / elapsed)
                return read_kbps, write_kbps
        except Exception:
            pass
        return 0.0, 0.0

    # ─── metrics snapshot ─────────────────────────────────────────────────

    def get_snapshot(self) -> dict:
        try:
            mem          = psutil.virtual_memory()
            # Note: net_connections requires root on some Linux kernels;
            # catch AccessDenied specifically so the rest of the snapshot
            # still succeeds instead of falling through to the zero-vector.
            try:
                net = psutil.net_connections(kind="inet")
            except psutil.AccessDenied:
                logger.debug("net_connections: AccessDenied — network socket count unavailable")
                net = []
            cpu          = psutil.cpu_percent(interval=None)
            disk_r, disk_w = self._disk_io_kbps()
            return {
                # ── legacy keys (backward-compatible with existing DB rows) ──
                "process_spawn_rate":   len(psutil.pids()),
                "file_write_rate":      self.file_tracker.get_write_rate(),
                "network_socket_count": len(net),
                "memory_alloc_spikes":  mem.percent,
                # ── extended metrics ──
                "file_delete_rate":     self.file_tracker.get_delete_rate(),
                "cpu_usage_pct":        cpu,
                "disk_read_kbps":       disk_r,
                "disk_write_kbps":      disk_w,
            }
        except Exception as e:
            logger.warning(f"SystemMonitor snapshot error: {e}")
            return {
                "process_spawn_rate":   0,
                "file_write_rate":      0.0,
                "network_socket_count": 0,
                "memory_alloc_spikes":  0.0,
                "file_delete_rate":     0.0,
                "cpu_usage_pct":        0.0,
                "disk_read_kbps":       0.0,
                "disk_write_kbps":      0.0,
            }

    @staticmethod
    def top_offender_process() -> dict | None:
        """
        Return info on the process consuming the most CPU right now.

        Note: psutil documents that cpu_percent(interval=None) always
        returns 0.0 on the very first call for each process (it needs a
        reference measurement). We prime the counters first, sleep briefly,
        then take the real reading.
        """
        # Prime the per-process CPU counters (returns 0.0 on first call)
        for proc in psutil.process_iter(["pid"]):
            try:
                proc.cpu_percent(interval=None)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        time.sleep(0.5)  # allow the kernel to accumulate CPU time

        best = None
        best_cpu = -1.0
        for proc in psutil.process_iter(["pid", "name", "exe", "cmdline"]):
            try:
                cpu = proc.cpu_percent(interval=None)
                if cpu > best_cpu:
                    best_cpu = cpu
                    best = proc
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if best is None:
            return None

        try:
            return {
                "pid":         best.pid,
                "name":        best.name(),
                "exe":         best.exe(),
                "cpu_percent": best_cpu,
                "cmdline":     " ".join(best.cmdline()),
            }
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None
