import time
import json
import numpy as np
import logging
import os
import psutil
from datetime import datetime
from src.db.database import DatabaseManager
from src.behavior.monitors import SystemMonitor, _DOWNLOAD_DIRS, PidSuspicionTracker
from src.config import Config
from src.paths import app_path

logger = logging.getLogger(__name__)

MIN_BASELINE_SAMPLES = 10

# ── Weighted anomaly category definitions ────────────────────────────────────
# Each category maps to one or more metric indices in get_baseline_metrics():
#   0: process_spawn_rate  1: file_write_rate   2: network_socket_count
#   3: memory_alloc_spikes 4: file_delete_rate  5: cpu_usage_pct
#   6: disk_read_kbps      7: disk_write_kbps
#
# Weights reflect relative threat-signal strength per category.
# Sum = 1.0 for normalized composite scoring.
_CATEGORY_WEIGHTS: dict = {
    "file_activity":    0.25,   # write + delete rates  (ransomware, exfil)
    "process_activity": 0.20,   # process count + CPU   (cryptominer, injection)
    "network_activity": 0.25,   # socket count          (C2, beacon, exfil)
    "memory_activity":  0.15,   # RAM %                 (heap spray, injection)
    "disk_activity":    0.15,   # disk read/write kbps  (mass encrypt, exfil)
}

# Processes whose executables should never be quarantined even at CRITICAL score.
# Add more system-critical binaries here as needed.
_QUARANTINE_BLOCKLIST: frozenset = frozenset({
    # Linux / macOS system processes
    "systemd", "init", "kthreadd", "kernel",
    "sshd", "login", "sudo", "su",
    "python", "python3",   # would quarantine ourselves
    "leukquant",
    # Windows critical system processes
    "svchost.exe", "wininit.exe", "lsass.exe", "csrss.exe",
    "winlogon.exe", "explorer.exe", "smss.exe", "services.exe",
})


class BehaviorProfiler:
    """
    Collects system metrics every `poll_interval` seconds, stores them in SQLite,
    and computes a Z-score anomaly metric against the rolling `baseline_days`-day window.

        A(t) = (1/N) * Σ |x_i(t) − μ_i| / σ_i

    Scores above `alert_threshold` are logged; scores above `quarantine_threshold`
    are also written as anomaly events for downstream quarantine decisions.
    """

    PID_FILE = app_path("logs", "monitor.pid")

    def __init__(self, poll_interval: int = 60, auto_scan: bool = True):
        cfg = Config.get()
        self.baseline_days: int = cfg.get_value("behavior", "baseline_period_days", default=14)
        self.alert_threshold: float = cfg.get_value("behavior", "alert_threshold", default=3.5)
        self.quarantine_threshold: float = cfg.get_value("behavior", "quarantine_threshold", default=5.0)
        self.poll_interval = poll_interval
        self.db = DatabaseManager()

        # ── per-PID suspicion tracker (shared with SystemMonitor / FileEventTracker) ──
        self.pid_tracker = PidSuspicionTracker()

        # ── auto-scan callback: triggered on every new file created/moved ──
        scan_cb = None
        if auto_scan:
            try:
                from src.scanner.scan import LocalScanner
                self._scanner = LocalScanner()
                scan_cb = self._on_new_file
                logger.info("[BehaviorProfiler] Auto-scan enabled: new files will be scanned on creation.")
            except Exception as exc:
                logger.warning(f"[BehaviorProfiler] Auto-scan unavailable: {exc}")

        self.monitor = SystemMonitor(
            scan_callback=scan_cb,
            pid_tracker=self.pid_tracker,
        )

        # Register common download/staging directories for file-creation watching
        for dl_dir in _DOWNLOAD_DIRS:
            self.monitor.add_watch_path(dl_dir)

    # ─── auto-scan callback ───────────────────────────────────────────────────

    def _on_new_file(self, path: str, pid: int | None = None):
        """
        Scan *path* with the local AI + signature scanner the moment it
        appears in any watched directory (Downloads, /tmp, Desktop …).

        *pid* is the creator process resolved by FileEventTracker._auto_scan.
        When provided, the suspicion score for that PID is updated based on
        the scan outcome — crossing configured thresholds causes the process
        to be suspended (SIGSTOP) or killed (SIGKILL) automatically.
        """
        try:
            result  = self._scanner.scan_file(path)
            verdict = result.get("verdict", "UNKNOWN")
            prob    = result.get("malware_probability", 0.0)
            threat  = result.get("composite_threat_score", prob * 100)
            sub     = result.get("anomaly_subscores", {})

            # ── Drive per-PID suspicion score based on scan outcome ──────
            if pid is not None:
                delta        = 0.0
                reason_parts: list[str] = []

                if verdict == "MALICIOUS":
                    delta        += PidSuspicionTracker.DELTA_SCAN_MALICIOUS
                    reason_parts.append("MALICIOUS verdict")
                elif threat > 40:
                    delta        += PidSuspicionTracker.DELTA_SCAN_SUSPICIOUS
                    reason_parts.append(f"suspicious composite={threat:.1f}")

                if sub.get("type_mismatch", 0.0) > 0.5:
                    delta        += PidSuspicionTracker.DELTA_TYPE_MISMATCH
                    reason_parts.append("type_mismatch")
                if sub.get("double_extension", 0.0) > 0.5:
                    delta        += PidSuspicionTracker.DELTA_DOUBLE_EXT
                    reason_parts.append("double_extension")
                if sub.get("path_anomaly", 0.0) > 0.5:
                    delta        += PidSuspicionTracker.DELTA_CREATED_SUSPICIOUS
                    reason_parts.append("suspicious_path")

                if delta > 0:
                    new_score = self.pid_tracker.increment(
                        pid, delta,
                        reason=(
                            f"scan: {', '.join(reason_parts)} "
                            f"| {os.path.basename(path)}"
                        ),
                    )
                    logger.debug(
                        f"[PidSuspicion] pid={pid} updated to {new_score:.2f} "
                        f"after scanning {os.path.basename(path)}"
                    )

            # ── Quarantine / log ─────────────────────────────────────────
            if verdict == "MALICIOUS":
                logger.warning(
                    f"[AutoScan] MALICIOUS file detected: {path} "
                    f"(prob={prob:.4f}, composite={threat:.1f}) — quarantining."
                )
                try:
                    from src.quarantine.manager import QuarantineManager
                    qm  = QuarantineManager()
                    qid = qm.quarantine_file(
                        path,
                        reason=(
                            f"AutoScan: verdict={verdict} prob={prob:.4f} "
                            f"composite={threat:.1f} creator_pid={pid}"
                        ),
                    )
                    self.db.log_anomaly(
                        prob * 100,
                        f"AutoScan MALICIOUS: {path} | qid={qid[:8]} | pid={pid}",
                    )
                except Exception as qe:
                    logger.error(f"[AutoScan] Quarantine failed for '{path}': {qe}")
            elif threat > 40:
                logger.warning(
                    f"[AutoScan] Suspicious file: {path} "
                    f"(prob={prob:.4f}, composite={threat:.1f}, pid={pid})"
                )
                self.db.log_anomaly(
                    threat,
                    f"AutoScan suspicious: {path} | verdict={verdict} "
                    f"prob={prob:.4f} | pid={pid}",
                )
            else:
                logger.info(
                    f"[AutoScan] Clean: {path} "
                    f"(prob={prob:.4f}, composite={threat:.1f}, pid={pid})"
                )
        except Exception as exc:
            logger.warning(f"[AutoScan] Scan error for '{path}': {exc}")

    # ─── metric helpers ───────────────────────────────────────────────────────

    def _collect(self) -> dict:
        snap = self.monitor.get_snapshot()
        snap["timestamp"] = datetime.now()
        return snap

    def calculate_anomaly_score(self, metrics: dict) -> tuple:
        """
        Compute a weighted multi-category anomaly score against the baseline.

        Returns
        -------
        (composite_score, category_scores)

          composite_score  — weighted sum of per-category Z-score means
          category_scores  — dict mapping category name → Z-score

        Scoring formula (aligned with the README weighted model):

            Composite = Σ( W_i × Z_i )   where Z_i = |x_i − μ_i| / σ_i
        """
        rows = self.db.get_baseline_metrics(days=self.baseline_days)
        if len(rows) < MIN_BASELINE_SAMPLES:
            logger.debug(f"Only {len(rows)} samples in baseline — skipping anomaly scoring.")
            return 0.0, {}

        baseline = np.array(rows, dtype=float)
        means    = np.mean(baseline, axis=0)
        stds     = np.std(baseline, axis=0)
        stds[stds == 0] = 1e-6

        # Column order must match get_baseline_metrics() SELECT order:
        # 0: process_spawn_rate  1: file_write_rate   2: network_socket_count
        # 3: memory_alloc_spikes 4: file_delete_rate  5: cpu_usage_pct
        # 6: disk_read_kbps      7: disk_write_kbps
        current = np.array([
            metrics.get("process_spawn_rate",   0),
            metrics.get("file_write_rate",       0.0),
            metrics.get("network_socket_count",  0),
            metrics.get("memory_alloc_spikes",   0.0),
            metrics.get("file_delete_rate",      0.0),
            metrics.get("cpu_usage_pct",         0.0),
            metrics.get("disk_read_kbps",        0.0),
            metrics.get("disk_write_kbps",       0.0),
        ], dtype=float)

        # Handle old 4-column baselines gracefully
        n = min(len(current), baseline.shape[1])
        z = np.abs(current[:n] - means[:n]) / stds[:n]

        def _z(idx: int) -> float:
            return float(z[idx]) if idx < n else 0.0

        category_z: dict = {
            "file_activity":    (_z(1) + _z(4)) / 2,   # write_rate + delete_rate
            "process_activity": (_z(0) + _z(5)) / 2,   # proc_count + cpu_pct
            "network_activity":  _z(2),                  # socket_count
            "memory_activity":   _z(3),                  # mem_pct
            "disk_activity":    (_z(6) + _z(7)) / 2,   # read_kbps + write_kbps
        }

        composite = sum(
            _CATEGORY_WEIGHTS[cat] * val
            for cat, val in category_z.items()
        )
        return float(composite), category_z

    # ─── quarantine helper ────────────────────────────────────────────────────

    def _try_quarantine_offender(self, score: float, details: str) -> None:
        """
        Identify the top CPU-consuming process and quarantine its executable
        if it is not on the system-process blocklist.
        """
        from src.quarantine.manager import QuarantineManager

        proc = SystemMonitor.top_offender_process()
        if not proc:
            logger.warning("[AUTO-QUARANTINE] Could not identify top offending process.")
            return

        exe = proc.get("exe", "") or ""
        name = proc.get("name", "") or ""

        if not exe or not os.path.isfile(exe):
            logger.warning(
                f"[AUTO-QUARANTINE] Skipped — no executable path for "
                f"'{name}' (pid={proc['pid']})."
            )
            return

        if name in _QUARANTINE_BLOCKLIST or os.path.basename(exe) in _QUARANTINE_BLOCKLIST:
            logger.warning(
                f"[AUTO-QUARANTINE] Skipped — '{name}' (pid={proc['pid']}) "
                f"is on the system-process blocklist."
            )
            return

        reason = (
            f"Behavior anomaly score={score:.3f} (threshold={self.quarantine_threshold}) | "
            f"pid={proc['pid']} cpu={proc['cpu_percent']:.1f}% | {details}"
        )
        try:
            qm = QuarantineManager()
            qid = qm.quarantine_file(exe, reason=reason)
            logger.warning(
                f"[AUTO-QUARANTINE] '{exe}' quarantined (id={qid}, "
                f"pid={proc['pid']}, cpu={proc['cpu_percent']:.1f}%)."
            )
        except Exception as exc:
            logger.error(f"[AUTO-QUARANTINE] Failed to quarantine '{exe}': {exc}")

    # ─── main loop ────────────────────────────────────────────────────────────

    def monitor_loop(self):
        os.makedirs(app_path("logs"), exist_ok=True)
        with open(self.PID_FILE, "w") as f:
            f.write(str(os.getpid()))

        # Note: if start() raises, the finally must NOT call stop()
        # (the Observer was never started). Use a guard flag.
        _started = False
        try:
            self.monitor.start()
            _started = True
            logger.info(f"Behavior monitor started (PID {os.getpid()}, interval {self.poll_interval}s).")

            _interval = 0
            while True:
                metrics = self._collect()
                self.db.insert_metrics(metrics)
                score, category_z = self.calculate_anomaly_score(metrics)

                if score > self.alert_threshold:
                    cat_str = " | ".join(f"{k}={v:.2f}" for k, v in category_z.items())
                    details = (
                        f"score={score:.3f} | "
                        f"procs={metrics['process_spawn_rate']} | "
                        f"files/min={metrics['file_write_rate']:.1f} | "
                        f"del/min={metrics['file_delete_rate']:.1f} | "
                        f"sockets={metrics['network_socket_count']} | "
                        f"cpu%={metrics['cpu_usage_pct']:.1f} | "
                        f"mem%={metrics['memory_alloc_spikes']:.1f} | "
                        f"disk_r={metrics['disk_read_kbps']:.0f}KB/s | "
                        f"disk_w={metrics['disk_write_kbps']:.0f}KB/s || "
                        f"[{cat_str}]"
                    )
                    level = "CRITICAL" if score > self.quarantine_threshold else "WARNING"
                    logger.warning(f"[{level}] Anomaly score {score:.3f} — {details}")
                    self.db.log_anomaly(score, details, category_scores=category_z)

                    # ── Auto-quarantine on CRITICAL ──────────────────────
                    if score > self.quarantine_threshold:
                        self._try_quarantine_offender(score, details)

                # ── Log top suspicious PIDs every 10 intervals ───────────
                _interval += 1
                if _interval % 10 == 0:
                    offenders = self.pid_tracker.top_offenders()
                    if offenders:
                        top_str = ", ".join(
                            f"pid={p} score={s:.1f}" for p, s in offenders
                        )
                        logger.info(f"[PidSuspicion] Top offenders: {top_str}")
                    # Purge scores for PIDs that no longer exist
                    live_pids = set(psutil.pids())
                    for pid in list(self.pid_tracker.all_scores()):
                        if pid not in live_pids:
                            self.pid_tracker.reset_pid(pid)

                time.sleep(self.poll_interval)
        finally:
            if _started:
                self.monitor.stop()
            try:
                os.remove(self.PID_FILE)
            except OSError:
                pass
            logger.info("Behavior monitor stopped.")


