import os
import logging
import tempfile
from typing import Optional
from src.paths import app_path

logger = logging.getLogger(__name__)

try:
    import oqs
    _test_kem = oqs.KeyEncapsulation.__doc__  # probe C library
    HAS_OQS = True
    logger.info("liboqs available — post-quantum algorithms active.")
except (ImportError, SystemExit, OSError, RuntimeError):
    HAS_OQS = False
    oqs = None  # type: ignore
    logger.warning(
        "liboqs C library not found. Falling back to classical X25519/Ed25519. "
        "Install liboqs and liboqs-python for quantum-safe cryptography."
    )

from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives import serialization


class KeyManager:
    """
    Manages post-quantum (ML-KEM / ML-DSA) keypairs with a classical fallback
    (X25519 / Ed25519) when liboqs is not installed.
    """

    KEM_ALGO = "ML-KEM-1024"
    SIG_ALGO = "ML-DSA-87"

    def __init__(self, keys_dir: str = None):
        self.keys_dir = keys_dir or app_path("keys")
        os.makedirs(self.keys_dir, exist_ok=True)

    # ─── generation ──────────────────────────────────────────────────────────

    def generate_kem_keypair(self, algo: str = None) -> tuple[bytes, bytes]:
        algo = algo or self.KEM_ALGO
        if HAS_OQS and algo.startswith("ML-KEM"):
            with oqs.KeyEncapsulation(algo) as kem:
                pub = kem.generate_keypair()
                priv = kem.export_secret_key()
            return pub, priv
        # Classical fallback
        logger.warning("Using X25519 fallback (NOT quantum-safe).")
        key = x25519.X25519PrivateKey.generate()
        priv = key.private_bytes(
            serialization.Encoding.Raw,
            serialization.PrivateFormat.Raw,
            serialization.NoEncryption(),
        )
        pub = key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
        return pub, priv

    def generate_sig_keypair(self, algo: str = None) -> tuple[bytes, bytes]:
        algo = algo or self.SIG_ALGO
        if HAS_OQS and (algo.startswith("ML-DSA") or algo.startswith("SLH-DSA")):
            with oqs.Signature(algo) as sig:
                pub = sig.generate_keypair()
                priv = sig.export_secret_key()
            return pub, priv
        # Classical fallback
        logger.warning("Using Ed25519 fallback (NOT quantum-safe).")
        key = ed25519.Ed25519PrivateKey.generate()
        priv = key.private_bytes(
            serialization.Encoding.Raw,
            serialization.PrivateFormat.Raw,
            serialization.NoEncryption(),
        )
        pub = key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
        return pub, priv

    # ─── persistence ─────────────────────────────────────────────────────────

    @staticmethod
    def _ensure_is_file(path: str):
        """If path exists as a directory (stale from os.makedirs bug), remove it."""
        if os.path.isdir(path):
            import shutil
            logger.warning(f"Removing stale directory at key path: {path}")
            shutil.rmtree(path)

    def save_keypair(self, name: str, pub: bytes, priv: bytes):
        """Write public + private key atomically (temp → rename) so a crash
        never leaves a mismatched / incomplete keypair on disk."""
        pub_path  = os.path.join(self.keys_dir, f"{name}.pub")
        priv_path = os.path.join(self.keys_dir, f"{name}.priv")
        self._ensure_is_file(pub_path)
        self._ensure_is_file(priv_path)

        for path, data in ((pub_path, pub), (priv_path, priv)):
            fd, tmp = tempfile.mkstemp(dir=self.keys_dir)
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
                os.replace(tmp, path)
            except Exception:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise

        # Note: os.chmod is a no-op on Windows; wrap so it never crashes
        try:
            os.chmod(priv_path, 0o600)  # private key: readable only by owner
        except OSError:
            logger.warning(
                f"Could not set permissions on {priv_path} "
                "(non-POSIX OS — ensure the file is protected manually)."
            )
        logger.info(f"Saved keypair: {name}.pub / {name}.priv")

    def load_key(self, name: str, key_type: str = "priv") -> Optional[bytes]:
        path = os.path.join(self.keys_dir, f"{name}.{key_type}")
        if not os.path.exists(path):
            return None
        with open(path, "rb") as f:
            return f.read()

    def list_keys(self) -> list[str]:
        return [
            f[:-4]
            for f in sorted(os.listdir(self.keys_dir))
            if f.endswith(".pub")
        ]

    # ─── sign / verify helpers ───────────────────────────────────────────────

    def sign(self, data: bytes, sig_priv: bytes, algo: str = None) -> bytes:
        algo = algo or self.SIG_ALGO
        if HAS_OQS and (algo.startswith("ML-DSA") or algo.startswith("SLH-DSA")):
            with oqs.Signature(algo, secret_key=sig_priv) as signer:
                return signer.sign(data)
        key = ed25519.Ed25519PrivateKey.from_private_bytes(sig_priv)
        return key.sign(data)

    def verify(self, data: bytes, signature: bytes, sig_pub: bytes, algo: str = None) -> bool:
        algo = algo or self.SIG_ALGO
        try:
            if HAS_OQS and (algo.startswith("ML-DSA") or algo.startswith("SLH-DSA")):
                with oqs.Signature(algo) as verifier:
                    return verifier.verify(data, signature, sig_pub)
            pub_key = ed25519.Ed25519PublicKey.from_public_bytes(sig_pub)
            pub_key.verify(signature, data)
            return True
        except Exception:
            return False

    @property
    def is_pqc(self) -> bool:
        return HAS_OQS
