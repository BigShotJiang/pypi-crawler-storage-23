import os
import shutil
import uuid
import hashlib
import logging
from datetime import datetime
from typing import Optional
from src.paths import app_path

logger = logging.getLogger(__name__)


class QuarantineManager:
    """
    Moves suspicious files to an isolated quarantine directory.
    Metadata (original path, hash, reason, timestamp) is stored in SQLite
    via DatabaseManager. Files can be restored, listed, or permanently deleted.
    """

    def __init__(self, quarantine_dir: str = None):
        # Import here to avoid circular dependency at module level
        from src.db.database import DatabaseManager

        self.quarantine_dir = quarantine_dir or app_path("quarantine")
        os.makedirs(self.quarantine_dir, exist_ok=True)
        self.db = DatabaseManager()

    # ─── internal helpers ────────────────────────────────────────────────────

    @staticmethod
    def _sha256(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()

    # ─── public API ──────────────────────────────────────────────────────────

    def quarantine_file(self, file_path: str, reason: str = "Malware detected") -> str:
        """
        Move *file_path* into the quarantine directory.
        Returns the quarantine UUID that can be used to restore/delete later.

        DB record is committed **before** the file is moved so that a DB
        failure never leaves the original file orphaned inside quarantine
        with no recoverable record.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        qid = str(uuid.uuid4())
        dest = os.path.join(self.quarantine_dir, qid)
        file_hash = self._sha256(file_path)
        original_abs = os.path.abspath(file_path)

        # Write DB record first — if this raises, the original file is untouched
        self.db.add_quarantine_entry(
            quarantine_id=qid,
            original_path=original_abs,
            quarantine_path=dest,
            file_hash=file_hash,
            reason=reason,
        )

        # Only move the file after the record is committed
        try:
            shutil.move(file_path, dest)
        except Exception:
            # Roll back the orphaned DB record so state stays consistent
            try:
                self.db.remove_quarantine_entry(qid)
            except Exception as rollback_exc:
                logger.error(f"[QUARANTINE] DB rollback failed: {rollback_exc}")
            raise

        logger.warning(
            f"[QUARANTINE] {original_abs} → {dest}  (id={qid}, reason={reason})"
        )
        return qid

    def restore_file(self, quarantine_id: str) -> bool:
        """Move the quarantined file back to its original location."""
        entry = self.db.get_quarantine_entry(quarantine_id)
        if not entry:
            logger.error(f"No quarantine entry: {quarantine_id}")
            return False

        dest = entry["original_path"]
        src = entry["quarantine_path"]

        if not os.path.exists(src):
            logger.error(f"Quarantined file missing from disk: {src}")
            return False

        # os.path.dirname returns "" for bare filenames — guard before makedirs
        dest_dir = os.path.dirname(dest)
        if dest_dir:
            os.makedirs(dest_dir, exist_ok=True)
        shutil.move(src, dest)
        self.db.remove_quarantine_entry(quarantine_id)
        logger.info(f"[RESTORE] {src} → {dest}")
        return True

    def delete_permanently(self, quarantine_id: str) -> bool:
        """Securely delete a quarantined file and remove its DB record."""
        entry = self.db.get_quarantine_entry(quarantine_id)
        if not entry:
            logger.error(f"No quarantine entry: {quarantine_id}")
            return False

        path = entry["quarantine_path"]
        if os.path.exists(path):
            try:
                # Overwrite before deletion to reduce forensic recovery.
                # Use 'r+b' (in-place) rather than 'wb' so the existing
                # inode is overwritten rather than replaced by a new file.
                size = os.path.getsize(path)
                chunk = 65536  # 64 KB
                with open(path, "r+b") as f:
                    remaining = size
                    while remaining > 0:
                        f.write(os.urandom(min(chunk, remaining)))
                        remaining -= chunk
                    f.flush()
                    os.fsync(f.fileno())
            except OSError as exc:
                # File may be locked on Windows; log and still attempt removal
                logger.warning(
                    f"[DELETE] Could not overwrite before delete "
                    f"(file may be locked): {exc}"
                )
            try:
                os.remove(path)
            except OSError as exc:
                logger.error(f"[DELETE] os.remove failed for '{path}': {exc}")
                raise

        self.db.remove_quarantine_entry(quarantine_id)
        logger.info(f"[DELETE] Permanently removed quarantine id={quarantine_id}")
        return True

    def list_quarantined(self) -> list[dict]:
        return self.db.list_quarantine_entries()

    def get_entry(self, quarantine_id: str) -> Optional[dict]:
        return self.db.get_quarantine_entry(quarantine_id)

    def delete_all(self) -> tuple[int, int]:
        """
        Permanently delete every quarantined file.

        Returns (deleted, failed) counts.
        """
        entries = self.list_quarantined()
        deleted = 0
        failed = 0
        for entry in entries:
            try:
                if self.delete_permanently(entry["id"]):
                    deleted += 1
                else:
                    failed += 1
            except Exception as exc:
                logger.error(
                    f"[DELETE-ALL] Failed to delete id={entry['id']}: {exc}"
                )
                failed += 1
        return deleted, failed
