import os
import re
import json
import math
import numpy as np
import onnxruntime as ort
import logging
import hashlib
from src.scanner.extract import extract_features, BASIC_FEATURE_COUNT
from src.db.database import DatabaseManager
from src.config import Config

logger = logging.getLogger(__name__)

# ── Static-analysis helpers ─────────────────────────────────────────────────

# Directories whose presence in a file path raises the path-anomaly weight
_SUSPICIOUS_DIRS = {
    # Linux / macOS suspicious paths
    "/tmp", "/var/tmp", "/dev/shm",
    "/proc", "/sys",
    # Windows suspicious paths (lowercased for case-insensitive matching)
    "%temp%", "%appdata%", "%localappdata%",
    "\\temp\\", "\\tmp\\", "\\recycler\\", "\\$recycle.bin\\",
    "\\windows\\temp\\", "\\programdata\\",
}

# Double-extension pattern  e.g. "report.pdf.exe", "image.jpg.bat"
_DOUBLE_EXT_RE = re.compile(
    r'\.(pdf|doc|docx|xls|xlsx|ppt|pptx|jpg|jpeg|png|gif|zip|rar|txt|mp3|mp4)'
    r'\.(exe|bat|cmd|ps1|vbs|js|jar|msi|com|scr|pif|hta|wsf)$',
    re.IGNORECASE,
)

# Magic-byte signatures: extension → expected first bytes (hex)
_MAGIC_MAP: dict = {
    ".exe":  b"MZ",
    ".dll":  b"MZ",
    ".pdf":  b"%PDF",
    ".zip":  b"PK\x03\x04",
    ".rar":  b"Rar!",
    ".png":  b"\x89PNG",
    ".jpg":  b"\xff\xd8\xff",
    ".gif":  b"GIF8",
    ".elf":  b"\x7fELF",
}

# Anomaly sub-score weights for the composite threat score.
# Composite = Σ (W_i × A_i × C_i)  scaled to 0–100.
_SCAN_WEIGHTS: dict = {
    "ai_model":        0.40,  # ONNX model confidence
    "entropy":         0.15,  # file entropy (high entropy → packed/encrypted)
    "path_anomaly":    0.10,  # suspicious directory or hidden path
    "double_extension":0.10,  # deceptive double extension
    "type_mismatch":   0.10,  # magic bytes ≠ extension
    "signature":       0.15,  # signature DB hit (partial weight; full hit = 1.0)
}


class LocalScanner:
    """
    Two-stage file scanner:
    1. Hash lookup against local SQLite threat signature DB.
    2. ONNX model inference on extracted file features.

    The companion <model>.meta.json file (written by train.py) records:
        {"n_features": N, "source": "<synthetic|ember|kaggle|files>"}
    so the scanner always uses the feature extractor that matches the
    model's training feature set.
    """

    def __init__(self, model_path: str = None, threshold: float = None):
        cfg = Config.get()
        self.model_path = model_path or cfg.get_value(
            "scanner", "model_path", default="models/malware_detector.onnx"
        )
        # threshold=None means "auto" — read from meta.json first, then config
        self._threshold_override = threshold
        self.threshold = threshold or cfg.get_value(
            "scanner", "malware_threshold", default=0.85
        )
        self.session = None
        self.n_features: int = BASIC_FEATURE_COUNT  # updated from meta
        self.model_source: str = "synthetic"
        self.db = DatabaseManager()
        self._load_model()

    # ── meta helper ──────────────────────────────────────────────────────────

    def _load_meta(self) -> dict:
        """Read companion .meta.json if it exists, else return defaults."""
        meta_path = os.path.splitext(self.model_path)[0] + ".meta.json"
        if os.path.exists(meta_path):
            try:
                with open(meta_path) as f:
                    return json.load(f)
            except Exception as exc:
                logger.warning(f"Could not read model metadata: {exc}")
        return {"n_features": BASIC_FEATURE_COUNT, "source": "synthetic"}

    def _load_model(self):
        if not os.path.exists(self.model_path):
            logger.warning(
                f"Model not found at '{self.model_path}'. "
                "Run 'leukquant train' to generate a model."
            )
            return
        try:
            self.session = ort.InferenceSession(self.model_path)
            meta = self._load_meta()
            self.n_features = meta.get("n_features", BASIC_FEATURE_COUNT)
            self.model_source = meta.get("source", "synthetic")
            # Prefer threshold stored in meta.json (set at training time based
            # on sample count) unless the caller supplied an explicit override.
            if self._threshold_override is None and "threshold" in meta:
                self.threshold = float(meta["threshold"])
            logger.info(
                f"Loaded ONNX model from {self.model_path} "
                f"(source={self.model_source}, features={self.n_features}, "
                f"threshold={self.threshold})"
            )
        except Exception as e:
            logger.error(f"Failed to load model: {e}")

    @staticmethod
    def hash_file(file_path: str) -> str:
        """Compute SHA-256 of a file (primary hash)."""
        h = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    @staticmethod
    def hash_file_md5(file_path: str) -> str:
        """Compute MD5 of a file (used for VirusShare hash-list lookups)."""
        h = hashlib.md5()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    @staticmethod
    def _compute_subscores(file_path: str) -> dict:
        """
        Compute static-analysis anomaly sub-scores (all 0.0–1.0).

        Returns a dict with keys:
          entropy_score      — normalized Shannon entropy (0=low, 1=very high)
          path_anomaly       — 1.0 if path contains a suspicious directory
          double_extension   — 1.0 if filename has a deceptive double extension
          type_mismatch      — 1.0 if magic bytes don’t match declared extension
          file_age_score     — 0.0 (placeholder; requires file-prevalence DB)
        """
        scores: dict = {
            "entropy_score":    0.0,
            "path_anomaly":     0.0,
            "double_extension": 0.0,
            "type_mismatch":    0.0,
            "file_age_score":   0.0,
        }

        # ─ entropy ────────────────────────────────────────────────────
        try:
            with open(file_path, "rb") as fh:
                data = fh.read()
            if data:
                from collections import Counter
                size = len(data)
                entropy = 0.0
                for count in Counter(data).values():
                    p = count / size
                    entropy -= p * math.log2(p)
                # Normalize: entropy 0–8 bits → score 0–1.0
                # Scores > 7.2 (highly compressed/encrypted) map to 1.0
                scores["entropy_score"] = min(1.0, max(0.0, (entropy - 4.0) / 4.0))
        except Exception:
            pass

        # ─ path anomaly ───────────────────────────────────────────────
        try:
            norm_path = file_path.lower().replace("\\", "/")
            basename  = os.path.basename(file_path)
            # Hidden file (Unix dot-file in unexpected location)
            # Use expanduser so this works on both Linux (/home/user) and Windows (C:/Users/user)
            home_norm = os.path.expanduser("~").lower().replace("\\", "/")
            if basename.startswith(".") and home_norm not in norm_path:
                scores["path_anomaly"] = 0.5
            for sus_dir in _SUSPICIOUS_DIRS:
                if sus_dir.lower() in norm_path:
                    scores["path_anomaly"] = 1.0
                    break
        except Exception:
            pass

        # ─ double extension ───────────────────────────────────────────
        try:
            if _DOUBLE_EXT_RE.search(os.path.basename(file_path)):
                scores["double_extension"] = 1.0
        except Exception:
            pass

        # ─ magic bytes vs extension mismatch ──────────────────────────
        try:
            _, ext = os.path.splitext(file_path.lower())
            expected_magic = _MAGIC_MAP.get(ext)
            if expected_magic:
                with open(file_path, "rb") as fh:
                    head = fh.read(len(expected_magic))
                if head != expected_magic:
                    scores["type_mismatch"] = 1.0
        except Exception:
            pass

        return scores

    def scan_file(self, file_path: str) -> dict:
        if not os.path.exists(file_path):
            return {"file": file_path, "error": "File not found"}

        file_hash     = self.hash_file(file_path)      # SHA-256 — primary / display
        file_hash_md5 = self.hash_file_md5(file_path)  # MD5 — for VirusShare lookups

        # ── Static anomaly sub-scores (no model required) ───────────────────────
        sub = self._compute_subscores(file_path)

        # ── Stage 1 — signature DB lookup (SHA-256 first, then MD5) ───────────
        sig = self.db.get_threat_signature(file_hash)
        if not sig and file_hash_md5:
            sig = self.db.get_threat_signature(file_hash_md5)
        if sig:
            composite = self._composite_score(
                ai_score=1.0, sig_score=1.0, subscores=sub
            )
            return {
                "file":                  file_path,
                "hash":                  file_hash,
                "malware_probability":   1.0,
                "verdict":               "MALICIOUS",
                "method":                "signature",
                "severity":              sig.get("severity", 5),
                "source":                sig.get("source", "local"),
                "anomaly_subscores":     sub,
                "composite_threat_score": composite,
                "threat_level":          self._threat_level(composite),
            }

        # ── Stage 2 — AI model inference ─────────────────────────────────
        if not self.session:
            composite = self._composite_score(
                ai_score=0.0, sig_score=0.0, subscores=sub
            )
            return {
                "file":                   file_path,
                "hash":                   file_hash,
                "malware_probability":    0.0,
                "verdict":                "UNKNOWN",
                "method":                 "none",
                "error":                  "Model not loaded",
                "anomaly_subscores":      sub,
                "composite_threat_score": composite,
                "threat_level":           self._threat_level(composite),
            }

        try:
            # Select extractor by feature count, not source tag — this works
            # correctly for every source (synthetic/ember/files/kaggle) and
            # is robust to lief version differences in the EMBER vector length.
            use_ember = (self.n_features > BASIC_FEATURE_COUNT)
            features  = extract_features(file_path, use_ember=use_ember)

            # Validate dimension before handing to ONNX — give a clear message
            if len(features) != self.n_features:
                return {
                    "file":  file_path,
                    "hash":  file_hash,
                    "malware_probability": 0.0,
                    "verdict": "ERROR",
                    "method": "none",
                    "error": (
                        f"Feature dimension mismatch: extractor produced {len(features)} "
                        f"but model expects {self.n_features}. "
                        f"Retrain with: leukquant train --source {'ember' if use_ember else 'synthetic'}"
                    ),
                }
            tensor     = np.array([features], dtype=np.float32)
            input_name = self.session.get_inputs()[0].name
            result     = self.session.run(None, {input_name: tensor})

            # skl2onnx emits a ZipMap as result[1] for probability output
            if (
                len(result) > 1
                and isinstance(result[1], list)
                and isinstance(result[1][0], dict)
            ):
                # Note: skl2onnx may emit ZipMap keys as int (1) OR str ("1")
                # depending on the skl2onnx/onnxruntime version. Try both.
                proba_map = result[1][0]
                score = float(proba_map.get(1, proba_map.get("1", 0.0)))
            else:
                probs = result[0][0]
                score = float(probs[1]) if len(probs) > 1 else float(probs[0])

            verdict   = "MALICIOUS" if score > self.threshold else "CLEAN"
            composite = self._composite_score(
                ai_score=score, sig_score=0.0, subscores=sub
            )
            return {
                "file":                   file_path,
                "hash":                   file_hash,
                "malware_probability":    score,
                "verdict":                verdict,
                "method":                 "ai_model",
                "anomaly_subscores":      sub,
                "composite_threat_score": composite,
                "threat_level":           self._threat_level(composite),
            }
        except Exception as e:
            logger.error(f"Error scanning {file_path}: {e}")
            return {"file": file_path, "error": str(e)}

    # ── Composite scoring helpers ──────────────────────────────────────────

    @staticmethod
    def _composite_score(
        ai_score: float,
        sig_score: float,
        subscores: dict,
        confidence: float = 1.0,
    ) -> float:
        """
        Compute a 0–100 composite threat score:

            Composite = 100 × Σ (W_i × A_i × C_i)

        where W_i are the category weights, A_i are the per-indicator
        anomaly scores (0–1), and C_i is the confidence factor.
        """
        weighted = (
            _SCAN_WEIGHTS["ai_model"]         * ai_score         * confidence
            + _SCAN_WEIGHTS["signature"]       * sig_score        * confidence
            + _SCAN_WEIGHTS["entropy"]         * subscores.get("entropy_score",    0.0) * confidence
            + _SCAN_WEIGHTS["path_anomaly"]    * subscores.get("path_anomaly",     0.0) * confidence
            + _SCAN_WEIGHTS["double_extension"]* subscores.get("double_extension", 0.0) * confidence
            + _SCAN_WEIGHTS["type_mismatch"]   * subscores.get("type_mismatch",    0.0) * confidence
        )
        return round(min(100.0, max(0.0, weighted * 100)), 2)

    @staticmethod
    def _threat_level(composite: float) -> str:
        """Map composite score to a human-readable severity tier."""
        if composite >= 91:  return "CRITICAL"
        if composite >= 76:  return "HIGH"
        if composite >= 51:  return "MEDIUM"
        if composite >= 26:  return "LOW"
        return "INFORMATIONAL"
