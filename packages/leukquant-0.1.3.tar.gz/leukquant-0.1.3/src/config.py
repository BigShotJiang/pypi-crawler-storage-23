import os
import copy
import tempfile
import yaml
import logging
from src.paths import app_path

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "behavior": {
        "baseline_period_days": 14,
        "alert_threshold": 3.5,
        "quarantine_threshold": 5.0,
        "features_monitored": [
            "process_spawn_rate",
            "file_write_rate",
            "network_socket_count",
            "memory_alloc_spikes",
        ],
    },
    "scanner": {
        "model_path": app_path("models", "malware_detector.onnx"),
        "malware_threshold": 0.85,
    },
    "crypto": {
        "default_kem": "ML-KEM-1024",
        "default_sig": "ML-DSA-87",
        "fallback_sig": "SLH-DSA-SHAKE-256s",
        "keys_dir": app_path("keys"),
    },
    "db": {
        "threats_db": app_path("db", "threats.db"),
        "behavior_db": app_path("db", "behavior_baseline.db"),
    },
    "quarantine": {
        "dir": app_path("quarantine"),
    },
    "offline": {
        "export_dir": app_path("exports"),
    },
}


class Config:
    _instance = None

    def __init__(self, config_path: str = None):
        self._data = copy.deepcopy(DEFAULT_CONFIG)
        self.config_path = config_path or app_path("config", "Leukquant.yml")
        self._load()

    @classmethod
    def get(cls, config_path: str = None) -> "Config":
        if cls._instance is None:
            cls._instance = cls(config_path)
        return cls._instance

    def _load(self):
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    overrides = yaml.safe_load(f)
                if overrides:
                    self._deep_merge(self._data, overrides)
                logger.debug(f"Loaded config from {self.config_path}")
            except Exception as e:
                logger.warning(f"Failed to load config: {e}. Using defaults.")

    def _deep_merge(self, base: dict, override: dict):
        for k, v in override.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                self._deep_merge(base[k], v)
            else:
                base[k] = v

    def save(self):
        """Write config atomically (temp file → rename) with explicit UTF-8 encoding."""
        config_dir = os.path.dirname(self.config_path)
        os.makedirs(config_dir, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(dir=config_dir, suffix=".yml.tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                yaml.safe_dump(self._data, f, default_flow_style=False)
            os.replace(tmp_path, self.config_path)  # atomic on POSIX; near-atomic on Windows
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    def __getitem__(self, key):
        return self._data[key]

    def get_value(self, *keys, default=None):
        d = self._data
        for k in keys:
            if isinstance(d, dict) and k in d:
                d = d[k]
            else:
                return default
        return d
