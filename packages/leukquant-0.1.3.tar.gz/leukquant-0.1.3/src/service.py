"""
Leukquant — Auto-start Service Installer
==========================================
Installs / uninstalls the Leukquant monitor daemon as a persistent
system service so it survives reboots without any manual intervention.

Platform support
----------------
Linux   systemd **user** unit
          ~/.config/systemd/user/leukquant.service
          Enabled via:  systemctl --user enable --now leukquant
          Boot support: loginctl enable-linger <user>   (run once per user)

Windows Task Scheduler task (no admin rights required for user tasks)
          Task name:  Leukquant\\Monitor
          Trigger:    At log-on of current user
          Action:     leukquant monitor start   (foreground; scheduler owns lifetime)

Both platforms write a small "service_info.json" marker to
~/.leukquant/  so that `leukquant status` can report the install state.
"""

import os
import sys
import json
import shutil
import logging
import platform
import subprocess
from src.paths import app_path

logger = logging.getLogger(__name__)

_SYSTEM   = platform.system()          # "Linux" | "Windows" | "Darwin"
_IS_WIN   = _SYSTEM == "Windows"
_IS_LINUX = _SYSTEM == "Linux"

_SERVICE_NAME    = "leukquant"
_TASK_PATH       = r"Leukquant\Monitor"   # Windows task scheduler path
_SERVICE_INFO    = app_path("service_info.json")


# ─── helpers ──────────────────────────────────────────────────────────────────

def _leukquant_exe() -> str:
    """Absolute path to the active leukquant executable."""
    exe = shutil.which("leukquant")
    if exe:
        return os.path.abspath(exe)
    # Fallback: reconstruct from current Python's Scripts / bin dir
    scripts = os.path.join(os.path.dirname(sys.executable),
                           "Scripts" if _IS_WIN else "bin",
                           "leukquant" + (".exe" if _IS_WIN else ""))
    return scripts


def _run(cmd: list, *, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


def _save_info(installed: bool, method: str = ""):
    os.makedirs(app_path(), exist_ok=True)
    with open(_SERVICE_INFO, "w") as f:
        json.dump({"installed": installed, "method": method, "platform": _SYSTEM}, f)


def service_installed() -> bool:
    if os.path.exists(_SERVICE_INFO):
        try:
            with open(_SERVICE_INFO) as f:
                return json.load(f).get("installed", False)
        except Exception:
            pass
    return False


# ═══════════════════════════════════════════════════════════════════════════════
# Linux — systemd user unit
# ═══════════════════════════════════════════════════════════════════════════════

def _systemd_unit_dir() -> str:
    return os.path.expanduser("~/.config/systemd/user")


def _systemd_unit_path() -> str:
    return os.path.join(_systemd_unit_dir(), f"{_SERVICE_NAME}.service")


def _write_systemd_unit(exe: str) -> str:
    unit = f"""\
[Unit]
Description=Leukquant Behavior & Threat Monitor
Documentation=https://github.com/leukquant/leukquant
After=network.target

[Service]
Type=simple
ExecStart={exe} monitor start
Restart=on-failure
RestartSec=15
# Keep stdout/stderr in the journal:  journalctl --user -u leukquant
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
"""
    unit_dir = _systemd_unit_dir()
    os.makedirs(unit_dir, exist_ok=True)
    unit_path = _systemd_unit_path()
    with open(unit_path, "w") as f:
        f.write(unit)
    return unit_path


def install_linux() -> tuple[bool, str]:
    """
    Install a systemd user unit and enable it for boot.

    Returns (success, message).
    """
    exe = _leukquant_exe()
    if not os.path.isfile(exe):
        return False, f"leukquant binary not found at {exe!r}. Is the env active?"

    unit_path = _write_systemd_unit(exe)

    steps = [
        (["systemctl", "--user", "daemon-reload"],   "daemon-reload"),
        (["systemctl", "--user", "enable", "--now", _SERVICE_NAME], "enable --now"),
    ]
    for cmd, label in steps:
        r = _run(cmd, check=False)
        if r.returncode != 0:
            return False, (
                f"'systemctl --user {label}' failed (rc={r.returncode}):\n"
                f"{r.stderr.strip()}"
            )

    # Enable linger so the user unit survives logout / starts at boot
    # Note: USER and LOGNAME may both be unset (Docker, some daemons);
    # fall back to getpass.getuser() which queries the OS username database.
    user = (
        os.environ.get("USER")
        or os.environ.get("LOGNAME")
        or __import__("getpass").getuser()
    )
    if user:
        _run(["loginctl", "enable-linger", user], check=False)

    _save_info(True, "systemd-user")
    return True, (
        f"systemd user unit installed: {unit_path}\n"
        f"Service enabled and started.  Logs: journalctl --user -u {_SERVICE_NAME}"
    )


def uninstall_linux() -> tuple[bool, str]:
    steps = [
        ["systemctl", "--user", "stop",    _SERVICE_NAME],
        ["systemctl", "--user", "disable", _SERVICE_NAME],
    ]
    for cmd in steps:
        _run(cmd, check=False)

    unit_path = _systemd_unit_path()
    if os.path.exists(unit_path):
        os.remove(unit_path)

    _run(["systemctl", "--user", "daemon-reload"], check=False)
    _save_info(False)
    return True, f"systemd user unit removed: {unit_path}"


# ═══════════════════════════════════════════════════════════════════════════════
# Windows — Task Scheduler
# ═══════════════════════════════════════════════════════════════════════════════

def _schtasks(*args) -> subprocess.CompletedProcess:
    return _run(["schtasks"] + list(args), check=False)


def install_windows() -> tuple[bool, str]:
    import xml.sax.saxutils as _sax
    exe = _leukquant_exe()
    if not os.path.isfile(exe):
        return False, f"leukquant binary not found at {exe!r}. Is the env active?"

    # XML-escape the exe path so special characters (&, <, >, ")
    # in unusual install paths don’t break the XML or allow tag injection.
    exe_escaped = _sax.escape(exe)

    # Build the XML for a richer task definition (start on logon + on system start)
    xml = f"""\
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2"
  xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Leukquant Behavior and Threat Monitor — auto-start on logon</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
    </LogonTrigger>
  </Triggers>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>10</Count>
    </RestartOnFailure>
  </Settings>
  <Actions>
    <Exec>
      <Command>{exe_escaped}</Command>
      <Arguments>monitor start</Arguments>
    </Exec>
  </Actions>
</Task>
"""
    os.makedirs(app_path(), exist_ok=True)
    xml_path = app_path("service_task.xml")
    with open(xml_path, "w", encoding="utf-16") as f:
        f.write(xml)

    # Delete any existing task silently first
    _schtasks("/delete", "/tn", _TASK_PATH, "/f")

    r = _schtasks("/create", "/tn", _TASK_PATH, "/xml", xml_path, "/f")
    if r.returncode != 0:
        return False, f"schtasks /create failed:\n{r.stderr.strip() or r.stdout.strip()}"

    # Run it immediately as well
    _schtasks("/run", "/tn", _TASK_PATH)

    _save_info(True, "schtasks")
    return True, (
        f"Task Scheduler task '{_TASK_PATH}' created.\n"
        f"The monitor will start automatically on every logon.\n"
        f"Manage in: Task Scheduler > Task Scheduler Library > Leukquant"
    )


def uninstall_windows() -> tuple[bool, str]:
    _schtasks("/end",    "/tn", _TASK_PATH)
    r = _schtasks("/delete", "/tn", _TASK_PATH, "/f")
    _save_info(False)
    if r.returncode != 0:
        return False, f"schtasks /delete failed:\n{r.stderr.strip()}"
    return True, f"Task Scheduler task '{_TASK_PATH}' removed."


# ═══════════════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════════════

def install_service() -> tuple[bool, str]:
    """Install the auto-start service for the current platform."""
    if _IS_LINUX:
        return install_linux()
    if _IS_WIN:
        return install_windows()
    return False, f"Auto-start is not supported on {_SYSTEM}."


def uninstall_service() -> tuple[bool, str]:
    """Remove the auto-start service for the current platform."""
    if _IS_LINUX:
        return uninstall_linux()
    if _IS_WIN:
        return uninstall_windows()
    return False, f"Auto-start is not supported on {_SYSTEM}."
