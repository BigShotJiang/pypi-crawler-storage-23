#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
Unified hash command: SM3 (GM/T) and SHA256, SHA384, SHA512.
"""
from __future__ import annotations

import hashlib

import click

from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import shell_completion
from easy_encryption_tool import command_perf
from easy_encryption_tool import validators
from easy_encryption_tool.rich_ui import error, plain_copyable_block, result_table

try:
    from easy_gmssl import EasySM3Digest

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

hash_alg_map = {
    "sha256": hashlib.sha256,
    "sha384": hashlib.sha384,
    "sha512": hashlib.sha512,
}
if EASY_GMSSL_AVAILABLE:
    hash_alg_map["sm3"] = "sm3"


def _compute_hash_fixed(alg: str, data: bytes) -> bytes:
    if alg == "sm3":
        return EasySM3Digest.Hash(data)
    h = hash_alg_map[alg]()
    h.update(data)
    return h.digest()


@click.command(name="hash", short_help="Hash digest: SM3, SHA256, SHA384, SHA512")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input: string, base64, or file path",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    type=click.Choice(list(hash_alg_map.keys())),
    default="sha256",
    show_default=True,
    help="Hash algorithm",
)
@command_perf.timing_decorator
def hash_command(
    input_data: str, is_base64_encoded: bool, is_a_file: bool, hash_alg: str
):
    """Compute hash digest. Default -i is UTF-8 plaintext; -e means base64; -f means file."""
    if hash_alg == "sm3" and not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM3")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "hash")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    input_raw_bytes = b""
    if not is_a_file:
        if not is_base64_encoded:
            try:
                input_raw_bytes = input_data.encode("utf-8")
            except UnicodeEncodeError:
                error("input contains invalid UTF-8 characters")
                return
        else:
            try:
                input_raw_bytes = common.decode_b64_data(input_data)
            except BaseException as e:
                error("invalid b64 encoded data: {}".format(e))
                hints.hint_invalid_b64("hash")
                return
        digest = _compute_hash_fixed(hash_alg, input_raw_bytes)
        result_table(
            {
                "hash algorithm": hash_alg,
                "input type": "base64" if is_base64_encoded else "utf-8 string",
                "input size": "{} bytes".format(len(input_raw_bytes)),
                "digest size": "{} bytes".format(len(digest)),
                "output format": "hex",
            },
            title="Hash",
        )
        plain_copyable_block("hash", digest.hex())
    else:
        try:
            with common.read_from_file(input_data) as input_file:
                if hash_alg == "sm3":
                    ctx = EasySM3Digest()
                    data_len = 0
                    while True:
                        chunk = input_file.read_n_bytes(4096)
                        if not chunk:
                            break
                        ctx.UpdateData(chunk)
                        data_len += len(chunk)
                    digest, _, _ = ctx.GetHash()
                else:
                    h = hash_alg_map[hash_alg]()
                    data_len = 0
                    while True:
                        chunk = input_file.read_n_bytes(4096)
                        if not chunk:
                            break
                        h.update(chunk)
                        data_len += len(chunk)
                    digest = h.digest()
                result_table(
                    {
                        "hash algorithm": hash_alg,
                        "input type": "file",
                        "file size": "{} bytes".format(data_len),
                        "digest size": "{} bytes".format(len(digest)),
                        "output format": "hex",
                    },
                    title="Hash (File)",
                )
                plain_copyable_block("hash", digest.hex())
        except OSError:
            error("file {} may not exist or may not be readable".format(input_data))
            return


if __name__ == "__main__":
    hash_command()
