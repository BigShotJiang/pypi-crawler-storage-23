#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-01 09:11:56
from __future__ import annotations

import base64
import binascii
import os
import os.path
import sys
import tempfile
from typing import Tuple

import click
from cryptography.hazmat.backends import default_backend

from easy_encryption_tool.rich_ui import error, info, success
from cryptography.hazmat.primitives import serialization

from easy_encryption_tool import random_str


def decode_b64_data(data: str) -> bytes:
    """Base64 decode, strict mode: reject invalid characters"""
    if len(data) <= 0:
        return bytes()
    # Strict mode: only standard base64 chars allowed
    if sys.version_info >= (3, 11):
        try:
            return base64.b64decode(data, validate=True)
        except binascii.Error as e:
            raise ValueError("base64 decode failed (invalid chars or format)") from e
    else:
        allowed = set(
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r "
        )
        if not all(c in allowed for c in data):
            raise ValueError("base64 input contains invalid characters")
        try:
            return base64.b64decode(data)
        except binascii.Error as e:
            raise ValueError("base64 decode failed") from e


def check_is_file_readable(input_data: str) -> bool:
    """Check if file exists and is readable"""
    return (
        os.path.exists(input_data)
        and os.access(input_data, mode=os.R_OK)
        and os.path.isfile(input_data)
    )


def check_is_file_writable(input_data: str, force: bool = True) -> bool:
    """
    Check if path is writable. If file exists, force=True overwrites, force=False returns False.
    Default force=True matches cp behavior; pass force=False to avoid overwrite.
    """
    if not os.path.exists(input_data):
        try:
            with open(input_data, "w") as _:
                pass
            return True
        except OSError:
            return False
    if not os.path.isfile(input_data) or not os.access(input_data, os.W_OK):
        return False
    if not force:
        return False  # exists and not force overwrite
    with open(input_data, "w") as file:
        file.truncate(0)
    return True


def process_key_iv(
    is_random: bool,
    key: str,
    iv: str,
    key_len: int,
    iv_len: int,
    nonce_len: int | None = None,
    mode: str | None = None,
) -> Tuple[str, str]:
    """
    Unified key/IV handling: random generate or pad/truncate to length (CSPRNG for padding).
    When mode is 'gcm' use nonce_len for iv length, else iv_len.
    """
    if is_random:
        key = random_str.generate_random_str(key_len)
        nlen = nonce_len if (mode == "gcm" and nonce_len is not None) else iv_len
        iv = random_str.generate_random_str(nlen)
        return key, iv
    # Truncate or pad
    if len(key) > key_len:
        key = key[:key_len]
    elif len(key) < key_len:
        key = key + random_str.generate_random_str(key_len - len(key))
    nlen = nonce_len if (mode == "gcm" and nonce_len is not None) else iv_len
    if len(iv) > nlen:
        iv = iv[:nlen]
    elif len(iv) < nlen:
        iv = iv + random_str.generate_random_str(nlen - len(iv))
    return key, iv


def validate_gcm_cipher_format(cipher_with_tag: bytes, tag_len: int) -> bool:
    """
    Validate GCM cipher format (NIST SP 800-38D: ciphertext || tag)
    :param cipher_with_tag: full cipher+tag bytes
    :param tag_len: tag length (usually 16 bytes)
    :return: True if format valid
    """
    if cipher_with_tag is None or len(cipher_with_tag) < tag_len:
        return False
    return True


def check_b64_data(input_data: str) -> Tuple[bool, bytes]:
    if len(input_data) <= 0:
        return False, b""
    try:
        ret = decode_b64_data(input_data)
    except (binascii.Error, ValueError):
        return False, b""
    else:
        if len(ret) <= 0:
            return False, b""
        return True, ret


class read_from_file:
    """Context manager for file read, ensures handle is closed"""

    def __init__(self, file_path: str):
        self._opened = False
        self._path = file_path
        if not check_is_file_readable(file_path):
            raise OSError("read from file {} error".format(file_path))
        self._file = open(file_path, "rb")
        self._opened = True

    def read_n_bytes(self, n: int) -> bytes:
        return self._file.read(n)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        if self._opened:
            self._file.close()
            self._opened = False

    def __del__(self):
        self.close()


def _check_can_write_atomic(file_path: str, force: bool) -> bool:
    """Check if path is writable (for atomic write, does not create/truncate target)"""
    if os.path.exists(file_path):
        if not os.path.isfile(file_path) or not os.access(file_path, os.W_OK):
            return False
        if not force:
            return False
    else:
        parent = os.path.dirname(file_path)
        if parent and not os.path.exists(parent):
            return False
        if parent and not os.access(parent, os.W_OK):
            return False
    return True


class write_to_file:
    """Context manager for file write, atomic write then rename to avoid partial write"""

    def __init__(self, file_path: str, force: bool = True):
        self._opened = False
        self._path = os.path.abspath(file_path)
        if not _check_can_write_atomic(file_path, force=force):
            raise OSError("write to file {} error".format(file_path))
        parent_dir = os.path.dirname(self._path) or "."
        fd, self._temp_path = tempfile.mkstemp(
            dir=parent_dir, prefix=".tmp_", suffix=""
        )
        try:
            self._file = os.fdopen(fd, "wb")
        except BaseException:
            os.unlink(self._temp_path)
            raise
        self._opened = True

    def write_bytes(self, data: bytes) -> bool:
        try:
            if len(data) > 0:
                self._file.write(data)
                self._file.flush()
        except BaseException as e:
            error("write to {} failed: {}".format(self._path, e))
            return False
        return True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        if not self._opened:
            return
        self._opened = False
        try:
            self._file.close()
        finally:
            try:
                os.replace(self._temp_path, self._path)
            except OSError as e:
                error("atomic rename to {} failed: {}".format(self._path, e))
            finally:
                if os.path.exists(self._temp_path):
                    try:
                        os.unlink(self._temp_path)
                    except OSError:
                        pass

    def __del__(self):
        self.close()


encoding_maps = {
    "pem": serialization.Encoding.PEM,
    "der": serialization.Encoding.DER,
    # 'ssh': serialization.Encoding.OpenSSH,
    # 'raw': serialization.Encoding.Raw,
    # 'smime': serialization.Encoding.SMIME,
    # 'x962': serialization.Encoding.X962,
}


def private_key_password(is_random: bool, password: str | None):
    enc = serialization.NoEncryption()
    if is_random:
        password = random_str.generate_random_str(32)
    if (
        password is not None and len(password) > 0
    ):  # If password provided, encrypt private key when writing
        enc = serialization.BestAvailableEncryption(password.encode("utf-8"))
    return password, enc


def load_public_key(encoding: str, file_path: str):
    try:
        pub_key = None
        with open(file_path, "rb") as key_file:
            if encoding == "pem":
                pub_key = serialization.load_pem_public_key(
                    key_file.read(), backend=default_backend()
                )
            if encoding == "der":
                pub_key = serialization.load_der_public_key(
                    key_file.read(), backend=default_backend()
                )
    except BaseException as e:
        error("load public key {} failed: {}".format(file_path, e))
        return None
    else:
        return pub_key


def load_private_key(encoding: str, file_path: str, password_bytes: bytes):
    pri_key = None
    try:  # Read private key
        with open(file_path, "rb") as key_file:
            if encoding == "pem":
                pri_key = serialization.load_pem_private_key(
                    key_file.read(), backend=default_backend(), password=password_bytes
                )
            if encoding == "der":
                pri_key = serialization.load_der_private_key(
                    key_file.read(), backend=default_backend(), password=password_bytes
                )
    except BaseException as e:
        error("load private key {} failed: {}".format(file_path, e))
        return None
    else:
        return pri_key


def bytes_to_str(data: bytes) -> Tuple[bool, str]:
    if data is None:
        return False, ""
    try:
        ret = data.decode("utf-8")
    except BaseException:
        return False, base64.b64encode(data).decode("utf-8")
    else:
        return True, ret


def write_asymmetric_key(
    file_name_prefix: str,
    asymmetric_type: str,
    encoding_type: str,
    is_private_encrypted: bool,
    private_password: str,
    public_data: bytes,
    private_data: bytes,
) -> bool:
    if file_name_prefix is None or len(file_name_prefix) <= 0:
        return False

    if len(file_name_prefix) > 0:
        public_file = "{}_{}_public.{}".format(
            file_name_prefix, asymmetric_type, encoding_type
        )
        private_file = "{}_{}_private.{}".format(
            file_name_prefix, asymmetric_type, encoding_type
        )
        if (
            is_private_encrypted
            and private_password is not None
            and len(private_password) > 0
        ):
            private_file = "{}_{}_private_cipher.{}".format(
                file_name_prefix, asymmetric_type, encoding_type
            )
        for i in [public_file, private_file]:
            try:
                f = write_to_file(i)
            except BaseException as e:
                error("write to {} failed: {}".format(i, e))
                return False
            else:
                if i == public_file:
                    if not f.write_bytes(public_data):
                        return False
                elif i == private_file:
                    if not f.write_bytes(private_data):
                        return False
                    if (
                        is_private_encrypted
                        and private_password is not None
                        and len(private_password) > 0
                    ):
                        info("private key password: {}".format(private_password))
        success("generate {}/{} success".format(public_file, private_file))
        return True
