#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 15:41:41
# 在导入子模块前注入 rich_click（若已安装），使所有子命令的 --help 获得统一 Rich 风格
# 使用 patch() 而非 sys.modules 替换，避免 _compat_click 误读版本号及 click.types 递归问题
import sys
try:
    from rich_click.patch import patch
    patch()
except ImportError:
    pass

import difflib
import os
import subprocess
import sys

import click

from easy_encryption_tool import (
    aes_command,
    cert_parse,
    ecc_command,
    hash_command,
    hmac_command,
    random_str,
    rsa_command,
    sm2_command,
    sm4_command,
    tool_version,
    zuc_command,
)


# 使用 RichGroup 获得统一 Rich 风格帮助，同时保留命令纠错
_BaseGroup = getattr(click, "RichGroup", click.Group)


class SmartGroup(_BaseGroup):
    """Group with similar command suggestions and Rich help"""

    def resolve_command(self, ctx, args):
        cmd_name = args[0] if args else None
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError as e:
            msg = str(e).lower()
            if cmd_name and ("no such command" in msg or "unknown command" in msg):
                suggestions = difflib.get_close_matches(
                    cmd_name, self.list_commands(ctx), n=3, cutoff=0.4
                )
                if suggestions:
                    from easy_encryption_tool.rich_ui import console, suggestion_panel

                    console.print(str(e))
                    suggestion_panel(suggestions)
            raise


def _show_welcome():
    """Show welcome message when no subcommand is given"""
    from easy_encryption_tool.rich_ui import welcome_panel

    welcome_panel([
        ("AES Encryption", "easy_encryption_tool aes -A encrypt -i 'hello'"),
        ("Random String", "easy_encryption_tool random-str -l 32"),
        ("Hash Digest", "easy_encryption_tool hash -i 'data' -a sha256"),
        ("Help", "easy_encryption_tool --help"),
        ("Tab Completion", "easy_encryption_tool install-completion --shell zsh"),
    ])


def _get_executable():
    """获取可执行文件路径，用于生成补全脚本"""
    import shutil

    which = shutil.which("easy_encryption_tool")
    if which:
        return which
    return sys.executable


def _patch_completion_script(script: str, shell: str) -> str:
    """
    后处理补全脚本：当当前词为空时，用 "-" 重试以触发选项补全，并与已有补全合并。
    - 叶子命令后（如 sm4 encrypt 后）：空词时 Click 返回空，用 - 拿到选项
    - 子命令组后（如 sm2 后）：空词时 Click 返回子命令，同时用 - 拿到选项（如 --help），合并展示
    """
    if shell == "zsh":
        old = (
            'response=("${(@f)$(env COMP_WORDS="${words[*]}" '
            'COMP_CWORD=$((CURRENT-1)) _EASY_ENCRYPTION_TOOL_COMPLETE=zsh_complete easy_encryption_tool)}")'
        )
        new = """response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) _EASY_ENCRYPTION_TOOL_COMPLETE=zsh_complete easy_encryption_tool)}")
    if [[ -z "${words[$CURRENT]:-}" ]]; then
        local opts=("${(@f)$(env COMP_WORDS="${words[1,$((CURRENT-1))]} -" COMP_CWORD=$((CURRENT-1)) _EASY_ENCRYPTION_TOOL_COMPLETE=zsh_complete easy_encryption_tool)}")
        local r="${(F)response}"
        if [[ -z "${r//[[:space:]]/}" ]]; then
            response=("${opts[@]}")
        elif [[ -n "${(F)opts}" ]]; then
            response=("${response[@]}" "${opts[@]}")
        fi
    fi"""
        if old in script:
            script = script.replace(old, new)
    elif shell == "bash":
        old = (
            'response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD '
            "_EASY_ENCRYPTION_TOOL_COMPLETE=bash_complete $1)"
        )
        new = """response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD _EASY_ENCRYPTION_TOOL_COMPLETE=bash_complete $1)
    if [[ -z "${COMP_WORDS[$COMP_CWORD]:-}" ]]; then
        local opts
        opts=$(env COMP_WORDS="${COMP_WORDS[*]} -" COMP_CWORD=$(($COMP_CWORD + 1)) _EASY_ENCRYPTION_TOOL_COMPLETE=bash_complete $1)
        local r="$response"
        if [[ -z "${r//[[:space:]]/}" ]]; then
            response="$opts"
        elif [[ -n "$opts" ]]; then
            response="$response"$'\\n'"$opts"
        fi
    fi"""
        if old in script:
            script = script.replace(old, new)
    return script


@click.command(
    name="install-completion",
    short_help="Install shell tab completion (bash/zsh/fish)",
)
@click.option(
    "--shell",
    "-s",
    type=click.Choice(["bash", "zsh", "fish"]),
    default=None,
    help="Shell type; auto-detect if not specified",
)
@click.option(
    "--path",
    "-p",
    "path_opt",
    type=click.Path(),
    default=None,
    help="Write completion script to file instead of stdout",
)
def install_completion(shell, path_opt):
    """生成并安装 Shell 自动补全脚本。支持 bash、zsh、fish。"""
    env_var = "_EASY_ENCRYPTION_TOOL_COMPLETE"
    if shell is None:
        shell = "bash"
        shell_env = os.environ.get("SHELL", "")
        if "zsh" in shell_env:
            shell = "zsh"
        elif "fish" in shell_env:
            shell = "fish"

    env = os.environ.copy()
    env[env_var] = f"{shell}_source"
    exe = _get_executable()
    cmd = [exe, "-m", "easy_encryption_tool.main"] if "python" in exe.lower() else [exe]
    try:
        result = subprocess.run(
            cmd,
            env=env,
            capture_output=True,
            text=True,
        )
        script = result.stdout or ""
        if result.returncode != 0 and not script:
            click.echo("Failed to generate completion script.", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    # 后处理：子命令后空词时用 "-" 触发选项补全（Click 默认需输入 - 才显示选项）
    script = _patch_completion_script(script, shell)

    if path_opt:
        try:
            with open(path_opt, "w") as f:
                f.write(script)
            click.echo(f"Completion script written to {path_opt}")
            click.echo(f"Add to your shell config: source {path_opt}")
        except OSError as e:
            click.echo(f"Failed to write file: {e}", err=True)
            sys.exit(1)
    else:
        click.echo(script)


@click.group(
    name="easy_encryption_tool",
    short_help="Cryptography CLI tool for AES, RSA, ECC, SM2, hash, HMAC, etc.",
    invoke_without_command=True,
    cls=SmartGroup,
)
@click.pass_context
def encryption_tool(ctx):
    if ctx.invoked_subcommand is None:
        _show_welcome()
        return


encryption_tool.add_command(tool_version.show_version)
encryption_tool.add_command(install_completion)
encryption_tool.add_command(aes_command.aes_command)
encryption_tool.add_command(sm4_command.sm4_command)
encryption_tool.add_command(random_str.get_random_str)

encryption_tool.add_command(hash_command.hash_command)
encryption_tool.add_command(hmac_command.hmac_command)

rsa_command.rsa_group.add_command(rsa_command.generate_key_pair)
rsa_command.rsa_group.add_command(rsa_command.rsa_encrypt)
rsa_command.rsa_group.add_command(rsa_command.rsa_decrypt)
rsa_command.rsa_group.add_command(rsa_command.rsa_sign)
rsa_command.rsa_group.add_command(rsa_command.rsa_verify)
encryption_tool.add_command(rsa_command.rsa_group)

ecc_command.ecc_group.add_command(ecc_command.generate)
ecc_command.ecc_group.add_command(ecc_command.key_exchange)
ecc_command.ecc_group.add_command(ecc_command.ecc_sign)
ecc_command.ecc_group.add_command(ecc_command.ecc_verify)
encryption_tool.add_command(ecc_command.ecc_group)

encryption_tool.add_command(sm2_command.sm2_group)

encryption_tool.add_command(zuc_command.zuc_command)

encryption_tool.add_command(cert_parse.parse_x509_cert_file)


if __name__ == "__main__":
    encryption_tool()
