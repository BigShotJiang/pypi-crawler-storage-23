#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-04 11:19:31
"""
性能计时装饰器。通过环境变量 EET_DEBUG_TIMING=1 启用详细计时输出。
"""
import hashlib
import os
import time
from datetime import datetime

from easy_encryption_tool.rich_ui import timing_begin, timing_end


def timing_decorator(func):
    def wrapper(*args, **kwargs):
        debug = os.environ.get("EET_DEBUG_TIMING", "").strip() in ("1", "true", "yes")
        now = datetime.now().strftime("%Y-%m-%d_%H:%M:%S.%f")[:-3]
        unique_flag = hashlib.sha3_512(now.encode("utf-8")).hexdigest()[-16:]
        if debug:
            timing_begin(unique_flag, now)
        start_time = time.perf_counter()
        result = func(*args, **kwargs)
        end_time = time.perf_counter()
        if debug:
            timing_end(unique_flag, (end_time - start_time) * 1000)
        return result

    return wrapper
