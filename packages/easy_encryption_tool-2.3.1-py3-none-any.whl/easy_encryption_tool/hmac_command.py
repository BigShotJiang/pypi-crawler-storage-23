#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-02 10:57:19
import hashlib
import hmac

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import shell_completion
from easy_encryption_tool import random_str
from easy_encryption_tool import command_perf
from easy_encryption_tool import validators
from easy_encryption_tool.rich_ui import error, plain_copyable_block, result_table, warning

try:
    from easy_gmssl import EasySM3Hmac
    from easy_gmssl.gmssl import SM3_HMAC_MIN_KEY_SIZE, SM3_HMAC_MAX_KEY_SIZE

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

hash_maps = {
    hashlib.sha224().name: hashlib.sha224,
    hashlib.sha256().name: hashlib.sha256,
    hashlib.sha384().name: hashlib.sha384,
    hashlib.sha512().name: hashlib.sha512,
    hashlib.sha3_224().name: hashlib.sha3_224,
    hashlib.sha3_256().name: hashlib.sha3_256,
    hashlib.sha3_384().name: hashlib.sha3_384,
    hashlib.sha3_512().name: hashlib.sha3_512,
}
if EASY_GMSSL_AVAILABLE:
    hash_maps["sm3"] = "sm3"


@click.command(name="hmac", short_help="HMAC message authentication code")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input: string, base64, or file path",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    type=click.Choice(list(hash_maps.keys())),
    default=hashlib.sha256().name,
    show_default=True,
    help="Hash algorithm: sm3, sha256, sha384, sha512, etc.",
)
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_HMAC_KEY,
    help="Key 32 bytes, CipherHUB compatible",
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "-r",
    "--random-key",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key (32 bytes)",
    multiple=False,
)
@command_perf.timing_decorator
def hmac_command(
    input_data: click.STRING,
    is_base64_encoded: click.BOOL,
    is_a_file: click.BOOL,
    random_key: click.BOOL,
    key: click.STRING,
    hash_alg: click.STRING,
):
    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "HMAC")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    # Determine key content
    if random_key:
        key = random_str.generate_random_str(32)

    key_bytes = key.encode("utf-8")
    if hash_alg == "sm3":
        if not EASY_GMSSL_AVAILABLE:
            hints.hint_missing_gmssl("SM3 HMAC")
            return
        if (
            len(key_bytes) < SM3_HMAC_MIN_KEY_SIZE
            or len(key_bytes) > SM3_HMAC_MAX_KEY_SIZE
        ):
            error(
                "SM3 HMAC key length must be {}-{} bytes".format(
                    SM3_HMAC_MIN_KEY_SIZE, SM3_HMAC_MAX_KEY_SIZE
                )
            )
            return
        h_sm3 = EasySM3Hmac(key=key_bytes)

    if not is_a_file:
        input_raw_bytes = b""
        if not is_base64_encoded:
            try:
                input_raw_bytes = input_data.encode("utf-8")
            except UnicodeEncodeError:
                error("input contains invalid UTF-8 characters")
                return
        elif is_base64_encoded:
            try:
                input_raw_bytes = common.decode_b64_data(input_data)
            except BaseException as e:
                error("invalid b64 encoded data: {}".format(e))
                hints.hint_invalid_b64("HMAC")
                return
        if hash_alg == "sm3":
            h_sm3.UpdateData(input_raw_bytes)
            ret_bytes, _, _ = h_sm3.GetHmac()
            ret = ret_bytes.hex()
        else:
            h = hmac.new(key=key_bytes, digestmod=hash_maps[hash_alg])
            h.update(input_raw_bytes)
            ret = h.hexdigest()
        result_table(
            {
                "hash algorithm": hash_alg,
                "input type": "base64" if is_base64_encoded else "utf-8 string",
                "input size": "{} bytes".format(len(input_raw_bytes)),
                "key size": "{} bytes".format(len(key_bytes)),
                "key": key,
                "digest size": "{} bytes".format(len(ret) // 2),
                "output format": "hex",
            },
            title="HMAC",
        )
        plain_copyable_block("hmac", ret)
    else:
        try:
            with common.read_from_file(input_data) as input_file:
                data_len = 0
                if hash_alg == "sm3":
                    while True:
                        data = input_file.read_n_bytes(4096)
                        data_len += len(data)
                        if len(data) > 0:
                            h_sm3.UpdateData(data)
                        else:
                            ret_bytes, _, _ = h_sm3.GetHmac()
                            ret = ret_bytes.hex()
                            result_table(
                                {
                                    "hash algorithm": hash_alg,
                                    "input type": "file",
                                    "file size": "{} bytes".format(data_len),
                                    "key size": "{} bytes".format(len(key_bytes)),
                                    "key": key,
                                    "digest size": "{} bytes".format(len(ret) // 2),
                                    "output format": "hex",
                                },
                                title="HMAC (File)",
                            )
                            plain_copyable_block("hmac", ret)
                            return
                else:
                    h = hmac.new(key=key_bytes, digestmod=hash_maps[hash_alg])
                    while True:
                        data = input_file.read_n_bytes(4096)
                        data_len += len(data)
                        if len(data) > 0:
                            h.update(data)
                        else:
                            ret = h.hexdigest()
                            result_table(
                                {
                                    "hash algorithm": hash_alg,
                                    "input type": "file",
                                    "file size": "{} bytes".format(data_len),
                                    "key size": "{} bytes".format(len(key_bytes)),
                                    "key": key,
                                    "digest size": "{} bytes".format(len(ret) // 2),
                                    "output format": "hex",
                                },
                                title="HMAC (File)",
                            )
                            plain_copyable_block("hmac", ret)
                            return
        except OSError:
            error("file {} may not exist or may not be readable".format(input_data))
            return


if __name__ == "__main__":
    hmac_command()
