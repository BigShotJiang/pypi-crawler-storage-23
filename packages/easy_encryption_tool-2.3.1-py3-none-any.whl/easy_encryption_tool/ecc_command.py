#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-03 23:05:39
import base64

import click
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, utils as asym_utils, x25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import command_perf
from easy_encryption_tool import common
from easy_encryption_tool import shell_completion
from easy_encryption_tool.rich_ui import error, plain_copyable_block, result_table, success

# SECP curves for ECDSA sign/verify and ECDH key exchange
ecc_map = {
    ec.SECP256R1().name: ec.SECP256R1,
    ec.SECP384R1().name: ec.SECP384R1,
    ec.SECP521R1().name: ec.SECP521R1,
    ec.SECP256K1().name: ec.SECP256K1,
}

# Ed25519: sign/verify only (no key exchange)
# X25519: key exchange only (no signing)
CURVE_ED25519 = "ed25519"
CURVE_X25519 = "x25519"
CURVES_SIGN = list(ecc_map.keys()) + [CURVE_ED25519]
CURVES_KEX = list(ecc_map.keys()) + [CURVE_X25519]
CURVES_ALL = list(ecc_map.keys()) + [CURVE_ED25519, CURVE_X25519]

ecc_hash_map = {
    hashes.SHA1().name: hashes.SHA1,
    hashes.SHA224().name: hashes.SHA224,
    hashes.SHA256().name: hashes.SHA256,
    hashes.SHA384().name: hashes.SHA384,
    hashes.SHA512().name: hashes.SHA512,
    hashes.SHA3_224().name: hashes.SHA3_224,
    hashes.SHA3_256().name: hashes.SHA3_256,
    hashes.SHA3_384().name: hashes.SHA3_384,
    hashes.SHA3_512().name: hashes.SHA3_512,
}

ecc_digest_size_map = {k: v().digest_size for k, v in ecc_hash_map.items()}

# Hash for ECC key exchange (CipherHUB supports SHA1-SHA512, no SHA3)
ecc_kex_hash_map = {
    hashes.SHA1().name: hashes.SHA1,
    hashes.SHA224().name: hashes.SHA224,
    hashes.SHA256().name: hashes.SHA256,
    hashes.SHA384().name: hashes.SHA384,
    hashes.SHA512().name: hashes.SHA512,
}


def _is_ec_private_key(key):
    """Check if key is EC (SECP) private key"""
    return isinstance(key, ec.EllipticCurvePrivateKey)


def _is_ed25519_private_key(key):
    """Check if key is Ed25519 private key (sign/verify only)"""
    return isinstance(key, ed25519.Ed25519PrivateKey)


def _is_x25519_private_key(key):
    """Check if key is X25519 private key (key exchange only)"""
    return isinstance(key, x25519.X25519PrivateKey)


def _is_ec_public_key(key):
    """Check if key is EC (SECP) public key"""
    return isinstance(key, ec.EllipticCurvePublicKey)


def _is_ed25519_public_key(key):
    """Check if key is Ed25519 public key"""
    return isinstance(key, ed25519.Ed25519PublicKey)


def _is_x25519_public_key(key):
    """Check if key is X25519 public key"""
    return isinstance(key, x25519.X25519PublicKey)


def _get_curve_name_from_private_key(pri_key):
    """Get curve name for display; works for EC, Ed25519, X25519"""
    if _is_ec_private_key(pri_key):
        return pri_key.curve.name
    if _is_ed25519_private_key(pri_key):
        return CURVE_ED25519
    if _is_x25519_private_key(pri_key):
        return CURVE_X25519
    return "unknown"


def _get_curve_name_from_public_key(pub_key):
    """Get curve name for display; works for EC, Ed25519, X25519"""
    if _is_ec_public_key(pub_key):
        return pub_key.curve.name
    if _is_ed25519_public_key(pub_key):
        return CURVE_ED25519
    if _is_x25519_public_key(pub_key):
        return CURVE_X25519
    return "unknown"


def _is_same_ec_key_pair(priv_key, pub_key):
    """
    Check if EC private key and public key form the same key pair.
    Uses sign/verify: if sign(priv) verifies with pub, they are the same pair.
    CipherHUB-aligned logic.
    """
    if not _is_ec_private_key(priv_key) or not _is_ec_public_key(pub_key):
        return False
    try:
        test_msg = b"ecc_ecdh_same_pair_check"
        sig = priv_key.sign(test_msg, ec.ECDSA(hashes.SHA256()))
        pub_key.verify(sig, test_msg, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False


def _is_same_x25519_key_pair(priv_key, pub_key):
    """
    Check if X25519 private key and public key form the same key pair.
    Compares raw public bytes. CipherHUB-aligned logic.
    """
    if not _is_x25519_private_key(priv_key) or not _is_x25519_public_key(pub_key):
        return False
    ours = priv_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    theirs = pub_key.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    return ours == theirs


@click.group(name="ecc", short_help="ECC sign/verify and key exchange")
def ecc_group():
    pass


@click.command(name="generate")
@click.option(
    "-c",
    "--curve",
    required=False,
    type=click.Choice(CURVES_ALL),
    default=ec.SECP256K1().name,
    show_default=True,
    help="Curve type: secp* for ECDSA/ECDH; ed25519 for sign only; x25519 for key exchange only",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-f",
    "--file-name",
    required=False,
    type=click.STRING,
    default="demo",
    show_default=True,
    help="Output file name prefix for key pair",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    help="Private key password",
)
@click.option(
    "-r",
    "--random-password",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Generate random private key password (32 bytes); omit -p when used",
)
@command_perf.timing_decorator
def generate(
    curve: click.STRING,
    encoding: click.STRING,
    file_name: click.STRING,
    password: click.STRING,
    random_password: click.BOOL,
):
    password, enc = common.private_key_password(random_password, password)
    if curve == CURVE_ED25519:
        ecc_private_key = ed25519.Ed25519PrivateKey.generate()
        ecc_public_key = ecc_private_key.public_key()
    elif curve == CURVE_X25519:
        ecc_private_key = x25519.X25519PrivateKey.generate()
        ecc_public_key = ecc_private_key.public_key()
    else:
        ecc_private_key = ec.generate_private_key(ecc_map[curve](), default_backend())
        ecc_public_key = ecc_private_key.public_key()
    private_key_encoding = ecc_private_key.private_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=enc,
    )
    public_key_encoding = ecc_public_key.public_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    if not common.write_asymmetric_key(
        file_name_prefix=file_name,
        asymmetric_type="ecc",
        encoding_type=encoding,
        is_private_encrypted=(password is not None and len(password) > 0),
        private_password=password,
        public_data=public_key_encoding,
        private_data=private_key_encoding,
    ):
        error("ecc generated failed")
    return


@click.command(name="ecdh")
@click.option(
    "-a",
    "--alice-pub-key",
    required=False,
    type=click.STRING,
    default=None,
    help="[Optional] Your public key file path for consistency check. Not required for ECDH derivation.",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-k",
    "--alice-pri-key",
    required=True,
    type=click.STRING,
    help="Your private key file path, e.g. ./alice_private.pem",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Your private key password (required if key was created with password)",
)
@click.option(
    "-b",
    "--bob-pub-key",
    required=True,
    type=click.STRING,
    help="Peer's public key file path, e.g. ./bob_public.pem",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-l",
    "--length",
    required=False,
    type=click.IntRange(16, 64),
    default=cipherhub_defaults.DEFAULT_ECC_DERIVED_KEY_LENGTH,
    show_default=True,
    help="Derived key length, CipherHUB compatible default",
)
@click.option(
    "-H",
    "--hash-alg",
    required=False,
    type=click.Choice(list(ecc_kex_hash_map.keys())),
    default=cipherhub_defaults.DEFAULT_ECC_HASH,
    show_default=True,
    help="HKDF hash algorithm, CipherHUB compatible",
)
@click.option(
    "-s",
    "--salt",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ECC_SALT,
    show_default=True,
    help="HKDF salt, CipherHUB default compatible",
)
@click.option(
    "-c",
    "--context",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ECC_ADDITIONAL_INFO,
    show_default=True,
    help="HKDF additional_info, CipherHUB default compatible",
)
@command_perf.timing_decorator
def key_exchange(
    alice_pub_key: click.STRING,
    alice_pri_key: click.STRING,
    password: click.STRING,
    bob_pub_key: click.STRING,
    encoding: click.STRING,
    length: click.INT,
    hash_alg: click.STRING,
    salt: click.STRING,
    context: click.STRING,
):
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None

    alice_pri = common.load_private_key(
        encoding=encoding, file_path=alice_pri_key, password_bytes=password_bytes
    )
    if alice_pri is None:
        return
    bob_pub = common.load_public_key(encoding=encoding, file_path=bob_pub_key)
    if bob_pub is None:
        return

    # [Optional] When alice public key provided, verify it matches alice private key
    if alice_pub_key:
        alice_pub = common.load_public_key(encoding=encoding, file_path=alice_pub_key)
        if alice_pub is None:
            return
        if _is_ec_private_key(alice_pri) and _is_ec_public_key(alice_pub):
            if not _is_same_ec_key_pair(alice_pri, alice_pub):
                error(
                    "ECC ECDH: Your public key (-a) does not match your private key (-k). "
                    "They must be from the same key pair."
                )
                raise click.Abort()
        elif _is_x25519_private_key(alice_pri) and _is_x25519_public_key(alice_pub):
            if not _is_same_x25519_key_pair(alice_pri, alice_pub):
                error(
                    "ECC ECDH: Your public key (-a) does not match your private key (-k). "
                    "They must be from the same key pair."
                )
                raise click.Abort()
        else:
            error(
                "ECC ECDH: Your public key (-a) and private key (-k) must be same curve type "
                "(both secp* or both x25519)."
            )
            raise click.Abort()

    # Ed25519 is for signing only, NOT key exchange
    if _is_ed25519_private_key(alice_pri):
        error(
            "ed25519 keys are for signing/verification only, not key exchange. "
            "Use x25519 or secp* curves for ECDH."
        )
        raise click.Abort()
    if _is_ed25519_public_key(bob_pub):
        error(
            "Peer key is ed25519 (signing only). Use x25519 or secp* public key for ECDH."
        )
        raise click.Abort()

    # Key type must match: both secp* or both x25519
    if _is_ec_private_key(alice_pri) != _is_ec_public_key(bob_pub):
        error(
            "Key type mismatch: alice private key and bob public key must be same curve type "
            "(both secp* or both x25519)."
        )
        raise click.Abort()
    if _is_x25519_private_key(alice_pri) != _is_x25519_public_key(bob_pub):
        error(
            "Key type mismatch: alice private key and bob public key must be same curve type "
            "(both secp* or both x25519)."
        )
        raise click.Abort()

    # SECP curves: exact curve name must match (e.g. secp256r1 vs secp384r1 cannot negotiate)
    if _is_ec_private_key(alice_pri) and _is_ec_public_key(bob_pub):
        if alice_pri.curve.name != bob_pub.curve.name:
            error(
                "Curve mismatch: alice private key curve [{}] != peer public key curve [{}]. "
                "ECDH requires both keys on the same curve (e.g. both secp256r1 or both secp384r1).".format(
                    alice_pri.curve.name, bob_pub.curve.name
                )
            )
            raise click.Abort()

    # Same key pair check: alice private + bob public must NOT be the same key pair
    if _is_x25519_private_key(alice_pri):
        if _is_same_x25519_key_pair(alice_pri, bob_pub):
            error(
                "Same key pair detected: your private key and peer's public key belong to the same key pair. "
                "ECDH requires two different parties. Use your private key with the other party's public key."
            )
            raise click.Abort()
    else:
        if _is_same_ec_key_pair(alice_pri, bob_pub):
            error(
                "Same key pair detected: your private key and peer's public key belong to the same key pair. "
                "ECDH requires two different parties. Use your private key with the other party's public key."
            )
            raise click.Abort()

    salt_bytes = salt.encode("utf-8") if salt else None
    context_bytes = context.encode("utf-8") if context else None

    if _is_x25519_private_key(alice_pri):
        shared_secret_alice = alice_pri.exchange(bob_pub)
    else:
        shared_secret_alice = alice_pri.exchange(ec.ECDH(), bob_pub)

    derived_key = HKDF(
        algorithm=ecc_kex_hash_map[hash_alg](),
        length=length,
        salt=salt_bytes,
        info=context_bytes,
        backend=default_backend(),
    ).derive(shared_secret_alice)
    curve_name = _get_curve_name_from_private_key(alice_pri)
    derived_b64 = base64.b64encode(derived_key).decode("utf-8")
    result_table(
        {
            "algorithm": "ECDH",
            "curve name": curve_name,
            "hash algorithm": hash_alg,
            "derived key length": "{} bytes".format(len(derived_key)),
            "salt": salt if salt else "(none)",
            "context": context if context else "(none)",
            "output format": "base64",
        },
        title="ECC Key Exchange",
    )
    plain_copyable_block("derived key (base64)", derived_b64)


@click.command(name="sign")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="Private key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default=cipherhub_defaults.DEFAULT_ECC_HASH,
    show_default=True,
    type=click.Choice(list(ecc_hash_map.keys())),
    help="Signature hash algorithm, CipherHUB compatible default",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Private key password (required if key was created with password)",
)
@click.option(
    "-i", "--input-data", required=True, type=click.STRING, help="Data to sign"
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is pre-computed digest (not raw); must match -a hash-alg length",
)
@command_perf.timing_decorator
def ecc_sign(
    private_key: click.STRING,
    input_data: click.STRING,
    hash_alg: click.STRING,
    password: click.STRING,
    encoding: click.STRING,
    is_base64_encoded: click.BOOL,
    input_is_digest: click.BOOL,
):
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None

    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            error(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    pri_key = common.load_private_key(
        encoding=encoding, file_path=private_key, password_bytes=password_bytes
    )
    if pri_key is None:
        return

    # X25519 is for key exchange only, NOT signing
    if _is_x25519_private_key(pri_key):
        error(
            "x25519 keys are for key exchange only, not signing. "
            "Use ed25519 or secp* curves for sign/verify."
        )
        return

    # Ed25519: sign raw message directly (ignores -a and -d)
    if _is_ed25519_private_key(pri_key):
        if input_is_digest:
            error(
                "Ed25519 (EdDSA) does not support -d/--input-is-digest: EdDSA hashes the message internally. "
                "Use raw message instead and omit -d."
            )
            return
        try:
            signature = pri_key.sign(input_raw_bytes)
            sig_b64 = base64.b64encode(signature).decode("utf-8")
            result_table(
                {
                    "algorithm": "Ed25519",
                    "curve name": CURVE_ED25519,
                    "input type": "base64" if is_base64_encoded else "utf-8 string",
                    "input size": "{} bytes".format(len(input_raw_bytes)),
                    "signature size": "{} bytes".format(len(signature)),
                    "output format": "base64",
                },
                title="ECC Sign",
            )
            plain_copyable_block("signature (base64)", sig_b64)
        except BaseException as e:
            error("sign failed: {} | private key: {} | mode: Ed25519".format(e, private_key))
        return

    # SECP curves: ECDSA with hash
    digest_size = ecc_digest_size_map[hash_alg]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            error(
                "input-is-digest mode requires {} bytes ({} digest length), got: {} bytes".format(
                    digest_size, hash_alg, len(input_raw_bytes)
                )
            )
            return

    try:
        hash_alg_obj = ecc_hash_map[hash_alg]()
        sign_algorithm = (
            ec.ECDSA(asym_utils.Prehashed(hash_alg_obj))
            if input_is_digest
            else ec.ECDSA(hash_alg_obj)
        )
        signature = pri_key.sign(input_raw_bytes, sign_algorithm)
        sig_b64 = base64.b64encode(signature).decode("utf-8")
        result_table(
            {
                "algorithm": "ECDSA",
                "curve name": pri_key.curve.name,
                "key size": "{} bits".format(pri_key.key_size),
                "hash algorithm": hash_alg,
                "input type": "digest" if input_is_digest else ("base64" if is_base64_encoded else "utf-8 string"),
                "input size": "{} bytes".format(len(input_raw_bytes)),
                "signature size": "{} bytes".format(len(signature)),
                "output format": "base64",
            },
            title="ECC Sign",
        )
        plain_copyable_block("signature (base64)", sig_b64)
    except BaseException as e:
        error(
            "sign failed: {} | private key: {} | mode: {}".format(
                e, private_key, ec.ECDSA.__name__
            )
        )
        return


@click.command(name="verify")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="Public key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default=cipherhub_defaults.DEFAULT_ECC_HASH,
    show_default=True,
    type=click.Choice(list(ecc_hash_map.keys())),
    help="Signature hash algorithm, CipherHUB compatible default",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Data to verify (raw or digest, use -d for digest)",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is pre-computed digest (not raw); must match -a hash-alg length",
)
@click.option(
    "-s",
    "--signature",
    required=True,
    type=click.STRING,
    help="Base64-encoded signature",
)
@command_perf.timing_decorator
def ecc_verify(
    public_key: click.STRING,
    input_data: click.STRING,
    is_base64_encoded: click.BOOL,
    signature: click.STRING,
    hash_alg: click.STRING,
    encoding: click.STRING,
    input_is_digest: click.BOOL,
):
    if not signature or len(signature.strip()) <= 0:
        error("signature cannot be empty")
        return
    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            error(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    try:
        signature_raw_bytes = common.decode_b64_data(signature)
    except BaseException as e:
        error("invalid b64 encoded signature, decoded failed:{}".format(e))
        return
    if len(signature_raw_bytes) <= 0:
        error("signature is empty after decode")
        return

    pub_key = common.load_public_key(encoding=encoding, file_path=public_key)
    if pub_key is None:
        return

    # X25519 is for key exchange only, NOT verification
    if _is_x25519_public_key(pub_key):
        error(
            "x25519 keys are for key exchange only, not verify. "
            "Use ed25519 or secp* curves for sign/verify."
        )
        return

    # Ed25519: verify raw message directly (ignores -a and -d)
    if _is_ed25519_public_key(pub_key):
        if input_is_digest:
            error(
                "Ed25519 (EdDSA) does not support -d/--input-is-digest: EdDSA hashes the message internally. "
                "Use raw message instead and omit -d."
            )
            return
        try:
            pub_key.verify(signature_raw_bytes, input_raw_bytes)
            success("verify success | curve: {} | mode: Ed25519".format(CURVE_ED25519))
        except InvalidSignature:
            error("InvalidSignature! | curve: {} | mode: Ed25519".format(CURVE_ED25519))
        return

    # SECP curves: ECDSA with hash
    digest_size = ecc_digest_size_map[hash_alg]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            error(
                "input-is-digest mode requires {} bytes ({} digest length), got: {} bytes".format(
                    digest_size, hash_alg, len(input_raw_bytes)
                )
            )
            return

    try:
        hash_alg_obj = ecc_hash_map[hash_alg]()
        verify_algorithm = (
            ec.ECDSA(asym_utils.Prehashed(hash_alg_obj))
            if input_is_digest
            else ec.ECDSA(hash_alg_obj)
        )
        pub_key.verify(signature_raw_bytes, input_raw_bytes, verify_algorithm)
    except InvalidSignature:
        error(
            "InvalidSignature!\nkey size:{}\nmode:{}".format(
                pub_key.key_size, ec.ECDSA.__name__
            )
        )
    else:
        success(
            "verify success | curve: {} | key size: {} | mode: {}".format(
                pub_key.curve.name, pub_key.key_size, ec.ECDSA.__name__
            )
        )


if __name__ == "__main__":
    ecc_group.add_command(generate)
    ecc_group.add_command(key_exchange)
    ecc_group.add_command(ecc_sign)
    ecc_group.add_command(ecc_verify)
    ecc_group()
