#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-01 09:04:43
"""
Cryptographically secure random: uses secrets module (CSPRNG).
"""
import secrets
import string
import sys

import click

from easy_encryption_tool import command_perf, common, shell_completion
from easy_encryption_tool.rich_ui import console, error, success

special_characters = "&=!@#$%^*()_+`"
characters: str = (
    string.ascii_lowercase + string.ascii_uppercase + string.digits + special_characters
)


def generate_random_str(length: int) -> str:
    """Generate cryptographically secure random string via secrets"""
    return "".join(secrets.choice(characters) for _ in range(length))


def generate_random_bytes(length: int) -> bytes:
    """Generate cryptographically secure random bytes for key/IV padding etc."""
    return secrets.token_bytes(length)


@click.command(name="random-str", short_help="Random string generator")
@click.option(
    "-l",
    "--length",
    required=False,
    type=click.IntRange(min=1, max=sys.maxsize),
    default=32,
    show_default=True,
    help="Min 1 byte, max length up to system max int",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; file must be writable",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file",
)
@command_perf.timing_decorator
def get_random_str(length: int, output_file: click.STRING, no_force: bool = False):
    write_to_output = None
    if output_file is not None and len(output_file) > 0:
        try:
            write_to_output = common.write_to_file(output_file, force=not no_force)
        except OSError as e:
            error("try write to {} failed".format(output_file))
            return

    # Generate 32 bytes per block to avoid high memory for long strings
    block_size = 32
    for i in range(0, length // block_size + 1):
        if length <= 0:
            break
        chunk_len = min(block_size, length)
        tmp = generate_random_str(chunk_len)
        if write_to_output is not None:
            if not write_to_output.write_bytes(tmp.encode("utf-8")):
                return
        else:
            console.print(tmp, end="", markup=False)
        length -= chunk_len
    if write_to_output is not None:
        success("write to {} success".format(output_file))
    else:
        console.print()


if __name__ == "__main__":
    get_random_str()
