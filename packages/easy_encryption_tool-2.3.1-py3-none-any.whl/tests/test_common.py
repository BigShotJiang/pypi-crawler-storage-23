#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
公共逻辑单元测试：common 模块。
"""
from __future__ import annotations

import base64
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from easy_encryption_tool import common


class TestDecodeB64Data:
    """decode_b64_data 单元测试"""

    def test_empty_input_returns_empty_bytes(self):
        assert common.decode_b64_data("") == b""

    def test_valid_base64_decode(self):
        data = b"hello"
        encoded = base64.b64encode(data).decode("utf-8")
        assert common.decode_b64_data(encoded) == data

    def test_invalid_base64_raises_value_error(self):
        with pytest.raises(ValueError, match="base64 decode failed"):
            common.decode_b64_data("!!!invalid!!!")

    def test_base64_with_newline_and_space(self):
        """Python < 3.11 允许 \\n \\r 空格；>= 3.11 使用 validate=True 会拒绝"""
        import sys
        data = base64.b64encode(b"test").decode("utf-8")
        if sys.version_info >= (3, 11):
            with pytest.raises(ValueError, match="base64 decode failed"):
                common.decode_b64_data(data + "\n")
        else:
            assert common.decode_b64_data(data + "\n") == b"test"


class TestCheckIsFileReadable:
    """check_is_file_readable 单元测试"""

    def test_nonexistent_file_returns_false(self):
        assert common.check_is_file_readable("/nonexistent/path/file.txt") is False

    def test_existing_readable_file_returns_true(self, tmp_file):
        path = tmp_file(b"content")
        assert common.check_is_file_readable(path) is True

    def test_directory_returns_false(self, tmp_dir):
        assert common.check_is_file_readable(tmp_dir) is False


class TestCheckIsFileWritable:
    """check_is_file_writable 单元测试"""

    def test_new_file_creatable_returns_true(self, tmp_dir):
        path = os.path.join(tmp_dir, "new_file.txt")
        assert common.check_is_file_writable(path, force=True) is True
        assert os.path.exists(path)

    def test_existing_writable_file_force_true_returns_true(self, tmp_file):
        path = tmp_file(b"old")
        assert common.check_is_file_writable(path, force=True) is True

    def test_existing_file_force_false_returns_false(self, tmp_file):
        path = tmp_file(b"old")
        assert common.check_is_file_writable(path, force=False) is False

    def test_existing_directory_returns_false(self, tmp_dir):
        assert common.check_is_file_writable(tmp_dir, force=True) is False

    def test_unwritable_parent_returns_false(self):
        assert common.check_is_file_writable("/nonexistent/parent/out.txt", force=True) is False


class TestProcessKeyIv:
    """process_key_iv 单元测试"""

    @patch("easy_encryption_tool.common.random_str")
    def test_random_mode_generates_key_iv(self, mock_random):
        mock_random.generate_random_str.side_effect = lambda n: "x" * n
        key, iv = common.process_key_iv(
            is_random=True, key="", iv="", key_len=32, iv_len=16
        )
        assert len(key) == 32
        assert len(iv) == 16
        assert mock_random.generate_random_str.call_count >= 2

    def test_key_truncated_when_too_long(self):
        key, iv = common.process_key_iv(
            is_random=False,
            key="a" * 40,
            iv="b" * 16,
            key_len=32,
            iv_len=16,
        )
        assert len(key) == 32
        assert key == "a" * 32

    @patch("easy_encryption_tool.common.random_str")
    def test_key_padded_when_too_short(self, mock_random):
        mock_random.generate_random_str.side_effect = lambda n: "p" * n
        key, iv = common.process_key_iv(
            is_random=False,
            key="a" * 10,
            iv="b" * 16,
            key_len=32,
            iv_len=16,
        )
        assert len(key) == 32
        assert key.startswith("a")
        assert key.endswith("p" * 22)

    def test_gcm_mode_uses_nonce_len(self):
        key, iv = common.process_key_iv(
            is_random=False,
            key="k" * 32,
            iv="v" * 12,
            key_len=32,
            iv_len=16,
            nonce_len=12,
            mode="gcm",
        )
        assert len(iv) == 12

    @patch("easy_encryption_tool.common.random_str")
    def test_iv_truncated_when_too_long(self, mock_random):
        key, iv = common.process_key_iv(
            is_random=False,
            key="k" * 32,
            iv="v" * 24,
            key_len=32,
            iv_len=16,
        )
        assert len(iv) == 16
        assert iv == "v" * 16

    @patch("easy_encryption_tool.common.random_str")
    def test_iv_padded_when_too_short(self, mock_random):
        mock_random.generate_random_str.side_effect = lambda n: "p" * n
        key, iv = common.process_key_iv(
            is_random=False,
            key="k" * 32,
            iv="v" * 8,
            key_len=32,
            iv_len=16,
        )
        assert len(iv) == 16
        assert iv.startswith("v")
        assert iv.endswith("p" * 8)


class TestValidateGcmCipherFormat:
    """validate_gcm_cipher_format 单元测试"""

    def test_none_returns_false(self):
        assert common.validate_gcm_cipher_format(None, 16) is False

    def test_too_short_returns_false(self):
        assert common.validate_gcm_cipher_format(b"short", 16) is False

    def test_valid_returns_true(self):
        data = b"x" * 32  # cipher + 16 byte tag
        assert common.validate_gcm_cipher_format(data, 16) is True


class TestCheckB64Data:
    """check_b64_data 单元测试"""

    def test_empty_returns_false_empty_bytes(self):
        ok, data = common.check_b64_data("")
        assert ok is False
        assert data == b""

    def test_valid_base64_returns_true_and_bytes(self):
        encoded = base64.b64encode(b"hello").decode("utf-8")
        ok, data = common.check_b64_data(encoded)
        assert ok is True
        assert data == b"hello"

    def test_invalid_base64_returns_false(self):
        ok, data = common.check_b64_data("!!!")
        assert ok is False
        assert data == b""

    def test_base64_decode_empty_result_returns_false(self):
        # "AA==" decodes to single null byte; "A" is invalid padding
        ok, data = common.check_b64_data("")
        assert ok is False
        assert data == b""


class TestReadFromFile:
    """read_from_file 上下文管理器单元测试"""

    def test_read_n_bytes(self, tmp_file):
        content = b"hello world"
        path = tmp_file(content)
        with common.read_from_file(path) as f:
            assert f.read_n_bytes(5) == b"hello"
            assert f.read_n_bytes(100) == b" world"

    def test_nonexistent_raises_oserror(self):
        with pytest.raises(OSError, match="read from file"):
            with common.read_from_file("/nonexistent/file"):
                pass


class TestWriteToFile:
    """write_to_file 上下文管理器单元测试"""

    def test_write_bytes_and_atomic_rename(self, tmp_dir):
        path = os.path.join(tmp_dir, "out.txt")
        with common.write_to_file(path, force=True) as f:
            f.write_bytes(b"content")
        assert Path(path).read_bytes() == b"content"

    def test_unwritable_parent_raises_oserror(self):
        with pytest.raises(OSError, match="write to file"):
            with common.write_to_file("/nonexistent/parent/out.txt", force=True):
                pass


class TestBytesToStr:
    """bytes_to_str 单元测试"""

    def test_none_returns_false_empty(self):
        ok, s = common.bytes_to_str(None)
        assert ok is False
        assert s == ""

    def test_valid_utf8_returns_true_and_str(self):
        ok, s = common.bytes_to_str(b"hello")
        assert ok is True
        assert s == "hello"

    def test_invalid_utf8_returns_base64(self):
        ok, s = common.bytes_to_str(b"\xff\xfe")
        assert ok is False
        assert s == base64.b64encode(b"\xff\xfe").decode("utf-8")


class TestPrivateKeyPassword:
    """private_key_password 单元测试"""

    def test_no_password_returns_no_encryption(self):
        pwd, enc = common.private_key_password(is_random=False, password=None)
        assert pwd is None
        from cryptography.hazmat.primitives.serialization import NoEncryption
        assert isinstance(enc, NoEncryption)

    @patch("easy_encryption_tool.common.random_str")
    def test_random_generates_password(self, mock_random):
        mock_random.generate_random_str.return_value = "r" * 32
        pwd, enc = common.private_key_password(is_random=True, password=None)
        assert pwd == "r" * 32

    def test_with_password_returns_encryption(self):
        pwd, enc = common.private_key_password(
            is_random=False, password="mypassword"
        )
        assert pwd == "mypassword"
        from cryptography.hazmat.primitives.serialization import BestAvailableEncryption
        assert isinstance(enc, BestAvailableEncryption)


class TestLoadPublicKey:
    """load_public_key 单元测试"""

    def test_load_pem_public_key(self, tmp_file):
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        key = rsa.generate_private_key(65537, 2048)
        pub = key.public_key()
        pem = pub.public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        path = tmp_file(pem)
        loaded = common.load_public_key("pem", path)
        assert loaded is not None

    def test_nonexistent_returns_none(self):
        with patch("easy_encryption_tool.common.error"):
            result = common.load_public_key("pem", "/nonexistent/key.pem")
        assert result is None


class TestLoadPrivateKey:
    """load_private_key 单元测试"""

    def test_load_pem_private_key(self, tmp_file):
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        key = rsa.generate_private_key(65537, 2048)
        pem = key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
        path = tmp_file(pem)
        loaded = common.load_private_key("pem", path, None)
        assert loaded is not None

    def test_nonexistent_returns_none(self):
        with patch("easy_encryption_tool.common.error"):
            result = common.load_private_key(
                "pem", "/nonexistent/key.pem", None
            )
        assert result is None


class TestWriteAsymmetricKey:
    """write_asymmetric_key 单元测试"""

    def test_empty_prefix_returns_false(self):
        assert common.write_asymmetric_key(
            file_name_prefix="",
            asymmetric_type="rsa",
            encoding_type="pem",
            is_private_encrypted=False,
            private_password=None,
            public_data=b"pub",
            private_data=b"pri",
        ) is False

    def test_success_writes_files(self, tmp_dir):
        prefix = os.path.join(tmp_dir, "demo")
        with patch("easy_encryption_tool.common.success"), \
             patch("easy_encryption_tool.common.info"):
            ok = common.write_asymmetric_key(
                file_name_prefix=prefix,
                asymmetric_type="rsa",
                encoding_type="pem",
                is_private_encrypted=False,
                private_password=None,
                public_data=b"-----BEGIN PUBLIC KEY-----\ntest\n-----END PUBLIC KEY-----",
                private_data=b"-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----",
            )
        assert ok is True
        pub_path = f"{prefix}_rsa_public.pem"
        pri_path = f"{prefix}_rsa_private.pem"
        assert os.path.exists(pub_path)
        assert os.path.exists(pri_path)
