#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
main 模块单元测试：CLI 入口、欢迎面板、命令纠错等。
"""
from __future__ import annotations

import subprocess
import sys

import pytest
from click.testing import CliRunner

from .conftest import strip_ansi
from easy_encryption_tool.main import encryption_tool


runner = CliRunner()


class TestEncryptionToolCLI:
    """主 CLI 入口测试"""

    def test_invoke_without_command_shows_welcome(self):
        result = runner.invoke(encryption_tool, [])
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "easy_encryption_tool" in out
        assert "AES" in out or "Hash" in out

    def test_help_works(self):
        result = runner.invoke(encryption_tool, ["--help"])
        assert result.exit_code == 0
        assert "aes" in result.output.lower() or "hash" in result.output.lower()

    def test_hash_subcommand(self):
        result = runner.invoke(encryption_tool, ["hash", "-i", "test", "-a", "sha256"])
        assert result.exit_code == 0

    def test_version_subcommand(self):
        result = runner.invoke(encryption_tool, ["version"])
        assert result.exit_code == 0


class TestSmartGroup:
    """SmartGroup 命令纠错测试"""

    def test_unknown_command_suggests_similar(self):
        result = runner.invoke(encryption_tool, ["has"])  # 接近 hash
        assert result.exit_code != 0
        out = strip_ansi(result.output)
        assert "hash" in out.lower() or "Did you mean" in out.lower() or "no such" in out.lower()


class TestInstallCompletion:
    """install-completion 命令测试"""

    def test_install_completion_stdout(self):
        result = runner.invoke(
            encryption_tool,
            ["install-completion", "--shell", "bash"],
        )
        assert result.exit_code == 0
        assert "complete" in result.output.lower() or "COMP" in result.output

    def test_install_completion_to_file(self, tmp_path):
        out_path = tmp_path / "completion.sh"
        result = runner.invoke(
            encryption_tool,
            ["install-completion", "--shell", "bash", "--path", str(out_path)],
        )
        assert result.exit_code == 0
        assert out_path.exists()
        assert "source" in result.output or str(out_path) in result.output
