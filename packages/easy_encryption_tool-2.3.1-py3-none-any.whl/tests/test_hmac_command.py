#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
HMAC 命令单元测试。
"""
from __future__ import annotations

import hashlib
import hmac

import pytest
from click.testing import CliRunner

from .conftest import strip_ansi
from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import hmac_command


runner = CliRunner()


class TestHmacCommandSha256:
    """HMAC SHA256 测试"""

    def test_hmac_plaintext(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "hello",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha256",
            ],
        )
        assert result.exit_code == 0
        expected = hmac.new(
            cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8"),
            b"hello",
            hashlib.sha256,
        ).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out

    def test_hmac_base64_input(self):
        import base64
        data = b"data"
        b64 = base64.b64encode(data).decode("utf-8")
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", b64, "-e",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha256",
            ],
        )
        assert result.exit_code == 0
        expected = hmac.new(
            cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8"),
            data,
            hashlib.sha256,
        ).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out


class TestHmacCommandFileMode:
    """HMAC 文件模式"""

    def test_hmac_file_sha256(self, tmp_file):
        content = b"file content"
        path = tmp_file(content)
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", path, "-f",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha256",
            ],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "hmac" in out.lower()

    @pytest.mark.skipif(
        not getattr(hmac_command, "EASY_GMSSL_AVAILABLE", False),
        reason="easy_gmssl not installed",
    )
    def test_hmac_file_sm3(self, tmp_file):
        content = b"file for sm3 hmac"
        path = tmp_file(content)
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", path, "-f",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sm3",
            ],
        )
        assert result.exit_code == 0

    def test_hmac_nonexistent_file_fails(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "/nonexistent/file.txt", "-f",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha256",
            ],
        )
        assert result.exit_code != 0 or "exist" in strip_ansi(result.output).lower()


class TestHmacCommandMultipleAlgs:
    """多种 HMAC 算法"""

    def test_hmac_sha384(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "msg",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha384",
            ],
        )
        assert result.exit_code == 0

    def test_hmac_sha512(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "msg",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha512",
            ],
        )
        assert result.exit_code == 0

    def test_hmac_random_key(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            ["-i", "msg", "-r", "-a", "sha256"],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "hmac" in out.lower()


class TestHmacCommandSm3:
    """HMAC SM3 测试（需 easy_gmssl）"""

    @pytest.mark.skipif(
        not getattr(hmac_command, "EASY_GMSSL_AVAILABLE", False),
        reason="easy_gmssl not installed",
    )
    def test_hmac_sm3(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "hello",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sm3",
            ],
        )
        assert result.exit_code == 0


class TestHmacValidation:
    """HMAC 参数验证"""

    def test_b64_and_file_mutually_exclusive(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            ["-i", "x", "-e", "-f", "-a", "sha256"],
        )
        out = strip_ansi(result.output).lower()
        assert "mutually" in out and "exclusive" in out


class TestHmacAllAlgorithms:
    """HMAC 所有算法正确性验证"""

    def test_hmac_sha224(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "msg",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha224",
            ],
        )
        assert result.exit_code == 0
        expected = hmac.new(
            cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8"),
            b"msg",
            hashlib.sha224,
        ).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out

    def test_hmac_sha3_256(self):
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", "msg",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha3_256",
            ],
        )
        assert result.exit_code == 0
        expected = hmac.new(
            cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8"),
            b"msg",
            hashlib.sha3_256,
        ).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out


class TestHmacFileMode:
    """HMAC 文件模式"""

    def test_hmac_file(self, tmp_file):
        content = b"file content"
        path = tmp_file(content)
        result = runner.invoke(
            hmac_command.hmac_command,
            [
                "-i", path, "-f",
                "-k", cipherhub_defaults.DEFAULT_HMAC_KEY,
                "-a", "sha256",
            ],
        )
        assert result.exit_code == 0
        expected = hmac.new(
            cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8"),
            content,
            hashlib.sha256,
        ).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out
