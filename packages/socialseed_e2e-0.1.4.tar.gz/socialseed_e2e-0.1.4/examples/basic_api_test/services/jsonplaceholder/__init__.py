# This file marks the jsonplaceholder directory as a Python package
