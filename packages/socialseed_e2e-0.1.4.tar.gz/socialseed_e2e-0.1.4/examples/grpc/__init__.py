"""gRPC Examples Package.

This package contains examples for testing gRPC services using socialseed-e2e.
"""

__all__ = ["mock_server", "user_grpc_page"]
