"""Schema adaptation package."""

from .schema_adapter import SchemaAdapter

__all__ = ["SchemaAdapter"]
