"""Penetration testing package."""

from .penetration_tester import PenetrationTester

__all__ = ["PenetrationTester"]
