"""Secret detection package."""

from .secret_detector import SecretDetector

__all__ = ["SecretDetector"]
