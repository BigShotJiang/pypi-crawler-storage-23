"""Security reports package."""

from .security_reporter import SecurityReporter

__all__ = ["SecurityReporter"]
