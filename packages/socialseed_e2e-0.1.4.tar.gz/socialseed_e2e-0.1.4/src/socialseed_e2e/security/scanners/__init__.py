"""Security scanners package."""

from .owasp_scanner import OWASPScanner

__all__ = ["OWASPScanner"]
