#!/usr/bin/env python3
"""Entry point for python -m socialseed_e2e."""

from socialseed_e2e.cli import main

if __name__ == "__main__":
    main()
