"""SocialSeed E2E Dashboard module.

Local Web Interface for Manual Test Execution and Debugging.
"""

from socialseed_e2e.dashboard.server import DashboardServer

__all__ = ["DashboardServer"]
