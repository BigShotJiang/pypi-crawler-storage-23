"""Test fixtures package for socialseed-e2e.

This package contains fixtures and utilities for testing,
including the MockAPIServer for integration testing.
"""
