"""Tests package for socialseed-e2e.

This package contains all tests for the socialseed-e2e framework,
including unit tests, integration tests, and fixtures.
"""
