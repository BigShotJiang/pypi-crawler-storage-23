"""Sync layer — bridges IDE parsers and the central database.

Parsers extract raw data into Pydantic models. This module
writes those models into swaitch.db via SQLAlchemy.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from swaitch.db.models import ConversationRow, MessageRow, ToolCallRow
from swaitch.db.session import get_session
from swaitch.models import ChatMessage, Conversation, IDEType
from swaitch.parsers.base import BaseParser

logger = logging.getLogger(__name__)

# Maximum messages to commit in a single batch
_BATCH_SIZE = 50


def sync_source(parser: BaseParser) -> int:
    """Sync all conversations from a parser into the central database.

    Performs an upsert: new conversations are inserted, existing ones
    are updated if their data has changed.

    Args:
        parser: The IDE parser to sync from.

    Returns:
        Number of conversations synced.
    """
    source = parser.ide_type.value
    logger.info("Starting sync for %s", source)

    conversation_ids = parser.list_conversation_ids()
    synced = 0
    skipped = 0

    session = get_session()
    try:
        for conv_id in conversation_ids:
            try:
                # Fetch full conversation from the parser
                # (Parsing is done on demand instead of upfront for all summaries)
                try:
                    conversation = parser.get_conversation(conv_id)
                except Exception:
                    logger.debug("Skipping invalid conversation %s", conv_id)
                    continue

                if not conversation.messages:
                    logger.debug("Skipping empty conversation %s", conv_id)
                    # If it was in the DB before but is now empty, clean it up
                    session.query(ConversationRow).filter_by(
                        source=source, remote_id=conv_id
                    ).delete()
                    continue
                
                # Check if conversation already exists and is up-to-date
                existing = (
                    session.query(ConversationRow)
                    .filter_by(source=source, remote_id=conv_id)
                    .first()
                )

                if existing and existing.updated_at and conversation.updated_at:
                    existing_dt = existing.updated_at
                    if existing_dt.tzinfo is None:
                        existing_dt = existing_dt.replace(tzinfo=timezone.utc)
                    
                    conv_dt = conversation.updated_at
                    if conv_dt.tzinfo is None:
                        conv_dt = conv_dt.replace(tzinfo=timezone.utc)

                    if existing_dt >= conv_dt:
                        skipped += 1
                        continue  # already up-to-date

                _upsert_conversation(session, source, conversation)
                synced += 1

                # Commit in batches
                if synced % _BATCH_SIZE == 0:
                    session.commit()
                    logger.info("Synced %d/%d conversations for %s", synced, len(conversation_ids), source)

            except Exception:
                logger.exception(
                    "Error syncing conversation %s from %s",
                    conv_id,
                    source,
                )
                session.rollback()

        session.commit()
        logger.info("Sync complete for %s: %d conversations synced", source, synced)

    except Exception:
        logger.exception("Fatal error during sync for %s", source)
        session.rollback()
    finally:
        session.close()

    return synced


def _upsert_conversation(
    session: Session,
    source: str,
    conversation: Conversation,
) -> None:
    """Insert or update a conversation and its messages in the database."""
    # Find or create conversation row
    conv_row = (
        session.query(ConversationRow)
        .filter_by(source=source, remote_id=conversation.conversation_id)
        .first()
    )

    if conv_row is None:
        conv_row = ConversationRow(
            remote_id=conversation.conversation_id,
            source=source,
        )
        session.add(conv_row)

    # Update conversation fields
    conv_row.title = conversation.title
    conv_row.summary = conversation.summary
    conv_row.created_at = conversation.created_at
    conv_row.updated_at = conversation.updated_at
    conv_row.message_count = len(conversation.messages)
    conv_row.raw_metadata = conversation.metadata or None

    # Flush to get conv_row.id for FK references
    session.flush()

    # Delete existing messages (full replace on each sync)
    session.query(MessageRow).filter_by(conversation_id=conv_row.id).delete()
    session.flush()

    # Insert all messages
    for msg in conversation.messages:
        _insert_message(session, conv_row.id, msg)


def _insert_message(
    session: Session,
    conversation_id: str,
    message: ChatMessage,
) -> None:
    """Insert a message and its tool calls into the database."""
    msg_row = MessageRow(
        remote_id=message.message_id,
        conversation_id=conversation_id,
        role=message.role.value,
        content=message.content,
        thinking=message.thinking,
        thinking_duration_ms=message.thinking_duration_ms,
        timestamp=message.timestamp,
        raw_metadata=message.metadata or None,
    )
    session.add(msg_row)
    session.flush()

    # Insert tool calls
    for tc in message.tool_calls:
        tc_row = ToolCallRow(
            message_id=msg_row.id,
            tool_call_id=tc.tool_call_id,
            name=tc.name,
            params=tc.params,
            result=tc.result,
            error=tc.error,
            status=tc.status,
        )
        session.add(tc_row)
