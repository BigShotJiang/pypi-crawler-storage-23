"""Database session and engine management for swAItch.

Provides a singleton engine and session factory for the central
swaitch.db SQLite database. Call init_db() once at startup.
"""

from __future__ import annotations

import logging
from pathlib import Path

from sqlalchemy import Engine, event, create_engine
from sqlalchemy.orm import Session, sessionmaker

from swaitch.db.models import Base

logger = logging.getLogger(__name__)

_DEFAULT_DB_DIR = Path.home() / ".swaitch"
_DEFAULT_DB_PATH = _DEFAULT_DB_DIR / "swaitch.db"

_engine: Engine | None = None
_SessionFactory: sessionmaker[Session] | None = None


def _enable_wal(dbapi_conn: object, _connection_record: object) -> None:
    """Enable WAL mode for better concurrent read performance."""
    cursor = dbapi_conn.cursor()  # type: ignore[union-attr]
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


def init_db(db_path: Path | None = None) -> Engine:
    """Initialize the database engine and create tables.

    Safe to call multiple times — returns the existing engine
    if already initialized.

    Args:
        db_path: Override the default database path (useful for testing).

    Returns:
        The SQLAlchemy Engine instance.
    """
    global _engine, _SessionFactory

    if _engine is not None:
        return _engine

    path = db_path or _DEFAULT_DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    url = f"sqlite:///{path}"
    _engine = create_engine(url, echo=False)

    # Enable WAL and foreign keys on every connection
    event.listen(_engine, "connect", _enable_wal)

    # Create tables if they don't exist
    Base.metadata.create_all(_engine)

    _SessionFactory = sessionmaker(bind=_engine)

    logger.info("Database initialized at %s", path)
    return _engine


def get_session() -> Session:
    """Get a new database session.

    Raises:
        RuntimeError: If init_db() has not been called yet.
    """
    if _SessionFactory is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _SessionFactory()


def get_engine() -> Engine:
    """Get the database engine.

    Raises:
        RuntimeError: If init_db() has not been called yet.
    """
    if _engine is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _engine
