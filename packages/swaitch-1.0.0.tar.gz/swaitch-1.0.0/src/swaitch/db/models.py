"""SQLAlchemy ORM models for the swAItch central database.

All IDE parsers sync their data into these tables, providing
a unified, queryable store regardless of the source IDE.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
)


def _uuid() -> str:
    """Generate a new UUID4 string for use as a primary key."""
    return str(uuid.uuid4())


class Base(DeclarativeBase):
    """Base class for all swAItch ORM models."""

    pass


class ConversationRow(Base):
    """A conversation imported from an IDE source."""

    __tablename__ = "conversations"
    __table_args__ = (
        UniqueConstraint("source", "remote_id", name="uq_conv_source_remote"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    remote_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    source: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    title: Mapped[str] = mapped_column(Text, default="")
    summary: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    message_count: Mapped[int] = mapped_column(Integer, default=0)
    raw_metadata: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    messages: Mapped[list[MessageRow]] = relationship(
        back_populates="conversation",
        cascade="all, delete-orphan",
        order_by="MessageRow.timestamp",
    )

    def __repr__(self) -> str:
        return f"<Conversation {self.source}:{self.remote_id[:12]}>"


class MessageRow(Base):
    """A single message (bubble) within a conversation."""

    __tablename__ = "messages"
    __table_args__ = (
        UniqueConstraint(
            "conversation_id", "remote_id", name="uq_msg_conv_remote"
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    remote_id: Mapped[str] = mapped_column(String(255), nullable=False)
    conversation_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    content: Mapped[str] = mapped_column(Text, default="")
    thinking: Mapped[str | None] = mapped_column(Text, nullable=True)
    thinking_duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    timestamp: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    raw_metadata: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    conversation: Mapped[ConversationRow] = relationship(back_populates="messages")
    tool_calls: Mapped[list[ToolCallRow]] = relationship(
        back_populates="message",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<Message {self.role}:{self.remote_id[:12]}>"


class ToolCallRow(Base):
    """A tool invocation attached to an assistant message."""

    __tablename__ = "tool_calls"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    message_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("messages.id", ondelete="CASCADE"), nullable=False, index=True
    )
    tool_call_id: Mapped[str] = mapped_column(String(255), default="")
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    params: Mapped[str | None] = mapped_column(Text, nullable=True)
    result: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="unknown")

    message: Mapped[MessageRow] = relationship(back_populates="tool_calls")

    def __repr__(self) -> str:
        return f"<ToolCall {self.name}:{self.status}>"
