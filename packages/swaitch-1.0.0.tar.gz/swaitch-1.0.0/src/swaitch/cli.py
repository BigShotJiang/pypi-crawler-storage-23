"""swAItch CLI — top-level command group.

Usage:
    swaitch run [--transport stdio|http] [--host HOST] [--port PORT]
"""

from __future__ import annotations

import argparse
import logging
import sys


def main() -> None:
    """Top-level CLI entry point with subcommands."""
    parser = argparse.ArgumentParser(
        prog="swaitch",
        description="swAItch — Switch IDEs without losing AI conversation context",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- swaitch run ---
    run_parser = subparsers.add_parser("run", help="Start the MCP server")
    run_parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport mode (default: stdio)",
    )
    run_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="HTTP host (default: 127.0.0.1)",
    )
    run_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="HTTP port (default: 8000)",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "run":
        _run_server(args)


def _run_server(args: argparse.Namespace) -> None:
    """Start the MCP server."""
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    logger = logging.getLogger(__name__)
    logger.info("Starting swAItch MCP server (transport=%s)", args.transport)

    from swaitch.server import mcp

    if args.transport == "http":
        mcp.run(transport="http", host=args.host, port=args.port)
    else:
        mcp.run(transport="stdio")
