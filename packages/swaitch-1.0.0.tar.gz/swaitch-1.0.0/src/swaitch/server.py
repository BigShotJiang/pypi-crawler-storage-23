"""swAItch MCP Server — the main entry point.

Wires together the parser registry, MCP tools, and file watcher
into a FastMCP server that can run via stdio or HTTP transport.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastmcp import FastMCP

from swaitch.db.session import init_db
from swaitch.parsers.cursor import CursorParser
from swaitch.parsers.registry import ParserRegistry
from swaitch.sync import sync_source
from swaitch.tools import register_tools
from swaitch.watcher import start_watcher

logger = logging.getLogger(__name__)


def _build_registry() -> ParserRegistry:
    """Build and populate the parser registry.

    New parsers are added here. This is the only place that
    knows about concrete parser implementations — everything
    else depends on the BaseParser/ParserRegistry abstractions.
    """
    registry = ParserRegistry()
    registry.register(CursorParser())
    # Future parsers:
    # registry.register(VSCodeCopilotParser())
    # registry.register(WindsurfParser())
    return registry


def _run_initial_sync(registry: ParserRegistry) -> None:
    """Run synchronous initial sync for all parsers."""
    for parser in registry.get_all_parsers():
        try:
            count = sync_source(parser)
            logger.info(
                "Initial sync for %s: %d conversations", parser.ide_type.value, count
            )
        except Exception:
            logger.exception("Initial sync failed for %s", parser.ide_type.value)


@asynccontextmanager
async def server_lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Manage server lifecycle — init DB, sync, start watcher.

    Yields a context dict that tools can access if needed.
    The file watcher runs as a background task and is cancelled
    on server shutdown.
    """
    # Initialize the central database
    init_db()

    registry = _build_registry()

    # Register MCP tools (they query the DB directly)
    register_tools(server)

    # Run initial sync in a thread to avoid blocking the event loop
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, _run_initial_sync, registry)

    # Start file watcher as background task
    shutdown_event = asyncio.Event()
    watcher_task = asyncio.create_task(
        start_watcher(registry, shutdown_event),
        name="swaitch-file-watcher",
    )

    sources = registry.detect_sources()
    available = [s for s in sources if s.status.value == "available"]
    logger.info(
        "swAItch ready — %d/%d IDE sources available: %s",
        len(available),
        len(sources),
        [s.name for s in available],
    )

    try:
        yield {"registry": registry}
    finally:
        # Graceful shutdown
        shutdown_event.set()
        watcher_task.cancel()
        try:
            await watcher_task
        except asyncio.CancelledError:
            pass
        logger.info("swAItch server shut down")


import importlib.metadata

try:
    __version__ = importlib.metadata.version("swaitch")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0-dev"

# Create the FastMCP server instance
mcp = FastMCP(
    name="swAItch",
    version=__version__,
    instructions="""\
swAItch lets you switch IDEs without losing your AI conversation context.

Available tools:
- list_sources: Discover which IDEs have conversation data on this system
- list_conversations: Get conversation summaries from an IDE (with IDs and descriptions)
- get_conversation: Fetch the full conversation content by ID
- get_conversation_message: Fetch full untruncated message content by message ID

Typical workflow:
1. Call list_sources to see what's available
2. Call list_conversations with source="cursor" (or another source) to browse conversations
3. Call get_conversation with the conversation_id and source to get the full context
4. If a message is truncated (is_truncated=True), use get_conversation_message to get the full text
""",
    lifespan=server_lifespan,
)

