"""MCP tool definitions for swAItch.

Each tool is a standalone function registered on the FastMCP server.
Tools query the central swaitch.db for conversation data.
"""

from __future__ import annotations

import logging
from typing import Any

from swaitch.db.models import ConversationRow, MessageRow, ToolCallRow
from swaitch.db.session import get_session
from swaitch.models import (
    ChatMessage,
    Conversation,
    ConversationSummary,
    IDEType,
    MessageRole,
    ToolCallData,
)

logger = logging.getLogger(__name__)

# Maximum content length before truncation
_MAX_CONTENT_LENGTH = 2000


def register_tools(mcp: Any) -> None:
    """Register all MCP tools on the FastMCP server instance.

    This function is called during server startup. Tools query
    the central database directly — no parser dependency.

    Args:
        mcp: The FastMCP server instance.
    """

    @mcp.tool(
        description=(
            "List all detected IDE sources on the user's system. "
            "Returns which IDEs have conversation data available for import. "
            "Call this first to discover what sources are available before "
            "fetching conversations."
        ),
    )
    def list_sources() -> dict:
        """List all detected IDE sources with their availability status."""
        from swaitch.parsers.registry import ParserRegistry

        registry = _get_registry()
        sources = registry.detect_sources()
        session = get_session()
        try:
            for source in sources:
                if source.status.value == "available":
                    # Override raw disk count with the accurate DB count (excludes empty)
                    db_count = (
                        session.query(ConversationRow)
                        .filter_by(source=source.ide.value)
                        .count()
                    )
                    source.conversation_count = db_count
        finally:
            session.close()

        return {
            "sources": [source.model_dump() for source in sources],
            "total": len(sources),
            "available": sum(
                1 for s in sources if s.status.value == "available"
            ),
        }

    @mcp.tool(
        description=(
            "List conversations from a specific IDE source. "
            "Returns conversation summaries with IDs, titles, and descriptions. "
            "Use the conversation_id from the results to get full conversation "
            "messages with get_conversation. "
            "Param 'source' must be one of the IDE types returned by list_sources "
            "(e.g., 'cursor', 'vscode_copilot'). "
            "Use 'offset' to paginate through results (e.g., offset=50 to get the next page)."
        ),
    )
    def list_conversations(
        source: str,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List conversation summaries from the central database.

        Args:
            source: IDE source identifier (e.g., 'cursor').
            limit: Maximum number of conversations to return (default: 50).
            offset: Number of conversations to skip for pagination (default: 0).
        """
        try:
            IDEType(source.lower())
        except ValueError:
            available = [t.value for t in IDEType]
            return {
                "error": f"Unknown source '{source}'. Available: {available}",
                "conversations": [],
            }

        session = get_session()
        try:
            total_count = (
                session.query(ConversationRow)
                .filter_by(source=source.lower())
                .count()
            )

            rows = (
                session.query(ConversationRow)
                .filter_by(source=source.lower())
                .order_by(ConversationRow.updated_at.desc())
                .offset(offset)
                .limit(limit)
                .all()
            )

            conversations = [
                ConversationSummary(
                    conversation_id=row.remote_id,
                    title=row.title,
                    summary=row.summary,
                    source=IDEType(row.source),
                    created_at=row.created_at,
                    updated_at=row.updated_at,
                    message_count=row.message_count,
                ).model_dump()
                for row in rows
            ]

            return {
                "source": source,
                "conversations": conversations,
                "total": total_count,
                "offset": offset,
                "limit": limit,
                "has_more": (offset + limit) < total_count,
            }
        finally:
            session.close()

    @mcp.tool(
        description=(
            "Get the full conversation content including all messages and artifacts. "
            "Use this after calling list_conversations to retrieve the complete "
            "context of a specific conversation. "
            "Param 'conversation_id' is the ID from list_conversations results. "
            "Param 'source' must match the source the conversation came from. "
            "Large messages are truncated — use get_conversation_message with "
            "the message_id to fetch the full content."
        ),
    )
    def get_conversation(
        conversation_id: str,
        source: str,
    ) -> dict:
        """Get full conversation messages with truncation for large content.

        Args:
            conversation_id: The conversation ID from list_conversations.
            source: IDE source identifier (e.g., 'cursor').
        """
        try:
            IDEType(source.lower())
        except ValueError:
            available = [t.value for t in IDEType]
            return {
                "error": f"Unknown source '{source}'. Available: {available}",
            }

        session = get_session()
        try:
            conv_row = (
                session.query(ConversationRow)
                .filter_by(source=source.lower(), remote_id=conversation_id)
                .first()
            )

            if conv_row is None:
                return {
                    "error": f"Conversation '{conversation_id}' not found in {source}"
                }

            # Build messages with truncation
            messages: list[dict] = []
            for msg_row in conv_row.messages:
                msg = _row_to_chat_message(msg_row, truncate=True)
                messages.append(msg.model_dump())

            conversation = Conversation(
                conversation_id=conv_row.remote_id,
                title=conv_row.title,
                summary=conv_row.summary,
                source=IDEType(conv_row.source),
                created_at=conv_row.created_at,
                updated_at=conv_row.updated_at,
                messages=[_row_to_chat_message(m, truncate=True) for m in conv_row.messages],
                metadata=conv_row.raw_metadata or {},
            )

            return conversation.model_dump()
        finally:
            session.close()

    @mcp.tool(
        description=(
            "Get the full, untruncated content of a specific message. "
            "Use this when get_conversation returns a message with "
            "is_truncated=True. "
            "Param 'message_id' is the message_id from get_conversation results."
        ),
    )
    def get_conversation_message(
        message_id: str,
    ) -> dict:
        """Get full untruncated message content.

        Args:
            message_id: The message_id (bubbleId) from get_conversation.
        """
        session = get_session()
        try:
            msg_row = (
                session.query(MessageRow)
                .filter_by(remote_id=message_id)
                .first()
            )

            if msg_row is None:
                return {"error": f"Message '{message_id}' not found"}

            msg = _row_to_chat_message(msg_row, truncate=False)
            return msg.model_dump()
        finally:
            session.close()


def _row_to_chat_message(msg_row: MessageRow, truncate: bool = False) -> ChatMessage:
    """Convert a MessageRow to a ChatMessage Pydantic model.

    Args:
        msg_row: The database message row.
        truncate: If True, truncate content longer than _MAX_CONTENT_LENGTH.
    """
    content = msg_row.content or ""
    is_truncated = False

    if truncate and len(content) > _MAX_CONTENT_LENGTH:
        content = content[:_MAX_CONTENT_LENGTH] + "... [TRUNCATED]"
        is_truncated = True

    # Build tool calls
    tool_calls = [
        ToolCallData(
            tool_call_id=tc.tool_call_id,
            name=tc.name,
            params=_maybe_truncate(tc.params, truncate),
            result=_maybe_truncate(tc.result, truncate),
            error=tc.error,
            status=tc.status,
        )
        for tc in msg_row.tool_calls
    ]

    # Check if any tool call was truncated
    if truncate:
        for tc in msg_row.tool_calls:
            if (tc.params and len(tc.params) > _MAX_CONTENT_LENGTH) or (
                tc.result and len(tc.result) > _MAX_CONTENT_LENGTH
            ):
                is_truncated = True
                break

    return ChatMessage(
        message_id=msg_row.remote_id,
        role=MessageRole(msg_row.role),
        content=content,
        thinking=msg_row.thinking,
        thinking_duration_ms=msg_row.thinking_duration_ms,
        tool_calls=tool_calls,
        is_truncated=is_truncated,
        timestamp=msg_row.timestamp,
        metadata=msg_row.raw_metadata or {},
    )


def _maybe_truncate(text: str | None, truncate: bool) -> str | None:
    """Truncate text if it exceeds the maximum content length."""
    if text is None:
        return None
    if truncate and len(text) > _MAX_CONTENT_LENGTH:
        return text[:_MAX_CONTENT_LENGTH] + "... [TRUNCATED]"
    return text


_registry_instance = None


def _get_registry():
    """Lazy-load the registry singleton for list_sources."""
    global _registry_instance
    if _registry_instance is None:
        from swaitch.parsers.cursor import CursorParser
        from swaitch.parsers.registry import ParserRegistry

        _registry_instance = ParserRegistry()
        _registry_instance.register(CursorParser())
    return _registry_instance
