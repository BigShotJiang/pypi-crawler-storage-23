"""Pydantic data models for swAItch conversation data.

All IDE parsers normalize their data into these models,
providing a consistent interface regardless of the source IDE.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class IDEType(str, Enum):
    """Supported IDE types."""

    CURSOR = "cursor"
    VSCODE_COPILOT = "vscode_copilot"
    WINDSURF = "windsurf"


class SourceStatus(str, Enum):
    """Detection status for an IDE source."""

    AVAILABLE = "available"
    NOT_FOUND = "not_found"
    UNSUPPORTED = "unsupported"
    ERROR = "error"


class IDESource(BaseModel):
    """A detected IDE installation on the user's system."""

    ide: IDEType
    name: str = Field(description="Human-readable IDE name")
    data_path: str = Field(description="Path to the IDE's conversation data")
    status: SourceStatus
    conversation_count: int = 0
    error_message: str | None = None


class MessageRole(str, Enum):
    """Role of a chat message sender."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


class ToolCallData(BaseModel):
    """A single tool invocation within a message."""

    tool_call_id: str = ""
    name: str
    params: str | None = None
    result: str | None = None
    error: str | None = None
    status: str = "unknown"


class ChatMessage(BaseModel):
    """A single message in a conversation."""

    message_id: str = Field(default="", description="Unique message identifier (e.g., bubbleId)")
    role: MessageRole
    content: str = ""
    thinking: str | None = Field(
        default=None,
        description="AI reasoning/chain-of-thought (when available from the source IDE)",
    )
    thinking_duration_ms: int | None = Field(
        default=None,
        description="Duration of thinking in milliseconds",
    )
    tool_calls: list[ToolCallData] = Field(
        default_factory=list,
        description="Tool invocations attached to this message",
    )
    is_truncated: bool = Field(
        default=False,
        description="True if content was truncated; use get_conversation_message for full text",
    )
    timestamp: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ConversationSummary(BaseModel):
    """Lightweight summary of a conversation — returned by list operations."""

    conversation_id: str
    title: str
    summary: str = ""
    source: IDEType
    created_at: datetime | None = None
    updated_at: datetime | None = None
    message_count: int = 0
    artifact_types: list[str] = Field(default_factory=list)


class Conversation(BaseModel):
    """Full conversation with all messages and metadata."""

    conversation_id: str
    title: str
    summary: str = ""
    source: IDEType
    created_at: datetime | None = None
    updated_at: datetime | None = None
    messages: list[ChatMessage] = Field(default_factory=list)
    artifacts: dict[str, str] = Field(
        default_factory=dict,
        description="Artifact name -> content mapping (e.g., task.md, walkthrough.md)",
    )
    metadata: dict[str, Any] = Field(default_factory=dict)

