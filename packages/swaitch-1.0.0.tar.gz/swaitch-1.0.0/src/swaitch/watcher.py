"""File system watcher for live conversation updates.

Monitors IDE data directories for changes and triggers
sync to update the central database.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from watchfiles import Change, awatch

from swaitch.parsers.registry import ParserRegistry
from swaitch.sync import sync_source

logger = logging.getLogger(__name__)

# Debounce window in seconds — group rapid successive writes
_DEBOUNCE_SECONDS = 0.3


async def start_watcher(
    registry: ParserRegistry,
    shutdown_event: asyncio.Event,
) -> None:
    """Start watching all parser directories for changes.

    Runs as an async background task during server lifespan.
    When files change, triggers a re-sync for affected parsers
    to update the central database.

    Args:
        registry: The parser registry to collect watch paths from.
        shutdown_event: Event to signal when the watcher should stop.
    """
    watch_paths = registry.get_all_watch_paths()
    if not watch_paths:
        logger.info("No paths to watch — file watcher idle")
        return

    # Filter to existing paths only
    existing_paths = [p for p in watch_paths if p.exists()]
    if not existing_paths:
        logger.warning("Watch paths do not exist yet: %s", watch_paths)
        return

    logger.info(
        "File watcher started — monitoring %d paths: %s",
        len(existing_paths),
        [str(p) for p in existing_paths],
    )

    try:
        async for changes in awatch(
            *existing_paths,
            debounce=int(_DEBOUNCE_SECONDS * 1000),
            step=100,
            stop_event=shutdown_event,
        ):
            await _handle_changes(changes, registry)
    except asyncio.CancelledError:
        logger.info("File watcher cancelled")
    except Exception:
        logger.exception("File watcher error")


async def _handle_changes(
    changes: set[tuple[Change, str]],
    registry: ParserRegistry,
) -> None:
    """Process a batch of file system changes.

    Invalidates parser caches and triggers re-sync to update the
    central database with fresh data.
    """
    change_summary = {
        Change.added: 0,
        Change.modified: 0,
        Change.deleted: 0,
    }

    affected_files: list[str] = []
    for change_type, path in changes:
        change_summary[change_type] = change_summary.get(change_type, 0) + 1
        affected_files.append(Path(path).name)

    logger.info(
        "File changes detected — added=%d modified=%d deleted=%d files=%s",
        change_summary.get(Change.added, 0),
        change_summary.get(Change.modified, 0),
        change_summary.get(Change.deleted, 0),
        affected_files[:5],  # log first 5 to avoid noise
    )

    # Invalidate caches and re-sync
    registry.invalidate_all()

    # Run sync in a thread to avoid blocking the event loop
    loop = asyncio.get_event_loop()
    for parser in registry.get_all_parsers():
        try:
            await loop.run_in_executor(None, sync_source, parser)
        except Exception:
            logger.exception("Re-sync failed for %s after file change", parser.ide_type.value)

    logger.debug("Re-sync complete after file changes")
