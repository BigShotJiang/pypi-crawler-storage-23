"""swAItch — Switch IDEs without losing your AI conversation context."""

__version__ = "0.1.0"
