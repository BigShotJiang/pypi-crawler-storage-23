"""Cursor IDE conversation parser.

Parses conversation data from Cursor's SQLite databases:
- globalStorage/state.vscdb → table: cursorDiskKV
  - composerData:<uuid> → conversation envelope (headers, status, context)
  - bubbleId:<composerId>:<bubbleId> → individual messages (text, type, timestamp)

All data is stored as JSON blobs in a simple key-value table.
No encryption — fully accessible via stdlib sqlite3.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path

from swaitch.config import config
from swaitch.models import (
    ChatMessage,
    Conversation,
    IDESource,
    IDEType,
    MessageRole,
    SourceStatus,
    ToolCallData,
)
from swaitch.parsers.base import BaseParser, ConversationNotFoundError

logger = logging.getLogger(__name__)

# Cursor bubble types → our MessageRole
_BUBBLE_TYPE_USER = 1
_BUBBLE_TYPE_ASSISTANT = 2


class CursorParser(BaseParser):
    """Parser for Cursor IDE conversations.

    Data layout:
        ~/Library/Application Support/Cursor/User/
        ├── globalStorage/
        │   └── state.vscdb          # SQLite: cursorDiskKV table
        └── workspaceStorage/
            └── <hash>/
                ├── workspace.json   # maps hash → project folder
                └── state.vscdb      # workspace-scoped data
    """

    @property
    def ide_type(self) -> IDEType:
        return IDEType.CURSOR

    @property
    def display_name(self) -> str:
        return "Cursor"

    def detect(self) -> IDESource:
        """Check if Cursor's globalStorage database exists."""
        db_path = self._get_db_path()

        if db_path.is_file():
            conv_count = len(self.list_conversation_ids())
            return IDESource(
                ide=self.ide_type,
                name=self.display_name,
                data_path=str(db_path.parent),
                status=SourceStatus.AVAILABLE,
                conversation_count=conv_count,
            )

        return IDESource(
            ide=self.ide_type,
            name=self.display_name,
            data_path=str(config.paths.cursor_global_storage),
            status=SourceStatus.NOT_FOUND,
        )

    def get_watch_paths(self) -> list[Path]:
        """Return paths to watch for conversation changes."""
        paths: list[Path] = []
        if config.paths.cursor_global_storage.is_dir():
            paths.append(config.paths.cursor_global_storage)
        return paths

    def list_conversation_ids(self) -> list[str]:
        """Return all conversation IDs from Cursor's globalStorage database."""
        db_path = self._get_db_path()
        if not db_path.is_file():
            return []

        try:
            with self._connect(db_path) as conn:
                cursor = conn.execute(
                    "SELECT key FROM cursorDiskKV WHERE key LIKE 'composerData:%'"
                )
                return [
                    row[0].removeprefix("composerData:")
                    for row in cursor.fetchall()
                ]
        except sqlite3.Error:
            logger.exception("Error listing Cursor conversation IDs")
            return []

    def get_conversation(self, conversation_id: str) -> Conversation:
        """Fetch a full conversation by ID.

        Reads the composerData envelope and all associated bubbleId messages,
        assembling them into a normalized Conversation object.
        """
        db_path = self._get_db_path()
        if not db_path.is_file():
            raise ConversationNotFoundError(conversation_id, self.ide_type)

        # Read composer data
        composer_data = self._query_key(db_path, f"composerData:{conversation_id}")
        if composer_data is None:
            raise ConversationNotFoundError(conversation_id, self.ide_type)

        try:
            composer = json.loads(composer_data)
        except (json.JSONDecodeError, TypeError) as e:
            raise ConversationNotFoundError(conversation_id, self.ide_type) from e

        headers = composer.get("fullConversationHeadersOnly", [])
        if not headers:
            return Conversation(
                conversation_id=conversation_id,
                title=conversation_id[:12] + "...",
                source=self.ide_type,
                messages=[],
            )

        # Read all bubble messages in order
        messages: list[ChatMessage] = []
        title = conversation_id[:12] + "..."
        earliest_ts: datetime | None = None
        latest_ts: datetime | None = None
        first_user_text = ""

        for header in headers:
            bubble_id = header.get("bubbleId", "")
            if not bubble_id:
                continue

            bubble_data = self._query_key(
                db_path, f"bubbleId:{conversation_id}:{bubble_id}"
            )
            if bubble_data is None:
                continue

            try:
                bubble = json.loads(bubble_data)
            except (json.JSONDecodeError, TypeError):
                continue

            message = self._bubble_to_message(bubble)
            if message is None:
                continue

            # Track first user message for title
            if message.role == MessageRole.USER and not first_user_text and message.content:
                first_user_text = message.content

            # Track timestamps
            if message.timestamp:
                if earliest_ts is None or message.timestamp < earliest_ts:
                    earliest_ts = message.timestamp
                if latest_ts is None or message.timestamp > latest_ts:
                    latest_ts = message.timestamp

            messages.append(message)

        # Derive title from first user message
        if first_user_text:
            if len(first_user_text) > 80:
                title = first_user_text[:77] + "..."
            else:
                title = first_user_text

        return Conversation(
            conversation_id=conversation_id,
            title=title,
            source=self.ide_type,
            created_at=earliest_ts,
            updated_at=latest_ts,
            messages=messages,
            metadata={
                "status": composer.get("status", ""),
                "message_count": len(messages),
                "db_path": str(db_path),
            },
        )

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _get_db_path() -> Path:
        """Return the path to Cursor's globalStorage database."""
        return config.paths.cursor_global_storage / "state.vscdb"

    @staticmethod
    def _bubble_to_message(bubble: dict) -> ChatMessage | None:
        """Convert a Cursor bubble JSON object to a ChatMessage.

        Handles all 4 bubble patterns:
        1. User messages (type=1): text, context, modelInfo
        2. Thinking-only (type=2, has thinking): thinking.text, thinkingDurationMs
        3. Status/text (type=2, has text, no tool): assistant response text
        4. Tool calls (type=2, has toolFormerData): name, params, result, error
        """
        bubble_type = bubble.get("type", 0)
        bubble_id = bubble.get("bubbleId", "")
        text = bubble.get("text", "")

        # Map bubble type to role
        if bubble_type == _BUBBLE_TYPE_USER:
            role = MessageRole.USER
        elif bubble_type == _BUBBLE_TYPE_ASSISTANT:
            role = MessageRole.ASSISTANT
        else:
            return None  # skip unknown types

        # Parse timestamp
        timestamp = None
        created_at = bubble.get("createdAt")
        if created_at:
            try:
                timestamp = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
            except (ValueError, TypeError):
                pass

        # Extract thinking/chain-of-thought
        thinking_text: str | None = None
        thinking_duration_ms: int | None = None
        thinking_data = bubble.get("thinking")
        if thinking_data and isinstance(thinking_data, dict):
            thinking_text = thinking_data.get("text") or None
            thinking_duration_ms = bubble.get("thinkingDurationMs")

        # Extract tool calls from toolFormerData
        tool_calls: list[ToolCallData] = []
        tool_former = bubble.get("toolFormerData")
        if tool_former and isinstance(tool_former, dict):
            tool_call = ToolCallData(
                tool_call_id=tool_former.get("toolCallId", ""),
                name=tool_former.get("name", "unknown"),
                params=tool_former.get("params"),
                result=tool_former.get("result"),
                error=_extract_error(tool_former),
                status=tool_former.get("status", "unknown"),
            )
            tool_calls.append(tool_call)

        # Build metadata with Cursor-specific fields
        metadata: dict = {}
        if bubble.get("modelInfo"):
            metadata["model"] = bubble["modelInfo"].get("modelName", "")
        if bubble.get("capabilityType") is not None:
            metadata["capability_type"] = bubble["capabilityType"]
        if bubble.get("isAgentic"):
            metadata["is_agentic"] = True
        if bubble.get("turnDurationMs"):
            metadata["turn_duration_ms"] = bubble["turnDurationMs"]
        if bubble.get("thinkingStyle") is not None:
            metadata["thinking_style"] = bubble["thinkingStyle"]
        if bubble.get("unifiedMode") is not None:
            metadata["unified_mode"] = bubble["unifiedMode"]
        if bubble.get("requestId"):
            metadata["request_id"] = bubble["requestId"]
        if bubble.get("checkpointId"):
            metadata["checkpoint_id"] = bubble["checkpointId"]

        # Don't skip empty assistant messages anymore — they may carry thinking or tool calls
        if not text and not thinking_text and not tool_calls and role == MessageRole.ASSISTANT:
            return None

        return ChatMessage(
            message_id=bubble_id,
            role=role,
            content=text,
            thinking=thinking_text,
            thinking_duration_ms=thinking_duration_ms,
            tool_calls=tool_calls,
            timestamp=timestamp,
            metadata=metadata,
        )

    @staticmethod
    def _query_key(db_path: Path, key: str) -> str | None:
        """Query a single key from cursorDiskKV.

        Opens the database in read-only mode to avoid locking conflicts
        with the running Cursor IDE.
        """
        try:
            uri = f"file:{db_path}?mode=ro"
            with sqlite3.connect(uri, uri=True) as conn:
                cursor = conn.execute(
                    "SELECT value FROM cursorDiskKV WHERE key = ?", (key,)
                )
                row = cursor.fetchone()
                return row[0] if row else None
        except sqlite3.Error:
            logger.debug("Error querying key %s", key)
            return None

    @staticmethod
    def _connect(db_path: Path) -> sqlite3.Connection:
        """Open the database in read-only mode.

        Uses URI mode so we don't create locks that interfere
        with the running Cursor IDE.
        """
        uri = f"file:{db_path}?mode=ro"
        return sqlite3.connect(uri, uri=True)


def _extract_error(tool_former: dict) -> str | None:
    """Extract error message from toolFormerData.

    Cursor stores errors as JSON strings with clientVisibleErrorMessage
    and modelVisibleErrorMessage fields.
    """
    error_raw = tool_former.get("error")
    if not error_raw:
        return None

    if isinstance(error_raw, str):
        try:
            error_data = json.loads(error_raw)
            return (
                error_data.get("clientVisibleErrorMessage")
                or error_data.get("modelVisibleErrorMessage")
                or error_raw
            )
        except (json.JSONDecodeError, TypeError):
            return error_raw

    if isinstance(error_raw, dict):
        return (
            error_raw.get("clientVisibleErrorMessage")
            or error_raw.get("modelVisibleErrorMessage")
            or str(error_raw)
        )

    return str(error_raw)
