"""IDE conversation parsers — extensible registry for multi-IDE support."""

from swaitch.parsers.registry import ParserRegistry

__all__ = ["ParserRegistry"]
