"""Parser registry — auto-discovers and manages IDE parsers.

Follows the Dependency Inversion Principle: the server and tools
depend on this registry abstraction, not on concrete parser implementations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from swaitch.models import IDESource, IDEType, SourceStatus

if TYPE_CHECKING:
    from pathlib import Path

    from swaitch.parsers.base import BaseParser

logger = logging.getLogger(__name__)


class ParserRegistry:
    """Central registry for IDE conversation parsers.

    Usage:
        registry = ParserRegistry()
        registry.register(CursorParser())
        registry.register(WindsurfParser())  # future

        sources = registry.detect_sources()
        parser = registry.get_parser(IDEType.CURSOR)
    """

    def __init__(self) -> None:
        self._parsers: dict[IDEType, BaseParser] = {}

    def register(self, parser: BaseParser) -> None:
        """Register a parser for an IDE type.

        Args:
            parser: Parser instance to register.

        Raises:
            ValueError: If a parser for this IDE type is already registered.
        """
        if parser.ide_type in self._parsers:
            raise ValueError(
                f"Parser for {parser.ide_type.value} is already registered"
            )
        self._parsers[parser.ide_type] = parser
        logger.info("Registered parser: %s", parser.display_name)

    def detect_sources(self) -> list[IDESource]:
        """Run detection for all registered parsers.

        Returns:
            List of IDESource objects with availability status.
        """
        sources: list[IDESource] = []
        for parser in self._parsers.values():
            try:
                source = parser.detect()
                sources.append(source)
            except Exception:
                logger.exception("Error detecting %s", parser.display_name)
                sources.append(
                    IDESource(
                        ide=parser.ide_type,
                        name=parser.display_name,
                        data_path="",
                        status=SourceStatus.ERROR,
                        error_message=f"Detection failed for {parser.display_name}",
                    )
                )
        return sources

    def get_parser(self, ide_type: IDEType) -> BaseParser:
        """Get the parser for a specific IDE type.

        Args:
            ide_type: The IDE type to look up.

        Returns:
            The registered parser.

        Raises:
            KeyError: If no parser is registered for this IDE type.
        """
        if ide_type not in self._parsers:
            available = [t.value for t in self._parsers]
            raise KeyError(
                f"No parser registered for '{ide_type.value}'. "
                f"Available: {available}"
            )
        return self._parsers[ide_type]

    def get_all_watch_paths(self) -> list[Path]:
        """Collect watch paths from all registered and available parsers.

        Returns:
            Flat list of filesystem paths to watch for changes.
        """
        paths: list[Path] = []
        for parser in self._parsers.values():
            try:
                source = parser.detect()
                if source.status == SourceStatus.AVAILABLE:
                    paths.extend(parser.get_watch_paths())
            except Exception:
                logger.exception(
                    "Error getting watch paths from %s", parser.display_name
                )
        return paths

    @property
    def registered_types(self) -> list[IDEType]:
        """List all registered IDE types."""
        return list(self._parsers.keys())

    def invalidate_all(self) -> None:
        """Invalidate caches for all parsers."""
        for parser in self._parsers.values():
            parser.invalidate_cache()

    def get_all_parsers(self) -> list[BaseParser]:
        """Return all registered parser instances."""
        return list(self._parsers.values())
