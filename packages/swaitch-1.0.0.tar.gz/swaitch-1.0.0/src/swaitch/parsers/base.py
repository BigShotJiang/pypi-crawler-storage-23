"""Abstract base parser — defines the contract all IDE parsers must implement.

Following the Open/Closed Principle: new parsers extend this class
without modifying existing code. Interface Segregation: only the
methods that are genuinely needed are required.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from swaitch.models import (
    Conversation,
    ConversationSummary,
    IDESource,
    IDEType,
)


class BaseParser(ABC):
    """Abstract base class for IDE conversation parsers.

    Each parser is responsible for:
    1. Detecting whether the IDE's data exists on the system
    2. Listing conversations with lightweight summaries
    3. Fetching full conversation details by ID
    4. Reporting which paths to watch for live updates

    Subclasses MUST implement all abstract methods.
    """

    @property
    @abstractmethod
    def ide_type(self) -> IDEType:
        """The IDE type this parser handles."""

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable name for the IDE (e.g., 'Cursor')."""

    @abstractmethod
    def detect(self) -> IDESource:
        """Check if the IDE's data exists on this system.

        Returns:
            An IDESource with status indicating availability.
        """

    @abstractmethod
    def get_watch_paths(self) -> list[Path]:
        """Return filesystem paths to watch for conversation changes.

        The watcher will monitor these paths and trigger cache invalidation
        when files change.

        Returns:
            List of directory paths to watch. Empty if IDE not detected.
        """

    @abstractmethod
    def list_conversation_ids(self) -> list[str]:
        """Return all conversation IDs available in this IDE.

        The sync layer uses this to know which conversations to fetch.

        Returns:
            List of conversation ID strings.
        """

    @abstractmethod
    def get_conversation(self, conversation_id: str) -> Conversation:
        """Fetch a full conversation by its ID.

        Args:
            conversation_id: Unique conversation identifier.

        Returns:
            Full conversation with all messages and artifacts.

        Raises:
            ConversationNotFoundError: If no conversation matches the ID.
        """

    def invalidate_cache(self) -> None:
        """Invalidate any cached data.

        Called by the file watcher when conversation files change.
        Subclasses should override if they maintain caches.
        """


class ConversationNotFoundError(Exception):
    """Raised when a conversation ID doesn't match any known conversation."""

    def __init__(self, conversation_id: str, source: IDEType) -> None:
        self.conversation_id = conversation_id
        self.source = source
        super().__init__(
            f"Conversation '{conversation_id}' not found in {source.value}"
        )
