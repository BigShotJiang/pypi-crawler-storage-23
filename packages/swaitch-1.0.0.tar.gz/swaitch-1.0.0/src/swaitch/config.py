"""Platform-aware configuration and path resolution for swAItch.

Centralizes all path constants and configuration so parsers
don't hardcode platform-specific paths.
"""

from __future__ import annotations

import platform
from dataclasses import dataclass, field
from pathlib import Path


def _get_home() -> Path:
    """Return the user's home directory."""
    return Path.home()


@dataclass(frozen=True)
class IDEPaths:
    """Known data paths for each IDE, resolved per-platform."""

    # Cursor
    cursor_global_storage: Path = field(init=False)
    cursor_workspace_storage: Path = field(init=False)

    # VS Code Copilot (future)
    vscode_workspace_storage: Path = field(init=False)

    # Windsurf (future)
    windsurf_cascade: Path = field(init=False)

    def __post_init__(self) -> None:
        home = _get_home()
        system = platform.system()

        # Cursor — platform-dependent
        if system == "Darwin":
            cursor_base = home / "Library" / "Application Support" / "Cursor" / "User"
        elif system == "Linux":
            cursor_base = home / ".config" / "Cursor" / "User"
        else:  # Windows
            cursor_base = home / "AppData" / "Roaming" / "Cursor" / "User"

        object.__setattr__(
            self, "cursor_global_storage", cursor_base / "globalStorage"
        )
        object.__setattr__(
            self, "cursor_workspace_storage", cursor_base / "workspaceStorage"
        )

        # VS Code Copilot — platform-dependent
        if system == "Darwin":
            vscode_base = home / "Library" / "Application Support" / "Code" / "User"
        elif system == "Linux":
            vscode_base = home / ".config" / "Code" / "User"
        else:
            vscode_base = home / "AppData" / "Roaming" / "Code" / "User"

        object.__setattr__(
            self, "vscode_workspace_storage", vscode_base / "workspaceStorage"
        )

        # Windsurf
        object.__setattr__(
            self,
            "windsurf_cascade",
            home / ".codeium" / "windsurf" / "cascade",
        )


@dataclass(frozen=True)
class SwaitchConfig:
    """Top-level swAItch configuration."""

    paths: IDEPaths = field(default_factory=IDEPaths)
    cache_dir: Path = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "cache_dir",
            _get_home() / ".swaitch" / "cache",
        )


# Module-level singleton — import and use directly
config = SwaitchConfig()
