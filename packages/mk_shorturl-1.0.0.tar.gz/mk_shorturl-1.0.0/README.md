# mk_shorturl

Python library to creating:
- Create a short link

## Installation
```bash
pip install mk_shorturl
```
## Usage

```python

import mk_shorturl

# لتنزيل الحزمة cmd اكتب هذا الامر في
# pip install mk_shorturl

s = mk_shorturl.Short_url("URL")

short = s.shorten()
print("Short URL:", short)

s.generate_qr("img.png")


