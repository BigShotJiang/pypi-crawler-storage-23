from n_utils.profile_util import cli_enable_profile

cli_enable_profile()
