# SPDX-License-Identifier: MIT
"""Domain helpers for initialization operations."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.infrastructure.fenix_api.client import FenixApiClient


@dataclass(slots=True)
class InitializationData:
    profile: Optional[Dict[str, Any]]
    core_documents: List[Dict[str, Any]]
    user_documents: List[Dict[str, Any]]
    my_work_items: List[Dict[str, Any]]


class InitializationService:
    """Fetch and format initialization data from the Fênix API."""

    def __init__(self, api_client: FenixApiClient, logger):
        self._api = api_client
        self._logger = logger

    async def gather_data(self, *, include_user_docs: bool) -> InitializationData:
        profile = await self._safe_call(self._api.get_profile)
        core_docs = await self._safe_call(
            self._api.list_core_documents,
            return_content=True,
        )
        if self._logger:
            self._logger.debug("Core docs response", extra={"core_docs": core_docs})
        user_docs: List[Dict[str, Any]] = []
        if include_user_docs:
            user_docs = (
                await self._safe_call(
                    self._api.list_user_core_documents,
                    return_content=True,
                )
                or []
            )
            if self._logger:
                self._logger.debug("User docs response", extra={"user_docs": user_docs})

        # Fetch user's assigned work items for proactive context
        work_items_response = await self._safe_call(
            self._api.get_work_items_mine,
            limit=10,
        )
        my_work_items = self._extract_items(work_items_response, "workItems")

        return InitializationData(
            profile=profile,
            core_documents=self._extract_items(core_docs, "coreDocuments"),
            user_documents=self._extract_items(user_docs, "userCoreDocuments"),
            my_work_items=my_work_items,
        )

    async def _safe_call(self, func, *args, **kwargs):
        try:
            return await asyncio.to_thread(func, *args, **kwargs)
        except Exception as exc:  # pragma: no cover - defensive logging path
            self._logger.warning("Initialization API call failed: %s", exc)
            return None

    @staticmethod
    def _extract_items(payload: Any, key: str) -> List[Dict[str, Any]]:
        if payload is None:
            return []
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]
        if isinstance(payload, dict):
            value = payload.get(key) or payload.get("data")
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        return []
