# SPDX-License-Identifier: MIT
"""Fenix Todo Add prompt - create a TODO from conversation context."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixTodoAddPrompt(Prompt):
    """Prompt to create a TODO from conversation context."""

    name = "todo-add"
    description = "Create a TODO from conversation context"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Create a TODO based on our conversation.

**Instructions:**
1. Analyze the conversation to identify action items or things to remember
2. Use `mcp__fenix__productivity` with `action: todo_create` and:
   - title: A clear, actionable title
   - content: Details and context from our conversation
   - priority: Set appropriately (low, medium, high, urgent)
   - tags: Add relevant tags
3. Confirm the TODO was created"""

        return PromptResult(
            description="Create TODO from conversation",
            messages=[PromptMessage(role="user", text=instruction)],
        )
