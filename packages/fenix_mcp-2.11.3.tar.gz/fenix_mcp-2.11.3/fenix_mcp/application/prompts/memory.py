# SPDX-License-Identifier: MIT
"""Fenix Memory prompt - save content to semantic memory."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixMemoryPrompt(Prompt):
    """Prompt to save content to Fenix semantic memory."""

    name = "memory"
    description = "Save content to Fenix semantic memory for future reference"
    arguments: List[PromptArgument] = [
        PromptArgument(
            name="content",
            description="The content to save (optional - will summarize conversation if empty)",
            required=False,
        ),
    ]

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        content = arguments.get("content", "")

        if not content:
            # No content provided - instruct to summarize the conversation
            instruction = """Summarize and save our conversation to Fenix semantic memory \
using the `mcp__fenix__intelligence` tool with `action: memory_save`.

**Instructions:**
1. Analyze the conversation above and identify the key decisions, learnings, or outcomes
2. Create a concise but comprehensive summary of what was discussed and decided
3. Create an appropriate title that captures the main topic
4. Generate relevant tags (at least 2-3 tags) based on the topics covered
5. Save using memory_save action
6. Confirm once saved successfully

Focus on capturing information that would be useful to recall in future conversations."""

            return PromptResult(
                description="Summarize and save conversation to Fenix memory",
                messages=[PromptMessage(role="user", text=instruction)],
            )

        instruction = f"""Save the following content to Fenix semantic memory using \
the `mcp__fenix__intelligence` tool with `action: memory_save`.

**Content to save:**
{content}

**Instructions:**
1. Create an appropriate title that summarizes the content
2. Generate relevant tags (at least 2-3 tags)
3. Use the content as provided for the memory content field
4. Confirm once saved successfully"""

        return PromptResult(
            description="Save content to Fenix semantic memory",
            messages=[PromptMessage(role="user", text=instruction)],
        )
