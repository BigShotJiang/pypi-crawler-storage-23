# SPDX-License-Identifier: MIT
"""Fenix Docs prompt - show documentation tree."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixDocsPrompt(Prompt):
    """Prompt to show the documentation tree."""

    name = "docs"
    description = "Show team documentation tree"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Show the team documentation structure.

**Instructions:**
1. Use `mcp__fenix__knowledge` with `action: doc_full_tree` to get the complete \
documentation tree
2. Present the structure in a clear, hierarchical format
3. Show folder names with their contents indented
4. Include document emojis and titles
5. Mention how many documents exist in total

Tip: Use /fenix:docs-search to search or /fenix:docs-create to create new docs."""

        return PromptResult(
            description="Show documentation tree",
            messages=[PromptMessage(role="user", text=instruction)],
        )
