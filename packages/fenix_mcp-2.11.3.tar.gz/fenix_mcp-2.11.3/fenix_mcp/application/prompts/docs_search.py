# SPDX-License-Identifier: MIT
"""Fenix Docs Search prompt - search team documentation."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixDocsSearchPrompt(Prompt):
    """Prompt to search team documentation."""

    name = "docs-search"
    description = "Search team documentation"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Search the team documentation for relevant information.

**Instructions:**
1. Ask me what I'm looking for in the documentation
2. Use `mcp__fenix__knowledge` with `action: doc_full_tree` to get the documentation tree
3. Look for documents related to my query
4. If found, use `action: doc_get` with the document ID to fetch the content
5. Present the relevant information in a clear format
6. If not found, suggest creating new documentation with /fenix:docs-create"""

        return PromptResult(
            description="Search team documentation",
            messages=[PromptMessage(role="user", text=instruction)],
        )
