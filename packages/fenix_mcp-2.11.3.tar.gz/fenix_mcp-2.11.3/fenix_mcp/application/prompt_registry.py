# SPDX-License-Identifier: MIT
"""Registry that keeps the mapping between prompt names and instances."""

from __future__ import annotations

from typing import Any, Dict, Iterable, List

from fenix_mcp.application.prompt_base import Prompt, PromptResult


class PromptRegistry:
    """Lookup table for prompt execution."""

    def __init__(self, prompts: Iterable[Prompt]):
        self._prompts: Dict[str, Prompt] = {}
        for prompt in prompts:
            if prompt.name in self._prompts:
                raise ValueError(f"Duplicate prompt name detected: {prompt.name}")
            self._prompts[prompt.name] = prompt

    def list_definitions(self) -> List[dict]:
        """Return list of prompt schemas for prompts/list."""
        return [prompt.schema() for prompt in self._prompts.values()]

    def get(self, name: str, arguments: Dict[str, Any]) -> PromptResult:
        """Get prompt messages for prompts/get."""
        try:
            prompt = self._prompts[name]
        except KeyError as exc:
            raise KeyError(f"Unknown prompt '{name}'") from exc
        return prompt.get_messages(arguments)


def build_default_prompt_registry() -> PromptRegistry:
    """Build the default prompt registry with all available prompts."""
    from fenix_mcp.application.prompts import build_prompts

    prompts = build_prompts()
    return PromptRegistry(prompts)
