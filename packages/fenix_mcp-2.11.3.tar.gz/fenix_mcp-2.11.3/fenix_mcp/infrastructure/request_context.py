# SPDX-License-Identifier: MIT
"""Request-scoped context using contextvars for async isolation."""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass
from typing import Optional

# Context variable for the current request's token
# This is automatically isolated per async task/request
_current_token: ContextVar[Optional[str]] = ContextVar("current_token", default=None)


@dataclass(slots=True, frozen=True)
class RequestContext:
    """Holds request-scoped data like the user's token."""

    token: Optional[str] = None
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    team_id: Optional[str] = None


def set_request_token(token: Optional[str]) -> None:
    """Set the token for the current async context/request."""
    _current_token.set(token)


def get_request_token() -> Optional[str]:
    """Get the token for the current async context/request."""
    return _current_token.get()


def clear_request_token() -> None:
    """Clear the token for the current async context/request."""
    _current_token.set(None)
