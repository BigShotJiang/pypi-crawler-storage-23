__author__ = "Mohit Rajput"
__version__ = "0.0.1"

author = __author__
version = __version__