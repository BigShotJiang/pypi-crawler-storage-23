"""Veld — contract-first, multi-stack API code generator."""

__version__ = "0.1.8"

