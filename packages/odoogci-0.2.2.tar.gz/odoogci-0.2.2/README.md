# odoogci

A utility for cloning Git repositories, removing unnecessary files, and installing dependencies from `requirements.txt`. It is specifically designed to facilitate building Odoo Docker images.

## Requirements

Ensure you have the following tools installed on your system:

- Python ^3.9
- Git
- pip (Python package manager)

## Installation

### Via pipx (Recommended for CLI)
```sh
pipx install odoogci
```

### Via pip
```sh
pip install odoogci
```

### In a Dockerfile (From source)
Add the following line to your Dockerfile:

```Dockerfile
RUN pip3 install git+https://gitlab.com/alitux/odoogci.git
```

## Usage

The general usage of the tool is:

```sh
odoogci [URL] [OPTIONS]
```

### Arguments

*   `URL`: URL of the repository to clone.

### Options

*   `--branch TEXT`: Branch of the repository.
*   `--repositories TEXT`: JSON string with a list of repositories to clone.
*   `--requirements / --no-requirements`: Install dependencies from `requirements.txt`. [default: no-requirements]
*   `--repopath TEXT`: Local path where the repository will be cloned.
*   `--token TEXT`: Access token for the repository (supports GitHub and GitLab).

### Examples

#### Simple Clone
```sh
odoogci https://github.com/ingadhoc/odoo-argentina --branch 16.0
```

#### Clone Multiple Repositories using JSON
```sh
odoogci --repositories '[
    {
        "url": "https://github.com/org/repo1",
        "branch": "18.0",
        "repo_path": "repo1"
    },
    {
        "url": "https://github.com/OCA/commission",
        "branch": "18.0",
        "repo_path": "oca/commission"
    }
]'
```

#### Usage in a Dockerfile

```Dockerfile
RUN cd /usr/lib/python3/dist-packages/odoo/addons/ && \
    odoogci https://github.com/ingadhoc/odoo-argentina --branch 16.0 && \
    odoogci https://github.com/ingadhoc/account-invoicing --branch 16.0
```
