# Ravana AI

Turn Claude Code into a professional equity research analyst.

## Install

```bash
pip install ravana-ai
```

## Setup

```bash
ravana init
cd analysis
claude
```

## What You Get

- **7 research skills** — `/analyze`, `/one-pager`, `/earnings-prep`, `/peer-comp`, `/screen`, `/deep-dive`, `/scrape-ir`
- **SEC EDGAR integration** — Pull filings and transcripts directly
- **Web research** — Search and scrape any public source
- **Structured workflow** — Professional equity research process, not generic AI chat

## Requirements

- [Claude Code](https://claude.ai/code) installed and configured
- Python 3.10+
