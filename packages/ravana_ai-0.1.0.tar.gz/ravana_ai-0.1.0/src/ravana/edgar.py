"""SEC EDGAR client — fetch filings and transcripts."""

import asyncio
import re
from typing import Optional

import httpx
from bs4 import BeautifulSoup

EDGAR_BASE = "https://data.sec.gov"
EDGAR_ARCHIVES = "https://www.sec.gov/Archives/edgar/data"
COMPANY_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"

# Cache ticker -> CIK mapping
_cik_cache: dict[str, str] = {}


async def _get_cik(ticker: str, user_agent: str) -> Optional[str]:
    """Resolve a ticker symbol to a CIK number."""
    ticker_upper = ticker.upper()
    if ticker_upper in _cik_cache:
        return _cik_cache[ticker_upper]

    headers = {"User-Agent": user_agent}
    async with httpx.AsyncClient() as client:
        resp = await client.get(COMPANY_TICKERS_URL, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()

    for entry in data.values():
        if entry.get("ticker", "").upper() == ticker_upper:
            cik = str(entry["cik_str"])
            _cik_cache[ticker_upper] = cik
            return cik

    return None


async def _get_filing_list(
    cik: str, filing_type: str, user_agent: str
) -> list[dict]:
    """Get list of filings for a CIK from EDGAR submissions API."""
    cik_padded = cik.zfill(10)
    url = f"{EDGAR_BASE}/submissions/CIK{cik_padded}.json"
    headers = {"User-Agent": user_agent}

    async with httpx.AsyncClient() as client:
        resp = await client.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()

    recent = data.get("filings", {}).get("recent", {})
    forms = recent.get("form", [])
    dates = recent.get("filingDate", [])
    accessions = recent.get("accessionNumber", [])
    primary_docs = recent.get("primaryDocument", [])

    filings = []
    for i, form in enumerate(forms):
        if form == filing_type:
            filings.append({
                "form": form,
                "date": dates[i] if i < len(dates) else "",
                "accession": accessions[i] if i < len(accessions) else "",
                "primary_doc": primary_docs[i] if i < len(primary_docs) else "",
            })

    return filings


def _clean_html(html: str, max_chars: int = 80000) -> str:
    """Parse HTML filing and extract clean text."""
    soup = BeautifulSoup(html, "html.parser")

    # Remove script and style elements
    for tag in soup(["script", "style", "meta", "link"]):
        tag.decompose()

    text = soup.get_text(separator="\n")

    # Clean up whitespace
    lines = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            lines.append(line)

    result = "\n".join(lines)

    # Truncate if too long
    if len(result) > max_chars:
        result = result[:max_chars] + f"\n\n[Truncated at {max_chars} characters. Full filing available on EDGAR.]"

    return result


async def edgar_fetch_filing(
    ticker: str,
    filing_type: str = "10-K",
    year: Optional[int] = None,
    user_agent: str = "",
) -> str:
    """Fetch an SEC filing from EDGAR."""
    if not user_agent:
        return "SEC EDGAR requires a User-Agent string. Configure sec_user_agent in config.yaml."

    # Normalize filing type
    filing_type = filing_type.upper().strip()
    valid_types = ["10-K", "10-Q", "8-K", "DEF 14A", "S-1", "20-F"]
    if filing_type not in valid_types:
        return f"Unsupported filing type '{filing_type}'. Supported: {', '.join(valid_types)}"

    # Resolve ticker to CIK
    cik = await _get_cik(ticker, user_agent)
    if not cik:
        return f"Could not find CIK for ticker '{ticker}'. Verify the ticker symbol."

    # Get filing list
    filings = await _get_filing_list(cik, filing_type, user_agent)
    if not filings:
        return f"No {filing_type} filings found for {ticker}."

    # Filter by year if specified
    if year:
        year_str = str(year)
        filings = [f for f in filings if f["date"].startswith(year_str)]
        if not filings:
            return f"No {filing_type} filings found for {ticker} in {year}."

    # Take the most recent filing
    filing = filings[0]
    accession_clean = filing["accession"].replace("-", "")
    doc_url = f"{EDGAR_ARCHIVES}/{cik}/{accession_clean}/{filing['primary_doc']}"

    headers = {"User-Agent": user_agent}
    async with httpx.AsyncClient() as client:
        # Rate limit: small delay
        await asyncio.sleep(0.15)
        resp = await client.get(doc_url, headers=headers, timeout=30, follow_redirects=True)
        resp.raise_for_status()

    content_type = resp.headers.get("content-type", "")

    if "html" in content_type or "xml" in content_type or filing["primary_doc"].endswith(".htm"):
        text = _clean_html(resp.text)
    else:
        text = resp.text[:80000]

    header = (
        f"## {ticker} {filing_type} — Filed {filing['date']}\n"
        f"Source: {doc_url}\n\n"
    )
    return header + text


async def edgar_fetch_transcript(
    ticker: str,
    quarter: Optional[str] = None,
    user_agent: str = "",
    transcript_api: Optional[str] = None,
) -> str:
    """Fetch earnings transcript. Falls back to 8-K earnings press release."""
    # If a transcript API is configured, use it
    if transcript_api:
        return f"Transcript API configured but not yet implemented. API: {transcript_api}"

    if not user_agent:
        return "SEC EDGAR requires a User-Agent string. Configure sec_user_agent in config.yaml."

    # Fallback: get 8-K filings (earnings press releases)
    cik = await _get_cik(ticker, user_agent)
    if not cik:
        return f"Could not find CIK for ticker '{ticker}'."

    filings = await _get_filing_list(cik, "8-K", user_agent)
    if not filings:
        return f"No 8-K filings found for {ticker}."

    # Filter by quarter if specified (rough match on date)
    if quarter:
        # Parse quarter like "Q4 2025" or "Q1 2026"
        match = re.match(r"Q(\d)\s*(\d{4})", quarter, re.IGNORECASE)
        if match:
            q, yr = int(match.group(1)), match.group(2)
            # Map quarter to approximate month ranges
            q_months = {1: ("01", "04"), 2: ("04", "07"), 3: ("07", "10"), 4: ("10", "12")}
            start_m, end_m = q_months.get(q, ("01", "12"))
            filings = [
                f for f in filings
                if f["date"] >= f"{yr}-{start_m}" and f["date"] <= f"{yr}-{end_m}-31"
            ]

    if not filings:
        return f"No 8-K filings found for {ticker} matching '{quarter}'."

    # Get the most recent 8-K
    filing = filings[0]
    accession_clean = filing["accession"].replace("-", "")
    doc_url = f"{EDGAR_ARCHIVES}/{cik}/{accession_clean}/{filing['primary_doc']}"

    headers = {"User-Agent": user_agent}
    async with httpx.AsyncClient() as client:
        await asyncio.sleep(0.15)
        resp = await client.get(doc_url, headers=headers, timeout=30, follow_redirects=True)
        resp.raise_for_status()

    text = _clean_html(resp.text)

    header = (
        f"## {ticker} 8-K (Earnings Press Release) — Filed {filing['date']}\n"
        f"Source: {doc_url}\n"
        f"Note: Full earnings call transcript not available via EDGAR. "
        f"This is the earnings press release. Configure a transcript API "
        f"in config.yaml for full transcripts.\n\n"
    )
    return header + text
