"""Ravana CLI — sets up the analysis workspace."""

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


TEMPLATES_DIR = Path(__file__).parent / "templates"


def get_mcp_config_path():
    """Get the path to Claude Code's MCP config file."""
    home = Path.home()
    return home / ".claude" / "mcp.json"


def hide_file_windows(filepath):
    """Hide a file on Windows using attrib +h."""
    if platform.system() == "Windows":
        try:
            subprocess.run(
                ["attrib", "+h", str(filepath)],
                check=True,
                capture_output=True,
            )
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass


def copy_template(src_name, dest_path):
    """Copy a template file to the destination."""
    src = TEMPLATES_DIR / src_name
    if src.is_file():
        shutil.copy2(src, dest_path)
    elif src.is_dir():
        if dest_path.exists():
            shutil.rmtree(dest_path)
        shutil.copytree(src, dest_path)


def copy_skills(dest_skills_dir):
    """Copy all skill templates to the destination skills directory."""
    src_skills = TEMPLATES_DIR / "skills"
    if not src_skills.exists():
        return
    for skill_dir in src_skills.iterdir():
        if skill_dir.is_dir():
            dest = dest_skills_dir / skill_dir.name
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(skill_dir, dest)


def register_mcp_server(analysis_dir):
    """Register the Ravana MCP server in Claude Code's mcp.json."""
    mcp_config_path = get_mcp_config_path()

    # Read existing config or start fresh
    config = {}
    if mcp_config_path.exists():
        try:
            with open(mcp_config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except (json.JSONDecodeError, IOError):
            config = {}

    if "mcpServers" not in config:
        config["mcpServers"] = {}

    # Add/update ravana server
    config["mcpServers"]["ravana"] = {
        "command": "python",
        "args": ["-m", "ravana.server"],
        "cwd": str(analysis_dir),
    }

    # Write back
    mcp_config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(mcp_config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def init_workspace(target_dir=None):
    """Initialize the analysis workspace."""
    if target_dir is None:
        target_dir = Path.cwd() / "analysis"
    else:
        target_dir = Path(target_dir)

    # Create directory structure
    target_dir.mkdir(parents=True, exist_ok=True)
    (target_dir / "notes").mkdir(exist_ok=True)
    (target_dir / "estimates").mkdir(exist_ok=True)

    claude_dir = target_dir / ".claude"
    claude_dir.mkdir(exist_ok=True)
    (claude_dir / "tickers").mkdir(exist_ok=True)
    (claude_dir / "skills").mkdir(exist_ok=True)

    # Copy template files to root (hidden on Windows)
    for filename in ["CLAUDE.md", "config.yaml", "fund_profile.md"]:
        dest = target_dir / filename
        if not dest.exists():
            copy_template(filename, dest)
            hide_file_windows(dest)

    # Copy settings.json to .claude/
    settings_dest = claude_dir / "settings.json"
    if not settings_dest.exists():
        copy_template("settings.json", settings_dest)

    # Copy skills
    copy_skills(claude_dir / "skills")

    # Register MCP server
    register_mcp_server(target_dir.resolve())

    # Print success
    rel_path = os.path.relpath(target_dir)
    print("")
    print("  Ravana AI workspace created.")
    print("")
    print(f"  cd {rel_path}")
    print("  claude")
    print("")
    print("  Your workspace:")
    print("    notes/      -- drop PDFs, docs, research notes here")
    print("    estimates/  -- your model numbers (always override consensus)")
    print("")


def main():
    """CLI entry point."""
    args = sys.argv[1:]

    if not args or args[0] == "init":
        target = args[1] if len(args) > 1 else None
        init_workspace(target)
    elif args[0] == "--version":
        from ravana import __version__
        print(f"ravana {__version__}")
    elif args[0] == "--help":
        print("Usage: ravana init [directory]")
        print("")
        print("Commands:")
        print("  init    Create an analysis workspace (default: ./analysis)")
        print("")
        print("Options:")
        print("  --version  Show version")
        print("  --help     Show this help")
    else:
        print(f"Unknown command: {args[0]}")
        print("Run 'ravana --help' for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
