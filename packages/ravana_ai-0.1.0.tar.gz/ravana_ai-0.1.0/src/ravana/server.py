"""Ravana MCP Server — data tools for equity research."""

import os
from pathlib import Path

import yaml
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

# Load environment from cwd (the analysis workspace)
load_dotenv()

# Load config
config = {}
config_path = Path("config.yaml")
if config_path.exists():
    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

mcp = FastMCP("ravana")

# --- EDGAR Tools ---

from ravana.edgar import (
    edgar_fetch_filing,
    edgar_fetch_transcript,
)


@mcp.tool()
async def fetch_filing(
    ticker: str,
    filing_type: str = "10-K",
    year: int | None = None,
) -> str:
    """Fetch an SEC filing (10-K, 10-Q, 8-K) from EDGAR.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
        filing_type: Type of filing — 10-K, 10-Q, or 8-K
        year: Optional year to filter filings. Defaults to most recent.

    Returns:
        Filing text content organized by sections.
    """
    user_agent = config.get("sec_user_agent", os.getenv("SEC_USER_AGENT", ""))
    if not user_agent or user_agent == "YourName your@email.com":
        return (
            "SEC EDGAR requires a user agent string. "
            "Set sec_user_agent in config.yaml (e.g., 'YourName your@email.com')."
        )
    return await edgar_fetch_filing(ticker, filing_type, year, user_agent)


@mcp.tool()
async def fetch_transcript(
    ticker: str,
    quarter: str | None = None,
) -> str:
    """Fetch an earnings call transcript.

    Tries configured transcript sources first, falls back to 8-K
    earnings press release from EDGAR.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
        quarter: Optional quarter (e.g., 'Q4 2025'). Defaults to most recent.

    Returns:
        Transcript or earnings press release text.
    """
    user_agent = config.get("sec_user_agent", os.getenv("SEC_USER_AGENT", ""))
    transcript_api = config.get("data_sources", {}).get("transcript_api")
    return await edgar_fetch_transcript(ticker, quarter, user_agent, transcript_api)


# --- Scraper Tools ---

from ravana.scraper import scraper_fetch_page


@mcp.tool()
async def scrape_page(url: str) -> str:
    """Scrape a web page and extract text content.

    Useful for reading company IR pages, press releases, earnings decks,
    and other web-based documents.

    Args:
        url: The URL to scrape.

    Returns:
        Extracted text content from the page.
    """
    return await scraper_fetch_page(url)


# --- Database Tools ---

from ravana.db import (
    db_get_company_overview,
    db_get_estimates,
    db_get_financials,
    db_get_hf_ownership,
    db_get_insider_trades,
    db_get_peer_comp,
    db_get_valuation,
    db_screen_stocks,
)


@mcp.tool()
async def get_company_overview(ticker: str) -> str:
    """Get company profile, description, sector classification, and AI-generated
    business summaries from the database.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
    """
    return db_get_company_overview(ticker)


@mcp.tool()
async def get_financials(
    ticker: str,
    statement_type: str = "income",
    period_type: str = "quarterly",
    periods: int = 8,
) -> str:
    """Get financial statements (income, balance sheet, cash flow) from the database.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
        statement_type: One of 'income', 'balance_sheet', 'cashflow'
        period_type: 'annual' or 'quarterly'
        periods: Number of periods to return (default 8)
    """
    return db_get_financials(ticker, statement_type, period_type, periods)


@mcp.tool()
async def get_valuation(ticker: str) -> str:
    """Get current valuation metrics, price performance, and trailing ratios
    from the database.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
    """
    return db_get_valuation(ticker)


@mcp.tool()
async def get_estimates(ticker: str) -> str:
    """Get forward consensus analyst estimates and earnings calendar
    from the database.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
    """
    return db_get_estimates(ticker)


@mcp.tool()
async def get_hf_ownership(ticker: str) -> str:
    """Get hedge fund ownership summary, top holders, and recent position
    changes from the database.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
    """
    return db_get_hf_ownership(ticker)


@mcp.tool()
async def get_insider_trades(ticker: str, months: int = 6) -> str:
    """Get insider trading activity (buys and sells) from the database.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
        months: Number of months of history to return (default 6)
    """
    return db_get_insider_trades(ticker, months)


@mcp.tool()
async def get_peer_comp(
    ticker: str,
    peers: str | None = None,
) -> str:
    """Get peer comparison table with valuation metrics.

    If peers are not specified, auto-selects based on industry and market cap.

    Args:
        ticker: Stock ticker symbol (e.g., AAPL)
        peers: Optional comma-separated peer tickers (e.g., 'MSFT,GOOG,META')
    """
    peer_list = [p.strip().upper() for p in peers.split(",")] if peers else None
    return db_get_peer_comp(ticker, peer_list)


@mcp.tool()
async def screen_stocks(query: str) -> str:
    """Screen stocks using natural language criteria.

    Translates your query into database filters. Works best with specific
    criteria like sector, valuation ranges, growth rates, or ownership patterns.

    Examples:
        'cheap large-cap tech stocks'
        'stocks with insider buying in the last 3 months'
        'high-growth SaaS under 10x revenue'
        'names hedge funds are adding to'

    Args:
        query: Natural language screening criteria
    """
    return db_screen_stocks(query)


def main():
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
