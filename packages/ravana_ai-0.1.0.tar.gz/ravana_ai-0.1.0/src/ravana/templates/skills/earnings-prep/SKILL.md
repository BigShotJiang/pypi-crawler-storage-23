---
name: earnings-prep
description: Pre-earnings research preparation. Use when a stock is about to report earnings, or the PM asks to prep for an earnings call, or wants to know what to watch for on an upcoming report.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# Earnings Prep for $ARGUMENTS

[PLACEHOLDER -- Earnings prep workflow to be developed through interview with AJ]

This skill will contain:
- How to pull consensus estimates and recent guidance
- What to look for in the prior quarter's results and transcript
- Key debates and what the street is focused on
- How to structure the pre-earnings cheat sheet
- Potential reaction scenarios
- Instructions on using MCP tools for data
