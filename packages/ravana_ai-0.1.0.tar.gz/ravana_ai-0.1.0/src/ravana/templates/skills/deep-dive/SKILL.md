---
name: deep-dive
description: Focused deep dive on a specific aspect of a company. Use when the PM asks to dig into a particular transaction, business segment, risk factor, accounting issue, or financial structure. Not a full analysis -- a surgical investigation of one thing.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# Deep Dive on $ARGUMENTS

[PLACEHOLDER -- Deep dive workflow to be developed through interview with AJ]

This skill will contain:
- How to identify the specific topic to investigate
- How to find all available information on that specific thing
- When to pull filings/transcripts using MCP tools
- How to walk through mechanics with real numbers
- How to save findings to .claude/tickers/[SYMBOL]/deep_dive_[topic].md
