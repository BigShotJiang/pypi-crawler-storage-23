---
name: scrape-ir
description: Scrape a company's investor relations page for earnings releases, presentations, SEC filings, and other IR documents. Use when the PM asks to check an IR page, find an earnings deck, or pull documents from a company's website.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# Scrape IR Page for $ARGUMENTS

[PLACEHOLDER -- IR scraping workflow to be developed through interview with AJ]

This skill will contain:
- How to find the company's IR page URL
- How to use the scrape_page MCP tool to fetch content
- What to look for on IR pages (earnings releases, presentations, SEC filings)
- How to extract and organize the documents found
- How to save processed content to .claude/tickers/[SYMBOL]/
