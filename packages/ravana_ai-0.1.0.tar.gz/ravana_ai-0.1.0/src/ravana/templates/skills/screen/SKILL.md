---
name: screen
description: Stock screening and idea generation. Use when the PM asks to find stocks matching criteria, run a screen, generate ideas, or look for names in a sector or theme.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# Stock Screen for $ARGUMENTS

[PLACEHOLDER -- Screening workflow to be developed through interview with AJ]

This skill will contain:
- How to translate PM's natural language into screening criteria
- How to use screen_stocks MCP tool if database is available
- Fallback approach using web search when no database
- How to present screening results
- What follow-up to suggest on interesting names
