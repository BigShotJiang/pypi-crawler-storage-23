---
name: analyze
description: Full equity research workflow. Use when the PM asks to analyze a stock, dig into a name, evaluate a long or short thesis, or do due diligence on a ticker. Do NOT trigger for quick questions, simple data pulls, or concept explanations.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# Analyze $ARGUMENTS

[PLACEHOLDER -- Research protocol to be developed through interview with AJ]

This skill will contain:
- Phase 1: Situation scan (search for recent events, earnings, news, price action)
- Phase 2: Present findings with real numbers, propose threads to dig into
- Phase 3: Deep dive on confirmed threads (transcripts, filings, numbers)
- Phase 4: Synthesis (market pricing vs reality, comp table, scenario math)
- Idea type routing (compounder, value, growth, short variants, catalyst, thematic)
- Instructions on using MCP tools (fetch_filing, get_financials, etc.)
- How to save work to .claude/tickers/[SYMBOL]/
