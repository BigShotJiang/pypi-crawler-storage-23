---
name: one-pager
description: Generate a structured investment thesis one-pager for a stock. Use when the PM asks for a write-up, pitch, one-pager, or investment memo.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# One-Pager for $ARGUMENTS

[PLACEHOLDER -- One-pager workflow to be developed through interview with AJ]

For the template structure, see [template.md](template.md).

This skill will contain:
- Instructions to research the company thoroughly before writing
- How to fill each section of the template with real data
- When to check estimates/ for fund's own numbers
- How to handle the valuation section (relative, not DCF)
- How to save the output to .claude/tickers/[SYMBOL]/
