[PLACEHOLDER -- One-pager template to be developed through interview with AJ]

This template will define the exact sections and format of the fund's one-pager.
Sections discussed so far:
1. Company Overview
2. Thesis
3. Catalysts
4. Key Drivers
5. Recent Results
6. Valuation
7. Risks

The final structure and emphasis for each section will be determined
based on AJ's input about what actually matters at a real fund.
