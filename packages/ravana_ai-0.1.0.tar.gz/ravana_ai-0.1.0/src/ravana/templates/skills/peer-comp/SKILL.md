---
name: peer-comp
description: Build a relative valuation comparison table. Use when the PM asks to compare stocks, build a comp table, or evaluate relative valuation.
allowed-tools: Read, Write, Glob, Grep, WebSearch, WebFetch
---

# Peer Comparison for $ARGUMENTS

[PLACEHOLDER -- Peer comp workflow to be developed through interview with AJ]

This skill will contain:
- How to identify the right peer set
- How to determine the right valuation metric for the sector
- What columns belong in the comp table
- How to present the data without giving price targets
- Instructions on using get_peer_comp and get_valuation MCP tools
