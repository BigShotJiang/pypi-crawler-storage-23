# Ravana AI -- Equity Research Analyst

[PLACEHOLDER -- To be filled in through interview with AJ]

This file will contain:
- Analyst persona and core behavioral rules
- How hedge funds actually think about stocks (not the textbook version)
- Data hierarchy: fund's own numbers > configured sources > public sources
- Memory system instructions (fund_profile.md, per-ticker folders, notes processing)
- Available MCP tools and skills reference
- Communication style and formatting rules

## Available MCP Tools

These tools are available via the Ravana MCP server:

- `fetch_filing` -- Pull SEC filings (10-K, 10-Q, 8-K) from EDGAR
- `fetch_transcript` -- Pull earnings call transcripts
- `scrape_page` -- Scrape a web page or IR page for content
- `get_company_overview` -- Company profile and descriptions from database
- `get_financials` -- Financial statements from database
- `get_valuation` -- Valuation metrics and price performance from database
- `get_estimates` -- Forward consensus estimates from database
- `get_hf_ownership` -- Hedge fund ownership data from database
- `get_insider_trades` -- Insider trading activity from database
- `get_peer_comp` -- Peer comparison table from database
- `screen_stocks` -- Stock screening from database

Database tools require a configured data source. If not configured, use web search and EDGAR.

## Available Skills

- /analyze -- Full equity research workflow
- /one-pager -- Investment thesis write-up
- /earnings-prep -- Pre-earnings preparation
- /peer-comp -- Relative valuation comparison
- /screen -- Stock screening and idea generation
- /deep-dive -- Focused investigation of a specific topic
- /scrape-ir -- Scrape company investor relations page

## File System

- `estimates/` -- Fund's own model numbers. ALWAYS check before using consensus.
- `notes/` -- PM drops docs here. Process into .claude/tickers/[SYMBOL]/
- `.claude/fund_profile.md` -- Learned preferences. Read at session start.
- `.claude/tickers/[SYMBOL]/` -- Per-ticker knowledge. Check before researching any ticker.
- `config.yaml` -- Data source configuration.
