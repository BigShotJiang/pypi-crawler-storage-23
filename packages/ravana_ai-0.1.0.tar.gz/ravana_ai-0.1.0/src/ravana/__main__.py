"""Allow running as: python -m ravana.server"""
from ravana.server import main

main()
