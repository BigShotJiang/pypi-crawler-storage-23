"""Web/IR page scraper — extract text content from URLs."""

import httpx
from bs4 import BeautifulSoup


async def scraper_fetch_page(url: str) -> str:
    """Fetch a web page and extract text content."""
    if not url or not url.startswith(("http://", "https://")):
        return "Invalid URL. Provide a full URL starting with http:// or https://"

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
    }

    try:
        async with httpx.AsyncClient(follow_redirects=True) as client:
            resp = await client.get(url, headers=headers, timeout=20)
            resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        return f"HTTP error {e.response.status_code} fetching {url}"
    except httpx.RequestError as e:
        return f"Request error fetching {url}: {e}"

    content_type = resp.headers.get("content-type", "")

    # If it's a PDF, we can't parse it inline — note that
    if "pdf" in content_type.lower():
        return (
            f"URL points to a PDF file: {url}\n"
            f"Download the PDF and drop it in the notes/ folder for processing."
        )

    # Parse HTML
    soup = BeautifulSoup(resp.text, "html.parser")

    # Remove nav, header, footer, script, style
    for tag in soup(["script", "style", "nav", "header", "footer", "aside", "meta", "link"]):
        tag.decompose()

    # Try to find main content
    main = soup.find("main") or soup.find("article") or soup.find(id="content") or soup.body
    if main is None:
        main = soup

    text = main.get_text(separator="\n")

    # Clean up
    lines = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            lines.append(line)

    result = "\n".join(lines)

    # Find linked documents (PDFs, presentations)
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        link_text = a.get_text(strip=True)
        if any(ext in href.lower() for ext in [".pdf", ".pptx", ".xlsx", ".docx"]):
            # Make absolute URL if relative
            if href.startswith("/"):
                from urllib.parse import urlparse
                parsed = urlparse(url)
                href = f"{parsed.scheme}://{parsed.netloc}{href}"
            links.append(f"  - [{link_text}]({href})")

    # Truncate if too long
    max_chars = 50000
    if len(result) > max_chars:
        result = result[:max_chars] + f"\n\n[Truncated at {max_chars} characters]"

    output = f"## Content from {url}\n\n{result}"

    if links:
        output += "\n\n## Linked Documents Found\n" + "\n".join(links[:30])

    return output
