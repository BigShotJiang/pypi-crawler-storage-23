"""Database connector — queries AJ's Railway PostgreSQL (or any configured DB)."""

import os
from datetime import date, datetime, timedelta
from typing import Optional

import psycopg2
import psycopg2.extras

NOT_CONFIGURED = (
    "Database not configured. To use database tools, set DB_URL in your .env file "
    "or configure database_url in config.yaml under data_sources."
)


def _get_connection():
    """Get a database connection from DB_URL environment variable."""
    db_url = os.getenv("DB_URL")
    if not db_url:
        return None
    return psycopg2.connect(db_url)


def _format_number(n, prefix="$", decimals=1) -> str:
    """Format a number nicely: $4.1B, $523M, $12.3K, etc."""
    if n is None:
        return "N/A"
    n = float(n)
    if n < 0:
        return f"-{_format_number(-n, prefix, decimals)}"
    if n >= 1_000_000_000_000:
        return f"{prefix}{n / 1_000_000_000_000:.{decimals}f}T"
    if n >= 1_000_000_000:
        return f"{prefix}{n / 1_000_000_000:.{decimals}f}B"
    if n >= 1_000_000:
        return f"{prefix}{n / 1_000_000:.{decimals}f}M"
    if n >= 1_000:
        return f"{prefix}{n / 1_000:.{decimals}f}K"
    return f"{prefix}{n:.{decimals}f}"


def _format_pct(n) -> str:
    """Format as percentage (value already in percent form, e.g., 4.66 = 4.66%)."""
    if n is None:
        return "N/A"
    return f"{float(n):.1f}%"


def _format_pct_decimal(n) -> str:
    """Format decimal as percentage (e.g., 0.70 = 70.0%)."""
    if n is None:
        return "N/A"
    return f"{float(n) * 100:.1f}%"


def _format_ratio(n) -> str:
    """Format a ratio/multiple."""
    if n is None:
        return "N/A"
    return f"{float(n):.1f}x"


def _md_table(headers: list[str], rows: list[list]) -> str:
    """Build a markdown table."""
    if not rows:
        return "No data found."
    lines = ["| " + " | ".join(headers) + " |"]
    lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
    for row in rows:
        lines.append("| " + " | ".join(str(c) for c in row) + " |")
    return "\n".join(lines)


def _resolve_ticker_id(cur, ticker: str) -> Optional[int]:
    """Resolve ticker symbol to ticker_id."""
    cur.execute("SELECT id FROM dc_tickers WHERE symbol = %s", (ticker.upper(),))
    row = cur.fetchone()
    return row[0] if row else None


# --- Tool Implementations ---


def db_get_company_overview(ticker: str) -> str:
    """Get company profile and descriptions."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(
                """SELECT symbol, company_name, sector, industry,
                          aj_sector, aj_industry, aj_subindustry, archetype,
                          description, plain_english, what_it_is,
                          how_it_makes_money, who_buys, key_products,
                          market_cap, exchange, shares_outstanding, float_shares, beta
                   FROM dc_tickers WHERE symbol = %s""",
                (ticker.upper(),),
            )
            row = cur.fetchone()
            if not row:
                return f"Ticker '{ticker}' not found in database."

            lines = [
                f"## {row['symbol']} — {row['company_name']}",
                f"**Exchange:** {row['exchange']}",
                f"**Sector:** {row['sector']} | **Industry:** {row['industry']}",
            ]
            if row["aj_sector"]:
                lines.append(f"**Custom Sector:** {row['aj_sector']} | {row['aj_industry'] or ''} | {row['aj_subindustry'] or ''}")
            if row["archetype"]:
                lines.append(f"**Archetype:** {row['archetype']}")
            if row["market_cap"]:
                lines.append(f"**Market Cap:** {_format_number(row['market_cap'])}")
            if row["shares_outstanding"]:
                lines.append(f"**Shares Out:** {_format_number(row['shares_outstanding'], prefix='', decimals=0)}")
            if row["beta"]:
                lines.append(f"**Beta:** {row['beta']:.2f}")

            lines.append("")
            if row["plain_english"]:
                lines.append(f"**Plain English:** {row['plain_english']}")
            if row["what_it_is"]:
                lines.append(f"**What It Is:** {row['what_it_is']}")
            if row["how_it_makes_money"]:
                lines.append(f"**How It Makes Money:** {row['how_it_makes_money']}")
            if row["who_buys"]:
                lines.append(f"**Who Buys:** {row['who_buys']}")
            if row["key_products"]:
                lines.append(f"**Key Products:** {row['key_products']}")

            return "\n".join(lines)
    finally:
        conn.close()


def db_get_financials(
    ticker: str,
    statement_type: str = "income",
    period_type: str = "quarterly",
    periods: int = 8,
) -> str:
    """Get financial statements."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    # Normalize inputs
    st_map = {"income": "income", "balance_sheet": "balance_sheet", "balance": "balance_sheet", "cashflow": "cashflow", "cash_flow": "cashflow"}
    statement_type = st_map.get(statement_type.lower(), statement_type.lower())
    pt_map = {"annual": "annual", "quarterly": "quarter", "quarter": "quarter"}
    period_type_db = pt_map.get(period_type.lower(), period_type.lower())

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            tid = _resolve_ticker_id(cur, ticker)
            if not tid:
                return f"Ticker '{ticker}' not found in database."

            cur.execute(
                """SELECT period_end, revenue, gross_profit, operating_income,
                          ebitda, net_income, eps, eps_diluted, shares_outstanding,
                          total_assets, total_liabilities, total_equity,
                          cash, total_debt, net_debt,
                          operating_cash_flow, capex, free_cash_flow, dividends_paid
                   FROM dc_financials
                   WHERE ticker_id = %s AND statement_type = %s AND period_type = %s
                   ORDER BY period_end DESC
                   LIMIT %s""",
                (tid, statement_type, period_type_db, periods),
            )
            rows = cur.fetchall()
            if not rows:
                return f"No {statement_type} ({period_type}) data for {ticker}."

            # Build table based on statement type
            if statement_type == "income":
                headers = ["Period", "Revenue", "Gross Profit", "EBITDA", "Op. Income", "Net Income", "EPS"]
                table_rows = []
                for r in rows:
                    table_rows.append([
                        str(r["period_end"]),
                        _format_number(r["revenue"]),
                        _format_number(r["gross_profit"]),
                        _format_number(r["ebitda"]),
                        _format_number(r["operating_income"]),
                        _format_number(r["net_income"]),
                        f"${r['eps_diluted']:.2f}" if r["eps_diluted"] else "N/A",
                    ])
            elif statement_type == "balance_sheet":
                headers = ["Period", "Total Assets", "Total Liab.", "Equity", "Cash", "Total Debt", "Net Debt"]
                table_rows = []
                for r in rows:
                    table_rows.append([
                        str(r["period_end"]),
                        _format_number(r["total_assets"]),
                        _format_number(r["total_liabilities"]),
                        _format_number(r["total_equity"]),
                        _format_number(r["cash"]),
                        _format_number(r["total_debt"]),
                        _format_number(r["net_debt"]),
                    ])
            else:  # cashflow
                headers = ["Period", "Op. CF", "CapEx", "FCF", "Dividends"]
                table_rows = []
                for r in rows:
                    table_rows.append([
                        str(r["period_end"]),
                        _format_number(r["operating_cash_flow"]),
                        _format_number(r["capex"]),
                        _format_number(r["free_cash_flow"]),
                        _format_number(r["dividends_paid"]),
                    ])

            title = f"## {ticker} — {statement_type.replace('_', ' ').title()} ({period_type})\n\n"
            return title + _md_table(headers, table_rows)
    finally:
        conn.close()


def db_get_valuation(ticker: str) -> str:
    """Get valuation metrics and price performance."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            tid = _resolve_ticker_id(cur, ticker)
            if not tid:
                return f"Ticker '{ticker}' not found in database."

            # Calculated metrics
            cur.execute(
                """SELECT price, market_cap, ev, pe_ttm, pe_fwd,
                          ev_ebitda, ev_ebitda_fwd, ev_revenue, ev_revenue_fwd,
                          fcf_yield, ytd_pct, pct_from_52wk_high, pct_from_52wk_low
                   FROM dc_calculated_metrics WHERE ticker_id = %s""",
                (tid,),
            )
            metrics = cur.fetchone()

            # Price performance
            cur.execute(
                """SELECT change_1d_pct, change_5d_pct, change_1m_pct,
                          change_3m_pct, change_6m_pct, change_ytd_pct,
                          change_1y_pct, change_3y_pct
                   FROM dc_price_deltas WHERE ticker_id = %s""",
                (tid,),
            )
            deltas = cur.fetchone()

            # TTM ratios
            cur.execute(
                """SELECT gross_margin, operating_margin, net_margin,
                          roe, roa, roic, debt_to_equity, fcf_yield
                   FROM dc_ratios_ttm WHERE ticker_id = %s""",
                (tid,),
            )
            ratios = cur.fetchone()

            lines = [f"## {ticker} — Valuation & Performance\n"]

            if metrics:
                lines.append("### Valuation Metrics")
                lines.append(f"**Price:** ${float(metrics['price']):.2f}" if metrics["price"] else "")
                lines.append(f"**Market Cap:** {_format_number(metrics['market_cap'])}")
                lines.append(f"**EV:** {_format_number(metrics['ev'])}")
                lines.append("")
                val_headers = ["Metric", "Trailing", "Forward"]
                val_rows = [
                    ["P/E", _format_ratio(metrics["pe_ttm"]), _format_ratio(metrics["pe_fwd"])],
                    ["EV/EBITDA", _format_ratio(metrics["ev_ebitda"]), _format_ratio(metrics["ev_ebitda_fwd"])],
                    ["EV/Revenue", _format_ratio(metrics["ev_revenue"]), _format_ratio(metrics["ev_revenue_fwd"])],
                    ["FCF Yield", _format_pct(metrics["fcf_yield"]), "N/A"],
                ]
                lines.append(_md_table(val_headers, val_rows))
                lines.append("")
                lines.append(f"**52wk High:** {_format_pct(metrics['pct_from_52wk_high'])} from high")
                lines.append(f"**52wk Low:** {_format_pct(metrics['pct_from_52wk_low'])} from low")

            if deltas:
                lines.append("\n### Price Performance")
                perf_headers = ["1D", "5D", "1M", "3M", "6M", "YTD", "1Y", "3Y"]
                perf_row = [
                    _format_pct(deltas["change_1d_pct"]),
                    _format_pct(deltas["change_5d_pct"]),
                    _format_pct(deltas["change_1m_pct"]),
                    _format_pct(deltas["change_3m_pct"]),
                    _format_pct(deltas["change_6m_pct"]),
                    _format_pct(deltas["change_ytd_pct"]),
                    _format_pct(deltas["change_1y_pct"]),
                    _format_pct(deltas["change_3y_pct"]),
                ]
                lines.append(_md_table(perf_headers, [perf_row]))

            if ratios:
                lines.append("\n### Profitability & Returns (TTM)")
                ratio_headers = ["Metric", "Value"]
                ratio_rows = [
                    ["Gross Margin", _format_pct_decimal(ratios["gross_margin"])],
                    ["Op. Margin", _format_pct_decimal(ratios["operating_margin"])],
                    ["Net Margin", _format_pct_decimal(ratios["net_margin"])],
                    ["ROE", _format_pct_decimal(ratios["roe"])],
                    ["ROA", _format_pct_decimal(ratios["roa"])],
                    ["ROIC", _format_pct_decimal(ratios["roic"])],
                    ["D/E", _format_ratio(ratios["debt_to_equity"])],
                    ["FCF Yield", _format_pct_decimal(ratios["fcf_yield"])],
                ]
                lines.append(_md_table(ratio_headers, ratio_rows))

            return "\n".join(lines)
    finally:
        conn.close()


def db_get_estimates(ticker: str) -> str:
    """Get forward consensus estimates and earnings calendar."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            tid = _resolve_ticker_id(cur, ticker)
            if not tid:
                return f"Ticker '{ticker}' not found in database."

            # Forward estimates
            cur.execute(
                """SELECT period_end, revenue_avg, revenue_low, revenue_high,
                          ebitda_avg, eps_avg, eps_low, eps_high, num_analysts
                   FROM dc_analyst_estimates
                   WHERE ticker_id = %s
                   ORDER BY period_end""",
                (tid,),
            )
            estimates = cur.fetchall()

            # Earnings calendar
            cur.execute(
                """SELECT earnings_date, eps_estimate, eps_actual,
                          revenue_estimate, revenue_actual
                   FROM dc_earnings_calendar
                   WHERE ticker_id = %s
                   ORDER BY earnings_date DESC
                   LIMIT 8""",
                (tid,),
            )
            earnings = cur.fetchall()

            lines = [f"## {ticker} — Estimates & Earnings\n"]

            if estimates:
                lines.append("### Forward Consensus Estimates")
                est_headers = ["FY End", "Revenue", "Rev Range", "EBITDA", "EPS", "EPS Range", "# Analysts"]
                est_rows = []
                for e in estimates:
                    est_rows.append([
                        str(e["period_end"]),
                        _format_number(e["revenue_avg"]),
                        f"{_format_number(e['revenue_low'])} - {_format_number(e['revenue_high'])}",
                        _format_number(e["ebitda_avg"]),
                        f"${e['eps_avg']:.2f}" if e["eps_avg"] else "N/A",
                        f"${e['eps_low']:.2f} - ${e['eps_high']:.2f}" if e["eps_low"] else "N/A",
                        str(e["num_analysts"] or "N/A"),
                    ])
                lines.append(_md_table(est_headers, est_rows))

            if earnings:
                lines.append("\n### Earnings History")
                earn_headers = ["Date", "EPS Est", "EPS Act", "Beat/Miss", "Rev Est", "Rev Act"]
                earn_rows = []
                for e in earnings:
                    eps_bm = ""
                    if e["eps_estimate"] is not None and e["eps_actual"] is not None:
                        diff = float(e["eps_actual"]) - float(e["eps_estimate"])
                        eps_bm = f"+${diff:.2f}" if diff >= 0 else f"-${abs(diff):.2f}"

                    earn_rows.append([
                        str(e["earnings_date"]),
                        f"${e['eps_estimate']:.2f}" if e["eps_estimate"] else "N/A",
                        f"${e['eps_actual']:.2f}" if e["eps_actual"] else "N/A",
                        eps_bm or "N/A",
                        _format_number(e["revenue_estimate"]) if e["revenue_estimate"] else "N/A",
                        _format_number(e["revenue_actual"]) if e["revenue_actual"] else "N/A",
                    ])
                lines.append(_md_table(earn_headers, earn_rows))

            if not estimates and not earnings:
                lines.append("No estimate or earnings data available.")

            return "\n".join(lines)
    finally:
        conn.close()


def db_get_hf_ownership(ticker: str) -> str:
    """Get hedge fund ownership summary and top holders."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            tid = _resolve_ticker_id(cur, ticker)
            if not tid:
                return f"Ticker '{ticker}' not found in database."

            # Ownership summary
            cur.execute(
                """SELECT num_funds, num_funds_adding, num_funds_trimming,
                          num_funds_new, num_funds_exiting,
                          total_hf_value, is_hf_hotel, hf_hotel_score, top_holders
                   FROM dc_hf_ownership_summary WHERE ticker_id = %s""",
                (tid,),
            )
            summary = cur.fetchone()

            # Top individual holdings
            cur.execute(
                """SELECT f.short_name, h.shares, h.value, h.share_change,
                          h.change_pct, h.is_new, h.is_exit, h.pct_of_portfolio,
                          h.quarter
                   FROM dc_13f_holdings h
                   JOIN dc_funds f ON f.id = h.fund_id
                   WHERE h.ticker_id = %s
                   ORDER BY h.quarter DESC, h.value DESC
                   LIMIT 15""",
                (tid,),
            )
            holdings = cur.fetchall()

            lines = [f"## {ticker} — Hedge Fund Ownership\n"]

            if summary:
                lines.append("### Summary")
                lines.append(f"**Tracked Funds Holding:** {summary['num_funds']}")
                lines.append(f"**Adding:** {summary['num_funds_adding']} | **Trimming:** {summary['num_funds_trimming']}")
                lines.append(f"**New Positions:** {summary['num_funds_new']} | **Exiting:** {summary['num_funds_exiting']}")
                lines.append(f"**Total HF Value:** {_format_number(summary['total_hf_value'])}")
                if summary["is_hf_hotel"]:
                    lines.append(f"**HF Hotel:** YES (score: {summary['hf_hotel_score']})")
                if summary["top_holders"]:
                    lines.append(f"**Top Holders:** {', '.join(summary['top_holders'][:5])}")

            if holdings:
                lines.append("\n### Top Positions (Recent Quarter)")
                h_headers = ["Fund", "Value", "Shares", "Change", "% Chg", "% of Port", "Status"]
                h_rows = []
                for h in holdings:
                    status = ""
                    if h["is_new"]:
                        status = "NEW"
                    elif h["is_exit"]:
                        status = "EXIT"
                    h_rows.append([
                        h["short_name"] or "Unknown",
                        _format_number(h["value"] * 1000) if h["value"] else "N/A",  # value stored in thousands
                        _format_number(h["shares"], prefix="", decimals=0) if h["shares"] else "N/A",
                        _format_number(h["share_change"], prefix="", decimals=0) if h["share_change"] else "N/A",
                        _format_pct(h["change_pct"]),
                        _format_pct(h["pct_of_portfolio"]),
                        status,
                    ])
                lines.append(_md_table(h_headers, h_rows))

            if not summary and not holdings:
                lines.append("No hedge fund ownership data available.")

            return "\n".join(lines)
    finally:
        conn.close()


def db_get_insider_trades(ticker: str, months: int = 6) -> str:
    """Get insider trading activity."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            tid = _resolve_ticker_id(cur, ticker)
            if not tid:
                return f"Ticker '{ticker}' not found in database."

            cutoff = date.today() - timedelta(days=months * 30)
            cur.execute(
                """SELECT transaction_date, insider_name, insider_title,
                          transaction_type, shares_transacted, price, value
                   FROM dc_insider_trades
                   WHERE ticker_id = %s AND transaction_date >= %s
                   ORDER BY transaction_date DESC""",
                (tid, cutoff),
            )
            trades = cur.fetchall()

            if not trades:
                return f"No insider trades for {ticker} in the last {months} months."

            lines = [f"## {ticker} — Insider Trades (Last {months} Months)\n"]

            headers = ["Date", "Insider", "Title", "Type", "Shares", "Price", "Value"]
            rows = []
            for t in trades:
                tx_type = "BUY" if t["transaction_type"] == "P" else "SELL" if t["transaction_type"] == "S" else t["transaction_type"]
                rows.append([
                    str(t["transaction_date"]),
                    t["insider_name"] or "Unknown",
                    t["insider_title"] or "",
                    tx_type,
                    _format_number(t["shares_transacted"], prefix="", decimals=0),
                    f"${float(t['price']):.2f}" if t["price"] else "N/A",
                    _format_number(t["value"]),
                ])

            lines.append(_md_table(headers, rows))

            # Summary
            buys = [t for t in trades if t["transaction_type"] == "P"]
            sells = [t for t in trades if t["transaction_type"] == "S"]
            if buys:
                total_buy = sum(float(t["value"] or 0) for t in buys)
                lines.append(f"\n**Total Insider Buys:** {len(buys)} transactions, {_format_number(total_buy)}")
            if sells:
                total_sell = sum(float(t["value"] or 0) for t in sells)
                lines.append(f"**Total Insider Sells:** {len(sells)} transactions, {_format_number(total_sell)}")

            return "\n".join(lines)
    finally:
        conn.close()


def db_get_peer_comp(ticker: str, peers: Optional[list[str]] = None) -> str:
    """Get peer comparison table."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            tid = _resolve_ticker_id(cur, ticker)
            if not tid:
                return f"Ticker '{ticker}' not found in database."

            # If no peers specified, auto-select from same industry
            if not peers:
                cur.execute(
                    """SELECT aj_industry, industry, market_cap
                       FROM dc_tickers WHERE id = %s""",
                    (tid,),
                )
                info = cur.fetchone()
                industry = info["aj_industry"] or info["industry"]
                mkt_cap = info["market_cap"] or 0

                # Find peers in same industry, similar market cap
                cur.execute(
                    """SELECT t.symbol
                       FROM dc_tickers t
                       WHERE t.id != %s
                         AND (t.aj_industry = %s OR t.industry = %s)
                         AND t.is_active = true
                       ORDER BY ABS(COALESCE(t.market_cap, 0) - %s)
                       LIMIT 5""",
                    (tid, industry, industry, mkt_cap),
                )
                peers = [r["symbol"] for r in cur.fetchall()]

            if not peers:
                return f"Could not find peers for {ticker}."

            # Get all tickers including the target
            all_tickers = [ticker.upper()] + [p.upper() for p in peers]

            # Build comp table
            placeholders = ",".join(["%s"] * len(all_tickers))
            cur.execute(
                f"""SELECT t.symbol, t.company_name,
                           m.market_cap, m.pe_ttm, m.pe_fwd,
                           m.ev_ebitda, m.ev_ebitda_fwd,
                           m.ev_revenue, m.ev_revenue_fwd,
                           m.fcf_yield, m.ytd_pct
                    FROM dc_tickers t
                    JOIN dc_calculated_metrics m ON m.ticker_id = t.id
                    WHERE t.symbol IN ({placeholders})
                    ORDER BY CASE WHEN t.symbol = %s THEN 0 ELSE 1 END, m.market_cap DESC""",
                (*all_tickers, ticker.upper()),
            )
            comps = cur.fetchall()

            if not comps:
                return f"No valuation data available for {ticker} or its peers."

            lines = [f"## {ticker} — Peer Comparison\n"]

            headers = ["Ticker", "Name", "Mkt Cap", "P/E TTM", "P/E Fwd", "EV/EBITDA", "EV/EBITDA Fwd", "EV/Rev", "FCF Yld", "YTD"]
            rows = []
            for c in comps:
                name = c["company_name"]
                if name and len(name) > 25:
                    name = name[:22] + "..."
                rows.append([
                    c["symbol"],
                    name or "",
                    _format_number(c["market_cap"]),
                    _format_ratio(c["pe_ttm"]),
                    _format_ratio(c["pe_fwd"]),
                    _format_ratio(c["ev_ebitda"]),
                    _format_ratio(c["ev_ebitda_fwd"]),
                    _format_ratio(c["ev_revenue"]),
                    _format_pct(c["fcf_yield"]),
                    _format_pct(c["ytd_pct"]),
                ])

            lines.append(_md_table(headers, rows))
            return "\n".join(lines)
    finally:
        conn.close()


def db_screen_stocks(query: str) -> str:
    """Screen stocks using keyword-to-SQL mapping."""
    conn = _get_connection()
    if not conn:
        return NOT_CONFIGURED

    query_lower = query.lower()

    # Build WHERE clauses from keywords
    conditions = []
    joins = set()
    description_parts = []

    # Market cap filters
    if "large-cap" in query_lower or "large cap" in query_lower:
        conditions.append("m.market_cap > 10000000000")
        description_parts.append("large-cap (>$10B)")
    elif "mid-cap" in query_lower or "mid cap" in query_lower:
        conditions.append("m.market_cap BETWEEN 2000000000 AND 10000000000")
        description_parts.append("mid-cap ($2B-$10B)")
    elif "small-cap" in query_lower or "small cap" in query_lower:
        conditions.append("m.market_cap BETWEEN 300000000 AND 2000000000")
        description_parts.append("small-cap ($300M-$2B)")

    # Valuation filters
    if "cheap" in query_lower or "undervalued" in query_lower or "value" in query_lower:
        conditions.append("(m.pe_fwd < 15 OR m.ev_ebitda_fwd < 10)")
        description_parts.append("cheap (P/E fwd < 15 or EV/EBITDA fwd < 10)")
    if "high growth" in query_lower or "growth" in query_lower:
        joins.add("LEFT JOIN dc_growth g ON g.ticker_id = t.id AND g.period_end = (SELECT MAX(period_end) FROM dc_growth WHERE ticker_id = t.id)")
        conditions.append("g.revenue_growth > 15")
        description_parts.append("high growth (revenue growth > 15%)")

    # Sector filters
    sectors = {
        "tech": "Technology", "technology": "Technology",
        "healthcare": "Healthcare", "health": "Healthcare",
        "financials": "Financials", "financial": "Financials",
        "energy": "Energy",
        "consumer": "Consumer Cyclical",
        "industrial": "Industrials",
        "real estate": "Real Estate", "reit": "Real Estate",
    }
    for keyword, sector in sectors.items():
        if keyword in query_lower:
            conditions.append(f"(t.sector = '{sector}' OR t.aj_sector = '{sector}')")
            description_parts.append(f"sector: {sector}")
            break

    # HF ownership filters
    if "hedge fund" in query_lower or "hf" in query_lower:
        joins.add("LEFT JOIN dc_hf_ownership_summary hf ON hf.ticker_id = t.id")
        if "buying" in query_lower or "adding" in query_lower:
            conditions.append("hf.num_funds_adding > 2")
            description_parts.append("hedge funds adding (>2 funds)")
        elif "crowded" in query_lower or "hotel" in query_lower:
            conditions.append("hf.is_hf_hotel = true")
            description_parts.append("HF hotels")
        else:
            conditions.append("hf.num_funds > 5")
            description_parts.append("HF owned (>5 funds)")

    # Insider buying
    if "insider" in query_lower:
        joins.add("""LEFT JOIN (
            SELECT ticker_id, COUNT(*) as buy_count
            FROM dc_insider_trades
            WHERE transaction_type = 'P' AND transaction_date > CURRENT_DATE - INTERVAL '90 days'
            GROUP BY ticker_id
        ) ins ON ins.ticker_id = t.id""")
        conditions.append("ins.buy_count > 0")
        description_parts.append("insider buying (last 90 days)")

    # Default: must have data
    conditions.append("m.market_cap IS NOT NULL")
    conditions.append("t.is_active = true")

    where_clause = " AND ".join(conditions)
    join_clause = " ".join(joins)

    sql = f"""
        SELECT t.symbol, t.company_name, t.sector,
               m.market_cap, m.pe_fwd, m.ev_ebitda_fwd, m.fcf_yield, m.ytd_pct
        FROM dc_tickers t
        JOIN dc_calculated_metrics m ON m.ticker_id = t.id
        {join_clause}
        WHERE {where_clause}
        ORDER BY m.market_cap DESC
        LIMIT 25
    """

    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(sql)
            rows = cur.fetchall()

            if not rows:
                return f"No stocks matched your screen: {query}"

            lines = [f"## Stock Screen: {query}\n"]
            if description_parts:
                lines.append(f"**Filters applied:** {', '.join(description_parts)}\n")

            headers = ["Ticker", "Company", "Sector", "Mkt Cap", "P/E Fwd", "EV/EBITDA Fwd", "FCF Yld", "YTD"]
            table_rows = []
            for r in rows:
                name = r["company_name"]
                if name and len(name) > 30:
                    name = name[:27] + "..."
                table_rows.append([
                    r["symbol"],
                    name or "",
                    r["sector"] or "",
                    _format_number(r["market_cap"]),
                    _format_ratio(r["pe_fwd"]),
                    _format_ratio(r["ev_ebitda_fwd"]),
                    _format_pct(r["fcf_yield"]),
                    _format_pct(r["ytd_pct"]),
                ])

            lines.append(_md_table(headers, table_rows))
            lines.append(f"\n*{len(rows)} results*")
            return "\n".join(lines)
    finally:
        conn.close()
