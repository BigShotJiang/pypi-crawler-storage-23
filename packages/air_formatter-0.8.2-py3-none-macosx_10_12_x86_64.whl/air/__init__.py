# `__init__.py` is a build system requirement, but isn't used. This is a "data
# only" package, the air binary ends up in `.data/scripts/` in the wheel and is
# installed from there.
