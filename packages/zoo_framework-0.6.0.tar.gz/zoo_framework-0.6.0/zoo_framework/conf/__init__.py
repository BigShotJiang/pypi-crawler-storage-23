from zoo_framework.conf.log_config import log_config, log_config_instance

__all__ = ["log_config", "log_config_instance"]
