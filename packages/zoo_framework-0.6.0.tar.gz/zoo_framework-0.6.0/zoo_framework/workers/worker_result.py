class WorkerResult:
    def __init__(self, topic, content, cls_name):
        self.topic = topic
        self.content = content
        self.cls_name = cls_name
