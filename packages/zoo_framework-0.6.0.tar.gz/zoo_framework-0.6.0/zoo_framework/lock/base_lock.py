from multiprocessing import Lock


class BaseLock(Lock):
    pass
