"""Failure taxonomy framework for RL episode classification (pure Python)."""
from __future__ import annotations

import ast
import operator
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

__all__ = [
    "DEFAULT_SUCCESS_LABEL",
    "FailureRule",
    "FailureTaxonomy",
    "auto_failures",
    "detect_failure_in_context",
    "is_failure_outcome",
    "SafeExpressionError",
]

DEFAULT_SUCCESS_LABEL = "success"


class SafeExpressionError(Exception):
    """Raised when a failure rule expression is invalid or unsafe."""


# ---------------------------------------------------------------------------
# Safe expression evaluator using Python's ast module
# ---------------------------------------------------------------------------

_COMPARE_OPS = {
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
}

_BOOL_OPS = {
    ast.And: all,
    ast.Or: any,
}

_UNARY_OPS = {
    ast.USub: operator.neg,
    ast.Not: operator.not_,
}


def _compile_expression(expr: str) -> Callable[[dict], bool]:
    """Parse and compile a safe boolean expression."""
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise SafeExpressionError(f"Invalid expression syntax: {expr!r}") from e

    _validate_node(tree.body)
    return lambda ns: _eval_node(tree.body, ns)


def _validate_node(node: ast.AST) -> None:
    """Walk the AST and reject anything unsafe."""
    if isinstance(node, ast.Expression):
        _validate_node(node.body)
    elif isinstance(node, ast.BoolOp):
        for v in node.values:
            _validate_node(v)
    elif isinstance(node, ast.UnaryOp):
        if type(node.op) not in _UNARY_OPS:
            raise SafeExpressionError(f"Unsupported unary operator: {type(node.op).__name__}")
        _validate_node(node.operand)
    elif isinstance(node, ast.Compare):
        _validate_node(node.left)
        for op, comparator in zip(node.ops, node.comparators):
            if type(op) not in _COMPARE_OPS:
                raise SafeExpressionError(f"Unsupported comparison: {type(op).__name__}")
            _validate_node(comparator)
    elif isinstance(node, ast.BinOp):
        allowed = (ast.Add, ast.Sub, ast.Mult, ast.Div)
        if type(node.op) not in allowed:
            raise SafeExpressionError(f"Unsupported binary operator: {type(node.op).__name__}")
        _validate_node(node.left)
        _validate_node(node.right)
    elif isinstance(node, ast.Name):
        pass
    elif isinstance(node, ast.Constant):
        if not isinstance(node.value, (int, float, bool, type(None))):
            raise SafeExpressionError(f"Unsupported literal type: {type(node.value).__name__}")
    else:
        raise SafeExpressionError(
            f"Unsupported expression node: {type(node).__name__}. "
            "Only comparisons, and/or/not, variables, and numeric literals are allowed."
        )


_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}


def _eval_node(node: ast.AST, ns: dict) -> Any:
    """Evaluate a validated AST node against a namespace."""
    if isinstance(node, ast.BoolOp):
        fn = _BOOL_OPS[type(node.op)]
        return fn(_eval_node(v, ns) for v in node.values)

    if isinstance(node, ast.UnaryOp):
        operand = _eval_node(node.operand, ns)
        return _UNARY_OPS[type(node.op)](operand)

    if isinstance(node, ast.Compare):
        left = _eval_node(node.left, ns)
        for op, comparator in zip(node.ops, node.comparators):
            right = _eval_node(comparator, ns)
            if not _COMPARE_OPS[type(op)](left, right):
                return False
            left = right
        return True

    if isinstance(node, ast.BinOp):
        left = _eval_node(node.left, ns)
        right = _eval_node(node.right, ns)
        return _BIN_OPS[type(node.op)](left, right)

    if isinstance(node, ast.Name):
        if node.id not in ns:
            return 0.0
        return ns[node.id]

    if isinstance(node, ast.Constant):
        return node.value

    raise SafeExpressionError(f"Cannot evaluate node: {type(node).__name__}")


# ---------------------------------------------------------------------------
# FailureRule / FailureTaxonomy
# ---------------------------------------------------------------------------


@dataclass
class FailureRule:
    """A single failure detection rule."""

    name: str
    expression: str
    _compiled: Callable[[dict], bool] = field(repr=False, default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self._compiled is None:
            self._compiled = _compile_expression(self.expression)

    def evaluate(self, namespace: dict) -> bool:
        try:
            return bool(self._compiled(namespace))
        except Exception:
            return False


_BUILTIN_SUCCESS_OUTCOMES = frozenset({
    "success", "landed", "soft_landing", "completed", "solved",
    "running", "incomplete",
})


def is_failure_outcome(
    name: str | None,
    taxonomy: "FailureTaxonomy | None" = None,
) -> bool:
    if not name:
        return False
    if taxonomy is not None:
        return taxonomy.is_failure_outcome(name)
    return name not in _BUILTIN_SUCCESS_OUTCOMES


def detect_failure_in_context(
    ctx: dict | None,
    *,
    failure_keys: Sequence[str],
    metrics_key: str = "metrics",
    return_value: bool = False,
) -> Any:
    ctx = ctx or {}

    failures = ctx.get("failures")
    if failures and isinstance(failures, dict):
        for key in failure_keys:
            if key in failures:
                return key
        first = next(iter(failures), None)
        if first is not None:
            return first

    ft = ctx.get("failure_type")
    if ft and isinstance(ft, str):
        if not failure_keys or ft in failure_keys:
            return ft

    metrics = ctx.get(metrics_key, {}) or {}
    for key in failure_keys:
        if key in metrics and metrics[key] not in (None, False, 0, 0.0, "", "0"):
            return metrics[key] if return_value else key
        if key in ctx and ctx[key] not in (None, False, 0, 0.0, "", "0"):
            return ctx[key] if return_value else key
    return None


class FailureTaxonomy:
    """Container for user-defined failure and success rules."""

    def __init__(
        self,
        rules: dict[str, str],
        successes: dict[str, str] | None = None,
    ) -> None:
        self.rules: list[FailureRule] = []
        for name, expr in rules.items():
            self.rules.append(FailureRule(name=name, expression=expr))

        user_success_names: set[str] = set()
        if successes:
            for name, expr in successes.items():
                self.rules.append(FailureRule(name=name, expression=expr))
                user_success_names.add(name)

        self.success_outcomes: frozenset[str] = (
            _BUILTIN_SUCCESS_OUTCOMES | frozenset(user_success_names)
        )

    @property
    def failure_names(self) -> list[str]:
        return [r.name for r in self.rules if r.name not in self.success_outcomes]

    @property
    def success_names(self) -> list[str]:
        return [r.name for r in self.rules if r.name in self.success_outcomes]

    def is_failure_outcome(self, name: str) -> bool:
        return name not in self.success_outcomes

    def evaluate_step(
        self,
        *,
        obs: Any = None,
        reward: float = 0.0,
        metrics: dict[str, float] | None = None,
        done: bool = False,
        truncated: bool = False,
        episode_reward: float = 0.0,
        extra: dict[str, Any] | None = None,
    ) -> str | None:
        ns = self._build_namespace(
            obs=obs, reward=reward, metrics=metrics,
            done=done, truncated=truncated,
            episode_reward=episode_reward, extra=extra,
        )
        for rule in self.rules:
            if rule.evaluate(ns):
                return rule.name
        return None

    def evaluate_step_all(
        self,
        *,
        obs: Any = None,
        reward: float = 0.0,
        metrics: dict[str, float] | None = None,
        done: bool = False,
        truncated: bool = False,
        episode_reward: float = 0.0,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, dict]:
        ns = self._build_namespace(
            obs=obs, reward=reward, metrics=metrics,
            done=done, truncated=truncated,
            episode_reward=episode_reward, extra=extra,
        )
        matches: dict[str, dict] = {}
        for rule in self.rules:
            if rule.evaluate(ns):
                evidence = self._extract_evidence(rule, ns)
                matches[rule.name] = {"evidence": evidence}
        return matches

    def classify_episode(self, episode_steps: list[dict]) -> dict:
        episode_reward = 0.0
        first_failure: str | None = None
        trigger_step: int | None = None
        evidence: dict = {}
        all_failures: dict[str, dict] = {}

        for i, step_data in enumerate(episode_steps):
            reward = float(step_data.get("reward", 0.0))
            episode_reward += reward

            matches = self.evaluate_step_all(
                obs=step_data.get("obs"),
                reward=reward,
                metrics=step_data.get("metrics"),
                done=step_data.get("done", False),
                truncated=step_data.get("truncated", False),
                episode_reward=episode_reward,
                extra=step_data.get("extra"),
            )
            if matches:
                for name, detail in matches.items():
                    if name not in all_failures:
                        all_failures[name] = {"trigger_step": i, **detail}
                if first_failure is None:
                    first_failure = next(iter(matches))
                    trigger_step = i
                    evidence = matches[first_failure].get("evidence", {})

        return {
            "failure_type": first_failure,
            "trigger_step": trigger_step,
            "evidence": evidence,
            "all_failures": all_failures,
        }

    def _build_namespace(
        self,
        *,
        obs: Any,
        reward: float,
        metrics: dict[str, float] | None,
        done: bool,
        truncated: bool,
        episode_reward: float,
        extra: dict[str, Any] | None,
    ) -> dict[str, Any]:
        ns: dict[str, Any] = {
            "reward": reward,
            "done": done,
            "truncated": truncated,
            "episode_reward": episode_reward,
        }
        if metrics:
            ns.update(metrics)
        if isinstance(obs, dict):
            ns.update(obs)
        elif obs is not None:
            try:
                import numpy as np
                arr = np.asarray(obs).flatten()
                for i in range(min(len(arr), 32)):
                    ns[f"obs_{i}"] = float(arr[i])
            except Exception:
                pass
        if extra:
            ns.update(extra)
        return ns

    def _extract_evidence(self, rule: FailureRule, ns: dict) -> dict[str, Any]:
        try:
            tree = ast.parse(rule.expression, mode="eval")
            names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
            return {name: ns.get(name) for name in sorted(names) if name in ns}
        except Exception:
            return {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "rules": {r.name: r.expression for r in self.rules},
            "success_outcomes": sorted(
                name for name in self.success_outcomes
                if name not in _BUILTIN_SUCCESS_OUTCOMES
                or any(r.name == name for r in self.rules)
            ),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FailureTaxonomy":
        if "rules" in data and isinstance(data["rules"], dict):
            all_rules = data["rules"]
            success_names = set(data.get("success_outcomes", []))
            failures = {n: e for n, e in all_rules.items() if n not in success_names}
            successes = {n: e for n, e in all_rules.items() if n in success_names}
            return cls(failures, successes=successes or None)
        return cls(data)

    def __repr__(self) -> str:
        failure_str = ", ".join(
            f"{r.name!r}: {r.expression!r}" for r in self.rules
            if r.name not in self.success_outcomes
        )
        success_str = ", ".join(
            f"{r.name!r}: {r.expression!r}" for r in self.rules
            if r.name in self.success_outcomes
        )
        parts = [f"{{{failure_str}}}"]
        if success_str:
            parts.append(f"successes={{{success_str}}}")
        return f"FailureTaxonomy({', '.join(parts)})"


# ---------------------------------------------------------------------------
# Factory: auto_failures
# ---------------------------------------------------------------------------


def auto_failures(env) -> FailureTaxonomy:
    """Return a default FailureTaxonomy based on the environment."""
    from ._metrics import extract_env_id

    env_id = extract_env_id(env)

    if "LunarLander" in env_id:
        return FailureTaxonomy(
            {"crashed": "reward < -50 and done"},
            successes={"success": "reward > 100 and done"},
        )

    if "Ant" in env_id:
        return FailureTaxonomy({
            "fallen": "obs_0 < 0.2",
            "backward": "x_velocity < -0.1",
        })

    if "CartPole" in env_id:
        return FailureTaxonomy({
            "failed": "done and not truncated",
        })

    if "MountainCar" in env_id:
        return FailureTaxonomy(
            {"stuck": "truncated and episode_reward < -199"},
            successes={"reached_goal": "obs_0 > 0.5 and done"},
        )

    return FailureTaxonomy({
        "low_reward": "episode_reward < -1.0 and done",
    })
