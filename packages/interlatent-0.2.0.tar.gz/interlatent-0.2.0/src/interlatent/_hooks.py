"""PyTorch forward hooks for activation capture (lazy torch import)."""
from __future__ import annotations

import itertools
import weakref
from contextlib import AbstractContextManager
from typing import Any, Callable, Dict, List, Optional, Sequence

from ._schema import ActivationEvent


def _find_submodule(root, dotted: str):
    """Traverse a dotted attribute path to find a submodule."""
    mod = root
    for attr in dotted.split("."):
        mod = getattr(mod, attr, None)
        if mod is None:
            return None
    return mod


class StepAlignedHookCtx(AbstractContextManager):
    """Forward-hook context that uses an external step counter from context.

    All torch imports are deferred to method calls.
    """

    def __init__(
        self,
        model,
        *,
        context_supplier: Optional[Callable[[], Dict[str, Any]]] = None,
        layers: Sequence[str],
        db,
        run_id: str,
        max_channels: int | None = None,
        step_key: str = "step",
    ) -> None:
        self.model = model
        self.layers = list(layers)
        self.db = db
        self.run_id = run_id
        self.max_channels = max_channels
        self.step_key = step_key
        self._ctx_fn = context_supplier or (lambda: {})

        self._handles: List = []
        self._step_counter = itertools.count().__next__

        self._module_lookup: Dict[str, Any] = {}
        for name in self.layers:
            mod = _find_submodule(model, name)
            if mod is None:
                raise ValueError(f"Layer '{name}' not found in model")
            self._module_lookup[name] = mod

    def __enter__(self):
        for layer_name, module in self._module_lookup.items():
            handle = module.register_forward_hook(self._make_hook(layer_name))
            self._handles.append(handle)
        return self

    def __exit__(self, exc_type, exc, tb):
        for h in self._handles:
            h.remove()
        self._handles.clear()
        return False

    def _make_hook(self, layer_name: str):
        db_ref = weakref.ref(self.db)
        run_id = self.run_id
        max_channels = self.max_channels
        step_key = self.step_key
        step_counter = self._step_counter

        def _hook(module, inp, out):
            db = db_ref()
            if db is None:
                return

            tensor = out.detach().cpu()
            if tensor.ndim < 2:
                tensor = tensor.unsqueeze(1)
            B, C = tensor.shape[:2]
            if max_channels is not None:
                C = min(C, max_channels)
                tensor = tensor[:, :C]

            # Flatten to (B, C) — mean over spatial dims if any
            if tensor.ndim > 2:
                tensor = tensor.reshape(B, C, -1).mean(dim=-1)
            else:
                tensor = tensor.reshape(B, C)

            ctx_base = dict(self._ctx_fn())
            base_step = ctx_base.get(step_key)
            if base_step is None:
                base_step = step_counter()

            for b in range(B):
                step = base_step + b if B > 1 else base_step
                vec = tensor[b].float()
                ctx = dict(ctx_base)
                ctx[step_key] = step
                ev = ActivationEvent(
                    run_id=run_id,
                    step=int(step),
                    layer=layer_name,
                    channel=0,
                    tensor=vec.tolist(),
                    value_sum=float(vec.sum()),
                    value_sq_sum=float((vec**2).sum()),
                    context=ctx,
                )
                db.write_event(ev)

        return _hook
