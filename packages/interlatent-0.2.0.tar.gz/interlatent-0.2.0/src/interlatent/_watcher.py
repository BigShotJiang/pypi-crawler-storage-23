"""Passive forward-hook watcher for user-driven training loops."""
from __future__ import annotations

import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence

from ._db import CollectionDB
from ._failures import FailureTaxonomy
from ._hooks import StepAlignedHookCtx
from ._schema import ActivationEvent, RunInfo


def _obs_to_dict(obs) -> Dict[str, float]:
    """Convert a numpy/array observation to a named dict for storage."""
    if obs is None:
        return {}
    try:
        import numpy as np
        arr = np.asarray(obs).flatten()
        return {f"obs_{i}": float(arr[i]) for i in range(min(len(arr), 32))}
    except Exception:
        return {}


class Watcher:
    """Passive hook watcher driven by an external training loop.

    Hooks the model on ``start()`` and records activations into a ``CollectionDB``.
    The caller drives the training loop and calls ``tick()`` after each step.
    """

    def __init__(
        self,
        model,
        *,
        layers: Sequence[str],
        env_name: str,
        db: CollectionDB,
        metrics: List | None = None,
        taxonomy: FailureTaxonomy | None = None,
        context_fn: Callable[..., Dict[str, Any]] | None = None,
        max_channels: int | None = None,
        total_steps: int | None = None,
    ) -> None:
        self._model = model
        self._layers = list(layers)
        self._env_name = env_name
        self._db = db
        self._metrics = {m.name: m for m in (metrics or [])}
        self._taxonomy = taxonomy
        self._context_fn = context_fn
        self._max_channels = max_channels
        self._total_steps = total_steps

        self._run_id = str(uuid.uuid4())
        self._step = 0
        self._episode_id = 0
        self._episode_step = 0
        self._episode_reward_acc = 0.0

        # Mutable context dict shared with the hook's context_supplier
        self._step_ctx: Dict[str, Any] = {}

        self._hook_ctx: StepAlignedHookCtx | None = None
        self._started = False

        self._run_info = RunInfo(
            run_id=self._run_id,
            env_name=self._env_name,
        )

        # Pending contexts for batch update
        self._pending_contexts: Dict[int, Dict[str, Any]] = {}
        self._context_batch_size = 256

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def run_id(self) -> str:
        return self._run_id

    @property
    def start_time(self) -> str:
        return self._run_info.start_time

    @property
    def step(self) -> int:
        return self._step

    @property
    def db(self) -> CollectionDB:
        return self._db

    def start(self) -> "Watcher":
        """Register forward hooks on the model."""
        if self._started:
            return self

        # Unwrap SB3 wrapper
        root = getattr(self._model, "policy", self._model)

        self._hook_ctx = StepAlignedHookCtx(
            root,
            context_supplier=lambda: dict(self._step_ctx),
            layers=self._layers,
            db=self._db,
            run_id=self._run_id,
            max_channels=self._max_channels,
        )
        self._hook_ctx.__enter__()
        self._started = True
        return self

    def tick(
        self,
        *,
        obs=None,
        reward: float = 0.0,
        done: bool = False,
        truncated: bool = False,
        info: dict | None = None,
    ) -> None:
        """Called by the training loop after each env.step()."""
        # Compute metrics
        metric_vals: Dict[str, float | None] = {}
        for m in self._metrics.values():
            val = m.step(
                obs=obs, reward=reward, info=info,
                done=done, truncated=truncated,
            )
            metric_vals[m.name] = val

        # Accumulate episode reward for taxonomy
        self._episode_reward_acc += float(reward)

        # Evaluate failure taxonomy
        if self._taxonomy is not None:
            failure_matches = self._taxonomy.evaluate_step_all(
                obs=obs,
                reward=float(reward),
                metrics={k: v for k, v in metric_vals.items() if v is not None},
                done=done,
                truncated=truncated,
                episode_reward=self._episode_reward_acc,
            )
            failure_type = next(iter(failure_matches), None) if failure_matches else None
        else:
            failure_matches = {}
            failure_type = None

        # Build context for this step
        ctx: Dict[str, Any] = {
            "env_id": self._env_name,
            "episode_id": self._episode_id,
            "t": self._episode_step,
            "step": self._step,
            "reward": float(reward),
            "done": bool(done),
            "truncated": bool(truncated),
            "metrics": metric_vals,
            "observations": _obs_to_dict(obs),
        }

        if failure_type is not None:
            ctx["failure_type"] = failure_type
        if failure_matches:
            ctx["failures"] = failure_matches

        # User-supplied context extension
        if self._context_fn is not None:
            extra = self._context_fn(
                obs=obs, reward=reward, done=done,
                truncated=truncated, info=info,
            )
            if extra:
                ctx.update(extra)

        # Update mutable dict read by context_supplier on next forward pass
        self._step_ctx.clear()
        self._step_ctx.update(ctx)

        # Batch pending context updates
        self._pending_contexts[self._step] = ctx
        if len(self._pending_contexts) >= self._context_batch_size:
            self._flush_contexts()

        self._step += 1
        self._episode_step += 1

        # Handle episode boundaries
        if done or truncated:
            for m in self._metrics.values():
                m.reset()
            self._episode_id += 1
            self._episode_step = 0
            self._episode_reward_acc = 0.0

    def stop(self) -> None:
        """Remove hooks and flush remaining data."""
        if not self._started:
            return
        self._flush_contexts()
        if self._hook_ctx is not None:
            self._hook_ctx.__exit__(None, None, None)
            self._hook_ctx = None
        self._db.flush()
        self._started = False

    def close(self) -> None:
        """Stop and release resources."""
        self.stop()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _flush_contexts(self) -> None:
        if self._pending_contexts:
            self._db.update_step_contexts(
                run_id=self._run_id,
                contexts=dict(self._pending_contexts),
            )
            self._pending_contexts.clear()
