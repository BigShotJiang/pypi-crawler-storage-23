# Interlatent Python SDK

Official Python client for the [Interlatent](https://interlatent.dev) hosted API.

Browse environments, inspect runs, read latent activations, and view episode data from your RL interpretability dashboards.

## Install

```bash
pip install interlatent
```

## Quickstart

```python
from interlatent import Interlatent

client = Interlatent(
    base_url="https://interlatent.dev",
    api_key="sk-...",
)

# Browse
envs = client.environments.list()
runs = client.environments.runs("Ant-v5")

# Inspect
run = client.runs.retrieve("run_abc123")
latents = client.latents.list("run_abc123")
meta = client.episodes.meta("episode_id")
chunk = client.episodes.chunk("episode_id", 0)

# Upload
client.runs.create(run_id="new_run", environment="Ant-v5", layer="policy_net.2")
client.latents.create("new_run", latents=[{"latent_id": 0, "name": "hip torque"}])
client.checkpoints.create("new_run", report={"failure_summary": {}})
```

## Resources

| Resource | Methods |
|----------|---------|
| `client.index` | `retrieve()` |
| `client.environments` | `list()`, `runs(env_id)` |
| `client.runs` | `retrieve()`, `create()`, `update()`, `upload_urls()`, `upload_complete()` |
| `client.episodes` | `meta()`, `chunk()`, `frame()` |
| `client.latents` | `list()`, `retrieve()`, `create()` |
| `client.checkpoints` | `list()`, `retrieve()`, `create()` |
| `client.auth` | `login()` |
