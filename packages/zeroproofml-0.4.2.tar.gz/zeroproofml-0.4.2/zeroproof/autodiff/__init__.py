# Copyright (c) 2025 ZeroProof Team
# SPDX-License-Identifier: MIT

"""Autodiff scaffolding for Signed Common Meadows."""

from __future__ import annotations

__all__: list[str] = []
