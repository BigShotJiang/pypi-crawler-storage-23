# Copyright (c) 2025 ZeroProof Team
# SPDX-License-Identifier: MIT

"""Losses that separate finite vs. bottom regions in SCM decoding."""

from __future__ import annotations

import torch
from torch import Tensor


def scm_separation_losses(
    Q: Tensor,
    *,
    mask_censored: Tensor,
    tau_bot: float = 1e-2,
    tau_finite: float = 5e-2,
) -> tuple[Tensor, Tensor]:
    """Return (push_down_loss, push_up_loss) for denominator magnitudes.

    This creates a "no man's land" between censored/bottom and finite states by:
      - pushing censored samples toward |Q| <= tau_bot
      - pushing finite samples toward |Q| >= tau_finite

    Args:
        Q: Predicted denominators (any shape).
        mask_censored: Boolean mask selecting censored/⊥ targets (same shape as Q
            or broadcastable to it).
        tau_bot: Target ceiling for censored points.
        tau_finite: Target floor for finite points.
    """

    cens = mask_censored.to(torch.bool)
    q_abs = torch.abs(Q)

    push_down = torch.relu(q_abs - float(tau_bot)).pow(2)
    push_up = torch.relu(float(tau_finite) - q_abs).pow(2)

    if int(cens.sum().item()) > 0:
        loss_cens = push_down[cens].mean()
    else:
        loss_cens = torch.zeros((), device=Q.device, dtype=Q.dtype)

    fin = ~cens
    if int(fin.sum().item()) > 0:
        loss_fin = push_up[fin].mean()
    else:
        loss_fin = torch.zeros((), device=Q.device, dtype=Q.dtype)

    return loss_cens, loss_fin
