# Copyright (c) 2025 ZeroProof Team
# SPDX-License-Identifier: MIT

"""Training log hooks compatible with :class:`zeroproof.training.TrainingConfig`.

The core trainer accepts a ``log_hook(metrics)`` callable. This module provides
simple implementations that write JSONL or TensorBoard event logs.

Dependencies are optional and imported lazily:
  - JSONL logger: always available (standard library only).
  - TensorBoard logger: requires ``tensorboard``.
"""

from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Mapping

__all__ = ["JsonlLogger", "TensorBoardLogger", "read_jsonl", "jsonl_to_dataframe"]


def _is_torch_tensor(value: Any) -> bool:
    try:  # pragma: no cover - optional dependency
        import torch

        return isinstance(value, torch.Tensor)
    except Exception:  # pragma: no cover - defensive
        return False


def _to_jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value

    if _is_torch_tensor(value):  # pragma: no cover - optional dependency
        tensor = value.detach().cpu()
        if tensor.numel() == 1:
            return float(tensor.item())
        return tensor.tolist()

    if is_dataclass(value) and not isinstance(value, type):
        return {k: _to_jsonable(v) for k, v in asdict(value).items()}

    if isinstance(value, Mapping):
        return {str(k): _to_jsonable(v) for k, v in value.items()}

    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]

    if hasattr(value, "__float__"):
        try:
            return float(value)
        except Exception:
            pass

    return str(value)


class JsonlLogger:
    """Append metrics dictionaries to a JSONL file."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def __call__(self, metrics: Mapping[str, Any]) -> None:
        payload = {str(k): _to_jsonable(v) for k, v in metrics.items()}
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, sort_keys=True) + "\n")


class TensorBoardLogger:
    """Write scalar metrics to TensorBoard.

    Requires ``tensorboard``. Metrics are logged with an internal step counter.
    """

    def __init__(self, log_dir: str | Path, *, step_key: str | None = None) -> None:
        try:
            from torch.utils.tensorboard import SummaryWriter
        except ModuleNotFoundError as exc:  # pragma: no cover - optional dependency
            raise ModuleNotFoundError(
                "TensorBoard logging requires tensorboard (`pip install tensorboard`)."
            ) from exc

        self._writer = SummaryWriter(log_dir=str(log_dir))
        self._step = 0
        self._step_key = step_key

    def __call__(self, metrics: Mapping[str, Any]) -> None:
        step = None
        if self._step_key is not None and self._step_key in metrics:
            try:
                step = int(float(metrics[self._step_key]))
            except Exception:
                step = None

        if step is None:
            step = self._step
            self._step += 1

        for key, value in metrics.items():
            if key == self._step_key:
                continue
            if isinstance(value, (int, float)):
                self._writer.add_scalar(str(key), float(value), step)
                continue
            if _is_torch_tensor(value):  # pragma: no cover - optional dependency
                tensor = value.detach()
                if tensor.numel() == 1:
                    self._writer.add_scalar(str(key), float(tensor.item()), step)

        self._writer.flush()

    def close(self) -> None:
        self._writer.close()


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    """Read a JSONL metrics log into a list of dictionaries."""

    file_path = Path(path)
    records: list[dict[str, Any]] = []
    with file_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
    return records


def jsonl_to_dataframe(path: str | Path) -> Any:
    """Load a JSONL log as a pandas DataFrame.

    Requires ``pandas`` (install via ``pip install pandas`` or the package's optional
    extras if provided).
    """

    try:
        import pandas as pd
    except ModuleNotFoundError as exc:  # pragma: no cover - optional dependency
        raise ModuleNotFoundError(
            "Loading JSONL logs as a DataFrame requires pandas (`pip install pandas`)."
        ) from exc

    return pd.DataFrame.from_records(read_jsonl(path))
