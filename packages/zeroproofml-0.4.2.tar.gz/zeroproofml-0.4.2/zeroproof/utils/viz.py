# Copyright (c) 2025 ZeroProof Team
# SPDX-License-Identifier: MIT

"""Lightweight visualization helpers for SCM masks and denominators.

This module keeps imports optional: heavy plotting dependencies are imported
inside functions so the base install does not require matplotlib.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

__all__ = [
    "plot_mask_rates",
    "plot_denominator_hist",
    "plot_2d_mask_map",
    "plot_eval_log",
]


def _import_numpy() -> Any:
    try:
        import numpy as np
    except ModuleNotFoundError as exc:  # pragma: no cover - optional dependency
        raise ModuleNotFoundError(
            "zeroproof.utils.viz requires NumPy (`pip install numpy`)."
        ) from exc
    return np


def _import_pyplot() -> Any:
    try:
        import matplotlib.pyplot as plt
    except ModuleNotFoundError as exc:  # pragma: no cover - optional dependency
        raise ModuleNotFoundError(
            "zeroproof.utils.viz requires matplotlib (`pip install matplotlib`)."
        ) from exc
    return plt


def _is_torch_tensor(x: Any) -> bool:
    try:  # pragma: no cover - optional dependency
        import torch

        return isinstance(x, torch.Tensor)
    except Exception:  # pragma: no cover - defensive
        return False


def _to_numpy(x: Any) -> Any:
    np = _import_numpy()
    if _is_torch_tensor(x):  # pragma: no cover - optional dependency
        return x.detach().cpu().numpy()
    return np.asarray(x)


def plot_mask_rates(
    bottom_mask: Any,
    gap_mask: Any | None = None,
    *,
    ax: Any | None = None,
) -> tuple[dict[str, float | None], Any]:
    """Plot basic rates for bottom/gap masks."""

    np = _import_numpy()
    plt = _import_pyplot()

    bottom = _to_numpy(bottom_mask).astype(bool).reshape(-1)
    gap = _to_numpy(gap_mask).astype(bool).reshape(-1) if gap_mask is not None else None

    total = float(bottom.size) if bottom.size else 0.0
    bottom_frac = float(np.mean(bottom)) if total else float("nan")
    finite_frac = float(1.0 - bottom_frac) if total else float("nan")
    gap_frac = float(np.mean(gap)) if (gap is not None and gap.size) else None

    labels = ["finite", "bottom"]
    values = [finite_frac, bottom_frac]
    if gap_frac is not None:
        labels.append("gap")
        values.append(gap_frac)

    if ax is None:
        _, ax = plt.subplots()
    ax.bar(labels, values)
    ax.set_ylim(0.0, 1.0)
    ax.set_ylabel("Fraction")
    ax.set_title("Mask rates")

    summary = {"finite_frac": finite_frac, "bottom_frac": bottom_frac, "gap_frac": gap_frac}
    return summary, ax


def plot_denominator_hist(
    denominator: Any,
    tau_infer: float,
    tau_train: float | None = None,
    *,
    bins: int = 50,
    ax: Any | None = None,
) -> Any:
    """Plot a histogram of ``|D|`` and overlay threshold lines."""

    np = _import_numpy()
    plt = _import_pyplot()

    denom = _to_numpy(denominator).reshape(-1)
    denom_abs = np.abs(denom).astype(float)

    if ax is None:
        _, ax = plt.subplots()

    ax.hist(denom_abs, bins=bins, color="tab:blue", alpha=0.7)
    ax.axvline(float(tau_infer), color="tab:red", linestyle="--", label="tau_infer")
    if tau_train is not None:
        ax.axvline(float(tau_train), color="tab:orange", linestyle="--", label="tau_train")
    ax.set_xlabel("|D|")
    ax.set_ylabel("Count")
    ax.set_title("Denominator magnitude")
    ax.legend()
    return ax


def plot_2d_mask_map(
    xy: Any,
    bottom_mask: Any,
    gap_mask: Any | None = None,
    *,
    ax: Any | None = None,
    s: float = 10.0,
) -> Any:
    """Scatter plot of 2D points colored by bottom/gap masks."""

    np = _import_numpy()
    plt = _import_pyplot()

    pts = _to_numpy(xy)
    pts = np.asarray(pts, dtype=float)
    if pts.ndim != 2 or pts.shape[1] != 2:
        raise ValueError("xy must have shape (N, 2)")

    bottom = _to_numpy(bottom_mask).astype(bool).reshape(-1)
    if bottom.shape[0] != pts.shape[0]:
        raise ValueError("bottom_mask must have length N")

    gap = None
    if gap_mask is not None:
        gap = _to_numpy(gap_mask).astype(bool).reshape(-1)
        if gap.shape[0] != pts.shape[0]:
            raise ValueError("gap_mask must have length N")

    finite = ~bottom

    if ax is None:
        _, ax = plt.subplots()

    ax.scatter(pts[finite, 0], pts[finite, 1], s=s, c="tab:blue", alpha=0.6, label="finite")
    ax.scatter(pts[bottom, 0], pts[bottom, 1], s=s, c="tab:red", alpha=0.8, label="bottom")
    if gap is not None and gap.any():
        ax.scatter(pts[gap, 0], pts[gap, 1], s=s, c="tab:orange", alpha=0.8, label="gap")

    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_title("Mask map")
    ax.legend()
    return ax


def _load_records(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []

    if text[0] in "[{":
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            payload = None

        if isinstance(payload, list):
            return [r for r in payload if isinstance(r, dict)]
        if isinstance(payload, dict):
            if isinstance(payload.get("records"), list):
                return [r for r in payload["records"] if isinstance(r, dict)]
            return [payload]

    records: list[dict[str, Any]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        obj = json.loads(line)
        if isinstance(obj, dict):
            records.append(obj)
    return records


def plot_eval_log(
    path: str | Path = "evaluation_log.json",
    *,
    keys: Iterable[str] | None = None,
    ax: Any | None = None,
) -> Any:
    """Plot selected numeric metrics from an evaluation log JSON/JSONL file."""

    np = _import_numpy()
    plt = _import_pyplot()

    log_path = Path(path)
    records = _load_records(log_path)
    if not records:
        raise ValueError(f"No records found in {log_path}")

    if ax is None:
        _, ax = plt.subplots()

    x_key = "step" if "step" in records[0] else ("epoch" if "epoch" in records[0] else None)
    x = [r.get(x_key) for r in records] if x_key else list(range(len(records)))

    if keys is None:
        preferred = ("loss", "coverage", "mse", "mae")
        keys = [k for k in preferred if any(k in r for r in records)]
        if not keys:
            numeric_keys: list[str] = []
            for r in records:
                for k, v in r.items():
                    if k in (x_key or "",):
                        continue
                    if isinstance(v, (int, float)) and k not in numeric_keys:
                        numeric_keys.append(k)
            keys = numeric_keys[:6]

    for k in keys:
        y = [r.get(k) for r in records]
        y = np.asarray(y, dtype=float)
        ax.plot(x, y, label=str(k))

    ax.set_xlabel(x_key or "index")
    ax.set_ylabel("value")
    ax.set_title(f"Evaluation log: {log_path.name}")
    ax.legend()
    return ax
