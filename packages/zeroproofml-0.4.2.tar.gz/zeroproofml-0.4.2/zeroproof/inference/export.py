# Copyright (c) 2025 ZeroProof Team
# SPDX-License-Identifier: MIT

"""Export helpers for SCM inference graphs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn

from .mode import InferenceConfig

__all__ = ["script_module", "export_onnx_model", "export_bundle"]


def script_module(model: nn.Module) -> torch.jit.ScriptModule:
    """Script a model for TorchScript deployment.

    The wrapper simply delegates to :func:`torch.jit.script` after forcing
    evaluation mode so that :class:`~zeroproof.inference.mode.SCMInferenceWrapper`
    instances emit strict SCM outputs.
    """

    model.eval()
    return torch.jit.script(model)


def export_onnx_model(
    model: nn.Module,
    example_inputs: tuple[Any, ...],
    output_path: str,
    *,
    opset: int = 17,
    dynamic_axes: dict[str, dict[int, str]] | None = None,
    input_names: list[str] | None = None,
    output_names: list[str] | None = None,
) -> None:
    """Export a model to ONNX in inference mode.

    Parameters
    ----------
    model:
        The model to export. Should already encode strict SCM behavior
        (e.g., via :class:`~zeroproof.inference.mode.SCMInferenceWrapper`).
    example_inputs:
        Example inputs used for tracing shapes.
    output_path:
        Destination filepath for the ONNX graph.
    opset:
        ONNX opset version. Defaults to 17 to match current PyTorch
        defaults while remaining compatible with most runtimes.
    dynamic_axes:
        Optional dynamic axes mapping passed to :func:`torch.onnx.export`.
    input_names:
        Optional input names passed to :func:`torch.onnx.export`.
    output_names:
        Optional output names passed to :func:`torch.onnx.export`.
    """

    model.eval()
    torch.onnx.export(
        model,
        example_inputs,
        output_path,
        opset_version=opset,
        training=torch.onnx.TrainingMode.EVAL,
        dynamic_axes=dynamic_axes,
        input_names=input_names,
        output_names=output_names,
    )


def _flatten_tree(value: Any) -> list[Any]:
    if isinstance(value, (tuple, list)):
        flattened: list[Any] = []
        for item in value:
            flattened.extend(_flatten_tree(item))
        return flattened
    return [value]


def export_bundle(
    model: nn.Module,
    example_inputs: tuple[Any, ...],
    out_dir: str | Path,
    *,
    config: InferenceConfig | None = None,
    opset: int = 17,
    dynamic_axes: dict[str, dict[int, str]] | None = None,
    input_names: list[str] | None = None,
    output_names: list[str] | None = None,
) -> dict[str, Any]:
    """Export an ONNX model plus a small metadata JSON sidecar.

    The bundle format is intentionally lightweight:

    - ``model.onnx``: exported ONNX graph (in eval mode).
    - ``metadata.json``: machine-readable export metadata for deployment.

    Parameters
    ----------
    model:
        The model to export. Should already encode strict SCM behavior in
        evaluation mode (e.g. via :class:`~zeroproof.inference.mode.SCMInferenceWrapper`).
    example_inputs:
        Example inputs used for tracing shapes.
    out_dir:
        Output directory for the bundle files.
    config:
        Optional inference configuration to record in metadata. When omitted
        and the model exposes ``tau_infer`` / ``tau_train`` attributes, the
        values are inferred from the model; otherwise defaults are recorded.
    opset:
        ONNX opset version for export.
    dynamic_axes:
        Optional dynamic axes mapping passed to the ONNX exporter. When omitted,
        axis 0 is marked as ``"batch"`` for tensor inputs/outputs with at least
        one dimension.
    input_names, output_names:
        Optional stable names for ONNX inputs/outputs. When omitted, names are
        generated from the flattened tensor inputs/outputs.

    Returns
    -------
    dict
        The written metadata dictionary.
    """

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    onnx_path = out_path / "model.onnx"
    metadata_path = out_path / "metadata.json"

    cfg = config
    config_source = "argument"
    if cfg is None:
        tau_infer = getattr(model, "tau_infer", None)
        if tau_infer is not None:
            tau_train_val = getattr(model, "tau_train", None)
            use_gap = bool(getattr(model, "use_gap", False))
            tau_train = float(tau_train_val) if (use_gap and tau_train_val is not None) else None
            cfg = InferenceConfig(tau_infer=float(tau_infer), tau_train=tau_train)
            config_source = "model"
        else:
            cfg = InferenceConfig()
            config_source = "default"

    tensor_inputs = [t for t in _flatten_tree(example_inputs) if isinstance(t, torch.Tensor)]
    if input_names is None:
        input_names = [f"input_{i}" for i in range(len(tensor_inputs))]

    output = None
    with torch.no_grad():
        output = model(*example_inputs)

    tensor_outputs = [t for t in _flatten_tree(output) if isinstance(t, torch.Tensor)]
    if output_names is None:
        if hasattr(output, "_fields"):  # NamedTuple
            output_names = list(getattr(output, "_fields"))
        else:
            output_names = [f"output_{i}" for i in range(len(tensor_outputs))]

    if dynamic_axes is None:
        dynamic_axes = {}
        for name, tensor in zip(input_names, tensor_inputs):
            if tensor.dim() > 0:
                dynamic_axes[name] = {0: "batch"}
        for name, tensor in zip(output_names, tensor_outputs):
            if tensor.dim() > 0:
                dynamic_axes[name] = {0: "batch"}

    export_onnx_model(
        model,
        example_inputs,
        str(onnx_path),
        opset=opset,
        dynamic_axes=dynamic_axes,
        input_names=input_names,
        output_names=output_names,
    )

    metadata: dict[str, Any] = {
        "format": "zeroproofml_export_bundle",
        "format_version": 1,
        "model_file": onnx_path.name,
        "opset": int(opset),
        "input_names": input_names,
        "output_names": output_names,
        "scm_decoding_mode": "strict",
        "tau_infer": float(cfg.tau_infer),
        "tau_train": None if cfg.tau_train is None else float(cfg.tau_train),
        "config_source": config_source,
    }

    metadata_path.write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return metadata
