# Copyright (c) 2025 ZeroProof Team
# SPDX-License-Identifier: MIT

"""ZeroProofML v0.4 Signed Common Meadow package.

This release resets the public surface around the Signed Common Meadows
(SCM) stack (see ``docs/``). Legacy Transreal/wheel-era
materials live under ``examples/archive_tr`` for historical reference and
are intentionally not importable as part of the v0.4 public API.
"""

from __future__ import annotations

__all__ = [
    "__version__",
]

__version__ = "0.4.2"
