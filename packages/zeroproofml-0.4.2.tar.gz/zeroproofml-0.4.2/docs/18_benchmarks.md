# Benchmarks

This page summarizes the benchmark utilities for the SCM stack.

## Parity Runner (Coverage vs Accuracy)

Runs a small synthetic regression task and writes a coverage/accuracy curve:

```bash
python benchmarks/parity_runner.py --output benchmark_results
```

Outputs:
- `benchmark_results/parity_report.json`
- `benchmark_results/coverage_accuracy.png`

## Performance Suite

Runs SCM microbenchmarks (arithmetic, layer forward/backward, inference-gap thresholds, etc.) and saves a timestamped JSON artifact:

```bash
python benchmarks/run_benchmarks.py --suite all --output benchmark_results
```

Output: `benchmark_results/benchmarks_<timestamp>.json`

## CI Regression Gate

Validates a benchmark artifact directory/JSON and fails fast on malformed entries or obviously slow results:

```bash
python scripts/ci/benchmark_gate.py benchmark_results
```

## Baseline Artifact (Optional)

Copies the newest benchmark JSON in a results directory to `benchmarks/baseline.json`:

```bash
python scripts/update_benchmark_baseline.py --src benchmark_results
```
