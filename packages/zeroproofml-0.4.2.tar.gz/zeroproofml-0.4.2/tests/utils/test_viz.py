import json

import pytest

np = pytest.importorskip("numpy")
matplotlib = pytest.importorskip("matplotlib")
matplotlib.use("Agg")

from zeroproof.utils.viz import (
    plot_2d_mask_map,
    plot_denominator_hist,
    plot_eval_log,
    plot_mask_rates,
)


def test_viz_helpers_run_on_minimal_examples(tmp_path):
    bottom = np.array([False, True, False, False])
    gap = np.array([False, False, True, False])

    summary, ax = plot_mask_rates(bottom, gap)
    assert "bottom_frac" in summary
    assert ax is not None

    denom = np.array([1.0, 1e-6, 1e-3, 10.0])
    ax = plot_denominator_hist(denom, tau_infer=1e-4, tau_train=1e-3)
    assert ax is not None

    xy = np.array([[0.0, 0.0], [1.0, 0.0], [0.2, 0.3], [-1.0, 0.5]])
    ax = plot_2d_mask_map(xy, bottom, gap)
    assert ax is not None

    log_path = tmp_path / "evaluation_log.json"
    log_path.write_text(
        "\n".join(
            json.dumps({"step": i, "loss": float(i), "coverage": 1.0 - 0.1 * i}) for i in range(3)
        )
        + "\n",
        encoding="utf-8",
    )
    ax = plot_eval_log(log_path, keys=("loss", "coverage"))
    assert ax is not None
