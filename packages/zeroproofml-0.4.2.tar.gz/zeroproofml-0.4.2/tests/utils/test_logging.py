import pytest

from zeroproof.utils.logging import JsonlLogger, jsonl_to_dataframe, read_jsonl


def test_read_jsonl_roundtrip(tmp_path):
    path = tmp_path / "metrics.jsonl"
    logger = JsonlLogger(path)
    logger({"loss": 1.0, "coverage": 0.5})
    logger({"loss": 2.0, "coverage": 0.75, "meta": {"run": 1}})

    records = read_jsonl(path)

    assert len(records) == 2
    assert records[0]["loss"] == 1.0
    assert records[1]["meta"]["run"] == 1


def test_jsonl_to_dataframe_optional_dependency(tmp_path):
    path = tmp_path / "metrics.jsonl"
    JsonlLogger(path)({"loss": 1.0, "coverage": 0.5})

    try:
        import pandas  # type: ignore[import-not-found]  # noqa: F401
    except ModuleNotFoundError:
        with pytest.raises(ModuleNotFoundError):
            jsonl_to_dataframe(path)
    else:
        df = jsonl_to_dataframe(path)
        assert "loss" in df.columns
