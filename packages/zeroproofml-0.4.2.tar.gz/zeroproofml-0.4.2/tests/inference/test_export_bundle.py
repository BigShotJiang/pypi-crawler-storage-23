import json
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
from torch import nn

from zeroproof.inference import InferenceConfig, SCMInferenceWrapper, export_bundle


class TupleModel(nn.Module):
    def forward(self, x):  # pragma: no cover - simple wiring
        return x + 1, x


def test_export_bundle_writes_files_and_metadata(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    captured: dict[str, object] = {}

    def fake_export(_model, _args, output_path, **kwargs):  # type: ignore[no-untyped-def]
        Path(output_path).write_bytes(b"onnx")
        captured.update(kwargs)

    monkeypatch.setattr(torch.onnx, "export", fake_export)

    model = SCMInferenceWrapper(
        TupleModel(), config=InferenceConfig(tau_infer=1e-4, tau_train=1e-3)
    )
    model.eval()
    x = torch.randn(4, 3)

    metadata = export_bundle(model, (x,), tmp_path)

    assert (tmp_path / "model.onnx").read_bytes() == b"onnx"

    raw = json.loads((tmp_path / "metadata.json").read_text(encoding="utf-8"))
    assert raw == metadata

    assert raw["opset"] == 17
    assert raw["scm_decoding_mode"] == "strict"
    assert raw["tau_infer"] == pytest.approx(1e-4)
    assert raw["tau_train"] == pytest.approx(1e-3)
    assert raw["output_names"] == ["decoded", "bottom_mask", "gap_mask"]

    assert captured["input_names"] == raw["input_names"]
    assert captured["output_names"] == raw["output_names"]
    assert "dynamic_axes" in captured


def test_export_bundle_can_be_loaded_with_onnx_if_available(tmp_path: Path) -> None:
    onnx = pytest.importorskip("onnx")

    model = SCMInferenceWrapper(
        TupleModel(), config=InferenceConfig(tau_infer=1e-4, tau_train=1e-3)
    )
    model.eval()
    x = torch.randn(2, 3)

    export_bundle(model, (x,), tmp_path)

    onnx_model = onnx.load(str(tmp_path / "model.onnx"))
    onnx.checker.check_model(onnx_model)
