"""Robotics dataset generators and experiment scripts.

Note: some scripts in this folder are legacy (TR-era) and are only exercised
when running optional evidence paths (e.g. `--include-3r` / `--include-6r`) in
`scripts/run_paper_suite.py`.
"""

