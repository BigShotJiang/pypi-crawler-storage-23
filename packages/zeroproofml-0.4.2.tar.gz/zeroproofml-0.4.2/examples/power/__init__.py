"""Power-domain examples (Phase 13)."""

