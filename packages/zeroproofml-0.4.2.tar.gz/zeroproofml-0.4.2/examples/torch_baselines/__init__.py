"""Torch-first baselines for Phase 12 paper suite.

These are intended to replace the legacy TRNode/Python-loop baselines for
scientifically accurate (implementation-parity) comparisons against SCM.
"""

