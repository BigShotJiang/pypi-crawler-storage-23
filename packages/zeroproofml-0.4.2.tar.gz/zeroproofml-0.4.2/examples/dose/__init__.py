"""Synthetic dose–response (censored potency) benchmark."""

