from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import torch
from torch import Tensor


@dataclass(frozen=True)
class DoseDataConfig:
    seed: int = 0
    n_train: int = 200_000
    n_val: int = 20_000
    n_test: int = 30_000

    # Assay window.
    c_min: float = 1e-9
    c_max: float = 1e-5
    n_points: int = 10

    # Regime thresholds (truth):
    # saturated/below if IC50 < c_min/10
    # inactive/above if IC50 > c_max*10
    below_factor: float = 0.1
    above_factor: float = 10.0

    # Hill parameters.
    hill_min: float = 0.8
    hill_max: float = 1.5
    emin_mean: float = 0.0
    emin_std: float = 0.02
    emax_mean: float = 1.0
    emax_std: float = 0.02
    null_effect_rate: float = 0.10

    # Observation noise.
    noise_std: float = 0.05

    # Train/test stratification.
    # Values are fractions and will be normalized.
    frac_below: float = 1.0
    frac_in_range: float = 1.0
    frac_above: float = 1.0

    dtype: str = "float64"


def log10_grid(c_min: float, c_max: float, n: int, *, device: str = "cpu", dtype: torch.dtype) -> Tensor:
    log_c = torch.linspace(float(torch.log10(torch.tensor(c_min))), float(torch.log10(torch.tensor(c_max))), int(n))
    return log_c.to(device=device, dtype=dtype)


def hill_response(
    c: Tensor,
    *,
    ic50: Tensor,
    h: Tensor,
    e_min: Tensor,
    e_max: Tensor,
) -> Tensor:
    # E(C) = Emin + (Emax - Emin) / (1 + (C/IC50)^h)
    ratio = (c / ic50).clamp(min=torch.finfo(c.dtype).tiny)
    denom = 1.0 + torch.pow(ratio, h)
    return e_min + (e_max - e_min) / denom


def _regime_thresholds(cfg: DoseDataConfig) -> Tuple[float, float]:
    c_low = float(cfg.c_min) * float(cfg.below_factor)
    c_high = float(cfg.c_max) * float(cfg.above_factor)
    return float(torch.log10(torch.tensor(c_low)).item()), float(torch.log10(torch.tensor(c_high)).item())


def _sample_regime_log_ic50(
    g: torch.Generator, cfg: DoseDataConfig, regime: int, *, dtype: torch.dtype
) -> Tensor:
    # regimes: 0=below/saturated, 1=in-range, 2=above/inactive
    log_below, log_above = _regime_thresholds(cfg)
    if regime == 0:
        lo, hi = log_below - 3.0, log_below - 0.2
    elif regime == 1:
        # Keep in-range inside the assay window for identifiability.
        lo, hi = float(torch.log10(torch.tensor(cfg.c_min)).item()) + 0.2, float(
            torch.log10(torch.tensor(cfg.c_max)).item()
        ) - 0.2
    elif regime == 2:
        lo, hi = log_above + 0.2, log_above + 3.0
    else:
        raise ValueError("regime must be 0 (below), 1 (in-range), or 2 (above)")
    u = torch.rand((), generator=g, dtype=dtype)
    return lo + (hi - lo) * u


def _sample_emins_emaxs(
    g: torch.Generator, n: int, cfg: DoseDataConfig, *, dtype: torch.dtype
) -> Tuple[Tensor, Tensor, Tensor]:
    e_min = cfg.emin_mean + cfg.emin_std * torch.randn((n,), generator=g, dtype=dtype)
    e_max = cfg.emax_mean + cfg.emax_std * torch.randn((n,), generator=g, dtype=dtype)
    is_null = torch.rand((n,), generator=g, dtype=dtype) < float(cfg.null_effect_rate)
    if is_null.any():
        # Flat line: set Emax ≈ Emin
        jitter = 0.01 * torch.randn((int(is_null.sum().item()),), generator=g, dtype=dtype)
        e_max = e_max.clone()
        e_max[is_null] = e_min[is_null] + jitter
    return e_min, e_max, is_null


def _targets_for_regime(
    log_ic50: Tensor, cfg: DoseDataConfig, regime: int, *, is_null: bool
) -> Tuple[float, float, float]:
    # Returns (y_clamped, y_n, y_d) in log10 space.
    # Clamping baseline uses assay window edges (log10(C_min), log10(C_max)).
    log_c_min = float(torch.log10(torch.tensor(cfg.c_min)).item())
    log_c_max = float(torch.log10(torch.tensor(cfg.c_max)).item())

    if is_null:
        # Treat null-effect curves as inactive / above.
        return log_c_max, 1.0, 0.0

    if regime == 1:
        return float(log_ic50.item()), float(log_ic50.item()), 1.0
    if regime == 2:
        return log_c_max, 1.0, 0.0
    if regime == 0:
        return log_c_min, -1.0, 0.0
    raise ValueError("regime must be 0,1,2")


def make_split(cfg: DoseDataConfig, *, n: int) -> Tuple[Tensor, Tensor]:
    """Return (x, y) tensors.

    x: shape (N, 2*n_points): flattened (logC_i, E_i) pairs.
    y: shape (N, 5): [log_ic50, class_id, clamped_target, y_n, y_d]
    """

    dtype = torch.float64 if cfg.dtype == "float64" else torch.float32
    g = torch.Generator(device="cpu")
    g.manual_seed(int(cfg.seed) + 17_000_003 + int(n))

    log_c = log10_grid(cfg.c_min, cfg.c_max, cfg.n_points, dtype=dtype)
    c = torch.pow(torch.full_like(log_c, 10.0), log_c)

    # Stratified by regime.
    w = torch.tensor([cfg.frac_below, cfg.frac_in_range, cfg.frac_above], dtype=dtype)
    w = w / w.sum()
    regime = torch.multinomial(w, int(n), replacement=True, generator=g).to(torch.int64)
    # regime: id per sample (0=below, 1=in-range, 2=above)

    e_min, e_max, is_null = _sample_emins_emaxs(g, int(n), cfg, dtype=dtype)
    h = cfg.hill_min + (cfg.hill_max - cfg.hill_min) * torch.rand((int(n),), generator=g, dtype=dtype)

    # Sample log(IC50) for each regime.
    log_below, log_above = _regime_thresholds(cfg)
    log_c_min = float(torch.log10(torch.tensor(cfg.c_min)).item())
    log_c_max = float(torch.log10(torch.tensor(cfg.c_max)).item())

    lo_map = torch.tensor([log_below - 3.0, log_c_min + 0.2, log_above + 0.2], dtype=dtype)
    hi_map = torch.tensor([log_below - 0.2, log_c_max - 0.2, log_above + 3.0], dtype=dtype)
    u = torch.rand((int(n),), generator=g, dtype=dtype)
    lo = lo_map[regime]
    hi = hi_map[regime]
    log_ic50 = lo + (hi - lo) * u

    # Null-effect curves are treated as above/inactive, but we keep the sampled log(IC50)
    # for consistency with the original scalar loop implementation.
    class_id = regime.clone()
    class_id = torch.where(is_null, torch.full_like(class_id, 2), class_id).to(torch.int64)

    # Targets: (y_clamped, y_n, y_d) in log10 space.
    clamped = torch.where(
        class_id == 0,
        torch.full((int(n),), log_c_min, dtype=dtype),
        torch.where(class_id == 2, torch.full((int(n),), log_c_max, dtype=dtype), log_ic50),
    )
    y_d = torch.where(class_id == 1, torch.ones((int(n),), dtype=dtype), torch.zeros((int(n),), dtype=dtype))
    y_n = torch.where(
        class_id == 1,
        log_ic50,
        torch.where(class_id == 0, torch.full((int(n),), -1.0, dtype=dtype), torch.full((int(n),), 1.0, dtype=dtype)),
    )

    ic50 = torch.pow(torch.full_like(log_ic50, 10.0), log_ic50)
    # Broadcast concentrations: (N, K)
    cc = c.unsqueeze(0).expand(int(n), int(cfg.n_points))
    ic50_b = ic50.unsqueeze(-1)
    h_b = h.unsqueeze(-1)
    e_min_b = e_min.unsqueeze(-1)
    e_max_b = e_max.unsqueeze(-1)
    e = hill_response(cc, ic50=ic50_b, h=h_b, e_min=e_min_b, e_max=e_max_b)

    noise = float(cfg.noise_std) * torch.randn(e.shape, generator=g, dtype=dtype)
    e_obs = e + noise

    # Features: interleave logC and E(C).
    log_c_b = log_c.unsqueeze(0).expand_as(e_obs)
    x = torch.stack([log_c_b, e_obs], dim=-1).reshape(int(n), int(cfg.n_points) * 2)
    y = torch.stack(
        [
            log_ic50,
            class_id.to(dtype=dtype),
            clamped,
            y_n,
            y_d,
        ],
        dim=-1,
    )
    return x.to(torch.float32), y.to(torch.float32)


class DoseDataset(torch.utils.data.Dataset[Tuple[Tensor, Tensor]]):
    def __init__(self, x: Tensor, y: Tensor) -> None:
        super().__init__()
        if x.shape[0] != y.shape[0]:
            raise ValueError("x and y must have same first dimension")
        self.x = x
        self.y = y

    def __len__(self) -> int:
        return int(self.x.shape[0])

    def __getitem__(self, idx: int) -> Tuple[Tensor, Tensor]:
        return self.x[idx], self.y[idx]


def make_dose_splits(cfg: DoseDataConfig) -> Tuple[DoseDataset, DoseDataset, DoseDataset, Tensor]:
    x_tr, y_tr = make_split(cfg, n=int(cfg.n_train))
    x_va, y_va = make_split(DoseDataConfig(**{**cfg.__dict__, "seed": int(cfg.seed) + 1}), n=int(cfg.n_val))
    # Test uses explicit stratification as specified: 33/33/33 by default
    test_cfg = DoseDataConfig(**{**cfg.__dict__, "seed": int(cfg.seed) + 2, "frac_below": 1, "frac_in_range": 1, "frac_above": 1})
    x_te, y_te = make_split(test_cfg, n=int(cfg.n_test))
    log_c = log10_grid(cfg.c_min, cfg.c_max, cfg.n_points, dtype=torch.float64)
    return DoseDataset(x_tr, y_tr), DoseDataset(x_va, y_va), DoseDataset(x_te, y_te), log_c
