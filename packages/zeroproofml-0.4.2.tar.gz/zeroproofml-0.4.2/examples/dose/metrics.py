from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import torch
from torch import Tensor


def macro_f1(y_true: Tensor, y_pred: Tensor, n_classes: int = 3) -> Tuple[float, Dict[str, float]]:
    y_true = y_true.to(torch.int64).flatten()
    y_pred = y_pred.to(torch.int64).flatten()
    per: Dict[str, float] = {}
    f1s = []
    for c in range(int(n_classes)):
        tp = int(((y_true == c) & (y_pred == c)).sum().item())
        fp = int(((y_true != c) & (y_pred == c)).sum().item())
        fn = int(((y_true == c) & (y_pred != c)).sum().item())
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = (2 * prec * rec / (prec + rec)) if (prec + rec) else 0.0
        per[f"f1_c{c}"] = float(f1)
        per[f"prec_c{c}"] = float(prec)
        per[f"rec_c{c}"] = float(rec)
        f1s.append(f1)
    return float(sum(f1s) / max(1, len(f1s))), per


@dataclass(frozen=True)
class DoseEvalConfig:
    log_below_thr: float
    log_above_thr: float


def classify_from_scalar(y_hat: Tensor, cfg: DoseEvalConfig) -> Tensor:
    below = y_hat < float(cfg.log_below_thr)
    above = y_hat > float(cfg.log_above_thr)
    return torch.where(below, torch.zeros_like(y_hat, dtype=torch.int64), torch.where(above, torch.full_like(y_hat, 2, dtype=torch.int64), torch.ones_like(y_hat, dtype=torch.int64)))


def boundary_metrics(y_true_cls: Tensor, y_pred_cls: Tensor) -> Dict[str, float]:
    # "Resolvable" = class 1. Censored = {0,2}.
    y_true_cls = y_true_cls.to(torch.int64)
    y_pred_cls = y_pred_cls.to(torch.int64)
    true_in = y_true_cls == 1
    true_cens = ~true_in
    pred_in = y_pred_cls == 1
    pred_cens = ~pred_in
    fn = float((true_in & pred_cens).float().mean().item())
    fp = float((true_cens & pred_in).float().mean().item())
    return {"false_censored_rate_on_in_range": fn, "false_in_range_rate_on_censored": fp}


def finite_mae(y_true_log: Tensor, y_pred_log: Tensor, y_true_cls: Tensor, y_pred_cls: Tensor) -> float:
    y_true_cls = y_true_cls.to(torch.int64)
    y_pred_cls = y_pred_cls.to(torch.int64)
    m = (y_true_cls == 1) & (y_pred_cls == 1) & torch.isfinite(y_pred_log) & torch.isfinite(y_true_log)
    if int(m.sum().item()) == 0:
        return float("nan")
    return float((y_pred_log[m] - y_true_log[m]).abs().mean().item())

