from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
from torch import Tensor

from zeroproof.autodiff.projective import renormalize
from zeroproof.layers.projective_rational import ProjectiveRationalMultiHead


def _mlp(in_dim: int, hidden_dims: tuple[int, ...], activation: str) -> nn.Sequential:
    act: nn.Module
    if activation == "relu":
        act = nn.ReLU()
    elif activation == "silu":
        act = nn.SiLU()
    else:
        raise ValueError("activation must be 'relu' or 'silu'")
    layers: list[nn.Module] = []
    prev = int(in_dim)
    for h in hidden_dims:
        layers.append(nn.Linear(prev, int(h)))
        layers.append(act)
        prev = int(h)
    return nn.Sequential(*layers)


@dataclass(frozen=True)
class ClampedMLPConfig:
    input_dim: int = 20
    hidden_dims: tuple[int, ...] = (256, 256, 256, 256)
    activation: str = "silu"


class ClampedMLP(nn.Module):
    def __init__(self, cfg: ClampedMLPConfig) -> None:
        super().__init__()
        self.backbone = _mlp(int(cfg.input_dim), cfg.hidden_dims, str(cfg.activation))
        last_dim = int(cfg.hidden_dims[-1]) if cfg.hidden_dims else int(cfg.input_dim)
        self.head = nn.Linear(last_dim, 1)

    def forward(self, x: Tensor) -> Tensor:
        h = self.backbone(x)
        return self.head(h).squeeze(-1)


@dataclass(frozen=True)
class TwoStageConfig:
    input_dim: int = 20
    hidden_dims: tuple[int, ...] = (256, 256, 256, 256)
    activation: str = "silu"
    lambda_reg: float = 1.0


class TwoStageDoseNet(nn.Module):
    def __init__(self, cfg: TwoStageConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.backbone = _mlp(int(cfg.input_dim), cfg.hidden_dims, str(cfg.activation))
        last_dim = int(cfg.hidden_dims[-1]) if cfg.hidden_dims else int(cfg.input_dim)
        self.classifier = nn.Linear(last_dim, 3)
        self.regressor = nn.Linear(last_dim, 1)

    def forward(self, x: Tensor) -> tuple[Tensor, Tensor]:
        h = self.backbone(x)
        logits = self.classifier(h)
        reg = self.regressor(h).squeeze(-1)
        return logits, reg


@dataclass(frozen=True)
class DoseProjectiveConfig:
    input_dim: int = 20
    hidden_dims: tuple[int, ...] = (64, 64)
    activation: str = "relu"
    numerator_degree: int = 3
    denominator_degree: int = 2
    q_anchor: str = "none"  # allow Q -> 0 for censored points
    gamma: float = 1e-9
    detach_renorm: bool = True
    q_init_scale: float = 1e-2
    aux_num_classes: int = 0  # 0 disables auxiliary classifier head
    dir_num_classes: int = 0  # 0 disables auxiliary censored-direction head
    dir_detach_backbone: bool = False  # if True, dir head does not backprop into backbone
    tau_infer: float = 1e-6
    tau_train: float = 1e-4


class DoseProjectiveSCMNet(nn.Module):
    """Single-head projective rational model for censored potency.

    Forward returns renormalized tuples (P, Q) for loss computation.
    """

    def __init__(self, cfg: DoseProjectiveConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.backbone = _mlp(int(cfg.input_dim), cfg.hidden_dims, str(cfg.activation))
        last_dim = int(cfg.hidden_dims[-1]) if cfg.hidden_dims else int(cfg.input_dim)
        self.feat = nn.Linear(last_dim, 2)  # [z_den, z_num]
        self.aux_classifier: nn.Linear | None = None
        if int(cfg.aux_num_classes) > 0:
            self.aux_classifier = nn.Linear(last_dim, int(cfg.aux_num_classes))
        self.dir_classifier: nn.Linear | None = None
        if int(cfg.dir_num_classes) > 0:
            self.dir_classifier = nn.Linear(last_dim, int(cfg.dir_num_classes))
        self.head = ProjectiveRationalMultiHead(
            output_dim=1,
            numerator_degree=int(cfg.numerator_degree),
            denominator_degree=int(cfg.denominator_degree),
            q_anchor=str(cfg.q_anchor),
            q_param="none",
            q_min=0.0,
        )
        if str(cfg.q_anchor) == "none" and float(cfg.q_init_scale) != 1.0:
            # "Shock" initialization: start close to Q≈0 so the model begins in the
            # censored hypothesis and learns to separate finite vs. ⊥ regions.
            with torch.no_grad():
                self.head.den_weights.mul_(float(cfg.q_init_scale))
                self.feat.weight[0].mul_(float(cfg.q_init_scale))
                if self.feat.bias is not None:
                    self.feat.bias[0].zero_()

    @property
    def tau_infer(self) -> float:
        return float(self.cfg.tau_infer)

    @property
    def tau_train(self) -> float:
        return float(self.cfg.tau_train)

    def forward(
        self,
        x: Tensor,
        *,
        return_raw: bool = False,
        return_hidden: bool = False,
        return_aux: bool = False,
        return_dir: bool = False,
    ) -> (
        tuple[Tensor, Tensor]
        | tuple[Tensor, Tensor, Tensor, Tensor]
        | tuple[Tensor, Tensor, Tensor]
        | tuple[Tensor, Tensor, Tensor, Tensor, Tensor]
        | tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]
        | tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor | None]
    ):
        h = self.backbone(x)
        feats = self.feat(h)
        z_den = feats[:, :1]
        z_num = feats[:, 1:]
        aux_logits = None
        if bool(return_aux) and self.aux_classifier is not None:
            aux_logits = self.aux_classifier(h)
        dir_logits = None
        if bool(return_dir) and self.dir_classifier is not None:
            h_dir = h.detach() if bool(self.cfg.dir_detach_backbone) else h
            dir_logits = self.dir_classifier(h_dir)
        p_raw, q_raw = self.head(z_num, z_den)
        # Ensure (B,) tensors for scalar output.
        p_raw = p_raw.squeeze(-1)
        q_raw = q_raw.squeeze(-1)
        stop_grad = None if bool(self.cfg.detach_renorm) else (lambda t: t)
        p, q = renormalize(p_raw, q_raw, gamma=float(self.cfg.gamma), stop_gradient=stop_grad)
        if bool(return_raw) and bool(return_hidden):
            if bool(return_aux) and bool(return_dir):
                return p, q, p_raw, q_raw, h, aux_logits, dir_logits
            if bool(return_aux):
                return p, q, p_raw, q_raw, h, aux_logits
            if bool(return_dir):
                return p, q, p_raw, q_raw, h, dir_logits
            return p, q, p_raw, q_raw, h
        if bool(return_raw):
            return p, q, p_raw, q_raw
        if bool(return_hidden):
            return p, q, h
        if bool(return_aux):
            if aux_logits is None:
                raise ValueError("return_aux=True requires aux_classifier (aux_num_classes>0)")
            return p, q, aux_logits
        if bool(return_dir):
            if dir_logits is None:
                raise ValueError("return_dir=True requires dir_classifier (dir_num_classes>0)")
            return p, q, dir_logits
        return p, q


@dataclass(frozen=True)
class DoseAngularConfig:
    input_dim: int = 20
    hidden_dims: tuple[int, ...] = (64, 64)
    activation: str = "relu"
    theta_scale: float = 1.0
    aux_num_classes: int = 0  # 0 disables auxiliary classifier head
    dir_num_classes: int = 0  # 0 disables auxiliary censored-direction head
    dir_detach_backbone: bool = False  # if True, dir head does not backprop into backbone
    tau_infer: float = 1e-6
    tau_train: float = 1e-4


class DoseAngularSCMNet(nn.Module):
    """
    Angular projective parameterization for DOSE.

    Instead of predicting an unconstrained tuple (P,Q)∈R², we predict an angle θ
    and set:
      P = cos(θ),  Q = sin(θ)

    This makes "separation" (Q→0) and "direction" (which pole / semicircle) a
    geometry problem rather than a magnitude-collapse problem.
    """

    def __init__(self, cfg: DoseAngularConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.backbone = _mlp(int(cfg.input_dim), cfg.hidden_dims, str(cfg.activation))
        last_dim = int(cfg.hidden_dims[-1]) if cfg.hidden_dims else int(cfg.input_dim)
        self.theta = nn.Linear(last_dim, 1)
        self.aux_classifier: nn.Linear | None = None
        if int(cfg.aux_num_classes) > 0:
            self.aux_classifier = nn.Linear(last_dim, int(cfg.aux_num_classes))
        self.dir_classifier: nn.Linear | None = None
        if int(cfg.dir_num_classes) > 0:
            self.dir_classifier = nn.Linear(last_dim, int(cfg.dir_num_classes))

    @property
    def tau_infer(self) -> float:
        return float(self.cfg.tau_infer)

    @property
    def tau_train(self) -> float:
        return float(self.cfg.tau_train)

    def forward(
        self,
        x: Tensor,
        *,
        return_raw: bool = False,
        return_hidden: bool = False,
        return_aux: bool = False,
        return_dir: bool = False,
    ):
        h = self.backbone(x)
        theta_raw = self.theta(h).squeeze(-1)
        theta = float(self.cfg.theta_scale) * theta_raw
        p = torch.cos(theta)
        q = torch.sin(theta)

        aux_logits = None
        if bool(return_aux) and self.aux_classifier is not None:
            aux_logits = self.aux_classifier(h)
        dir_logits = None
        if bool(return_dir) and self.dir_classifier is not None:
            h_dir = h.detach() if bool(self.cfg.dir_detach_backbone) else h
            dir_logits = self.dir_classifier(h_dir)

        # For compatibility with the projective SCM loss/eval codepaths, we
        # return a (P,Q) tuple and (optionally) raw values. For angular mode,
        # "raw" is the pre-trig scalar θ (duplicated into p_raw/q_raw slots).
        p_raw = theta_raw
        q_raw = theta_raw

        if bool(return_raw) and bool(return_hidden):
            if bool(return_aux) and bool(return_dir):
                return p, q, p_raw, q_raw, h, aux_logits, dir_logits
            if bool(return_aux):
                return p, q, p_raw, q_raw, h, aux_logits
            if bool(return_dir):
                return p, q, p_raw, q_raw, h, dir_logits
            return p, q, p_raw, q_raw, h
        if bool(return_raw):
            return p, q, p_raw, q_raw
        if bool(return_hidden):
            return p, q, h
        if bool(return_aux):
            if aux_logits is None:
                raise ValueError("return_aux=True requires aux_classifier (aux_num_classes>0)")
            return p, q, aux_logits
        if bool(return_dir):
            if dir_logits is None:
                raise ValueError("return_dir=True requires dir_classifier (dir_num_classes>0)")
            return p, q, dir_logits
        return p, q
