"""Brachytherapy example code (Phase 14)."""

