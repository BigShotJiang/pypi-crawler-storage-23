"""
Export a strict SCM inference model as an ONNX "deployment bundle".

Writes:
  - export_bundle_demo/model.onnx
  - export_bundle_demo/metadata.json
"""

from __future__ import annotations

import json
from pathlib import Path

import torch
from torch import nn

from zeroproof.inference import InferenceConfig, SCMInferenceWrapper, export_bundle


class TupleModel(nn.Module):
    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        return x + 1.0, x


def main() -> None:
    model = SCMInferenceWrapper(TupleModel(), config=InferenceConfig(tau_infer=1e-6, tau_train=1e-4))
    model.eval()

    x = torch.randn(8, 3)
    out_dir = Path("export_bundle_demo")
    metadata = export_bundle(model, (x,), out_dir)

    print(f"Wrote: {out_dir / 'model.onnx'}")
    print(f"Wrote: {out_dir / 'metadata.json'}")
    print(json.dumps(metadata, indent=2, sort_keys=True))

    try:  # Optional: verify the ONNX file can be parsed.
        import onnx  # type: ignore[import-not-found]

        onnx.load(str(out_dir / "model.onnx"))
        print("ONNX load: OK")
    except Exception as exc:
        print(f"ONNX load skipped/failed: {exc}")


if __name__ == "__main__":
    main()

