"""Baselines for RR IK comparisons (MLP, rational+eps, DLS, ZeroProofML)."""
