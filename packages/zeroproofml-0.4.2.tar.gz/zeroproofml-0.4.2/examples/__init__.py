"""Examples package for ZeroProofML demos and baselines."""
