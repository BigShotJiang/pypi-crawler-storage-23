"""Reporting for NotionSource."""

from dataclasses import dataclass, field
from typing import Dict

from datahub.ingestion.source.state.stale_entity_removal_handler import (
    StaleEntityRemovalSourceReport,
)
from datahub.utilities.lossy_collections import LossyDict, LossyList


@dataclass
class NotionSourceReport(StaleEntityRemovalSourceReport):
    """Report for NotionSource combining stateful ingestion and file processing tracking."""

    # Files processed
    num_files_scanned: int = 0
    num_files_processed: int = 0
    num_files_skipped: int = 0
    num_files_failed: int = 0

    # Documents created
    num_documents_created: int = 0
    num_folder_documents_created: int = 0

    # Text extraction
    total_text_extracted_bytes: int = 0
    total_elements_extracted: int = 0

    # Errors
    processing_errors: LossyList[str] = field(default_factory=LossyList)
    skipped_files: LossyDict[str, str] = field(
        default_factory=LossyDict
    )  # file_path -> reason

    # Statistics by file type
    files_by_type: Dict[str, int] = field(default_factory=dict)

    # Partitioning statistics
    partitioning_strategy_used: Dict[str, int] = field(
        default_factory=dict
    )  # strategy -> count

    # Embedding statistics (from chunking source)
    num_documents_with_embeddings: int = 0
    num_embedding_failures: int = 0
    embedding_failures: LossyList[str] = field(default_factory=LossyList)
    num_documents_limit_reached: bool = False

    # Synced blocks (unsupported in unstructured-ingest v0.7.2)
    num_synced_blocks_skipped: int = 0
    synced_blocks_skipped: LossyList[str] = field(
        default_factory=LossyList
    )  # page_ids with synced blocks

    def report_file_scanned(self) -> None:
        self.num_files_scanned += 1

    def report_file_processed(
        self, file_type: str, num_elements: int, text_bytes: int
    ) -> None:
        self.num_files_processed += 1
        self.total_elements_extracted += num_elements
        self.total_text_extracted_bytes += text_bytes
        self.files_by_type[file_type] = self.files_by_type.get(file_type, 0) + 1

    def report_file_skipped(self, file_path: str, reason: str) -> None:
        self.num_files_skipped += 1
        self.skipped_files[file_path] = reason

    def report_file_failed(self, error_msg: str) -> None:
        self.num_files_failed += 1
        self.processing_errors.append(error_msg)

    def report_document_created(self, is_folder: bool = False) -> None:
        self.num_documents_created += 1
        if is_folder:
            self.num_folder_documents_created += 1

    def report_partitioning_strategy(self, strategy: str) -> None:
        self.partitioning_strategy_used[strategy] = (
            self.partitioning_strategy_used.get(strategy, 0) + 1
        )

    def report_synced_block_skipped(self, page_id: str) -> None:
        """Report that a synced block was skipped due to unstructured-ingest limitation."""
        self.num_synced_blocks_skipped += 1
        if page_id not in self.synced_blocks_skipped:
            self.synced_blocks_skipped.append(page_id)
            self.report_warning(
                title="Synced Block Content Skipped",
                message="Page contains synced blocks that cannot be fully ingested. "
                "The page will be ingested but synced block content will be missing. "
                "This is a known limitation of the current connector version.",
                context=f"Page ID: {page_id}",
            )
