"""Microsoft Fabric common components for DataHub ingestion."""
