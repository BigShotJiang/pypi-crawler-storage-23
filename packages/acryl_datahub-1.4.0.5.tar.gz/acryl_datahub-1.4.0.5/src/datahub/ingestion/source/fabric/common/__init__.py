"""Common components for Microsoft Fabric connectors."""
