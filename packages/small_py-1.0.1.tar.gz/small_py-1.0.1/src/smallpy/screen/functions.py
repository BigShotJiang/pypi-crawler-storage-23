import pyautogui as pag
from typing import Union,Tuple
import time
import os
from ..utils import clear_terminal

def wait_for_image(
    image_path: Union[str,list],
    timeout: int = 5,
    interval: float = 0.1,
    conf: float = 0.95,
    invert_search: bool = False,
    allow_failure: bool = False,
    dec_indents: int = 1
) -> Tuple[int, int] | None:
    """
    Wait for an image (or list of images) to appear (or disappear) on the screen.

    Parameters
    ----------
    image_path : str or list of str
        Path to an image file, or list of image paths to search for.
    timeout : int, optional
        Maximum time to wait (seconds), default is 5.
    interval : float, optional
        Time to wait between search attempts (seconds), default is 0.1.
    conf : float, optional
        Confidence threshold for image recognition (0.0 - 1.0), default is 0.95.
    invert_search : bool, optional
        If True, waits for the image(s) to disappear instead of appear,
        default is False.
    allow_failure : bool, optional
        Will return None if `image_path` is not found within the `timeout`, default is False.
    dec_indents : int, optional
        Number of spaces before print statement decorators, default is 1.

    Returns
    -------
    tuple of int or bool
        - Coordinates `(x, y)` of the found image center if invert_search is False
        - True if invert_search is True and the image(s) disappear

    Raises
    ------
    TypeError
        If `image_path` is neither a string nor a list.
    """
    start_time = time.time()
    coord = None
    printed = False
    
    imgs = []
    if isinstance(image_path,str):
        imgs.append(image_path)
        image_path = imgs
    
    if isinstance(image_path,list):
        while coord is None:
            if (time.time() - start_time) < timeout:
                pass
            elif ((time.time() - start_time) > timeout) and allow_failure:
                return None
            else:
                if not printed:
                    if not invert_search:
                        print(f'{' '*dec_indents}>> Unable to locate {[os.path.split(img)[1] for img in image_path]}')
                    else:
                        print(f'{' '*dec_indents}>> Waiting for {[os.path.split(img)[1] for img in image_path]} to close')
                    printed = True
            
            for img in image_path:
                if not invert_search:
                    try:
                        coord = pag.locateCenterOnScreen(img,grayscale=True,confidence=conf)
                    except pag.ImageNotFoundException:
                        pass
                else:
                    try:
                        coord = pag.locateCenterOnScreen(img,grayscale=True,confidence=conf)
                    except pag.ImageNotFoundException:
                        coord = True
                
                time.sleep(interval)
        if printed:
            clear_terminal()
        return coord
    else:
        raise TypeError(f'Unsupported image_path type: {type(image_path)}')
    
def find_and_click(
    image_path: str,
    offset: Tuple[int,int] = (0, 0)
) -> None:
    """
    Wait for an image to appear on screen, optionally offset the coordinates,
    and perform a mouse click at that location.

    Parameters
    ----------
    image_path : str
        Path to the image to locate on screen.
    offset : tuple of int, optional
        (x, y) offset to apply to the found image coordinates before clicking.
        Default is (0, 0).

    Returns
    -------
    None
    """
    coord = wait_for_image(image_path)
    coord = offset_coords(coord,offset)
    pag.sleep(0.25)
    pag.click(coord)
    pag.sleep(0.25)

def offset_coords(
    coords: Tuple[int, int],
    offset: Tuple[int, int] = (0,0)
) -> Tuple[int,int]:
    """
    Apply an (x, y) offset to a pair of screen coordinates.

    Parameters
    ----------
    coords : tuple of int
        Original (x, y) coordinates.
    offset : tuple of int, optional
        (x, y) offset to apply. Default is (0, 0).

    Returns
    -------
    tuple of int
        New coordinates after applying the offset.

    Examples
    --------
    >>> offset_coords((100, 200), (10, -5))
    (110, 195)
    """
    x,y = coords
    x_off,y_off = offset

    return (x+x_off,y+y_off)