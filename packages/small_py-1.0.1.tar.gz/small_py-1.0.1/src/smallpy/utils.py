from datetime import datetime,timedelta
import time
import os
import ctypes
import pandas as pd
import json
import pyautogui as pag
from typing import Dict,Any,Optional,Sequence,Union,Tuple,List

def enable_virtual_terminal() -> None:
    """
    Enable virtual terminal processing for the current Windows console.

    This allows ANSI escape sequences (such as color codes and cursor
    movement) to work correctly in the Windows terminal.

    On non-Windows platforms, this function does nothing.

    Returns
    -------
    None
    """
    if os.name == 'nt':  # Windows
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_ulong()
        kernel32.GetConsoleMode(handle, ctypes.byref(mode))
        mode.value |= 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
        kernel32.SetConsoleMode(handle, mode)

def clear_terminal(
    lines: int = 1,
    length: int = 100
) -> None:
    """
    Clear previously printed lines from the terminal.

    This function moves the cursor up and overwrites the specified
    number of lines with spaces, effectively erasing them from view.

    Parameters
    ----------
    lines : int, optional
        Number of lines to clear from the terminal (default is 1).
    length : int, optional
        Number of character spaces used to overwrite each line
        (default is 100).

    Returns
    -------
    None
    """
    for _ in range(lines):
        print('\033[A'+' '*length,'\033[A')

def write_to_excel(
    dataframe: pd.DataFrame,
    output_path: str,
    print_decorators: bool = True
) -> None:
    """
    Write a Pandas DataFrame to an Excel file.

    Parameters
    ----------
    dataframe : pd.DataFrame
        The DataFrame to be written to the Excel file.
    output_path : str
        Path (including filename) where the Excel file will be saved.
    print_decorators : bool, optional
        Whether to print status messages before and after writing
        the file (default is True).

    Returns
    -------
    None
    """
    print('WRITING TO EXCEL') if print_decorators else None
    with pd.ExcelWriter(output_path) as writer:
        dataframe.to_excel(writer, index=False)
    print(' Success') if print_decorators else None

class Counter:
    """
    A simple progress counter to track task completion and estimate remaining time.

    Attributes
    ----------
    n : int
        Current progress count.
    count : int
        Total count to reach completion.
    formatter : str, optional
        A custom formatting string for display. Supports placeholders:
        - %n : current count
        - %N : total count
        - %T : estimated completion time (hh:mm AM/PM)
        - %t : remaining time in seconds
        - %f : remaining time formatted as "Hh Mm Ss"
    times_to_complete : list[float]
        List of time intervals between successive `display()` calls.
    start_times : list[datetime]
        Timestamps of when `display()` was called.
    max_completion_n : int
        Maximum number of recent intervals to track for averaging.
    """
    def __init__(self,count,max_completion_n=10,format=None):
        self.n:int = 0
        self.count:int = count
        self.formatter:str = format
        self.times_to_complete = []
        self.start_times = []
        self.max_completion_n = max_completion_n
    
    @property
    def __default(self):
        return f"{self.n}/{self.count}"
    
    @property
    def __formatted(self):
        formatting_map = {
            '%n':self.n,
            '%N':self.count,
            '%T':self.__completion_time,
            '%t':self.__time_remaining(),
            '%f':self.__time_remaining(formatted=True)
        }

        formatting_str = self.formatter
        for key,value in formatting_map.items():
            if value is None:
                formatting_str = formatting_str.replace(key,'')
            else:
                formatting_str = formatting_str.replace(key,f'{value}')
        
        return formatting_str
    
    @property
    def __completion_time(self):
        if self.__time_remaining() is not None:
            exp_end_time = datetime.fromtimestamp(datetime.now().timestamp() + self.__time_remaining())
            return exp_end_time.strftime('%I:%M %p')
        else:
            return None
    
    def __format_time(self,seconds):
        secs = int(seconds)
        hr = secs // 3600
        mins = (secs % 3600) // 60
        sec = secs % 60
        return f'{hr}h {mins}m {sec}s'
    
    def __time_remaining(self,formatted = False):
        if not self.times_to_complete:
            return None
        
        count_remaining = self.count - self.n
        avg_time = (sum(self.times_to_complete) / len(self.times_to_complete))
        seconds = avg_time * count_remaining

        if formatted:
            return self.__format_time(seconds)
        else:
            return round(seconds,2)

    def display(self):
        self.start_times.append(datetime.now())

        if len(self.start_times) > 1:
            self.times_to_complete.append(self.start_times[-1].timestamp() - self.start_times[-2].timestamp())
            if len(self.times_to_complete) > self.max_completion_n:
                self.times_to_complete = self.times_to_complete[-self.max_completion_n:]

        self.n += 1
        if self.formatter:
            print(self.__formatted)
        else:
            print(self.__default)

def get_most_recent_file(directory: str) -> str:
    """
    Return the most recently created or modified file in a given directory.

    Parameters
    ----------
    directory : str
        Path to the directory to search for files.

    Returns
    -------
    str
        Full path to the most recently created/modified file.
        Returns "No files found" if the directory contains no files.

    Examples
    --------
    >>> get_most_recent_file(r"C:\\Users\\Me\\Documents")
    'C:\\Users\\Me\\Documents\\latest_report.xlsx'
    """
    files = [os.path.join(directory, file) for file in os.listdir(directory) 
             if os.path.isfile(os.path.join(directory, file))]

    return max(files, key=os.path.getctime) if files else "No files found"
        
def __main():
    ...

if __name__ == '__main__':
    __main()
