from python_base_command import Runner

Runner(commands_dir="usage_example/commands").run()
