from __future__ import annotations
import asyncio
import json
import struct

from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import Optional


class FunnelMessageType(StrEnum):
    CONNECT = "connect"
    ACCEPT = "accept"
    HEARTBEAT = "heartbeat"
    INCOMING = "incoming_connection"
    RECEIVE = "receive_connection"


@dataclass
class FunnelMessage:
    type: FunnelMessageType
    connection_id: Optional[str] = None
    proxy_subdomain: Optional[str] = None
    method: Optional[str] = None
    request_line: Optional[str] = None

    def encode(self) -> bytes:
        # filter out missing keys before sending the message
        data = {k: v for k, v in asdict(self).items() if v is not None}
        return json.dumps(data).encode()

    @classmethod
    def decode(cls, data: bytes) -> FunnelMessage:
        return cls(**json.loads(data))


async def read_message(reader: asyncio.StreamReader) -> FunnelMessage:
    message_length = struct.unpack(">I", await reader.readexactly(4))[0]
    data = await reader.readexactly(message_length)
    return FunnelMessage.decode(data)


async def write_message(
    writer: asyncio.StreamWriter, funnel_message: FunnelMessage
) -> None:
    data = funnel_message.encode()
    writer.write(struct.pack(">I", len(data)))
    writer.write(data)
    await writer.drain()


async def forward(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    data = await reader.read(4096)
    while data:
        writer.write(data)
        await writer.drain()
        data = await reader.read(4096)
    writer.close()
