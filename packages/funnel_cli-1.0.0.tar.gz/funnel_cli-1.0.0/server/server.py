import asyncio
import logging
import uuid
import ssl

from dataclasses import dataclass
from shared.lib import (
    forward,
    FunnelMessage,
    FunnelMessageType,
    read_message,
    write_message,
)
from server.util import generate_random_subdomain, send_html_response

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("funnel_server")

HOST = "0.0.0.0"
HTTP_PORT = 80
CLIENT_PORT = 8080
BASE_DOMAIN = "funnel.delivery"


@dataclass
class Tunnel:
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    lock: asyncio.Lock


@dataclass
class PendingConnection:
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    proxy_subdomain: str
    identifier_bytes: bytes


TUNNELS: dict[str, Tunnel] = {}
PENDING_CONNECTIONS: dict[str, PendingConnection] = {}


async def handle_heartbeat(
    proxy_subdomain: str, writer: asyncio.StreamWriter, lock: asyncio.Lock
) -> None:
    """
    Periodically sends heartbeat messages to the funnel client to ensure the connection
    is still alive. Cleans up the connection if the client becomes unreachable.
    """
    try:
        while True:
            async with lock:
                logger.info("Sending heartbeat")
                await write_message(
                    writer,
                    FunnelMessage(type=FunnelMessageType.HEARTBEAT),
                )
            await asyncio.sleep(10)

    # if heartbeat fails, clean up connection
    except Exception as e:
        logger.error(e)
        writer.close()
        del TUNNELS[proxy_subdomain]
        to_remove = [
            cid
            for cid, conn in PENDING_CONNECTIONS.items()
            if conn.proxy_subdomain == proxy_subdomain
        ]
        for cid in to_remove:
            PENDING_CONNECTIONS[cid].writer.close()
            del PENDING_CONNECTIONS[cid]
        logger.info(f"Cleaned up connection associated with {proxy_subdomain}")


async def check_pending_connection(connection_id: str) -> None:
    """
    Checks if a connection ID is still in the pool of pending connections.
    Deletes the connection and shuts the writer down if it hasn't been
    claimed within 10 seconds.
    """
    await asyncio.sleep(10)
    if connection_id in PENDING_CONNECTIONS:
        logger.info(f"connection {connection_id} is unclaimed, cleaning it up")
        pending_connection = PENDING_CONNECTIONS[connection_id]
        pending_connection.writer.close()
        del PENDING_CONNECTIONS[connection_id]


async def handle_public(
    public_reader: asyncio.StreamReader, public_writer: asyncio.StreamWriter
) -> None:
    """
    Sets up a short-lived connection between a public request and the funnel server
    and notifies the client of the connection
    """
    try:
        header_bytes = await public_reader.readuntil(b"\r\n\r\n")
        header_lines = header_bytes.decode().split("\r\n")
        request_line = header_lines[0]
        headers = dict(line.split(": ", 1) for line in header_lines if ": " in line)
        host = headers["Host"].split(":")[0].lower()
        proxy_subdomain = host.split(".")[0]

        if host == BASE_DOMAIN:
            await send_html_response(public_writer, "home.html")
            return

        client_writer = TUNNELS[proxy_subdomain].writer
        lock = TUNNELS[proxy_subdomain].lock

    except Exception as e:
        logger.error(f"failed to parse proxy subdomain with error {e}")
        await send_html_response(
            public_writer, "404.html", status=404, subdomain=proxy_subdomain
        )
        return

    connection_id = str(uuid.uuid4())
    PENDING_CONNECTIONS[connection_id] = PendingConnection(
        reader=public_reader,
        writer=public_writer,
        proxy_subdomain=proxy_subdomain,
        identifier_bytes=header_bytes,
    )

    asyncio.create_task(check_pending_connection(connection_id))

    logger.info(f"Created temporary request identifier {connection_id}")
    # lock the client writer since the control connection has multiple things
    # being written to it at once
    async with lock:
        await write_message(
            client_writer,
            FunnelMessage(
                type=FunnelMessageType.INCOMING,
                connection_id=connection_id,
                request_line=request_line,
            ),
        )


# request will be to open up a long-running TCP connection
# this is the control connection, raw bytes do not flow over this connection
async def handle_client(
    client_reader: asyncio.StreamReader, client_writer: asyncio.StreamWriter
) -> None:
    """
    Handles the control connection between the funnel client and funnel server.
    The initial connection is established here, as well as setting up new connections
    when a client requests data to be forwarded to it.
    """
    try:
        message = await read_message(client_reader)
        match message.type:
            case FunnelMessageType.CONNECT:
                logger.info("Received connection request from client")
                proxy_subdomain = message.proxy_subdomain
                if not proxy_subdomain:
                    proxy_subdomain = generate_random_subdomain()
                proxy_subdomain = proxy_subdomain.lower()
                if proxy_subdomain in TUNNELS:
                    raise Exception(
                        f"subdomain {proxy_subdomain} has already been claimed"
                    )
                lock = asyncio.Lock()
                logger.info(f"assigning subdomain {proxy_subdomain} to client")
                TUNNELS[proxy_subdomain] = Tunnel(
                    reader=client_reader, writer=client_writer, lock=lock
                )

                async with lock:
                    await write_message(
                        client_writer,
                        FunnelMessage(
                            type=FunnelMessageType.ACCEPT,
                            proxy_subdomain=proxy_subdomain,
                        ),
                    )

                asyncio.create_task(
                    handle_heartbeat(proxy_subdomain, client_writer, lock)
                )

            case FunnelMessageType.RECEIVE:
                connection_id = message.connection_id
                if not connection_id:
                    raise Exception("no connection ID present in receive message")
                connection = PENDING_CONNECTIONS[connection_id]
                public_reader, public_writer = (
                    connection.reader,
                    connection.writer,
                )

                # write the initial bytes that were read for subdomain routing to the client
                client_writer.write(connection.identifier_bytes)
                await client_writer.drain()

                await asyncio.gather(
                    asyncio.create_task(forward(public_reader, client_writer)),
                    asyncio.create_task(forward(client_reader, public_writer)),
                )

                logger.info(
                    f"Request closed, terminating connection ID {connection_id}"
                )
                del PENDING_CONNECTIONS[connection_id]

            case _:
                logger.info(message.type)
                raise Exception("Invalid connection request")

    except Exception as e:
        logger.error(f"Error connecting to client: {e}")
        client_writer.close()


async def start_client_handler():
    ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_ctx.load_cert_chain(
        "/etc/letsencrypt/live/funnel.delivery/fullchain.pem",
        "/etc/letsencrypt/live/funnel.delivery/privkey.pem",
    )
    server = await asyncio.start_server(handle_client, HOST, CLIENT_PORT, ssl=ssl_ctx)
    await server.serve_forever()


async def start_public_handler():
    server = await asyncio.start_server(handle_public, HOST, HTTP_PORT)
    await server.serve_forever()


async def main():
    await asyncio.gather(start_client_handler(), start_public_handler())


if __name__ == "__main__":
    asyncio.run(main())
