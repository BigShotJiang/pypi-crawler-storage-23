import asyncio
import random
from pathlib import Path

TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"

STATUS_PHRASES = {
    200: "OK",
    404: "Not Found",
}


def load_template(name: str, **kwargs: str) -> str:
    text = (TEMPLATE_DIR / name).read_text()
    for key, value in kwargs.items():
        text = text.replace(f"{{{key}}}", value)
    return text


async def send_html_response(
    writer: asyncio.StreamWriter,
    template: str,
    status: int = 200,
    **kwargs: str,
) -> None:
    body = load_template(template, **kwargs)
    phrase = STATUS_PHRASES.get(status, "OK")
    response = (
        f"HTTP/1.1 {status} {phrase}\r\n"
        "Content-Type: text/html\r\n"
        "Connection: close\r\n"
        f"Content-Length: {len(body)}\r\n"
        "\r\n" + body
    )
    writer.write(response.encode())
    await writer.drain()
    writer.close()


def generate_random_subdomain() -> str:
    adjectives = [
        "auspicious",
        "diabolical",
        "ominous",
        "glib",
        "crusty",
        "swift",
        "moldy",
        "spicy",
        "fuzzy",
        "wonky",
        "crispy",
        "soggy",
        "sneaky",
        "famous",
        "infamous",
        "controversial",
        "rusty",
        "dusty",
        "toasty",
        "frosty",
        "gloomy",
        "zesty",
    ]
    nouns = [
        "yak",
        "clam",
        "waffle",
        "toad",
        "walrus",
        "pickle",
        "badger",
        "turnip",
        "eel",
        "moose",
        "squid",
        "mango",
        "puffin",
        "ferret",
        "shrimp",
        "egret",
        "parrot",
        "trashcan",
        "spatula",
        "mitochondria",
        "rat",
    ]
    return f"{random.choice(adjectives)}-{random.choice(nouns)}"
