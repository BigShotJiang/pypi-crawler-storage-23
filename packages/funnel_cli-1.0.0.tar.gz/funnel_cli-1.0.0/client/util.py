from textual.theme import Theme

HOST = "funnel.delivery"
PORT = 8080
DEFAULT_LOCAL_PORT = 8000

FUNNEL_THEME = Theme(
    name="funnel",
    primary="#22c55e",
    secondary="#3b82f6",
    accent="#3b82f6",
    warning="#eab308",
    error="#ef4444",
    success="#22c55e",
    foreground="#e4e4e7",
    background="#09090b",
    surface="#18181b",
    panel="#27272a",
)

METHOD_COLORS: dict[str, str] = {
    "GET": "#22c55e",
    "POST": "#3b82f6",
    "PUT": "#eab308",
    "DELETE": "#ef4444",
    "PATCH": "#06b6d4",
    "HEAD": "#a855f7",
    "OPTIONS": "#71717a",
}

APP_CSS = """
#tunnel-info {
    height: auto;
    padding: 1 1;
    background: $surface;
}

#separator {
    height: 1;
    background: $panel;
    color: #3b82f6;
}

#request-count {
    height: 1;
    padding: 0 1;
    background: $panel;
    text-style: bold;
    color: $text-muted;
}

#request-table {
    height: 1fr;
}
"""

HELP_TEXT = """\
\033[1mfunnel\033[0m - expose local ports to public URLs

\033[1mUSAGE:\033[0m
  funnel <port> [flags]

\033[1mDESCRIPTION:\033[0m
  Funnel creates a secure tunnel from a public URL to your local
  service. Traffic to https://<subdomain>.funnel.delivery gets
  forwarded to localhost on the port you specify.

\033[1mEXAMPLES:\033[0m
  # forward traffic to local port 3000
  funnel 3000

  # request a specific subdomain
  funnel 8080 --subdomain my-app

  # your app is then available at:
  # https://my-app.funnel.delivery

\033[1mFLAGS:\033[0m
  -s, --subdomain <name>   request a specific subdomain (default: random)
  -h, --help               show this help message

\033[1mNOTES:\033[0m
  Press Ctrl+C to disconnect the tunnel.
  Install: pipx install funnel-cli
"""
