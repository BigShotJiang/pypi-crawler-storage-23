import argparse
import asyncio
from datetime import datetime

from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.reactive import reactive
from textual.widgets import DataTable, Static

from shared.lib import (
    FunnelMessage,
    FunnelMessageType,
    forward,
    read_message,
    write_message,
)
from client.util import (
    APP_CSS,
    DEFAULT_LOCAL_PORT,
    FUNNEL_THEME,
    HELP_TEXT,
    HOST,
    METHOD_COLORS,
    PORT,
)


class TunnelInfo(Static):
    """Header panel showing tunnel URL, forwarding target, and connection status."""

    subdomain = reactive("")
    local_port = reactive(DEFAULT_LOCAL_PORT)
    connected = reactive(False)
    local_up = reactive(False)

    def render(self) -> str:
        if self.subdomain:
            tunnel = f"[bold #3b82f6]https://{self.subdomain}.{HOST}[/]"
        else:
            tunnel = f"[#71717a]connecting to {HOST}…[/]"

        fwd = f"[#a1a1aa]http://localhost:{self.local_port}[/]"

        if not self.connected:
            if self.subdomain:
                status = "[#ef4444]● Disconnected from server[/]"
            else:
                status = "[#eab308]● Connecting…[/]"
        elif not self.local_up:
            status = f"[#22c55e]● Tunnel ready[/]  [#eab308]— no service on port {self.local_port}, requests won't be forwarded[/]"
        else:
            status = "[#22c55e]● Forwarding requests[/]"

        return (
            f"  [#a1a1aa]Tunnel[/]    {tunnel}  →  {fwd}\n"
            f"  [#a1a1aa]Status[/]    {status}"
        )


class RequestCount(Static):
    """Section header that tracks total number of forwarded requests."""

    count = reactive(0)

    def render(self) -> str:
        return f" Requests ({self.count} total)"


class FunnelApp(App):
    """Funnel tunnel client TUI."""

    TITLE = "Funnel"
    ENABLE_COMMAND_PALETTE = False
    CSS = APP_CSS

    def __init__(
        self,
        subdomain: str | None = None,
        local_port: int = DEFAULT_LOCAL_PORT,
    ):
        super().__init__()
        self.register_theme(FUNNEL_THEME)
        self.theme = "funnel"
        self._subdomain_request = subdomain
        self._local_port = local_port
        self._control_writer: asyncio.StreamWriter | None = None

    def compose(self) -> ComposeResult:
        info = TunnelInfo(id="tunnel-info")
        info.local_port = self._local_port
        yield info
        yield Static("─" * 200, id="separator")
        yield RequestCount(id="request-count")
        yield DataTable(id="request-table")

    def on_mount(self) -> None:
        table = self.query_one("#request-table", DataTable)
        table.add_columns("Time", "Method", "Path", "ID")
        table.cursor_type = "none"
        self._run_tunnel()
        self._monitor_local_service()

    @work(exclusive=True)
    async def _run_tunnel(self) -> None:
        """Background worker managing the tunnel control connection."""
        info = self.query_one("#tunnel-info", TunnelInfo)
        try:
            reader, writer = await asyncio.open_connection(HOST, PORT, ssl=True)
            self._control_writer = writer

            await write_message(
                writer,
                FunnelMessage(
                    type=FunnelMessageType.CONNECT,
                    proxy_subdomain=self._subdomain_request,
                ),
            )

            accept = await read_message(reader)
            if accept.type == FunnelMessageType.ACCEPT:
                info.subdomain = accept.proxy_subdomain or ""
                info.connected = True

            while True:
                msg = await read_message(reader)
                if msg.type == FunnelMessageType.HEARTBEAT:
                    continue
                elif msg.type == FunnelMessageType.INCOMING:
                    self._record_request(msg)

        except Exception:
            info.connected = False

    def _record_request(self, message: FunnelMessage) -> None:
        """Parse an INCOMING message and append it to the request table."""
        method, path = "???", "/"
        if message.request_line:
            parts = message.request_line.split()
            if len(parts) >= 2:
                method, path = parts[0], parts[1]

        timestamp = datetime.now().strftime("%H:%M:%S")
        color = METHOD_COLORS.get(method.upper(), "white")
        styled_method = Text(f" {method:<7}", style=f"bold {color}")
        conn_short = (message.connection_id or "")[:8]

        table = self.query_one("#request-table", DataTable)
        table.add_row(timestamp, styled_method, path, conn_short)
        table.scroll_end(animate=False)

        counter = self.query_one("#request-count", RequestCount)
        counter.count += 1

        if message.connection_id:
            asyncio.create_task(self._handle_data_connection(message.connection_id))

    async def _check_local_port(self) -> bool:
        """Return True if something is listening on the local forwarding port."""
        try:
            _, w = await asyncio.open_connection("localhost", self._local_port)
            w.close()
            await w.wait_closed()
            return True
        except OSError:
            return False

    @work(exclusive=True, group="local_monitor")
    async def _monitor_local_service(self) -> None:
        """Periodically check that the local service is still reachable."""
        info = self.query_one("#tunnel-info", TunnelInfo)
        while True:
            info.local_up = await self._check_local_port()
            await asyncio.sleep(3)

    async def _handle_data_connection(self, connection_id: str) -> None:
        """Open a data connection to forward traffic for a single request."""
        try:
            local_r, local_w = await asyncio.open_connection(
                "localhost", self._local_port
            )
            remote_r, remote_w = await asyncio.open_connection(HOST, PORT, ssl=True)

            await write_message(
                remote_w,
                FunnelMessage(
                    type=FunnelMessageType.RECEIVE,
                    connection_id=connection_id,
                ),
            )

            await asyncio.gather(
                forward(remote_r, local_w),
                forward(local_r, remote_w),
            )
        except Exception:
            pass

    def action_help_quit(self) -> None:
        self.exit()


def main() -> None:
    parser = argparse.ArgumentParser(
        usage="funnel <port> [flags]",
        add_help=False,
    )
    parser.add_argument(
        "port",
        nargs="?",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "-s",
        "--subdomain",
        type=str,
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "-h",
        "--help",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    args = parser.parse_args()

    if args.help or args.port is None:
        print(HELP_TEXT)
        return

    app = FunnelApp(subdomain=args.subdomain, local_port=args.port)
    app.run()


if __name__ == "__main__":
    main()
