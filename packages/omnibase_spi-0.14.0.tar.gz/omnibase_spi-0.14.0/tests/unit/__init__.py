"""Unit tests for omnibase_spi."""
