"""Tests for registry protocols."""
