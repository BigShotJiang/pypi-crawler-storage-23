# 🐍 Familiar Quick Start

Awaken the Mother of Monsters in 5 minutes.

---

## Step 1: Install

```bash
unzip familiar.zip
cd familiar
pip install -r requirements.txt --break-system-packages
python -m familiar --init
```

---

## Step 2: Give Her a Brain

Choose ONE:

```bash
# Claude (smartest)
export ANTHROPIC_API_KEY="sk-ant-api03-..."

# OR GPT-4 
export OPENAI_API_KEY="sk-..."

# OR Ollama (free, local, private)
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3.2
```

---

## Step 3: Unleash

### Option A: Command Line
```bash
python -m familiar
```

### Option B: Telegram Bot
```bash
export TELEGRAM_BOT_TOKEN="your-token-from-botfather"
python -m familiar --telegram
```

### Option C: Discord Bot
```bash
export DISCORD_BOT_TOKEN="your-token"
python -m familiar --discord
```

### Option D: Web Dashboard
```bash
python -m familiar --dashboard
# Open http://localhost:5000
```

---

## Step 4: Command Your Monsters

```
You: What can you do?

You: Add a task to call Sarah, due tomorrow, urgent

You: Sort my inbox

You: Give me my morning briefing
```

---

## 🐕‍🦺 Meet the Monsters

| Monster | Command |
|---------|---------|
| 📧 Cerberus | "Sort my inbox" |
| ✅ Hydra | "Show my tasks" |
| 📅 Chronos | "What's on my calendar?" |
| 🌐 Arachne | "Log into the portal" |
| 📡 Hermes | "Message Mom: I'll be late" |
| ☀️ Helios | "Morning briefing" |

---

## Optional: Email Setup

```bash
export EMAIL_ADDRESS="you@gmail.com"
export EMAIL_PASSWORD="xxxx-xxxx-xxxx-xxxx"  # App password
```

Then: `"Check my inbox"` or `"Sort my emails"`

---

## Optional: Run Forever

```bash
# Install as system service
make service-install
make service-start

# Familiar now runs 24/7, even after reboot
```

---

## Need More?

See `README.md` for:
- All 15 monsters explained
- Multi-device mesh setup
- Plugin marketplace
- Full configuration options

---

**🐍 The Mother awakens.** 
