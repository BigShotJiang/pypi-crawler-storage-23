# Meeting Management Skill

End-to-end meeting lifecycle: schedule with invites, generate agendas,
take minutes, distribute follow-ups, track action items.

## Usage

Use this skill when the user wants to:
- Schedule a meeting and send calendar invites
- Generate a meeting agenda from topics and prior action items
- Record meeting minutes (manual entry or from transcription)
- Distribute minutes to attendees with highlighted action items
- Extract and track action items from meeting minutes

## Cross-Skill Integration

- **calendar**: schedule_meeting creates event + sends invites
- **contacts**: Attendees resolved from contacts by name or email
- **email**: Invites and minutes distributed via email
- **documents**: Agenda and minutes generated as DOCX/PDF
- **tasks**: Action items auto-create tasks assigned to contacts
- **voice**: Minutes can be fed from live transcription

## Dependencies

- icalendar (optional, for .ics invite generation)
- Integrates with existing calendar, contacts, email, documents, tasks skills
