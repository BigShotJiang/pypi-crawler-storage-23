# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar - Main Agent Class

Brings together:
- LLM providers
- Memory system
- Tools
- Skills
- Scheduler
- Observability (tracing, cost tracking)
- Resilience (retry with backoff)
- Security (trust levels, capabilities, budget)
- Compliance (HIPAA, SOC2, etc.)
- Streaming support

Phase 1 (v1.6): Multi-user support via UserContext
Phase 2.1 (v2.1): Input sanitization and structured exceptions

This is the core brain of the agent.
"""

import json
import logging
import os
import platform
import threading
import time
import uuid
from datetime import datetime
from datetime import timezone as _dt_timezone
from pathlib import Path
from typing import Any, Callable, Dict, Generator, Optional

from .analytics import get_analytics_store
from .backup import (
    BackupConfig,
    BackupManager,
    BackupManifest,
    BackupType,
)
from .bus import (
    SkillBus,
    set_skill_bus,
)
from .config import Config, load_config
from .context import (
    EmbeddingProvider as ContextEmbeddingProvider,
)
from .context import (
    InMemoryVectorStore,
    RetrievalConfig,
    SemanticRetriever,
)
from .embeddings import (
    EmbeddingProvider as RawEmbeddingProvider,
)
from .embeddings import (
    TFIDFEmbeddings,
    get_embedding_provider,
)
from .episodic_memory import (
    FileMemoryPersistence as EpisodicPersistence,
)
from .episodic_memory import (
    MemorySystem as EpisodicMemorySystem,
)
from .episodic_memory import (
    RetrievalStrategy as EpisodicRetrievalStrategy,
)
from .event_emitter import EventEmitter, ExecutionEvent
from .exceptions import (
    BudgetExceededError,
    SessionExpiredError,
)
from .experiments import (
    ExperimentManager,
    set_experiment_manager,
)
from .guardrails import (
    GuardrailConfig,
    Guardrails,
    GuardrailViolation,
    UsageTracker,
    ViolationType,
)
from .health import (
    DependencyHealth,
    DependencyType,
    HealthChecker,
    create_memory_agent_health_check,
    create_planner_health_check,
)
from .memory import ConversationHistory, Memory
from .memory_agent import MemoryExtractor

# Mesh networking — lazy imports inside methods to avoid port binding at module load
# Full imports happen in start_mesh() and __init__ (gateway object only)
from .mesh import (
    MeshGateway,
)
from .metrics import (
    MetricsCollector,
    get_metrics_collector,
)
from .observability import Trace, calculate_cost
from .orchestration import (
    Orchestrator,
)
from .planner import TaskPlanner
from .providers import (
    LLMProvider,
    LLMResponse,
    StreamEvent,
    StreamEventType,
    get_best_ollama_model,
    get_provider,
)

try:
    from .providers import OllamaProvider as _OllamaProvider
except ImportError:
    _OllamaProvider = None
from .resilience import ProviderCapacityTracker, RetryConfig
from .saga import (
    InMemorySagaLog,
    Saga,
    SagaExecution,
    SagaOrchestrator,
)

# Phase 2: Input sanitization and exceptions
from .sanitization import SanitizationLevel, sanitize_user_input
from .scheduler import TaskFrequency, get_scheduler
from .security import (
    Capability,
    SecureSession,
    SecurityConfig,
    SecurityMode,
    SessionManager,
    TrustLevel,
    check_skill_access,
    is_encryption_enabled,
)
from .skills import SkillLoader
from .structured_output import (
    ExtractionMethod,
    StructuredGenerator,
    ValidationStrategy,
)
from .tool_router import RouterConfig, ToolRouter
from .tools import get_tool_registry

# Phase 1: Multi-user support
try:
    from .data_store import DataStore, get_data_store
    from .users import User, UserContext, UserRole

    HAS_USER_MANAGEMENT = True
except ImportError:
    HAS_USER_MANAGEMENT = False
    UserContext = None
    UserRole = None
    User = None
    DataStore = None
    get_data_store = None

# Import compliance module (optional)
try:
    from .compliance import (
        ComplianceMode,
        validate_compliance,
    )

    COMPLIANCE_AVAILABLE = True
except ImportError:
    COMPLIANCE_AVAILABLE = False
    ComplianceMode = None

logger = logging.getLogger(__name__)


# ── EpisodicMemory encryption singleton ──────────────────────────────────────
# Mirrors the pattern in core/memory.py: lazy-init, graceful degradation.
# Uses the same EncryptedStorage class and FAMILIAR_ENCRYPTION_KEY env var.
# Separate singleton from security.py's session encryption so each subsystem
# manages its own storage independently.

try:
    from .encryption import CRYPTOGRAPHY_AVAILABLE as _EP_CRYPTO
    from .encryption import EncryptedStorage as _EpisodicEncStorage
except ImportError:
    _EpisodicEncStorage = None
    _EP_CRYPTO = False

_episodic_encryption = None
_episodic_encryption_initialized = False
_episodic_encryption_lock = threading.Lock()


def _get_episodic_encryption():
    """
    Return the EncryptedStorage singleton for episodic memory, or None.

    Reads FAMILIAR_ENCRYPTION_KEY on first call. If the key is set and
    cryptography is installed, returns a ready EncryptedStorage instance.
    Otherwise returns None — callers fall back to plaintext JSON.
    """
    global _episodic_encryption, _episodic_encryption_initialized
    if _episodic_encryption_initialized:
        return _episodic_encryption
    with _episodic_encryption_lock:
        if _episodic_encryption_initialized:
            return _episodic_encryption
        key = os.environ.get("FAMILIAR_ENCRYPTION_KEY")
        if key and _EP_CRYPTO and _EpisodicEncStorage:
            try:
                enc = _EpisodicEncStorage()
                if enc.is_available:
                    _episodic_encryption = enc
                    logger.info("EpisodicMemory encryption enabled")
                else:
                    logger.warning(
                        "FAMILIAR_ENCRYPTION_KEY set but encryption unavailable — "
                        "EpisodicMemory will use plaintext storage"
                    )
            except Exception as e:
                logger.warning(f"EpisodicMemory encryption init failed: {e}")
        _episodic_encryption_initialized = True
    return _episodic_encryption


class _GuardrailBlock(Exception):
    """
    Internal sentinel raised by _setup_request when a guardrail fires before
    the session is established.  Caught in chat() and chat_stream() and
    converted directly to a user-facing string — never propagates to callers.
    """


def _capture_context_from_result(
    tool_name: str,
    tool_input: dict,
    result,
    session,
    sessions_manager,
) -> None:
    """
    Phase-4 shared helper: write session_context keys from a tool result.
    Called from both _execute_tool_secure (normal path) and channel confirm
    handlers (Phase-2 re-execution path) so context capture fires regardless
    of execution path.
    """
    import datetime as _dt4h
    import threading as _thr4h

    if result is None or not isinstance(result, str):
        return

    # 1. Triage thread-local
    try:
        _tc = getattr(_thr4h.current_thread(), "_familiar_triage_ctx", None)
        if _tc and isinstance(_tc, dict) and _tc.get("emails"):
            session.session_context["triage_emails"] = _tc["emails"]
            session.session_context["triage_at"] = _dt4h.datetime.now(
                _dt4h.timezone.utc
            ).isoformat()
            _thr4h.current_thread()._familiar_triage_ctx = None
    except Exception:
        pass

    # 2. last_doc_id from drive_create_doc
    if tool_name == "drive_create_doc" and "   ID: " in result:
        try:
            for _ln in result.splitlines():
                if _ln.strip().startswith("ID: "):
                    _did = _ln.split("ID: ", 1)[1].strip()
                    if _did:
                        session.session_context["last_doc_id"] = _did
                        session.session_context["last_doc_title"] = (
                            tool_input.get("title", "") if tool_input else ""
                        )
                    break
        except Exception:
            pass

    # 3. last_event_title from create_event
    if tool_name == "create_event" and result.startswith("\u2705"):
        try:
            session.session_context["last_event_title"] = (
                tool_input.get("title", "") if tool_input else ""
            )
        except Exception:
            pass

    if sessions_manager is not None:
        try:
            sessions_manager.save_session(session)
        except Exception:
            pass


class Agent:
    """
    The main agent class.

    Usage:
        agent = Agent()
        response = agent.chat("Hello!", user_id="user123", channel="telegram")

    Security:
        Each user gets a SecureSession with trust level, capabilities, and budget.
        Tools are checked against capabilities before execution.
    """

    def __init__(
        self, config: Optional[Config] = None, security_mode: Optional[SecurityMode] = None
    ):
        self.config = config or load_config()

        # Initialize compliance mode
        self.compliance_mode = None
        self._compliance_profile = None
        self._audit_encrypted_storage = None
        self._compliance_audit_logger = None
        self._validate_compliance()

        # Initialize security
        self.security_mode = security_mode or SecurityMode(
            getattr(self.config.agent, "security_mode", "balanced")
        )
        self.sessions = SessionManager(self.security_mode)

        # Initialize components
        self.memory = Memory() if self.config.agent.memory_enabled else None
        self.history = ConversationHistory(max_per_chat=self.config.agent.max_conversation_history)

        # Initialize tool registry with sandboxed directories from config
        self.tools = get_tool_registry(sandboxed_dirs=self.config.agent.sandboxed_directories)

        self.skills = SkillLoader(self.config.agent.skills_dirs)
        self.scheduler = get_scheduler() if self.config.agent.scheduler_enabled else None

        # Set agent reference on scheduler for built-in handlers
        if self.scheduler:
            self.scheduler.set_agent(self)

            # Register compliance cleanup task when compliance mode is active
            if self.compliance_mode and self._compliance_profile:
                existing = self.scheduler.list_tasks()
                has_cleanup = any(t["name"] == "compliance_cleanup" for t in existing)
                if not has_cleanup:
                    from .scheduler import TaskFrequency, TaskType

                    retention = self._compliance_profile.data_retention_days or 365
                    self.scheduler.add_task(
                        name="compliance_cleanup",
                        description=f"Compliance data retention cleanup (max_age={retention} days)",
                        frequency=TaskFrequency.DAILY,
                        task_type=TaskType.CLEANUP,
                        payload={"max_age_days": retention},
                        time_of_day="03:00",
                    )
                    logger.info(f"Registered compliance_cleanup task (retention={retention} days)")

            # Auto-start the scheduler thread here so backup tasks and other
            # registered tasks fire on all deployments — not just CLI/Telegram.
            # Channels that want to register delivery callbacks before any task
            # fires can still call start_scheduler() again (idempotent — the
            # thread-alive check inside prevents double-starting the loop).
            self.scheduler.start()

        # Initialize tool router — pre-filters the tool list per message so the
        # LLM receives only the most relevant subset rather than all 189+ tools
        # a TRUSTED user would otherwise see.  Works without TOOLS.yaml guidance
        # via schema-based keyword scoring.
        #
        # Local models (Ollama) are much slower per input token, so we send
        # fewer tools to keep inference fast on CPU-only hardware.
        _is_local = (
            _OllamaProvider is not None
            and hasattr(self, "provider")
            and isinstance(self.provider, _OllamaProvider)
        ) or getattr(getattr(self.config, "llm", None), "default_provider", "") == "ollama"
        self.tool_router = ToolRouter(
            guidance=None,
            tool_registry=self.tools,
            config=RouterConfig(
                max_tools=6 if _is_local else 15,
                fallback_count=10 if _is_local else 20,
                confidence_threshold=0.10,
                min_routing_confidence=0.15,
                enabled=True,
            ),
        )

        # Initialize observability
        self.tracer = None  # Tracer disabled for compatibility

        # Initialize resilience config
        self.retry_config = (
            RetryConfig(
                max_attempts=self.config.resilience.max_attempts,
                base_delay=self.config.resilience.base_delay,
                max_delay=self.config.resilience.max_delay,
                exponential_base=self.config.resilience.exponential_base,
                jitter=self.config.resilience.jitter,
            )
            if self.config.resilience.enabled
            else None
        )

        # Initialize capacity tracker for proactive rate limit avoidance
        self.capacity_tracker = ProviderCapacityTracker()

        # Initialize LLM provider
        self.provider = self._init_provider()

        # Initialize model router for multi-LLM orchestration.
        # Routes queries to the best model based on complexity, privacy,
        # and cost. Falls back to self.provider if router not configured.
        self.model_router = None
        self._init_model_router()

        # Manual routing control: "auto" lets the router decide,
        # "manual" uses user-assigned provider per query category.
        self._routing_mode = "auto"
        self._manual_routes = {}  # maps QueryType value → model name

        # Initialize task planner (uses provider for plan generation)
        planning_enabled = getattr(self.config.agent, "planning_enabled", True)

        # Initialize agentic memory extractor (async post-conversation)
        extraction_enabled = getattr(self.config.agent, "memory_extraction_enabled", True)

        # Try to get a lightweight provider for background tasks.
        # Falls back to main provider if none configured.
        self._lightweight_provider = None
        if planning_enabled or extraction_enabled:
            try:
                from .providers import get_lightweight_provider

                self._lightweight_provider = get_lightweight_provider(self.config)
            except Exception as e:
                logger.debug(f"No lightweight provider: {e}")

        bg_provider = self._lightweight_provider or self.provider

        self.planner = (
            TaskPlanner(
                provider=bg_provider,
                enabled=planning_enabled,
            )
            if planning_enabled
            else None
        )

        self.memory_extractor = (
            MemoryExtractor(
                provider=bg_provider,
                memory=self.memory,
                enabled=extraction_enabled and self.memory is not None,
            )
            if extraction_enabled
            else None
        )

        # Load skills
        if self.config.agent.skills_enabled:
            self.skills.load_all()
            # Rebuild router index now that skill tools are registered
            self.tool_router._build_index()

        # Guardrails — content safety, PII, rate limits, token/cost/iteration caps.
        #
        # Limits come from agent config where present, falling back to sensible
        # defaults that match the existing session-level budget system.
        # All limits are permissive by default so existing behaviour is unchanged
        # unless the operator explicitly tightens them.
        guardrail_cfg = GuardrailConfig(
            max_tokens_per_request=getattr(self.config.agent, "guardrail_max_tokens", 200_000),
            max_cost_per_request=getattr(self.config.agent, "guardrail_max_cost_request", 2.00),
            max_cost_per_hour=getattr(self.config.agent, "guardrail_max_cost_hour", 20.00),
            max_cost_per_day=getattr(self.config.agent, "guardrail_max_cost_day", 100.00),
            max_iterations=getattr(self.config.agent, "max_iterations", 15),
            max_requests_per_minute=getattr(self.config.agent, "guardrail_rpm", 30),
            request_timeout_seconds=getattr(self.config.agent, "guardrail_timeout", 300.0),
            enable_content_filter=True,
            enable_pii_detection=getattr(self.config.agent, "enable_pii_detection", False),
            blocked_tools=getattr(self.config.agent, "blocked_tools", []),
            require_approval_tools=getattr(self.config.agent, "require_approval_tools", []),
        )
        self.guardrails = Guardrails(guardrail_cfg)

        # Propagate compliance mode to guardrails (HIPAA → PII BLOCK)
        if self.compliance_mode:
            self.guardrails.set_compliance_mode(self.compliance_mode)

        logger.debug(
            f"Guardrails active: rpm={guardrail_cfg.max_requests_per_minute} "
            f"max_iter={guardrail_cfg.max_iterations} "
            f"pii={'on' if guardrail_cfg.enable_pii_detection else 'off'}"
        )

        # EpisodicMemory — per-user MemorySystem instances, keyed by user_id.
        #
        # Stores conversation turns (user message + assistant response) with
        # decay, reinforcement, and working-memory recall across sessions.
        # Separate from core/memory.py (fact extraction) — episodic stores
        # *exchanges*, fact extraction stores *semantic facts*.
        #
        # Enabled only when memory_enabled is true (same gate as MemoryExtractor).
        # Each user gets their own MemorySystem so data is isolated.
        self._episodic_stores: Dict[str, EpisodicMemorySystem] = {}
        self._episodic_lock = threading.Lock()
        self._episodic_enabled = getattr(self.config.agent, "memory_enabled", True)
        self._episodic_dir = (
            Path.home() / ".familiar" / "episodic" if self._episodic_enabled else None
        )
        if self._episodic_enabled and self._episodic_dir:
            self._episodic_dir.mkdir(parents=True, exist_ok=True)
            logger.debug(f"EpisodicMemory active: store={self._episodic_dir}")

        # SagaOrchestrator — shared across requests, thread-safe internally.
        # Tools call tool_context["sagas"].run(saga, context) (sync bridge).
        # Skills register sagas at load time via agent.sagas.register(saga).
        # Uses InMemorySagaLog by default; swap for FileSagaLog for persistence.
        self.sagas = SagaOrchestrator(
            saga_log=InMemorySagaLog(),
            default_timeout=getattr(self.config.agent, "saga_default_timeout", 300.0),
        )
        logger.debug("SagaOrchestrator active (InMemorySagaLog)")

        # ExperimentManager — feature flags and A/B experiments.
        # Persists to disk so flags survive restarts.
        # Skills register flags at load time: agent.experiments.create_flag("my_feature")
        # Tool handlers check flags: tool_context["experiments"].is_enabled("flag", user_id)
        _exp_dir = Path.home() / ".familiar" / "experiments"
        _exp_dir.mkdir(parents=True, exist_ok=True)
        _exp_path = str(_exp_dir / "experiments.json")
        self.experiments = ExperimentManager(persistence_path=_exp_path)
        set_experiment_manager(self.experiments)
        logger.debug(f"ExperimentManager active: store={_exp_path}")

        # ── Orchestrator ──────────────────────────────────────────────────────
        # Multi-agent coordination: HIERARCHICAL, CONSENSUS, DEBATE strategies.
        # RemoteAgents (mesh peers) auto-register here when they connect.
        self.orchestrator = Orchestrator()

        # ── SkillBus ──────────────────────────────────────────────────────────
        # Inter-skill communication: pub/sub events, direct invocation with
        # retry + dead-letter queue, shared state, workflow orchestration.
        #
        # Skills register actions at load time:
        #   agent.bus.register_skill("donor", {"intake": handle_intake})
        #
        # Tools fire events after execution (tool.executed topic).
        # Subscribers react without the LLM needing to chain calls manually:
        #   agent.bus.subscribe("donor.intake.completed", trigger_crm_update)
        #   agent.bus.subscribe("triage.case.created", assign_to_volunteer)
        #
        # Module-level publish()/subscribe()/invoke() route to this instance.
        self.bus = SkillBus(
            async_processing=True,
            dead_letter_queue_size=1000,
        )
        set_skill_bus(self.bus)  # wire module-level helpers
        logger.debug("SkillBus active: pub/sub, invoke, workflows, shared state, DLQ")

        # ── SemanticRetriever (RAG pipeline) ──────────────────────────────────
        # Chunked document retrieval for arbitrary knowledge sources:
        # org handbooks, grant guidelines, donor intake forms, policy docs.
        #
        # Uses the same embedding provider cascade as memory:
        #   Ollama (nomic-embed-text) → ONNX → HTTP endpoint → Voyage → OpenAI → TF-IDF
        #
        # Skills and tools add documents at load time or runtime:
        #   agent.retriever.add_text("Grant eligibility: ...", metadata={"source": "smith_foundation"})
        #
        # The current message is used to retrieve top-k relevant chunks
        # that are injected into the LLM system prompt alongside memory.
        #
        # Accessible as tool_context["retriever"] — tools add docs on demand:
        #   tool_context["retriever"].add_text(fetched_doc, metadata={"url": url})
        #   results = tool_context["retriever"].retrieve("query", top_k=5)
        self.retriever: SemanticRetriever = self._init_retriever()
        _emb_name = (
            type(self.memory._embedder).__name__
            if (self.memory and self.memory._embedder)
            else "TFIDFEmbeddings"
        )
        logger.debug(f"SemanticRetriever active: {_emb_name} embeddings")

        # ── HealthChecker ─────────────────────────────────────────────────────
        # Liveness / readiness / startup probes for Kubernetes, Docker, Fly.io.
        # Agent-aware checks registered here:
        #   filesystem   — always registered (built-in)
        #   llm_provider — checks provider connectivity
        #   memory_agent — checks background extraction thread
        #   planner      — checks for stuck plans
        #   bus          — checks SkillBus worker thread
        #
        # Expose via tool_context["health"] so skills can register custom checks.
        # Call agent.mark_ready() once your entry point finishes init.
        #
        # HTTP probes (Kubernetes):
        #   GET /healthz         → liveness_check()
        #   GET /readyz          → readiness_check()
        #   GET /startupz        → startup_check()
        #   GET /health          → check_health() (full report)
        # ── MetricsCollector ──────────────────────────────────────────────────
        # Per-call tool latency (p50/p95/p99), success rates, error counts.
        # Per-call LLM latency, token usage, cost tracking.
        # Custom counters, gauges, histograms for skill-level metrics.
        # Alert thresholds fire callbacks when failure rates exceed limits.
        #
        # Automatically records every tool call via _execute_tool_secure.
        # Automatically records every LLM chat call in _run_agent_loop.
        # Accessible via tool_context["metrics"] for skill-level recording.
        self.metrics: MetricsCollector = get_metrics_collector()
        logger.debug("MetricsCollector active: tool + LLM call recording enabled")

        # ── BackupManager ─────────────────────────────────────────────────────
        # Encrypted incremental backups of all user data:
        #   memory.json           — semantic facts
        #   episodic/*.json(.enc) — per-user conversation history
        #   history.json          — global conversation log
        #   users.db              — user database
        #   analytics.db          — analytics
        #   skills/               — skill data
        #
        # Disabled by default (no-op BackupManager) — enable via config:
        #   config.backup.enabled = True
        #   config.backup.encrypt = True
        #   config.backup.encryption_key = Fernet.generate_key().decode()
        #   config.backup.path = Path("/var/backups/familiar")
        #
        # Manual trigger: agent.create_backup()
        # Restore:        agent.restore_backup(backup_id)
        # Health check:   agent.get_health_status()  (backup_freshness dep)
        self.backup: BackupManager = self._init_backup()
        logger.debug("BackupManager active: data protection enabled")

        # Register scheduled backup task when both backup and scheduler enabled.
        # Safe to call here: scheduler exists (wired above), backup exists,
        # episodic_dir is set. _schedule_backup is a no-op if scheduler=None.
        if getattr(self.backup.config, "enabled", False) and self.scheduler is not None:
            self._schedule_backup()

        # ── HealthChecker — MUST come after backup, metrics, retriever ─────────
        # _init_health_checker references self.backup, self.bus, self.planner,
        # self.memory — all must exist before this call.
        self.health: HealthChecker = self._init_health_checker()
        logger.debug("HealthChecker active: liveness/readiness/startup probes registered")

        # ── Mesh Gateway ──────────────────────────────────────────────────────
        # NOT started here — mesh binds a port and needs an event loop.
        # Call agent.start_mesh() from your entry point when ready.
        #
        # Enabled by:  FAMILIAR_MESH_ENABLED=true  (env var)
        #              or config.agent.mesh_enabled = True
        #
        # Default port: 18789 (configurable via FAMILIAR_MESH_PORT)
        _mesh_enabled = getattr(self.config.agent, "mesh_enabled", False) or os.environ.get(
            "FAMILIAR_MESH_ENABLED", ""
        ).lower() in ("1", "true", "yes")
        _mesh_host = os.environ.get("FAMILIAR_MESH_HOST", "127.0.0.1")
        _mesh_port = int(os.environ.get("FAMILIAR_MESH_PORT", "18789"))

        self.mesh_gateway: Optional[MeshGateway] = None
        self._mesh_enabled = _mesh_enabled
        self._mesh_host = _mesh_host
        self._mesh_port = _mesh_port

        if _mesh_enabled:
            self.mesh_gateway = MeshGateway(self, host=_mesh_host, port=_mesh_port)
            # Wire orchestrator so RemoteAgents auto-register on peer connect
            self.mesh_gateway.set_orchestrator(self.orchestrator)
            # Wire memory bridge if memory is available
            if self.memory is not None:
                hipaa = getattr(self.config.agent, "hipaa_enabled", False) or os.environ.get(
                    "FAMILIAR_HIPAA", ""
                ).lower() in ("1", "true", "yes")
                self.mesh_gateway.init_memory_bridge(self.memory, hipaa_enabled=hipaa)
            logger.info(
                f"Mesh gateway configured: {_mesh_host}:{_mesh_port} "
                f"(call start_mesh() to activate)"
            )
        else:
            logger.debug("Mesh disabled. Set FAMILIAR_MESH_ENABLED=true to enable.")

        # Log initialization summary
        encryption_status = "encrypted" if is_encryption_enabled() else "unencrypted"
        compliance_status = self.compliance_mode.value if self.compliance_mode else "none"
        logger.info(
            f"Agent initialized: provider={self.provider.name}, "
            f"security={self.security_mode.value}, "
            f"compliance={compliance_status}, "
            f"storage={encryption_status}"
        )

        # Mark startup complete — readiness probe returns ready=True from here.
        self.health.mark_startup_complete()

    def _get_episodic_memory(self, user_id: str) -> Optional[EpisodicMemorySystem]:
        """
        Return the EpisodicMemorySystem for this user, creating and loading
        it from disk on first access.

        Load order (mirrors core/memory.py):
        1. {user_id}.json.enc  — encrypted, tried first if encryption available
        2. {user_id}.json      — plaintext fallback / migration source

        Returns None if episodic memory is disabled.
        Thread-safe: double-checked locking on _episodic_lock.
        """
        if not self._episodic_enabled or self._episodic_dir is None:
            return None

        uid = str(user_id)
        if uid in self._episodic_stores:
            return self._episodic_stores[uid]

        with self._episodic_lock:
            # Double-check after acquiring lock
            if uid in self._episodic_stores:
                return self._episodic_stores[uid]

            ms = EpisodicMemorySystem(
                max_memories=getattr(self.config.agent, "episodic_max_memories", 5000),
                working_memory_size=getattr(self.config.agent, "episodic_working_size", 20),
                decay_rate=getattr(self.config.agent, "episodic_decay_rate", 0.05),
            )

            # Sanitize uid for filesystem safety (prevent path traversal)
            import re

            safe_uid = re.sub(r"[^a-zA-Z0-9_\-.]", "_", uid)
            enc_path = self._episodic_dir / f"{safe_uid}.json.enc"
            plain_path = self._episodic_dir / f"{safe_uid}.json"
            loaded = False

            # ── Try encrypted file first ──────────────────────────────
            encryption = _get_episodic_encryption()
            if encryption and encryption.is_available and enc_path.exists():
                try:
                    encrypted_data = enc_path.read_text()
                    json_data = encryption.decrypt(encrypted_data)
                    data = json.loads(json_data)
                    ms.import_memories(data)
                    loaded = True
                    logger.debug(
                        f"EpisodicMemory loaded (encrypted) "
                        f"{ms.get_stats().get('total_stored', 0)} memories for user {uid}"
                    )
                except Exception as e:
                    logger.error(f"EpisodicMemory failed to load encrypted file for {uid}: {e}")
                    # Don't fall through to plaintext — encrypted file exists
                    # but is unreadable, safer to start fresh than leak data
                    loaded = False

            # ── Fall back to plaintext ────────────────────────────────
            if not loaded and plain_path.exists():
                try:
                    persistence = EpisodicPersistence(str(plain_path))
                    loaded = persistence.load(ms)
                    if loaded:
                        logger.debug(
                            f"EpisodicMemory loaded (plaintext) "
                            f"{ms.get_stats().get('total_stored', 0)} memories for user {uid}"
                        )
                        # If encryption is now available, migrate on next save
                        if encryption and encryption.is_available:
                            logger.info(
                                f"EpisodicMemory: plaintext found for {uid}, "
                                f"will migrate to encrypted on next save"
                            )
                except Exception as e:
                    logger.error(f"EpisodicMemory failed to load plaintext file for {uid}: {e}")

            self._episodic_stores[uid] = ms
            return ms

    def _save_episodic_memory_async(self, user_id: str):
        """
        Persist the user's EpisodicMemorySystem to disk in a daemon thread.

        Encryption behaviour mirrors core/memory.py:
        - If FAMILIAR_ENCRYPTION_KEY is set and cryptography is installed:
            → serialize to JSON → encrypt → write {user_id}.json.enc (atomic)
            → chmod 0o600
        - Otherwise:
            → write {user_id}.json (plaintext)

        Never blocks response finalization — fires in a daemon thread.
        """
        ms = self._episodic_stores.get(str(user_id))
        if ms is None or self._episodic_dir is None:
            return

        # Sanitize uid for filesystem safety (prevent path traversal)
        import re

        safe_uid = re.sub(r"[^a-zA-Z0-9_\-.]", "_", str(user_id))
        plaintext_path = self._episodic_dir / f"{safe_uid}.json"
        enc_path = self._episodic_dir / f"{safe_uid}.json.enc"

        # Snapshot data on the calling thread to avoid racing with mutations
        try:
            snapshot = ms.export()
        except Exception as e:
            logger.warning(f"EpisodicMemory export failed for {user_id}: {e}")
            return

        def _save():
            try:
                json_data = json.dumps(snapshot, indent=2, default=str)
                encryption = _get_episodic_encryption()

                if encryption and encryption.is_available:
                    # ── Encrypted path ───────────────────────────────────
                    # Backup existing .enc before overwrite
                    if enc_path.exists():
                        backup = enc_path.with_suffix(".enc.bak")
                        try:
                            import shutil

                            shutil.copy2(enc_path, backup)
                        except Exception:
                            pass

                    encrypted_data = encryption.encrypt(json_data)
                    tmp_path = enc_path.with_suffix(".enc.tmp")
                    tmp_path.write_text(encrypted_data)
                    tmp_path.chmod(0o600)
                    tmp_path.replace(enc_path)

                    # Remove any leftover plaintext file (migration case)
                    if plaintext_path.exists():
                        plaintext_path.unlink(missing_ok=True)

                    logger.debug(f"EpisodicMemory saved (encrypted) for user {user_id}")
                else:
                    # ── Plaintext path ───────────────────────────────────
                    tmp_path = plaintext_path.with_suffix(".json.tmp")
                    tmp_path.write_text(json_data)
                    tmp_path.replace(plaintext_path)
                    logger.debug(f"EpisodicMemory saved (plaintext) for user {user_id}")

            except Exception as e:
                logger.warning(f"EpisodicMemory save failed for {user_id}: {e}")

        t = threading.Thread(target=_save, daemon=True)
        t.start()

    def set_tool_event_callback(
        self,
        user_id: str,
        callback: "Callable[[ExecutionEvent], None]",
    ):
        """
        Register a callback to receive ExecutionEvent objects for a user's
        tool executions. Called for every TOOL_START, TOOL_PROGRESS,
        TOOL_COMPLETE, TOOL_ERROR, and any other events tools emit.

        Replaces any existing callback for that user. Pass None to remove.

        Typical use — stream progress to a WebSocket before a request:

            agent.set_tool_event_callback(
                user_id,
                lambda evt: websocket.send_json(evt.to_dict())
            )
            result = agent.chat(message, user_id=user_id)
            agent.set_tool_event_callback(user_id, None)  # clean up

        Thread-safe: callbacks dict is protected by a lock.
        """
        if not hasattr(self, "_tool_event_callbacks"):
            self._tool_event_callbacks: Dict[str, Any] = {}
        if not hasattr(self, "_tool_event_callbacks_lock"):
            self._tool_event_callbacks_lock = threading.Lock()
        with self._tool_event_callbacks_lock:
            if callback is None:
                self._tool_event_callbacks.pop(str(user_id), None)
            else:
                self._tool_event_callbacks[str(user_id)] = callback

    def clear_tool_event_callback(self, user_id: str):
        """Remove the tool event callback for a user. No-op if not set."""
        self.set_tool_event_callback(user_id, None)

    def run_saga(
        self,
        saga: "Saga",
        context: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> "SagaExecution":
        """
        Execute a saga synchronously from sync tool-handler context.

        SagaOrchestrator.execute() is async. Tool handlers run in the agent's
        sync call path, so a direct ``await`` is not possible. This bridge
        runs the coroutine in a dedicated thread with its own event loop —
        safe regardless of whether an outer loop is running.

        Args:
            saga:    Saga definition (built with SagaBuilder or inline).
            context: Initial context dict passed to every step.
            timeout: Override saga-level timeout (seconds). None = saga default.

        Returns:
            SagaExecution with .status, .current_context, .step_executions, etc.

        Example (inside a tool handler)::

            def process_donor_intake(input_data, tool_context):
                agent = tool_context["agent"]
                saga = (
                    SagaBuilder("donor_intake")
                    .add_step("validate",  validate_donor,   undo_validate)
                    .add_step("crm_add",   add_to_crm,       remove_from_crm)
                    .add_step("welcome",   send_welcome,      None)
                    .add_step("schedule",  schedule_followup, cancel_followup)
                    .build()
                )
                execution = agent.run_saga(saga, context={
                    "donor": input_data,
                    "user_id": tool_context["user_id"],
                })
                if execution.status == SagaStatus.COMPLETED:
                    return json.dumps({"ok": True, "id": execution.execution_id})
                return json.dumps({"error": execution.error, "status": execution.status})
        """
        import asyncio
        import concurrent.futures

        async def _run():
            if timeout is not None:
                # Temporarily override saga timeout for this call
                original = saga.timeout_seconds
                saga.timeout_seconds = timeout
                try:
                    return await self.sagas.execute(saga, context)
                finally:
                    saga.timeout_seconds = original
            return await self.sagas.execute(saga, context)

        # Always run in a new thread with its own loop — avoids "cannot run
        # nested event loop" errors when called from within an existing loop.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            fut = pool.submit(lambda: asyncio.run(_run()))
            eff_timeout = timeout or saga.timeout_seconds + 5  # +5s grace
            try:
                return fut.result(timeout=eff_timeout)
            except concurrent.futures.TimeoutError:
                logger.error(f"run_saga timed out after {eff_timeout}s: {saga.name}")
                # Return a synthetic timeout execution
                exec_ = SagaExecution(saga_name=saga.name)
                exec_.mark_timeout()
                return exec_

    # ── Mesh lifecycle ──────────────────────────────────────────────────────

    async def start_mesh(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> None:
        """
        Start the mesh gateway WebSocket server.

        Must be called from an async context (e.g. inside an asyncio.run() or
        existing event loop). Binds the port and begins accepting connections.

        If mesh was not enabled at __init__ time (FAMILIAR_MESH_ENABLED not set),
        this method will create and start a gateway on demand.

        Args:
            host: Override the host (default: value from env/config)
            port: Override the port (default: value from env/config)

        Example::

            async def main():
                agent = Agent()
                await agent.start_mesh()          # runs forever
                # or run other tasks alongside:
                await asyncio.gather(
                    agent.start_mesh(),
                    my_telegram_bot.run(),
                )
        """
        import asyncio as _asyncio

        _host = host or self._mesh_host
        _port = port or self._mesh_port

        if self.mesh_gateway is None:
            self.mesh_gateway = MeshGateway(self, host=_host, port=_port)
            self.mesh_gateway.set_orchestrator(self.orchestrator)
            if self.memory is not None:
                hipaa = getattr(self.config.agent, "hipaa_enabled", False) or os.environ.get(
                    "FAMILIAR_HIPAA", ""
                ).lower() in ("1", "true", "yes")
                self.mesh_gateway.init_memory_bridge(self.memory, hipaa_enabled=hipaa)

        logger.info(f"Starting mesh gateway on {_host}:{_port}")
        await self.mesh_gateway.start()

        try:
            while True:
                await _asyncio.sleep(1)
        except (KeyboardInterrupt, _asyncio.CancelledError):
            logger.info("Mesh gateway shutting down...")
            await self.mesh_gateway.stop()

    async def stop_mesh(self) -> None:
        """Stop the mesh gateway and disconnect all peers."""
        if self.mesh_gateway and self.mesh_gateway._running:
            await self.mesh_gateway.stop()
            logger.info("Mesh gateway stopped")

    def get_mesh_context(self, query: str, timeout: float = 1.5) -> str:
        """
        Query peer memories relevant to the current conversation turn.

        Called from get_system_prompt() when mesh is active and memory
        bridge is wired. Returns a formatted string injected into the
        LLM system prompt so the model sees cross-device context.

        Returns "" if mesh is not active, HIPAA mode is on, or no
        relevant memories are found within the timeout.

        Args:
            query:   The user's current message (used as search query)
            timeout: Max seconds to wait for peer responses (default 1.5)
        """
        if not self.mesh_gateway:
            return ""
        bridge = getattr(self.mesh_gateway, "memory_bridge", None)
        if bridge is None:
            return ""
        try:
            return bridge.get_mesh_context(query, timeout=timeout)
        except Exception as e:
            logger.debug(f"Mesh context fetch failed: {e}")
            return ""

    def get_mesh_status(self) -> dict:
        """
        Return a dict describing current mesh state.

        Suitable for admin dashboards, CLI /mesh status commands,
        and health checks. Safe to call when mesh is not running.
        """
        if not self.mesh_gateway:
            return {"enabled": False, "running": False}

        gw = self.mesh_gateway
        trust_status = {}
        if gw.trust_manager:
            try:
                trust_status = gw.trust_manager.get_status()
            except Exception:
                pass

        memory_status = {}
        if gw.memory_bridge:
            try:
                memory_status = gw.memory_bridge.get_status()
            except Exception:
                pass

        return {
            "enabled": True,
            "running": gw._running,
            "host": gw.host,
            "port": gw.port,
            "node_id": gw.config.get("node_id", "")[:8] + "...",
            "node_name": gw.config.get("node_name", "familiar"),
            "connected_nodes": len(gw.nodes),
            "peer_gateways": len(gw.peer_gateways),
            "discovery_active": gw.discovery is not None,
            "trust": trust_status,
            "memory": memory_status,
            "remote_agents": len(
                [
                    a
                    for a in self.orchestrator.registry.get_all()
                    if getattr(a, "_metadata", {}).get("remote")
                ]
            ),
        }

    # ════════════════════════════════════════════════════════════════
    # BACKUP
    # ════════════════════════════════════════════════════════════════

    def _init_backup(self) -> BackupManager:
        """
        Create and configure the BackupManager for this agent.

        Configuration comes from config.backup (if present) with safe defaults:
          - enabled:          False (opt-in — no surprise disk writes)
          - path:             ~/.familiar/backups
          - encrypt:          False (opt-in — requires cryptography package)
          - retention_days:   30
          - include_history:  True
          - include_audit:    True

        The BackupManager is always created (never None) so agent.backup is safe
        to call even when backup is disabled — create_backup() will still work,
        it just won't be triggered automatically.

        Episodic memory directory is threaded through so the manager knows where
        per-user recalled conversation files live.
        """
        backup_cfg_raw = getattr(self.config, "backup", None)
        if backup_cfg_raw is not None and hasattr(backup_cfg_raw, "__dict__"):
            try:
                raw_dict = {k: v for k, v in vars(backup_cfg_raw).items() if not k.startswith("_")}
                # Convert path string -> Path (BackupConfig expects Path)
                raw_path = raw_dict.get("path", "")
                if not raw_path:
                    raw_dict["path"] = Path.home() / ".familiar" / "backups"
                else:
                    raw_dict["path"] = Path(raw_path)
                # Empty encryption_key -> None so Fernet isn't called with ''
                if not raw_dict.get("encryption_key", ""):
                    raw_dict["encryption_key"] = None
                # Empty s3_bucket -> None
                if not raw_dict.get("s3_bucket", ""):
                    raw_dict["s3_bucket"] = None
                # Only pass fields BackupConfig knows about
                valid_fields = set(BackupConfig.__dataclass_fields__)
                bc = BackupConfig(**{k: v for k, v in raw_dict.items() if k in valid_fields})
            except Exception as _bc_err:
                logger.debug(f"BackupConfig from agent config failed ({_bc_err}), using defaults")
                bc = BackupConfig()
        else:
            bc = BackupConfig()

        manager = BackupManager(config=bc)
        # Pass episodic dir so _backup_episodic knows where to look
        manager._episodic_dir = self._episodic_dir

        return manager

    def create_backup(
        self,
        backup_type: BackupType = BackupType.FULL,
        description: Optional[str] = None,
    ) -> "BackupManifest":
        """
        Create a backup of all agent data immediately.

        Captures:
          - memory.json          (semantic facts per user)
          - episodic/*.json(.enc) (per-user conversation history — highest priority)
          - history.json          (global conversation log)
          - users.db              (user database, if present)
          - analytics.db          (analytics, if present)
          - audit.db              (audit log, if present)
          - skills/               (skill data, if present)
          - config.yaml           (configuration, for FULL backup)

        Args:
            backup_type: FULL (default), DATA_ONLY, or CONFIG_ONLY
            description: Optional label stored in manifest

        Returns:
            BackupManifest with status, file list, checksum, and timing.

        Example::

            manifest = agent.create_backup()
            print(f"Backup {manifest.id}: {manifest.file_count} files, "
                  f"{manifest.total_size} bytes")
        """
        manifest = self.backup.create_backup(
            backup_type=backup_type,
            description=description,
        )
        # Register freshness with health checker
        if hasattr(self, "health"):
            self.health._cached_result = None  # bust cache so next check is fresh
        logger.info(
            f"Backup created: {manifest.id} "
            f"({manifest.file_count} files, {manifest.total_size} bytes, "
            f"status={manifest.status.value})"
        )
        return manifest

    def restore_backup(
        self,
        backup_id: str,
        target_dir: Optional[Path] = None,
        dry_run: bool = False,
    ) -> dict:
        """
        Restore agent data from a backup.

        WARNING: Overwrites current data files. Call create_backup() first to
        snapshot current state before restoring an older backup.

        Args:
            backup_id: Backup ID from list_backups() or create_backup().id
            target_dir: Optional directory to restore into. Default: original
                        data paths (~/.familiar/data, ~./familiar/episodic).
            dry_run:    If True, simulate and count files without writing.

        Returns:
            Dict with files_restored count, errors list, dry_run flag.
        """
        result = self.backup.restore(
            backup_id=backup_id,
            target_dir=target_dir,
            dry_run=dry_run,
        )
        if not dry_run:
            logger.warning(
                f"Backup restored: {backup_id} ({result.get('files_restored', 0)} files written)"
            )
        return result

    def list_backups(self) -> list:
        """
        Return all available backup manifests, newest first.

        Each manifest has:
            id, created_at, backup_type, status, file_count,
            total_size, encrypted, compressed, duration_seconds

        Example::

            for b in agent.list_backups():
                print(f"{b.id}  {b.backup_type.value}  "
                      f"{b.file_count} files  {b.status.value}")
        """
        return self.backup.list_backups()

    def verify_backup(self, backup_id: str) -> dict:
        """
        Verify the integrity of a backup archive.

        Checks that the archive exists on disk and the manifest is readable.
        Returns a result dict with ``valid`` bool, file count, size, and
        encryption flag.  On success, also updates the manifest status to
        VERIFIED so the health probe can report freshness correctly.

        Args:
            backup_id: ID from list_backups() or create_backup().id

        Returns:
            Dict with ``valid``, ``backup_id``, ``created_at``, ``size``,
            ``files``, ``encrypted``.  ``valid=False`` includes an ``error``
            key describing the problem.

        Example::

            result = agent.verify_backup("20260220_030000")
            if result["valid"]:
                print(f"OK — {result['files']} files, {result['size']} bytes")
            else:
                print(f"CORRUPT: {result['error']}")
        """
        return self.backup.verify_backup(backup_id)

    def cleanup_old_backups(self) -> int:
        """
        Delete backups older than config.backup.retention_days (default 30).

        Returns the number of backup archives deleted.  Safe to call at any
        time — only removes archives whose manifest ``created_at`` predates
        the retention window.

        Example::

            deleted = agent.cleanup_old_backups()
            print(f"Pruned {deleted} old backups")
        """
        return self.backup.cleanup_old_backups()

    def _schedule_backup(self) -> None:
        """
        Register a recurring backup task with the scheduler.

        Called from __init__ when both backup.enabled and scheduler are active.
        The schedule is driven by config.backup.schedule:
          daily   → runs at 03:00 each night (TaskFrequency.DAILY, time_of_day="03:00")
          hourly  → runs at the top of each hour (TaskFrequency.HOURLY)
          weekly  → runs at 03:00 on Sundays (TaskFrequency.DAILY every 7 days)

        A cleanup task is also registered to prune backups older than
        retention_days.

        Both tasks are silent if the scheduler has already registered tasks
        with the same name (idempotent on re-init).
        """
        if self.scheduler is None:
            return

        schedule = getattr(self.backup.config, "schedule", "daily")

        # Map schedule string to TaskFrequency
        if schedule == "hourly":
            freq = TaskFrequency.HOURLY
            kwargs: dict = {}
        else:
            # daily and weekly both use DAILY with time_of_day; weekly is
            # handled by cleanup running every day but retention_days controls
            # the window (weekly schedule is just daily with longer retention)
            freq = TaskFrequency.DAILY
            kwargs = {"time_of_day": "03:00"}

        _backup_ref = self.backup

        def _run_scheduled_backup():
            try:
                manifest = _backup_ref.create_backup(BackupType.FULL)
                logger.info(
                    f"Scheduled backup completed: {manifest.id} "
                    f"({manifest.file_count} files, {manifest.total_size} bytes)"
                )
                # Prune old backups after each successful backup
                _backup_ref.cleanup_old_backups()
            except Exception as e:
                logger.error(f"Scheduled backup failed: {e}")

        self.scheduler.add_task(
            name="familiar_auto_backup",
            description=f"Automatic {schedule} backup of all agent data",
            frequency=freq,
            callback=_run_scheduled_backup,
            **kwargs,
        )
        logger.info(f"Scheduled {schedule} backup registered (03:00 daily)")

    # ════════════════════════════════════════════════════════════════
    # HEALTH CHECKER
    # ════════════════════════════════════════════════════════════════

    def _init_health_checker(self) -> HealthChecker:
        """
        Create and configure the HealthChecker with agent-aware dependency checks.

        Built-in checks registered here:
          filesystem   — write/read /tmp, always registered by HealthChecker itself
          llm_provider — verifies provider has API key / is reachable
          memory_agent — background extraction thread liveness + last-error
          planner      — no plans stuck > 30 min
          bus          — SkillBus worker thread alive

        The version string is taken from the package __version__ if available,
        falling back to "unknown". Cache TTL is 10 s — cheap for polling probes.
        """
        try:
            from familiar import __version__ as _ver
        except Exception:
            _ver = "unknown"

        hc = HealthChecker(
            version=_ver,
            check_timeout_seconds=5.0,
            cache_ttl_seconds=10.0,
        )

        # ── LLM provider ─────────────────────────────────────────────────────
        # Checks that the configured provider has an API key set (or is local).
        provider_name = getattr(self.provider, "name", "unknown")

        def _check_provider() -> DependencyHealth:
            # Local providers (ollama, llamacpp) are always reachable when configured.
            local_names = ("ollama", "llamacpp", "local", "mock")
            if any(n in provider_name.lower() for n in local_names):
                return DependencyHealth(
                    name="llm_provider",
                    healthy=True,
                    message=f"Local provider '{provider_name}' configured",
                    dependency_type=DependencyType.LLM_PROVIDER,
                    details={"provider": provider_name, "local": True},
                )
            # Cloud providers need an API key
            key_env = {
                "anthropic": "ANTHROPIC_API_KEY",
                "openai": "OPENAI_API_KEY",
                "gemini": "GOOGLE_API_KEY",
            }.get(provider_name.lower(), "")
            key_set = bool(os.environ.get(key_env)) if key_env else True
            return DependencyHealth(
                name="llm_provider",
                healthy=key_set,
                message=(
                    f"Provider '{provider_name}' ready"
                    if key_set
                    else f"Provider '{provider_name}' missing {key_env}"
                ),
                dependency_type=DependencyType.LLM_PROVIDER,
                details={"provider": provider_name, "key_env": key_env, "key_set": key_set},
            )

        hc.register_dependency_check("llm_provider", _check_provider, DependencyType.LLM_PROVIDER)

        # ── SkillBus ─────────────────────────────────────────────────────────
        _bus = self.bus

        def _check_bus() -> DependencyHealth:
            running = getattr(_bus, "_running", False) or (
                hasattr(_bus, "_worker") and _bus._worker is not None and _bus._worker.is_alive()
            )
            return DependencyHealth(
                name="bus",
                healthy=running,
                message="SkillBus worker running" if running else "SkillBus worker not running",
                dependency_type=DependencyType.INTERNAL,
                details={"running": running},
            )

        hc.register_dependency_check("bus", _check_bus, DependencyType.INTERNAL)

        # ── Memory agent ─────────────────────────────────────────────────────
        if self.memory is not None:
            _mem_agent = getattr(self.memory, "_memory_agent", None) or getattr(
                self.memory, "_agent", None
            )
            if _mem_agent is not None:
                hc.register_dependency_check(
                    "memory_agent",
                    create_memory_agent_health_check(_mem_agent),
                    DependencyType.INTERNAL,
                )

        # ── Planner ──────────────────────────────────────────────────────────
        if self.planner is not None:
            hc.register_dependency_check(
                "planner",
                create_planner_health_check(self.planner),
                DependencyType.INTERNAL,
            )

        # ── Backup freshness ──────────────────────────────────────────────────
        # Healthy: at least one completed backup exists AND the most recent one
        # is within 2× the configured retention period (generous threshold —
        # we just want to surface "never backed up" and "backup very stale").
        # Reports "no backups yet" on a fresh install, which is informational
        # rather than critical: healthy=True so it doesn't break readiness.
        _backup_mgr = self.backup

        def _check_backup_freshness() -> DependencyHealth:
            try:
                backups = _backup_mgr.list_backups()
            except Exception as e:
                return DependencyHealth(
                    name="backup_freshness",
                    healthy=False,
                    message=f"Could not list backups: {e}",
                    dependency_type=DependencyType.INTERNAL,
                )
            if not backups:
                return DependencyHealth(
                    name="backup_freshness",
                    healthy=True,  # informational — fresh install
                    message="No backups yet. Call agent.create_backup() to protect data.",
                    dependency_type=DependencyType.INTERNAL,
                    details={"backup_count": 0},
                )
            latest = backups[0]
            age_days = (
                datetime.now(_dt_timezone.utc).replace(tzinfo=None) - latest.created_at
            ).total_seconds() / 86400
            retention = getattr(_backup_mgr.config, "retention_days", 30)
            stale_threshold_days = retention * 2
            healthy = age_days <= stale_threshold_days
            return DependencyHealth(
                name="backup_freshness",
                healthy=healthy,
                message=(
                    f"Latest backup: {latest.id} ({age_days:.1f} days ago, "
                    f"status={latest.status.value})"
                ),
                dependency_type=DependencyType.INTERNAL,
                details={
                    "backup_count": len(backups),
                    "latest_id": latest.id,
                    "latest_status": latest.status.value,
                    "age_days": round(age_days, 1),
                    "stale_threshold_days": stale_threshold_days,
                },
            )

        hc.register_dependency_check(
            "backup_freshness", _check_backup_freshness, DependencyType.INTERNAL
        )

        return hc

    def mark_ready(self) -> None:
        """
        Explicitly mark the agent as ready for traffic.

        `__init__` calls this automatically. Call it again from your entry
        point if you add post-init setup that must complete before the agent
        handles requests (e.g. loading a large knowledge base into retriever).

        After this call, readiness_check() returns ready=True and Kubernetes
        will route traffic to the pod.
        """
        self.health.mark_startup_complete()
        logger.info("Agent marked ready (readiness probe will return ready=True)")

    def liveness(self) -> dict:
        """
        Liveness probe. Kubernetes calls this to decide whether to restart a pod.

        Returns {"status": "ok", "timestamp": "..."} as long as the process
        can allocate memory and execute code. Only fails if the process is
        deadlocked or OOM-killed.

        Maps to:  GET /healthz
        """
        return self.health.liveness_check()

    def readiness(self) -> dict:
        """
        Readiness probe. Kubernetes calls this to decide whether to send traffic.

        Returns ready=True once startup is complete and all critical dependencies
        are healthy. Returns ready=False (and removes pod from load balancer) if
        the LLM provider key is missing or the filesystem is unhealthy.

        Maps to:  GET /readyz
        """
        return self.health.readiness_check()

    def startup_probe(self) -> dict:
        """
        Startup probe. Kubernetes calls this during pod startup.

        Returns started=True once __init__ completes. Before that, Kubernetes
        will not run liveness or readiness checks (gives slow-starting pods time
        to initialize without being killed).

        Maps to:  GET /startupz
        """
        return self.health.startup_check()

    def get_health_status(self, include_resources: bool = True) -> dict:
        """
        Full health report as a plain dict — suitable for a /health endpoint,
        logging, dashboards, or operator tooling.

        Keys:
          status          — "healthy" | "degraded" | "unhealthy"
          healthy         — bool
          message         — human-readable summary
          version         — package version string
          uptime_seconds  — seconds since Agent.__init__ completed
          dependencies    — list of {name, healthy, status, latency_ms, message, type}
          resources       — {cpu, memory, disk, process} (None if psutil not installed)
          timestamp       — ISO-8601 check time

        Args:
          include_resources: Set False to skip psutil resource collection
                             (faster, useful for high-frequency polling).
        """
        return self.health.check_health(
            include_resources=include_resources,
            use_cache=True,
        ).to_dict()

    # ════════════════════════════════════════════════════════════════
    # SEMANTIC RETRIEVER (RAG)
    # ════════════════════════════════════════════════════════════════

    def _init_retriever(self) -> SemanticRetriever:
        """
        Create a SemanticRetriever backed by the same embedding provider
        cascade that memory uses.

        The bridge adapter makes embeddings.EmbeddingProvider satisfy
        context.EmbeddingProvider's interface — they share the same abstract
        surface (embed, embed_batch) but have different ABC hierarchies and
        one uses .dimensions vs .dimension.
        """

        class _EmbeddingBridge(ContextEmbeddingProvider):
            """Adapt embeddings.EmbeddingProvider → context.EmbeddingProvider."""

            def __init__(self, provider: RawEmbeddingProvider):
                self._p = provider

            def embed(self, text: str):
                return self._p.embed(text)

            def embed_batch(self, texts):
                return self._p.embed_batch(texts)

            @property
            def dimension(self) -> int:
                # embeddings.py uses .dimensions; context.py uses .dimension
                if hasattr(self._p, "dimensions") and self._p.dimensions:
                    return self._p.dimensions
                if hasattr(self._p, "_dimensions") and self._p._dimensions:
                    return self._p._dimensions
                return 512  # safe default for TF-IDF and unknown providers

        # Reuse memory's already-initialized embedder when available
        # so we don't double-initialize (or double-probe Ollama).
        raw_provider = None
        if self.memory and getattr(self.memory, "_embedder", None):
            raw_provider = self.memory._embedder
        else:
            try:
                prefer_local = (
                    self.config.agent.get("prefer_local_embeddings", False)
                    if hasattr(self.config.agent, "get")
                    else False
                )
                raw_provider = get_embedding_provider(prefer_local=prefer_local)
            except Exception as e:
                logger.warning(
                    f"Retriever could not initialize embedding provider: {e}. Using TF-IDF."
                )
                raw_provider = TFIDFEmbeddings()

        bridge = _EmbeddingBridge(raw_provider)
        config = RetrievalConfig(
            top_k=5,
            min_score=0.05,  # Low threshold — TF-IDF scores are naturally lower than neural
            max_tokens=1500,
            chunk_size=400,
            chunk_overlap=40,
        )
        return SemanticRetriever(
            embedding_provider=bridge,
            vector_store=InMemoryVectorStore(),
            config=config,
        )

    def _retrieve_rag_context(self, query: str, max_tokens: int = 1500) -> str:
        """
        Query the RAG retriever with the current user message and return a
        formatted string suitable for injection into the LLM system prompt.

        Returns empty string when:
        - No documents have been indexed
        - Query is empty or too short
        - All results score below min_score threshold

        Always safe to call — exceptions are caught and logged.
        """
        if not query or len(query) < 3:
            return ""
        if self.retriever.count == 0:
            return ""
        try:
            ctx = self.retriever.get_context(
                query,
                max_tokens=max_tokens,
                format="numbered",
            )
            if ctx:
                return "## Retrieved Knowledge\n\n" + ctx
            return ""
        except Exception as e:
            logger.debug(f"RAG retrieval skipped: {e}")
            return ""

    def get_retriever_status(self) -> dict:
        """
        Return a structured dict describing the current RAG retriever state.

        Keys:
          provider      — embedding provider name (e.g. 'tfidf', 'ollama/nomic-embed-text')
          doc_count     — number of indexed document chunks
          vector_store  — vector store class name (e.g. 'InMemoryVectorStore')
          config        — RetrievalConfig values (top_k, min_score, chunk_size)
        """
        provider_name = "unknown"
        try:
            # Peek through bridge to underlying provider
            raw = getattr(self.retriever._embedding, "_p", None)
            if raw:
                provider_name = getattr(raw, "name", type(raw).__name__)
        except Exception:
            pass

        return {
            "provider": provider_name,
            "doc_count": self.retriever.count,
            "vector_store": type(self.retriever._store).__name__,
            "config": {
                "top_k": self.retriever.config.top_k,
                "min_score": self.retriever.config.min_score,
                "chunk_size": self.retriever.config.chunk_size,
                "chunk_overlap": self.retriever.config.chunk_overlap,
                "max_tokens": self.retriever.config.max_tokens,
            },
        }

    def get_metrics_summary(
        self,
        tool_name: Optional[str] = None,
        include_llm: bool = True,
        include_tools: bool = True,
        include_alerts: bool = True,
    ) -> dict:
        """
        Return aggregated metrics as a plain dict — suitable for dashboards,
        logging, operator tooling, or the /metrics endpoint.

        Args:
            tool_name:      If given, return per-tool detail for that tool only
                            instead of the full tool summary.
            include_llm:    Include LLM call metrics (latency, tokens, cost).
            include_tools:  Include tool execution metrics (latency, success rate).
            include_alerts: Include recent alert history.

        Tool metrics per tool:
            total_calls, successful_calls, failed_calls, success_rate,
            avg/min/max/p50/p95/p99 duration_ms, timeout_count,
            last_execution, last_error

        LLM metrics per provider:model:
            total_calls, successful_calls, failed_calls, success_rate,
            avg/p95 duration_ms, total_prompt_tokens, total_completion_tokens,
            total_cost_usd, avg_cost_per_call, rate_limit_errors, auth_errors

        Examples::

            # Full report
            report = agent.get_metrics_summary()
            print(report["tools"]["total_calls"])
            print(report["llm"]["total_cost_usd"])

            # Per-tool drill-down
            t = agent.get_metrics_summary(tool_name="send_email")
            print(t["avg_duration_ms"], t["success_rate"])

            # Feed into health check
            agent.health.register_dependency_check(
                "tool_error_rate",
                lambda: DependencyHealth(
                    name="tool_error_rate",
                    healthy=agent.metrics.get_tool_metrics("send_email").success_rate > 0.9,
                )
            )
        """
        if tool_name is not None:
            tm = self.metrics.get_tool_metrics(tool_name)
            return tm.to_dict() if tm else {"tool_name": tool_name, "total_calls": 0}

        result: dict = {}

        if include_tools:
            result["tools"] = self.metrics.get_tool_summary()

        if include_llm:
            llm_summary = self.metrics.get_llm_summary()
            # Flatten total_cost_usd to top level for easy access
            result["llm"] = llm_summary
            result["total_cost_usd"] = llm_summary.get("total_cost_usd", 0.0)
            result["total_tokens"] = llm_summary.get("total_tokens", 0)

        if include_alerts:
            result["alerts"] = [a.to_dict() for a in self.metrics.get_alerts()]

        result["timestamp"] = __import__("datetime").datetime.now().isoformat()
        return result

    def get_bus_status(self) -> dict:
        """
        Return a structured dict describing the current SkillBus state.

        Useful for admin dashboards, /bus status CLI commands, and health
        checks. Includes registered skills, subscription count, dead-letter
        queue stats, and shared state key count.

        Returns dict with keys:
          running          — whether the bus worker thread is alive
          registered_skills — list of skill names on the bus
          subscription_count — total active topic subscriptions
          shared_state_keys  — list of keys currently in shared state
          dead_letter        — DLQ stats dict (size, by_skill, by_error_type)
        """
        dlq_stats = {}
        try:
            dlq_stats = self.bus.get_dead_letter_stats()
        except Exception:
            pass

        return {
            "running": self.bus._running,
            "registered_skills": self.bus.list_skills(),
            "subscription_count": len(self.bus._subscriptions),
            "shared_state_keys": self.bus.state.keys(),
            "dead_letter": dlq_stats,
        }

    def _handle_guardrail_violation(self, gv: GuardrailViolation, user_id: str) -> str:
        """
        Convert a GuardrailViolation into a clean user-facing message and
        log it to the audit trail.

        Never raises — always returns a string the agent can return directly.
        Each violation_type gets a specific, actionable message rather than
        leaking internal limit values to the user.
        """
        vtype = gv.violation_type

        user_messages = {
            ViolationType.RATE_LIMIT: (
                "⚠️ You're sending messages too quickly. Please wait a moment before trying again."
            ),
            ViolationType.COST_LIMIT: (
                "⚠️ You've reached your usage limit for this period. "
                "Limits reset hourly and daily — try again later or contact your admin."
            ),
            ViolationType.TOKEN_LIMIT: (
                "⚠️ This conversation has grown very long and hit a processing limit. "
                "Please start a new conversation to continue."
            ),
            ViolationType.ITERATION_LIMIT: (
                "⚠️ I got stuck in a loop trying to complete that request. "
                "Please try rephrasing or breaking it into smaller steps."
            ),
            ViolationType.TIMEOUT: (
                "⚠️ That request took too long to complete. "
                "Please try a simpler request or try again in a moment."
            ),
            ViolationType.CONTENT_SAFETY: (
                "⚠️ I can't process that message — it triggered a content safety check. "
                "Please rephrase your request."
            ),
            ViolationType.TOOL_BLOCKED: (
                "⚠️ That action requires administrator approval and can't be completed automatically. "
                "Please contact your admin."
            ),
        }

        msg = user_messages.get(vtype, f"⚠️ Request blocked: {vtype.value}")

        # Route to existing audit trail (not the duplicate AuditLogger in guardrails.py)
        try:
            from .audit import get_audit_logger as _get_audit

            _get_audit().log_guardrail_violation(
                user_id=str(user_id),
                violation_type=vtype.value,
                detail=str(gv),
            )
        except Exception:
            # audit.py may not have log_guardrail_violation — fall back to session audit
            logger.warning(f"Guardrail violation [{vtype.value}] for user {user_id}: {gv}")

        return msg

    def _validate_compliance(self):
        """Validate and apply compliance configuration."""
        if not COMPLIANCE_AVAILABLE:
            return

        # Get compliance mode from config
        compliance_config = getattr(self.config, "compliance", None)
        if not compliance_config:
            return

        mode_str = getattr(compliance_config, "mode", "none")
        if mode_str == "none":
            return

        try:
            self.compliance_mode = ComplianceMode(mode_str)
        except ValueError:
            logger.warning(f"Unknown compliance mode: {mode_str}")
            return

        # Store the compliance profile for later use (session timeout, etc.)
        try:
            from .compliance import get_compliance_config as _get_cc

            self._compliance_profile = _get_cc(self.compliance_mode)
        except ImportError:
            self._compliance_profile = None

        # Hard-fail: encryption key required for HIPAA/SOC2/PCI-DSS
        encryption_modes = {"hipaa", "soc2", "pci_dss"}
        if mode_str in encryption_modes:
            if not os.environ.get("FAMILIAR_ENCRYPTION_KEY"):
                raise SystemExit(
                    f"\n{'=' * 60}\n"
                    f"FATAL: Compliance mode '{mode_str}' requires encryption.\n"
                    f"Set FAMILIAR_ENCRYPTION_KEY before starting the agent.\n\n"
                    f"Generate a key with:\n"
                    f'  python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"\n\n'
                    f"Then export it:\n"
                    f"  export FAMILIAR_ENCRYPTION_KEY=<your-key>\n"
                    f"{'=' * 60}"
                )

        # Convert config to dict for validation
        config_dict = {
            "security": {
                "encrypt_sessions": getattr(self.config.security, "encrypt_sessions", False),
                "encrypt_memory": getattr(self.config.security, "encrypt_memory", False),
                "encrypt_history": getattr(self.config.security, "encrypt_history", False),
                "session_timeout_minutes": getattr(
                    self.config.security, "session_timeout_minutes", 60
                ),
            },
            "observability": {
                "audit_logging": getattr(self.config.observability, "tracing_enabled", False),
                "log_retention_days": 90,  # Default
            },
        }

        # Validate compliance requirements
        errors = validate_compliance(config_dict, self.compliance_mode)
        if errors:
            logger.warning(f"Compliance validation warnings for {self.compliance_mode.value}:")
            for error in errors:
                logger.warning(f"  - {error}")
        else:
            logger.info(f"Compliance mode {self.compliance_mode.value} requirements met")

        # Wire encrypted storage to audit subsystem
        encryption_modes = {"hipaa", "soc2", "pci_dss"}
        if mode_str in encryption_modes:
            try:
                from .encryption import EncryptedStorage

                es = EncryptedStorage()
                if es.is_available:
                    self._audit_encrypted_storage = es
            except Exception:
                pass

        # Initialize audit store with encryption if available
        from .audit import get_audit_store

        get_audit_store(encrypted_storage=self._audit_encrypted_storage)

        # Instantiate ComplianceAuditLogger
        try:
            from .compliance import ComplianceAuditLogger
            from .config import DATA_DIR

            self._compliance_audit_logger = ComplianceAuditLogger(
                config=self._compliance_profile,
                base_path=DATA_DIR,
                encrypted_storage=self._audit_encrypted_storage,
            )
        except Exception as e:
            logger.warning(f"ComplianceAuditLogger init failed: {e}")

    def _init_provider(self) -> LLMProvider:
        """Initialize the LLM provider.

        Checks both API key presence AND package availability
        before selecting a provider. Falls through gracefully:
        anthropic → openai → ollama (native, zero deps).
        """
        provider_name = self.config.llm.default_provider

        # Check what's available (key + package)
        has_anthropic_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
        has_openai_key = bool(os.environ.get("OPENAI_API_KEY"))

        try:
            import anthropic  # noqa: F401

            has_anthropic_pkg = True
        except ImportError:
            has_anthropic_pkg = False

        try:
            import openai  # noqa: F401

            has_openai_pkg = True
        except ImportError:
            has_openai_pkg = False

        has_anthropic = has_anthropic_key and has_anthropic_pkg
        has_openai = has_openai_key and has_openai_pkg

        # Log helpful diagnostics for missing packages
        if has_anthropic_key and not has_anthropic_pkg:
            logger.warning(
                "ANTHROPIC_API_KEY is set but 'anthropic' package not installed."
            )
        if has_openai_key and not has_openai_pkg:
            logger.warning(
                "OPENAI_API_KEY is set but 'openai' package not installed."
            )

        # Fallback logic
        if provider_name in ["anthropic", "claude"] and not has_anthropic:
            if has_openai:
                provider_name = "openai"
                logger.warning("Anthropic unavailable, falling back to OpenAI")
            else:
                provider_name = "ollama"
                logger.warning("No cloud providers available, falling back to Ollama (local)")

        if provider_name in ["openai", "gpt"] and not has_openai:
            if has_anthropic:
                provider_name = "anthropic"
                logger.warning("OpenAI unavailable, falling back to Anthropic")
            else:
                provider_name = "ollama"
                logger.warning("No cloud providers available, falling back to Ollama (local)")

        return get_provider(provider_name, self.config)

    def _init_model_router(self):
        """Initialize multi-LLM model router if multiple providers are available.

        The router enables intelligent query routing:
        - Complex reasoning → Claude Sonnet or GPT-4o
        - Simple queries → Haiku or lightweight model
        - Privacy-preferred → local Ollama when available
        - Coding tasks → best available coding model

        Only activates when 2+ providers are available. Single-provider
        setups bypass the router entirely for zero overhead.
        """
        try:
            from .model_router import ModelRouter, RoutingStrategy
        except ImportError:
            logger.debug("Model router module not available")
            return

        # Detect available providers
        has_anthropic = bool(os.environ.get("ANTHROPIC_API_KEY"))
        has_openai = bool(os.environ.get("OPENAI_API_KEY"))
        has_gemini = bool(
            os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        )
        has_ollama = False
        ollama_models = []

        try:
            import urllib.request

            req = urllib.request.Request(
                f"{self.config.llm.ollama_base_url}/api/tags",
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=2) as resp:
                import json

                data = json.loads(resp.read())
                ollama_models = [m["name"] for m in data.get("models", [])]
                has_ollama = len(ollama_models) > 0
        except Exception:
            pass

        available_count = sum([has_anthropic, has_openai, has_gemini, has_ollama])
        if available_count < 2:
            logger.debug(f"Model router: {available_count} provider(s), skipping (need 2+)")
            return

        # Build the router
        router = ModelRouter(
            default_model=self.provider.name,
            default_provider=self.config.llm.default_provider,
            strategy=RoutingStrategy.FIRST_MATCH,
        )

        # Private data → always route to local Ollama
        if has_ollama:
            ollama_model = self.config.llm.ollama_model
            router.add_model(
                name=f"ollama/{ollama_model}",
                provider="ollama",
                predicate=lambda q: q.is_private,
                priority=5,  # Highest priority for privacy
            )

        # Complex reasoning or tool use → best cloud model
        # Small local models can't reliably format tool calls, so any query
        # that may invoke skills (browse, search, email, etc.) goes to cloud.
        if has_anthropic:
            router.add_model(
                name="claude-sonnet",
                provider="anthropic",
                predicate=lambda q: (
                    q.complexity > 0.5 or q.requires_reasoning or q.requires_tools
                ),
                priority=10,
            )
        elif has_openai:
            router.add_model(
                name="gpt-4o",
                provider="openai",
                predicate=lambda q: (
                    q.complexity > 0.5 or q.requires_reasoning or q.requires_tools
                ),
                priority=10,
            )
        elif has_gemini:
            router.add_model(
                name="gemini-2.5-flash",
                provider="gemini",
                predicate=lambda q: (
                    q.complexity > 0.5 or q.requires_reasoning or q.requires_tools
                ),
                priority=10,
            )

        # Simple/fast queries → lightweight
        if has_anthropic:
            router.add_model(
                name="claude-haiku",
                provider="anthropic",
                predicate=lambda q: q.is_simple,
                priority=30,
            )
        elif has_openai:
            router.add_model(
                name="gpt-4o-mini",
                provider="openai",
                predicate=lambda q: q.is_simple,
                priority=30,
            )
        elif has_gemini:
            router.add_model(
                name="gemini-2.5-flash",
                provider="gemini",
                predicate=lambda q: q.is_simple,
                priority=30,
            )

        # Register remaining provider models without predicates so they
        # appear in the manual routing dropdown (won't affect auto-routing).
        extra_models = {}
        if has_anthropic:
            extra_models.update({
                "claude-sonnet": "anthropic",
                "claude-haiku": "anthropic",
            })
        if has_openai:
            extra_models.update({
                "gpt-4o": "openai",
                "gpt-4o-mini": "openai",
            })
        if has_gemini:
            extra_models.update({
                "gemini-2.5-flash": "gemini",
            })
        if has_ollama:
            for om in ollama_models:
                extra_models[f"ollama/{om}"] = "ollama"
        for name, prov in extra_models.items():
            if name not in router._models:
                router.add_model(name=name, provider=prov)

        # Build fallback chain
        fallbacks = []
        if has_anthropic:
            fallbacks.append("claude-sonnet")
        if has_openai:
            fallbacks.append("gpt-4o")
        if has_gemini:
            fallbacks.append("gemini-2.5-flash")
        if has_ollama:
            fallbacks.append(f"ollama/{self.config.llm.ollama_model}")
        router.set_fallback_chain(fallbacks)

        self.model_router = router
        logger.info(
            f"Model router active: {available_count} providers, "
            f"{len(router._models)} models configured, "
            f"fallback chain: {' → '.join(fallbacks)}"
        )

    def get_routing_config(self) -> dict:
        """Return current routing configuration for the dashboard.

        Returns dict with mode, available_models, categories, and router_active.
        Each category includes its auto-assigned model and current (manual) model.
        """
        from .model_router import QueryContext, QueryType

        result = {
            "mode": self._routing_mode,
            "router_active": self.model_router is not None,
            "available_models": [],
            "categories": {},
        }

        if not self.model_router:
            result["available_models"] = [self.provider.name]
            return result

        result["available_models"] = list(self.model_router._models.keys())

        # For each QueryType, build a synthetic QueryContext and route it
        # to discover the auto-assigned model.
        category_descriptions = {
            "simple": "Quick factual answers, greetings",
            "moderate": "Standard Q&A conversations",
            "complex": "Multi-step reasoning tasks",
            "coding": "Code generation and review",
            "creative": "Writing and brainstorming",
            "private": "Contains sensitive data (local only)",
            "long": "Large input context",
        }
        category_flags = {
            "simple": {"is_simple": True, "complexity": 0.1},
            "moderate": {"complexity": 0.5},
            "complex": {"is_complex": True, "complexity": 0.9, "requires_reasoning": True},
            "coding": {"is_coding": True, "complexity": 0.6, "requires_tools": True},
            "creative": {"is_creative": True, "complexity": 0.5},
            "private": {"is_private": True, "complexity": 0.5},
            "long": {"is_long_context": True, "complexity": 0.5},
        }

        for qt in QueryType:
            flags = category_flags.get(qt.value, {"complexity": 0.5})
            ctx = QueryContext(**flags)
            try:
                auto_model, _ = self.model_router.route(ctx)
            except Exception:
                auto_model = self.model_router.default_model
            manual_model = self._manual_routes.get(qt.value, auto_model)
            result["categories"][qt.value] = {
                "auto_model": auto_model,
                "model": manual_model,
                "description": category_descriptions.get(qt.value, ""),
            }

        return result

    def set_routing_config(self, mode: str, routes: dict = None) -> dict:
        """Update routing mode and manual route assignments.

        Args:
            mode: "auto" or "manual"
            routes: Optional dict mapping query type value to model name

        Returns:
            Updated routing config (same shape as get_routing_config).
        """
        if mode not in ("auto", "manual"):
            raise ValueError(f"Invalid routing mode: {mode!r} (expected 'auto' or 'manual')")
        self._routing_mode = mode
        if routes is not None:
            self._manual_routes = dict(routes)
        return self.get_routing_config()

    def switch_provider(self, provider_name: str) -> str:
        """Switch to a different LLM provider."""
        try:
            self.provider = get_provider(provider_name, self.config)
            # Reinitialize router — available providers may have changed
            self._init_model_router()
            return f"Switched to {self.provider.name}"
        except ValueError as e:
            return str(e)

    def get_system_prompt(
        self,
        session: Optional[SecureSession] = None,
        user_context: Optional["UserContext"] = None,
        current_message: Optional[str] = None,
        channel: str = "default",
        is_proactive: bool = False,
    ) -> str:
        """
        Build the system prompt with constitutional personality.

        Phase 1 integration: Uses the Familiar Constitution to generate
        relationship-stage-aware, channel-appropriate system prompts.
        Falls back to legacy prompt if constitution module unavailable.
        """
        parts = []

        # Determine user_id for relationship tracking
        user_id = "default"
        if user_context and HAS_USER_MANAGEMENT:
            user_id = user_context.user.email or user_context.user.id or "default"
        elif session:
            user_id = getattr(session, "user_id", "default")

        # Constitutional identity (Phase 1)
        try:
            from .constitution import (
                InteractionTracker,
                get_constitutional_prompt,
            )

            # Get or create tracker
            if not hasattr(self, "_interaction_tracker"):
                self._interaction_tracker = InteractionTracker()

            # Record this interaction
            self._interaction_tracker.record_interaction(user_id)

            constitutional_prompt = get_constitutional_prompt(
                agent_name=self.config.agent.name,
                user_id=user_id,
                channel=channel,
                provider_name=self.provider.name,
                is_proactive=is_proactive,
                persona_overlay=getattr(self, "_persona_overlay", ""),
                interaction_tracker=self._interaction_tracker,
            )
            parts.append(constitutional_prompt)

        except ImportError:
            # Fallback to legacy prompt if constitution module not available
            logger.debug("Constitution module not available, using legacy prompt")
            parts.append(f"""You are {self.config.agent.name}, {self.config.agent.persona}.

Current time: {datetime.now().strftime("%Y-%m-%d %H:%M %Z")}
System: {platform.node()} ({platform.system()})
Model: {self.provider.name}

You have access to tools that let you interact with the local system, manage files,
run commands, and more. Use them when needed to actually accomplish tasks.

Be concise and helpful. When asked to do something, do it - don't just describe how.""")

        # Phase 1: User context (takes precedence over session)
        if user_context and HAS_USER_MANAGEMENT:
            user = user_context.user
            parts.append(f"""## User Context

User: {user.display_name}
Email: {user.email}
Role: {user.role.value.upper()}
Can Write: {"Yes" if user_context.can_write else "No (read-only)"}

Note: Respect user's role permissions. Read-only users cannot make changes.""")

        # Legacy security context (fallback)
        elif session:
            caps = [c.value for c in session.capabilities]
            parts.append(f"""## User Security Context

Trust Level: {session.trust_level.value.upper()}
Capabilities: {len(caps)} granted
Daily Budget: ${session.remaining_budget:.2f} remaining

Note: Only use tools the user has capability for. If they lack permission,
explain what they need to unlock it (more interactions = more trust).""")

        # Tool usage guidance — help the LLM pick the right tool category
        parts.append("""## Tool Selection Guide

- **Web searches**: Always use `web_search` for looking up information, news, or topics online. Do NOT use browser tools for general searches.
- **Browser tools** (`browser_navigate`, etc.): Only for interacting with a specific known URL — filling forms, clicking buttons, reading a page you already navigated to.
- **web_read** / **web_summarize**: For fetching and extracting content from a specific URL after finding it via web_search.
- **Notes vs Memory vs Knowledge**: `joplin_*` = user's personal notes app. `remember`/`recall` = agent's own memory. `search_knowledge` = ingested documents. `search_knowledge_base` = saved snippets. Four different systems — do not confuse them.
- **Files — local vs cloud**: `nextcloud_files_*` = cloud/WebDAV server. `read_document`/`write_file` = local disk. "my files" / "my cloud" → Nextcloud. Local path → local tools.
- **Calendar — Google vs CalDAV**: `calendar_*` = Google Calendar. `nextcloud_calendar_*` = CalDAV/self-hosted. If both are configured, ask which calendar the user means.
- **Smart home**: `ha_*` for lights, switches, sensors, temperature, locks, covers, climate, automations via Home Assistant.
- **Media server**: `jf_*` for movies, shows, music, media library on Jellyfin. NOT for streaming services or local media files.
- **Self-hosted repos**: `gitea_*` for Gitea/Forgejo repos, issues, and PRs. `run_shell` + git for local repos. NOT for GitHub or GitLab.
- **DNS / ad blocking**: `pihole_*` for DNS query logs, blocked domains, and blocking statistics via Pi-hole or AdGuard Home.
- **VPN / Proton**: `proton_*` for Proton VPN control and Bridge health. NOT for sending email (use email tools) or DNS blocking (use pihole tools).""")

        # Memory context — query-relevant + high-importance global
        if self.memory:
            # Semantic: surface memories relevant to current query
            if current_message:
                relevant = self.memory.get_relevant_context(query=current_message, max_results=10)
                if relevant:
                    parts.append(relevant)

            # Global: always include top high-importance memories
            global_ctx = self.memory.get_context_string(max_entries=5)
            if global_ctx:
                parts.append(global_ctx)

        # ── Phase 4: Session context injection ──────────────────────────────
        if session and session.session_context:
            _ctx = session.session_context
            _ctx_lines = []
            _triage_emails = _ctx.get("triage_emails", [])
            _triage_at = _ctx.get("triage_at", "")
            if _triage_emails:
                import datetime as _dt4c

                _stale = False
                if _triage_at:
                    try:
                        _age = _dt4c.datetime.now(
                            _dt4c.timezone.utc
                        ) - _dt4c.datetime.fromisoformat(_triage_at)
                        _stale = _age.total_seconds() > 14400
                    except Exception:
                        pass
                if _stale:
                    _ctx_lines.append(
                        "Recent triage results are older than 4 hours. "
                        "Suggest a fresh triage run if the user references past emails."
                    )
                else:
                    _ctx_lines.append("Recent triage email list (use #N index to reference):")
                    _pri_emoji = {"urgent": "\U0001f534", "action": "\U0001f7e1", "fyi": "\u26aa"}
                    for _em in _triage_emails[:50]:
                        _p = _pri_emoji.get(_em.get("priority", "fyi"), "\u26aa")
                        _sub = _em.get("subject", "")[:60]
                        _ctx_lines.append(
                            "  #"
                            + str(_em["index"])
                            + " "
                            + _p
                            + " "
                            + _em.get("from_name", "?")
                            + " <"
                            + _em.get("from_email", "")
                            + "> "
                            + chr(8212)
                            + " "
                            + _sub
                            + " ["
                            + _em.get("category", "")
                            + "]"
                            + " [id_source="
                            + _em.get("id_source", "")
                            + "]"
                        )
            if _ctx.get("last_doc_id"):
                _ctx_lines.append(
                    "Last created doc: "
                    + repr(_ctx.get("last_doc_title", ""))
                    + " (ID: "
                    + _ctx["last_doc_id"]
                    + ") "
                    "use this ID when the user says 'that doc'."
                )
            if _ctx.get("last_event_title"):
                _ctx_lines.append(
                    "Last created event: "
                    + repr(_ctx["last_event_title"])
                    + " reference when the user says 'that event'."
                )
            if _ctx_lines:
                parts.append("## Recent Context\n\n" + "\n".join(_ctx_lines))
        # Skills documentation
        # For small local models (Ollama), skip verbose skill docs to save context.
        # The tools are already passed as structured schemas — the model doesn't need
        # a second description in prose. Cloud models (Claude, GPT) handle it fine.
        if self.config.agent.skills_enabled:
            is_local_model = getattr(self.provider, "name", "").lower() in ("ollama",)
            if not is_local_model:
                skill_docs = self.skills.get_skill_docs()
                if skill_docs:
                    parts.append(f"## Available Skills\n\n{skill_docs}")

        return "\n\n".join(parts)

    def chat(
        self,
        message: str,
        user_id: Any = "default",
        channel: str = "default",
        include_history: bool = True,
        user_context: Optional["UserContext"] = None,
    ) -> str:
        """
        Process a message and return a response.

        Args:
            message: The user's message
            user_id: Unique identifier for the user/chat (ignored if user_context provided)
            channel: Which channel this came from (telegram, discord, cli)
            include_history: Whether to include conversation history
            user_context: Phase 1 - UserContext from authenticated channel user

        Returns:
            The agent's response text

        Raises:
            BudgetExceededError: If user's daily budget is exhausted
            ProviderError: If LLM provider fails
        """
        # _setup_request may raise before session/trace are returned.
        # _GuardrailBlock is caught here and returned as a plain string.
        try:
            session, message, user_id, trace, guardrail_tracker = self._setup_request(
                message, user_id, channel, user_context
            )
        except _GuardrailBlock as gb:
            return str(gb)

        gen = self._run_agent_loop(
            message=message,
            user_id=user_id,
            channel=channel,
            include_history=include_history,
            user_context=user_context,
            session=session,
            trace=trace,
            stream=False,
            emit_tool_events=False,
            guardrail_tracker=guardrail_tracker,
        )
        try:
            # stream=False: loop emits no events, returns result via StopIteration.value
            while True:
                next(gen)
        except StopIteration as done:
            return done.value

    def chat_stream(
        self,
        message: str,
        user_id: Any = "default",
        channel: str = "default",
        include_history: bool = True,
        emit_tool_events: bool = True,
        user_context: Optional["UserContext"] = None,
    ) -> Generator[StreamEvent, None, str]:
        """
        Process a message and stream the response.

        Tool calls are executed synchronously (buffered), but the final
        text response is streamed as it's generated.

        Args:
            message: The user's message
            user_id: Unique identifier for the user/chat
            channel: Which channel this came from
            include_history: Whether to include conversation history
            emit_tool_events: If True, emit TOOL_START/TOOL_END events
            user_context: Phase 1 - UserContext from authenticated channel user

        Yields:
            StreamEvent objects with text chunks and status updates

        Returns:
            The complete response text (accessible after iteration)

        Usage:
            final_text = ""
            for event in agent.chat_stream("Hello!"):
                if event.type == StreamEventType.TEXT:
                    print(event.content, end="", flush=True)
                    final_text += event.content
                elif event.type == StreamEventType.TOOL_START:
                    print(f"\\n[Running {event.tool_name}...]")
            print()  # Final newline
        """
        # Sanitize before checking streaming support (mirrors chat() path)
        sanitization_result = sanitize_user_input(
            message, level=SanitizationLevel.BASIC, max_length=50_000
        )
        if sanitization_result.was_modified:
            logger.debug(f"Input sanitized: {sanitization_result.warnings}")
        message = sanitization_result.sanitized

        # If provider doesn't support streaming, fall through to chat()
        # which has the full pipeline — this is the safe fallback path.
        if not self.provider.supports_streaming:
            result = self.chat(
                message, user_id, channel, include_history, user_context=user_context
            )
            yield StreamEvent(type=StreamEventType.TEXT, content=result)
            yield StreamEvent(type=StreamEventType.DONE)
            return result

        # Derive user_id first so _setup_request gets the right value
        if user_context and HAS_USER_MANAGEMENT:
            user_id = user_context.user.id

        try:
            session, message, user_id, trace, guardrail_tracker = self._setup_request(
                message,
                user_id,
                channel,
                user_context,
                already_sanitized=True,  # we sanitized above
            )
        except _GuardrailBlock as gb:
            yield StreamEvent(type=StreamEventType.TEXT, content=str(gb))
            yield StreamEvent(type=StreamEventType.DONE)
            return str(gb)

        yield from self._run_agent_loop(
            message=message,
            user_id=user_id,
            channel=channel,
            include_history=include_history,
            user_context=user_context,
            session=session,
            trace=trace,
            stream=True,
            emit_tool_events=emit_tool_events,
            guardrail_tracker=guardrail_tracker,
        )

    # ============================================================
    # CORE: UNIFIED AGENT LOOP
    # ============================================================

    def _setup_request(
        self,
        message: str,
        user_id: Any,
        channel: str,
        user_context: Optional["UserContext"],
        already_sanitized: bool = False,
    ):
        """
        Shared pre-flight for chat() and chat_stream().

        Handles: sanitization, user_id derivation, session creation,
        role→trust sync, budget check, interaction recording, trace creation.

        Returns: (session, sanitized_message, resolved_user_id, trace)
        """
        # Sanitize (skip if caller already did it, e.g. chat_stream fallback)
        if not already_sanitized:
            sanitization_result = sanitize_user_input(
                message, level=SanitizationLevel.BASIC, max_length=50_000
            )
            if sanitization_result.was_modified:
                logger.debug(f"Input sanitized: {sanitization_result.warnings}")
            message = sanitization_result.sanitized

        # Resolve user_id early — needed for guardrails before session exists
        resolved_uid = str(
            user_context.user.id if (user_context and HAS_USER_MANAGEMENT) else user_id
        )

        # ── Guardrails: rate limit + hourly/daily cost gate ──────────────────
        # Runs before session creation so blocked requests don't consume budget
        # or record an interaction.  Returns a UsageTracker that must be passed
        # to every subsequent guardrail call for this request.
        try:
            guardrail_tracker: Optional[UsageTracker] = self.guardrails.start_request(resolved_uid)
        except GuardrailViolation as gv:
            raise _GuardrailBlock(self._handle_guardrail_violation(gv, resolved_uid)) from gv

        # ── Guardrails: PII — redact before message reaches LLM ─────────────
        # process_with_pii returns (processed_text, findings, blocked).
        # Default PIIAction is REDACT so findings are replaced with <EMAIL> etc.
        # and the cleaned text is used as the message going forward.
        # If operator configured PIIAction.BLOCK this raises GuardrailViolation.
        try:
            message, pii_findings, _blocked = self.guardrails.process_with_pii(message)
            if pii_findings:
                logger.info(
                    f"PII redacted: {[f.entity_type for f in pii_findings]} for user {resolved_uid}"
                )
                session_pii_note = f"pii_redacted:{len(pii_findings)}_entities"
            else:
                session_pii_note = None
        except GuardrailViolation as gv:
            # PIIAction.BLOCK — content contains PII that must not be processed
            self.guardrails.end_request(resolved_uid, guardrail_tracker)
            raise _GuardrailBlock(self._handle_guardrail_violation(gv, resolved_uid)) from gv

        # Resolve user_id from context (use .id, not .email — email is mutable)
        if user_context and HAS_USER_MANAGEMENT:
            user_id = user_context.user.id
            logger.info(f"Chat from {user_context.user.email} ({user_context.user.role.value})")

        # Session setup
        session = self.sessions.get_or_create_session(str(user_id), channel)

        # Session timeout enforcement — invalidate expired sessions in compliance mode
        if self.compliance_mode and self._compliance_profile:
            timeout = self._compliance_profile.session_timeout_minutes
            if session.is_expired(timeout):
                self.sessions.invalidate_session(str(user_id), channel)
                raise SessionExpiredError(
                    f"Session expired (idle >{timeout} min). Please re-authenticate."
                )

        # Sync role → trust level (must happen before capability checks).
        # Always called: handles both the user_context path and the
        # preauth-only path (no user_context but persisted user_role).
        self._sync_user_to_session(user_context, session)

        # Budget gate — check before recording interaction so over-budget
        # users don't gain trust credit for a request that was blocked
        if session.remaining_budget <= 0:
            raise BudgetExceededError(
                "Daily budget exceeded. Try again tomorrow or contact admin.",
                budget_type="daily",
                spent=session.spent_today,
                budget=session.daily_budget,
            )

        # Record interaction after budget gate passes
        session.record_interaction(positive=True)

        # Interaction tracker (constitutional relationship stage)
        try:
            from .constitution import InteractionTracker

            if not hasattr(self, "_interaction_tracker"):
                self._interaction_tracker = InteractionTracker()
            self._interaction_tracker.record_interaction(str(user_id))
        except ImportError:
            pass

        # Trace
        trace = None
        if self.tracer:
            trace = self.tracer.create_trace(user_id=str(user_id), channel=channel)

        # Record PII redaction in session audit if it happened
        if session_pii_note:
            session.add_audit("pii_redacted", {"note": session_pii_note})

        return session, message, user_id, trace, guardrail_tracker

    def _select_provider(self, message: str, session):
        """
        Route message to the best available provider.

        Returns (active_provider, model_name) — model_name may be the
        default provider name if routing is inactive or fails.
        """
        active_provider = self.provider
        model_name = self.config.llm.default_provider  # safe default for logging
        manual_routed = False

        # Manual routing: user-assigned provider per query category
        if (
            self.model_router
            and self._routing_mode == "manual"
            and self._manual_routes
        ):
            try:
                analyzer = self.model_router.analyzer
                qc = analyzer.analyze(message)
                route_model = self._manual_routes.get(qc.query_type.value)
                if route_model and route_model in self.model_router._models:
                    cfg = self.model_router._models[route_model]
                    routed = get_provider(cfg.provider, self.config)
                    active_provider = routed
                    model_name = route_model
                    manual_routed = True
                    logger.info(
                        f"Manual route: {qc.query_type.value} -> "
                        f"{route_model} ({cfg.provider})"
                    )
            except Exception as e:
                logger.debug(f"Manual routing fallback to auto: {e}")

        # Auto routing (skipped if manual routing already succeeded)
        if self.model_router and not manual_routed:
            try:
                model_name, provider_name = self.model_router.route(message)
                routed = get_provider(provider_name, self.config)
                active_provider = routed
                if provider_name != self.config.llm.default_provider:
                    logger.info(f"Routed to {model_name} ({provider_name})")
            except Exception as e:
                logger.debug(f"Router fallback to default: {e}")

        # PHI guard — hard constraint: PHI never leaves device in HIPAA mode
        if self.compliance_mode and hasattr(active_provider, "name"):
            try:
                from .compliance import check_phi_content

                if check_phi_content(message, self.compliance_mode):
                    is_cloud = any(
                        p in active_provider.name.lower()
                        for p in ("anthropic", "openai", "gemini")
                    )
                    if is_cloud:
                        try:
                            local_provider = get_provider("ollama", self.config)
                            logger.warning(
                                f"PHI detected — rerouted from {model_name} to "
                                f"local Ollama ({self.config.llm.ollama_model})"
                            )
                            return local_provider, model_name
                        except Exception:
                            logger.error("PHI detected but no local provider available")
                            # Signal to caller to block the request
                            raise RuntimeError("PHI_NO_LOCAL_FALLBACK")
            except ImportError:
                pass

        return active_provider, model_name

    def _provider_fallback(self, active_provider, primary_error: Exception):
        """
        Attempt a provider fallback after a failure.

        Returns the fallback provider or None if no fallback is available.
        Records circuit breaker failure for the failing provider.
        Records rate limit events for capacity tracking.
        """
        # Record circuit breaker failure
        if self.model_router and hasattr(active_provider, "name"):
            try:
                for name, cb in self.model_router._circuit_breakers.items():
                    if active_provider.name.lower() in name.lower():
                        cb.record_failure()
                        logger.info(f"Circuit breaker recorded failure for {name}")
            except Exception as e:
                logger.debug(f"Circuit breaker update failed: {e}")

        # Record rate limit events for capacity tracking
        err_type = type(primary_error).__name__
        err_str = str(primary_error).lower()
        if "ratelimit" in err_type.lower() or "rate limit" in err_str or "429" in err_str:
            provider_key = active_provider.name.split("(")[0].strip().lower()
            self.capacity_tracker.record_rate_limit(provider_key)
            logger.info(f"Capacity tracker: recorded rate limit for {provider_key}")

        fallback = None
        provider_name = active_provider.name.lower()

        # Try fallback providers in order, skipping the one that just failed
        fallback_order = ["ollama", "anthropic", "openai", "gemini"]
        for fb_name in fallback_order:
            if fb_name == provider_name or fb_name in provider_name:
                continue
            # Skip providers we know are rate-limited
            if self.capacity_tracker.is_rate_limited(fb_name):
                logger.info(f"Skipping {fb_name} fallback — rate limited (capacity tracker)")
                continue
            try:
                if fb_name == "ollama":
                    # Use smart model selection for Ollama fallback
                    fallback = get_best_ollama_model(self.config)
                    if not fallback:
                        fallback = get_provider("ollama", self.config)
                else:
                    fallback = get_provider(fb_name, self.config)
                logger.warning(f"{active_provider.name} failed — falling back to {fallback.name}")
                break
            except Exception:
                continue

        return fallback

    def _execute_tools(
        self,
        tool_calls,
        session,
        tool_context: dict,
        retry_tracker,
        trace,
        stream: bool,
        emit_tool_events: bool,
    ):
        """
        Execute a list of tool calls, applying self-correction.

        In stream mode, yields TOOL_START / TOOL_END events.
        In non-stream mode, returns list of tool result dicts directly.

        Returns (tool_results, events) where events is a list of
        StreamEvent objects (empty in non-stream mode).
        """
        tool_results = []
        events = []

        # Pull the emitter from tool_context (always present after v1.1.16).
        # If somehow absent (tests that build tool_context manually), create
        # a no-op emitter so the rest of the code never needs to null-check.
        emitter: EventEmitter = tool_context.get("emitter") or EventEmitter(execution_id="fallback")

        for tc in tool_calls:
            logger.info(f"Tool: {tc.name}({json.dumps(tc.input)[:100]}...)")

            # Emit structured TOOL_START through EventEmitter.
            # In stream mode, also translate to StreamEvent for the yield path.
            tool_id = str(uuid.uuid4())[:8]
            _tool_start = time.monotonic()

            emitter.tool_start(tc.name, tc.input, tool_id=tool_id)

            if stream and emit_tool_events:
                events.append(
                    StreamEvent(
                        type=StreamEventType.TOOL_START,
                        tool_name=tc.name,
                        tool_input=tc.input,
                    )
                )

            # Self-correction: respect retry budget
            if not retry_tracker.should_retry(tc.name) and retry_tracker.get_attempts(tc.name) > 0:
                result = retry_tracker.format_give_up(tc.name, "Max retries exhausted")
                logger.warning(
                    f"Tool {tc.name} exhausted after {retry_tracker.get_attempts(tc.name)} attempts"
                )
                elapsed_ms = (time.monotonic() - _tool_start) * 1000
                emitter.tool_error(
                    tc.name, error="Max retries exhausted", elapsed_ms=elapsed_ms, tool_id=tool_id
                )
            else:
                result = self._execute_tool_secure(tc.name, tc.input, session, tool_context, trace)

                elapsed_ms = (time.monotonic() - _tool_start) * 1000

                if retry_tracker.is_error(result):
                    error_class = retry_tracker.record_failure(tc.name, result)
                    emitter.tool_retry(
                        tc.name,
                        attempt=retry_tracker.get_attempts(tc.name),
                        reason=result,
                        tool_id=tool_id,
                    )
                    if retry_tracker.should_retry(tc.name):
                        result = retry_tracker.format_error_feedback(tc.name, result, error_class)
                    else:
                        result = retry_tracker.format_give_up(tc.name, result, error_class)
                        emitter.tool_error(
                            tc.name, error=result, elapsed_ms=elapsed_ms, tool_id=tool_id
                        )
                    session.add_audit(
                        "tool_error",
                        {
                            "tool": tc.name,
                            "error_class": error_class.value,
                            "attempt": retry_tracker.get_attempts(tc.name),
                        },
                    )
                else:
                    # Success — emit TOOL_COMPLETE and reset retry tracker
                    emitter.tool_complete(
                        tc.name,
                        result=result[:200] if result else None,
                        elapsed_ms=elapsed_ms,
                        tool_id=tool_id,
                    )
                    retry_tracker._attempts.pop(tc.name, None)
                    retry_tracker._error_classes.pop(tc.name, None)

                    # Progressive: track skill usage
                    try:
                        from familiar.core.progressive import on_tool_executed

                        tool_skill = self._get_skill_for_tool(tc.name)
                        if tool_skill:
                            on_tool_executed(tc.name, tool_skill)
                    except (ImportError, Exception):
                        pass

            if stream and emit_tool_events:
                events.append(
                    StreamEvent(
                        type=StreamEventType.TOOL_END,
                        tool_name=tc.name,
                        tool_result=result[:500] if result else None,
                    )
                )

            # Sentinel: skill wants confirmation — short-circuit the tool loop.
            # The sentinel is returned as the chat response so the channel
            # can render the appropriate UI without an LLM round-trip.
            from familiar.core.confirmations import (
                CALENDAR_MENU_PREFIX,
                EMAIL_MENU_PREFIX,
                SENTINEL_PREFIX,
            )

            if isinstance(result, str) and result.startswith(SENTINEL_PREFIX):
                return [
                    {"type": "confirmation_pending", "sentinel": result, "tool_use_id": tc.id}
                ], events

            if isinstance(result, str) and result.startswith(EMAIL_MENU_PREFIX):
                return [
                    {"type": "email_menu_pending", "sentinel": result, "tool_use_id": tc.id}
                ], events

            if isinstance(result, str) and result.startswith(CALENDAR_MENU_PREFIX):
                return [
                    {"type": "calendar_menu_pending", "sentinel": result, "tool_use_id": tc.id}
                ], events

            tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": tc.id,
                    "content": result,
                }
            )

        return tool_results, events

    def _finalize_response(
        self,
        message: str,
        final_text: str,
        user_id: Any,
        channel: str,
        user_context,
        session,
        trace,
        response,
        start_time: float,
        guardrail_tracker: Optional[UsageTracker] = None,
    ) -> str:
        """
        Shared post-processing after the agent produces its final text.

        Handles: history save, analytics, trace finish, session save,
        memory extraction, progressive milestone check, guardrail cleanup.

        Returns final_text (may be augmented with achievement banner).
        """
        # Save conversation history
        if user_context and HAS_USER_MANAGEMENT:
            self._save_user_history(user_context, channel, message, final_text)
        else:
            self.history.add_message(user_id, "user", message, channel)
            self.history.add_message(user_id, "assistant", final_text, channel)

        # Analytics
        self._record_analytics(
            user_id=str(user_id),
            channel=channel,
            response=response,
            start_time=start_time,
            user_context=user_context,
        )

        # Trace
        if trace:
            self.tracer.finish_trace(trace)

        # Session
        self.sessions.save_session(session)

        # Async memory extraction
        if self.memory_extractor:
            self.memory_extractor.extract_async(message, final_text, channel)

        # Guardrails: finalize request tracking.
        self.guardrails.end_request(str(user_id), guardrail_tracker)

        # EpisodicMemory: store this exchange as a conversation memory.
        # Runs after guardrails so we only store completed, non-blocked requests.
        # Stored as CONVERSATION type with both turns linked — the MemorySystem
        # associates adjacent turns so retrieval surfaces full exchanges.
        # Saved async to disk so it doesn't block response finalization.
        _episodic_ms = self._get_episodic_memory(str(user_id))
        if _episodic_ms is not None and final_text:
            try:
                _episodic_ms.store_conversation(
                    messages=[
                        {"role": "user", "content": message},
                        {"role": "assistant", "content": final_text},
                    ],
                    conversation_id=str(session.session_id),
                    importance=0.6,
                )
                self._save_episodic_memory_async(str(user_id))
            except Exception as e:
                logger.debug(f"EpisodicMemory store skipped: {e}")

        # Progressive capability milestones
        try:
            from familiar.core.progressive import on_interaction_complete

            if hasattr(self, "_interaction_tracker"):
                count = self._interaction_tracker.get_count(str(user_id))
                achievement = on_interaction_complete(str(user_id), count, self.skills)
                if achievement:
                    final_text = f"{final_text}\n\n---\n{achievement}"
        except (ImportError, AttributeError, Exception):
            pass

        return final_text

    def _run_agent_loop(
        self,
        message: str,
        user_id: Any,
        channel: str,
        include_history: bool,
        user_context,
        session,
        trace,
        stream: bool,
        emit_tool_events: bool,
        guardrail_tracker: Optional[UsageTracker] = None,
    ):
        """
        Unified agent loop used by both chat() and chat_stream().

        In non-stream mode (stream=False): returns final response str.
        In stream mode (stream=True): is a generator that yields StreamEvents
        and returns the final text string via StopIteration.value / return.

        All security, capability filtering, planning, routing, PHI guard,
        self-correction, history, analytics, and memory extraction run
        through this single path regardless of streaming mode.

        guardrail_tracker: UsageTracker returned by guardrails.start_request()
            in _setup_request.  Passed explicitly (not stored on self) so
            concurrent requests don't share state.
        """
        try:
            fallback_notice = None  # Set if provider fallback occurs

            # ── History ──────────────────────────────────────────
            if include_history:
                if user_context and HAS_USER_MANAGEMENT:
                    history = self._get_user_history(user_context, channel)
                else:
                    history = self.history.get_history(user_id, channel)
            else:
                history = []

            history.append({"role": "user", "content": message})

            # ── Tool context ─────────────────────────────────────
            # EventEmitter: one per request, keyed to a short execution ID.
            # Injected into tool_context so any tool handler can emit structured
            # progress events without coupling to the agent or streaming layer.
            # The agent automatically emits TOOL_START / TOOL_COMPLETE / TOOL_ERROR
            # for every call — tools only need to emit TOOL_PROGRESS themselves.
            #
            # Clients subscribe a callback before the request:
            #   agent.set_tool_event_callback(user_id, handler)
            # See _get_tool_event_callback() for the registry.
            _request_emitter = EventEmitter(
                execution_id=f"{str(user_id)[:8]}-{str(uuid.uuid4())[:6]}"
            )
            _tool_cb = getattr(self, "_tool_event_callbacks", {}).get(str(user_id))
            if _tool_cb is not None:
                _request_emitter.subscribe(_tool_cb)

            # StructuredGenerator: lazy adapter wrapping the current provider.
            # Built as a lambda so provider swaps (fallback routing) are picked up
            # at call time rather than captured at request-start.
            # Tools call: tool_context["structured"].generate(MyModel, "prompt...")
            # Returns a GenerationResult — check .success before calling .unwrap().
            def _make_structured_provider(agent_ref):
                def _provider(messages, model=None, **kw):
                    # Bridge StructuredGenerator's (messages, model) call convention
                    # to provider.chat(messages, tools, system, max_tokens).
                    return agent_ref.provider.chat(
                        messages=messages,
                        tools=[],
                        system="You are a precise data extraction assistant. Output only valid JSON.",
                        max_tokens=kw.get("max_tokens", 2048),
                    )

                return _provider

            _structured_generator = StructuredGenerator(
                llm_provider=_make_structured_provider(self),
                max_retries=3,
                extraction_method=ExtractionMethod.FIRST_JSON,
                validation_strategy=ValidationStrategy.RETRY,
                repair_json=True,
            )

            tool_context = {
                "memory": self.memory,
                "user_id": user_id,
                "channel": channel,
                "session": session,
                "session_manager": self.sessions,
                "agent": self,
                "user_context": user_context,
                "emitter": _request_emitter,
                "structured": _structured_generator,
                # sagas: shared SagaOrchestrator for multi-step atomic workflows.
                # Tools call tool_context["sagas"].run(saga, context) (sync bridge)
                # or tool_context["run_saga"](saga, context) for convenience.
                # Register saga definitions at skill load time via agent.sagas.register(saga).
                "sagas": self.sagas,
                "run_saga": self.run_saga,
                # experiments: feature flags and A/B testing.
                # Check flags: tool_context["experiments"].is_enabled("flag_name", str(user_id))
                # Get variant: tool_context["experiments"].get_variant("exp_name", str(user_id))
                "experiments": self.experiments,
                # mesh: MeshGateway (None if mesh not enabled/started).
                # Check agent.get_mesh_status() for runtime state.
                # Peer tool delegation: tool_context["orchestrator"].execute(task)
                "mesh": self.mesh_gateway,
                "orchestrator": self.orchestrator,
                # bus: SkillBus — inter-skill pub/sub, invocation, workflows.
                #
                # Publish an event (fire-and-forget, async):
                #   tool_context["bus"].publish("donor.intake.completed",
                #       {"donor_id": "123", "name": "Alice"})
                #
                # Invoke another skill synchronously (with retry):
                #   result = tool_context["bus"].invoke(
                #       "crm", "upsert_contact", {"email": "alice@example.com"})
                #
                # Shared state (cross-tool, in-process):
                #   tool_context["bus"].state.set("intake_lock", True)
                #   tool_context["bus"].state.get("intake_lock")
                #
                # Run a multi-skill workflow:
                #   wf = tool_context["bus"].create_workflow("donor_intake")
                #   wf.add_step("crm", "upsert", step_id="crm")
                #   wf.add_step("email", "send_welcome", depends_on=["crm"])
                #   tool_context["bus"].execute_workflow(wf, initial_context)
                "bus": self.bus,
                # retriever: SemanticRetriever — chunked document RAG.
                # Skills add org docs at load time or on demand:
                #   tool_context["retriever"].add_text(
                #       grant_guidelines, metadata={"source": "smith_foundation_2026"})
                # Query with natural language:
                #   results = tool_context["retriever"].retrieve("grant deadline", top_k=3)
                #   ctx = tool_context["retriever"].get_context("eligibility criteria")
                # The current user message is automatically used to retrieve
                # relevant chunks and inject them into the LLM system prompt.
                "retriever": self.retriever,
                # health: HealthChecker — liveness/readiness/dependency probes.
                # Skills register custom dependency checks:
                #   tool_context["health"].register_dependency_check(
                #       "crm", lambda: DependencyHealth(name="crm", healthy=ping_crm()))
                # Run probes:
                #   tool_context["health"].liveness_check()   → {"status": "ok"}
                #   tool_context["health"].readiness_check()  → {"ready": True, ...}
                #   tool_context["health"].check_health()     → HealthCheckResult
                "health": self.health,
                # metrics: MetricsCollector — per-call latency, success rates, cost.
                # Skills record custom metrics:
                #   tool_context["metrics"].increment_counter("donor_created")
                #   tool_context["metrics"].record_histogram("email_size_bytes", len(body))
                #   tool_context["metrics"].set_gauge("queue_depth", q.size())
                # Full report: agent.get_metrics_summary()
                "metrics": self.metrics,
                # backup: BackupManager — create/list/restore backups from skills.
                # tool_context["backup"].create_backup() triggers an on-demand backup.
                # tool_context["backup"].list_backups() returns manifest list.
                "backup": self.backup,
            }
            if user_context and HAS_USER_MANAGEMENT and get_data_store:
                try:
                    tool_context["data_store"] = get_data_store(
                        user_id=user_context.user.id,
                        user_role=user_context.user.role.value,
                    )
                except Exception as e:
                    logger.warning(f"Could not get user data store: {e}")

            # ── System prompt + capability-filtered tools ─────────
            system = self.get_system_prompt(
                session, user_context, current_message=message, channel=channel
            )

            # ── EpisodicMemory: inject past conversation context ───
            # Retrieve conversation memories relevant to this message and
            # prepend them to the system prompt so the LLM has cross-session
            # recall without requiring the full conversation history.
            #
            # Complementary to MemoryExtractor (which extracts semantic facts):
            # episodic memory stores conversation *exchanges* — "three weeks ago
            # you told me the Q1 donor campaign was 50K short."
            #
            # Skip for local models — these sections add hundreds of tokens
            # that small models on CPU can't process quickly enough.
            _is_local_provider = (_OllamaProvider is not None and isinstance(self.provider, _OllamaProvider))
            _episodic_ms = self._get_episodic_memory(str(user_id))
            if _episodic_ms is not None and not _is_local_provider:
                try:
                    _ep_results = _episodic_ms.retrieve(
                        query=message,
                        top_k=5,
                        strategy=EpisodicRetrievalStrategy.COMBINED,
                        min_strength=0.1,
                    )
                    # Also pull working memory (hot buffer of recent exchanges)
                    _wm_ctx = _episodic_ms.working_memory.get_context_string(max_tokens=400)
                    # Format retrieved memories not already in working memory
                    _wm_ids = {m.id for m in _episodic_ms.working_memory}
                    _extra_lines = [
                        f"- {m.content[:200]}" for m in _ep_results if m.id not in _wm_ids
                    ]
                    _extra_ctx = "\n".join(_extra_lines)

                    # Build the injected block — only append if non-empty
                    _ep_block_parts = []
                    if _wm_ctx.strip():
                        _ep_block_parts.append(_wm_ctx)
                    if _extra_ctx.strip():
                        _ep_block_parts.append(_extra_ctx)

                    if _ep_block_parts:
                        _ep_block = "\n".join(_ep_block_parts)
                        # Cap at ~800 chars to avoid dominating context window
                        if len(_ep_block) > 800:
                            _ep_block = _ep_block[:800] + "…"
                        system = f"{system}\n\n## Past conversation context\n{_ep_block}"
                        logger.debug(
                            f"EpisodicMemory: injected {len(_ep_results)} memories "
                            f"for user {user_id}"
                        )
                except Exception as e:
                    logger.debug(f"EpisodicMemory retrieval skipped: {e}")

            # ── RAG context: retrieved document chunks ────────────────────
            # Query the SemanticRetriever with the current user message
            # and inject the top-k relevant chunks into the system prompt.
            # Only fires when documents have been indexed (retriever.count > 0).
            # Org handbooks, grant guidelines, policy docs, intake forms —
            # any text added via agent.retriever.add_text() or tool_context["retriever"].
            if self.retriever.count > 0 and not _is_local_provider:
                try:
                    _rag_ctx = self._retrieve_rag_context(message, max_tokens=1500)
                    if _rag_ctx:
                        system = f"{system}\n\n{_rag_ctx}"
                        logger.debug(f"RAG context injected: {self.retriever.count} docs indexed")
                except Exception as e:
                    logger.debug(f"RAG context skipped: {e}")

            # ── Mesh context: cross-device memories from peer nodes ───
            # If the mesh gateway is running and has trusted peers with
            # shared memories, inject their relevant context here.
            # Timeout is short (1.5s) so it never blocks the response.
            if self.mesh_gateway and self.mesh_gateway._running and not _is_local_provider:
                try:
                    _mesh_ctx = self.get_mesh_context(message, timeout=1.5)
                    if _mesh_ctx.strip():
                        system = f"{system}\n\n{_mesh_ctx}"
                        logger.debug("Mesh context injected into system prompt")
                except Exception as e:
                    logger.debug(f"Mesh context skipped: {e}")

            # Capability filtering applies in BOTH stream and non-stream paths
            tool_schemas = self._get_allowed_tools(session, message=message)

            # ── Planning ─────────────────────────────────────────
            if self.planner and self.planner.should_plan(message, tool_schemas):
                memory_ctx = ""
                if self.memory:
                    memory_ctx = self.memory.get_relevant_context(message, max_results=5)
                plan = self.planner.create_plan(message, tool_schemas, memory_ctx)
                if plan:
                    system += "\n\n" + plan.to_prompt()
                    logger.info(f"Plan: {plan.goal} ({len(plan.steps)} steps)")

            # ── Provider selection + PHI guard ────────────────────
            try:
                active_provider, model_name = self._select_provider(message, session)
            except RuntimeError as phi_err:
                if "PHI_NO_LOCAL_FALLBACK" in str(phi_err):
                    session.add_audit("phi_blocked", {"reason": "PHI detected, no local fallback"})
                    self.sessions.save_session(session)
                    phi_msg = (
                        "⚠️ This message appears to contain protected health "
                        "information (PHI) and cannot be sent to a cloud provider "
                        "under current compliance settings. Please configure a "
                        "local Ollama model or rephrase your request."
                    )
                    if stream:
                        yield StreamEvent(type=StreamEventType.TEXT, content=phi_msg)
                        yield StreamEvent(type=StreamEventType.DONE)
                        return phi_msg
                    return phi_msg
                raise

            # ── Loop setup ────────────────────────────────────────
            security_config = SecurityConfig.from_mode(self.security_mode)
            max_iterations = min(15, security_config.max_iterations)
            start_time = time.time()

            from .self_correction import ToolRetryTracker

            retry_tracker = ToolRetryTracker()

            # ── Agent loop ────────────────────────────────────────
            for i in range(max_iterations):
                # ── Guardrails: iteration cap + timeout ───────────
                # Explicit tracker passed — thread-safe, no shared state.
                try:
                    self.guardrails.check_iteration(i, guardrail_tracker)
                except GuardrailViolation as gv:
                    guard_msg = self._handle_guardrail_violation(gv, user_id)
                    if stream:
                        yield StreamEvent(type=StreamEventType.TEXT, content=guard_msg)
                        yield StreamEvent(type=StreamEventType.DONE)
                        return guard_msg
                    return guard_msg

                # ── Proactive rate limit skip ─────────────────────
                provider_key = active_provider.name.split("(")[0].strip().lower()
                if self.capacity_tracker.is_rate_limited(provider_key):
                    original_name = active_provider.name
                    fallback = self._provider_fallback(active_provider, RuntimeError("proactive_skip"))
                    if fallback:
                        active_provider = fallback
                        fallback_notice = f"[{original_name} rate limited — using {fallback.name}]"
                        session.add_audit(
                            "proactive_fallback",
                            {"from": original_name, "to": fallback.name},
                        )
                        logger.info(f"Proactive fallback: {original_name} → {fallback.name}")

                # ── LLM call ──────────────────────────────────────
                response = None
                try:
                    if stream:
                        # Consume the stream, collecting text and the response object.
                        # Providers signal tool_calls via the returned LLMResponse,
                        # which is only accessible via StopIteration.value after the
                        # generator is exhausted (generator.value is not a valid attr).
                        stream_gen = active_provider.chat_stream(
                            messages=history,
                            tools=tool_schemas,
                            system=system,
                            max_tokens=self.config.llm.max_tokens,
                            trace=trace,
                        )
                        collected_text = ""
                        response = None
                        try:
                            while True:
                                event = next(stream_gen)
                                if event.type == StreamEventType.TEXT:
                                    collected_text += event.content
                                elif event.type == StreamEventType.ERROR:
                                    raise Exception(event.error)
                        except StopIteration as si:
                            response = si.value  # LLMResponse from generator return
                        if response is None:
                            # Provider didn't return an LLMResponse via StopIteration.
                            # Reconstruct from collected text (no tool calls possible).
                            logger.debug(
                                "Stream provider returned no LLMResponse; reconstructing from text"
                            )
                            response = LLMResponse(
                                text=collected_text or None,
                                tool_calls=[],
                                stop_reason="end_turn",
                            )
                    else:
                        _llm_start = time.time()
                        _llm_exc: Optional[str] = None
                        try:
                            response = active_provider.chat(
                                messages=history,
                                tools=tool_schemas,
                                system=system,
                                max_tokens=self.config.llm.max_tokens,
                                trace=trace,
                                retry_config=self.retry_config,
                            )
                        except Exception as _llm_e:
                            _llm_exc = str(_llm_e)
                            raise
                        finally:
                            try:
                                _usage = (response.usage if response else {}) or {}
                                self.metrics.record_llm_call(
                                    provider=active_provider.name,
                                    model=getattr(active_provider, "model_name", ""),
                                    duration_ms=(time.time() - _llm_start) * 1000,
                                    success=_llm_exc is None,
                                    prompt_tokens=_usage.get("input_tokens", 0),
                                    completion_tokens=_usage.get("output_tokens", 0),
                                    error_message=_llm_exc,
                                    user_id=str(current_user_id)
                                    if (current_user_id := locals().get("user_id"))
                                    else "",
                                )
                            except Exception as _m_err:
                                logger.debug(f"Metrics record_llm_call skipped: {_m_err}")

                except Exception as e:
                    logger.error(f"LLM call failed: {e}")
                    session.add_audit("llm_error", {"error": str(e)})

                    original_name = active_provider.name
                    fallback = self._provider_fallback(active_provider, e)
                    if fallback:
                        try:
                            session.add_audit(
                                "provider_fallback",
                                {
                                    "from": str(e)[:100],
                                    "to": fallback.name,
                                },
                            )
                            active_provider = fallback
                            fallback_notice = f"[{original_name} unavailable — using {fallback.name}]"
                            # Always use non-streaming for fallback (simpler, safer)
                            response = active_provider.chat(
                                messages=history,
                                tools=tool_schemas,
                                system=system,
                                max_tokens=self.config.llm.max_tokens,
                                trace=trace,
                                retry_config=self.retry_config,
                            )
                        except Exception as e2:
                            logger.error(f"Fallback provider also failed: {e2}")
                            error_msg = (
                                "I'm having trouble reaching my AI providers right now. "
                                "Please try again in a moment."
                            )
                            if trace:
                                self.tracer.finish_trace(trace)
                            self.sessions.save_session(session)
                            if stream:
                                yield StreamEvent(type=StreamEventType.ERROR, error=error_msg)
                                return error_msg
                            return error_msg
                    else:
                        logger.error(f"Provider error: {e}")
                        error_msg = (
                            f"I'm having trouble reaching {active_provider.name} right now. "
                            "Please try again in a moment."
                        )
                        if trace:
                            self.tracer.finish_trace(trace)
                        self.sessions.save_session(session)
                        if stream:
                            yield StreamEvent(type=StreamEventType.ERROR, error=error_msg)
                            return error_msg
                        return error_msg

                # ── Budget: charge actual token cost after LLM call ──────
                # Done here (after the call) so we use real token counts
                # rather than a flat estimate. Falls back to a conservative
                # per-iteration floor for providers that don't report usage
                # (e.g. Ollama) so the session budget still enforces limits.
                if response is not None:
                    actual_cost = 0.0
                    in_tokens = 0
                    out_tokens = 0
                    if response.usage:
                        in_tokens = response.usage.get("input_tokens", 0)
                        out_tokens = response.usage.get("output_tokens", 0)
                        actual_cost = calculate_cost(
                            active_provider.model_name,
                            in_tokens,
                            out_tokens,
                        )
                    if actual_cost == 0.0:
                        # Provider returned no usage (Ollama) or unknown model:
                        # charge a conservative floor so budgets still bind.
                        actual_cost = 0.005
                    if not session.charge(actual_cost):
                        self.sessions.save_session(session)
                        budget_msg = "⚠️ Budget limit reached for this request."
                        if stream:
                            yield StreamEvent(type=StreamEventType.TEXT, content=budget_msg)
                            yield StreamEvent(type=StreamEventType.DONE)
                            return budget_msg
                        return budget_msg

                    # Guardrails: track token + cost accumulation for this request.
                    # Raises GuardrailViolation if per-request token/cost cap hit.
                    # Uses same numbers as session.charge() — no second calculation.
                    try:
                        self.guardrails.track_llm_usage(
                            in_tokens, out_tokens, actual_cost, guardrail_tracker
                        )
                    except GuardrailViolation as gv:
                        guard_msg = self._handle_guardrail_violation(gv, user_id)
                        if stream:
                            yield StreamEvent(type=StreamEventType.TEXT, content=guard_msg)
                            yield StreamEvent(type=StreamEventType.DONE)
                            return guard_msg
                        return guard_msg

                # ── Tool calls ────────────────────────────────────
                if response.tool_calls:
                    history.append({"role": "assistant", "content": response})

                    tool_results, tool_events = self._execute_tools(
                        tool_calls=response.tool_calls,
                        session=session,
                        tool_context=tool_context,
                        retry_tracker=retry_tracker,
                        trace=trace,
                        stream=stream,
                        emit_tool_events=emit_tool_events,
                    )

                    # Yield tool events in stream mode
                    if stream:
                        for ev in tool_events:
                            yield ev

                    # Confirmation pending — return sentinel directly,
                    # skip adding to history (no LLM needed for UI routing)
                    if (
                        tool_results
                        and isinstance(tool_results[0], dict)
                        and tool_results[0].get("type") in ("confirmation_pending", "email_menu_pending", "calendar_menu_pending")
                    ):
                        sentinel = tool_results[0]["sentinel"]
                        if stream:
                            yield StreamEvent(type=StreamEventType.DONE)
                            return sentinel
                        return sentinel

                    history.append({"role": "user", "content": tool_results})
                    continue

                # ── Final response ────────────────────────────────
                else:
                    final_text = response.text or "(no response)"

                    final_text = self._finalize_response(
                        message=message,
                        final_text=final_text,
                        user_id=user_id,
                        channel=channel,
                        user_context=user_context,
                        session=session,
                        trace=trace,
                        response=response,
                        start_time=start_time,
                        guardrail_tracker=guardrail_tracker,
                    )

                    if fallback_notice:
                        final_text = f"{fallback_notice}\n\n{final_text}"

                    if stream:
                        yield StreamEvent(type=StreamEventType.TEXT, content=final_text)
                        yield StreamEvent(type=StreamEventType.DONE, usage=response.usage)
                        return final_text
                    return final_text

            # ── Max iterations ────────────────────────────────────
            if trace:
                self.tracer.finish_trace(trace)
            self.sessions.save_session(session)
            timeout_msg = "(max iterations reached - task may be too complex)"
            if stream:
                yield StreamEvent(type=StreamEventType.TEXT, content=timeout_msg)
                yield StreamEvent(type=StreamEventType.DONE)
                return timeout_msg
            return timeout_msg

        except Exception as e:
            # Inner error paths (provider fail, budget) already save session and
            # finish trace before returning. This catches anything unexpected that
            # bypasses those paths (e.g. an exception in history loading, planning,
            # or _execute_tools itself).
            if trace:
                try:
                    self.tracer.finish_trace(trace)
                except Exception:
                    pass
            self.sessions.save_session(session)
            if stream:
                yield StreamEvent(type=StreamEventType.ERROR, error=str(e))
            raise

    def _get_allowed_tools(self, session: SecureSession, message: str = "") -> list:
        """Filter tools based on session capabilities, then route by message relevance.

        Two-stage pipeline:
          1. Capability gate  — hard filter by trust level / session capabilities.
          2. Relevance routing — soft filter via ToolRouter, trims to <=15 most
             relevant schemas so the LLM receives a focused context per message.

        Falls back to the full capability-allowed set when routing confidence is
        low or the set is already small enough.
        """
        from .security import SKILL_DIRECTORY_CAPABILITIES

        all_schemas = self.tools.get_schemas()
        capability_allowed = []

        # Build tool->skill mapping from skill loader
        tool_to_skill = {}
        if hasattr(self, "skills") and self.skills:
            for skill_name, skill in self.skills.skills.items():
                for tool in skill.tools:
                    tool_to_skill[tool.name] = skill_name

        # Stage 1: capability gate
        for schema in all_schemas:
            tool_name = schema.get("name", "")

            skill_name = tool_to_skill.get(tool_name)
            if skill_name and skill_name in SKILL_DIRECTORY_CAPABILITIES:
                required = SKILL_DIRECTORY_CAPABILITIES[skill_name]
                missing = {cap for cap in required if not session.has_capability(cap)}
                if missing:
                    logger.debug(
                        f"Tool {tool_name} blocked (skill={skill_name}): missing {missing}"
                    )
                    continue
                capability_allowed.append(schema)
                continue

            allowed_access, missing, _ = check_skill_access(tool_name, session)
            if allowed_access:
                if session.trust_level == TrustLevel.STRANGER and not skill_name:
                    logger.debug(f"Tool {tool_name} blocked for STRANGER (unmapped)")
                    continue
                capability_allowed.append(schema)
            else:
                logger.debug(
                    f"Tool {tool_name} blocked for user {session.user_id}: missing {missing}"
                )

        # Stage 2: relevance routing (skip for small sets or no message context)
        if not message or len(capability_allowed) <= self.tool_router.config.fallback_count:
            return capability_allowed

        try:
            routing = self.tool_router.route(
                message=message,
                allowed_schemas=capability_allowed,
            )
            if not routing.fallback and len(routing.schemas) < len(capability_allowed):
                logger.debug(
                    f"ToolRouter: {len(capability_allowed)} -> {len(routing.schemas)} tools "
                    f"(conf={routing.confidence:.2f}, {routing.route_time_ms:.1f}ms)"
                )
                return routing.schemas
        except Exception as e:
            logger.warning(f"ToolRouter failed, using full capability set: {e}")

        return capability_allowed

    def _get_skill_for_tool(self, tool_name: str) -> Optional[str]:
        """Look up which skill a tool belongs to. Used for progressive tracking."""
        if hasattr(self, "skills") and self.skills:
            for skill_name, skill in self.skills.skills.items():
                for tool in skill.tools:
                    if tool.name == tool_name:
                        return skill_name
        return None

    def _execute_tool_secure(
        self,
        tool_name: str,
        tool_input: Dict,
        session: SecureSession,
        context: Dict,
        trace: Optional[Trace] = None,
    ) -> str:
        """Execute a tool with security checks."""
        # Phase 1: Check user_context write permission for write operations
        user_context = context.get("user_context")
        if user_context and HAS_USER_MANAGEMENT:
            # Determine if this is a write operation
            write_tools = {
                "write_file",
                "create_file",
                "delete_file",
                "move_file",
                "send_email",
                "send_message",
                "send_sms",
                "create_task",
                "update_task",
                "delete_task",
                "create_event",
                "update_event",
                "delete_event",
                "add_memory",
                "update_memory",
                "delete_memory",
                "execute_command",
                "run_shell",
            }

            is_write_operation = any(w in tool_name.lower() for w in write_tools)

            if is_write_operation and not user_context.can_write:
                session.add_audit(
                    "tool_blocked_readonly",
                    {
                        "tool": tool_name,
                        "user": user_context.user.email,
                        "role": user_context.user.role.value,
                    },
                )
                return (
                    f"⚠️ Permission denied. Your role ({user_context.user.role.value}) is read-only."
                )

        # Check capability (trust-level security)
        allowed, missing, needs_confirm = check_skill_access(tool_name, session)

        if not allowed:
            missing_str = ", ".join(c.value for c in missing)
            session.add_audit(
                "tool_blocked", {"tool": tool_name, "missing_capabilities": missing_str}
            )
            return f"⚠️ Permission denied. Missing: {missing_str}. Build trust to unlock."

        # RBAC enforcement — check skill-level permissions from rbac.json
        try:
            from familiar.skills.rbac.skill import _check_perm as _rbac_check
            from familiar.skills.rbac.skill import _get_role_permissions as _rbac_perms
            from familiar.skills.rbac.skill import _load_data as _rbac_load

            rbac_data = _rbac_load()
            assignments = rbac_data.get("assignments", {})
            user_assignment = assignments.get(session.user_id)
            if user_assignment:
                role_name = user_assignment.get("role", "")
                user_perms = _rbac_perms(role_name)
                if user_perms:
                    # Determine skill name for this tool
                    skill_name = self._get_skill_for_tool(tool_name) or ""
                    if not _rbac_check(user_perms, skill_name, tool_name):
                        session.add_audit(
                            "tool_blocked_rbac",
                            {"tool": tool_name, "role": role_name, "skill": skill_name},
                        )
                        return (
                            f"⚠️ Permission denied. Role '{role_name}' cannot use "
                            f"{skill_name}:{tool_name}."
                        )
        except ImportError:
            pass  # RBAC skill not available — skip check

        # Guardrails: config-level blocklist + approval-required list.
        # Second layer on top of trust-level capability — operator can block
        # specific tools regardless of trust level, or mark them as requiring
        # explicit approval (e.g. send_email, execute_command).
        # Note: pass tool_registry=None — self.tools is the simple tools.ToolRegistry
        # (no .status/.safety_level), not the advanced tool_registry.ToolRegistry.
        # The blocklist and approval-required checks still work; registry-based
        # safety level validation is skipped gracefully when registry is None.
        guardrail_allowed, guardrail_reason, requires_approval = self.guardrails.check_tool_call(
            tool_name, tool_input, tool_registry=None
        )

        if not guardrail_allowed:
            session.add_audit(
                "tool_blocked_guardrail",
                {
                    "tool": tool_name,
                    "reason": guardrail_reason,
                },
            )
            return f"⚠️ {guardrail_reason}"

        if requires_approval:
            session.add_audit(
                "tool_blocked_needs_approval",
                {
                    "tool": tool_name,
                    "reason": guardrail_reason,
                },
            )
            return (
                f"⚠️ '{tool_name}' requires administrator approval and cannot run automatically. "
                f"Please contact your admin or use a manual workflow."
            )

        # Check if confirmation needed
        if needs_confirm:
            session.add_audit("tool_requires_confirmation", {"tool": tool_name})
            logger.debug(
                f"Tool {tool_name}: capability-level confirm noted; skill-level gate handles UI"
            )

        # Execute tool with span tracking
        session.add_audit(
            "tool_executed",
            {
                "tool": tool_name,
                "input_preview": str(tool_input)[:200],
                "user": user_context.user.email if user_context else None,
            },
        )

        # ── Tool execution + metrics ──────────────────────────────────────────
        # Wrap the actual execute() call with timing so every tool call is
        # recorded: duration_ms, success/failure, input/output sizes.
        _tool_start = time.time()
        _tool_error: Optional[str] = None
        if trace:
            with trace.span(f"tool:{tool_name}") as span:
                result = self.tools.execute(tool_name, tool_input, context=context)
                span.metadata["tool_input"] = tool_input
        else:
            result = self.tools.execute(tool_name, tool_input, context=context)

        _tool_duration_ms = (time.time() - _tool_start) * 1000

        # ── Inline confirmation intercept ─────────────────────────────────────
        # Skills return a ConfirmationRequired object when they need approval.
        # Store the deferred call and return a channel-routable sentinel string.
        if hasattr(result, "is_confirmation_required") and result.is_confirmation_required():
            import datetime as _dt
            import secrets as _sec

            from familiar.core.confirmations import SENTINEL_PREFIX

            token = _sec.token_hex(8)
            now = _dt.datetime.now(_dt.timezone.utc)
            session.pending_confirmations[token] = {
                "tool_name": result.tool_name,
                "tool_input": result.tool_input,
                "preview": result.preview,
                "risk": result.risk,
                "created_at": now.isoformat(),
                "expires_at": (now + _dt.timedelta(seconds=300)).isoformat(),
            }
            session.add_audit(
                "confirmation_pending",
                {
                    "tool": result.tool_name,
                    "token": token,
                    "risk": result.risk,
                },
            )
            self.sessions.save_session(session)
            return f"{SENTINEL_PREFIX}{token}"

        # ── Phase 4: Session context capture (shared helper) ────────────────
        _capture_context_from_result(tool_name, tool_input, result, session, self.sessions)
        _is_error = (
            result
            and isinstance(result, str)
            and (result.startswith("⚠️") or result.startswith("Error"))
        )
        if _is_error:
            _tool_error = result[:200]
        try:
            self.metrics.record_tool_execution(
                tool_name=tool_name,
                duration_ms=_tool_duration_ms,
                success=not _is_error,
                error_message=_tool_error,
                input_size=len(str(tool_input)),
                output_size=len(result) if result else 0,
                user_id=str(context.get("user_id", "")),
            )
        except Exception as _m_err:
            logger.debug(f"Metrics record_tool_execution skipped: {_m_err}")

        # ── Analytics: record tool call ─────────────────────────────
        _skill_name = ""
        try:
            _skill_name = self._get_skill_for_tool(tool_name) or ""
            get_analytics_store().record_tool_call(
                user_id=str(context.get("user_id", "")),
                channel=str(context.get("channel", "")),
                skill=_skill_name,
                action=tool_name,
                latency_ms=int(_tool_duration_ms),
                success=not _is_error,
                error_message=_tool_error,
                metadata={
                    "tool_input": tool_input,
                    "tool_result_preview": (result[:500] if result else ""),
                },
            )
        except Exception as _analytics_err:
            logger.debug(f"Analytics record_tool_call skipped: {_analytics_err}")

        # ── Bus event spine ───────────────────────────────────────────────────
        # Publish a "tool.executed" event after every successful tool call.
        # Skills subscribe to react without LLM chaining:
        #   bus.subscribe("tool.executed", handle_any_tool)
        #   bus.subscribe("tool.executed", handler,
        #       filter_fn=lambda m: m.payload["tool"] == "create_donor")
        # The topic hierarchy mirrors tool name:
        #   tool.executed          — every tool
        #   tool.<tool_name>       — specific tool (e.g. tool.create_donor)
        try:
            _bus_payload = {
                "tool": tool_name,
                "skill": _skill_name,
                "user_id": str(user_id) if (user_id := context.get("user_id")) else "",
                "success": not _is_error,
                "result_preview": result[:200] if result else "",
                "input_preview": str(tool_input)[:200],
            }
            self.bus.publish("tool.executed", _bus_payload, source_skill=_skill_name)
            self.bus.publish(f"tool.{tool_name}", _bus_payload, source_skill=_skill_name)
        except Exception as _bus_err:
            logger.debug(f"Bus publish skipped after tool execution: {_bus_err}")

        return result

    # ── Phase 3: Self-Correction Helpers ──────────────────────

    # Error indicators in tool results
    _ERROR_PREFIXES = ("⚠️", "Error:", "error:", "ERROR:", "Failed:", "FAILED:")
    _ERROR_SUBSTRINGS = (
        "Permission denied",
        "not found",
        "does not exist",
        "invalid",
        "connection refused",
        "timed out",
        "timeout",
        "rate limit",
        "exceeds limit",
    )

    # Error classification for reflection guidance
    _ERROR_CLASSES = {
        "permission": {
            "patterns": ("Permission denied", "not allowed", "read-only", "Missing:"),
            "action": "Report this limitation to the user. Do NOT retry — permissions cannot change mid-conversation.",
            "retryable": False,
        },
        "not_found": {
            "patterns": ("not found", "does not exist", "no results", "no match"),
            "action": "Try searching with different terms, check for typos, or ask the user to clarify.",
            "retryable": True,
        },
        "validation": {
            "patterns": (
                "invalid ",
                "must be ",
                "expected type",
                "required field",
                "cannot be empty",
                "is required",
            ),
            "action": "Check the error message for the correct format, then retry with corrected parameters.",
            "retryable": True,
        },
        "connection": {
            "patterns": (
                "connection refused",
                "timed out",
                "timeout",
                "unreachable",
                "connection error",
            ),
            "action": "This is a transient infrastructure issue. Inform the user and suggest trying again shortly.",
            "retryable": False,
        },
        "rate_limit": {
            "patterns": ("rate limit", "too many requests", "quota exceeded", "exceeds limit"),
            "action": "Inform the user about the rate limit. Do NOT retry immediately.",
            "retryable": False,
        },
    }

    def _is_tool_error(self, result: str) -> bool:
        """Detect whether a tool result is an error."""
        if not result:
            return False
        r = result.strip()
        if any(r.startswith(p) for p in self._ERROR_PREFIXES):
            return True
        r_lower = r.lower()
        if any(s.lower() in r_lower for s in self._ERROR_SUBSTRINGS):
            return True
        return False

    def _classify_error(self, error_text: str) -> tuple:
        """
        Classify an error into a category and return (class_name, action_hint, retryable).
        """
        lower = error_text.lower()
        for cls_name, cls_info in self._ERROR_CLASSES.items():
            if any(p.lower() in lower for p in cls_info["patterns"]):
                return cls_name, cls_info["action"], cls_info["retryable"]
        return "unknown", "Analyze the error and decide the best recovery approach.", True

    def _format_tool_error(
        self,
        tool_name: str,
        tool_input: Dict,
        error_text: str,
        attempt: int,
        max_attempts: int,
    ) -> str:
        """
        Format a tool error with reflection guidance for the LLM.

        Instead of passing the raw error back, this adds structured
        analysis prompts that help the LLM recover intelligently.
        """
        cls_name, action_hint, retryable = self._classify_error(error_text)

        parts = [
            f"TOOL ERROR [{tool_name}] (attempt {attempt}/{max_attempts})",
            f"Error: {error_text}",
            f"Classification: {cls_name}",
            f"Input was: {json.dumps(tool_input)[:200]}",
            "",
            "Recovery guidance:",
            f"  {action_hint}",
        ]

        if retryable and attempt < max_attempts:
            parts.append(
                f"  You may retry with corrected parameters ({max_attempts - attempt} attempts remaining)."
            )
        elif not retryable:
            parts.append("  Do NOT retry this tool. Inform the user or try a different approach.")

        return "\n".join(parts)

    def _format_tool_exhausted(self, tool_name: str, attempts: int) -> str:
        """Format message when a tool has been retried too many times."""
        return (
            f"TOOL EXHAUSTED [{tool_name}]: Failed {attempts} times. "
            f"Stop calling this tool. Inform the user what you were trying to do, "
            f"what went wrong, and suggest alternatives or manual steps they can take."
        )

    # ============================================================
    # PHASE 1: MULTI-USER HELPERS
    # ============================================================

    def _sync_user_to_session(self, user_context: "UserContext", session: SecureSession):
        """
        Sync UserContext role to SecureSession trust level.

        This bridges the new multi-user system with the existing
        progressive trust security model.

        Role → Trust mapping:
            ADMIN → OWNER (full access)
            STAFF → TRUSTED (most capabilities)
            READONLY → KNOWN (read-only capabilities)
        """
        if not HAS_USER_MANAGEMENT or not user_context:
            # Check if this user is the configured owner (OWNER_TELEGRAM_ID or equivalent).
            # The Telegram channel does this in _get_session(), but agent.chat() is called
            # directly by tests and non-Telegram callers, so we replicate the check here.
            owner_id = getattr(self.config.channels, "owner_telegram_id", None)
            if owner_id and str(session.user_id) == str(owner_id):
                if session.trust_level != TrustLevel.OWNER:
                    session.set_trust_level(TrustLevel.OWNER)
                    logger.info(
                        f"Auto-promoted owner {session.user_id} to OWNER trust (agent sync)"
                    )
                return

            # Fallback: restore trust from previously persisted role on session.
            # This keeps staff from reverting to STRANGER if users.py fails to
            # import at bot restart (e.g. sqlite3 lock, missing dep).
            if session.user_role:
                _role_to_trust = {
                    "admin": TrustLevel.OWNER,
                    "staff": TrustLevel.TRUSTED,
                    "readonly": TrustLevel.KNOWN,
                }
                restored = _role_to_trust.get(session.user_role)
                if restored and session.trust_level == TrustLevel.STRANGER:
                    session.trust_level = restored
                    logger.warning(
                        f"user_management unavailable; restored trust={restored.value} "
                        f"from persisted role={session.user_role} for user={session.user_id}"
                    )
            return

        role = user_context.user.role

        # Map role to trust level and merge capabilities into _explicit_grants.
        # Use |= (union) so manually granted capabilities are preserved.
        if role == UserRole.ADMIN:
            session.trust_level = TrustLevel.OWNER
            session._explicit_grants |= {c.value for c in Capability}
        elif role == UserRole.STAFF:
            session.trust_level = TrustLevel.TRUSTED
            session._explicit_grants |= {
                c.value
                for c in {
                    Capability.READ_TIME,
                    Capability.READ_WEATHER,
                    Capability.READ_MEMORY,
                    Capability.WRITE_MEMORY,
                    Capability.READ_CALENDAR,
                    Capability.WRITE_CALENDAR,
                    Capability.READ_TASKS,
                    Capability.WRITE_TASKS,
                    Capability.SEND_NOTIFICATIONS,
                    Capability.HTTP_REQUESTS,
                }
            }
        else:  # READONLY
            session.trust_level = TrustLevel.KNOWN
            session._explicit_grants |= {
                c.value
                for c in {
                    Capability.READ_TIME,
                    Capability.READ_WEATHER,
                    Capability.READ_MEMORY,
                    Capability.READ_CALENDAR,
                    Capability.READ_TASKS,
                }
            }

        logger.debug(
            f"Synced {user_context.user.email} role {role.value} to trust {session.trust_level.value}"
        )
        # Persist role to session so trust survives bot restarts even if
        # core/users.py is temporarily unavailable at session load time.
        session.user_role = role.value

    def _get_user_history(self, user_context: "UserContext", channel: str, limit: int = 20) -> list:
        """
        Get conversation history from user's isolated data store.

        Falls back to global history if data store unavailable.
        """
        if not HAS_USER_MANAGEMENT or not get_data_store:
            return self.history.get_history(user_context.user.id, channel)

        try:
            store = get_data_store(
                user_id=user_context.user.id, user_role=user_context.user.role.value
            )

            # Use conversation ID based on channel
            conv_id = f"{channel}_current"
            messages = store.load_history(conv_id)

            # Return last N messages as history format
            return messages[-limit:] if messages else []
        except Exception as e:
            logger.warning(f"Could not load user history: {e}")
            return self.history.get_history(user_context.user.id, channel)

    def _save_user_history(
        self, user_context: "UserContext", channel: str, user_message: str, assistant_response: str
    ):
        """
        Save conversation to user's isolated data store.

        Also saves to global history for backward compatibility.
        """
        user_id = user_context.user.id

        # Always save to global history (backward compatibility)
        self.history.add_message(user_id, "user", user_message, channel)
        self.history.add_message(user_id, "assistant", assistant_response, channel)

        # Also save to user's isolated data store
        if HAS_USER_MANAGEMENT and get_data_store:
            try:
                store = get_data_store(user_id=user_id, user_role=user_context.user.role.value)

                conv_id = f"{channel}_current"

                # Load existing, append, save
                messages = store.load_history(conv_id)
                messages.append({"role": "user", "content": user_message})
                messages.append({"role": "assistant", "content": assistant_response})

                # Keep last 100 messages
                if len(messages) > 100:
                    messages = messages[-100:]

                store.save_history(conv_id, messages)
            except Exception as e:
                logger.warning(f"Could not save user history: {e}")

    # ============================================================
    # PHASE 2: ANALYTICS HELPERS
    # ============================================================

    def _record_analytics(
        self,
        user_id: str,
        channel: str,
        response: "LLMResponse",
        start_time: float,
        user_context: Optional["UserContext"] = None,
        skill: str = None,
    ):
        """
        Record usage analytics for this request.

        Called after successful chat completion.
        """
        try:
            import time

            from .analytics import record_agent_usage

            # Calculate latency
            latency_ms = int((time.time() - start_time) * 1000)

            # Get token counts from response.usage dict (if available)
            usage = getattr(response, "usage", None) or {}
            tokens_in = usage.get("input_tokens", 0) or 0
            tokens_out = usage.get("output_tokens", 0) or 0

            # Estimate if not provided
            if tokens_in == 0 and tokens_out == 0 and response.text:
                tokens_out = len(response.text) // 4  # Rough estimate

            # Get user email if available
            user_email = None
            if user_context and HAS_USER_MANAGEMENT:
                user_email = user_context.user.email

            record_agent_usage(
                user_id=user_id,
                channel=channel,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                latency_ms=latency_ms,
                model=self.provider.name if self.provider else None,
                skill=skill,
                user_email=user_email,
                success=True,
            )
        except ImportError:
            # Analytics not available
            pass
        except Exception as e:
            logger.warning(f"Could not record analytics: {e}")

    # ============================================================
    # END PHASE 2 HELPERS
    # ============================================================

    def clear_history(self, user_id: Any = "default", channel: str = "default"):
        """Clear conversation history for a user."""
        self.history.clear(user_id, channel)

    def remember(self, key: str, value: str, category: str = "fact"):
        """Store something in memory."""
        if self.memory:
            self.memory.remember(key, value, category=category)

    def recall(self, query: str) -> list:
        """Search memory."""
        if self.memory:
            return self.memory.search(query)
        return []

    def add_reminder(
        self,
        name: str,
        message: str,
        when: datetime,
        channel: Optional[str] = None,
        chat_id: Optional[str] = None,
        callback: Optional[Any] = None,
    ) -> str:
        """Add a one-time reminder."""
        if not self.scheduler:
            return "Scheduler not enabled"

        minutes_until = (when - datetime.now()).total_seconds() / 60

        def reminder_callback(task):
            if callback:
                callback(message, channel, chat_id)

        task_id = self.scheduler.add_task(
            name=name,
            description=message,
            frequency=TaskFrequency.ONCE,
            callback=reminder_callback,
            channel=channel,
            chat_id=chat_id,
            interval_minutes=int(minutes_until),
            payload={"message": message},
        )

        return task_id

    def start_scheduler(self):
        """Start the background scheduler and register default proactive tasks."""
        if self.scheduler:
            self._register_default_tasks()
            self.scheduler.start()

    def _register_default_tasks(self):
        """Register built-in proactive tasks if not already present."""
        if not self.scheduler:
            return

        from .scheduler import TaskFrequency, TaskType

        # Check what's already registered (by name, not ID)
        existing_names = {t.name for t in self.scheduler.tasks.values()}

        defaults = [
            {
                "name": "morning_briefing",
                "description": "Daily morning briefing with calendar, tasks, and weather",
                "frequency": TaskFrequency.DAILY,
                "task_type": TaskType.BRIEFING,
                "time_of_day": "08:00",
                "payload": {
                    "prompt": (
                        "Give me my morning briefing. Include: "
                        "today's calendar events, pending tasks and deadlines, "
                        "weather if available, and any unread messages or notifications."
                    )
                },
            },
            {
                "name": "heartbeat",
                "description": "System health check every 4 hours",
                "frequency": TaskFrequency.HOURLY,
                "task_type": TaskType.HEARTBEAT,
                "interval_minutes": 240,
            },
            {
                "name": "eod_summary",
                "description": "End-of-day summary of completed work",
                "frequency": TaskFrequency.DAILY,
                "task_type": TaskType.BRIEFING,
                "time_of_day": "18:00",
                "payload": {
                    "prompt": (
                        "Give me an end-of-day summary. Include: "
                        "what was accomplished today, tasks completed, "
                        "upcoming deadlines, and anything that needs attention tomorrow."
                    )
                },
            },
        ]

        registered = 0
        for task_def in defaults:
            if task_def["name"] not in existing_names:
                try:
                    self.scheduler.add_task(**task_def)
                    registered += 1
                except Exception as e:
                    logger.debug(f"Could not register {task_def['name']}: {e}")

        if registered:
            logger.info(f"Registered {registered} default proactive task(s)")

    def stop_scheduler(self):
        """Stop the scheduler."""
        if self.scheduler:
            self.scheduler.stop()

    def get_status(self) -> dict:
        """Get agent status."""
        # Tool count: show owner-accessible tools (CLI = owner).
        # Raw registry count is misleading when trust filtering is active.
        total_tools = len(self.tools.tools)
        try:
            owner_session = SecureSession("_status", "cli")
            owner_session.set_trust_level(TrustLevel.OWNER)
            filtered = self._get_allowed_tools(owner_session)
            tool_count = len(filtered)
        except Exception:
            tool_count = total_tools

        return {
            "name": self.config.agent.name,
            "provider": self.provider.name,
            "memory_entries": len(self.memory.memories) if self.memory else 0,
            "skills_loaded": len(self.skills.skills),
            "tools_available": tool_count,
            "tools_registered": total_tools,
            "scheduled_tasks": len(self.scheduler.tasks) if self.scheduler else 0,
            "security_mode": self.security_mode.value,
            "active_sessions": len(self.sessions.get_all_sessions()),
            "model_router": "active" if self.model_router else "inactive",
        }

    def get_session(self, user_id: str, channel: str) -> SecureSession:
        """Get the secure session for a user."""
        return self.sessions.get_or_create_session(user_id, channel)

    def set_user_trust(self, user_id: str, channel: str, level: TrustLevel):
        """Manually set a user's trust level (admin action)."""
        session = self.sessions.get_or_create_session(user_id, channel)
        session.set_trust_level(level)
        self.sessions.save_session(session)

    def grant_capability(self, user_id: str, channel: str, cap: Capability):
        """Grant a specific capability to a user."""
        session = self.sessions.get_or_create_session(user_id, channel)
        session.grant_capability(cap)
        self.sessions.save_session(session)

    def deny_capability(self, user_id: str, channel: str, cap: Capability):
        """Deny a specific capability from a user."""
        session = self.sessions.get_or_create_session(user_id, channel)
        session.deny_capability(cap)
        self.sessions.save_session(session)


# Convenience function
def create_agent(config: Optional[Config] = None) -> Agent:
    """Create and return a configured agent."""
    return Agent(config)
