'use client';

import { useEffect } from 'react';
import { useAuthStore, selectCheckAuth } from '@/stores/auth';
import { AUTH_SESSION_EXPIRED_EVENT } from '@/lib/constants';
import { clearAccessToken } from '@/lib/auth-storage';

export function useAuthInit() {
  const checkAuth = useAuthStore(selectCheckAuth);

  useEffect(() => {
    checkAuth();

    const handleSessionExpired = () => {
      clearAccessToken();
      useAuthStore.setState({ user: null });
    };

    window.addEventListener(AUTH_SESSION_EXPIRED_EVENT, handleSessionExpired);
    return () => {
      window.removeEventListener(AUTH_SESSION_EXPIRED_EVENT, handleSessionExpired);
    };
  }, [checkAuth]);
}
