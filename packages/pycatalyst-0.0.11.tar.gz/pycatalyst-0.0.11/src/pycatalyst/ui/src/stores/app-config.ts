import { create } from 'zustand';
import { APP_NAME } from '@/lib/constants';

export interface AppConfigState {
  appName: string;
  theme: string;
  version: string;
  setAppConfig: (patch: Partial<Omit<AppConfigState, 'setAppConfig'>>) => void;
}

export const useAppConfigStore = create<AppConfigState>()((set) => ({
  appName: APP_NAME,
  theme: 'light',
  version: '',
  setAppConfig: (patch) => set(patch),
}));

export const selectAppName = (s: AppConfigState) => s.appName;
export const selectTheme = (s: AppConfigState) => s.theme;
export const selectVersion = (s: AppConfigState) => s.version;
export const selectSetAppConfig = (s: AppConfigState) => s.setAppConfig;
