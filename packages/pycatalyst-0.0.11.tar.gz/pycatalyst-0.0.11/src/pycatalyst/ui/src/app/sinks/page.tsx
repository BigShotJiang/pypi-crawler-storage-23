'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PageContainer } from '@/components/layout/PageContainer';
import { PageHeader } from '@/components/layout/PageHeader';
import { Database, FileText, Globe, HardDrive, Radio, Server } from 'lucide-react';

const sinks = [
  {
    name: 'Memory',
    description: 'Store generated records in-memory for programmatic access and testing. No external dependencies required.',
    icon: HardDrive,
    extras: null,
    config: `sink:
  type: memory`,
  },
  {
    name: 'File',
    description: 'Write records to JSON, CSV, or YAML files. Supports append mode for incremental writes.',
    icon: FileText,
    extras: null,
    config: `sink:
  type: file
  config:
    path: output/data.json
    format: json  # json, csv, yaml
    append: false`,
  },
  {
    name: 'HTTP',
    description: 'Send records via HTTP POST/PUT/PATCH to REST APIs. Supports batching, auth tokens, and custom headers.',
    icon: Globe,
    extras: 'pip install pycatalyst[http]',
    config: `sink:
  type: http
  config:
    url: http://localhost:8000/api/v1/data
    method: POST
    headers:
      Content-Type: application/json
    batch_size: 100
    timeout: 30`,
  },
  {
    name: 'Database',
    description: 'Insert records into any SQL database via SQLAlchemy. Supports batching, append/replace modes.',
    icon: Database,
    extras: 'pip install pycatalyst[db]',
    config: `sink:
  type: database
  config:
    connection_url: sqlite:///data.db
    table_name: generated_data
    batch_size: 500
    if_exists: append  # append or replace`,
  },
  {
    name: 'Kafka',
    description: 'Publish records as JSON messages to Kafka topics. Supports key fields and delivery callbacks.',
    icon: Radio,
    extras: 'pip install pycatalyst[kafka]',
    config: `sink:
  type: kafka
  config:
    bootstrap_servers: localhost:9092
    topic: test-data
    key_field: id
    flush_timeout: 10.0`,
  },
  {
    name: 'RabbitMQ',
    description: 'Publish records to RabbitMQ exchanges. Supports queue declaration, routing keys, and persistent delivery.',
    icon: Server,
    extras: 'pip install pycatalyst[rabbitmq]',
    config: `sink:
  type: rabbitmq
  config:
    url: amqp://guest:guest@localhost/
    exchange: ""
    routing_key: test-queue
    queue: test-queue
    declare_queue: true`,
  },
];

export default function SinksPage() {
  return (
    <PageContainer>
      <PageHeader
        title="Sinks"
        description="Available data sink types for delivering generated records to targets"
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sinks.map((sink) => {
          const Icon = sink.icon;
          return (
            <Card key={sink.name}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Icon className="h-6 w-6 text-primary" />
                  <div>
                    <CardTitle className="text-lg">{sink.name}</CardTitle>
                    {sink.extras && (
                      <Badge variant="secondary" className="mt-1 font-mono text-xs">
                        {sink.extras}
                      </Badge>
                    )}
                  </div>
                </div>
                <CardDescription className="mt-2">{sink.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <pre className="bg-muted rounded-md p-3 overflow-x-auto text-xs font-mono">
                  {sink.config}
                </pre>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </PageContainer>
  );
}
