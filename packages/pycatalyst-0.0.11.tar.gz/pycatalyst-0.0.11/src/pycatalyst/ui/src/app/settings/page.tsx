'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { PageContainer } from '@/components/layout/PageContainer';
import { PageHeader } from '@/components/layout/PageHeader';
import { loadSettings, saveSettings } from '@/lib/settings';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export default function SettingsPage() {
  const [apiUrl, setApiUrl] = useState('');
  const [saved, setSaved] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    const settings = loadSettings();
    setApiUrl(settings.apiServer.url);
  }, []);

  const handleSave = () => {
    const settings = loadSettings();
    settings.apiServer.url = apiUrl.trim();
    saveSettings(settings);
    setSaved(true);
    setTestResult(null);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const url = apiUrl.trim() || window.location.origin;
    try {
      const res = await fetch(`${url.replace(/\/+$/, '')}/health`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        setTestResult({ ok: true, message: 'API server is reachable' });
      } else {
        setTestResult({ ok: false, message: `Server returned ${res.status}` });
      }
    } catch {
      setTestResult({ ok: false, message: 'Cannot connect to API server' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader title="Settings" description="Configure PyCatalyst UI preferences" />

      <div className="space-y-6 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>API Server</CardTitle>
            <CardDescription>
              Configure the PyCatalyst API server URL. Leave empty to use the default (same origin proxy).
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="api-url">API URL</Label>
              <Input
                id="api-url"
                value={apiUrl}
                onChange={(e) => { setApiUrl(e.target.value); setSaved(false); }}
                placeholder="http://localhost:8006"
              />
              <p className="text-xs text-muted-foreground">
                Default: http://localhost:8006 — Start with: <code className="font-mono">pycatalyst api</code>
              </p>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saved}>
                {saved ? 'Saved!' : 'Save'}
              </Button>
              <Button variant="outline" onClick={handleTest} disabled={testing}>
                {testing ? 'Testing...' : 'Test Connection'}
              </Button>
            </div>

            {testResult && (
              <Alert variant={testResult.ok ? 'default' : 'destructive'}>
                {testResult.ok ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <AlertCircle className="h-4 w-4" />
                )}
                <AlertDescription>{testResult.message}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
