'use client';

import { useState } from 'react';
import { PageContainer } from '@/components/layout/PageContainer';
import { CollapsibleSidebar, type SidebarSection } from '@/components/sidebar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { api, ApiError } from '@/lib/api';
import type { MlRunResponse } from '@/lib/types';
import { BarChart3, Play, FileText, HelpCircle, RefreshCw } from 'lucide-react';

type ModelTrainingView = 'overview' | 'run' | 'results' | 'help';

const SIDEBAR_SECTIONS: SidebarSection[] = [
  {
    id: 'overview',
    title: 'Overview',
    icon: BarChart3,
    items: [{ id: 'overview', label: 'Overview' }],
  },
  {
    id: 'experiment',
    title: 'Experiment',
    icon: Play,
    items: [{ id: 'run', label: 'Run experiment' }],
  },
  {
    id: 'results',
    title: 'Results',
    icon: FileText,
    items: [{ id: 'results', label: 'Last run' }],
  },
  {
    id: 'help',
    title: 'Help',
    icon: HelpCircle,
    items: [{ id: 'help', label: 'Config reference' }],
  },
];

function getHeaderInfo(view: ModelTrainingView): { title: string; description: string } {
  switch (view) {
    case 'overview':
      return { title: 'Model Training', description: 'Run and inspect ML experiments from YAML config' };
    case 'run':
      return { title: 'Run experiment', description: 'Submit a YAML config to run a training job' };
    case 'results':
      return { title: 'Last run', description: 'Metrics, artifacts, and training history from the latest run' };
    case 'help':
      return { title: 'Config reference', description: 'Required YAML shape and backend options' };
    default:
      return { title: 'Model Training', description: '' };
  }
}

const HELP_CONTENT = `# Experiment config (YAML)

Top-level key \`experiment\` is required with at least:

- \`name\`: string — experiment name
- \`backend\`: one of \`pytorch\`, \`sklearn\`, \`huggingface\`

Example (minimal):

\`\`\`yaml
experiment:
  name: my-experiment
  backend: sklearn
  # ... backend-specific sections (data, model, train)
\`\`\`

Backends require different sections (data path, model architecture, training params). See package docs for each engine.`;

export default function ModelTrainingPage() {
  const [activeView, setActiveView] = useState<ModelTrainingView>('overview');
  const [lastResult, setLastResult] = useState<MlRunResponse | null>(null);
  const [yamlConfig, setYamlConfig] = useState('');
  const [running, setRunning] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);

  const handleSidebarItemClick = (_sectionId: string, itemId: string) => {
    setActiveView(itemId as ModelTrainingView);
    setRunError(null);
  };

  const handleRun = async () => {
    if (!yamlConfig.trim()) {
      setRunError('Enter a non-empty YAML config');
      return;
    }
    setRunError(null);
    setRunning(true);
    try {
      const result = await api.ml.runExperiment({ config: yamlConfig });
      setLastResult(result);
      setActiveView('results');
    } catch (err) {
      let msg = 'Run failed';
      if (err instanceof ApiError) {
        const d = err.response?.detail;
        msg = typeof d === 'object' && d !== null && 'message' in d
          ? String((d as { message: unknown }).message)
          : typeof d === 'string'
            ? d
            : err.message;
      } else if (err instanceof Error) {
        msg = err.message;
      }
      setRunError(msg);
    } finally {
      setRunning(false);
    }
  };

  const { title, description } = getHeaderInfo(activeView);

  return (
    <PageContainer fullHeight>
      <CollapsibleSidebar
        sections={SIDEBAR_SECTIONS}
        headerTitle="Model Training"
        onItemClick={handleSidebarItemClick}
        selectedItemId={activeView}
      />
      <main className="flex-1 overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          </div>
          {activeView === 'overview' && (
            <Button variant="outline" onClick={() => setActiveView('run')}>
              Run experiment
            </Button>
          )}
        </div>

        {activeView === 'overview' && (
          <Card>
            <CardHeader>
              <CardTitle>Overview</CardTitle>
              <CardDescription>
                Run ML experiments (PyTorch, sklearn, Hugging Face) from a YAML config. Submit config in Run experiment, then view metrics and artifacts in Last run.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Backends: <code className="bg-muted px-1 rounded">pytorch</code>, <code className="bg-muted px-1 rounded">sklearn</code>, <code className="bg-muted px-1 rounded">huggingface</code>.
                {lastResult && (
                  <span className="block mt-2">
                    Last run: <strong>{lastResult.name}</strong> ({lastResult.backend}) — {lastResult.duration_seconds.toFixed(1)}s
                  </span>
                )}
              </p>
              <Button onClick={() => setActiveView('run')}>
                Run experiment
              </Button>
            </CardContent>
          </Card>
        )}

        {activeView === 'run' && (
          <Card>
            <CardHeader>
              <CardTitle>Run experiment</CardTitle>
              <CardDescription>
                Paste your experiment YAML below. The config must include <code className="bg-muted px-1 rounded">experiment.name</code> and <code className="bg-muted px-1 rounded">experiment.backend</code>.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {runError && (
                <Alert variant="destructive">
                  <AlertDescription>{runError}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-2">
                <Label htmlFor="yaml-config">YAML config</Label>
                <textarea
                  id="yaml-config"
                  className="w-full min-h-[240px] rounded-md border border-input bg-background px-3 py-2 text-sm font-mono ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  placeholder="experiment:\n  name: my-exp\n  backend: sklearn\n  ..."
                  value={yamlConfig}
                  onChange={(e) => setYamlConfig(e.target.value)}
                />
              </div>
              <Button onClick={handleRun} disabled={running}>
                {running ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}
                {running ? 'Running…' : 'Run'}
              </Button>
            </CardContent>
          </Card>
        )}

        {activeView === 'results' && (
          <Card>
            <CardHeader>
              <CardTitle>Last run</CardTitle>
              <CardDescription>
                Result of the most recent experiment run from this session.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {lastResult ? (
                <div className="space-y-4 text-sm">
                  <div className="grid grid-cols-2 gap-2 max-w-md">
                    <span className="text-muted-foreground">Name</span>
                    <span className="font-medium">{lastResult.name}</span>
                    <span className="text-muted-foreground">Backend</span>
                    <span className="font-medium">{lastResult.backend}</span>
                    <span className="text-muted-foreground">Duration</span>
                    <span className="font-medium">{lastResult.duration_seconds.toFixed(2)}s</span>
                  </div>
                  {Object.keys(lastResult.metrics).length > 0 && (
                    <div>
                      <h4 className="font-medium text-foreground mb-2">Metrics</h4>
                      <pre className="bg-muted p-3 rounded-md overflow-x-auto text-xs">
                        {JSON.stringify(lastResult.metrics, null, 2)}
                      </pre>
                    </div>
                  )}
                  {Object.keys(lastResult.artifacts).length > 0 && (
                    <div>
                      <h4 className="font-medium text-foreground mb-2">Artifacts</h4>
                      <pre className="bg-muted p-3 rounded-md overflow-x-auto text-xs">
                        {JSON.stringify(lastResult.artifacts, null, 2)}
                      </pre>
                    </div>
                  )}
                  {lastResult.training_history.length > 0 && (
                    <div>
                      <h4 className="font-medium text-foreground mb-2">Training history</h4>
                      <pre className="bg-muted p-3 rounded-md overflow-x-auto text-xs max-h-48">
                        {JSON.stringify(lastResult.training_history, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-muted-foreground">
                  No run yet. Use Run experiment to submit a config.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {activeView === 'help' && (
          <Card>
            <CardHeader>
              <CardTitle>Config reference</CardTitle>
              <CardDescription>
                Required YAML structure for experiment config.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto text-sm whitespace-pre-wrap font-mono text-foreground">
                {HELP_CONTENT}
              </pre>
            </CardContent>
          </Card>
        )}
      </main>
    </PageContainer>
  );
}
