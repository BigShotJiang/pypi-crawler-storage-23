'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { TerminalPanel, type PanelType } from '@/components/workbench/TerminalPanel';
import { WorkbenchToolbar, type SplitDirection } from '@/components/workbench/WorkbenchToolbar';
import { ContainerDialog } from '@/components/workbench/ContainerDialog';
import { DatabaseDialog } from '@/components/workbench/DatabaseDialog';
import { CreateEnvDialog } from '@/components/workbench/CreateEnvDialog';
import { InstallPackageDialog } from '@/components/workbench/InstallPackageDialog';
import { PackagePanel } from '@/components/workbench/PackagePanel';
import { SendDataDialog } from '@/components/workbench/SendDataDialog';
import { ServiceStatusBar } from '@/components/workbench/ServiceStatusBar';
import { Terminal as TerminalIcon } from 'lucide-react';
import {
  getCapabilities,
  createEnvironment,
  destroyEnvironment,
  createSessionInEnv,
  deleteSession,
  refreshSessionEnv,
  listEnvironments,
  listSessions,
  createService,
  listServices,
  getService,
  destroyService,
  type WorkbenchCapabilities,
  type EnvironmentInfo,
  type WorkbenchSession,
  type ServiceInfo,
  type CreateServiceOptions,
  type PackageInfo,
} from '@/lib/workbench';
import { loadWorkbenchLayout, saveWorkbenchLayout } from '@/lib/workbench-storage';

interface PanelState {
  id: string;
  sessionId: string;
  command: string;
  envId: string;
  panelType: PanelType;
}

let nextPanelId = 1;
function makePanelId(): string {
  return `panel-${nextPanelId++}`;
}

function panelTypeFromSession(session: WorkbenchSession): PanelType {
  return session.backend_type === 'docker' ? 'container' : 'venv';
}

export default function WorkbenchPage() {
  const [capabilities, setCapabilities] = useState<WorkbenchCapabilities>({
    venv: true,
    docker: false,
    services: false,
  });
  const [environments, setEnvironments] = useState<EnvironmentInfo[]>([]);
  const [activeEnvId, setActiveEnvId] = useState<string | null>(null);
  const [envLoading, setEnvLoading] = useState(true);
  const [panels, setPanels] = useState<PanelState[]>([]);
  const [activePanelId, setActivePanelId] = useState<string>('');
  const [splitDirection, setSplitDirection] = useState<SplitDirection>('horizontal');
  const [splitRatio, setSplitRatio] = useState(50);
  const [envCreating, setEnvCreating] = useState(false);
  const [containerDialogOpen, setContainerDialogOpen] = useState(false);
  const [containerLaunching, setContainerLaunching] = useState(false);
  const [databaseDialogOpen, setDatabaseDialogOpen] = useState(false);
  const [databaseLaunching, setDatabaseLaunching] = useState(false);
  const [services, setServices] = useState<ServiceInfo[]>([]);
  const [packagePanelOpen, setPackagePanelOpen] = useState(false);
  const [installDialogOpen, setInstallDialogOpen] = useState(false);
  const [packages, setPackages] = useState<PackageInfo[]>([]);
  const [createEnvDialogOpen, setCreateEnvDialogOpen] = useState(false);
  const [sendDataDialogOpen, setSendDataDialogOpen] = useState(false);
  const isDragging = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const initRef = useRef(false);

  // Keep a ref in sync with panels so callbacks never see stale state.
  const panelsRef = useRef<PanelState[]>(panels);
  useEffect(() => {
    panelsRef.current = panels;
  }, [panels]);

  const environmentsRef = useRef<EnvironmentInfo[]>(environments);
  useEffect(() => {
    environmentsRef.current = environments;
  }, [environments]);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    const saved = loadWorkbenchLayout();

    (async () => {
      try {
        const caps = await getCapabilities();
        setCapabilities(caps);
      } catch {
        // API may be unavailable; fall back to defaults
      }

      try {
        // Restore existing environments and their live sessions.
        const existingEnvs = await listEnvironments();
        if (existingEnvs.length > 0) {
          setEnvironments(existingEnvs);

          // Restore active env from saved layout if it still exists.
          const savedEnvExists = saved.activeEnvId
            && existingEnvs.some((e) => e.env_id === saved.activeEnvId);
          setActiveEnvId(savedEnvExists ? saved.activeEnvId : existingEnvs[0].env_id);

          const sessions = await listSessions();
          const aliveSessions = sessions.filter((s) => s.alive);
          if (aliveSessions.length > 0) {
            const restored: PanelState[] = aliveSessions.map((s) => ({
              id: makePanelId(),
              sessionId: s.session_id,
              command: s.command,
              envId: s.env_id,
              panelType: panelTypeFromSession(s),
            }));

            // Reorder panels to match saved order, appending any unsaved.
            if (saved.panelSessionIds.length > 0) {
              const bySession = new Map(restored.map((p) => [p.sessionId, p]));
              const ordered: PanelState[] = [];
              for (const sid of saved.panelSessionIds) {
                const p = bySession.get(sid);
                if (p) {
                  ordered.push(p);
                  bySession.delete(sid);
                }
              }
              // Append panels not in the saved list.
              for (const p of bySession.values()) {
                ordered.push(p);
              }
              setPanels(ordered);

              // Restore active panel by matching saved session ID.
              const activePanel = saved.activePanelSessionId
                ? ordered.find((p) => p.sessionId === saved.activePanelSessionId)
                : null;
              setActivePanelId(activePanel ? activePanel.id : ordered[0].id);
            } else {
              setPanels(restored);
              setActivePanelId(restored[0].id);
            }

            // Restore split direction and ratio from saved layout.
            setSplitDirection(saved.splitDirection);
            setSplitRatio(saved.splitRatio);
            return;
          }

          // Environments exist but no live sessions — spawn a default shell.
          const session = await createSessionInEnv(existingEnvs[0].env_id, 'bash');
          const panelId = makePanelId();
          setPanels([
            {
              id: panelId,
              sessionId: session.session_id,
              command: 'bash',
              envId: existingEnvs[0].env_id,
              panelType: 'venv',
            },
          ]);
          setActivePanelId(panelId);
          return;
        }

        // No existing environments — create a fresh one.
        const env = await createEnvironment('venv');
        setEnvironments([env]);
        setActiveEnvId(env.env_id);

        const session = await createSessionInEnv(env.env_id, 'bash');
        const panelId = makePanelId();
        setPanels([
          {
            id: panelId,
            sessionId: session.session_id,
            command: 'bash',
            envId: env.env_id,
            panelType: 'venv',
          },
        ]);
        setActivePanelId(panelId);
      } catch {
        // Initialization failed — user will see the empty state
      } finally {
        setEnvLoading(false);
      }
    })();
  }, []);

  // Re-fetch capabilities when tab becomes visible or periodically, so the Server
  // button becomes clickable if Docker was started after the page loaded.
  useEffect(() => {
    const refresh = () => {
      getCapabilities()
        .then(setCapabilities)
        .catch(() => {});
    };

    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') refresh();
    };

    document.addEventListener('visibilitychange', onVisibilityChange);
    const interval = setInterval(refresh, 60_000);

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      clearInterval(interval);
    };
  }, []);

  // Fetch services when active env changes or periodically while services exist
  useEffect(() => {
    if (!activeEnvId) return;

    const refreshServices = () => {
      listServices(activeEnvId)
        .then(setServices)
        .catch(() => {});
    };

    refreshServices();

    // Poll while any service is in a transitional state
    const interval = setInterval(() => {
      refreshServices();
    }, 5000);

    return () => clearInterval(interval);
  }, [activeEnvId]);

  // Poll individual services that are still starting
  useEffect(() => {
    const starting = services.filter(
      (s) => s.status === 'creating' || s.status === 'starting',
    );
    if (starting.length === 0) return;

    const interval = setInterval(() => {
      for (const svc of starting) {
        getService(svc.service_id)
          .then((updated) => {
            if (updated) {
              setServices((prev) =>
                prev.map((s) => (s.service_id === updated.service_id ? updated : s)),
              );
            }
          })
          .catch(() => {});
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [services]);

  const addPanel = useCallback(
    async (command: string, panelType: PanelType) => {
      if (!activeEnvId) return;

      try {
        const session = await createSessionInEnv(activeEnvId, command);
        const panelId = makePanelId();
        setPanels((prev) => [
          ...prev,
          {
            id: panelId,
            sessionId: session.session_id,
            command,
            envId: activeEnvId,
            panelType,
          },
        ]);
        setActivePanelId(panelId);
      } catch {
        // Session creation failed — panel not added
      }
    },
    [activeEnvId],
  );

  const removePanel = useCallback((panelId: string) => {
    // Read the latest panels via ref to avoid stale closures.
    const current = panelsRef.current;
    const panel = current.find((p) => p.id === panelId);

    // Fire the side effect *outside* the state updater.
    if (panel) {
      deleteSession(panel.sessionId).catch(() => {});
    }

    setPanels((prev) => prev.filter((p) => p.id !== panelId));

    // Use the ref snapshot (not the closure) to pick the next active panel.
    setActivePanelId((prev) => {
      if (prev !== panelId) return prev;
      const remaining = current.filter((p) => p.id !== panelId);
      return remaining.length > 0 ? remaining[remaining.length - 1].id : '';
    });
  }, []);

  const clearAll = useCallback(async () => {
    // Snapshot via refs so this callback never depends on [panels, environments].
    const currentPanels = panelsRef.current;
    const currentEnvs = environmentsRef.current;

    for (const p of currentPanels) {
      deleteSession(p.sessionId).catch(() => {});
    }
    for (const env of currentEnvs) {
      destroyEnvironment(env.env_id).catch(() => {});
    }

    setEnvLoading(true);
    setPanels([]);
    setEnvironments([]);
    setActiveEnvId(null);

    try {
      const env = await createEnvironment('venv');
      setEnvironments([env]);
      setActiveEnvId(env.env_id);

      const session = await createSessionInEnv(env.env_id, 'bash');
      const panelId = makePanelId();
      setPanels([
        {
          id: panelId,
          sessionId: session.session_id,
          command: 'bash',
          envId: env.env_id,
          panelType: 'venv',
        },
      ]);
      setActivePanelId(panelId);
    } catch {
      // Reset failed — user will see the empty state
    } finally {
      setEnvLoading(false);
    }
  }, []);

  const handleRefreshEnv = useCallback(() => {
    const current = panelsRef.current;
    current.forEach((p) => {
      if (p.command === 'python' || p.command === 'ipython') {
        refreshSessionEnv(p.sessionId).catch(() => {});
      }
    });
  }, []);

  const handleLaunchContainer = useCallback(() => {
    if (!capabilities.docker) return;
    setContainerDialogOpen(true);
  }, [capabilities.docker]);

  const handleContainerLaunch = useCallback(
    async (opts: { command: string }) => {
      setContainerLaunching(true);
      try {
        const env = await createEnvironment('docker');
        setEnvironments((prev) => [...prev, env]);

        const session = await createSessionInEnv(env.env_id, opts.command);
        const panelId = makePanelId();
        setPanels((prev) => [
          ...prev,
          {
            id: panelId,
            sessionId: session.session_id,
            command: opts.command,
            envId: env.env_id,
            panelType: 'container',
          },
        ]);
        setActivePanelId(panelId);
        setContainerDialogOpen(false);
      } catch {
        // Container launch failed
      } finally {
        setContainerLaunching(false);
      }
    },
    [],
  );

  const handleLaunchDatabase = useCallback(() => {
    if (!capabilities.services) return;
    setDatabaseDialogOpen(true);
  }, [capabilities.services]);

  const handleDatabaseLaunch = useCallback(
    async (opts: CreateServiceOptions) => {
      if (!activeEnvId) return;
      setDatabaseLaunching(true);
      try {
        const svc = await createService(activeEnvId, opts);
        setServices((prev) => [...prev, svc]);
        setDatabaseDialogOpen(false);
      } catch {
        // Database launch failed
      } finally {
        setDatabaseLaunching(false);
      }
    },
    [activeEnvId],
  );

  const handleDestroyService = useCallback(async (serviceId: string) => {
    try {
      await destroyService(serviceId);
      setServices((prev) => prev.filter((s) => s.service_id !== serviceId));
    } catch {
      // Service destroy failed
    }
  }, []);

  const handleSwitchEnv = useCallback((envId: string) => {
    setActiveEnvId(envId);
  }, []);

  const handleCreateEnv = useCallback(() => {
    setCreateEnvDialogOpen(true);
  }, []);

  const handleCreateEnvSubmit = useCallback(
    async (backend: string, profile?: string) => {
      setEnvCreating(true);
      try {
        const env = await createEnvironment(backend, profile);
        setEnvironments((prev) => [...prev, env]);
        setActiveEnvId(env.env_id);
        setCreateEnvDialogOpen(false);
      } catch {
        // Environment creation failed
      } finally {
        setEnvCreating(false);
      }
    },
    [],
  );

  const handleDeleteEnv = useCallback(
    async (envId: string) => {
      const currentPanels = panelsRef.current;
      const currentEnvs = environmentsRef.current;

      // Close all panels belonging to this environment.
      const envPanels = currentPanels.filter((p) => p.envId === envId);
      for (const p of envPanels) {
        deleteSession(p.sessionId).catch(() => {});
      }
      setPanels((prev) => prev.filter((p) => p.envId !== envId));

      // Destroy the environment.
      destroyEnvironment(envId).catch(() => {});
      const remaining = currentEnvs.filter((e) => e.env_id !== envId);
      setEnvironments(remaining);

      // Switch active env to the first remaining.
      if (remaining.length > 0) {
        setActiveEnvId(remaining[0].env_id);
      }

      // Update active panel to first remaining panel.
      setActivePanelId((prev) => {
        const remainingPanels = currentPanels.filter((p) => p.envId !== envId);
        if (remainingPanels.find((p) => p.id === prev)) return prev;
        return remainingPanels.length > 0 ? remainingPanels[0].id : '';
      });
    },
    [],
  );

  const removeActivePanel = useCallback(() => {
    const current = panelsRef.current;
    const active = current.find((p) => p.id === activePanelId);
    if (active) removePanel(active.id);
  }, [activePanelId, removePanel]);

  const switchPanel = useCallback(
    (direction: 1 | -1) => {
      const current = panelsRef.current;
      if (current.length < 2) return;
      const idx = current.findIndex((p) => p.id === activePanelId);
      const next = (idx + direction + current.length) % current.length;
      setActivePanelId(current[next].id);
    },
    [activePanelId],
  );

  const hasPythonSessions = panels.some(
    (p) => p.command === 'python' || p.command === 'ipython',
  );

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      isDragging.current = true;

      const handleMouseMove = (e: MouseEvent) => {
        if (!isDragging.current || !containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        let ratio: number;
        if (splitDirection === 'horizontal') {
          ratio = ((e.clientX - rect.left) / rect.width) * 100;
        } else {
          ratio = ((e.clientY - rect.top) / rect.height) * 100;
        }
        setSplitRatio(Math.max(15, Math.min(85, ratio)));
      };

      const handleMouseUp = () => {
        isDragging.current = false;
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    },
    [splitDirection],
  );

  // -----------------------------------------------------------------------
  // Keyboard shortcuts (Ctrl+Shift+<key> to avoid conflicts with terminal)
  // -----------------------------------------------------------------------
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!e.ctrlKey || !e.shiftKey) return;

      switch (e.key) {
        case '`': // Ctrl+Shift+` — new shell
        case '~': // some keyboards send ~ for Ctrl+Shift+`
          e.preventDefault();
          addPanel('bash', 'venv');
          break;
        case 'P': // Ctrl+Shift+P — new Python REPL
          e.preventDefault();
          addPanel('python', 'venv');
          break;
        case 'I': // Ctrl+Shift+I — new IPython session
          e.preventDefault();
          addPanel('ipython', 'venv');
          break;
        case 'W': // Ctrl+Shift+W — close active panel
          e.preventDefault();
          removeActivePanel();
          break;
        case '[': // Ctrl+Shift+[ — previous panel
        case '{': // some keyboards
          e.preventDefault();
          switchPanel(-1);
          break;
        case ']': // Ctrl+Shift+] — next panel
        case '}': // some keyboards
          e.preventDefault();
          switchPanel(1);
          break;
        case 'R': // Ctrl+Shift+R — refresh environment
          e.preventDefault();
          handleRefreshEnv();
          break;
        case 'H': // Ctrl+Shift+H — horizontal split
          e.preventDefault();
          setSplitDirection('horizontal');
          break;
        case 'V': // Ctrl+Shift+V — vertical split
          e.preventDefault();
          setSplitDirection('vertical');
          break;
        case 'E': // Ctrl+Shift+E — new environment
          e.preventDefault();
          handleCreateEnv();
          break;
      }
    };

    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [addPanel, removeActivePanel, switchPanel, handleRefreshEnv, handleCreateEnv]);

  // -----------------------------------------------------------------------
  // Persist layout to localStorage on meaningful state changes
  // -----------------------------------------------------------------------
  useEffect(() => {
    // Skip while loading — prevents overwriting saved state with defaults.
    if (envLoading) return;

    const activePanel = panels.find((p) => p.id === activePanelId);
    saveWorkbenchLayout({
      splitDirection,
      splitRatio,
      activeEnvId,
      activePanelSessionId: activePanel ? activePanel.sessionId : null,
      panelSessionIds: panels.map((p) => p.sessionId),
    });
  }, [splitDirection, splitRatio, activeEnvId, activePanelId, panels, envLoading]);

  const firstPanel = panels[0];
  const restPanels = panels.slice(1);
  const showSplit = panels.length >= 2;

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] overflow-hidden">
      <ContainerDialog
        open={containerDialogOpen}
        onClose={() => setContainerDialogOpen(false)}
        onLaunch={handleContainerLaunch}
        loading={containerLaunching}
      />

      <DatabaseDialog
        open={databaseDialogOpen}
        onClose={() => setDatabaseDialogOpen(false)}
        onLaunch={handleDatabaseLaunch}
        loading={databaseLaunching}
      />

      <CreateEnvDialog
        open={createEnvDialogOpen}
        capabilities={capabilities}
        onClose={() => setCreateEnvDialogOpen(false)}
        onCreate={handleCreateEnvSubmit}
        loading={envCreating}
      />

      {activeEnvId && (
        <InstallPackageDialog
          open={installDialogOpen}
          envId={activeEnvId}
          onClose={() => setInstallDialogOpen(false)}
          onInstalled={(pkgs) => setPackages(pkgs)}
        />
      )}

      <SendDataDialog
        open={sendDataDialogOpen}
        onClose={() => setSendDataDialogOpen(false)}
      />

      <WorkbenchToolbar
        capabilities={capabilities}
        environments={environments}
        activeEnvId={activeEnvId}
        panelCount={panels.length}
        hasPythonSessions={hasPythonSessions}
        splitDirection={splitDirection}
        envLoading={envLoading}
        onAddPanel={addPanel}
        onSplitDirectionChange={setSplitDirection}
        onRefreshEnv={handleRefreshEnv}
        onClearAll={clearAll}
        onLaunchContainer={handleLaunchContainer}
        onLaunchDatabase={handleLaunchDatabase}
        onTogglePackages={() => setPackagePanelOpen((prev) => !prev)}
        onSendData={() => setSendDataDialogOpen(true)}
        onSwitchEnv={handleSwitchEnv}
        onCreateEnv={handleCreateEnv}
        onDeleteEnv={handleDeleteEnv}
        envCreating={envCreating}
      />

      <ServiceStatusBar services={services} onDestroy={handleDestroyService} />

      <div ref={containerRef} className="flex-1 min-h-0 p-2 relative">
        {activeEnvId && (
          <PackagePanel
            open={packagePanelOpen}
            envId={activeEnvId}
            onClose={() => setPackagePanelOpen(false)}
            onInstallClick={() => setInstallDialogOpen(true)}
            packages={packages}
            onPackagesChange={setPackages}
          />
        )}
        {envLoading && (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center">
              <div className="h-8 w-8 mx-auto mb-3 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
              <p className="text-sm">Creating environment...</p>
              <p className="text-xs mt-1 text-muted-foreground/60">
                Setting up isolated Python environment
              </p>
            </div>
          </div>
        )}

        {!envLoading && panels.length === 0 && (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center">
              <TerminalIcon className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No terminals open</p>
              <p className="text-xs mt-1">Click Shell, Python, or IPython to start</p>
            </div>
          </div>
        )}

        {!envLoading && panels.length === 1 && firstPanel && (
          <TerminalPanel
            key={firstPanel.sessionId}
            sessionId={firstPanel.sessionId}
            command={firstPanel.command}
            envId={firstPanel.envId}
            panelType={firstPanel.panelType}
            onClose={() => removePanel(firstPanel.id)}
            isActive={true}
            onFocus={() => setActivePanelId(firstPanel.id)}
          />
        )}

        {!envLoading && showSplit && (
          <div
            className={`flex h-full gap-0 ${splitDirection === 'vertical' ? 'flex-col' : 'flex-row'}`}
          >
            <div
              style={
                splitDirection === 'horizontal'
                  ? { width: `${splitRatio}%` }
                  : { height: `${splitRatio}%` }
              }
              className="min-w-0 min-h-0"
            >
              {firstPanel && (
                <TerminalPanel
                  key={firstPanel.sessionId}
                  sessionId={firstPanel.sessionId}
                  command={firstPanel.command}
                  envId={firstPanel.envId}
                  panelType={firstPanel.panelType}
                  onClose={() => removePanel(firstPanel.id)}
                  isActive={activePanelId === firstPanel.id}
                  onFocus={() => setActivePanelId(firstPanel.id)}
                />
              )}
            </div>

            <div
              className={`shrink-0 flex items-center justify-center group ${
                splitDirection === 'horizontal'
                  ? 'w-2 cursor-col-resize hover:bg-primary/10'
                  : 'h-2 cursor-row-resize hover:bg-primary/10'
              }`}
              onMouseDown={handleMouseDown}
            >
              <div
                className={`rounded-full bg-border group-hover:bg-primary/50 transition-colors ${
                  splitDirection === 'horizontal' ? 'w-0.5 h-8' : 'h-0.5 w-8'
                }`}
              />
            </div>

            <div
              style={
                splitDirection === 'horizontal'
                  ? { width: `${100 - splitRatio}%` }
                  : { height: `${100 - splitRatio}%` }
              }
              className={`min-w-0 min-h-0 flex ${
                restPanels.length > 1
                  ? splitDirection === 'horizontal'
                    ? 'flex-col'
                    : 'flex-row'
                  : ''
              } gap-1`}
            >
              {restPanels.map((panel) => (
                <div key={panel.sessionId} className="flex-1 min-h-0 min-w-0">
                  <TerminalPanel
                    sessionId={panel.sessionId}
                    command={panel.command}
                    envId={panel.envId}
                    panelType={panel.panelType}
                    onClose={() => removePanel(panel.id)}
                    isActive={activePanelId === panel.id}
                    onFocus={() => setActivePanelId(panel.id)}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
