'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { PageContainer } from '@/components/layout/PageContainer';
import { PageHeader } from '@/components/layout/PageHeader';
import { getApiBaseUrl } from '@/lib/settings';
import { Play, AlertCircle } from 'lucide-react';

const ENDPOINTS = [
  {
    name: 'Generate Data',
    method: 'POST',
    path: '/api/v1/generate',
    description: 'Generate synthetic data from an inline schema definition',
    example: JSON.stringify({
      name: 'test_schema',
      fields: [
        { name: 'id', type: 'int', constraints: { min: 1, max: 1000 } },
        { name: 'name', type: 'string' },
        { name: 'active', type: 'bool' },
      ],
      count: 5,
      seed: 42,
    }, null, 2),
  },
  {
    name: 'Infer Schema',
    method: 'POST',
    path: '/api/v1/infer',
    description: 'Infer a schema from sample records',
    example: JSON.stringify({
      records: [
        { id: 1, name: 'Alice', score: 95.5 },
        { id: 2, name: 'Bob', score: 87.3 },
      ],
      name: 'inferred_data',
    }, null, 2),
  },
  {
    name: 'Run Recipe',
    method: 'POST',
    path: '/api/v1/recipes/run',
    description: 'Execute a recipe configuration to generate and deliver data',
    example: JSON.stringify({
      name: 'api_test',
      schema: {
        fields: [
          { name: 'x', type: 'int' },
          { name: 'y', type: 'float' },
        ],
      },
      generation: { count: 10, seed: 42 },
    }, null, 2),
  },
  {
    name: 'Health Check',
    method: 'GET',
    path: '/health',
    description: 'Check API server health status',
    example: '',
  },
];

export default function DocumentationPage() {
  const [selectedEndpoint, setSelectedEndpoint] = useState(ENDPOINTS[0]);
  const [requestBody, setRequestBody] = useState(ENDPOINTS[0].example);
  const [response, setResponse] = useState<string | null>(null);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectEndpoint = (ep: typeof ENDPOINTS[0]) => {
    setSelectedEndpoint(ep);
    setRequestBody(ep.example);
    setResponse(null);
    setResponseStatus(null);
    setError(null);
  };

  const handleSend = async () => {
    setError(null);
    setResponse(null);
    setResponseStatus(null);
    setLoading(true);
    const base = getApiBaseUrl();
    try {
      const init: RequestInit = {
        method: selectedEndpoint.method,
        headers: { 'Content-Type': 'application/json' },
      };
      if (selectedEndpoint.method !== 'GET' && requestBody.trim()) {
        init.body = requestBody;
      }
      const res = await fetch(`${base}${selectedEndpoint.path}`, init);
      setResponseStatus(res.status);
      const text = await res.text();
      try {
        const json = JSON.parse(text);
        setResponse(JSON.stringify(json, null, 2));
      } catch {
        setResponse(text);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Request failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="API Playground"
        description="Test PyCatalyst API endpoints interactively"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Endpoint List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Endpoints</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            {ENDPOINTS.map((ep) => (
              <button
                key={ep.path}
                type="button"
                onClick={() => selectEndpoint(ep)}
                className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                  selectedEndpoint.path === ep.path
                    ? 'bg-primary/10 text-primary font-medium'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <span className="font-mono text-xs font-bold mr-2">{ep.method}</span>
                {ep.name}
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Request/Response */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <span className="font-mono text-sm px-2 py-1 rounded bg-primary/10 text-primary">
                  {selectedEndpoint.method}
                </span>
                <span className="font-mono text-sm">{selectedEndpoint.path}</span>
              </CardTitle>
              <CardDescription>{selectedEndpoint.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedEndpoint.method !== 'GET' && (
                <div className="space-y-2">
                  <Label>Request Body</Label>
                  <Textarea
                    value={requestBody}
                    onChange={(e) => setRequestBody(e.target.value)}
                    className="font-mono text-sm min-h-[200px]"
                  />
                </div>
              )}

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button onClick={handleSend} disabled={loading}>
                <Play className="h-4 w-4 mr-2" />
                {loading ? 'Sending...' : 'Send Request'}
              </Button>
            </CardContent>
          </Card>

          {response !== null && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  Response
                  {responseStatus !== null && (
                    <span className={`font-mono text-sm px-2 py-1 rounded ${
                      responseStatus < 400
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                    }`}>
                      {responseStatus}
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="bg-muted rounded-md p-4 overflow-auto max-h-[500px] text-xs font-mono">
                  {response}
                </pre>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </PageContainer>
  );
}
