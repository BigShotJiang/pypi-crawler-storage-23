'use client';

import { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { PageContainer } from '@/components/layout/PageContainer';
import { PageHeader } from '@/components/layout/PageHeader';
import { Switch } from '@/components/ui/switch';
import { api, ApiError } from '@/lib/api';
import type { GenerateField, InferField } from '@/lib/types';
import {
  Plus,
  Trash2,
  Play,
  AlertCircle,
  Search,
  BookOpen,
  LayoutGrid,
  FileJson,
} from 'lucide-react';

const FIELD_TYPES = [
  'string', 'int', 'float', 'bool', 'date', 'datetime', 'uuid', 'enum',
];

const BUILT_IN_TEMPLATES: Record<string, string> = {
  'Order Events': `name: order_events
description: Generate order events for testing
schema:
  fields:
    - name: order_id
      type: uuid
    - name: symbol
      type: enum
      constraints:
        choices: [AAPL, GOOGL, MSFT, AMZN]
    - name: quantity
      type: int
      constraints:
        min: 1
        max: 10000
    - name: price
      type: float
      constraints:
        min: 1.0
        max: 5000.0
    - name: side
      type: enum
      constraints:
        choices: [buy, sell]
    - name: timestamp
      type: datetime
generation:
  count: 100
  seed: 42`,
  'User Profiles': `name: user_profiles
description: Generate user profile data
schema:
  fields:
    - name: user_id
      type: uuid
    - name: username
      type: string
    - name: email
      type: string
    - name: age
      type: int
      constraints:
        min: 18
        max: 85
    - name: active
      type: bool
    - name: signup_date
      type: date
generation:
  count: 50
  seed: 123`,
  'Sensor Readings': `name: sensor_readings
description: Generate IoT sensor data
schema:
  fields:
    - name: sensor_id
      type: uuid
    - name: temperature
      type: float
      constraints:
        min: -20.0
        max: 50.0
    - name: humidity
      type: float
      constraints:
        min: 0.0
        max: 100.0
    - name: status
      type: enum
      constraints:
        choices: [online, offline, error]
    - name: reading_time
      type: datetime
generation:
  count: 200`,
};

interface FieldRow {
  id: number;
  name: string;
  type: string;
  nullable: boolean;
  constraintMin: string;
  constraintMax: string;
  constraintChoices: string;
  constraintPattern: string;
}

let nextId = 1;
function newField(): FieldRow {
  return {
    id: nextId++,
    name: '',
    type: 'string',
    nullable: false,
    constraintMin: '',
    constraintMax: '',
    constraintChoices: '',
    constraintPattern: '',
  };
}

/** Types that require nested children; infer API does not return children, so we cannot generate from them. */
const TYPES_REQUIRING_CHILDREN = ['object', 'array'];

function inferFieldToGenerateField(f: InferField): GenerateField {
  return {
    name: f.name,
    type: f.type,
    nullable: f.nullable ?? false,
    constraints: f.constraints ?? undefined,
  };
}

/** Build generate fields from inferred, excluding object/array (no children from infer). Returns { fields, omittedCount }. */
function inferredFieldsToGenerateFields(inferred: InferField[]): {
  fields: GenerateField[];
  omittedCount: number;
} {
  const omitted = inferred.filter((f) =>
    TYPES_REQUIRING_CHILDREN.includes(f.type.toLowerCase()),
  );
  const fields = inferred
    .filter((f) => !TYPES_REQUIRING_CHILDREN.includes(f.type.toLowerCase()))
    .map(inferFieldToGenerateField);
  return { fields, omittedCount: omitted.length };
}

/** Map JSON Schema property to our GenerateField type. */
function jsonSchemaPropertyToGenerateField(
  name: string,
  prop: Record<string, unknown>,
): GenerateField {
  const type = prop.type as string | undefined;
  const format = prop.format as string | undefined;
  const enumVal = prop.enum as unknown[] | undefined;
  const nullable =
    prop.nullable === true ||
    (Array.isArray(type) && type.includes('null')) ||
    type === 'null';

  let fieldType = 'string';
  const constraints: Record<string, unknown> = {};

  if (enumVal && enumVal.length > 0) {
    fieldType = 'enum';
    constraints.choices = enumVal.map(String);
  } else if (type === 'integer') {
    fieldType = 'int';
    if (typeof prop.minimum === 'number') constraints.min = prop.minimum;
    if (typeof prop.maximum === 'number') constraints.max = prop.maximum;
    if (prop.exclusiveMinimum === true) constraints.exclusiveMinimum = true;
    if (prop.exclusiveMaximum === true) constraints.exclusiveMaximum = true;
    if (typeof prop.multipleOf === 'number') constraints.multipleOf = prop.multipleOf;
  } else if (type === 'number') {
    fieldType = 'float';
    if (typeof prop.minimum === 'number') constraints.min = prop.minimum;
    if (typeof prop.maximum === 'number') constraints.max = prop.maximum;
    if (prop.exclusiveMinimum === true) constraints.exclusiveMinimum = true;
    if (prop.exclusiveMaximum === true) constraints.exclusiveMaximum = true;
    if (typeof prop.multipleOf === 'number') constraints.multipleOf = prop.multipleOf;
  } else if (type === 'boolean') {
    fieldType = 'bool';
  } else if (type === 'string') {
    if (format === 'date') fieldType = 'date';
    else if (format === 'date-time') fieldType = 'datetime';
    else if (format === 'uuid') fieldType = 'uuid';
    else fieldType = 'string';
    if (typeof prop.pattern === 'string') constraints.pattern = prop.pattern;
    if (typeof prop.minLength === 'number') constraints.min = prop.minLength;
    if (typeof prop.maxLength === 'number') constraints.max = prop.maxLength;
  }

  const field: GenerateField = {
    name,
    type: fieldType,
    nullable: nullable ?? false,
  };
  if (Object.keys(constraints).length > 0) field.constraints = constraints;
  return field;
}

/** Parse JSON Schema object and return GenerateField[] from properties. */
function parseJsonSchemaToFields(schema: Record<string, unknown>): GenerateField[] {
  const props = schema.properties as Record<string, Record<string, unknown>> | undefined;
  if (!props || typeof props !== 'object') return [];
  return Object.entries(props).map(([name, prop]) =>
    jsonSchemaPropertyToGenerateField(name, prop ?? {}),
  );
}

export default function GeneratePage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const modeParam = searchParams.get('mode');
  const initialTab =
    modeParam === 'infer'
      ? 'infer'
      : modeParam === 'recipe'
        ? 'recipe'
        : modeParam === 'json-schema'
          ? 'json-schema'
          : 'build';

  const [activeTab, setActiveTab] = useState(initialTab);
  const [results, setResults] = useState<Record<string, unknown>[] | null>(null);
  const [resultMeta, setResultMeta] = useState<{
    count: number;
    duration: number;
    sink?: string;
  } | null>(null);
  const [inferredFields, setInferredFields] = useState<InferField[] | null>(null);
  const [jsonSchemaFields, setJsonSchemaFields] = useState<GenerateField[] | null>(
    null,
  );

  useEffect(() => {
    const m = searchParams.get('mode');
    const tab =
      m === 'infer'
        ? 'infer'
        : m === 'recipe'
          ? 'recipe'
          : m === 'json-schema'
            ? 'json-schema'
            : 'build';
    setActiveTab(tab);
  }, [searchParams]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    const mode = value === 'build' ? '' : `?mode=${value}`;
    router.replace(`/generate${mode}`, { scroll: false });
  };

  const showInferredInResults = activeTab === 'infer' && inferredFields && !results;
  const showJsonSchemaInResults =
    activeTab === 'json-schema' && jsonSchemaFields && jsonSchemaFields.length > 0 && !results;

  return (
    <PageContainer>
      <PageHeader
        title="Generate"
        description="Infer schemas from data, paste a JSON Schema, build schemas with the form, or run YAML recipes — then generate synthetic data"
      />

      <Tabs value={activeTab} onValueChange={handleTabChange}>
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 max-w-2xl">
          <TabsTrigger value="infer">
            <Search className="h-4 w-4 mr-2" />
            Infer from data
          </TabsTrigger>
          <TabsTrigger value="json-schema">
            <FileJson className="h-4 w-4 mr-2" />
            JSON Schema
          </TabsTrigger>
          <TabsTrigger value="build">
            <LayoutGrid className="h-4 w-4 mr-2" />
            Build schema
          </TabsTrigger>
          <TabsTrigger value="recipe">
            <BookOpen className="h-4 w-4 mr-2" />
            Recipe (YAML)
          </TabsTrigger>
        </TabsList>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <div>
            <TabsContent value="infer" className="mt-0">
              <InferTab
                onInferred={setInferredFields}
                onGenerateResult={(records, count, duration) => {
                  setResults(records);
                  setResultMeta({ count, duration });
                }}
              />
            </TabsContent>
            <TabsContent value="build" className="mt-0">
              <BuildSchemaTab
                onResult={(records, duration) => {
                  setResults(records);
                  setResultMeta(records ? { count: records.length, duration } : null);
                }}
              />
            </TabsContent>
            <TabsContent value="json-schema" className="mt-0">
              <JsonSchemaTab
                onParsedFields={setJsonSchemaFields}
                onGenerateResult={(records, count, duration) => {
                  setResults(records);
                  setResultMeta({ count, duration });
                }}
              />
            </TabsContent>
            <TabsContent value="recipe" className="mt-0">
              <RecipeTab
                onResult={(records, count, sink, duration) => {
                  setResults(records);
                  setResultMeta({ count, duration, sink });
                }}
              />
            </TabsContent>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Results
                {resultMeta && results && (
                  <span className="text-sm font-normal text-muted-foreground ml-2">
                    {resultMeta.count} records
                    {resultMeta.sink != null && ` · ${resultMeta.sink} sink`}
                    {` · ${resultMeta.duration.toFixed(1)}ms`}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {results && results.length > 0 ? (
                <pre className="bg-muted rounded-md p-4 overflow-auto max-h-[600px] text-xs font-mono">
                  {JSON.stringify(results, null, 2)}
                </pre>
              ) : showInferredInResults ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground mb-3">Inferred schema</p>
                  {inferredFields!.map((field) => (
                    <div
                      key={field.name}
                      className="flex items-center gap-3 p-3 rounded-md border"
                    >
                      <span className="font-mono text-sm font-medium flex-1">
                        {field.name}
                      </span>
                      <span className="text-xs px-2 py-1 rounded bg-primary/10 text-primary font-medium">
                        {field.type}
                      </span>
                      {field.nullable && (
                        <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">
                          nullable
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ) : showJsonSchemaInResults ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground mb-3">
                    From JSON Schema
                  </p>
                  {jsonSchemaFields!.map((field) => (
                    <div
                      key={field.name}
                      className="flex items-center gap-3 p-3 rounded-md border"
                    >
                      <span className="font-mono text-sm font-medium flex-1">
                        {field.name}
                      </span>
                      <span className="text-xs px-2 py-1 rounded bg-primary/10 text-primary font-medium">
                        {field.type}
                      </span>
                      {field.nullable && (
                        <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">
                          nullable
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-16">
                  <p>
                  Use a tab to infer a schema, paste a JSON Schema, build one, or
                  run a recipe
                </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </Tabs>
    </PageContainer>
  );
}

function InferTab({
  onInferred,
  onGenerateResult,
}: {
  onInferred: (fields: InferField[] | null) => void;
  onGenerateResult: (
    records: Record<string, unknown>[],
    count: number,
    duration: number,
  ) => void;
}) {
  const [sampleInput, setSampleInput] = useState('');
  const [schemaName, setSchemaName] = useState('');
  const [inferredFields, setInferredFields] = useState<InferField[] | null>(null);
  const [count, setCount] = useState(10);
  const [seed, setSeed] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [genLoading, setGenLoading] = useState(false);

  const handleInfer = async () => {
    setError(null);
    setInferredFields(null);
    onInferred(null);
    let records: Record<string, unknown>[];
    try {
      records = JSON.parse(sampleInput);
      if (!Array.isArray(records)) {
        setError('Input must be a JSON array of records');
        return;
      }
    } catch {
      setError('Invalid JSON. Please enter a valid JSON array.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.infer.run({
        records,
        name: schemaName || undefined,
      });
      setInferredFields(res.fields);
      if (!schemaName) setSchemaName(res.name);
      onInferred(res.fields);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Inference failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateFromInferred = async () => {
    if (!inferredFields?.length) return;
    const { fields, omittedCount } = inferredFieldsToGenerateFields(inferredFields);
    if (fields.length === 0) {
      setError(
        'No generatable fields: inferred schema has only object/array fields, which require nested structure. Use sample data with flat fields (string, int, float, bool, etc.).',
      );
      return;
    }
    setError(null);
    setGenLoading(true);
    try {
      const res = await api.generate.run({
        name: schemaName || 'inferred_schema',
        fields,
        count,
        seed: seed ? Number(seed) : undefined,
      });
      onGenerateResult(res.records, res.count, res.duration_ms);
      if (omittedCount > 0) {
        setError(null);
      }
    } catch (err) {
      let msg = 'Generation failed';
      if (err instanceof ApiError) {
        const d = err.response?.detail;
        msg =
          typeof d === 'object' && d !== null && 'message' in d
            ? String((d as { message: unknown }).message)
            : typeof d === 'string'
              ? d
              : err.message;
      } else if (err instanceof Error) {
        msg = err.message;
      }
      setError(msg);
    } finally {
      setGenLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Infer from data</CardTitle>
        <CardDescription>
          Paste sample records as a JSON array to infer the schema, then generate data
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Schema name (optional)</Label>
          <Input
            value={schemaName}
            onChange={(e) => setSchemaName(e.target.value)}
            placeholder="inferred_schema"
          />
        </div>
        <div className="space-y-2">
          <Label>Sample data (JSON array)</Label>
          <Textarea
            value={sampleInput}
            onChange={(e) => setSampleInput(e.target.value)}
            placeholder={'[\n  { "id": 1, "name": "Alice", "score": 95.5 },\n  { "id": 2, "name": "Bob", "score": 87.3 }\n]'}
            className="font-mono text-sm min-h-[200px]"
          />
        </div>
        <Button
          onClick={handleInfer}
          disabled={loading || !sampleInput.trim()}
        >
          {loading ? 'Inferring...' : 'Infer schema'}
        </Button>

        {inferredFields && inferredFields.length > 0 && (
          <>
            <div className="border-t pt-4 space-y-2">
              <Label>Generate from inferred schema</Label>
              {inferredFields.some((f) =>
                TYPES_REQUIRING_CHILDREN.includes(f.type.toLowerCase()),
              ) && (
                <p className="text-xs text-muted-foreground">
                  Object/array fields are omitted when generating (infer does not
                  return nested structure).
                </p>
              )}
              <div className="flex gap-4">
                <div className="space-y-1 flex-1">
                  <Label className="text-xs">Count</Label>
                  <Input
                    type="number"
                    min={1}
                    max={100000}
                    value={count}
                    onChange={(e) => setCount(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-1 flex-1">
                  <Label className="text-xs">Seed (optional)</Label>
                  <Input
                    value={seed}
                    onChange={(e) => setSeed(e.target.value)}
                    placeholder="e.g. 42"
                  />
                </div>
              </div>
              <Button
                onClick={handleGenerateFromInferred}
                disabled={genLoading}
              >
                <Play className="h-4 w-4 mr-2" />
                {genLoading ? 'Generating...' : 'Generate data'}
              </Button>
            </div>
          </>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}

function JsonSchemaTab({
  onParsedFields,
  onGenerateResult,
}: {
  onParsedFields: (fields: GenerateField[] | null) => void;
  onGenerateResult: (
    records: Record<string, unknown>[],
    count: number,
    duration: number,
  ) => void;
}) {
  const [schemaInput, setSchemaInput] = useState('');
  const [schemaName, setSchemaName] = useState('json_schema');
  const [parsedFields, setParsedFields] = useState<GenerateField[] | null>(null);
  const [count, setCount] = useState(10);
  const [seed, setSeed] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [genLoading, setGenLoading] = useState(false);

  const handleParse = () => {
    setError(null);
    setParsedFields(null);
    onParsedFields(null);
    let schema: Record<string, unknown>;
    try {
      schema = JSON.parse(schemaInput);
      if (!schema || typeof schema !== 'object') {
        setError('Invalid JSON. Root must be an object.');
        return;
      }
    } catch {
      setError('Invalid JSON. Please enter a valid JSON Schema.');
      return;
    }
    const fields = parseJsonSchemaToFields(schema);
    if (fields.length === 0) {
      setError('No "properties" found in the JSON Schema.');
      return;
    }
    setParsedFields(fields);
    onParsedFields(fields);
  };

  const handleGenerate = async () => {
    if (!parsedFields?.length) return;
    setError(null);
    setGenLoading(true);
    try {
      const res = await api.generate.run({
        name: schemaName || 'json_schema',
        fields: parsedFields,
        count,
        seed: seed ? Number(seed) : undefined,
      });
      onGenerateResult(res.records, res.count, res.duration_ms);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Generation failed');
    } finally {
      setGenLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">From JSON Schema</CardTitle>
        <CardDescription>
          Paste a JSON Schema (with a &quot;properties&quot; object) to parse
          and generate synthetic data
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>JSON Schema</Label>
          <Textarea
            value={schemaInput}
            onChange={(e) => setSchemaInput(e.target.value)}
            placeholder={'{\n  "type": "object",\n  "properties": {\n    "id": { "type": "integer" },\n    "name": { "type": "string" },\n    "active": { "type": "boolean" }\n  }\n}'}
            className="font-mono text-sm min-h-[200px]"
          />
        </div>
        <Button onClick={handleParse} disabled={!schemaInput.trim()}>
          Parse schema
        </Button>

        {parsedFields && parsedFields.length > 0 && (
          <>
            <div className="border-t pt-4 space-y-2">
              <Label>Generate from parsed schema</Label>
              <div className="flex gap-4">
                <div className="space-y-1 flex-1">
                  <Label className="text-xs">Schema name</Label>
                  <Input
                    value={schemaName}
                    onChange={(e) => setSchemaName(e.target.value)}
                    placeholder="json_schema"
                  />
                </div>
                <div className="space-y-1 flex-1">
                  <Label className="text-xs">Count</Label>
                  <Input
                    type="number"
                    min={1}
                    max={100000}
                    value={count}
                    onChange={(e) => setCount(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-1 flex-1">
                  <Label className="text-xs">Seed (optional)</Label>
                  <Input
                    value={seed}
                    onChange={(e) => setSeed(e.target.value)}
                    placeholder="e.g. 42"
                  />
                </div>
              </div>
              <Button onClick={handleGenerate} disabled={genLoading}>
                <Play className="h-4 w-4 mr-2" />
                {genLoading ? 'Generating...' : 'Generate data'}
              </Button>
            </div>
          </>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}

function BuildSchemaTab({
  onResult,
}: {
  onResult: (records: Record<string, unknown>[] | null, duration: number) => void;
}) {
  const [schemaName, setSchemaName] = useState('generated_data');
  const [fields, setFields] = useState<FieldRow[]>([newField()]);
  const [count, setCount] = useState(10);
  const [seed, setSeed] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const addField = () => setFields([...fields, newField()]);
  const removeField = (id: number) => {
    if (fields.length > 1) setFields(fields.filter((f) => f.id !== id));
  };
  const updateField = (id: number, patch: Partial<FieldRow>) => {
    setFields(fields.map((f) => (f.id === id ? { ...f, ...patch } : f)));
  };

  const buildFields = (): GenerateField[] => {
    return fields
      .filter((f) => f.name.trim())
      .map((f) => {
        const field: GenerateField = {
          name: f.name.trim(),
          type: f.type,
          nullable: f.nullable,
        };
        const constraints: Record<string, unknown> = {};
        if (f.constraintMin) constraints.min = Number(f.constraintMin);
        if (f.constraintMax) constraints.max = Number(f.constraintMax);
        if (f.constraintChoices) {
          constraints.choices = f.constraintChoices
            .split(',')
            .map((c) => c.trim())
            .filter(Boolean);
        }
        if (f.constraintPattern) constraints.pattern = f.constraintPattern;
        if (Object.keys(constraints).length > 0) field.constraints = constraints;
        return field;
      });
  };

  const handleGenerate = async () => {
    setError(null);
    const builtFields = buildFields();
    if (builtFields.length === 0) {
      setError('Add at least one field with a name');
      return;
    }
    setLoading(true);
    try {
      const res = await api.generate.run({
        name: schemaName || 'generated_data',
        fields: builtFields,
        count,
        seed: seed ? Number(seed) : undefined,
      });
      onResult(res.records, res.duration_ms);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Generation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Build schema</CardTitle>
        <CardDescription>
          Define fields and constraints, then generate data
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Schema name</Label>
            <Input
              value={schemaName}
              onChange={(e) => setSchemaName(e.target.value)}
              placeholder="my_schema"
            />
          </div>
          <div className="space-y-2">
            <Label>Record count</Label>
            <Input
              type="number"
              min={1}
              max={100000}
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Seed (optional)</Label>
          <Input
            type="number"
            value={seed}
            onChange={(e) => setSeed(e.target.value)}
            placeholder="Reproducibility"
          />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>Fields</Label>
            <Button variant="outline" size="sm" onClick={addField}>
              <Plus className="h-4 w-4 mr-1" /> Add field
            </Button>
          </div>
          <div className="space-y-3">
            {fields.map((field) => (
              <div key={field.id} className="border rounded-md p-3 space-y-2">
                <div className="flex gap-2 items-end">
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs">Name</Label>
                    <Input
                      value={field.name}
                      onChange={(e) => updateField(field.id, { name: e.target.value })}
                      placeholder="field_name"
                    />
                  </div>
                  <div className="w-32 space-y-1">
                    <Label className="text-xs">Type</Label>
                    <select
                      value={field.type}
                      onChange={(e) => updateField(field.id, { type: e.target.value })}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      {FIELD_TYPES.map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-2 pb-1">
                    <Switch
                      checked={field.nullable}
                      onCheckedChange={(checked) =>
                        updateField(field.id, { nullable: checked })
                      }
                    />
                    <span className="text-xs text-muted-foreground">Null</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeField(field.id)}
                    disabled={fields.length <= 1}
                    className="shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {(field.type === 'int' || field.type === 'float') && (
                  <div className="flex gap-2">
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Min</Label>
                      <Input
                        type="number"
                        value={field.constraintMin}
                        onChange={(e) =>
                          updateField(field.id, { constraintMin: e.target.value })
                        }
                        placeholder="min"
                      />
                    </div>
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Max</Label>
                      <Input
                        type="number"
                        value={field.constraintMax}
                        onChange={(e) =>
                          updateField(field.id, { constraintMax: e.target.value })
                        }
                        placeholder="max"
                      />
                    </div>
                  </div>
                )}
                {field.type === 'enum' && (
                  <div className="space-y-1">
                    <Label className="text-xs">Choices (comma-separated)</Label>
                    <Input
                      value={field.constraintChoices}
                      onChange={(e) =>
                        updateField(field.id, { constraintChoices: e.target.value })
                      }
                      placeholder="a, b, c"
                    />
                  </div>
                )}
                {field.type === 'string' && (
                  <div className="space-y-1">
                    <Label className="text-xs">Pattern (regex, optional)</Label>
                    <Input
                      value={field.constraintPattern}
                      onChange={(e) =>
                        updateField(field.id, { constraintPattern: e.target.value })
                      }
                      placeholder="[A-Z]+"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <Button onClick={handleGenerate} disabled={loading} className="w-full">
          <Play className="h-4 w-4 mr-2" />
          {loading ? 'Generating...' : 'Generate data'}
        </Button>
      </CardContent>
    </Card>
  );
}

function RecipeTab({
  onResult,
}: {
  onResult: (
    records: Record<string, unknown>[],
    count: number,
    sink: string,
    duration: number,
  ) => void;
}) {
  const [yamlInput, setYamlInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleRun = async () => {
    setError(null);
    if (!yamlInput.trim()) {
      setError('Enter a recipe YAML or select a template');
      return;
    }
    setLoading(true);
    try {
      const jsYaml = await import('js-yaml');
      const parsed = jsYaml.load(yamlInput) as Record<string, unknown>;
      if (!parsed || typeof parsed !== 'object') {
        setError('Invalid YAML format');
        return;
      }
      const res = await api.recipes.run(
        parsed as unknown as Parameters<typeof api.recipes.run>[0],
      );
      onResult(res.records, res.count, res.sink_type, res.duration_ms);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Recipe execution failed');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recipe (YAML)</CardTitle>
        <CardDescription>
          Write or select a YAML recipe to run a full pipeline
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Templates</Label>
          <div className="flex flex-wrap gap-2">
            {Object.keys(BUILT_IN_TEMPLATES).map((name) => (
              <Button
                key={name}
                variant="outline"
                size="sm"
                onClick={() => setYamlInput(BUILT_IN_TEMPLATES[name])}
              >
                <BookOpen className="h-3 w-3 mr-1" />
                {name}
              </Button>
            ))}
          </div>
        </div>
        <div className="space-y-2">
          <Label>Recipe YAML</Label>
          <Textarea
            value={yamlInput}
            onChange={(e) => setYamlInput(e.target.value)}
            placeholder="Paste recipe YAML or select a template..."
            className="font-mono text-sm min-h-[400px]"
          />
        </div>
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <Button onClick={handleRun} disabled={loading} className="w-full">
          <Play className="h-4 w-4 mr-2" />
          {loading ? 'Running...' : 'Run recipe'}
        </Button>
      </CardContent>
    </Card>
  );
}
