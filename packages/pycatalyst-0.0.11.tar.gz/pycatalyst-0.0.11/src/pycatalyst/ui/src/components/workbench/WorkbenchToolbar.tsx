'use client';

import { Button } from '@/components/ui/button';
import {
  Terminal as TerminalIcon,
  Code2,
  Braces,
  RefreshCw,
  SplitSquareHorizontal,
  SplitSquareVertical,
  Trash2,
  Server,
  Database,
  Loader2,
  Plus,
  X,
  Package,
  Send,
} from 'lucide-react';
import type { WorkbenchCapabilities, EnvironmentInfo } from '@/lib/workbench';
import type { PanelType } from '@/components/workbench/TerminalPanel';

export type SplitDirection = 'horizontal' | 'vertical';

interface WorkbenchToolbarProps {
  capabilities: WorkbenchCapabilities;
  environments: EnvironmentInfo[];
  activeEnvId: string | null;
  panelCount: number;
  hasPythonSessions: boolean;
  splitDirection: SplitDirection;
  envLoading: boolean;

  onAddPanel: (command: string, panelType: PanelType) => void;
  onSplitDirectionChange: (dir: SplitDirection) => void;
  onRefreshEnv: () => void;
  onClearAll: () => void;
  onLaunchContainer: () => void;
  onLaunchDatabase: () => void;
  onTogglePackages: () => void;
  onSendData: () => void;
  onSwitchEnv: (envId: string) => void;
  onCreateEnv: () => void;
  onDeleteEnv: (envId: string) => void;
  envCreating: boolean;
}

export function WorkbenchToolbar({
  capabilities,
  environments,
  activeEnvId,
  panelCount,
  hasPythonSessions,
  splitDirection,
  envLoading,
  onAddPanel,
  onSplitDirectionChange,
  onRefreshEnv,
  onClearAll,
  onLaunchContainer,
  onLaunchDatabase,
  onTogglePackages,
  onSendData,
  onSwitchEnv,
  onCreateEnv,
  onDeleteEnv,
  envCreating,
}: WorkbenchToolbarProps) {
  const disabled = envLoading || !activeEnvId;

  return (
    <div className="flex items-center gap-2 px-4 py-2 border-b bg-background shrink-0">
      <div className="flex items-center gap-1.5">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onAddPanel('bash', 'venv')}
          disabled={disabled}
          title="New Shell (Ctrl+Shift+`)"
        >
          <TerminalIcon className="h-4 w-4 mr-1.5" />
          Shell
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onAddPanel('python', 'venv')}
          disabled={disabled}
          title="New Python REPL (Ctrl+Shift+P)"
        >
          <Code2 className="h-4 w-4 mr-1.5" />
          Python
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onAddPanel('ipython', 'venv')}
          disabled={disabled}
          title="New IPython session (Ctrl+Shift+I)"
        >
          <Braces className="h-4 w-4 mr-1.5" />
          IPython
        </Button>
      </div>

      <div className="h-5 w-px bg-border mx-1" />

      <Button
        variant="outline"
        size="sm"
        onClick={onLaunchContainer}
        disabled={disabled || !capabilities.docker}
        title={
          capabilities.docker
            ? 'Launch a Docker container'
            : 'Docker not available on this system'
        }
      >
        <Server className="h-4 w-4 mr-1.5" />
        Server
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onLaunchDatabase}
        disabled={disabled || !capabilities.services}
        title={
          capabilities.services
            ? 'Launch a database service (Postgres / MongoDB)'
            : 'Database services not available (Docker required)'
        }
      >
        <Database className="h-4 w-4 mr-1.5" />
        Database
      </Button>

      <div className="h-5 w-px bg-border mx-1" />

      <Button
        variant="outline"
        size="sm"
        onClick={onTogglePackages}
        disabled={disabled}
        title="Manage packages"
      >
        <Package className="h-4 w-4 mr-1.5" />
        Packages
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onSendData}
        disabled={disabled}
        title="Generate and send test data"
      >
        <Send className="h-4 w-4 mr-1.5" />
        Send Data
      </Button>

      <div className="h-5 w-px bg-border mx-1" />

      <div className="flex items-center gap-1.5">
        <Button
          variant={splitDirection === 'horizontal' ? 'secondary' : 'ghost'}
          size="sm"
          onClick={() => onSplitDirectionChange('horizontal')}
          title="Split horizontally (Ctrl+Shift+H)"
        >
          <SplitSquareHorizontal className="h-4 w-4" />
        </Button>
        <Button
          variant={splitDirection === 'vertical' ? 'secondary' : 'ghost'}
          size="sm"
          onClick={() => onSplitDirectionChange('vertical')}
          title="Split vertically (Ctrl+Shift+V)"
        >
          <SplitSquareVertical className="h-4 w-4" />
        </Button>
      </div>

      <div className="h-5 w-px bg-border mx-1" />

      <Button
        variant="ghost"
        size="sm"
        onClick={onRefreshEnv}
        disabled={!hasPythonSessions}
        title="Refresh environment (Ctrl+Shift+R)"
      >
        <RefreshCw className="h-4 w-4 mr-1.5" />
        Refresh Env
      </Button>

      <div className="flex-1" />

      <div className="flex items-center gap-1.5 mr-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onCreateEnv}
          disabled={envCreating || envLoading}
          title="New Environment (Ctrl+Shift+E)"
        >
          {envCreating ? (
            <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
          ) : (
            <Plus className="h-4 w-4 mr-1.5" />
          )}
          New Env
        </Button>

        {activeEnvId && (
          <select
            className="text-xs bg-muted/60 border border-border rounded px-2 py-0.5 text-muted-foreground font-mono"
            value={activeEnvId}
            onChange={(e) => onSwitchEnv(e.target.value)}
          >
            {environments.map((env) => (
              <option key={env.env_id} value={env.env_id}>
                {env.env_id.slice(0, 8)} ({env.backend}, {env.session_count} sessions)
              </option>
            ))}
          </select>
        )}

        {environments.length > 1 && activeEnvId && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDeleteEnv(activeEnvId)}
            title="Delete selected environment"
            className="text-muted-foreground hover:text-destructive h-7 w-7 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      <span className="text-xs text-muted-foreground mr-2">
        {panelCount} {panelCount === 1 ? 'panel' : 'panels'}
      </span>

      {(capabilities.session_idle_timeout_seconds ?? 0) > 0 && (
        <span
          className="text-xs text-muted-foreground mr-2"
          title="Inactive sessions are closed automatically"
        >
          Sessions close after{' '}
          {Math.round((capabilities.session_idle_timeout_seconds ?? 0) / 60)} min
          idle
        </span>
      )}

      <Button
        variant="ghost"
        size="sm"
        onClick={onClearAll}
        title="Close all and reset"
        className="text-muted-foreground hover:text-destructive"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}
