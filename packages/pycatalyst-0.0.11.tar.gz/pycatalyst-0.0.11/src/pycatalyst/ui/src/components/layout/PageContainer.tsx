'use client';

import { cn } from '@/lib/utils';

interface PageContainerProps {
  children: React.ReactNode;
  fullHeight?: boolean;
  className?: string;
}

export function PageContainer({ children, fullHeight = false, className }: PageContainerProps) {
  if (fullHeight) {
    return <div className={cn('flex h-[calc(100vh-4rem)] overflow-hidden', className)}>{children}</div>;
  }
  return (
    <div className={cn('min-h-screen bg-background', className)}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">{children}</div>
    </div>
  );
}
