'use client';

import { useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useAuthStore, selectUser, selectLoading, selectAuthDisabled, selectApiUnavailable } from '@/stores/auth';
import { ROUTES } from '@/lib/constants';
import { LoadingSpinner } from '@/components/common/LoadingSpinner';

function isPublicPath(pathname: string | null): boolean {
  if (!pathname) return false;
  const normalized = pathname.replace(/\/+$/, '') || '/';
  return normalized === ROUTES.LOGIN || normalized === ROUTES.SETTINGS;
}

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const user = useAuthStore(selectUser);
  const loading = useAuthStore(selectLoading);
  const authDisabled = useAuthStore(selectAuthDisabled);
  const apiUnavailable = useAuthStore(selectApiUnavailable);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (isPublicPath(pathname)) return;
    if (apiUnavailable || authDisabled || user) return;
    sessionStorage.setItem('pycatalyst_return_url', pathname || ROUTES.HOME);
    router.replace(ROUTES.LOGIN);
  }, [loading, pathname, user, authDisabled, apiUnavailable, router]);

  if (isPublicPath(pathname)) return <>{children}</>;
  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><LoadingSpinner /></div>;
  if (apiUnavailable || authDisabled || user) return <>{children}</>;
  return null;
}
