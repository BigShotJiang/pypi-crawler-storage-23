'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X, Send, Loader2 } from 'lucide-react';
import { listRecipeTemplates, runRecipe, type RecipeTemplate } from '@/lib/workbench';

interface SendDataDialogProps {
  open: boolean;
  onClose: () => void;
}

export function SendDataDialog({ open, onClose }: SendDataDialogProps) {
  const [templates, setTemplates] = useState<RecipeTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [targetUrl, setTargetUrl] = useState('http://localhost:8000/api/v1/events');
  const [method, setMethod] = useState<string>('POST');
  const [recordCount, setRecordCount] = useState(100);
  const [batchSize, setBatchSize] = useState(50);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string>('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      listRecipeTemplates()
        .then(setTemplates)
        .catch(() => {});
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTemplate) return;

    setLoading(true);
    setResult('');
    setError('');

    const recipe = {
      name: `workbench_send_${selectedTemplate}`,
      template: selectedTemplate,
      generation: { count: recordCount },
      sink: {
        type: 'http',
        config: {
          url: targetUrl.trim(),
          method: method,
          batch_size: batchSize,
        },
      },
    };

    try {
      const res = await runRecipe(recipe);
      setResult(
        `Sent ${res.records_generated} records to ${targetUrl}` +
          (res.errors?.length ? `\nErrors: ${res.errors.join(', ')}` : ''),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setResult('');
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={handleClose} />
      <div className="relative bg-background border rounded-lg shadow-xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Send Test Data</h2>
          <button
            type="button"
            onClick={handleClose}
            className="p-1 rounded hover:bg-muted text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="recipe-select">Recipe Template</Label>
            <select
              id="recipe-select"
              className="w-full text-sm bg-muted/60 border border-border rounded px-3 py-1.5"
              value={selectedTemplate}
              onChange={(e) => setSelectedTemplate(e.target.value)}
            >
              <option value="">Select a template...</option>
              {templates.map((t) => (
                <option key={t.name} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="target-url">Target URL</Label>
            <Input
              id="target-url"
              value={targetUrl}
              onChange={(e) => setTargetUrl(e.target.value)}
              placeholder="http://localhost:8000/api/v1/events"
              className="font-mono text-sm"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-2">
              <Label htmlFor="method">Method</Label>
              <select
                id="method"
                className="w-full text-sm bg-muted/60 border border-border rounded px-2 py-1.5"
                value={method}
                onChange={(e) => setMethod(e.target.value)}
              >
                <option value="POST">POST</option>
                <option value="PUT">PUT</option>
                <option value="PATCH">PATCH</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="count">Count</Label>
              <Input
                id="count"
                type="number"
                min={1}
                max={10000}
                value={recordCount}
                onChange={(e) => setRecordCount(parseInt(e.target.value) || 100)}
                className="text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="batch">Batch</Label>
              <Input
                id="batch"
                type="number"
                min={1}
                max={1000}
                value={batchSize}
                onChange={(e) => setBatchSize(parseInt(e.target.value) || 50)}
                className="text-sm"
              />
            </div>
          </div>

          {result && (
            <pre className="bg-muted rounded p-3 text-xs font-mono whitespace-pre-wrap">
              {result}
            </pre>
          )}

          {error && <p className="text-sm text-destructive">{error}</p>}

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={handleClose}>
              Close
            </Button>
            <Button
              type="submit"
              size="sm"
              disabled={loading || !selectedTemplate || !targetUrl.trim()}
            >
              {loading ? (
                <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
              ) : (
                <Send className="h-4 w-4 mr-1.5" />
              )}
              {loading ? 'Sending...' : 'Send Data'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
