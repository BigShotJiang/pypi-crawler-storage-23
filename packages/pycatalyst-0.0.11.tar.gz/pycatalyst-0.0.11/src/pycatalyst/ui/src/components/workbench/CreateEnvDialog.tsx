'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { X, Plus, Loader2 } from 'lucide-react';
import {
  listProfiles,
  type WorkbenchCapabilities,
  type EnvironmentProfile,
} from '@/lib/workbench';

interface CreateEnvDialogProps {
  open: boolean;
  capabilities: WorkbenchCapabilities;
  onClose: () => void;
  onCreate: (backend: string, profile?: string) => void;
  loading?: boolean;
}

export function CreateEnvDialog({
  open,
  capabilities,
  onClose,
  onCreate,
  loading,
}: CreateEnvDialogProps) {
  const [backend, setBackend] = useState<string>('venv');
  const [selectedProfile, setSelectedProfile] = useState<string>('');
  const [profiles, setProfiles] = useState<EnvironmentProfile[]>([]);

  useEffect(() => {
    if (open) {
      listProfiles()
        .then(setProfiles)
        .catch(() => {});
    }
  }, [open]);

  if (!open) return null;

  const activeProfile = profiles.find((p) => p.name === selectedProfile);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreate(backend, selectedProfile || undefined);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-background border rounded-lg shadow-xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">New Environment</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded hover:bg-muted text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Backend</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={backend === 'venv' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setBackend('venv')}
                className="flex-1"
              >
                Venv
              </Button>
              <Button
                type="button"
                variant={backend === 'docker' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setBackend('docker')}
                disabled={!capabilities.docker}
                className="flex-1"
              >
                Docker
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="profile-select">Setup Profile</Label>
            <select
              id="profile-select"
              className="w-full text-sm bg-muted/60 border border-border rounded px-3 py-1.5"
              value={selectedProfile}
              onChange={(e) => setSelectedProfile(e.target.value)}
            >
              <option value="">None (blank environment)</option>
              {profiles
                .filter((p) => p.backend === backend || !p.backend)
                .map((p) => (
                  <option key={p.name} value={p.name}>
                    {p.name}
                  </option>
                ))}
            </select>
          </div>

          {activeProfile && (
            <div className="bg-muted/50 rounded p-3 space-y-1">
              <p className="text-xs text-muted-foreground">
                {activeProfile.description}
              </p>
              {activeProfile.packages.length > 0 && (
                <p className="text-xs">
                  <span className="text-muted-foreground">Packages: </span>
                  <code className="bg-muted px-1 rounded">
                    {activeProfile.packages.join(', ')}
                  </code>
                </p>
              )}
              {activeProfile.editable_packages.length > 0 && (
                <p className="text-xs">
                  <span className="text-muted-foreground">Editable: </span>
                  <code className="bg-muted px-1 rounded">
                    {activeProfile.editable_packages.join(', ')}
                  </code>
                </p>
              )}
            </div>
          )}

          {selectedProfile && (
            <p className="text-xs text-muted-foreground">
              The selected profile&apos;s packages will be installed
              automatically after the environment is created.
            </p>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" size="sm" disabled={loading}>
              {loading ? (
                <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
              ) : (
                <Plus className="h-4 w-4 mr-1.5" />
              )}
              {loading ? 'Creating...' : 'Create'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
