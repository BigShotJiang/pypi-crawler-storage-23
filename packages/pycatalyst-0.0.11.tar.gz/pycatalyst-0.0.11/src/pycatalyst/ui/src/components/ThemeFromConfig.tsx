'use client';

import { useEffect } from 'react';
import { getApiBaseUrl } from '@/lib/settings';
import { useAppConfigStore, selectSetAppConfig } from '@/stores/app-config';
import { THEME_STORAGE_KEY } from '@/lib/constants';

function persistTheme(theme: string) {
  try { localStorage.setItem(THEME_STORAGE_KEY, theme); } catch (_) {}
}

export default function ThemeFromConfig() {
  const setAppConfig = useAppConfigStore(selectSetAppConfig);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (window.__APP_CONFIG__) {
      const theme = window.__APP_CONFIG__.theme ?? 'light';
      setAppConfig({
        appName: window.__APP_CONFIG__.appName,
        theme,
        version: window.__APP_CONFIG__.version,
      });
      persistTheme(theme);
      return;
    }
    const base = getApiBaseUrl();
    const url = base ? `${base.replace(/\/$/, '')}/api/v1/settings/app-config` : '/api/v1/settings/app-config';
    fetch(url)
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { theme?: string; app_name?: string; version?: string } | null) => {
        if (!data) return;
        const theme = data.theme ?? 'light';
        const appName = data.app_name ?? window.__APP_CONFIG__?.appName;
        const version = data.version ?? window.__APP_CONFIG__?.version ?? '';
        setAppConfig({ appName, theme, version });
        persistTheme(theme);
      })
      .catch(() => {});
  }, [setAppConfig]);
  return null;
}
