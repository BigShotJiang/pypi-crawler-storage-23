/** Typed API client for PyCatalyst. */

import { getApiBaseUrl } from '@/lib/settings';
import { getAccessToken, clearAccessToken } from '@/lib/auth-storage';
import { AUTH_SESSION_EXPIRED_EVENT } from '@/lib/constants';
import type {
  AuthMeResponse,
  AuthLoginResponse,
  GenerateRequest,
  GenerateResponse,
  InferRequest,
  InferResponse,
  MlRunRequest,
  MlRunResponse,
  RecipeRunRequest,
  RecipeRunResponse,
} from '@/lib/types';

export type { AuthMeResponse };

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

function authHeaders(): Record<string, string> {
  const token = getAccessToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (response.status === 401) {
    clearAccessToken();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT));
    }
  }
  if (response.status === 204) return undefined as T;
  const text = await response.text();
  let data: T | undefined;
  try {
    data = JSON.parse(text) as T;
  } catch {}
  if (!response.ok) {
    const msg = (data as Record<string, unknown>)?.detail ?? text ?? `HTTP ${response.status}`;
    throw new ApiError(String(msg), response.status, data as Record<string, unknown>);
  }
  return data as T;
}

function wrapNetworkError(err: unknown): never {
  if (err instanceof ApiError) throw err;
  const apiUrl = getApiBaseUrl() || window.location.origin;
  if (err instanceof TypeError && err.message === 'Failed to fetch') {
    throw new ApiError(
      `Unable to connect to API server at ${apiUrl}. Please ensure the API server is running (pycatalyst api).`,
      0,
      { originalError: 'NetworkError', apiUrl, suggestion: 'Check Settings' },
    );
  }
  throw new ApiError(String(err), 0);
}

async function get<T>(endpoint: string): Promise<T> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, { headers: authHeaders() });
    return handleResponse<T>(res);
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function post<T>(endpoint: string, body?: unknown): Promise<T> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, {
      method: 'POST',
      headers: authHeaders(),
      body: body != null ? JSON.stringify(body) : undefined,
    });
    return handleResponse<T>(res);
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function fetchWithTimeout<T>(
  endpoint: string,
  timeoutMs: number,
  init?: RequestInit,
): Promise<T> {
  const base = getApiBaseUrl();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}${endpoint}`, {
      ...init,
      headers: { ...authHeaders(), ...(init?.headers ?? {}) },
      signal: controller.signal,
    });
    return handleResponse<T>(res);
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new ApiError(`Request timed out after ${timeoutMs}ms`, 0);
    }
    return wrapNetworkError(err);
  } finally {
    clearTimeout(timer);
  }
}

export async function loginWithTimeout(
  username: string,
  password: string,
  timeoutMs: number,
): Promise<AuthLoginResponse> {
  return fetchWithTimeout<AuthLoginResponse>(
    '/api/v1/auth/login',
    timeoutMs,
    {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    },
  );
}

export const api = {
  auth: {
    login: (username: string, password: string) =>
      post<AuthLoginResponse>('/api/v1/auth/login', { username, password }),
    logout: () => post<void>('/api/v1/auth/logout'),
    me: () => get<AuthMeResponse>('/api/v1/auth/me'),
    meWithTimeout: (timeoutMs: number) =>
      fetchWithTimeout<AuthMeResponse>('/api/v1/auth/me', timeoutMs),
  },
  generate: {
    run: (params: GenerateRequest) =>
      post<GenerateResponse>('/api/v1/generate', params),
  },
  infer: {
    run: (params: InferRequest) =>
      post<InferResponse>('/api/v1/infer', params),
  },
  recipes: {
    run: (params: RecipeRunRequest) =>
      post<RecipeRunResponse>('/api/v1/recipes/run', params),
  },
  ml: {
    runExperiment: (params: MlRunRequest) =>
      post<MlRunResponse>('/api/v1/ml/run', params),
  },
};
