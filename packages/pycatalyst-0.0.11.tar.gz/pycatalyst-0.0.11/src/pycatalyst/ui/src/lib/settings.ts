/** API base URL resolution. */

const SETTINGS_KEY = 'pycatalyst_settings';

export interface AppSettings {
  apiServer: {
    url: string;
  };
}

const DEFAULT_SETTINGS: AppSettings = {
  apiServer: {
    url: '',
  },
};

export function loadSettings(): AppSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {}
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: AppSettings): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function getApiBaseUrl(): string {
  // 1. Environment variable (set during build or dev)
  if (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_API_URL) {
    return process.env.NEXT_PUBLIC_API_URL.replace(/\/+$/, '');
  }
  // 2. User setting from localStorage
  const settings = loadSettings();
  if (settings.apiServer.url) {
    return settings.apiServer.url.replace(/\/+$/, '');
  }
  // 3. Same origin (UI server proxies API)
  if (typeof window !== 'undefined') {
    return '';
  }
  return 'http://localhost:8006';
}
