/** TypeScript type definitions for PyCatalyst API. */

// Auth
export interface AuthMeResponse {
  username: string;
  auth_disabled: boolean;
}

export interface AuthLoginResponse {
  access_token: string;
}

// Generate
export interface GenerateField {
  name: string;
  type: string;
  nullable?: boolean;
  constraints?: Record<string, unknown>;
  children?: GenerateField[];
}

export interface GenerateRequest {
  name: string;
  fields: GenerateField[];
  count: number;
  seed?: number;
}

export interface GenerateResponse {
  records: Record<string, unknown>[];
  count: number;
  schema_name: string;
  duration_ms: number;
  seed?: number;
}

// Infer
export interface InferRequest {
  records: Record<string, unknown>[];
  name?: string;
}

export interface InferField {
  name: string;
  type: string;
  nullable: boolean;
  constraints?: Record<string, unknown>;
}

export interface InferResponse {
  name: string;
  fields: InferField[];
  field_count: number;
}

// Recipes
export interface RecipeRunRequest {
  name: string;
  description?: string;
  schema: Record<string, unknown>;
  generation?: Record<string, unknown>;
  sink?: Record<string, unknown>;
}

export interface RecipeRunResponse {
  records: Record<string, unknown>[];
  count: number;
  records_sent: number;
  sink_type: string;
  duration_ms: number;
}

// ML / Model Training
export interface MlRunRequest {
  config: string;
}

export interface MlRunResponse {
  name: string;
  backend: string;
  metrics: Record<string, number>;
  artifacts: Record<string, string>;
  training_history: Record<string, unknown>[];
  duration_seconds: number;
}
