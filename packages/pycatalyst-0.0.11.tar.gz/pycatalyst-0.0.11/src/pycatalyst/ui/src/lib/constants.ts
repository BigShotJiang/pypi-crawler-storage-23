/** Central application constants. */

export const APP_NAME = 'PyCatalyst';
export const APP_DESCRIPTION = 'Data Generation and Testing Platform';

/** Theme storage key in localStorage. */
export const THEME_STORAGE_KEY = 'pycatalyst-theme';

/** Named theme IDs that use data-theme attribute. */
export const NAMED_THEME_IDS = [
  'ocean',
  'forest',
  'sunset',
  'high-contrast',
  'sepia',
  'violet',
  'cathay',
] as const;

export type NamedThemeId = (typeof NAMED_THEME_IDS)[number];

/** Application routes. */
export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  GENERATE: '/generate',
  SCHEMAS: '/schemas',
  RECIPES: '/recipes',
  SINKS: '/sinks',
  DOCUMENTATION: '/documentation',
  WORKBENCH: '/workbench',
  MODEL_TRAINING: '/model-training',
  SETTINGS: '/settings',
} as const;

/** Timeout for auth check on initial load (ms). */
export const AUTH_CHECK_TIMEOUT_MS = 4000;

/** Timeout for login request (ms). */
export const LOGIN_REQUEST_TIMEOUT_MS = 10000;

/** Custom event dispatched when server returns 401. */
export const AUTH_SESSION_EXPIRED_EVENT = 'pycatalyst:auth:session-expired';
