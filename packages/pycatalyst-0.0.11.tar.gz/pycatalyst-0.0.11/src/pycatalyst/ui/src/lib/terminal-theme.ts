/** Terminal theme utilities — derives xterm.js ITheme from app CSS variables. */

import type { ITheme } from '@xterm/xterm';

/**
 * Convert an HSL string like "222.2 84% 4.9%" to a hex color.
 * Falls back to the provided default if parsing fails.
 */
function hslToHex(hsl: string, fallback: string): string {
  const parts = hsl.trim().split(/\s+/);
  if (parts.length < 3) return fallback;

  const h = parseFloat(parts[0]) / 360;
  const s = parseFloat(parts[1]) / 100;
  const l = parseFloat(parts[2]) / 100;

  if (isNaN(h) || isNaN(s) || isNaN(l)) return fallback;

  // HSL → RGB conversion
  let r: number, g: number, b: number;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }

  const toHex = (c: number) =>
    Math.round(c * 255)
      .toString(16)
      .padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

/** Read a CSS variable from :root and convert HSL → hex. */
function cssVar(name: string, fallback: string): string {
  if (typeof window === 'undefined') return fallback;
  const raw = getComputedStyle(document.documentElement)
    .getPropertyValue(name)
    .trim();
  if (!raw) return fallback;
  return hslToHex(raw, fallback);
}

/** ANSI color palette for dark backgrounds. */
const DARK_ANSI = {
  black: '#15161e',
  red: '#f7768e',
  green: '#9ece6a',
  yellow: '#e0af68',
  blue: '#7aa2f7',
  magenta: '#bb9af7',
  cyan: '#7dcfff',
  white: '#a9b1d6',
  brightBlack: '#414868',
  brightRed: '#f7768e',
  brightGreen: '#9ece6a',
  brightYellow: '#e0af68',
  brightBlue: '#7aa2f7',
  brightMagenta: '#bb9af7',
  brightCyan: '#7dcfff',
  brightWhite: '#c0caf5',
};

/** ANSI color palette for light backgrounds. */
const LIGHT_ANSI = {
  black: '#343b58',
  red: '#8c4351',
  green: '#485e30',
  yellow: '#8f5e15',
  blue: '#34548a',
  magenta: '#5a4a78',
  cyan: '#0f4b6e',
  white: '#343b58',
  brightBlack: '#9699a3',
  brightRed: '#8c4351',
  brightGreen: '#485e30',
  brightYellow: '#8f5e15',
  brightBlue: '#34548a',
  brightMagenta: '#5a4a78',
  brightCyan: '#0f4b6e',
  brightWhite: '#343b58',
};

/**
 * Build an xterm.js ITheme from the current app CSS variables.
 *
 * Reads `--background`, `--foreground`, `--muted-foreground`, and `--border`
 * from the computed styles and pairs them with an appropriate ANSI palette.
 */
export function buildTerminalTheme(): ITheme {
  const bg = cssVar('--background', '#1a1b26');
  const fg = cssVar('--foreground', '#c0caf5');
  const selection = cssVar('--muted', '#33467c');
  const cursorAccent = bg;

  // Determine if the resolved background is "dark" by checking luminance.
  const isDark = isColorDark(bg);
  const ansi = isDark ? DARK_ANSI : LIGHT_ANSI;

  return {
    background: bg,
    foreground: fg,
    cursor: fg,
    cursorAccent,
    selectionBackground: selection,
    ...ansi,
  };
}

/** Rough luminance check: returns true if the hex color is dark. */
function isColorDark(hex: string): boolean {
  const c = hex.replace('#', '');
  const r = parseInt(c.substring(0, 2), 16);
  const g = parseInt(c.substring(2, 4), 16);
  const b = parseInt(c.substring(4, 6), 16);
  // Relative luminance (simplified)
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance < 0.5;
}
