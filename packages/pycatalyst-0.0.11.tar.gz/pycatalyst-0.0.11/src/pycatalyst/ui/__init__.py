"""PyCatalyst UI — Next.js frontend for data generation and testing."""

from __future__ import annotations
