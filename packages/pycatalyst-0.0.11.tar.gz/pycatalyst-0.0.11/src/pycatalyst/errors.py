"""Exception hierarchy for PyCatalyst.

All PyCatalyst exceptions inherit from CatalystError, making it easy
to catch any data-generation-related error with a single except clause.
"""

from __future__ import annotations

from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    """Machine-readable error codes for programmatic error handling."""

    SCHEMA_INVALID = "schema_invalid"
    GENERATION_FAILED = "generation_failed"
    SINK_ERROR = "sink_error"
    RECIPE_INVALID = "recipe_invalid"
    INFERENCE_FAILED = "inference_failed"
    CONFIG = "config"
    GENERATOR_NOT_FOUND = "generator_not_found"
    CONSTRAINT_VIOLATION = "constraint_violation"
    SERVICE_ERROR = "service_error"
    TRAINING_FAILED = "training_failed"
    MODEL_NOT_FOUND = "model_not_found"
    BACKEND_UNAVAILABLE = "backend_unavailable"


class CatalystError(Exception):
    """Base exception for all PyCatalyst errors.

    Attributes:
        message: Human-readable error description.
        context: Additional context about the error.
        code: Machine-readable error code for programmatic handling.
    """

    def __init__(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        *,
        code: ErrorCode | None = None,
    ) -> None:
        self.message = message
        self.context = context or {}
        self.code = code
        super().__init__(message)

    def __str__(self) -> str:
        if self.context:
            ctx_str = ", ".join(f"{k}={v!r}" for k, v in self.context.items())
            return f"{self.message} ({ctx_str})"
        return self.message

    def to_dict(self) -> dict[str, Any]:
        """Serialize error to dictionary."""
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "code": self.code.value if self.code else None,
            "context": self.context,
        }


class SchemaError(CatalystError):
    """Error in schema definition or validation.

    Attributes:
        field_name: The field that caused the error, if applicable.
    """

    def __init__(
        self,
        message: str,
        field_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if field_name:
            ctx["field_name"] = field_name
        super().__init__(message, ctx)
        self.field_name = field_name
        self.code = ErrorCode.SCHEMA_INVALID


class GenerationError(CatalystError):
    """Error during data generation.

    Attributes:
        field_name: The field that failed to generate.
        schema_name: The schema being generated.
    """

    def __init__(
        self,
        message: str,
        field_name: str | None = None,
        schema_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if field_name:
            ctx["field_name"] = field_name
        if schema_name:
            ctx["schema_name"] = schema_name
        super().__init__(message, ctx)
        self.field_name = field_name
        self.schema_name = schema_name
        self.code = ErrorCode.GENERATION_FAILED


class GeneratorNotFoundError(CatalystError):
    """Generator not registered for a field type.

    Attributes:
        field_type: The field type with no registered generator.
    """

    def __init__(
        self,
        message: str,
        field_type: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx["field_type"] = field_type
        super().__init__(message, ctx)
        self.field_type = field_type
        self.code = ErrorCode.GENERATOR_NOT_FOUND


class SinkError(CatalystError):
    """Error sending data to a sink target.

    Attributes:
        sink_type: The type of sink that failed.
        records_sent: Number of records successfully sent before failure.
    """

    def __init__(
        self,
        message: str,
        sink_type: str | None = None,
        records_sent: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if sink_type:
            ctx["sink_type"] = sink_type
        ctx["records_sent"] = records_sent
        super().__init__(message, ctx)
        self.sink_type = sink_type
        self.records_sent = records_sent
        self.code = ErrorCode.SINK_ERROR


class RecipeError(CatalystError):
    """Error in recipe definition or execution.

    Attributes:
        recipe_name: The recipe that caused the error.
        path: File path of the recipe, if applicable.
    """

    def __init__(
        self,
        message: str,
        recipe_name: str | None = None,
        path: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if recipe_name:
            ctx["recipe_name"] = recipe_name
        if path:
            ctx["path"] = path
        super().__init__(message, ctx)
        self.recipe_name = recipe_name
        self.path = path
        self.code = ErrorCode.RECIPE_INVALID


class InferenceError(CatalystError):
    """Error during schema inference from data.

    Attributes:
        source_type: Type of data source (csv, json, parquet, etc.).
    """

    def __init__(
        self,
        message: str,
        source_type: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if source_type:
            ctx["source_type"] = source_type
        super().__init__(message, ctx)
        self.source_type = source_type
        self.code = ErrorCode.INFERENCE_FAILED


class ConfigError(CatalystError):
    """Error in PyCatalyst configuration.

    Attributes:
        path: Config file path, if applicable.
    """

    def __init__(
        self,
        message: str,
        path: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if path:
            ctx["path"] = path
        super().__init__(message, ctx)
        self.path = path
        self.code = ErrorCode.CONFIG


class ConstraintViolationError(CatalystError):
    """Generated value violated a field constraint.

    Attributes:
        field_name: The field with the violated constraint.
        constraint: Description of the violated constraint.
    """

    def __init__(
        self,
        message: str,
        field_name: str,
        constraint: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx.update({"field_name": field_name, "constraint": constraint})
        super().__init__(message, ctx)
        self.field_name = field_name
        self.constraint = constraint
        self.code = ErrorCode.CONSTRAINT_VIOLATION


class ServiceError(CatalystError):
    """Error in workbench service container lifecycle.

    Attributes:
        service_id: The service that caused the error, if applicable.
        service_type: The type of service (postgres, mongodb).
    """

    def __init__(
        self,
        message: str,
        service_id: str | None = None,
        service_type: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if service_id:
            ctx["service_id"] = service_id
        if service_type:
            ctx["service_type"] = service_type
        super().__init__(message, ctx)
        self.service_id = service_id
        self.service_type = service_type
        self.code = ErrorCode.SERVICE_ERROR


class TrainingError(CatalystError):
    """Error during ML model training.

    Attributes:
        backend: The ML backend that failed (pytorch, sklearn, huggingface).
        experiment_name: Name of the experiment that failed.
    """

    def __init__(
        self,
        message: str,
        backend: str | None = None,
        experiment_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if backend:
            ctx["backend"] = backend
        if experiment_name:
            ctx["experiment_name"] = experiment_name
        super().__init__(message, ctx)
        self.backend = backend
        self.experiment_name = experiment_name
        self.code = ErrorCode.TRAINING_FAILED


class ModelNotFoundError(CatalystError):
    """Trained model not found at expected path.

    Attributes:
        model_path: The path where the model was expected.
    """

    def __init__(
        self,
        message: str,
        model_path: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if model_path:
            ctx["model_path"] = model_path
        super().__init__(message, ctx)
        self.model_path = model_path
        self.code = ErrorCode.MODEL_NOT_FOUND


class BackendUnavailableError(CatalystError):
    """ML backend dependencies not installed.

    Attributes:
        backend: The backend whose deps are missing.
        install_hint: pip install command to fix.
    """

    def __init__(
        self,
        message: str,
        backend: str | None = None,
        install_hint: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if backend:
            ctx["backend"] = backend
        if install_hint:
            ctx["install_hint"] = install_hint
        super().__init__(message, ctx)
        self.backend = backend
        self.install_hint = install_hint
        self.code = ErrorCode.BACKEND_UNAVAILABLE
