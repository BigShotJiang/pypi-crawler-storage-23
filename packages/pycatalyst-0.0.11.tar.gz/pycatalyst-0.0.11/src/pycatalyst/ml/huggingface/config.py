"""Pydantic configuration for HuggingFace LLM fine-tuning experiments."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class ExperimentSection(BaseModel):
    name: str = Field(..., min_length=1)
    seed: int = Field(default=42, ge=0)
    backend: Literal["huggingface"] = "huggingface"
    output_dir: str = Field(default="./runs/experiment")


class DataSection(BaseModel):
    path: str = Field(..., min_length=1)
    format: Literal["instruction", "chat", "completion"] = "instruction"
    max_length: int = Field(default=512, ge=16)
    val_split: float = Field(default=0.1, gt=0, lt=1)


class LoRAParams(BaseModel):
    r: int = Field(default=16, ge=1)
    lora_alpha: int = Field(default=32, ge=1)
    lora_dropout: float = Field(default=0.05, ge=0, le=1)
    target_modules: list[str] = Field(default=["q_proj", "v_proj"])


class ModelSection(BaseModel):
    base_model: str = Field(..., min_length=1)
    adapter: Literal["lora", "qlora", "none"] = "lora"
    params: LoRAParams = Field(default_factory=LoRAParams)
    quantization: Literal["4bit", "8bit"] | None = None

    @model_validator(mode="after")
    def _qlora_needs_quantization(self) -> ModelSection:
        if self.adapter == "qlora" and self.quantization is None:
            self.quantization = "4bit"
        return self


class TrainingSection(BaseModel):
    epochs: int = Field(default=3, ge=1)
    batch_size: int = Field(default=4, ge=1)
    gradient_accumulation_steps: int = Field(default=4, ge=1)
    learning_rate: float = Field(default=2e-4, gt=0)
    warmup_ratio: float = Field(default=0.03, ge=0, le=1)
    mixed_precision: Literal["bf16", "fp16"] | None = "bf16"
    max_grad_norm: float = Field(default=1.0, ge=0)


class EvaluationSection(BaseModel):
    metrics: list[str] = Field(default=["eval_loss", "perplexity"], min_length=1)


class HFExperimentConfig(BaseModel):
    experiment: ExperimentSection
    data: DataSection
    model: ModelSection
    training: TrainingSection = Field(default_factory=TrainingSection)
    evaluation: EvaluationSection = Field(default_factory=EvaluationSection)

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> HFExperimentConfig:
        return cls.model_validate(raw)
