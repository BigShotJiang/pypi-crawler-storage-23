"""Experiment dispatcher — reads YAML, detects backend, calls the right engine.

Public API::

    from pycatalyst.ml import run, load

    config = load("experiment.yaml")   # parse without running
    result = run("experiment.yaml")    # parse + train
    result = run(config_dict)          # dict input also supported
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from pycatalyst.ml.results import ExperimentResult


def load(path: str | Path) -> dict[str, Any]:
    """Load and return an experiment config without running it.

    Useful for inspection, modification, or passing to ``run()``.

    Args:
        path: Path to a YAML or JSON experiment config file.

    Returns:
        Parsed config dictionary.

    Raises:
        FileNotFoundError: If *path* does not exist.
        ValueError: If the file content is not a mapping.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")

    raw = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Expected a YAML mapping, got {type(raw).__name__}")
    return raw


def run(config: str | Path | dict[str, Any]) -> ExperimentResult:
    """Load an experiment config and dispatch to the appropriate engine.

    This is the primary config-driven entry point for pycatalyst ML.

    Args:
        config: Path to a YAML/JSON config file, or a dict.

    Returns:
        ExperimentResult from the engine.

    Raises:
        FileNotFoundError: If a path is given and does not exist.
        ValueError: If the backend is missing or unrecognised.
    """
    if isinstance(config, str | Path):
        raw = load(config)
    else:
        raw = config

    backend = (raw.get("experiment") or {}).get("backend")
    if not backend:
        raise ValueError(
            "Missing 'experiment.backend' in config. "
            "Must be one of: pytorch, sklearn, huggingface"
        )

    backend = backend.strip().lower()

    if backend == "pytorch":
        try:
            from pycatalyst.ml.pytorch import run as pytorch_run  # noqa: WPS433
        except ImportError as exc:
            raise ImportError(
                "PyTorch engine requires torch. "
                "Install with: pip install pycatalyst[ml-core]"
            ) from exc
        return pytorch_run(raw)

    if backend == "sklearn":
        try:
            from pycatalyst.ml.sklearn import run as sklearn_run  # noqa: WPS433
        except ImportError as exc:
            raise ImportError(
                "Sklearn engine requires scikit-learn. "
                "Install with: pip install pycatalyst[ml-sklearn]"
            ) from exc
        return sklearn_run(raw)

    if backend == "huggingface":
        try:
            from pycatalyst.ml.huggingface import run as hf_run  # noqa: WPS433
        except ImportError as exc:
            raise ImportError(
                "HuggingFace engine requires transformers + peft. "
                "Install with: pip install pycatalyst[ml-llm]"
            ) from exc
        return hf_run(raw)

    raise ValueError(
        f"Unknown backend: {backend!r}. Must be one of: pytorch, sklearn, huggingface"
    )


# Backward compatibility alias
run_experiment = run
