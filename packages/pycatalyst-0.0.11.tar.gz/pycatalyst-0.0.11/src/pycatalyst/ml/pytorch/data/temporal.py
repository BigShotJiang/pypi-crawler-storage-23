"""Temporal data pipeline — chronological split + sliding windows for RNNs/Transformers.

Converts a 2-D DataFrame (rows=time, cols=features) into 3-D tensors
``(batch, sequence_length, features)`` without shuffling.  The scaler is
fit **only** on the training portion.

Large datasets are handled via numpy views where possible; the sliding
window creates a strided view over the pre-allocated array so no deep
copy is made until the tensor materialisation step.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset

from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
from pycatalyst.ml.pytorch.data.scaling import Scaler


@dataclass
class TemporalSplits:
    train_loader: DataLoader
    val_loader: DataLoader
    test_loader: DataLoader
    scaler: Scaler
    feature_names: list[str]
    target_name: str
    input_size: int
    sequence_length: int


def prepare_temporal(config: PytorchExperimentConfig) -> TemporalSplits:
    """Load time-series data, split chronologically, window, and return DataLoaders."""
    df = _load_dataframe(config.data.path)
    target = config.data.target

    if target not in df.columns:
        raise ValueError(
            f"Target column {target!r} not found. Available: {list(df.columns)}"
        )

    feature_cols = config.data.features or [c for c in df.columns if c != target]
    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Feature columns not found: {missing}")

    feat_raw = df[feature_cols].values.astype(np.float32)
    tgt_raw = df[target].values.astype(np.float32).reshape(-1, 1)

    n = len(feat_raw)
    split = config.data.split
    n_train = int(n * split.train)
    n_val = int(n * split.val)

    feat_train = feat_raw[:n_train]
    feat_val = feat_raw[n_train : n_train + n_val]
    feat_test = feat_raw[n_train + n_val :]

    tgt_train = tgt_raw[:n_train]
    tgt_val = tgt_raw[n_train : n_train + n_val]
    tgt_test = tgt_raw[n_train + n_val :]

    # Feature scaler — this is what gets saved for inference
    scaler = Scaler(config.data.scaler)
    scaler.fit(feat_train)
    feat_train = scaler.transform(feat_train)
    feat_val = scaler.transform(feat_val)
    feat_test = scaler.transform(feat_test)

    # Target scaler — separate so inference predictions stay interpretable
    tgt_scaler = Scaler(config.data.scaler)
    tgt_scaler.fit(tgt_train)
    tgt_train = tgt_scaler.transform(tgt_train)
    tgt_val = tgt_scaler.transform(tgt_val)
    tgt_test = tgt_scaler.transform(tgt_test)

    seq_len = config.data.sequence_length
    stride = config.data.stride

    train_X, train_y = _sliding_windows(feat_train, tgt_train, seq_len, stride)
    val_X, val_y = _sliding_windows(feat_val, tgt_val, seq_len, stride)
    test_X, test_y = _sliding_windows(feat_test, tgt_test, seq_len, stride)

    bs = config.training.batch_size

    train_loader = DataLoader(
        TensorDataset(torch.from_numpy(train_X), torch.from_numpy(train_y)),
        batch_size=bs,
        shuffle=False,
    )
    val_loader = DataLoader(
        TensorDataset(torch.from_numpy(val_X), torch.from_numpy(val_y)),
        batch_size=bs,
        shuffle=False,
    )
    test_loader = DataLoader(
        TensorDataset(torch.from_numpy(test_X), torch.from_numpy(test_y)),
        batch_size=bs,
        shuffle=False,
    )

    return TemporalSplits(
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        scaler=scaler,
        feature_names=feature_cols,
        target_name=target,
        input_size=len(feature_cols),
        sequence_length=seq_len,
    )


def _sliding_windows(
    features: np.ndarray,
    targets: np.ndarray,
    seq_len: int,
    stride: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Create sliding-window views over separate feature and target arrays.

    Returns:
        X — shape ``(n_windows, seq_len, n_features)``
        y — shape ``(n_windows, 1)``  (the target at the step after the window)
    """
    n = len(features)
    n_features = features.shape[1]
    if n <= seq_len:
        return (
            np.empty((0, seq_len, n_features), dtype=np.float32),
            np.empty((0, 1), dtype=np.float32),
        )

    indices = list(range(0, n - seq_len, stride))
    X = np.empty((len(indices), seq_len, n_features), dtype=np.float32)
    y = np.empty((len(indices), 1), dtype=np.float32)

    for i, start in enumerate(indices):
        X[i] = features[start : start + seq_len]
        y[i, 0] = targets[start + seq_len, 0]

    return X, y


def _load_dataframe(path: str) -> pd.DataFrame:
    if path.endswith(".parquet"):
        return pd.read_parquet(path)
    return pd.read_csv(path)
