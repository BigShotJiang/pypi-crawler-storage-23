"""Stateful scalers — fit on train, serialize for inference.

Scalers are intentionally implemented without sklearn so that the serving
path has zero heavy dependencies.  Parameters are serialised as plain JSON.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np


class Scaler:
    """MinMax / Standard / Robust scaler with serialisation."""

    def __init__(self, method: str = "minmax") -> None:
        if method not in ("minmax", "standard", "robust", "none"):
            raise ValueError(f"Unknown scaler method: {method!r}")
        self.method = method
        self._params: dict[str, Any] = {}

    def fit(self, data: np.ndarray) -> Scaler:
        """Fit scaler parameters from *data* (2-D array, rows=samples)."""
        if self.method == "none":
            return self

        if self.method == "minmax":
            self._params["min"] = data.min(axis=0).tolist()
            self._params["max"] = data.max(axis=0).tolist()

        elif self.method == "standard":
            self._params["mean"] = data.mean(axis=0).tolist()
            self._params["std"] = data.std(axis=0).tolist()

        elif self.method == "robust":
            self._params["median"] = np.median(data, axis=0).tolist()
            q25 = np.percentile(data, 25, axis=0)
            q75 = np.percentile(data, 75, axis=0)
            self._params["iqr"] = (q75 - q25).tolist()

        return self

    def transform(self, data: np.ndarray) -> np.ndarray:
        """Apply the fitted transform to *data*."""
        if self.method == "none":
            return data

        if self.method == "minmax":
            mn = np.array(self._params["min"])
            mx = np.array(self._params["max"])
            denom = mx - mn
            denom[denom == 0] = 1.0
            return (data - mn) / denom

        if self.method == "standard":
            mean = np.array(self._params["mean"])
            std = np.array(self._params["std"])
            std[std == 0] = 1.0
            return (data - mean) / std

        if self.method == "robust":
            med = np.array(self._params["median"])
            iqr = np.array(self._params["iqr"])
            iqr[iqr == 0] = 1.0
            return (data - med) / iqr

        return data

    def inverse_transform(self, data: np.ndarray) -> np.ndarray:
        """Reverse the scaling."""
        if self.method == "none":
            return data

        if self.method == "minmax":
            mn = np.array(self._params["min"])
            mx = np.array(self._params["max"])
            return data * (mx - mn) + mn

        if self.method == "standard":
            mean = np.array(self._params["mean"])
            std = np.array(self._params["std"])
            std[std == 0] = 1.0
            return data * std + mean

        if self.method == "robust":
            med = np.array(self._params["median"])
            iqr = np.array(self._params["iqr"])
            iqr[iqr == 0] = 1.0
            return data * iqr + med

        return data

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Write scaler parameters to a JSON file."""
        payload = {"method": self.method, "params": self._params}
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> Scaler:
        """Reconstruct a scaler from a saved JSON file."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        scaler = cls(method=data["method"])
        scaler._params = data["params"]
        return scaler
