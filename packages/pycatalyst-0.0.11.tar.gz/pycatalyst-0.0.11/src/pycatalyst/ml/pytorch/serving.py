"""Serving — load a trained model, validate inputs, and predict.

The serving path depends only on torch, numpy, and the engine's own code.
No training script, dataset, or sklearn dependency is required.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np
import torch

from pycatalyst.ml.pytorch.data.scaling import Scaler
from pycatalyst.ml.pytorch.device import get_device
from pycatalyst.ml.pytorch.models.base import TorchModel

logger = logging.getLogger(__name__)


class Predictor:
    """Zero-dependency model loader and predictor.

    Reconstructs a model from ``model_config.json`` + ``model.pt`` and a
    scaler from ``scaler.json``.  Validates input shape before every
    prediction.
    """

    def __init__(
        self,
        model_dir: str | Path,
        *,
        device: str | None = None,
    ) -> None:
        d = Path(model_dir)

        self.model = TorchModel.load(d)
        self.device = get_device(device)
        self.model.to(self.device)
        self.model.eval()

        scaler_path = d / "scaler.json"
        self.scaler = (
            Scaler.load(scaler_path) if scaler_path.exists() else Scaler("none")
        )

        cfg = self.model.get_config()
        self.input_size: int = cfg.get("input_size", 0)
        self.architecture: str = cfg.get("architecture", "unknown")

        config_path = d / "model_config.json"
        self._raw_config: dict[str, Any] = {}
        if config_path.exists():
            self._raw_config = json.loads(config_path.read_text(encoding="utf-8"))

        logger.info(
            "Predictor ready: arch=%s  input_size=%d  device=%s",
            self.architecture,
            self.input_size,
            self.device,
        )

    def predict(self, data: np.ndarray) -> np.ndarray:
        """Run inference on a numpy array.

        For temporal models *data* should be shaped ``(batch, seq_len, features)``
        or ``(seq_len, features)`` (a single window — batch dim is added).

        For tabular models *data* should be ``(batch, features)`` or
        ``(features,)`` (single sample).

        Returns:
            Numpy array of predictions.

        Raises:
            ValueError: If the feature dimension does not match training.
        """
        data = np.asarray(data, dtype=np.float32)

        if data.ndim == 1:
            data = data.reshape(1, -1)
        if data.ndim == 2 and self.architecture in {
            "lstm",
            "gru",
            "tcn",
            "transformer",
        }:
            data = data[np.newaxis, ...]  # add batch dim

        feature_dim = data.shape[-1]
        if self.input_size and feature_dim != self.input_size:
            raise ValueError(
                f"Input has {feature_dim} features but model expects "
                f"{self.input_size}. Check your data matches the training schema."
            )

        scaled = self.scaler.transform(data.reshape(-1, feature_dim)).reshape(
            data.shape
        )
        tensor = torch.from_numpy(scaled.astype(np.float32)).to(self.device)

        with torch.no_grad():
            output = self.model(tensor)

        return output.cpu().numpy()

    def predict_single(self, window: np.ndarray) -> float:
        """Convenience for tick-by-tick prediction.  Returns a scalar."""
        result = self.predict(window)
        return float(result.squeeze())


def export_jit(model_dir: str | Path, output_path: str | Path | None = None) -> str:
    """Export a saved model to TorchScript.

    Args:
        model_dir: Directory containing ``model_config.json`` and ``model.pt``.
        output_path: Where to save the JIT model.  Defaults to
            ``<model_dir>/model_jit.pt``.

    Returns:
        Path to the saved TorchScript file.
    """
    d = Path(model_dir)
    model = TorchModel.load(d)
    model.eval()

    cfg = model.get_config()
    input_size = cfg.get("input_size", 1)
    arch = cfg.get("architecture", "")

    if arch in {"lstm", "gru", "tcn", "transformer"}:
        dummy = torch.randn(1, 60, input_size)
    else:
        dummy = torch.randn(1, input_size)

    traced = torch.jit.trace(model, dummy)
    out = Path(output_path) if output_path else d / "model_jit.pt"
    traced.save(str(out))
    logger.info("TorchScript model saved to %s", out)
    return str(out)
