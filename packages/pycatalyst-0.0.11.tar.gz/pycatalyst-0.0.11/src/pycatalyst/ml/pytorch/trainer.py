"""PyTorch training loop with checkpointing, early stopping, and gradient clipping.

This is the single most important file in the engine.  It orchestrates the
full experiment lifecycle: seed → data → model → train → evaluate → save.
"""

from __future__ import annotations

import json
import logging
import math
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau, StepLR
from torch.utils.data import DataLoader

from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
from pycatalyst.ml.pytorch.data.scaling import Scaler
from pycatalyst.ml.pytorch.device import get_device
from pycatalyst.ml.pytorch.models.registry import create_model
from pycatalyst.ml.results import ExperimentResult

logger = logging.getLogger(__name__)

_TEMPORAL_ARCHITECTURES = frozenset({"lstm", "gru", "tcn", "transformer"})


# ------------------------------------------------------------------
# Public entry point
# ------------------------------------------------------------------


def train(config: PytorchExperimentConfig) -> ExperimentResult:
    """Run a full PyTorch experiment from a validated config."""
    t0 = time.time()
    _seed_all(config.experiment.seed)

    output_dir = Path(config.experiment.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    device = get_device()

    # --- Data ---
    if config.model.architecture in _TEMPORAL_ARCHITECTURES:
        from pycatalyst.ml.pytorch.data.temporal import prepare_temporal

        splits = prepare_temporal(config)
        input_size = splits.input_size
    else:
        from pycatalyst.ml.pytorch.data.tabular import prepare_tabular

        splits = prepare_tabular(config)
        input_size = splits.input_size

    scaler: Scaler = splits.scaler
    scaler_path = output_dir / "scaler.json"
    scaler.save(scaler_path)

    # --- Model ---
    model = create_model(
        config.model.architecture,
        input_size=input_size,
        **config.model.params,
    )
    model.to(device)
    logger.info(
        "Model: %s  params=%s  device=%s",
        config.model.architecture,
        sum(p.numel() for p in model.parameters()),
        device,
    )

    # --- Optimizer & scheduler ---
    optimizer = _build_optimizer(config, model)
    scheduler = _build_scheduler(config, optimizer)

    # --- Training loop ---
    criterion = nn.MSELoss()
    best_metric = (
        math.inf if config.training.early_stopping.mode == "min" else -math.inf
    )
    patience_counter = 0
    history: list[dict[str, Any]] = []

    for epoch in range(1, config.training.epochs + 1):
        train_loss = _train_one_epoch(
            model,
            splits.train_loader,
            criterion,
            optimizer,
            device,
            config.training.gradient_clip,
        )

        val_loss = _evaluate_loss(model, splits.val_loader, criterion, device)

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(val_loss)
            else:
                scheduler.step()

        current_lr = optimizer.param_groups[0]["lr"]
        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "lr": current_lr,
            }
        )

        logger.info(
            "Epoch %d/%d  train_loss=%.6f  val_loss=%.6f  lr=%.2e",
            epoch,
            config.training.epochs,
            train_loss,
            val_loss,
            current_lr,
        )

        # NaN guard
        if math.isnan(train_loss) or math.isnan(val_loss):
            logger.error("NaN detected at epoch %d — stopping training", epoch)
            break

        # Checkpointing
        improved = _is_improvement(
            val_loss,
            best_metric,
            config.training.early_stopping.mode,
        )
        if improved:
            best_metric = val_loss
            patience_counter = 0
            model.save(output_dir)
            logger.info("  ✓ checkpoint saved (val_loss=%.6f)", val_loss)
        else:
            patience_counter += 1

        # Early stopping
        if patience_counter >= config.training.early_stopping.patience:
            logger.info(
                "Early stopping at epoch %d (patience=%d)",
                epoch,
                config.training.early_stopping.patience,
            )
            break

    # --- Save training history ---
    history_path = output_dir / "history.json"
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")

    # --- Reload best weights for evaluation ---
    best_weights = output_dir / "model.pt"
    if best_weights.exists():
        model.load_state_dict(
            torch.load(best_weights, map_location=device, weights_only=True),
        )

    # --- Evaluation on test set ---
    from pycatalyst.ml.pytorch.evaluation import evaluate

    metrics, plot_paths = evaluate(
        model=model,
        test_loader=splits.test_loader,
        scaler=scaler,
        device=device,
        output_dir=output_dir,
        metric_names=config.evaluation.metrics,
        plot_names=config.evaluation.plots,
        history=history,
        target_idx=-1,
    )

    # --- JIT export ---
    if config.serving.jit_export:
        _export_jit(model, splits, device, output_dir)

    duration = time.time() - t0

    artifacts = {
        "weights": str(output_dir / "model.pt"),
        "config": str(output_dir / "model_config.json"),
        "scaler": str(scaler_path),
        "history": str(history_path),
    }
    for name, path in plot_paths.items():
        artifacts[f"plot_{name}"] = path

    return ExperimentResult(
        name=config.experiment.name,
        backend="pytorch",
        metrics=metrics,
        artifacts=artifacts,
        training_history=history,
        duration_seconds=duration,
    )


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def _seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _build_optimizer(
    config: PytorchExperimentConfig,
    model: nn.Module,
) -> torch.optim.Optimizer:
    lr = config.training.learning_rate
    opt = config.training.optimizer
    if opt == "adam":
        return torch.optim.Adam(model.parameters(), lr=lr)
    if opt == "adamw":
        return torch.optim.AdamW(model.parameters(), lr=lr)
    if opt == "sgd":
        return torch.optim.SGD(model.parameters(), lr=lr)
    raise ValueError(f"Unknown optimizer: {opt!r}")


def _build_scheduler(
    config: PytorchExperimentConfig,
    optimizer: torch.optim.Optimizer,
) -> Any | None:
    name = config.training.scheduler
    if name is None:
        return None
    if name == "cosine":
        return CosineAnnealingLR(optimizer, T_max=config.training.epochs)
    if name == "step":
        return StepLR(optimizer, step_size=max(1, config.training.epochs // 3))
    if name == "plateau":
        return ReduceLROnPlateau(optimizer, patience=5)
    raise ValueError(f"Unknown scheduler: {name!r}")


def _train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    clip_norm: float,
) -> float:
    model.train()
    running_loss = 0.0
    n_batches = 0

    for X_batch, y_batch in loader:
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)

        optimizer.zero_grad()
        preds = model(X_batch)
        loss = criterion(preds, y_batch)
        loss.backward()

        if clip_norm > 0:
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)

        optimizer.step()
        running_loss += loss.item()
        n_batches += 1

    return running_loss / max(n_batches, 1)


def _evaluate_loss(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
) -> float:
    model.eval()
    running_loss = 0.0
    n_batches = 0

    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            preds = model(X_batch)
            loss = criterion(preds, y_batch)
            running_loss += loss.item()
            n_batches += 1

    return running_loss / max(n_batches, 1)


def _is_improvement(current: float, best: float, mode: str) -> bool:
    if mode == "min":
        return current < best
    return current > best


def _export_jit(
    model: nn.Module,
    splits: Any,
    device: torch.device,
    output_dir: Path,
) -> None:
    model.eval()
    sample = next(iter(splits.test_loader))[0][:1].to(device)
    try:
        traced = torch.jit.trace(model, sample)
        jit_path = output_dir / "model_jit.pt"
        traced.save(str(jit_path))
        logger.info("TorchScript model saved to %s", jit_path)
    except Exception:
        logger.warning("TorchScript export failed", exc_info=True)
