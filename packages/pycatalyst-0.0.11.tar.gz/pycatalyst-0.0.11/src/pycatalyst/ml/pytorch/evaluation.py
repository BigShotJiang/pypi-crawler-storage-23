"""Evaluation — compute metrics and generate diagnostic plots."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from pycatalyst.ml.pytorch.data.scaling import Scaler

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Public entry point
# ------------------------------------------------------------------


def evaluate(
    *,
    model: nn.Module,
    test_loader: DataLoader,
    scaler: Scaler,
    device: torch.device,
    output_dir: Path,
    metric_names: list[str],
    plot_names: list[str],
    history: list[dict[str, Any]],
    target_idx: int = -1,
) -> tuple[dict[str, float], dict[str, str]]:
    """Evaluate a trained model on the test set.

    Returns:
        (metrics_dict, plot_paths_dict)
    """
    y_true_all: list[np.ndarray] = []
    y_pred_all: list[np.ndarray] = []

    model.eval()
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch = X_batch.to(device)
            preds = model(X_batch).cpu().numpy()
            y_pred_all.append(preds)
            y_true_all.append(y_batch.numpy())

    if not y_true_all:
        logger.warning("Test set is empty — skipping evaluation")
        return {}, {}

    y_true = np.concatenate(y_true_all, axis=0).squeeze()
    y_pred = np.concatenate(y_pred_all, axis=0).squeeze()

    metrics = _compute_metrics(y_true, y_pred, metric_names)

    metrics_path = output_dir / "metrics.json"
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    logger.info("Metrics: %s", metrics)

    plot_dir = output_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    plot_paths = _generate_plots(
        y_true,
        y_pred,
        history,
        plot_names,
        plot_dir,
    )

    return metrics, plot_paths


# ------------------------------------------------------------------
# Metrics
# ------------------------------------------------------------------

_METRIC_FNS: dict[str, Any] = {}


def _register(name: str):
    def decorator(fn):
        _METRIC_FNS[name] = fn
        return fn

    return decorator


@_register("mse")
def _mse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean((y_true - y_pred) ** 2))


@_register("mae")
def _mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))


@_register("rmse")
def _rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


@_register("r2")
def _r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    if ss_tot == 0:
        return 0.0
    return float(1 - ss_res / ss_tot)


@_register("mape")
def _mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    mask = y_true != 0
    if not mask.any():
        return 0.0
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)


@_register("directional_accuracy")
def _directional_accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Fraction of time steps where the predicted direction (up/down) matches actual."""
    if len(y_true) < 2:
        return 0.0
    actual_dir = np.sign(np.diff(y_true))
    pred_dir = np.sign(np.diff(y_pred))
    return float(np.mean(actual_dir == pred_dir))


def _compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    names: list[str],
) -> dict[str, float]:
    out: dict[str, float] = {}
    for name in names:
        fn = _METRIC_FNS.get(name)
        if fn is None:
            logger.warning("Unknown metric %r — skipping", name)
            continue
        out[name] = fn(y_true, y_pred)
    return out


# ------------------------------------------------------------------
# Plots
# ------------------------------------------------------------------


def _generate_plots(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    history: list[dict[str, Any]],
    plot_names: list[str],
    plot_dir: Path,
) -> dict[str, str]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not installed — skipping plots")
        return {}

    paths: dict[str, str] = {}

    for name in plot_names:
        if name == "predicted_vs_actual":
            fig, ax = plt.subplots(figsize=(12, 5))
            ax.plot(y_true, label="Actual", alpha=0.8, linewidth=0.8)
            ax.plot(y_pred, label="Predicted", alpha=0.8, linewidth=0.8)
            ax.set_xlabel("Time step")
            ax.set_ylabel("Value")
            ax.set_title("Predicted vs Actual")
            ax.legend()
            ax.grid(True, alpha=0.3)
            p = plot_dir / "predicted_vs_actual.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        elif name == "loss_curves":
            if not history:
                continue
            fig, ax = plt.subplots(figsize=(10, 5))
            epochs = [h["epoch"] for h in history]
            ax.plot(epochs, [h["train_loss"] for h in history], label="Train loss")
            ax.plot(epochs, [h["val_loss"] for h in history], label="Val loss")
            ax.set_xlabel("Epoch")
            ax.set_ylabel("Loss")
            ax.set_title("Training & Validation Loss")
            ax.legend()
            ax.grid(True, alpha=0.3)
            p = plot_dir / "loss_curves.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        elif name == "residuals":
            residuals = y_true - y_pred
            fig, ax = plt.subplots(figsize=(10, 5))
            ax.hist(residuals, bins=50, edgecolor="black", alpha=0.7)
            ax.set_xlabel("Residual")
            ax.set_ylabel("Frequency")
            ax.set_title("Residual Distribution")
            ax.grid(True, alpha=0.3)
            p = plot_dir / "residuals.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        else:
            logger.warning("Unknown plot %r — skipping", name)

    return paths
