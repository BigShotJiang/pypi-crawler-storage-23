"""PyCatalyst PyTorch engine — config-driven deep learning training."""

from __future__ import annotations

from typing import Any

from pycatalyst.ml.results import ExperimentResult


def run(raw: dict[str, Any]) -> ExperimentResult:
    """Entry point for the PyTorch engine.

    Called by :func:`pycatalyst.ml.run.run_experiment` after backend dispatch.
    """
    from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
    from pycatalyst.ml.pytorch.trainer import train

    config = PytorchExperimentConfig.from_raw(raw)
    return train(config)
