"""Multi-layer perceptron for tabular regression / classification."""

from __future__ import annotations

import torch
import torch.nn as nn

from pycatalyst.ml.pytorch.models.base import TorchModel


class MLPModel(TorchModel):
    """Simple feed-forward MLP for tabular data."""

    architecture = "mlp"

    def __init__(
        self,
        *,
        input_size: int,
        hidden_size: int = 128,
        num_layers: int = 3,
        dropout: float = 0.0,
        output_size: int = 1,
    ) -> None:
        super().__init__(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout,
            output_size=output_size,
        )
        layers: list[nn.Module] = []
        in_dim = input_size
        for _ in range(num_layers - 1):
            layers.extend(
                [
                    nn.Linear(in_dim, hidden_size),
                    nn.ReLU(),
                    nn.Dropout(dropout),
                ]
            )
            in_dim = hidden_size
        layers.append(nn.Linear(in_dim, output_size))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)
