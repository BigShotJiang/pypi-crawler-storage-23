"""PyTorch model architectures for time-series and tabular data."""

from __future__ import annotations
