"""Model registry — maps architecture name strings to model classes."""

from __future__ import annotations

from typing import Any

from pycatalyst.ml.pytorch.models.base import TorchModel
from pycatalyst.ml.pytorch.models.gru import GRUModel
from pycatalyst.ml.pytorch.models.lstm import LSTMModel
from pycatalyst.ml.pytorch.models.mlp import MLPModel
from pycatalyst.ml.pytorch.models.tcn import TCNModel
from pycatalyst.ml.pytorch.models.transformer import TransformerModel

MODEL_REGISTRY: dict[str, type[TorchModel]] = {
    "lstm": LSTMModel,
    "gru": GRUModel,
    "tcn": TCNModel,
    "transformer": TransformerModel,
    "mlp": MLPModel,
}


def create_model(architecture: str, **kwargs: Any) -> TorchModel:
    """Instantiate a model from the registry by name.

    Raises:
        ValueError: If *architecture* is not registered.
    """
    cls = MODEL_REGISTRY.get(architecture)
    if cls is None:
        raise ValueError(
            f"Unknown architecture {architecture!r}. Registered: {list(MODEL_REGISTRY)}"
        )
    return cls(**kwargs)
