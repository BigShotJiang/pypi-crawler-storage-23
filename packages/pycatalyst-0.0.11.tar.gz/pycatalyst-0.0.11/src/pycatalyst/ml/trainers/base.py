"""Base trainer class following sklearn conventions.

Provides ``get_params()`` / ``set_params()`` introspection,
``fit/predict/score`` sklearn-style API, ``run(config)`` config-driven API,
``from_config()`` / ``to_config()`` round-trip, and ``save/load`` persistence.

This is the direct parallel to pyoptima's ``BaseOptimizer``.
"""

from __future__ import annotations

import inspect
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Self, TypeVar

import yaml

from pycatalyst.ml.results import ExperimentResult

logger = logging.getLogger(__name__)

T = TypeVar("T", bound="BaseTrainer")


def clone(trainer: T, **params: Any) -> T:
    """Clone a trainer with optional parameter overrides.

    Args:
        trainer: Trainer to clone.
        **params: Parameters to override.

    Returns:
        New trainer instance with same/updated parameters.
    """
    klass = trainer.__class__
    new_params = trainer.get_params(deep=False)
    new_params.update(params)
    return klass(**new_params)


class BaseTrainer(ABC):
    """Base class for all pycatalyst ML trainers.

    Follows sklearn conventions matching pyoptima's BaseOptimizer.
    Subclasses must implement ``_train(**data)`` and ``_predict(X)``.
    """

    _config_data: dict[str, Any] | None = None  # set by from_config()

    def get_params(self, deep: bool = True) -> dict[str, Any]:
        """Get parameters for this trainer.

        Args:
            deep: If True, also return parameters of nested objects.

        Returns:
            Dictionary of parameter names to values.
        """
        init_signature = inspect.signature(self.__class__.__init__)
        params: dict[str, Any] = {}
        for name, param in init_signature.parameters.items():
            if name == "self":
                continue
            if hasattr(self, name):
                value = getattr(self, name)
            elif param.default is not inspect.Parameter.empty:
                value = param.default
            else:
                value = None
            params[name] = value
            if deep and hasattr(value, "get_params"):
                nested_params = value.get_params(deep=True)
                for key, val in nested_params.items():
                    params[f"{name}__{key}"] = val
        return params

    def set_params(self, **params: Any) -> Self:
        """Set parameters for this trainer.

        Args:
            **params: Parameter names and values to set.

        Returns:
            self

        Raises:
            ValueError: If an invalid parameter name is provided.
        """
        valid_params = self.get_params(deep=True)
        nested_params: dict[str, dict[str, Any]] = {}
        for key, value in params.items():
            if "__" in key:
                param_name, sub_key = key.split("__", 1)
                if param_name not in nested_params:
                    nested_params[param_name] = {}
                nested_params[param_name][sub_key] = value
            else:
                if key not in valid_params:
                    raise ValueError(
                        f"Invalid parameter '{key}' for "
                        f"{self.__class__.__name__}. "
                        f"Valid parameters: {sorted(valid_params.keys())}"
                    )
                setattr(self, key, value)
        for param_name, sub_params in nested_params.items():
            if hasattr(self, param_name):
                nested_obj = getattr(self, param_name)
                if hasattr(nested_obj, "set_params"):
                    nested_obj.set_params(**sub_params)
        return self

    # --- Config-driven primary API ---

    def run(
        self,
        config: dict[str, Any] | str | Path | None = None,
    ) -> ExperimentResult:
        """Run training from config (primary interface).

        Args:
            config: YAML/JSON path, dict, or None (uses stored config).

        Returns:
            ExperimentResult with metrics, artifacts, and history.

        Raises:
            ValueError: If no config is provided and none was stored.
        """
        if config is None and hasattr(self, "_config_data"):
            config = self._config_data
        if isinstance(config, str | Path):
            config = _load_config_file(config)
        if config is None:
            raise ValueError(
                "No config provided and no stored config from from_config()"
            )
        self._validate_config(config)
        result = self._train(**config)
        self._last_result = result
        return result

    # --- sklearn-style secondary API ---

    def fit(self, X: Any = None, y: Any = None, **data: Any) -> Self:
        """Train the model (sklearn-style). Returns self.

        Args:
            X: Input features.
            y: Target values.
            **data: Additional data passed to ``_train()``.
        """
        fit_data: dict[str, Any] = dict(data)
        if X is not None:
            fit_data["X"] = X
        if y is not None:
            fit_data["y"] = y
        self._fit_data = fit_data
        self._last_result = self._train(**fit_data)
        return self

    def predict(self, X: Any) -> Any:
        """Run inference using the trained model.

        Args:
            X: Input features.

        Raises:
            RuntimeError: If the trainer has not been fitted yet.
        """
        if not hasattr(self, "_last_result"):
            raise RuntimeError(
                "Trainer has not been fit yet. Call fit() or run() first."
            )
        return self._predict(X)

    def score(self, X: Any = None, y: Any = None, **data: Any) -> float:
        """Return the primary metric value.

        Args:
            X: Input features.
            y: Target values.
            **data: Additional data.

        Returns:
            Primary metric value, or ``-inf`` if not found.
        """
        score_data: dict[str, Any] = dict(data)
        if X is not None:
            score_data["X"] = X
        if y is not None:
            score_data["y"] = y
        if not score_data and hasattr(self, "_fit_data"):
            score_data = dict(self._fit_data)
        result = self._train(**score_data)
        primary = self._primary_metric()
        return result.metrics.get(primary, float("-inf"))

    # --- Config round-trip ---

    @classmethod
    def from_config(cls, config: dict[str, Any] | str | Path) -> BaseTrainer:
        """Build a trainer from a config file or dict.

        Args:
            config: Path to .json/.yaml, dict, or Pydantic config.

        Returns:
            Configured trainer instance.
        """
        if isinstance(config, str | Path):
            config = _load_config_file(config)
        if isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = dict(config) if hasattr(config, "__iter__") else {}
        init_sig = inspect.signature(cls.__init__)
        kwargs: dict[str, Any] = {}
        for pname in init_sig.parameters:
            if pname == "self":
                continue
            if pname in cfg:
                kwargs[pname] = cfg[pname]
        trainer = cls(**kwargs)
        trainer._config_data = cfg  # noqa: SLF001
        return trainer

    def to_config(self) -> dict[str, Any]:
        """Serialize trainer to a config dictionary."""
        return self.get_params(deep=False)

    # --- Persistence ---

    def save(self, directory: str | Path) -> dict[str, str]:
        """Save trained model and config to directory.

        Raises:
            RuntimeError: If no trained model to save.
        """
        if not hasattr(self, "_last_result"):
            raise RuntimeError("No trained model to save. Call fit() or run() first.")
        return self._save(directory)

    @classmethod
    def load(cls, directory: str | Path) -> BaseTrainer:
        """Load a trained trainer from a directory."""
        return cls._load(directory)

    # --- Abstract methods (subclasses implement) ---

    @abstractmethod
    def _train(self, **data: Any) -> ExperimentResult:
        """Actual training implementation."""
        ...

    @abstractmethod
    def _predict(self, X: Any) -> Any:
        """Actual prediction implementation."""
        ...

    def _validate_config(self, config: dict[str, Any]) -> None:
        """Validate config data. Override in subclasses."""

    def _primary_metric(self) -> str:
        """Return the name of the primary metric for ``score()``."""
        return "mse"

    def _save(self, directory: str | Path) -> dict[str, str]:
        """Save implementation. Override in subclasses."""
        raise NotImplementedError(f"{self.__class__.__name__} does not support save()")

    @classmethod
    def _load(cls, directory: str | Path) -> BaseTrainer:
        """Load implementation. Override in subclasses."""
        raise NotImplementedError(f"{cls.__name__} does not support load()")

    # --- Dunder methods ---

    def __repr__(self) -> str:
        """sklearn-style repr showing class and parameters."""
        params = self.get_params(deep=False)
        param_strs = []
        for name, value in params.items():
            if isinstance(value, str):
                param_strs.append(f"{name}={value!r}")
            elif isinstance(value, float):
                param_strs.append(f"{name}={value:.4g}")
            elif value is None:
                continue
            else:
                param_strs.append(f"{name}={value!r}")
        return f"{self.__class__.__name__}({', '.join(param_strs)})"

    def __eq__(self, other: object) -> bool:
        """Check equality based on class and parameters."""
        if not isinstance(other, BaseTrainer):
            return False
        if self.__class__ != other.__class__:
            return False
        return self.get_params() == other.get_params()

    def __hash__(self) -> int:
        """Hash based on class name (not params, as they're mutable)."""
        return hash(self.__class__.__name__)


def _load_config_file(path: str | Path) -> dict[str, Any]:
    """Load a YAML or JSON config file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    raw = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Expected a YAML mapping, got {type(raw).__name__}")
    return raw
