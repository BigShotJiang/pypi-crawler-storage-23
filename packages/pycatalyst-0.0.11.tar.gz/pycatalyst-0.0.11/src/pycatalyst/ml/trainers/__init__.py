"""ML trainer classes — sklearn-style estimator interface for all backends.

Re-exports the public API::

    from pycatalyst.ml.trainers import SklearnTrainer, clone

    trainer = SklearnTrainer(architecture="ridge")
    trainer.fit(X_train, y_train)
    preds = trainer.predict(X_test)
"""

from __future__ import annotations

from pycatalyst.ml.trainers.base import BaseTrainer, clone

__all__ = [
    "BaseTrainer",
    "HuggingFaceTrainer",
    "PytorchTrainer",
    "SklearnTrainer",
    "clone",
]


def __getattr__(name: str) -> type:
    """Lazy imports to avoid pulling heavy deps at import time."""
    if name == "SklearnTrainer":
        from pycatalyst.ml.trainers.sklearn import SklearnTrainer

        return SklearnTrainer

    if name == "PytorchTrainer":
        from pycatalyst.ml.trainers.pytorch import PytorchTrainer

        return PytorchTrainer

    if name == "HuggingFaceTrainer":
        from pycatalyst.ml.trainers.huggingface import HuggingFaceTrainer

        return HuggingFaceTrainer

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
