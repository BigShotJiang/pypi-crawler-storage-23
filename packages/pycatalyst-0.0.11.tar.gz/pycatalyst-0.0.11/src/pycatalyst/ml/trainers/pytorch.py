"""PyTorch trainer — sklearn-style estimator wrapping the pytorch engine.

Provides both config-driven and programmatic access to PyTorch models::

    # Config-driven
    trainer = PytorchTrainer.from_config("experiment.yaml")
    result = trainer.run()

    # Python API
    trainer = PytorchTrainer(architecture="lstm", epochs=50)
    print(trainer.get_params())
    config = trainer.to_config()

Note:
    The ``fit(X, y)`` sklearn-style path is not yet supported for
    PyTorch models because they require sequence windowing and
    DataLoader setup.  Use the config-driven ``run()`` path instead.
"""

from __future__ import annotations

import logging
from typing import Any

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.trainers.base import BaseTrainer

logger = logging.getLogger(__name__)


class PytorchTrainer(BaseTrainer):
    """Trainer for PyTorch deep learning models.

    Wraps the PyTorch engine to provide introspection, config round-trip,
    and the standard trainer interface.

    Args:
        architecture: Model type (e.g. ``"lstm"``, ``"gru"``, ``"tcn"``).
        params: Model hyperparameters (hidden_size, num_layers, etc.).
        epochs: Number of training epochs.
        batch_size: Mini-batch size.
        learning_rate: Optimizer learning rate.
        optimizer: Optimizer name (``"adam"``, ``"adamw"``, ``"sgd"``).
        scheduler: LR scheduler name or None.
        gradient_clip: Max gradient norm for clipping.
        patience: Early stopping patience.
        seed: Random seed.
        jit_export: Whether to export TorchScript model.
        output_dir: Directory for saving artifacts.

    Example::

        trainer = PytorchTrainer(architecture="lstm",
                                 params={"hidden_size": 128})
        result = trainer.run("experiment.yaml")
        print(result.metrics)
    """

    def __init__(
        self,
        architecture: str = "lstm",
        params: dict[str, Any] | None = None,
        epochs: int = 100,
        batch_size: int = 32,
        learning_rate: float = 1e-3,
        optimizer: str = "adam",
        scheduler: str | None = None,
        gradient_clip: float = 1.0,
        patience: int = 10,
        seed: int = 42,
        jit_export: bool = False,
        output_dir: str = "./runs/pytorch",
    ) -> None:
        self.architecture = architecture
        self.params = params or {}
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.gradient_clip = gradient_clip
        self.patience = patience
        self.seed = seed
        self.jit_export = jit_export
        self.output_dir = output_dir

    # ------------------------------------------------------------------
    # Abstract implementations
    # ------------------------------------------------------------------

    def _train(self, **data: Any) -> ExperimentResult:
        """Train via the PyTorch engine.

        Only config-driven path is supported. The data dict must contain
        ``"experiment"`` and ``"data"`` sections (from YAML config).
        """
        if "experiment" not in data:
            raise NotImplementedError(
                "PytorchTrainer only supports config-driven training. "
                "Use run() with a YAML config file."
            )

        from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
        from pycatalyst.ml.pytorch.trainer import train

        config = PytorchExperimentConfig.from_raw(data)
        return train(config)

    def _predict(self, X: Any) -> Any:
        """Prediction requires loading saved model weights."""
        raise NotImplementedError(
            "PytorchTrainer.predict() requires loading model weights. "
            "Use the pytorch.serving.Predictor for inference instead."
        )

    def _primary_metric(self) -> str:
        """Default primary metric for PyTorch models."""
        return "mse"

    def _validate_config(self, config: dict[str, Any]) -> None:
        """Validate config has required sections."""
        if "experiment" not in config:
            raise ValueError("Config must have an 'experiment' section")
        if "data" not in config:
            raise ValueError("Config must have a 'data' section")
        if "model" not in config:
            raise ValueError("Config must have a 'model' section")

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def list_architectures() -> list[str]:
        """Return sorted list of available PyTorch architectures."""
        # Lazy import to avoid requiring torch at import time
        try:
            from pycatalyst.ml.pytorch.models.registry import MODEL_REGISTRY

            return sorted(MODEL_REGISTRY.keys())
        except ImportError:
            logger.warning("PyTorch not installed — cannot list architectures")
            return []
