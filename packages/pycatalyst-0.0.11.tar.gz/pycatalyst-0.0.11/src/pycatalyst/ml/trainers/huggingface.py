"""HuggingFace trainer — sklearn-style estimator wrapping the HF engine.

Provides config-driven access to HuggingFace fine-tuning::

    trainer = HuggingFaceTrainer.from_config("llm_experiment.yaml")
    result = trainer.run()
    print(result.metrics)

Note:
    The ``fit(X, y)`` sklearn-style path is not supported for LLM
    fine-tuning.  Use the config-driven ``run()`` path instead.
"""

from __future__ import annotations

import logging
from typing import Any

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.trainers.base import BaseTrainer

logger = logging.getLogger(__name__)


class HuggingFaceTrainer(BaseTrainer):
    """Trainer for HuggingFace Transformers with PEFT/LoRA.

    Wraps the HuggingFace engine to provide introspection, config
    round-trip, and the standard trainer interface.

    Args:
        base_model: HuggingFace model identifier.
        adapter: Adapter type (``"lora"``, ``"qlora"``, ``"none"``).
        r: LoRA rank.
        lora_alpha: LoRA alpha scaling.
        epochs: Number of training epochs.
        batch_size: Per-device batch size.
        learning_rate: Optimizer learning rate.
        seed: Random seed.
        output_dir: Directory for saving artifacts.

    Example::

        trainer = HuggingFaceTrainer(base_model="microsoft/phi-2")
        result = trainer.run("llm_config.yaml")
        print(result.metrics)
    """

    def __init__(
        self,
        base_model: str = "microsoft/phi-2",
        adapter: str = "lora",
        r: int = 16,
        lora_alpha: int = 32,
        epochs: int = 3,
        batch_size: int = 4,
        learning_rate: float = 2e-4,
        seed: int = 42,
        output_dir: str = "./runs/huggingface",
    ) -> None:
        self.base_model = base_model
        self.adapter = adapter
        self.r = r
        self.lora_alpha = lora_alpha
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.seed = seed
        self.output_dir = output_dir

    # ------------------------------------------------------------------
    # Abstract implementations
    # ------------------------------------------------------------------

    def _train(self, **data: Any) -> ExperimentResult:
        """Train via the HuggingFace engine.

        Only config-driven path is supported.
        """
        if "experiment" not in data:
            raise NotImplementedError(
                "HuggingFaceTrainer only supports config-driven training. "
                "Use run() with a YAML config file."
            )

        from pycatalyst.ml.huggingface.config import HFExperimentConfig
        from pycatalyst.ml.huggingface.engine import train

        config = HFExperimentConfig.from_raw(data)
        return train(config)

    def _predict(self, X: Any) -> Any:
        """Text generation requires adapter loading — not supported here."""
        raise NotImplementedError(
            "HuggingFaceTrainer.predict() is not supported. "
            "Use the HuggingFace pipeline or model.generate() directly."
        )

    def _primary_metric(self) -> str:
        """Default primary metric for LLM fine-tuning."""
        return "eval_loss"

    def _validate_config(self, config: dict[str, Any]) -> None:
        """Validate config has required sections."""
        if "experiment" not in config:
            raise ValueError("Config must have an 'experiment' section")
        if "data" not in config:
            raise ValueError("Config must have a 'data' section")
        if "model" not in config:
            raise ValueError("Config must have a 'model' section")
