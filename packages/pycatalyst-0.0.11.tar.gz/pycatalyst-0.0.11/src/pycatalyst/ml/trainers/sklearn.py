"""Sklearn trainer — sklearn-style estimator wrapping the sklearn engine.

Provides both config-driven and Python API access to sklearn models::

    # Config-driven
    trainer = SklearnTrainer.from_config("experiment.yaml")
    result = trainer.run()

    # sklearn-style
    trainer = SklearnTrainer(architecture="ridge", params={"alpha": 1.0})
    trainer.fit(X_train, y_train)
    preds = trainer.predict(X_test)
    print(trainer.score(X_test, y_test))
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

import numpy as np

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.trainers.base import BaseTrainer

logger = logging.getLogger(__name__)


class SklearnTrainer(BaseTrainer):
    """Trainer for scikit-learn classical ML models.

    Wraps the sklearn engine to provide both config-driven (``run()``)
    and sklearn-style (``fit/predict/score``) interfaces.

    Args:
        architecture: Model type (e.g. ``"ridge"``, ``"random_forest"``).
        params: Model hyperparameters passed to the sklearn constructor.
        seed: Random seed for reproducibility.
        scaler: Feature scaling method.
        metrics: Evaluation metric names.
        output_dir: Directory for saving artifacts.

    Example::

        trainer = SklearnTrainer(architecture="random_forest",
                                 params={"n_estimators": 200})
        trainer.fit(X_train, y_train)
        score = trainer.score(X_test, y_test)
    """

    def __init__(
        self,
        architecture: str = "linear_regression",
        params: dict[str, Any] | None = None,
        seed: int = 42,
        scaler: str = "standard",
        metrics: list[str] | None = None,
        output_dir: str = "./runs/sklearn",
    ) -> None:
        self.architecture = architecture
        self.params = params or {}
        self.seed = seed
        self.scaler = scaler
        self.metrics = metrics or ["mse", "mae", "r2"]
        self.output_dir = output_dir

        # Internal state (not part of get_params)
        self._model: Any = None
        self._scaler_params: dict[str, Any] = {}
        self._feature_names: list[str] = []

    # ------------------------------------------------------------------
    # Abstract implementations
    # ------------------------------------------------------------------

    def _train(self, **data: Any) -> ExperimentResult:
        """Train sklearn model from either config or raw arrays."""
        # Config path: has 'experiment' key → delegate to engine
        if "experiment" in data:
            return self._train_from_config(data)
        # sklearn path: has X/y
        return self._train_from_arrays(data)

    def _predict(self, X: Any) -> np.ndarray:
        """Run inference using the fitted model."""
        if self._model is None:
            raise RuntimeError("Model not fitted. Call fit() first.")

        X = np.asarray(X, dtype=np.float64)
        if self._scaler_params:
            X = self._apply_scaler(X)
        return self._model.predict(X)

    def _primary_metric(self) -> str:
        """Return the first metric in the list."""
        return self.metrics[0] if self.metrics else "mse"

    def _validate_config(self, config: dict[str, Any]) -> None:
        """Validate that config has required sections."""
        if "experiment" not in config:
            raise ValueError("Config must have an 'experiment' section")

    def _save(self, directory: str | Path) -> dict[str, str]:
        """Save model and config to directory."""
        import joblib

        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)

        model_path = d / "model.joblib"
        joblib.dump(self._model, model_path)

        config_data = {
            "architecture": self.architecture,
            "params": self.params,
            "features": self._feature_names,
            "scaler": self.scaler,
            "scaler_params": self._scaler_params,
            "seed": self.seed,
            "metrics": self.metrics,
        }
        config_path = d / "trainer_config.json"
        config_path.write_text(
            json.dumps(config_data, indent=2),
            encoding="utf-8",
        )

        return {"model": str(model_path), "config": str(config_path)}

    @classmethod
    def _load(cls, directory: str | Path) -> SklearnTrainer:
        """Load a saved SklearnTrainer from directory."""
        import joblib

        d = Path(directory)
        config_path = d / "trainer_config.json"
        config_data = json.loads(config_path.read_text(encoding="utf-8"))

        trainer = cls(
            architecture=config_data["architecture"],
            params=config_data.get("params", {}),
            seed=config_data.get("seed", 42),
            scaler=config_data.get("scaler", "standard"),
            metrics=config_data.get("metrics", ["mse", "mae", "r2"]),
        )
        trainer._model = joblib.load(d / "model.joblib")
        trainer._scaler_params = config_data.get("scaler_params", {})
        trainer._feature_names = config_data.get("features", [])

        # Mark as fitted
        trainer._last_result = ExperimentResult(
            name="loaded",
            backend="sklearn",
        )
        return trainer

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def list_architectures() -> list[str]:
        """Return sorted list of available sklearn architectures."""
        from pycatalyst.ml.sklearn.engine import list_architectures

        return list_architectures()

    # ------------------------------------------------------------------
    # Internal training paths
    # ------------------------------------------------------------------

    def _train_from_config(self, data: dict[str, Any]) -> ExperimentResult:
        """Delegate to the existing sklearn engine for config-driven runs."""
        from pycatalyst.ml.sklearn.config import SklearnExperimentConfig
        from pycatalyst.ml.sklearn.engine import train

        config = SklearnExperimentConfig.from_raw(data)
        result = train(config)

        # Capture model reference for predict()
        self._load_model_from_output(config.experiment.output_dir)

        return result

    def _train_from_arrays(self, data: dict[str, Any]) -> ExperimentResult:
        """Train directly from X/y arrays (sklearn-style path)."""
        from pycatalyst.ml.sklearn._helpers import (
            compute_metrics,
            scale,
            seed_all,
            split,
        )
        from pycatalyst.ml.sklearn.engine import get_model_class

        t0 = time.time()
        seed_all(self.seed)

        X = np.asarray(data["X"], dtype=np.float64)
        y = np.asarray(data["y"], dtype=np.float64)

        # Split: use 70/15/15 default
        train_ratio = data.get("train_ratio", 0.7)
        val_ratio = data.get("val_ratio", 0.15)
        X_train, X_val, X_test, y_train, y_val, y_test = split(
            X,
            y,
            "random",
            train_ratio,
            val_ratio,
            self.seed,
        )

        # Scale
        X_train, X_val, X_test, self._scaler_params = scale(
            X_train,
            X_val,
            X_test,
            self.scaler,
        )

        # Build and fit model
        model_cls = get_model_class(self.architecture)
        self._model = model_cls(**self.params)
        self._model.fit(X_train, y_train)

        # Evaluate
        y_pred = self._model.predict(X_test)
        metrics = compute_metrics(y_test, y_pred, self.metrics)

        duration = time.time() - t0
        logger.info(
            "Trained %s in %.2fs — %s",
            self.architecture,
            duration,
            {k: round(v, 6) for k, v in metrics.items()},
        )

        return ExperimentResult(
            name=f"sklearn-{self.architecture}",
            backend="sklearn",
            metrics=metrics,
            duration_seconds=duration,
            config=self.to_config(),
        )

    def _load_model_from_output(self, output_dir: str) -> None:
        """Load model from engine output for subsequent predict() calls."""
        import joblib

        model_path = Path(output_dir) / "model.joblib"
        if model_path.exists():
            self._model = joblib.load(model_path)

        scaler_path = Path(output_dir) / "scaler.json"
        if scaler_path.exists():
            scaler_data = json.loads(
                scaler_path.read_text(encoding="utf-8"),
            )
            self._scaler_params = scaler_data.get("params", {})

    def _apply_scaler(self, X: np.ndarray) -> np.ndarray:
        """Apply saved scaler parameters to input features."""
        if not self._scaler_params:
            return X

        if self.scaler == "standard":
            mean = np.array(self._scaler_params["mean"])
            std = np.array(self._scaler_params["std"])
            return (X - mean) / std

        if self.scaler == "minmax":
            mn = np.array(self._scaler_params["min"])
            mx = np.array(self._scaler_params["max"])
            denom = mx - mn
            denom[denom == 0] = 1.0
            return (X - mn) / denom

        if self.scaler == "robust":
            med = np.array(self._scaler_params["median"])
            iqr = np.array(self._scaler_params["iqr"])
            return (X - med) / iqr

        return X
