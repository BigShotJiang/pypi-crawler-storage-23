"""Shared output schema for all ML engines.

Every engine must return an ``ExperimentResult`` so that the CLI, API, and UI
can display results uniformly regardless of which backend produced them.

Mirrors pyoptima's ``OptimizationResult`` pattern with pandas-style IO methods.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from pycatalyst.ml._types import TrainingStatus

try:
    import pandas as pd

    _HAS_PANDAS = True
except ImportError:
    _HAS_PANDAS = False


@dataclass
class ExperimentResult:
    """Standard output produced by every ML engine after training.

    Provides pandas-style export methods following pyoptima's
    ``OptimizationResult`` pattern::

        result = trainer.fit(X, y)
        print(result.to_json())
        df = result.to_dataframe()
        result.to_json("result.json")
    """

    name: str
    backend: str
    status: TrainingStatus = TrainingStatus.COMPLETED
    metrics: dict[str, float] = field(default_factory=dict)
    artifacts: dict[str, str] = field(default_factory=dict)
    training_history: list[dict[str, Any]] = field(default_factory=list)
    duration_seconds: float = 0.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    config: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_completed(self) -> bool:
        """Check if training completed (finished or early-stopped)."""
        return self.status in (
            TrainingStatus.COMPLETED,
            TrainingStatus.EARLY_STOPPED,
        )

    @property
    def is_successful(self) -> bool:
        """Check if training completed and produced metrics."""
        return self.is_completed and bool(self.metrics)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ExperimentResult:
        """Build an ExperimentResult from a dictionary.

        Args:
            d: Dictionary with result fields.

        Returns:
            Reconstructed ExperimentResult.
        """
        status_val = d.get("status", "completed")
        if isinstance(status_val, TrainingStatus):
            status = status_val
        else:
            try:
                status = TrainingStatus(status_val)
            except ValueError:
                status = TrainingStatus.UNKNOWN

        ts = d.get("timestamp")
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)
        elif not isinstance(ts, datetime):
            ts = datetime.now(UTC)

        return cls(
            name=d.get("name", ""),
            backend=d.get("backend", ""),
            status=status,
            metrics=d.get("metrics", {}),
            artifacts=d.get("artifacts", {}),
            training_history=d.get("training_history", []),
            duration_seconds=d.get("duration_seconds", 0.0),
            timestamp=ts,
            config=d.get("config", {}),
        )

    # ------------------------------------------------------------------
    # Export methods (pandas-style, matching OptimizationResult)
    # ------------------------------------------------------------------

    def to_dict(self, include_config: bool = True) -> dict[str, Any]:
        """Export result as dictionary.

        Args:
            include_config: Whether to include the full config dict.

        Returns:
            Dictionary representation with only non-empty fields.
        """
        result: dict[str, Any] = {
            "name": self.name,
            "backend": self.backend,
            "status": self.status.value,
            "metrics": self.metrics,
            "duration_seconds": self.duration_seconds,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }

        if self.artifacts:
            result["artifacts"] = self.artifacts
        if self.training_history:
            result["training_history"] = self.training_history
        if include_config and self.config:
            result["config"] = self.config

        return result

    def to_dataframe(self, orient: str = "index") -> pd.DataFrame:
        """Export result as pandas DataFrame.

        Args:
            orient: DataFrame orientation (``"index"`` or ``"columns"``).

        Returns:
            pandas DataFrame.

        Raises:
            ImportError: If pandas is not installed.
        """
        if not _HAS_PANDAS:
            raise ImportError(
                "pandas is required for to_dataframe(). "
                "Install with: pip install pandas"
            )

        data = self.to_dict(include_config=False)

        if orient == "index":
            return pd.DataFrame.from_dict(data, orient="index", columns=["value"])
        return pd.DataFrame([data])

    def history_to_dataframe(self) -> pd.DataFrame:
        """Export training history as a DataFrame.

        Each row is one epoch/step. Columns are the metrics recorded
        at each step (e.g. train_loss, val_loss, learning_rate).

        Returns:
            DataFrame with one row per history entry.

        Raises:
            ImportError: If pandas is not installed.
            ValueError: If no training history available.
        """
        if not _HAS_PANDAS:
            raise ImportError(
                "pandas is required for history_to_dataframe(). "
                "Install with: pip install pandas"
            )
        if not self.training_history:
            raise ValueError("No training history available")
        return pd.DataFrame(self.training_history)

    def to_json(self, path: str | None = None, indent: int = 2) -> str:
        """Export result as JSON.

        Args:
            path: Optional file path to write to.
            indent: JSON indentation level.

        Returns:
            JSON string.
        """
        data = self.to_dict()
        json_str = json.dumps(data, indent=indent, default=str)

        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(json_str)

        return json_str

    def to_sql(
        self,
        table: str,
        connection: Any,
        schema: str | None = None,
        if_exists: str = "append",
    ) -> None:
        """Write result to SQL database.

        Args:
            table: Table name.
            connection: SQLAlchemy connection or engine.
            schema: Database schema.
            if_exists: How to handle existing table.

        Raises:
            ImportError: If pandas is not installed.
        """
        if not _HAS_PANDAS:
            raise ImportError(
                "pandas is required for to_sql(). Install with: pip install pandas"
            )
        df = self.to_dataframe(orient="columns")
        df.to_sql(table, connection, schema=schema, if_exists=if_exists, index=False)

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def summary(self) -> str:
        """Pretty-print experiment summary for CLI output."""
        lines = [
            f"Experiment: {self.name}  (backend={self.backend})",
            f"Status:     {self.status.value}",
            f"Duration:   {self.duration_seconds:.1f}s",
        ]
        if self.metrics:
            lines.append("Metrics:")
            for k, v in self.metrics.items():
                lines.append(f"  {k}: {v:.6g}")
        if self.artifacts:
            lines.append("Artifacts:")
            for k, v in self.artifacts.items():
                lines.append(f"  {k}: {v}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        """Concise repr matching pyoptima style."""
        parts = [f"ExperimentResult(status={self.status.value}"]
        if self.metrics:
            primary = next(iter(self.metrics.values()))
            primary_name = next(iter(self.metrics))
            parts.append(f", {primary_name}={primary:.6g}")
        if self.duration_seconds:
            parts.append(f", time={self.duration_seconds:.1f}s")
        parts.append(")")
        return "".join(parts)
