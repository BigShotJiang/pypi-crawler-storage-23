"""PyCatalyst ML — config-driven model training with sklearn-style API.

Two-tier API following pyoptima's pattern:

**Tier 1: Config-driven** (primary interface)::

    from pycatalyst import ml

    result = ml.run("experiment.yaml")
    config = ml.load("experiment.yaml")
    backends = ml.list_backends()

**Tier 2: Python API** (sklearn-style)::

    from pycatalyst.ml import SklearnTrainer, clone

    trainer = SklearnTrainer(architecture="ridge")
    trainer.fit(X_train, y_train)
    preds = trainer.predict(X_test)
    trainer2 = clone(trainer, architecture="lasso")
"""

from __future__ import annotations

# Types
from pycatalyst.ml._types import Backend, TrainingStatus

# Tier 1: Config-driven API
from pycatalyst.ml.registry import list_architectures, list_backends
from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.run import load, run

# Tier 2: Re-exported from trainers (lazy)
from pycatalyst.ml.trainers import BaseTrainer, clone

__all__ = [
    # Tier 1
    "run",
    "load",
    "list_backends",
    "list_architectures",
    "ExperimentResult",
    # Tier 2
    "BaseTrainer",
    "SklearnTrainer",
    "PytorchTrainer",
    "HuggingFaceTrainer",
    "clone",
    # Types
    "TrainingStatus",
    "Backend",
]


def __getattr__(name: str) -> type:
    """Lazy imports for trainer classes to avoid pulling heavy deps."""
    if name == "SklearnTrainer":
        from pycatalyst.ml.trainers.sklearn import SklearnTrainer

        return SklearnTrainer

    if name == "PytorchTrainer":
        from pycatalyst.ml.trainers.pytorch import PytorchTrainer

        return PytorchTrainer

    if name == "HuggingFaceTrainer":
        from pycatalyst.ml.trainers.huggingface import HuggingFaceTrainer

        return HuggingFaceTrainer

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
