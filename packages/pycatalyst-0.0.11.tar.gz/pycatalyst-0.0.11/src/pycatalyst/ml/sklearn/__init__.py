"""PyCatalyst sklearn engine — config-driven classical ML training."""

from __future__ import annotations

from typing import Any

from pycatalyst.ml.results import ExperimentResult


def run(raw: dict[str, Any]) -> ExperimentResult:
    """Entry point for the sklearn engine."""
    from pycatalyst.ml.sklearn.config import SklearnExperimentConfig
    from pycatalyst.ml.sklearn.engine import train

    config = SklearnExperimentConfig.from_raw(raw)
    return train(config)
