"""Pydantic configuration for sklearn experiments."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class ExperimentSection(BaseModel):
    name: str = Field(..., min_length=1)
    seed: int = Field(default=42, ge=0)
    backend: Literal["sklearn"] = "sklearn"
    output_dir: str = Field(default="./runs/experiment")


class SplitConfig(BaseModel):
    strategy: Literal["random", "temporal"] = "random"
    train: float = Field(default=0.7, gt=0, lt=1)
    val: float = Field(default=0.15, gt=0, lt=1)
    test: float = Field(default=0.15, gt=0, lt=1)

    @model_validator(mode="after")
    def _ratios_sum_to_one(self) -> SplitConfig:
        total = self.train + self.val + self.test
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"Split ratios must sum to 1.0, got {total:.4f}")
        return self


class DataSection(BaseModel):
    path: str = Field(..., min_length=1)
    target: str = Field(..., min_length=1)
    features: list[str] | None = None
    split: SplitConfig = Field(default_factory=SplitConfig)
    scaler: Literal["standard", "minmax", "robust", "none"] = "standard"
    handle_missing: Literal["drop", "mean", "median", "mode"] = "drop"


class ModelSection(BaseModel):
    architecture: str = Field(..., min_length=1)
    params: dict[str, Any] = Field(default_factory=dict)


class CrossValidationConfig(BaseModel):
    enabled: bool = False
    folds: int = Field(default=5, ge=2)
    scoring: str = "neg_mean_squared_error"


class TrainingSection(BaseModel):
    cross_validation: CrossValidationConfig = Field(
        default_factory=CrossValidationConfig,
    )


class EvaluationSection(BaseModel):
    metrics: list[str] = Field(default=["mse", "mae", "r2"], min_length=1)
    plots: list[str] = Field(default=["predicted_vs_actual"])


class SklearnExperimentConfig(BaseModel):
    experiment: ExperimentSection
    data: DataSection
    model: ModelSection
    training: TrainingSection = Field(default_factory=TrainingSection)
    evaluation: EvaluationSection = Field(default_factory=EvaluationSection)

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> SklearnExperimentConfig:
        return cls.model_validate(raw)
