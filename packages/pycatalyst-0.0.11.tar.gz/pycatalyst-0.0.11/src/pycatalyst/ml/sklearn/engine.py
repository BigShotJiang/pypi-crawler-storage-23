"""Sklearn engine — load, split, fit, cross-val, evaluate, save.

The heavy helper functions (split, scale, metrics, plots) are in
``_helpers.py`` to keep both modules under the 400-line limit.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

import numpy as np

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.sklearn._helpers import (
    compute_metrics,
    generate_plots,
    handle_missing,
    load_dataframe,
    scale,
    seed_all,
    split,
)
from pycatalyst.ml.sklearn.config import SklearnExperimentConfig

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Model registry
# ------------------------------------------------------------------

_MODEL_REGISTRY: dict[str, Any] = {}


def _populate_registry() -> None:
    """Lazily populate the registry on first use."""
    if _MODEL_REGISTRY:
        return

    from sklearn.ensemble import (
        AdaBoostRegressor,
        GradientBoostingRegressor,
        RandomForestRegressor,
    )
    from sklearn.linear_model import Lasso, LinearRegression, Ridge
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.svm import SVR
    from sklearn.tree import DecisionTreeRegressor

    _MODEL_REGISTRY.update(
        {
            "linear_regression": LinearRegression,
            "ridge": Ridge,
            "lasso": Lasso,
            "decision_tree": DecisionTreeRegressor,
            "random_forest": RandomForestRegressor,
            "gradient_boosting": GradientBoostingRegressor,
            "adaboost": AdaBoostRegressor,
            "svm": SVR,
            "knn": KNeighborsRegressor,
        }
    )

    try:
        from sklearn.ensemble import HistGradientBoostingRegressor

        _MODEL_REGISTRY["hist_gradient_boosting"] = HistGradientBoostingRegressor
    except ImportError:
        pass


def list_architectures() -> list[str]:
    """Return sorted list of registered sklearn architecture names."""
    _populate_registry()
    return sorted(_MODEL_REGISTRY.keys())


def get_model_class(architecture: str) -> Any:
    """Look up an sklearn model class by architecture name.

    Args:
        architecture: Registered model name (e.g. ``"ridge"``).

    Returns:
        The sklearn estimator class.

    Raises:
        ValueError: If *architecture* is not registered.
    """
    _populate_registry()
    cls = _MODEL_REGISTRY.get(architecture)
    if cls is None:
        raise ValueError(
            f"Unknown architecture {architecture!r}. Registered: {list_architectures()}"
        )
    return cls


# ------------------------------------------------------------------
# Public entry point
# ------------------------------------------------------------------


def train(config: SklearnExperimentConfig) -> ExperimentResult:
    """Run a full sklearn experiment."""
    t0 = time.time()
    seed_all(config.experiment.seed)

    output_dir = Path(config.experiment.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Data ---
    df = load_dataframe(config.data.path)
    df = handle_missing(df, config.data.handle_missing)

    target = config.data.target
    if target not in df.columns:
        raise ValueError(
            f"Target column {target!r} not found. Available: {list(df.columns)}"
        )

    feature_cols = config.data.features or [c for c in df.columns if c != target]
    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Feature columns not found: {missing}")

    X = df[feature_cols].values.astype(np.float64)
    y = df[target].values.astype(np.float64)

    X_train, X_val, X_test, y_train, y_val, y_test = split(
        X,
        y,
        config.data.split.strategy,
        config.data.split.train,
        config.data.split.val,
        config.experiment.seed,
    )

    # --- Scaling ---
    X_train, X_val, X_test, scaler_params = scale(
        X_train,
        X_val,
        X_test,
        config.data.scaler,
    )

    scaler_path = output_dir / "scaler.json"
    scaler_path.write_text(
        json.dumps(
            {"method": config.data.scaler, "params": scaler_params},
            indent=2,
        ),
        encoding="utf-8",
    )

    # --- Model ---
    model_cls = get_model_class(config.model.architecture)

    model = model_cls(**config.model.params)
    logger.info(
        "Training %s with params %s",
        config.model.architecture,
        config.model.params,
    )
    model.fit(X_train, y_train)

    # --- Cross-validation ---
    cv_results: dict[str, Any] = {}
    cv_config = config.training.cross_validation
    if cv_config.enabled:
        from sklearn.model_selection import cross_val_score

        scores = cross_val_score(
            model_cls(**config.model.params),
            np.concatenate([X_train, X_val]),
            np.concatenate([y_train, y_val]),
            cv=cv_config.folds,
            scoring=cv_config.scoring,
        )
        cv_results = {
            "cv_mean": float(scores.mean()),
            "cv_std": float(scores.std()),
            "cv_scores": scores.tolist(),
        }
        logger.info(
            "CV %s: %.4f ± %.4f",
            cv_config.scoring,
            scores.mean(),
            scores.std(),
        )

    # --- Evaluate ---
    y_pred_test = model.predict(X_test)
    metrics = compute_metrics(y_test, y_pred_test, config.evaluation.metrics)
    metrics.update(cv_results)

    metrics_path = output_dir / "metrics.json"
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    logger.info(
        "Metrics: %s",
        {k: v for k, v in metrics.items() if isinstance(v, float)},
    )

    # --- Plots ---
    plot_dir = output_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    plot_paths = generate_plots(
        y_test,
        y_pred_test,
        model,
        feature_cols,
        config.evaluation.plots,
        plot_dir,
    )

    # --- Save model ---
    import joblib

    model_path = output_dir / "model.joblib"
    joblib.dump(model, model_path)

    config_path = output_dir / "model_config.json"
    config_path.write_text(
        json.dumps(
            {
                "architecture": config.model.architecture,
                "params": config.model.params,
                "features": feature_cols,
                "target": target,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    duration = time.time() - t0

    artifacts = {
        "model": str(model_path),
        "config": str(config_path),
        "scaler": str(scaler_path),
        "metrics": str(metrics_path),
    }
    for name, path in plot_paths.items():
        artifacts[f"plot_{name}"] = path

    return ExperimentResult(
        name=config.experiment.name,
        backend="sklearn",
        metrics={k: v for k, v in metrics.items() if isinstance(v, int | float)},
        artifacts=artifacts,
        training_history=[],
        duration_seconds=duration,
    )
