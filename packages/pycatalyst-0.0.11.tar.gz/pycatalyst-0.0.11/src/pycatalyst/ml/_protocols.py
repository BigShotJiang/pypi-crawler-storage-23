"""Protocol definitions for pycatalyst ML pluggable interfaces.

All protocols are ``@runtime_checkable`` so that ``isinstance()`` checks
work at runtime, following the same pattern as ``pyoptima.core.protocols``
and ``pycatalyst._protocols``.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

import numpy as np

from pycatalyst.ml.results import ExperimentResult


@runtime_checkable
class Engine(Protocol):
    """Protocol for ML training engines.

    Each backend (sklearn, pytorch, huggingface) provides an engine
    that converts a validated config into a trained model + results.
    """

    name: str

    def train(self, config: Any) -> ExperimentResult:
        """Run training with the given config.

        Args:
            config: Backend-specific Pydantic config object.

        Returns:
            ExperimentResult with metrics, artifacts, and history.
        """
        ...

    def is_available(self) -> bool:
        """Check whether this engine's dependencies are installed."""
        ...


@runtime_checkable
class ModelArtifact(Protocol):
    """Protocol for a trained model that supports prediction and persistence.

    Implementations include ``TorchModel``, sklearn estimators (via wrapper),
    and HuggingFace adapters.
    """

    def predict(self, data: np.ndarray) -> np.ndarray:
        """Run inference on input data.

        Args:
            data: Input features array.

        Returns:
            Model predictions.
        """
        ...

    def save(self, directory: str) -> dict[str, str]:
        """Persist model artifacts to *directory*.

        Args:
            directory: Target directory path.

        Returns:
            Mapping of artifact name to file path.
        """
        ...


@runtime_checkable
class Preprocessor(Protocol):
    """Protocol for data preprocessors (scalers, encoders).

    Follows the standard fit/transform/inverse_transform pattern
    from scikit-learn.
    """

    def fit(self, data: np.ndarray) -> Preprocessor:
        """Fit parameters from training data.

        Args:
            data: Training data array.

        Returns:
            self (for method chaining).
        """
        ...

    def transform(self, data: np.ndarray) -> np.ndarray:
        """Apply the fitted transformation.

        Args:
            data: Data to transform.

        Returns:
            Transformed data.
        """
        ...

    def inverse_transform(self, data: np.ndarray) -> np.ndarray:
        """Reverse the transformation.

        Args:
            data: Transformed data.

        Returns:
            Original-scale data.
        """
        ...
