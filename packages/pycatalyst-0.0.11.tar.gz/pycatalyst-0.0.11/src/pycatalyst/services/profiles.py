"""Environment setup profiles for workbench environments.

Profiles define reusable package installation sets that are applied
automatically when creating a new environment.  Built-in profiles live
in ``data/profiles/`` and user profiles in ``~/.pycatalyst/profiles/``.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Re-use the same env var pattern as the recipe loader.
_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::(-[^}]*|\?[^}]*))?\}")

_BUILTIN_DIR = Path(__file__).resolve().parent.parent / "data" / "profiles"
_USER_DIR = Path.home() / ".pycatalyst" / "profiles"


class EnvironmentProfile(BaseModel):
    """Reusable environment setup profile."""

    name: str = Field(description="Unique profile name")
    description: str = Field(default="", description="Human-readable description")
    backend: str = Field(default="venv", description="Backend type: venv or docker")
    packages: list[str] = Field(
        default_factory=list, description="Regular pip install specs"
    )
    editable_packages: list[str] = Field(
        default_factory=list,
        description="Local paths installed with -e",
    )


def list_profiles() -> list[EnvironmentProfile]:
    """Load and return all available profiles (built-in + user).

    User profiles override built-in profiles with the same name.
    """
    profiles: dict[str, EnvironmentProfile] = {}

    for directory in (_BUILTIN_DIR, _USER_DIR):
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("*.yaml")):
            profile = _load_profile(path)
            if profile is not None:
                profiles[profile.name] = profile

    return list(profiles.values())


def get_profile(name: str) -> EnvironmentProfile | None:
    """Look up a profile by name.

    User profiles take precedence over built-in profiles.
    """
    # Check user dir first (higher priority)
    for directory in (_USER_DIR, _BUILTIN_DIR):
        if not directory.is_dir():
            continue
        for path in directory.glob("*.yaml"):
            profile = _load_profile(path)
            if profile is not None and profile.name == name:
                return profile
    return None


def _load_profile(path: Path) -> EnvironmentProfile | None:
    """Load a single profile YAML file with env var substitution."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        logger.warning("Cannot read profile file: %s", path)
        return None

    resolved = _substitute_env_vars(raw)

    try:
        data = yaml.safe_load(resolved)
    except yaml.YAMLError:
        logger.warning("Invalid YAML in profile: %s", path)
        return None

    if not isinstance(data, dict):
        logger.warning("Profile must be a YAML mapping: %s", path)
        return None

    try:
        return EnvironmentProfile.model_validate(data)
    except Exception as exc:
        logger.warning("Invalid profile %s: %s", path, exc)
        return None


def _substitute_env_vars(content: str) -> str:
    """Replace ``${VAR}``, ``${VAR:-default}``, ``${VAR:?msg}`` patterns."""

    def _replacer(match: re.Match[str]) -> str:
        var_name = match.group(1)
        modifier = match.group(2)
        value = os.environ.get(var_name)

        if modifier is None:
            return value if value is not None else match.group(0)

        if modifier.startswith("-"):
            default = modifier[1:]
            return value if value is not None else default

        if modifier.startswith("?"):
            if value is None:
                logger.warning("Required env var '%s' not set in profile", var_name)
                return match.group(0)
            return value

        return match.group(0)

    return _ENV_PATTERN.sub(_replacer, content)
