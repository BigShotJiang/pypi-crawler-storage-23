"""Tier 2 backend — Docker container isolation via docker-py.

Requires the ``docker`` Python package (``pip install pycatalyst[sandbox]``)
and a running Docker daemon accessible via the default socket.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from typing import Any

from pycatalyst.services.backends.base import SessionHandle

logger = logging.getLogger(__name__)

_ALIVE_CACHE_TTL = 5.0  # seconds to cache container-running status

_DOCKER_CMD_MAP: dict[str, str] = {
    "bash": "bash",
    "sh": "sh",
    "zsh": "zsh",
    "fish": "fish",
    "python": "python3",
    "ipython": "python3 -m IPython",
}
"""Allowed commands mapped to their Docker equivalents."""


class DockerBackend:
    """Tier 2 backend: per-environment Docker container with exec-based sessions."""

    backend_type: str = "docker"

    def __init__(
        self,
        image: str = "python:3.13-slim",
        mem_limit: str = "512m",
    ) -> None:
        self._image = image
        self._mem_limit = mem_limit
        self._containers: dict[str, Any] = {}
        self._sessions: dict[str, SessionHandle] = {}
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            import docker

            self._client = docker.from_env()
        return self._client

    async def create(self) -> str:
        env_id = uuid.uuid4().hex[:12]

        def _run() -> Any:
            client = self._get_client()
            container = client.containers.run(
                self._image,
                command="sleep infinity",
                detach=True,
                tty=True,
                mem_limit=self._mem_limit,
                network_mode="bridge",
                name=f"pycatalyst-wb-{env_id}",
                labels={"pycatalyst.workbench": "true", "pycatalyst.env_id": env_id},
            )
            return container

        container = await asyncio.to_thread(_run)
        self._containers[env_id] = container
        logger.info(
            "Created Docker environment %s (container=%s)", env_id, container.short_id
        )
        return env_id

    async def destroy(self, env_id: str) -> None:
        container = self._containers.pop(env_id, None)
        if container is None:
            return

        for sid, handle in list(self._sessions.items()):
            if handle.env_id == env_id:
                handle.close()
                self._sessions.pop(sid, None)

        def _stop_remove() -> None:
            try:
                container.stop(timeout=5)
            except Exception:
                pass
            try:
                container.remove(force=True)
            except Exception:
                pass

        await asyncio.to_thread(_stop_remove)
        logger.info("Destroyed Docker environment %s", env_id)

    async def spawn_session(
        self,
        env_id: str,
        command: str,
        cols: int,
        rows: int,
    ) -> SessionHandle:
        container = self._containers.get(env_id)
        if container is None:
            raise ValueError(f"Unknown Docker environment: {env_id}")

        cmd = _DOCKER_CMD_MAP.get(command)
        if cmd is None:
            raise ValueError(
                f"Command {command!r} is not supported in Docker environments"
            )

        def _exec() -> tuple[Any, str]:
            client = self._get_client()
            exec_id = client.api.exec_create(
                container.id,
                cmd,
                tty=True,
                stdin=True,
                environment={"TERM": "xterm-256color"},
            )["Id"]
            sock = client.api.exec_start(exec_id, tty=True, socket=True)
            client.api.exec_resize(exec_id, height=rows, width=cols)
            return sock, exec_id

        sock, exec_id = await asyncio.to_thread(_exec)
        sock_fd = sock.fileno()

        import fcntl

        flags = fcntl.fcntl(sock_fd, fcntl.F_GETFL)
        fcntl.fcntl(sock_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        session_id = uuid.uuid4().hex[:12]
        closed = False
        # Cache container-running status to avoid HTTP roundtrip per call.
        alive_cache: dict[str, Any] = {"value": True, "ts": time.monotonic()}

        def _write(data: bytes) -> None:
            nonlocal closed
            if closed:
                return
            try:
                os.write(sock_fd, data)
            except OSError:
                pass

        def _resize(c: int, r: int) -> None:
            nonlocal closed
            if closed:
                return
            try:
                self._get_client().api.exec_resize(exec_id, height=r, width=c)
            except Exception:
                pass

        def _close() -> None:
            nonlocal closed
            if closed:
                return
            closed = True
            try:
                sock.close()
            except Exception:
                pass

        def _is_alive() -> bool:
            if closed:
                return False
            now = time.monotonic()
            if now - alive_cache["ts"] < _ALIVE_CACHE_TTL:
                return alive_cache["value"]
            try:
                container.reload()
                result = container.status == "running"
            except Exception:
                result = False
            alive_cache["value"] = result
            alive_cache["ts"] = now
            return result

        handle = SessionHandle(
            session_id=session_id,
            env_id=env_id,
            command=command,
            backend_type="docker",
            read_fd=sock_fd,
            write=_write,
            resize=_resize,
            close=_close,
            is_alive=_is_alive,
            pid=0,
            cols=cols,
            rows=rows,
            _extra={"socket": sock, "container": container, "exec_id": exec_id},
        )

        self._sessions[session_id] = handle
        logger.info(
            "Spawned Docker session %s (cmd=%s, env=%s)",
            session_id,
            command,
            env_id,
        )
        return handle

    async def install_packages(
        self,
        env_id: str,
        packages: list[str],
        *,
        editable: bool = False,
        upgrade: bool = False,
    ) -> dict[str, Any]:
        """Install packages into the Docker environment via pip.

        Args:
            env_id: Environment identifier.
            packages: Package specs (names, paths, or URLs).
            editable: Use ``-e`` flag for editable installs.
            upgrade: Use ``--upgrade`` flag.

        Returns:
            Dict with ``success``, ``output``, and ``packages`` keys.
        """
        container = self._containers.get(env_id)
        if container is None:
            raise ValueError(f"Unknown Docker environment: {env_id}")

        cmd_parts = ["pip", "install"]
        if editable:
            cmd_parts.append("-e")
        if upgrade:
            cmd_parts.append("--upgrade")
        cmd_parts.extend(packages)
        cmd = " ".join(cmd_parts)

        def _run() -> tuple[int, str]:
            exit_code, output = container.exec_run(cmd, tty=False)
            return exit_code, output.decode(errors="replace") if output else ""

        exit_code, output = await asyncio.to_thread(_run)
        success = exit_code == 0

        if success:
            logger.info("Installed packages in Docker %s: %s", env_id, packages)
        else:
            logger.warning("pip install failed in Docker %s: %s", env_id, output[:200])

        installed = await self.list_packages(env_id)
        return {"success": success, "output": output, "packages": installed}

    async def uninstall_packages(
        self,
        env_id: str,
        packages: list[str],
    ) -> dict[str, Any]:
        """Uninstall packages from the Docker environment via pip.

        Args:
            env_id: Environment identifier.
            packages: Package names to remove.

        Returns:
            Dict with ``success``, ``output``, and ``packages`` keys.
        """
        container = self._containers.get(env_id)
        if container is None:
            raise ValueError(f"Unknown Docker environment: {env_id}")

        cmd = "pip uninstall -y " + " ".join(packages)

        def _run() -> tuple[int, str]:
            exit_code, output = container.exec_run(cmd, tty=False)
            return exit_code, output.decode(errors="replace") if output else ""

        exit_code, output = await asyncio.to_thread(_run)
        success = exit_code == 0

        if success:
            logger.info("Uninstalled packages from Docker %s: %s", env_id, packages)
        else:
            logger.warning(
                "pip uninstall failed in Docker %s: %s", env_id, output[:200]
            )

        remaining = await self.list_packages(env_id)
        return {"success": success, "output": output, "packages": remaining}

    async def list_packages(self, env_id: str) -> list[dict]:
        container = self._containers.get(env_id)
        if container is None:
            raise ValueError(f"Unknown Docker environment: {env_id}")

        def _pip_list() -> list[dict]:
            try:
                exit_code, output = container.exec_run(
                    "pip list --format=json",
                    tty=False,
                )
                if exit_code != 0:
                    return []
                return json.loads(output.decode())
            except Exception:
                return []

        return await asyncio.to_thread(_pip_list)

    def get_session(self, session_id: str) -> SessionHandle | None:
        handle = self._sessions.get(session_id)
        if handle and not handle.is_alive():
            self._sessions.pop(session_id, None)
            return None
        return handle

    def remove_session(self, session_id: str) -> bool:
        handle = self._sessions.pop(session_id, None)
        if handle is None:
            return False
        handle.close()
        return True

    def has_env(self, env_id: str) -> bool:
        return env_id in self._containers

    def env_session_count(self, env_id: str) -> int:
        return sum(1 for h in self._sessions.values() if h.env_id == env_id)

    def list_sessions(self) -> list[SessionHandle]:
        """Return all active session handles."""
        return list(self._sessions.values())

    def shutdown(self) -> None:
        for handle in self._sessions.values():
            handle.close()
        self._sessions.clear()

        for _env_id, container in list(self._containers.items()):
            try:
                container.stop(timeout=5)
            except Exception:
                pass
            try:
                container.remove(force=True)
            except Exception:
                pass
        self._containers.clear()
        logger.info("DockerBackend shut down")

    async def connect_to_network(self, env_id: str, network_name: str) -> None:
        """Connect the workbench container to a Docker network.

        Idempotent — silently succeeds if already connected.
        """
        container = self._containers.get(env_id)
        if container is None:
            logger.debug("No container for env %s — skip network connect", env_id)
            return

        def _connect() -> None:
            import docker.errors

            try:
                client = self._get_client()
                nets = client.networks.list(names=[network_name])
                if not nets:
                    logger.debug("Network %s not found — skip connect", network_name)
                    return
                nets[0].connect(container)
            except docker.errors.APIError as exc:
                # Already connected is fine
                if "already exists" in str(exc).lower():
                    return
                logger.warning(
                    "Failed to connect env %s to network %s: %s",
                    env_id,
                    network_name,
                    exc,
                )

        await asyncio.to_thread(_connect)

    @classmethod
    def is_available(cls) -> bool:
        try:
            import docker

            docker.from_env().ping()
            return True
        except Exception:
            return False
