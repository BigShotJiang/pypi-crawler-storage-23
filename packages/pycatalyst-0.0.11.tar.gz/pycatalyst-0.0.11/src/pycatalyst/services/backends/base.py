"""Protocol and shared types for workbench environment backends."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


class ScrollbackBuffer:
    """Fixed-capacity ring buffer that retains the most recent terminal output.

    Used to replay scrollback when a WebSocket client reconnects to an
    existing PTY session.  The buffer is a pre-allocated ``bytearray``
    so writes never allocate memory beyond the initial capacity.
    """

    __slots__ = ("_buf", "_capacity", "_pos", "_full")

    def __init__(self, capacity: int = 131_072) -> None:
        self._capacity = capacity
        self._buf = bytearray(capacity)
        self._pos = 0
        self._full = False

    def write(self, data: bytes) -> None:
        """Append *data* to the ring buffer, overwriting oldest bytes."""
        if self._capacity == 0 or not data:
            return

        n = len(data)
        if n >= self._capacity:
            # Only the tail fits — overwrite the entire buffer.
            self._buf[:] = data[-self._capacity :]
            self._pos = 0
            self._full = True
            return

        end = self._pos + n
        if end <= self._capacity:
            self._buf[self._pos : end] = data
        else:
            first = self._capacity - self._pos
            self._buf[self._pos :] = data[:first]
            self._buf[: n - first] = data[first:]

        self._pos = end % self._capacity
        if end >= self._capacity:
            self._full = True

    def read(self) -> bytes:
        """Return buffered bytes in chronological order."""
        if self._capacity == 0:
            return b""
        if not self._full:
            return bytes(self._buf[: self._pos])
        return bytes(self._buf[self._pos :] + self._buf[: self._pos])

    def __len__(self) -> int:
        """Number of bytes currently stored."""
        if self._full:
            return self._capacity
        return self._pos


@dataclass
class SessionHandle:
    """Unified handle over a PTY fd or Docker exec socket.

    The WebSocket bridge reads from ``read_fd`` and writes via ``write()``,
    regardless of the underlying backend.
    """

    session_id: str
    env_id: str
    command: str
    backend_type: str
    read_fd: int
    write: Callable[[bytes], None]
    resize: Callable[[int, int], None]
    close: Callable[[], None]
    is_alive: Callable[[], bool]
    owner: str = ""
    pid: int = 0
    cols: int = 80
    rows: int = 24
    last_activity: float = field(default_factory=time.monotonic)
    close_reason: str | None = None
    _extra: dict[str, Any] = field(default_factory=dict)

    def touch(self) -> None:
        """Update the last activity timestamp."""
        self.last_activity = time.monotonic()


@runtime_checkable
class EnvironmentBackend(Protocol):
    """Contract for an isolated environment that can host terminal sessions."""

    backend_type: str

    async def create(self) -> str:
        """Create an isolated environment. Returns env_id."""
        ...

    async def destroy(self, env_id: str) -> None:
        """Destroy an environment and all of its resources."""
        ...

    async def spawn_session(
        self,
        env_id: str,
        command: str,
        cols: int,
        rows: int,
    ) -> SessionHandle:
        """Spawn a terminal session inside the environment."""
        ...

    async def list_packages(self, env_id: str) -> list[dict]:
        """List installed Python packages in the environment."""
        ...

    async def install_packages(
        self,
        env_id: str,
        packages: list[str],
        *,
        editable: bool = False,
        upgrade: bool = False,
    ) -> dict[str, Any]:
        """Install packages into the environment.

        Returns:
            Dict with ``success``, ``output``, and ``packages`` keys.
        """
        ...

    async def uninstall_packages(
        self,
        env_id: str,
        packages: list[str],
    ) -> dict[str, Any]:
        """Uninstall packages from the environment.

        Returns:
            Dict with ``success``, ``output``, and ``packages`` keys.
        """
        ...

    def get_session(self, session_id: str) -> SessionHandle | None:
        """Look up a session by ID. Returns None if not found or dead."""
        ...

    def remove_session(self, session_id: str) -> bool:
        """Kill and remove a session. Returns True if it existed."""
        ...

    def env_session_count(self, env_id: str) -> int:
        """Return the number of active sessions in an environment."""
        ...

    def has_env(self, env_id: str) -> bool:
        """Check whether an environment exists in this backend."""
        ...

    def list_sessions(self) -> list[SessionHandle]:
        """Return all active session handles."""
        ...

    def shutdown(self) -> None:
        """Shut down the backend, closing all sessions and cleaning up."""
        ...

    @classmethod
    def is_available(cls) -> bool:
        """Check if this backend can be used on the current system."""
        ...
