"""Workbench orchestrator — routes requests to the correct environment backend.

Tracks all environments and their sessions, enforces limits, and delegates
to ``VenvBackend`` / ``DockerBackend`` based on ``backend_type``.

All mutating operations require an ``owner`` (username) so that environments
and sessions are scoped per-user.  When auth is disabled the API layer passes
``"anonymous"`` which effectively disables isolation.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pycatalyst.services.backends.base import EnvironmentBackend, SessionHandle
from pycatalyst.services.service_containers import (
    ServiceConfig,
    ServiceContainerManager,
    ServiceInfo,
)

logger = logging.getLogger(__name__)


@dataclass
class EnvironmentInfo:
    """Metadata for a workbench environment."""

    env_id: str
    backend_type: str
    owner: str = ""
    created_at: float = field(default_factory=time.time)

    def to_dict(self, session_count: int = 0) -> dict[str, Any]:
        """Serialise to a dict suitable for API responses."""
        return {
            "env_id": self.env_id,
            "backend": self.backend_type,
            "created_at": self.created_at,
            "session_count": session_count,
        }


class WorkbenchManager:
    """Central orchestrator for all workbench environments and sessions."""

    def __init__(
        self,
        *,
        venv_base_dir: str | None = None,
        max_environments: int = 5,
        max_venvs: int | None = None,
        max_containers: int | None = None,
        max_sessions_per_env: int = 10,
        session_idle_timeout: int = 1800,
    ) -> None:
        from pycatalyst.services.backends.venv_backend import VenvBackend

        self._backends: dict[str, EnvironmentBackend] = {}
        self._environments: dict[str, EnvironmentInfo] = {}
        self._env_backend_map: dict[str, str] = {}
        self._max_environments = max_environments
        self._max_env_limits: dict[str, int] = {
            "venv": max_venvs if max_venvs is not None else max_environments,
            "docker": max_containers
            if max_containers is not None
            else max_environments,
        }
        self._max_sessions_per_env = max_sessions_per_env
        self._session_idle_timeout = session_idle_timeout

        if venv_base_dir is None:
            from pycatalyst.config.workbench import get_workbench_venv_dir

            venv_base_dir = get_workbench_venv_dir()

        self._backends["venv"] = VenvBackend(base_dir=venv_base_dir)
        self._service_manager: ServiceContainerManager | None = None

        self._try_register_docker()

    # ------------------------------------------------------------------
    # Backend registration
    # ------------------------------------------------------------------

    def _try_register_docker(self) -> None:
        """Register the Docker backend and service manager if the daemon is reachable."""
        try:
            from pycatalyst.services.backends.docker_backend import DockerBackend

            if DockerBackend.is_available():
                from pycatalyst.config.workbench import (
                    get_workbench_docker_image,
                    get_workbench_docker_mem_limit,
                )

                backend = DockerBackend(
                    image=get_workbench_docker_image(),
                    mem_limit=get_workbench_docker_mem_limit(),
                )
                self._backends["docker"] = backend
                logger.info("DockerBackend registered (Docker available)")

                # Create service container manager with the same Docker client
                try:
                    client = backend._get_client()
                    self._service_manager = ServiceContainerManager(client)
                    logger.info("ServiceContainerManager registered")
                except Exception:
                    logger.warning("ServiceContainerManager could not be created")
            else:
                logger.info("DockerBackend not registered (Docker unavailable)")
        except ImportError:
            logger.info("DockerBackend not registered (docker package not installed)")

    def capabilities(self) -> dict[str, bool]:
        """Return which backends are available (based on currently registered backends only)."""
        return {
            "venv": "venv" in self._backends,
            "docker": "docker" in self._backends,
            "services": self._service_manager is not None,
        }

    def workbench_health(self) -> str:
        """Return workbench readiness for health checks: ok, degraded, or unavailable."""
        venv = self._backends.get("venv")
        if not venv or not hasattr(venv, "_base_dir"):
            return "unavailable"
        base = getattr(venv, "_base_dir", None)
        if base is None:
            return "unavailable"
        path = Path(base) if not isinstance(base, Path) else base
        if not path.exists():
            try:
                path.mkdir(parents=True, exist_ok=True)
            except OSError:
                return "unavailable"
        if not os.access(path, os.W_OK):
            return "unavailable"
        docker_backend = self._backends.get("docker")
        if docker_backend is not None:
            try:
                client = docker_backend._get_client()
                client.ping()
            except Exception:
                return "degraded"
        return "ok"

    # ------------------------------------------------------------------
    # Environment lifecycle
    # ------------------------------------------------------------------

    async def create_environment(
        self,
        backend_type: str = "venv",
        *,
        owner: str = "",
        profile: str | None = None,
    ) -> EnvironmentInfo:
        """Create a new isolated environment owned by *owner*.

        When *profile* is given, the matching profile's packages are
        installed automatically after the environment is created.  Install
        failures are logged but do not prevent the environment from being
        returned.
        """
        backend = self._backends.get(backend_type)
        if backend is None:
            raise ValueError(f"Backend '{backend_type}' is not available")

        limit = self._max_env_limits.get(backend_type, self._max_environments)
        active = sum(
            1
            for info in self._environments.values()
            if info.backend_type == backend_type and info.owner == owner
        )
        if active >= limit:
            raise RuntimeError(f"Maximum {backend_type} environments ({limit}) reached")

        env_id = await backend.create()
        info = EnvironmentInfo(
            env_id=env_id,
            backend_type=backend_type,
            owner=owner,
        )
        self._environments[env_id] = info
        self._env_backend_map[env_id] = backend_type
        logger.info("Created %s environment %s (owner=%s)", backend_type, env_id, owner)

        if profile:
            await self._apply_profile(env_id, profile, backend)

        return info

    async def _apply_profile(
        self,
        env_id: str,
        profile_name: str,
        backend: EnvironmentBackend,
    ) -> None:
        """Install packages defined by a profile into the environment."""
        from pycatalyst.services.profiles import get_profile

        prof = get_profile(profile_name)
        if prof is None:
            logger.warning("Profile '%s' not found — skipping", profile_name)
            return

        if prof.packages:
            try:
                result = await backend.install_packages(env_id, prof.packages)
                if not result["success"]:
                    logger.warning(
                        "Profile '%s' package install partial failure: %s",
                        profile_name,
                        result["output"][:200],
                    )
            except Exception:
                logger.exception(
                    "Failed to install profile '%s' packages in %s",
                    profile_name,
                    env_id,
                )

        if prof.editable_packages:
            try:
                result = await backend.install_packages(
                    env_id, prof.editable_packages, editable=True
                )
                if not result["success"]:
                    logger.warning(
                        "Profile '%s' editable install partial failure: %s",
                        profile_name,
                        result["output"][:200],
                    )
            except Exception:
                logger.exception(
                    "Failed to install profile '%s' editable packages in %s",
                    profile_name,
                    env_id,
                )

    async def destroy_environment(self, env_id: str, *, owner: str = "") -> None:
        """Destroy an environment.  Raises ValueError if not found or not owned."""
        info = self._environments.get(env_id)
        if info is None:
            raise ValueError(f"Unknown environment: {env_id}")
        if owner and info.owner != owner:
            raise ValueError(f"Unknown environment: {env_id}")

        # Clean up service containers first (best-effort)
        if self._service_manager is not None:
            try:
                await self._service_manager.destroy_all_for_env(env_id)
            except Exception:
                logger.warning("Failed to clean up services for env %s", env_id)

        self._environments.pop(env_id, None)
        backend_type = self._env_backend_map.pop(env_id, info.backend_type)
        backend = self._backends.get(backend_type)
        if backend:
            await backend.destroy(env_id)
        logger.info("Destroyed environment %s", env_id)

    def list_environments(self, *, owner: str = "") -> list[dict[str, Any]]:
        """List environments visible to *owner*."""
        result = []
        for info in self._environments.values():
            if owner and info.owner != owner:
                continue
            backend = self._backends.get(info.backend_type)
            count = backend.env_session_count(info.env_id) if backend else 0
            result.append(info.to_dict(session_count=count))
        return result

    def get_environment(
        self,
        env_id: str,
        *,
        owner: str = "",
    ) -> EnvironmentInfo | None:
        """Return environment info, or None if not found / not owned."""
        info = self._environments.get(env_id)
        if info is None:
            return None
        if owner and info.owner != owner:
            return None
        return info

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    async def spawn_session(
        self,
        env_id: str,
        command: str,
        cols: int = 80,
        rows: int = 24,
        *,
        owner: str = "",
    ) -> SessionHandle:
        """Spawn a terminal session inside an environment owned by *owner*."""
        info = self._environments.get(env_id)
        if info is None:
            raise ValueError(f"Unknown environment: {env_id}")
        if owner and info.owner != owner:
            raise ValueError(f"Unknown environment: {env_id}")

        backend = self._backends.get(info.backend_type)
        if backend is None:
            raise RuntimeError(f"Backend '{info.backend_type}' is not available")

        count = backend.env_session_count(env_id)
        if count >= self._max_sessions_per_env:
            raise RuntimeError(
                f"Maximum sessions per environment ({self._max_sessions_per_env}) reached"
            )

        handle = await backend.spawn_session(env_id, command, cols, rows)
        handle.owner = owner
        return handle

    def get_session(
        self,
        session_id: str,
        *,
        owner: str = "",
    ) -> SessionHandle | None:
        """Look up a session by ID, returning None if not found or not owned."""
        for backend in self._backends.values():
            handle = backend.get_session(session_id)
            if handle is not None:
                if owner and handle.owner != owner:
                    return None
                return handle
        return None

    def kill_session(self, session_id: str, *, owner: str = "") -> bool:
        """Kill a session.  Returns False if not found or not owned."""
        handle = self.get_session(session_id)
        if handle is None:
            return False
        if owner and handle.owner != owner:
            return False
        for backend in self._backends.values():
            if backend.remove_session(session_id):
                return True
        return False

    def list_sessions(
        self,
        env_id: str | None = None,
        *,
        owner: str = "",
    ) -> list[dict[str, Any]]:
        """List sessions, optionally filtered by environment and owner."""
        result = []
        for backend in self._backends.values():
            for handle in backend.list_sessions():
                if env_id and handle.env_id != env_id:
                    continue
                if owner and handle.owner != owner:
                    continue
                result.append(
                    {
                        "session_id": handle.session_id,
                        "env_id": handle.env_id,
                        "command": handle.command,
                        "backend_type": handle.backend_type,
                        "pid": handle.pid,
                        "cols": handle.cols,
                        "rows": handle.rows,
                        "alive": handle.is_alive(),
                    }
                )
        return result

    async def list_packages(
        self,
        env_id: str,
        *,
        owner: str = "",
    ) -> list[dict]:
        """List Python packages in an environment owned by *owner*."""
        info = self._environments.get(env_id)
        if info is None:
            raise ValueError(f"Unknown environment: {env_id}")
        if owner and info.owner != owner:
            raise ValueError(f"Unknown environment: {env_id}")

        backend = self._backends.get(info.backend_type)
        if backend is None:
            return []

        return await backend.list_packages(env_id)

    async def install_packages(
        self,
        env_id: str,
        packages: list[str],
        *,
        editable: bool = False,
        upgrade: bool = False,
        owner: str = "",
    ) -> dict[str, Any]:
        """Install packages into an environment owned by *owner*."""
        info = self._environments.get(env_id)
        if info is None:
            raise ValueError(f"Unknown environment: {env_id}")
        if owner and info.owner != owner:
            raise ValueError(f"Unknown environment: {env_id}")

        backend = self._backends.get(info.backend_type)
        if backend is None:
            raise RuntimeError(f"Backend '{info.backend_type}' is not available")

        return await backend.install_packages(
            env_id, packages, editable=editable, upgrade=upgrade
        )

    async def uninstall_packages(
        self,
        env_id: str,
        packages: list[str],
        *,
        owner: str = "",
    ) -> dict[str, Any]:
        """Uninstall packages from an environment owned by *owner*."""
        info = self._environments.get(env_id)
        if info is None:
            raise ValueError(f"Unknown environment: {env_id}")
        if owner and info.owner != owner:
            raise ValueError(f"Unknown environment: {env_id}")

        backend = self._backends.get(info.backend_type)
        if backend is None:
            raise RuntimeError(f"Backend '{info.backend_type}' is not available")

        return await backend.uninstall_packages(env_id, packages)

    # ------------------------------------------------------------------
    # Service containers
    # ------------------------------------------------------------------

    async def create_service(
        self,
        env_id: str,
        config: ServiceConfig,
        *,
        owner: str = "",
    ) -> ServiceInfo:
        """Create a database service for an environment owned by *owner*."""
        info = self._environments.get(env_id)
        if info is None:
            raise ValueError(f"Unknown environment: {env_id}")
        if owner and info.owner != owner:
            raise ValueError(f"Unknown environment: {env_id}")
        if self._service_manager is None:
            raise RuntimeError("Service containers are not available (Docker required)")

        svc = await self._service_manager.create_service(env_id, config)

        # Connect workbench Docker container to the service network
        if info.backend_type == "docker":
            docker_backend = self._backends.get("docker")
            if docker_backend is not None and hasattr(
                docker_backend, "connect_to_network"
            ):
                net_name = f"pycatalyst-net-{env_id}"
                try:
                    await docker_backend.connect_to_network(env_id, net_name)
                except Exception:
                    logger.warning(
                        "Could not connect workbench container to service network"
                    )

        return svc

    async def destroy_service(
        self,
        service_id: str,
        *,
        owner: str = "",
    ) -> None:
        """Destroy a database service."""
        if self._service_manager is None:
            raise RuntimeError("Service containers are not available")

        # Verify ownership via the service's env_id
        svc = self._service_manager.get_service(service_id)
        if svc is None:
            raise ValueError(f"Unknown service: {service_id}")
        env_info = self._environments.get(svc.env_id)
        if owner and (env_info is None or env_info.owner != owner):
            raise ValueError(f"Unknown service: {service_id}")

        await self._service_manager.destroy_service(service_id)

    def list_services(
        self,
        env_id: str | None = None,
        *,
        owner: str = "",
    ) -> list[dict]:
        """List database services, optionally filtered by environment."""
        if self._service_manager is None:
            return []

        services = self._service_manager.list_services(env_id)

        # Filter by owner via env_id ownership
        if owner:
            services = [
                s
                for s in services
                if self._environments.get(s.env_id)
                and self._environments[s.env_id].owner == owner
            ]

        return [s.to_dict() for s in services]

    def get_service_status(
        self,
        service_id: str,
        *,
        owner: str = "",
    ) -> dict | None:
        """Get a service's status, refreshing from Docker first."""
        if self._service_manager is None:
            return None

        svc = self._service_manager.get_service(service_id)
        if svc is None:
            return None

        # Ownership check
        env_info = self._environments.get(svc.env_id)
        if owner and (env_info is None or env_info.owner != owner):
            return None

        self._service_manager.refresh_status(service_id)
        return svc.to_dict()

    # ------------------------------------------------------------------
    # Idle reaper
    # ------------------------------------------------------------------

    def reap_idle_sessions(self) -> int:
        """Close sessions that have been idle longer than the timeout.

        Returns the number of sessions reaped.
        """
        if self._session_idle_timeout <= 0:
            return 0

        now = time.monotonic()
        reaped = 0
        for backend in self._backends.values():
            for handle in backend.list_sessions():
                idle = now - handle.last_activity
                if idle >= self._session_idle_timeout:
                    logger.info(
                        "Reaping idle session %s (idle %.0fs)",
                        handle.session_id,
                        idle,
                    )
                    handle.close_reason = "Idle timeout"
                    backend.remove_session(handle.session_id)
                    reaped += 1
        return reaped

    async def run_reaper(self) -> None:
        """Background coroutine that periodically reaps idle sessions.

        Runs every 60 seconds.  Meant to be launched as a task from the
        FastAPI lifespan context and cancelled on shutdown.
        """
        interval = 60.0
        while True:
            await asyncio.sleep(interval)
            try:
                count = self.reap_idle_sessions()
                if count:
                    logger.info("Idle reaper cleaned up %d session(s)", count)
            except Exception:
                logger.exception("Error in idle reaper")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def shutdown(self) -> None:
        """Shut down all backends and service containers."""
        # Shut down service containers first
        if self._service_manager is not None:
            try:
                self._service_manager.shutdown()
            except Exception:
                logger.warning("Error shutting down service containers")

        for backend in self._backends.values():
            backend.shutdown()
        self._environments.clear()
        self._env_backend_map.clear()
        logger.info("WorkbenchManager shut down")


def _create_manager() -> WorkbenchManager:
    """Create the module-level singleton with values from config."""
    from pycatalyst.config.workbench import (
        get_workbench_max_containers,
        get_workbench_max_environments,
        get_workbench_max_sessions,
        get_workbench_max_venvs,
        get_workbench_session_idle_timeout,
        get_workbench_venv_dir,
    )

    return WorkbenchManager(
        venv_base_dir=get_workbench_venv_dir(),
        max_environments=get_workbench_max_environments(),
        max_venvs=get_workbench_max_venvs(),
        max_containers=get_workbench_max_containers(),
        max_sessions_per_env=get_workbench_max_sessions(),
        session_idle_timeout=get_workbench_session_idle_timeout(),
    )


workbench_manager = _create_manager()
