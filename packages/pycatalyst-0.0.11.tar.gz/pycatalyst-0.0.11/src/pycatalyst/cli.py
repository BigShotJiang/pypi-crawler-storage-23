"""CLI entry-point for PyCatalyst: ``pycatalyst generate | infer | recipe``."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main() -> int:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="PyCatalyst — data generation and testing platform",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command", required=True)

    # --- generate ----------------------------------------------------------
    gen_p = sub.add_parser("generate", help="Generate data from a recipe or schema")
    gen_p.add_argument(
        "--recipe", "-r", default=None, help="Path to a recipe YAML file"
    )
    gen_p.add_argument(
        "--schema", "-s", default=None, help="Path to a JSON Schema file"
    )
    gen_p.add_argument(
        "-n", "--count", type=int, default=10, help="Number of records (default: 10)"
    )
    gen_p.add_argument(
        "--seed", type=int, default=None, help="Random seed for reproducibility"
    )
    gen_p.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output file path (default: stdout as JSON)",
    )

    # --- infer -------------------------------------------------------------
    infer_p = sub.add_parser("infer", help="Infer schema from sample data")
    infer_p.add_argument("--input", "-i", required=True, help="Input data file")
    infer_p.add_argument(
        "-o", "--output", default=None, help="Output schema file (default: stdout)"
    )
    infer_p.add_argument("--name", default=None, help="Schema name override")

    # --- recipe ------------------------------------------------------------
    recipe_p = sub.add_parser("recipe", help="Recipe management")
    recipe_sub = recipe_p.add_subparsers(dest="recipe_command", required=True)

    recipe_sub.add_parser("list", help="List built-in recipe templates")
    val_p = recipe_sub.add_parser("validate", help="Validate a recipe file")
    val_p.add_argument("path", help="Path to recipe YAML file")

    # --- api ---------------------------------------------------------------
    api_p = sub.add_parser("api", help="Start the API server")
    api_p.add_argument("--host", default="0.0.0.0")
    api_p.add_argument("--port", type=int, default=8006)
    api_p.add_argument("--reload", action="store_true", default=True)
    api_p.add_argument("--no-reload", dest="reload", action="store_false")

    # --- ui ----------------------------------------------------------------
    ui_p = sub.add_parser("ui", help="UI commands")
    ui_sub = ui_p.add_subparsers(dest="ui_command", required=True)

    serve_p = ui_sub.add_parser("serve", help="Serve built UI")
    serve_p.add_argument("--api-url", default=None)
    serve_p.add_argument("--host", default="127.0.0.1")
    serve_p.add_argument("--port", type=int, default=3006)

    dev_p = ui_sub.add_parser("dev", help="Run UI dev server")
    dev_p.add_argument("--api-url", default=None)
    dev_p.add_argument("--port", type=int, default=3006)

    ui_sub.add_parser("build", help="Build UI for production")

    # --- db ----------------------------------------------------------------
    sub.add_parser(
        "db",
        help="Database management commands",
        description="Manage PyCatalyst database: init, upgrade, downgrade, seed, truncate",
    )

    # --- train -------------------------------------------------------------
    train_p = sub.add_parser(
        "train", help="Train an ML model from an experiment config"
    )
    train_p.add_argument(
        "--config", "-c", required=True, help="Path to experiment YAML config"
    )

    # --- predict -----------------------------------------------------------
    predict_p = sub.add_parser("predict", help="Run inference with a trained model")
    predict_p.add_argument(
        "--model-dir",
        "-m",
        required=True,
        help="Directory containing model weights and config",
    )
    predict_p.add_argument(
        "--input",
        "-i",
        required=True,
        help="Input data file (CSV) for prediction",
    )
    predict_p.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output file for predictions (default: stdout)",
    )

    args, remaining = parser.parse_known_args()

    if args.command == "generate":
        return _cmd_generate(args)
    if args.command == "infer":
        return _cmd_infer(args)
    if args.command == "recipe":
        return _cmd_recipe(args)
    if args.command == "api":
        return _cmd_api(args)
    if args.command == "ui":
        return _cmd_ui(args)
    if args.command == "db":
        return _run_db(remaining)
    if args.command == "train":
        return _cmd_train(args)
    if args.command == "predict":
        return _cmd_predict(args)

    parser.print_help()
    return 1


def _run_db(remaining: list[str]) -> int:
    """Delegate to db CLI subcommands."""
    try:
        from pycatalyst.db.cli import main as db_main
    except ImportError as e:
        print(f"Database CLI not available: {e}", file=sys.stderr)
        return 1
    sys.argv = ["pycatalyst db", *remaining]
    return db_main()


def _cmd_generate(args: argparse.Namespace) -> int:
    """Handle the generate command."""
    if args.recipe:
        from pycatalyst.recipes.runner import RecipeRunner

        runner = RecipeRunner()
        gen_result, sink_result = runner.run_file(args.recipe)

        if args.output:
            from pycatalyst.sinks.file import FileSink

            sink = FileSink(args.output)
            sink.send(list(gen_result.records), {})
            print(f"Generated {gen_result.count} records -> {args.output}")
        else:
            print(json.dumps(list(gen_result.records), indent=2, default=str))
        return 0

    if args.schema:
        from pycatalyst.generators.engine import GenerationEngine
        from pycatalyst.schema.json_schema import from_json_schema

        schema_path = Path(args.schema)
        schema_data = json.loads(schema_path.read_text(encoding="utf-8"))
        schema = from_json_schema(schema_data, name=schema_path.stem)

        engine = GenerationEngine()
        result = engine.generate(schema, count=args.count, seed=args.seed)

        if args.output:
            from pycatalyst.sinks.file import FileSink

            sink = FileSink(args.output)
            sink.send(list(result.records), {})
            print(f"Generated {result.count} records -> {args.output}")
        else:
            print(json.dumps(list(result.records), indent=2, default=str))
        return 0

    print("Error: --recipe or --schema is required", file=sys.stderr)
    return 1


def _cmd_infer(args: argparse.Namespace) -> int:
    """Handle the infer command."""
    import yaml

    from pycatalyst.schema.inferrer import infer_from_file

    schema = infer_from_file(args.input, name=args.name)

    # Convert to a serializable dict
    schema_dict = _schema_to_dict(schema)

    if args.output:
        output_path = Path(args.output)
        suffix = output_path.suffix.lower()
        if suffix == ".json":
            output_path.write_text(json.dumps(schema_dict, indent=2), encoding="utf-8")
        else:
            output_path.write_text(
                yaml.dump(schema_dict, default_flow_style=False, sort_keys=False),
                encoding="utf-8",
            )
        print(f"Inferred schema -> {args.output}")
    else:
        print(yaml.dump(schema_dict, default_flow_style=False, sort_keys=False))
    return 0


def _cmd_recipe(args: argparse.Namespace) -> int:
    """Handle recipe subcommands."""
    if args.recipe_command == "list":
        return _cmd_recipe_list()
    if args.recipe_command == "validate":
        return _cmd_recipe_validate(args.path)
    return 1


def _cmd_recipe_list() -> int:
    """List built-in recipe templates."""
    templates_dir = Path(__file__).parent / "data" / "templates" / "recipes"
    if not templates_dir.exists():
        print("No built-in recipes found.")
        return 0

    recipes = sorted(templates_dir.glob("*.yaml"))
    if not recipes:
        print("No built-in recipes found.")
        return 0

    print("Built-in recipe templates:")
    for recipe_path in recipes:
        print(f"  - {recipe_path.stem}")
    return 0


def _cmd_recipe_validate(path: str) -> int:
    """Validate a recipe file."""
    from pycatalyst.recipes.loader import load_recipe

    try:
        config = load_recipe(path)
        print(f"Recipe '{config.name}' is valid.")
        print(f"  Fields: {len(config.schema_.fields)}")
        print(f"  Count: {config.generation.count}")
        print(f"  Sink: {config.sink.type}")
        return 0
    except Exception as exc:
        print(f"Validation failed: {exc}", file=sys.stderr)
        return 1


def _cmd_api(args: argparse.Namespace) -> int:
    """Start the API server."""
    try:
        import uvicorn
    except ImportError:
        print(
            "API server requires uvicorn. Install with: pip install pycatalyst[api]",
            file=sys.stderr,
        )
        return 1

    uvicorn.run(
        "pycatalyst.api.main:create_application",
        host=args.host,
        port=args.port,
        reload=args.reload,
        factory=True,
    )
    return 0


def _cmd_ui(args: argparse.Namespace) -> int:
    """Handle UI subcommands."""
    if args.ui_command == "serve":
        from pycatalyst.ui.server import serve_ui

        serve_ui(api_url=args.api_url, host=args.host, port=args.port)
        return 0
    if args.ui_command == "dev":
        from pycatalyst.ui.dev import run_dev_server

        run_dev_server(api_url=args.api_url, port=args.port)
        return 0
    if args.ui_command == "build":
        from pycatalyst.ui.build import build_ui

        return build_ui()
    return 1


def _schema_to_dict(schema: object) -> dict:
    """Convert SchemaSpec to a serializable dict for output."""
    from pycatalyst._types import SchemaSpec

    if not isinstance(schema, SchemaSpec):
        return {}

    return {
        "name": schema.name,
        "fields": [_field_to_dict(f) for f in schema.fields],
    }


def _field_to_dict(field: object) -> dict:
    """Convert FieldSpec to dict."""
    from pycatalyst._types import FieldSpec

    if not isinstance(field, FieldSpec):
        return {}

    d: dict = {
        "name": field.name,
        "type": field.type.value,
    }
    if field.nullable:
        d["nullable"] = True
    if field.constraints:
        constraints: dict = {}
        c = field.constraints
        if c.min is not None:
            constraints["min"] = c.min
        if c.max is not None:
            constraints["max"] = c.max
        if c.precision is not None:
            constraints["precision"] = c.precision
        if c.choices:
            constraints["choices"] = list(c.choices)
        if c.pattern:
            constraints["pattern"] = c.pattern
        if constraints:
            d["constraints"] = constraints
    return d


# -----------------------------------------------------------------------
# ML commands
# -----------------------------------------------------------------------


def _cmd_train(args: argparse.Namespace) -> int:
    """Train an ML model from an experiment config."""
    try:
        from pycatalyst.ml.run import run_experiment
    except ImportError as exc:
        print(
            f"ML training not available: {exc}\n"
            "Install with: pip install pycatalyst[ml-core]",
            file=sys.stderr,
        )
        return 1

    try:
        result = run_experiment(args.config)
        print(result.summary())
        return 0
    except Exception as exc:
        print(f"Training failed: {exc}", file=sys.stderr)
        return 1


def _cmd_predict(args: argparse.Namespace) -> int:
    """Run inference with a trained PyTorch model."""
    try:
        import numpy as np
        import pandas as pd

        from pycatalyst.ml.pytorch.serving import Predictor
    except ImportError as exc:
        print(
            f"ML prediction not available: {exc}\n"
            "Install with: pip install pycatalyst[ml-core]",
            file=sys.stderr,
        )
        return 1

    try:
        predictor = Predictor(args.model_dir)
        df = pd.read_csv(args.input)
        data = df.values.astype(np.float32)
        predictions = predictor.predict(data)

        if args.output:
            out_path = Path(args.output)
            pd.DataFrame(predictions, columns=["prediction"]).to_csv(
                out_path,
                index=False,
            )
            print(f"Predictions saved to {out_path}")
        else:
            for i, pred in enumerate(predictions.squeeze()):
                print(f"{i}: {pred:.6f}")
        return 0
    except Exception as exc:
        print(f"Prediction failed: {exc}", file=sys.stderr)
        return 1
