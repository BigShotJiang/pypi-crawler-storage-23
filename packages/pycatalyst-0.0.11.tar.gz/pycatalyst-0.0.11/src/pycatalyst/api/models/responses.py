"""Response models for PyCatalyst API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class LoginResponse(BaseModel):
    """Response from successful login."""

    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field("bearer", description="Token type")
    expires_in: int = Field(3600, description="Token lifetime in seconds")


class UserResponse(BaseModel):
    """Response for current user query."""

    username: str = Field(..., description="Username")
    auth_disabled: bool = Field(False, description="Whether auth is disabled")
