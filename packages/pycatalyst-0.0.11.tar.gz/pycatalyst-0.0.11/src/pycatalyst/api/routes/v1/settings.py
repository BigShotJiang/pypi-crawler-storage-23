"""
Route handlers for settings: app-config for UI (theme, app name, version).
"""

from __future__ import annotations

from fastapi import APIRouter, status

from pycatalyst import __version__ as catalyst_version
from pycatalyst.config import get_ui_app_name, get_ui_theme

# Public router: no auth (so UI can load theme before login)
public_router = APIRouter()


@public_router.get(
    "/settings/app-config",
    status_code=status.HTTP_200_OK,
    summary="Get app config (theme, app name, version) for UI",
    description="Returns UI theme (light, dark, system), app name, and release version. No auth required.",
)
async def get_app_config() -> dict[str, str]:
    return {
        "theme": get_ui_theme(),
        "app_name": get_ui_app_name(),
        "version": catalyst_version or "",
    }
