"""ML experiment endpoint — POST /api/v1/ml/run.

Runs a single experiment from YAML config. Core pycatalyst.ml remains stateless;
this route owns the HTTP contract and temporary file handling.
"""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst.ml.run import run_experiment

router = APIRouter()


class MlRunRequest(BaseModel):
    """Request body for running an ML experiment."""

    config: str = Field(..., description="Experiment config as YAML string")


class MlRunResponse(BaseModel):
    """Response from running an ML experiment. Mirrors ExperimentResult."""

    name: str
    backend: str
    metrics: dict[str, float] = Field(default_factory=dict)
    artifacts: dict[str, str] = Field(default_factory=dict)
    training_history: list[dict] = Field(default_factory=list)
    duration_seconds: float = 0.0


@router.post("/ml/run", response_model=MlRunResponse)
async def run_ml_experiment(request: MlRunRequest) -> MlRunResponse:
    """Run an ML experiment from YAML config and return the result.

    Writes config to a temporary file and calls stateless run_experiment() in a
    thread pool so the event loop is not blocked. Long-running training may
    hit timeouts; consider increasing gateway/worker timeouts for large jobs.
    """
    if not request.config.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="config must be a non-empty YAML string",
        )

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".yaml",
            delete=False,
            encoding="utf-8",
        ) as f:
            f.write(request.config)
            config_path = f.name

        try:
            result = await asyncio.to_thread(run_experiment, config_path)
        finally:
            Path(config_path).unlink(missing_ok=True)

        return MlRunResponse(
            name=result.name,
            backend=result.backend,
            metrics=dict(result.metrics),
            artifacts=dict(result.artifacts),
            training_history=list(result.training_history),
            duration_seconds=result.duration_seconds,
        )
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        ) from exc
    except ImportError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": str(exc),
                "hint": "Install the required ML extra (e.g. pycatalyst[ml-core], pycatalyst[ml-sklearn], pycatalyst[ml-llm])",
            },
        ) from exc
