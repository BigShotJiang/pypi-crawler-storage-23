"""Service container endpoints — CRUD for dockerized database services.

Endpoints for creating, listing, inspecting, and destroying database
service containers (Postgres, MongoDB) tied to workbench environments.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, field_validator

from pycatalyst.api.dependencies.auth import get_current_user
from pycatalyst.errors import ServiceError
from pycatalyst.services.service_containers import ServiceConfig, ServiceType
from pycatalyst.services.workbench_manager import workbench_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workbench")

ALLOWED_SERVICE_TYPES = frozenset(t.value for t in ServiceType)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _owner_from_user(user: dict[str, Any]) -> str:
    """Extract the owner identifier from the resolved user dict."""
    return user.get("username", "anonymous")


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CreateServiceRequest(BaseModel):
    """Request to create a database service container."""

    service_type: str = Field(
        description="Database type: postgres or mongodb",
    )
    database: str = Field(
        default="pycatalyst_db",
        description="Initial database name to create",
    )
    username: str = Field(
        default="pycatalyst",
        description="Database admin username",
    )
    password: str = Field(
        default="pycatalyst_dev",
        description="Database admin password",
    )

    @field_validator("service_type")
    @classmethod
    def _validate_service_type(cls, v: str) -> str:
        val = v.strip().lower()
        if val not in ALLOWED_SERVICE_TYPES:
            allowed = ", ".join(sorted(ALLOWED_SERVICE_TYPES))
            raise ValueError(f"Service type {v!r} is not supported. Allowed: {allowed}")
        return val


class ServiceInfoResponse(BaseModel):
    """Public representation of a database service."""

    service_id: str
    env_id: str
    service_type: str
    status: str
    host_url: str
    container_url: str
    host_port: int
    container_name: str
    container_id: str
    database: str
    username: str
    created_at: float
    error_message: str


class ServiceListResponse(BaseModel):
    """Wrapper for a list of services."""

    services: list[ServiceInfoResponse]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/environments/{env_id}/services",
    response_model=ServiceInfoResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_service(
    env_id: str,
    body: CreateServiceRequest,
    user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    """Create a database service container for an environment."""
    owner = _owner_from_user(user)

    config = ServiceConfig(
        service_type=ServiceType(body.service_type),
        database=body.database,
        username=body.username,
        password=body.password,
    )

    try:
        svc = await workbench_manager.create_service(env_id, config, owner=owner)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ServiceError as exc:
        raise HTTPException(status_code=400, detail=exc.message) from exc

    return svc.to_dict()


@router.get(
    "/environments/{env_id}/services",
    response_model=ServiceListResponse,
)
async def list_services(
    env_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    """List database services for an environment."""
    owner = _owner_from_user(user)

    env_info = workbench_manager.get_environment(env_id, owner=owner)
    if env_info is None:
        raise HTTPException(status_code=404, detail=f"Unknown environment: {env_id}")

    services = workbench_manager.list_services(env_id, owner=owner)
    return {"services": services}


@router.get(
    "/services/{service_id}",
    response_model=ServiceInfoResponse,
)
async def get_service(
    service_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    """Get status of a database service."""
    owner = _owner_from_user(user)

    result = workbench_manager.get_service_status(service_id, owner=owner)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Unknown service: {service_id}")
    return result


@router.delete(
    "/services/{service_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def destroy_service(
    service_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> None:
    """Destroy a database service container."""
    owner = _owner_from_user(user)

    try:
        await workbench_manager.destroy_service(service_id, owner=owner)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
