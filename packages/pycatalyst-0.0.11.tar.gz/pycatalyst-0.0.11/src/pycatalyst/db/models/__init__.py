"""SQLAlchemy models for PyCatalyst DB."""

from __future__ import annotations

from pycatalyst.db.models.app_metadata import AppMetadataModel

__all__ = ["AppMetadataModel"]
