"""PyCatalyst database package: config, base, migrations, CLI."""

from __future__ import annotations

from pycatalyst.db.base import Base, get_engine, get_schema_prefix, get_session
from pycatalyst.db.config import (
    detect_db_type,
    get_alembic_config,
    get_db_url,
    get_migrations_dir,
    is_default_db_url,
    require_alembic,
)

__all__ = [
    "Base",
    "detect_db_type",
    "get_alembic_config",
    "get_engine",
    "get_migrations_dir",
    "get_db_url",
    "get_schema_prefix",
    "get_session",
    "is_default_db_url",
    "require_alembic",
]
