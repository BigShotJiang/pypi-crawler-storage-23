"""Initial app_metadata table

Revision ID: 20260101000000
Revises: None
Create Date: 2026-01-01

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260101000000"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pycatalyst schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pycatalyst"


def upgrade() -> None:
    schema_name = _schema()
    op.create_table(
        "app_metadata",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("key", sa.String(255), nullable=False),
        sa.Column("value", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        schema=schema_name,
    )
    op.create_index(
        op.f("ix_app_metadata_key"),
        "app_metadata",
        ["key"],
        unique=False,
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        op.f("ix_app_metadata_key"),
        table_name="app_metadata",
        schema=schema_name,
    )
    op.drop_table("app_metadata", schema=schema_name)
