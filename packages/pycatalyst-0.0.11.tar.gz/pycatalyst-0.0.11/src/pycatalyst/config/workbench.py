"""Workbench config. Env or pycatalyst.cfg [workbench]; keys = env names."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from pycatalyst.config.ui import _cfg

_DEFAULT_MAX_SESSIONS = 10
_DEFAULT_MAX_ENVIRONMENTS = 5
_DEFAULT_MAX_VENVS = 5
_DEFAULT_MAX_CONTAINERS = 3
_DEFAULT_SHELL = ""
_DEFAULT_DOCKER_IMAGE = "python:3.13-slim"
_DEFAULT_DOCKER_MEM_LIMIT = "512m"
_DEFAULT_SESSION_IDLE_TIMEOUT = 1800  # 30 minutes
_DEFAULT_SCROLLBACK_SIZE = 131_072  # 128 KB


def get_workbench_max_sessions() -> int:
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_MAX_SESSIONS")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_MAX_SESSIONS")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(1, val)
    except (ValueError, TypeError):
        return _DEFAULT_MAX_SESSIONS


def get_workbench_shell() -> str:
    """Default shell for new terminal sessions."""
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_SHELL")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_SHELL")
        or ""
    )
    shell = raw.strip()
    if shell:
        return shell
    for candidate in ("bash", "zsh", "sh"):
        if shutil.which(candidate):
            return candidate
    return "/bin/sh"


def get_workbench_venv_dir() -> str:
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_VENV_DIR")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_VENV_DIR")
        or ""
    )
    if raw.strip():
        return raw.strip()
    return str(Path.home() / ".pycatalyst" / "workbench")


def get_workbench_docker_image() -> str:
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_DOCKER_IMAGE")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_DOCKER_IMAGE")
        or ""
    )
    return raw.strip() or _DEFAULT_DOCKER_IMAGE


def get_workbench_docker_mem_limit() -> str:
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_DOCKER_MEM_LIMIT")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_DOCKER_MEM_LIMIT")
        or ""
    )
    return raw.strip() or _DEFAULT_DOCKER_MEM_LIMIT


def get_workbench_session_idle_timeout() -> int:
    """Idle timeout in seconds before a session is reaped. 0 = disabled."""
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_SESSION_IDLE_TIMEOUT")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_SESSION_IDLE_TIMEOUT")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(0, val)
    except (ValueError, TypeError):
        return _DEFAULT_SESSION_IDLE_TIMEOUT


def get_workbench_scrollback_size() -> int:
    """Scrollback ring-buffer size in bytes. 0 = disabled."""
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_SCROLLBACK_SIZE")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_SCROLLBACK_SIZE")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(0, val)
    except (ValueError, TypeError):
        return _DEFAULT_SCROLLBACK_SIZE


def get_workbench_max_environments() -> int:
    """General fallback limit per backend type. Prefer the specific getters."""
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_MAX_ENVIRONMENTS")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_MAX_ENVIRONMENTS")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(1, val)
    except (ValueError, TypeError):
        return _DEFAULT_MAX_ENVIRONMENTS


def get_workbench_max_venvs() -> int:
    """Max venv environments per user. Falls back to MAX_ENVIRONMENTS."""
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_MAX_VENVS")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_MAX_VENVS")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(1, val)
    except (ValueError, TypeError):
        return _DEFAULT_MAX_VENVS


def get_workbench_max_containers() -> int:
    """Max Docker container environments per user. Falls back to MAX_ENVIRONMENTS."""
    raw = (
        os.getenv("PYCATALYST_WORKBENCH_MAX_CONTAINERS")
        or _cfg("workbench", "PYCATALYST_WORKBENCH_MAX_CONTAINERS")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(1, val)
    except (ValueError, TypeError):
        return _DEFAULT_MAX_CONTAINERS


# ── Service container config ───────────────────────────────────────────────

_DEFAULT_SERVICE_POSTGRES_IMAGE = "postgres:16-alpine"
_DEFAULT_SERVICE_MONGODB_IMAGE = "mongo:7"
_DEFAULT_SERVICE_MEM_LIMIT = "512m"
_DEFAULT_SERVICE_HEALTH_TIMEOUT = 30
_DEFAULT_MAX_SERVICES_PER_ENV = 3


def get_service_postgres_image() -> str:
    """Docker image for Postgres service containers."""
    raw = (
        os.getenv("PYCATALYST_SERVICE_POSTGRES_IMAGE")
        or _cfg("workbench", "PYCATALYST_SERVICE_POSTGRES_IMAGE")
        or ""
    )
    return raw.strip() or _DEFAULT_SERVICE_POSTGRES_IMAGE


def get_service_mongodb_image() -> str:
    """Docker image for MongoDB service containers."""
    raw = (
        os.getenv("PYCATALYST_SERVICE_MONGODB_IMAGE")
        or _cfg("workbench", "PYCATALYST_SERVICE_MONGODB_IMAGE")
        or ""
    )
    return raw.strip() or _DEFAULT_SERVICE_MONGODB_IMAGE


def get_service_mem_limit() -> str:
    """Memory limit for service containers (e.g. '512m', '1g')."""
    raw = (
        os.getenv("PYCATALYST_SERVICE_MEM_LIMIT")
        or _cfg("workbench", "PYCATALYST_SERVICE_MEM_LIMIT")
        or ""
    )
    return raw.strip() or _DEFAULT_SERVICE_MEM_LIMIT


def get_service_health_timeout() -> int:
    """Seconds to wait for a service container to become healthy."""
    raw = (
        os.getenv("PYCATALYST_SERVICE_HEALTH_TIMEOUT")
        or _cfg("workbench", "PYCATALYST_SERVICE_HEALTH_TIMEOUT")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(5, val)
    except (ValueError, TypeError):
        return _DEFAULT_SERVICE_HEALTH_TIMEOUT


def get_service_max_per_env() -> int:
    """Maximum number of service containers per workbench environment."""
    raw = (
        os.getenv("PYCATALYST_SERVICE_MAX_PER_ENV")
        or _cfg("workbench", "PYCATALYST_SERVICE_MAX_PER_ENV")
        or ""
    )
    try:
        val = int(raw.strip())
        return max(1, val)
    except (ValueError, TypeError):
        return _DEFAULT_MAX_SERVICES_PER_ENV
