"""PyCatalyst configuration utilities."""

from __future__ import annotations

from pycatalyst.config.auth import (
    get_auth_initial_credentials,
    get_auth_jwt_secret,
    is_auth_disabled,
)
from pycatalyst.config.database import get_database_url, set_database_url
from pycatalyst.config.paths import find_config_file
from pycatalyst.config.ui import get_ui_app_name, get_ui_theme
from pycatalyst.config.workbench import (
    get_workbench_docker_image,
    get_workbench_docker_mem_limit,
    get_workbench_max_environments,
    get_workbench_max_sessions,
    get_workbench_shell,
    get_workbench_venv_dir,
)

__all__ = [
    "find_config_file",
    "get_auth_initial_credentials",
    "get_auth_jwt_secret",
    "get_database_url",
    "get_ui_app_name",
    "get_ui_theme",
    "get_workbench_docker_image",
    "get_workbench_docker_mem_limit",
    "get_workbench_max_environments",
    "get_workbench_max_sessions",
    "get_workbench_shell",
    "get_workbench_venv_dir",
    "is_auth_disabled",
    "set_database_url",
]
