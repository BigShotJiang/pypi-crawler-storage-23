"""Generation engine that orchestrates field generators.

The GenerationEngine is the main entry point for producing data batches.
It takes a SchemaSpec and produces records by delegating to the
appropriate generator for each field.
"""

from __future__ import annotations

import logging
import random
import time
from random import Random
from typing import Any

from pycatalyst._types import GenerationResult, SchemaSpec
from pycatalyst.errors import GenerationError
from pycatalyst.generators.registry import GeneratorRegistry

logger = logging.getLogger(__name__)


class GenerationEngine:
    """Orchestrates data generation from a SchemaSpec.

    Uses a GeneratorRegistry to resolve generators for each field
    type, then produces batches of records.

    Attributes:
        registry: The generator registry for field type resolution.
    """

    def __init__(
        self,
        registry: GeneratorRegistry | None = None,
    ) -> None:
        self._registry = registry or GeneratorRegistry.default()

    def generate(
        self,
        schema: SchemaSpec,
        count: int = 10,
        seed: int | None = None,
    ) -> GenerationResult:
        """Generate a batch of records from a schema.

        Args:
            schema: The schema describing records to generate.
            count: Number of records to generate.
            seed: Random seed for reproducible output.

        Returns:
            GenerationResult with the generated records.

        Raises:
            GenerationError: If generation fails for any field.
        """
        if count < 1:
            raise GenerationError(
                f"count must be at least 1, got {count}",
                schema_name=schema.name,
            )

        rng = Random(seed)
        if seed is not None:
            random.seed(seed)
        start = time.monotonic()

        records: list[dict[str, Any]] = []
        for i in range(count):
            try:
                record = self._generate_record(schema, rng)
                records.append(record)
            except Exception as exc:
                raise GenerationError(
                    f"Failed to generate record {i}: {exc}",
                    schema_name=schema.name,
                ) from exc

        duration_ms = (time.monotonic() - start) * 1000

        logger.info(
            "generated %d records for schema '%s' in %.1fms",
            count,
            schema.name,
            duration_ms,
        )

        return GenerationResult(
            records=tuple(records),
            schema=schema,
            count=count,
            duration_ms=duration_ms,
            seed=seed,
        )

    def _generate_record(
        self,
        schema: SchemaSpec,
        rng: Random,
    ) -> dict[str, Any]:
        """Generate a single record from a schema."""
        record: dict[str, Any] = {}
        for field_spec in schema.fields:
            # Handle nullable fields
            if field_spec.nullable and rng.random() < field_spec.nullable_rate:
                record[field_spec.name] = None
                continue

            gen = self._registry.get(field_spec.type)
            record[field_spec.name] = gen.generate(field_spec, rng)

        return record
