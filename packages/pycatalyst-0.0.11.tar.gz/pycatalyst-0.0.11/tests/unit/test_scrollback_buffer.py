"""Unit tests for the ScrollbackBuffer ring buffer."""

from __future__ import annotations

import pytest

from pycatalyst.services.backends.base import ScrollbackBuffer


class TestScrollbackBuffer:
    """Verify ring-buffer semantics for terminal scrollback replay."""

    def test_empty_read(self) -> None:
        buf = ScrollbackBuffer(64)
        assert buf.read() == b""

    def test_write_and_read(self) -> None:
        buf = ScrollbackBuffer(64)
        buf.write(b"hello")
        assert buf.read() == b"hello"

    def test_len(self) -> None:
        buf = ScrollbackBuffer(64)
        assert len(buf) == 0
        buf.write(b"abc")
        assert len(buf) == 3

    def test_wrap_around(self) -> None:
        buf = ScrollbackBuffer(8)
        buf.write(b"12345678")  # fills exactly
        buf.write(b"AB")  # wraps: overwrites first 2 bytes
        assert len(buf) == 8
        assert buf.read() == b"345678AB"

    def test_exact_capacity(self) -> None:
        buf = ScrollbackBuffer(8)
        buf.write(b"abcdefgh")
        assert len(buf) == 8
        assert buf.read() == b"abcdefgh"

    def test_oversized_chunk(self) -> None:
        buf = ScrollbackBuffer(4)
        buf.write(b"0123456789")  # 10 bytes into 4-byte buffer
        assert len(buf) == 4
        assert buf.read() == b"6789"

    def test_multiple_small_writes(self) -> None:
        buf = ScrollbackBuffer(6)
        for ch in b"abcdefghij":
            buf.write(bytes([ch]))
        assert len(buf) == 6
        assert buf.read() == b"efghij"

    def test_zero_capacity(self) -> None:
        buf = ScrollbackBuffer(0)
        buf.write(b"data")
        assert len(buf) == 0
        assert buf.read() == b""

    @pytest.mark.parametrize(
        ("writes", "capacity", "expected"),
        [
            ([b"abc", b"def"], 6, b"abcdef"),
            ([b"abc", b"def"], 4, b"cdef"),
            ([b"a" * 10, b"b" * 5], 8, b"aaabbbbb"),
        ],
    )
    def test_parametrized_sequences(
        self,
        writes: list[bytes],
        capacity: int,
        expected: bytes,
    ) -> None:
        buf = ScrollbackBuffer(capacity)
        for w in writes:
            buf.write(w)
        assert buf.read() == expected
