"""Tests for pycatalyst.api.routes.v1.workbench REST endpoints."""

from __future__ import annotations

from collections.abc import Generator
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from pycatalyst.api.main import create_application
from pycatalyst.api.routes.v1.workbench import ALLOWED_COMMANDS, CreateSessionRequest
from pycatalyst.services.backends.base import SessionHandle
from pycatalyst.services.workbench_manager import EnvironmentInfo

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_handle(**kwargs: Any) -> SessionHandle:
    """Create a minimal SessionHandle for testing."""
    defaults = {
        "session_id": "sess-1",
        "env_id": "env-1",
        "command": "bash",
        "backend_type": "venv",
        "read_fd": 0,
        "write": lambda _: None,
        "resize": lambda c, r: None,
        "close": MagicMock(),
        "is_alive": lambda: True,
        "owner": "anonymous",
        "pid": 12345,
        "cols": 80,
        "rows": 24,
    }
    defaults.update(kwargs)
    return SessionHandle(**defaults)


@pytest.fixture()
def client() -> Generator[TestClient, None, None]:
    """Create a test client with auth disabled."""
    with patch(
        "pycatalyst.api.dependencies.auth.is_auth_disabled",
        return_value=True,
    ):
        app = create_application()
        yield TestClient(app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Pydantic model validation
# ---------------------------------------------------------------------------


class TestCreateSessionRequest:
    """Tests for CreateSessionRequest validation."""

    @pytest.mark.parametrize("cmd", sorted(ALLOWED_COMMANDS))
    def test_allows_valid_commands(self, cmd: str) -> None:
        req = CreateSessionRequest(command=cmd)
        assert req.command == cmd

    def test_normalizes_command_case(self) -> None:
        req = CreateSessionRequest(command="BASH")
        assert req.command == "bash"

    def test_rejects_disallowed_command(self) -> None:
        with pytest.raises(ValueError, match="not allowed"):
            CreateSessionRequest(command="rm")


# ---------------------------------------------------------------------------
# Capabilities (public, no auth)
# ---------------------------------------------------------------------------


class TestCapabilities:
    """Tests for GET /api/v1/workbench/capabilities."""

    def test_returns_capabilities(self, client: TestClient) -> None:
        resp = client.get("/api/v1/workbench/capabilities")
        assert resp.status_code == 200
        data = resp.json()
        assert "venv" in data
        assert "docker" in data


# ---------------------------------------------------------------------------
# Environment CRUD
# ---------------------------------------------------------------------------


class TestCreateEnvironment:
    """Tests for POST /api/v1/workbench/environments."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_creates_environment(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.create_environment = AsyncMock(
            return_value=EnvironmentInfo(
                env_id="env-1",
                backend_type="venv",
                owner="anonymous",
            ),
        )
        resp = client.post(
            "/api/v1/workbench/environments",
            json={"backend": "venv"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["env_id"] == "env-1"
        assert data["backend"] == "venv"

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_rejects_bad_backend(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.create_environment = AsyncMock(
            side_effect=ValueError("Backend 'nope' is not available"),
        )
        resp = client.post(
            "/api/v1/workbench/environments",
            json={"backend": "nope"},
        )
        assert resp.status_code == 400

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_429_on_limit(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.create_environment = AsyncMock(
            side_effect=RuntimeError("Maximum venv environments (5) reached"),
        )
        resp = client.post(
            "/api/v1/workbench/environments",
            json={"backend": "venv"},
        )
        assert resp.status_code == 429


class TestListEnvironments:
    """Tests for GET /api/v1/workbench/environments."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_lists_environments(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.list_environments.return_value = [
            {
                "env_id": "env-1",
                "backend": "venv",
                "created_at": 1.0,
                "session_count": 0,
            },
        ]
        resp = client.get("/api/v1/workbench/environments")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["environments"]) == 1


class TestDestroyEnvironment:
    """Tests for DELETE /api/v1/workbench/environments/{env_id}."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_destroys_environment(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.destroy_environment = AsyncMock()
        resp = client.delete("/api/v1/workbench/environments/env-1")
        assert resp.status_code == 204

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.destroy_environment = AsyncMock(
            side_effect=ValueError("Unknown environment"),
        )
        resp = client.delete("/api/v1/workbench/environments/env-1")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Session CRUD
# ---------------------------------------------------------------------------


class TestCreateSession:
    """Tests for POST /api/v1/workbench/environments/{env_id}/sessions."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_creates_session(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.spawn_session = AsyncMock(return_value=_make_handle())
        resp = client.post(
            "/api/v1/workbench/environments/env-1/sessions",
            json={"command": "bash"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["session_id"] == "sess-1"
        assert data["command"] == "bash"

    def test_rejects_invalid_command(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/workbench/environments/env-1/sessions",
            json={"command": "rm -rf /"},
        )
        # Validation rejects the command; 422 or 500 depending on error
        # serialization (the global handler may not serialize Pydantic
        # validation errors cleanly).
        assert resp.status_code in (422, 500)
        assert resp.status_code != 200

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown_env(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.spawn_session = AsyncMock(
            side_effect=ValueError("Unknown environment"),
        )
        resp = client.post(
            "/api/v1/workbench/environments/env-1/sessions",
            json={"command": "bash"},
        )
        assert resp.status_code == 404


class TestListSessions:
    """Tests for GET /api/v1/workbench/sessions."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_lists_sessions(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.list_sessions.return_value = [
            {
                "session_id": "sess-1",
                "env_id": "env-1",
                "command": "bash",
                "backend_type": "venv",
                "pid": 12345,
                "cols": 80,
                "rows": 24,
                "alive": True,
            },
        ]
        resp = client.get("/api/v1/workbench/sessions")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["sessions"]) == 1


class TestDeleteSession:
    """Tests for DELETE /api/v1/workbench/sessions/{session_id}."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_deletes_session(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.kill_session.return_value = True
        resp = client.delete("/api/v1/workbench/sessions/sess-1")
        assert resp.status_code == 204

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.kill_session.return_value = False
        resp = client.delete("/api/v1/workbench/sessions/sess-1")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Packages
# ---------------------------------------------------------------------------


class TestListPackages:
    """Tests for GET /api/v1/workbench/environments/{env_id}/packages."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_lists_packages(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.list_packages = AsyncMock(
            return_value=[{"name": "pip", "version": "24.0"}],
        )
        resp = client.get("/api/v1/workbench/environments/env-1/packages")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["packages"]) == 1
        assert data["packages"][0]["name"] == "pip"

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown_env(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.list_packages = AsyncMock(
            side_effect=ValueError("Unknown environment"),
        )
        resp = client.get("/api/v1/workbench/environments/env-1/packages")
        assert resp.status_code == 404


class TestInstallPackages:
    """Tests for POST /api/v1/workbench/environments/{env_id}/packages/install."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_installs_packages(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.install_packages = AsyncMock(
            return_value={
                "success": True,
                "output": "Successfully installed httpx",
                "packages": [{"name": "httpx", "version": "0.27.0"}],
            },
        )
        resp = client.post(
            "/api/v1/workbench/environments/env-1/packages/install",
            json={"packages": ["httpx"]},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert len(data["packages"]) == 1
        assert data["packages"][0]["name"] == "httpx"

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown_env(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.install_packages = AsyncMock(
            side_effect=ValueError("Unknown environment"),
        )
        resp = client.post(
            "/api/v1/workbench/environments/env-1/packages/install",
            json={"packages": ["httpx"]},
        )
        assert resp.status_code == 404


class TestUninstallPackages:
    """Tests for POST /api/v1/workbench/environments/{env_id}/packages/uninstall."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_uninstalls_packages(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.uninstall_packages = AsyncMock(
            return_value={
                "success": True,
                "output": "Successfully uninstalled httpx",
                "packages": [],
            },
        )
        resp = client.post(
            "/api/v1/workbench/environments/env-1/packages/uninstall",
            json={"packages": ["httpx"]},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown_env(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.uninstall_packages = AsyncMock(
            side_effect=ValueError("Unknown environment"),
        )
        resp = client.post(
            "/api/v1/workbench/environments/env-1/packages/uninstall",
            json={"packages": ["httpx"]},
        )
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Profiles
# ---------------------------------------------------------------------------


class TestProfiles:
    """Tests for GET /api/v1/workbench/profiles."""

    @patch("pycatalyst.services.profiles.list_profiles")
    def test_returns_profiles(
        self,
        mock_list: MagicMock,
        client: TestClient,
    ) -> None:
        from pycatalyst.services.profiles import EnvironmentProfile

        mock_list.return_value = [
            EnvironmentProfile(
                name="test-profile",
                description="A test profile",
                backend="venv",
                packages=["httpx"],
                editable_packages=[],
            ),
        ]
        resp = client.get("/api/v1/workbench/profiles")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["profiles"]) == 1
        assert data["profiles"][0]["name"] == "test-profile"


# ---------------------------------------------------------------------------
# Refresh env
# ---------------------------------------------------------------------------


class TestRefreshEnv:
    """Tests for POST /api/v1/workbench/sessions/{session_id}/refresh-env."""

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_refresh_python_session(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        handle = _make_handle(command="python")
        mock_mgr.get_session.return_value = handle
        resp = client.post("/api/v1/workbench/sessions/sess-1/refresh-env")
        assert resp.status_code == 200

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_rejects_non_python_session(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        handle = _make_handle(command="bash")
        mock_mgr.get_session.return_value = handle
        resp = client.post("/api/v1/workbench/sessions/sess-1/refresh-env")
        assert resp.status_code == 400

    @patch("pycatalyst.api.routes.v1.workbench.workbench_manager")
    def test_returns_404_for_unknown(
        self,
        mock_mgr: MagicMock,
        client: TestClient,
    ) -> None:
        mock_mgr.get_session.return_value = None
        resp = client.post("/api/v1/workbench/sessions/sess-1/refresh-env")
        assert resp.status_code == 404
