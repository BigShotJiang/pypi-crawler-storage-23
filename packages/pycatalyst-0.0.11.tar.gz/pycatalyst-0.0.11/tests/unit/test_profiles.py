"""Tests for pycatalyst.services.profiles."""

from __future__ import annotations

import pytest

from pycatalyst.services.profiles import (
    EnvironmentProfile,
    _substitute_env_vars,
    get_profile,
    list_profiles,
)


class TestEnvironmentProfile:
    """Tests for the EnvironmentProfile model."""

    def test_minimal_profile(self) -> None:
        p = EnvironmentProfile(name="test")
        assert p.name == "test"
        assert p.backend == "venv"
        assert p.packages == []
        assert p.editable_packages == []

    def test_full_profile(self) -> None:
        p = EnvironmentProfile(
            name="dev",
            description="Dev profile",
            backend="docker",
            packages=["httpx", "pytest"],
            editable_packages=["/path/to/pkg"],
        )
        assert p.name == "dev"
        assert p.description == "Dev profile"
        assert p.backend == "docker"
        assert len(p.packages) == 2
        assert len(p.editable_packages) == 1


class TestSubstituteEnvVars:
    """Tests for env var substitution in profiles."""

    def test_default_value(self) -> None:
        result = _substitute_env_vars("${NONEXISTENT_VAR_XYZ:-/default/path}")
        assert result == "/default/path"

    def test_env_var_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CATALYST_TEST_VAR", "/custom/path")
        result = _substitute_env_vars("${CATALYST_TEST_VAR:-/default/path}")
        assert result == "/custom/path"

    def test_required_var_missing(self) -> None:
        # Required var missing — logs warning and keeps placeholder
        result = _substitute_env_vars("${NONEXISTENT_REQUIRED_VAR:?Must set this}")
        assert "${NONEXISTENT_REQUIRED_VAR:?Must set this}" in result

    def test_bare_var_missing(self) -> None:
        result = _substitute_env_vars("${NONEXISTENT_BARE_VAR}")
        assert "${NONEXISTENT_BARE_VAR}" in result

    def test_bare_var_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CATALYST_BARE", "value")
        result = _substitute_env_vars("${CATALYST_BARE}")
        assert result == "value"


class TestListProfiles:
    """Tests for list_profiles."""

    def test_loads_builtin_profiles(self) -> None:
        profiles = list_profiles()
        # Should find the built-in pystator-dev and pycharter-dev profiles
        names = {p.name for p in profiles}
        assert "pystator-dev" in names
        assert "pycharter-dev" in names

    def test_profiles_have_required_fields(self) -> None:
        profiles = list_profiles()
        for p in profiles:
            assert p.name
            assert p.backend in ("venv", "docker")


class TestGetProfile:
    """Tests for get_profile."""

    def test_finds_builtin_profile(self) -> None:
        p = get_profile("pystator-dev")
        assert p is not None
        assert p.name == "pystator-dev"
        assert p.backend == "venv"
        assert "ipython" in p.packages

    def test_returns_none_for_missing(self) -> None:
        assert get_profile("nonexistent-profile-xyz") is None
