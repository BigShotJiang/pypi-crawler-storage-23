"""Tests for pycatalyst.ml._types module."""

from __future__ import annotations

import pytest

from pycatalyst.ml._types import VALID_BACKENDS, Backend, TrainingStatus


class TestTrainingStatus:
    """Tests for TrainingStatus enum."""

    def test_all_values_are_strings(self) -> None:
        for status in TrainingStatus:
            assert isinstance(status.value, str)

    def test_expected_statuses(self) -> None:
        expected = {"completed", "early_stopped", "failed", "interrupted", "unknown"}
        assert {s.value for s in TrainingStatus} == expected

    def test_string_construction(self) -> None:
        assert TrainingStatus("completed") == TrainingStatus.COMPLETED
        assert TrainingStatus("failed") == TrainingStatus.FAILED
        assert TrainingStatus("early_stopped") == TrainingStatus.EARLY_STOPPED

    def test_invalid_status_raises(self) -> None:
        with pytest.raises(ValueError):
            TrainingStatus("invalid")

    def test_is_str_subclass(self) -> None:
        assert isinstance(TrainingStatus.COMPLETED, str)
        assert TrainingStatus.COMPLETED == "completed"


class TestBackend:
    """Tests for Backend enum."""

    def test_all_values_are_strings(self) -> None:
        for b in Backend:
            assert isinstance(b.value, str)

    def test_expected_backends(self) -> None:
        expected = {"sklearn", "pytorch", "huggingface"}
        assert {b.value for b in Backend} == expected

    def test_string_construction(self) -> None:
        assert Backend("sklearn") == Backend.SKLEARN
        assert Backend("pytorch") == Backend.PYTORCH

    def test_invalid_backend_raises(self) -> None:
        with pytest.raises(ValueError):
            Backend("tensorflow")

    def test_is_str_subclass(self) -> None:
        assert isinstance(Backend.SKLEARN, str)
        assert Backend.SKLEARN == "sklearn"


class TestValidBackends:
    """Tests for VALID_BACKENDS constant."""

    def test_is_frozenset(self) -> None:
        assert isinstance(VALID_BACKENDS, frozenset)

    def test_contains_all_backends(self) -> None:
        assert "sklearn" in VALID_BACKENDS
        assert "pytorch" in VALID_BACKENDS
        assert "huggingface" in VALID_BACKENDS

    def test_matches_enum(self) -> None:
        assert VALID_BACKENDS == {b.value for b in Backend}
