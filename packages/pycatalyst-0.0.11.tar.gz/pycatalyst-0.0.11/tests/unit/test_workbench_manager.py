"""Tests for pycatalyst.services.workbench_manager."""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import MagicMock

import pytest

from pycatalyst.services.backends.base import SessionHandle
from pycatalyst.services.workbench_manager import EnvironmentInfo, WorkbenchManager

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_handle(
    session_id: str = "sess-1",
    env_id: str = "env-1",
    command: str = "bash",
    owner: str = "",
    **kwargs: Any,
) -> SessionHandle:
    """Create a minimal SessionHandle for testing."""
    return SessionHandle(
        session_id=session_id,
        env_id=env_id,
        command=command,
        backend_type="venv",
        read_fd=0,
        write=lambda _: None,
        resize=lambda c, r: None,
        close=MagicMock(),
        is_alive=lambda: True,
        owner=owner,
        **kwargs,
    )


def _make_mock_backend(
    backend_type: str = "venv",
    sessions: dict[str, SessionHandle] | None = None,
) -> MagicMock:
    """Create a mock backend satisfying the EnvironmentBackend protocol."""
    backend = MagicMock()
    backend.backend_type = backend_type
    _sessions = dict(sessions) if sessions else {}
    _env_counter = [0]

    async def _create() -> str:
        _env_counter[0] += 1
        return f"mock-env-{_env_counter[0]}"

    async def _destroy(env_id: str) -> None:
        pass

    async def _spawn_session(
        env_id: str, command: str, cols: int, rows: int
    ) -> SessionHandle:
        h = _make_handle(
            session_id=f"sess-{len(_sessions) + 1}", env_id=env_id, command=command
        )
        _sessions[h.session_id] = h
        return h

    async def _list_packages(env_id: str) -> list[dict]:
        return []

    async def _install_packages(
        env_id: str,
        packages: list[str],
        *,
        editable: bool = False,
        upgrade: bool = False,
    ) -> dict[str, Any]:
        return {"success": True, "output": "ok", "packages": []}

    async def _uninstall_packages(
        env_id: str,
        packages: list[str],
    ) -> dict[str, Any]:
        return {"success": True, "output": "ok", "packages": []}

    backend.create = _create
    backend.destroy = _destroy
    backend.spawn_session = _spawn_session
    backend.list_packages = _list_packages
    backend.install_packages = _install_packages
    backend.uninstall_packages = _uninstall_packages
    backend.get_session = lambda sid: _sessions.get(sid)
    backend.remove_session = lambda sid: _sessions.pop(sid, None) is not None
    backend.env_session_count = lambda eid: sum(
        1 for h in _sessions.values() if h.env_id == eid
    )
    backend.has_env = lambda eid: True
    backend.list_sessions = lambda: list(_sessions.values())
    backend.shutdown = MagicMock()
    return backend


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def manager(tmp_path: Any) -> WorkbenchManager:
    """WorkbenchManager with a mock venv backend."""
    mgr = WorkbenchManager.__new__(WorkbenchManager)
    mgr._backends = {}
    mgr._environments = {}
    mgr._env_backend_map = {}
    mgr._max_environments = 5
    mgr._max_env_limits = {"venv": 5, "docker": 3}
    mgr._max_sessions_per_env = 10
    mgr._session_idle_timeout = 1800
    mgr._service_manager = None
    mgr._backends["venv"] = _make_mock_backend("venv")
    return mgr


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCapabilities:
    """Tests for WorkbenchManager.capabilities."""

    def test_returns_registered_backends(self, manager: WorkbenchManager) -> None:
        caps = manager.capabilities()
        assert caps["venv"] is True
        assert caps["docker"] is False


class TestCreateEnvironment:
    """Tests for WorkbenchManager.create_environment."""

    async def test_creates_environment(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        assert info.env_id == "mock-env-1"
        assert info.backend_type == "venv"
        assert info.owner == "alice"

    async def test_rejects_unknown_backend(self, manager: WorkbenchManager) -> None:
        with pytest.raises(ValueError, match="not available"):
            await manager.create_environment("nope")

    async def test_enforces_max_environments(self, manager: WorkbenchManager) -> None:
        manager._max_env_limits["venv"] = 1
        await manager.create_environment("venv", owner="alice")
        with pytest.raises(RuntimeError, match="Maximum"):
            await manager.create_environment("venv", owner="alice")

    async def test_max_envs_scoped_per_owner(self, manager: WorkbenchManager) -> None:
        manager._max_env_limits["venv"] = 1
        await manager.create_environment("venv", owner="alice")
        # Different owner should still be able to create
        info = await manager.create_environment("venv", owner="bob")
        assert info.owner == "bob"


class TestDestroyEnvironment:
    """Tests for WorkbenchManager.destroy_environment."""

    async def test_destroys_environment(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        await manager.destroy_environment(info.env_id, owner="alice")
        assert manager.get_environment(info.env_id) is None

    async def test_rejects_unknown_env(self, manager: WorkbenchManager) -> None:
        with pytest.raises(ValueError, match="Unknown"):
            await manager.destroy_environment("nope")

    async def test_rejects_wrong_owner(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        with pytest.raises(ValueError, match="Unknown"):
            await manager.destroy_environment(info.env_id, owner="eve")


class TestListEnvironments:
    """Tests for WorkbenchManager.list_environments."""

    async def test_lists_own_environments(self, manager: WorkbenchManager) -> None:
        await manager.create_environment("venv", owner="alice")
        await manager.create_environment("venv", owner="bob")

        alice_envs = manager.list_environments(owner="alice")
        assert len(alice_envs) == 1

        all_envs = manager.list_environments()
        assert len(all_envs) == 2


class TestSpawnSession:
    """Tests for WorkbenchManager.spawn_session."""

    async def test_spawns_session(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        handle = await manager.spawn_session(
            info.env_id,
            "bash",
            owner="alice",
        )
        assert handle.session_id.startswith("sess-")
        assert handle.owner == "alice"

    async def test_rejects_unknown_env(self, manager: WorkbenchManager) -> None:
        with pytest.raises(ValueError, match="Unknown"):
            await manager.spawn_session("nope", "bash", owner="alice")

    async def test_rejects_wrong_owner(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        with pytest.raises(ValueError, match="Unknown"):
            await manager.spawn_session(info.env_id, "bash", owner="eve")

    async def test_enforces_max_sessions(self, manager: WorkbenchManager) -> None:
        manager._max_sessions_per_env = 1
        info = await manager.create_environment("venv", owner="alice")
        await manager.spawn_session(info.env_id, "bash", owner="alice")
        with pytest.raises(RuntimeError, match="Maximum sessions"):
            await manager.spawn_session(info.env_id, "bash", owner="alice")


class TestGetSession:
    """Tests for WorkbenchManager.get_session."""

    async def test_finds_session(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        handle = await manager.spawn_session(info.env_id, "bash", owner="alice")
        found = manager.get_session(handle.session_id, owner="alice")
        assert found is not None
        assert found.session_id == handle.session_id

    async def test_returns_none_for_wrong_owner(
        self,
        manager: WorkbenchManager,
    ) -> None:
        info = await manager.create_environment("venv", owner="alice")
        handle = await manager.spawn_session(info.env_id, "bash", owner="alice")
        assert manager.get_session(handle.session_id, owner="eve") is None

    def test_returns_none_for_missing(self, manager: WorkbenchManager) -> None:
        assert manager.get_session("nonexistent") is None


class TestKillSession:
    """Tests for WorkbenchManager.kill_session."""

    async def test_kills_session(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        handle = await manager.spawn_session(info.env_id, "bash", owner="alice")
        assert manager.kill_session(handle.session_id, owner="alice") is True
        assert manager.get_session(handle.session_id) is None

    async def test_rejects_wrong_owner(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        handle = await manager.spawn_session(info.env_id, "bash", owner="alice")
        assert manager.kill_session(handle.session_id, owner="eve") is False

    def test_returns_false_for_missing(self, manager: WorkbenchManager) -> None:
        assert manager.kill_session("nonexistent") is False


class TestListSessions:
    """Tests for WorkbenchManager.list_sessions."""

    async def test_lists_sessions(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        await manager.spawn_session(info.env_id, "bash", owner="alice")
        await manager.spawn_session(info.env_id, "python", owner="alice")

        sessions = manager.list_sessions(owner="alice")
        assert len(sessions) == 2

    async def test_filters_by_env(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        await manager.spawn_session(info.env_id, "bash", owner="alice")

        sessions = manager.list_sessions(env_id="nonexistent", owner="alice")
        assert len(sessions) == 0


class TestInstallPackages:
    """Tests for WorkbenchManager.install_packages."""

    async def test_installs_packages(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        result = await manager.install_packages(info.env_id, ["httpx"], owner="alice")
        assert result["success"] is True

    async def test_rejects_unknown_env(self, manager: WorkbenchManager) -> None:
        with pytest.raises(ValueError, match="Unknown"):
            await manager.install_packages("nope", ["httpx"], owner="alice")

    async def test_rejects_wrong_owner(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        with pytest.raises(ValueError, match="Unknown"):
            await manager.install_packages(info.env_id, ["httpx"], owner="eve")


class TestUninstallPackages:
    """Tests for WorkbenchManager.uninstall_packages."""

    async def test_uninstalls_packages(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        result = await manager.uninstall_packages(info.env_id, ["httpx"], owner="alice")
        assert result["success"] is True

    async def test_rejects_unknown_env(self, manager: WorkbenchManager) -> None:
        with pytest.raises(ValueError, match="Unknown"):
            await manager.uninstall_packages("nope", ["httpx"], owner="alice")

    async def test_rejects_wrong_owner(self, manager: WorkbenchManager) -> None:
        info = await manager.create_environment("venv", owner="alice")
        with pytest.raises(ValueError, match="Unknown"):
            await manager.uninstall_packages(info.env_id, ["httpx"], owner="eve")


class TestReapIdleSessions:
    """Tests for WorkbenchManager.reap_idle_sessions."""

    async def test_reaps_idle_session(self, manager: WorkbenchManager) -> None:
        manager._session_idle_timeout = 1
        info = await manager.create_environment("venv", owner="alice")
        handle = await manager.spawn_session(info.env_id, "bash", owner="alice")

        # Artificially age the session
        handle.last_activity = time.monotonic() - 10
        reaped = manager.reap_idle_sessions()
        assert reaped == 1

    async def test_skips_active_session(self, manager: WorkbenchManager) -> None:
        manager._session_idle_timeout = 3600
        info = await manager.create_environment("venv", owner="alice")
        await manager.spawn_session(info.env_id, "bash", owner="alice")

        reaped = manager.reap_idle_sessions()
        assert reaped == 0

    def test_disabled_when_timeout_zero(self, manager: WorkbenchManager) -> None:
        manager._session_idle_timeout = 0
        assert manager.reap_idle_sessions() == 0


class TestShutdown:
    """Tests for WorkbenchManager.shutdown."""

    async def test_shutdown_clears_state(self, manager: WorkbenchManager) -> None:
        await manager.create_environment("venv", owner="alice")
        manager.shutdown()

        assert len(manager._environments) == 0
        assert len(manager._env_backend_map) == 0
        manager._backends["venv"].shutdown.assert_called_once()


class TestEnvironmentInfo:
    """Tests for EnvironmentInfo dataclass."""

    def test_to_dict(self) -> None:
        info = EnvironmentInfo(
            env_id="env-1",
            backend_type="venv",
            owner="alice",
        )
        d = info.to_dict(session_count=3)
        assert d["env_id"] == "env-1"
        assert d["backend"] == "venv"
        assert d["session_count"] == 3
        assert "created_at" in d
