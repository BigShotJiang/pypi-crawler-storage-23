API Reference
=============

.. autofunction:: recursive_diff.recursive_diff

.. autofunction:: recursive_diff.recursive_eq

.. autofunction:: recursive_diff.cast

.. autofunction:: recursive_diff.open

.. autofunction:: recursive_diff.recursive_open
