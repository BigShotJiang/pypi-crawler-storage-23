"""Scapy compatibility tests for Stackforge."""
