# UXLint

AI-powered UX quality gate for web applications.

Paste a URL. Get Pass/Fail in 30 seconds.

🚧 Coming soon. Join the waitlist at https://uxlint.dev