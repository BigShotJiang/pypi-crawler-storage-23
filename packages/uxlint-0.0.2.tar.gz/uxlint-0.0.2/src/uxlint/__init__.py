"""UXLint — AI-powered UX quality gate for web applications."""

__version__ = "0.0.2"