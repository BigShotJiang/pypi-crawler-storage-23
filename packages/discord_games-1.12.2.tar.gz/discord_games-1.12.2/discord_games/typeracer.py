from __future__ import annotations

from typing import Optional, ClassVar, TypedDict
from io import BytesIO

import textwrap
import time
import random
import asyncio
import aiohttp
import difflib
import pathlib

from PIL import Image, ImageDraw, ImageFont
import discord
from discord.ext import commands

from .utils import DEFAULT_COLOR, DiscordColor, executor


class UserData(TypedDict):
    user: discord.User
    time: float
    wpm: float
    acc: float


class TypeRacer:
    """Type racing game, message-based.

    Players race to type a sentence. Measures WPM and accuracy.
    """

    SENTENCE_URL: ClassVar[str] = "https://zenquotes.io/api/random"
    EMOJI_MAP: ClassVar[dict[int, str]] = {
        1: "🥇",
        2: "🥈",
        3: "🥉",
    }

    @executor()
    def _tr_img(self, text: str, font_path: str) -> BytesIO:
        text = "\n".join(textwrap.wrap(text, width=25))

        font = ImageFont.truetype(font_path, 30)
        try:
            x, y = font.getsize_multiline(text)  # type: ignore[attr-defined]
        except AttributeError:
            _, _, x, y = ImageDraw.Draw(Image.new("RGB", (0, 0))).multiline_textbbox(
                (10, 10),
                text,
                font=font,
            )

        with Image.new("RGB", (int(x) + 20, int(y) + 30), (0, 0, 30)) as image:
            cursor = ImageDraw.Draw(image)
            cursor.multiline_text((10, 10), text, font=font, fill=(220, 200, 220))

            buffer = BytesIO()
            image.save(buffer, "PNG")
            buffer.seek(0)
            return buffer

    def format_line(self, i: int, data: UserData) -> str:
        return f" • {self.EMOJI_MAP[i]} | {data['user'].mention} in {data['time']:.2f}s | **WPM:** {data['wpm']:.2f} | **ACC:** {data['acc']:.2f}%"

    async def wait_for_tr_response(
        self,
        ctx: commands.Context[commands.Bot],
        text: str,
        *,
        timeout: float,
        min_accuracy: float,
    ) -> discord.Message:
        self.embed.description = ""

        winners = []
        start = time.perf_counter()

        while not ctx.bot.is_closed():

            def check(m: discord.Message) -> bool:
                content = m.content.replace("\n", " ").strip()
                if (
                    m.channel == ctx.channel
                    and not m.author.bot
                    and m.author not in map(lambda m: m["user"], winners)
                ):
                    sim = difflib.SequenceMatcher(None, content, text).ratio()
                    return sim >= min_accuracy
                return False

            try:
                message: discord.Message = await ctx.bot.wait_for(
                    "message", timeout=timeout, check=check
                )
            except asyncio.TimeoutError:
                if winners:
                    break
                else:
                    return await ctx.reply(
                        "Looks like no one responded",
                        allowed_mentions=discord.AllowedMentions.none(),
                    )

            end = time.perf_counter()
            content = message.content.replace("\n", " ").strip()
            timeout -= round(end - start)

            winners.append(
                {
                    "user": message.author,
                    "time": end - start,
                    "wpm": len(text.split()) / ((end - start) / 60),
                    "acc": difflib.SequenceMatcher(None, content, text).ratio() * 100,
                }
            )

            self.embed.description += (
                self.format_line(len(winners), winners[len(winners) - 1]) + "\n"
            )
            await self.message.edit(embed=self.embed)

            await message.add_reaction(self.EMOJI_MAP[len(winners)])

            if len(winners) >= 3:
                break

        desc = [self.format_line(i, x) for i, x in enumerate(winners, 1)]
        embed = discord.Embed(
            title="Typerace results",
            color=self.embed_color,
            timestamp=discord.utils.utcnow(),
        )
        embed.add_field(name="Winners", value="\n".join(desc))

        return await ctx.reply(
            embed=embed, allowed_mentions=discord.AllowedMentions.none()
        )

    async def start(
        self,
        ctx: commands.Context[commands.Bot],
        *,
        embed_title: str = "Type the following sentence in the chat now!",
        embed_color: DiscordColor = DEFAULT_COLOR,
        path_to_text_font: Optional[str] = None,
        timeout: float = 40,
        words_mode: bool = False,
        show_author: bool = True,
        max_quote_length: Optional[int] = None,
        min_accuracy: float = 0.9,
    ) -> discord.Message:
        """
        starts the typerace game

        Parameters
        ----------
        ctx : commands.Context
            the context of the invokation command
        embed_title : str, optional
            the title of the game embed, by default 'Type the following sentence in the chat now!'
        embed_color : DiscordColor, optional
            the color of the game embed, by default DEFAULT_COLOR
        path_to_text_font : Optional[str], optional
            path to the font you want to use for the image
            fallbacks to SegoeUI if not specified, by default None
        timeout : float, optional
            the game timeout, by default 40
        words_mode : bool, optional
            specifies whether or not to just use random words instead of a quote, by default False
        show_author : bool, optional
            specifies whether or not to show the command author in the embed, by default True
        max_quote_length : int, optional
            specifies the maximum length of the quote to truncate to if necessary, by default None
        min_accuracy : float, optional
            specifies the minimum accuracy an attempt needs to be for it to be accepted by the bot

        Returns
        -------
        discord.Message
            the game message

        Raises
        ------
        RuntimeError
            requesting the quote failed
        """
        self.embed_color = embed_color
        parent = pathlib.Path(__file__).parent

        if not words_mode:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.SENTENCE_URL) as r:
                    if r.ok:
                        data: list[dict[str, str]] = await r.json()
                        text = data[0].get("q", "").replace("\n", " ").strip()
                    else:
                        raise RuntimeError(
                            f"HTTP request raised an error: {r.status}; {r.reason}"
                        )

        else:
            with open(parent / "assets/words.txt", "r") as wordsfp:
                words = wordsfp.read().splitlines()
                text = " ".join(random.choice(words).lower() for _ in range(8))

        if max_quote_length is not None:
            if len(text) > max_quote_length:
                text = textwrap.shorten(text, width=max_quote_length, placeholder="")

        if not path_to_text_font:
            path_to_text_font = str(parent / "assets/segoe-ui-semilight-411.ttf")

        buffer = await self._tr_img(text, path_to_text_font)

        embed = discord.Embed(
            title=embed_title, color=self.embed_color, timestamp=discord.utils.utcnow()
        )
        embed.set_image(url="attachment://tr.png")

        if show_author:
            embed.set_author(
                name=ctx.author.name, icon_url=ctx.author.display_avatar.url
            )

        self.embed = embed
        self.message = await ctx.send(embed=embed, file=discord.File(buffer, "tr.png"))

        await self.wait_for_tr_response(
            ctx, text, timeout=timeout, min_accuracy=min_accuracy
        )
        return self.message
