from __future__ import annotations

import pathlib
import random
import asyncio
from typing import Optional, Final
from io import BytesIO

import discord
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont

from .utils import DEFAULT_COLOR, DiscordColor, executor

BORDER: Final[int] = 40
SQ: Final[int] = 100
SPACE: Final[int] = 10

WIDTH: Final[int] = BORDER * 2 + SQ * 5 + SPACE * 4
HEIGHT: Final[int] = BORDER * 2 + SQ * 6 + SPACE * 5

GRAY: Final[tuple[int, int, int]] = (119, 123, 125)
ORANGE: Final[tuple[int, int, int]] = (200, 179, 87)
GREEN: Final[tuple[int, int, int]] = (105, 169, 99)
LGRAY: Final[tuple[int, int, int]] = (198, 201, 205)


class Guess:
    __slots__ = ("letter", "color")

    def __init__(self, letter: str, color: tuple[int, int, int]) -> None:
        self.letter = letter
        self.color = color


class Wordle:
    """Wordle game, message-based.

    Guess a five-letter word with color-coded feedback
    for each attempt.
    """

    word: str

    def __init__(self, word: Optional[str] = None, *, text_size: int = 55) -> None:
        self.embed_color: Optional[DiscordColor] = None

        parent = pathlib.Path(__file__).parent
        with open(parent / "assets/words.txt", "r") as f:
            self._valid_words = tuple(f.read().splitlines())
        self._text_size = text_size
        self._font = ImageFont.truetype(
            str(parent / "assets/HelveticaNeuBold.ttf"), self._text_size
        )

        self.guesses: list[list[Optional[Guess]]] = []

        if word:
            if len(word) != 5:
                raise ValueError("Word must be of length 5")

            if not word.isalpha():
                raise ValueError("Word must be an alphabetical string")

            self.word = word
        else:
            self.word = random.choice(self._valid_words)

    def parse_guess(self, guess: str) -> bool:
        assert (guess_len := len(guess)) == len(self.word)

        word: list[Optional[str]] = list(self.word)
        curr_guess: list[Optional[Guess]] = [None] * guess_len

        for i, letter in enumerate(guess):
            if word[i] == letter:
                word[i] = None
                curr_guess[i] = Guess(letter, GREEN)

        for i, letter in enumerate(guess):
            if word[i] is not None:
                curr_guess[i] = Guess(letter, ORANGE if letter in word else GRAY)

        self.guesses.append(curr_guess)
        return guess == self.word

    @executor()
    def render_image(self) -> BytesIO:
        with Image.new("RGB", (WIDTH, HEIGHT), (255, 255, 255)) as img:
            cursor = ImageDraw.Draw(img)

            x = y = BORDER
            for i in range(6):
                for j in range(5):
                    try:
                        letter = self.guesses[i][j]
                        assert letter is not None
                        color = letter.color
                        literal_letter = letter.letter
                    except (IndexError, KeyError):
                        cursor.rectangle((x, y, x + SQ, y + SQ), outline=LGRAY, width=4)
                    else:
                        cursor.rectangle((x, y, x + SQ, y + SQ), width=0, fill=color)
                        cursor.text(
                            (x + SQ / 2, y + SQ / 2),
                            literal_letter.upper(),
                            font=self._font,
                            anchor="mm",
                            fill=(255, 255, 255),
                        )

                    x += SQ + SPACE
                x = BORDER
                y += SQ + SPACE

            buf = BytesIO()
            img.save(buf, "PNG")
        buf.seek(0)
        return buf

    async def start(
        self,
        ctx: commands.Context[commands.Bot],
        *,
        timeout: Optional[float] = None,
        embed_color: DiscordColor = DEFAULT_COLOR,
    ) -> discord.Message:
        """
        starts the wordle game

        Parameters
        ----------
        ctx : commands.Context
            the context of the invokation command
        timeout : Optional[float], optional
            the timeout for when waiting, by default None
        embed_color : DiscordColor, optional
            the color of the game embed, by default DEFAULT_COLOR

        Returns
        -------
        discord.Message
            returns the game message
        """
        self.embed_color = embed_color

        buf = await self.render_image()

        embed = discord.Embed(title="Wordle!", color=self.embed_color)
        embed.set_image(url="attachment://wordle.png")
        embed.set_footer(text='Say "stop" to cancel the game!')

        self.message = await ctx.send(embed=embed, file=discord.File(buf, "wordle.png"))

        while not ctx.bot.is_closed():

            def check(m: discord.Message) -> bool:
                return (
                    (len(m.content) == 5 or m.content.lower() == "stop")
                    and m.author == ctx.author
                    and m.channel == ctx.channel
                )

            try:
                guess: discord.Message = await ctx.bot.wait_for(
                    "message", timeout=timeout, check=check
                )
            except asyncio.TimeoutError:
                break

            content = guess.content.lower()

            if content == "stop":
                await ctx.send(f"Game Over! cancelled, the word was: **{self.word}**")
                break

            if content != self.word and content not in self._valid_words:
                await ctx.send("That is not a valid word!")
            else:
                won = self.parse_guess(content)
                buf = await self.render_image()

                await self.message.delete()

                embed = discord.Embed(title="Wordle!", color=self.embed_color)
                embed.set_image(url="attachment://wordle.png")

                self.message = await ctx.send(
                    embed=embed, file=discord.File(buf, "wordle.png")
                )

                if won:
                    await ctx.send("Game Over! You won!")
                    break
                elif len(self.guesses) >= 6:
                    await ctx.send(
                        f"Game Over! You lose, the word was: **{self.word}**"
                    )
                    break

        return self.message
