"""Tool: signals — View buying signals, signal reports, strategy insights, and feedback.

Thin dispatcher that routes to existing run_* functions based on the action parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def run_signals(
    action: str = "show",
    campaign_id: str = "",
    signal_type: str = "",
    status: str = "",
    limit: int = 20,
    days: int = 30,
    signal_id: str = "",
    feedback: str = "",
) -> str:
    """View and analyze buying signals from LinkedIn.

    Actions:
      show     — Display detected buying signals (keyword mentions, job changes, etc.)
      report   — Signal analytics report with trends and ROI
      strategy — Show strategy engine insights, patterns, and autonomous actions
      feedback — Mark a signal as 'useful' or 'not_useful' (improves future classification)

    Args:
        action: What to do: 'show', 'report', 'strategy', 'feedback'.
        campaign_id: Filter by campaign. Shows all if empty.
        signal_type: Filter by signal type, e.g. 'keyword_mention', 'job_change' (for 'show').
        status: Filter by status: 'new', 'classified', 'actioned' (for 'show').
        limit: Max signals to show (for 'show'). Default 20.
        days: Lookback window in days (for 'report'). Default 30.
        signal_id: Signal ID (for 'feedback' action).
        feedback: 'useful' or 'not_useful' (for 'feedback' action).
    """
    action = action.lower().strip()

    if action == "show":
        from .show_signals import run_show_signals
        return await run_show_signals(
            signal_type=signal_type,
            campaign_id=campaign_id,
            status=status,
            limit=limit,
        )

    if action == "report":
        from .signal_report import run_signal_report
        return await run_signal_report(days=days, campaign_id=campaign_id)

    if action == "strategy":
        from .show_strategy import run_show_strategy
        return await run_show_strategy(campaign_id=campaign_id)

    if action == "feedback":
        return _handle_feedback(signal_id=signal_id, feedback=feedback)

    if action in ("website_setup", "website"):
        return await _handle_website_setup()

    if action == "website_stats":
        return await _handle_website_stats(days=days)

    return (
        f"Unknown action: '{action}'. "
        "Use 'show', 'report', 'strategy', 'feedback', 'website_setup', or 'website_stats'."
    )


def _handle_feedback(signal_id: str, feedback: str) -> str:
    """Record user feedback on a signal's usefulness."""
    import time as _time
    from ..db.signal_queries import get_signal, update_signal

    if not signal_id:
        return "signal_id is required for feedback action."

    feedback = feedback.lower().strip()
    if feedback not in ("useful", "not_useful"):
        return "feedback must be 'useful' or 'not_useful'."

    signal = get_signal(signal_id)
    if not signal:
        return f"Signal '{signal_id}' not found."

    update_signal(
        signal_id,
        user_feedback=feedback,
        feedback_at=int(_time.time()),
    )

    return f"Feedback recorded: signal {signal_id[:8]} marked as '{feedback}'."


async def _handle_website_setup() -> str:
    """Set up website visitor tracking — generate snippet token and embed code."""
    from ..linkedin.factory import get_linkedin_client

    client = get_linkedin_client()

    # Backend mode — call /t/setup via the backend
    if hasattr(client, "base_url") and hasattr(client, "jwt_token"):
        import httpx

        url = f"{client.base_url}/t/setup"
        try:
            async with httpx.AsyncClient(timeout=15.0) as http:
                resp = await http.post(
                    url,
                    headers={"Authorization": f"Bearer {client.jwt_token}"},
                    json={},
                )
                if resp.status_code != 200:
                    return f"Failed to set up website tracking (HTTP {resp.status_code}): {resp.text}"
                data = resp.json()
        except Exception as e:
            return f"Failed to connect to backend for website setup: {e}"

        embed_code = data.get("embed_code", "")
        high_intent = data.get("high_intent_paths", [])

        lines = [
            "## Website Visitor Tracking — Setup Complete",
            "",
            "Your tracking snippet is ready! Add this to your website's `<head>` tag:",
            "",
            "```html",
            embed_code,
            "```",
            "",
            f"**High-intent pages** (generate stronger signals): {', '.join(high_intent)}",
            "",
            "**How it works:**",
            "- Identifies visiting companies via IP-to-company resolution",
            "- No cookies, no fingerprinting — GDPR/CCPA compliant",
            "- Company-level identification only (no individual tracking)",
            "- Generates `website_visit` and `website_high_intent` signals",
            "- Signals feed into your existing scoring and outreach pipeline",
            "",
            "**Customize paths:** Use `signals(action='website_setup')` with custom high-intent paths,",
            "or call `POST /t/config` on the backend directly.",
        ]
        return "\n".join(lines)

    return (
        "Website tracking requires backend mode. "
        "Connect your account via setup_profile() first."
    )


async def _handle_website_stats(days: int = 30) -> str:
    """Fetch website tracking stats from the backend."""
    from ..linkedin.factory import get_linkedin_client

    client = get_linkedin_client()

    if hasattr(client, "base_url") and hasattr(client, "jwt_token"):
        import httpx

        url = f"{client.base_url}/t/stats"
        try:
            async with httpx.AsyncClient(timeout=15.0) as http:
                resp = await http.get(
                    url,
                    headers={"Authorization": f"Bearer {client.jwt_token}"},
                    params={"days": days},
                )
                if resp.status_code != 200:
                    return f"Failed to fetch website stats (HTTP {resp.status_code}): {resp.text}"
                data = resp.json()
        except Exception as e:
            return f"Failed to connect to backend for website stats: {e}"

        lines = [
            f"## Website Tracking Stats (last {days} days)",
            "",
            f"- **Total visits:** {data.get('total_visits', 0)}",
            f"- **Unique companies:** {data.get('unique_companies', 0)}",
            f"- **High-intent visits:** {data.get('high_intent_visits', 0)}",
            f"- **Signals created:** {data.get('signals_created', 0)}",
        ]

        top = data.get("top_companies", [])
        if top:
            lines.append("")
            lines.append("### Top Companies")
            for c in top[:10]:
                hi = f" ({c['high_intent']} high-intent)" if c.get("high_intent") else ""
                lines.append(f"- **{c['company']}** — {c['visits']} visits{hi}")

        recent = data.get("recent_visits", [])
        if recent:
            lines.append("")
            lines.append("### Recent Visits")
            for v in recent[:10]:
                intent = " [HIGH INTENT]" if v.get("high_intent") else ""
                company = f" ({v['company']})" if v.get("company") else ""
                lines.append(f"- {v.get('url', 'unknown')}{company}{intent}")

        return "\n".join(lines)

    return "Website tracking requires backend mode."
