"""Hardware Agent - AI-powered lab instrument connection assistant."""

__version__ = "0.1.0"
