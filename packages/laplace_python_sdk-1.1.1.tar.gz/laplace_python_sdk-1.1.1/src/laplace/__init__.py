"""Laplace Python SDK - A Python client for the Laplace stock data platform."""

from .client import LaplaceClient

__version__ = "0.1.1"
__all__ = ["LaplaceClient"]
