"""systemd service installer/uninstaller for mocea."""

import logging
import shutil
import subprocess
import sys
from pathlib import Path

log = logging.getLogger(__name__)

SYSTEM_SERVICE_DIR = Path("/etc/systemd/system")
USER_SERVICE_DIR = Path.home() / ".config" / "systemd" / "user"
SERVICE_NAME = "mocea.service"
PROFILE_SCRIPT = Path("/etc/profile.d/mocea.sh")

MOTD_SCRIPT = """\
if systemctl is-active --quiet mocea.service; then
    echo "mocea: running"
else
    echo "mocea: NOT running"
fi
"""

SERVICE_TEMPLATE = """\
[Unit]
Description=mocea - idle droplet monitor
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={exec_start} run
Restart=on-failure
RestartSec=30
{env_line}

[Install]
WantedBy={wanted_by}
"""


def _find_mocea_binary() -> str:
    path = shutil.which("mocea")
    if path:
        return path
    # Under sudo, the venv isn't on PATH. Check next to the Python interpreter
    # since pip installs console scripts alongside it.
    candidate = Path(sys.executable).parent / "mocea"
    if candidate.is_file():
        return str(candidate)
    raise FileNotFoundError(
        "Could not find 'mocea' on PATH. Ensure mocea is installed (e.g. 'pip install mocea') and on PATH."
    )


def generate_service(user: bool = False, env_file: str | None = None) -> str:
    """Generate the systemd service file content."""
    exec_start = _find_mocea_binary()

    if env_file:
        env_line = f"EnvironmentFile={env_file}"
    else:
        env_line = "# EnvironmentFile=/etc/mocea/env"

    wanted_by = "default.target" if user else "multi-user.target"

    return SERVICE_TEMPLATE.format(
        exec_start=exec_start,
        env_line=env_line,
        wanted_by=wanted_by,
    )


def install_service(user: bool = False, env_file: str | None = None) -> Path:
    """Write the service file and enable/start the service."""
    content = generate_service(user=user, env_file=env_file)

    if user:
        service_dir = USER_SERVICE_DIR
        service_dir.mkdir(parents=True, exist_ok=True)
        systemctl = ["systemctl", "--user"]
    else:
        service_dir = SYSTEM_SERVICE_DIR
        systemctl = ["systemctl"]

    service_path = service_dir / SERVICE_NAME
    service_path.write_text(content)
    log.info("Created %s", service_path)

    subprocess.run([*systemctl, "daemon-reload"], check=True)
    subprocess.run([*systemctl, "enable", SERVICE_NAME], check=True)
    subprocess.run([*systemctl, "start", SERVICE_NAME], check=True)

    log.info("Enabled and started %s", SERVICE_NAME)

    if not user:
        _install_motd()

    return service_path


def _install_motd() -> None:
    """Install login banner that shows mocea service status."""
    PROFILE_SCRIPT.write_text(MOTD_SCRIPT)
    log.info("Created %s", PROFILE_SCRIPT)


def _uninstall_motd() -> None:
    """Remove login banner."""
    if PROFILE_SCRIPT.exists():
        PROFILE_SCRIPT.unlink()
        log.info("Removed %s", PROFILE_SCRIPT)


def uninstall_service(user: bool = False) -> None:
    """Stop, disable, and remove the service file."""
    if user:
        service_dir = USER_SERVICE_DIR
        systemctl = ["systemctl", "--user"]
    else:
        service_dir = SYSTEM_SERVICE_DIR
        systemctl = ["systemctl"]

    # Stop and disable (ignore errors if not running/enabled)
    subprocess.run([*systemctl, "stop", SERVICE_NAME], check=False)
    subprocess.run([*systemctl, "disable", SERVICE_NAME], check=False)

    service_path = service_dir / SERVICE_NAME
    if service_path.exists():
        service_path.unlink()
        log.info("Removed %s", service_path)

    subprocess.run([*systemctl, "daemon-reload"], check=True)

    if not user:
        _uninstall_motd()

    log.info("Uninstalled %s", SERVICE_NAME)


def service_status(user: bool = False) -> str | None:
    """Return systemctl status output, or None if service not found."""
    systemctl = ["systemctl", "--user"] if user else ["systemctl"]
    result = subprocess.run(
        [*systemctl, "status", SERVICE_NAME],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode == 4:  # unit not found
        return None
    return result.stdout
