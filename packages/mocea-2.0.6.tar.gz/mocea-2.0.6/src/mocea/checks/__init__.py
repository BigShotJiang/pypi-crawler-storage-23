"""Idle detection checks."""

from .base import BaseCheck
from .cpu import CpuCheck
from .gpu import GpuCheck
from .heartbeat import HeartbeatCheck
from .load import LoadCheck
from .network import NetworkCheck
from .process import ProcessCheck
from .ssh import SshCheck

REGISTRY: dict[str, type[BaseCheck]] = {
    "cpu": CpuCheck,
    "process": ProcessCheck,
    "ssh": SshCheck,
    "load": LoadCheck,
    "network": NetworkCheck,
    "gpu": GpuCheck,
    "heartbeat": HeartbeatCheck,
}


def load_checks(config) -> list[BaseCheck]:
    """Instantiate enabled checks from config."""
    checks = []
    for name, check_cfg in config.enabled_checks().items():
        cls = REGISTRY.get(name)
        if cls is None:
            continue
        checks.append(cls(check_cfg.params))
    return checks
