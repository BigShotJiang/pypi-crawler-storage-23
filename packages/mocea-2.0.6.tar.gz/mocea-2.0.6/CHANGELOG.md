# Changelog

## Version 2.0.0

### Added
- **Snapshot tagging**: when terminating a droplet, mocea now tags the snapshot with metadata (IP address, droplet size, region/location) so that ocea can pick up and display this information when restoring.

## Version 1.1.0

### Added
- **Fallback action chain**: if the primary action fails (e.g., `ocea` binary missing), mocea automatically tries fallback actions (`api` → `shutdown`) instead of crashing in a loop. Default chains are built-in; configurable via `[action] fallback = "..."` or opt-out with `fallback = "none"`.
- **Enhanced binary resolution**: the `ocea` action now searches the Python venv's `bin/` directory, `/usr/local/bin`, and `~/.local/bin` in addition to `PATH` — handles systemd's restricted environment.
- **Startup validation**: mocea checks action prerequisites at startup (binary existence, API token, pydo availability) and logs warnings, giving early notice of problems.
- **`validate()` hook on all actions**: `BaseAction.validate()` returns a list of warning strings. Overridden in `OceaAction` (binary check) and `ApiAction` (token + pydo check).
- **`FallbackAction` wrapper**: transparent wrapper that catches primary action failures and iterates through fallbacks. If all fail, logs `CRITICAL` and exits cleanly (no crash loop).
- **`fallback_action_type` config field**: new optional field in `[action]` table to explicitly set or disable fallback behavior.

## Version 0.1.0

- Initial release
