﻿"""SDK exceptions for Azure Content Understanding.

This module provides the common exception hierarchy used by the client and
model validation layers.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""


class AzureCUError(Exception):
    """Base exception for azure-cu-sdk errors."""


class ClientConfigurationError(AzureCUError):
    """Raised when required client configuration is missing or invalid."""


class AuthenticationError(AzureCUError):
    """Raised when authentication fails or is not provided."""


class ServiceError(AzureCUError):
    """Raised when the service returns an error response."""
