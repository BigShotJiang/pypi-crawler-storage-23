﻿"""Client SDK for Azure Content Understanding.

This package defines the public SDK surface and re-exports the primary client,
models, and exception types.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""

from .client import ContentUnderstandingClient
from .exceptions import AzureCUError, AuthenticationError, ClientConfigurationError, ServiceError
from .models import (
    AnalyzeRequest,
    AnalyzeResponse,
    ContentItem,
    DocumentSource,
    ImageSource,
    TextSource,
)

__all__ = [
    "ContentUnderstandingClient",
    "AzureCUError",
    "AuthenticationError",
    "ClientConfigurationError",
    "ServiceError",
    "AnalyzeRequest",
    "AnalyzeResponse",
    "ContentItem",
    "DocumentSource",
    "ImageSource",
    "TextSource",
]
