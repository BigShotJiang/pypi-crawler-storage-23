﻿"""Pydantic models for request and response payloads.

This module defines the SDK's structured request/response contracts used by
the client and published API.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

from pydantic import BaseModel, Field


class TextSource(BaseModel):
    """Raw text input for analysis.

    Attributes:
        text: The raw text to analyze.
    """

    text: str = Field(..., min_length=1, description="Raw text to analyze.")


class DocumentSource(BaseModel):
    """Document input for analysis.

    Attributes:
        uri: A URI pointing to a document (PDF, DOCX, etc.).
        sas_token: Optional SAS token appended at request time.
    """

    uri: str = Field(..., min_length=1, description="Document URI.")
    sas_token: Optional[str] = Field(default=None, description="Optional SAS token.")


class ImageSource(BaseModel):
    """Image input for analysis.

    Attributes:
        uri: A URI pointing to an image.
        sas_token: Optional SAS token appended at request time.
    """

    uri: str = Field(..., min_length=1, description="Image URI.")
    sas_token: Optional[str] = Field(default=None, description="Optional SAS token.")


ContentSource = Union[TextSource, DocumentSource, ImageSource]


class ContentItem(BaseModel):
    """Content wrapper for an analysis request.

    Attributes:
        source: The content source for analysis.
        content_type: Optional hint describing the content type.
    """

    source: ContentSource
    content_type: Optional[str] = Field(
        default=None,
        description="Optional content type hint (e.g., application/pdf).",
    )


class AnalyzeRequest(BaseModel):
    """Request payload for content understanding analysis.

    Attributes:
        content: The content payload for analysis.
        options: Optional analysis options (model, language, etc.).
    """

    content: ContentItem
    options: Dict[str, Any] = Field(default_factory=dict)


class AnalyzeResponse(BaseModel):
    """Standardized response payload for content understanding analysis.

    Attributes:
        request_id: Service-generated request ID.
        status: Status of the analysis.
        result: Service-provided results.
        warnings: Optional warnings returned by the service.
    """

    request_id: Optional[str] = None
    status: str = Field(..., description="Status of the analysis request.")
    result: Dict[str, Any] = Field(default_factory=dict)
    warnings: Optional[list[str]] = None
