﻿"""Client interface for Azure Content Understanding.

This module defines the client configuration and public methods used to
submit content for analysis and build standard request headers.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .exceptions import AuthenticationError, ClientConfigurationError
from .models import AnalyzeRequest, AnalyzeResponse
from .types import Headers, JsonDict


@dataclass
class ClientConfig:
    """Configuration for the ContentUnderstandingClient.

    Attributes:
        endpoint: Base service endpoint.
        api_key: API key used for authentication.
        api_version: Service API version string.
        user_agent: Optional custom User-Agent header value.
    """

    endpoint: str
    api_key: str
    api_version: str
    user_agent: Optional[str] = None


class ContentUnderstandingClient:
    """Client for Azure Content Understanding.

    This client is intentionally lightweight. HTTP transport and actual
    service calls can be implemented later without changing the public API.

    Args:
        endpoint: Base service endpoint.
        api_key: API key for the service.
        api_version: Service API version string.
        user_agent: Optional custom User-Agent string.
    """

    def __init__(
        self,
        endpoint: str,
        api_key: str,
        api_version: str,
        user_agent: Optional[str] = None,
    ) -> None:
        if not endpoint or not endpoint.strip():
            raise ClientConfigurationError("endpoint is required")
        if not api_key or not api_key.strip():
            raise AuthenticationError("api_key is required")
        if not api_version or not api_version.strip():
            raise ClientConfigurationError("api_version is required")

        self._config = ClientConfig(
            endpoint=endpoint.rstrip("/"),
            api_key=api_key,
            api_version=api_version,
            user_agent=user_agent,
        )

    @property
    def config(self) -> ClientConfig:
        """Get the client configuration."""

        return self._config

    def build_headers(self) -> Headers:
        """Build standard HTTP headers for requests.

        Returns:
            Headers: A dictionary of request headers.
        """

        headers: Headers = {
            "Content-Type": "application/json",
            "Ocp-Apim-Subscription-Key": self._config.api_key,
        }
        if self._config.user_agent:
            headers["User-Agent"] = self._config.user_agent
        return headers

    def analyze(self, request: AnalyzeRequest) -> AnalyzeResponse:
        """Analyze content with the service.

        Args:
            request: The analysis request payload.

        Returns:
            AnalyzeResponse: Standardized response model.
        """

        _ = self._serialize_request(request)

        # Placeholder response for now. Implement HTTP transport later.
        return AnalyzeResponse(
            request_id=None,
            status="not_implemented",
            result={},
            warnings=["Service call not implemented yet."],
        )

    def _serialize_request(self, request: AnalyzeRequest) -> JsonDict:
        """Serialize a request to JSON.

        Args:
            request: The analysis request payload.

        Returns:
            JsonDict: A JSON-serializable dictionary.
        """

        return request.model_dump(mode="json", exclude_none=True)
