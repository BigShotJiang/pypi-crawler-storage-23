﻿"""Low-level type aliases for the SDK.

This module centralizes reusable type hints for headers and JSON payloads.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""

from typing import Any, Dict

Headers = Dict[str, str]
JsonDict = Dict[str, Any]
