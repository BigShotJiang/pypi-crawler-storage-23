﻿"""Asynchronous client for Azure Content Understanding.

This module provides an aiohttp-based client for interacting with the Content
Understanding REST APIs, including document analysis and classifier endpoints.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import aiofiles
import aiohttp

from .exceptions import AuthenticationError, ClientConfigurationError, ServiceError

POLL_TIMEOUT_SECONDS = 180


class AsyncAzureContentUnderstandingClient:
    """Asynchronous client for Azure Content Understanding REST APIs.

    The client can either accept an external aiohttp.ClientSession or manage its
    own session lifecycle via async context manager methods.
    """

    PREBUILT_DOCUMENT_ANALYZER_ID: str = "prebuilt-documentAnalyzer"
    MAX_PAGINATION_PAGES: int = 1000

    def __init__(
        self,
        endpoint: str,
        api_version: str,
        api_key: Optional[str] = None,
        token_provider: Optional[Callable[[], str]] = None,
        x_ms_useragent: str = "cu-python-client",
        session: Optional[aiohttp.ClientSession] = None,
    ) -> None:
        if not endpoint or not endpoint.strip():
            raise ClientConfigurationError("endpoint is required")
        if not api_version or not api_version.strip():
            raise ClientConfigurationError("api_version is required")
        if not api_key and not token_provider:
            raise AuthenticationError("api_key or token_provider is required")

        self._endpoint = endpoint.rstrip("/")
        self._api_version = api_version

        token = token_provider() if token_provider and not api_key else None
        self._headers = self._get_headers(api_key, token, x_ms_useragent)

        self._session = session
        self._owns_session = session is None

    async def __aenter__(self) -> "AsyncAzureContentUnderstandingClient":
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the internal session if this client owns it."""
        if self._owns_session and self._session is not None:
            await self._session.close()
        self._session = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            if not self._owns_session:
                raise ClientConfigurationError(
                    "Client session is not initialized. Provide a session or use async context manager."
                )
            self._session = aiohttp.ClientSession()
        return self._session

    async def get_all_analyzers(self) -> Dict[str, Any]:
        """Retrieve all analyzers defined in the Content Understanding resource."""
        all_analyzers: List[Dict[str, Any]] = []
        url = self._get_analyzer_list_url()
        visited_urls = set()
        page_count = 0

        while url:
            if url in visited_urls:
                raise ServiceError("Circular pagination detected.")
            visited_urls.add(url)

            page_count += 1
            if page_count > self.MAX_PAGINATION_PAGES:
                raise ServiceError("Maximum pagination limit exceeded.")

            session = await self._ensure_session()
            async with session.get(url, headers=self._headers) as resp:
                await self._raise_for_status_with_detail(resp)
                payload = await self._safe_json(resp)

            value = payload.get("value", [])
            if not isinstance(value, list):
                raise ServiceError("Invalid response format: 'value' must be a list.")

            all_analyzers.extend(value)
            url = payload.get("nextLink")

        return {"value": all_analyzers}

    async def get_analyzer_detail_by_id(self, analyzer_id: str) -> Dict[str, Any]:
        """Retrieve details for a specific analyzer."""
        session = await self._ensure_session()
        async with session.get(
            self._get_analyzer_url(analyzer_id),
            headers=self._headers,
        ) as resp:
            await self._raise_for_status_with_detail(resp)
            return await self._safe_json(resp)

    async def begin_create_analyzer(
        self,
        analyzer_id: str,
        analyzer_template: Dict[str, Any],
    ) -> aiohttp.ClientResponse:
        """Create or update an analyzer."""
        if not analyzer_id:
            raise ClientConfigurationError("analyzer_id is required")
        if not analyzer_template:
            raise ClientConfigurationError("analyzer_template is required")

        headers = {"Content-Type": "application/json", **self._headers}
        session = await self._ensure_session()
        resp = await session.put(
            self._get_analyzer_url(analyzer_id),
            headers=headers,
            json=analyzer_template,
        )
        await self._raise_for_status_with_detail(resp)
        return resp

    async def delete_analyzer(self, analyzer_id: str) -> aiohttp.ClientResponse:
        """Delete an analyzer."""
        session = await self._ensure_session()
        resp = await session.delete(
            self._get_analyzer_url(analyzer_id),
            headers=self._headers,
        )
        await self._raise_for_status_with_detail(resp)
        return resp

    async def begin_analyze_url(
        self,
        analyzer_id: str,
        url: str,
    ) -> aiohttp.ClientResponse:
        """Submit a document for analysis using a public or SAS URL."""
        if not analyzer_id:
            raise ClientConfigurationError("analyzer_id is required")
        if not url.startswith(("http://", "https://")):
            raise ClientConfigurationError("url must be HTTP or HTTPS")

        payload = {"url": url}
        headers = {"Content-Type": "application/json", **self._headers}

        session = await self._ensure_session()
        resp = await session.post(
            self._get_analyze_url(analyzer_id),
            headers=headers,
            json=payload,
        )
        await self._raise_for_status_with_detail(resp)
        return resp

    async def begin_analyze_binary(
        self,
        analyzer_id: str,
        file_location: str,
    ) -> aiohttp.ClientResponse:
        """Submit a local file for analysis."""
        path = Path(file_location)
        if not path.is_file():
            raise ClientConfigurationError("file_location must be a valid file path")

        async with aiofiles.open(path, "rb") as f:
            data = await f.read()

        headers = {"Content-Type": "application/octet-stream", **self._headers}
        session = await self._ensure_session()
        resp = await session.post(
            self._get_analyze_binary_url(analyzer_id),
            headers=headers,
            data=data,
        )
        await self._raise_for_status_with_detail(resp)
        return resp

    async def poll_result(
        self,
        response: aiohttp.ClientResponse,
        timeout_seconds: int = POLL_TIMEOUT_SECONDS,
        polling_interval_seconds: int = 2,
    ) -> Dict[str, Any]:
        """Poll an analysis operation until completion."""
        operation_location = response.headers.get("operation-location")
        if not operation_location:
            raise ServiceError("Operation location header not found.")

        start_time = time.time()
        while True:
            if time.time() - start_time > timeout_seconds:
                raise TimeoutError("Operation timed out.")

            session = await self._ensure_session()
            async with session.get(
                operation_location,
                headers=self._headers,
            ) as poll_response:
                await self._raise_for_status_with_detail(poll_response)
                payload = await self._safe_json(poll_response)

            status = str(payload.get("status", "")).lower()
            if status == "succeeded":
                return payload
            if status == "failed":
                raise ServiceError("Operation failed.")

            await asyncio.sleep(polling_interval_seconds)

    async def get_result_file(
        self,
        analyze_response: aiohttp.ClientResponse,
        file_id: str,
    ) -> Optional[bytes]:
        """Retrieve a generated result file from an analysis operation."""
        operation_location = analyze_response.headers.get("operation-location")
        if not operation_location:
            raise ServiceError("Operation location header not found.")

        operation_id = operation_location.split("?")[0].rstrip("/").split("/")[-1]
        url = (
            f"{self._endpoint}/contentunderstanding/analyzerResults/"
            f"{operation_id}/files/{file_id}?api-version={self._api_version}"
        )

        session = await self._ensure_session()
        async with session.get(url, headers=self._headers) as resp:
            await self._raise_for_status_with_detail(resp)
            return await resp.read()

    async def begin_create_classifier(
        self,
        classifier_id: str,
        classifier_schema: Dict[str, Any],
    ) -> aiohttp.ClientResponse:
        """Create or update a classifier."""
        if not classifier_id or not classifier_schema:
            raise ClientConfigurationError("classifier_id and classifier_schema are required")

        headers = {"Content-Type": "application/json", **self._headers}
        session = await self._ensure_session()
        resp = await session.put(
            self._get_classifier_url(classifier_id),
            headers=headers,
            json=classifier_schema,
        )
        await self._raise_for_status_with_detail(resp)
        return resp

    async def begin_classify(
        self,
        classifier_id: str,
        file_location: str,
    ) -> aiohttp.ClientResponse:
        """Classify a document using a classifier."""
        headers = dict(self._headers)

        if Path(file_location).is_file():
            async with aiofiles.open(file_location, "rb") as f:
                data = await f.read()
            headers["Content-Type"] = "application/octet-stream"
            session = await self._ensure_session()
            resp = await session.post(
                self._get_classify_url(classifier_id),
                headers=headers,
                data=data,
            )
        elif file_location.startswith(("http://", "https://")):
            headers["Content-Type"] = "application/json"
            session = await self._ensure_session()
            resp = await session.post(
                self._get_classify_url(classifier_id),
                headers=headers,
                json={"url": file_location},
            )
        else:
            raise ClientConfigurationError("file_location must be a valid path or public URL")

        await self._raise_for_status_with_detail(resp)
        return resp

    def _get_headers(
        self,
        api_key: Optional[str],
        api_token: Optional[str],
        x_ms_useragent: str,
    ) -> Dict[str, str]:
        headers = (
            {"Ocp-Apim-Subscription-Key": api_key}
            if api_key
            else {"Authorization": f"Bearer {api_token}"}
        )
        headers["x-ms-useragent"] = x_ms_useragent
        return headers

    async def _raise_for_status_with_detail(
        self,
        response: aiohttp.ClientResponse,
    ) -> None:
        if 200 <= response.status < 300:
            return

        detail = ""
        try:
            payload = await self._safe_json(response)
            detail = json.dumps(payload, indent=2)
        except Exception:
            text = await response.text()
            detail = text[:500] if text else ""

        message = (
            f"{response.status} {response.reason} "
            f"for url: {response.url}\n{detail}"
        )
        raise ServiceError(message)

    async def _safe_json(self, response: aiohttp.ClientResponse) -> Any:
        try:
            return await response.json(content_type=None)
        except Exception:
            text = await response.text()
            try:
                return json.loads(text)
            except Exception:
                return {}

    def _get_analyzer_url(self, analyzer_id: str) -> str:
        return (
            f"{self._endpoint}/contentunderstanding/analyzers/"
            f"{analyzer_id}?api-version={self._api_version}"
        )

    def _get_analyzer_list_url(self) -> str:
        return (
            f"{self._endpoint}/contentunderstanding/analyzers"
            f"?api-version={self._api_version}"
        )

    def _get_analyze_url(self, analyzer_id: str) -> str:
        return (
            f"{self._endpoint}/contentunderstanding/analyzers/"
            f"{analyzer_id}:analyze?api-version={self._api_version}"
        )

    def _get_analyze_binary_url(self, analyzer_id: str) -> str:
        return (
            f"{self._endpoint}/contentunderstanding/analyzers/"
            f"{analyzer_id}:analyzeBinary?api-version={self._api_version}"
        )

    def _get_classifier_url(self, classifier_id: str) -> str:
        return (
            f"{self._endpoint}/contentunderstanding/classifiers/"
            f"{classifier_id}?api-version={self._api_version}"
        )

    def _get_classify_url(self, classifier_id: str) -> str:
        return (
            f"{self._endpoint}/contentunderstanding/classifiers/"
            f"{classifier_id}:classify?api-version={self._api_version}"
        )
