﻿"""Helper utilities for Azure Content Understanding workflows.

This module provides operational helpers and Pydantic models used to execute
and normalize document analysis at a higher level than the raw REST client.

Author: Kintu Sangwan
Email: kintu.sangwn.ref@gmail.com
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Awaitable, Callable, Dict, List, Optional

from pydantic import BaseModel, Field

from .client_async import AsyncAzureContentUnderstandingClient

logger = logging.getLogger(__name__)


class DocumentExecutionRequest(BaseModel):
    """Execution contract for a single document analysis request.

    Attributes:
        document_url: Public or SAS-protected URL of the document to analyze.
        file_name: Original file name of the document.
        file_id: Stable identifier representing the document across pipeline stages.
    """

    document_url: str
    file_name: str = Field(..., min_length=1)
    file_id: str = Field(..., min_length=1)


@dataclass(frozen=True)
class ContentUnderstandingExecutionConfig:
    """Immutable execution configuration for Azure Content Understanding.

    Attributes:
        analyzer_id: Analyzer ID deployed in Azure Content Understanding.
        poll_timeout_seconds: Maximum duration to wait for analysis completion.
        poll_interval_seconds: Interval between polling attempts.
    """

    analyzer_id: str
    poll_timeout_seconds: int = 300
    poll_interval_seconds: int = 2


# Fields that MUST always be present and MUST always be lists
LIST_FIELDS = {
    "mentioned_brands",
    "ai_tags",
    "competitor_brands",
    "key_ingredients",
    "mentioned_countries",
    "key_claims",
    "mentioned_competitors",
}


RawPayloadHandler = Callable[[Dict[str, Any], DocumentExecutionRequest], Awaitable[None]]


class ContentUnderstandingOperationsHelper:
    """Operational wrapper over Azure Content Understanding.

    Responsibilities:
    - Execute document analysis using a configured analyzer
    - Poll analysis jobs until completion
    - Normalize CU output into schema-stable, page-level chunks
    - Enforce deterministic typing for custom fields
    - Provide safe fallbacks when page-level extraction is unavailable
    - Optionally persist raw CU payloads for audit and replay
    """

    def __init__(
        self,
        client: AsyncAzureContentUnderstandingClient,
        config: ContentUnderstandingExecutionConfig,
        raw_payload_handler: Optional[RawPayloadHandler] = None,
    ) -> None:
        if not config.analyzer_id:
            raise ValueError("analyzer_id is required")

        self._client = client
        self._config = config
        self._raw_payload_handler = raw_payload_handler

    async def list_analyzers(self) -> List[str]:
        """List all analyzers available in the CU resource."""
        analyzers = await self._client.get_all_analyzers()
        return [a.get("analyzerId") for a in analyzers.get("value", [])]

    async def get_analyzer_details(self, analyzer_id: Optional[str] = None) -> Dict[str, Any]:
        """Retrieve metadata for a specific analyzer."""
        resolved_id = analyzer_id or self._config.analyzer_id
        return await self._client.get_analyzer_detail_by_id(resolved_id)

    def _normalize_to_list(self, value: Any) -> List[str]:
        """Normalize arbitrary CU field values into List[str]."""
        if value is None:
            return []

        if isinstance(value, list):
            return [str(v).strip() for v in value if str(v).strip()]

        if not isinstance(value, str):
            value = str(value)

        value = value.strip()
        if not value:
            return []

        delimiter = "," if "," in value else " "
        return [item.strip() for item in value.split(delimiter) if item.strip()]

    async def analyze_document(
        self,
        request: DocumentExecutionRequest,
        *,
        analyzer_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Execute analysis for a single document URL and normalize to chunks."""
        try:
            resolved_analyzer_id = analyzer_id or self._config.analyzer_id
            response = await self._client.begin_analyze_url(
                analyzer_id=resolved_analyzer_id,
                url=request.document_url,
            )

            payload = await self._client.poll_result(
                response=response,
                timeout_seconds=self._config.poll_timeout_seconds,
                polling_interval_seconds=self._config.poll_interval_seconds,
            )

            if self._raw_payload_handler:
                asyncio.create_task(self._raw_payload_handler(payload, request))

            return self._build_page_chunks(
                payload=payload,
                file_id=request.file_id,
            )

        except Exception as exc:
            logger.exception("Content Understanding analysis failed")

            return [
                {
                    "id": f"{request.file_id}_failed",
                    "_status": "failed",
                    "file_id": request.file_id,
                    "page_number": None,
                    "total_document_pages": None,
                    "content": "",
                    "usage": {},
                    **{field: [] for field in LIST_FIELDS},
                    "error": str(exc),
                }
            ]

    def _build_page_chunks(
        self,
        payload: Dict[str, Any],
        file_id: str,
    ) -> List[Dict[str, Any]]:
        """Transform raw CU output into page-level chunks."""
        status = payload.get("status")
        normalized_status = self._normalize_status(status)
        usage = payload.get("usage", {})

        result = payload.get("result", {})
        contents_list = result.get("contents", [])

        if not contents_list:
            return []

        contents = contents_list[-1]
        extracted_fields = self._extract_custom_fields(contents.get("fields", {}))

        start_page = int(contents.get("startPageNumber", 1))
        end_page = int(contents.get("endPageNumber", start_page))
        total_pages = end_page - start_page + 1

        pages = contents.get("pages", [])
        chunks: List[Dict[str, Any]] = []

        if pages:
            for page in pages:
                page_number = int(page.get("pageNumber"))
                page_text = "\n".join(
                    line.get("content", "") for line in page.get("lines", [])
                ).strip()

                chunks.append(
                    {
                        "id": f"{file_id}_page_{page_number}",
                        "_status": normalized_status,
                        "file_id": file_id,
                        "page_number": page_number,
                        "total_document_pages": total_pages,
                        "content": page_text,
                        "usage": usage,
                        **extracted_fields,
                        "used_markdown_fallback": False,
                    }
                )

            return chunks

        fallback_text = contents.get("markdown", "").strip()
        if not fallback_text:
            return []

        return self._build_markdown_fallback_chunks(
            fallback_text=fallback_text,
            file_id=file_id,
            start_page=start_page,
            total_pages=total_pages,
            status=normalized_status,
            usage=usage,
            extracted_fields=extracted_fields,
        )

    def _build_markdown_fallback_chunks(
        self,
        *,
        fallback_text: str,
        file_id: str,
        start_page: int,
        total_pages: int,
        status: Optional[str],
        usage: Dict[str, Any],
        extracted_fields: Dict[str, Any],
        max_chars: int = 12000,
        overlap_chars: int = 800,
    ) -> List[Dict[str, Any]]:
        """Chunk markdown fallback text while preserving structure."""
        sections = self._split_markdown_sections(fallback_text)
        chunks_text: List[str] = []
        current: List[str] = []
        current_len = 0

        for section in sections:
            section_len = len(section)
            if section_len > max_chars:
                if current:
                    chunks_text.append("\n".join(current).strip())
                    current = []
                    current_len = 0

                chunks_text.extend(self._split_large_block(section, max_chars=max_chars))
                continue

            if current_len + section_len + 1 > max_chars and current:
                chunks_text.append("\n".join(current).strip())
                current = [section]
                current_len = section_len
            else:
                if current:
                    current.append(section)
                    current_len += section_len + 1
                else:
                    current = [section]
                    current_len = section_len

        if current:
            chunks_text.append("\n".join(current).strip())

        if overlap_chars > 0 and len(chunks_text) > 1:
            chunks_text = self._apply_overlap(chunks_text, overlap_chars)

        chunks: List[Dict[str, Any]] = []
        for idx, chunk_text in enumerate(chunks_text, start=1):
            chunks.append(
                {
                    "id": f"{file_id}_page_{start_page}_chunk_{idx}",
                    "_status": status,
                    "file_id": file_id,
                    "page_number": start_page,
                    "total_document_pages": total_pages,
                    "content": chunk_text,
                    "usage": usage,
                    **extracted_fields,
                    "used_markdown_fallback": True,
                }
            )

        return chunks

    def _split_markdown_sections(self, text: str) -> List[str]:
        """Split markdown into sections, each starting with a heading."""
        lines = text.splitlines()
        sections: List[List[str]] = []
        current: List[str] = []
        heading_re = re.compile(r"^#{1,6}\s+")

        for line in lines:
            if heading_re.match(line) and current:
                sections.append(current)
                current = [line]
            else:
                current.append(line)

        if current:
            sections.append(current)

        return ["\n".join(section).strip() for section in sections if "\n".join(section).strip()]

    def _split_large_block(self, block: str, *, max_chars: int) -> List[str]:
        """Split a large block by paragraphs to fit within max_chars."""
        paragraphs = self._split_paragraphs(block)
        chunks: List[str] = []
        current: List[str] = []
        current_len = 0

        for para in paragraphs:
            para_len = len(para)
            if para_len > max_chars:
                if current:
                    chunks.append("\n\n".join(current).strip())
                    current = []
                    current_len = 0

                chunks.extend(self._split_hard_paragraph(para, max_chars=max_chars))
                continue

            if current_len + para_len + 2 > max_chars and current:
                chunks.append("\n\n".join(current).strip())
                current = [para]
                current_len = para_len
            else:
                if current:
                    current.append(para)
                    current_len += para_len + 2
                else:
                    current = [para]
                    current_len = para_len

        if current:
            chunks.append("\n\n".join(current).strip())

        return chunks

    def _split_paragraphs(self, text: str) -> List[str]:
        """Split text into paragraphs separated by blank lines."""
        parts = re.split(r"\n\s*\n", text.strip())
        return [p.strip() for p in parts if p.strip()]

    def _split_hard_paragraph(self, paragraph: str, *, max_chars: int) -> List[str]:
        """Last-resort split for a single huge paragraph by lines."""
        lines = paragraph.splitlines()
        chunks: List[str] = []
        current: List[str] = []
        current_len = 0

        for line in lines:
            line_len = len(line)
            if current_len + line_len + 1 > max_chars and current:
                chunks.append("\n".join(current).strip())
                current = [line]
                current_len = line_len
            else:
                if current:
                    current.append(line)
                    current_len += line_len + 1
                else:
                    current = [line]
                    current_len = line_len

        if current:
            chunks.append("\n".join(current).strip())

        return chunks

    def _apply_overlap(self, chunks_text: List[str], overlap_chars: int) -> List[str]:
        """Prepend a tail slice of the previous chunk to the next."""
        overlapped: List[str] = [chunks_text[0]]
        for prev, curr in zip(chunks_text, chunks_text[1:]):
            tail = self._paragraph_tail(prev, overlap_chars)
            if tail:
                overlapped.append(f"{tail}\n\n{curr}".strip())
            else:
                overlapped.append(curr)
        return overlapped

    def _paragraph_tail(self, text: str, max_chars: int) -> str:
        """Return the last whole paragraphs whose total length <= max_chars."""
        paragraphs = self._split_paragraphs(text)
        tail: List[str] = []
        total = 0
        for para in reversed(paragraphs):
            add_len = len(para) + (2 if tail else 0)
            if total + add_len > max_chars:
                break
            tail.insert(0, para)
            total += add_len
        return "\n\n".join(tail).strip()

    def _extract_custom_fields(self, fields: Dict[str, Any]) -> Dict[str, Any]:
        """Extract and normalize custom analyzer fields."""
        extracted: Dict[str, Any] = {}

        for key, value in fields.items():
            if not isinstance(value, dict):
                continue

            raw_value = value.get("valueString")

            if key in LIST_FIELDS:
                extracted[key] = self._normalize_to_list(raw_value)
            else:
                extracted[key] = raw_value

        for field in LIST_FIELDS:
            extracted.setdefault(field, [])

        return extracted

    @staticmethod
    def _normalize_status(status: Optional[str]) -> str:
        if not status:
            return "failed"
        lowered = str(status).strip().lower()
        if lowered in {"succeeded", "success"}:
            return "success"
        if lowered in {"failed", "error"}:
            return "failed"
        return lowered


async def default_raw_payload_logger(
    payload: Dict[str, Any],
    request: DocumentExecutionRequest,
) -> None:
    """Example raw payload handler that logs to stdout as JSON."""
    wrapped_payload = {
        "file_id": request.file_id,
        "file_name": request.file_name,
        "analysis_run_utc": datetime.utcnow().isoformat() + "Z",
        "content_understanding_response": payload,
    }
    logger.info(json.dumps(wrapped_payload, indent=2))
