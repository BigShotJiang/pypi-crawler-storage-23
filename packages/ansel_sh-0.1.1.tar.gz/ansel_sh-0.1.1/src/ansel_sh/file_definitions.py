"""
Shared file definitions and format adapters.

A FileDefinition describes the schema (name, row model, headers) used to pass
structured data between domain modules and agents. Row models are
format-agnostic; adapters handle CSV (or future formats).

Manifests (dimension data: entities, file metadata) and snapshots (fact data:
time series) are both typed CSV files with a row model -- this module provides
the common base for both.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping, Sequence
from enum import Enum, StrEnum
from pathlib import Path
from types import UnionType
from typing import (
    ClassVar,
    Generic,
    Protocol,
    TypeVar,
    cast,
    get_args,
    get_origin,
)

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .agents.observability import add_trace_tags
from .csv_utils import (
    ValidationIssue,
    ValidationResult,
    normalize_row_for_model,
    read_csv_rows,
    serialize_csv_value,
    validate_csv_structure,
    write_csv,
)
from .markdown_utils import (
    read_markdown,
    validate_markdown_structure,
    write_markdown,
)
from .models import DescribedStrEnum

# ============================================
# 1. FILE FORMAT
# ============================================


class FileFormat(StrEnum):
    csv = "csv"
    markdown = "md"

    @property
    def extension(self) -> str:
        return self.value


# ============================================
# 2. FORMAT ADAPTERS
# ============================================


ModelT = TypeVar("ModelT", bound=BaseModel)


class FileAdapter(Protocol[ModelT]):
    """Protocol for format-specific file IO adapters."""

    def dump(self, path: Path, rows: Iterable[ModelT], row_model: type[ModelT], /) -> None:
        """Serialize rows to a file."""
        ...

    def load(self, path: Path, row_model: type[ModelT], /) -> list[ModelT]:
        """Deserialize rows from a file."""
        ...

    def validate(
        self,
        path: Path,
        row_model: type[ModelT],
        /,
        *,
        row_key: str | None,
        mutable_fields: Sequence[str] = (),
        immutable_values: Mapping[str, Mapping[str, str]] | None = None,
    ) -> ValidationResult:
        """Validate file structure and row data."""
        ...


class CsvFileAdapter(Generic[ModelT]):
    """CSV adapter that handles list fields and scalar normalization."""

    def dump(self, path: Path, rows: Iterable[ModelT], row_model: type[ModelT], /) -> None:
        """Write rows to a CSV file with headers derived from the row model's field order.

        Enums and datetimes are coerced to strings; lists become
        comma-separated values; ``None`` becomes an empty cell.
        """
        headers = tuple(row_model.model_fields.keys())
        csv_rows: list[list[str]] = []
        for row in rows:
            data = row.model_dump()
            csv_rows.append([serialize_csv_value(data.get(header)) for header in headers])
        write_csv(path, headers, csv_rows)

    def load(self, path: Path, row_model: type[ModelT], /) -> list[ModelT]:
        """Load rows from a CSV into typed Pydantic models.

        Rows that fail model validation are silently skipped — call
        ``validate()`` first to capture and report issues.
        """
        _, raw_rows = read_csv_rows(path)
        parsed_rows: list[ModelT] = []
        for raw_row in raw_rows:
            normalized = normalize_row_for_model(raw_row, row_model)
            try:
                parsed_rows.append(row_model.model_validate(normalized))
            except Exception:
                continue
        return parsed_rows

    def validate(
        self,
        path: Path,
        row_model: type[ModelT],
        /,
        *,
        row_key: str | None,
        mutable_fields: Sequence[str] = (),
        immutable_values: Mapping[str, Mapping[str, str]] | None = None,
    ) -> ValidationResult:
        """Validate CSV structure and row data via validate_csv_structure."""
        return validate_csv_structure(
            path=path,
            row_model=row_model,
            row_key=row_key,
            mutable_fields=mutable_fields,
            immutable_values=immutable_values,
        )


class MarkdownFileAdapter(Generic[ModelT]):
    """Adapter for markdown files with YAML frontmatter.

    Single-entry files: frontmatter holds all fields except a designated
    *content* field (default ``"content"``), which maps to the markdown body.
    """

    content_field: str = "content"

    def dump(self, path: Path, rows: Iterable[ModelT], row_model: type[ModelT], /) -> None:
        """Write a single entry as frontmatter + content body.

        Takes the first row from *rows*; remaining rows are ignored.
        An empty iterable writes a template with empty-string values.
        """
        row = next(iter(rows), None)
        if row is not None:
            data = row.model_dump()
        else:
            data = {name: "" for name in row_model.model_fields}

        content = str(data.pop(self.content_field, ""))
        metadata = {k: str(v) for k, v in data.items()}
        write_markdown(path, metadata, content)

    def load(self, path: Path, row_model: type[ModelT], /) -> list[ModelT]:
        """Load a single entry from frontmatter + content body.

        Returns a single-element list on success, empty list on validation failure.
        """
        metadata, content = read_markdown(path)
        row_data = {**metadata, self.content_field: content.strip()}
        try:
            return [row_model.model_validate(row_data)]
        except Exception:
            return []

    def validate(
        self,
        path: Path,
        row_model: type[ModelT],
        /,
        *,
        row_key: str | None,
        mutable_fields: Sequence[str] = (),
        immutable_values: Mapping[str, Mapping[str, str]] | None = None,
    ) -> ValidationResult:
        """Validate markdown structure and frontmatter via validate_markdown_structure.

        For single-entry markdown files, ``immutable_values`` is flattened:
        ``{"key": {"field": "value"}}`` → ``{"field": "value"}`` using the
        first (only) entry.
        """
        flat_immutable: Mapping[str, str] | None = None
        if immutable_values:
            # Single-entry files have one key; flatten to {field: value}.
            first_entry = next(iter(immutable_values.values()), None)
            flat_immutable = first_entry

        return validate_markdown_structure(
            path=path,
            row_model=row_model,
            row_key=row_key,
            content_field=self.content_field,
            mutable_fields=mutable_fields,
            immutable_values=flat_immutable,
        )


_FORMAT_ADAPTERS: dict[FileFormat, type[FileAdapter[BaseModel]]] = {
    FileFormat.csv: CsvFileAdapter,
    FileFormat.markdown: MarkdownFileAdapter,
}


# ============================================
# 3. FILE DEFINITION
# ============================================


def _extract_enum_type(annotation: object) -> type[Enum] | None:
    """Extract an Enum subclass from a field annotation.

    Handles ``SomeEnum``, ``list[SomeEnum]``, and ``SomeEnum | None``.
    """
    origin = get_origin(annotation)
    args: tuple[object, ...] = get_args(annotation)

    # list[SomeEnum]
    if origin is list and args:
        inner = args[0]
        if isinstance(inner, type) and issubclass(inner, Enum):
            return inner
        return None

    # SomeEnum | None  (types.UnionType)
    if isinstance(annotation, UnionType):
        for arg in args:
            if isinstance(arg, type) and issubclass(arg, Enum):
                return arg
        return None

    # Direct SomeEnum
    if isinstance(annotation, type) and issubclass(annotation, Enum):
        return annotation

    return None


class FileDefinition(BaseModel, Generic[ModelT]):
    """Schema for a structured file exchanged between domain modules and agents.

    Each file flows through a sandbox lifecycle:

    1. **Creation** — ``dump()`` writes a file (often a blank template) into
       the sandbox for an agent to populate.
    2. **Agent interaction** — the agent reads the file, fills in the
       ``mutable_fields``, and writes it back.
    3. **Validation** — ``validate()`` checks structural integrity and that
       the agent did not modify read-only fields.
    4. **Loading** — ``load()`` / ``load_one()`` deserializes the agent's
       output into typed Pydantic models for downstream domain logic.
    """

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)

    stem: str = Field(
        description=(
            "Bare filename without extension (e.g. 'files_manifest'). "
            "Combined with format to produce the on-disk filename. "
            "Also used as the human-readable prefix in validation log messages and trace tags."
        ),
    )
    description: str
    row_model: type[ModelT] = Field(
        description="Pydantic model defining the schema for each row/entry.",
    )
    row_key: str | None = Field(
        description=(
            "Field name that uniquely identifies each row. "
            "Used for immutable-value indexing and validation error labels. "
            "None for single-entry files with no natural key."
        ),
    )
    format: FileFormat = Field(
        default=FileFormat.csv,
        description="On-disk format; determines which adapter handles IO.",
    )
    mutable_fields: tuple[str, ...] = Field(
        default=(),
        description=(
            "Fields the agent is allowed to edit. "
            "All others are read-only; validate() flags changes as immutable_mutation issues."
        ),
    )

    @model_validator(mode="after")
    def _check_field_references(self) -> FileDefinition[ModelT]:
        model_fields = set(self.row_model.model_fields.keys())
        if self.row_key is not None and self.row_key not in model_fields:
            raise ValueError(f"row_key={self.row_key!r} not in {self.row_model.__name__} fields")
        invalid = set(self.mutable_fields) - model_fields
        if invalid:
            raise ValueError(f"mutable_fields {invalid} not in {self.row_model.__name__} fields")
        return self

    @property
    def filename(self) -> str:
        """Full filename with extension derived from format (e.g. ``"files_manifest.csv"``)."""
        return f"{self.stem}.{self.format.extension}"

    @property
    def _adapter(self) -> FileAdapter[ModelT]:
        """Resolve the format-specific adapter."""
        adapter_cls = _FORMAT_ADAPTERS.get(self.format)
        if adapter_cls is None:
            raise ValueError(f"no adapter for format {self.format!r}")
        return cast(FileAdapter[ModelT], adapter_cls())

    @property
    def headers(self) -> tuple[str, ...]:
        """Return header names in row-model field order."""
        return tuple(self.row_model.model_fields.keys())

    def immutable_row_values(
        self,
        rows: Iterable[ModelT],
    ) -> dict[str, dict[str, str]]:
        """Snapshot read-only field values before agent execution.

        Call this before handing the file to an agent, then pass the result
        to ``validate(immutable_values=...)`` afterward to detect
        unauthorized mutations.

        Returns ``{row_key_value: {field: str_value}}`` for every field
        **not** in ``mutable_fields``, keyed by each row's ``row_key``
        value.

        Raises:
            ValueError: If ``self.row_key`` is None (can't uniquely
                identify rows without a key).
        """
        if self.row_key is None:
            raise ValueError("immutable_row_values requires a row_key")
        immutable = [f for f in self.headers if f not in self.mutable_fields]
        result: dict[str, dict[str, str]] = {}
        for row in rows:
            data: dict[str, object] = row.model_dump()
            key = str(data[self.row_key])
            result[key] = {f: str(data.get(f, "")) for f in immutable}
        return result

    def dump(self, sandbox_dir: Path, rows: Iterable[ModelT], /) -> str:
        """Write rows to the sandbox, creating the file agents will interact with.

        An empty iterable writes a headers-only / empty-template file — the
        typical pattern for files the agent is expected to populate from
        scratch. The file is created or overwritten unconditionally.

        Returns the sandbox-relative path (i.e. the filename) so callers
        can pass it directly to agent inputs.
        """
        self._adapter.dump(sandbox_dir / self.filename, rows, self.row_model)
        return self.filename

    def load(self, sandbox_dir: Path, /) -> list[ModelT]:
        """Deserialize the agent's output into typed Pydantic models.

        Rows that fail model validation are silently dropped. Always call
        ``validate()`` first so issues are logged and traced before any
        data is lost here.
        """
        return self._adapter.load(sandbox_dir / self.filename, self.row_model)

    def load_one(self, sandbox_dir: Path, /) -> ModelT:
        """Load exactly one entry, or raise if the count is wrong.

        Intended for single-entry formats like markdown with frontmatter
        where the file represents one object (e.g. model instructions for
        a single entity).
        """
        rows = self.load(sandbox_dir)
        if len(rows) != 1:
            raise ValueError(f"expected exactly 1 entry in {self.filename}, got {len(rows)}")
        return rows[0]

    def validate_file(
        self,
        sandbox_dir: Path,
        /,
        *,
        immutable_values: Mapping[str, Mapping[str, str]] | None = None,
    ) -> ValidationResult:
        """Check structural integrity and immutability after agent execution.

        Detects missing/extra headers, unparseable rows, and unauthorized
        changes to read-only fields (when ``immutable_values`` is provided
        from a prior ``immutable_row_values()`` call).

        When issues are found, logs a WARNING with details and adds issue
        codes as Laminar trace tags for observability. The returned
        ``ValidationResult`` is mainly used in tests; production callers
        rely on the logging/tracing side effects.
        """
        result = self._adapter.validate(
            sandbox_dir / self.filename,
            self.row_model,
            row_key=self.row_key,
            mutable_fields=self.mutable_fields,
            immutable_values=immutable_values,
        )
        if result.issues:
            self._report_issues(result.issues)
        return result

    def _report_issues(self, issues: tuple[ValidationIssue, ...]) -> None:
        """Log validation issues and add trace tags."""
        prefix = self.stem
        logger = logging.getLogger("ansel")

        formatted: list[tuple[str, str]] = []
        for issue in issues:
            detail = issue.detail
            if issue.row_key:
                detail = f"{issue.row_key} {detail}"
            elif issue.row_index is not None:
                detail = f"row {issue.row_index} {detail}"
            formatted.append((f"{prefix}:{issue.code}", detail))

        label = prefix.replace("_", " ").title()
        logger.warning(
            "%s issues:\n%s",
            label,
            "\n".join(f"- {code}: {detail}" for code, detail in formatted),
        )
        add_trace_tags(sorted({code for code, _ in formatted}))

    @property
    def column_descriptions(self) -> dict[str, str]:
        """Field-name-to-description mapping for building agent system prompts.

        Only includes fields that have a ``Field(description=...)`` set.
        """
        return {
            name: info.description
            for name, info in self.row_model.model_fields.items()
            if info.description
        }

    @property
    def enum_value_definitions(self) -> dict[str, dict[str, str]]:
        """Allowed enum values and their meanings, for agent system prompts.

        Returns ``{field: {value: description}}`` for every
        ``DescribedStrEnum`` field (including ``list[SomeEnum]``). Plain
        ``Enum`` fields are skipped since they lack per-value descriptions.
        """
        result: dict[str, dict[str, str]] = {}
        for name, field_info in self.row_model.model_fields.items():
            enum_type = _extract_enum_type(field_info.annotation)
            if enum_type is not None and issubclass(enum_type, DescribedStrEnum):
                result[name] = enum_type.value_descriptions()
        return result
