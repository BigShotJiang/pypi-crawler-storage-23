"""
ForecastModel domain module.

Sections:
1. ForecastModel Entity
2. Domain Events
3. Agent Runners
4. Public Entrypoint
5. Resolution
"""

from __future__ import annotations

from collections.abc import Awaitable
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Protocol, override

from claude_agent_sdk import ResultMessage
from pydantic import BaseModel, Field

from .agents import run_agent
from .agents.forecast_models import (
    BASE_INSTRUCTION_ENTRY,
    FORECAST_MODEL_ANALYST,
    FORECAST_MODEL_TRAINER,
    ForecastModelAnalystInput,
    ForecastModelTrainerInput,
)
from .agents.observability import observe
from .entities import Entity, resolve_entities
from .events import Event, event, log_events, publish
from .file_schemas import (
    BASE_INSTRUCTION,
    FILES_MANIFEST,
    MODEL_INSTRUCTIONS,
    TESTING_SNAPSHOT,
    TRAINING_SNAPSHOT,
    FilesManifestEntry,
    ModelInstructionsEntry,
    create_snapshot,
)
from .files import FileResult, resolve_files
from .models import File, ForecastSettings
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .storage import materialize, stage_files_to_sandbox
from .utils import generate_id, utc_now

# ============================================
# 1. FORECAST MODEL ENTITY
# ============================================


class ForecastModel(BaseModel):
    """
    Trained forecasting model.

    Created by running the model trainer agent in two steps:
    1. Data preparation — populates training + testing time series snapshots.
    2. Model configuration — produces an instructions file and evidence.

    Attributes:
        id: Unique identifier (mdl_xxx).
        entity_id: ID of the entity this model is trained for.
        settings: Forecast settings used for training.
        instructions: Model instructions file produced by step 2.
        trained: Training data snapshot (time series CSV).
        tested: Testing/holdout data snapshot (time series CSV).
        status: Current model status.
        created_at: When this model was created.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("mdl"))

    # Entity reference
    entity_id: str

    settings: ForecastSettings

    # Outputs
    instructions: File
    trained: File
    tested: File

    status: Literal["training", "ready"] = "training"

    # Time
    created_at: datetime = Field(default_factory=utc_now)


# ============================================
# 2. DOMAIN EVENTS (stubbed)
# ============================================


@event
class ModelTrainingStarted(Event, frozen=True):
    entity_id: str

    @override
    def message(self) -> str:
        return f"Start training model for entity {self.entity_id}"


@event
class ModelDataPrepCompleted(Event, frozen=True):
    entity_id: str

    @override
    def message(self) -> str:
        return f"Training data prepared for entity {self.entity_id}"


@event
class ModelTrainingCompleted(Event, frozen=True):
    model_id: str
    entity_id: str

    @override
    def message(self) -> str:
        return f"Model {self.model_id} trained for entity {self.entity_id}"


# ============================================
# 3. AGENT RUNNERS
# ============================================


@dataclass(frozen=True)
class ForecastModelAnalystResult:
    """Output from a forecast model analyst run."""

    training: FileResult
    testing: FileResult
    result: ResultMessage


@dataclass(frozen=True)
class ForecastModelTrainerResult:
    """Output from a forecast model trainer run."""

    instructions: FileResult
    result: ResultMessage


class ForecastModelAnalystRunner(Protocol):
    def __call__(
        self,
        entity: Entity,
        files: list[File],
        settings: ForecastSettings,
        /,
    ) -> Awaitable[ForecastModelAnalystResult]: ...


class ForecastModelTrainerRunner(Protocol):
    def __call__(
        self,
        entity: Entity,
        training_file: File,
        settings: ForecastSettings,
        /,
    ) -> Awaitable[ForecastModelTrainerResult]: ...


@observe(name="forecast_model_analyst")
async def _run_forecast_model_analyst(
    entity: Entity,
    files: list[File],
    settings: ForecastSettings,
    /,
) -> ForecastModelAnalystResult:
    """Run step 1: populate training + testing snapshots from user files.

    The agent receives the files manifest, user files, the base instruction,
    and empty training/testing snapshot CSVs in the sandbox. It reads the
    base instruction for context on how to split data, then populates both
    snapshot files.
    """
    if not files:
        raise ValueError("files required")

    # Create interval-aware snapshot definitions for date format validation.
    training_snapshot = create_snapshot(
        settings.interval, TRAINING_SNAPSHOT.stem, TRAINING_SNAPSHOT.description
    )
    testing_snapshot = create_snapshot(
        settings.interval, TESTING_SNAPSHOT.stem, TESTING_SNAPSHOT.description
    )

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        manifest_entries = [FilesManifestEntry.from_file(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, manifest_entries)

        # Write empty snapshot files (headers only) for the agent to populate.
        training_snapshot_path = training_snapshot.dump(sandbox_dir, [])
        testing_snapshot_path = testing_snapshot.dump(sandbox_dir, [])

        # Write the base instruction so the agent can reference it.
        base_instruction_path = BASE_INSTRUCTION.dump(sandbox_dir, [BASE_INSTRUCTION_ENTRY])

        agent_input = ForecastModelAnalystInput(
            entity_name=entity.name,
            entity_aggregation=entity.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            files_manifest_path=files_manifest_path,
            training_snapshot_path=training_snapshot_path,
            testing_snapshot_path=testing_snapshot_path,
            base_instruction_path=base_instruction_path,
        )

        result_message = await run_agent(FORECAST_MODEL_ANALYST, agent_input, sandbox_dir)

        # Validate agent output in sandbox before materialization
        training_validation_result = training_snapshot.validate_file(sandbox_dir)
        testing_validation_result = testing_snapshot.validate_file(sandbox_dir)

        # Materialize agent outputs
        training_file = materialize(
            training_snapshot, sandbox_dir, agent_name="forecast_model_analyst"
        )
        testing_file = materialize(
            testing_snapshot, sandbox_dir, agent_name="forecast_model_analyst"
        )

        return ForecastModelAnalystResult(
            training=FileResult(file=training_file, issues=training_validation_result.issues),
            testing=FileResult(file=testing_file, issues=testing_validation_result.issues),
            result=result_message,
        )


@observe(name="forecast_model_trainer")
async def _run_forecast_model_trainer(
    entity: Entity,
    training_file: File,
    settings: ForecastSettings,
    /,
) -> ForecastModelTrainerResult:
    """Run step 2: create model instructions from training data and base instruction.

    The agent receives the training snapshot (read-only context), the base
    instruction, and an instructions template (mutable). It writes improved
    instructions based on patterns learned from the training data.
    """
    # Load training entries from the materialized analyst output.
    training_entries = TRAINING_SNAPSHOT.load(training_file.local_path.parent)

    with create_agent_sandbox_dir() as sandbox_dir:
        # Dump training snapshot into sandbox (read-only context).
        training_snapshot_path = TRAINING_SNAPSHOT.dump(sandbox_dir, training_entries)

        # Write the base instruction so the agent can reference it.
        base_instruction_path = BASE_INSTRUCTION.dump(sandbox_dir, [BASE_INSTRUCTION_ENTRY])

        # Dump a template instructions file with immutable frontmatter.
        template_entry = ModelInstructionsEntry(
            entity_id=entity.id,
            entity_name=entity.name,
        )
        _ = MODEL_INSTRUCTIONS.dump(sandbox_dir, [template_entry])
        immutable_values = MODEL_INSTRUCTIONS.immutable_row_values([template_entry])

        agent_input = ForecastModelTrainerInput(
            entity_name=entity.name,
            entity_aggregation=entity.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            training_snapshot_path=training_snapshot_path,
            base_instruction_path=base_instruction_path,
        )

        result_message = await run_agent(FORECAST_MODEL_TRAINER, agent_input, sandbox_dir)

        # Validate the instructions file the agent wrote.
        instructions_validation_result = MODEL_INSTRUCTIONS.validate_file(
            sandbox_dir, immutable_values=immutable_values
        )

        # Materialize the instructions file.
        instructions_file = materialize(
            MODEL_INSTRUCTIONS, sandbox_dir, agent_name="forecast_model_trainer"
        )

        return ForecastModelTrainerResult(
            instructions=FileResult(
                file=instructions_file, issues=instructions_validation_result.issues
            ),
            result=result_message,
        )


# ============================================
# 4. PUBLIC ENTRYPOINT
# ============================================


@log_events
async def forecast_model(
    entity: Entity | None = None,
    files: File | list[File] | None = None,
    settings: ForecastSettings | None = None,
) -> list[ForecastModel]:
    """
    Public entrypoint: resolve files, entity, then train a forecast model.

    Handles run context, file resolution (ensuring classification), entity
    resolution (if not provided), and model training end-to-end.

    Args:
        entity: Entity to train the model for. When None, files are analyzed
            and the first discovered entity is used.
        files: Input data files. Accepts a single File, a list, or None to
            discover from the default data directory. Files are classified
            automatically when needed.
        settings: Forecast settings. Defaults to standard settings when None.

    Returns:
        Trained forecast models.
    """
    with with_run_context():
        # Resolve files — ensures classification.
        if files is None:
            resolved_files = await resolve_files()
        else:
            input_files = [files] if isinstance(files, File) else files
            resolved_files = await resolve_files(input_files)

        # Resolve entity — discover from files when not provided.
        if entity is None:
            entities = await resolve_entities(resolved_files)
            if not entities:
                raise ValueError("no entities found")
            entity = entities[0]

        resolved_settings = settings if settings is not None else ForecastSettings()

        model = await resolve_forecast_model(entity, resolved_files, resolved_settings)
        return [model]


# ============================================
# 5. RESOLUTION
# ============================================


async def resolve_forecast_model(
    entity: Entity,
    files: list[File],
    settings: ForecastSettings,
    analyst_runner: ForecastModelAnalystRunner = _run_forecast_model_analyst,
    trainer_runner: ForecastModelTrainerRunner = _run_forecast_model_trainer,
    /,
) -> ForecastModel:
    """
    Internal resolver: run analyst then trainer agents sequentially.

    Called after entities and files are resolved. Accepts optional runner
    overrides for testing without live agent calls.

    Args:
        entity: The entity to train a model for (first resolved entity).
        files: Classified files to use for training.
        settings: Forecast settings (target, interval, horizon).
        analyst_runner: Analyzes files and populates training + testing snapshots.
        trainer_runner: Trains model and produces instructions file + evidence.

    Returns:
        Trained ForecastModel.

    Raises:
        ValueError: If files is empty.
    """
    if not files:
        raise ValueError("files required")

    publish(ModelTrainingStarted(entity_id=entity.id))

    # Analyst: data preparation — training + testing snapshots
    analyst_result = await analyst_runner(entity, files, settings)
    training_file = analyst_result.training.file
    # TODO: testing snapshot is produced but unused — decide if it should be
    # used for backtesting/evaluation, passed to a separate scoring agent,
    # or removed from the analyst output entirely.
    testing_file = analyst_result.testing.file
    publish(ModelDataPrepCompleted(entity_id=entity.id))

    # Trainer: model configuration — instructions from training data + base instruction
    trainer_result = await trainer_runner(entity, training_file, settings)
    model = ForecastModel(
        entity_id=entity.id,
        settings=settings,
        instructions=trainer_result.instructions.file,
        trained=training_file,
        tested=testing_file,
        status="ready",
    )

    publish(ModelTrainingCompleted(model_id=model.id, entity_id=entity.id))
    return model
