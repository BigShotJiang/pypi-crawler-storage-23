"""Shared utility functions and constants."""

from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4

# Type aliases
ForecastInterval = Literal["week", "month", "quarter"]

# Defaults
DEFAULT_TARGET = "demand"
DEFAULT_FORECAST_INTERVAL: ForecastInterval = "month"
DEFAULT_HORIZON = 12


def utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


def generate_id(prefix: str) -> str:
    """Generate a prefixed unique ID."""
    return f"{prefix}_{uuid4().hex[:12]}"
