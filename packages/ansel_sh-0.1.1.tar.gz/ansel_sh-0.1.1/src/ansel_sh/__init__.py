"""
Ansel — Demand forecasting API for AIs.

Auditable demand forecasts from raw data for operational planning.

Quick start:

    from ansel_sh import forecasts

    # User-provided data files are auto-discovered
    result = forecasts()
"""

import asyncio

from .entities import Entity
from .entities import entities as entities_async
from .files import files as files_async
from .forecast_models import ForecastModel
from .forecast_models import forecast_model as models_async
from .forecasts import Forecast
from .forecasts import forecast as forecasts_async
from .models import File, ForecastSettings


def forecasts(
    entity: Entity | None = None,
    files: File | list[File] | None = None,
    model: ForecastModel | None = None,
    settings: ForecastSettings | None = None,
) -> list[Forecast]:
    """Generate forecasts. Sync wrapper around forecasts_async."""
    return asyncio.run(forecasts_async(entity=entity, files=files, model=model, settings=settings))


def models(
    entity: Entity | None = None,
    files: File | list[File] | None = None,
    settings: ForecastSettings | None = None,
) -> list[ForecastModel]:
    """Train forecast models. Sync wrapper around models_async."""
    return asyncio.run(models_async(entity=entity, files=files, settings=settings))


def entities(files: File | list[File] | None = None) -> list[Entity]:
    """Extract entities from files. Sync wrapper around entities_async."""
    return asyncio.run(entities_async(files=files))


def files(files: File | list[File] | None = None) -> list[File]:
    """Resolve and classify files. Sync wrapper around files_async."""
    return asyncio.run(files_async(files=files))


__all__ = [
    # Data types
    "Entity",
    "File",
    "Forecast",
    "ForecastModel",
    # Sync API (default)
    "forecasts",
    "models",
    "entities",
    "files",
    # Async API
    "forecasts_async",
    "models_async",
    "entities_async",
    "files_async",
]
