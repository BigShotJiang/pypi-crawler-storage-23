"""Markdown utilities for YAML frontmatter parsing, serialization, and validation.

Parallel to ``csv_utils`` — standalone pure functions with no internal deps
except reusing ``ValidationIssue`` and ``ValidationResult``.

File format::

    ---
    entity_id: ent_123
    entity_name: iPhone 16 Pro Max
    ---

    [content here]

Frontmatter is flat ``key: value`` lines (split on first ``:`` only).
No PyYAML dependency — parsed manually.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path

from pydantic import BaseModel, ValidationError

from .csv_utils import ValidationIssue, ValidationResult

_DELIMITER = "---"


def parse_frontmatter(text: str, /) -> tuple[dict[str, str], str]:
    """Parse YAML frontmatter from markdown text.

    Returns ``(metadata, content)`` where *metadata* is a dict of frontmatter
    key-value pairs and *content* is everything after the closing ``---``.

    No frontmatter (text doesn't start with ``---``) returns ``({}, full_text)``.
    Unclosed ``---`` raises ``ValueError``.
    """
    stripped = text.lstrip("\n")
    if not stripped.startswith(_DELIMITER):
        return {}, text

    # Find the closing delimiter (skip the opening line).
    after_open = stripped[len(_DELIMITER) :]
    # The opening delimiter line may have trailing whitespace/newline.
    first_newline = after_open.find("\n")
    if first_newline == -1:
        raise ValueError("unclosed frontmatter: no closing '---' delimiter")

    body_after_open = after_open[first_newline + 1 :]
    close_pos = body_after_open.find(f"{_DELIMITER}")
    if close_pos == -1:
        raise ValueError("unclosed frontmatter: no closing '---' delimiter")

    # Verify the closing delimiter is on its own line.
    # It must be at position 0 or preceded by a newline.
    if close_pos != 0 and body_after_open[close_pos - 1] != "\n":
        raise ValueError("unclosed frontmatter: no closing '---' delimiter")

    frontmatter_block = body_after_open[:close_pos]
    # Content starts after the closing delimiter line.
    after_close = body_after_open[close_pos + len(_DELIMITER) :]
    # Skip the rest of the closing delimiter line.
    close_newline = after_close.find("\n")
    if close_newline == -1:
        content = ""
    else:
        content = after_close[close_newline + 1 :]

    metadata: dict[str, str] = {}
    for line in frontmatter_block.splitlines():
        line = line.strip()
        if not line:
            continue
        colon_pos = line.find(":")
        if colon_pos == -1:
            continue
        key = line[:colon_pos].strip()
        value = line[colon_pos + 1 :].strip()
        if key:
            metadata[key] = value

    return metadata, content


def serialize_frontmatter(metadata: dict[str, str], content: str, /) -> str:
    """Serialize metadata and content into markdown with YAML frontmatter.

    Produces::

        ---
        key1: value1
        key2: value2
        ---

        content here
    """
    lines = [_DELIMITER]
    for key, value in metadata.items():
        lines.append(f"{key}: {value}")
    lines.append(_DELIMITER)
    lines.append("")  # blank line between frontmatter and content
    lines.append(content)
    return "\n".join(lines)


def write_markdown(path: Path, metadata: dict[str, str], content: str, /) -> None:
    """Write a markdown file with YAML frontmatter."""
    text = serialize_frontmatter(metadata, content)
    _ = path.write_text(text, encoding="utf-8")


def read_markdown(path: Path, /) -> tuple[dict[str, str], str]:
    """Read a markdown file and parse its YAML frontmatter.

    Returns ``(metadata, content)``.
    """
    text = path.read_text(encoding="utf-8")
    return parse_frontmatter(text)


def validate_markdown_structure(
    *,
    path: Path,
    row_model: type[BaseModel],
    row_key: str | None,
    content_field: str = "content",
    mutable_fields: Sequence[str] = (),
    immutable_values: Mapping[str, str] | None = None,
) -> ValidationResult:
    """Validate a markdown file's structure and frontmatter against a row model.

    Issue codes (parallel to CSV validation):
    - ``frontmatter_missing`` — no ``---`` delimiters found.
    - ``frontmatter_parse_error`` — malformed frontmatter (unclosed delimiters).
    - ``field_missing`` — required model field not in frontmatter (excluding content_field).
    - ``field_extra`` — frontmatter key not in model.
    - ``immutable_mutation`` — frontmatter value differs from expected.
    - ``field_incomplete`` — content field is empty/whitespace when mutable.
    - ``row_validation_error`` — Pydantic model validation failed.
    """
    _ = row_key  # accepted for interface consistency; not used for single-entry files
    text = path.read_text(encoding="utf-8")
    issues: list[ValidationIssue] = []

    # Parse frontmatter.
    try:
        metadata, content = parse_frontmatter(text)
    except ValueError as exc:
        issues.append(ValidationIssue(code="frontmatter_parse_error", detail=str(exc)))
        return ValidationResult(issues=tuple(issues), parsed_rows=())

    if not metadata and text.strip():
        # File has content but no frontmatter delimiters.
        issues.append(ValidationIssue(code="frontmatter_missing", detail="no frontmatter found"))
        return ValidationResult(issues=tuple(issues), parsed_rows=())

    if not metadata and not text.strip():
        # Completely empty file — also missing frontmatter.
        issues.append(ValidationIssue(code="frontmatter_missing", detail="no frontmatter found"))
        return ValidationResult(issues=tuple(issues), parsed_rows=())

    # Check for missing / extra fields.
    model_fields = set(row_model.model_fields.keys())
    frontmatter_fields = set(metadata.keys())
    # Fields expected in frontmatter = all model fields except content_field.
    expected_in_frontmatter = model_fields - {content_field}

    for field_name in expected_in_frontmatter:
        if field_name not in frontmatter_fields:
            issues.append(ValidationIssue(code="field_missing", detail=f"missing {field_name}"))

    for field_name in frontmatter_fields:
        if field_name not in model_fields:
            issues.append(ValidationIssue(code="field_extra", detail=f"extra {field_name}"))

    # Check immutable values.
    if immutable_values:
        for field_name, expected_value in immutable_values.items():
            if field_name in metadata and metadata[field_name] != expected_value:
                issues.append(
                    ValidationIssue(
                        code="immutable_mutation",
                        detail=f"{field_name} changed: expected {expected_value!r}, got {metadata[field_name]!r}",
                    )
                )

    # Check content completeness.
    if content_field in mutable_fields and immutable_values is not None:
        if not content.strip():
            issues.append(
                ValidationIssue(code="field_incomplete", detail=f"{content_field} is empty")
            )

    # Validate with Pydantic model.
    row_data = {**metadata, content_field: content.strip()}
    parsed_model: BaseModel | None = None
    try:
        parsed_model = row_model.model_validate(row_data)
    except ValidationError as exc:
        for error in exc.errors():
            field = ".".join(str(part) for part in error.get("loc", ()))
            issues.append(
                ValidationIssue(
                    code="row_validation_error",
                    detail=f"{field}: {error.get('msg', 'invalid value')}",
                )
            )

    parsed_row: dict[str, object] = dict(row_data)
    parsed_rows: tuple[dict[str, object], ...] = (parsed_row,) if parsed_row else ()
    parsed_models = (parsed_model,) if parsed_model is not None else ()

    return ValidationResult(
        issues=tuple(issues),
        parsed_rows=parsed_rows,
        parsed_models=parsed_models,
    )
