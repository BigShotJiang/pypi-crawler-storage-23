---
tags:
  category: system
  context: tag-value
---
# status: `declined`

Not accepted. The request was turned down or the offer was not taken up. Terminal state — the speech act is closed without fulfillment.

## Prompt

The request or offer was rejected. Look for "no", "declined", "not going to", "decided against".
