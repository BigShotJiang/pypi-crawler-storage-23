from ._storage import FileWebmentionsStorage


__all__ = [
    "FileWebmentionsStorage",
]
