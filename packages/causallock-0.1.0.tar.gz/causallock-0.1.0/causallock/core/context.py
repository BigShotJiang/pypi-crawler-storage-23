# causallock/core/context.py

from datetime import datetime, timezone
import uuid
from typing import Optional, Callable
from causallock.runtime.determinism import get_active_determinism


class DeterministicContext:
    """
    Provides injectable sources for:
    - timestamp
    - uuid generation

    Enables deterministic testing and replay mode.
    """

    def __init__(
        self,
        time_provider: Optional[Callable[[], str]] = None,
        uuid_provider: Optional[Callable[[], str]] = None
    ):
        self._time_provider = time_provider or self._default_time
        self._uuid_provider = uuid_provider or self._default_uuid

    @staticmethod
    def _default_time() -> str:
        active = get_active_determinism()
        if active is not None:
            return active.initial_timestamp
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _default_uuid() -> str:
        return str(uuid.uuid4())

    def now(self) -> str:
        return self._time_provider()

    def new_uuid(self) -> str:
        return self._uuid_provider()
