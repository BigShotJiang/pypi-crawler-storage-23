# causallock/core/trace.py

from typing import Dict, Any, List, Optional

from .models import Trace, Event, EnvironmentInfo
from .serializer import canonical_dumps
from .hashing import chain_hash, trace_root_hash
from .context import DeterministicContext
from .schema import CURRENT_SCHEMA_VERSION
from .environment import collect_environment_fingerprint
from causallock.runtime.determinism import get_active_determinism


class TraceBuilder:

    def __init__(
        self,
        model_name: Optional[str] = None,
        context: Optional[DeterministicContext] = None,
        version: str = "1.0",
        schema_version: str = CURRENT_SCHEMA_VERSION,
        sdk_version: str = "0.1.0",
        redaction_version: str = "1",
        determinism_seed: int | None = None,
        project_name: str | None = None,
        agent_name: str | None = None,
    ):
        self._context = context or DeterministicContext()
        self._events: List[Event] = []
        self._prev_hash: str = "0" * 64
        self._version = version
        self._schema_version = schema_version
        self._project_name = project_name
        self._agent_name = agent_name

        active_determinism = get_active_determinism()
        resolved_seed = determinism_seed if determinism_seed is not None else (
            active_determinism.seed if active_determinism is not None else None
        )
        env_data = collect_environment_fingerprint(
            model_name=model_name,
            determinism_seed=resolved_seed,
            sdk_version=sdk_version,
            redaction_version=redaction_version,
        )
        self._environment = EnvironmentInfo.model_validate(env_data)

    def add_event(
        self,
        event_type: str,
        input_data: Dict[str, Any],
        output_data: Dict[str, Any],
        timestamp: Optional[str] = None
    ) -> Event:

        timestamp = timestamp or self._context.now()

        event = Event(
            event_id=self._context.new_uuid(),
            type=event_type,
            input=input_data,
            output=output_data,
            timestamp=timestamp,
            prev_hash=self._prev_hash
        )

        # Compute deterministic hash
        event_dict = event.model_dump(exclude={"hash"})
        serialized = canonical_dumps(event_dict)
        event_hash = chain_hash(self._prev_hash, serialized)

        event.hash = event_hash
        self._prev_hash = event_hash
        self._events.append(event)

        return event

    def build(self) -> Trace:
        trace = Trace(
            version=self._version,
            schema_version=self._schema_version,
            trace_id=self._context.new_uuid(),
            project_name=self._project_name,
            agent_name=self._agent_name,
            created_at=self._context.now(),
            environment=self._environment,
            events=self._events
        )

        # Ensure no None hashes exist
        hashes: List[str] = []
        for event in self._events:
            if event.hash is None:
                raise RuntimeError("Event hash missing — deterministic invariant violated.")
            hashes.append(event.hash)

        trace.final_hash = trace_root_hash(
            event_hashes=hashes,
            schema_version=trace.schema_version,
            redaction_version=trace.environment.redaction_version,
            determinism_seed=trace.environment.determinism_seed,
            tool_runtime_version="1",
            sdk_version=trace.environment.sdk_version,
        )

        return trace
