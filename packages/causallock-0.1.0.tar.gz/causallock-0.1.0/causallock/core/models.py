# causallock/core/models.py

from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional


class EnvironmentInfo(BaseModel):
    python_version: str
    platform: str
    model: Optional[str] = None
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    architecture: Optional[str] = None
    tool_versions: Dict[str, str] = Field(default_factory=dict)
    sdk_version: str = "0.1.0"
    redaction_version: str = "1"
    determinism_seed: Optional[int] = None


class Event(BaseModel):
    event_id: str
    type: str
    input: Dict[str, Any]
    output: Dict[str, Any]
    timestamp: str
    prev_hash: str
    hash: Optional[str] = None


class SignatureBlock(BaseModel):
    algorithm: str
    public_key: str  # base64
    signature: str   # base64
    key_id: Optional[str] = None
    detached: bool = False


class Trace(BaseModel):
    version: str
    schema_version: str = "1.2"
    trace_id: str
    project_name: Optional[str] = None
    agent_name: Optional[str] = None
    created_at: str
    environment: EnvironmentInfo
    events: List[Event]
    final_hash: Optional[str] = None
    signature: Optional[SignatureBlock] = None
