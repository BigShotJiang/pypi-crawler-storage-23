# causallock/core/serializer.py

from typing import Any

from causallock.core.serialization import (
    deserialize_canonical,
    serialize_canonical,
)


def canonical_dumps(data: Any) -> bytes:
    return serialize_canonical(data)


def canonical_loads(data: bytes) -> Any:
    return deserialize_canonical(data)
