# causallock/core/hashing.py

import hashlib
from typing import List

from causallock.core.serializer import canonical_dumps


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def chain_hash(prev_hash: str, payload: bytes) -> str:
    combined = prev_hash.encode("utf-8") + payload
    return sha256_bytes(combined)


def trace_root_hash(
    event_hashes: List[str],
    schema_version: str,
    redaction_version: str,
    determinism_seed: int | None,
    tool_runtime_version: str,
    sdk_version: str,
) -> str:
    payload = {
        "event_hashes": event_hashes,
        "schema_version": schema_version,
        "redaction_version": redaction_version,
        "determinism_seed": determinism_seed,
        "tool_runtime_version": tool_runtime_version,
        "sdk_version": sdk_version,
    }
    return sha256_bytes(canonical_dumps(payload))
