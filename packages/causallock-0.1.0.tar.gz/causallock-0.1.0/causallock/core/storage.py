# causallock/core/storage.py

from pathlib import Path
from typing import Any, Dict, Union, List
import base64
import hashlib

from causallock.core.models import Trace
from causallock.core.serializer import canonical_dumps, canonical_loads
from causallock.core.hashing import sha256_bytes, chain_hash, trace_root_hash
from causallock.core.schema import migrate_trace_data
from causallock.security.redaction import RedactionEngine
from causallock.security.default_rules import DEFAULT_REDACTION_RULES
from causallock.security.signing import TraceSigner, SignatureVerificationError


class TraceIntegrityError(Exception):
    pass


class TraceFormatError(Exception):
    pass


class TraceStorage:

    @staticmethod
    def _atomic_write(path: Path, payload: bytes) -> None:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(payload)
        tmp.replace(path)

    @staticmethod
    def save(
        trace: Trace,
        path: Union[str, Path],
        redact: bool = False
    ) -> None:
        path = Path(path)

        data = trace.model_dump()

        if redact:
            engine = RedactionEngine(DEFAULT_REDACTION_RULES)
            data = engine.apply(data)

        serialized = canonical_dumps(data)
        TraceStorage._atomic_write(path, serialized)

    @staticmethod
    def save_cas(
        trace: Trace,
        storage_dir: Union[str, Path],
        redact: bool = False,
    ) -> Path:
        storage_dir = Path(storage_dir)
        storage_dir.mkdir(parents=True, exist_ok=True)

        data = trace.model_dump()
        if redact:
            engine = RedactionEngine(DEFAULT_REDACTION_RULES)
            data = engine.apply(data)

        serialized = canonical_dumps(data)
        content_hash = sha256_bytes(serialized)
        cas_path = storage_dir / f"{content_hash}.traj"

        if cas_path.exists():
            existing = cas_path.read_bytes()
            if existing != serialized:
                fallback = hashlib.sha3_256(serialized).hexdigest()
                cas_path = storage_dir / f"{content_hash}-{fallback}.traj"
        if not cas_path.exists():
            TraceStorage._atomic_write(cas_path, serialized)

        return cas_path

    @staticmethod
    def load(
        path: Union[str, Path],
        verify_integrity: bool = True,
        verify_signature: bool = False,
    ) -> Trace:

        path = Path(path)
        try:
            raw = path.read_bytes()
            raw_data = canonical_loads(raw)
            if not isinstance(raw_data, dict):
                raise TraceFormatError("Trace root must be a JSON object.")
            data = migrate_trace_data(raw_data)
            trace = Trace.model_validate(data)
        except TraceFormatError:
            raise
        except Exception as exc:
            raise TraceFormatError(f"Malformed trace file: {path}") from exc

        if verify_integrity:
            TraceStorage._verify_trace(trace)

        if verify_signature:
            TraceStorage._verify_signature(trace)

        return trace

    @staticmethod
    def load_cas(
        content_hash: str,
        storage_dir: Union[str, Path],
        verify_integrity: bool = True,
        verify_signature: bool = False,
    ) -> Trace:
        storage_dir = Path(storage_dir)
        path = storage_dir / f"{content_hash}.traj"
        if not path.exists():
            raise FileNotFoundError(f"CAS trace not found: {path}")
        blob = path.read_bytes()
        expected = path.stem
        actual = sha256_bytes(blob)
        if actual != expected:
            raise TraceIntegrityError(
                f"CAS corruption detected for {path.name}: hash mismatch"
            )
        return TraceStorage.load(
            path=path,
            verify_integrity=verify_integrity,
            verify_signature=verify_signature,
        )

    @staticmethod
    def _verify_trace(trace: Trace) -> None:
        prev_hash = "0" * 64
        verified_hashes: List[str] = []

        for event in trace.events:
            if event.prev_hash != prev_hash:
                raise TraceIntegrityError(
                    f"prev_hash mismatch in event {event.event_id}"
                )
            event_dict = event.model_dump(exclude={"hash"})
            serialized = canonical_dumps(event_dict)
            computed_hash = chain_hash(prev_hash, serialized)

            if computed_hash != event.hash:
                raise TraceIntegrityError(
                    f"Hash mismatch in event {event.event_id}"
                )

            if event.hash is None:
                raise TraceIntegrityError(
                    f"Missing hash in event {event.event_id}"
                )

            verified_hashes.append(event.hash)
            prev_hash = computed_hash

        computed_final = trace_root_hash(
            event_hashes=verified_hashes,
            schema_version=trace.schema_version,
            redaction_version=trace.environment.redaction_version,
            determinism_seed=trace.environment.determinism_seed,
            tool_runtime_version="1",
            sdk_version=trace.environment.sdk_version,
        )

        if computed_final != trace.final_hash:
            # Backward compatibility for older schema/hash model.
            legacy_final = sha256_bytes("".join(verified_hashes).encode("utf-8"))
            if legacy_final != trace.final_hash:
                raise TraceIntegrityError("Final trace hash mismatch")

    @staticmethod
    def _verify_signature(trace: Trace) -> None:
        if trace.final_hash is None:
            raise TraceIntegrityError(
                "Trace missing final_hash; cannot verify signature."
            )

        if trace.signature is None:
            raise TraceIntegrityError("No signature present in trace.")

        sig = trace.signature

        if sig.algorithm != "ed25519":
            raise TraceIntegrityError("Unsupported signature algorithm.")

        public_key_bytes = base64.b64decode(sig.public_key)

        try:
            TraceSigner.verify(
                final_hash=trace.final_hash,  # now guaranteed non-None
                signature_b64=sig.signature,
                public_key_bytes=public_key_bytes,
            )
        except SignatureVerificationError as e:
            raise TraceIntegrityError(str(e)) from e
