from __future__ import annotations

from importlib import metadata
import platform
import sys
from typing import Dict, Optional


def _dist_version(name: str) -> str:
    try:
        return metadata.version(name)
    except Exception:
        return "unknown"


def collect_tool_versions() -> Dict[str, str]:
    return {
        "causallock": _dist_version("causallock"),
        "pydantic": _dist_version("pydantic"),
        "orjson": _dist_version("orjson"),
        "cryptography": _dist_version("cryptography"),
    }


def collect_environment_fingerprint(
    model_name: Optional[str] = None,
    determinism_seed: Optional[int] = None,
    sdk_version: str = "0.1.0",
    redaction_version: str = "1",
) -> Dict[str, object]:
    return {
        "python_version": sys.version,
        "platform": platform.platform(),
        "model": model_name,
        "os_name": platform.system(),
        "os_version": platform.version(),
        "architecture": platform.machine(),
        "tool_versions": collect_tool_versions(),
        "sdk_version": sdk_version,
        "redaction_version": redaction_version,
        "determinism_seed": determinism_seed,
    }
