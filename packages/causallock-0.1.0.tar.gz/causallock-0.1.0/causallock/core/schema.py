from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List

CURRENT_SCHEMA_VERSION = "1.2"


@dataclass(frozen=True)
class Migration:
    source: str
    target: str
    transform: Callable[[Dict[str, Any]], Dict[str, Any]]


def _migrate_1_0_to_1_1(data: Dict[str, Any]) -> Dict[str, Any]:
    migrated = dict(data)
    migrated["schema_version"] = "1.1"
    return migrated


def _migrate_1_1_to_1_2(data: Dict[str, Any]) -> Dict[str, Any]:
    migrated = dict(data)
    migrated["schema_version"] = "1.2"

    env = dict(migrated.get("environment", {}))
    env.setdefault("os_name", None)
    env.setdefault("os_version", None)
    env.setdefault("architecture", None)
    env.setdefault("tool_versions", {})
    env.setdefault("sdk_version", "0.1.0")
    env.setdefault("redaction_version", "1")
    env.setdefault("determinism_seed", None)
    migrated["environment"] = env
    return migrated


MIGRATIONS: List[Migration] = [
    Migration(source="1.0", target="1.1", transform=_migrate_1_0_to_1_1),
    Migration(source="1.1", target="1.2", transform=_migrate_1_1_to_1_2),
]


def migrate_trace_data(data: Dict[str, Any]) -> Dict[str, Any]:
    migrated = dict(data)
    schema_version = migrated.get("schema_version")

    if schema_version is None:
        schema_version = str(migrated.get("version", "1.0"))
        migrated["schema_version"] = schema_version

    while schema_version != CURRENT_SCHEMA_VERSION:
        migration = next(
            (item for item in MIGRATIONS if item.source == schema_version),
            None,
        )
        if migration is None:
            raise ValueError(
                f"Unsupported trace schema_version '{schema_version}'."
            )
        migrated = migration.transform(migrated)
        schema_version = migration.target

    return migrated
