from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal
import math
import unicodedata
from typing import Any

import orjson


def _normalize_string(value: str) -> str:
    return unicodedata.normalize("NFC", value)


def _normalize_datetime(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    value = value.astimezone(timezone.utc)
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


def _normalize_float(value: float) -> float | str:
    if math.isnan(value):
        return "NaN"
    if math.isinf(value):
        return "Infinity" if value > 0 else "-Infinity"
    return value


def _normalize(obj: Any) -> Any:
    if obj is None or isinstance(obj, (bool, int)):
        return obj

    if isinstance(obj, str):
        return _normalize_string(obj)

    if isinstance(obj, float):
        return _normalize_float(obj)

    if isinstance(obj, Decimal):
        return format(obj.normalize(), "f")

    if isinstance(obj, datetime):
        return _normalize_datetime(obj)

    if isinstance(obj, date):
        return obj.isoformat()

    if isinstance(obj, dict):
        return {_normalize_string(str(k)): _normalize(v) for k, v in obj.items()}

    if isinstance(obj, (list, tuple)):
        return [_normalize(item) for item in obj]

    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="strict")

    if hasattr(obj, "model_dump"):
        return _normalize(obj.model_dump())

    if hasattr(obj, "__dict__"):
        return _normalize(vars(obj))

    return _normalize_string(str(obj))


def serialize_canonical(obj: Any) -> bytes:
    normalized = _normalize(obj)
    return orjson.dumps(normalized, option=orjson.OPT_SORT_KEYS)


def deserialize_canonical(data: bytes) -> Any:
    return orjson.loads(data)
