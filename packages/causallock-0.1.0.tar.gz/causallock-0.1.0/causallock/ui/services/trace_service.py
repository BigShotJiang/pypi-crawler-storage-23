from pathlib import Path
from typing import Dict, Any

from causallock.core.storage import (
    TraceStorage,
    TraceIntegrityError,
    TraceFormatError,
)


def _infer_grouping_from_filename(path: Path) -> tuple[str, str]:
    stem = path.stem
    if "__" in stem:
        parts = stem.split("__")
        project = parts[0] or "default"
        agent = parts[1] if len(parts) > 1 and parts[1] else "default"
        return project, agent
    if "-" in stem:
        parts = stem.split("-")
        project = parts[0] or "default"
        agent = parts[1] if len(parts) > 1 and parts[1] else "default"
        return project, agent
    return "default", "default"


def load_trace_summary(path: Path) -> Dict[str, Any]:
    try:
        trace = TraceStorage.load(
            path,
            verify_integrity=True,
            verify_signature=False,
        )
        valid_chain = True
    except (TraceIntegrityError, TraceFormatError):
        try:
            # Load without verification to still show metadata
            trace = TraceStorage.load(
                path,
                verify_integrity=False,
                verify_signature=False,
            )
            valid_chain = False
        except TraceFormatError:
            project_name, agent_name = _infer_grouping_from_filename(path)
            return {
                "trace_name": path.name,
                "trace_id": path.name,
                "project_name": project_name,
                "agent_name": agent_name,
                "created_at": "invalid",
                "event_count": 0,
                "final_hash": "invalid",
                "signed": False,
                "valid_hash_chain": False,
                "schema_version": "unknown",
                "model": None,
                "determinism_seed": None,
            }

    inferred_project, inferred_agent = _infer_grouping_from_filename(path)
    return {
        "trace_name": path.name,
        "trace_id": trace.trace_id,
        "project_name": trace.project_name or inferred_project,
        "agent_name": trace.agent_name or inferred_agent,
        "created_at": trace.created_at,
        "event_count": len(trace.events),
        "final_hash": trace.final_hash,
        "signed": trace.signature is not None,
        "valid_hash_chain": valid_chain,
        "schema_version": trace.schema_version,
        "model": trace.environment.model,
        "determinism_seed": trace.environment.determinism_seed,
    }


def load_trace_events(path: Path, offset: int = 0, limit: int = 500):
    trace = TraceStorage.load(
        path,
        verify_integrity=True,
        verify_signature=False,
    )

    sliced_events = trace.events[offset : offset + limit]

    events = []
    for idx, event in enumerate(sliced_events, start=offset):
        events.append(
            {
                "index": idx,
                "type": event.type,
                "hash": event.hash,
                "prev_hash": event.prev_hash,
                "timestamp": event.timestamp,
                "payload": event.model_dump(),
            }
        )

    return {
        "metadata": {
            "trace_id": trace.trace_id,
            "final_hash": trace.final_hash,
            "offset": offset,
            "limit": limit,
            "total_events": len(trace.events),
            "schema_version": trace.schema_version,
        },
        "events": events,
    }


def load_trace_event_summaries(path: Path, offset: int = 0, limit: int = 500):
    trace = TraceStorage.load(
        path,
        verify_integrity=True,
        verify_signature=False,
    )

    sliced_events = trace.events[offset : offset + limit]

    events = []
    for idx, event in enumerate(sliced_events, start=offset):
        events.append(
            {
                "index": idx,
                "type": event.type,
                "hash": event.hash,
                "prev_hash": event.prev_hash,
                "timestamp": event.timestamp,
            }
        )

    return {
        "metadata": {
            "trace_id": trace.trace_id,
            "final_hash": trace.final_hash,
            "offset": offset,
            "limit": limit,
            "total_events": len(trace.events),
            "schema_version": trace.schema_version,
        },
        "events": events,
    }


def load_event_payload(path: Path, index: int) -> Dict[str, Any]:
    trace = TraceStorage.load(
        path,
        verify_integrity=True,
        verify_signature=False,
    )

    if index < 0 or index >= len(trace.events):
        raise IndexError("Event index out of range")

    event = trace.events[index]

    return {
        "index": index,
        "type": event.type,
        "hash": event.hash,
        "prev_hash": event.prev_hash,
        "timestamp": event.timestamp,
        "payload": event.model_dump(),
    }
