from pathlib import Path
from typing import List


def list_traj_files(directory: Path) -> List[Path]:
    if not directory.exists():
        return []
    return sorted(directory.glob("*.traj"))