from pathlib import Path
from typing import Dict
import base64

from causallock.core.storage import TraceStorage, TraceFormatError, TraceIntegrityError
from causallock.security.signing import TraceSigner, SignatureVerificationError


def verify_trace_signature(path: Path) -> Dict[str, str]:
    try:
        trace = TraceStorage.load(
            path,
            verify_integrity=True,
            verify_signature=False,
        )
    except (TraceFormatError, TraceIntegrityError):
        return {"status": "invalid"}

    if trace.signature is None:
        return {"status": "unsigned"}

    if trace.final_hash is None:
        # This should never happen in a valid trace,
        # but we guard for strict type safety.
        return {"status": "invalid"}

    try:
        public_key_bytes = base64.b64decode(trace.signature.public_key)

        TraceSigner.verify(
            final_hash=trace.final_hash,
            signature_b64=trace.signature.signature,
            public_key_bytes=public_key_bytes,
        )

        return {"status": "valid"}

    except SignatureVerificationError:
        return {"status": "invalid"}
