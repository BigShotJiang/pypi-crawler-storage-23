from pathlib import Path
from typing import Dict, Any

from causallock.core.storage import TraceStorage
from causallock.diff.engine import TraceDiffer


def compute_diff(path_a: Path, path_b: Path) -> Dict[str, Any]:
    trace_a = TraceStorage.load(path_a)
    trace_b = TraceStorage.load(path_b)

    result = TraceDiffer.diff(trace_a, trace_b)

    return {
        "diverged": result.diverged,
        "divergence_index": result.index,
        "reason": result.reason,
        "details": result.details,
    }
