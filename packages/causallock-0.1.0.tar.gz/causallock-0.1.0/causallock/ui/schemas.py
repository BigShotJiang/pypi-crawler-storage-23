from pydantic import BaseModel
from typing import List, Optional, Dict, Any


class TraceSummary(BaseModel):
    trace_name: str
    trace_id: str
    project_name: Optional[str] = None
    agent_name: Optional[str] = None
    created_at: str
    event_count: int
    final_hash: str
    signed: bool
    valid_hash_chain: bool
    schema_version: str
    model: Optional[str] = None
    determinism_seed: Optional[int] = None


class EventModel(BaseModel):
    index: int
    type: str
    hash: Optional[str]
    prev_hash: Optional[str]
    timestamp: str
    payload: Optional[Dict[str, Any]] = None


class EventSummary(BaseModel):
    index: int
    type: str
    hash: Optional[str]
    prev_hash: Optional[str]
    timestamp: str


class TraceResponse(BaseModel):
    metadata: Dict[str, Any]
    events: List[EventModel]


class EventSummaryResponse(BaseModel):
    metadata: Dict[str, Any]
    events: List[EventSummary]


class DiffResponse(BaseModel):
    diverged: bool
    divergence_index: Optional[int]
    reason: Optional[str]
    details: Optional[Dict[str, Any]]


class VerifyResponse(BaseModel):
    status: str
