from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from causallock.cli.parallel import replay_worker
from causallock.core.environment import collect_environment_fingerprint
from causallock.core.storage import TraceFormatError, TraceIntegrityError, TraceStorage
from causallock.core.hashing import sha256_bytes
from causallock.diff.engine import TraceDiffer
from causallock.replay.engine import ReplayDivergenceError, ReplayEngine
from causallock.security.default_rules import DEFAULT_REDACTION_RULES
from causallock.ui.config import DEFAULT_TRACE_DIR, HOST, PORT
from causallock.ui.services.filesystem_service import list_traj_files
from causallock.ui.services.trace_service import (
    load_event_payload,
    load_trace_event_summaries,
    load_trace_events,
    load_trace_summary,
)
from causallock.ui.services.verify_service import verify_trace_signature
from causallock.ui.schemas import (
    DiffResponse,
    EventModel,
    EventSummaryResponse,
    TraceResponse,
    TraceSummary,
    VerifyResponse,
)


class ReplayStartRequest(BaseModel):
    trace_name: str
    immutable: bool = False
    force_env_mismatch: bool = False
    seed: Optional[int] = None


class ReplayStepRequest(BaseModel):
    session_id: str
    direction: str = "forward"


class ReplayStopRequest(BaseModel):
    session_id: str


class DiffQuery(BaseModel):
    traceA: str
    traceB: str
    semantic: bool = False


class TestRunRequest(BaseModel):
    directory: str = "regression"
    workers: int = 2
    strict: bool = False


@dataclass
class ReplaySession:
    session_id: str
    trace_name: str
    immutable: bool
    total_events: int
    index: int = 0
    status: str = "running"
    started_at: float = 0.0


app = FastAPI(title="causallock UI")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

TRACE_DIR = DEFAULT_TRACE_DIR
TRACE_DIR.mkdir(parents=True, exist_ok=True)
TRACE_DIR_RESOLVED = TRACE_DIR.resolve()
STATIC_DIR = Path(__file__).parent / "static"
if STATIC_DIR.exists() and (STATIC_DIR / "index.html").exists():
    app.mount("/ui", StaticFiles(directory=STATIC_DIR, html=True), name="ui")

REPLAY_SESSIONS: Dict[str, ReplaySession] = {}


def _resolve_trace_path(trace_name: str) -> Path:
    if not trace_name.endswith(".traj"):
        raise HTTPException(status_code=400, detail="Only .traj files are supported")
    candidate = (TRACE_DIR / trace_name).resolve()
    if candidate.parent != TRACE_DIR_RESOLVED:
        raise HTTPException(status_code=400, detail="Invalid trace path")
    if not candidate.exists():
        raise HTTPException(status_code=404, detail="Trace not found")
    return candidate


def _get_trace(trace_name: str, verify: bool = True):
    path = _resolve_trace_path(trace_name)
    return TraceStorage.load(path, verify_integrity=verify, verify_signature=False)


def _summaries() -> List[Dict[str, Any]]:
    return [load_trace_summary(f) for f in list_traj_files(TRACE_DIR)]


@app.get("/")
def health():
    if STATIC_DIR.exists() and (STATIC_DIR / "index.html").exists():
        return RedirectResponse(url="/ui")
    return {"service": "causallock-ui-api", "status": "ok"}


# Legacy routes
@app.get("/traces", response_model=List[TraceSummary])
def get_traces():
    return _summaries()


@app.get("/trace/{trace_name}", response_model=TraceResponse)
def get_trace(trace_name: str, offset: int = 0, limit: int = 500):
    path = _resolve_trace_path(trace_name)
    try:
        return load_trace_events(path, offset, limit)
    except (TraceFormatError, TraceIntegrityError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/trace/{trace_name}/events", response_model=EventSummaryResponse)
def get_trace_events(trace_name: str, offset: int = 0, limit: int = 500):
    path = _resolve_trace_path(trace_name)
    try:
        return load_trace_event_summaries(path, offset, limit)
    except (TraceFormatError, TraceIntegrityError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/trace/{trace_name}/event/{index}", response_model=EventModel)
def get_trace_event(trace_name: str, index: int):
    path = _resolve_trace_path(trace_name)
    try:
        return load_event_payload(path, index)
    except IndexError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (TraceFormatError, TraceIntegrityError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/diff/{trace_a}/{trace_b}", response_model=DiffResponse)
def get_diff(trace_a: str, trace_b: str):
    try:
        ta = _get_trace(trace_a, verify=True)
        tb = _get_trace(trace_b, verify=True)
        result = TraceDiffer.diff(ta, tb)
        return {
            "diverged": result.diverged,
            "divergence_index": result.index,
            "reason": result.reason,
            "details": result.details,
        }
    except (TraceFormatError, TraceIntegrityError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/verify/{trace_name}", response_model=VerifyResponse)
def verify(trace_name: str):
    path = _resolve_trace_path(trace_name)
    return verify_trace_signature(path)


# 2027-style API namespace
@app.get("/api/traces")
def api_traces():
    return _summaries()


@app.get("/api/trace/{trace_name}")
def api_trace(trace_name: str, offset: int = 0, limit: int = 500):
    return get_trace(trace_name, offset, limit)


@app.get("/api/trace/{trace_name}/events")
def api_trace_events(trace_name: str, offset: int = 0, limit: int = 500):
    return get_trace_events(trace_name, offset, limit)


@app.get("/api/trace/{trace_name}/event/{index}")
def api_trace_event(trace_name: str, index: int):
    return get_trace_event(trace_name, index)


@app.get("/api/trace/{trace_name}/state")
def api_trace_state(trace_name: str, index: int):
    trace = _get_trace(trace_name, verify=True)
    if index < 0:
        index = 0
    if index >= len(trace.events):
        index = len(trace.events) - 1 if trace.events else 0

    tool_results: List[Dict[str, Any]] = []
    llm_outputs: List[Dict[str, Any]] = []
    stream_outputs: List[Dict[str, Any]] = []
    for i, event in enumerate(trace.events):
        if i > index:
            break
        if event.type == "tool_call":
            tool_results.append({"index": i, "result": event.output.get("result")})
        elif event.type == "llm_call":
            llm_outputs.append({"index": i, "output": event.output})
        elif event.type == "llm_stream":
            stream_outputs.append({"index": i, "reconstructed": event.output.get("reconstructed")})

    return {
        "trace_name": trace_name,
        "index": index,
        "applied_events": index + 1 if trace.events else 0,
        "state": {
            "tool_results": tool_results,
            "llm_outputs": llm_outputs,
            "stream_outputs": stream_outputs,
        },
    }


@app.get("/api/search")
def api_search(q: str, regex: bool = False, limit: int = 50):
    import re

    summaries = _summaries()
    if not q.strip():
        return {"matches": []}

    matches: List[Dict[str, Any]] = []
    pattern = re.compile(q) if regex else None

    for summary in summaries:
        text = " ".join(
            [
                summary.get("trace_name", ""),
                summary.get("trace_id", ""),
                str(summary.get("project_name", "")),
                str(summary.get("agent_name", "")),
                str(summary.get("model", "")),
            ]
        )
        hit = pattern.search(text) if pattern else q.lower() in text.lower()
        if hit:
            matches.append(
                {
                    "kind": "trace",
                    "trace_name": summary["trace_name"],
                    "trace_id": summary["trace_id"],
                    "project_name": summary.get("project_name"),
                    "agent_name": summary.get("agent_name"),
                }
            )
        if len(matches) >= limit:
            break

    return {"matches": matches}


@app.post("/api/replay/start")
def api_replay_start(req: ReplayStartRequest):
    trace = TraceStorage.load(
        _resolve_trace_path(req.trace_name),
        verify_integrity=True,
        verify_signature=req.immutable,
    )
    ReplayEngine(
        trace,
        strict=req.immutable,
        immutable=req.immutable,
        force_env_mismatch=req.force_env_mismatch,
        expected_seed=req.seed,
    )
    session_id = str(uuid.uuid4())
    REPLAY_SESSIONS[session_id] = ReplaySession(
        session_id=session_id,
        trace_name=req.trace_name,
        immutable=req.immutable,
        total_events=len(trace.events),
        index=0,
        status="running",
        started_at=time.time(),
    )
    return {
        "session_id": session_id,
        "trace_name": req.trace_name,
        "total_events": len(trace.events),
        "status": "running",
    }


@app.post("/api/replay/step")
def api_replay_step(req: ReplayStepRequest):
    session = REPLAY_SESSIONS.get(req.session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Replay session not found")
    if req.direction == "back":
        session.index = max(0, session.index - 1)
    else:
        session.index = min(session.total_events, session.index + 1)
    if session.index >= session.total_events:
        session.status = "completed"
    return {
        "session_id": session.session_id,
        "index": session.index,
        "total_events": session.total_events,
        "status": session.status,
    }


@app.post("/api/replay/stop")
def api_replay_stop(req: ReplayStopRequest):
    session = REPLAY_SESSIONS.pop(req.session_id, None)
    if session is None:
        raise HTTPException(status_code=404, detail="Replay session not found")
    return {"session_id": req.session_id, "status": "stopped"}


@app.get("/api/replay/status")
def api_replay_status(session_id: Optional[str] = None):
    if session_id:
        session = REPLAY_SESSIONS.get(session_id)
        if session is None:
            raise HTTPException(status_code=404, detail="Replay session not found")
        return session.__dict__
    return {"sessions": [s.__dict__ for s in REPLAY_SESSIONS.values()]}


@app.get("/api/replay/progress/{session_id}")
async def api_replay_progress(session_id: str):
    if session_id not in REPLAY_SESSIONS:
        raise HTTPException(status_code=404, detail="Replay session not found")

    async def event_stream():
        while session_id in REPLAY_SESSIONS:
            session = REPLAY_SESSIONS[session_id]
            payload = {
                "session_id": session.session_id,
                "index": session.index,
                "total_events": session.total_events,
                "status": session.status,
                "hash_status": "valid",
            }
            yield f"event: replay_progress\ndata: {json.dumps(payload)}\n\n"
            if session.status != "running":
                break
            session.index = min(session.total_events, session.index + 1)
            if session.index >= session.total_events:
                session.status = "completed"
            await asyncio.sleep(0.35)

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@app.get("/api/diff")
def api_diff(traceA: str, traceB: str, semantic: bool = False):
    ta = _get_trace(traceA, verify=True)
    tb = _get_trace(traceB, verify=True)
    result = TraceDiffer.diff(ta, tb, semantic=semantic)
    return {
        "divergence_index": result.index,
        "type": result.classification,
        "summary": result.reason,
        "field_deltas": result.details or {},
        "diverged": result.diverged,
    }


@app.get("/api/vcr/stats")
def api_vcr_stats():
    tool_calls = 0
    unique_hashes = set()
    hits = 0
    misses = 0
    per_tool: Dict[str, int] = {}
    for f in list_traj_files(TRACE_DIR):
        trace = TraceStorage.load(f, verify_integrity=False, verify_signature=False)
        for event in trace.events:
            if event.type != "tool_call":
                continue
            tool_calls += 1
            payload_hash = event.output.get("payload_hash")
            tool_name = str(event.input.get("kwargs", {}).get("name", "unknown"))
            per_tool[tool_name] = per_tool.get(tool_name, 0) + 1
            if payload_hash in unique_hashes:
                hits += 1
            else:
                unique_hashes.add(payload_hash)
                misses += 1
    return {
        "tool_calls": tool_calls,
        "cache_hits": hits,
        "cache_misses": misses,
        "unique_payload_hashes": len(unique_hashes),
        "tool_usage": per_tool,
    }


@app.get("/api/vcr/{tool_hash}")
def api_vcr_hash(tool_hash: str):
    events: List[Dict[str, Any]] = []
    for f in list_traj_files(TRACE_DIR):
        trace = TraceStorage.load(f, verify_integrity=False, verify_signature=False)
        for idx, event in enumerate(trace.events):
            if event.type == "tool_call" and event.output.get("payload_hash") == tool_hash:
                events.append(
                    {
                        "trace_name": f.name,
                        "index": idx,
                        "tool_version": event.output.get("tool_version"),
                        "input": event.input,
                        "output": event.output,
                    }
                )
    return {"tool_hash": tool_hash, "matches": events}


@app.get("/api/redaction/rules")
def api_redaction_rules():
    rules = []
    for rule in DEFAULT_REDACTION_RULES:
        rules.append(
            {
                "pattern": rule._regex.pattern,  # noqa: SLF001
                "replacement": rule._replacement,  # noqa: SLF001
            }
        )
    return {"version": "1", "rules": rules}


@app.get("/api/trace/{trace_name}/redaction-log")
def api_redaction_log(trace_name: str):
    trace = _get_trace(trace_name, verify=False)
    markers = ("[REDACTED_EMAIL]", "[REDACTED_SSN]", "[REDACTED_PHONE]", "[REDACTED_API_KEY]")
    findings: List[Dict[str, Any]] = []
    for idx, event in enumerate(trace.events):
        payload = str(event.model_dump())
        for marker in markers:
            if marker in payload:
                findings.append({"index": idx, "event_type": event.type, "marker": marker})
    return {"trace_name": trace_name, "findings": findings, "count": len(findings)}


@app.get("/api/trust/{trace_name}")
def api_trust(trace_name: str):
    path = _resolve_trace_path(trace_name)
    chain_valid = True
    try:
        trace = TraceStorage.load(path, verify_integrity=True, verify_signature=False)
    except Exception as exc:  # noqa: BLE001
        chain_valid = False
        trace = TraceStorage.load(path, verify_integrity=False, verify_signature=False)

    sig = verify_trace_signature(path).get("status")
    env_now = collect_environment_fingerprint()
    env_mismatch = []
    for field in ("python_version", "os_name", "os_version", "architecture"):
        recorded = getattr(trace.environment, field, None)
        if recorded and env_now.get(field) and recorded != env_now[field]:
            env_mismatch.append(field)

    blob = path.read_bytes()
    cas_hash = sha256_bytes(blob)
    cas_path = Path("storage") / f"{cas_hash}.traj"
    cas_status = "present" if cas_path.exists() else "missing"
    return {
        "trace_name": trace_name,
        "hash_chain": "valid" if chain_valid else "invalid",
        "signature": sig,
        "environment_mismatch_fields": env_mismatch,
        "cas_status": cas_status,
        "schema_version": trace.schema_version,
    }


@app.post("/api/test/run")
def api_test_run(req: TestRunRequest):
    directory = Path(req.directory)
    if not directory.exists():
        raise HTTPException(status_code=404, detail="Regression directory not found")
    files = sorted(directory.glob("*.traj"), key=lambda p: p.name.lower())
    results = [replay_worker((f, req.strict)) for f in files]
    failures = [r for r in results if not r[1]]
    return {
        "total": len(results),
        "failures": len(failures),
        "results": [
            {"trace": name, "success": success, "error": err}
            for name, success, err in results
        ],
    }


def run():
    import uvicorn

    uvicorn.run("causallock.ui.server:app", host=HOST, port=PORT, reload=False)
