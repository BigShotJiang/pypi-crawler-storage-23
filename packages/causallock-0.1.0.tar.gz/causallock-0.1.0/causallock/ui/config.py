from pathlib import Path
import os

DEFAULT_TRACE_DIR = Path(os.getenv("causallock_TRACE_DIR", "regression"))
HOST = os.getenv("causallock_UI_HOST", "127.0.0.1")
PORT = int(os.getenv("causallock_UI_PORT", "8765"))
