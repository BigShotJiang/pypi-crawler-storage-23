# causallock/diff/engine.py

from typing import Any, Dict, List, Optional, Tuple

from causallock.core.models import Trace
from causallock.core.serializer import canonical_dumps


SEMANTIC_IGNORE_FIELDS = {"timestamp", "created_at"}


class TraceDiffResult:
    def __init__(
        self,
        diverged: bool,
        index: Optional[int],
        reason: str,
        classification: str = "none",
        details: Optional[Dict[str, Any]] = None,
    ):
        self.diverged = diverged
        self.index = index
        self.reason = reason
        self.classification = classification
        self.details = details


def _normalize_semantic_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {
        key: value
        for key, value in payload.items()
        if key not in SEMANTIC_IGNORE_FIELDS
    }


def _field_level_delta(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    keys = sorted(set(a.keys()) | set(b.keys()))
    changed: List[Dict[str, Any]] = []
    for key in keys:
        va = a.get(key, "__missing__")
        vb = b.get(key, "__missing__")
        if canonical_dumps(va) != canonical_dumps(vb):
            changed.append({"field": key, "trace_a": va, "trace_b": vb})
    return {"changed_fields": changed, "changed_count": len(changed)}


class TraceDiffer:

    @staticmethod
    def diff(trace_a: Trace, trace_b: Trace, semantic: bool = False) -> TraceDiffResult:
        if len(trace_a.events) != len(trace_b.events):
            return TraceDiffResult(
                diverged=True,
                index=min(len(trace_a.events), len(trace_b.events)),
                reason="Event count mismatch.",
                classification="order_drift",
                details={
                    "trace_a_event_count": len(trace_a.events),
                    "trace_b_event_count": len(trace_b.events),
                },
            )

        for idx, (event_a, event_b) in enumerate(zip(trace_a.events, trace_b.events)):
            if event_a.type != event_b.type:
                return TraceDiffResult(
                    diverged=True,
                    index=idx,
                    reason="Event type mismatch.",
                    classification="event_type_mismatch",
                    details={
                        "trace_a_type": event_a.type,
                        "trace_b_type": event_b.type,
                    },
                )

            input_a = event_a.input
            input_b = event_b.input
            output_a = event_a.output
            output_b = event_b.output

            if semantic:
                input_a = _normalize_semantic_payload(input_a)
                input_b = _normalize_semantic_payload(input_b)
                output_a = _normalize_semantic_payload(output_a)
                output_b = _normalize_semantic_payload(output_b)

            if canonical_dumps(input_a) != canonical_dumps(input_b):
                return TraceDiffResult(
                    diverged=True,
                    index=idx,
                    reason="Input payload mismatch.",
                    classification="payload_delta_input",
                    details=_field_level_delta(input_a, input_b),
                )

            if canonical_dumps(output_a) != canonical_dumps(output_b):
                return TraceDiffResult(
                    diverged=True,
                    index=idx,
                    reason="Output payload mismatch.",
                    classification="payload_delta_output",
                    details=_field_level_delta(output_a, output_b),
                )

            if event_a.hash != event_b.hash:
                return TraceDiffResult(
                    diverged=True,
                    index=idx,
                    reason="Event hash mismatch.",
                    classification="hash_mismatch",
                    details={
                        "trace_a_hash": event_a.hash,
                        "trace_b_hash": event_b.hash,
                    },
                )

        if trace_a.final_hash != trace_b.final_hash:
            return TraceDiffResult(
                diverged=True,
                index=None,
                reason="Final hash mismatch.",
                classification="hash_mismatch",
                details={
                    "trace_a_final_hash": trace_a.final_hash,
                    "trace_b_final_hash": trace_b.final_hash,
                },
            )

        return TraceDiffResult(
            diverged=False,
            index=None,
            reason="No divergence detected.",
            classification="none",
        )
