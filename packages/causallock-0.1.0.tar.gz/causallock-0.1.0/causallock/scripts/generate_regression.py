# scripts/generate_regression.py

from pathlib import Path
import shutil
import subprocess
import sys

from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext
from causallock.core.storage import TraceStorage


REGRESSION_DIR = Path("regression")


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def create_trace(index: int):
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=lambda: f"00000000-0000-0000-0000-00000000000{index}"
    )

    builder = TraceBuilder(context=context)
    builder.add_event(
        "llm_call",
        {"prompt": f"Hello {index}"},
        {"response": f"Hi {index}"}
    )

    return builder.build()


def generate_traces(count: int = 2):
    if REGRESSION_DIR.exists():
        shutil.rmtree(REGRESSION_DIR)

    REGRESSION_DIR.mkdir(parents=True)

    for i in range(count):
        trace = create_trace(i)
        file_path = REGRESSION_DIR / f"sample{i+1}.traj"
        TraceStorage.save(trace, file_path)

    print(f"Generated {count} deterministic traces in {REGRESSION_DIR}")


def run_cli_test():
    print("\nRunning causallock regression test...\n")

    result = subprocess.run(
        ["causallock", "test", "run", str(REGRESSION_DIR)],
        capture_output=True,
        text=True
    )

    print(result.stdout)

    if result.returncode != 0:
        print("Regression FAILED")
        sys.exit(1)

    print("Regression PASSED")


if __name__ == "__main__":
    generate_traces(count=2)
    run_cli_test()