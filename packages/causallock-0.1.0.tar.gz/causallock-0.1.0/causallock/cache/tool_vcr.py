# causallock/cache/tool_vcr.py

from typing import Callable, Any, Dict, Optional
from functools import wraps
import hashlib

from causallock.interceptor.mode import AuditMode
from causallock.core.trace import TraceBuilder
from causallock.core.serializer import canonical_dumps
from causallock.replay.engine import ReplayEngine, ReplayDivergenceError


class ToolDivergenceError(Exception):
    pass


class ToolVCR:
    """
    Deterministic Tool VCR layer.

    RECORD mode:
        - Executes tool
        - Stores input/output in trace

    REPLAY mode:
        - Skips execution
        - Returns cached output
        - Enforces strict divergence detection
    """

    def __init__(
        self,
        mode: AuditMode,
        trace_builder: Optional[TraceBuilder] = None,
        replay_engine: Optional[ReplayEngine] = None,
        tool_version: str = "1",
        deterministic: bool = True,
        allow_side_effects_in_replay: bool = False,
    ):
        self._mode = mode
        self._trace_builder = trace_builder
        self._replay_engine = replay_engine
        self._tool_version = tool_version
        self._deterministic = deterministic
        self._allow_side_effects_in_replay = allow_side_effects_in_replay

    def wrap(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """
        Decorator to wrap deterministic tool execution.
        """

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:

            payload: Dict[str, Any] = {
                "args": args,
                "kwargs": kwargs,
                "tool_version": self._tool_version,
                "deterministic": self._deterministic,
            }
            payload_hash = hashlib.sha256(canonical_dumps(payload)).hexdigest()

            # ---------------------------
            # REPLAY MODE
            # ---------------------------
            if self._mode == AuditMode.REPLAY:

                if self._replay_engine is None:
                    raise RuntimeError(
                        "Replay engine not provided in REPLAY mode."
                    )

                try:
                    event_output = self._replay_engine.next_tool_call(payload)
                except ReplayDivergenceError as e:
                    raise ToolDivergenceError(str(e)) from e

                if "result" not in event_output:
                    raise ToolDivergenceError(
                        "Malformed tool replay payload: missing 'result'."
                    )
                if not self._deterministic and not self._allow_side_effects_in_replay:
                    raise ToolDivergenceError(
                        "Replay disallowed for non-deterministic side-effect tool."
                    )
                if event_output.get("payload_hash") != payload_hash:
                    raise ToolDivergenceError(
                        "Tool payload hash mismatch during replay."
                    )

                return event_output["result"]

            # ---------------------------
            # RECORD MODE
            # ---------------------------
            result = func(*args, **kwargs)

            if self._trace_builder is None:
                raise RuntimeError(
                    "TraceBuilder not provided in RECORD mode."
                )

            self._trace_builder.add_event(
                event_type="tool_call",
                input_data=payload,
                output_data={
                    "result": result,
                    "payload_hash": payload_hash,
                    "tool_version": self._tool_version,
                },
            )

            return result

        return wrapper
