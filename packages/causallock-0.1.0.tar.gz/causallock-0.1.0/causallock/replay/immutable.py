# causallock/replay/immutable.py

from causallock.core.models import Trace


class ImmutableTrace:
    """
    Read-only wrapper around Trace to prevent mutation.
    """

    def __init__(self, trace: Trace):
        self._trace = trace

    def __getattr__(self, item):
        return getattr(self._trace, item)

    def __setattr__(self, key, value):
        if key == "_trace":
            super().__setattr__(key, value)
        else:
            raise AttributeError("ImmutableTrace does not allow mutation.")