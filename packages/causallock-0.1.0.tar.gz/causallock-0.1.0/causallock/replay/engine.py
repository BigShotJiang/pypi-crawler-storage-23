# causallock/replay/engine.py

from typing import Dict, Any, List
import copy

from causallock.core.environment import collect_environment_fingerprint
from causallock.core.models import Trace, Event
from causallock.core.serializer import canonical_dumps
from causallock.core.hashing import sha256_bytes


class ReplayDivergenceError(Exception):
    pass


class ReplayEngine:

    def __init__(
        self,
        trace: Trace,
        strict: bool = False,
        immutable: bool = False,
        force_env_mismatch: bool = False,
        expected_seed: int | None = None,
    ):
        self._trace: Trace = trace
        self._events: List[Event] = trace.events
        self._pointer: int = 0
        self._strict: bool = strict
        self._immutable: bool = immutable

        if strict and trace.signature is None:
            raise ReplayDivergenceError(
                "Strict mode requires a signed trace."
            )

        self._validate_replay_environment(
            force_env_mismatch=force_env_mismatch,
            expected_seed=expected_seed,
        )

    # ---------------------------
    # Internal
    # ---------------------------

    def _fingerprint(self, payload: Dict[str, Any]) -> str:
        serialized = canonical_dumps(payload)
        return sha256_bytes(serialized)

    def _next_event(self) -> Event:
        if self._pointer >= len(self._events):
            raise ReplayDivergenceError("No more recorded events.")

        event = self._events[self._pointer]
        self._pointer += 1
        return event

    def _validate_replay_environment(
        self,
        force_env_mismatch: bool,
        expected_seed: int | None,
    ) -> None:
        trace_seed = self._trace.environment.determinism_seed
        if expected_seed is not None and trace_seed != expected_seed:
            raise ReplayDivergenceError(
                f"Seed mismatch: trace={trace_seed}, expected={expected_seed}"
            )

        if force_env_mismatch:
            return

        current = collect_environment_fingerprint()
        mismatches: List[str] = []
        for field in ("python_version", "os_name", "os_version", "architecture"):
            recorded = getattr(self._trace.environment, field, None)
            now = current.get(field)
            if recorded and now and recorded != now:
                mismatches.append(field)

        if mismatches and (self._strict or self._immutable):
            raise ReplayDivergenceError(
                "Environment fingerprint mismatch: " + ", ".join(mismatches)
            )

    # ---------------------------
    # Public API
    # ---------------------------

    def next_llm_call(self, request_payload: Dict[str, Any]) -> Dict[str, Any]:
        event = self._next_event()

        if event.type not in ("llm_call", "llm_stream"):
            raise ReplayDivergenceError(
                f"Expected llm_call but got {event.type}"
            )

        incoming_fp = self._fingerprint(request_payload)
        recorded_fp = self._fingerprint(event.input)

        if incoming_fp != recorded_fp:
            raise ReplayDivergenceError(
                "LLM request payload divergence detected."
            )

        return copy.deepcopy(event.output)

    def next_tool_call(self, request_payload: Dict[str, Any]) -> Dict[str, Any]:
        event = self._next_event()

        if event.type != "tool_call":
            raise ReplayDivergenceError(
                f"Expected tool_call but got {event.type}"
            )

        incoming_fp = self._fingerprint(request_payload)
        recorded_fp = self._fingerprint(event.input)

        if incoming_fp != recorded_fp:
            raise ReplayDivergenceError(
                "Tool request payload divergence detected."
            )

        return copy.deepcopy(event.output)
