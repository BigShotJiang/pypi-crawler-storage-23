from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import os
import random
import threading
import time
import uuid
from typing import Callable, Generator, Optional


try:
    import numpy as _np  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    _np = None


_STATE_LOCAL = threading.local()


@dataclass(frozen=True)
class DeterministicExecutionContext:
    seed: int
    initial_timestamp: str


def _iso_utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def get_active_determinism() -> Optional[DeterministicExecutionContext]:
    return getattr(_STATE_LOCAL, "determinism", None)


@contextmanager
def deterministic_context(
    seed: int,
    initial_timestamp: Optional[str] = None,
    override_os_entropy: bool = False,
) -> Generator[DeterministicExecutionContext, None, None]:
    """
    Applies deterministic shims for randomness and uuid generation.
    Intended for record/replay runs that need stable behavior.
    """
    ts = initial_timestamp or _iso_utc_now()
    ctx = DeterministicExecutionContext(seed=seed, initial_timestamp=ts)

    seeded_random = random.Random(seed)
    seeded_for_bytes = random.Random(seed ^ 0xA5A5_A5A5_A5A5_A5A5)

    orig_uuid4: Callable[[], uuid.UUID] = uuid.uuid4
    orig_urandom = os.urandom
    orig_random_state = random.getstate()
    orig_time = time.time
    orig_monotonic = time.monotonic

    np_state = None
    if _np is not None:
        np_state = _np.random.get_state()

    base_dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    base_epoch = base_dt.timestamp()
    monotonic_base = 1_000_000_000.0 + float(seed % 1000)
    ticks = {"n": 0}

    def deterministic_uuid4() -> uuid.UUID:
        return uuid.UUID(int=seeded_random.getrandbits(128), version=4)

    def deterministic_urandom(n: int) -> bytes:
        return bytes(seeded_for_bytes.getrandbits(8) for _ in range(n))

    def deterministic_time() -> float:
        ticks["n"] += 1
        return base_epoch + (ticks["n"] * 0.001)

    def deterministic_monotonic() -> float:
        ticks["n"] += 1
        return monotonic_base + (ticks["n"] * 0.001)

    try:
        random.seed(seed)
        if _np is not None:
            _np.random.seed(seed)
        uuid.uuid4 = deterministic_uuid4
        time.time = deterministic_time  # type: ignore[assignment]
        time.monotonic = deterministic_monotonic  # type: ignore[assignment]
        if override_os_entropy:
            os.urandom = deterministic_urandom  # type: ignore[assignment]
        _STATE_LOCAL.determinism = ctx
        yield ctx
    finally:
        uuid.uuid4 = orig_uuid4
        os.urandom = orig_urandom
        time.time = orig_time  # type: ignore[assignment]
        time.monotonic = orig_monotonic  # type: ignore[assignment]
        random.setstate(orig_random_state)
        if _np is not None and np_state is not None:
            _np.random.set_state(np_state)
        _STATE_LOCAL.determinism = None
