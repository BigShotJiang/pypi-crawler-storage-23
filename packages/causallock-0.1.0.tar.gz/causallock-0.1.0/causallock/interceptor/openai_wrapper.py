# causallock/interceptor/openai_wrapper.py

from typing import Any, Dict, Optional, List
import base64

from causallock.interceptor.base import LLMInterceptor
from causallock.interceptor.mode import AuditMode
from causallock.replay.engine import ReplayEngine
from causallock.core.serializer import canonical_dumps


class AuditOpenAIClient(LLMInterceptor):

    def __init__(
        self,
        client: Any,
        trace_builder,
        mode: AuditMode,
        replay_engine: Optional[ReplayEngine] = None,
        stream_chunk_group_size: int = 1,
        raw_stream: bool = False,
    ):
        super().__init__(client, trace_builder, mode)
        self._replay_engine = replay_engine
        self._stream_chunk_group_size = max(1, stream_chunk_group_size)
        self._raw_stream = raw_stream

    # ---------------------------
    # Non-Streaming
    # ---------------------------

    def chat_completion(self, **kwargs: Any):

        if self._mode == AuditMode.REPLAY:
            if not self._replay_engine:
                raise RuntimeError("Replay engine not provided.")
            return self._replay_engine.next_llm_call(kwargs)

        response = self._client.chat.completions.create(**kwargs)

        if hasattr(response, "model_dump"):
            response_dict = response.model_dump()
        else:
            response_dict = dict(response)

        self._record_event(
            request_payload=kwargs,
            response_payload=response_dict
        )

        return response

    # ---------------------------
    # Streaming
    # ---------------------------

    def chat_completion_stream(self, **kwargs: Any):

        if self._mode == AuditMode.REPLAY:
            if not self._replay_engine:
                raise RuntimeError("Replay engine not provided.")

            replay_data = self._replay_engine.next_llm_call(kwargs)

            for chunk in replay_data["chunks"]:
                yield chunk
            return

        stream = self._client.chat.completions.create(
            **kwargs,
            stream=True
        )

        collected_chunks: List[Dict[str, Any]] = []
        raw_chunks: List[Dict[str, Any]] = []
        reconstructed_text = ""
        staged_content: List[str] = []

        def flush_staged_chunks() -> None:
            if not staged_content:
                return
            collected_chunks.append(
                {
                    "choices": [
                        {
                            "delta": {
                                "content": "".join(staged_content)
                            }
                        }
                    ]
                }
            )
            staged_content.clear()

        stream_headers = {}
        if self._raw_stream and hasattr(stream, "response") and hasattr(stream.response, "headers"):
            stream_headers = dict(stream.response.headers)

        complete = False
        try:
            for idx, chunk in enumerate(stream):
                if hasattr(chunk, "model_dump"):
                    chunk_dict = chunk.model_dump()
                else:
                    chunk_dict = dict(chunk)

                try:
                    delta = chunk_dict["choices"][0]["delta"]
                    if "content" in delta:
                        content = delta["content"]
                        reconstructed_text += content
                        staged_content.append(content)
                        if len(staged_content) >= self._stream_chunk_group_size:
                            flush_staged_chunks()
                    else:
                        collected_chunks.append(chunk_dict)
                except Exception:
                    collected_chunks.append(chunk_dict)

                if self._raw_stream:
                    raw_chunks.append(
                        {
                            "raw_index": idx,
                            "raw_event_id": chunk_dict.get("id"),
                            "raw_bytes_b64": base64.b64encode(
                                canonical_dumps(chunk_dict)
                            ).decode("utf-8"),
                        }
                    )

                yield chunk
            complete = True
        finally:
            if not complete:
                raise RuntimeError("Interrupted stream: refusing partial stream commit.")
            flush_staged_chunks()
            self._trace_builder.add_event(
                event_type="llm_stream",
                input_data=kwargs,
                output_data={
                    "chunks": collected_chunks,
                    "reconstructed": reconstructed_text,
                    "provider_headers": stream_headers,
                    "raw_chunks": raw_chunks,
                },
            )
