# causallock/interceptor/mode.py

from enum import Enum


class AuditMode(str, Enum):
    RECORD = "record"
    REPLAY = "replay"