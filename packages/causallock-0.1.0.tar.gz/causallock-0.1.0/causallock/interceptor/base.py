# causallock/interceptor/base.py

from typing import Any, Dict, Callable
from causallock.core.trace import TraceBuilder
from causallock.interceptor.mode import AuditMode


class LLMInterceptor:

    def __init__(
        self,
        client: Any,
        trace_builder: TraceBuilder,
        mode: AuditMode = AuditMode.RECORD
    ):
        self._client = client
        self._trace_builder = trace_builder
        self._mode = mode

    def _record_event(
        self,
        request_payload: Dict[str, Any],
        response_payload: Dict[str, Any]
    ) -> None:
        self._trace_builder.add_event(
            event_type="llm_call",
            input_data=request_payload,
            output_data=response_payload
        )