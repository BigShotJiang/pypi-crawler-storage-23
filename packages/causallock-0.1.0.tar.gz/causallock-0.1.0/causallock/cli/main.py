import typer
from rich.console import Console

from causallock.cli.commands import replay as replay_cmd
from causallock.cli.commands import test as test_cmd
from causallock.cli.commands import sign as sign_cmd
from causallock.cli.commands import diff as diff_cmd
from causallock.cli.commands import init as init_cmd
from causallock.cli.commands import freeze as freeze_cmd
from causallock.cli.commands.ui import launch_ui

app = typer.Typer(help="causallock CLI")
console = Console()

app.add_typer(replay_cmd.app, name="replay")
app.add_typer(test_cmd.app, name="test")
app.add_typer(sign_cmd.app, name="sign")
app.add_typer(diff_cmd.app, name="diff")
app.add_typer(init_cmd.app, name="init")
app.add_typer(freeze_cmd.app, name="freeze")


@app.command()
def ui():
    """
    Launch the local causallock Flight Recorder UI.
    """
    launch_ui()


if __name__ == "__main__":
    app()
