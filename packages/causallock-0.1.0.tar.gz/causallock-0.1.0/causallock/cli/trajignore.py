from pathlib import Path
from typing import List

REQUIRED_TRAJIGNORE_LINES: List[str] = [
    "*.traj",
    "enterprise_vault/",
    "*.traj.snapshot",
]


def ensure_trajignore(project_root: Path) -> bool:
    path = project_root / ".trajignore"
    existing = []
    if path.exists():
        existing = [line.strip() for line in path.read_text(encoding="utf-8").splitlines()]

    changed = False
    for required in REQUIRED_TRAJIGNORE_LINES:
        if required not in existing:
            existing.append(required)
            changed = True

    if not path.exists():
        changed = True

    if changed:
        header = [
            "# causallock trace ignore rules",
            "# Prevent accidental commits of sensitive deterministic trace artifacts.",
        ]
        body = "\n".join(header + [""] + existing) + "\n"
        path.write_text(body, encoding="utf-8")

    return changed
