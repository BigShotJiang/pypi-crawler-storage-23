# causallock/cli/parallel.py

from pathlib import Path
from typing import Tuple
from causallock.core.storage import TraceStorage
from causallock.replay.engine import ReplayEngine


def replay_worker(args) -> Tuple[str, bool, str]:
    path, strict = args

    try:
        trace = TraceStorage.load(
            path,
            verify_integrity=True,
            verify_signature=strict,
        )

        ReplayEngine(trace, strict=strict)

        return (path.name, True, "")

    except Exception as e:
        return (path.name, False, str(e))