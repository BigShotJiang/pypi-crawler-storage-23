import webbrowser
from causallock.ui.server import run
from causallock.ui.config import HOST, PORT


def launch_ui():
    url = f"http://{HOST}:{PORT}/ui"
    webbrowser.open(url)
    run()
