import typer
from pathlib import Path
from rich.console import Console

from causallock.cli.trajignore import ensure_trajignore

app = typer.Typer()
console = Console()


@app.command()
def run(
    project_root: Path = typer.Argument(
        Path("."),
        help="Project directory for causallock initialization.",
    )
):
    """
    Initialize causallock project defaults.
    """
    root = project_root.resolve()
    root.mkdir(parents=True, exist_ok=True)

    regression_dir = root / "regression"
    cas_dir = root / "storage"
    regression_dir.mkdir(parents=True, exist_ok=True)
    cas_dir.mkdir(parents=True, exist_ok=True)

    changed = ensure_trajignore(root)

    console.print(f"[green]Initialized causallock at {root}[/green]")
    console.print(f"Regression dir: {regression_dir}")
    console.print(f"CAS storage dir: {cas_dir}")
    if changed:
        console.print("[green].trajignore updated[/green]")
    else:
        console.print("[yellow].trajignore already up to date[/yellow]")
