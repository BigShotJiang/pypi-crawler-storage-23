# causallock/cli/commands/replay.py

import typer
from pathlib import Path
from rich.console import Console

from causallock.core.storage import TraceStorage
from causallock.replay.engine import ReplayEngine
from causallock.cli.trajignore import ensure_trajignore

app = typer.Typer()
console = Console()


@app.command()
def run(
    trace_path: Path,
    immutable: bool = typer.Option(
        False, help="Enable immutable replay mode."
    ),
    force_env_mismatch: bool = typer.Option(
        False, help="Allow replay even when environment fingerprint differs."
    ),
    seed: int | None = typer.Option(
        None, help="Expected deterministic seed recorded in the trace."
    ),
):
    """
    Replay a .traj file and verify integrity.
    """
    if not trace_path.exists():
        console.print("[red]Trace file not found.[/red]")
        raise typer.Exit(code=1)

    ensure_trajignore(Path.cwd())

    try:
        stat_before = trace_path.stat()
        trace = TraceStorage.load(
            trace_path,
            verify_integrity=True,
            verify_signature=immutable,
        )
        ReplayEngine(
            trace,
            strict=immutable,
            immutable=immutable,
            force_env_mismatch=force_env_mismatch,
            expected_seed=seed,
        )
        if immutable:
            stat_after = trace_path.stat()
            if (stat_before.st_mtime_ns != stat_after.st_mtime_ns) or (
                stat_before.st_size != stat_after.st_size
            ):
                raise RuntimeError("Immutable replay violation: trace file changed during replay.")

        console.print("[green]Replay validation successful.[/green]")
    except Exception as e:
        console.print(f"[red]Replay failed:[/red] {e}")
        raise typer.Exit(code=1)
