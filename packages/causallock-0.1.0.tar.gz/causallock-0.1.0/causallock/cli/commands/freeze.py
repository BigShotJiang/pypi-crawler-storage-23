import os
from pathlib import Path

import typer
from rich.console import Console


app = typer.Typer()
console = Console()


@app.command()
def run(
    directory: Path,
    dry_run: bool = typer.Option(False, help="Preview files without changing mode."),
):
    """
    Freeze regression snapshots by making .traj files read-only.
    """
    if not directory.exists():
        console.print("[red]Directory not found.[/red]")
        raise typer.Exit(code=1)

    files = sorted(directory.glob("*.traj"), key=lambda p: p.name.lower())
    if not files:
        console.print("[yellow]No .traj files found.[/yellow]")
        raise typer.Exit(code=0)

    for file in files:
        if dry_run:
            console.print(f"[cyan]would-freeze[/cyan] {file}")
            continue
        mode = file.stat().st_mode
        file.chmod(mode & ~os.W_OK)
        console.print(f"[green]frozen[/green] {file}")
