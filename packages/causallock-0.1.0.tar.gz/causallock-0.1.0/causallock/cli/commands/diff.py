# causallock/cli/commands/diff.py

import typer
from pathlib import Path
from rich.console import Console

from causallock.core.storage import TraceStorage
from causallock.diff.engine import TraceDiffer

app = typer.Typer()
console = Console()


@app.command()
def run(
    trace_a: Path,
    trace_b: Path,
    semantic: bool = typer.Option(
        False, help="Ignore non-impacting metadata fields (timestamps, etc)."
    ),
):
    """
    Diff two .traj files.
    """

    if not trace_a.exists() or not trace_b.exists():
        console.print("[red]Trace file not found.[/red]")
        raise typer.Exit(code=1)

    t1 = TraceStorage.load(trace_a, verify_integrity=True)
    t2 = TraceStorage.load(trace_b, verify_integrity=True)

    result = TraceDiffer.diff(t1, t2, semantic=semantic)

    if result.diverged:
        console.print("[red]Traces diverged.[/red]")
        console.print(f"Index: {result.index}")
        console.print(f"Reason: {result.reason}")
        console.print(f"Classification: {result.classification}")
        if result.details:
            console.print(f"Details: {result.details}")
        raise typer.Exit(code=1)

    console.print("[green]Traces are identical.[/green]")
