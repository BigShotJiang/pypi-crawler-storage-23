# causallock/cli/commands/test.py

import typer
from pathlib import Path
from rich.console import Console
from multiprocessing import Pool, cpu_count
import json

from causallock.cli.parallel import replay_worker
from causallock.cli.trajignore import ensure_trajignore

app = typer.Typer()
console = Console()


@app.command()
def run(
    directory: Path,
    workers: int = typer.Option(
        default=max(1, cpu_count() // 2),
        help="Number of parallel workers."
    ),
    strict: bool = typer.Option(
        False,
        help="Enable strict replay mode (requires signature)."
    ),
    json_output: bool = typer.Option(
        False, help="Emit machine-readable JSON summary."
    ),
):
    """
    Run deterministic regression tests.
    """

    if not directory.exists():
        console.print("[red]Directory not found.[/red]")
        raise typer.Exit(code=1)

    ensure_trajignore(Path.cwd())

    traj_files = sorted(directory.glob("*.traj"), key=lambda p: p.name.lower())

    if not traj_files:
        console.print("[yellow]No .traj files found.[/yellow]")
        raise typer.Exit(code=0)

    console.print(f"[bold]Running with {workers} workers[/bold]")
    if strict:
        console.print("[bold red]STRICT MODE ENABLED[/bold red]")

    failures = 0
    report = []

    with Pool(processes=workers) as pool:
        results = pool.map(
            replay_worker,
            [(file, strict) for file in traj_files]
        )
    results = sorted(results, key=lambda item: item[0].lower())

    for name, success, error in results:
        if success:
            console.print(f"[green]PASS[/green] {name}")
            report.append({"trace": name, "status": "pass", "error": ""})
        else:
            console.print(f"[red]FAIL[/red] {name} → {error}")
            failures += 1
            report.append(
                {
                    "trace": name,
                    "status": "fail",
                    "error": error,
                    "classification": "replay_divergence",
                }
            )

    if json_output:
        print(
            json.dumps(
                {"total": len(results), "failures": failures, "results": report}
            )
        )

    if failures > 0:
        raise typer.Exit(code=1)

    console.print("[bold green]All regression tests passed.[/bold green]")
