# causallock/cli/commands/sign.py

import typer
from pathlib import Path
import base64

from rich.console import Console
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from causallock.core.models import SignatureBlock
from causallock.core.storage import TraceStorage
from causallock.security.key_registry import load_key_registry, save_key_registry
from causallock.security.signing import TraceSigner

app = typer.Typer()
console = Console()


@app.command()
def keygen(
    output: Path = typer.Option(..., help="Directory to save keys"),
    key_id: str | None = typer.Option(None, help="Optional key id to register."),
    registry: Path | None = typer.Option(
        None, help="Optional JSON key registry path for key rotation."
    ),
):
    """
    Generate Ed25519 keypair.
    """
    output.mkdir(parents=True, exist_ok=True)

    private_key, public_key = TraceSigner.generate_keypair()

    private_path = output / "private.key"
    public_path = output / "public.key"

    private_path.write_bytes(base64.b64encode(private_key))
    public_path.write_bytes(base64.b64encode(public_key))

    console.print("[green]Keys generated successfully.[/green]")
    console.print(f"Private: {private_path}")
    console.print(f"Public:  {public_path}")
    if key_id and registry:
        reg = load_key_registry(registry)
        reg[key_id] = base64.b64encode(public_key).decode("utf-8")
        save_key_registry(registry, reg)
        console.print(f"[green]Registered key_id '{key_id}' in:[/green] {registry}")


@app.command()
def sign(
    trace_path: Path,
    private_key_path: Path,
    detached: bool = typer.Option(
        False, help="Write detached signature file instead of embedding into trace."
    ),
    signature_path: Path | None = typer.Option(
        None, help="Path for detached signature output."
    ),
    key_id: str | None = typer.Option(
        None, help="Optional key identifier for key registry workflows."
    ),
):
    """
    Sign a trace file using a private key.
    """

    if not trace_path.exists():
        console.print("[red]Trace file not found.[/red]")
        raise typer.Exit(code=1)

    if not private_key_path.exists():
        console.print("[red]Private key not found.[/red]")
        raise typer.Exit(code=1)

    trace = TraceStorage.load(trace_path, verify_integrity=True)

    private_key_bytes = base64.b64decode(private_key_path.read_bytes())

    private_key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
    public_key = private_key.public_key()

    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    trace = TraceSigner.attach_signature(
        trace,
        private_key_bytes=private_key_bytes,
        public_key_bytes=public_key_bytes,
        key_id=key_id,
        detached=detached,
    )

    if detached:
        out = signature_path or trace_path.with_suffix(".sig")
        out.write_text(trace.signature.model_dump_json(indent=2), encoding="utf-8")
        console.print(f"[green]Detached signature written:[/green] {out}")
    else:
        TraceStorage.save(trace, trace_path)
        console.print("[green]Trace signed successfully.[/green]")


@app.command()
def verify(
    trace_path: Path,
    signature_path: Path | None = typer.Option(
        None, help="Detached signature file path."
    ),
    registry: Path | None = typer.Option(
        None, help="Optional key registry file for key-id based verification."
    ),
):
    """
    Verify trace integrity and signature.
    """

    if not trace_path.exists():
        console.print("[red]Trace file not found.[/red]")
        raise typer.Exit(code=1)

    try:
        if signature_path is None:
            TraceStorage.load(
                trace_path,
                verify_integrity=True,
                verify_signature=True,
            )
        else:
            trace = TraceStorage.load(trace_path, verify_integrity=True, verify_signature=False)
            if not signature_path.exists():
                raise FileNotFoundError(f"Signature file not found: {signature_path}")
            sig_data = signature_path.read_text(encoding="utf-8")
            sig = SignatureBlock.model_validate_json(sig_data)
            trace.signature = sig
            if registry and sig.key_id:
                reg = load_key_registry(registry)
                public_key = reg.get(sig.key_id)
                if public_key is None:
                    raise ValueError(f"key_id '{sig.key_id}' not found in registry")
                trace.signature.public_key = public_key
            TraceStorage._verify_signature(trace)
        console.print("[green]Trace verified successfully.[/green]")
    except Exception as e:
        console.print(f"[red]Verification failed:[/red] {e}")
        raise typer.Exit(code=1)
