# causallock/security/default_rules.py

from causallock.security.redaction import RedactionRule


DEFAULT_REDACTION_RULES = [

    # Email
    RedactionRule(
        pattern=r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",
        replacement="[REDACTED_EMAIL]"
    ),

    # US SSN
    RedactionRule(
        pattern=r"\b\d{3}-\d{2}-\d{4}\b",
        replacement="[REDACTED_SSN]"
    ),

    # Phone
    RedactionRule(
        pattern=r"\b\d{10}\b",
        replacement="[REDACTED_PHONE]"
    ),

    # OpenAI-like API keys
    RedactionRule(
        pattern=r"sk-[a-zA-Z0-9]{20,}",
        replacement="[REDACTED_API_KEY]"
    ),
]