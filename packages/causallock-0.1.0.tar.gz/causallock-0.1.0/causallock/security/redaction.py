# causallock/security/redaction.py

import re
from typing import Any, Dict, List, Callable


class RedactionRule:
    """
    Deterministic redaction rule.
    """

    def __init__(self, pattern: str, replacement: str):
        self._regex = re.compile(pattern)
        self._replacement = replacement

    def apply(self, value: str) -> str:
        return self._regex.sub(self._replacement, value)


class RedactionEngine:
    """
    Recursively traverses nested structures and applies redaction rules
    deterministically to string values.
    """

    def __init__(self, rules: List[RedactionRule]):
        self._rules = rules

    def apply(self, data: Any) -> Any:
        if isinstance(data, dict):
            return {
                key: self.apply(value)
                for key, value in data.items()
            }

        if isinstance(data, list):
            return [self.apply(item) for item in data]

        if isinstance(data, str):
            return self._apply_rules(data)

        return data

    def _apply_rules(self, value: str) -> str:
        result = value
        for rule in self._rules:
            result = rule.apply(result)
        return result