# causallock/security/signing.py

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from typing import Tuple
import base64

from causallock.core.models import SignatureBlock


class SignatureVerificationError(Exception):
    pass


class TraceSigner:

    @staticmethod
    def generate_keypair() -> Tuple[bytes, bytes]:
        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        private_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )

        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

        return private_bytes, public_bytes

    @staticmethod
    def sign(final_hash: str, private_key_bytes: bytes) -> str:
        private_key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
        signature = private_key.sign(final_hash.encode("utf-8"))
        return base64.b64encode(signature).decode("utf-8")

    @staticmethod
    def verify(
        final_hash: str,
        signature_b64: str,
        public_key_bytes: bytes,
    ) -> None:
        public_key = Ed25519PublicKey.from_public_bytes(public_key_bytes)
        signature = base64.b64decode(signature_b64)

        try:
            public_key.verify(signature, final_hash.encode("utf-8"))
        except Exception:
            raise SignatureVerificationError(
                "Trace signature verification failed."
            )

    @staticmethod
    def attach_signature(
        trace,
        private_key_bytes: bytes,
        public_key_bytes: bytes,
        key_id: str | None = None,
        detached: bool = False,
    ):
        signature = TraceSigner.sign(trace.final_hash, private_key_bytes)

        signature_block = SignatureBlock(
            algorithm="ed25519",
            public_key=base64.b64encode(public_key_bytes).decode("utf-8"),
            signature=signature,
            key_id=key_id,
            detached=detached,
        )

        trace.signature = signature_block
        return trace
