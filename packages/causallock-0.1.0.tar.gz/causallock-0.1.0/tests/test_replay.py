from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext
from causallock.interceptor.openai_wrapper import AuditOpenAIClient
from causallock.interceptor.mode import AuditMode
from causallock.replay.engine import ReplayEngine


class FakeResponse:
    def model_dump(self):
        return {"choices": [{"message": {"content": "Hi"}}]}


class FakeChat:
    class completions:
        @staticmethod
        def create(**kwargs):
            return FakeResponse()


class FakeClient:
    chat = FakeChat()


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_replay_zero_token():
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid
    )

    # RECORD PHASE
    builder = TraceBuilder(context=context)
    fake_client = FakeClient()

    record_client = AuditOpenAIClient(
        client=fake_client,
        trace_builder=builder,
        mode=AuditMode.RECORD
    )

    record_client.chat_completion(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}]
    )

    trace = builder.build()

    # REPLAY PHASE
    replay_engine = ReplayEngine(trace)

    replay_client = AuditOpenAIClient(
        client=None,
        trace_builder=None,
        mode=AuditMode.REPLAY,
        replay_engine=replay_engine
    )

    replay_response = replay_client.chat_completion(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}]
    )

    assert replay_response["choices"][0]["message"]["content"] == "Hi"