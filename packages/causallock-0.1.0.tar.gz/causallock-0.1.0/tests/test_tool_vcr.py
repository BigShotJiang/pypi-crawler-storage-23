from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext
from causallock.interceptor.mode import AuditMode
from causallock.replay.engine import ReplayEngine
from causallock.cache.tool_vcr import ToolVCR


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_tool_vcr_record_and_replay():
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid
    )

    builder = TraceBuilder(context=context)

    vcr_record = ToolVCR(
        mode=AuditMode.RECORD,
        trace_builder=builder
    )

    @vcr_record.wrap
    def add(a, b):
        return a + b

    result_record = add(2, 3)
    assert result_record == 5

    trace = builder.build()

    replay_engine = ReplayEngine(trace)

    vcr_replay = ToolVCR(
        mode=AuditMode.REPLAY,
        replay_engine=replay_engine
    )

    @vcr_replay.wrap
    def add_replay(a, b):
        # Should never execute
        raise RuntimeError("Should not execute in replay mode.")

    result_replay = add_replay(2, 3)
    assert result_replay == 5