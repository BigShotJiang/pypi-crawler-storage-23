from pathlib import Path

from causallock.core.context import DeterministicContext
from causallock.core.serializer import canonical_dumps
from causallock.core.storage import TraceStorage
from causallock.core.trace import TraceBuilder


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def _build_trace():
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid,
    )
    builder = TraceBuilder(context=context)
    builder.add_event("llm_call", {"prompt": "Hello"}, {"response": "Hi"})
    return builder.build()


def test_migrates_missing_schema_version(tmp_path: Path):
    trace = _build_trace()
    data = trace.model_dump()
    del data["schema_version"]

    path = tmp_path / "legacy.traj"
    path.write_bytes(canonical_dumps(data))

    loaded = TraceStorage.load(path)
    assert loaded.schema_version == "1.2"


def test_content_addressable_storage_deduplicates(tmp_path: Path):
    trace = _build_trace()
    storage_dir = tmp_path / "storage"

    first = TraceStorage.save_cas(trace, storage_dir)
    second = TraceStorage.save_cas(trace, storage_dir)

    assert first == second
    assert first.exists()
