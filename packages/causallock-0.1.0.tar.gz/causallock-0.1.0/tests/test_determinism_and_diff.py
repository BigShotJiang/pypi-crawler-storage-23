from causallock.core.trace import TraceBuilder
from causallock.replay.engine import ReplayDivergenceError, ReplayEngine
from causallock.diff.engine import TraceDiffer
from causallock.runtime.determinism import deterministic_context


def test_seed_is_captured_in_trace_environment():
    with deterministic_context(seed=42, initial_timestamp="2026-01-01T00:00:00Z"):
        builder = TraceBuilder()
        builder.add_event("llm_call", {"x": 1}, {"y": 2})
        trace = builder.build()
    assert trace.environment.determinism_seed == 42


def test_replay_seed_mismatch_fails():
    with deterministic_context(seed=7, initial_timestamp="2026-01-01T00:00:00Z"):
        builder = TraceBuilder()
        builder.add_event("llm_call", {"prompt": "a"}, {"response": "b"})
        trace = builder.build()

    try:
        ReplayEngine(trace, strict=False, immutable=True, expected_seed=999)
    except ReplayDivergenceError as exc:
        assert "Seed mismatch" in str(exc)
    else:
        raise AssertionError("Expected replay seed mismatch failure")


def test_diff_classification_payload_delta():
    b1 = TraceBuilder(determinism_seed=1)
    b1.add_event("llm_call", {"a": 1}, {"b": 1})
    t1 = b1.build()

    b2 = TraceBuilder(determinism_seed=1)
    b2.add_event("llm_call", {"a": 2}, {"b": 1})
    t2 = b2.build()

    result = TraceDiffer.diff(t1, t2)
    assert result.diverged is True
    assert result.classification == "payload_delta_input"
