from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext
from causallock.core.storage import TraceStorage
from causallock.security.signing import TraceSigner
from pathlib import Path


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_signed_trace(tmp_path: Path):

    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid
    )

    builder = TraceBuilder(context=context)
    builder.add_event("llm_call", {"prompt": "Hello"}, {"response": "Hi"})
    trace = builder.build()

    private_key, public_key = TraceSigner.generate_keypair()

    trace = TraceSigner.attach_signature(trace, private_key, public_key)

    file_path = tmp_path / "signed.traj"
    TraceStorage.save(trace, file_path)

    # Should verify
    TraceStorage.load(file_path, verify_integrity=True, verify_signature=True)