from causallock.security.signing import TraceSigner


def test_sign_and_verify():
    private_key, public_key = TraceSigner.generate_keypair()

    final_hash = "abc123"

    signature = TraceSigner.sign(final_hash, private_key)

    # Should not raise
    TraceSigner.verify(final_hash, signature, public_key)