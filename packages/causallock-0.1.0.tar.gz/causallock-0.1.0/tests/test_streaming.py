from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext
from causallock.interceptor.openai_wrapper import AuditOpenAIClient
from causallock.interceptor.mode import AuditMode
from causallock.replay.engine import ReplayEngine


class FakeChunk:
    def __init__(self, content):
        self._content = content

    def model_dump(self):
        return {
            "choices": [
                {"delta": {"content": self._content}}
            ]
        }


class FakeChat:
    class completions:
        @staticmethod
        def create(**kwargs):
            if kwargs.get("stream"):
                return [
                    FakeChunk("Hel"),
                    FakeChunk("lo")
                ]
            return None


class FakeClient:
    chat = FakeChat()


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_stream_record_and_replay():
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid
    )

    builder = TraceBuilder(context=context)
    fake_client = FakeClient()

    # RECORD
    record_client = AuditOpenAIClient(
        client=fake_client,
        trace_builder=builder,
        mode=AuditMode.RECORD
    )

    collected = ""
    for chunk in record_client.chat_completion_stream(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}]
    ):
        collected += chunk.model_dump()["choices"][0]["delta"]["content"]

    assert collected == "Hello"

    trace = builder.build()

    # REPLAY
    replay_engine = ReplayEngine(trace)

    replay_client = AuditOpenAIClient(
        client=None,
        trace_builder=None,
        mode=AuditMode.REPLAY,
        replay_engine=replay_engine
    )

    replay_collected = ""
    for chunk in replay_client.chat_completion_stream(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}]
    ):
        replay_collected += chunk["choices"][0]["delta"]["content"]

    assert replay_collected == "Hello"