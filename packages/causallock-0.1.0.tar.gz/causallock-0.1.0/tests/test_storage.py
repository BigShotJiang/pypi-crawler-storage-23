from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext
from causallock.core.storage import TraceStorage
from pathlib import Path


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_save_and_load(tmp_path: Path):
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid
    )

    builder = TraceBuilder(context=context)
    builder.add_event("llm_call", {"prompt": "Hello"}, {"response": "Hi"})
    trace = builder.build()

    file_path = tmp_path / "test.traj"

    TraceStorage.save(trace, file_path)
    loaded = TraceStorage.load(file_path)

    assert trace.final_hash == loaded.final_hash