from pathlib import Path

from causallock.core.context import DeterministicContext
from causallock.core.storage import TraceIntegrityError, TraceStorage
from causallock.core.trace import TraceBuilder


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def _build_and_save(path: Path):
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid,
    )
    builder = TraceBuilder(context=context)
    builder.add_event("llm_call", {"prompt": "Hello"}, {"response": "Hi"})
    trace = builder.build()
    TraceStorage.save(trace, path)


def test_detects_corrupted_event_hash(tmp_path: Path):
    path = tmp_path / "trace.traj"
    _build_and_save(path)

    tampered = TraceStorage.load(path, verify_integrity=False)
    tampered.events[0].hash = "0" * 64
    TraceStorage.save(tampered, path)

    try:
        TraceStorage.load(path, verify_integrity=True)
        assert False, "Expected TraceIntegrityError"
    except TraceIntegrityError:
        assert True


def test_detects_corrupted_payload(tmp_path: Path):
    path = tmp_path / "trace.traj"
    _build_and_save(path)

    tampered = TraceStorage.load(path, verify_integrity=False)
    tampered.events[0].output["response"] = "Tampered"
    TraceStorage.save(tampered, path)

    try:
        TraceStorage.load(path, verify_integrity=True)
        assert False, "Expected TraceIntegrityError"
    except TraceIntegrityError:
        assert True
