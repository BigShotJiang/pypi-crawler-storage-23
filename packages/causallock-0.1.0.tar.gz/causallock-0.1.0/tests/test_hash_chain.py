from causallock.core.trace import TraceBuilder
from causallock.core.context import DeterministicContext


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_deterministic_hash():
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid
    )

    builder1 = TraceBuilder(context=context)
    builder1.add_event("llm_call", {"prompt": "Hello"}, {"response": "Hi"})
    trace1 = builder1.build()

    builder2 = TraceBuilder(context=context)
    builder2.add_event("llm_call", {"prompt": "Hello"}, {"response": "Hi"})
    trace2 = builder2.build()

    assert trace1.final_hash == trace2.final_hash