from causallock.core.context import DeterministicContext
from causallock.core.trace import TraceBuilder
from causallock.interceptor.mode import AuditMode
from causallock.interceptor.openai_wrapper import AuditOpenAIClient


class FakeChunk:
    def __init__(self, content):
        self._content = content

    def model_dump(self):
        return {"choices": [{"delta": {"content": self._content}}]}


class FakeChat:
    class completions:
        @staticmethod
        def create(**kwargs):
            return [FakeChunk("a"), FakeChunk("b"), FakeChunk("c"), FakeChunk("d")]


class FakeClient:
    chat = FakeChat()


def fixed_time():
    return "2026-01-01T00:00:00+00:00"


def fixed_uuid():
    return "00000000-0000-0000-0000-000000000000"


def test_stream_chunks_are_grouped_for_storage():
    context = DeterministicContext(
        time_provider=fixed_time,
        uuid_provider=fixed_uuid,
    )
    builder = TraceBuilder(context=context)
    client = AuditOpenAIClient(
        client=FakeClient(),
        trace_builder=builder,
        mode=AuditMode.RECORD,
        stream_chunk_group_size=2,
    )

    chunks = list(
        client.chat_completion_stream(
            model="gpt-4",
            messages=[{"role": "user", "content": "hello"}],
        )
    )
    assert len(chunks) == 4

    trace = builder.build()
    assert trace.events[0].type == "llm_stream"
    recorded_chunks = trace.events[0].output["chunks"]
    assert len(recorded_chunks) == 2
