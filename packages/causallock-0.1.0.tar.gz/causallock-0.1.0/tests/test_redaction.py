from causallock.security.redaction import RedactionEngine
from causallock.security.default_rules import DEFAULT_REDACTION_RULES


def test_email_redaction():
    engine = RedactionEngine(DEFAULT_REDACTION_RULES)

    data = {
        "message": "Contact me at john@example.com"
    }

    redacted = engine.apply(data)

    assert "[REDACTED_EMAIL]" in redacted["message"]