# causallock

causallock is a deterministic execution recording, replay, and audit platform for AI agents.

It provides:
- deterministic trace capture (`.traj`)
- hash-chain integrity verification
- replay validation and divergence detection
- regression testing at trace level
- cryptographic signing support
- UI control plane for replay/diff/VCR/redaction/trust workflows

---

## What This Project Is

causallock is not a prompt evaluator.  
It is execution infrastructure for reliability and auditability:

- record each LLM/tool event
- preserve event ordering and hashes
- replay under deterministic constraints
- detect divergence at payload/hash/order levels
- expose trust evidence for compliance-style review

---

## Distribution Model (No Node Required for End Users)

End users install and run with Python only:

```bash
pip install causallock
causallock ui
```

This works because the built React dashboard is packaged into `causallock/ui/static` and served by FastAPI.

You do **not** need `cd dashboard` as an end user.

---

## Install

### From local source

```bash
pip install .
```

### Editable (contributors)

```bash
pip install -e .
```

### From GitHub

```bash
pip install "git+https://github.com/GunaShankar0213/CausalLock.git"
```

---

## Quick Run

```bash
causallock init run .
causallock ui
```

Open:
- `http://127.0.0.1:8765/ui`

Recommended server start options:

```bash
# Preferred
causallock ui

# Equivalent backend launch
uvicorn causallock.ui.server:app --host 127.0.0.1 --port 8765
```

---

## CLI Commands

### Replay

```bash
causallock replay run regression/sample1.traj
causallock replay run regression/sample1.traj --immutable --seed 1337
causallock replay run regression/sample1.traj --immutable --force-env-mismatch
```

### Diff

```bash
causallock diff run regression/sample1.traj regression/sample2.traj
causallock diff run regression/sample1.traj regression/sample2.traj --semantic
```

### Regression

```bash
causallock test run regression --workers 4 --json-output
causallock test run regression --strict
```

### Freeze snapshots

```bash
causallock freeze run regression/
```

### Signing

```bash
causallock sign keygen --output keys
causallock sign sign regression/sample1.traj keys/private.key
causallock sign verify regression/sample1.traj
causallock sign sign regression/sample1.traj keys/private.key --detached --signature-path regression/sample1.sig --key-id team-key-1
causallock sign verify regression/sample1.traj --signature-path regression/sample1.sig
```

---

## API Surface (`/api/*`)

### Trace + search
- `GET /api/traces`
- `GET /api/trace/{trace_name}`
- `GET /api/trace/{trace_name}/events`
- `GET /api/trace/{trace_name}/event/{index}`
- `GET /api/trace/{trace_name}/state?index=N`
- `GET /api/search?q=...`

### Replay control
- `POST /api/replay/start`
- `POST /api/replay/step`
- `POST /api/replay/stop`
- `GET /api/replay/status`
- `GET /api/replay/progress/{session_id}` (SSE event: `replay_progress`)

### Diff / VCR / redaction / trust
- `GET /api/diff?traceA=...&traceB=...&semantic=true|false`
- `GET /api/vcr/stats`
- `GET /api/vcr/{tool_hash}`
- `GET /api/redaction/rules`
- `GET /api/trace/{trace_name}/redaction-log`
- `GET /api/trust/{trace_name}`
- `POST /api/test/run`

---

## UI Pages and Components

The packaged dashboard includes:

### 1. Explorer
- grouped runs by `project_name -> agent_name`
- trace cards (name/id/model/seed/signature/hash-chain/event count)
- virtualized timeline
- lazy payload inspector

### 2. Replay
- start/step/stop replay
- immutable replay toggle
- optional seed override
- replay status panel
- live SSE progress stream
- deterministic state snapshot viewer

### 3. Diff
- trace A/B selection
- semantic toggle
- structured divergence result:
  - `type`
  - `summary`
  - `field_deltas`
  - `divergence_index`

### 4. VCR
- cache hit/miss totals
- unique payload hash count
- per-tool usage
- lookup by tool payload hash

### 5. Redaction
- active rule listing
- per-trace redaction marker log

### 6. Trust
- hash-chain status
- signature status
- environment mismatch fields
- CAS presence check
- strict regression run trigger

---

## UI Event Tags and Meanings

Event row colors/types:
- `llm_call`: discrete model invocation
- `llm_stream`: streaming model output event
- `tool_call`: tool execution capture/replay unit
- generic fallback: non-categorized deterministic event

Trace card tags:
- `signed` / `unsigned`
- `chain ok` / `chain bad`
- `model <name>`
- `seed <value>`

---

## Multi-Agent Grouping

Trace schema fields:
- `project_name`
- `agent_name`

UI groups using these fields.

Backward compatibility for older traces:
- inferred from filename patterns:
  - `project__agent__...`
  - `project-agent-...`

---

## Real-Time Example (Ollama Phi)

```bash
python scripts/ollama_realtime_example.py \
  --model phi4 \
  --project customer_support \
  --agent planner \
  --runs 5 \
  --seed 1337 \
  --show-ui
```

What this does:
- live OpenAI-compatible calls to Ollama
- deterministic trace capture
- CAS write
- immutable replay verification per run
- auto-opens UI
- file naming suitable for grouping:
  - `project__agent__model__run_N.traj`

After generating demo traces, replay one run:

```bash
causallock replay run regression/demo__planner__phi4__run_1.traj --immutable --seed 1337
```

---

## Contributor Workflow (when editing UI)

### Dev mode (HMR)

```bash
cd dashboard
npm install
npm run dev
```

### Sync built UI into Python package

```bash
python scripts/sync_dashboard_static.py
```

This builds `dashboard/dist` and copies it into `causallock/ui/static`.

---

## Release Automation

Prepare release artifacts with one command:

```bash
python scripts/prepare_release.py
```

It runs:
1. Python tests
2. dashboard build + static sync
3. `python -m build`

---

## Verification

```bash
python -m pytest -q
python -m py_compile causallock/ui/server.py scripts/ollama_realtime_example.py
cd dashboard && npm run build
```

---

## Why Use causallock (Pros)

- reproducible replay workflows for agent debugging
- deterministic integrity model (hash-chain + root hash metadata)
- fast CI-grade regression without paid model calls
- strong auditability path (signature + trust diagnostics)
- project/agent grouping for multi-agent systems
- Python-first distribution (`pip install` + single `causallock ui`)

---

## Conclusion and Expansion Path

causallock now supports a full local-first deterministic execution workflow:
- record
- replay
- diff
- regression
- trust inspection

Natural next expansion tracks:
- WebGL graph layer for large trace topology
- WASM diff/hashing accelerators
- multi-user relay and RBAC
- compliance bundle export pipeline
 
---  
 
## Troubleshooting  
 
- Use `causallock ui` or `uvicorn causallock.ui.server:app --host 127.0.0.1 --port 8765` to start UI backend.  
- Do not rely on `python -m causallock.ui.server` unless you explicitly add a module runner block.  
- If replay says `Trace file not found`, first list available files: `dir regression` then replay with an exact filename.  
- If `causallock` command is not found, use `python -m causallock.cli.main --help` or add Python Scripts path to PATH. 
