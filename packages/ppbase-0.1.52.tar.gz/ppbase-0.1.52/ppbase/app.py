"""FastAPI application factory."""

from __future__ import annotations

import logging
import os
import sys
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from ppbase.config import Settings

if TYPE_CHECKING:
    from ppbase.ext.registry import ExtensionRegistry

logger = logging.getLogger(__name__)


def _handle_db_connection_error(database_url: str, exc: BaseException) -> None:
    """Print a clear message when PostgreSQL is unreachable and exit."""
    import re
    # Mask password in URL for display
    safe_url = re.sub(r"://([^:]*):([^@]*)@", r"://\1:****@", database_url)

    msg = (
        "\n"
        "PostgreSQL is not reachable. PPBase cannot start without a database.\n"
        "\n"
        "  Database URL: %s\n"
        "\n"
        "  Make sure PostgreSQL is running, then try:\n"
        "    python -m ppbase db start   # start PostgreSQL via Docker\n"
        "\n"
        "  Or set PPBASE_DATABASE_URL if using a different database.\n"
    ) % safe_url
    print(msg, file=sys.stderr)
    os._exit(1)  # Exit immediately without raising (avoids traceback)


@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Manage startup and shutdown of the database engine."""
    import asyncio
    from ppbase.db.engine import init_engine, close_engine
    from ppbase.db.system_tables import create_system_tables
    from ppbase.ext.events import BootstrapEvent, ServeEvent, TerminateEvent
    from ppbase.ext.registry import HOOK_BOOTSTRAP, HOOK_SERVE, HOOK_TERMINATE
    from ppbase.services.realtime_service import SubscriptionManager, listen_for_db_events

    settings: Settings = app.state.settings
    extensions = getattr(app.state, "extension_registry", None)

    if not settings.jwt_secret and not settings.dev:
        logger.warning(
            "PPBASE_JWT_SECRET is not set; PPBase will use a project-local generated "
            "secret from data_dir/.jwt_secret."
        )

    if extensions is not None:
        await extensions.hooks.get(HOOK_BOOTSTRAP).trigger(
            BootstrapEvent(app=app, settings=settings),
        )

    # Startup: create engine and ensure system tables exist
    try:
        engine = await init_engine(
            settings.database_url,
            pool_size=settings.pool_size,
            max_overflow=settings.max_overflow,
            echo=settings.dev,
        )
        await create_system_tables(engine)
    except (ConnectionRefusedError, OSError) as exc:
        _handle_db_connection_error(settings.database_url, exc)

    # Initialize realtime subscription manager
    subscription_manager = SubscriptionManager(extension_registry=extensions)
    app.state.subscription_manager = subscription_manager

    # Start PostgreSQL LISTEN task for realtime events
    listen_task = asyncio.create_task(
        listen_for_db_events(engine, subscription_manager)
    )
    logger.info("Started PostgreSQL LISTEN task for realtime events")

    # Bootstrap all system collections and backfill auth options
    from ppbase.db.bootstrap import bootstrap_system_collections
    from ppbase.db.system_tables import ParamRecord
    from ppbase.services.auth_service import generate_default_auth_options
    from ppbase.services.file_storage import configure_storage_runtime_from_settings_payload
    from sqlalchemy.ext.asyncio import AsyncSession as _AS, async_sessionmaker as _asm

    _boot_factory = _asm(bind=engine, class_=_AS, expire_on_commit=False)
    async with _boot_factory() as _boot_session:
        async with _boot_session.begin():
            await bootstrap_system_collections(_boot_session, engine)

            # Backfill auth options for existing auth collections
            from ppbase.db.system_tables import CollectionRecord
            from sqlalchemy import select

            stmt = select(CollectionRecord).where(CollectionRecord.type == "auth")
            auth_colls = (await _boot_session.execute(stmt)).scalars().all()
            for coll in auth_colls:
                opts = coll.options or {}
                if not opts.get("authToken"):
                    is_su = (coll.name == "_superusers")
                    coll.options = generate_default_auth_options(is_superusers=is_su)
                    await _boot_session.flush()

            settings_stmt = select(ParamRecord.value).where(ParamRecord.key == "settings")
            settings_row = (await _boot_session.execute(settings_stmt)).scalar_one_or_none()
            configure_storage_runtime_from_settings_payload(
                settings_row if isinstance(settings_row, dict) else None
            )

    # Apply pending migrations if auto_migrate is enabled
    if settings.auto_migrate:
        from ppbase.services.migration_runner import apply_all_pending
        from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

        migrations_dir = settings.migrations_dir
        os.makedirs(migrations_dir, exist_ok=True)

        session_factory = async_sessionmaker(
            bind=engine, class_=AsyncSession, expire_on_commit=False,
        )
        async with session_factory() as session:
            try:
                async with session.begin():
                    applied = await apply_all_pending(session, engine, migrations_dir)
                if applied:
                    logger.info(
                        "Applied %d pending migration(s) on startup", len(applied)
                    )
                else:
                    logger.debug("No pending migrations to apply")
            except Exception as exc:
                logger.error(
                    "Migration failed during startup: %s", exc
                )
                raise
    else:
        logger.info("Auto-migrate disabled, skipping migration check")

    # Check if any admin exists — if not, generate setup token and print unique URL
    from ppbase.services.admin_service import count_admins
    from ppbase.services.setup_service import get_or_create_setup_token
    from sqlalchemy.ext.asyncio import AsyncSession as _CheckAS, async_sessionmaker as _check_asm

    _check_factory = _check_asm(bind=engine, class_=_CheckAS, expire_on_commit=False)
    async with _check_factory() as _check_session:
        admin_count = await count_admins(_check_session)
        if admin_count == 0:
            setup_token = await get_or_create_setup_token(_check_session)
            await _check_session.commit()

    if admin_count == 0:
        display_host = settings.host if settings.host != "0.0.0.0" else "127.0.0.1"
        setup_url = f"http://{display_host}:{settings.port}/_/setup?token={setup_token}"
        print(
            "\n"
            "  No admin account found. Create your first admin:\n"
            "\n"
            f"  {setup_url}\n"
            "\n"
            "  This is a one-time link — open it in your browser.\n"
        )
        # Try to open in browser (PocketBase-style)
        try:
            import webbrowser
            if sys.stdin.isatty():
                webbrowser.open(setup_url)
        except Exception:
            pass

    if extensions is not None:
        await extensions.hooks.get(HOOK_SERVE).trigger(
            ServeEvent(app=app, settings=settings),
        )

    yield

    if extensions is not None:
        await extensions.hooks.get(HOOK_TERMINATE).trigger(
            TerminateEvent(app=app, settings=settings),
        )

    # Shutdown: cancel LISTEN task and dispose of the connection pool
    logger.info("Shutting down PostgreSQL LISTEN task")
    listen_task.cancel()
    try:
        await listen_task
    except asyncio.CancelledError:
        pass

    await close_engine()


def create_app(
    settings: Settings | None = None,
    *,
    extensions: "ExtensionRegistry | None" = None,
) -> FastAPI:
    """Build and return the FastAPI application.

    Args:
        settings: Optional ``Settings`` instance.  If not provided a
            default ``Settings()`` is created (reads env / .env).

    Returns:
        A fully configured :class:`FastAPI` application.
    """
    if settings is None:
        settings = Settings()

    app = FastAPI(
        title="PPBase",
        version="0.1.0",
        docs_url="/api/docs" if settings.dev else None,
        redoc_url=None,
        lifespan=_lifespan,
    )

    # Attach settings to app state so dependencies can access them
    app.state.settings = settings
    app.state.extension_registry = extensions
    app.state.rate_limit_settings_version = 0

    from ppbase.services.file_storage import set_storage_settings

    set_storage_settings(settings)

    # CORS
    from ppbase.middleware.cors import setup_cors

    setup_cors(app, settings.origins)

    # Request logger
    from ppbase.middleware.request_logger import RequestLoggerMiddleware
    from ppbase.middleware.rate_limit import RateLimitMiddleware

    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(RequestLoggerMiddleware)

    # API routes
    from ppbase.api.router import (
        api_router,
        _records_router,
        _record_auth_router,
        _realtime_router,
    )

    app.include_router(api_router, prefix="/api")

    # The records router uses full paths like /api/collections/{...}/records
    # so it must be included at the root level.
    if _records_router is not None:
        app.include_router(_records_router, tags=["records"])

    # The record auth router uses full paths like /api/collections/{...}/auth-*
    # so it must also be included at the root level.
    if _record_auth_router is not None:
        app.include_router(_record_auth_router, tags=["record-auth"])

    # The realtime router uses full paths like /api/realtime
    # so it must also be included at the root level.
    if _realtime_router is not None:
        app.include_router(_realtime_router, tags=["realtime"])

    if extensions is not None:
        extensions.mount_routes(app)

    # Admin UI - serve static files from ppbase/admin/dist/
    import pathlib

    from fastapi.responses import FileResponse, Response
    from fastapi.staticfiles import StaticFiles

    admin_dist = pathlib.Path(__file__).parent / "admin" / "dist"
    if admin_dist.is_dir():
        # Serve static assets (css/, js/)
        app.mount(
            "/_/assets",
            StaticFiles(directory=str(admin_dist)),
            name="admin-assets",
        )

        # Serve admin SPA at /_/ (all routes fall back to index.html)
        @app.get("/_/{rest_of_path:path}", include_in_schema=False)
        async def _admin_spa(rest_of_path: str = "") -> FileResponse:
            index = admin_dist / "index.html"
            if index.exists():
                return FileResponse(str(index))
            return JSONResponse(
                {"message": "Admin UI not built"}, status_code=404
            )

        # Redirect root /_/ access
        @app.get("/_", include_in_schema=False)
        async def _admin_redirect():
            from fastapi.responses import RedirectResponse

            return RedirectResponse("/_/")

    # Public directory (PocketBase-like): files are served at /
    # without directory listing; "/" serves index.html when present.
    public_dir = str(settings.public_dir or "").strip()
    if public_dir:
        public_root = pathlib.Path(public_dir).expanduser().resolve()

        @app.get("/", include_in_schema=False)
        async def _public_index() -> Response:
            index = public_root / "index.html"
            if index.is_file():
                return FileResponse(str(index))
            return Response(status_code=404)

        @app.get("/{public_path:path}", include_in_schema=False)
        async def _public_file(public_path: str) -> Response:
            normalized = public_path.strip("/")
            if not normalized:
                return Response(status_code=404)
            if (
                normalized in {"api", "_"}
                or normalized.startswith("api/")
                or normalized.startswith("_/")
            ):
                raise HTTPException(status_code=404, detail="Not Found")

            candidate = (public_root / normalized).resolve()
            try:
                candidate.relative_to(public_root)
            except ValueError:
                return Response(status_code=404)

            if not candidate.is_file():
                return Response(status_code=404)
            return FileResponse(str(candidate))

    # Custom exception handler: PocketBase returns flat error objects, not
    # FastAPI's default {"detail": ...} wrapper.
    @app.exception_handler(HTTPException)
    async def _pocketbase_error_handler(
        request: Request, exc: HTTPException
    ) -> JSONResponse:
        detail = exc.detail
        if isinstance(detail, dict) and "status" in detail:
            # Already a PocketBase-format error dict
            return JSONResponse(
                content=detail,
                status_code=exc.status_code,
            )
        # Fallback: wrap plain string errors
        return JSONResponse(
            content={
                "status": exc.status_code,
                "message": str(detail) if detail else "",
                "data": {},
            },
            status_code=exc.status_code,
        )

    # Handle Pydantic request validation errors in PocketBase format.
    @app.exception_handler(RequestValidationError)
    async def _validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        data: dict = {}
        for err in exc.errors():
            loc = err.get("loc", ())
            # Field name is typically the last element after "body"
            field_name = str(loc[-1]) if loc else "unknown"
            data[field_name] = {
                "code": "validation_required",
                "message": err.get("msg", "Invalid value."),
            }
        return JSONResponse(
            content={
                "status": 400,
                "message": "Something went wrong while processing your request.",
                "data": data,
            },
            status_code=400,
        )

    return app
