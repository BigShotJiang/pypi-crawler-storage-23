"""Auth middleware.

Authentication is handled via FastAPI dependency injection in ``api/deps.py``.
This module is kept as a placeholder for any future ASGI-level auth middleware
that might be needed (e.g., rate limiting tied to auth state).
"""
