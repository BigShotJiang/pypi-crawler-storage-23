from datetime import date, datetime
import ipaddress
from logging import getLogger
import re
from typing import Callable, Iterator, IO, List, Set


from urllib.parse import (
    urlparse,
    parse_qs,
    urlencode,
    urlunparse
)


logger = getLogger(__name__)

LOG_REGEXES = {
    "apache": (
        r"(?P<ip_address>\d+\.\d+\.\d+\.\d+) "
        r"(?P<users>.+ .+) "
        r"\[(?P<timestamp>.+)\] "
        r'"(?P<request>.+)" '
        r"(?P<status_code>\d+) "        
        r"(?P<sent_bytes>\d+) "         
        r'(?P<referer>".+") '
        r'"(?P<user_agent>.+)"'
    ),
    "aws_alb": (  # AWS Application Load Balancer
        r"[^ ]+ "                           # type (e.g. h2)
        r"(?P<timestamp>[^ ]+) "            
        r"[^ ]+ "                           # elb_id
        r"(?P<ip_address>[^:]+):[^ ]+ "     # client:port (Capture IP only)
        r"[^ ]+ "                           # target:port
        r"[^ ]+ [^ ]+ [^ ]+ "               # processing times
        r"(?P<status_code>\d+) "            # elb_status_code
        r"[^ ]+ [^ ]+ "                     # target_status_code received_bytes
        r"(?P<sent_bytes>\d+) "             
        r"\"(?P<request>[^\"]+)\" "         
        r"\"(?P<user_agent>[^\"]+)\" "      
        r".*"                               # Ignore the rest (ssl, arn, etc)
    )
}


class Request:
    """Represent the data in a single line of the Apache log file."""

    def __init__(
            self,
            ip_address: str,
            url_prefix: str,
            url: str,
            response_code: int,
            content_length: int,
            timestamp: datetime,
            user_agent: str,
            match_url_params: list[str] | None = None,
            canonical_url_params: list[str] | None = None,
            keep_trailing_slash: bool = False,
    ):
        self.ip_address = ip_address
        self.timestamp = timestamp
        self.user_agent = user_agent or ""
        self.response_code = response_code
        self.content_length = content_length

        """Note: 
            self.match_url is used to match a URL to a measure_uri.
            self.canonical_url is returned to later match it against the work.
            By default url params will be stripped in both scenarios. 
        """
        self.raw_url = url
        self.parsed_url = urlparse(url)

        self.match_url, self.canonical_url = self._build_dual_urls(
            url,
            url_prefix,
            match_url_params,
            canonical_url_params,
            keep_trailing_slash=keep_trailing_slash,
        )

    @staticmethod
    def _clean_path(path: str) -> str:
        """Removes duplicate slashes and trailing slashes from a URL path."""
        if not path:
            return ""

        cleaned = re.sub(r'/+', '/', path)
        if cleaned != "/" and cleaned.endswith("/"):
            cleaned = cleaned.rstrip("/")

        return cleaned

    @staticmethod
    def _build_dual_urls(
            raw_url: str,
            url_prefix: str,
            match_params: list[str] | None = None,
            canonical_params: list[str] | None = None,
            keep_trailing_slash: bool = False,
    ) -> tuple[str, str]:
        """Standardizes a URL by swapping its domain, cleaning its path,
        and builds two distinct versions based on different parameter filters.

        Returns: (match_url, canonical_url)
        """
        match_params = match_params or []
        canonical_params = canonical_params or []

        parsed_original = urlparse(raw_url)
        parsed_prefix = urlparse(url_prefix)
        params_dict = parse_qs(parsed_original.query)

        def _filter_query(allowed_params: list[str] | None) -> str:
            if not allowed_params:
                return ""

            filtered = []
            for key in allowed_params:
                if key in params_dict:
                    for value in params_dict[key]:
                        filtered.append((key, value))
            return urlencode(filtered)

        try:
            match_query = _filter_query(match_params)
            cannon_query = _filter_query(canonical_params)

            original_path = parsed_original.path
            if not keep_trailing_slash and original_path != "/":
                original_path = original_path.rstrip('/')

            base_parts = parsed_prefix._replace(  # Created shared the base URL
                path=original_path,
                fragment=""  # Strip fragments globally
            )

            match_url = urlunparse(base_parts._replace(query=match_query))
            canonical_url = urlunparse(base_parts._replace(query=cannon_query))

            return match_url, canonical_url

        except Exception as err:
            logger.error(f"Error processing URL '{raw_url}': {err}")
            raise

    def fmttime(self) -> str:
        return self.timestamp.strftime("%Y-%m-%d %H:%M:%S")

    def __str__(self) -> str:
        return (
            f"Request {self.fmttime()}, {self.ip_address}, {self.canonical_url}"
        )

    def __iter__(self):
        for _item in self.as_tuple():
            yield _item

    def as_tuple(self) -> tuple[str, str, str, str]:
        return (
            self.fmttime(),
            self.ip_address,
            self.canonical_url,
            self.user_agent
        )


class LogProcessor:
    """Consumes an open file stream, parses lines, applies filters,
    and yields Request objects.
    """

    def __init__(
            self,
            measure_regexes: dict,
            url_prefix: str,
            start_date: str,
            end_date: str,
            log_type: str = "apache",
            log_re_pattern: str | None = None,
            excluded_ips: list[str] | None = None,
            allowed_codes: list[str] | None = None,
            match_url_params: list[str] | None = None,
            canonical_url_params: list[str] | None = None,
            keep_trailing_slash: bool = False,
    ) -> None:
        self.url_prefix = url_prefix
        self.start_date = date.fromisoformat(start_date)
        self.end_date = date.fromisoformat(end_date)

        self.log_regex_patterns = LOG_REGEXES
        self.log_type = log_type
        self._set_log_regex(log_type, log_re_pattern)
        self.match_url_params = match_url_params or []
        self.canonical_url_params = canonical_url_params or []

        self.excluded_ips = set(excluded_ips) if excluded_ips else set()
        self.allowed_codes = set(allowed_codes) if allowed_codes else {200, 304}
        self.url_matchers = [  # Build the extractors once during startup
            (item["measure"], make_matcher(item["regex"]))
            for item in measure_regexes
        ]
        self.keep_trailing_slash = keep_trailing_slash

    def _set_log_regex(self, log_type: str, log_pattern) -> None:
        """Attempt to determine regex pattern to use based on log type."""
        if log_type is None:
            self.log_regex = None
            return None
        elif log_type in LOG_REGEXES:
            log_pattern = LOG_REGEXES[log_type]
        elif log_type == "custom":
            if not log_pattern:
                ValueError(
                    f"`log_re_pattern` must be specified for "
                    f"`log_type` value 'custom'."
                )

        self.log_regex = re.compile(log_pattern)
        return None

    def _determine_log_regex(self, line: str) -> tuple:
        """Determine the regex pattern that matches the log line. If no pattern
        matches, raises a ValueError.

        Args:
            line (str): Log line to match against the registered regex patterns.

        Raises:
            ValueError: If no regex pattern matches the log line.

        Returns:
            tuple: The regex pattern that matches the given log line.
        """
        for log_type, log_pattern in self.log_regex_patterns.items():
            match = re.search(log_pattern, line)
            if match:
                return log_type, log_pattern
        else:
            raise ValueError(
                f"No regex patterns found that match the format of the log "
                f"file. Please set a custom regex pattern."
            )

    def process(self, file_stream: IO[str]) -> Iterator[tuple]:
        """Takes a file-like object (text mode), iterates it, and yields
         filtered results.
        """
        for line in file_stream:
            if isinstance(line, bytes):  # Handle mixed bytes/string input.
                line = line.decode("utf-8")

            if line := line.strip():
                request_obj = self._parse_line(line)
                if not request_obj or not is_valid_request(
                        request_obj,
                        self.allowed_codes,
                        self.excluded_ips
                ):
                    continue

                for measure_uri, matcher in self.url_matchers:
                    if matcher(request_obj.match_url):
                        yield measure_uri, request_obj
                        break  # only allow one measure to match per line

    def _parse_line(self, line: str) -> Request | None:
        """Internal method to match regex and create a Request object"""
        if not self.log_regex:
            self.log_type, log_pattern = self._determine_log_regex(line)
            self._set_log_regex(self.log_type, log_pattern)

        match = self.log_regex.search(line)
        if not match:
            logger.warning(f"Skipping malformed line: {line.strip()[:100]}...")
            return None
        data = match.groupdict()

        try:
            if self.log_type == "apache":
                timestamp = datetime.strptime(
                    data.pop("timestamp"),
                    "%d/%b/%Y:%H:%M:%S %z"
                )
            elif self.log_type == "aws_alb":
                ts_str = data.pop("timestamp")
                timestamp = datetime.fromisoformat(ts_str)
            else:
                logger.error(
                    f"Log type {self.log_type} is not currently supported."
                )  # TODO: Add support for custom timestamp format.
                raise ValueError("Invalid log type")
        except ValueError:
            return None

        if not self.start_date <= timestamp.date() <= self.end_date:
            return None

        user_agent = data.get("user_agent", "-")
        ip = data.pop("ip_address")
        if not self._validate_ip(ip):
            return None

        if url := self._validate_request(data.pop("request")):
            return Request(
                ip_address=ip,
                url_prefix=self.url_prefix,
                url=url,
                response_code=int(data["status_code"]),
                content_length=int(data["sent_bytes"]),
                timestamp=timestamp,
                user_agent=user_agent,
                match_url_params=self.match_url_params,
                canonical_url_params=self.canonical_url_params,
                keep_trailing_slash=self.keep_trailing_slash,
            )

    @staticmethod
    def _validate_request(request_str):
        parts = request_str.split()
        if len(parts) == 3:
            return parts[1]
        return None

    @staticmethod
    def _validate_ip(ip_address_str):
        """Validates whether the string is a valid IPv4 or IPv6 address."""
        try:
            ipaddress.ip_address(ip_address_str)
            return True
        except ValueError:
            return False  # TODO: fix country code for IP6 Addresses


def is_valid_request(
        request: Request,
        allowed_codes: Set[int],
        excluded_ips: Set[str]
) -> bool:
    """Runs cheap boolean checks to immediately discard garbage requests."""

    if request.response_code not in allowed_codes:
        return False

    if request.ip_address in excluded_ips:
        return False

    if request.parsed_url.path == "*" or "+http" in request.user_agent:
        return False

    return True


def make_matcher(regexes: List[str]) -> Callable[[str], bool]:
    """Compile patterns once and returns a boolean function that checks if a
    URL matches any of the patterns.
    """
    compiled_patterns = [re.compile(r) for r in regexes]

    def matches(url: str) -> bool:
        return any(pattern.search(url) for pattern in compiled_patterns)

    return matches
