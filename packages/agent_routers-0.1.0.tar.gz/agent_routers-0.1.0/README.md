# Agent Routers

> Deterministic, priority-based routing engine for multi-agent systems.

Agent Routers is a lightweight Python library for building rule-based routing layers.
It allows you to register sync or async handlers and dispatch inputs using
priority-aware regex matching — without requiring LLMs or web frameworks.

---

## Why Agent Routers?

- Supports **sync and async handlers**
- Deterministic, priority-based rule resolution
- Perfect for multi-agent supervisors and orchestration layers
- Minimal overhead, zero external dependencies

---

## Installation

```bash
pip install agent-routers
```
