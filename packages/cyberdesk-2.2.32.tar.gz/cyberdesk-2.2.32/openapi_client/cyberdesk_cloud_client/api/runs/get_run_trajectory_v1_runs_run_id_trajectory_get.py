from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.trajectory_response import TrajectoryResponse
from ...types import Response


def _get_kwargs(
    run_id: UUID,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/runs/{run_id}/trajectory".format(
            run_id=quote(str(run_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | TrajectoryResponse | None:
    if response.status_code == 200:
        response_200 = TrajectoryResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | TrajectoryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | TrajectoryResponse]:
    """Get Run Trajectory

     Get the latest trajectory associated with a run.

    Returns generated and non-generated trajectories so run details can expose
    generation state.

    Selection is based on newest `updated_at` for the run. If a duplicated
    trajectory linked to the run is now the latest row, this endpoint will
    return that duplicate.

    Args:
        run_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TrajectoryResponse]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | TrajectoryResponse | None:
    """Get Run Trajectory

     Get the latest trajectory associated with a run.

    Returns generated and non-generated trajectories so run details can expose
    generation state.

    Selection is based on newest `updated_at` for the run. If a duplicated
    trajectory linked to the run is now the latest row, this endpoint will
    return that duplicate.

    Args:
        run_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TrajectoryResponse
    """

    return sync_detailed(
        run_id=run_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | TrajectoryResponse]:
    """Get Run Trajectory

     Get the latest trajectory associated with a run.

    Returns generated and non-generated trajectories so run details can expose
    generation state.

    Selection is based on newest `updated_at` for the run. If a duplicated
    trajectory linked to the run is now the latest row, this endpoint will
    return that duplicate.

    Args:
        run_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TrajectoryResponse]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | TrajectoryResponse | None:
    """Get Run Trajectory

     Get the latest trajectory associated with a run.

    Returns generated and non-generated trajectories so run details can expose
    generation state.

    Selection is based on newest `updated_at` for the run. If a duplicated
    trajectory linked to the run is now the latest row, this endpoint will
    return that duplicate.

    Args:
        run_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TrajectoryResponse
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            client=client,
        )
    ).parsed
