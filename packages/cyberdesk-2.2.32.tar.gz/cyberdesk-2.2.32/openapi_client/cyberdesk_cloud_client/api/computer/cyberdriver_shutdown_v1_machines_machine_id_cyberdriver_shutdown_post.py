from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cyberdriver_shutdown_request import CyberdriverShutdownRequest
from ...models.cyberdriver_shutdown_v1_machines_machine_id_cyberdriver_shutdown_post_response_cyberdriver_shutdown_v1_machines_machine_id_cyberdriver_shutdown_post import (
    CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    machine_id: str,
    *,
    body: CyberdriverShutdownRequest | None | Unset = UNSET,
    idempotency_key: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(idempotency_key, Unset):
        headers["Idempotency-Key"] = idempotency_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/machines/{machine_id}/cyberdriver/shutdown".format(
            machine_id=quote(str(machine_id), safe=""),
        ),
    }

    if isinstance(body, CyberdriverShutdownRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost
    | HTTPValidationError
    | None
):
    if response.status_code == 200:
        response_200 = CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 403:
        response_403 = cast(Any, None)
        return response_403

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost
    | HTTPValidationError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    machine_id: str,
    *,
    client: AuthenticatedClient,
    body: CyberdriverShutdownRequest | None | Unset = UNSET,
    idempotency_key: str | Unset = UNSET,
) -> Response[
    Any
    | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost
    | HTTPValidationError
]:
    """Shutdown Cyberdriver via tunnel

     Request CyberDriver process shutdown through the existing tunnel proxy path.

    Args:
        machine_id (str):
        idempotency_key (str | Unset):  Example: 550e8400-e29b-41d4-a716-446655440000.
        body (CyberdriverShutdownRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        machine_id=machine_id,
        body=body,
        idempotency_key=idempotency_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    machine_id: str,
    *,
    client: AuthenticatedClient,
    body: CyberdriverShutdownRequest | None | Unset = UNSET,
    idempotency_key: str | Unset = UNSET,
) -> (
    Any
    | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost
    | HTTPValidationError
    | None
):
    """Shutdown Cyberdriver via tunnel

     Request CyberDriver process shutdown through the existing tunnel proxy path.

    Args:
        machine_id (str):
        idempotency_key (str | Unset):  Example: 550e8400-e29b-41d4-a716-446655440000.
        body (CyberdriverShutdownRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost | HTTPValidationError
    """

    return sync_detailed(
        machine_id=machine_id,
        client=client,
        body=body,
        idempotency_key=idempotency_key,
    ).parsed


async def asyncio_detailed(
    machine_id: str,
    *,
    client: AuthenticatedClient,
    body: CyberdriverShutdownRequest | None | Unset = UNSET,
    idempotency_key: str | Unset = UNSET,
) -> Response[
    Any
    | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost
    | HTTPValidationError
]:
    """Shutdown Cyberdriver via tunnel

     Request CyberDriver process shutdown through the existing tunnel proxy path.

    Args:
        machine_id (str):
        idempotency_key (str | Unset):  Example: 550e8400-e29b-41d4-a716-446655440000.
        body (CyberdriverShutdownRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        machine_id=machine_id,
        body=body,
        idempotency_key=idempotency_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    machine_id: str,
    *,
    client: AuthenticatedClient,
    body: CyberdriverShutdownRequest | None | Unset = UNSET,
    idempotency_key: str | Unset = UNSET,
) -> (
    Any
    | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost
    | HTTPValidationError
    | None
):
    """Shutdown Cyberdriver via tunnel

     Request CyberDriver process shutdown through the existing tunnel proxy path.

    Args:
        machine_id (str):
        idempotency_key (str | Unset):  Example: 550e8400-e29b-41d4-a716-446655440000.
        body (CyberdriverShutdownRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPostResponseCyberdriverShutdownV1MachinesMachineIdCyberdriverShutdownPost | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            machine_id=machine_id,
            client=client,
            body=body,
            idempotency_key=idempotency_key,
        )
    ).parsed
