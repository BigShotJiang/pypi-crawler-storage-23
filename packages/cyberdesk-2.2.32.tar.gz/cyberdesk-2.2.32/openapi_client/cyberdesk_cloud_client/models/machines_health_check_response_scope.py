from enum import Enum


class MachinesHealthCheckResponseScope(str, Enum):
    ALL_ORGANIZATIONS = "all_organizations"
    ORGANIZATION = "organization"

    def __str__(self) -> str:
        return str(self.value)
