"""
VibeFoundry IDE - A local IDE for data science workflows
"""

__version__ = "0.1.38"
__all__ = ["main"]

from vibefoundry.cli import main
