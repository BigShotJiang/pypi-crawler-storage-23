
class Concavity:
    pass
