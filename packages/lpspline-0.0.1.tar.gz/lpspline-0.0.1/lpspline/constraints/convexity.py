
class Convexity:
    pass
