
class Monotonicity:
    pass

class Concavity:
    pass

class Convexity:
    pass

class Anchor:
    pass
