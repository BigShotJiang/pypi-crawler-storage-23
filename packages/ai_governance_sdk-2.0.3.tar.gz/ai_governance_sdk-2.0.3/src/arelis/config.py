"""Client configuration for the Arelis AI SDK.

Ports ``ClientConfig`` from the TypeScript SDK's ``packages/sdk/src/config.ts``.
Provides the :class:`ClientConfig` dataclass containing all registries, engines,
and optional components needed to construct an :class:`~arelis.client.ArelisClient`.
"""

from __future__ import annotations

from dataclasses import dataclass

from arelis.audit.sink import AuditSink
from arelis.compliance.types import ComplianceConfig
from arelis.core.run_context import ContextResolver
from arelis.core.types import GovernanceContext
from arelis.data_sources.registry import DataSourceRegistry
from arelis.evaluations.types import Evaluator
from arelis.extensions.config import ClientExtensionsConfig
from arelis.knowledge.registry import KBRegistry
from arelis.mcp.registry import MCPRegistry
from arelis.memory.registry import MemoryRegistry
from arelis.models.registry import ModelRegistry
from arelis.policy.engine import PolicyEngine
from arelis.policy.redactor import Redactor
from arelis.prompts.registry import TemplateRegistry
from arelis.quotas.manager import QuotaManager
from arelis.secrets.resolver import SecretResolver
from arelis.tools.registry import ToolRegistry

__all__ = [
    "ClientConfig",
    "PolicyCompilationConfig",
]


# ---------------------------------------------------------------------------
# Policy compilation config
# ---------------------------------------------------------------------------


@dataclass
class PolicyCompilationConfig:
    """Configuration for policy compilation.

    Attributes:
        compiler: The policy compiler to use.
        source: The compilation input source.
    """

    compiler: object
    source: object


# ---------------------------------------------------------------------------
# ClientConfig
# ---------------------------------------------------------------------------


@dataclass
class ClientConfig:
    """Configuration for the :class:`~arelis.client.ArelisClient`.

    The three required fields are ``model_registry``, ``policy_engine``, and
    ``audit_sink``.  All other fields have sensible defaults or are optional.

    Attributes:
        model_registry: Model registry for resolving model providers.
        policy_engine: Policy engine for governance decisions.
        audit_sink: Audit sink for writing audit events.
        telemetry: Optional telemetry for distributed tracing.
        context_resolver: Optional context resolver for governance context.
        tool_registry: Optional tool registry for tool operations.
        mcp_registry: Optional MCP registry for MCP server operations.
        kb_registry: Optional knowledge base registry for RAG operations.
        prompt_registry: Optional prompt template registry.
        memory_registry: Optional memory registry.
        data_source_registry: Optional data source registry.
        quota_manager: Optional quota manager.
        evaluators: Optional list of evaluators.
        approval_store: Optional approval store.
        secret_resolver: Optional secret resolver.
        redactor: Optional redactor for sensitive data.
        policy_compilation: Optional policy compilation config.
        compliance: Optional compliance configuration.
        extensions: Optional extension capability config.
        default_context: Optional default governance context used when
            individual operations do not supply one.
    """

    model_registry: ModelRegistry
    policy_engine: PolicyEngine
    audit_sink: AuditSink
    telemetry: object | None = None
    context_resolver: ContextResolver | None = None
    tool_registry: ToolRegistry | None = None
    mcp_registry: MCPRegistry | None = None
    kb_registry: KBRegistry | None = None
    prompt_registry: TemplateRegistry | None = None
    memory_registry: MemoryRegistry | None = None
    data_source_registry: DataSourceRegistry | None = None
    quota_manager: QuotaManager | None = None
    evaluators: list[Evaluator] | None = None
    approval_store: object | None = None
    secret_resolver: SecretResolver | None = None
    redactor: Redactor | None = None
    policy_compilation: PolicyCompilationConfig | None = None
    compliance: ComplianceConfig | None = None
    extensions: ClientExtensionsConfig | None = None
    default_context: GovernanceContext | None = None
