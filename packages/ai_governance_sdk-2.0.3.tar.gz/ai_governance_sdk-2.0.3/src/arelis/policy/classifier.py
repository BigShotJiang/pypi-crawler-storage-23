"""Data classifier for the Arelis AI SDK.

Ports the classifier from the TypeScript SDK's governance package.
Provides pattern-based data classification for determining sensitivity levels.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Literal, Protocol, runtime_checkable

__all__ = [
    "ClassificationLevel",
    "ClassificationResult",
    "Classifier",
    "PatternClassifier",
    "NoOpClassifier",
    "create_pattern_classifier",
    "create_no_op_classifier",
]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

ClassificationLevel = Literal["public", "internal", "confidential", "restricted"]
"""Data classification level, from least to most sensitive."""


@dataclass
class ClassificationResult:
    """Result of a data classification."""

    level: ClassificationLevel
    """Overall classification level."""

    categories: list[str]
    """Categories of data detected."""

    confidence: float
    """Confidence score (0-1)."""

    details: dict[str, object] | None = None
    """Additional details."""


# ---------------------------------------------------------------------------
# Classifier protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class Classifier(Protocol):
    """Classifier interface for data classification."""

    async def classify(self, content: str) -> ClassificationResult:
        """Classify the given text content."""
        ...

    async def classify_data(self, data: dict[str, object]) -> ClassificationResult:
        """Classify structured data."""
        ...


# ---------------------------------------------------------------------------
# Level priority
# ---------------------------------------------------------------------------

_LEVEL_PRIORITY: list[ClassificationLevel] = [
    "public",
    "internal",
    "confidential",
    "restricted",
]


# ---------------------------------------------------------------------------
# PatternClassifier
# ---------------------------------------------------------------------------


@dataclass
class _PatternEntry:
    """A pattern with its associated category."""

    pattern: re.Pattern[str]
    category: str


class PatternClassifier:
    """Simple pattern-based classifier.

    Uses regular expressions to detect sensitive data categories and
    assigns a classification level based on the highest-sensitivity match.
    """

    def __init__(self) -> None:
        self._patterns: dict[ClassificationLevel, list[_PatternEntry]] = {
            "restricted": [
                _PatternEntry(
                    pattern=re.compile(r"\bssn\b|\bsocial\s*security", re.IGNORECASE),
                    category="ssn",
                ),
                _PatternEntry(
                    pattern=re.compile(r"\bcredit\s*card\b|\bcc\s*number", re.IGNORECASE),
                    category="credit_card",
                ),
                _PatternEntry(
                    pattern=re.compile(r"\bpassword\b|\bpasswd\b", re.IGNORECASE),
                    category="credential",
                ),
            ],
            "confidential": [
                _PatternEntry(
                    pattern=re.compile(r"\bsalary\b|\bcompensation\b", re.IGNORECASE),
                    category="financial",
                ),
                _PatternEntry(
                    pattern=re.compile(r"\bmedical\b|\bhealth\s*record", re.IGNORECASE),
                    category="health",
                ),
                _PatternEntry(
                    pattern=re.compile(r"\bpii\b|\bpersonal\s*data", re.IGNORECASE),
                    category="pii",
                ),
            ],
            "internal": [
                _PatternEntry(
                    pattern=re.compile(r"\binternal\s*only\b", re.IGNORECASE),
                    category="internal",
                ),
                _PatternEntry(
                    pattern=re.compile(r"\bproprietary\b", re.IGNORECASE),
                    category="proprietary",
                ),
                _PatternEntry(
                    pattern=re.compile(r"\bconfidential\b", re.IGNORECASE),
                    category="marked_confidential",
                ),
            ],
        }

    async def classify(self, content: str) -> ClassificationResult:
        """Classify text content using pattern matching.

        Scans content against all patterns and returns the highest
        classification level found.
        """
        categories: list[str] = []
        highest_level: ClassificationLevel = "public"

        for level, entries in self._patterns.items():
            for entry in entries:
                if entry.pattern.search(content) is not None:
                    categories.append(entry.category)
                    if _LEVEL_PRIORITY.index(level) > _LEVEL_PRIORITY.index(highest_level):
                        highest_level = level

        return ClassificationResult(
            level=highest_level,
            categories=categories,
            confidence=0.8 if len(categories) > 0 else 0.5,
        )

    async def classify_data(self, data: dict[str, object]) -> ClassificationResult:
        """Classify structured data by converting to JSON string."""
        content = json.dumps(data)
        return await self.classify(content)


# ---------------------------------------------------------------------------
# NoOpClassifier
# ---------------------------------------------------------------------------


class NoOpClassifier:
    """No-op classifier that always returns public.

    Useful for development or when classification is not needed.
    """

    async def classify(self, content: str = "") -> ClassificationResult:
        """Always returns public classification."""
        return ClassificationResult(
            level="public",
            categories=[],
            confidence=1.0,
        )

    async def classify_data(self, data: dict[str, object] | None = None) -> ClassificationResult:
        """Always returns public classification."""
        return await self.classify()


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def create_pattern_classifier() -> PatternClassifier:
    """Create a pattern-based classifier.

    Returns:
        A ``PatternClassifier`` instance with built-in patterns for detecting
        SSNs, credit cards, credentials, financial data, health records,
        PII, internal markings, and proprietary content.
    """
    return PatternClassifier()


def create_no_op_classifier() -> NoOpClassifier:
    """Create a no-op classifier.

    Returns:
        A ``NoOpClassifier`` that always returns ``"public"`` classification.
    """
    return NoOpClassifier()
