"""Policy module for the Arelis AI SDK.

Provides policy engine, compilation, redaction, classification, risk routing,
and data retention enforcement. This module ports the TypeScript SDK's
``@ai-governance-sdk/governance`` package.
"""

from __future__ import annotations

# Classifier
from arelis.policy.classifier import (
    ClassificationLevel,
    ClassificationResult,
    Classifier,
    NoOpClassifier,
    PatternClassifier,
    create_no_op_classifier,
    create_pattern_classifier,
)

# Compiler
from arelis.policy.compiler import (
    POLICY_COMPILER_VERSION,
    PolicyCompiler,
    canonicalize_policy,
    compile_policy,
    create_json_policy_compiler,
    create_policy_engine_from_config,
    hash_canonical_policy,
    load_policy_config_file,
    load_policy_engine_from_file,
    parse_policy_config,
)

# Engine
from arelis.policy.engine import (
    JsonRulesEngine,
    PolicyEngine,
    PolicyModeResolver,
    create_allow_all_engine,
    create_deny_all_engine,
    create_policy_mode_engine,
)

# Redactor
from arelis.policy.redactor import (
    RedactionFinding,
    RedactionFindingType,
    RedactionPattern,
    RedactionResult,
    Redactor,
    RedactorConfig,
    create_redactor,
)

# Retention
from arelis.policy.retention import (
    ClassificationBasedRetentionResolver,
    EnvironmentAwareRetentionResolver,
    RetentionInput,
    RetentionPolicy,
    RetentionPolicyResolver,
    RetentionUnit,
    calculate_retention_end_date,
    create_environment_aware_retention_resolver,
    create_retention_resolver,
)

# Risk Router
from arelis.policy.risk_router import (
    RiskRouteAction,
    RiskRouteDecision,
    RiskRouterConfig,
    RiskRoutingMode,
    RiskThresholds,
    RuntimeRiskInput,
    compute_runtime_risk,
    resolve_risk_route,
)

# Types
from arelis.policy.types import (
    POLICY_CHECKPOINTS,
    CompiledPolicyConstraint,
    DisclosureDerivation,
    DisclosureRule,
    DisclosureRuleMatch,
    DisclosureRuleRedact,
    DisclosureRuleReveal,
    DisclosureRuleSet,
    JsonRule,
    JsonRuleAction,
    JsonRulesConfig,
    Patch,
    PatchOp,
    PolicyCheckpoint,
    PolicyCompilationInput,
    PolicyCompilationResult,
    PolicyConfigFile,
    PolicyConstraintAction,
    PolicyDecision,
    PolicyDecisionEffect,
    PolicyEnforcementMode,
    PolicyInput,
    PolicyInputCompiled,
    PolicyInputData,
    PolicyInputRisk,
    PolicyResult,
    PolicyResultSummary,
    PolicySnapshot,
    RuleCondition,
    RuleConditionOperator,
    # Decision factories
    aggregate_decisions,
    allow_decision,
    apply_patches,
    block_decision,
    drop_patch,
    normalize_patch,
    redact_patch,
    replace_patch,
    require_approval_decision,
    transform_decision,
)

__all__ = [
    # --- Types ---
    "POLICY_CHECKPOINTS",
    "PolicyCheckpoint",
    "PatchOp",
    "Patch",
    "replace_patch",
    "redact_patch",
    "drop_patch",
    "normalize_patch",
    "apply_patches",
    "PolicyDecisionEffect",
    "PolicyDecision",
    "allow_decision",
    "block_decision",
    "transform_decision",
    "require_approval_decision",
    "aggregate_decisions",
    "PolicyResultSummary",
    "PolicyResult",
    "PolicyEnforcementMode",
    "PolicyInputCompiled",
    "PolicyInputRisk",
    "PolicyInputData",
    "PolicyInput",
    "PolicyConstraintAction",
    "CompiledPolicyConstraint",
    "DisclosureRuleMatch",
    "DisclosureRuleReveal",
    "DisclosureRuleRedact",
    "DisclosureRule",
    "DisclosureRuleSet",
    "PolicySnapshot",
    "PolicyCompilationInput",
    "DisclosureDerivation",
    "PolicyCompilationResult",
    "RuleConditionOperator",
    "RuleCondition",
    "JsonRuleAction",
    "JsonRule",
    "JsonRulesConfig",
    "PolicyConfigFile",
    # --- Engine ---
    "PolicyEngine",
    "PolicyModeResolver",
    "JsonRulesEngine",
    "create_policy_mode_engine",
    "create_allow_all_engine",
    "create_deny_all_engine",
    # --- Compiler ---
    "POLICY_COMPILER_VERSION",
    "PolicyCompiler",
    "canonicalize_policy",
    "hash_canonical_policy",
    "compile_policy",
    "create_json_policy_compiler",
    "parse_policy_config",
    "load_policy_config_file",
    "create_policy_engine_from_config",
    "load_policy_engine_from_file",
    # --- Redactor ---
    "RedactionFindingType",
    "RedactionFinding",
    "RedactionResult",
    "RedactionPattern",
    "RedactorConfig",
    "Redactor",
    "create_redactor",
    # --- Classifier ---
    "ClassificationLevel",
    "ClassificationResult",
    "Classifier",
    "PatternClassifier",
    "NoOpClassifier",
    "create_pattern_classifier",
    "create_no_op_classifier",
    # --- Retention ---
    "RetentionUnit",
    "RetentionPolicy",
    "RetentionInput",
    "RetentionPolicyResolver",
    "ClassificationBasedRetentionResolver",
    "EnvironmentAwareRetentionResolver",
    "calculate_retention_end_date",
    "create_retention_resolver",
    "create_environment_aware_retention_resolver",
    # --- Risk Router ---
    "RiskRouteAction",
    "RiskRoutingMode",
    "RuntimeRiskInput",
    "RiskRouterConfig",
    "RiskThresholds",
    "RiskRouteDecision",
    "compute_runtime_risk",
    "resolve_risk_route",
]
