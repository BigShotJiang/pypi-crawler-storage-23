"""Policy types for the Arelis AI SDK.

Ports types from the TypeScript SDK's governance package:
- PolicyCheckpoint, Patch, PolicyDecision, PolicyResult
- PolicyEnforcementMode, PolicyInput, PolicySummary
- PolicyCompilation types (constraints, snapshots, disclosure rules)
- JsonRules types (conditions, rules, config)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

__all__ = [
    # Checkpoints
    "PolicyCheckpoint",
    "POLICY_CHECKPOINTS",
    # Patch
    "PatchOp",
    "Patch",
    "replace_patch",
    "redact_patch",
    "drop_patch",
    "normalize_patch",
    "apply_patches",
    # Decisions
    "PolicyDecisionEffect",
    "PolicyDecision",
    "allow_decision",
    "block_decision",
    "transform_decision",
    "require_approval_decision",
    "aggregate_decisions",
    # Result / Summary
    "PolicyResultSummary",
    "PolicyResult",
    # Enforcement
    "PolicyEnforcementMode",
    # Input
    "PolicyInputCompiled",
    "PolicyInputRisk",
    "PolicyInputData",
    "PolicyInput",
    # Compilation
    "PolicyConstraintAction",
    "CompiledPolicyConstraint",
    "DisclosureRuleMatch",
    "DisclosureRuleReveal",
    "DisclosureRuleRedact",
    "DisclosureRule",
    "DisclosureRuleSet",
    "PolicySnapshot",
    "PolicyCompilationInput",
    "DisclosureDerivation",
    "PolicyCompilationResult",
    # JSON Rules
    "RuleConditionOperator",
    "RuleCondition",
    "JsonRuleAction",
    "JsonRule",
    "JsonRulesConfig",
    # Policy config file
    "PolicyConfigFile",
]

# ---------------------------------------------------------------------------
# Policy checkpoints
# ---------------------------------------------------------------------------

PolicyCheckpoint = Literal[
    "BeforeOperation",
    "BeforePrompt",
    "AfterModelOutput",
    "BeforeToolCall",
    "AfterToolResult",
    "BeforePersist",
    "BeforeProvision",
    "BeforeDestroy",
    "BeforeConfigChange",
    "BeforeAuth",
    "BeforeAgentStep",
]
"""Policy checkpoint types. Extension checkpoints are additive and namespace-isolated."""

POLICY_CHECKPOINTS: tuple[str, ...] = (
    "BeforeOperation",
    "BeforePrompt",
    "AfterModelOutput",
    "BeforeToolCall",
    "AfterToolResult",
    "BeforePersist",
    "BeforeProvision",
    "BeforeDestroy",
    "BeforeConfigChange",
    "BeforeAuth",
    "BeforeAgentStep",
)
"""All valid policy checkpoint values as a tuple."""

# ---------------------------------------------------------------------------
# Patch operations
# ---------------------------------------------------------------------------

PatchOp = Literal["replace", "redact", "drop", "normalize"]
"""Patch operation type."""


@dataclass
class Patch:
    """Patch operation for transform decisions."""

    op: PatchOp
    """Operation type."""

    path: str
    """Path to the field to modify (JSON pointer format)."""

    value: object | None = None
    """New value for replace/normalize operations."""

    reason: str | None = None
    """Reason for the patch."""


def replace_patch(path: str, value: object, reason: str | None = None) -> Patch:
    """Create a replace patch."""
    return Patch(op="replace", path=path, value=value, reason=reason)


def redact_patch(path: str, reason: str | None = None) -> Patch:
    """Create a redact patch."""
    return Patch(op="redact", path=path, value="[REDACTED]", reason=reason)


def drop_patch(path: str, reason: str | None = None) -> Patch:
    """Create a drop patch."""
    return Patch(op="drop", path=path, reason=reason)


def normalize_patch(path: str, value: object, reason: str | None = None) -> Patch:
    """Create a normalize patch."""
    return Patch(op="normalize", path=path, value=value, reason=reason)


def apply_patches(data: dict[str, object], patches: list[Patch]) -> dict[str, object]:
    """Apply patches to data.

    Supports basic JSON pointer paths like ``/field`` or ``/nested/field``.
    Returns a deep copy of ``data`` with patches applied.
    """
    import json

    # Deep copy via JSON round-trip to match TS behavior (serializable data only)
    result: dict[str, object] = json.loads(json.dumps(data))

    for patch in patches:
        path_parts = [p for p in patch.path.split("/") if p != ""]

        if len(path_parts) == 0:
            continue

        # Navigate to parent
        current: dict[str, object] = result
        broken = False
        for i in range(len(path_parts) - 1):
            part = path_parts[i]
            child = current.get(part)
            if child is None or not isinstance(child, dict):
                broken = True
                break
            current = child

        if broken:
            continue

        last_key = path_parts[-1]

        if patch.op in ("replace", "normalize"):
            current[last_key] = patch.value
        elif patch.op == "redact":
            current[last_key] = patch.value if patch.value is not None else "[REDACTED]"
        elif patch.op == "drop":
            current.pop(last_key, None)

    return result


# ---------------------------------------------------------------------------
# Policy decisions
# ---------------------------------------------------------------------------

PolicyDecisionEffect = Literal["allow", "block", "transform", "require_approval"]
"""The effect of a policy decision."""


@dataclass
class PolicyDecision:
    """A single policy decision."""

    effect: PolicyDecisionEffect

    reason: str | None = None
    """Reason for block or require_approval decisions."""

    code: str | None = None
    """Optional code for block decisions."""

    patches: list[Patch] | None = None
    """Patches for transform decisions."""

    approvers: list[str] | None = None
    """Required approvers for require_approval decisions."""


def allow_decision() -> PolicyDecision:
    """Create an allow decision."""
    return PolicyDecision(effect="allow")


def block_decision(reason: str, code: str | None = None) -> PolicyDecision:
    """Create a block decision."""
    return PolicyDecision(effect="block", reason=reason, code=code)


def transform_decision(patches: list[Patch], reason: str | None = None) -> PolicyDecision:
    """Create a transform decision."""
    return PolicyDecision(effect="transform", patches=patches, reason=reason)


def require_approval_decision(approvers: list[str], reason: str) -> PolicyDecision:
    """Create a require_approval decision."""
    return PolicyDecision(effect="require_approval", approvers=approvers, reason=reason)


# ---------------------------------------------------------------------------
# Policy result / summary
# ---------------------------------------------------------------------------


@dataclass
class PolicyResultSummary:
    """Summary of a policy evaluation."""

    allowed: bool
    """Whether the request is allowed to proceed."""

    block_reason: str | None = None
    """Primary reason if blocked."""

    block_code: str | None = None
    """Block code if blocked."""

    approvers: list[str] | None = None
    """Approvers required if approval needed."""


@dataclass
class PolicyResult:
    """Result of a policy evaluation."""

    decisions: list[PolicyDecision]
    """All decisions made."""

    summary: PolicyResultSummary
    """Summary of the evaluation."""

    policy_version: str | None = None
    """Policy version or identifier."""


def aggregate_decisions(decisions: list[PolicyDecision]) -> PolicyResult:
    """Aggregate multiple decisions into a policy result.

    Block decisions take highest priority, followed by require_approval.
    """
    summary = PolicyResultSummary(allowed=True)

    # Check for blocks first (highest priority)
    for d in decisions:
        if d.effect == "block":
            summary.allowed = False
            summary.block_reason = d.reason
            summary.block_code = d.code
            return PolicyResult(decisions=decisions, summary=summary)

    # Check for approval required
    for d in decisions:
        if d.effect == "require_approval":
            summary.allowed = False
            summary.block_reason = d.reason
            summary.approvers = d.approvers
            return PolicyResult(decisions=decisions, summary=summary)

    return PolicyResult(decisions=decisions, summary=summary)


# ---------------------------------------------------------------------------
# Policy enforcement mode
# ---------------------------------------------------------------------------

PolicyEnforcementMode = Literal["enforce", "monitor", "off"]
"""Policy enforcement mode."""


# ---------------------------------------------------------------------------
# Policy input
# ---------------------------------------------------------------------------


@dataclass
class PolicyInputCompiled:
    """Compiled policy metadata attached to policy input."""

    compiler_id: str | None = None
    """Compiler identifier."""

    snapshot_hash: str | None = None
    """Policy snapshot hash."""

    constraints: object | None = None
    """Compiled constraints (engine-specific)."""

    disclosure_rules: object | None = None
    """Compiled disclosure rules (engine-specific)."""


@dataclass
class PolicyInputRisk:
    """Risk routing metadata in policy input data."""

    score: float | None = None
    factors: list[str] | None = None
    route: Literal["auto_execute", "sandbox", "require_approval", "block"] | None = None


@dataclass
class PolicyInputData:
    """Data to evaluate in policy input."""

    model_id: str | None = None
    """Model ID (for model-related checkpoints)."""

    provider: str | None = None
    """Provider name."""

    input: object | None = None
    """Input content."""

    output: object | None = None
    """Output content."""

    tool_name: str | None = None
    """Tool name (for tool-related checkpoints)."""

    tool_args: dict[str, object] | None = None
    """Tool arguments."""

    tool_result: object | None = None
    """Tool result."""

    operation: str | None = None
    """Operation name for lifecycle checkpoints."""

    agent_phase: Literal["plan", "execute", "observe"] | None = None
    """Agent phase for runtime step checkpointing."""

    step_number: int | None = None
    """Step number for agent phase checkpointing."""

    risk: PolicyInputRisk | None = None
    """Optional risk routing metadata."""


@dataclass
class PolicyInput:
    """Input to the policy engine."""

    checkpoint: PolicyCheckpoint
    """Checkpoint where the policy is being evaluated."""

    context: object  # GovernanceContext - use object to avoid circular import issues
    """Governance context."""

    run_id: str
    """Run ID."""

    data: PolicyInputData
    """Data to evaluate."""

    compiled: PolicyInputCompiled | None = None
    """Optional compiled policy metadata."""


# ---------------------------------------------------------------------------
# Policy compilation types
# ---------------------------------------------------------------------------

PolicyConstraintAction = Literal["allow", "block", "transform", "require_approval"]
"""Action for a compiled policy constraint."""


@dataclass
class CompiledPolicyConstraint:
    """A compiled policy constraint."""

    id: str
    checkpoints: list[PolicyCheckpoint]
    action: PolicyConstraintAction
    reason: str | None = None
    code: str | None = None
    priority: int | None = None
    conditions: object | None = None
    source: str | None = None


@dataclass
class DisclosureRuleMatch:
    """Match criteria for a disclosure rule."""

    event_types: list[str] | None = None
    node_kinds: list[Literal["run", "event"]] | None = None


@dataclass
class DisclosureRuleReveal:
    """Fields/attributes to reveal in a disclosure rule."""

    fields: list[str] | None = None
    attributes: list[str] | None = None


@dataclass
class DisclosureRuleRedact:
    """Fields to redact in a disclosure rule."""

    fields: list[str] | None = None


@dataclass
class DisclosureRule:
    """A disclosure rule controlling audit event visibility."""

    id: str
    match: DisclosureRuleMatch
    description: str | None = None
    reveal: DisclosureRuleReveal | None = None
    redact: DisclosureRuleRedact | None = None


@dataclass
class DisclosureRuleSet:
    """A set of disclosure rules."""

    rules: list[DisclosureRule]
    version: str | None = None


@dataclass
class PolicySnapshot:
    """Snapshot of a compiled policy for verification."""

    hash: str
    algorithm: Literal["sha256"]
    compiler_version: str
    created_at: str
    policy_version: str | None = None
    disclosure_rule_set_hash: str | None = None


@dataclass
class PolicyCompilationInput:
    """Input for policy compilation."""

    policy: object
    """Policy configuration (JsonRulesConfig or generic dict)."""

    disclosure: DisclosureRuleSet | None = None
    """Optional disclosure rule set."""

    engine_id: str | None = None
    """Engine identifier."""


@dataclass
class DisclosureDerivation:
    """Derivation metadata for disclosure rules."""

    strategy: Literal["explicit", "policy-derived"]
    version: Literal["1"]
    rule_set_id: str
    rule_set_hash: str
    source_constraint_ids: list[str]


@dataclass
class PolicyCompilationResult:
    """Result of policy compilation."""

    constraints: list[CompiledPolicyConstraint]
    disclosure_rules: list[DisclosureRule]
    snapshot: PolicySnapshot
    engine_id: str | None = None
    policy_version: str | None = None
    disclosure_derivation: DisclosureDerivation | None = None


# ---------------------------------------------------------------------------
# JSON Rules types
# ---------------------------------------------------------------------------

RuleConditionOperator = Literal[
    "equals", "notEquals", "contains", "notContains", "in", "notIn", "matches"
]
"""Operator for a rule condition."""


@dataclass
class RuleCondition:
    """A condition in a JSON rule."""

    field: str
    """Field path to check (dot notation)."""

    operator: RuleConditionOperator
    """Comparison operator."""

    value: object
    """Value to compare against."""


JsonRuleAction = Literal["block", "allow"]
"""Action to take when a JSON rule matches."""


@dataclass
class JsonRule:
    """A JSON rule definition."""

    id: str
    """Rule ID."""

    name: str
    """Rule name."""

    checkpoints: list[PolicyCheckpoint]
    """Checkpoints where this rule applies."""

    conditions: list[RuleCondition]
    """Conditions that must all be true for the rule to apply."""

    action: JsonRuleAction
    """Action to take when conditions match."""

    description: str | None = None
    """Description."""

    reason: str | None = None
    """Reason for the action (required for block)."""

    code: str | None = None
    """Code for the action (optional, for block)."""

    priority: int | None = None
    """Priority (higher = evaluated first)."""


@dataclass
class JsonRulesConfig:
    """Configuration for JSON rules adapter."""

    rules: list[JsonRule]
    """Rules to evaluate."""

    version: str | None = None
    """Optional policy version identifier."""

    default_action: JsonRuleAction | None = None
    """Default action when no rules match."""

    default_block_reason: str | None = None
    """Default block reason when default_action is 'block'."""


# ---------------------------------------------------------------------------
# Policy config file
# ---------------------------------------------------------------------------


@dataclass
class PolicyConfigFile:
    """Parsed policy configuration file."""

    policy: JsonRulesConfig
    """Policy rules configuration."""

    disclosure: DisclosureRuleSet | None = None
    """Optional disclosure rule set."""
