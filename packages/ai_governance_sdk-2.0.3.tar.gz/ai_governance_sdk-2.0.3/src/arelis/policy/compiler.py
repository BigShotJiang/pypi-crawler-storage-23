"""Policy compiler for the Arelis AI SDK.

Ports the policy compiler from the TypeScript SDK's governance package:
- Deterministic snapshot hashing via canonicalization
- Policy compilation from JsonRulesConfig to CompiledPolicyConstraint
- Disclosure rule derivation
- Policy config file loading
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import datetime, timezone
from typing import Protocol

from arelis.policy.types import (
    CompiledPolicyConstraint,
    DisclosureDerivation,
    DisclosureRule,
    DisclosureRuleMatch,
    DisclosureRuleRedact,
    DisclosureRuleReveal,
    DisclosureRuleSet,
    JsonRule,
    JsonRulesConfig,
    PolicyCheckpoint,
    PolicyCompilationInput,
    PolicyCompilationResult,
    PolicyConfigFile,
    PolicySnapshot,
    RuleCondition,
)

__all__ = [
    "POLICY_COMPILER_VERSION",
    "PolicyCompiler",
    "canonicalize_policy",
    "hash_canonical_policy",
    "compile_policy",
    "create_json_policy_compiler",
    "parse_policy_config",
    "load_policy_config_file",
    "create_policy_engine_from_config",
    "load_policy_engine_from_file",
]

POLICY_COMPILER_VERSION = "1.0"
"""Current version of the policy compiler."""


# ---------------------------------------------------------------------------
# PolicyCompiler protocol
# ---------------------------------------------------------------------------


class PolicyCompiler(Protocol):
    """Policy compiler interface."""

    @property
    def id(self) -> str:
        """Compiler identifier."""
        ...

    def compile(self, input: PolicyCompilationInput) -> PolicyCompilationResult:
        """Compile a policy into constraints and disclosure rules."""
        ...


# ---------------------------------------------------------------------------
# Canonicalization and hashing
# ---------------------------------------------------------------------------


def _normalize_value(value: object) -> object:
    """Recursively normalize a value for deterministic serialization.

    Sorts dictionary keys, converts sets to sorted lists, and handles
    special types for consistent hashing.
    """
    if isinstance(value, datetime):
        return value.isoformat()

    if isinstance(value, (list, tuple)):
        return [_normalize_value(entry) for entry in value]

    if isinstance(value, set):
        return sorted(
            [_normalize_value(entry) for entry in value],
            key=lambda x: str(x),
        )

    if isinstance(value, dict):
        sorted_keys = sorted(value.keys())
        result: dict[str, object] = {}
        for key in sorted_keys:
            result[key] = _normalize_value(value[key])
        return result

    return value


def canonicalize_policy(value: object) -> str:
    """Canonicalize a policy value for deterministic hashing.

    Normalizes the value (sorting keys, handling special types) and
    serializes to a deterministic JSON string.
    """
    normalized = _normalize_value(value)
    return json.dumps(normalized, separators=(",", ":"), sort_keys=False)


def hash_canonical_policy(canonical: str) -> str:
    """Hash a canonical policy string using SHA-256.

    Args:
        canonical: The canonicalized JSON string from ``canonicalize_policy()``.

    Returns:
        Hex-encoded SHA-256 hash.
    """
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Compilation helpers
# ---------------------------------------------------------------------------

_CHECKPOINT_TO_EVENT_TYPES: dict[str, list[str]] = {
    "BeforeOperation": ["orchestration.step"],
    "BeforePrompt": ["model.request"],
    "AfterModelOutput": ["model.response"],
    "BeforeToolCall": ["tool.call"],
    "AfterToolResult": ["tool.result"],
    "BeforePersist": ["memory.write", "memory.delete"],
    "BeforeProvision": ["infra.provision.started", "infra.provision.completed"],
    "BeforeDestroy": ["infra.destroy.started", "infra.destroy.completed"],
    "BeforeConfigChange": ["config.change.started", "config.change.completed"],
    "BeforeAuth": ["auth.started", "auth.succeeded"],
    "BeforeAgentStep": ["agent.step", "agent.attestation.created"],
}


def _is_json_rules_config(value: object) -> bool:
    """Check if a value looks like a JsonRulesConfig."""
    if isinstance(value, JsonRulesConfig):
        return True
    if isinstance(value, dict):
        return isinstance(value.get("rules"), list)
    return False


def _config_to_dict(config: object) -> dict[str, object]:
    """Convert a JsonRulesConfig or dict to a plain dict for serialization."""
    if isinstance(config, JsonRulesConfig):
        result: dict[str, object] = {
            "rules": [_json_rule_to_dict(r) for r in config.rules],
        }
        if config.version is not None:
            result["version"] = config.version
        if config.default_action is not None:
            result["defaultAction"] = config.default_action
        if config.default_block_reason is not None:
            result["defaultBlockReason"] = config.default_block_reason
        return result
    if isinstance(config, dict):
        return config
    return {}


def _json_rule_to_dict(rule: JsonRule) -> dict[str, object]:
    """Convert a JsonRule to a plain dict."""
    d: dict[str, object] = {
        "id": rule.id,
        "name": rule.name,
        "checkpoints": list(rule.checkpoints),
        "conditions": [
            {"field": c.field, "operator": c.operator, "value": c.value} for c in rule.conditions
        ],
        "action": rule.action,
    }
    if rule.description is not None:
        d["description"] = rule.description
    if rule.reason is not None:
        d["reason"] = rule.reason
    if rule.code is not None:
        d["code"] = rule.code
    if rule.priority is not None:
        d["priority"] = rule.priority
    return d


def _get_rules_from_config(config: object) -> list[JsonRule]:
    """Extract rules from a JsonRulesConfig or dict."""
    if isinstance(config, JsonRulesConfig):
        return config.rules
    if isinstance(config, dict):
        raw_rules = config.get("rules", [])
        if isinstance(raw_rules, list):
            return [_parse_json_rule(r) for r in raw_rules if isinstance(r, dict)]
    return []


def _get_version_from_config(config: object) -> str | None:
    """Extract version from a JsonRulesConfig or dict."""
    if isinstance(config, JsonRulesConfig):
        return config.version
    if isinstance(config, dict):
        v = config.get("version")
        return str(v) if v is not None else None
    return None


def _compile_json_rules(rules: list[JsonRule]) -> list[CompiledPolicyConstraint]:
    """Compile JSON rules into policy constraints."""
    return [
        CompiledPolicyConstraint(
            id=rule.id,
            checkpoints=list(rule.checkpoints),
            action=rule.action,
            reason=rule.reason,
            code=rule.code,
            priority=rule.priority,
            conditions=[
                {"field": c.field, "operator": c.operator, "value": c.value}
                for c in rule.conditions
            ],
            source="json-rules",
        )
        for rule in rules
    ]


def _derive_disclosure_rules(
    constraints: list[CompiledPolicyConstraint],
) -> list[DisclosureRule]:
    """Derive disclosure rules from compiled constraints."""
    result: list[DisclosureRule] = []
    for constraint in constraints:
        event_types: list[str] = []
        seen: set[str] = set()
        for checkpoint in constraint.checkpoints:
            for et in _CHECKPOINT_TO_EVENT_TYPES.get(checkpoint, []):
                if et not in seen:
                    event_types.append(et)
                    seen.add(et)

        result.append(
            DisclosureRule(
                id=f"derived.{constraint.id}",
                description=f"Derived from policy constraint {constraint.id}",
                match=DisclosureRuleMatch(
                    event_types=event_types,
                    node_kinds=["event"],
                ),
                reveal=DisclosureRuleReveal(
                    fields=[
                        "type",
                        "time",
                        "runId",
                        "context.org.id",
                        "context.actor.type",
                    ],
                    attributes=["risk", "checkpoint"],
                ),
                redact=DisclosureRuleRedact(
                    fields=["context.actor.email", "context.actor.roles"],
                ),
            )
        )

    return result


def _disclosure_rule_to_dict(rule: DisclosureRule) -> dict[str, object]:
    """Convert a DisclosureRule to a plain dict for serialization."""
    d: dict[str, object] = {
        "id": rule.id,
        "match": {
            "eventTypes": rule.match.event_types,
            "nodeKinds": rule.match.node_kinds,
        },
    }
    if rule.description is not None:
        d["description"] = rule.description
    if rule.reveal is not None:
        d["reveal"] = {
            "fields": rule.reveal.fields,
            "attributes": rule.reveal.attributes,
        }
    if rule.redact is not None:
        d["redact"] = {"fields": rule.redact.fields}
    return d


def _disclosure_ruleset_to_dict(
    ruleset: DisclosureRuleSet | None,
) -> dict[str, object] | None:
    """Convert a DisclosureRuleSet to a plain dict for serialization."""
    if ruleset is None:
        return None
    d: dict[str, object] = {
        "rules": [_disclosure_rule_to_dict(r) for r in ruleset.rules],
    }
    if ruleset.version is not None:
        d["version"] = ruleset.version
    return d


# ---------------------------------------------------------------------------
# compile_policy
# ---------------------------------------------------------------------------


def compile_policy(input: PolicyCompilationInput) -> PolicyCompilationResult:
    """Compile a policy into constraints, disclosure rules, and a snapshot.

    If the input policy is a ``JsonRulesConfig`` (or dict with ``rules``),
    compiles the rules into ``CompiledPolicyConstraint`` objects. If no
    explicit disclosure rules are provided, they are derived from the
    compiled constraints.

    Returns a ``PolicyCompilationResult`` with a deterministic snapshot hash.
    """
    disclosure_rules: list[DisclosureRule] = []
    if input.disclosure is not None:
        disclosure_rules = list(input.disclosure.rules)

    constraints: list[CompiledPolicyConstraint] = []
    policy_version: str | None = None

    if _is_json_rules_config(input.policy):
        rules = _get_rules_from_config(input.policy)
        constraints = _compile_json_rules(rules)
        policy_version = _get_version_from_config(input.policy)

    # Derive or record disclosure derivation
    disclosure_derivation: DisclosureDerivation

    if input.disclosure is None or len(input.disclosure.rules) == 0:
        disclosure_rules = _derive_disclosure_rules(constraints)
        derivation_payload = {
            "strategy": "policy-derived",
            "constraintIds": sorted(c.id for c in constraints),
            "disclosureRuleIds": sorted(r.id for r in disclosure_rules),
        }
        derivation_hash = hash_canonical_policy(canonicalize_policy(derivation_payload))
        disclosure_derivation = DisclosureDerivation(
            strategy="policy-derived",
            version="1",
            rule_set_id=f"derived-ruleset-{derivation_hash[:12]}",
            rule_set_hash=derivation_hash,
            source_constraint_ids=[c.id for c in constraints],
        )
    else:
        explicit_payload = {
            "strategy": "explicit",
            "disclosureRuleIds": sorted(r.id for r in disclosure_rules),
        }
        explicit_hash = hash_canonical_policy(canonicalize_policy(explicit_payload))
        disclosure_derivation = DisclosureDerivation(
            strategy="explicit",
            version="1",
            rule_set_id=f"explicit-ruleset-{explicit_hash[:12]}",
            rule_set_hash=explicit_hash,
            source_constraint_ids=[c.id for c in constraints],
        )

    # Build canonical representation for snapshot hash
    policy_dict = (
        _config_to_dict(input.policy) if _is_json_rules_config(input.policy) else input.policy
    )
    canonical = canonicalize_policy(
        {
            "engineId": input.engine_id,
            "policy": policy_dict,
            "disclosure": _disclosure_ruleset_to_dict(input.disclosure),
        }
    )

    snapshot = PolicySnapshot(
        hash=hash_canonical_policy(canonical),
        algorithm="sha256",
        compiler_version=POLICY_COMPILER_VERSION,
        created_at=datetime.now(timezone.utc).isoformat(),
        policy_version=policy_version,
        disclosure_rule_set_hash=disclosure_derivation.rule_set_hash,
    )

    return PolicyCompilationResult(
        engine_id=input.engine_id,
        policy_version=policy_version,
        constraints=constraints,
        disclosure_rules=disclosure_rules,
        disclosure_derivation=disclosure_derivation,
        snapshot=snapshot,
    )


# ---------------------------------------------------------------------------
# JSON Policy Compiler
# ---------------------------------------------------------------------------


class _JsonPolicyCompiler:
    """Concrete JSON policy compiler."""

    def __init__(self, compiler_id: str) -> None:
        self._id = compiler_id

    @property
    def id(self) -> str:
        return self._id

    def compile(self, input: PolicyCompilationInput) -> PolicyCompilationResult:
        engine_id = input.engine_id if input.engine_id is not None else self._id
        return compile_policy(
            PolicyCompilationInput(
                policy=input.policy,
                disclosure=input.disclosure,
                engine_id=engine_id,
            )
        )


def create_json_policy_compiler(
    compiler_id: str = "json-rules",
) -> _JsonPolicyCompiler:
    """Create a JSON policy compiler.

    Args:
        compiler_id: Identifier for the compiler instance.

    Returns:
        A ``PolicyCompiler`` implementation for JSON rules.
    """
    return _JsonPolicyCompiler(compiler_id)


# ---------------------------------------------------------------------------
# Policy config file loading
# ---------------------------------------------------------------------------

_SUPPORTED_EXTENSIONS = frozenset({".json", ".jsonc"})


def _strip_json_comments(text: str) -> str:
    """Strip C-style comments from JSONC content."""
    # Remove block comments
    text = re.sub(r"/\*[\s\S]*?\*/", "", text)
    # Remove line comments (not inside strings - simplified approach)
    text = re.sub(r"(^|[^:])//.*$", r"\1", text, flags=re.MULTILINE)
    return text


def _parse_json_content(contents: str, extension: str) -> object:
    """Parse JSON or JSONC content."""
    try:
        return json.loads(contents)
    except json.JSONDecodeError:
        if extension == ".jsonc":
            return json.loads(_strip_json_comments(contents))
        raise


def _parse_json_rule(raw: dict[str, object]) -> JsonRule:
    """Parse a raw dict into a JsonRule."""
    conditions: list[RuleCondition] = []
    raw_conditions = raw.get("conditions", [])
    if isinstance(raw_conditions, list):
        for c in raw_conditions:
            if isinstance(c, dict):
                conditions.append(
                    RuleCondition(
                        field=str(c.get("field", "")),
                        operator=c.get("operator", "equals"),
                        value=c.get("value"),
                    )
                )

    raw_checkpoints = raw.get("checkpoints", [])
    checkpoints: list[PolicyCheckpoint] = []
    if isinstance(raw_checkpoints, list):
        checkpoints = raw_checkpoints

    return JsonRule(
        id=str(raw.get("id", "")),
        name=str(raw.get("name", "")),
        checkpoints=checkpoints,
        conditions=conditions,
        action=raw.get("action", "allow"),  # type: ignore[arg-type]
        description=raw.get("description"),  # type: ignore[arg-type]
        reason=raw.get("reason"),  # type: ignore[arg-type]
        code=raw.get("code"),  # type: ignore[arg-type]
        priority=raw.get("priority"),  # type: ignore[arg-type]
    )


def _parse_json_rules_config(raw: dict[str, object]) -> JsonRulesConfig:
    """Parse a raw dict into a JsonRulesConfig."""
    raw_rules = raw.get("rules", [])
    rules: list[JsonRule] = []
    if isinstance(raw_rules, list):
        rules = [_parse_json_rule(r) for r in raw_rules if isinstance(r, dict)]

    return JsonRulesConfig(
        rules=rules,
        version=raw.get("version"),  # type: ignore[arg-type]
        default_action=raw.get("defaultAction"),  # type: ignore[arg-type]
        default_block_reason=raw.get("defaultBlockReason"),  # type: ignore[arg-type]
    )


def _parse_disclosure_ruleset(raw: dict[str, object]) -> DisclosureRuleSet:
    """Parse a raw dict into a DisclosureRuleSet."""
    raw_rules = raw.get("rules", [])
    rules: list[DisclosureRule] = []
    if isinstance(raw_rules, list):
        for r in raw_rules:
            if isinstance(r, dict):
                match_raw = r.get("match", {})
                match = DisclosureRuleMatch(
                    event_types=match_raw.get("eventTypes")
                    if isinstance(match_raw, dict)
                    else None,
                    node_kinds=match_raw.get("nodeKinds") if isinstance(match_raw, dict) else None,
                )
                reveal_raw = r.get("reveal")
                reveal = None
                if isinstance(reveal_raw, dict):
                    reveal = DisclosureRuleReveal(
                        fields=reveal_raw.get("fields"),
                        attributes=reveal_raw.get("attributes"),
                    )
                redact_raw = r.get("redact")
                redact = None
                if isinstance(redact_raw, dict):
                    redact = DisclosureRuleRedact(
                        fields=redact_raw.get("fields"),
                    )
                rules.append(
                    DisclosureRule(
                        id=str(r.get("id", "")),
                        match=match,
                        description=r.get("description"),
                        reveal=reveal,
                        redact=redact,
                    )
                )

    return DisclosureRuleSet(
        rules=rules,
        version=raw.get("version"),  # type: ignore[arg-type]
    )


def parse_policy_config(value: object) -> PolicyConfigFile:
    """Parse a raw value (dict) into a PolicyConfigFile.

    The value can be either:
    - ``{"policy": {...}, "disclosure": {...}}`` (wrapper format)
    - ``{"rules": [...]}`` (direct policy format)

    Raises:
        ValueError: If the config is invalid.
    """
    if not isinstance(value, dict):
        raise ValueError("Policy config must be a JSON object")

    # The policy may be nested under "policy" key or be the value itself
    policy_value = value.get("policy", value)

    if not isinstance(policy_value, dict):
        raise ValueError("Policy config must include a policy object")

    if not isinstance(policy_value.get("rules"), list):
        raise ValueError('Policy config must include a "rules" array')

    policy = _parse_json_rules_config(policy_value)

    disclosure: DisclosureRuleSet | None = None
    disclosure_raw = value.get("disclosure")
    if disclosure_raw is not None:
        if not isinstance(disclosure_raw, dict):
            raise ValueError("Disclosure config must be an object")
        if not isinstance(disclosure_raw.get("rules"), list):
            raise ValueError('Disclosure config must include a "rules" array')
        disclosure = _parse_disclosure_ruleset(disclosure_raw)

    return PolicyConfigFile(policy=policy, disclosure=disclosure)


async def load_policy_config_file(file_path: str) -> PolicyConfigFile:
    """Load and parse a policy configuration file.

    Supports ``.json`` and ``.jsonc`` extensions.

    Args:
        file_path: Path to the policy configuration file.

    Returns:
        Parsed ``PolicyConfigFile``.

    Raises:
        ValueError: If the file extension is unsupported or content is invalid.
        FileNotFoundError: If the file does not exist.
    """
    _, extension = os.path.splitext(file_path)
    extension = extension.lower()

    if extension not in _SUPPORTED_EXTENSIONS:
        supported = ", ".join(sorted(_SUPPORTED_EXTENSIONS))
        raise ValueError(
            f'Unsupported policy config extension "{extension}". Supported: {supported}'
        )

    import aiofiles  # type: ignore[import-untyped]

    async with aiofiles.open(file_path, encoding="utf-8") as f:
        contents = await f.read()

    parsed = _parse_json_content(contents, extension)
    return parse_policy_config(parsed)


def create_policy_engine_from_config(config: PolicyConfigFile) -> object:
    """Create a JsonRulesEngine from a parsed policy config.

    Args:
        config: Parsed policy configuration.

    Returns:
        A ``JsonRulesEngine`` instance.
    """
    from arelis.policy.engine import JsonRulesEngine

    return JsonRulesEngine(config.policy)


async def load_policy_engine_from_file(
    file_path: str,
) -> dict[str, object]:
    """Load a policy engine from a configuration file.

    Args:
        file_path: Path to the policy configuration file.

    Returns:
        A dict with ``engine`` (JsonRulesEngine) and ``config`` (PolicyConfigFile).
    """
    config = await load_policy_config_file(file_path)
    engine = create_policy_engine_from_config(config)
    return {"engine": engine, "config": config}
