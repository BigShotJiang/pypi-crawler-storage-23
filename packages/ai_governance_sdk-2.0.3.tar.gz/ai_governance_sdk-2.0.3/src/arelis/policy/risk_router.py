"""Risk router for the Arelis AI SDK.

Ports the risk router from the TypeScript SDK's governance package.
Provides risk-adaptive routing decisions based on policy decisions,
quota effects, evaluation effects, and explicit signals.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Literal

from arelis.policy.types import PolicyDecision

__all__ = [
    "RiskRouteAction",
    "RiskRoutingMode",
    "RuntimeRiskInput",
    "RiskRouterConfig",
    "RiskRouteDecision",
    "RiskThresholds",
    "compute_runtime_risk",
    "resolve_risk_route",
]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

RiskRouteAction = Literal["auto_execute", "sandbox", "require_approval", "block"]
"""Action to take based on risk assessment."""

RiskRoutingMode = Literal["off", "enabled"]
"""Risk routing mode."""


@dataclass
class RuntimeRiskInput:
    """Input for runtime risk computation."""

    operation: str
    """Operation being performed."""

    context: object  # GovernanceContext
    """Governance context."""

    policy_decisions: list[PolicyDecision]
    """Policy decisions for the current operation."""

    quota_effect: Literal["allow", "limit", "block"] | None = None
    """Quota effect."""

    evaluation_effect: Literal["pass", "warn", "block"] | None = None
    """Evaluation effect."""

    explicit_signals: list[str] | None = None
    """Explicit risk signals."""


@dataclass
class RiskThresholds:
    """Thresholds for risk-based routing."""

    sandbox: float = 0.35
    require_approval: float = 0.65
    block: float = 0.9


@dataclass
class RiskRouterConfig:
    """Configuration for the risk router."""

    mode: RiskRoutingMode = "off"
    """Routing mode."""

    default_action: RiskRouteAction = "auto_execute"
    """Default action when mode is 'off'."""

    thresholds: RiskThresholds | None = None
    """Risk score thresholds."""


@dataclass
class RiskRouteDecision:
    """Result of a risk routing decision."""

    action: RiskRouteAction
    """Action to take."""

    score: float
    """Computed risk score (0-1)."""

    factors: list[str]
    """Risk factors that contributed to the score."""

    deterministic_inputs_hash: str
    """SHA-256 hash of the deterministic inputs for reproducibility."""


@dataclass
class _RiskSignal:
    """Internal risk computation result."""

    score: float
    factors: list[str]
    deterministic_inputs_hash: str


# ---------------------------------------------------------------------------
# Default thresholds
# ---------------------------------------------------------------------------

_DEFAULT_THRESHOLDS = RiskThresholds(
    sandbox=0.35,
    require_approval=0.65,
    block=0.9,
)


# ---------------------------------------------------------------------------
# Risk computation
# ---------------------------------------------------------------------------


def _hash_deterministic_payload(payload: object) -> str:
    """Hash a payload for deterministic reproducibility."""
    return hashlib.sha256(
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    ).hexdigest()


def compute_runtime_risk(input: RuntimeRiskInput) -> _RiskSignal:
    """Compute runtime risk score from policy decisions and signals.

    The risk score starts at 0.1 and is raised based on:
    - Policy decisions (transform=0.45, require_approval=0.75, block=0.95)
    - Quota effects (limit=0.55, block=0.95)
    - Evaluation effects (warn=0.6, block=0.95)
    - Explicit signals (critical*=0.95)

    Returns a ``_RiskSignal`` with score, factors, and a deterministic hash.
    """
    factors: list[str] = []
    score = 0.1

    for decision in input.policy_decisions:
        if decision.effect == "allow":
            score = max(score, 0.1)
            continue
        if decision.effect == "transform":
            score = max(score, 0.45)
            reason = decision.reason or "transform"
            factors.append(f"policy.transform:{reason}")
            continue
        if decision.effect == "require_approval":
            score = max(score, 0.75)
            factors.append(f"policy.require_approval:{decision.reason}")
            continue
        # block
        score = max(score, 0.95)
        factors.append(f"policy.block:{decision.reason}")

    if input.quota_effect == "limit":
        score = max(score, 0.55)
        factors.append("quota.limit")
    if input.quota_effect == "block":
        score = max(score, 0.95)
        factors.append("quota.block")

    if input.evaluation_effect == "warn":
        score = max(score, 0.6)
        factors.append("evaluation.warn")
    if input.evaluation_effect == "block":
        score = max(score, 0.95)
        factors.append("evaluation.block")

    if input.explicit_signals is not None:
        for signal in input.explicit_signals:
            factors.append(f"signal:{signal}")
            if signal.startswith("critical"):
                score = max(score, 0.95)

    # Build deterministic hash from context
    ctx = input.context
    ctx_dict: dict[str, object] = {}
    if hasattr(ctx, "org") and hasattr(ctx.org, "id"):
        ctx_dict["orgId"] = ctx.org.id
    if hasattr(ctx, "actor") and hasattr(ctx.actor, "type"):
        ctx_dict["actorType"] = ctx.actor.type
    if hasattr(ctx, "purpose"):
        ctx_dict["purpose"] = ctx.purpose
    if hasattr(ctx, "environment"):
        ctx_dict["environment"] = ctx.environment

    deterministic_inputs_hash = _hash_deterministic_payload(
        {
            "operation": input.operation,
            "context": ctx_dict,
            "quotaEffect": input.quota_effect,
            "evaluationEffect": input.evaluation_effect,
            "factors": factors,
            "score": score,
        }
    )

    return _RiskSignal(
        score=score,
        factors=factors,
        deterministic_inputs_hash=deterministic_inputs_hash,
    )


def resolve_risk_route(
    input: RuntimeRiskInput,
    config: RiskRouterConfig | None = None,
) -> RiskRouteDecision:
    """Resolve a risk-based routing decision.

    When mode is ``"off"``, returns the default action with the computed
    risk score. When mode is ``"enabled"``, uses thresholds to determine
    the action based on the risk score.

    Args:
        input: Runtime risk input with policy decisions and signals.
        config: Optional router configuration. Defaults to mode ``"off"``.

    Returns:
        A ``RiskRouteDecision`` with the action, score, factors, and hash.
    """
    if config is None:
        config = RiskRouterConfig()

    mode = config.mode

    if mode == "off":
        signal = compute_runtime_risk(input)
        return RiskRouteDecision(
            action=config.default_action,
            score=signal.score,
            factors=signal.factors,
            deterministic_inputs_hash=signal.deterministic_inputs_hash,
        )

    thresholds = config.thresholds or _DEFAULT_THRESHOLDS

    signal = compute_runtime_risk(input)
    action: RiskRouteAction = "auto_execute"

    if signal.score >= thresholds.block:
        action = "block"
    elif signal.score >= thresholds.require_approval:
        action = "require_approval"
    elif signal.score >= thresholds.sandbox:
        action = "sandbox"

    return RiskRouteDecision(
        action=action,
        score=signal.score,
        factors=signal.factors,
        deterministic_inputs_hash=signal.deterministic_inputs_hash,
    )
