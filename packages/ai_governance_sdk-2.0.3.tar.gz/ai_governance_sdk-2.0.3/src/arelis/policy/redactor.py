"""Redactor for detecting and redacting sensitive data.

Ports the Redactor from the TypeScript SDK's governance package.
Supports detection of emails, phone numbers, API keys, and custom patterns.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

__all__ = [
    "RedactionFindingType",
    "RedactionFinding",
    "RedactionResult",
    "RedactionPattern",
    "RedactorConfig",
    "Redactor",
    "create_redactor",
]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

RedactionFindingType = Literal["email", "phone", "api_key", "custom"]
"""Type of sensitive data found."""


@dataclass
class RedactionFinding:
    """A finding of sensitive data in text."""

    type: RedactionFindingType
    """Type of sensitive data found."""

    original: str
    """Original value that was found."""

    start: int
    """Start index in the text."""

    end: int
    """End index in the text."""

    pattern: str | None = None
    """Pattern name that matched."""


@dataclass
class RedactionResult:
    """Result of a redaction operation."""

    text: str
    """Redacted text."""

    redacted: bool
    """Whether any redaction was performed."""

    findings: list[RedactionFinding]
    """Findings of sensitive data."""


@dataclass
class RedactionPattern:
    """Custom pattern definition for redaction."""

    name: str
    """Pattern name."""

    pattern: re.Pattern[str]
    """Compiled regular expression pattern."""

    type: RedactionFindingType
    """Type of sensitive data."""

    replacement: str | None = None
    """Replacement text (default: [REDACTED])."""


@dataclass
class RedactorConfig:
    """Configuration for the Redactor."""

    detect_emails: bool = True
    """Enable email detection."""

    detect_phones: bool = True
    """Enable phone number detection."""

    detect_api_keys: bool = True
    """Enable API key detection."""

    secret_patterns: list[RedactionPattern] | None = None
    """Secret patterns to detect."""

    custom_patterns: list[RedactionPattern] | None = None
    """Custom patterns to detect."""

    default_replacement: str = "[REDACTED]"
    """Default replacement text."""


# ---------------------------------------------------------------------------
# Built-in patterns
# ---------------------------------------------------------------------------

_EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")

_PHONE_PATTERN = re.compile(r"(?:\+?1[-.\s]?)?(?:\(?[0-9]{3}\)?[-.\s]?)?[0-9]{3}[-.\s]?[0-9]{4}")

_API_KEY_PATTERNS: list[re.Pattern[str]] = [
    # Generic API key patterns
    re.compile(
        r"(?:api[_-]?key|apikey|api_secret|api-secret)[=:\s]+['\"]?"
        r"([a-zA-Z0-9_-]{20,})['\"]?",
        re.IGNORECASE,
    ),
    # Bearer tokens
    re.compile(r"Bearer\s+[a-zA-Z0-9_-]{20,}", re.IGNORECASE),
    # AWS-style keys
    re.compile(r"(?:AKIA|ASIA)[A-Z0-9]{16}"),
    # Generic secrets
    re.compile(
        r"(?:secret|password|passwd|pwd)[=:\s]+['\"]?([^\s'\"]{8,})['\"]?",
        re.IGNORECASE,
    ),
]


# ---------------------------------------------------------------------------
# Redactor
# ---------------------------------------------------------------------------


class Redactor:
    """Redactor for detecting and redacting sensitive data.

    Detects emails, phone numbers, API keys, and custom patterns in text,
    replacing them with configurable replacement strings.
    """

    def __init__(self, config: RedactorConfig | None = None) -> None:
        if config is None:
            config = RedactorConfig()

        self._detect_emails = config.detect_emails
        self._detect_phones = config.detect_phones
        self._detect_api_keys = config.detect_api_keys
        self._default_replacement = config.default_replacement

        # Merge secret_patterns and custom_patterns (matching TS behavior)
        secret = config.secret_patterns or []
        custom = config.custom_patterns or []
        self._custom_patterns: list[RedactionPattern] = secret + custom

    def redact(self, text: str) -> RedactionResult:
        """Redact sensitive data from text.

        Args:
            text: The text to scan and redact.

        Returns:
            A ``RedactionResult`` with redacted text, findings, and a flag
            indicating whether any redaction was performed.
        """
        findings: list[RedactionFinding] = []

        # Detect emails
        if self._detect_emails:
            findings.extend(self._find_matches(text, _EMAIL_PATTERN, "email"))

        # Detect phone numbers
        if self._detect_phones:
            findings.extend(self._find_matches(text, _PHONE_PATTERN, "phone"))

        # Detect API keys
        if self._detect_api_keys:
            for pattern in _API_KEY_PATTERNS:
                findings.extend(self._find_matches(text, pattern, "api_key"))

        # Custom patterns
        for custom_pattern in self._custom_patterns:
            findings.extend(
                self._find_matches(
                    text,
                    custom_pattern.pattern,
                    custom_pattern.type,
                    custom_pattern.name,
                )
            )

        # Sort findings by start position descending for replacement from end
        sorted_findings = sorted(findings, key=lambda f: f.start, reverse=True)

        # Remove duplicates (overlapping findings)
        unique_findings = self._remove_duplicates(sorted_findings)

        # Apply redactions (findings are in reverse order)
        redacted_text = text
        for finding in unique_findings:
            # Find custom replacement if available
            replacement = self._default_replacement
            for cp in self._custom_patterns:
                if cp.name == finding.pattern and cp.replacement is not None:
                    replacement = cp.replacement
                    break
            redacted_text = (
                redacted_text[: finding.start] + replacement + redacted_text[finding.end :]
            )

        # Return findings sorted by start position ascending
        return RedactionResult(
            text=redacted_text,
            redacted=len(unique_findings) > 0,
            findings=sorted(unique_findings, key=lambda f: f.start),
        )

    def contains_sensitive_data(self, text: str) -> bool:
        """Check if text contains sensitive data without redacting.

        Args:
            text: The text to scan.

        Returns:
            True if sensitive data was detected.
        """
        if self._detect_emails and _EMAIL_PATTERN.search(text) is not None:
            return True

        if self._detect_phones and _PHONE_PATTERN.search(text) is not None:
            return True

        if self._detect_api_keys:
            for pattern in _API_KEY_PATTERNS:
                if pattern.search(text) is not None:
                    return True

        for custom_pattern in self._custom_patterns:
            if custom_pattern.pattern.search(text) is not None:
                return True

        return False

    def _find_matches(
        self,
        text: str,
        pattern: re.Pattern[str],
        finding_type: RedactionFindingType,
        pattern_name: str | None = None,
    ) -> list[RedactionFinding]:
        """Find all matches of a pattern in text."""
        findings: list[RedactionFinding] = []

        for match in pattern.finditer(text):
            findings.append(
                RedactionFinding(
                    type=finding_type,
                    original=match.group(0),
                    start=match.start(),
                    end=match.end(),
                    pattern=pattern_name,
                )
            )

        return findings

    def _remove_duplicates(self, findings: list[RedactionFinding]) -> list[RedactionFinding]:
        """Remove overlapping findings.

        Expects findings sorted by start position descending.
        Keeps non-overlapping findings, preferring earlier (higher start) ones
        when they don't overlap with already-kept findings.
        """
        result: list[RedactionFinding] = []
        last_end = float("inf")

        for finding in findings:
            # Skip if this finding overlaps with the previous one
            if finding.end <= last_end:
                result.append(finding)
                last_end = finding.start

        return result


def create_redactor(config: RedactorConfig | None = None) -> Redactor:
    """Create a default redactor instance.

    Args:
        config: Optional redactor configuration. If None, uses defaults
                (all built-in detections enabled).

    Returns:
        A configured ``Redactor`` instance.
    """
    return Redactor(config)
