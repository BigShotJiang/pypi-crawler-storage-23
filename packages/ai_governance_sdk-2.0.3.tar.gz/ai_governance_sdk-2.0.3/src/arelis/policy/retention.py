"""Data retention enforcement for the Arelis AI SDK.

Ports the retention module from the TypeScript SDK's governance package.
Provides retention policy resolution based on data classification and
deployment environment.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Literal, Protocol, runtime_checkable

from arelis.policy.classifier import ClassificationLevel

__all__ = [
    "RetentionUnit",
    "RetentionPolicy",
    "RetentionInput",
    "RetentionPolicyResolver",
    "ClassificationBasedRetentionResolver",
    "EnvironmentAwareRetentionResolver",
    "calculate_retention_end_date",
    "create_retention_resolver",
    "create_environment_aware_retention_resolver",
]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

RetentionUnit = Literal["days", "months", "years"]
"""Retention period unit."""


@dataclass
class RetentionPolicy:
    """Data retention policy."""

    period: int
    """Retention period value."""

    unit: RetentionUnit
    """Retention period unit."""

    delete_after: bool
    """Whether to delete after retention period."""

    archive_before_delete: bool = False
    """Archive before deletion."""

    metadata: dict[str, object] | None = None
    """Custom metadata."""


@dataclass
class RetentionInput:
    """Input for retention policy resolution."""

    context: object  # GovernanceContext
    """Governance context."""

    data_type: str
    """Data type (e.g., 'audit_event', 'model_request', 'tool_call')."""

    classification: ClassificationLevel | None = None
    """Data classification level."""

    metadata: dict[str, object] | None = None
    """Additional metadata."""


# ---------------------------------------------------------------------------
# RetentionPolicyResolver protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class RetentionPolicyResolver(Protocol):
    """Interface for resolving retention policies."""

    async def resolve(self, input: RetentionInput) -> RetentionPolicy:
        """Resolve the retention policy for the given input."""
        ...


# ---------------------------------------------------------------------------
# Default policies by classification level
# ---------------------------------------------------------------------------

_DEFAULT_POLICIES: dict[ClassificationLevel, RetentionPolicy] = {
    "public": RetentionPolicy(
        period=30,
        unit="days",
        delete_after=True,
        archive_before_delete=False,
    ),
    "internal": RetentionPolicy(
        period=90,
        unit="days",
        delete_after=True,
        archive_before_delete=True,
    ),
    "confidential": RetentionPolicy(
        period=1,
        unit="years",
        delete_after=True,
        archive_before_delete=True,
    ),
    "restricted": RetentionPolicy(
        period=7,
        unit="years",
        delete_after=False,
        archive_before_delete=True,
    ),
}


# ---------------------------------------------------------------------------
# ClassificationBasedRetentionResolver
# ---------------------------------------------------------------------------


class ClassificationBasedRetentionResolver:
    """Simple classification-based retention policy resolver.

    Maps classification levels to retention policies using configurable
    defaults.
    """

    def __init__(
        self,
        custom_policies: dict[ClassificationLevel, RetentionPolicy] | None = None,
    ) -> None:
        self._policies: dict[ClassificationLevel, RetentionPolicy] = {
            **_DEFAULT_POLICIES,
        }
        if custom_policies is not None:
            self._policies.update(custom_policies)

    async def resolve(self, input: RetentionInput) -> RetentionPolicy:
        """Resolve retention policy based on classification level.

        Defaults to ``"internal"`` if no classification is provided.
        """
        classification = input.classification or "internal"
        return self._policies[classification]


# ---------------------------------------------------------------------------
# EnvironmentAwareRetentionResolver
# ---------------------------------------------------------------------------


class EnvironmentAwareRetentionResolver:
    """Environment-aware retention policy resolver.

    Uses shorter retention for dev environments and longer retention for
    production. Staging and other environments fall back to a configurable
    resolver (defaults to classification-based).
    """

    def __init__(
        self,
        dev_policy: RetentionPolicy | None = None,
        prod_policy: RetentionPolicy | None = None,
        fallback: RetentionPolicyResolver | None = None,
    ) -> None:
        self._dev_policy = dev_policy or RetentionPolicy(
            period=7,
            unit="days",
            delete_after=True,
            archive_before_delete=False,
        )
        self._prod_policy = prod_policy or _DEFAULT_POLICIES["confidential"]
        self._fallback: RetentionPolicyResolver = fallback or ClassificationBasedRetentionResolver()

    async def resolve(self, input: RetentionInput) -> RetentionPolicy:
        """Resolve retention policy based on environment.

        - ``dev``: uses short-lived dev policy
        - ``prod``: uses production policy
        - Other environments: delegates to fallback resolver
        """
        ctx = input.context
        environment = getattr(ctx, "environment", None)

        if environment == "dev":
            return self._dev_policy

        if environment == "prod":
            return self._prod_policy

        # Staging and others use the fallback
        return await self._fallback.resolve(input)


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def calculate_retention_end_date(
    start_date: datetime,
    policy: RetentionPolicy,
) -> datetime:
    """Calculate the retention end date from a start date and policy.

    Args:
        start_date: The start date of the retention period.
        policy: The retention policy defining period and unit.

    Returns:
        The calculated end date.

    Note:
        For ``"months"`` and ``"years"``, uses approximate day calculations
        (30 days/month, 365 days/year) to avoid edge cases with varying
        month lengths. This matches the TS SDK behavior where ``setMonth``
        and ``setFullYear`` handle overflow.
    """
    if policy.unit == "days":
        return start_date + timedelta(days=policy.period)
    elif policy.unit == "months":
        # Approximate month calculation matching JS Date.setMonth behavior
        year = start_date.year
        month = start_date.month + policy.period
        # Handle month overflow
        year += (month - 1) // 12
        month = ((month - 1) % 12) + 1
        # Handle day overflow (e.g., Jan 31 + 1 month)
        import calendar

        max_day = calendar.monthrange(year, month)[1]
        day = min(start_date.day, max_day)
        return start_date.replace(year=year, month=month, day=day)
    elif policy.unit == "years":
        year = start_date.year + policy.period
        # Handle leap year edge case (Feb 29)
        import calendar

        if start_date.month == 2 and start_date.day == 29:
            max_day = calendar.monthrange(year, 2)[1]
            return start_date.replace(year=year, day=min(start_date.day, max_day))
        return start_date.replace(year=year)
    else:
        # Should not happen with proper typing, but handle gracefully
        return start_date


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def create_retention_resolver(
    custom_policies: dict[ClassificationLevel, RetentionPolicy] | None = None,
) -> ClassificationBasedRetentionResolver:
    """Create a classification-based retention resolver.

    Args:
        custom_policies: Optional overrides for default classification-level policies.

    Returns:
        A ``ClassificationBasedRetentionResolver`` instance.
    """
    return ClassificationBasedRetentionResolver(custom_policies)


def create_environment_aware_retention_resolver(
    dev_policy: RetentionPolicy | None = None,
    prod_policy: RetentionPolicy | None = None,
) -> EnvironmentAwareRetentionResolver:
    """Create an environment-aware retention resolver.

    Args:
        dev_policy: Custom policy for dev environments.
        prod_policy: Custom policy for production environments.

    Returns:
        An ``EnvironmentAwareRetentionResolver`` instance.
    """
    return EnvironmentAwareRetentionResolver(
        dev_policy=dev_policy,
        prod_policy=prod_policy,
    )
