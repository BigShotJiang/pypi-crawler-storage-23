"""Policy engine for the Arelis AI SDK.

Ports the policy engine from the TypeScript SDK's governance package:
- PolicyEngine protocol
- PolicyModeEngine with enforce/monitor/off modes
- JsonRulesEngine for declarative rule evaluation
- Factory functions for creating engines
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Protocol, runtime_checkable

from arelis.policy.types import (
    JsonRulesConfig,
    PolicyDecision,
    PolicyInput,
    PolicyResult,
    PolicyResultSummary,
    RuleCondition,
    aggregate_decisions,
    allow_decision,
    block_decision,
)

__all__ = [
    "PolicyEngine",
    "PolicyModeResolver",
    "JsonRulesEngine",
    "create_policy_mode_engine",
    "create_allow_all_engine",
    "create_deny_all_engine",
]

# ---------------------------------------------------------------------------
# PolicyEngine protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class PolicyEngine(Protocol):
    """Policy engine interface."""

    async def evaluate(self, input: PolicyInput) -> PolicyResult:
        """Evaluate policies for the given input."""
        ...

    async def evaluate_compiled(self, input: PolicyInput) -> PolicyResult:
        """Evaluate policies using compiled constraints (optional).

        Default implementation delegates to evaluate().
        """
        ...


# ---------------------------------------------------------------------------
# PolicyModeResolver
# ---------------------------------------------------------------------------

PolicyModeResolver = str | Callable[[PolicyInput], str]
"""Policy mode resolver - either a literal mode string or a callable that returns one."""


def _resolve_policy_mode(
    resolver: PolicyModeResolver,
    input: PolicyInput,
) -> str:
    """Resolve the current policy enforcement mode."""
    if callable(resolver):
        return resolver(input)
    return resolver


def _allow_result() -> PolicyResult:
    """Create an allow-all result."""
    return PolicyResult(
        decisions=[allow_decision()],
        summary=PolicyResultSummary(allowed=True),
    )


# ---------------------------------------------------------------------------
# PolicyModeEngine
# ---------------------------------------------------------------------------


class _PolicyModeEngine:
    """Wraps a base policy engine with enforcement mode logic.

    - ``enforce``: respect block/approval decisions
    - ``monitor``: evaluate but do not block (summary.allowed is always True)
    - ``off``: skip evaluation entirely, always allow
    """

    def __init__(self, base: PolicyEngine, mode: PolicyModeResolver) -> None:
        self._base = base
        self._mode = mode

    async def _evaluate_with_mode(self, input: PolicyInput, prefer_compiled: bool) -> PolicyResult:
        current_mode = _resolve_policy_mode(self._mode, input)

        if current_mode == "off":
            return _allow_result()

        if prefer_compiled:
            try:
                result = await self._base.evaluate_compiled(input)
            except (AttributeError, NotImplementedError):
                result = await self._base.evaluate(input)
        else:
            result = await self._base.evaluate(input)

        if current_mode == "monitor" and not result.summary.allowed:
            return PolicyResult(
                decisions=result.decisions,
                summary=PolicyResultSummary(allowed=True),
                policy_version=result.policy_version,
            )

        return result

    async def evaluate(self, input: PolicyInput) -> PolicyResult:
        """Evaluate with mode enforcement."""
        return await self._evaluate_with_mode(input, prefer_compiled=False)

    async def evaluate_compiled(self, input: PolicyInput) -> PolicyResult:
        """Evaluate with mode enforcement, preferring compiled path."""
        return await self._evaluate_with_mode(input, prefer_compiled=True)


def create_policy_mode_engine(
    base: PolicyEngine,
    mode: PolicyModeResolver,
) -> _PolicyModeEngine:
    """Wrap a policy engine with enforcement modes.

    Args:
        base: The underlying policy engine to wrap.
        mode: Enforcement mode - ``"enforce"``, ``"monitor"``, ``"off"``,
              or a callable that resolves the mode per-input.

    Returns:
        A new engine that respects the enforcement mode.
    """
    return _PolicyModeEngine(base, mode)


# ---------------------------------------------------------------------------
# JSON Rules Engine
# ---------------------------------------------------------------------------


def _get_field_value(field: str, input: PolicyInput) -> object:
    """Get a field value from the policy input using dot notation."""
    parts = field.split(".")
    current: object = input

    for part in parts:
        if current is None:
            return None
        if not hasattr(current, "__getitem__") and not hasattr(current, part):
            # Try dict-style access
            if isinstance(current, dict):
                current = current.get(part)
            else:
                # Try attribute access on dataclass
                current = getattr(current, part, None)
        elif isinstance(current, dict):
            current = current.get(part)
        else:
            current = getattr(current, part, None)

    return current


def _evaluate_condition(condition: RuleCondition, input: PolicyInput) -> bool:
    """Evaluate a single condition against the policy input."""
    value = _get_field_value(condition.field, input)
    cond_value = condition.value

    if condition.operator == "equals":
        return value == cond_value
    elif condition.operator == "notEquals":
        return value != cond_value
    elif condition.operator == "contains":
        if isinstance(value, str) and isinstance(cond_value, str):
            return cond_value in value
        if isinstance(value, list):
            return cond_value in value
        return False
    elif condition.operator == "notContains":
        if isinstance(value, str) and isinstance(cond_value, str):
            return cond_value not in value
        if isinstance(value, list):
            return cond_value not in value
        return True
    elif condition.operator == "in":
        if isinstance(cond_value, list):
            return value in cond_value
        return False
    elif condition.operator == "notIn":
        if isinstance(cond_value, list):
            return value not in cond_value
        return True
    elif condition.operator == "matches":
        if isinstance(value, str) and isinstance(cond_value, str):
            try:
                return bool(re.search(cond_value, value))
            except re.error:
                return False
        return False
    else:
        return False


class JsonRulesEngine:
    """JSON rules policy engine implementation.

    Evaluates declarative JSON rules against policy inputs. Rules are sorted
    by priority (higher first) and evaluated in order.
    """

    def __init__(self, config: JsonRulesConfig | None = None) -> None:
        if config is None:
            config = JsonRulesConfig(rules=[])
        # Sort rules by priority (higher first)
        self._rules = sorted(
            list(config.rules),
            key=lambda r: r.priority if r.priority is not None else 0,
            reverse=True,
        )
        self._default_action = config.default_action or "allow"
        self._default_block_reason = config.default_block_reason or "Request blocked by policy"
        self._version = config.version

    async def evaluate(self, input: PolicyInput) -> PolicyResult:
        """Evaluate rules against the policy input."""
        decisions: list[PolicyDecision] = []

        # Filter rules that apply to this checkpoint
        applicable_rules = [rule for rule in self._rules if input.checkpoint in rule.checkpoints]

        for rule in applicable_rules:
            # Check if all conditions match
            all_match = all(_evaluate_condition(cond, input) for cond in rule.conditions)

            if all_match:
                if rule.action == "block":
                    decisions.append(
                        block_decision(
                            rule.reason or "Blocked by rule",
                            rule.code,
                        )
                    )
                    # Stop evaluation on first block
                    break
                else:
                    decisions.append(allow_decision())

        # Apply default action if no explicit decisions
        if len(decisions) == 0:
            if self._default_action == "block":
                decisions.append(block_decision(self._default_block_reason))
            else:
                decisions.append(allow_decision())

        result = aggregate_decisions(decisions)
        if self._version is not None:
            result.policy_version = self._version
        return result

    async def evaluate_compiled(self, input: PolicyInput) -> PolicyResult:
        """Evaluate compiled (delegates to evaluate for JSON rules)."""
        return await self.evaluate(input)

    def add_rule(self, rule: object) -> None:
        """Add a rule to the engine.

        Args:
            rule: A JsonRule instance to add.
        """
        from arelis.policy.types import JsonRule

        if not isinstance(rule, JsonRule):
            raise TypeError(f"Expected JsonRule, got {type(rule).__name__}")
        self._rules.append(rule)
        # Re-sort by priority
        self._rules.sort(
            key=lambda r: r.priority if r.priority is not None else 0,
            reverse=True,
        )

    def remove_rule(self, rule_id: str) -> bool:
        """Remove a rule by ID.

        Returns:
            True if the rule was found and removed, False otherwise.
        """
        for i, rule in enumerate(self._rules):
            if rule.id == rule_id:
                self._rules.pop(i)
                return True
        return False

    def get_rules(self) -> list[object]:
        """Get all rules (read-only copy)."""
        return list(self._rules)


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def create_allow_all_engine() -> _AllowAllEngine:
    """Create an allow-all policy engine (for development)."""
    return _AllowAllEngine()


def create_deny_all_engine(reason: str = "All requests denied") -> _DenyAllEngine:
    """Create a deny-all policy engine (for testing)."""
    return _DenyAllEngine(reason)


class _AllowAllEngine:
    """Policy engine that always allows."""

    async def evaluate(self, input: PolicyInput) -> PolicyResult:
        return aggregate_decisions([allow_decision()])

    async def evaluate_compiled(self, input: PolicyInput) -> PolicyResult:
        return await self.evaluate(input)


class _DenyAllEngine:
    """Policy engine that always denies."""

    def __init__(self, reason: str) -> None:
        self._reason = reason

    async def evaluate(self, input: PolicyInput) -> PolicyResult:
        return aggregate_decisions([block_decision(self._reason, "DENY_ALL")])

    async def evaluate_compiled(self, input: PolicyInput) -> PolicyResult:
        return await self.evaluate(input)
