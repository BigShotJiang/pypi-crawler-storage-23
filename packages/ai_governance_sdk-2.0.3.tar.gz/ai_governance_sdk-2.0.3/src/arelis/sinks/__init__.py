"""HTTP audit sink module for the Arelis AI SDK.

Provides :class:`HttpAuditSink` for posting audit events to an HTTP endpoint
with batching, retry, and configurable authentication.
"""

from __future__ import annotations

from arelis.sinks.http import (
    HttpAuditSink,
    HttpSinkAuth,
    HttpSinkAuthBasic,
    HttpSinkAuthBearer,
    HttpSinkAuthCustom,
    HttpSinkAuthHeader,
    HttpSinkConfig,
    HttpSinkError,
    create_http_audit_sink,
)

__all__ = [
    "HttpAuditSink",
    "HttpSinkAuth",
    "HttpSinkAuthBasic",
    "HttpSinkAuthBearer",
    "HttpSinkAuthCustom",
    "HttpSinkAuthHeader",
    "HttpSinkConfig",
    "HttpSinkError",
    "create_http_audit_sink",
]
