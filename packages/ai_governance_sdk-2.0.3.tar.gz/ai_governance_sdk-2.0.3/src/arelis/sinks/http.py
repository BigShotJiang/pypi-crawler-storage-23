"""HTTP audit sink for the Arelis AI SDK.

Posts audit events to an HTTP endpoint with batching, retry, and authentication
support. Uses ``httpx.AsyncClient`` for async HTTP requests.

Ports ``packages/sinks-http/src/http-sink.ts`` from the TypeScript SDK.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import math
import random
from base64 import b64encode
from dataclasses import asdict, dataclass, field
from typing import Literal

import httpx

from arelis.audit.types import AuditEvent

__all__ = [
    "HttpAuditSink",
    "HttpSinkAuth",
    "HttpSinkAuthBasic",
    "HttpSinkAuthBearer",
    "HttpSinkAuthCustom",
    "HttpSinkAuthHeader",
    "HttpSinkConfig",
    "HttpSinkError",
    "create_http_audit_sink",
]


# ---------------------------------------------------------------------------
# Authentication types (discriminated union)
# ---------------------------------------------------------------------------


@dataclass
class HttpSinkAuthBearer:
    """Bearer token authentication."""

    type: Literal["bearer"] = field(default="bearer", init=False)
    token: str = ""


@dataclass
class HttpSinkAuthBasic:
    """Basic authentication."""

    type: Literal["basic"] = field(default="basic", init=False)
    username: str = ""
    password: str = ""


@dataclass
class HttpSinkAuthHeader:
    """Custom single header authentication."""

    type: Literal["header"] = field(default="header", init=False)
    name: str = ""
    value: str = ""


@dataclass
class HttpSinkAuthCustom:
    """Custom headers authentication."""

    type: Literal["custom"] = field(default="custom", init=False)
    headers: dict[str, str] = field(default_factory=dict)


HttpSinkAuth = HttpSinkAuthBearer | HttpSinkAuthBasic | HttpSinkAuthHeader | HttpSinkAuthCustom


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class HttpSinkConfig:
    """Configuration for the HTTP audit sink."""

    endpoint: str = ""
    """Target endpoint URL."""

    auth: HttpSinkAuth | None = None
    """Authentication configuration."""

    max_retries: int = 3
    """Maximum number of retries (default: 3)."""

    base_delay_ms: int = 1000
    """Base delay for exponential backoff in ms (default: 1000)."""

    max_delay_ms: int = 30000
    """Maximum delay for exponential backoff in ms (default: 30000)."""

    batching: bool = False
    """Enable batching (default: False)."""

    batch_size: int = 100
    """Batch size threshold (default: 100)."""

    flush_interval_ms: int = 5000
    """Flush interval in ms (default: 5000)."""

    timeout_ms: int = 30000
    """Request timeout in ms (default: 30000)."""

    headers: dict[str, str] | None = None
    """Custom headers to include in requests."""


# ---------------------------------------------------------------------------
# Error
# ---------------------------------------------------------------------------


class HttpSinkError(Exception):
    """Error thrown by the HTTP audit sink."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


# ---------------------------------------------------------------------------
# Serialization helper
# ---------------------------------------------------------------------------


def _serialize_event(event: AuditEvent) -> dict[str, object]:
    """Serialize an audit event to a JSON-safe dict."""
    return asdict(event)


# ---------------------------------------------------------------------------
# HTTP Audit Sink
# ---------------------------------------------------------------------------


class HttpAuditSink:
    """HTTP audit sink for posting audit events to an endpoint.

    Implements the ``AuditSink`` protocol with batching, periodic flush, retry
    with exponential backoff, and configurable authentication.
    """

    def __init__(self, config: HttpSinkConfig) -> None:
        self._config = config
        self._buffer: list[AuditEvent] = []
        self._flush_task: asyncio.Task[None] | None = None
        self._closed = False
        self._client: httpx.AsyncClient | None = None

        if self._config.batching:
            self._start_flush_timer()

    # -- AuditSink protocol --------------------------------------------------

    async def write(self, event: AuditEvent) -> None:
        """Write a single audit event."""
        if self._closed:
            raise HttpSinkError("HttpAuditSink is closed")

        if self._config.batching:
            self._buffer.append(event)
            if len(self._buffer) >= self._config.batch_size:
                await self.flush()
        else:
            await self._send_with_retry([event])

    async def write_batch(self, events: list[AuditEvent]) -> None:
        """Write multiple audit events."""
        if self._closed:
            raise HttpSinkError("HttpAuditSink is closed")

        if self._config.batching:
            self._buffer.extend(events)
            if len(self._buffer) >= self._config.batch_size:
                await self.flush()
        else:
            await self._send_with_retry(events)

    async def flush(self) -> None:
        """Flush buffered events to the endpoint."""
        if not self._buffer:
            return

        events = self._buffer
        self._buffer = []

        await self._send_with_retry(events)

    async def close(self) -> None:
        """Close the sink and flush remaining events."""
        if self._closed:
            return

        self._closed = True
        self._stop_flush_timer()

        if self._buffer:
            await self.flush()

        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # -- Internal methods ---------------------------------------------------

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self._config.timeout_ms / 1000.0)
            )
        return self._client

    async def _send_with_retry(self, events: list[AuditEvent]) -> None:
        """Send events with retry logic and exponential backoff."""
        last_error: BaseException | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                await self._send(events)
                return
            except HttpSinkError as exc:
                last_error = exc
                # Do not retry on client errors (4xx)
                if exc.status_code is not None and 400 <= exc.status_code < 500:
                    raise
                # Do not wait after the last attempt
                if attempt < self._config.max_retries:
                    delay = self._calculate_backoff_delay(attempt)
                    await asyncio.sleep(delay / 1000.0)
            except Exception as exc:
                last_error = exc
                if attempt < self._config.max_retries:
                    delay = self._calculate_backoff_delay(attempt)
                    await asyncio.sleep(delay / 1000.0)

        if last_error is not None:
            raise last_error
        raise HttpSinkError("Failed to send events")

    async def _send(self, events: list[AuditEvent]) -> None:
        """Send events to the endpoint."""
        client = await self._get_client()
        headers = self._build_headers()
        payload = json.dumps(
            {"events": [_serialize_event(e) for e in events]},
            default=str,
        )

        try:
            response = await client.post(
                self._config.endpoint,
                content=payload,
                headers=headers,
            )
        except httpx.TimeoutException as exc:
            raise HttpSinkError("Request timeout") from exc

        if response.status_code >= 400:
            raise HttpSinkError(
                f"HTTP {response.status_code}: {response.reason_phrase}",
                response.status_code,
            )

    def _build_headers(self) -> dict[str, str]:
        """Build request headers including authentication."""
        headers: dict[str, str] = {"Content-Type": "application/json"}

        if self._config.headers:
            headers.update(self._config.headers)

        if self._config.auth is not None:
            auth_headers = self._get_auth_headers(self._config.auth)
            headers.update(auth_headers)

        return headers

    @staticmethod
    def _get_auth_headers(auth: HttpSinkAuth) -> dict[str, str]:
        """Get authentication headers based on auth config."""
        if isinstance(auth, HttpSinkAuthBearer):
            return {"Authorization": f"Bearer {auth.token}"}
        elif isinstance(auth, HttpSinkAuthBasic):
            encoded = b64encode(f"{auth.username}:{auth.password}".encode()).decode("ascii")
            return {"Authorization": f"Basic {encoded}"}
        elif isinstance(auth, HttpSinkAuthHeader):
            return {auth.name: auth.value}
        elif isinstance(auth, HttpSinkAuthCustom):
            return dict(auth.headers)
        return {}

    def _calculate_backoff_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay with jitter."""
        exponential_delay = self._config.base_delay_ms * math.pow(2, attempt)
        capped_delay = min(exponential_delay, self._config.max_delay_ms)
        # Add jitter (0-25% of delay)
        jitter = capped_delay * 0.25 * random.random()
        return math.floor(capped_delay + jitter)

    def _start_flush_timer(self) -> None:
        """Start the periodic flush timer for batching."""

        async def _periodic_flush() -> None:
            while not self._closed:
                await asyncio.sleep(self._config.flush_interval_ms / 1000.0)
                if not self._closed and self._buffer:
                    with contextlib.suppress(Exception):
                        await self.flush()

        try:
            loop = asyncio.get_running_loop()
            self._flush_task = loop.create_task(_periodic_flush())
        except RuntimeError:
            # No running event loop yet -- timer will be started lazily
            pass

    def _stop_flush_timer(self) -> None:
        """Stop the periodic flush timer."""
        if self._flush_task is not None:
            self._flush_task.cancel()
            self._flush_task = None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_http_audit_sink(config: HttpSinkConfig) -> HttpAuditSink:
    """Create an HTTP audit sink."""
    return HttpAuditSink(config)
