"""Data source provider protocol.

Ports the TypeScript SDK's `DataSourceProvider` interface from
`packages/data-sources/src/types.ts`.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from arelis.data_sources.types import DataSourceContext, DataSourceQuery, DataSourceResult

__all__ = [
    "DataSourceProvider",
]


@runtime_checkable
class DataSourceProvider(Protocol):
    """Interface for data source providers.

    Implementations must expose an ``id`` property and an async ``read()`` method
    that executes a query against the data source.
    """

    @property
    def id(self) -> str:
        """Unique identifier for this provider."""
        ...

    async def read(
        self,
        query: DataSourceQuery,
        context: DataSourceContext,
    ) -> DataSourceResult:
        """Read data from the source using the given query and context."""
        ...
