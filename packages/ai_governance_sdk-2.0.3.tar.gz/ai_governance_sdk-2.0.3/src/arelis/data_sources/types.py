"""Data source types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/data-sources/src/types.ts`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from arelis.core.types import GovernanceContext

__all__ = [
    "DataClass",
    "DataResidency",
    "DataSourceAccess",
    "DataSourceContext",
    "DataSourceDescriptor",
    "DataSourceGovernance",
    "DataSourceQuery",
    "DataSourceReadInput",
    "DataSourceRegisterInput",
    "DataSourceResult",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

DataClass = Literal["public", "internal", "confidential", "restricted"]
"""Classification level for a data source."""

DataResidency = Literal["EU", "US", "APAC"]
"""Geographic data residency region."""

# ---------------------------------------------------------------------------
# Nested descriptor types
# ---------------------------------------------------------------------------


@dataclass
class DataSourceGovernance:
    """Governance metadata attached to a data source descriptor."""

    data_residency: DataResidency | None = None
    approved_for_purposes: list[str] | None = None
    data_class: DataClass | None = None


@dataclass
class DataSourceAccess:
    """Access permissions for a data source."""

    read: bool | None = None
    write: bool | None = None


# ---------------------------------------------------------------------------
# Core types
# ---------------------------------------------------------------------------


@dataclass
class DataSourceDescriptor:
    """Describes a registered data source and its properties."""

    id: str
    provider: str
    region: str | None = None
    governance: DataSourceGovernance | None = None
    access: DataSourceAccess | None = None
    connection: dict[str, object] | None = None


@dataclass
class DataSourceContext:
    """Runtime context passed to data source operations."""

    run_id: str
    governance: object  # GovernanceContext — imported as object to avoid circular deps


@dataclass
class DataSourceQuery:
    """Query parameters for reading from a data source."""

    source_id: str
    query: str
    metadata: dict[str, object] | None = None


@dataclass
class DataSourceResult:
    """Result returned from a data source read operation."""

    records: list[object] = field(default_factory=list)
    total: int | None = None


# ---------------------------------------------------------------------------
# Client method input types
# ---------------------------------------------------------------------------


@dataclass
class DataSourceRegisterInput:
    """Input for ``client.data_sources.register()``."""

    descriptor: DataSourceDescriptor
    provider: object  # DataSourceProvider — use object to avoid circular import
    context: GovernanceContext | None = None


@dataclass
class DataSourceReadInput:
    """Input for ``client.data_sources.read()``."""

    source_id: str
    query: str
    context: GovernanceContext | None = None
    metadata: dict[str, object] | None = None
