"""Data sources module — registry and provider protocol for external data."""

from __future__ import annotations

from arelis.data_sources.provider import DataSourceProvider
from arelis.data_sources.registry import (
    DataSourceRegistry,
    RegisteredDataSource,
    create_data_source_registry,
)
from arelis.data_sources.types import (
    DataClass,
    DataResidency,
    DataSourceAccess,
    DataSourceContext,
    DataSourceDescriptor,
    DataSourceGovernance,
    DataSourceQuery,
    DataSourceResult,
)

__all__ = [
    "DataClass",
    "DataResidency",
    "DataSourceAccess",
    "DataSourceContext",
    "DataSourceDescriptor",
    "DataSourceGovernance",
    "DataSourceProvider",
    "DataSourceQuery",
    "DataSourceRegistry",
    "DataSourceResult",
    "RegisteredDataSource",
    "create_data_source_registry",
]
