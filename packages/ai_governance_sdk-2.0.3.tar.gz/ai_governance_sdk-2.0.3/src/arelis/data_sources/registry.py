"""Data source registry.

Ports the TypeScript SDK's `DataSourceRegistry` from
`packages/data-sources/src/registry.ts`.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.data_sources.provider import DataSourceProvider
from arelis.data_sources.types import DataSourceDescriptor

__all__ = [
    "DataSourceRegistry",
    "RegisteredDataSource",
    "create_data_source_registry",
]


@dataclass
class RegisteredDataSource:
    """A data source that has been registered in the registry."""

    descriptor: DataSourceDescriptor
    provider: DataSourceProvider
    registered_at: str


class DataSourceRegistry:
    """Registry for managing data source descriptors and their providers.

    Mirrors the TypeScript ``DataSourceRegistry`` class, providing ``register``,
    ``get``, ``list``, and ``clear`` operations.
    """

    def __init__(self) -> None:
        self._sources: dict[str, RegisteredDataSource] = {}

    def register(
        self,
        descriptor: DataSourceDescriptor,
        provider: DataSourceProvider,
    ) -> None:
        """Register a data source with its provider.

        Raises ``ValueError`` if the descriptor has no ``id``.
        """
        if not descriptor.id:
            raise ValueError("Data source id is required")

        self._sources[descriptor.id] = RegisteredDataSource(
            descriptor=descriptor,
            provider=provider,
            registered_at=datetime.now(timezone.utc).isoformat(),
        )

    def get(self, id: str) -> RegisteredDataSource | None:
        """Look up a registered data source by id."""
        return self._sources.get(id)

    def list(self) -> list[RegisteredDataSource]:
        """Return all registered data sources."""
        return list(self._sources.values())

    def clear(self) -> None:
        """Remove all registered data sources."""
        self._sources.clear()


def create_data_source_registry() -> DataSourceRegistry:
    """Factory function to create a new ``DataSourceRegistry``."""
    return DataSourceRegistry()
