"""Storage module for the Arelis AI SDK.

Provides PostgreSQL-backed storage implementations. Requires the ``asyncpg``
package::

    pip install "ai-governance-sdk[postgres]"

Use::

    from arelis.storage.postgres import (
        PostgresAuditSink,
        PostgresCausalGraphStore,
        PostgresMemoryProvider,
    )
"""

from __future__ import annotations

__all__: list[str] = []
