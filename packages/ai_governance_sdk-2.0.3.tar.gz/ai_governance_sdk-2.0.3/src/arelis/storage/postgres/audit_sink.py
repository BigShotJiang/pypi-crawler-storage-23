"""PostgreSQL audit sink for the Arelis AI SDK.

Persists audit events to a PostgreSQL database using ``asyncpg``.
Supports batching, periodic flush, and retry with exponential backoff.

Ports ``packages/storage-postgres/src/postgres-audit-sink.ts`` from the
TypeScript SDK, replacing Prisma with raw SQL via asyncpg.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import math
import random
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone

from arelis.audit.types import AuditEvent
from arelis.storage.postgres.migrations import MigrationMode, run_migrations, should_migrate

__all__ = [
    "PostgresAuditSink",
    "PostgresAuditSinkConfig",
    "PostgresStorageConfig",
    "PostgresStorageError",
    "create_postgres_audit_sink",
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class PostgresStorageError(Exception):
    """Error class for PostgreSQL storage operations."""

    def __init__(
        self,
        message: str,
        code: str,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.__cause__ = cause


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class PostgresStorageConfig:
    """Base configuration for PostgreSQL storage."""

    connection_string: str | None = None
    """Database connection URL. Defaults to DATABASE_URL env variable."""

    schema: str | None = None
    """Optional schema name for table isolation."""

    auto_migrate: MigrationMode = "auto"
    """Migration mode: 'auto' migrates in dev/test, 'always' always, 'never' skips."""

    debug: bool = False
    """Enable debug logging."""


@dataclass
class PostgresAuditSinkConfig(PostgresStorageConfig):
    """Configuration for PostgresAuditSink."""

    batching: bool = True
    """Enable batching (default: True)."""

    batch_size: int = 100
    """Batch size threshold (default: 100)."""

    flush_interval_ms: int = 5000
    """Flush interval in ms (default: 5000)."""

    max_retries: int = 3
    """Maximum number of retries (default: 3)."""

    base_delay_ms: int = 1000
    """Base delay for exponential backoff in ms (default: 1000)."""

    max_delay_ms: int = 30000
    """Maximum delay for exponential backoff in ms (default: 30000)."""


# ---------------------------------------------------------------------------
# Serialization helper
# ---------------------------------------------------------------------------


def _serialize_event(event: AuditEvent) -> dict[str, object]:
    """Serialize an audit event to a JSON-safe dict."""
    return asdict(event)


# ---------------------------------------------------------------------------
# Connection pool helper
# ---------------------------------------------------------------------------


async def _get_pool(config: PostgresStorageConfig) -> object:
    """Create or reuse an asyncpg connection pool."""
    import os

    import asyncpg

    dsn = config.connection_string or os.environ.get("DATABASE_URL")
    if not dsn:
        raise PostgresStorageError(
            "Database URL not provided. Set DATABASE_URL env variable "
            "or pass connection_string in config.",
            "CONFIG_ERROR",
        )

    if should_migrate(config.auto_migrate):
        await run_migrations(dsn, schema=config.schema, debug=config.debug)

    pool: asyncpg.Pool = await asyncpg.create_pool(dsn)
    return pool


# ---------------------------------------------------------------------------
# PostgreSQL Audit Sink
# ---------------------------------------------------------------------------


class PostgresAuditSink:
    """PostgreSQL audit sink using asyncpg.

    Implements the ``AuditSink`` protocol with batching, periodic flush,
    retry with exponential backoff, and connection pooling.
    """

    def __init__(self, config: PostgresAuditSinkConfig | None = None) -> None:
        self._config = config or PostgresAuditSinkConfig()
        self._pool: object | None = None
        self._pool_lock = asyncio.Lock()
        self._buffer: list[AuditEvent] = []
        self._flush_task: asyncio.Task[None] | None = None
        self._closed = False

        if self._config.batching:
            self._start_flush_timer()

    # -- AuditSink protocol --------------------------------------------------

    async def write(self, event: AuditEvent) -> None:
        """Write a single audit event."""
        if self._closed:
            raise PostgresStorageError("PostgresAuditSink is closed", "SINK_CLOSED")

        if self._config.batching:
            self._buffer.append(event)
            if len(self._buffer) >= self._config.batch_size:
                await self.flush()
        else:
            await self._insert_with_retry([event])

    async def write_batch(self, events: list[AuditEvent]) -> None:
        """Write multiple audit events."""
        if self._closed:
            raise PostgresStorageError("PostgresAuditSink is closed", "SINK_CLOSED")

        if self._config.batching:
            self._buffer.extend(events)
            if len(self._buffer) >= self._config.batch_size:
                await self.flush()
        else:
            await self._insert_with_retry(events)

    async def flush(self) -> None:
        """Flush buffered events to the database."""
        if not self._buffer:
            return

        events = self._buffer
        self._buffer = []

        try:
            await self._insert_with_retry(events)
        except Exception:
            # Re-queue failed batch
            self._buffer = events + self._buffer
            raise

    async def close(self) -> None:
        """Close the sink and flush remaining events."""
        if self._closed:
            return

        self._closed = True
        self._stop_flush_timer()

        if self._buffer:
            await self.flush()

        if self._pool is not None:
            import asyncpg

            pool: asyncpg.Pool = self._pool
            await pool.close()
            self._pool = None

    # -- Extended methods (causal graph and compliance artifacts) -----

    async def save_causal_graph(self, graph: object) -> None:
        """Persist a causal audit graph snapshot as a synthetic audit event.

        Args:
            graph: A causal graph object with ``run_id`` and ``nodes``
                attributes.
        """
        pool = await self._get_pool()
        run_id = getattr(graph, "run_id", "")
        context = self._extract_context_from_graph(graph)
        event_id = f"cag_{uuid.uuid4()}"
        now = datetime.now(timezone.utc)
        payload = json.dumps({"graph": _graph_to_dict(graph)}, default=str)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            await conn.execute(
                """
                INSERT INTO audit_events
                    (event_id, run_id, parent_run_id, type, time,
                     org_id, team_id, actor_type, actor_id, purpose,
                     environment, payload)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                ON CONFLICT (event_id) DO NOTHING
                """,
                event_id,
                run_id,
                None,
                "cag.snapshot",
                now,
                context["org_id"],
                context.get("team_id"),
                context["actor_type"],
                context["actor_id"],
                context["purpose"],
                context["environment"],
                payload,
            )

    async def save_compliance_artifact(self, artifact: object) -> None:
        """Persist a compliance artifact as a synthetic audit event.

        Args:
            artifact: A compliance artifact object with ``run_id`` and
                optional ``context`` attributes.
        """
        pool = await self._get_pool()
        run_id = getattr(artifact, "run_id", "")
        ctx = getattr(artifact, "context", None)
        if ctx is not None:
            org_id = getattr(getattr(ctx, "org", None), "id", "unknown")
            actor_type = getattr(getattr(ctx, "actor", None), "type", "service")
            actor_id = getattr(getattr(ctx, "actor", None), "id", "unknown")
            purpose = getattr(ctx, "purpose", "compliance-artifact")
            environment = getattr(ctx, "environment", "prod")
            team = getattr(ctx, "team", None)
            team_id = getattr(team, "id", None) if team else None
        else:
            org_id = "unknown"
            actor_type = "service"
            actor_id = "unknown"
            purpose = "compliance-artifact"
            environment = "prod"
            team_id = None

        event_id = f"artifact_{uuid.uuid4()}"
        now = datetime.now(timezone.utc)
        payload = json.dumps({"artifact": _obj_to_dict(artifact)}, default=str)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            await conn.execute(
                """
                INSERT INTO audit_events
                    (event_id, run_id, parent_run_id, type, time,
                     org_id, team_id, actor_type, actor_id, purpose,
                     environment, payload)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                ON CONFLICT (event_id) DO NOTHING
                """,
                event_id,
                run_id,
                None,
                "compliance.artifact",
                now,
                org_id,
                team_id,
                actor_type,
                actor_id,
                purpose,
                environment,
                payload,
            )

    # -- Internal -----------------------------------------------------------

    async def _get_pool(self) -> object:
        """Get or create the connection pool (thread-safe)."""
        if self._pool is not None:
            return self._pool

        async with self._pool_lock:
            if self._pool is None:
                self._pool = await _get_pool(self._config)
            return self._pool

    async def _insert_with_retry(self, events: list[AuditEvent]) -> None:
        """Insert events with retry and exponential backoff."""
        last_error: BaseException | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                await self._insert(events)
                return
            except Exception as exc:
                last_error = exc
                # Do not retry validation errors
                if self._is_validation_error(exc):
                    raise
                if attempt < self._config.max_retries:
                    delay = self._calculate_backoff_delay(attempt)
                    await asyncio.sleep(delay / 1000.0)

        raise PostgresStorageError(
            f"Failed to insert audit events after {self._config.max_retries} retries",
            "INSERT_FAILED",
            last_error,
        )

    async def _insert(self, events: list[AuditEvent]) -> None:
        """Insert events into the database."""
        pool = await self._get_pool()

        rows = []
        for event in events:
            ctx = event.context
            rows.append(
                (
                    event.event_id,
                    event.run_id,
                    getattr(event, "parent_run_id", None),
                    event.type,
                    datetime.fromisoformat(event.time)
                    if isinstance(event.time, str)
                    else event.time,
                    ctx.org.id,
                    ctx.team.id if ctx.team else None,
                    ctx.actor.type,
                    ctx.actor.id,
                    ctx.purpose,
                    ctx.environment,
                    json.dumps(_serialize_event(event), default=str),
                )
            )

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            await conn.executemany(
                """
                INSERT INTO audit_events
                    (event_id, run_id, parent_run_id, type, time,
                     org_id, team_id, actor_type, actor_id, purpose,
                     environment, payload)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                ON CONFLICT (event_id) DO NOTHING
                """,
                rows,
            )

    @staticmethod
    def _extract_context_from_graph(graph: object) -> dict[str, str | None]:
        """Extract context from the first event node of a causal graph."""
        nodes = getattr(graph, "nodes", [])
        for node in nodes:
            if getattr(node, "kind", None) == "event":
                event = getattr(node, "event", None)
                if event is not None:
                    ctx = getattr(event, "context", None)
                    if ctx is not None:
                        org = getattr(ctx, "org", None)
                        actor = getattr(ctx, "actor", None)
                        team = getattr(ctx, "team", None)
                        return {
                            "org_id": getattr(org, "id", "unknown"),
                            "team_id": getattr(team, "id", None) if team else None,
                            "actor_type": getattr(actor, "type", "service"),
                            "actor_id": getattr(actor, "id", "unknown"),
                            "purpose": getattr(ctx, "purpose", "cag.snapshot"),
                            "environment": getattr(ctx, "environment", "prod"),
                        }
        return {
            "org_id": "unknown",
            "team_id": None,
            "actor_type": "service",
            "actor_id": "unknown",
            "purpose": "cag.snapshot",
            "environment": "prod",
        }

    @staticmethod
    def _is_validation_error(error: BaseException) -> bool:
        """Check if an error is a validation (non-retryable) error."""
        message = str(error).lower()
        return any(keyword in message for keyword in ("validation", "invalid", "constraint"))

    def _calculate_backoff_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay with jitter."""
        exponential_delay = self._config.base_delay_ms * math.pow(2, attempt)
        capped_delay = min(exponential_delay, self._config.max_delay_ms)
        jitter = capped_delay * 0.25 * random.random()
        return math.floor(capped_delay + jitter)

    def _start_flush_timer(self) -> None:
        """Start the periodic flush timer."""

        async def _periodic_flush() -> None:
            while not self._closed:
                await asyncio.sleep(self._config.flush_interval_ms / 1000.0)
                if not self._closed and self._buffer:
                    with contextlib.suppress(Exception):
                        await self.flush()

        try:
            loop = asyncio.get_running_loop()
            self._flush_task = loop.create_task(_periodic_flush())
        except RuntimeError:
            pass

    def _stop_flush_timer(self) -> None:
        """Stop the periodic flush timer."""
        if self._flush_task is not None:
            self._flush_task.cancel()
            self._flush_task = None


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------


def _graph_to_dict(graph: object) -> dict[str, object]:
    """Convert a graph-like object to a dict."""
    if hasattr(graph, "__dict__"):
        return {k: v for k, v in graph.__dict__.items() if not k.startswith("_")}
    return {}


def _obj_to_dict(obj: object) -> dict[str, object]:
    """Convert an object to a dict."""
    if hasattr(obj, "__dict__"):
        return {k: v for k, v in obj.__dict__.items() if not k.startswith("_")}
    return {}


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_postgres_audit_sink(
    config: PostgresAuditSinkConfig | None = None,
) -> PostgresAuditSink:
    """Create a PostgreSQL audit sink."""
    return PostgresAuditSink(config)
