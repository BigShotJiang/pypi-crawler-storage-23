"""PostgreSQL causal audit graph store for the Arelis AI SDK.

Persists and retrieves causal audit graphs from a PostgreSQL database using
``asyncpg``.

Ports ``packages/storage-postgres/src/postgres-causal-graph-store.ts`` from
the TypeScript SDK.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.storage.postgres.audit_sink import (
    PostgresStorageConfig,
    PostgresStorageError,
)
from arelis.storage.postgres.migrations import run_migrations, should_migrate

__all__ = [
    "PostgresCausalGraphStore",
    "create_postgres_causal_graph_store",
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Connection pool helper (shared pattern)
# ---------------------------------------------------------------------------


async def _get_pool(config: PostgresStorageConfig) -> object:
    """Create an asyncpg connection pool."""
    import os

    import asyncpg

    dsn = config.connection_string or os.environ.get("DATABASE_URL")
    if not dsn:
        raise PostgresStorageError(
            "Database URL not provided. Set DATABASE_URL env variable "
            "or pass connection_string in config.",
            "CONFIG_ERROR",
        )

    if should_migrate(config.auto_migrate):
        await run_migrations(dsn, schema=config.schema, debug=config.debug)

    pool: asyncpg.Pool = await asyncpg.create_pool(dsn)
    return pool


# ---------------------------------------------------------------------------
# CausalGraph dict representation (for storage/retrieval)
# ---------------------------------------------------------------------------


@dataclass
class CausalGraphNode:
    """A node in the causal audit graph."""

    node_id: str
    kind: str
    event_id: str | None = None
    label: str | None = None
    event: object | None = None
    metadata: dict[str, object] | None = None


@dataclass
class CausalGraphEdge:
    """An edge in the causal audit graph."""

    source: str
    target: str
    label: str | None = None
    metadata: dict[str, object] | None = None


@dataclass
class CausalGraph:
    """Causal audit graph representation."""

    run_id: str
    nodes: list[CausalGraphNode]
    edges: list[CausalGraphEdge]


# ---------------------------------------------------------------------------
# PostgreSQL Causal Graph Store
# ---------------------------------------------------------------------------


class PostgresCausalGraphStore:
    """PostgreSQL-backed causal audit graph store using asyncpg.

    Implements the ``CausalGraphStore`` protocol. Stores graphs as synthetic
    ``cag.snapshot`` events in the ``audit_events`` table (matching the
    TypeScript SDK behavior).
    """

    def __init__(self, config: PostgresStorageConfig | None = None) -> None:
        self._config = config or PostgresStorageConfig()
        self._pool: object | None = None
        self._pool_lock = asyncio.Lock()

    async def save(self, graph: object) -> None:
        """Save a causal audit graph.

        Args:
            graph: A causal graph object with ``run_id`` and ``nodes``
                attributes.
        """
        pool = await self._ensure_pool()
        run_id = getattr(graph, "run_id", "")
        context = self._extract_context(graph)
        event_id = f"cag_{uuid.uuid4()}"
        now = datetime.now(timezone.utc)
        payload = json.dumps({"graph": _to_dict(graph)}, default=str)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            await conn.execute(
                """
                INSERT INTO audit_events
                    (event_id, run_id, parent_run_id, type, time,
                     org_id, team_id, actor_type, actor_id, purpose,
                     environment, payload)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                ON CONFLICT (event_id) DO NOTHING
                """,
                event_id,
                run_id,
                None,
                "cag.snapshot",
                now,
                context["org_id"],
                context.get("team_id"),
                context["actor_type"],
                context["actor_id"],
                context["purpose"],
                context["environment"],
                payload,
            )

    async def get(self, run_id: str) -> dict[str, object] | None:
        """Retrieve the most recent causal graph for a run.

        Returns the graph as a dict, or ``None`` if not found.
        """
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            row = await conn.fetchrow(
                """
                SELECT payload FROM audit_events
                WHERE run_id = $1 AND type = 'cag.snapshot'
                ORDER BY time DESC
                LIMIT 1
                """,
                run_id,
            )

        if row is None:
            return None

        payload_str = row["payload"]
        payload = json.loads(payload_str) if isinstance(payload_str, str) else payload_str

        graph: dict[str, object] | None = payload.get("graph")
        return graph

    async def close(self) -> None:
        """Close the connection pool."""
        if self._pool is not None:
            import asyncpg

            pool: asyncpg.Pool = self._pool
            await pool.close()
            self._pool = None

    # -- Internal -----------------------------------------------------------

    async def _ensure_pool(self) -> object:
        """Get or create the connection pool."""
        if self._pool is not None:
            return self._pool

        async with self._pool_lock:
            if self._pool is None:
                self._pool = await _get_pool(self._config)
            return self._pool

    @staticmethod
    def _extract_context(graph: object) -> dict[str, str | None]:
        """Extract context from the first event node of a causal graph."""
        nodes = getattr(graph, "nodes", [])
        for node in nodes:
            if getattr(node, "kind", None) == "event":
                event = getattr(node, "event", None)
                if event is not None:
                    ctx = getattr(event, "context", None)
                    if ctx is not None:
                        org = getattr(ctx, "org", None)
                        actor = getattr(ctx, "actor", None)
                        team = getattr(ctx, "team", None)
                        return {
                            "org_id": getattr(org, "id", "unknown"),
                            "team_id": getattr(team, "id", None) if team else None,
                            "actor_type": getattr(actor, "type", "service"),
                            "actor_id": getattr(actor, "id", "unknown"),
                            "purpose": getattr(ctx, "purpose", "cag.snapshot"),
                            "environment": getattr(ctx, "environment", "prod"),
                        }
        return {
            "org_id": "unknown",
            "team_id": None,
            "actor_type": "service",
            "actor_id": "unknown",
            "purpose": "cag.snapshot",
            "environment": "prod",
        }


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------


def _to_dict(obj: object) -> dict[str, object]:
    """Convert an object to a dict, skipping private attributes."""
    if hasattr(obj, "__dict__"):
        result: dict[str, object] = {}
        for k, v in obj.__dict__.items():
            if not k.startswith("_"):
                if hasattr(v, "__dict__") and not isinstance(v, (str, int, float, bool)):
                    result[k] = _to_dict(v)
                elif isinstance(v, list):
                    result[k] = [
                        _to_dict(item) if hasattr(item, "__dict__") else item for item in v
                    ]
                else:
                    result[k] = v
        return result
    return {}


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_postgres_causal_graph_store(
    config: PostgresStorageConfig | None = None,
) -> PostgresCausalGraphStore:
    """Create a PostgreSQL causal graph store."""
    return PostgresCausalGraphStore(config)
