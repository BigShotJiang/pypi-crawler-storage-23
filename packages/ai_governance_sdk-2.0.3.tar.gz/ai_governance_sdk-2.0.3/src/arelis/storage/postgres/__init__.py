"""PostgreSQL storage backend for the Arelis AI SDK.

Provides PostgreSQL-backed implementations of:

- :class:`PostgresAuditSink` -- audit event persistence
- :class:`PostgresCausalGraphStore` -- causal audit graph storage
- :class:`PostgresMemoryProvider` -- memory provider with expiration

All require the ``asyncpg`` package::

    pip install "ai-governance-sdk[postgres]"
"""

from __future__ import annotations

from arelis.storage.postgres.audit_sink import (
    PostgresAuditSink,
    PostgresAuditSinkConfig,
    PostgresStorageConfig,
    PostgresStorageError,
    create_postgres_audit_sink,
)
from arelis.storage.postgres.cag_store import (
    CausalGraph,
    CausalGraphEdge,
    CausalGraphNode,
    PostgresCausalGraphStore,
    create_postgres_causal_graph_store,
)
from arelis.storage.postgres.memory_provider import (
    MemoryEntry,
    PostgresMemoryProvider,
    PostgresMemoryProviderConfig,
    create_postgres_memory_provider,
)
from arelis.storage.postgres.migrations import (
    MigrationMode,
    run_migrations,
    should_migrate,
)

__all__ = [
    # Config
    "MigrationMode",
    "PostgresAuditSinkConfig",
    "PostgresMemoryProviderConfig",
    "PostgresStorageConfig",
    # Errors
    "PostgresStorageError",
    # Audit sink
    "PostgresAuditSink",
    "create_postgres_audit_sink",
    # Causal graph store
    "CausalGraph",
    "CausalGraphEdge",
    "CausalGraphNode",
    "PostgresCausalGraphStore",
    "create_postgres_causal_graph_store",
    # Memory provider
    "MemoryEntry",
    "PostgresMemoryProvider",
    "create_postgres_memory_provider",
    # Migrations
    "run_migrations",
    "should_migrate",
]
