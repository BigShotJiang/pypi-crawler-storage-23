"""PostgreSQL memory provider for the Arelis AI SDK.

Persists memory entries in a PostgreSQL database using ``asyncpg``,
with support for scoped keys, multi-tenant isolation by org_id, and
optional TTL-based expiration.

Ports ``packages/storage-postgres/src/postgres-memory-provider.ts`` from
the TypeScript SDK, replacing Prisma with raw SQL via asyncpg.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.storage.postgres.audit_sink import (
    PostgresStorageConfig,
    PostgresStorageError,
)
from arelis.storage.postgres.migrations import run_migrations, should_migrate

__all__ = [
    "PostgresMemoryProvider",
    "PostgresMemoryProviderConfig",
    "create_postgres_memory_provider",
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class PostgresMemoryProviderConfig(PostgresStorageConfig):
    """Configuration for the PostgreSQL memory provider."""

    id: str = "postgres"
    """Provider ID (default: 'postgres')."""

    org_id: str | None = None
    """Organization ID override for multi-tenant isolation.

    Defaults to the org ID from the context passed to each operation.
    """


# ---------------------------------------------------------------------------
# Memory entry data type
# ---------------------------------------------------------------------------


@dataclass
class MemoryEntry:
    """A memory entry stored in PostgreSQL."""

    id: str
    scope: str
    key: str
    value: object
    created_at: str
    updated_at: str
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Connection pool helper
# ---------------------------------------------------------------------------


async def _get_pool(config: PostgresStorageConfig) -> object:
    """Create an asyncpg connection pool."""
    import asyncpg

    dsn = config.connection_string or os.environ.get("DATABASE_URL")
    if not dsn:
        raise PostgresStorageError(
            "Database URL not provided. Set DATABASE_URL env variable "
            "or pass connection_string in config.",
            "CONFIG_ERROR",
        )

    if should_migrate(config.auto_migrate):
        await run_migrations(dsn, schema=config.schema, debug=config.debug)

    pool: asyncpg.Pool = await asyncpg.create_pool(dsn)
    return pool


# ---------------------------------------------------------------------------
# PostgreSQL Memory Provider
# ---------------------------------------------------------------------------


class PostgresMemoryProvider:
    """PostgreSQL-backed memory provider using asyncpg.

    Implements the ``MemoryProvider`` protocol. Memory entries are scoped by
    ``(scope, key, org_id)`` and stored in the ``memory_entries`` table.
    """

    def __init__(self, config: PostgresMemoryProviderConfig | None = None) -> None:
        cfg = config or PostgresMemoryProviderConfig()
        self.id: str = cfg.id
        self._config = cfg
        self._pool: object | None = None
        self._pool_lock = asyncio.Lock()

    # -- MemoryProvider protocol ---------------------------------------------

    async def read(
        self,
        scope: str,
        key: str,
        context: object,
    ) -> MemoryEntry | None:
        """Read a memory entry.

        Args:
            scope: Memory scope (e.g., 'ephemeral', 'session', 'longterm', 'shared').
            key: Entry key within the scope.
            context: A memory context object with a ``governance`` attribute
                containing the org ID.

        Returns:
            The :class:`MemoryEntry` if found, otherwise ``None``.
        """
        pool = await self._ensure_pool()
        org_id = self._resolve_org_id(context)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            # Also clean up expired entries
            row = await conn.fetchrow(
                """
                SELECT id, scope, key, value, metadata, created_at, updated_at
                FROM memory_entries
                WHERE scope = $1 AND key = $2 AND org_id = $3
                  AND (expires_at IS NULL OR expires_at > NOW())
                """,
                scope,
                key,
                org_id,
            )

        if row is None:
            return None

        return self._row_to_entry(row)

    async def write(
        self,
        scope: str,
        key: str,
        value: object,
        context: object,
        metadata: dict[str, object] | None = None,
        ttl_seconds: int | None = None,
    ) -> MemoryEntry:
        """Write (upsert) a memory entry.

        Args:
            scope: Memory scope.
            key: Entry key within the scope.
            value: Value to store (must be JSON-serializable).
            context: Memory context with governance org ID.
            metadata: Optional metadata dict.
            ttl_seconds: Optional time-to-live in seconds. If provided, the
                entry will expire after this duration.

        Returns:
            The created or updated :class:`MemoryEntry`.
        """
        pool = await self._ensure_pool()
        org_id = self._resolve_org_id(context)
        now = datetime.now(timezone.utc)
        value_json = json.dumps(value, default=str)
        metadata_json = json.dumps(metadata, default=str) if metadata else None

        expires_at = None
        if ttl_seconds is not None:
            from datetime import timedelta

            expires_at = now + timedelta(seconds=ttl_seconds)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            row = await conn.fetchrow(
                """
                INSERT INTO memory_entries
                    (scope, key, org_id, value, metadata, expires_at, created_at, updated_at)
                VALUES ($1, $2, $3, $4::jsonb, $5::jsonb, $6, $7, $7)
                ON CONFLICT (scope, key, org_id)
                DO UPDATE SET
                    value = EXCLUDED.value,
                    metadata = EXCLUDED.metadata,
                    expires_at = EXCLUDED.expires_at,
                    updated_at = EXCLUDED.updated_at
                RETURNING id, scope, key, value, metadata, created_at, updated_at
                """,
                scope,
                key,
                org_id,
                value_json,
                metadata_json,
                expires_at,
                now,
            )

        return self._row_to_entry(row)

    async def delete(
        self,
        scope: str,
        key: str,
        context: object,
    ) -> bool:
        """Delete a memory entry.

        Returns ``True`` if an entry was deleted, ``False`` if not found.
        """
        pool = await self._ensure_pool()
        org_id = self._resolve_org_id(context)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            result = await conn.execute(
                """
                DELETE FROM memory_entries
                WHERE scope = $1 AND key = $2 AND org_id = $3
                """,
                scope,
                key,
                org_id,
            )

        # asyncpg returns "DELETE N" where N is the count
        deleted: bool = result != "DELETE 0"
        return deleted

    async def list(
        self,
        scope: str,
        context: object,
    ) -> list[MemoryEntry]:
        """List all non-expired entries in a scope.

        Args:
            scope: Memory scope.
            context: Memory context with governance org ID.

        Returns:
            List of :class:`MemoryEntry` objects ordered by creation time.
        """
        pool = await self._ensure_pool()
        org_id = self._resolve_org_id(context)

        async with pool.acquire() as conn:  # type: ignore[attr-defined]
            rows = await conn.fetch(
                """
                SELECT id, scope, key, value, metadata, created_at, updated_at
                FROM memory_entries
                WHERE scope = $1 AND org_id = $2
                  AND (expires_at IS NULL OR expires_at > NOW())
                ORDER BY created_at ASC
                """,
                scope,
                org_id,
            )

        return [self._row_to_entry(row) for row in rows]

    async def close(self) -> None:
        """Close the connection pool and release resources."""
        if self._pool is not None:
            import asyncpg

            pool: asyncpg.Pool = self._pool
            await pool.close()
            self._pool = None

    # -- Internal -----------------------------------------------------------

    async def _ensure_pool(self) -> object:
        """Get or create the connection pool."""
        if self._pool is not None:
            return self._pool

        async with self._pool_lock:
            if self._pool is None:
                self._pool = await _get_pool(self._config)
            return self._pool

    def _resolve_org_id(self, context: object) -> str:
        """Resolve org_id from config or context.

        Falls back to extracting from ``context.governance.org.id``.
        """
        if self._config.org_id is not None:
            return self._config.org_id

        governance = getattr(context, "governance", None)
        if governance is not None:
            org = getattr(governance, "org", None)
            if org is not None:
                org_id = getattr(org, "id", None)
                if org_id is not None:
                    return str(org_id)

        raise PostgresStorageError(
            "Could not resolve org_id from config or context. "
            "Provide org_id in config or ensure context.governance.org.id is set.",
            "CONFIG_ERROR",
        )

    @staticmethod
    def _row_to_entry(row: object) -> MemoryEntry:
        """Convert a database row to a MemoryEntry."""
        row_id = row["id"]  # type: ignore[index]
        value_raw = row["value"]  # type: ignore[index]
        metadata_raw = row["metadata"]  # type: ignore[index]
        created_at: datetime = row["created_at"]  # type: ignore[index]
        updated_at: datetime = row["updated_at"]  # type: ignore[index]

        # asyncpg returns jsonb as Python objects, or as strings
        if isinstance(value_raw, str):
            value: object = json.loads(value_raw)
        else:
            value = value_raw

        metadata: dict[str, object] | None = None
        if metadata_raw is not None:
            metadata = json.loads(metadata_raw) if isinstance(metadata_raw, str) else metadata_raw

        return MemoryEntry(
            id=str(row_id),
            scope=row["scope"],  # type: ignore[index]
            key=row["key"],  # type: ignore[index]
            value=value,
            created_at=created_at.isoformat(),
            updated_at=updated_at.isoformat(),
            metadata=metadata,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_postgres_memory_provider(
    config: PostgresMemoryProviderConfig | None = None,
) -> PostgresMemoryProvider:
    """Create a PostgreSQL memory provider."""
    return PostgresMemoryProvider(config)
