"""PostgreSQL migration utilities for the Arelis AI SDK.

Provides SQL DDL for creating the required tables and a simple migration
runner using ``asyncpg``.

Tables:
- ``audit_events`` -- stores audit trail events
- ``causal_graph_nodes`` -- stores causal audit graph nodes
- ``causal_graph_edges`` -- stores causal audit graph edges
- ``memory_entries`` -- stores memory provider entries with expiration
"""

from __future__ import annotations

import logging
import os
from typing import Literal

__all__ = [
    "MigrationMode",
    "run_migrations",
    "should_migrate",
]

logger = logging.getLogger(__name__)

MigrationMode = Literal["auto", "always", "never"]
"""Migration mode: 'auto' migrates in dev/test, 'always' always migrates, 'never' skips."""


# ---------------------------------------------------------------------------
# DDL Statements
# ---------------------------------------------------------------------------

_CREATE_AUDIT_EVENTS_TABLE = """\
CREATE TABLE IF NOT EXISTS audit_events (
    id              BIGSERIAL PRIMARY KEY,
    event_id        TEXT NOT NULL UNIQUE,
    run_id          TEXT NOT NULL,
    parent_run_id   TEXT,
    type            TEXT NOT NULL,
    time            TIMESTAMPTZ NOT NULL,
    org_id          TEXT NOT NULL,
    team_id         TEXT,
    actor_type      TEXT NOT NULL,
    actor_id        TEXT NOT NULL,
    purpose         TEXT NOT NULL,
    environment     TEXT NOT NULL,
    payload         JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

_CREATE_AUDIT_EVENTS_INDEXES = """\
CREATE INDEX IF NOT EXISTS idx_audit_events_run_id ON audit_events (run_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_type ON audit_events (type);
CREATE INDEX IF NOT EXISTS idx_audit_events_org_id ON audit_events (org_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_time ON audit_events (time);
CREATE INDEX IF NOT EXISTS idx_audit_events_actor_id ON audit_events (actor_id);
"""

_CREATE_CAUSAL_GRAPH_NODES_TABLE = """\
CREATE TABLE IF NOT EXISTS causal_graph_nodes (
    id              BIGSERIAL PRIMARY KEY,
    node_id         TEXT NOT NULL,
    run_id          TEXT NOT NULL,
    kind            TEXT NOT NULL,
    event_id        TEXT,
    label           TEXT,
    metadata        JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (run_id, node_id)
);
"""

_CREATE_CAUSAL_GRAPH_NODES_INDEXES = """\
CREATE INDEX IF NOT EXISTS idx_cag_nodes_run_id ON causal_graph_nodes (run_id);
"""

_CREATE_CAUSAL_GRAPH_EDGES_TABLE = """\
CREATE TABLE IF NOT EXISTS causal_graph_edges (
    id              BIGSERIAL PRIMARY KEY,
    run_id          TEXT NOT NULL,
    source_node_id  TEXT NOT NULL,
    target_node_id  TEXT NOT NULL,
    label           TEXT,
    metadata        JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

_CREATE_CAUSAL_GRAPH_EDGES_INDEXES = """\
CREATE INDEX IF NOT EXISTS idx_cag_edges_run_id ON causal_graph_edges (run_id);
CREATE INDEX IF NOT EXISTS idx_cag_edges_source ON causal_graph_edges (source_node_id);
CREATE INDEX IF NOT EXISTS idx_cag_edges_target ON causal_graph_edges (target_node_id);
"""

_CREATE_MEMORY_ENTRIES_TABLE = """\
CREATE TABLE IF NOT EXISTS memory_entries (
    id              BIGSERIAL PRIMARY KEY,
    scope           TEXT NOT NULL,
    key             TEXT NOT NULL,
    org_id          TEXT NOT NULL,
    value           JSONB NOT NULL,
    metadata        JSONB,
    expires_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (scope, key, org_id)
);
"""

_CREATE_MEMORY_ENTRIES_INDEXES = """\
CREATE INDEX IF NOT EXISTS idx_memory_entries_scope_org ON memory_entries (scope, org_id);
CREATE INDEX IF NOT EXISTS idx_memory_entries_expires ON memory_entries (expires_at)
    WHERE expires_at IS NOT NULL;
"""

_MIGRATION_STATEMENTS = [
    _CREATE_AUDIT_EVENTS_TABLE,
    _CREATE_AUDIT_EVENTS_INDEXES,
    _CREATE_CAUSAL_GRAPH_NODES_TABLE,
    _CREATE_CAUSAL_GRAPH_NODES_INDEXES,
    _CREATE_CAUSAL_GRAPH_EDGES_TABLE,
    _CREATE_CAUSAL_GRAPH_EDGES_INDEXES,
    _CREATE_MEMORY_ENTRIES_TABLE,
    _CREATE_MEMORY_ENTRIES_INDEXES,
]


# ---------------------------------------------------------------------------
# Migration helpers
# ---------------------------------------------------------------------------


def should_migrate(mode: MigrationMode) -> bool:
    """Determine if migrations should run based on mode.

    - ``'always'`` -- always run migrations
    - ``'never'`` -- never run migrations
    - ``'auto'`` -- run only if ``ARELIS_ENV`` or ``PYTHON_ENV`` is
      ``'development'`` or ``'test'``
    """
    if mode == "always":
        return True
    if mode == "never":
        return False
    # auto mode
    env = os.environ.get("ARELIS_ENV") or os.environ.get("PYTHON_ENV", "")
    return env in ("development", "test")


async def run_migrations(
    connection_string: str,
    *,
    schema: str | None = None,
    debug: bool = False,
) -> None:
    """Run database migrations to create required tables.

    Requires the ``asyncpg`` package::

        pip install "ai-governance-sdk[postgres]"

    Args:
        connection_string: PostgreSQL connection string (DSN).
        schema: Optional schema name. If provided, ``SET search_path`` is
            executed before running DDL statements.
        debug: If ``True``, log executed SQL statements.
    """
    try:
        import asyncpg
    except ImportError as exc:
        raise ImportError(
            "The 'asyncpg' package is required for PostgreSQL storage. "
            'Install it with: pip install "ai-governance-sdk[postgres]"'
        ) from exc

    conn: asyncpg.Connection = await asyncpg.connect(connection_string)
    try:
        if schema:
            await conn.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")
            await conn.execute(f"SET search_path TO {schema}")

        for stmt in _MIGRATION_STATEMENTS:
            if debug:
                logger.debug("Executing migration:\n%s", stmt)
            await conn.execute(stmt)

        logger.info("Arelis PostgreSQL migrations completed successfully.")
    finally:
        await conn.close()
