"""Compliance replay functionality for the Arelis AI SDK.

Ports ``replayCausalGraph`` and ``replayAuditRun`` from the TypeScript SDK's
``packages/audit/src/replay.ts``.
Provides causal graph replay with drift diagnostics.
"""

from __future__ import annotations

from arelis.audit.cag import CausalGraph
from arelis.audit.types import AuditEvent
from arelis.compliance.types import (
    AuditReplayResultWithSnapshot,
    AuditReplayStepOutput,
    ReplayDriftDiagnostic,
    SnapshotBundle,
)

__all__ = [
    "compute_drift_diagnostics",
    "replay_audit_run",
    "replay_causal_graph",
]


# ---------------------------------------------------------------------------
# Drift diagnostics
# ---------------------------------------------------------------------------

_DRIFT_FIELDS: list[str] = [
    "policy_snapshot_hash",
    "model_route_id",
    "tool_registry_hash",
    "config_state_hash",
]


def compute_drift_diagnostics(
    recorded_snapshot: SnapshotBundle | None,
    replay_snapshot: SnapshotBundle | None,
) -> list[ReplayDriftDiagnostic] | None:
    """Compare two snapshot bundles and return drift diagnostics.

    Returns ``None`` if either snapshot is missing.
    """
    if recorded_snapshot is None or replay_snapshot is None:
        return None

    diagnostics: list[ReplayDriftDiagnostic] = []
    for field_name in _DRIFT_FIELDS:
        recorded_val = getattr(recorded_snapshot, field_name, None)
        replayed_val = getattr(replay_snapshot, field_name, None)
        diagnostics.append(
            ReplayDriftDiagnostic(
                field=field_name,
                recorded=recorded_val,
                replayed=replayed_val,
                compatible=recorded_val == replayed_val,
            )
        )

    return diagnostics


# ---------------------------------------------------------------------------
# Replay functions
# ---------------------------------------------------------------------------


async def replay_audit_run(
    run_id: str,
    events: list[AuditEvent],
    recorded_snapshot: SnapshotBundle | None = None,
    replay_snapshot: SnapshotBundle | None = None,
) -> AuditReplayResultWithSnapshot:
    """Replay a series of audit events and produce a replay result.

    Each event becomes a step in the replay output. Model request events
    have their ``input`` resolved from inline data refs, and model response
    events have their ``output`` resolved similarly.

    Args:
        run_id: The run identifier.
        events: Ordered list of audit events.
        recorded_snapshot: Snapshot captured at original run time.
        replay_snapshot: Snapshot provided for replay comparison.

    Returns:
        The replay result with steps and optional drift diagnostics.
    """
    warnings: list[str] = []
    steps: list[AuditReplayStepOutput] = []

    for event in events:
        step_input: object | None = None
        step_output: object | None = None

        # Resolve model.request inputRef
        if event.type == "model.request":
            input_ref = getattr(event, "input_ref", None)
            if input_ref is not None:
                kind = getattr(input_ref, "kind", None)
                if kind == "inline":
                    step_input = getattr(input_ref, "value", None)
                else:
                    warnings.append(
                        f"Missing resolver for model.request.inputRef ({_describe_ref(input_ref)})"
                    )

        # Resolve model.response outputRef
        if event.type == "model.response":
            output_ref = getattr(event, "output_ref", None)
            if output_ref is not None:
                kind = getattr(output_ref, "kind", None)
                if kind == "inline":
                    step_output = getattr(output_ref, "value", None)
                else:
                    warnings.append(
                        f"Missing resolver for model.response.outputRef "
                        f"({_describe_ref(output_ref)})"
                    )

        step = AuditReplayStepOutput(
            event={
                "event_id": event.event_id,
                "run_id": event.run_id,
                "type": event.type,
                "time": event.time,
            },
            input=step_input,
            output=step_output,
        )
        steps.append(step)

    drift_diagnostics = compute_drift_diagnostics(recorded_snapshot, replay_snapshot)
    if drift_diagnostics is not None and any(not d.compatible for d in drift_diagnostics):
        warnings.append("Replay snapshot drift detected")

    return AuditReplayResultWithSnapshot(
        run_id=run_id,
        steps=steps,
        warnings=warnings if warnings else None,
        drift_diagnostics=drift_diagnostics,
    )


async def replay_causal_graph(
    graph: CausalGraph,
    recorded_snapshot: SnapshotBundle | None = None,
    replay_snapshot: SnapshotBundle | None = None,
) -> AuditReplayResultWithSnapshot:
    """Replay a causal graph by extracting events and running the audit replay.

    Events are extracted from the graph's event nodes, sorted by time, and
    replayed through :func:`replay_audit_run`.

    Args:
        graph: The causal graph to replay.
        recorded_snapshot: Snapshot from original run.
        replay_snapshot: Snapshot for replay comparison.

    Returns:
        The replay result with steps and optional drift diagnostics.
    """
    events: list[AuditEvent] = []
    for node in graph.nodes:
        if node.kind == "event" and node.event is not None:
            events.append(node.event)

    events.sort(key=lambda e: e.time)

    return await replay_audit_run(
        run_id=graph.run_id,
        events=events,
        recorded_snapshot=recorded_snapshot,
        replay_snapshot=replay_snapshot,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _describe_ref(ref: object) -> str:
    """Describe a DataRef for warning messages."""
    kind = getattr(ref, "kind", None)
    if kind == "inline":
        return "inline"
    if kind == "hash":
        sha = getattr(ref, "sha256", "")
        return f"hash:{sha}"
    uri = getattr(ref, "uri", "")
    return f"blob:{uri}"
