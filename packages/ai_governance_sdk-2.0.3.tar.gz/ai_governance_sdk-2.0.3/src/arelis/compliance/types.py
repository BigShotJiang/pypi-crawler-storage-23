"""Compliance types for the Arelis AI SDK.

Ports compliance-related types from the TypeScript SDK:
- ``packages/sdk/src/client.ts`` (ComplianceArtifactRequest, ComplianceProofRequest, etc.)
- ``packages/audit/src/compliance.ts`` (ComplianceArtifact, ComplianceArtifactStore)
- ``packages/audit/src/proofs.ts`` (ProofVerificationResult, DisclosureProof, etc.)
- ``packages/audit/src/replay.ts`` (SnapshotBundle, AuditReplayResultWithSnapshot)
- ``packages/sdk/src/config.ts`` (ComplianceConfig)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol, runtime_checkable

__all__ = [
    "AuditReplayResultWithSnapshot",
    "AuditReplayStepOutput",
    "ComplianceArtifact",
    "ComplianceArtifactRequest",
    "ComplianceArtifactStore",
    "ComplianceConfig",
    "ComplianceLayerKind",
    "ComplianceProofRequest",
    "ComplianceReplayInput",
    "ComplianceVerificationInput",
    "DisclosureProof",
    "DisclosureRule",
    "InMemoryComplianceArtifactStore",
    "LayerProof",
    "ProofVerificationResult",
    "SnapshotBundle",
    "CausalGraphCommitment",
    "ReplayDriftDiagnostic",
]

# ---------------------------------------------------------------------------
# Compliance layer kinds
# ---------------------------------------------------------------------------

ComplianceLayerKind = Literal["infra", "config", "auth", "inference", "agent", "tools"]
"""Layer kind for compliance proofs."""

# ---------------------------------------------------------------------------
# DisclosureRule
# ---------------------------------------------------------------------------


@dataclass
class DisclosureRule:
    """Disclosure rule for compliance proofs.

    Attributes:
        id: Unique identifier for the rule.
        description: Human-readable description.
        fields: Fields to disclose.
    """

    id: str
    description: str | None = None
    fields: list[str] | None = None


# ---------------------------------------------------------------------------
# CausalGraphCommitment
# ---------------------------------------------------------------------------


@dataclass
class CausalGraphCommitment:
    """Commitment to a causal graph.

    Attributes:
        run_id: Run ID the graph belongs to.
        root: Merkle root of node digests.
        algorithm: Hash algorithm used.
        created_at: ISO-8601 timestamp.
        node_count: Number of nodes in the graph.
        edge_count: Number of edges in the graph.
        signer_id: ID of the signer, if signed.
        signature: Signature, if signed.
    """

    run_id: str
    root: str
    algorithm: str
    created_at: str
    node_count: int
    edge_count: int
    signer_id: str | None = None
    signature: str | None = None


# ---------------------------------------------------------------------------
# LayerProof / DisclosureProof
# ---------------------------------------------------------------------------


@dataclass
class LayerProof:
    """Proof for a single compliance layer.

    Attributes:
        layer: The layer kind.
        digest: Hash digest of the layer content.
        algorithm: Hash algorithm used.
        event_ids: Event IDs included in this layer.
    """

    layer: ComplianceLayerKind
    digest: str
    algorithm: str = "sha256"
    event_ids: list[str] | None = None


@dataclass
class DisclosureProof:
    """Disclosure proof for compliance verification.

    Attributes:
        schema_version: Schema version of the proof.
        commitment_root: Root hash of the proof commitment.
        algorithm: Hash algorithm used.
        rule_ids: IDs of disclosure rules applied.
        disclosed_fields: Fields that are disclosed.
        layers: Layer proofs for composed proofs.
        narrowing_proof: Narrowing proof data, if included.
        lineage_proof: Lineage proof data, if included.
    """

    schema_version: str
    commitment_root: str
    algorithm: str = "sha256"
    rule_ids: list[str] | None = None
    disclosed_fields: list[str] | None = None
    layers: list[LayerProof] | None = None
    narrowing_proof: dict[str, object] | None = None
    lineage_proof: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# ComplianceArtifact
# ---------------------------------------------------------------------------

COMPLIANCE_ARTIFACT_SCHEMA_V1 = "arelis.audit.compliance.v1"
COMPLIANCE_ARTIFACT_SCHEMA_V2 = "arelis.audit.compliance.composed.v2"
COMPLIANCE_PROOF_SCHEMA_V2 = "arelis.audit.compliance.proof.composed.v2"


@dataclass
class ComplianceArtifact:
    """Compliance artifact containing commitment and proof.

    Attributes:
        id: Unique identifier for the artifact.
        run_id: Run ID this artifact belongs to.
        created_at: ISO-8601 creation timestamp.
        commitment: Causal graph commitment.
        proof: Disclosure proof.
        disclosure_rule_ids: IDs of disclosure rules applied.
        artifact_schema: Schema version of the artifact.
        context: Audit context, if available.
        policy_snapshot_hash: Hash of the policy snapshot, if available.
    """

    id: str
    run_id: str
    created_at: str
    commitment: CausalGraphCommitment
    proof: DisclosureProof
    disclosure_rule_ids: list[str] = field(default_factory=list)
    artifact_schema: str | None = None
    context: dict[str, object] | None = None
    policy_snapshot_hash: str | None = None


# ---------------------------------------------------------------------------
# ComplianceArtifactStore protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ComplianceArtifactStore(Protocol):
    """Interface for compliance artifact storage."""

    async def save(self, artifact: ComplianceArtifact) -> None:
        """Save a compliance artifact."""
        ...

    async def get(self, run_id: str, artifact_id: str) -> ComplianceArtifact | None:
        """Retrieve a specific artifact by run ID and artifact ID."""
        ...

    async def list(self, run_id: str) -> list[ComplianceArtifact]:
        """List all artifacts for a run ID."""
        ...


# ---------------------------------------------------------------------------
# InMemoryComplianceArtifactStore
# ---------------------------------------------------------------------------


class InMemoryComplianceArtifactStore:
    """In-memory implementation of :class:`ComplianceArtifactStore`."""

    def __init__(self) -> None:
        self._artifacts_by_run: dict[str, list[ComplianceArtifact]] = {}

    async def save(self, artifact: ComplianceArtifact) -> None:
        """Save a compliance artifact."""
        existing = self._artifacts_by_run.get(artifact.run_id)
        if existing is None:
            existing = []
            self._artifacts_by_run[artifact.run_id] = existing
        existing.append(artifact)

    async def get(self, run_id: str, artifact_id: str) -> ComplianceArtifact | None:
        """Retrieve a specific artifact by run ID and artifact ID."""
        artifacts = self._artifacts_by_run.get(run_id, [])
        for artifact in artifacts:
            if artifact.id == artifact_id:
                return artifact
        return None

    async def list(self, run_id: str) -> list[ComplianceArtifact]:
        """List all artifacts for a run ID."""
        return list(self._artifacts_by_run.get(run_id, []))


# ---------------------------------------------------------------------------
# ComplianceArtifactRequest / ComplianceProofRequest
# ---------------------------------------------------------------------------


@dataclass
class ComposedProofProfile:
    """Composed proof profile options.

    Attributes:
        enable_zk: Whether to enable ZK mode.
        include_narrowing_proof: Whether to include narrowing proof.
        include_lineage_proof: Whether to include lineage proof.
    """

    enable_zk: bool = False
    include_narrowing_proof: bool = False
    include_lineage_proof: bool = False


@dataclass
class ComplianceArtifactRequest:
    """Request to generate a compliance artifact.

    Attributes:
        run_id: Run ID to generate the artifact for.
        disclosure_rules: Optional disclosure rules to apply.
        disclosure_rule_ids: Optional rule IDs to filter the disclosure rules.
        composed: Optional composed proof profile.
    """

    run_id: str
    disclosure_rules: list[DisclosureRule] | None = None
    disclosure_rule_ids: list[str] | None = None
    composed: ComposedProofProfile | None = None


@dataclass
class ComplianceProofRequest(ComplianceArtifactRequest):
    """Compliance proof job request.

    Extends :class:`ComplianceArtifactRequest` with async option.

    Attributes:
        async_: Whether to use async proof jobs when available.
    """

    async_: bool = False


# ---------------------------------------------------------------------------
# ComplianceVerificationInput
# ---------------------------------------------------------------------------


@dataclass
class ComplianceVerificationInput:
    """Input for verifying a compliance artifact.

    Attributes:
        artifact: Compliance artifact to verify.
        disclosure_rules: Disclosure rules used to generate the proof.
        policy_snapshot_hash: Policy snapshot hash for verification.
        expect_composed: Require composed artifact semantics.
    """

    artifact: ComplianceArtifact
    disclosure_rules: list[DisclosureRule] | None = None
    policy_snapshot_hash: str | None = None
    expect_composed: bool | None = None


# ---------------------------------------------------------------------------
# ProofVerificationResult
# ---------------------------------------------------------------------------


@dataclass
class ProofVerificationResult:
    """Result of verifying a compliance proof.

    Attributes:
        valid: Whether the proof is valid.
        reason: Human-readable reason if invalid.
        reason_code: Machine-readable reason code.
        reason_codes: List of all reason codes.
        failed_layer: Layer that failed verification.
    """

    valid: bool
    reason: str | None = None
    reason_code: str | None = None
    reason_codes: list[str] | None = None
    failed_layer: ComplianceLayerKind | None = None


# ---------------------------------------------------------------------------
# SnapshotBundle and Replay types
# ---------------------------------------------------------------------------


@dataclass
class SnapshotBundle:
    """Snapshot bundle captured during a run.

    Attributes:
        schema: Schema identifier.
        captured_at: ISO-8601 timestamp when captured.
        policy_snapshot_hash: Hash of the policy snapshot.
        model_route_id: Model route identifier.
        tool_registry_hash: Hash of the tool registry.
        config_state_hash: Hash of the config state.
    """

    schema: str = "arelis.audit.snapshot.bundle.v1"
    captured_at: str = ""
    policy_snapshot_hash: str | None = None
    model_route_id: str | None = None
    tool_registry_hash: str | None = None
    config_state_hash: str | None = None


@dataclass
class ReplayDriftDiagnostic:
    """Diagnostic for snapshot drift during replay.

    Attributes:
        field: Field that drifted.
        recorded: Recorded value.
        replayed: Replayed value.
        compatible: Whether the recorded and replayed values are compatible.
    """

    field: str
    recorded: str | None = None
    replayed: str | None = None
    compatible: bool = True


@dataclass
class AuditReplayStepOutput:
    """Output for a single audit replay step.

    Attributes:
        event: The audit event.
        input: Input data, if available.
        output: Output data, if available.
    """

    event: dict[str, object]
    input: object | None = None
    output: object | None = None


@dataclass
class AuditReplayResultWithSnapshot:
    """Result of replaying a compliance run, with optional drift diagnostics.

    Attributes:
        run_id: The run identifier that was replayed.
        steps: Ordered list of reconstructed replay steps.
        warnings: Any warnings encountered during replay.
        drift_diagnostics: Snapshot drift diagnostics, if any.
    """

    run_id: str
    steps: list[AuditReplayStepOutput] = field(default_factory=list)
    warnings: list[str] | None = None
    drift_diagnostics: list[ReplayDriftDiagnostic] | None = None


# ---------------------------------------------------------------------------
# ComplianceReplayInput
# ---------------------------------------------------------------------------


@dataclass
class ComplianceReplayInput:
    """Input for replaying a compliance run.

    Attributes:
        run_id: Run ID to replay.
        replay_snapshot: Optional snapshot bundle for drift detection.
    """

    run_id: str
    replay_snapshot: SnapshotBundle | None = None


# ---------------------------------------------------------------------------
# ComplianceConfig
# ---------------------------------------------------------------------------


@dataclass
class ComplianceConfig:
    """Configuration for compliance features.

    Attributes:
        causal_graph_store: Store for causal graphs.
        artifact_store: Store for compliance artifacts.
        proof_provider: Provider for generating and verifying proofs.
        proof_job_queue: Queue for async proof generation jobs.
        commitment_signer: Signer for commitments.
        disclosure_rules: Default disclosure rules.
        proof_timeout_ms: Timeout for proof generation in milliseconds.
    """

    causal_graph_store: object | None = None
    artifact_store: ComplianceArtifactStore | None = None
    proof_provider: object | None = None
    proof_job_queue: object | None = None
    commitment_signer: object | None = None
    disclosure_rules: list[DisclosureRule] | None = None
    proof_timeout_ms: int | None = None
