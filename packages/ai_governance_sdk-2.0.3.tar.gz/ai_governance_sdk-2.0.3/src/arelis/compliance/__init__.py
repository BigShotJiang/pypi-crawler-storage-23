"""Compliance module for the Arelis AI SDK.

Provides compliance artifact verification, types for compliance proofs,
causal graph commitments, replay functionality, and disclosure rule resolution.
"""

from __future__ import annotations

from arelis.compliance.disclosure import resolve_disclosure_rules
from arelis.compliance.replay import (
    compute_drift_diagnostics,
    replay_audit_run,
    replay_causal_graph,
)
from arelis.compliance.types import (
    COMPLIANCE_ARTIFACT_SCHEMA_V1,
    COMPLIANCE_ARTIFACT_SCHEMA_V2,
    COMPLIANCE_PROOF_SCHEMA_V2,
    AuditReplayResultWithSnapshot,
    AuditReplayStepOutput,
    CausalGraphCommitment,
    ComplianceArtifact,
    ComplianceArtifactRequest,
    ComplianceArtifactStore,
    ComplianceConfig,
    ComplianceLayerKind,
    ComplianceProofRequest,
    ComplianceReplayInput,
    ComplianceVerificationInput,
    ComposedProofProfile,
    DisclosureProof,
    DisclosureRule,
    InMemoryComplianceArtifactStore,
    LayerProof,
    ProofVerificationResult,
    ReplayDriftDiagnostic,
    SnapshotBundle,
)
from arelis.compliance.verification import (
    ComplianceVerifierOptions,
    ProofProvider,
    verify_compliance_artifact,
)

__all__ = [
    "COMPLIANCE_ARTIFACT_SCHEMA_V1",
    "COMPLIANCE_ARTIFACT_SCHEMA_V2",
    "COMPLIANCE_PROOF_SCHEMA_V2",
    "AuditReplayResultWithSnapshot",
    "AuditReplayStepOutput",
    "CausalGraphCommitment",
    "ComplianceArtifact",
    "ComplianceArtifactRequest",
    "ComplianceArtifactStore",
    "ComplianceConfig",
    "ComplianceLayerKind",
    "ComplianceProofRequest",
    "ComplianceReplayInput",
    "ComplianceVerificationInput",
    "ComplianceVerifierOptions",
    "ComposedProofProfile",
    "DisclosureProof",
    "DisclosureRule",
    "InMemoryComplianceArtifactStore",
    "LayerProof",
    "ProofProvider",
    "ProofVerificationResult",
    "ReplayDriftDiagnostic",
    "SnapshotBundle",
    "compute_drift_diagnostics",
    "replay_audit_run",
    "replay_causal_graph",
    "resolve_disclosure_rules",
    "verify_compliance_artifact",
]
