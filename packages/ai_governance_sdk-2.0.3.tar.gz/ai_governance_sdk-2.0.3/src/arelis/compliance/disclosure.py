"""Disclosure rule resolution for the Arelis AI SDK.

Ports ``resolveDisclosureRules`` from the TypeScript SDK's
``packages/sdk/src/compliance-internal.ts``.
"""

from __future__ import annotations

from arelis.audit.proof import DisclosureRule

__all__ = [
    "resolve_disclosure_rules",
]


def resolve_disclosure_rules(
    base_rules: list[DisclosureRule],
    allowed_rule_ids: list[str] | None = None,
) -> list[DisclosureRule]:
    """Filter base disclosure rules by an optional allowlist of rule IDs.

    If *allowed_rule_ids* is ``None`` or empty, all *base_rules* are returned.

    Args:
        base_rules: The full set of disclosure rules.
        allowed_rule_ids: Optional list of rule IDs to keep.

    Returns:
        The filtered (or unfiltered) list of disclosure rules.
    """
    if not allowed_rule_ids:
        return base_rules

    allowed = set(allowed_rule_ids)
    return [rule for rule in base_rules if rule.id in allowed]
