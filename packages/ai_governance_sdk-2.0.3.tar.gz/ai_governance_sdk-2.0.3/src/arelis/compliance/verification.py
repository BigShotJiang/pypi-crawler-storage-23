"""Compliance artifact verification for the Arelis AI SDK.

Ports ``packages/sdk/src/compliance.ts`` from the TypeScript SDK.
Provides :func:`verify_compliance_artifact` for verifying compliance proofs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from arelis.compliance.types import (
    COMPLIANCE_ARTIFACT_SCHEMA_V2,
    COMPLIANCE_PROOF_SCHEMA_V2,
    ComplianceArtifact,
    DisclosureRule,
    ProofVerificationResult,
)

__all__ = [
    "ComplianceVerifierOptions",
    "ProofProvider",
    "verify_compliance_artifact",
]


# ---------------------------------------------------------------------------
# ProofProvider protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ProofProvider(Protocol):
    """Protocol for proof verification providers."""

    async def verify_proof(
        self,
        *,
        commitment: object,
        proof: object,
        disclosure_rules: list[DisclosureRule],
        policy_snapshot_hash: str | None = None,
        expect_composed: bool = False,
    ) -> ProofVerificationResult:
        """Verify a compliance proof."""
        ...


# ---------------------------------------------------------------------------
# ComplianceVerifierOptions
# ---------------------------------------------------------------------------


@dataclass
class ComplianceVerifierOptions:
    """Options for verifying a compliance artifact.

    Attributes:
        provider: Custom proof verification provider.
        disclosure_rules: Disclosure rules used for verification.
        policy_snapshot_hash: Expected policy snapshot hash.
    """

    provider: ProofProvider | None = None
    disclosure_rules: list[DisclosureRule] | None = None
    policy_snapshot_hash: str | None = None


# ---------------------------------------------------------------------------
# verify_compliance_artifact
# ---------------------------------------------------------------------------


async def verify_compliance_artifact(
    artifact: ComplianceArtifact,
    options: ComplianceVerifierOptions | None = None,
) -> ProofVerificationResult:
    """Verify a compliance artifact using the configured proof provider.

    If no provider is given in options, a default hash-based provider is used
    that validates the proof structure and returns a basic result.

    Args:
        artifact: The compliance artifact to verify.
        options: Optional verification options.

    Returns:
        The proof verification result indicating validity.
    """
    opts = options or ComplianceVerifierOptions()
    provider = opts.provider

    if provider is None:
        # Default hash-based verification: check structural integrity
        return _default_verify(artifact, opts)

    expect_composed = (
        artifact.artifact_schema == COMPLIANCE_ARTIFACT_SCHEMA_V2
        or artifact.proof.schema_version == COMPLIANCE_PROOF_SCHEMA_V2
    )

    return await provider.verify_proof(
        commitment=artifact.commitment,
        proof=artifact.proof,
        disclosure_rules=opts.disclosure_rules or [],
        policy_snapshot_hash=(opts.policy_snapshot_hash or artifact.policy_snapshot_hash),
        expect_composed=expect_composed,
    )


def _default_verify(
    artifact: ComplianceArtifact,
    options: ComplianceVerifierOptions,
) -> ProofVerificationResult:
    """Default hash-based verification.

    Checks that the artifact has a valid commitment and proof structure.
    """
    if not artifact.commitment or not artifact.commitment.root:
        return ProofVerificationResult(
            valid=False,
            reason="Missing commitment root",
            reason_code="missing_commitment_root",
        )

    if not artifact.proof or not artifact.proof.commitment_root:
        return ProofVerificationResult(
            valid=False,
            reason="Missing proof commitment root",
            reason_code="missing_proof_commitment_root",
        )

    # Check policy snapshot hash if provided
    expected_hash = options.policy_snapshot_hash or artifact.policy_snapshot_hash
    if (
        expected_hash
        and artifact.policy_snapshot_hash
        and expected_hash != artifact.policy_snapshot_hash
    ):
        return ProofVerificationResult(
            valid=False,
            reason="Policy snapshot hash mismatch",
            reason_code="snapshot_mismatch",
        )

    return ProofVerificationResult(valid=True)
