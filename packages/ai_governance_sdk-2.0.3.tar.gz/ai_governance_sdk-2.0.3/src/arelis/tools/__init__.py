"""Tools module for the Arelis AI SDK.

Provides tool registration, validation, permission checking, and invocation.
Ports functionality from the TypeScript SDK's ``packages/tools/src/``.
"""

from __future__ import annotations

from arelis.tools.registry import (
    ToolRegistry,
    create_tool_registry,
    validate_arguments,
)
from arelis.tools.types import (
    DiscoveredTool,
    JsonSchema,
    JsonSchemaProperty,
    PermissionCheckResult,
    ToolContext,
    ToolDefinition,
    ToolErrorInfo,
    ToolHandler,
    ToolInvokeOptions,
    ToolPermissions,
    ToolPermissionScope,
    ToolRegistryOptions,
    ToolResult,
    ToolRunnerOptions,
    ToolValidationError,
    ValidationResult,
)

__all__ = [
    "DiscoveredTool",
    "JsonSchema",
    "JsonSchemaProperty",
    "PermissionCheckResult",
    "ToolContext",
    "ToolDefinition",
    "ToolErrorInfo",
    "ToolHandler",
    "ToolInvokeOptions",
    "ToolPermissionScope",
    "ToolPermissions",
    "ToolRegistry",
    "ToolRegistryOptions",
    "ToolResult",
    "ToolRunnerOptions",
    "ToolValidationError",
    "ValidationResult",
    "create_tool_registry",
    "validate_arguments",
]
