"""Tool types for the Arelis AI SDK.

Ports types from the TypeScript SDK's ``packages/tools/src/types.ts``:
ToolDefinition, ToolHandler, ToolResult, ToolPermissions, ToolContext,
and related configuration types.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import (
    Literal,
)

from arelis.core.types import GovernanceContext

__all__ = [
    "DiscoveredTool",
    "JsonSchema",
    "JsonSchemaProperty",
    "PermissionCheckResult",
    "ToolContext",
    "ToolDefinition",
    "ToolErrorInfo",
    "ToolHandler",
    "ToolInvokeOptions",
    "ToolPermissionScope",
    "ToolPermissions",
    "ToolRegistryOptions",
    "ToolResult",
    "ToolRunnerOptions",
    "ToolValidationError",
    "ValidationResult",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

ToolPermissionScope = Literal[
    "read",
    "write",
    "execute",
    "network",
    "filesystem",
    "database",
    "admin",
]
"""Permission scope for a tool."""

# ---------------------------------------------------------------------------
# JSON Schema types
# ---------------------------------------------------------------------------


@dataclass
class JsonSchemaProperty:
    """JSON Schema property definition for tool argument validation."""

    type: Literal["string", "number", "boolean", "array", "object"]
    description: str | None = None
    enum: list[str] | None = None
    items: JsonSchemaProperty | None = None
    properties: dict[str, JsonSchemaProperty] | None = None
    required: list[str] | None = None
    minimum: float | None = None
    maximum: float | None = None
    min_length: int | None = None
    max_length: int | None = None
    pattern: str | None = None
    default: object | None = None


@dataclass
class JsonSchema:
    """JSON Schema definition for tool arguments."""

    type: Literal["object"] = "object"
    properties: dict[str, JsonSchemaProperty] | None = None
    required: list[str] | None = None
    additional_properties: bool | None = None


# ---------------------------------------------------------------------------
# Tool context
# ---------------------------------------------------------------------------


@dataclass
class ToolContext:
    """Context passed to tool handlers during execution."""

    run_id: str
    governance: GovernanceContext
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Tool handler type
# ---------------------------------------------------------------------------

ToolHandler = Callable[[dict[str, object], ToolContext], Awaitable[object]]
"""Tool handler function signature.

Takes arguments dict and a ToolContext, returns an awaitable result.
"""

# ---------------------------------------------------------------------------
# Tool permissions
# ---------------------------------------------------------------------------


@dataclass
class ToolPermissions:
    """Permission configuration for a tool."""

    scopes: list[ToolPermissionScope]
    allowed_actor_types: list[Literal["human", "service", "agent"]] | None = None
    allowed_environments: list[Literal["dev", "staging", "prod"]] | None = None
    allowed_purposes: list[str] | None = None
    allowed_roles: list[str] | None = None


# ---------------------------------------------------------------------------
# Tool definition
# ---------------------------------------------------------------------------


@dataclass
class ToolDefinition:
    """Complete tool definition including handler and metadata."""

    name: str
    description: str
    schema: JsonSchema
    permissions: ToolPermissions
    handler: ToolHandler
    timeout: int | None = None
    tags: list[str] | None = None


# ---------------------------------------------------------------------------
# Tool result
# ---------------------------------------------------------------------------


@dataclass
class ToolErrorInfo:
    """Error information for a failed tool execution."""

    type: str
    code: str
    message: str


@dataclass
class ToolResult:
    """Result of a tool execution."""

    success: bool
    duration_ms: int
    tool_name: str
    run_id: str
    data: object | None = None
    error: ToolErrorInfo | None = None


# ---------------------------------------------------------------------------
# Tool invocation options
# ---------------------------------------------------------------------------


@dataclass
class ToolInvokeOptions:
    """Options for tool invocation."""

    timeout: int | None = None
    skip_permission_check: bool = False
    skip_validation: bool = False
    skip_policy_check: bool = False


# ---------------------------------------------------------------------------
# Tool validation
# ---------------------------------------------------------------------------


@dataclass
class ToolValidationError:
    """Validation error for tool arguments."""

    path: str
    message: str
    expected: str | None = None
    actual: str | None = None


@dataclass
class ValidationResult:
    """Result of validating tool arguments against a JSON schema."""

    valid: bool
    errors: list[ToolValidationError] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Permission check result
# ---------------------------------------------------------------------------


@dataclass
class PermissionCheckResult:
    """Result of a permission check."""

    allowed: bool
    reason: str | None = None
    missing_scopes: list[ToolPermissionScope] | None = None


# ---------------------------------------------------------------------------
# Registry and runner options
# ---------------------------------------------------------------------------


@dataclass
class ToolRegistryOptions:
    """Options for the tool registry."""

    allow_overwrite: bool = False
    default_timeout: int = 30000


@dataclass
class ToolRunnerOptions:
    """Options for the tool runner."""

    data_ref_mode: Literal["inline", "hash"] = "hash"


# ---------------------------------------------------------------------------
# Discovered tool (used during MCP discovery)
# ---------------------------------------------------------------------------


@dataclass
class DiscoveredTool:
    """Information about a tool discovered from an MCP server."""

    name: str
    original_name: str
    server_id: str
    description: str | None = None
    registered: bool = False
    skip_reason: str | None = None
