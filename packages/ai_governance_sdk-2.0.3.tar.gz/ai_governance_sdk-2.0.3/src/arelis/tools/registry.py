"""Tool registry for the Arelis AI SDK.

Ports the ``ToolRegistry`` class from the TypeScript SDK's
``packages/tools/src/tool-registry.ts``.  Provides registration, lookup,
listing, and permission checking for tool definitions.

Also includes argument validation via ``jsonschema.validate()``.
"""

from __future__ import annotations

import asyncio
import builtins
import time

import jsonschema

from arelis.core.types import GovernanceContext
from arelis.tools.types import (
    JsonSchema,
    JsonSchemaProperty,
    PermissionCheckResult,
    ToolContext,
    ToolDefinition,
    ToolErrorInfo,
    ToolInvokeOptions,
    ToolPermissions,
    ToolPermissionScope,
    ToolRegistryOptions,
    ToolResult,
    ToolValidationError,
    ValidationResult,
)

__all__ = [
    "ToolRegistry",
    "create_tool_registry",
    "validate_arguments",
]


# ---------------------------------------------------------------------------
# Argument validation
# ---------------------------------------------------------------------------


def _json_schema_property_to_dict(prop: JsonSchemaProperty) -> dict[str, object]:
    """Convert a JsonSchemaProperty to a plain dict for jsonschema validation."""
    result: dict[str, object] = {"type": prop.type}

    if prop.description is not None:
        result["description"] = prop.description
    if prop.enum is not None:
        result["enum"] = prop.enum
    if prop.minimum is not None:
        result["minimum"] = prop.minimum
    if prop.maximum is not None:
        result["maximum"] = prop.maximum
    if prop.min_length is not None:
        result["minLength"] = prop.min_length
    if prop.max_length is not None:
        result["maxLength"] = prop.max_length
    if prop.pattern is not None:
        result["pattern"] = prop.pattern
    if prop.default is not None:
        result["default"] = prop.default
    if prop.items is not None:
        result["items"] = _json_schema_property_to_dict(prop.items)
    if prop.properties is not None:
        result["properties"] = {
            k: _json_schema_property_to_dict(v) for k, v in prop.properties.items()
        }
    if prop.required is not None:
        result["required"] = prop.required

    return result


def _json_schema_to_dict(schema: JsonSchema) -> dict[str, object]:
    """Convert a JsonSchema to a plain dict for jsonschema validation."""
    result: dict[str, object] = {"type": schema.type}

    if schema.properties is not None:
        result["properties"] = {
            k: _json_schema_property_to_dict(v) for k, v in schema.properties.items()
        }
    if schema.required is not None:
        result["required"] = schema.required
    if schema.additional_properties is not None:
        result["additionalProperties"] = schema.additional_properties

    return result


def validate_arguments(
    args: dict[str, object],
    schema: JsonSchema,
) -> ValidationResult:
    """Validate tool arguments against a JSON Schema.

    Uses ``jsonschema.validate()`` for schema validation and returns a
    :class:`ValidationResult` with structured errors.
    """
    errors: list[ToolValidationError] = []

    # Check if args is a dict
    if not isinstance(args, dict):
        errors.append(
            ToolValidationError(
                path="args",
                message="Arguments must be an object",
                expected="object",
                actual=type(args).__name__,
            )
        )
        return ValidationResult(valid=False, errors=errors)

    schema_dict = _json_schema_to_dict(schema)

    validator = jsonschema.Draft7Validator(schema_dict)
    for error in validator.iter_errors(args):
        path = "args"
        if error.absolute_path:
            path = "args." + ".".join(str(p) for p in error.absolute_path)

        errors.append(
            ToolValidationError(
                path=path,
                message=error.message,
            )
        )

    return ValidationResult(valid=len(errors) == 0, errors=errors)


# ---------------------------------------------------------------------------
# ToolRegistry
# ---------------------------------------------------------------------------


class ToolRegistry:
    """Registry for managing tool definitions.

    Provides registration, lookup, listing, permission checking, and
    invocation of tools.
    """

    def __init__(self, options: ToolRegistryOptions | None = None) -> None:
        opts = options or ToolRegistryOptions()
        self._allow_overwrite: bool = opts.allow_overwrite
        self._default_timeout: int = opts.default_timeout
        self._tools: dict[str, ToolDefinition] = {}

    # -- Registration -------------------------------------------------------

    def register(self, tool: ToolDefinition) -> None:
        """Register a tool definition.

        Raises
        ------
        ValueError
            If validation fails or the tool is already registered and
            overwriting is disabled.
        """
        if not tool.name or not isinstance(tool.name, str):
            raise ValueError("Tool name is required and must be a string")

        if not tool.description or not isinstance(tool.description, str):
            raise ValueError("Tool description is required and must be a string")

        if not tool.schema or tool.schema.type != "object":
            raise ValueError('Tool schema is required and must have type "object"')

        if not tool.permissions or not isinstance(tool.permissions.scopes, list):
            raise ValueError("Tool permissions with scopes list is required")

        if not callable(tool.handler):
            raise ValueError("Tool handler must be a callable")

        if tool.name in self._tools and not self._allow_overwrite:
            raise ValueError(f'Tool "{tool.name}" is already registered')

        # Apply default timeout if not specified
        effective_timeout = tool.timeout if tool.timeout is not None else self._default_timeout
        registered_tool = ToolDefinition(
            name=tool.name,
            description=tool.description,
            schema=tool.schema,
            permissions=tool.permissions,
            handler=tool.handler,
            timeout=effective_timeout,
            tags=tool.tags,
        )
        self._tools[tool.name] = registered_tool

    # -- Lookup -------------------------------------------------------------

    def get(self, name: str) -> ToolDefinition | None:
        """Get a tool definition by name."""
        return self._tools.get(name)

    def has(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tools

    # -- Listing ------------------------------------------------------------

    def list(self) -> builtins.list[ToolDefinition]:
        """List all registered tool definitions."""
        return [*self._tools.values()]

    def list_names(self) -> builtins.list[str]:
        """List all registered tool names."""
        return [*self._tools.keys()]

    def list_by_tag(self, tag: str) -> builtins.list[ToolDefinition]:
        """List tools that have the given tag."""
        return [t for t in self._tools.values() if t.tags and tag in t.tags]

    # -- Unregistration -----------------------------------------------------

    def unregister(self, name: str) -> bool:
        """Unregister a tool. Returns ``True`` if the tool was found and removed."""
        if name in self._tools:
            del self._tools[name]
            return True
        return False

    def clear(self) -> None:
        """Remove all registered tools."""
        self._tools.clear()

    # -- Size ---------------------------------------------------------------

    @property
    def size(self) -> int:
        """Number of registered tools."""
        return len(self._tools)

    # -- Permission checks --------------------------------------------------

    def has_permission(
        self,
        tool_name: str,
        context: GovernanceContext,
        required_scopes: builtins.list[ToolPermissionScope] | None = None,
    ) -> PermissionCheckResult:
        """Check if a governance context has permission to use a tool."""
        tool = self._tools.get(tool_name)
        if not tool:
            return PermissionCheckResult(
                allowed=False,
                reason=f'Tool "{tool_name}" not found',
            )

        return self.check_permissions(tool.permissions, context, required_scopes)

    def check_permissions(
        self,
        permissions: ToolPermissions,
        context: GovernanceContext,
        required_scopes: builtins.list[ToolPermissionScope] | None = None,
    ) -> PermissionCheckResult:
        """Check permissions against a governance context."""
        # Check actor type
        if (
            permissions.allowed_actor_types is not None
            and context.actor.type not in permissions.allowed_actor_types
        ):
            return PermissionCheckResult(
                allowed=False,
                reason=f'Actor type "{context.actor.type}" is not allowed',
            )

        # Check environment
        if (
            permissions.allowed_environments is not None
            and context.environment not in permissions.allowed_environments
        ):
            return PermissionCheckResult(
                allowed=False,
                reason=f'Environment "{context.environment}" is not allowed',
            )

        # Check purpose
        if (
            permissions.allowed_purposes is not None
            and context.purpose not in permissions.allowed_purposes
        ):
            return PermissionCheckResult(
                allowed=False,
                reason=f'Purpose "{context.purpose}" is not allowed',
            )

        # Check roles
        if permissions.allowed_roles and len(permissions.allowed_roles) > 0:
            actor_roles = context.actor.roles or []
            has_required_role = any(role in actor_roles for role in permissions.allowed_roles)
            if not has_required_role:
                return PermissionCheckResult(
                    allowed=False,
                    reason=(
                        f"Actor does not have required roles: "
                        f"{', '.join(permissions.allowed_roles)}"
                    ),
                )

        # Check required scopes
        if required_scopes and len(required_scopes) > 0:
            missing = [s for s in required_scopes if s not in permissions.scopes]
            if missing:
                return PermissionCheckResult(
                    allowed=False,
                    reason=f"Missing required scopes: {', '.join(missing)}",
                    missing_scopes=missing,
                )

        return PermissionCheckResult(allowed=True)

    # -- Invocation ---------------------------------------------------------

    async def invoke(
        self,
        tool_name: str,
        args: dict[str, object],
        context: ToolContext,
        options: ToolInvokeOptions | None = None,
    ) -> ToolResult:
        """Invoke a tool by name with validation and permission checks.

        Parameters
        ----------
        tool_name:
            The registered name of the tool.
        args:
            The arguments to pass to the tool handler.
        context:
            The tool execution context.
        options:
            Optional invocation options.

        Returns
        -------
        ToolResult
            The result of the tool execution.
        """
        opts = options or ToolInvokeOptions()
        start_ms = int(time.monotonic() * 1000)

        # Get tool definition
        tool = self._tools.get(tool_name)
        if not tool:
            return ToolResult(
                success=False,
                error=ToolErrorInfo(
                    type="ToolNotFoundError",
                    code="TOOL_NOT_FOUND",
                    message=f'Tool "{tool_name}" not found',
                ),
                duration_ms=int(time.monotonic() * 1000) - start_ms,
                tool_name=tool_name,
                run_id=context.run_id,
            )

        # Check permissions
        if not opts.skip_permission_check:
            perm_result = self.has_permission(tool_name, context.governance)
            if not perm_result.allowed:
                return ToolResult(
                    success=False,
                    error=ToolErrorInfo(
                        type="PermissionDeniedError",
                        code="PERMISSION_DENIED",
                        message=perm_result.reason or "Permission denied",
                    ),
                    duration_ms=int(time.monotonic() * 1000) - start_ms,
                    tool_name=tool_name,
                    run_id=context.run_id,
                )

        # Validate arguments
        if not opts.skip_validation:
            validation = validate_arguments(args, tool.schema)
            if not validation.valid:
                error_msg = "; ".join(f"{e.path}: {e.message}" for e in validation.errors)
                return ToolResult(
                    success=False,
                    error=ToolErrorInfo(
                        type="ValidationError",
                        code="VALIDATION_FAILED",
                        message=error_msg,
                    ),
                    duration_ms=int(time.monotonic() * 1000) - start_ms,
                    tool_name=tool_name,
                    run_id=context.run_id,
                )

        # Execute handler with timeout
        timeout_ms = opts.timeout or tool.timeout or self._default_timeout
        timeout_s = timeout_ms / 1000.0

        try:
            result = await asyncio.wait_for(
                tool.handler(args, context),
                timeout=timeout_s,
            )
            return ToolResult(
                success=True,
                data=result,
                duration_ms=int(time.monotonic() * 1000) - start_ms,
                tool_name=tool_name,
                run_id=context.run_id,
            )
        except asyncio.TimeoutError:
            return ToolResult(
                success=False,
                error=ToolErrorInfo(
                    type="TimeoutError",
                    code="TIMEOUT",
                    message=f"Tool execution timed out after {timeout_ms}ms",
                ),
                duration_ms=int(time.monotonic() * 1000) - start_ms,
                tool_name=tool_name,
                run_id=context.run_id,
            )
        except Exception as exc:
            error_message = str(exc)
            error_type = type(exc).__name__

            return ToolResult(
                success=False,
                error=ToolErrorInfo(
                    type=error_type,
                    code="EXECUTION_ERROR",
                    message=error_message,
                ),
                duration_ms=int(time.monotonic() * 1000) - start_ms,
                tool_name=tool_name,
                run_id=context.run_id,
            )


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def create_tool_registry(options: ToolRegistryOptions | None = None) -> ToolRegistry:
    """Create a new tool registry."""
    return ToolRegistry(options)
