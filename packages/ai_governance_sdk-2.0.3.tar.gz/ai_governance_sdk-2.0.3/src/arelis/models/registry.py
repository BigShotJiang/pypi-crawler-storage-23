"""Model registry for provider and route management.

Ports the TypeScript SDK's `packages/models/src/model-registry.ts`.
"""

from __future__ import annotations

import builtins
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.core.types import GovernanceContext
from arelis.models.provider import ModelProvider
from arelis.models.routing import is_descriptor_allowed
from arelis.models.types import (
    DataClass,
    DataResidency,
    ModelDescriptor,
    ModelRoute,
)

__all__ = [
    "ModelRegistry",
    "ProviderMetadata",
    "RegisterOptions",
    "ResolveOptions",
    "ProviderNotFoundError",
    "ProviderAlreadyRegisteredError",
    "ModelNotSupportedError",
    "RouteResolution",
    "create_model_registry",
    "get_default_registry",
    "reset_default_registry",
]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ProviderNotFoundError(Exception):
    """Raised when a provider is not found in the registry."""

    def __init__(self, provider_id: str, available_providers: list[str]) -> None:
        self.provider_id = provider_id
        self.available_providers = available_providers
        available = ", ".join(available_providers) if available_providers else "none"
        super().__init__(
            f'Model provider "{provider_id}" not found. Available providers: {available}'
        )


class ProviderAlreadyRegisteredError(Exception):
    """Raised when a provider with the same ID is already registered."""

    def __init__(self, provider_id: str) -> None:
        self.provider_id = provider_id
        super().__init__(f'Model provider "{provider_id}" is already registered')


class ModelNotSupportedError(Exception):
    """Raised when no provider supports the requested model."""

    def __init__(self, model: str, available_models: list[str]) -> None:
        self.model = model
        self.available_models = available_models
        available = ", ".join(available_models) if available_models else "none"
        super().__init__(f'No provider found for model "{model}". Available models: {available}')


# ---------------------------------------------------------------------------
# Helper dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ProviderMetadata:
    """Metadata stored alongside each registered provider."""

    provider: ModelProvider
    registered_at: datetime
    priority: int = 0
    enabled: bool = True


@dataclass
class RegisterOptions:
    """Options for registering a provider."""

    priority: int = 0
    enabled: bool = True
    replace: bool = False


@dataclass
class ResolveOptions:
    """Options for resolving a provider."""

    enabled_only: bool = True


@dataclass
class RouteResolution:
    """Result of resolving a route or model ID."""

    descriptor: ModelDescriptor
    route_id: str | None = None
    fallback_used: bool | None = None


# ---------------------------------------------------------------------------
# ModelRegistry
# ---------------------------------------------------------------------------


class ModelRegistry:
    """Registry for model providers, descriptors, and routes.

    Maintains three internal stores:
    - providers: ``ModelProvider`` instances keyed by provider ID.
    - model_descriptors: ``ModelDescriptor`` instances keyed by model ID.
    - routes: ``ModelRoute`` instances keyed by route ID.
    """

    def __init__(self) -> None:
        self._providers: dict[str, ProviderMetadata] = {}
        self._model_descriptors: dict[str, ModelDescriptor] = {}
        self._routes: dict[str, ModelRoute] = {}

    # -- Provider management ------------------------------------------------

    def register(
        self,
        provider: ModelProvider,
        options: RegisterOptions | None = None,
    ) -> None:
        """Register a model provider.

        Raises:
            ProviderAlreadyRegisteredError: If the provider ID is already
                registered and ``options.replace`` is ``False``.
        """
        opts = options or RegisterOptions()

        if provider.id in self._providers and not opts.replace:
            raise ProviderAlreadyRegisteredError(provider.id)

        self._providers[provider.id] = ProviderMetadata(
            provider=provider,
            registered_at=datetime.now(timezone.utc),
            priority=opts.priority,
            enabled=opts.enabled,
        )

    def unregister(self, provider_id: str) -> bool:
        """Unregister a model provider. Returns ``True`` if it existed."""
        return self._providers.pop(provider_id, None) is not None

    def resolve(
        self,
        provider_id: str,
        options: ResolveOptions | None = None,
    ) -> ModelProvider:
        """Resolve a provider by ID.

        Raises:
            ProviderNotFoundError: If the provider is not found or is
                disabled when ``enabled_only`` is ``True``.
        """
        opts = options or ResolveOptions()
        metadata = self._providers.get(provider_id)

        if metadata is None:
            raise ProviderNotFoundError(provider_id, self.list_provider_ids())

        if opts.enabled_only and not metadata.enabled:
            raise ProviderNotFoundError(
                provider_id,
                self.list_provider_ids(ResolveOptions(enabled_only=True)),
            )

        return metadata.provider

    def resolve_for_model(
        self,
        model: str,
        options: ResolveOptions | None = None,
    ) -> ModelProvider:
        """Resolve the highest-priority provider that supports *model*.

        Raises:
            ModelNotSupportedError: If no registered provider supports the
                model.
        """
        opts = options or ResolveOptions()
        sorted_providers = sorted(
            (m for m in self._providers.values() if not opts.enabled_only or m.enabled),
            key=lambda m: m.priority,
            reverse=True,
        )

        for metadata in sorted_providers:
            if metadata.provider.supports_model(model):
                return metadata.provider

        all_models = self.list_supported_models(opts)
        raise ModelNotSupportedError(model, all_models)

    def has(self, provider_id: str) -> bool:
        """Check if a provider is registered."""
        return provider_id in self._providers

    def get_metadata(self, provider_id: str) -> ProviderMetadata | None:
        """Get provider metadata."""
        return self._providers.get(provider_id)

    def set_enabled(self, provider_id: str, enabled: bool) -> bool:
        """Enable or disable a provider. Returns ``True`` if found."""
        metadata = self._providers.get(provider_id)
        if metadata is not None:
            metadata.enabled = enabled
            return True
        return False

    def set_priority(self, provider_id: str, priority: int) -> bool:
        """Update provider priority. Returns ``True`` if found."""
        metadata = self._providers.get(provider_id)
        if metadata is not None:
            metadata.priority = priority
            return True
        return False

    def list_provider_ids(
        self,
        options: ResolveOptions | None = None,
    ) -> builtins.list[str]:
        """List all registered provider IDs."""
        opts = options or ResolveOptions(enabled_only=False)
        return [pid for pid, m in self._providers.items() if not opts.enabled_only or m.enabled]

    def list(
        self,
        options: ResolveOptions | None = None,
    ) -> builtins.list[ModelProvider]:
        """List all registered providers, sorted by priority (highest first)."""
        opts = options or ResolveOptions(enabled_only=False)
        sorted_meta = sorted(
            (m for m in self._providers.values() if not opts.enabled_only or m.enabled),
            key=lambda m: m.priority,
            reverse=True,
        )
        return [m.provider for m in sorted_meta]

    def list_supported_models(
        self,
        options: ResolveOptions | None = None,
    ) -> builtins.list[str]:
        """List all supported models across all providers."""
        opts = options or ResolveOptions(enabled_only=False)
        models: set[str] = set()
        for metadata in self._providers.values():
            if not opts.enabled_only or metadata.enabled:
                for model in metadata.provider.supported_models:
                    models.add(model)
        return sorted(models)

    # -- Model descriptor management ----------------------------------------

    def register_model(
        self,
        descriptor: ModelDescriptor,
        *,
        replace: bool = False,
    ) -> None:
        """Register a model descriptor.

        Raises:
            ValueError: If the descriptor ID is already registered and
                *replace* is ``False``.
        """
        if descriptor.id in self._model_descriptors and not replace:
            raise ValueError(f'Model descriptor "{descriptor.id}" is already registered')
        self._model_descriptors[descriptor.id] = descriptor

    def get_model(self, model_id: str) -> ModelDescriptor | None:
        """Get a model descriptor by ID."""
        return self._model_descriptors.get(model_id)

    # -- Route management ---------------------------------------------------

    def register_route(
        self,
        route: ModelRoute,
        *,
        replace: bool = False,
    ) -> None:
        """Register a model route.

        Raises:
            ValueError: If the route ID is already registered and *replace*
                is ``False``.
        """
        if route.id in self._routes and not replace:
            raise ValueError(f'Model route "{route.id}" is already registered')
        self._routes[route.id] = route

    def get_route(self, route_id: str) -> ModelRoute | None:
        """Get a model route by ID."""
        return self._routes.get(route_id)

    # -- Combined resolution ------------------------------------------------

    def resolve_route_or_model(
        self,
        route_or_model_id: str,
        context: GovernanceContext,
        data_class: DataClass | None = None,
        required_residency: DataResidency | None = None,
    ) -> RouteResolution:
        """Resolve a route or model ID using governance context.

        If *route_or_model_id* matches a registered route, candidates are
        evaluated in weight-descending order.  The first candidate whose
        descriptor passes governance checks is returned.

        If no route matches, the ID is treated as a direct model identifier.

        Raises:
            ModelNotSupportedError: If a route exists but no candidate is
                allowed.
            ValueError: If a direct model ID is not allowed.
        """
        route = self._routes.get(route_or_model_id)
        if route is not None:
            sorted_candidates = sorted(
                route.candidates,
                key=lambda c: c.weight if c.weight is not None else 0,
                reverse=True,
            )
            for i, candidate in enumerate(sorted_candidates):
                descriptor = self._get_or_create_descriptor(candidate.model_id)
                if not is_descriptor_allowed(
                    descriptor,
                    context.purpose,
                    data_class,
                    required_residency,
                    candidate,
                ):
                    continue
                fallback_used = i > 0
                return RouteResolution(
                    descriptor=descriptor,
                    route_id=route.id,
                    fallback_used=fallback_used,
                )
            raise ModelNotSupportedError(
                route_or_model_id,
                [c.model_id for c in route.candidates],
            )

        descriptor = self._get_or_create_descriptor(route_or_model_id)
        if not is_descriptor_allowed(descriptor, context.purpose, data_class, required_residency):
            raise ValueError(f'Model "{descriptor.id}" is not allowed for purpose or data class')
        return RouteResolution(descriptor=descriptor)

    # -- Housekeeping -------------------------------------------------------

    def clear(self) -> None:
        """Clear all registered providers, descriptors, and routes."""
        self._providers.clear()
        self._model_descriptors.clear()
        self._routes.clear()

    @property
    def size(self) -> int:
        """Number of registered providers."""
        return len(self._providers)

    # -- Private helpers ----------------------------------------------------

    def _get_or_create_descriptor(self, model_id: str) -> ModelDescriptor:
        """Return a descriptor for *model_id*, auto-creating one if needed."""
        existing = self._model_descriptors.get(model_id)
        if existing is not None:
            return existing

        provider = self.resolve_for_model(model_id)
        descriptor = ModelDescriptor(
            id=model_id,
            provider_id=provider.id,
            lifecycle_state="approved",
        )
        self._model_descriptors[model_id] = descriptor
        return descriptor


# ---------------------------------------------------------------------------
# Factory and default registry
# ---------------------------------------------------------------------------

_default_registry: ModelRegistry | None = None


def create_model_registry() -> ModelRegistry:
    """Create a new model registry."""
    return ModelRegistry()


def get_default_registry() -> ModelRegistry:
    """Get the default global model registry (created on first access)."""
    global _default_registry
    if _default_registry is None:
        _default_registry = create_model_registry()
    return _default_registry


def reset_default_registry() -> None:
    """Reset the default global registry (mainly for testing)."""
    global _default_registry
    _default_registry = None
