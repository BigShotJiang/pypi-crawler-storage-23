"""Model capabilities and descriptors.

Provides the ``ModelCapability`` literal type and re-exports
``ModelDescriptor`` from ``types`` for convenience.
"""

from __future__ import annotations

from typing import Literal

from arelis.models.types import ModelDescriptor

__all__ = [
    "ModelCapability",
    "ModelDescriptor",
]

ModelCapability = Literal[
    "text_generation",
    "streaming",
    "tool_use",
    "token_estimation",
    "image_generation",
    "audio_generation",
    "video_generation",
    "image_to_text",
    "image_to_audio",
    "image_to_video",
    "audio_to_text",
    "audio_to_image",
    "audio_to_video",
    "video_to_text",
    "video_to_image",
    "video_to_audio",
]
"""Capabilities that a model provider can support."""
