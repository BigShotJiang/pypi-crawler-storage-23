"""Model routing utilities.

Ports route-matching logic from the TypeScript SDK's
`packages/models/src/model-registry.ts` (the ``resolveRouteOrModel`` helper
and associated data-class ranking).
"""

from __future__ import annotations

from arelis.models.types import DataClass, DataResidency, ModelDescriptor, ModelRouteCandidate

__all__ = [
    "DATA_CLASS_RANK",
    "data_class_allowed",
    "is_descriptor_allowed",
]

# ---------------------------------------------------------------------------
# Data class ranking (lower = less sensitive)
# ---------------------------------------------------------------------------

DATA_CLASS_RANK: dict[DataClass, int] = {
    "public": 0,
    "internal": 1,
    "confidential": 2,
    "restricted": 3,
}
"""Numeric sensitivity rank for each ``DataClass`` level."""


def data_class_allowed(
    input_class: DataClass | None,
    max_allowed: DataClass | None,
) -> bool:
    """Return ``True`` if *input_class* does not exceed *max_allowed*.

    If either value is ``None`` the check is skipped (permissive).
    """
    if input_class is None or max_allowed is None:
        return True
    return DATA_CLASS_RANK[input_class] <= DATA_CLASS_RANK[max_allowed]


def is_descriptor_allowed(
    descriptor: ModelDescriptor,
    purpose: str,
    data_class: DataClass | None = None,
    required_residency: DataResidency | None = None,
    candidate: ModelRouteCandidate | None = None,
) -> bool:
    """Check whether a model descriptor is allowed given governance constraints.

    Parameters
    ----------
    descriptor:
        The model descriptor to evaluate.
    purpose:
        The governance purpose string (from ``GovernanceContext.purpose``).
    data_class:
        The data classification of the current request (optional).
    required_residency:
        The residency requirement of the current request (optional).
    candidate:
        An optional route candidate whose overrides take precedence over
        the descriptor's own ``max_data_class`` and ``required_residency``.

    Returns
    -------
    bool
        ``True`` if the model is allowed, ``False`` otherwise.
    """
    if descriptor.lifecycle_state == "disabled":
        return False

    if descriptor.allowed_purposes is not None and purpose not in descriptor.allowed_purposes:
        return False

    max_class = (
        candidate.max_data_class if candidate is not None else None
    ) or descriptor.max_data_class
    if not data_class_allowed(data_class, max_class):
        return False

    residency = (
        candidate.required_residency if candidate is not None else None
    ) or descriptor.required_residency
    return not (required_residency and residency and residency != required_residency)
