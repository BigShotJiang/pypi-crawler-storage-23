"""Model types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/models/src/types.ts` and
relevant generate input types from `packages/sdk/src/client.ts`.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

from arelis.core.types import GovernanceContext, UsageInfo

__all__ = [
    # Message types
    "MessageRole",
    "TextContentPart",
    "ImageContentPart",
    "ToolUseContentPart",
    "ToolResultContentPart",
    "ContentPart",
    "ModelMessage",
    # Config
    "ModelConfig",
    # Tool definitions
    "ToolDefinition",
    "ToolCall",
    # Request / Response
    "ModelRequest",
    "FinishReason",
    "ModelUsage",
    "ModelResponse",
    "StreamChunk",
    "ToolCallDelta",
    # Generation options
    "GenerateOptions",
    # Media types
    "MediaModality",
    "BinaryMediaInput",
    "Base64MediaInput",
    "MediaInput",
    "ImageInput",
    "AudioInput",
    "VideoInput",
    "MediaGenerationOptions",
    "MediaTransformOptions",
    "MediaToTextOptions",
    "ImageGenerationOptions",
    "AudioGenerationOptions",
    "VideoGenerationOptions",
    "ImageToTextOptions",
    "AudioToTextOptions",
    "VideoToTextOptions",
    "ImageToAudioOptions",
    "ImageToVideoOptions",
    "AudioToImageOptions",
    "AudioToVideoOptions",
    "VideoToImageOptions",
    "VideoToAudioOptions",
    "MediaResponseBase",
    "TextResponseBase",
    "ImageGenerationResponse",
    "AudioGenerationResponse",
    "VideoGenerationResponse",
    "TextFromImageResponse",
    "TextFromAudioResponse",
    "TextFromVideoResponse",
    "AudioFromImageResponse",
    "AudioFromVideoResponse",
    "ImageFromAudioResponse",
    "ImageFromVideoResponse",
    "VideoFromImageResponse",
    "VideoFromAudioResponse",
    # Model descriptors and routing
    "ModelLifecycleState",
    "DataClass",
    "DataResidency",
    "ModelDescriptor",
    "ModelRouteCandidate",
    "ModelRoute",
    # High-level generate inputs
    "OutputSchema",
    "JsonSchemaOutput",
    "ValidatorOutput",
    "OutputValidationMode",
    "GroundingInput",
    "GroundingOptions",
    "PromptTemplateRef",
    "GenerateInput",
    "GenerateStreamResult",
    "StreamOptions",
    "GenerateStreamInput",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

MessageRole = Literal["system", "user", "assistant", "tool"]
"""Role of a message in the conversation."""

FinishReason = Literal["stop", "length", "tool_use", "content_filter", "error"]
"""Reason the model stopped generating."""

MediaModality = Literal["text", "image", "audio", "video"]
"""Supported media modalities."""

ModelLifecycleState = Literal["experimental", "approved", "restricted", "deprecated", "disabled"]
"""Lifecycle state of a registered model."""

DataClass = Literal["public", "internal", "confidential", "restricted"]
"""Data classification level."""

DataResidency = Literal["EU", "US", "APAC"]
"""Data residency requirement."""

OutputValidationMode = Literal["warn", "block"]
"""How output schema validation failures are handled."""

# ---------------------------------------------------------------------------
# Content parts (multimodal messages)
# ---------------------------------------------------------------------------


@dataclass
class TextContentPart:
    """Text content part."""

    text: str
    type: Literal["text"] = "text"


@dataclass
class ImageContentPart:
    """Image content part."""

    data: str
    mime_type: str
    type: Literal["image"] = "image"


@dataclass
class ToolUseContentPart:
    """Tool use content part (model requesting a tool call)."""

    id: str
    name: str
    input: dict[str, object]
    type: Literal["tool_use"] = "tool_use"


@dataclass
class ToolResultContentPart:
    """Tool result content part (result of a tool call)."""

    id: str
    content: str
    is_error: bool | None = None
    type: Literal["tool_result"] = "tool_result"


ContentPart = TextContentPart | ImageContentPart | ToolUseContentPart | ToolResultContentPart
"""A single content part in a multimodal message."""

# ---------------------------------------------------------------------------
# ModelMessage
# ---------------------------------------------------------------------------


@dataclass
class ModelMessage:
    """A message in the conversation."""

    role: MessageRole
    content: str | list[ContentPart]
    name: str | None = None


# ---------------------------------------------------------------------------
# ModelConfig
# ---------------------------------------------------------------------------


@dataclass
class ModelConfig:
    """Configuration options for model generation."""

    max_tokens: int | None = None
    temperature: float | None = None
    top_p: float | None = None
    stop: list[str] | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    seed: int | None = None
    provider_options: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Tool definitions and calls
# ---------------------------------------------------------------------------


@dataclass
class ToolDefinition:
    """Tool definition for function calling."""

    name: str
    description: str
    parameters: dict[str, object]


@dataclass
class ToolCall:
    """Tool call in the response."""

    id: str
    name: str
    arguments: dict[str, object]


@dataclass
class ToolCallDelta:
    """Partial tool call delta for streaming."""

    index: int
    id: str | None = None
    name: str | None = None
    arguments: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# ModelRequest
# ---------------------------------------------------------------------------


@dataclass
class ModelRequest:
    """Request to a model provider."""

    model: str
    messages: list[ModelMessage]
    system_prompt: str | None = None
    config: ModelConfig | None = None
    tools: list[ToolDefinition] | None = None
    context: GovernanceContext | None = None
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# ModelUsage
# ---------------------------------------------------------------------------


@dataclass
class ModelUsage(UsageInfo):
    """Token usage information for model calls.

    Extends ``UsageInfo`` with provider-specific token counts.
    """

    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    cached_tokens: int | None = None


# ---------------------------------------------------------------------------
# ModelResponse
# ---------------------------------------------------------------------------


@dataclass
class ModelResponse:
    """Response from a model provider."""

    id: str
    model: str
    content: str | list[ContentPart]
    finish_reason: FinishReason
    usage: ModelUsage
    created_at: datetime
    tool_calls: list[ToolCall] | None = None
    provider_metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# StreamChunk
# ---------------------------------------------------------------------------

StreamChunkType = Literal["content", "tool_call", "usage", "done"]


@dataclass
class StreamChunk:
    """Streaming chunk from model generation."""

    type: StreamChunkType
    content: str | None = None
    tool_call: ToolCallDelta | None = None
    usage: ModelUsage | None = None
    finish_reason: FinishReason | None = None


# ---------------------------------------------------------------------------
# GenerateOptions
# ---------------------------------------------------------------------------


@dataclass
class GenerateOptions:
    """Options for model generation."""

    timeout: int | None = None
    stream: bool | None = None
    max_tokens: int | None = None


# ---------------------------------------------------------------------------
# Media types
# ---------------------------------------------------------------------------


@dataclass
class BinaryMediaInput:
    """Binary media input."""

    data: bytes
    mime_type: str


@dataclass
class Base64MediaInput:
    """Base64-encoded media input."""

    base64: str
    mime_type: str


MediaInput = BinaryMediaInput | Base64MediaInput
ImageInput = MediaInput
AudioInput = MediaInput
VideoInput = MediaInput


@dataclass
class MediaGenerationOptions:
    """Options for media generation."""

    model: str | None = None
    provider_options: dict[str, object] | None = None


@dataclass
class MediaTransformOptions(MediaGenerationOptions):
    """Options for media transformation."""

    prompt: str | None = None


@dataclass
class MediaToTextOptions(MediaTransformOptions):
    """Options for media-to-text conversion."""

    config: ModelConfig | None = None


# Type aliases matching the TS SDK
ImageGenerationOptions = MediaGenerationOptions
AudioGenerationOptions = MediaGenerationOptions
VideoGenerationOptions = MediaGenerationOptions

ImageToTextOptions = MediaToTextOptions
AudioToTextOptions = MediaToTextOptions
VideoToTextOptions = MediaToTextOptions

ImageToAudioOptions = MediaTransformOptions
ImageToVideoOptions = MediaTransformOptions
AudioToImageOptions = MediaTransformOptions
AudioToVideoOptions = MediaTransformOptions
VideoToImageOptions = MediaTransformOptions
VideoToAudioOptions = MediaTransformOptions


# ---------------------------------------------------------------------------
# Media response types
# ---------------------------------------------------------------------------


@dataclass
class MediaResponseBase:
    """Base response for media generation."""

    id: str
    data: bytes
    mime_type: str
    created_at: datetime
    model: str | None = None
    url: str | None = None
    provider_metadata: dict[str, object] | None = None


@dataclass
class TextResponseBase:
    """Base response for text generation from media."""

    id: str
    text: str
    created_at: datetime
    model: str | None = None
    provider_metadata: dict[str, object] | None = None


@dataclass
class ImageGenerationResponse(MediaResponseBase):
    """Response from image generation."""

    width: int | None = None
    height: int | None = None


@dataclass
class AudioGenerationResponse(MediaResponseBase):
    """Response from audio generation."""

    duration_ms: int | None = None
    sample_rate_hz: int | None = None
    channels: int | None = None


@dataclass
class VideoGenerationResponse(MediaResponseBase):
    """Response from video generation."""

    duration_ms: int | None = None
    width: int | None = None
    height: int | None = None
    frame_rate: float | None = None


# Type aliases for text-from-media responses
TextFromImageResponse = TextResponseBase
TextFromAudioResponse = TextResponseBase
TextFromVideoResponse = TextResponseBase

# Type aliases for cross-media responses
AudioFromImageResponse = AudioGenerationResponse
AudioFromVideoResponse = AudioGenerationResponse
ImageFromAudioResponse = ImageGenerationResponse
ImageFromVideoResponse = ImageGenerationResponse
VideoFromImageResponse = VideoGenerationResponse
VideoFromAudioResponse = VideoGenerationResponse


# ---------------------------------------------------------------------------
# Model descriptors and routing
# ---------------------------------------------------------------------------


@dataclass
class ModelDescriptor:
    """Descriptor for a registered model."""

    id: str
    provider_id: str
    lifecycle_state: ModelLifecycleState
    version: str | None = None
    max_data_class: DataClass | None = None
    required_residency: DataResidency | None = None
    allowed_purposes: list[str] | None = None


@dataclass
class ModelRouteCandidate:
    """A candidate model in a route."""

    model_id: str
    weight: float | None = None
    max_data_class: DataClass | None = None
    required_residency: DataResidency | None = None


@dataclass
class ModelRoute:
    """A route mapping an ID to a list of candidate models."""

    id: str
    candidates: list[ModelRouteCandidate] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Output schema types
# ---------------------------------------------------------------------------


@dataclass
class JsonSchemaOutput:
    """JSON Schema-based output schema."""

    schema: dict[str, object]
    type: Literal["json_schema"] = "json_schema"


@dataclass
class ValidatorOutput:
    """Validator-based output schema (Python equivalent of Zod)."""

    validator: Callable[[object], ValidatorResult]
    type: Literal["validator"] = "validator"


@dataclass
class ValidatorResult:
    """Result of a validator check."""

    success: bool
    error: str | None = None


OutputSchema = JsonSchemaOutput | ValidatorOutput
"""Output schema for structured output validation."""


# ---------------------------------------------------------------------------
# Grounding / RAG input
# ---------------------------------------------------------------------------


@dataclass
class GroundingOptions:
    """Additional grounding options."""

    metadata: dict[str, object] | None = None


@dataclass
class GroundingInput:
    """Grounding configuration for RAG-based generation."""

    kb_ids: list[str]
    query: str | None = None
    top_k: int | None = None
    options: GroundingOptions | None = None


# ---------------------------------------------------------------------------
# Prompt template reference
# ---------------------------------------------------------------------------


@dataclass
class PromptTemplateRef:
    """Reference to a registered prompt template."""

    id: str
    version: str | None = None


# ---------------------------------------------------------------------------
# GenerateInput / GenerateStreamInput
# ---------------------------------------------------------------------------


@dataclass
class GenerateInput:
    """High-level input for ``client.models.generate()``."""

    model: str
    request: ModelRequest
    context: GovernanceContext
    options: GenerateOptions | None = None
    grounding: GroundingInput | None = None
    prompt_template: PromptTemplateRef | None = None
    data_class: DataClass | None = None
    required_residency: DataResidency | None = None
    output_schema: OutputSchema | None = None
    output_validation_mode: OutputValidationMode | None = None
    evaluators: list[object] | None = None


@dataclass
class StreamOptions:
    """Options specific to streaming generation."""

    emit_chunks: bool | None = None
    abort_on_sensitive: bool | None = None


@dataclass
class GenerateStreamInput(GenerateInput):
    """High-level input for ``client.models.generate_stream()``."""

    stream_options: StreamOptions | None = None


@dataclass
class GenerateStreamResult:
    """Result of ``client.models.generate_stream()``."""

    run_id: str
    stream: object  # AsyncIterator[StreamChunk]
