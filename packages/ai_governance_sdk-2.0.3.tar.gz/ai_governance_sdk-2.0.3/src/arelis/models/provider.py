"""Model provider protocol and base class.

Ports the TypeScript SDK's `packages/models/src/model-provider.ts`.
"""

from __future__ import annotations

import secrets
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Protocol, runtime_checkable

from arelis.models.types import (
    AudioFromImageResponse,
    AudioFromVideoResponse,
    AudioGenerationOptions,
    AudioGenerationResponse,
    AudioInput,
    AudioToImageOptions,
    AudioToTextOptions,
    AudioToVideoOptions,
    GenerateOptions,
    ImageFromAudioResponse,
    ImageFromVideoResponse,
    ImageGenerationOptions,
    ImageGenerationResponse,
    ImageInput,
    ImageToAudioOptions,
    ImageToTextOptions,
    ImageToVideoOptions,
    ModelRequest,
    ModelResponse,
    StreamChunk,
    TextFromAudioResponse,
    TextFromImageResponse,
    TextFromVideoResponse,
    VideoFromAudioResponse,
    VideoFromImageResponse,
    VideoGenerationOptions,
    VideoGenerationResponse,
    VideoInput,
    VideoToAudioOptions,
    VideoToImageOptions,
    VideoToTextOptions,
)

__all__ = [
    "ModelProvider",
    "BaseModelProvider",
    "ProviderCapabilityNotSupportedError",
    "supports_streaming",
    "supports_token_estimation",
    # Multi-modal provider protocols
    "ImageGenerationProvider",
    "AudioGenerationProvider",
    "VideoGenerationProvider",
    "ImageToTextProvider",
    "ImageToAudioProvider",
    "ImageToVideoProvider",
    "AudioToTextProvider",
    "AudioToImageProvider",
    "AudioToVideoProvider",
    "VideoToTextProvider",
    "VideoToImageProvider",
    "VideoToAudioProvider",
    # Multi-modal capability helpers
    "has_capability_flag",
    "supports_image_generation",
    "supports_audio_generation",
    "supports_video_generation",
    "supports_image_to_text",
    "supports_image_to_audio",
    "supports_image_to_video",
    "supports_audio_to_text",
    "supports_audio_to_image",
    "supports_audio_to_video",
    "supports_video_to_text",
    "supports_video_to_image",
    "supports_video_to_audio",
]


# ---------------------------------------------------------------------------
# ModelProvider protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ModelProvider(Protocol):
    """Interface for model providers.

    Implementations must provide ``id``, ``name``, ``supported_models``,
    ``generate()``, and ``supports_model()``.  Optionally they may also
    implement ``stream()`` and ``estimate_tokens()``.
    """

    @property
    def id(self) -> str:
        """Unique identifier for this provider."""
        ...

    @property
    def name(self) -> str:
        """Human-readable name."""
        ...

    @property
    def supported_models(self) -> list[str]:
        """List of models supported by this provider."""
        ...

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        """Generate a response from the model."""
        ...

    def supports_model(self, model: str) -> bool:
        """Check if a specific model is supported."""
        ...

    def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a response from the model.

        Optional -- providers that do not support streaming should not
        implement this method.
        """
        ...

    async def estimate_tokens(self, request: ModelRequest) -> int:
        """Estimate token count for messages.

        Optional -- providers that do not support token estimation should not
        implement this method.
        """
        ...


# ---------------------------------------------------------------------------
# BaseModelProvider (ABC with shared helpers)
# ---------------------------------------------------------------------------


class BaseModelProvider(ABC):
    """Base class for model providers with common functionality.

    Subclasses must override ``id``, ``name``, ``supported_models``, and
    ``generate()``.
    """

    @property
    @abstractmethod
    def id(self) -> str:
        """Unique identifier for this provider."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name."""
        ...

    @property
    @abstractmethod
    def supported_models(self) -> list[str]:
        """List of models supported by this provider."""
        ...

    @abstractmethod
    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        """Generate a response from the model."""
        ...

    def supports_model(self, model: str) -> bool:
        """Check if a specific model is supported."""
        return model in self.supported_models

    def validate_request(self, request: ModelRequest) -> None:
        """Validate a model request.

        Raises:
            ValueError: If the request is invalid.
        """
        if not request.model:
            raise ValueError("Model identifier is required")

        if not request.messages or len(request.messages) == 0:
            raise ValueError("At least one message is required")

        if not self.supports_model(request.model):
            raise ValueError(f'Model "{request.model}" is not supported by provider "{self.id}"')

    @staticmethod
    def generate_response_id() -> str:
        """Generate a unique response ID."""
        ts = int(time.time() * 1000)
        rand = secrets.token_hex(5)
        return f"resp_{ts}_{rand}"


# ---------------------------------------------------------------------------
# ProviderCapabilityNotSupportedError
# ---------------------------------------------------------------------------


class ProviderCapabilityNotSupportedError(Exception):
    """Raised when a provider does not support a requested capability."""

    def __init__(self, provider_id: str, capability: str) -> None:
        self.provider_id = provider_id
        self.capability = capability
        super().__init__(f'Provider "{provider_id}" does not support capability "{capability}"')


# ---------------------------------------------------------------------------
# Capability guards
# ---------------------------------------------------------------------------


def supports_streaming(provider: ModelProvider) -> bool:
    """Check whether *provider* implements ``stream()``."""
    stream_method = getattr(provider, "stream", None)
    return callable(stream_method)


def supports_token_estimation(provider: ModelProvider) -> bool:
    """Check whether *provider* implements ``estimate_tokens()``."""
    estimate_method = getattr(provider, "estimate_tokens", None)
    return callable(estimate_method)


# ---------------------------------------------------------------------------
# Multi-modal provider protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class ImageGenerationProvider(Protocol):
    """Provider that can generate images from text prompts."""

    async def generate_image(
        self,
        prompt: str,
        options: ImageGenerationOptions | None = None,
    ) -> ImageGenerationResponse:
        """Generate an image from a text prompt."""
        ...


@runtime_checkable
class AudioGenerationProvider(Protocol):
    """Provider that can generate audio from text prompts."""

    async def generate_audio(
        self,
        prompt: str,
        options: AudioGenerationOptions | None = None,
    ) -> AudioGenerationResponse:
        """Generate audio from a text prompt."""
        ...


@runtime_checkable
class VideoGenerationProvider(Protocol):
    """Provider that can generate video from text prompts."""

    async def generate_video(
        self,
        prompt: str,
        options: VideoGenerationOptions | None = None,
    ) -> VideoGenerationResponse:
        """Generate video from a text prompt."""
        ...


@runtime_checkable
class ImageToTextProvider(Protocol):
    """Provider that can extract text from images."""

    async def image_to_text(
        self,
        input: ImageInput,
        options: ImageToTextOptions | None = None,
    ) -> TextFromImageResponse:
        """Extract text from an image."""
        ...


@runtime_checkable
class ImageToAudioProvider(Protocol):
    """Provider that can generate audio from images."""

    async def image_to_audio(
        self,
        input: ImageInput,
        options: ImageToAudioOptions | None = None,
    ) -> AudioFromImageResponse:
        """Generate audio from an image."""
        ...


@runtime_checkable
class ImageToVideoProvider(Protocol):
    """Provider that can generate video from images."""

    async def image_to_video(
        self,
        input: ImageInput,
        options: ImageToVideoOptions | None = None,
    ) -> VideoFromImageResponse:
        """Generate video from an image."""
        ...


@runtime_checkable
class AudioToTextProvider(Protocol):
    """Provider that can transcribe audio to text."""

    async def audio_to_text(
        self,
        input: AudioInput,
        options: AudioToTextOptions | None = None,
    ) -> TextFromAudioResponse:
        """Transcribe audio to text."""
        ...


@runtime_checkable
class AudioToImageProvider(Protocol):
    """Provider that can generate images from audio."""

    async def audio_to_image(
        self,
        input: AudioInput,
        options: AudioToImageOptions | None = None,
    ) -> ImageFromAudioResponse:
        """Generate an image from audio."""
        ...


@runtime_checkable
class AudioToVideoProvider(Protocol):
    """Provider that can generate video from audio."""

    async def audio_to_video(
        self,
        input: AudioInput,
        options: AudioToVideoOptions | None = None,
    ) -> VideoFromAudioResponse:
        """Generate video from audio."""
        ...


@runtime_checkable
class VideoToTextProvider(Protocol):
    """Provider that can extract text from video."""

    async def video_to_text(
        self,
        input: VideoInput,
        options: VideoToTextOptions | None = None,
    ) -> TextFromVideoResponse:
        """Extract text from video."""
        ...


@runtime_checkable
class VideoToImageProvider(Protocol):
    """Provider that can extract images from video."""

    async def video_to_image(
        self,
        input: VideoInput,
        options: VideoToImageOptions | None = None,
    ) -> ImageFromVideoResponse:
        """Extract images from video."""
        ...


@runtime_checkable
class VideoToAudioProvider(Protocol):
    """Provider that can extract audio from video."""

    async def video_to_audio(
        self,
        input: VideoInput,
        options: VideoToAudioOptions | None = None,
    ) -> AudioFromVideoResponse:
        """Extract audio from video."""
        ...


# ---------------------------------------------------------------------------
# Multi-modal capability helpers
# ---------------------------------------------------------------------------


def has_capability_flag(provider: ModelProvider, flag: str) -> bool | None:
    """Check whether *provider* exposes a capability flag.

    Returns ``True`` or ``False`` if the provider has a ``capabilities``
    attribute containing the given *flag*, or ``None`` if the attribute
    is missing or the flag is not present.
    """
    capabilities = getattr(provider, "capabilities", None)
    if capabilities is None:
        return None
    if isinstance(capabilities, dict):
        value = capabilities.get(flag)
        if isinstance(value, bool):
            return value
    return None


def supports_image_generation(provider: ModelProvider) -> bool:
    """Check whether *provider* supports image generation."""
    if isinstance(provider, ImageGenerationProvider):
        return True
    flag = has_capability_flag(provider, "image_generation")
    return flag if flag is not None else False


def supports_audio_generation(provider: ModelProvider) -> bool:
    """Check whether *provider* supports audio generation."""
    if isinstance(provider, AudioGenerationProvider):
        return True
    flag = has_capability_flag(provider, "audio_generation")
    return flag if flag is not None else False


def supports_video_generation(provider: ModelProvider) -> bool:
    """Check whether *provider* supports video generation."""
    if isinstance(provider, VideoGenerationProvider):
        return True
    flag = has_capability_flag(provider, "video_generation")
    return flag if flag is not None else False


def supports_image_to_text(provider: ModelProvider) -> bool:
    """Check whether *provider* supports image-to-text conversion."""
    if isinstance(provider, ImageToTextProvider):
        return True
    flag = has_capability_flag(provider, "image_to_text")
    return flag if flag is not None else False


def supports_image_to_audio(provider: ModelProvider) -> bool:
    """Check whether *provider* supports image-to-audio conversion."""
    if isinstance(provider, ImageToAudioProvider):
        return True
    flag = has_capability_flag(provider, "image_to_audio")
    return flag if flag is not None else False


def supports_image_to_video(provider: ModelProvider) -> bool:
    """Check whether *provider* supports image-to-video conversion."""
    if isinstance(provider, ImageToVideoProvider):
        return True
    flag = has_capability_flag(provider, "image_to_video")
    return flag if flag is not None else False


def supports_audio_to_text(provider: ModelProvider) -> bool:
    """Check whether *provider* supports audio-to-text conversion."""
    if isinstance(provider, AudioToTextProvider):
        return True
    flag = has_capability_flag(provider, "audio_to_text")
    return flag if flag is not None else False


def supports_audio_to_image(provider: ModelProvider) -> bool:
    """Check whether *provider* supports audio-to-image conversion."""
    if isinstance(provider, AudioToImageProvider):
        return True
    flag = has_capability_flag(provider, "audio_to_image")
    return flag if flag is not None else False


def supports_audio_to_video(provider: ModelProvider) -> bool:
    """Check whether *provider* supports audio-to-video conversion."""
    if isinstance(provider, AudioToVideoProvider):
        return True
    flag = has_capability_flag(provider, "audio_to_video")
    return flag if flag is not None else False


def supports_video_to_text(provider: ModelProvider) -> bool:
    """Check whether *provider* supports video-to-text conversion."""
    if isinstance(provider, VideoToTextProvider):
        return True
    flag = has_capability_flag(provider, "video_to_text")
    return flag if flag is not None else False


def supports_video_to_image(provider: ModelProvider) -> bool:
    """Check whether *provider* supports video-to-image conversion."""
    if isinstance(provider, VideoToImageProvider):
        return True
    flag = has_capability_flag(provider, "video_to_image")
    return flag if flag is not None else False


def supports_video_to_audio(provider: ModelProvider) -> bool:
    """Check whether *provider* supports video-to-audio conversion."""
    if isinstance(provider, VideoToAudioProvider):
        return True
    flag = has_capability_flag(provider, "video_to_audio")
    return flag if flag is not None else False
