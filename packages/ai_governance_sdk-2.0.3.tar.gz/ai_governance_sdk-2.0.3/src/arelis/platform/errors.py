"""Platform API error types."""

from __future__ import annotations


class ArelisApiError(Exception):
    """RFC7807-compatible API error raised by :class:`ArelisPlatform`."""

    def __init__(
        self,
        *,
        type: str,
        title: str,
        status: int,
        detail: str,
        instance: str | None = None,
    ) -> None:
        super().__init__(detail)
        self.type = type
        self.title = title
        self.status = status
        self.detail = detail
        self.instance = instance


__all__ = ["ArelisApiError"]
