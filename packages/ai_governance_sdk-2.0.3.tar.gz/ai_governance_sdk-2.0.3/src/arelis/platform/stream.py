"""SSE stream connection support for the platform client."""

from __future__ import annotations

import json
import threading
from collections.abc import Callable, Iterable
from typing import Any

import httpx

DEFAULT_EVENT_TYPES: tuple[str, ...] = (
    "event:created",
    "proof:created",
    "risk:evaluated",
    "replay:completed",
    "policy:updated",
    "usage:updated",
    "key:updated",
)


class EventStreamConnection:
    """Background SSE connection with explicit close support."""

    def __init__(
        self,
        *,
        url: str,
        timeout_ms: int,
        on_event: Callable[[str, Any], None],
        event_types: Iterable[str] | None = None,
    ) -> None:
        self._url = url
        self._timeout_ms = timeout_ms
        self._on_event = on_event
        self._event_types = set(event_types if event_types is not None else DEFAULT_EVENT_TYPES)
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._client: httpx.Client | None = None
        self._response: httpx.Response | None = None
        self._thread.start()

    def close(self) -> None:
        """Close the live stream connection."""
        self._stop_event.set()
        if self._response is not None:
            self._response.close()
        if self._client is not None:
            self._client.close()
        if self._thread.is_alive():
            self._thread.join(timeout=0.2)

    def _run(self) -> None:
        event_type = "message"
        data_lines: list[str] = []
        timeout = httpx.Timeout(connect=self._timeout_ms / 1000.0, read=None, write=None, pool=None)

        try:
            with httpx.Client(timeout=timeout) as client:
                self._client = client
                with client.stream(
                    "GET",
                    self._url,
                    headers={
                        "Accept": "text/event-stream",
                        "Cache-Control": "no-cache",
                    },
                ) as response:
                    self._response = response
                    if response.status_code >= 400:
                        return

                    for raw_line in response.iter_lines():
                        if self._stop_event.is_set():
                            return

                        line = raw_line.strip()
                        if line == "":
                            self._emit(event_type, data_lines)
                            event_type = "message"
                            data_lines = []
                            continue

                        if line.startswith(":"):
                            continue

                        field, sep, value = line.partition(":")
                        if sep == "":
                            continue
                        value = value.lstrip(" ")

                        if field == "event":
                            event_type = value
                        elif field == "data":
                            data_lines.append(value)
        except Exception:
            return

    def _emit(self, event_type: str, data_lines: list[str]) -> None:
        if event_type not in self._event_types or not data_lines:
            return
        payload = "\n".join(data_lines)
        try:
            data = json.loads(payload)
        except Exception:
            return
        self._on_event(event_type, data)


__all__ = ["DEFAULT_EVENT_TYPES", "EventStreamConnection"]
