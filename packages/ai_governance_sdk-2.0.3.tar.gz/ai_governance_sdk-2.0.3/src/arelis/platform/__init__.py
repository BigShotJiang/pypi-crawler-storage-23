"""Arelis Platform SDK surface."""

from __future__ import annotations

import warnings

from arelis.platform.errors import ArelisApiError
from arelis.platform.event_bridge import audit_event_to_platform_event, create_platform_event
from arelis.platform.helpers import (
    INITIAL_BACKOFF_MS,
    MAX_BACKOFF_MS,
    RETRYABLE_STATUS_CODES,
    build_query_string,
    is_retryable_error,
)
from arelis.platform.platform_client import (
    DEFAULT_ARELIS_PLATFORM_BASE_URL,
    ArelisPlatform,
)
from arelis.platform.types import *  # noqa: F403
from arelis.platform.types import ArelisPlatformConfig


def create_arelis_platform(config: ArelisPlatformConfig) -> ArelisPlatform:
    """Create an :class:`ArelisPlatform` client from platform config."""
    return ArelisPlatform(config)


def createArelisPlatform(config: ArelisPlatformConfig) -> ArelisPlatform:  # noqa: N802
    """CamelCase compatibility alias for :func:`create_arelis_platform`."""
    warnings.warn(
        "createArelisPlatform() is a compatibility alias and will be deprecated in a future "
        "major release; use create_arelis_platform() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return create_arelis_platform(config)


__all__ = [
    "ArelisApiError",
    "ArelisPlatform",
    "ArelisPlatformConfig",
    "create_arelis_platform",
    "createArelisPlatform",
    "INITIAL_BACKOFF_MS",
    "MAX_BACKOFF_MS",
    "RETRYABLE_STATUS_CODES",
    "is_retryable_error",
    "build_query_string",
    "DEFAULT_ARELIS_PLATFORM_BASE_URL",
    "create_platform_event",
    "audit_event_to_platform_event",
]
