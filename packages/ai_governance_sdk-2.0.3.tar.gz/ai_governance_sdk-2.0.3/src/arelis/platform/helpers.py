"""Platform client helper utilities and retry constants."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from urllib.parse import quote

import httpx

from arelis.platform.errors import ArelisApiError

INITIAL_BACKOFF_MS = 500
MAX_BACKOFF_MS = 30_000
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def is_retryable_error(error: BaseException) -> bool:
    """Return whether an error is retryable according to platform semantics."""
    if isinstance(error, ArelisApiError):
        return error.status in RETRYABLE_STATUS_CODES
    return isinstance(
        error,
        (
            httpx.TimeoutException,
            httpx.NetworkError,
            httpx.RemoteProtocolError,
            httpx.TransportError,
        ),
    )


def build_query_string(params: Mapping[str, Any]) -> str:
    """Build a query string from non-null/defined parameters."""
    entries: list[str] = []
    for key, value in params.items():
        if value is None:
            continue
        query_value = str(value).lower() if isinstance(value, bool) else str(value)
        entries.append(f"{quote(str(key), safe='')}={quote(query_value, safe='')}")
    if not entries:
        return ""
    return f"?{'&'.join(entries)}"


__all__ = [
    "INITIAL_BACKOFF_MS",
    "MAX_BACKOFF_MS",
    "RETRYABLE_STATUS_CODES",
    "is_retryable_error",
    "build_query_string",
]
