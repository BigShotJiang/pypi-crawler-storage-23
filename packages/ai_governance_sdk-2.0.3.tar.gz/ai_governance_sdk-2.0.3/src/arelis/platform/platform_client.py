# ruff: noqa: E501
"""Unified Arelis Platform HTTP client."""

from __future__ import annotations

import inspect
import random
import re
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from types import SimpleNamespace
from typing import Any, cast
from urllib.parse import quote

import httpx

from arelis.platform.errors import ArelisApiError
from arelis.platform.helpers import (
    INITIAL_BACKOFF_MS,
    MAX_BACKOFF_MS,
    RETRYABLE_STATUS_CODES,
    build_query_string,
    is_retryable_error,
)
from arelis.platform.stream import EventStreamConnection
from arelis.platform.types import ArelisPlatformConfig, GetPiiConfigOptions
from arelis.policy.redactor import RedactionPattern, RedactorConfig

JsonObject = dict[str, Any]
DEFAULT_ARELIS_PLATFORM_BASE_URL = "https://api.arelis.digital"


class ArelisPlatform:
    """Client for the Arelis Platform API."""

    def __init__(self, config: ArelisPlatformConfig) -> None:
        resolved_base_url = (
            str(config["baseUrl"]).strip()
            if "baseUrl" in config and str(config["baseUrl"]).strip() != ""
            else DEFAULT_ARELIS_PLATFORM_BASE_URL
        )
        self._base_url = resolved_base_url.rstrip("/")
        self._api_key = str(config["apiKey"]) if "apiKey" in config else None
        self._token = str(config["token"]) if "token" in config else None
        self._max_retries = int(config.get("maxRetries", 3))
        self._timeout_ms = int(config.get("timeout", 30_000))

        self.events: Any = SimpleNamespace(
            create=lambda event: self._request("POST", "/api/v1/events", event),
            createBatch=lambda payload: self._request("POST", "/api/v1/events/batch", payload),
            list=lambda params: self._request("GET", f"/api/v1/events{build_query_string(params)}"),
            get=lambda event_id: self._request(
                "GET", f"/api/v1/events/{quote(str(event_id), safe='')}"
            ),
            count=lambda params=None: self._request(
                "GET", f"/api/v1/events/count{build_query_string(params or {})}"
            ),
        )

        self.proofs: Any = SimpleNamespace(
            create=lambda payload: self._request("POST", "/api/v1/proofs", payload),
            get=lambda proof_id: self._request(
                "GET", f"/api/v1/proofs/{quote(str(proof_id), safe='')}"
            ),
            verify=lambda payload: self._request("POST", "/api/v1/proofs/verify", payload),
            list=lambda params=None: self._request(
                "GET", f"/api/v1/proofs{build_query_string(params or {})}"
            ),
        )

        self.risk: Any = SimpleNamespace(
            evaluate=lambda payload: self._request("POST", "/api/v1/risk/evaluate", payload),
            getConfig=lambda: self._request("GET", "/api/v1/risk/config"),
            updateConfig=lambda payload: self._request("PUT", "/api/v1/risk/config", payload),
            listDecisions=lambda params=None: self._request(
                "GET", f"/api/v1/risk/decisions{build_query_string(params or {})}"
            ),
            simulate=lambda payload: self._request("POST", "/api/v1/risk/simulate", payload),
            getConfigVersions=lambda: self._request("GET", "/api/v1/risk/config/versions"),
            saveDraft=lambda payload: self._request("POST", "/api/v1/risk/config/draft", payload),
            clearDraft=lambda: self._request("DELETE", "/api/v1/risk/config/draft"),
            publishDraft=lambda payload=None: self._request(
                "POST", "/api/v1/risk/config/publish", payload or {}
            ),
            rollbackConfig=lambda payload: self._request(
                "POST", "/api/v1/risk/config/rollback", payload
            ),
        )

        self.replay: Any = SimpleNamespace(
            start=lambda payload: self._request("POST", "/api/v1/replay", payload),
            startCausalGraph=lambda payload: self._request(
                "POST", "/api/v1/replay/causal-graph", payload
            ),
            get=lambda replay_id: self._request(
                "GET", f"/api/v1/replay/{quote(str(replay_id), safe='')}"
            ),
            list=lambda params=None: self._request(
                "GET", f"/api/v1/replay{build_query_string(params or {})}"
            ),
            createTemplate=lambda payload: self._request(
                "POST", "/api/v1/replay/templates", payload
            ),
            listTemplates=lambda params=None: self._request(
                "GET", f"/api/v1/replay/templates{build_query_string(params or {})}"
            ),
            getTemplate=lambda template_id: self._request(
                "GET", f"/api/v1/replay/templates/{quote(str(template_id), safe='')}"
            ),
            updateTemplate=lambda template_id, payload: self._request(
                "PUT", f"/api/v1/replay/templates/{quote(str(template_id), safe='')}", payload
            ),
            deleteTemplate=lambda template_id: self._request(
                "DELETE", f"/api/v1/replay/templates/{quote(str(template_id), safe='')}"
            ),
            compare=lambda payload: self._request("POST", "/api/v1/replay/compare", payload),
        )

        self.graphs: Any = SimpleNamespace(
            list=lambda params=None: self._request(
                "GET", f"/api/v1/graphs{build_query_string(params or {})}"
            ),
            get=lambda run_id: self._request(
                "GET", f"/api/v1/graphs/{quote(str(run_id), safe='')}"
            ),
            commit=lambda run_id: self._request(
                "POST", f"/api/v1/graphs/{quote(str(run_id), safe='')}/commit"
            ),
            lineage=lambda run_id, node_id=None: self._request(
                "GET",
                f"/api/v1/graphs/{quote(str(run_id), safe='')}/lineage"
                f"{build_query_string({'nodeId': node_id} if node_id else {})}",
            ),
        )

        governance_policies = SimpleNamespace(
            create=lambda payload: self._request("POST", "/api/v1/governance/policies", payload),
            list=lambda params=None: self._request(
                "GET", f"/api/v1/governance/policies{build_query_string(params or {})}"
            ),
            get=lambda policy_id: self._request(
                "GET", f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}"
            ),
            update=lambda policy_id, payload: self._request(
                "PUT", f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}", payload
            ),
            delete=lambda policy_id: self._request(
                "DELETE", f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}"
            ),
            restore=lambda policy_id: self._request(
                "POST", f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/restore"
            ),
            createVersion=lambda policy_id, payload: self._request(
                "POST",
                f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/versions",
                payload,
            ),
            listVersions=lambda policy_id: self._request(
                "GET", f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/versions"
            ),
            activateVersion=lambda policy_id, payload: self._request(
                "POST",
                f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/activate-version",
                payload,
            ),
            transition=lambda policy_id, payload: self._request(
                "POST",
                f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/transition",
                payload,
            ),
            rollback=lambda policy_id, payload: self._request(
                "POST",
                f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/rollback",
                payload,
            ),
            simulate=lambda policy_id, payload: self._request(
                "POST",
                f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/simulate",
                payload,
            ),
            bulkSimulate=lambda payload: self._request(
                "POST", "/api/v1/governance/policies/simulate", payload
            ),
            impact=lambda policy_id, payload: self._request(
                "POST",
                f"/api/v1/governance/policies/{quote(str(policy_id), safe='')}/impact",
                payload,
            ),
        )

        self.governance: Any = SimpleNamespace(
            evaluatePolicy=lambda payload: self._request(
                "POST", "/api/v1/governance/policy/evaluate", payload
            ),
            getPiiConfig=lambda options=None: self._get_managed_pii_config(options),
            listPolicyEvaluations=lambda params=None: self._request(
                "GET",
                f"/api/v1/governance/policy/evaluations{build_query_string(params or {})}",
            ),
            getSnapshot=lambda run_id, params=None: self._request(
                "GET",
                f"/api/v1/governance/snapshots/{quote(str(run_id), safe='')}"
                f"{build_query_string(params or {})}",
            ),
            policies=governance_policies,
        )

        self.apiKeys: Any = SimpleNamespace(
            create=lambda payload: self._request("POST", "/api/v1/api-keys", payload),
            list=lambda: self._request("GET", "/api/v1/api-keys"),
            update=lambda key_id, payload: self._request(
                "PUT", f"/api/v1/api-keys/{quote(str(key_id), safe='')}", payload
            ),
            revoke=lambda key_id: self._request(
                "DELETE", f"/api/v1/api-keys/{quote(str(key_id), safe='')}"
            ),
            rotate=lambda key_id: self._request(
                "POST", f"/api/v1/api-keys/{quote(str(key_id), safe='')}/rotate"
            ),
        )

        self.usage: Any = SimpleNamespace(
            get=lambda: self._request("GET", "/api/v1/usage"),
            history=lambda: self._request("GET", "/api/v1/usage/history"),
        )

        self.jobs: Any = SimpleNamespace(
            list=lambda params=None: self._request(
                "GET", f"/api/v1/jobs{build_query_string(params or {})}"
            ),
            get=lambda job_id: self._request("GET", f"/api/v1/jobs/{quote(str(job_id), safe='')}"),
            retry=lambda job_id: self._request(
                "POST", f"/api/v1/jobs/{quote(str(job_id), safe='')}/retry"
            ),
        )

        self.organization: Any = SimpleNamespace(
            get=lambda: self._request("GET", "/api/v1/organization")
        )

        self.quotas: Any = SimpleNamespace(get=lambda: self._request("GET", "/api/v1/quotas"))

        self.billing: Any = SimpleNamespace(
            summary=lambda: self._request("GET", "/api/v1/billing/summary")
        )

        self.metering: Any = SimpleNamespace(
            getMilestones=lambda: self._request("GET", "/api/v1/metering/milestones"),
            updateMilestones=lambda payload: self._request(
                "PUT", "/api/v1/metering/milestones", payload
            ),
            listMilestoneDeliveries=lambda params=None: self._request(
                "GET", f"/api/v1/metering/milestones/deliveries{build_query_string(params or {})}"
            ),
        )

        self.telemetry: Any = SimpleNamespace(
            reportUsage=lambda payload: self._request("POST", "/api/v1/telemetry/usage", payload),
            submitAttestation=lambda challenge_id, payload: self._request(
                "POST",
                f"/api/v1/telemetry/attestations/{quote(str(challenge_id), safe='')}",
                payload,
            ),
            listReports=lambda params=None: self._request(
                "GET", f"/api/v1/telemetry/reports{build_query_string(params or {})}"
            ),
            listChallenges=lambda params=None: self._request(
                "GET", f"/api/v1/telemetry/challenges{build_query_string(params or {})}"
            ),
        )

        self.exports: Any = SimpleNamespace(
            create=lambda payload: self._request("POST", "/api/v1/exports", payload),
            list=lambda params=None: self._request(
                "GET", f"/api/v1/exports{build_query_string(params or {})}"
            ),
            get=lambda export_id: self._request(
                "GET", f"/api/v1/exports/{quote(str(export_id), safe='')}"
            ),
            download=lambda export_id: self._download_export_artifact(str(export_id)),
        )

        self.namespaces: Any = SimpleNamespace(
            agents=self._build_namespace_crud("/api/v1/namespaces/agents"),
            approvals=self._build_namespace_crud("/api/v1/namespaces/approvals"),
            complianceConfig=self._build_namespace_crud("/api/v1/namespaces/compliance-config"),
            dataSources=self._build_namespace_crud("/api/v1/namespaces/data-sources"),
            evaluations=self._build_namespace_crud("/api/v1/namespaces/evaluations"),
            governanceConfig=self._build_namespace_crud("/api/v1/namespaces/governance-config"),
            knowledge=self._build_namespace_crud("/api/v1/namespaces/knowledge"),
            mcp=SimpleNamespace(
                **self._build_namespace_crud("/api/v1/namespaces/mcp").__dict__,
                evaluateTool=lambda payload: self._request(
                    "POST", "/api/v1/mcp/tools/evaluate", payload
                ),
                governedInvoke=self._governed_invoke,
            ),
            memory=self._build_namespace_crud("/api/v1/namespaces/memory"),
            prompts=self._build_namespace_crud("/api/v1/namespaces/prompts"),
            quotas=self._build_namespace_crud("/api/v1/namespaces/quotas/config"),
            secrets=self._build_namespace_crud("/api/v1/namespaces/secrets"),
            telemetry=self._build_namespace_crud("/api/v1/namespaces/telemetry"),
            tools=self._build_namespace_crud("/api/v1/namespaces/tools"),
        )

        self.approvals: Any = SimpleNamespace(
            list=lambda params=None: self._request(
                "GET", f"/api/v1/namespaces/approvals{build_query_string(params or {})}"
            ),
            resolve=lambda approval_id, payload: self._request(
                "POST", f"/api/v1/approvals/{quote(str(approval_id), safe='')}/resolve", payload
            ),
            getConfig=lambda: self._request("GET", "/api/v1/namespaces/approvals"),
            updateConfig=lambda payload: self._request(
                "POST", "/api/v1/namespaces/approvals", payload
            ),
        )

        self.aiSystems: Any = SimpleNamespace(
            register=lambda payload: self._request("POST", "/api/v1/ai-systems", payload),
            list=lambda params=None: self._request(
                "GET", f"/api/v1/ai-systems{build_query_string(params or {})}"
            ),
            get=lambda system_id: self._request(
                "GET", f"/api/v1/ai-systems/{quote(str(system_id), safe='')}"
            ),
            update=lambda system_id, payload: self._request(
                "PUT", f"/api/v1/ai-systems/{quote(str(system_id), safe='')}", payload
            ),
            archive=lambda system_id: self._request(
                "DELETE", f"/api/v1/ai-systems/{quote(str(system_id), safe='')}"
            ),
            setDefault=lambda system_id: self._request(
                "POST", f"/api/v1/ai-systems/{quote(str(system_id), safe='')}/set-default"
            ),
            summary=lambda system_id, params=None: self._request(
                "GET",
                f"/api/v1/ai-systems/{quote(str(system_id), safe='')}/summary"
                f"{build_query_string(params or {})}",
            ),
        )

        self.mcpServers: Any = SimpleNamespace(
            create=lambda payload: self._request("POST", "/api/v1/mcp-servers", payload),
            list=lambda params=None: self._request(
                "GET", f"/api/v1/mcp-servers{build_query_string(params or {})}"
            ),
            get=lambda server_id: self._request(
                "GET", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}"
            ),
            update=lambda server_id, payload: self._request(
                "PUT", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}", payload
            ),
            archive=lambda server_id: self._request(
                "DELETE", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}"
            ),
            createTool=lambda server_id, payload: self._request(
                "POST", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/tools", payload
            ),
            listTools=lambda server_id, params=None: self._request(
                "GET",
                f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/tools"
                f"{build_query_string(params or {})}",
            ),
            updateTool=lambda server_id, tool_name, payload: self._request(
                "PUT",
                f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/tools/{quote(str(tool_name), safe='')}",
                payload,
            ),
            refreshTools=lambda server_id: self._request(
                "POST", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/refresh-tools"
            ),
            healthCheck=lambda server_id: self._request(
                "POST", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/health-check"
            ),
            healthHistory=lambda server_id, params=None: self._request(
                "GET",
                f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/health"
                f"{build_query_string(params or {})}",
            ),
            linkSystem=lambda server_id, payload: self._request(
                "POST", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/link", payload
            ),
            unlinkSystem=lambda server_id, system_id: self._request(
                "DELETE",
                f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/link/{quote(str(system_id), safe='')}",
            ),
            linkedSystems=lambda server_id: self._request(
                "GET", f"/api/v1/mcp-servers/{quote(str(server_id), safe='')}/systems"
            ),
        )

    def _request(self, method: str, path: str, body: Any | None = None) -> Any:
        url = f"{self._base_url}{path}"
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._fetch_with_timeout(url=url, method=method, body=body)

                if 200 <= response.status_code < 300:
                    if response.status_code == 204:
                        return None
                    return response.json()

                error_body = self._safe_parse_json(response)
                api_error = self._to_api_error(response, error_body)

                if (
                    response.status_code not in RETRYABLE_STATUS_CODES
                    or attempt == self._max_retries
                ):
                    raise api_error

                last_error = api_error
                time.sleep(self._compute_backoff(attempt, response) / 1000.0)
            except Exception as error:
                if isinstance(error, ArelisApiError):
                    if not is_retryable_error(error) or attempt == self._max_retries:
                        raise
                    last_error = error
                elif is_retryable_error(error):
                    if attempt == self._max_retries:
                        raise
                    last_error = error
                else:
                    raise

                time.sleep(self._compute_backoff(attempt) / 1000.0)

        if last_error is not None:
            raise last_error
        raise RuntimeError("Platform request failed without error details")

    def _fetch_with_timeout(
        self, *, url: str, method: str, body: Any | None = None
    ) -> httpx.Response:
        headers: JsonObject = {"Accept": "application/json"}

        if self._api_key is not None:
            headers["x-api-key"] = self._api_key
        elif self._token is not None:
            headers["Authorization"] = f"Bearer {self._token}"

        kwargs: JsonObject = {
            "method": method,
            "url": url,
            "headers": headers,
            "timeout": self._timeout_ms / 1000.0,
        }

        if body is not None:
            headers["Content-Type"] = "application/json"
            kwargs["json"] = body

        return httpx.request(**kwargs)

    def _download_export_artifact(self, export_id: str) -> JsonObject:
        encoded_id = quote(export_id, safe="")
        response = self._fetch_with_timeout(
            url=f"{self._base_url}/api/v1/exports/{encoded_id}/download",
            method="GET",
        )

        if response.status_code >= 400:
            error_body = self._safe_parse_json(response)
            raise self._to_api_error(response, error_body)

        disposition = response.headers.get("Content-Disposition", "")
        file_name = f"export-{export_id}.dat"
        if "filename=" in disposition:
            value = disposition.split("filename=", 1)[1].strip()
            if value.startswith('"') and value.endswith('"') and len(value) > 1:
                file_name = value[1:-1]
            else:
                file_name = value.strip(";")

        return {
            "file_name": file_name,
            "mime_type": response.headers.get("Content-Type", "application/octet-stream"),
            "content": response.text,
        }

    def _build_namespace_crud(self, route_path: str) -> Any:
        return SimpleNamespace(
            list=lambda params=None: self._request(
                "GET", f"{route_path}{build_query_string(params or {})}"
            ),
            create=lambda data: self._request("POST", route_path, data),
            get=lambda item_id: self._request(
                "GET", f"{route_path}/{quote(str(item_id), safe='')}"
            ),
            update=lambda item_id, data: self._request(
                "PUT", f"{route_path}/{quote(str(item_id), safe='')}", data
            ),
            archive=lambda item_id: self._request(
                "DELETE", f"{route_path}/{quote(str(item_id), safe='')}"
            ),
        )

    async def _governed_invoke(self, payload: JsonObject) -> JsonObject:
        invoke = payload.get("invoke")
        if not callable(invoke):
            raise ValueError("governedInvoke requires callable 'invoke'")

        deny_mode = payload.get("denyMode")
        evaluation_payload = dict(payload)
        evaluation_payload.pop("invoke", None)
        evaluation_payload.pop("denyMode", None)

        decision = self._request("POST", "/api/v1/mcp/tools/evaluate", evaluation_payload)
        decision_value = str(decision.get("decision", "")) if isinstance(decision, dict) else ""

        if decision_value in {"deny", "escalate"}:
            if deny_mode == "throw":
                block_reason = "MCP tool call blocked by policy"
                policy = decision.get("policy") if isinstance(decision, dict) else None
                if isinstance(policy, dict):
                    summary = policy.get("summary")
                    if isinstance(summary, dict) and isinstance(summary.get("blockReason"), str):
                        block_reason = summary["blockReason"]
                raise ArelisApiError(
                    type="https://arelis.dev/errors/mcp-tool-denied",
                    title="MCP Tool Call Denied",
                    status=403,
                    detail=block_reason,
                    instance=None,
                )
            return {"runId": decision.get("runId"), "invoked": False, "decision": decision}

        result = invoke()
        if inspect.isawaitable(result):
            result = await result
        return {
            "runId": decision.get("runId") if isinstance(decision, dict) else None,
            "invoked": True,
            "decision": decision,
            "result": result,
        }

    def _to_api_error(
        self, response: httpx.Response, error_body: JsonObject | None
    ) -> ArelisApiError:
        type_value = (
            error_body.get("type")
            if isinstance(error_body, dict) and isinstance(error_body.get("type"), str)
            else None
        )
        title_value = (
            error_body.get("title")
            if isinstance(error_body, dict) and isinstance(error_body.get("title"), str)
            else None
        )
        detail_value = (
            error_body.get("detail")
            if isinstance(error_body, dict) and isinstance(error_body.get("detail"), str)
            else None
        )
        instance_value = (
            error_body.get("instance")
            if isinstance(error_body, dict) and isinstance(error_body.get("instance"), str)
            else None
        )

        return ArelisApiError(
            type=type_value or f"https://arelis.dev/errors/http-{response.status_code}",
            title=title_value or response.reason_phrase,
            status=response.status_code,
            detail=detail_value or f"Request failed with status {response.status_code}",
            instance=instance_value,
        )

    def _compute_backoff(self, attempt: int, response: httpx.Response | None = None) -> int:
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                as_seconds = self._parse_retry_after_seconds(retry_after)
                if as_seconds is not None:
                    return min(max(as_seconds * 1000, 0), MAX_BACKOFF_MS)

        base = INITIAL_BACKOFF_MS * (2**attempt)
        jitter = random.random() * base * 0.5
        return int(min(base + jitter, MAX_BACKOFF_MS))

    def _parse_retry_after_seconds(self, value: str) -> int | None:
        try:
            seconds = int(float(value.strip()))
            if seconds >= 0:
                return seconds
        except ValueError:
            pass

        try:
            parsed = parsedate_to_datetime(value)
        except (TypeError, ValueError):
            return None

        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)

        delta = parsed - datetime.now(tz=timezone.utc)
        return max(int(delta.total_seconds()), 0)

    def _safe_parse_json(self, response: httpx.Response) -> JsonObject | None:
        try:
            parsed = response.json()
        except ValueError:
            return None
        if isinstance(parsed, dict):
            return parsed
        return None

    def _get_managed_pii_config(self, options: GetPiiConfigOptions | None = None) -> RedactorConfig:
        requested_namespace = (
            options["namespace"]
            if options is not None and "namespace" in options
            else "pii.default"
        )
        response = self._request(
            "GET", f"/api/v1/namespaces/governance-config{build_query_string({'limit': 250})}"
        )
        data = response.get("data") if isinstance(response, dict) else None
        payload = self._resolve_managed_pii_payload(data, requested_namespace)
        if payload is None:
            return RedactorConfig()
        return self._normalize_managed_pii_config(payload)

    def _resolve_managed_pii_payload(
        self, data: Any, requested_namespace: str
    ) -> JsonObject | None:
        if isinstance(data, list):
            records = [entry for entry in data if isinstance(entry, dict)]
            selected_record = next(
                (
                    record
                    for record in records
                    if isinstance(record.get("namespace"), str)
                    and record.get("namespace") == requested_namespace
                ),
                None,
            ) or next(
                (
                    record
                    for record in records
                    if isinstance(record.get("namespace"), str)
                    and record.get("namespace") == "pii.default"
                ),
                None,
            )

            if not isinstance(selected_record, dict):
                return None

            selected_payload = selected_record.get("data")
            return selected_payload if isinstance(selected_payload, dict) else None

        if not isinstance(data, dict):
            return None

        if isinstance(data.get("namespace"), str) and "data" in data:
            namespace = data.get("namespace")
            if namespace not in (requested_namespace, "pii.default"):
                return None
            nested = data.get("data")
            return nested if isinstance(nested, dict) else None

        return data

    def _normalize_managed_pii_config(self, raw: JsonObject) -> RedactorConfig:
        payload_candidate = raw.get("piiConfig") if isinstance(raw.get("piiConfig"), dict) else raw
        if not isinstance(payload_candidate, dict):
            return RedactorConfig()

        payload = cast("JsonObject", payload_candidate)
        config = RedactorConfig()

        if isinstance(payload.get("detectEmails"), bool):
            config.detect_emails = payload["detectEmails"]
        if isinstance(payload.get("detectPhones"), bool):
            config.detect_phones = payload["detectPhones"]
        if isinstance(payload.get("detectApiKeys"), bool):
            config.detect_api_keys = payload["detectApiKeys"]
        if isinstance(payload.get("defaultReplacement"), str):
            config.default_replacement = payload["defaultReplacement"]

        secret_patterns = self._normalize_managed_patterns(payload.get("secretPatterns"), "secret")
        custom_patterns = self._normalize_managed_patterns(payload.get("customPatterns"), "custom")

        if len(secret_patterns) > 0:
            config.secret_patterns = secret_patterns
        if len(custom_patterns) > 0:
            config.custom_patterns = custom_patterns

        return config

    def _normalize_managed_patterns(self, raw: Any, prefix: str) -> list[RedactionPattern]:
        if not isinstance(raw, list):
            return []

        patterns: list[RedactionPattern] = []
        for index, entry in enumerate(raw):
            if not isinstance(entry, dict):
                continue

            source = (
                entry["pattern"]
                if isinstance(entry.get("pattern"), str)
                else entry["source"]
                if isinstance(entry.get("source"), str)
                else None
            )

            if source is None or source == "":
                continue

            flags = self._sanitize_regex_flags(entry.get("flags"))
            try:
                compiled = self._compile_pattern(source, flags)
            except re.error:
                continue

            pattern_type = (
                entry["type"]
                if entry.get("type") in ("email", "phone", "api_key", "custom")
                else "custom"
            )
            pattern_name = (
                entry["name"]
                if isinstance(entry.get("name"), str) and entry["name"] != ""
                else f"{prefix}_{index + 1}"
            )
            replacement = entry.get("replacement")

            patterns.append(
                RedactionPattern(
                    name=pattern_name,
                    pattern=compiled,
                    type=cast("Any", pattern_type),
                    replacement=replacement if isinstance(replacement, str) else None,
                )
            )

        return patterns

    def _sanitize_regex_flags(self, raw: Any) -> str:
        if not isinstance(raw, str) or raw == "":
            return "g"

        allowed = {"g", "i", "m", "s", "u", "y", "d"}
        out = ""
        for char in raw:
            if char in allowed and char not in out:
                out += char
        return out or "g"

    def _compile_pattern(self, source: str, flags: str) -> re.Pattern[str]:
        py_flags = 0
        if "i" in flags:
            py_flags |= re.IGNORECASE
        if "m" in flags:
            py_flags |= re.MULTILINE
        if "s" in flags:
            py_flags |= re.DOTALL
        return re.compile(source, py_flags)

    def stream(self, options: JsonObject) -> EventStreamConnection:
        """Open an SSE connection to the platform stream endpoint."""
        if "onEvent" not in options or not callable(options["onEvent"]):
            raise ValueError("stream requires an 'onEvent' callback")

        token = self._api_key or self._token or ""
        url = f"{self._base_url}/api/v1/stream?token={quote(token, safe='')}"
        event_types = options.get("eventTypes")
        return EventStreamConnection(
            url=url,
            timeout_ms=self._timeout_ms,
            on_event=options["onEvent"],
            event_types=event_types if isinstance(event_types, list) else None,
        )


__all__ = ["DEFAULT_ARELIS_PLATFORM_BASE_URL", "ArelisPlatform"]
