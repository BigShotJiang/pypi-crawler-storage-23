# ruff: noqa: UP013, E501
"""Platform TypedDict contracts for the Arelis Platform API."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias, TypedDict

ArelisPlatformConfig = TypedDict(
    "ArelisPlatformConfig",
    {
        "baseUrl": str,
        "apiKey": str,
        "token": str,
        "maxRetries": float,
        "timeout": float,
    },
    total=False,
)

ManagedPiiPatternDefinition = TypedDict(
    "ManagedPiiPatternDefinition",
    {
        "name": str,
        "pattern": str,
        "source": str,
        "flags": str,
        "type": Literal["email", "phone", "api_key", "custom"],
        "replacement": str,
    },
    total=False,
)

ManagedPiiConfig = TypedDict(
    "ManagedPiiConfig",
    {
        "detectEmails": bool,
        "detectPhones": bool,
        "detectApiKeys": bool,
        "defaultReplacement": str,
        "secretPatterns": list[ManagedPiiPatternDefinition],
        "customPatterns": list[ManagedPiiPatternDefinition],
    },
    total=False,
)

GetPiiConfigOptions = TypedDict(
    "GetPiiConfigOptions",
    {
        "namespace": str,
    },
    total=False,
)

AuditEventInput = TypedDict(
    "AuditEventInput",
    {
        "runId": str,
        "eventType": str,
        "actor": str | dict[str, Any],
        "resource": str | dict[str, Any],
        "action": str,
        "timestamp": str,
        "metadata": dict[str, Any],
        "aiSystemId": str,
    },
    total=False,
)

CreateEventResponse = TypedDict(
    "CreateEventResponse",
    {
        "eventId": str,
        "runId": str,
    },
    total=False,
)

BatchEventInput = TypedDict(
    "BatchEventInput",
    {
        "events": list[Any],
    },
    total=False,
)

BatchEventResult = TypedDict(
    "BatchEventResult",
    {
        "eventId": str | None,
        "status": Literal["accepted", "rejected"],
        "reason": str,
    },
    total=False,
)

BatchEventResponse = TypedDict(
    "BatchEventResponse",
    {
        "results": list[Any],
    },
    total=False,
)

EventRecord = TypedDict(
    "EventRecord",
    {
        "eventId": str,
        "runId": str,
        "eventType": str,
        "actor": Any,
        "resource": Any,
        "action": str,
        "timestamp": str,
        "serverTimestamp": str,
        "metadata": Any,
        "aiSystemId": str | None,
    },
    total=False,
)

ListEventsParams = TypedDict(
    "ListEventsParams",
    {
        "runId": str,
        "eventType": str,
        "startTime": str,
        "endTime": str,
        "cursor": str,
        "limit": float,
        "aiSystemId": str,
    },
    total=False,
)

ListEventsResponse = TypedDict(
    "ListEventsResponse",
    {
        "events": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

ComplianceProofRequest = TypedDict(
    "ComplianceProofRequest",
    {
        "runId": str,
        "schemaVersion": Literal["v1", "v2"],
        "disclosureRuleIds": list[str],
        "composed": dict[str, Any],
        "async": bool,
        "aiSystemId": str,
    },
    total=False,
)

ProofLayer = TypedDict(
    "ProofLayer",
    {
        "name": str,
        "hash": str,
        "verified": bool,
    },
    total=False,
)

CreateProofResponse = TypedDict(
    "CreateProofResponse",
    {
        "proofId": str,
        "runId": str,
        "schemaVersion": str,
        "commitment": Any,
        "proofHash": str,
        "layers": list[Any],
        "createdAt": str,
    },
    total=False,
)

AsyncProofResponse = TypedDict(
    "AsyncProofResponse",
    {
        "jobId": str,
    },
    total=False,
)

ProofRecord = TypedDict(
    "ProofRecord",
    {
        "proofId": str,
        "runId": str,
        "schemaVersion": str,
        "commitment": Any,
        "proofHash": str,
        "layers": list[Any],
        "metadata": Any,
        "aiSystemId": str | None,
        "createdAt": str,
    },
    total=False,
)

ListProofsParams = TypedDict(
    "ListProofsParams",
    {
        "runId": str,
        "cursor": str,
        "limit": float,
        "aiSystemId": str,
    },
    total=False,
)

ListProofsResponse = TypedDict(
    "ListProofsResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

ComplianceVerificationByIdInput = TypedDict(
    "ComplianceVerificationByIdInput",
    {
        "proofId": str,
    },
    total=False,
)

ComplianceVerificationArtifactInput = TypedDict(
    "ComplianceVerificationArtifactInput",
    {
        "proofId": str,
        "runId": str,
        "schemaVersion": Literal["v1", "v2"],
        "commitment": Any,
        "proofHash": str,
        "layers": list[dict[str, Any]],
    },
    total=False,
)

VerificationLayerResult = TypedDict(
    "VerificationLayerResult",
    {
        "name": str,
        "passed": bool,
        "reason": str,
    },
    total=False,
)

VerifyProofResponse = TypedDict(
    "VerifyProofResponse",
    {
        "proofId": str,
        "verified": bool,
        "layers": list[Any],
        "proofHashMismatch": bool,
    },
    total=False,
)

RuntimeRiskInput = TypedDict(
    "RuntimeRiskInput",
    {
        "runId": str,
        "policyDecisions": list[dict[str, Any]],
        "quotaState": dict[str, Any],
        "evaluationSignals": list[dict[str, Any]],
        "explicitSignals": dict[str, Any],
        "aiSystemId": str,
    },
    total=False,
)

RiskFactor = TypedDict(
    "RiskFactor",
    {
        "name": str,
        "score": float,
        "weight": float,
    },
    total=False,
)

RiskEvaluationResponse = TypedDict(
    "RiskEvaluationResponse",
    {
        "id": str,
        "runId": str,
        "action": str,
        "score": float,
        "factors": list[Any],
        "deterministicInputsHash": str,
        "approvalId": str | None,
    },
    total=False,
)

RiskRouterConfig = TypedDict(
    "RiskRouterConfig",
    {
        "mode": Literal["adaptive", "strict", "permissive"],
        "thresholds": dict[str, Any],
        "defaultAction": Literal["allow", "flag", "block", "escalate"],
    },
    total=False,
)

RiskDecisionRecord = TypedDict(
    "RiskDecisionRecord",
    {
        "id": str,
        "runId": str,
        "action": str,
        "score": float,
        "factors": Any,
        "deterministicInputsHash": str,
        "aiSystemId": str | None,
        "createdAt": str,
    },
    total=False,
)

ListDecisionsParams = TypedDict(
    "ListDecisionsParams",
    {
        "runId": str,
        "action": Literal["allow", "flag", "block", "escalate"],
        "minScore": float,
        "maxScore": float,
        "startTime": str,
        "endTime": str,
        "cursor": str,
        "limit": float,
        "aiSystemId": str,
    },
    total=False,
)

ListDecisionsResponse = TypedDict(
    "ListDecisionsResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

ReplayRequest = TypedDict(
    "ReplayRequest",
    {
        "runId": str,
        "replaySnapshot": dict[str, Any],
        "aiSystemId": str,
    },
    total=False,
)

CausalGraphReplayRequest = TypedDict(
    "CausalGraphReplayRequest",
    {
        "runId": str,
        "nodes": list[dict[str, Any]],
        "edges": list[dict[str, Any]],
        "replaySnapshot": dict[str, Any],
    },
    total=False,
)

AsyncJobResponse = TypedDict(
    "AsyncJobResponse",
    {
        "jobId": str,
    },
    total=False,
)

ReplayStepRecord = TypedDict(
    "ReplayStepRecord",
    {
        "index": float,
        "eventId": str,
        "status": Literal["match", "drift", "missing"],
        "eventType": str,
        "action": str,
        "timestamp": str,
    },
    total=False,
)

ReplayDriftDiagnosticRecord = TypedDict(
    "ReplayDriftDiagnosticRecord",
    {
        "field": str,
        "expected": Any,
        "actual": Any,
        "severity": Any,
    },
    total=False,
)

ReplayResultResponse = TypedDict(
    "ReplayResultResponse",
    {
        "replayId": str,
        "runId": str,
        "steps": list[Any] | Any,
        "warnings": list[str] | Any,
        "driftDiagnostics": list[Any] | Any,
        "createdAt": str,
    },
    total=False,
)

ReplayListParams = TypedDict(
    "ReplayListParams",
    {
        "runId": str,
        "status": Literal["pending", "processing", "completed", "failed"],
        "cursor": str,
        "limit": float,
    },
    total=False,
)

ReplayListItem = TypedDict(
    "ReplayListItem",
    {
        "jobId": str,
        "replayId": str | None,
        "runId": str,
        "status": Literal["pending", "processing", "completed", "failed"],
        "stepsCount": float,
        "warningsCount": float,
        "driftCount": float,
        "createdAt": str,
        "completedAt": str | None,
        "error": str | None,
    },
    total=False,
)

ReplayListResponse = TypedDict(
    "ReplayListResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

CausalGraphResponse = TypedDict(
    "CausalGraphResponse",
    {
        "id": str,
        "runId": str,
        "nodes": list[dict[str, Any]],
        "edges": list[dict[str, Any]],
        "digestMetadata": dict[str, Any],
        "rootHash": str | None,
        "createdAt": str,
    },
    total=False,
)

GraphCommitResponse = TypedDict(
    "GraphCommitResponse",
    {
        "runId": str,
        "rootHash": str,
        "committedAt": str,
    },
    total=False,
)

GraphLineageResponse = TypedDict(
    "GraphLineageResponse",
    {
        "runId": str,
        "nodeId": str,
        "nodes": list[dict[str, Any]],
        "edges": list[dict[str, Any]],
        "ancestorCount": float,
        "descendantCount": float,
    },
    total=False,
)

PolicyEvaluateInput = TypedDict(
    "PolicyEvaluateInput",
    {
        "runId": str,
        "policies": list[Any],
        "checkpoint": dict[str, Any],
        "policyIds": list[str],
    },
    total=False,
)

PolicyEvaluateResponse = TypedDict(
    "PolicyEvaluateResponse",
    {
        "runId": str,
        "decisions": list[Any],
        "evaluatedAt": str,
        "policySetHash": str | None,
        "evaluatedPolicies": list[dict[str, Any]],
    },
    total=False,
)

GovernanceSnapshotResponse = TypedDict(
    "GovernanceSnapshotResponse",
    {
        "runId": str,
        "policyHash": str | None,
        "modelRoute": str | None,
        "toolRegistryHash": str | None,
        "configStateHash": str | None,
        "rootHash": str | None,
        "committedAt": str | None,
        "related": dict[str, Any],
    },
    total=False,
)

ManagedPolicy = TypedDict(
    "ManagedPolicy",
    {
        "id": str,
        "orgId": str,
        "projectId": str,
        "key": str,
        "name": str,
        "description": str | None,
        "status": str,
        "priority": float,
        "activeVersion": float | None,
        "deletedAt": str | None,
        "createdAt": str,
        "updatedAt": str,
    },
    total=False,
)

ManagedPolicyVersion = TypedDict(
    "ManagedPolicyVersion",
    {
        "id": str,
        "policyId": str,
        "version": float,
        "condition": Any,
        "action": str,
        "severity": str,
        "metadata": Any,
        "changeSummary": str | None,
        "createdBy": str | None,
        "createdAt": str,
    },
    total=False,
)

CreatePolicyInput = TypedDict(
    "CreatePolicyInput",
    {
        "key": str,
        "name": str,
        "description": str,
        "condition": Any,
        "action": str,
        "severity": str,
        "priority": float,
    },
    total=False,
)

UpdatePolicyInput = TypedDict(
    "UpdatePolicyInput",
    {
        "name": str,
        "description": str,
        "status": str,
        "priority": float,
        "newVersion": dict[str, Any],
    },
    total=False,
)

CreateVersionInput = TypedDict(
    "CreateVersionInput",
    {
        "condition": Any,
        "action": str,
        "severity": str,
        "changeSummary": str,
        "metadata": dict[str, Any],
    },
    total=False,
)

ActivateVersionInput = TypedDict(
    "ActivateVersionInput",
    {
        "version": float,
    },
    total=False,
)

TransitionPolicyInput = TypedDict(
    "TransitionPolicyInput",
    {
        "targetStatus": Literal["draft", "review", "active", "disabled", "archived"],
        "reason": str,
    },
    total=False,
)

TransitionPolicyResponse = TypedDict(
    "TransitionPolicyResponse",
    {
        "id": str,
        "status": str,
        "previousStatus": str,
    },
    total=False,
)

RollbackPolicyInput = TypedDict(
    "RollbackPolicyInput",
    {
        "targetVersion": float,
        "reason": str,
    },
    total=False,
)

RollbackPolicyResponse = TypedDict(
    "RollbackPolicyResponse",
    {
        "id": str,
        "activeVersion": float,
        "previousVersion": float | None,
        "status": str,
    },
    total=False,
)

PolicySimulateInput = TypedDict(
    "PolicySimulateInput",
    {
        "checkpoint": dict[str, Any],
    },
    total=False,
)

PolicySimulateResponse = TypedDict(
    "PolicySimulateResponse",
    {
        "simulation": Any,
        "policyId": str,
        "decisions": list[Any],
        "summary": dict[str, Any],
        "simulatedAt": str,
    },
    total=False,
)

BulkPolicySimulateInput = TypedDict(
    "BulkPolicySimulateInput",
    {
        "checkpoint": dict[str, Any],
        "policyIds": list[str],
    },
    total=False,
)

BulkPolicySimulateResponse = TypedDict(
    "BulkPolicySimulateResponse",
    {
        "simulation": Any,
        "decisions": list[Any],
        "summary": dict[str, Any],
        "policies": float,
        "simulatedAt": str,
    },
    total=False,
)

PolicyImpactInput = TypedDict(
    "PolicyImpactInput",
    {
        "proposedVersion": dict[str, Any],
        "sampleCheckpoints": list[dict[str, Any]],
    },
    total=False,
)

PolicyImpactResponse = TypedDict(
    "PolicyImpactResponse",
    {
        "policyId": str,
        "sampleCount": float,
        "comparison": list[dict[str, Any]],
        "changeRate": float,
        "analyzedAt": str,
    },
    total=False,
)

RiskSimulateInput = TypedDict(
    "RiskSimulateInput",
    {
        "runId": str,
        "policyDecisions": list[dict[str, Any]],
        "quotaState": dict[str, Any],
        "evaluationSignals": list[dict[str, Any]],
        "explicitSignals": dict[str, Any],
        "configOverrides": Any,
    },
    total=False,
)

RiskSimulateResponse = TypedDict(
    "RiskSimulateResponse",
    {
        "simulation": Any,
        "runId": str,
        "score": float,
        "factors": list[Any],
        "simulatedAction": str,
        "currentAction": str,
        "actionChanged": bool,
        "configUsed": Any,
        "policyResults": list[Any],
        "simulatedAt": str,
    },
    total=False,
)

RiskConfigVersionRecord = TypedDict(
    "RiskConfigVersionRecord",
    {
        "version": float,
        "config": Any,
        "status": Literal["draft", "active", "archived"],
        "hash": str,
        "createdAt": str,
        "createdBy": str | None,
        "changeSummary": str | None,
    },
    total=False,
)

RiskConfigResponse = TypedDict(
    "RiskConfigResponse",
    {
        "config": Any,
        "activeVersion": float,
        "status": str,
        "totalVersions": float,
        "draft": dict[str, Any],
    },
    total=False,
)

RiskConfigDraftInput = TypedDict(
    "RiskConfigDraftInput",
    {
        "config": Any,
        "changeSummary": str,
    },
    total=False,
)

RiskConfigRollbackInput = TypedDict(
    "RiskConfigRollbackInput",
    {
        "targetVersion": float,
        "reason": str,
    },
    total=False,
)

ListPoliciesParams = TypedDict(
    "ListPoliciesParams",
    {
        "status": str,
        "search": str,
        "includeDeleted": bool,
        "cursor": str,
        "limit": float,
    },
    total=False,
)

ListPoliciesResponse = TypedDict(
    "ListPoliciesResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

CreateApiKeyInput = TypedDict(
    "CreateApiKeyInput",
    {
        "name": str,
        "scopes": list[str],
        "expiresAt": str,
    },
    total=False,
)

CreateApiKeyResponse = TypedDict(
    "CreateApiKeyResponse",
    {
        "id": str,
        "prefix": str,
        "name": str,
        "scopes": list[str],
        "rawKey": str,
        "createdAt": str,
        "expiresAt": str | None,
    },
    total=False,
)

ApiKeyRecord = TypedDict(
    "ApiKeyRecord",
    {
        "id": str,
        "prefix": str,
        "name": str,
        "scopes": list[str],
        "createdAt": str,
        "expiresAt": str | None,
        "revokedAt": str | None,
    },
    total=False,
)

ListApiKeysResponse = TypedDict(
    "ListApiKeysResponse",
    {
        "data": list[Any],
    },
    total=False,
)

UpdateApiKeyInput = TypedDict(
    "UpdateApiKeyInput",
    {
        "name": str,
        "scopes": list[str],
    },
    total=False,
)

UsageOperationSummary = TypedDict(
    "UsageOperationSummary",
    {
        "operationType": str,
        "used": float,
        "limit": float | None,
        "percentage": float | None,
    },
    total=False,
)

UsageSummaryResponse = TypedDict(
    "UsageSummaryResponse",
    {
        "operations": list[Any],
    },
    total=False,
)

UsageHistoryEntry = TypedDict(
    "UsageHistoryEntry",
    {
        "date": str,
        "audit_event": float,
        "compliance_proof": float,
        "risk_decision": float,
        "replay_verification": float,
    },
    total=False,
)

UsageHistoryResponse = TypedDict(
    "UsageHistoryResponse",
    {
        "entries": list[Any],
    },
    total=False,
)

StreamConnection = TypedDict("StreamConnection", {}, total=False)

JobStatusResponse = TypedDict(
    "JobStatusResponse",
    {
        "jobId": str,
        "type": Literal["proof", "replay", "export"],
        "status": str,
        "runId": str | None,
        "request": Any,
        "result": Any,
        "createdAt": str,
        "completedAt": str | None,
        "retryEligible": bool,
    },
    total=False,
)

ListJobsParams = TypedDict(
    "ListJobsParams",
    {
        "type": Literal["proof", "replay", "export"],
        "status": Literal["pending", "processing", "completed", "failed", "cancelled"],
        "runId": str,
        "startTime": str,
        "endTime": str,
        "cursor": str,
        "limit": float,
    },
    total=False,
)

JobListItem = TypedDict(
    "JobListItem",
    {
        "jobId": str,
        "type": Literal["proof", "replay", "export"],
        "runId": str | None,
        "status": str,
        "createdAt": str,
        "completedAt": str | None,
        "durationMs": float | None,
        "errorSummary": str | None,
        "result": Any,
        "request": Any,
    },
    total=False,
)

JobListResponse = TypedDict(
    "JobListResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

RetryJobResponse = TypedDict(
    "RetryJobResponse",
    {
        "jobId": str,
        "type": Literal["proof", "replay", "export"],
        "retriedFrom": str,
        "retryEligible": bool,
    },
    total=False,
)

GraphListParams = TypedDict(
    "GraphListParams",
    {
        "runId": str,
        "startTime": str,
        "endTime": str,
        "cursor": str,
        "limit": float,
    },
    total=False,
)

GraphListItem = TypedDict(
    "GraphListItem",
    {
        "id": str,
        "runId": str,
        "rootHash": str | None,
        "committedAt": str | None,
        "createdAt": str,
        "nodeCount": float,
        "edgeCount": float,
    },
    total=False,
)

GraphListResponse = TypedDict(
    "GraphListResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

PolicyEvaluationHistoryRecord = TypedDict(
    "PolicyEvaluationHistoryRecord",
    {
        "id": str,
        "runId": str | None,
        "policySource": str,
        "policyCount": float,
        "decisions": Any,
        "checkpoint": Any,
        "policySetHash": str | None,
        "evaluatedAt": str,
    },
    total=False,
)

PolicyEvaluationHistoryResponse = TypedDict(
    "PolicyEvaluationHistoryResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

EventCountParams = TypedDict(
    "EventCountParams",
    {
        "runId": str,
        "eventType": str,
        "startTime": str,
        "endTime": str,
    },
    total=False,
)

EventCountResponse = TypedDict(
    "EventCountResponse",
    {
        "count": float,
    },
    total=False,
)

ReplayTemplate = TypedDict(
    "ReplayTemplate",
    {
        "id": str,
        "name": str,
        "description": str | None,
        "runId": str | None,
        "snapshot": dict[str, Any],
        "createdAt": str,
        "updatedAt": str,
    },
    total=False,
)

ReplayTemplateInput = TypedDict(
    "ReplayTemplateInput",
    {
        "name": str,
        "description": str,
        "runId": str,
        "snapshot": dict[str, Any],
    },
    total=False,
)

ReplayTemplateListResponse = TypedDict(
    "ReplayTemplateListResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

ReplayCompareInput = TypedDict(
    "ReplayCompareInput",
    {
        "runId": str,
        "baselineReplayId": str,
        "candidateReplayId": str,
        "setAsBaseline": bool,
        "baselineTemplateId": str,
        "notes": str,
    },
    total=False,
)

ReplayCompareResponse = TypedDict(
    "ReplayCompareResponse",
    {
        "runId": str,
        "baselineReplayId": str,
        "candidateReplayId": str,
        "comparedAt": str,
        "summary": dict[str, Any],
        "rows": dict[str, Any],
        "links": dict[str, Any],
    },
    total=False,
)

MilestoneConfigRecord = TypedDict(
    "MilestoneConfigRecord",
    {
        "operationType": str,
        "thresholds": list[float],
        "notificationsEnabled": bool,
        "webhookUrl": str | None,
        "currentUsage": float,
        "limit": float | None,
    },
    total=False,
)

MilestoneConfigResponse = TypedDict(
    "MilestoneConfigResponse",
    {
        "data": list[Any],
    },
    total=False,
)

MilestoneConfigInput = TypedDict(
    "MilestoneConfigInput",
    {
        "operationType": Literal[
            "audit_event", "compliance_proof", "risk_decision", "replay_verification"
        ],
        "thresholds": list[float],
        "notificationsEnabled": bool,
        "webhookUrl": str | None,
    },
    total=False,
)

MilestoneDeliveryRecord = TypedDict(
    "MilestoneDeliveryRecord",
    {
        "id": str,
        "orgId": str,
        "projectId": str,
        "operationType": str,
        "milestone": float,
        "currentUsage": float,
        "limit": float,
        "webhookUrl": str | None,
        "status": str,
        "responseCode": float | None,
        "error": str | None,
        "createdAt": str,
    },
    total=False,
)

MilestoneDeliveryListResponse = TypedDict(
    "MilestoneDeliveryListResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

TelemetryReportListResponse = TypedDict(
    "TelemetryReportListResponse",
    {
        "data": list[dict[str, Any]],
        "nextCursor": str | None,
    },
    total=False,
)

TelemetryChallengeListResponse = TypedDict(
    "TelemetryChallengeListResponse",
    {
        "data": list[dict[str, Any]],
        "nextCursor": str | None,
    },
    total=False,
)

BillingSummaryResponse = TypedDict(
    "BillingSummaryResponse",
    {
        "organization": dict[str, Any],
        "currency": str,
        "currentScenario": dict[str, Any],
        "comparison": dict[str, Any],
    },
    total=False,
)

OrganizationResponse = TypedDict(
    "OrganizationResponse",
    {
        "id": str,
        "name": str,
        "slug": str,
        "region": str,
        "complianceProfile": str,
        "dataRetentionPolicy": str,
        "tier": str,
        "createdAt": str,
    },
    total=False,
)

QuotaResponse = TypedDict(
    "QuotaResponse",
    {
        "data": list[dict[str, Any]],
    },
    total=False,
)

CreateExportInput = TypedDict(
    "CreateExportInput",
    {
        "resource": Any,
        "format": Any,
        "filters": dict[str, Any],
        "includeFields": list[str],
    },
    total=False,
)

CreateExportResponse = TypedDict(
    "CreateExportResponse",
    {
        "exportId": str,
        "resource": Any,
        "format": Any,
        "status": Any,
        "createdAt": str,
    },
    total=False,
)

ListExportsParams = TypedDict(
    "ListExportsParams",
    {
        "resource": Any,
        "status": Any,
        "cursor": str,
        "limit": float,
    },
    total=False,
)

ExportRecord = TypedDict(
    "ExportRecord",
    {
        "exportId": str,
        "resource": Any,
        "format": Any,
        "status": Any,
        "rowCount": float | None,
        "checksumSha256": str | None,
        "failureReason": str | None,
        "createdAt": str,
        "startedAt": str | None,
        "completedAt": str | None,
        "expiresAt": str | None,
    },
    total=False,
)

ExportDetailRecord = TypedDict(
    "ExportDetailRecord",
    {
        "filters": dict[str, Any],
        "includeFields": list[str],
        "artifactFileName": str | None,
        "artifactMimeType": str | None,
        "artifactSizeBytes": float | None,
    },
    total=False,
)

ListExportsResponse = TypedDict(
    "ListExportsResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

DownloadExportResponse = TypedDict(
    "DownloadExportResponse",
    {
        "file_name": str,
        "mime_type": str,
        "content": str,
    },
    total=False,
)

ApprovalRecord = TypedDict(
    "ApprovalRecord",
    {
        "id": str,
        "runId": str,
        "eventType": str,
        "source": str,
        "status": Any,
        "reason": str,
        "context": Any,
        "decidedBy": str | None,
        "decidedAt": str | None,
        "createdAt": str,
    },
    total=False,
)

ApprovalResolveInput = TypedDict(
    "ApprovalResolveInput",
    {
        "decision": Literal["approved", "denied"],
        "decidedBy": str,
        "notes": str,
    },
    total=False,
)

ApprovalResolveResponse = TypedDict(
    "ApprovalResolveResponse",
    {
        "approvalId": str,
        "status": str,
        "alreadyResolved": bool,
    },
    total=False,
)

ApprovalConfigInput = TypedDict(
    "ApprovalConfigInput",
    {
        "autoApprove": bool,
        "autoApproveRules": list[Any],
        "timeoutMs": float | None,
        "escalationPolicy": Any | None,
    },
    total=False,
)

ApprovalConfig = TypedDict(
    "ApprovalConfig",
    {
        "autoApprove": bool,
        "autoApproveRules": list[Any],
        "timeoutMs": float | None,
        "escalationPolicy": Any | None,
        "updatedAt": str,
    },
    total=False,
)

ApprovalListResponse = TypedDict(
    "ApprovalListResponse",
    {
        "data": list[Any],
        "config": Any | None,
        "pagination": dict[str, Any],
    },
    total=False,
)

AiSystemInput = TypedDict(
    "AiSystemInput",
    {
        "name": str,
        "type": Any,
        "provider": str,
        "modelRef": str,
        "version": str,
        "description": str,
        "config": dict[str, Any],
        "metadata": dict[str, Any],
        "tags": list[str],
    },
    total=False,
)

AiSystemUpdateInput = TypedDict(
    "AiSystemUpdateInput",
    {
        "name": str,
        "type": Any,
        "provider": str | None,
        "modelRef": str | None,
        "version": str | None,
        "status": Any,
        "description": str | None,
        "config": dict[str, Any],
        "metadata": dict[str, Any],
        "tags": list[str] | None,
    },
    total=False,
)

AiSystemRecord = TypedDict(
    "AiSystemRecord",
    {
        "id": str,
        "slug": str,
        "name": str,
        "type": Any,
        "provider": str | None,
        "modelRef": str | None,
        "version": str | None,
        "status": Any,
        "isDefault": bool,
        "description": str | None,
        "config": Any,
        "metadata": Any,
        "tags": list[str],
        "createdAt": str,
        "updatedAt": str,
    },
    total=False,
)

ListAiSystemsParams = TypedDict(
    "ListAiSystemsParams",
    {
        "type": Any,
        "status": Any,
        "provider": str,
        "tag": str,
        "search": str,
        "cursor": str,
        "limit": float,
    },
    total=False,
)

ListAiSystemsResponse = TypedDict(
    "ListAiSystemsResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

AiSystemSummaryParams = TypedDict(
    "AiSystemSummaryParams",
    {
        "start": str,
        "end": str,
    },
    total=False,
)

AiSystemSummary = TypedDict(
    "AiSystemSummary",
    {
        "aiSystem": dict[str, Any],
        "period": dict[str, Any],
        "events": dict[str, Any],
        "risk": dict[str, Any],
        "proofs": dict[str, Any],
        "policies": dict[str, Any],
    },
    total=False,
)

MCPToolEvaluateInput = TypedDict(
    "MCPToolEvaluateInput",
    {
        "runId": str,
        "serverId": str,
        "toolName": str,
        "toolArgs": dict[str, Any],
        "policyIds": list[str],
        "actor": dict[str, Any],
        "serverTrustLevel": float,
        "toolCapability": str,
        "transportType": str,
    },
    total=False,
)

MCPToolPiiFinding = TypedDict(
    "MCPToolPiiFinding",
    {
        "type": str,
        "original": str,
        "pattern": str,
    },
    total=False,
)

MCPToolEvaluateResponse = TypedDict(
    "MCPToolEvaluateResponse",
    {
        "runId": str,
        "decision": Literal["allow", "deny", "escalate"],
        "pii": dict[str, Any],
        "policy": dict[str, Any],
        "evaluatedAt": str,
        "approvalId": str | None,
    },
    total=False,
)

CreateMcpServerInput = TypedDict(
    "CreateMcpServerInput",
    {
        "name": str,
        "uri": str,
        "transportType": Any,
        "slug": str,
        "trustLevel": float,
        "description": str,
        "tags": list[str],
        "capabilities": dict[str, Any],
        "config": dict[str, Any],
        "metadata": dict[str, Any],
    },
    total=False,
)

UpdateMcpServerInput = TypedDict(
    "UpdateMcpServerInput",
    {
        "name": str,
        "uri": str,
        "transportType": Any,
        "trustLevel": float,
        "description": str | None,
        "tags": list[str],
        "capabilities": dict[str, Any],
        "config": dict[str, Any],
        "metadata": dict[str, Any],
    },
    total=False,
)

McpServerRecord = TypedDict(
    "McpServerRecord",
    {
        "id": str,
        "slug": str,
        "name": str,
        "uri": str,
        "transportType": Any,
        "trustLevel": float,
        "status": Any,
        "healthStatus": Any,
        "lastHealthCheckAt": str | None,
        "toolRegistryHash": str | None,
        "capabilities": Any,
        "config": Any,
        "metadata": Any,
        "tags": list[str] | None,
        "description": str | None,
        "createdAt": str,
        "updatedAt": str,
        "_count": dict[str, Any],
        "toolCounts": dict[str, Any],
        "linkedSystemCount": float,
    },
    total=False,
)

ListMcpServersParams = TypedDict(
    "ListMcpServersParams",
    {
        "status": Any,
        "transportType": Any,
        "healthStatus": Any,
        "search": str,
        "trustLevelMin": float,
        "trustLevelMax": float,
        "cursor": str,
        "limit": float,
    },
    total=False,
)

ListMcpServersResponse = TypedDict(
    "ListMcpServersResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

McpServerToolRecord = TypedDict(
    "McpServerToolRecord",
    {
        "id": str,
        "name": str,
        "description": str | None,
        "inputSchema": Any,
        "capability": Any,
        "status": Any,
        "metadata": Any,
        "lastSeenAt": str,
        "createdAt": str,
    },
    total=False,
)

CreateMcpServerToolInput = TypedDict(
    "CreateMcpServerToolInput",
    {
        "name": str,
        "description": str,
        "inputSchema": dict[str, Any],
        "capability": Any,
        "metadata": dict[str, Any],
    },
    total=False,
)

UpdateMcpServerToolInput = TypedDict(
    "UpdateMcpServerToolInput",
    {
        "status": Any,
        "capability": Any,
        "metadata": dict[str, Any],
    },
    total=False,
)

McpServerHealthLogRecord = TypedDict(
    "McpServerHealthLogRecord",
    {
        "id": str,
        "status": str,
        "latencyMs": float | None,
        "errorMessage": str | None,
        "checkedAt": str,
    },
    total=False,
)

HealthCheckResult = TypedDict(
    "HealthCheckResult",
    {
        "status": str,
        "latencyMs": float | None,
        "errorMessage": str | None,
        "checkedAt": str,
    },
    total=False,
)

ToolRefreshResult = TypedDict(
    "ToolRefreshResult",
    {
        "added": list[Any],
        "updated": list[Any],
        "deprecated": list[Any],
        "unchanged": float,
        "toolRegistryHash": str,
    },
    total=False,
)

McpServerUsageRecord = TypedDict(
    "McpServerUsageRecord",
    {
        "id": str,
        "serverId": str,
        "systemId": str,
        "tools": Any,
        "createdAt": str,
    },
    total=False,
)

LinkedSystemRecord = TypedDict(
    "LinkedSystemRecord",
    {
        "id": str,
        "system": dict[str, Any],
        "tools": Any,
        "createdAt": str,
    },
    total=False,
)

NamespaceRecord = TypedDict(
    "NamespaceRecord",
    {
        "id": str,
        "namespace": str,
        "data": dict[str, Any],
        "createdAt": str,
        "updatedAt": str,
    },
    total=False,
)

NamespaceListResponse = TypedDict(
    "NamespaceListResponse",
    {
        "data": list[Any],
        "nextCursor": str | None,
    },
    total=False,
)

NamespaceListParams = TypedDict(
    "NamespaceListParams",
    {
        "cursor": str,
        "limit": float,
    },
    total=False,
)

AiSystemsMethods = TypedDict("AiSystemsMethods", {}, total=False)

McpServersMethods = TypedDict("McpServersMethods", {}, total=False)

ComplianceVerificationInput: TypeAlias = (
    ComplianceVerificationByIdInput | ComplianceVerificationArtifactInput
)

MCPGovernedInvokeInput: TypeAlias = dict[str, Any]

MCPGovernedInvokeResult: TypeAlias = dict[str, Any]

ReplayDriftSeverity: TypeAlias = Literal["low", "medium", "high"]

ExportResource: TypeAlias = Literal[
    "events",
    "proofs",
    "risk_decisions",
    "replays",
    "jobs",
    "integrity",
    "telemetry_reports",
    "telemetry_challenges",
    "usage_summary",
    "usage_history",
    "metering_milestones",
    "metering_deliveries",
    "policies",
    "policy_evaluations",
    "graphs",
]

ExportFormat: TypeAlias = Literal["json", "csv"]

ExportStatus: TypeAlias = Literal["pending", "processing", "completed", "failed", "expired"]

ApprovalStatus: TypeAlias = Literal["pending", "approved", "denied", "expired"]

ApprovalSource: TypeAlias = Literal["policy_escalation", "risk_escalation", "manual"]

AiSystemType: TypeAlias = Literal["model", "agent", "pipeline", "tool_chain"]

AiSystemStatus: TypeAlias = Literal["active", "archived", "deprecated"]

McpTransportType: TypeAlias = Literal["http", "stdio", "sse"]

McpServerStatus: TypeAlias = Literal["active", "archived"]

McpHealthStatus: TypeAlias = Literal["healthy", "unhealthy", "unknown"]

McpToolCapability: TypeAlias = Literal["read", "write", "execute", "admin"]

McpToolStatus: TypeAlias = Literal["active", "disabled", "deprecated"]

PlatformComplianceProofRequest: TypeAlias = ComplianceProofRequest
PlatformComplianceVerificationInput: TypeAlias = ComplianceVerificationInput
PlatformApprovalResolveInput: TypeAlias = ApprovalResolveInput

__all__ = [
    "ArelisPlatformConfig",
    "ManagedPiiPatternDefinition",
    "ManagedPiiConfig",
    "GetPiiConfigOptions",
    "AuditEventInput",
    "CreateEventResponse",
    "BatchEventInput",
    "BatchEventResult",
    "BatchEventResponse",
    "EventRecord",
    "ListEventsParams",
    "ListEventsResponse",
    "ComplianceProofRequest",
    "ProofLayer",
    "CreateProofResponse",
    "AsyncProofResponse",
    "ProofRecord",
    "ListProofsParams",
    "ListProofsResponse",
    "ComplianceVerificationByIdInput",
    "ComplianceVerificationArtifactInput",
    "VerificationLayerResult",
    "VerifyProofResponse",
    "RuntimeRiskInput",
    "RiskFactor",
    "RiskEvaluationResponse",
    "RiskRouterConfig",
    "RiskDecisionRecord",
    "ListDecisionsParams",
    "ListDecisionsResponse",
    "ReplayRequest",
    "CausalGraphReplayRequest",
    "AsyncJobResponse",
    "ReplayStepRecord",
    "ReplayDriftDiagnosticRecord",
    "ReplayResultResponse",
    "ReplayListParams",
    "ReplayListItem",
    "ReplayListResponse",
    "CausalGraphResponse",
    "GraphCommitResponse",
    "GraphLineageResponse",
    "PolicyEvaluateInput",
    "PolicyEvaluateResponse",
    "GovernanceSnapshotResponse",
    "ManagedPolicy",
    "ManagedPolicyVersion",
    "CreatePolicyInput",
    "UpdatePolicyInput",
    "CreateVersionInput",
    "ActivateVersionInput",
    "TransitionPolicyInput",
    "TransitionPolicyResponse",
    "RollbackPolicyInput",
    "RollbackPolicyResponse",
    "PolicySimulateInput",
    "PolicySimulateResponse",
    "BulkPolicySimulateInput",
    "BulkPolicySimulateResponse",
    "PolicyImpactInput",
    "PolicyImpactResponse",
    "RiskSimulateInput",
    "RiskSimulateResponse",
    "RiskConfigVersionRecord",
    "RiskConfigResponse",
    "RiskConfigDraftInput",
    "RiskConfigRollbackInput",
    "ListPoliciesParams",
    "ListPoliciesResponse",
    "CreateApiKeyInput",
    "CreateApiKeyResponse",
    "ApiKeyRecord",
    "ListApiKeysResponse",
    "UpdateApiKeyInput",
    "UsageOperationSummary",
    "UsageSummaryResponse",
    "UsageHistoryEntry",
    "UsageHistoryResponse",
    "StreamConnection",
    "JobStatusResponse",
    "ListJobsParams",
    "JobListItem",
    "JobListResponse",
    "RetryJobResponse",
    "GraphListParams",
    "GraphListItem",
    "GraphListResponse",
    "PolicyEvaluationHistoryRecord",
    "PolicyEvaluationHistoryResponse",
    "EventCountParams",
    "EventCountResponse",
    "ReplayTemplate",
    "ReplayTemplateInput",
    "ReplayTemplateListResponse",
    "ReplayCompareInput",
    "ReplayCompareResponse",
    "MilestoneConfigRecord",
    "MilestoneConfigResponse",
    "MilestoneConfigInput",
    "MilestoneDeliveryRecord",
    "MilestoneDeliveryListResponse",
    "TelemetryReportListResponse",
    "TelemetryChallengeListResponse",
    "BillingSummaryResponse",
    "OrganizationResponse",
    "QuotaResponse",
    "CreateExportInput",
    "CreateExportResponse",
    "ListExportsParams",
    "ExportRecord",
    "ExportDetailRecord",
    "ListExportsResponse",
    "DownloadExportResponse",
    "ApprovalRecord",
    "ApprovalResolveInput",
    "ApprovalResolveResponse",
    "ApprovalConfigInput",
    "ApprovalConfig",
    "ApprovalListResponse",
    "AiSystemInput",
    "AiSystemUpdateInput",
    "AiSystemRecord",
    "ListAiSystemsParams",
    "ListAiSystemsResponse",
    "AiSystemSummaryParams",
    "AiSystemSummary",
    "MCPToolEvaluateInput",
    "MCPToolPiiFinding",
    "MCPToolEvaluateResponse",
    "MCPGovernedInvokeInput",
    "MCPGovernedInvokeResult",
    "CreateMcpServerInput",
    "UpdateMcpServerInput",
    "McpServerRecord",
    "ListMcpServersParams",
    "ListMcpServersResponse",
    "McpServerToolRecord",
    "CreateMcpServerToolInput",
    "UpdateMcpServerToolInput",
    "McpServerHealthLogRecord",
    "HealthCheckResult",
    "ToolRefreshResult",
    "McpServerUsageRecord",
    "LinkedSystemRecord",
    "NamespaceRecord",
    "NamespaceListResponse",
    "NamespaceListParams",
    "AiSystemsMethods",
    "McpServersMethods",
    "ComplianceVerificationInput",
    "ReplayDriftSeverity",
    "ExportResource",
    "ExportFormat",
    "ExportStatus",
    "ApprovalStatus",
    "ApprovalSource",
    "AiSystemType",
    "AiSystemStatus",
    "McpTransportType",
    "McpServerStatus",
    "McpHealthStatus",
    "McpToolCapability",
    "McpToolStatus",
    "PlatformComplianceProofRequest",
    "PlatformComplianceVerificationInput",
    "PlatformApprovalResolveInput",
]
