"""Helpers to bridge local audit-style events to platform event payloads."""

from __future__ import annotations

from typing import Any, TypedDict, cast

from arelis.audit.types import AuditEvent
from arelis.platform.types import AuditEventInput


class PlatformActor(TypedDict):
    """Actor shape for platform event payloads."""

    id: str
    type: str


class PlatformResource(TypedDict):
    """Resource shape for platform event payloads."""

    id: str
    type: str


class PlatformEventBridgeInput(TypedDict, total=False):
    """Input for :func:`create_platform_event`."""

    runId: str
    eventType: str
    context: dict[str, Any]
    actor: PlatformActor
    resource: PlatformResource
    action: str
    timestamp: str
    metadata: dict[str, Any]


__all__ = [
    "PlatformEventBridgeInput",
    "create_platform_event",
    "audit_event_to_platform_event",
]


def create_platform_event(input: PlatformEventBridgeInput) -> AuditEventInput:
    """Create a platform event payload from local context."""
    actor = input.get("actor") or _actor_from_context(input.get("context"))
    resource = input.get("resource") or {"type": "run", "id": str(input["runId"])}
    action = input.get("action") or _default_action_for_event_type(str(input["eventType"]))

    payload: AuditEventInput = {
        "runId": str(input["runId"]),
        "eventType": str(input["eventType"]),
        "actor": cast("dict[str, Any]", actor),
        "resource": cast("dict[str, Any]", resource),
        "action": action,
        "timestamp": input.get("timestamp") or "",
    }

    if payload["timestamp"] == "":
        from datetime import datetime, timezone

        payload["timestamp"] = datetime.now(timezone.utc).isoformat()

    metadata = input.get("metadata")
    if isinstance(metadata, dict):
        payload["metadata"] = metadata

    return payload


def audit_event_to_platform_event(event: AuditEvent) -> AuditEventInput:
    """Convert a local audit event to a platform events.create payload."""
    actor: PlatformActor = {
        "id": event.context.actor.id,
        "type": event.context.actor.type,
    }

    if event.type in ("model.request", "model.response"):
        model_id = getattr(getattr(event, "model", None), "id", "") or "unknown"
        return create_platform_event(
            {
                "runId": event.run_id,
                "eventType": event.type,
                "actor": actor,
                "resource": {"type": "model", "id": str(model_id)},
                "action": _default_action_for_event_type(event.type),
                "timestamp": event.time,
                "metadata": {"schemaVersion": event.schema_version},
            }
        )

    if event.type in ("tool.call", "tool.result"):
        tool_name = getattr(event, "tool_name", "") or "unknown"
        return create_platform_event(
            {
                "runId": event.run_id,
                "eventType": event.type,
                "actor": actor,
                "resource": {"type": "tool", "id": str(tool_name)},
                "action": _default_action_for_event_type(event.type),
                "timestamp": event.time,
                "metadata": {"schemaVersion": event.schema_version},
            }
        )

    if event.type == "agent.step":
        step_type = str(getattr(event, "step_type", "execute"))
        step_number = int(getattr(event, "step_number", 0))
        return create_platform_event(
            {
                "runId": event.run_id,
                "eventType": event.type,
                "actor": actor,
                "resource": {
                    "type": "agent_step",
                    "id": f"{step_type}-{step_number}",
                },
                "action": step_type,
                "timestamp": event.time,
                "metadata": {
                    "schemaVersion": event.schema_version,
                    "stepNumber": step_number,
                },
            }
        )

    return create_platform_event(
        {
            "runId": event.run_id,
            "eventType": event.type,
            "actor": actor,
            "resource": {"type": "run", "id": event.run_id},
            "action": _default_action_for_event_type(event.type),
            "timestamp": event.time,
            "metadata": {"schemaVersion": event.schema_version},
        }
    )


def _actor_from_context(context: dict[str, Any] | None) -> PlatformActor:
    if isinstance(context, dict):
        actor = context.get("actor")
        if isinstance(actor, dict):
            actor_id = actor.get("id")
            actor_type = actor.get("type")
            if (
                isinstance(actor_id, str)
                and actor_id
                and isinstance(actor_type, str)
                and actor_type
            ):
                return {
                    "id": actor_id,
                    "type": actor_type,
                }

    return {
        "id": "arelis-sdk",
        "type": "service",
    }


def _default_action_for_event_type(event_type: str) -> str:
    parts = event_type.split(".")
    if len(parts) > 1 and parts[1] != "":
        return parts[1]
    return "recorded"
