from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal

from arelis.audit.types import (
    AuditEvent,
    AuditEventType,
    AuditPolicyDecision,
    AuditRiskAssessment,
)

__all__ = [
    "CAUSAL_GRAPH_SCHEMA_VERSION",
    "CausalGraphNodeKind",
    "CausalGraphEdgeKind",
    "CausalGraphNode",
    "CausalGraphEdge",
    "CausalGraph",
    "CausalGraphBuilder",
    "LineageTraversalDirection",
    "LineageTraversalInput",
    "LifecycleLineageCategory",
    "build_causal_graph",
    "traverse_lineage",
    "find_inference_runs_from_lifecycle",
    "trace_lifecycle_origins_for_output",
    "assess_policy_risk",
    "PolicyRiskWeights",
]

CAUSAL_GRAPH_SCHEMA_VERSION = "1.0"

CausalGraphNodeKind = Literal["run", "event"]

CausalGraphEdgeKind = Literal[
    "contains",
    "sequence",
    "parent",
    "provisioned",
    "configured",
    "authenticated",
    "discovered",
    "agent_child",
]

LineageTraversalDirection = Literal["forward", "backward"]

LifecycleLineageCategory = Literal["infra", "config", "auth"]


# ---------------------------------------------------------------------------
# Risk assessment
# ---------------------------------------------------------------------------


@dataclass
class PolicyRiskWeights:
    """Configurable weights for policy risk assessment."""

    allow_level: Literal["low", "medium", "high", "critical"] = "low"
    allow_score: float = 0.1
    transform_level: Literal["low", "medium", "high", "critical"] = "medium"
    transform_score: float = 0.55
    require_approval_level: Literal["low", "medium", "high", "critical"] = "high"
    require_approval_score: float = 0.75
    block_level: Literal["low", "medium", "high", "critical"] = "critical"
    block_score: float = 0.9


_DEFAULT_WEIGHTS = PolicyRiskWeights()


def assess_policy_risk(
    decisions: list[AuditPolicyDecision],
    weights: PolicyRiskWeights | None = None,
) -> AuditRiskAssessment | None:
    """Assess policy risk from a list of policy decisions."""
    if not decisions:
        return None

    w = weights if weights is not None else _DEFAULT_WEIGHTS

    factors = [
        f"{d.effect}:{d.reason}" if d.reason else d.effect for d in decisions if d.effect != "allow"
    ]

    if any(d.effect == "block" for d in decisions):
        return AuditRiskAssessment(level=w.block_level, score=w.block_score, factors=factors)

    if any(d.effect == "require_approval" for d in decisions):
        return AuditRiskAssessment(
            level=w.require_approval_level, score=w.require_approval_score, factors=factors
        )

    if any(d.effect == "transform" for d in decisions):
        return AuditRiskAssessment(
            level=w.transform_level, score=w.transform_score, factors=factors
        )

    return AuditRiskAssessment(level=w.allow_level, score=w.allow_score, factors=factors)


# ---------------------------------------------------------------------------
# Crypto helpers (inlined to avoid circular imports)
# ---------------------------------------------------------------------------


def _normalize_value(value: object) -> object:
    """Normalize a value for deterministic JSON serialization."""
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, list):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        sorted_keys = sorted(value.keys())
        return {k: _normalize_value(value[k]) for k in sorted_keys}
    if hasattr(value, "__dataclass_fields__"):
        from dataclasses import asdict

        return _normalize_value(asdict(value))  # type: ignore[call-overload]
    return value


def _canonicalize_payload(value: object) -> str:
    """Canonicalize a value to a deterministic JSON string."""
    return json.dumps(_normalize_value(value), separators=(",", ":"), sort_keys=False)


def _hash_object(value: object) -> str:
    """Compute SHA-256 hash of a canonicalized object."""
    canonical = _canonicalize_payload(value)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _hash_payload(payload: str) -> str:
    """Compute SHA-256 hash of a string payload."""
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Graph data structures
# ---------------------------------------------------------------------------


@dataclass
class CausalGraphNode:
    """A node in the causal graph."""

    id: str
    kind: CausalGraphNodeKind
    run_id: str
    digest: str
    event_id: str | None = None
    event_type: AuditEventType | None = None
    time: str | None = None
    event: AuditEvent | None = None
    annotations: dict[str, object] | None = None


@dataclass
class CausalGraphEdge:
    """An edge in the causal graph."""

    id: str
    from_node: str
    to_node: str
    kind: CausalGraphEdgeKind


@dataclass
class CausalGraph:
    """A causal audit graph for a run."""

    run_id: str
    schema_version: str
    created_at: str
    nodes: list[CausalGraphNode] = field(default_factory=list)
    edges: list[CausalGraphEdge] = field(default_factory=list)


@dataclass
class LineageTraversalInput:
    """Input for lineage traversal."""

    start_node_id: str
    direction: LineageTraversalDirection = "forward"
    edge_kinds: list[CausalGraphEdgeKind] | None = None
    max_depth: int = 12


# ---------------------------------------------------------------------------
# Annotation extraction
# ---------------------------------------------------------------------------


def _extract_annotations(event: AuditEvent) -> dict[str, object] | None:
    """Extract annotations from an audit event for graph nodes."""
    from arelis.audit.types import (
        ModelRequestEvent,
        ModelResponseEvent,
        PolicyEvaluatedEvent,
        ToolCallEvent,
        ToolResultEvent,
    )

    if isinstance(event, PolicyEvaluatedEvent):
        risk = assess_policy_risk(event.decisions)
        return {
            "checkpoint": event.checkpoint,
            "allowed": event.allowed,
            "policyVersion": event.policy_version,
            "policySnapshotHash": event.policy_snapshot_hash,
            "risk": risk,
        }

    if isinstance(event, ModelRequestEvent):
        return {
            "modelId": event.model.id,
            "provider": event.model.provider,
        }

    if isinstance(event, ModelResponseEvent):
        risk = event.risk or assess_policy_risk(event.policy or [])
        return {
            "modelId": event.model.id,
            "provider": event.model.provider,
            "risk": risk,
        }

    if isinstance(event, (ToolCallEvent, ToolResultEvent)):
        return {"toolName": event.tool_name}

    return None


# ---------------------------------------------------------------------------
# Helper ID generators
# ---------------------------------------------------------------------------


def _run_node_id(run_id: str) -> str:
    return f"run:{run_id}"


def _event_node_id(event_id: str) -> str:
    return f"evt:{event_id}"


def _edge_id(from_node: str, to_node: str, kind: CausalGraphEdgeKind) -> str:
    return f"{from_node}:{kind}:{to_node}"


# ---------------------------------------------------------------------------
# CausalGraphBuilder
# ---------------------------------------------------------------------------


class CausalGraphBuilder:
    """Builder for constructing a CausalGraph from audit events."""

    def __init__(self, run_id: str) -> None:
        self._run_id = run_id
        self._nodes: dict[str, CausalGraphNode] = {}
        self._edges: dict[str, CausalGraphEdge] = {}
        self._last_event_by_run: dict[str, str] = {}
        self._lineage_markers_by_run: dict[str, dict[str, str]] = {}

    def _add_edge(self, from_node: str, to_node: str, kind: CausalGraphEdgeKind) -> None:
        edge = CausalGraphEdge(
            id=_edge_id(from_node, to_node, kind),
            from_node=from_node,
            to_node=to_node,
            kind=kind,
        )
        self._edges[edge.id] = edge

    def _set_lineage_marker(
        self,
        run_id: str,
        marker: str,
        event_node_id: str,
    ) -> None:
        existing = self._lineage_markers_by_run.get(run_id, {})
        existing[marker] = event_node_id
        self._lineage_markers_by_run[run_id] = existing

    def record_event(self, event: AuditEvent) -> None:
        """Record an audit event into the causal graph."""
        run_id = event.run_id
        run_node_key = _run_node_id(run_id)

        # Ensure run node exists
        if run_node_key not in self._nodes:
            self._nodes[run_node_key] = CausalGraphNode(
                id=run_node_key,
                kind="run",
                run_id=run_id,
                digest=_hash_object({"runId": run_id, "kind": "run"}),
            )

        # Create event node
        event_node_key = _event_node_id(event.event_id)
        annotations = _extract_annotations(event)
        if event_node_key not in self._nodes:
            self._nodes[event_node_key] = CausalGraphNode(
                id=event_node_key,
                kind="event",
                run_id=run_id,
                event_id=event.event_id,
                event_type=event.type,
                time=event.time,
                event=event,
                annotations=annotations,
                digest=_hash_object(
                    {
                        "eventId": event.event_id,
                        "runId": run_id,
                        "type": event.type,
                        "time": event.time,
                        "annotations": annotations,
                    }
                ),
            )

        # contains edge: run -> event
        self._add_edge(run_node_key, event_node_key, "contains")

        # sequence edge: previous event -> this event
        last_event = self._last_event_by_run.get(run_id)
        if last_event is not None and last_event != event_node_key:
            self._add_edge(last_event, event_node_key, "sequence")

        self._last_event_by_run[run_id] = event_node_key

        # Lineage markers
        if event.type in (
            "infra.provision.completed",
            "infra.destroy.completed",
            "resource.created",
            "resource.updated",
            "resource.deleted",
        ):
            self._set_lineage_marker(run_id, "infra", event_node_key)
        elif event.type == "config.change.completed":
            self._set_lineage_marker(run_id, "config", event_node_key)
        elif event.type == "auth.succeeded":
            self._set_lineage_marker(run_id, "auth", event_node_key)
        elif event.type in ("mcp.tools.discovered", "mcp.server.connected"):
            self._set_lineage_marker(run_id, "discovered", event_node_key)
        elif event.type == "agent.step":
            self._set_lineage_marker(run_id, "agent", event_node_key)

        # Parent run edges
        if event.parent_run_id is not None:
            parent_node_key = _run_node_id(event.parent_run_id)
            if parent_node_key not in self._nodes:
                self._nodes[parent_node_key] = CausalGraphNode(
                    id=parent_node_key,
                    kind="run",
                    run_id=event.parent_run_id,
                    digest=_hash_object(
                        {
                            "runId": event.parent_run_id,
                            "kind": "run",
                        }
                    ),
                )

            self._add_edge(parent_node_key, run_node_key, "parent")

            parent_markers = self._lineage_markers_by_run.get(event.parent_run_id, {})
            marker_to_edge: dict[str, CausalGraphEdgeKind] = {
                "infra": "provisioned",
                "config": "configured",
                "auth": "authenticated",
                "discovered": "discovered",
                "agent": "agent_child",
            }
            for marker_name, edge_kind in marker_to_edge.items():
                marker_value = parent_markers.get(marker_name)
                if marker_value is not None:
                    self._add_edge(marker_value, run_node_key, edge_kind)

    def build(self) -> CausalGraph:
        """Build the causal graph from recorded events."""
        return CausalGraph(
            run_id=self._run_id,
            schema_version=CAUSAL_GRAPH_SCHEMA_VERSION,
            created_at=datetime.now(timezone.utc).isoformat(),
            nodes=list(self._nodes.values()),
            edges=list(self._edges.values()),
        )


def build_causal_graph(run_id: str, events: list[AuditEvent]) -> CausalGraph:
    """Build a causal graph from a list of audit events."""
    builder = CausalGraphBuilder(run_id)
    for event in events:
        builder.record_event(event)
    return builder.build()


# ---------------------------------------------------------------------------
# Lineage traversal
# ---------------------------------------------------------------------------


def traverse_lineage(graph: CausalGraph, input: LineageTraversalInput) -> list[str]:
    """Traverse lineage in the causal graph (BFS)."""
    direction = input.direction
    max_depth = input.max_depth
    allowed_kinds = set(input.edge_kinds) if input.edge_kinds is not None else None
    visited: set[str] = {input.start_node_id}
    queue: list[tuple[str, int]] = [(input.start_node_id, 0)]

    while queue:
        current_id, depth = queue.pop(0)
        if depth >= max_depth:
            continue

        for edge in graph.edges:
            if allowed_kinds is not None and edge.kind not in allowed_kinds:
                continue

            if direction == "forward" and edge.from_node == current_id:
                next_id = edge.to_node
            elif direction == "backward" and edge.to_node == current_id:
                next_id = edge.from_node
            else:
                continue

            if next_id not in visited:
                visited.add(next_id)
                queue.append((next_id, depth + 1))

    return list(visited)


def find_inference_runs_from_lifecycle(
    graph: CausalGraph,
    category: LifecycleLineageCategory,
) -> list[str]:
    """Find inference run IDs linked from lifecycle events of the given category."""
    edge_kind_map: dict[str, CausalGraphEdgeKind] = {
        "infra": "provisioned",
        "config": "configured",
        "auth": "authenticated",
    }
    edge_kind = edge_kind_map[category]

    run_ids: set[str] = set()
    node_map = {node.id: node for node in graph.nodes}

    for edge in graph.edges:
        if edge.kind != edge_kind:
            continue
        target = node_map.get(edge.to_node)
        if target is not None and target.kind == "run":
            run_ids.add(target.run_id)

    return list(run_ids)


def trace_lifecycle_origins_for_output(
    graph: CausalGraph,
    output_event_id: str,
) -> list[str]:
    """Trace lifecycle origin event types that led to the given output event."""
    start_node = None
    for node in graph.nodes:
        if node.kind == "event" and node.event_id == output_event_id:
            start_node = node
            break

    if start_node is None:
        return []

    lineage_node_ids = traverse_lineage(
        graph,
        LineageTraversalInput(
            start_node_id=start_node.id,
            direction="backward",
            edge_kinds=[
                "contains",
                "sequence",
                "parent",
                "provisioned",
                "configured",
                "authenticated",
            ],
        ),
    )

    node_map = {node.id: node for node in graph.nodes}
    origin_types: set[str] = set()

    for node_id in lineage_node_ids:
        found_node = node_map.get(node_id)
        if found_node is None or found_node.kind != "event" or found_node.event_type is None:
            continue
        if (
            found_node.event_type.startswith("infra.")
            or found_node.event_type.startswith("config.change.")
            or found_node.event_type.startswith("auth.")
        ):
            origin_types.add(found_node.event_type)

    return list(origin_types)
