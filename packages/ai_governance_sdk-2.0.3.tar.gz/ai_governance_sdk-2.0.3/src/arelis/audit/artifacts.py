from __future__ import annotations

import asyncio
import secrets
from dataclasses import dataclass, field
from typing import Literal, Protocol, runtime_checkable

from arelis.audit.proof import (
    CausalGraphCommitment,
    DisclosureProof,
    ProofInput,
    ProofProvider,
)
from arelis.audit.types import AuditContext

__all__ = [
    "COMPLIANCE_ARTIFACT_SCHEMA_V1",
    "COMPLIANCE_ARTIFACT_SCHEMA_V2",
    "ComplianceArtifact",
    "ComplianceArtifactStore",
    "InMemoryComplianceArtifactStore",
    "ProofJobStatus",
    "ProofJobResult",
    "ProofJob",
    "ProofJobQueue",
    "InMemoryProofJobQueue",
]

COMPLIANCE_ARTIFACT_SCHEMA_V1 = "arelis.audit.compliance.v1"
COMPLIANCE_ARTIFACT_SCHEMA_V2 = "arelis.audit.compliance.composed.v2"


# ---------------------------------------------------------------------------
# ComplianceArtifact
# ---------------------------------------------------------------------------


@dataclass
class ComplianceArtifact:
    """A compliance artifact containing a commitment and proof for a run."""

    id: str
    run_id: str
    created_at: str
    commitment: CausalGraphCommitment
    proof: DisclosureProof
    disclosure_rule_ids: list[str] = field(default_factory=list)
    artifact_schema: str | None = None
    context: AuditContext | None = None
    policy_snapshot_hash: str | None = None


# ---------------------------------------------------------------------------
# ComplianceArtifactStore
# ---------------------------------------------------------------------------


@runtime_checkable
class ComplianceArtifactStore(Protocol):
    """Protocol for storing compliance artifacts."""

    async def save(self, artifact: ComplianceArtifact) -> None: ...

    async def get(self, run_id: str, artifact_id: str) -> ComplianceArtifact | None: ...

    async def list(self, run_id: str) -> list[ComplianceArtifact]: ...


class InMemoryComplianceArtifactStore:
    """In-memory implementation of ComplianceArtifactStore."""

    def __init__(self) -> None:
        self._artifacts_by_run: dict[str, list[ComplianceArtifact]] = {}

    async def save(self, artifact: ComplianceArtifact) -> None:
        existing = self._artifacts_by_run.get(artifact.run_id, [])
        existing.append(artifact)
        self._artifacts_by_run[artifact.run_id] = existing

    async def get(self, run_id: str, artifact_id: str) -> ComplianceArtifact | None:
        artifacts = self._artifacts_by_run.get(run_id, [])
        for artifact in artifacts:
            if artifact.id == artifact_id:
                return artifact
        return None

    async def list(self, run_id: str) -> list[ComplianceArtifact]:
        return list(self._artifacts_by_run.get(run_id, []))


# ---------------------------------------------------------------------------
# ProofJob types
# ---------------------------------------------------------------------------

ProofJobStatus = Literal["pending", "completed", "failed"]


@dataclass
class ProofJobResult:
    """Result of a proof job."""

    status: ProofJobStatus
    proof: DisclosureProof | None = None
    error: str | None = None


@dataclass
class ProofJob:
    """A proof generation job."""

    id: str
    status: ProofJobStatus
    result: ProofJobResult | None = None


# ---------------------------------------------------------------------------
# ProofJobQueue
# ---------------------------------------------------------------------------


@runtime_checkable
class ProofJobQueue(Protocol):
    """Protocol for submitting and tracking proof generation jobs."""

    def submit(self, input: ProofInput, provider: ProofProvider) -> ProofJob: ...

    def get(self, job_id: str) -> ProofJob | None: ...


class InMemoryProofJobQueue:
    """In-memory proof job queue that runs jobs as background tasks."""

    def __init__(self) -> None:
        self._jobs: dict[str, ProofJob] = {}

    def submit(self, input: ProofInput, provider: ProofProvider) -> ProofJob:
        """Submit a proof job for background processing."""
        job = ProofJob(
            id=f"job_{secrets.token_hex(4)}",
            status="pending",
        )
        self._jobs[job.id] = job

        # Schedule the job as a background task
        async def _run_job() -> None:
            try:
                proof = await provider.create_proof(input)
                job.status = "completed"
                job.result = ProofJobResult(status="completed", proof=proof)
            except Exception as exc:
                job.status = "failed"
                job.result = ProofJobResult(status="failed", error=str(exc))

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(_run_job())
        except RuntimeError:
            # No running event loop; mark as pending (caller must await manually)
            pass

        return job

    def get(self, job_id: str) -> ProofJob | None:
        """Get a proof job by ID."""
        return self._jobs.get(job_id)
