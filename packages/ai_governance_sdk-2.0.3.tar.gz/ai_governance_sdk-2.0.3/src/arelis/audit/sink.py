from __future__ import annotations

import asyncio
import contextlib
import json
import sys
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from arelis.audit.types import AuditEvent, AuditEventType

__all__ = [
    "AuditSink",
    "CompositeSink",
    "NoOpSink",
    "ConsoleSink",
    "ConsoleSinkConfig",
    "MemorySink",
    "MemorySinkConfig",
    "create_composite_sink",
    "create_no_op_sink",
    "create_console_sink",
    "create_minimal_console_sink",
    "create_memory_sink",
]


@runtime_checkable
class AuditSink(Protocol):
    """Interface for writing audit events."""

    async def write(self, event: AuditEvent) -> None:
        """Write a single audit event."""
        ...

    async def write_batch(self, events: list[AuditEvent]) -> None:
        """Write multiple audit events."""
        ...

    async def flush(self) -> None:
        """Flush any buffered events."""
        ...

    async def close(self) -> None:
        """Close the sink and release resources."""
        ...


class CompositeSink:
    """Composite sink that writes to multiple sinks."""

    def __init__(self, sinks: list[AuditSink] | None = None) -> None:
        self._sinks: list[AuditSink] = list(sinks) if sinks is not None else []

    async def write(self, event: AuditEvent) -> None:
        await asyncio.gather(*(sink.write(event) for sink in self._sinks))

    async def write_batch(self, events: list[AuditEvent]) -> None:
        async def _write_to_sink(sink: AuditSink) -> None:
            try:
                await sink.write_batch(events)
            except (AttributeError, NotImplementedError):
                for event in events:
                    await sink.write(event)

        await asyncio.gather(*(_write_to_sink(sink) for sink in self._sinks))

    async def flush(self) -> None:
        for sink in self._sinks:
            with contextlib.suppress(AttributeError, NotImplementedError):
                await sink.flush()

    async def close(self) -> None:
        for sink in self._sinks:
            with contextlib.suppress(AttributeError, NotImplementedError):
                await sink.close()


class NoOpSink:
    """No-op sink that discards all events."""

    async def write(self, _event: AuditEvent) -> None:
        pass

    async def write_batch(self, _events: list[AuditEvent]) -> None:
        pass

    async def flush(self) -> None:
        pass

    async def close(self) -> None:
        pass


def create_composite_sink(sinks: list[AuditSink]) -> CompositeSink:
    """Create a composite sink from multiple sinks."""
    return CompositeSink(sinks)


def create_no_op_sink() -> NoOpSink:
    """Create a no-op sink."""
    return NoOpSink()


# ---------------------------------------------------------------------------
# Console sink
# ---------------------------------------------------------------------------


@dataclass
class ConsoleSinkConfig:
    """Console sink configuration."""

    pretty: bool = True
    timestamp: bool = True
    event_types: list[AuditEventType] | None = None
    formatter: Callable[[AuditEvent], str] | None = None


class ConsoleSink:
    """Console sink for development logging."""

    def __init__(self, config: ConsoleSinkConfig | None = None) -> None:
        cfg = config if config is not None else ConsoleSinkConfig()
        self._pretty = cfg.pretty
        self._timestamp = cfg.timestamp
        self._event_types = cfg.event_types
        self._formatter = cfg.formatter

    def _format_event(self, event: AuditEvent) -> str:
        if self._formatter is not None:
            return self._formatter(event)

        prefix = f"[{event.time}] [{event.type}] " if self._timestamp else f"[{event.type}] "

        # Build a simple dict representation for logging
        event_dict = _event_to_dict(event)
        json_str = (
            json.dumps(event_dict, indent=2, default=str)
            if self._pretty
            else json.dumps(event_dict, default=str)
        )

        return f"{prefix}\n{json_str}"

    async def write(self, event: AuditEvent) -> None:
        if self._event_types is not None and event.type not in self._event_types:
            return
        output = self._format_event(event)
        print(output, file=sys.stdout)

    async def write_batch(self, events: list[AuditEvent]) -> None:
        for event in events:
            await self.write(event)

    async def flush(self) -> None:
        sys.stdout.flush()

    async def close(self) -> None:
        pass


def _event_to_dict(event: AuditEvent) -> dict[str, object]:
    """Convert an audit event dataclass to a dictionary for serialization."""
    from dataclasses import asdict

    return asdict(event)


def create_console_sink(config: ConsoleSinkConfig | None = None) -> ConsoleSink:
    """Create a console sink with the given configuration."""
    return ConsoleSink(config)


def create_minimal_console_sink() -> ConsoleSink:
    """Create a minimal console sink for compact output."""

    def _minimal_formatter(event: AuditEvent) -> str:
        parts = [f"[{event.time}]", f"[{event.type}]", f"run={event.run_id}"]

        if hasattr(event, "model") and event.model is not None:
            model = event.model
            if hasattr(model, "id"):
                parts.append(f"model={model.id}")

        if hasattr(event, "tool_name"):
            parts.append(f"tool={event.tool_name}")

        if hasattr(event, "success"):
            parts.append(f"success={event.success}")

        if hasattr(event, "error") and event.error is not None:
            err = event.error
            if isinstance(err, str):
                parts.append(f"error={err}")
            elif hasattr(err, "message"):
                parts.append(f"error={err.message}")

        return " ".join(parts)

    return ConsoleSink(
        ConsoleSinkConfig(
            pretty=False,
            timestamp=True,
            formatter=_minimal_formatter,
        )
    )


# ---------------------------------------------------------------------------
# Memory sink (for testing)
# ---------------------------------------------------------------------------


@dataclass
class MemorySinkConfig:
    """Memory sink configuration."""

    max_events: int = 1000


class MemorySink:
    """In-memory sink for testing."""

    def __init__(self, config: MemorySinkConfig | None = None) -> None:
        cfg = config if config is not None else MemorySinkConfig()
        self._max_events = cfg.max_events
        self._events: list[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self._events.append(event)
        if len(self._events) > self._max_events:
            self._events = self._events[-self._max_events :]

    async def write_batch(self, events: list[AuditEvent]) -> None:
        self._events.extend(events)
        if len(self._events) > self._max_events:
            self._events = self._events[-self._max_events :]

    async def flush(self) -> None:
        pass

    async def close(self) -> None:
        pass

    def get_events(self) -> list[AuditEvent]:
        """Get all stored events."""
        return list(self._events)

    def get_events_by_type(self, event_type: AuditEventType) -> list[AuditEvent]:
        """Get events by type."""
        return [e for e in self._events if e.type == event_type]

    def get_events_by_run_id(self, run_id: str) -> list[AuditEvent]:
        """Get events by run ID."""
        return [e for e in self._events if e.run_id == run_id]

    def get_last_event(self) -> AuditEvent | None:
        """Get the most recent event."""
        return self._events[-1] if self._events else None

    def get_last_event_by_type(self, event_type: AuditEventType) -> AuditEvent | None:
        """Get the most recent event of a specific type."""
        for event in reversed(self._events):
            if event.type == event_type:
                return event
        return None

    def find_events(self, predicate: Callable[[AuditEvent], bool]) -> list[AuditEvent]:
        """Find events matching a predicate."""
        return [e for e in self._events if predicate(e)]

    def has_event(self, predicate: Callable[[AuditEvent], bool]) -> bool:
        """Check if any event matches a predicate."""
        return any(predicate(e) for e in self._events)

    def count(self) -> int:
        """Get the count of events."""
        return len(self._events)

    def count_by_type(self, event_type: AuditEventType) -> int:
        """Get count of events by type."""
        return sum(1 for e in self._events if e.type == event_type)

    def clear(self) -> None:
        """Clear all events."""
        self._events = []

    def assert_has_event_type(self, event_type: AuditEventType) -> None:
        """Assert that an event of the given type exists. Raises if not found."""
        if not any(e.type == event_type for e in self._events):
            raise AssertionError(f'Expected audit event of type "{event_type}" but none found')

    def assert_event_count(self, expected_count: int) -> None:
        """Assert the exact count of events. Raises if count does not match."""
        if len(self._events) != expected_count:
            raise AssertionError(f"Expected {expected_count} events but found {len(self._events)}")


def create_memory_sink(config: MemorySinkConfig | None = None) -> MemorySink:
    """Create an in-memory sink for testing."""
    return MemorySink(config)
