from __future__ import annotations

import hashlib
import json
from typing import Literal

from arelis.audit.types import (
    BlobDataRef,
    DataRef,
    HashDataRef,
    InlineDataRef,
)

__all__ = [
    "DataRefType",
    "create_inline_ref",
    "create_blob_ref",
    "create_hash_ref",
    "create_data_ref",
    "hash_sha256",
    "is_inline_ref",
    "is_blob_ref",
    "is_hash_ref",
    "get_inline_value",
    "serialize_data_ref",
    "deserialize_data_ref",
]

DataRefType = Literal["inline", "blob", "hash"]


def hash_sha256(value: str) -> str:
    """Compute SHA-256 hash of a string."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def create_inline_ref(value: str, redacted: bool | None = None) -> InlineDataRef:
    """Create an inline data reference."""
    return InlineDataRef(value=value, redacted=redacted)


def create_blob_ref(uri: str, checksum: str, encrypted: bool) -> BlobDataRef:
    """Create a blob data reference."""
    return BlobDataRef(uri=uri, checksum=checksum, encrypted=encrypted)


def create_hash_ref(value: str) -> HashDataRef:
    """Create a hash-only data reference from a string value."""
    return HashDataRef(sha256=hash_sha256(value))


def create_data_ref(
    value: str,
    mode: Literal["inline", "hash"] = "hash",
    redacted: bool | None = None,
) -> DataRef:
    """Create a data reference based on mode."""
    if mode == "inline":
        return create_inline_ref(value, redacted)
    return create_hash_ref(value)


def is_inline_ref(ref: DataRef) -> bool:
    """Check if a data reference is inline."""
    return ref.kind == "inline"


def is_blob_ref(ref: DataRef) -> bool:
    """Check if a data reference is a blob."""
    return ref.kind == "blob"


def is_hash_ref(ref: DataRef) -> bool:
    """Check if a data reference is a hash."""
    return ref.kind == "hash"


def get_inline_value(ref: DataRef) -> str | None:
    """Get the value from an inline reference, or None for other types."""
    if isinstance(ref, InlineDataRef):
        return ref.value
    return None


def serialize_data_ref(ref: DataRef) -> str:
    """Serialize a data reference to JSON."""
    if isinstance(ref, InlineDataRef):
        result: dict[str, object] = {"kind": "inline", "value": ref.value}
        if ref.redacted is not None:
            result["redacted"] = ref.redacted
        return json.dumps(result)
    elif isinstance(ref, BlobDataRef):
        return json.dumps(
            {
                "kind": "blob",
                "uri": ref.uri,
                "checksum": ref.checksum,
                "encrypted": ref.encrypted,
            }
        )
    else:
        return json.dumps({"kind": "hash", "sha256": ref.sha256})


def deserialize_data_ref(json_str: str) -> DataRef:
    """Deserialize a data reference from JSON."""
    parsed = json.loads(json_str)

    if not isinstance(parsed, dict):
        raise ValueError("Invalid DataRef: expected object")

    kind = parsed.get("kind")

    if kind == "inline" and isinstance(parsed.get("value"), str):
        redacted = parsed.get("redacted")
        return create_inline_ref(
            parsed["value"],
            redacted if isinstance(redacted, bool) else None,
        )

    if (
        kind == "blob"
        and isinstance(parsed.get("uri"), str)
        and isinstance(parsed.get("checksum"), str)
        and isinstance(parsed.get("encrypted"), bool)
    ):
        return create_blob_ref(parsed["uri"], parsed["checksum"], parsed["encrypted"])

    if kind == "hash" and isinstance(parsed.get("sha256"), str):
        return HashDataRef(sha256=parsed["sha256"])

    raise ValueError("Invalid DataRef: unknown kind or missing fields")
