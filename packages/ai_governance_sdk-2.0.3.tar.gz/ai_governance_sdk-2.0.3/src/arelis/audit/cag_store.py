from __future__ import annotations

import contextlib
from typing import Protocol, runtime_checkable

from arelis.audit.cag import (
    CausalGraph,
    CausalGraphBuilder,
)
from arelis.audit.types import AuditEvent

__all__ = [
    "CausalGraphStore",
    "InMemoryCausalGraphStore",
    "CausalGraphAuditSink",
    "CausalGraphSinkOptions",
    "create_causal_graph_audit_sink",
]


@runtime_checkable
class CausalGraphStore(Protocol):
    """Protocol for persisting causal graphs."""

    async def save(self, graph: CausalGraph) -> None:
        """Save a causal graph."""
        ...

    async def get(self, run_id: str) -> CausalGraph | None:
        """Get a causal graph by run ID."""
        ...


class InMemoryCausalGraphStore:
    """In-memory implementation of CausalGraphStore."""

    def __init__(self) -> None:
        self._graphs: dict[str, CausalGraph] = {}

    async def save(self, graph: CausalGraph) -> None:
        self._graphs[graph.run_id] = graph

    async def get(self, run_id: str) -> CausalGraph | None:
        return self._graphs.get(run_id)


class CausalGraphSinkOptions:
    """Options for the CausalGraphAuditSink."""

    def __init__(
        self,
        store: CausalGraphStore,
        auto_persist_on_run_end: bool = True,
    ) -> None:
        self.store = store
        self.auto_persist_on_run_end = auto_persist_on_run_end


class CausalGraphAuditSink:
    """Audit sink that builds causal graphs from events and persists them.

    Wraps a base audit sink and intercepts events to build causal graphs.
    """

    def __init__(
        self,
        base_sink: object,
        options: CausalGraphSinkOptions,
    ) -> None:
        self._base_sink = base_sink
        self._store = options.store
        self._auto_persist_on_run_end = options.auto_persist_on_run_end
        self._builders: dict[str, CausalGraphBuilder] = {}

    def _record_event(self, event: AuditEvent) -> None:
        run_id = event.run_id
        if run_id not in self._builders:
            self._builders[run_id] = CausalGraphBuilder(run_id)
        self._builders[run_id].record_event(event)

    async def _maybe_persist(self, event: AuditEvent) -> None:
        if not self._auto_persist_on_run_end:
            return
        if event.type in ("run.ended", "run.error"):
            builder = self._builders.get(event.run_id)
            if builder is not None:
                await self._store.save(builder.build())

    async def write(self, event: AuditEvent) -> None:
        """Write an event to the base sink and record it in the causal graph."""
        # Forward to base sink
        write_fn = getattr(self._base_sink, "write", None)
        if write_fn is not None:
            await write_fn(event)
        self._record_event(event)
        await self._maybe_persist(event)

    async def write_batch(self, events: list[AuditEvent]) -> None:
        """Write a batch of events."""
        write_batch_fn = getattr(self._base_sink, "write_batch", None)
        if write_batch_fn is not None:
            try:
                await write_batch_fn(events)
            except (AttributeError, NotImplementedError):
                write_fn = getattr(self._base_sink, "write", None)
                if write_fn is not None:
                    for event in events:
                        await write_fn(event)
        else:
            write_fn = getattr(self._base_sink, "write", None)
            if write_fn is not None:
                for event in events:
                    await write_fn(event)

        for event in events:
            self._record_event(event)
            await self._maybe_persist(event)

    async def flush(self) -> None:
        """Flush the base sink."""
        flush_fn = getattr(self._base_sink, "flush", None)
        if flush_fn is not None:
            with contextlib.suppress(AttributeError, NotImplementedError):
                await flush_fn()

    async def close(self) -> None:
        """Persist all remaining graphs and close the base sink."""
        for builder in self._builders.values():
            await self._store.save(builder.build())
        self._builders.clear()

        close_fn = getattr(self._base_sink, "close", None)
        if close_fn is not None:
            with contextlib.suppress(AttributeError, NotImplementedError):
                await close_fn()


def create_causal_graph_audit_sink(
    base_sink: object,
    options: CausalGraphSinkOptions,
) -> CausalGraphAuditSink:
    """Create a CausalGraphAuditSink wrapping a base sink."""
    return CausalGraphAuditSink(base_sink, options)
