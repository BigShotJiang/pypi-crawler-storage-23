from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

__all__ = [
    "AUDIT_SCHEMA_VERSION",
    "AuditEventType",
    "AuditMediaModality",
    "MediaRequestEventType",
    "MediaResponseEventType",
    "RiskRouteAction",
    "DataRef",
    "InlineDataRef",
    "BlobDataRef",
    "HashDataRef",
    "AuditPolicyDecision",
    "AuditRiskAssessment",
    "AuditModelInfo",
    "AuditPromptTemplateInfo",
    "MediaMetadata",
    "AuditContext",
    "AuditContextOrg",
    "AuditContextTeam",
    "AuditContextActor",
    "AuditKBInfo",
    "AuditMemoryInfo",
    "AuditDataSourceInfo",
    "AuditResourceInfo",
    "QuotaKeyInfo",
    "ErrorDetail",
    "ToolCallInfo",
    "AgentStepPolicy",
    "BaseAuditEvent",
    "RunStartedEvent",
    "RunEndedEvent",
    "RunErrorEvent",
    "PolicyEvaluatedEvent",
    "ModelRequestEvent",
    "ModelResponseEvent",
    "MediaRequestEvent",
    "MediaResponseEvent",
    "ModelResolvedEvent",
    "ModelFallbackUsedEvent",
    "ModelDeprecatedUsedEvent",
    "ModelDisabledBlockedEvent",
    "ModelStreamStartedEvent",
    "ModelStreamChunkEvent",
    "ModelStreamEndedEvent",
    "ModelStreamAbortedEvent",
    "ToolCallEvent",
    "ToolResultEvent",
    "AgentStepEvent",
    "KBQueryEvent",
    "KBResultsEvent",
    "KBChunkFilteredEvent",
    "KBGroundingAppliedEvent",
    "MemoryReadEvent",
    "MemoryWriteEvent",
    "MemoryDeleteEvent",
    "DataReadEvent",
    "DataFilteredEvent",
    "DataBlockedEvent",
    "ApprovalRequestedEvent",
    "ApprovalGrantedEvent",
    "ApprovalRejectedEvent",
    "EvaluationRunEvent",
    "EvaluationResultEvent",
    "EvaluationWarningEvent",
    "EvaluationBlockedEvent",
    "QuotaCheckedEvent",
    "QuotaLimitedEvent",
    "QuotaExceededEvent",
    "QuotaCommittedEvent",
    "OutputValidationStartedEvent",
    "OutputValidationPassedEvent",
    "OutputValidationFailedEvent",
    "SecretResolvedEvent",
    "SecretDetectedBlockedEvent",
    "PromptTemplateUsedEvent",
    "OrchestrationStepEvent",
    "ResourceCreatedEvent",
    "ResourceUpdatedEvent",
    "ResourceDeletedEvent",
    "CliCommandStartedEvent",
    "CliCommandCompletedEvent",
    "CliCommandFailedEvent",
    "InfraProvisionStartedEvent",
    "InfraProvisionCompletedEvent",
    "InfraProvisionFailedEvent",
    "InfraDestroyStartedEvent",
    "InfraDestroyCompletedEvent",
    "InfraDestroyFailedEvent",
    "ConfigChangeStartedEvent",
    "ConfigChangeCompletedEvent",
    "ConfigChangeFailedEvent",
    "AuthStartedEvent",
    "AuthSucceededEvent",
    "AuthFailedEvent",
    "MCPServerRegisteredEvent",
    "MCPServerConnectedEvent",
    "MCPServerDisconnectedEvent",
    "MCPToolsDiscoveredEvent",
    "AgentAttestationCreatedEvent",
    "ComplianceProofComposedEvent",
    "RiskRouteDecidedEvent",
    "SnapshotCapturedEvent",
    "ReplayDriftDetectedEvent",
    "DisclosureDerivedGeneratedEvent",
    "AuditEvent",
    "to_audit_context",
    "to_audit_decisions",
    "SnapshotBundle",
]

AUDIT_SCHEMA_VERSION = "1.0"


@dataclass
class SnapshotBundle:
    """A bundle of state captured at a point in time for audit/replay."""

    schema: str
    captured_at: str
    policy_snapshot_hash: str | None = None
    model_route_id: str | None = None
    tool_registry_hash: str | None = None
    config_state_hash: str | None = None
    hash: str | None = None


AuditEventType = Literal[
    "run.started",
    "run.ended",
    "run.error",
    "policy.evaluated",
    "model.request",
    "model.response",
    "model.resolved",
    "model.fallback.used",
    "model.deprecated.used",
    "model.disabled.blocked",
    "model.stream.started",
    "model.stream.chunk",
    "model.stream.ended",
    "model.stream.aborted",
    "image.generate.request",
    "image.generate.response",
    "audio.generate.request",
    "audio.generate.response",
    "video.generate.request",
    "video.generate.response",
    "image.to_text.request",
    "image.to_text.response",
    "image.to_audio.request",
    "image.to_audio.response",
    "image.to_video.request",
    "image.to_video.response",
    "audio.to_text.request",
    "audio.to_text.response",
    "audio.to_image.request",
    "audio.to_image.response",
    "audio.to_video.request",
    "audio.to_video.response",
    "video.to_text.request",
    "video.to_text.response",
    "video.to_image.request",
    "video.to_image.response",
    "video.to_audio.request",
    "video.to_audio.response",
    "tool.call",
    "tool.result",
    "agent.step",
    "kb.query",
    "kb.results",
    "kb.chunk.filtered",
    "kb.grounding.applied",
    "memory.read",
    "memory.write",
    "memory.delete",
    "data.read",
    "data.filtered",
    "data.blocked",
    "approval.requested",
    "approval.granted",
    "approval.rejected",
    "evaluation.run",
    "evaluation.result",
    "evaluation.warning",
    "evaluation.blocked",
    "quota.checked",
    "quota.limited",
    "quota.exceeded",
    "quota.committed",
    "output.validation.started",
    "output.validation.passed",
    "output.validation.failed",
    "secret.resolved",
    "secret.detected.blocked",
    "prompt.template.used",
    "orchestration.step",
    "resource.created",
    "resource.updated",
    "resource.deleted",
    "cli.command.started",
    "cli.command.completed",
    "cli.command.failed",
    "infra.provision.started",
    "infra.provision.completed",
    "infra.provision.failed",
    "infra.destroy.started",
    "infra.destroy.completed",
    "infra.destroy.failed",
    "config.change.started",
    "config.change.completed",
    "config.change.failed",
    "auth.started",
    "auth.succeeded",
    "auth.failed",
    "mcp.server.registered",
    "mcp.server.connected",
    "mcp.server.disconnected",
    "mcp.tools.discovered",
    "agent.attestation.created",
    "compliance.proof.composed",
    "risk.route.decided",
    "snapshot.captured",
    "replay.drift.detected",
    "disclosure.derived.generated",
]

AuditMediaModality = Literal["text", "image", "audio", "video"]

MediaRequestEventType = Literal[
    "image.generate.request",
    "audio.generate.request",
    "video.generate.request",
    "image.to_text.request",
    "image.to_audio.request",
    "image.to_video.request",
    "audio.to_text.request",
    "audio.to_image.request",
    "audio.to_video.request",
    "video.to_text.request",
    "video.to_image.request",
    "video.to_audio.request",
]

MediaResponseEventType = Literal[
    "image.generate.response",
    "audio.generate.response",
    "video.generate.response",
    "image.to_text.response",
    "image.to_audio.response",
    "image.to_video.response",
    "audio.to_text.response",
    "audio.to_image.response",
    "audio.to_video.response",
    "video.to_text.response",
    "video.to_image.response",
    "video.to_audio.response",
]

RiskRouteAction = Literal["auto_execute", "sandbox", "require_approval", "block"]


# ---------------------------------------------------------------------------
# Data reference types (discriminated union)
# ---------------------------------------------------------------------------


@dataclass
class InlineDataRef:
    """Inline data reference with value stored directly."""

    kind: Literal["inline"] = field(default="inline", init=False)
    value: str = ""
    redacted: bool | None = None


@dataclass
class BlobDataRef:
    """Blob data reference pointing to external storage."""

    kind: Literal["blob"] = field(default="blob", init=False)
    uri: str = ""
    checksum: str = ""
    encrypted: bool = False


@dataclass
class HashDataRef:
    """Hash-only data reference for content-addressable storage."""

    kind: Literal["hash"] = field(default="hash", init=False)
    sha256: str = ""


DataRef = InlineDataRef | BlobDataRef | HashDataRef


# ---------------------------------------------------------------------------
# Supporting dataclasses for audit event fields
# ---------------------------------------------------------------------------


@dataclass
class AuditPolicyDecision:
    """Policy decision in audit events."""

    effect: Literal["allow", "block", "transform", "require_approval"]
    reason: str | None = None
    code: str | None = None


@dataclass
class AuditRiskAssessment:
    """Risk assessment in audit events."""

    level: Literal["low", "medium", "high", "critical"]
    factors: list[str] | None = None
    score: float | None = None


@dataclass
class AuditModelInfo:
    """Model information in audit events."""

    id: str
    provider: str | None = None
    version: str | None = None
    lifecycle_state: str | None = None


@dataclass
class AuditPromptTemplateInfo:
    """Prompt template information in audit events."""

    id: str
    version: str
    hash: str


@dataclass
class MediaMetadata:
    """Media metadata for audit events."""

    mime_type: str | None = None
    width: int | None = None
    height: int | None = None
    duration_ms: int | None = None
    sample_rate_hz: int | None = None
    channels: int | None = None
    frame_rate: float | None = None


@dataclass
class AuditContextOrg:
    """Organization context for audit events."""

    id: str


@dataclass
class AuditContextTeam:
    """Team context for audit events."""

    id: str


@dataclass
class AuditContextActor:
    """Actor context for audit events."""

    type: str
    id: str


@dataclass
class AuditContext:
    """Minimal context for audit events."""

    org: AuditContextOrg
    actor: AuditContextActor
    purpose: str
    environment: str
    team: AuditContextTeam | None = None


@dataclass
class AuditKBInfo:
    """Knowledge base info for audit events."""

    id: str
    provider: str | None = None
    region: str | None = None


@dataclass
class AuditMemoryInfo:
    """Memory info for audit events."""

    scope: str
    key: str
    provider_id: str | None = None


@dataclass
class AuditDataSourceInfo:
    """Data source info for audit events."""

    id: str
    provider: str | None = None
    region: str | None = None


@dataclass
class AuditResourceInfo:
    """Resource metadata for audit events."""

    type: str
    id: str | None = None
    name: str | None = None
    provider: str | None = None
    region: str | None = None
    tags: dict[str, str] | None = None
    metadata: dict[str, object] | None = None


@dataclass
class QuotaKeyInfo:
    """Quota key information."""

    org_id: str
    purpose: str
    environment: str
    team_id: str | None = None
    actor_id: str | None = None


@dataclass
class ErrorDetail:
    """Error detail for audit events."""

    type: str
    message: str
    code: str | None = None


@dataclass
class ToolCallInfo:
    """Tool call information within an agent step."""

    tool_name: str
    success: bool
    args_ref: DataRef | None = None
    result_ref: DataRef | None = None


@dataclass
class AgentStepPolicy:
    """Policy metadata for an agent step."""

    allowed: bool
    decision_effects: list[Literal["allow", "block", "transform", "require_approval"]]
    checkpoint: str | None = None
    policy_snapshot_hash: str | None = None


# ---------------------------------------------------------------------------
# Base audit event
# ---------------------------------------------------------------------------


@dataclass
class BaseAuditEvent:
    """Base audit event with common fields."""

    schema_version: str
    event_id: str
    time: str
    run_id: str
    type: AuditEventType
    context: AuditContext
    parent_run_id: str | None = None


# ---------------------------------------------------------------------------
# Concrete audit event types
# ---------------------------------------------------------------------------


@dataclass
class RunStartedEvent(BaseAuditEvent):
    """Run started event."""

    operation: str | None = None
    snapshot_hash: str | None = None


@dataclass
class RunEndedEvent(BaseAuditEvent):
    """Run ended event."""

    success: bool = False
    duration_ms: float | None = None


@dataclass
class RunErrorEvent(BaseAuditEvent):
    """Run error event."""

    error: ErrorDetail = field(default_factory=lambda: ErrorDetail(type="", message=""))


@dataclass
class PolicyEvaluatedEvent(BaseAuditEvent):
    """Policy evaluated event."""

    checkpoint: str = ""
    decisions: list[AuditPolicyDecision] = field(default_factory=list)
    allowed: bool = False
    policy_version: str | None = None
    policy_snapshot_hash: str | None = None
    policy_compiler_id: str | None = None


@dataclass
class ModelRequestEvent(BaseAuditEvent):
    """Model request event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    input_ref: DataRef | None = None
    prompt_template: AuditPromptTemplateInfo | None = None


@dataclass
class ModelResponseEvent(BaseAuditEvent):
    """Model response event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    output_ref: DataRef | None = None
    usage: dict[str, object] | None = None
    policy: list[AuditPolicyDecision] | None = None
    risk: AuditRiskAssessment | None = None


@dataclass
class MediaRequestEvent(BaseAuditEvent):
    """Media request event (image/audio/video generation or conversion)."""

    source: AuditMediaModality = "text"
    target: AuditMediaModality = "text"
    model: AuditModelInfo | None = None
    input_ref: DataRef | None = None


@dataclass
class MediaResponseEvent(BaseAuditEvent):
    """Media response event (image/audio/video generation or conversion)."""

    source: AuditMediaModality = "text"
    target: AuditMediaModality = "text"
    model: AuditModelInfo | None = None
    output_ref: DataRef | None = None
    media_metadata: MediaMetadata | None = None
    usage: dict[str, object] | None = None
    policy: list[AuditPolicyDecision] | None = None
    risk: AuditRiskAssessment | None = None


@dataclass
class ModelResolvedEvent(BaseAuditEvent):
    """Model resolved event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    route_id: str | None = None
    fallback_used: bool | None = None


@dataclass
class ModelFallbackUsedEvent(BaseAuditEvent):
    """Model fallback used event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    route_id: str | None = None
    reason: str | None = None


@dataclass
class ModelDeprecatedUsedEvent(BaseAuditEvent):
    """Model deprecated used event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    reason: str | None = None


@dataclass
class ModelDisabledBlockedEvent(BaseAuditEvent):
    """Model disabled blocked event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    reason: str | None = None


@dataclass
class ModelStreamStartedEvent(BaseAuditEvent):
    """Model stream started event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))


@dataclass
class ModelStreamChunkEvent(BaseAuditEvent):
    """Model stream chunk event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    chunk_type: str = ""
    size: int | None = None


@dataclass
class ModelStreamEndedEvent(BaseAuditEvent):
    """Model stream ended event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    finish_reason: str | None = None


@dataclass
class ModelStreamAbortedEvent(BaseAuditEvent):
    """Model stream aborted event."""

    model: AuditModelInfo = field(default_factory=lambda: AuditModelInfo(id=""))
    reason: str = ""


@dataclass
class ToolCallEvent(BaseAuditEvent):
    """Tool call event."""

    tool_name: str = ""
    args_ref: DataRef | None = None


@dataclass
class ToolResultEvent(BaseAuditEvent):
    """Tool result event."""

    tool_name: str = ""
    success: bool = False
    result_ref: DataRef | None = None
    error: ErrorDetail | None = None


@dataclass
class AgentStepEvent(BaseAuditEvent):
    """Agent step event."""

    step_number: int = 0
    step_type: Literal["plan", "execute", "observe"] = "execute"
    policy: AgentStepPolicy | None = None
    attestation_hash: str | None = None
    tool_calls: list[ToolCallInfo] | None = None


@dataclass
class KBQueryEvent(BaseAuditEvent):
    """KB query event - emitted before retrieval."""

    kb: AuditKBInfo = field(default_factory=lambda: AuditKBInfo(id=""))
    query_id: str = ""
    query_ref: DataRef | None = None
    top_k: int | None = None


@dataclass
class KBResultsEvent(BaseAuditEvent):
    """KB results event - emitted after retrieval."""

    kb: AuditKBInfo = field(default_factory=lambda: AuditKBInfo(id=""))
    query_id: str = ""
    chunk_count: int = 0
    chunk_refs: list[DataRef] | None = None
    total_found: int | None = None


@dataclass
class KBChunkFilteredEvent(BaseAuditEvent):
    """KB chunk filtered event - emitted when a chunk is blocked by policy."""

    kb: AuditKBInfo = field(default_factory=lambda: AuditKBInfo(id=""))
    query_id: str = ""
    reason: str = ""
    chunk_ref: DataRef | None = None
    policy: AuditPolicyDecision | None = None


@dataclass
class KBGroundingAppliedEvent(BaseAuditEvent):
    """KB grounding applied event - emitted when chunks are injected into prompt."""

    kbs: list[AuditKBInfo] = field(default_factory=list)
    query_ids: list[str] = field(default_factory=list)
    chunks_used: int = 0
    chunks_filtered: int = 0
    chunk_refs: list[DataRef] | None = None


@dataclass
class MemoryReadEvent(BaseAuditEvent):
    """Memory read event."""

    memory: AuditMemoryInfo = field(default_factory=lambda: AuditMemoryInfo(scope="", key=""))


@dataclass
class MemoryWriteEvent(BaseAuditEvent):
    """Memory write event."""

    memory: AuditMemoryInfo = field(default_factory=lambda: AuditMemoryInfo(scope="", key=""))
    value_ref: DataRef | None = None


@dataclass
class MemoryDeleteEvent(BaseAuditEvent):
    """Memory delete event."""

    memory: AuditMemoryInfo = field(default_factory=lambda: AuditMemoryInfo(scope="", key=""))


@dataclass
class DataReadEvent(BaseAuditEvent):
    """Data read event."""

    source: AuditDataSourceInfo = field(default_factory=lambda: AuditDataSourceInfo(id=""))
    query_ref: DataRef | None = None


@dataclass
class DataFilteredEvent(BaseAuditEvent):
    """Data filtered event."""

    source: AuditDataSourceInfo = field(default_factory=lambda: AuditDataSourceInfo(id=""))
    reason: str = ""


@dataclass
class DataBlockedEvent(BaseAuditEvent):
    """Data blocked event."""

    source: AuditDataSourceInfo = field(default_factory=lambda: AuditDataSourceInfo(id=""))
    reason: str = ""


@dataclass
class ApprovalRequestedEvent(BaseAuditEvent):
    """Approval requested event."""

    approval_id: str = ""
    approvers: list[str] = field(default_factory=list)
    reason: str = ""


@dataclass
class ApprovalGrantedEvent(BaseAuditEvent):
    """Approval granted event."""

    approval_id: str = ""
    resolved_by: str = ""
    reason: str | None = None


@dataclass
class ApprovalRejectedEvent(BaseAuditEvent):
    """Approval rejected event."""

    approval_id: str = ""
    resolved_by: str = ""
    reason: str | None = None


@dataclass
class EvaluationRunEvent(BaseAuditEvent):
    """Evaluation run event."""

    evaluator_id: str = ""
    version: str | None = None


@dataclass
class EvaluationResultEvent(BaseAuditEvent):
    """Evaluation result event."""

    evaluator_id: str = ""
    effect: Literal["pass", "warn", "block"] = "pass"
    finding_count: int = 0
    version: str | None = None
    max_severity: str | None = None


@dataclass
class EvaluationWarningEvent(BaseAuditEvent):
    """Evaluation warning event."""

    evaluator_id: str = ""
    message: str = ""


@dataclass
class EvaluationBlockedEvent(BaseAuditEvent):
    """Evaluation blocked event."""

    evaluator_id: str = ""
    reason: str = ""


@dataclass
class QuotaCheckedEvent(BaseAuditEvent):
    """Quota checked event."""

    key: QuotaKeyInfo = field(
        default_factory=lambda: QuotaKeyInfo(org_id="", purpose="", environment="")
    )


@dataclass
class QuotaLimitedEvent(BaseAuditEvent):
    """Quota limited event."""

    key: QuotaKeyInfo = field(
        default_factory=lambda: QuotaKeyInfo(org_id="", purpose="", environment="")
    )
    reason: str = ""


@dataclass
class QuotaExceededEvent(BaseAuditEvent):
    """Quota exceeded event."""

    key: QuotaKeyInfo = field(
        default_factory=lambda: QuotaKeyInfo(org_id="", purpose="", environment="")
    )
    reason: str = ""


@dataclass
class QuotaCommittedEvent(BaseAuditEvent):
    """Quota committed event."""

    key: QuotaKeyInfo = field(
        default_factory=lambda: QuotaKeyInfo(org_id="", purpose="", environment="")
    )


@dataclass
class OutputValidationStartedEvent(BaseAuditEvent):
    """Output validation started event."""

    schema_type: str = ""


@dataclass
class OutputValidationPassedEvent(BaseAuditEvent):
    """Output validation passed event."""

    schema_type: str = ""


@dataclass
class OutputValidationFailedEvent(BaseAuditEvent):
    """Output validation failed event."""

    schema_type: str = ""
    error: str = ""


@dataclass
class SecretResolvedEvent(BaseAuditEvent):
    """Secret resolved event."""

    ref: str = ""
    resolver_id: str = ""


@dataclass
class SecretDetectedBlockedEvent(BaseAuditEvent):
    """Secret detected and blocked event."""

    reason: str = ""


@dataclass
class PromptTemplateUsedEvent(BaseAuditEvent):
    """Prompt template used event."""

    template: AuditPromptTemplateInfo = field(
        default_factory=lambda: AuditPromptTemplateInfo(id="", version="", hash="")
    )


@dataclass
class OrchestrationStepEvent(BaseAuditEvent):
    """Orchestration step event - emitted for CLI/SDK orchestration steps."""

    operation: str = ""
    step: str = ""
    status: Literal["started", "completed", "failed"] = "started"
    duration_ms: float | None = None
    error: ErrorDetail | None = None
    details: dict[str, object] | None = None


@dataclass
class ResourceCreatedEvent(BaseAuditEvent):
    """Resource created event."""

    resource: AuditResourceInfo = field(default_factory=lambda: AuditResourceInfo(type=""))
    operation: str | None = None


@dataclass
class ResourceUpdatedEvent(BaseAuditEvent):
    """Resource updated event."""

    resource: AuditResourceInfo = field(default_factory=lambda: AuditResourceInfo(type=""))
    operation: str | None = None
    changes: dict[str, object] | None = None


@dataclass
class ResourceDeletedEvent(BaseAuditEvent):
    """Resource deleted event."""

    resource: AuditResourceInfo = field(default_factory=lambda: AuditResourceInfo(type=""))
    operation: str | None = None
    reason: str | None = None


@dataclass
class CliCommandStartedEvent(BaseAuditEvent):
    """CLI command started event."""

    command: str = ""
    args_ref: DataRef | None = None


@dataclass
class CliCommandCompletedEvent(BaseAuditEvent):
    """CLI command completed event."""

    command: str = ""
    duration_ms: float | None = None


@dataclass
class CliCommandFailedEvent(BaseAuditEvent):
    """CLI command failed event."""

    command: str = ""
    error: ErrorDetail = field(default_factory=lambda: ErrorDetail(type="", message=""))


@dataclass
class InfraProvisionStartedEvent(BaseAuditEvent):
    """Infrastructure provision started event."""

    stack: str | None = None
    provider: str | None = None
    region: str | None = None


@dataclass
class InfraProvisionCompletedEvent(BaseAuditEvent):
    """Infrastructure provision completed event."""

    stack: str | None = None
    provider: str | None = None
    region: str | None = None
    duration_ms: float | None = None


@dataclass
class InfraProvisionFailedEvent(BaseAuditEvent):
    """Infrastructure provision failed event."""

    stack: str | None = None
    provider: str | None = None
    region: str | None = None
    error: ErrorDetail = field(default_factory=lambda: ErrorDetail(type="", message=""))


@dataclass
class InfraDestroyStartedEvent(BaseAuditEvent):
    """Infrastructure destroy started event."""

    stack: str | None = None
    provider: str | None = None
    region: str | None = None


@dataclass
class InfraDestroyCompletedEvent(BaseAuditEvent):
    """Infrastructure destroy completed event."""

    stack: str | None = None
    provider: str | None = None
    region: str | None = None
    duration_ms: float | None = None


@dataclass
class InfraDestroyFailedEvent(BaseAuditEvent):
    """Infrastructure destroy failed event."""

    stack: str | None = None
    provider: str | None = None
    region: str | None = None
    error: ErrorDetail = field(default_factory=lambda: ErrorDetail(type="", message=""))


@dataclass
class ConfigChangeStartedEvent(BaseAuditEvent):
    """Config change started event."""

    path: str | None = None
    value_ref: DataRef | None = None


@dataclass
class ConfigChangeCompletedEvent(BaseAuditEvent):
    """Config change completed event."""

    path: str | None = None
    duration_ms: float | None = None


@dataclass
class ConfigChangeFailedEvent(BaseAuditEvent):
    """Config change failed event."""

    path: str | None = None
    error: ErrorDetail = field(default_factory=lambda: ErrorDetail(type="", message=""))


@dataclass
class AuthStartedEvent(BaseAuditEvent):
    """Auth started event."""

    profile: str | None = None


@dataclass
class AuthSucceededEvent(BaseAuditEvent):
    """Auth succeeded event."""

    profile: str | None = None
    auth_source: str | None = None


@dataclass
class AuthFailedEvent(BaseAuditEvent):
    """Auth failed event."""

    profile: str | None = None
    error: ErrorDetail = field(default_factory=lambda: ErrorDetail(type="", message=""))


@dataclass
class MCPServerRegisteredEvent(BaseAuditEvent):
    """MCP server registered event."""

    server_id: str = ""
    transport: Literal["stdio", "http"] = "stdio"


@dataclass
class MCPServerConnectedEvent(BaseAuditEvent):
    """MCP server connected event."""

    server_id: str = ""


@dataclass
class MCPServerDisconnectedEvent(BaseAuditEvent):
    """MCP server disconnected event."""

    server_id: str = ""
    reason: str | None = None


@dataclass
class MCPToolsDiscoveredEvent(BaseAuditEvent):
    """MCP tools discovered event."""

    server_id: str = ""
    total_discovered: int = 0
    registered_count: int = 0
    skipped_count: int = 0
    tool_names: list[str] | None = None


@dataclass
class AgentAttestationCreatedEvent(BaseAuditEvent):
    """Agent attestation created event."""

    step_number: int = 0
    step_type: Literal["plan", "execute", "observe"] = "execute"
    attestation_hash: str = ""
    policy_snapshot_hash: str | None = None


@dataclass
class ComplianceProofComposedEvent(BaseAuditEvent):
    """Compliance proof composed event."""

    artifact_id: str = ""
    artifact_schema: str = ""
    layer_count: int = 0
    layer_kinds: list[str] = field(default_factory=list)
    includes_narrowing_proof: bool = False
    includes_lineage_proof: bool = False


@dataclass
class RiskRouteDecidedEvent(BaseAuditEvent):
    """Risk route decided event."""

    route: RiskRouteAction = "auto_execute"
    score: float = 0.0
    factors: list[str] = field(default_factory=list)
    deterministic_inputs_hash: str = ""


@dataclass
class SnapshotCapturedEvent(BaseAuditEvent):
    """Snapshot captured event."""

    snapshot_schema: str = ""
    snapshot_hash: str = ""
    policy_snapshot_hash: str | None = None
    model_route_id: str | None = None
    tool_registry_hash: str | None = None
    config_state_hash: str | None = None


@dataclass
class ReplayDriftDetectedEvent(BaseAuditEvent):
    """Replay drift detected event."""

    snapshot_schema: str = ""
    drift_fields: list[str] = field(default_factory=list)
    compatible: bool = False


@dataclass
class DisclosureDerivedGeneratedEvent(BaseAuditEvent):
    """Disclosure derived generated event."""

    derived_rule_set_id: str = ""
    derived_rule_count: int = 0
    derivation_hash: str = ""
    policy_snapshot_hash: str | None = None


# ---------------------------------------------------------------------------
# Union of all audit event types
# ---------------------------------------------------------------------------

AuditEvent = (
    RunStartedEvent
    | RunEndedEvent
    | RunErrorEvent
    | PolicyEvaluatedEvent
    | ModelRequestEvent
    | ModelResponseEvent
    | MediaRequestEvent
    | MediaResponseEvent
    | ModelResolvedEvent
    | ModelFallbackUsedEvent
    | ModelDeprecatedUsedEvent
    | ModelDisabledBlockedEvent
    | ModelStreamStartedEvent
    | ModelStreamChunkEvent
    | ModelStreamEndedEvent
    | ModelStreamAbortedEvent
    | ToolCallEvent
    | ToolResultEvent
    | AgentStepEvent
    | KBQueryEvent
    | KBResultsEvent
    | KBChunkFilteredEvent
    | KBGroundingAppliedEvent
    | MemoryReadEvent
    | MemoryWriteEvent
    | MemoryDeleteEvent
    | DataReadEvent
    | DataFilteredEvent
    | DataBlockedEvent
    | ApprovalRequestedEvent
    | ApprovalGrantedEvent
    | ApprovalRejectedEvent
    | EvaluationRunEvent
    | EvaluationResultEvent
    | EvaluationWarningEvent
    | EvaluationBlockedEvent
    | QuotaCheckedEvent
    | QuotaLimitedEvent
    | QuotaExceededEvent
    | QuotaCommittedEvent
    | OutputValidationStartedEvent
    | OutputValidationPassedEvent
    | OutputValidationFailedEvent
    | SecretResolvedEvent
    | SecretDetectedBlockedEvent
    | PromptTemplateUsedEvent
    | OrchestrationStepEvent
    | ResourceCreatedEvent
    | ResourceUpdatedEvent
    | ResourceDeletedEvent
    | CliCommandStartedEvent
    | CliCommandCompletedEvent
    | CliCommandFailedEvent
    | InfraProvisionStartedEvent
    | InfraProvisionCompletedEvent
    | InfraProvisionFailedEvent
    | InfraDestroyStartedEvent
    | InfraDestroyCompletedEvent
    | InfraDestroyFailedEvent
    | ConfigChangeStartedEvent
    | ConfigChangeCompletedEvent
    | ConfigChangeFailedEvent
    | AuthStartedEvent
    | AuthSucceededEvent
    | AuthFailedEvent
    | MCPServerRegisteredEvent
    | MCPServerConnectedEvent
    | MCPServerDisconnectedEvent
    | MCPToolsDiscoveredEvent
    | AgentAttestationCreatedEvent
    | ComplianceProofComposedEvent
    | RiskRouteDecidedEvent
    | SnapshotCapturedEvent
    | ReplayDriftDetectedEvent
    | DisclosureDerivedGeneratedEvent
)


# ---------------------------------------------------------------------------
# Utility: convert GovernanceContext to AuditContext
# ---------------------------------------------------------------------------


def to_audit_context(context: object) -> AuditContext:
    """Convert a full GovernanceContext (or compatible dict-like object) to AuditContext.

    Accepts any object with org, actor, purpose, environment, and optional team attributes.
    """
    org_attr = getattr(context, "org", None)
    actor_attr = getattr(context, "actor", None)
    purpose = getattr(context, "purpose", "")
    environment = getattr(context, "environment", "")
    team_attr = getattr(context, "team", None)

    org_id = getattr(org_attr, "id", "") if org_attr is not None else ""
    actor_type = getattr(actor_attr, "type", "") if actor_attr is not None else ""
    actor_id = getattr(actor_attr, "id", "") if actor_attr is not None else ""

    audit_ctx = AuditContext(
        org=AuditContextOrg(id=str(org_id)),
        actor=AuditContextActor(type=str(actor_type), id=str(actor_id)),
        purpose=str(purpose),
        environment=str(environment),
    )

    if team_attr is not None:
        team_id = getattr(team_attr, "id", None)
        if team_id is not None:
            audit_ctx.team = AuditContextTeam(id=str(team_id))

    return audit_ctx


def to_audit_decisions(decisions: list[Any]) -> list[AuditPolicyDecision]:
    """Convert policy decisions to audit-ready policy decisions."""
    return [
        AuditPolicyDecision(
            effect=d.effect,
            reason=d.reason,
            code=d.code,
        )
        for d in decisions
    ]
