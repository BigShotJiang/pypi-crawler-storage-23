"""Event builder for Arelis audit events.

Ports ``packages/audit/src/event-builder.ts`` from the TypeScript SDK.
Provides factory functions for creating structured audit events with consistent
IDs, timestamps, and context resolution.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Literal

from arelis.audit.types import (
    AUDIT_SCHEMA_VERSION,
    AgentAttestationCreatedEvent,
    AgentStepEvent,
    AgentStepPolicy,
    ApprovalGrantedEvent,
    ApprovalRejectedEvent,
    ApprovalRequestedEvent,
    AuditContext,
    AuditDataSourceInfo,
    AuditKBInfo,
    AuditMemoryInfo,
    AuditModelInfo,
    AuditPolicyDecision,
    AuditPromptTemplateInfo,
    AuditResourceInfo,
    ComplianceProofComposedEvent,
    ConfigChangeCompletedEvent,
    ConfigChangeFailedEvent,
    ConfigChangeStartedEvent,
    DataBlockedEvent,
    DataFilteredEvent,
    DataReadEvent,
    DataRef,
    ErrorDetail,
    EvaluationBlockedEvent,
    EvaluationResultEvent,
    EvaluationRunEvent,
    EvaluationWarningEvent,
    KBChunkFilteredEvent,
    KBGroundingAppliedEvent,
    KBQueryEvent,
    KBResultsEvent,
    MCPServerRegisteredEvent,
    MCPToolsDiscoveredEvent,
    MemoryDeleteEvent,
    MemoryReadEvent,
    MemoryWriteEvent,
    ModelDeprecatedUsedEvent,
    ModelDisabledBlockedEvent,
    ModelFallbackUsedEvent,
    ModelRequestEvent,
    ModelResolvedEvent,
    ModelResponseEvent,
    ModelStreamAbortedEvent,
    ModelStreamChunkEvent,
    ModelStreamEndedEvent,
    ModelStreamStartedEvent,
    OrchestrationStepEvent,
    OutputValidationFailedEvent,
    OutputValidationPassedEvent,
    OutputValidationStartedEvent,
    PolicyEvaluatedEvent,
    PromptTemplateUsedEvent,
    QuotaCheckedEvent,
    QuotaCommittedEvent,
    QuotaExceededEvent,
    QuotaLimitedEvent,
    ResourceCreatedEvent,
    RiskRouteDecidedEvent,
    RunEndedEvent,
    RunErrorEvent,
    RunStartedEvent,
    SecretDetectedBlockedEvent,
    SecretResolvedEvent,
    SnapshotCapturedEvent,
    ToolCallEvent,
    ToolCallInfo,
    ToolResultEvent,
    to_audit_context,
)

if TYPE_CHECKING:
    from arelis.audit.types import AuditEventType


def _generate_event_id() -> str:
    """Generate a unique event ID."""
    return f"evt_{uuid.uuid4().hex[:12]}"


def _get_current_time() -> str:
    """Get current UTC time in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _create_base_event(
    event_type: AuditEventType,
    run_id: str,
    context: Any,
    parent_run_id: str | None = None,
) -> dict[str, Any]:
    """Create the base fields for an audit event."""
    audit_context = context if isinstance(context, AuditContext) else to_audit_context(context)

    base = {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "event_id": _generate_event_id(),
        "time": _get_current_time(),
        "run_id": run_id,
        "type": event_type,
        "context": audit_context,
    }

    if parent_run_id:
        base["parent_run_id"] = parent_run_id

    return base


def create_run_started_event(
    run_id: str,
    context: Any,
    parent_run_id: str | None = None,
    operation: str | None = None,
    snapshot_hash: str | None = None,
) -> RunStartedEvent:
    """Create a run started event."""
    base = _create_base_event("run.started", run_id, context, parent_run_id)
    return RunStartedEvent(**base, operation=operation, snapshot_hash=snapshot_hash)


def create_run_ended_event(
    run_id: str,
    context: Any,
    success: bool,
    duration_ms: float | None = None,
    parent_run_id: str | None = None,
) -> RunEndedEvent:
    """Create a run ended event."""
    base = _create_base_event("run.ended", run_id, context, parent_run_id)
    return RunEndedEvent(**base, success=success, duration_ms=duration_ms)


def create_run_error_event(
    run_id: str,
    context: Any,
    error: ErrorDetail | dict[str, Any],
    parent_run_id: str | None = None,
) -> RunErrorEvent:
    """Create a run error event."""
    base = _create_base_event("run.error", run_id, context, parent_run_id)
    if isinstance(error, dict):
        error = ErrorDetail(**error)
    return RunErrorEvent(**base, error=error)


def create_policy_evaluated_event(
    run_id: str,
    context: Any,
    checkpoint: str,
    decisions: list[AuditPolicyDecision],
    allowed: bool,
    policy_version: str | None = None,
    policy_snapshot_hash: str | None = None,
    policy_compiler_id: str | None = None,
    parent_run_id: str | None = None,
) -> PolicyEvaluatedEvent:
    """Create a policy evaluated event."""
    base = _create_base_event("policy.evaluated", run_id, context, parent_run_id)
    return PolicyEvaluatedEvent(
        **base,
        checkpoint=checkpoint,
        decisions=decisions,
        allowed=allowed,
        policy_version=policy_version,
        policy_snapshot_hash=policy_snapshot_hash,
        policy_compiler_id=policy_compiler_id,
    )


def create_model_request_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo | None = None,
    input_ref: DataRef | None = None,
    prompt_template: AuditPromptTemplateInfo | None = None,
    parent_run_id: str | None = None,
    *,
    model_id: str | None = None,
    request: object | None = None,
) -> ModelRequestEvent:
    """Create a model request event.

    Either *model* (an :class:`AuditModelInfo`) or *model_id* (a plain
    string) must be provided.  When *model_id* is given it is wrapped in
    a minimal ``AuditModelInfo``.
    """
    resolved_model = model or AuditModelInfo(id=model_id or "unknown")
    base = _create_base_event("model.request", run_id, context, parent_run_id)
    return ModelRequestEvent(
        **base,
        model=resolved_model,
        input_ref=input_ref,
        prompt_template=prompt_template,
    )


def create_model_response_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo | None = None,
    output_ref: DataRef | None = None,
    usage: dict[str, Any] | None = None,
    policy: list[AuditPolicyDecision] | None = None,
    parent_run_id: str | None = None,
    *,
    model_id: str | None = None,
    response: object | None = None,
) -> ModelResponseEvent:
    """Create a model response event.

    Either *model* or *model_id* must be provided.
    """
    resolved_model = model or AuditModelInfo(id=model_id or "unknown")
    base = _create_base_event("model.response", run_id, context, parent_run_id)
    return ModelResponseEvent(
        **base,
        model=resolved_model,
        output_ref=output_ref,
        usage=usage,
        policy=policy,
    )


def create_model_resolved_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo | None = None,
    route_id: str | None = None,
    fallback_used: bool | None = None,
    parent_run_id: str | None = None,
    model_id: str | None = None,
) -> ModelResolvedEvent:
    """Create a model resolved event."""
    base = _create_base_event("model.resolved", run_id, context, parent_run_id)
    resolved_model = model or AuditModelInfo(id=model_id or "")
    return ModelResolvedEvent(
        **base,
        model=resolved_model,
        route_id=route_id,
        fallback_used=fallback_used,
    )


def create_model_fallback_used_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    route_id: str | None = None,
    reason: str | None = None,
    parent_run_id: str | None = None,
) -> ModelFallbackUsedEvent:
    """Create a model fallback used event."""
    base = _create_base_event("model.fallback.used", run_id, context, parent_run_id)
    return ModelFallbackUsedEvent(
        **base,
        model=model,
        route_id=route_id,
        reason=reason,
    )


def create_model_deprecated_used_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    reason: str | None = None,
    parent_run_id: str | None = None,
) -> ModelDeprecatedUsedEvent:
    """Create a model deprecated used event."""
    base = _create_base_event("model.deprecated.used", run_id, context, parent_run_id)
    return ModelDeprecatedUsedEvent(**base, model=model, reason=reason)


def create_model_disabled_blocked_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    reason: str | None = None,
    parent_run_id: str | None = None,
) -> ModelDisabledBlockedEvent:
    """Create a model disabled blocked event."""
    base = _create_base_event("model.disabled.blocked", run_id, context, parent_run_id)
    return ModelDisabledBlockedEvent(**base, model=model, reason=reason)


def create_model_stream_started_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    parent_run_id: str | None = None,
) -> ModelStreamStartedEvent:
    """Create a model stream started event."""
    base = _create_base_event("model.stream.started", run_id, context, parent_run_id)
    return ModelStreamStartedEvent(**base, model=model)


def create_model_stream_chunk_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    chunk_type: str,
    size: int | None = None,
    parent_run_id: str | None = None,
) -> ModelStreamChunkEvent:
    """Create a model stream chunk event."""
    base = _create_base_event("model.stream.chunk", run_id, context, parent_run_id)
    return ModelStreamChunkEvent(**base, model=model, chunk_type=chunk_type, size=size)


def create_model_stream_ended_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    finish_reason: str | None = None,
    parent_run_id: str | None = None,
) -> ModelStreamEndedEvent:
    """Create a model stream ended event."""
    base = _create_base_event("model.stream.ended", run_id, context, parent_run_id)
    return ModelStreamEndedEvent(**base, model=model, finish_reason=finish_reason)


def create_model_stream_aborted_event(
    run_id: str,
    context: Any,
    model: AuditModelInfo,
    reason: str,
    parent_run_id: str | None = None,
) -> ModelStreamAbortedEvent:
    """Create a model stream aborted event."""
    base = _create_base_event("model.stream.aborted", run_id, context, parent_run_id)
    return ModelStreamAbortedEvent(**base, model=model, reason=reason)


def create_tool_call_event(
    run_id: str,
    context: Any,
    tool_name: str,
    args_ref: DataRef | None = None,
    parent_run_id: str | None = None,
) -> ToolCallEvent:
    """Create a tool call event."""
    base = _create_base_event("tool.call", run_id, context, parent_run_id)
    return ToolCallEvent(**base, tool_name=tool_name, args_ref=args_ref)


def create_tool_result_event(
    run_id: str,
    context: Any,
    tool_name: str,
    success: bool,
    result_ref: DataRef | None = None,
    error: ErrorDetail | dict[str, Any] | None = None,
    parent_run_id: str | None = None,
) -> ToolResultEvent:
    """Create a tool result event."""
    base = _create_base_event("tool.result", run_id, context, parent_run_id)
    if isinstance(error, dict):
        error = ErrorDetail(**error)
    return ToolResultEvent(
        **base,
        tool_name=tool_name,
        success=success,
        result_ref=result_ref,
        error=error,
    )


def create_agent_step_event(
    run_id: str,
    context: Any,
    step_number: int,
    step_type: Literal["plan", "execute", "observe"] = "execute",
    policy: AgentStepPolicy | dict[str, Any] | None = None,
    attestation_hash: str | None = None,
    tool_calls: list[ToolCallInfo] | list[dict[str, Any]] | None = None,
    parent_run_id: str | None = None,
) -> AgentStepEvent:
    """Create an agent step event."""
    base = _create_base_event("agent.step", run_id, context, parent_run_id)
    if isinstance(policy, dict):
        policy = AgentStepPolicy(**policy)
    if tool_calls is not None:
        tool_calls = [
            tc if isinstance(tc, ToolCallInfo) else ToolCallInfo(**tc) for tc in tool_calls
        ]
    return AgentStepEvent(
        **base,
        step_number=step_number,
        step_type=step_type,
        policy=policy,
        attestation_hash=attestation_hash,
        tool_calls=tool_calls,
    )


def create_agent_attestation_created_event(
    run_id: str,
    context: Any,
    step_number: int,
    step_type: Literal["plan", "execute", "observe"] = "execute",
    attestation_hash: str = "",
    policy_snapshot_hash: str | None = None,
    parent_run_id: str | None = None,
) -> AgentAttestationCreatedEvent:
    """Create an agent attestation created event."""
    base = _create_base_event("agent.attestation.created", run_id, context, parent_run_id)
    return AgentAttestationCreatedEvent(
        **base,
        step_number=step_number,
        step_type=step_type,
        attestation_hash=attestation_hash,
        policy_snapshot_hash=policy_snapshot_hash,
    )


def create_kb_query_event(
    run_id: str,
    context: Any,
    kb: AuditKBInfo,
    query_id: str,
    query_ref: DataRef | None = None,
    top_k: int | None = None,
    parent_run_id: str | None = None,
) -> KBQueryEvent:
    """Create a KB query event."""
    base = _create_base_event("kb.query", run_id, context, parent_run_id)
    return KBQueryEvent(
        **base,
        kb=kb,
        query_id=query_id,
        query_ref=query_ref,
        top_k=top_k,
    )


def create_kb_results_event(
    run_id: str,
    context: Any,
    kb: AuditKBInfo,
    query_id: str,
    chunk_count: int,
    chunk_refs: list[DataRef] | None = None,
    total_found: int | None = None,
    parent_run_id: str | None = None,
) -> KBResultsEvent:
    """Create a KB results event."""
    base = _create_base_event("kb.results", run_id, context, parent_run_id)
    return KBResultsEvent(
        **base,
        kb=kb,
        query_id=query_id,
        chunk_count=chunk_count,
        chunk_refs=chunk_refs,
        total_found=total_found,
    )


def create_kb_chunk_filtered_event(
    run_id: str,
    context: Any,
    kb: AuditKBInfo,
    query_id: str,
    reason: str,
    chunk_ref: DataRef | None = None,
    policy: AuditPolicyDecision | None = None,
    parent_run_id: str | None = None,
) -> KBChunkFilteredEvent:
    """Create a KB chunk filtered event."""
    base = _create_base_event("kb.chunk.filtered", run_id, context, parent_run_id)
    return KBChunkFilteredEvent(
        **base,
        kb=kb,
        query_id=query_id,
        reason=reason,
        chunk_ref=chunk_ref,
        policy=policy,
    )


def create_kb_grounding_applied_event(
    run_id: str,
    context: Any,
    kbs: list[AuditKBInfo],
    query_ids: list[str],
    chunks_used: int,
    chunks_filtered: int,
    chunk_refs: list[DataRef] | None = None,
    parent_run_id: str | None = None,
) -> KBGroundingAppliedEvent:
    """Create a KB grounding applied event."""
    base = _create_base_event("kb.grounding.applied", run_id, context, parent_run_id)
    return KBGroundingAppliedEvent(
        **base,
        kbs=kbs,
        query_ids=query_ids,
        chunks_used=chunks_used,
        chunks_filtered=chunks_filtered,
        chunk_refs=chunk_refs,
    )


def create_memory_read_event(
    run_id: str,
    context: Any,
    memory: AuditMemoryInfo,
    parent_run_id: str | None = None,
) -> MemoryReadEvent:
    """Create a memory read event."""
    base = _create_base_event("memory.read", run_id, context, parent_run_id)
    return MemoryReadEvent(**base, memory=memory)


def create_memory_write_event(
    run_id: str,
    context: Any,
    memory: AuditMemoryInfo,
    value_ref: DataRef | None = None,
    parent_run_id: str | None = None,
) -> MemoryWriteEvent:
    """Create a memory write event."""
    base = _create_base_event("memory.write", run_id, context, parent_run_id)
    return MemoryWriteEvent(**base, memory=memory, value_ref=value_ref)


def create_memory_delete_event(
    run_id: str,
    context: Any,
    memory: AuditMemoryInfo,
    parent_run_id: str | None = None,
) -> MemoryDeleteEvent:
    """Create a memory delete event."""
    base = _create_base_event("memory.delete", run_id, context, parent_run_id)
    return MemoryDeleteEvent(**base, memory=memory)


def create_data_read_event(
    run_id: str,
    context: Any,
    source: AuditDataSourceInfo,
    query_ref: DataRef | None = None,
    parent_run_id: str | None = None,
) -> DataReadEvent:
    """Create a data read event."""
    base = _create_base_event("data.read", run_id, context, parent_run_id)
    return DataReadEvent(**base, source=source, query_ref=query_ref)


def create_data_filtered_event(
    run_id: str,
    context: Any,
    source: AuditDataSourceInfo,
    reason: str,
    parent_run_id: str | None = None,
) -> DataFilteredEvent:
    """Create a data filtered event."""
    base = _create_base_event("data.filtered", run_id, context, parent_run_id)
    return DataFilteredEvent(**base, source=source, reason=reason)


def create_data_blocked_event(
    run_id: str,
    context: Any,
    source: AuditDataSourceInfo,
    reason: str,
    parent_run_id: str | None = None,
) -> DataBlockedEvent:
    """Create a data blocked event."""
    base = _create_base_event("data.blocked", run_id, context, parent_run_id)
    return DataBlockedEvent(**base, source=source, reason=reason)


def create_approval_requested_event(
    run_id: str,
    context: Any,
    approval_id: str,
    reason: str,
    approvers: list[str] | None = None,
    parent_run_id: str | None = None,
) -> ApprovalRequestedEvent:
    """Create an approval requested event."""
    base = _create_base_event("approval.requested", run_id, context, parent_run_id)
    return ApprovalRequestedEvent(
        **base,
        approval_id=approval_id,
        reason=reason,
        approvers=approvers or [],
    )


def create_approval_granted_event(
    run_id: str,
    context: Any,
    approval_id: str,
    resolved_by: str,
    reason: str | None = None,
    parent_run_id: str | None = None,
) -> ApprovalGrantedEvent:
    """Create an approval granted event."""
    base = _create_base_event("approval.granted", run_id, context, parent_run_id)
    return ApprovalGrantedEvent(
        **base,
        approval_id=approval_id,
        resolved_by=resolved_by,
        reason=reason,
    )


def create_approval_rejected_event(
    run_id: str,
    context: Any,
    approval_id: str,
    resolved_by: str,
    reason: str | None = None,
    parent_run_id: str | None = None,
) -> ApprovalRejectedEvent:
    """Create an approval rejected event."""
    base = _create_base_event("approval.rejected", run_id, context, parent_run_id)
    return ApprovalRejectedEvent(
        **base,
        approval_id=approval_id,
        resolved_by=resolved_by,
        reason=reason,
    )


def create_evaluation_run_event(
    run_id: str,
    context: Any,
    evaluator_id: str,
    version: str | None = None,
    parent_run_id: str | None = None,
) -> EvaluationRunEvent:
    """Create an evaluation run event."""
    base = _create_base_event("evaluation.run", run_id, context, parent_run_id)
    return EvaluationRunEvent(**base, evaluator_id=evaluator_id, version=version)


def create_evaluation_result_event(
    run_id: str,
    context: Any,
    evaluator_id: str,
    effect: Literal["pass", "warn", "block"],
    finding_count: int,
    version: str | None = None,
    max_severity: str | None = None,
    parent_run_id: str | None = None,
) -> EvaluationResultEvent:
    """Create an evaluation result event."""
    base = _create_base_event("evaluation.result", run_id, context, parent_run_id)
    return EvaluationResultEvent(
        **base,
        evaluator_id=evaluator_id,
        effect=effect,
        finding_count=finding_count,
        version=version,
        max_severity=max_severity,
    )


def create_evaluation_warning_event(
    run_id: str,
    context: Any,
    evaluator_id: str,
    message: str,
    parent_run_id: str | None = None,
) -> EvaluationWarningEvent:
    """Create an evaluation warning event."""
    base = _create_base_event("evaluation.warning", run_id, context, parent_run_id)
    return EvaluationWarningEvent(**base, evaluator_id=evaluator_id, message=message)


def create_evaluation_blocked_event(
    run_id: str,
    context: Any,
    evaluator_id: str,
    reason: str,
    parent_run_id: str | None = None,
) -> EvaluationBlockedEvent:
    """Create an evaluation blocked event."""
    base = _create_base_event("evaluation.blocked", run_id, context, parent_run_id)
    return EvaluationBlockedEvent(**base, evaluator_id=evaluator_id, reason=reason)


def create_quota_checked_event(
    run_id: str,
    context: Any,
    key: Any,
    parent_run_id: str | None = None,
) -> QuotaCheckedEvent:
    """Create a quota checked event."""
    base = _create_base_event("quota.checked", run_id, context, parent_run_id)
    return QuotaCheckedEvent(**base, key=key)


def create_quota_limited_event(
    run_id: str,
    context: Any,
    key: Any,
    reason: str,
    parent_run_id: str | None = None,
) -> QuotaLimitedEvent:
    """Create a quota limited event."""
    base = _create_base_event("quota.limited", run_id, context, parent_run_id)
    return QuotaLimitedEvent(**base, key=key, reason=reason)


def create_quota_exceeded_event(
    run_id: str,
    context: Any,
    key: Any,
    reason: str,
    parent_run_id: str | None = None,
) -> QuotaExceededEvent:
    """Create a quota exceeded event."""
    base = _create_base_event("quota.exceeded", run_id, context, parent_run_id)
    return QuotaExceededEvent(**base, key=key, reason=reason)


def create_quota_committed_event(
    run_id: str,
    context: Any,
    key: Any,
    parent_run_id: str | None = None,
) -> QuotaCommittedEvent:
    """Create a quota committed event."""
    base = _create_base_event("quota.committed", run_id, context, parent_run_id)
    return QuotaCommittedEvent(**base, key=key)


def create_output_validation_started_event(
    run_id: str,
    context: Any,
    schema_type: str,
    parent_run_id: str | None = None,
) -> OutputValidationStartedEvent:
    """Create an output validation started event."""
    base = _create_base_event("output.validation.started", run_id, context, parent_run_id)
    return OutputValidationStartedEvent(**base, schema_type=schema_type)


def create_output_validation_passed_event(
    run_id: str,
    context: Any,
    schema_type: str,
    parent_run_id: str | None = None,
) -> OutputValidationPassedEvent:
    """Create an output validation passed event."""
    base = _create_base_event("output.validation.passed", run_id, context, parent_run_id)
    return OutputValidationPassedEvent(**base, schema_type=schema_type)


def create_output_validation_failed_event(
    run_id: str,
    context: Any,
    schema_type: str,
    error: str,
    parent_run_id: str | None = None,
) -> OutputValidationFailedEvent:
    """Create an output validation failed event."""
    base = _create_base_event("output.validation.failed", run_id, context, parent_run_id)
    return OutputValidationFailedEvent(**base, schema_type=schema_type, error=error)


def create_secret_resolved_event(
    run_id: str,
    context: Any,
    ref: str,
    resolver_id: str,
    parent_run_id: str | None = None,
) -> SecretResolvedEvent:
    """Create a secret resolved event."""
    base = _create_base_event("secret.resolved", run_id, context, parent_run_id)
    return SecretResolvedEvent(**base, ref=ref, resolver_id=resolver_id)


def create_secret_detected_blocked_event(
    run_id: str,
    context: Any,
    reason: str,
    parent_run_id: str | None = None,
) -> SecretDetectedBlockedEvent:
    """Create a secret detected blocked event."""
    base = _create_base_event("secret.detected.blocked", run_id, context, parent_run_id)
    return SecretDetectedBlockedEvent(**base, reason=reason)


def create_prompt_template_used_event(
    run_id: str,
    context: Any,
    template: AuditPromptTemplateInfo,
    parent_run_id: str | None = None,
) -> PromptTemplateUsedEvent:
    """Create a prompt template used event."""
    base = _create_base_event("prompt.template.used", run_id, context, parent_run_id)
    return PromptTemplateUsedEvent(**base, template=template)


def create_orchestration_step_event(
    run_id: str,
    context: Any,
    operation: str,
    step: str,
    status: Literal["started", "completed", "failed"] = "started",
    duration_ms: float | None = None,
    error: ErrorDetail | None = None,
    details: dict[str, Any] | None = None,
    parent_run_id: str | None = None,
) -> OrchestrationStepEvent:
    """Create an orchestration step event."""
    base = _create_base_event("orchestration.step", run_id, context, parent_run_id)
    return OrchestrationStepEvent(
        **base,
        operation=operation,
        step=step,
        status=status,
        duration_ms=duration_ms,
        error=error,
        details=details,
    )


def create_resource_created_event(
    run_id: str,
    context: Any,
    resource: AuditResourceInfo,
    operation: str | None = None,
    parent_run_id: str | None = None,
) -> ResourceCreatedEvent:
    """Create a resource created event."""
    base = _create_base_event("resource.created", run_id, context, parent_run_id)
    return ResourceCreatedEvent(**base, resource=resource, operation=operation)


def create_mcp_server_registered_event(
    run_id: str,
    context: Any,
    server_id: str,
    transport: Literal["stdio", "http"] = "stdio",
    parent_run_id: str | None = None,
) -> MCPServerRegisteredEvent:
    """Create an MCP server registered event."""
    base = _create_base_event("mcp.server.registered", run_id, context, parent_run_id)
    return MCPServerRegisteredEvent(**base, server_id=server_id, transport=transport)


def create_mcp_tools_discovered_event(
    run_id: str,
    context: Any,
    server_id: str,
    total_discovered: int,
    registered_count: int,
    skipped_count: int,
    tool_names: list[str] | None = None,
    parent_run_id: str | None = None,
) -> MCPToolsDiscoveredEvent:
    """Create an MCP tools discovered event."""
    base = _create_base_event("mcp.tools.discovered", run_id, context, parent_run_id)
    return MCPToolsDiscoveredEvent(
        **base,
        server_id=server_id,
        total_discovered=total_discovered,
        registered_count=registered_count,
        skipped_count=skipped_count,
        tool_names=tool_names,
    )


def create_snapshot_captured_event(
    run_id: str,
    context: Any,
    snapshot_hash: str,
    snapshot_schema: str = "v1",
    policy_snapshot_hash: str | None = None,
    model_route_id: str | None = None,
    tool_registry_hash: str | None = None,
    config_state_hash: str | None = None,
    parent_run_id: str | None = None,
) -> SnapshotCapturedEvent:
    """Create a snapshot captured event."""
    base = _create_base_event("snapshot.captured", run_id, context, parent_run_id)
    return SnapshotCapturedEvent(
        **base,
        snapshot_hash=snapshot_hash,
        snapshot_schema=snapshot_schema,
        policy_snapshot_hash=policy_snapshot_hash,
        model_route_id=model_route_id,
        tool_registry_hash=tool_registry_hash,
        config_state_hash=config_state_hash,
    )


def create_risk_route_decided_event(
    run_id: str,
    context: Any,
    route: Literal["auto_execute", "sandbox", "require_approval", "block"],
    score: float = 0.0,
    factors: list[str] | None = None,
    deterministic_inputs_hash: str = "",
    parent_run_id: str | None = None,
) -> RiskRouteDecidedEvent:
    """Create a risk route decided event."""
    base = _create_base_event("risk.route.decided", run_id, context, parent_run_id)
    return RiskRouteDecidedEvent(
        **base,
        route=route,
        score=score,
        factors=factors or [],
        deterministic_inputs_hash=deterministic_inputs_hash,
    )


def create_compliance_proof_composed_event(
    run_id: str,
    context: Any,
    artifact_id: str,
    artifact_schema: str,
    layer_count: int,
    layer_kinds: list[str],
    includes_narrowing_proof: bool = False,
    includes_lineage_proof: bool = False,
    parent_run_id: str | None = None,
) -> ComplianceProofComposedEvent:
    """Create a compliance proof composed event."""
    base = _create_base_event("compliance.proof.composed", run_id, context, parent_run_id)
    return ComplianceProofComposedEvent(
        **base,
        artifact_id=artifact_id,
        artifact_schema=artifact_schema,
        layer_count=layer_count,
        layer_kinds=layer_kinds,
        includes_narrowing_proof=includes_narrowing_proof,
        includes_lineage_proof=includes_lineage_proof,
    )


def create_config_change_started_event(
    run_id: str,
    context: Any,
    path: str | None = None,
    value_ref: DataRef | None = None,
    parent_run_id: str | None = None,
) -> ConfigChangeStartedEvent:
    """Create a config change started event."""
    base = _create_base_event("config.change.started", run_id, context, parent_run_id)
    return ConfigChangeStartedEvent(
        **base,
        path=path,
        value_ref=value_ref,
    )


def create_config_change_completed_event(
    run_id: str,
    context: Any,
    path: str | None = None,
    duration_ms: float | None = None,
    parent_run_id: str | None = None,
) -> ConfigChangeCompletedEvent:
    """Create a config change completed event."""
    base = _create_base_event("config.change.completed", run_id, context, parent_run_id)
    return ConfigChangeCompletedEvent(
        **base,
        path=path,
        duration_ms=duration_ms,
    )


def create_config_change_failed_event(
    run_id: str,
    context: Any,
    path: str | None = None,
    error: ErrorDetail | None = None,
    parent_run_id: str | None = None,
) -> ConfigChangeFailedEvent:
    """Create a config change failed event."""
    base = _create_base_event("config.change.failed", run_id, context, parent_run_id)
    return ConfigChangeFailedEvent(
        **base,
        path=path,
        error=error or ErrorDetail(type="", message=""),
    )
