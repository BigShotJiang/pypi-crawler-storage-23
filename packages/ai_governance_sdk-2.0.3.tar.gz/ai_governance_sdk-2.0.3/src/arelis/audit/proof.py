from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal, Protocol, runtime_checkable

from arelis.audit.cag import (
    CausalGraph,
    _hash_object,
    _hash_payload,
)

__all__ = [
    "COMPLIANCE_PROOF_SCHEMA_V1",
    "COMPLIANCE_PROOF_SCHEMA_V2",
    "ComplianceLayerKind",
    "DisclosureRule",
    "DisclosureRuleMatch",
    "DisclosureRuleReveal",
    "DisclosureRuleRedact",
    "LayerProof",
    "NarrowingProof",
    "LineageProof",
    "DisclosureProof",
    "ProofInput",
    "ProofComposedOptions",
    "ProofVerificationInput",
    "ProofVerificationResult",
    "ProofProvider",
    "HashProofProvider",
    "NoOpProofProvider",
    "CausalGraphCommitment",
    "compute_merkle_root",
    "create_causal_graph_commitment",
    "verify_causal_graph_commitment",
    "create_layer_proof",
    "create_narrowing_proof",
    "create_lineage_proof",
    "verify_composed_proof_details",
    "Signer",
]

COMPLIANCE_PROOF_SCHEMA_V1 = "arelis.audit.compliance.v1"
COMPLIANCE_PROOF_SCHEMA_V2 = "arelis.audit.compliance.composed.v2"

ComplianceLayerKind = Literal["infra", "config", "auth", "inference", "agent", "tools"]


# ---------------------------------------------------------------------------
# Signer protocol (used for commitments)
# ---------------------------------------------------------------------------


@runtime_checkable
class Signer(Protocol):
    """Protocol for signing payloads."""

    @property
    def id(self) -> str: ...

    def sign(self, payload: str) -> str: ...

    def verify(self, payload: str, signature: str) -> bool: ...


# ---------------------------------------------------------------------------
# Disclosure rule types
# ---------------------------------------------------------------------------


@dataclass
class DisclosureRuleMatch:
    """Match criteria for a disclosure rule."""

    event_types: list[str] | None = None
    node_kinds: list[Literal["run", "event"]] | None = None


@dataclass
class DisclosureRuleReveal:
    """Fields to reveal in a disclosure rule."""

    fields: list[str] | None = None
    attributes: list[str] | None = None


@dataclass
class DisclosureRuleRedact:
    """Fields to redact in a disclosure rule."""

    fields: list[str] | None = None


@dataclass
class DisclosureRule:
    """A disclosure rule for compliance proofs."""

    id: str
    description: str | None = None
    match: DisclosureRuleMatch | None = None
    reveal: DisclosureRuleReveal | None = None
    redact: DisclosureRuleRedact | None = None


# ---------------------------------------------------------------------------
# Proof data structures
# ---------------------------------------------------------------------------


@dataclass
class LayerProof:
    """Proof for a single compliance layer."""

    layer: ComplianceLayerKind
    digest: str
    algorithm: Literal["sha256"] = "sha256"


@dataclass
class NarrowingProof:
    """Narrowing proof binding disclosure rules to a commitment."""

    id: str
    digest: str
    algorithm: Literal["sha256"] = "sha256"
    rule_ids: list[str] = field(default_factory=list)
    policy_snapshot_hash: str | None = None


@dataclass
class LineageProof:
    """Lineage proof for the causal graph structure."""

    id: str
    digest: str
    algorithm: Literal["sha256"] = "sha256"
    node_count: int = 0
    edge_count: int = 0


@dataclass
class DisclosureProof:
    """A disclosure proof for compliance verification."""

    id: str
    kind: Literal["zk", "composed"]
    created_at: str
    commitment_root: str
    rule_ids: list[str] = field(default_factory=list)
    proof: str = ""
    schema_version: str | None = None
    layers: list[LayerProof] | None = None
    narrowing_proof: NarrowingProof | None = None
    lineage_proof: LineageProof | None = None
    zk: dict[str, object] | None = None
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Commitment
# ---------------------------------------------------------------------------


@dataclass
class CausalGraphCommitment:
    """A cryptographic commitment to a causal graph."""

    run_id: str
    root: str
    algorithm: Literal["sha256"] = "sha256"
    created_at: str = ""
    node_count: int = 0
    edge_count: int = 0
    signer_id: str | None = None
    signature: str | None = None


def _combine_hashes(left: str, right: str) -> str:
    return _hash_payload(f"{left}{right}")


def compute_merkle_root(hashes: list[str]) -> str:
    """Compute a Merkle root from a list of hash strings."""
    if not hashes:
        return _hash_payload("")

    level = list(hashes)
    while len(level) > 1:
        next_level: list[str] = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else left
            next_level.append(_combine_hashes(left, right))
        level = next_level

    return level[0]


def create_causal_graph_commitment(
    graph: CausalGraph,
    signer: Signer | None = None,
) -> CausalGraphCommitment:
    """Create a cryptographic commitment to a causal graph."""
    node_digests = sorted(node.digest for node in graph.nodes)
    root = compute_merkle_root(node_digests)

    commitment = CausalGraphCommitment(
        run_id=graph.run_id,
        root=root,
        algorithm="sha256",
        created_at=datetime.now(timezone.utc).isoformat(),
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
    )

    if signer is not None:
        payload = f"{commitment.run_id}:{commitment.root}:{commitment.created_at}"
        commitment.signer_id = signer.id
        commitment.signature = signer.sign(payload)

    return commitment


def verify_causal_graph_commitment(
    graph: CausalGraph,
    commitment: CausalGraphCommitment,
    signer: Signer | None = None,
) -> bool:
    """Verify a causal graph commitment against the graph."""
    recalculated = create_causal_graph_commitment(graph)
    if recalculated.root != commitment.root:
        return False

    if commitment.signature is not None and signer is not None:
        payload = f"{commitment.run_id}:{commitment.root}:{commitment.created_at}"
        return signer.verify(payload, commitment.signature)

    return True


# ---------------------------------------------------------------------------
# Layer / Narrowing / Lineage proof constructors
# ---------------------------------------------------------------------------


def create_layer_proof(layer: ComplianceLayerKind, payload: object) -> LayerProof:
    """Create a layer proof from a layer kind and payload."""
    return LayerProof(
        layer=layer,
        digest=_hash_object({"layer": layer, "payload": payload}),
        algorithm="sha256",
    )


def create_narrowing_proof(
    commitment_root: str,
    rule_ids: list[str],
    policy_snapshot_hash: str | None = None,
) -> NarrowingProof:
    """Create a narrowing proof binding rules to a commitment."""
    sorted_rule_ids = sorted(rule_ids)
    payload = {
        "commitmentRoot": commitment_root,
        "ruleIds": sorted_rule_ids,
        "policySnapshotHash": policy_snapshot_hash,
    }
    digest = _hash_object(payload)
    return NarrowingProof(
        id=f"narrowing_{digest[:16]}",
        digest=digest,
        algorithm="sha256",
        rule_ids=sorted_rule_ids,
        policy_snapshot_hash=policy_snapshot_hash,
    )


def create_lineage_proof(graph: CausalGraph) -> LineageProof:
    """Create a lineage proof for the causal graph structure."""
    sorted_node_ids = sorted(node.id for node in graph.nodes)
    sorted_edges = sorted(
        [{"from": edge.from_node, "to": edge.to_node, "kind": edge.kind} for edge in graph.edges],
        key=lambda e: f"{e['kind']}:{e['from']}:{e['to']}",
    )
    payload = {
        "runId": graph.run_id,
        "nodeIds": sorted_node_ids,
        "edges": sorted_edges,
    }
    digest = _hash_object(payload)
    return LineageProof(
        id=f"lineage_{digest[:16]}",
        digest=digest,
        algorithm="sha256",
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
    )


# ---------------------------------------------------------------------------
# Proof verification helpers
# ---------------------------------------------------------------------------


@dataclass
class ProofVerificationResult:
    """Result of proof verification."""

    valid: bool
    reason: str | None = None
    reason_code: str | None = None
    reason_codes: list[str] | None = None
    failed_layer: ComplianceLayerKind | None = None


def verify_composed_proof_details(
    proof: DisclosureProof,
    commitment_root: str,
    expected_rule_ids: list[str],
    expected_policy_snapshot_hash: str | None = None,
) -> ProofVerificationResult:
    """Verify composed proof details."""
    errors: list[str] = []

    if proof.schema_version != COMPLIANCE_PROOF_SCHEMA_V2:
        errors.append("schema.mismatch")

    if not proof.layers or len(proof.layers) == 0:
        errors.append("layers.missing")

    if proof.narrowing_proof is None:
        errors.append("narrowing.missing")

    if proof.lineage_proof is None:
        errors.append("lineage.missing")

    if proof.narrowing_proof is not None:
        expected_narrowing = create_narrowing_proof(
            commitment_root=commitment_root,
            rule_ids=expected_rule_ids,
            policy_snapshot_hash=expected_policy_snapshot_hash,
        )
        if expected_narrowing.digest != proof.narrowing_proof.digest:
            errors.append("narrowing.invalid_digest")

    if errors:
        return ProofVerificationResult(
            valid=False,
            reason=f"Composed proof validation failed: {', '.join(errors)}",
            reason_code=errors[0],
            reason_codes=errors,
        )

    return ProofVerificationResult(valid=True)


# ---------------------------------------------------------------------------
# Proof input types
# ---------------------------------------------------------------------------


@dataclass
class ProofComposedOptions:
    """Options for composed proof creation."""

    layers: list[dict[str, object]] | None = None
    include_narrowing_proof: bool = True
    include_lineage_proof: bool = True
    enable_zk: bool = False


@dataclass
class ProofInput:
    """Input for proof creation."""

    graph: CausalGraph
    commitment: CausalGraphCommitment
    disclosure_rules: list[DisclosureRule]
    policy_snapshot_hash: str | None = None
    composed: ProofComposedOptions | None = None


@dataclass
class ProofVerificationInput:
    """Input for proof verification."""

    commitment: CausalGraphCommitment
    proof: DisclosureProof
    disclosure_rules: list[DisclosureRule]
    policy_snapshot_hash: str | None = None
    expect_composed: bool = False


# ---------------------------------------------------------------------------
# ProofProvider protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ProofProvider(Protocol):
    """Protocol for creating and verifying compliance proofs."""

    @property
    def id(self) -> str: ...

    async def create_proof(self, input: ProofInput) -> DisclosureProof: ...

    async def verify_proof(self, input: ProofVerificationInput) -> ProofVerificationResult: ...


# ---------------------------------------------------------------------------
# HashProofProvider
# ---------------------------------------------------------------------------


class HashProofProvider:
    """Hash-based proof provider for compliance verification."""

    def __init__(self, id: str = "hash-proof-provider") -> None:
        self._id = id

    @property
    def id(self) -> str:
        return self._id

    async def create_proof(self, input: ProofInput) -> DisclosureProof:
        """Create a hash-based disclosure proof."""
        rule_ids = sorted(rule.id for rule in input.disclosure_rules)
        created_at = datetime.now(timezone.utc).isoformat()

        if input.composed is not None:
            # Composed proof
            composed = input.composed
            if composed.layers and len(composed.layers) > 0:
                layers = [
                    create_layer_proof(layer["layer"], layer["payload"])  # type: ignore[arg-type]
                    for layer in composed.layers
                ]
            else:
                # Default layers from graph
                layers = [
                    create_layer_proof(
                        "infra",
                        [
                            {"from": e.from_node, "to": e.to_node, "kind": e.kind}
                            for e in input.graph.edges
                            if e.kind == "provisioned"
                        ],
                    ),
                    create_layer_proof(
                        "config",
                        [
                            {"from": e.from_node, "to": e.to_node, "kind": e.kind}
                            for e in input.graph.edges
                            if e.kind == "configured"
                        ],
                    ),
                    create_layer_proof(
                        "auth",
                        [
                            {"from": e.from_node, "to": e.to_node, "kind": e.kind}
                            for e in input.graph.edges
                            if e.kind == "authenticated"
                        ],
                    ),
                    create_layer_proof(
                        "inference",
                        [
                            n.id
                            for n in input.graph.nodes
                            if n.event_type is not None and n.event_type.startswith("model.")
                        ],
                    ),
                    create_layer_proof(
                        "agent",
                        [
                            n.id
                            for n in input.graph.nodes
                            if n.event_type is not None and n.event_type.startswith("agent.")
                        ],
                    ),
                    create_layer_proof(
                        "tools",
                        [
                            n.id
                            for n in input.graph.nodes
                            if n.event_type in ("tool.call", "tool.result")
                        ],
                    ),
                ]

            narrowing_proof = (
                None
                if composed.include_narrowing_proof is False
                else create_narrowing_proof(
                    commitment_root=input.commitment.root,
                    rule_ids=rule_ids,
                    policy_snapshot_hash=input.policy_snapshot_hash,
                )
            )

            lineage_proof = (
                None
                if composed.include_lineage_proof is False
                else create_lineage_proof(input.graph)
            )

            composed_root = _hash_object(
                {
                    "layers": [layer.digest for layer in layers],
                    "narrowingProof": narrowing_proof.digest if narrowing_proof else None,
                    "lineageProof": lineage_proof.digest if lineage_proof else None,
                }
            )

            composed_payload = {
                "root": input.commitment.root,
                "rules": rule_ids,
                "policySnapshotHash": input.policy_snapshot_hash,
                "composedRoot": composed_root,
            }

            return DisclosureProof(
                id=f"proof_{_hash_object(composed_payload)[:16]}",
                kind="composed",
                schema_version=COMPLIANCE_PROOF_SCHEMA_V2,
                created_at=created_at,
                commitment_root=input.commitment.root,
                rule_ids=rule_ids,
                proof=_hash_object(composed_payload),
                layers=layers,
                narrowing_proof=narrowing_proof,
                lineage_proof=lineage_proof,
                zk={
                    "enabled": composed.enable_zk,
                    "provider": self._id if composed.enable_zk else None,
                },
                metadata={"provider": self._id, "composedRoot": composed_root},
            )

        # Legacy (non-composed) proof
        payload = {
            "root": input.commitment.root,
            "rules": rule_ids,
            "policySnapshotHash": input.policy_snapshot_hash,
        }

        return DisclosureProof(
            id=f"proof_{_hash_object(payload)[:16]}",
            kind="zk",
            schema_version=COMPLIANCE_PROOF_SCHEMA_V1,
            created_at=created_at,
            commitment_root=input.commitment.root,
            rule_ids=rule_ids,
            proof=_hash_object(payload),
            metadata={"provider": self._id},
        )

    async def verify_proof(self, input: ProofVerificationInput) -> ProofVerificationResult:
        """Verify a hash-based disclosure proof."""
        if input.expect_composed and input.proof.schema_version != COMPLIANCE_PROOF_SCHEMA_V2:
            return ProofVerificationResult(
                valid=False,
                reason="Expected composed proof schema",
                reason_code="schema.expected_composed",
                reason_codes=["schema.expected_composed"],
            )

        if input.proof.schema_version == COMPLIANCE_PROOF_SCHEMA_V2:
            return verify_composed_proof_details(
                proof=input.proof,
                commitment_root=input.commitment.root,
                expected_rule_ids=[rule.id for rule in input.disclosure_rules],
                expected_policy_snapshot_hash=input.policy_snapshot_hash,
            )

        # Legacy verification
        payload = {
            "root": input.commitment.root,
            "rules": sorted(rule.id for rule in input.disclosure_rules),
            "policySnapshotHash": input.policy_snapshot_hash,
        }

        expected = _hash_object(payload)
        if expected != input.proof.proof:
            return ProofVerificationResult(
                valid=False,
                reason="Proof hash mismatch",
                reason_code="legacy.hash_mismatch",
                reason_codes=["legacy.hash_mismatch"],
            )

        return ProofVerificationResult(valid=True)


# ---------------------------------------------------------------------------
# NoOpProofProvider
# ---------------------------------------------------------------------------


class NoOpProofProvider:
    """No-op proof provider for testing."""

    def __init__(self, id: str = "noop-proof-provider") -> None:
        self._id = id

    @property
    def id(self) -> str:
        return self._id

    async def create_proof(self, input: ProofInput) -> DisclosureProof:
        return DisclosureProof(
            id=f"proof_{input.commitment.root[:12]}",
            kind="zk",
            schema_version=COMPLIANCE_PROOF_SCHEMA_V1,
            created_at=datetime.now(timezone.utc).isoformat(),
            commitment_root=input.commitment.root,
            rule_ids=[rule.id for rule in input.disclosure_rules],
            proof="noop",
            metadata={"provider": self._id},
        )

    async def verify_proof(self, input: ProofVerificationInput) -> ProofVerificationResult:
        if input.proof.proof == "noop":
            return ProofVerificationResult(valid=True)

        return ProofVerificationResult(
            valid=False,
            reason="Unsupported proof format",
            reason_code="legacy.unsupported_format",
            reason_codes=["legacy.unsupported_format"],
        )
