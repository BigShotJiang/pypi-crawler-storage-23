"""ArelisClient -- unified entry point with 13 namespaced APIs.

Ports ``packages/sdk/src/client.ts`` from the TypeScript SDK.
The client provides descriptor-based namespace objects so consumers can write
``client.models.generate()``, ``client.agents.run()``, etc.

Each namespace is implemented as a private class whose ``__init__`` receives
the owning :class:`ArelisClient` instance.  The namespaces are exposed via
:func:`property` descriptors on the client.
"""

from __future__ import annotations

import warnings
from collections.abc import AsyncIterator
from typing import Any, Literal

from arelis.agents.runtime import AgentRuntime
from arelis.agents.types import AgentLimits, AgentResult
from arelis.agents.types import AgentRunInput as _RuntimeAgentRunInput
from arelis.audit import (
    SnapshotBundle,
    cag,
    create_approval_requested_event,
    create_model_request_event,
    create_model_resolved_event,
    create_model_response_event,
    create_model_stream_aborted_event,
    create_model_stream_chunk_event,
    create_model_stream_ended_event,
    create_model_stream_started_event,
    create_policy_evaluated_event,
    create_risk_route_decided_event,
    create_run_ended_event,
    create_run_started_event,
    create_snapshot_captured_event,
)
from arelis.audit.artifacts import ProofJob, ProofJobQueue
from arelis.audit.cag_store import CausalGraphStore
from arelis.audit.proof import (
    DisclosureProof,
    HashProofProvider,
    ProofComposedOptions,
    ProofInput,
    ProofProvider,
    Signer,
    create_causal_graph_commitment,
)
from arelis.audit.sink import AuditSink
from arelis.audit.types import AuditModelInfo, to_audit_decisions
from arelis.compliance.disclosure import resolve_disclosure_rules
from arelis.compliance.replay import replay_causal_graph
from arelis.compliance.types import (
    COMPLIANCE_ARTIFACT_SCHEMA_V1,
    COMPLIANCE_ARTIFACT_SCHEMA_V2,
    COMPLIANCE_PROOF_SCHEMA_V2,
    AuditReplayResultWithSnapshot,
    ComplianceArtifact,
    ComplianceArtifactStore,
    ComplianceProofRequest,
    ComplianceReplayInput,
    ComplianceVerificationInput,
    InMemoryComplianceArtifactStore,
    ProofVerificationResult,
)
from arelis.compliance.types import (
    DisclosureRule as ComplianceDisclosureRule,
)
from arelis.compliance.verification import ComplianceVerifierOptions, verify_compliance_artifact
from arelis.config import ClientConfig
from arelis.core.approval_store import (
    ApprovalRequest,
    ApprovalResolveInput,
    ApprovalStatus,
    ApprovalStore,
    CreateApprovalRequest,
    create_in_memory_approval_store,
)
from arelis.core.errors import PolicyApprovalRequiredError, PolicyBlockedError
from arelis.core.result import create_result
from arelis.core.run_context import (
    ContextResolver,
    default_context_resolver,
    generate_run_id,
)
from arelis.core.types import (
    GovernanceContext,
    PolicySummary,
    ResultEnvelope,
    UsageInfo,
)
from arelis.data_sources.provider import DataSourceProvider
from arelis.data_sources.registry import DataSourceRegistry, create_data_source_registry
from arelis.data_sources.types import (
    DataSourceContext,
    DataSourceDescriptor,
    DataSourceQuery,
    DataSourceReadInput,
    DataSourceRegisterInput,
    DataSourceResult,
)
from arelis.evaluations.runner import run_evaluations
from arelis.evaluations.types import (
    EvaluationInput,
    EvaluationRunResult,
    Evaluator,
)
from arelis.extensions.config import ClientExtensionsConfig
from arelis.governance_gate.types import (
    GovernanceGateEvaluatePolicyInput,
    GovernanceGateEvaluator,
)
from arelis.knowledge.registry import KBRegistry, create_kb_registry
from arelis.knowledge.types import (
    KnowledgeBaseDescriptor,
    RegisterKBInput,
    RetrievalQuery,
    RetrievalResult,
    RetrieveInput,
)
from arelis.mcp.registry import MCPRegistry, create_mcp_registry
from arelis.mcp.types import (
    DiscoverMCPToolsInput,
    MCPServerDescriptor,
    MCPToolDiscoveryResult,
    RegisterMCPServerInput,
)
from arelis.memory.provider import MemoryProvider
from arelis.memory.registry import MemoryRegistry, create_memory_registry
from arelis.memory.types import (
    MemoryContext,
    MemoryDeleteInput,
    MemoryEntry,
    MemoryReadInput,
    MemoryScope,
    MemoryWriteInput,
)
from arelis.models.registry import ModelRegistry
from arelis.models.types import (
    GenerateInput,
    GenerateStreamInput,
    ModelRequest,
    ModelResponse,
    StreamChunk,
)
from arelis.policy.compiler import PolicyCompiler
from arelis.policy.engine import PolicyEngine
from arelis.policy.risk_router import RuntimeRiskInput, resolve_risk_route
from arelis.policy.types import (
    PolicyCheckpoint,
    PolicyDecision,
    PolicyInput,
    PolicyInputCompiled,
    PolicyInputData,
    PolicyResult,
    PolicyResultSummary,
)
from arelis.prompts.registry import TemplateRegistry, create_template_registry
from arelis.prompts.types import PromptTemplate, PromptTemplateInput, PromptTemplateQuery
from arelis.quotas.manager import QuotaManager
from arelis.quotas.types import QuotaDecision, QuotaKey, QuotaUsage
from arelis.secrets.resolver import SecretResolver, create_env_secret_resolver, resolve_secret_value
from arelis.secrets.types import SecretResolverContext
from arelis.tools.registry import ToolRegistry

__all__ = [
    "ArelisClient",
    "ClientAgentRunInput",
    "create_arelis_client",
    "createArelisClient",
]


# ---------------------------------------------------------------------------
# Client-level agent run input (differs from runtime AgentRunInput)
# ---------------------------------------------------------------------------

from dataclasses import dataclass


@dataclass
class ClientAgentRunInput:
    """Input for running an agent through the client.

    This is the client-level input type that wraps an ``AgentRuntime``
    instance together with initial input, optional limits, and governance
    context.  It maps to the TypeScript SDK's ``AgentRunInput`` from
    ``packages/sdk/src/client.ts``.

    Attributes:
        agent: The configured agent runtime to execute.
        input: Initial input for the agent.
        context: Governance context.
        limits: Optional limits override.
    """

    agent: AgentRuntime
    input: object
    context: GovernanceContext
    limits: AgentLimits | None = None


# ---------------------------------------------------------------------------
# Helper: build PolicySummary from a PolicyResult
# ---------------------------------------------------------------------------


def _to_policy_summary(result: PolicyResult) -> PolicySummary:
    """Convert a :class:`PolicyResult` to a :class:`PolicySummary`."""
    evaluated = len(result.decisions)
    allowed = sum(1 for d in result.decisions if d.effect == "allow")
    blocked = sum(1 for d in result.decisions if d.effect == "block")
    transformed = sum(1 for d in result.decisions if d.effect == "transform")

    reasons: list[str] = []
    for d in result.decisions:
        if d.effect != "allow" and d.reason is not None:
            reasons.append(d.reason)

    return PolicySummary(
        evaluated=evaluated,
        allowed=allowed,
        blocked=blocked,
        transformed=transformed,
        reasons=reasons if reasons else None,
    )


# ===========================================================================
# Namespace classes
# ===========================================================================


class _ModelsNamespace:
    """Namespace: ``client.models``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def generate(self, input: GenerateInput) -> ResultEnvelope[ModelResponse]:
        """Generate a response from a model with policy checks and audit logging.

        Resolves the model route, applies pre-prompt policy, invokes the
        provider, applies post-output policy, and wraps the result in a
        :class:`ResultEnvelope`.
        """
        c = self._client
        run_id = generate_run_id()
        context = await c._resolve_context(input.context)

        # 1. Capture Snapshot
        snapshot = await c._capture_snapshot(run_id, context)

        # 2. Risk Route
        await c._enforce_runtime_risk_route(
            run_id=run_id,
            context=context,
            operation="models.generate",
            policy_decisions=[],
        )

        # 3. Audit Start
        await c._audit_sink.write(
            create_run_started_event(
                run_id=run_id,
                context=context,
                operation="models.generate",
                snapshot_hash=snapshot.hash,
            )
        )

        try:
            # 2. Resolve Model
            resolution = c._model_registry.resolve_route_or_model(
                input.model,
                context,
                data_class=input.data_class,
                required_residency=input.required_residency,
            )
            descriptor = resolution.descriptor
            provider = c._model_registry.resolve_for_model(descriptor.id)

            await c._audit_sink.write(
                create_model_resolved_event(
                    run_id=run_id,
                    context=context,
                    model_id=descriptor.id,
                    route_id=input.model if resolution.route_id else None,
                )
            )

            # 3. Pre-prompt policy
            policy_result = await c._evaluate_policy(
                checkpoint="BeforePrompt",
                run_id=run_id,
                context=context,
                data={
                    "model_id": descriptor.id,
                    "provider": descriptor.provider_id,
                    "input": input.request.messages if input.request else None,
                },
            )

            await c._audit_sink.write(
                c._create_policy_evaluated_event_with_metadata(
                    run_id=run_id,
                    context=context,
                    checkpoint="BeforePrompt",
                    decisions=to_audit_decisions(policy_result.decisions),
                    allowed=policy_result.summary.allowed,
                )
            )

            if not policy_result.summary.allowed:
                raise await c._create_policy_error(policy_result, run_id, context)

            # 4. Prompt Template
            request = input.request
            if input.prompt_template is not None:
                template = c._prompt_registry.get(
                    PromptTemplateQuery(
                        id=input.prompt_template.id,
                        version=input.prompt_template.version,
                    )
                )
                if template is not None and request.system_prompt is None:
                    request = ModelRequest(
                        model=request.model,
                        messages=request.messages,
                        system_prompt=template.content,
                        config=request.config,
                        tools=request.tools,
                        context=request.context,
                        metadata=request.metadata,
                    )

            # 5. Invoke Model
            await c._audit_sink.write(
                create_model_request_event(
                    run_id=run_id,
                    context=context,
                    model_id=descriptor.id,
                    request=request,
                )
            )

            response = await provider.generate(request, input.options)

            await c._audit_sink.write(
                create_model_response_event(
                    run_id=run_id,
                    context=context,
                    model_id=descriptor.id,
                    response=response,
                )
            )

            # 6. Post-output policy
            post_policy_result = await c._evaluate_policy(
                checkpoint="AfterModelOutput",
                run_id=run_id,
                context=context,
                data={
                    "model_id": descriptor.id,
                    "input": input.request.messages if input.request else None,
                    "output": response.content if isinstance(response.content, str) else "",
                },
            )

            await c._audit_sink.write(
                c._create_policy_evaluated_event_with_metadata(
                    run_id=run_id,
                    context=context,
                    checkpoint="AfterModelOutput",
                    decisions=to_audit_decisions(post_policy_result.decisions),
                    allowed=post_policy_result.summary.allowed,
                )
            )

            if not post_policy_result.summary.allowed:
                raise await c._create_policy_error(post_policy_result, run_id, context)

            # 7. Evaluators
            evaluators = input.evaluators or c._evaluators
            if evaluators:
                eval_input = EvaluationInput(
                    run_id=run_id,
                    context=context,
                    surface="model",
                    output_ref=response.content if isinstance(response.content, str) else "",
                )
                eval_result = await run_evaluations(
                    evaluators,  # type: ignore[arg-type]
                    eval_input,
                    stop_on_block=True,
                )
                if eval_result.effect == "block":
                    from arelis.core.errors import EvaluationBlockedError

                    blocked_eval = next(
                        (r for r in eval_result.results if r.effect == "block"),
                        None,
                    )
                    evaluator_id = blocked_eval.evaluator_id if blocked_eval else "unknown"
                    reason = (
                        blocked_eval.findings[0].message
                        if blocked_eval and blocked_eval.findings
                        else "Evaluation blocked"
                    )
                    raise EvaluationBlockedError(
                        run_id=run_id,
                        evaluator_id=evaluator_id,
                        reason=reason,
                        context=context,
                    )

            # 8. End Audit
            usage = UsageInfo(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
                total_tokens=response.usage.total_tokens,
                cost_usd=response.usage.cost_usd,
            )

            await c._audit_sink.write(
                create_run_ended_event(
                    run_id=run_id,
                    context=context,
                    success=True,
                )
            )

            return create_result(
                run_id=run_id,
                output=response,
                usage=usage,
                policy=_to_policy_summary(post_policy_result),
            )

        except Exception as e:
            # Optionally audit error here
            raise e

    async def generate_stream(self, input: GenerateStreamInput) -> dict[str, object]:
        """Generate a streaming response from a model with policy checks and auditing.

        Resolves the model route, applies pre-prompt policy, and wraps the
        provider's stream in an audited iterator.
        """
        c = self._client
        run_id = generate_run_id()
        context = await c._resolve_context(input.context)

        # 1. Capture Snapshot
        snapshot = await c._capture_snapshot(run_id, context)

        # 2. Risk Route
        await c._enforce_runtime_risk_route(
            run_id=run_id,
            context=context,
            operation="models.generateStream",
            policy_decisions=[],
        )

        # 3. Audit Start
        await c._audit_sink.write(
            create_run_started_event(
                run_id=run_id,
                context=context,
                operation="models.generateStream",
                snapshot_hash=snapshot.hash,
            )
        )

        try:
            # 4. Resolve Model
            resolution = c._model_registry.resolve_route_or_model(
                input.model,
                context,
                data_class=input.data_class,
                required_residency=input.required_residency,
            )
            descriptor = resolution.descriptor
            provider = c._model_registry.resolve_for_model(descriptor.id)

            await c._audit_sink.write(
                create_model_resolved_event(
                    run_id=run_id,
                    context=context,
                    model_id=descriptor.id,
                    route_id=input.model if resolution.route_id else None,
                )
            )

            # 5. Pre-prompt policy
            policy_result = await c._evaluate_policy(
                checkpoint="BeforePrompt",
                run_id=run_id,
                context=context,
                data={
                    "model_id": descriptor.id,
                    "provider": descriptor.provider_id,
                    "input": input.request.messages if input.request else None,
                },
            )

            await c._audit_sink.write(
                c._create_policy_evaluated_event_with_metadata(
                    run_id=run_id,
                    context=context,
                    checkpoint="BeforePrompt",
                    decisions=to_audit_decisions(policy_result.decisions),
                    allowed=policy_result.summary.allowed,
                )
            )

            if not policy_result.summary.allowed:
                raise await c._create_policy_error(policy_result, run_id, context)

            # 6. Model Request event
            await c._audit_sink.write(
                create_model_request_event(
                    run_id=run_id,
                    context=context,
                    model_id=descriptor.id,
                    request=input.request,
                )
            )

            # 7. Invoke Model Stream
            raw_stream = provider.stream(input.request, input.options)

            # 8. Wrap stream
            stream = c._wrap_model_stream(
                raw_stream,
                run_id,
                context,
                descriptor.id,
            )

            return {"run_id": run_id, "stream": stream}

        except Exception as e:
            # TODO: Audit exception
            raise e


class _AgentsNamespace:
    """Namespace: ``client.agents``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def run(self, input: ClientAgentRunInput) -> AgentResult[object]:
        """Run an agent with limits and governance.

        Args:
            input: Agent run input containing the runtime, initial input,
                optional limits, and governance context.

        Returns:
            The agent result with steps, output, and usage information.
        """
        c = self._client
        run_id = generate_run_id()
        context = await c._resolve_context(input.context)

        # 1. Capture Snapshot
        snapshot = await c._capture_snapshot(run_id, context)

        # 2. Risk Route
        await c._enforce_runtime_risk_route(
            run_id=run_id,
            context=context,
            operation="agents.run",
            policy_decisions=[],
        )

        # 3. Audit Start
        await c._audit_sink.write(
            create_run_started_event(
                run_id=run_id,
                context=context,
                operation="agents.run",
                snapshot_hash=snapshot.hash,
            )
        )

        try:
            runtime_input = _RuntimeAgentRunInput(
                input=input.input,
                run_id=run_id,
                limits=input.limits,
            )

            result = await input.agent.run(runtime_input)

            # 4. Audit End
            await c._audit_sink.write(
                create_run_ended_event(
                    run_id=run_id,
                    context=context,
                    success=result.status == "completed",
                )
            )

            return result
        except Exception as e:
            # TODO: Audit exception
            raise e


class _MCPNamespace:
    """Namespace: ``client.mcp``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def register_server(
        self,
        input: RegisterMCPServerInput | None = None,
        *,
        server: MCPServerDescriptor | None = None,
        context: GovernanceContext | None = None,
    ) -> None:
        """Register an MCP server with governance checks.

        Accepts either a :class:`RegisterMCPServerInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with server and context fields.
            server: The MCP server descriptor to register (keyword fallback).
            context: Optional governance context (keyword fallback).
        """
        if input is not None:
            server = input.server
            context = input.context
        if server is None:
            raise ValueError("server is required")
        c = self._client
        await c._resolve_context(context)
        c._mcp_registry.register_server(server)

    async def discover_tools(
        self,
        input: DiscoverMCPToolsInput | None = None,
        *,
        server_id: str | None = None,
        context: GovernanceContext | None = None,
    ) -> MCPToolDiscoveryResult:
        """Discover tools from a registered MCP server.

        Accepts either a :class:`DiscoverMCPToolsInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with server_id and context fields.
            server_id: ID of the registered MCP server (keyword fallback).
            context: Optional governance context (keyword fallback).

        Returns:
            The tool discovery result.
        """
        if input is not None:
            server_id = input.server_id
            context = input.context
        if server_id is None:
            raise ValueError("server_id is required")
        c = self._client
        await c._resolve_context(context)
        registered = c._mcp_registry.get_server(server_id)
        if registered is None:
            raise ValueError(f'MCP server "{server_id}" not found')

        if registered.transport is None:
            raise ValueError(f'MCP server "{server_id}" has no connected transport')

        tools = await registered.transport.list_tools()
        from datetime import datetime, timezone

        from arelis.mcp.types import MCPToolDiscoveryResult, MCPToolSchema

        tool_schemas: list[MCPToolSchema] = []
        for tool in tools:
            tool_schemas.append(
                MCPToolSchema(
                    name=tool.name if hasattr(tool, "name") else str(tool),
                    description=getattr(tool, "description", None),
                    input_schema=getattr(tool, "input_schema", None),
                )
            )

        return MCPToolDiscoveryResult(
            server_id=server_id,
            tools=tool_schemas,
            discovered_at=datetime.now(timezone.utc).isoformat(),
        )

    def get_registry(self) -> MCPRegistry:
        """Get the MCP registry instance."""
        return self._client._mcp_registry


class _KnowledgeNamespace:
    """Namespace: ``client.knowledge``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def register_kb(
        self,
        input: RegisterKBInput | None = None,
        *,
        kb: KnowledgeBaseDescriptor | None = None,
        context: GovernanceContext | None = None,
    ) -> None:
        """Register a knowledge base with governance checks.

        Accepts either a :class:`RegisterKBInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with kb and context fields.
            kb: Knowledge base descriptor (keyword fallback).
            context: Optional governance context (keyword fallback).
        """
        if input is not None:
            kb = input.kb
            context = input.context
        if kb is None:
            raise ValueError("kb is required")
        c = self._client
        _resolved = await c._resolve_context(context)
        c._kb_registry.register_kb(kb)

    async def retrieve(
        self,
        input: RetrieveInput | None = None,
        *,
        kb_id: str | None = None,
        query: RetrievalQuery | None = None,
        context: GovernanceContext | None = None,
    ) -> RetrievalResult:
        """Retrieve chunks from a knowledge base.

        Accepts either a :class:`RetrieveInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with kb_id, query, and context fields.
            kb_id: ID of the registered knowledge base (keyword fallback).
            query: Retrieval query parameters (keyword fallback).
            context: Optional governance context (keyword fallback).

        Returns:
            The retrieval result with chunks.
        """
        if input is not None:
            kb_id = input.kb_id
            query = input.query
            context = input.context
        if kb_id is None:
            raise ValueError("kb_id is required")
        if query is None:
            raise ValueError("query is required")
        c = self._client
        await c._resolve_context(context)

        registered = c._kb_registry.get_kb(kb_id)
        if registered is None:
            raise ValueError(f'Knowledge base "{kb_id}" not found')

        provider = registered.provider
        if provider is None:
            raise ValueError(f'Knowledge base "{kb_id}" has no connected provider')

        from datetime import datetime, timezone

        run_id = generate_run_id()
        chunks = await provider.retrieve(query)
        return RetrievalResult(
            chunks=chunks,
            query_id=run_id,
            kb_id=kb_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            total_found=len(chunks),
        )

    def get_registry(self) -> KBRegistry:
        """Get the knowledge base registry instance."""
        return self._client._kb_registry


class _PromptsNamespace:
    """Namespace: ``client.prompts``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def register(
        self,
        input: PromptTemplateInput,
        context: GovernanceContext | None = None,
    ) -> PromptTemplate:
        """Register a prompt template.

        Args:
            input: Prompt template input with id, version, and content.
            context: Optional governance context.

        Returns:
            The registered prompt template.
        """
        _resolved = await self._client._resolve_context(context)
        return self._client._prompt_registry.register(input)

    def get(self, query: PromptTemplateQuery) -> PromptTemplate | None:
        """Get a prompt template by query.

        Args:
            query: Query with id and optional version.

        Returns:
            The prompt template, or ``None`` if not found.
        """
        return self._client._prompt_registry.get(query)

    def list(self, id: str | None = None) -> list[PromptTemplate]:
        """List prompt templates.

        Args:
            id: Optional template ID to filter by.

        Returns:
            List of prompt templates.
        """
        return self._client._prompt_registry.list(id)


class _MemoryNamespace:
    """Namespace: ``client.memory``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    def _get_provider(self, provider_id: str | None = None) -> MemoryProvider:
        """Resolve a memory provider by ID or return the first registered one."""
        registry = self._client._memory_registry
        if provider_id is not None:
            provider = registry.get(provider_id)
            if provider is None:
                raise ValueError(f'Memory provider "{provider_id}" not found')
            return provider

        providers = registry.list()
        if not providers:
            raise ValueError("No memory providers registered")
        return providers[0]

    async def read(
        self,
        input: MemoryReadInput | None = None,
        *,
        scope: MemoryScope | None = None,
        key: str | None = None,
        context: GovernanceContext | None = None,
        provider_id: str | None = None,
    ) -> MemoryEntry | None:
        """Read a memory entry.

        Accepts either a :class:`MemoryReadInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with scope, key, context, provider_id.
            scope: Memory scope (keyword fallback).
            key: Entry key (keyword fallback).
            context: Optional governance context (keyword fallback).
            provider_id: Optional provider ID (keyword fallback).

        Returns:
            The memory entry, or ``None`` if not found.
        """
        if input is not None:
            scope = input.scope
            key = input.key
            context = input.context
            provider_id = input.provider_id
        if scope is None:
            raise ValueError("scope is required")
        if key is None:
            raise ValueError("key is required")
        resolved = await self._client._resolve_context(context)
        provider = self._get_provider(provider_id)
        mem_ctx = MemoryContext(run_id=generate_run_id(), governance=resolved)
        return await provider.read(scope, key, mem_ctx)

    async def write(
        self,
        input: MemoryWriteInput | None = None,
        *,
        scope: MemoryScope | None = None,
        key: str | None = None,
        value: object | None = None,
        context: GovernanceContext | None = None,
        provider_id: str | None = None,
        metadata: dict[str, object] | None = None,
    ) -> MemoryEntry:
        """Write a memory entry.

        Accepts either a :class:`MemoryWriteInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with scope, key, value, context, provider_id, metadata.
            scope: Memory scope (keyword fallback).
            key: Entry key (keyword fallback).
            value: Entry value (keyword fallback).
            context: Optional governance context (keyword fallback).
            provider_id: Optional provider ID (keyword fallback).
            metadata: Optional metadata (keyword fallback).

        Returns:
            The written memory entry.
        """
        if input is not None:
            scope = input.scope
            key = input.key
            value = input.value
            context = input.context
            provider_id = input.provider_id
            metadata = input.metadata
        if scope is None:
            raise ValueError("scope is required")
        if key is None:
            raise ValueError("key is required")
        if value is None:
            raise ValueError("value is required")
        resolved = await self._client._resolve_context(context)
        provider = self._get_provider(provider_id)
        mem_ctx = MemoryContext(run_id=generate_run_id(), governance=resolved)
        return await provider.write(scope, key, value, mem_ctx, metadata)

    async def delete(
        self,
        input: MemoryDeleteInput | None = None,
        *,
        scope: MemoryScope | None = None,
        key: str | None = None,
        context: GovernanceContext | None = None,
        provider_id: str | None = None,
    ) -> bool:
        """Delete a memory entry.

        Accepts either a :class:`MemoryDeleteInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with scope, key, context, provider_id.
            scope: Memory scope (keyword fallback).
            key: Entry key (keyword fallback).
            context: Optional governance context (keyword fallback).
            provider_id: Optional provider ID (keyword fallback).

        Returns:
            ``True`` if the entry was deleted.
        """
        if input is not None:
            scope = input.scope
            key = input.key
            context = input.context
            provider_id = input.provider_id
        if scope is None:
            raise ValueError("scope is required")
        if key is None:
            raise ValueError("key is required")
        resolved = await self._client._resolve_context(context)
        provider = self._get_provider(provider_id)
        mem_ctx = MemoryContext(run_id=generate_run_id(), governance=resolved)
        return await provider.delete(scope, key, mem_ctx)

    async def list(
        self,
        scope: MemoryScope,
        context: GovernanceContext | None = None,
        provider_id: str | None = None,
    ) -> list[MemoryEntry]:
        """List memory entries for a scope.

        Args:
            scope: Memory scope.
            context: Optional governance context.
            provider_id: Optional provider ID.

        Returns:
            List of memory entries.
        """
        resolved = await self._client._resolve_context(context)
        provider = self._get_provider(provider_id)
        mem_ctx = MemoryContext(run_id=generate_run_id(), governance=resolved)
        return await provider.list(scope, mem_ctx)


class _DataSourcesNamespace:
    """Namespace: ``client.data_sources``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def register(
        self,
        input: DataSourceRegisterInput | None = None,
        *,
        descriptor: DataSourceDescriptor | None = None,
        provider: DataSourceProvider | None = None,
        context: GovernanceContext | None = None,
    ) -> None:
        """Register a data source.

        Accepts either a :class:`DataSourceRegisterInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with descriptor, provider, and context.
            descriptor: Data source descriptor (keyword fallback).
            provider: Data source provider (keyword fallback).
            context: Optional governance context (keyword fallback).
        """
        if input is not None:
            descriptor = input.descriptor
            provider = input.provider  # type: ignore[assignment]
            context = input.context
        if descriptor is None:
            raise ValueError("descriptor is required")
        if provider is None:
            raise ValueError("provider is required")
        _resolved = await self._client._resolve_context(context)
        self._client._data_source_registry.register(descriptor, provider)

    async def read(
        self,
        input: DataSourceReadInput | None = None,
        *,
        source_id: str | None = None,
        query: str | None = None,
        context: GovernanceContext | None = None,
        metadata: dict[str, object] | None = None,
    ) -> DataSourceResult:
        """Read from a data source.

        Accepts either a :class:`DataSourceReadInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with source_id, query, context, metadata.
            source_id: ID of the registered data source (keyword fallback).
            query: Query string (keyword fallback).
            context: Optional governance context (keyword fallback).
            metadata: Optional metadata (keyword fallback).

        Returns:
            The data source result.
        """
        if input is not None:
            source_id = input.source_id
            query = input.query
            context = input.context
            metadata = input.metadata
        if source_id is None:
            raise ValueError("source_id is required")
        if query is None:
            raise ValueError("query is required")
        c = self._client
        resolved = await c._resolve_context(context)
        registered = c._data_source_registry.get(source_id)
        if registered is None:
            raise ValueError(f'Data source "{source_id}" not found')

        ds_context = DataSourceContext(run_id=generate_run_id(), governance=resolved)
        ds_query = DataSourceQuery(
            source_id=source_id,
            query=query,
            metadata=metadata,
        )
        return await registered.provider.read(ds_query, ds_context)

    def get_registry(self) -> DataSourceRegistry:
        """Get the data source registry instance."""
        return self._client._data_source_registry


class _ApprovalsNamespace:
    """Namespace: ``client.approvals``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def approve(
        self,
        input: ApprovalResolveInput | None = None,
        *,
        approval_id: str | None = None,
        resolved_by: str | None = None,
        reason: str | None = None,
        context: GovernanceContext | None = None,
    ) -> None:
        """Approve a pending approval request.

        Accepts either an :class:`ApprovalResolveInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with approval_id, resolved_by, reason, context.
            approval_id: ID of the approval request (keyword fallback).
            resolved_by: Identifier of the approver (keyword fallback).
            reason: Optional reason for approval (keyword fallback).
            context: Optional governance context (keyword fallback).
        """
        if input is not None:
            approval_id = input.approval_id
            resolved_by = input.resolved_by
            reason = input.reason
            context = input.context
        if approval_id is None:
            raise ValueError("approval_id is required")
        if resolved_by is None:
            raise ValueError("resolved_by is required")
        _resolved = await self._client._resolve_context(context)
        await self._client._approval_store.approve(approval_id, resolved_by, reason)

    async def reject(
        self,
        input: ApprovalResolveInput | None = None,
        *,
        approval_id: str | None = None,
        resolved_by: str | None = None,
        reason: str | None = None,
        context: GovernanceContext | None = None,
    ) -> None:
        """Reject a pending approval request.

        Accepts either an :class:`ApprovalResolveInput` object or keyword
        arguments for backward compatibility.

        Args:
            input: Input object with approval_id, resolved_by, reason, context.
            approval_id: ID of the approval request (keyword fallback).
            resolved_by: Identifier of the rejector (keyword fallback).
            reason: Optional reason for rejection (keyword fallback).
            context: Optional governance context (keyword fallback).
        """
        if input is not None:
            approval_id = input.approval_id
            resolved_by = input.resolved_by
            reason = input.reason
            context = input.context
        if approval_id is None:
            raise ValueError("approval_id is required")
        if resolved_by is None:
            raise ValueError("resolved_by is required")
        _resolved = await self._client._resolve_context(context)
        await self._client._approval_store.reject(approval_id, resolved_by, reason)

    async def list(self, status: ApprovalStatus | None = None) -> list[ApprovalRequest]:
        """List approval requests.

        Args:
            status: Optional filter by status.

        Returns:
            List of approval requests.
        """
        return await self._client._approval_store.list(status)

    async def get(self, approval_id: str) -> ApprovalRequest | None:
        """Get an approval request by ID.

        Args:
            approval_id: The approval request ID.

        Returns:
            The approval request, or ``None`` if not found.
        """
        return await self._client._approval_store.get(approval_id)


class _EvaluationsNamespace:
    """Namespace: ``client.evaluations``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def run(
        self,
        input: EvaluationInput,
        evaluators: list[Evaluator] | None = None,
    ) -> EvaluationRunResult:
        """Run evaluations against the given input.

        Args:
            input: Evaluation input containing run context and output reference.
            evaluators: Optional evaluator list (defaults to client evaluators).

        Returns:
            The aggregated evaluation run result.
        """
        evals = evaluators or self._client._evaluators
        if not evals:
            return EvaluationRunResult()
        return await run_evaluations(evals, input, stop_on_block=True)


class _QuotasNamespace:
    """Namespace: ``client.quotas``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def check(self, key: QuotaKey, proposed: QuotaUsage) -> QuotaDecision:
        """Check whether proposed usage is within quota.

        Args:
            key: Quota key identifying the scope.
            proposed: Proposed usage to check.

        Returns:
            The quota decision.

        Raises:
            ValueError: If no quota manager is configured.
        """
        if self._client._quota_manager is None:
            raise ValueError("Quota manager not configured")
        return await self._client._quota_manager.check(key, proposed)

    async def commit(self, key: QuotaKey, actual: QuotaUsage) -> None:
        """Record actual usage against a quota key.

        Args:
            key: Quota key identifying the scope.
            actual: Actual usage to commit.

        Raises:
            ValueError: If no quota manager is configured.
        """
        if self._client._quota_manager is None:
            raise ValueError("Quota manager not configured")
        await self._client._quota_manager.commit(key, actual)


class _SecretsNamespace:
    """Namespace: ``client.secrets``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def resolve(
        self,
        ref: str,
        context: GovernanceContext | None = None,
    ) -> str:
        """Resolve a secret by reference.

        Args:
            ref: Secret reference string.
            context: Optional governance context.

        Returns:
            The resolved secret value.
        """
        c = self._client
        run_id = generate_run_id()
        resolved_ctx = await c._resolve_context(context) if context else None
        resolver_ctx = SecretResolverContext(
            context=resolved_ctx,
            run_id=run_id,
        )
        result = await resolve_secret_value(c._secret_resolver, ref, resolver_ctx)
        return result.value


class _ComplianceNamespace:
    """Namespace: ``client.compliance``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    # -- request_artifact ------------------------------------------------------

    async def request_artifact(
        self,
        input: ComplianceProofRequest,
    ) -> ComplianceArtifact | ProofJob:
        """Request generation of a compliance artifact.

        Implements the full proof generation flow ported from the TypeScript
        SDK's ``requestComplianceArtifact`` method in ``client.ts``.

        Flow:
        1. Retrieve the causal graph for the run from the graph store.
        2. Resolve disclosure rules (from input, client config, or compiled policy).
        3. Create a causal graph commitment (optionally signed).
        4. Determine if composed proofs are enabled (via input or extension config).
        5. If ``input.async_`` is ``True`` and a proof job queue is configured,
           submit an async proof job and return the :class:`ProofJob`.
        6. Otherwise, generate the proof synchronously (with optional timeout),
           construct the :class:`ComplianceArtifact`, save it to the artifact
           store, and return it.

        Args:
            input: The compliance proof request with run_id and options.

        Returns:
            A :class:`ComplianceArtifact` or :class:`ProofJob` (when async).

        Raises:
            ValueError: If the compliance graph store is not configured or
                no causal graph is found for the given run ID.
        """
        import asyncio
        import time as _time

        c = self._client

        # 1. Validate graph store is configured
        if c._compliance_graph_store is None:
            raise ValueError("Compliance graph store not configured")

        # 2. Retrieve causal graph
        graph = await c._compliance_graph_store.get(input.run_id)
        if graph is None:
            raise ValueError(f"No causal graph found for run {input.run_id}")

        # 3. Resolve disclosure rules
        from arelis.audit.proof import DisclosureRule as _DisclosureRule

        base_rules_raw = (
            input.disclosure_rules
            if input.disclosure_rules is not None
            else (c._compliance_disclosure_rules or [])
        )
        typed_base_rules: list[_DisclosureRule] = [
            rule for rule in base_rules_raw if isinstance(rule, _DisclosureRule)
        ]

        disclosure_rules = resolve_disclosure_rules(
            typed_base_rules,
            input.disclosure_rule_ids,
        )

        # 4. Extract policy snapshot hash
        policy_snapshot_hash = _extract_policy_snapshot_hash_from_graph(graph)
        if policy_snapshot_hash is None and c._compiled_policy is not None:
            snapshot = getattr(c._compiled_policy, "snapshot", None)
            if snapshot is not None:
                policy_snapshot_hash = getattr(snapshot, "hash", None)

        # 5. Create causal graph commitment
        commitment = create_causal_graph_commitment(graph, c._compliance_signer)

        # 6. Determine if composed proofs are enabled
        composed_enabled = input.composed is not None or _is_composed_proof_capability_enabled(c)

        composed_input: ProofComposedOptions | None = None
        if composed_enabled:
            include_narrowing = (
                input.composed.include_narrowing_proof if input.composed is not None else True
            )
            include_lineage = (
                input.composed.include_lineage_proof if input.composed is not None else True
            )
            enable_zk = False
            if input.composed is not None:
                enable_zk = input.composed.enable_zk
            elif (
                c._extensions is not None
                and c._extensions.composed_proofs is not None
                and c._extensions.composed_proofs.enable_zk_mode is not None
            ):
                enable_zk = c._extensions.composed_proofs.enable_zk_mode

            composed_input = ProofComposedOptions(
                layers=_build_composed_proof_layers(graph),
                include_narrowing_proof=include_narrowing,
                include_lineage_proof=include_lineage,
                enable_zk=enable_zk,
            )

        # 7. Build proof input
        proof_input = ProofInput(
            graph=graph,
            commitment=commitment,
            disclosure_rules=disclosure_rules,
            policy_snapshot_hash=policy_snapshot_hash,
            composed=composed_input,
        )

        # 8. Get proof provider
        provider = c._compliance_proof_provider or HashProofProvider()

        # 9. Cache key
        rule_key = "|".join(sorted(rule.id for rule in disclosure_rules))
        composed_label = "composed" if composed_enabled else "legacy"
        cache_key = f"{input.run_id}:{rule_key}:{composed_label}"

        # 10. Async mode: submit job and return ProofJob
        if input.async_ and c._compliance_proof_job_queue is not None:
            return c._compliance_proof_job_queue.submit(proof_input, provider)

        # 11. Synchronous proof generation (with optional timeout and cache)
        proof = c._compliance_proof_cache.get(cache_key)
        if proof is None:
            timeout_ms = c._compliance_proof_timeout_ms
            if timeout_ms is not None and timeout_ms > 0:
                try:
                    proof = await asyncio.wait_for(
                        provider.create_proof(proof_input),
                        timeout=timeout_ms / 1000.0,
                    )
                except asyncio.TimeoutError:
                    raise ValueError("Compliance proof generation timed out") from None
            else:
                proof = await provider.create_proof(proof_input)
            c._compliance_proof_cache[cache_key] = proof

        # 12. Determine artifact schema
        artifact_schema = (
            COMPLIANCE_ARTIFACT_SCHEMA_V2
            if proof.schema_version == COMPLIANCE_PROOF_SCHEMA_V2
            else COMPLIANCE_ARTIFACT_SCHEMA_V1
        )

        # 13. Build artifact
        artifact = ComplianceArtifact(
            id=f"artifact_{input.run_id}_{int(_time.time() * 1000)}",
            run_id=input.run_id,
            created_at=_iso_now(),
            artifact_schema=artifact_schema,
            context=_extract_audit_context_from_graph(graph),
            policy_snapshot_hash=policy_snapshot_hash,
            commitment=commitment,  # type: ignore[arg-type]
            proof=proof,  # type: ignore[arg-type]
            disclosure_rule_ids=[rule.id for rule in disclosure_rules],
        )

        # 14. Save to artifact store
        if c._compliance_artifact_store is not None:
            await c._compliance_artifact_store.save(artifact)

        return artifact

    # -- get_artifacts ---------------------------------------------------------

    async def get_artifacts(self, run_id: str) -> list[ComplianceArtifact]:
        """Get all compliance artifacts for a run.

        Args:
            run_id: The run ID.

        Returns:
            List of compliance artifacts.
        """
        c = self._client
        if c._compliance_artifact_store is None:
            return []
        return await c._compliance_artifact_store.list(run_id)

    # -- verify_artifact -------------------------------------------------------

    async def verify_artifact(self, input: ComplianceVerificationInput) -> ProofVerificationResult:
        """Verify a compliance artifact.

        Args:
            input: Verification input with artifact and optional rules.

        Returns:
            The proof verification result.
        """
        options = ComplianceVerifierOptions(
            disclosure_rules=input.disclosure_rules,
            policy_snapshot_hash=input.policy_snapshot_hash,
        )
        return await verify_compliance_artifact(input.artifact, options)

    # -- replay_run ------------------------------------------------------------

    async def replay_run(self, input: ComplianceReplayInput) -> AuditReplayResultWithSnapshot:
        """Replay a compliance run from the causal graph.

        Implements causal graph replay ported from the TypeScript SDK's
        ``replayComplianceRun`` method in ``client.ts``.

        Flow:
        1. Retrieve the causal graph for the run from the graph store.
        2. Extract events from graph nodes, sort by time.
        3. Reconstruct steps from events.
        4. Compute drift diagnostics between recorded and replay snapshots.
        5. Return :class:`AuditReplayResultWithSnapshot`.

        Args:
            input: Replay input with run_id and optional snapshot.

        Returns:
            The replay result with steps and drift diagnostics.

        Raises:
            ValueError: If the compliance graph store is not configured or
                no causal graph is found for the given run ID.
        """
        c = self._client

        if c._compliance_graph_store is None:
            raise ValueError("Compliance graph store not configured")

        graph = await c._compliance_graph_store.get(input.run_id)
        if graph is None:
            raise ValueError(f"No causal graph found for run {input.run_id}")

        recorded_snapshot = c._run_snapshots.get(input.run_id)

        return await replay_causal_graph(
            graph=graph,
            recorded_snapshot=recorded_snapshot,  # type: ignore[arg-type]
            replay_snapshot=input.replay_snapshot,
        )


# ---------------------------------------------------------------------------
# Compliance helper functions (module-level, used by _ComplianceNamespace)
# ---------------------------------------------------------------------------


def _iso_now() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def _extract_audit_context_from_graph(
    graph: cag.CausalGraph,
) -> dict[str, object] | None:
    """Extract audit context from the first event node in the graph."""
    for node in graph.nodes:
        if node.kind == "event" and node.event is not None:
            context = getattr(node.event, "context", None)
            if context is not None:
                if isinstance(context, dict):
                    return context
                # Convert dataclass-like context to dict
                return (
                    {k: v for k, v in vars(context).items() if not k.startswith("_")}
                    if hasattr(context, "__dict__")
                    else None
                )
    return None


def _extract_policy_snapshot_hash_from_graph(
    graph: cag.CausalGraph,
) -> str | None:
    """Extract policy snapshot hash from a policy.evaluated event in the graph."""
    for node in graph.nodes:
        if (
            node.kind == "event"
            and node.event is not None
            and node.event_type == "policy.evaluated"
        ):
            return getattr(node.event, "policy_snapshot_hash", None)
    return None


def _is_composed_proof_capability_enabled(client: ArelisClient) -> bool:
    """Check if composed proof capability is enabled via extensions."""
    ext = client._extensions
    if ext is None:
        return False

    # Check capabilities dict
    if ext.capabilities is not None:
        cap = ext.capabilities.get("multiLayerComposedComplianceProofs")
        if cap is not None and getattr(cap, "enabled", False):
            return True

    # Check composed_proofs profile
    return ext.composed_proofs is not None and ext.composed_proofs.profile == "hash_and_zk"


def _build_composed_proof_layers(
    graph: cag.CausalGraph,
) -> list[dict[str, object]]:
    """Build composed proof layers from a causal graph.

    Groups event nodes by type prefix into compliance layers, matching the
    TypeScript SDK's ``buildComposedProofLayers`` method.
    """
    event_nodes = [
        node for node in graph.nodes if node.kind == "event" and node.event_type is not None
    ]

    def ids_by_prefix(prefixes: list[str]) -> list[str]:
        return [
            node.id
            for node in event_nodes
            if any(
                node.event_type is not None and node.event_type.startswith(prefix)
                for prefix in prefixes
            )
        ]

    layers: list[dict[str, object]] = [
        {"layer": "infra", "payload": ids_by_prefix(["infra.", "resource."])},
        {"layer": "config", "payload": ids_by_prefix(["config.change."])},
        {"layer": "auth", "payload": ids_by_prefix(["auth."])},
        {"layer": "inference", "payload": ids_by_prefix(["model.", "output.validation."])},
        {"layer": "agent", "payload": ids_by_prefix(["agent."])},
        {"layer": "tools", "payload": ids_by_prefix(["tool.", "mcp.tools."])},
    ]

    return layers


class _GovernanceNamespace:
    """Namespace: ``client.governance``."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    def create_gate_evaluator(self) -> GovernanceGateEvaluator:
        """Create a governance gate evaluator backed by this client.

        Returns:
            A governance gate evaluator with access to the client's
            context resolver and policy engine.
        """
        return _ClientGovernanceGateEvaluator(self._client)  # type: ignore[return-value]


class _ClientGovernanceGateEvaluator:
    """GovernanceGateEvaluator implementation backed by ArelisClient internals."""

    def __init__(self, client: ArelisClient) -> None:
        self._client = client

    async def resolve_context(self, partial: GovernanceContext | None = None) -> GovernanceContext:
        """Resolve a (possibly partial) governance context."""
        return await self._client._resolve_context(partial)

    async def evaluate_policy(self, input: GovernanceGateEvaluatePolicyInput) -> PolicyResult:
        """Evaluate policy for the given input."""
        c = self._client
        policy_input = PolicyInput(
            checkpoint=input.checkpoint,
            context=input.context,
            run_id=input.run_id,
            data=PolicyInputData(
                model_id=input.data.model_id,
                provider=input.data.provider,
                input=input.data.input,
                output=input.data.output,
                tool_name=input.data.tool_name,
            ),
        )
        return await c._policy_engine.evaluate(policy_input)

    def get_policy_metadata(self) -> dict[str, str | None] | None:
        """Get policy metadata (snapshot hash, compiler ID)."""
        return None


# ===========================================================================
# ArelisClient
# ===========================================================================


class ArelisClient:
    """Unified entry point for the AI Governance SDK with 13 namespaced APIs.

    Each namespace is an attribute providing a group of related methods:

    * ``client.models`` -- model generation
    * ``client.agents`` -- agent execution
    * ``client.mcp`` -- MCP server management
    * ``client.knowledge`` -- knowledge base operations
    * ``client.prompts`` -- prompt template registry
    * ``client.memory`` -- memory read/write/delete
    * ``client.data_sources`` -- data source management
    * ``client.approvals`` -- approval workflows
    * ``client.evaluations`` -- evaluator orchestration
    * ``client.quotas`` -- quota management
    * ``client.secrets`` -- secret resolution
    * ``client.compliance`` -- compliance artifacts and replay
    * ``client.governance`` -- governance gate evaluators

    Example::

        config = ClientConfig(
            model_registry=registry,
            policy_engine=engine,
            audit_sink=sink,
        )
        client = ArelisClient(config)
        result = await client.models.generate(input)
    """

    def __init__(self, config: ClientConfig) -> None:
        # -- required components -----------------------------------------------
        self._model_registry: ModelRegistry = config.model_registry
        self._policy_engine: PolicyEngine = config.policy_engine
        self._audit_sink: AuditSink = config.audit_sink

        # -- context resolution ------------------------------------------------
        self._context_resolver: ContextResolver = (
            config.context_resolver
            if config.context_resolver is not None
            else default_context_resolver
        )
        self._default_context: GovernanceContext | None = config.default_context

        # -- optional registries -----------------------------------------------
        self._tool_registry: ToolRegistry | None = config.tool_registry

        self._mcp_registry: MCPRegistry = (
            config.mcp_registry if config.mcp_registry is not None else create_mcp_registry()
        )

        self._kb_registry: KBRegistry = (
            config.kb_registry if config.kb_registry is not None else create_kb_registry()
        )

        self._prompt_registry: TemplateRegistry = (
            config.prompt_registry
            if config.prompt_registry is not None
            else create_template_registry()
        )

        self._memory_registry: MemoryRegistry = (
            config.memory_registry
            if config.memory_registry is not None
            else create_memory_registry()
        )

        self._data_source_registry: DataSourceRegistry = (
            config.data_source_registry
            if config.data_source_registry is not None
            else create_data_source_registry()
        )

        # -- optional managers / evaluators ------------------------------------
        self._quota_manager: QuotaManager | None = config.quota_manager
        self._evaluators: list[Evaluator] = (
            list(config.evaluators) if config.evaluators is not None else []
        )

        self._approval_store: ApprovalStore = (
            config.approval_store  # type: ignore[assignment]
            if config.approval_store is not None
            else create_in_memory_approval_store()
        )

        self._secret_resolver: SecretResolver = (
            config.secret_resolver
            if config.secret_resolver is not None
            else create_env_secret_resolver()
        )

        self._redactor = config.redactor

        # -- compliance --------------------------------------------------------
        compliance = config.compliance
        self._compliance_graph_store: CausalGraphStore | None = (
            compliance.causal_graph_store  # type: ignore[assignment]
            if compliance is not None and compliance.causal_graph_store is not None
            else None
        )
        self._compliance_artifact_store: ComplianceArtifactStore | None = (
            compliance.artifact_store
            if compliance is not None and compliance.artifact_store is not None
            else (InMemoryComplianceArtifactStore() if compliance is not None else None)
        )
        self._compliance_proof_provider: ProofProvider | None = (
            compliance.proof_provider  # type: ignore[assignment]
            if compliance is not None and compliance.proof_provider is not None
            else (HashProofProvider() if compliance is not None else None)
        )
        self._compliance_proof_job_queue: ProofJobQueue | None = (
            compliance.proof_job_queue  # type: ignore[assignment]
            if compliance is not None and compliance.proof_job_queue is not None
            else None
        )
        self._compliance_disclosure_rules: list[ComplianceDisclosureRule] | None = (
            compliance.disclosure_rules
            if compliance is not None and compliance.disclosure_rules is not None
            else None
        )
        self._compliance_signer: Signer | None = (
            compliance.commitment_signer  # type: ignore[assignment]
            if compliance is not None and compliance.commitment_signer is not None
            else None
        )
        self._compliance_proof_timeout_ms: int | None = (
            compliance.proof_timeout_ms if compliance is not None else None
        )
        self._compliance_proof_cache: dict[str, DisclosureProof] = {}

        # -- extensions --------------------------------------------------------
        self._extensions: ClientExtensionsConfig | None = config.extensions

        # -- telemetry ---------------------------------------------------------
        self._telemetry = config.telemetry

        # -- policy compilation ------------------------------------------------
        self._compiled_policy = None
        if config.policy_compilation:
            compiler: PolicyCompiler = config.policy_compilation.compiler  # type: ignore[assignment]
            self._compiled_policy = compiler.compile(
                config.policy_compilation.source  # type: ignore[arg-type]
            )

        # -- build namespace objects -------------------------------------------
        self._models = _ModelsNamespace(self)
        self._agents = _AgentsNamespace(self)
        self._mcp = _MCPNamespace(self)
        self._knowledge = _KnowledgeNamespace(self)
        self._prompts = _PromptsNamespace(self)
        self._memory = _MemoryNamespace(self)
        self._data_sources = _DataSourcesNamespace(self)
        self._approvals = _ApprovalsNamespace(self)
        self._evaluations = _EvaluationsNamespace(self)
        self._quotas = _QuotasNamespace(self)
        self._secrets = _SecretsNamespace(self)
        self._compliance = _ComplianceNamespace(self)
        self._governance = _GovernanceNamespace(self)

        # -- run state ---------------------------------------------------------
        self._run_snapshots: dict[str, SnapshotBundle] = {}

    # -- namespace properties --------------------------------------------------

    @property
    def models(self) -> _ModelsNamespace:
        """Models namespace: ``generate()``, ``generate_stream()``."""
        return self._models

    @property
    def agents(self) -> _AgentsNamespace:
        """Agents namespace: ``run()``."""
        return self._agents

    @property
    def mcp(self) -> _MCPNamespace:
        """MCP namespace: ``register_server()``, ``discover_tools()``, ``get_registry()``."""
        return self._mcp

    @property
    def knowledge(self) -> _KnowledgeNamespace:
        """Knowledge namespace: ``register_kb()``, ``retrieve()``, ``get_registry()``."""
        return self._knowledge

    @property
    def prompts(self) -> _PromptsNamespace:
        """Prompts namespace: ``register()``, ``get()``, ``list()``."""
        return self._prompts

    @property
    def memory(self) -> _MemoryNamespace:
        """Memory namespace: ``read()``, ``write()``, ``delete()``, ``list()``."""
        return self._memory

    @property
    def data_sources(self) -> _DataSourcesNamespace:
        """Data sources namespace: ``register()``, ``read()``, ``get_registry()``."""
        return self._data_sources

    @property
    def approvals(self) -> _ApprovalsNamespace:
        """Approvals namespace: ``approve()``, ``reject()``, ``list()``, ``get()``."""
        return self._approvals

    @property
    def evaluations(self) -> _EvaluationsNamespace:
        """Evaluations namespace: ``run()``."""
        return self._evaluations

    @property
    def quotas(self) -> _QuotasNamespace:
        """Quotas namespace: ``check()``, ``commit()``."""
        return self._quotas

    @property
    def secrets(self) -> _SecretsNamespace:
        """Secrets namespace: ``resolve()``."""
        return self._secrets

    @property
    def compliance(self) -> _ComplianceNamespace:
        """Compliance: request_artifact, get_artifacts, verify_artifact, replay_run."""
        return self._compliance

    @property
    def governance(self) -> _GovernanceNamespace:
        """Governance namespace: ``create_gate_evaluator()``."""
        return self._governance

    # -- internal helpers ------------------------------------------------------

    async def _resolve_context(self, context: GovernanceContext | None) -> GovernanceContext:
        """Resolve a governance context using the configured resolver.

        Falls back to :attr:`_default_context` when *context* is ``None``.
        """
        effective = context if context is not None else self._default_context
        return await self._context_resolver(effective)

    async def _evaluate_policy(
        self,
        checkpoint: PolicyCheckpoint,
        run_id: str,
        context: GovernanceContext,
        data: dict[str, Any],
    ) -> PolicyResult:
        """Evaluate a policy checkpoint."""
        compiled: PolicyInputCompiled | None = None
        if self._compiled_policy:
            compiled = PolicyInputCompiled(
                compiler_id=self._compiled_policy.engine_id,
                snapshot_hash=self._compiled_policy.snapshot.hash,
                constraints=self._compiled_policy.constraints,
                disclosure_rules=self._compiled_policy.disclosure_rules,
            )

        policy_input = PolicyInput(
            checkpoint=checkpoint,
            context=context,
            run_id=run_id,
            data=PolicyInputData(**data),
            compiled=compiled,
        )

        return await self._policy_engine.evaluate(policy_input)

    async def _create_policy_error(
        self,
        result: PolicyResult,
        run_id: str,
        context: GovernanceContext,
    ) -> Exception:
        """Create appropriate error from policy result."""
        if result.summary.approvers and len(result.summary.approvers) > 0:
            try:
                approval = await self._approval_store.create(
                    CreateApprovalRequest(
                        run_id=run_id,
                        context=context,
                        operation="policy",
                        reason=result.summary.block_reason or "Approval required",
                        approvers=result.summary.approvers,
                    )
                )

                await self._audit_sink.write(
                    create_approval_requested_event(
                        run_id=run_id,
                        context=context,
                        approval_id=approval.id,
                        approvers=approval.approvers,
                        reason=approval.reason,
                    )
                )

                return PolicyApprovalRequiredError(
                    run_id=run_id,
                    context=context,
                    reason=result.summary.block_reason or "Approval required",
                    approvers=result.summary.approvers,
                    approval_id=approval.id,
                )
            except Exception as e:
                raise e

        return PolicyBlockedError(
            run_id=run_id,
            context=context,
            reason=result.summary.block_reason or "Policy blocked request",
            policy_code=result.summary.block_code,
        )

    def _get_policy_audit_metadata(self) -> dict[str, str | None]:
        """Get policy audit metadata."""
        if not self._compiled_policy:
            return {"policy_snapshot_hash": None, "policy_compiler_id": None}

        return {
            "policy_snapshot_hash": self._compiled_policy.snapshot.hash,
            "policy_compiler_id": self._compiled_policy.engine_id,
        }

    def _create_policy_evaluated_event_with_metadata(
        self,
        run_id: str,
        context: GovernanceContext,
        checkpoint: str,
        decisions: list[Any],
        allowed: bool,
        policy_version: str | None = None,
        parent_run_id: str | None = None,
    ) -> Any:
        """Create policy evaluated event with additional metadata."""
        metadata = self._get_policy_audit_metadata()
        return create_policy_evaluated_event(
            run_id=run_id,
            context=context,
            checkpoint=checkpoint,
            decisions=decisions,
            allowed=allowed,
            policy_version=policy_version,
            policy_snapshot_hash=metadata["policy_snapshot_hash"],
            policy_compiler_id=metadata["policy_compiler_id"],
            parent_run_id=parent_run_id,
        )

    async def _capture_snapshot(
        self,
        run_id: str,
        context: GovernanceContext,
        model_route_id: str | None = None,
    ) -> SnapshotBundle:
        """Capture a snapshot of the current state."""
        from datetime import datetime, timezone

        tool_registry_hash = None
        if self._tool_registry:
            tool_names = sorted([t.name for t in self._tool_registry.list()])
            tool_registry_hash = cag._hash_object(tool_names)

        config_state = {
            "extensions": str(self._extensions) if self._extensions else None,
            "policy_compiler_id": (
                self._compiled_policy.engine_id if self._compiled_policy else None
            ),
            "policy_version": (
                self._compiled_policy.policy_version if self._compiled_policy else None
            ),
        }
        config_state_hash = cag._hash_object(config_state)

        snapshot = SnapshotBundle(
            schema="arelis.audit.snapshot.bundle.v1",
            captured_at=datetime.now(timezone.utc).isoformat(),
            policy_snapshot_hash=(
                self._compiled_policy.snapshot.hash if self._compiled_policy else None
            ),
            model_route_id=model_route_id,
            tool_registry_hash=tool_registry_hash,
            config_state_hash=config_state_hash,
        )

        snapshot_hash = cag._hash_object(snapshot)
        snapshot.hash = snapshot_hash

        self._run_snapshots[run_id] = snapshot

        await self._audit_sink.write(
            create_snapshot_captured_event(
                run_id=run_id,
                context=context,
                snapshot_schema=snapshot.schema,
                snapshot_hash=snapshot_hash,
                policy_snapshot_hash=snapshot.policy_snapshot_hash,
                model_route_id=snapshot.model_route_id,
                tool_registry_hash=snapshot.tool_registry_hash,
                config_state_hash=snapshot.config_state_hash,
            )
        )

        return snapshot

    def _resolve_runtime_risk_route(
        self,
        operation: str,
        context: GovernanceContext,
        policy_decisions: list[PolicyDecision],
        quota_effect: Literal["allow", "limit", "block"] | None = None,
        evaluation_effect: Literal["pass", "warn", "block"] | None = None,
        explicit_signals: list[str] | None = None,
    ) -> Any:
        """Resolve risk route for an operation."""
        config = self._extensions.risk_routing if self._extensions else None
        return resolve_risk_route(
            RuntimeRiskInput(
                operation=operation,
                context=context,
                policy_decisions=policy_decisions,
                quota_effect=quota_effect,
                evaluation_effect=evaluation_effect,
                explicit_signals=explicit_signals,
            ),
            config=config,  # type: ignore[arg-type]
        )

    async def _enforce_runtime_risk_route(
        self,
        run_id: str,
        context: GovernanceContext,
        operation: str,
        policy_decisions: list[PolicyDecision],
        quota_effect: Literal["allow", "limit", "block"] | None = None,
        evaluation_effect: Literal["pass_result", "warn", "block"] | None = None,
        explicit_signals: list[str] | None = None,
    ) -> None:
        """Enforce risk route for an operation."""
        decision = self._resolve_runtime_risk_route(
            operation=operation,
            context=context,
            policy_decisions=policy_decisions,
            quota_effect=quota_effect,
            evaluation_effect="pass" if evaluation_effect == "pass_result" else evaluation_effect,
            explicit_signals=explicit_signals,
        )

        await self._audit_sink.write(
            create_risk_route_decided_event(
                run_id=run_id,
                context=context,
                route=decision.action,
                score=decision.score,
                factors=decision.factors,
                deterministic_inputs_hash=decision.deterministic_inputs_hash,
            )
        )

        if decision.action == "block":
            raise PolicyBlockedError(
                run_id=run_id,
                context=context,
                reason="Risk router blocked execution",
                policy_code="RISK_ROUTE_BLOCKED",
            )

        if decision.action == "require_approval":
            # Map simple decision to a PolicyResult for _create_policy_error
            fake_result = PolicyResult(
                decisions=policy_decisions,
                summary=PolicyResultSummary(
                    allowed=False,
                    block_reason="Risk router requires approval",
                    approvers=[context.actor.id] if context.actor else [],
                ),
            )
            raise await self._create_policy_error(fake_result, run_id, context)

    async def _wrap_model_stream(
        self,
        stream: AsyncIterator[StreamChunk],
        run_id: str,
        context: GovernanceContext,
        descriptor_id: str,
    ) -> AsyncIterator[StreamChunk]:
        """Wrap a model stream for auditing."""
        c = self

        model_info = AuditModelInfo(id=descriptor_id)

        await c._audit_sink.write(
            create_model_stream_started_event(
                run_id=run_id,
                context=context,
                model=model_info,
            )
        )

        try:
            async for chunk in stream:
                await c._audit_sink.write(
                    create_model_stream_chunk_event(
                        run_id=run_id,
                        context=context,
                        model=model_info,
                        chunk_type="delta",
                    )
                )
                yield chunk

            await c._audit_sink.write(
                create_model_stream_ended_event(
                    run_id=run_id,
                    context=context,
                    model=model_info,
                )
            )

            # End Audit Run
            await c._audit_sink.write(
                create_run_ended_event(
                    run_id=run_id,
                    context=context,
                    success=True,
                )
            )
        except Exception as e:
            await c._audit_sink.write(
                create_model_stream_aborted_event(
                    run_id=run_id,
                    context=context,
                    model=model_info,
                    reason=str(e),
                )
            )
            raise e


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------


def create_arelis_client(config: ClientConfig) -> ArelisClient:
    """Create a new :class:`ArelisClient` from the given configuration.

    This is the recommended entry point for constructing a client.

    Args:
        config: The client configuration.

    Returns:
        A configured ``ArelisClient`` instance.
    """
    return ArelisClient(config)


def createArelisClient(config: ClientConfig) -> ArelisClient:  # noqa: N802
    """CamelCase compatibility alias for :func:`create_arelis_client`."""
    warnings.warn(
        "createArelisClient() is a compatibility alias and will be deprecated in a future "
        "major release; use create_arelis_client() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return create_arelis_client(config)
