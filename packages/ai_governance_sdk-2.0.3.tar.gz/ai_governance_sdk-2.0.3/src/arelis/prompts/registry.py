"""Prompt template registry with versioning and hashing.

Ports `packages/prompts/src/template-registry.ts` from the TypeScript SDK.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone

from arelis.prompts.types import (
    PromptTemplate,
    PromptTemplateInput,
    PromptTemplateQuery,
)

__all__ = [
    "TemplateRegistry",
    "compute_prompt_hash",
    "create_template_registry",
]


def compute_prompt_hash(id: str, version: str, content: str) -> str:
    """Compute a SHA-256 hash for a prompt template.

    The hash is computed from ``{id}:{version}:{content}``.
    """
    payload = f"{id}:{version}:{content}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class TemplateRegistry:
    """Prompt template registry with versioning and content hashing."""

    def __init__(self) -> None:
        # id -> (version -> PromptTemplate)
        self._templates: dict[str, dict[str, PromptTemplate]] = {}
        self._latest_version: dict[str, str] = {}

    def register(self, input: PromptTemplateInput) -> PromptTemplate:
        """Register a prompt template."""
        if not input.id or not input.version:
            raise ValueError("Prompt template id and version are required")

        template = PromptTemplate(
            id=input.id,
            version=input.version,
            content=input.content,
            hash=compute_prompt_hash(input.id, input.version, input.content),
            metadata=input.metadata,
            created_at=datetime.now(timezone.utc).isoformat(),
        )

        versions = self._templates.get(input.id)
        if versions is None:
            versions = {}
            self._templates[input.id] = versions

        versions[input.version] = template
        self._latest_version[input.id] = input.version

        return template

    def get(self, query: PromptTemplateQuery) -> PromptTemplate | None:
        """Get a prompt template by query.

        If ``version`` is not specified, returns the latest registered version.
        """
        versions = self._templates.get(query.id)
        if versions is None:
            return None

        if query.version is not None:
            return versions.get(query.version)

        latest = self._latest_version.get(query.id)
        if latest is not None:
            return versions.get(latest)

        # Fallback to last inserted value
        last: PromptTemplate | None = None
        for value in versions.values():
            last = value
        return last

    def list(self, id: str | None = None) -> list[PromptTemplate]:
        """List prompt templates.

        If ``id`` is provided, lists all versions for that template.
        Otherwise, lists all templates across all IDs.
        """
        if id is not None:
            versions = self._templates.get(id)
            if versions is None:
                return []
            return list(versions.values())

        all_templates: list[PromptTemplate] = []
        for versions in self._templates.values():
            all_templates.extend(versions.values())
        return all_templates

    def clear(self) -> None:
        """Clear all registered templates."""
        self._templates.clear()
        self._latest_version.clear()


def create_template_registry() -> TemplateRegistry:
    """Create a new template registry."""
    return TemplateRegistry()
