"""Prompts module for the Arelis AI SDK.

Provides prompt template registration, versioning, and content hashing.
"""

from __future__ import annotations

from arelis.prompts.registry import (
    TemplateRegistry,
    compute_prompt_hash,
    create_template_registry,
)
from arelis.prompts.types import (
    PromptTemplate,
    PromptTemplateInput,
    PromptTemplateMetadata,
    PromptTemplateQuery,
)

__all__ = [
    "PromptTemplate",
    "PromptTemplateInput",
    "PromptTemplateMetadata",
    "PromptTemplateQuery",
    "TemplateRegistry",
    "compute_prompt_hash",
    "create_template_registry",
]
