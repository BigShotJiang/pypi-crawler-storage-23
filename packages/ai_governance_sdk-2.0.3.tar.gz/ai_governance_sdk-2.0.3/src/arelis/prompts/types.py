"""Prompt template types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/prompts/src/types.ts`.
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "PromptTemplate",
    "PromptTemplateInput",
    "PromptTemplateMetadata",
    "PromptTemplateQuery",
]


@dataclass
class PromptTemplateMetadata:
    """Optional metadata for a prompt template."""

    description: str | None = None
    tags: dict[str, str] | None = None


@dataclass
class PromptTemplate:
    """Registered prompt template."""

    id: str
    version: str
    hash: str
    content: str
    created_at: str
    metadata: PromptTemplateMetadata | None = None


@dataclass
class PromptTemplateInput:
    """Input for registering a prompt template."""

    id: str
    version: str
    content: str
    metadata: PromptTemplateMetadata | None = None


@dataclass
class PromptTemplateQuery:
    """Query for looking up a prompt template."""

    id: str
    version: str | None = None
