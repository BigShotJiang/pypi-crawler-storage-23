"""Quota manager protocol.

Ports the TypeScript SDK's `QuotaManager` interface from
`packages/quotas/src/types.ts`.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from arelis.quotas.types import QuotaDecision, QuotaKey, QuotaUsage

__all__ = [
    "QuotaManager",
]


@runtime_checkable
class QuotaManager(Protocol):
    """Interface for quota management.

    Implementations must provide ``check()`` to verify whether a proposed usage
    is within quota, and ``commit()`` to record actual usage after an operation
    completes.
    """

    async def check(self, key: QuotaKey, proposed: QuotaUsage) -> QuotaDecision:
        """Check whether *proposed* usage is within the quota for *key*."""
        ...

    async def commit(self, key: QuotaKey, actual: QuotaUsage) -> None:
        """Record *actual* usage against *key*."""
        ...
