"""Quotas module — quota management and enforcement."""

from __future__ import annotations

from arelis.quotas.in_memory import InMemoryQuotaManager, create_in_memory_quota_manager
from arelis.quotas.manager import QuotaManager
from arelis.quotas.types import (
    QuotaDecision,
    QuotaDecisionAllow,
    QuotaDecisionBlock,
    QuotaDecisionLimit,
    QuotaKey,
    QuotaLimits,
    QuotaUsage,
)

__all__ = [
    "InMemoryQuotaManager",
    "QuotaDecision",
    "QuotaDecisionAllow",
    "QuotaDecisionBlock",
    "QuotaDecisionLimit",
    "QuotaKey",
    "QuotaLimits",
    "QuotaManager",
    "QuotaUsage",
    "create_in_memory_quota_manager",
]
