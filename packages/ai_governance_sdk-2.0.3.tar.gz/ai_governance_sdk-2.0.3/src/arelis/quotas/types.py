"""Quota types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/quotas/src/types.ts`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

__all__ = [
    "QuotaDecision",
    "QuotaDecisionAllow",
    "QuotaDecisionBlock",
    "QuotaDecisionLimit",
    "QuotaKey",
    "QuotaLimits",
    "QuotaUsage",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

QuotaEnvironment = Literal["dev", "staging", "prod"]
"""Environment for quota scoping."""

# ---------------------------------------------------------------------------
# Core types
# ---------------------------------------------------------------------------


@dataclass
class QuotaKey:
    """Identifies a quota scope — who, what purpose, and which environment."""

    org_id: str
    purpose: str
    environment: QuotaEnvironment
    team_id: str | None = None
    actor_id: str | None = None


@dataclass
class QuotaUsage:
    """Usage metrics tracked by the quota system."""

    tokens_in: int | None = None
    tokens_out: int | None = None
    usd: float | None = None
    tool_calls: int | None = None
    kb_queries: int | None = None
    agent_steps: int | None = None
    wall_time_ms: float | None = None


# Type alias for partial usage used as limits.
QuotaLimits = QuotaUsage
"""Alias for ``QuotaUsage`` used to express limits (all fields optional)."""

# ---------------------------------------------------------------------------
# Quota decisions — discriminated union modelled as separate dataclasses
# ---------------------------------------------------------------------------


@dataclass
class QuotaDecisionAllow:
    """Quota check passed — request is allowed."""

    effect: Literal["allow"] = "allow"


@dataclass
class QuotaDecisionLimit:
    """Quota check partially limits the request."""

    applied: QuotaUsage
    reason: str
    effect: Literal["limit"] = "limit"


@dataclass
class QuotaDecisionBlock:
    """Quota check failed — request is blocked."""

    reason: str
    effect: Literal["block"] = "block"
    code: str | None = None


# Union type for quota decisions.
QuotaDecision = QuotaDecisionAllow | QuotaDecisionLimit | QuotaDecisionBlock
