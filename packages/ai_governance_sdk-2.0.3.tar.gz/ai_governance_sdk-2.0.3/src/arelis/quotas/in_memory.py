"""In-memory quota manager implementation.

Ports the TypeScript SDK's `InMemoryQuotaManager` from
`packages/quotas/src/quota-manager.ts`.
"""

from __future__ import annotations

from arelis.quotas.types import (
    QuotaDecision,
    QuotaDecisionAllow,
    QuotaDecisionBlock,
    QuotaDecisionLimit,
    QuotaKey,
    QuotaLimits,
    QuotaUsage,
)

__all__ = [
    "InMemoryQuotaManager",
    "create_in_memory_quota_manager",
]

# Fields on QuotaUsage that are trackable — order matches the TS SDK.
_USAGE_FIELDS: list[str] = [
    "tokens_in",
    "tokens_out",
    "usd",
    "tool_calls",
    "kb_queries",
    "agent_steps",
    "wall_time_ms",
]


def _key_to_string(key: QuotaKey) -> str:
    """Serialise a quota key to a deterministic cache string."""
    return "::".join(
        [
            key.org_id,
            key.team_id or "",
            key.actor_id or "",
            key.purpose,
            key.environment,
        ]
    )


class InMemoryQuotaManager:
    """Simple in-memory quota manager with configurable limits.

    Suitable for development and testing.  All state is lost when the process
    exits.  Mirrors the TypeScript ``InMemoryQuotaManager`` class.
    """

    def __init__(self, limits: QuotaLimits | None = None) -> None:
        self._limits = limits or QuotaUsage()
        self._usage: dict[str, QuotaUsage] = {}

    # -- QuotaManager protocol -----------------------------------------------

    async def check(self, key: QuotaKey, proposed: QuotaUsage) -> QuotaDecision:
        """Check whether *proposed* usage is within limits for *key*."""
        cache_key = _key_to_string(key)
        current = self._usage.get(cache_key, QuotaUsage())
        limited = False
        applied = QuotaUsage()

        for field_name in _USAGE_FIELDS:
            limit_val = getattr(self._limits, field_name)
            proposed_val = getattr(proposed, field_name)
            if limit_val is None or proposed_val is None:
                continue

            current_val: float = getattr(current, field_name) or 0
            remaining = limit_val - current_val

            if remaining <= 0:
                return QuotaDecisionBlock(
                    reason=f"Quota exceeded for {field_name}",
                    code="QUOTA_EXCEEDED",
                )

            if proposed_val > remaining:
                limited = True
                setattr(applied, field_name, remaining)

        if limited:
            return QuotaDecisionLimit(
                applied=applied,
                reason="Quota limited to remaining allowance",
            )

        return QuotaDecisionAllow()

    async def commit(self, key: QuotaKey, actual: QuotaUsage) -> None:
        """Record *actual* usage against *key*."""
        cache_key = _key_to_string(key)
        current = self._usage.get(cache_key, QuotaUsage())

        for field_name in _USAGE_FIELDS:
            value = getattr(actual, field_name)
            if value is None:
                continue
            current_value: float = getattr(current, field_name) or 0
            setattr(current, field_name, current_value + value)

        self._usage[cache_key] = current

    # -- Extra utility (matches TS SDK) --------------------------------------

    def get_usage(self, key: QuotaKey) -> QuotaUsage:
        """Return the current accumulated usage for *key*."""
        return self._usage.get(_key_to_string(key), QuotaUsage())


def create_in_memory_quota_manager(
    limits: QuotaLimits | None = None,
) -> InMemoryQuotaManager:
    """Factory function to create an ``InMemoryQuotaManager``."""
    return InMemoryQuotaManager(limits=limits)
