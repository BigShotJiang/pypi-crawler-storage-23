"""Secret types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/secrets/src/types.ts`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

__all__ = [
    "SecretRedactionPattern",
    "SecretResolution",
    "SecretResolutionResult",
    "SecretResolverContext",
]


@dataclass
class SecretResolverContext:
    """Context passed to secret resolution operations."""

    context: object | None = None  # GovernanceContext
    run_id: str | None = None
    metadata: dict[str, object] | None = None


@dataclass
class SecretResolution:
    """Metadata about a resolved secret — does NOT contain the value."""

    ref: str
    resolver_id: str
    resolved_at: str


@dataclass
class SecretResolutionResult:
    """Result of resolving a secret value."""

    value: str
    resolution: SecretResolution


@dataclass
class SecretRedactionPattern:
    """A pattern used to detect and redact secrets in text."""

    name: str
    pattern: re.Pattern[str]
    type: str = "custom"
    replacement: str | None = None
