"""Secrets module — secret resolution and detection."""

from __future__ import annotations

from arelis.secrets.patterns import get_secret_redaction_patterns
from arelis.secrets.resolver import (
    EnvSecretResolver,
    SecretResolver,
    create_env_secret_resolver,
    resolve_secret_value,
)
from arelis.secrets.types import (
    SecretRedactionPattern,
    SecretResolution,
    SecretResolutionResult,
    SecretResolverContext,
)

__all__ = [
    "EnvSecretResolver",
    "SecretRedactionPattern",
    "SecretResolution",
    "SecretResolutionResult",
    "SecretResolver",
    "SecretResolverContext",
    "create_env_secret_resolver",
    "get_secret_redaction_patterns",
    "resolve_secret_value",
]
