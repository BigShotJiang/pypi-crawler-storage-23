"""Secret resolver protocol and implementations.

Ports the TypeScript SDK's `SecretResolver` interface and `EnvSecretResolver`
from `packages/secrets/src/types.ts` and `packages/secrets/src/resolvers/env.ts`.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable

from arelis.secrets.types import SecretResolution, SecretResolutionResult, SecretResolverContext

__all__ = [
    "EnvSecretResolver",
    "SecretResolver",
    "create_env_secret_resolver",
    "resolve_secret_value",
]


@runtime_checkable
class SecretResolver(Protocol):
    """Interface for secret resolvers.

    Implementations must expose an ``id`` property and an async ``resolve()``
    method that returns the secret value for the given reference string.
    """

    @property
    def id(self) -> str:
        """Unique identifier for this resolver."""
        ...

    async def resolve(
        self,
        ref: str,
        ctx: SecretResolverContext | None = None,
    ) -> str:
        """Resolve the secret referenced by *ref* and return its value."""
        ...


class EnvSecretResolver:
    """Secret resolver that reads values from environment variables.

    If the reference starts with ``env:``, the prefix is stripped before looking
    up the environment variable.
    """

    @property
    def id(self) -> str:
        return "env"

    async def resolve(
        self,
        ref: str,
        _ctx: SecretResolverContext | None = None,
    ) -> str:
        key = ref[4:] if ref.startswith("env:") else ref
        value = os.environ.get(key)
        if not value:
            raise ValueError(f"Secret not found in env: {key}")
        return value


def create_env_secret_resolver() -> EnvSecretResolver:
    """Factory function to create an ``EnvSecretResolver``."""
    return EnvSecretResolver()


async def resolve_secret_value(
    resolver: SecretResolver,
    ref: str,
    ctx: SecretResolverContext | None = None,
) -> SecretResolutionResult:
    """Resolve a secret and return both the value and resolution metadata.

    Returns a :class:`SecretResolutionResult` with ``value`` and ``resolution`` fields.
    """
    value = await resolver.resolve(ref, ctx)
    resolution = SecretResolution(
        ref=ref,
        resolver_id=resolver.id,
        resolved_at=datetime.now(timezone.utc).isoformat(),
    )
    return SecretResolutionResult(value=value, resolution=resolution)
