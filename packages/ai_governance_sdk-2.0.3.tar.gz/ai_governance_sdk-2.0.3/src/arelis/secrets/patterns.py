"""Default secret redaction patterns.

Ports the TypeScript SDK's `packages/secrets/src/patterns.ts`.
"""

from __future__ import annotations

import re

from arelis.secrets.types import SecretRedactionPattern

__all__ = [
    "get_secret_redaction_patterns",
]

_PATTERNS: list[SecretRedactionPattern] = [
    SecretRedactionPattern(
        name="openai_sk",
        pattern=re.compile(r"sk-[A-Za-z0-9]{20,}"),
        type="custom",
    ),
    SecretRedactionPattern(
        name="slack_token",
        pattern=re.compile(r"xox[baprs]-[A-Za-z0-9\-]{10,}"),
        type="custom",
    ),
]


def get_secret_redaction_patterns() -> list[SecretRedactionPattern]:
    """Return a copy of the default secret redaction patterns."""
    return list(_PATTERNS)
