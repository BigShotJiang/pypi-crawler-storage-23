"""AI Governance SDK for Python — governed AI orchestration.

Top-level public API. Import common runtime and platform entry points from here::

    from arelis import create_arelis_client, create_arelis_platform, create_arelis
"""

from __future__ import annotations

# ── Audit ────────────────────────────────────────────────────────────────────
from arelis.audit.proof import DisclosureProof

# ── Client & Config ──────────────────────────────────────────────────────────
from arelis.client import (
    ArelisClient,
    ClientAgentRunInput,
    create_arelis_client,
    createArelisClient,
)

# ── Compliance ──────────────────────────────────────────────────────────────
from arelis.compliance.types import (
    ComplianceArtifact,
    ComplianceProofRequest,
    ComplianceReplayInput,
    ComplianceVerificationInput,
)
from arelis.config import ClientConfig, PolicyCompilationConfig

# ── Core runtime ─────────────────────────────────────────────────────────────
from arelis.core.approval_store import ApprovalResolveInput
from arelis.core.errors import (
    ArelisError,
    ArelisTimeoutError,
    EvaluationBlockedError,
    GovernanceGateDeniedError,
    PolicyApprovalRequiredError,
    PolicyBlockedError,
    ProviderError,
    ToolError,
    is_arelis_error,
    is_arelis_timeout_error,
    is_evaluation_blocked_error,
    is_governance_gate_denied_error,
    is_policy_approval_required_error,
    is_policy_blocked_error,
    is_provider_error,
    is_tool_error,
)
from arelis.core.middleware import MiddlewarePipeline
from arelis.core.result import ResultBuilder, create_empty_policy_summary, create_result_builder
from arelis.core.run_context import generate_run_id
from arelis.core.types import (
    ActorRef,
    GovernanceContext,
    OrgRef,
    ResultEnvelope,
    RunWarning,
)

# ── Data sources ─────────────────────────────────────────────────────────────
from arelis.data_sources.types import DataSourceReadInput, DataSourceRegisterInput
from arelis.governance_gate import (
    EvaluatePreInvocationGateInput,
    GovernanceGateClient,
    GovernanceGateDecisionTimings,
    GovernanceGateDeniedMode,
    GovernanceGateEvaluatePolicyInput,
    GovernanceGateEvaluator,
    GovernanceGatePlatform,
    GovernanceGatePolicyData,
    GovernanceGateSource,
    GovernanceGateTelemetryOptions,
    PreInvocationGateDecision,
    PreInvocationGateMetadata,
    PromptPiiFinding,
    PromptPiiScanResult,
    ScanPromptForPiiOptions,
    WithGovernanceGateOptions,
    WithGovernanceGateResult,
    create_governance_gate_evaluator,
    evaluate_pre_invocation_gate,
    scan_prompt_for_pii,
    with_governance_gate,
)
from arelis.governance_gate import (
    PolicyDecision as GovernanceGatePolicyDecision,
)
from arelis.governance_gate import (
    PolicyResult as GovernanceGatePolicyResult,
)
from arelis.governance_gate import (
    PolicyResultSummary as GovernanceGatePolicyResultSummary,
)
from arelis.governance_gate import (
    PolicySummaryInfo as GovernanceGatePolicySummaryInfo,
)

# ── Knowledge ────────────────────────────────────────────────────────────────
from arelis.knowledge.types import RegisterKBInput, RetrieveInput

# ── MCP ──────────────────────────────────────────────────────────────────────
from arelis.mcp.types import DiscoverMCPToolsInput, RegisterMCPServerInput

# ── Memory ───────────────────────────────────────────────────────────────────
from arelis.memory.types import MemoryDeleteInput, MemoryReadInput, MemoryWriteInput

# ── Models & Providers ───────────────────────────────────────────────────────
from arelis.models.provider import (
    AudioGenerationProvider,
    AudioToImageProvider,
    AudioToTextProvider,
    AudioToVideoProvider,
    BaseModelProvider,
    ImageGenerationProvider,
    ImageToAudioProvider,
    ImageToTextProvider,
    ImageToVideoProvider,
    ModelProvider,
    VideoGenerationProvider,
    VideoToAudioProvider,
    VideoToImageProvider,
    VideoToTextProvider,
    has_capability_flag,
    supports_audio_generation,
    supports_audio_to_image,
    supports_audio_to_text,
    supports_audio_to_video,
    supports_image_generation,
    supports_image_to_audio,
    supports_image_to_text,
    supports_image_to_video,
    supports_streaming,
    supports_token_estimation,
    supports_video_generation,
    supports_video_to_audio,
    supports_video_to_image,
    supports_video_to_text,
)
from arelis.models.types import (
    GenerateInput,
    GenerateStreamInput,
    GenerateStreamResult,
)
from arelis.platform import (
    DEFAULT_ARELIS_PLATFORM_BASE_URL,
    ArelisApiError,
    ArelisPlatform,
    ArelisPlatformConfig,
    audit_event_to_platform_event,
    create_arelis_platform,
    create_platform_event,
    createArelisPlatform,
)
from arelis.platform.types import (
    AuditEventInput,
    GetPiiConfigOptions,
    ManagedPiiConfig,
    ManagedPiiPatternDefinition,
    MCPGovernedInvokeInput,
    MCPGovernedInvokeResult,
    PlatformApprovalResolveInput,
    RuntimeRiskInput,
)
from arelis.platform.types import (
    ComplianceProofRequest as PlatformComplianceProofRequest,
)
from arelis.platform.types import (
    ComplianceVerificationInput as PlatformComplianceVerificationInput,
)

# ── Secrets ──────────────────────────────────────────────────────────────────
from arelis.secrets.types import SecretResolutionResult
from arelis.unified import (
    AgentConversationMessage,
    AgentModelResponse,
    AgentModelToolCall,
    ArelisInstance,
    CreateArelisConfig,
    GovernedAgentRunInput,
    GovernedAgentRunResult,
    GovernedAgentRunStatus,
    GovernedAgentStep,
    GovernedAgentStepToolResult,
    GovernedAgentTool,
    GovernedInvokeInput,
    GovernedInvokeResult,
    GovernedProofResult,
    create_arelis,
    createArelis,
)

__all__ = [
    # Client
    "ArelisClient",
    "create_arelis_client",
    "createArelisClient",
    "create_arelis",
    "createArelis",
    "ArelisInstance",
    "CreateArelisConfig",
    "ArelisPlatform",
    "ArelisPlatformConfig",
    "ArelisApiError",
    "DEFAULT_ARELIS_PLATFORM_BASE_URL",
    "create_arelis_platform",
    "createArelisPlatform",
    "create_platform_event",
    "audit_event_to_platform_event",
    "ClientConfig",
    "PolicyCompilationConfig",
    # Core types
    "GovernanceContext",
    "ResultEnvelope",
    "RunWarning",
    "ActorRef",
    "OrgRef",
    "ResultBuilder",
    "create_result_builder",
    "create_empty_policy_summary",
    "MiddlewarePipeline",
    "generate_run_id",
    # Governance gate helpers
    "create_governance_gate_evaluator",
    "scan_prompt_for_pii",
    "evaluate_pre_invocation_gate",
    "with_governance_gate",
    "EvaluatePreInvocationGateInput",
    "GovernanceGateClient",
    "GovernanceGateDecisionTimings",
    "GovernanceGateDeniedMode",
    "GovernanceGateEvaluatePolicyInput",
    "GovernanceGateEvaluator",
    "GovernanceGatePlatform",
    "GovernanceGatePolicyData",
    "GovernanceGateSource",
    "GovernanceGateTelemetryOptions",
    "GovernanceGatePolicyDecision",
    "GovernanceGatePolicyResult",
    "GovernanceGatePolicyResultSummary",
    "GovernanceGatePolicySummaryInfo",
    "PreInvocationGateDecision",
    "PreInvocationGateMetadata",
    "PromptPiiFinding",
    "PromptPiiScanResult",
    "ScanPromptForPiiOptions",
    "WithGovernanceGateOptions",
    "WithGovernanceGateResult",
    # Errors
    "ArelisError",
    "PolicyBlockedError",
    "PolicyApprovalRequiredError",
    "EvaluationBlockedError",
    "ProviderError",
    "ToolError",
    "ArelisTimeoutError",
    "GovernanceGateDeniedError",
    "is_arelis_error",
    "is_policy_blocked_error",
    "is_policy_approval_required_error",
    "is_evaluation_blocked_error",
    "is_provider_error",
    "is_tool_error",
    "is_arelis_timeout_error",
    "is_governance_gate_denied_error",
    # Input dataclasses
    "GenerateInput",
    "GenerateStreamInput",
    "ClientAgentRunInput",
    "RegisterMCPServerInput",
    "DiscoverMCPToolsInput",
    "RegisterKBInput",
    "RetrieveInput",
    "MemoryReadInput",
    "MemoryWriteInput",
    "MemoryDeleteInput",
    "DataSourceRegisterInput",
    "DataSourceReadInput",
    "ApprovalResolveInput",
    # Models & Providers
    "ModelProvider",
    "BaseModelProvider",
    "ImageGenerationProvider",
    "AudioGenerationProvider",
    "VideoGenerationProvider",
    "ImageToTextProvider",
    "ImageToAudioProvider",
    "ImageToVideoProvider",
    "AudioToTextProvider",
    "AudioToImageProvider",
    "AudioToVideoProvider",
    "VideoToTextProvider",
    "VideoToImageProvider",
    "VideoToAudioProvider",
    "has_capability_flag",
    "supports_streaming",
    "supports_token_estimation",
    "supports_image_generation",
    "supports_audio_generation",
    "supports_video_generation",
    "supports_image_to_text",
    "supports_image_to_audio",
    "supports_image_to_video",
    "supports_audio_to_text",
    "supports_audio_to_image",
    "supports_audio_to_video",
    "supports_video_to_text",
    "supports_video_to_image",
    "supports_video_to_audio",
    "GenerateStreamResult",
    # Audit
    "DisclosureProof",
    # Compliance
    "ComplianceProofRequest",
    "ComplianceVerificationInput",
    "ComplianceReplayInput",
    "ComplianceArtifact",
    # Platform payload contracts (curated subset)
    "AuditEventInput",
    "ManagedPiiPatternDefinition",
    "ManagedPiiConfig",
    "GetPiiConfigOptions",
    "RuntimeRiskInput",
    "MCPGovernedInvokeInput",
    "MCPGovernedInvokeResult",
    "PlatformComplianceProofRequest",
    "PlatformComplianceVerificationInput",
    "PlatformApprovalResolveInput",
    # Secrets
    "SecretResolutionResult",
    # Unified orchestration
    "GovernedInvokeInput",
    "GovernedInvokeResult",
    "AgentModelToolCall",
    "AgentModelResponse",
    "GovernedAgentTool",
    "AgentConversationMessage",
    "GovernedAgentStepToolResult",
    "GovernedAgentStep",
    "GovernedAgentRunInput",
    "GovernedAgentRunStatus",
    "GovernedProofResult",
    "GovernedAgentRunResult",
]
