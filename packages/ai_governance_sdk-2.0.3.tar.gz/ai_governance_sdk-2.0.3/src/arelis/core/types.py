"""Core types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/core/src/types.ts`:
GovernanceContext, UsageInfo, PolicySummary, RunWarning, ResultEnvelope[T],
MiddlewareContext, and the Middleware protocol.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import (
    Generic,
    Literal,
    TypeVar,
)

__all__ = [
    "ActorRef",
    "ActorType",
    "Environment",
    "GovernanceContext",
    "Middleware",
    "MiddlewareContext",
    "OrgRef",
    "PolicySummary",
    "ResultEnvelope",
    "RunWarning",
    "TeamRef",
    "UsageInfo",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

ActorType = Literal["human", "service", "agent"]
"""The type of actor performing an action."""

Environment = Literal["dev", "staging", "prod"]
"""Deployment environment."""

# ---------------------------------------------------------------------------
# Nested reference types
# ---------------------------------------------------------------------------


@dataclass
class OrgRef:
    """Organization reference."""

    id: str
    name: str | None = None


@dataclass
class TeamRef:
    """Team reference (optional in GovernanceContext)."""

    id: str
    name: str | None = None


@dataclass
class ActorRef:
    """Actor performing the action."""

    type: ActorType
    id: str
    email: str | None = None
    roles: list[str] | None = None


# ---------------------------------------------------------------------------
# GovernanceContext
# ---------------------------------------------------------------------------


@dataclass
class GovernanceContext:
    """Governance context containing org, team, actor, and request metadata.

    Every SDK operation requires a ``GovernanceContext`` to identify the caller,
    the organisation, the purpose of the request and the deployment environment.
    The context flows through the middleware pipeline and is attached to every
    audit event.
    """

    org: OrgRef
    actor: ActorRef
    purpose: str
    environment: Environment
    team: TeamRef | None = None
    session_id: str | None = None
    request_id: str | None = None
    tags: dict[str, str] | None = None


# ---------------------------------------------------------------------------
# UsageInfo
# ---------------------------------------------------------------------------


@dataclass
class UsageInfo:
    """Usage information for model calls."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    cost_usd: float | None = None


# ---------------------------------------------------------------------------
# PolicySummary
# ---------------------------------------------------------------------------


@dataclass
class PolicySummary:
    """Policy evaluation summary for a run."""

    evaluated: int = 0
    allowed: int = 0
    blocked: int = 0
    transformed: int = 0
    reasons: list[str] | None = None


# ---------------------------------------------------------------------------
# RunWarning
# ---------------------------------------------------------------------------


@dataclass
class RunWarning:
    """Warning produced during a run."""

    code: str
    message: str
    details: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# ResultEnvelope[T]
# ---------------------------------------------------------------------------

T = TypeVar("T")


@dataclass
class ResultEnvelope(Generic[T]):
    """Result envelope returned by all SDK operations.

    Wraps the operation output with run tracing, usage metrics, policy
    evaluation summaries, and any warnings produced during the run.
    """

    run_id: str
    output: T
    usage: UsageInfo | None = None
    policy: PolicySummary | None = None
    warnings: list[RunWarning] | None = None


# ---------------------------------------------------------------------------
# MiddlewareContext
# ---------------------------------------------------------------------------


@dataclass
class MiddlewareContext:
    """Context passed through the middleware pipeline."""

    run_id: str
    context: GovernanceContext
    metadata: dict[str, object] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Middleware callable type
# ---------------------------------------------------------------------------

Middleware = Callable[[MiddlewareContext, Callable[[], Awaitable[None]]], Awaitable[None]]
"""Middleware function signature.

A middleware receives the current ``MiddlewareContext`` and a *next* callback.
It must ``await next()`` to continue the pipeline (or skip it to short-circuit).
"""
