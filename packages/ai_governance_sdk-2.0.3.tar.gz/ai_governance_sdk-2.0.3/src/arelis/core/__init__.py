"""Core runtime module — types, errors, middleware, result builder, and context."""

from __future__ import annotations

from arelis.core.approval_store import ApprovalStore, InMemoryApprovalStore
from arelis.core.errors import (
    ArelisError,
    ArelisTimeoutError,
    EvaluationBlockedError,
    GovernanceGateDeniedError,
    PolicyApprovalRequiredError,
    PolicyBlockedError,
    ProviderError,
    ToolError,
    is_arelis_error,
    is_arelis_timeout_error,
    is_evaluation_blocked_error,
    is_governance_gate_denied_error,
    is_policy_approval_required_error,
    is_policy_blocked_error,
    is_provider_error,
    is_tool_error,
)
from arelis.core.middleware import MiddlewarePipeline, compose_middleware, named_middleware
from arelis.core.result import ResultBuilder, create_result, merge_policy_summaries
from arelis.core.run_context import generate_run_id
from arelis.core.types import (
    ActorRef,
    GovernanceContext,
    OrgRef,
    ResultEnvelope,
    RunWarning,
)

__all__ = [
    # Types
    "ActorRef",
    "GovernanceContext",
    "OrgRef",
    "ResultEnvelope",
    "RunWarning",
    # Errors
    "ArelisError",
    "ArelisTimeoutError",
    "EvaluationBlockedError",
    "GovernanceGateDeniedError",
    "PolicyApprovalRequiredError",
    "PolicyBlockedError",
    "ProviderError",
    "ToolError",
    "is_arelis_error",
    "is_arelis_timeout_error",
    "is_evaluation_blocked_error",
    "is_governance_gate_denied_error",
    "is_policy_approval_required_error",
    "is_policy_blocked_error",
    "is_provider_error",
    "is_tool_error",
    # Middleware
    "MiddlewarePipeline",
    "compose_middleware",
    "named_middleware",
    # Result
    "ResultBuilder",
    "create_result",
    "merge_policy_summaries",
    # Context
    "generate_run_id",
    # Approval
    "ApprovalStore",
    "InMemoryApprovalStore",
]
