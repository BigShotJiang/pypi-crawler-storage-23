"""Error hierarchy for the Arelis AI SDK.

Ports the full error tree from the TypeScript SDK's
``packages/core/src/errors.ts`` plus ``GovernanceGateDeniedError`` from
``packages/sdk/src/governance-gate.ts``.

Each concrete error class has a corresponding ``is_*`` guard function that
mirrors the TypeScript ``isFooError()`` helpers.
"""

from __future__ import annotations

from arelis.core.types import GovernanceContext

__all__ = [
    "ArelisError",
    "ArelisTimeoutError",
    "EvaluationBlockedError",
    "GovernanceGateDeniedError",
    "PolicyApprovalRequiredError",
    "PolicyBlockedError",
    "ProviderError",
    "ToolError",
    "is_arelis_error",
    "is_arelis_timeout_error",
    "is_evaluation_blocked_error",
    "is_governance_gate_denied_error",
    "is_policy_approval_required_error",
    "is_policy_blocked_error",
    "is_provider_error",
    "is_tool_error",
]


# ---------------------------------------------------------------------------
# Base error
# ---------------------------------------------------------------------------


class ArelisError(Exception):
    """Base error for all Arelis SDK errors.

    Parameters
    ----------
    message:
        Human-readable error description.
    run_id:
        Unique run identifier that produced this error.
    code:
        Machine-readable error code (e.g. ``"POLICY_BLOCKED"``).
    error_type:
        Dotted error category (e.g. ``"policy.blocked"``).
    context:
        The :class:`GovernanceContext` active when the error occurred.
    cause:
        An optional underlying exception.
    """

    def __init__(
        self,
        message: str,
        *,
        run_id: str,
        code: str,
        error_type: str,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.run_id: str = run_id
        self.code: str = code
        self.error_type: str = error_type
        self.context: GovernanceContext | None = context
        self.__cause__ = cause

    def to_dict(self) -> dict[str, object]:
        """Serialise the error to a JSON-safe dictionary."""
        result: dict[str, object] = {
            "name": type(self).__name__,
            "message": str(self),
            "run_id": self.run_id,
            "code": self.code,
            "type": self.error_type,
        }
        if self.context is not None:
            result["context"] = {
                "org": {"id": self.context.org.id, "name": self.context.org.name},
                "actor": {"type": self.context.actor.type, "id": self.context.actor.id},
                "purpose": self.context.purpose,
                "environment": self.context.environment,
            }
        return result


# ---------------------------------------------------------------------------
# Concrete error classes
# ---------------------------------------------------------------------------


class PolicyBlockedError(ArelisError):
    """Error thrown when a policy blocks an operation."""

    def __init__(
        self,
        *,
        run_id: str,
        reason: str,
        context: GovernanceContext | None = None,
        policy_code: str | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(
            f"Policy blocked: {reason}",
            run_id=run_id,
            code=policy_code or "POLICY_BLOCKED",
            error_type="policy.blocked",
            context=context,
            cause=cause,
        )
        self.reason: str = reason
        self.policy_code: str | None = policy_code


class PolicyApprovalRequiredError(ArelisError):
    """Error thrown when an operation requires approval before proceeding."""

    def __init__(
        self,
        *,
        run_id: str,
        reason: str,
        approvers: list[str] | None = None,
        approval_id: str | None = None,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(
            f"Approval required: {reason}",
            run_id=run_id,
            code="APPROVAL_REQUIRED",
            error_type="policy.approval_required",
            context=context,
            cause=cause,
        )
        self.reason: str = reason
        self.approvers: list[str] = approvers if approvers is not None else []
        self.approval_id: str | None = approval_id


class EvaluationBlockedError(ArelisError):
    """Error thrown when an evaluation guardrail blocks an operation."""

    def __init__(
        self,
        *,
        run_id: str,
        evaluator_id: str,
        reason: str,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(
            f"Evaluation blocked: {reason}",
            run_id=run_id,
            code="EVALUATION_BLOCKED",
            error_type="evaluation.blocked",
            context=context,
            cause=cause,
        )
        self.evaluator_id: str = evaluator_id
        self.reason: str = reason


class ProviderError(ArelisError):
    """Error thrown by model providers (e.g. rate limit, auth failure)."""

    def __init__(
        self,
        *,
        run_id: str,
        message: str,
        provider: str,
        retryable: bool = False,
        status_code: int | None = None,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(
            message,
            run_id=run_id,
            code="PROVIDER_ERROR",
            error_type="provider.error",
            context=context,
            cause=cause,
        )
        self.provider: str = provider
        self.retryable: bool = retryable
        self.status_code: int | None = status_code


class ToolError(ArelisError):
    """Error thrown during tool execution."""

    def __init__(
        self,
        *,
        run_id: str,
        message: str,
        tool_name: str,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(
            f'Tool "{tool_name}" failed: {message}',
            run_id=run_id,
            code="TOOL_ERROR",
            error_type="tool.error",
            context=context,
            cause=cause,
        )
        self.tool_name: str = tool_name
        self.original_error: BaseException | None = cause


class ArelisTimeoutError(ArelisError):
    """Error thrown when an operation exceeds its time budget.

    Named ``ArelisTimeoutError`` to avoid shadowing the built-in
    :class:`TimeoutError`.
    """

    def __init__(
        self,
        *,
        run_id: str,
        elapsed_ms: float,
        limit_ms: float,
        operation: str | None = None,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        op = operation or "Operation"
        super().__init__(
            f"{op} timed out after {elapsed_ms}ms (limit: {limit_ms}ms)",
            run_id=run_id,
            code="TIMEOUT",
            error_type="timeout",
            context=context,
            cause=cause,
        )
        self.elapsed_ms: float = elapsed_ms
        self.limit_ms: float = limit_ms


class GovernanceGateDeniedError(ArelisError):
    """Error thrown when the pre-invocation governance gate denies a request.

    Carries the list of *reasons* from the gate decision.
    """

    def __init__(
        self,
        *,
        run_id: str,
        reasons: list[str] | None = None,
        decision: object | None = None,
        context: GovernanceContext | None = None,
        cause: BaseException | None = None,
    ) -> None:
        reason_list = reasons if reasons is not None else []
        combined = "; ".join(reason_list) if reason_list else "Policy denied"
        super().__init__(
            f"Governance gate denied invocation: {combined}",
            run_id=run_id,
            code="GOVERNANCE_GATE_DENIED",
            error_type="governance_gate.denied",
            context=context,
            cause=cause,
        )
        self.reasons: list[str] = reason_list
        self.decision: object | None = decision


# ---------------------------------------------------------------------------
# Guard functions
# ---------------------------------------------------------------------------


def is_arelis_error(error: object) -> bool:
    """Check if *error* is an :class:`ArelisError`."""
    return isinstance(error, ArelisError)


def is_policy_blocked_error(error: object) -> bool:
    """Check if *error* is a :class:`PolicyBlockedError`."""
    return isinstance(error, PolicyBlockedError)


def is_policy_approval_required_error(error: object) -> bool:
    """Check if *error* is a :class:`PolicyApprovalRequiredError`."""
    return isinstance(error, PolicyApprovalRequiredError)


def is_evaluation_blocked_error(error: object) -> bool:
    """Check if *error* is an :class:`EvaluationBlockedError`."""
    return isinstance(error, EvaluationBlockedError)


def is_provider_error(error: object) -> bool:
    """Check if *error* is a :class:`ProviderError`."""
    return isinstance(error, ProviderError)


def is_tool_error(error: object) -> bool:
    """Check if *error* is a :class:`ToolError`."""
    return isinstance(error, ToolError)


def is_arelis_timeout_error(error: object) -> bool:
    """Check if *error* is an :class:`ArelisTimeoutError`."""
    return isinstance(error, ArelisTimeoutError)


def is_governance_gate_denied_error(error: object) -> bool:
    """Check if *error* is a :class:`GovernanceGateDeniedError`."""
    return isinstance(error, GovernanceGateDeniedError)
