"""Middleware pipeline for ordered execution.

Ports ``packages/core/src/middleware.ts`` from the TypeScript SDK.
Provides :class:`MiddlewarePipeline` for chaining async middleware functions,
:func:`compose_middleware` for combining multiple middleware into one,
and :func:`named_middleware` for attaching debug timing metadata.
"""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable

from arelis.core.types import Middleware, MiddlewareContext

__all__ = [
    "MiddlewarePipeline",
    "compose_middleware",
    "named_middleware",
]


class MiddlewarePipeline:
    """Middleware pipeline for ordered execution.

    Middleware functions are executed in the order they were added via
    :meth:`use`.  Each middleware receives the shared
    :class:`~arelis.core.types.MiddlewareContext` and a ``next`` callback that
    invokes the next middleware in the chain.
    """

    def __init__(self) -> None:
        self._middlewares: list[Middleware] = []

    def use(self, middleware: Middleware) -> MiddlewarePipeline:
        """Add a middleware to the pipeline.

        Returns *self* so calls can be chained.
        """
        self._middlewares.append(middleware)
        return self

    async def execute(self, ctx: MiddlewareContext) -> None:
        """Execute all middleware in order."""
        index = 0

        async def next_fn() -> None:
            nonlocal index
            if index >= len(self._middlewares):
                return

            middleware = self._middlewares[index]
            index += 1
            await middleware(ctx, next_fn)

        await next_fn()

    @property
    def length(self) -> int:
        """Return the number of middleware in the pipeline."""
        return len(self._middlewares)

    def clear(self) -> None:
        """Remove all middleware from the pipeline."""
        self._middlewares.clear()


def compose_middleware(*middlewares: Middleware) -> Middleware:
    """Compose multiple middleware into a single middleware.

    The composed middleware executes the given *middlewares* in order, then
    calls the outer ``next`` callback once all have completed.
    """

    async def composed(
        ctx: MiddlewareContext,
        next_fn: Callable[[], Awaitable[None]],
    ) -> None:
        index = 0

        async def dispatch() -> None:
            nonlocal index
            if index >= len(middlewares):
                await next_fn()
                return

            middleware = middlewares[index]
            index += 1
            await middleware(ctx, dispatch)

        await dispatch()

    return composed


def named_middleware(name: str, fn: Middleware) -> Middleware:
    """Create a named middleware that records timing metadata.

    The middleware stores ``middleware.<name>.started`` and
    ``middleware.<name>.ended`` timestamps (epoch milliseconds) in
    ``ctx.metadata`` for debugging and telemetry purposes.
    """

    async def middleware(
        ctx: MiddlewareContext,
        next_fn: Callable[[], Awaitable[None]],
    ) -> None:
        ctx.metadata[f"middleware.{name}.started"] = int(time.time() * 1000)
        try:
            await fn(ctx, next_fn)
        finally:
            ctx.metadata[f"middleware.{name}.ended"] = int(time.time() * 1000)

    # Attach the name for introspection (mirrors Object.defineProperty in TS)
    middleware.__name__ = name
    middleware.__qualname__ = name
    return middleware
