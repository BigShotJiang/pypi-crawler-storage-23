"""Run context utilities for the Arelis AI SDK.

Ports ``packages/core/src/run-context.ts``:

- :func:`generate_run_id` -- ULID-like run identifier with ``run_`` prefix.
- :func:`default_context_resolver` -- validates and fills defaults on a partial
  :class:`GovernanceContext`.
- :func:`create_middleware_context` -- builds a :class:`MiddlewareContext`.
- :class:`RunContext` -- tracks a single run's lifecycle (timing, metadata).
"""

from __future__ import annotations

import os
import time
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone

from arelis.core.types import (
    GovernanceContext,
    MiddlewareContext,
)

__all__ = [
    "ContextResolver",
    "RunContext",
    "create_middleware_context",
    "default_context_resolver",
    "generate_run_id",
]


# ---------------------------------------------------------------------------
# Run ID generation
# ---------------------------------------------------------------------------


def generate_run_id() -> str:
    """Generate a unique run ID with the ``run_`` prefix.

    The ID is composed of a 48-bit millisecond timestamp (12 hex chars) followed
    by 80 bits of randomness (20 hex chars), giving ULID-like ordering and
    uniqueness guarantees while staying purely in the standard library.

    Example output: ``run_018f6e3a1b4c9a7d3e2f1b0c8a``
    """
    timestamp_ms = int(time.time() * 1000)
    random_bytes = os.urandom(10)  # 80 bits
    ts_hex = f"{timestamp_ms:012x}"
    rand_hex = random_bytes.hex()
    return f"run_{ts_hex}{rand_hex}"


# ---------------------------------------------------------------------------
# Context resolver
# ---------------------------------------------------------------------------

ContextResolver = Callable[[GovernanceContext | None], Awaitable[GovernanceContext]]
"""Async callable that resolves a (possibly partial) governance context into
a fully-populated :class:`GovernanceContext`."""


async def default_context_resolver(
    partial: GovernanceContext | None,
) -> GovernanceContext:
    """Validate and fill in defaults for a :class:`GovernanceContext`.

    Raises :class:`ValueError` if any mandatory field is missing.
    """
    if partial is None:
        raise ValueError("GovernanceContext is required")

    if not partial.org or not partial.org.id:
        raise ValueError("GovernanceContext.org.id is required")

    if not partial.actor or not partial.actor.type or not partial.actor.id:
        raise ValueError("GovernanceContext.actor (type and id) is required")

    if not partial.purpose:
        raise ValueError("GovernanceContext.purpose is required")

    if not partial.environment:
        raise ValueError("GovernanceContext.environment is required")

    result = GovernanceContext(
        org=partial.org,
        actor=partial.actor,
        purpose=partial.purpose,
        environment=partial.environment,
    )

    if partial.team is not None:
        result.team = partial.team

    if partial.session_id is not None:
        result.session_id = partial.session_id

    result.request_id = partial.request_id if partial.request_id is not None else generate_run_id()

    if partial.tags is not None:
        result.tags = partial.tags

    return result


# ---------------------------------------------------------------------------
# Middleware context factory
# ---------------------------------------------------------------------------


def create_middleware_context(
    context: GovernanceContext,
    run_id: str | None = None,
) -> MiddlewareContext:
    """Create a :class:`MiddlewareContext` for a new run."""
    return MiddlewareContext(
        run_id=run_id if run_id is not None else generate_run_id(),
        context=context,
        metadata={},
    )


# ---------------------------------------------------------------------------
# RunContext
# ---------------------------------------------------------------------------


class RunContext:
    """Tracks the lifecycle of a single SDK run.

    Records start/end times, holds metadata, and provides duration calculation.
    """

    def __init__(
        self,
        context: GovernanceContext,
        run_id: str | None = None,
    ) -> None:
        self.run_id: str = run_id if run_id is not None else generate_run_id()
        self.context: GovernanceContext = context
        self.start_time: datetime = datetime.now(timezone.utc)
        self.end_time: datetime | None = None
        self._metadata: dict[str, object] = {}

    # -- lifecycle -----------------------------------------------------------

    def end(self) -> None:
        """Mark the run as ended."""
        self.end_time = datetime.now(timezone.utc)

    def get_duration_ms(self) -> float | None:
        """Return the run duration in milliseconds, or ``None`` if not ended."""
        if self.end_time is None:
            return None
        delta = self.end_time - self.start_time
        return delta.total_seconds() * 1000.0

    # -- metadata ------------------------------------------------------------

    def set_metadata(self, key: str, value: object) -> None:
        """Store an arbitrary metadata value on the run context."""
        self._metadata[key] = value

    def get_metadata(self, key: str) -> object | None:
        """Retrieve a metadata value, or ``None`` if not present."""
        return self._metadata.get(key)
