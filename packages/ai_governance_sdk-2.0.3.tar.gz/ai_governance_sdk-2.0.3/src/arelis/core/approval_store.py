"""Approval store for governance-controlled operations.

Ports ``packages/core/src/approval-store.ts`` from the TypeScript SDK.
Provides the :class:`ApprovalStore` protocol, supporting types, and an
:class:`InMemoryApprovalStore` reference implementation.
"""

from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Literal, Protocol, runtime_checkable

from arelis.core.types import GovernanceContext

__all__ = [
    "ApprovalResolveInput",
    "ApprovalStatus",
    "ApprovalRequest",
    "ApprovalDecision",
    "ApprovalStore",
    "InMemoryApprovalStore",
    "create_in_memory_approval_store",
]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

ApprovalStatus = Literal["pending", "approved", "rejected"]
"""Status of an approval request."""


@dataclass
class ApprovalRequest:
    """An approval request tracked by an :class:`ApprovalStore`."""

    id: str
    run_id: str
    context: GovernanceContext
    operation: str
    reason: str
    approvers: list[str]
    status: ApprovalStatus
    created_at: str
    resolved_at: str | None = None
    resolved_by: str | None = None
    metadata: dict[str, object] | None = None


@dataclass
class ApprovalDecision:
    """The outcome of resolving an approval request."""

    id: str
    status: Literal["approved", "rejected"]
    resolved_at: str
    resolved_by: str
    reason: str | None = None


@dataclass
class CreateApprovalRequest:
    """Input for creating a new approval request.

    Contains all fields of :class:`ApprovalRequest` except ``id``,
    ``status``, and ``created_at`` which are assigned by the store.
    """

    run_id: str
    context: GovernanceContext
    operation: str
    reason: str
    approvers: list[str] | None = None
    metadata: dict[str, object] | None = None


@dataclass
class ApprovalResolveInput:
    """Input for ``client.approvals.approve()`` / ``reject()``."""

    approval_id: str
    resolved_by: str
    reason: str | None = None
    context: GovernanceContext | None = None


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ApprovalStore(Protocol):
    """Protocol for approval request persistence."""

    async def create(self, request: CreateApprovalRequest) -> ApprovalRequest:
        """Create a new pending approval request."""
        ...

    async def get(self, id: str) -> ApprovalRequest | None:
        """Retrieve an approval request by ID, or ``None`` if not found."""
        ...

    async def list(self, status: ApprovalStatus | None = None) -> list[ApprovalRequest]:
        """List approval requests, optionally filtered by status."""
        ...

    async def approve(
        self,
        id: str,
        resolved_by: str,
        reason: str | None = None,
    ) -> ApprovalDecision:
        """Approve an approval request."""
        ...

    async def reject(
        self,
        id: str,
        resolved_by: str,
        reason: str | None = None,
    ) -> ApprovalDecision:
        """Reject an approval request."""
        ...


# ---------------------------------------------------------------------------
# In-memory implementation
# ---------------------------------------------------------------------------


def _generate_approval_id() -> str:
    """Generate a unique approval request identifier."""
    ts = int(time.time() * 1000)
    suffix = secrets.token_hex(3)
    return f"approval_{ts}_{suffix}"


def _iso_now() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


class InMemoryApprovalStore:
    """In-memory :class:`ApprovalStore` implementation.

    Useful for testing, development, and single-process deployments.
    Data is lost when the process exits.
    """

    def __init__(self) -> None:
        self._requests: dict[str, ApprovalRequest] = {}

    async def create(self, request: CreateApprovalRequest) -> ApprovalRequest:
        """Create a new pending approval request."""
        approval_id = _generate_approval_id()
        created_at = _iso_now()

        entry = ApprovalRequest(
            id=approval_id,
            run_id=request.run_id,
            context=request.context,
            operation=request.operation,
            reason=request.reason,
            approvers=list(request.approvers) if request.approvers is not None else [],
            status="pending",
            created_at=created_at,
            metadata=dict(request.metadata) if request.metadata is not None else None,
        )

        self._requests[approval_id] = entry
        return entry

    async def get(self, id: str) -> ApprovalRequest | None:
        """Retrieve an approval request by ID."""
        return self._requests.get(id)

    async def list(self, status: ApprovalStatus | None = None) -> list[ApprovalRequest]:
        """List approval requests, optionally filtered by status."""
        all_requests = list(self._requests.values())
        if status is not None:
            return [r for r in all_requests if r.status == status]
        return all_requests

    async def approve(
        self,
        id: str,
        resolved_by: str,
        reason: str | None = None,
    ) -> ApprovalDecision:
        """Approve an approval request.

        Raises:
            KeyError: If the approval request is not found.
        """
        req = self._requests.get(id)
        if req is None:
            raise KeyError(f"Approval request not found: {id}")

        resolved_at = _iso_now()
        req.status = "approved"
        req.resolved_at = resolved_at
        req.resolved_by = resolved_by

        if reason is not None:
            if req.metadata is None:
                req.metadata = {}
            req.metadata["reason"] = reason

        return ApprovalDecision(
            id=id,
            status="approved",
            resolved_at=resolved_at,
            resolved_by=resolved_by,
            reason=reason,
        )

    async def reject(
        self,
        id: str,
        resolved_by: str,
        reason: str | None = None,
    ) -> ApprovalDecision:
        """Reject an approval request.

        Raises:
            KeyError: If the approval request is not found.
        """
        req = self._requests.get(id)
        if req is None:
            raise KeyError(f"Approval request not found: {id}")

        resolved_at = _iso_now()
        req.status = "rejected"
        req.resolved_at = resolved_at
        req.resolved_by = resolved_by

        if reason is not None:
            if req.metadata is None:
                req.metadata = {}
            req.metadata["reason"] = reason

        return ApprovalDecision(
            id=id,
            status="rejected",
            resolved_at=resolved_at,
            resolved_by=resolved_by,
            reason=reason,
        )


def create_in_memory_approval_store() -> InMemoryApprovalStore:
    """Factory function for :class:`InMemoryApprovalStore`."""
    return InMemoryApprovalStore()
