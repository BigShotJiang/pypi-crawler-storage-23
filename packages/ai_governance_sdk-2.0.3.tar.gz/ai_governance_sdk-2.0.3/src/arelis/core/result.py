"""Result envelope builder and merge helpers.

Ports ``packages/core/src/result.ts`` from the TypeScript SDK.
Provides :class:`ResultBuilder` for incrementally constructing a
:class:`~arelis.core.types.ResultEnvelope`, plus factory and merge utilities.
"""

from __future__ import annotations

from typing import Generic, TypeVar

from arelis.core.types import PolicySummary, ResultEnvelope, RunWarning, UsageInfo

__all__ = [
    "ResultBuilder",
    "create_result",
    "create_result_builder",
    "create_empty_policy_summary",
    "merge_policy_summaries",
]

T = TypeVar("T")


class ResultBuilder(Generic[T]):
    """Builder for creating :class:`ResultEnvelope` instances incrementally."""

    def __init__(self, run_id: str) -> None:
        self._run_id = run_id
        self._output: T | None = None
        self._usage: UsageInfo | None = None
        self._policy: PolicySummary | None = None
        self._warnings: list[RunWarning] = []

    def set_output(self, output: T) -> ResultBuilder[T]:
        """Set the output value."""
        self._output = output
        return self

    def set_usage(self, usage: UsageInfo) -> ResultBuilder[T]:
        """Set usage information."""
        self._usage = usage
        return self

    def set_policy(self, policy: PolicySummary) -> ResultBuilder[T]:
        """Set policy summary."""
        self._policy = policy
        return self

    def add_warning(self, warning: RunWarning) -> ResultBuilder[T]:
        """Add a single warning."""
        self._warnings.append(warning)
        return self

    def add_warnings(self, warnings: list[RunWarning]) -> ResultBuilder[T]:
        """Add multiple warnings."""
        self._warnings.extend(warnings)
        return self

    def build(self) -> ResultEnvelope[T]:
        """Build the result envelope.

        Raises:
            ValueError: If no output has been set.
        """
        if self._output is None:
            raise ValueError("Output is required to build a result envelope")

        result = ResultEnvelope[T](
            run_id=self._run_id,
            output=self._output,
        )

        if self._usage is not None:
            result.usage = self._usage

        if self._policy is not None:
            result.policy = self._policy

        if len(self._warnings) > 0:
            result.warnings = list(self._warnings)

        return result


def create_result_builder(run_id: str) -> ResultBuilder[object]:
    """Create a new :class:`ResultBuilder` with the given run ID."""
    return ResultBuilder[object](run_id)


def create_result(
    run_id: str,
    output: T,
    *,
    usage: UsageInfo | None = None,
    policy: PolicySummary | None = None,
    warnings: list[RunWarning] | None = None,
) -> ResultEnvelope[T]:
    """Create a simple result envelope in one call."""
    result = ResultEnvelope[T](
        run_id=run_id,
        output=output,
    )

    if usage is not None:
        result.usage = usage

    if policy is not None:
        result.policy = policy

    if warnings is not None and len(warnings) > 0:
        result.warnings = list(warnings)

    return result


def create_empty_policy_summary() -> PolicySummary:
    """Create an empty :class:`PolicySummary` with all counters at zero."""
    return PolicySummary(evaluated=0, allowed=0, blocked=0, transformed=0)


def merge_policy_summaries(*summaries: PolicySummary) -> PolicySummary:
    """Merge multiple :class:`PolicySummary` instances into one.

    Counters are summed and reason lists are concatenated.
    """
    result = create_empty_policy_summary()
    all_reasons: list[str] = []

    for summary in summaries:
        result.evaluated += summary.evaluated
        result.allowed += summary.allowed
        result.blocked += summary.blocked
        result.transformed += summary.transformed

        if summary.reasons is not None:
            all_reasons.extend(summary.reasons)

    if len(all_reasons) > 0:
        result.reasons = all_reasons

    return result
