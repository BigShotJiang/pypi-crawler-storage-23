"""Replay engine for deterministic re-execution from audit trails.

Ports ``packages/core/src/replay.ts`` from the TypeScript SDK.
Provides types for capturing replay inputs and results, and a
:data:`ReplayRunner` callable protocol for executing replays.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Generic, TypeVar

__all__ = [
    "ReplayInput",
    "ReplayStep",
    "ReplayResult",
    "ReplayRunner",
]

Event = TypeVar("Event")
Output = TypeVar("Output")


@dataclass
class ReplayInput(Generic[Event]):
    """Input for a replay operation.

    Attributes:
        run_id: The run identifier to replay.
        events: Audit or telemetry events used for replay.
    """

    run_id: str
    events: list[Event] = field(default_factory=list)


@dataclass
class ReplayStep(Generic[Output]):
    """A single step reconstructed during replay.

    Attributes:
        index: Index of the step in replay order.
        type: Event type or step label, if available.
        time: Event timestamp in ISO-8601 format, if available.
        output: Output reconstructed for this step, if available.
    """

    index: int
    type: str | None = None
    time: str | None = None
    output: Output | None = None


@dataclass
class ReplayResult(Generic[Output]):
    """The result of replaying a run.

    Attributes:
        run_id: The run identifier that was replayed.
        steps: Ordered list of reconstructed replay steps.
        warnings: Any warnings encountered during replay.
    """

    run_id: str
    steps: list[ReplayStep[Output]] = field(default_factory=list)
    warnings: list[str] | None = None


ReplayRunner = Callable[[ReplayInput[Event]], Awaitable[ReplayResult[Output]]]
"""Callable type for replay execution.

A replay runner takes a :class:`ReplayInput` and returns a
:class:`ReplayResult` asynchronously.
"""
