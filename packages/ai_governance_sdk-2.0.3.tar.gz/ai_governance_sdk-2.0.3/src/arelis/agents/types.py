"""Agent types for the Arelis AI SDK.

Ports ``packages/agents/src/types.ts`` from the TypeScript SDK.
Provides types for agent execution: configuration, steps, results,
handlers, and run inputs.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime
from typing import Generic, Literal, TypeVar

from arelis.core.types import GovernanceContext, PolicySummary, UsageInfo

__all__ = [
    "AgentConfig",
    "AgentHandlers",
    "AgentLimits",
    "AgentResult",
    "AgentRunInput",
    "AgentRunStatus",
    "AgentStep",
    "AgentStepAttestation",
    "AgentStepPhase",
    "CompiledPolicyMetadata",
    "StepExecution",
    "StepObservation",
    "StepPlan",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

AgentStepPhase = Literal["plan", "execute", "observe"]
"""Phase of an agent step."""

AgentRunStatus = Literal["running", "completed", "failed", "max_steps_reached", "timeout"]
"""Status of an agent run."""

# ---------------------------------------------------------------------------
# Compiled policy metadata
# ---------------------------------------------------------------------------


@dataclass
class CompiledPolicyMetadata:
    """Compiled policy metadata for the agent runtime.

    Mirrors ``CompiledPolicyMetadata`` from the TypeScript SDK's agent-runtime.

    Attributes:
        snapshot_hash: Hash of the compiled policy snapshot.
        compiler_id: Identifier of the policy compiler.
        constraints: Compiled policy constraints (engine-specific).
        disclosure_rules: Compiled disclosure rules (engine-specific).
        policy_version: Version of the compiled policy.
    """

    snapshot_hash: str | None = None
    compiler_id: str | None = None
    constraints: object | None = None
    disclosure_rules: object | None = None
    policy_version: str | None = None


# ---------------------------------------------------------------------------
# Agent limits
# ---------------------------------------------------------------------------


@dataclass
class AgentLimits:
    """Agent execution limits.

    Attributes:
        max_steps: Maximum number of steps the agent can execute.
        max_time_ms: Maximum execution time in milliseconds.
    """

    max_steps: int = 10
    max_time_ms: int = 30_000


# ---------------------------------------------------------------------------
# Step attestation
# ---------------------------------------------------------------------------


@dataclass
class AgentStepAttestation:
    """Attestation for a single agent step phase.

    Attributes:
        step_number: Step number this attestation belongs to.
        phase: Phase of the step.
        attestation_hash: Hash of the attestation payload.
        parent_attestation_hash: Hash of the parent attestation, if any.
        policy_snapshot_hash: Hash of the policy snapshot, if available.
        created_at: Timestamp when the attestation was created.
    """

    step_number: int
    phase: AgentStepPhase
    attestation_hash: str
    created_at: datetime
    parent_attestation_hash: str | None = None
    policy_snapshot_hash: str | None = None


# ---------------------------------------------------------------------------
# Step sub-structures
# ---------------------------------------------------------------------------


@dataclass
class StepPlan:
    """Plan output from an agent step.

    Attributes:
        action: Description of the action to take.
        reasoning: The agent's reasoning for this action.
        tool_name: Name of the tool to invoke, if any.
        tool_input: Arguments for the tool, if any.
    """

    action: str
    reasoning: str
    tool_name: str | None = None
    tool_input: dict[str, object] | None = None


@dataclass
class StepExecution:
    """Execution result from an agent step.

    Attributes:
        tool_name: Name of the tool that was invoked, if any.
        tool_input: Arguments passed to the tool, if any.
        tool_output: Output from the tool, if any.
        child_run_id: Run ID of a child run, if one was created.
        parent_run_id: Run ID of the parent run.
        governance_context: Governance context used during execution.
        error: Error message if execution failed.
    """

    tool_name: str | None = None
    tool_input: dict[str, object] | None = None
    tool_output: object | None = None
    child_run_id: str | None = None
    parent_run_id: str | None = None
    governance_context: GovernanceContext | None = None
    error: str | None = None


@dataclass
class StepObservation:
    """Observation from an agent step execution.

    Attributes:
        result: The observation result.
        is_complete: Whether the agent considers the task complete.
        next_action: Suggested next action, if any.
    """

    result: object
    is_complete: bool
    next_action: str | None = None


# ---------------------------------------------------------------------------
# AgentStep
# ---------------------------------------------------------------------------


@dataclass
class AgentStep:
    """Represents a single step in the agent execution loop.

    Attributes:
        step_number: Step number (1-indexed).
        phase: Current phase of the step.
        input: Input for the step.
        started_at: Step start timestamp.
        plan: Plan output (what the agent decided to do).
        execution: Execution result.
        observation: Observation from the execution.
        ended_at: Step end timestamp.
        duration_ms: Duration of the step in milliseconds.
        attestations: Optional step attestations by phase.
    """

    step_number: int
    phase: AgentStepPhase
    input: object
    started_at: datetime
    plan: StepPlan | None = None
    execution: StepExecution | None = None
    observation: StepObservation | None = None
    ended_at: datetime | None = None
    duration_ms: float | None = None
    attestations: list[AgentStepAttestation] | None = None


# ---------------------------------------------------------------------------
# AgentConfig
# ---------------------------------------------------------------------------


@dataclass
class AgentConfig:
    """Configuration for creating an agent.

    Attributes:
        agent_id: Unique identifier for the agent.
        name: Human-readable name for the agent.
        system_prompt: System prompt for the agent.
        limits: Execution limits.
        context: Governance context for the agent.
        description: Description of the agent's purpose.
        tools: Available tool names the agent can use.
        metadata: Additional metadata.
    """

    agent_id: str
    name: str
    system_prompt: str
    limits: AgentLimits
    context: GovernanceContext
    description: str | None = None
    tools: list[str] | None = None
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# AgentResult
# ---------------------------------------------------------------------------

T = TypeVar("T")


@dataclass
class AgentResult(Generic[T]):
    """Result of an agent execution.

    Attributes:
        run_id: Unique run identifier.
        agent_id: Agent identifier.
        status: Final status of the run.
        output: Output from the agent.
        steps: All steps executed.
        total_steps: Total number of steps executed.
        total_duration_ms: Total execution time in milliseconds.
        started_at: Start timestamp.
        ended_at: End timestamp.
        usage: Aggregated usage information.
        policy: Policy summary.
        error: Error message if failed.
    """

    run_id: str
    agent_id: str
    status: AgentRunStatus
    output: T | None
    steps: list[AgentStep]
    total_steps: int
    total_duration_ms: float
    started_at: datetime
    ended_at: datetime
    usage: UsageInfo | None = None
    policy: PolicySummary | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# AgentHandlers
# ---------------------------------------------------------------------------


@dataclass
class AgentHandlers:
    """Handler functions for the agent runtime.

    Attributes:
        plan: Plan the next action based on current state.
        execute: Execute the planned action.
        observe: Observe the execution result and decide next steps.
        execute_tool: Execute a tool invocation via a tool runner (optional).
    """

    plan: Callable[[object, AgentStep], Awaitable[StepPlan]]
    execute: Callable[[StepPlan, AgentStep], Awaitable[StepExecution]]
    observe: Callable[[StepExecution, AgentStep], Awaitable[StepObservation]]
    execute_tool: Callable[[StepPlan, AgentStep, object], Awaitable[StepExecution]] | None = None


# ---------------------------------------------------------------------------
# AgentRunInput
# ---------------------------------------------------------------------------


@dataclass
class AgentRunInput:
    """Input for starting an agent run.

    Attributes:
        input: Initial input for the agent.
        run_id: Optional run ID (generated if not provided).
        limits: Optional override for limits.
        parent_run_id: Optional parent run ID for lineage propagation.
        on_step: Optional step hook callback.
    """

    input: object
    run_id: str | None = None
    limits: AgentLimits | None = None
    parent_run_id: str | None = None
    on_step: Callable[[AgentStep], Awaitable[None] | None] | None = None
