"""Agent runtime for the Arelis AI SDK.

Ports ``packages/agents/src/agent-runtime.ts`` from the TypeScript SDK.
Implements the governed plan-execute-observe agent loop with policy
checkpointing, attestation chains, and audit event emission.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, TypeVar

from arelis.agents.memory import AgentMemory, InMemoryAgentMemory, MemoryQuery
from arelis.agents.types import (
    AgentConfig,
    AgentHandlers,
    AgentLimits,
    AgentResult,
    AgentRunInput,
    AgentRunStatus,
    AgentStep,
    AgentStepAttestation,
    AgentStepPhase,
    CompiledPolicyMetadata,
)
from arelis.audit.event_builder import (
    create_agent_attestation_created_event,
    create_agent_step_event,
    create_memory_delete_event,
    create_memory_read_event,
    create_memory_write_event,
    create_policy_evaluated_event,
)
from arelis.audit.types import (
    AuditMemoryInfo,
    AuditPolicyDecision,
    HashDataRef,
    ToolCallInfo,
)
from arelis.core.errors import ArelisTimeoutError, PolicyBlockedError
from arelis.core.run_context import generate_run_id
from arelis.policy.types import (
    PolicyDecision,
    PolicyInput,
    PolicyInputCompiled,
    PolicyInputData,
    PolicyResult,
    PolicyResultSummary,
)

if TYPE_CHECKING:
    from arelis.audit.sink import AuditSink
    from arelis.policy.engine import PolicyEngine

__all__ = [
    "AgentRuntime",
    "AgentRuntimeOptions",
    "MaxStepsReachedError",
    "create_agent_runtime",
    "is_max_steps_reached_error",
]

T = TypeVar("T")


# ---------------------------------------------------------------------------
# MaxStepsReachedError
# ---------------------------------------------------------------------------


class MaxStepsReachedError(Exception):
    """Error thrown when max steps limit is reached."""

    def __init__(self, max_steps: int, steps_executed: int) -> None:
        super().__init__(
            f"Agent reached maximum steps limit: {steps_executed}/{max_steps} steps executed"
        )
        self.max_steps: int = max_steps
        self.steps_executed: int = steps_executed


def is_max_steps_reached_error(error: object) -> bool:
    """Check if *error* is a :class:`MaxStepsReachedError`."""
    return isinstance(error, MaxStepsReachedError)


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


@dataclass
class AgentRuntimeOptions:
    """Options for creating an :class:`AgentRuntime`.

    Attributes:
        config: Agent configuration.
        handlers: Handler functions for plan, execute, observe.
        memory: Optional custom memory implementation.
        on_step: Callback for step events.
        policy_engine: Optional policy engine for runtime phase checkpointing.
        audit_sink: Optional audit sink for runtime-level events.
        compiled_policy: Optional compiled policy metadata.
        tool_runner: Optional tool runner for automatic tool execution.
        tool_invoke_options: Optional tool invocation options.
    """

    config: AgentConfig
    handlers: AgentHandlers
    memory: AgentMemory | None = None
    on_step: Callable[[AgentStep], Awaitable[None] | None] | None = None
    policy_engine: object | None = None
    audit_sink: object | None = None
    compiled_policy: object | None = None
    tool_runner: object | None = None
    tool_invoke_options: object | None = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _hash_object(value: object) -> str:
    """Compute a SHA-256 hash of a JSON-serialised value."""
    serialised = json.dumps(value, sort_keys=True, default=str)
    return hashlib.sha256(serialised.encode("utf-8")).hexdigest()


@dataclass
class _StepExecutionResult:
    step: AgentStep
    latest_attestation_hash: str | None = None


# ---------------------------------------------------------------------------
# Default allow-all policy result
# ---------------------------------------------------------------------------

_ALLOW_ALL_RESULT = PolicyResult(
    decisions=[PolicyDecision(effect="allow")],
    summary=PolicyResultSummary(allowed=True),
)


# ---------------------------------------------------------------------------
# AgentRuntime
# ---------------------------------------------------------------------------


class AgentRuntime:
    """Agent runtime that executes the plan-execute-observe loop.

    The runtime respects configured step and time limits, creates
    attestation chains per phase, and stores steps in agent memory.
    Policy checkpoints are evaluated at ``BeforeAgentStep`` before each
    phase, and audit events are emitted for each phase and attestation.
    """

    def __init__(self, options: AgentRuntimeOptions) -> None:
        self._config: AgentConfig = options.config
        self._handlers: AgentHandlers = options.handlers
        self._memory: AgentMemory = options.memory or InMemoryAgentMemory()
        self._on_step: Callable[[AgentStep], Awaitable[None] | None] | None = options.on_step
        self._policy_engine: PolicyEngine | None = options.policy_engine  # type: ignore[assignment]
        self._audit_sink: AuditSink | None = options.audit_sink  # type: ignore[assignment]
        self._compiled_policy: CompiledPolicyMetadata | None = options.compiled_policy  # type: ignore[assignment]
        self._tool_runner: object | None = options.tool_runner
        self._tool_invoke_options: object | None = options.tool_invoke_options

    # -- public accessors ----------------------------------------------------

    def get_config(self) -> AgentConfig:
        """Get the agent configuration."""
        return self._config

    def get_memory(self) -> AgentMemory:
        """Get the agent memory."""
        return self._memory

    # -- governance configuration --------------------------------------------

    def configure_runtime_governance(
        self,
        *,
        policy_engine: object | None = None,
        audit_sink: object | None = None,
        compiled_policy: object | None = None,
    ) -> None:
        """Inject governance dependencies into the runtime.

        Allows external wrappers (for example SDK clients) to inject governance
        runtime dependencies while preserving runtime-level checkpoint semantics.

        Args:
            policy_engine: Policy engine for phase checkpoint evaluation.
            audit_sink: Audit sink for runtime-level audit events.
            compiled_policy: Compiled policy metadata.
        """
        if policy_engine is not None:
            self._policy_engine = policy_engine  # type: ignore[assignment]
        if audit_sink is not None:
            self._audit_sink = audit_sink  # type: ignore[assignment]
        if compiled_policy is not None:
            self._compiled_policy = compiled_policy  # type: ignore[assignment]

    # -- policy helpers ------------------------------------------------------

    def _to_audit_decisions(
        self,
        decisions: list[PolicyDecision],
    ) -> list[AuditPolicyDecision]:
        """Convert policy decisions to audit-friendly representations."""
        result: list[AuditPolicyDecision] = []
        for decision in decisions:
            if decision.effect == "block":
                result.append(
                    AuditPolicyDecision(
                        effect="block",
                        reason=decision.reason,
                        code=getattr(decision, "code", None),
                    )
                )
            elif decision.effect == "transform":
                result.append(AuditPolicyDecision(effect="transform", reason=decision.reason))
            elif decision.effect == "require_approval":
                result.append(
                    AuditPolicyDecision(effect="require_approval", reason=decision.reason)
                )
            else:
                result.append(AuditPolicyDecision(effect="allow"))
        return result

    async def _evaluate_checkpoint(
        self,
        policy_input: PolicyInput,
        parent_run_id: str | None = None,
    ) -> PolicyResult:
        """Evaluate a policy checkpoint.

        If no policy engine is configured, returns an allow-all result.
        Emits a ``policy.evaluated`` audit event when a sink is available.
        Raises :class:`PolicyBlockedError` if the policy blocks.
        """
        if self._policy_engine is None:
            return _ALLOW_ALL_RESULT

        # Prefer evaluateCompiled if compiled metadata is present
        if (
            policy_input.compiled is not None
            and hasattr(self._policy_engine, "evaluate_compiled")
            and self._policy_engine.evaluate_compiled is not None
        ):
            result = await self._policy_engine.evaluate_compiled(policy_input)
        else:
            result = await self._policy_engine.evaluate(policy_input)

        # Emit audit event
        if self._audit_sink is not None:
            event = create_policy_evaluated_event(
                run_id=policy_input.run_id,
                context=policy_input.context,
                parent_run_id=parent_run_id,
                checkpoint=policy_input.checkpoint,
                decisions=self._to_audit_decisions(result.decisions),
                allowed=result.summary.allowed,
                policy_version=result.policy_version,
                policy_snapshot_hash=(
                    self._compiled_policy.snapshot_hash
                    if self._compiled_policy is not None
                    else None
                ),
                policy_compiler_id=(
                    self._compiled_policy.compiler_id if self._compiled_policy is not None else None
                ),
            )
            await self._audit_sink.write(event)

        if not result.summary.allowed:
            raise PolicyBlockedError(
                run_id=policy_input.run_id,
                reason=result.summary.block_reason
                or f"Policy blocked at {policy_input.checkpoint}",
                context=self._config.context,
            )

        return result

    def _build_compiled_input(self) -> PolicyInputCompiled | None:
        """Build compiled policy input from stored metadata."""
        if self._compiled_policy is None:
            return None
        return PolicyInputCompiled(
            compiler_id=self._compiled_policy.compiler_id,
            snapshot_hash=self._compiled_policy.snapshot_hash,
            constraints=self._compiled_policy.constraints,
            disclosure_rules=self._compiled_policy.disclosure_rules,
        )

    def _create_hash_only_ref(self, value: object) -> HashDataRef:
        """Create a hash-only DataRef for a value."""
        return HashDataRef(sha256=_hash_object(value))

    # -- audit helpers -------------------------------------------------------

    async def _emit_agent_phase_event(
        self,
        *,
        run_id: str,
        parent_run_id: str | None,
        step: AgentStep,
        phase: AgentStepPhase,
        policy_result: PolicyResult,
        attestation: AgentStepAttestation,
    ) -> None:
        """Emit agent.step and agent.attestation.created audit events."""
        if self._audit_sink is None:
            return

        tool_calls: list[ToolCallInfo] | None = None
        if phase == "execute" and step.execution is not None and step.execution.tool_name:
            args_ref = (
                self._create_hash_only_ref(step.execution.tool_input)
                if step.execution.tool_input is not None
                else None
            )
            result_ref = (
                self._create_hash_only_ref(step.execution.tool_output)
                if step.execution.tool_output is not None
                else None
            )
            tool_calls = [
                ToolCallInfo(
                    tool_name=step.execution.tool_name,
                    args_ref=args_ref,
                    result_ref=result_ref,
                    success=step.execution.error is None,
                )
            ]

        await self._audit_sink.write(
            create_agent_step_event(
                run_id=run_id,
                context=self._config.context,
                parent_run_id=parent_run_id,
                step_number=step.step_number,
                step_type=phase,
                tool_calls=tool_calls,
                attestation_hash=attestation.attestation_hash,
                policy={
                    "checkpoint": "BeforeAgentStep",
                    "allowed": policy_result.summary.allowed,
                    "decision_effects": [d.effect for d in policy_result.decisions],
                    "policy_snapshot_hash": (
                        self._compiled_policy.snapshot_hash
                        if self._compiled_policy is not None
                        else None
                    ),
                },
            )
        )

        await self._audit_sink.write(
            create_agent_attestation_created_event(
                run_id=run_id,
                context=self._config.context,
                parent_run_id=parent_run_id,
                step_number=step.step_number,
                step_type=phase,
                policy_snapshot_hash=(
                    self._compiled_policy.snapshot_hash
                    if self._compiled_policy is not None
                    else None
                ),
                attestation_hash=attestation.attestation_hash,
            )
        )

    # -- governed memory operations ------------------------------------------

    async def _governed_memory_read(
        self,
        run_id: str,
        step_number: int,
        parent_run_id: str | None = None,
    ) -> None:
        """Read agent memory with policy checkpoint and audit event."""
        policy_input = PolicyInput(
            checkpoint="BeforeAgentStep",
            context=self._config.context,
            run_id=run_id,
            compiled=self._build_compiled_input(),
            data=PolicyInputData(
                operation="agent.memory.read",
                step_number=step_number,
                agent_phase="plan",
            ),
        )

        await self._evaluate_checkpoint(policy_input, parent_run_id)
        await self._memory.retrieve(MemoryQuery(type="step", limit=5, order_by="desc"))

        if self._audit_sink is not None:
            await self._audit_sink.write(
                create_memory_read_event(
                    run_id=run_id,
                    context=self._config.context,
                    parent_run_id=parent_run_id,
                    memory=AuditMemoryInfo(scope="agent.runtime", key=f"steps:{step_number}"),
                )
            )

    async def _governed_memory_write(
        self,
        run_id: str,
        step: AgentStep,
        parent_run_id: str | None = None,
    ) -> None:
        """Write agent step to memory with policy checkpoint and audit event."""
        policy_input = PolicyInput(
            checkpoint="BeforePersist",
            context=self._config.context,
            run_id=run_id,
            compiled=self._build_compiled_input(),
            data=PolicyInputData(
                operation="agent.memory.write",
                step_number=step.step_number,
                agent_phase=step.phase,
            ),
        )

        await self._evaluate_checkpoint(policy_input, parent_run_id)
        await self._memory.store_step(step)

        if self._audit_sink is not None:
            await self._audit_sink.write(
                create_memory_write_event(
                    run_id=run_id,
                    context=self._config.context,
                    parent_run_id=parent_run_id,
                    memory=AuditMemoryInfo(scope="agent.runtime", key=f"step:{step.step_number}"),
                    value_ref=self._create_hash_only_ref(step),
                )
            )

    async def _governed_memory_delete(
        self,
        run_id: str,
        key: str,
        parent_run_id: str | None = None,
    ) -> None:
        """Delete agent memory with policy checkpoint and audit event."""
        policy_input = PolicyInput(
            checkpoint="BeforePersist",
            context=self._config.context,
            run_id=run_id,
            compiled=self._build_compiled_input(),
            data=PolicyInputData(
                operation="agent.memory.delete",
                input={"key": key},
            ),
        )

        await self._evaluate_checkpoint(policy_input, parent_run_id)
        await self._memory.clear(key)

        if self._audit_sink is not None:
            await self._audit_sink.write(
                create_memory_delete_event(
                    run_id=run_id,
                    context=self._config.context,
                    parent_run_id=parent_run_id,
                    memory=AuditMemoryInfo(scope="agent.runtime", key=key),
                )
            )

    # -- public run ----------------------------------------------------------

    async def run(self, run_input: AgentRunInput) -> AgentResult[object]:
        """Run the agent with the given input.

        Implements the governed agent loop: for each step, the runtime
        executes the plan-execute-observe cycle, stores the step in
        memory, and checks completion and limits.

        Args:
            run_input: Input for the agent run.

        Returns:
            The agent result containing all steps and final output.
        """
        run_id = run_input.run_id or generate_run_id()

        # Merge limits: run_input overrides config
        limits = AgentLimits(
            max_steps=(
                run_input.limits.max_steps
                if run_input.limits is not None
                else self._config.limits.max_steps
            ),
            max_time_ms=(
                run_input.limits.max_time_ms
                if run_input.limits is not None
                else self._config.limits.max_time_ms
            ),
        )

        started_at = datetime.now(timezone.utc)
        steps: list[AgentStep] = []
        current_input: object = run_input.input
        status: AgentRunStatus = "running"
        output: object | None = None
        error: str | None = None

        start_time_ms = time.monotonic() * 1000
        attestation_cursor: str | None = None

        try:
            # Clear scratch memory (governed)
            await self._governed_memory_delete(run_id, "scratch", run_input.parent_run_id)

            for step_number in range(1, limits.max_steps + 1):
                # Check time limit before each step
                elapsed_ms = time.monotonic() * 1000 - start_time_ms
                if elapsed_ms >= limits.max_time_ms:
                    raise ArelisTimeoutError(
                        run_id=run_id,
                        elapsed_ms=elapsed_ms,
                        limit_ms=limits.max_time_ms,
                        operation="Agent execution",
                        context=self._config.context,
                    )

                # Read recent memory (governed)
                await self._governed_memory_read(run_id, step_number, run_input.parent_run_id)

                result = await self._execute_step(
                    step_number=step_number,
                    input_data=current_input,
                    remaining_time_ms=limits.max_time_ms - elapsed_ms,
                    run_id=run_id,
                    parent_run_id=run_input.parent_run_id,
                    parent_attestation_hash=attestation_cursor,
                )
                step = result.step
                steps.append(step)
                attestation_cursor = result.latest_attestation_hash or attestation_cursor

                # Store step in memory (governed)
                await self._governed_memory_write(run_id, step, run_input.parent_run_id)

                # Notify step hooks
                if self._on_step is not None:
                    maybe_awaitable = self._on_step(step)
                    if maybe_awaitable is not None:
                        await maybe_awaitable
                if run_input.on_step is not None:
                    maybe_awaitable = run_input.on_step(step)
                    if maybe_awaitable is not None:
                        await maybe_awaitable

                # Check if the agent is done
                if step.observation is not None and step.observation.is_complete:
                    status = "completed"
                    output = step.observation.result
                    break

                # Update input for next step
                if step.observation is not None:
                    current_input = step.observation.result
                elif step.execution is not None:
                    current_input = step.execution.tool_output
                else:
                    current_input = None

                # Check if we've hit max steps
                if step_number == limits.max_steps:
                    status = "max_steps_reached"
                    error = f"Maximum steps limit reached: {limits.max_steps}"

            # Clear scratch memory (governed)
            await self._governed_memory_delete(run_id, "scratch", run_input.parent_run_id)

        except ArelisTimeoutError as err:
            status = "timeout"
            error = str(err)
        except MaxStepsReachedError as err:
            status = "max_steps_reached"
            error = str(err)
        except PolicyBlockedError as err:
            status = "failed"
            error = str(err)
        except Exception as err:
            status = "failed"
            error = str(err)

        ended_at = datetime.now(timezone.utc)
        total_duration_ms = (ended_at - started_at).total_seconds() * 1000

        return AgentResult(
            run_id=run_id,
            agent_id=self._config.agent_id,
            status=status,
            output=output,
            steps=steps,
            total_steps=len(steps),
            total_duration_ms=total_duration_ms,
            error=error,
            started_at=started_at,
            ended_at=ended_at,
        )

    # -- private step execution ----------------------------------------------

    async def _execute_step(
        self,
        step_number: int,
        input_data: object,
        remaining_time_ms: float,
        run_id: str,
        parent_run_id: str | None,
        parent_attestation_hash: str | None,
    ) -> _StepExecutionResult:
        """Execute a single step (plan -> execute -> observe).

        Each phase is preceded by a ``BeforeAgentStep`` policy checkpoint.
        After each phase, an attestation is created and audit events are emitted.
        """
        started_at = datetime.now(timezone.utc)
        step = AgentStep(
            step_number=step_number,
            phase="plan",
            input=input_data,
            started_at=started_at,
            attestations=[],
        )

        attestation_cursor = parent_attestation_hash
        step_start_ms = time.monotonic() * 1000

        # -- Plan phase --
        plan_policy_result = await self._evaluate_checkpoint(
            PolicyInput(
                checkpoint="BeforeAgentStep",
                context=self._config.context,
                run_id=run_id,
                compiled=self._build_compiled_input(),
                data=PolicyInputData(
                    operation="agent.step.plan",
                    step_number=step_number,
                    agent_phase="plan",
                    input=input_data,
                ),
            ),
            parent_run_id,
        )

        step.phase = "plan"
        step.plan = await self._execute_with_timeout(
            self._handlers.plan(input_data, step),
            remaining_time_ms,
            run_id,
            "Plan phase",
        )

        plan_attestation = self._create_attestation(
            run_id=run_id,
            step_number=step_number,
            phase="plan",
            parent_attestation_hash=attestation_cursor,
        )
        attestation_cursor = plan_attestation.attestation_hash
        if step.attestations is not None:
            step.attestations.append(plan_attestation)
        await self._emit_agent_phase_event(
            run_id=run_id,
            parent_run_id=parent_run_id,
            step=step,
            phase="plan",
            policy_result=plan_policy_result,
            attestation=plan_attestation,
        )

        # -- Execute phase --
        execute_policy_result = await self._evaluate_checkpoint(
            PolicyInput(
                checkpoint="BeforeAgentStep",
                context=self._config.context,
                run_id=run_id,
                compiled=self._build_compiled_input(),
                data=PolicyInputData(
                    operation="agent.step.execute",
                    step_number=step_number,
                    agent_phase="execute",
                    input=step.plan,
                ),
            ),
            parent_run_id,
        )

        step.phase = "execute"
        execute_remaining = remaining_time_ms - (time.monotonic() * 1000 - step_start_ms)
        plan = step.plan

        if plan is not None and plan.tool_name and self._handlers.execute_tool is not None:
            # Tool execution path with custom handler
            step.execution = await self._execute_with_timeout(
                self._handlers.execute_tool(plan, step, {}),
                execute_remaining,
                run_id,
                "Execute tool",
            )
        elif plan is not None:
            step.execution = await self._execute_with_timeout(
                self._handlers.execute(plan, step),
                execute_remaining,
                run_id,
                "Execute phase",
            )

        execute_attestation = self._create_attestation(
            run_id=run_id,
            step_number=step_number,
            phase="execute",
            parent_attestation_hash=attestation_cursor,
        )
        attestation_cursor = execute_attestation.attestation_hash
        if step.attestations is not None:
            step.attestations.append(execute_attestation)
        await self._emit_agent_phase_event(
            run_id=run_id,
            parent_run_id=parent_run_id,
            step=step,
            phase="execute",
            policy_result=execute_policy_result,
            attestation=execute_attestation,
        )

        # -- Observe phase --
        observe_policy_result = await self._evaluate_checkpoint(
            PolicyInput(
                checkpoint="BeforeAgentStep",
                context=self._config.context,
                run_id=run_id,
                compiled=self._build_compiled_input(),
                data=PolicyInputData(
                    operation="agent.step.observe",
                    step_number=step_number,
                    agent_phase="observe",
                    input=step.execution,
                ),
            ),
            parent_run_id,
        )

        step.phase = "observe"
        observe_remaining = remaining_time_ms - (time.monotonic() * 1000 - step_start_ms)
        if step.execution is not None:
            step.observation = await self._execute_with_timeout(
                self._handlers.observe(step.execution, step),
                observe_remaining,
                run_id,
                "Observe phase",
            )

        observe_attestation = self._create_attestation(
            run_id=run_id,
            step_number=step_number,
            phase="observe",
            parent_attestation_hash=attestation_cursor,
        )
        attestation_cursor = observe_attestation.attestation_hash
        if step.attestations is not None:
            step.attestations.append(observe_attestation)
        await self._emit_agent_phase_event(
            run_id=run_id,
            parent_run_id=parent_run_id,
            step=step,
            phase="observe",
            policy_result=observe_policy_result,
            attestation=observe_attestation,
        )

        step.ended_at = datetime.now(timezone.utc)
        step.duration_ms = (step.ended_at - step.started_at).total_seconds() * 1000

        return _StepExecutionResult(
            step=step,
            latest_attestation_hash=attestation_cursor,
        )

    # -- helpers -------------------------------------------------------------

    def _create_attestation(
        self,
        *,
        run_id: str,
        step_number: int,
        phase: AgentStepPhase,
        parent_attestation_hash: str | None,
    ) -> AgentStepAttestation:
        """Create an attestation for a step phase."""
        now = datetime.now(timezone.utc)
        payload = {
            "runId": run_id,
            "stepNumber": step_number,
            "phase": phase,
            "parentAttestationHash": parent_attestation_hash,
            "policySnapshotHash": (
                self._compiled_policy.snapshot_hash if self._compiled_policy is not None else None
            ),
            "createdAt": now.isoformat(),
        }

        return AgentStepAttestation(
            step_number=step_number,
            phase=phase,
            attestation_hash=_hash_object(payload),
            parent_attestation_hash=parent_attestation_hash,
            policy_snapshot_hash=(
                self._compiled_policy.snapshot_hash if self._compiled_policy is not None else None
            ),
            created_at=now,
        )

    async def _execute_with_timeout(
        self,
        coro: Awaitable[T],
        timeout_ms: float,
        run_id: str,
        operation: str,
    ) -> T:
        """Execute an awaitable with a timeout."""
        if timeout_ms <= 0:
            raise ArelisTimeoutError(
                run_id=run_id,
                elapsed_ms=self._config.limits.max_time_ms,
                limit_ms=self._config.limits.max_time_ms,
                operation=operation,
                context=self._config.context,
            )

        try:
            return await asyncio.wait_for(
                coro,
                timeout=timeout_ms / 1000.0,
            )
        except asyncio.TimeoutError:
            raise ArelisTimeoutError(
                run_id=run_id,
                elapsed_ms=timeout_ms,
                limit_ms=timeout_ms,
                operation=operation,
                context=self._config.context,
            ) from None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_agent_runtime(options: AgentRuntimeOptions) -> AgentRuntime:
    """Factory function to create an agent runtime."""
    return AgentRuntime(options)
