"""Agent runtime module for the Arelis AI SDK.

Provides the agent execution loop with plan-execute-observe phases,
agent memory, attestation chains, and configurable limits.
"""

from __future__ import annotations

from arelis.agents.memory import (
    AgentMemory,
    InMemoryAgentMemory,
    MemoryEntry,
    MemoryQuery,
    create_in_memory_agent_memory,
)
from arelis.agents.runtime import (
    AgentRuntime,
    AgentRuntimeOptions,
    MaxStepsReachedError,
    create_agent_runtime,
    is_max_steps_reached_error,
)
from arelis.agents.types import (
    AgentConfig,
    AgentHandlers,
    AgentLimits,
    AgentResult,
    AgentRunInput,
    AgentRunStatus,
    AgentStep,
    AgentStepAttestation,
    AgentStepPhase,
    CompiledPolicyMetadata,
    StepExecution,
    StepObservation,
    StepPlan,
)

__all__ = [
    "AgentConfig",
    "AgentHandlers",
    "AgentLimits",
    "AgentMemory",
    "AgentResult",
    "AgentRunInput",
    "AgentRunStatus",
    "AgentRuntime",
    "AgentRuntimeOptions",
    "AgentStep",
    "AgentStepAttestation",
    "AgentStepPhase",
    "CompiledPolicyMetadata",
    "InMemoryAgentMemory",
    "MaxStepsReachedError",
    "MemoryEntry",
    "MemoryQuery",
    "StepExecution",
    "StepObservation",
    "StepPlan",
    "create_agent_runtime",
    "create_in_memory_agent_memory",
    "is_max_steps_reached_error",
]
