"""Agent memory for the Arelis AI SDK.

Ports ``packages/agents/src/agent-memory.ts`` from the TypeScript SDK.
Provides the :class:`AgentMemory` protocol and an in-memory implementation.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Literal, Protocol, runtime_checkable

from arelis.agents.types import AgentStep

__all__ = [
    "AgentMemory",
    "InMemoryAgentMemory",
    "MemoryEntry",
    "MemoryQuery",
    "create_in_memory_agent_memory",
]


# ---------------------------------------------------------------------------
# MemoryEntry
# ---------------------------------------------------------------------------


@dataclass
class MemoryEntry:
    """Memory entry stored in agent memory.

    Attributes:
        id: Unique identifier for the memory entry.
        type: Type of memory (e.g., 'step', 'context', 'fact').
        content: Content of the memory entry.
        created_at: Timestamp when the entry was created.
        metadata: Optional metadata.
    """

    id: str
    type: str
    content: object
    created_at: datetime
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# MemoryQuery
# ---------------------------------------------------------------------------


@dataclass
class MemoryQuery:
    """Query options for retrieving memories.

    Attributes:
        type: Filter by type.
        limit: Limit number of results.
        metadata: Filter by metadata key-value pairs.
        order_by: Order by creation time.
    """

    type: str | None = None
    limit: int | None = None
    metadata: dict[str, object] | None = None
    order_by: Literal["asc", "desc"] = "asc"


# ---------------------------------------------------------------------------
# AgentMemory protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class AgentMemory(Protocol):
    """Interface for agent memory storage."""

    async def store(
        self,
        *,
        type: str,
        content: object,
        metadata: dict[str, object] | None = None,
    ) -> MemoryEntry:
        """Store a new memory entry."""
        ...

    async def retrieve(self, query: MemoryQuery | None = None) -> list[MemoryEntry]:
        """Retrieve memories matching the query."""
        ...

    async def retrieve_by_id(self, id: str) -> MemoryEntry | None:
        """Retrieve a specific memory entry by ID."""
        ...

    async def clear(self, type: str | None = None) -> int:
        """Clear all memories or memories matching a type."""
        ...

    async def count(self, type: str | None = None) -> int:
        """Get the total count of memories."""
        ...

    async def store_step(self, step: AgentStep) -> MemoryEntry:
        """Store an agent step as a memory entry."""
        ...

    async def retrieve_steps(self) -> list[AgentStep]:
        """Retrieve all steps for the current session."""
        ...


# ---------------------------------------------------------------------------
# Internal entry with insertion order
# ---------------------------------------------------------------------------


@dataclass
class _InternalMemoryEntry:
    """Internal memory entry with insertion order for stable sorting."""

    entry: MemoryEntry
    insertion_order: int


# ---------------------------------------------------------------------------
# InMemoryAgentMemory
# ---------------------------------------------------------------------------


class InMemoryAgentMemory:
    """In-memory implementation of :class:`AgentMemory`.

    Stores all entries in a dictionary keyed by entry ID.
    Suitable for testing and single-session agent runs.
    """

    def __init__(self) -> None:
        self._entries: dict[str, _InternalMemoryEntry] = {}
        self._id_counter: int = 0
        self._insertion_counter: int = 0

    def _generate_id(self) -> str:
        self._id_counter += 1
        return f"mem_{self._id_counter:06d}"

    async def store(
        self,
        *,
        type: str,
        content: object,
        metadata: dict[str, object] | None = None,
    ) -> MemoryEntry:
        """Store a new memory entry."""
        entry_id = self._generate_id()
        self._insertion_counter += 1
        entry = MemoryEntry(
            id=entry_id,
            type=type,
            content=content,
            created_at=datetime.now(timezone.utc),
            metadata=metadata,
        )
        self._entries[entry_id] = _InternalMemoryEntry(
            entry=entry,
            insertion_order=self._insertion_counter,
        )
        return entry

    async def retrieve(self, query: MemoryQuery | None = None) -> list[MemoryEntry]:
        """Retrieve memories matching the query."""
        results = list(self._entries.values())

        # Filter by type
        if query is not None and query.type is not None:
            results = [r for r in results if r.entry.type == query.type]

        # Filter by metadata
        if query is not None and query.metadata is not None:
            filter_meta = query.metadata

            def _matches(r: _InternalMemoryEntry) -> bool:
                if r.entry.metadata is None:
                    return False
                return all(r.entry.metadata.get(k) == v for k, v in filter_meta.items())

            results = [r for r in results if _matches(r)]

        # Sort by creation time with insertion order as tiebreaker
        order_by = query.order_by if query is not None else "asc"
        reverse = order_by == "desc"

        results.sort(
            key=lambda r: (r.entry.created_at, r.insertion_order),
            reverse=reverse,
        )

        # Apply limit
        if query is not None and query.limit is not None and query.limit > 0:
            results = results[: query.limit]

        return [r.entry for r in results]

    async def retrieve_by_id(self, id: str) -> MemoryEntry | None:
        """Retrieve a specific memory entry by ID."""
        internal = self._entries.get(id)
        if internal is None:
            return None
        return internal.entry

    async def clear(self, type: str | None = None) -> int:
        """Clear all memories or memories matching a type."""
        if type is None:
            count = len(self._entries)
            self._entries.clear()
            return count

        to_remove = [
            entry_id for entry_id, internal in self._entries.items() if internal.entry.type == type
        ]
        for entry_id in to_remove:
            del self._entries[entry_id]
        return len(to_remove)

    async def count(self, type: str | None = None) -> int:
        """Get the total count of memories."""
        if type is None:
            return len(self._entries)

        return sum(1 for internal in self._entries.values() if internal.entry.type == type)

    async def store_step(self, step: AgentStep) -> MemoryEntry:
        """Store an agent step as a memory entry."""
        return await self.store(
            type="step",
            content=step,
            metadata={
                "stepNumber": step.step_number,
                "phase": step.phase,
            },
        )

    async def retrieve_steps(self) -> list[AgentStep]:
        """Retrieve all steps for the current session."""
        entries = await self.retrieve(MemoryQuery(type="step", order_by="asc"))
        return [entry.content for entry in entries]  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_in_memory_agent_memory() -> InMemoryAgentMemory:
    """Factory function to create an in-memory agent memory."""
    return InMemoryAgentMemory()
