"""MCP (Model Context Protocol) module for the Arelis AI SDK.

Provides MCP server registration, tool discovery, transport management,
and tool invocation with governance checks.
Ports functionality from the TypeScript SDK's ``packages/mcp/src/``.
"""

from __future__ import annotations

# Discovery
from arelis.mcp.discovery import (
    ToolDiscoveryFullResult,
    ToolDiscoveryOptions,
    discover_tools,
    list_server_tools,
    unregister_server_tools,
)

# Registry
from arelis.mcp.registry import (
    MCPRegistry,
    RegisteredMCPServer,
    create_mcp_registry,
)

# Transports
from arelis.mcp.transports import (
    HttpMCPTransport,
    MCPTransport,
    MockMCPTransport,
    MockMCPTransportOptions,
    MockToolHandler,
    StdioMCPTransport,
    StdioTransportOptions,
    create_http_mcp_transport,
    create_mock_mcp_transport,
    create_stdio_mcp_transport,
    create_test_mcp_transport,
)

# Types
from arelis.mcp.types import (
    MCPAuthConfig,
    MCPAuthConfigApiKey,
    MCPAuthConfigBearer,
    MCPAuthConfigNone,
    MCPAuthType,
    MCPContext,
    MCPGovernanceConfig,
    MCPLifecycleEmitter,
    MCPProducerEvent,
    MCPProducerEventType,
    MCPRegistryOptions,
    MCPServerDescriptor,
    MCPToolDiscoveryResult,
    MCPToolInvokeRequest,
    MCPToolInvokeResponse,
    MCPToolSchema,
    MCPTransportConfig,
    MCPTransportConfigHttp,
    MCPTransportConfigStdio,
    MCPTransportType,
    get_mcp_tool_name,
    parse_mcp_tool_name,
    to_json_schema,
)

__all__ = [
    # Types
    "MCPAuthConfig",
    "MCPAuthConfigApiKey",
    "MCPAuthConfigBearer",
    "MCPAuthConfigNone",
    "MCPAuthType",
    "MCPContext",
    "MCPGovernanceConfig",
    "MCPLifecycleEmitter",
    "MCPProducerEvent",
    "MCPProducerEventType",
    "MCPRegistryOptions",
    "MCPServerDescriptor",
    "MCPToolDiscoveryResult",
    "MCPToolInvokeRequest",
    "MCPToolInvokeResponse",
    "MCPToolSchema",
    "MCPTransport",
    "MCPTransportConfig",
    "MCPTransportConfigHttp",
    "MCPTransportConfigStdio",
    "MCPTransportType",
    "get_mcp_tool_name",
    "parse_mcp_tool_name",
    "to_json_schema",
    # Registry
    "MCPRegistry",
    "RegisteredMCPServer",
    "create_mcp_registry",
    # Discovery
    "ToolDiscoveryFullResult",
    "ToolDiscoveryOptions",
    "discover_tools",
    "list_server_tools",
    "unregister_server_tools",
    # Transports
    "HttpMCPTransport",
    "MockMCPTransport",
    "MockMCPTransportOptions",
    "MockToolHandler",
    "StdioMCPTransport",
    "StdioTransportOptions",
    "create_http_mcp_transport",
    "create_mock_mcp_transport",
    "create_stdio_mcp_transport",
    "create_test_mcp_transport",
]
