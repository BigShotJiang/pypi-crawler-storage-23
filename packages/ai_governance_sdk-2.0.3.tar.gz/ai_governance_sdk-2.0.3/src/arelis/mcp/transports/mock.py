"""Mock MCP transport for the Arelis AI SDK.

Provides a configurable mock transport for testing MCP tool discovery
and invocation without a real MCP server.
Ports ``MockMCPTransport`` from ``packages/mcp/src/transports/mock.ts``.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass

from arelis.mcp.types import MCPToolInvokeResponse, MCPToolSchema

__all__ = [
    "MockMCPTransport",
    "MockMCPTransportOptions",
    "MockToolHandler",
    "create_mock_mcp_transport",
    "create_test_mcp_transport",
]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

MockToolHandler = Callable[[str, dict[str, object]], Awaitable[object]]
"""Mock tool handler: receives tool name and args, returns result."""


# ---------------------------------------------------------------------------
# Default handler
# ---------------------------------------------------------------------------


async def _default_handler(name: str, args: dict[str, object]) -> object:
    """Default mock tool handler that echoes input."""
    from datetime import datetime, timezone

    return {
        "tool": name,
        "input": args,
        "output": f"Mock response from {name}",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


@dataclass
class MockMCPTransportOptions:
    """Options for the mock MCP transport."""

    tools: list[MCPToolSchema] | None = None
    handler: MockToolHandler | None = None
    connect_delay: int = 0
    """Simulate connection delay in ms."""

    invoke_delay: int = 0
    """Simulate invocation delay in ms."""

    simulate_connection_failure: bool = False
    """Whether to simulate connection failure."""


# ---------------------------------------------------------------------------
# MockMCPTransport
# ---------------------------------------------------------------------------


class MockMCPTransport:
    """Mock MCP transport for testing.

    Provides configurable responses for tool listing and invocation
    without requiring a real MCP server process.
    """

    def __init__(self, options: MockMCPTransportOptions | None = None) -> None:
        opts = options or MockMCPTransportOptions()
        self._tools: list[MCPToolSchema] = list(opts.tools) if opts.tools else []
        self._handler: MockToolHandler = opts.handler or _default_handler
        self._connect_delay: int = opts.connect_delay
        self._invoke_delay: int = opts.invoke_delay
        self._simulate_connection_failure: bool = opts.simulate_connection_failure
        self._connected: bool = False

    async def connect(self) -> None:
        """Connect to the mock MCP server."""
        if self._connect_delay > 0:
            await asyncio.sleep(self._connect_delay / 1000.0)

        if self._simulate_connection_failure:
            raise RuntimeError("Mock connection failure")

        self._connected = True

    async def disconnect(self) -> None:
        """Disconnect from the mock MCP server."""
        self._connected = False

    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected

    async def list_tools(self) -> list[MCPToolSchema]:
        """List available mock tools."""
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")
        return list(self._tools)

    async def invoke_tool(
        self,
        name: str,
        args: dict[str, object],
    ) -> MCPToolInvokeResponse:
        """Invoke a mock tool."""
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")

        # Check if tool exists
        tool = next((t for t in self._tools if t.name == name), None)
        if tool is None:
            return MCPToolInvokeResponse(
                content={"error": f'Tool "{name}" not found'},
                is_error=True,
            )

        if self._invoke_delay > 0:
            await asyncio.sleep(self._invoke_delay / 1000.0)

        try:
            result = await self._handler(name, args)
            return MCPToolInvokeResponse(content=result, is_error=False)
        except Exception as exc:
            return MCPToolInvokeResponse(
                content={"error": str(exc)},
                is_error=True,
            )

    # -- Extra helpers for tests --------------------------------------------

    def add_tool(self, tool: MCPToolSchema) -> None:
        """Add a tool to the mock transport."""
        self._tools.append(tool)

    def set_handler(self, handler: MockToolHandler) -> None:
        """Set the tool handler."""
        self._handler = handler


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def create_mock_mcp_transport(
    options: MockMCPTransportOptions | None = None,
) -> MockMCPTransport:
    """Create a mock MCP transport."""
    return MockMCPTransport(options)


def create_test_mcp_transport() -> MockMCPTransport:
    """Create a mock MCP transport with common test tools."""
    return MockMCPTransport(
        MockMCPTransportOptions(
            tools=[
                MCPToolSchema(
                    name="lookup",
                    description="Look up information",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Search query"},
                        },
                        "required": ["query"],
                    },
                ),
                MCPToolSchema(
                    name="create",
                    description="Create a resource",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Resource name"},
                            "data": {"type": "object", "description": "Resource data"},
                        },
                        "required": ["name"],
                    },
                ),
                MCPToolSchema(
                    name="update",
                    description="Update a resource",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "id": {"type": "string", "description": "Resource ID"},
                            "data": {"type": "object", "description": "Updated data"},
                        },
                        "required": ["id"],
                    },
                ),
            ],
        )
    )
