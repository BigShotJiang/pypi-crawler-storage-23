"""Stdio MCP transport for the Arelis AI SDK.

Communicates with an MCP server process via stdin/stdout using JSON-RPC 2.0.
Ports ``StdioMCPTransport`` from ``packages/mcp/src/transports/stdio.ts``.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import random
from dataclasses import dataclass

from arelis.mcp.types import MCPToolInvokeResponse, MCPToolSchema, MCPTransportConfigStdio

__all__ = [
    "StdioMCPTransport",
    "StdioTransportOptions",
    "create_stdio_mcp_transport",
]

# ---------------------------------------------------------------------------
# JSON-RPC 2.0 constants
# ---------------------------------------------------------------------------

MCP_PROTOCOL_VERSION = "2024-11-05"

MCP_METHODS_INITIALIZE = "initialize"
MCP_METHODS_SHUTDOWN = "shutdown"
MCP_METHODS_TOOLS_LIST = "tools/list"
MCP_METHODS_TOOLS_CALL = "tools/call"

# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


@dataclass
class StdioTransportOptions:
    """Options for the stdio transport."""

    connection_timeout: int = 30000
    """Connection timeout in milliseconds."""

    auto_reconnect: bool = True
    """Auto-reconnect on unexpected disconnect."""

    max_reconnect_attempts: int = 3
    """Maximum reconnection attempts."""

    base_delay_ms: int = 1000
    """Base delay for exponential backoff in ms."""

    max_delay_ms: int = 30000
    """Maximum delay for exponential backoff in ms."""

    max_retries: int = 2
    """Maximum retries for tool invocations."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _calculate_backoff_delay(attempt: int, base_delay_ms: int, max_delay_ms: int) -> int:
    """Calculate backoff delay with exponential growth and jitter."""
    exponential_delay = base_delay_ms * (2**attempt)
    capped_delay = min(exponential_delay, max_delay_ms)
    jitter = capped_delay * 0.25 * random.random()
    return int(capped_delay + jitter)


def _create_json_rpc_request(
    request_id: int,
    method: str,
    params: dict[str, object] | None = None,
) -> dict[str, object]:
    """Create a JSON-RPC 2.0 request."""
    request: dict[str, object] = {
        "jsonrpc": "2.0",
        "id": request_id,
        "method": method,
    }
    if params is not None:
        request["params"] = params
    return request


def _create_json_rpc_notification(
    method: str,
    params: dict[str, object] | None = None,
) -> dict[str, object]:
    """Create a JSON-RPC 2.0 notification (no response expected)."""
    notification: dict[str, object] = {
        "jsonrpc": "2.0",
        "method": method,
    }
    if params is not None:
        notification["params"] = params
    return notification


def _serialize_json_rpc_message(message: dict[str, object]) -> bytes:
    """Serialize a JSON-RPC message for transmission (newline-delimited)."""
    return (json.dumps(message) + "\n").encode("utf-8")


def _parse_json_rpc_response(data: str) -> dict[str, object]:
    """Parse a JSON-RPC 2.0 response from a string."""
    parsed = json.loads(data)
    if not isinstance(parsed, dict):
        raise ValueError("JSON-RPC response must be an object")
    if parsed.get("jsonrpc") != "2.0":
        raise ValueError('JSON-RPC response must have jsonrpc: "2.0"')
    if not isinstance(parsed.get("id"), int):
        raise ValueError("JSON-RPC response must have a numeric id")
    return parsed


def _is_json_rpc_error(response: dict[str, object]) -> bool:
    """Check if a JSON-RPC response is an error."""
    return "error" in response and response["error"] is not None


def _is_transient_error(error: Exception) -> bool:
    """Determine if an error is transient and should be retried."""
    message = str(error).lower()
    transient_patterns = [
        "econnreset",
        "econnrefused",
        "etimedout",
        "epipe",
        "enotfound",
        "enetunreach",
        "ehostunreach",
        "connection",
        "timeout",
        "socket hang up",
        "network",
        "aborted",
    ]
    return any(pattern in message for pattern in transient_patterns)


# ---------------------------------------------------------------------------
# StdioMCPTransport
# ---------------------------------------------------------------------------


class StdioMCPTransport:
    """Stdio MCP transport.

    Spawns a child process and communicates via JSON-RPC 2.0 over stdin/stdout.
    Supports automatic reconnection and retry logic for transient failures.
    """

    def __init__(
        self,
        config: MCPTransportConfigStdio,
        options: StdioTransportOptions | None = None,
    ) -> None:
        self._config = config
        self._options = options or StdioTransportOptions()
        self._process: asyncio.subprocess.Process | None = None
        self._connected = False
        self._connecting = False
        self._next_id = 1
        self._pending: dict[int, asyncio.Future[dict[str, object]]] = {}
        self._buffer = ""
        self._reconnect_attempts = 0
        self._server_capabilities: dict[str, object] = {}
        self._reader_task: asyncio.Task[None] | None = None

    async def connect(self) -> None:
        """Connect to the MCP server by spawning the process and initializing."""
        if self._connected:
            return
        if self._connecting:
            raise RuntimeError("Connection already in progress")

        self._connecting = True
        try:
            await self._spawn_process()
            await self._initialize()
            self._connected = True
            self._reconnect_attempts = 0
        finally:
            self._connecting = False

    async def disconnect(self) -> None:
        """Disconnect from the MCP server."""
        if not self._connected and not self._process:
            return

        # Send shutdown notification
        if self._process and self._process.stdin:
            try:
                notification = _create_json_rpc_notification(MCP_METHODS_SHUTDOWN)
                self._process.stdin.write(_serialize_json_rpc_message(notification))
                await self._process.stdin.drain()
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass

        self._cleanup()

    def is_connected(self) -> bool:
        """Check if connected to the MCP server."""
        return self._connected

    async def list_tools(self) -> list[MCPToolSchema]:
        """List available tools from the MCP server."""
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")

        response = await self._send_request(MCP_METHODS_TOOLS_LIST)

        if _is_json_rpc_error(response):
            error = response.get("error", {})
            msg = error.get("message", "Unknown error") if isinstance(error, dict) else str(error)
            raise RuntimeError(f"Failed to list tools: {msg}")

        result = response.get("result")
        raw_tools = result.get("tools", []) if isinstance(result, dict) else []

        tools: list[MCPToolSchema] = []
        if isinstance(raw_tools, list):
            for t in raw_tools:
                if isinstance(t, dict):
                    tools.append(
                        MCPToolSchema(
                            name=str(t.get("name", "")),
                            description=t.get("description"),
                            input_schema=t.get("inputSchema"),
                        )
                    )
        return tools

    async def invoke_tool(
        self,
        name: str,
        args: dict[str, object],
    ) -> MCPToolInvokeResponse:
        """Invoke a tool on the MCP server with retry logic."""
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")

        last_error: Exception | None = None

        for attempt in range(self._options.max_retries + 1):
            try:
                return await self._invoke_once(name, args)
            except Exception as exc:
                last_error = exc
                if not _is_transient_error(exc):
                    raise
                if attempt < self._options.max_retries:
                    delay = _calculate_backoff_delay(
                        attempt,
                        self._options.base_delay_ms,
                        self._options.max_delay_ms,
                    )
                    await asyncio.sleep(delay / 1000.0)

        raise last_error or RuntimeError("Operation failed after retries")

    def get_config(self) -> MCPTransportConfigStdio:
        """Get the transport configuration."""
        return self._config

    def get_server_capabilities(self) -> dict[str, object]:
        """Get the server capabilities from the initialize response."""
        return self._server_capabilities

    async def reconnect(self) -> None:
        """Explicitly reconnect to the MCP server."""
        self._cleanup()
        await self.connect()

    # -- Private methods ----------------------------------------------------

    async def _invoke_once(
        self,
        name: str,
        args: dict[str, object],
    ) -> MCPToolInvokeResponse:
        """Perform a single tool invocation without retries."""
        response = await self._send_request(
            MCP_METHODS_TOOLS_CALL,
            {"name": name, "arguments": args},
        )

        if _is_json_rpc_error(response):
            error = response.get("error", {})
            if isinstance(error, dict):
                return MCPToolInvokeResponse(
                    content={
                        "error": error.get("message", "Unknown error"),
                        "code": error.get("code"),
                        "data": error.get("data"),
                    },
                    is_error=True,
                )
            return MCPToolInvokeResponse(
                content={"error": str(error)},
                is_error=True,
            )

        result = response.get("result")
        if isinstance(result, dict):
            return MCPToolInvokeResponse(
                content=result.get("content"),
                is_error=bool(result.get("isError", False)),
            )
        return MCPToolInvokeResponse(content=result, is_error=False)

    async def _spawn_process(self) -> None:
        """Spawn the child process."""
        import os

        env = dict(os.environ)
        if self._config.env:
            env.update(self._config.env)

        self._process = await asyncio.create_subprocess_exec(
            self._config.command,
            *(self._config.args or []),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self._config.cwd,
            env=env,
        )

        # Start a background task to read stdout
        self._reader_task = asyncio.create_task(self._read_stdout())

    async def _read_stdout(self) -> None:
        """Continuously read stdout and resolve pending requests."""
        if not self._process or not self._process.stdout:
            return

        try:
            while True:
                line_bytes = await self._process.stdout.readline()
                if not line_bytes:
                    break

                line = line_bytes.decode("utf-8").strip()
                if not line:
                    continue

                try:
                    response = _parse_json_rpc_response(line)
                    response_id = response.get("id")
                    if isinstance(response_id, int) and response_id in self._pending:
                        future = self._pending.pop(response_id)
                        if not future.done():
                            future.set_result(response)
                except (json.JSONDecodeError, ValueError):
                    # Skip invalid lines (may be server logging)
                    pass
        except (asyncio.CancelledError, Exception):
            pass
        finally:
            # Process exited -- reject all pending requests
            self._connected = False
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(RuntimeError("Process exited"))
            self._pending.clear()

            # Attempt reconnection if enabled
            if self._options.auto_reconnect:
                asyncio.create_task(self._attempt_reconnect())

    async def _initialize(self) -> None:
        """Send the initialize request and wait for the response."""
        response = await self._send_request(
            MCP_METHODS_INITIALIZE,
            {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {
                    "name": "arelis-mcp-client",
                    "version": "1.0.0",
                },
            },
        )

        if _is_json_rpc_error(response):
            error = response.get("error", {})
            msg = error.get("message", "Unknown error") if isinstance(error, dict) else str(error)
            raise RuntimeError(f"Failed to initialize MCP connection: {msg}")

        result = response.get("result")
        if isinstance(result, dict):
            caps = result.get("capabilities")
            self._server_capabilities = caps if isinstance(caps, dict) else {}

    async def _send_request(
        self,
        method: str,
        params: dict[str, object] | None = None,
    ) -> dict[str, object]:
        """Send a JSON-RPC request and wait for the response."""
        if not self._process or not self._process.stdin:
            raise RuntimeError("Process stdin not writable")

        request_id = self._next_id
        self._next_id += 1

        request = _create_json_rpc_request(request_id, method, params)
        message = _serialize_json_rpc_message(request)

        loop = asyncio.get_event_loop()
        future: asyncio.Future[dict[str, object]] = loop.create_future()
        self._pending[request_id] = future

        try:
            self._process.stdin.write(message)
            await self._process.stdin.drain()
        except Exception as exc:
            self._pending.pop(request_id, None)
            raise exc

        timeout_s = self._options.connection_timeout / 1000.0
        try:
            return await asyncio.wait_for(future, timeout=timeout_s)
        except asyncio.TimeoutError as exc:
            self._pending.pop(request_id, None)
            raise RuntimeError(
                f"Request {method} timed out after {self._options.connection_timeout}ms"
            ) from exc

    async def _attempt_reconnect(self) -> None:
        """Attempt to reconnect with exponential backoff."""
        if self._reconnect_attempts >= self._options.max_reconnect_attempts:
            return

        self._reconnect_attempts += 1
        delay = _calculate_backoff_delay(
            self._reconnect_attempts - 1,
            self._options.base_delay_ms,
            self._options.max_delay_ms,
        )
        await asyncio.sleep(delay / 1000.0)

        with contextlib.suppress(Exception):
            await self.connect()

    def _cleanup(self) -> None:
        """Clean up resources."""
        self._connected = False
        self._buffer = ""

        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            self._reader_task = None

        if self._process:
            with contextlib.suppress(ProcessLookupError, OSError):
                self._process.kill()
            self._process = None

        # Reject all pending
        for future in self._pending.values():
            if not future.done():
                future.set_exception(RuntimeError("Transport disconnected"))
        self._pending.clear()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_stdio_mcp_transport(
    config: MCPTransportConfigStdio,
    options: StdioTransportOptions | None = None,
) -> StdioMCPTransport:
    """Create a stdio MCP transport."""
    return StdioMCPTransport(config, options)
