"""Base MCP transport protocol for the Arelis AI SDK.

Defines the ``MCPTransport`` protocol that all transport implementations
must satisfy.  Ports the ``MCPTransport`` interface from
``packages/mcp/src/types.ts``.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from arelis.mcp.types import MCPToolInvokeResponse, MCPToolSchema

__all__ = [
    "MCPTransport",
]


@runtime_checkable
class MCPTransport(Protocol):
    """Protocol for MCP server transports.

    Implementations communicate with an MCP server over different
    channels (stdio, HTTP, mock, etc.).
    """

    async def connect(self) -> None:
        """Establish connection to the MCP server."""
        ...

    async def disconnect(self) -> None:
        """Disconnect from the MCP server."""
        ...

    def is_connected(self) -> bool:
        """Check if currently connected to the MCP server."""
        ...

    async def list_tools(self) -> list[MCPToolSchema]:
        """List available tools from the MCP server."""
        ...

    async def invoke_tool(
        self,
        name: str,
        args: dict[str, object],
    ) -> MCPToolInvokeResponse:
        """Invoke a tool on the MCP server."""
        ...
