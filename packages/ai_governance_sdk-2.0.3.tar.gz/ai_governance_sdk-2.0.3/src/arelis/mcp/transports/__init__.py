"""MCP transport implementations for the Arelis AI SDK.

Provides stdio, HTTP, and mock transports for communicating with MCP servers.
"""

from __future__ import annotations

from arelis.mcp.transports.base import MCPTransport
from arelis.mcp.transports.http import (
    HttpMCPTransport,
    HttpTransportOptions,
    create_http_mcp_transport,
)
from arelis.mcp.transports.mock import (
    MockMCPTransport,
    MockMCPTransportOptions,
    MockToolHandler,
    create_mock_mcp_transport,
    create_test_mcp_transport,
)
from arelis.mcp.transports.stdio import (
    StdioMCPTransport,
    StdioTransportOptions,
    create_stdio_mcp_transport,
)

__all__ = [
    "HttpMCPTransport",
    "HttpTransportOptions",
    "MCPTransport",
    "MockMCPTransport",
    "MockMCPTransportOptions",
    "MockToolHandler",
    "StdioMCPTransport",
    "StdioTransportOptions",
    "create_http_mcp_transport",
    "create_mock_mcp_transport",
    "create_stdio_mcp_transport",
    "create_test_mcp_transport",
]
