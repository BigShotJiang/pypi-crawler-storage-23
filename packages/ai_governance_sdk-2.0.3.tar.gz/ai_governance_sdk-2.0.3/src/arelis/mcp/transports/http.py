"""HTTP/SSE MCP transport for the Arelis AI SDK.

Communicates with an MCP server via HTTP POST (client-to-server) and
SSE (server-to-client).  Implements JSON-RPC 2.0 message marshaling,
request correlation with unique IDs, timeout handling, and retry logic.

Ports ``HttpMCPTransport`` from ``packages/mcp/src/transports/http.ts``,
extended with a full working implementation using ``httpx``.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import random
from dataclasses import dataclass
from urllib.parse import urlparse

import httpx

from arelis.mcp.types import MCPToolInvokeResponse, MCPToolSchema, MCPTransportConfigHttp

__all__ = [
    "HttpMCPTransport",
    "HttpTransportOptions",
    "create_http_mcp_transport",
]

# ---------------------------------------------------------------------------
# JSON-RPC 2.0 constants (shared with stdio transport)
# ---------------------------------------------------------------------------

MCP_PROTOCOL_VERSION = "2024-11-05"

MCP_METHODS_INITIALIZE = "initialize"
MCP_METHODS_SHUTDOWN = "shutdown"
MCP_METHODS_TOOLS_LIST = "tools/list"
MCP_METHODS_TOOLS_CALL = "tools/call"

# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


@dataclass
class HttpTransportOptions:
    """Options for the HTTP MCP transport."""

    connection_timeout: int = 30000
    """Connection timeout in milliseconds."""

    request_timeout: int = 60000
    """Per-request timeout in milliseconds."""

    sse_reconnect_interval: int = 3000
    """SSE reconnect interval in milliseconds."""

    max_retries: int = 2
    """Maximum retries for tool invocations on transient errors."""

    base_delay_ms: int = 1000
    """Base delay for exponential backoff in ms."""

    max_delay_ms: int = 30000
    """Maximum delay for exponential backoff in ms."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _calculate_backoff_delay(attempt: int, base_delay_ms: int, max_delay_ms: int) -> int:
    """Calculate backoff delay with exponential growth and jitter."""
    exponential_delay = base_delay_ms * (2**attempt)
    capped_delay = min(exponential_delay, max_delay_ms)
    jitter = capped_delay * 0.25 * random.random()
    return int(capped_delay + jitter)


def _is_transient_error(error: Exception) -> bool:
    """Determine if an error is transient and should be retried."""
    message = str(error).lower()
    transient_patterns = [
        "econnreset",
        "econnrefused",
        "etimedout",
        "epipe",
        "enotfound",
        "enetunreach",
        "ehostunreach",
        "connection",
        "timeout",
        "socket hang up",
        "network",
        "aborted",
    ]
    return any(pattern in message for pattern in transient_patterns)


def _create_json_rpc_request(
    request_id: int,
    method: str,
    params: dict[str, object] | None = None,
) -> dict[str, object]:
    """Create a JSON-RPC 2.0 request."""
    request: dict[str, object] = {
        "jsonrpc": "2.0",
        "id": request_id,
        "method": method,
    }
    if params is not None:
        request["params"] = params
    return request


def _is_json_rpc_error(response: dict[str, object]) -> bool:
    """Check if a JSON-RPC response is an error."""
    return "error" in response and response["error"] is not None


def _parse_sse_event(raw: str) -> dict[str, str]:
    """Parse a single SSE event block into its fields.

    An SSE event consists of lines like::

        event: message
        data: {"jsonrpc":"2.0",...}
        id: 123

    Returns a dict with keys ``event``, ``data``, ``id`` where present.
    """
    fields: dict[str, str] = {}
    for line in raw.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            # SSE spec: if a space follows the colon, strip it
            if value.startswith(" "):
                value = value[1:]
            key = key.strip()
            if key in ("event", "data", "id", "retry"):
                # data can be multi-line; concatenate with newlines
                if key == "data" and "data" in fields:
                    fields["data"] = fields["data"] + "\n" + value
                else:
                    fields[key] = value
    return fields


# ---------------------------------------------------------------------------
# HttpMCPTransport
# ---------------------------------------------------------------------------


class HttpMCPTransport:
    """HTTP/SSE MCP transport.

    Uses HTTP POST for client-to-server JSON-RPC 2.0 requests and optionally
    receives server-to-client messages via Server-Sent Events (SSE).

    Lifecycle:
        1. ``connect()`` validates the URL, creates an ``httpx.AsyncClient``,
           optionally opens an SSE stream for server-initiated messages,
           and sends the MCP ``initialize`` handshake.
        2. ``list_tools()`` / ``invoke_tool()`` send JSON-RPC requests via
           HTTP POST and correlate responses by request ID.
        3. ``disconnect()`` sends a shutdown notification and closes all
           HTTP resources.
    """

    def __init__(
        self,
        config: MCPTransportConfigHttp,
        options: HttpTransportOptions | None = None,
    ) -> None:
        self._config = config
        self._options = options or HttpTransportOptions()
        self._connected = False
        self._next_id = 1
        self._client: httpx.AsyncClient | None = None
        self._server_capabilities: dict[str, object] = {}
        # SSE state
        self._sse_task: asyncio.Task[None] | None = None
        self._sse_pending: dict[int, asyncio.Future[dict[str, object]]] = {}

    # -- Public API ---------------------------------------------------------

    async def connect(self) -> None:
        """Connect to the MCP server.

        Validates the URL, creates an httpx client, and performs the MCP
        initialize handshake via HTTP POST.
        """
        if self._connected:
            return

        # Validate URL
        parsed = urlparse(self._config.url)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError(f"Invalid URL: {self._config.url}")

        # Create httpx async client
        timeout = httpx.Timeout(
            connect=self._options.connection_timeout / 1000.0,
            read=self._options.request_timeout / 1000.0,
            write=self._options.request_timeout / 1000.0,
            pool=self._options.connection_timeout / 1000.0,
        )
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers=self.get_headers(),
        )

        # Perform MCP initialize handshake
        await self._initialize()
        self._connected = True

    async def disconnect(self) -> None:
        """Disconnect from the MCP server.

        Sends a shutdown notification and closes all HTTP resources.
        """
        if not self._connected and not self._client:
            return

        # Send shutdown notification (best effort)
        if self._client:
            try:
                request = _create_json_rpc_request(
                    self._next_id,
                    MCP_METHODS_SHUTDOWN,
                )
                self._next_id += 1
                await self._client.post(
                    self._config.url,
                    json=request,
                )
            except (httpx.HTTPError, OSError):
                pass

        await self._cleanup()

    def is_connected(self) -> bool:
        """Check if connected to the MCP server."""
        return self._connected

    async def list_tools(self) -> list[MCPToolSchema]:
        """List available tools from the MCP server.

        Sends a ``tools/list`` JSON-RPC request via HTTP POST and parses
        the response into ``MCPToolSchema`` instances.
        """
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")

        response = await self._send_request(MCP_METHODS_TOOLS_LIST)

        if _is_json_rpc_error(response):
            error = response.get("error", {})
            msg = error.get("message", "Unknown error") if isinstance(error, dict) else str(error)
            raise RuntimeError(f"Failed to list tools: {msg}")

        result = response.get("result")
        raw_tools = result.get("tools", []) if isinstance(result, dict) else []

        tools: list[MCPToolSchema] = []
        if isinstance(raw_tools, list):
            for t in raw_tools:
                if isinstance(t, dict):
                    tools.append(
                        MCPToolSchema(
                            name=str(t.get("name", "")),
                            description=t.get("description"),
                            input_schema=t.get("inputSchema"),
                        )
                    )
        return tools

    async def invoke_tool(
        self,
        name: str,
        args: dict[str, object],
    ) -> MCPToolInvokeResponse:
        """Invoke a tool on the MCP server with retry logic.

        Sends a ``tools/call`` JSON-RPC request via HTTP POST.  Transient
        errors are retried with exponential backoff.
        """
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")

        last_error: Exception | None = None

        for attempt in range(self._options.max_retries + 1):
            try:
                return await self._invoke_once(name, args)
            except Exception as exc:
                last_error = exc
                if not _is_transient_error(exc):
                    raise
                if attempt < self._options.max_retries:
                    delay = _calculate_backoff_delay(
                        attempt,
                        self._options.base_delay_ms,
                        self._options.max_delay_ms,
                    )
                    await asyncio.sleep(delay / 1000.0)

        raise last_error or RuntimeError("Operation failed after retries")

    def get_config(self) -> MCPTransportConfigHttp:
        """Get the transport configuration."""
        return self._config

    def get_headers(self) -> dict[str, str]:
        """Get headers for requests."""
        headers = {"Content-Type": "application/json"}
        if self._config.headers:
            headers.update(self._config.headers)
        return headers

    def get_server_capabilities(self) -> dict[str, object]:
        """Get the server capabilities from the initialize response."""
        return self._server_capabilities

    async def start_sse_listener(self, sse_url: str | None = None) -> None:
        """Start an SSE listener for server-to-client messages.

        This opens a long-lived HTTP connection to the SSE endpoint and
        processes incoming events in a background task.  Responses with a
        matching JSON-RPC ``id`` resolve the corresponding pending future.

        Parameters
        ----------
        sse_url:
            The SSE endpoint URL.  Defaults to the transport URL with
            ``/sse`` appended.
        """
        if self._sse_task is not None:
            return
        if not self._client:
            raise RuntimeError("Client not initialized — call connect() first")

        url = sse_url or self._config.url.rstrip("/") + "/sse"
        self._sse_task = asyncio.create_task(self._sse_read_loop(url))

    async def stop_sse_listener(self) -> None:
        """Stop the SSE listener if running."""
        if self._sse_task is not None and not self._sse_task.done():
            self._sse_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._sse_task
            self._sse_task = None

    # -- Private methods ----------------------------------------------------

    async def _initialize(self) -> None:
        """Send the initialize request and capture server capabilities."""
        response = await self._send_request(
            MCP_METHODS_INITIALIZE,
            {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {
                    "name": "arelis-mcp-client",
                    "version": "1.0.0",
                },
            },
        )

        if _is_json_rpc_error(response):
            error = response.get("error", {})
            msg = error.get("message", "Unknown error") if isinstance(error, dict) else str(error)
            raise RuntimeError(f"Failed to initialize MCP connection: {msg}")

        result = response.get("result")
        if isinstance(result, dict):
            caps = result.get("capabilities")
            self._server_capabilities = caps if isinstance(caps, dict) else {}

    async def _send_request(
        self,
        method: str,
        params: dict[str, object] | None = None,
    ) -> dict[str, object]:
        """Send a JSON-RPC 2.0 request via HTTP POST and return the response.

        The response is expected as a JSON body in the HTTP response.
        """
        if not self._client:
            raise RuntimeError("HTTP client not initialized")

        request_id = self._next_id
        self._next_id += 1

        request = _create_json_rpc_request(request_id, method, params)

        try:
            http_response = await self._client.post(
                self._config.url,
                json=request,
            )
            http_response.raise_for_status()
        except httpx.TimeoutException as exc:
            raise RuntimeError(
                f"Request {method} timed out after {self._options.request_timeout}ms"
            ) from exc
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(
                f"HTTP error {exc.response.status_code} for {method}: {exc.response.text[:200]}"
            ) from exc
        except httpx.HTTPError as exc:
            raise RuntimeError(f"HTTP request failed for {method}: {exc}") from exc

        # Parse JSON-RPC response
        try:
            body = http_response.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError(
                f"Invalid JSON response for {method}: {http_response.text[:200]}"
            ) from exc

        if not isinstance(body, dict):
            raise RuntimeError(f"JSON-RPC response must be an object, got {type(body).__name__}")

        return body

    async def _send_request_via_sse(
        self,
        method: str,
        params: dict[str, object] | None = None,
        timeout_ms: int | None = None,
    ) -> dict[str, object]:
        """Send a JSON-RPC request via HTTP POST and wait for the response
        on the SSE stream.

        This is used when responses arrive asynchronously via SSE rather than
        in the HTTP POST response body.  The request is correlated by its
        JSON-RPC ``id``.
        """
        if not self._client:
            raise RuntimeError("HTTP client not initialized")
        if self._sse_task is None or self._sse_task.done():
            raise RuntimeError("SSE listener not running — call start_sse_listener() first")

        request_id = self._next_id
        self._next_id += 1

        request = _create_json_rpc_request(request_id, method, params)

        # Create a future to await the SSE response
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, object]] = loop.create_future()
        self._sse_pending[request_id] = future

        # POST the request
        try:
            http_response = await self._client.post(
                self._config.url,
                json=request,
            )
            http_response.raise_for_status()
        except Exception as exc:
            self._sse_pending.pop(request_id, None)
            raise RuntimeError(f"HTTP request failed for {method}: {exc}") from exc

        # Wait for SSE response with timeout
        effective_timeout = (timeout_ms or self._options.request_timeout) / 1000.0
        try:
            return await asyncio.wait_for(future, timeout=effective_timeout)
        except asyncio.TimeoutError as exc:
            self._sse_pending.pop(request_id, None)
            raise RuntimeError(
                f"SSE response for {method} timed out after "
                f"{timeout_ms or self._options.request_timeout}ms"
            ) from exc

    async def _invoke_once(
        self,
        name: str,
        args: dict[str, object],
    ) -> MCPToolInvokeResponse:
        """Perform a single tool invocation without retries."""
        response = await self._send_request(
            MCP_METHODS_TOOLS_CALL,
            {"name": name, "arguments": args},
        )

        if _is_json_rpc_error(response):
            error = response.get("error", {})
            if isinstance(error, dict):
                return MCPToolInvokeResponse(
                    content={
                        "error": error.get("message", "Unknown error"),
                        "code": error.get("code"),
                        "data": error.get("data"),
                    },
                    is_error=True,
                )
            return MCPToolInvokeResponse(
                content={"error": str(error)},
                is_error=True,
            )

        result = response.get("result")
        if isinstance(result, dict):
            return MCPToolInvokeResponse(
                content=result.get("content"),
                is_error=bool(result.get("isError", False)),
            )
        return MCPToolInvokeResponse(content=result, is_error=False)

    async def _sse_read_loop(self, url: str) -> None:
        """Background task that reads SSE events and resolves pending futures.

        Each SSE ``data`` line is expected to contain a JSON-RPC 2.0 response.
        If the response ``id`` matches a pending future, that future is
        resolved.
        """
        if not self._client:
            return

        try:
            async with self._client.stream(
                "GET", url, headers={"Accept": "text/event-stream"}
            ) as response:
                response.raise_for_status()
                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    # SSE events are separated by blank lines
                    while "\n\n" in buffer:
                        event_raw, buffer = buffer.split("\n\n", 1)
                        event = _parse_sse_event(event_raw)
                        data = event.get("data")
                        if not data:
                            continue
                        self._handle_sse_data(data)
        except asyncio.CancelledError:
            pass
        except (httpx.HTTPError, OSError):
            # SSE stream disconnected -- mark pending as failed
            pass
        finally:
            # Reject remaining pending SSE futures
            for future in self._sse_pending.values():
                if not future.done():
                    future.set_exception(RuntimeError("SSE stream closed"))
            self._sse_pending.clear()

    def _handle_sse_data(self, data: str) -> None:
        """Parse an SSE data payload and resolve a pending future if matched."""
        try:
            parsed = json.loads(data)
        except (json.JSONDecodeError, ValueError):
            return

        if not isinstance(parsed, dict):
            return

        response_id = parsed.get("id")
        if isinstance(response_id, int) and response_id in self._sse_pending:
            future = self._sse_pending.pop(response_id)
            if not future.done():
                future.set_result(parsed)

    async def _cleanup(self) -> None:
        """Clean up all HTTP resources."""
        self._connected = False

        # Stop SSE listener
        await self.stop_sse_listener()

        # Close httpx client
        if self._client:
            with contextlib.suppress(Exception):
                await self._client.aclose()
            self._client = None

        # Reject all pending SSE futures
        for future in self._sse_pending.values():
            if not future.done():
                future.set_exception(RuntimeError("Transport disconnected"))
        self._sse_pending.clear()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_http_mcp_transport(
    config: MCPTransportConfigHttp,
    options: HttpTransportOptions | None = None,
) -> HttpMCPTransport:
    """Create an HTTP MCP transport."""
    return HttpMCPTransport(config, options)
