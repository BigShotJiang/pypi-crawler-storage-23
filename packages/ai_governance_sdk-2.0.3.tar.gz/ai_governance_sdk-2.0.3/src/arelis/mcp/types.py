"""MCP types for the Arelis AI SDK.

Ports types from the TypeScript SDK's ``packages/mcp/src/types.ts``:
MCPServerDescriptor, MCPTransportConfig, MCPAuthConfig, MCPGovernanceConfig,
MCPToolSchema, and related types.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from arelis.core.types import GovernanceContext
from arelis.tools.types import JsonSchema, JsonSchemaProperty

if TYPE_CHECKING:
    from arelis.mcp.discovery import ToolDiscoveryOptions

__all__ = [
    "MCPAuthConfig",
    "MCPAuthConfigApiKey",
    "MCPAuthConfigBearer",
    "MCPAuthConfigNone",
    "MCPAuthType",
    "MCPContext",
    "DiscoverMCPToolsInput",
    "MCPGovernanceConfig",
    "MCPLifecycleEmitter",
    "MCPProducerEvent",
    "MCPProducerEventType",
    "MCPRegistryOptions",
    "MCPServerDescriptor",
    "MCPToolDiscoveryResult",
    "MCPToolInvokeRequest",
    "MCPToolInvokeResponse",
    "MCPToolSchema",
    "MCPTransportConfig",
    "MCPTransportConfigHttp",
    "MCPTransportConfigStdio",
    "MCPTransportType",
    "RegisterMCPServerInput",
    "get_mcp_tool_name",
    "parse_mcp_tool_name",
    "to_json_schema",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

MCPTransportType = Literal["stdio", "http"]
"""MCP transport types."""

MCPAuthType = Literal["none", "bearer", "apiKey"]
"""MCP authentication types."""

MCPProducerEventType = Literal[
    "mcp.server.registered",
    "mcp.server.connected",
    "mcp.server.disconnected",
    "mcp.tools.discovered",
]
"""MCP lifecycle event types."""

# ---------------------------------------------------------------------------
# Transport configuration
# ---------------------------------------------------------------------------


@dataclass
class MCPTransportConfigStdio:
    """Stdio transport configuration."""

    type: Literal["stdio"] = "stdio"
    command: str = ""
    args: list[str] | None = None
    env: dict[str, str] | None = None
    cwd: str | None = None


@dataclass
class MCPTransportConfigHttp:
    """HTTP transport configuration."""

    type: Literal["http"] = "http"
    url: str = ""
    headers: dict[str, str] | None = None


MCPTransportConfig = MCPTransportConfigStdio | MCPTransportConfigHttp
"""Union type for transport configuration."""

# ---------------------------------------------------------------------------
# Authentication configuration
# ---------------------------------------------------------------------------


@dataclass
class MCPAuthConfigNone:
    """No authentication."""

    type: Literal["none"] = "none"


@dataclass
class MCPAuthConfigBearer:
    """Bearer token authentication."""

    type: Literal["bearer"] = "bearer"
    value_ref: str = ""


@dataclass
class MCPAuthConfigApiKey:
    """API key authentication."""

    type: Literal["apiKey"] = "apiKey"
    value_ref: str = ""
    header_name: str | None = None


MCPAuthConfig = MCPAuthConfigNone | MCPAuthConfigBearer | MCPAuthConfigApiKey
"""Union type for authentication configuration."""

# ---------------------------------------------------------------------------
# Governance configuration
# ---------------------------------------------------------------------------


@dataclass
class MCPGovernanceConfig:
    """Governance configuration for an MCP server."""

    data_residency: Literal["EU", "US", "APAC"] | None = None
    allowed_tools: list[str] | None = None
    denied_tools: list[str] | None = None
    approved_for_purposes: list[str] | None = None


# ---------------------------------------------------------------------------
# Server descriptor
# ---------------------------------------------------------------------------


@dataclass
class MCPServerDescriptor:
    """Descriptor for an MCP server registration."""

    id: str
    transport: MCPTransportConfig
    name: str | None = None
    auth: MCPAuthConfig | None = None
    governance: MCPGovernanceConfig | None = None
    tags: dict[str, str] | None = None


# ---------------------------------------------------------------------------
# Tool schema (from MCP protocol)
# ---------------------------------------------------------------------------


@dataclass
class MCPToolSchema:
    """Tool schema as reported by an MCP server."""

    name: str
    description: str | None = None
    input_schema: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Discovery result
# ---------------------------------------------------------------------------


@dataclass
class MCPToolDiscoveryResult:
    """Result of discovering tools from an MCP server."""

    server_id: str
    tools: list[MCPToolSchema] = field(default_factory=list)
    discovered_at: str = ""


# ---------------------------------------------------------------------------
# Invocation request/response
# ---------------------------------------------------------------------------


@dataclass
class MCPToolInvokeRequest:
    """Request to invoke an MCP tool."""

    tool_name: str
    args: dict[str, object]
    server_id: str


@dataclass
class MCPToolInvokeResponse:
    """Response from invoking an MCP tool."""

    content: object
    is_error: bool = False


# ---------------------------------------------------------------------------
# Lifecycle events
# ---------------------------------------------------------------------------


@dataclass
class MCPProducerEvent:
    """Lifecycle event emitted by the MCP registry."""

    type: MCPProducerEventType
    server_id: str
    time: str
    transport: MCPTransportType | None = None
    total_discovered: int | None = None
    registered_count: int | None = None
    skipped_count: int | None = None
    tool_names: list[str] | None = None
    reason: str | None = None


MCPLifecycleEmitter = Callable[[MCPProducerEvent], None | Awaitable[None]]
"""Lifecycle event emitter callback."""

# ---------------------------------------------------------------------------
# Registry options
# ---------------------------------------------------------------------------


@dataclass
class MCPRegistryOptions:
    """Options for the MCP registry."""

    allow_overwrite: bool = False
    default_timeout: int = 30000
    lifecycle_emitter: MCPLifecycleEmitter | None = None


# ---------------------------------------------------------------------------
# MCP context
# ---------------------------------------------------------------------------


@dataclass
class MCPContext:
    """Context for MCP operations."""

    run_id: str
    governance: GovernanceContext
    metadata: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Client method input types
# ---------------------------------------------------------------------------


@dataclass
class RegisterMCPServerInput:
    """Input for ``client.mcp.register_server()``."""

    server: MCPServerDescriptor
    context: GovernanceContext | None = None
    discovery_options: ToolDiscoveryOptions | None = None


@dataclass
class DiscoverMCPToolsInput:
    """Input for ``client.mcp.discover_tools()``."""

    server_id: str
    context: GovernanceContext | None = None
    options: ToolDiscoveryOptions | None = None


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def to_json_schema(mcp_schema: dict[str, object] | None) -> JsonSchema:
    """Convert an MCP tool input schema dict to an Arelis JsonSchema."""
    if not mcp_schema:
        return JsonSchema(type="object", properties={}, required=[])

    properties: dict[str, JsonSchemaProperty] | None = None
    raw_props = mcp_schema.get("properties")
    if isinstance(raw_props, dict):
        properties = {}
        for key, value in raw_props.items():
            if isinstance(value, dict):
                prop_type = value.get("type", "string")
                if isinstance(prop_type, str) and prop_type in (
                    "string",
                    "number",
                    "boolean",
                    "array",
                    "object",
                ):
                    properties[key] = JsonSchemaProperty(
                        type=prop_type,  # type: ignore[arg-type]
                        description=value.get("description"),
                    )

    required: list[str] | None = None
    raw_required = mcp_schema.get("required")
    if isinstance(raw_required, list):
        required = [str(r) for r in raw_required]

    return JsonSchema(type="object", properties=properties, required=required)


def get_mcp_tool_name(server_id: str, tool_name: str) -> str:
    """Generate a namespaced tool name for MCP tools.

    Format: ``mcp.<serverId>.<toolName>``
    """
    return f"mcp.{server_id}.{tool_name}"


def parse_mcp_tool_name(full_name: str) -> tuple[str, str] | None:
    """Parse a namespaced MCP tool name.

    Returns a tuple of ``(server_id, tool_name)`` or ``None`` if the
    format is invalid.
    """
    parts = full_name.split(".")
    if len(parts) < 3 or parts[0] != "mcp":
        return None
    server_id = parts[1]
    tool_name = ".".join(parts[2:])
    if not server_id or not tool_name:
        return None
    return (server_id, tool_name)
