"""MCP tool discovery for the Arelis AI SDK.

Ports ``discoverTools``, ``unregisterServerTools``, and ``listServerTools``
from ``packages/mcp/src/tool-discovery.ts``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from arelis.mcp.types import (
    get_mcp_tool_name,
    to_json_schema,
)
from arelis.tools.types import (
    DiscoveredTool,
    ToolDefinition,
    ToolPermissions,
)

if TYPE_CHECKING:
    from arelis.mcp.registry import MCPRegistry
    from arelis.tools.registry import ToolRegistry

__all__ = [
    "ToolDiscoveryFullResult",
    "ToolDiscoveryOptions",
    "discover_tools",
    "list_server_tools",
    "unregister_server_tools",
]

# ---------------------------------------------------------------------------
# Options and result types
# ---------------------------------------------------------------------------


@dataclass
class ToolDiscoveryOptions:
    """Options for MCP tool discovery."""

    default_permissions: ToolPermissions | None = None
    """Override default permissions for discovered tools."""

    skip_governance_check: bool = False
    """Whether to skip governance checks during discovery."""

    tags: list[str] | None = None
    """Additional tags to apply to all discovered tools."""


@dataclass
class ToolDiscoveryFullResult:
    """Full result of discovering tools from an MCP server."""

    server_id: str
    total_discovered: int = 0
    registered_count: int = 0
    skipped_count: int = 0
    tools: list[DiscoveredTool] = field(default_factory=list)
    discovered_at: str = ""


# ---------------------------------------------------------------------------
# Default permissions
# ---------------------------------------------------------------------------

_DEFAULT_MCP_PERMISSIONS = ToolPermissions(
    scopes=["network", "read"],
    allowed_actor_types=["human", "service", "agent"],
    allowed_environments=["dev", "staging", "prod"],
)


# ---------------------------------------------------------------------------
# MCP tool handler factory
# ---------------------------------------------------------------------------


def _create_mcp_tool_handler(
    mcp_registry: MCPRegistry,
    server_id: str,
    tool_name: str,
) -> object:
    """Create an async tool handler that invokes an MCP tool via the transport."""

    async def handler(
        args: dict[str, object],
        context: object,
    ) -> object:
        transport = mcp_registry.get_transport(server_id)
        if transport is None:
            raise RuntimeError(f'No transport available for MCP server "{server_id}"')

        if not transport.is_connected():
            raise RuntimeError(f'MCP server "{server_id}" is not connected')

        response = await transport.invoke_tool(tool_name, args)

        if response.is_error:
            import json

            try:
                content_str = json.dumps(response.content)
            except (TypeError, ValueError):
                content_str = str(response.content)
            raise RuntimeError(f"MCP tool error: {content_str}")

        return response.content

    return handler


# ---------------------------------------------------------------------------
# Discovery function
# ---------------------------------------------------------------------------


async def discover_tools(
    mcp_registry: MCPRegistry,
    tool_registry: ToolRegistry,
    server_id: str,
    options: ToolDiscoveryOptions | None = None,
) -> ToolDiscoveryFullResult:
    """Discover tools from an MCP server and register them in the tool registry.

    Parameters
    ----------
    mcp_registry:
        The MCP server registry.
    tool_registry:
        The tool registry to register discovered tools in.
    server_id:
        The ID of the MCP server to discover tools from.
    options:
        Discovery options.

    Returns
    -------
    ToolDiscoveryFullResult
        The result of the discovery operation.
    """
    opts = options or ToolDiscoveryOptions()

    server = mcp_registry.get_server(server_id)
    if server is None:
        raise ValueError(f'MCP server "{server_id}" not found')

    transport = mcp_registry.get_transport(server_id)
    if transport is None:
        raise ValueError(f'No transport available for MCP server "{server_id}"')

    if not transport.is_connected():
        await transport.connect()
        mcp_registry.notify_server_connected(server_id)

    # Get tools from MCP server
    mcp_tools = await transport.list_tools()

    result = ToolDiscoveryFullResult(
        server_id=server_id,
        total_discovered=len(mcp_tools),
        registered_count=0,
        skipped_count=0,
        tools=[],
        discovered_at=datetime.now(timezone.utc).isoformat(),
    )

    for mcp_tool in mcp_tools:
        full_name = get_mcp_tool_name(server_id, mcp_tool.name)
        discovered_tool = DiscoveredTool(
            name=full_name,
            original_name=mcp_tool.name,
            server_id=server_id,
            description=mcp_tool.description,
            registered=False,
        )

        # Check if tool is allowed by governance
        if not opts.skip_governance_check and not mcp_registry.is_tool_allowed(
            server_id, mcp_tool.name
        ):
            discovered_tool.skip_reason = "Tool not allowed by governance config"
            result.skipped_count += 1
            result.tools.append(discovered_tool)
            continue

        # Build permissions
        permissions = ToolPermissions(
            scopes=list(_DEFAULT_MCP_PERMISSIONS.scopes),
            allowed_actor_types=(
                list(_DEFAULT_MCP_PERMISSIONS.allowed_actor_types)
                if _DEFAULT_MCP_PERMISSIONS.allowed_actor_types
                else None
            ),
            allowed_environments=(
                list(_DEFAULT_MCP_PERMISSIONS.allowed_environments)
                if _DEFAULT_MCP_PERMISSIONS.allowed_environments
                else None
            ),
        )

        # Merge overrides from options
        if opts.default_permissions is not None:
            if opts.default_permissions.scopes:
                permissions.scopes = list(opts.default_permissions.scopes)
            if opts.default_permissions.allowed_actor_types is not None:
                permissions.allowed_actor_types = list(opts.default_permissions.allowed_actor_types)
            if opts.default_permissions.allowed_environments is not None:
                permissions.allowed_environments = list(
                    opts.default_permissions.allowed_environments
                )
            if opts.default_permissions.allowed_purposes is not None:
                permissions.allowed_purposes = list(opts.default_permissions.allowed_purposes)
            if opts.default_permissions.allowed_roles is not None:
                permissions.allowed_roles = list(opts.default_permissions.allowed_roles)

        # Apply purpose restrictions from server governance
        server_governance = server.descriptor.governance
        if server_governance and server_governance.approved_for_purposes:
            permissions.allowed_purposes = list(server_governance.approved_for_purposes)

        # Build tags
        tool_tags = ["mcp", f"mcp:{server_id}"]
        if opts.tags:
            tool_tags.extend(opts.tags)

        tool_definition = ToolDefinition(
            name=full_name,
            description=(mcp_tool.description or f"MCP tool: {mcp_tool.name} from {server_id}"),
            schema=to_json_schema(mcp_tool.input_schema),
            permissions=permissions,
            handler=_create_mcp_tool_handler(mcp_registry, server_id, mcp_tool.name),  # type: ignore[arg-type]
            tags=tool_tags,
        )

        try:
            tool_registry.register(tool_definition)
            discovered_tool.registered = True
            result.registered_count += 1
        except Exception as exc:
            discovered_tool.skip_reason = str(exc)
            result.skipped_count += 1

        result.tools.append(discovered_tool)

    mcp_registry.notify_tools_discovered(
        server_id=server_id,
        total_discovered=result.total_discovered,
        registered_count=result.registered_count,
        skipped_count=result.skipped_count,
        tool_names=[t.original_name for t in result.tools],
    )

    return result


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def unregister_server_tools(tool_registry: ToolRegistry, server_id: str) -> int:
    """Unregister all tools from an MCP server.

    Returns the number of tools unregistered.
    """
    prefix = f"mcp.{server_id}."
    tool_names = tool_registry.list_names()
    count = 0

    for name in tool_names:
        if name.startswith(prefix) and tool_registry.unregister(name):
            count += 1

    return count


def list_server_tools(tool_registry: ToolRegistry, server_id: str) -> list[ToolDefinition]:
    """List all tools from an MCP server."""
    prefix = f"mcp.{server_id}."
    return [tool for tool in tool_registry.list() if tool.name.startswith(prefix)]
