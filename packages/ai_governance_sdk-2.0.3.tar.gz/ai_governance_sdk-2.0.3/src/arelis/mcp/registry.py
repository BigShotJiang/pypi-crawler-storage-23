"""MCP server registry for the Arelis AI SDK.

Ports ``MCPRegistry`` from ``packages/mcp/src/mcp-registry.ts``.
Manages MCP server registrations, transports, and governance checks.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.mcp.transports.base import MCPTransport
from arelis.mcp.types import (
    MCPLifecycleEmitter,
    MCPProducerEvent,
    MCPRegistryOptions,
    MCPServerDescriptor,
    MCPTransportConfigHttp,
    MCPTransportConfigStdio,
    MCPTransportType,
)

__all__ = [
    "MCPRegistry",
    "RegisteredMCPServer",
    "create_mcp_registry",
]

# ---------------------------------------------------------------------------
# Registered server entry
# ---------------------------------------------------------------------------


@dataclass
class RegisteredMCPServer:
    """A registered MCP server entry."""

    descriptor: MCPServerDescriptor
    registered_at: str
    transport: MCPTransport | None = None


# ---------------------------------------------------------------------------
# MCPRegistry
# ---------------------------------------------------------------------------


class MCPRegistry:
    """Registry for managing MCP server registrations.

    Provides server registration, transport management, governance checking,
    and lifecycle event emission.
    """

    def __init__(self, options: MCPRegistryOptions | None = None) -> None:
        opts = options or MCPRegistryOptions()
        self._allow_overwrite: bool = opts.allow_overwrite
        self._default_timeout: int = opts.default_timeout
        self._lifecycle_emitter: MCPLifecycleEmitter | None = opts.lifecycle_emitter
        self._servers: dict[str, RegisteredMCPServer] = {}

    # -- Lifecycle emission -------------------------------------------------

    def _emit_lifecycle(
        self,
        event_type: str,
        server_id: str,
        transport: MCPTransportType | None = None,
        total_discovered: int | None = None,
        registered_count: int | None = None,
        skipped_count: int | None = None,
        tool_names: list[str] | None = None,
        reason: str | None = None,
    ) -> None:
        """Emit a lifecycle event (best-effort, non-blocking)."""
        if not self._lifecycle_emitter:
            return

        event = MCPProducerEvent(
            type=event_type,  # type: ignore[arg-type]
            server_id=server_id,
            time=datetime.now(timezone.utc).isoformat(),
            transport=transport,
            total_discovered=total_discovered,
            registered_count=registered_count,
            skipped_count=skipped_count,
            tool_names=tool_names,
            reason=reason,
        )

        try:
            result = self._lifecycle_emitter(event)
            # If the emitter returns a coroutine, schedule it
            if asyncio.iscoroutine(result):
                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(result)
                except RuntimeError:
                    # No running event loop, ignore
                    pass
        except Exception:
            # Lifecycle hooks are best-effort
            pass

    # -- Registration -------------------------------------------------------

    def register_server(self, descriptor: MCPServerDescriptor) -> None:
        """Register an MCP server.

        Raises
        ------
        ValueError
            If validation fails or the server is already registered and
            overwriting is disabled.
        """
        if not descriptor.id or not isinstance(descriptor.id, str):
            raise ValueError("MCP server ID is required and must be a string")

        if not descriptor.transport:
            raise ValueError("MCP server transport configuration is required")

        transport_type = descriptor.transport.type
        if transport_type not in ("stdio", "http"):
            raise ValueError(f"Invalid transport type: {transport_type}")

        if (
            isinstance(descriptor.transport, MCPTransportConfigStdio)
            and not descriptor.transport.command
        ):
            raise ValueError("Stdio transport requires a command")

        if (
            isinstance(descriptor.transport, MCPTransportConfigHttp)
            and not descriptor.transport.url
        ):
            raise ValueError("HTTP transport requires a URL")

        if descriptor.id in self._servers and not self._allow_overwrite:
            raise ValueError(f'MCP server "{descriptor.id}" is already registered')

        self._servers[descriptor.id] = RegisteredMCPServer(
            descriptor=descriptor,
            registered_at=datetime.now(timezone.utc).isoformat(),
        )

        self._emit_lifecycle(
            event_type="mcp.server.registered",
            server_id=descriptor.id,
            transport=transport_type,
        )

    # -- Lookup -------------------------------------------------------------

    def get_server(self, server_id: str) -> RegisteredMCPServer | None:
        """Get a registered server by ID."""
        return self._servers.get(server_id)

    def has_server(self, server_id: str) -> bool:
        """Check if a server is registered."""
        return server_id in self._servers

    # -- Listing ------------------------------------------------------------

    def list_servers(self) -> list[RegisteredMCPServer]:
        """List all registered servers."""
        return list(self._servers.values())

    def list_server_ids(self) -> list[str]:
        """List all registered server IDs."""
        return list(self._servers.keys())

    # -- Unregistration -----------------------------------------------------

    def unregister_server(self, server_id: str) -> bool:
        """Unregister a server. Returns ``True`` if found and removed."""
        server = self._servers.get(server_id)
        if server is None:
            return False

        if server.transport:
            # Disconnect transport -- best-effort
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(server.transport.disconnect())
            except RuntimeError:
                pass

            self._emit_lifecycle(
                event_type="mcp.server.disconnected",
                server_id=server_id,
                transport=server.descriptor.transport.type,
                reason="unregister",
            )

        del self._servers[server_id]
        return True

    def clear(self) -> None:
        """Remove all registered servers, disconnecting transports."""
        for server in self._servers.values():
            if server.transport:
                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(server.transport.disconnect())
                except RuntimeError:
                    pass

                self._emit_lifecycle(
                    event_type="mcp.server.disconnected",
                    server_id=server.descriptor.id,
                    transport=server.descriptor.transport.type,
                    reason="clear",
                )

        self._servers.clear()

    # -- Size ---------------------------------------------------------------

    @property
    def size(self) -> int:
        """Number of registered servers."""
        return len(self._servers)

    @property
    def default_timeout(self) -> int:
        """Default timeout for tool invocations in milliseconds."""
        return self._default_timeout

    # -- Transport management -----------------------------------------------

    def set_transport(self, server_id: str, transport: MCPTransport) -> None:
        """Set the transport for a server.

        Raises
        ------
        ValueError
            If the server is not registered.
        """
        server = self._servers.get(server_id)
        if server is None:
            raise ValueError(f'MCP server "{server_id}" not found')

        server.transport = transport

        if transport.is_connected():
            self._emit_lifecycle(
                event_type="mcp.server.connected",
                server_id=server_id,
                transport=server.descriptor.transport.type,
            )

    def get_transport(self, server_id: str) -> MCPTransport | None:
        """Get the transport for a server."""
        server = self._servers.get(server_id)
        if server is None:
            return None
        return server.transport

    # -- Governance checks --------------------------------------------------

    def is_tool_allowed(self, server_id: str, tool_name: str) -> bool:
        """Check if a tool is allowed for a server based on governance config."""
        server = self._servers.get(server_id)
        if server is None:
            return False

        governance = server.descriptor.governance
        if governance is None:
            return True

        # Check denylist first
        if governance.denied_tools and tool_name in governance.denied_tools:
            return False

        # If allowlist exists, tool must be in it
        if governance.allowed_tools and len(governance.allowed_tools) > 0:
            return tool_name in governance.allowed_tools

        return True

    def is_purpose_approved(self, server_id: str, purpose: str) -> bool:
        """Check if a purpose is approved for a server."""
        server = self._servers.get(server_id)
        if server is None:
            return False

        governance = server.descriptor.governance
        if governance is None or governance.approved_for_purposes is None:
            return True

        return purpose in governance.approved_for_purposes

    # -- Lifecycle notifications --------------------------------------------

    def notify_server_connected(self, server_id: str) -> None:
        """Notify that a server has connected."""
        server = self._servers.get(server_id)
        if server is None:
            return
        self._emit_lifecycle(
            event_type="mcp.server.connected",
            server_id=server_id,
            transport=server.descriptor.transport.type,
        )

    def notify_server_disconnected(
        self,
        server_id: str,
        reason: str | None = None,
    ) -> None:
        """Notify that a server has disconnected."""
        server = self._servers.get(server_id)
        if server is None:
            return
        self._emit_lifecycle(
            event_type="mcp.server.disconnected",
            server_id=server_id,
            transport=server.descriptor.transport.type,
            reason=reason,
        )

    def notify_tools_discovered(
        self,
        server_id: str,
        total_discovered: int,
        registered_count: int,
        skipped_count: int,
        tool_names: list[str] | None = None,
    ) -> None:
        """Notify that tools have been discovered from a server."""
        self._emit_lifecycle(
            event_type="mcp.tools.discovered",
            server_id=server_id,
            total_discovered=total_discovered,
            registered_count=registered_count,
            skipped_count=skipped_count,
            tool_names=tool_names,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_mcp_registry(options: MCPRegistryOptions | None = None) -> MCPRegistry:
    """Create a new MCP registry."""
    return MCPRegistry(options)
