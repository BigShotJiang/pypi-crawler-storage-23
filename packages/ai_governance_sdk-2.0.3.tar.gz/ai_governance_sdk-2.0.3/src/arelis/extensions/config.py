"""Extension configuration for the Arelis AI SDK.

Ports extension configuration types from ``packages/sdk/src/config.ts``
in the TypeScript SDK.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from arelis.extensions.contracts import ExtensionCapabilityFlag

__all__ = [
    "ClientExtensionsConfig",
    "ComposedProofExtensionConfig",
    "ExtensionCapabilityConfig",
    "ExtensionEnforcementMode",
    "RiskRoutingExtensionConfig",
    "SnapshotReplayExtensionConfig",
]

# ---------------------------------------------------------------------------
# Extension enforcement mode
# ---------------------------------------------------------------------------

ExtensionEnforcementMode = Literal["off", "monitor", "enforce"]
"""Enforcement mode for extensions."""

# ---------------------------------------------------------------------------
# ExtensionCapabilityConfig
# ---------------------------------------------------------------------------


@dataclass
class ExtensionCapabilityConfig:
    """Configuration for an individual extension capability.

    Attributes:
        enabled: Whether the extension is enabled.
        mode: Enforcement mode.
    """

    enabled: bool | None = None
    mode: ExtensionEnforcementMode | None = None


# ---------------------------------------------------------------------------
# Composed proof extension config
# ---------------------------------------------------------------------------


@dataclass
class ComposedProofExtensionConfig:
    """Configuration for the composed compliance proofs extension.

    Attributes:
        enable_zk_mode: Whether to enable ZK mode.
        profile: Proof generation profile.
    """

    enable_zk_mode: bool | None = None
    profile: Literal["hash_only", "hash_and_zk"] | None = None


# ---------------------------------------------------------------------------
# Risk routing extension config
# ---------------------------------------------------------------------------


@dataclass
class RiskRoutingExtensionConfig:
    """Configuration for the risk-adaptive runtime routing extension.

    Attributes:
        mode: Whether routing is enabled.
        default_action: Default routing action.
    """

    mode: Literal["off", "enabled"] | None = None
    default_action: Literal["auto_execute", "sandbox", "require_approval", "block"] | None = None


# ---------------------------------------------------------------------------
# Snapshot replay extension config
# ---------------------------------------------------------------------------


@dataclass
class SnapshotReplayExtensionConfig:
    """Configuration for the time-bound snapshot replay extension.

    Attributes:
        capture_model_route: Whether to capture model route in snapshots.
        capture_tool_registry: Whether to capture tool registry in snapshots.
        capture_config_state: Whether to capture config state in snapshots.
    """

    capture_model_route: bool | None = None
    capture_tool_registry: bool | None = None
    capture_config_state: bool | None = None


# ---------------------------------------------------------------------------
# ClientExtensionsConfig
# ---------------------------------------------------------------------------


@dataclass
class ClientExtensionsConfig:
    """Client-level extension configuration.

    Attributes:
        capabilities: Per-capability configuration keyed by capability flag.
        composed_proofs: Composed proof extension configuration.
        risk_routing: Risk routing extension configuration.
        snapshot_replay: Snapshot replay extension configuration.
    """

    capabilities: dict[ExtensionCapabilityFlag, ExtensionCapabilityConfig] | None = None
    composed_proofs: ComposedProofExtensionConfig | None = None
    risk_routing: RiskRoutingExtensionConfig | None = None
    snapshot_replay: SnapshotReplayExtensionConfig | None = None
