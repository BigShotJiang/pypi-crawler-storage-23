"""Extension contracts for the Arelis AI SDK.

Ports ``packages/sdk/src/extension-contracts.ts`` from the TypeScript SDK.
Defines extension IDs, namespace contracts, and collision detection.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

__all__ = [
    "EXTENSION_NAMESPACE_CONTRACTS",
    "ExtensionCapabilityFlag",
    "ExtensionCollision",
    "ExtensionId",
    "ExtensionNamespaceContract",
    "detect_extension_contract_collisions",
    "extension_contract_by_id",
]

# ---------------------------------------------------------------------------
# Extension ID
# ---------------------------------------------------------------------------

ExtensionId = Literal[
    "foundation.policy_compiled_orchestration_cag_selective_disclosure",
    "extension.full_lifecycle_governance_audit_trail",
    "extension.agent_operated_governed_self_service",
    "extension.multi_layer_composed_compliance_proofs",
    "extension.risk_adaptive_runtime_routing",
    "extension.time_bound_snapshot_replay",
    "extension.policy_derived_selective_disclosure",
]
"""All known extension identifiers."""

# ---------------------------------------------------------------------------
# Extension capability flag
# ---------------------------------------------------------------------------

ExtensionCapabilityFlag = Literal[
    "foundationPolicyCompiledOrchestrationCagSelectiveDisclosure",
    "fullLifecycleGovernanceAuditTrail",
    "agentOperatedGovernedSelfService",
    "multiLayerComposedComplianceProofs",
    "riskAdaptiveRuntimeRouting",
    "timeBoundSnapshotReplay",
    "policyDerivedSelectiveDisclosure",
]
"""Capability flag names for extensions."""

# ---------------------------------------------------------------------------
# ExtensionNamespaceContract
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExtensionNamespaceContract:
    """Namespace contract for an extension.

    Defines additive extension boundaries so each feature can coexist
    without identifier collisions.

    Attributes:
        id: Extension identifier.
        capability_flag: Capability flag name.
        config_namespace: Configuration namespace.
        api_namespace: API namespace.
        event_prefixes: Event type prefixes.
        checkpoint_namespaces: Policy checkpoint namespaces.
        artifact_schemas: Compliance artifact schemas.
    """

    id: ExtensionId
    capability_flag: ExtensionCapabilityFlag
    config_namespace: str
    api_namespace: str
    event_prefixes: tuple[str, ...]
    checkpoint_namespaces: tuple[str, ...]
    artifact_schemas: tuple[str, ...]


# ---------------------------------------------------------------------------
# Contract registry
# ---------------------------------------------------------------------------

EXTENSION_NAMESPACE_CONTRACTS: tuple[ExtensionNamespaceContract, ...] = (
    ExtensionNamespaceContract(
        id="foundation.policy_compiled_orchestration_cag_selective_disclosure",
        capability_flag="foundationPolicyCompiledOrchestrationCagSelectiveDisclosure",
        config_namespace="extensions.foundation",
        api_namespace="foundation",
        event_prefixes=("policy.", "model.", "tool.", "orchestration."),
        checkpoint_namespaces=("BeforeOperation", "BeforePrompt", "AfterModelOutput"),
        artifact_schemas=("arelis.audit.compliance.v1",),
    ),
    ExtensionNamespaceContract(
        id="extension.full_lifecycle_governance_audit_trail",
        capability_flag="fullLifecycleGovernanceAuditTrail",
        config_namespace="extensions.fullLifecycleGovernanceAuditTrail",
        api_namespace="extensions.lifecycleAudit",
        event_prefixes=(
            "cli.command.",
            "infra.",
            "config.",
            "auth.",
            "mcp.server.",
            "mcp.tools.",
        ),
        checkpoint_namespaces=(
            "BeforeProvision",
            "BeforeDestroy",
            "BeforeConfigChange",
            "BeforeAuth",
        ),
        artifact_schemas=("arelis.audit.lifecycle.v1",),
    ),
    ExtensionNamespaceContract(
        id="extension.agent_operated_governed_self_service",
        capability_flag="agentOperatedGovernedSelfService",
        config_namespace="extensions.agentOperatedGovernedSelfService",
        api_namespace="extensions.agentGovernance",
        event_prefixes=("agent.step.", "agent.attestation.", "memory."),
        checkpoint_namespaces=("BeforeAgentStep",),
        artifact_schemas=("arelis.audit.agent-attestation.v1",),
    ),
    ExtensionNamespaceContract(
        id="extension.multi_layer_composed_compliance_proofs",
        capability_flag="multiLayerComposedComplianceProofs",
        config_namespace="extensions.multiLayerComposedComplianceProofs",
        api_namespace="extensions.composedProofs",
        event_prefixes=("compliance.proof.",),
        checkpoint_namespaces=(),
        artifact_schemas=("arelis.audit.compliance.composed.v2",),
    ),
    ExtensionNamespaceContract(
        id="extension.risk_adaptive_runtime_routing",
        capability_flag="riskAdaptiveRuntimeRouting",
        config_namespace="extensions.riskAdaptiveRuntimeRouting",
        api_namespace="extensions.riskRouting",
        event_prefixes=("risk.route.",),
        checkpoint_namespaces=(),
        artifact_schemas=("arelis.audit.risk-routing.v1",),
    ),
    ExtensionNamespaceContract(
        id="extension.time_bound_snapshot_replay",
        capability_flag="timeBoundSnapshotReplay",
        config_namespace="extensions.timeBoundSnapshotReplay",
        api_namespace="extensions.snapshotReplay",
        event_prefixes=("snapshot.", "replay."),
        checkpoint_namespaces=(),
        artifact_schemas=("arelis.audit.snapshot.bundle.v1",),
    ),
    ExtensionNamespaceContract(
        id="extension.policy_derived_selective_disclosure",
        capability_flag="policyDerivedSelectiveDisclosure",
        config_namespace="extensions.policyDerivedSelectiveDisclosure",
        api_namespace="extensions.policyDisclosureSynthesis",
        event_prefixes=("disclosure.derived.",),
        checkpoint_namespaces=(),
        artifact_schemas=("arelis.audit.disclosure.derived.v1",),
    ),
)
"""All extension namespace contracts."""


# ---------------------------------------------------------------------------
# Lookup by ID
# ---------------------------------------------------------------------------


def extension_contract_by_id(id: ExtensionId) -> ExtensionNamespaceContract:
    """Look up an extension namespace contract by its ID.

    Args:
        id: The extension ID to look up.

    Returns:
        The matching contract.

    Raises:
        ValueError: If the ID is not found.
    """
    for contract in EXTENSION_NAMESPACE_CONTRACTS:
        if contract.id == id:
            return contract
    raise ValueError(f"Unknown extension contract: {id}")


# ---------------------------------------------------------------------------
# Collision detection
# ---------------------------------------------------------------------------

CollisionType = Literal[
    "capabilityFlag",
    "configNamespace",
    "apiNamespace",
    "artifactSchema",
    "eventPrefix",
]


@dataclass
class ExtensionCollision:
    """Detected collision between two extension contracts.

    Attributes:
        type: Type of collision.
        value: The colliding value.
        left_id: First extension ID.
        right_id: Second extension ID.
    """

    type: CollisionType
    value: str
    left_id: ExtensionId
    right_id: ExtensionId


def detect_extension_contract_collisions(
    contracts: tuple[ExtensionNamespaceContract, ...] | None = None,
) -> list[ExtensionCollision]:
    """Detect identifier collisions between extension contracts.

    Checks capability flags, config namespaces, API namespaces,
    artifact schemas, and event prefixes for duplicates across
    different extensions.

    Args:
        contracts: Contracts to check. Defaults to
            :data:`EXTENSION_NAMESPACE_CONTRACTS`.

    Returns:
        A list of detected collisions (empty if none).
    """
    if contracts is None:
        contracts = EXTENSION_NAMESPACE_CONTRACTS

    collisions: list[ExtensionCollision] = []
    seen: dict[str, ExtensionId] = {}

    def _record(
        collision_type: CollisionType,
        values: tuple[str, ...] | list[str],
        contract_id: ExtensionId,
    ) -> None:
        for value in values:
            key = f"{collision_type}:{value}"
            existing = seen.get(key)
            if existing is not None and existing != contract_id:
                collisions.append(
                    ExtensionCollision(
                        type=collision_type,
                        value=value,
                        left_id=existing,
                        right_id=contract_id,
                    )
                )
            else:
                seen[key] = contract_id

    for contract in contracts:
        _record("capabilityFlag", (contract.capability_flag,), contract.id)
        _record("configNamespace", (contract.config_namespace,), contract.id)
        _record("apiNamespace", (contract.api_namespace,), contract.id)
        _record("artifactSchema", contract.artifact_schemas, contract.id)
        _record("eventPrefix", contract.event_prefixes, contract.id)

    return collisions


# ---------------------------------------------------------------------------
# Runtime validation: ExtensionCapabilityFlag vs EXTENSION_NAMESPACE_CONTRACTS
# ---------------------------------------------------------------------------
#
# ``ExtensionCapabilityFlag`` is manually maintained as a ``Literal`` union
# because Python's type system does not support deriving ``Literal`` types
# dynamically from runtime data.  The assertion below ensures it stays in
# sync with the actual capability flags present in
# ``EXTENSION_NAMESPACE_CONTRACTS``.
# ---------------------------------------------------------------------------

_CONTRACT_FLAGS: frozenset[str] = frozenset(
    c.capability_flag for c in EXTENSION_NAMESPACE_CONTRACTS
)
_LITERAL_FLAGS: frozenset[str] = frozenset(ExtensionCapabilityFlag.__args__)  # type: ignore[attr-defined]

assert _CONTRACT_FLAGS == _LITERAL_FLAGS, (
    "ExtensionCapabilityFlag Literal union is out of sync with "
    "EXTENSION_NAMESPACE_CONTRACTS. "
    f"Missing from Literal: {_CONTRACT_FLAGS - _LITERAL_FLAGS}. "
    f"Extra in Literal: {_LITERAL_FLAGS - _CONTRACT_FLAGS}."
)
