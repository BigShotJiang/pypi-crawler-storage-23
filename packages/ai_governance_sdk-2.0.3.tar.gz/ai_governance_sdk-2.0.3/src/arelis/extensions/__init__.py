"""Extensions module for the Arelis AI SDK.

Provides extension contracts, capability flags, namespace collision
detection, extension configuration types, the extension registry,
and runtime hook management.
"""

from __future__ import annotations

from arelis.extensions.config import (
    ClientExtensionsConfig,
    ComposedProofExtensionConfig,
    ExtensionCapabilityConfig,
    ExtensionEnforcementMode,
    RiskRoutingExtensionConfig,
    SnapshotReplayExtensionConfig,
)
from arelis.extensions.contracts import (
    EXTENSION_NAMESPACE_CONTRACTS,
    ExtensionCapabilityFlag,
    ExtensionCollision,
    ExtensionId,
    ExtensionNamespaceContract,
    detect_extension_contract_collisions,
    extension_contract_by_id,
)
from arelis.extensions.registry import (
    ExtensionRegistry,
    create_extension_registry,
)
from arelis.extensions.types import (
    ExtensionDescriptor,
    ExtensionHook,
    ExtensionHookContext,
    ExtensionLifecycle,
    ExtensionPointName,
    ExtensionStatus,
    ExtensionStatusInfo,
)

__all__ = [
    "EXTENSION_NAMESPACE_CONTRACTS",
    "ClientExtensionsConfig",
    "ComposedProofExtensionConfig",
    "ExtensionCapabilityConfig",
    "ExtensionCapabilityFlag",
    "ExtensionCollision",
    "ExtensionDescriptor",
    "ExtensionEnforcementMode",
    "ExtensionHook",
    "ExtensionHookContext",
    "ExtensionId",
    "ExtensionLifecycle",
    "ExtensionNamespaceContract",
    "ExtensionPointName",
    "ExtensionRegistry",
    "ExtensionStatus",
    "ExtensionStatusInfo",
    "RiskRoutingExtensionConfig",
    "SnapshotReplayExtensionConfig",
    "create_extension_registry",
    "detect_extension_contract_collisions",
    "extension_contract_by_id",
]
