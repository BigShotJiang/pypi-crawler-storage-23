"""Extension types for the Arelis AI SDK.

Defines types for the extension system including extension descriptors,
lifecycle hooks, capability queries, and status reporting.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal, Protocol

from arelis.extensions.config import ExtensionCapabilityConfig  # noqa: TC001 (runtime default)

if TYPE_CHECKING:
    from arelis.extensions.config import ExtensionEnforcementMode
    from arelis.extensions.contracts import (
        ExtensionCapabilityFlag,
        ExtensionId,
        ExtensionNamespaceContract,
    )

__all__ = [
    "ExtensionDescriptor",
    "ExtensionHook",
    "ExtensionHookContext",
    "ExtensionLifecycle",
    "ExtensionPointName",
    "ExtensionStatus",
    "ExtensionStatusInfo",
]

# ---------------------------------------------------------------------------
# Extension point names (hook attachment points)
# ---------------------------------------------------------------------------

ExtensionPointName = Literal[
    "before_prompt",
    "after_model_output",
    "before_tool_call",
    "after_tool_result",
    "before_persist",
    "before_operation",
    "before_provision",
    "before_destroy",
    "before_config_change",
    "before_auth",
    "before_agent_step",
]
"""Named extension points where hooks can be attached."""

# ---------------------------------------------------------------------------
# Extension status
# ---------------------------------------------------------------------------

ExtensionStatus = Literal["registered", "enabled", "disabled"]
"""Runtime status of an extension."""

# ---------------------------------------------------------------------------
# ExtensionHookContext
# ---------------------------------------------------------------------------


@dataclass
class ExtensionHookContext:
    """Context passed to extension hooks at runtime.

    Attributes:
        extension_id: The extension that owns this hook.
        point: The extension point being executed.
        run_id: The current run ID, if available.
        metadata: Arbitrary metadata for the hook.
    """

    extension_id: ExtensionId
    point: ExtensionPointName
    run_id: str | None = None
    metadata: dict[str, object] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Extension hook callable
# ---------------------------------------------------------------------------

ExtensionHook = Callable[[ExtensionHookContext], Awaitable[None]]
"""Async callable invoked at an extension point."""

# ---------------------------------------------------------------------------
# ExtensionLifecycle protocol
# ---------------------------------------------------------------------------


class ExtensionLifecycle(Protocol):
    """Protocol for extension lifecycle management.

    Extensions that need setup/teardown can implement this protocol.
    """

    async def on_enable(self) -> None:
        """Called when the extension is enabled."""
        ...

    async def on_disable(self) -> None:
        """Called when the extension is disabled."""
        ...


# ---------------------------------------------------------------------------
# ExtensionDescriptor
# ---------------------------------------------------------------------------


@dataclass
class ExtensionDescriptor:
    """Descriptor for a registered extension.

    Combines the namespace contract with runtime hooks, capability config,
    and optional lifecycle management.

    Attributes:
        contract: The namespace contract for this extension.
        capability_config: The capability configuration (enabled, mode).
        hooks: Mapping of extension points to hook callables.
        lifecycle: Optional lifecycle handler for setup/teardown.
        status: Current runtime status.
    """

    contract: ExtensionNamespaceContract
    capability_config: ExtensionCapabilityConfig = field(
        default_factory=ExtensionCapabilityConfig,
    )
    hooks: dict[ExtensionPointName, list[ExtensionHook]] = field(
        default_factory=dict,
    )
    lifecycle: ExtensionLifecycle | None = None
    status: ExtensionStatus = "registered"


# ---------------------------------------------------------------------------
# ExtensionStatusInfo
# ---------------------------------------------------------------------------


@dataclass
class ExtensionStatusInfo:
    """Status report for an extension.

    Attributes:
        id: Extension identifier.
        capability_flag: Capability flag name.
        status: Current runtime status.
        mode: Enforcement mode, if configured.
        hook_count: Number of registered hooks across all points.
    """

    id: ExtensionId
    capability_flag: ExtensionCapabilityFlag
    status: ExtensionStatus
    mode: ExtensionEnforcementMode | None = None
    hook_count: int = 0
