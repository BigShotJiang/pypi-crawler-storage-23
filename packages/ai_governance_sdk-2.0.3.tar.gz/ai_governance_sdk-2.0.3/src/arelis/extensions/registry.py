"""Extension registry for the Arelis AI SDK.

Provides the ``ExtensionRegistry`` class that manages extension registration,
enablement, capability queries, hook execution, and collision detection.
"""

from __future__ import annotations

from arelis.extensions.config import (
    ClientExtensionsConfig,
    ExtensionCapabilityConfig,
    ExtensionEnforcementMode,
)
from arelis.extensions.contracts import (
    EXTENSION_NAMESPACE_CONTRACTS,
    ExtensionCapabilityFlag,
    ExtensionCollision,
    ExtensionId,
    ExtensionNamespaceContract,
    detect_extension_contract_collisions,
    extension_contract_by_id,
)
from arelis.extensions.types import (
    ExtensionDescriptor,
    ExtensionHook,
    ExtensionHookContext,
    ExtensionPointName,
    ExtensionStatusInfo,
)

__all__ = [
    "ExtensionRegistry",
    "create_extension_registry",
]


# ---------------------------------------------------------------------------
# ExtensionRegistry
# ---------------------------------------------------------------------------


class ExtensionRegistry:
    """Registry that manages the lifecycle of SDK extensions.

    Handles registration, enablement/disablement, capability queries,
    hook management, and collision detection.

    Args:
        config: Optional client extensions configuration to apply
            on construction.
    """

    def __init__(self, config: ClientExtensionsConfig | None = None) -> None:
        self._extensions: dict[ExtensionId, ExtensionDescriptor] = {}
        self._config = config

        if config is not None:
            self._apply_config(config)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self,
        extension_id: ExtensionId,
        *,
        capability_config: ExtensionCapabilityConfig | None = None,
    ) -> ExtensionDescriptor:
        """Register an extension by its ID.

        The extension's namespace contract is looked up from the built-in
        contracts table.  If a ``capability_config`` is provided it overrides
        whatever was set via ``ClientExtensionsConfig``.

        Args:
            extension_id: The extension ID to register.
            capability_config: Optional capability config override.

        Returns:
            The created extension descriptor.

        Raises:
            ValueError: If the extension is already registered.
        """
        if extension_id in self._extensions:
            raise ValueError(f"Extension already registered: {extension_id}")

        contract = extension_contract_by_id(extension_id)

        resolved_config = capability_config
        if resolved_config is None and self._config is not None:
            caps = self._config.capabilities
            if caps is not None:
                resolved_config = caps.get(contract.capability_flag)

        descriptor = ExtensionDescriptor(
            contract=contract,
            capability_config=resolved_config or ExtensionCapabilityConfig(),
        )
        self._extensions[extension_id] = descriptor
        return descriptor

    def register_contract(
        self,
        contract: ExtensionNamespaceContract,
        *,
        capability_config: ExtensionCapabilityConfig | None = None,
    ) -> ExtensionDescriptor:
        """Register an extension from an explicit contract.

        Useful for custom contracts not in the built-in table.

        Args:
            contract: The namespace contract.
            capability_config: Optional capability config.

        Returns:
            The created extension descriptor.

        Raises:
            ValueError: If the extension is already registered.
        """
        if contract.id in self._extensions:
            raise ValueError(f"Extension already registered: {contract.id}")

        descriptor = ExtensionDescriptor(
            contract=contract,
            capability_config=capability_config or ExtensionCapabilityConfig(),
        )
        self._extensions[contract.id] = descriptor
        return descriptor

    def unregister(self, extension_id: ExtensionId) -> None:
        """Unregister an extension.

        Args:
            extension_id: The extension ID to remove.

        Raises:
            KeyError: If the extension is not registered.
        """
        if extension_id not in self._extensions:
            raise KeyError(f"Extension not registered: {extension_id}")
        del self._extensions[extension_id]

    # ------------------------------------------------------------------
    # Enable / disable
    # ------------------------------------------------------------------

    async def enable(self, extension_id: ExtensionId) -> None:
        """Enable a registered extension.

        If the extension implements :class:`ExtensionLifecycle`, its
        ``on_enable`` callback is invoked.

        Args:
            extension_id: The extension to enable.

        Raises:
            KeyError: If the extension is not registered.
        """
        descriptor = self._get_descriptor(extension_id)
        descriptor.status = "enabled"
        descriptor.capability_config = ExtensionCapabilityConfig(
            enabled=True,
            mode=descriptor.capability_config.mode,
        )
        if descriptor.lifecycle is not None:
            await descriptor.lifecycle.on_enable()

    async def disable(self, extension_id: ExtensionId) -> None:
        """Disable a registered extension.

        If the extension implements :class:`ExtensionLifecycle`, its
        ``on_disable`` callback is invoked.

        Args:
            extension_id: The extension to disable.

        Raises:
            KeyError: If the extension is not registered.
        """
        descriptor = self._get_descriptor(extension_id)
        descriptor.status = "disabled"
        descriptor.capability_config = ExtensionCapabilityConfig(
            enabled=False,
            mode=descriptor.capability_config.mode,
        )
        if descriptor.lifecycle is not None:
            await descriptor.lifecycle.on_disable()

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def is_registered(self, extension_id: ExtensionId) -> bool:
        """Check whether an extension is registered.

        Args:
            extension_id: The extension to check.

        Returns:
            ``True`` if the extension is registered.
        """
        return extension_id in self._extensions

    def is_enabled(self, extension_id: ExtensionId) -> bool:
        """Check whether an extension is enabled.

        An extension is considered enabled if its ``capability_config.enabled``
        is ``True`` **or** its status is ``"enabled"``.

        Args:
            extension_id: The extension to check.

        Returns:
            ``True`` if the extension is registered and enabled.
        """
        descriptor = self._extensions.get(extension_id)
        if descriptor is None:
            return False
        if descriptor.capability_config.enabled is True:
            return True
        return descriptor.status == "enabled"

    def is_capability_enabled(self, flag: ExtensionCapabilityFlag) -> bool:
        """Check whether a capability flag is enabled.

        Looks up the extension associated with the given capability flag
        and returns whether it is enabled.

        Args:
            flag: The capability flag to check.

        Returns:
            ``True`` if the capability is enabled.
        """
        for descriptor in self._extensions.values():
            if descriptor.contract.capability_flag == flag:
                return self.is_enabled(descriptor.contract.id)
        return False

    def get_enforcement_mode(
        self,
        extension_id: ExtensionId,
    ) -> ExtensionEnforcementMode | None:
        """Get the enforcement mode for an extension.

        Args:
            extension_id: The extension to query.

        Returns:
            The enforcement mode, or ``None`` if not registered or not set.
        """
        descriptor = self._extensions.get(extension_id)
        if descriptor is None:
            return None
        return descriptor.capability_config.mode

    def get_descriptor(self, extension_id: ExtensionId) -> ExtensionDescriptor | None:
        """Get the descriptor for an extension.

        Args:
            extension_id: The extension to look up.

        Returns:
            The descriptor, or ``None`` if not registered.
        """
        return self._extensions.get(extension_id)

    def list_registered(self) -> list[ExtensionId]:
        """List all registered extension IDs.

        Returns:
            A list of registered extension IDs.
        """
        return list(self._extensions.keys())

    def list_enabled(self) -> list[ExtensionId]:
        """List all enabled extension IDs.

        Returns:
            A list of enabled extension IDs.
        """
        return [eid for eid in self._extensions if self.is_enabled(eid)]

    def get_status(self) -> list[ExtensionStatusInfo]:
        """Get status information for all registered extensions.

        Returns:
            A list of status info objects.
        """
        result: list[ExtensionStatusInfo] = []
        for descriptor in self._extensions.values():
            hook_count = sum(len(hooks) for hooks in descriptor.hooks.values())
            result.append(
                ExtensionStatusInfo(
                    id=descriptor.contract.id,
                    capability_flag=descriptor.contract.capability_flag,
                    status=descriptor.status,
                    mode=descriptor.capability_config.mode,
                    hook_count=hook_count,
                )
            )
        return result

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    def add_hook(
        self,
        extension_id: ExtensionId,
        point: ExtensionPointName,
        hook: ExtensionHook,
    ) -> None:
        """Attach a hook to an extension at the given extension point.

        Args:
            extension_id: The owning extension.
            point: The extension point to attach to.
            hook: The async hook callable.

        Raises:
            KeyError: If the extension is not registered.
        """
        descriptor = self._get_descriptor(extension_id)
        if point not in descriptor.hooks:
            descriptor.hooks[point] = []
        descriptor.hooks[point].append(hook)

    def remove_hook(
        self,
        extension_id: ExtensionId,
        point: ExtensionPointName,
        hook: ExtensionHook,
    ) -> None:
        """Remove a previously attached hook.

        Args:
            extension_id: The owning extension.
            point: The extension point.
            hook: The hook to remove.

        Raises:
            KeyError: If the extension is not registered.
            ValueError: If the hook is not found at the given point.
        """
        descriptor = self._get_descriptor(extension_id)
        hooks = descriptor.hooks.get(point)
        if hooks is None or hook not in hooks:
            raise ValueError(f"Hook not found at point '{point}' for extension '{extension_id}'")
        hooks.remove(hook)
        if not hooks:
            del descriptor.hooks[point]

    async def execute_hooks(
        self,
        point: ExtensionPointName,
        *,
        run_id: str | None = None,
        metadata: dict[str, object] | None = None,
    ) -> None:
        """Execute all hooks for enabled extensions at the given point.

        Hooks are executed in registration order.  Only hooks belonging to
        enabled extensions are invoked.

        Args:
            point: The extension point to execute.
            run_id: Optional run ID for context.
            metadata: Optional metadata passed to each hook.
        """
        for extension_id, descriptor in self._extensions.items():
            if not self.is_enabled(extension_id):
                continue
            hooks = descriptor.hooks.get(point)
            if hooks is None:
                continue
            for hook in hooks:
                ctx = ExtensionHookContext(
                    extension_id=extension_id,
                    point=point,
                    run_id=run_id,
                    metadata=metadata or {},
                )
                await hook(ctx)

    # ------------------------------------------------------------------
    # Collision detection
    # ------------------------------------------------------------------

    def detect_collisions(self) -> list[ExtensionCollision]:
        """Detect namespace collisions among registered extensions.

        Returns:
            A list of collisions (empty if none).
        """
        contracts = tuple(d.contract for d in self._extensions.values())
        return detect_extension_contract_collisions(contracts)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_descriptor(self, extension_id: ExtensionId) -> ExtensionDescriptor:
        """Look up a descriptor, raising ``KeyError`` if missing."""
        descriptor = self._extensions.get(extension_id)
        if descriptor is None:
            raise KeyError(f"Extension not registered: {extension_id}")
        return descriptor

    def _apply_config(self, config: ClientExtensionsConfig) -> None:
        """Pre-register extensions whose capabilities are configured.

        For each capability flag present in ``config.capabilities`` that
        maps to a known contract, the extension is registered with the
        given config.
        """
        if config.capabilities is None:
            return

        for contract in EXTENSION_NAMESPACE_CONTRACTS:
            cap_config = config.capabilities.get(contract.capability_flag)
            if cap_config is not None and contract.id not in self._extensions:
                descriptor = ExtensionDescriptor(
                    contract=contract,
                    capability_config=cap_config,
                )
                if cap_config.enabled is True:
                    descriptor.status = "enabled"
                self._extensions[contract.id] = descriptor


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------


def create_extension_registry(
    config: ClientExtensionsConfig | None = None,
) -> ExtensionRegistry:
    """Create an :class:`ExtensionRegistry`.

    Args:
        config: Optional client extensions configuration.

    Returns:
        A new extension registry instance.
    """
    return ExtensionRegistry(config=config)
