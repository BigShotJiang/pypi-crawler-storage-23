"""OpenTelemetry adapter for the Arelis AI SDK.

Wraps the ``opentelemetry-api`` package to implement the :class:`Telemetry`
protocol. The ``opentelemetry`` package is an optional dependency -- if it is
not installed, importing this module will raise :class:`ImportError`.

Install via::

    pip install "ai-governance-sdk[otel]"
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TypeVar

from arelis.telemetry.types import (
    SpanAttributes,
    SpanHandle,
    SpanStatusCode,
    Telemetry,
    create_context_attributes,
)

try:
    from opentelemetry import context as otel_context
    from opentelemetry import trace
    from opentelemetry.trace import Span as OTelSpan
    from opentelemetry.trace import StatusCode as OTelStatusCode
    from opentelemetry.trace import Tracer
except ImportError as _err:
    raise ImportError(
        "The 'opentelemetry-api' package is required to use the OTel adapter. "
        'Install it with: pip install "ai-governance-sdk[otel]"'
    ) from _err

__all__ = [
    "OTelAdapter",
    "OTelAdapterConfig",
    "OTelSpanHandle",
    "create_otel_adapter",
]

_T = TypeVar("_T")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class OTelAdapterConfig:
    """Configuration for the OpenTelemetry adapter."""

    tracer_name: str = "arelis-sdk"
    """Tracer name registered with OpenTelemetry."""

    tracer_version: str = "0.1.0"
    """Tracer version string."""

    default_attributes: SpanAttributes | None = None
    """Default attributes to add to all spans."""


# ---------------------------------------------------------------------------
# Span handle wrapping an OTel Span
# ---------------------------------------------------------------------------


def _clean_attributes(
    attributes: SpanAttributes | None,
) -> dict[str, str | int | float | bool] | None:
    """Remove ``None`` values from attribute dicts."""
    if attributes is None:
        return None
    cleaned: dict[str, str | int | float | bool] = {}
    for key, value in attributes.items():
        if value is not None:
            cleaned[key] = value
    return cleaned if cleaned else None


class OTelSpanHandle:
    """Span handle implementation backed by an OpenTelemetry span."""

    __slots__ = ("_span",)

    def __init__(self, span: OTelSpan) -> None:
        self._span = span

    def end(self) -> None:
        """End the span."""
        self._span.end()

    def add_event(self, name: str, attributes: SpanAttributes | None = None) -> None:
        """Add an event to the span."""
        cleaned = _clean_attributes(attributes)
        if cleaned is not None:
            self._span.add_event(name, attributes=cleaned)
        else:
            self._span.add_event(name)

    def set_attribute(self, key: str, value: str | int | float | bool) -> None:
        """Set an attribute on the span."""
        self._span.set_attribute(key, value)

    def record_error(self, error: BaseException) -> None:
        """Record an error on the span and set ERROR status."""
        self._span.record_exception(error)
        self._span.set_status(OTelStatusCode.ERROR, str(error))

    def set_status(self, code: SpanStatusCode, message: str | None = None) -> None:
        """Set the span status."""
        otel_code = OTelStatusCode.OK if code == "ok" else OTelStatusCode.ERROR
        self._span.set_status(otel_code, message)


# ---------------------------------------------------------------------------
# OTel Adapter implementing the Telemetry protocol
# ---------------------------------------------------------------------------


class OTelAdapter:
    """OpenTelemetry telemetry adapter.

    Implements the :class:`Telemetry` protocol by delegating to an
    OpenTelemetry :class:`Tracer`.
    """

    def __init__(self, config: OTelAdapterConfig | None = None) -> None:
        cfg = config or OTelAdapterConfig()
        self._tracer: Tracer = trace.get_tracer(cfg.tracer_name, cfg.tracer_version)
        self._default_attributes: SpanAttributes = cfg.default_attributes or {}

    # -- Telemetry protocol -------------------------------------------------

    def start_span(self, name: str, attributes: SpanAttributes | None = None) -> SpanHandle:
        """Start a new span."""
        merged: SpanAttributes = {**self._default_attributes, **(attributes or {})}
        cleaned = _clean_attributes(merged)
        span = self._tracer.start_span(name, attributes=cleaned)
        return OTelSpanHandle(span)

    def add_event(self, name: str, attributes: SpanAttributes | None = None) -> None:
        """Add an event to the currently active span."""
        current_span = trace.get_current_span()
        if current_span is not None and current_span.is_recording():
            cleaned = _clean_attributes(attributes)
            if cleaned is not None:
                current_span.add_event(name, attributes=cleaned)
            else:
                current_span.add_event(name)

    def context_attributes(self, context: object) -> SpanAttributes:
        """Create standard attributes from governance context."""
        return create_context_attributes(context)

    # -- Extended helpers (not part of base Telemetry protocol) ---------------

    async def with_span(
        self,
        name: str,
        attributes: SpanAttributes | None,
        fn: Callable[[SpanHandle], Awaitable[_T]],
    ) -> _T:
        """Run an async function within a new span.

        Sets status to ``ok`` on success, records the error and re-raises on
        failure. The span is always ended.
        """
        span = self.start_span(name, attributes)
        try:
            result = await fn(span)
            span.set_status("ok")
            return result
        except BaseException as exc:
            span.record_error(exc)
            raise
        finally:
            span.end()

    def with_span_sync(
        self,
        name: str,
        attributes: SpanAttributes | None,
        fn: Callable[[SpanHandle], _T],
    ) -> _T:
        """Run a synchronous function within a new span.

        Sets status to ``ok`` on success, records the error and re-raises on
        failure. The span is always ended.
        """
        span = self.start_span(name, attributes)
        try:
            result = fn(span)
            span.set_status("ok")
            return result
        except BaseException as exc:
            span.record_error(exc)
            raise
        finally:
            span.end()

    def get_active_context(self) -> object:
        """Return the active OpenTelemetry context."""
        return otel_context.get_current()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_otel_adapter(config: OTelAdapterConfig | None = None) -> Telemetry:
    """Create an OpenTelemetry adapter."""
    return OTelAdapter(config)
