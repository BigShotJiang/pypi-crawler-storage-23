"""Telemetry module for the Arelis AI SDK.

Provides the :class:`Telemetry` protocol and implementations:

- :class:`NoOpTelemetry` -- default, discards all data
- :class:`OTelAdapter` -- wraps ``opentelemetry-api`` (requires ``ai-governance-sdk[otel]``)
"""

from __future__ import annotations

from arelis.telemetry.noop import (
    NoOpSpanHandle,
    NoOpTelemetry,
    create_noop_telemetry,
)
from arelis.telemetry.types import (
    EventNames,
    SpanAttributes,
    SpanHandle,
    SpanNames,
    SpanStatusCode,
    Telemetry,
    create_agent_step_attributes,
    create_context_attributes,
    create_model_attributes,
    create_tool_attributes,
)

__all__ = [
    # Protocols and types
    "EventNames",
    "SpanAttributes",
    "SpanHandle",
    "SpanNames",
    "SpanStatusCode",
    "Telemetry",
    # Attribute helpers
    "create_agent_step_attributes",
    "create_context_attributes",
    "create_model_attributes",
    "create_tool_attributes",
    # No-op implementation
    "NoOpSpanHandle",
    "NoOpTelemetry",
    "create_noop_telemetry",
    # OTel adapter is imported lazily to avoid hard dependency on opentelemetry
    # Use: from arelis.telemetry.otel import OTelAdapter, create_otel_adapter
]
