"""No-op telemetry implementation.

Provides ``NoOpTelemetry`` and ``NoOpSpanHandle`` that silently discard all
telemetry data. Used as the default when no OpenTelemetry SDK is configured.
"""

from __future__ import annotations

from arelis.telemetry.types import (
    SpanAttributes,
    SpanHandle,
    SpanStatusCode,
    Telemetry,
    create_context_attributes,
)

__all__ = [
    "NoOpSpanHandle",
    "NoOpTelemetry",
    "create_noop_telemetry",
]


# ---------------------------------------------------------------------------
# No-op span handle
# ---------------------------------------------------------------------------


class NoOpSpanHandle:
    """Span handle that does nothing."""

    __slots__ = ()

    def end(self) -> None:
        """No-op."""

    def add_event(self, _name: str, _attributes: SpanAttributes | None = None) -> None:
        """No-op."""

    def set_attribute(self, _key: str, _value: str | int | float | bool) -> None:
        """No-op."""

    def record_error(self, _error: BaseException) -> None:
        """No-op."""

    def set_status(self, _code: SpanStatusCode, _message: str | None = None) -> None:
        """No-op."""


# ---------------------------------------------------------------------------
# No-op telemetry
# ---------------------------------------------------------------------------


class NoOpTelemetry:
    """Telemetry implementation that silently discards all data."""

    def __init__(self) -> None:
        self._span_handle = NoOpSpanHandle()

    def start_span(self, _name: str, _attributes: SpanAttributes | None = None) -> SpanHandle:
        """Return a no-op span handle."""
        return self._span_handle

    def add_event(self, _name: str, _attributes: SpanAttributes | None = None) -> None:
        """No-op."""

    def context_attributes(self, context: object) -> SpanAttributes:
        """Create standard attributes from governance context."""
        return create_context_attributes(context)


# ---------------------------------------------------------------------------
# Singleton factory
# ---------------------------------------------------------------------------

_noop_telemetry_instance: NoOpTelemetry | None = None


def create_noop_telemetry() -> Telemetry:
    """Create a no-op telemetry instance (singleton).

    Returns the same instance on repeated calls.
    """
    global _noop_telemetry_instance  # noqa: PLW0603
    if _noop_telemetry_instance is None:
        _noop_telemetry_instance = NoOpTelemetry()
    return _noop_telemetry_instance
