"""Telemetry types and protocols for the Arelis AI SDK.

Ports types from the TypeScript SDK's `packages/telemetry-otel/src/telemetry.ts`:
Telemetry protocol, SpanHandle protocol, SpanAttributes type alias, standard span/event
names, and helper functions for creating span attributes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol, runtime_checkable

__all__ = [
    "EventNames",
    "SpanAttributes",
    "SpanHandle",
    "SpanNames",
    "SpanStatusCode",
    "Telemetry",
    "create_agent_step_attributes",
    "create_context_attributes",
    "create_model_attributes",
    "create_tool_attributes",
]

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

SpanAttributes = dict[str, str | int | float | bool]
"""Span attributes for telemetry. Values may be str, int, float, or bool."""

SpanStatusCode = Literal["ok", "error"]
"""Span status code."""


# ---------------------------------------------------------------------------
# SpanHandle protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class SpanHandle(Protocol):
    """Handle to an active telemetry span."""

    def end(self) -> None:
        """End the span."""
        ...

    def add_event(self, name: str, attributes: SpanAttributes | None = None) -> None:
        """Add an event to the span."""
        ...

    def set_attribute(self, key: str, value: str | int | float | bool) -> None:
        """Set an attribute on the span."""
        ...

    def record_error(self, error: BaseException) -> None:
        """Record an error on the span."""
        ...

    def set_status(self, code: SpanStatusCode, message: str | None = None) -> None:
        """Set the span status."""
        ...


# ---------------------------------------------------------------------------
# Telemetry protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class Telemetry(Protocol):
    """Telemetry interface for spans and events."""

    def start_span(self, name: str, attributes: SpanAttributes | None = None) -> SpanHandle:
        """Start a new span."""
        ...

    def add_event(self, name: str, attributes: SpanAttributes | None = None) -> None:
        """Add an event to the current span."""
        ...

    def context_attributes(self, context: object) -> SpanAttributes:
        """Create standard attributes from governance context.

        Accepts any object with org, actor, purpose, environment, and optional
        team/session_id/request_id attributes.
        """
        ...


# ---------------------------------------------------------------------------
# Standard span names
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _SpanNames:
    """Standard span names used by the SDK."""

    RUN: str = field(default="arelis.run", init=False)
    MODEL_GENERATE: str = field(default="arelis.model.generate", init=False)
    TOOL_INVOKE: str = field(default="arelis.tool.invoke", init=False)
    AGENT_STEP: str = field(default="arelis.agent.step", init=False)
    MODEL_RESOLVE: str = field(default="arelis.model.resolve", init=False)
    MODEL_STREAM: str = field(default="arelis.model.stream", init=False)
    EVALUATION_RUN: str = field(default="arelis.evaluation.run", init=False)
    QUOTA_CHECK: str = field(default="arelis.quota.check", init=False)
    OUTPUT_VALIDATE: str = field(default="arelis.output.validate", init=False)
    MEMORY_WRITE: str = field(default="arelis.memory.write", init=False)
    DATA_READ: str = field(default="arelis.data.read", init=False)
    APPROVAL_REQUEST: str = field(default="arelis.approval.request", init=False)


SpanNames = _SpanNames()
"""Singleton instance of standard span names."""


# ---------------------------------------------------------------------------
# Standard event names
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _EventNames:
    """Standard event names used by the SDK."""

    POLICY_DECISION: str = field(default="policy.decision", init=False)
    REDACTION_APPLIED: str = field(default="redaction.applied", init=False)
    TOOL_PERMISSION_DENIED: str = field(default="tool.permission.denied", init=False)
    COMPLIANCE_PROOF_GENERATED: str = field(default="compliance.proof.generated", init=False)
    COMPLIANCE_PROOF_VERIFIED: str = field(default="compliance.proof.verified", init=False)


EventNames = _EventNames()
"""Singleton instance of standard event names."""


# ---------------------------------------------------------------------------
# Attribute helper functions
# ---------------------------------------------------------------------------


def create_context_attributes(context: object) -> SpanAttributes:
    """Create standard attributes from a governance context.

    Accepts any object with org, actor, purpose, environment, and optional
    team, session_id, and request_id attributes (e.g., ``GovernanceContext``).
    """
    org = getattr(context, "org", None)
    actor = getattr(context, "actor", None)

    attrs: SpanAttributes = {
        "arelis.org.id": getattr(org, "id", "") if org is not None else "",
        "arelis.actor.type": getattr(actor, "type", "") if actor is not None else "",
        "arelis.actor.id": getattr(actor, "id", "") if actor is not None else "",
        "arelis.purpose": str(getattr(context, "purpose", "")),
        "arelis.environment": str(getattr(context, "environment", "")),
    }

    if org is not None:
        org_name = getattr(org, "name", None)
        if org_name is not None:
            attrs["arelis.org.name"] = str(org_name)

    team = getattr(context, "team", None)
    if team is not None:
        attrs["arelis.team.id"] = str(getattr(team, "id", ""))
        team_name = getattr(team, "name", None)
        if team_name is not None:
            attrs["arelis.team.name"] = str(team_name)

    session_id = getattr(context, "session_id", None)
    if session_id is not None:
        attrs["arelis.session.id"] = str(session_id)

    request_id = getattr(context, "request_id", None)
    if request_id is not None:
        attrs["arelis.request.id"] = str(request_id)

    return attrs


def create_model_attributes(model_id: str, provider: str | None = None) -> SpanAttributes:
    """Create model-specific attributes."""
    attrs: SpanAttributes = {"arelis.model.id": model_id}
    if provider is not None:
        attrs["arelis.model.provider"] = provider
    return attrs


def create_tool_attributes(tool_name: str) -> SpanAttributes:
    """Create tool-specific attributes."""
    return {"arelis.tool.name": tool_name}


def create_agent_step_attributes(step_number: int, step_type: str) -> SpanAttributes:
    """Create agent step attributes."""
    return {
        "arelis.agent.step.number": step_number,
        "arelis.agent.step.type": step_type,
    }
