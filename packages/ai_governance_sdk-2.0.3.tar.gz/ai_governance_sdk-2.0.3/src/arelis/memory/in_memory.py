"""In-memory memory provider implementation.

Ports `packages/memory/src/providers/in-memory.ts` from the TypeScript SDK.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from arelis.memory.types import MemoryContext, MemoryEntry, MemoryScope

__all__ = [
    "InMemoryMemoryProvider",
    "create_in_memory_memory_provider",
]


class InMemoryMemoryProvider:
    """In-memory implementation of the MemoryProvider protocol.

    Stores entries in a plain dictionary keyed by ``{scope}::{key}``.
    Suitable for testing and lightweight use cases.
    """

    def __init__(self, id: str = "memory") -> None:
        self._id = id
        self._entries: dict[str, MemoryEntry] = {}

    @property
    def id(self) -> str:
        """Provider identifier."""
        return self._id

    async def read(
        self,
        scope: MemoryScope,
        key: str,
        _context: MemoryContext,
    ) -> MemoryEntry | None:
        """Read a memory entry by scope and key."""
        return self._entries.get(self._make_key(scope, key))

    async def write(
        self,
        scope: MemoryScope,
        key: str,
        value: object,
        _context: MemoryContext,
        metadata: dict[str, object] | None = None,
    ) -> MemoryEntry:
        """Write a memory entry."""
        now = datetime.now(timezone.utc).isoformat()
        existing = self._entries.get(self._make_key(scope, key))

        entry = MemoryEntry(
            id=existing.id if existing is not None else str(uuid.uuid4()),
            scope=scope,
            key=key,
            value=value,
            created_at=existing.created_at if existing is not None else now,
            updated_at=now,
            metadata=metadata
            if metadata is not None
            else (existing.metadata if existing is not None else None),
        )

        self._entries[self._make_key(scope, key)] = entry
        return entry

    async def delete(
        self,
        scope: MemoryScope,
        key: str,
        _context: MemoryContext,
    ) -> bool:
        """Delete a memory entry. Returns True if the entry existed."""
        composite_key = self._make_key(scope, key)
        if composite_key in self._entries:
            del self._entries[composite_key]
            return True
        return False

    async def list(
        self,
        scope: MemoryScope,
        _context: MemoryContext,
    ) -> list[MemoryEntry]:
        """List all memory entries for a given scope."""
        return [entry for entry in self._entries.values() if entry.scope == scope]

    def _make_key(self, scope: MemoryScope, key: str) -> str:
        """Create a composite storage key from scope and key."""
        return f"{scope}::{key}"


def create_in_memory_memory_provider(id: str = "memory") -> InMemoryMemoryProvider:
    """Create an in-memory memory provider."""
    return InMemoryMemoryProvider(id)
