"""Memory provider protocol.

Ports the MemoryProvider interface from the TypeScript SDK.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from arelis.memory.types import MemoryContext, MemoryEntry, MemoryScope

__all__ = [
    "MemoryProvider",
]


@runtime_checkable
class MemoryProvider(Protocol):
    """Memory provider interface.

    Implementations provide scoped key-value storage for agent memory.
    """

    @property
    def id(self) -> str:
        """Provider identifier."""
        ...

    async def read(
        self,
        scope: MemoryScope,
        key: str,
        context: MemoryContext,
    ) -> MemoryEntry | None:
        """Read a memory entry by scope and key."""
        ...

    async def write(
        self,
        scope: MemoryScope,
        key: str,
        value: object,
        context: MemoryContext,
        metadata: dict[str, object] | None = None,
    ) -> MemoryEntry:
        """Write a memory entry."""
        ...

    async def delete(
        self,
        scope: MemoryScope,
        key: str,
        context: MemoryContext,
    ) -> bool:
        """Delete a memory entry. Returns True if the entry existed."""
        ...

    async def list(
        self,
        scope: MemoryScope,
        context: MemoryContext,
    ) -> list[MemoryEntry]:
        """List all memory entries for a given scope."""
        ...
