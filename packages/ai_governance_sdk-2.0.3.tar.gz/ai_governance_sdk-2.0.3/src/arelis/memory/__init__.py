"""Memory module for the Arelis AI SDK.

Provides scoped key-value memory storage for agents with pluggable providers.
"""

from __future__ import annotations

from arelis.memory.in_memory import (
    InMemoryMemoryProvider,
    create_in_memory_memory_provider,
)
from arelis.memory.provider import MemoryProvider
from arelis.memory.registry import (
    MemoryRegistry,
    create_memory_registry,
)
from arelis.memory.types import (
    MemoryContext,
    MemoryEntry,
    MemoryScope,
)

__all__ = [
    "InMemoryMemoryProvider",
    "MemoryContext",
    "MemoryEntry",
    "MemoryProvider",
    "MemoryRegistry",
    "MemoryScope",
    "create_in_memory_memory_provider",
    "create_memory_registry",
]
