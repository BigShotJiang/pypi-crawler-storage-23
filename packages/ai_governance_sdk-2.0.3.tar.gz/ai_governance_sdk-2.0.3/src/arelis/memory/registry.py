"""Memory provider registry.

Ports `packages/memory/src/memory-registry.ts` from the TypeScript SDK.
"""

from __future__ import annotations

from arelis.memory.provider import MemoryProvider

__all__ = [
    "MemoryRegistry",
    "create_memory_registry",
]


class MemoryRegistry:
    """Registry for memory providers."""

    def __init__(self) -> None:
        self._providers: dict[str, MemoryProvider] = {}

    def register(
        self,
        provider: MemoryProvider,
        replace: bool = False,
    ) -> None:
        """Register a memory provider.

        Args:
            provider: The memory provider to register.
            replace: If True, allows overwriting an existing registration.

        Raises:
            ValueError: If the provider ID is already registered and replace is False.
        """
        if provider.id in self._providers and not replace:
            raise ValueError(f'Memory provider "{provider.id}" is already registered')
        self._providers[provider.id] = provider

    def get(self, id: str) -> MemoryProvider | None:
        """Get a memory provider by ID."""
        return self._providers.get(id)

    def list(self) -> list[MemoryProvider]:
        """List all registered memory providers."""
        return list(self._providers.values())

    def clear(self) -> None:
        """Clear all registered providers."""
        self._providers.clear()


def create_memory_registry() -> MemoryRegistry:
    """Create a new memory registry."""
    return MemoryRegistry()
