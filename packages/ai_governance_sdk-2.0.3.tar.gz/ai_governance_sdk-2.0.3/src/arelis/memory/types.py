"""Memory types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/memory/src/types.ts`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from arelis.core.types import GovernanceContext

__all__ = [
    "MemoryContext",
    "MemoryDeleteInput",
    "MemoryEntry",
    "MemoryReadInput",
    "MemoryScope",
    "MemoryWriteInput",
]

MemoryScope = Literal["ephemeral", "session", "long-term", "shared"]
"""Memory scope determines the lifetime and visibility of a memory entry."""


@dataclass
class MemoryEntry:
    """A single memory entry."""

    id: str
    scope: MemoryScope
    key: str
    value: object
    created_at: str
    updated_at: str
    metadata: dict[str, object] | None = None


@dataclass
class MemoryContext:
    """Memory operation context."""

    run_id: str
    governance: GovernanceContext


# ---------------------------------------------------------------------------
# Client method input types
# ---------------------------------------------------------------------------


@dataclass
class MemoryReadInput:
    """Input for ``client.memory.read()``."""

    scope: MemoryScope
    key: str
    context: GovernanceContext | None = None
    provider_id: str | None = None


@dataclass
class MemoryWriteInput:
    """Input for ``client.memory.write()``."""

    scope: MemoryScope
    key: str
    value: object
    context: GovernanceContext | None = None
    provider_id: str | None = None
    metadata: dict[str, object] | None = None


@dataclass
class MemoryDeleteInput:
    """Input for ``client.memory.delete()``."""

    scope: MemoryScope
    key: str
    context: GovernanceContext | None = None
    provider_id: str | None = None
