"""Unified runtime + platform factory helpers."""

from __future__ import annotations

import json
import warnings
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Generic, TypedDict, TypeVar, cast

from arelis.audit import (
    AuditEvent,
    CausalGraph,
    build_causal_graph,
    create_agent_step_event,
    create_hash_ref,
    create_run_ended_event,
    create_run_started_event,
    create_tool_call_event,
    create_tool_result_event,
)
from arelis.client import ArelisClient, create_arelis_client
from arelis.config import ClientConfig
from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.governance_gate import (
    EvaluatePreInvocationGateInput,
    GovernanceGateDeniedMode,
    GovernanceGateSource,
    GovernanceGateTelemetryOptions,
    PreInvocationGateDecision,
    WithGovernanceGateOptions,
    with_governance_gate,
)
from arelis.platform import (
    ArelisPlatform,
    ArelisPlatformConfig,
    audit_event_to_platform_event,
    create_arelis_platform,
    create_platform_event,
)
from arelis.platform.types import (
    CausalGraphResponse,
    CreateProofResponse,
    EventRecord,
    GetPiiConfigOptions,
    ProofRecord,
    RiskEvaluationResponse,
)
from arelis.policy.redactor import RedactorConfig, create_redactor

T = TypeVar("T")
TOutput = TypeVar("TOutput")

DEFAULT_AGENT_MAX_STEPS = 8


class CreateArelisConfig(TypedDict, total=False):
    """Configuration for ``create_arelis``."""

    runtime: ClientConfig
    platform: ArelisPlatformConfig


@dataclass
class GovernedInvokeInput(Generic[T]):
    """Input for high-level governed invocation orchestration."""

    model: str
    prompt: str
    invoke: Callable[[str], Any]
    run_id: str | None = None
    actor: ActorRef | None = None
    context: GovernanceContext | None = None
    policy_ids: list[str] | None = None
    pii_namespace: str | None = None
    deny_mode: GovernanceGateDeniedMode | None = None
    include_risk: bool | None = None


@dataclass
class GovernedInvokeResult(Generic[T]):
    """Output from ``governed_invoke`` orchestration."""

    run_id: str
    invoked: bool
    decision: PreInvocationGateDecision
    sanitized_prompt: str
    result: T | None = None
    risk: RiskEvaluationResponse | None = None
    warnings: list[str] | None = None


@dataclass
class AgentModelToolCall:
    """Tool call emitted by model during an agent step."""

    id: str
    name: str
    args: dict[str, Any]


@dataclass
class AgentModelResponse:
    """Model response abstraction for high-level agent loop."""

    text: str | None = None
    tool_calls: list[AgentModelToolCall] = field(default_factory=list)
    finish_reason: str | None = None


@dataclass
class GovernedAgentTool:
    """Tool metadata provided to ``agents.run``."""

    name: str
    description: str | None = None
    schema: dict[str, Any] | None = None


@dataclass
class AgentConversationMessage:
    """Conversation message in high-level agent loop."""

    role: str
    content: str
    tool_call_id: str | None = None
    name: str | None = None


@dataclass
class GovernedAgentStepToolResult:
    """Tool execution result captured at a step."""

    tool_call_id: str
    tool_name: str
    success: bool
    result: Any | None = None
    error: str | None = None


@dataclass
class GovernedAgentStep:
    """One high-level agent step."""

    step_number: int
    model_response: AgentModelResponse
    tool_results: list[GovernedAgentStepToolResult]


@dataclass
class GovernedAgentRunInput(Generic[TOutput]):
    """Input contract for ``agents.run`` orchestration."""

    model: str
    prompt: str
    tools: list[GovernedAgentTool]
    invoke_model: Callable[[dict[str, Any]], Any]
    execute_tool_call: Callable[[dict[str, Any]], Any]
    run_id: str | None = None
    actor: ActorRef | None = None
    context: GovernanceContext | None = None
    policy_ids: list[str] | None = None
    pii_namespace: str | None = None
    deny_mode: GovernanceGateDeniedMode | None = None
    max_steps: int | None = None
    include_risk: bool | None = None
    proof_schema_version: str | None = None
    map_output: Callable[[dict[str, Any]], TOutput] | None = None


GovernedAgentRunStatus = str


@dataclass
class GovernedProofResult:
    """Best-effort proof creation outcome for agent runs."""

    request: CreateProofResponse | dict[str, Any]
    record: ProofRecord | dict[str, Any] | None = None


@dataclass
class GovernedAgentRunResult(Generic[TOutput]):
    """Output contract for ``agents.run`` orchestration."""

    run_id: str
    status: GovernedAgentRunStatus
    decision: PreInvocationGateDecision
    sanitized_prompt: str
    steps: list[GovernedAgentStep]
    events: list[AuditEvent]
    graph: CausalGraph
    output: TOutput | None = None
    platform_events: list[EventRecord] | None = None
    platform_graph: CausalGraphResponse | dict[str, Any] | None = None
    proof: GovernedProofResult | None = None
    risk: RiskEvaluationResponse | None = None
    warnings: list[str] | None = None


class _UnifiedGovernanceNamespace:
    def __init__(self, parent: ArelisInstance) -> None:
        self._parent = parent

    async def get_pii_config(
        self,
        options: GetPiiConfigOptions | None = None,
    ) -> RedactorConfig:
        if self._parent.platform is None:
            return RedactorConfig()
        return cast(
            "RedactorConfig",
            await _maybe_await(self._parent.platform.governance.getPiiConfig(options)),
        )

    async def getPiiConfig(  # noqa: N802
        self,
        options: GetPiiConfigOptions | None = None,
    ) -> RedactorConfig:
        return await self.get_pii_config(options)


class _UnifiedAgentsNamespace:
    def __init__(self, parent: ArelisInstance) -> None:
        self._parent = parent

    async def run(
        self,
        input: GovernedAgentRunInput[TOutput],
    ) -> GovernedAgentRunResult[TOutput]:
        return await self._parent._agents_run(input)


class ArelisInstance:
    """Unified runtime + platform orchestrator with dict compatibility shims."""

    def __init__(
        self,
        *,
        runtime: ArelisClient | None,
        platform: ArelisPlatform | None,
    ) -> None:
        self.runtime = runtime
        self.platform = platform
        self.governance = _UnifiedGovernanceNamespace(self)
        self.agents = _UnifiedAgentsNamespace(self)

    def __getitem__(self, key: str) -> Any:
        if key == "runtime":
            return self.runtime
        if key == "platform":
            return self.platform
        if key == "governance":
            return self.governance
        if key == "agents":
            return self.agents
        if key == "governed_invoke":
            return self.governed_invoke
        if key == "governedInvoke":
            return self.governedInvoke
        raise KeyError(key)

    async def governed_invoke(
        self,
        input: GovernedInvokeInput[T],
    ) -> GovernedInvokeResult[T]:
        run_id = input.run_id or _generate_run_id()
        warnings_out: list[str] = []
        actor = input.actor or _default_actor()
        context = _resolve_context(input.context, actor, "governed-invoke")
        managed_pii = await _try_get_managed_pii_config(
            self.platform,
            warnings_out,
            input.pii_namespace,
        )
        sanitized_prompt = create_redactor(managed_pii).redact(input.prompt).text
        gate_source = _resolve_gate_source(self.runtime, self.platform)

        async def _invoke_wrapper() -> T:
            await _report_platform_event(
                self.platform,
                warnings_out,
                {
                    "run_id": run_id,
                    "event_type": "model.request",
                    "actor": actor,
                    "action": "request",
                    "resource": {"type": "model", "id": input.model},
                    "metadata": {
                        "promptHash": _data_ref_sha256(create_hash_ref(sanitized_prompt)),
                        "promptRedacted": sanitized_prompt != input.prompt,
                    },
                },
            )

            try:
                result_value = await _maybe_await(input.invoke(sanitized_prompt))
            except Exception as error:
                await _report_platform_event(
                    self.platform,
                    warnings_out,
                    {
                        "run_id": run_id,
                        "event_type": "model.error",
                        "actor": actor,
                        "action": "error",
                        "resource": {"type": "model", "id": input.model},
                        "metadata": {"message": str(error)},
                    },
                )
                raise

            await _report_platform_event(
                self.platform,
                warnings_out,
                {
                    "run_id": run_id,
                    "event_type": "model.response",
                    "actor": actor,
                    "action": "response",
                    "resource": {"type": "model", "id": input.model},
                    "metadata": {
                        "outputHash": _data_ref_sha256(
                            create_hash_ref(_stringify_safe(result_value))
                        )
                    },
                },
            )

            return cast("T", result_value)

        gate = await with_governance_gate(
            gate_source,
            EvaluatePreInvocationGateInput(
                run_id=run_id,
                prompt=input.prompt,
                policy_ids=input.policy_ids,
                model=input.model,
                actor=actor,
                context=context,
            ),
            _invoke_wrapper,
            options=WithGovernanceGateOptions(
                deny_mode=input.deny_mode or "return",
                redactor_config=managed_pii,
                telemetry=GovernanceGateTelemetryOptions(
                    enabled=True,
                    platform=cast("Any", self.platform),
                ),
            ),
        )

        warnings_out.extend(gate.warnings or [])

        if not gate.invoked:
            await _report_platform_event(
                self.platform,
                warnings_out,
                {
                    "run_id": run_id,
                    "event_type": "model.blocked",
                    "actor": actor,
                    "action": "blocked",
                    "resource": {"type": "model", "id": input.model},
                    "metadata": {
                        "reasons": gate.decision.reasons,
                        "codes": gate.decision.codes,
                    },
                },
            )

        risk = await _try_evaluate_risk(
            self.platform,
            warnings_out,
            {
                "run_id": run_id,
                "include_risk": input.include_risk if input.include_risk is not None else True,
                "policy_decisions": gate.decision.policy.decisions,
                "explicit_signals": {
                    "surface": "model",
                    "outcome": "allowed" if gate.invoked else "blocked",
                },
            },
        )

        return GovernedInvokeResult(
            run_id=gate.run_id,
            invoked=gate.invoked,
            decision=gate.decision,
            sanitized_prompt=sanitized_prompt,
            result=gate.result,
            risk=risk,
            warnings=warnings_out if len(warnings_out) > 0 else None,
        )

    async def governedInvoke(  # noqa: N802
        self,
        input: GovernedInvokeInput[T],
    ) -> GovernedInvokeResult[T]:
        return await self.governed_invoke(input)

    async def _agents_run(
        self,
        input: GovernedAgentRunInput[TOutput],
    ) -> GovernedAgentRunResult[TOutput]:
        run_id = input.run_id or _generate_run_id()
        warnings_out: list[str] = []
        actor = input.actor or _default_actor()
        context = _resolve_context(input.context, actor, "agents.run")
        managed_pii = await _try_get_managed_pii_config(
            self.platform,
            warnings_out,
            input.pii_namespace,
        )
        sanitized_prompt = create_redactor(managed_pii).redact(input.prompt).text
        gate_source = _resolve_gate_source(self.runtime, self.platform)

        gate = await with_governance_gate(
            gate_source,
            EvaluatePreInvocationGateInput(
                run_id=run_id,
                prompt=input.prompt,
                policy_ids=input.policy_ids,
                model=input.model,
                actor=actor,
                context=context,
            ),
            lambda: _run_high_level_agent_loop(
                {
                    "run_id": run_id,
                    "context": context,
                    "model": input.model,
                    "prompt": sanitized_prompt,
                    "tools": input.tools,
                    "max_steps": input.max_steps or DEFAULT_AGENT_MAX_STEPS,
                    "invoke_model": input.invoke_model,
                    "execute_tool_call": input.execute_tool_call,
                    "map_output": input.map_output,
                }
            ),
            options=WithGovernanceGateOptions(
                deny_mode=input.deny_mode or "return",
                redactor_config=managed_pii,
                telemetry=GovernanceGateTelemetryOptions(
                    enabled=True,
                    platform=cast("Any", self.platform),
                ),
            ),
        )

        warnings_out.extend(gate.warnings or [])

        status: GovernedAgentRunStatus
        output: TOutput | None = None
        steps: list[GovernedAgentStep]
        events: list[AuditEvent]

        if not gate.invoked:
            status = "blocked"
            steps = []
            events = [
                create_run_started_event(
                    run_id=gate.run_id,
                    context=context,
                    operation="agents.run",
                ),
                create_run_ended_event(
                    run_id=gate.run_id,
                    context=context,
                    success=False,
                    duration_ms=0,
                ),
            ]
        elif gate.result is None:
            status = "failed"
            steps = []
            events = [
                create_run_started_event(
                    run_id=gate.run_id,
                    context=context,
                    operation="agents.run",
                ),
                create_run_ended_event(
                    run_id=gate.run_id,
                    context=context,
                    success=False,
                    duration_ms=0,
                ),
            ]
        else:
            status = gate.result["status"]
            output = gate.result["output"]
            steps = gate.result["steps"]
            events = gate.result["events"]

        graph = build_causal_graph(gate.run_id, events)
        platform_events = await _try_upload_and_fetch_platform_events(
            self.platform,
            warnings_out,
            events,
            gate.run_id,
        )
        platform_graph = await _try_fetch_platform_graph(
            self.platform,
            warnings_out,
            gate.run_id,
        )
        proof = await _try_create_proof(
            self.platform,
            warnings_out,
            gate.run_id,
            input.proof_schema_version or "v2",
        )
        risk = await _try_evaluate_risk(
            self.platform,
            warnings_out,
            {
                "run_id": gate.run_id,
                "include_risk": input.include_risk if input.include_risk is not None else True,
                "policy_decisions": gate.decision.policy.decisions,
                "explicit_signals": {
                    "surface": "agent",
                    "status": status,
                    "stepCount": len(steps),
                },
            },
        )

        return GovernedAgentRunResult(
            run_id=gate.run_id,
            status=status,
            decision=gate.decision,
            sanitized_prompt=sanitized_prompt,
            output=output,
            steps=steps,
            events=events,
            graph=graph,
            platform_events=platform_events,
            platform_graph=platform_graph,
            proof=proof,
            risk=risk,
            warnings=warnings_out if len(warnings_out) > 0 else None,
        )


async def _run_high_level_agent_loop(input: dict[str, Any]) -> dict[str, Any]:
    started_at = time_ms()
    events: list[AuditEvent] = []
    steps: list[GovernedAgentStep] = []
    messages: list[AgentConversationMessage] = [
        AgentConversationMessage(
            role="user",
            content=str(input["prompt"]),
        )
    ]

    status: GovernedAgentRunStatus = "completed"
    output: Any | None = None
    final_response = AgentModelResponse()

    events.append(
        create_run_started_event(
            run_id=str(input["run_id"]),
            context=cast("GovernanceContext", input["context"]),
            operation="agents.run",
        )
    )

    try:
        for step_number in range(1, int(input["max_steps"]) + 1):
            events.append(
                create_agent_step_event(
                    run_id=str(input["run_id"]),
                    context=cast("GovernanceContext", input["context"]),
                    step_number=step_number,
                    step_type="plan",
                )
            )

            model_response_raw = await _maybe_await(
                input["invoke_model"](
                    {
                        "runId": str(input["run_id"]),
                        "model": str(input["model"]),
                        "stepNumber": step_number,
                        "messages": messages,
                        "tools": input["tools"],
                        "context": input["context"],
                    }
                )
            )
            model_response = _coerce_model_response(model_response_raw)
            final_response = model_response

            if model_response.text:
                messages.append(
                    AgentConversationMessage(
                        role="assistant",
                        content=model_response.text,
                    )
                )

            tool_calls = model_response.tool_calls or []
            tool_call_event_payload = [
                {
                    "tool_name": tool_call.name,
                    "args_ref": create_hash_ref(_stringify_safe(tool_call.args)),
                    "success": True,
                }
                for tool_call in tool_calls
            ]

            events.append(
                create_agent_step_event(
                    run_id=str(input["run_id"]),
                    context=cast("GovernanceContext", input["context"]),
                    step_number=step_number,
                    step_type="execute",
                    tool_calls=tool_call_event_payload,
                )
            )

            tool_results: list[GovernedAgentStepToolResult] = []
            for tool_call in tool_calls:
                events.append(
                    create_tool_call_event(
                        run_id=str(input["run_id"]),
                        context=cast("GovernanceContext", input["context"]),
                        tool_name=tool_call.name,
                        args_ref=create_hash_ref(_stringify_safe(tool_call.args)),
                    )
                )

                try:
                    result = await _maybe_await(
                        input["execute_tool_call"](
                            {
                                "runId": str(input["run_id"]),
                                "stepNumber": step_number,
                                "model": str(input["model"]),
                                "tool": tool_call,
                                "context": input["context"],
                            }
                        )
                    )

                    tool_results.append(
                        GovernedAgentStepToolResult(
                            tool_call_id=tool_call.id,
                            tool_name=tool_call.name,
                            success=True,
                            result=result,
                        )
                    )

                    events.append(
                        create_tool_result_event(
                            run_id=str(input["run_id"]),
                            context=cast("GovernanceContext", input["context"]),
                            tool_name=tool_call.name,
                            success=True,
                            result_ref=create_hash_ref(_stringify_safe(result)),
                        )
                    )

                    messages.append(
                        AgentConversationMessage(
                            role="tool",
                            content=_stringify_safe(result),
                            tool_call_id=tool_call.id,
                            name=tool_call.name,
                        )
                    )
                except Exception as error:
                    message = str(error)
                    tool_results.append(
                        GovernedAgentStepToolResult(
                            tool_call_id=tool_call.id,
                            tool_name=tool_call.name,
                            success=False,
                            error=message,
                        )
                    )

                    events.append(
                        create_tool_result_event(
                            run_id=str(input["run_id"]),
                            context=cast("GovernanceContext", input["context"]),
                            tool_name=tool_call.name,
                            success=False,
                            error={"type": "ToolExecutionError", "message": message},
                        )
                    )

                    messages.append(
                        AgentConversationMessage(
                            role="tool",
                            content=_stringify_safe({"error": message}),
                            tool_call_id=tool_call.id,
                            name=tool_call.name,
                        )
                    )

            events.append(
                create_agent_step_event(
                    run_id=str(input["run_id"]),
                    context=cast("GovernanceContext", input["context"]),
                    step_number=step_number,
                    step_type="observe",
                )
            )

            steps.append(
                GovernedAgentStep(
                    step_number=step_number,
                    model_response=model_response,
                    tool_results=tool_results,
                )
            )

            if len(tool_calls) == 0 or model_response.finish_reason == "stop":
                status = "completed"
                if callable(input.get("map_output")):
                    output = input["map_output"](
                        {
                            "runId": str(input["run_id"]),
                            "steps": steps,
                            "messages": messages,
                            "finalResponse": model_response,
                        }
                    )
                else:
                    output = cast("Any", model_response.text)
                break

            if step_number == int(input["max_steps"]):
                status = "max_steps_reached"
    except Exception:
        status = "failed"

    events.append(
        create_run_ended_event(
            run_id=str(input["run_id"]),
            context=cast("GovernanceContext", input["context"]),
            success=(status == "completed"),
            duration_ms=(time_ms() - started_at),
        )
    )

    if status == "completed" and output is None and callable(input.get("map_output")):
        output = input["map_output"](
            {
                "runId": str(input["run_id"]),
                "steps": steps,
                "messages": messages,
                "finalResponse": final_response,
            }
        )

    return {
        "status": status,
        "output": output,
        "steps": steps,
        "events": events,
    }


async def _try_get_managed_pii_config(
    platform: ArelisPlatform | None,
    warnings_out: list[str],
    namespace: str | None,
) -> RedactorConfig:
    if platform is None:
        return RedactorConfig()

    try:
        return cast(
            "RedactorConfig",
            await _maybe_await(
                platform.governance.getPiiConfig(
                    {"namespace": namespace} if isinstance(namespace, str) and namespace else {}
                )
            ),
        )
    except Exception as error:
        warnings_out.append(f"Failed to load managed PII config: {error}")
        return RedactorConfig()


async def _report_platform_event(
    platform: ArelisPlatform | None,
    warnings_out: list[str],
    input: dict[str, Any],
) -> None:
    if platform is None:
        return

    try:
        resource = cast("dict[str, Any]", input["resource"])
        payload = create_platform_event(
            {
                "runId": str(input["run_id"]),
                "eventType": str(input["event_type"]),
                "actor": {
                    "id": cast("ActorRef", input["actor"]).id,
                    "type": cast("ActorRef", input["actor"]).type,
                },
                "action": str(input["action"]),
                "resource": {
                    "type": str(resource.get("type", "")),
                    "id": str(resource.get("id", "")),
                },
                "metadata": cast("dict[str, Any]", input["metadata"]),
            }
        )
        await _maybe_await(platform.events.create(payload))
    except Exception as error:
        warnings_out.append(f"Failed to report platform event ({input['event_type']}): {error}")


async def _try_upload_and_fetch_platform_events(
    platform: ArelisPlatform | None,
    warnings_out: list[str],
    events: list[AuditEvent],
    run_id: str,
) -> list[EventRecord] | None:
    if platform is None or len(events) == 0:
        return None

    try:
        await _maybe_await(
            platform.events.createBatch(
                {
                    "events": [audit_event_to_platform_event(event) for event in events],
                }
            )
        )
    except Exception as error:
        warnings_out.append(f"Failed to upload agent events to platform: {error}")
        return None

    try:
        listed = await _maybe_await(platform.events.list({"runId": run_id, "limit": 250}))
        if isinstance(listed, dict) and isinstance(listed.get("events"), list):
            return cast("list[EventRecord]", listed["events"])
        return []
    except Exception as error:
        if _is_invalid_events_query_params_error(error):
            try:
                listed = await _maybe_await(platform.events.list({"runId": run_id}))
                if isinstance(listed, dict) and isinstance(listed.get("events"), list):
                    return cast("list[EventRecord]", listed["events"])
                return []
            except Exception as fallback_error:
                warnings_out.append(
                    f"Failed to fetch persisted platform events: {_error_message(fallback_error)}"
                )
                return None

        warnings_out.append(f"Failed to fetch persisted platform events: {_error_message(error)}")
        return None


async def _try_fetch_platform_graph(
    platform: ArelisPlatform | None,
    warnings_out: list[str],
    run_id: str,
) -> CausalGraphResponse | dict[str, Any] | None:
    if platform is None:
        return None

    try:
        graph = await _maybe_await(platform.graphs.get(run_id))
        if isinstance(graph, dict):
            return cast("CausalGraphResponse | dict[str, Any]", graph)
        return None
    except Exception as error:
        if _is_not_found_error(error):
            return None

        warnings_out.append(f"Failed to fetch platform causal graph: {_error_message(error)}")
        return None


async def _try_create_proof(
    platform: ArelisPlatform | None,
    warnings_out: list[str],
    run_id: str,
    schema_version: str,
) -> GovernedProofResult | None:
    if platform is None:
        return None

    try:
        created = await _maybe_await(
            platform.proofs.create({"runId": run_id, "schemaVersion": schema_version})
        )
        if isinstance(created, dict) and isinstance(created.get("proofId"), str):
            try:
                record = await _maybe_await(platform.proofs.get(created["proofId"]))
                if isinstance(record, dict):
                    return GovernedProofResult(
                        request=cast("CreateProofResponse | dict[str, Any]", created),
                        record=cast("ProofRecord | dict[str, Any]", record),
                    )
            except Exception as error:
                warnings_out.append(f"Failed to fetch created proof record: {error}")

        if isinstance(created, dict):
            return GovernedProofResult(
                request=cast("CreateProofResponse | dict[str, Any]", created),
            )
        return None
    except Exception as error:
        warnings_out.append(f"Failed to create compliance proof: {error}")
        return None


async def _try_evaluate_risk(
    platform: ArelisPlatform | None,
    warnings_out: list[str],
    input: dict[str, Any],
) -> RiskEvaluationResponse | None:
    if platform is None or not bool(input["include_risk"]):
        return None

    try:
        result = await _maybe_await(
            platform.risk.evaluate(
                {
                    "runId": str(input["run_id"]),
                    "policyDecisions": [
                        _normalize_decision_for_risk(d)
                        for d in cast("list[Any]", input["policy_decisions"])
                    ],
                    "quotaState": {},
                    "evaluationSignals": [],
                    "explicitSignals": cast("dict[str, Any]", input["explicit_signals"]),
                }
            )
        )
        if isinstance(result, dict):
            return cast("RiskEvaluationResponse", result)
        return None
    except Exception as error:
        warnings_out.append(f"Failed to evaluate platform risk: {error}")
        return None


def _normalize_decision_for_risk(decision: Any) -> dict[str, Any]:
    effect = getattr(decision, "effect", None)

    if effect == "block":
        return {
            "effect": decision.effect,
            "reason": decision.reason,
            "code": decision.code,
        }

    if effect == "require_approval":
        return {
            "effect": decision.effect,
            "reason": decision.reason,
            "approvers": decision.approvers,
        }

    if effect == "transform":
        return {
            "effect": decision.effect,
            "reason": decision.reason,
            "patchCount": 0,
        }

    return {"effect": effect}


def _resolve_gate_source(
    runtime: ArelisClient | None,
    platform: ArelisPlatform | None,
) -> GovernanceGateSource:
    if platform is not None:
        return cast("GovernanceGateSource", platform)
    if runtime is not None:
        return cast("GovernanceGateSource", runtime)
    raise ValueError("No governance gate source available: runtime or platform is required")


def _resolve_context(
    partial: GovernanceContext | None,
    actor: ActorRef,
    purpose: str,
) -> GovernanceContext:
    return GovernanceContext(
        org=partial.org if partial is not None else OrgRef(id="arelis-sdk"),
        team=partial.team if partial is not None else None,
        actor=actor,
        purpose=partial.purpose if partial is not None else purpose,
        environment=partial.environment if partial is not None else "dev",
        session_id=partial.session_id if partial is not None else None,
        request_id=partial.request_id if partial is not None else None,
        tags=partial.tags if partial is not None else None,
    )


def _default_actor() -> ActorRef:
    return ActorRef(
        type="service",
        id="arelis-sdk",
    )


def _stringify_safe(value: Any) -> str:
    try:
        return json.dumps(value)
    except Exception:
        return str(value)


def _data_ref_sha256(ref: Any) -> str | None:
    if getattr(ref, "kind", None) == "hash":
        return cast("str", getattr(ref, "sha256", None))
    return None


def _error_message(error: Any) -> str:
    if isinstance(error, Exception):
        return str(error)

    if isinstance(error, str):
        return error

    if isinstance(error, dict) and isinstance(error.get("detail"), str):
        return cast("str", error["detail"])

    return str(error)


def _is_not_found_error(error: Any) -> bool:
    if hasattr(error, "status") and error.status == 404:
        return True

    if isinstance(error, dict) and error.get("status") == 404:
        return True

    return "not found" in _error_message(error).lower()


def _is_invalid_events_query_params_error(error: Any) -> bool:
    message = _error_message(error).lower()
    status = getattr(error, "status", None)
    if status is None and isinstance(error, dict):
        status = error.get("status")

    if isinstance(status, int) and status != 400:
        return False

    return "invalid events query parameters" in message or (
        "invalid" in message and "event" in message and "query" in message
    )


def _coerce_model_response(raw: Any) -> AgentModelResponse:
    if isinstance(raw, AgentModelResponse):
        return raw

    if not isinstance(raw, dict):
        return AgentModelResponse(text=str(raw), finish_reason="stop")

    raw_tool_calls = raw.get("toolCalls")
    if raw_tool_calls is None:
        raw_tool_calls = raw.get("tool_calls")

    tool_calls: list[AgentModelToolCall] = []
    if isinstance(raw_tool_calls, list):
        for item in raw_tool_calls:
            if isinstance(item, AgentModelToolCall):
                tool_calls.append(item)
                continue
            if isinstance(item, dict):
                tool_calls.append(
                    AgentModelToolCall(
                        id=str(item.get("id", "")),
                        name=str(item.get("name", "")),
                        args=cast(
                            "dict[str, Any]",
                            item.get("args") if isinstance(item.get("args"), dict) else {},
                        ),
                    )
                )

    finish_reason = raw.get("finishReason")
    if finish_reason is None:
        finish_reason = raw.get("finish_reason")

    return AgentModelResponse(
        text=cast("str | None", raw.get("text") if isinstance(raw.get("text"), str) else None),
        tool_calls=tool_calls,
        finish_reason=finish_reason if isinstance(finish_reason, str) else None,
    )


async def _maybe_await(value: Any) -> Any:
    import inspect

    if inspect.isawaitable(value):
        return await cast("Any", value)
    return value


def _generate_run_id() -> str:
    from arelis.core.run_context import generate_run_id

    return generate_run_id()


def time_ms() -> float:
    import time

    return time.time() * 1000.0


def create_arelis(config: CreateArelisConfig) -> ArelisInstance:
    """Create runtime and/or platform clients from a single config object."""
    runtime = create_arelis_client(config["runtime"]) if "runtime" in config else None
    platform = create_arelis_platform(config["platform"]) if "platform" in config else None

    if runtime is None and platform is None:
        raise ValueError("createArelis requires at least one configuration: runtime or platform")

    return ArelisInstance(runtime=runtime, platform=platform)


def createArelis(config: CreateArelisConfig) -> ArelisInstance:  # noqa: N802
    """CamelCase compatibility alias for :func:`create_arelis`."""
    warnings.warn(
        "createArelis() is a compatibility alias and will be deprecated in a future "
        "release; use create_arelis() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return create_arelis(config)


__all__ = [
    "CreateArelisConfig",
    "ArelisInstance",
    "GovernedInvokeInput",
    "GovernedInvokeResult",
    "AgentModelToolCall",
    "AgentModelResponse",
    "GovernedAgentTool",
    "AgentConversationMessage",
    "GovernedAgentStepToolResult",
    "GovernedAgentStep",
    "GovernedAgentRunInput",
    "GovernedAgentRunStatus",
    "GovernedProofResult",
    "GovernedAgentRunResult",
    "create_arelis",
    "createArelis",
]
