"""Evaluation types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/evaluations/src/types.ts`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol, runtime_checkable

__all__ = [
    "EvaluationEffect",
    "EvaluationFinding",
    "EvaluationFindingCategory",
    "EvaluationFindingSeverity",
    "EvaluationGroundingChunk",
    "EvaluationGroundingInfo",
    "EvaluationInput",
    "EvaluationResult",
    "EvaluationRunResult",
    "EvaluationSurface",
    "Evaluator",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

EvaluationSurface = Literal["model", "agent", "tool", "kb"]
"""The surface being evaluated."""

EvaluationFindingCategory = Literal[
    "safety", "pii", "secrets", "grounding", "schema", "policy", "business"
]
"""Category of an evaluation finding."""

EvaluationFindingSeverity = Literal["info", "low", "medium", "high", "critical"]
"""Severity level of an evaluation finding."""

EvaluationEffect = Literal["pass", "warn", "block"]
"""The overall effect of an evaluation or evaluation run."""

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class EvaluationGroundingChunk:
    """A single grounding chunk referenced during evaluation."""

    chunk_id: str
    ref: str  # DataRef — stored as string reference
    used: bool


@dataclass
class EvaluationGroundingInfo:
    """Grounding context for evaluation — links to knowledge base chunks."""

    kb_id: str
    chunks: list[EvaluationGroundingChunk] = field(default_factory=list)


@dataclass
class EvaluationInput:
    """Input passed to an evaluator."""

    run_id: str
    context: object  # GovernanceContext — imported as object to avoid circular deps
    surface: EvaluationSurface
    output_ref: str  # DataRef
    prompt_ref: str | None = None  # DataRef
    grounding: EvaluationGroundingInfo | None = None
    metadata: dict[str, object] | None = None


@dataclass
class EvaluationFinding:
    """A single finding produced by an evaluator."""

    id: str
    category: EvaluationFindingCategory
    severity: EvaluationFindingSeverity
    message: str
    evidence_ref: str | None = None  # DataRef
    score: float | None = None


@dataclass
class EvaluationResult:
    """Result returned from a single evaluator."""

    evaluator_id: str
    effect: EvaluationEffect
    findings: list[EvaluationFinding] = field(default_factory=list)
    version: str | None = None
    time_ms: float = 0.0


@dataclass
class EvaluationRunResult:
    """Aggregated result from running multiple evaluators."""

    results: list[EvaluationResult] = field(default_factory=list)
    effect: EvaluationEffect = "pass"
    max_severity: EvaluationFindingSeverity | None = None


# ---------------------------------------------------------------------------
# Evaluator protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class Evaluator(Protocol):
    """Interface for evaluators.

    Implementations must expose an ``id`` property and an async ``evaluate()``
    method.
    """

    @property
    def id(self) -> str:
        """Unique identifier for this evaluator."""
        ...

    @property
    def version(self) -> str | None:
        """Optional version string."""
        ...

    async def evaluate(self, input: EvaluationInput) -> EvaluationResult:
        """Run the evaluation on the given input."""
        ...
