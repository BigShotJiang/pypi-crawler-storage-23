"""Evaluations module — evaluator orchestration and guardrails."""

from __future__ import annotations

from arelis.evaluations.runner import derive_evaluation_effect, run_evaluations
from arelis.evaluations.types import (
    EvaluationEffect,
    EvaluationFinding,
    EvaluationFindingCategory,
    EvaluationFindingSeverity,
    EvaluationGroundingChunk,
    EvaluationGroundingInfo,
    EvaluationInput,
    EvaluationResult,
    EvaluationRunResult,
    EvaluationSurface,
    Evaluator,
)

__all__ = [
    "EvaluationEffect",
    "EvaluationFinding",
    "EvaluationFindingCategory",
    "EvaluationFindingSeverity",
    "EvaluationGroundingChunk",
    "EvaluationGroundingInfo",
    "EvaluationInput",
    "EvaluationResult",
    "EvaluationRunResult",
    "EvaluationSurface",
    "Evaluator",
    "derive_evaluation_effect",
    "run_evaluations",
]
