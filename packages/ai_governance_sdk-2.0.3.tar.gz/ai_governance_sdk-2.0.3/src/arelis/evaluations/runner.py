"""Evaluator runner — executes evaluators and aggregates results.

Ports the TypeScript SDK's `packages/evaluations/src/evaluator-runner.ts`.
"""

from __future__ import annotations

import time

from arelis.evaluations.types import (
    EvaluationEffect,
    EvaluationFindingSeverity,
    EvaluationInput,
    EvaluationResult,
    EvaluationRunResult,
    Evaluator,
)

__all__ = [
    "derive_evaluation_effect",
    "run_evaluations",
]

# ---------------------------------------------------------------------------
# Severity ranking
# ---------------------------------------------------------------------------

_SEVERITY_RANK: dict[EvaluationFindingSeverity, int] = {
    "info": 0,
    "low": 1,
    "medium": 2,
    "high": 3,
    "critical": 4,
}

# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def derive_evaluation_effect(results: list[EvaluationResult]) -> EvaluationRunResult:
    """Derive the aggregate effect and max severity from a list of results.

    Follows the same logic as the TypeScript ``deriveEvaluationEffect``:
    - ``block`` overrides everything.
    - ``warn`` overrides ``pass``.
    - ``max_severity`` is the highest severity across all findings.
    """
    effect: EvaluationEffect = "pass"
    max_severity: EvaluationFindingSeverity | None = None

    for result in results:
        if result.effect == "block":
            effect = "block"
        elif result.effect == "warn" and effect == "pass":
            effect = "warn"

        for finding in result.findings:
            if (
                max_severity is None
                or _SEVERITY_RANK[finding.severity] > _SEVERITY_RANK[max_severity]
            ):
                max_severity = finding.severity

    return EvaluationRunResult(results=results, effect=effect, max_severity=max_severity)


async def run_evaluations(
    evaluators: list[Evaluator],
    input: EvaluationInput,
    *,
    stop_on_block: bool = False,
) -> EvaluationRunResult:
    """Run a list of evaluators sequentially against the given input.

    If *stop_on_block* is ``True``, execution stops as soon as any evaluator
    returns a ``block`` effect.

    Each result is annotated with timing information — if the evaluator did not
    set ``time_ms``, the elapsed wall-clock time is used.
    """
    results: list[EvaluationResult] = []

    for evaluator in evaluators:
        started_at = time.monotonic()
        result = await evaluator.evaluate(input)

        # Use evaluator-reported timing if available; otherwise measure it.
        time_ms = result.time_ms if result.time_ms else (time.monotonic() - started_at) * 1000
        with_timing = EvaluationResult(
            evaluator_id=result.evaluator_id,
            effect=result.effect,
            findings=result.findings,
            version=result.version,
            time_ms=time_ms,
        )
        results.append(with_timing)

        if with_timing.effect == "block" and stop_on_block:
            break

    return derive_evaluation_effect(results)
