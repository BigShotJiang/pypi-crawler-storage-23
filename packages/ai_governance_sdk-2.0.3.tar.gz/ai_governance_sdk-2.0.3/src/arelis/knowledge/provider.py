"""Knowledge base provider protocol.

Ports the KBProvider interface from the TypeScript SDK.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from arelis.knowledge.types import KBProviderType, RetrievalQuery, RetrievedChunk

__all__ = [
    "KBProvider",
]


@runtime_checkable
class KBProvider(Protocol):
    """Knowledge base provider interface.

    Implementations must provide retrieval capabilities for a specific
    knowledge base backend (Pinecone, Weaviate, in-memory, etc.).
    """

    @property
    def type(self) -> KBProviderType:
        """Provider type identifier."""
        ...

    async def connect(self) -> None:
        """Connect to the knowledge base."""
        ...

    async def disconnect(self) -> None:
        """Disconnect from the knowledge base."""
        ...

    def is_connected(self) -> bool:
        """Check if connected to the knowledge base."""
        ...

    async def retrieve(self, query: RetrievalQuery) -> list[RetrievedChunk]:
        """Retrieve chunks based on query."""
        ...
