"""Knowledge base registry for managing KB registrations.

Ports `packages/knowledge/src/kb-registry.ts` from the TypeScript SDK.
"""

from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.knowledge.provider import KBProvider
from arelis.knowledge.types import (
    VALID_KB_PROVIDERS,
    KBRegistryOptions,
    KnowledgeBaseDescriptor,
)

__all__ = [
    "KBRegistry",
    "RegisteredKB",
    "create_kb_registry",
]


@dataclass
class RegisteredKB:
    """Registered knowledge base entry."""

    descriptor: KnowledgeBaseDescriptor
    registered_at: str
    provider: KBProvider | None = None


class KBRegistry:
    """Knowledge base registry for managing KB registrations."""

    def __init__(self, options: KBRegistryOptions | None = None) -> None:
        opts = options or KBRegistryOptions()
        self._allow_overwrite = opts.allow_overwrite
        self._default_top_k = opts.default_top_k
        self._default_min_score = opts.default_min_score
        self._kbs: dict[str, RegisteredKB] = {}

    def register_kb(self, descriptor: KnowledgeBaseDescriptor) -> None:
        """Register a knowledge base."""
        if not descriptor.id or not isinstance(descriptor.id, str):
            raise ValueError("KB ID is required and must be a string")

        if not descriptor.provider or not isinstance(descriptor.provider, str):
            raise ValueError("KB provider is required and must be a string")

        if descriptor.provider not in VALID_KB_PROVIDERS:
            valid = ", ".join(sorted(VALID_KB_PROVIDERS))
            raise ValueError(f"Invalid provider: {descriptor.provider}. Must be one of: {valid}")

        if descriptor.connection is None or not isinstance(descriptor.connection, dict):
            raise ValueError("KB connection configuration is required")

        if descriptor.id in self._kbs and not self._allow_overwrite:
            raise ValueError(f'KB "{descriptor.id}" is already registered')

        self._kbs[descriptor.id] = RegisteredKB(
            descriptor=descriptor,
            registered_at=datetime.now(timezone.utc).isoformat(),
        )

    def get_kb(self, id: str) -> RegisteredKB | None:
        """Get a registered KB by ID."""
        return self._kbs.get(id)

    def has_kb(self, id: str) -> bool:
        """Check if a KB is registered."""
        return id in self._kbs

    def list_kbs(self) -> list[RegisteredKB]:
        """List all registered KBs."""
        return list(self._kbs.values())

    def list_kb_ids(self) -> list[str]:
        """List KB IDs."""
        return list(self._kbs.keys())

    def unregister_kb(self, id: str) -> bool:
        """Unregister a KB."""
        kb = self._kbs.get(id)
        if kb is not None and kb.provider is not None:
            # Fire and forget disconnect
            with contextlib.suppress(RuntimeError):
                asyncio.get_event_loop().create_task(kb.provider.disconnect())
        return self._kbs.pop(id, None) is not None

    def clear(self) -> None:
        """Clear all registered KBs."""
        for kb in self._kbs.values():
            if kb.provider is not None:
                with contextlib.suppress(RuntimeError):
                    asyncio.get_event_loop().create_task(kb.provider.disconnect())
        self._kbs.clear()

    @property
    def size(self) -> int:
        """Get the number of registered KBs."""
        return len(self._kbs)

    @property
    def default_top_k(self) -> int:
        """Get default topK."""
        return self._default_top_k

    @property
    def default_min_score(self) -> float:
        """Get default minimum score."""
        return self._default_min_score

    def set_provider(self, id: str, provider: KBProvider) -> None:
        """Set provider for a KB."""
        kb = self._kbs.get(id)
        if kb is None:
            raise ValueError(f'KB "{id}" not found')
        kb.provider = provider

    def get_provider(self, id: str) -> KBProvider | None:
        """Get provider for a KB."""
        kb = self._kbs.get(id)
        return kb.provider if kb is not None else None

    def is_purpose_approved(self, kb_id: str, purpose: str) -> bool:
        """Check if a purpose is approved for a KB."""
        kb = self._kbs.get(kb_id)
        if kb is None:
            return False

        governance = kb.descriptor.governance
        if governance is None or governance.approved_for_purposes is None:
            return True  # No purpose restrictions

        return purpose in governance.approved_for_purposes

    def get_data_classification(self, kb_id: str) -> str | None:
        """Get data classification for a KB."""
        kb = self._kbs.get(kb_id)
        if kb is None:
            return None
        gov = kb.descriptor.governance
        return gov.data_class if gov is not None else None

    def get_data_residency(self, kb_id: str) -> str | None:
        """Get data residency for a KB."""
        kb = self._kbs.get(kb_id)
        if kb is None:
            return None
        gov = kb.descriptor.governance
        return gov.data_residency if gov is not None else None


def create_kb_registry(options: KBRegistryOptions | None = None) -> KBRegistry:
    """Create a new KB registry."""
    return KBRegistry(options)
