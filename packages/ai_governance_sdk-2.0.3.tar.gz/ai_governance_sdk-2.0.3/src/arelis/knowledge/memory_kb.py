"""In-memory knowledge base provider for testing and lightweight use.

Uses hybrid scoring: BM25 + keyword overlap + optional embeddings.

Ports `packages/knowledge/src/providers/memory.ts` from the TypeScript SDK.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass

from arelis.knowledge.scoring import (
    BM25Params,
    HybridScorer,
    HybridScorerOptions,
    ScoringWeights,
)
from arelis.knowledge.types import (
    ChunkSource,
    KBProviderType,
    RetrievalQuery,
    RetrievedChunk,
)

__all__ = [
    "EmbedFunction",
    "MemoryDocument",
    "MemoryKBProvider",
    "MemoryKBProviderOptions",
    "MemoryKBScoringOptions",
    "create_memory_kb_provider",
    "create_test_kb_provider",
]


@dataclass
class MemoryDocument:
    """Document for in-memory KB."""

    id: str
    text: str
    uri: str | None = None
    title: str | None = None
    metadata: dict[str, object] | None = None


EmbedFunction = Callable[[list[str]], Awaitable[list[list[float]]]]
"""Function that embeds an array of texts into vectors."""


@dataclass
class MemoryKBScoringOptions:
    """Scoring configuration for the in-memory KB provider."""

    weights: ScoringWeights | None = None
    bm25_params: BM25Params | None = None
    remove_stop_words: bool = True


@dataclass
class MemoryKBProviderOptions:
    """In-memory KB provider options."""

    kb_id: str
    documents: list[MemoryDocument] | None = None
    embed: EmbedFunction | None = None
    scoring: MemoryKBScoringOptions | None = None


class MemoryKBProvider:
    """In-memory knowledge base provider for testing and lightweight use.

    Uses hybrid scoring: BM25 + keyword overlap + optional embeddings.
    """

    def __init__(self, options: MemoryKBProviderOptions) -> None:
        self._type: KBProviderType = "memory"
        self._connected = False
        self._documents: list[MemoryDocument] = list(options.documents or [])
        self._kb_id = options.kb_id
        self._embed_fn = options.embed

        scoring = options.scoring or MemoryKBScoringOptions()
        self._scorer = HybridScorer(
            HybridScorerOptions(
                weights=scoring.weights,
                bm25_params=scoring.bm25_params,
                remove_stop_words=scoring.remove_stop_words,
            )
        )

        self._index_dirty = True
        self._embeddings_dirty = True
        self._cached_doc_embeddings: list[list[float]] | None = None

    @property
    def type(self) -> KBProviderType:
        """Provider type identifier."""
        return self._type

    async def connect(self) -> None:
        """Connect to the KB."""
        self._connected = True

    async def disconnect(self) -> None:
        """Disconnect from the KB."""
        self._connected = False

    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected

    def add_document(self, doc: MemoryDocument) -> None:
        """Add a document to the KB."""
        self._documents.append(doc)
        self._index_dirty = True
        self._embeddings_dirty = True

    def add_documents(self, docs: list[MemoryDocument]) -> None:
        """Add multiple documents to the KB."""
        self._documents.extend(docs)
        self._index_dirty = True
        self._embeddings_dirty = True

    def clear_documents(self) -> None:
        """Clear all documents."""
        self._documents = []
        self._index_dirty = True
        self._embeddings_dirty = True
        self._cached_doc_embeddings = None

    @property
    def document_count(self) -> int:
        """Get document count."""
        return len(self._documents)

    async def retrieve(self, query: RetrievalQuery) -> list[RetrievedChunk]:
        """Retrieve chunks based on query."""
        if not self._connected:
            raise RuntimeError("Not connected to KB")

        top_k = query.top_k if query.top_k is not None else 5
        min_score = query.min_score if query.min_score is not None else 0.0
        texts = [d.text for d in self._documents]

        # Rebuild BM25 index if documents changed
        if self._index_dirty:
            self._scorer.build_index(texts)
            self._index_dirty = False

        # Compute document embeddings if dirty and embed function available
        doc_embeddings: list[list[float]] | None = None
        query_embedding: list[float] | None = None

        if self._embed_fn is not None:
            if self._embeddings_dirty or self._cached_doc_embeddings is None:
                if len(texts) > 0:
                    self._cached_doc_embeddings = await self._embed_fn(texts)
                else:
                    self._cached_doc_embeddings = []
                self._embeddings_dirty = False
            doc_embeddings = self._cached_doc_embeddings

            # Embed the query
            q_emb_result = await self._embed_fn([query.query])
            query_embedding = q_emb_result[0]

        # Score all documents
        scored = self._scorer.score_all(query.query, texts, doc_embeddings, query_embedding)

        # Map back to documents, apply filters
        results: list[tuple[MemoryDocument, float]] = []
        for sr in scored:
            doc = self._documents[sr.index]
            score = sr.score

            # Apply metadata filters
            if query.filters is not None:
                if doc.metadata is None:
                    continue
                matches_filters = all(
                    doc.metadata.get(key) == value for key, value in query.filters.items()
                )
                if not matches_filters:
                    continue

            results.append((doc, score))

        # Filter and slice
        filtered = [(doc, score) for doc, score in results if score >= min_score][:top_k]

        # Convert to RetrievedChunk
        return [
            RetrievedChunk(
                id=doc.id,
                source=ChunkSource(
                    kb_id=self._kb_id,
                    uri=doc.uri,
                    title=doc.title,
                    metadata=doc.metadata,
                ),
                text=doc.text,
                score=score,
                metadata=doc.metadata,
            )
            for doc, score in filtered
        ]


def create_memory_kb_provider(options: MemoryKBProviderOptions) -> MemoryKBProvider:
    """Create an in-memory KB provider."""
    return MemoryKBProvider(options)


def create_test_kb_provider(kb_id: str = "test-kb") -> MemoryKBProvider:
    """Create a test KB provider with sample documents."""
    return MemoryKBProvider(
        MemoryKBProviderOptions(
            kb_id=kb_id,
            documents=[
                MemoryDocument(
                    id="doc-1",
                    text=(
                        "Our refund policy allows returns within 30 days of purchase. "
                        "Full refunds are provided for items in original condition."
                    ),
                    uri="https://docs.example.com/refund-policy",
                    title="Refund Policy",
                    metadata={"category": "policy", "product": "general"},
                ),
                MemoryDocument(
                    id="doc-2",
                    text=(
                        "To cancel your subscription, go to Settings > Account > Subscription "
                        "and click Cancel. Your access continues until the billing period ends."
                    ),
                    uri="https://docs.example.com/cancel-subscription",
                    title="Cancellation Guide",
                    metadata={"category": "howto", "product": "subscription"},
                ),
                MemoryDocument(
                    id="doc-3",
                    text=(
                        "EU customers are protected under GDPR. Data deletion requests are "
                        "processed within 30 days. Contact privacy@example.com for data requests."
                    ),
                    uri="https://docs.example.com/gdpr",
                    title="GDPR Compliance",
                    metadata={"category": "policy", "region": "EU"},
                ),
                MemoryDocument(
                    id="doc-4",
                    text=(
                        "Premium support is available 24/7 for enterprise customers. "
                        "Standard support hours are 9 AM to 6 PM EST, Monday through Friday."
                    ),
                    uri="https://docs.example.com/support-hours",
                    title="Support Hours",
                    metadata={"category": "support", "product": "general"},
                ),
                MemoryDocument(
                    id="doc-5",
                    text=(
                        "Password requirements: minimum 8 characters, at least one uppercase, "
                        "one lowercase, one number, and one special character."
                    ),
                    uri="https://docs.example.com/password-policy",
                    title="Password Policy",
                    metadata={"category": "security", "product": "general"},
                ),
            ],
        )
    )
