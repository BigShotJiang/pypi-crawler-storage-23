"""Knowledge base module for the Arelis AI SDK.

Provides knowledge base registration, retrieval, grounding, hybrid scoring,
and an in-memory provider for testing.
"""

from __future__ import annotations

# Grounding
from arelis.knowledge.grounding import (
    GroundingFilter,
    GroundingHelper,
    GroundingOptions,
    apply_grounding,
    create_grounding_helper,
    merge_retrieval_results,
)

# In-memory provider
from arelis.knowledge.memory_kb import (
    EmbedFunction,
    MemoryDocument,
    MemoryKBProvider,
    MemoryKBProviderOptions,
    MemoryKBScoringOptions,
    create_memory_kb_provider,
    create_test_kb_provider,
)

# Provider protocol
from arelis.knowledge.provider import KBProvider

# Registry
from arelis.knowledge.registry import (
    KBRegistry,
    RegisteredKB,
    create_kb_registry,
)

# Retriever
from arelis.knowledge.retriever import (
    ChunkFilterResult,
    KBRetriever,
    RetrievalOptions,
    create_kb_retriever,
    retrieve_from_kb,
)

# Scoring
from arelis.knowledge.scoring import (
    BM25Index,
    BM25Params,
    HybridScorer,
    HybridScorerOptions,
    ScoredResult,
    ScoredResultComponents,
    ScoringWeights,
    build_bm25_index,
    cosine_similarity,
    keyword_overlap,
    score_bm25,
    score_bm25_all,
    tokenize,
)

# Types
from arelis.knowledge.types import (
    ChunkSource,
    DataClassification,
    FilteredChunkEntry,
    GroundingResult,
    KBContext,
    KBGovernanceConfig,
    KBProviderType,
    KBRegistryOptions,
    KnowledgeBaseDescriptor,
    RetrievalQuery,
    RetrievalResult,
    RetrievedChunk,
    calculate_text_similarity,
    generate_query_id,
)

__all__ = [
    # Types
    "ChunkSource",
    "DataClassification",
    "FilteredChunkEntry",
    "GroundingResult",
    "KBContext",
    "KBGovernanceConfig",
    "KBProviderType",
    "KBRegistryOptions",
    "KnowledgeBaseDescriptor",
    "RetrievalQuery",
    "RetrievalResult",
    "RetrievedChunk",
    "calculate_text_similarity",
    "generate_query_id",
    # Provider
    "KBProvider",
    # Registry
    "KBRegistry",
    "RegisteredKB",
    "create_kb_registry",
    # Retriever
    "ChunkFilterResult",
    "KBRetriever",
    "RetrievalOptions",
    "create_kb_retriever",
    "retrieve_from_kb",
    # Grounding
    "GroundingFilter",
    "GroundingHelper",
    "GroundingOptions",
    "apply_grounding",
    "create_grounding_helper",
    "merge_retrieval_results",
    # Scoring
    "BM25Index",
    "BM25Params",
    "HybridScorer",
    "HybridScorerOptions",
    "ScoredResult",
    "ScoredResultComponents",
    "ScoringWeights",
    "build_bm25_index",
    "cosine_similarity",
    "keyword_overlap",
    "score_bm25",
    "score_bm25_all",
    "tokenize",
    # In-memory provider
    "EmbedFunction",
    "MemoryDocument",
    "MemoryKBProvider",
    "MemoryKBProviderOptions",
    "MemoryKBScoringOptions",
    "create_memory_kb_provider",
    "create_test_kb_provider",
]
