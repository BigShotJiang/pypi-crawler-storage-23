"""Knowledge base retriever.

Ports `packages/knowledge/src/retriever.ts` from the TypeScript SDK.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.core.types import GovernanceContext
from arelis.knowledge.registry import KBRegistry
from arelis.knowledge.types import (
    KBContext,
    RetrievalQuery,
    RetrievalResult,
    RetrievedChunk,
    generate_query_id,
)

__all__ = [
    "ChunkFilter",
    "KBRetriever",
    "RetrievalOptions",
    "create_kb_retriever",
    "retrieve_from_kb",
]


@dataclass
class RetrievalOptions:
    """Retrieval options."""

    skip_governance_check: bool = False
    top_k: int | None = None
    min_score: float | None = None


ChunkFilter = Callable[[RetrievedChunk, KBContext], "ChunkFilterResult"]
"""Chunk filter function for policy-based filtering."""


@dataclass
class ChunkFilterResult:
    """Result of a chunk filter evaluation."""

    allowed: bool
    reason: str | None = None


class KBRetriever:
    """Knowledge base retriever."""

    def __init__(self, registry: KBRegistry) -> None:
        self._registry = registry
        self._chunk_filters: list[ChunkFilter] = []

    def add_chunk_filter(self, filter_fn: ChunkFilter) -> None:
        """Add a chunk filter for policy-based filtering."""
        self._chunk_filters.append(filter_fn)

    def clear_chunk_filters(self) -> None:
        """Clear all chunk filters."""
        self._chunk_filters = []

    async def retrieve(
        self,
        query: RetrievalQuery,
        context: KBContext,
        options: RetrievalOptions | None = None,
    ) -> RetrievalResult:
        """Retrieve chunks from a knowledge base."""
        opts = options or RetrievalOptions()

        kb = self._registry.get_kb(query.kb)
        if kb is None:
            raise ValueError(f'KB "{query.kb}" not found')

        # Governance checks
        if not opts.skip_governance_check and not self._registry.is_purpose_approved(
            query.kb, context.governance.purpose
        ):
            raise ValueError(
                f'Purpose "{context.governance.purpose}" is not approved for KB "{query.kb}"'
            )

        # Get provider
        provider = self._registry.get_provider(query.kb)
        if provider is None:
            raise ValueError(f'No provider available for KB "{query.kb}"')

        if not provider.is_connected():
            await provider.connect()

        # Build query with defaults
        full_query = RetrievalQuery(
            query=query.query,
            kb=query.kb,
            top_k=(
                opts.top_k
                if opts.top_k is not None
                else (query.top_k if query.top_k is not None else self._registry.default_top_k)
            ),
            min_score=(
                opts.min_score
                if opts.min_score is not None
                else (
                    query.min_score
                    if query.min_score is not None
                    else self._registry.default_min_score
                )
            ),
            filters=query.filters,
            namespace=query.namespace,
        )

        # Execute retrieval
        chunks = await provider.retrieve(full_query)

        # Apply chunk filters
        filtered_chunks: list[RetrievedChunk] = []
        filtered_count = 0

        for chunk in chunks:
            allowed = True
            for filter_fn in self._chunk_filters:
                result = filter_fn(chunk, context)
                if not result.allowed:
                    allowed = False
                    filtered_count += 1
                    break
            if allowed:
                filtered_chunks.append(chunk)

        return RetrievalResult(
            chunks=filtered_chunks,
            query_id=generate_query_id(),
            kb_id=query.kb,
            timestamp=datetime.now(timezone.utc).isoformat(),
            total_found=len(chunks),
            filtered_count=filtered_count,
        )

    async def retrieve_multiple(
        self,
        queries: list[RetrievalQuery],
        context: KBContext,
        options: RetrievalOptions | None = None,
    ) -> list[RetrievalResult]:
        """Retrieve from multiple KBs."""
        return list(
            await asyncio.gather(*(self.retrieve(query, context, options) for query in queries))
        )


def create_kb_retriever(registry: KBRegistry) -> KBRetriever:
    """Create a new KB retriever."""
    return KBRetriever(registry)


async def retrieve_from_kb(
    registry: KBRegistry,
    query: RetrievalQuery,
    governance: GovernanceContext,
    run_id: str,
    options: RetrievalOptions | None = None,
) -> RetrievalResult:
    """Convenience function to retrieve from a KB."""
    retriever = KBRetriever(registry)
    return await retriever.retrieve(query, KBContext(run_id=run_id, governance=governance), options)
