"""Knowledge base types for the Arelis AI SDK.

Ports all types from the TypeScript SDK's `packages/knowledge/src/types.ts`.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Literal

from arelis.core.types import GovernanceContext

__all__ = [
    "ChunkSource",
    "DataClassification",
    "GroundingResult",
    "KBContext",
    "KBGovernanceConfig",
    "KBProviderType",
    "KBRegistryOptions",
    "KnowledgeBaseDescriptor",
    "RegisterKBInput",
    "RetrievalQuery",
    "RetrieveInput",
    "RetrievalResult",
    "RetrievedChunk",
    "calculate_text_similarity",
    "generate_query_id",
]

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

KBProviderType = Literal[
    "pinecone",
    "weaviate",
    "qdrant",
    "pgvector",
    "elastic",
    "memory",
    "custom",
]
"""Knowledge base provider types."""

VALID_KB_PROVIDERS: frozenset[str] = frozenset(
    ["pinecone", "weaviate", "qdrant", "pgvector", "elastic", "memory", "custom"]
)

DataClassification = Literal["public", "internal", "confidential", "restricted"]
"""Data classification levels."""


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class KBGovernanceConfig:
    """Knowledge base governance configuration."""

    data_residency: Literal["EU", "US", "APAC"] | None = None
    approved_for_purposes: list[str] | None = None
    data_class: DataClassification | None = None


@dataclass
class KnowledgeBaseDescriptor:
    """Knowledge base descriptor."""

    id: str
    provider: KBProviderType
    connection: dict[str, object]
    name: str | None = None
    region: str | None = None
    governance: KBGovernanceConfig | None = None
    tags: dict[str, str] | None = None


@dataclass
class ChunkSource:
    """Retrieved chunk source information."""

    kb_id: str
    uri: str | None = None
    title: str | None = None
    metadata: dict[str, object] | None = None


@dataclass
class RetrievedChunk:
    """Retrieved chunk from knowledge base."""

    id: str
    source: ChunkSource
    text: str
    score: float | None = None
    metadata: dict[str, object] | None = None


@dataclass
class RetrievalQuery:
    """Retrieval query parameters."""

    query: str
    kb: str
    top_k: int | None = None
    min_score: float | None = None
    filters: dict[str, object] | None = None
    namespace: str | None = None


@dataclass
class RetrievalResult:
    """Retrieval result."""

    chunks: list[RetrievedChunk]
    query_id: str
    kb_id: str
    timestamp: str
    total_found: int | None = None
    filtered_count: int | None = None


@dataclass
class FilteredChunkEntry:
    """A chunk that was filtered out during grounding."""

    chunk: RetrievedChunk
    reason: str


@dataclass
class GroundingResult:
    """Grounding result when chunks are applied to a prompt."""

    used_chunks: list[RetrievedChunk]
    filtered_chunks: list[FilteredChunkEntry]
    timestamp: str
    augmented_prompt: str | None = None


@dataclass
class KBContext:
    """Knowledge base retrieval context."""

    run_id: str
    governance: GovernanceContext
    metadata: dict[str, object] | None = None


@dataclass
class KBRegistryOptions:
    """KB registry options."""

    allow_overwrite: bool = False
    default_top_k: int = 5
    default_min_score: float = 0.0


# ---------------------------------------------------------------------------
# Client method input types
# ---------------------------------------------------------------------------


@dataclass
class RegisterKBInput:
    """Input for ``client.knowledge.register_kb()``."""

    kb: KnowledgeBaseDescriptor
    context: GovernanceContext | None = None


@dataclass
class RetrieveInput:
    """Input for ``client.knowledge.retrieve()``."""

    kb_id: str
    query: RetrievalQuery
    context: GovernanceContext | None = None
    options: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def generate_query_id() -> str:
    """Generate a unique query ID."""
    timestamp = _base36_encode(int(time.time() * 1000))
    import random as _random

    random_part = _base36_encode(_random.randint(0, 36**8 - 1)).ljust(8, "0")
    return f"kbq_{timestamp}_{random_part}"


def _base36_encode(num: int) -> str:
    """Encode a non-negative integer to base-36 string."""
    if num == 0:
        return "0"
    chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    result: list[str] = []
    while num > 0:
        result.append(chars[num % 36])
        num //= 36
    return "".join(reversed(result))


def calculate_text_similarity(text1: str, text2: str) -> float:
    """Calculate simple text similarity using Jaccard overlap.

    .. deprecated::
        Use :class:`~arelis.knowledge.scoring.HybridScorer` for better retrieval quality.
    """
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())

    intersection = words1 & words2
    union = words1 | words2

    if len(union) == 0:
        return 0.0
    return len(intersection) / len(union)
