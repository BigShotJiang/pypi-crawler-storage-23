"""Hybrid scoring primitives for knowledge base retrieval.

Provides tokenization, BM25, cosine similarity, keyword overlap,
and a composite :class:`HybridScorer` that blends all three signals.

Ports `packages/knowledge/src/scoring.ts` from the TypeScript SDK.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

__all__ = [
    "BM25Index",
    "BM25Params",
    "HybridScorer",
    "HybridScorerOptions",
    "ScoredResult",
    "ScoringWeights",
    "build_bm25_index",
    "cosine_similarity",
    "keyword_overlap",
    "score_bm25",
    "score_bm25_all",
    "tokenize",
]


# ---------------------------------------------------------------------------
# Stop words
# ---------------------------------------------------------------------------

STOP_WORDS: frozenset[str] = frozenset(
    [
        "a",
        "an",
        "the",
        "and",
        "or",
        "but",
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "with",
        "by",
        "from",
        "as",
        "is",
        "was",
        "are",
        "were",
        "been",
        "be",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "shall",
        "can",
        "need",
        "dare",
        "ought",
        "used",
        "it",
        "its",
        "he",
        "she",
        "we",
        "they",
        "i",
        "me",
        "him",
        "her",
        "us",
        "them",
        "my",
        "his",
        "our",
        "your",
        "their",
        "this",
        "that",
        "these",
        "those",
        "not",
        "no",
        "nor",
        "so",
        "if",
        "then",
        "than",
        "too",
        "very",
        "just",
        "about",
        "above",
        "after",
        "again",
        "all",
        "also",
        "am",
        "any",
        "because",
        "before",
        "between",
        "both",
        "each",
        "few",
        "more",
        "most",
        "other",
        "own",
        "same",
        "some",
        "such",
        "into",
        "over",
        "up",
        "down",
        "out",
        "off",
        "only",
        "once",
        "here",
        "there",
        "when",
        "where",
        "why",
        "how",
        "what",
        "which",
        "who",
        "whom",
    ]
)


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------


def tokenize(text: str, remove_stop_words: bool = False) -> list[str]:
    """Tokenize text into lowercase words, optionally removing stop words."""
    tokens = [t for t in text.lower().split() if len(t) > 0]
    if not remove_stop_words:
        return tokens
    return [t for t in tokens if t not in STOP_WORDS]


# ---------------------------------------------------------------------------
# BM25
# ---------------------------------------------------------------------------


@dataclass
class BM25Params:
    """BM25 tuning parameters."""

    k1: float = 1.2
    b: float = 0.75


@dataclass
class BM25Index:
    """BM25 index built from a collection of documents."""

    df: dict[str, int]
    doc_count: int
    avg_dl: float
    doc_tokens: list[list[str]]
    doc_lengths: list[int]


def build_bm25_index(
    texts: list[str],
    remove_stop_words: bool = False,
) -> BM25Index:
    """Build a BM25 index from a list of document texts."""
    doc_tokens = [tokenize(t, remove_stop_words) for t in texts]
    doc_lengths = [len(t) for t in doc_tokens]
    total_length = sum(doc_lengths)
    avg_dl = total_length / len(texts) if len(texts) > 0 else 0.0

    df: dict[str, int] = {}
    for tokens in doc_tokens:
        unique = set(tokens)
        for term in unique:
            df[term] = df.get(term, 0) + 1

    return BM25Index(
        df=df,
        doc_count=len(texts),
        avg_dl=avg_dl,
        doc_tokens=doc_tokens,
        doc_lengths=doc_lengths,
    )


def score_bm25(
    query_tokens: list[str],
    doc_index: int,
    index: BM25Index,
    params: BM25Params | None = None,
) -> float:
    """Score a single document against query tokens using BM25."""
    p = params or BM25Params()
    k1 = p.k1
    b = p.b
    n = index.doc_count
    dl = index.doc_lengths[doc_index] if doc_index < len(index.doc_lengths) else 0
    avgdl = index.avg_dl
    doc_toks = index.doc_tokens[doc_index] if doc_index < len(index.doc_tokens) else []

    # Build term frequency map for this document
    tf: dict[str, int] = {}
    for tok in doc_toks:
        tf[tok] = tf.get(tok, 0) + 1

    score = 0.0
    for term in query_tokens:
        df_val = index.df.get(term, 0)
        if df_val == 0:
            continue

        idf = math.log((n - df_val + 0.5) / (df_val + 0.5) + 1)
        term_freq = tf.get(term, 0)
        denom = avgdl if avgdl != 0 else 1.0
        tf_sat = (term_freq * (k1 + 1)) / (term_freq + k1 * (1 - b + b * (dl / denom)))
        score += idf * tf_sat

    return score


def score_bm25_all(
    query: str,
    index: BM25Index,
    params: BM25Params | None = None,
    remove_stop_words: bool = False,
) -> list[float]:
    """Score all documents against a query. Returns scores normalized to [0, 1]."""
    query_tokens = tokenize(query, remove_stop_words)
    raw = [score_bm25(query_tokens, i, index, params) for i in range(index.doc_count)]

    max_score = max(*raw, 0.0) if raw else 0.0
    if max_score == 0:
        return raw

    return [s / max_score for s in raw]


# ---------------------------------------------------------------------------
# Cosine similarity
# ---------------------------------------------------------------------------


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors, clamped to [0, 1].

    Returns 0 for zero-magnitude vectors.
    """
    length = min(len(a), len(b))
    dot = 0.0
    mag_a = 0.0
    mag_b = 0.0

    for i in range(length):
        ai = a[i] if i < len(a) else 0.0
        bi = b[i] if i < len(b) else 0.0
        dot += ai * bi
        mag_a += ai * ai
        mag_b += bi * bi

    denom = math.sqrt(mag_a) * math.sqrt(mag_b)
    if denom == 0:
        return 0.0

    return max(0.0, min(1.0, dot / denom))


# ---------------------------------------------------------------------------
# Keyword overlap (Jaccard)
# ---------------------------------------------------------------------------


def keyword_overlap(query_tokens: list[str], doc_tokens: list[str]) -> float:
    """Jaccard overlap between two pre-tokenized arrays."""
    q_set = set(query_tokens)
    d_set = set(doc_tokens)

    if len(q_set) == 0 and len(d_set) == 0:
        return 0.0

    intersection_size = len(q_set & d_set)
    union_size = len(q_set | d_set)

    if union_size == 0:
        return 0.0

    return intersection_size / union_size


# ---------------------------------------------------------------------------
# HybridScorer
# ---------------------------------------------------------------------------


@dataclass
class ScoringWeights:
    """Component weights for hybrid scoring."""

    embedding: float = 0.5
    bm25: float = 0.3
    keyword_overlap: float = 0.2


@dataclass
class HybridScorerOptions:
    """Options for the hybrid scorer."""

    weights: ScoringWeights | None = None
    bm25_params: BM25Params | None = None
    remove_stop_words: bool = True


@dataclass
class ScoredResultComponents:
    """Individual component scores for a scored result."""

    bm25: float
    keyword_overlap: float
    embedding: float | None = None


@dataclass
class ScoredResult:
    """A scored document result."""

    index: int
    score: float
    components: ScoredResultComponents


class HybridScorer:
    """Hybrid scorer that blends embedding similarity, BM25, and keyword overlap.

    When embeddings are not available, weights are redistributed proportionally
    across BM25 and keyword overlap.
    """

    def __init__(self, options: HybridScorerOptions | None = None) -> None:
        opts = options or HybridScorerOptions()
        w = opts.weights or ScoringWeights()
        self._weights = ScoringWeights(
            embedding=w.embedding,
            bm25=w.bm25,
            keyword_overlap=w.keyword_overlap,
        )
        self._bm25_params = opts.bm25_params or BM25Params()
        self._remove_stop_words = opts.remove_stop_words
        self._index: BM25Index | None = None

    def build_index(self, document_texts: list[str]) -> None:
        """Build (or rebuild) the BM25 index for the given document texts."""
        self._index = build_bm25_index(document_texts, self._remove_stop_words)

    def get_effective_weights(self, has_embeddings: bool) -> ScoringWeights:
        """Compute effective weights based on whether embeddings are available.

        When embeddings are absent, the embedding weight is redistributed
        proportionally to BM25 and keyword overlap.
        """
        if has_embeddings:
            return ScoringWeights(
                embedding=self._weights.embedding,
                bm25=self._weights.bm25,
                keyword_overlap=self._weights.keyword_overlap,
            )

        total = self._weights.bm25 + self._weights.keyword_overlap
        if total == 0:
            return ScoringWeights(embedding=0.0, bm25=0.5, keyword_overlap=0.5)

        return ScoringWeights(
            embedding=0.0,
            bm25=self._weights.bm25 / total,
            keyword_overlap=self._weights.keyword_overlap / total,
        )

    def score_all(
        self,
        query: str,
        document_texts: list[str],
        document_embeddings: list[list[float]] | None = None,
        query_embedding: list[float] | None = None,
    ) -> list[ScoredResult]:
        """Score all documents against a query.

        Args:
            query: The search query text.
            document_texts: Array of document texts (order must match build_index).
            document_embeddings: Optional pre-computed document embeddings.
            query_embedding: Optional pre-computed query embedding.

        Returns:
            Scored results sorted descending by score.
        """
        if self._index is None or self._index.doc_count != len(document_texts):
            self.build_index(document_texts)

        assert self._index is not None  # for type checker

        has_embeddings = document_embeddings is not None and query_embedding is not None
        effective_weights = self.get_effective_weights(has_embeddings)

        # BM25 scores (normalized to [0, 1])
        bm25_scores = score_bm25_all(query, self._index, self._bm25_params, self._remove_stop_words)

        # Keyword overlap scores
        query_tokens = tokenize(query, self._remove_stop_words)
        kw_scores = [
            keyword_overlap(query_tokens, tokenize(text, self._remove_stop_words))
            for text in document_texts
        ]

        # Build results
        results: list[ScoredResult] = []
        for i in range(len(document_texts)):
            bm25_val = bm25_scores[i] if i < len(bm25_scores) else 0.0
            kw_val = kw_scores[i] if i < len(kw_scores) else 0.0

            emb_score: float | None = None
            if has_embeddings:
                assert document_embeddings is not None
                assert query_embedding is not None
                doc_emb = document_embeddings[i] if i < len(document_embeddings) else []
                emb_score = cosine_similarity(query_embedding, doc_emb)

            score = (
                effective_weights.embedding * (emb_score if emb_score is not None else 0.0)
                + effective_weights.bm25 * bm25_val
                + effective_weights.keyword_overlap * kw_val
            )

            results.append(
                ScoredResult(
                    index=i,
                    score=score,
                    components=ScoredResultComponents(
                        bm25=bm25_val,
                        keyword_overlap=kw_val,
                        embedding=emb_score,
                    ),
                )
            )

        # Sort descending by score
        results.sort(key=lambda r: r.score, reverse=True)
        return results
