"""Grounding helper for applying retrieved chunks to prompts.

Ports `packages/knowledge/src/grounding.ts` from the TypeScript SDK.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone

from arelis.knowledge.types import (
    FilteredChunkEntry,
    GroundingResult,
    KBContext,
    RetrievalResult,
    RetrievedChunk,
)

__all__ = [
    "ChunkFilterResult",
    "GroundingFilter",
    "GroundingHelper",
    "GroundingOptions",
    "apply_grounding",
    "create_grounding_helper",
    "merge_retrieval_results",
]


@dataclass
class GroundingOptions:
    """Grounding options."""

    max_chunks: int = 5
    min_score: float = 0.0
    prompt_template: str | None = None
    include_citations: bool = True
    format_chunk: Callable[[RetrievedChunk, int], str] | None = None


@dataclass
class ChunkFilterResult:
    """Chunk filter result for grounding."""

    chunk: RetrievedChunk
    allowed: bool
    reason: str | None = None


GroundingFilter = Callable[[RetrievedChunk, KBContext], ChunkFilterResult]
"""Grounding filter function."""


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_PROMPT_TEMPLATE = (
    "Use the following context to answer the user's question. "
    "If the context doesn't contain relevant information, say so.\n\n"
    "Context:\n{chunks}\n\n---\n"
)


def _default_format_chunk(chunk: RetrievedChunk, index: int) -> str:
    """Default chunk formatter."""
    citation = chunk.source.title or chunk.source.uri or f"Source {index + 1}"
    return f"[{index + 1}] {citation}\n{chunk.text}"


# ---------------------------------------------------------------------------
# GroundingHelper
# ---------------------------------------------------------------------------


class GroundingHelper:
    """Grounding helper for applying retrieved chunks to prompts."""

    def __init__(self) -> None:
        self._filters: list[GroundingFilter] = []

    def add_filter(self, filter_fn: GroundingFilter) -> None:
        """Add a grounding filter."""
        self._filters.append(filter_fn)

    def clear_filters(self) -> None:
        """Clear all filters."""
        self._filters = []

    def apply_grounding(
        self,
        retrieval_result: RetrievalResult,
        context: KBContext,
        options: GroundingOptions | None = None,
    ) -> GroundingResult:
        """Apply grounding to create an augmented prompt."""
        opts = options or GroundingOptions()
        max_chunks = opts.max_chunks
        min_score = opts.min_score
        prompt_template = opts.prompt_template or DEFAULT_PROMPT_TEMPLATE
        format_chunk = opts.format_chunk or _default_format_chunk

        used_chunks: list[RetrievedChunk] = []
        filtered_chunks: list[FilteredChunkEntry] = []

        # Process each chunk
        for chunk in retrieval_result.chunks:
            # Check minimum score
            if chunk.score is not None and chunk.score < min_score:
                filtered_chunks.append(
                    FilteredChunkEntry(
                        chunk=chunk,
                        reason=f"Score {chunk.score} below minimum {min_score}",
                    )
                )
                continue

            # Check max chunks limit
            if len(used_chunks) >= max_chunks:
                filtered_chunks.append(
                    FilteredChunkEntry(
                        chunk=chunk,
                        reason=f"Exceeded maximum chunk limit of {max_chunks}",
                    )
                )
                continue

            # Apply custom filters
            allowed = True
            filter_reason = ""

            for filter_fn in self._filters:
                result = filter_fn(chunk, context)
                if not result.allowed:
                    allowed = False
                    filter_reason = result.reason or "Filtered by policy"
                    break

            if not allowed:
                filtered_chunks.append(FilteredChunkEntry(chunk=chunk, reason=filter_reason))
                continue

            used_chunks.append(chunk)

        # Format chunks for prompt
        formatted_chunks = "\n\n".join(
            format_chunk(chunk, index) for index, chunk in enumerate(used_chunks)
        )

        # Build augmented prompt
        augmented_prompt = prompt_template.replace("{chunks}", formatted_chunks)

        return GroundingResult(
            used_chunks=used_chunks,
            filtered_chunks=filtered_chunks,
            augmented_prompt=augmented_prompt,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def create_citations(
        self,
        used_chunks: list[RetrievedChunk],
    ) -> list[dict[str, object]]:
        """Create citations from used chunks."""
        citations: list[dict[str, object]] = []
        for index, chunk in enumerate(used_chunks):
            citation: dict[str, object] = {
                "index": index + 1,
                "source": chunk.source.kb_id,
            }
            if chunk.source.title is not None:
                citation["title"] = chunk.source.title
            if chunk.source.uri is not None:
                citation["uri"] = chunk.source.uri
            citations.append(citation)
        return citations

    def format_as_context(
        self,
        chunks: list[RetrievedChunk],
        include_scores: bool = False,
        include_metadata: bool = False,
    ) -> str:
        """Format chunks as a context string."""
        parts: list[str] = []
        for i, chunk in enumerate(chunks):
            formatted = f"[{i + 1}] {chunk.text}"
            if include_scores and chunk.score is not None:
                formatted += f" (score: {chunk.score:.2f})"
            if include_metadata and chunk.metadata is not None:
                formatted += f"\nMetadata: {json.dumps(chunk.metadata)}"
            parts.append(formatted)
        return "\n\n".join(parts)


def create_grounding_helper() -> GroundingHelper:
    """Create a new grounding helper."""
    return GroundingHelper()


def apply_grounding(
    retrieval_result: RetrievalResult,
    context: KBContext,
    options: GroundingOptions | None = None,
) -> GroundingResult:
    """Quick grounding function."""
    helper = GroundingHelper()
    return helper.apply_grounding(retrieval_result, context, options)


def merge_retrieval_results(results: list[RetrievalResult]) -> RetrievalResult:
    """Merge multiple retrieval results."""
    all_chunks: list[RetrievedChunk] = []
    total_found = 0
    total_filtered = 0

    for result in results:
        all_chunks.extend(result.chunks)
        total_found += result.total_found if result.total_found is not None else len(result.chunks)
        total_filtered += result.filtered_count if result.filtered_count is not None else 0

    # Sort by score descending
    all_chunks.sort(key=lambda c: c.score if c.score is not None else 0.0, reverse=True)

    return RetrievalResult(
        chunks=all_chunks,
        query_id=results[0].query_id if results else "",
        kb_id="+".join(r.kb_id for r in results),
        timestamp=datetime.now(timezone.utc).isoformat(),
        total_found=total_found,
        filtered_count=total_filtered,
    )
