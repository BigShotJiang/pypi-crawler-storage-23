"""Google Vertex AI provider adapter.

Ports the TypeScript SDK's `packages/providers-google-vertex/src/provider.ts`
and `packages/providers-google-vertex/src/mapping.ts`.

Requires the ``google-cloud-aiplatform`` extra::

    pip install "ai-governance-sdk[google-vertex]"
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Literal

import httpx

from arelis.models.provider import BaseModelProvider, ProviderCapabilityNotSupportedError
from arelis.models.types import (
    AudioFromImageResponse,
    AudioFromVideoResponse,
    AudioGenerationResponse,
    AudioInput,
    AudioToImageOptions,
    AudioToTextOptions,
    AudioToVideoOptions,
    FinishReason,
    GenerateOptions,
    ImageContentPart,
    ImageFromAudioResponse,
    ImageFromVideoResponse,
    ImageGenerationOptions,
    ImageGenerationResponse,
    ImageInput,
    ImageToAudioOptions,
    ImageToTextOptions,
    ImageToVideoOptions,
    ModelConfig,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelUsage,
    StreamChunk,
    TextContentPart,
    TextFromAudioResponse,
    TextFromImageResponse,
    TextFromVideoResponse,
    ToolCall,
    ToolCallDelta,
    ToolResultContentPart,
    ToolUseContentPart,
    VideoFromAudioResponse,
    VideoFromImageResponse,
    VideoGenerationOptions,
    VideoGenerationResponse,
    VideoInput,
    VideoToAudioOptions,
    VideoToImageOptions,
    VideoToTextOptions,
)
from arelis.providers.shared.base import (
    ProviderCapabilities,
    ProviderConfigBase,
    ensure_tool_call_args_object,
    extract_text_from_content,
    fetch_json,
    normalize_base64_input,
    parse_sse_json,
    split_system_messages,
    to_provider_tool_schema,
)

__all__ = [
    "VertexAIProvider",
    "VertexProviderConfig",
    "VertexAuthConfig",
    "VertexRequest",
    "VertexResponse",
    "build_vertex_request",
    "parse_vertex_response",
    "parse_vertex_stream_chunk",
]


# ---------------------------------------------------------------------------
# Config types
# ---------------------------------------------------------------------------


@dataclass
class VertexAuthAccessToken:
    """Static access token authentication."""

    access_token: str


@dataclass
class VertexAuthTokenProvider:
    """Dynamic access token authentication via callback."""

    get_access_token: object  # Callable[[], Awaitable[str]]


VertexAuthConfig = VertexAuthAccessToken | VertexAuthTokenProvider


@dataclass
class VertexProviderConfig(ProviderConfigBase):
    """Configuration for the Google Vertex AI provider."""

    project_id: str = ""
    location: str = ""
    publisher: str | None = None
    auth: VertexAuthConfig | None = None
    api_endpoint: str | None = None


# ---------------------------------------------------------------------------
# Vertex-specific request/response types
# ---------------------------------------------------------------------------

# VertexPart is represented as plain dicts for flexibility
VertexPart = dict[str, object]


@dataclass
class VertexContent:
    """A content block in a Vertex request."""

    role: Literal["user", "model"]
    parts: list[VertexPart]


@dataclass
class VertexGenerationConfig:
    """Generation config for Vertex requests."""

    max_output_tokens: int | None = None
    temperature: float | None = None
    top_p: float | None = None
    stop_sequences: list[str] | None = None
    response_modalities: list[str] | None = None
    image_config: dict[str, object] | None = None
    video_config: dict[str, object] | None = None


@dataclass
class VertexRequest:
    """A Vertex AI generateContent request body."""

    contents: list[VertexContent] = field(default_factory=list)
    system_instruction: dict[str, object] | None = None
    generation_config: VertexGenerationConfig | None = None
    tools: list[dict[str, object]] | None = None
    tool_config: dict[str, object] | None = None


@dataclass
class VertexUsageMetadata:
    """Token usage metadata from Vertex."""

    prompt_token_count: int | None = None
    candidates_token_count: int | None = None
    total_token_count: int | None = None


@dataclass
class VertexCandidate:
    """A candidate in a Vertex response."""

    content: dict[str, object] | None = None
    finish_reason: str | None = None


@dataclass
class VertexResponse:
    """A Vertex AI generateContent response."""

    candidates: list[VertexCandidate] | None = None
    usage_metadata: VertexUsageMetadata | None = None


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------

_ROLE_MAP: dict[str, Literal["user", "model"]] = {
    "user": "user",
    "assistant": "model",
    "tool": "user",
}


def _map_finish_reason(reason: str | None) -> FinishReason:
    """Map a Vertex finish reason to the SDK's FinishReason."""
    value = (reason or "").lower()
    if value in ("length", "max_tokens"):
        return "length"
    if value in ("content_filter", "safety"):
        return "content_filter"
    if value in ("tool_use", "tool_calls"):
        return "tool_use"
    return "stop"


def _map_message_parts(message: ModelMessage) -> list[VertexPart]:
    """Map a ModelMessage's content to Vertex parts."""
    if isinstance(message.content, str):
        return [{"text": message.content}]

    parts: list[VertexPart] = []
    for part in message.content:
        if isinstance(part, TextContentPart):
            parts.append({"text": part.text})
        elif isinstance(part, ImageContentPart):
            parts.append({"inlineData": {"mimeType": part.mime_type, "data": part.data}})
        elif isinstance(part, ToolUseContentPart):
            parts.append({"functionCall": {"name": part.name, "args": part.input}})
        elif isinstance(part, ToolResultContentPart):
            response: dict[str, object]
            if isinstance(part.content, str):
                try:
                    response = json.loads(part.content)
                except (json.JSONDecodeError, ValueError):
                    response = {"result": part.content}
            else:
                response = {"result": part.content}
            parts.append({"functionResponse": {"name": part.id, "response": response}})
    return parts


def build_vertex_request(
    request: ModelRequest,
    options: GenerateOptions | None = None,
) -> VertexRequest:
    """Build a Vertex AI request from a ModelRequest."""
    split = split_system_messages(request.messages)
    contents: list[VertexContent] = [
        VertexContent(
            role=_ROLE_MAP.get(msg.role, "user"),
            parts=_map_message_parts(msg),
        )
        for msg in split.rest
    ]

    gen_config = VertexGenerationConfig()
    has_config = False

    max_tokens = (options.max_tokens if options else None) or (
        request.config.max_tokens if request.config else None
    )
    if max_tokens is not None:
        gen_config.max_output_tokens = max_tokens
        has_config = True

    if request.config:
        if request.config.temperature is not None:
            gen_config.temperature = request.config.temperature
            has_config = True
        if request.config.top_p is not None:
            gen_config.top_p = request.config.top_p
            has_config = True
        if request.config.stop:
            gen_config.stop_sequences = request.config.stop
            has_config = True

    tools_list: list[dict[str, object]] | None = None
    if request.tools:
        func_decls = [
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": to_provider_tool_schema(tool.parameters),
            }
            for tool in request.tools
        ]
        tools_list = [{"functionDeclarations": func_decls}]

    return VertexRequest(
        contents=contents,
        system_instruction=({"parts": [{"text": split.system}]} if split.system else None),
        generation_config=gen_config if has_config else None,
        tools=tools_list,
        tool_config=({"functionCallingConfig": {"mode": "AUTO"}} if tools_list else None),
    )


def _parse_vertex_raw_response(raw: dict[str, object]) -> VertexResponse:
    """Parse a raw JSON dict into a VertexResponse."""
    candidates_raw = raw.get("candidates") or []
    candidates: list[VertexCandidate] = []
    for cand in candidates_raw:  # type: ignore[attr-defined]
        if isinstance(cand, dict):
            candidates.append(
                VertexCandidate(
                    content=cand.get("content"),
                    finish_reason=cand.get("finishReason"),
                )
            )

    usage_raw = raw.get("usageMetadata")
    usage: VertexUsageMetadata | None = None
    if isinstance(usage_raw, dict):
        usage = VertexUsageMetadata(
            prompt_token_count=usage_raw.get("promptTokenCount"),
            candidates_token_count=usage_raw.get("candidatesTokenCount"),
            total_token_count=usage_raw.get("totalTokenCount"),
        )

    return VertexResponse(candidates=candidates, usage_metadata=usage)


def parse_vertex_response(
    raw: dict[str, object],
    request: ModelRequest,
) -> ModelResponse:
    """Parse a Vertex AI response into a ModelResponse."""
    response = _parse_vertex_raw_response(raw)
    candidate = response.candidates[0] if response.candidates else None
    parts_raw: list[object] = []
    if candidate and candidate.content and isinstance(candidate.content, dict):
        parts_raw = candidate.content.get("parts", []) or []  # type: ignore[assignment]

    text_parts: list[str] = []
    tool_calls: list[ToolCall] = []

    for part in parts_raw:
        if not isinstance(part, dict):
            continue
        if "text" in part and part["text"]:
            text_parts.append(str(part["text"]))
        elif "functionCall" in part:
            fc = part["functionCall"]
            if isinstance(fc, dict):
                tool_calls.append(
                    ToolCall(
                        id=f"tool_{len(tool_calls) + 1}",
                        name=str(fc.get("name", "")),
                        arguments=ensure_tool_call_args_object(fc.get("args", {})),
                    )
                )

    usage = ModelUsage(
        input_tokens=response.usage_metadata.prompt_token_count or 0
        if response.usage_metadata
        else 0,
        output_tokens=response.usage_metadata.candidates_token_count or 0
        if response.usage_metadata
        else 0,
        total_tokens=response.usage_metadata.total_token_count or 0
        if response.usage_metadata
        else 0,
    )

    from datetime import datetime

    return ModelResponse(
        id=f"vertex_{int(time.time() * 1000)}",
        model=request.model,
        content="".join(text_parts),
        tool_calls=tool_calls if tool_calls else None,
        finish_reason=_map_finish_reason(candidate.finish_reason if candidate else None),
        usage=usage,
        created_at=datetime.now(),
        provider_metadata={"raw": raw},
    )


def parse_vertex_stream_chunk(
    raw: dict[str, object],
    _request: ModelRequest,
) -> list[StreamChunk]:
    """Parse a single Vertex AI stream chunk into StreamChunks."""
    response = _parse_vertex_raw_response(raw)
    chunks: list[StreamChunk] = []
    candidate = response.candidates[0] if response.candidates else None
    parts_raw: list[object] = []
    if candidate and candidate.content and isinstance(candidate.content, dict):
        parts_raw = candidate.content.get("parts", []) or []  # type: ignore[assignment]

    for part in parts_raw:
        if not isinstance(part, dict):
            continue
        if "text" in part and part["text"]:
            chunks.append(StreamChunk(type="content", content=str(part["text"])))
        elif "functionCall" in part:
            fc = part["functionCall"]
            if isinstance(fc, dict):
                chunks.append(
                    StreamChunk(
                        type="tool_call",
                        tool_call=ToolCallDelta(
                            index=0,
                            name=str(fc.get("name", "")),
                            arguments=ensure_tool_call_args_object(fc.get("args", {})),
                        ),
                    )
                )

    if response.usage_metadata:
        chunks.append(
            StreamChunk(
                type="usage",
                usage=ModelUsage(
                    input_tokens=response.usage_metadata.prompt_token_count,
                    output_tokens=response.usage_metadata.candidates_token_count,
                    total_tokens=response.usage_metadata.total_token_count,
                ),
            )
        )

    if candidate and candidate.finish_reason:
        chunks.append(
            StreamChunk(
                type="done",
                finish_reason=_map_finish_reason(candidate.finish_reason),
            )
        )

    return chunks


# ---------------------------------------------------------------------------
# Veo (video generation) types
# ---------------------------------------------------------------------------


@dataclass
class VeoOperationResponse:
    """Response from a Veo long-running operation."""

    name: str = ""
    done: bool = False
    response: dict[str, object] | None = None
    error: dict[str, object] | None = None


# ---------------------------------------------------------------------------
# VertexAIProvider
# ---------------------------------------------------------------------------


class VertexAIProvider(BaseModelProvider):
    """Google Vertex AI model provider.

    Supports text generation, streaming, multimodal input, image generation
    (via Imagen), and video generation (via Veo).
    """

    def __init__(
        self,
        config: VertexProviderConfig,
        supported_models: list[str] | None = None,
    ) -> None:
        self._config = config
        self._supported_models = supported_models or []
        self._capabilities = ProviderCapabilities(
            streaming=True,
            tool_calls=True,
            multimodal=True,
            image_generation=True,
            audio_generation=False,
            video_generation=True,
            image_to_text=True,
            image_to_audio=False,
            image_to_video=True,
            audio_to_text=False,
            audio_to_image=False,
            audio_to_video=False,
            video_to_text=False,
            video_to_image=False,
            video_to_audio=False,
        )

    @property
    def id(self) -> str:
        return "google-vertex"

    @property
    def name(self) -> str:
        return "Google Vertex AI"

    @property
    def supported_models(self) -> list[str]:
        return self._supported_models

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._capabilities

    # -- Auth ---------------------------------------------------------------

    async def _get_access_token(self) -> str:
        """Resolve the access token from config."""
        if self._config.auth is None:
            raise ValueError("Vertex AI auth config is required")
        if isinstance(self._config.auth, VertexAuthAccessToken):
            return self._config.auth.access_token
        get_fn = self._config.auth.get_access_token
        if asyncio.iscoroutinefunction(get_fn):
            return await get_fn()  # type: ignore[no-any-return]
        return get_fn()  # type: ignore[no-any-return, operator]

    # -- Endpoint builders ---------------------------------------------------

    def _build_endpoint(self, model_id: str, stream: bool) -> str:
        base = self._config.api_endpoint or (
            f"https://{self._config.location}-aiplatform.googleapis.com"
        )
        publisher = self._config.publisher or "google"
        method = "streamGenerateContent" if stream else "generateContent"
        url = (
            f"{base}/v1/projects/{self._config.project_id}"
            f"/locations/{self._config.location}"
            f"/publishers/{publisher}/models/{model_id}:{method}"
        )
        return f"{url}?alt=sse" if stream else url

    def _build_veo_endpoint(self, model_id: str) -> str:
        base = self._config.api_endpoint or (
            f"https://{self._config.location}-aiplatform.googleapis.com"
        )
        publisher = self._config.publisher or "google"
        return (
            f"{base}/v1/projects/{self._config.project_id}"
            f"/locations/{self._config.location}"
            f"/publishers/{publisher}/models/{model_id}:predictLongRunning"
        )

    def _build_veo_operation_url(self, operation_name: str) -> str:
        base = self._config.api_endpoint or (
            f"https://{self._config.location}-aiplatform.googleapis.com"
        )
        return f"{base}/v1/{operation_name}"

    # -- Internal request helpers -------------------------------------------

    async def _request_json(self, model_id: str, body: dict[str, object]) -> dict[str, object]:
        token = await self._get_access_token()
        result = await fetch_json(
            self._build_endpoint(model_id, stream=False),
            method="POST",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            body=json.dumps(body),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )
        return result  # type: ignore[return-value]

    def _serialize_vertex_request(self, req: VertexRequest) -> dict[str, object]:
        """Serialize a VertexRequest to a plain dict for JSON."""
        contents: list[dict[str, object]] = []
        for c in req.contents:
            contents.append({"role": c.role, "parts": c.parts})

        body: dict[str, object] = {"contents": contents}
        if req.system_instruction is not None:
            body["systemInstruction"] = req.system_instruction
        if req.generation_config is not None:
            gc: dict[str, object] = {}
            if req.generation_config.max_output_tokens is not None:
                gc["maxOutputTokens"] = req.generation_config.max_output_tokens
            if req.generation_config.temperature is not None:
                gc["temperature"] = req.generation_config.temperature
            if req.generation_config.top_p is not None:
                gc["topP"] = req.generation_config.top_p
            if req.generation_config.stop_sequences is not None:
                gc["stopSequences"] = req.generation_config.stop_sequences
            if req.generation_config.response_modalities is not None:
                gc["responseModalities"] = req.generation_config.response_modalities
            if req.generation_config.image_config is not None:
                gc["imageConfig"] = req.generation_config.image_config
            if req.generation_config.video_config is not None:
                gc["videoConfig"] = req.generation_config.video_config
            if gc:
                body["generationConfig"] = gc
        if req.tools is not None:
            body["tools"] = req.tools
        if req.tool_config is not None:
            body["toolConfig"] = req.tool_config
        return body

    # -- Unsupported helper -------------------------------------------------

    def _unsupported(self, capability: str) -> None:
        raise ProviderCapabilityNotSupportedError(self.id, capability)

    # -- Core generation ----------------------------------------------------

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        self.validate_request(request)
        payload = build_vertex_request(request, options)
        body = self._serialize_vertex_request(payload)
        raw = await self._request_json(request.model, body)
        return parse_vertex_response(raw, request)

    async def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        self.validate_request(request)
        payload = build_vertex_request(request, options)
        body = self._serialize_vertex_request(payload)
        token = await self._get_access_token()
        url = self._build_endpoint(request.model, stream=True)

        client, should_close = (
            (self._config.http_client, False)
            if self._config.http_client
            else (httpx.AsyncClient(), True)
        )
        try:
            async with client.stream(
                "POST",
                url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                },
                content=json.dumps(body),
                timeout=self._config.timeout_ms / 1000.0 if self._config.timeout_ms else 30.0,
            ) as resp:
                if resp.status_code >= 400:
                    error_text = await resp.aread()
                    raise ValueError(
                        f"Vertex stream error {resp.status_code}: {error_text.decode()}"
                    )

                async for chunk_obj in parse_sse_json(resp.aiter_bytes()):
                    if isinstance(chunk_obj, dict):
                        mapped = parse_vertex_stream_chunk(chunk_obj, request)
                        for item in mapped:
                            yield item
        finally:
            if should_close:
                await client.aclose()

    # -- Media: extract helpers ---------------------------------------------

    @staticmethod
    def _decode_base64_to_bytes(base64_data: str) -> bytes:
        return base64.b64decode(base64_data)

    def _extract_media_from_response(
        self,
        raw: dict[str, object],
        modality: Literal["image", "video"],
    ) -> tuple[bytes, str, str | None]:
        """Extract binary media from a Vertex response.

        Returns ``(data, mime_type, url)``.
        """
        response = _parse_vertex_raw_response(raw)
        candidate = response.candidates[0] if response.candidates else None
        parts_raw: list[object] = []
        if candidate and candidate.content and isinstance(candidate.content, dict):
            parts_raw = candidate.content.get("parts", []) or []  # type: ignore[assignment]

        for part in parts_raw:
            if not isinstance(part, dict):
                continue

            inline = part.get("inlineData")
            if isinstance(inline, dict):
                mime = str(inline.get("mimeType", ""))
                if mime and not mime.startswith(f"{modality}/"):
                    continue
                b64 = str(inline.get("data", ""))
                return (
                    self._decode_base64_to_bytes(b64),
                    mime or (f"{modality}/png" if modality == "image" else f"{modality}/mp4"),
                    None,
                )

            file_data = part.get("fileData")
            if isinstance(file_data, dict):
                mime = str(file_data.get("mimeType", ""))
                if mime and not mime.startswith(f"{modality}/"):
                    continue
                uri = str(file_data.get("fileUri", ""))
                return (
                    b"",
                    mime or (f"{modality}/png" if modality == "image" else f"{modality}/mp4"),
                    uri or None,
                )

        raise ValueError(f"No {modality} data found in Vertex AI response")

    # -- Image generation ---------------------------------------------------

    async def generate_image(
        self,
        prompt: str,
        options: ImageGenerationOptions | None = None,
    ) -> ImageGenerationResponse:
        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for image generation")

        aspect_ratio: str | None = None
        if options and options.provider_options:
            ar = options.provider_options.get("aspectRatio")
            if isinstance(ar, str):
                aspect_ratio = ar

        gen_config: dict[str, object] = {"responseModalities": ["IMAGE"]}
        if aspect_ratio:
            gen_config["imageConfig"] = {"aspectRatio": aspect_ratio}

        body: dict[str, object] = {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": gen_config,
        }

        raw = await self._request_json(model, body)
        data, mime_type, url = self._extract_media_from_response(raw, "image")

        from datetime import datetime

        return ImageGenerationResponse(
            id=f"vertex_img_{int(time.time() * 1000)}",
            model=model,
            data=data,
            mime_type=mime_type,
            url=url,
            created_at=datetime.now(),
            provider_metadata={"raw": raw},
        )

    # -- Audio generation (unsupported) -------------------------------------

    async def generate_audio(
        self,
        _prompt: str,
        _options: object | None = None,
    ) -> AudioGenerationResponse:
        self._unsupported("audioGeneration")
        raise AssertionError("unreachable")  # for type checker

    # -- Video generation (Veo) ---------------------------------------------

    def _build_veo_parameters(self, options: VideoGenerationOptions | None) -> dict[str, object]:
        provider_options = (options.provider_options if options else None) or {}
        params: dict[str, object] = {"sampleCount": 1}

        for key in ("aspectRatio", "durationSeconds", "sampleCount", "generateAudio", "resolution"):
            val = provider_options.get(key)
            if val is not None:
                params[key] = val

        return params

    async def _poll_veo_operation(
        self, operation_name: str, timeout_ms: int = 180_000
    ) -> dict[str, object]:
        token = await self._get_access_token()
        url = self._build_veo_operation_url(operation_name)
        start = time.monotonic()
        delay = 2.0
        max_delay = 10.0
        backoff_factor = 1.5

        while (time.monotonic() - start) * 1000 < timeout_ms:
            await asyncio.sleep(delay)
            result = await fetch_json(
                url,
                method="GET",
                headers={"Authorization": f"Bearer {token}"},
                http_client=self._config.http_client,
            )
            if not isinstance(result, dict):
                continue

            error = result.get("error")
            if isinstance(error, dict):
                msg = error.get("message", "unknown")
                code = error.get("code", "?")
                raise ValueError(f"Veo operation failed: {msg} (code {code})")

            if result.get("done"):
                return result

            delay = min(delay * backoff_factor, max_delay)

        raise TimeoutError(f"Veo operation timed out after {timeout_ms}ms")

    def _extract_veo_video(self, response: dict[str, object]) -> tuple[bytes, str, str | None]:
        resp_data = response.get("response")
        if isinstance(resp_data, dict):
            videos = resp_data.get("videos")
            if isinstance(videos, list) and videos:
                first = videos[0]
                if isinstance(first, dict):
                    video_data = first.get("video")
                    if isinstance(video_data, dict):
                        b64 = video_data.get("bytesBase64Encoded")
                        if isinstance(b64, str):
                            mime = str(first.get("mimeType", "video/mp4"))
                            return self._decode_base64_to_bytes(b64), mime, None

            samples = resp_data.get("generatedSamples")
            if isinstance(samples, list) and samples:
                first_sample = samples[0]
                if isinstance(first_sample, dict):
                    vid = first_sample.get("video")
                    if isinstance(vid, dict):
                        uri = vid.get("uri")
                        if isinstance(uri, str):
                            return b"", "video/mp4", uri

        raise ValueError("No video data found in Veo response")

    async def generate_video(
        self,
        prompt: str,
        options: VideoGenerationOptions | None = None,
    ) -> VideoGenerationResponse:
        if not self._capabilities.video_generation:
            self._unsupported("videoGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for video generation")

        token = await self._get_access_token()
        veo_url = self._build_veo_endpoint(model)
        parameters = self._build_veo_parameters(options)

        body = {"instances": [{"prompt": prompt}], "parameters": parameters}
        timeout_ms = self._config.timeout_ms or 180_000

        operation = await fetch_json(
            veo_url,
            method="POST",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            body=json.dumps(body),
            http_client=self._config.http_client,
            timeout_ms=timeout_ms,
        )

        if not isinstance(operation, dict):
            raise ValueError("Invalid Veo operation response")

        completed = await self._poll_veo_operation(str(operation.get("name", "")), timeout_ms)
        data, mime_type, url = self._extract_veo_video(completed)

        from datetime import datetime

        return VideoGenerationResponse(
            id=f"vertex_vid_{int(time.time() * 1000)}",
            model=model,
            data=data,
            mime_type=mime_type,
            url=url,
            created_at=datetime.now(),
            provider_metadata={"raw": completed},
        )

    # -- Image-to-text ------------------------------------------------------

    async def image_to_text(
        self,
        media_input: ImageInput,
        options: ImageToTextOptions | None = None,
    ) -> TextFromImageResponse:
        if not self._capabilities.image_to_text:
            self._unsupported("imageToText")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for imageToText")

        payload = normalize_base64_input(media_input)
        prompt_text = (options.prompt if options else None) or "Describe this image."

        config: ModelConfig | None = None
        if options and options.config:
            config = options.config

        img_request = ModelRequest(
            model=model,
            messages=[
                ModelMessage(
                    role="user",
                    content=[
                        TextContentPart(text=prompt_text),
                        ImageContentPart(data=payload.base64, mime_type=payload.mime_type),
                    ],
                ),
            ],
            config=config,
        )
        response = await self.generate(img_request)

        return TextFromImageResponse(
            id=response.id,
            model=response.model,
            text=extract_text_from_content(response.content),
            created_at=response.created_at,
            provider_metadata=response.provider_metadata,
        )

    # -- Image-to-video (Veo) -----------------------------------------------

    async def image_to_video(
        self,
        media_input: ImageInput,
        options: ImageToVideoOptions | None = None,
    ) -> VideoFromImageResponse:
        if not self._capabilities.image_to_video:
            self._unsupported("imageToVideo")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for imageToVideo")

        payload = normalize_base64_input(media_input)
        prompt_text = (options.prompt if options else None) or "Generate a video from this image."

        token = await self._get_access_token()
        veo_url = self._build_veo_endpoint(model)
        parameters = self._build_veo_parameters(options)

        body = {
            "instances": [
                {
                    "prompt": prompt_text,
                    "image": {
                        "bytesBase64Encoded": payload.base64,
                        "mimeType": payload.mime_type,
                    },
                }
            ],
            "parameters": parameters,
        }
        timeout_ms = self._config.timeout_ms or 180_000

        operation = await fetch_json(
            veo_url,
            method="POST",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            body=json.dumps(body),
            http_client=self._config.http_client,
            timeout_ms=timeout_ms,
        )

        if not isinstance(operation, dict):
            raise ValueError("Invalid Veo operation response")

        completed = await self._poll_veo_operation(str(operation.get("name", "")), timeout_ms)
        data, mime_type, url = self._extract_veo_video(completed)

        from datetime import datetime

        return VideoFromImageResponse(
            id=f"vertex_vid_{int(time.time() * 1000)}",
            model=model,
            data=data,
            mime_type=mime_type,
            url=url,
            created_at=datetime.now(),
            provider_metadata={"raw": completed},
        )

    # -- Unsupported cross-modal methods ------------------------------------

    async def image_to_audio(
        self, _input: ImageInput, _options: ImageToAudioOptions | None = None
    ) -> AudioFromImageResponse:
        self._unsupported("imageToAudio")
        raise AssertionError("unreachable")

    async def audio_to_text(
        self, _input: AudioInput, _options: AudioToTextOptions | None = None
    ) -> TextFromAudioResponse:
        self._unsupported("audioToText")
        raise AssertionError("unreachable")

    async def audio_to_image(
        self, _input: AudioInput, _options: AudioToImageOptions | None = None
    ) -> ImageFromAudioResponse:
        self._unsupported("audioToImage")
        raise AssertionError("unreachable")

    async def audio_to_video(
        self, _input: AudioInput, _options: AudioToVideoOptions | None = None
    ) -> VideoFromAudioResponse:
        self._unsupported("audioToVideo")
        raise AssertionError("unreachable")

    async def video_to_text(
        self, _input: VideoInput, _options: VideoToTextOptions | None = None
    ) -> TextFromVideoResponse:
        self._unsupported("videoToText")
        raise AssertionError("unreachable")

    async def video_to_image(
        self, _input: VideoInput, _options: VideoToImageOptions | None = None
    ) -> ImageFromVideoResponse:
        self._unsupported("videoToImage")
        raise AssertionError("unreachable")

    async def video_to_audio(
        self, _input: VideoInput, _options: VideoToAudioOptions | None = None
    ) -> AudioFromVideoResponse:
        self._unsupported("videoToAudio")
        raise AssertionError("unreachable")
