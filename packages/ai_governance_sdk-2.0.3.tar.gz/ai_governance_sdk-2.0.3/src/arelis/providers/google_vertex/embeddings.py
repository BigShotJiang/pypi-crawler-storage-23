"""Google Vertex AI embedding function.

Ports ``createVertexEmbedFunction`` from the TypeScript SDK's
``packages/providers-google-vertex/src/embeddings.ts``.

Provides a factory that returns an async callable compatible with
knowledge-base and memory embedding interfaces.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Literal

import httpx

from arelis.providers.google_vertex.provider import (
    VertexAuthAccessToken,
    VertexAuthConfig,
)

__all__ = [
    "GeminiEmbeddingTaskType",
    "VertexEmbeddingConfig",
    "create_vertex_embed_function",
]

# ---------------------------------------------------------------------------
# Task type literal
# ---------------------------------------------------------------------------

GeminiEmbeddingTaskType = Literal[
    "RETRIEVAL_QUERY",
    "RETRIEVAL_DOCUMENT",
    "SEMANTIC_SIMILARITY",
    "CLASSIFICATION",
    "CLUSTERING",
    "QUESTION_ANSWERING",
    "FACT_VERIFICATION",
]
"""Gemini embedding task types.

See https://cloud.google.com/vertex-ai/generative-ai/docs/embeddings/get-text-embeddings
"""

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class VertexEmbeddingConfig:
    """Configuration for the Vertex AI embedding function.

    Attributes:
        project_id: Google Cloud project ID.
        location: Google Cloud region (e.g. ``'us-central1'``).
        auth: Authentication configuration (static token or provider).
        model: Embedding model name (default: ``'gemini-embedding-001'``).
        task_type: Task type hint (default: ``'RETRIEVAL_DOCUMENT'``).
        output_dimensionality: Output vector dimensionality (model-dependent, 128-3072).
        api_endpoint: Custom API endpoint override.
        timeout_ms: Request timeout in milliseconds.
    """

    project_id: str
    location: str
    auth: VertexAuthConfig
    model: str | None = None
    task_type: GeminiEmbeddingTaskType | None = None
    output_dimensionality: int | None = None
    api_endpoint: str | None = None
    timeout_ms: int | None = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


async def _resolve_access_token(auth: VertexAuthConfig) -> str:
    """Resolve the access token from an auth config."""
    if isinstance(auth, VertexAuthAccessToken):
        return auth.access_token
    get_fn = auth.get_access_token
    if asyncio.iscoroutinefunction(get_fn):
        result: str = await get_fn()
        return result
    return get_fn()  # type: ignore[no-any-return, operator]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_vertex_embed_function(
    config: VertexEmbeddingConfig,
) -> Callable[[list[str]], Awaitable[list[list[float]]]]:
    """Create an embedding function backed by Vertex AI's Gemini embedding model.

    The returned async callable accepts a list of text strings and returns a
    list of embedding vectors (one per input text).

    Example::

        embed = create_vertex_embed_function(VertexEmbeddingConfig(
            project_id="my-project",
            location="us-central1",
            auth=VertexAuthAccessToken(access_token="ya29..."),
        ))

        vectors = await embed(["hello world", "goodbye"])

    Args:
        config: Embedding configuration including project, location, and auth.

    Returns:
        An async callable ``(texts: list[str]) -> list[list[float]]``.
    """
    model = config.model or "gemini-embedding-001"
    task_type: GeminiEmbeddingTaskType = config.task_type or "RETRIEVAL_DOCUMENT"
    base = config.api_endpoint or f"https://{config.location}-aiplatform.googleapis.com"
    url = (
        f"{base}/v1/projects/{config.project_id}/locations/{config.location}"
        f"/publishers/google/models/{model}:predict"
    )

    async def embed(texts: list[str]) -> list[list[float]]:
        token = await _resolve_access_token(config.auth)

        instances: list[dict[str, object]] = []
        for text in texts:
            instance: dict[str, object] = {"content": text, "taskType": task_type}
            if config.output_dimensionality is not None:
                instance["outputDimensionality"] = config.output_dimensionality
            instances.append(instance)

        body = {"instances": instances}

        timeout = config.timeout_ms / 1000.0 if config.timeout_ms is not None else 30.0

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=body,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()

        predictions: list[dict[str, object]] = data["predictions"]
        result: list[list[float]] = []
        for prediction in predictions:
            embeddings = prediction["embeddings"]
            assert isinstance(embeddings, dict)
            values = embeddings["values"]
            assert isinstance(values, list)
            result.append(values)
        return result

    return embed
