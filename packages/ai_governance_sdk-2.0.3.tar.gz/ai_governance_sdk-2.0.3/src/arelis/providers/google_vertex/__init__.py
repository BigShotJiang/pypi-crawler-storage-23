"""Google Vertex AI provider package."""

from __future__ import annotations

from arelis.providers.google_vertex.embeddings import (
    GeminiEmbeddingTaskType,
    VertexEmbeddingConfig,
    create_vertex_embed_function,
)
from arelis.providers.google_vertex.provider import (
    VertexAIProvider,
    VertexAuthAccessToken,
    VertexAuthConfig,
    VertexAuthTokenProvider,
    VertexProviderConfig,
    VertexRequest,
    VertexResponse,
    build_vertex_request,
    parse_vertex_response,
    parse_vertex_stream_chunk,
)

__all__ = [
    "GeminiEmbeddingTaskType",
    "VertexAIProvider",
    "VertexAuthAccessToken",
    "VertexAuthConfig",
    "VertexAuthTokenProvider",
    "VertexEmbeddingConfig",
    "VertexProviderConfig",
    "VertexRequest",
    "VertexResponse",
    "build_vertex_request",
    "create_vertex_embed_function",
    "parse_vertex_response",
    "parse_vertex_stream_chunk",
]
