"""On-premise (OpenAI-compatible) provider package."""

from __future__ import annotations

from arelis.providers.onpremise.provider import (
    OnPremiseConfig,
    OnPremiseEndpoints,
    OnPremiseProvider,
    build_onpremise_chat_request,
    create_onpremise_provider,
    parse_onpremise_chat_response,
    parse_onpremise_stream_chunk,
)

__all__ = [
    "OnPremiseProvider",
    "OnPremiseConfig",
    "OnPremiseEndpoints",
    "create_onpremise_provider",
    "build_onpremise_chat_request",
    "parse_onpremise_chat_response",
    "parse_onpremise_stream_chunk",
]
