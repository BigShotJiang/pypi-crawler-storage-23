"""On-premise (OpenAI-compatible) provider adapter.

Ports the TypeScript SDK's `packages/providers-onpremise/src/provider.ts`
and `packages/providers-onpremise/src/mapping.ts`.

Uses ``httpx`` for HTTP requests. No additional dependencies required.
"""

from __future__ import annotations

import base64
import json
import re
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime

import httpx

from arelis.models.provider import BaseModelProvider, ProviderCapabilityNotSupportedError
from arelis.models.types import (
    AudioGenerationOptions,
    AudioGenerationResponse,
    FinishReason,
    GenerateOptions,
    ImageGenerationOptions,
    ImageGenerationResponse,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelUsage,
    StreamChunk,
    ToolCall,
    ToolCallDelta,
    VideoGenerationOptions,
    VideoGenerationResponse,
)
from arelis.providers.shared.base import (
    ProviderCapabilities,
    ProviderConfigBase,
    ensure_tool_call_args_object,
    fetch_json,
    normalize_content_parts,
    parse_sse_json,
    to_base64_image_url,
)

__all__ = [
    "OnPremiseProvider",
    "OnPremiseConfig",
    "OnPremiseEndpoints",
    "create_onpremise_provider",
    "build_onpremise_chat_request",
    "parse_onpremise_chat_response",
    "parse_onpremise_stream_chunk",
]


# ---------------------------------------------------------------------------
# Config types
# ---------------------------------------------------------------------------


@dataclass
class OnPremiseEndpoints:
    """Custom endpoint paths for the on-premise provider."""

    chat: str | None = None
    audio_speech: str | None = None
    image_generation: str | None = None
    video_generation: str | None = None


@dataclass
class OnPremiseConfig(ProviderConfigBase):
    """Configuration for the on-premise provider."""

    base_url: str = ""
    api_key: str | None = None
    headers: dict[str, str] | None = None
    endpoints: OnPremiseEndpoints | None = None
    capabilities: ProviderCapabilities | None = None


# ---------------------------------------------------------------------------
# Endpoint resolution
# ---------------------------------------------------------------------------


def _is_absolute_url(value: str) -> bool:
    return bool(re.match(r"^https?://", value, re.IGNORECASE))


def _join_url(base: str, path: str) -> str:
    return f"{base.rstrip('/')}/{path.lstrip('/')}"


def _resolve_path(base_url: str, value: str | None) -> str | None:
    if not value:
        return None
    if _is_absolute_url(value):
        return value
    return _join_url(base_url, value)


@dataclass
class _DefaultPaths:
    chat: str
    audio_speech: str
    image_generation: str
    video_generation: str


def _default_paths(base_url: str) -> _DefaultPaths:
    has_v1 = bool(re.search(r"/v1/?$", base_url))
    return _DefaultPaths(
        chat="/chat/completions" if has_v1 else "/v1/chat/completions",
        audio_speech="/audio/speech" if has_v1 else "/v1/audio/speech",
        image_generation="/images/generations" if has_v1 else "/v1/images/generations",
        video_generation="/videos/generations" if has_v1 else "/v1/videos/generations",
    )


@dataclass
class _ResolvedEndpoints:
    chat: str
    audio_speech: str | None = None
    image_generation: str | None = None
    video_generation: str | None = None


def _resolve_endpoints(
    base_url: str,
    endpoints: OnPremiseEndpoints | None,
    capability_overrides: ProviderCapabilities | None,
) -> _ResolvedEndpoints:
    defaults = _default_paths(base_url)

    chat = _resolve_path(base_url, (endpoints.chat if endpoints else None) or defaults.chat)

    audio = _resolve_path(base_url, endpoints.audio_speech if endpoints else None) or (
        _resolve_path(base_url, defaults.audio_speech)
        if capability_overrides and capability_overrides.audio_generation
        else None
    )
    image = _resolve_path(base_url, endpoints.image_generation if endpoints else None) or (
        _resolve_path(base_url, defaults.image_generation)
        if capability_overrides and capability_overrides.image_generation
        else None
    )
    video = _resolve_path(base_url, endpoints.video_generation if endpoints else None) or (
        _resolve_path(base_url, defaults.video_generation)
        if capability_overrides and capability_overrides.video_generation
        else None
    )

    if not chat:
        raise ValueError("On-premise provider requires a chat completions endpoint.")

    return _ResolvedEndpoints(
        chat=chat,
        audio_speech=audio,
        image_generation=image,
        video_generation=video,
    )


# ---------------------------------------------------------------------------
# Media extraction helpers
# ---------------------------------------------------------------------------


def _decode_base64(b64: str) -> bytes:
    return base64.b64decode(b64)


def _resolve_mime_type(record: dict[str, object], fallback: str) -> str:
    for key in ("mime_type", "content_type", "mimeType", "contentType"):
        val = record.get(key)
        if isinstance(val, str) and val:
            return val
    return fallback


def _extract_media_data(
    response: dict[str, object],
) -> tuple[str | None, str | None, str | None]:
    """Extract media data from a JSON response.

    Returns ``(base64_data, url, mime_type)``.
    """
    b64_json = response.get("b64_json")
    if isinstance(b64_json, str):
        return b64_json, None, _resolve_mime_type(response, "")

    data = response.get("data")
    if isinstance(data, list) and data:
        item = data[0]
        if isinstance(item, dict):
            if isinstance(item.get("b64_json"), str):
                return str(item["b64_json"]), None, _resolve_mime_type(item, "")
            if isinstance(item.get("base64"), str):
                return str(item["base64"]), None, _resolve_mime_type(item, "")
            if isinstance(item.get("url"), str):
                return None, str(item["url"]), _resolve_mime_type(item, "")

    url_val = response.get("url")
    if isinstance(url_val, str):
        return None, url_val, _resolve_mime_type(response, "")

    return None, None, None


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------


def _map_finish_reason(reason: str | None) -> FinishReason:
    if reason == "length":
        return "length"
    if reason == "tool_calls":
        return "tool_use"
    if reason == "content_filter":
        return "content_filter"
    if reason == "error":
        return "error"
    return "stop"


def _map_message_content(message: ModelMessage) -> str | list[dict[str, object]]:
    if isinstance(message.content, str):
        return message.content
    parts = normalize_content_parts(message.content)
    result: list[dict[str, object]] = []
    for part in parts:
        if part.type == "text":
            result.append({"type": "text", "text": part.text})
        elif part.type == "image":
            result.append(
                {
                    "type": "image_url",
                    "image_url": {"url": to_base64_image_url(part.data, part.mime_type)},
                }
            )
    return result


def _scrub_provider_options(options: dict[str, object] | None) -> dict[str, object]:
    if not options:
        return {}
    reserved = {"model", "messages", "stream", "tools", "tool_choice"}
    return {k: v for k, v in options.items() if k not in reserved}


def build_onpremise_chat_request(
    request: ModelRequest,
    options: GenerateOptions | None = None,
) -> dict[str, object]:
    """Build an OpenAI-compatible chat completions request body."""
    messages: list[dict[str, object]] = []
    for msg in request.messages:
        mapped: dict[str, object] = {
            "role": msg.role,
            "content": _map_message_content(msg),
        }
        if msg.name:
            mapped["name"] = msg.name
        messages.append(mapped)

    tools: list[dict[str, object]] | None = None
    if request.tools:
        tools = [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters or {},
                },
            }
            for tool in request.tools
        ]

    provider_options = _scrub_provider_options(
        request.config.provider_options if request.config else None
    )

    body: dict[str, object] = {
        "model": request.model,
        "messages": messages,
    }

    max_tokens = (options.max_tokens if options else None) or (
        request.config.max_tokens if request.config else None
    )
    if max_tokens is not None:
        body["max_tokens"] = max_tokens
    if request.config:
        if request.config.temperature is not None:
            body["temperature"] = request.config.temperature
        if request.config.top_p is not None:
            body["top_p"] = request.config.top_p
        if request.config.stop is not None:
            body["stop"] = request.config.stop
        if request.config.frequency_penalty is not None:
            body["frequency_penalty"] = request.config.frequency_penalty
        if request.config.presence_penalty is not None:
            body["presence_penalty"] = request.config.presence_penalty
        if request.config.seed is not None:
            body["seed"] = request.config.seed

    if tools:
        body["tools"] = tools
        body["tool_choice"] = "auto"

    body.update(provider_options)
    return body


def parse_onpremise_chat_response(
    raw: dict[str, object],
    request: ModelRequest,
) -> ModelResponse:
    """Parse an OpenAI-compatible chat response into a ModelResponse."""
    choices = raw.get("choices") or []
    choice: dict[str, object] = choices[0] if isinstance(choices, list) and choices else {}
    message = choice.get("message") or {}

    tool_calls: list[ToolCall] = []
    if isinstance(message, dict):
        tc_list = message.get("tool_calls")
        if isinstance(tc_list, list):
            for tc in tc_list:
                if isinstance(tc, dict):
                    func = tc.get("function", {})
                    if isinstance(func, dict):
                        tool_calls.append(
                            ToolCall(
                                id=str(tc.get("id", "")),
                                name=str(func.get("name", "")),
                                arguments=ensure_tool_call_args_object(func.get("arguments", "{}")),
                            )
                        )

    content_val = message.get("content", "") if isinstance(message, dict) else ""
    usage_raw = raw.get("usage")
    input_tokens = 0
    output_tokens = 0
    total_tokens = 0
    if isinstance(usage_raw, dict):
        input_tokens = int(usage_raw.get("prompt_tokens", 0) or 0)
        output_tokens = int(usage_raw.get("completion_tokens", 0) or 0)
        total_tokens = int(usage_raw.get("total_tokens", 0) or 0)

    return ModelResponse(
        id=str(raw.get("id", f"onprem_{int(time.time() * 1000)}")),
        model=request.model,
        content=str(content_val or ""),
        tool_calls=tool_calls if tool_calls else None,
        finish_reason=_map_finish_reason(
            str(choice.get("finish_reason", "")) if isinstance(choice, dict) else None
        ),
        usage=ModelUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
        ),
        created_at=datetime.now(),
        provider_metadata={"raw": raw},
    )


def parse_onpremise_stream_chunk(raw: dict[str, object]) -> list[StreamChunk]:
    """Parse a single stream chunk from an OpenAI-compatible API."""
    chunks: list[StreamChunk] = []
    choices = raw.get("choices") or []
    choice: dict[str, object] = choices[0] if isinstance(choices, list) and choices else {}

    delta = choice.get("delta") if isinstance(choice, dict) else None
    if isinstance(delta, dict):
        content = delta.get("content")
        if content:
            chunks.append(StreamChunk(type="content", content=str(content)))

        tc_list = delta.get("tool_calls")
        if isinstance(tc_list, list):
            for tc in tc_list:
                if isinstance(tc, dict):
                    func = tc.get("function", {})
                    args = None
                    if isinstance(func, dict) and func.get("arguments"):
                        args = ensure_tool_call_args_object(func["arguments"])
                    chunks.append(
                        StreamChunk(
                            type="tool_call",
                            tool_call=ToolCallDelta(
                                index=int(tc.get("index", 0)),
                                id=str(tc["id"]) if tc.get("id") else None,
                                name=str(func.get("name", ""))
                                if isinstance(func, dict) and func.get("name")
                                else None,
                                arguments=args,
                            ),
                        )
                    )

    usage_raw = raw.get("usage")
    if isinstance(usage_raw, dict):
        chunks.append(
            StreamChunk(
                type="usage",
                usage=ModelUsage(
                    input_tokens=usage_raw.get("prompt_tokens"),
                    output_tokens=usage_raw.get("completion_tokens"),
                    total_tokens=usage_raw.get("total_tokens"),
                ),
            )
        )

    finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
    if finish_reason:
        chunks.append(
            StreamChunk(type="done", finish_reason=_map_finish_reason(str(finish_reason)))
        )

    return chunks


# ---------------------------------------------------------------------------
# OnPremiseProvider
# ---------------------------------------------------------------------------


class OnPremiseProvider(BaseModelProvider):
    """On-premise (OpenAI-compatible) model provider.

    Connects to any OpenAI-compatible API endpoint. Supports text
    generation, streaming, tool calls, and optionally image/audio/video
    generation via configurable endpoints.
    """

    def __init__(
        self,
        config: OnPremiseConfig,
        supported_models: list[str] | None = None,
    ) -> None:
        self._config = config
        self._supported_models = supported_models or []
        self._endpoints = _resolve_endpoints(config.base_url, config.endpoints, config.capabilities)

        base_capabilities = ProviderCapabilities(
            streaming=True,
            tool_calls=True,
            multimodal=False,
            image_generation=bool(self._endpoints.image_generation),
            audio_generation=bool(self._endpoints.audio_speech),
            video_generation=bool(self._endpoints.video_generation),
            image_to_text=False,
            image_to_audio=False,
            image_to_video=False,
            audio_to_text=False,
            audio_to_image=False,
            audio_to_video=False,
            video_to_text=False,
            video_to_image=False,
            video_to_audio=False,
        )

        if config.capabilities:
            # Merge overrides
            self._capabilities = ProviderCapabilities(
                streaming=config.capabilities.streaming
                if config.capabilities.streaming
                else base_capabilities.streaming,
                tool_calls=config.capabilities.tool_calls
                if config.capabilities.tool_calls
                else base_capabilities.tool_calls,
                multimodal=config.capabilities.multimodal
                if config.capabilities.multimodal
                else base_capabilities.multimodal,
                image_generation=config.capabilities.image_generation
                if config.capabilities.image_generation
                else base_capabilities.image_generation,
                audio_generation=config.capabilities.audio_generation
                if config.capabilities.audio_generation
                else base_capabilities.audio_generation,
                video_generation=config.capabilities.video_generation
                if config.capabilities.video_generation
                else base_capabilities.video_generation,
                image_to_text=config.capabilities.image_to_text,
                image_to_audio=config.capabilities.image_to_audio,
                image_to_video=config.capabilities.image_to_video,
                audio_to_text=config.capabilities.audio_to_text,
                audio_to_image=config.capabilities.audio_to_image,
                audio_to_video=config.capabilities.audio_to_video,
                video_to_text=config.capabilities.video_to_text,
                video_to_image=config.capabilities.video_to_image,
                video_to_audio=config.capabilities.video_to_audio,
            )
        else:
            self._capabilities = base_capabilities

    @property
    def id(self) -> str:
        return "onpremise"

    @property
    def name(self) -> str:
        return "On-Premise (OpenAI-Compatible)"

    @property
    def supported_models(self) -> list[str]:
        return self._supported_models

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._capabilities

    def _unsupported(self, capability: str) -> None:
        raise ProviderCapabilityNotSupportedError(self.id, capability)

    def _build_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            **(self._config.headers or {}),
        }
        if self._config.api_key and "Authorization" not in headers:
            headers["Authorization"] = f"Bearer {self._config.api_key}"
        return headers

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        self.validate_request(request)
        payload = build_onpremise_chat_request(request, options)

        raw = await fetch_json(
            self._endpoints.chat,
            method="POST",
            headers=self._build_headers(),
            body=json.dumps(payload),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )
        return parse_onpremise_chat_response(raw, request)  # type: ignore[arg-type]

    async def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        if not self._capabilities.streaming:
            self._unsupported("streaming")

        self.validate_request(request)
        payload = {**build_onpremise_chat_request(request, options), "stream": True}

        client, should_close = (
            (self._config.http_client, False)
            if self._config.http_client
            else (httpx.AsyncClient(), True)
        )
        try:
            async with client.stream(
                "POST",
                self._endpoints.chat,
                headers={**self._build_headers(), "Accept": "text/event-stream"},
                content=json.dumps(payload),
                timeout=self._config.timeout_ms / 1000.0 if self._config.timeout_ms else 30.0,
            ) as resp:
                if resp.status_code >= 400:
                    error_text = await resp.aread()
                    raise ValueError(
                        f"On-premise stream error {resp.status_code}: {error_text.decode()}"
                    )

                async for chunk_obj in parse_sse_json(resp.aiter_bytes()):
                    if isinstance(chunk_obj, dict):
                        mapped = parse_onpremise_stream_chunk(chunk_obj)
                        for item in mapped:
                            yield item
        finally:
            if should_close:
                await client.aclose()

    # -- Media fetch helpers ------------------------------------------------

    async def _fetch_with_timeout(
        self,
        url: str,
        method: str = "POST",
        headers: dict[str, str] | None = None,
        body: str | None = None,
    ) -> httpx.Response:
        client, should_close = (
            (self._config.http_client, False)
            if self._config.http_client
            else (httpx.AsyncClient(), True)
        )
        timeout = (self._config.timeout_ms or 30_000) / 1000.0
        try:
            response = await client.request(
                method, url, headers=headers or {}, content=body, timeout=timeout
            )
            return response
        finally:
            if should_close:
                await client.aclose()

    async def _fetch_media(
        self, url: str, body: str, fallback_mime: str
    ) -> tuple[bytes, str, str | None, object | None]:
        """Fetch media from an endpoint.

        Returns ``(data, mime_type, url_link, raw_json)``.
        """
        response = await self._fetch_with_timeout(
            url, method="POST", headers=self._build_headers(), body=body
        )

        if response.status_code >= 400:
            raise ValueError(f"On-premise media error {response.status_code}: {response.text}")

        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            json_data = response.json()
            b64, media_url, mime = _extract_media_data(json_data)
            mime_type = mime or fallback_mime

            if b64:
                return _decode_base64(b64), mime_type, None, json_data

            if media_url:
                fetched = await self._fetch_with_timeout(media_url, method="GET")
                if fetched.status_code >= 400:
                    raise ValueError(
                        f"On-premise media url error {fetched.status_code}: {fetched.text}"
                    )
                fetched_ct = fetched.headers.get("content-type", "")
                fetched_mime = (
                    fetched_ct.split(";")[0].strip() if fetched_ct else (mime_type or fallback_mime)
                )
                return fetched.content, fetched_mime, media_url, json_data

            raise ValueError(
                "On-premise media response did not include base64 data. "
                'Set providerOptions.response_format="b64_json" or configure '
                "the media endpoint to return binary."
            )

        # Binary response
        ct = content_type.split(";")[0].strip() if content_type else fallback_mime
        return response.content, ct, None, None

    # -- Image generation ---------------------------------------------------

    async def generate_image(
        self,
        prompt: str,
        options: ImageGenerationOptions | None = None,
    ) -> ImageGenerationResponse:
        if not self._capabilities.image_generation or not self._endpoints.image_generation:
            self._unsupported("imageGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for image generation")

        provider_options = dict((options.provider_options if options else None) or {})
        if "response_format" not in provider_options:
            provider_options["response_format"] = "b64_json"

        payload = {"model": model, "prompt": prompt, **provider_options}
        image_endpoint = self._endpoints.image_generation
        assert image_endpoint is not None
        data, mime_type, url, raw = await self._fetch_media(
            image_endpoint, json.dumps(payload), "image/png"
        )

        return ImageGenerationResponse(
            id=self.generate_response_id(),
            model=model,
            data=data,
            mime_type=mime_type,
            url=url,
            created_at=datetime.now(),
            provider_metadata={"raw": raw} if raw else None,
        )

    # -- Audio generation ---------------------------------------------------

    async def generate_audio(
        self,
        prompt: str,
        options: AudioGenerationOptions | None = None,
    ) -> AudioGenerationResponse:
        if not self._capabilities.audio_generation or not self._endpoints.audio_speech:
            self._unsupported("audioGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for audio generation")

        provider_options = dict((options.provider_options if options else None) or {})
        if "input" not in provider_options:
            provider_options["input"] = prompt

        payload = {"model": model, **provider_options}
        audio_endpoint = self._endpoints.audio_speech
        assert audio_endpoint is not None
        data, mime_type, url, raw = await self._fetch_media(
            audio_endpoint, json.dumps(payload), "audio/mpeg"
        )

        return AudioGenerationResponse(
            id=self.generate_response_id(),
            model=model,
            data=data,
            mime_type=mime_type,
            url=url,
            created_at=datetime.now(),
            provider_metadata={"raw": raw} if raw else None,
        )

    # -- Video generation ---------------------------------------------------

    async def generate_video(
        self,
        prompt: str,
        options: VideoGenerationOptions | None = None,
    ) -> VideoGenerationResponse:
        if not self._capabilities.video_generation or not self._endpoints.video_generation:
            self._unsupported("videoGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for video generation")

        provider_options = dict((options.provider_options if options else None) or {})
        if "response_format" not in provider_options:
            provider_options["response_format"] = "b64_json"

        payload = {"model": model, "prompt": prompt, **provider_options}
        video_endpoint = self._endpoints.video_generation
        assert video_endpoint is not None
        data, mime_type, url, raw = await self._fetch_media(
            video_endpoint, json.dumps(payload), "video/mp4"
        )

        return VideoGenerationResponse(
            id=self.generate_response_id(),
            model=model,
            data=data,
            mime_type=mime_type,
            url=url,
            created_at=datetime.now(),
            provider_metadata={"raw": raw} if raw else None,
        )


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------


def create_onpremise_provider(
    config: OnPremiseConfig,
    supported_models: list[str] | None = None,
) -> OnPremiseProvider:
    """Create an OnPremiseProvider with the given configuration."""
    return OnPremiseProvider(config, supported_models)
