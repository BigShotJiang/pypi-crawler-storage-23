"""Hugging Face provider adapter.

Ports the TypeScript SDK's `packages/providers-huggingface/src/provider.ts`,
`packages/providers-huggingface/src/mapping.ts`, and
`packages/providers-huggingface/src/inference-providers.ts`.

Requires the ``huggingface`` extra::

    pip install "ai-governance-sdk[huggingface]"
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from typing import Literal

import httpx

from arelis.models.provider import BaseModelProvider, ProviderCapabilityNotSupportedError
from arelis.models.types import (
    AudioFromImageResponse,
    AudioFromVideoResponse,
    AudioGenerationOptions,
    AudioGenerationResponse,
    AudioInput,
    AudioToImageOptions,
    AudioToTextOptions,
    AudioToVideoOptions,
    FinishReason,
    GenerateOptions,
    ImageFromAudioResponse,
    ImageFromVideoResponse,
    ImageGenerationOptions,
    ImageGenerationResponse,
    ImageInput,
    ImageToAudioOptions,
    ImageToTextOptions,
    ImageToVideoOptions,
    MediaGenerationOptions,
    MediaTransformOptions,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelUsage,
    StreamChunk,
    TextFromAudioResponse,
    TextFromImageResponse,
    TextFromVideoResponse,
    ToolCall,
    ToolCallDelta,
    VideoFromAudioResponse,
    VideoFromImageResponse,
    VideoGenerationOptions,
    VideoGenerationResponse,
    VideoInput,
    VideoToAudioOptions,
    VideoToImageOptions,
    VideoToTextOptions,
)
from arelis.providers.shared.base import (
    ProviderCapabilities,
    ProviderConfigBase,
    collect_message_text,
    ensure_tool_call_args_object,
    fetch_binary,
    fetch_json,
    normalize_base64_input,
    normalize_content_parts,
    parse_sse_json,
    to_base64_image_url,
)

__all__ = [
    "HuggingFaceProvider",
    "HuggingFaceConfig",
    "HuggingFaceApiType",
    "build_huggingface_request",
    "parse_huggingface_response",
    "parse_huggingface_stream_chunk",
]

HuggingFaceApiType = Literal["inference", "openai"]


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass
class HuggingFaceConfig(ProviderConfigBase):
    """Configuration for the Hugging Face provider."""

    token: str | None = None
    endpoint: str | None = None
    api_type: HuggingFaceApiType = "inference"
    inference_provider: str = "hf-inference"


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------


def _map_finish_reason(reason: str | None) -> FinishReason:
    if reason == "length":
        return "length"
    if reason == "tool_calls":
        return "tool_use"
    if reason == "content_filter":
        return "content_filter"
    if reason == "error":
        return "error"
    return "stop"


def _map_openai_message(message: ModelMessage) -> dict[str, object]:
    """Map a ModelMessage to an OpenAI-style message dict."""
    if isinstance(message.content, str):
        return {"role": message.role, "content": message.content}

    parts = normalize_content_parts(message.content)
    mapped: list[dict[str, object]] = []
    for part in parts:
        if part.type == "text":
            mapped.append({"type": "text", "text": part.text})
        elif part.type == "image":
            mapped.append(
                {
                    "type": "image_url",
                    "image_url": {"url": to_base64_image_url(part.data, part.mime_type)},
                }
            )
    return {"role": message.role, "content": mapped}


def build_huggingface_request(
    request: ModelRequest,
    api_type: HuggingFaceApiType,
    options: GenerateOptions | None = None,
) -> dict[str, object]:
    """Build a Hugging Face request body from a ModelRequest."""
    if api_type == "openai":
        tools: list[dict[str, object]] | None = None
        if request.tools:
            tools = [
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.parameters or {},
                    },
                }
                for tool in request.tools
            ]

        body: dict[str, object] = {
            "model": request.model,
            "messages": [_map_openai_message(msg) for msg in request.messages],
        }
        max_tokens = (options.max_tokens if options else None) or (
            request.config.max_tokens if request.config else None
        )
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if request.config:
            if request.config.temperature is not None:
                body["temperature"] = request.config.temperature
            if request.config.top_p is not None:
                body["top_p"] = request.config.top_p
            if request.config.stop is not None:
                body["stop"] = request.config.stop
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        return body

    # Inference API
    params: dict[str, object] = {}
    max_tokens = (options.max_tokens if options else None) or (
        request.config.max_tokens if request.config else None
    )
    if max_tokens is not None:
        params["max_new_tokens"] = max_tokens
    if request.config:
        if request.config.temperature is not None:
            params["temperature"] = request.config.temperature
        if request.config.top_p is not None:
            params["top_p"] = request.config.top_p
        if request.config.stop is not None:
            params["stop"] = request.config.stop

    return {
        "inputs": collect_message_text(request.messages),
        "parameters": params,
    }


def parse_huggingface_response(
    raw: object,
    request: ModelRequest,
    api_type: HuggingFaceApiType,
) -> ModelResponse:
    """Parse a Hugging Face response into a ModelResponse."""
    if api_type == "openai" and isinstance(raw, dict):
        choices = raw.get("choices") or []
        choice: dict[str, object] = choices[0] if isinstance(choices, list) and choices else {}
        message = choice.get("message") or {}

        tool_calls: list[ToolCall] = []
        if isinstance(message, dict):
            tc_list = message.get("tool_calls")
            if isinstance(tc_list, list):
                for tc in tc_list:
                    if isinstance(tc, dict):
                        func = tc.get("function", {})
                        if isinstance(func, dict):
                            tool_calls.append(
                                ToolCall(
                                    id=str(tc.get("id", "")),
                                    name=str(func.get("name", "")),
                                    arguments=ensure_tool_call_args_object(
                                        func.get("arguments", "{}")
                                    ),
                                )
                            )

        content_val = message.get("content", "") if isinstance(message, dict) else ""
        usage_raw = raw.get("usage")
        input_tokens = 0
        output_tokens = 0
        total_tokens = 0
        if isinstance(usage_raw, dict):
            input_tokens = int(usage_raw.get("prompt_tokens", 0) or 0)
            output_tokens = int(usage_raw.get("completion_tokens", 0) or 0)
            total_tokens = int(usage_raw.get("total_tokens", 0) or 0)

        return ModelResponse(
            id=str(raw.get("id", f"hf_{int(time.time() * 1000)}")),
            model=request.model,
            content=str(content_val or ""),
            tool_calls=tool_calls if tool_calls else None,
            finish_reason=_map_finish_reason(
                str(choice.get("finish_reason", "")) if isinstance(choice, dict) else None
            ),
            usage=ModelUsage(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=total_tokens,
            ),
            created_at=datetime.now(),
            provider_metadata={"raw": raw},
        )

    # Inference API response
    text = ""
    if isinstance(raw, list) and raw:
        first = raw[0]
        if isinstance(first, dict):
            text = str(first.get("generated_text", ""))

    return ModelResponse(
        id=f"hf_{int(time.time() * 1000)}",
        model=request.model,
        content=text,
        finish_reason="stop",
        usage=ModelUsage(input_tokens=0, output_tokens=0, total_tokens=0),
        created_at=datetime.now(),
        provider_metadata={"raw": raw},
    )


def parse_huggingface_stream_chunk(raw: dict[str, object]) -> list[StreamChunk]:
    """Parse a single HuggingFace OpenAI-format stream chunk."""
    chunks: list[StreamChunk] = []
    choices = raw.get("choices") or []
    choice: dict[str, object] = choices[0] if isinstance(choices, list) and choices else {}

    delta = choice.get("delta") if isinstance(choice, dict) else None
    if isinstance(delta, dict):
        content = delta.get("content")
        if content:
            chunks.append(StreamChunk(type="content", content=str(content)))

        tc_list = delta.get("tool_calls")
        if isinstance(tc_list, list):
            for tc in tc_list:
                if isinstance(tc, dict):
                    func = tc.get("function", {})
                    args = None
                    if isinstance(func, dict) and func.get("arguments"):
                        args = ensure_tool_call_args_object(func["arguments"])
                    chunks.append(
                        StreamChunk(
                            type="tool_call",
                            tool_call=ToolCallDelta(
                                index=int(tc.get("index", 0)),
                                id=str(tc["id"]) if tc.get("id") else None,
                                name=str(func.get("name", ""))
                                if isinstance(func, dict) and func.get("name")
                                else None,
                                arguments=args,
                            ),
                        )
                    )

    usage_raw = raw.get("usage")
    if isinstance(usage_raw, dict):
        chunks.append(
            StreamChunk(
                type="usage",
                usage=ModelUsage(
                    input_tokens=usage_raw.get("prompt_tokens"),
                    output_tokens=usage_raw.get("completion_tokens"),
                    total_tokens=usage_raw.get("total_tokens"),
                ),
            )
        )

    finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
    if finish_reason:
        chunks.append(
            StreamChunk(type="done", finish_reason=_map_finish_reason(str(finish_reason)))
        )

    return chunks


# ---------------------------------------------------------------------------
# Helper: parse inference text response
# ---------------------------------------------------------------------------


def _parse_inference_text_response(response: object) -> str:
    """Extract text from a Hugging Face inference response."""
    if isinstance(response, str):
        return response
    if isinstance(response, list) and response:
        first = response[0]
        if isinstance(first, str):
            return first
        if isinstance(first, dict):
            for key in ("text", "generated_text", "summary_text", "translation_text"):
                val = first.get(key)
                if isinstance(val, str):
                    return val
    if isinstance(response, dict):
        for key in ("text", "generated_text", "summary_text", "translation_text"):
            val = response.get(key)
            if isinstance(val, str):
                return val
    raise ValueError("Unable to parse Hugging Face inference text response")


# ---------------------------------------------------------------------------
# HuggingFaceProvider
# ---------------------------------------------------------------------------


class HuggingFaceProvider(BaseModelProvider):
    """Hugging Face model provider.

    Supports both the Inference API (text generation, image/audio/video
    generation) and OpenAI-compatible API (chat completions, streaming,
    tool calls).
    """

    def __init__(
        self,
        config: HuggingFaceConfig,
        supported_models: list[str] | None = None,
    ) -> None:
        self._config = config
        self._supported_models = supported_models or []
        self._api_type = config.api_type
        self._inference_provider = config.inference_provider

        self._capabilities = ProviderCapabilities(
            streaming=self._api_type == "openai",
            tool_calls=self._api_type == "openai",
            multimodal=self._api_type == "openai",
            image_generation=self._api_type == "inference",
            audio_generation=self._api_type == "inference",
            video_generation=self._api_type == "inference",
            image_to_text=False,
            image_to_audio=False,
            image_to_video=False,
            audio_to_text=self._api_type == "inference",
            audio_to_image=False,
            audio_to_video=False,
            video_to_text=self._api_type == "inference",
            video_to_image=False,
            video_to_audio=False,
        )

        # SDK client for inference providers other than hf-inference
        self._sdk_client: object | None = None
        if self._inference_provider != "hf-inference":
            self._sdk_client = self._create_inference_client()

    def _create_inference_client(self) -> object | None:
        """Create a huggingface InferenceClient if the library is available."""
        try:
            from huggingface_hub import InferenceClient

            kwargs: dict[str, object] = {}
            if self._config.token:
                kwargs["token"] = self._config.token
            if self._config.endpoint:
                kwargs["api_url"] = self._config.endpoint
            client: object = InferenceClient(**kwargs)
            return client
        except ImportError:
            return None

    @property
    def id(self) -> str:
        return "huggingface"

    @property
    def name(self) -> str:
        return "Hugging Face"

    @property
    def supported_models(self) -> list[str]:
        return self._supported_models

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._capabilities

    def _unsupported(self, capability: str) -> None:
        raise ProviderCapabilityNotSupportedError(self.id, capability)

    def _build_url(self, model_id: str) -> str:
        if self._api_type == "openai":
            base = self._config.endpoint or "https://router.huggingface.co/v1"
            return f"{base.rstrip('/')}/chat/completions"
        base = self._config.endpoint or "https://router.huggingface.co/hf-inference/models"
        return f"{base.rstrip('/')}/{model_id}"

    def _build_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._config.token:
            headers["Authorization"] = f"Bearer {self._config.token}"
        return headers

    def _build_inference_parameters(
        self, options: MediaGenerationOptions | MediaTransformOptions | None
    ) -> dict[str, object] | None:
        prompt = getattr(options, "prompt", None) if options else None
        provider_options = (options.provider_options if options else None) or {}

        # Filter out payloadFormat if present
        rest = {k: v for k, v in provider_options.items() if k != "payloadFormat"}

        if prompt and "prompt" not in rest:
            rest["prompt"] = prompt

        if rest:
            return rest
        if prompt:
            return {"prompt": prompt}
        return None

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        self.validate_request(request)
        payload = build_huggingface_request(request, self._api_type, options)
        raw = await fetch_json(
            self._build_url(request.model),
            method="POST",
            headers=self._build_headers(),
            body=json.dumps(payload),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )
        return parse_huggingface_response(raw, request, self._api_type)

    async def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        self.validate_request(request)

        if self._api_type != "openai":
            response = await self.generate(request, options)
            if isinstance(response.content, str):
                yield StreamChunk(type="content", content=response.content)
            yield StreamChunk(type="done", finish_reason=response.finish_reason)
            return

        payload = {
            **build_huggingface_request(request, "openai", options),
            "stream": True,
        }

        client, should_close = (
            (self._config.http_client, False)
            if self._config.http_client
            else (httpx.AsyncClient(), True)
        )
        try:
            async with client.stream(
                "POST",
                self._build_url(request.model),
                headers={**self._build_headers(), "Accept": "text/event-stream"},
                content=json.dumps(payload),
                timeout=self._config.timeout_ms / 1000.0 if self._config.timeout_ms else 30.0,
            ) as resp:
                if resp.status_code >= 400:
                    error_text = await resp.aread()
                    raise ValueError(
                        f"Hugging Face stream error {resp.status_code}: {error_text.decode()}"
                    )

                async for chunk_obj in parse_sse_json(resp.aiter_bytes()):
                    if isinstance(chunk_obj, dict):
                        mapped = parse_huggingface_stream_chunk(chunk_obj)
                        for item in mapped:
                            yield item
        finally:
            if should_close:
                await client.aclose()

    # -- Image generation ---------------------------------------------------

    async def generate_image(
        self,
        prompt: str,
        options: ImageGenerationOptions | None = None,
    ) -> ImageGenerationResponse:
        if not self._capabilities.image_generation:
            self._unsupported("imageGeneration")
        if self._api_type != "inference":
            self._unsupported("imageGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for image generation")

        parameters = self._build_inference_parameters(options)

        if self._sdk_client is not None:
            data, mime_type = await self._sdk_text_to_image(model, prompt, parameters)
        else:
            payload: dict[str, object] = {"inputs": prompt}
            if parameters:
                payload["parameters"] = parameters
            raw_data, mime_type = await fetch_binary(
                self._build_url(model),
                method="POST",
                headers=self._build_headers(),
                body=json.dumps(payload),
                http_client=self._config.http_client,
                timeout_ms=self._config.timeout_ms,
            )
            data = raw_data

        return ImageGenerationResponse(
            id=self.generate_response_id(),
            model=model,
            data=data,
            mime_type=mime_type,
            created_at=datetime.now(),
            provider_metadata={
                "apiType": self._api_type,
                "inferenceProvider": self._inference_provider,
            },
        )

    async def _sdk_text_to_image(
        self,
        model: str,
        prompt: str,
        parameters: dict[str, object] | None,
    ) -> tuple[bytes, str]:
        """Use the huggingface_hub SDK for text-to-image."""
        try:
            from huggingface_hub import InferenceClient  # noqa: F811

            _ = InferenceClient  # ensure import is used for availability check
        except ImportError as exc:
            raise ImportError(
                "huggingface-hub is required for the Hugging Face provider. "
                'Install it with: pip install "ai-governance-sdk[huggingface]"'
            ) from exc

        import asyncio

        client = self._sdk_client
        loop = asyncio.get_event_loop()

        def _call() -> object:
            return client.text_to_image(  # type: ignore[union-attr]
                prompt=prompt,
                model=model,
                **(parameters or {}),
            )

        result = await loop.run_in_executor(None, _call)
        # Result is a PIL Image -- convert to bytes
        import io

        buf = io.BytesIO()
        result.save(buf, format="PNG")  # type: ignore[attr-defined]
        return buf.getvalue(), "image/png"

    # -- Audio generation ---------------------------------------------------

    async def generate_audio(
        self,
        prompt: str,
        options: AudioGenerationOptions | None = None,
    ) -> AudioGenerationResponse:
        if not self._capabilities.audio_generation:
            self._unsupported("audioGeneration")
        if self._api_type != "inference":
            self._unsupported("audioGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for audio generation")

        if self._sdk_client is not None:
            data, mime_type = await self._sdk_text_to_audio(model, prompt)
        else:
            parameters = self._build_inference_parameters(options)
            payload: dict[str, object] = {"inputs": prompt}
            if parameters:
                payload["parameters"] = parameters
            raw_data, mime_type = await fetch_binary(
                self._build_url(model),
                method="POST",
                headers=self._build_headers(),
                body=json.dumps(payload),
                http_client=self._config.http_client,
                timeout_ms=self._config.timeout_ms,
            )
            data = raw_data

        return AudioGenerationResponse(
            id=self.generate_response_id(),
            model=model,
            data=data,
            mime_type=mime_type,
            created_at=datetime.now(),
            provider_metadata={
                "apiType": self._api_type,
                "inferenceProvider": self._inference_provider,
            },
        )

    async def _sdk_text_to_audio(self, model: str, prompt: str) -> tuple[bytes, str]:
        """Use the huggingface_hub SDK for text-to-speech."""
        try:
            from huggingface_hub import InferenceClient  # noqa: F811

            _ = InferenceClient  # ensure import is used for availability check
        except ImportError as exc:
            raise ImportError(
                "huggingface-hub is required for the Hugging Face provider. "
                'Install it with: pip install "ai-governance-sdk[huggingface]"'
            ) from exc

        import asyncio

        client = self._sdk_client
        loop = asyncio.get_event_loop()

        def _call() -> bytes:
            raw_result: bytes = client.text_to_speech(  # type: ignore[union-attr]
                text=prompt,
                model=model,
            )
            return raw_result

        result = await loop.run_in_executor(None, _call)
        if isinstance(result, bytes):
            return result, "audio/wav"
        # May be a file-like or Blob
        return bytes(result), "audio/wav"

    # -- Video generation ---------------------------------------------------

    async def generate_video(
        self,
        prompt: str,
        options: VideoGenerationOptions | None = None,
    ) -> VideoGenerationResponse:
        if not self._capabilities.video_generation:
            self._unsupported("videoGeneration")
        if self._api_type != "inference":
            self._unsupported("videoGeneration")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for video generation")

        parameters = self._build_inference_parameters(options)
        payload: dict[str, object] = {"inputs": prompt}
        if parameters:
            payload["parameters"] = parameters

        raw_data, mime_type = await fetch_binary(
            self._build_url(model),
            method="POST",
            headers=self._build_headers(),
            body=json.dumps(payload),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )

        return VideoGenerationResponse(
            id=self.generate_response_id(),
            model=model,
            data=raw_data,
            mime_type=mime_type,
            created_at=datetime.now(),
            provider_metadata={
                "apiType": self._api_type,
                "inferenceProvider": self._inference_provider,
            },
        )

    # -- Audio-to-text ------------------------------------------------------

    async def audio_to_text(
        self,
        media_input: AudioInput,
        options: AudioToTextOptions | None = None,
    ) -> TextFromAudioResponse:
        if not self._capabilities.audio_to_text:
            self._unsupported("audioToText")
        if self._api_type != "inference":
            self._unsupported("audioToText")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for audio to text")

        payload_data = normalize_base64_input(media_input)
        body: dict[str, object] = {"inputs": payload_data.base64}
        parameters = self._build_inference_parameters(options)
        if parameters:
            body["parameters"] = parameters

        raw = await fetch_json(
            self._build_url(model),
            method="POST",
            headers=self._build_headers(),
            body=json.dumps(body),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )
        text = _parse_inference_text_response(raw)
        return TextFromAudioResponse(
            id=self.generate_response_id(),
            model=model,
            text=text,
            created_at=datetime.now(),
            provider_metadata={
                "apiType": self._api_type,
                "inferenceProvider": self._inference_provider,
            },
        )

    # -- Video-to-text ------------------------------------------------------

    async def video_to_text(
        self,
        media_input: VideoInput,
        options: VideoToTextOptions | None = None,
    ) -> TextFromVideoResponse:
        if not self._capabilities.video_to_text:
            self._unsupported("videoToText")
        if self._api_type != "inference":
            self._unsupported("videoToText")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for video to text")

        payload_data = normalize_base64_input(media_input)
        body: dict[str, object] = {"inputs": payload_data.base64}
        parameters = self._build_inference_parameters(options)
        if parameters:
            body["parameters"] = parameters

        raw = await fetch_json(
            self._build_url(model),
            method="POST",
            headers=self._build_headers(),
            body=json.dumps(body),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )
        text = _parse_inference_text_response(raw)
        return TextFromVideoResponse(
            id=self.generate_response_id(),
            model=model,
            text=text,
            created_at=datetime.now(),
            provider_metadata={
                "apiType": self._api_type,
                "inferenceProvider": self._inference_provider,
            },
        )

    # -- Unsupported methods ------------------------------------------------

    async def image_to_text(
        self, _input: ImageInput, _options: ImageToTextOptions | None = None
    ) -> TextFromImageResponse:
        self._unsupported("imageToText")
        raise AssertionError("unreachable")

    async def image_to_audio(
        self, _input: ImageInput, _options: ImageToAudioOptions | None = None
    ) -> AudioFromImageResponse:
        self._unsupported("imageToAudio")
        raise AssertionError("unreachable")

    async def image_to_video(
        self, _input: ImageInput, _options: ImageToVideoOptions | None = None
    ) -> VideoFromImageResponse:
        self._unsupported("imageToVideo")
        raise AssertionError("unreachable")

    async def audio_to_image(
        self, _input: AudioInput, _options: AudioToImageOptions | None = None
    ) -> ImageFromAudioResponse:
        self._unsupported("audioToImage")
        raise AssertionError("unreachable")

    async def audio_to_video(
        self, _input: AudioInput, _options: AudioToVideoOptions | None = None
    ) -> VideoFromAudioResponse:
        self._unsupported("audioToVideo")
        raise AssertionError("unreachable")

    async def video_to_image(
        self, _input: VideoInput, _options: VideoToImageOptions | None = None
    ) -> ImageFromVideoResponse:
        self._unsupported("videoToImage")
        raise AssertionError("unreachable")

    async def video_to_audio(
        self, _input: VideoInput, _options: VideoToAudioOptions | None = None
    ) -> AudioFromVideoResponse:
        self._unsupported("videoToAudio")
        raise AssertionError("unreachable")
