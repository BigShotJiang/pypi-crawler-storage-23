"""Azure OpenAI provider package."""

from __future__ import annotations

from arelis.providers.azure_openai.provider import (
    AzureOpenAIADTokenAuth,
    AzureOpenAIADTokenProviderAuth,
    AzureOpenAIApiKeyAuth,
    AzureOpenAIAuth,
    AzureOpenAIConfig,
    AzureOpenAIProvider,
    build_azure_chat_request,
    parse_azure_chat_response,
    parse_azure_stream_chunk,
)

__all__ = [
    "AzureOpenAIProvider",
    "AzureOpenAIConfig",
    "AzureOpenAIAuth",
    "AzureOpenAIApiKeyAuth",
    "AzureOpenAIADTokenAuth",
    "AzureOpenAIADTokenProviderAuth",
    "build_azure_chat_request",
    "parse_azure_chat_response",
    "parse_azure_stream_chunk",
]
