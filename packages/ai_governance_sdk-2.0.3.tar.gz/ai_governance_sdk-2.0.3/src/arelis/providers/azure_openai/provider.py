"""Azure OpenAI provider adapter.

Ports the TypeScript SDK's `packages/providers-azure-openai/src/provider.ts`
and `packages/providers-azure-openai/src/mapping.ts`.

Requires the ``azure-openai`` extra::

    pip install "ai-governance-sdk[azure-openai]"
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime

import httpx

from arelis.models.provider import BaseModelProvider, ProviderCapabilityNotSupportedError
from arelis.models.types import (
    AudioFromImageResponse,
    AudioFromVideoResponse,
    AudioGenerationResponse,
    AudioInput,
    AudioToImageOptions,
    AudioToTextOptions,
    AudioToVideoOptions,
    FinishReason,
    GenerateOptions,
    ImageContentPart,
    ImageFromAudioResponse,
    ImageFromVideoResponse,
    ImageGenerationResponse,
    ImageInput,
    ImageToAudioOptions,
    ImageToTextOptions,
    ImageToVideoOptions,
    ModelConfig,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelUsage,
    StreamChunk,
    TextContentPart,
    TextFromAudioResponse,
    TextFromImageResponse,
    TextFromVideoResponse,
    ToolCall,
    ToolCallDelta,
    VideoFromAudioResponse,
    VideoFromImageResponse,
    VideoGenerationResponse,
    VideoInput,
    VideoToAudioOptions,
    VideoToImageOptions,
    VideoToTextOptions,
)
from arelis.providers.shared.base import (
    ProviderCapabilities,
    ProviderConfigBase,
    ensure_tool_call_args_object,
    extract_text_from_content,
    fetch_json,
    normalize_base64_input,
    normalize_content_parts,
    parse_sse_json,
    to_base64_image_url,
)

__all__ = [
    "AzureOpenAIProvider",
    "AzureOpenAIConfig",
    "AzureOpenAIAuth",
    "AzureOpenAIApiKeyAuth",
    "AzureOpenAIADTokenAuth",
    "AzureOpenAIADTokenProviderAuth",
    "build_azure_chat_request",
    "parse_azure_chat_response",
    "parse_azure_stream_chunk",
]


# ---------------------------------------------------------------------------
# Auth config
# ---------------------------------------------------------------------------


@dataclass
class AzureOpenAIApiKeyAuth:
    """API key-based authentication."""

    api_key: str


@dataclass
class AzureOpenAIADTokenAuth:
    """Static Azure AD token authentication."""

    azure_ad_token: str


@dataclass
class AzureOpenAIADTokenProviderAuth:
    """Dynamic Azure AD token authentication via callback."""

    get_azure_ad_token: object  # Callable[[], Awaitable[str]]


AzureOpenAIAuth = AzureOpenAIApiKeyAuth | AzureOpenAIADTokenAuth | AzureOpenAIADTokenProviderAuth


@dataclass
class AzureOpenAIConfig(ProviderConfigBase):
    """Configuration for the Azure OpenAI provider."""

    endpoint: str = ""
    api_version: str | None = None
    auth: AzureOpenAIAuth | None = None


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------


def _map_finish_reason(reason: str | None) -> FinishReason:
    """Map an Azure/OpenAI finish reason to FinishReason."""
    if reason == "length":
        return "length"
    if reason == "tool_calls":
        return "tool_use"
    if reason == "content_filter":
        return "content_filter"
    if reason == "error":
        return "error"
    return "stop"


def _map_message_content(
    message: ModelMessage,
) -> str | list[dict[str, object]]:
    """Map a ModelMessage's content to Azure chat format."""
    if isinstance(message.content, str):
        return message.content

    parts = normalize_content_parts(message.content)
    result: list[dict[str, object]] = []
    for part in parts:
        if part.type == "text":
            result.append({"type": "text", "text": part.text})
        elif part.type == "image":
            result.append(
                {
                    "type": "image_url",
                    "image_url": {"url": to_base64_image_url(part.data, part.mime_type)},
                }
            )
    return result


def build_azure_chat_request(
    request: ModelRequest,
    options: GenerateOptions | None = None,
) -> dict[str, object]:
    """Build an Azure OpenAI chat completions request body."""
    messages: list[dict[str, object]] = [
        {"role": msg.role, "content": _map_message_content(msg)} for msg in request.messages
    ]

    tools: list[dict[str, object]] | None = None
    if request.tools:
        tools = [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters or {},
                },
            }
            for tool in request.tools
        ]

    body: dict[str, object] = {"messages": messages}
    max_tokens = (options.max_tokens if options else None) or (
        request.config.max_tokens if request.config else None
    )
    if max_tokens is not None:
        body["max_completion_tokens"] = max_tokens
    if request.config:
        if request.config.temperature is not None:
            body["temperature"] = request.config.temperature
        if request.config.top_p is not None:
            body["top_p"] = request.config.top_p
        if request.config.stop is not None:
            body["stop"] = request.config.stop
    if tools:
        body["tools"] = tools
        body["tool_choice"] = "auto"

    return body


def parse_azure_chat_response(
    raw: dict[str, object],
    request: ModelRequest,
) -> ModelResponse:
    """Parse an Azure OpenAI chat response into a ModelResponse."""
    choices = raw.get("choices") or []
    choice: dict[str, object] = choices[0] if isinstance(choices, list) and choices else {}
    message = choice.get("message") or {}

    tool_calls: list[ToolCall] = []
    if isinstance(message, dict):
        raw_tool_calls = message.get("tool_calls")
        if isinstance(raw_tool_calls, list):
            for tc in raw_tool_calls:
                if isinstance(tc, dict):
                    func = tc.get("function", {})
                    if isinstance(func, dict):
                        tool_calls.append(
                            ToolCall(
                                id=str(tc.get("id", "")),
                                name=str(func.get("name", "")),
                                arguments=ensure_tool_call_args_object(func.get("arguments", "{}")),
                            )
                        )

    content_val = message.get("content", "") if isinstance(message, dict) else ""
    usage_raw = raw.get("usage")
    input_tokens = 0
    output_tokens = 0
    total_tokens = 0
    if isinstance(usage_raw, dict):
        input_tokens = int(usage_raw.get("prompt_tokens", 0) or 0)
        output_tokens = int(usage_raw.get("completion_tokens", 0) or 0)
        total_tokens = int(usage_raw.get("total_tokens", 0) or 0)

    return ModelResponse(
        id=str(raw.get("id", f"azure_{int(time.time() * 1000)}")),
        model=request.model,
        content=str(content_val or ""),
        tool_calls=tool_calls if tool_calls else None,
        finish_reason=_map_finish_reason(
            str(choice.get("finish_reason", "")) if isinstance(choice, dict) else None
        ),
        usage=ModelUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
        ),
        created_at=datetime.now(),
        provider_metadata={"raw": raw},
    )


def parse_azure_stream_chunk(raw: dict[str, object]) -> list[StreamChunk]:
    """Parse a single Azure OpenAI stream chunk into StreamChunks."""
    chunks: list[StreamChunk] = []
    choices = raw.get("choices") or []
    choice: dict[str, object] = choices[0] if isinstance(choices, list) and choices else {}

    delta = choice.get("delta") if isinstance(choice, dict) else None
    if isinstance(delta, dict):
        content = delta.get("content")
        if content:
            chunks.append(StreamChunk(type="content", content=str(content)))

        tc_list = delta.get("tool_calls")
        if isinstance(tc_list, list):
            for tc in tc_list:
                if isinstance(tc, dict):
                    func = tc.get("function", {})
                    args = None
                    if isinstance(func, dict) and func.get("arguments"):
                        args = ensure_tool_call_args_object(func["arguments"])
                    chunks.append(
                        StreamChunk(
                            type="tool_call",
                            tool_call=ToolCallDelta(
                                index=int(tc.get("index", 0)),
                                id=str(tc["id"]) if tc.get("id") else None,
                                name=str(func.get("name", ""))
                                if isinstance(func, dict) and func.get("name")
                                else None,
                                arguments=args,
                            ),
                        )
                    )

    usage_raw = raw.get("usage")
    if isinstance(usage_raw, dict):
        chunks.append(
            StreamChunk(
                type="usage",
                usage=ModelUsage(
                    input_tokens=usage_raw.get("prompt_tokens"),
                    output_tokens=usage_raw.get("completion_tokens"),
                    total_tokens=usage_raw.get("total_tokens"),
                ),
            )
        )

    finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
    if finish_reason:
        chunks.append(
            StreamChunk(type="done", finish_reason=_map_finish_reason(str(finish_reason)))
        )

    return chunks


# ---------------------------------------------------------------------------
# AzureOpenAIProvider
# ---------------------------------------------------------------------------


class AzureOpenAIProvider(BaseModelProvider):
    """Azure OpenAI model provider.

    Supports text generation, streaming, multimodal input, and tool calls
    via Azure-hosted OpenAI models.
    """

    def __init__(
        self,
        config: AzureOpenAIConfig,
        supported_models: list[str] | None = None,
    ) -> None:
        self._config = config
        self._supported_models = supported_models or []
        self._capabilities = ProviderCapabilities(
            streaming=True,
            tool_calls=True,
            multimodal=True,
            image_generation=False,
            audio_generation=False,
            video_generation=False,
            image_to_text=True,
            image_to_audio=False,
            image_to_video=False,
            audio_to_text=False,
            audio_to_image=False,
            audio_to_video=False,
            video_to_text=False,
            video_to_image=False,
            video_to_audio=False,
        )

    @property
    def id(self) -> str:
        return "azure-openai"

    @property
    def name(self) -> str:
        return "Azure OpenAI"

    @property
    def supported_models(self) -> list[str]:
        return self._supported_models

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._capabilities

    def _unsupported(self, capability: str) -> None:
        raise ProviderCapabilityNotSupportedError(self.id, capability)

    async def _resolve_auth_header(self) -> dict[str, str]:
        if self._config.auth is None:
            return {}
        if isinstance(self._config.auth, AzureOpenAIApiKeyAuth):
            return {"api-key": self._config.auth.api_key}
        if isinstance(self._config.auth, AzureOpenAIADTokenAuth):
            return {"Authorization": f"Bearer {self._config.auth.azure_ad_token}"}
        get_fn = self._config.auth.get_azure_ad_token
        if asyncio.iscoroutinefunction(get_fn):
            token = await get_fn()
        else:
            token = get_fn()  # type: ignore[operator]
        return {"Authorization": f"Bearer {token}"}

    def _build_url(self, model_id: str) -> str:
        api_version = self._config.api_version or "2024-02-15-preview"
        return (
            f"{self._config.endpoint}/openai/deployments/{model_id}"
            f"/chat/completions?api-version={api_version}"
        )

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        self.validate_request(request)
        payload = build_azure_chat_request(request, options)
        auth_headers = await self._resolve_auth_header()

        raw = await fetch_json(
            self._build_url(request.model),
            method="POST",
            headers={
                **auth_headers,
                "Content-Type": "application/json",
            },
            body=json.dumps(payload),
            http_client=self._config.http_client,
            timeout_ms=self._config.timeout_ms,
        )
        return parse_azure_chat_response(raw, request)  # type: ignore[arg-type]

    async def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        self.validate_request(request)
        payload = {**build_azure_chat_request(request, options), "stream": True}
        auth_headers = await self._resolve_auth_header()

        client, should_close = (
            (self._config.http_client, False)
            if self._config.http_client
            else (httpx.AsyncClient(), True)
        )
        try:
            async with client.stream(
                "POST",
                self._build_url(request.model),
                headers={
                    **auth_headers,
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                },
                content=json.dumps(payload),
                timeout=self._config.timeout_ms / 1000.0 if self._config.timeout_ms else 30.0,
            ) as resp:
                if resp.status_code >= 400:
                    error_text = await resp.aread()
                    raise ValueError(
                        f"Azure OpenAI stream error {resp.status_code}: {error_text.decode()}"
                    )

                async for chunk_obj in parse_sse_json(resp.aiter_bytes()):
                    if isinstance(chunk_obj, dict):
                        mapped = parse_azure_stream_chunk(chunk_obj)
                        for item in mapped:
                            yield item
        finally:
            if should_close:
                await client.aclose()

    # -- Image-to-text ------------------------------------------------------

    async def image_to_text(
        self,
        media_input: ImageInput,
        options: ImageToTextOptions | None = None,
    ) -> TextFromImageResponse:
        if not self._capabilities.image_to_text:
            self._unsupported("imageToText")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for imageToText")

        payload = normalize_base64_input(media_input)
        prompt_text = (options.prompt if options else None) or "Describe this image."

        config: ModelConfig | None = None
        if options and options.config:
            config = options.config

        img_request = ModelRequest(
            model=model,
            messages=[
                ModelMessage(
                    role="user",
                    content=[
                        TextContentPart(text=prompt_text),
                        ImageContentPart(data=payload.base64, mime_type=payload.mime_type),
                    ],
                ),
            ],
            config=config,
        )
        response = await self.generate(img_request)
        return TextFromImageResponse(
            id=response.id,
            model=response.model,
            text=extract_text_from_content(response.content),
            created_at=response.created_at,
            provider_metadata=response.provider_metadata,
        )

    # -- Unsupported methods ------------------------------------------------

    async def generate_image(
        self, _prompt: str, _options: object | None = None
    ) -> ImageGenerationResponse:
        self._unsupported("imageGeneration")
        raise AssertionError("unreachable")

    async def generate_audio(
        self, _prompt: str, _options: object | None = None
    ) -> AudioGenerationResponse:
        self._unsupported("audioGeneration")
        raise AssertionError("unreachable")

    async def generate_video(
        self, _prompt: str, _options: object | None = None
    ) -> VideoGenerationResponse:
        self._unsupported("videoGeneration")
        raise AssertionError("unreachable")

    async def image_to_audio(
        self, _input: ImageInput, _options: ImageToAudioOptions | None = None
    ) -> AudioFromImageResponse:
        self._unsupported("imageToAudio")
        raise AssertionError("unreachable")

    async def image_to_video(
        self, _input: ImageInput, _options: ImageToVideoOptions | None = None
    ) -> VideoFromImageResponse:
        self._unsupported("imageToVideo")
        raise AssertionError("unreachable")

    async def audio_to_text(
        self, _input: AudioInput, _options: AudioToTextOptions | None = None
    ) -> TextFromAudioResponse:
        self._unsupported("audioToText")
        raise AssertionError("unreachable")

    async def audio_to_image(
        self, _input: AudioInput, _options: AudioToImageOptions | None = None
    ) -> ImageFromAudioResponse:
        self._unsupported("audioToImage")
        raise AssertionError("unreachable")

    async def audio_to_video(
        self, _input: AudioInput, _options: AudioToVideoOptions | None = None
    ) -> VideoFromAudioResponse:
        self._unsupported("audioToVideo")
        raise AssertionError("unreachable")

    async def video_to_text(
        self, _input: VideoInput, _options: VideoToTextOptions | None = None
    ) -> TextFromVideoResponse:
        self._unsupported("videoToText")
        raise AssertionError("unreachable")

    async def video_to_image(
        self, _input: VideoInput, _options: VideoToImageOptions | None = None
    ) -> ImageFromVideoResponse:
        self._unsupported("videoToImage")
        raise AssertionError("unreachable")

    async def video_to_audio(
        self, _input: VideoInput, _options: VideoToAudioOptions | None = None
    ) -> AudioFromVideoResponse:
        self._unsupported("videoToAudio")
        raise AssertionError("unreachable")
