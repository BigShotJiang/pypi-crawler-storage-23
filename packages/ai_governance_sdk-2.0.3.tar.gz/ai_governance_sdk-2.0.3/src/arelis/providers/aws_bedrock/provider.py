"""AWS Bedrock provider adapter.

Ports the TypeScript SDK's `packages/providers-aws-bedrock/src/provider.ts`
and `packages/providers-aws-bedrock/src/mapping.ts`.

Requires the ``aws-bedrock`` extra::

    pip install "ai-governance-sdk[aws-bedrock]"
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from typing import Literal

from arelis.models.provider import BaseModelProvider, ProviderCapabilityNotSupportedError
from arelis.models.types import (
    AudioFromImageResponse,
    AudioFromVideoResponse,
    AudioGenerationResponse,
    AudioInput,
    AudioToImageOptions,
    AudioToTextOptions,
    AudioToVideoOptions,
    FinishReason,
    GenerateOptions,
    ImageContentPart,
    ImageFromAudioResponse,
    ImageFromVideoResponse,
    ImageGenerationResponse,
    ImageInput,
    ImageToAudioOptions,
    ImageToTextOptions,
    ImageToVideoOptions,
    ModelConfig,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelUsage,
    StreamChunk,
    TextContentPart,
    TextFromAudioResponse,
    TextFromImageResponse,
    TextFromVideoResponse,
    ToolCall,
    ToolCallDelta,
    VideoFromAudioResponse,
    VideoFromImageResponse,
    VideoGenerationResponse,
    VideoInput,
    VideoToAudioOptions,
    VideoToImageOptions,
    VideoToTextOptions,
)
from arelis.providers.shared.base import (
    ProviderCapabilities,
    ProviderConfigBase,
    ensure_tool_call_args_object,
    extract_text_from_content,
    normalize_base64_input,
    normalize_content_parts,
    split_system_messages,
    to_provider_tool_schema,
)

__all__ = [
    "BedrockProvider",
    "BedrockProviderConfig",
    "build_bedrock_request",
    "parse_bedrock_response",
    "parse_bedrock_stream_event",
]


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass
class BedrockProviderConfig(ProviderConfigBase):
    """Configuration for the AWS Bedrock provider."""

    region: str = ""
    credentials: object | None = None  # AWS credential provider
    client: object | None = None  # Pre-configured BedrockRuntimeClient


# ---------------------------------------------------------------------------
# Bedrock Anthropic request/response types (dicts for simplicity)
# ---------------------------------------------------------------------------


def _map_finish_reason(reason: str | None) -> FinishReason:
    """Map a Bedrock finish reason string to FinishReason."""
    value = (reason or "").lower()
    if value in ("max_tokens", "length"):
        return "length"
    if value in ("tool_use", "tool_calls"):
        return "tool_use"
    if value == "content_filter":
        return "content_filter"
    if value == "error":
        return "error"
    return "stop"


_ROLE_MAP: dict[str, Literal["user", "assistant"]] = {
    "user": "user",
    "assistant": "assistant",
    "tool": "user",
}


def build_bedrock_request(
    request: ModelRequest,
    options: GenerateOptions | None = None,
) -> dict[str, object]:
    """Build a Bedrock Anthropic request body from a ModelRequest."""
    split = split_system_messages(request.messages)

    messages: list[dict[str, object]] = []
    for msg in split.rest:
        parts = normalize_content_parts(msg.content)
        mapped_parts: list[dict[str, object]] = []
        for part in parts:
            if part.type == "text":
                mapped_parts.append({"type": "text", "text": part.text})
            elif part.type == "image":
                mapped_parts.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": part.mime_type,
                            "data": part.data,
                        },
                    }
                )
        messages.append(
            {
                "role": _ROLE_MAP.get(msg.role, "user"),
                "content": mapped_parts,
            }
        )

    max_tokens = (options.max_tokens if options else None) or (
        request.config.max_tokens if request.config else None
    )

    body: dict[str, object] = {
        "anthropic_version": "bedrock-2023-05-31",
        "messages": messages,
    }
    if split.system is not None:
        body["system"] = split.system
    if max_tokens is not None:
        body["max_tokens"] = max_tokens
    if request.config:
        if request.config.temperature is not None:
            body["temperature"] = request.config.temperature
        if request.config.top_p is not None:
            body["top_p"] = request.config.top_p
        if request.config.stop is not None:
            body["stop_sequences"] = request.config.stop

    if request.tools:
        body["tools"] = [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": to_provider_tool_schema(tool.parameters),
            }
            for tool in request.tools
        ]

    return body


def parse_bedrock_response(
    raw: dict[str, object],
    request: ModelRequest,
) -> ModelResponse:
    """Parse a Bedrock Anthropic response into a ModelResponse."""
    content_parts = raw.get("content") or []
    text_parts: list[str] = []
    tool_calls: list[ToolCall] = []

    if isinstance(content_parts, list):
        for part in content_parts:
            if not isinstance(part, dict):
                continue
            if part.get("type") == "text":
                text_parts.append(str(part.get("text", "")))
            elif part.get("type") == "tool_use":
                tool_calls.append(
                    ToolCall(
                        id=str(part.get("id", f"tool_{len(tool_calls) + 1}")),
                        name=str(part.get("name", "")),
                        arguments=ensure_tool_call_args_object(part.get("input", {})),
                    )
                )

    usage_raw = raw.get("usage")
    input_tokens = 0
    output_tokens = 0
    if isinstance(usage_raw, dict):
        input_tokens = int(usage_raw.get("input_tokens", 0) or 0)
        output_tokens = int(usage_raw.get("output_tokens", 0) or 0)

    return ModelResponse(
        id=f"bedrock_{int(time.time() * 1000)}",
        model=request.model,
        content="".join(text_parts),
        tool_calls=tool_calls if tool_calls else None,
        finish_reason=_map_finish_reason(raw.get("stop_reason")),  # type: ignore[arg-type]
        usage=ModelUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        ),
        created_at=datetime.now(),
        provider_metadata={"raw": raw},
    )


def parse_bedrock_stream_event(event: dict[str, object]) -> list[StreamChunk]:
    """Parse a single Bedrock stream event into StreamChunks."""
    chunks: list[StreamChunk] = []
    event_type = event.get("type", "")

    if event_type == "content_block_delta":
        delta = event.get("delta")
        if isinstance(delta, dict) and delta.get("text"):
            chunks.append(StreamChunk(type="content", content=str(delta["text"])))

    if event_type == "content_block_start":
        block = event.get("content_block")
        if isinstance(block, dict) and block.get("type") == "tool_use":
            chunks.append(
                StreamChunk(
                    type="tool_call",
                    tool_call=ToolCallDelta(
                        index=0,
                        name=str(block.get("name", "tool")),
                        arguments=ensure_tool_call_args_object(block.get("input", {})),
                    ),
                )
            )

    if event_type == "message_stop":
        stop_reason = event.get("stop_reason")
        if stop_reason:
            chunks.append(
                StreamChunk(type="done", finish_reason=_map_finish_reason(str(stop_reason)))
            )

    msg = event.get("message")
    if isinstance(msg, dict):
        msg_usage = msg.get("usage")
        if isinstance(msg_usage, dict):
            inp = int(msg_usage.get("input_tokens", 0) or 0)
            out = int(msg_usage.get("output_tokens", 0) or 0)
            chunks.append(
                StreamChunk(
                    type="usage",
                    usage=ModelUsage(
                        input_tokens=inp,
                        output_tokens=out,
                        total_tokens=inp + out,
                    ),
                )
            )

    return chunks


# ---------------------------------------------------------------------------
# BedrockProvider
# ---------------------------------------------------------------------------


class BedrockProvider(BaseModelProvider):
    """AWS Bedrock model provider.

    Supports text generation, streaming, multimodal input (images),
    and tool calls via the Anthropic Claude models on Bedrock.
    """

    def __init__(
        self,
        config: BedrockProviderConfig,
        supported_models: list[str] | None = None,
    ) -> None:
        self._config = config
        self._supported_models = supported_models or []
        self._capabilities = ProviderCapabilities(
            streaming=True,
            tool_calls=True,
            multimodal=True,
            image_generation=False,
            audio_generation=False,
            video_generation=False,
            image_to_text=True,
            image_to_audio=False,
            image_to_video=False,
            audio_to_text=False,
            audio_to_image=False,
            audio_to_video=False,
            video_to_text=False,
            video_to_image=False,
            video_to_audio=False,
        )
        self._client: object | None = None

    def _get_client(self) -> object:
        """Lazy-initialize the Bedrock client."""
        if self._client is not None:
            return self._client

        if self._config.client is not None:
            self._client = self._config.client
            return self._client

        try:
            import boto3
        except ImportError as exc:
            raise ImportError(
                "boto3 is required for the AWS Bedrock provider. "
                'Install it with: pip install "ai-governance-sdk[aws-bedrock]"'
            ) from exc

        kwargs: dict[str, object] = {}
        if self._config.region:
            kwargs["region_name"] = self._config.region
        self._client = boto3.client("bedrock-runtime", **kwargs)
        return self._client

    @property
    def id(self) -> str:
        return "aws-bedrock"

    @property
    def name(self) -> str:
        return "AWS Bedrock"

    @property
    def supported_models(self) -> list[str]:
        return self._supported_models

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._capabilities

    def _unsupported(self, capability: str) -> None:
        raise ProviderCapabilityNotSupportedError(self.id, capability)

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        self.validate_request(request)
        payload = build_bedrock_request(request, options)
        client = self._get_client()

        import asyncio

        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: client.invoke_model(  # type: ignore[attr-defined]
                modelId=request.model,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(payload),
            ),
        )

        body_bytes = response["body"].read()
        parsed = json.loads(body_bytes)
        return parse_bedrock_response(parsed, request)

    async def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        self.validate_request(request)
        payload = build_bedrock_request(request, options)
        client = self._get_client()

        import asyncio

        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: client.invoke_model_with_response_stream(  # type: ignore[attr-defined]
                modelId=request.model,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(payload),
            ),
        )

        stream_body = response.get("body")
        if not stream_body:
            raise ValueError("Bedrock stream not available")

        for event in stream_body:
            chunk_bytes = event.get("chunk", {}).get("bytes")
            if chunk_bytes:
                event_data = json.loads(chunk_bytes)
                chunks = parse_bedrock_stream_event(event_data)
                for chunk in chunks:
                    yield chunk

    # -- Image-to-text ------------------------------------------------------

    async def image_to_text(
        self,
        media_input: ImageInput,
        options: ImageToTextOptions | None = None,
    ) -> TextFromImageResponse:
        if not self._capabilities.image_to_text:
            self._unsupported("imageToText")

        model = options.model if options else None
        if not model:
            raise ValueError("Model is required for imageToText")

        payload = normalize_base64_input(media_input)
        prompt_text = (options.prompt if options else None) or "Describe this image."

        config: ModelConfig | None = None
        if options and options.config:
            config = options.config

        img_request = ModelRequest(
            model=model,
            messages=[
                ModelMessage(
                    role="user",
                    content=[
                        TextContentPart(text=prompt_text),
                        ImageContentPart(data=payload.base64, mime_type=payload.mime_type),
                    ],
                ),
            ],
            config=config,
        )
        response = await self.generate(img_request)
        return TextFromImageResponse(
            id=response.id,
            model=response.model,
            text=extract_text_from_content(response.content),
            created_at=response.created_at,
            provider_metadata=response.provider_metadata,
        )

    # -- Unsupported methods ------------------------------------------------

    async def generate_image(
        self, _prompt: str, _options: object | None = None
    ) -> ImageGenerationResponse:
        self._unsupported("imageGeneration")
        raise AssertionError("unreachable")

    async def generate_audio(
        self, _prompt: str, _options: object | None = None
    ) -> AudioGenerationResponse:
        self._unsupported("audioGeneration")
        raise AssertionError("unreachable")

    async def generate_video(
        self, _prompt: str, _options: object | None = None
    ) -> VideoGenerationResponse:
        self._unsupported("videoGeneration")
        raise AssertionError("unreachable")

    async def image_to_audio(
        self, _input: ImageInput, _options: ImageToAudioOptions | None = None
    ) -> AudioFromImageResponse:
        self._unsupported("imageToAudio")
        raise AssertionError("unreachable")

    async def image_to_video(
        self, _input: ImageInput, _options: ImageToVideoOptions | None = None
    ) -> VideoFromImageResponse:
        self._unsupported("imageToVideo")
        raise AssertionError("unreachable")

    async def audio_to_text(
        self, _input: AudioInput, _options: AudioToTextOptions | None = None
    ) -> TextFromAudioResponse:
        self._unsupported("audioToText")
        raise AssertionError("unreachable")

    async def audio_to_image(
        self, _input: AudioInput, _options: AudioToImageOptions | None = None
    ) -> ImageFromAudioResponse:
        self._unsupported("audioToImage")
        raise AssertionError("unreachable")

    async def audio_to_video(
        self, _input: AudioInput, _options: AudioToVideoOptions | None = None
    ) -> VideoFromAudioResponse:
        self._unsupported("audioToVideo")
        raise AssertionError("unreachable")

    async def video_to_text(
        self, _input: VideoInput, _options: VideoToTextOptions | None = None
    ) -> TextFromVideoResponse:
        self._unsupported("videoToText")
        raise AssertionError("unreachable")

    async def video_to_image(
        self, _input: VideoInput, _options: VideoToImageOptions | None = None
    ) -> ImageFromVideoResponse:
        self._unsupported("videoToImage")
        raise AssertionError("unreachable")

    async def video_to_audio(
        self, _input: VideoInput, _options: VideoToAudioOptions | None = None
    ) -> AudioFromVideoResponse:
        self._unsupported("videoToAudio")
        raise AssertionError("unreachable")
