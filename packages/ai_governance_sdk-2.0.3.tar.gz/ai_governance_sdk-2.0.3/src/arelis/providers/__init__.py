"""Providers package -- model provider adapters for various LLM services.

Each sub-package is an optional provider that requires its own dependencies.
The shared utilities are always available.

Usage::

    from arelis.providers.shared import ProviderCapabilities
    from arelis.providers.google_vertex import VertexAIProvider
    from arelis.providers.aws_bedrock import BedrockProvider
    from arelis.providers.azure_openai import AzureOpenAIProvider
    from arelis.providers.huggingface import HuggingFaceProvider
    from arelis.providers.onpremise import OnPremiseProvider
"""

from __future__ import annotations

__all__: list[str] = []
