"""Conformance test helpers for provider adapters.

Ports the TypeScript SDK's `packages/providers-shared/src/conformance.ts`.
Provides a framework-agnostic way to validate that a provider correctly
builds requests, parses responses, and handles stream chunks.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Generic, TypeVar

from arelis.models.types import (
    ModelRequest,
    ModelResponse,
    StreamChunk,
    ToolCall,
)

__all__ = [
    "ConformanceFixture",
    "ConformanceExpectedStream",
    "ConformanceSuite",
    "run_conformance_tests",
]

TProviderRequest = TypeVar("TProviderRequest")
TProviderResponse = TypeVar("TProviderResponse")
TStreamChunk = TypeVar("TStreamChunk")


# ---------------------------------------------------------------------------
# Conformance data types
# ---------------------------------------------------------------------------


@dataclass
class ConformanceExpectedStream(Generic[TStreamChunk]):
    """Expected stream data for a conformance fixture."""

    provider_chunks: list[TStreamChunk]
    expected_chunks: list[StreamChunk]


@dataclass
class ConformanceFixture(Generic[TProviderRequest, TProviderResponse, TStreamChunk]):
    """A single conformance test fixture."""

    name: str
    request: ModelRequest
    expected_provider_request: TProviderRequest
    provider_response: TProviderResponse
    expected_text: str | None = None
    expected_tool_calls: list[ToolCall] | None = None
    expected_stream: ConformanceExpectedStream[TStreamChunk] | None = None


@dataclass
class ConformanceSuite(Generic[TProviderRequest, TProviderResponse, TStreamChunk]):
    """A conformance test suite for a provider adapter."""

    name: str
    build_request: Callable[[ModelRequest], TProviderRequest]
    parse_response: Callable[[TProviderResponse, ModelRequest], ModelResponse]
    fixtures: list[ConformanceFixture[TProviderRequest, TProviderResponse, TStreamChunk]] = field(
        default_factory=list,
    )
    parse_stream_chunk: (
        Callable[[TStreamChunk, ModelRequest], StreamChunk | list[StreamChunk] | None] | None
    ) = None


# ---------------------------------------------------------------------------
# Run conformance tests
# ---------------------------------------------------------------------------


def run_conformance_tests(
    suite: ConformanceSuite[TProviderRequest, TProviderResponse, TStreamChunk],
) -> list[tuple[str, bool, str]]:
    """Run conformance tests and return results.

    Returns a list of ``(test_name, passed, message)`` tuples.  This is
    framework-agnostic -- callers can feed the results into pytest, unittest,
    or any other test runner.
    """
    results: list[tuple[str, bool, str]] = []

    for fixture in suite.fixtures:
        # --- Test: build request ---
        test_name = f"{suite.name} conformance: builds provider request for {fixture.name}"
        try:
            actual = suite.build_request(fixture.request)
            if actual == fixture.expected_provider_request:
                results.append((test_name, True, "OK"))
            else:
                results.append(
                    (
                        test_name,
                        False,
                        f"Expected {fixture.expected_provider_request!r}, got {actual!r}",
                    )
                )
        except Exception as exc:
            results.append((test_name, False, f"Exception: {exc}"))

        # --- Test: parse response ---
        test_name = f"{suite.name} conformance: parses provider response for {fixture.name}"
        try:
            response = suite.parse_response(fixture.provider_response, fixture.request)
            passed = True
            message = "OK"

            if fixture.expected_text is not None:
                actual_text = (
                    response.content if isinstance(response.content, str) else str(response.content)
                )
                if actual_text != fixture.expected_text:
                    passed = False
                    message = (
                        f"Text mismatch: expected {fixture.expected_text!r}, got {actual_text!r}"
                    )

            if (
                fixture.expected_tool_calls is not None
                and response.tool_calls != fixture.expected_tool_calls
            ):
                passed = False
                message = (
                    f"Tool calls mismatch: expected {fixture.expected_tool_calls!r}, "
                    f"got {response.tool_calls!r}"
                )

            results.append((test_name, passed, message))
        except Exception as exc:
            results.append((test_name, False, f"Exception: {exc}"))

        # --- Test: parse stream chunks ---
        if fixture.expected_stream is not None and suite.parse_stream_chunk is not None:
            expected_stream = fixture.expected_stream
            parse_fn = suite.parse_stream_chunk
            test_name = f"{suite.name} conformance: parses stream chunks for {fixture.name}"
            try:
                parsed: list[StreamChunk] = []
                for provider_chunk in expected_stream.provider_chunks:
                    chunk = parse_fn(provider_chunk, fixture.request)
                    if isinstance(chunk, list):
                        parsed.extend(chunk)
                    elif chunk is not None:
                        parsed.append(chunk)

                if parsed == expected_stream.expected_chunks:
                    results.append((test_name, True, "OK"))
                else:
                    results.append(
                        (
                            test_name,
                            False,
                            f"Stream mismatch: expected "
                            f"{expected_stream.expected_chunks!r}, got {parsed!r}",
                        )
                    )
            except Exception as exc:
                results.append((test_name, False, f"Exception: {exc}"))

    return results
