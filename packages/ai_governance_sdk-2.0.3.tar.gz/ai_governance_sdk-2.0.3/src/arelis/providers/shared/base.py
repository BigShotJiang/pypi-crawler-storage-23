"""Shared provider base class and utilities.

Ports the TypeScript SDK's `packages/providers-shared/src/` modules:
- types.ts (ProviderCapabilities, ProviderConfigBase)
- messages.ts (message helpers)
- media.ts (base64 encoding)
- http.ts (fetch helpers)
- sse.ts (SSE parsing)
"""

from __future__ import annotations

import base64
import json
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Literal, TypeVar

import httpx

from arelis.models.types import (
    Base64MediaInput,
    BinaryMediaInput,
    ContentPart,
    ImageContentPart,
    MediaInput,
    ModelMessage,
    TextContentPart,
)

__all__ = [
    # Types
    "ProviderCapabilities",
    "ProviderConfigBase",
    "Base64MediaPayload",
    "NormalizedTextPart",
    "NormalizedImagePart",
    "NormalizedPart",
    "SplitMessagesResult",
    # Message helpers
    "extract_text_from_content",
    "normalize_content_parts",
    "split_system_messages",
    "ensure_tool_call_args_object",
    "to_base64_image_url",
    "to_provider_tool_schema",
    "collect_message_text",
    "filter_content_parts",
    # Media helpers
    "encode_base64",
    "normalize_base64_input",
    # HTTP helpers
    "fetch_json",
    "fetch_text",
    "fetch_binary",
    # SSE helpers
    "parse_sse",
    "parse_sse_json",
]

T = TypeVar("T")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class ProviderCapabilities:
    """Capabilities supported by a model provider."""

    streaming: bool = False
    tool_calls: bool = False
    multimodal: bool = False
    image_generation: bool = False
    audio_generation: bool = False
    video_generation: bool = False
    image_to_text: bool = False
    image_to_audio: bool = False
    image_to_video: bool = False
    audio_to_text: bool = False
    audio_to_image: bool = False
    audio_to_video: bool = False
    video_to_text: bool = False
    video_to_image: bool = False
    video_to_audio: bool = False


@dataclass
class ProviderConfigBase:
    """Base configuration shared by all provider configs."""

    timeout_ms: int | None = None
    http_client: httpx.AsyncClient | None = None


# ---------------------------------------------------------------------------
# Media helpers
# ---------------------------------------------------------------------------


@dataclass
class Base64MediaPayload:
    """A base64-encoded media payload with its MIME type."""

    base64: str
    mime_type: str


def encode_base64(data: bytes) -> str:
    """Encode raw bytes to a base64 string."""
    return base64.b64encode(data).decode("ascii")


def normalize_base64_input(media_input: MediaInput) -> Base64MediaPayload:
    """Normalize a media input to a Base64MediaPayload."""
    if isinstance(media_input, Base64MediaInput):
        return Base64MediaPayload(base64=media_input.base64, mime_type=media_input.mime_type)
    if isinstance(media_input, BinaryMediaInput):
        return Base64MediaPayload(
            base64=encode_base64(media_input.data), mime_type=media_input.mime_type
        )
    # Fallback: treat as Base64MediaInput duck-type
    b64 = getattr(media_input, "base64", None)
    if b64 is not None:
        return Base64MediaPayload(base64=b64, mime_type=media_input.mime_type)
    raw_data = getattr(media_input, "data", b"")
    return Base64MediaPayload(base64=encode_base64(raw_data), mime_type=media_input.mime_type)


# ---------------------------------------------------------------------------
# Message helpers
# ---------------------------------------------------------------------------


def extract_text_from_content(content: str | list[ContentPart]) -> str:
    """Extract text from a message's content."""
    if isinstance(content, str):
        return content
    parts: list[str] = []
    for part in content:
        if isinstance(part, TextContentPart):
            parts.append(part.text)
    return " ".join(parts)


@dataclass
class NormalizedTextPart:
    """Normalized text part."""

    text: str
    type: Literal["text"] = "text"


@dataclass
class NormalizedImagePart:
    """Normalized image part."""

    data: str
    mime_type: str
    type: Literal["image"] = "image"


NormalizedPart = NormalizedTextPart | NormalizedImagePart


def normalize_content_parts(content: str | list[ContentPart]) -> list[NormalizedPart]:
    """Normalize message content into a flat list of text/image parts."""
    if isinstance(content, str):
        return [NormalizedTextPart(text=content)]

    parts: list[NormalizedPart] = []
    for part in content:
        if isinstance(part, TextContentPart):
            parts.append(NormalizedTextPart(text=part.text))
        elif isinstance(part, ImageContentPart):
            parts.append(NormalizedImagePart(data=part.data, mime_type=part.mime_type))
    return parts


@dataclass
class SplitMessagesResult:
    """Result of splitting system messages from the rest."""

    system: str | None
    rest: list[ModelMessage]


def split_system_messages(messages: list[ModelMessage]) -> SplitMessagesResult:
    """Split system messages from the rest, concatenating system texts."""
    system_parts: list[str] = []
    rest: list[ModelMessage] = []

    for message in messages:
        if message.role == "system":
            system_parts.append(extract_text_from_content(message.content))
        else:
            rest.append(message)

    system = "\n".join(system_parts) if system_parts else None
    return SplitMessagesResult(system=system, rest=rest)


def ensure_tool_call_args_object(value: object) -> dict[str, object]:
    """Ensure a tool call argument is a dict.

    If *value* is already a dict, returns it. If a JSON string, attempts
    to parse it.  Falls back to ``{"value": value}``.
    """
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, ValueError):
            return {"value": value}
    return {"value": value}


def to_base64_image_url(data: str, mime_type: str) -> str:
    """Convert base64 data + mime type to a data URL."""
    if data.startswith("data:"):
        return data
    return f"data:{mime_type};base64,{data}"


def to_provider_tool_schema(parameters: dict[str, object]) -> dict[str, object]:
    """Ensure a tool schema has ``type: 'object'``."""
    schema: dict[str, object] = dict(parameters) if parameters else {}
    if "type" in schema:
        return schema
    return {"type": "object", **schema}


def collect_message_text(messages: list[ModelMessage]) -> str:
    """Collect all text from messages, joined by newlines."""
    return "\n".join(extract_text_from_content(m.content) for m in messages)


def filter_content_parts(content: str | list[ContentPart]) -> list[ContentPart]:
    """Filter content parts to text and image only."""
    if isinstance(content, str):
        return [TextContentPart(text=content)]
    return [p for p in content if isinstance(p, (TextContentPart, ImageContentPart))]


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------


def _default_timeout(timeout_ms: int | None) -> float:
    """Convert timeout_ms to seconds, defaulting to 30s."""
    return (timeout_ms or 30_000) / 1000.0


async def _get_client(
    client: httpx.AsyncClient | None,
) -> tuple[httpx.AsyncClient, bool]:
    """Return the given client or create a new one.

    Returns a tuple of (client, should_close).
    """
    if client is not None:
        return client, False
    return httpx.AsyncClient(), True


async def fetch_json(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    http_client: httpx.AsyncClient | None = None,
    timeout_ms: int | None = None,
) -> object:
    """Fetch JSON from a URL with timeout."""
    client, should_close = await _get_client(http_client)
    timeout = _default_timeout(timeout_ms)
    try:
        response = await client.request(
            method,
            url,
            headers=headers or {},
            content=body,
            timeout=timeout,
        )
        if response.status_code >= 400:
            text = response.text
            raise httpx.HTTPStatusError(
                f"HTTP {response.status_code}: {text}",
                request=response.request,
                response=response,
            )
        return response.json()
    finally:
        if should_close:
            await client.aclose()


async def fetch_text(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    http_client: httpx.AsyncClient | None = None,
    timeout_ms: int | None = None,
) -> str:
    """Fetch text from a URL with timeout."""
    client, should_close = await _get_client(http_client)
    timeout = _default_timeout(timeout_ms)
    try:
        response = await client.request(
            method,
            url,
            headers=headers or {},
            content=body,
            timeout=timeout,
        )
        if response.status_code >= 400:
            text = response.text
            raise httpx.HTTPStatusError(
                f"HTTP {response.status_code}: {text}",
                request=response.request,
                response=response,
            )
        return response.text
    finally:
        if should_close:
            await client.aclose()


async def fetch_binary(
    url: str,
    *,
    method: str = "POST",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    http_client: httpx.AsyncClient | None = None,
    timeout_ms: int | None = None,
) -> tuple[bytes, str]:
    """Fetch binary data from a URL. Returns (data, content_type)."""
    client, should_close = await _get_client(http_client)
    timeout = _default_timeout(timeout_ms)
    try:
        response = await client.request(
            method,
            url,
            headers=headers or {},
            content=body,
            timeout=timeout,
        )
        if response.status_code >= 400:
            text = response.text
            raise httpx.HTTPStatusError(
                f"HTTP {response.status_code}: {text}",
                request=response.request,
                response=response,
            )
        content_type = response.headers.get("content-type", "application/octet-stream")
        return response.content, content_type
    finally:
        if should_close:
            await client.aclose()


# ---------------------------------------------------------------------------
# SSE helpers
# ---------------------------------------------------------------------------


async def parse_sse(stream: AsyncIterator[bytes]) -> AsyncIterator[str]:
    """Parse a server-sent events stream into data payloads.

    Each yielded string is one complete SSE data payload (the lines between
    blank lines, with the ``data:`` prefix stripped).
    """
    buffer = ""
    current = ""

    async for raw_chunk in stream:
        buffer += raw_chunk.decode("utf-8", errors="replace")
        while "\n" in buffer:
            idx = buffer.index("\n")
            line = buffer[:idx].rstrip("\r")
            buffer = buffer[idx + 1 :]

            if line == "":
                # Blank line = end of event
                if current:
                    if current != "[DONE]":
                        yield current
                    current = ""
                continue

            if line.startswith("data:"):
                value = line[5:].strip()
                current += value

    # Flush remaining
    if current and current != "[DONE]":
        yield current


async def parse_sse_json(stream: AsyncIterator[bytes]) -> AsyncIterator[object]:
    """Parse an SSE stream, yielding parsed JSON objects."""
    async for chunk_str in parse_sse(stream):
        yield json.loads(chunk_str)
