"""Shared provider utilities, base types, and conformance test helpers."""

from __future__ import annotations

from arelis.providers.shared.base import (
    Base64MediaPayload,
    NormalizedImagePart,
    NormalizedPart,
    NormalizedTextPart,
    ProviderCapabilities,
    ProviderConfigBase,
    SplitMessagesResult,
    collect_message_text,
    encode_base64,
    ensure_tool_call_args_object,
    extract_text_from_content,
    fetch_binary,
    fetch_json,
    fetch_text,
    filter_content_parts,
    normalize_base64_input,
    normalize_content_parts,
    parse_sse,
    parse_sse_json,
    split_system_messages,
    to_base64_image_url,
    to_provider_tool_schema,
)
from arelis.providers.shared.conformance import (
    ConformanceExpectedStream,
    ConformanceFixture,
    ConformanceSuite,
    run_conformance_tests,
)

__all__ = [
    # Types
    "ProviderCapabilities",
    "ProviderConfigBase",
    "Base64MediaPayload",
    "NormalizedTextPart",
    "NormalizedImagePart",
    "NormalizedPart",
    "SplitMessagesResult",
    # Message helpers
    "extract_text_from_content",
    "normalize_content_parts",
    "split_system_messages",
    "ensure_tool_call_args_object",
    "to_base64_image_url",
    "to_provider_tool_schema",
    "collect_message_text",
    "filter_content_parts",
    # Media helpers
    "encode_base64",
    "normalize_base64_input",
    # HTTP helpers
    "fetch_json",
    "fetch_text",
    "fetch_binary",
    # SSE helpers
    "parse_sse",
    "parse_sse_json",
    # Conformance
    "ConformanceExpectedStream",
    "ConformanceFixture",
    "ConformanceSuite",
    "run_conformance_tests",
]
