"""PII scanning for the Arelis AI SDK governance gate.

Provides PII detection for prompts using the Redactor from
``arelis.policy.redactor``.  When a ``Redactor`` instance or
``RedactorConfig`` is supplied via :class:`ScanPromptForPiiOptions`
the redactor is used directly; otherwise a default Redactor is created.
A legacy regex-based fallback is kept for cases where the redactor
module is unavailable.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, cast

from arelis.governance_gate.types import (
    PromptPiiFinding,
    PromptPiiScanResult,
    ScanPromptForPiiOptions,
)

if TYPE_CHECKING:
    from arelis.policy.redactor import Redactor, RedactorConfig

__all__ = [
    "scan_prompt_for_pii",
]

# ---------------------------------------------------------------------------
# PII detection patterns (legacy regex fallback)
# ---------------------------------------------------------------------------

_EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")

_PHONE_PATTERN = re.compile(r"(?:\+?1[-.\s]?)?(?:\(?[0-9]{3}\)?[-.\s]?)?[0-9]{3}[-.\s]?[0-9]{4}")

_SSN_PATTERN = re.compile(r"\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b")

_CREDIT_CARD_PATTERN = re.compile(r"\b(?:\d{4}[-.\s]?){3}\d{4}\b")


# ---------------------------------------------------------------------------
# Redactor-based PII mapping
# ---------------------------------------------------------------------------

# Map RedactionFindingType to PromptPiiFinding type.  The Redactor emits
# types like "email", "phone", "api_key", "custom".  We map "api_key" to
# the closest PII category ("api_key") and "custom" to "custom".
_REDACTION_TO_PII_TYPE: dict[str, str] = {
    "email": "email",
    "phone": "phone",
    "api_key": "api_key",
    "custom": "custom",
}


def _resolve_redactor(opts: ScanPromptForPiiOptions) -> Redactor:
    """Resolve a Redactor from scan options, matching TS SDK behaviour.

    Priority:
    1. ``opts.redactor`` -- use it directly (cast from ``object``).
    2. ``opts.redactor_config`` -- create a Redactor from the config.
    3. Otherwise create a default Redactor.
    """
    from arelis.policy.redactor import Redactor as RedactorClass
    from arelis.policy.redactor import create_redactor

    if opts.redactor is not None:
        return cast("RedactorClass", opts.redactor)

    if opts.redactor_config is not None:
        return create_redactor(cast("RedactorConfig", opts.redactor_config))

    return create_redactor()


def _scan_with_redactor(
    prompt: str,
    redactor: Redactor,
) -> PromptPiiScanResult:
    """Scan *prompt* using an ``arelis.policy.redactor.Redactor`` instance."""
    result = redactor.redact(prompt)

    findings: list[PromptPiiFinding] = []
    for finding in result.findings:
        # Map the redaction finding type to the PII finding type.
        # Types that don't have a direct mapping (e.g. "api_key", "custom")
        # are mapped to "custom" in PromptPiiFinding.
        pii_type_str = _REDACTION_TO_PII_TYPE.get(finding.type, "custom")
        # Validate against the Literal union accepted by PromptPiiFinding.
        if pii_type_str not in ("email", "phone", "ssn", "credit_card", "api_key", "custom"):
            pii_type_str = "custom"

        findings.append(
            PromptPiiFinding(
                type=pii_type_str,  # type: ignore[arg-type]
                original=finding.original,
                start=finding.start,
                end=finding.end,
                pattern=finding.pattern,
            )
        )

    return PromptPiiScanResult(
        has_pii=len(findings) > 0,
        findings=findings,
    )


# ---------------------------------------------------------------------------
# Legacy regex-based fallback
# ---------------------------------------------------------------------------


def _scan_with_regex(
    prompt: str,
    opts: ScanPromptForPiiOptions,
) -> PromptPiiScanResult:
    """Fallback regex-based PII scan (used when Redactor is unavailable)."""
    findings: list[PromptPiiFinding] = []

    if opts.detect_emails:
        for match in _EMAIL_PATTERN.finditer(prompt):
            findings.append(
                PromptPiiFinding(
                    type="email",
                    original=match.group(),
                    start=match.start(),
                    end=match.end(),
                    pattern="email",
                )
            )

    if opts.detect_phones:
        for match in _PHONE_PATTERN.finditer(prompt):
            findings.append(
                PromptPiiFinding(
                    type="phone",
                    original=match.group(),
                    start=match.start(),
                    end=match.end(),
                    pattern="phone",
                )
            )

    if opts.detect_ssns:
        for match in _SSN_PATTERN.finditer(prompt):
            findings.append(
                PromptPiiFinding(
                    type="ssn",
                    original=match.group(),
                    start=match.start(),
                    end=match.end(),
                    pattern="ssn",
                )
            )

    if opts.detect_credit_cards:
        for match in _CREDIT_CARD_PATTERN.finditer(prompt):
            findings.append(
                PromptPiiFinding(
                    type="credit_card",
                    original=match.group(),
                    start=match.start(),
                    end=match.end(),
                    pattern="credit_card",
                )
            )

    # Sort findings by start position
    findings.sort(key=lambda f: f.start)

    return PromptPiiScanResult(
        has_pii=len(findings) > 0,
        findings=findings,
    )


# ---------------------------------------------------------------------------
# scan_prompt_for_pii
# ---------------------------------------------------------------------------


def scan_prompt_for_pii(
    prompt: str,
    options: ScanPromptForPiiOptions | None = None,
) -> PromptPiiScanResult:
    """Scan a prompt for PII.

    When a :class:`~arelis.policy.redactor.Redactor` or
    :class:`~arelis.policy.redactor.RedactorConfig` is provided via
    *options*, the Redactor is used for detection (matching the TypeScript
    SDK behaviour).  If neither is provided a default Redactor is created.

    A legacy regex-based fallback is used only when the redactor module
    cannot be imported.

    Args:
        prompt: The text to scan.
        options: Scanning options controlling PII detection behaviour.

    Returns:
        A scan result with findings.
    """
    opts = options or ScanPromptForPiiOptions()

    # TS parity: always prefer Redactor path (explicit instance/config or
    # default create_redactor()). Regex scanning is fallback-only when
    # redactor imports are unavailable.
    try:
        redactor = _resolve_redactor(opts)
        return _scan_with_redactor(prompt, redactor)
    except ImportError:
        return _scan_with_regex(prompt, opts)
