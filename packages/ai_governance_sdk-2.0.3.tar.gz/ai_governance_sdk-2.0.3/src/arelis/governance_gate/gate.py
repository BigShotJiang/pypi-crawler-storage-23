"""Governance gate evaluation for the Arelis AI SDK.

Ports ``evaluatePreInvocationGate`` and ``withGovernanceGate`` from
``packages/sdk/src/governance-gate.ts`` in the TypeScript SDK.
"""

from __future__ import annotations

import inspect
import time
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar, cast

from arelis.core.errors import GovernanceGateDeniedError
from arelis.core.run_context import default_context_resolver, generate_run_id
from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.governance_gate.pii import scan_prompt_for_pii
from arelis.governance_gate.types import (
    EvaluatePreInvocationGateInput,
    GovernanceGateDecisionTimings,
    GovernanceGateEvaluatePolicyInput,
    GovernanceGateEvaluator,
    GovernanceGatePlatform,
    GovernanceGatePolicyData,
    GovernanceGateSource,
    GovernanceGateTelemetryOptions,
    PolicyDecision,
    PolicyResult,
    PolicyResultSummary,
    PolicySummaryInfo,
    PreInvocationGateDecision,
    PreInvocationGateMetadata,
    ScanPromptForPiiOptions,
    WithGovernanceGateOptions,
    WithGovernanceGateResult,
)
from arelis.platform import (
    DEFAULT_ARELIS_PLATFORM_BASE_URL,
    ArelisPlatform,
)
from arelis.platform.event_bridge import create_platform_event

__all__ = [
    "evaluate_pre_invocation_gate",
    "with_governance_gate",
]

T = TypeVar("T")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value


def _is_platform_source(source: GovernanceGateSource) -> bool:
    return (
        hasattr(source, "events")
        and hasattr(source, "governance")
        and hasattr(source.governance, "evaluatePolicy")
        and hasattr(source.events, "create")
    )


def _resolve_evaluator(source: GovernanceGateSource) -> GovernanceGateEvaluator:
    """Resolve a governance gate source to an evaluator."""
    if _is_platform_source(source):
        return _PlatformGovernanceGateEvaluator(cast("GovernanceGatePlatform", source))

    if hasattr(source, "governance") and hasattr(source.governance, "create_gate_evaluator"):
        return source.governance.create_gate_evaluator()

    if hasattr(source, "evaluate_policy") and hasattr(source, "resolve_context"):
        return cast("GovernanceGateEvaluator", source)

    raise ValueError(
        "Unsupported governance gate source: expected "
        "ArelisClient.governance.create_gate_evaluator(), ArelisPlatform, "
        "or GovernanceGateEvaluator"
    )


class _PlatformGovernanceGateEvaluator:
    """Governance evaluator backed by ``ArelisPlatform.governance.evaluatePolicy``."""

    def __init__(self, platform: GovernanceGatePlatform) -> None:
        self._platform = platform
        self._last_policy_set_hash: str | None = None

    async def resolve_context(self, partial: GovernanceContext | None = None) -> GovernanceContext:
        return await default_context_resolver(partial)

    async def evaluate_policy(self, input: GovernanceGateEvaluatePolicyInput) -> PolicyResult:
        response = await _maybe_await(
            self._platform.governance.evaluatePolicy(
                {
                    "runId": input.run_id,
                    "policyIds": input.policy_ids,
                    "checkpoint": {
                        "stage": input.checkpoint,
                        "context": {
                            "orgId": input.context.org.id,
                            "teamId": input.context.team.id if input.context.team else None,
                            "actorId": input.context.actor.id,
                            "actorType": input.context.actor.type,
                            "purpose": input.context.purpose,
                            "environment": input.context.environment,
                            "tags": input.context.tags,
                        },
                        "modelId": input.data.model_id,
                        "input": input.data.input,
                    },
                }
            )
        )

        if isinstance(response, dict):
            policy_set_hash = response.get("policySetHash")
            if isinstance(policy_set_hash, str) and policy_set_hash != "":
                self._last_policy_set_hash = policy_set_hash

        return _normalize_platform_policy_response(response)

    def get_policy_metadata(self) -> dict[str, str | None] | None:
        return {
            "policy_snapshot_hash": self._last_policy_set_hash,
            "policy_compiler_id": "platform-managed",
        }


def _normalize_platform_policy_response(response: Any) -> PolicyResult:
    if not isinstance(response, dict):
        return PolicyResult(
            decisions=[PolicyDecision(effect="allow")],
            summary=PolicyResultSummary(allowed=True),
        )

    raw_decisions = response.get("decisions")
    decisions = (
        [_normalize_platform_policy_decision(d) for d in raw_decisions]
        if isinstance(raw_decisions, list)
        else []
    )

    block_decision = next((d for d in decisions if d.effect == "block"), None)
    approval_decision = next((d for d in decisions if d.effect == "require_approval"), None)

    policy_version: str | None = None
    evaluated = response.get("evaluatedPolicies")
    if isinstance(evaluated, list) and len(evaluated) > 0 and isinstance(evaluated[0], dict):
        first = evaluated[0]
        policy_id = first.get("id")
        version = first.get("version")
        if isinstance(policy_id, str) and isinstance(version, (int, float)):
            policy_version = f"{policy_id}@{version}"

    return PolicyResult(
        decisions=decisions,
        policy_version=policy_version,
        summary=PolicyResultSummary(
            allowed=block_decision is None and approval_decision is None,
            block_reason=(
                block_decision.reason
                if block_decision is not None
                else approval_decision.reason
                if approval_decision is not None
                else None
            ),
            block_code=block_decision.code if block_decision is not None else None,
            approvers=approval_decision.approvers if approval_decision is not None else None,
        ),
    )


def _normalize_platform_policy_decision(raw_decision: Any) -> PolicyDecision:
    if not isinstance(raw_decision, dict):
        return PolicyDecision(effect="allow")

    decision_value = _to_lower_text(raw_decision.get("decision") or raw_decision.get("effect"))
    reason = (
        _read_string(raw_decision.get("reason"))
        or _read_string(raw_decision.get("message"))
        or _read_string(raw_decision.get("policyId"))
    )
    code = _read_string(raw_decision.get("code")) or _read_nested_string(
        raw_decision.get("metadata"), "code"
    )

    if decision_value in ("deny", "block"):
        return PolicyDecision(
            effect="block",
            reason=reason or "Blocked by platform policy",
            code=code,
        )

    if decision_value in ("escalate", "require_approval"):
        approvers = _read_string_array(raw_decision.get("approvers"))
        return PolicyDecision(
            effect="require_approval",
            reason=reason or "Approval required by platform policy",
            approvers=approvers if len(approvers) > 0 else ["platform-approval"],
        )

    if decision_value in ("transform", "redact"):
        return PolicyDecision(
            effect="transform",
            reason=reason,
        )

    return PolicyDecision(effect="allow")


def _read_string(value: Any) -> str | None:
    return value if isinstance(value, str) and value != "" else None


def _read_nested_string(value: Any, key: str) -> str | None:
    if not isinstance(value, dict):
        return None
    return _read_string(value.get(key))


def _to_lower_text(value: Any) -> str | None:
    if not isinstance(value, str) or value == "":
        return None
    return value.lower()


def _read_string_array(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [entry for entry in value if isinstance(entry, str) and entry != ""]


def _collect_reasons(result: PolicyResult) -> list[str]:
    """Collect denial reasons from a policy result."""
    reasons: set[str] = set()

    for decision in result.decisions:
        if decision.effect in ("block", "transform", "require_approval") and decision.reason:
            reasons.add(decision.reason)

    if result.summary.block_reason:
        reasons.add(result.summary.block_reason)

    return list(reasons)


def _collect_codes(result: PolicyResult) -> list[str]:
    """Collect denial codes from a policy result."""
    codes: set[str] = set()

    for decision in result.decisions:
        if decision.effect == "block" and decision.code:
            codes.add(decision.code)

    if result.summary.block_code:
        codes.add(result.summary.block_code)

    return list(codes)


def _resolve_telemetry_platform(
    source: GovernanceGateSource,
    options: GovernanceGateTelemetryOptions | None,
) -> GovernanceGatePlatform | None:
    if options is not None and options.platform is not None:
        return options.platform

    if options is not None and options.api_key is not None:
        return cast(
            "GovernanceGatePlatform",
            ArelisPlatform(
                {
                    "apiKey": options.api_key,
                    "baseUrl": options.base_url or DEFAULT_ARELIS_PLATFORM_BASE_URL,
                }
            ),
        )

    if _is_platform_source(source):
        return cast("GovernanceGatePlatform", source)

    return None


async def _report_gate_event(
    platform: GovernanceGatePlatform,
    warnings: list[str],
    input: dict[str, Any],
) -> None:
    try:
        resource = cast("dict[str, Any]", input["resource"])
        payload = create_platform_event(
            {
                "runId": str(input["run_id"]),
                "eventType": str(input["event_type"]),
                "actor": {
                    "id": str(input["actor"].id),
                    "type": str(input["actor"].type),
                },
                "action": str(input["action"]),
                "resource": {
                    "type": str(resource.get("type", "")),
                    "id": str(resource.get("id", "")),
                },
                "metadata": cast("dict[str, Any]", input["metadata"]),
            }
        )
        await _maybe_await(platform.events.create(cast("dict[str, object]", dict(payload))))
    except Exception as error:
        warnings.append(
            f"Failed to report platform gate telemetry ({input['event_type']}): {error}"
        )


# ---------------------------------------------------------------------------
# evaluate_pre_invocation_gate
# ---------------------------------------------------------------------------


async def evaluate_pre_invocation_gate(
    source: GovernanceGateSource,
    input: EvaluatePreInvocationGateInput,
    options: ScanPromptForPiiOptions | None = None,
) -> PreInvocationGateDecision:
    """Evaluate the pre-invocation governance gate.

    Scans the prompt for PII, resolves governance context, and evaluates
    policy at the ``BeforePrompt`` checkpoint.
    """
    started_at = time.perf_counter()
    evaluator = _resolve_evaluator(source)

    scan_started_at = time.perf_counter()
    pii = scan_prompt_for_pii(input.prompt, options)
    scan_ms = (time.perf_counter() - scan_started_at) * 1000.0

    run_id = input.run_id or generate_run_id()

    partial_context = GovernanceContext(
        org=(input.context.org if input.context is not None else OrgRef(id="sdk-governance-gate")),
        actor=input.actor,
        purpose=(input.context.purpose if input.context is not None else "pre-invocation-gate"),
        environment=(input.context.environment if input.context is not None else "dev"),
        team=input.context.team if input.context is not None else None,
        session_id=input.context.session_id if input.context is not None else None,
        request_id=input.context.request_id if input.context is not None else None,
        tags=input.context.tags if input.context is not None else None,
    )

    context = await evaluator.resolve_context(partial_context)

    policy_eval_started_at = time.perf_counter()
    policy_result = await evaluator.evaluate_policy(
        GovernanceGateEvaluatePolicyInput(
            checkpoint="BeforePrompt",
            run_id=run_id,
            context=context,
            data=GovernanceGatePolicyData(
                model_id=input.model,
                input=[{"role": "user", "content": input.prompt}],
            ),
            policy_ids=input.policy_ids,
        )
    )
    policy_eval_ms = (time.perf_counter() - policy_eval_started_at) * 1000.0
    total_ms = (time.perf_counter() - started_at) * 1000.0

    reasons = _collect_reasons(policy_result)
    codes = _collect_codes(policy_result)
    metadata_dict = (
        evaluator.get_policy_metadata() if evaluator.get_policy_metadata is not None else None
    ) or {}

    return PreInvocationGateDecision(
        run_id=run_id,
        decision="allow" if policy_result.summary.allowed else "deny",
        pii=pii,
        policy=PolicySummaryInfo(
            allowed=policy_result.summary.allowed,
            decisions=policy_result.decisions,
            summary=policy_result.summary,
            policy_version=policy_result.policy_version,
        ),
        metadata=PreInvocationGateMetadata(
            policy_ids=list(input.policy_ids or []),
            policy_ids_mode="metadata_only",
            actor=ActorRef(
                id=input.actor.id,
                type=input.actor.type,
            ),
            model=input.model,
            policy_snapshot_hash=metadata_dict.get("policy_snapshot_hash"),
            policy_compiler_id=metadata_dict.get("policy_compiler_id"),
            timings=GovernanceGateDecisionTimings(
                scan_ms=scan_ms,
                policy_eval_ms=policy_eval_ms,
                total_ms=total_ms,
            ),
        ),
        reasons=reasons,
        codes=codes,
    )


# ---------------------------------------------------------------------------
# with_governance_gate
# ---------------------------------------------------------------------------


async def with_governance_gate(
    source: GovernanceGateSource,
    input: EvaluatePreInvocationGateInput,
    invoke: Callable[[], Awaitable[T]],
    options: WithGovernanceGateOptions | None = None,
) -> WithGovernanceGateResult[T]:
    """Evaluate the governance gate and optionally invoke a function."""
    opts = options or WithGovernanceGateOptions()
    warnings: list[str] = []

    telemetry_platform = _resolve_telemetry_platform(source, opts.telemetry)
    telemetry_enabled = opts.telemetry.enabled if opts.telemetry is not None else True

    decision = await evaluate_pre_invocation_gate(source, input, opts)

    if telemetry_enabled and telemetry_platform is not None:
        await _report_gate_event(
            telemetry_platform,
            warnings,
            {
                "run_id": decision.run_id,
                "event_type": "governance.gate.evaluated",
                "actor": input.actor,
                "action": "evaluate",
                "resource": {
                    "type": "governance_gate",
                    "id": input.model or "pre-invocation",
                },
                "metadata": {
                    "decision": decision.decision,
                    "hasPii": decision.pii.has_pii,
                    "piiFindingsCount": len(decision.pii.findings),
                    "timings": {
                        "scan_ms": decision.metadata.timings.scan_ms
                        if decision.metadata.timings
                        else None,
                        "policy_eval_ms": decision.metadata.timings.policy_eval_ms
                        if decision.metadata.timings
                        else None,
                        "total_ms": decision.metadata.timings.total_ms
                        if decision.metadata.timings
                        else None,
                    },
                    "codes": decision.codes,
                    "reasons": decision.reasons,
                },
            },
        )

    if decision.decision == "deny":
        if telemetry_enabled and telemetry_platform is not None:
            await _report_gate_event(
                telemetry_platform,
                warnings,
                {
                    "run_id": decision.run_id,
                    "event_type": "governance.gate.outcome",
                    "actor": input.actor,
                    "action": "blocked",
                    "resource": {
                        "type": "governance_gate",
                        "id": input.model or "pre-invocation",
                    },
                    "metadata": {
                        "outcome": "blocked",
                        "invoked": False,
                        "decision": decision.decision,
                        "timings": {
                            "scan_ms": decision.metadata.timings.scan_ms
                            if decision.metadata.timings
                            else None,
                            "policy_eval_ms": decision.metadata.timings.policy_eval_ms
                            if decision.metadata.timings
                            else None,
                            "total_ms": decision.metadata.timings.total_ms
                            if decision.metadata.timings
                            else None,
                        },
                    },
                },
            )

        if opts.deny_mode == "return":
            return WithGovernanceGateResult(
                run_id=decision.run_id,
                invoked=False,
                decision=decision,
                warnings=warnings if len(warnings) > 0 else None,
            )

        raise GovernanceGateDeniedError(
            run_id=decision.run_id,
            reasons=decision.reasons,
            decision=decision,
        )

    try:
        result = await invoke()
        if telemetry_enabled and telemetry_platform is not None:
            await _report_gate_event(
                telemetry_platform,
                warnings,
                {
                    "run_id": decision.run_id,
                    "event_type": "governance.gate.outcome",
                    "actor": input.actor,
                    "action": "allowed",
                    "resource": {
                        "type": "governance_gate",
                        "id": input.model or "pre-invocation",
                    },
                    "metadata": {
                        "outcome": "allowed",
                        "invoked": True,
                        "decision": decision.decision,
                        "timings": {
                            "scan_ms": decision.metadata.timings.scan_ms
                            if decision.metadata.timings
                            else None,
                            "policy_eval_ms": decision.metadata.timings.policy_eval_ms
                            if decision.metadata.timings
                            else None,
                            "total_ms": decision.metadata.timings.total_ms
                            if decision.metadata.timings
                            else None,
                        },
                    },
                },
            )

        return WithGovernanceGateResult(
            run_id=decision.run_id,
            invoked=True,
            decision=decision,
            result=result,
            warnings=warnings if len(warnings) > 0 else None,
        )
    except Exception as error:
        if telemetry_enabled and telemetry_platform is not None:
            await _report_gate_event(
                telemetry_platform,
                warnings,
                {
                    "run_id": decision.run_id,
                    "event_type": "governance.gate.outcome",
                    "actor": input.actor,
                    "action": "error",
                    "resource": {
                        "type": "governance_gate",
                        "id": input.model or "pre-invocation",
                    },
                    "metadata": {
                        "outcome": "error",
                        "invoked": True,
                        "decision": decision.decision,
                        "error": str(error),
                        "timings": {
                            "scan_ms": decision.metadata.timings.scan_ms
                            if decision.metadata.timings
                            else None,
                            "policy_eval_ms": decision.metadata.timings.policy_eval_ms
                            if decision.metadata.timings
                            else None,
                            "total_ms": decision.metadata.timings.total_ms
                            if decision.metadata.timings
                            else None,
                        },
                    },
                },
            )

        raise
