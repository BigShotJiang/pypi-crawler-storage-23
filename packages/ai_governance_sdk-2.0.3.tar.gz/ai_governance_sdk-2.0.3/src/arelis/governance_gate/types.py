"""Governance gate types for the Arelis AI SDK.

Ports governance gate types from ``packages/sdk/src/governance-gate.ts``
in the TypeScript SDK.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, Literal, Protocol, TypeVar, runtime_checkable

from arelis.core.types import ActorRef, GovernanceContext

__all__ = [
    "EvaluatePreInvocationGateInput",
    "GovernanceGateClient",
    "GovernanceGateDecisionTimings",
    "GovernanceGateDeniedMode",
    "GovernanceGateEvaluatePolicyInput",
    "GovernanceGateEvaluator",
    "GovernanceGatePolicyData",
    "GovernanceGatePlatform",
    "GovernanceGateSource",
    "GovernanceGateTelemetryOptions",
    "PolicyDecision",
    "PolicyResult",
    "PolicyResultSummary",
    "PolicySummaryInfo",
    "PreInvocationGateDecision",
    "PreInvocationGateMetadata",
    "PromptPiiFinding",
    "PromptPiiScanResult",
    "ScanPromptForPiiOptions",
    "WithGovernanceGateOptions",
    "WithGovernanceGateResult",
]

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

GovernanceGateDeniedMode = Literal["throw", "return"]
"""Mode for handling governance gate denials."""

PolicyCheckpoint = Literal[
    "BeforeOperation",
    "BeforePrompt",
    "AfterModelOutput",
    "BeforeToolCall",
    "AfterToolResult",
    "BeforePersist",
    "BeforeProvision",
    "BeforeDestroy",
    "BeforeConfigChange",
    "BeforeAuth",
    "BeforeAgentStep",
]
"""Policy checkpoint types."""

# ---------------------------------------------------------------------------
# Policy types (minimal, for governance gate use)
# ---------------------------------------------------------------------------


@dataclass
class PolicyDecision:
    """A single policy decision.

    Attributes:
        effect: The effect of the decision.
        reason: Reason for block/transform/require_approval.
        code: Machine-readable code for block decisions.
        approvers: Required approvers for require_approval decisions.
    """

    effect: Literal["allow", "block", "transform", "require_approval"]
    reason: str | None = None
    code: str | None = None
    approvers: list[str] | None = None


@dataclass
class PolicyResultSummary:
    """Summary of a policy evaluation.

    Attributes:
        allowed: Whether the request is allowed.
        block_reason: Primary reason if blocked.
        block_code: Block code if blocked.
        approvers: Approvers required if approval needed.
    """

    allowed: bool
    block_reason: str | None = None
    block_code: str | None = None
    approvers: list[str] | None = None


@dataclass
class PolicyResult:
    """Result of a policy evaluation.

    Attributes:
        decisions: All decisions made.
        summary: Summary of the evaluation.
        policy_version: Policy version or identifier.
    """

    decisions: list[PolicyDecision]
    summary: PolicyResultSummary
    policy_version: str | None = None


# ---------------------------------------------------------------------------
# PII types
# ---------------------------------------------------------------------------


@dataclass
class PromptPiiFinding:
    """A PII finding in a prompt.

    Attributes:
        type: Type of sensitive data found.
        original: Original value that was found.
        start: Start index in the text.
        end: End index in the text.
        pattern: Pattern name that matched, if any.
    """

    type: Literal["email", "phone", "ssn", "credit_card", "api_key", "custom"]
    original: str
    start: int
    end: int
    pattern: str | None = None


@dataclass
class PromptPiiScanResult:
    """Result of scanning a prompt for PII.

    Attributes:
        has_pii: Whether PII was found.
        findings: List of PII findings.
    """

    has_pii: bool
    findings: list[PromptPiiFinding] = field(default_factory=list)


@dataclass
class ScanPromptForPiiOptions:
    """Options for PII scanning.

    Attributes:
        redactor: An existing Redactor instance to use for scanning.
            Typed as ``object`` to avoid circular imports; at runtime this
            should be a ``arelis.policy.redactor.Redactor``.
        redactor_config: Configuration to create a Redactor.
            Typed as ``object`` to avoid circular imports; at runtime this
            should be a ``arelis.policy.redactor.RedactorConfig``.
        detect_emails: Whether to detect email addresses (legacy regex fallback).
        detect_phones: Whether to detect phone numbers (legacy regex fallback).
        detect_ssns: Whether to detect SSNs (legacy regex fallback).
        detect_credit_cards: Whether to detect credit card numbers (legacy regex fallback).
    """

    redactor: object | None = None
    redactor_config: object | None = None
    detect_emails: bool = True
    detect_phones: bool = True
    detect_ssns: bool = True
    detect_credit_cards: bool = True


# ---------------------------------------------------------------------------
# Governance gate policy data
# ---------------------------------------------------------------------------


@dataclass
class GovernanceGatePolicyData:
    """Data passed to the policy engine during governance gate evaluation.

    Attributes:
        model_id: Model identifier, if applicable.
        provider: Provider name, if applicable.
        input: Input content.
        output: Output content.
        tool_name: Tool name, if applicable.
        tool_args: Tool arguments, if applicable.
        tool_result: Tool result, if applicable.
    """

    model_id: str | None = None
    provider: str | None = None
    input: object | None = None
    output: object | None = None
    tool_name: str | None = None
    tool_args: dict[str, object] | None = None
    tool_result: object | None = None


# ---------------------------------------------------------------------------
# GovernanceGateEvaluatePolicyInput
# ---------------------------------------------------------------------------


@dataclass
class GovernanceGateEvaluatePolicyInput:
    """Input for evaluating policy in the governance gate.

    Attributes:
        checkpoint: Policy checkpoint.
        run_id: Run ID.
        context: Governance context.
        data: Policy data to evaluate.
    """

    checkpoint: PolicyCheckpoint
    run_id: str
    context: GovernanceContext
    data: GovernanceGatePolicyData
    policy_ids: list[str] | None = None


# ---------------------------------------------------------------------------
# GovernanceGateEvaluator protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class GovernanceGateEvaluator(Protocol):
    """Protocol for governance gate evaluators."""

    async def resolve_context(self, partial: GovernanceContext | None = None) -> GovernanceContext:
        """Resolve a (possibly partial) governance context."""
        ...

    async def evaluate_policy(self, input: GovernanceGateEvaluatePolicyInput) -> PolicyResult:
        """Evaluate policy for the given input."""
        ...

    def get_policy_metadata(self) -> dict[str, str | None] | None:
        """Get policy metadata (snapshot hash, compiler ID).

        Returns:
            Dictionary with optional ``policy_snapshot_hash`` and
            ``policy_compiler_id`` keys, or None.
        """
        ...


# ---------------------------------------------------------------------------
# GovernanceGateClient protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class GovernanceGateClient(Protocol):
    """Protocol for clients that provide governance gate evaluators."""

    class _GovernanceNamespace(Protocol):
        def create_gate_evaluator(self) -> GovernanceGateEvaluator: ...

    @property
    def governance(self) -> _GovernanceNamespace: ...


@runtime_checkable
class GovernanceGatePlatform(Protocol):
    """Protocol for platform-backed governance evaluation and telemetry."""

    class _EventsNamespace(Protocol):
        def create(self, event: dict[str, object]) -> object: ...

    class _GovernanceNamespace(Protocol):
        def evaluatePolicy(  # noqa: N802
            self, payload: dict[str, object]
        ) -> object: ...

    @property
    def events(self) -> _EventsNamespace: ...

    @property
    def governance(self) -> _GovernanceNamespace: ...


# Union type for governance gate source
GovernanceGateSource = GovernanceGateEvaluator | GovernanceGateClient | GovernanceGatePlatform
"""Source for governance gate evaluation: either a client or an evaluator."""


# ---------------------------------------------------------------------------
# EvaluatePreInvocationGateInput
# ---------------------------------------------------------------------------


@dataclass
class EvaluatePreInvocationGateInput:
    """Input for evaluating the pre-invocation governance gate.

    Attributes:
        prompt: The prompt to evaluate.
        actor: Actor performing the action.
        run_id: Optional run ID.
        policy_ids: Optional policy IDs to include as metadata.
        model: Optional model identifier.
        context: Optional partial governance context.
    """

    prompt: str
    actor: ActorRef
    run_id: str | None = None
    policy_ids: list[str] | None = None
    model: str | None = None
    context: GovernanceContext | None = None


# ---------------------------------------------------------------------------
# PreInvocationGateMetadata
# ---------------------------------------------------------------------------


@dataclass
class PreInvocationGateMetadata:
    """Metadata from the governance gate evaluation.

    Attributes:
        policy_ids: Policy IDs evaluated.
        policy_ids_mode: Mode for policy IDs (always 'metadata_only').
        actor: Actor who triggered the gate.
        model: Model identifier, if applicable.
        policy_snapshot_hash: Policy snapshot hash, if available.
        policy_compiler_id: Policy compiler ID, if available.
    """

    policy_ids: list[str]
    policy_ids_mode: Literal["metadata_only"]
    actor: ActorRef
    model: str | None = None
    policy_snapshot_hash: str | None = None
    policy_compiler_id: str | None = None
    timings: GovernanceGateDecisionTimings | None = None


@dataclass
class GovernanceGateDecisionTimings:
    """Timing diagnostics captured during gate evaluation."""

    scan_ms: float
    policy_eval_ms: float
    total_ms: float


# ---------------------------------------------------------------------------
# PolicySummaryInfo (for the decision's policy field)
# ---------------------------------------------------------------------------


@dataclass
class PolicySummaryInfo:
    """Policy summary within a gate decision.

    Attributes:
        allowed: Whether the policy allowed the request.
        decisions: All policy decisions.
        summary: Policy result summary.
        policy_version: Policy version, if available.
    """

    allowed: bool
    decisions: list[PolicyDecision]
    summary: PolicyResultSummary
    policy_version: str | None = None


# ---------------------------------------------------------------------------
# PreInvocationGateDecision
# ---------------------------------------------------------------------------


@dataclass
class PreInvocationGateDecision:
    """Decision from the pre-invocation governance gate.

    Attributes:
        run_id: Run ID for the evaluation.
        decision: Allow or deny.
        pii: PII scan result.
        policy: Policy evaluation summary.
        metadata: Gate metadata.
        reasons: Human-readable reasons for denial.
        codes: Machine-readable denial codes.
    """

    run_id: str
    decision: Literal["allow", "deny"]
    pii: PromptPiiScanResult
    policy: PolicySummaryInfo
    metadata: PreInvocationGateMetadata
    reasons: list[str] = field(default_factory=list)
    codes: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# WithGovernanceGateOptions
# ---------------------------------------------------------------------------


@dataclass
class WithGovernanceGateOptions(ScanPromptForPiiOptions):
    """Options for :func:`with_governance_gate`.

    Extends :class:`ScanPromptForPiiOptions` with deny mode.

    Attributes:
        deny_mode: How to handle denial ('throw' or 'return').
    """

    deny_mode: GovernanceGateDeniedMode = "throw"
    telemetry: GovernanceGateTelemetryOptions | None = None


@dataclass
class GovernanceGateTelemetryOptions:
    """Best-effort platform telemetry settings for gate evaluation."""

    enabled: bool = True
    platform: GovernanceGatePlatform | None = None
    api_key: str | None = None
    base_url: str | None = None


# ---------------------------------------------------------------------------
# WithGovernanceGateResult
# ---------------------------------------------------------------------------


@dataclass
class WithGovernanceGateResult(Generic[T]):
    """Result of invoking a function through the governance gate.

    Attributes:
        run_id: Run ID for the evaluation.
        invoked: Whether the function was actually invoked.
        decision: The gate decision.
        result: The function result, if invoked.
    """

    run_id: str
    invoked: bool
    decision: PreInvocationGateDecision
    result: T | None = None
    warnings: list[str] | None = None
