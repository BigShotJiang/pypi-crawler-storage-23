"""Governance gate module for the Arelis AI SDK.

Provides pre-invocation governance gate evaluation with PII scanning,
policy enforcement, and configurable deny modes.
"""

from __future__ import annotations

from arelis.governance_gate.evaluator import (
    SimpleGovernanceGateEvaluator,
    create_governance_gate_evaluator,
)
from arelis.governance_gate.gate import (
    evaluate_pre_invocation_gate,
    with_governance_gate,
)
from arelis.governance_gate.pii import scan_prompt_for_pii
from arelis.governance_gate.types import (
    EvaluatePreInvocationGateInput,
    GovernanceGateClient,
    GovernanceGateDecisionTimings,
    GovernanceGateDeniedMode,
    GovernanceGateEvaluatePolicyInput,
    GovernanceGateEvaluator,
    GovernanceGatePlatform,
    GovernanceGatePolicyData,
    GovernanceGateSource,
    GovernanceGateTelemetryOptions,
    PolicyCheckpoint,
    PolicyDecision,
    PolicyResult,
    PolicyResultSummary,
    PolicySummaryInfo,
    PreInvocationGateDecision,
    PreInvocationGateMetadata,
    PromptPiiFinding,
    PromptPiiScanResult,
    ScanPromptForPiiOptions,
    WithGovernanceGateOptions,
    WithGovernanceGateResult,
)

__all__ = [
    "EvaluatePreInvocationGateInput",
    "GovernanceGateClient",
    "GovernanceGateDecisionTimings",
    "GovernanceGateDeniedMode",
    "GovernanceGateEvaluatePolicyInput",
    "GovernanceGateEvaluator",
    "GovernanceGatePolicyData",
    "GovernanceGatePlatform",
    "GovernanceGateSource",
    "GovernanceGateTelemetryOptions",
    "PolicyCheckpoint",
    "PolicyDecision",
    "PolicyResult",
    "PolicyResultSummary",
    "PolicySummaryInfo",
    "PreInvocationGateDecision",
    "PreInvocationGateMetadata",
    "PromptPiiFinding",
    "PromptPiiScanResult",
    "ScanPromptForPiiOptions",
    "SimpleGovernanceGateEvaluator",
    "WithGovernanceGateOptions",
    "WithGovernanceGateResult",
    "create_governance_gate_evaluator",
    "evaluate_pre_invocation_gate",
    "scan_prompt_for_pii",
    "with_governance_gate",
]
