"""Governance gate evaluator for the Arelis AI SDK.

Ports the ``createGovernanceGateEvaluator`` factory from
``packages/sdk/src/governance-gate.ts`` in the TypeScript SDK.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from arelis.core.run_context import default_context_resolver
from arelis.core.types import GovernanceContext
from arelis.governance_gate.types import (
    GovernanceGateEvaluatePolicyInput,
    PolicyResult,
)

__all__ = [
    "SimpleGovernanceGateEvaluator",
    "create_governance_gate_evaluator",
]


# ---------------------------------------------------------------------------
# Concrete evaluator
# ---------------------------------------------------------------------------


class SimpleGovernanceGateEvaluator:
    """Simple governance gate evaluator wrapping user-provided callables.

    This class is returned by :func:`create_governance_gate_evaluator` and
    implements the :class:`GovernanceGateEvaluator` protocol.
    """

    def __init__(
        self,
        *,
        evaluate_policy: Callable[[GovernanceGateEvaluatePolicyInput], Awaitable[PolicyResult]],
        resolve_context: Callable[[GovernanceContext | None], Awaitable[GovernanceContext]]
        | None = None,
        get_policy_metadata: Callable[[], dict[str, str | None] | None] | None = None,
    ) -> None:
        self._evaluate_policy = evaluate_policy
        self._resolve_context = resolve_context or default_context_resolver
        self._get_policy_metadata = get_policy_metadata

    async def resolve_context(self, partial: GovernanceContext | None = None) -> GovernanceContext:
        """Resolve a (possibly partial) governance context."""
        return await self._resolve_context(partial)

    async def evaluate_policy(self, input: GovernanceGateEvaluatePolicyInput) -> PolicyResult:
        """Evaluate policy for the given input."""
        return await self._evaluate_policy(input)

    def get_policy_metadata(self) -> dict[str, str | None] | None:
        """Get policy metadata."""
        if self._get_policy_metadata is not None:
            return self._get_policy_metadata()
        return None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_governance_gate_evaluator(
    *,
    evaluate_policy: Callable[[GovernanceGateEvaluatePolicyInput], Awaitable[PolicyResult]],
    resolve_context: Callable[[GovernanceContext | None], Awaitable[GovernanceContext]]
    | None = None,
    get_policy_metadata: Callable[[], dict[str, str | None] | None] | None = None,
) -> SimpleGovernanceGateEvaluator:
    """Create a governance gate evaluator from handler functions.

    Args:
        evaluate_policy: Async function to evaluate policy.
        resolve_context: Optional async function to resolve governance context.
            Defaults to :func:`~arelis.core.run_context.default_context_resolver`.
        get_policy_metadata: Optional function returning policy metadata.

    Returns:
        A :class:`SimpleGovernanceGateEvaluator` instance.
    """
    return SimpleGovernanceGateEvaluator(
        evaluate_policy=evaluate_policy,
        resolve_context=resolve_context,
        get_policy_metadata=get_policy_metadata,
    )
