# Tasks: SDK Parity Fixes

## Relevant Files

### Core Changes
- `src/arelis/__init__.py` — Top-level exports (FR-5)
- `src/arelis/client.py` — Client method signatures (FR-1)
- `src/arelis/config.py` — ClientConfig fields (FR-11)
- `src/arelis/core/__init__.py` — Core module exports (FR-5)

### Models & Providers
- `src/arelis/models/provider.py` — Multi-modal provider protocols (FR-2)
- `src/arelis/models/types.py` — Multi-modal types already defined here (FR-2 reference)
- `src/arelis/models/__init__.py` — Models module exports (FR-5)
- `src/arelis/providers/google_vertex/provider.py` — Vertex embeddings (FR-10)
- `src/arelis/providers/google_vertex/embeddings.py` — New: Vertex embed function (FR-10)
- `src/arelis/providers/google_vertex/__init__.py` — Vertex module exports (FR-10)

### Policy & Governance
- `src/arelis/governance_gate/pii.py` — PII/Redactor integration (FR-7)
- `src/arelis/governance_gate/types.py` — PII options types (FR-7)
- `src/arelis/governance_gate/gate.py` — GovernanceGateDeniedError enhancement (FR-14)
- `src/arelis/governance_gate/__init__.py` — Governance gate exports (FR-7, FR-14)

### Agents
- `src/arelis/agents/runtime.py` — Agent governance integration (FR-3)
- `src/arelis/agents/types.py` — Agent runtime options (FR-3)
- `src/arelis/agents/__init__.py` — Agent module exports (FR-3)

### Audit & Compliance
- `src/arelis/audit/cag.py` — Missing CAG function (FR-9)
- `src/arelis/audit/__init__.py` — Audit module exports (FR-9)
- `src/arelis/compliance/types.py` — DisclosureProof field naming (FR-8)
- `src/arelis/compliance/verification.py` — Compliance implementation (FR-4)
- `src/arelis/compliance/__init__.py` — Compliance module exports (FR-4, FR-8)

### MCP
- `src/arelis/mcp/transports/http.py` — HTTP transport implementation (FR-6)
- `src/arelis/mcp/types.py` — MCP input types (FR-1)
- `src/arelis/mcp/__init__.py` — MCP module exports (FR-1)

### Memory, Data Sources, Approvals, Secrets
- `src/arelis/memory/types.py` — Memory input types (FR-1)
- `src/arelis/memory/__init__.py` — Memory module exports (FR-1)
- `src/arelis/data_sources/types.py` — DataSource input types (FR-1)
- `src/arelis/data_sources/__init__.py` — DataSource module exports (FR-1)
- `src/arelis/core/approval_store.py` — Approval input types (FR-1)
- `src/arelis/secrets/resolver.py` — Secret resolution return type (FR-12)
- `src/arelis/secrets/types.py` — Secret resolution result type (FR-12)
- `src/arelis/secrets/__init__.py` — Secrets module exports (FR-12)

### Extensions
- `src/arelis/extensions/contracts.py` — Capability flag derivation (FR-15)
- `src/arelis/extensions/types.py` — ExtensionCapabilityFlag type (FR-15)

### Tests
- `tests/unit/test_client.py` — Client method tests (FR-1)
- `tests/unit/models/test_provider.py` — New: Provider protocol tests (FR-2)
- `tests/unit/agents/test_runtime.py` — Agent governance tests (FR-3)
- `tests/unit/compliance/test_verification.py` — New: Compliance tests (FR-13)
- `tests/unit/compliance/test_types.py` — New: Compliance type tests (FR-13)
- `tests/unit/mcp/test_http_transport.py` — New: HTTP transport tests (FR-6)
- `tests/unit/governance_gate/test_pii.py` — Updated PII tests (FR-7)
- `tests/unit/audit/test_cag.py` — CAG function tests (FR-9)
- `tests/unit/secrets/test_resolver.py` — Updated resolver tests (FR-12)
- `tests/unit/storage/test_postgres_audit.py` — New: Storage unit tests (FR-13)
- `tests/unit/storage/test_postgres_memory.py` — New: Storage unit tests (FR-13)
- `tests/unit/extensions/test_contracts.py` — New: Capability derivation tests (FR-15)

### Reference (TypeScript SDK — read-only)
- `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/client.ts` — Client signatures reference
- `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/index.ts` — Public exports reference
- `/Users/ramon.marrero/arelis-sdk/packages/models/src/model-provider.ts` — Multi-modal protocols reference
- `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/agent-runtime.ts` — Agent governance reference
- `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/compliance.ts` — Compliance reference
- `/Users/ramon.marrero/arelis-sdk/packages/mcp/src/transports/http.ts` — HTTP transport reference
- `/Users/ramon.marrero/arelis-sdk/packages/governance/src/governance-gate.ts` — PII/Redactor reference
- `/Users/ramon.marrero/arelis-sdk/packages/providers-google-vertex/src/embeddings.ts` — Vertex embeddings reference
- `/Users/ramon.marrero/arelis-sdk/packages/governance/src/redactor.ts` — Redactor interface reference

---

## Notes

- **Dependency order:** Tasks 1, 2, 3, 4 are independent and can be parallelized. Task 5 depends on 1 (needs the new input types to export). Task 16 depends on all other tasks.
- **TypeScript SDK is source of truth:** Always read the corresponding TS source before implementing. Adapt naming to Python conventions (camelCase -> snake_case).
- **Backward compatibility:** For FR-1 (client method signatures), consider keeping kwargs as a fallback with deprecation warnings during transition.
- **Test strategy:** Each implementation task should include updating or adding tests for the changed module. Task 13 covers modules that need tests independent of other changes.

---

## Tasks

### 0.0 Create feature branch
- [x] 0.1 Run `git checkout main && git pull` to ensure latest main
- [x] 0.2 Create branch: `git checkout -b fix/sdk-parity-fixes`

---

### 1.0 Create input dataclasses for client methods (FR-1) [Critical]

#### 1.1 Define MCP input dataclasses
- [x] 1.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/client.ts` lines for MCP namespace to confirm exact field names and types
- [x] 1.1.2 In `src/arelis/mcp/types.py`, add `RegisterMCPServerInput` dataclass with fields: `server: MCPServerDescriptor`, `context: GovernanceContext | None = None`, `discovery_options: ToolDiscoveryOptions | None = None`
- [x] 1.1.3 In `src/arelis/mcp/types.py`, add `DiscoverMCPToolsInput` dataclass with fields: `server_id: str`, `context: GovernanceContext | None = None`, `options: ToolDiscoveryOptions | None = None`
- [x] 1.1.4 Export both types from `src/arelis/mcp/__init__.py`

#### 1.2 Define Knowledge input dataclasses
- [x] 1.2.1 In `src/arelis/knowledge/types.py`, add `RegisterKBInput` dataclass with fields: `kb: KnowledgeBaseDescriptor`, `context: GovernanceContext | None = None`
- [x] 1.2.2 In `src/arelis/knowledge/types.py`, add `RetrieveInput` dataclass with fields: `kb_id: str`, `query: RetrievalQuery`, `context: GovernanceContext | None = None`, `options: RetrievalOptions | None = None`
- [x] 1.2.3 In `src/arelis/knowledge/types.py`, add `RetrievalOptions` dataclass if not already present (check TS for fields)
- [x] 1.2.4 Export types from `src/arelis/knowledge/__init__.py`

#### 1.3 Define Memory input dataclasses
- [x] 1.3.1 In `src/arelis/memory/types.py`, add `MemoryReadInput` dataclass with fields: `scope: MemoryScope`, `key: str`, `context: GovernanceContext | None = None`, `provider_id: str | None = None`
- [x] 1.3.2 In `src/arelis/memory/types.py`, add `MemoryWriteInput` dataclass with fields: `scope: MemoryScope`, `key: str`, `value: object`, `context: GovernanceContext | None = None`, `provider_id: str | None = None`, `metadata: dict[str, object] | None = None`
- [x] 1.3.3 In `src/arelis/memory/types.py`, add `MemoryDeleteInput` dataclass with fields: `scope: MemoryScope`, `key: str`, `context: GovernanceContext | None = None`, `provider_id: str | None = None`
- [x] 1.3.4 Export types from `src/arelis/memory/__init__.py`

#### 1.4 Define DataSource input dataclasses
- [x] 1.4.1 In `src/arelis/data_sources/types.py`, add `DataSourceRegisterInput` dataclass with fields: `descriptor: DataSourceDescriptor`, `provider: DataSourceProvider`, `context: GovernanceContext | None = None`
- [x] 1.4.2 In `src/arelis/data_sources/types.py`, add `DataSourceReadInput` dataclass with fields: `source_id: str`, `query: str`, `context: GovernanceContext | None = None`, `metadata: dict[str, object] | None = None`
- [x] 1.4.3 Export types from `src/arelis/data_sources/__init__.py`

#### 1.5 Define Approval input dataclass
- [x] 1.5.1 In `src/arelis/core/approval_store.py`, add `ApprovalResolveInput` dataclass with fields: `approval_id: str`, `resolved_by: str`, `reason: str | None = None`, `context: GovernanceContext | None = None`
- [x] 1.5.2 Export type from `src/arelis/core/__init__.py`

#### 1.6 Add missing fields to GenerateInput and GenerateStreamInput
- [x] 1.6.1 Read `src/arelis/models/types.py` to find existing `GenerateInput` definition
- [x] 1.6.2 Add `grounding: GroundingInput | None = None` field to `GenerateInput`
- [x] 1.6.3 Add `output_schema: OutputSchema | None = None` field to `GenerateInput`
- [x] 1.6.4 Add `output_validation_mode: OutputValidationMode | None = None` field to `GenerateInput`
- [x] 1.6.5 Add `evaluators: list[object] | None = None` field to `GenerateInput`
- [x] 1.6.6 Define `StreamOptions` dataclass with fields: `emit_chunks: bool = True`, `abort_on_sensitive: bool = False`
- [x] 1.6.7 Add `stream_options: StreamOptions | None = None` field to `GenerateStreamInput`

#### 1.7 Refactor client methods to accept input objects
- [x] 1.7.1 Refactor `_MCPNamespace.register_server()` in `client.py` to accept `RegisterMCPServerInput` and return `ToolDiscoveryFullResult`
- [x] 1.7.2 Refactor `_MCPNamespace.discover_tools()` in `client.py` to accept `DiscoverMCPToolsInput`
- [x] 1.7.3 Refactor `_KnowledgeNamespace.register_kb()` in `client.py` to accept `RegisterKBInput`
- [x] 1.7.4 Refactor `_KnowledgeNamespace.retrieve()` in `client.py` to accept `RetrieveInput`
- [x] 1.7.5 Refactor `_MemoryNamespace.read()` in `client.py` to accept `MemoryReadInput`
- [x] 1.7.6 Refactor `_MemoryNamespace.write()` in `client.py` to accept `MemoryWriteInput`
- [x] 1.7.7 Refactor `_MemoryNamespace.delete()` in `client.py` to accept `MemoryDeleteInput`
- [x] 1.7.8 Refactor `_MemoryNamespace.list()` in `client.py` — keep `(scope, context)` positional params (matches TS)
- [x] 1.7.9 Refactor `_DataSourcesNamespace.register()` in `client.py` to accept `DataSourceRegisterInput`
- [x] 1.7.10 Refactor `_DataSourcesNamespace.read()` in `client.py` to accept `DataSourceReadInput`
- [x] 1.7.11 Refactor `_ApprovalsNamespace.approve()` in `client.py` to accept `ApprovalResolveInput` and return `None`
- [x] 1.7.12 Refactor `_ApprovalsNamespace.reject()` in `client.py` to accept `ApprovalResolveInput` and return `None`
- [x] 1.7.13 Fix `_ComplianceNamespace.request_artifact()` return type to `ComplianceArtifact | ProofJob`
- [x] 1.7.14 Fix `_ModelsNamespace.generate_stream()` return type to typed dataclass with `run_id: str` and `stream: AsyncIterator[StreamChunk]`

#### 1.8 Update client tests
- [x] 1.8.1 Update `tests/unit/test_client.py` to use new input objects for all refactored methods
- [x] 1.8.2 Add tests verifying correct parameter unpacking from input objects
- [x] 1.8.3 Add tests for new fields (grounding, output_schema, stream_options)

#### 1.9 Update example scripts
- [x] 1.9.1 Review all example scripts in `examples/` and update any that use kwargs to use input objects
- [x] 1.9.2 Ensure examples still run without errors after refactoring

---

### 2.0 Add multi-modal provider protocols and guard functions (FR-2) [Critical]

#### 2.1 Define multi-modal response/input types
- [x] 2.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/models/src/model-provider.ts` for exact type definitions
- [x] 2.1.2 In `src/arelis/models/types.py`, verify or add: `ImageGenerationOptions`, `ImageGenerationResponse`, `AudioGenerationOptions`, `AudioGenerationResponse`, `VideoGenerationOptions`, `VideoGenerationResponse`
- [x] 2.1.3 In `src/arelis/models/types.py`, verify or add: `ImageInput`, `AudioInput`, `VideoInput` (media input types)
- [x] 2.1.4 In `src/arelis/models/types.py`, verify or add: `ImageToTextOptions`, `TextFromImageResponse`, `ImageToAudioOptions`, `AudioFromImageResponse`, `ImageToVideoOptions`, `VideoFromImageResponse`
- [x] 2.1.5 In `src/arelis/models/types.py`, verify or add: `AudioToTextOptions`, `TextFromAudioResponse`, `AudioToImageOptions`, `ImageFromAudioResponse`, `AudioToVideoOptions`, `VideoFromAudioResponse`
- [x] 2.1.6 In `src/arelis/models/types.py`, verify or add: `VideoToTextOptions`, `TextFromVideoResponse`, `VideoToImageOptions`, `ImageFromVideoResponse`, `VideoToAudioOptions`, `AudioFromVideoResponse`

#### 2.2 Add provider protocol classes
- [x] 2.2.1 In `src/arelis/models/provider.py`, add `ImageGenerationProvider` protocol with `async def generate_image(self, prompt: str, options: ImageGenerationOptions | None = None) -> ImageGenerationResponse`
- [x] 2.2.2 Add `AudioGenerationProvider` protocol with `async def generate_audio(self, prompt: str, options: AudioGenerationOptions | None = None) -> AudioGenerationResponse`
- [x] 2.2.3 Add `VideoGenerationProvider` protocol with `async def generate_video(self, prompt: str, options: VideoGenerationOptions | None = None) -> VideoGenerationResponse`
- [x] 2.2.4 Add `ImageToTextProvider` protocol with `async def image_to_text(self, input: ImageInput, options: ImageToTextOptions | None = None) -> TextFromImageResponse`
- [x] 2.2.5 Add `ImageToAudioProvider` protocol with `async def image_to_audio(self, input: ImageInput, options: ImageToAudioOptions | None = None) -> AudioFromImageResponse`
- [x] 2.2.6 Add `ImageToVideoProvider` protocol with `async def image_to_video(self, input: ImageInput, options: ImageToVideoOptions | None = None) -> VideoFromImageResponse`
- [x] 2.2.7 Add `AudioToTextProvider` protocol with `async def audio_to_text(self, input: AudioInput, options: AudioToTextOptions | None = None) -> TextFromAudioResponse`
- [x] 2.2.8 Add `AudioToImageProvider` protocol with `async def audio_to_image(self, input: AudioInput, options: AudioToImageOptions | None = None) -> ImageFromAudioResponse`
- [x] 2.2.9 Add `AudioToVideoProvider` protocol with `async def audio_to_video(self, input: AudioInput, options: AudioToVideoOptions | None = None) -> VideoFromAudioResponse`
- [x] 2.2.10 Add `VideoToTextProvider` protocol with `async def video_to_text(self, input: VideoInput, options: VideoToTextOptions | None = None) -> TextFromVideoResponse`
- [x] 2.2.11 Add `VideoToImageProvider` protocol with `async def video_to_image(self, input: VideoInput, options: VideoToImageOptions | None = None) -> ImageFromVideoResponse`
- [x] 2.2.12 Add `VideoToAudioProvider` protocol with `async def video_to_audio(self, input: VideoInput, options: VideoToAudioOptions | None = None) -> AudioFromVideoResponse`

#### 2.3 Add guard functions and helper
- [x] 2.3.1 Add `has_capability_flag(provider: ModelProvider, flag: str) -> bool | None` helper function
- [x] 2.3.2 Add `supports_image_generation(provider: ModelProvider) -> bool` — checks `isinstance(provider, ImageGenerationProvider)` or `has_capability_flag`
- [x] 2.3.3 Add `supports_audio_generation(provider: ModelProvider) -> bool`
- [x] 2.3.4 Add `supports_video_generation(provider: ModelProvider) -> bool`
- [x] 2.3.5 Add `supports_image_to_text(provider: ModelProvider) -> bool`
- [x] 2.3.6 Add `supports_image_to_audio(provider: ModelProvider) -> bool`
- [x] 2.3.7 Add `supports_image_to_video(provider: ModelProvider) -> bool`
- [x] 2.3.8 Add `supports_audio_to_text(provider: ModelProvider) -> bool`
- [x] 2.3.9 Add `supports_audio_to_image(provider: ModelProvider) -> bool`
- [x] 2.3.10 Add `supports_audio_to_video(provider: ModelProvider) -> bool`
- [x] 2.3.11 Add `supports_video_to_text(provider: ModelProvider) -> bool`
- [x] 2.3.12 Add `supports_video_to_image(provider: ModelProvider) -> bool`
- [x] 2.3.13 Add `supports_video_to_audio(provider: ModelProvider) -> bool`

#### 2.4 Update exports and tests
- [x] 2.4.1 Export all new protocols and guard functions from `src/arelis/models/__init__.py`
- [x] 2.4.2 Create `tests/unit/models/test_provider.py` with tests for each protocol (duck-typing checks) and guard function
- [x] 2.4.3 Test `has_capability_flag()` with providers that do and don't have the flag

---

### 3.0 Integrate governance into agent runtime (FR-3) [Critical]

#### 3.1 Update agent types
- [x] 3.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/agent-runtime.ts` to confirm exact governance fields
- [x] 3.1.2 In `src/arelis/agents/types.py`, add to `AgentRuntimeOptions` (or equivalent config type): `policy_engine: PolicyEngine | None = None`, `audit_sink: AuditSink | None = None`, `compiled_policy: PolicyInputCompiled | None = None`, `tool_runner: object | None = None`, `tool_invoke_options: ToolInvokeOptions | None = None`
- [x] 3.1.3 Ensure `AgentResult` includes `policy_decisions: list[PolicyDecision] | None = None` field

#### 3.2 Implement governance in agent loop
- [x] 3.2.1 In `src/arelis/agents/runtime.py`, at the start of each agent step, call `policy_engine.evaluate()` with checkpoint `BeforeAgentStep` if policy_engine is configured
- [x] 3.2.2 If policy evaluation returns `block`, stop the agent loop and return error result
- [x] 3.2.3 If policy evaluation returns `require_approval`, check approval store or stop
- [x] 3.2.4 After each step, emit an audit event for `agent.step` via `audit_sink.write()` if configured
- [x] 3.2.5 When attestation is created, emit `agent.attestation.created` audit event

#### 3.3 Implement governed memory operations
- [x] 3.3.1 Before memory write, evaluate `BeforePersist` checkpoint if policy_engine is configured
- [x] 3.3.2 Emit `memory.read`, `memory.write`, `memory.delete` audit events for agent memory operations

#### 3.4 Add configure_runtime_governance method
- [x] 3.4.1 Add `configure_runtime_governance(policy_engine, audit_sink, compiled_policy)` method to `AgentRuntime` that sets governance dependencies post-construction

#### 3.5 Update agent tests
- [x] 3.5.1 Update `tests/unit/agents/test_runtime.py` to test agent loop with mock policy engine that allows all
- [x] 3.5.2 Add test for agent loop with policy engine that blocks at step 2
- [x] 3.5.3 Add test for audit event emission during agent execution
- [x] 3.5.4 Add test for governed memory operations (write blocked by policy)

---

### 4.0 Implement compliance request_artifact and replay_run (FR-4) [Critical]

#### 4.1 Implement request_artifact
- [x] 4.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/compliance.ts` for full implementation logic
- [x] 4.1.2 In `client.py` `_ComplianceNamespace.request_artifact()`, implement proof generation flow:
  - Retrieve audit events for the run_id from audit sink
  - Build causal graph from events
  - Apply disclosure rules to determine what to include
  - Generate layer proofs using proof_provider
  - Create composed compliance artifact
  - Store in artifact store
  - Return `ComplianceArtifact`
- [x] 4.1.3 Support `async` mode: when `async=True` in input, create a `ProofJob`, enqueue it in `proof_job_queue`, and return the `ProofJob` instead
- [x] 4.1.4 Handle case where no proof_provider is configured — raise descriptive error

#### 4.2 Implement replay_run
- [x] 4.2.1 In `client.py` `_ComplianceNamespace.replay_run()`, implement causal graph replay:
  - Retrieve the causal graph for the run_id from `causal_graph_store`
  - Reconstruct steps from graph nodes (ordered by timestamp)
  - For each step, re-evaluate policy with the original input data
  - Compare original vs replayed decisions for drift detection
  - Build `AuditReplayResultWithSnapshot` with steps and any drift diagnostics
- [x] 4.2.2 Handle case where no causal_graph_store is configured — raise descriptive error

#### 4.3 Add compliance tests
- [x] 4.3.1 Create `tests/unit/compliance/test_verification.py` with tests for `request_artifact()`:
  - Test successful artifact generation with mock proof provider
  - Test async mode returns ProofJob
  - Test error when no proof provider configured
- [x] 4.3.2 Add tests for `replay_run()`:
  - Test replay with mock causal graph store
  - Test drift detection when policies differ
  - Test error when no causal graph store configured

---

### 5.0 Fix public API exports (FR-5) [High]

#### 5.1 Add input type exports to top-level __init__.py
- [x] 5.1.1 After task 1.0 is complete, add to `src/arelis/__init__.py` `__all__` list: `GenerateInput`, `GenerateStreamInput`, `StreamOptions`, `AgentRunInput` (or `ClientAgentRunInput`), `GroundingInput`, `PromptTemplateRef`, `OutputSchema`, `OutputValidationMode`
- [x] 5.1.2 Add: `RegisterMCPServerInput`, `DiscoverMCPToolsInput`
- [x] 5.1.3 Add: `RegisterKBInput`, `RetrieveInput`
- [x] 5.1.4 Add: `MemoryReadInput`, `MemoryWriteInput`, `MemoryDeleteInput`
- [x] 5.1.5 Add: `DataSourceRegisterInput`, `DataSourceReadInput`
- [x] 5.1.6 Add: `ApprovalResolveInput`
- [x] 5.1.7 Add: `ComplianceArtifactRequest`, `ComplianceProofRequest`, `ComplianceVerificationInput`, `ComplianceReplayInput`
- [x] 5.1.8 Add the corresponding import statements for each type

#### 5.2 Fix module-level __init__.py exports
- [x] 5.2.1 Review `src/arelis/core/__init__.py` — add missing factories and utilities (e.g., `compose_middleware`, `named_middleware`, `generate_run_id`)
- [x] 5.2.2 Review `src/arelis/models/__init__.py` — add new provider protocols and guard functions from task 2.0
- [x] 5.2.3 Review `src/arelis/audit/__init__.py` — add `find_inference_runs_from_lifecycle` from task 9.0
- [x] 5.2.4 Review all other module `__init__.py` files for missing exports and fix

#### 5.3 Verify exports
- [x] 5.3.1 Write a quick test or script that imports every symbol from `arelis` and `arelis.<module>` to confirm no ImportError
- [x] 5.3.2 Cross-reference with `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/index.ts` exports

---

### 6.0 Implement MCP HTTP transport (FR-6) [High]

#### 6.1 Read TypeScript reference
- [x] 6.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/mcp/src/transports/http.ts` for full HTTP transport implementation details

#### 6.2 Implement HTTP transport
- [x] 6.2.1 In `src/arelis/mcp/transports/http.py`, replace stub with full implementation using `httpx.AsyncClient`
- [x] 6.2.2 Implement `connect()`: validate URL, establish SSE connection for server-to-client messages, start background read task
- [x] 6.2.3 Implement `disconnect()`: close SSE connection, cleanup httpx client
- [x] 6.2.4 Implement `list_tools()`: send JSON-RPC 2.0 `tools/list` request via HTTP POST, parse response
- [x] 6.2.5 Implement `invoke_tool()`: send JSON-RPC 2.0 `tools/call` request via HTTP POST, parse response, handle errors
- [x] 6.2.6 Implement SSE stream reading: parse `data:` lines, handle `event:` lines, correlate responses to pending requests
- [x] 6.2.7 Add request ID correlation using pending futures dict (same pattern as stdio transport)
- [x] 6.2.8 Add timeout handling with configurable connection_timeout
- [x] 6.2.9 Add auth header support: merge auth config (bearer, apiKey) into request headers via `get_headers()`

#### 6.3 Add HTTP transport options
- [x] 6.3.1 Add `HttpTransportOptions` dataclass with: `connection_timeout: int = 30000`, `max_retries: int = 2`, `retry_delay_ms: int = 1000`

#### 6.4 Add tests
- [x] 6.4.1 Create `tests/unit/mcp/test_http_transport.py`
- [x] 6.4.2 Test `connect()` with mocked httpx responses
- [x] 6.4.3 Test `list_tools()` with mocked JSON-RPC response
- [x] 6.4.4 Test `invoke_tool()` with success and error responses
- [x] 6.4.5 Test auth header generation for bearer and apiKey configs
- [x] 6.4.6 Test timeout handling
- [x] 6.4.7 Test `disconnect()` cleanup

---

### 7.0 Integrate Redactor into governance gate PII scanning (FR-7) [High]

#### 7.1 Update PII options types
- [x] 7.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/governance/src/governance-gate.ts` for exact PII options
- [x] 7.1.2 In `src/arelis/governance_gate/types.py`, add `redactor: Redactor | None = None` field to `ScanPromptForPiiOptions`
- [x] 7.1.3 Add `redactor_config: RedactorConfig | None = None` field to `ScanPromptForPiiOptions`

#### 7.2 Refactor PII scanning
- [x] 7.2.1 In `src/arelis/governance_gate/pii.py`, update `scan_prompt_for_pii()` to:
  - If `options.redactor` is provided, use it directly
  - Else if `options.redactor_config` is provided, create a `Redactor` from config
  - Else create a default `Redactor` with standard patterns
- [x] 7.2.2 Replace inline regex patterns with `Redactor.redact()` calls
- [x] 7.2.3 Map `RedactionFinding` results to PII scan results

#### 7.3 Update tests
- [x] 7.3.1 Update `tests/unit/governance_gate/test_pii.py` to test with default Redactor
- [x] 7.3.2 Add test with custom Redactor instance
- [x] 7.3.3 Add test with RedactorConfig (custom patterns)

---

### 8.0 Fix DisclosureProof field naming (FR-8) [High]

#### 8.1 Rename fields
- [x] 8.1.1 In `src/arelis/compliance/types.py`, rename `DisclosureProof.root_hash` to `commitment_root`
- [x] 8.1.2 Rename `DisclosureProof.event_hashes` to `rule_ids`
- [x] 8.1.3 Verify `schema_version` matches TS `schemaVersion` (this one is correct)

#### 8.2 Update all references
- [x] 8.2.1 Search for all usages of `root_hash` and `event_hashes` on DisclosureProof across the codebase and update to new names
- [x] 8.2.2 Update `src/arelis/audit/proof.py` if it constructs DisclosureProof instances
- [x] 8.2.3 Update `src/arelis/compliance/verification.py` if it reads DisclosureProof fields
- [x] 8.2.4 Update any tests that reference these fields

---

### 9.0 Add find_inference_runs_from_lifecycle to CAG (FR-9) [Medium]

#### 9.1 Implement function
- [x] 9.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/audit/src/causal-graph.ts` for `findInferenceRunsFromLifecycle()` implementation
- [x] 9.1.2 In `src/arelis/audit/cag.py`, implement `find_inference_runs_from_lifecycle(graph: CausalGraph) -> list[str]` that traverses the causal graph to find inference run nodes linked to lifecycle events
- [x] 9.1.3 Export from `src/arelis/audit/__init__.py`

#### 9.2 Add tests
- [x] 9.2.1 In `tests/unit/audit/test_cag.py`, add test for `find_inference_runs_from_lifecycle()` with a graph containing inference and lifecycle nodes
- [x] 9.2.2 Add test with empty graph (returns empty list)
- [x] 9.2.3 Add test with graph that has no lifecycle nodes

---

### 10.0 Add Google Vertex embeddings function (FR-10) [Medium]

#### 10.1 Implement embeddings
- [x] 10.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/providers-google-vertex/src/embeddings.ts` for full implementation
- [x] 10.1.2 Create `src/arelis/providers/google_vertex/embeddings.py`
- [x] 10.1.3 Define `VertexEmbeddingTaskType` literal: `"RETRIEVAL_QUERY"`, `"RETRIEVAL_DOCUMENT"`, `"SEMANTIC_SIMILARITY"`, `"CLASSIFICATION"`, `"CLUSTERING"`
- [x] 10.1.4 Define `VertexEmbedOptions` dataclass with: `model: str = "text-embedding-004"`, `task_type: VertexEmbeddingTaskType | None = None`, `output_dimensionality: int | None = None`, `api_endpoint: str | None = None`
- [x] 10.1.5 Implement `create_vertex_embed_function(project: str, location: str, options: VertexEmbedOptions | None = None) -> EmbedFunction` that returns an async function `(texts: list[str]) -> list[list[float]]`
- [x] 10.1.6 The embed function should call Vertex AI's embedding endpoint via HTTP (using the provider's existing auth mechanism)

#### 10.2 Export and test
- [x] 10.2.1 Export `create_vertex_embed_function`, `VertexEmbedOptions`, `VertexEmbeddingTaskType` from `src/arelis/providers/google_vertex/__init__.py`
- [x] 10.2.2 Add unit test in `tests/unit/providers/test_google_vertex_embeddings.py` with mocked HTTP response

---

### 11.0 Add missing ClientConfig fields (FR-11) [Medium]

#### 11.1 Define ComplianceConfig
- [x] 11.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/sdk/src/config.ts` for exact ComplianceConfig fields
- [x] 11.1.2 In `src/arelis/config.py`, add `ComplianceConfig` dataclass (or TypedDict) with fields: `causal_graph_store: CausalGraphStore | None = None`, `artifact_store: ComplianceArtifactStore | None = None`, `proof_provider: ProofProvider | None = None`, `proof_job_queue: ProofJobQueue | None = None`, `commitment_signer: Signer | None = None`, `disclosure_rules: list[DisclosureRule] | None = None`, `proof_timeout_ms: int | None = None`
- [x] 11.1.3 Replace existing compliance-related fields in `ClientConfig` with `compliance: ComplianceConfig | None = None`
- [x] 11.1.4 Update `ArelisClient.__init__()` in `client.py` to unpack `ComplianceConfig` fields into internal references

#### 11.2 Update tests
- [x] 11.2.1 Update `tests/unit/test_client.py` to create clients with `ComplianceConfig`

---

### 12.0 Fix secrets resolve_secret_value return type (FR-12) [Medium]

#### 12.1 Create result dataclass
- [x] 12.1.1 In `src/arelis/secrets/types.py`, add `SecretResolutionResult` dataclass with fields: `value: str`, `resolution: SecretResolution`
- [x] 12.1.2 Export from `src/arelis/secrets/__init__.py`

#### 12.2 Update function
- [x] 12.2.1 In `src/arelis/secrets/resolver.py`, change `resolve_secret_value()` return type from `tuple[str, SecretResolution]` to `SecretResolutionResult`
- [x] 12.2.2 Update the return statement to construct `SecretResolutionResult(value=..., resolution=...)`

#### 12.3 Update references and tests
- [x] 12.3.1 Search for all callers of `resolve_secret_value()` and update tuple unpacking to attribute access
- [x] 12.3.2 Update `tests/unit/secrets/test_resolver.py` to assert on `.value` and `.resolution` attributes

---

### 13.0 Add missing unit tests (FR-13) [Medium]

#### 13.1 Compliance unit tests
- [x] 13.1.1 Create `tests/unit/compliance/__init__.py`
- [x] 13.1.2 Create `tests/unit/compliance/test_types.py`:
  - Test `ComplianceArtifact` dataclass construction
  - Test `DisclosureProof` dataclass with correct field names (after task 8.0)
  - Test `InMemoryComplianceArtifactStore` store/list/get operations
  - Test `ProofJob` and `InMemoryProofJobQueue` enqueue/dequeue
- [x] 13.1.3 Create `tests/unit/compliance/test_verification.py`:
  - Test `verify_compliance_artifact()` with valid artifact
  - Test verification with invalid artifact (tampered hash)
  - Test verification with custom proof provider

#### 13.2 Storage unit tests
- [x] 13.2.1 Create `tests/unit/storage/__init__.py`
- [x] 13.2.2 Create `tests/unit/storage/test_postgres_audit.py`:
  - Test `PostgresAuditSink` initialization with mock pool
  - Test batching logic (buffer fills, triggers flush)
  - Test retry logic with mocked connection errors
  - Test event serialization to SQL parameters
- [x] 13.2.3 Create `tests/unit/storage/test_postgres_memory.py`:
  - Test `PostgresMemoryProvider` read/write/delete/list with mock pool
  - Test scope-based key isolation
  - Test metadata storage and retrieval

---

### 14.0 Enhance GovernanceGateDeniedError (FR-14) [Low]

#### 14.1 Update error class
- [x] 14.1.1 Read `/Users/ramon.marrero/arelis-sdk/packages/governance/src/governance-gate.ts` for GovernanceGateDeniedError structure
- [x] 14.1.2 In `src/arelis/core/errors.py` (or `governance_gate/gate.py`), add `decision: PreInvocationGateDecision | None = None` field to `GovernanceGateDeniedError`
- [x] 14.1.3 Update the constructor to accept and store the full decision object

#### 14.2 Update gate code
- [x] 14.2.1 In `src/arelis/governance_gate/gate.py`, pass the full `decision` when creating `GovernanceGateDeniedError`
- [x] 14.2.2 Update tests in `tests/unit/governance_gate/test_gate.py` to verify `error.decision` is populated

---

### 15.0 Derive ExtensionCapabilityFlag from contracts (FR-15) [Low]

#### 15.1 Implement derivation
- [x] 15.1.1 In `src/arelis/extensions/types.py` or `contracts.py`, derive `ExtensionCapabilityFlag` dynamically from `EXTENSION_NAMESPACE_CONTRACTS` by extracting all unique capability strings from all contracts
- [x] 15.1.2 If dynamic Literal derivation is not possible in Python's type system, add a comment explaining why it's manually maintained, and add a runtime assertion that validates the manual list matches the contracts
- [x] 15.1.3 Add a unit test in `tests/unit/extensions/test_contracts.py` that verifies `ExtensionCapabilityFlag` contains all capabilities from all contracts

---

### 16.0 Final verification pass [Required]

#### 16.1 Type checking
- [x] 16.1.1 Run `mypy --strict src/arelis` and fix any errors
- [x] 16.1.2 Ensure all new types have proper annotations (no `Any`)

#### 16.2 Linting
- [x] 16.2.1 Run `ruff check src/ tests/` and fix any warnings
- [x] 16.2.2 Run `ruff format src/ tests/` to ensure consistent formatting

#### 16.3 Test suite
- [x] 16.3.1 Run `pytest` — all tests must pass
- [x] 16.3.2 Run `pytest --cov=arelis --cov-report=term-missing` — verify >= 80% coverage
- [x] 16.3.3 Fix any failing tests from the changes

#### 16.4 Cross-reference with TS SDK
- [x] 16.4.1 Verify all 30 client methods now accept proper input objects
- [x] 16.4.2 Verify all public types are exported from `arelis` top-level
- [x] 16.4.3 Spot-check 3-5 methods against TypeScript SDK to confirm exact parity
