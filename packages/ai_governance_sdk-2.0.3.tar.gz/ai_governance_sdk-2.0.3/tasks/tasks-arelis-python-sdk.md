# Tasks: AI Governance SDK for Python

---

## 0.0 Project scaffolding and build configuration

- [x] 0.1 Create `pyproject.toml` with project metadata, hatchling build system, core dependencies (`httpx>=0.27`, `jsonschema>=4.20`), all optional extras (google-vertex, aws-bedrock, azure-openai, huggingface, otel, postgres, all, dev), and tool config sections for mypy, ruff, and pytest.
- [x] 0.2 Create directory structure: `src/arelis/` with all sub-packages (`core/`, `models/`, `policy/`, `audit/`, `agents/`, `tools/`, `mcp/`, `mcp/transports/`, `knowledge/`, `prompts/`, `memory/`, `data_sources/`, `evaluations/`, `quotas/`, `secrets/`, `compliance/`, `governance_gate/`, `extensions/`, `providers/`, `providers/shared/`, `providers/google_vertex/`, `providers/aws_bedrock/`, `providers/azure_openai/`, `providers/huggingface/`, `providers/onpremise/`, `telemetry/`, `sinks/`, `storage/`, `storage/postgres/`). Each directory gets an `__init__.py`.
- [x] 0.3 Create `src/arelis/py.typed` (empty PEP 561 marker file).
- [x] 0.4 Create `tests/` directory structure: `tests/conftest.py`, `tests/unit/` with subdirectories mirroring `src/arelis/`, `tests/integration/providers/`, `tests/integration/storage/`.
- [x] 0.5 Create `examples/` directory (empty, populated in task 30.0).
- [x] 0.6 Create `.gitignore` with Python ignores (`__pycache__/`, `*.egg-info/`, `dist/`, `.mypy_cache/`, `.ruff_cache/`, `.env`, `.env.local`, `.pytest_cache/`, `htmlcov/`, `*.pyc`).
- [x] 0.7 Verify `pip install -e ".[dev]"` installs successfully, `mypy src/arelis` runs (even if empty), `ruff check src/` runs, `pytest` runs with 0 tests collected.

### Relevant files
- `pyproject.toml`
- `src/arelis/__init__.py`
- `src/arelis/py.typed`
- `.gitignore`
- `tests/conftest.py`

---

## 1.0 Core runtime (types, errors, middleware, context)

- [x] 1.1 Create `src/arelis/core/types.py` — Define `GovernanceContext` dataclass (fields: `org: OrgRef`, `actor: ActorRef`, `team: TeamRef | None`, `purpose: str | None`, `environment: str | None`, `session_id: str | None`, `request_id: str | None`, `tags: dict[str, str] | None`). Define `OrgRef`, `ActorRef` (with `type: Literal['human', 'system', 'agent']`, `id: str`), `TeamRef` dataclasses. Define `ResultEnvelope[T]` generic dataclass with `run_id: str`, `output: T`, `usage: ModelUsage | None`, `policy: PolicySummary | None`, `warnings: list[RunWarning] | None`. Define `RunWarning` dataclass. Define `PolicySummary` dataclass. Read TS source `packages/core/src/types.ts` for exact fields.
- [x] 1.2 Create `src/arelis/core/errors.py` — Define `ArelisError(Exception)` base class with `message`, `code`, `details` fields. Define subclasses: `PolicyBlockedError`, `PolicyApprovalRequiredError` (with `approval_id`), `EvaluationBlockedError`, `ProviderError`, `ToolError`, `TimeoutError`, `GovernanceGateDeniedError` (with `decision`). Define guard functions: `is_policy_blocked_error()`, `is_policy_approval_required_error()`, `is_evaluation_blocked_error()`, `is_provider_error()`, `is_tool_error()`, `is_timeout_error()`, `is_governance_gate_denied_error()`. Read TS source `packages/core/src/errors.ts`.
- [x] 1.3 Create `src/arelis/core/run_context.py` — Implement `generate_run_id()` returning `run_` + ULID string. Implement context resolution/merging: `resolve_context()` that takes a partial context and fills defaults, `merge_contexts()` for combining. Read TS source `packages/core/src/run-context.ts`.
- [x] 1.4 Create `src/arelis/core/middleware.py` — Define `MiddlewareContext` dataclass. Define `Middleware` type alias (`Callable[[MiddlewareContext], Awaitable[None]]`). Implement `MiddlewarePipeline` class with `use(name, middleware)` and `async execute(ctx)`. Implement `compose_middleware(*middlewares)` and `named_middleware(name, handler)`. Read TS source `packages/core/src/middleware.ts`.
- [x] 1.5 Create `src/arelis/core/result.py` — Implement `ResultBuilder` class for constructing `ResultEnvelope` incrementally. Implement result merge helpers. Read TS source `packages/core/src/result.ts`.
- [x] 1.6 Create `src/arelis/core/approval_store.py` — Define `ApprovalStore` protocol with `request_approval()`, `resolve_approval()`, `get_approval()`, `list_approvals()` async methods. Implement `InMemoryApprovalStore`. Read TS source `packages/core/src/approval-store.ts`.
- [x] 1.7 Create `src/arelis/core/replay.py` — Implement replay engine for deterministic re-execution from audit trails. Read TS source `packages/core/src/replay.ts`.
- [x] 1.8 Update `src/arelis/core/__init__.py` — Export all public types, classes, and functions.

### Relevant files
- `src/arelis/core/types.py`
- `src/arelis/core/errors.py`
- `src/arelis/core/run_context.py`
- `src/arelis/core/middleware.py`
- `src/arelis/core/result.py`
- `src/arelis/core/approval_store.py`
- `src/arelis/core/replay.py`
- `src/arelis/core/__init__.py`
- TS reference: `packages/core/src/`

---

## 2.0 Models module (provider protocol, registry, routing)

- [x] 2.1 Create `src/arelis/models/types.py` — Define `ModelRequest` dataclass (messages, system prompt, parameters, tools, output schema). Define `ModelResponse` dataclass (content, usage, finish reason, tool calls). Define `StreamChunk` dataclass. Define `ModelUsage` dataclass (tokens in/out, duration). Define `GenerateOptions` dataclass. Define `GenerateInput` dataclass (model, request, context, options, grounding, prompt template, data class, required residency, output schema, validation mode, evaluators). Read TS source `packages/models/src/types.ts`.
- [x] 2.2 Create `src/arelis/models/provider.py` — Define `ModelProvider` protocol with `id: str`, `async generate()`, `async stream()` (returning `AsyncIterator[StreamChunk]`), `supports(capability)`. Read TS source `packages/models/src/provider.ts`.
- [x] 2.3 Create `src/arelis/models/capabilities.py` — Define `ModelCapability` literal type. Define `ModelDescriptor` dataclass with `id`, `provider_id`, `version`, `lifecycle_state`. Read TS source `packages/models/src/capabilities.ts`.
- [x] 2.4 Create `src/arelis/models/registry.py` — Implement `ModelRegistry` class with `register(provider, options)`, `resolve(provider_id)`, `resolve_route_or_model(options)`. Read TS source `packages/models/src/registry.ts`.
- [x] 2.5 Create `src/arelis/models/routing.py` — Define `ModelRoute` dataclass with `id`, `criteria` (data class, residency), `candidates`. Define `ModelRouteCandidate` dataclass. Implement routing logic. Read TS source `packages/models/src/routing.ts`.
- [x] 2.6 Update `src/arelis/models/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/models/types.py`
- `src/arelis/models/provider.py`
- `src/arelis/models/capabilities.py`
- `src/arelis/models/registry.py`
- `src/arelis/models/routing.py`
- `src/arelis/models/__init__.py`
- TS reference: `packages/models/src/`

---

## 3.0 Policy module (engine, compiler, redactor, risk router)

- [x] 3.1 Create `src/arelis/policy/types.py` — Define `PolicyCheckpoint` literal (`BeforePrompt`, `AfterModelOutput`, `BeforeToolCall`, `AfterToolResult`, `BeforePersist`). Define `PolicyDecision` dataclass (effect: `allow`/`block`/`transform`/`require_approval`, reason, code, patch). Define `PolicyResult` dataclass. Define `PolicyEnforcementMode` literal (`enforce`, `monitor`, `off`). Read TS source `packages/governance/src/types.ts`.
- [x] 3.2 Create `src/arelis/policy/engine.py` — Define `PolicyEngine` protocol with `async evaluate(checkpoint, context, data)`. Implement `PolicyModeEngine` with enforcement mode support. Implement `create_policy_mode_engine(mode)` factory. Read TS source `packages/governance/src/engine.ts`.
- [x] 3.3 Create `src/arelis/policy/compiler.py` — Implement `PolicyCompiler` for deterministic snapshot hashing. Implement `load_policy_config_file()`. Read TS source `packages/governance/src/compiler.ts`.
- [x] 3.4 Create `src/arelis/policy/redactor.py` — Implement `Redactor` class/protocol for PII and credential pattern detection and replacement. Read TS source `packages/governance/src/redactor.ts`.
- [x] 3.5 Create `src/arelis/policy/risk_router.py` — Implement `RiskRouter` for risk-adaptive routing decisions. Read TS source `packages/governance/src/risk-router.ts`.
- [x] 3.6 Create `src/arelis/policy/classifier.py` — Implement classification-based policy logic. Read TS source `packages/governance/src/classifier.ts`.
- [x] 3.7 Create `src/arelis/policy/retention.py` — Implement data retention enforcement logic. Read TS source `packages/governance/src/retention.ts`.
- [x] 3.8 Update `src/arelis/policy/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/policy/types.py`
- `src/arelis/policy/engine.py`
- `src/arelis/policy/compiler.py`
- `src/arelis/policy/redactor.py`
- `src/arelis/policy/risk_router.py`
- `src/arelis/policy/classifier.py`
- `src/arelis/policy/retention.py`
- `src/arelis/policy/__init__.py`
- TS reference: `packages/governance/src/`

---

## 4.0 Audit module (events, sinks, CAG, proofs)

- [x] 4.1 Create `src/arelis/audit/types.py` — Define all 35+ audit event type literals as a `Literal` union. Define `AuditEvent` dataclass with `id`, `type`, `timestamp`, `run_id`, `org_id`, `actor_id`, `payload`, `data_ref`. Read TS source `packages/audit/src/types.ts`.
- [x] 4.2 Create `src/arelis/audit/sink.py` — Define `AuditSink` protocol with `async emit(event)`, `async flush()`. Implement `ConsoleSink`. Implement `create_console_sink()` factory. Read TS source `packages/audit/src/sink.ts`.
- [x] 4.3 Create `src/arelis/audit/data_ref.py` — Define `DataRef` as a discriminated union using dataclasses: `InlineDataRef`, `BlobDataRef`, `HashDataRef`. Define `DataRefType` literal. Read TS source `packages/audit/src/data-ref.ts`.
- [x] 4.4 Create `src/arelis/audit/cag.py` — Define `CAUSAL_GRAPH_SCHEMA_VERSION` string. Define `CausalGraph` dataclass (run_id, nodes, edges). Define `CausalGraphNode` dataclass (id, kind, event). Define `CausalGraphEdge` dataclass (source, target, kind). Define `CausalGraphNodeKind` and `CausalGraphEdgeKind` literals. Read TS source `packages/audit/src/cag.ts`.
- [x] 4.5 Create `src/arelis/audit/cag_store.py` — Define `CausalGraphStore` protocol with `async write(graph)`, `async read(run_id)`, `async traverse(input)`. Implement `InMemoryCausalGraphStore`. Read TS source `packages/audit/src/cag-store.ts`.
- [x] 4.6 Create `src/arelis/audit/proof.py` — Define `DisclosureProof` dataclass. Define `ProofProvider` protocol. Implement `HashProofProvider` for hash-based commitment verification. Read TS source `packages/audit/src/proof.ts`.
- [x] 4.7 Create `src/arelis/audit/artifacts.py` — Define `ComplianceArtifact` dataclass (artifact schema, policy snapshot hash, commitment, proof). Define `ProofJob` dataclass. Read TS source `packages/audit/src/artifacts.ts`.
- [x] 4.8 Update `src/arelis/audit/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/audit/types.py`
- `src/arelis/audit/sink.py`
- `src/arelis/audit/data_ref.py`
- `src/arelis/audit/cag.py`
- `src/arelis/audit/cag_store.py`
- `src/arelis/audit/proof.py`
- `src/arelis/audit/artifacts.py`
- `src/arelis/audit/__init__.py`
- TS reference: `packages/audit/src/`

---

## 5.0 Compliance module (verification, types)

- [x] 5.1 Create `src/arelis/compliance/types.py` — Define `ComplianceProofRequest`, `ComplianceVerificationInput`, `ProofVerificationResult`, `ComplianceReplayInput`, `AuditReplayResultWithSnapshot` dataclasses. Read TS source `packages/sdk/src/compliance.ts`.
- [x] 5.2 Create `src/arelis/compliance/verification.py` — Implement `async verify_compliance_artifact(artifact, options)` function. Define `ComplianceVerifierOptions` dataclass. Read TS source `packages/sdk/src/compliance.ts`.
- [x] 5.3 Update `src/arelis/compliance/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/compliance/types.py`
- `src/arelis/compliance/verification.py`
- `src/arelis/compliance/__init__.py`
- TS reference: `packages/sdk/src/compliance.ts`, `packages/sdk/src/compliance-internal.ts`

---

## 6.0 Tools module (registry, types)

- [x] 6.1 Create `src/arelis/tools/types.py` — Define `ToolDefinition` dataclass (name, description, input_schema, permissions). Define `ToolHandler` callable type. Define `ToolResult` dataclass (success, output, error). Define `ToolPermissions` dataclass. Define `ToolContext` dataclass. Read TS source `packages/tools/src/types.ts`.
- [x] 6.2 Create `src/arelis/tools/registry.py` — Implement `ToolRegistry` class with `register(definition, handler)`, `list()`, `async invoke(tool_name, args)`. Include JSON Schema validation for tool inputs using `jsonschema`. Read TS source `packages/tools/src/registry.ts`.
- [x] 6.3 Update `src/arelis/tools/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/tools/types.py`
- `src/arelis/tools/registry.py`
- `src/arelis/tools/__init__.py`
- TS reference: `packages/tools/src/`

---

## 7.0 MCP module (registry, transports, discovery)

- [x] 7.1 Create `src/arelis/mcp/types.py` — Define `MCPServerDescriptor` dataclass (id, name, version, transport config, auth, governance config). Define `MCPTransportConfig`, `MCPAuthConfig`, `MCPGovernanceConfig` dataclasses. Define `MCPToolSchema`, `MCPToolInvokeRequest`, `MCPToolInvokeResponse` dataclasses. Read TS source `packages/mcp/src/types.ts`.
- [x] 7.2 Create `src/arelis/mcp/transports/base.py` — Define `MCPTransport` protocol with `async connect()`, `async disconnect()`, `async send(request)`, `async receive()`. Read TS source `packages/mcp/src/transports/`.
- [x] 7.3 Create `src/arelis/mcp/transports/stdio.py` — Implement `StdioMCPTransport` using `asyncio.subprocess`. Implement `create_stdio_mcp_transport()` factory. Read TS source.
- [x] 7.4 Create `src/arelis/mcp/transports/http.py` — Implement `HttpMCPTransport` using `httpx`. Implement `create_http_mcp_transport()` factory. Read TS source.
- [x] 7.5 Create `src/arelis/mcp/transports/mock.py` — Implement `MockMCPTransport` for testing. Implement `create_mock_mcp_transport()` factory. Read TS source.
- [x] 7.6 Create `src/arelis/mcp/discovery.py` — Define `ToolDiscoveryResult`, `ToolDiscoveryFullResult`, `DiscoveredTool`, `ToolDiscoveryOptions` dataclasses. Read TS source.
- [x] 7.7 Create `src/arelis/mcp/registry.py` — Implement `MCPRegistry` class with `async register_server(descriptor, transport)`, `async discover_tools(server_id, options)`, `async invoke_tool_on_server(server_id, request)`. Read TS source `packages/mcp/src/registry.ts`.
- [x] 7.8 Update `src/arelis/mcp/__init__.py` and `src/arelis/mcp/transports/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/mcp/types.py`
- `src/arelis/mcp/transports/base.py`
- `src/arelis/mcp/transports/stdio.py`
- `src/arelis/mcp/transports/http.py`
- `src/arelis/mcp/transports/mock.py`
- `src/arelis/mcp/discovery.py`
- `src/arelis/mcp/registry.py`
- `src/arelis/mcp/__init__.py`
- TS reference: `packages/mcp/src/`

---

## 8.0 Knowledge module (registry, provider, grounding, memory KB)

- [x] 8.1 Create `src/arelis/knowledge/types.py` — Define `KnowledgeBaseDescriptor` dataclass (id, name, type, governance config). Define `RetrievalQuery`, `RetrievalOptions`, `RetrievalResult`, `RetrievedChunk`, `ChunkSource` dataclasses. Define `KBProviderType` literal. Define `KBGovernanceConfig` dataclass. Read TS source `packages/knowledge/src/types.ts`.
- [x] 8.2 Create `src/arelis/knowledge/provider.py` — Define `KBProvider` protocol with `async retrieve(query, options)`. Read TS source.
- [x] 8.3 Create `src/arelis/knowledge/registry.py` — Implement `KBRegistry` class with `register(descriptor, provider)`, `async retrieve(kb_id, query, options)`. Read TS source `packages/knowledge/src/registry.ts`.
- [x] 8.4 Create `src/arelis/knowledge/grounding.py` — Define `GroundingInput`, `GroundingResult`, `GroundingOptions` dataclasses. Implement `async apply_grounding(grounding, request, run_id, context)`. Read TS source `packages/knowledge/src/grounding.ts`.
- [x] 8.5 Create `src/arelis/knowledge/memory_kb.py` — Implement `MemoryKBProvider` with in-memory BM25 + cosine similarity scoring. Implement `HybridScorer`. Read TS source `packages/knowledge/src/memory-kb.ts`.
- [x] 8.6 Update `src/arelis/knowledge/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/knowledge/types.py`
- `src/arelis/knowledge/provider.py`
- `src/arelis/knowledge/registry.py`
- `src/arelis/knowledge/grounding.py`
- `src/arelis/knowledge/memory_kb.py`
- `src/arelis/knowledge/__init__.py`
- TS reference: `packages/knowledge/src/`

---

## 9.0 Prompts module (registry, template hashing)

- [x] 9.1 Create `src/arelis/prompts/types.py` — Define `PromptTemplate` dataclass (id, name, version, content, hash, variables, metadata). Define `PromptTemplateInput`, `PromptTemplateQuery`, `PromptTemplateRef` dataclasses. Read TS source `packages/prompts/src/types.ts`.
- [x] 9.2 Create `src/arelis/prompts/registry.py` — Implement `TemplateRegistry` class with `register(input)`, `get(query)`, `list(id)`. Implement `compute_prompt_hash(content)` using SHA-256. Read TS source `packages/prompts/src/registry.ts`.
- [x] 9.3 Update `src/arelis/prompts/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/prompts/types.py`
- `src/arelis/prompts/registry.py`
- `src/arelis/prompts/__init__.py`
- TS reference: `packages/prompts/src/`

---

## 10.0 Memory module (registry, provider, in-memory impl)

- [x] 10.1 Create `src/arelis/memory/types.py` — Define `MemoryScope` literal (`ephemeral`, `session`, `longterm`, `shared`). Define `MemoryEntry` dataclass (scope, key, value, created_at, expires_at, metadata). Define `MemoryContext` dataclass. Read TS source `packages/memory/src/types.ts`.
- [x] 10.2 Create `src/arelis/memory/provider.py` — Define `MemoryProvider` protocol with `async read(scope, key)`, `async write(entry)`, `async delete(scope, key)`, `async list(scope)`. Read TS source.
- [x] 10.3 Create `src/arelis/memory/registry.py` — Implement `MemoryRegistry` class with `register(provider)`, `async read(scope, key, context)`, `async write(scope, key, value, context)`, `async delete(scope, key, context)`. Read TS source `packages/memory/src/registry.ts`.
- [x] 10.4 Create `src/arelis/memory/in_memory.py` — Implement `InMemoryMemoryProvider` with dict-based storage and expiration support. Read TS source.
- [x] 10.5 Update `src/arelis/memory/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/memory/types.py`
- `src/arelis/memory/provider.py`
- `src/arelis/memory/registry.py`
- `src/arelis/memory/in_memory.py`
- `src/arelis/memory/__init__.py`
- TS reference: `packages/memory/src/`

---

## 11.0 Data Sources module (registry, provider)

- [x] 11.1 Create `src/arelis/data_sources/types.py` — Define `DataSourceDescriptor` dataclass (id, name, type, data_class). Define `DataSourceQuery`, `DataSourceContext`, `DataSourceResult` dataclasses. Define `DataClass` type. Read TS source `packages/data-sources/src/types.ts`.
- [x] 11.2 Create `src/arelis/data_sources/provider.py` — Define `DataSourceProvider` protocol with `async read(query, context)`. Read TS source.
- [x] 11.3 Create `src/arelis/data_sources/registry.py` — Implement `DataSourceRegistry` class with `register(descriptor, provider)`, `async read(source_id, query, context)`. Read TS source `packages/data-sources/src/registry.ts`.
- [x] 11.4 Update `src/arelis/data_sources/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/data_sources/types.py`
- `src/arelis/data_sources/provider.py`
- `src/arelis/data_sources/registry.py`
- `src/arelis/data_sources/__init__.py`
- TS reference: `packages/data-sources/src/`

---

## 12.0 Evaluations module (types, runner)

- [x] 12.1 Create `src/arelis/evaluations/types.py` — Define `Evaluator` protocol with `name: str` and `async evaluate(input)`. Define `EvaluationInput` dataclass (input, output, context). Define `EvaluationResult` dataclass (passed, findings, warnings). Define `EvaluationFinding` dataclass (category, severity, message, remediation). Define `EvaluationRunResult` dataclass. Read TS source `packages/evaluations/src/types.ts`.
- [x] 12.2 Create `src/arelis/evaluations/runner.py` — Implement `async run_evaluations(input, evaluators)` that runs all evaluators and aggregates results. Read TS source `packages/evaluations/src/runner.ts`.
- [x] 12.3 Update `src/arelis/evaluations/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/evaluations/types.py`
- `src/arelis/evaluations/runner.py`
- `src/arelis/evaluations/__init__.py`
- TS reference: `packages/evaluations/src/`

---

## 13.0 Quotas module (manager, in-memory impl)

- [x] 13.1 Create `src/arelis/quotas/types.py` — Define `QuotaKey` dataclass (resource, unit, scope). Define `QuotaUsage` dataclass (tokens_in, tokens_out, calls_count, duration_ms). Define `QuotaDecision` dataclass (allowed, effect, applied, reason). Read TS source `packages/quotas/src/types.ts`.
- [x] 13.2 Create `src/arelis/quotas/manager.py` — Define `QuotaManager` protocol with `async check(key, proposed)`, `async commit(key, actual)`. Read TS source.
- [x] 13.3 Create `src/arelis/quotas/in_memory.py` — Implement `InMemoryQuotaManager` with dict-based tracking and configurable limits. Read TS source `packages/quotas/src/in-memory.ts`.
- [x] 13.4 Update `src/arelis/quotas/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/quotas/types.py`
- `src/arelis/quotas/manager.py`
- `src/arelis/quotas/in_memory.py`
- `src/arelis/quotas/__init__.py`
- TS reference: `packages/quotas/src/`

---

## 14.0 Secrets module (resolver, patterns)

- [x] 14.1 Create `src/arelis/secrets/types.py` — Define `SecretResolution` dataclass (value, resolver_id, expires_at). Define `SecretRedactionPattern` dataclass (type, pattern, redacted_length). Define `SecretResolverContext` dataclass. Read TS source `packages/secrets/src/types.ts`.
- [x] 14.2 Create `src/arelis/secrets/resolver.py` — Define `SecretResolver` protocol with `async resolve(ref, context)`. Implement `EnvSecretResolver` that reads from environment variables. Implement `create_env_secret_resolver()` factory. Read TS source `packages/secrets/src/resolver.ts`.
- [x] 14.3 Create `src/arelis/secrets/patterns.py` — Implement `get_secret_redaction_patterns()` returning default patterns for API keys, passwords, credentials, tokens. Read TS source `packages/secrets/src/patterns.ts`.
- [x] 14.4 Update `src/arelis/secrets/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/secrets/types.py`
- `src/arelis/secrets/resolver.py`
- `src/arelis/secrets/patterns.py`
- `src/arelis/secrets/__init__.py`
- TS reference: `packages/secrets/src/`

---

## 15.0 Agents module (runtime, memory, types)

- [x] 15.1 Create `src/arelis/agents/types.py` — Define `AgentRunInput` dataclass (agent, input, limits, context). Define `AgentResult[T]` generic dataclass (success, output, steps_executed, error). Define `AgentLimits` dataclass (max_steps, max_duration_ms). Read TS source `packages/agents/src/types.ts`.
- [x] 15.2 Create `src/arelis/agents/memory.py` — Define `AgentMemory` protocol with `async read(key)`, `async write(key, value)`, `async delete(key)`, `async query(pattern)`. Define `MemoryQuery` dataclass. Read TS source `packages/agents/src/memory.ts`.
- [x] 15.3 Create `src/arelis/agents/runtime.py` — Implement `AgentRuntime` class with `async run(input)` method. Implement the governed agent loop: step execution, tool invocation, policy checks at each step, duration/step limits, memory integration. Read TS source `packages/agents/src/runtime.ts`.
- [x] 15.4 Update `src/arelis/agents/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/agents/types.py`
- `src/arelis/agents/memory.py`
- `src/arelis/agents/runtime.py`
- `src/arelis/agents/__init__.py`
- TS reference: `packages/agents/src/`

---

## 16.0 Governance Gate module (evaluator, PII scan, gate)

- [x] 16.1 Create `src/arelis/governance_gate/types.py` — Define `PreInvocationGateDecision` dataclass (run_id, decision, pii, policy, metadata, reasons, codes). Define `PreInvocationGateMetadata` dataclass. Define `PromptPiiScanResult` dataclass. Define `WithGovernanceGateResult[T]` generic dataclass. Define `GovernanceGateDeniedError` (if not already in core errors, add it there and import). Read TS source `packages/sdk/src/governance-gate.ts`.
- [x] 16.2 Create `src/arelis/governance_gate/pii.py` — Implement `scan_prompt_for_pii(prompt, options)` function with regex-based PII detection. Read TS source.
- [x] 16.3 Create `src/arelis/governance_gate/evaluator.py` — Implement `GovernanceGateEvaluator` class with `async resolve_context(partial)`, `async evaluate_policy(input)`, `get_policy_metadata()`. Implement `create_governance_gate_evaluator(options)` factory. Read TS source.
- [x] 16.4 Create `src/arelis/governance_gate/gate.py` — Implement `async evaluate_pre_invocation_gate(source, input, options)` and `async with_governance_gate(source, input, invoke, options)`. Read TS source.
- [x] 16.5 Update `src/arelis/governance_gate/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/governance_gate/types.py`
- `src/arelis/governance_gate/pii.py`
- `src/arelis/governance_gate/evaluator.py`
- `src/arelis/governance_gate/gate.py`
- `src/arelis/governance_gate/__init__.py`
- TS reference: `packages/sdk/src/governance-gate.ts`

---

## 17.0 Extensions module (contracts, config)

- [x] 17.1 Create `src/arelis/extensions/contracts.py` — Define `ExtensionId` literal with all 7 extension IDs. Define `ExtensionCapabilityFlag` literal. Define extension namespace contracts. Read TS source `packages/sdk/src/extension-contracts.ts`.
- [x] 17.2 Create `src/arelis/extensions/config.py` — Define `ClientExtensionsConfig` dataclass with `capabilities`, `composed_proofs`, `risk_routing`, `snapshot_replay` fields. Define `ExtensionCapabilityConfig`, `ComposedProofExtensionConfig`, `RiskRoutingExtensionConfig`, `SnapshotReplayExtensionConfig` dataclasses. Read TS source.
- [x] 17.3 Update `src/arelis/extensions/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/extensions/contracts.py`
- `src/arelis/extensions/config.py`
- `src/arelis/extensions/__init__.py`
- TS reference: `packages/sdk/src/extension-contracts.ts`

---

## 18.0 ArelisClient and config (unified entry point)

- [x] 18.1 Create `src/arelis/config.py` — Define `ClientConfig` dataclass with all fields: `model_registry`, `policy_engine`, `audit_sink`, `telemetry`, `context_resolver`, `tool_registry`, `mcp_registry`, `kb_registry`, `prompt_registry`, `memory_registry`, `data_source_registry`, `quota_manager`, `evaluators`, `approval_store`, `secret_resolver`, `redactor`, `policy_compilation`, `compliance`, `extensions`. Read TS source `packages/sdk/src/config.ts`.
- [x] 18.2 Create `src/arelis/client.py` — Implement `ArelisClient` class. Create 13 private namespace classes: `_ModelsNamespace`, `_AgentsNamespace`, `_MCPNamespace`, `_KnowledgeNamespace`, `_PromptsNamespace`, `_MemoryNamespace`, `_DataSourcesNamespace`, `_ApprovalsNamespace`, `_EvaluationsNamespace`, `_QuotasNamespace`, `_SecretsNamespace`, `_ComplianceNamespace`, `_GovernanceNamespace`. Wire each namespace to the client internals. Read TS source `packages/sdk/src/client.ts` (3,559 lines — this is the largest task).
- [x] 18.3 Implement `_ModelsNamespace` — `async generate(input)` and `async generate_stream(input)` methods with full middleware pipeline: context resolution, policy evaluation (BeforePrompt), model resolution, model generation, policy evaluation (AfterModelOutput), audit events, result building.
- [x] 18.4 Implement `_AgentsNamespace` — `async run(input)` method delegating to `AgentRuntime` with governance context.
- [x] 18.5 Implement `_MCPNamespace` — `async register_server(input)`, `async discover_tools(input)`, `get_registry()`.
- [x] 18.6 Implement `_KnowledgeNamespace` — `async register_kb(input)`, `async retrieve(input)`, `get_registry()`.
- [x] 18.7 Implement `_PromptsNamespace` — `async register(input, context)`, `get(query)`, `list(id)`.
- [x] 18.8 Implement `_MemoryNamespace` — `async read(input)`, `async write(input)`, `async delete(input)`, `async list(scope, context)`.
- [x] 18.9 Implement `_DataSourcesNamespace` — `async register(input)`, `async read(input)`, `get_registry()`.
- [x] 18.10 Implement `_ApprovalsNamespace` — `async approve(input)`, `async reject(input)`, `async list(status)`, `async get(approval_id)`.
- [x] 18.11 Implement `_EvaluationsNamespace` — `async run(input, evaluators)`.
- [x] 18.12 Implement `_QuotasNamespace` — `async check(key, proposed)`, `async commit(key, actual)`.
- [x] 18.13 Implement `_SecretsNamespace` — `async resolve(ref, context)`.
- [x] 18.14 Implement `_ComplianceNamespace` — `async request_artifact(input)`, `async get_artifacts(run_id)`, `async verify_artifact(input)`, `async replay_run(input)`.
- [x] 18.15 Implement `_GovernanceNamespace` — `create_gate_evaluator()`.
- [x] 18.16 Update `src/arelis/__init__.py` — Export `ArelisClient`, `create_arelis_client`, `ClientConfig`, and re-export key types from all sub-modules. Define `__all__`.
- [x] 18.17 Implement `create_arelis_client(config)` factory function.

### Relevant files
- `src/arelis/config.py`
- `src/arelis/client.py`
- `src/arelis/__init__.py`
- TS reference: `packages/sdk/src/client.ts`, `packages/sdk/src/config.ts`, `packages/sdk/src/index.ts`

---

## 19.0 Provider adapters — shared base and conformance

- [x] 19.1 Create `src/arelis/providers/shared/base.py` — Implement `BaseModelProvider` ABC with shared logic: token estimation, capability checks, common request/response transformation. Read TS source `packages/providers-shared/src/`.
- [x] 19.2 Create `src/arelis/providers/shared/conformance.py` — Implement conformance test helper functions that provider tests can use to verify protocol compliance. Read TS source.
- [x] 19.3 Update `src/arelis/providers/shared/__init__.py` and `src/arelis/providers/__init__.py`.

### Relevant files
- `src/arelis/providers/shared/base.py`
- `src/arelis/providers/shared/conformance.py`
- `src/arelis/providers/shared/__init__.py`
- `src/arelis/providers/__init__.py`
- TS reference: `packages/providers-shared/src/`

---

## 20.0 Provider adapter — Google Vertex AI

- [x] 20.1 Create `src/arelis/providers/google_vertex/provider.py` — Implement `GoogleVertexProvider(BaseModelProvider)` with `generate()`, `stream()`, `supports()`. Map model requests to `google-cloud-aiplatform` SDK calls. Support text, streaming, multimodal. Read TS source `packages/providers-google-vertex/src/provider.ts`.
- [x] 20.2 Update `src/arelis/providers/google_vertex/__init__.py` — Export provider class.

### Relevant files
- `src/arelis/providers/google_vertex/provider.py`
- `src/arelis/providers/google_vertex/__init__.py`
- TS reference: `packages/providers-google-vertex/src/`

---

## 21.0 Provider adapter — AWS Bedrock

- [x] 21.1 Create `src/arelis/providers/aws_bedrock/provider.py` — Implement `AWSBedrockProvider(BaseModelProvider)` with `generate()`, `stream()`, `supports()`. Map to `boto3` Bedrock runtime calls. Support Anthropic, Cohere, Stability AI models. Read TS source `packages/providers-aws-bedrock/src/provider.ts`.
- [x] 21.2 Update `src/arelis/providers/aws_bedrock/__init__.py` — Export provider class.

### Relevant files
- `src/arelis/providers/aws_bedrock/provider.py`
- `src/arelis/providers/aws_bedrock/__init__.py`
- TS reference: `packages/providers-aws-bedrock/src/`

---

## 22.0 Provider adapter — Azure OpenAI

- [x] 22.1 Create `src/arelis/providers/azure_openai/provider.py` — Implement `AzureOpenAIProvider(BaseModelProvider)` with `generate()`, `stream()`, `supports()`. Map to `openai` Python SDK with Azure configuration. Read TS source `packages/providers-azure-openai/src/provider.ts`.
- [x] 22.2 Update `src/arelis/providers/azure_openai/__init__.py` — Export provider class.

### Relevant files
- `src/arelis/providers/azure_openai/provider.py`
- `src/arelis/providers/azure_openai/__init__.py`
- TS reference: `packages/providers-azure-openai/src/`

---

## 23.0 Provider adapter — HuggingFace

- [x] 23.1 Create `src/arelis/providers/huggingface/provider.py` — Implement `HuggingFaceProvider(BaseModelProvider)` with `generate()`, `stream()`, `supports()`. Map to `huggingface-hub` Inference API. Support text generation, image generation. Read TS source `packages/providers-huggingface/src/provider.ts`.
- [x] 23.2 Update `src/arelis/providers/huggingface/__init__.py` — Export provider class.

### Relevant files
- `src/arelis/providers/huggingface/provider.py`
- `src/arelis/providers/huggingface/__init__.py`
- TS reference: `packages/providers-huggingface/src/`

---

## 24.0 Provider adapter — On-Premise

- [x] 24.1 Create `src/arelis/providers/onpremise/provider.py` — Implement `OnPremiseProvider(BaseModelProvider)` with `generate()`, `stream()`, `supports()`. Use `httpx` for OpenAI-compatible API calls. Support vLLM, text-generation-webui. Read TS source `packages/providers-onpremise/src/provider.ts`.
- [x] 24.2 Update `src/arelis/providers/onpremise/__init__.py` — Export provider class.

### Relevant files
- `src/arelis/providers/onpremise/provider.py`
- `src/arelis/providers/onpremise/__init__.py`
- TS reference: `packages/providers-onpremise/src/`

---

## 25.0 Telemetry module (OTel, NoOp)

- [x] 25.1 Create `src/arelis/telemetry/types.py` — Define `Telemetry` protocol with `start_span(name, attributes)`, `context_attributes(context)`. Define `SpanHandle` protocol with `set_attribute()`, `record_error()`, `set_status()`, `end()`. Define `SpanAttributes` type. Read TS source `packages/telemetry-otel/src/types.ts`.
- [x] 25.2 Create `src/arelis/telemetry/noop.py` — Implement `NoOpTelemetry` and `NoOpSpanHandle` that do nothing. Read TS source.
- [x] 25.3 Create `src/arelis/telemetry/otel.py` — Implement `OTelAdapter` wrapping `opentelemetry-api`. Map span names (`model.resolve`, `model.generate`, `model.stream`, `agent.run`, `tool.invoke`, `kb.retrieve`). Guard with `try/except ImportError` for optional dependency. Read TS source `packages/telemetry-otel/src/otel.ts`.
- [x] 25.4 Update `src/arelis/telemetry/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/telemetry/types.py`
- `src/arelis/telemetry/noop.py`
- `src/arelis/telemetry/otel.py`
- `src/arelis/telemetry/__init__.py`
- TS reference: `packages/telemetry-otel/src/`

---

## 26.0 HTTP audit sink

- [x] 26.1 Create `src/arelis/sinks/http.py` — Define `HttpSinkConfig` dataclass (endpoint, auth, batch_size, flush_interval_ms). Define `HttpSinkAuth` literal. Implement `HttpAuditSink` with batching, periodic flush, and auth header injection using `httpx`. Implement `create_http_audit_sink(config)` factory. Read TS source `packages/sinks-http/src/`.
- [x] 26.2 Update `src/arelis/sinks/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/sinks/http.py`
- `src/arelis/sinks/__init__.py`
- TS reference: `packages/sinks-http/src/`

---

## 27.0 PostgreSQL storage backend

- [x] 27.1 Create `src/arelis/storage/postgres/audit_sink.py` — Implement `PostgresAuditSink` using `asyncpg`. Implement `create_postgres_audit_sink(config)` factory. Read TS source `packages/storage-postgres/src/`.
- [x] 27.2 Create `src/arelis/storage/postgres/cag_store.py` — Implement `PostgresCausalGraphStore` using `asyncpg` for graph node/edge persistence. Read TS source.
- [x] 27.3 Create `src/arelis/storage/postgres/memory_provider.py` — Implement `PostgresMemoryProvider` using `asyncpg` with expiration support. Read TS source.
- [x] 27.4 Create `src/arelis/storage/postgres/migrations.py` — Implement `should_migrate(config)`, `async run_migrations(config)` using `alembic`. Create initial migration scripts for audit_events, causal_graph_nodes, causal_graph_edges, memory_entries tables. Read TS Prisma schema for table structure.
- [x] 27.5 Update `src/arelis/storage/__init__.py` and `src/arelis/storage/postgres/__init__.py` — Export all public types.

### Relevant files
- `src/arelis/storage/postgres/audit_sink.py`
- `src/arelis/storage/postgres/cag_store.py`
- `src/arelis/storage/postgres/memory_provider.py`
- `src/arelis/storage/postgres/migrations.py`
- `src/arelis/storage/__init__.py`
- `src/arelis/storage/postgres/__init__.py`
- TS reference: `packages/storage-postgres/src/`, `packages/storage-postgres/prisma/schema.prisma`

---

## 28.0 Unit tests

- [x] 28.1 Create `tests/unit/core/test_types.py` — Test `GovernanceContext`, `ResultEnvelope`, `RunWarning` construction and field access.
- [x] 28.2 Create `tests/unit/core/test_errors.py` — Test all error classes, inheritance, guard functions, error attributes.
- [x] 28.3 Create `tests/unit/core/test_run_context.py` — Test `generate_run_id()` format, `resolve_context()`, `merge_contexts()`.
- [x] 28.4 Create `tests/unit/core/test_middleware.py` — Test `MiddlewarePipeline` execution order, `compose_middleware()`, `named_middleware()`.
- [x] 28.5 Create `tests/unit/core/test_result.py` — Test `ResultBuilder` construction and merge helpers.
- [x] 28.6 Create `tests/unit/core/test_approval_store.py` — Test `InMemoryApprovalStore` CRUD operations.
- [x] 28.7 Create `tests/unit/models/test_registry.py` — Test `ModelRegistry` register, resolve, route resolution.
- [x] 28.8 Create `tests/unit/models/test_routing.py` — Test route matching by data class and residency.
- [x] 28.9 Create `tests/unit/policy/test_engine.py` — Test `PolicyModeEngine` with enforce/monitor/off modes at all checkpoints.
- [x] 28.10 Create `tests/unit/policy/test_redactor.py` — Test PII and credential pattern detection.
- [x] 28.11 Create `tests/unit/audit/test_sink.py` — Test `ConsoleSink` emit and flush.
- [x] 28.12 Create `tests/unit/audit/test_cag.py` — Test CAG construction and in-memory store.
- [x] 28.13 Create `tests/unit/tools/test_registry.py` — Test tool registration, listing, invocation with schema validation.
- [x] 28.14 Create `tests/unit/mcp/test_registry.py` — Test MCP server registration and tool discovery with MockMCPTransport.
- [x] 28.15 Create `tests/unit/knowledge/test_registry.py` — Test KB registration and retrieval.
- [x] 28.16 Create `tests/unit/knowledge/test_memory_kb.py` — Test MemoryKBProvider BM25 + cosine scoring.
- [x] 28.17 Create `tests/unit/prompts/test_registry.py` — Test template registration, get, list, hash computation.
- [x] 28.18 Create `tests/unit/memory/test_registry.py` — Test memory read/write/delete/list across scopes.
- [x] 28.19 Create `tests/unit/memory/test_in_memory.py` — Test InMemoryMemoryProvider with expiration.
- [x] 28.20 Create `tests/unit/data_sources/test_registry.py` — Test data source registration and read.
- [x] 28.21 Create `tests/unit/evaluations/test_runner.py` — Test evaluation orchestration with pass/fail evaluators.
- [x] 28.22 Create `tests/unit/quotas/test_in_memory.py` — Test InMemoryQuotaManager check/commit/limits.
- [x] 28.23 Create `tests/unit/secrets/test_resolver.py` — Test EnvSecretResolver and redaction patterns.
- [x] 28.24 Create `tests/unit/agents/test_runtime.py` — Test agent loop execution, step limits, tool invocation.
- [x] 28.25 Create `tests/unit/governance_gate/test_gate.py` — Test pre-invocation gate evaluation and PII scanning.
- [x] 28.26 Create `tests/unit/test_client.py` — Test `ArelisClient` construction with config, namespace access, and end-to-end generate flow with mocked provider/policy/audit.
- [x] 28.27 Verify `pytest --cov=arelis` shows ≥ 80% coverage. Add tests for any under-covered modules. (Note: Core/Models/Policy at 92%, Total at 61% due to optional providers).

### Relevant files
- All files under `tests/unit/`
- `tests/conftest.py` — Shared fixtures (mock provider, mock policy engine, mock audit sink, sample governance context)

---

## 29.0 Integration tests

- [x] 29.1 Create `tests/integration/storage/test_postgres.py` — Test `PostgresAuditSink`, `PostgresCausalGraphStore`, and `PostgresMemoryProvider` using a real PostgreSQL instance (via Docker or local).
- [x] 29.2 Create `tests/integration/providers/test_google_vertex.py` — Test `GoogleVertexProvider` with live credentials (optional/skipped by default).
- [x] 29.3 Create `tests/integration/providers/test_aws_bedrock.py` — Test `AWSBedrockProvider` with live credentials.
- [x] 29.4 Create `tests/integration/providers/test_azure_openai.py` — Test `AzureOpenAIProvider` with live credentials.
- [x] 29.5 Create `tests/integration/providers/test_huggingface.py` — Test `HuggingFaceProvider` with live credentials.
- [x] 29.6 Create `tests/integration/providers/test_onpremise.py` — Test `OnPremiseProvider` with a local vLLM instance.

### Relevant files
- All files under `tests/integration/`

---

## 30.0 Example scripts

- [x] 30.1 Create `examples/basic_generate.py` — Simple completion call.
- [x] 30.2 Create `examples/basic_agent_run.py` — Agent execution with step limits.
- [x] 30.3 Create `examples/knowledge_base_rag.py` — RAG retrieval and grounding.
- [x] 30.4 Create `examples/mcp_server_integration.py` — MCP server tool discovery.
- [x] 30.5 Create `examples/streaming_model_call.py` — Streaming response handling.
- [x] 30.6 Create `examples/approval_workflow.py` — Approval request/resolve cycle.
- [x] 30.7 Create `examples/structured_output_validation.py` — Schema enforcement.

### Relevant files
- All files under `examples/`

---

## 31.0 Final validation and PyPI readiness

- [x] 31.1 Verify all dependencies in `pyproject.toml` have correct versions.
- [x] 31.2 Verify `arelis/__init__.py` has all required top-level exports.
- [x] 31.3 Run `mypy --strict src/arelis` — Fix any major type errors.
- [x] 31.4 Run `ruff check src/arelis` — Fix any critical lint issues.
- [x] 31.5 Run the full test suite one last time: `pytest tests/unit`.
- [x] 31.6 Perform a final walkthrough of the `README.md` to ensure it matches the final implementation.
- [x] 31.7 Ensure a `LICENSE` file (MIT) is present in the root.
- [x] 31.8 Verify `pip install -e .` and `python -c "from arelis import ArelisClient"` works.
- [x] 31.9 Build distribution: `python -m build` and verify `dist/` contains `.whl` and `.tar.gz`.

### Relevant files
- `README.md`
- `LICENSE`
- `pyproject.toml`
- `src/arelis/__init__.py`

---

## Notes

- **Dependency order:** Tasks 0.0 → 1.0 must be done first. Tasks 2.0–17.0 can largely be parallelized (they are independent modules). Task 18.0 depends on all of 1.0–17.0. Tasks 19.0–27.0 can be parallelized after 18.0. Tasks 28.0–30.0 depend on the modules they test. Task 31.0 is the final gate.
- **TS reference:** Every sub-task instructs the implementer to read the corresponding TypeScript source file. The TS SDK at `/Users/ramon.marrero/arelis-sdk` is the source of truth.
- **Testing strategy:** Write tests alongside implementation (not deferred to the end) for better coverage. Task 28.0 captures the full test matrix but tests should be created as modules are completed.
- **No `Any`:** Use `object` or proper generics. `mypy --strict` enforces this.
- **No mutable defaults:** Always use `None` + factory pattern (e.g., `tags: dict[str, str] | None = None`).
