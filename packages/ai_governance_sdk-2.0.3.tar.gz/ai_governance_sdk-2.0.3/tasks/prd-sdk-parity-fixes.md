# PRD: SDK Parity Fixes

## 1. Overview

### Problem Statement
A comprehensive evaluation of the AI Governance SDK for Python against the TypeScript reference SDK (`/Users/ramon.marrero/arelis-sdk`) revealed 15 gaps across multiple modules. These range from critical API parity breaks (client method signatures, missing provider protocols, stub implementations) to medium/low priority issues (missing exports, field naming mismatches, missing utility functions). The SDK cannot be considered production-ready or fully API-compatible until these gaps are resolved.

### Solution
Address all 15 identified gaps across the Python SDK to achieve full API parity with the TypeScript SDK. This includes refactoring client method signatures, adding missing protocols and guard functions, implementing stub modules, fixing exports, and adding/updating unit tests for all changed modules.

### Target Audience
- Internal teams using the Python SDK for governed AI orchestration.
- External developers consuming `ai-governance-sdk` from PyPI who expect API parity with the TypeScript SDK.

### Success Criteria
- All 30 client methods accept proper input dataclass objects (not `**kwargs`).
- All 10 multi-modal provider protocols and 12 guard functions implemented.
- Agent runtime integrates policy checkpoints and audit event emission.
- Compliance `request_artifact()` and `replay_run()` are fully functional.
- All public types exported from `src/arelis/__init__.py`.
- `mypy --strict` passes with zero errors.
- `ruff check` passes with zero warnings.
- Unit test coverage remains >= 80% with new tests for all changed modules.

---

## 2. Functional Requirements

### FR-1: Client Method Signature Refactoring (Critical)
- **FR-1.1:** Create input dataclasses for all 11 methods currently using `**kwargs`: `mcp.register_server()`, `mcp.discover_tools()`, `knowledge.register_kb()`, `knowledge.retrieve()`, `memory.read()`, `memory.write()`, `memory.delete()`, `memory.list()`, `data_sources.register()`, `data_sources.read()`, `approvals.approve()`, `approvals.reject()`.
- **FR-1.2:** Refactor each method to accept a single input object matching the TypeScript SDK's pattern (e.g., `MemoryReadInput`, `RegisterMCPServerInput`).
- **FR-1.3:** Fix return types where they differ: `mcp.register_server()` should return `ToolDiscoveryFullResult`, `approvals.approve()`/`reject()` should return `None`, `compliance.request_artifact()` should return `ComplianceArtifact | ProofJob`.
- **FR-1.4:** Add missing input fields: `grounding` and `outputSchema` in `GenerateInput`, `streamOptions` in `GenerateStreamInput`, `discoveryOptions` in `RegisterMCPServerInput`, `options` in `RetrieveInput`.

### FR-2: Multi-Modal Provider Protocols (Critical)
- **FR-2.1:** Add 10 specialized provider protocol classes: `ImageGenerationProvider`, `AudioGenerationProvider`, `VideoGenerationProvider`, `ImageToTextProvider`, `ImageToAudioProvider`, `ImageToVideoProvider`, `AudioToTextProvider`, `AudioToImageProvider`, `AudioToVideoProvider`, `VideoToTextProvider`.
- **FR-2.2:** Add 12 guard functions: `supports_image_generation()`, `supports_audio_generation()`, `supports_video_generation()`, `supports_image_to_text()`, `supports_image_to_audio()`, `supports_image_to_video()`, `supports_audio_to_text()`, `supports_audio_to_image()`, `supports_audio_to_video()`, `supports_video_to_text()`, `supports_video_to_image()`, `supports_video_to_audio()`.
- **FR-2.3:** Add `has_capability_flag()` helper function.

### FR-3: Agent Runtime Governance Integration (Critical)
- **FR-3.1:** Add `policy_engine`, `audit_sink`, `compiled_policy`, `tool_runner`, and `tool_invoke_options` to `AgentRuntimeOptions`.
- **FR-3.2:** Implement policy checkpoint evaluation at `BeforeAgentStep` in the agent loop.
- **FR-3.3:** Emit audit events for agent steps, attestation creation, and memory operations.
- **FR-3.4:** Add `configure_runtime_governance()` method for injecting governance dependencies.
- **FR-3.5:** Pass policy decisions alongside agent results.

### FR-4: Compliance Implementation (Critical)
- **FR-4.1:** Implement full `request_artifact()` with proof job generation, async proof workflows, composed proofs, and disclosure rule resolution.
- **FR-4.2:** Implement full `replay_run()` with causal graph replay logic, step reconstruction, and drift diagnostics.
- **FR-4.3:** Support `ProofJob` return type from `request_artifact()` when `async=True`.

### FR-5: Public API Exports (High)
- **FR-5.1:** Export 21+ input types from `src/arelis/__init__.py`: `GenerateInput`, `GenerateStreamInput`, `AgentRunInput`, `PromptTemplateRef`, `GroundingInput`, `OutputSchema`, `OutputValidationMode`, `RegisterMCPServerInput`, `DiscoverMCPToolsInput`, `RegisterKBInput`, `RetrieveInput`, `MemoryReadInput`, `MemoryWriteInput`, `MemoryDeleteInput`, `DataSourceRegisterInput`, `DataSourceReadInput`, `ApprovalResolveInput`, `ComplianceArtifactRequest`, `ComplianceProofRequest`, `ComplianceVerificationInput`, `ComplianceReplayInput`.
- **FR-5.2:** Add missing exports to module-level `__init__.py` files (core, models, audit, etc.).

### FR-6: MCP HTTP Transport (High)
- **FR-6.1:** Implement full HTTP/SSE transport using `httpx` for MCP server communication.
- **FR-6.2:** Support SSE stream handling for server-to-client messages.
- **FR-6.3:** Support HTTP POST for client-to-server messages.
- **FR-6.4:** Implement JSON-RPC 2.0 message marshaling over HTTP.
- **FR-6.5:** Support request correlation and timeout handling.

### FR-7: Governance Gate PII/Redactor Integration (High)
- **FR-7.1:** Replace regex-based PII scanning with `Redactor` integration from the policy module.
- **FR-7.2:** Add `redactor` and `redactor_config` parameters to `ScanPromptForPiiOptions`.
- **FR-7.3:** Support configurable redaction patterns via the Redactor interface.

### FR-8: DisclosureProof Field Naming Fix (High)
- **FR-8.1:** Rename `DisclosureProof.root_hash` to `commitment_root` to match TypeScript's `commitmentRoot`.
- **FR-8.2:** Rename `DisclosureProof.event_hashes` to `rule_ids` to match TypeScript's `ruleIds`.
- **FR-8.3:** Update all references to these fields across compliance, audit, and proof modules.

### FR-9: CAG Missing Function (Medium)
- **FR-9.1:** Implement `find_inference_runs_from_lifecycle()` function in `audit/cag.py` matching the TypeScript implementation.

### FR-10: Google Vertex Embeddings (Medium)
- **FR-10.1:** Implement `create_vertex_embed_function()` for generating embeddings using Vertex AI's embedding models.
- **FR-10.2:** Support task types (RETRIEVAL_QUERY, SEMANTIC_SIMILARITY, etc.), output dimensionality control, and custom API endpoints.

### FR-11: ClientConfig Missing Fields (Medium)
- **FR-11.1:** Add missing `ComplianceConfig` typed fields to `ClientConfig`: `causal_graph_store`, `artifact_store`, `proof_provider`, `proof_job_queue`, `commitment_signer`, `disclosure_rules`, `proof_timeout_ms`.

### FR-12: Secrets Return Type Fix (Medium)
- **FR-12.1:** Change `resolve_secret_value()` return type from `tuple[str, SecretResolution]` to a `SecretResolutionResult` dataclass with `value` and `resolution` fields.

### FR-13: Missing Tests (Medium)
- **FR-13.1:** Add compliance module unit tests (`tests/unit/compliance/`).
- **FR-13.2:** Add storage module unit tests (`tests/unit/storage/`).

### FR-14: GovernanceGateDeniedError Enhancement (Low)
- **FR-14.1:** Store the full `PreInvocationGateDecision` in `GovernanceGateDeniedError` (not just reasons).

### FR-15: Extension Capability Flag Derivation (Low)
- **FR-15.1:** Derive `ExtensionCapabilityFlag` from `EXTENSION_NAMESPACE_CONTRACTS` instead of manually defining it as a Literal union.

---

## 3. Non-Functional Requirements

- **NFR-1:** All changes must pass `mypy --strict` with zero errors.
- **NFR-2:** All changes must pass `ruff check` with zero warnings.
- **NFR-3:** Unit test coverage must remain >= 80%.
- **NFR-4:** No breaking changes to existing public API (additive changes only where possible; for method signature changes, the new input-object pattern replaces kwargs).
- **NFR-5:** All changes must follow existing code conventions from CLAUDE.md.

---

## 4. User Stories

### US-1: Input Object API
As a developer, I want to call SDK methods with structured input objects (e.g., `client.memory.read(MemoryReadInput(...))`) instead of kwargs, so that my code matches the TypeScript SDK's API and benefits from type-safe input validation.

### US-2: Multi-Modal Provider Detection
As a developer, I want to check if a provider supports specific capabilities (e.g., `supports_image_generation(provider)`) before calling multi-modal methods, so that I can handle unsupported operations gracefully.

### US-3: Governed Agent Execution
As a developer, I want the agent runtime to automatically enforce policy checkpoints and emit audit events during execution, so that agent loops are fully governed and auditable.

### US-4: Compliance Proof Generation
As a developer, I want to call `client.compliance.request_artifact()` and receive a real compliance artifact with proof generation, so that I can produce auditable proofs of policy adherence.

### US-5: Complete Type Exports
As a developer, I want all input/output types to be importable from `arelis` (e.g., `from arelis import MemoryReadInput`), so that I don't have to reach into internal module paths.

### US-6: MCP HTTP Transport
As a developer, I want to connect to MCP servers over HTTP/SSE (not just stdio), so that I can integrate with remote tool servers.

---

## 5. Technical Constraints

- Must maintain backward compatibility where possible (kwargs can be supported alongside input objects during transition).
- Must follow the TypeScript SDK at `/Users/ramon.marrero/arelis-sdk` as the source of truth.
- All I/O methods remain `async def`.
- Use `typing.Protocol` for new provider interfaces.
- Use `@dataclass` for new input types.

---

## 6. Out of Scope

- CLI tool porting.
- Sync wrappers.
- Framework integrations (Django, FastAPI, Flask).
- New features not in the TypeScript SDK.
- Provider integration test updates (only unit tests are in scope).

---

## 7. Dependencies & Risks

| Dependency | Risk | Mitigation |
|---|---|---|
| Client signature refactoring | Breaking change for existing consumers | Provide deprecation warnings for kwargs pattern |
| Compliance implementation complexity | Proof generation involves cryptographic operations | Follow TS implementation closely |
| MCP HTTP transport | SSE handling complexity | Use httpx's streaming capabilities |
| Agent governance integration | Touches core agent loop | Extensive testing with mock policy engines |
