# PRD: AI Governance SDK for Python

## 1. Overview

### Problem Statement
The Arelis Governance SDK currently exists only as a TypeScript/Node.js package. Python is the dominant language in the AI/ML ecosystem, and teams building governed AI applications in Python have no native SDK. They must either call the TypeScript SDK via subprocess/HTTP shims or reimplement governance logic manually — both fragile and error-prone.

### Solution
Build `ai-governance-sdk`, a production-grade Python SDK that provides full API parity with the TypeScript Arelis Governance SDK. It will be a single installable package with optional extras for provider adapters, storage backends, and telemetry. The SDK enables Python developers to build governed AI applications with model routing, agent loops, tool invocation, policy enforcement, audit trails, and telemetry across multiple LLM providers.

### Target Audience
- **Internal teams:** Python-based services integrating governed AI orchestration.
- **External developers:** Published on PyPI as `ai-governance-sdk` for the broader Python AI community.

### Success Criteria
- Full API parity with all 13 client namespaces (30 methods) from the TypeScript SDK.
- All 5 provider adapters ported (Google Vertex, AWS Bedrock, Azure OpenAI, HuggingFace, On-Premise).
- `mypy --strict` passes with zero errors.
- `ruff` passes with zero warnings.
- Unit test coverage >= 80%.
- 7 runnable example scripts.
- Published to PyPI as `ai-governance-sdk`.

---

## 2. Functional Requirements

### FR-1: Core Runtime (Phase 1)
- **FR-1.1:** `GovernanceContext` dataclass with `org`, `actor`, `team`, `purpose`, `environment`, `session_id`, `request_id`, `tags`.
- **FR-1.2:** `ResultEnvelope[T]` generic dataclass with `run_id`, `output`, `usage`, `policy`, `warnings`.
- **FR-1.3:** Error hierarchy: `ArelisError` base with `PolicyBlockedError`, `PolicyApprovalRequiredError`, `EvaluationBlockedError`, `ProviderError`, `ToolError`, `TimeoutError`, `GovernanceGateDeniedError`. Each error has a guard function (`is_policy_blocked_error()`, etc.).
- **FR-1.4:** `generate_run_id()` producing ULID-prefixed `run_` strings.
- **FR-1.5:** `MiddlewarePipeline` supporting `use(name, middleware)` and `execute(ctx)`. `compose_middleware()` and `named_middleware()` helpers.
- **FR-1.6:** `ResultBuilder` for constructing `ResultEnvelope` with merge helpers.
- **FR-1.7:** `ApprovalStore` protocol with `InMemoryApprovalStore` implementation.
- **FR-1.8:** Replay engine for deterministic audit re-execution.

### FR-2: Model Abstraction (Phase 2 — Models)
- **FR-2.1:** `ModelRequest` and `ModelResponse` dataclasses with messages, parameters, and usage tracking.
- **FR-2.2:** `ModelProvider` protocol with `id`, `generate()`, `stream()`, `supports()`.
- **FR-2.3:** `ModelCapability` and `ModelDescriptor` for capability introspection.
- **FR-2.4:** `ModelRegistry` with `register()`, `resolve()`, `resolve_route_or_model()`.
- **FR-2.5:** `ModelRoute` and `ModelRouteCandidate` for data-class and residency-based routing.
- **FR-2.6:** `StreamChunk` type and async iterator streaming support.

### FR-3: Policy Engine (Phase 2 — Policy)
- **FR-3.1:** `PolicyEngine` protocol with evaluation at 5 checkpoints: `BeforePrompt`, `AfterModelOutput`, `BeforeToolCall`, `AfterToolResult`, `BeforePersist`.
- **FR-3.2:** `PolicyDecision` with effects: `allow`, `block`, `transform`, `require_approval`.
- **FR-3.3:** `PolicyModeEngine` with enforcement modes: `enforce`, `monitor`, `off`.
- **FR-3.4:** `PolicyCompiler` for deterministic policy snapshot hashing.
- **FR-3.5:** `Redactor` with PII and credential pattern detection.
- **FR-3.6:** `RiskRouter` for risk-adaptive runtime routing decisions.
- **FR-3.7:** Classification-based policy support.
- **FR-3.8:** Data retention enforcement.

### FR-4: Audit & Compliance (Phase 3)
- **FR-4.1:** `AuditEvent` with 35+ event type literals covering run, policy, model, tool, agent, KB, memory, data source, approval, evaluation, quota, output validation, secret, prompt, MCP, compliance, risk, and snapshot events.
- **FR-4.2:** `AuditSink` protocol with `ConsoleSink` built-in.
- **FR-4.3:** `DataRef` discriminated union: `inline`, `blob`, `hash`.
- **FR-4.4:** Causal Audit Graph (CAG): `CausalGraph`, `CausalGraphNode`, `CausalGraphEdge`, `CausalGraphStore` protocol with in-memory implementation.
- **FR-4.5:** `DisclosureProof` and `HashProofProvider` for selective disclosure.
- **FR-4.6:** `ComplianceArtifact`, `ProofJob`, compliance verification via `verify_compliance_artifact()`.

### FR-5: Feature Modules (Phase 4)
- **FR-5.1:** `ToolRegistry` — register, list, invoke tools with `ToolDefinition`, `ToolHandler`, `ToolResult`. JSON Schema validation for tool inputs.
- **FR-5.2:** MCP integration — `MCPRegistry` with `register_server()`, `discover_tools()`, `invoke_tool_on_server()`. Three transports: `StdioMCPTransport`, `HttpMCPTransport`, `MockMCPTransport`.
- **FR-5.3:** Knowledge/RAG — `KBRegistry`, `KBProvider` protocol, `apply_grounding()`. Built-in `MemoryKBProvider` with BM25 + cosine scoring.
- **FR-5.4:** Prompts — `TemplateRegistry` with register, get, list. `compute_prompt_hash()` for content hashing.
- **FR-5.5:** Memory — `MemoryRegistry`, `MemoryProvider` protocol. Scopes: `ephemeral`, `session`, `longterm`, `shared`. Built-in `InMemoryMemoryProvider`.
- **FR-5.6:** Data Sources — `DataSourceRegistry`, `DataSourceProvider` protocol, read API.
- **FR-5.7:** Evaluations — `Evaluator` protocol, `run_evaluations()` orchestrator, findings with severity levels.
- **FR-5.8:** Quotas — `QuotaManager` protocol, `InMemoryQuotaManager`. Quota decisions: `allow`, `limit`, `deny`.
- **FR-5.9:** Secrets — `SecretResolver` protocol, `EnvSecretResolver`. Redaction patterns for API keys, passwords, credentials, tokens.

### FR-6: Agents (Phase 5)
- **FR-6.1:** `AgentRuntime` with governed agent loop.
- **FR-6.2:** `AgentRunInput` with model, tools, context, and limits (`max_steps`, `max_duration_ms`).
- **FR-6.3:** `AgentResult[T]` with `success`, `output`, `steps_executed`, `error`.
- **FR-6.4:** `AgentMemory` protocol for agent-scoped memory.

### FR-7: Governance Gate & Extensions (Phase 6)
- **FR-7.1:** `GovernanceGateEvaluator` with `resolve_context()`, `evaluate_policy()`.
- **FR-7.2:** `scan_prompt_for_pii()` for pre-invocation PII scanning.
- **FR-7.3:** `evaluate_pre_invocation_gate()` and `with_governance_gate()` wrappers.
- **FR-7.4:** `GovernanceGateDeniedError` with full decision payload.
- **FR-7.5:** Extension system with 7 extension IDs and capability flags.
- **FR-7.6:** `ClientExtensionsConfig` for composed proofs, risk routing, snapshot replay.

### FR-8: ArelisClient (Phase 7)
- **FR-8.1:** `ClientConfig` dataclass with all registry/engine/sink/telemetry fields.
- **FR-8.2:** `ArelisClient` class with 13 descriptor-based namespace objects.
- **FR-8.3:** `create_arelis_client()` factory function.
- **FR-8.4:** Full method parity — 30 methods across 13 namespaces (see API Parity Checklist in PLAN.md).

### FR-9: Provider Adapters (Phase 8)
- **FR-9.1:** `BaseModelProvider` ABC with shared implementation logic.
- **FR-9.2:** Provider conformance test helpers.
- **FR-9.3:** `GoogleVertexProvider` — text, streaming, embeddings, multimodal via `google-cloud-aiplatform`.
- **FR-9.4:** `AWSBedrockProvider` — Anthropic, Cohere, Stability AI models via `boto3`.
- **FR-9.5:** `AzureOpenAIProvider` — OpenAI models on Azure via `openai`.
- **FR-9.6:** `HuggingFaceProvider` — text generation, image generation via `huggingface-hub`.
- **FR-9.7:** `OnPremiseProvider` — vLLM, text-generation-webui compatible via `httpx`.

### FR-10: Observability & Storage (Phase 9)
- **FR-10.1:** `Telemetry` protocol with `SpanHandle`. `NoOpTelemetry` default.
- **FR-10.2:** `OTelAdapter` for OpenTelemetry integration with span names: `model.resolve`, `model.generate`, `model.stream`, `agent.run`, `tool.invoke`, `kb.retrieve`.
- **FR-10.3:** `HttpAuditSink` with batching, flush intervals, and auth (bearer, basic, apikey).
- **FR-10.4:** PostgreSQL storage: `PostgresAuditSink`, `PostgresCausalGraphStore`, `PostgresMemoryProvider`, migrations via `asyncpg` + `alembic`.

### FR-11: Tests & Examples (Phase 10)
- **FR-11.1:** Unit tests — one test file per module, ≥ 80% coverage.
- **FR-11.2:** Integration tests for providers and storage.
- **FR-11.3:** Provider conformance test suite.
- **FR-11.4:** 7 example scripts: basic model call, basic agent run, knowledge base RAG, MCP server integration, streaming model call, approval workflow, structured output validation.

---

## 3. Non-Functional Requirements

- **NFR-1:** Python ≥ 3.10 required.
- **NFR-2:** Async-first — all I/O methods are `async def`. No sync wrappers.
- **NFR-3:** `mypy --strict` must pass with zero errors. `py.typed` marker included.
- **NFR-4:** `ruff` linting and formatting with zero warnings. 4-space indent, 100-char line width, double quotes.
- **NFR-5:** Minimal core dependencies (`httpx`, `jsonschema`). All heavy dependencies via optional extras.
- **NFR-6:** Strict API parity with the TypeScript SDK — no additions, no omissions.
- **NFR-7:** PEP 621 compliant packaging via `hatchling` and `pyproject.toml`.

---

## 4. User Stories

### US-1: Basic Model Generation
As a developer, I want to call `await client.models.generate(input)` and receive a `ResultEnvelope[ModelResponse]` with governance context, so that I can generate AI responses with policy enforcement and audit trails.

### US-2: Streaming Responses
As a developer, I want to call `await client.models.generate_stream(input)` and iterate over `AsyncIterator[StreamChunk]`, so that I can process AI responses incrementally with governance applied to each chunk.

### US-3: Agent Execution
As a developer, I want to call `await client.agents.run(input)` with tools and limits, so that I can run governed agent loops that auto-invoke tools and respect step/duration limits.

### US-4: Policy Enforcement
As a developer, I want the SDK to automatically evaluate policies at all 5 checkpoints and block/transform/require-approval when policies are violated, so that I can trust that all AI operations comply with organizational policies.

### US-5: Audit Trail
As a developer, I want every SDK operation to emit structured `AuditEvent`s to configured sinks, so that I have a complete, immutable audit trail for compliance.

### US-6: Knowledge Base RAG
As a developer, I want to register knowledge bases and apply grounding to model requests via `client.knowledge.retrieve()`, so that I can build RAG applications with governed retrieval.

### US-7: MCP Integration
As a developer, I want to register MCP servers and discover tools via `client.mcp.register_server()` and `client.mcp.discover_tools()`, so that I can connect to external tool servers.

### US-8: Provider Flexibility
As a developer, I want to swap provider adapters (Vertex, Bedrock, Azure, HuggingFace, on-prem) by changing configuration, so that I can run the same governed application across different LLM backends.

### US-9: Compliance Verification
As a developer, I want to request and verify compliance artifacts via `client.compliance`, so that I can produce auditable proofs of policy adherence.

### US-10: Quota Management
As a developer, I want to check and commit quotas via `client.quotas`, so that I can enforce budget and usage limits on AI operations.

---

## 5. Technical Constraints

- Must follow the TypeScript SDK as source of truth — read TS source before implementing.
- `typing.Protocol` for pluggable interfaces; ABCs only when shared implementation is needed.
- `@dataclass` for objects; `TypedDict` for inline config dicts.
- No `Any` — use `object` or `Unknown` patterns.
- No default mutable arguments — use `None` + factory pattern.
- Single package with optional extras (not a monorepo).

---

## 6. Out of Scope

- CLI tool (the TS SDK has `governance-cli` and `deploy-kubernetes` — not ported).
- Sync wrappers — async-first only.
- Framework integrations (Django, FastAPI, Flask).
- Additional features not in the TypeScript SDK.

---

## 7. Dependencies & Risks

| Dependency | Risk | Mitigation |
|---|---|---|
| TypeScript SDK stability | TS SDK changes during Python port | Pin to current TS SDK version as reference |
| Provider Python SDK availability | Provider SDKs may differ in API shape | Adapt to each provider's Python SDK idioms |
| `asyncio` ecosystem | Some libraries may lack async support | Use `httpx` (async-native) and `asyncpg` |
| Large surface area (3,500-line client) | Risk of incomplete parity | Phase incrementally, test each phase independently |
| PyPI publication | Naming conflicts | Reserve `ai-governance-sdk` name early |
