# AI Governance SDK for Python — Implementation Plan

## Overview

Port the **Arelis Governance SDK** from TypeScript to Python, preserving the same architecture, API surface, and functionality. The TypeScript SDK is a monorepo with 28 packages organized around a unified `ArelisClient`. The Python SDK will be a single installable package (`ai-governance-sdk`) with optional extras for provider adapters and storage backends.

---

## 1. Project Structure

```
ai-governance-sdk/
├── pyproject.toml                    # Build config, dependencies, extras
├── README.md
├── LICENSE
├── CHANGELOG.md
├── PLAN.md                           # This file
├── src/
│   └── arelis/                       # Root namespace package
│       ├── __init__.py               # Top-level exports (ArelisClient, etc.)
│       ├── py.typed                  # PEP 561 marker
│       │
│       ├── core/                     # ← governance-core
│       │   ├── __init__.py
│       │   ├── types.py              # GovernanceContext, ResultEnvelope, RunWarning
│       │   ├── run_context.py        # generate_run_id, context resolution
│       │   ├── middleware.py         # MiddlewarePipeline, compose_middleware
│       │   ├── result.py             # ResultBuilder, merge helpers
│       │   ├── errors.py             # ArelisError hierarchy + guards
│       │   ├── replay.py             # Replay engine
│       │   └── approval_store.py     # InMemoryApprovalStore
│       │
│       ├── models/                   # ← governance-models
│       │   ├── __init__.py
│       │   ├── types.py              # ModelRequest, ModelResponse, StreamChunk, ModelUsage
│       │   ├── registry.py           # ModelRegistry
│       │   ├── provider.py           # ModelProvider protocol/ABC
│       │   ├── routing.py            # ModelRoute, ModelRouteCandidate
│       │   └── capabilities.py       # ModelCapability, ModelDescriptor
│       │
│       ├── policy/                   # ← governance-policy
│       │   ├── __init__.py
│       │   ├── engine.py             # PolicyEngine, PolicyModeEngine
│       │   ├── compiler.py           # PolicyCompiler, snapshot hashing
│       │   ├── types.py              # PolicyDecision, PolicyCheckpoint, PolicyResult
│       │   ├── redactor.py           # Redactor, PII pattern detection
│       │   ├── risk_router.py        # RiskRouter, risk-adaptive routing
│       │   ├── classifier.py         # Classification-based policies
│       │   └── retention.py          # Data retention enforcement
│       │
│       ├── audit/                    # ← governance-audit
│       │   ├── __init__.py
│       │   ├── types.py              # AuditEvent, all event type literals
│       │   ├── sink.py               # AuditSink protocol, ConsoleSink
│       │   ├── cag.py                # CausalGraph, CausalGraphNode/Edge
│       │   ├── cag_store.py          # CausalGraphStore protocol
│       │   ├── proof.py              # DisclosureProof, HashProofProvider
│       │   ├── data_ref.py           # DataRef (inline, blob, hash)
│       │   └── artifacts.py          # ComplianceArtifact, ProofJob
│       │
│       ├── agents/                   # ← governance-agents
│       │   ├── __init__.py
│       │   ├── runtime.py            # AgentRuntime, agent loop
│       │   ├── types.py              # AgentRunInput, AgentResult, AgentLimits
│       │   └── memory.py             # AgentMemory protocol
│       │
│       ├── tools/                    # ← governance-tools
│       │   ├── __init__.py
│       │   ├── registry.py           # ToolRegistry
│       │   └── types.py              # ToolDefinition, ToolHandler, ToolResult
│       │
│       ├── mcp/                      # ← governance-mcp
│       │   ├── __init__.py
│       │   ├── registry.py           # MCPRegistry
│       │   ├── types.py              # MCPServerDescriptor, MCPToolSchema
│       │   ├── transports/
│       │   │   ├── __init__.py
│       │   │   ├── base.py           # MCPTransport protocol
│       │   │   ├── stdio.py          # StdioMCPTransport
│       │   │   ├── http.py           # HttpMCPTransport
│       │   │   └── mock.py           # MockMCPTransport
│       │   └── discovery.py          # ToolDiscoveryResult, DiscoveredTool
│       │
│       ├── knowledge/                # ← governance-knowledge
│       │   ├── __init__.py
│       │   ├── registry.py           # KBRegistry
│       │   ├── types.py              # KnowledgeBaseDescriptor, RetrievalResult, RetrievedChunk
│       │   ├── provider.py           # KBProvider protocol
│       │   ├── grounding.py          # apply_grounding, GroundingInput
│       │   └── memory_kb.py          # MemoryKBProvider (in-memory BM25 + cosine)
│       │
│       ├── prompts/                  # ← governance-prompts
│       │   ├── __init__.py
│       │   ├── registry.py           # TemplateRegistry
│       │   └── types.py              # PromptTemplate, PromptTemplateInput/Query
│       │
│       ├── memory/                   # ← governance-memory
│       │   ├── __init__.py
│       │   ├── registry.py           # MemoryRegistry
│       │   ├── types.py              # MemoryScope, MemoryEntry
│       │   ├── provider.py           # MemoryProvider protocol
│       │   └── in_memory.py          # InMemoryMemoryProvider
│       │
│       ├── data_sources/             # ← governance-data-sources
│       │   ├── __init__.py
│       │   ├── registry.py           # DataSourceRegistry
│       │   ├── types.py              # DataSourceDescriptor, DataSourceResult
│       │   └── provider.py           # DataSourceProvider protocol
│       │
│       ├── evaluations/              # ← governance-evaluations
│       │   ├── __init__.py
│       │   ├── runner.py             # run_evaluations
│       │   └── types.py              # Evaluator protocol, EvaluationInput/Result/Finding
│       │
│       ├── quotas/                   # ← governance-quotas
│       │   ├── __init__.py
│       │   ├── manager.py            # QuotaManager protocol
│       │   ├── types.py              # QuotaKey, QuotaUsage, QuotaDecision
│       │   └── in_memory.py          # InMemoryQuotaManager
│       │
│       ├── secrets/                  # ← governance-secrets
│       │   ├── __init__.py
│       │   ├── resolver.py           # SecretResolver protocol, EnvSecretResolver
│       │   ├── types.py              # SecretResolution, SecretRedactionPattern
│       │   └── patterns.py           # get_secret_redaction_patterns
│       │
│       ├── compliance/               # Compliance helpers (from sdk package)
│       │   ├── __init__.py
│       │   ├── verification.py       # verify_compliance_artifact
│       │   └── types.py              # ComplianceProofRequest, ComplianceVerificationInput
│       │
│       ├── governance_gate/          # Governance gate (from sdk package)
│       │   ├── __init__.py
│       │   ├── evaluator.py          # GovernanceGateEvaluator
│       │   ├── gate.py               # evaluate_pre_invocation_gate, with_governance_gate
│       │   ├── pii.py                # scan_prompt_for_pii
│       │   └── types.py              # PreInvocationGateDecision, GovernanceGateDeniedError
│       │
│       ├── extensions/               # Extension system (from sdk package)
│       │   ├── __init__.py
│       │   ├── contracts.py          # ExtensionId, ExtensionCapabilityFlag
│       │   └── config.py             # ClientExtensionsConfig
│       │
│       ├── client.py                 # ArelisClient — unified entry point
│       ├── config.py                 # ClientConfig dataclass
│       │
│       ├── providers/                # Provider adapters (optional extras)
│       │   ├── __init__.py
│       │   ├── shared/
│       │   │   ├── __init__.py
│       │   │   ├── base.py           # BaseModelProvider
│       │   │   └── conformance.py    # Conformance test helpers
│       │   ├── google_vertex/
│       │   │   ├── __init__.py
│       │   │   └── provider.py       # GoogleVertexProvider
│       │   ├── aws_bedrock/
│       │   │   ├── __init__.py
│       │   │   └── provider.py       # AWSBedrockProvider
│       │   ├── azure_openai/
│       │   │   ├── __init__.py
│       │   │   └── provider.py       # AzureOpenAIProvider
│       │   ├── huggingface/
│       │   │   ├── __init__.py
│       │   │   └── provider.py       # HuggingFaceProvider
│       │   └── onpremise/
│       │       ├── __init__.py
│       │       └── provider.py       # OnPremiseProvider
│       │
│       ├── telemetry/                # OpenTelemetry integration (optional extra)
│       │   ├── __init__.py
│       │   ├── types.py              # Telemetry protocol, SpanHandle
│       │   ├── otel.py               # OTelAdapter
│       │   └── noop.py               # NoOpTelemetry
│       │
│       ├── sinks/                    # Audit sinks (optional extras)
│       │   ├── __init__.py
│       │   └── http.py               # HttpAuditSink, HttpSinkConfig
│       │
│       └── storage/                  # Storage backends (optional extras)
│           ├── __init__.py
│           └── postgres/
│               ├── __init__.py
│               ├── audit_sink.py     # PostgresAuditSink
│               ├── cag_store.py      # PostgresCausalGraphStore
│               ├── memory_provider.py# PostgresMemoryProvider
│               └── migrations.py     # run_migrations, should_migrate
│
├── tests/
│   ├── conftest.py
│   ├── unit/
│   │   ├── core/
│   │   ├── models/
│   │   ├── policy/
│   │   ├── audit/
│   │   ├── agents/
│   │   ├── tools/
│   │   ├── mcp/
│   │   ├── knowledge/
│   │   ├── prompts/
│   │   ├── memory/
│   │   ├── data_sources/
│   │   ├── evaluations/
│   │   ├── quotas/
│   │   ├── secrets/
│   │   ├── compliance/
│   │   ├── governance_gate/
│   │   ├── extensions/
│   │   └── test_client.py
│   └── integration/
│       ├── providers/
│       └── storage/
│
└── examples/
    ├── basic_model_call.py
    ├── basic_agent_run.py
    ├── knowledge_base_rag.py
    ├── mcp_server_integration.py
    ├── streaming_model_call.py
    ├── approval_workflow.py
    └── structured_output_validation.py
```

---

## 2. Technology & Tooling Choices

| Concern | Choice | Rationale |
|---|---|---|
| **Python version** | ≥ 3.10 | `match` statements, `ParamSpec`, `TypeAlias` |
| **Build system** | `hatchling` via `pyproject.toml` | Modern, PEP 621 compliant |
| **Type checking** | `mypy` (strict) + `py.typed` marker | Parity with full TS typing |
| **Testing** | `pytest` + `pytest-asyncio` | Standard, async-first |
| **Linting/Formatting** | `ruff` | Fast, replaces flake8+isort+black |
| **Async runtime** | `asyncio` (native) | Match TS `async/await` |
| **HTTP client** | `httpx` | Async support, modern API |
| **Protocols** | `typing.Protocol` | Duck-typed interfaces like TS interfaces |
| **Dataclasses** | `dataclasses` + `TypedDict` | Parity with TS types/interfaces |
| **Streaming** | `AsyncIterator` / `AsyncGenerator` | Parity with TS `AsyncIterable` |
| **JSON Schema** | `jsonschema` | For tool input validation |

---

## 3. Python ↔ TypeScript Mapping Conventions

| TypeScript | Python |
|---|---|
| `interface Foo { ... }` | `@dataclass` or `TypedDict` or `Protocol` |
| `type Foo = { ... }` | `@dataclass` or `TypedDict` |
| `type Foo = 'a' \| 'b'` | `Literal['a', 'b']` |
| `enum Foo { A, B }` | `enum.StrEnum` / `enum.IntEnum` |
| `async function` | `async def` |
| `AsyncIterable<T>` | `AsyncIterator[T]` |
| `Promise<T>` | Coroutine returning `T` |
| `Record<string, T>` | `dict[str, T]` |
| `T \| undefined` | `T \| None` |
| `class Foo implements Bar` | `class Foo(Bar)` (Protocol or ABC) |
| Namespace (`client.models.xxx`) | Descriptor-based namespace objects |
| `export { ... }` | `__all__` in `__init__.py` |

---

## 4. Implementation Phases

### Phase 1 — Foundation (Core + Types)

**Goal:** Establish the type system, error hierarchy, and core runtime utilities.

| # | Module | Key Deliverables |
|---|---|---|
| 1.1 | `core/types.py` | `GovernanceContext`, `ResultEnvelope`, `RunWarning` |
| 1.2 | `core/errors.py` | `ArelisError`, `PolicyBlockedError`, `PolicyApprovalRequiredError`, `EvaluationBlockedError`, `ProviderError`, `ToolError`, `TimeoutError`, guard functions |
| 1.3 | `core/run_context.py` | `generate_run_id()`, context resolution/merging |
| 1.4 | `core/middleware.py` | `MiddlewarePipeline`, `compose_middleware()`, `named_middleware()` |
| 1.5 | `core/result.py` | `ResultBuilder`, result merging helpers |
| 1.6 | `core/approval_store.py` | `ApprovalStore` protocol, `InMemoryApprovalStore` |
| 1.7 | `core/replay.py` | Replay engine for audit re-execution |

### Phase 2 — Models & Policy

**Goal:** Model provider abstraction, registry, routing, and policy engine.

| # | Module | Key Deliverables |
|---|---|---|
| 2.1 | `models/types.py` | `ModelRequest`, `ModelResponse`, `StreamChunk`, `ModelUsage`, `GenerateOptions` |
| 2.2 | `models/provider.py` | `ModelProvider` Protocol |
| 2.3 | `models/capabilities.py` | `ModelCapability`, `ModelDescriptor` |
| 2.4 | `models/registry.py` | `ModelRegistry` (register, resolve, route) |
| 2.5 | `models/routing.py` | `ModelRoute`, `ModelRouteCandidate`, routing logic |
| 2.6 | `policy/types.py` | `PolicyDecision`, `PolicyCheckpoint`, `PolicyResult`, `PolicyEnforcementMode` |
| 2.7 | `policy/engine.py` | `PolicyEngine` Protocol, `PolicyModeEngine` |
| 2.8 | `policy/compiler.py` | `PolicyCompiler`, deterministic snapshot hashing |
| 2.9 | `policy/redactor.py` | `Redactor`, PII/credential pattern detection |
| 2.10 | `policy/risk_router.py` | `RiskRouter`, risk-adaptive routing decisions |
| 2.11 | `policy/classifier.py` | Classification-based policies |
| 2.12 | `policy/retention.py` | Data retention enforcement |

### Phase 3 — Audit & Compliance

**Goal:** Full audit event system, CAG, and compliance artifacts.

| # | Module | Key Deliverables |
|---|---|---|
| 3.1 | `audit/types.py` | All audit event types (35+ event literals), `AuditEvent` |
| 3.2 | `audit/sink.py` | `AuditSink` Protocol, `ConsoleSink` |
| 3.3 | `audit/data_ref.py` | `DataRef` (inline, blob, hash variants) |
| 3.4 | `audit/cag.py` | `CausalGraph`, `CausalGraphNode`, `CausalGraphEdge` |
| 3.5 | `audit/cag_store.py` | `CausalGraphStore` Protocol, in-memory impl |
| 3.6 | `audit/proof.py` | `DisclosureProof`, `HashProofProvider`, selective disclosure |
| 3.7 | `audit/artifacts.py` | `ComplianceArtifact`, `ProofJob` |
| 3.8 | `compliance/types.py` | `ComplianceProofRequest`, `ComplianceVerificationInput` |
| 3.9 | `compliance/verification.py` | `verify_compliance_artifact()` |

### Phase 4 — Feature Modules

**Goal:** Implement all feature registries and protocols.

| # | Module | Key Deliverables |
|---|---|---|
| 4.1 | `tools/types.py` | `ToolDefinition`, `ToolHandler`, `ToolResult`, `ToolPermissions` |
| 4.2 | `tools/registry.py` | `ToolRegistry` (register, list, invoke) |
| 4.3 | `mcp/types.py` | `MCPServerDescriptor`, `MCPToolSchema`, `MCPTransportConfig` |
| 4.4 | `mcp/transports/` | `MCPTransport` Protocol, stdio/http/mock impls |
| 4.5 | `mcp/discovery.py` | `ToolDiscoveryResult`, `DiscoveredTool` |
| 4.6 | `mcp/registry.py` | `MCPRegistry` (register, discover, invoke) |
| 4.7 | `knowledge/types.py` | `KnowledgeBaseDescriptor`, `RetrievalResult`, `RetrievedChunk` |
| 4.8 | `knowledge/provider.py` | `KBProvider` Protocol |
| 4.9 | `knowledge/registry.py` | `KBRegistry` (register, retrieve) |
| 4.10 | `knowledge/grounding.py` | `apply_grounding()`, `GroundingInput`, `GroundingResult` |
| 4.11 | `knowledge/memory_kb.py` | `MemoryKBProvider` (BM25 + cosine) |
| 4.12 | `prompts/types.py` | `PromptTemplate`, `PromptTemplateInput`, `PromptTemplateQuery` |
| 4.13 | `prompts/registry.py` | `TemplateRegistry`, `compute_prompt_hash()` |
| 4.14 | `memory/types.py` | `MemoryScope`, `MemoryEntry` |
| 4.15 | `memory/provider.py` | `MemoryProvider` Protocol |
| 4.16 | `memory/registry.py` | `MemoryRegistry` |
| 4.17 | `memory/in_memory.py` | `InMemoryMemoryProvider` |
| 4.18 | `data_sources/types.py` | `DataSourceDescriptor`, `DataSourceResult`, `DataSourceQuery` |
| 4.19 | `data_sources/provider.py` | `DataSourceProvider` Protocol |
| 4.20 | `data_sources/registry.py` | `DataSourceRegistry` |
| 4.21 | `evaluations/types.py` | `Evaluator` Protocol, `EvaluationInput`, `EvaluationResult`, `EvaluationFinding` |
| 4.22 | `evaluations/runner.py` | `run_evaluations()` |
| 4.23 | `quotas/types.py` | `QuotaKey`, `QuotaUsage`, `QuotaDecision` |
| 4.24 | `quotas/manager.py` | `QuotaManager` Protocol |
| 4.25 | `quotas/in_memory.py` | `InMemoryQuotaManager` |
| 4.26 | `secrets/types.py` | `SecretResolution`, `SecretRedactionPattern` |
| 4.27 | `secrets/resolver.py` | `SecretResolver` Protocol, `EnvSecretResolver` |
| 4.28 | `secrets/patterns.py` | `get_secret_redaction_patterns()` |

### Phase 5 — Agents

**Goal:** Agent runtime loop with governance integration.

| # | Module | Key Deliverables |
|---|---|---|
| 5.1 | `agents/types.py` | `AgentRunInput`, `AgentResult`, `AgentLimits` |
| 5.2 | `agents/memory.py` | `AgentMemory` Protocol |
| 5.3 | `agents/runtime.py` | `AgentRuntime`, governed agent loop |

### Phase 6 — Governance Gate & Extensions

**Goal:** Pre-invocation governance gate and extension system.

| # | Module | Key Deliverables |
|---|---|---|
| 6.1 | `governance_gate/types.py` | `PreInvocationGateDecision`, `GovernanceGateDeniedError` |
| 6.2 | `governance_gate/pii.py` | `scan_prompt_for_pii()` |
| 6.3 | `governance_gate/evaluator.py` | `GovernanceGateEvaluator` |
| 6.4 | `governance_gate/gate.py` | `evaluate_pre_invocation_gate()`, `with_governance_gate()` |
| 6.5 | `extensions/contracts.py` | `ExtensionId`, `ExtensionCapabilityFlag` |
| 6.6 | `extensions/config.py` | `ClientExtensionsConfig` |

### Phase 7 — ArelisClient (Unified Entry Point)

**Goal:** Port the main `ArelisClient` class with all 13 namespaced APIs.

| # | Module | Key Deliverables |
|---|---|---|
| 7.1 | `config.py` | `ClientConfig` dataclass |
| 7.2 | `client.py` | `ArelisClient` with namespaces: `models`, `agents`, `mcp`, `knowledge`, `prompts`, `memory`, `data_sources`, `approvals`, `evaluations`, `quotas`, `secrets`, `compliance`, `governance` |
| 7.3 | `__init__.py` | Public API exports, `create_arelis_client()` factory |

### Phase 8 — Provider Adapters

**Goal:** Port all five model provider adapters.

| # | Module | Key Deliverables |
|---|---|---|
| 8.1 | `providers/shared/` | `BaseModelProvider`, conformance test helpers |
| 8.2 | `providers/google_vertex/` | `GoogleVertexProvider` (google-cloud-aiplatform) |
| 8.3 | `providers/aws_bedrock/` | `AWSBedrockProvider` (boto3) |
| 8.4 | `providers/azure_openai/` | `AzureOpenAIProvider` (openai) |
| 8.5 | `providers/huggingface/` | `HuggingFaceProvider` (huggingface-hub) |
| 8.6 | `providers/onpremise/` | `OnPremiseProvider` (httpx) |

### Phase 9 — Observability & Storage

**Goal:** Telemetry, sinks, and storage backends.

| # | Module | Key Deliverables |
|---|---|---|
| 9.1 | `telemetry/types.py` | `Telemetry` Protocol, `SpanHandle` |
| 9.2 | `telemetry/noop.py` | `NoOpTelemetry` |
| 9.3 | `telemetry/otel.py` | `OTelAdapter` (opentelemetry-api) |
| 9.4 | `sinks/http.py` | `HttpAuditSink`, `HttpSinkConfig` |
| 9.5 | `storage/postgres/` | `PostgresAuditSink`, `PostgresCausalGraphStore`, `PostgresMemoryProvider`, migrations |

### Phase 10 — Tests & Examples

**Goal:** Comprehensive test coverage and usage examples.

| # | Deliverable | Details |
|---|---|---|
| 10.1 | Unit tests | One test file per module, matching TS test coverage |
| 10.2 | Integration tests | Provider + storage integration tests |
| 10.3 | Conformance tests | Provider conformance suite |
| 10.4 | Examples | 7 example scripts matching TS examples |

---

## 5. Package Configuration (`pyproject.toml`)

```toml
[project]
name = "ai-governance-sdk"
version = "1.0.0"
requires-python = ">=3.10"
dependencies = [
    "httpx>=0.27",
    "jsonschema>=4.20",
]

[project.optional-dependencies]
google-vertex = ["google-cloud-aiplatform>=1.40"]
aws-bedrock = ["boto3>=1.34"]
azure-openai = ["openai>=1.10"]
huggingface = ["huggingface-hub>=0.20"]
otel = ["opentelemetry-api>=1.20", "opentelemetry-sdk>=1.20"]
postgres = ["asyncpg>=0.29", "alembic>=1.13"]
all = ["ai-governance-sdk[google-vertex,aws-bedrock,azure-openai,huggingface,otel,postgres]"]
dev = ["pytest>=8.0", "pytest-asyncio>=0.23", "mypy>=1.8", "ruff>=0.2"]
```

---

## 6. Key Design Decisions

### 6.1 Protocols vs ABCs

Use `typing.Protocol` for pluggable interfaces (ModelProvider, AuditSink, SecretResolver, etc.) to enable structural subtyping — the same duck-typing philosophy as TypeScript interfaces. Use ABCs only when shared implementation logic is needed (e.g., `BaseModelProvider`).

### 6.2 Dataclasses vs TypedDict

- **Dataclasses** for objects that are instantiated and passed around (GovernanceContext, ResultEnvelope, etc.)
- **TypedDict** for dictionary-shaped input configs that users construct inline
- Both support full type checking

### 6.3 Async-First

All I/O-bound methods are `async def`, matching the TypeScript SDK's `Promise`-based API:
- `client.models.generate()` → `await client.models.generate()`
- `client.models.generate_stream()` → returns `AsyncIterator[StreamChunk]`

### 6.4 Namespace Pattern

TypeScript uses property namespaces (`client.models.generate()`). Python will use descriptor-based namespace objects:

```python
class ArelisClient:
    def __init__(self, config: ClientConfig):
        self.models = _ModelsNamespace(self)
        self.agents = _AgentsNamespace(self)
        # ...
```

### 6.5 Error Guards

TypeScript uses `isPolicyBlockedError()` functions. Python will provide both:
- Functions: `is_policy_blocked_error(err)` for functional style
- `isinstance()` checks for Pythonic style

### 6.6 Single Package with Extras

Instead of 28 npm packages, the Python SDK ships as one package (`ai-governance-sdk`) with optional extras for heavy dependencies (provider SDKs, postgres, otel). This simplifies installation while keeping the dependency footprint small for basic usage.

---

## 7. API Parity Checklist

| TypeScript API | Python Equivalent | Status |
|---|---|---|
| `client.models.generate()` | `await client.models.generate()` | ☐ |
| `client.models.generateStream()` | `await client.models.generate_stream()` → `AsyncIterator` | ☐ |
| `client.agents.run()` | `await client.agents.run()` | ☐ |
| `client.mcp.registerServer()` | `await client.mcp.register_server()` | ☐ |
| `client.mcp.discoverTools()` | `await client.mcp.discover_tools()` | ☐ |
| `client.mcp.getRegistry()` | `client.mcp.get_registry()` | ☐ |
| `client.knowledge.registerKB()` | `await client.knowledge.register_kb()` | ☐ |
| `client.knowledge.retrieve()` | `await client.knowledge.retrieve()` | ☐ |
| `client.prompts.register()` | `await client.prompts.register()` | ☐ |
| `client.prompts.get()` | `client.prompts.get()` | ☐ |
| `client.prompts.list()` | `client.prompts.list()` | ☐ |
| `client.memory.read()` | `await client.memory.read()` | ☐ |
| `client.memory.write()` | `await client.memory.write()` | ☐ |
| `client.memory.delete()` | `await client.memory.delete()` | ☐ |
| `client.memory.list()` | `await client.memory.list()` | ☐ |
| `client.dataSources.register()` | `await client.data_sources.register()` | ☐ |
| `client.dataSources.read()` | `await client.data_sources.read()` | ☐ |
| `client.approvals.approve()` | `await client.approvals.approve()` | ☐ |
| `client.approvals.reject()` | `await client.approvals.reject()` | ☐ |
| `client.approvals.list()` | `await client.approvals.list()` | ☐ |
| `client.approvals.get()` | `await client.approvals.get()` | ☐ |
| `client.evaluations.run()` | `await client.evaluations.run()` | ☐ |
| `client.quotas.check()` | `await client.quotas.check()` | ☐ |
| `client.quotas.commit()` | `await client.quotas.commit()` | ☐ |
| `client.secrets.resolve()` | `await client.secrets.resolve()` | ☐ |
| `client.compliance.requestArtifact()` | `await client.compliance.request_artifact()` | ☐ |
| `client.compliance.getArtifacts()` | `await client.compliance.get_artifacts()` | ☐ |
| `client.compliance.verifyArtifact()` | `await client.compliance.verify_artifact()` | ☐ |
| `client.compliance.replayRun()` | `await client.compliance.replay_run()` | ☐ |
| `client.governance.createGateEvaluator()` | `client.governance.create_gate_evaluator()` | ☐ |

---

## 8. Naming Conventions

| TypeScript | Python |
|---|---|
| `camelCase` methods | `snake_case` methods |
| `PascalCase` types/classes | `PascalCase` classes |
| `camelCase` properties | `snake_case` attributes |
| `SCREAMING_SNAKE` constants | `SCREAMING_SNAKE` constants |
| File names: `kebab-case.ts` | File names: `snake_case.py` |

---

## 9. Risk & Mitigations

| Risk | Mitigation |
|---|---|
| TS SDK surface is very large (3,500-line client) | Phase incrementally; each phase is self-contained and testable |
| Async ecosystem differences | Use `asyncio` natively; provide sync wrappers only if needed later |
| Provider SDK differences across languages | Leverage each cloud provider's official Python SDK |
| No direct equivalent of TS generics with constraints | Use `TypeVar` with bounds and `Generic[T]` |
| MCP stdio transport complexity | Use `asyncio.subprocess` for process management |

---

## 10. Definition of Done

- [ ] All 13 client namespaces implemented with full method parity
- [ ] All types/dataclasses match TS interfaces
- [ ] All 5 provider adapters ported
- [ ] Audit event system with CAG fully functional
- [ ] Policy engine with all checkpoints operational
- [ ] Comprehensive unit tests (≥80% coverage)
- [ ] `mypy --strict` passes with zero errors
- [ ] `ruff` passes with zero warnings
- [ ] 7 example scripts run successfully
- [ ] `py.typed` marker present for downstream type checking
- [ ] Published to PyPI as `ai-governance-sdk`
