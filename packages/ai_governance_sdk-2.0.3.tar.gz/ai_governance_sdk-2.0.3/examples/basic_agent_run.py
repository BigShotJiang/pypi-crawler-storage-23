"""Governed agent execution example.

Demonstrates running a simple agent with step limits and governance context.

Usage:
    python examples/basic_agent_run.py
"""

from __future__ import annotations

import asyncio

from arelis import (
    ArelisClient,
    GovernanceContext,
    create_arelis_client,
)
from arelis.agents import AgentLimits, AgentRunInput


async def main() -> None:
    # 1. Create the client (using default in-memory registries)
    client = create_arelis_client()

    # 2. Define governance context
    context = GovernanceContext(
        actor={"id": "agent-manager", "type": "system"},
        org={"id": "org-1"},
        purpose="automated-task",
        environment="production",
    )

    # 3. Define agent execution input
    agent_input = AgentRunInput(
        agent="research-bot",
        input="Find the latest news on AI safety.",
        limits=AgentLimits(max_steps=5, max_duration_ms=30000),
    )

    # 4. Run the agent
    print("Starting agent run...")
    result = await client.agents.run(
        input=agent_input,
        context=context,
    )

    print(f"Run ID: {result.run_id}")
    if result.success:
        print(f"Agent Output: {result.output}")
    else:
        print(f"Agent Failed: {result.error}")
    
    print(f"Steps Executed: {result.steps_executed}")


if __name__ == "__main__":
    asyncio.run(main())
