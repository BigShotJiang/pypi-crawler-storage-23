"""Audit trail example.

Demonstrates capturing and inspecting audit events using the memory sink.

Usage:
    python examples/audit_trail.py
"""

from __future__ import annotations

import asyncio

from arelis.audit import (
    MemorySink,
    MemorySinkConfig,
    RunStartedEvent,
    create_memory_sink,
    to_audit_context,
)
from arelis.core.run_context import generate_run_id
from arelis.core.types import GovernanceContext


async def main() -> None:
    # 1. Create a memory sink to capture events
    sink = create_memory_sink()

    # 2. Create a governance context
    context = GovernanceContext(
        actor={"id": "user-1", "type": "human"},
        org={"id": "org-1", "name": "Acme Corp"},
        purpose="audit-demo",
        environment="development",
    )

    # 3. Emit some events
    run_id = generate_run_id()
    audit_context = to_audit_context(context)

    event = RunStartedEvent(
        run_id=run_id,
        context=audit_context,
    )
    await sink.emit(event)

    # 4. Inspect captured events
    events = sink.get_events()
    print(f"Captured {len(events)} events:")
    for evt in events:
        print(f"  - {evt.__class__.__name__}: run_id={evt.run_id}")


if __name__ == "__main__":
    asyncio.run(main())
