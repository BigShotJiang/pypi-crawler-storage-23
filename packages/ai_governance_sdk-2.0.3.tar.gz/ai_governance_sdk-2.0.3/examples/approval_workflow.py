"""Governed approval workflow example.

Demonstrates requesting and resolving human-in-the-loop approvals.

Usage:
    python examples/approval_workflow.py
"""

from __future__ import annotations

import asyncio

from arelis import create_arelis_client


async def main() -> None:
    # 1. Create client
    client = create_arelis_client()

    # 2. Simulate a task requiring approval (manually check policies or just use the API)
    # The client.approvals namespace manages the pending requests.
    
    print("Listing pending approvals...")
    approvals = await client.approvals.list(status="pending")
    print(f"Pending: {len(approvals)}")

    # 3. Approve a request (if one existed, here we just show the API)
    if approvals:
        target_id = approvals[0].id
        print(f"Approving request {target_id}...")
        await client.approvals.approve(
            approval_id=target_id,
            resolved_by="admin-1",
            reason="Validated by security team.",
        )
        print("Approved.")
    else:
        print("No pending approvals found to demonstrate resolution.")


if __name__ == "__main__":
    asyncio.run(main())
