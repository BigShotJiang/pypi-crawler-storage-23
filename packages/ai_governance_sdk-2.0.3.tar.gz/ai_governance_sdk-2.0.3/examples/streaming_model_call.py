"""Streaming model generation example.

Demonstrates how to handle streaming responses from a model.

Usage:
    python examples/streaming_model_call.py
"""

from __future__ import annotations

import asyncio

from arelis import create_arelis_client
from arelis.models import GenerateStreamInput


async def main() -> None:
    # 1. Create client
    client = create_arelis_client()

    # 2. Start a streaming generation
    print("Starting stream...")
    stream = await client.models.generate_stream(
        input=GenerateStreamInput(
            model="gpt-4",
            messages=[{"role": "user", "content": "Write a short poem about space."}],
        )
    )

    # 3. Iterate over chunks
    async for chunk in stream:
        if chunk.content:
            print(chunk.content, end="", flush=True)
    
    print("\nStream finished.")


if __name__ == "__main__":
    asyncio.run(main())
