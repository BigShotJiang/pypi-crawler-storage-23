"""Platform API quickstart: policy evaluation and risk routing."""

from arelis import create_arelis_platform

platform = create_arelis_platform(
    {
        "baseUrl": "https://api.arelis.digital",
        "apiKey": "ak_live_or_test",
    }
)

policy = platform.governance.evaluatePolicy(
    {
        "runId": "run_abc",
        "checkpoint": "BeforePrompt",
        "data": {
            "prompt": "Summarize this customer ticket",
        },
    }
)
print("policy", policy)

risk = platform.risk.evaluate(
    {
        "runId": "run_abc",
        "policyDecisions": [],
        "quotaState": {},
        "evaluationSignals": [],
    }
)
print("risk", risk)
