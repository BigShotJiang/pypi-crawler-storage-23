"""Tool registry example.

Demonstrates registering and invoking tools with the Arelis SDK.

Usage:
    python examples/tool_registry.py
"""

from __future__ import annotations

import asyncio

from arelis.tools import (
    ToolDefinition,
    ToolRegistry,
    ToolResult,
    create_tool_registry,
)


async def main() -> None:
    # 1. Create a tool registry
    registry = create_tool_registry()

    # 2. Define a tool
    async def calculator(arguments: dict[str, object]) -> ToolResult:
        """A simple calculator tool."""
        a = float(str(arguments.get("a", 0)))
        b = float(str(arguments.get("b", 0)))
        op = str(arguments.get("operation", "add"))

        if op == "add":
            result = a + b
        elif op == "subtract":
            result = a - b
        elif op == "multiply":
            result = a * b
        elif op == "divide":
            if b == 0:
                return ToolResult(output="Error: division by zero", is_error=True)
            result = a / b
        else:
            return ToolResult(output=f"Unknown operation: {op}", is_error=True)

        return ToolResult(output=str(result))

    tool_def = ToolDefinition(
        name="calculator",
        description="Perform basic arithmetic operations",
        input_schema={
            "type": "object",
            "properties": {
                "a": {"type": "number", "description": "First operand"},
                "b": {"type": "number", "description": "Second operand"},
                "operation": {
                    "type": "string",
                    "enum": ["add", "subtract", "multiply", "divide"],
                    "description": "The arithmetic operation",
                },
            },
            "required": ["a", "b", "operation"],
        },
        handler=calculator,
    )

    # 3. Register the tool
    registry.register(tool_def)

    # 4. List registered tools
    tools = registry.list()
    print(f"Registered tools: {[t.name for t in tools]}")

    # 5. Invoke the tool
    result = await registry.invoke(
        "calculator",
        {"a": 10, "b": 3, "operation": "multiply"},
    )
    print(f"10 * 3 = {result.output}")


if __name__ == "__main__":
    asyncio.run(main())
