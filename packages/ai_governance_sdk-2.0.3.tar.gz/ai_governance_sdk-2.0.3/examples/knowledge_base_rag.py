"""Knowledge base and RAG example.

Demonstrates registering a knowledge base and retrieving grounded results.

Usage:
    python examples/knowledge_base_rag.py
"""

from __future__ import annotations

import asyncio

from arelis import create_arelis_client
from arelis.knowledge import (
    KnowledgeBaseDescriptor,
    RetrievalQuery,
    create_memory_kb_provider,
)


async def main() -> None:
    # 1. Create client
    client = create_arelis_client()

    # 2. Register an in-memory knowledge base
    kb_provider = create_memory_kb_provider()
    # (In a real scenario, you'd add documents to the provider first)
    
    client.knowledge.register_kb(
        descriptor=KnowledgeBaseDescriptor(
            id="kb-docs",
            name="Documentation",
            type="memory",
        ),
        provider=kb_provider,
    )

    # 3. Retrieve information
    print("Retrieving from KB...")
    query = RetrievalQuery(text="How do I configure the policy engine?")
    result = await client.knowledge.retrieve(
        kb_id="kb-docs",
        query=query,
    )

    print(f"Found {len(result.chunks)} chunks.")
    for i, chunk in enumerate(result.chunks):
        print(f"Chunk {i+1} (Score: {chunk.score:.2f}): {chunk.text[:100]}...")


if __name__ == "__main__":
    asyncio.run(main())
