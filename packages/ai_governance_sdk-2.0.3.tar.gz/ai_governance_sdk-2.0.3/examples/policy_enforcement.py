"""Policy enforcement example.

Demonstrates how to use the policy engine to enforce rules on model
requests, including blocking and redaction.

Usage:
    python examples/policy_enforcement.py
"""

from __future__ import annotations

import asyncio

from arelis.policy import (
    PolicyCheckpoint,
    Redactor,
    create_redactor,
)


async def main() -> None:
    # 1. Create a redactor with default patterns
    redactor = create_redactor()

    # 2. Redact sensitive content
    text = "Contact john@example.com or call 555-123-4567 for details."
    result = redactor.redact(text)

    print(f"Original: {text}")
    print(f"Redacted: {result.redacted}")
    print(f"Findings: {len(result.findings)}")
    for finding in result.findings:
        print(f"  - {finding.type}: '{finding.original}' at ({finding.start}, {finding.end})")


if __name__ == "__main__":
    asyncio.run(main())
