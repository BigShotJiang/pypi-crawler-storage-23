"""Platform API quickstart: create and list audit events."""

from arelis import create_arelis_platform

platform = create_arelis_platform(
    {
        "baseUrl": "https://api.arelis.digital",
        "apiKey": "ak_live_or_test",
    }
)

created = platform.events.create(
    {
        "runId": "run_123",
        "eventType": "model.invoked",
        "actor": {"type": "service", "id": "sdk"},
        "resource": {"type": "model", "id": "gpt-4o"},
        "action": "invoke",
        "timestamp": "2026-02-18T00:00:00Z",
    }
)
print("created", created)

listed = platform.events.list({"runId": "run_123", "limit": 20})
print("events", listed)
