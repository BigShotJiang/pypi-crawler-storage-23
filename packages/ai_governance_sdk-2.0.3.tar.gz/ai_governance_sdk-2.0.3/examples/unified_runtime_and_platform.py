"""Unified factory quickstart for runtime and platform surfaces."""

from arelis import ClientConfig, create_arelis

instance = create_arelis(
    {
        "runtime": ClientConfig(
            model_registry=my_model_registry,  # noqa: F821
            policy_engine=my_policy_engine,  # noqa: F821
            audit_sink=my_audit_sink,  # noqa: F821
        ),
        "platform": {
            "baseUrl": "https://api.arelis.digital",
            "apiKey": "ak_live_or_test",
        },
    }
)

runtime = instance["runtime"]
platform = instance["platform"]

print(runtime)
print(platform.organization.get())
