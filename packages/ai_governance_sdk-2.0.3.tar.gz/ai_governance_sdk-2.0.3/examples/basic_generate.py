"""Basic model generation example.

Demonstrates the simplest usage of the Arelis AI SDK: registering
a model provider and generating a completion.

Usage:
    python examples/basic_generate.py
"""

from __future__ import annotations

import asyncio

from arelis import GovernanceContext, create_arelis_client
from arelis.audit import create_console_sink
from arelis.models import (
    GenerateInput,
    ModelRegistry,
    ModelResponse,
    create_model_registry,
)
from arelis.policy import create_allow_all_engine


async def main() -> None:
    # 1. Set up registries
    model_registry = create_model_registry()
    policy_engine = create_allow_all_engine()
    audit_sink = create_console_sink()

    # 2. Create the client
    client = create_arelis_client(
        model_registry=model_registry,
        policy_engine=policy_engine,
        audit_sink=audit_sink,
    )

    # 3. Define governance context
    context = GovernanceContext(
        actor={"id": "user-1", "type": "human"},
        org={"id": "org-1", "name": "Acme Corp"},
        purpose="demo",
        environment="development",
    )

    # 4. Generate a completion
    result = await client.models.generate(
        input=GenerateInput(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello, world!"}],
        ),
        context=context,
    )

    print(f"Run ID: {result.run_id}")
    print(f"Output: {result.output}")
    print(f"Warnings: {result.warnings}")


if __name__ == "__main__":
    asyncio.run(main())
