"""MCP (Model Context Protocol) integration example.

Demonstrates registering an MCP server and discovering its tools.

Usage:
    python examples/mcp_server_integration.py
"""

from __future__ import annotations

import asyncio

from arelis import create_arelis_client
from arelis.mcp import MCPServerDescriptor
from arelis.mcp.transports.mock import create_mock_mcp_transport


async def main() -> None:
    # 1. Create client
    client = create_arelis_client()

    # 2. Register a mock MCP server
    # In practice, use StdioMCPTransport or HttpMCPTransport for real servers
    transport = create_mock_mcp_transport()
    
    await client.mcp.register_server(
        descriptor=MCPServerDescriptor(
            id="weather-service",
            name="Weather Service",
            version="1.0.0",
        ),
        transport=transport,
    )

    # 3. Discover tools from the server
    print("Discovering tools from MCP server...")
    tools_result = await client.mcp.discover_tools(server_id="weather-service")

    print(f"Discovered {len(tools_result.tools)} tools:")
    for tool in tools_result.tools:
        print(f" - {tool.name}: {tool.description}")


if __name__ == "__main__":
    asyncio.run(main())
