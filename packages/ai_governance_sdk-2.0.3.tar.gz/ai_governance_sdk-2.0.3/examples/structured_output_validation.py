"""Structured output validation example.

Demonstrates enforcing JSON schemas and validating model outputs.

Usage:
    python examples/structured_output_validation.py
"""

from __future__ import annotations

import asyncio

from arelis import create_arelis_client
from arelis.models import GenerateInput


async def main() -> None:
    # 1. Create client
    client = create_arelis_client()

    # 2. Define a JSON schema for the output
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
        },
        "required": ["name", "age"],
    }

    # 3. Generate with validation
    print("Generating structured output...")
    try:
        result = await client.models.generate(
            input=GenerateInput(
                model="gpt-4",
                messages=[{"role": "user", "content": "Extract: My name is Alice and I am 30 years old."}],
                output_schema=schema,
            )
        )
        print(f"Validated JSON Output: {result.output}")
    except Exception as e:
        print(f"Validation Error: {e}")


if __name__ == "__main__":
    asyncio.run(main())
