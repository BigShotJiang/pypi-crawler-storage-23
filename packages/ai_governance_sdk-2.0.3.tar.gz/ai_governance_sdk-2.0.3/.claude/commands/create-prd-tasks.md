Generate a PRD and task list for a feature request. This command runs 4 stages sequentially, pausing for user input between stages.

**Input:** $ARGUMENTS (the feature request or description)

---

## Stage 1: Generate PRD

Follow the process defined in `docs/create-prd.md` exactly:

1. Read `docs/create-prd.md` for the full PRD generation rules.
2. Analyze the user's feature request: "$ARGUMENTS"
3. Ask 3-5 clarifying questions using userAskQuestions.
4. **STOP and wait for the user's answers.** Do not proceed until the user responds.
5. After receiving answers, generate the PRD using the structure from `docs/create-prd.md`.
6. Save it to `/tasks/prd-[feature-name].md`.
7. Present the PRD to the user and say: **"Stage 1 complete. PRD saved. Proceeding with Stage 2..."**
8. **Continue with Stage 2.**

## Stage 2: Generate Parent Tasks

Follow the process defined in `docs/generate-tasks.md` exactly:

1. Read `docs/generate-tasks.md` for the full task generation rules.
2. Analyze the PRD created in Stage 1.
3. Generate the parent (high-level) tasks. Always include task 0.0 "Create feature branch" as the first task.
4. Identify the relevant files section.
5. Save the initial task list (parent tasks only, no sub-tasks yet) to `/tasks/tasks-[feature-name].md`.
6. Present the parent tasks to the user and say: **"Stage 2 complete. Parent tasks generated. Proceeding with Stage 3..."**
7. **Continue with Stage 3.**

## Stage 3: Generate Sub-Tasks

1. For each parent task from Stage 2, generate detailed, actionable sub-tasks as specified in `docs/generate-tasks.md`.
2. Ensure sub-tasks are specific enough for a junior developer to implement without ambiguity.
3. Update `/tasks/tasks-[feature-name].md` with the complete task list (parents + sub-tasks + relevant files + notes).
4. Present the full task list to the user and say: **"Stage 3 complete. Sub-tasks generated. Proceeding with Stage 4..."**
5. **Continue with Stage 4.**

## Stage 4: Gap Analysis (PRD vs Tasks)

Perform a thorough gap analysis between the PRD and the task list:

1. Re-read both `/tasks/prd-[feature-name].md` and `/tasks/tasks-[feature-name].md`.
2. For each functional requirement in the PRD, verify there is at least one task/sub-task that addresses it.
3. For each user story in the PRD, verify the task list covers the described workflow end-to-end.
4. Check for:
   - **Missing coverage:** PRD requirements with no corresponding task.
   - **Orphaned tasks:** Tasks that don't trace back to any PRD requirement.
   - **Incomplete flows:** User stories only partially covered by tasks.
   - **Missing test tasks:** Features without corresponding test/validation tasks.
   - **Missing error handling:** Happy paths covered but edge cases or error states missing.
5. If gaps are found:
   - List each gap with the PRD requirement reference and what is missing.
   - Add the missing tasks/sub-tasks to the task file.
   - Update the relevant files section if new files are needed.
6. If no gaps are found, confirm the task list fully covers the PRD.
7. Present the gap analysis results and say: **"Stage 4 complete. Gap analysis finished."**

## Final Output

Confirm the two deliverables:
- `/tasks/prd-[feature-name].md` — the PRD
- `/tasks/tasks-[feature-name].md` — the complete task list with sub-tasks
- Provide an analysis of what was produced as well as impact of the new feature. 

## Important

- Do NOT skip stages or combine them. Each stage must complete before the next begins.
- Do NOT start implementing any code. This command is for planning only.
- Always wait for user input between stages (clarifying answers after Stage 1, "Go" for Stages 2-4).
- Use the same `[feature-name]` slug for both filenames so they are clearly paired.
