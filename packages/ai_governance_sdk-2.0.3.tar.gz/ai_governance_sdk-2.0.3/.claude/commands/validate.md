Run the post-task validation loop. This MUST be executed after completing any implementation task.

## Steps

1. Run `ruff check src/ tests/` to check for linting errors.
   - If lint fails: fix the issues, then re-run lint (max 2 retries).

2. Run `ruff format --check src/ tests/` to verify formatting.
   - If formatting fails: run `ruff format src/ tests/` to fix, then re-check.

3. Run `mypy src/arelis` to verify type checking passes.
   - If mypy fails: fix the type errors, then re-run (max 2 retries).
   - Do NOT use `# type: ignore` unless absolutely necessary and documented.

4. Run `pytest` for the affected test files (or full suite if core modules changed).
   - If tests fail: fix the issues, then re-run (max 2 retries).
   - Do NOT skip or delete failing tests.

5. If any validation step fails after retries:
   - Document the root cause in the appropriate `.claude/fixes/*.md` file using the template from `.claude/fixes/TEMPLATE.md`
   - Update `.claude/fixes/INDEX.md` with the new entry count
   - Stop and report the failure to the user

6. If all validations pass:
   - Append a progress entry to `.claude/progress.log` summarizing the completed task
   - Report success with a short summary of what was validated

## Important

- Do NOT skip steps. Run them in order.
- Do NOT run the full test suite unless core modules changed — run only affected test files for scoped changes.
- If a new gotcha is discovered during validation, always record it in `.claude/fixes/` before reporting success.
