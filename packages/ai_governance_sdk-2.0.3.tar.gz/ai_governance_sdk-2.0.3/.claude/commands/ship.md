Commit all staged and unstaged changes, push to develop, merge into main, and return to develop. Follow these steps exactly:

1. Run `git status` (never use -uall) and `git diff` and `git log --oneline -5` in parallel to understand what changed.
2. Stage all modified and untracked files with `git add -A`, then create a commit. Analyze the changes and write a conventional commit message (feat/fix/chore/refactor/docs) that summarizes the "why". End the message with the Co-Authored-By trailer.
3. Push the commit to origin develop: `git push origin develop`.
4. Switch to main and merge develop: `git checkout main && git pull origin main && git merge develop`.
5. Push main: `git push origin main`.
6. Switch back to develop: `git checkout develop`.
7. Print a short summary of what was committed and confirm all branches are up to date.

If any step fails, stop immediately and report the error — do NOT force-push or use destructive flags.
