# Fix Entry Templates

## Short Format (simple fixes)

```
### [DATE] — Short title
**Symptom:** What happened / what error you saw
**Fix:** What you changed
**Rule:** One-line rule to prevent recurrence
```

## Extended Format (multi-attempt fixes)

```
### [DATE] — Short title
**Symptom:** What happened / what error you saw
**Root cause:** Why it happened (the non-obvious part)
**Attempted fixes:**
1. First thing tried — why it didn't work
2. Second thing tried — why it didn't work
**Actual fix:** What finally worked
**Rule:** One-line rule to prevent recurrence
**Files changed:** List of files modified
```
