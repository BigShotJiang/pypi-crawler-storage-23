# Fix Index

| File | Category | Entries | Last Updated | Trend |
|---|---|---|---|---|
| `typing.md` | mypy strict mode, Protocols, generics | 0 | — | — |
| `async.md` | asyncio patterns, event loops, iterators | 0 | — | — |
| `providers.md` | Provider adapters, SDK versions | 0 | — | — |
| `testing.md` | pytest-asyncio, mocking async code | 0 | — | — |

**Total fixes:** 0
**Last review:** —
