# Typing Fixes

mypy strict mode issues, Protocol definitions, generic constraints, and type narrowing.

<!-- Append new entries below this line -->
