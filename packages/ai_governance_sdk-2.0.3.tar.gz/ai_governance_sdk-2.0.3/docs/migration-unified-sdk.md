# Migration: Runtime-Only to Unified SDK (2.x)

## What changed
- `ai-governance-sdk` remains the package name.
- Platform API is now included in the same package.
- New unified factory: `create_arelis({ runtime?, platform? })`.
- Runtime factory still works: `create_arelis_client(...)`.

## Runtime-only code (no change required)
```python
from arelis import create_arelis_client

client = create_arelis_client(config)
```

## New platform-only usage
```python
from arelis import create_arelis_platform

platform = create_arelis_platform({
    "baseUrl": "https://api.arelis.digital",
    "apiKey": "ak_test",
})
```

## Unified usage
```python
from arelis import create_arelis

sdk = create_arelis({
    "runtime": runtime_config,
    "platform": {"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test"},
})

runtime = sdk["runtime"]
platform = sdk["platform"]
```

## Naming compatibility
- Snake case: `create_arelis_client`, `create_arelis_platform`, `create_arelis`.
- Camel case aliases: `createArelisClient`, `createArelisPlatform`, `createArelis`.
