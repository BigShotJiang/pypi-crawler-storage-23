# CLAUDE.md

AI Governance SDK for Python (`ai-governance-sdk`) — a Python port of the Arelis Governance SDK (TypeScript). Governed AI orchestration: model routing, agent loops, tool invocation, policy enforcement, audit trails, and telemetry across multiple LLM providers. See `PLAN.md` for the detailed implementation plan (read on demand).

The reference TypeScript SDK lives at `/Users/ramon.marrero/arelis-sdk`. This Python SDK must maintain full API parity with it.

## Commands

```bash
pip install -e ".[dev]"               # Install in editable mode with dev deps
pytest                                # Run all tests
pytest tests/unit/core/test_errors.py # Run a specific test file
pytest --cov=arelis --cov-report=term-missing  # Tests with coverage
mypy src/arelis                       # Type checking (strict mode)
ruff check src/ tests/                # Lint
ruff format src/ tests/               # Format
ruff check --fix src/ tests/          # Auto-fix lint issues
```

IMPORTANT: Always run `mypy src/arelis` after modifying type signatures or adding new modules. Always run `ruff check` and `ruff format` before committing. After adding new public APIs, update `src/arelis/__init__.py`.

## Verification

After making changes, verify your work:
- Run `ruff check src/ tests/` after any code changes
- Run `ruff format --check src/ tests/` to verify formatting
- Run `mypy src/arelis` after type signature changes or new modules
- Run `pytest` for the affected test files (or all tests if changes are broad)
- For provider adapters: run the conformance tests in `providers/shared/`
- Only run the full test suite when explicitly requested or when core modules changed — do NOT run it after every small task

## Code Style (differs from defaults)

- **Python version:** ≥ 3.10 (for `match` statements, `ParamSpec`, `TypeAlias`)
- Double quotes, not single quotes (see `[tool.ruff.format]` in pyproject.toml)
- 100-char line width, trailing commas in multi-line structures
- Import sorting (isort-compatible via Ruff)
- 4-space indent
- Files: `snake_case.py` (e.g., `model_registry.py`, `run_context.py`)
- Classes/Types/Protocols: `PascalCase` (e.g., `RunContext`, `ModelProvider`)
- Functions/variables: `snake_case` (e.g., `generate_run_id`)
- Constants: `SCREAMING_SNAKE_CASE` (e.g., `DEFAULT_MAX_STEPS`)
- Private/internal: prefix with `_` (e.g., `_ModelsNamespace`, `_resolve_context`)
- Prefix unused params with `_`
- Named exports only in `__init__.py` — use explicit `__all__` lists
- **Strict typing** — `mypy --strict` must pass with zero errors. Include `py.typed` marker.
- **No `Any`** — Use `object`, `Unknown` patterns, or proper generics
- **Async-first** — All I/O methods are `async def`. Use `asyncio` natively. No sync wrappers unless explicitly requested.
- **Protocols over ABCs** — Use `typing.Protocol` for pluggable interfaces. Use ABCs only when shared implementation is needed.
- **Dataclasses for models** — `@dataclass` for objects passed around. `TypedDict` for dictionary-shaped input configs.
- **No default mutable arguments** — Use `None` + factory pattern (e.g., `field(default_factory=list)`)

## IMPORTANT: Library Versions & Documentation Lookup

**Before writing code that uses any external library, YOU MUST use the Context7 MCP to look up the latest documentation.** This is non-negotiable. Do NOT rely on training data for SDK/library APIs — they go stale.

How: Use the `context7` MCP tools (`resolve-library-id` then `query-docs`) to fetch current API signatures, import paths, and usage patterns before writing any integration code.

This applies to: AI/LLM provider SDKs, async HTTP clients, database drivers, OpenTelemetry, and any third-party package where the API may have changed.

### Known SDK corrections (do NOT use the old versions)

| Library | CORRECT usage | WRONG (deprecated) usage |
|---|---|---|
| httpx async | `async with httpx.AsyncClient() as client:` | ~~`requests.get()`~~ (sync, wrong library) |
| google-cloud-aiplatform | Check Context7 — API changes frequently | ~~Hardcoded import paths from training data~~ |
| boto3 bedrock | `client.invoke_model()` | ~~`client.invoke_model_with_response_stream()`~~ (check current API) |
| opentelemetry | `from opentelemetry import trace` | ~~`from opentelemetry.trace import ...`~~ (verify with Context7) |

## Architecture (non-obvious decisions)

- **GovernanceContext** — Every operation requires actor identity, org, purpose, and environment. Threads through audit, policy, and telemetry. Never optional.
- **ResultEnvelope[T]** — All operations return `ResultEnvelope` with `run_id`, `output`, `usage`, `policy`, `warnings`. The `run_id` (ULID prefixed `run_`) traces the full request.
- **Middleware pipeline** — Core orchestration chains async middleware functions via `MiddlewarePipeline`. Order matters — policy before model, audit after.
- **Registry pattern** — Pluggable registries for models, tools, knowledge, memory, MCP servers, data sources. Register implementations, look them up at runtime. Always import from the registry, never instantiate providers directly.
- **Protocol-based interfaces** — Use `typing.Protocol` for pluggable contracts (ModelProvider, AuditSink, SecretResolver, etc.). Structural subtyping like TS interfaces.
- **Provider adapters** — Each LLM provider implements `ModelProvider` protocol. Conformance tests in `providers/shared/` ensure consistency. New providers MUST pass conformance tests.
- **Policy checkpoints** — Enforcement at `BeforePrompt`, `AfterModelOutput`, `BeforeToolCall`, `AfterToolResult`, `BeforePersist`. Never skip a checkpoint.
- **Audit trail** — Immutable events with `DataRef`-based payload handling. Sinks: console, HTTP, PostgreSQL.
- **Namespace objects** — Client API uses descriptor-based namespace objects: `client.models.generate()`, `client.agents.run()`, etc.

### Client Namespaces (13 APIs)

| Namespace | Methods |
|---|---|
| `client.models` | `generate()`, `generate_stream()` |
| `client.agents` | `run()` |
| `client.mcp` | `register_server()`, `discover_tools()`, `get_registry()` |
| `client.knowledge` | `register_kb()`, `retrieve()`, `get_registry()` |
| `client.prompts` | `register()`, `get()`, `list()` |
| `client.memory` | `read()`, `write()`, `delete()`, `list()` |
| `client.data_sources` | `register()`, `read()`, `get_registry()` |
| `client.approvals` | `approve()`, `reject()`, `list()`, `get()` |
| `client.evaluations` | `run()` |
| `client.quotas` | `check()`, `commit()` |
| `client.secrets` | `resolve()` |
| `client.compliance` | `request_artifact()`, `get_artifacts()`, `verify_artifact()`, `replay_run()` |
| `client.governance` | `create_gate_evaluator()` |

### TypeScript → Python Mapping

| TypeScript | Python |
|---|---|
| `interface Foo` | `class Foo(Protocol)` or `@dataclass` |
| `type Foo = { ... }` | `@dataclass` or `TypedDict` |
| `type Foo = 'a' \| 'b'` | `Literal['a', 'b']` |
| `async function` | `async def` |
| `AsyncIterable<T>` | `AsyncIterator[T]` |
| `Promise<T>` | `async def -> T` |
| `Record<string, T>` | `dict[str, T]` |
| `T \| undefined` | `T \| None` |
| `client.dataSources.read()` | `client.data_sources.read()` |
| `isPolicyBlockedError()` | `is_policy_blocked_error()` + `isinstance()` |

## Testing

- **Framework:** pytest + pytest-asyncio (asyncio_mode = "auto" in pyproject.toml)
- **Location:** `tests/unit/<module>/test_<file>.py` mirroring `src/arelis/` structure
- **Async tests:** Automatically detected by pytest-asyncio (`asyncio_mode = "auto"`)
- **Coverage:** ≥ 80% target, use `pytest-cov`
- **Integration tests:** Under `tests/integration/`, may require running services
- Test both success and error paths. Mock external dependencies.
- Provider conformance tests in `providers/shared/` — all providers must pass.

## Project Structure

```
src/arelis/
  __init__.py            # Top-level exports (ArelisClient, create_arelis_client, etc.)
  py.typed               # PEP 561 marker for downstream type checking
  client.py              # ArelisClient — unified entry point with 13 namespaced APIs
  config.py              # ClientConfig dataclass

  core/                  # Runtime orchestration, middleware, errors, context
  models/                # Model registry, provider protocol, routing, capabilities
  policy/                # Policy engine, compiler, redactor, risk router
  audit/                 # Audit events, sinks, Causal Audit Graph, proofs
  agents/                # Agent runtime loop and memory
  tools/                 # Tool registry, invocation, permissions
  mcp/                   # MCP server registry, transports (stdio/http/mock), discovery
  knowledge/             # Knowledge base retrieval and grounding (RAG)
  prompts/               # Prompt template registry with versioning and hashing
  memory/                # Memory provider registry (ephemeral/session/longterm/shared)
  data_sources/          # Data source registry and read API
  evaluations/           # Evaluator orchestration and guardrails
  quotas/                # Quota management and enforcement
  secrets/               # Secret resolution and detection
  compliance/            # Compliance artifact verification
  governance_gate/       # Pre-invocation governance gate, PII scanning
  extensions/            # Extension system and capability flags
  telemetry/             # OpenTelemetry integration (optional)
  sinks/                 # HTTP audit sink (optional)
  storage/               # PostgreSQL storage backend (optional)

  providers/             # Model provider adapters (optional extras)
    shared/              # BaseModelProvider, conformance test helpers
    google_vertex/       # Google Vertex AI / Gemini
    aws_bedrock/         # Amazon Bedrock
    azure_openai/        # Azure OpenAI
    huggingface/         # Hugging Face Inference
    onpremise/           # On-premise OpenAI-compatible

tests/
  unit/                  # Unit tests mirroring src/arelis/ structure
  integration/           # Provider and storage integration tests

examples/               # Runnable example scripts
```

## Dependencies

### Core (always installed)

- `httpx` — Async HTTP client
- `jsonschema` — JSON Schema validation for tool inputs

### Optional Extras

```bash
pip install "ai-governance-sdk[google-vertex]"    # google-cloud-aiplatform
pip install "ai-governance-sdk[aws-bedrock]"      # boto3
pip install "ai-governance-sdk[azure-openai]"     # openai
pip install "ai-governance-sdk[huggingface]"      # huggingface-hub
pip install "ai-governance-sdk[otel]"            # opentelemetry-api + sdk
pip install "ai-governance-sdk[postgres]"        # asyncpg + alembic
pip install "ai-governance-sdk[all]"             # Everything
pip install "ai-governance-sdk[dev]"             # pytest, mypy, ruff
```

## Error Hierarchy

```
ArelisError (base)
├── PolicyBlockedError
├── PolicyApprovalRequiredError
├── EvaluationBlockedError
├── ProviderError
├── ToolError
├── TimeoutError
└── GovernanceGateDeniedError
```

Each error has a corresponding guard function (e.g., `is_policy_blocked_error(err)`).

## Reference SDK

The TypeScript SDK at `/Users/ramon.marrero/arelis-sdk` is the source of truth. When implementing any feature:

1. Read the corresponding TypeScript source first
2. Preserve the same behavior, error conditions, and edge cases
3. Adapt naming to Python conventions (camelCase → snake_case)
4. Maintain the same public API surface (all methods, all parameters, all return types)

Key TypeScript files to reference:
- `packages/sdk/src/client.ts` — Main client (3,559 lines, all 13 namespaces)
- `packages/sdk/src/index.ts` — Public exports
- `packages/core/src/types.ts` — GovernanceContext, ResultEnvelope
- `packages/core/src/errors.ts` — Error hierarchy
- `packages/core/src/middleware.ts` — Middleware pipeline
- Each `packages/<module>/src/` directory for module-specific types and logic

## Git Workflow

- **Main branch:** `main`
- **Branch names:** `feature/description`, `fix/description`, `docs/description`, `refactor/description`
- **Commits:** Conventional commits — `feat(core): add middleware pipeline`, `fix(audit): correct timestamp`, `test(policy): add edge cases`
- Do NOT commit: `.env`, `.env.local`, `__pycache__/`, `.mypy_cache/`, `*.egg-info/`, `dist/`, `.ruff_cache/`, `.pytest_cache/`
- Do NOT edit `requirements*.txt` by hand if using pyproject.toml (this project uses pyproject.toml)

## Things to Avoid

- Adding features or refactoring beyond what was requested
- Using `Any` — use `object`, `Unknown` patterns, or proper generics
- Adding default mutable arguments (use `None` + factory pattern)
- Adding sync wrappers unless explicitly requested — stay async-first
- Diverging from the TypeScript SDK's behavior — when in doubt, check the TS source
- Using deprecated/outdated library imports without checking Context7 first
- Bypassing type checking with `# type: ignore` unless absolutely necessary and documented
- Changing public APIs without updating `src/arelis/__init__.py`, examples, and tests
- Using `requests` instead of `httpx` (this project uses httpx for async support)
- Creating circular imports between modules (use `TYPE_CHECKING` guard for type-only imports)

## Pre-Flight: Required Reading by Task Type

**Before starting any task, read the files relevant to the task type.** This is non-negotiable.

| Task Type | Must Read Before Starting |
|---|---|
| Core module work | `src/arelis/core/errors.py`, `src/arelis/core/context.py`, `.claude/fixes/typing.md` |
| Provider adapter | `src/arelis/providers/shared/`, TS source for that provider, `.claude/fixes/providers.md` |
| Policy/governance | `src/arelis/policy/`, corresponding TS `packages/policy/src/` |
| Audit/compliance | `src/arelis/audit/`, corresponding TS `packages/audit/src/` |
| New module | `src/arelis/__init__.py`, `PLAN.md`, corresponding TS package |
| Test writing | Existing tests in same module, `tests/conftest.py` if it exists |
| Async patterns | `.claude/fixes/async.md`, existing async code in same module |
| Type issues | `.claude/fixes/typing.md`, `pyproject.toml` mypy config |
| SDK/library integration | Use Context7 MCP first, then `.claude/fixes/providers.md` |

## Post-Task Validation

After completing any implementation task, run `/validate` to execute the validation loop. This runs lint, type checking, and tests — and records the outcome.

## Progress Tracking

After completing any task, append a one-line entry to `.claude/progress.log`:
- Format: `[YYYY-MM-DD HH:MM] STATUS type(scope): description — outcome`
- STATUS values: `completed`, `failed`, `blocked`, `discovered`
- Reference `.claude/fixes/*.md` if a new gotcha was discovered
- This file is append-only. Never edit or truncate existing entries.

## Context Management

- NEVER read all files in `tasks/`, `docs/`, or `.claude/fixes/` at once
- Only read files directly relevant to the current task (use the Pre-Flight table above)
- When context grows large, summarize findings rather than re-reading source files
- For multi-step tasks, complete and commit each step before starting the next to keep context fresh
- The TypeScript reference SDK is large — read only the specific TS file for the module you are porting

## Lessons Learned

IMPORTANT: When you encounter a bug that took multiple attempts to fix, a non-obvious Python/async gotcha, or a configuration issue, YOU MUST read the relevant fix file below, then append your new entry to it. This prevents repeating mistakes across sessions.

Known fixes live in `.claude/fixes/`. See `.claude/fixes/INDEX.md` for an aggregated view with entry counts and trends. See `.claude/fixes/TEMPLATE.md` for the entry format (short and extended).

- @.claude/fixes/typing.md — mypy strict mode, Protocol issues, generic constraints
- @.claude/fixes/async.md — asyncio patterns, event loop gotchas, async iterator issues
- @.claude/fixes/providers.md — Provider adapter issues, SDK version mismatches
- @.claude/fixes/testing.md — pytest-asyncio configuration, mocking async code
- @.claude/fixes/INDEX.md — Aggregated fix index with counts and trends
- @.claude/fixes/TEMPLATE.md — Entry format template (short + extended)

All fix files above are **read on demand** (not auto-loaded). Claude must `Read` the relevant file before making changes in that area.

**Format for new entries:** Use short format for simple fixes, extended format for multi-attempt fixes. See TEMPLATE.md.

**After adding a fix:** Always update `INDEX.md` with the new entry count and date.

If no file matches the issue category, create a new `.md` file in `.claude/fixes/` and add a row to INDEX.md.

## Periodic Review

Run `/review-fixes` periodically (weekly or after major milestones) to:
- Identify patterns across fix files that should become rules in CLAUDE.md
- Mark resolved/obsolete fixes
- Propose structural changes for categories with 5+ entries
- Update INDEX.md trends
