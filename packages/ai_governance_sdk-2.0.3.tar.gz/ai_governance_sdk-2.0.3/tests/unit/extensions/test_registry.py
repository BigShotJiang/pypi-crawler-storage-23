"""Tests for arelis.extensions.registry."""

from __future__ import annotations

import pytest

from arelis.extensions.config import ClientExtensionsConfig, ExtensionCapabilityConfig
from arelis.extensions.contracts import (
    extension_contract_by_id,
)
from arelis.extensions.registry import ExtensionRegistry, create_extension_registry
from arelis.extensions.types import ExtensionDescriptor, ExtensionHookContext

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TEST_EXT_ID = "extension.full_lifecycle_governance_audit_trail"
_TEST_EXT_ID_2 = "extension.agent_operated_governed_self_service"


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


class TestExtensionRegistryRegister:
    def test_register_by_id(self) -> None:
        registry = ExtensionRegistry()
        descriptor = registry.register(_TEST_EXT_ID)
        assert isinstance(descriptor, ExtensionDescriptor)
        assert descriptor.contract.id == _TEST_EXT_ID
        assert descriptor.status == "registered"

    def test_register_duplicate_raises(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        with pytest.raises(ValueError, match="already registered"):
            registry.register(_TEST_EXT_ID)

    def test_register_with_capability_config(self) -> None:
        registry = ExtensionRegistry()
        config = ExtensionCapabilityConfig(enabled=True, mode="enforce")
        descriptor = registry.register(_TEST_EXT_ID, capability_config=config)
        assert descriptor.capability_config.enabled is True
        assert descriptor.capability_config.mode == "enforce"

    def test_register_contract(self) -> None:
        registry = ExtensionRegistry()
        contract = extension_contract_by_id(_TEST_EXT_ID)
        descriptor = registry.register_contract(contract)
        assert descriptor.contract is contract

    def test_register_contract_duplicate_raises(self) -> None:
        registry = ExtensionRegistry()
        contract = extension_contract_by_id(_TEST_EXT_ID)
        registry.register_contract(contract)
        with pytest.raises(ValueError, match="already registered"):
            registry.register_contract(contract)


# ---------------------------------------------------------------------------
# Unregister
# ---------------------------------------------------------------------------


class TestExtensionRegistryUnregister:
    def test_unregister(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        registry.unregister(_TEST_EXT_ID)
        assert not registry.is_registered(_TEST_EXT_ID)

    def test_unregister_not_registered_raises(self) -> None:
        registry = ExtensionRegistry()
        with pytest.raises(KeyError, match="not registered"):
            registry.unregister(_TEST_EXT_ID)


# ---------------------------------------------------------------------------
# Enable / disable
# ---------------------------------------------------------------------------


class TestExtensionRegistryEnableDisable:
    @pytest.mark.asyncio
    async def test_enable(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        await registry.enable(_TEST_EXT_ID)
        assert registry.is_enabled(_TEST_EXT_ID)

    @pytest.mark.asyncio
    async def test_disable(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        await registry.enable(_TEST_EXT_ID)
        await registry.disable(_TEST_EXT_ID)
        assert not registry.is_enabled(_TEST_EXT_ID)

    @pytest.mark.asyncio
    async def test_enable_not_registered_raises(self) -> None:
        registry = ExtensionRegistry()
        with pytest.raises(KeyError, match="not registered"):
            await registry.enable(_TEST_EXT_ID)

    @pytest.mark.asyncio
    async def test_disable_not_registered_raises(self) -> None:
        registry = ExtensionRegistry()
        with pytest.raises(KeyError, match="not registered"):
            await registry.disable(_TEST_EXT_ID)


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------


class TestExtensionRegistryQueries:
    def test_is_registered(self) -> None:
        registry = ExtensionRegistry()
        assert not registry.is_registered(_TEST_EXT_ID)
        registry.register(_TEST_EXT_ID)
        assert registry.is_registered(_TEST_EXT_ID)

    def test_is_enabled_false_by_default(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        assert not registry.is_enabled(_TEST_EXT_ID)

    def test_is_enabled_with_config_enabled(self) -> None:
        registry = ExtensionRegistry()
        config = ExtensionCapabilityConfig(enabled=True)
        registry.register(_TEST_EXT_ID, capability_config=config)
        assert registry.is_enabled(_TEST_EXT_ID)

    def test_is_enabled_not_registered(self) -> None:
        registry = ExtensionRegistry()
        assert not registry.is_enabled(_TEST_EXT_ID)

    def test_is_capability_enabled(self) -> None:
        registry = ExtensionRegistry()
        contract = extension_contract_by_id(_TEST_EXT_ID)
        config = ExtensionCapabilityConfig(enabled=True)
        registry.register(_TEST_EXT_ID, capability_config=config)
        assert registry.is_capability_enabled(contract.capability_flag)

    def test_is_capability_enabled_false(self) -> None:
        registry = ExtensionRegistry()
        assert not registry.is_capability_enabled("fullLifecycleGovernanceAuditTrail")

    def test_get_enforcement_mode(self) -> None:
        registry = ExtensionRegistry()
        config = ExtensionCapabilityConfig(enabled=True, mode="monitor")
        registry.register(_TEST_EXT_ID, capability_config=config)
        assert registry.get_enforcement_mode(_TEST_EXT_ID) == "monitor"

    def test_get_enforcement_mode_not_registered(self) -> None:
        registry = ExtensionRegistry()
        assert registry.get_enforcement_mode(_TEST_EXT_ID) is None

    def test_get_descriptor(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        desc = registry.get_descriptor(_TEST_EXT_ID)
        assert desc is not None
        assert desc.contract.id == _TEST_EXT_ID

    def test_get_descriptor_not_registered(self) -> None:
        registry = ExtensionRegistry()
        assert registry.get_descriptor(_TEST_EXT_ID) is None

    def test_list_registered(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        registry.register(_TEST_EXT_ID_2)
        ids = registry.list_registered()
        assert _TEST_EXT_ID in ids
        assert _TEST_EXT_ID_2 in ids

    @pytest.mark.asyncio
    async def test_list_enabled(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        registry.register(_TEST_EXT_ID_2)
        await registry.enable(_TEST_EXT_ID)
        enabled = registry.list_enabled()
        assert _TEST_EXT_ID in enabled
        assert _TEST_EXT_ID_2 not in enabled

    def test_get_status(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        statuses = registry.get_status()
        assert len(statuses) == 1
        assert statuses[0].id == _TEST_EXT_ID
        assert statuses[0].status == "registered"


# ---------------------------------------------------------------------------
# Hooks
# ---------------------------------------------------------------------------


class TestExtensionRegistryHooks:
    def test_add_hook(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        calls: list[str] = []

        async def my_hook(ctx: ExtensionHookContext) -> None:
            calls.append(ctx.point)

        registry.add_hook(_TEST_EXT_ID, "before_prompt", my_hook)
        desc = registry.get_descriptor(_TEST_EXT_ID)
        assert desc is not None
        assert "before_prompt" in desc.hooks
        assert len(desc.hooks["before_prompt"]) == 1

    def test_add_hook_not_registered_raises(self) -> None:
        registry = ExtensionRegistry()
        with pytest.raises(KeyError, match="not registered"):
            registry.add_hook(_TEST_EXT_ID, "before_prompt", lambda ctx: None)  # type: ignore[arg-type, return-value]

    def test_remove_hook(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)

        async def my_hook(ctx: ExtensionHookContext) -> None:
            pass

        registry.add_hook(_TEST_EXT_ID, "before_prompt", my_hook)
        registry.remove_hook(_TEST_EXT_ID, "before_prompt", my_hook)
        desc = registry.get_descriptor(_TEST_EXT_ID)
        assert desc is not None
        assert "before_prompt" not in desc.hooks

    def test_remove_hook_not_found_raises(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)

        async def my_hook(ctx: ExtensionHookContext) -> None:
            pass

        with pytest.raises(ValueError, match="Hook not found"):
            registry.remove_hook(_TEST_EXT_ID, "before_prompt", my_hook)

    @pytest.mark.asyncio
    async def test_execute_hooks(self) -> None:
        registry = ExtensionRegistry()
        config = ExtensionCapabilityConfig(enabled=True)
        registry.register(_TEST_EXT_ID, capability_config=config)
        calls: list[str] = []

        async def my_hook(ctx: ExtensionHookContext) -> None:
            calls.append(f"{ctx.extension_id}:{ctx.point}")

        registry.add_hook(_TEST_EXT_ID, "before_prompt", my_hook)
        await registry.execute_hooks("before_prompt", run_id="run_1")
        assert len(calls) == 1
        assert calls[0] == f"{_TEST_EXT_ID}:before_prompt"

    @pytest.mark.asyncio
    async def test_execute_hooks_skips_disabled(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)  # not enabled
        calls: list[str] = []

        async def my_hook(ctx: ExtensionHookContext) -> None:
            calls.append("called")

        registry.add_hook(_TEST_EXT_ID, "before_prompt", my_hook)
        await registry.execute_hooks("before_prompt")
        assert len(calls) == 0


# ---------------------------------------------------------------------------
# Collision detection
# ---------------------------------------------------------------------------


class TestExtensionRegistryCollisions:
    def test_no_collisions_with_distinct_extensions(self) -> None:
        registry = ExtensionRegistry()
        registry.register(_TEST_EXT_ID)
        registry.register(_TEST_EXT_ID_2)
        collisions = registry.detect_collisions()
        assert collisions == []


# ---------------------------------------------------------------------------
# Config-based construction
# ---------------------------------------------------------------------------


class TestExtensionRegistryConfig:
    def test_config_pre_registers_extensions(self) -> None:
        contract = extension_contract_by_id(_TEST_EXT_ID)
        config = ClientExtensionsConfig(
            capabilities={
                contract.capability_flag: ExtensionCapabilityConfig(enabled=True),
            }
        )
        registry = ExtensionRegistry(config=config)
        assert registry.is_registered(_TEST_EXT_ID)
        assert registry.is_enabled(_TEST_EXT_ID)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestCreateExtensionRegistry:
    def test_returns_instance(self) -> None:
        registry = create_extension_registry()
        assert isinstance(registry, ExtensionRegistry)

    def test_with_config(self) -> None:
        config = ClientExtensionsConfig()
        registry = create_extension_registry(config=config)
        assert isinstance(registry, ExtensionRegistry)
