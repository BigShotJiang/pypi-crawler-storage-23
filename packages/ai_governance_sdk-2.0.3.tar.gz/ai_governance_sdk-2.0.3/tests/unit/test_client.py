from unittest.mock import AsyncMock, MagicMock

import pytest

from arelis.client import ArelisClient, ClientConfig, create_arelis_client, createArelisClient
from arelis.core.types import ActorRef, GovernanceContext, OrgRef, ResultEnvelope
from arelis.models.capabilities import ModelDescriptor
from arelis.models.provider import ModelProvider
from arelis.models.registry import ModelRegistry, RouteResolution
from arelis.models.types import GenerateInput, ModelRequest, ModelResponse, UsageInfo
from arelis.policy.engine import PolicyEngine
from arelis.policy.types import PolicyResult, PolicyResultSummary


@pytest.fixture
def mock_config():
    config = MagicMock(spec=ClientConfig)
    # Default mocks for components
    config.model_registry = MagicMock(spec=ModelRegistry)
    config.policy_engine = MagicMock(spec=PolicyEngine)
    config.context_resolver = AsyncMock(
        return_value=GovernanceContext(
            org=OrgRef(id="test-org"),
            actor=ActorRef(type="user", id="test-user"),
            purpose="test",
            environment="test",
        )
    )

    # Initialize other registries as MagicMocks to avoid attribution errors
    config.tool_registry = None
    config.mcp_registry = None
    config.kb_registry = None
    config.prompt_registry = None
    config.memory_registry = None
    config.data_source_registry = None
    config.quota_manager = None
    config.evaluators = []
    config.approval_store = None
    config.secret_resolver = None
    config.redactor = None
    config.policy_compilation = None
    config.compliance = None
    config.extensions = None
    config.telemetry = None
    config.audit_sink = MagicMock()
    config.audit_sink.emit = AsyncMock()
    config.audit_sink.write = AsyncMock()
    config.audit_sink.flush = AsyncMock()

    return config


@pytest.fixture
def client(mock_config):
    return ArelisClient(mock_config)


def test_client_initialization(mock_config):
    client = create_arelis_client(mock_config)
    assert isinstance(client, ArelisClient)
    assert client.models is not None
    assert client.agents is not None
    assert client.mcp is not None
    assert client.knowledge is not None


def test_create_arelis_client_camel_alias_warns(mock_config):
    with pytest.deprecated_call():
        client = createArelisClient(mock_config)
    assert isinstance(client, ArelisClient)


@pytest.mark.asyncio
async def test_models_generate_flow(client, mock_config):
    # Setup
    mock_provider = MagicMock(spec=ModelProvider)
    mock_provider.generate = AsyncMock(
        return_value=ModelResponse(
            id="resp-1",
            created_at="2024-01-01T00:00:00Z",
            model="test-model",
            content="Hello world",
            usage=UsageInfo(input_tokens=10, output_tokens=5, total_tokens=15),
            finish_reason="stop",
        )
    )

    descriptor = ModelDescriptor(
        id="test-model", provider_id="test-provider", version="1.0", lifecycle_state="active"
    )
    mock_config.model_registry.resolve_route_or_model.return_value = RouteResolution(
        descriptor=descriptor
    )
    mock_config.model_registry.resolve_for_model.return_value = mock_provider

    # Policy mocks (allow everything)
    mock_config.policy_engine.evaluate = AsyncMock(
        return_value=PolicyResult(
            decisions=[], summary=PolicyResultSummary(allowed=True), policy_version="v1"
        )
    )

    input_data = GenerateInput(
        model="test-model",
        request=ModelRequest(messages=[{"role": "user", "content": "Hi"}], model="test-model"),
        context=GovernanceContext(
            org=OrgRef(id="o"), actor=ActorRef(type="u", id="u"), purpose="test", environment="test"
        ),
    )

    # Execute
    result = await client.models.generate(input_data)

    # Verify
    assert isinstance(result, ResultEnvelope)
    assert result.output.content == "Hello world"
    assert result.run_id.startswith("run_")

    # Check calls
    mock_config.model_registry.resolve_route_or_model.assert_called_once()
    mock_config.policy_engine.evaluate.assert_called()  # Called twice (pre/post)
    mock_provider.generate.assert_called_once()


@pytest.mark.asyncio
async def test_models_generate_policy_block(client, mock_config):
    # Setup policy block
    mock_config.model_registry.resolve_route_or_model.return_value = RouteResolution(
        descriptor=ModelDescriptor(id="m", provider_id="p", version="1", lifecycle_state="active")
    )
    mock_config.policy_engine.evaluate = AsyncMock(
        return_value=PolicyResult(
            decisions=[],
            summary=PolicyResultSummary(allowed=False, block_reason="Forbidden"),
            policy_version="v1",
        )
    )

    input_data = GenerateInput(
        model="test-model",
        request=ModelRequest(messages=[], model="test-model"),
        context=GovernanceContext(
            org=OrgRef(id="o"), actor=ActorRef(type="u", id="u"), purpose="test", environment="test"
        ),
    )

    from arelis.core.errors import PolicyBlockedError

    with pytest.raises(PolicyBlockedError, match="Forbidden"):
        await client.models.generate(input_data)


@pytest.mark.asyncio
async def test_agents_run_flow(client, mock_config):
    from arelis.agents.runtime import AgentRuntime
    from arelis.agents.types import AgentResult as TypeAgentResult

    mock_runtime = MagicMock(spec=AgentRuntime)
    mock_runtime.run = AsyncMock(
        return_value=TypeAgentResult(
            run_id="run-1",
            agent_id="agent-1",
            status="completed",
            output="Done",
            steps=[],
            total_steps=0,
            total_duration_ms=10,
            started_at=MagicMock(),
            ended_at=MagicMock(),
        )
    )

    from arelis.client import ClientAgentRunInput

    input_data = ClientAgentRunInput(
        agent=mock_runtime,
        input="Work",
        context=GovernanceContext(
            org=OrgRef(id="o"), actor=ActorRef(type="u", id="u"), purpose="p", environment="e"
        ),
    )

    result = await client.agents.run(input_data)
    assert result.status == "completed"
    mock_runtime.run.assert_called_once()
