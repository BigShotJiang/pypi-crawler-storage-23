import dataclasses
from unittest.mock import MagicMock

import pytest

from arelis.audit.sink import (
    ConsoleSinkConfig,
    MemorySinkConfig,
    create_composite_sink,
    create_console_sink,
    create_memory_sink,
    create_no_op_sink,
)
from arelis.audit.types import (
    AuditContext,
    AuditContextActor,
    AuditContextOrg,
    AuditContextTeam,
    RunStartedEvent,
)


@pytest.fixture
def mock_audit_context():
    return AuditContext(
        org=AuditContextOrg(id="org-123"),
        actor=AuditContextActor(type="user", id="user-123"),
        purpose="testing",
        environment="test",
        team=AuditContextTeam(id="team-123"),
    )


@pytest.fixture
def mock_event(mock_audit_context):
    return RunStartedEvent(
        schema_version="1.0",
        event_id="evt-123",
        time="2023-01-01T00:00:00Z",
        run_id="run-123",
        type="run.started",
        context=mock_audit_context,
    )


@pytest.mark.asyncio
async def test_memory_sink(mock_event):
    sink = create_memory_sink(MemorySinkConfig(max_events=10))
    await sink.write(mock_event)

    assert sink.count() == 1
    assert sink.get_last_event() == mock_event
    assert sink.get_events_by_type("run.started") == [mock_event]
    assert sink.get_events_by_run_id("run-123") == [mock_event]

    await sink.flush()  # Should not raise
    await sink.close()  # Should not raise


@pytest.mark.asyncio
async def test_memory_sink_limit(mock_event):
    sink = create_memory_sink(MemorySinkConfig(max_events=2))

    # Create 3 events
    e1 = mock_event
    e2 = dataclasses.replace(mock_event, event_id="evt-124")
    e3 = dataclasses.replace(mock_event, event_id="evt-125")

    await sink.write(e1)
    await sink.write(e2)
    assert sink.count() == 2

    await sink.write(e3)
    assert sink.count() == 2
    assert sink.get_events() == [e2, e3]


@pytest.mark.asyncio
async def test_console_sink(mock_event, capsys):
    sink = create_console_sink(ConsoleSinkConfig(pretty=False, timestamp=False))
    await sink.write(mock_event)

    captured = capsys.readouterr()
    assert "[run.started]" in captured.out
    assert "evt-123" in captured.out


@pytest.mark.asyncio
async def test_noop_sink(mock_event):
    sink = create_no_op_sink()
    await sink.write(mock_event)
    # Just verify it doesn't crash


@pytest.mark.asyncio
async def test_composite_sink(mock_event):
    mock_sink1 = MagicMock()
    mock_sink1.write = MagicMock(return_value=None)

    # Async mock for write
    async def async_write1(e):
        mock_sink1.write(e)

    sink1 = MagicMock()
    sink1.write = async_write1

    sink2 = create_memory_sink()

    composite = create_composite_sink([sink1, sink2])

    await composite.write(mock_event)

    mock_sink1.write.assert_called_once_with(mock_event)
    assert sink2.count() == 1
