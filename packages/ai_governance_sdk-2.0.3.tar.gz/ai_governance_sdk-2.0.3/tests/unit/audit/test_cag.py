import pytest

from arelis.audit.cag import (
    CausalGraphBuilder,
    assess_policy_risk,
)
from arelis.audit.cag_store import InMemoryCausalGraphStore
from arelis.audit.types import (
    AuditContext,
    AuditContextActor,
    AuditContextOrg,
    AuditContextTeam,
    AuditPolicyDecision,
    PolicyEvaluatedEvent,
    RunEndedEvent,
    RunStartedEvent,
)


@pytest.fixture
def mock_audit_context():
    return AuditContext(
        org=AuditContextOrg(id="org-123"),
        actor=AuditContextActor(type="user", id="user-123"),
        purpose="testing",
        environment="test",
        team=AuditContextTeam(id="team-123"),
    )


def test_assess_policy_risk():
    block_decision = AuditPolicyDecision(effect="block", reason="Too risky")
    risk = assess_policy_risk([block_decision])
    assert risk.level == "critical"

    allow_decision = AuditPolicyDecision(effect="allow")
    risk = assess_policy_risk([allow_decision])
    assert risk.level == "low"

    transform_decision = AuditPolicyDecision(effect="transform", reason="PII redacted")
    risk = assess_policy_risk([transform_decision])
    assert risk.level == "medium"

    approval_decision = AuditPolicyDecision(effect="require_approval", reason="Check needed")
    risk = assess_policy_risk([approval_decision])
    assert risk.level == "high"


def test_causal_graph_builder(mock_audit_context):
    run_id = "run-123"
    builder = CausalGraphBuilder(run_id)

    events = [
        RunStartedEvent(
            schema_version="1.0",
            event_id="evt-1",
            time="2023-01-01T00:00:01Z",
            run_id=run_id,
            type="run.started",
            context=mock_audit_context,
        ),
        PolicyEvaluatedEvent(
            schema_version="1.0",
            event_id="evt-2",
            time="2023-01-01T00:00:02Z",
            run_id=run_id,
            type="policy.evaluated",
            context=mock_audit_context,
            allowed=True,
            checkpoint="BeforePrompt",
        ),
        RunEndedEvent(
            schema_version="1.0",
            event_id="evt-3",
            time="2023-01-01T00:00:03Z",
            run_id=run_id,
            type="run.ended",
            context=mock_audit_context,
            success=True,
        ),
    ]

    for event in events:
        builder.record_event(event)

    graph = builder.build()

    assert graph.run_id == run_id
    assert len(graph.nodes) == 4  # run node + 3 event nodes
    assert len(graph.edges) == 5  # 3 contains edges + 2 sequence edges

    node_ids = {n.id for n in graph.nodes}
    assert f"run:{run_id}" in node_ids
    assert "evt:evt-1" in node_ids
    assert "evt:evt-2" in node_ids
    assert "evt:evt-3" in node_ids


def test_parent_run_link(mock_audit_context):
    parent_run_id = "run-parent"
    child_run_id = "run-child"

    child_event = RunStartedEvent(
        schema_version="1.0",
        event_id="evt-child-1",
        time="2023-01-01T00:00:01Z",
        run_id=child_run_id,
        type="run.started",
        context=mock_audit_context,
        parent_run_id=parent_run_id,
    )

    builder = CausalGraphBuilder(child_run_id)
    builder.record_event(child_event)
    graph = builder.build()

    # Should have a parent edge
    edge_kinds = {e.kind for e in graph.edges}
    assert "parent" in edge_kinds

    # Check parent node
    parent_node_id = f"run:{parent_run_id}"
    matches = [n for n in graph.nodes if n.id == parent_node_id]
    assert len(matches) == 1


@pytest.mark.asyncio
async def test_in_memory_store(mock_audit_context):
    run_id = "run-XYZ"
    builder = CausalGraphBuilder(run_id)
    graph = builder.build()

    store = InMemoryCausalGraphStore()
    await store.save(graph)

    retrieved = await store.get(run_id)
    assert retrieved is not None
    assert retrieved.run_id == run_id
