"""Tests for arelis.secrets.resolver."""

from __future__ import annotations

import pytest

from arelis.secrets.resolver import (
    EnvSecretResolver,
    create_env_secret_resolver,
    resolve_secret_value,
)
from arelis.secrets.types import SecretResolution, SecretResolverContext

# ---------------------------------------------------------------------------
# EnvSecretResolver
# ---------------------------------------------------------------------------


class TestEnvSecretResolver:
    def test_id(self) -> None:
        resolver = EnvSecretResolver()
        assert resolver.id == "env"

    @pytest.mark.asyncio
    async def test_resolve_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MY_SECRET", "s3cret")
        resolver = EnvSecretResolver()
        value = await resolver.resolve("MY_SECRET")
        assert value == "s3cret"

    @pytest.mark.asyncio
    async def test_resolve_strips_env_prefix(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("API_KEY", "key123")
        resolver = EnvSecretResolver()
        value = await resolver.resolve("env:API_KEY")
        assert value == "key123"

    @pytest.mark.asyncio
    async def test_resolve_raises_on_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("NONEXISTENT_VAR", raising=False)
        resolver = EnvSecretResolver()
        with pytest.raises(ValueError, match="Secret not found in env"):
            await resolver.resolve("NONEXISTENT_VAR")

    @pytest.mark.asyncio
    async def test_resolve_raises_on_empty_value(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("EMPTY_VAR", "")
        resolver = EnvSecretResolver()
        with pytest.raises(ValueError, match="Secret not found in env"):
            await resolver.resolve("EMPTY_VAR")


# ---------------------------------------------------------------------------
# resolve_secret_value
# ---------------------------------------------------------------------------


class TestResolveSecretValue:
    @pytest.mark.asyncio
    async def test_returns_value_and_resolution(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("TEST_KEY", "my_value")
        resolver = EnvSecretResolver()
        result = await resolve_secret_value(resolver, "TEST_KEY")
        assert result.value == "my_value"
        assert isinstance(result.resolution, SecretResolution)
        assert result.resolution.ref == "TEST_KEY"
        assert result.resolution.resolver_id == "env"
        assert result.resolution.resolved_at  # non-empty ISO string

    @pytest.mark.asyncio
    async def test_with_context(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CTX_KEY", "ctx_val")
        resolver = EnvSecretResolver()
        ctx = SecretResolverContext(run_id="run_1")
        result = await resolve_secret_value(resolver, "CTX_KEY", ctx)
        assert result.value == "ctx_val"
        assert result.resolution.resolver_id == "env"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestCreateEnvSecretResolver:
    def test_returns_instance(self) -> None:
        resolver = create_env_secret_resolver()
        assert isinstance(resolver, EnvSecretResolver)
        assert resolver.id == "env"
