"""Tests for arelis.secrets.patterns."""

from __future__ import annotations

from arelis.secrets.patterns import get_secret_redaction_patterns
from arelis.secrets.types import SecretRedactionPattern

# ---------------------------------------------------------------------------
# get_secret_redaction_patterns
# ---------------------------------------------------------------------------


class TestGetSecretRedactionPatterns:
    def test_returns_list(self) -> None:
        patterns = get_secret_redaction_patterns()
        assert isinstance(patterns, list)
        assert len(patterns) >= 2

    def test_returns_copies(self) -> None:
        p1 = get_secret_redaction_patterns()
        p2 = get_secret_redaction_patterns()
        assert p1 is not p2  # different list instances

    def test_contains_openai_pattern(self) -> None:
        patterns = get_secret_redaction_patterns()
        names = {p.name for p in patterns}
        assert "openai_sk" in names

    def test_contains_slack_pattern(self) -> None:
        patterns = get_secret_redaction_patterns()
        names = {p.name for p in patterns}
        assert "slack_token" in names

    def test_openai_pattern_matches(self) -> None:
        patterns = get_secret_redaction_patterns()
        openai = next(p for p in patterns if p.name == "openai_sk")
        assert openai.pattern.search("sk-" + "A" * 30)
        assert not openai.pattern.search("not-a-key")

    def test_slack_pattern_matches(self) -> None:
        patterns = get_secret_redaction_patterns()
        slack = next(p for p in patterns if p.name == "slack_token")
        assert slack.pattern.search("xoxb-1234567890-abcdef")
        assert not slack.pattern.search("not-a-slack-token")

    def test_all_patterns_are_correct_type(self) -> None:
        patterns = get_secret_redaction_patterns()
        for p in patterns:
            assert isinstance(p, SecretRedactionPattern)
            assert p.type == "custom"
