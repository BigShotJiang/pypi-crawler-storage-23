from unittest.mock import AsyncMock, MagicMock

import pytest

from arelis.knowledge.provider import KBProvider
from arelis.knowledge.registry import KBRegistry, KBRegistryOptions
from arelis.knowledge.types import KBGovernanceConfig, KnowledgeBaseDescriptor


@pytest.fixture
def kb_descriptor():
    return KnowledgeBaseDescriptor(
        id="kb-123",
        provider="memory",
        connection={"host": "localhost"},
        name="Test KB",
        region="us-east-1",
        governance=KBGovernanceConfig(
            data_residency="US",
            approved_for_purposes=["research", "support"],
            data_class="internal",
        ),
    )


@pytest.fixture
def mock_provider():
    provider = MagicMock(spec=KBProvider)
    provider.type = "memory"
    provider.connect = AsyncMock()
    provider.disconnect = AsyncMock()
    provider.is_connected = MagicMock(return_value=True)
    provider.retrieve = AsyncMock(return_value=[])
    return provider


def test_registry_init():
    registry = KBRegistry()
    assert registry.size == 0
    assert registry.default_top_k == 5

    opts = KBRegistryOptions(default_top_k=10)
    registry = KBRegistry(opts)
    assert registry.default_top_k == 10


def test_register_kb(kb_descriptor):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)

    assert registry.size == 1
    assert registry.has_kb("kb-123")
    assert registry.get_kb("kb-123").descriptor == kb_descriptor


def test_register_duplicate_kb(kb_descriptor):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)

    with pytest.raises(ValueError, match="already registered"):
        registry.register_kb(kb_descriptor)

    # Allow overwrite
    registry_overwrite = KBRegistry(KBRegistryOptions(allow_overwrite=True))
    registry_overwrite.register_kb(kb_descriptor)
    registry_overwrite.register_kb(kb_descriptor)  # Should not raise
    assert registry_overwrite.size == 1


def test_register_invalid_provider():
    registry = KBRegistry()
    desc = KnowledgeBaseDescriptor(id="kb-bad", provider="invalid", connection={})  # type: ignore
    with pytest.raises(ValueError, match="Invalid provider"):
        registry.register_kb(desc)


def test_unregister_kb(kb_descriptor, mock_provider):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)
    registry.set_provider("kb-123", mock_provider)

    assert registry.unregister_kb("kb-123")
    assert registry.size == 0
    assert not registry.has_kb("kb-123")

    # Should call disconnect (fire and forget, tricky to test without loop control,
    # but at least verify it doesn't crash)


def test_provider_management(kb_descriptor, mock_provider):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)

    assert registry.get_provider("kb-123") is None

    registry.set_provider("kb-123", mock_provider)
    assert registry.get_provider("kb-123") == mock_provider

    with pytest.raises(ValueError):
        registry.set_provider("non-existent", mock_provider)


def test_governance_checks(kb_descriptor):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)

    assert registry.is_purpose_approved("kb-123", "research")
    assert registry.is_purpose_approved("kb-123", "support")
    assert not registry.is_purpose_approved("kb-123", "marketing")

    assert registry.get_data_classification("kb-123") == "internal"
    assert registry.get_data_residency("kb-123") == "US"

    assert registry.get_data_classification("non-existent") is None


def test_list_kbs(kb_descriptor):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)

    kbs = registry.list_kbs()
    assert len(kbs) == 1
    assert kbs[0].descriptor.id == "kb-123"

    ids = registry.list_kb_ids()
    assert ids == ["kb-123"]


def test_clear(kb_descriptor):
    registry = KBRegistry()
    registry.register_kb(kb_descriptor)
    registry.clear()
    assert registry.size == 0
