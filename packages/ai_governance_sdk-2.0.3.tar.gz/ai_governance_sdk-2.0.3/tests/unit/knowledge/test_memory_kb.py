import pytest

from arelis.knowledge.memory_kb import (
    MemoryDocument,
    MemoryKBProvider,
    MemoryKBProviderOptions,
    MemoryKBScoringOptions,
    create_test_kb_provider,
)
from arelis.knowledge.scoring import ScoringWeights
from arelis.knowledge.types import RetrievalQuery


@pytest.fixture
def sample_docs():
    return [
        MemoryDocument(
            id="doc-1",
            text="The quick brown fox jumps over the lazy dog.",
            metadata={"category": "animals"},
        ),
        MemoryDocument(
            id="doc-2",
            text="A fool thinks himself to be wise, but a wise man knows himself to be a fool.",
            metadata={"category": "philosophy", "author": "Shakespeare"},
        ),
        MemoryDocument(
            id="doc-3",
            text="To be or not to be, that is the question.",
            metadata={"category": "literature", "author": "Shakespeare"},
        ),
    ]


@pytest.fixture
def provider(sample_docs):
    return MemoryKBProvider(MemoryKBProviderOptions(kb_id="test-kb", documents=sample_docs))


async def test_memory_kb_init(provider):
    assert provider.type == "memory"
    await provider.connect()
    assert provider.is_connected()
    await provider.disconnect()
    assert not provider.is_connected()


async def test_document_management(provider):
    assert provider.document_count == 3

    new_doc = MemoryDocument(id="doc-4", text="New doc")
    provider.add_document(new_doc)
    assert provider.document_count == 4

    provider.add_documents(
        [
            MemoryDocument(id="doc-5", text="Another doc"),
            MemoryDocument(id="doc-6", text="Yet another doc"),
        ]
    )
    assert provider.document_count == 6

    provider.clear_documents()
    assert provider.document_count == 0


async def test_retrieval(provider):
    await provider.connect()

    # Simple query
    results = await provider.retrieve(RetrievalQuery(query="lazy dog", kb="test-kb"))
    assert len(results) > 0
    assert results[0].id == "doc-1"
    assert "lazy dog" in results[0].text

    # Top-k
    results = await provider.retrieve(RetrievalQuery(query="to be", kb="test-kb", top_k=1))
    assert len(results) == 1

    # Metadata filter
    results = await provider.retrieve(
        RetrievalQuery(query="wise", kb="test-kb", filters={"category": "philosophy"})
    )
    assert len(results) == 1
    assert results[0].id == "doc-2"

    # Filter mismatch
    results = await provider.retrieve(
        RetrievalQuery(query="wise", kb="test-kb", filters={"category": "science"})
    )
    assert len(results) == 0


async def test_min_score(provider):
    await provider.connect()

    # Should get nothing if threshold is too high
    results = await provider.retrieve(RetrievalQuery(query="fox", kb="test-kb", min_score=0.99))
    assert len(results) == 0


async def test_embedding_scoring(sample_docs):
    # Mock embedding function
    async def mock_embed(texts):
        # Determine "vector" based on length as a deterministic proxy
        return [[float(len(t))] for t in texts]

    provider = MemoryKBProvider(
        MemoryKBProviderOptions(
            kb_id="embed-kb",
            documents=sample_docs,
            embed=mock_embed,
            scoring=MemoryKBScoringOptions(weights=ScoringWeights(embedding=0.5, bm25=0.5)),
        )
    )
    await provider.connect()

    results = await provider.retrieve(RetrievalQuery(query="fox", kb="embed-kb"))
    assert len(results) > 0

    # Ensure cache is used (coverage)
    results2 = await provider.retrieve(RetrievalQuery(query="fox", kb="embed-kb"))
    assert len(results2) == len(results)


async def test_create_test_kb():
    kb = create_test_kb_provider()
    await kb.connect()
    assert kb.document_count > 0

    res = await kb.retrieve(RetrievalQuery(query="refund", kb="test"))
    assert len(res) > 0
    assert "refund" in res[0].text.lower()
