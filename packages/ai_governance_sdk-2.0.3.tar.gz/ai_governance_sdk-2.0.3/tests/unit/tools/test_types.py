"""Tests for arelis.tools.types."""

from __future__ import annotations

from arelis.tools.types import (
    DiscoveredTool,
    JsonSchema,
    JsonSchemaProperty,
    PermissionCheckResult,
    ToolDefinition,
    ToolErrorInfo,
    ToolInvokeOptions,
    ToolPermissions,
    ToolRegistryOptions,
    ToolResult,
    ToolRunnerOptions,
    ToolValidationError,
    ValidationResult,
)

# ---------------------------------------------------------------------------
# JsonSchemaProperty
# ---------------------------------------------------------------------------


class TestJsonSchemaProperty:
    def test_minimal_property(self) -> None:
        prop = JsonSchemaProperty(type="string")
        assert prop.type == "string"
        assert prop.description is None
        assert prop.enum is None
        assert prop.items is None
        assert prop.properties is None
        assert prop.required is None
        assert prop.minimum is None
        assert prop.maximum is None
        assert prop.min_length is None
        assert prop.max_length is None
        assert prop.pattern is None
        assert prop.default is None

    def test_full_property(self) -> None:
        prop = JsonSchemaProperty(
            type="string",
            description="A name field",
            enum=["a", "b"],
            min_length=1,
            max_length=100,
            pattern="^[a-z]+$",
            default="a",
        )
        assert prop.description == "A name field"
        assert prop.enum == ["a", "b"]
        assert prop.min_length == 1
        assert prop.max_length == 100
        assert prop.pattern == "^[a-z]+$"
        assert prop.default == "a"

    def test_nested_properties(self) -> None:
        inner = JsonSchemaProperty(type="string", description="inner")
        outer = JsonSchemaProperty(
            type="object",
            properties={"name": inner},
            required=["name"],
        )
        assert outer.properties is not None
        assert "name" in outer.properties
        assert outer.properties["name"].description == "inner"
        assert outer.required == ["name"]

    def test_array_items(self) -> None:
        items = JsonSchemaProperty(type="number", minimum=0.0, maximum=100.0)
        prop = JsonSchemaProperty(type="array", items=items)
        assert prop.items is not None
        assert prop.items.type == "number"
        assert prop.items.minimum == 0.0
        assert prop.items.maximum == 100.0


# ---------------------------------------------------------------------------
# JsonSchema
# ---------------------------------------------------------------------------


class TestJsonSchema:
    def test_defaults(self) -> None:
        schema = JsonSchema()
        assert schema.type == "object"
        assert schema.properties is None
        assert schema.required is None
        assert schema.additional_properties is None

    def test_with_properties(self) -> None:
        schema = JsonSchema(
            properties={"query": JsonSchemaProperty(type="string")},
            required=["query"],
            additional_properties=False,
        )
        assert schema.properties is not None
        assert "query" in schema.properties
        assert schema.required == ["query"]
        assert schema.additional_properties is False


# ---------------------------------------------------------------------------
# ToolPermissions
# ---------------------------------------------------------------------------


class TestToolPermissions:
    def test_minimal(self) -> None:
        perms = ToolPermissions(scopes=["read"])
        assert perms.scopes == ["read"]
        assert perms.allowed_actor_types is None
        assert perms.allowed_environments is None
        assert perms.allowed_purposes is None
        assert perms.allowed_roles is None

    def test_full(self) -> None:
        perms = ToolPermissions(
            scopes=["read", "write"],
            allowed_actor_types=["human", "agent"],
            allowed_environments=["prod"],
            allowed_purposes=["customer-support"],
            allowed_roles=["admin"],
        )
        assert "write" in perms.scopes
        assert perms.allowed_actor_types == ["human", "agent"]
        assert perms.allowed_environments == ["prod"]
        assert perms.allowed_purposes == ["customer-support"]
        assert perms.allowed_roles == ["admin"]


# ---------------------------------------------------------------------------
# ToolDefinition
# ---------------------------------------------------------------------------


class TestToolDefinition:
    def test_construction(self) -> None:
        async def handler(args: dict[str, object], ctx: object) -> object:
            return {"ok": True}

        defn = ToolDefinition(
            name="my-tool",
            description="A test tool",
            schema=JsonSchema(),
            permissions=ToolPermissions(scopes=["execute"]),
            handler=handler,
            timeout=5000,
            tags=["test"],
        )
        assert defn.name == "my-tool"
        assert defn.description == "A test tool"
        assert defn.timeout == 5000
        assert defn.tags == ["test"]
        assert callable(defn.handler)

    def test_defaults(self) -> None:
        async def handler(args: dict[str, object], ctx: object) -> object:
            return None

        defn = ToolDefinition(
            name="t",
            description="d",
            schema=JsonSchema(),
            permissions=ToolPermissions(scopes=[]),
            handler=handler,
        )
        assert defn.timeout is None
        assert defn.tags is None


# ---------------------------------------------------------------------------
# ToolResult & ToolErrorInfo
# ---------------------------------------------------------------------------


class TestToolResult:
    def test_success(self) -> None:
        result = ToolResult(
            success=True,
            duration_ms=42,
            tool_name="my-tool",
            run_id="run_123",
            data={"answer": 42},
        )
        assert result.success is True
        assert result.data == {"answer": 42}
        assert result.error is None

    def test_failure(self) -> None:
        err = ToolErrorInfo(type="RuntimeError", code="ERR", message="boom")
        result = ToolResult(
            success=False,
            duration_ms=1,
            tool_name="my-tool",
            run_id="run_123",
            error=err,
        )
        assert result.success is False
        assert result.error is not None
        assert result.error.message == "boom"
        assert result.error.code == "ERR"
        assert result.data is None


# ---------------------------------------------------------------------------
# ToolInvokeOptions
# ---------------------------------------------------------------------------


class TestToolInvokeOptions:
    def test_defaults(self) -> None:
        opts = ToolInvokeOptions()
        assert opts.timeout is None
        assert opts.skip_permission_check is False
        assert opts.skip_validation is False
        assert opts.skip_policy_check is False


# ---------------------------------------------------------------------------
# ValidationResult / ToolValidationError
# ---------------------------------------------------------------------------


class TestValidationResult:
    def test_valid(self) -> None:
        vr = ValidationResult(valid=True)
        assert vr.valid is True
        assert vr.errors == []

    def test_invalid(self) -> None:
        err = ToolValidationError(
            path="args.name",
            message="required",
            expected="string",
            actual="None",
        )
        vr = ValidationResult(valid=False, errors=[err])
        assert vr.valid is False
        assert len(vr.errors) == 1
        assert vr.errors[0].path == "args.name"
        assert vr.errors[0].expected == "string"


# ---------------------------------------------------------------------------
# PermissionCheckResult
# ---------------------------------------------------------------------------


class TestPermissionCheckResult:
    def test_allowed(self) -> None:
        pcr = PermissionCheckResult(allowed=True)
        assert pcr.allowed is True
        assert pcr.reason is None
        assert pcr.missing_scopes is None

    def test_denied(self) -> None:
        pcr = PermissionCheckResult(
            allowed=False,
            reason="Missing scope",
            missing_scopes=["admin"],
        )
        assert pcr.allowed is False
        assert pcr.reason == "Missing scope"
        assert pcr.missing_scopes == ["admin"]


# ---------------------------------------------------------------------------
# ToolRegistryOptions / ToolRunnerOptions
# ---------------------------------------------------------------------------


class TestToolRegistryOptions:
    def test_defaults(self) -> None:
        opts = ToolRegistryOptions()
        assert opts.allow_overwrite is False
        assert opts.default_timeout == 30000


class TestToolRunnerOptions:
    def test_defaults(self) -> None:
        opts = ToolRunnerOptions()
        assert opts.data_ref_mode == "hash"

    def test_inline(self) -> None:
        opts = ToolRunnerOptions(data_ref_mode="inline")
        assert opts.data_ref_mode == "inline"


# ---------------------------------------------------------------------------
# DiscoveredTool
# ---------------------------------------------------------------------------


class TestDiscoveredTool:
    def test_construction(self) -> None:
        dt = DiscoveredTool(
            name="mcp.server1.tool1",
            original_name="tool1",
            server_id="server1",
            description="A discovered tool",
            registered=True,
        )
        assert dt.name == "mcp.server1.tool1"
        assert dt.original_name == "tool1"
        assert dt.registered is True
        assert dt.skip_reason is None

    def test_defaults(self) -> None:
        dt = DiscoveredTool(name="t", original_name="t", server_id="s")
        assert dt.description is None
        assert dt.registered is False
        assert dt.skip_reason is None
