"""Tests for arelis.tools.registry."""

from __future__ import annotations

import asyncio

import pytest

from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.tools.registry import ToolRegistry, create_tool_registry, validate_arguments
from arelis.tools.types import (
    JsonSchema,
    JsonSchemaProperty,
    ToolContext,
    ToolDefinition,
    ToolInvokeOptions,
    ToolPermissions,
    ToolRegistryOptions,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _gov_ctx(
    actor_type: str = "human",
    environment: str = "dev",
    purpose: str = "testing",
    roles: list[str] | None = None,
) -> GovernanceContext:
    return GovernanceContext(
        org=OrgRef(id="org-1"),
        actor=ActorRef(type=actor_type, id="actor-1", roles=roles),  # type: ignore[arg-type]
        purpose=purpose,
        environment=environment,  # type: ignore[arg-type]
    )


def _tool_ctx(run_id: str = "run_001", **kwargs: object) -> ToolContext:
    gov = _gov_ctx(**kwargs)  # type: ignore[arg-type]
    return ToolContext(run_id=run_id, governance=gov)


async def _echo_handler(args: dict[str, object], ctx: ToolContext) -> object:
    return {"echo": args}


def _make_tool(
    name: str = "test-tool",
    scopes: list[str] | None = None,
    tags: list[str] | None = None,
    timeout: int | None = None,
    handler: object | None = None,
    schema: JsonSchema | None = None,
    permissions: ToolPermissions | None = None,
) -> ToolDefinition:
    return ToolDefinition(
        name=name,
        description=f"Tool {name}",
        schema=schema or JsonSchema(properties={"q": JsonSchemaProperty(type="string")}),
        permissions=permissions or ToolPermissions(scopes=scopes or ["read"]),
        handler=handler or _echo_handler,  # type: ignore[arg-type]
        timeout=timeout,
        tags=tags,
    )


# ---------------------------------------------------------------------------
# create_tool_registry
# ---------------------------------------------------------------------------


class TestCreateToolRegistry:
    def test_returns_registry(self) -> None:
        reg = create_tool_registry()
        assert isinstance(reg, ToolRegistry)
        assert reg.size == 0

    def test_custom_options(self) -> None:
        reg = create_tool_registry(ToolRegistryOptions(allow_overwrite=True, default_timeout=5000))
        assert reg.size == 0


# ---------------------------------------------------------------------------
# validate_arguments
# ---------------------------------------------------------------------------


class TestValidateArguments:
    def test_valid_args(self) -> None:
        schema = JsonSchema(
            properties={"name": JsonSchemaProperty(type="string")},
            required=["name"],
        )
        result = validate_arguments({"name": "Alice"}, schema)
        assert result.valid is True
        assert result.errors == []

    def test_missing_required(self) -> None:
        schema = JsonSchema(
            properties={"name": JsonSchemaProperty(type="string")},
            required=["name"],
        )
        result = validate_arguments({}, schema)
        assert result.valid is False
        assert len(result.errors) > 0

    def test_wrong_type(self) -> None:
        schema = JsonSchema(
            properties={"count": JsonSchemaProperty(type="number")},
        )
        result = validate_arguments({"count": "not-a-number"}, schema)
        assert result.valid is False

    def test_not_a_dict(self) -> None:
        schema = JsonSchema()
        result = validate_arguments("bad", schema)  # type: ignore[arg-type]
        assert result.valid is False
        assert result.errors[0].path == "args"
        assert "object" in result.errors[0].message.lower()

    def test_additional_properties_allowed_by_default(self) -> None:
        schema = JsonSchema(properties={"a": JsonSchemaProperty(type="string")})
        result = validate_arguments({"a": "ok", "b": "extra"}, schema)
        assert result.valid is True

    def test_additional_properties_disallowed(self) -> None:
        schema = JsonSchema(
            properties={"a": JsonSchemaProperty(type="string")},
            additional_properties=False,
        )
        result = validate_arguments({"a": "ok", "b": "extra"}, schema)
        assert result.valid is False

    def test_nested_object_validation(self) -> None:
        inner = JsonSchemaProperty(
            type="object",
            properties={"x": JsonSchemaProperty(type="number")},
            required=["x"],
        )
        schema = JsonSchema(properties={"nested": inner}, required=["nested"])
        result = validate_arguments({"nested": {"x": 5}}, schema)
        assert result.valid is True

        result2 = validate_arguments({"nested": {}}, schema)
        assert result2.valid is False

    def test_array_items_validation(self) -> None:
        schema = JsonSchema(
            properties={
                "items": JsonSchemaProperty(
                    type="array",
                    items=JsonSchemaProperty(type="number"),
                )
            },
        )
        assert validate_arguments({"items": [1, 2, 3]}, schema).valid is True
        assert validate_arguments({"items": [1, "x"]}, schema).valid is False

    def test_min_max_validation(self) -> None:
        schema = JsonSchema(
            properties={"val": JsonSchemaProperty(type="number", minimum=0.0, maximum=10.0)},
        )
        assert validate_arguments({"val": 5}, schema).valid is True
        assert validate_arguments({"val": -1}, schema).valid is False
        assert validate_arguments({"val": 11}, schema).valid is False


# ---------------------------------------------------------------------------
# ToolRegistry: register
# ---------------------------------------------------------------------------


class TestToolRegistryRegister:
    def test_register_and_get(self) -> None:
        reg = ToolRegistry()
        tool = _make_tool("my-tool")
        reg.register(tool)
        assert reg.has("my-tool") is True
        assert reg.get("my-tool") is not None
        assert reg.get("my-tool").name == "my-tool"  # type: ignore[union-attr]
        assert reg.size == 1

    def test_register_duplicate_raises(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("dup"))
        with pytest.raises(ValueError, match="already registered"):
            reg.register(_make_tool("dup"))

    def test_register_duplicate_with_overwrite(self) -> None:
        reg = ToolRegistry(ToolRegistryOptions(allow_overwrite=True))
        reg.register(_make_tool("dup"))
        reg.register(_make_tool("dup"))
        assert reg.size == 1

    def test_register_applies_default_timeout(self) -> None:
        reg = ToolRegistry(ToolRegistryOptions(default_timeout=9999))
        reg.register(_make_tool("t1"))
        assert reg.get("t1") is not None
        assert reg.get("t1").timeout == 9999  # type: ignore[union-attr]

    def test_register_preserves_custom_timeout(self) -> None:
        reg = ToolRegistry(ToolRegistryOptions(default_timeout=9999))
        reg.register(_make_tool("t1", timeout=1000))
        assert reg.get("t1").timeout == 1000  # type: ignore[union-attr]

    def test_register_empty_name_raises(self) -> None:
        with pytest.raises(ValueError, match="name"):
            ToolRegistry().register(_make_tool(name=""))

    def test_register_no_handler_raises(self) -> None:
        tool = _make_tool("t")
        tool.handler = None  # type: ignore[assignment]
        with pytest.raises(ValueError, match="handler"):
            ToolRegistry().register(tool)


# ---------------------------------------------------------------------------
# ToolRegistry: listing
# ---------------------------------------------------------------------------


class TestToolRegistryListing:
    def test_list_and_list_names(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("a"))
        reg.register(_make_tool("b"))
        assert len(reg.list()) == 2
        assert set(reg.list_names()) == {"a", "b"}

    def test_list_by_tag(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("a", tags=["alpha", "beta"]))
        reg.register(_make_tool("b", tags=["beta"]))
        reg.register(_make_tool("c"))
        assert len(reg.list_by_tag("beta")) == 2
        assert len(reg.list_by_tag("alpha")) == 1
        assert len(reg.list_by_tag("gamma")) == 0


# ---------------------------------------------------------------------------
# ToolRegistry: unregister / clear
# ---------------------------------------------------------------------------


class TestToolRegistryUnregister:
    def test_unregister(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("x"))
        assert reg.unregister("x") is True
        assert reg.has("x") is False
        assert reg.size == 0

    def test_unregister_missing(self) -> None:
        assert ToolRegistry().unregister("nope") is False

    def test_clear(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("a"))
        reg.register(_make_tool("b"))
        reg.clear()
        assert reg.size == 0


# ---------------------------------------------------------------------------
# ToolRegistry: permission checks
# ---------------------------------------------------------------------------


class TestToolRegistryPermissions:
    def test_has_permission_allowed(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("t", scopes=["read"]))
        ctx = _gov_ctx()
        result = reg.has_permission("t", ctx)
        assert result.allowed is True

    def test_has_permission_tool_not_found(self) -> None:
        reg = ToolRegistry()
        result = reg.has_permission("nonexistent", _gov_ctx())
        assert result.allowed is False
        assert "not found" in (result.reason or "")

    def test_permission_actor_type_denied(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read"], allowed_actor_types=["service"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(actor_type="human"))
        assert result.allowed is False
        assert "Actor type" in (result.reason or "")

    def test_permission_environment_denied(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read"], allowed_environments=["prod"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(environment="dev"))
        assert result.allowed is False
        assert "Environment" in (result.reason or "")

    def test_permission_purpose_denied(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read"], allowed_purposes=["analytics"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(purpose="testing"))
        assert result.allowed is False
        assert "Purpose" in (result.reason or "")

    def test_permission_role_denied(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read"], allowed_roles=["admin"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(roles=["viewer"]))
        assert result.allowed is False
        assert "roles" in (result.reason or "").lower()

    def test_permission_role_allowed(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read"], allowed_roles=["admin"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(roles=["admin", "viewer"]))
        assert result.allowed is True

    def test_required_scopes_missing(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(), required_scopes=["write"])
        assert result.allowed is False
        assert result.missing_scopes == ["write"]

    def test_required_scopes_present(self) -> None:
        reg = ToolRegistry()
        perms = ToolPermissions(scopes=["read", "write"])
        reg.register(_make_tool("t", permissions=perms))
        result = reg.has_permission("t", _gov_ctx(), required_scopes=["read"])
        assert result.allowed is True


# ---------------------------------------------------------------------------
# ToolRegistry: invoke
# ---------------------------------------------------------------------------


class TestToolRegistryInvoke:
    @pytest.mark.asyncio
    async def test_invoke_success(self) -> None:
        reg = ToolRegistry()
        reg.register(_make_tool("echo"))
        ctx = _tool_ctx()
        result = await reg.invoke("echo", {"q": "hi"}, ctx)
        assert result.success is True
        assert result.tool_name == "echo"
        assert result.run_id == "run_001"
        assert result.data is not None
        assert result.duration_ms >= 0

    @pytest.mark.asyncio
    async def test_invoke_tool_not_found(self) -> None:
        reg = ToolRegistry()
        ctx = _tool_ctx()
        result = await reg.invoke("nope", {}, ctx)
        assert result.success is False
        assert result.error is not None
        assert result.error.code == "TOOL_NOT_FOUND"

    @pytest.mark.asyncio
    async def test_invoke_validation_failure(self) -> None:
        schema = JsonSchema(
            properties={"name": JsonSchemaProperty(type="string")},
            required=["name"],
        )
        reg = ToolRegistry()
        reg.register(_make_tool("t", schema=schema))
        ctx = _tool_ctx()
        result = await reg.invoke("t", {}, ctx)
        assert result.success is False
        assert result.error is not None
        assert result.error.code == "VALIDATION_FAILED"

    @pytest.mark.asyncio
    async def test_invoke_skip_validation(self) -> None:
        schema = JsonSchema(
            properties={"name": JsonSchemaProperty(type="string")},
            required=["name"],
        )
        reg = ToolRegistry()
        reg.register(_make_tool("t", schema=schema))
        ctx = _tool_ctx()
        opts = ToolInvokeOptions(skip_validation=True)
        result = await reg.invoke("t", {}, ctx, options=opts)
        assert result.success is True

    @pytest.mark.asyncio
    async def test_invoke_permission_denied(self) -> None:
        perms = ToolPermissions(scopes=["read"], allowed_environments=["prod"])
        reg = ToolRegistry()
        reg.register(_make_tool("t", permissions=perms))
        ctx = _tool_ctx(environment="dev")
        result = await reg.invoke("t", {}, ctx)
        assert result.success is False
        assert result.error is not None
        assert result.error.code == "PERMISSION_DENIED"

    @pytest.mark.asyncio
    async def test_invoke_skip_permission_check(self) -> None:
        perms = ToolPermissions(scopes=["read"], allowed_environments=["prod"])
        reg = ToolRegistry()
        reg.register(_make_tool("t", permissions=perms))
        ctx = _tool_ctx(environment="dev")
        opts = ToolInvokeOptions(skip_permission_check=True)
        result = await reg.invoke("t", {}, ctx, options=opts)
        assert result.success is True

    @pytest.mark.asyncio
    async def test_invoke_handler_exception(self) -> None:
        async def bad_handler(args: dict[str, object], ctx: ToolContext) -> object:
            raise RuntimeError("boom")

        reg = ToolRegistry()
        reg.register(_make_tool("bad", handler=bad_handler))
        ctx = _tool_ctx()
        result = await reg.invoke("bad", {}, ctx)
        assert result.success is False
        assert result.error is not None
        assert result.error.code == "EXECUTION_ERROR"
        assert "boom" in result.error.message

    @pytest.mark.asyncio
    async def test_invoke_timeout(self) -> None:
        async def slow_handler(args: dict[str, object], ctx: ToolContext) -> object:
            await asyncio.sleep(5)
            return None

        reg = ToolRegistry()
        reg.register(_make_tool("slow", handler=slow_handler, timeout=50))
        ctx = _tool_ctx()
        result = await reg.invoke("slow", {}, ctx)
        assert result.success is False
        assert result.error is not None
        assert result.error.code == "TIMEOUT"
