"""Tests for arelis.mcp.types."""

from __future__ import annotations

from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.mcp.types import (
    MCPAuthConfigApiKey,
    MCPAuthConfigBearer,
    MCPAuthConfigNone,
    MCPContext,
    MCPGovernanceConfig,
    MCPProducerEvent,
    MCPRegistryOptions,
    MCPServerDescriptor,
    MCPToolDiscoveryResult,
    MCPToolInvokeRequest,
    MCPToolInvokeResponse,
    MCPToolSchema,
    MCPTransportConfigHttp,
    MCPTransportConfigStdio,
    get_mcp_tool_name,
    parse_mcp_tool_name,
    to_json_schema,
)

# ---------------------------------------------------------------------------
# Transport configs
# ---------------------------------------------------------------------------


class TestMCPTransportConfigStdio:
    def test_defaults(self) -> None:
        cfg = MCPTransportConfigStdio()
        assert cfg.type == "stdio"
        assert cfg.command == ""
        assert cfg.args is None
        assert cfg.env is None
        assert cfg.cwd is None

    def test_with_values(self) -> None:
        cfg = MCPTransportConfigStdio(
            command="node",
            args=["server.js"],
            env={"NODE_ENV": "production"},
            cwd="/app",
        )
        assert cfg.command == "node"
        assert cfg.args == ["server.js"]
        assert cfg.env == {"NODE_ENV": "production"}
        assert cfg.cwd == "/app"


class TestMCPTransportConfigHttp:
    def test_defaults(self) -> None:
        cfg = MCPTransportConfigHttp()
        assert cfg.type == "http"
        assert cfg.url == ""
        assert cfg.headers is None

    def test_with_values(self) -> None:
        cfg = MCPTransportConfigHttp(
            url="https://mcp.example.com",
            headers={"X-Api-Key": "secret"},
        )
        assert cfg.url == "https://mcp.example.com"
        assert cfg.headers == {"X-Api-Key": "secret"}


# ---------------------------------------------------------------------------
# Auth configs
# ---------------------------------------------------------------------------


class TestMCPAuthConfigs:
    def test_none_auth(self) -> None:
        auth = MCPAuthConfigNone()
        assert auth.type == "none"

    def test_bearer_auth(self) -> None:
        auth = MCPAuthConfigBearer(value_ref="secret://token")
        assert auth.type == "bearer"
        assert auth.value_ref == "secret://token"

    def test_api_key_auth(self) -> None:
        auth = MCPAuthConfigApiKey(
            value_ref="secret://key",
            header_name="X-Api-Key",
        )
        assert auth.type == "apiKey"
        assert auth.value_ref == "secret://key"
        assert auth.header_name == "X-Api-Key"

    def test_api_key_defaults(self) -> None:
        auth = MCPAuthConfigApiKey()
        assert auth.header_name is None


# ---------------------------------------------------------------------------
# Governance config
# ---------------------------------------------------------------------------


class TestMCPGovernanceConfig:
    def test_defaults(self) -> None:
        cfg = MCPGovernanceConfig()
        assert cfg.data_residency is None
        assert cfg.allowed_tools is None
        assert cfg.denied_tools is None
        assert cfg.approved_for_purposes is None

    def test_with_values(self) -> None:
        cfg = MCPGovernanceConfig(
            data_residency="EU",
            allowed_tools=["lookup"],
            denied_tools=["delete"],
            approved_for_purposes=["analytics"],
        )
        assert cfg.data_residency == "EU"
        assert cfg.allowed_tools == ["lookup"]
        assert cfg.denied_tools == ["delete"]


# ---------------------------------------------------------------------------
# Server descriptor
# ---------------------------------------------------------------------------


class TestMCPServerDescriptor:
    def test_minimal(self) -> None:
        desc = MCPServerDescriptor(
            id="server-1",
            transport=MCPTransportConfigHttp(url="https://mcp.example.com"),
        )
        assert desc.id == "server-1"
        assert desc.name is None
        assert desc.auth is None
        assert desc.governance is None
        assert desc.tags is None

    def test_full(self) -> None:
        desc = MCPServerDescriptor(
            id="s1",
            transport=MCPTransportConfigStdio(command="node", args=["server.js"]),
            name="My Server",
            auth=MCPAuthConfigBearer(value_ref="secret://tok"),
            governance=MCPGovernanceConfig(data_residency="US"),
            tags={"env": "prod"},
        )
        assert desc.name == "My Server"
        assert desc.auth is not None
        assert desc.governance is not None
        assert desc.tags == {"env": "prod"}


# ---------------------------------------------------------------------------
# Tool schema
# ---------------------------------------------------------------------------


class TestMCPToolSchema:
    def test_minimal(self) -> None:
        ts = MCPToolSchema(name="lookup")
        assert ts.name == "lookup"
        assert ts.description is None
        assert ts.input_schema is None

    def test_with_schema(self) -> None:
        ts = MCPToolSchema(
            name="search",
            description="Search for stuff",
            input_schema={
                "type": "object",
                "properties": {"q": {"type": "string"}},
                "required": ["q"],
            },
        )
        assert ts.description == "Search for stuff"
        assert ts.input_schema is not None


# ---------------------------------------------------------------------------
# Discovery result
# ---------------------------------------------------------------------------


class TestMCPToolDiscoveryResult:
    def test_defaults(self) -> None:
        dr = MCPToolDiscoveryResult(server_id="s1")
        assert dr.server_id == "s1"
        assert dr.tools == []
        assert dr.discovered_at == ""

    def test_with_tools(self) -> None:
        dr = MCPToolDiscoveryResult(
            server_id="s1",
            tools=[MCPToolSchema(name="t1")],
            discovered_at="2024-01-01T00:00:00Z",
        )
        assert len(dr.tools) == 1


# ---------------------------------------------------------------------------
# Invoke request/response
# ---------------------------------------------------------------------------


class TestMCPToolInvokeRequestResponse:
    def test_request(self) -> None:
        req = MCPToolInvokeRequest(tool_name="t", args={"a": 1}, server_id="s1")
        assert req.tool_name == "t"
        assert req.args == {"a": 1}

    def test_response_success(self) -> None:
        resp = MCPToolInvokeResponse(content={"result": "ok"})
        assert resp.is_error is False

    def test_response_error(self) -> None:
        resp = MCPToolInvokeResponse(content={"error": "fail"}, is_error=True)
        assert resp.is_error is True


# ---------------------------------------------------------------------------
# Lifecycle event
# ---------------------------------------------------------------------------


class TestMCPProducerEvent:
    def test_construction(self) -> None:
        evt = MCPProducerEvent(
            type="mcp.server.registered",
            server_id="s1",
            time="2024-01-01T00:00:00Z",
            transport="http",
        )
        assert evt.type == "mcp.server.registered"
        assert evt.transport == "http"
        assert evt.total_discovered is None


# ---------------------------------------------------------------------------
# Registry options
# ---------------------------------------------------------------------------


class TestMCPRegistryOptions:
    def test_defaults(self) -> None:
        opts = MCPRegistryOptions()
        assert opts.allow_overwrite is False
        assert opts.default_timeout == 30000
        assert opts.lifecycle_emitter is None


# ---------------------------------------------------------------------------
# MCP context
# ---------------------------------------------------------------------------


class TestMCPContext:
    def test_construction(self) -> None:
        gov = GovernanceContext(
            org=OrgRef(id="org-1"),
            actor=ActorRef(type="human", id="actor-1"),
            purpose="testing",
            environment="dev",
        )
        ctx = MCPContext(run_id="run_001", governance=gov)
        assert ctx.run_id == "run_001"
        assert ctx.metadata is None


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


class TestGetMCPToolName:
    def test_basic(self) -> None:
        assert get_mcp_tool_name("server1", "lookup") == "mcp.server1.lookup"

    def test_empty(self) -> None:
        assert get_mcp_tool_name("", "tool") == "mcp..tool"


class TestParseMCPToolName:
    def test_valid(self) -> None:
        result = parse_mcp_tool_name("mcp.server1.lookup")
        assert result == ("server1", "lookup")

    def test_tool_with_dots(self) -> None:
        result = parse_mcp_tool_name("mcp.server1.ns.tool")
        assert result == ("server1", "ns.tool")

    def test_invalid_prefix(self) -> None:
        assert parse_mcp_tool_name("xxx.server1.tool") is None

    def test_too_few_parts(self) -> None:
        assert parse_mcp_tool_name("mcp.server1") is None

    def test_empty_server_id(self) -> None:
        assert parse_mcp_tool_name("mcp..tool") is None

    def test_empty_tool_name(self) -> None:
        # "mcp.server." splits to ["mcp", "server", ""] -> tool_name is empty
        assert parse_mcp_tool_name("mcp.server.") is None


class TestToJsonSchema:
    def test_none_input(self) -> None:
        schema = to_json_schema(None)
        assert schema.type == "object"
        assert schema.properties == {}
        assert schema.required == []

    def test_empty_dict(self) -> None:
        schema = to_json_schema({})
        assert schema.type == "object"

    def test_with_properties(self) -> None:
        raw = {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "count": {"type": "number"},
            },
            "required": ["query"],
        }
        schema = to_json_schema(raw)
        assert schema.properties is not None
        assert "query" in schema.properties
        assert schema.properties["query"].type == "string"
        assert schema.properties["query"].description == "Search query"
        assert schema.required == ["query"]

    def test_ignores_invalid_types(self) -> None:
        raw = {
            "type": "object",
            "properties": {
                "valid": {"type": "string"},
                "invalid": {"type": "integer"},  # not in allowed set
            },
        }
        schema = to_json_schema(raw)
        assert schema.properties is not None
        assert "valid" in schema.properties
        assert "invalid" not in schema.properties
