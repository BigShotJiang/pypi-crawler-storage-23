"""Tests for arelis.mcp.transports.mock."""

from __future__ import annotations

import pytest

from arelis.mcp.transports.mock import (
    MockMCPTransport,
    MockMCPTransportOptions,
    create_mock_mcp_transport,
    create_test_mcp_transport,
)
from arelis.mcp.types import MCPToolSchema

# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestMockMCPTransportConstruction:
    def test_default_options(self) -> None:
        transport = MockMCPTransport()
        assert transport.is_connected() is False

    def test_with_tools(self) -> None:
        tools = [MCPToolSchema(name="t1"), MCPToolSchema(name="t2")]
        transport = MockMCPTransport(MockMCPTransportOptions(tools=tools))
        assert transport.is_connected() is False

    def test_factory_function(self) -> None:
        transport = create_mock_mcp_transport()
        assert isinstance(transport, MockMCPTransport)

    def test_test_factory(self) -> None:
        transport = create_test_mcp_transport()
        assert isinstance(transport, MockMCPTransport)


# ---------------------------------------------------------------------------
# Connect / disconnect
# ---------------------------------------------------------------------------


class TestMockMCPTransportConnect:
    @pytest.mark.asyncio
    async def test_connect(self) -> None:
        transport = MockMCPTransport()
        await transport.connect()
        assert transport.is_connected() is True

    @pytest.mark.asyncio
    async def test_disconnect(self) -> None:
        transport = MockMCPTransport()
        await transport.connect()
        await transport.disconnect()
        assert transport.is_connected() is False

    @pytest.mark.asyncio
    async def test_connect_failure(self) -> None:
        transport = MockMCPTransport(MockMCPTransportOptions(simulate_connection_failure=True))
        with pytest.raises(RuntimeError, match="Mock connection failure"):
            await transport.connect()
        assert transport.is_connected() is False

    @pytest.mark.asyncio
    async def test_connect_delay(self) -> None:
        transport = MockMCPTransport(MockMCPTransportOptions(connect_delay=10))
        await transport.connect()
        assert transport.is_connected() is True


# ---------------------------------------------------------------------------
# list_tools
# ---------------------------------------------------------------------------


class TestMockMCPTransportListTools:
    @pytest.mark.asyncio
    async def test_list_tools(self) -> None:
        tools = [MCPToolSchema(name="a"), MCPToolSchema(name="b")]
        transport = MockMCPTransport(MockMCPTransportOptions(tools=tools))
        await transport.connect()
        result = await transport.list_tools()
        assert len(result) == 2
        assert result[0].name == "a"

    @pytest.mark.asyncio
    async def test_list_tools_not_connected(self) -> None:
        transport = MockMCPTransport(MockMCPTransportOptions(tools=[MCPToolSchema(name="a")]))
        with pytest.raises(RuntimeError, match="Not connected"):
            await transport.list_tools()

    @pytest.mark.asyncio
    async def test_list_tools_empty(self) -> None:
        transport = MockMCPTransport()
        await transport.connect()
        result = await transport.list_tools()
        assert result == []

    @pytest.mark.asyncio
    async def test_list_tools_returns_copy(self) -> None:
        tools = [MCPToolSchema(name="a")]
        transport = MockMCPTransport(MockMCPTransportOptions(tools=tools))
        await transport.connect()
        result1 = await transport.list_tools()
        result2 = await transport.list_tools()
        assert result1 is not result2


# ---------------------------------------------------------------------------
# invoke_tool
# ---------------------------------------------------------------------------


class TestMockMCPTransportInvoke:
    @pytest.mark.asyncio
    async def test_invoke_default_handler(self) -> None:
        transport = MockMCPTransport(MockMCPTransportOptions(tools=[MCPToolSchema(name="echo")]))
        await transport.connect()
        response = await transport.invoke_tool("echo", {"q": "hi"})
        assert response.is_error is False
        assert isinstance(response.content, dict)
        assert response.content["tool"] == "echo"  # type: ignore[index]

    @pytest.mark.asyncio
    async def test_invoke_custom_handler(self) -> None:
        async def custom_handler(name: str, args: dict[str, object]) -> object:
            return {"custom": True, "name": name}

        transport = MockMCPTransport(
            MockMCPTransportOptions(
                tools=[MCPToolSchema(name="my-tool")],
                handler=custom_handler,
            )
        )
        await transport.connect()
        response = await transport.invoke_tool("my-tool", {})
        assert response.is_error is False
        assert response.content["custom"] is True  # type: ignore[index]

    @pytest.mark.asyncio
    async def test_invoke_tool_not_found(self) -> None:
        transport = MockMCPTransport()
        await transport.connect()
        response = await transport.invoke_tool("nonexistent", {})
        assert response.is_error is True

    @pytest.mark.asyncio
    async def test_invoke_not_connected(self) -> None:
        transport = MockMCPTransport(MockMCPTransportOptions(tools=[MCPToolSchema(name="t")]))
        with pytest.raises(RuntimeError, match="Not connected"):
            await transport.invoke_tool("t", {})

    @pytest.mark.asyncio
    async def test_invoke_handler_exception(self) -> None:
        async def failing_handler(name: str, args: dict[str, object]) -> object:
            raise ValueError("handler error")

        transport = MockMCPTransport(
            MockMCPTransportOptions(
                tools=[MCPToolSchema(name="fail")],
                handler=failing_handler,
            )
        )
        await transport.connect()
        response = await transport.invoke_tool("fail", {})
        assert response.is_error is True

    @pytest.mark.asyncio
    async def test_invoke_with_delay(self) -> None:
        transport = MockMCPTransport(
            MockMCPTransportOptions(
                tools=[MCPToolSchema(name="slow")],
                invoke_delay=10,
            )
        )
        await transport.connect()
        response = await transport.invoke_tool("slow", {})
        assert response.is_error is False


# ---------------------------------------------------------------------------
# add_tool / set_handler
# ---------------------------------------------------------------------------


class TestMockMCPTransportHelpers:
    @pytest.mark.asyncio
    async def test_add_tool(self) -> None:
        transport = MockMCPTransport()
        await transport.connect()
        assert await transport.list_tools() == []
        transport.add_tool(MCPToolSchema(name="new"))
        tools = await transport.list_tools()
        assert len(tools) == 1
        assert tools[0].name == "new"

    @pytest.mark.asyncio
    async def test_set_handler(self) -> None:
        async def new_handler(name: str, args: dict[str, object]) -> object:
            return "replaced"

        transport = MockMCPTransport(MockMCPTransportOptions(tools=[MCPToolSchema(name="t")]))
        transport.set_handler(new_handler)
        await transport.connect()
        response = await transport.invoke_tool("t", {})
        assert response.content == "replaced"


# ---------------------------------------------------------------------------
# create_test_mcp_transport
# ---------------------------------------------------------------------------


class TestCreateTestMCPTransport:
    @pytest.mark.asyncio
    async def test_has_default_tools(self) -> None:
        transport = create_test_mcp_transport()
        await transport.connect()
        tools = await transport.list_tools()
        names = [t.name for t in tools]
        assert "lookup" in names
        assert "create" in names
        assert "update" in names
        assert len(tools) == 3
