"""Tests for arelis.mcp.registry."""

from __future__ import annotations

import pytest

from arelis.mcp.registry import MCPRegistry, RegisteredMCPServer, create_mcp_registry
from arelis.mcp.transports.mock import MockMCPTransport
from arelis.mcp.types import (
    MCPGovernanceConfig,
    MCPProducerEvent,
    MCPRegistryOptions,
    MCPServerDescriptor,
    MCPTransportConfigHttp,
    MCPTransportConfigStdio,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _http_desc(
    server_id: str = "server-1",
    url: str = "https://mcp.example.com",
    governance: MCPGovernanceConfig | None = None,
) -> MCPServerDescriptor:
    return MCPServerDescriptor(
        id=server_id,
        transport=MCPTransportConfigHttp(url=url),
        governance=governance,
    )


def _stdio_desc(server_id: str = "server-1", command: str = "node") -> MCPServerDescriptor:
    return MCPServerDescriptor(
        id=server_id,
        transport=MCPTransportConfigStdio(command=command),
    )


# ---------------------------------------------------------------------------
# create_mcp_registry
# ---------------------------------------------------------------------------


class TestCreateMCPRegistry:
    def test_returns_registry(self) -> None:
        reg = create_mcp_registry()
        assert isinstance(reg, MCPRegistry)
        assert reg.size == 0

    def test_custom_options(self) -> None:
        reg = create_mcp_registry(MCPRegistryOptions(allow_overwrite=True, default_timeout=5000))
        assert reg.default_timeout == 5000


# ---------------------------------------------------------------------------
# register_server
# ---------------------------------------------------------------------------


class TestRegisterServer:
    def test_register_http(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        assert reg.has_server("s1") is True
        assert reg.size == 1

    def test_register_stdio(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_stdio_desc("s1"))
        assert reg.has_server("s1") is True

    def test_duplicate_raises(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        with pytest.raises(ValueError, match="already registered"):
            reg.register_server(_http_desc("s1"))

    def test_duplicate_with_overwrite(self) -> None:
        reg = MCPRegistry(MCPRegistryOptions(allow_overwrite=True))
        reg.register_server(_http_desc("s1", url="https://old.example.com"))
        reg.register_server(_http_desc("s1", url="https://new.example.com"))
        assert reg.size == 1
        server = reg.get_server("s1")
        assert server is not None
        assert isinstance(server.descriptor.transport, MCPTransportConfigHttp)
        assert server.descriptor.transport.url == "https://new.example.com"

    def test_empty_id_raises(self) -> None:
        reg = MCPRegistry()
        with pytest.raises(ValueError, match="ID"):
            reg.register_server(
                MCPServerDescriptor(
                    id="",
                    transport=MCPTransportConfigHttp(url="https://x.com"),
                )
            )

    def test_stdio_missing_command_raises(self) -> None:
        reg = MCPRegistry()
        with pytest.raises(ValueError, match="command"):
            reg.register_server(
                MCPServerDescriptor(
                    id="s1",
                    transport=MCPTransportConfigStdio(command=""),
                )
            )

    def test_http_missing_url_raises(self) -> None:
        reg = MCPRegistry()
        with pytest.raises(ValueError, match="URL"):
            reg.register_server(
                MCPServerDescriptor(
                    id="s1",
                    transport=MCPTransportConfigHttp(url=""),
                )
            )


# ---------------------------------------------------------------------------
# get_server / has_server
# ---------------------------------------------------------------------------


class TestGetServer:
    def test_get_existing(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        server = reg.get_server("s1")
        assert server is not None
        assert isinstance(server, RegisteredMCPServer)
        assert server.descriptor.id == "s1"
        assert server.registered_at != ""

    def test_get_missing(self) -> None:
        assert MCPRegistry().get_server("nope") is None

    def test_has_server_false(self) -> None:
        assert MCPRegistry().has_server("nope") is False


# ---------------------------------------------------------------------------
# list_servers / list_server_ids
# ---------------------------------------------------------------------------


class TestListServers:
    def test_list_servers(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("a"))
        reg.register_server(_http_desc("b"))
        servers = reg.list_servers()
        assert len(servers) == 2

    def test_list_server_ids(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("x"))
        reg.register_server(_http_desc("y"))
        assert set(reg.list_server_ids()) == {"x", "y"}


# ---------------------------------------------------------------------------
# unregister_server / clear
# ---------------------------------------------------------------------------


class TestUnregisterServer:
    def test_unregister_existing(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        assert reg.unregister_server("s1") is True
        assert reg.size == 0

    def test_unregister_missing(self) -> None:
        assert MCPRegistry().unregister_server("nope") is False

    def test_clear(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("a"))
        reg.register_server(_http_desc("b"))
        reg.clear()
        assert reg.size == 0


# ---------------------------------------------------------------------------
# Transport management
# ---------------------------------------------------------------------------


class TestTransportManagement:
    def test_set_and_get_transport(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        transport = MockMCPTransport()
        reg.set_transport("s1", transport)
        assert reg.get_transport("s1") is transport

    def test_set_transport_missing_server_raises(self) -> None:
        reg = MCPRegistry()
        with pytest.raises(ValueError, match="not found"):
            reg.set_transport("nope", MockMCPTransport())

    def test_get_transport_missing_server(self) -> None:
        assert MCPRegistry().get_transport("nope") is None

    def test_get_transport_no_transport_set(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        assert reg.get_transport("s1") is None


# ---------------------------------------------------------------------------
# Governance checks
# ---------------------------------------------------------------------------


class TestGovernanceChecks:
    def test_tool_allowed_no_governance(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        assert reg.is_tool_allowed("s1", "anything") is True

    def test_tool_denied(self) -> None:
        gov = MCPGovernanceConfig(denied_tools=["dangerous"])
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1", governance=gov))
        assert reg.is_tool_allowed("s1", "dangerous") is False
        assert reg.is_tool_allowed("s1", "safe") is True

    def test_tool_allowed_list(self) -> None:
        gov = MCPGovernanceConfig(allowed_tools=["lookup", "search"])
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1", governance=gov))
        assert reg.is_tool_allowed("s1", "lookup") is True
        assert reg.is_tool_allowed("s1", "delete") is False

    def test_denied_takes_precedence(self) -> None:
        gov = MCPGovernanceConfig(allowed_tools=["lookup"], denied_tools=["lookup"])
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1", governance=gov))
        assert reg.is_tool_allowed("s1", "lookup") is False

    def test_tool_allowed_unknown_server(self) -> None:
        assert MCPRegistry().is_tool_allowed("nope", "tool") is False

    def test_purpose_approved_no_governance(self) -> None:
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1"))
        assert reg.is_purpose_approved("s1", "anything") is True

    def test_purpose_approved(self) -> None:
        gov = MCPGovernanceConfig(approved_for_purposes=["analytics", "support"])
        reg = MCPRegistry()
        reg.register_server(_http_desc("s1", governance=gov))
        assert reg.is_purpose_approved("s1", "analytics") is True
        assert reg.is_purpose_approved("s1", "marketing") is False

    def test_purpose_unknown_server(self) -> None:
        assert MCPRegistry().is_purpose_approved("nope", "x") is False


# ---------------------------------------------------------------------------
# Lifecycle events
# ---------------------------------------------------------------------------


class TestLifecycleEvents:
    def test_lifecycle_emitter_called_on_register(self) -> None:
        events: list[MCPProducerEvent] = []
        reg = MCPRegistry(MCPRegistryOptions(lifecycle_emitter=lambda e: events.append(e)))
        reg.register_server(_http_desc("s1"))
        assert len(events) == 1
        assert events[0].type == "mcp.server.registered"
        assert events[0].server_id == "s1"
        assert events[0].transport == "http"

    def test_notify_tools_discovered(self) -> None:
        events: list[MCPProducerEvent] = []
        reg = MCPRegistry(MCPRegistryOptions(lifecycle_emitter=lambda e: events.append(e)))
        reg.register_server(_http_desc("s1"))
        events.clear()
        reg.notify_tools_discovered("s1", 3, 2, 1, ["t1", "t2"])
        assert len(events) == 1
        assert events[0].type == "mcp.tools.discovered"
        assert events[0].total_discovered == 3
        assert events[0].registered_count == 2
        assert events[0].skipped_count == 1
        assert events[0].tool_names == ["t1", "t2"]

    def test_notify_connected(self) -> None:
        events: list[MCPProducerEvent] = []
        reg = MCPRegistry(MCPRegistryOptions(lifecycle_emitter=lambda e: events.append(e)))
        reg.register_server(_http_desc("s1"))
        events.clear()
        reg.notify_server_connected("s1")
        assert len(events) == 1
        assert events[0].type == "mcp.server.connected"

    def test_notify_disconnected(self) -> None:
        events: list[MCPProducerEvent] = []
        reg = MCPRegistry(MCPRegistryOptions(lifecycle_emitter=lambda e: events.append(e)))
        reg.register_server(_http_desc("s1"))
        events.clear()
        reg.notify_server_disconnected("s1", reason="shutdown")
        assert len(events) == 1
        assert events[0].type == "mcp.server.disconnected"
        assert events[0].reason == "shutdown"

    def test_notify_unknown_server_is_noop(self) -> None:
        events: list[MCPProducerEvent] = []
        reg = MCPRegistry(MCPRegistryOptions(lifecycle_emitter=lambda e: events.append(e)))
        reg.notify_server_connected("unknown")
        assert len(events) == 0
