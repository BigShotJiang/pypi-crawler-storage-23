"""Tests for arelis.prompts.registry."""

from __future__ import annotations

import hashlib

import pytest

from arelis.prompts.registry import (
    TemplateRegistry,
    compute_prompt_hash,
    create_template_registry,
)
from arelis.prompts.types import (
    PromptTemplate,
    PromptTemplateInput,
    PromptTemplateMetadata,
    PromptTemplateQuery,
)

# ---------------------------------------------------------------------------
# compute_prompt_hash
# ---------------------------------------------------------------------------


class TestComputePromptHash:
    def test_returns_sha256_hex(self) -> None:
        result = compute_prompt_hash("tpl-1", "1.0", "Hello {{name}}")
        expected = hashlib.sha256(b"tpl-1:1.0:Hello {{name}}").hexdigest()
        assert result == expected

    def test_different_inputs_produce_different_hashes(self) -> None:
        h1 = compute_prompt_hash("a", "1", "content")
        h2 = compute_prompt_hash("b", "1", "content")
        h3 = compute_prompt_hash("a", "2", "content")
        h4 = compute_prompt_hash("a", "1", "other")
        assert len({h1, h2, h3, h4}) == 4

    def test_same_inputs_produce_same_hash(self) -> None:
        h1 = compute_prompt_hash("id", "v", "c")
        h2 = compute_prompt_hash("id", "v", "c")
        assert h1 == h2


# ---------------------------------------------------------------------------
# TemplateRegistry.register
# ---------------------------------------------------------------------------


class TestTemplateRegistryRegister:
    def test_register_returns_template(self) -> None:
        registry = TemplateRegistry()
        inp = PromptTemplateInput(id="tpl-1", version="1.0", content="Hello")
        result = registry.register(inp)
        assert isinstance(result, PromptTemplate)
        assert result.id == "tpl-1"
        assert result.version == "1.0"
        assert result.content == "Hello"
        assert result.hash == compute_prompt_hash("tpl-1", "1.0", "Hello")
        assert result.created_at  # non-empty

    def test_register_with_metadata(self) -> None:
        registry = TemplateRegistry()
        meta = PromptTemplateMetadata(description="A greeting", tags={"lang": "en"})
        inp = PromptTemplateInput(id="tpl-1", version="1.0", content="Hi", metadata=meta)
        result = registry.register(inp)
        assert result.metadata is not None
        assert result.metadata.description == "A greeting"
        assert result.metadata.tags == {"lang": "en"}

    def test_register_raises_on_empty_id(self) -> None:
        registry = TemplateRegistry()
        inp = PromptTemplateInput(id="", version="1.0", content="test")
        with pytest.raises(ValueError, match="id and version are required"):
            registry.register(inp)

    def test_register_raises_on_empty_version(self) -> None:
        registry = TemplateRegistry()
        inp = PromptTemplateInput(id="tpl-1", version="", content="test")
        with pytest.raises(ValueError, match="id and version are required"):
            registry.register(inp)

    def test_register_multiple_versions(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="tpl-1", version="1.0", content="v1"))
        registry.register(PromptTemplateInput(id="tpl-1", version="2.0", content="v2"))
        templates = registry.list(id="tpl-1")
        assert len(templates) == 2


# ---------------------------------------------------------------------------
# TemplateRegistry.get
# ---------------------------------------------------------------------------


class TestTemplateRegistryGet:
    def test_get_by_id_and_version(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="tpl-1", version="1.0", content="v1"))
        registry.register(PromptTemplateInput(id="tpl-1", version="2.0", content="v2"))
        result = registry.get(PromptTemplateQuery(id="tpl-1", version="1.0"))
        assert result is not None
        assert result.content == "v1"

    def test_get_latest_version_when_no_version_specified(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="tpl-1", version="1.0", content="v1"))
        registry.register(PromptTemplateInput(id="tpl-1", version="2.0", content="v2"))
        result = registry.get(PromptTemplateQuery(id="tpl-1"))
        assert result is not None
        assert result.version == "2.0"
        assert result.content == "v2"

    def test_get_returns_none_for_unknown_id(self) -> None:
        registry = TemplateRegistry()
        result = registry.get(PromptTemplateQuery(id="unknown"))
        assert result is None

    def test_get_returns_none_for_unknown_version(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="tpl-1", version="1.0", content="v1"))
        result = registry.get(PromptTemplateQuery(id="tpl-1", version="99.0"))
        assert result is None


# ---------------------------------------------------------------------------
# TemplateRegistry.list
# ---------------------------------------------------------------------------


class TestTemplateRegistryList:
    def test_list_all_templates(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="a", version="1", content="a1"))
        registry.register(PromptTemplateInput(id="b", version="1", content="b1"))
        all_templates = registry.list()
        assert len(all_templates) == 2

    def test_list_by_id(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="a", version="1", content="a1"))
        registry.register(PromptTemplateInput(id="a", version="2", content="a2"))
        registry.register(PromptTemplateInput(id="b", version="1", content="b1"))
        a_templates = registry.list(id="a")
        assert len(a_templates) == 2
        assert all(t.id == "a" for t in a_templates)

    def test_list_by_unknown_id_returns_empty(self) -> None:
        registry = TemplateRegistry()
        result = registry.list(id="nope")
        assert result == []

    def test_list_empty_registry(self) -> None:
        registry = TemplateRegistry()
        assert registry.list() == []


# ---------------------------------------------------------------------------
# TemplateRegistry.clear
# ---------------------------------------------------------------------------


class TestTemplateRegistryClear:
    def test_clear_removes_all(self) -> None:
        registry = TemplateRegistry()
        registry.register(PromptTemplateInput(id="a", version="1", content="c"))
        registry.clear()
        assert registry.list() == []
        assert registry.get(PromptTemplateQuery(id="a")) is None


# ---------------------------------------------------------------------------
# create_template_registry factory
# ---------------------------------------------------------------------------


class TestCreateTemplateRegistry:
    def test_returns_registry_instance(self) -> None:
        registry = create_template_registry()
        assert isinstance(registry, TemplateRegistry)
