"""Tests for arelis.telemetry.noop."""

from __future__ import annotations

from arelis.telemetry.noop import NoOpSpanHandle, NoOpTelemetry, create_noop_telemetry
from arelis.telemetry.types import SpanHandle, Telemetry

# ---------------------------------------------------------------------------
# NoOpSpanHandle
# ---------------------------------------------------------------------------


class TestNoOpSpanHandle:
    def test_end_no_op(self) -> None:
        handle = NoOpSpanHandle()
        handle.end()  # should not raise

    def test_add_event_no_op(self) -> None:
        handle = NoOpSpanHandle()
        handle.add_event("test_event")
        handle.add_event("test_event", {"key": "value"})

    def test_set_attribute_no_op(self) -> None:
        handle = NoOpSpanHandle()
        handle.set_attribute("key", "value")
        handle.set_attribute("count", 42)
        handle.set_attribute("ratio", 0.5)
        handle.set_attribute("flag", True)

    def test_record_error_no_op(self) -> None:
        handle = NoOpSpanHandle()
        handle.record_error(RuntimeError("test"))

    def test_set_status_no_op(self) -> None:
        handle = NoOpSpanHandle()
        handle.set_status("ok")
        handle.set_status("error", "something went wrong")

    def test_implements_span_handle_protocol(self) -> None:
        handle = NoOpSpanHandle()
        assert isinstance(handle, SpanHandle)


# ---------------------------------------------------------------------------
# NoOpTelemetry
# ---------------------------------------------------------------------------


class TestNoOpTelemetry:
    def test_start_span_returns_span_handle(self) -> None:
        telemetry = NoOpTelemetry()
        handle = telemetry.start_span("test")
        assert isinstance(handle, NoOpSpanHandle)

    def test_start_span_with_attributes(self) -> None:
        telemetry = NoOpTelemetry()
        handle = telemetry.start_span("test", {"key": "value"})
        assert isinstance(handle, NoOpSpanHandle)

    def test_add_event_no_op(self) -> None:
        telemetry = NoOpTelemetry()
        telemetry.add_event("event")
        telemetry.add_event("event", {"k": 1})

    def test_context_attributes_returns_dict(self) -> None:
        telemetry = NoOpTelemetry()
        # Use a simple object with expected attributes
        attrs = telemetry.context_attributes(object())
        assert isinstance(attrs, dict)

    def test_context_attributes_with_governance_like_object(self) -> None:

        class FakeContext:
            class _Org:
                id = "org-1"
                name = "Test Org"

            class _Actor:
                type = "human"
                id = "actor-1"

            org = _Org()
            actor = _Actor()
            purpose = "testing"
            environment = "dev"

        telemetry = NoOpTelemetry()
        attrs = telemetry.context_attributes(FakeContext())
        assert attrs["arelis.org.id"] == "org-1"
        assert attrs["arelis.actor.id"] == "actor-1"
        assert attrs["arelis.purpose"] == "testing"
        assert attrs["arelis.environment"] == "dev"

    def test_implements_telemetry_protocol(self) -> None:
        telemetry = NoOpTelemetry()
        assert isinstance(telemetry, Telemetry)

    def test_same_span_handle_reused(self) -> None:
        telemetry = NoOpTelemetry()
        h1 = telemetry.start_span("a")
        h2 = telemetry.start_span("b")
        assert h1 is h2  # singleton NoOpSpanHandle


# ---------------------------------------------------------------------------
# create_noop_telemetry
# ---------------------------------------------------------------------------


class TestCreateNoopTelemetry:
    def test_returns_telemetry_instance(self) -> None:
        telemetry = create_noop_telemetry()
        assert isinstance(telemetry, Telemetry)

    def test_singleton(self) -> None:
        t1 = create_noop_telemetry()
        t2 = create_noop_telemetry()
        assert t1 is t2
