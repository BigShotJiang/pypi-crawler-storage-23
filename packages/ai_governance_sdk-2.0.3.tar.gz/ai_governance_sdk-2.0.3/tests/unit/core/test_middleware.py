"""Tests for arelis.core.middleware."""

from __future__ import annotations

from collections.abc import Awaitable, Callable

import pytest

from arelis.core.middleware import (
    MiddlewarePipeline,
    compose_middleware,
    named_middleware,
)
from arelis.core.types import ActorRef, GovernanceContext, MiddlewareContext, OrgRef


def _make_mw_ctx(run_id: str = "run_test") -> MiddlewareContext:
    gov = GovernanceContext(
        org=OrgRef(id="org-1"),
        actor=ActorRef(type="human", id="u-1"),
        purpose="test",
        environment="dev",
    )
    return MiddlewareContext(run_id=run_id, context=gov)


# ---------------------------------------------------------------------------
# MiddlewarePipeline
# ---------------------------------------------------------------------------


class TestMiddlewarePipeline:
    @pytest.mark.asyncio
    async def test_empty_pipeline(self) -> None:
        pipeline = MiddlewarePipeline()
        assert pipeline.length == 0
        # Should not raise
        await pipeline.execute(_make_mw_ctx())

    @pytest.mark.asyncio
    async def test_single_middleware(self) -> None:
        called = False

        async def mw(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            nonlocal called
            called = True
            await next_fn()

        pipeline = MiddlewarePipeline()
        pipeline.use(mw)
        assert pipeline.length == 1
        await pipeline.execute(_make_mw_ctx())
        assert called is True

    @pytest.mark.asyncio
    async def test_execution_order(self) -> None:
        order: list[str] = []

        async def mw_a(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            order.append("a-before")
            await next_fn()
            order.append("a-after")

        async def mw_b(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            order.append("b-before")
            await next_fn()
            order.append("b-after")

        pipeline = MiddlewarePipeline()
        pipeline.use(mw_a)
        pipeline.use(mw_b)
        await pipeline.execute(_make_mw_ctx())
        assert order == ["a-before", "b-before", "b-after", "a-after"]

    @pytest.mark.asyncio
    async def test_short_circuit(self) -> None:
        """Middleware that does not call next() short-circuits the pipeline."""
        order: list[str] = []

        async def mw_blocker(
            ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]
        ) -> None:
            order.append("blocker")
            # Intentionally NOT calling next_fn

        async def mw_after(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            order.append("after")
            await next_fn()

        pipeline = MiddlewarePipeline()
        pipeline.use(mw_blocker)
        pipeline.use(mw_after)
        await pipeline.execute(_make_mw_ctx())
        assert order == ["blocker"]

    @pytest.mark.asyncio
    async def test_middleware_can_modify_context(self) -> None:
        async def mw(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            ctx.metadata["injected"] = True
            await next_fn()

        ctx = _make_mw_ctx()
        pipeline = MiddlewarePipeline()
        pipeline.use(mw)
        await pipeline.execute(ctx)
        assert ctx.metadata["injected"] is True

    def test_use_returns_self(self) -> None:
        async def mw(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            await next_fn()

        pipeline = MiddlewarePipeline()
        result = pipeline.use(mw)
        assert result is pipeline

    def test_clear(self) -> None:
        async def mw(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            await next_fn()

        pipeline = MiddlewarePipeline()
        pipeline.use(mw)
        assert pipeline.length == 1
        pipeline.clear()
        assert pipeline.length == 0

    @pytest.mark.asyncio
    async def test_error_propagation(self) -> None:
        async def mw_error(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            raise RuntimeError("boom")

        pipeline = MiddlewarePipeline()
        pipeline.use(mw_error)
        with pytest.raises(RuntimeError, match="boom"):
            await pipeline.execute(_make_mw_ctx())


# ---------------------------------------------------------------------------
# compose_middleware
# ---------------------------------------------------------------------------


class TestComposeMiddleware:
    @pytest.mark.asyncio
    async def test_composed_execution_order(self) -> None:
        order: list[str] = []

        async def mw_a(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            order.append("a")
            await next_fn()

        async def mw_b(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            order.append("b")
            await next_fn()

        composed = compose_middleware(mw_a, mw_b)

        # Use in a pipeline to verify outer next is called
        order_outer: list[str] = []

        async def outer_mw(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            order_outer.append("outer")
            await next_fn()

        pipeline = MiddlewarePipeline()
        pipeline.use(composed)
        pipeline.use(outer_mw)
        await pipeline.execute(_make_mw_ctx())
        assert order == ["a", "b"]
        assert order_outer == ["outer"]

    @pytest.mark.asyncio
    async def test_composed_calls_outer_next(self) -> None:
        """After all composed middlewares run, the outer next is invoked."""
        outer_called = False

        async def mw(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            await next_fn()

        composed = compose_middleware(mw)

        async def check_next() -> None:
            nonlocal outer_called
            outer_called = True

        ctx = _make_mw_ctx()
        await composed(ctx, check_next)
        assert outer_called is True

    @pytest.mark.asyncio
    async def test_empty_compose(self) -> None:
        """Composing zero middlewares just calls next."""
        called = False

        async def check_next() -> None:
            nonlocal called
            called = True

        composed = compose_middleware()
        await composed(_make_mw_ctx(), check_next)
        assert called is True


# ---------------------------------------------------------------------------
# named_middleware
# ---------------------------------------------------------------------------


class TestNamedMiddleware:
    @pytest.mark.asyncio
    async def test_records_timing(self) -> None:
        async def inner(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            await next_fn()

        named = named_middleware("auth", inner)
        ctx = _make_mw_ctx()
        pipeline = MiddlewarePipeline()
        pipeline.use(named)
        await pipeline.execute(ctx)

        assert "middleware.auth.started" in ctx.metadata
        assert "middleware.auth.ended" in ctx.metadata
        started = ctx.metadata["middleware.auth.started"]
        ended = ctx.metadata["middleware.auth.ended"]
        assert isinstance(started, int)
        assert isinstance(ended, int)
        assert ended >= started

    @pytest.mark.asyncio
    async def test_records_timing_on_error(self) -> None:
        """Timing metadata is recorded even if the middleware raises."""

        async def inner(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            raise RuntimeError("fail")

        named = named_middleware("failing", inner)
        ctx = _make_mw_ctx()
        pipeline = MiddlewarePipeline()
        pipeline.use(named)

        with pytest.raises(RuntimeError):
            await pipeline.execute(ctx)

        assert "middleware.failing.started" in ctx.metadata
        assert "middleware.failing.ended" in ctx.metadata

    def test_function_name(self) -> None:
        async def inner(ctx: MiddlewareContext, next_fn: Callable[[], Awaitable[None]]) -> None:
            await next_fn()

        named = named_middleware("my_mw", inner)
        assert named.__name__ == "my_mw"
        assert named.__qualname__ == "my_mw"
