"""Tests for arelis.core.approval_store."""

from __future__ import annotations

import pytest

from arelis.core.approval_store import (
    ApprovalStore,
    CreateApprovalRequest,
    InMemoryApprovalStore,
    create_in_memory_approval_store,
)
from arelis.core.types import ActorRef, GovernanceContext, OrgRef


def _make_ctx() -> GovernanceContext:
    return GovernanceContext(
        org=OrgRef(id="org-1"),
        actor=ActorRef(type="human", id="u-1"),
        purpose="testing",
        environment="dev",
    )


def _make_create_request(**overrides: object) -> CreateApprovalRequest:
    defaults: dict[str, object] = {
        "run_id": "run_1",
        "context": _make_ctx(),
        "operation": "model.generate",
        "reason": "needs approval",
        "approvers": ["alice"],
    }
    defaults.update(overrides)
    return CreateApprovalRequest(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# InMemoryApprovalStore
# ---------------------------------------------------------------------------


class TestInMemoryApprovalStore:
    @pytest.mark.asyncio
    async def test_create_returns_pending(self) -> None:
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request())
        assert req.status == "pending"
        assert req.id.startswith("approval_")
        assert req.run_id == "run_1"
        assert req.operation == "model.generate"
        assert req.reason == "needs approval"
        assert req.approvers == ["alice"]
        assert req.resolved_at is None
        assert req.resolved_by is None

    @pytest.mark.asyncio
    async def test_get_existing(self) -> None:
        store = InMemoryApprovalStore()
        created = await store.create(_make_create_request())
        fetched = await store.get(created.id)
        assert fetched is not None
        assert fetched.id == created.id

    @pytest.mark.asyncio
    async def test_get_missing(self) -> None:
        store = InMemoryApprovalStore()
        result = await store.get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_list_all(self) -> None:
        store = InMemoryApprovalStore()
        await store.create(_make_create_request())
        await store.create(_make_create_request(operation="tool.invoke"))
        items = await store.list()
        assert len(items) == 2

    @pytest.mark.asyncio
    async def test_list_filtered_by_status(self) -> None:
        store = InMemoryApprovalStore()
        r1 = await store.create(_make_create_request())
        await store.create(_make_create_request(operation="tool.invoke"))
        await store.approve(r1.id, "admin")

        pending = await store.list(status="pending")
        assert len(pending) == 1

        approved = await store.list(status="approved")
        assert len(approved) == 1
        assert approved[0].id == r1.id

    @pytest.mark.asyncio
    async def test_approve(self) -> None:
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request())
        decision = await store.approve(req.id, "admin", reason="looks good")

        assert decision.status == "approved"
        assert decision.resolved_by == "admin"
        assert decision.reason == "looks good"
        assert decision.id == req.id

        # Verify the stored request was updated
        updated = await store.get(req.id)
        assert updated is not None
        assert updated.status == "approved"
        assert updated.resolved_by == "admin"
        assert updated.resolved_at is not None
        assert updated.metadata is not None
        assert updated.metadata["reason"] == "looks good"

    @pytest.mark.asyncio
    async def test_reject(self) -> None:
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request())
        decision = await store.reject(req.id, "admin", reason="not allowed")

        assert decision.status == "rejected"
        assert decision.resolved_by == "admin"
        assert decision.reason == "not allowed"

        updated = await store.get(req.id)
        assert updated is not None
        assert updated.status == "rejected"

    @pytest.mark.asyncio
    async def test_approve_nonexistent_raises(self) -> None:
        store = InMemoryApprovalStore()
        with pytest.raises(KeyError, match="not found"):
            await store.approve("nonexistent", "admin")

    @pytest.mark.asyncio
    async def test_reject_nonexistent_raises(self) -> None:
        store = InMemoryApprovalStore()
        with pytest.raises(KeyError, match="not found"):
            await store.reject("nonexistent", "admin")

    @pytest.mark.asyncio
    async def test_approve_without_reason(self) -> None:
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request())
        decision = await store.approve(req.id, "admin")
        assert decision.reason is None
        updated = await store.get(req.id)
        assert updated is not None
        # metadata should not have reason key if no reason given
        assert updated.metadata is None

    @pytest.mark.asyncio
    async def test_create_without_approvers(self) -> None:
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request(approvers=None))
        assert req.approvers == []

    @pytest.mark.asyncio
    async def test_create_with_metadata(self) -> None:
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request(metadata={"key": "val"}))
        assert req.metadata is not None
        assert req.metadata["key"] == "val"

    @pytest.mark.asyncio
    async def test_metadata_is_copied(self) -> None:
        """Mutating the input metadata should not affect the stored request."""
        meta: dict[str, object] = {"key": "val"}
        store = InMemoryApprovalStore()
        req = await store.create(_make_create_request(metadata=meta))
        meta["key"] = "changed"
        stored = await store.get(req.id)
        assert stored is not None
        assert stored.metadata is not None
        assert stored.metadata["key"] == "val"


# ---------------------------------------------------------------------------
# create_in_memory_approval_store factory
# ---------------------------------------------------------------------------


class TestCreateInMemoryApprovalStore:
    def test_returns_instance(self) -> None:
        store = create_in_memory_approval_store()
        assert isinstance(store, InMemoryApprovalStore)


# ---------------------------------------------------------------------------
# Protocol conformance
# ---------------------------------------------------------------------------


class TestProtocolConformance:
    def test_implements_protocol(self) -> None:
        store = InMemoryApprovalStore()
        assert isinstance(store, ApprovalStore)
