"""Tests for arelis.core.types."""

from __future__ import annotations

from arelis.core.types import (
    ActorRef,
    GovernanceContext,
    MiddlewareContext,
    OrgRef,
    PolicySummary,
    ResultEnvelope,
    RunWarning,
    TeamRef,
    UsageInfo,
)

# ---------------------------------------------------------------------------
# OrgRef
# ---------------------------------------------------------------------------


class TestOrgRef:
    def test_required_id(self) -> None:
        org = OrgRef(id="org-1")
        assert org.id == "org-1"
        assert org.name is None

    def test_with_name(self) -> None:
        org = OrgRef(id="org-1", name="Acme Corp")
        assert org.id == "org-1"
        assert org.name == "Acme Corp"


# ---------------------------------------------------------------------------
# TeamRef
# ---------------------------------------------------------------------------


class TestTeamRef:
    def test_required_id(self) -> None:
        team = TeamRef(id="team-1")
        assert team.id == "team-1"
        assert team.name is None

    def test_with_name(self) -> None:
        team = TeamRef(id="team-1", name="Engineering")
        assert team.name == "Engineering"


# ---------------------------------------------------------------------------
# ActorRef
# ---------------------------------------------------------------------------


class TestActorRef:
    def test_minimal(self) -> None:
        actor = ActorRef(type="human", id="user-1")
        assert actor.type == "human"
        assert actor.id == "user-1"
        assert actor.email is None
        assert actor.roles is None

    def test_full(self) -> None:
        actor = ActorRef(
            type="service",
            id="svc-1",
            email="svc@example.com",
            roles=["admin", "reader"],
        )
        assert actor.type == "service"
        assert actor.email == "svc@example.com"
        assert actor.roles == ["admin", "reader"]

    def test_agent_type(self) -> None:
        actor = ActorRef(type="agent", id="agent-1")
        assert actor.type == "agent"


# ---------------------------------------------------------------------------
# GovernanceContext
# ---------------------------------------------------------------------------


class TestGovernanceContext:
    def test_minimal(self) -> None:
        ctx = GovernanceContext(
            org=OrgRef(id="org-1"),
            actor=ActorRef(type="human", id="u-1"),
            purpose="testing",
            environment="dev",
        )
        assert ctx.org.id == "org-1"
        assert ctx.actor.id == "u-1"
        assert ctx.purpose == "testing"
        assert ctx.environment == "dev"
        assert ctx.team is None
        assert ctx.session_id is None
        assert ctx.request_id is None
        assert ctx.tags is None

    def test_full(self) -> None:
        ctx = GovernanceContext(
            org=OrgRef(id="org-1", name="Acme"),
            actor=ActorRef(type="human", id="u-1"),
            purpose="testing",
            environment="prod",
            team=TeamRef(id="team-1", name="Eng"),
            session_id="sess-1",
            request_id="req-1",
            tags={"project": "alpha"},
        )
        assert ctx.team is not None
        assert ctx.team.id == "team-1"
        assert ctx.session_id == "sess-1"
        assert ctx.request_id == "req-1"
        assert ctx.tags == {"project": "alpha"}


# ---------------------------------------------------------------------------
# UsageInfo
# ---------------------------------------------------------------------------


class TestUsageInfo:
    def test_defaults(self) -> None:
        usage = UsageInfo()
        assert usage.input_tokens is None
        assert usage.output_tokens is None
        assert usage.total_tokens is None
        assert usage.cost_usd is None

    def test_with_values(self) -> None:
        usage = UsageInfo(input_tokens=100, output_tokens=50, total_tokens=150, cost_usd=0.01)
        assert usage.input_tokens == 100
        assert usage.total_tokens == 150
        assert usage.cost_usd == 0.01


# ---------------------------------------------------------------------------
# PolicySummary
# ---------------------------------------------------------------------------


class TestPolicySummary:
    def test_defaults(self) -> None:
        ps = PolicySummary()
        assert ps.evaluated == 0
        assert ps.allowed == 0
        assert ps.blocked == 0
        assert ps.transformed == 0
        assert ps.reasons is None

    def test_with_values(self) -> None:
        ps = PolicySummary(evaluated=5, allowed=3, blocked=2, reasons=["PII detected"])
        assert ps.evaluated == 5
        assert ps.blocked == 2
        assert ps.reasons == ["PII detected"]


# ---------------------------------------------------------------------------
# RunWarning
# ---------------------------------------------------------------------------


class TestRunWarning:
    def test_basic(self) -> None:
        w = RunWarning(code="W001", message="Something is off")
        assert w.code == "W001"
        assert w.message == "Something is off"
        assert w.details is None

    def test_with_details(self) -> None:
        w = RunWarning(code="W002", message="Deprecated", details={"field": "name"})
        assert w.details == {"field": "name"}


# ---------------------------------------------------------------------------
# ResultEnvelope
# ---------------------------------------------------------------------------


class TestResultEnvelope:
    def test_minimal(self) -> None:
        env = ResultEnvelope(run_id="run_abc", output="hello")
        assert env.run_id == "run_abc"
        assert env.output == "hello"
        assert env.usage is None
        assert env.policy is None
        assert env.warnings is None

    def test_generic_type(self) -> None:
        env: ResultEnvelope[int] = ResultEnvelope(run_id="run_1", output=42)
        assert env.output == 42

    def test_full(self) -> None:
        env = ResultEnvelope(
            run_id="run_1",
            output="done",
            usage=UsageInfo(input_tokens=10),
            policy=PolicySummary(evaluated=1, allowed=1),
            warnings=[RunWarning(code="W001", message="warn")],
        )
        assert env.usage is not None
        assert env.usage.input_tokens == 10
        assert env.policy is not None
        assert env.policy.evaluated == 1
        assert env.warnings is not None
        assert len(env.warnings) == 1


# ---------------------------------------------------------------------------
# MiddlewareContext
# ---------------------------------------------------------------------------


class TestMiddlewareContext:
    def test_defaults(self) -> None:
        gov = GovernanceContext(
            org=OrgRef(id="org-1"),
            actor=ActorRef(type="human", id="u-1"),
            purpose="test",
            environment="dev",
        )
        mc = MiddlewareContext(run_id="run_1", context=gov)
        assert mc.run_id == "run_1"
        assert mc.context is gov
        assert mc.metadata == {}

    def test_metadata_factory(self) -> None:
        """Ensure default metadata dict is not shared between instances."""
        gov = GovernanceContext(
            org=OrgRef(id="org-1"),
            actor=ActorRef(type="human", id="u-1"),
            purpose="test",
            environment="dev",
        )
        mc1 = MiddlewareContext(run_id="run_1", context=gov)
        mc2 = MiddlewareContext(run_id="run_2", context=gov)
        mc1.metadata["key"] = "val"
        assert "key" not in mc2.metadata
