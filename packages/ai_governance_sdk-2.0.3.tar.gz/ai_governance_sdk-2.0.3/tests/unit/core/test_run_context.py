"""Tests for arelis.core.run_context."""

from __future__ import annotations

import re

import pytest

from arelis.core.run_context import (
    RunContext,
    create_middleware_context,
    default_context_resolver,
    generate_run_id,
)
from arelis.core.types import ActorRef, GovernanceContext, OrgRef, TeamRef


def _make_ctx(**overrides: object) -> GovernanceContext:
    defaults: dict[str, object] = {
        "org": OrgRef(id="org-1"),
        "actor": ActorRef(type="human", id="u-1"),
        "purpose": "testing",
        "environment": "dev",
    }
    defaults.update(overrides)
    return GovernanceContext(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# generate_run_id
# ---------------------------------------------------------------------------


class TestGenerateRunId:
    def test_prefix(self) -> None:
        rid = generate_run_id()
        assert rid.startswith("run_")

    def test_format(self) -> None:
        rid = generate_run_id()
        # run_ + 12 hex (timestamp) + 20 hex (random) = run_ + 32 hex
        assert re.fullmatch(r"run_[0-9a-f]{32}", rid), f"Unexpected format: {rid}"

    def test_uniqueness(self) -> None:
        ids = {generate_run_id() for _ in range(100)}
        assert len(ids) == 100


# ---------------------------------------------------------------------------
# default_context_resolver
# ---------------------------------------------------------------------------


class TestDefaultContextResolver:
    @pytest.mark.asyncio
    async def test_valid_context(self) -> None:
        ctx = _make_ctx()
        result = await default_context_resolver(ctx)
        assert result.org.id == "org-1"
        assert result.actor.id == "u-1"
        assert result.purpose == "testing"
        assert result.environment == "dev"
        # request_id should be auto-generated
        assert result.request_id is not None
        assert result.request_id.startswith("run_")

    @pytest.mark.asyncio
    async def test_preserves_optional_fields(self) -> None:
        ctx = _make_ctx(
            team=TeamRef(id="team-1"),
            session_id="sess-1",
            request_id="req-custom",
            tags={"k": "v"},
        )
        result = await default_context_resolver(ctx)
        assert result.team is not None
        assert result.team.id == "team-1"
        assert result.session_id == "sess-1"
        assert result.request_id == "req-custom"
        assert result.tags == {"k": "v"}

    @pytest.mark.asyncio
    async def test_none_raises(self) -> None:
        with pytest.raises(ValueError, match="GovernanceContext is required"):
            await default_context_resolver(None)

    @pytest.mark.asyncio
    async def test_missing_org_id_raises(self) -> None:
        ctx = _make_ctx(org=OrgRef(id=""))
        with pytest.raises(ValueError, match="org.id"):
            await default_context_resolver(ctx)

    @pytest.mark.asyncio
    async def test_missing_actor_raises(self) -> None:
        ctx = _make_ctx(actor=ActorRef(type="human", id=""))
        with pytest.raises(ValueError, match="actor"):
            await default_context_resolver(ctx)

    @pytest.mark.asyncio
    async def test_missing_purpose_raises(self) -> None:
        ctx = _make_ctx(purpose="")
        with pytest.raises(ValueError, match="purpose"):
            await default_context_resolver(ctx)

    @pytest.mark.asyncio
    async def test_missing_environment_raises(self) -> None:
        ctx = _make_ctx(environment="")
        with pytest.raises(ValueError, match="environment"):
            await default_context_resolver(ctx)


# ---------------------------------------------------------------------------
# create_middleware_context
# ---------------------------------------------------------------------------


class TestCreateMiddlewareContext:
    def test_with_explicit_run_id(self) -> None:
        ctx = _make_ctx()
        mc = create_middleware_context(ctx, run_id="run_custom")
        assert mc.run_id == "run_custom"
        assert mc.context is ctx
        assert mc.metadata == {}

    def test_auto_generated_run_id(self) -> None:
        ctx = _make_ctx()
        mc = create_middleware_context(ctx)
        assert mc.run_id.startswith("run_")


# ---------------------------------------------------------------------------
# RunContext
# ---------------------------------------------------------------------------


class TestRunContext:
    def test_auto_run_id(self) -> None:
        ctx = _make_ctx()
        rc = RunContext(ctx)
        assert rc.run_id.startswith("run_")
        assert rc.context is ctx
        assert rc.end_time is None

    def test_explicit_run_id(self) -> None:
        ctx = _make_ctx()
        rc = RunContext(ctx, run_id="run_xyz")
        assert rc.run_id == "run_xyz"

    def test_duration_before_end(self) -> None:
        ctx = _make_ctx()
        rc = RunContext(ctx)
        assert rc.get_duration_ms() is None

    def test_duration_after_end(self) -> None:
        ctx = _make_ctx()
        rc = RunContext(ctx)
        rc.end()
        duration = rc.get_duration_ms()
        assert duration is not None
        assert duration >= 0.0

    def test_metadata(self) -> None:
        ctx = _make_ctx()
        rc = RunContext(ctx)
        assert rc.get_metadata("missing") is None
        rc.set_metadata("key", "value")
        assert rc.get_metadata("key") == "value"

    def test_start_time_is_set(self) -> None:
        ctx = _make_ctx()
        rc = RunContext(ctx)
        assert rc.start_time is not None
