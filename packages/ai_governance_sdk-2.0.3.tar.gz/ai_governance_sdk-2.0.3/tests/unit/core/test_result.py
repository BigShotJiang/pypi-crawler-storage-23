"""Tests for arelis.core.result."""

from __future__ import annotations

import pytest

from arelis.core.result import (
    ResultBuilder,
    create_empty_policy_summary,
    create_result,
    create_result_builder,
    merge_policy_summaries,
)
from arelis.core.types import PolicySummary, RunWarning, UsageInfo

# ---------------------------------------------------------------------------
# ResultBuilder
# ---------------------------------------------------------------------------


class TestResultBuilder:
    def test_build_minimal(self) -> None:
        builder: ResultBuilder[str] = ResultBuilder("run_1")
        builder.set_output("hello")
        result = builder.build()
        assert result.run_id == "run_1"
        assert result.output == "hello"
        assert result.usage is None
        assert result.policy is None
        assert result.warnings is None

    def test_build_full(self) -> None:
        usage = UsageInfo(input_tokens=10, output_tokens=20)
        policy = PolicySummary(evaluated=1, allowed=1)
        w1 = RunWarning(code="W1", message="warn1")
        w2 = RunWarning(code="W2", message="warn2")

        builder: ResultBuilder[int] = ResultBuilder("run_2")
        result = (
            builder.set_output(42)
            .set_usage(usage)
            .set_policy(policy)
            .add_warning(w1)
            .add_warnings([w2])
            .build()
        )

        assert result.output == 42
        assert result.usage is usage
        assert result.policy is policy
        assert result.warnings is not None
        assert len(result.warnings) == 2
        assert result.warnings[0].code == "W1"
        assert result.warnings[1].code == "W2"

    def test_build_without_output_raises(self) -> None:
        builder: ResultBuilder[str] = ResultBuilder("run_1")
        with pytest.raises(ValueError, match="Output is required"):
            builder.build()

    def test_chaining(self) -> None:
        builder: ResultBuilder[str] = ResultBuilder("run_1")
        ret = builder.set_output("x")
        assert ret is builder

    def test_warnings_are_copied(self) -> None:
        """The built result's warnings list should be a copy."""
        builder: ResultBuilder[str] = ResultBuilder("run_1")
        builder.set_output("x")
        w = RunWarning(code="W", message="m")
        builder.add_warning(w)
        result = builder.build()
        # Mutating builder warnings afterward should not affect the result
        builder.add_warning(RunWarning(code="W2", message="m2"))
        assert result.warnings is not None
        assert len(result.warnings) == 1


# ---------------------------------------------------------------------------
# create_result_builder
# ---------------------------------------------------------------------------


class TestCreateResultBuilder:
    def test_factory(self) -> None:
        builder = create_result_builder("run_x")
        assert isinstance(builder, ResultBuilder)


# ---------------------------------------------------------------------------
# create_result
# ---------------------------------------------------------------------------


class TestCreateResult:
    def test_minimal(self) -> None:
        result = create_result("run_1", "output")
        assert result.run_id == "run_1"
        assert result.output == "output"
        assert result.usage is None
        assert result.policy is None
        assert result.warnings is None

    def test_full(self) -> None:
        usage = UsageInfo(input_tokens=5)
        policy = PolicySummary(evaluated=2, blocked=1)
        warnings = [RunWarning(code="W", message="m")]
        result = create_result(
            "run_2",
            100,
            usage=usage,
            policy=policy,
            warnings=warnings,
        )
        assert result.output == 100
        assert result.usage is usage
        assert result.policy is policy
        assert result.warnings is not None
        assert len(result.warnings) == 1

    def test_empty_warnings_not_set(self) -> None:
        result = create_result("run_1", "x", warnings=[])
        assert result.warnings is None


# ---------------------------------------------------------------------------
# create_empty_policy_summary
# ---------------------------------------------------------------------------


class TestCreateEmptyPolicySummary:
    def test_all_zero(self) -> None:
        ps = create_empty_policy_summary()
        assert ps.evaluated == 0
        assert ps.allowed == 0
        assert ps.blocked == 0
        assert ps.transformed == 0
        assert ps.reasons is None


# ---------------------------------------------------------------------------
# merge_policy_summaries
# ---------------------------------------------------------------------------


class TestMergePolicySummaries:
    def test_merge_two(self) -> None:
        a = PolicySummary(evaluated=3, allowed=2, blocked=1, reasons=["pii"])
        b = PolicySummary(evaluated=2, allowed=1, blocked=0, transformed=1, reasons=["toxicity"])
        merged = merge_policy_summaries(a, b)
        assert merged.evaluated == 5
        assert merged.allowed == 3
        assert merged.blocked == 1
        assert merged.transformed == 1
        assert merged.reasons == ["pii", "toxicity"]

    def test_merge_none_reasons(self) -> None:
        a = PolicySummary(evaluated=1)
        b = PolicySummary(evaluated=2)
        merged = merge_policy_summaries(a, b)
        assert merged.evaluated == 3
        assert merged.reasons is None

    def test_merge_empty(self) -> None:
        merged = merge_policy_summaries()
        assert merged.evaluated == 0
        assert merged.reasons is None

    def test_merge_single(self) -> None:
        a = PolicySummary(evaluated=5, allowed=5, reasons=["ok"])
        merged = merge_policy_summaries(a)
        assert merged.evaluated == 5
        assert merged.allowed == 5
        assert merged.reasons == ["ok"]
