"""Tests for arelis.core.errors."""

from __future__ import annotations

import pytest

from arelis.core.errors import (
    ArelisError,
    ArelisTimeoutError,
    EvaluationBlockedError,
    GovernanceGateDeniedError,
    PolicyApprovalRequiredError,
    PolicyBlockedError,
    ProviderError,
    ToolError,
    is_arelis_error,
    is_arelis_timeout_error,
    is_evaluation_blocked_error,
    is_governance_gate_denied_error,
    is_policy_approval_required_error,
    is_policy_blocked_error,
    is_provider_error,
    is_tool_error,
)
from arelis.core.types import ActorRef, GovernanceContext, OrgRef


def _make_ctx() -> GovernanceContext:
    return GovernanceContext(
        org=OrgRef(id="org-1", name="Acme"),
        actor=ActorRef(type="human", id="u-1"),
        purpose="testing",
        environment="dev",
    )


# ---------------------------------------------------------------------------
# ArelisError (base)
# ---------------------------------------------------------------------------


class TestArelisError:
    def test_basic_attributes(self) -> None:
        err = ArelisError(
            "something broke",
            run_id="run_1",
            code="GENERIC",
            error_type="generic.error",
        )
        assert str(err) == "something broke"
        assert err.run_id == "run_1"
        assert err.code == "GENERIC"
        assert err.error_type == "generic.error"
        assert err.context is None
        assert err.__cause__ is None

    def test_with_context_and_cause(self) -> None:
        ctx = _make_ctx()
        cause = RuntimeError("root cause")
        err = ArelisError(
            "fail",
            run_id="run_2",
            code="X",
            error_type="x.y",
            context=ctx,
            cause=cause,
        )
        assert err.context is ctx
        assert err.__cause__ is cause

    def test_is_exception(self) -> None:
        err = ArelisError("x", run_id="r", code="C", error_type="t")
        assert isinstance(err, Exception)

    def test_to_dict_without_context(self) -> None:
        err = ArelisError("msg", run_id="run_1", code="C", error_type="t")
        d = err.to_dict()
        assert d["name"] == "ArelisError"
        assert d["message"] == "msg"
        assert d["run_id"] == "run_1"
        assert d["code"] == "C"
        assert d["type"] == "t"
        assert "context" not in d

    def test_to_dict_with_context(self) -> None:
        ctx = _make_ctx()
        err = ArelisError("msg", run_id="run_1", code="C", error_type="t", context=ctx)
        d = err.to_dict()
        assert "context" in d
        ctx_dict = d["context"]
        assert isinstance(ctx_dict, dict)
        assert ctx_dict["org"]["id"] == "org-1"  # type: ignore[index]
        assert ctx_dict["actor"]["id"] == "u-1"  # type: ignore[index]
        assert ctx_dict["purpose"] == "testing"  # type: ignore[index]
        assert ctx_dict["environment"] == "dev"  # type: ignore[index]


# ---------------------------------------------------------------------------
# PolicyBlockedError
# ---------------------------------------------------------------------------


class TestPolicyBlockedError:
    def test_attributes(self) -> None:
        err = PolicyBlockedError(run_id="run_1", reason="PII detected")
        assert str(err) == "Policy blocked: PII detected"
        assert err.run_id == "run_1"
        assert err.code == "POLICY_BLOCKED"
        assert err.error_type == "policy.blocked"
        assert err.reason == "PII detected"
        assert err.policy_code is None

    def test_custom_policy_code(self) -> None:
        err = PolicyBlockedError(run_id="run_1", reason="x", policy_code="PII_001")
        assert err.code == "PII_001"
        assert err.policy_code == "PII_001"

    def test_is_subclass(self) -> None:
        err = PolicyBlockedError(run_id="run_1", reason="x")
        assert isinstance(err, ArelisError)


# ---------------------------------------------------------------------------
# PolicyApprovalRequiredError
# ---------------------------------------------------------------------------


class TestPolicyApprovalRequiredError:
    def test_attributes(self) -> None:
        err = PolicyApprovalRequiredError(
            run_id="run_1",
            reason="needs sign-off",
            approvers=["alice", "bob"],
            approval_id="appr_1",
        )
        assert str(err) == "Approval required: needs sign-off"
        assert err.code == "APPROVAL_REQUIRED"
        assert err.error_type == "policy.approval_required"
        assert err.reason == "needs sign-off"
        assert err.approvers == ["alice", "bob"]
        assert err.approval_id == "appr_1"

    def test_default_approvers(self) -> None:
        err = PolicyApprovalRequiredError(run_id="run_1", reason="x")
        assert err.approvers == []
        assert err.approval_id is None


# ---------------------------------------------------------------------------
# EvaluationBlockedError
# ---------------------------------------------------------------------------


class TestEvaluationBlockedError:
    def test_attributes(self) -> None:
        err = EvaluationBlockedError(
            run_id="run_1",
            evaluator_id="eval-1",
            reason="toxicity too high",
        )
        assert str(err) == "Evaluation blocked: toxicity too high"
        assert err.code == "EVALUATION_BLOCKED"
        assert err.error_type == "evaluation.blocked"
        assert err.evaluator_id == "eval-1"
        assert err.reason == "toxicity too high"


# ---------------------------------------------------------------------------
# ProviderError
# ---------------------------------------------------------------------------


class TestProviderError:
    def test_attributes(self) -> None:
        err = ProviderError(
            run_id="run_1",
            message="rate limited",
            provider="openai",
            retryable=True,
            status_code=429,
        )
        assert str(err) == "rate limited"
        assert err.code == "PROVIDER_ERROR"
        assert err.error_type == "provider.error"
        assert err.provider == "openai"
        assert err.retryable is True
        assert err.status_code == 429

    def test_defaults(self) -> None:
        err = ProviderError(run_id="run_1", message="fail", provider="vertex")
        assert err.retryable is False
        assert err.status_code is None


# ---------------------------------------------------------------------------
# ToolError
# ---------------------------------------------------------------------------


class TestToolError:
    def test_attributes(self) -> None:
        cause = ValueError("bad input")
        err = ToolError(
            run_id="run_1",
            message="invalid args",
            tool_name="calculator",
            cause=cause,
        )
        assert str(err) == 'Tool "calculator" failed: invalid args'
        assert err.code == "TOOL_ERROR"
        assert err.error_type == "tool.error"
        assert err.tool_name == "calculator"
        assert err.original_error is cause
        assert err.__cause__ is cause


# ---------------------------------------------------------------------------
# ArelisTimeoutError
# ---------------------------------------------------------------------------


class TestArelisTimeoutError:
    def test_attributes(self) -> None:
        err = ArelisTimeoutError(
            run_id="run_1",
            elapsed_ms=5000.0,
            limit_ms=3000.0,
            operation="model.generate",
        )
        assert "timed out after 5000.0ms (limit: 3000.0ms)" in str(err)
        assert "model.generate" in str(err)
        assert err.code == "TIMEOUT"
        assert err.error_type == "timeout"
        assert err.elapsed_ms == 5000.0
        assert err.limit_ms == 3000.0

    def test_default_operation(self) -> None:
        err = ArelisTimeoutError(run_id="run_1", elapsed_ms=100.0, limit_ms=50.0)
        assert str(err).startswith("Operation timed out")


# ---------------------------------------------------------------------------
# GovernanceGateDeniedError
# ---------------------------------------------------------------------------


class TestGovernanceGateDeniedError:
    def test_with_reasons(self) -> None:
        err = GovernanceGateDeniedError(
            run_id="run_1",
            reasons=["PII detected", "Unauthorized model"],
        )
        assert "PII detected; Unauthorized model" in str(err)
        assert err.code == "GOVERNANCE_GATE_DENIED"
        assert err.error_type == "governance_gate.denied"
        assert err.reasons == ["PII detected", "Unauthorized model"]

    def test_no_reasons(self) -> None:
        err = GovernanceGateDeniedError(run_id="run_1")
        assert "Policy denied" in str(err)
        assert err.reasons == []

    def test_empty_reasons(self) -> None:
        err = GovernanceGateDeniedError(run_id="run_1", reasons=[])
        assert "Policy denied" in str(err)
        assert err.reasons == []


# ---------------------------------------------------------------------------
# Guard functions
# ---------------------------------------------------------------------------


class TestGuardFunctions:
    def test_is_arelis_error(self) -> None:
        err = ArelisError("x", run_id="r", code="C", error_type="t")
        assert is_arelis_error(err) is True
        assert is_arelis_error(ValueError("x")) is False
        assert is_arelis_error("not an error") is False

    def test_is_arelis_error_on_subclass(self) -> None:
        err = PolicyBlockedError(run_id="r", reason="x")
        assert is_arelis_error(err) is True

    def test_is_policy_blocked_error(self) -> None:
        err = PolicyBlockedError(run_id="r", reason="x")
        assert is_policy_blocked_error(err) is True
        assert (
            is_policy_blocked_error(ArelisError("x", run_id="r", code="C", error_type="t")) is False
        )

    def test_is_policy_approval_required_error(self) -> None:
        err = PolicyApprovalRequiredError(run_id="r", reason="x")
        assert is_policy_approval_required_error(err) is True
        assert (
            is_policy_approval_required_error(PolicyBlockedError(run_id="r", reason="x")) is False
        )

    def test_is_evaluation_blocked_error(self) -> None:
        err = EvaluationBlockedError(run_id="r", evaluator_id="e", reason="x")
        assert is_evaluation_blocked_error(err) is True
        assert is_evaluation_blocked_error(ValueError()) is False

    def test_is_provider_error(self) -> None:
        err = ProviderError(run_id="r", message="x", provider="p")
        assert is_provider_error(err) is True
        assert is_provider_error(ToolError(run_id="r", message="x", tool_name="t")) is False

    def test_is_tool_error(self) -> None:
        err = ToolError(run_id="r", message="x", tool_name="t")
        assert is_tool_error(err) is True
        assert is_tool_error(ProviderError(run_id="r", message="x", provider="p")) is False

    def test_is_arelis_timeout_error(self) -> None:
        err = ArelisTimeoutError(run_id="r", elapsed_ms=1.0, limit_ms=0.5)
        assert is_arelis_timeout_error(err) is True
        assert is_arelis_timeout_error(ValueError()) is False

    def test_is_governance_gate_denied_error(self) -> None:
        err = GovernanceGateDeniedError(run_id="r")
        assert is_governance_gate_denied_error(err) is True
        assert is_governance_gate_denied_error(PolicyBlockedError(run_id="r", reason="x")) is False


# ---------------------------------------------------------------------------
# Catchability
# ---------------------------------------------------------------------------


class TestCatchability:
    def test_catch_as_exception(self) -> None:
        with pytest.raises(Exception, match="x"):
            raise ArelisError("x", run_id="r", code="C", error_type="t")

    def test_catch_subclass_as_base(self) -> None:
        with pytest.raises(ArelisError):
            raise PolicyBlockedError(run_id="r", reason="blocked")
