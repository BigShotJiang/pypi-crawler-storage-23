"""Tests for arelis.quotas.in_memory."""

from __future__ import annotations

import pytest

from arelis.quotas.in_memory import InMemoryQuotaManager, create_in_memory_quota_manager
from arelis.quotas.types import (
    QuotaDecisionAllow,
    QuotaDecisionBlock,
    QuotaDecisionLimit,
    QuotaKey,
    QuotaUsage,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_key(**kwargs: object) -> QuotaKey:
    defaults: dict[str, object] = {
        "org_id": "org-1",
        "purpose": "testing",
        "environment": "dev",
    }
    defaults.update(kwargs)
    return QuotaKey(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# InMemoryQuotaManager.check
# ---------------------------------------------------------------------------


class TestInMemoryQuotaManagerCheck:
    @pytest.mark.asyncio
    async def test_allow_when_no_limits(self) -> None:
        mgr = InMemoryQuotaManager()
        decision = await mgr.check(_make_key(), QuotaUsage(tokens_in=100))
        assert isinstance(decision, QuotaDecisionAllow)
        assert decision.effect == "allow"

    @pytest.mark.asyncio
    async def test_allow_within_limits(self) -> None:
        mgr = InMemoryQuotaManager(limits=QuotaUsage(tokens_in=1000))
        decision = await mgr.check(_make_key(), QuotaUsage(tokens_in=500))
        assert isinstance(decision, QuotaDecisionAllow)

    @pytest.mark.asyncio
    async def test_block_when_exhausted(self) -> None:
        mgr = InMemoryQuotaManager(limits=QuotaUsage(tokens_in=100))
        key = _make_key()
        await mgr.commit(key, QuotaUsage(tokens_in=100))
        decision = await mgr.check(key, QuotaUsage(tokens_in=1))
        assert isinstance(decision, QuotaDecisionBlock)
        assert decision.effect == "block"
        assert "tokens_in" in decision.reason

    @pytest.mark.asyncio
    async def test_limit_when_proposed_exceeds_remaining(self) -> None:
        mgr = InMemoryQuotaManager(limits=QuotaUsage(tokens_in=100))
        key = _make_key()
        await mgr.commit(key, QuotaUsage(tokens_in=80))
        decision = await mgr.check(key, QuotaUsage(tokens_in=50))
        assert isinstance(decision, QuotaDecisionLimit)
        assert decision.effect == "limit"
        assert decision.applied.tokens_in == 20  # remaining

    @pytest.mark.asyncio
    async def test_multiple_fields(self) -> None:
        mgr = InMemoryQuotaManager(limits=QuotaUsage(tokens_in=1000, tokens_out=500))
        decision = await mgr.check(_make_key(), QuotaUsage(tokens_in=100, tokens_out=100))
        assert isinstance(decision, QuotaDecisionAllow)


# ---------------------------------------------------------------------------
# InMemoryQuotaManager.commit
# ---------------------------------------------------------------------------


class TestInMemoryQuotaManagerCommit:
    @pytest.mark.asyncio
    async def test_commit_accumulates(self) -> None:
        mgr = InMemoryQuotaManager(limits=QuotaUsage(tokens_in=1000))
        key = _make_key()
        await mgr.commit(key, QuotaUsage(tokens_in=100))
        await mgr.commit(key, QuotaUsage(tokens_in=200))
        usage = mgr.get_usage(key)
        assert usage.tokens_in == 300

    @pytest.mark.asyncio
    async def test_commit_independent_keys(self) -> None:
        mgr = InMemoryQuotaManager()
        k1 = _make_key(actor_id="alice")
        k2 = _make_key(actor_id="bob")
        await mgr.commit(k1, QuotaUsage(tokens_in=100))
        await mgr.commit(k2, QuotaUsage(tokens_in=200))
        assert mgr.get_usage(k1).tokens_in == 100
        assert mgr.get_usage(k2).tokens_in == 200


# ---------------------------------------------------------------------------
# get_usage
# ---------------------------------------------------------------------------


class TestGetUsage:
    def test_returns_empty_for_unknown_key(self) -> None:
        mgr = InMemoryQuotaManager()
        usage = mgr.get_usage(_make_key())
        assert usage.tokens_in is None
        assert usage.tokens_out is None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestCreateInMemoryQuotaManager:
    def test_returns_instance(self) -> None:
        mgr = create_in_memory_quota_manager()
        assert isinstance(mgr, InMemoryQuotaManager)

    def test_with_limits(self) -> None:
        mgr = create_in_memory_quota_manager(limits=QuotaUsage(tokens_in=500))
        assert isinstance(mgr, InMemoryQuotaManager)
