import pytest

from arelis import (
    AuditEventInput,
    GetPiiConfigOptions,
    ManagedPiiConfig,
    ManagedPiiPatternDefinition,
    MCPGovernedInvokeInput,
    MCPGovernedInvokeResult,
    PlatformApprovalResolveInput,
    PlatformComplianceProofRequest,
    PlatformComplianceVerificationInput,
    RuntimeRiskInput,
    createArelisPlatform,
)
from arelis.platform.types import ArelisPlatformConfig


def test_platform_type_exports_are_available() -> None:
    config: ArelisPlatformConfig = {
        "baseUrl": "https://api.arelis.digital",
        "apiKey": "ak_test",
    }

    event: AuditEventInput = {
        "runId": "run_1",
        "eventType": "model.invoked",
        "actor": {"type": "service", "id": "svc_1"},
        "resource": {"type": "model", "id": "model_1"},
        "action": "invoke",
        "timestamp": "2026-01-01T00:00:00Z",
    }

    verify: PlatformComplianceVerificationInput = {"proofId": "proof_1"}
    proof_alias: PlatformComplianceProofRequest = {"runId": "run_2", "schemaVersion": "v1"}
    approval_alias: PlatformApprovalResolveInput = {"status": "approved"}
    governed_input: MCPGovernedInvokeInput = {"invoke": lambda: {"ok": True}}
    governed_output: MCPGovernedInvokeResult = {"invoked": True}
    pii_opts: GetPiiConfigOptions = {"namespace": "pii.default"}
    pii_pattern: ManagedPiiPatternDefinition = {"name": "ssn", "pattern": r"\d+"}
    pii_config: ManagedPiiConfig = {"customPatterns": [pii_pattern]}
    risk: RuntimeRiskInput = {
        "runId": "run_3",
        "policyDecisions": [],
        "quotaState": {},
        "evaluationSignals": [],
    }

    assert bool(
        config
        and event
        and verify
        and proof_alias
        and approval_alias
        and governed_input
        and governed_output
        and pii_opts
        and pii_pattern
        and pii_config
        and risk
    )


def test_create_arelis_platform_camel_alias_warns() -> None:
    with pytest.deprecated_call():
        createArelisPlatform(
            {
                "baseUrl": "https://api.arelis.digital",
                "apiKey": "ak_test",
            }
        )
