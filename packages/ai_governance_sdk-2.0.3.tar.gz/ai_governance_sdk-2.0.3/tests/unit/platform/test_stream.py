from typing import Any

import pytest

from arelis.platform.platform_client import ArelisPlatform


class _CaptureConnection:
    captured: dict[str, Any] = {}

    def __init__(self, **kwargs: Any) -> None:
        _CaptureConnection.captured = kwargs

    def close(self) -> None:
        return


def test_stream_requires_callback() -> None:
    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test"})

    with pytest.raises(ValueError, match="onEvent"):
        platform.stream({})


def test_stream_builds_expected_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("arelis.platform.platform_client.EventStreamConnection", _CaptureConnection)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital/", "apiKey": "ak_test"})

    platform.stream({"onEvent": lambda _type, _data: None, "eventTypes": ["event:created"]})

    assert (
        _CaptureConnection.captured["url"]
        == "https://api.arelis.digital/api/v1/stream?token=ak_test"
    )
    assert _CaptureConnection.captured["event_types"] == ["event:created"]
