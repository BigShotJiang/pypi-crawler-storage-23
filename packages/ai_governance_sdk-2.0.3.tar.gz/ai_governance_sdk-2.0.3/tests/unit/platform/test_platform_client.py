# ruff: noqa: E501
from __future__ import annotations

import asyncio
import re
from typing import Any

import httpx
import pytest

from arelis.platform import ArelisApiError, ArelisPlatform


def _json_response(
    payload: dict[str, Any], *, status: int = 200, headers: dict[str, str] | None = None
) -> httpx.Response:
    merged_headers = {"Content-Type": "application/json"}
    if headers:
        merged_headers.update(headers)
    return httpx.Response(status, json=payload, headers=merged_headers)


def test_representative_method_group_endpoint_mapping(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    def fake_request(**kwargs: Any) -> httpx.Response:
        calls.append(kwargs)
        return _json_response({"ok": True})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital/", "apiKey": "ak_test"})

    platform.events.count()
    platform.proofs.get("proof_1")
    platform.risk.getConfig()
    platform.replay.get("replay_1")
    platform.graphs.get("run_1")
    platform.governance.evaluatePolicy({"runId": "run_1"})
    platform.apiKeys.list()
    platform.usage.history()
    platform.jobs.get("job_1")
    platform.organization.get()
    platform.quotas.get()
    platform.billing.summary()
    platform.metering.getMilestones()
    platform.telemetry.listReports()
    platform.exports.get("exp_1")
    platform.namespaces.agents.list()
    platform.approvals.getConfig()
    platform.aiSystems.list()
    platform.mcpServers.list()

    assert [call["url"] for call in calls] == [
        "https://api.arelis.digital/api/v1/events/count",
        "https://api.arelis.digital/api/v1/proofs/proof_1",
        "https://api.arelis.digital/api/v1/risk/config",
        "https://api.arelis.digital/api/v1/replay/replay_1",
        "https://api.arelis.digital/api/v1/graphs/run_1",
        "https://api.arelis.digital/api/v1/governance/policy/evaluate",
        "https://api.arelis.digital/api/v1/api-keys",
        "https://api.arelis.digital/api/v1/usage/history",
        "https://api.arelis.digital/api/v1/jobs/job_1",
        "https://api.arelis.digital/api/v1/organization",
        "https://api.arelis.digital/api/v1/quotas",
        "https://api.arelis.digital/api/v1/billing/summary",
        "https://api.arelis.digital/api/v1/metering/milestones",
        "https://api.arelis.digital/api/v1/telemetry/reports",
        "https://api.arelis.digital/api/v1/exports/exp_1",
        "https://api.arelis.digital/api/v1/namespaces/agents",
        "https://api.arelis.digital/api/v1/namespaces/approvals",
        "https://api.arelis.digital/api/v1/ai-systems",
        "https://api.arelis.digital/api/v1/mcp-servers",
    ]


def test_auth_headers_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    def fake_request(**kwargs: Any) -> httpx.Response:
        calls.append(kwargs)
        return _json_response({"eventId": "evt_1", "runId": "run_1"})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital/", "apiKey": "ak_test"})
    platform.events.create({"runId": "run_1"})

    headers = calls[0]["headers"]
    assert headers["x-api-key"] == "ak_test"
    assert "Authorization" not in headers


def test_auth_headers_bearer_token(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    def fake_request(**kwargs: Any) -> httpx.Response:
        calls.append(kwargs)
        return _json_response({"data": []})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital", "token": "token_123"})
    platform.jobs.list()

    headers = calls[0]["headers"]
    assert headers["Authorization"] == "Bearer token_123"
    assert "x-api-key" not in headers


def test_query_string_bool_values_use_lowercase(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    def fake_request(**kwargs: Any) -> httpx.Response:
        calls.append(kwargs)
        return _json_response({"data": []})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test"})
    platform.telemetry.listReports({"status": "pending", "includeExpired": True})

    assert calls[0]["url"].endswith("status=pending&includeExpired=true")


def test_timeout_is_applied(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    def fake_request(**kwargs: Any) -> httpx.Response:
        calls.append(kwargs)
        return _json_response({"data": []})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform(
        {"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test", "timeout": 5000}
    )
    platform.jobs.list()

    assert calls[0]["timeout"] == 5.0


def test_retryable_http_status_retries(monkeypatch: pytest.MonkeyPatch) -> None:
    responses = [
        _json_response(
            {
                "type": "https://arelis.dev/errors/retryable",
                "title": "Retryable",
                "status": 503,
                "detail": "Temporary outage",
            },
            status=503,
            headers={"Retry-After": "0"},
        ),
        _json_response({"data": {"id": "org_1"}}),
    ]

    def fake_request(**_: Any) -> httpx.Response:
        return responses.pop(0)

    monkeypatch.setattr(httpx, "request", fake_request)
    monkeypatch.setattr("arelis.platform.platform_client.time.sleep", lambda _: None)

    platform = ArelisPlatform(
        {"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test", "maxRetries": 1}
    )
    platform.organization.get()

    assert len(responses) == 0


def test_retryable_network_error_retries(monkeypatch: pytest.MonkeyPatch) -> None:
    calls = {"count": 0}

    def fake_request(**_: Any) -> httpx.Response:
        calls["count"] += 1
        if calls["count"] == 1:
            raise httpx.ReadTimeout("timeout")
        return _json_response({"data": []})

    monkeypatch.setattr(httpx, "request", fake_request)
    monkeypatch.setattr("arelis.platform.platform_client.time.sleep", lambda _: None)

    platform = ArelisPlatform(
        {"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test", "maxRetries": 1}
    )
    platform.jobs.list()

    assert calls["count"] == 2


def test_non_retryable_4xx_raises_without_retry(monkeypatch: pytest.MonkeyPatch) -> None:
    calls = {"count": 0}

    def fake_request(**_: Any) -> httpx.Response:
        calls["count"] += 1
        return _json_response(
            {
                "type": "https://arelis.dev/errors/forbidden",
                "title": "Forbidden",
                "status": 403,
                "detail": "Policy denied",
                "instance": "/api/v1/proofs/verify",
            },
            status=403,
        )

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform(
        {"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test", "maxRetries": 2}
    )

    with pytest.raises(ArelisApiError):
        platform.proofs.verify({"proofId": "proof_1"})

    assert calls["count"] == 1


def test_rfc7807_errors_map_to_arelis_api_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**_: Any) -> httpx.Response:
        return _json_response(
            {
                "type": "https://arelis.dev/errors/forbidden",
                "title": "Forbidden",
                "status": 403,
                "detail": "Policy denied",
                "instance": "/api/v1/proofs/verify",
            },
            status=403,
        )

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test"})

    with pytest.raises(ArelisApiError) as exc:
        platform.proofs.verify({"proofId": "proof_1"})

    assert exc.value.type == "https://arelis.dev/errors/forbidden"
    assert exc.value.title == "Forbidden"
    assert exc.value.status == 403
    assert exc.value.detail == "Policy denied"
    assert exc.value.instance == "/api/v1/proofs/verify"


def test_export_download_shape(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**_: Any) -> httpx.Response:
        return httpx.Response(
            200,
            text="csv,data",
            headers={
                "Content-Type": "text/csv",
                "Content-Disposition": 'attachment; filename="usage.csv"',
            },
        )

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test"})
    artifact = platform.exports.download("exp_1")

    assert artifact["file_name"] == "usage.csv"
    assert artifact["mime_type"] == "text/csv"
    assert artifact["content"] == "csv,data"


def test_governed_invoke_awaits_async_callable(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**_: Any) -> httpx.Response:
        return _json_response(
            {
                "runId": "run_123",
                "decision": "allow",
                "policy": {"summary": {}},
            }
        )

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"baseUrl": "https://api.arelis.digital", "apiKey": "ak_test"})

    async def invoke() -> dict[str, Any]:
        return {"ok": True}

    result = asyncio.run(
        platform.namespaces.mcp.governedInvoke(
            {
                "runId": "run_123",
                "serverId": "srv_1",
                "toolName": "t_1",
                "toolArgs": {},
                "invoke": invoke,
            }
        )
    )

    assert result["invoked"] is True
    assert result["result"] == {"ok": True}


def test_default_base_url_when_not_provided(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    def fake_request(**kwargs: Any) -> httpx.Response:
        calls.append(kwargs)
        return _json_response({"data": []})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"apiKey": "ak_test"})
    platform.jobs.list()

    assert calls[0]["url"] == "https://api.arelis.digital/api/v1/jobs"


def test_get_pii_config_from_namespace_records(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**kwargs: Any) -> httpx.Response:
        if kwargs["url"].endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response(
                {
                    "data": [
                        {
                            "id": "cfg_1",
                            "namespace": "pii.default",
                            "data": {
                                "detectEmails": True,
                                "detectPhones": False,
                                "customPatterns": [
                                    {
                                        "name": "ssn",
                                        "pattern": r"\\b\\d{3}-\\d{2}-\\d{4}\\b",
                                        "flags": "g",
                                        "type": "custom",
                                    }
                                ],
                            },
                        }
                    ],
                    "nextCursor": None,
                }
            )
        return _json_response({})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"apiKey": "ak_test"})
    config = platform.governance.getPiiConfig()

    assert config.detect_emails is True
    assert config.detect_phones is False
    assert config.custom_patterns is not None
    assert config.custom_patterns[0].name == "ssn"
    assert isinstance(config.custom_patterns[0].pattern, re.Pattern)


def test_get_pii_config_nested_pii_config_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**kwargs: Any) -> httpx.Response:
        if kwargs["url"].endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response(
                {
                    "data": [
                        {
                            "id": "cfg_2",
                            "namespace": "pii.default",
                            "data": {
                                "piiConfig": {
                                    "detectApiKeys": False,
                                    "secretPatterns": [
                                        {
                                            "name": "tenant-token",
                                            "pattern": "tenant_[A-Z0-9]{10}",
                                            "flags": "gi",
                                            "type": "custom",
                                            "replacement": "[TENANT]",
                                        }
                                    ],
                                }
                            },
                        }
                    ]
                }
            )
        return _json_response({})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"apiKey": "ak_test"})
    config = platform.governance.getPiiConfig()

    assert config.detect_api_keys is False
    assert config.secret_patterns is not None
    assert config.secret_patterns[0].replacement == "[TENANT]"


def test_get_pii_config_singleton_config_object(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**kwargs: Any) -> httpx.Response:
        if kwargs["url"].endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response(
                {
                    "data": {
                        "status": "active",
                        "piiConfig": {
                            "detectEmails": True,
                            "detectPhones": True,
                            "customPatterns": [
                                {
                                    "name": "tax-id",
                                    "pattern": r"\\b\\d{2}-\\d{7}\\b",
                                    "flags": "g",
                                    "type": "custom",
                                }
                            ],
                        },
                    }
                }
            )
        return _json_response({})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"apiKey": "ak_test"})
    config = platform.governance.getPiiConfig()

    assert config.detect_emails is True
    assert config.detect_phones is True
    assert config.custom_patterns is not None
    assert config.custom_patterns[0].name == "tax-id"


def test_get_pii_config_singleton_namespace_record(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**kwargs: Any) -> httpx.Response:
        if kwargs["url"].endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response(
                {
                    "data": {
                        "id": "cfg_single",
                        "namespace": "pii.default",
                        "data": {
                            "detectApiKeys": False,
                            "defaultReplacement": "[MASKED]",
                        },
                    }
                }
            )
        return _json_response({})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"apiKey": "ak_test"})
    config = platform.governance.getPiiConfig()

    assert config.detect_api_keys is False
    assert config.default_replacement == "[MASKED]"


def test_get_pii_config_skips_invalid_regex_patterns(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**kwargs: Any) -> httpx.Response:
        if kwargs["url"].endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response(
                {
                    "data": [
                        {
                            "namespace": "pii.default",
                            "data": {
                                "customPatterns": [
                                    {
                                        "name": "invalid",
                                        "pattern": "[unterminated",
                                        "flags": "g",
                                    },
                                    {
                                        "name": "valid",
                                        "pattern": r"user_[0-9]{4}",
                                        "flags": "g",
                                    },
                                ]
                            },
                        }
                    ]
                }
            )
        return _json_response({})

    monkeypatch.setattr(httpx, "request", fake_request)

    platform = ArelisPlatform({"apiKey": "ak_test"})
    config = platform.governance.getPiiConfig()

    assert config.custom_patterns is not None
    assert len(config.custom_patterns) == 1
    assert config.custom_patterns[0].name == "valid"
