from __future__ import annotations

from arelis.audit.event_builder import (
    create_agent_step_event,
    create_model_request_event,
    create_run_started_event,
    create_tool_call_event,
)
from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.platform.event_bridge import audit_event_to_platform_event, create_platform_event


def _context() -> GovernanceContext:
    return GovernanceContext(
        org=OrgRef(id="org-1"),
        actor=ActorRef(type="service", id="svc-1"),
        purpose="testing",
        environment="dev",
    )


def test_create_platform_event_defaults() -> None:
    event = create_platform_event(
        {
            "runId": "run-1",
            "eventType": "model.request",
        }
    )

    assert event["runId"] == "run-1"
    assert event["eventType"] == "model.request"
    assert event["action"] == "request"
    assert event["resource"] == {"type": "run", "id": "run-1"}


def test_audit_event_to_platform_event_model_mapping() -> None:
    event = create_model_request_event(
        run_id="run-model",
        context=_context(),
        model_id="gpt-test",
    )

    payload = audit_event_to_platform_event(event)

    assert payload["eventType"] == "model.request"
    assert payload["resource"] == {"type": "model", "id": "gpt-test"}
    assert payload["action"] == "request"


def test_audit_event_to_platform_event_tool_mapping() -> None:
    event = create_tool_call_event(
        run_id="run-tool",
        context=_context(),
        tool_name="lookup_order",
    )

    payload = audit_event_to_platform_event(event)

    assert payload["eventType"] == "tool.call"
    assert payload["resource"] == {"type": "tool", "id": "lookup_order"}
    assert payload["action"] == "call"


def test_audit_event_to_platform_event_agent_step_mapping() -> None:
    event = create_agent_step_event(
        run_id="run-agent",
        context=_context(),
        step_number=2,
        step_type="execute",
    )

    payload = audit_event_to_platform_event(event)

    assert payload["eventType"] == "agent.step"
    assert payload["resource"] == {"type": "agent_step", "id": "execute-2"}
    assert payload["action"] == "execute"


def test_audit_event_to_platform_event_default_mapping() -> None:
    event = create_run_started_event(
        run_id="run-start",
        context=_context(),
        operation="agents.run",
    )

    payload = audit_event_to_platform_event(event)

    assert payload["eventType"] == "run.started"
    assert payload["resource"] == {"type": "run", "id": "run-start"}
    assert payload["action"] == "started"
