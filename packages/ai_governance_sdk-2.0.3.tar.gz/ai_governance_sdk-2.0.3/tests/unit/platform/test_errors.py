from arelis.platform.errors import ArelisApiError


def test_arelis_api_error_fields() -> None:
    err = ArelisApiError(
        type="https://arelis.dev/errors/forbidden",
        title="Forbidden",
        status=403,
        detail="Policy denied",
        instance="/api/v1/proofs/verify",
    )

    assert err.type == "https://arelis.dev/errors/forbidden"
    assert err.title == "Forbidden"
    assert err.status == 403
    assert err.detail == "Policy denied"
    assert err.instance == "/api/v1/proofs/verify"
    assert str(err) == "Policy denied"
