import asyncio
import dataclasses
from unittest.mock import AsyncMock, MagicMock

import pytest

from arelis.agents.memory import InMemoryAgentMemory
from arelis.agents.runtime import AgentRuntime, AgentRuntimeOptions
from arelis.agents.types import (
    AgentConfig,
    AgentHandlers,
    AgentLimits,
    AgentRunInput,
    StepExecution,
    StepObservation,
    StepPlan,
)
from arelis.core.types import ActorRef, GovernanceContext, OrgRef


@pytest.fixture
def agent_config():
    return AgentConfig(
        agent_id="agent-001",
        name="Test Agent",
        system_prompt="You are a test agent.",
        limits=AgentLimits(max_steps=5, max_time_ms=1000),
        context=GovernanceContext(
            org=OrgRef(id="org-1"),
            actor=ActorRef(type="user", id="user-1"),
            purpose="test",
            environment="test",
        ),
    )


@pytest.fixture
def mock_handlers():
    async def plan(input_data, step):
        if input_data == "DONE":
            # Plan to use the echo tool with "DONE" msg, which observe will recognize as complete
            return StepPlan(
                action="finish",
                reasoning="Task complete",
                tool_name="echo",
                tool_input={"msg": "DONE"},
            )
        return StepPlan(
            action="continue",
            reasoning="Working...",
            tool_name="echo",
            tool_input={"msg": input_data},
        )

    async def execute(plan, step):
        return StepExecution(tool_output=f"Executed: {plan.action}")

    async def execute_tool(plan, step, ctx):
        return StepExecution(
            tool_name=plan.tool_name, tool_output=f"Echo: {plan.tool_input['msg']}"
        )

    async def observe(execution, step):
        if execution.tool_output == "Echo: DONE":
            return StepObservation(result="Success", is_complete=True)
        return StepObservation(result=execution.tool_output, is_complete=False)

    return AgentHandlers(plan=plan, execute=execute, observe=observe, execute_tool=execute_tool)


@pytest.mark.asyncio
async def test_agent_run_success(agent_config, mock_handlers):
    runtime = AgentRuntime(AgentRuntimeOptions(config=agent_config, handlers=mock_handlers))

    # Run with input that requires 1 step to finish (echo "DONE" -> observe completion)
    result = await runtime.run(AgentRunInput(input="DONE"))

    assert result.status == "completed"
    assert result.output == "Success"
    assert len(result.steps) == 1
    assert result.steps[0].phase == "observe"
    assert result.steps[0].plan.tool_name == "echo"


@pytest.mark.asyncio
async def test_max_steps_reached(agent_config, mock_handlers):
    # Reduce max steps to 1
    config = dataclasses.replace(agent_config, limits=AgentLimits(max_steps=1, max_time_ms=1000))
    runtime = AgentRuntime(AgentRuntimeOptions(config=config, handlers=mock_handlers))

    # Input "loop" will cause it to continue, but step limit 1 will stop it
    result = await runtime.run(AgentRunInput(input="loop"))

    assert result.status == "max_steps_reached"
    assert "Maximum steps limit reached" in (result.error or "")
    assert len(result.steps) == 1


@pytest.mark.asyncio
async def test_timeout(agent_config):
    # Slow handler
    async def slow_plan(input_data, step):
        await asyncio.sleep(0.2)
        return StepPlan(action="sleep", reasoning="sleeping")

    handlers = AgentHandlers(
        plan=slow_plan,
        execute=AsyncMock(return_value=StepExecution()),
        observe=AsyncMock(return_value=StepObservation(result=None, is_complete=False)),
    )

    # Set timeout to 100ms
    config = dataclasses.replace(agent_config, limits=AgentLimits(max_steps=5, max_time_ms=100))
    runtime = AgentRuntime(AgentRuntimeOptions(config=config, handlers=handlers))

    result = await runtime.run(AgentRunInput(input="start"))

    assert result.status == "timeout"
    assert result.error is not None


@pytest.mark.asyncio
async def test_memory_storage(agent_config, mock_handlers):
    memory = InMemoryAgentMemory()
    runtime = AgentRuntime(
        AgentRuntimeOptions(config=agent_config, handlers=mock_handlers, memory=memory)
    )

    await runtime.run(AgentRunInput(input="DONE"))

    # Check if steps were stored
    # We can't easily check internal memory state of InMemoryAgentMemory without its methods
    # But we can verify no error occurred and the workflow completed.
    # To really check, we could mock the memory.

    mock_mem = MagicMock(spec=InMemoryAgentMemory)
    # Behave like a nice async mock
    mock_mem.clear = AsyncMock()
    mock_mem.retrieve = AsyncMock(return_value=[])
    mock_mem.store_step = AsyncMock()

    runtime_mock_mem = AgentRuntime(
        AgentRuntimeOptions(config=agent_config, handlers=mock_handlers, memory=mock_mem)
    )

    await runtime_mock_mem.run(AgentRunInput(input="DONE"))

    assert mock_mem.store_step.called
    assert mock_mem.store_step.call_count == 1
