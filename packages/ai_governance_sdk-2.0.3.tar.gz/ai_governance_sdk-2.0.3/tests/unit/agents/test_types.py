"""Tests for arelis.agents.types."""

from __future__ import annotations

from datetime import datetime, timezone

from arelis.agents.types import (
    AgentConfig,
    AgentHandlers,
    AgentLimits,
    AgentResult,
    AgentRunInput,
    AgentStep,
    AgentStepAttestation,
    StepExecution,
    StepObservation,
    StepPlan,
)
from arelis.core.types import ActorRef, GovernanceContext, OrgRef

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOW = datetime.now(timezone.utc)


def _gov_ctx() -> GovernanceContext:
    return GovernanceContext(
        org=OrgRef(id="org-1"),
        actor=ActorRef(type="human", id="a-1"),
        purpose="testing",
        environment="dev",
    )


# ---------------------------------------------------------------------------
# AgentLimits
# ---------------------------------------------------------------------------


class TestAgentLimits:
    def test_defaults(self) -> None:
        limits = AgentLimits()
        assert limits.max_steps == 10
        assert limits.max_time_ms == 30_000

    def test_custom(self) -> None:
        limits = AgentLimits(max_steps=50, max_time_ms=120_000)
        assert limits.max_steps == 50
        assert limits.max_time_ms == 120_000


# ---------------------------------------------------------------------------
# AgentStepAttestation
# ---------------------------------------------------------------------------


class TestAgentStepAttestation:
    def test_construction(self) -> None:
        att = AgentStepAttestation(
            step_number=1,
            phase="plan",
            attestation_hash="abc123",
            created_at=_NOW,
        )
        assert att.step_number == 1
        assert att.phase == "plan"
        assert att.attestation_hash == "abc123"
        assert att.parent_attestation_hash is None
        assert att.policy_snapshot_hash is None

    def test_with_parent(self) -> None:
        att = AgentStepAttestation(
            step_number=2,
            phase="execute",
            attestation_hash="def456",
            created_at=_NOW,
            parent_attestation_hash="abc123",
            policy_snapshot_hash="pol_hash",
        )
        assert att.parent_attestation_hash == "abc123"
        assert att.policy_snapshot_hash == "pol_hash"


# ---------------------------------------------------------------------------
# StepPlan / StepExecution / StepObservation
# ---------------------------------------------------------------------------


class TestStepPlan:
    def test_minimal(self) -> None:
        plan = StepPlan(action="think", reasoning="need more info")
        assert plan.action == "think"
        assert plan.reasoning == "need more info"
        assert plan.tool_name is None
        assert plan.tool_input is None

    def test_with_tool(self) -> None:
        plan = StepPlan(
            action="call tool",
            reasoning="need data",
            tool_name="lookup",
            tool_input={"q": "test"},
        )
        assert plan.tool_name == "lookup"
        assert plan.tool_input == {"q": "test"}


class TestStepExecution:
    def test_defaults(self) -> None:
        exe = StepExecution()
        assert exe.tool_name is None
        assert exe.tool_input is None
        assert exe.tool_output is None
        assert exe.child_run_id is None
        assert exe.parent_run_id is None
        assert exe.governance_context is None
        assert exe.error is None

    def test_with_tool_result(self) -> None:
        exe = StepExecution(
            tool_name="lookup",
            tool_input={"q": "test"},
            tool_output={"result": "found"},
            parent_run_id="run_001",
        )
        assert exe.tool_name == "lookup"
        assert exe.tool_output == {"result": "found"}

    def test_with_error(self) -> None:
        exe = StepExecution(error="Tool not found")
        assert exe.error == "Tool not found"


class TestStepObservation:
    def test_incomplete(self) -> None:
        obs = StepObservation(result="partial data", is_complete=False, next_action="retry")
        assert obs.is_complete is False
        assert obs.next_action == "retry"

    def test_complete(self) -> None:
        obs = StepObservation(result="done", is_complete=True)
        assert obs.is_complete is True
        assert obs.next_action is None


# ---------------------------------------------------------------------------
# AgentStep
# ---------------------------------------------------------------------------


class TestAgentStep:
    def test_construction(self) -> None:
        step = AgentStep(
            step_number=1,
            phase="plan",
            input="What is the weather?",
            started_at=_NOW,
        )
        assert step.step_number == 1
        assert step.phase == "plan"
        assert step.input == "What is the weather?"
        assert step.plan is None
        assert step.execution is None
        assert step.observation is None
        assert step.ended_at is None
        assert step.duration_ms is None
        assert step.attestations is None

    def test_full_step(self) -> None:
        plan = StepPlan(action="call tool", reasoning="need data", tool_name="weather")
        exe = StepExecution(tool_name="weather", tool_output={"temp": 72})
        obs = StepObservation(result="Temperature is 72F", is_complete=True)
        att = AgentStepAttestation(
            step_number=1, phase="plan", attestation_hash="hash1", created_at=_NOW
        )

        step = AgentStep(
            step_number=1,
            phase="observe",
            input="What is the weather?",
            started_at=_NOW,
            plan=plan,
            execution=exe,
            observation=obs,
            ended_at=_NOW,
            duration_ms=150.5,
            attestations=[att],
        )
        assert step.plan is not None
        assert step.execution is not None
        assert step.observation is not None
        assert step.duration_ms == 150.5
        assert len(step.attestations) == 1  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# AgentConfig
# ---------------------------------------------------------------------------


class TestAgentConfig:
    def test_minimal(self) -> None:
        config = AgentConfig(
            agent_id="agent-1",
            name="Test Agent",
            system_prompt="You are a helpful assistant.",
            limits=AgentLimits(),
            context=_gov_ctx(),
        )
        assert config.agent_id == "agent-1"
        assert config.name == "Test Agent"
        assert config.description is None
        assert config.tools is None
        assert config.metadata is None

    def test_full(self) -> None:
        config = AgentConfig(
            agent_id="agent-1",
            name="Agent",
            system_prompt="prompt",
            limits=AgentLimits(max_steps=5),
            context=_gov_ctx(),
            description="A test agent",
            tools=["lookup", "create"],
            metadata={"key": "value"},
        )
        assert config.tools == ["lookup", "create"]
        assert config.metadata == {"key": "value"}
        assert config.limits.max_steps == 5


# ---------------------------------------------------------------------------
# AgentResult
# ---------------------------------------------------------------------------


class TestAgentResult:
    def test_success(self) -> None:
        result: AgentResult[str] = AgentResult(
            run_id="run_001",
            agent_id="agent-1",
            status="completed",
            output="Task done",
            steps=[],
            total_steps=3,
            total_duration_ms=500.0,
            started_at=_NOW,
            ended_at=_NOW,
        )
        assert result.status == "completed"
        assert result.output == "Task done"
        assert result.error is None
        assert result.usage is None
        assert result.policy is None

    def test_failure(self) -> None:
        result: AgentResult[None] = AgentResult(
            run_id="run_002",
            agent_id="agent-1",
            status="failed",
            output=None,
            steps=[],
            total_steps=1,
            total_duration_ms=100.0,
            started_at=_NOW,
            ended_at=_NOW,
            error="Something went wrong",
        )
        assert result.status == "failed"
        assert result.error == "Something went wrong"
        assert result.output is None

    def test_max_steps_reached(self) -> None:
        result: AgentResult[None] = AgentResult(
            run_id="run_003",
            agent_id="agent-1",
            status="max_steps_reached",
            output=None,
            steps=[],
            total_steps=10,
            total_duration_ms=5000.0,
            started_at=_NOW,
            ended_at=_NOW,
        )
        assert result.status == "max_steps_reached"


# ---------------------------------------------------------------------------
# AgentHandlers
# ---------------------------------------------------------------------------


class TestAgentHandlers:
    def test_construction(self) -> None:
        async def plan_fn(inp: object, step: AgentStep) -> StepPlan:
            return StepPlan(action="a", reasoning="r")

        async def exec_fn(plan: StepPlan, step: AgentStep) -> StepExecution:
            return StepExecution()

        async def observe_fn(exe: StepExecution, step: AgentStep) -> StepObservation:
            return StepObservation(result="ok", is_complete=True)

        handlers = AgentHandlers(plan=plan_fn, execute=exec_fn, observe=observe_fn)
        assert callable(handlers.plan)
        assert callable(handlers.execute)
        assert callable(handlers.observe)
        assert handlers.execute_tool is None


# ---------------------------------------------------------------------------
# AgentRunInput
# ---------------------------------------------------------------------------


class TestAgentRunInput:
    def test_minimal(self) -> None:
        run_input = AgentRunInput(input="Hello")
        assert run_input.input == "Hello"
        assert run_input.run_id is None
        assert run_input.limits is None
        assert run_input.parent_run_id is None
        assert run_input.on_step is None

    def test_full(self) -> None:
        run_input = AgentRunInput(
            input="Hello",
            run_id="run_custom",
            limits=AgentLimits(max_steps=3),
            parent_run_id="run_parent",
        )
        assert run_input.run_id == "run_custom"
        assert run_input.limits is not None
        assert run_input.limits.max_steps == 3
        assert run_input.parent_run_id == "run_parent"
