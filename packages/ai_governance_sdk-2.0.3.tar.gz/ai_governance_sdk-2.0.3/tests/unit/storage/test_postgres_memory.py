"""Unit tests for arelis.storage.postgres.memory_provider."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from arelis.storage.postgres.audit_sink import PostgresStorageError
from arelis.storage.postgres.memory_provider import (
    MemoryEntry,
    PostgresMemoryProvider,
    PostgresMemoryProviderConfig,
    create_postgres_memory_provider,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_context(org_id: str = "org-1") -> SimpleNamespace:
    """Create a mock memory context with governance.org.id."""
    return SimpleNamespace(
        governance=SimpleNamespace(
            org=SimpleNamespace(id=org_id),
        ),
    )


def _make_db_row(
    row_id: int = 1,
    scope: str = "session",
    key: str = "key-1",
    value: object = "hello",
    metadata: dict[str, object] | None = None,
    created_at: datetime | None = None,
    updated_at: datetime | None = None,
) -> dict[str, object]:
    """Create a mock database row dict (asyncpg Record-like)."""
    now = datetime.now(timezone.utc)
    return {
        "id": row_id,
        "scope": scope,
        "key": key,
        "value": json.dumps(value),
        "metadata": json.dumps(metadata) if metadata else None,
        "created_at": created_at or now,
        "updated_at": updated_at or now,
    }


def _make_mock_pool() -> MagicMock:
    """Create a mock asyncpg pool."""
    mock_conn = AsyncMock()
    mock_conn.fetchrow = AsyncMock(return_value=None)
    mock_conn.fetch = AsyncMock(return_value=[])
    mock_conn.execute = AsyncMock(return_value="DELETE 0")

    mock_pool = MagicMock()
    mock_pool.close = AsyncMock()

    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=mock_conn)
    cm.__aexit__ = AsyncMock(return_value=False)
    mock_pool.acquire = MagicMock(return_value=cm)

    return mock_pool


def _get_mock_conn(mock_pool: MagicMock) -> AsyncMock:
    """Extract the mock connection from a mock pool."""
    cm = mock_pool.acquire.return_value
    # The conn is returned by __aenter__; we need to get the mock directly
    return cm.__aenter__.return_value


# ---------------------------------------------------------------------------
# Initialization tests
# ---------------------------------------------------------------------------


class TestPostgresMemoryProviderInit:
    """Tests for PostgresMemoryProvider initialization."""

    def test_default_config(self) -> None:
        """Provider uses default config when none provided."""
        provider = PostgresMemoryProvider()
        assert provider.id == "postgres"
        assert provider._pool is None

    def test_custom_config(self) -> None:
        """Provider respects custom config values."""
        config = PostgresMemoryProviderConfig(
            id="custom-pg",
            org_id="org-fixed",
            auto_migrate="never",
        )
        provider = PostgresMemoryProvider(config)
        assert provider.id == "custom-pg"
        assert provider._config.org_id == "org-fixed"

    def test_factory_function(self) -> None:
        """create_postgres_memory_provider returns a PostgresMemoryProvider."""
        config = PostgresMemoryProviderConfig(auto_migrate="never")
        provider = create_postgres_memory_provider(config)
        assert isinstance(provider, PostgresMemoryProvider)

    def test_factory_function_default(self) -> None:
        """create_postgres_memory_provider works with None config."""
        provider = create_postgres_memory_provider(None)
        assert isinstance(provider, PostgresMemoryProvider)


# ---------------------------------------------------------------------------
# Read tests
# ---------------------------------------------------------------------------


class TestRead:
    """Tests for PostgresMemoryProvider.read()."""

    @pytest.mark.asyncio
    async def test_read_returns_none_when_not_found(self) -> None:
        """read() returns None when no row is found."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=None)

        result = await provider.read("session", "missing-key", _make_context())
        assert result is None

    @pytest.mark.asyncio
    async def test_read_returns_memory_entry(self) -> None:
        """read() returns a MemoryEntry when a row is found."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        row = _make_db_row(scope="session", key="greeting", value="hello world")
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        result = await provider.read("session", "greeting", _make_context())

        assert result is not None
        assert isinstance(result, MemoryEntry)
        assert result.scope == "session"
        assert result.key == "greeting"
        assert result.value == "hello world"

    @pytest.mark.asyncio
    async def test_read_passes_correct_scope_and_key(self) -> None:
        """read() passes scope, key, and org_id to the query."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-42")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=None)

        await provider.read("longterm", "user-prefs", _make_context())

        mock_conn.fetchrow.assert_called_once()
        call_args = mock_conn.fetchrow.call_args[0]
        # Args after the SQL: scope, key, org_id
        assert call_args[1] == "longterm"
        assert call_args[2] == "user-prefs"
        assert call_args[3] == "org-42"


# ---------------------------------------------------------------------------
# Write tests
# ---------------------------------------------------------------------------


class TestWrite:
    """Tests for PostgresMemoryProvider.write()."""

    @pytest.mark.asyncio
    async def test_write_returns_memory_entry(self) -> None:
        """write() returns the created/updated MemoryEntry."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        row = _make_db_row(scope="session", key="greeting", value="hi")
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        result = await provider.write(
            "session",
            "greeting",
            "hi",
            _make_context(),
        )

        assert isinstance(result, MemoryEntry)
        assert result.scope == "session"
        assert result.key == "greeting"
        assert result.value == "hi"

    @pytest.mark.asyncio
    async def test_write_with_metadata(self) -> None:
        """write() stores metadata alongside the value."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        meta = {"source": "user", "priority": 1}
        row = _make_db_row(
            scope="session",
            key="pref",
            value={"color": "blue"},
            metadata=meta,
        )
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        result = await provider.write(
            "session",
            "pref",
            {"color": "blue"},
            _make_context(),
            metadata=meta,
        )

        assert result.metadata == meta

    @pytest.mark.asyncio
    async def test_write_passes_ttl(self) -> None:
        """write() computes expires_at when ttl_seconds is provided."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        row = _make_db_row(scope="ephemeral", key="tmp", value="data")
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        await provider.write(
            "ephemeral",
            "tmp",
            "data",
            _make_context(),
            ttl_seconds=300,
        )

        mock_conn.fetchrow.assert_called_once()
        call_args = mock_conn.fetchrow.call_args[0]
        # expires_at is the 6th positional arg (index 6)
        expires_at = call_args[6]
        assert expires_at is not None
        # It should be a datetime about 300 seconds in the future
        assert isinstance(expires_at, datetime)

    @pytest.mark.asyncio
    async def test_write_no_ttl_sets_null_expiration(self) -> None:
        """write() sets expires_at to None when ttl_seconds is not provided."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        row = _make_db_row(scope="longterm", key="permanent", value="keep")
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        await provider.write("longterm", "permanent", "keep", _make_context())

        call_args = mock_conn.fetchrow.call_args[0]
        expires_at = call_args[6]
        assert expires_at is None


# ---------------------------------------------------------------------------
# Delete tests
# ---------------------------------------------------------------------------


class TestDelete:
    """Tests for PostgresMemoryProvider.delete()."""

    @pytest.mark.asyncio
    async def test_delete_returns_true_when_found(self) -> None:
        """delete() returns True when a row was deleted."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.execute = AsyncMock(return_value="DELETE 1")

        result = await provider.delete("session", "greeting", _make_context())
        assert result is True

    @pytest.mark.asyncio
    async def test_delete_returns_false_when_not_found(self) -> None:
        """delete() returns False when no row was deleted."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.execute = AsyncMock(return_value="DELETE 0")

        result = await provider.delete("session", "nonexistent", _make_context())
        assert result is False

    @pytest.mark.asyncio
    async def test_delete_passes_correct_params(self) -> None:
        """delete() passes scope, key, and org_id to the query."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-99")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.execute = AsyncMock(return_value="DELETE 0")

        await provider.delete("shared", "secret", _make_context())

        call_args = mock_conn.execute.call_args[0]
        assert call_args[1] == "shared"
        assert call_args[2] == "secret"
        assert call_args[3] == "org-99"


# ---------------------------------------------------------------------------
# List tests
# ---------------------------------------------------------------------------


class TestList:
    """Tests for PostgresMemoryProvider.list()."""

    @pytest.mark.asyncio
    async def test_list_returns_empty_list(self) -> None:
        """list() returns empty list when no rows found."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetch = AsyncMock(return_value=[])

        result = await provider.list("session", _make_context())
        assert result == []

    @pytest.mark.asyncio
    async def test_list_returns_multiple_entries(self) -> None:
        """list() returns all entries in the scope."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        rows = [
            _make_db_row(row_id=1, scope="session", key="a", value="val-a"),
            _make_db_row(row_id=2, scope="session", key="b", value="val-b"),
            _make_db_row(row_id=3, scope="session", key="c", value="val-c"),
        ]
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetch = AsyncMock(return_value=rows)

        result = await provider.list("session", _make_context())

        assert len(result) == 3
        assert all(isinstance(e, MemoryEntry) for e in result)
        assert [e.key for e in result] == ["a", "b", "c"]

    @pytest.mark.asyncio
    async def test_list_passes_scope_and_org_id(self) -> None:
        """list() passes scope and org_id to the query."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-77")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetch = AsyncMock(return_value=[])

        await provider.list("longterm", _make_context())

        call_args = mock_conn.fetch.call_args[0]
        assert call_args[1] == "longterm"
        assert call_args[2] == "org-77"


# ---------------------------------------------------------------------------
# Scope-based key isolation tests
# ---------------------------------------------------------------------------


class TestScopeIsolation:
    """Tests that scope and org_id isolate keys."""

    @pytest.mark.asyncio
    async def test_different_scopes_different_queries(self) -> None:
        """Reading the same key in different scopes produces different queries."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=None)

        await provider.read("session", "key-1", _make_context())
        await provider.read("longterm", "key-1", _make_context())

        calls = mock_conn.fetchrow.call_args_list
        assert len(calls) == 2
        # Different scope values
        assert calls[0][0][1] == "session"
        assert calls[1][0][1] == "longterm"
        # Same key
        assert calls[0][0][2] == "key-1"
        assert calls[1][0][2] == "key-1"

    @pytest.mark.asyncio
    async def test_different_orgs_different_queries(self) -> None:
        """Different org_ids produce different queries."""
        provider_a = PostgresMemoryProvider(
            PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-A"),
        )
        provider_b = PostgresMemoryProvider(
            PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-B"),
        )

        mock_pool_a = _make_mock_pool()
        mock_pool_b = _make_mock_pool()
        provider_a._pool = mock_pool_a
        provider_b._pool = mock_pool_b

        mock_conn_a = _get_mock_conn(mock_pool_a)
        mock_conn_b = _get_mock_conn(mock_pool_b)
        mock_conn_a.fetchrow = AsyncMock(return_value=None)
        mock_conn_b.fetchrow = AsyncMock(return_value=None)

        await provider_a.read("session", "key-1", _make_context("org-A"))
        await provider_b.read("session", "key-1", _make_context("org-B"))

        args_a = mock_conn_a.fetchrow.call_args[0]
        args_b = mock_conn_b.fetchrow.call_args[0]
        assert args_a[3] == "org-A"
        assert args_b[3] == "org-B"


# ---------------------------------------------------------------------------
# Metadata storage and retrieval tests
# ---------------------------------------------------------------------------


class TestMetadataStorage:
    """Tests for metadata handling in MemoryEntry."""

    @pytest.mark.asyncio
    async def test_read_entry_with_metadata(self) -> None:
        """Reading an entry with metadata returns it correctly."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        meta = {"author": "system", "version": 2}
        row = _make_db_row(
            scope="session",
            key="tagged",
            value="data",
            metadata=meta,
        )
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        result = await provider.read("session", "tagged", _make_context())
        assert result is not None
        assert result.metadata == meta

    @pytest.mark.asyncio
    async def test_read_entry_without_metadata(self) -> None:
        """Reading an entry with null metadata returns None for metadata."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        row = _make_db_row(scope="session", key="plain", value="data", metadata=None)
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        result = await provider.read("session", "plain", _make_context())
        assert result is not None
        assert result.metadata is None

    @pytest.mark.asyncio
    async def test_read_entry_with_dict_value(self) -> None:
        """Reading an entry where asyncpg already decoded jsonb to a dict."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="org-1")
        provider = PostgresMemoryProvider(config)
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        now = datetime.now(timezone.utc)
        # Simulate asyncpg returning already-parsed jsonb as a dict
        row = {
            "id": 5,
            "scope": "session",
            "key": "parsed",
            "value": {"nested": True},
            "metadata": {"tag": "auto"},
            "created_at": now,
            "updated_at": now,
        }
        mock_conn = _get_mock_conn(mock_pool)
        mock_conn.fetchrow = AsyncMock(return_value=row)

        result = await provider.read("session", "parsed", _make_context())
        assert result is not None
        assert result.value == {"nested": True}
        assert result.metadata == {"tag": "auto"}


# ---------------------------------------------------------------------------
# Org ID resolution tests
# ---------------------------------------------------------------------------


class TestOrgIdResolution:
    """Tests for _resolve_org_id."""

    def test_resolve_from_config(self) -> None:
        """org_id is resolved from config when set."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id="config-org")
        provider = PostgresMemoryProvider(config)
        result = provider._resolve_org_id(_make_context("ctx-org"))
        assert result == "config-org"

    def test_resolve_from_context(self) -> None:
        """org_id falls back to context.governance.org.id."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id=None)
        provider = PostgresMemoryProvider(config)
        result = provider._resolve_org_id(_make_context("ctx-org"))
        assert result == "ctx-org"

    def test_resolve_raises_when_missing(self) -> None:
        """Raises PostgresStorageError when org_id cannot be resolved."""
        config = PostgresMemoryProviderConfig(auto_migrate="never", org_id=None)
        provider = PostgresMemoryProvider(config)
        # Context with no governance attribute
        with pytest.raises(PostgresStorageError, match="org_id"):
            provider._resolve_org_id(object())


# ---------------------------------------------------------------------------
# Close tests
# ---------------------------------------------------------------------------


class TestClose:
    """Tests for PostgresMemoryProvider.close()."""

    @pytest.mark.asyncio
    async def test_close_with_no_pool(self) -> None:
        """close() is a no-op when no pool exists."""
        provider = PostgresMemoryProvider(
            PostgresMemoryProviderConfig(auto_migrate="never"),
        )
        await provider.close()  # Should not raise
        assert provider._pool is None

    @pytest.mark.asyncio
    async def test_close_closes_pool(self) -> None:
        """close() closes the pool and sets it to None."""
        import sys

        provider = PostgresMemoryProvider(
            PostgresMemoryProviderConfig(auto_migrate="never"),
        )
        mock_pool = _make_mock_pool()
        provider._pool = mock_pool

        # The close() method does `import asyncpg` locally, so we must
        # inject a mock into sys.modules for the import to succeed.
        mock_asyncpg = MagicMock()
        mock_asyncpg.Pool = MagicMock
        had_asyncpg = "asyncpg" in sys.modules
        original = sys.modules.get("asyncpg")
        sys.modules["asyncpg"] = mock_asyncpg
        try:
            await provider.close()
        finally:
            if had_asyncpg:
                sys.modules["asyncpg"] = original  # type: ignore[assignment]
            else:
                del sys.modules["asyncpg"]

        mock_pool.close.assert_called_once()
        assert provider._pool is None


# ---------------------------------------------------------------------------
# MemoryEntry dataclass tests
# ---------------------------------------------------------------------------


class TestMemoryEntry:
    """Tests for the MemoryEntry dataclass."""

    def test_fields(self) -> None:
        entry = MemoryEntry(
            id="1",
            scope="session",
            key="k",
            value="v",
            created_at="2024-01-01T00:00:00",
            updated_at="2024-01-01T00:00:00",
            metadata={"a": 1},
        )
        assert entry.id == "1"
        assert entry.scope == "session"
        assert entry.key == "k"
        assert entry.value == "v"
        assert entry.metadata == {"a": 1}

    def test_default_metadata_is_none(self) -> None:
        entry = MemoryEntry(
            id="1",
            scope="s",
            key="k",
            value="v",
            created_at="t",
            updated_at="t",
        )
        assert entry.metadata is None
