"""Unit tests for arelis.storage.postgres.audit_sink."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from arelis.audit.types import (
    AuditContext,
    AuditContextActor,
    AuditContextOrg,
    AuditContextTeam,
    RunStartedEvent,
)
from arelis.storage.postgres.audit_sink import (
    PostgresAuditSink,
    PostgresAuditSinkConfig,
    PostgresStorageError,
    _serialize_event,
    create_postgres_audit_sink,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_context(
    org_id: str = "org-1",
    actor_id: str = "user-1",
    actor_type: str = "user",
    purpose: str = "test",
    environment: str = "test",
    team_id: str | None = None,
) -> AuditContext:
    return AuditContext(
        org=AuditContextOrg(id=org_id),
        actor=AuditContextActor(type=actor_type, id=actor_id),
        purpose=purpose,
        environment=environment,
        team=AuditContextTeam(id=team_id) if team_id else None,
    )


def _make_event(
    event_id: str = "evt-1",
    run_id: str = "run-1",
    event_type: str = "run.started",
    context: AuditContext | None = None,
) -> RunStartedEvent:
    return RunStartedEvent(
        schema_version="1.0",
        event_id=event_id,
        time=datetime.now(timezone.utc).isoformat(),
        run_id=run_id,
        type=event_type,  # type: ignore[arg-type]
        context=context or _make_context(),
    )


def _make_mock_pool() -> MagicMock:
    """Create a mock asyncpg pool with acquire() context manager."""
    mock_conn = AsyncMock()
    mock_conn.execute = AsyncMock(return_value="INSERT 1")
    mock_conn.executemany = AsyncMock()

    mock_pool = MagicMock()
    mock_pool.close = AsyncMock()

    # Make acquire() return an async context manager yielding mock_conn
    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=mock_conn)
    cm.__aexit__ = AsyncMock(return_value=False)
    mock_pool.acquire = MagicMock(return_value=cm)

    return mock_pool


# ---------------------------------------------------------------------------
# Initialization tests
# ---------------------------------------------------------------------------


class TestPostgresAuditSinkInit:
    """Tests for PostgresAuditSink initialization."""

    def test_default_config(self) -> None:
        """Sink uses default config when none provided."""
        config = PostgresAuditSinkConfig(auto_migrate="never")
        sink = PostgresAuditSink(config)
        assert sink._config.batching is True
        assert sink._config.batch_size == 100
        assert sink._config.flush_interval_ms == 5000
        assert sink._config.max_retries == 3
        assert sink._closed is False

    def test_custom_config(self) -> None:
        """Sink respects custom config values."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=False,
            batch_size=50,
            flush_interval_ms=1000,
            max_retries=5,
        )
        sink = PostgresAuditSink(config)
        assert sink._config.batching is False
        assert sink._config.batch_size == 50
        assert sink._config.flush_interval_ms == 1000
        assert sink._config.max_retries == 5

    def test_empty_buffer_on_init(self) -> None:
        """Buffer is empty on initialization."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)
        assert sink._buffer == []
        assert sink._pool is None

    def test_factory_function(self) -> None:
        """create_postgres_audit_sink returns a PostgresAuditSink."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = create_postgres_audit_sink(config)
        assert isinstance(sink, PostgresAuditSink)

    def test_factory_function_default_config(self) -> None:
        """create_postgres_audit_sink works with None config."""
        sink = create_postgres_audit_sink(None)
        assert isinstance(sink, PostgresAuditSink)


# ---------------------------------------------------------------------------
# Batching logic tests
# ---------------------------------------------------------------------------


class TestBatchingLogic:
    """Tests for event batching behavior."""

    @pytest.mark.asyncio
    async def test_write_buffers_when_batching_enabled(self) -> None:
        """Events are buffered when batching is enabled."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=10,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()  # Prevent background flush
        event = _make_event()

        # Patch _insert_with_retry to track calls
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        await sink.write(event)

        assert len(sink._buffer) == 1
        assert sink._buffer[0] is event
        sink._insert_with_retry.assert_not_called()

    @pytest.mark.asyncio
    async def test_write_flushes_at_batch_size(self) -> None:
        """Buffer is flushed when it reaches batch_size."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=3,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()

        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        for i in range(3):
            await sink.write(_make_event(event_id=f"evt-{i}"))

        # Buffer should be empty after flush
        assert len(sink._buffer) == 0
        sink._insert_with_retry.assert_called_once()
        flushed_events = sink._insert_with_retry.call_args[0][0]
        assert len(flushed_events) == 3

    @pytest.mark.asyncio
    async def test_write_batch_buffers_multiple_events(self) -> None:
        """write_batch adds all events to the buffer."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=100,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        events = [_make_event(event_id=f"evt-{i}") for i in range(5)]
        await sink.write_batch(events)

        assert len(sink._buffer) == 5
        sink._insert_with_retry.assert_not_called()

    @pytest.mark.asyncio
    async def test_write_batch_flushes_at_threshold(self) -> None:
        """write_batch flushes when buffer reaches batch_size."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=3,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        events = [_make_event(event_id=f"evt-{i}") for i in range(5)]
        await sink.write_batch(events)

        assert len(sink._buffer) == 0
        sink._insert_with_retry.assert_called_once()

    @pytest.mark.asyncio
    async def test_write_without_batching_inserts_immediately(self) -> None:
        """Events are inserted immediately when batching is disabled."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=False,
        )
        sink = PostgresAuditSink(config)
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        event = _make_event()
        await sink.write(event)

        assert len(sink._buffer) == 0
        sink._insert_with_retry.assert_called_once_with([event])

    @pytest.mark.asyncio
    async def test_flush_empty_buffer_is_noop(self) -> None:
        """Flushing an empty buffer does nothing."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        await sink.flush()

        sink._insert_with_retry.assert_not_called()

    @pytest.mark.asyncio
    async def test_flush_clears_buffer(self) -> None:
        """Flush empties the buffer and inserts events."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=100,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        events = [_make_event(event_id=f"evt-{i}") for i in range(3)]
        for e in events:
            await sink.write(e)

        assert len(sink._buffer) == 3
        await sink.flush()
        assert len(sink._buffer) == 0

    @pytest.mark.asyncio
    async def test_flush_requeues_on_failure(self) -> None:
        """Failed flush re-queues events back into the buffer."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=100,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()
        sink._insert_with_retry = AsyncMock(  # type: ignore[method-assign]
            side_effect=PostgresStorageError("insert failed", "INSERT_FAILED"),
        )

        events = [_make_event(event_id=f"evt-{i}") for i in range(3)]
        for e in events:
            await sink.write(e)

        with pytest.raises(PostgresStorageError):
            await sink.flush()

        # Events should be re-queued
        assert len(sink._buffer) == 3


# ---------------------------------------------------------------------------
# Event serialization tests
# ---------------------------------------------------------------------------


class TestEventSerialization:
    """Tests for _serialize_event."""

    def test_serialize_produces_dict(self) -> None:
        """_serialize_event returns a dict from a dataclass event."""
        event = _make_event()
        result = _serialize_event(event)
        assert isinstance(result, dict)
        assert result["event_id"] == "evt-1"
        assert result["run_id"] == "run-1"
        assert result["type"] == "run.started"

    def test_serialize_includes_context(self) -> None:
        """Serialized event includes context fields."""
        ctx = _make_context(org_id="org-42", actor_id="actor-7", team_id="team-3")
        event = _make_event(context=ctx)
        result = _serialize_event(event)
        assert result["context"]["org"]["id"] == "org-42"
        assert result["context"]["actor"]["id"] == "actor-7"
        assert result["context"]["team"]["id"] == "team-3"

    def test_serialize_is_json_safe(self) -> None:
        """Serialized event can be converted to JSON."""
        event = _make_event()
        result = _serialize_event(event)
        json_str = json.dumps(result, default=str)
        assert isinstance(json_str, str)
        parsed = json.loads(json_str)
        assert parsed["event_id"] == "evt-1"


# ---------------------------------------------------------------------------
# Write/close error handling
# ---------------------------------------------------------------------------


class TestSinkErrorHandling:
    """Tests for error states and close behavior."""

    @pytest.mark.asyncio
    async def test_write_after_close_raises(self) -> None:
        """Writing to a closed sink raises PostgresStorageError."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)
        sink._closed = True

        with pytest.raises(PostgresStorageError, match="closed"):
            await sink.write(_make_event())

    @pytest.mark.asyncio
    async def test_write_batch_after_close_raises(self) -> None:
        """write_batch on a closed sink raises PostgresStorageError."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)
        sink._closed = True

        with pytest.raises(PostgresStorageError, match="closed"):
            await sink.write_batch([_make_event()])

    @pytest.mark.asyncio
    async def test_close_flushes_remaining_events(self) -> None:
        """close() flushes any buffered events."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            batching=True,
            batch_size=100,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()
        sink._insert_with_retry = AsyncMock()  # type: ignore[method-assign]

        await sink.write(_make_event())
        assert len(sink._buffer) == 1

        await sink.close()
        assert sink._closed is True
        # flush was called which drained the buffer
        sink._insert_with_retry.assert_called_once()

    @pytest.mark.asyncio
    async def test_close_idempotent(self) -> None:
        """Calling close() twice is safe."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)
        await sink.close()
        await sink.close()  # Should not raise
        assert sink._closed is True

    @pytest.mark.asyncio
    async def test_close_closes_pool(self) -> None:
        """close() closes the underlying connection pool."""
        import sys

        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)

        mock_pool = _make_mock_pool()
        sink._pool = mock_pool

        # The close() method does `import asyncpg` locally, so we must
        # inject a mock into sys.modules for the import to succeed.
        mock_asyncpg = MagicMock()
        mock_asyncpg.Pool = MagicMock
        had_asyncpg = "asyncpg" in sys.modules
        original = sys.modules.get("asyncpg")
        sys.modules["asyncpg"] = mock_asyncpg
        try:
            await sink.close()
        finally:
            if had_asyncpg:
                sys.modules["asyncpg"] = original  # type: ignore[assignment]
            else:
                del sys.modules["asyncpg"]

        mock_pool.close.assert_called_once()
        assert sink._pool is None


# ---------------------------------------------------------------------------
# Insert with mock pool tests
# ---------------------------------------------------------------------------


class TestInsertWithMockPool:
    """Tests for _insert using a mock pool."""

    @pytest.mark.asyncio
    async def test_insert_calls_executemany(self) -> None:
        """_insert calls executemany on the connection."""
        config = PostgresAuditSinkConfig(auto_migrate="never", batching=False)
        sink = PostgresAuditSink(config)
        mock_pool = _make_mock_pool()
        sink._pool = mock_pool

        event = _make_event()
        await sink._insert([event])

        cm = mock_pool.acquire.return_value
        mock_conn = await cm.__aenter__()
        mock_conn.executemany.assert_called_once()
        call_args = mock_conn.executemany.call_args
        # First arg is the SQL, second is the rows list
        rows = call_args[0][1]
        assert len(rows) == 1
        assert rows[0][0] == "evt-1"  # event_id
        assert rows[0][1] == "run-1"  # run_id


# ---------------------------------------------------------------------------
# Backoff calculation tests
# ---------------------------------------------------------------------------


class TestBackoffCalculation:
    """Tests for exponential backoff delay calculation."""

    def test_attempt_zero(self) -> None:
        """First attempt uses base_delay_ms."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            base_delay_ms=1000,
            max_delay_ms=30000,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()

        delay = sink._calculate_backoff_delay(0)
        # base * 2^0 = 1000, plus up to 25% jitter
        assert 1000 <= delay <= 1250

    def test_attempt_increases_delay(self) -> None:
        """Later attempts produce larger delays."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            base_delay_ms=1000,
            max_delay_ms=30000,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()

        delay_0 = sink._calculate_backoff_delay(0)
        delay_2 = sink._calculate_backoff_delay(2)
        # attempt 2: base * 4 = 4000, jitter up to +1000
        assert delay_2 >= delay_0

    def test_delay_capped_at_max(self) -> None:
        """Delay is capped at max_delay_ms (plus jitter)."""
        config = PostgresAuditSinkConfig(
            auto_migrate="never",
            base_delay_ms=1000,
            max_delay_ms=5000,
        )
        sink = PostgresAuditSink(config)
        sink._stop_flush_timer()

        delay = sink._calculate_backoff_delay(20)  # Very high attempt
        # capped at 5000 + up to 25% jitter = 6250
        assert delay <= 6250


# ---------------------------------------------------------------------------
# Validation error detection
# ---------------------------------------------------------------------------


class TestValidationErrorDetection:
    """Tests for _is_validation_error static method."""

    def test_validation_keyword_detected(self) -> None:
        assert PostgresAuditSink._is_validation_error(ValueError("validation failed"))

    def test_invalid_keyword_detected(self) -> None:
        assert PostgresAuditSink._is_validation_error(ValueError("invalid input"))

    def test_constraint_keyword_detected(self) -> None:
        assert PostgresAuditSink._is_validation_error(ValueError("constraint violation"))

    def test_unrelated_error_not_detected(self) -> None:
        assert not PostgresAuditSink._is_validation_error(RuntimeError("connection timeout"))


# ---------------------------------------------------------------------------
# PostgresStorageError tests
# ---------------------------------------------------------------------------


class TestPostgresStorageError:
    """Tests for the PostgresStorageError class."""

    def test_error_attributes(self) -> None:
        err = PostgresStorageError("test message", "TEST_CODE")
        assert str(err) == "test message"
        assert err.code == "TEST_CODE"
        assert err.__cause__ is None

    def test_error_with_cause(self) -> None:
        cause = RuntimeError("original")
        err = PostgresStorageError("wrapper", "WRAP_CODE", cause)
        assert err.__cause__ is cause
        assert err.code == "WRAP_CODE"
