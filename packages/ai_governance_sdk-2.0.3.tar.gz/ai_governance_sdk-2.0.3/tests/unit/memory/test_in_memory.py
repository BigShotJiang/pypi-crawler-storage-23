"""Tests for arelis.memory.in_memory."""

from __future__ import annotations

import pytest

from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.memory.in_memory import InMemoryMemoryProvider, create_in_memory_memory_provider
from arelis.memory.types import MemoryContext, MemoryEntry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_context() -> MemoryContext:
    return MemoryContext(
        run_id="run_test",
        governance=GovernanceContext(
            org=OrgRef(id="org-1"),
            actor=ActorRef(type="human", id="actor-1"),
            purpose="testing",
            environment="dev",
        ),
    )


# ---------------------------------------------------------------------------
# InMemoryMemoryProvider
# ---------------------------------------------------------------------------


class TestInMemoryMemoryProvider:
    @pytest.mark.asyncio
    async def test_write_and_read(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        entry = await provider.write("ephemeral", "key1", {"data": 42}, ctx)
        assert isinstance(entry, MemoryEntry)
        assert entry.scope == "ephemeral"
        assert entry.key == "key1"
        assert entry.value == {"data": 42}
        assert entry.created_at
        assert entry.updated_at

        read_entry = await provider.read("ephemeral", "key1", ctx)
        assert read_entry is not None
        assert read_entry.id == entry.id
        assert read_entry.value == {"data": 42}

    @pytest.mark.asyncio
    async def test_read_nonexistent_returns_none(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        result = await provider.read("ephemeral", "missing", ctx)
        assert result is None

    @pytest.mark.asyncio
    async def test_write_updates_existing(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        first = await provider.write("session", "k", "old", ctx)
        second = await provider.write("session", "k", "new", ctx)
        assert second.id == first.id  # same ID preserved
        assert second.value == "new"
        assert second.created_at == first.created_at
        assert second.updated_at >= first.updated_at

    @pytest.mark.asyncio
    async def test_write_with_metadata(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        entry = await provider.write("long-term", "k", "val", ctx, metadata={"source": "test"})
        assert entry.metadata == {"source": "test"}

    @pytest.mark.asyncio
    async def test_write_preserves_metadata_on_update_without_new_metadata(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        await provider.write("shared", "k", "v1", ctx, metadata={"a": "b"})
        updated = await provider.write("shared", "k", "v2", ctx)
        assert updated.metadata == {"a": "b"}

    @pytest.mark.asyncio
    async def test_delete_existing_returns_true(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        await provider.write("ephemeral", "k", "v", ctx)
        result = await provider.delete("ephemeral", "k", ctx)
        assert result is True
        assert await provider.read("ephemeral", "k", ctx) is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent_returns_false(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        result = await provider.delete("ephemeral", "nope", ctx)
        assert result is False

    @pytest.mark.asyncio
    async def test_list_entries_by_scope(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        await provider.write("ephemeral", "a", 1, ctx)
        await provider.write("ephemeral", "b", 2, ctx)
        await provider.write("session", "c", 3, ctx)
        entries = await provider.list("ephemeral", ctx)
        assert len(entries) == 2
        keys = {e.key for e in entries}
        assert keys == {"a", "b"}

    @pytest.mark.asyncio
    async def test_list_empty_scope(self) -> None:
        provider = InMemoryMemoryProvider()
        ctx = _make_context()
        entries = await provider.list("long-term", ctx)
        assert entries == []

    def test_custom_id(self) -> None:
        provider = InMemoryMemoryProvider(id="custom-mem")
        assert provider.id == "custom-mem"

    def test_default_id(self) -> None:
        provider = InMemoryMemoryProvider()
        assert provider.id == "memory"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestCreateInMemoryMemoryProvider:
    def test_factory_returns_provider(self) -> None:
        provider = create_in_memory_memory_provider()
        assert isinstance(provider, InMemoryMemoryProvider)

    def test_factory_with_custom_id(self) -> None:
        provider = create_in_memory_memory_provider(id="my-mem")
        assert provider.id == "my-mem"
