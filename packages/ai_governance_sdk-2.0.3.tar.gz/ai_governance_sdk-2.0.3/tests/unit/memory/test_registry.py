"""Tests for arelis.memory.registry."""

from __future__ import annotations

import pytest

from arelis.memory.in_memory import InMemoryMemoryProvider
from arelis.memory.registry import MemoryRegistry, create_memory_registry

# ---------------------------------------------------------------------------
# MemoryRegistry
# ---------------------------------------------------------------------------


class TestMemoryRegistry:
    def test_register_and_get(self) -> None:
        registry = MemoryRegistry()
        provider = InMemoryMemoryProvider(id="mem-1")
        registry.register(provider)
        result = registry.get("mem-1")
        assert result is not None
        assert result.id == "mem-1"

    def test_get_unknown_returns_none(self) -> None:
        registry = MemoryRegistry()
        assert registry.get("nonexistent") is None

    def test_register_duplicate_raises(self) -> None:
        registry = MemoryRegistry()
        provider = InMemoryMemoryProvider(id="mem-1")
        registry.register(provider)
        with pytest.raises(ValueError, match="already registered"):
            registry.register(provider)

    def test_register_duplicate_with_replace(self) -> None:
        registry = MemoryRegistry()
        p1 = InMemoryMemoryProvider(id="mem-1")
        p2 = InMemoryMemoryProvider(id="mem-1")
        registry.register(p1)
        registry.register(p2, replace=True)
        result = registry.get("mem-1")
        assert result is p2

    def test_list(self) -> None:
        registry = MemoryRegistry()
        p1 = InMemoryMemoryProvider(id="a")
        p2 = InMemoryMemoryProvider(id="b")
        registry.register(p1)
        registry.register(p2)
        providers = registry.list()
        assert len(providers) == 2

    def test_list_empty(self) -> None:
        registry = MemoryRegistry()
        assert registry.list() == []

    def test_clear(self) -> None:
        registry = MemoryRegistry()
        registry.register(InMemoryMemoryProvider(id="x"))
        registry.clear()
        assert registry.list() == []
        assert registry.get("x") is None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestCreateMemoryRegistry:
    def test_returns_instance(self) -> None:
        registry = create_memory_registry()
        assert isinstance(registry, MemoryRegistry)
