"""Tests for arelis.models.registry."""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import datetime, timezone

import pytest

from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.models.registry import (
    ModelNotSupportedError,
    ModelRegistry,
    ProviderAlreadyRegisteredError,
    ProviderNotFoundError,
    RegisterOptions,
    ResolveOptions,
    create_model_registry,
    get_default_registry,
    reset_default_registry,
)
from arelis.models.types import (
    GenerateOptions,
    ModelDescriptor,
    ModelRequest,
    ModelResponse,
    ModelRoute,
    ModelRouteCandidate,
    ModelUsage,
    StreamChunk,
)

# ---------------------------------------------------------------------------
# Fake provider for testing
# ---------------------------------------------------------------------------


class FakeProvider:
    """Minimal provider for testing the registry."""

    def __init__(self, provider_id: str, name: str, models: list[str]) -> None:
        self._id = provider_id
        self._name = name
        self._models = models

    @property
    def id(self) -> str:
        return self._id

    @property
    def name(self) -> str:
        return self._name

    @property
    def supported_models(self) -> list[str]:
        return list(self._models)

    async def generate(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> ModelResponse:
        return ModelResponse(
            id="resp_fake",
            model=request.model,
            content="fake",
            finish_reason="stop",
            usage=ModelUsage(),
            created_at=datetime.now(timezone.utc),
        )

    def supports_model(self, model: str) -> bool:
        return model in self._models

    def stream(
        self,
        request: ModelRequest,
        options: GenerateOptions | None = None,
    ) -> AsyncIterator[StreamChunk]:
        raise NotImplementedError

    async def estimate_tokens(self, request: ModelRequest) -> int:
        return 0


def _make_ctx(purpose: str = "test") -> GovernanceContext:
    return GovernanceContext(
        org=OrgRef(id="org1"),
        actor=ActorRef(type="human", id="user1"),
        purpose=purpose,
        environment="dev",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestModelRegistryBasics:
    def test_create_model_registry(self) -> None:
        reg = create_model_registry()
        assert isinstance(reg, ModelRegistry)
        assert reg.size == 0

    def test_register_and_resolve(self) -> None:
        reg = ModelRegistry()
        provider = FakeProvider("openai", "OpenAI", ["gpt-4"])
        reg.register(provider)
        assert reg.has("openai")
        resolved = reg.resolve("openai")
        assert resolved.id == "openai"

    def test_register_duplicate_raises(self) -> None:
        reg = ModelRegistry()
        provider = FakeProvider("openai", "OpenAI", ["gpt-4"])
        reg.register(provider)
        with pytest.raises(ProviderAlreadyRegisteredError):
            reg.register(provider)

    def test_register_duplicate_with_replace(self) -> None:
        reg = ModelRegistry()
        p1 = FakeProvider("openai", "OpenAI v1", ["gpt-4"])
        p2 = FakeProvider("openai", "OpenAI v2", ["gpt-4", "gpt-4o"])
        reg.register(p1)
        reg.register(p2, RegisterOptions(replace=True))
        resolved = reg.resolve("openai")
        assert resolved.name == "OpenAI v2"

    def test_unregister(self) -> None:
        reg = ModelRegistry()
        provider = FakeProvider("openai", "OpenAI", ["gpt-4"])
        reg.register(provider)
        assert reg.unregister("openai") is True
        assert reg.has("openai") is False
        assert reg.unregister("openai") is False

    def test_resolve_not_found(self) -> None:
        reg = ModelRegistry()
        with pytest.raises(ProviderNotFoundError) as exc_info:
            reg.resolve("nonexistent")
        assert "nonexistent" in str(exc_info.value)

    def test_size_and_clear(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("a", "A", ["m1"]))
        reg.register(FakeProvider("b", "B", ["m2"]))
        assert reg.size == 2
        reg.clear()
        assert reg.size == 0


class TestEnableDisable:
    def test_disabled_provider_not_resolved_by_default(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1"]), RegisterOptions(enabled=False))
        with pytest.raises(ProviderNotFoundError):
            reg.resolve("p1")

    def test_disabled_provider_resolved_when_enabled_only_false(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1"]), RegisterOptions(enabled=False))
        resolved = reg.resolve("p1", ResolveOptions(enabled_only=False))
        assert resolved.id == "p1"

    def test_set_enabled(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1"]), RegisterOptions(enabled=False))
        assert reg.set_enabled("p1", True) is True
        resolved = reg.resolve("p1")
        assert resolved.id == "p1"

    def test_set_enabled_nonexistent(self) -> None:
        reg = ModelRegistry()
        assert reg.set_enabled("nope", True) is False


class TestPriority:
    def test_resolve_for_model_uses_priority(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("low", "Low", ["m1"]), RegisterOptions(priority=1))
        reg.register(FakeProvider("high", "High", ["m1"]), RegisterOptions(priority=10))
        resolved = reg.resolve_for_model("m1")
        assert resolved.id == "high"

    def test_set_priority(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1"]), RegisterOptions(priority=1))
        assert reg.set_priority("p1", 100) is True
        meta = reg.get_metadata("p1")
        assert meta is not None
        assert meta.priority == 100

    def test_set_priority_nonexistent(self) -> None:
        reg = ModelRegistry()
        assert reg.set_priority("nope", 10) is False


class TestResolveForModel:
    def test_model_not_supported(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1"]))
        with pytest.raises(ModelNotSupportedError) as exc_info:
            reg.resolve_for_model("unknown_model")
        assert "unknown_model" in str(exc_info.value)

    def test_model_supported(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1", "m2"]))
        resolved = reg.resolve_for_model("m2")
        assert resolved.id == "p1"


class TestListMethods:
    def test_list_provider_ids(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("a", "A", ["m1"]))
        reg.register(FakeProvider("b", "B", ["m2"]), RegisterOptions(enabled=False))
        # Default: enabled_only=False for list_provider_ids
        all_ids = reg.list_provider_ids()
        assert "a" in all_ids
        assert "b" in all_ids
        # enabled_only=True
        enabled_ids = reg.list_provider_ids(ResolveOptions(enabled_only=True))
        assert "a" in enabled_ids
        assert "b" not in enabled_ids

    def test_list_returns_sorted_by_priority(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("low", "Low", ["m1"]), RegisterOptions(priority=1))
        reg.register(FakeProvider("high", "High", ["m2"]), RegisterOptions(priority=10))
        providers = reg.list()
        assert providers[0].id == "high"
        assert providers[1].id == "low"

    def test_list_supported_models(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("p1", "P1", ["m1", "m2"]))
        reg.register(FakeProvider("p2", "P2", ["m2", "m3"]))
        models = reg.list_supported_models()
        assert models == ["m1", "m2", "m3"]


class TestModelDescriptors:
    def test_register_and_get_model(self) -> None:
        reg = ModelRegistry()
        desc = ModelDescriptor(id="gpt-4", provider_id="openai", lifecycle_state="approved")
        reg.register_model(desc)
        result = reg.get_model("gpt-4")
        assert result is not None
        assert result.id == "gpt-4"

    def test_register_model_duplicate_raises(self) -> None:
        reg = ModelRegistry()
        desc = ModelDescriptor(id="gpt-4", provider_id="openai", lifecycle_state="approved")
        reg.register_model(desc)
        with pytest.raises(ValueError, match="already registered"):
            reg.register_model(desc)

    def test_register_model_duplicate_with_replace(self) -> None:
        reg = ModelRegistry()
        d1 = ModelDescriptor(id="gpt-4", provider_id="openai", lifecycle_state="approved")
        d2 = ModelDescriptor(id="gpt-4", provider_id="openai", lifecycle_state="deprecated")
        reg.register_model(d1)
        reg.register_model(d2, replace=True)
        result = reg.get_model("gpt-4")
        assert result is not None
        assert result.lifecycle_state == "deprecated"

    def test_get_model_not_found(self) -> None:
        reg = ModelRegistry()
        assert reg.get_model("nonexistent") is None


class TestRoutes:
    def test_register_and_get_route(self) -> None:
        reg = ModelRegistry()
        route = ModelRoute(
            id="default",
            candidates=[ModelRouteCandidate(model_id="gpt-4", weight=1.0)],
        )
        reg.register_route(route)
        result = reg.get_route("default")
        assert result is not None
        assert result.id == "default"

    def test_register_route_duplicate_raises(self) -> None:
        reg = ModelRegistry()
        route = ModelRoute(id="default")
        reg.register_route(route)
        with pytest.raises(ValueError, match="already registered"):
            reg.register_route(route)

    def test_get_route_not_found(self) -> None:
        reg = ModelRegistry()
        assert reg.get_route("nonexistent") is None


class TestResolveRouteOrModel:
    def test_direct_model_id(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("openai", "OpenAI", ["gpt-4"]))
        ctx = _make_ctx()
        result = reg.resolve_route_or_model("gpt-4", ctx)
        assert result.descriptor.id == "gpt-4"
        assert result.route_id is None

    def test_route_with_single_candidate(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("openai", "OpenAI", ["gpt-4"]))
        reg.register_route(
            ModelRoute(
                id="default",
                candidates=[ModelRouteCandidate(model_id="gpt-4", weight=1.0)],
            )
        )
        ctx = _make_ctx()
        result = reg.resolve_route_or_model("default", ctx)
        assert result.descriptor.id == "gpt-4"
        assert result.route_id == "default"
        assert result.fallback_used is False

    def test_route_with_fallback(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("openai", "OpenAI", ["gpt-4", "gpt-3.5"]))
        # First candidate is disabled, should fall back to second
        reg.register_model(
            ModelDescriptor(
                id="gpt-4",
                provider_id="openai",
                lifecycle_state="disabled",
            )
        )
        reg.register_route(
            ModelRoute(
                id="default",
                candidates=[
                    ModelRouteCandidate(model_id="gpt-4", weight=2.0),
                    ModelRouteCandidate(model_id="gpt-3.5", weight=1.0),
                ],
            )
        )
        ctx = _make_ctx()
        result = reg.resolve_route_or_model("default", ctx)
        assert result.descriptor.id == "gpt-3.5"
        assert result.fallback_used is True

    def test_route_all_candidates_blocked(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("openai", "OpenAI", ["gpt-4"]))
        reg.register_model(
            ModelDescriptor(id="gpt-4", provider_id="openai", lifecycle_state="disabled")
        )
        reg.register_route(
            ModelRoute(
                id="default",
                candidates=[ModelRouteCandidate(model_id="gpt-4", weight=1.0)],
            )
        )
        ctx = _make_ctx()
        with pytest.raises(ModelNotSupportedError):
            reg.resolve_route_or_model("default", ctx)

    def test_direct_model_not_allowed(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("openai", "OpenAI", ["gpt-4"]))
        reg.register_model(
            ModelDescriptor(
                id="gpt-4",
                provider_id="openai",
                lifecycle_state="approved",
                allowed_purposes=["analysis"],
            )
        )
        ctx = _make_ctx(purpose="chat")
        with pytest.raises(ValueError, match="not allowed"):
            reg.resolve_route_or_model("gpt-4", ctx)

    def test_data_class_filtering(self) -> None:
        reg = ModelRegistry()
        reg.register(FakeProvider("openai", "OpenAI", ["gpt-4"]))
        reg.register_model(
            ModelDescriptor(
                id="gpt-4",
                provider_id="openai",
                lifecycle_state="approved",
                max_data_class="internal",
            )
        )
        ctx = _make_ctx()
        with pytest.raises(ValueError, match="not allowed"):
            reg.resolve_route_or_model("gpt-4", ctx, data_class="restricted")


class TestDefaultRegistry:
    def test_get_and_reset(self) -> None:
        reset_default_registry()
        reg1 = get_default_registry()
        reg2 = get_default_registry()
        assert reg1 is reg2
        reset_default_registry()
        reg3 = get_default_registry()
        assert reg3 is not reg1


class TestProviderErrors:
    def test_provider_not_found_error_message(self) -> None:
        err = ProviderNotFoundError("openai", ["azure", "bedrock"])
        assert "openai" in str(err)
        assert "azure" in str(err)
        assert err.provider_id == "openai"
        assert err.available_providers == ["azure", "bedrock"]

    def test_provider_not_found_error_empty(self) -> None:
        err = ProviderNotFoundError("openai", [])
        assert "none" in str(err)

    def test_provider_already_registered_error(self) -> None:
        err = ProviderAlreadyRegisteredError("openai")
        assert "openai" in str(err)
        assert err.provider_id == "openai"

    def test_model_not_supported_error(self) -> None:
        err = ModelNotSupportedError("gpt-5", ["gpt-4", "gpt-3.5"])
        assert "gpt-5" in str(err)
        assert err.model == "gpt-5"
        assert err.available_models == ["gpt-4", "gpt-3.5"]
