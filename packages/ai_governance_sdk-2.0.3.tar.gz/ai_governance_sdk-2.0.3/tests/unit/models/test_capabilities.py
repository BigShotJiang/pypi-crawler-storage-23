"""Tests for arelis.models.capabilities."""

from __future__ import annotations

from typing import get_args

from arelis.models.capabilities import ModelCapability, ModelDescriptor
from arelis.models.types import ModelDescriptor as TypesModelDescriptor


class TestModelCapability:
    def test_all_capabilities_are_strings(self) -> None:
        caps = get_args(ModelCapability)
        assert len(caps) > 0
        for cap in caps:
            assert isinstance(cap, str)

    def test_expected_capabilities_present(self) -> None:
        caps = get_args(ModelCapability)
        expected = [
            "text_generation",
            "streaming",
            "tool_use",
            "token_estimation",
            "image_generation",
            "audio_generation",
            "video_generation",
            "image_to_text",
            "audio_to_text",
            "video_to_text",
        ]
        for exp in expected:
            assert exp in caps, f"Expected capability {exp} not found"


class TestModelDescriptorReExport:
    def test_re_exported_from_capabilities(self) -> None:
        # ModelDescriptor is re-exported from capabilities for convenience
        assert ModelDescriptor is TypesModelDescriptor

    def test_descriptor_creation(self) -> None:
        d = ModelDescriptor(id="m1", provider_id="p1", lifecycle_state="approved")
        assert d.id == "m1"
