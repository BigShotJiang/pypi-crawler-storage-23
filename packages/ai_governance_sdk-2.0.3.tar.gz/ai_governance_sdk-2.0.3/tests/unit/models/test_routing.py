"""Tests for arelis.models.routing."""

from __future__ import annotations

from arelis.models.routing import DATA_CLASS_RANK, data_class_allowed, is_descriptor_allowed
from arelis.models.types import ModelDescriptor, ModelRouteCandidate


class TestDataClassRank:
    def test_ranking_order(self) -> None:
        assert DATA_CLASS_RANK["public"] < DATA_CLASS_RANK["internal"]
        assert DATA_CLASS_RANK["internal"] < DATA_CLASS_RANK["confidential"]
        assert DATA_CLASS_RANK["confidential"] < DATA_CLASS_RANK["restricted"]

    def test_all_data_classes_present(self) -> None:
        expected = {"public", "internal", "confidential", "restricted"}
        assert set(DATA_CLASS_RANK.keys()) == expected


class TestDataClassAllowed:
    def test_both_none(self) -> None:
        assert data_class_allowed(None, None) is True

    def test_input_none(self) -> None:
        assert data_class_allowed(None, "confidential") is True

    def test_max_none(self) -> None:
        assert data_class_allowed("restricted", None) is True

    def test_equal_classes(self) -> None:
        assert data_class_allowed("internal", "internal") is True

    def test_input_lower_than_max(self) -> None:
        assert data_class_allowed("public", "confidential") is True

    def test_input_higher_than_max(self) -> None:
        assert data_class_allowed("restricted", "internal") is False

    def test_public_to_public(self) -> None:
        assert data_class_allowed("public", "public") is True

    def test_restricted_to_restricted(self) -> None:
        assert data_class_allowed("restricted", "restricted") is True


class TestIsDescriptorAllowed:
    def _make_descriptor(
        self,
        lifecycle_state: str = "approved",
        allowed_purposes: list[str] | None = None,
        max_data_class: str | None = None,
        required_residency: str | None = None,
    ) -> ModelDescriptor:
        return ModelDescriptor(
            id="m1",
            provider_id="p1",
            lifecycle_state=lifecycle_state,  # type: ignore[arg-type]
            allowed_purposes=allowed_purposes,
            max_data_class=max_data_class,  # type: ignore[arg-type]
            required_residency=required_residency,  # type: ignore[arg-type]
        )

    def test_disabled_model_not_allowed(self) -> None:
        d = self._make_descriptor(lifecycle_state="disabled")
        assert is_descriptor_allowed(d, "test") is False

    def test_approved_model_allowed(self) -> None:
        d = self._make_descriptor(lifecycle_state="approved")
        assert is_descriptor_allowed(d, "test") is True

    def test_restricted_model_allowed(self) -> None:
        d = self._make_descriptor(lifecycle_state="restricted")
        assert is_descriptor_allowed(d, "test") is True

    def test_purpose_allowed(self) -> None:
        d = self._make_descriptor(allowed_purposes=["analysis", "chat"])
        assert is_descriptor_allowed(d, "analysis") is True

    def test_purpose_not_allowed(self) -> None:
        d = self._make_descriptor(allowed_purposes=["analysis"])
        assert is_descriptor_allowed(d, "chat") is False

    def test_no_purpose_restriction(self) -> None:
        d = self._make_descriptor(allowed_purposes=None)
        assert is_descriptor_allowed(d, "anything") is True

    def test_data_class_allowed(self) -> None:
        d = self._make_descriptor(max_data_class="confidential")
        assert is_descriptor_allowed(d, "test", data_class="internal") is True

    def test_data_class_not_allowed(self) -> None:
        d = self._make_descriptor(max_data_class="internal")
        assert is_descriptor_allowed(d, "test", data_class="restricted") is False

    def test_residency_match(self) -> None:
        d = self._make_descriptor(required_residency="EU")
        assert is_descriptor_allowed(d, "test", required_residency="EU") is True

    def test_residency_mismatch(self) -> None:
        d = self._make_descriptor(required_residency="EU")
        assert is_descriptor_allowed(d, "test", required_residency="US") is False

    def test_no_residency_requirement(self) -> None:
        d = self._make_descriptor(required_residency=None)
        assert is_descriptor_allowed(d, "test", required_residency="US") is True

    def test_candidate_overrides_data_class(self) -> None:
        d = self._make_descriptor(max_data_class="public")
        candidate = ModelRouteCandidate(model_id="m1", max_data_class="restricted")
        assert (
            is_descriptor_allowed(d, "test", data_class="restricted", candidate=candidate) is True
        )

    def test_candidate_overrides_residency(self) -> None:
        d = self._make_descriptor(required_residency="EU")
        candidate = ModelRouteCandidate(model_id="m1", required_residency="US")
        assert (
            is_descriptor_allowed(d, "test", required_residency="US", candidate=candidate) is True
        )

    def test_candidate_without_override_falls_back_to_descriptor(self) -> None:
        d = self._make_descriptor(max_data_class="internal")
        candidate = ModelRouteCandidate(model_id="m1")  # no override
        assert (
            is_descriptor_allowed(d, "test", data_class="restricted", candidate=candidate) is False
        )
