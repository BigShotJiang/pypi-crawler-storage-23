"""Tests for arelis.models.types."""

from __future__ import annotations

from datetime import datetime, timezone

from arelis.core.types import ActorRef, GovernanceContext, OrgRef
from arelis.models.types import (
    Base64MediaInput,
    BinaryMediaInput,
    ContentPart,
    GenerateInput,
    GenerateOptions,
    GenerateStreamInput,
    GroundingInput,
    GroundingOptions,
    ImageContentPart,
    ImageGenerationResponse,
    JsonSchemaOutput,
    MediaResponseBase,
    ModelConfig,
    ModelDescriptor,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelRoute,
    ModelRouteCandidate,
    ModelUsage,
    PromptTemplateRef,
    StreamChunk,
    StreamOptions,
    TextContentPart,
    TextResponseBase,
    ToolCall,
    ToolCallDelta,
    ToolDefinition,
    ToolResultContentPart,
    ToolUseContentPart,
    ValidatorOutput,
    ValidatorResult,
    VideoGenerationResponse,
)

# ---------------------------------------------------------------------------
# Content parts
# ---------------------------------------------------------------------------


class TestTextContentPart:
    def test_creation(self) -> None:
        part = TextContentPart(text="hello")
        assert part.text == "hello"
        assert part.type == "text"

    def test_type_default(self) -> None:
        part = TextContentPart(text="x")
        assert part.type == "text"


class TestImageContentPart:
    def test_creation(self) -> None:
        part = ImageContentPart(data="base64data", mime_type="image/png")
        assert part.data == "base64data"
        assert part.mime_type == "image/png"
        assert part.type == "image"


class TestToolUseContentPart:
    def test_creation(self) -> None:
        part = ToolUseContentPart(id="call_1", name="search", input={"q": "test"})
        assert part.id == "call_1"
        assert part.name == "search"
        assert part.input == {"q": "test"}
        assert part.type == "tool_use"


class TestToolResultContentPart:
    def test_creation(self) -> None:
        part = ToolResultContentPart(id="call_1", content="result")
        assert part.id == "call_1"
        assert part.content == "result"
        assert part.is_error is None
        assert part.type == "tool_result"

    def test_with_error(self) -> None:
        part = ToolResultContentPart(id="call_1", content="err", is_error=True)
        assert part.is_error is True


# ---------------------------------------------------------------------------
# ModelMessage
# ---------------------------------------------------------------------------


class TestModelMessage:
    def test_string_content(self) -> None:
        msg = ModelMessage(role="user", content="hi")
        assert msg.role == "user"
        assert msg.content == "hi"
        assert msg.name is None

    def test_multimodal_content(self) -> None:
        parts: list[ContentPart] = [
            TextContentPart(text="look"),
            ImageContentPart(data="abc", mime_type="image/jpeg"),
        ]
        msg = ModelMessage(role="user", content=parts, name="alice")
        assert len(msg.content) == 2  # type: ignore[arg-type]
        assert msg.name == "alice"


# ---------------------------------------------------------------------------
# ModelConfig
# ---------------------------------------------------------------------------


class TestModelConfig:
    def test_defaults(self) -> None:
        cfg = ModelConfig()
        assert cfg.max_tokens is None
        assert cfg.temperature is None
        assert cfg.top_p is None
        assert cfg.stop is None
        assert cfg.frequency_penalty is None
        assert cfg.presence_penalty is None
        assert cfg.seed is None
        assert cfg.provider_options is None

    def test_with_values(self) -> None:
        cfg = ModelConfig(max_tokens=100, temperature=0.7, stop=["END"])
        assert cfg.max_tokens == 100
        assert cfg.temperature == 0.7
        assert cfg.stop == ["END"]


# ---------------------------------------------------------------------------
# Tool types
# ---------------------------------------------------------------------------


class TestToolDefinition:
    def test_creation(self) -> None:
        td = ToolDefinition(
            name="search",
            description="Search the web",
            parameters={"type": "object", "properties": {"q": {"type": "string"}}},
        )
        assert td.name == "search"
        assert td.description == "Search the web"


class TestToolCall:
    def test_creation(self) -> None:
        tc = ToolCall(id="tc_1", name="search", arguments={"q": "hello"})
        assert tc.id == "tc_1"
        assert tc.name == "search"


class TestToolCallDelta:
    def test_defaults(self) -> None:
        delta = ToolCallDelta(index=0)
        assert delta.index == 0
        assert delta.id is None
        assert delta.name is None
        assert delta.arguments is None


# ---------------------------------------------------------------------------
# ModelRequest
# ---------------------------------------------------------------------------


class TestModelRequest:
    def test_minimal(self) -> None:
        req = ModelRequest(
            model="gpt-4",
            messages=[ModelMessage(role="user", content="hi")],
        )
        assert req.model == "gpt-4"
        assert len(req.messages) == 1
        assert req.system_prompt is None
        assert req.config is None
        assert req.tools is None
        assert req.context is None
        assert req.metadata is None

    def test_with_all_fields(self) -> None:
        ctx = GovernanceContext(
            org=OrgRef(id="org1"),
            actor=ActorRef(type="human", id="user1"),
            purpose="testing",
            environment="dev",
        )
        req = ModelRequest(
            model="gpt-4",
            messages=[ModelMessage(role="user", content="hi")],
            system_prompt="You are a helper",
            config=ModelConfig(max_tokens=500),
            tools=[ToolDefinition(name="t", description="d", parameters={})],
            context=ctx,
            metadata={"key": "value"},
        )
        assert req.system_prompt == "You are a helper"
        assert req.config is not None
        assert req.tools is not None
        assert len(req.tools) == 1
        assert req.context is not None
        assert req.metadata == {"key": "value"}


# ---------------------------------------------------------------------------
# ModelUsage
# ---------------------------------------------------------------------------


class TestModelUsage:
    def test_defaults(self) -> None:
        usage = ModelUsage()
        assert usage.prompt_tokens is None
        assert usage.completion_tokens is None
        assert usage.cached_tokens is None
        # inherited from UsageInfo
        assert usage.input_tokens is None
        assert usage.output_tokens is None
        assert usage.total_tokens is None
        assert usage.cost_usd is None

    def test_with_values(self) -> None:
        usage = ModelUsage(
            prompt_tokens=100,
            completion_tokens=50,
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
        )
        assert usage.prompt_tokens == 100
        assert usage.completion_tokens == 50
        assert usage.total_tokens == 150


# ---------------------------------------------------------------------------
# ModelResponse
# ---------------------------------------------------------------------------


class TestModelResponse:
    def test_creation(self) -> None:
        now = datetime.now(timezone.utc)
        resp = ModelResponse(
            id="resp_1",
            model="gpt-4",
            content="Hello!",
            finish_reason="stop",
            usage=ModelUsage(prompt_tokens=10, completion_tokens=5),
            created_at=now,
        )
        assert resp.id == "resp_1"
        assert resp.model == "gpt-4"
        assert resp.content == "Hello!"
        assert resp.finish_reason == "stop"
        assert resp.tool_calls is None
        assert resp.provider_metadata is None

    def test_with_tool_calls(self) -> None:
        now = datetime.now(timezone.utc)
        resp = ModelResponse(
            id="resp_2",
            model="gpt-4",
            content="",
            finish_reason="tool_use",
            usage=ModelUsage(),
            created_at=now,
            tool_calls=[ToolCall(id="tc_1", name="search", arguments={"q": "hi"})],
        )
        assert resp.tool_calls is not None
        assert len(resp.tool_calls) == 1


# ---------------------------------------------------------------------------
# StreamChunk
# ---------------------------------------------------------------------------


class TestStreamChunk:
    def test_content_chunk(self) -> None:
        chunk = StreamChunk(type="content", content="Hello")
        assert chunk.type == "content"
        assert chunk.content == "Hello"
        assert chunk.tool_call is None

    def test_tool_call_chunk(self) -> None:
        delta = ToolCallDelta(index=0, id="tc_1", name="search")
        chunk = StreamChunk(type="tool_call", tool_call=delta)
        assert chunk.type == "tool_call"
        assert chunk.tool_call is not None

    def test_usage_chunk(self) -> None:
        chunk = StreamChunk(type="usage", usage=ModelUsage(prompt_tokens=10))
        assert chunk.type == "usage"
        assert chunk.usage is not None

    def test_done_chunk(self) -> None:
        chunk = StreamChunk(type="done", finish_reason="stop")
        assert chunk.type == "done"
        assert chunk.finish_reason == "stop"


# ---------------------------------------------------------------------------
# GenerateInput / GenerateStreamInput
# ---------------------------------------------------------------------------


class TestGenerateInput:
    def test_minimal(self) -> None:
        ctx = GovernanceContext(
            org=OrgRef(id="org1"),
            actor=ActorRef(type="human", id="user1"),
            purpose="test",
            environment="dev",
        )
        req = ModelRequest(
            model="gpt-4",
            messages=[ModelMessage(role="user", content="hi")],
        )
        gi = GenerateInput(model="gpt-4", request=req, context=ctx)
        assert gi.model == "gpt-4"
        assert gi.options is None
        assert gi.grounding is None
        assert gi.data_class is None

    def test_with_options(self) -> None:
        ctx = GovernanceContext(
            org=OrgRef(id="org1"),
            actor=ActorRef(type="human", id="user1"),
            purpose="test",
            environment="dev",
        )
        req = ModelRequest(
            model="gpt-4",
            messages=[ModelMessage(role="user", content="hi")],
        )
        gi = GenerateInput(
            model="gpt-4",
            request=req,
            context=ctx,
            options=GenerateOptions(timeout=5000),
            data_class="confidential",
            grounding=GroundingInput(kb_ids=["kb1"], top_k=5),
            prompt_template=PromptTemplateRef(id="tmpl1"),
            output_schema=JsonSchemaOutput(schema={"type": "object"}),
            output_validation_mode="block",
        )
        assert gi.options is not None
        assert gi.options.timeout == 5000
        assert gi.data_class == "confidential"
        assert gi.grounding is not None
        assert gi.grounding.kb_ids == ["kb1"]


class TestGenerateStreamInput:
    def test_inherits_generate_input(self) -> None:
        ctx = GovernanceContext(
            org=OrgRef(id="org1"),
            actor=ActorRef(type="human", id="user1"),
            purpose="test",
            environment="dev",
        )
        req = ModelRequest(
            model="gpt-4",
            messages=[ModelMessage(role="user", content="hi")],
        )
        gsi = GenerateStreamInput(
            model="gpt-4",
            request=req,
            context=ctx,
            stream_options=StreamOptions(emit_chunks=True),
        )
        assert gsi.stream_options is not None
        assert gsi.stream_options.emit_chunks is True


# ---------------------------------------------------------------------------
# Model descriptor and route types
# ---------------------------------------------------------------------------


class TestModelDescriptor:
    def test_minimal(self) -> None:
        d = ModelDescriptor(id="gpt-4", provider_id="openai", lifecycle_state="approved")
        assert d.id == "gpt-4"
        assert d.provider_id == "openai"
        assert d.lifecycle_state == "approved"
        assert d.max_data_class is None
        assert d.allowed_purposes is None

    def test_full(self) -> None:
        d = ModelDescriptor(
            id="gpt-4",
            provider_id="openai",
            lifecycle_state="restricted",
            version="0613",
            max_data_class="confidential",
            required_residency="EU",
            allowed_purposes=["analysis", "chat"],
        )
        assert d.max_data_class == "confidential"
        assert d.required_residency == "EU"
        assert d.allowed_purposes == ["analysis", "chat"]


class TestModelRoute:
    def test_empty_candidates(self) -> None:
        route = ModelRoute(id="default")
        assert route.id == "default"
        assert route.candidates == []

    def test_with_candidates(self) -> None:
        route = ModelRoute(
            id="default",
            candidates=[
                ModelRouteCandidate(model_id="gpt-4", weight=1.0),
                ModelRouteCandidate(model_id="gpt-3.5", weight=0.5),
            ],
        )
        assert len(route.candidates) == 2


# ---------------------------------------------------------------------------
# Media types
# ---------------------------------------------------------------------------


class TestMediaTypes:
    def test_binary_media_input(self) -> None:
        m = BinaryMediaInput(data=b"\x89PNG", mime_type="image/png")
        assert m.data == b"\x89PNG"
        assert m.mime_type == "image/png"

    def test_base64_media_input(self) -> None:
        m = Base64MediaInput(base64="iVBOR...", mime_type="image/png")
        assert m.base64 == "iVBOR..."

    def test_media_response_base(self) -> None:
        now = datetime.now(timezone.utc)
        r = MediaResponseBase(id="img_1", data=b"raw", mime_type="image/png", created_at=now)
        assert r.id == "img_1"
        assert r.model is None
        assert r.url is None

    def test_image_generation_response(self) -> None:
        now = datetime.now(timezone.utc)
        r = ImageGenerationResponse(
            id="img_1", data=b"raw", mime_type="image/png", created_at=now, width=512, height=512
        )
        assert r.width == 512
        assert r.height == 512

    def test_text_response_base(self) -> None:
        now = datetime.now(timezone.utc)
        r = TextResponseBase(id="txt_1", text="description of image", created_at=now)
        assert r.text == "description of image"

    def test_video_generation_response(self) -> None:
        now = datetime.now(timezone.utc)
        r = VideoGenerationResponse(
            id="vid_1",
            data=b"raw",
            mime_type="video/mp4",
            created_at=now,
            duration_ms=5000,
            frame_rate=30.0,
        )
        assert r.duration_ms == 5000
        assert r.frame_rate == 30.0


# ---------------------------------------------------------------------------
# Output schema types
# ---------------------------------------------------------------------------


class TestOutputSchemaTypes:
    def test_json_schema_output(self) -> None:
        o = JsonSchemaOutput(schema={"type": "object"})
        assert o.type == "json_schema"
        assert o.schema == {"type": "object"}

    def test_validator_output(self) -> None:
        def my_validator(val: object) -> ValidatorResult:
            return ValidatorResult(success=True)

        o = ValidatorOutput(validator=my_validator)
        assert o.type == "validator"
        result = o.validator("test")
        assert result.success is True

    def test_validator_result_error(self) -> None:
        r = ValidatorResult(success=False, error="bad format")
        assert r.success is False
        assert r.error == "bad format"


# ---------------------------------------------------------------------------
# Grounding
# ---------------------------------------------------------------------------


class TestGroundingInput:
    def test_creation(self) -> None:
        g = GroundingInput(kb_ids=["kb1", "kb2"], query="find docs", top_k=10)
        assert g.kb_ids == ["kb1", "kb2"]
        assert g.query == "find docs"
        assert g.top_k == 10
        assert g.options is None

    def test_with_options(self) -> None:
        g = GroundingInput(
            kb_ids=["kb1"],
            options=GroundingOptions(metadata={"source": "test"}),
        )
        assert g.options is not None
        assert g.options.metadata == {"source": "test"}
