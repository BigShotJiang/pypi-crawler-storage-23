"""Unit tests for arelis.compliance.types module."""

from __future__ import annotations

import pytest

from arelis.compliance.types import (
    CausalGraphCommitment,
    ComplianceArtifact,
    ComplianceArtifactStore,
    DisclosureProof,
    DisclosureRule,
    InMemoryComplianceArtifactStore,
    LayerProof,
    ProofVerificationResult,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_commitment(run_id: str = "run_abc") -> CausalGraphCommitment:
    return CausalGraphCommitment(
        run_id=run_id,
        root="deadbeef",
        algorithm="sha256",
        created_at="2026-01-01T00:00:00Z",
        node_count=3,
        edge_count=2,
    )


def _make_proof() -> DisclosureProof:
    return DisclosureProof(
        schema_version="arelis.audit.compliance.proof.composed.v2",
        commitment_root="deadbeef",
        algorithm="sha256",
    )


def _make_artifact(
    artifact_id: str = "art-1",
    run_id: str = "run_abc",
) -> ComplianceArtifact:
    return ComplianceArtifact(
        id=artifact_id,
        run_id=run_id,
        created_at="2026-01-01T00:00:00Z",
        commitment=_make_commitment(run_id=run_id),
        proof=_make_proof(),
    )


# ---------------------------------------------------------------------------
# ComplianceArtifact dataclass construction
# ---------------------------------------------------------------------------


class TestComplianceArtifact:
    """Tests for ComplianceArtifact dataclass."""

    def test_basic_construction(self) -> None:
        artifact = _make_artifact()
        assert artifact.id == "art-1"
        assert artifact.run_id == "run_abc"
        assert artifact.created_at == "2026-01-01T00:00:00Z"
        assert artifact.commitment.root == "deadbeef"
        assert artifact.proof.schema_version == "arelis.audit.compliance.proof.composed.v2"

    def test_default_fields(self) -> None:
        artifact = _make_artifact()
        assert artifact.disclosure_rule_ids == []
        assert artifact.artifact_schema is None
        assert artifact.context is None
        assert artifact.policy_snapshot_hash is None

    def test_optional_fields(self) -> None:
        artifact = ComplianceArtifact(
            id="art-2",
            run_id="run_xyz",
            created_at="2026-01-01T00:00:00Z",
            commitment=_make_commitment(run_id="run_xyz"),
            proof=_make_proof(),
            disclosure_rule_ids=["rule-1", "rule-2"],
            artifact_schema="arelis.audit.compliance.composed.v2",
            context={"tenant": "acme"},
            policy_snapshot_hash="abc123",
        )
        assert artifact.disclosure_rule_ids == ["rule-1", "rule-2"]
        assert artifact.artifact_schema == "arelis.audit.compliance.composed.v2"
        assert artifact.context == {"tenant": "acme"}
        assert artifact.policy_snapshot_hash == "abc123"

    def test_default_factory_not_shared(self) -> None:
        """Ensure default list factory creates independent lists."""
        a = _make_artifact(artifact_id="a1")
        b = _make_artifact(artifact_id="a2")
        a.disclosure_rule_ids.append("rule-x")
        assert "rule-x" not in b.disclosure_rule_ids


# ---------------------------------------------------------------------------
# DisclosureProof dataclass
# ---------------------------------------------------------------------------


class TestDisclosureProof:
    """Tests for DisclosureProof dataclass."""

    def test_required_fields(self) -> None:
        proof = DisclosureProof(
            schema_version="v1",
            commitment_root="root123",
        )
        assert proof.schema_version == "v1"
        assert proof.commitment_root == "root123"
        assert proof.algorithm == "sha256"

    def test_optional_fields(self) -> None:
        proof = DisclosureProof(
            schema_version="v2",
            commitment_root="root456",
            algorithm="sha512",
            rule_ids=["r1"],
            disclosed_fields=["field.a"],
            layers=[LayerProof(layer="infra", digest="d1")],
            narrowing_proof={"id": "n1"},
            lineage_proof={"id": "l1"},
        )
        assert proof.algorithm == "sha512"
        assert proof.rule_ids == ["r1"]
        assert proof.disclosed_fields == ["field.a"]
        assert proof.layers is not None and len(proof.layers) == 1
        assert proof.narrowing_proof == {"id": "n1"}
        assert proof.lineage_proof == {"id": "l1"}

    def test_defaults_are_none(self) -> None:
        proof = _make_proof()
        assert proof.rule_ids is None
        assert proof.disclosed_fields is None
        assert proof.layers is None
        assert proof.narrowing_proof is None
        assert proof.lineage_proof is None


# ---------------------------------------------------------------------------
# DisclosureRule dataclass
# ---------------------------------------------------------------------------


class TestDisclosureRule:
    """Tests for DisclosureRule dataclass."""

    def test_construction(self) -> None:
        rule = DisclosureRule(id="rule-1", description="Test rule", fields=["a", "b"])
        assert rule.id == "rule-1"
        assert rule.description == "Test rule"
        assert rule.fields == ["a", "b"]

    def test_defaults(self) -> None:
        rule = DisclosureRule(id="rule-2")
        assert rule.description is None
        assert rule.fields is None


# ---------------------------------------------------------------------------
# LayerProof dataclass
# ---------------------------------------------------------------------------


class TestLayerProof:
    """Tests for LayerProof dataclass."""

    def test_construction(self) -> None:
        lp = LayerProof(layer="infra", digest="abc")
        assert lp.layer == "infra"
        assert lp.digest == "abc"
        assert lp.algorithm == "sha256"

    def test_event_ids_default(self) -> None:
        lp = LayerProof(layer="tools", digest="xyz")
        assert lp.event_ids is None


# ---------------------------------------------------------------------------
# CausalGraphCommitment dataclass
# ---------------------------------------------------------------------------


class TestCausalGraphCommitment:
    """Tests for CausalGraphCommitment dataclass."""

    def test_construction(self) -> None:
        c = _make_commitment()
        assert c.run_id == "run_abc"
        assert c.root == "deadbeef"
        assert c.algorithm == "sha256"
        assert c.node_count == 3
        assert c.edge_count == 2
        assert c.signer_id is None
        assert c.signature is None

    def test_signed_commitment(self) -> None:
        c = CausalGraphCommitment(
            run_id="run_1",
            root="root_hash",
            algorithm="sha256",
            created_at="2026-01-01T00:00:00Z",
            node_count=1,
            edge_count=0,
            signer_id="signer-1",
            signature="sig-abc",
        )
        assert c.signer_id == "signer-1"
        assert c.signature == "sig-abc"


# ---------------------------------------------------------------------------
# ProofVerificationResult dataclass
# ---------------------------------------------------------------------------


class TestProofVerificationResult:
    """Tests for ProofVerificationResult dataclass."""

    def test_valid_result(self) -> None:
        r = ProofVerificationResult(valid=True)
        assert r.valid is True
        assert r.reason is None
        assert r.reason_code is None

    def test_invalid_result(self) -> None:
        r = ProofVerificationResult(
            valid=False,
            reason="Bad hash",
            reason_code="hash_mismatch",
            reason_codes=["hash_mismatch", "snapshot_mismatch"],
            failed_layer="inference",
        )
        assert r.valid is False
        assert r.reason == "Bad hash"
        assert r.reason_code == "hash_mismatch"
        assert r.reason_codes == ["hash_mismatch", "snapshot_mismatch"]
        assert r.failed_layer == "inference"


# ---------------------------------------------------------------------------
# InMemoryComplianceArtifactStore
# ---------------------------------------------------------------------------


class TestInMemoryComplianceArtifactStore:
    """Tests for InMemoryComplianceArtifactStore."""

    @pytest.mark.asyncio
    async def test_save_and_get(self) -> None:
        store = InMemoryComplianceArtifactStore()
        artifact = _make_artifact()
        await store.save(artifact)

        result = await store.get("run_abc", "art-1")
        assert result is not None
        assert result.id == "art-1"

    @pytest.mark.asyncio
    async def test_get_returns_none_for_missing(self) -> None:
        store = InMemoryComplianceArtifactStore()
        assert await store.get("run_abc", "nonexistent") is None

    @pytest.mark.asyncio
    async def test_get_returns_none_for_wrong_run(self) -> None:
        store = InMemoryComplianceArtifactStore()
        await store.save(_make_artifact())
        assert await store.get("run_other", "art-1") is None

    @pytest.mark.asyncio
    async def test_list_empty(self) -> None:
        store = InMemoryComplianceArtifactStore()
        result = await store.list("run_abc")
        assert result == []

    @pytest.mark.asyncio
    async def test_list_returns_all_for_run(self) -> None:
        store = InMemoryComplianceArtifactStore()
        await store.save(_make_artifact(artifact_id="a1", run_id="run_abc"))
        await store.save(_make_artifact(artifact_id="a2", run_id="run_abc"))
        await store.save(_make_artifact(artifact_id="a3", run_id="run_other"))

        result = await store.list("run_abc")
        assert len(result) == 2
        ids = {a.id for a in result}
        assert ids == {"a1", "a2"}

    @pytest.mark.asyncio
    async def test_list_returns_copy(self) -> None:
        """Mutating the returned list should not affect the store."""
        store = InMemoryComplianceArtifactStore()
        await store.save(_make_artifact())
        result = await store.list("run_abc")
        result.clear()
        assert len(await store.list("run_abc")) == 1

    @pytest.mark.asyncio
    async def test_implements_protocol(self) -> None:
        store = InMemoryComplianceArtifactStore()
        assert isinstance(store, ComplianceArtifactStore)

    @pytest.mark.asyncio
    async def test_multiple_saves_same_artifact(self) -> None:
        """Saving the same artifact twice appends it (no dedup)."""
        store = InMemoryComplianceArtifactStore()
        artifact = _make_artifact()
        await store.save(artifact)
        await store.save(artifact)
        result = await store.list("run_abc")
        assert len(result) == 2
