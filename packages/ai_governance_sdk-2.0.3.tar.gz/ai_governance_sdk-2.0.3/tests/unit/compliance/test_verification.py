"""Unit tests for arelis.compliance.verification module."""

from __future__ import annotations

import pytest

from arelis.compliance.types import (
    CausalGraphCommitment,
    ComplianceArtifact,
    DisclosureProof,
    ProofVerificationResult,
)
from arelis.compliance.verification import (
    ComplianceVerifierOptions,
    verify_compliance_artifact,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_commitment(run_id: str = "run_abc", root: str = "deadbeef") -> CausalGraphCommitment:
    return CausalGraphCommitment(
        run_id=run_id,
        root=root,
        algorithm="sha256",
        created_at="2026-01-01T00:00:00Z",
        node_count=3,
        edge_count=2,
    )


def _make_proof(commitment_root: str = "deadbeef") -> DisclosureProof:
    return DisclosureProof(
        schema_version="arelis.audit.compliance.proof.composed.v2",
        commitment_root=commitment_root,
        algorithm="sha256",
    )


def _make_artifact(
    artifact_id: str = "art-1",
    run_id: str = "run_abc",
    commitment_root: str = "deadbeef",
    policy_snapshot_hash: str | None = None,
) -> ComplianceArtifact:
    return ComplianceArtifact(
        id=artifact_id,
        run_id=run_id,
        created_at="2026-01-01T00:00:00Z",
        commitment=_make_commitment(run_id=run_id, root=commitment_root),
        proof=_make_proof(commitment_root=commitment_root),
        policy_snapshot_hash=policy_snapshot_hash,
    )


# ---------------------------------------------------------------------------
# verify_compliance_artifact with valid artifact
# ---------------------------------------------------------------------------


class TestVerifyComplianceArtifactValid:
    """Tests for verify_compliance_artifact with structurally valid artifacts."""

    @pytest.mark.asyncio
    async def test_valid_artifact_default_provider(self) -> None:
        """A well-formed artifact passes default hash-based verification."""
        artifact = _make_artifact()
        result = await verify_compliance_artifact(artifact)
        assert result.valid is True
        assert result.reason is None

    @pytest.mark.asyncio
    async def test_valid_artifact_with_none_options(self) -> None:
        """Passing options=None is equivalent to default options."""
        artifact = _make_artifact()
        result = await verify_compliance_artifact(artifact, options=None)
        assert result.valid is True

    @pytest.mark.asyncio
    async def test_valid_artifact_with_empty_options(self) -> None:
        """Passing empty ComplianceVerifierOptions works."""
        artifact = _make_artifact()
        result = await verify_compliance_artifact(artifact, options=ComplianceVerifierOptions())
        assert result.valid is True

    @pytest.mark.asyncio
    async def test_valid_artifact_with_matching_policy_hash(self) -> None:
        """Artifact passes when policy snapshot hashes match."""
        artifact = _make_artifact(policy_snapshot_hash="hash-abc")
        result = await verify_compliance_artifact(
            artifact,
            options=ComplianceVerifierOptions(policy_snapshot_hash="hash-abc"),
        )
        assert result.valid is True


# ---------------------------------------------------------------------------
# verify_compliance_artifact with invalid artifact
# ---------------------------------------------------------------------------


class TestVerifyComplianceArtifactInvalid:
    """Tests for verify_compliance_artifact with invalid/tampered artifacts."""

    @pytest.mark.asyncio
    async def test_missing_commitment_root(self) -> None:
        """Artifact with empty commitment root is invalid."""
        artifact = _make_artifact()
        artifact.commitment.root = ""
        result = await verify_compliance_artifact(artifact)
        assert result.valid is False
        assert result.reason_code == "missing_commitment_root"

    @pytest.mark.asyncio
    async def test_missing_proof_commitment_root(self) -> None:
        """Artifact with empty proof commitment root is invalid."""
        artifact = _make_artifact()
        artifact.proof.commitment_root = ""
        result = await verify_compliance_artifact(artifact)
        assert result.valid is False
        assert result.reason_code == "missing_proof_commitment_root"

    @pytest.mark.asyncio
    async def test_policy_snapshot_hash_mismatch(self) -> None:
        """Mismatched policy snapshot hash causes failure."""
        artifact = _make_artifact(policy_snapshot_hash="hash-original")
        result = await verify_compliance_artifact(
            artifact,
            options=ComplianceVerifierOptions(policy_snapshot_hash="hash-tampered"),
        )
        assert result.valid is False
        assert result.reason_code == "snapshot_mismatch"

    @pytest.mark.asyncio
    async def test_policy_hash_in_options_only_passes(self) -> None:
        """When artifact has no policy hash but options does, verification passes.

        The default verifier only fails when both artifact and options have
        hashes and they differ.
        """
        artifact = _make_artifact(policy_snapshot_hash=None)
        result = await verify_compliance_artifact(
            artifact,
            options=ComplianceVerifierOptions(policy_snapshot_hash="hash-from-options"),
        )
        assert result.valid is True

    @pytest.mark.asyncio
    async def test_result_is_proof_verification_result(self) -> None:
        """Return type is always ProofVerificationResult."""
        artifact = _make_artifact()
        result = await verify_compliance_artifact(artifact)
        assert isinstance(result, ProofVerificationResult)
