"""Tests for arelis.data_sources.registry."""

from __future__ import annotations

import pytest

from arelis.data_sources.registry import (
    DataSourceRegistry,
    RegisteredDataSource,
    create_data_source_registry,
)
from arelis.data_sources.types import (
    DataSourceContext,
    DataSourceDescriptor,
    DataSourceQuery,
    DataSourceResult,
)

# ---------------------------------------------------------------------------
# Stub provider
# ---------------------------------------------------------------------------


class _StubProvider:
    """Minimal data source provider for testing."""

    def __init__(self, id: str = "stub") -> None:
        self._id = id
        self.last_query: DataSourceQuery | None = None

    @property
    def id(self) -> str:
        return self._id

    async def read(
        self,
        query: DataSourceQuery,
        context: DataSourceContext,
    ) -> DataSourceResult:
        self.last_query = query
        return DataSourceResult(records=[{"answer": 42}], total=1)


# ---------------------------------------------------------------------------
# DataSourceRegistry
# ---------------------------------------------------------------------------


class TestDataSourceRegistry:
    def test_register_and_get(self) -> None:
        registry = DataSourceRegistry()
        descriptor = DataSourceDescriptor(id="ds-1", provider="stub")
        provider = _StubProvider()
        registry.register(descriptor, provider)
        result = registry.get("ds-1")
        assert result is not None
        assert isinstance(result, RegisteredDataSource)
        assert result.descriptor.id == "ds-1"
        assert result.provider is provider
        assert result.registered_at  # non-empty

    def test_get_unknown_returns_none(self) -> None:
        registry = DataSourceRegistry()
        assert registry.get("nope") is None

    def test_register_raises_on_empty_id(self) -> None:
        registry = DataSourceRegistry()
        descriptor = DataSourceDescriptor(id="", provider="stub")
        with pytest.raises(ValueError, match="id is required"):
            registry.register(descriptor, _StubProvider())

    def test_register_overwrites_existing(self) -> None:
        registry = DataSourceRegistry()
        desc = DataSourceDescriptor(id="ds-1", provider="stub")
        p1 = _StubProvider("p1")
        p2 = _StubProvider("p2")
        registry.register(desc, p1)
        registry.register(desc, p2)
        result = registry.get("ds-1")
        assert result is not None
        assert result.provider is p2

    def test_list(self) -> None:
        registry = DataSourceRegistry()
        registry.register(DataSourceDescriptor(id="a", provider="s"), _StubProvider())
        registry.register(DataSourceDescriptor(id="b", provider="s"), _StubProvider())
        sources = registry.list()
        assert len(sources) == 2

    def test_list_empty(self) -> None:
        registry = DataSourceRegistry()
        assert registry.list() == []

    def test_clear(self) -> None:
        registry = DataSourceRegistry()
        registry.register(DataSourceDescriptor(id="x", provider="s"), _StubProvider())
        registry.clear()
        assert registry.list() == []
        assert registry.get("x") is None


# ---------------------------------------------------------------------------
# Read through provider
# ---------------------------------------------------------------------------


class TestDataSourceRegistryRead:
    @pytest.mark.asyncio
    async def test_read_through_provider(self) -> None:
        registry = DataSourceRegistry()
        provider = _StubProvider()
        registry.register(DataSourceDescriptor(id="ds-1", provider="stub"), provider)
        registered = registry.get("ds-1")
        assert registered is not None
        query = DataSourceQuery(source_id="ds-1", query="SELECT 1")
        ctx = DataSourceContext(run_id="run_1", governance=None)
        result = await registered.provider.read(query, ctx)
        assert result.total == 1
        assert result.records == [{"answer": 42}]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestCreateDataSourceRegistry:
    def test_returns_instance(self) -> None:
        registry = create_data_source_registry()
        assert isinstance(registry, DataSourceRegistry)
