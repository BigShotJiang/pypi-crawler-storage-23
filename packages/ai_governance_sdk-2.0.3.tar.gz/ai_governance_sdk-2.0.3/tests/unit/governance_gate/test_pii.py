"""Tests for arelis.governance_gate.pii."""

from __future__ import annotations

import re

from arelis.governance_gate.pii import scan_prompt_for_pii
from arelis.governance_gate.types import ScanPromptForPiiOptions
from arelis.policy.redactor import RedactionPattern, RedactorConfig

# ---------------------------------------------------------------------------
# scan_prompt_for_pii — emails
# ---------------------------------------------------------------------------


class TestScanEmails:
    def test_detects_email(self) -> None:
        result = scan_prompt_for_pii("Contact us at user@example.com for info.")
        assert result.has_pii is True
        assert len(result.findings) >= 1
        finding = next(f for f in result.findings if f.type == "email")
        assert finding.original == "user@example.com"

    def test_detects_multiple_emails(self) -> None:
        result = scan_prompt_for_pii("a@b.com and c@d.org")
        emails = [f for f in result.findings if f.type == "email"]
        assert len(emails) == 2

    def test_no_email_detection_when_disabled(self) -> None:
        opts = ScanPromptForPiiOptions(
            redactor_config=RedactorConfig(
                detect_emails=False,
                detect_phones=False,
                detect_api_keys=False,
            )
        )
        result = scan_prompt_for_pii("user@example.com", opts)
        assert result.has_pii is False


# ---------------------------------------------------------------------------
# scan_prompt_for_pii — phones
# ---------------------------------------------------------------------------


class TestScanPhones:
    def test_detects_phone_number(self) -> None:
        result = scan_prompt_for_pii("Call 555-123-4567 today.")
        assert result.has_pii is True
        phones = [f for f in result.findings if f.type == "phone"]
        assert len(phones) >= 1

    def test_detects_phone_with_country_code(self) -> None:
        result = scan_prompt_for_pii("Call +1-555-123-4567.")
        phones = [f for f in result.findings if f.type == "phone"]
        assert len(phones) >= 1


# ---------------------------------------------------------------------------
# scan_prompt_for_pii — SSNs
# ---------------------------------------------------------------------------


class TestScanSSNs:
    def test_detects_ssn(self) -> None:
        result = scan_prompt_for_pii(
            "SSN: 123-45-6789",
            ScanPromptForPiiOptions(
                redactor_config=RedactorConfig(
                    detect_emails=False,
                    detect_phones=False,
                    detect_api_keys=False,
                    custom_patterns=[
                        RedactionPattern(
                            name="ssn",
                            pattern=re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
                            type="custom",
                        )
                    ],
                )
            ),
        )
        assert result.has_pii is True
        ssns = [f for f in result.findings if f.pattern == "ssn"]
        assert len(ssns) >= 1
        assert "123-45-6789" in ssns[0].original


# ---------------------------------------------------------------------------
# scan_prompt_for_pii — credit cards
# ---------------------------------------------------------------------------


class TestScanCreditCards:
    def test_detects_credit_card(self) -> None:
        result = scan_prompt_for_pii(
            "Card: 4111-1111-1111-1111",
            ScanPromptForPiiOptions(
                redactor_config=RedactorConfig(
                    detect_emails=False,
                    detect_phones=False,
                    detect_api_keys=False,
                    custom_patterns=[
                        RedactionPattern(
                            name="credit_card",
                            pattern=re.compile(r"\b(?:\d{4}[-.\s]?){3}\d{4}\b"),
                            type="custom",
                        )
                    ],
                )
            ),
        )
        assert result.has_pii is True
        cards = [f for f in result.findings if f.pattern == "credit_card"]
        assert len(cards) >= 1

    def test_detects_credit_card_no_dashes(self) -> None:
        result = scan_prompt_for_pii(
            "Card: 4111111111111111",
            ScanPromptForPiiOptions(
                redactor_config=RedactorConfig(
                    detect_emails=False,
                    detect_phones=False,
                    detect_api_keys=False,
                    custom_patterns=[
                        RedactionPattern(
                            name="credit_card",
                            pattern=re.compile(r"\b(?:\d{4}[-.\s]?){3}\d{4}\b"),
                            type="custom",
                        )
                    ],
                )
            ),
        )
        cards = [f for f in result.findings if f.pattern == "credit_card"]
        assert len(cards) >= 1


# ---------------------------------------------------------------------------
# scan_prompt_for_pii — general
# ---------------------------------------------------------------------------


class TestScanGeneral:
    def test_no_pii_in_clean_text(self) -> None:
        result = scan_prompt_for_pii("Hello, this is a clean prompt.")
        # May detect phone-like patterns, so just check no emails/ssns/credit cards
        emails = [f for f in result.findings if f.type == "email"]
        ssns = [f for f in result.findings if f.type == "ssn"]
        cards = [f for f in result.findings if f.type == "credit_card"]
        assert len(emails) == 0
        assert len(ssns) == 0
        assert len(cards) == 0

    def test_default_options_detect_all(self) -> None:
        text = "email: a@b.com, SSN: 123-45-6789, card: 4111-1111-1111-1111"
        result = scan_prompt_for_pii(text)
        assert result.has_pii is True
        types_found = {f.type for f in result.findings}
        assert "email" in types_found

    def test_findings_sorted_by_start_position(self) -> None:
        text = "SSN: 123-45-6789. Email: x@y.com"
        result = scan_prompt_for_pii(text)
        starts = [f.start for f in result.findings]
        assert starts == sorted(starts)

    def test_finding_has_start_end(self) -> None:
        result = scan_prompt_for_pii("user@example.com")
        assert len(result.findings) >= 1
        finding = result.findings[0]
        assert finding.start == 0
        assert finding.end == len("user@example.com")
