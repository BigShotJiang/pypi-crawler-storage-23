from unittest.mock import AsyncMock, MagicMock

import pytest

from arelis.core.errors import GovernanceGateDeniedError
from arelis.core.types import ActorRef, GovernanceContext
from arelis.governance_gate.gate import evaluate_pre_invocation_gate, with_governance_gate
from arelis.governance_gate.types import (
    EvaluatePreInvocationGateInput,
    GovernanceGateEvaluator,
    PolicyDecision,
    PolicyResult,
    PolicyResultSummary,
    WithGovernanceGateOptions,
)


@pytest.fixture
def mock_evaluator():
    evaluator = MagicMock(spec=GovernanceGateEvaluator)
    evaluator.resolve_context = AsyncMock(return_value=MagicMock(spec=GovernanceContext))
    evaluator.get_policy_metadata = MagicMock(return_value={"policy_snapshot_hash": "hash-123"})
    return evaluator


@pytest.fixture
def input_data():
    return EvaluatePreInvocationGateInput(
        prompt="Hello world", actor=ActorRef(type="user", id="user-1"), run_id="run-123"
    )


@pytest.mark.asyncio
async def test_evaluate_gate_allow(mock_evaluator, input_data):
    # Setup allow result
    mock_evaluator.evaluate_policy = AsyncMock(
        return_value=PolicyResult(
            decisions=[], summary=PolicyResultSummary(allowed=True), policy_version="v1"
        )
    )

    decision = await evaluate_pre_invocation_gate(mock_evaluator, input_data)

    assert decision.decision == "allow"
    assert decision.run_id == "run-123"
    assert decision.metadata.policy_snapshot_hash == "hash-123"
    assert decision.metadata.timings is not None
    assert decision.metadata.timings.scan_ms >= 0
    assert decision.metadata.timings.policy_eval_ms >= 0
    assert decision.metadata.timings.total_ms >= 0
    assert len(decision.reasons) == 0


@pytest.mark.asyncio
async def test_evaluate_gate_deny(mock_evaluator, input_data):
    # Setup deny result
    mock_evaluator.evaluate_policy = AsyncMock(
        return_value=PolicyResult(
            decisions=[PolicyDecision(effect="block", reason="Policy says no", code="BLOCK_1")],
            summary=PolicyResultSummary(
                allowed=False, block_reason="Policy says no", block_code="BLOCK_1"
            ),
            policy_version="v1",
        )
    )

    decision = await evaluate_pre_invocation_gate(mock_evaluator, input_data)

    assert decision.decision == "deny"
    assert "Policy says no" in decision.reasons
    assert "BLOCK_1" in decision.codes


@pytest.mark.asyncio
async def test_with_governance_gate_throw(mock_evaluator, input_data):
    # Setup deny result
    mock_evaluator.evaluate_policy = AsyncMock(
        return_value=PolicyResult(
            decisions=[PolicyDecision(effect="block", reason="Denied")],
            summary=PolicyResultSummary(allowed=False, block_reason="Denied"),
            policy_version="v1",
        )
    )

    invoke = AsyncMock(return_value="result")

    with pytest.raises(GovernanceGateDeniedError, match="Denied"):
        await with_governance_gate(
            mock_evaluator, input_data, invoke, WithGovernanceGateOptions(deny_mode="throw")
        )

    invoke.assert_not_called()


@pytest.mark.asyncio
async def test_with_governance_gate_return(mock_evaluator, input_data):
    # Setup deny result
    mock_evaluator.evaluate_policy = AsyncMock(
        return_value=PolicyResult(
            decisions=[PolicyDecision(effect="block", reason="Denied")],
            summary=PolicyResultSummary(allowed=False, block_reason="Denied"),
            policy_version="v1",
        )
    )

    invoke = AsyncMock(return_value="result")

    result = await with_governance_gate(
        mock_evaluator, input_data, invoke, WithGovernanceGateOptions(deny_mode="return")
    )

    assert not result.invoked
    assert result.decision.decision == "deny"
    assert result.result is None
    invoke.assert_not_called()


@pytest.mark.asyncio
async def test_with_governance_gate_allow_invoke(mock_evaluator, input_data):
    # Setup allow result
    mock_evaluator.evaluate_policy = AsyncMock(
        return_value=PolicyResult(
            decisions=[], summary=PolicyResultSummary(allowed=True), policy_version="v1"
        )
    )

    invoke = AsyncMock(return_value="success_result")

    result = await with_governance_gate(mock_evaluator, input_data, invoke)

    assert result.invoked
    assert result.decision.decision == "allow"
    assert result.result == "success_result"
    invoke.assert_called_once()


class _DummyPlatformEvents:
    def __init__(self, fail: bool = False) -> None:
        self.fail = fail
        self.created: list[dict[str, object]] = []

    def create(self, event: dict[str, object]) -> dict[str, str]:
        if self.fail:
            raise RuntimeError("event write failed")
        self.created.append(event)
        return {"eventId": "evt_1"}


class _DummyPlatformGovernance:
    def __init__(self, decisions: list[dict[str, object]], policy_hash: str | None = None) -> None:
        self._decisions = decisions
        self._policy_hash = policy_hash

    def evaluatePolicy(self, _: dict[str, object]) -> dict[str, object]:  # noqa: N802
        return {
            "runId": "run-platform",
            "decisions": self._decisions,
            "evaluatedAt": "2026-01-01T00:00:00Z",
            "policySetHash": self._policy_hash,
        }


class _DummyPlatformSource:
    def __init__(
        self,
        *,
        decisions: list[dict[str, object]],
        policy_hash: str | None = None,
        fail_events: bool = False,
    ) -> None:
        self.events = _DummyPlatformEvents(fail=fail_events)
        self.governance = _DummyPlatformGovernance(decisions=decisions, policy_hash=policy_hash)


@pytest.mark.asyncio
async def test_evaluate_pre_invocation_gate_supports_platform_source() -> None:
    platform = _DummyPlatformSource(
        decisions=[
            {
                "policyId": "policy-1",
                "decision": "deny",
                "reason": "Blocked by managed policy",
                "code": "PLATFORM_DENY",
            }
        ],
        policy_hash="platform_hash_1",
    )

    result = await evaluate_pre_invocation_gate(
        platform,  # type: ignore[arg-type]
        EvaluatePreInvocationGateInput(
            run_id="run-platform",
            prompt="block this prompt",
            actor=ActorRef(type="service", id="svc-gate"),
            model="managed-model",
        ),
    )

    assert result.decision == "deny"
    assert "PLATFORM_DENY" in result.codes
    assert "Blocked by managed policy" in result.reasons
    assert result.metadata.policy_snapshot_hash == "platform_hash_1"


@pytest.mark.asyncio
async def test_with_governance_gate_reports_platform_telemetry_events() -> None:
    platform = _DummyPlatformSource(
        decisions=[{"policyId": "policy-1", "decision": "allow"}],
        policy_hash="platform_hash_2",
    )

    invoke = AsyncMock(return_value={"ok": True})
    result = await with_governance_gate(
        platform,  # type: ignore[arg-type]
        EvaluatePreInvocationGateInput(
            run_id="run-platform",
            prompt="safe prompt",
            actor=ActorRef(type="service", id="svc-gate"),
            model="managed-model",
        ),
        invoke,
        WithGovernanceGateOptions(deny_mode="return"),
    )

    assert result.invoked is True
    event_types = [event["eventType"] for event in platform.events.created]
    assert "governance.gate.evaluated" in event_types
    assert "governance.gate.outcome" in event_types


@pytest.mark.asyncio
async def test_with_governance_gate_records_warnings_on_telemetry_failure() -> None:
    platform = _DummyPlatformSource(
        decisions=[{"policyId": "policy-1", "decision": "deny", "reason": "Blocked"}],
        fail_events=True,
    )

    result = await with_governance_gate(
        platform,  # type: ignore[arg-type]
        EvaluatePreInvocationGateInput(
            run_id="run-platform",
            prompt="blocked prompt",
            actor=ActorRef(type="service", id="svc-gate"),
            model="managed-model",
        ),
        AsyncMock(return_value="should-not-run"),
        WithGovernanceGateOptions(deny_mode="return"),
    )

    assert result.invoked is False
    assert result.warnings is not None
    assert len(result.warnings) > 0
