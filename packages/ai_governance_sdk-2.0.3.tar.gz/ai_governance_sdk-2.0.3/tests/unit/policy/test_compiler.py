"""Tests for arelis.policy.compiler."""

from __future__ import annotations

import hashlib
import json

import pytest

from arelis.policy.compiler import (
    POLICY_COMPILER_VERSION,
    canonicalize_policy,
    compile_policy,
    create_json_policy_compiler,
    hash_canonical_policy,
    parse_policy_config,
)
from arelis.policy.types import (
    DisclosureRule,
    DisclosureRuleMatch,
    DisclosureRuleSet,
    JsonRule,
    JsonRulesConfig,
    PolicyCompilationInput,
    RuleCondition,
)

# ---------------------------------------------------------------------------
# Canonicalization
# ---------------------------------------------------------------------------


class TestCanonicalizePolicy:
    def test_simple_dict(self) -> None:
        result = canonicalize_policy({"b": 2, "a": 1})
        # Keys should be sorted
        parsed = json.loads(result)
        assert list(parsed.keys()) == ["a", "b"]

    def test_nested_dict_keys_sorted(self) -> None:
        result = canonicalize_policy({"z": {"b": 2, "a": 1}})
        parsed = json.loads(result)
        assert list(parsed["z"].keys()) == ["a", "b"]

    def test_list_preserved(self) -> None:
        result = canonicalize_policy([3, 1, 2])
        assert json.loads(result) == [3, 1, 2]

    def test_deterministic(self) -> None:
        v1 = canonicalize_policy({"b": 2, "a": 1, "c": [3, 2, 1]})
        v2 = canonicalize_policy({"c": [3, 2, 1], "a": 1, "b": 2})
        assert v1 == v2

    def test_no_whitespace(self) -> None:
        result = canonicalize_policy({"a": 1})
        assert " " not in result
        assert "\n" not in result

    def test_set_sorted(self) -> None:
        result = canonicalize_policy({"s": {3, 1, 2}})
        parsed = json.loads(result)
        assert parsed["s"] == [1, 2, 3]

    def test_none_value(self) -> None:
        result = canonicalize_policy({"a": None})
        assert json.loads(result) == {"a": None}

    def test_string_value(self) -> None:
        result = canonicalize_policy("hello")
        assert json.loads(result) == "hello"


# ---------------------------------------------------------------------------
# Hashing
# ---------------------------------------------------------------------------


class TestHashCanonicalPolicy:
    def test_sha256_hex(self) -> None:
        canonical = '{"a":1}'
        result = hash_canonical_policy(canonical)
        expected = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        assert result == expected

    def test_deterministic(self) -> None:
        h1 = hash_canonical_policy('{"a":1,"b":2}')
        h2 = hash_canonical_policy('{"a":1,"b":2}')
        assert h1 == h2

    def test_different_inputs_different_hash(self) -> None:
        h1 = hash_canonical_policy('{"a":1}')
        h2 = hash_canonical_policy('{"a":2}')
        assert h1 != h2


# ---------------------------------------------------------------------------
# compile_policy
# ---------------------------------------------------------------------------


class TestCompilePolicy:
    def test_empty_rules(self) -> None:
        config = JsonRulesConfig(rules=[])
        result = compile_policy(PolicyCompilationInput(policy=config, engine_id="test"))
        assert len(result.constraints) == 0
        assert result.snapshot.algorithm == "sha256"
        assert result.snapshot.compiler_version == POLICY_COMPILER_VERSION

    def test_single_rule(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block GPT-4",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="equals", value="gpt-4")
                    ],
                    action="block",
                    reason="Not allowed",
                    code="B1",
                    priority=5,
                )
            ],
            version="v1",
        )
        result = compile_policy(PolicyCompilationInput(policy=config, engine_id="json-rules"))
        assert len(result.constraints) == 1
        c = result.constraints[0]
        assert c.id == "r1"
        assert c.action == "block"
        assert c.reason == "Not allowed"
        assert c.source == "json-rules"
        assert result.policy_version == "v1"
        assert result.engine_id == "json-rules"

    def test_derived_disclosure_rules(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block",
                    checkpoints=["BeforePrompt"],
                    conditions=[],
                    action="block",
                    reason="No",
                )
            ]
        )
        result = compile_policy(PolicyCompilationInput(policy=config))
        # Disclosure rules derived from constraints
        assert len(result.disclosure_rules) == 1
        assert result.disclosure_rules[0].id == "derived.r1"
        assert result.disclosure_derivation is not None
        assert result.disclosure_derivation.strategy == "policy-derived"

    def test_explicit_disclosure_rules(self) -> None:
        config = JsonRulesConfig(rules=[])
        disclosure = DisclosureRuleSet(
            rules=[
                DisclosureRule(
                    id="explicit1",
                    match=DisclosureRuleMatch(event_types=["model.request"]),
                )
            ]
        )
        result = compile_policy(PolicyCompilationInput(policy=config, disclosure=disclosure))
        assert len(result.disclosure_rules) == 1
        assert result.disclosure_rules[0].id == "explicit1"
        assert result.disclosure_derivation is not None
        assert result.disclosure_derivation.strategy == "explicit"

    def test_snapshot_hash_deterministic(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Test",
                    checkpoints=["BeforePrompt"],
                    conditions=[],
                    action="allow",
                )
            ]
        )
        r1 = compile_policy(PolicyCompilationInput(policy=config, engine_id="e1"))
        r2 = compile_policy(PolicyCompilationInput(policy=config, engine_id="e1"))
        assert r1.snapshot.hash == r2.snapshot.hash

    def test_dict_policy_input(self) -> None:
        policy_dict: dict[str, object] = {
            "rules": [
                {
                    "id": "r1",
                    "name": "Block",
                    "checkpoints": ["BeforePrompt"],
                    "conditions": [
                        {"field": "data.model_id", "operator": "equals", "value": "gpt-4"}
                    ],
                    "action": "block",
                    "reason": "No GPT-4",
                }
            ]
        }
        result = compile_policy(PolicyCompilationInput(policy=policy_dict, engine_id="json-rules"))
        assert len(result.constraints) == 1


# ---------------------------------------------------------------------------
# JSON Policy Compiler
# ---------------------------------------------------------------------------


class TestJsonPolicyCompiler:
    def test_compile(self) -> None:
        compiler = create_json_policy_compiler("my-compiler")
        assert compiler.id == "my-compiler"
        config = JsonRulesConfig(rules=[])
        result = compiler.compile(PolicyCompilationInput(policy=config))
        assert result.engine_id == "my-compiler"

    def test_default_id(self) -> None:
        compiler = create_json_policy_compiler()
        assert compiler.id == "json-rules"


# ---------------------------------------------------------------------------
# parse_policy_config
# ---------------------------------------------------------------------------


class TestParsePolicyConfig:
    def test_direct_format(self) -> None:
        raw: dict[str, object] = {
            "rules": [
                {
                    "id": "r1",
                    "name": "Test",
                    "checkpoints": ["BeforePrompt"],
                    "conditions": [],
                    "action": "allow",
                }
            ]
        }
        result = parse_policy_config(raw)
        assert len(result.policy.rules) == 1

    def test_wrapper_format(self) -> None:
        raw: dict[str, object] = {
            "policy": {
                "rules": [
                    {
                        "id": "r1",
                        "name": "Test",
                        "checkpoints": ["BeforePrompt"],
                        "conditions": [],
                        "action": "allow",
                    }
                ]
            }
        }
        result = parse_policy_config(raw)
        assert len(result.policy.rules) == 1

    def test_with_disclosure(self) -> None:
        raw: dict[str, object] = {
            "policy": {"rules": []},
            "disclosure": {
                "rules": [
                    {
                        "id": "d1",
                        "match": {"eventTypes": ["model.request"]},
                    }
                ]
            },
        }
        result = parse_policy_config(raw)
        assert result.disclosure is not None
        assert len(result.disclosure.rules) == 1

    def test_invalid_not_dict(self) -> None:
        with pytest.raises(ValueError, match="JSON object"):
            parse_policy_config("not a dict")

    def test_invalid_no_rules(self) -> None:
        with pytest.raises(ValueError, match="rules"):
            parse_policy_config({"policy": {"no_rules": True}})

    def test_invalid_disclosure_not_dict(self) -> None:
        with pytest.raises(ValueError, match="Disclosure"):
            parse_policy_config({"rules": [], "disclosure": "bad"})

    def test_invalid_disclosure_no_rules(self) -> None:
        with pytest.raises(ValueError, match="Disclosure"):
            parse_policy_config({"rules": [], "disclosure": {"no_rules": True}})
