"""Tests for arelis.policy.risk_router."""

from __future__ import annotations

from dataclasses import dataclass

from arelis.policy.risk_router import (
    RiskRouterConfig,
    RiskThresholds,
    RuntimeRiskInput,
    compute_runtime_risk,
    resolve_risk_route,
)
from arelis.policy.types import PolicyDecision, allow_decision, block_decision


@dataclass
class _FakeContext:
    """Minimal governance-like context for tests."""

    class _Org:
        id: str = "org1"

    class _Actor:
        type: str = "human"
        id: str = "user1"

    org: _Org = _Org()
    actor: _Actor = _Actor()
    purpose: str = "test"
    environment: str = "dev"


def _make_risk_input(
    policy_decisions: list[PolicyDecision] | None = None,
    quota_effect: str | None = None,
    evaluation_effect: str | None = None,
    explicit_signals: list[str] | None = None,
) -> RuntimeRiskInput:
    return RuntimeRiskInput(
        operation="generate",
        context=_FakeContext(),
        policy_decisions=policy_decisions or [allow_decision()],
        quota_effect=quota_effect,  # type: ignore[arg-type]
        evaluation_effect=evaluation_effect,  # type: ignore[arg-type]
        explicit_signals=explicit_signals,
    )


# ---------------------------------------------------------------------------
# compute_runtime_risk
# ---------------------------------------------------------------------------


class TestComputeRuntimeRisk:
    def test_baseline_risk(self) -> None:
        signal = compute_runtime_risk(_make_risk_input())
        assert signal.score == 0.1
        assert len(signal.factors) == 0
        assert len(signal.deterministic_inputs_hash) == 64  # SHA-256 hex

    def test_block_decision_high_risk(self) -> None:
        signal = compute_runtime_risk(
            _make_risk_input(policy_decisions=[block_decision("blocked")])
        )
        assert signal.score >= 0.95
        assert any("policy.block" in f for f in signal.factors)

    def test_transform_decision(self) -> None:
        td = PolicyDecision(effect="transform", reason="PII found")
        signal = compute_runtime_risk(_make_risk_input(policy_decisions=[td]))
        assert signal.score >= 0.45
        assert any("policy.transform" in f for f in signal.factors)

    def test_require_approval_decision(self) -> None:
        ad = PolicyDecision(effect="require_approval", reason="high risk", approvers=["admin"])
        signal = compute_runtime_risk(_make_risk_input(policy_decisions=[ad]))
        assert signal.score >= 0.75
        assert any("policy.require_approval" in f for f in signal.factors)

    def test_quota_limit(self) -> None:
        signal = compute_runtime_risk(_make_risk_input(quota_effect="limit"))
        assert signal.score >= 0.55
        assert "quota.limit" in signal.factors

    def test_quota_block(self) -> None:
        signal = compute_runtime_risk(_make_risk_input(quota_effect="block"))
        assert signal.score >= 0.95
        assert "quota.block" in signal.factors

    def test_evaluation_warn(self) -> None:
        signal = compute_runtime_risk(_make_risk_input(evaluation_effect="warn"))
        assert signal.score >= 0.6
        assert "evaluation.warn" in signal.factors

    def test_evaluation_block(self) -> None:
        signal = compute_runtime_risk(_make_risk_input(evaluation_effect="block"))
        assert signal.score >= 0.95
        assert "evaluation.block" in signal.factors

    def test_explicit_signals(self) -> None:
        signal = compute_runtime_risk(_make_risk_input(explicit_signals=["custom_warning"]))
        assert "signal:custom_warning" in signal.factors

    def test_critical_signal(self) -> None:
        signal = compute_runtime_risk(_make_risk_input(explicit_signals=["critical_issue"]))
        assert signal.score >= 0.95
        assert "signal:critical_issue" in signal.factors

    def test_deterministic_hash(self) -> None:
        input_data = _make_risk_input()
        s1 = compute_runtime_risk(input_data)
        s2 = compute_runtime_risk(input_data)
        assert s1.deterministic_inputs_hash == s2.deterministic_inputs_hash

    def test_max_score_policy_wins(self) -> None:
        # Multiple decisions, highest risk wins
        decisions = [
            allow_decision(),
            PolicyDecision(effect="transform", reason="t"),
            block_decision("blocked"),
        ]
        signal = compute_runtime_risk(_make_risk_input(policy_decisions=decisions))
        assert signal.score >= 0.95


# ---------------------------------------------------------------------------
# resolve_risk_route
# ---------------------------------------------------------------------------


class TestResolveRiskRoute:
    def test_off_mode_uses_default_action(self) -> None:
        config = RiskRouterConfig(mode="off", default_action="auto_execute")
        result = resolve_risk_route(_make_risk_input(), config)
        assert result.action == "auto_execute"
        assert result.score >= 0.0

    def test_off_mode_custom_default(self) -> None:
        config = RiskRouterConfig(mode="off", default_action="sandbox")
        result = resolve_risk_route(_make_risk_input(), config)
        assert result.action == "sandbox"

    def test_enabled_auto_execute(self) -> None:
        config = RiskRouterConfig(mode="enabled")
        result = resolve_risk_route(_make_risk_input(), config)
        assert result.action == "auto_execute"
        assert result.score < 0.35

    def test_enabled_sandbox(self) -> None:
        config = RiskRouterConfig(mode="enabled")
        td = PolicyDecision(effect="transform", reason="PII")
        result = resolve_risk_route(_make_risk_input(policy_decisions=[td]), config)
        assert result.action == "sandbox"
        assert result.score >= 0.35

    def test_enabled_require_approval(self) -> None:
        config = RiskRouterConfig(mode="enabled")
        ad = PolicyDecision(effect="require_approval", reason="high risk", approvers=["admin"])
        result = resolve_risk_route(_make_risk_input(policy_decisions=[ad]), config)
        assert result.action == "require_approval"
        assert result.score >= 0.65

    def test_enabled_block(self) -> None:
        config = RiskRouterConfig(mode="enabled")
        result = resolve_risk_route(
            _make_risk_input(policy_decisions=[block_decision("blocked")]), config
        )
        assert result.action == "block"
        assert result.score >= 0.9

    def test_custom_thresholds(self) -> None:
        config = RiskRouterConfig(
            mode="enabled",
            thresholds=RiskThresholds(sandbox=0.1, require_approval=0.3, block=0.5),
        )
        # Baseline risk is 0.1, with custom thresholds this should hit sandbox
        result = resolve_risk_route(_make_risk_input(), config)
        assert result.action == "sandbox"

    def test_default_config(self) -> None:
        # No config = off mode
        result = resolve_risk_route(_make_risk_input())
        assert result.action == "auto_execute"

    def test_result_has_factors_and_hash(self) -> None:
        result = resolve_risk_route(_make_risk_input(policy_decisions=[block_decision("x")]))
        assert isinstance(result.factors, list)
        assert len(result.deterministic_inputs_hash) == 64
