"""Tests for arelis.policy.redactor."""

from __future__ import annotations

import re

from arelis.policy.redactor import (
    RedactionPattern,
    Redactor,
    RedactorConfig,
    create_redactor,
)


class TestRedactorEmails:
    def test_detects_email(self) -> None:
        r = Redactor()
        result = r.redact("Contact bob@example.com for details")
        assert result.redacted is True
        assert "[REDACTED]" in result.text
        assert "bob@example.com" not in result.text
        assert len(result.findings) == 1
        assert result.findings[0].type == "email"
        assert result.findings[0].original == "bob@example.com"

    def test_multiple_emails(self) -> None:
        r = Redactor()
        result = r.redact("alice@x.com and bob@y.org")
        assert result.redacted is True
        assert result.text.count("[REDACTED]") == 2

    def test_no_email(self) -> None:
        r = Redactor()
        result = r.redact("Hello world")
        # Phone pattern may match "world" - check email specifically
        email_findings = [f for f in result.findings if f.type == "email"]
        assert len(email_findings) == 0

    def test_email_detection_disabled(self) -> None:
        r = Redactor(
            RedactorConfig(detect_emails=False, detect_phones=False, detect_api_keys=False)
        )
        result = r.redact("Contact bob@example.com")
        assert result.redacted is False


class TestRedactorPhones:
    def test_detects_us_phone(self) -> None:
        r = Redactor(RedactorConfig(detect_emails=False, detect_api_keys=False))
        result = r.redact("Call me at 555-123-4567")
        assert result.redacted is True
        phone_findings = [f for f in result.findings if f.type == "phone"]
        assert len(phone_findings) >= 1

    def test_detects_phone_with_country_code(self) -> None:
        r = Redactor(RedactorConfig(detect_emails=False, detect_api_keys=False))
        result = r.redact("Call +1-555-123-4567")
        assert result.redacted is True

    def test_phone_detection_disabled(self) -> None:
        r = Redactor(
            RedactorConfig(detect_phones=False, detect_emails=False, detect_api_keys=False)
        )
        result = r.redact("Call 555-123-4567")
        assert result.redacted is False


class TestRedactorApiKeys:
    def test_detects_bearer_token(self) -> None:
        r = Redactor(RedactorConfig(detect_emails=False, detect_phones=False))
        result = r.redact("Authorization: Bearer eyJhbGciOiJIUzI1NiJ9token")
        assert result.redacted is True
        api_findings = [f for f in result.findings if f.type == "api_key"]
        assert len(api_findings) >= 1

    def test_detects_aws_key(self) -> None:
        r = Redactor(RedactorConfig(detect_emails=False, detect_phones=False))
        result = r.redact("key=AKIAIOSFODNN7EXAMPLE")
        assert result.redacted is True

    def test_detects_api_key_assignment(self) -> None:
        r = Redactor(RedactorConfig(detect_emails=False, detect_phones=False))
        result = r.redact("api_key=sk_test_1234567890abcdef")
        assert result.redacted is True

    def test_api_key_detection_disabled(self) -> None:
        r = Redactor(
            RedactorConfig(detect_api_keys=False, detect_emails=False, detect_phones=False)
        )
        result = r.redact("api_key=sk_test_1234567890abcdef")
        assert result.redacted is False


class TestRedactorCustomPatterns:
    def test_custom_pattern(self) -> None:
        ssn_pattern = RedactionPattern(
            name="ssn",
            pattern=re.compile(r"\d{3}-\d{2}-\d{4}"),
            type="custom",
        )
        r = Redactor(
            RedactorConfig(
                detect_emails=False,
                detect_phones=False,
                detect_api_keys=False,
                custom_patterns=[ssn_pattern],
            )
        )
        result = r.redact("SSN: 123-45-6789")
        assert result.redacted is True
        assert len(result.findings) == 1
        assert result.findings[0].type == "custom"
        assert result.findings[0].original == "123-45-6789"
        assert result.findings[0].pattern == "ssn"

    def test_custom_replacement(self) -> None:
        pattern = RedactionPattern(
            name="credit_card",
            pattern=re.compile(r"\d{4}-\d{4}-\d{4}-\d{4}"),
            type="custom",
            replacement="[CARD REDACTED]",
        )
        r = Redactor(
            RedactorConfig(
                detect_emails=False,
                detect_phones=False,
                detect_api_keys=False,
                custom_patterns=[pattern],
            )
        )
        result = r.redact("Card: 1234-5678-9012-3456")
        assert "[CARD REDACTED]" in result.text

    def test_secret_patterns(self) -> None:
        secret_pattern = RedactionPattern(
            name="internal_token",
            pattern=re.compile(r"tok_[a-zA-Z0-9]{20,}"),
            type="custom",
        )
        r = Redactor(
            RedactorConfig(
                detect_emails=False,
                detect_phones=False,
                detect_api_keys=False,
                secret_patterns=[secret_pattern],
            )
        )
        result = r.redact("Token: tok_abcdefghijklmnopqrst")
        assert result.redacted is True


class TestRedactorContainsSensitiveData:
    def test_contains_email(self) -> None:
        r = Redactor()
        assert r.contains_sensitive_data("bob@example.com") is True

    def test_no_sensitive_data(self) -> None:
        r = Redactor(
            RedactorConfig(detect_emails=False, detect_phones=False, detect_api_keys=False)
        )
        assert r.contains_sensitive_data("Hello world") is False

    def test_contains_custom_pattern(self) -> None:
        pattern = RedactionPattern(
            name="ssn",
            pattern=re.compile(r"\d{3}-\d{2}-\d{4}"),
            type="custom",
        )
        r = Redactor(
            RedactorConfig(
                detect_emails=False,
                detect_phones=False,
                detect_api_keys=False,
                custom_patterns=[pattern],
            )
        )
        assert r.contains_sensitive_data("SSN: 123-45-6789") is True
        assert r.contains_sensitive_data("No SSN here") is False


class TestCreateRedactor:
    def test_default_config(self) -> None:
        r = create_redactor()
        assert isinstance(r, Redactor)

    def test_custom_config(self) -> None:
        r = create_redactor(RedactorConfig(detect_emails=False))
        result = r.redact("bob@example.com")
        email_findings = [f for f in result.findings if f.type == "email"]
        assert len(email_findings) == 0


class TestRedactorDefaultReplacement:
    def test_custom_default_replacement(self) -> None:
        r = Redactor(
            RedactorConfig(default_replacement="***", detect_phones=False, detect_api_keys=False)
        )
        result = r.redact("Email: bob@example.com")
        assert "***" in result.text
        assert "[REDACTED]" not in result.text
