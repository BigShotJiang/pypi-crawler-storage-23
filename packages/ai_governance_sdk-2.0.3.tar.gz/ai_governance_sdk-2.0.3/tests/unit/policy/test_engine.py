"""Tests for arelis.policy.engine."""

from __future__ import annotations

import pytest

from arelis.policy.engine import (
    JsonRulesEngine,
    create_allow_all_engine,
    create_deny_all_engine,
    create_policy_mode_engine,
)
from arelis.policy.types import (
    JsonRule,
    JsonRulesConfig,
    PolicyInput,
    PolicyInputData,
    RuleCondition,
)


def _make_input(
    checkpoint: str = "BeforePrompt",
    model_id: str | None = None,
    tool_name: str | None = None,
) -> PolicyInput:
    return PolicyInput(
        checkpoint=checkpoint,  # type: ignore[arg-type]
        context={"org": "org1"},
        run_id="run_123",
        data=PolicyInputData(model_id=model_id, tool_name=tool_name),
    )


# ---------------------------------------------------------------------------
# AllowAll / DenyAll engines
# ---------------------------------------------------------------------------


class TestAllowAllEngine:
    @pytest.mark.asyncio
    async def test_evaluate_allows(self) -> None:
        engine = create_allow_all_engine()
        result = await engine.evaluate(_make_input())
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_evaluate_compiled_allows(self) -> None:
        engine = create_allow_all_engine()
        result = await engine.evaluate_compiled(_make_input())
        assert result.summary.allowed is True


class TestDenyAllEngine:
    @pytest.mark.asyncio
    async def test_evaluate_denies(self) -> None:
        engine = create_deny_all_engine("No access")
        result = await engine.evaluate(_make_input())
        assert result.summary.allowed is False
        assert result.summary.block_reason == "No access"
        assert result.summary.block_code == "DENY_ALL"

    @pytest.mark.asyncio
    async def test_evaluate_compiled_denies(self) -> None:
        engine = create_deny_all_engine()
        result = await engine.evaluate_compiled(_make_input())
        assert result.summary.allowed is False

    @pytest.mark.asyncio
    async def test_default_reason(self) -> None:
        engine = create_deny_all_engine()
        result = await engine.evaluate(_make_input())
        assert result.summary.block_reason == "All requests denied"


# ---------------------------------------------------------------------------
# JsonRulesEngine
# ---------------------------------------------------------------------------


class TestJsonRulesEngine:
    @pytest.mark.asyncio
    async def test_empty_rules_allows(self) -> None:
        engine = JsonRulesEngine()
        result = await engine.evaluate(_make_input())
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_matching_block_rule(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block GPT-4",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="equals", value="gpt-4")
                    ],
                    action="block",
                    reason="GPT-4 not allowed",
                    code="B1",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is False
        assert result.summary.block_reason == "GPT-4 not allowed"
        assert result.summary.block_code == "B1"

    @pytest.mark.asyncio
    async def test_non_matching_rule_allows(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block GPT-4",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="equals", value="gpt-4")
                    ],
                    action="block",
                    reason="GPT-4 not allowed",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="gpt-3.5"))
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_checkpoint_filtering(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block tool calls",
                    checkpoints=["BeforeToolCall"],
                    conditions=[
                        RuleCondition(field="data.tool_name", operator="equals", value="delete")
                    ],
                    action="block",
                    reason="Delete not allowed",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        # Different checkpoint - rule should not apply
        result = await engine.evaluate(_make_input(checkpoint="BeforePrompt", tool_name="delete"))
        assert result.summary.allowed is True
        # Matching checkpoint
        result = await engine.evaluate(_make_input(checkpoint="BeforeToolCall", tool_name="delete"))
        assert result.summary.allowed is False

    @pytest.mark.asyncio
    async def test_allow_rule(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Allow GPT-4",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="equals", value="gpt-4")
                    ],
                    action="allow",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_default_action_block(self) -> None:
        config = JsonRulesConfig(
            rules=[],
            default_action="block",
            default_block_reason="Denied by default",
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input())
        assert result.summary.allowed is False
        assert result.summary.block_reason == "Denied by default"

    @pytest.mark.asyncio
    async def test_priority_ordering(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="low",
                    name="Allow all",
                    checkpoints=["BeforePrompt"],
                    conditions=[],
                    action="allow",
                    priority=1,
                ),
                JsonRule(
                    id="high",
                    name="Block GPT-4",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="equals", value="gpt-4")
                    ],
                    action="block",
                    reason="Blocked",
                    priority=10,
                ),
            ]
        )
        engine = JsonRulesEngine(config)
        # The high-priority block rule is evaluated first
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is False

    @pytest.mark.asyncio
    async def test_version_in_result(self) -> None:
        config = JsonRulesConfig(rules=[], version="v2.0")
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input())
        assert result.policy_version == "v2.0"

    @pytest.mark.asyncio
    async def test_evaluate_compiled_delegates(self) -> None:
        engine = JsonRulesEngine()
        result = await engine.evaluate_compiled(_make_input())
        assert result.summary.allowed is True


class TestJsonRulesEngineConditionOperators:
    @pytest.mark.asyncio
    async def test_not_equals(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block non-GPT-4",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="notEquals", value="gpt-4")
                    ],
                    action="block",
                    reason="Only GPT-4 allowed",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="gpt-3.5"))
        assert result.summary.allowed is False
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_contains(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block if tool contains delete",
                    checkpoints=["BeforeToolCall"],
                    conditions=[
                        RuleCondition(field="data.tool_name", operator="contains", value="delete")
                    ],
                    action="block",
                    reason="No delete",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(
            _make_input(checkpoint="BeforeToolCall", tool_name="file_delete")
        )
        assert result.summary.allowed is False
        result = await engine.evaluate(
            _make_input(checkpoint="BeforeToolCall", tool_name="file_read")
        )
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_in_operator(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block listed models",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(
                            field="data.model_id", operator="in", value=["gpt-4", "gpt-4o"]
                        )
                    ],
                    action="block",
                    reason="Blocked model",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is False
        result = await engine.evaluate(_make_input(model_id="gpt-3.5"))
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_matches_regex(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block GPT models",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(field="data.model_id", operator="matches", value="^gpt-")
                    ],
                    action="block",
                    reason="No GPT",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is False
        result = await engine.evaluate(_make_input(model_id="claude-3"))
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_not_contains(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block if not admin tool",
                    checkpoints=["BeforeToolCall"],
                    conditions=[
                        RuleCondition(field="data.tool_name", operator="notContains", value="admin")
                    ],
                    action="block",
                    reason="Admin tools only",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(
            _make_input(checkpoint="BeforeToolCall", tool_name="user_read")
        )
        assert result.summary.allowed is False
        result = await engine.evaluate(
            _make_input(checkpoint="BeforeToolCall", tool_name="admin_read")
        )
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_not_in(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Block non-approved models",
                    checkpoints=["BeforePrompt"],
                    conditions=[
                        RuleCondition(
                            field="data.model_id",
                            operator="notIn",
                            value=["gpt-4", "claude-3"],
                        )
                    ],
                    action="block",
                    reason="Not approved",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        result = await engine.evaluate(_make_input(model_id="llama-2"))
        assert result.summary.allowed is False
        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is True


class TestJsonRulesEngineManagement:
    def test_add_rule(self) -> None:
        engine = JsonRulesEngine()
        rule = JsonRule(
            id="r1",
            name="Test",
            checkpoints=["BeforePrompt"],
            conditions=[],
            action="allow",
        )
        engine.add_rule(rule)
        assert len(engine.get_rules()) == 1

    def test_add_rule_wrong_type(self) -> None:
        engine = JsonRulesEngine()
        with pytest.raises(TypeError, match="Expected JsonRule"):
            engine.add_rule("not a rule")  # type: ignore[arg-type]

    def test_remove_rule(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Test",
                    checkpoints=["BeforePrompt"],
                    conditions=[],
                    action="allow",
                )
            ]
        )
        engine = JsonRulesEngine(config)
        assert engine.remove_rule("r1") is True
        assert len(engine.get_rules()) == 0

    def test_remove_nonexistent_rule(self) -> None:
        engine = JsonRulesEngine()
        assert engine.remove_rule("nonexistent") is False

    def test_get_rules_returns_copy(self) -> None:
        engine = JsonRulesEngine()
        rules = engine.get_rules()
        rules.append("fake")  # type: ignore[arg-type]
        assert len(engine.get_rules()) == 0


# ---------------------------------------------------------------------------
# PolicyModeEngine
# ---------------------------------------------------------------------------


class TestPolicyModeEngine:
    @pytest.mark.asyncio
    async def test_enforce_mode_blocks(self) -> None:
        base = create_deny_all_engine("denied")
        engine = create_policy_mode_engine(base, "enforce")
        result = await engine.evaluate(_make_input())
        assert result.summary.allowed is False

    @pytest.mark.asyncio
    async def test_monitor_mode_allows(self) -> None:
        base = create_deny_all_engine("denied")
        engine = create_policy_mode_engine(base, "monitor")
        result = await engine.evaluate(_make_input())
        # Monitor mode overrides to allowed
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_off_mode_skips_evaluation(self) -> None:
        base = create_deny_all_engine("denied")
        engine = create_policy_mode_engine(base, "off")
        result = await engine.evaluate(_make_input())
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_callable_mode_resolver(self) -> None:
        base = create_deny_all_engine("denied")

        def resolver(input: PolicyInput) -> str:
            if input.data.model_id == "gpt-4":
                return "enforce"
            return "off"

        engine = create_policy_mode_engine(base, resolver)

        result = await engine.evaluate(_make_input(model_id="gpt-4"))
        assert result.summary.allowed is False

        result = await engine.evaluate(_make_input(model_id="gpt-3.5"))
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_evaluate_compiled_enforce(self) -> None:
        base = create_deny_all_engine("denied")
        engine = create_policy_mode_engine(base, "enforce")
        result = await engine.evaluate_compiled(_make_input())
        assert result.summary.allowed is False

    @pytest.mark.asyncio
    async def test_evaluate_compiled_off(self) -> None:
        base = create_deny_all_engine("denied")
        engine = create_policy_mode_engine(base, "off")
        result = await engine.evaluate_compiled(_make_input())
        assert result.summary.allowed is True

    @pytest.mark.asyncio
    async def test_monitor_preserves_decisions(self) -> None:
        base = create_deny_all_engine("denied")
        engine = create_policy_mode_engine(base, "monitor")
        result = await engine.evaluate(_make_input())
        # Decisions from the base engine are preserved
        assert len(result.decisions) > 0
        assert result.decisions[0].effect == "block"
