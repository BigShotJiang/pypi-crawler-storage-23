"""Tests for arelis.policy.types."""

from __future__ import annotations

from arelis.policy.types import (
    POLICY_CHECKPOINTS,
    CompiledPolicyConstraint,
    DisclosureRule,
    DisclosureRuleMatch,
    DisclosureRuleRedact,
    DisclosureRuleReveal,
    DisclosureRuleSet,
    JsonRule,
    JsonRulesConfig,
    Patch,
    PolicyConfigFile,
    PolicyInput,
    PolicyInputData,
    PolicyResult,
    PolicyResultSummary,
    PolicySnapshot,
    RuleCondition,
    aggregate_decisions,
    allow_decision,
    apply_patches,
    block_decision,
    drop_patch,
    normalize_patch,
    redact_patch,
    replace_patch,
    require_approval_decision,
    transform_decision,
)

# ---------------------------------------------------------------------------
# Policy checkpoints
# ---------------------------------------------------------------------------


class TestPolicyCheckpoints:
    def test_all_checkpoints_present(self) -> None:
        expected = {
            "BeforeOperation",
            "BeforePrompt",
            "AfterModelOutput",
            "BeforeToolCall",
            "AfterToolResult",
            "BeforePersist",
            "BeforeProvision",
            "BeforeDestroy",
            "BeforeConfigChange",
            "BeforeAuth",
            "BeforeAgentStep",
        }
        assert set(POLICY_CHECKPOINTS) == expected

    def test_checkpoints_is_tuple(self) -> None:
        assert isinstance(POLICY_CHECKPOINTS, tuple)


# ---------------------------------------------------------------------------
# Patch operations
# ---------------------------------------------------------------------------


class TestPatch:
    def test_replace_patch(self) -> None:
        p = replace_patch("/name", "Alice", reason="normalize")
        assert p.op == "replace"
        assert p.path == "/name"
        assert p.value == "Alice"
        assert p.reason == "normalize"

    def test_redact_patch(self) -> None:
        p = redact_patch("/email", reason="PII")
        assert p.op == "redact"
        assert p.path == "/email"
        assert p.value == "[REDACTED]"
        assert p.reason == "PII"

    def test_drop_patch(self) -> None:
        p = drop_patch("/ssn", reason="sensitive")
        assert p.op == "drop"
        assert p.path == "/ssn"
        assert p.value is None
        assert p.reason == "sensitive"

    def test_normalize_patch(self) -> None:
        p = normalize_patch("/phone", "+1-555-0100", reason="format")
        assert p.op == "normalize"
        assert p.path == "/phone"
        assert p.value == "+1-555-0100"

    def test_patch_no_reason(self) -> None:
        p = replace_patch("/x", 42)
        assert p.reason is None


class TestApplyPatches:
    def test_replace(self) -> None:
        data: dict[str, object] = {"name": "Bob", "age": 30}
        result = apply_patches(data, [replace_patch("/name", "Alice")])
        assert result["name"] == "Alice"
        assert result["age"] == 30
        # Original not mutated
        assert data["name"] == "Bob"

    def test_redact(self) -> None:
        data: dict[str, object] = {"email": "bob@example.com"}
        result = apply_patches(data, [redact_patch("/email")])
        assert result["email"] == "[REDACTED]"

    def test_drop(self) -> None:
        data: dict[str, object] = {"name": "Bob", "ssn": "123-45-6789"}
        result = apply_patches(data, [drop_patch("/ssn")])
        assert "ssn" not in result
        assert result["name"] == "Bob"

    def test_normalize(self) -> None:
        data: dict[str, object] = {"phone": "5550100"}
        result = apply_patches(data, [normalize_patch("/phone", "+1-555-0100")])
        assert result["phone"] == "+1-555-0100"

    def test_nested_path(self) -> None:
        data: dict[str, object] = {"user": {"name": "Bob", "email": "bob@x.com"}}
        result = apply_patches(data, [redact_patch("/user/email")])
        assert result["user"]["email"] == "[REDACTED]"  # type: ignore[index]

    def test_nonexistent_path_skipped(self) -> None:
        data: dict[str, object] = {"name": "Bob"}
        result = apply_patches(data, [replace_patch("/missing/deep", "val")])
        assert result == {"name": "Bob"}

    def test_empty_path_skipped(self) -> None:
        data: dict[str, object] = {"name": "Bob"}
        result = apply_patches(data, [Patch(op="replace", path="", value="x")])
        assert result == {"name": "Bob"}

    def test_multiple_patches(self) -> None:
        data: dict[str, object] = {"a": 1, "b": 2, "c": 3}
        patches = [
            replace_patch("/a", 10),
            drop_patch("/b"),
            normalize_patch("/c", 30),
        ]
        result = apply_patches(data, patches)
        assert result["a"] == 10
        assert "b" not in result
        assert result["c"] == 30

    def test_deep_copy(self) -> None:
        data: dict[str, object] = {"nested": {"val": 1}}
        result = apply_patches(data, [])
        result["nested"]["val"] = 999  # type: ignore[index]
        assert data["nested"]["val"] == 1  # type: ignore[index]


# ---------------------------------------------------------------------------
# Policy decisions
# ---------------------------------------------------------------------------


class TestPolicyDecision:
    def test_allow_decision(self) -> None:
        d = allow_decision()
        assert d.effect == "allow"
        assert d.reason is None

    def test_block_decision(self) -> None:
        d = block_decision("not allowed", "BLOCKED_001")
        assert d.effect == "block"
        assert d.reason == "not allowed"
        assert d.code == "BLOCKED_001"

    def test_transform_decision(self) -> None:
        patches = [redact_patch("/email")]
        d = transform_decision(patches, "PII found")
        assert d.effect == "transform"
        assert d.patches is not None
        assert len(d.patches) == 1
        assert d.reason == "PII found"

    def test_require_approval_decision(self) -> None:
        d = require_approval_decision(["admin@x.com"], "High risk")
        assert d.effect == "require_approval"
        assert d.approvers == ["admin@x.com"]
        assert d.reason == "High risk"


# ---------------------------------------------------------------------------
# Aggregate decisions
# ---------------------------------------------------------------------------


class TestAggregateDecisions:
    def test_all_allow(self) -> None:
        result = aggregate_decisions([allow_decision(), allow_decision()])
        assert result.summary.allowed is True
        assert result.summary.block_reason is None

    def test_block_takes_priority(self) -> None:
        decisions = [
            allow_decision(),
            block_decision("blocked!", "B1"),
            require_approval_decision(["admin"], "needs approval"),
        ]
        result = aggregate_decisions(decisions)
        assert result.summary.allowed is False
        assert result.summary.block_reason == "blocked!"
        assert result.summary.block_code == "B1"

    def test_require_approval_when_no_block(self) -> None:
        decisions = [
            allow_decision(),
            require_approval_decision(["admin@x.com"], "needs review"),
        ]
        result = aggregate_decisions(decisions)
        assert result.summary.allowed is False
        assert result.summary.approvers == ["admin@x.com"]
        assert result.summary.block_reason == "needs review"

    def test_empty_decisions(self) -> None:
        result = aggregate_decisions([])
        assert result.summary.allowed is True

    def test_decisions_preserved(self) -> None:
        decisions = [allow_decision(), block_decision("no")]
        result = aggregate_decisions(decisions)
        assert len(result.decisions) == 2


# ---------------------------------------------------------------------------
# PolicyResult
# ---------------------------------------------------------------------------


class TestPolicyResult:
    def test_creation(self) -> None:
        result = PolicyResult(
            decisions=[allow_decision()],
            summary=PolicyResultSummary(allowed=True),
            policy_version="v1",
        )
        assert result.policy_version == "v1"
        assert result.summary.allowed is True


# ---------------------------------------------------------------------------
# PolicyInput
# ---------------------------------------------------------------------------


class TestPolicyInput:
    def test_creation(self) -> None:
        pi = PolicyInput(
            checkpoint="BeforePrompt",
            context={"org": "org1"},
            run_id="run_123",
            data=PolicyInputData(model_id="gpt-4", provider="openai"),
        )
        assert pi.checkpoint == "BeforePrompt"
        assert pi.run_id == "run_123"
        assert pi.data.model_id == "gpt-4"
        assert pi.compiled is None


# ---------------------------------------------------------------------------
# Compilation types
# ---------------------------------------------------------------------------


class TestCompiledPolicyConstraint:
    def test_creation(self) -> None:
        c = CompiledPolicyConstraint(
            id="c1",
            checkpoints=["BeforePrompt", "AfterModelOutput"],
            action="block",
            reason="test",
            code="B1",
            priority=10,
        )
        assert c.id == "c1"
        assert len(c.checkpoints) == 2
        assert c.action == "block"


class TestDisclosureTypes:
    def test_disclosure_rule(self) -> None:
        rule = DisclosureRule(
            id="dr1",
            match=DisclosureRuleMatch(event_types=["model.request"]),
            reveal=DisclosureRuleReveal(fields=["type", "time"]),
            redact=DisclosureRuleRedact(fields=["context.actor.email"]),
        )
        assert rule.id == "dr1"
        assert rule.match.event_types == ["model.request"]

    def test_disclosure_rule_set(self) -> None:
        rs = DisclosureRuleSet(
            rules=[
                DisclosureRule(
                    id="dr1",
                    match=DisclosureRuleMatch(),
                )
            ],
            version="v1",
        )
        assert len(rs.rules) == 1
        assert rs.version == "v1"


class TestPolicySnapshot:
    def test_creation(self) -> None:
        s = PolicySnapshot(
            hash="abc123",
            algorithm="sha256",
            compiler_version="1.0",
            created_at="2024-01-01T00:00:00Z",
            policy_version="v1",
        )
        assert s.hash == "abc123"
        assert s.algorithm == "sha256"


# ---------------------------------------------------------------------------
# JSON Rules types
# ---------------------------------------------------------------------------


class TestJsonRuleTypes:
    def test_rule_condition(self) -> None:
        c = RuleCondition(field="data.model_id", operator="equals", value="gpt-4")
        assert c.field == "data.model_id"
        assert c.operator == "equals"

    def test_json_rule(self) -> None:
        rule = JsonRule(
            id="r1",
            name="Block GPT-4",
            checkpoints=["BeforePrompt"],
            conditions=[RuleCondition(field="data.model_id", operator="equals", value="gpt-4")],
            action="block",
            reason="GPT-4 not allowed",
            priority=10,
        )
        assert rule.id == "r1"
        assert rule.action == "block"
        assert rule.priority == 10

    def test_json_rules_config(self) -> None:
        config = JsonRulesConfig(
            rules=[
                JsonRule(
                    id="r1",
                    name="Allow all",
                    checkpoints=["BeforePrompt"],
                    conditions=[],
                    action="allow",
                )
            ],
            version="v1",
            default_action="allow",
        )
        assert len(config.rules) == 1
        assert config.version == "v1"


class TestPolicyConfigFile:
    def test_creation(self) -> None:
        cfg = PolicyConfigFile(
            policy=JsonRulesConfig(rules=[]),
            disclosure=None,
        )
        assert len(cfg.policy.rules) == 0
        assert cfg.disclosure is None
