"""Tests for arelis.evaluations.runner."""

from __future__ import annotations

import pytest

from arelis.evaluations.runner import derive_evaluation_effect, run_evaluations
from arelis.evaluations.types import (
    EvaluationEffect,
    EvaluationFinding,
    EvaluationInput,
    EvaluationResult,
)

# ---------------------------------------------------------------------------
# Stub evaluator
# ---------------------------------------------------------------------------


class _StubEvaluator:
    def __init__(
        self,
        evaluator_id: str,
        effect: EvaluationEffect = "pass",
        findings: list[EvaluationFinding] | None = None,
        time_ms: float = 0.0,
    ) -> None:
        self._id = evaluator_id
        self._effect = effect
        self._findings = findings or []
        self._time_ms = time_ms
        self.called = False

    @property
    def id(self) -> str:
        return self._id

    @property
    def version(self) -> str | None:
        return "1.0"

    async def evaluate(self, input: EvaluationInput) -> EvaluationResult:
        self.called = True
        return EvaluationResult(
            evaluator_id=self._id,
            effect=self._effect,
            findings=self._findings,
            version=self.version,
            time_ms=self._time_ms,
        )


def _make_input() -> EvaluationInput:
    return EvaluationInput(
        run_id="run_1",
        context=None,
        surface="model",
        output_ref="ref:output",
    )


# ---------------------------------------------------------------------------
# derive_evaluation_effect
# ---------------------------------------------------------------------------


class TestDeriveEvaluationEffect:
    def test_all_pass(self) -> None:
        results = [
            EvaluationResult(evaluator_id="e1", effect="pass"),
            EvaluationResult(evaluator_id="e2", effect="pass"),
        ]
        run_result = derive_evaluation_effect(results)
        assert run_result.effect == "pass"
        assert run_result.max_severity is None

    def test_warn_overrides_pass(self) -> None:
        results = [
            EvaluationResult(evaluator_id="e1", effect="pass"),
            EvaluationResult(evaluator_id="e2", effect="warn"),
        ]
        run_result = derive_evaluation_effect(results)
        assert run_result.effect == "warn"

    def test_block_overrides_warn(self) -> None:
        results = [
            EvaluationResult(evaluator_id="e1", effect="warn"),
            EvaluationResult(evaluator_id="e2", effect="block"),
        ]
        run_result = derive_evaluation_effect(results)
        assert run_result.effect == "block"

    def test_block_overrides_pass(self) -> None:
        results = [
            EvaluationResult(evaluator_id="e1", effect="pass"),
            EvaluationResult(evaluator_id="e2", effect="block"),
        ]
        run_result = derive_evaluation_effect(results)
        assert run_result.effect == "block"

    def test_max_severity_tracked(self) -> None:
        results = [
            EvaluationResult(
                evaluator_id="e1",
                effect="warn",
                findings=[
                    EvaluationFinding(id="f1", category="safety", severity="low", message="low"),
                ],
            ),
            EvaluationResult(
                evaluator_id="e2",
                effect="warn",
                findings=[
                    EvaluationFinding(
                        id="f2", category="pii", severity="critical", message="critical"
                    ),
                ],
            ),
        ]
        run_result = derive_evaluation_effect(results)
        assert run_result.max_severity == "critical"

    def test_empty_results(self) -> None:
        run_result = derive_evaluation_effect([])
        assert run_result.effect == "pass"
        assert run_result.max_severity is None
        assert run_result.results == []

    def test_severity_ordering(self) -> None:
        results = [
            EvaluationResult(
                evaluator_id="e1",
                effect="warn",
                findings=[
                    EvaluationFinding(id="f1", category="safety", severity="medium", message="m"),
                    EvaluationFinding(id="f2", category="safety", severity="high", message="h"),
                    EvaluationFinding(id="f3", category="safety", severity="info", message="i"),
                ],
            ),
        ]
        run_result = derive_evaluation_effect(results)
        assert run_result.max_severity == "high"


# ---------------------------------------------------------------------------
# run_evaluations
# ---------------------------------------------------------------------------


class TestRunEvaluations:
    @pytest.mark.asyncio
    async def test_runs_all_evaluators(self) -> None:
        e1 = _StubEvaluator("e1", effect="pass")
        e2 = _StubEvaluator("e2", effect="warn")
        result = await run_evaluations([e1, e2], _make_input())
        assert e1.called
        assert e2.called
        assert len(result.results) == 2
        assert result.effect == "warn"

    @pytest.mark.asyncio
    async def test_stop_on_block(self) -> None:
        e1 = _StubEvaluator("e1", effect="block")
        e2 = _StubEvaluator("e2", effect="pass")
        result = await run_evaluations([e1, e2], _make_input(), stop_on_block=True)
        assert e1.called
        assert not e2.called
        assert len(result.results) == 1
        assert result.effect == "block"

    @pytest.mark.asyncio
    async def test_does_not_stop_without_flag(self) -> None:
        e1 = _StubEvaluator("e1", effect="block")
        e2 = _StubEvaluator("e2", effect="pass")
        result = await run_evaluations([e1, e2], _make_input(), stop_on_block=False)
        assert e2.called
        assert len(result.results) == 2

    @pytest.mark.asyncio
    async def test_timing_measured_when_not_provided(self) -> None:
        evaluator = _StubEvaluator("e1", effect="pass", time_ms=0.0)
        result = await run_evaluations([evaluator], _make_input())
        # time_ms should be set to measured time (> 0 or close to 0)
        assert result.results[0].time_ms >= 0

    @pytest.mark.asyncio
    async def test_evaluator_reported_timing_preserved(self) -> None:
        evaluator = _StubEvaluator("e1", effect="pass", time_ms=123.45)
        result = await run_evaluations([evaluator], _make_input())
        assert result.results[0].time_ms == 123.45

    @pytest.mark.asyncio
    async def test_empty_evaluators(self) -> None:
        result = await run_evaluations([], _make_input())
        assert result.effect == "pass"
        assert result.results == []
