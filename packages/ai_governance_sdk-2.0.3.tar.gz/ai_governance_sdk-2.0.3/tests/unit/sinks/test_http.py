import asyncio
import json
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from arelis.audit.types import (
    AuditContext,
    AuditContextActor,
    AuditContextOrg,
    RunStartedEvent,
)
from arelis.sinks.http import (
    HttpAuditSink,
    HttpSinkAuthBasic,
    HttpSinkAuthBearer,
    HttpSinkAuthHeader,
    HttpSinkConfig,
)


@pytest.fixture
def mock_audit_context():
    return AuditContext(
        org=AuditContextOrg(id="org-123"),
        actor=AuditContextActor(type="user", id="user-123"),
        purpose="testing",
        environment="test",
    )


@pytest.fixture
def mock_event(mock_audit_context):
    return RunStartedEvent(
        schema_version="1.0",
        event_id="evt-123",
        time="2023-01-01T00:00:00Z",
        run_id="run-123",
        type="run.started",
        context=mock_audit_context,
    )


@pytest.mark.asyncio
async def test_write_and_flush(mock_event):
    config = HttpSinkConfig(endpoint="http://test.com/audit", batching=True, batch_size=2)
    sink = HttpAuditSink(config)

    # Mock httpx client
    mock_client = AsyncMock(spec=httpx.AsyncClient)
    dummy_request = httpx.Request("POST", config.endpoint)
    mock_client.post.return_value = httpx.Response(200, request=dummy_request)

    with patch.object(sink, "_get_client", return_value=mock_client):
        # Write one event (should be buffered)
        await sink.write(mock_event)
        mock_client.post.assert_not_called()

        # Write second event (should trigger flush)
        await sink.write(mock_event)

        assert mock_client.post.called
        call_args = mock_client.post.call_args
        payload = json.loads(call_args[1]["content"])
        assert "events" in payload
        assert len(payload["events"]) == 2
        assert payload["events"][0]["event_id"] == "evt-123"

    await sink.close()


@pytest.mark.asyncio
async def test_write_no_batching(mock_event):
    config = HttpSinkConfig(endpoint="http://test.com/audit", batching=False)
    sink = HttpAuditSink(config)

    mock_client = AsyncMock(spec=httpx.AsyncClient)
    dummy_request = httpx.Request("POST", config.endpoint)
    mock_client.post.return_value = httpx.Response(200, request=dummy_request)

    with patch.object(sink, "_get_client", return_value=mock_client):
        await sink.write(mock_event)
        mock_client.post.assert_called_once()
        payload = json.loads(mock_client.post.call_args[1]["content"])
        assert len(payload["events"]) == 1

    await sink.close()


@pytest.mark.asyncio
async def test_auth_headers(mock_event):
    # Test Bearer auth
    bearer_config = HttpSinkConfig(
        endpoint="http://test.com/audit", auth=HttpSinkAuthBearer(token="test-token")
    )
    sink = HttpAuditSink(bearer_config)
    headers = sink._build_headers()
    assert headers["Authorization"] == "Bearer test-token"

    # Test Basic auth
    basic_config = HttpSinkConfig(
        endpoint="http://test.com/audit", auth=HttpSinkAuthBasic(username="user", password="pass")
    )
    sink = HttpAuditSink(basic_config)
    headers = sink._build_headers()
    assert headers["Authorization"].startswith("Basic ")

    # Test Custom Header auth
    header_config = HttpSinkConfig(
        endpoint="http://test.com/audit",
        auth=HttpSinkAuthHeader(name="X-Audit-Key", value="secret"),
    )
    sink = HttpAuditSink(header_config)
    headers = sink._build_headers()
    assert headers["X-Audit-Key"] == "secret"


@pytest.mark.asyncio
async def test_retry_on_server_error(mock_event):
    config = HttpSinkConfig(
        endpoint="http://test.com/audit", batching=False, max_retries=1, base_delay_ms=1
    )
    sink = HttpAuditSink(config)

    mock_client = AsyncMock(spec=httpx.AsyncClient)
    dummy_request = httpx.Request("POST", config.endpoint)

    # First call fails with 500, second succeeds
    mock_client.post.side_effect = [
        httpx.Response(500, request=dummy_request),
        httpx.Response(200, request=dummy_request),
    ]

    with patch.object(sink, "_get_client", return_value=mock_client):
        await sink.write(mock_event)
        assert mock_client.post.call_count == 2

    await sink.close()


@pytest.mark.asyncio
async def test_no_retry_on_client_error(mock_event):
    config = HttpSinkConfig(
        endpoint="http://test.com/audit", batching=False, max_retries=1, base_delay_ms=1
    )
    sink = HttpAuditSink(config)

    mock_client = AsyncMock(spec=httpx.AsyncClient)
    dummy_request = httpx.Request("POST", config.endpoint)

    # 400 Bad Request should not be retried
    mock_client.post.return_value = httpx.Response(400, request=dummy_request)

    from arelis.sinks.http import HttpSinkError

    with patch.object(sink, "_get_client", return_value=mock_client):
        with pytest.raises(HttpSinkError) as excinfo:
            await sink.write(mock_event)
        assert excinfo.value.status_code == 400
        assert mock_client.post.call_count == 1

    await sink.close()


@pytest.mark.asyncio
async def test_periodic_flush(mock_event):
    config = HttpSinkConfig(
        endpoint="http://test.com/audit", batching=True, batch_size=10, flush_interval_ms=100
    )
    sink = HttpAuditSink(config)

    mock_client = AsyncMock(spec=httpx.AsyncClient)
    dummy_request = httpx.Request("POST", config.endpoint)
    mock_client.post.return_value = httpx.Response(200, request=dummy_request)

    with patch.object(sink, "_get_client", return_value=mock_client):
        await sink.write(mock_event)
        mock_client.post.assert_not_called()

        # Wait for periodic flush
        await asyncio.sleep(0.3)
        assert mock_client.post.called

    await sink.close()
