from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from arelis import (
    AgentModelResponse,
    AgentModelToolCall,
    ArelisClient,
    ArelisPlatform,
    ClientConfig,
    GovernedAgentRunInput,
    GovernedAgentTool,
    GovernedInvokeInput,
    create_arelis,
    createArelis,
)


def _runtime_config() -> ClientConfig:
    policy_engine = MagicMock()
    policy_engine.evaluate = AsyncMock(
        return_value=MagicMock(
            decisions=[],
            summary=MagicMock(allowed=True, block_reason=None, block_code=None, approvers=None),
            policy_version="v1",
        )
    )

    return ClientConfig(
        model_registry=MagicMock(),
        policy_engine=policy_engine,
        audit_sink=MagicMock(),
    )


def _json_response(payload: dict[str, object], *, status: int = 200) -> httpx.Response:
    return httpx.Response(status, json=payload, headers={"Content-Type": "application/json"})


def test_create_arelis_runtime_only() -> None:
    instance = create_arelis({"runtime": _runtime_config()})

    assert isinstance(instance["runtime"], ArelisClient)
    assert instance["platform"] is None
    assert callable(instance.governed_invoke)
    assert callable(instance.governedInvoke)
    assert callable(instance.agents.run)
    assert callable(instance.governance.get_pii_config)
    assert callable(instance.governance.getPiiConfig)


def test_create_arelis_platform_only() -> None:
    instance = create_arelis(
        {
            "platform": {
                "baseUrl": "https://api.arelis.digital",
                "apiKey": "ak_test",
            }
        }
    )

    assert isinstance(instance["platform"], ArelisPlatform)
    assert instance["runtime"] is None


def test_create_arelis_runtime_and_platform() -> None:
    instance = create_arelis(
        {
            "runtime": _runtime_config(),
            "platform": {
                "baseUrl": "https://api.arelis.digital",
                "apiKey": "ak_test",
            },
        }
    )

    assert isinstance(instance["runtime"], ArelisClient)
    assert isinstance(instance["platform"], ArelisPlatform)


def test_create_arelis_requires_one_config() -> None:
    with pytest.raises(ValueError, match="createArelis requires at least one configuration"):
        create_arelis({})


def test_create_arelis_camel_alias_warns() -> None:
    with pytest.deprecated_call():
        createArelis(
            {
                "platform": {
                    "baseUrl": "https://api.arelis.digital",
                    "apiKey": "ak_test",
                }
            }
        )


@pytest.mark.asyncio
async def test_governed_invoke_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_request(**kwargs: object) -> httpx.Response:
        url = str(kwargs["url"])

        if url.endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response(
                {
                    "data": [
                        {
                            "namespace": "pii.default",
                            "data": {
                                "customPatterns": [
                                    {
                                        "name": "ssn",
                                        "pattern": r"\d{3}-\d{2}-\d{4}",
                                        "flags": "g",
                                        "type": "custom",
                                    }
                                ]
                            },
                        }
                    ],
                    "nextCursor": None,
                }
            )

        if url.endswith("/api/v1/governance/policy/evaluate"):
            return _json_response(
                {
                    "runId": "run_unified_1",
                    "decisions": [{"policyId": "policy-1", "decision": "allow"}],
                    "evaluatedAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/events"):
            return _json_response({"eventId": "evt_1", "runId": "run_unified_1"})

        if url.endswith("/api/v1/risk/evaluate"):
            return _json_response(
                {
                    "id": "risk_1",
                    "runId": "run_unified_1",
                    "action": "allow",
                    "score": 0.1,
                    "factors": [],
                    "deterministicInputsHash": "hash_1",
                    "approvalId": None,
                }
            )

        return _json_response({}, status=404)

    monkeypatch.setattr(httpx, "request", fake_request)

    arelis = create_arelis(
        {
            "platform": {"apiKey": "ak_test", "maxRetries": 0},
        }
    )

    result = await arelis.governed_invoke(
        GovernedInvokeInput(
            run_id="run_unified_1",
            model="gemini-2.5-flash",
            prompt="my ssn is 123-45-6789",
            invoke=lambda sanitized_prompt: f"echo:{sanitized_prompt}",
        )
    )

    assert result.invoked is True
    assert isinstance(result.result, str)
    assert result.result.startswith("echo:")
    assert result.risk is not None
    assert result.risk["action"] == "allow"
    assert result.warnings is None


@pytest.mark.asyncio
async def test_governed_invoke_blocked(monkeypatch: pytest.MonkeyPatch) -> None:
    invoke = AsyncMock(return_value="should-not-run")

    def fake_request(**kwargs: object) -> httpx.Response:
        url = str(kwargs["url"])

        if url.endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response({"data": [], "nextCursor": None})

        if url.endswith("/api/v1/governance/policy/evaluate"):
            return _json_response(
                {
                    "runId": "run_unified_2",
                    "decisions": [
                        {
                            "policyId": "policy-1",
                            "decision": "deny",
                            "reason": "Blocked by policy",
                        }
                    ],
                    "evaluatedAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/events"):
            return _json_response({"eventId": "evt_1", "runId": "run_unified_2"})

        return _json_response({}, status=404)

    monkeypatch.setattr(httpx, "request", fake_request)

    arelis = create_arelis({"platform": {"apiKey": "ak_test", "maxRetries": 0}})

    result = await arelis.governed_invoke(
        GovernedInvokeInput(
            run_id="run_unified_2",
            model="gemini-2.5-flash",
            prompt="blocked prompt",
            deny_mode="return",
            invoke=invoke,
        )
    )

    assert result.invoked is False
    assert result.result is None
    invoke.assert_not_awaited()


@pytest.mark.asyncio
async def test_governed_invoke_side_effect_failures_return_warnings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_request(**kwargs: object) -> httpx.Response:
        url = str(kwargs["url"])

        if url.endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response({"data": [], "nextCursor": None})

        if url.endswith("/api/v1/governance/policy/evaluate"):
            return _json_response(
                {
                    "runId": "run_unified_3",
                    "decisions": [{"policyId": "policy-1", "decision": "allow"}],
                    "evaluatedAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/events"):
            return _json_response(
                {
                    "type": "https://arelis.dev/errors/server-error",
                    "title": "Server Error",
                    "status": 500,
                    "detail": "event write failed",
                },
                status=500,
            )

        if url.endswith("/api/v1/risk/evaluate"):
            return _json_response(
                {
                    "type": "https://arelis.dev/errors/server-error",
                    "title": "Server Error",
                    "status": 500,
                    "detail": "risk failed",
                },
                status=500,
            )

        return _json_response({}, status=404)

    monkeypatch.setattr(httpx, "request", fake_request)

    arelis = create_arelis({"platform": {"apiKey": "ak_test", "maxRetries": 0}})

    result = await arelis.governed_invoke(
        GovernedInvokeInput(
            run_id="run_unified_3",
            model="gemini-2.5-flash",
            prompt="safe prompt",
            invoke=lambda _sanitized: "ok",
        )
    )

    assert result.invoked is True
    assert result.result == "ok"
    assert result.warnings is not None
    assert len(result.warnings) > 0


@pytest.mark.asyncio
async def test_agents_run_completes_and_returns_platform_artifacts(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_request(**kwargs: object) -> httpx.Response:
        url = str(kwargs["url"])

        if url.endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response({"data": [], "nextCursor": None})

        if url.endswith("/api/v1/governance/policy/evaluate"):
            return _json_response(
                {
                    "runId": "run_agent_1",
                    "decisions": [{"policyId": "policy-1", "decision": "allow"}],
                    "evaluatedAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/events"):
            return _json_response({"eventId": "evt_1", "runId": "run_agent_1"})

        if url.endswith("/api/v1/events/batch"):
            return _json_response({"results": []})

        if "/api/v1/events?" in url:
            return _json_response({"events": [], "nextCursor": None})

        if url.endswith("/api/v1/graphs/run_agent_1"):
            return _json_response(
                {
                    "runId": "run_agent_1",
                    "schemaVersion": "1.0",
                    "rootHash": None,
                    "nodes": [],
                    "edges": [],
                    "createdAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/proofs"):
            return _json_response(
                {
                    "proofId": "proof_1",
                    "runId": "run_agent_1",
                    "schemaVersion": "v2",
                    "commitment": {},
                    "proofHash": "proof_hash",
                    "layers": [],
                    "createdAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/proofs/proof_1"):
            return _json_response(
                {
                    "proofId": "proof_1",
                    "runId": "run_agent_1",
                    "schemaVersion": "v2",
                    "commitment": {},
                    "proofHash": "proof_hash",
                    "layers": [],
                    "metadata": {},
                    "aiSystemId": None,
                    "createdAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/risk/evaluate"):
            return _json_response(
                {
                    "id": "risk_1",
                    "runId": "run_agent_1",
                    "action": "allow",
                    "score": 0.2,
                    "factors": [],
                    "deterministicInputsHash": "risk_hash",
                    "approvalId": None,
                }
            )

        return _json_response({}, status=404)

    monkeypatch.setattr(httpx, "request", fake_request)

    arelis = create_arelis({"platform": {"apiKey": "ak_test", "maxRetries": 0}})

    result = await arelis.agents.run(
        GovernedAgentRunInput(
            run_id="run_agent_1",
            model="gemini-2.5-flash",
            prompt="Find the order status.",
            tools=[GovernedAgentTool(name="lookup_order")],
            invoke_model=lambda input_data: (
                AgentModelResponse(
                    text="I need to call a tool",
                    finish_reason="tool_call",
                    tool_calls=[
                        AgentModelToolCall(
                            id="call_1",
                            name="lookup_order",
                            args={"orderId": "A-100"},
                        )
                    ],
                )
                if input_data["stepNumber"] == 1
                else AgentModelResponse(text="Order A-100 is delivered.", finish_reason="stop")
            ),
            execute_tool_call=lambda _tool_input: {"status": "delivered"},
        )
    )

    event_types = [event.type for event in result.events]

    assert result.status == "completed"
    assert len(result.steps) == 2
    assert "agent.step" in event_types
    assert "tool.call" in event_types
    assert "tool.result" in event_types
    assert len(result.graph.nodes) > 0
    assert result.proof is not None
    assert result.risk is not None
    assert result.risk["action"] == "allow"


@pytest.mark.asyncio
async def test_agents_run_events_list_fallback_and_graph_404_suppression(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_request(**kwargs: object) -> httpx.Response:
        url = str(kwargs["url"])

        if url.endswith("/api/v1/namespaces/governance-config?limit=250"):
            return _json_response({"data": [], "nextCursor": None})

        if url.endswith("/api/v1/governance/policy/evaluate"):
            return _json_response(
                {
                    "runId": "run_agent_3",
                    "decisions": [{"policyId": "policy-1", "decision": "allow"}],
                    "evaluatedAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/events"):
            return _json_response({"eventId": "evt_1", "runId": "run_agent_3"})

        if url.endswith("/api/v1/events/batch"):
            return _json_response({"results": []})

        if "/api/v1/events?" in url and "limit=" in url:
            return _json_response(
                {
                    "type": "https://api.arelis.digital/errors/bad-request",
                    "title": "Bad Request",
                    "status": 400,
                    "detail": "Invalid events query parameters.",
                },
                status=400,
            )

        if "/api/v1/events?" in url:
            return _json_response({"events": [], "nextCursor": None})

        if url.endswith("/api/v1/graphs/run_agent_3"):
            return _json_response(
                {
                    "type": "https://api.arelis.digital/errors/not-found",
                    "title": "Not Found",
                    "status": 404,
                    "detail": "Causal graph not found.",
                },
                status=404,
            )

        if url.endswith("/api/v1/proofs"):
            return _json_response(
                {
                    "proofId": "proof_3",
                    "runId": "run_agent_3",
                    "schemaVersion": "v2",
                    "commitment": {},
                    "proofHash": "proof_hash",
                    "layers": [],
                    "createdAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/proofs/proof_3"):
            return _json_response(
                {
                    "proofId": "proof_3",
                    "runId": "run_agent_3",
                    "schemaVersion": "v2",
                    "commitment": {},
                    "proofHash": "proof_hash",
                    "layers": [],
                    "metadata": {},
                    "aiSystemId": None,
                    "createdAt": "2026-01-01T00:00:00Z",
                }
            )

        if url.endswith("/api/v1/risk/evaluate"):
            return _json_response(
                {
                    "id": "risk_3",
                    "runId": "run_agent_3",
                    "action": "allow",
                    "score": 0,
                    "factors": [],
                    "deterministicInputsHash": "risk_hash",
                    "approvalId": None,
                }
            )

        return _json_response({}, status=404)

    monkeypatch.setattr(httpx, "request", fake_request)

    arelis = create_arelis({"platform": {"apiKey": "ak_test", "maxRetries": 0}})

    result = await arelis.agents.run(
        GovernedAgentRunInput(
            run_id="run_agent_3",
            model="gemini-2.5-flash",
            prompt="Find the order status.",
            tools=[GovernedAgentTool(name="lookup_order")],
            invoke_model=lambda input_data: (
                AgentModelResponse(
                    text="I need to call a tool",
                    finish_reason="tool_call",
                    tool_calls=[
                        AgentModelToolCall(
                            id="call_1",
                            name="lookup_order",
                            args={"orderId": "A-100"},
                        )
                    ],
                )
                if input_data["stepNumber"] == 1
                else AgentModelResponse(text="Order A-100 is delivered.", finish_reason="stop")
            ),
            execute_tool_call=lambda _tool_input: {"status": "delivered"},
        )
    )

    assert result.status == "completed"
    assert result.platform_events == []
    assert result.platform_graph is None
    assert result.warnings is None


@pytest.mark.asyncio
async def test_agents_run_max_steps_reached_runtime_source() -> None:
    arelis = create_arelis({"runtime": _runtime_config()})

    result = await arelis.agents.run(
        GovernedAgentRunInput(
            run_id="run_agent_2",
            model="mock-model",
            prompt="Continue forever",
            tools=[GovernedAgentTool(name="noop_tool")],
            max_steps=1,
            invoke_model=lambda _input: AgentModelResponse(
                text="Need another tool call",
                finish_reason="tool_call",
                tool_calls=[AgentModelToolCall(id="call_1", name="noop_tool", args={})],
            ),
            execute_tool_call=lambda _tool_input: {"ok": True},
        )
    )

    assert result.status == "max_steps_reached"
    assert len(result.steps) == 1
    assert any(event.type == "tool.call" for event in result.events)
    assert len(result.graph.nodes) > 0
