"""Shared test fixtures for the Arelis AI SDK test suite."""
