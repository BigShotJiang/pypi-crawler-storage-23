"""Integration tests for On-Premise provider.

Requires a running vLLM or text-generation-webui instance. Set
``ONPREMISE_BASE_URL`` to enable::

    ONPREMISE_BASE_URL=http://localhost:8000 pytest tests/integration/providers/test_onpremise.py
"""

from __future__ import annotations

import os

import pytest

BASE_URL = os.getenv("ONPREMISE_BASE_URL")

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not BASE_URL, reason="ONPREMISE_BASE_URL not set"),
]


@pytest.mark.asyncio
async def test_onpremise_generate() -> None:
    """OnPremiseProvider can generate a text response."""
    from arelis.providers.onpremise import OnPremiseProvider

    assert BASE_URL is not None
    provider = OnPremiseProvider(base_url=BASE_URL)
    # Placeholder — real test would call provider.generate()
    assert provider.id == "onpremise"
