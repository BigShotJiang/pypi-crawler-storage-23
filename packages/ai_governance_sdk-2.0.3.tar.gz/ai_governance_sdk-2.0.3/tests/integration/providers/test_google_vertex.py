"""Integration tests for Google Vertex AI provider.

These tests require valid Google Cloud credentials. Set the
``GOOGLE_VERTEX_PROJECT`` and ``GOOGLE_VERTEX_LOCATION`` environment
variables to enable them::

    GOOGLE_VERTEX_PROJECT=my-project \
        GOOGLE_VERTEX_LOCATION=us-central1 pytest tests/integration/
"""

from __future__ import annotations

import os

import pytest

PROJECT = os.getenv("GOOGLE_VERTEX_PROJECT")
LOCATION = os.getenv("GOOGLE_VERTEX_LOCATION", "us-central1")

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not PROJECT, reason="GOOGLE_VERTEX_PROJECT not set"),
]


@pytest.mark.asyncio
async def test_google_vertex_generate() -> None:
    """GoogleVertexProvider can generate a text response."""
    from arelis.providers.google_vertex import GoogleVertexProvider

    assert PROJECT is not None
    provider = GoogleVertexProvider(project=PROJECT, location=LOCATION)
    # Placeholder — real test would call provider.generate()
    assert provider.id == "google-vertex"
