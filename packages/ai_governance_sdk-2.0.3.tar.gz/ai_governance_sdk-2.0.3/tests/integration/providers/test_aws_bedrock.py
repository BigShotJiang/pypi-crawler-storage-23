"""Integration tests for AWS Bedrock provider.

Requires valid AWS credentials and Bedrock access. Set ``AWS_BEDROCK_ENABLED=1``
to enable::

    AWS_BEDROCK_ENABLED=1 pytest tests/integration/providers/test_aws_bedrock.py
"""

from __future__ import annotations

import os

import pytest

ENABLED = os.getenv("AWS_BEDROCK_ENABLED")

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not ENABLED, reason="AWS_BEDROCK_ENABLED not set"),
]


@pytest.mark.asyncio
async def test_aws_bedrock_generate() -> None:
    """AWSBedrockProvider can generate a text response."""
    from arelis.providers.aws_bedrock import AWSBedrockProvider

    provider = AWSBedrockProvider()
    # Placeholder — real test would call provider.generate()
    assert provider.id == "aws-bedrock"
