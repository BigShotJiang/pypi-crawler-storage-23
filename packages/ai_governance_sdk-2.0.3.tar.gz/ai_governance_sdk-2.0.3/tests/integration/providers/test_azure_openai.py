"""Integration tests for Azure OpenAI provider.

Requires a valid Azure OpenAI deployment. Set ``AZURE_OPENAI_ENDPOINT`` and
``AZURE_OPENAI_API_KEY`` to enable::

    AZURE_OPENAI_ENDPOINT=https://... AZURE_OPENAI_API_KEY=... \
        pytest tests/integration/providers/test_azure_openai.py
"""

from __future__ import annotations

import os

import pytest

ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not ENDPOINT or not API_KEY, reason="Azure OpenAI creds not set"),
]


@pytest.mark.asyncio
async def test_azure_openai_generate() -> None:
    """AzureOpenAIProvider can generate a text response."""
    from arelis.providers.azure_openai import AzureOpenAIProvider

    assert ENDPOINT is not None and API_KEY is not None
    provider = AzureOpenAIProvider(endpoint=ENDPOINT, api_key=API_KEY)
    # Placeholder — real test would call provider.generate()
    assert provider.id == "azure-openai"
