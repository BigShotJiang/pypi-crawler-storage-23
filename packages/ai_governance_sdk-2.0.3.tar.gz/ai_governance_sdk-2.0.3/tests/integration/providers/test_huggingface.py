"""Integration tests for HuggingFace provider.

Requires a valid Hugging Face API token. Set ``HUGGINGFACE_TOKEN`` to enable::

    HUGGINGFACE_TOKEN=hf_... pytest tests/integration/providers/test_huggingface.py
"""

from __future__ import annotations

import os

import pytest

TOKEN = os.getenv("HUGGINGFACE_TOKEN")

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not TOKEN, reason="HUGGINGFACE_TOKEN not set"),
]


@pytest.mark.asyncio
async def test_huggingface_generate() -> None:
    """HuggingFaceProvider can generate a text response."""
    from arelis.providers.huggingface import HuggingFaceProvider

    assert TOKEN is not None
    provider = HuggingFaceProvider(token=TOKEN)
    # Placeholder — real test would call provider.generate()
    assert provider.id == "huggingface"
