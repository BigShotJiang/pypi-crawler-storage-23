"""Integration tests for PostgreSQL storage backends.

These tests require a running PostgreSQL instance. Set the ``POSTGRES_URL``
environment variable to enable them::

    POSTGRES_URL=postgresql://user:pass@localhost:5432/arelis_test pytest tests/integration/storage/
"""

from __future__ import annotations

import os

import pytest

POSTGRES_URL = os.getenv("POSTGRES_URL")

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not POSTGRES_URL, reason="POSTGRES_URL not set"),
]


@pytest.mark.asyncio
async def test_postgres_audit_sink_write_and_flush() -> None:
    """PostgresAuditSink can write events and flush them."""
    from arelis.storage.postgres.audit_sink import create_postgres_audit_sink

    assert POSTGRES_URL is not None
    sink = await create_postgres_audit_sink({"dsn": POSTGRES_URL})
    # Placeholder — real test would write an event and verify
    await sink.close()


@pytest.mark.asyncio
async def test_postgres_cag_store_write_and_read() -> None:
    """PostgresCausalGraphStore can write and read graphs."""
    from arelis.storage.postgres.cag_store import create_postgres_cag_store

    assert POSTGRES_URL is not None
    store = await create_postgres_cag_store({"dsn": POSTGRES_URL})
    # Placeholder — real test would write a graph and readback
    await store.close()


@pytest.mark.asyncio
async def test_postgres_memory_provider_crud() -> None:
    """PostgresMemoryProvider can read/write/delete/list entries."""
    from arelis.storage.postgres.memory_provider import create_postgres_memory_provider

    assert POSTGRES_URL is not None
    provider = await create_postgres_memory_provider({"dsn": POSTGRES_URL})
    # Placeholder — real test would exercise CRUD
    await provider.close()
