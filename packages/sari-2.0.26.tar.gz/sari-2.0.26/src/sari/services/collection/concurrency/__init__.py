"""collection concurrency helpers."""

