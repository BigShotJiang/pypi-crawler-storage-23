from setuptools import setup, find_packages

setup(
    name="hiosw-harp",
    version="1.0.0",
    description="Network Auto-Discovery Service for TAFTP Protocol Stack",
    packages=find_packages(),
    # ВОТ ОНО - МАГИЯ ЗАВИСИМОСТИ
    install_requires=[
        "taftp>=5.0.1", 
        "rich",
        "psutil",
        "requests"
    ],
    python_requires='>=3.12',
    classifiers=[
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Networking",
    ],
)