import socket
import time
import psutil
from typing import List, Dict

# КРИТИЧЕСКАЯ ЗАВИСИМОСТЬ:
try:
    from taftp import TAFTPPacket, TAFTPConnection
except ImportError:
    # Если библиотеки нет, HARP выбрасывает исключение при импорте
    raise ImportError(
        "\n[!] ОШИБКА: Библиотека 'taftp' (ядро HioSW) не установлена.\n"
        "[!] HARP является надстройкой над TAFTP и не может работать автономно.\n"
        "[!] Установите ядро: pip install taftp"
    )

class HARPRadar:
    """
    HioSW Address Resolution Protocol.
    Использует транспортный уровень TAFTP для поиска узлов в подсети.
    """
    def __init__(self, port: int = 55555):
        self.port = port
        self.magic_marker = "HIOSW_NODE_DISCOVERY"
        # Создаем пакет через движок TAFTP
        self.node = TAFTPConnection(mtu=64)
        self.scan_pkt = TAFTPPacket("SYN", 0, 0, self.magic_marker).pack()

    def get_local_subnet(self) -> str:
        """Автоматическое определение текущей подсети."""
        for interface, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == socket.AF_INET and not addr.address.startswith("127."):
                    return ".".join(addr.address.split('.')[:-1])
        return "127.0.0"

    def broadcast_scan(self):
        """Рассылка широковещательного запроса по всей подсети."""
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            # Отправка на broadcast-адрес подсети
            s.sendto(self.scan_pkt.encode('utf-8'), ("<broadcast>", self.port))

    def listen_responses(self, timeout=2.5) -> List[str]:
        """Сбор ответов от узлов, распознающих сигнатуру TAFTP."""
        found_ips = []
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", self.port))
            s.settimeout(timeout)
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    data, addr = s.recvfrom(1024)
                    # Попытка декапсуляции пакета через TAFTP-движок
                    pkt = TAFTPPacket.unpack(data.decode('utf-8'))
                    if pkt and self.magic_marker in pkt.data:
                        if addr not in found_ips:
                            found_ips.append(addr)
                except:
                    break
        return found_ips

def scan():
    """Публичный API для автоматического поиска соседей."""
    radar = HARPRadar()
    radar.broadcast_scan()
    return radar.listen_responses()