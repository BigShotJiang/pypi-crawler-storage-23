"""
BMAD Story Automation - CLI tools for BMAD workflow automation

This package provides three CLI tools:
- bmad: Unified CLI entry point with interactive menu
- bmad-runner: Story automation runner (create + develop + verify)
- bmad-verifier: Story validation with optional Claude AI
"""

__version__ = "0.1.0"
__author__ = "Althio"
