from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="WorkflowInternalMetadata")


@_attrs_define
class WorkflowInternalMetadata:
    """Backend workflow metadata exposed read-only for internal observability.

    Attributes:
        has_unaddressed_error (bool | None | Unset): True when at least one run has failed and remains unaddressed.
        last_errored_run_start (datetime.datetime | None | Unset): Start timestamp of the most recent
            errored/task_failed run.
        last_errored_run_uuid (None | Unset | UUID): Run UUID of the most recent errored/task_failed run.
    """

    has_unaddressed_error: bool | None | Unset = UNSET
    last_errored_run_start: datetime.datetime | None | Unset = UNSET
    last_errored_run_uuid: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        has_unaddressed_error: bool | None | Unset
        if isinstance(self.has_unaddressed_error, Unset):
            has_unaddressed_error = UNSET
        else:
            has_unaddressed_error = self.has_unaddressed_error

        last_errored_run_start: None | str | Unset
        if isinstance(self.last_errored_run_start, Unset):
            last_errored_run_start = UNSET
        elif isinstance(self.last_errored_run_start, datetime.datetime):
            last_errored_run_start = self.last_errored_run_start.isoformat()
        else:
            last_errored_run_start = self.last_errored_run_start

        last_errored_run_uuid: None | str | Unset
        if isinstance(self.last_errored_run_uuid, Unset):
            last_errored_run_uuid = UNSET
        elif isinstance(self.last_errored_run_uuid, UUID):
            last_errored_run_uuid = str(self.last_errored_run_uuid)
        else:
            last_errored_run_uuid = self.last_errored_run_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if has_unaddressed_error is not UNSET:
            field_dict["has_unaddressed_error"] = has_unaddressed_error
        if last_errored_run_start is not UNSET:
            field_dict["last_errored_run_start"] = last_errored_run_start
        if last_errored_run_uuid is not UNSET:
            field_dict["last_errored_run_uuid"] = last_errored_run_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_has_unaddressed_error(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        has_unaddressed_error = _parse_has_unaddressed_error(d.pop("has_unaddressed_error", UNSET))

        def _parse_last_errored_run_start(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_errored_run_start_type_0 = isoparse(data)

                return last_errored_run_start_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_errored_run_start = _parse_last_errored_run_start(d.pop("last_errored_run_start", UNSET))

        def _parse_last_errored_run_uuid(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_errored_run_uuid_type_0 = UUID(data)

                return last_errored_run_uuid_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        last_errored_run_uuid = _parse_last_errored_run_uuid(d.pop("last_errored_run_uuid", UNSET))

        workflow_internal_metadata = cls(
            has_unaddressed_error=has_unaddressed_error,
            last_errored_run_start=last_errored_run_start,
            last_errored_run_uuid=last_errored_run_uuid,
        )

        workflow_internal_metadata.additional_properties = d
        return workflow_internal_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
