from enum import Enum


class RunStatus(str, Enum):
    CANCELLED = "cancelled"
    ERROR = "error"
    RUNNING = "running"
    SCHEDULING = "scheduling"
    SUCCESS = "success"
    TASK_FAILED = "task_failed"

    def __str__(self) -> str:
        return str(self.value)
