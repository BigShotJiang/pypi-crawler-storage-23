# FILE TO SET DECAY NAME

sample_decay = 'Lb2LPsimm'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
