from cbtesting.helpers import tuple_maker

# ONLY CONFIG NEEDED
tuple_name     = 'Lb2JpsiL_eeTuple' # BECAUSE THIS RECONSTRUCTS Lb2Lee with Jpsi resonance

tuple_maker.tuple_maker( tuple_name, upstream_electrons=True) #False )

