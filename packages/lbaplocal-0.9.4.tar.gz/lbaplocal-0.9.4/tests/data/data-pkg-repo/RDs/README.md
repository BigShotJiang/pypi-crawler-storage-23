# R Ds ntuple options

Options files for creating ntuples for the measurement of R Ds

## Datasets


## Monte Carlo samples

* 13266069: [[B_s0]cc ==> (D_s- ==> K+ K- pi-) pi+ pi+ pi- ]CC (normalization channel)
