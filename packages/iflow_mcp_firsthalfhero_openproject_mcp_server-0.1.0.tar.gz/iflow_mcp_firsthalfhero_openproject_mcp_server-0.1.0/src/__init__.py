"""OpenProject MCP Server - MVP Implementation."""
__version__ = "0.1.0"


