"""MCP request handlers for OpenProject integration."""



