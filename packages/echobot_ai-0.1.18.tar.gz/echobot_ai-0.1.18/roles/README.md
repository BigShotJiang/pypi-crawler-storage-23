# Roles - 角色系统

echobot 的角色系统用于做三件事：
- 路由：根据任务类型选择最合适的角色。
- 权限：不同角色使用不同工具边界。
- 交付：按角色风格输出稳定结果。

## 目录结构

```
roles/
├── default/              # 默认助手（通用）
├── orchestrator/         # 总控协作角色（多角色拆分与汇总）
├── fitness/              # 健身管家（训练/饮食/执行）
├── finance/              # 理财管家（记账/预算/资产）
├── ceo/                  # CEO 战略官
├── cto/                  # CTO 架构官
├── product/              # 产品经理
├── interaction/          # 交互设计师
├── ui/                   # UI 视觉设计师
├── fullstack/            # 全栈工程师
├── qa/                   # 质量保障
├── marketing/            # 增长营销
├── operations/           # 运营经理
├── sales/                # 商业销售
├── coder/                # 编程角色
├── text_assistant/       # 文本助手（写作/润色/摘要/翻译）
├── excel_assistant/      # Excel 助手（表格清洗/公式/透视）
├── excel_processor/      # Excel 处理助手（处理导向：清洗/修复/导出）
├── data_analyst/         # 数据分析师（指标/SQL/洞察）
├── analyzer/             # 历史分析师角色（兼容保留）
├── tester/               # 测试角色（受限权限）
└── lanyangyang/          # 风格化角色
```

## 推荐分层

### 总入口

- `orchestrator`
  - 适用：跨职能复杂任务、方案评审、综合决策。
  - 特点：拆题、并行协作、统一结论。
- `fitness`
  - 适用：健身训练、饮食控制、减脂增肌执行。
- `finance`
  - 适用：理财记账、预算控制、资产结构梳理。

### 专家角色

- `ceo`
  - 适用：战略方向、优先级、投入产出与里程碑。
- `cto`
  - 适用：架构评审、技术选型、性能与可靠性治理。
- `product`
  - 适用：需求拆解、MVP 设计、验收标准定义。
- `interaction`
  - 适用：用户流程、状态反馈、异常恢复路径设计。
- `ui`
  - 适用：视觉体系、组件样式、可访问性视觉优化。
- `fullstack`
  - 适用：端到端实现、联调、部署与回滚。
- `qa`
  - 适用：风险识别、测试策略、发布门禁。
- `marketing`
  - 适用：定位叙事、发布文案、渠道增长方案。
- `operations`
  - 适用：上线排期、监控告警、SOP 与复盘闭环。
- `sales`
  - 适用：定价、销售漏斗、成交推进策略。
- `text_assistant`
  - 适用：文档写作、润色改写、摘要翻译。
- `excel_assistant`
  - 适用：Excel/CSV 清洗、公式排查、透视与报表。
- `excel_processor`
  - 适用：明确“处理并交付文件”的 Excel/CSV 任务（清洗、修复、导出）。
- `data_analyst`
  - 适用：指标分析、SQL、趋势与业务解读。

### 其他角色

- `coder`：代码开发与调试。
- `tester`：最小权限验证角色。
- `analyzer`：旧分析角色，建议逐步迁移到 `excel_assistant` 与 `data_analyst`。

## 触发与优先级

- 自动触发基于 `trigger_keywords` + `trigger_patterns`。
- 多角色同时匹配时，按 `priority` 决定（数字越大优先级越高）。
- 手动指定 `--role` 的优先级最高。

## 使用方式

### CLI 指定角色

```bash
# 网关使用总入口角色
# 注：实际端口等参数按你的部署配置调整

echobot gateway --role orchestrator

# 单次 agent 使用专家角色

echobot agent --role text_assistant -m "把这段会议纪要润色成公告"
echobot agent --role excel_assistant -m "清洗 sales.xlsx 并给出透视汇总"
echobot agent --role excel_processor -m "修复 sales.xlsx 公式并导出清洗结果"
echobot agent --role data_analyst -m "用 SQL 分析近30天留存趋势"

# 查看可用角色

echobot roles
```

### 代码中切换角色

```python
from echobot.roles import RoleManager

manager = RoleManager()
manager.switch_role("excel_assistant")
print(manager.get_current_role().name)
```

## 创建新角色

1. 新建目录：`roles/<name>/`
2. 添加 `config.yaml`（元信息、触发词、技能、工具、权限、优先级）
3. 添加 `SKILL.md`（工作方式与输出规范）
4. 运行 `echobot roles` 验证是否成功加载

## 设计建议

- 角色只做“路由 + 权限 + 交付风格”。
- 复杂能力优先放在 skill（可复用脚本与知识）。
- 复杂跨域任务统一由 `orchestrator` 汇总，不要让每个角色都内置总控逻辑。
