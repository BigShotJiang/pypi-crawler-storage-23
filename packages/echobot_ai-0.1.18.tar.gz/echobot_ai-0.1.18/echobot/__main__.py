# 中文注释：
# 文件：echobot/__main__.py
# 说明：项目核心源码。

"""
入口模块 - 通过 python -m echobot 直接运行

使用示例：
    python -m echobot agent -m "Hello!"    # 直接与 Agent 对话
    python -m echobot gateway              # 启动网关服务
    python -m echobot onboard              # 初始化配置
"""

from loguru import logger
import sys

# 默认移除所有日志处理器（静默模式）
logger.remove()


from echobot.cli.commands import app


if __name__ == "__main__":
    app()
