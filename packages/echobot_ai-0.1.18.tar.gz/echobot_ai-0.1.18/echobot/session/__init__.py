# 中文注释：
# 文件：echobot/session/__init__.py
# 说明：会话状态与持久化管理。

"""Session management module."""

from echobot.session.manager import SessionManager, Session

__all__ = ["SessionManager", "Session"]
