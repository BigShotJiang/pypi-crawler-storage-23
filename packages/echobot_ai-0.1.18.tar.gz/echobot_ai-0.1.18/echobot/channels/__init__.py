# 中文注释：
# 文件：echobot/channels/__init__.py
# 说明：渠道适配层，负责 Telegram/DingTalk 等消息收发。

"""Chat channels module with plugin architecture."""

from echobot.channels.base import BaseChannel
from echobot.channels.manager import ChannelManager

__all__ = ["BaseChannel", "ChannelManager"]
