# 中文注释：
# 文件：echobot/skills/xlsx/scripts/office/helpers/__init__.py
# 说明：项目核心源码。

