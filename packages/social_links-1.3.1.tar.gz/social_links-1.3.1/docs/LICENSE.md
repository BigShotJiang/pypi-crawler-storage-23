---
title: MIT License

description: "MIT License terms and permissions for social-links Python library. Free to use, modify, and distribute this open source social media URL validation and parsing tool."

keywords:
  - MIT License
  - open source license
  - social-links license
  - Python library license
  - free software
  - open source terms
  - license permissions
  - redistribution rights
  - modification rights
  - software license
---

--8<-- "LICENSE"

