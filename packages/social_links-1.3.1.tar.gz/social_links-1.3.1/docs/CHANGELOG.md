---
title: Changelog

description: "Complete changelog and version history for social-links Python library. Track new features, bug fixes, platform additions, and updates for social media URL validation and parsing."

keywords:
  - changelog
  - version history
  - release notes
  - social-links updates
  - Python library changelog
  - social media URL validator updates
  - new features
  - bug fixes
  - platform additions
  - version releases
  - update history
---

--8<-- "CHANGELOG.md"

