from setuptools import setup


setup(
    name='python-josso-auth',
    description='A JOSSO backend for python-social-auth',
    keywords='python-social-auth,social-auth-app-django,sso,josso',
    version='0.2.1',
    packages=['josso'],
    package_dir={'josso': 'josso'},
    package_data={'josso': ['wsdl/*.xml']},
    install_requires=['social-auth-app-django', 'suds-jurko', 'six'],
    url='https://github.com/consbio/python-josso-auth',
    license='BSD'
)
