# Changelog

All notable changes to **smello-server** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.2.1] - 2026-02-23

## [0.2.0] - 2026-02-23

### Added

- `GET /api/meta` endpoint returning distinct hosts and methods for filter dropdowns.
- React SPA frontend (MUI, TanStack Query, jotai) replacing Jinja2/HTMX server-side rendering.
- `SMELLO_FRONTEND_DIR` env var to serve pre-built frontend assets from FastAPI.
- Multi-stage Dockerfile building both frontend and server.

### Removed

- Jinja2 templates, HTMX, and all server-side rendered web routes.
- `jinja2` dependency.

## [0.1.2] - 2026-02-20

## [0.1.1] - 2025-01-01

### Fixed

- Fix bump recipes: add `--frozen` to prevent `uv.lock` modification.

## [0.1.0] - 2025-01-01

- Initial release.
