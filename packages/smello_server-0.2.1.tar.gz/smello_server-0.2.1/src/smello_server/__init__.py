"""Smello Server - HTTP request inspection dashboard."""

__version__ = "0.2.1"
