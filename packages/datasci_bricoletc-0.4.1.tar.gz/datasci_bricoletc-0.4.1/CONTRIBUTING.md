## Build, release

Using [uv](https://docs.astral.sh/uv/):

```sh
uv sync
uv lock
# Optional: codebase formatting
# uv format
rm dist/*
uv build
# Here, can use tokens: https://pypi.org/manage/account/token/
uv publish
```
