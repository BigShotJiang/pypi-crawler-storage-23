"""Test runner commands for executing service tests locally."""

import asyncio
import json
import os
from datetime import UTC, datetime
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from .api import UnitySvcAPI
from .output import format_output

app = typer.Typer(help="Run and manage service tests")
console = Console()


class TestRunner(UnitySvcAPI):
    """Run tests for services locally and submit results to backend."""

    async def list_documents(self, service_id: str, executable_only: bool = True) -> list[dict[str, Any]]:
        """List documents for a service."""
        params = {"executable_only": "true"} if executable_only else {}
        result = await self.get(f"/seller/services/{service_id}/documents", params=params)
        # API may return list directly or wrapped in {"data": [...]}
        if isinstance(result, list):
            return result
        return result.get("data", [])

    async def get_document(self, document_id: str, file_content: bool = False) -> dict[str, Any]:
        """Get document details, optionally with file content."""
        params = {"file_content": "true"} if file_content else {}
        return await self.get(f"/seller/documents/{document_id}", params=params)

    async def update_test_result(
        self,
        document_id: str,
        status: str,
        tests: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update document test metadata with execution results."""
        data: dict[str, Any] = {
            "status": status,
            "executed_at": datetime.now(UTC).isoformat(),
        }
        if tests is not None:
            data["tests"] = tests

        return await self.patch(f"/seller/documents/{document_id}", json_data=data)

    async def list_interfaces(self, service_id: str) -> list[dict[str, Any]]:
        """List all access interfaces for a service from the backend."""
        result = await self.get(f"/seller/services/{service_id}/interfaces")
        if isinstance(result, list):
            return result
        return result.get("data", [])

    async def resolve_service_id_from_document(self, document_id: str) -> str:
        """Look up the service ID that owns a document.

        Fetches the document to get its entity_id, then searches seller
        services to find the one whose listing or offering matches.

        Raises:
            ValueError: When the owning service cannot be found.
        """
        doc = await self.get_document(document_id)
        entity_id = doc.get("entity_id", "")

        services = await self.get("/seller/services")
        service_list = services.get("data", services) if isinstance(services, dict) else services

        for svc in service_list:
            svc_id = str(svc.get("id", ""))
            listing_id = str(svc.get("listing_id", ""))
            offering_id = str(svc.get("offering_id", ""))
            if entity_id and entity_id in (svc_id, listing_id, offering_id):
                return svc_id

        raise ValueError(f"Cannot find service for document {document_id} (entity_id={entity_id})")

    async def skip_test(self, document_id: str) -> dict[str, Any]:
        """Mark a test as skipped."""
        return await self.post(f"/seller/documents/{document_id}/skip")

    async def unskip_test(self, document_id: str) -> dict[str, Any]:
        """Remove skip status from a test."""
        return await self.post(f"/seller/documents/{document_id}/unskip")


@app.command("list")
def list_tests(
    service_id: str = typer.Argument(
        None, help="Service ID (supports partial IDs). If not specified, lists tests for all services."
    ),
    all_docs: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Show all documents, not just executable ones",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Include test result details (exit_code, stdout, stderr)",
    ),
    status_filter: str = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by test status (e.g. success, script_failed, pending)",
    ),
    format: str = typer.Option(
        "table",
        "--format",
        "-f",
        help="Output format: table, json, tsv, csv",
    ),
):
    """List testable documents for a service or all services.

    By default, shows only executable documents (code_example, connectivity_test).
    Use --all to show all documents. Use --verbose to include stdout/stderr from
    test results.

    Examples:
        usvc services list-tests                        # All services
        usvc services list-tests 297040cd               # Specific service
        usvc services list-tests --all                  # Include non-executable docs
        usvc services list-tests --format json
        usvc services list-tests -v --status success    # Successful tests with stdout
        usvc services list-tests -v -f json             # Full results as JSON
    """

    async def _list():
        async def _fetch_interfaces(runner: TestRunner, svc_id: str) -> list[tuple[str, str]]:
            try:
                interfaces = await runner.list_interfaces(svc_id)
                return _resolve_interfaces(interfaces)
            except Exception:
                return [("default", "")]

        async with TestRunner() as runner:
            if service_id:
                # Pass partial ID directly to backend - it handles resolution
                svc_data = await runner.get(f"/seller/services/{service_id}/data")
                full_id = svc_data.get("service_id", service_id)
                svc_name = svc_data.get("service_name", full_id[:8])
                docs = await runner.list_documents(full_id, executable_only=not all_docs)
                interfaces = await _fetch_interfaces(runner, full_id)
                return [(full_id, svc_name, docs, interfaces)]
            else:
                # List all services first, then get documents for each
                services = await runner.get("/seller/services")
                service_list = services.get("data", services) if isinstance(services, dict) else services

                results = []
                for svc in service_list:
                    svc_id = str(svc.get("id", ""))
                    svc_name = svc.get("name", svc_id[:8])
                    try:
                        docs = await runner.list_documents(svc_id, executable_only=not all_docs)
                        if docs:
                            interfaces = await _fetch_interfaces(runner, svc_id)
                            results.append((svc_id, svc_name, docs, interfaces))
                    except Exception:
                        # Skip services that fail (e.g., no documents)
                        pass
                return results

    try:
        results = asyncio.run(_list())

        # Flatten into one row per (doc, interface) pair
        rows: list[dict[str, str]] = []
        for svc_id, svc_name, docs, interfaces in results:
            for doc in docs:
                meta = doc.get("meta") or {}
                test_meta = meta.get("test") or {}
                doc_id = doc.get("id", "")
                doc_status = test_meta.get("status", "pending")

                if status_filter and doc_status != status_filter:
                    continue

                if verbose:
                    # Build one row per interface from test results
                    test_results = test_meta.get("tests") or {}
                    if test_results:
                        for iface_name, iface_data in test_results.items():
                            rows.append(
                                {
                                    "service_name": svc_name,
                                    "service_id": svc_id[:8] + "..." if svc_id else "-",
                                    "doc_id": doc_id[:8] + "..." if doc_id else "-",
                                    "title": doc.get("title", ""),
                                    "category": doc.get("category", ""),
                                    "interface": iface_name,
                                    "status": iface_data.get("status", doc_status),
                                    "exit_code": str(iface_data.get("exit_code", "")),
                                    "stdout": (iface_data.get("stdout", "") or "").strip(),
                                    "stderr": (iface_data.get("stderr", "") or "").strip(),
                                }
                            )
                    else:
                        for iface_name, _iface_url in interfaces:
                            rows.append(
                                {
                                    "service_name": svc_name,
                                    "service_id": svc_id[:8] + "..." if svc_id else "-",
                                    "doc_id": doc_id[:8] + "..." if doc_id else "-",
                                    "title": doc.get("title", ""),
                                    "category": doc.get("category", ""),
                                    "interface": iface_name,
                                    "status": doc_status,
                                    "exit_code": "",
                                    "stdout": "",
                                    "stderr": "",
                                }
                            )
                else:
                    for iface_name, iface_url in interfaces:
                        rows.append(
                            {
                                "service_id": svc_id[:8] + "..." if svc_id else "-",
                                "service_name": svc_name,
                                "doc_id": doc_id[:8] + "..." if doc_id else "-",
                                "title": doc.get("title", ""),
                                "category": doc.get("category", ""),
                                "interface": iface_name,
                                "interface_base_url": iface_url,
                                "status": doc_status,
                            }
                        )

        if verbose:
            columns = [
                "service_name",
                "service_id",
                "doc_id",
                "title",
                "interface",
                "status",
                "exit_code",
                "stdout",
                "stderr",
            ]
        else:
            columns = ["service_name", "service_id", "doc_id", "title", "category", "interface", "status"]

        format_output(
            rows,
            output_format=format,
            columns=columns,
            column_styles={
                "service_name": "cyan",
                "service_id": "dim",
                "doc_id": "yellow",
                "title": "white",
                "category": "blue",
                "interface": "magenta",
            },
            title="Service Tests",
            console=console,
        )

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)


def _find_document(documents: list[dict], title: str | None, doc_id: str | None) -> dict:
    """Find a document by title or document ID."""
    if doc_id:
        # Find by document ID (supports partial)
        doc = next((d for d in documents if str(d.get("id", "")).startswith(doc_id)), None)
        if not doc:
            raise ValueError(f"Document not found with ID: {doc_id}")
        return doc
    elif title:
        # Find by title
        doc = next((d for d in documents if d.get("title") == title), None)
        if not doc:
            available = [d.get("title") for d in documents]
            raise ValueError(f"Document not found: '{title}'. Available: {available}")
        return doc
    else:
        raise ValueError("Either --title or --doc-id must be specified")


def _resolve_interfaces(interfaces: list[dict]) -> list[tuple[str, str]]:
    """Extract (name, base_url) pairs from interface list.

    Filters out inactive interfaces. The backend resolves
    ``${GATEWAY_BASE_URL}`` placeholders before returning data,
    so base_url values are ready to use as-is.
    """
    result = []
    for iface in interfaces:
        if not iface.get("is_active", True):
            continue
        result.append((iface.get("name", "default"), iface.get("base_url", "")))

    if not result:
        result.append(("default", ""))

    return result


@app.command("show")
def show_test(
    service_id: str = typer.Argument(None, help="Service ID (required when using --title)"),
    title: str = typer.Option(None, "--title", "-t", help="Document title to show (requires service_id)"),
    doc_id: str = typer.Option(None, "--doc-id", "-d", help="Document ID (supports partial IDs)"),
    script: bool = typer.Option(
        False,
        "--script",
        "-s",
        help="Show script content and execution environment (for debugging)",
    ),
    format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, table, tsv, csv",
    ),
):
    """Show test details and metadata for a document.

    When --doc-id is provided, service_id is not required since the document ID
    uniquely identifies the document. When --title is used, service_id is required
    to search within the service's documents.

    Examples:
        usvc services show-test -d abc123
        usvc services show-test -d abc123 --script
        usvc services show-test 297040cd --title "Quick Start"
        usvc services show-test 297040cd -t "Connectivity Test" --format table
    """
    if not title and not doc_id:
        console.print("[red]Error: Either --title or --doc-id must be specified[/red]")
        raise typer.Exit(code=1)

    if title and not service_id:
        console.print("[red]Error: service_id is required when using --title[/red]")
        raise typer.Exit(code=1)

    async def _show():
        async with TestRunner() as runner:
            if doc_id:
                # doc_id uniquely identifies the document, no need for service_id
                document = await runner.get_document(doc_id, file_content=script)
            else:
                # --title requires listing documents for the service first
                documents = await runner.list_documents(service_id, executable_only=False)
                doc = _find_document(documents, title, doc_id)
                document = await runner.get_document(doc["id"], file_content=script)

            # Resolve interfaces to get actual SERVICE_BASE_URL when showing script
            interfaces_list = []
            if script:
                resolved_sid = service_id
                if not resolved_sid:
                    try:
                        resolved_sid = await runner.resolve_service_id_from_document(document.get("id", doc_id or ""))
                    except Exception:
                        pass
                if resolved_sid:
                    try:
                        interfaces_data = await runner.list_interfaces(resolved_sid)
                        interfaces_list = _resolve_interfaces(interfaces_data)
                    except Exception:
                        pass

            return document, interfaces_list

    try:
        document, interfaces_list = asyncio.run(_show())

        if script:
            # Show script content for debugging
            console.print(f"[bold cyan]Document:[/bold cyan] {document.get('title', 'Unknown')}")
            console.print(f"[dim]ID: {document.get('id')}[/dim]")
            console.print(f"[dim]MIME type: {document.get('mime_type')}[/dim]")
            console.print()

            # Show environment variables needed to run the script
            if interfaces_list:
                console.print("[bold yellow]Environment Variables:[/bold yellow]")
                for iface_name, iface_url in interfaces_list:
                    if len(interfaces_list) > 1:
                        console.print(f"  # {iface_name}")
                    console.print(f"  SERVICE_BASE_URL={iface_url or '<gateway_url>'}")
                console.print("[bold yellow]Set before running:[/bold yellow]")
            else:
                console.print("[bold yellow]Environment Variables (set these before running):[/bold yellow]")
                console.print("  SERVICE_BASE_URL=<gateway_url>")
            console.print("  UNITYSVC_API_KEY=<your_customer_api_key>")
            console.print()

            # Show script content
            file_content = document.get("file_content")
            if file_content:
                console.print("[bold yellow]Script Content:[/bold yellow]")
                console.print("-" * 60)
                console.print(file_content)
                console.print("-" * 60)
            else:
                console.print("[yellow]No script content available[/yellow]")

        elif format == "json":
            console.print(json.dumps(document, indent=2, default=str))
        elif format in ("tsv", "csv"):
            sep = "\t" if format == "tsv" else ","
            meta = document.get("meta") or {}
            test_meta = meta.get("test") or {}
            fields = ["id", "title", "category", "mime_type", "status"]
            print(sep.join(fields))
            row = [
                document.get("id", ""),
                document.get("title", ""),
                document.get("category", ""),
                document.get("mime_type", ""),
                test_meta.get("status", "pending"),
            ]
            if format == "csv":
                row = [f'"{v}"' if "," in str(v) or '"' in str(v) else str(v) for v in row]
            print(sep.join(str(v) for v in row))
        elif format == "table":
            table = Table(title=f"Document: {title}")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="white")

            # Show main fields
            for key in ["id", "title", "category", "mime_type", "filename", "filesize"]:
                if key in document:
                    table.add_row(key, str(document[key]) if document[key] is not None else "-")

            # Show test metadata
            meta = document.get("meta") or {}
            test_meta = meta.get("test") or {}
            if test_meta:
                table.add_row("[bold]test[/bold]", "")
                for key, value in test_meta.items():
                    if value is not None:
                        display_value = str(value)
                        if len(display_value) > 100:
                            display_value = display_value[:100] + "..."
                        table.add_row(f"  {key}", display_value)

            console.print(table)
        else:
            console.print(f"[red]Unknown format: {format}[/red]")
            raise typer.Exit(code=1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)


@app.command("run")
def run_test(
    service_id: str = typer.Argument(
        None, help="Service ID (supports partial IDs). Required unless --doc-id or --all is provided."
    ),
    title: str = typer.Option(None, "--title", "-t", help="Only run test with this title (runs all if not specified)"),
    doc_id: str = typer.Option(
        None,
        "--doc-id",
        "-d",
        help="Only run test with this document ID (supports partial). When provided, service_id is optional.",
    ),
    all_services: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Run tests for ALL services (ignores SERVICE_ID)",
    ),
    timeout: int = typer.Option(
        30,
        "--timeout",
        help="Execution timeout in seconds",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output including stdout/stderr",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Force rerun all tests (ignore previous success status)",
    ),
    fail_fast: bool = typer.Option(
        False,
        "--fail-fast",
        "-x",
        help="Stop on first failure",
    ),
    concurrency: int = typer.Option(
        1,
        "--concurrency",
        "-j",
        help="Number of services to test in parallel (only with --all)",
    ),
):
    """Run tests locally and submit results to backend.

    By default, runs ALL executable tests for the service. Use --title or --doc-id
    to run a specific test. Use --all to run tests for every service.
    Use --all -j 4 to run 4 services in parallel.

    When --doc-id is provided, service_id is optional — the service is inferred
    from the document's entity.

    Fetches scripts from the backend and executes locally. SERVICE_BASE_URL is set
    automatically per access interface. Set UNITYSVC_API_KEY to your ops_customer
    team API key before running tests:

        export UNITYSVC_API_KEY=svcpass_your_customer_api_key

    Results are submitted back to the backend to update test metadata.

    Examples:
        # Run all tests for a service
        usvc services run-tests 297040cd

        # Run tests for ALL services
        usvc services run-tests --all

        # Run specific test by title
        usvc services run-tests 297040cd --title "Quick Start"

        # Run specific test by document ID (no service_id needed)
        usvc services run-tests -d abc123

        # Run specific test by document ID with explicit service
        usvc services run-tests 297040cd -d abc123

        # Run with verbose output
        usvc services run-tests 297040cd --verbose

        # Force rerun (ignore previous success)
        usvc services run-tests 297040cd --force

        # Stop on first failure
        usvc services run-tests 297040cd --fail-fast
    """
    if not service_id and not doc_id and not all_services:
        console.print("[red]Error: Either SERVICE_ID argument, --doc-id, or --all must be provided[/red]")
        raise typer.Exit(code=1)
    from .utils import execute_script_content

    def _execute_script(file_content: str, mime_type: str, output_contains: str | None, resolved_base_url: str) -> dict:
        """Execute a single script with the given base URL. Returns result dict."""
        exec_env: dict[str, str] = {}
        if resolved_base_url:
            exec_env["SERVICE_BASE_URL"] = resolved_base_url

        try:
            result = execute_script_content(
                script=file_content,
                mime_type=mime_type,
                env_vars=exec_env,
                timeout=timeout,
                output_contains=output_contains,
            )
            return {
                "exit_code": result.get("exit_code", -1),
                "stdout": result.get("stdout", ""),
                "stderr": result.get("stderr", ""),
                "status": result.get("status", "task_failed"),
                "error": result.get("error"),
            }
        except Exception as e:
            return {
                "exit_code": -1,
                "stdout": "",
                "stderr": str(e),
                "status": "task_failed",
                "error": str(e),
            }

    async def _run_for_service(
        runner: TestRunner,
        resolved_service_id: str,
        out: Console,
        svc_name: str = "",
        filter_title: str | None = None,
        filter_doc_id: str | None = None,
    ) -> tuple[list[dict], bool]:
        """Run tests for a single service. Returns (results, stop_early)."""
        documents = await runner.list_documents(resolved_service_id, executable_only=True)

        if not documents:
            out.print("[yellow]No testable documents found.[/yellow]")
            return [], False

        if filter_title or filter_doc_id:
            doc = _find_document(documents, filter_title, filter_doc_id)
            documents = [doc]

        try:
            interfaces_data = await runner.list_interfaces(resolved_service_id)
            interfaces_list = _resolve_interfaces(interfaces_data)
        except Exception:
            interfaces_list = [("default", "")]

        api_key = os.environ.get("UNITYSVC_API_KEY", "")
        if interfaces_list or api_key:
            for iface_name, iface_url in interfaces_list:
                out.print(f"[dim]{iface_name}: SERVICE_BASE_URL={iface_url}[/dim]")
            api_key_display = f"{api_key[:12]}...{api_key[-4:]}" if len(api_key) > 20 else api_key
            out.print(f"[dim]UNITYSVC_API_KEY={api_key_display or '(not set)'}[/dim]")
            out.print()
        else:
            out.print("[yellow]Warning: No interfaces found and UNITYSVC_API_KEY is not set[/yellow]")
            out.print()

        multi_interface = len(interfaces_list) > 1
        stop_early = False
        results = []
        for doc in documents:
            if stop_early:
                break

            doc_title = doc.get("title", doc.get("id", ""))
            document_id = doc["id"]

            meta = doc.get("meta") or {}
            test_meta = meta.get("test") or {}
            if not force:
                status = test_meta.get("status")
                if status == "success":
                    label = f"{doc_title} (all interfaces)" if multi_interface else doc_title
                    out.print(f"[cyan]Running: {label}...[/cyan]")
                    out.print("  [yellow]SKIP[/yellow] (already passed)")
                    results.append({"title": doc_title, "status": "skipped", "reason": "already passed"})
                    continue
                if status == "skip":
                    label = f"{doc_title} (all interfaces)" if multi_interface else doc_title
                    out.print(f"[cyan]Running: {label}...[/cyan]")
                    out.print("  [yellow]SKIP[/yellow] (marked as skip)")
                    results.append({"title": doc_title, "status": "skipped", "reason": "marked as skip"})
                    continue

            full_doc = await runner.get_document(document_id, file_content=True)
            file_content = full_doc.get("file_content")
            if not file_content:
                out.print(f"[cyan]Running: {doc_title}...[/cyan]")
                out.print("  [yellow]SKIP[/yellow] (no file content)")
                results.append({"title": doc_title, "status": "skipped", "reason": "no file content"})
                continue

            mime_type = full_doc.get("mime_type", "")
            full_meta = full_doc.get("meta") or {}
            output_contains = full_meta.get("output_contains")

            doc_results = []
            for iface_name, resolved_url in interfaces_list:
                label = f"{doc_title} [{iface_name}]" if multi_interface else doc_title
                out.print(f"[cyan]Running: {label}...[/cyan]")

                result = await asyncio.to_thread(
                    _execute_script,
                    file_content,
                    mime_type,
                    output_contains,
                    resolved_url,
                )
                result["title"] = label
                result["interface"] = iface_name
                result["resolved_base_url"] = resolved_url
                result["file_content"] = file_content
                doc_results.append(result)
                results.append(result)

                if result["status"] == "success":
                    out.print("  [green]PASS[/green]")
                else:
                    out.print(f"  [red]FAIL[/red] ({result['status']})")
                    if result.get("error"):
                        out.print(f"  [red]Error: {result['error']}[/red]")

                if result["status"] != "success":
                    filename = doc.get("filename", "")
                    script_stem = os.path.splitext(filename)[0] if filename else doc.get("id", "unknown")[:8]
                    safe_iface = iface_name.replace(" ", "_").replace("/", "_")
                    base_name = f"failed_{resolved_service_id}_{script_stem}_{safe_iface}"
                    if result.get("file_content"):
                        ext = os.path.splitext(filename)[1] if filename else ""
                        script_name = f"{base_name}{ext}"
                        with open(script_name, "w") as f:
                            f.write(result["file_content"])
                        os.chmod(script_name, 0o755)
                        out.print(f"  [dim]script: {script_name}[/dim]")
                    if result.get("stdout"):
                        with open(f"{base_name}.out", "w") as f:
                            f.write(result["stdout"])
                        out.print(f"  [dim]stdout: {base_name}.out[/dim]")
                    if result.get("stderr"):
                        with open(f"{base_name}.err", "w") as f:
                            f.write(result["stderr"])
                        out.print(f"  [dim]stderr: {base_name}.err[/dim]")
                    env_path = f"{base_name}.env"
                    with open(env_path, "w") as f:
                        f.write(f"SERVICE_BASE_URL={resolved_url}\n")
                        f.write(f"UNITYSVC_API_KEY={os.environ.get('UNITYSVC_API_KEY', '')}\n")
                    out.print(f"  [dim]   env: {env_path}[/dim]")

                if fail_fast and result["status"] != "success":
                    out.print("[red]Stopping on first failure (--fail-fast)[/red]")
                    stop_early = True
                    break

            if doc_results:
                failed = [r for r in doc_results if r["status"] not in ("success", "skipped")]
                worst = failed[0] if failed else doc_results[0]
                iface_results: dict[str, Any] = {}
                for r in doc_results:
                    entry: dict[str, Any] = {"status": r["status"]}
                    if r.get("exit_code") is not None:
                        entry["exit_code"] = r["exit_code"]
                    if r.get("error"):
                        entry["error"] = r["error"]
                    if r.get("stdout"):
                        entry["stdout"] = r["stdout"][:10000]
                    if r.get("stderr"):
                        entry["stderr"] = r["stderr"][:10000]
                    iface_results[r.get("interface", "default")] = entry
                try:
                    await runner.update_test_result(
                        document_id=document_id,
                        status=worst["status"],
                        tests=iface_results,
                    )
                except Exception as update_error:
                    out.print(f"  [yellow]Warning: Failed to update test result: {update_error}[/yellow]")

        return results, stop_early

    async def _run():
        import io

        async with TestRunner() as runner:
            if all_services:
                services = await runner.get("/seller/services")
                service_list = services.get("data", services) if isinstance(services, dict) else services
                total = len(service_list)
                console.print(f"[bold]Running tests for {total} services (concurrency={concurrency})...[/bold]\n")

                all_results: list[dict] = []
                completed = 0

                if concurrency <= 1:
                    # Sequential mode — print directly to console
                    for idx, svc in enumerate(service_list, 1):
                        svc_id = str(svc.get("id", ""))
                        svc_name = svc.get("name", svc_id[:8])
                        console.print(f"[bold cyan]\\[{idx}/{total}] {svc_name}[/bold cyan] ({svc_id[:8]}...)")
                        try:
                            svc_results, stop = await _run_for_service(
                                runner,
                                svc_id,
                                out=console,
                                svc_name=svc_name,
                            )
                            all_results.extend(svc_results)
                            if stop:
                                break
                        except Exception as e:
                            console.print(f"  [red]Error: {e}[/red]")
                        console.print()
                else:
                    # Parallel mode — buffer output per service, flush when done
                    sem = asyncio.Semaphore(concurrency)
                    stop_all = asyncio.Event()

                    async def _worker(idx: int, svc: dict) -> list[dict]:
                        nonlocal completed
                        if stop_all.is_set():
                            return []
                        async with sem:
                            if stop_all.is_set():
                                return []
                            svc_id = str(svc.get("id", ""))
                            svc_name = svc.get("name", svc_id[:8])
                            buf = io.StringIO()
                            buf_console = Console(file=buf, force_terminal=True)
                            buf_console.print(f"[bold cyan]\\[{idx}/{total}] {svc_name}[/bold cyan] ({svc_id[:8]}...)")
                            try:
                                svc_results, stop = await _run_for_service(
                                    runner,
                                    svc_id,
                                    out=buf_console,
                                    svc_name=svc_name,
                                )
                                if stop and fail_fast:
                                    stop_all.set()
                            except Exception as e:
                                buf_console.print(f"  [red]Error: {e}[/red]")
                                svc_results = []
                            buf_console.print()
                            # Flush buffered output atomically
                            completed += 1
                            console.print(buf.getvalue(), end="", highlight=False, markup=False)
                            console.print(f"[dim]  ({completed}/{total} services completed)[/dim]")
                            return svc_results

                    tasks = [_worker(idx, svc) for idx, svc in enumerate(service_list, 1)]
                    results_per_svc = await asyncio.gather(*tasks)
                    for svc_results in results_per_svc:
                        all_results.extend(svc_results)

                return all_results
            else:
                # Single service mode
                resolved_service_id = service_id
                if not resolved_service_id:
                    console.print(f"[dim]Resolving service from document {doc_id}...[/dim]")
                    resolved_service_id = await runner.resolve_service_id_from_document(doc_id)
                    console.print(f"[dim]Found service: {resolved_service_id}[/dim]\n")

                results, _ = await _run_for_service(
                    runner,
                    resolved_service_id,
                    out=console,
                    filter_title=title,
                    filter_doc_id=doc_id,
                )
                return results

    try:
        results = asyncio.run(_run())

        # Summary
        if results:
            passed = sum(1 for r in results if r["status"] == "success")
            failed = sum(1 for r in results if r["status"] not in ("success", "skipped"))
            skipped = sum(1 for r in results if r["status"] == "skipped")

            console.print()
            console.print(f"[bold]Results:[/bold] {passed} passed, {failed} failed, {skipped} skipped")

            if failed > 0:
                raise typer.Exit(code=1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)


@app.command("skip")
def skip_test(
    service_id: str = typer.Argument(None, help="Service ID (supports partial IDs). Required when using --title."),
    title: str = typer.Option(None, "--title", "-t", help="Document title to skip (requires service_id)"),
    doc_id: str = typer.Option(None, "--doc-id", "-d", help="Document ID (supports partial IDs, no service_id needed)"),
):
    """Mark a test as skipped.

    Skipped tests won't be required to pass for service approval.
    Only code_example documents can be skipped (connectivity_test cannot).

    When --doc-id is provided, service_id is not required.

    Examples:
        usvc services skip-test 297040cd --title "Optional Demo"
        usvc services skip-test -d abc123
    """
    if not title and not doc_id:
        console.print("[red]Error: Either --title or --doc-id must be specified[/red]")
        raise typer.Exit(code=1)

    if title and not service_id:
        console.print("[red]Error: service_id is required when using --title[/red]")
        raise typer.Exit(code=1)

    async def _skip():
        async with TestRunner() as runner:
            if doc_id and not service_id:
                # doc_id uniquely identifies the document
                return await runner.skip_test(doc_id)
            else:
                # Find document by title or ID within the service
                documents = await runner.list_documents(service_id, executable_only=True)
                doc = _find_document(documents, title, doc_id)
                return await runner.skip_test(doc["id"])

    try:
        asyncio.run(_skip())
        test_name = title or doc_id
        console.print(f"[green]Test '{test_name}' marked as skipped.[/green]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)


@app.command("unskip")
def unskip_test(
    service_id: str = typer.Argument(None, help="Service ID (supports partial IDs). Required when using --title."),
    title: str = typer.Option(None, "--title", "-t", help="Document title to unskip (requires service_id)"),
    doc_id: str = typer.Option(None, "--doc-id", "-d", help="Document ID (supports partial IDs, no service_id needed)"),
):
    """Remove skip status from a test.

    The test will be set to 'pending' status and can be executed again.

    When --doc-id is provided, service_id is not required.

    Examples:
        usvc services unskip-test 297040cd --title "Optional Demo"
        usvc services unskip-test -d abc123
    """
    if not title and not doc_id:
        console.print("[red]Error: Either --title or --doc-id must be specified[/red]")
        raise typer.Exit(code=1)

    if title and not service_id:
        console.print("[red]Error: service_id is required when using --title[/red]")
        raise typer.Exit(code=1)

    async def _unskip():
        async with TestRunner() as runner:
            if doc_id and not service_id:
                # doc_id uniquely identifies the document
                return await runner.unskip_test(doc_id)
            else:
                # Find document by title or ID within the service
                documents = await runner.list_documents(service_id, executable_only=True)
                doc = _find_document(documents, title, doc_id)
                return await runner.unskip_test(doc["id"])

    try:
        asyncio.run(_unskip())
        test_name = title or doc_id
        console.print(f"[green]Test '{test_name}' unskipped (status: pending).[/green]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)
