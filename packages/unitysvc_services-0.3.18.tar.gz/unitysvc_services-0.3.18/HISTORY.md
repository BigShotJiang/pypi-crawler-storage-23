# History

## 0.1.0 (2025-10-03)

* First release on PyPI.
