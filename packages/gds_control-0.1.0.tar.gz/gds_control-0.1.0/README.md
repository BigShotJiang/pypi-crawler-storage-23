# gds-control

State-space control DSL over GDS semantics — control theory with formal guarantees.

Part of the [GDS ecosystem](https://github.com/BlockScience/gds-core).
