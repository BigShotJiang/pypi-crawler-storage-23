"""plotcat - Faceted data plots."""

from dapple.extras.plotcat.plotcat import plotcat, main

__all__ = ["plotcat", "main"]
