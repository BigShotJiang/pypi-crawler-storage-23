"""dashcat - YAML-driven dashboard."""

from dapple.extras.dashcat.dashcat import dashcat, main

__all__ = ["dashcat", "main"]
