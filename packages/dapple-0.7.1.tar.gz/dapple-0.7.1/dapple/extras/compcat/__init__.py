"""compcat - Renderer comparison tool."""

from dapple.extras.compcat.compcat import compcat, main

__all__ = ["compcat", "main"]
