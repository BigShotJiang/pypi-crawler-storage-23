"""funcat - Terminal function plotter with selectable renderers."""

from dapple.extras.funcat.funcat import main

__all__ = ["main"]
