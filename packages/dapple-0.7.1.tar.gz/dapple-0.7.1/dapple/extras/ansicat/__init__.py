"""ansicat - ANSI art viewer."""

from dapple.extras.ansicat.ansicat import ansicat, main

__all__ = ["ansicat", "main"]
