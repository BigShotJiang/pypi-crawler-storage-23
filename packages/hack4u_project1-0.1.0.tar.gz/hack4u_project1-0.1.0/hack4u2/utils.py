from .courses import courses #desde courses.py (q esta en el directorio actual)importar courses que el la lista de objetos

def total_duration():

    return sum(course.duration for course in courses)
