
class Prop:
    ENCODER_KEY = 'kCEK'
    ID = 1
    NAME = 2
    VARIATIONS = 3
    M_4 = 4
    M_5 = 5
    M_6 = 6
    M_7 = 7

class VarProp:
    ENCODED_KEY = "kCEK"
    OBJECT_STRING = 1
    WEIGHT = 2