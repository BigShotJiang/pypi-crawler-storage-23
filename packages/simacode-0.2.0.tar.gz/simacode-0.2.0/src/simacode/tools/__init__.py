"""
SimaCode Tool System

This module provides a comprehensive tool framework for the SimaCode AI assistant,
enabling secure and controlled execution of various operations including file
operations, system commands, and custom tools.

The tool system is built around a plugin architecture with:
- Base tool abstractions
- Input validation and output formatting
- Permission-based access control
- Tool registration and discovery
- Execution monitoring and logging
"""

from .base import Tool, ToolResult, ToolInput, ToolRegistry, ToolResultType, execute_tool
from .bash import BashTool
from .file_read import FileReadTool
from .file_write import FileWriteTool
# EmailSendTool has been migrated to MCP server: tools/mcp_smtp_send_email.py
# from .email_send import EmailSendTool

def initialize_tools_with_session_manager(session_manager=None, config=None):
    """
    Initialize or re-register tools with SessionManager dependency.

    Args:
        session_manager: SessionManager instance to inject into tools
        config: Config instance to determine which tools to enable
    """
    # Clear existing tools to re-register with session manager
    ToolRegistry.clear()

    # Get tools configuration
    tools_config = config.tools if config else None

    # Register tools based on configuration
    tools = []

    # Register BashTool if enabled
    if tools_config is None or tools_config.bash:
        tools.append(BashTool(session_manager=session_manager))

    # Register FileReadTool if enabled
    if tools_config is None or tools_config.file_read:
        tools.append(FileReadTool(session_manager=session_manager))

    # Register FileWriteTool if enabled
    if tools_config is None or tools_config.file_write:
        tools.append(FileWriteTool(session_manager=session_manager))

    # Register all tools
    for tool in tools:
        ToolRegistry.register(tool)

    return tools


__all__ = [
    "Tool",
    "ToolResult",
    "ToolInput",
    "ToolRegistry",
    "ToolResultType",
    "execute_tool",
    "initialize_tools_with_session_manager",
    "BashTool",
    "FileReadTool",
    "FileWriteTool",
    # "EmailSendTool",  # Migrated to MCP server: tools/mcp_smtp_send_email.py
]