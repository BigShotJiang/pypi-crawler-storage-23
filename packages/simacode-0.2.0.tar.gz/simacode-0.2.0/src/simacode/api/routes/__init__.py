"""
API routes for SimaCode API service.

This package contains all the FastAPI route handlers organized by functionality.
"""