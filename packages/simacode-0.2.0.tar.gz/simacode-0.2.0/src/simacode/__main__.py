"""
Entry point for python -m simacode
"""

from .cli import main

if __name__ == "__main__":
    main()