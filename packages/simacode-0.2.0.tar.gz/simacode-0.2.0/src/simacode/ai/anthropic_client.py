"""
Anthropic (Claude) API client implementation.

This implementation references claude_engine.py for Anthropic API usage patterns.
"""

from typing import List, Dict, Any, AsyncIterator
from anthropic import AsyncAnthropic, APIError

from .base import AIClient, AIResponse, Message, Role


class AnthropicClient(AIClient):
    """Anthropic (Claude) API client implementation."""

    def __init__(self, config: Dict[str, Any]):
        """Initialize Anthropic client (references claude_engine.py implementation)."""
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.base_url = config.get("base_url")
        self.model = config.get("model", "claude-3-5-sonnet-20241022")
        self.max_tokens = config.get("max_tokens", 4000)
        self.temperature = config.get("temperature", 0.1)
        self.timeout = config.get("timeout", 60)

        if not self.api_key:
            raise ValueError("Anthropic API key is required")

        # Initialize Anthropic client (same pattern as claude_engine.py:56-61)
        client_kwargs = {
            "api_key": self.api_key,
            "timeout": self.timeout,
        }

        if self.base_url:
            client_kwargs["base_url"] = self.base_url

        self.client = AsyncAnthropic(**client_kwargs)

    @property
    def provider_name(self) -> str:
        """Get the provider name."""
        return "anthropic"

    def validate_config(self) -> bool:
        """Validate Anthropic configuration."""
        if not self.api_key or not isinstance(self.api_key, str):
            return False

        if not isinstance(self.model, str) or not self.model.strip():
            return False

        if not isinstance(self.max_tokens, int) or self.max_tokens <= 0:
            return False

        if not isinstance(self.temperature, (int, float)) or not 0 <= self.temperature <= 1:
            return False

        return True

    def update_config(self, new_config: Dict[str, Any]) -> None:
        """
        Update client configuration dynamically.

        Args:
            new_config: New configuration dictionary

        Raises:
            ValueError: If API key is missing in new config
            Exception: If configuration update fails
        """
        # Update config dictionary
        self.config.update(new_config)

        # Track if we need to recreate the client
        recreate_client = False

        # Update instance attributes
        if "api_key" in new_config:
            self.api_key = new_config["api_key"]
            if not self.api_key:
                raise ValueError("Anthropic API key is required")
            recreate_client = True

        if "base_url" in new_config:
            self.base_url = new_config["base_url"]
            recreate_client = True

        if "model" in new_config:
            self.model = new_config["model"]

        if "max_tokens" in new_config:
            self.max_tokens = new_config["max_tokens"]

        if "temperature" in new_config:
            self.temperature = new_config["temperature"]

        if "timeout" in new_config:
            self.timeout = new_config["timeout"]
            recreate_client = True

        # Recreate Anthropic client if necessary
        if recreate_client:
            client_kwargs = {
                "api_key": self.api_key,
                "timeout": self.timeout,
            }

            if self.base_url:
                client_kwargs["base_url"] = self.base_url

            self.client = AsyncAnthropic(**client_kwargs)

    def _convert_messages(self, messages: List[Message]) -> tuple[List[Dict[str, Any]], str]:
        """
        Convert Message objects to Anthropic API format.

        Anthropic has specific requirements:
        - System messages must be passed separately via 'system' parameter
        - Only 'user' and 'assistant' roles are supported in messages array

        Returns:
            Tuple of (converted_messages, system_prompt)
        """
        system_prompt = ""
        converted_messages = []

        for msg in messages:
            # Extract system message separately (Anthropic requirement)
            if msg.role == Role.SYSTEM:
                system_prompt = msg.content
            else:
                # Map to Anthropic's role format
                role_map = {
                    Role.USER: "user",
                    Role.ASSISTANT: "assistant",
                    Role.TOOL: "user",  # Tool messages are treated as user messages
                }

                anthropic_role = role_map.get(msg.role, "user")
                converted_messages.append({
                    "role": anthropic_role,
                    "content": msg.content
                })

        return converted_messages, system_prompt

    async def chat(self, messages: List[Message]) -> AIResponse:
        """
        Send chat request to Anthropic API.

        References claude_engine.py:189-217 for API call pattern.
        """
        try:
            # Convert messages to Anthropic format
            anthropic_messages, system_prompt = self._convert_messages(messages)

            # Prepare API call parameters (same structure as claude_engine.py:189-194)
            call_params = {
                "model": self.model,
                "messages": anthropic_messages,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
            }

            # Add system prompt if present
            if system_prompt:
                call_params["system"] = system_prompt

            # Call Anthropic API
            response = await self.client.messages.create(**call_params)

            # Extract response content (same pattern as claude_engine.py:197)
            if response.content and len(response.content) > 0:
                # Anthropic returns TextBlock objects
                content_text = response.content[0].text

                # 🔍 DEBUG: Log raw API response details
                import logging
                logger = logging.getLogger(__name__)
                logger.debug(f"[ANTHROPIC_CLIENT] API response received:")
                logger.debug(f"  - content_length: {len(content_text)}")
                logger.debug(f"  - stop_reason: {response.stop_reason}")
                logger.debug(f"  - model: {response.model}")
                logger.debug(f"  - input_tokens: {response.usage.input_tokens if response.usage else 0}")
                logger.debug(f"  - output_tokens: {response.usage.output_tokens if response.usage else 0}")
                logger.debug(f"  - content (last 200 chars): ...{content_text[-200:]}")

                return AIResponse(
                    content=content_text,
                    usage={
                        "input_tokens": response.usage.input_tokens if response.usage else 0,
                        "output_tokens": response.usage.output_tokens if response.usage else 0,
                        "total_tokens": (
                            (response.usage.input_tokens or 0) +
                            (response.usage.output_tokens or 0)
                        ) if response.usage else 0,
                    },
                    model=response.model,
                    finish_reason=response.stop_reason,
                    metadata={
                        "response_id": response.id,
                        "type": response.type,
                    }
                )
            else:
                raise Exception("No content in Anthropic response")

        except APIError as e:
            raise Exception(f"Anthropic API error: {e.status_code if hasattr(e, 'status_code') else 'unknown'} - {str(e)}")
        except Exception as e:
            raise Exception(f"Anthropic client error: {str(e)}")

    async def chat_stream(self, messages: List[Message]) -> AsyncIterator[str]:
        """
        Send streaming chat request to Anthropic API.

        Uses Anthropic's streaming API for real-time responses.
        """
        try:
            # Convert messages to Anthropic format
            anthropic_messages, system_prompt = self._convert_messages(messages)

            # Prepare API call parameters
            call_params = {
                "model": self.model,
                "messages": anthropic_messages,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
            }

            # Add system prompt if present
            if system_prompt:
                call_params["system"] = system_prompt

            # Call Anthropic streaming API
            async with self.client.messages.stream(**call_params) as stream:
                async for text in stream.text_stream:
                    if text:
                        yield text

        except APIError as e:
            raise Exception(f"Anthropic API error: {e.status_code if hasattr(e, 'status_code') else 'unknown'} - {str(e)}")
        except Exception as e:
            raise Exception(f"Anthropic streaming error: {str(e)}")
