"""
Cross-Package Intelligence for Antaris Pipeline

Implements intelligence flows between packages so they can mutually
inform each other's decisions:

  Memory → Router:  recall quality boosts routing confidence for known task types
  Router → Context: route cost/confidence drives context budget + depth
  Guard  → Memory:  detected threats are persisted as mistake memories for future recall
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    # Avoid hard circular imports at runtime; only used for type hints.
    from antaris_memory import MemorySystem
    from antaris_router import Router
    from antaris_context import ContextManager

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Task-type keyword sets used by memory→router flow
# ---------------------------------------------------------------------------
_TASK_KEYWORDS: Dict[str, list] = {
    "coding":     ["code", "function", "class", "debug", "implement", "refactor", "python", "javascript", "sql"],
    "writing":    ["write", "essay", "paragraph", "summarize", "rewrite", "draft", "article"],
    "analysis":   ["analyze", "compare", "evaluate", "assess", "review", "examine"],
    "math":       ["calculate", "solve", "equation", "formula", "compute", "math"],
    "research":   ["research", "find", "search", "look up", "explain", "what is", "how does"],
}


def _detect_task_type(text: str) -> Optional[str]:
    """Return the dominant task type detected in *text*, or None."""
    text_lower = text.lower()
    scores: Dict[str, int] = {}
    for task_type, keywords in _TASK_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text_lower)
        if score:
            scores[task_type] = score
    if not scores:
        return None
    return max(scores, key=lambda k: scores[k])


def _average_recall_quality(retrievals: list) -> float:
    """Return mean relevance score across *retrievals* (0.0-1.0)."""
    if not retrievals:
        return 0.0
    scores = []
    for r in retrievals:
        for key in ("relevance", "score", "similarity", "relevance_score"):
            val = r.get(key)
            if val is not None:
                scores.append(float(val))
                break
        else:
            scores.append(1.0)  # unknown → pass through at full weight
    return sum(scores) / len(scores)


# ---------------------------------------------------------------------------
# CrossPackageIntelligence
# ---------------------------------------------------------------------------

class CrossPackageIntelligence:
    """
    Applies intelligence flows that allow Antaris packages to inform each other.

    All methods are *stateless helpers* — they read existing state from package
    objects and either mutate configuration or return adjusted values.  Each
    flow is isolated so callers can pick and choose which flows to enable.
    """

    # ------------------------------------------------------------------
    # Flow 1: Memory → Router
    # ------------------------------------------------------------------

    @staticmethod
    def memory_to_router(
        memory_data: Dict[str, Any],
        router: "Router",
        request: str,
        *,
        boost_amount: float = 0.10,
        quality_threshold: float = 0.6,
    ) -> Dict[str, Any]:
        """
        Use memory recall quality to boost router confidence for familiar tasks.

        When past retrievals for the current task type were high quality the
        router already "knows" this domain well, so we nudge its confidence
        threshold down (making it *easier* to route with confidence) and record
        the boost in a metadata dict returned to the caller.

        Args:
            memory_data:       Output of pipeline.memory_retrieval() — must
                               contain a "retrievals" list.
            router:            Live Router instance.
            request:           The current user request (used for task detection).
            boost_amount:      How much to reduce confidence_threshold when
                               recall quality is high (default 0.10).
            quality_threshold: Minimum mean recall quality to trigger a boost
                               (default 0.6).

        Returns:
            Dict with keys: task_type, recall_quality, boosted (bool),
            confidence_delta (float applied), original_threshold, new_threshold.
        """
        retrievals = memory_data.get("retrievals", [])
        task_type = _detect_task_type(request)
        recall_quality = _average_recall_quality(retrievals)

        result: Dict[str, Any] = {
            "task_type": task_type,
            "recall_quality": recall_quality,
            "boosted": False,
            "confidence_delta": 0.0,
            "original_threshold": None,
            "new_threshold": None,
        }

        if task_type is None or recall_quality < quality_threshold:
            return result

        # Retrieve the current threshold from the router (attribute may vary).
        original = None
        for attr in ("confidence_threshold", "_confidence_threshold"):
            val = getattr(router, attr, None)
            if val is not None:
                original = float(val)
                break

        if original is None:
            # Router doesn't expose a threshold — nothing to boost.
            return result

        new_threshold = max(0.0, original - boost_amount)
        try:
            # Prefer the public attribute; fall back to the private one.
            if hasattr(router, "confidence_threshold"):
                router.confidence_threshold = new_threshold
            elif hasattr(router, "_confidence_threshold"):
                router._confidence_threshold = new_threshold

            result.update(
                boosted=True,
                confidence_delta=-boost_amount,
                original_threshold=original,
                new_threshold=new_threshold,
            )
            logger.debug(
                "memory_to_router: task=%s quality=%.2f threshold %.2f→%.2f",
                task_type, recall_quality, original, new_threshold,
            )
        except Exception as exc:
            logger.warning("memory_to_router: failed to apply boost: %s", exc)

        return result

    # ------------------------------------------------------------------
    # Flow 2: Router → Context
    # ------------------------------------------------------------------

    @staticmethod
    def router_to_context(
        route_decision: Dict[str, Any],
        context_manager: "ContextManager",
        *,
        base_budget: int = 8000,
        cost_tightening_factor: float = 0.5,
        low_confidence_expansion: float = 1.5,
        low_confidence_threshold: float = 0.5,
        high_cost_threshold: float = 0.10,
    ) -> Dict[str, Any]:
        """
        Use routing decision to set context token budget and depth.

        Two heuristics are applied:

        1. **Cost → tighter budget** — if the selected model is expensive
           (estimated_cost > high_cost_threshold) we halve the context budget
           to keep total cost in check.

        2. **Low confidence → more context** — if the router wasn't confident
           we give the model *more* context so it has enough signal to work with.

        Args:
            route_decision:   Dict from pipeline.smart_routing() — expects keys
                              ``estimated_cost`` and ``confidence`` (both float).
            context_manager:  Live ContextManager instance.
            base_budget:      Default token budget (tokens), default 8000.
            cost_tightening_factor:  Multiplier when cost is high (default 0.5).
            low_confidence_expansion: Multiplier when confidence is low (default 1.5).
            low_confidence_threshold: Confidence value below which we expand budget.
            high_cost_threshold: estimated_cost above which we tighten budget.

        Returns:
            Dict with keys: estimated_cost, confidence, budget_multiplier,
            new_budget, actions (list of str).
        """
        estimated_cost = float(route_decision.get("estimated_cost", 0.0))
        confidence = float(route_decision.get("confidence", 1.0))

        budget_multiplier = 1.0
        actions: list = []

        if estimated_cost > high_cost_threshold:
            budget_multiplier *= cost_tightening_factor
            actions.append(f"tightened_budget (cost={estimated_cost:.3f})")

        if confidence < low_confidence_threshold:
            budget_multiplier *= low_confidence_expansion
            actions.append(f"expanded_budget (confidence={confidence:.2f})")

        new_budget = max(1000, int(base_budget * budget_multiplier))

        # Apply to context manager — attribute names differ between versions.
        applied = False
        for attr in ("max_tokens", "_max_tokens", "budget", "_budget", "default_max_tokens"):
            if hasattr(context_manager, attr):
                try:
                    setattr(context_manager, attr, new_budget)
                    applied = True
                    break
                except Exception:
                    continue

        if not applied:
            # Try a set_budget() method if attributes failed.
            set_budget = getattr(context_manager, "set_budget", None)
            if callable(set_budget):
                try:
                    set_budget(new_budget)
                    applied = True
                except Exception as exc:
                    logger.warning("router_to_context: set_budget() failed: %s", exc)

        logger.debug(
            "router_to_context: cost=%.3f conf=%.2f multiplier=%.2f budget=%d applied=%s",
            estimated_cost, confidence, budget_multiplier, new_budget, applied,
        )

        return {
            "estimated_cost": estimated_cost,
            "confidence": confidence,
            "budget_multiplier": budget_multiplier,
            "new_budget": new_budget,
            "applied": applied,
            "actions": actions,
        }

    # ------------------------------------------------------------------
    # Flow 3: Guard → Memory
    # ------------------------------------------------------------------

    @staticmethod
    def guard_to_memory(
        guard_decision: Dict[str, Any],
        memory: "MemorySystem",
        *,
        threat_importance: float = 0.9,
    ) -> Dict[str, Any]:
        """
        Persist detected threat patterns into memory as "mistake" entries.

        If the guard flagged the interaction as unsafe, we ingest a mistake
        memory so future sessions can recall the pattern and treat it with
        heightened suspicion.

        Args:
            guard_decision:    Dict from pipeline.guard_input_scan() — expects
                               ``allowed`` (bool) and optionally ``evidence``
                               or ``message``.
            memory:            Live MemorySystem instance.
            threat_importance: Importance score attached to threat memories
                               (default 0.9 — high priority).

        Returns:
            Dict with keys: threat_detected (bool), memory_ingested (bool),
            threat_summary (str | None).
        """
        allowed = guard_decision.get("allowed", True)

        result: Dict[str, Any] = {
            "threat_detected": not allowed,
            "memory_ingested": False,
            "threat_summary": None,
        }

        if allowed:
            return result

        # Build a concise threat summary from available guard fields.
        evidence = guard_decision.get("evidence") or guard_decision.get("patterns") or []
        message = guard_decision.get("message", "")
        if isinstance(evidence, (list, tuple)) and evidence:
            evidence_str = ", ".join(str(e) for e in evidence[:5])
        elif isinstance(evidence, str):
            evidence_str = evidence
        else:
            evidence_str = message or "unknown threat"

        threat_summary = f"Threat pattern detected: {evidence_str}"
        result["threat_summary"] = threat_summary

        # Ingest as a "mistake" memory so it propagates to future recall.
        try:
            # Build tags from guard decision fields for searchability
            decision_tags = [
                f"severity:{guard_decision.get('severity', 'unknown')}",
                f"category:{guard_decision.get('category', 'unknown')}",
                "guard_threat",
            ]
            ingest_kwargs: Dict[str, Any] = {
                "content": threat_summary,
                "source": "guard_to_memory",
                "category": "security",
                "memory_type": "mistake",
                "tags": decision_tags,
            }
            # MemorySystem.ingest() signature may vary; try with kwargs then fallback.
            ingest = getattr(memory, "ingest", None) or getattr(memory, "store", None)
            if ingest is None:
                raise AttributeError("MemorySystem has no ingest() or store() method")

            ingest(**ingest_kwargs)
            result["memory_ingested"] = True
            logger.debug("guard_to_memory: ingested threat memory — %s", threat_summary)
        except Exception as exc:
            logger.warning("guard_to_memory: failed to ingest threat memory: %s", exc)

        return result


__all__ = ["CrossPackageIntelligence"]
