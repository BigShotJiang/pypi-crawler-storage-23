# mcp-scan Reference

Security scanner for AI agents, MCP servers, and agent skills by Snyk.

## Installation

```bash
# Install uv (required)
# Windows
pip install uv

# Mac/Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

## Commands

### Scan Skills

```bash
# Scan single skill
uvx mcp-scan@latest --skills ~/path/to/SKILL.md

# Scan directory
uvx mcp-scan@latest --skills ~/.claude/skills

# Full scan with all toxic flows
uvx mcp-scan@latest --skills --full-toxic-flows
```

### Scan MCP Servers

```bash
# Scan config file
uvx mcp-scan@latest ~/.vscode/mcp.json

# Auto-discover and scan all
uvx mcp-scan@latest
```

### Proxy Mode (Runtime Monitoring)

```bash
# Monitor MCP traffic in real-time
uvx --with "mcp-scan[proxy]" mcp-scan@latest proxy
```

### JSON Output

```bash
# Machine-readable output
uvx mcp-scan@latest --json --skills /path/to/scan
```

## Vulnerability Types

| Type | Description | Severity |
|------|-------------|----------|
| Prompt Injection | Malicious prompts hidden in tool descriptions | Critical |
| Tool Poisoning | Tools with harmful side effects | High |
| Toxic Flows | Dangerous tool combinations | Medium-High |
| Data Exposure | Leaking sensitive information | Medium |
| Hard-coded Secrets | API keys, tokens in code | Medium |
| Malware Payloads | Malicious code in extensions | Critical |

## CLI Options

```
--storage-file FILE    Store results location (default: ~/.mcp-scan)
--base-url URL         Verification server URL
--verbose              Detailed logging
--print-errors         Show error tracebacks
--full-toxic-flows     Show all toxic flow participants
--json                 JSON output format
--skills               Enable skill scanning
--server-timeout SEC   Connection timeout (default: 10)
--checks-per-server N  Checks per server (default: 1)
```

## Whitelist Management

```bash
# View whitelist
uvx mcp-scan@latest whitelist

# Add to whitelist
uvx mcp-scan@latest whitelist tool "tool_name" "hash"

# Reset whitelist
uvx mcp-scan@latest whitelist --reset
```

## Guardrails Config

Create `~/.mcp-scan/guardrails_config.yml`:

```yaml
client-name:
  server-name:
    guardrails:
      secrets: block  # Block secrets in calls/results
      custom_guardrails:
        - name: "Block errors"
          id: "error_filter"
          action: block
          content: |
            raise "Error found" if:
              (msg: ToolOutput)
              "error" in msg.content
```

## Resources

- GitHub: https://github.com/snyk/agent-scan
- Docs: https://invariantlabs-ai.github.io/docs/mcp-scan
- Blog: https://invariantlabs.ai/blog/introducing-mcp-scan
