# extension-agent-installer

> Secure extension installer for AI coding agents with vulnerability scanning and credential guidance

**Current Version:** 1.5.4 | [Changelog](CHANGELOG.md) | [Repository](https://github.com/lmt-expert-company/extension-agent-installer)

## Why This Skill Exists

**The AI era brings new security risks.**

AI agents like Claude Code, OpenCode, and Cursor have unprecedented access to your digital life:
- Your files and documents
- Your terminal and commands
- Your API keys and credentials
- Your browsing and communication

A single malicious extension can steal your banking credentials, exfiltrate sensitive data, or execute unauthorized transactions.

**This skill protects users who cannot verify extension safety themselves.**

Many people use AI agents but don't have the technical expertise to:
- Review extension source code
- Identify hidden malicious payloads
- Detect prompt injection attacks
- Understand what permissions an extension requires

**Our mission is to promote digital hygiene in the AI era by:**

1. **Never install blindly** - Always scan before installation
2. **Alert to risks** - Show vulnerabilities and explain what they mean
3. **Guide setup** - Help users understand what access they're granting
4. **Empower users** - Give everyone the tools to make informed decisions

Don't let your AI agent become a backdoor for attackers. Verify before you install.

---

## Features

- **Multi-Client Support** - Works with OpenCode, Claude Code, Cursor, Windsurf, Gemini CLI, Codex, GitHub Copilot
- **Security Scanning** - Dual vulnerability detection using mcp-scan (Snyk) and Agent Trust Hub (Gen Digital)
- **Credential Guidance** - Step-by-step setup help for non-technical users
- **Vulnerability Notifications** - Always alerts user before installing risky extensions
- **Auto-Detection** - Automatically determines extension type and target client
- **Dependency Checking** - Verifies required tools before installation
- **Self-Update** - Can update itself from GitHub

## Updating

To update this skill to the latest version, send this to your agent:

```
Update extension-agent-installer from https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Fetch SKILL.md from the repository
2. Compare version numbers
3. If newer version available, download and replace current SKILL.md
4. Also update scripts/ and references/ folders
5. Report what changed
```

Or simply say:
- "update extension-agent-installer"
- "check for updates"
- "обнови скилл инсталлер"

## Installation

### Quick Install (Recommended)

**Using uv (fastest):**
```bash
# Auto-detect client, install to current project
uvx extension-agent-installer install

# Install globally for all projects
uvx extension-agent-installer install --global

# Specify client
uvx extension-agent-installer install --client opencode --global
```

**Using npm:**
```bash
# Auto-detect client, install to current project
npx extension-agent-installer install

# Install globally for all projects
npx extension-agent-installer install --global

# Specify client
npx extension-agent-installer install --client opencode --global
```

### Supported Clients

| Client | `--client` value | Project Path | Global Path |
|--------|-----------------|--------------|-------------|
| OpenCode | `opencode` | `.opencode/skills/` | `~/.config/opencode/skills/` |
| Claude Code | `claude` | `.claude/skills/` | `~/.claude/skills/` |
| Cursor | `cursor` | `.cursor/skills/` | `~/.cursor/skills/` |
| Windsurf | `windsurf` | `.windsurf/skills/` | `~/.codeium/windsurf/skills/` |
| Gemini CLI | `gemini` | `.gemini/skills/` | `~/.gemini/skills/` |
| Codex | `codex` | `.agents/skills/` | `~/.agents/skills/` |
| GitHub Copilot | `copilot` | `.github/skills/` | `~/.copilot/skills/` |

### Detect Installed Clients

```bash
uvx extension-agent-installer detect
# or
npx extension-agent-installer detect
```

---

### Manual Installation (Alternative)

Choose your AI client below and copy the instruction to send to your agent.

---

### For OpenCode

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .opencode/skills/extension-agent-installer/ (project) or ~/.config/opencode/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

### For Claude Code

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .claude/skills/extension-agent-installer/ (project) or ~/.claude/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

### For Cursor

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .cursor/skills/extension-agent-installer/ (project) or ~/.cursor/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

### For Windsurf

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .windsurf/skills/extension-agent-installer/ (project) or ~/.codeium/windsurf/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

### For Gemini CLI

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .gemini/skills/extension-agent-installer/ (project) or ~/.gemini/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

### For Codex

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .agents/skills/extension-agent-installer/ (project) or ~/.agents/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

### For GitHub Copilot

**Copy and send this to your agent:**

```
Install the skill from repository: https://github.com/lmt-expert-company/extension-agent-installer

Steps:
1. Create directory: .github/skills/extension-agent-installer/ (project) or ~/.copilot/skills/extension-agent-installer/ (global)
2. Download SKILL.md from the repository and save it to the path above
3. Optionally download scripts/ and references/ folders for full functionality
4. Verify the file was created correctly
```

---

## Usage

Once installed, just give your AI agent a link to any extension:

```
Install this skill: https://github.com/user/awesome-skill
```

The agent will:
1. Fetch and analyze the extension
2. Scan for security vulnerabilities
3. Alert you to any risks found
4. Ask for your confirmation
5. Install to the correct location
6. Guide you through credential setup if needed

### Example Prompts

```
Install this MCP server: https://github.com/modelcontextprotocol/servers/tree/main/src/github
```

```
Add this plugin to opencode: https://github.com/user/opencode-wakatime
```

```
I want a notification plugin for my AI agent
```

## Security

This skill uses two complementary security scanners:

### 1. mcp-scan (Snyk)

Local static analysis that detects:
- Prompt injection attacks
- Tool poisoning attacks
- Toxic flows
- Malware payloads
- Hard-coded secrets

[GitHub Repository](https://github.com/snyk/agent-scan)

### 2. Agent Trust Hub (Gen Digital)

Cloud-based verification backed by Gen Threat Labs:
- Real-time threat intelligence
- Community-reported vulnerabilities
- Trusted developer verification

[Agent Trust Hub](https://ai.gendigital.com/agent-trust-hub)

### Vulnerability Handling

| Severity | Action |
|----------|--------|
| SAFE | Install freely |
| LOW | Warn, install |
| MEDIUM | Ask user |
| HIGH | Warn strongly, require explicit OK |
| CRITICAL | Strongly discourage, require explicit OK |

## Supported Clients

| Client | Project Path | Global Path | Docs |
|--------|--------------|-------------|------|
| OpenCode | `.opencode/skills/` | `~/.config/opencode/skills/` | [Docs](https://opencode.ai/docs/skills/) |
| Claude Code | `.claude/skills/` | `~/.claude/skills/` | [Docs](https://docs.anthropic.com/en/docs/claude-code/skills) |
| Cursor | `.cursor/skills/` | `~/.cursor/skills/` | [Docs](https://cursor.com/docs/context/skills) |
| Windsurf | `.windsurf/skills/` | `~/.codeium/windsurf/skills/` | [Docs](https://docs.windsurf.com/windsurf/cascade/skills) |
| Gemini CLI | `.gemini/skills/` | `~/.gemini/skills/` | [Docs](https://geminicli.com/docs/cli/skills/) |
| Codex | `.agents/skills/` | `~/.agents/skills/` | [Docs](https://developers.openai.com/codex/skills) |
| GitHub Copilot | `.github/skills/` | `~/.copilot/skills/` | [Docs](https://docs.github.com/en/copilot/concepts/agents/about-agent-skills) |

## Credential Setup

This skill automatically detects when extensions need credentials and guides you through setup:

1. **Detects required credentials** - API keys, tokens, OAuth
2. **Provides direct links** - URLs to get credentials
3. **Step-by-step instructions** - Plain language, no jargon
4. **Offers to help** - Can assist with configuration

### Supported Services

| Service | Credential Type |
|---------|-----------------|
| OpenAI | API Key |
| Anthropic | API Key |
| GitHub | Personal Access Token |
| Vercel | API Token |
| Sentry | Auth Token |
| Stripe | Secret Key |
| Cloudflare | API Token |

## Project Structure

```
extension-agent-installer/
├── SKILL.md                    # Main skill file
├── README.md                   # This file
├── LICENSE                     # MIT License
├── scripts/
│   ├── scan_extension.py       # mcp-scan wrapper
│   └── scan_agent_trust.py     # Agent Trust Hub API client
└── references/
    ├── mcp-scan.md             # mcp-scan documentation
    └── agent-trust-hub.md      # Agent Trust Hub documentation
```

## Inspiration & Resources

This project was inspired by and builds upon:

- [Snyk agent-scan](https://github.com/snyk/agent-scan) - Security scanner for AI agents, MCP servers and agent skills
- [Gen Digital Agent Trust Hub](https://ai.gendigital.com/agent-trust-hub) - AI agent security scanner
- [VoltAgent awesome-agent-skills](https://github.com/VoltAgent/awesome-agent-skills) - Curated collection of 380+ agent skills
- [OpenCode Documentation](https://opencode.ai/docs/) - Official OpenCode docs

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Secure Publishing (Maintainers)

For npm CI/CD publishing, this repo now uses **Trusted Publishing (OIDC)** instead of long-lived write tokens.

1. On npm, open package settings for `extension-agent-installer`
2. Configure **Trusted Publisher**:
   - Provider: GitHub Actions
   - Organization/user: `lmt-expert-company`
   - Repository: `extension-agent-installer`
   - Workflow filename: `publish.yml`
3. Keep `id-token: write` permission enabled in `.github/workflows/publish.yml`

Notes:
- This avoids OTP/token security issues in CI
- `NPM_TOKEN` is no longer required for trusted publishing
- PyPI publishing still uses `PYPI_API_TOKEN`

## License

MIT License - see [LICENSE](LICENSE) for details.

---

## Disclaimer

**IMPORTANT: Third-Party Security Tools Disclaimer**

This skill relies on **third-party security scanning tools and APIs** developed and maintained by independent organizations:

1. **mcp-scan** is developed by [Snyk](https://snyk.com/) - a third-party security company
2. **Agent Trust Hub** is operated by [Gen Digital](https://www.gendigital.com/) - a third-party security company

**The author of this skill:**

- **Does NOT guarantee** the accuracy, completeness, or reliability of security scans
- **Is NOT responsible** for any security issues that may not be detected by these third-party tools
- **Is NOT affiliated** with Snyk, Gen Digital, or any other third-party security providers
- **Cannot be held liable** for any damages resulting from the use of this skill or the third-party security tools it integrates

**Users acknowledge that:**

- Security scanning is provided by independent third parties
- Third-party tools may have limitations, bugs, or false positives/negatives
- Extensions may be modified after scanning
- Users should always review extension source code before installation
- Security tools may share data with their respective providers (see their privacy policies)

**Third-Party Terms:**

- Using mcp-scan means you agree to Snyk's [Terms of Use](https://snyk.com/policies/terms-of-use/) and [Privacy Policy](https://snyk.com/policies/privacy/)
- Using Agent Trust Hub means you agree to Gen Digital's [Terms](https://www.gendigital.com/terms) and [Privacy Policy](https://www.gendigital.com/privacy)

**Use this skill at your own risk. Always verify extensions manually before installation.**
