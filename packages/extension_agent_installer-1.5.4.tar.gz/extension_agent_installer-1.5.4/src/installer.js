#!/usr/bin/env node

/**
 * Cross-platform installer for extension-agent-installer skill.
 * Installs to OpenCode, Claude Code, Cursor, Windsurf, Gemini CLI, Codex, GitHub Copilot.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

const VERSION = '1.5.4';
const REPO_URL = 'https://github.com/lmt-expert-company/extension-agent-installer';

const CLIENTS = {
  opencode: {
    projectDir: '.opencode/skills/extension-agent-installer',
    globalDir: '.config/opencode/skills/extension-agent-installer',
    name: 'OpenCode'
  },
  claude: {
    projectDir: '.claude/skills/extension-agent-installer',
    globalDir: '.claude/skills/extension-agent-installer',
    name: 'Claude Code'
  },
  cursor: {
    projectDir: '.cursor/skills/extension-agent-installer',
    globalDir: '.cursor/skills/extension-agent-installer',
    name: 'Cursor'
  },
  windsurf: {
    projectDir: '.windsurf/skills/extension-agent-installer',
    globalDir: '.codeium/windsurf/skills/extension-agent-installer',
    name: 'Windsurf'
  },
  gemini: {
    projectDir: '.gemini/skills/extension-agent-installer',
    globalDir: '.gemini/skills/extension-agent-installer',
    name: 'Gemini CLI'
  },
  codex: {
    projectDir: '.agents/skills/extension-agent-installer',
    globalDir: '.agents/skills/extension-agent-installer',
    name: 'Codex'
  },
  copilot: {
    projectDir: '.github/skills/extension-agent-installer',
    globalDir: '.copilot/skills/extension-agent-installer',
    name: 'GitHub Copilot'
  }
};

function getPackageDir() {
  return path.join(__dirname, '..');
}

function expandPath(p) {
  if (p.startsWith('~')) {
    return path.join(os.homedir(), p.slice(1));
  }
  return path.resolve(p);
}

function detectClient() {
  const cwd = process.cwd();
  const detected = [];
  
  for (const [clientId, clientInfo] of Object.entries(CLIENTS)) {
    const projectDir = path.join(cwd, clientInfo.projectDir.split('/')[0]);
    if (fs.existsSync(projectDir)) {
      detected.push(clientId);
    }
  }
  
  return detected;
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function install(client, globalInstall = false, verbose = true) {
  if (!CLIENTS[client]) {
    console.log(`Error: Unknown client '${client}'`);
    console.log(`Available clients: ${Object.keys(CLIENTS).join(', ')}`);
    return false;
  }
  
  const clientInfo = CLIENTS[client];
  const dirKey = globalInstall ? 'globalDir' : 'projectDir';
  const targetDir = expandPath(clientInfo[dirKey]);
  
  if (verbose) {
    const scope = globalInstall ? 'global' : 'project';
    console.log(`Installing to ${clientInfo.name} (${scope})...`);
    console.log(`Target: ${targetDir}`);
  }
  
  fs.mkdirSync(targetDir, { recursive: true });
  
  const packageDir = getPackageDir();
  
  const filesToCopy = [
    ['SKILL.md', 'SKILL.md'],
    ['README.md', 'README.md'],
    ['LICENSE', 'LICENSE'],
    ['CHANGELOG.md', 'CHANGELOG.md']
  ];
  
  const dirsToCopy = ['scripts', 'references'];
  
  for (const [srcName, dstName] of filesToCopy) {
    const src = path.join(packageDir, srcName);
    const dst = path.join(targetDir, dstName);
    if (fs.existsSync(src)) {
      fs.copyFileSync(src, dst);
      if (verbose) console.log(`  Copied: ${dstName}`);
    }
  }
  
  for (const dirName of dirsToCopy) {
    const srcDir = path.join(packageDir, dirName);
    const dstDir = path.join(targetDir, dirName);
    if (fs.existsSync(srcDir)) {
      if (fs.existsSync(dstDir)) {
        fs.rmSync(dstDir, { recursive: true });
      }
      copyDir(srcDir, dstDir);
      if (verbose) console.log(`  Copied: ${dirName}/`);
    }
  }
  
  if (verbose) {
    console.log(`\nSuccess! Installed extension-agent-installer v${VERSION}`);
    console.log(`Location: ${targetDir}`);
    console.log(`\nRepository: ${REPO_URL}`);
  }
  
  return true;
}

function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  if (command === 'version' || command === '-v' || command === '--version') {
    console.log(`extension-agent-installer v${VERSION}`);
    process.exit(0);
  }
  
  if (command === 'detect') {
    const detected = detectClient();
    if (detected.length > 0) {
      console.log('Detected AI clients:');
      for (const clientId of detected) {
        console.log(`  - ${CLIENTS[clientId].name}`);
      }
    } else {
      console.log('No AI clients detected in current directory');
      console.log('\nAvailable clients:');
      for (const [clientId, info] of Object.entries(CLIENTS)) {
        console.log(`  - ${info.name}: --client ${clientId}`);
      }
    }
    process.exit(0);
  }
  
  if (command === 'install' || command === undefined) {
    let client = null;
    let globalInstall = false;
    
    for (let i = 1; i < args.length; i++) {
      if (args[i] === '--client' || args[i] === '-c') {
        client = args[++i];
      } else if (args[i] === '--global' || args[i] === '-g') {
        globalInstall = true;
      } else if (args[i] === '--project' || args[i] === '-p') {
        globalInstall = false;
      }
    }
    
    if (!client) {
      const detected = detectClient();
      if (detected.length === 1) {
        client = detected[0];
        console.log(`Auto-detected: ${CLIENTS[client].name}`);
      } else if (detected.length > 1) {
        console.log('Multiple clients detected. Please specify with --client');
        console.log(`Options: ${detected.join(', ')}`);
        process.exit(1);
      } else {
        console.log('No client detected. Please specify with --client');
        console.log(`Options: ${Object.keys(CLIENTS).join(', ')}`);
        process.exit(1);
      }
    }
    
    const success = install(client, globalInstall);
    process.exit(success ? 0 : 1);
  }
  
  console.log('Usage: extension-agent-installer install [--client CLIENT] [--global]');
  console.log('       extension-agent-installer detect');
  console.log('       extension-agent-installer version');
  process.exit(0);
}

main();
