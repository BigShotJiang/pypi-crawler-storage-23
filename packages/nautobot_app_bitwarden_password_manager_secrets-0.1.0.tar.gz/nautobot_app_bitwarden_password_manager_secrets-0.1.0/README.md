# Nautobot Bitwarden Password Manager Secrets Provider

A [Nautobot](https://nautobot.com/) app that provides a secrets provider for [Bitwarden Password Manager](https://bitwarden.com/), using the REST API exposed by `bw serve`.

## Installation

```bash
pip install nautobot-app-bitwarden-password-manager-secrets
```

## Configuration

Add the app to your `nautobot_config.py`:

```python
PLUGINS = ["nautobot_bitwarden_password_manager_secrets"]
PLUGINS_CONFIG = {
    "nautobot_bitwarden_password_manager_secrets": {
        "base_url": "http://localhost:8087",  # URL of your bw serve instance
    },
}
```

## Prerequisites

You must have the [Bitwarden CLI](https://bitwarden.com/help/cli/) installed and running `bw serve` with the vault unlocked:

```bash
bw serve --port 8087
```

## Usage

1. Navigate to **Secrets > Secrets** in Nautobot
2. Create a new Secret and select **Bitwarden Password Manager** as the provider
3. Enter the vault item ID (GUID) and select the field to retrieve

### Supported Fields

| Field | Description |
|-------|-------------|
| Username | Login username |
| Password | Login password |
| TOTP (Seed/URI) | TOTP seed or URI for 2FA |
| URI (first) | First URI associated with the login |
| Notes | Item notes |
| Custom Field | A named custom field (specify the field name) |

## License

This project is licensed under the [Mozilla Public License 2.0](LICENSE).
