"""LiveKit plugin adapters for voicetest.

Platform-specific plugins for STT, LLM, and TTS.
"""
