/* tslint:disable */
/* eslint-disable */

/**
 * A handle to a viewer instance. Each handle manages its own canvas and state.
 *
 * This struct is exposed to JavaScript and provides methods to control the viewer.
 * It holds an Rc to the widget so it can call methods on it, and also stores
 * the eframe runner for the application lifecycle.
 */
export class ViewerHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Clear all registered callbacks.
     */
    clearCallbacks(): void;
    /**
     * Create a new viewer instance attached to the given canvas element.
     * Returns a promise that resolves to a ViewerHandle when initialization completes.
     *
     * Use this static factory method instead of a constructor since async constructors
     * are deprecated in wasm-bindgen.
     */
    static create(canvas: HTMLCanvasElement): Promise<ViewerHandle>;
    /**
     * End event loop and release resources
     */
    destroy(): void;
    /**
     * Get current bias value (0.0 to 1.0, default 0.5)
     */
    getBias(): number;
    /**
     * Get the colormap name
     */
    getColormap(): string;
    /**
     * Get whether the colormap is reversed
     */
    getColormapReversed(): boolean;
    /**
     * Get current contrast value (0.0 to 10.0, default 1.0)
     */
    getContrast(): number;
    /**
     * Get point markers as a flat [x0, y0, x1, y1, ...] float array.
     */
    getMarkers(): Float32Array;
    /**
     * Get the overlay message shown at the bottom of the viewer.
     */
    getOverlayMessage(): string;
    /**
     * Get pivot point as [x, y] in image coordinates
     */
    getPivotPoint(): Float32Array;
    /**
     * Get current rotation angle in degrees (counter-clockwise)
     */
    getRotation(): number;
    /**
     * Get whether the pivot marker is visible
     */
    getShowPivotMarker(): boolean;
    /**
     * Get current stretch mode as string: "linear", "log", or "symmetric"
     */
    getStretchMode(): string;
    /**
     * Get the image value range (vmin, vmax) as [min, max]
     */
    getValueRange(): Float64Array;
    /**
     * Get visible image bounds as [xmin, xmax, ymin, ymax] in pixel coordinates.
     * Returns the portion of the image currently visible in the viewport.
     * If no image is loaded or bounds cannot be computed, returns [0, 0, 0, 0].
     */
    getViewBounds(viewport_width: number, viewport_height: number): Float64Array;
    /**
     * Get current zoom level (1.0 = fit to view)
     */
    getZoom(): number;
    /**
     * Register a callback to be called when the user shift-clicks on the image.
     * The callback receives: { x, y } in continuous image coordinates.
     */
    onClick(callback: Function): void;
    /**
     * Register a callback to be called when viewer state changes.
     * The callback receives an object with the current state:
     * { contrast, bias, stretchMode, zoom, xlim, ylim, colormap, colormapReversed, vmin, vmax }
     */
    onStateChange(callback: Function): void;
    /**
     * Set bias value (0.0 to 1.0)
     */
    setBias(bias: number): void;
    /**
     * Set the colormap by name.
     *
     * Accepted values include: Gray, Inferno, Magma, RdBu, RdYlBu.
     * Invalid names are ignored.
     */
    setColormap(name: string): void;
    /**
     * Set whether the colormap is reversed
     */
    setColormapReversed(reversed: boolean): void;
    /**
     * Set contrast value (0.0 to 10.0)
     */
    setContrast(contrast: number): void;
    /**
     * Set the image data to display.
     *
     * # Arguments
     * * `buffer` - ArrayBuffer containing the raw pixel data
     * * `width` - Image width in pixels
     * * `height` - Image height in pixels
     * * `array_type` - Rust-style type specifier:
     *   - "i8" (signed 8-bit integer)
     *   - "u8" (unsigned 8-bit integer)
     *   - "i16" (signed 16-bit integer)
     *   - "u16" (unsigned 16-bit integer)
     *   - "i32" (signed 32-bit integer)
     *   - "u32" (unsigned 32-bit integer)
     *   - "i64" (signed 64-bit integer)
     *   - "u64" (unsigned 64-bit integer)
     *   - "f32" (32-bit float)
     *   - "f64" (64-bit float, default)
     */
    setImageData(buffer: ArrayBuffer, width: number, height: number, array_type: string): void;
    /**
     * Set point markers from a flat [x0, y0, x1, y1, ...] float array.
     */
    setMarkers(flat_points: Float32Array): void;
    /**
     * Set the overlay message shown at the bottom of the viewer.
     */
    setOverlayMessage(message: string): void;
    /**
     * Set pivot point in image coordinates
     */
    setPivotPoint(x: number, y: number): void;
    /**
     * Set rotation angle in degrees (counter-clockwise)
     */
    setRotation(degrees: number): void;
    /**
     * Set whether to show the pivot marker
     */
    setShowPivotMarker(show: boolean): void;
    /**
     * Set stretch mode: "linear", "log", or "symmetric"
     */
    setStretchMode(mode: string): void;
    /**
     * Set the image value range (vmin, vmax) for display scaling
     */
    setValueRange(min_val: number, max_val: number): void;
    /**
     * Set view to show specific image bounds [xmin, xmax, ymin, ymax] in pixel coordinates.
     * This adjusts zoom and pan to display the specified region.
     */
    setViewBounds(xmin: number, xmax: number, ymin: number, ymax: number, viewport_width: number, viewport_height: number): void;
    /**
     * Set zoom level directly (1.0 = fit to view)
     */
    setZoom(level: number): void;
    /**
     * Zoom in by one step (1.25x)
     */
    zoomIn(): void;
    /**
     * Zoom out by one step (1/1.25x)
     */
    zoomOut(): void;
    /**
     * Reset zoom and pan to fit-to-view
     */
    zoomToFit(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_viewerhandle_free: (a: number, b: number) => void;
    readonly viewerhandle_clearCallbacks: (a: number) => void;
    readonly viewerhandle_create: (a: any) => any;
    readonly viewerhandle_destroy: (a: number) => void;
    readonly viewerhandle_getBias: (a: number) => number;
    readonly viewerhandle_getColormap: (a: number) => [number, number];
    readonly viewerhandle_getColormapReversed: (a: number) => number;
    readonly viewerhandle_getContrast: (a: number) => number;
    readonly viewerhandle_getMarkers: (a: number) => any;
    readonly viewerhandle_getOverlayMessage: (a: number) => [number, number];
    readonly viewerhandle_getPivotPoint: (a: number) => any;
    readonly viewerhandle_getRotation: (a: number) => number;
    readonly viewerhandle_getShowPivotMarker: (a: number) => number;
    readonly viewerhandle_getStretchMode: (a: number) => [number, number];
    readonly viewerhandle_getValueRange: (a: number) => any;
    readonly viewerhandle_getViewBounds: (a: number, b: number, c: number) => any;
    readonly viewerhandle_getZoom: (a: number) => number;
    readonly viewerhandle_onClick: (a: number, b: any) => void;
    readonly viewerhandle_onStateChange: (a: number, b: any) => void;
    readonly viewerhandle_setBias: (a: number, b: number) => void;
    readonly viewerhandle_setColormap: (a: number, b: number, c: number) => void;
    readonly viewerhandle_setColormapReversed: (a: number, b: number) => void;
    readonly viewerhandle_setContrast: (a: number, b: number) => void;
    readonly viewerhandle_setImageData: (a: number, b: any, c: number, d: number, e: number, f: number) => [number, number];
    readonly viewerhandle_setMarkers: (a: number, b: number, c: number) => void;
    readonly viewerhandle_setOverlayMessage: (a: number, b: number, c: number) => void;
    readonly viewerhandle_setPivotPoint: (a: number, b: number, c: number) => void;
    readonly viewerhandle_setRotation: (a: number, b: number) => void;
    readonly viewerhandle_setShowPivotMarker: (a: number, b: number) => void;
    readonly viewerhandle_setStretchMode: (a: number, b: number, c: number) => void;
    readonly viewerhandle_setValueRange: (a: number, b: number, c: number) => void;
    readonly viewerhandle_setViewBounds: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly viewerhandle_setZoom: (a: number, b: number) => void;
    readonly viewerhandle_zoomIn: (a: number) => void;
    readonly viewerhandle_zoomOut: (a: number) => void;
    readonly viewerhandle_zoomToFit: (a: number) => void;
    readonly wasm_bindgen__closure__destroy__h293211c26b6d7263: (a: number, b: number) => void;
    readonly wasm_bindgen__closure__destroy__h905b98c3d456fd30: (a: number, b: number) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h5ad7d9a44532e3a5: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hbce3c904773be13e: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h440c9e74639da121: (a: number, b: number) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__hfb9f1a9994119dd6: (a: number, b: number, c: any) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
