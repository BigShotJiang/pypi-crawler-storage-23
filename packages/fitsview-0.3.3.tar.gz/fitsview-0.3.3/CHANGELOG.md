# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->
## 0.3.3 (2026-02-22)

- Updated the `viewarr` submodule to `v0.3.3`.
- Pulled in upstream viewer fixes from `viewarr` since the prior submodule pin, including colorbar/contrast UX fixes and coordinate handling improvements.
- Verified the JupyterLab integration remains compatible with the existing `viewarr` API usage and rebuilt successfully.

## 0.1.0

- Initial release.

<!-- <END NEW CHANGELOG ENTRY> -->
