"""Constants for atpcli."""

# AT Protocol constants
DEFAULT_PDS_URL = "https://bsky.social"

# Spice constants
SPICE_COLLECTION_NAME = "tools.spice.note"
SPICE_MAX_TEXT_LENGTH = 256
