"""Example: Loading Phonon Data and Generating Displacements

This example demonstrates how to:
1. Load phonon data from a phonopy YAML file
2. Display mode information (frequencies, symmetry)
3. Generate thermal displacements at a specific temperature
4. Export modes to MCIF format for visualization

Usage:
    python examples/mode_decomposition.py

Requirements:
    - phononkit installed
    - A phonopy_params.yaml or phonopy.yaml file in examples/data/
"""

import numpy as np
from pathlib import Path

from phononkit import load_from_phonopy_yaml
from phononkit import generate_thermal_structure
from phononkit.io import save_mcif_file
from phononkit.analysis import generate_mode_summary


def main():
    """Run the example with real phonopy data."""
    # Path to the phonopy YAML file (BaTiO3 - Barium Titanate)
    yaml_path = Path(__file__).parent / "data" / "phonopy_params.yaml"

    if not yaml_path.exists():
        print(f"ERROR: Data file not found: {yaml_path}")
        print("Please ensure examples/data/phonopy_params.yaml exists")
        return

    print("=" * 70)
    print("Phonon Kit Example: Real Data Analysis")
    print("=" * 70)
    print(f"\nLoading: {yaml_path.name}")
    print("Material: BaTiO3 (Barium Titanate)")

    # Load phonon data
    try:
        structure, modes = load_from_phonopy_yaml(str(yaml_path))
        print(f"\n✓ Loaded successfully!")
        print(f"  Atoms: {len(structure)}")
        print(f"  Modes: {modes.n_modes}")
        print(f"  Formula: {structure.get_chemical_formula()}")
    except Exception as e:
        print(f"\n✗ Error loading data: {e}")
        return

    # Display mode summary
    print("\n" + "=" * 70)
    print("Mode Summary (Gamma Point)")
    print("=" * 70)
    summary = generate_mode_summary(modes, title="BaTiO3 Phonon Modes")
    print(summary)

    # Filter low-frequency modes (acoustic + low optical)
    print("\n" + "=" * 70)
    print("Filtering: Low-frequency modes (0-8 THz)")
    print("=" * 70)
    low_freq_modes = modes.filter_by_frequency(freq_min=0, freq_max=8)
    print(f"Found {low_freq_modes.n_modes} modes in this range")

    # Generate thermal displacement structure at 300K
    print("\n" + "=" * 70)
    print("Generating: Thermal Structure at 300K")
    print("=" * 70)
    try:
        thermal_structure = generate_thermal_structure(modes, temperature=300.0)
        print(f"✓ Generated thermal structure")
        print(f"  Temperature: 300 K")
        print(
            f"  Max displacement: {np.max(np.abs(thermal_structure.positions - structure.positions)):.4f} Å"
        )
    except Exception as e:
        print(f"✗ Error: {e}")

    # Export low-frequency modes to MCIF for visualization
    print("\n" + "=" * 70)
    print("Exporting: Low-frequency modes to MCIF")
    print("=" * 70)
    try:
        output_file = save_mcif_file(
            low_freq_modes,
            title="BaTiO3_LowFreqModes",
            filename=str(Path(__file__).parent / "BaTiO3_low_freq.mcif"),
        )
        print(f"✓ Saved to: {output_file}")
        print(f"  You can visualize this file with VESTA or Jmol")
    except Exception as e:
        print(f"✗ Error exporting MCIF: {e}")

    # Summary
    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    print(f"✓ Loaded {modes.n_modes} phonon modes from BaTiO3")
    print(f"✓ Identified {low_freq_modes.n_modes} low-frequency modes")
    print(f"✓ Generated thermal structure at 300K")
    print(f"✓ Exported MCIF file for visualization")
    print("\nNext steps:")
    print("  - Open the MCIF file in VESTA to visualize phonon modes")
    print("  - Try different temperatures for thermal displacements")
    print("  - Filter modes by different frequency ranges")


if __name__ == "__main__":
    main()
