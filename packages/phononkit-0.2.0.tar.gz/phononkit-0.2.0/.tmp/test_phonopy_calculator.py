"""
Test the PhonopyCalculator by comparing with manual calculation.
"""
import numpy as np
from ase import Atoms
from ase.build import bulk
from phononkit.calculators.phonopy_calculator import PhonopyCalculator

def test_calculator():
    print("Testing PhonopyCalculator...")
    
    # 1. Setup a simple 1-atom system (Al)
    # But for FCs we usually need a supercell. Let's make a mock FC matrix.
    atoms = bulk('Al', 'fcc', a=4.05)
    # 1x1x1 supercell = 1 atom. FC is 3x3.
    # Suppose a simple spring k=10.0 eV/A^2
    fc = np.zeros((1, 1, 3, 3))
    fc[0, 0] = np.eye(3) * 10.0
    
    calc = PhonopyCalculator(force_constants=fc, supercell=atoms)
    atoms.set_calculator(calc)
    
    # displacement u = 0.1 along x
    atoms.positions[0, 0] += 0.1
    
    forces = atoms.get_forces()
    energy = atoms.get_potential_energy()
    
    print(f"Force on atom 0: {forces[0]}")
    print(f"Energy: {energy:.6f}")
    
    # Expected F = -k*u = -10 * 0.1 = -1.0
    # Expected E = 0.5 * k * u^2 = 0.5 * 10 * 0.01 = 0.05
    assert np.allclose(forces[0], [-1.0, 0, 0])
    assert np.isclose(energy, 0.05)
    
    print("✅ Basic force/energy test passed!")

    # 2. Test Supercell
    from ase.build import make_supercell
    atoms_prim = bulk('Al', 'fcc', a=4.05)
    sc_matrix = np.diag([2, 1, 1])
    atoms_sc = make_supercell(atoms_prim, sc_matrix)
    n_atoms = len(atoms_sc) # 2 atoms
    
    # Mock FC (2, 2, 3, 3)
    # Simple diagonal spring for each atom
    fc_sc = np.zeros((n_atoms, n_atoms, 3, 3))
    for i in range(n_atoms):
        fc_sc[i, i] = np.eye(3) * 5.0
        
    calc_sc = PhonopyCalculator(force_constants=fc_sc, supercell=atoms_sc)
    atoms_sc.set_calculator(calc_sc)
    
    # Displace both atoms
    atoms_sc.positions[0, 0] += 0.2
    atoms_sc.positions[1, 1] += 0.1
    
    f_sc = atoms_sc.get_forces()
    e_sc = atoms_sc.get_potential_energy()
    
    print(f"Supercell forces:\n{f_sc}")
    print(f"Supercell energy: {e_sc:.6f}")
    
    # F0 = -5 * 0.2 = -1.0
    # F1 = -5 * 0.1 = -0.5
    assert np.allclose(f_sc[0], [-1.0, 0, 0])
    assert np.allclose(f_sc[1], [0, -0.5, 0])
    # E = 0.5 * 5 * (0.2^2 + 0.1^2) = 2.5 * (0.04 + 0.01) = 2.5 * 0.05 = 0.125
    assert np.isclose(e_sc, 0.125)
    
    print("✅ Supercell test passed!")

if __name__ == "__main__":
    test_calculator()
