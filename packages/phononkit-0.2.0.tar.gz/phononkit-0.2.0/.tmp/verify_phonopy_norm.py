"""
Test script to verify Phonopy-consistent displacement normalization.
Uses the formula extracted from phonopy/phonon/modulation.py.

Formula:
u = eigenvector * exp(i 2pi q.R_L) / sqrt(mass) / sqrt(N_atoms_supercell)
u *= phase_factor * amplitude

phase_factor:
max_elem = u[index_of_max_abs_element]
phase_for_zero = max_elem / abs(max_elem)
phase_factor = exp(1j * phase_angle) / phase_for_zero
"""

import numpy as np
from ase import Atoms
from phononkit.modes.phonon_mode import PhononMode
from phononkit.supercells.supercell import Supercell

def phonopy_modulation_formula(mode, supercell_matrix, amplitude, phase_angle_deg):
    """Manual implementation of Phonopy's modulation formula."""
    structure = mode.structure
    n_atoms_prim = len(structure)
    q = mode.qpoint
    eigvec = mode.eigenvector.reshape(n_atoms_prim, 3)
    
    # Create supercell to get positions and masses
    sc = Supercell(structure, supercell_matrix)
    n_atoms_sc = len(sc)
    masses_sc = sc.supercell.get_masses()
    spos_sc = sc.supercell.get_scaled_positions()
    
    # 1. Base displacements: eig / sqrt(m) * exp(i 2pi q.R) / sqrt(N)
    dim = supercell_matrix
    phase_factors = np.exp(2j * np.pi * np.dot(np.dot(spos_sc, dim.T), q))
    
    u = []
    for i in range(n_atoms_sc):
        i_prim = sc.atom_map[i]
        u_i = eigvec[i_prim] * phase_factors[i] / np.sqrt(masses_sc[i])
        u.append(u_i)
    
    u = np.array(u) / np.sqrt(n_atoms_sc)
    
    # 2. Phase shift logic
    u_rav = u.ravel()
    index_max = np.argmax(np.abs(u_rav))
    max_elem = u_rav[index_max]
    phase_for_zero = max_elem / np.abs(max_elem)
    
    phase_factor = np.exp(1j * np.radians(phase_angle_deg)) / phase_for_zero
    u *= phase_factor * amplitude
    
    return u

from phononkit.displacements.mode_displacement import calculate_supercell_displacement

def test_normalization():
    # Setup a simple 2-atom structure
    atoms = Atoms('NaCl', positions=[[0,0,0], [2,2,2]], cell=[4,4,4])
    eigvec = np.array([1, 0, 0, 0, 1, 0], dtype=complex) / np.sqrt(2)
    mode = PhononMode(qpoint=np.array([0.25, 0, 0]), frequency=1.0, eigenvector=eigvec, structure=atoms) # Non-zero q for phase effects
    
    supercell_matrix = np.diag([2, 1, 1]) # Smaller supercell for easy debug
    amplitude = 0.5
    phase_deg = 45.0
    phase_complex = np.exp(1j * np.radians(phase_deg))
    
    # 1. Manual Phonopy formula
    expected_u = phonopy_modulation_formula(mode, supercell_matrix, amplitude, phase_deg)
    
    # 2. My new implementation
    actual_u = calculate_supercell_displacement(
        mode, 
        supercell=supercell_matrix, 
        amplitude=amplitude, 
        phase=phase_complex, 
        normalize=True
    )
    
    diff = np.max(np.abs(expected_u - actual_u))
    print(f"Max difference: {diff:.2e}")
    
    if diff < 1e-12:
        print("✅ Phonopy-consistent normalization verified!")
    else:
        print("❌ Normalization mismatch!")
        print("Actual u:\n", actual_u)
        print("Expected u:\n", expected_u)

if __name__ == "__main__":
    test_normalization()
