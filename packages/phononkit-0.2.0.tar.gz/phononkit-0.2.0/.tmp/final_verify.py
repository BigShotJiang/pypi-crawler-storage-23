"""
Final verification of phononkit refactoring.
Tests:
1. Top-level imports
2. Displacement generation logic
3. Supercell building and mapping

How to run:
python .tmp/final_verify.py
"""
import numpy as np
from ase.build import bulk
import phononkit

def test_imports():
    print("Testing top-level imports...")
    try:
        from phononkit import PhononMode, PhononModeCollection
        from phononkit import generate_supercell_displacement
        from phononkit.supercells import Supercell
        print("✅ Imports successful")
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        raise

def test_displacement_generation():
    print("\nTesting displacement generation...")
    # Setup: Simple Primitive Cell (Al bulk)
    atoms = bulk('Al', 'fcc', a=4.05)
    
    # 1. Create a dummy PhononMode at q=(0.5, 0.5, 0.5)
    qpoint = np.array([0.5, 0.5, 0.5])
    eigenvector = np.zeros(3, dtype=complex)
    eigenvector[0] = 1.0  # Displacement along x
    
    mode = phononkit.PhononMode(
        structure=atoms,
        qpoint=qpoint,
        frequency=1.0,
        eigenvector=eigenvector
    )
    
    # 2. Generate Supercell (2x2x2)
    supercell_matrix = np.diag([2, 2, 2])
    
    # Using the new generate_supercell_displacement function
    # which uses the Supercell object internally.
    displaced_atoms = phononkit.generate_supercell_displacement(
        mode=mode,
        supercell=supercell_matrix,
        amplitude=0.1,
        real_only=True
    )
    
    print(f"Displaced atoms: {len(displaced_atoms)}")
    assert len(displaced_atoms) == 8
    
    # Check if displacements are non-zero (basic check)
    assert np.any(np.abs(displaced_atoms.positions - atoms.repeat([2,2,2]).positions) > 0)
    print("✅ Displacement generation successful")

if __name__ == "__main__":
    try:
        test_imports()
        test_displacement_generation()
        print("\n✨ All tests passed successfully!")
    except Exception as e:
        print(f"\n❌ Verification failed: {e}")
        exit(1)
