import json

def parse_irreps(txt_path, json_path):
    irreps_data = {}
    
    with open(txt_path, 'r') as f:
        lines = f.readlines()
        
    for line in lines:
        line = line.strip()
        # Skip empty lines or headers
        if not line or line.startswith('q-point') or line.startswith('Point group') or line.startswith('#'):
            continue
            
        parts = line.split()
        if len(parts) >= 7:
            try:
                # Format: qx qy qz band freq(THz) freq(cm-1) label IR Raman
                # band is 0-indexed in the file (0 to 59)
                band_idx = int(parts[3])
                freq_thz = float(parts[4])
                label = parts[6]
                
                # We'll store it by 1-indexed mode number to match our other scripts
                mode_num = band_idx + 1
                
                irreps_data[mode_num] = {
                    "index": mode_num,
                    "frequency_thz": freq_thz,
                    "label": label
                }
            except ValueError:
                continue
                
    with open(json_path, 'w') as f:
        json.dump(irreps_data, f, indent=4)
        
    print(f"Parsed {len(irreps_data)} modes and saved to {json_path}")

if __name__ == "__main__":
    parse_irreps("../TmFeO3/TmFeO3_irreps.txt", "../TmFeO3/TmFeO3_irreps.json")
