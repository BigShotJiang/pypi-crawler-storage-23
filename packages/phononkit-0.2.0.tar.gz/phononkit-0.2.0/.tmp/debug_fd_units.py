"""
Debug the energy FD unit mismatch - v2.
How to run:
    /Users/hexu/projects/phononkit_dev/phononkit/.venv/bin/python .tmp/debug_fd_units.py
"""
import numpy as np
import phonopy
import phononkit
from ase import Atoms
from phononkit.modes.phonon_mode import PhononMode
from phononkit.displacements.mode_displacement import calculate_supercell_displacement
from phononkit.supercells.supercell import Supercell

yaml_path = "Refs/phonproj/data/BaTiO3_phonopy_params.yaml"
ph = phonopy.load(yaml_path)
calc = phononkit.load_phonopy_calculator(yaml_path)

ph.run_qpoints([[0, 0, 0]], with_eigenvectors=True)
qpoints_dict = ph.get_qpoints_dict()
frequencies = qpoints_dict['frequencies'][0]
eigenvectors = qpoints_dict['eigenvectors'][0]

atoms = ph.unitcell
ase_atoms = Atoms(symbols=atoms.symbols, positions=atoms.positions, cell=atoms.cell, pbc=True)
sc_matrix = ph.supercell_matrix
sc_obj = Supercell(ase_atoms, sc_matrix)
n_sc_atoms = len(sc_obj)

amplitude = 0.01
m_idx = 14
mode = PhononMode(
    qpoint=np.array([0,0,0]),
    frequency=frequencies[m_idx],
    eigenvector=eigenvectors[:, m_idx],
    structure=ase_atoms,
    atomic_masses=ph.masses,
)

disp_plus = calculate_supercell_displacement(mode, sc_obj, amplitude=amplitude, phase=1.0, normalize=False, real_only=True)
disp_minus = calculate_supercell_displacement(mode, sc_obj, amplitude=-amplitude, phase=1.0, normalize=False, real_only=True)

print(f"amplitude = {amplitude}")
print(f"disp_plus max: {np.max(np.abs(disp_plus)):.6e}")
print(f"disp_plus norm (total): {np.linalg.norm(disp_plus):.6e}")
print(f"n_sc_atoms: {n_sc_atoms}")

# Energy
atoms_0 = sc_obj.supercell.copy()
atoms_0.calc = calc
e0 = atoms_0.get_potential_energy()

atoms_p = atoms_0.copy(); atoms_p.calc = calc; atoms_p.positions += disp_plus
ep = atoms_p.get_potential_energy()

atoms_m = atoms_0.copy(); atoms_m.calc = calc; atoms_m.positions += disp_minus
em = atoms_m.get_potential_energy()

dE = ((ep - e0) + (em - e0)) / 2.0
print(f"\ne0={e0:.6f}, ep={ep:.6f}, em={em:.6f}")
print(f"dE = {dE:.6e}")

# What amplitude^2 gives the right freq?
ref_freq = frequencies[m_idx]  # THz
const_factor = 15.633302
print(f"\nRef freq (THz): {ref_freq}")
omega2_ref = (ref_freq / const_factor)**2
print(f"Expected omega^2 = {omega2_ref:.6e}")
print(f"Needed A_eff^2 = 2*dE / omega2_ref = {2*dE / omega2_ref:.6e}")
print(f"amplitude^2 = {amplitude**2:.6e}")

# So what correction factor?
correction = 2*dE / (omega2_ref * amplitude**2)
print(f"\nCorrection factor (disp_norm_sq needed?) = {correction:.6f}")

# Compute it from the displacement itself
n_prim = mode.n_atoms
eig = mode.eigenvector.reshape(n_prim, 3)
masses = mode.atomic_masses
disp_norm_sq_prim = float(np.sum(np.abs(eig)**2 / masses[:, np.newaxis]))
print(f"disp_norm_sq (prim) = {disp_norm_sq_prim:.6f}")
print(f"disp_norm_sq (prim) * n_sc/n_prim = {disp_norm_sq_prim * n_sc_atoms / n_prim:.6f}")
