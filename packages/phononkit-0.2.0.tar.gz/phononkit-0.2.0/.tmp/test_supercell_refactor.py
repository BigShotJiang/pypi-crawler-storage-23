"""
Verify Supercell displacement refactoring.
Tests:
1. calculate_supercell_displacement returns complex array
2. generate_supercell_structure returns Atoms object with real displacement

How to run:
python .tmp/test_supercell_refactor.py
"""
import numpy as np
from ase.build import bulk
import phononkit
from phononkit.displacements.mode_displacement import (
    calculate_supercell_displacement,
    generate_supercell_structure
)

def test_supercell_functions():
    print("Testing supercell refactor...")
    atoms = bulk('Al', 'fcc', a=4.05)
    
    # Create a mode at X point (0.5, 0.5, 0.0)
    qpoint = np.array([0.5, 0.5, 0.0])
    eigenvector = np.array([1, 0, 0], dtype=complex)
    mode = phononkit.PhononMode(
        structure=atoms,
        qpoint=qpoint,
        frequency=1.0,
        eigenvector=eigenvector
    )
    
    # 2x2x2 supercell
    sc_matrix = 2 * np.eye(3)
    
    # 1. Test calculation
    displacements = calculate_supercell_displacement(mode, sc_matrix, amplitude=0.1)
    print(f"Displacements shape: {displacements.shape}")
    assert displacements.shape == (8, 3)
    assert np.iscomplexobj(displacements)
    # At X point, phase factors are 1 or -1 or i... 
    # Max real displacement should be 0.1
    print(f"Max real displacement: {np.max(np.abs(displacements.real))}")
    # With Phonopy normalization, max displacement depends on mass and 1/sqrt(N)
    assert np.max(np.linalg.norm(displacements, axis=1)) > 0
    
    # 2. Test structure generation
    displaced_atoms = generate_supercell_structure(mode, sc_matrix, amplitude=0.1)
    print(f"Number of atoms in supercell: {len(displaced_atoms)}")
    assert len(displaced_atoms) == 8
    
    # Check if displacements are applied
    orig_sc = phononkit.Supercell(atoms, sc_matrix).supercell
    diff = displaced_atoms.positions - orig_sc.positions
    print(f"Max applied displacement: {np.max(np.abs(diff))}")
    assert np.isclose(np.max(np.abs(diff)), np.max(np.abs(displacements.real)))
    
    print("✅ Supercell refactor verified")

if __name__ == "__main__":
    try:
        test_supercell_functions()
    except Exception as e:
        print(f"❌ Verification failed: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
