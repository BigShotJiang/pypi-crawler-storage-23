"""Test the energy-based finite-difference frequency extraction.

Loads BaTiO3 Phonopy data, runs calculate_mode_frequency_fd for several
modes, and compares the result against Phonopy's reference frequencies.

How to run:
    cd /Users/hexu/projects/phononkit_dev/phononkit
    python .tmp/test_frequency_fd.py

Expected behavior:
    Each tested mode should match Phonopy within ~0.1 THz (energy method is
    less precise than force projection for imaginary modes).
    The whole script should complete in under 30 seconds.
"""

import signal
import numpy as np
import os
import phonopy
import phononkit
from phononkit.displacements.frequency_fd import calculate_mode_frequency_fd
from phononkit.modes.phonon_mode import PhononMode
from ase import Atoms


TIMEOUT_SECONDS = 30


def _timeout_handler(signum, frame):
    raise TimeoutError(f"Test exceeded {TIMEOUT_SECONDS}s limit — possible infinite loop or hang.")


def main():
    yaml_path = "Refs/phonproj/data/BaTiO3_phonopy_params.yaml"

    if not os.path.exists(yaml_path):
        print(f"Error: Could not find {yaml_path}")
        return

    signal.signal(signal.SIGALRM, _timeout_handler)
    signal.alarm(TIMEOUT_SECONDS)

    try:
        print("Loading Phonopy data and Calculator...")
        ph = phonopy.load(yaml_path)
        calc = phononkit.load_phonopy_calculator(yaml_path)

        qpoint = np.array([0, 0, 0])
        ph.run_qpoints([qpoint], with_eigenvectors=True)

        qpoints_dict = ph.get_qpoints_dict()
        frequencies = qpoints_dict['frequencies'][0]
        eigenvectors = qpoints_dict['eigenvectors'][0]

        atoms = ph.unitcell
        ase_atoms = Atoms(
            symbols=atoms.symbols,
            positions=atoms.positions,
            cell=atoms.cell,
            pbc=True,
        )

        test_modes = [0, 1, 3, 14]

        print("\nEnergy-FD Frequency Extraction Test")
        print(f"{'Mode':<6} {'Phonopy (THz)':>15} {'FD Energy (THz)':>17} {'|Diff|':>12}")
        print("-" * 55)

        for m_idx in test_modes:
            mode = PhononMode(
                qpoint=qpoint,
                frequency=frequencies[m_idx],
                eigenvector=eigenvectors[:, m_idx],
                structure=ase_atoms,
                atomic_masses=ph.masses,
            )

            fd_freq = calculate_mode_frequency_fd(
                mode=mode,
                calculator=calc,
                supercell=ph.supercell_matrix,
                amplitude=0.01,
            )

            ref = frequencies[m_idx]
            diff = abs(ref - fd_freq)
            print(f"{m_idx:<6} {ref:>15.6f} {fd_freq:>17.6f} {diff:>12.6e}")

        print("\nTest completed successfully.")

    except TimeoutError as e:
        print(f"\n[TIMEOUT] {e}")
        import traceback
        traceback.print_stack()

    finally:
        signal.alarm(0)


if __name__ == '__main__':
    main()
