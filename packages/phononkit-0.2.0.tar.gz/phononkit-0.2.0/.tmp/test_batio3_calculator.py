"""
Test PhonopyCalculator on BaTiO3.

This test:
1. Loads BaTiO3 phonopy params.
2. Evaluates forces on the equilibrium structure.
3. Applies random displacements and re-evaluates.
4. Relaxes the structure back using ASE's BFGS.

How to run:
python .tmp/test_batio3_calculator.py
"""
import numpy as np
import os
from ase.optimize import LBFGS
import phononkit

def main():
    yaml_path = "Refs/phonproj/data/BaTiO3_phonopy_params.yaml"
    
    if not os.path.exists(yaml_path):
        print(f"Error: Could not find {yaml_path}")
        return
        
    print(f"Loading {yaml_path}...")
    calc = phononkit.load_phonopy_calculator(yaml_path)
    
    # Use the supercell from the calculator
    atoms = calc.supercell.copy()
    atoms.calc = calc
    
    n_atoms = len(atoms)
    print(f"Loaded supercell with {n_atoms} atoms.")
    
    # 1. Equilibrium check
    f0 = atoms.get_forces()
    e0 = atoms.get_potential_energy()
    print(f"Equilibrium max force: {np.max(np.abs(f0)):.6e} eV/A")
    print(f"Equilibrium energy: {e0:.6e} eV")
    assert np.max(np.abs(f0)) < 1e-10
    
    # 2. Add random displacements (~0.05 A)
    np.random.seed(42)
    displacements = np.random.randn(n_atoms, 3) * 0.05
    atoms.positions += displacements
    
    f1 = atoms.get_forces()
    e1 = atoms.get_potential_energy()
    print(f"\nAfter displacement:")
    print(f"  Max force: {np.max(np.abs(f1)):.6f} eV/A")
    print(f"  Energy: {e1:.6f} eV")
    assert e1 > 0
    assert np.max(np.abs(f1)) > 0
    
    # 3. Demonstrate Divergence using Molecular Dynamics
    from ase.md.velocitydistribution import MaxwellBoltzmannDistribution
    from ase.md.verlet import VelocityVerlet
    from ase import units
    
    print("\nStarting MD to demonstrate instability divergence...")
    # Initialize velocities corresponding to 10K
    MaxwellBoltzmannDistribution(atoms, temperature_K=10)
    
    dyn = VelocityVerlet(atoms, 1.0 * units.fs)
    
    try:
        for step in range(100):
            dyn.run(1)
            e_pot = atoms.get_potential_energy()
            f_max = np.max(np.abs(atoms.get_forces()))
            if step % 10 == 0:
                print(f"  Step {step:3d}: E_pot = {e_pot:10.2f} eV, Max Force = {f_max:10.2f} eV/A")
            
            # If the energy drops too far (divergence), we catch it
            if e_pot < -1000:
                print(f"  Step {step:3d}: System diverged! (E_pot < -1000 eV)")
                break
    except Exception as e:
        print(f"  MD crashed due to divergence: {e}")
        
    e_final = atoms.get_potential_energy()
    print(f"\nFinal Energy: {e_final:.2f} eV")
    if e_final < -10:
        print("✅ BaTiO3 test passed: System correctly diverges as expected for an unstable harmonic potential.")
    else:
        print("❌ BaTiO3 test failed: System did not diverge.")

if __name__ == '__main__':
    main()
