"""
Verify ASE Phonons with PhonopyCalculator.

This script:
1. Uses `ase.phonons.Phonons` to compute force constants via finite differences,
   employing our new `PhonopyCalculator` as the backend engine.
2. Extracts the Gamma point frequencies from ASE.
3. Compares them against Phonopy's exact harmonic frequencies.
"""
import numpy as np
import os
import shutil
import phonopy
from ase.phonons import Phonons
import phononkit

def main():
    yaml_path = "Refs/phonproj/data/BaTiO3_phonopy_params.yaml"
    
    if not os.path.exists(yaml_path):
        print(f"Error: Could not find {yaml_path}")
        return

    print("Loading Phonopy data...")
    # Load raw phonopy object to get reference frequencies and supercell matrix
    ph = phonopy.load(yaml_path)
    supercell_matrix = ph.supercell_matrix
    
    # Calculate reference frequencies at Gamma
    ph.run_qpoints([[0, 0, 0]])
    ref_freqs = ph.get_qpoints_dict()['frequencies'][0]
    # Convert from THz to eV (Phonopy defaults to THz, ASE Phonons outputs eV)
    # 1 THz = 0.004135667696 eV (approximately, via Planck constant)
    from ase.units import _hplanck, _e
    thz_to_ev = (_hplanck * 1e12) / _e
    ref_freqs_ev = ref_freqs * thz_to_ev

    print("Setting up PhonopyCalculator...")
    calc = phononkit.load_phonopy_calculator(yaml_path)
    
    # ASE's Phonons wants the PRIMITIVE cell 
    # (actually the unit cell that the supercell matrix scales up)
    # However, depending on the `phonopy.yaml`, the unitcell and primitive cell 
    # might be different. Let's use the unitcell that corresponds to the supercell matrix.
    atoms = ph.unitcell.copy() # Need ASE atoms
    from ase import Atoms
    ase_atoms = Atoms(symbols=atoms.symbols, positions=atoms.positions, cell=atoms.cell, pbc=True)
    
    # Check if a previous ASE phonon calculation exists in cwd, clean it if so
    phonon_dir = "phonon_ase_test"
    if os.path.exists(phonon_dir):
        shutil.rmtree(phonon_dir)
    os.makedirs(phonon_dir, exist_ok=True)
    
    os.chdir(phonon_dir)
    
    print(f"Initializing ASE Phonons on {len(ase_atoms)} atoms with supercell {supercell_matrix.diagonal()}...")
    # Create the Phonons object
    supercell_tuple = tuple(supercell_matrix.diagonal().astype(int))
    ase_phonons = Phonons(ase_atoms, calc, supercell=supercell_tuple, delta=1e-4)
    
    # Run the force calculations (this will displace atoms one by one in the supercell)
    # and call `calc.get_forces()`. Since `calc` is our PhonopyCalculator, it will 
    # compute F = -Phi * u instantly!
    print("Running ASE finite displacements...")
    try:
        ase_phonons.run()
    except Exception as e:
        print(f"Failed during phonon run: {e}")
        # Let's verify if the shapes matched inside ASE's run loop
        return

    # Read the forces from the cache and compute dynamical matrix
    ase_phonons.read()
    
    # Get frequencies at Gamma
    res = ase_phonons.band_structure([[0, 0, 0]])
    if hasattr(res, 'energies'):
        ase_freqs_ev = res.energies[0]
    else:
        ase_freqs_ev = res[0]
    
    print("\n--- Frequency Comparison (eV) at Gamma ---")
    print(f"{'Phonopy (Exact)':>20} | {'ASE Phonons (FD)':>20} | {'Diff':>15}")
    print("-" * 60)
    
    # Sort frequencies to compare them directly (imaginary freqs might be sorted differently)
    ref_freqs_ev = np.sort(ref_freqs_ev)
    ase_freqs_ev = np.sort(ase_freqs_ev)
    
    for p_freq, a_freq in zip(ref_freqs_ev, ase_freqs_ev):
        print(f"{p_freq:20.6e} | {a_freq:20.6e} | {abs(p_freq - a_freq):15.6e}")
        
    os.chdir("..")

if __name__ == '__main__':
    main()
