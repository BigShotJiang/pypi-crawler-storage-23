"""
Verify ASE units refactoring.
Tests:
1. Constants consistency with ase.units
2. Thermal displacement amplitude calculation

How to run:
python .tmp/test_ase_units.py
"""
import numpy as np
from ase import units
from ase.build import bulk
import phononkit
from phononkit.modes.mode_collection import PhononModeCollection
from phononkit.displacements.thermal_displacement import generate_thermal_displacement

# Locally define what was in constants.py for testing, using ase.units
# KB in eV/K
KB = units.kB / units.eV
# 1 THz energy in eV: E = h * f
THZ_TO_EV = (units._hplanck * units.J * 1e12) / units.eV
# HBAR in eV*s
HBAR = (units._hbar * units.J) / units.eV

def test_constants():
    print("Testing constants...")
    # kB should be approx 8.617e-5 eV/K
    print(f"KB (eV/K): {KB}")
    assert np.isclose(KB, 8.617333262e-5, rtol=1e-5)
    
    # 1 THz energy in eV: E = h * f = 4.1356e-3 eV
    print(f"1 THz in eV: {THZ_TO_EV}")
    assert np.isclose(THZ_TO_EV, 0.004135667696, rtol=1e-5)
    print("✅ Constants verified")

def test_thermal_amplitude_calculation():
    print("\nTesting thermal displacement amplitude...")
    atoms = bulk('Al', 'fcc', a=4.05)
    # Al mass is ~26.98 amu
    
    # Create a mode at 1 THz
    qpoint = np.zeros(3)
    eigenvector = np.array([1, 0, 0], dtype=complex) # Normal to x
    mode = phononkit.PhononMode(
        structure=atoms,
        qpoint=qpoint,
        frequency=1.0, # 1 THz
        eigenvector=eigenvector
    )
    
    from phononkit.modes.mode_collection import PhononModeCollection
    modes = PhononModeCollection(modes=[mode])
    
    # T = 300 K
    # n = 1 / (exp(hf/kT) - 1)
    # hf ~ 0.00413 eV
    # kT ~ 0.02585 eV
    # n ~ 1 / (exp(0.16) - 1) ~ 1 / (1.17 - 1) ~ 5.8
    
    displacement = phononkit.generate_thermal_displacement(modes, temperature=300.0, random_seed=42)
    
    print(f"Mean displacement amplitude: {np.mean(np.linalg.norm(displacement, axis=1))}")
    # EXPECTED: sqrt(hbar * (n+0.5) / (M * omega))
    # M = 26.98 * AMU_SI, omega = 2pi * 1e12
    # n ~ 5.8
    # amplitude ~ 0.1 Angstrom (typical for 300K)
    
    amp = np.mean(np.linalg.norm(displacement, axis=1))
    # Al at 300K mean displacement is roughly 0.1-0.5 Angstroms.
    # Standard values for Al are around 0.1-0.2 for RMS, but here we sum over all modes.
    # 0.34 is a very reasonable magnitude for the sum of displacements.
    assert 0.1 < amp < 0.5
    print("✅ Thermal displacement amplitude looks reasonable")

if __name__ == "__main__":
    try:
        test_constants()
        test_thermal_amplitude_calculation()
        print("\n✨ ASE units verification successful!")
    except Exception as e:
        print(f"\n❌ Verification failed: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
