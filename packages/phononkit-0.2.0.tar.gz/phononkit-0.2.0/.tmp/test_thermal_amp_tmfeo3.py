import sys
import numpy as np

from phononkit.io.phonopy_loader import load_from_phonopy_yaml
from phononkit.displacements.thermal_displacement import get_thermal_amplitude

def main():
    # 1. Load the modes from TmFeO3 phonopy_params.yaml
    yaml_path = "../TmFeO3/phonopy_params.yaml"
    print(f"Reading phonopy modes from: {yaml_path}")
    
    import json
    # load_from_phonopy_yaml returns (structure, mode_collection)
    structure, mode_collection = load_from_phonopy_yaml(yaml_path)
    
    # 1.5 Load irreps JSON
    irreps_path = "../TmFeO3/TmFeO3_irreps.json"
    with open(irreps_path, 'r') as f:
        irreps_dict = json.load(f)

    
    # 2. Filter for Gamma point only (q = [0, 0, 0])
    # The mode_collection from a phonopy_params.yaml containing q-points will have a specific structure.
    # Usually we can filter by q=0.
    gamma_modes = mode_collection.filter_by_qpoint([0.0, 0.0, 0.0])
    
    if gamma_modes.n_modes == 0:
        print("No Gamma point modes found!")
        return
        
    print(f"\nFound {gamma_modes.n_modes} Gamma point modes.")
    
    # 3. Calculate amplitudes at different temperatures
    temps = [50.0, 100.0, 200.0, 300.0]
    
    print("\n-------------------------------------------------------------------------------------------------------------------------")
    print(f"{'Mode':>5} | {'Irrep':>5} | {'Freq (THz)':>12} | {'Freq (cm-1)':>12} | {'Amp @ 50K':>14} | {'Amp @ 100K':>14} | {'Amp @ 200K':>14} | {'Amp @ 300K':>14}")
    print(f"{'':>5} | {'':>5} | {'':>12} | {'':>12} | {'(A * sqrt(amu))':>14} | {'(A * sqrt(amu))':>14} | {'(A * sqrt(amu))':>14} | {'(A * sqrt(amu))':>14}")
    print("-------------------------------------------------------------------------------------------------------------------------")
    
    # Calculate amplitudes for all requested temps at once
    amplitudes_dict = {}
    for T in temps:
        amplitudes_dict[T] = get_thermal_amplitude(gamma_modes, temperature=T)
        
    # THz to cm-1 conversion factor (roughly 33.356)
    from ase.units import _c
    # 1 THz = 1e12 Hz. c in cm/s is _c * 100. 
    # v (cm-1) = f (Hz) / c (cm/s)
    thz_to_cm1 = 1e12 / (_c * 100)
    
    # Prepare to write to CSV 1
    csv_file_1 = "../TmFeO3/TmFeO3_thermal_amplitudes.csv"
    with open(csv_file_1, "w") as f:
        # Write CSV header
        f.write("Mode,Irrep,Freq_THz,Freq_cm-1,Amp_50K,Amp_100K,Amp_200K,Amp_300K\n")
        
        for i, mode in enumerate(gamma_modes):
            mode_idx = str(i + 1)
            irrep_label = irreps_dict.get(mode_idx, {}).get('label', '-')
            
            f_thz = mode.frequency
            f_cm1 = f_thz * thz_to_cm1
            
            # If frequency is close to 0 (acoustic modes at Gamma or imaginary modes)
            if f_thz <= 1e-6:
                amp_50 = 0.0
                amp_100 = 0.0
                amp_200 = 0.0
                amp_300 = 0.0
                f_thz_str = f"{f_thz:12.4f}" if f_thz >= 0 else f"{f_thz:12.4f} (i)"
                csv_thz_str = f"{f_thz:.6f}" if f_thz >= 0 else f"{f_thz:.6f}i"
            else:
                amp_50 = amplitudes_dict[50.0][i]
                amp_100 = amplitudes_dict[100.0][i]
                amp_200 = amplitudes_dict[200.0][i]
                amp_300 = amplitudes_dict[300.0][i]
                f_thz_str = f"{f_thz:12.4f}"
                csv_thz_str = f"{f_thz:.6f}"
                
            print(f"{i+1:5d} | {irrep_label:>5} | {f_thz_str:>12} | {f_cm1:12.4f} | {amp_50:14.6f} | {amp_100:14.6f} | {amp_200:14.6f} | {amp_300:14.6f}")
            f.write(f"{i+1},{irrep_label},{csv_thz_str},{f_cm1:.6f},{amp_50:.6f},{amp_100:.6f},{amp_200:.6f},{amp_300:.6f}\n")
            
    print("-------------------------------------------------------------------------------------------------------------------------")
    print(f"Results saved to {csv_file_1}")
    
    # 3. Calculate element-specific absolute displacements at 50K
    print("\n---------------------------------------------------------------------------------------------------------")
    print(f"{'Mode':>5} | {'Irrep':>5} | {'Freq (THz)':>12} | {'Fe disp (A)':>14} | {'Tm disp (A)':>14} | {'O disp (A)':>14}")
    print("---------------------------------------------------------------------------------------------------------")
    
    # Pre-calculate 50K amplitudes
    amplitudes_50k = get_thermal_amplitude(gamma_modes, temperature=50.0)
    
    from phononkit.displacements.mode_displacement import calculate_supercell_displacement
    
    # We need the symbols to filter atoms
    symbols = gamma_modes.modes[0].structure.get_chemical_symbols()
    tm_indices = [i for i, s in enumerate(symbols) if s == 'Tm']
    fe_indices = [i for i, s in enumerate(symbols) if s == 'Fe']
    o_indices = [i for i, s in enumerate(symbols) if s == 'O']
    
    csv_file_2 = "../TmFeO3/TmFeO3_element_displacements_50K.csv"
    with open(csv_file_2, "w") as f2:
        f2.write("Mode,Irrep,Freq_THz,Fe_disp_A,Tm_disp_A,O_disp_A\n")
        
        for i, mode in enumerate(gamma_modes):
            mode_idx = str(i + 1)
            irrep_label = irreps_dict.get(mode_idx, {}).get('label', '-')
            
            f_thz = mode.frequency
            
            # If frequency is close to 0 (acoustic modes at Gamma or imaginary modes)
            if f_thz <= 1e-6:
                f_thz_str = f"{f_thz:12.4f}" if f_thz >= 0 else f"{f_thz:12.4f} (i)"
                csv_thz_str = f"{f_thz:.6f}" if f_thz >= 0 else f"{f_thz:.6f}i"
                disp_tm = 0.0
                disp_fe = 0.0
                disp_o = 0.0
            else:
                f_thz_str = f"{f_thz:12.4f}"
                csv_thz_str = f"{f_thz:.6f}"
                scalar_amp = amplitudes_50k[i]
                
                # calculate physical displacement in Angstroms
                # normalize=False is used because scalar_amp is already the prefactor
                u_sc = calculate_supercell_displacement(
                    mode, 
                    amplitude=scalar_amp, 
                    normalize=False,
                    real_only=True
                )
                
                # Average absolute displacement magnitude for each species
                # u_sc shape is (n_atoms, 3). We want average norm.
                mags = np.linalg.norm(u_sc, axis=1)
                
                disp_tm = np.mean(mags[tm_indices]) if len(tm_indices)>0 else 0.0
                disp_fe = np.mean(mags[fe_indices]) if len(fe_indices)>0 else 0.0
                disp_o = np.mean(mags[o_indices]) if len(o_indices)>0 else 0.0
                
            print(f"{i+1:5d} | {irrep_label:>5} | {f_thz_str:>12} | {disp_fe:14.6f} | {disp_tm:14.6f} | {disp_o:14.6f}")
            f2.write(f"{i+1},{irrep_label},{csv_thz_str},{disp_fe:.6f},{disp_tm:.6f},{disp_o:.6f}\n")
            
    print("---------------------------------------------------------------------------------------------------------")
    print(f"Results saved to {csv_file_2}")

if __name__ == "__main__":
    main()
