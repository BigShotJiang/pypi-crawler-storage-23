# User Guide - phononkit

## Quick Start (5 Minutes)

### Installation
```bash
pip install phononkit
```

Or from source:
```bash
git clone https://github.com/phonontools/phonon_kit.git
cd phonon_kit
pip install -e .
```

### Your First Analysis

Here's a complete example using real phonopy data:

```python
from phononkit import load_from_phonopy_yaml
from phononkit import generate_thermal_structure

# Load phonon data from phonopy YAML file
structure, modes = load_from_phonopy_yaml('phonopy_params.yaml')

print(f"Loaded {modes.n_modes} phonon modes")
print(f"Structure: {structure.get_chemical_formula()}")

# Filter modes by frequency
low_freq = modes.filter_by_frequency(freq_max=5.0)
print(f"Low-frequency modes: {low_freq.n_modes}")

# Generate thermal displacements at 300K
thermal = generate_thermal_structure(modes, temperature=300.0)
```

## Real-World Examples

### Example 1: Mode Analysis (BaTiO3)

Analyze phonon modes for Barium Titanate (BaTiO3):

```python
from phononkit import load_from_phonopy_yaml
from phononkit.analysis import generate_mode_summary

# Load data
structure, modes = load_from_phonopy_yaml('examples/data/phonopy_params.yaml')

# Display all modes with frequencies
summary = generate_mode_summary(modes)
print(summary)

# Output:
# BaTiO3 Phonon Modes
# Mode 1: -6.049 THz - Acoustic
# Mode 2: -6.049 THz - Acoustic
# ...
```

### Example 2: Thermal Displacements

Generate structures with thermal displacements at different temperatures:

```python
from phononkit import load_from_phonopy_yaml, generate_thermal_structure
from ase.io import write

structure, modes = load_from_phonopy_yaml('phonopy_params.yaml')

# Generate at room temperature (300K)
thermal_300K = generate_thermal_structure(modes, temperature=300.0)
write('thermal_300K.vasp', thermal_300K)

# Generate at high temperature (800K)
thermal_800K = generate_thermal_structure(modes, temperature=800.0)
write('thermal_800K.vasp', thermal_800K)
```

### Example 3: MCIF Export for Visualization

Export phonon modes to MCIF format for visualization in VESTA:

```python
from phononkit import load_from_phonopy_yaml
from phononkit.io import save_mcif_file

structure, modes = load_from_phonopy_yaml('phonopy_params.yaml')

# Export all modes
save_mcif_file(modes, filename='all_modes.mcif')

# Or export only low-frequency modes
low_freq = modes.filter_by_frequency(freq_max=10.0)
save_mcif_file(low_freq, filename='low_freq.mcif')
```

## Common Tasks

### Loading Phonopy Data

```python
from phononkit import load_from_phonopy_yaml

# Basic loading
structure, modes = load_from_phonopy_yaml('phonopy_params.yaml')

# The structure is an ASE Atoms object
print(f"Formula: {structure.get_chemical_formula()}")
print(f"Atoms: {len(structure)}")

# modes is a PhononModeCollection
print(f"Number of modes: {modes.n_modes}")
```

### Filtering Modes

```python
# By frequency range
optical = modes.filter_by_frequency(freq_min=5.0, freq_max=15.0)

# By q-point (e.g., Gamma point only)
gamma_modes = modes.filter_by_qpoint([0.0, 0.0, 0.0])

# By gauge convention
r_gauge = modes.filter_by_gauge('r')
```

### Generating Displacements

```python
from phononkit import generate_mode_displacement

# Get first mode
mode = modes[0]

# Generate displacement with 1.0 Å amplitude
displaced_structure = generate_mode_displacement(mode, amplitude=1.0)

# Save to file
from ase.io import write
write('displaced.vasp', displaced_structure)
```

### Working with Supercells

```python
from phononkit import build_supercell, is_commensurate_qpoint
import numpy as np

# Build 2x2x2 supercell
supercell_matrix = np.diag([2, 2, 2])
supercell = build_supercell(structure, supercell_matrix)

# Check if q-point is commensurate
q_point = np.array([0.5, 0.0, 0.0])
if is_commensurate_qpoint(q_point, supercell_matrix):
    print("Q-point is commensurate with supercell")
```

## Understanding the Output

### Mode Frequencies
- **Acoustic modes**: Low frequency (< 3 THz), correspond to translations
- **Optical modes**: Higher frequency, involve internal atomic displacements
- **Soft modes**: Very low frequency (< 1 THz), often indicate phase transitions

### Thermal Displacements
The amplitude of thermal displacements depends on:
- Temperature (higher T = larger displacements)
- Mode frequency (lower freq = larger displacements)
- Atomic mass (lighter atoms = larger displacements)

### MCIF Files
MCIF (Modulated Crystal Information File) format allows visualization of:
- Individual phonon mode displacements
- Thermal ellipsoids
- Supercell modulations

Open these files in:
- **VESTA** (recommended)
- **Jmol**
- **Ovito**

## Sample Data

The `examples/data/` directory contains sample phonopy data:

- **phonopy_params.yaml**: BaTiO3 (Barium Titanate) phonon data
  - 5 atoms per primitive cell
  - 15 phonon modes per q-point
  - Includes force constants and eigenvectors

You can use your own phonopy YAML files by replacing the path in the examples.

## Troubleshooting

### "File not found" error
Make sure the YAML file path is correct:
```python
from pathlib import Path

yaml_path = Path('/path/to/phonopy_params.yaml')
if yaml_path.exists():
    structure, modes = load_from_phonopy_yaml(str(yaml_path))
```

### Import errors
If you get import errors, ensure phononkit is installed:
```bash
python -c "import phononkit; print(phononkit.__version__)"
```

### Complex eigenvector warning
Phonon eigenvectors can be complex. When saving structures:
```python
# ASE might warn about complex displacements
# This is normal - the real part is used for visualization
displaced = generate_mode_displacement(mode, amplitude=1.0)
# Warning is expected and safe to ignore
```

### Memory issues with large systems
For large supercells, process modes individually:
```python
# Instead of loading all at once
for mode in modes:
    displaced = generate_mode_displacement(mode, amplitude=1.0)
    # Process and save immediately
    # Don't accumulate all in memory
```

## Next Steps

- **Examples**: See `examples/` directory for complete scripts
- **API Reference**: See `docs/api/` for detailed function documentation
- **Methodology**: See `docs/methodology/` for mathematical background
- **GitHub**: Report issues at https://github.com/phonontools/phonon_kit

## Getting Help

If you encounter issues:

1. Check the examples in the `examples/` directory
2. Review the API documentation
3. Open an issue on GitHub with:
   - The error message
   - Your code snippet
   - The phonopy version used
