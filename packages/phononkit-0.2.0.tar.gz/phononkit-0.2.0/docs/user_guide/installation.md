# Installation Guide

## Requirements
- Python 3.9, 3.10, 3.11, 3.12, 3.13, or 3.14
- numpy
- scipy
- ase (Atomic Simulation Environment)
- phonopy >= 2.0.0

## Installing from Source

```bash
git clone https://github.com/phonontools/phonon_kit.git
cd phonon_kit
pip install .
```

## Developer Installation
For developers, we recommend using `uv` and installing in editable mode with development dependencies.

```bash
uv venv
source .venv/bin/activate
uv pip install -e '.[dev]'
```

## Verifying Installation

```python
import phononkit
print(phononkit.__version__)
```
