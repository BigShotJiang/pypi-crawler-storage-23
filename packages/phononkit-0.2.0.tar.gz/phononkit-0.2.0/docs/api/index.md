# API Reference

Phonon Kit is organized into the following modules:

## [core](../phononkit/core)
Foundational types and constants.
- `types.py`: TypedDict contracts for module boundaries.
- `constants.py`: Physical constants in SI units.

## [qpoints](../phononkit/qpoints)
Q-point mathematics.
- `grid.py`: Mesh generation (Monkhorst-Pack, Gamma-centered).
- `commensurate.py`: Supercell-qpoint commensurability.
- `path.py`: Band structure path generation.
- `utils.py`: Euclidean distances and BZ reduction.

## [modes](../phononkit/modes)
Phonon mode representation.
- `mode.py`: `PhononMode` class.
- `collection.py`: `PhononModeCollection` class.
- `gauge.py`: R ↔ r gauge transformations.

## [displacements](../phononkit/displacements)
Displacement generation.
- `generator.py`: Cartesian displacement generation.
- `thermal.py`: Thermal displacement patterns.

## [projections](../phononkit/projections)
Mode projections.
- `mass_weighted.py`: Mass-weighted projection logic.
- `orthonormality.py`: Orthonormality verification.

## [supercells](../phononkit/supercells)
Supercell operations.
- `builder.py`: Supercell construction.
- `phase.py`: Phase factor application.

## [analysis](../phononkit/analysis)
Structural and symmetry analysis.
- `structure.py`: Atomic correspondence and matching.
- `substitution.py`: Species substitution handling.
- `symmetry.py`: Degeneracy and IR analysis.

## [io](../phononkit/io)
Data import and export.
- `phonopy_loader.py`: Integration with phonopy YAML.
- `mcif.py`: Export to modulated CIF format.
