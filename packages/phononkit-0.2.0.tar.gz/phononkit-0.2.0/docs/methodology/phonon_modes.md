# Phonon Mode Methodology

## Eigenvector Normalization
Phonon eigenvectors $\mathbf{e}_{j}(\mathbf{q})$ are solutions to the dynamical matrix equation. In phononkit, we assume eigenvectors are normalized such that:
$$\sum_{i, \alpha} |e_{i, \alpha, j}(\mathbf{q})|^2 = 1$$
where $i$ is the atom index and $\alpha$ is the Cartesian component.

## Mass Weighting
For many physical applications, mass-weighted eigenvectors are required:
$$\tilde{e}_{i, \alpha, j}(\mathbf{q}) = \sqrt{M_i} e_{i, \alpha, j}(\mathbf{q})$$
These are implemented in the `projections.mass_weighted` module.

## Gauge Conventions
Two common gauge conventions exist for phonon modes:
- **R-gauge**: Eigenvectors include a phase factor $\exp(i \mathbf{q} \cdot \mathbf{R}_l)$ where $\mathbf{R}_l$ is the lattice vector.
- **r-gauge**: Eigenvectors include a phase factor $\exp(i \mathbf{q} \cdot \mathbf{r}_i)$ where $\mathbf{r}_i$ is the atomic position.

The transformation between gauges is handled by the `modes.gauge` module.

## Thermal Displacements
Thermal displacement patterns are generated using Bose-Einstein statistics:
$$\langle |u_{i, \alpha}|^2 \rangle = \frac{\hbar}{2 M_i} \sum_{j, \mathbf{q}} \frac{1}{\omega_{j}(\mathbf{q})} (2 n_{j}(\mathbf{q}) + 1) |e_{i, \alpha, j}(\mathbf{q})|^2$$
where $n_{j}(\mathbf{q})$ is the Bose-Einstein occupation factor.
