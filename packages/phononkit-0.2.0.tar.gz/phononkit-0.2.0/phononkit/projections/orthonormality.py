"""Orthonormality verification for eigenvectors.

This module provides functions for verifying that eigenvectors are
properly orthonormal within numerical tolerance.
"""

import numpy as np
from ase import Atoms

from phononkit.modes.phonon_mode import PhononMode


def verify_orthonormality(
    eigenvectors: np.ndarray, atomic_masses: np.ndarray, tol: float = 1e-5
) -> bool:
    """Verify that eigenvectors are orthonormal.

    Eigenvectors should satisfy: e_i† @ e_j = δ_ij

    Parameters:
        eigenvectors: Array of eigenvectors, shape (n_modes, n_atoms*3)
        atomic_masses: Atomic masses in AMU, shape (n_atoms,)
        tol: Tolerance for orthonormality check

    Returns:
        True if orthonormal within tolerance

    Examples:
        >>> verify_orthonormality(eigvecs, masses)
        True
    """
    from phononkit.projections.mass_weighted import mass_weight_eigenvector

    n_modes = eigenvectors.shape[0]

    weighted_eigenvectors = np.array(
        [
            mass_weight_eigenvector(eigenvectors[i], atomic_masses)
            for i in range(n_modes)
        ]
    )

    inner_products = weighted_eigenvectors @ weighted_eigenvectors.conj().T

    identity = np.eye(n_modes)

    return np.allclose(inner_products, identity, atol=tol)


def compute_inner_products(
    mode1: PhononMode, mode2: PhononMode, tol: float = 1e-5
) -> float:
    """Compute inner product between two mass-weighted eigenvectors.

    Parameters:
        mode1: First phonon mode
        mode2: Second phonon mode
        tol: Tolerance for orthonormality check

    Returns:
        Inner product of mass-weighted eigenvectors

    Examples:
        >>> inner = compute_inner_products(mode1, mode2)
    """
    from phononkit.projections.mass_weighted import mass_weight_eigenvector

    weighted1 = mass_weight_eigenvector(mode1.eigenvector, mode1.atomic_masses)
    weighted2 = mass_weight_eigenvector(mode2.eigenvector, mode2.atomic_masses)

    inner = np.vdot(weighted1, weighted2.conj())

    return inner
