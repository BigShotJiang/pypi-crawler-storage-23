"""Mass-weighted projections and orthonormality verification.

This module provides:
- Mass-weighted projection of displacements onto phonon modes
- Orthonormality verification for eigenvectors
- Inner product calculations between modes
"""

from phononkit.projections.mass_weighted import (
    mass_weight_eigenvector,
    project_onto_modes,
)
from phononkit.projections.orthonormality import (
    verify_orthonormality,
    compute_inner_products,
)

__all__ = [
    "mass_weight_eigenvector",
    "project_onto_modes",
    "verify_orthonormality",
    "compute_inner_products",
]
