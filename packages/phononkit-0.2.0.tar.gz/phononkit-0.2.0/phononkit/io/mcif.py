"""MCIF (modulated crystal information file) export functionality.

This module provides functions for exporting phonon mode
displacements to MCIF format for visualization and analysis.
"""

import os
import numpy as np
from ase import Atoms
from typing import TextIO, List, Optional

from phononkit.modes.phonon_mode import PhononMode
from phononkit.modes.mode_collection import PhononModeCollection


def write_mcif_header(output: TextIO, title: str, cell: Atoms):
    """Write MCIF header with metadata.

    Parameters:
        output: File-like object to write to
        title: Title of the crystal structure
        cell: Atomic structure with cell parameters
    """
    a, b, c, alpha, beta, gamma = cell.get_cell_lengths_and_angles()
    output.write("_cell_length_a_b_c_alpha_beta_gamma\n")
    output.write(f"{a:.6f} {b:.6f} {c:.6f} {alpha:.6f} {beta:.6f} {gamma:.6f}\n")
    output.write("_cell_volume\n")
    volume = np.linalg.det(cell.cell)
    output.write(f"{volume:.6f}\n")
    output.write(f"_symmetry_space_group\nP1\n")
    output.write("_symmetry_Int_Tables_number\n")
    output.write("1\n")
    output.write(f"_chemical_formula_sum\n{title}\n")
    output.write("_symmetry_space_group_setting\n")
    output.write("1\n")


def write_mcif_atoms(output: TextIO, structure: Atoms):
    """Write atomic positions to MCIF format.

    Parameters:
        output: File-like object to write to
        structure: Atomic structure with positions and symbols
    """
    n_atoms = len(structure)
    output.write(f"_symmetry_equiv_pos_as_site\n{n_atoms}\n")
    output.write("_symmetry_Int_Tables\n")

    positions = structure.get_scaled_positions()

    for i, (x, y, z) in enumerate(positions):
        output.write(f"_{i + 1}\n")
        output.write(f"{x:.6f} {y:.6f} {z:.6f}\n")

    output.write("_symmetry_space_group_sym_ops\n")

    for i in range(24):
        op_matrix = np.eye(3)
        for row in range(3):
            for col in range(3):
                if row == col:
                    op_matrix[row, col] = 1.0
        for row in range(3):
            output.write(" ".join([f"{op_matrix[row, col]:.1f}" for col in range(3)]))
            output.write("\n")

    output.write("_space_group_symop\n")


def write_mode_displacement(
    output: TextIO, mode: PhononMode, mode_idx: int, amplitude: float
) -> None:
    """Write mode displacement data to MCIF format.

    Parameters:
        output: File-like object to write to
        mode: PhononMode to export
        mode_idx: Mode index for labeling
        amplitude: Displacement amplitude
    """
    n_atoms = mode.n_atoms
    eigenvector = mode.eigenvector.reshape(n_atoms, 3).real

    output.write(f"_displacement_amplitude_{mode_idx + 1}\n")
    output.write(f"{float(amplitude):.6f}\n")
    output.write(f"_displacement_cartesian_{mode_idx + 1}\n")

    for atom_idx in range(n_atoms):
        displacement = amplitude * eigenvector[atom_idx]
        output.write(" ".join([f"{float(displacement[dim]):.8f}" for dim in range(3)]))
        output.write("\n")


def export_to_mcif(
    modes: PhononModeCollection,
    title: str = "Phonon Modes",
) -> str:
    """Export phonon mode displacements to MCIF format.

    Parameters:
        modes: PhononModeCollection to export
        title: Title for the MCIF file
        filename: Output filename (optional, uses title-based naming)

    Returns:
        MCIF content as string

    Examples:
        >>> content = export_to_mcif(modes, title="MyCrystal")
        >>> with open('output.mcif', 'w') as f:
        ...     f.write(content)
    """
    from io import StringIO

    output = StringIO()

    if modes.n_modes == 0:
        raise ValueError("No modes to export")

    structure = modes.modes[0].structure

    write_mcif_header(output, title, structure)
    write_mcif_atoms(output, structure)

    for mode_idx, mode in enumerate(modes):
        write_mode_displacement(output, mode, mode_idx, amplitude=1.0)

    content = output.getvalue()

    return content


def save_mcif_file(
    modes: PhononModeCollection,
    title: str = "Phonon Modes",
    filename: Optional[str] = None,
) -> str:
    """Save phonon modes to MCIF file.

    Parameters:
        modes: PhononModeCollection to export
        title: Title for the MCIF file
        filename: Output filename

    Returns:
        Path to saved MCIF file

    Examples:
        >>> filepath = save_mcif_file(modes, filename="modes.mcif")
        >>> print(f"Saved to {filepath}")
    """
    import os

    if filename is None:
        safe_title = "".join(c if c.isalnum() else "_" for c in title)
        filename = f"{safe_title}.mcif"

    with open(filename, "w") as f:
        f.write(export_to_mcif(modes, title=title))

    return os.path.abspath(filename)
