"""Phonopy ASE Calculator for harmonic potentials.

This module provides an ASE Calculator that uses Phonopy force constants
to calculate harmonic energy and forces.
"""

import numpy as np
from ase.calculators.calculator import Calculator, all_changes
from typing import Optional, Union


class PhonopyCalculator(Calculator):
    """ASE Calculator using Phonopy force constants as an harmonic potential.
    
    The energy is calculated as:
        E = 0.5 * sum_{ij} u_i * Phi_{ij} * u_j
    The force is calculated as:
        F_i = -sum_j Phi_{ij} * u_j
        
    where Phi is the force constant matrix and u is the displacement from 
    equilibrium positions.
    """
    
    implemented_properties = ['energy', 'forces']
    
    def __init__(
        self,
        phonopy_obj=None,
        force_constants: Optional[np.ndarray] = None,
        supercell=None,
        primitive=None,
        **kwargs
    ):
        """Initialize the calculator.
        
        Parameters:
            phonopy_obj: A phonopy.Phonopy object (optional)
            force_constants: Force constant matrix (optional)
            supercell: Supercell Atoms object (optional)
            primitive: Primitive Atoms object (optional)
        """
        Calculator.__init__(self, **kwargs)
        
        import numpy as np
        
        if phonopy_obj is not None:
            raw_fc = phonopy_obj.force_constants
            
            # Check if force constants are in compact format
            if raw_fc.shape[0] != raw_fc.shape[1]:
                from phonopy.harmonic.force_constants import distribute_force_constants_by_translations
                prim = phonopy_obj.primitive
                p_sc = phonopy_obj.supercell
                n_sc = raw_fc.shape[1]
                full_fc = np.zeros((n_sc, n_sc, 3, 3), dtype='double', order='C')
                full_fc[prim.p2s_map] = raw_fc
                
                import inspect
                sig = inspect.signature(distribute_force_constants_by_translations)
                if len(sig.parameters) == 2:
                    distribute_force_constants_by_translations(full_fc, prim)
                else:
                    distribute_force_constants_by_translations(full_fc, prim, p_sc)
                    
                self.force_constants = full_fc
            else:
                self.force_constants = raw_fc
                p_sc = phonopy_obj.supercell
                
            # Phonopy's supercell is what the FCs are defined on
            from ase import Atoms
            self.supercell = Atoms(
                symbols=p_sc.symbols,
                positions=p_sc.positions,
                cell=p_sc.cell,
                pbc=True
            )
        else:
            self.force_constants = force_constants
            self.supercell = supercell
            
        if self.force_constants is None or self.supercell is None:
            raise ValueError("force_constants and supercell must be provided.")
            
        # Prepare the flat 2D force constant matrix once
        n_sc_atoms = len(self.supercell)
        self.fc_matrix = self.force_constants.transpose(0, 2, 1, 3).reshape(3*n_sc_atoms, 3*n_sc_atoms)
        
    def calculate(self, atoms=None, properties=['energy'], system_changes=all_changes):
        """Calculate energy and forces."""
        Calculator.calculate(self, atoms, properties, system_changes)
        
        # 1. Get current displacements u = R - R0
        # Check if the structure matches the supercell
        if len(self.atoms) != len(self.supercell):
            raise ValueError(f"Number of atoms ({len(self.atoms)}) does not match "
                             f"force constant supercell ({len(self.supercell)}).")
            
        n_atoms = len(self.atoms)
        fc_matrix = self.fc_matrix
        
        # Determine mapping from self.atoms to self.supercell (reference)
        # We do this by finding the closest reference position for each current atom.
        # This handles the case where the incoming Atoms object has a different 
        # ordering than the Phonopy supercell (e.g., from ase.phonons).
        if getattr(self, '_cached_mapping', None) is None or len(self._cached_mapping) != n_atoms:
            pos = self.atoms.get_scaled_positions()
            ref_pos = self.supercell.get_scaled_positions()
            
            diff = pos[:, None, :] - ref_pos[None, :, :]
            diff -= np.round(diff)  # Minimum image convention in fractional coords
            
            # Convert to Cartesian to measure true distance
            cell = self.supercell.cell[:]
            dist_sq = np.sum(np.dot(diff, cell)**2, axis=2)
            
            mapping = np.argmin(dist_sq, axis=1)
            
            # Verify mapping is one-to-one and distances are small (i.e., pure displacement)
            if len(np.unique(mapping)) != n_atoms:
                raise ValueError("Could not establish a 1-to-1 mapping between the provided Atoms and the reference supercell.")
            max_dist = np.sqrt(np.max(np.min(dist_sq, axis=1)))
            if max_dist > 1.0:
                raise ValueError(f"Atoms are too far from reference positions to safely map. Max displacement: {max_dist:.2f} A")
                
            self._cached_mapping = mapping
        
        mapping = self._cached_mapping
        
        # Calculate displacements correctly accounting for PBC and mapping
        pos = self.atoms.get_scaled_positions()
        ref_pos = self.supercell.get_scaled_positions()[mapping]
        
        diff_frac = pos - ref_pos
        diff_frac -= np.round(diff_frac)
        u = np.dot(diff_frac, self.atoms.cell[:])
        
        # We need to map u to the internal reference ordering to multiply with FC matrix
        inv_mapping = np.argsort(mapping)
        u_ref_order = u[inv_mapping]
        u_flat = u_ref_order.ravel()
        
        # Forces F = -Phi * u (in reference ordering)
        f_flat = -np.dot(fc_matrix, u_flat)
        f_ref_order = f_flat.reshape(n_atoms, 3)
        
        # Map forces back to the incoming atoms ordering
        self.results['forces'] = f_ref_order[mapping]
        
        # Energy E = 0.5 * u * Phi * u
        self.results['energy'] = 0.5 * np.dot(u_flat, np.dot(fc_matrix, u_flat))

def load_phonopy_calculator(yaml_path: str, **kwargs) -> PhonopyCalculator:
    """Helper to create a PhonopyCalculator from a phonopy.yaml file."""
    try:
        import phonopy
    except ImportError:
        raise ImportError("phonopy is required for this calculator.")
        
    ph = phonopy.load(yaml_path, produce_fc=True)
    return PhonopyCalculator(phonopy_obj=ph, **kwargs)
