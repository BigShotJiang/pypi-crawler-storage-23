"""Phonon mode representation and management.

This module provides:
- PhononMode: Single phonon mode representation
- PhononModeCollection: Collection management with filtering/selection
- Gauge transformation utilities (R and r gauges)
- Phonopy YAML loading
"""

from phononkit.modes.phonon_mode import PhononMode
from phononkit.modes.mode_collection import PhononModeCollection
from phononkit.modes.gauge import (
    transform_eigenvector_gauge,
    transform_phonon_mode_gauge,
)

__all__ = [
    "PhononMode",
    "PhononModeCollection",
    "transform_eigenvector_gauge",
    "transform_phonon_mode_gauge",
]
