"""PhononModeCollection for managing multiple phonon modes.

This module provides functionality for managing collections of phonon modes,
including filtering, selection, and iteration.
"""

import numpy as np
from ase import Atoms
from typing import List, Union

from phononkit.modes.phonon_mode import PhononMode


class PhononModeCollection:
    """Collection of phonon modes for efficient querying and filtering.

    A PhononModeCollection manages multiple PhononMode objects, providing
    convenient methods for filtering and selecting modes based on various criteria.

    Attributes:
        modes: List of PhononMode objects
    """

    def __init__(self, modes: List[PhononMode]):
        """Initialize a PhononModeCollection.

        Parameters:
            modes: List of PhononMode objects
        """
        self.modes = modes

    @property
    def n_modes(self) -> int:
        """Total number of modes in the collection."""
        return len(self.modes)

    @property
    def n_atoms(self) -> int:
        """Number of atoms (all modes must have same n_atoms)."""
        if not self.modes:
            return 0
        return self.modes[0].n_atoms

    @property
    def frequencies(self) -> np.ndarray:
        """Array of frequencies for all modes, shape (n_modes,)."""
        return np.array([mode.frequency for mode in self.modes])

    @property
    def eigenvectors(self) -> np.ndarray:
        """Array of eigenvectors for all modes, shape (n_modes, n_atoms*3)."""
        return np.array([mode.eigenvector for mode in self.modes])

    @property
    def qpoints(self) -> np.ndarray:
        """Array of unique q-points in the collection, shape (n_qpoints, 3)."""
        if not self.modes:
            return np.zeros((0, 3))
        
        # Use rounding to handle floating point precision
        q_list = [tuple(np.round(mode.qpoint, 8)) for mode in self.modes]
        unique_q = sorted(list(set(q_list)))
        return np.array(unique_q)

    def filter_by_frequency(
        self, freq_min: float = -np.inf, freq_max: float = np.inf
    ) -> "PhononModeCollection":
        """Filter modes by frequency range.

        Parameters:
            freq_min: Minimum frequency (THz), default -inf
            freq_max: Maximum frequency (THz), default +inf

        Returns:
            New PhononModeCollection with filtered modes

        Examples:
            >>> collection.filter_by_frequency(freq_min=0, freq_max=5)
            PhononModeCollection with only modes 0-5 THz
        """
        filtered = [
            mode for mode in self.modes if freq_min <= mode.frequency <= freq_max
        ]
        return PhononModeCollection(filtered)

    def filter_by_qpoint(
        self,
        qpoint: np.ndarray,
        tol: float = 1e-6,
    ) -> "PhononModeCollection":
        """Filter modes by q-point (exact match).

        Parameters:
            qpoint: Target q-point in reduced coordinates
            tol: Tolerance for q-point comparison

        Returns:
            New PhononModeCollection with matching modes

        Examples:
            >>> collection.filter_by_qpoint(np.array([0.0, 0.0, 0.0]))
            PhononModeCollection with gamma-point modes
        """
        filtered = [
            mode for mode in self.modes if np.allclose(mode.qpoint, qpoint, atol=tol)
        ]
        return PhononModeCollection(filtered)

    def filter_by_gauge(self, gauge: str) -> "PhononModeCollection":
        """Filter modes by gauge convention.

        Parameters:
            gauge: Gauge convention ('R' or 'r')

        Returns:
            New PhononModeCollection with matching modes
        """
        filtered = [mode for mode in self.modes if mode.gauge == gauge]
        return PhononModeCollection(filtered)

    def select_by_index(self, indices: Union[int, List[int]]) -> "PhononModeCollection":
        """Select specific modes by index.

        Parameters:
            indices: Single index or list of indices

        Returns:
            New PhononModeCollection with selected modes
        """
        if isinstance(indices, int):
            indices = [indices]

        selected = [self.modes[i] for i in indices if 0 <= i < len(self.modes)]

        return PhononModeCollection(selected)

    def get_gamma_point_modes(self, tol: float = 1e-6) -> "PhononModeCollection":
        """Get all modes at gamma point (q = [0, 0, 0]).

        Parameters:
            tol: Tolerance for q-point comparison

        Returns:
            New PhononModeCollection with gamma-point modes
        """
        return self.filter_by_qpoint(np.zeros(3), tol)

    def __iter__(self):
        """Iterate over modes."""
        return iter(self.modes)

    def __len__(self) -> int:
        """Return number of modes."""
        return len(self.modes)

    def __getitem__(self, index) -> PhononMode:
        """Get mode by index."""
        return self.modes[index]

    def __repr__(self) -> str:
        """String representation."""
        return f"PhononModeCollection(n_modes={self.n_modes}, n_atoms={self.n_atoms})"
