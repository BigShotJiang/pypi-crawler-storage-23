"""PhononMode class for representing a single phonon mode.

This module provides the core data structure for representing individual
phonon modes with frequencies, eigenvectors, and associated q-points.
"""

import numpy as np
from ase import Atoms
from typing import Optional


class PhononMode:
    """Representation of a single phonon mode.

    A PhononMode represents a single vibrational mode at a specific
    q-point, containing frequency, eigenvector, and structure information.

    Attributes:
        frequency: Mode frequency in THz
        eigenvector: Complex eigenvector, shape (n_atoms * 3,)
        qpoint: Q-point in reduced coordinates, shape (3,)
        structure: Atomic structure
        atomic_masses: Array of atomic masses for mass weighting
        gauge: Gauge convention ('R' or 'r')
    """

    def __init__(
        self,
        frequency: float,
        eigenvector: np.ndarray,
        qpoint: np.ndarray,
        structure: Atoms,
        atomic_masses: Optional[np.ndarray] = None,
        gauge: str = "R",
    ):
        """Initialize a PhononMode object.

        Parameters:
            frequency: Mode frequency in THz
            eigenvector: Complex eigenvector, shape (n_atoms * 3,)
            qpoint: Q-point in reduced coordinates, shape (3,)
            structure: Atomic structure
            atomic_masses: Atomic masses for mass weighting, shape (n_atoms,)
                         If None, uses structure.get_masses()
            gauge: Gauge convention ('R' or 'r')
        """
        self.frequency = float(frequency)
        self.eigenvector = np.asarray(eigenvector, dtype=complex)
        self.qpoint = np.asarray(qpoint, dtype=float)
        self.structure = structure
        self.gauge = gauge

        n_atoms = len(structure)
        if eigenvector.shape != (n_atoms * 3,):
            raise ValueError(
                f"eigenvector shape must be ({n_atoms * 3},), got {eigenvector.shape}"
            )
        if qpoint.shape != (3,):
            raise ValueError(f"qpoint shape must be (3,), got {qpoint.shape}")

        if atomic_masses is None:
            self.atomic_masses = structure.get_masses()
        else:
            self.atomic_masses = np.asarray(atomic_masses, dtype=float)

        if len(self.atomic_masses) != n_atoms:
            raise ValueError(
                f"Number of atomic masses ({len(self.atomic_masses)}) "
                f"must match number of atoms ({n_atoms})"
            )

    @property
    def n_atoms(self) -> int:
        """Number of atoms in the structure."""
        return len(self.structure)

    @property
    def n_modes(self) -> int:
        """Number of modes (always 3*n_atoms for a PhononMode)."""
        return 3 * len(self.structure)

    def copy(self) -> "PhononMode":
        """Create a copy of this PhononMode."""
        return PhononMode(
            frequency=self.frequency,
            eigenvector=self.eigenvector.copy(),
            qpoint=self.qpoint.copy(),
            structure=self.structure.copy(),
            atomic_masses=self.atomic_masses.copy(),
            gauge=self.gauge,
        )

    def __repr__(self) -> str:
        """String representation of PhononMode."""
        return (
            f"PhononMode(frequency={self.frequency:.3f} THz, "
            f"qpoint={self.qpoint}, gauge='{self.gauge}', "
            f"n_atoms={self.n_atoms})"
        )
