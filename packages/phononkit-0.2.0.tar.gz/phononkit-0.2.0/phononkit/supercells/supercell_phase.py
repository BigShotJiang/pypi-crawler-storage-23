"""Phase factor utilities for supercell expansion.

This module provides functions for calculating and applying phase factors
to phonon modes in supercell expansions.
"""

import numpy as np
from ase import Atoms
from typing import Tuple

from phononkit.modes.phonon_mode import PhononMode


def calculate_phase_factors(
    qpoint: np.ndarray, structure: Atoms, supercell_matrix: np.ndarray
) -> np.ndarray:
    """Calculate phase factors for supercell expansion.

    Phase factors are used to ensure correct mode expansion in
    supercells based on q-point and atomic positions.

    Parameters:
        qpoint: Q-point in reduced coordinates
        structure: Atomic structure with positions
        supercell_matrix: 3x3 supercell transformation matrix

    Returns:
        Phase factors for each atom, shape (n_atoms,)

    Examples:
        >>> phases = calculate_phase_factors(q, atoms, S)
        >>> phases.shape
        (4,)
    """
    n_atoms = len(structure)
    scaled_positions = structure.get_scaled_positions()

    phases = np.exp(-2j * np.pi * np.dot(scaled_positions, qpoint))

    return phases


def apply_phases_to_mode(mode: PhononMode, phase_factors: np.ndarray) -> np.ndarray:
    """Apply phase factors to a phonon mode eigenvector.

    Parameters:
        mode: PhononMode to apply phases to
        phase_factors: Phase factors for each atom, shape (n_atoms,)

    Returns:
        Phase-modified eigenvector

    Examples:
        >>> modified_eigvec = apply_phases_to_mode(mode, phases)
    """
    n_atoms = mode.n_atoms

    if len(phase_factors) != n_atoms:
        raise ValueError(
            f"Number of phase factors ({len(phase_factors)}) "
            f"must match number of atoms ({n_atoms})"
        )

    phases_cartesian = np.repeat(phase_factors, 3)

    modified_eigenvector = mode.eigenvector * phases_cartesian

    return modified_eigenvector


def create_supercell_mode(mode: PhononMode, supercell_matrix: np.ndarray) -> PhononMode:
    """Create a phonon mode for a supercell by tiling and applying phases.

    Parameters:
        mode: Original phonon mode (in primitive cell)
        supercell_matrix: 3x3 supercell transformation matrix

    Returns:
        New PhononMode for the supercell structure
    """
    from phononkit.supercells.supercell_builder import build_supercell

    supercell_structure = build_supercell(mode.structure, supercell_matrix)

    # 1. Tile the eigenvector to match supercell size
    n_atoms_primitive = mode.n_atoms
    det_s = int(round(abs(np.linalg.det(supercell_matrix))))
    tiled_eigenvector = np.tile(mode.eigenvector, det_s)

    # 2. Calculate phase factors for all atoms in supercell
    # Note: This requires knowing the relationship between supercell atoms
    # and primitive cell atoms. ASE's make_supercell tiles them in a specific order.
    phase_factors = calculate_phase_factors(
        mode.qpoint, supercell_structure, supercell_matrix
    )

    # 3. Apply phases
    phases_cartesian = np.repeat(phase_factors, 3)
    supercell_eigenvector = tiled_eigenvector * phases_cartesian

    return PhononMode(
        frequency=mode.frequency,
        eigenvector=supercell_eigenvector,
        qpoint=mode.qpoint,
        structure=supercell_structure,
        gauge=mode.gauge,
    )
