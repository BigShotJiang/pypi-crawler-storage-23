"""Supercell construction and phase factor handling.

This module provides:
- Supercell building from transformation matrices
- Phase factor calculation and application
- Supercell-qpoint commensurability validation
"""

from phononkit.supercells.supercell_builder import build_supercell, build_supercell_for_qpoint
from phononkit.supercells.supercell_phase import (
    calculate_phase_factors,
    apply_phases_to_mode,
    create_supercell_mode,
)
from phononkit.supercells.supercell import Supercell

__all__ = [
    "build_supercell",
    "build_supercell_for_qpoint",
    "calculate_phase_factors",
    "apply_phases_to_mode",
    "create_supercell_mode",
    "Supercell",
]
