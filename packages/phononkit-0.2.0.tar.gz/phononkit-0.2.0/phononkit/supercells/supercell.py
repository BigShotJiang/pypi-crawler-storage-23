"""Supercell data structure for phonon calculations.

This module defines the Supercell class which manages the relationship
between primitive and supercell structures, including atom mapping
and lattice translations.
"""

import numpy as np
from ase import Atoms
from typing import Optional


class Supercell:
    """Data structure representing a supercell and its relationship to a primitive cell.

    Attributes:
        supercell: The supercell Atoms object
        primitive: The primitive unit cell Atoms object
        matrix: 3x3 transformation matrix
        atom_map: Mapping from supercell atom indices to primitive atom indices
        translations: Lattice translation vectors R_L for each supercell atom
    """

    def __init__(
        self,
        primitive: Atoms,
        matrix: np.ndarray,
        supercell: Optional[Atoms] = None,
    ):
        """Initialize Supercell and calculate mapping.

        Parameters:
            primitive: Primitive unit cell structure
            matrix: 3x3 supercell transformation matrix
            supercell: Pre-built supercell structure (optional)
        """
        self.primitive = primitive.copy()
        self.matrix = np.array(matrix)
        
        if supercell is None:
            from ase.build import make_supercell
            self.supercell = make_supercell(primitive, self.matrix)
        else:
            self.supercell = supercell.copy()

        self._calculate_mapping()

    def _calculate_mapping(self):
        """Calculate the mapping from supercell atoms to primitive atoms.
        
        This finds which primitive atom each supercell atom corresponds to,
        and the lattice translation vector R_L.
        """
        n_prim = len(self.primitive)
        n_super = len(self.supercell)
        
        self.atom_map = np.zeros(n_super, dtype=int)
        self.translations = np.zeros((n_super, 3))
        
        # Positions of primitive atoms
        prim_pos = self.primitive.positions
        super_pos = self.supercell.positions
        
        # For each atom in the supercell, find its primitive counterpart and R_L
        # R_super = R_prim + R_L
        
        for i in range(n_super):
            # Map back to primitive index
            # Simple assumption: make_supercell preserves the order of atoms in blocks
            i_prim = i % n_prim
            self.atom_map[i] = i_prim
            
            # Lattice translation vector R_L in Cartesian
            R_L = super_pos[i] - prim_pos[i_prim]
            self.translations[i] = R_L

    def get_phase_factors(self, qpoint: np.ndarray) -> np.ndarray:
        """Calculate phase factors exp(i 2pi q . R_L) for each atom.

        Parameters:
            qpoint: Q-vector in reduced coordinates of the primitive cell

        Returns:
            Phase factors for each supercell atom, shape (n_super,)
        """
        # q . R_L where q is reduced and R_L is Cartesian
        # R_L_reduced = R_L @ inv_primitive_cell
        inv_prim_cell = np.linalg.inv(self.primitive.cell)
        R_L_reduced = self.translations @ inv_prim_cell
        
        phases = np.exp(2j * np.pi * np.dot(R_L_reduced, qpoint))
        return phases

    def __len__(self):
        return len(self.supercell)
