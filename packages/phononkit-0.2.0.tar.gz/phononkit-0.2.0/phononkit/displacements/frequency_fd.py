"""Calculate phonon frequencies from energy finite differences.

Background
----------
For a harmonic potential along mass-weighted normal mode coordinate q_m:

    V(q_m) = 1/2 * omega_m^2 * q_m^2                               (1)

The Cartesian displacement of atom j caused by mode amplitude A is:

    u_{j,alpha} = ( e_{m,j,alpha} / sqrt(m_j) ) * A                (2)

where e_{m,j,alpha} is the (Phonopy-normalized) eigenvector component
satisfying  sum_j |e_{m,j}|^2 = 1,  and  m_j is the atomic mass [AMU].

Method
------
Evaluate the potential energy at the equilibrium structure and at the
+A and -A displaced structures:

    dE = [ E(+A) + E(-A) ] / 2 - E(0)                              (3)

For a harmonic potential this gives  dE = 1/2 * omega^2 * A^2  *per unit cell*.
Because the calculator returns the energy of the full supercell with N_cells
primitive-cell replicas, each contributing equally:

    E_supercell(A) = N_cells * 1/2 * omega^2 * A^2                  (4)

Solving for omega^2:

    omega^2 = 2 * dE / ( N_cells * A^2 )                            (5)

Units
-----
Quantity     Symbol    Unit
---------    ------    -------------------------
Amplitude    A         Ang * sqrt(AMU)
Energy       dE        eV
omega^2               eV / (Ang^2 * AMU)
Frequency    f         THz

Conversion:  f [THz] = sqrt(omega^2) * 15.633302
(Phonopy constant, equivalent to sqrt(eV / (Ang^2 * AMU)) / (2*pi) * 1e-12 s)

Sign convention
---------------
If omega^2 < 0 (unstable / imaginary mode), the returned frequency is
negative, matching Phonopy's convention (e.g. -6.0 THz means 6.0i THz).
"""

import numpy as np
from ase.calculators.calculator import Calculator
from typing import Optional, Union

from phononkit.modes.phonon_mode import PhononMode
from phononkit.supercells.supercell import Supercell
from phononkit.displacements.mode_displacement import calculate_supercell_displacement


def calculate_mode_frequency_fd(
    mode: PhononMode,
    calculator: Calculator,
    supercell: Optional[Union[Supercell, np.ndarray]] = None,
    amplitude: float = 0.01,
) -> float:
    """Calculate the phonon frequency using central finite differences of energy.

    Displaces atoms by +A and -A along the mode eigenvector (Eq. 2 in module
    docstring), evaluates potential energies, and extracts the frequency from
    the curvature of the harmonic potential (Eq. 5):

        omega^2 = 2 * dE / (N_cells * A^2)

    where dE = [E(+A) + E(-A)] / 2 - E(0)  and  N_cells is the number of
    primitive cells in the supercell (needed because the calculator reports
    the total supercell energy).

    Parameters
    ----------
    mode : PhononMode
        The phonon mode to evaluate.
    calculator : Calculator
        ASE-compatible calculator that provides potential energies.
    supercell : Supercell or (3, 3) array, optional
        Supercell definition. If None, the primitive cell is used (N_cells=1).
    amplitude : float
        Normal-mode coordinate amplitude A in units of **Ang * sqrt(AMU)**.
        The resulting Cartesian displacement of atom j is
        ``u_j = eig_j / sqrt(m_j) * A``.
        Default 0.01 Ang*sqrt(AMU) gives displacements of order ~1e-3 Å,
        well within the harmonic regime.

    Returns
    -------
    float
        Frequency in THz. A **negative** value indicates an imaginary
        (unstable) mode, matching Phonopy's convention.
    """
    if supercell is not None and not isinstance(supercell, Supercell):
        supercell = Supercell(mode.structure, supercell)

    base_structure = supercell.supercell.copy() if supercell else mode.structure.copy()
    base_structure.calc = calculator

    e_0 = base_structure.get_potential_energy()

    # The PhonopyCalculator returns the energy of the full supercell.
    # With N_cells primitive cells, each cell contributes 1/2*omega^2*A^2 to the
    # harmonic energy, so: E_supercell = N_cells * 1/2 * omega^2 * A^2
    # => omega^2 = 2 * dE / (N_cells * amplitude^2)
    n_prim = mode.n_atoms
    n_sc = len(base_structure)
    n_cells = n_sc // n_prim  # number of primitive cells in supercell

    disp_plus = calculate_supercell_displacement(
        mode, supercell, amplitude=amplitude, phase=1.0, normalize=False, real_only=True
    )
    disp_minus = calculate_supercell_displacement(
        mode, supercell, amplitude=-amplitude, phase=1.0, normalize=False, real_only=True
    )

    struct_plus = base_structure.copy()
    struct_plus.calc = calculator
    struct_plus.positions += disp_plus
    e_plus = struct_plus.get_potential_energy()

    struct_minus = base_structure.copy()
    struct_minus.calc = calculator
    struct_minus.positions += disp_minus
    e_minus = struct_minus.get_potential_energy()

    # Average symmetric energy rise: dE = (E(+A) + E(-A))/2 - E(0)
    dE = ((e_plus - e_0) + (e_minus - e_0)) / 2.0

    # omega^2 in [eV / (Ang^2 * AMU)], convert to THz via Phonopy constant
    omega_sq = (2.0 * dE) / (n_cells * amplitude ** 2)
    const_factor = 15.633302  # sqrt(eV / (Ang^2 * AMU)) -> THz

    if omega_sq >= 0:
        return float(np.sqrt(omega_sq) * const_factor)
    else:
        return float(-np.sqrt(-omega_sq) * const_factor)
