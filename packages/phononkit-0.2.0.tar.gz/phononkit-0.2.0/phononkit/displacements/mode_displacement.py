"""Displacement generation for phonon modes.

This module provides functions for generating atomic displacements
from phonon modes.
"""

import numpy as np
from ase import Atoms
from typing import Optional, Union

from phononkit.modes.phonon_mode import PhononMode
from phononkit.supercells.supercell import Supercell


def calculate_supercell_displacement(
    mode: PhononMode, 
    supercell: Optional[Union[Supercell, np.ndarray]] = None,
    amplitude: float = 1.0,
    phase: complex = 1.0,
    normalize: bool = True,
    qpoint: Optional[np.ndarray] = None,
    real_only: bool = False,
) -> np.ndarray:
    """Calculate atomic displacements for a supercell.

    Parameters:
        mode: PhononMode to generate displacement for
        supercell: Supercell object or 3x3 matrix for supercell construction.
                  If None, uses primitive cell (1x1x1).
        amplitude: Displacement amplitude in Angstroms
        phase: Complex phase factor or phase angle in radians (if complex).
               If normalization is used, this defines the phase 
               of the largest displacement component.
        normalize: If True (default), use Phonopy-consistent normalization:
                  - Scaled by 1/sqrt(N_atoms_supercell).
                  - Phase shift applied such that the max-abs element matches 'phase'.
                  If False, 'amplitude' is a direct multiplier.
        qpoint: Optional q-vector. If None, uses mode.qpoint.
        real_only: If True, return only the real part of the displacement.

    Returns:
        Atomic displacements, shape (n_super_atoms, 3)
    """
    if qpoint is None:
        qpoint = mode.qpoint

    # 1. Base primitive displacement: eig / sqrt(mass)
    n_atoms_prim = mode.n_atoms
    eigenvector = mode.eigenvector.reshape(n_atoms_prim, 3)
    masses_prim = mode.atomic_masses
    u_base = eigenvector / np.sqrt(masses_prim)[:, np.newaxis]

    # 2. Handle Supercell
    if supercell is None:
        # 1x1x1 case
        n_atoms_sc = n_atoms_prim
        atom_map = np.arange(n_atoms_prim)
        sc_pos = mode.structure.positions
        inv_prim_cell = np.linalg.inv(mode.structure.cell)
    else:
        if not isinstance(supercell, Supercell):
            supercell_obj = Supercell(mode.structure, supercell)
        else:
            supercell_obj = supercell
        
        n_atoms_sc = len(supercell_obj)
        atom_map = supercell_obj.atom_map
        sc_pos = supercell_obj.supercell.positions
        inv_prim_cell = np.linalg.inv(supercell_obj.primitive.cell)

    # 3. Apply phase factors and tile to supercell
    # Phonopy formula: phase = exp(2j * pi * q . (R_L + tau_i))
    pos_reduced = sc_pos @ inv_prim_cell
    phase_factors = np.exp(2j * np.pi * np.dot(pos_reduced, qpoint))

    u_sc = np.zeros((n_atoms_sc, 3), dtype=complex)
    for i in range(n_atoms_sc):
        u_sc[i] = u_base[atom_map[i]] * phase_factors[i]

    # 4. Normalization and Phase Shift
    if normalize:
        # Phonopy formula: u = (scaled_eig / sqrt(N)) * phase_factor * amplitude
        u_sc /= np.sqrt(n_atoms_sc)
        
        # Consistent phase shift: max element phase matches input 'phase'
        u_rav = u_sc.ravel()
        idx_max = np.argmax(np.abs(u_rav))
        max_val = u_rav[idx_max]
        if np.abs(max_val) > 1e-12:
            phase_for_zero = max_val / np.abs(max_val)
        else:
            phase_for_zero = 1.0
            
        target_phase = phase if isinstance(phase, complex) else np.exp(1j * phase)
        u_sc *= (target_phase / phase_for_zero) * amplitude
        
    else:
        # Direct multiplier
        u_sc *= phase * amplitude

    if real_only:
        return u_sc.real
    return u_sc


def generate_displaced_structure(
    structure: Atoms,
    displacement: np.ndarray,
) -> Atoms:
    """Generate a structure with atomic displacements applied.

    Parameters:
        structure: Original atomic structure
        displacement: Atomic displacements in Cartesian coordinates, shape (n_atoms, 3)

    Returns:
        New Atoms object with displacements applied

    Examples:
        >>> new_atoms = generate_displaced_structure(atoms, displacement)
    """
    if len(structure) != displacement.shape[0]:
        raise ValueError(
            f"Structure has {len(structure)} atoms but "
            f"displacement has {displacement.shape[0]} rows"
        )

    new_structure = structure.copy()
    new_structure.positions = structure.positions + displacement

    return new_structure


def generate_mode_displacement(
    mode: PhononMode, amplitude: float = 1.0
) -> Atoms:
    """Generate a displaced structure from a phonon mode.

    Parameters:
        mode: PhononMode to generate displacement for
        amplitude: Displacement amplitude in Angstroms

    Returns:
        New Atoms object with mode displacement applied
    """
    displacement = calculate_supercell_displacement(mode, amplitude=amplitude, real_only=True)
    displaced_structure = generate_displaced_structure(mode.structure, displacement)

    return displaced_structure


def generate_supercell_structure(
    mode: PhononMode,
    supercell: Union[Supercell, np.ndarray],
    amplitude: float = 1.0,
    qpoint: Optional[np.ndarray] = None,
) -> Atoms:
    """Generate a displaced supercell structure from a phonon mode.

    Parameters:
        mode: PhononMode to generate displacement for
        supercell: Supercell object or 3x3 matrix for supercell construction
        amplitude: Displacement amplitude in Angstroms
        qpoint: Optional q-vector. If None, uses mode.qpoint.

    Returns:
        Displaced supercell structure (ase.Atoms)
    """
    # 1. Ensure we have a Supercell object
    if not isinstance(supercell, Supercell):
        supercell_obj = Supercell(mode.structure, supercell)
    else:
        supercell_obj = supercell

    # 2. Calculate displacements (passing the supercell_obj to avoid duplication)
    displacements = calculate_supercell_displacement(
        mode=mode,
        supercell=supercell_obj,
        amplitude=amplitude,
        qpoint=qpoint,
        real_only=True
    )

    # 3. Generate displaced structure
    new_structure = supercell_obj.supercell.copy()
    new_structure.positions += displacements
        
    return new_structure
