"""Thermal displacement pattern generation.

This module provides functions for generating thermal displacement
patterns at specified temperatures using Bose-Einstein statistics.
"""

import numpy as np
from ase import Atoms
from typing import Optional

from ase import units
from phononkit.modes.phonon_mode import PhononMode
from phononkit.modes.mode_collection import PhononModeCollection
from phononkit.displacements.mode_displacement import calculate_supercell_displacement

# Energy of 1 THz phonon in eV: E = h * f
# In ASE, units.J is Joules per internal energy unit (eV)
# units._hplanck is Planck constant in J*s
# So h (eV*s) = units._hplanck * units.J
H = units._hplanck * units.J
THZ_TO_EV = H * 1e12
HBAR = (units._hbar * units.J)
KB = units.kB


def bose_einstein(frequencies: np.ndarray, temperature: float) -> np.ndarray:
    """Calculate Bose-Einstein occupation factors.

    Parameters:
        frequencies: Mode frequencies in THz, shape (n_modes,)
        temperature: Temperature in Kelvin

    Returns:
        Occupation factors for each mode, shape (n_modes,)
    """
    if temperature <= 0:
        return np.zeros_like(frequencies)

    # Use ASE units (eV) for ratio (dimensionless)
    energies_ev = frequencies * THZ_TO_EV
    occupation = 1.0 / (np.exp(energies_ev / (KB * temperature)) - 1.0)

    return occupation


def get_thermal_amplitude(
    modes: PhononModeCollection,
    temperature: float = 300.0
) -> np.ndarray:
    """Calculate the scalar thermal displacement amplitude multiplier for each mode.

    Parameters:
        modes: PhononModeCollection with multipe modes
        temperature: Temperature in Kelvin

    Returns:
        Scalar amplitudes for each mode, shape (n_modes,)
    """
    if modes.n_modes == 0:
        return np.array([])
        
    n_qpoints = len(modes.qpoints) if len(modes.qpoints) > 0 else 1
    occupation = bose_einstein(modes.frequencies, temperature)
    
    # hbar_internal (eV * internal_time)
    from ase import units
    hbar_internal = HBAR * units.s
    
    amplitudes = np.zeros(modes.n_modes)
    for i, (mode, n) in enumerate(zip(modes, occupation)):
        if mode.frequency <= 1e-6:
            continue
            
        omega_internal = 2.0 * np.pi * mode.frequency * 1e12 / units.s
        amplitudes[i] = np.sqrt(hbar_internal * (n + 0.5) / (n_qpoints * omega_internal))
        
    return amplitudes


def generate_thermal_displacement(
    modes: PhononModeCollection, 
    temperature: float = 300.0,
    random_seed: Optional[int] = None
) -> np.ndarray:
    """Generate thermal displacement pattern for a collection of modes.

    Parameters:
        modes: PhononModeCollection with multiple modes
        temperature: Temperature in Kelvin
        random_seed: Seed for random phases (optional)

    Returns:
        Thermal displacement pattern in Angstroms, shape (n_atoms, 3)
    """
    if modes.n_modes == 0:
        raise ValueError("No modes in collection")

    n_qpoints = len(modes.qpoints) if len(modes.qpoints) > 0 else 1

    frequencies = modes.frequencies
    occupation = bose_einstein(frequencies, temperature)

    if random_seed is not None:
        np.random.seed(random_seed)
    
    phases = np.exp(1j * np.random.uniform(0, 2 * np.pi, modes.n_modes))

    thermal_displacement = np.zeros((len(modes.modes[0].structure), 3), dtype=complex)

    # Use purely internal units for calculations
    # hbar_internal (eV * internal_time)
    from ase import units
    hbar_internal = HBAR * units.s

    for i, (mode, n) in enumerate(zip(modes, occupation)):
        if mode.frequency <= 1e-6:
            continue
            
        # u = sqrt(hbar_int * (n+0.5) / (N * m_int * omega_int))
        # Result is in Angstroms because N, m_int (amu), and omega_int (1/internal_time) 
        # are all in consistent ASE internal units.
        masses_internal = mode.atomic_masses # in amu (already internal units)
        omega_internal = 2.0 * np.pi * mode.frequency * 1e12 / units.s
        
        # Calculate a scalar multiplier and let generate_displacement handle eigenvector/sqrt(mass)
        # scalar_amp = sqrt(hbar * (n+0.5) / (N * omega))
        scalar_amp = np.sqrt(hbar_internal * (n + 0.5) / (n_qpoints * omega_internal))
        
        mode_displacement = calculate_supercell_displacement(
            mode, 
            amplitude=scalar_amp, 
            phase=phases[i], 
            normalize=False
        )
        thermal_displacement += mode_displacement

    return thermal_displacement.real


def generate_thermal_structure(
    modes: PhononModeCollection, temperature: float = 300.0
) -> Atoms:
    """Generate a structure with thermal displacements applied.

    Parameters:
        modes: PhononModeCollection with multiple modes
        temperature: Temperature in Kelvin

    Returns:
        New Atoms object with thermal displacements applied

    Examples:
        >>> thermal_atoms = generate_thermal_structure(modes, temperature=300)
    """
    displacement = generate_thermal_displacement(modes, temperature)
    from phononkit.displacements.mode_displacement import generate_displaced_structure

    return generate_displaced_structure(modes.modes[0].structure, displacement)
