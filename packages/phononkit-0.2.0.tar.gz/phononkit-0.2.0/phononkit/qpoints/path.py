"""Q-point path generation for band structure calculations.

This module provides automatic generation of standard q-paths for different
crystal systems, following conventions used in phonopy and other tools.
"""

import numpy as np
from typing import List, Tuple

# High-symmetry points for common crystal systems
# Labels follow standard conventions from phonopy
HIGH_SYMMETRY_POINTS = {
    "cubic": {
        "Gamma": np.array([0.0, 0.0, 0.0]),
        "X": np.array([0.5, 0.0, 0.0]),
        "M": np.array([0.5, 0.5, 0.0]),
        "R": np.array([0.5, 0.5, 0.5]),
    },
    "tetragonal": {
        "Gamma": np.array([0.0, 0.0, 0.0]),
        "X": np.array([0.5, 0.0, 0.0]),
        "M": np.array([0.5, 0.5, 0.0]),
        "Z": np.array([0.0, 0.0, 0.5]),
        "R": np.array([0.5, 0.5, 0.5]),
        "A": np.array([0.5, 0.5, 0.0]),
    },
    "orthorhombic": {
        "Gamma": np.array([0.0, 0.0, 0.0]),
        "X": np.array([0.5, 0.0, 0.0]),
        "S": np.array([0.5, 0.5, 0.0]),
        "Y": np.array([0.0, 0.5, 0.0]),
        "Z": np.array([0.0, 0.0, 0.5]),
        "U": np.array([0.5, 0.5, 0.5]),
        "R": np.array([0.5, 0.0, 0.5]),
        "T": np.array([0.0, 0.5, 0.5]),
    },
    "hexagonal": {
        "Gamma": np.array([0.0, 0.0, 0.0]),
        "K": np.array([1.0 / 3.0, 1.0 / 3.0, 0.0]),
        "M": np.array([0.5, 0.0, 0.0]),
        "A": np.array([0.0, 0.0, 0.5]),
        "L": np.array([0.5, 0.0, 0.5]),
        "H": np.array([1.0 / 3.0, 1.0 / 3.0, 0.5]),
    },
}


def interpolate_path(start: np.ndarray, end: np.ndarray, n_points: int) -> np.ndarray:
    """Linearly interpolate between two q-points.

    Parameters:
        start: Starting q-point in reduced coordinates
        end: Ending q-point in reduced coordinates
        n_points: Number of points along path (including endpoints)

    Returns:
        Array of q-points along path, shape (n_points, 3)

    Examples:
        >>> start = np.array([0.0, 0.0, 0.0])
        >>> end = np.array([0.5, 0.0, 0.0])
        >>> path = interpolate_path(start, end, 5)
        >>> path.shape
        (5, 3)
    """
    if n_points < 2:
        raise ValueError("n_points must be >= 2")

    t = np.linspace(0.0, 1.0, n_points).reshape(-1, 1)

    return (1.0 - t) * start + t * end


def generate_path(
    path_labels: List[Tuple[str, str]], n_points_per_segment: int = 20
) -> Tuple[np.ndarray, List[str]]:
    """Generate q-point path from a list of high-symmetry point pairs.

    Parameters:
        path_labels: List of tuples like [('Gamma', 'X'), ('X', 'M'), ...]
        n_points_per_segment: Number of points per segment

    Returns:
        qpoints: Array of q-points along path, shape (total_points, 3)
        labels: List of labels for special points

    Examples:
        >>> path_labels = [('Gamma', 'X'), ('X', 'M'), ('M', 'Gamma')]
        >>> qpoints, labels = generate_path(path_labels, 10)
        >>> len(qpoints)
        31
    """
    if len(path_labels) == 0:
        return np.array((0, 3)), []

    qpoints_list = []
    labels = [(0, path_labels[0][0])]

    current_pos = 0

    for i, (start_label, end_label) in enumerate(path_labels):
        start_point = HIGH_SYMMETRY_POINTS.get("cubic", {}).get(
            start_label,
            np.zeros(3),
        )
        end_point = HIGH_SYMMETRY_POINTS.get("cubic", {}).get(
            end_label,
            np.zeros(3),
        )

        segment = interpolate_path(start_point, end_point, n_points_per_segment)

        if i > 0:
            segment = segment[1:]  # Skip duplicate point

        qpoints_list.append(segment)
        labels.append((current_pos, end_label))
        current_pos += len(segment)

    qpoints = np.vstack(qpoints_list) if qpoints_list else np.zeros((0, 3))

    return qpoints, labels


def get_default_path(crystal_system: str = "cubic") -> List[Tuple[str, str]]:
    """Get default q-point path for a crystal system.

    Parameters:
        crystal_system: Crystal system ('cubic', 'tetragonal', 'orthorhombic', 'hexagonal')

    Returns:
        List of (start_label, end_label) tuples

    Examples:
        >>> get_default_path('cubic')
        [('Gamma', 'X'), ('X', 'M'), ('M', 'Gamma'), ('Gamma', 'R'), ('R', 'M')]
    """
    default_paths = {
        "cubic": [
            ("Gamma", "X"),
            ("X", "M"),
            ("M", "Gamma"),
            ("Gamma", "R"),
            ("R", "M"),
        ],
        "tetragonal": [
            ("Gamma", "X"),
            ("X", "M"),
            ("M", "Gamma"),
            ("Gamma", "Z"),
            ("Z", "R"),
        ],
        "orthorhombic": [
            ("Gamma", "X"),
            ("X", "S"),
            ("S", "Y"),
            ("Y", "Gamma"),
            ("Gamma", "Z"),
        ],
        "hexagonal": [
            ("Gamma", "M"),
            ("M", "K"),
            ("K", "Gamma"),
            ("Gamma", "A"),
            ("A", "L"),
        ],
    }

    return default_paths.get(crystal_system, default_paths["cubic"])
