"""Q-point mathematics and grid generation.

This module provides functions for:
- Generating q-point grids (Monkhorst-Pack, gamma-centered)
- Identifying and validating commensurate q-points
- Automatic q-path generation for band structures
- Q-point utility functions

All functions are pure mathematical operations with no dependencies
on other phononkit modules (Layer 0).
"""

from phononkit.qpoints.grid import (
    generate_monkhorst_pack_grid,
    generate_gamma_centered_grid,
    reduce_qpoints_to_brillouin_zone,
)
from phononkit.qpoints.commensurate import (
    is_commensurate_qpoint,
    find_commensurate_qpoints,
    validate_supercell_commensurability,
    get_commensurate_grid,
)
from phononkit.qpoints.path import (
    interpolate_path,
    generate_path,
    get_default_path,
)
from phononkit.qpoints.utils import (
    qpoint_distance,
    reduce_qpoint,
    find_nearest_qpoint,
    is_gamma_point,
)

__all__ = [
    # Grid generation
    "generate_monkhorst_pack_grid",
    "generate_gamma_centered_grid",
    "reduce_qpoints_to_brillouin_zone",
    # Commensurate q-points
    "is_commensurate_qpoint",
    "find_commensurate_qpoints",
    "validate_supercell_commensurability",
    "get_commensurate_grid",
    # Q-point paths
    "interpolate_path",
    "generate_path",
    "get_default_path",
    # Utilities
    "qpoint_distance",
    "reduce_qpoint",
    "find_nearest_qpoint",
    "is_gamma_point",
]
