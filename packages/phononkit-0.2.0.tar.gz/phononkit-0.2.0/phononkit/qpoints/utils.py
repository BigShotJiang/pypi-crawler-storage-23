"""Q-point utility functions.

This module provides helper functions for q-point operations,
including distance calculations and symmetry transformations.
"""

import numpy as np


def qpoint_distance(q1: np.ndarray, q2: np.ndarray) -> float:
    """Calculate distance between two q-points.

    Parameters:
        q1: First q-point in reduced coordinates
        q2: Second q-point in reduced coordinates

    Returns:
        Distance between q-points

    Examples:
        >>> q1 = np.array([0.0, 0.0, 0.0])
        >>> q2 = np.array([0.5, 0.0, 0.0])
        >>> qpoint_distance(q1, q2)
        0.5
    """
    return np.linalg.norm(q2 - q1)


def reduce_qpoint(qpoint: np.ndarray) -> np.ndarray:
    """Reduce q-point to first Brillouin zone [0, 1).

    Parameters:
        qpoint: Q-point in reduced coordinates

    Returns:
        Reduced q-point in [0, 1)

    Examples:
        >>> qpoint = np.array([1.25, -0.3, 1.0])
        >>> reduced = reduce_qpoint(qpoint)
        >>> reduced
        array([0.25, 0.7, 0.  ])
    """
    return qpoint - np.floor(qpoint)


def find_nearest_qpoint(
    target: np.ndarray, qpoints: np.ndarray
) -> tuple[int, np.ndarray]:
    """Find nearest q-point to a target.

    Parameters:
        target: Target q-point in reduced coordinates
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)

    Returns:
        (index, qpoint) - Index and coordinates of nearest q-point

    Examples:
        >>> target = np.array([0.1, 0.2, 0.3])
        >>> qpoints = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
        >>> idx, qp = find_nearest_qpoint(target, qpoints)
        >>> idx
        0
    """
    if len(qpoints) == 0:
        raise ValueError("qpoints array is empty")

    distances = np.linalg.norm(qpoints - target, axis=1)

    nearest_idx = int(np.argmin(distances))

    return nearest_idx, qpoints[nearest_idx]


def is_gamma_point(qpoint: np.ndarray, tol: float = 1e-6) -> bool:
    """Check if q-point is gamma point (0, 0, 0).

    Parameters:
        qpoint: Q-point in reduced coordinates
        tol: Tolerance for checking zero

    Returns:
        True if q-point is gamma point

    Examples:
        >>> is_gamma_point(np.array([0.0, 0.0, 0.0]))
        True
        >>> is_gamma_point(np.array([0.5, 0.0, 0.0]))
        False
    """
    return np.allclose(qpoint, 0.0, atol=tol)
