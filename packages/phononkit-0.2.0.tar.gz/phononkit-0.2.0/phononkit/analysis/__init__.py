"""Structure analysis, species substitution, and symmetry.

This module provides:
- Atomic correspondence between structures
- Species substitution handling
- Symmetry analysis and irreducible representations
"""

from phononkit.analysis.structure import (
    create_atom_mapping,
    create_enhanced_atom_mapping,
    align_structures_by_com,
    project_out_acoustic_modes,
    decompose_displacement_to_modes,
)
from phononkit.analysis.substitution import (
    create_substitution_map,
    validate_substitution,
)
from phononkit.analysis.symmetry import (
    find_degenerate_modes,
    classify_mode_symmetry,
    generate_mode_summary,
)
from phononkit.analysis.irreps import (
    analyze_irreps,
    IrRepsEigen,
)

__all__ = [
    "find_atomic_correspondence",
    "apply_atomic_mapping",
    "create_substitution_map",
    "validate_substitution",
    "find_degenerate_modes",
    "classify_mode_symmetry",
    "generate_mode_summary",
    "analyze_irreps",
    "IrRepsEigen",
]
