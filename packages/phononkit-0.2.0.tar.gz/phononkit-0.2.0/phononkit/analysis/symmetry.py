"""Symmetry analysis and irreducible representations.

This module provides functionality for analyzing phonon mode
symmetries and identifying degenerate mode sets using
irreducible representations.
"""

import numpy as np
from ase import Atoms
from typing import List, Tuple

from phononkit.modes.phonon_mode import PhononMode
from phononkit.modes.mode_collection import PhononModeCollection


def find_degenerate_modes(
    modes: PhononModeCollection, freq_tol: float = 1e-6
) -> List[List[int]]:
    """Find groups of degenerate modes by frequency.

    Parameters:
        modes: PhononModeCollection to analyze
        freq_tol: Frequency tolerance for considering modes degenerate

    Returns:
        List of degenerate mode index groups

    Examples:
        >>> degen_groups = find_degenerate_modes(modes)
        >>> degen_groups
        [[0, 1], [2], [3, 4, 5]]
    """
    frequencies = modes.frequencies
    n_modes = len(frequencies)

    if n_modes == 0:
        return []

    freq_sorted_indices = np.argsort(frequencies)

    degenerate_groups = []
    current_group = [freq_sorted_indices[0]]

    for idx in freq_sorted_indices[1:]:
        if abs(frequencies[idx] - frequencies[current_group[-1]]) <= freq_tol:
            current_group.append(idx)
        else:
            degenerate_groups.append(current_group)
            current_group = [idx]

    degenerate_groups.append(current_group)

    return degenerate_groups


def classify_mode_symmetry(
    mode: PhononMode,
    freq_tol: float = 1e-3,
    q_tol: float = 1e-6,
) -> str:
    """Classify mode symmetry based on frequency and q-point.

    Acoustic modes are defined as modes with:
    - Frequency ≈ 0 (within tolerance)
    - At Gamma point (q = [0, 0, 0])

    This is the correct physical definition - acoustic modes correspond
    to uniform translations of the crystal, which only exist at Gamma
    and have zero frequency (in the harmonic approximation without strain).

    Parameters:
        mode: PhononMode to classify
        freq_tol: Frequency tolerance for zero frequency (THz), default 1e-3
        q_tol: Q-point tolerance for Gamma point, default 1e-6

    Returns:
        Symmetry classification label ("Acoustic" or "Optical")

    Examples:
        >>> label = classify_mode_symmetry(mode)
        >>> print(label)
        'Acoustic'  # If mode is at Gamma with freq ≈ 0
    """
    # Check if at Gamma point
    is_gamma = np.allclose(mode.qpoint, 0.0, atol=q_tol)

    # Check if frequency is approximately zero
    is_zero_freq = abs(mode.frequency) < freq_tol

    # Acoustic modes: must be BOTH at Gamma AND have zero frequency
    if is_gamma and is_zero_freq:
        return "Acoustic"

    # Everything else is Optical (including low-freq modes at non-Gamma points)
    return "Optical"


def generate_mode_summary(
    modes: PhononModeCollection,
    title: str = "Phonon Mode Summary",
) -> str:
    """Generate formatted summary table of phonon modes.

    Parameters:
        modes: PhononModeCollection to summarize
        title: Title for the summary table

    Returns:
        Formatted summary table as string

    Examples:
        >>> summary = generate_mode_summary(modes)
        >>> print(summary)
    """
    if modes.n_modes == 0:
        return "No modes to summarize"

    frequencies = modes.frequencies
    qpoints = np.array([mode.qpoint for mode in modes])

    summary_lines = [f"{title}\n"]
    summary_lines.append(
        f"{'Mode':<10} {'Frequency (THz)':<20} {'Q-point':<10} {'Symmetry':<10}\n"
    )
    summary_lines.append("-" * 65 + "\n")

    for idx, mode in enumerate(modes):
        freq = frequencies[idx]
        qpt = qpoints[idx]
        symmetry = classify_mode_symmetry(mode)

        summary_lines.append(f"{idx + 1:>6}{freq:>15.3f}{str(qpt):>15}{symmetry:>15}\n")

    summary_lines.append("-" * 65 + "\n")
    summary_lines.append(f"Total modes: {modes.n_modes}\n")

    return "".join(summary_lines)
