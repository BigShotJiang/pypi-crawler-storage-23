"""Species substitution handling.

This module provides functions for handling species substitution
in structural comparisons and mode projections.
"""

import numpy as np
from ase import Atoms
from typing import Dict, Optional

from phononkit.analysis.structure import (
    find_nearest_atoms,
)

def create_substitution_map(
    structure1: Atoms, structure2: Atoms, tol: float = 0.1
) -> Dict[str, str]:
    """Create species substitution map between two structures.

    Finds atomic correspondences and creates a mapping of which species
    in structure2 should replace which species in structure1.

    Parameters:
        structure1: First structure
        structure2: Second structure
        tol: Position matching tolerance

    Returns:
        Dictionary mapping structure1 species to structure2 species

    Examples:
        >>> sub_map = create_substitution_map(atoms1, atoms2)
        >>> sub_map
        {'Ti': 'Zr', 'O': 'O'}
    """
    mapping, _, _ = find_nearest_atoms(structure1, structure2)

    species1 = np.array(structure1.get_chemical_symbols())
    species2 = np.array(structure2.get_chemical_symbols())

    substitution_map: Dict[str, str] = {}

    for i, target_idx in enumerate(mapping):
        old_species = species1[i]
        new_species = species2[target_idx]

        if old_species != new_species:
            substitution_map[old_species] = new_species

    return substitution_map


def validate_substitution(substitution_map: dict) -> bool:
    """Validate a substitution map is well-formed.

    Parameters:
        substitution_map: Dictionary mapping old to new species

    Returns:
        True if valid, False otherwise

    Examples:
        >>> is_valid = validate_substitution({'Ti': 'Zr'})
        >>> is_valid
        True
    """
    if not isinstance(substitution_map, dict):
        return False

    for old_species, new_species in substitution_map.items():
        if not isinstance(old_species, str) or not isinstance(new_species, str):
            return False

        if old_species == new_species:
            return False

    return True
