"""Tests for commensurate q-point operations."""

import numpy as np
import pytest


def test_is_commensurate_qpoint_simple():
    """Test simple commensurate q-point check."""
    from phononkit.qpoints.commensurate import is_commensurate_qpoint

    qpoint = np.array([0.5, 0.0, 0.0])
    supercell_matrix = np.diag([2, 1, 1])
    assert is_commensurate_qpoint(qpoint, supercell_matrix)


def test_is_commensurate_qpoint_not_commensurate():
    """Test non-commensurate q-point check."""
    from phononkit.qpoints.commensurate import is_commensurate_qpoint

    qpoint = np.array([0.25, 0.0, 0.0])
    supercell_matrix = np.diag([2, 1, 1])
    assert not is_commensurate_qpoint(qpoint, supercell_matrix)


def test_find_commensurate_qpoints():
    """Test finding commensurate q-points from list."""
    from phononkit.qpoints.commensurate import find_commensurate_qpoints

    qpoints = np.array([[0.5, 0.0, 0.0], [0.25, 0.0, 0.0]])
    supercell_matrix = np.diag([2, 1, 1])
    mask = find_commensurate_qpoints(qpoints, supercell_matrix)
    assert mask.tolist() == [True, False]


def test_validate_supercell_commensurability():
    """Test validation of supercell commensurability."""
    from phononkit.qpoints.commensurate import validate_supercell_commensurability

    qpoints = np.array([[0.5, 0.0, 0.0], [0.0, 0.0, 0.0]])
    supercell_matrix = np.diag([2, 1, 1])
    assert validate_supercell_commensurability(qpoints, supercell_matrix)


def test_get_commensurate_grid():
    """Test generating commensurate grid."""
    from phononkit.qpoints.commensurate import get_commensurate_grid

    supercell_matrix = np.diag([2, 1, 1])
    qpoints, weights = get_commensurate_grid(supercell_matrix, (2, 2, 2))
    assert len(qpoints) > 0
    assert len(qpoints) < 64  # Should be filtered down
    assert len(weights) == len(qpoints)
