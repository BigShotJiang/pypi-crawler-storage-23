"""Tests for q-point grid generation."""

import numpy as np
import pytest


def test_monkhorst_pack_grid_shape():
    """Test that Monkhorst-Pack grid has correct shape."""
    from phononkit.qpoints.grid import generate_monkhorst_pack_grid

    qpoints, weights = generate_monkhorst_pack_grid((4, 4, 4))
    assert qpoints.shape == (64, 3)
    assert weights.shape == (64,)
    assert np.allclose(weights.sum(), 1.0)


def test_gamma_centered_grid_has_gamma():
    """Test that gamma-centered grid includes gamma point."""
    from phononkit.qpoints.grid import generate_gamma_centered_grid

    qpoints, weights = generate_gamma_centered_grid((4, 4, 4), include_gamma=True)
    assert np.any(np.all(np.isclose(qpoints, 0.0), axis=1))


def test_gamma_centered_grid_exclude_gamma():
    """Test that gamma point can be excluded."""
    from phononkit.qpoints.grid import generate_gamma_centered_grid

    qpoints, weights = generate_gamma_centered_grid((4, 4, 4), include_gamma=False)
    assert not np.any(np.all(np.isclose(qpoints, 0.0), axis=1))


def test_reduce_to_brillouin_zone():
    """Test reduction to first Brillouin zone."""
    from phononkit.qpoints.grid import reduce_qpoints_to_brillouin_zone

    qpoints = np.array([[0.75, 0.0, 0.0], [-0.75, 0.0, 0.0]])
    reduced = reduce_qpoints_to_brillouin_zone(qpoints)
    assert np.allclose(reduced[0], [-0.25, 0.0, 0.0])
    assert np.allclose(reduced[1], [0.25, 0.0, 0.0])


def test_reduce_in_bz_unchanged():
    """Test that points in BZ are unchanged."""
    from phononkit.qpoints.grid import reduce_qpoints_to_brillouin_zone

    qpoints = np.array([[0.25, 0.0, 0.0], [-0.25, 0.0, 0.0]])
    reduced = reduce_qpoints_to_brillouin_zone(qpoints)
    assert np.allclose(reduced, qpoints)
