"""Tutorial 4: Simple One-Line API for Displaced Structures

This tutorial demonstrates the simplest possible API for generating
displaced structures - just one function call!

Usage:
    python tests/tutorials/04_simple_api.py
"""

import phononkit
from ase.io import write

# Path to phonopy data
yaml_path = "examples/data/phonopy_params.yaml"

print("Tutorial: Simple One-Function API")
print("=" * 50)

# Simple one-line API!
print("\nOne function call to generate displaced structure:")
print("-" * 50)

structure = phononkit.generate_structure_for_mode(
    yaml_path=yaml_path,
    qpoint=[0, 0, 0],  # Gamma point
    mode_index=2,  # 3rd mode (0-based)
    amplitude=0.5,  # 0.5 Angstroms
)

print("✓ Structure generated!")
print(f"  Formula: {structure.get_chemical_formula()}")
print(f"  Atoms: {len(structure)}")

# Save to file
print("\nSaving to file...")
output_file = "simple_api_output.vasp"
write(output_file, structure)
print(f"  Saved: {output_file}")

# Example with supercell
print("\n" + "-" * 50)
print("Example with 2x2x2 supercell:")
print("-" * 50)

structure_supercell = phononkit.generate_structure_for_mode(
    yaml_path=yaml_path,
    qpoint=[0, 0, 0],
    mode_index=2,
    amplitude=0.5,
    supercell=[2, 2, 2],  # 2x2x2 supercell (simple diagonal notation!)
)

print("✓ Supercell structure generated!")
print(f"  Formula: {structure_supercell.get_chemical_formula()}")
print(f"  Atoms: {len(structure_supercell)} (vs {len(structure)} in primitive)")

output_file_super = "simple_api_supercell.vasp"
write(output_file_super, structure_supercell)
print(f"  Saved: {output_file_super}")

print("\n" + "=" * 50)
print("✓ Tutorial complete!")
print("\nThe simple API:")
print(
    "  generate_structure_for_mode(yaml_path, qpoint, mode_index, amplitude, supercell)"
)
print("\nParameters:")
print("  - yaml_path: Path to phonopy YAML file")
print("  - qpoint: [qx, qy, qz] (e.g., [0,0,0] for Gamma)")
print("  - mode_index: Mode number (0=1st, 1=2nd, 2=3rd, ...)")
print("  - amplitude: Displacement in Angstroms")
print("  - supercell: Optional - [n1,n2,n3] for diagonal or 3x3 matrix")
print("\nSupercell input formats:")
print("  1. Simple: supercell=[2, 2, 2] → 2×2×2 supercell")
print("  2. Full: supercell=[[2,0,0], [0,2,0], [0,0,2]]")
print("\nReturns: ASE Atoms object (ready to use or save!)")
