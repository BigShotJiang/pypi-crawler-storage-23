"""Tests for PhononModeCollection class."""

import numpy as np
import pytest
from ase import Atoms

from phononkit.modes.mode import PhononMode
from phononkit.modes.collection import PhononModeCollection


def test_collection_initialization():
    """Test PhononModeCollection initialization."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    modes = []
    for i in range(5):
        eigenvector = np.random.randn(12) + 1j * np.random.randn(12)
        mode = PhononMode(float(i), eigenvector, np.zeros(3), structure)
        modes.append(mode)

    collection = PhononModeCollection(modes)

    assert collection.n_modes == 5
    assert len(collection) == 5


def test_collection_filter_by_frequency():
    """Test filtering by frequency."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    modes = []
    for i in range(10):
        eigenvector = np.random.randn(12) + 1j * np.random.randn(12)
        mode = PhononMode(float(i), eigenvector, np.zeros(3), structure)
        modes.append(mode)

    collection = PhononModeCollection(modes)
    filtered = collection.filter_by_frequency(freq_min=3, freq_max=7)

    assert filtered.n_modes == 5


def test_collection_filter_by_qpoint():
    """Test filtering by q-point."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    modes = []
    for i in range(10):
        qpoint = np.array([0.0, 0.0, 0.0] if i < 5 else [0.5, 0.0, 0.0])
        eigenvector = np.random.randn(12) + 1j * np.random.randn(12)
        mode = PhononMode(float(i), eigenvector, qpoint, structure)
        modes.append(mode)

    collection = PhononModeCollection(modes)
    gamma_modes = collection.filter_by_qpoint(np.zeros(3))

    assert gamma_modes.n_modes == 5


def test_collection_select_by_index():
    """Test selecting by index."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    modes = []
    for i in range(10):
        eigenvector = np.random.randn(12) + 1j * np.random.randn(12)
        mode = PhononMode(float(i), eigenvector, np.zeros(3), structure)
        modes.append(mode)

    collection = PhononModeCollection(modes)
    selected = collection.select_by_index([0, 2, 5])

    assert selected.n_modes == 3
    assert selected.modes[0].frequency == 0.0
    assert selected.modes[1].frequency == 2.0
    assert selected.modes[2].frequency == 5.0


def test_collection_get_gamma_modes():
    """Test getting gamma point modes."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    modes = []
    for i in range(10):
        qpoint = np.array([0.0, 0.0, 0.0] if i < 5 else [0.5, 0.0, 0.0])
        eigenvector = np.random.randn(12) + 1j * np.random.randn(12)
        mode = PhononMode(float(i), eigenvector, qpoint, structure)
        modes.append(mode)

    collection = PhononModeCollection(modes)
    gamma_modes = collection.get_gamma_point_modes()

    assert gamma_modes.n_modes == 5


def test_collection_iteration():
    """Test iterating over collection."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    modes = []
    for i in range(5):
        eigenvector = np.random.randn(12) + 1j * np.random.randn(12)
        mode = PhononMode(float(i), eigenvector, np.zeros(3), structure)
        modes.append(mode)

    collection = PhononModeCollection(modes)

    frequencies_from_iter = [mode.frequency for mode in collection]

    assert len(frequencies_from_iter) == 5
    assert list(range(5)) == frequencies_from_iter
