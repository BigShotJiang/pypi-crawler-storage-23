"""Tests for gauge transformation utilities."""

import numpy as np
import pytest
from ase import Atoms

from phononkit.modes.mode import PhononMode
from phononkit.modes.gauge import (
    transform_eigenvector_gauge,
    transform_phonon_mode_gauge,
)


def test_eigenvector_transform_r_to_r():
    """Test R to R transformation (no change)."""
    structure = Atoms(
        symbols=["Cu"] * 2,
        positions=[[0.0, 0.0, 0.0], [0.5, 0.5, 0.0]],
        cell=[[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    )
    eigenvector = np.ones(6, dtype=complex)
    qpoint = np.array([0.0, 0.0, 0.0])

    transformed = transform_eigenvector_gauge(eigenvector, qpoint, structure, "R", "R")

    assert np.allclose(transformed, eigenvector)


def test_eigenvector_transform_r_to_r_with_q():
    """Test R to R transformation with non-zero q-point (no change)."""
    structure = Atoms(
        symbols=["Cu"] * 2,
        positions=[[0.0, 0.0, 0.0], [0.5, 0.5, 0.0]],
        cell=[[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    )
    eigenvector = np.ones(6, dtype=complex)
    qpoint = np.array([0.5, 0.0, 0.0])

    transformed = transform_eigenvector_gauge(eigenvector, qpoint, structure, "R", "R")

    assert np.allclose(transformed, eigenvector)


def test_eigenvector_invalid_gauge():
    """Test error on invalid gauge value."""
    structure = Atoms(
        symbols=["Cu"] * 2,
        positions=[[0.0, 0.0, 0.0], [0.5, 0.5, 0.0]],
        cell=[[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    )
    eigenvector = np.ones(6, dtype=complex)
    qpoint = np.array([0.0, 0.0, 0.0])

    with pytest.raises(ValueError):
        transform_eigenvector_gauge(eigenvector, qpoint, structure, "X", "R")

    with pytest.raises(ValueError):
        transform_eigenvector_gauge(eigenvector, qpoint, structure, "R", "Y")


def test_phonon_mode_transform_gauge():
    """Test PhononMode gauge transformation."""
    structure = Atoms(
        symbols=["Cu"] * 2,
        positions=[[0.0, 0.0, 0.0], [0.5, 0.5, 0.0]],
        cell=[[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    )
    eigenvector = np.ones(6, dtype=complex)
    qpoint = np.array([0.5, 0.0, 0.0])

    mode_R = PhononMode(5.0, eigenvector, qpoint, structure, gauge="R")

    mode_r = transform_phonon_mode_gauge(mode_R, "r")

    assert mode_r.gauge == "r"
    assert mode_r.frequency == mode_R.frequency
    assert np.allclose(mode_r.qpoint, mode_R.qpoint)


def test_phonon_mode_transform_same_gauge():
    """Test PhononMode transformation to same gauge."""
    structure = Atoms(
        symbols=["Cu"] * 2,
        positions=[[0.0, 0.0, 0.0], [0.5, 0.5, 0.0]],
        cell=[[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    )
    eigenvector = np.ones(6, dtype=complex)
    qpoint = np.array([0.0, 0.0, 0.0])

    mode_R = PhononMode(5.0, eigenvector, qpoint, structure, gauge="R")
    mode_copy = transform_phonon_mode_gauge(mode_R, "R")

    assert mode_copy.gauge == "R"
    assert mode_copy.frequency == mode_R.frequency
    assert np.allclose(mode_copy.eigenvector, mode_R.eigenvector)
    assert mode_copy is not mode_R
