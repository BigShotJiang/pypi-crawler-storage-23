"""Tests for PhononMode class."""

import numpy as np
import pytest
from ase import Atoms

from phononkit.modes.mode import PhononMode


def test_phonon_mode_initialization():
    """Test PhononMode initialization."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    frequency = 5.0
    eigenvector = np.ones(12, dtype=complex)
    qpoint = np.array([0.0, 0.0, 0.0])

    mode = PhononMode(frequency, eigenvector, qpoint, structure)

    assert mode.frequency == 5.0
    assert mode.n_atoms == 4
    assert mode.gauge == "R"
    assert np.array_equal(mode.eigenvector, eigenvector)
    assert np.array_equal(mode.qpoint, qpoint)


def test_phonon_mode_invalid_eigenvector_shape():
    """Test PhononMode with invalid eigenvector shape."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    eigenvector = np.ones(10, dtype=complex)
    qpoint = np.array([0.0, 0.0, 0.0])

    with pytest.raises(ValueError):
        PhononMode(5.0, eigenvector, qpoint, structure)


def test_phonon_mode_invalid_qpoint_shape():
    """Test PhononMode with invalid qpoint shape."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    eigenvector = np.ones(12, dtype=complex)
    qpoint = np.array([0.0, 0.0])

    with pytest.raises(ValueError):
        PhononMode(5.0, eigenvector, qpoint, structure)


def test_phonon_mode_copy():
    """Test PhononMode copy."""
    structure = Atoms(
        symbols=["Cu"] * 4,
        positions=[[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
    )
    frequency = 5.0
    eigenvector = np.ones(12, dtype=complex)
    qpoint = np.array([0.0, 0.0, 0.0])

    mode = PhononMode(frequency, eigenvector, qpoint, structure)
    mode_copy = mode.copy()

    assert mode_copy.frequency == mode.frequency
    assert np.array_equal(mode_copy.eigenvector, mode.eigenvector)
    assert mode_copy is not mode
    assert mode_copy.eigenvector is not mode.eigenvector
