
from setuptools import setup, find_packages
from torch.utils.cpp_extension import BuildExtension, CUDAExtension
import os

setup(
    name='sylvica',
    version='1.0.0',
    description='Sylvester Vector Inference Core Accelerator (SYLVICA): Zero-Memory-Wall Matrix Multiplication',
    long_description='A Pure C++ CUDA implementation of Matrix Multiplication using Sylvester Isotropic Diagonal Topology. Supports FP16, Rectangular Matrices, and Batched 3D Tensors.',
    long_description_content_type='text/markdown',
    author='Zero-Class Mathematical Architect',
    url='https://github.com/yourusername/sylvica',  # (رابط افتراضي يمكن تعديله لاحقاً)
    packages=find_packages(),
    ext_modules=[
        CUDAExtension(
            name='sylvester_cuda._C', 
            sources=[os.path.join('csrc', 'interface.cpp'), os.path.join('csrc', 'sidrc_kernel.cu')],
            extra_compile_args={'cxx': ['-O3'], 'nvcc': ['-O3', '--use_fast_math', '-maxrregcount=128']}
        )
    ],
    cmdclass={'build_ext': BuildExtension},
    install_requires=['torch'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: POSIX :: Linux',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
    ],
)
