
#include <torch/extension.h>
torch::Tensor sidrc_forward_cuda(torch::Tensor A, torch::Tensor B);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &sidrc_forward_cuda, "SIDRC Forward Pass");
}
