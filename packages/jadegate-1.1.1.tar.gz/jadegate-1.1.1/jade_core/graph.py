"""
💠 JadeGate Skill Graph Index
==============================
Semantic graph index for AI agents to discover, relate, and compose skills.

Features:
- Tag-based similarity graph (skills sharing tags are connected)
- Domain-based clustering (skills hitting same APIs are related)
- Semantic search (fuzzy match on name, description, tags)
- Composition suggestions (find skill chains for complex tasks)
- Agent-friendly output (structured JSON for LLM consumption)

The graph is built at startup from the skill catalog — zero external deps.
"""

import os
import json
import re
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from collections import defaultdict


@dataclass
class SkillNode:
    skill_id: str
    name: str
    description: str
    skill_type: str  # MCP | Tool
    tags: List[str]
    domains: List[str]
    sandbox: str
    seal: str  # root | community | partial | none
    neighbors: Set[str] = field(default_factory=set)
    weight: float = 1.0  # trust-weighted score

    def to_dict(self):
        return {
            "skill_id": self.skill_id,
            "name": self.name,
            "description": self.description,
            "type": self.skill_type,
            "tags": self.tags,
            "domains": self.domains,
            "seal": self.seal,
            "trust_score": self.weight,
        }


class SkillGraph:
    """In-memory skill graph for semantic discovery."""

    def __init__(self):
        self.nodes: Dict[str, SkillNode] = {}
        self.tag_index: Dict[str, Set[str]] = defaultdict(set)
        self.domain_index: Dict[str, Set[str]] = defaultdict(set)
        self.word_index: Dict[str, Set[str]] = defaultdict(set)

    def load_from_directory(self, *dirs: str):
        """Load skills from JSON directories."""
        for d in dirs:
            if not os.path.exists(d):
                continue
            for fname in os.listdir(d):
                if not fname.endswith('.json') or fname.endswith('.sig.json'):
                    continue
                path = os.path.join(d, fname)
                with open(path) as f:
                    skill = json.load(f)
                self._add_skill(skill)
        self._build_edges()

    def load_from_json(self, skills_json: List[Dict]):
        """Load from pre-extracted skill list."""
        for s in skills_json:
            node = SkillNode(
                skill_id=s["id"],
                name=s["name"],
                description=s["description"],
                skill_type=s["type"],
                tags=s.get("tags", []),
                domains=s.get("domains", []),
                sandbox=s.get("sandbox", "strict"),
                seal=s.get("seal", "none"),
            )
            node.weight = {"root": 1.0, "community": 0.8, "partial": 0.5, "none": 0.2}[node.seal]
            self.nodes[node.skill_id] = node
            for tag in node.tags:
                self.tag_index[tag.lower()].add(node.skill_id)
            for domain in node.domains:
                self.domain_index[domain.lower()].add(node.skill_id)
            for word in self._tokenize(f"{node.name} {node.description} {' '.join(node.tags)}"):
                self.word_index[word].add(node.skill_id)
        self._build_edges()

    def _add_skill(self, skill: Dict):
        meta = skill.get("metadata", {})
        sec = skill.get("security", {})
        sig = skill.get("jade_signature")
        community = skill.get("community_signatures", [])
        seal = "root" if sig else ("community" if len(community) >= 5 else ("partial" if community else "none"))

        node = SkillNode(
            skill_id=skill["skill_id"],
            name=meta.get("name", ""),
            description=meta.get("description", ""),
            skill_type="MCP" if "mcp" in skill.get("skill_id", "") else "Tool",
            tags=meta.get("tags", []),
            domains=sec.get("network_whitelist", []),
            sandbox=sec.get("sandbox", "strict"),
            seal=seal,
        )
        node.weight = {"root": 1.0, "community": 0.8, "partial": 0.5, "none": 0.2}[seal]
        self.nodes[node.skill_id] = node

        for tag in node.tags:
            self.tag_index[tag.lower()].add(node.skill_id)
        for domain in node.domains:
            self.domain_index[domain.lower()].add(node.skill_id)
        for word in self._tokenize(f"{node.name} {node.description} {' '.join(node.tags)}"):
            self.word_index[word].add(node.skill_id)

    def _build_edges(self):
        """Connect skills that share tags or domains."""
        # Tag edges
        for tag, skill_ids in self.tag_index.items():
            ids = list(skill_ids)
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    self.nodes[ids[i]].neighbors.add(ids[j])
                    self.nodes[ids[j]].neighbors.add(ids[i])

        # Domain edges (stronger connection)
        for domain, skill_ids in self.domain_index.items():
            ids = list(skill_ids)
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    self.nodes[ids[i]].neighbors.add(ids[j])
                    self.nodes[ids[j]].neighbors.add(ids[i])

    def _tokenize(self, text: str) -> List[str]:
        """Simple word tokenizer."""
        return [w.lower() for w in re.findall(r'[a-zA-Z]{2,}', text)]

    def search(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Semantic search — returns ranked skills.
        Scoring: word match + tag match + trust weight.
        """
        query_words = set(self._tokenize(query))
        scores: Dict[str, float] = defaultdict(float)

        # Word matching
        for word in query_words:
            for sid in self.word_index.get(word, set()):
                scores[sid] += 1.0

            # Prefix matching for partial words
            for indexed_word, sids in self.word_index.items():
                if indexed_word.startswith(word) or word.startswith(indexed_word):
                    for sid in sids:
                        scores[sid] += 0.5

        # Tag exact match bonus
        for word in query_words:
            for sid in self.tag_index.get(word, set()):
                scores[sid] += 2.0

        # Domain match
        for word in query_words:
            for sid in self.domain_index.get(word, set()):
                scores[sid] += 1.5

        # Apply trust weight
        for sid in scores:
            scores[sid] *= self.nodes[sid].weight

        # Sort by score
        ranked = sorted(scores.items(), key=lambda x: -x[1])[:limit]
        return [
            {**self.nodes[sid].to_dict(), "relevance": round(score, 2)}
            for sid, score in ranked
        ]

    def related(self, skill_id: str, limit: int = 10) -> List[Dict]:
        """Find skills related to a given skill via graph edges."""
        if skill_id not in self.nodes:
            return []

        node = self.nodes[skill_id]
        results = []
        for neighbor_id in node.neighbors:
            neighbor = self.nodes[neighbor_id]
            # Count shared tags/domains for relevance
            shared_tags = set(t.lower() for t in node.tags) & set(t.lower() for t in neighbor.tags)
            shared_domains = set(d.lower() for d in node.domains) & set(d.lower() for d in neighbor.domains)
            score = len(shared_tags) * 1.0 + len(shared_domains) * 2.0
            score *= neighbor.weight
            results.append({
                **neighbor.to_dict(),
                "shared_tags": list(shared_tags),
                "shared_domains": list(shared_domains),
                "relevance": round(score, 2),
            })

        results.sort(key=lambda x: -x["relevance"])
        return results[:limit]

    def compose(self, query: str, max_chain: int = 5) -> Dict:
        """
        Suggest a skill composition chain for a complex task.
        Breaks query into sub-tasks and finds matching skills.
        """
        # Simple keyword-based decomposition
        words = self._tokenize(query)
        
        # Find all relevant skills
        candidates = self.search(query, limit=20)
        
        if not candidates:
            return {"chain": [], "description": "No matching skills found"}

        # Greedy chain: pick highest relevance, then find connected skills
        chain = []
        used = set()
        
        for candidate in candidates:
            if len(chain) >= max_chain:
                break
            sid = candidate["skill_id"]
            if sid in used:
                continue
            chain.append(candidate)
            used.add(sid)

        return {
            "query": query,
            "chain": chain,
            "chain_length": len(chain),
            "description": f"Suggested {len(chain)}-skill composition for: {query}",
        }

    def stats(self) -> Dict:
        """Graph statistics."""
        total_edges = sum(len(n.neighbors) for n in self.nodes.values()) // 2
        sealed = sum(1 for n in self.nodes.values() if n.seal == "root")
        return {
            "total_skills": len(self.nodes),
            "total_edges": total_edges,
            "sealed": sealed,
            "tags": len(self.tag_index),
            "domains": len(self.domain_index),
            "avg_connections": round(total_edges * 2 / max(len(self.nodes), 1), 1),
        }

    def to_agent_prompt(self) -> str:
        """
        Generate a compact prompt for AI agents describing available skills.
        This is what makes JadeGate agent-friendly.
        """
        lines = [
            "# Available JadeGate Skills",
            f"Total: {len(self.nodes)} verified skills\n",
        ]

        # Group by type
        by_type = defaultdict(list)
        for node in self.nodes.values():
            by_type[node.skill_type].append(node)

        for stype, nodes in sorted(by_type.items()):
            lines.append(f"## {stype} ({len(nodes)})")
            for node in sorted(nodes, key=lambda n: -n.weight):
                seal = "💠" if node.seal == "root" else "🔹" if node.seal in ("community", "partial") else "⬜"
                lines.append(f"- {seal} **{node.skill_id}**: {node.description}")
            lines.append("")

        lines.append("Use `jade search <query>` or `jade graph related <skill_id>` to explore.")
        return "\n".join(lines)

    def to_llms_txt(self) -> str:
        """
        Generate llms.txt format for AI agent discovery.
        Following the llms.txt standard.
        """
        lines = [
            "# JadeGate Skill Registry",
            "",
            "> Deterministic Security for AI Agent Skills",
            "> 101 verified skills with Ed25519 signature chain",
            "",
            "## API",
            "",
            "- `jade search <query>` — Semantic skill search",
            "- `jade list [--type mcp|tool]` — List all skills",
            "- `jade info <skill_id>` — Skill details",
            "- `jade verify <file>` — 5-layer verification",
            "- `jade graph related <skill_id>` — Related skills",
            "- `jade graph compose <task>` — Auto-compose skill chain",
            "",
            "## Skills",
            "",
        ]

        for node in sorted(self.nodes.values(), key=lambda n: n.skill_id):
            seal = "verified" if node.seal == "root" else "community" if node.seal == "community" else "unverified"
            lines.append(f"- [{node.skill_id}]({node.skill_id}): {node.description} ({seal})")

        return "\n".join(lines)
