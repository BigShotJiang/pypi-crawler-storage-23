"""
💠 JadeGate Auto-Discovery Engine
===================================
Makes AI agents smarter after `pip install jadegate`.

Three mechanisms:
1. jade manifest  → .well-known/jade.json for agent frameworks
2. jade doctor    → scan env, recommend skills
3. jadegate.activate() → inject into agent tool registry

Works with: OpenClaw, Claude MCP, LangChain, AutoGPT, CrewAI
"""

import os
import json
import re
from pathlib import Path
from typing import Dict, List, Optional

# Well-known paths agents check
MANIFEST_PATHS = [
    ".well-known/jade.json",
    ".jade/manifest.json",
    "jade.json",
]

# Environment variable patterns → skill recommendations
ENV_SKILL_MAP = {
    r"GITHUB_TOKEN|GH_TOKEN": ["mcp_github_create_issue", "mcp_github_pr_create", "github_create_issue"],
    r"SLACK_TOKEN|SLACK_BOT": ["slack_send_message", "mcp_slack_post"],
    r"OPENAI_API_KEY": ["mcp_openai_chat"],
    r"BRAVE_API_KEY": ["mcp_brave_search"],
    r"SENDGRID_API_KEY": ["mcp_sendgrid_email"],
    r"STRIPE_SECRET": ["mcp_stripe_payments"],
    r"SUPABASE_URL|SUPABASE_KEY": ["mcp_supabase_query"],
    r"TELEGRAM_BOT_TOKEN": ["telegram_send"],
    r"DISCORD_TOKEN|DISCORD_BOT": ["discord_send_message"],
    r"AWS_ACCESS_KEY": ["mcp_s3_upload", "mcp_lambda_invoke"],
    r"REDIS_URL|REDIS_HOST": ["mcp_redis_get"],
    r"DATABASE_URL|POSTGRES": ["mcp_supabase_query"],
    r"DOCKER_HOST": ["mcp_docker_run"],
    r"SENTRY_DSN": ["mcp_sentry_create_issue"],
    r"NOTION_TOKEN": ["mcp_notion_create_page"],
    r"LINEAR_API_KEY": ["mcp_linear_create_issue"],
}

# File patterns → skill recommendations
FILE_SKILL_MAP = {
    "package.json": ["mcp_npm_search", "mcp_npm_publish"],
    "requirements.txt": ["mcp_pypi_search"],
    "pyproject.toml": ["mcp_pypi_search"],
    "Dockerfile": ["mcp_docker_run", "mcp_docker_hub_search"],
    "docker-compose.yml": ["mcp_docker_run"],
    ".github/workflows": ["mcp_github_create_issue", "mcp_github_pr_create"],
    "terraform": ["mcp_terraform_plan"],
    "k8s": ["mcp_kubectl_apply"],
}


class JadeAutoDiscovery:
    """Scan environment and recommend skills."""

    def __init__(self, skill_dir: Optional[str] = None):
        self.skill_dir = skill_dir or self._find_skill_dir()
        self._skills_cache = None

    def _find_skill_dir(self) -> str:
        """Find installed skill directory."""
        candidates = [
            Path(__file__).parent.parent / "jade_skills",
            Path.home() / ".jade" / "skills",
            Path(os.environ.get("APPDATA", "/usr/local/share")) / "jade" / "skills",
        ]
        for c in candidates:
            if c.exists():
                return str(c)
        return str(candidates[0])

    def _load_skills(self) -> Dict:
        """Load all available skills."""
        if self._skills_cache:
            return self._skills_cache
        skills = {}
        sd = Path(self.skill_dir)
        for subdir in ['mcp', 'tools']:
            d = sd / subdir
            if not d.exists():
                continue
            for f in d.glob("*.json"):
                if f.name.endswith('.sig.json'):
                    continue
                try:
                    with open(f) as fh:
                        data = json.load(fh)
                    skills[data.get('skill_id', f.stem)] = data
                except Exception:
                    pass
        self._skills_cache = skills
        return skills

    def scan_env(self) -> Dict[str, List[str]]:
        """Scan environment variables and return matching skills."""
        matches = {}
        env_keys = set(os.environ.keys())
        for pattern, skill_ids in ENV_SKILL_MAP.items():
            for key in env_keys:
                if re.search(pattern, key, re.IGNORECASE):
                    for sid in skill_ids:
                        matches.setdefault(key, []).append(sid)
        return matches

    def scan_files(self, project_dir: str = ".") -> Dict[str, List[str]]:
        """Scan project files and return matching skills."""
        matches = {}
        pd = Path(project_dir)
        for pattern, skill_ids in FILE_SKILL_MAP.items():
            if (pd / pattern).exists():
                matches[pattern] = skill_ids
        return matches

    def doctor(self, project_dir: str = ".") -> Dict:
        """Full diagnostic: env + files + recommendations."""
        env_matches = self.scan_env()
        file_matches = self.scan_files(project_dir)
        skills = self._load_skills()

        # Collect all recommended skill IDs
        recommended = set()
        for sids in env_matches.values():
            recommended.update(sids)
        for sids in file_matches.values():
            recommended.update(sids)

        # Check which are available and sealed
        available = []
        missing = []
        for sid in sorted(recommended):
            if sid in skills:
                s = skills[sid]
                seal = s.get('jade_signature', {})
                available.append({
                    "skill_id": sid,
                    "name": s.get('metadata', {}).get('name', sid),
                    "sealed": bool(seal),
                    "seal_type": seal.get('seal_type', 'unsigned') if seal else 'unsigned',
                })
            else:
                missing.append(sid)

        return {
            "env_detected": env_matches,
            "files_detected": file_matches,
            "recommended_skills": available,
            "missing_skills": missing,
            "total_available": len(skills),
            "total_recommended": len(available),
        }

    def generate_manifest(self, project_dir: str = ".", output: str = None) -> str:
        """
        Generate .well-known/jade.json manifest.
        AI agents auto-discover this file.
        """
        diag = self.doctor(project_dir)
        skills = self._load_skills()

        manifest = {
            "jade_version": "1.0.0",
            "protocol": "jadegate",
            "registry": "https://jadegate.io",
            "total_skills": len(skills),
            "recommended": diag["recommended_skills"],
            "categories": {},
            "discovery": {
                "llms_txt": "https://jadegate.io/llms.txt",
                "api": "https://jadegate.io/api/v1/skills",
                "search": "https://jadegate.io/api/v1/search",
            },
            "agent_hint": (
                "This project uses JadeGate for verified AI skill management. "
                "Skills listed in 'recommended' are pre-verified and safe to use. "
                "All skills with seal_type='root' have been cryptographically signed "
                "by the JadeGate root authority."
            ),
        }

        # Categorize all skills
        for sid, s in skills.items():
            tags = s.get('metadata', {}).get('tags', [])
            for tag in tags[:3]:
                manifest["categories"].setdefault(tag, []).append(sid)

        out_path = output or os.path.join(project_dir, ".well-known", "jade.json")
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        with open(out_path, 'w') as f:
            json.dump(manifest, f, indent=2)

        return out_path

    def generate_agent_prompt(self) -> str:
        """
        Generate a compact system prompt snippet for AI agents.
        Inject this into your agent's system prompt to make it JadeGate-aware.
        """
        skills = self._load_skills()
        sealed = sum(1 for s in skills.values() if s.get('jade_signature'))

        lines = [
            "## 💠 JadeGate Skills Available",
            f"You have access to {len(skills)} verified skills ({sealed} root-sealed).",
            "Use `jade search <query>` to find skills, or `jade info <id>` for details.",
            "",
            "### Quick Reference (top skills by category):",
        ]

        # Group by first tag
        cats = {}
        for sid, s in skills.items():
            tags = s.get('metadata', {}).get('tags', [])
            cat = tags[0] if tags else 'other'
            cats.setdefault(cat, []).append(s.get('metadata', {}).get('name', sid))

        for cat in sorted(cats)[:15]:
            items = cats[cat][:5]
            lines.append(f"- **{cat}**: {', '.join(items)}")

        lines.extend([
            "",
            "### Trust Levels:",
            "- 💠 Root Sealed — cryptographically verified by JadeGate authority",
            "- 🔷 Org Sealed — verified by authorized organization",
            "- 🔹 Community — 5+ independent community signatures",
            "- ⚠️ Unsigned — use with caution",
        ])

        return "\n".join(lines)


def activate(project_dir: str = "."):
    """
    One-liner to make the current agent JadeGate-aware.
    
    Usage:
        import jadegate
        jadegate.activate()
    """
    disco = JadeAutoDiscovery()
    
    # Generate manifest if not exists
    manifest_path = os.path.join(project_dir, ".well-known", "jade.json")
    if not os.path.exists(manifest_path):
        disco.generate_manifest(project_dir)
    
    # Set environment hint for agents
    os.environ["JADE_ACTIVE"] = "1"
    os.environ["JADE_MANIFEST"] = manifest_path
    os.environ["JADE_SKILLS_COUNT"] = str(len(disco._load_skills()))
    
    return disco
