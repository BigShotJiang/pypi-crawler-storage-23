# Installation

Mangle.dev for Python can be installed in multiple ways depending on your preference.

## Option 1: Using pip (Recommended)

Install Mangle.dev directly from PyPI:

```bash
pip install mangledotdev
```

Or with pip3:

```bash
pip3 install mangledotdev
```

## Option 2: Manual Installation

Download the `mangledotdev.py` file and place it in your project directory or Python path.

### Project Structure Example

```
project/
├── mangledotdev.py
├── main.py
└── process.py
```

## Verifying Installation

After installation, verify that Mangle.dev is working correctly:

```python
# test_mangledotdev.py
try:
    from mangledotdev import InputManager, OutputManager
    print("Mangle imported successfully!")
except ImportError as e:
    print(f"Import error: {e}")
```

Run the test:

```bash
python test_mangledotdev.py
```