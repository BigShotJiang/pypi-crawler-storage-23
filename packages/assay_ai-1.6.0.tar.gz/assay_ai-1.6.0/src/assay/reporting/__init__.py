"""Assay reporting: generate shareable artifacts from scan results."""
