"""Compatibility helpers for third-party libraries used by receipts."""

from __future__ import annotations

__all__ = ["pyd"]

