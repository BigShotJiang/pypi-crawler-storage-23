# controlled-lr

Runtime LR control for PyTorch `LambdaLR` using a file-queue control plane.

## Features

- Wraps `torch.optim.lr_scheduler.LambdaLR`
- Runtime commands via JSON files in a queue directory
- Distributed-safe: rank 0 reads commands, broadcasts to all ranks
- Drains all queued commands in order on each poll
- Moves processed command files to `processed/` for debugging
- Supports step-based checks (`check_every`) and optional time-based checks (`check_every_seconds`)
- Command validation + versioning schema
- CLI helper (`lrctl`) to enqueue commands

## Install

```bash
pip install controlled-lr
```

For local development:

```bash
pip install -e .
```

## Command schema

```json
{"version": 1, "kind": "set_lr_scale", "value": 0.5}
```

or

```json
{"version": 1, "kind": "mul_lr_scale", "value": 0.5}
```

`kind` aliases accepted by CLI:
- `set-scale` -> `set_lr_scale`
- `mul-scale` -> `mul_lr_scale`

## Usage

```python
from controlled_lr import ControlledLambdaLR

sched = ControlledLambdaLR(
    optimizer,
    lr_lambda=lambda step: 1.0,
    queue_dir="/tmp/lr_cmds",
    check_every=500,
    check_every_seconds=2.0,
)

for step in range(100000):
    # train step
    sched.step()
```

Send commands at runtime:

```bash
lrctl --run_dir /tmp/lr_cmds set-scale 0.5
lrctl --run_dir /tmp/lr_cmds mul-scale 0.8
```
