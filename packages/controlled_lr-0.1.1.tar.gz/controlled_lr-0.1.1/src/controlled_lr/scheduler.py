from __future__ import annotations

import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import torch.distributed as dist
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LambdaLR

from .queue import CommandQueue, normalize_command


class ControlledLambdaLR:
    """
    LambdaLR wrapper with runtime LR scaling via file queue commands.

    Command schema:
        {"version": 1, "kind": "set_lr_scale"|"mul_lr_scale", "value": <float>}
    """

    def __init__(
        self,
        optimizer: Optimizer,
        lr_lambda: Callable[[int], float],
        *,
        queue_dir: str | Path,
        check_every: int = 500,
        check_every_seconds: float | None = None,
        last_epoch: int = -1,
    ):
        self.optimizer = optimizer
        self._user_lr_lambda = lr_lambda
        self.lr_scale = 1.0

        self.queue = CommandQueue(queue_dir)
        self.check_every = int(check_every)
        self.check_every_seconds = float(check_every_seconds) if check_every_seconds is not None else None

        self._step_calls = 0
        self._last_poll_ts = 0.0

        def combined(step: int) -> float:
            return self.lr_scale * float(self._user_lr_lambda(step))

        self._sched = LambdaLR(optimizer, lr_lambda=combined, last_epoch=last_epoch)

    def step(self, *args, **kwargs):
        out = self._sched.step(*args, **kwargs)
        self._step_calls += 1

        should_poll = False
        if self.check_every > 0 and (self._step_calls % self.check_every == 0):
            should_poll = True

        if self.check_every_seconds is not None and self.check_every_seconds > 0:
            now = time.time()
            if (now - self._last_poll_ts) >= self.check_every_seconds:
                should_poll = True

        if should_poll:
            self._poll_and_apply()

        return out

    def get_last_lr(self):
        return self._sched.get_last_lr()

    def state_dict(self):
        d = self._sched.state_dict()
        d["_controlled_lr_scale"] = self.lr_scale
        d["_controlled_step_calls"] = self._step_calls
        d["_controlled_last_poll_ts"] = self._last_poll_ts
        return d

    def load_state_dict(self, state_dict):
        self.lr_scale = float(state_dict.get("_controlled_lr_scale", 1.0))
        self._step_calls = int(state_dict.get("_controlled_step_calls", 0))
        self._last_poll_ts = float(state_dict.get("_controlled_last_poll_ts", 0.0))

        sd = dict(state_dict)
        sd.pop("_controlled_lr_scale", None)
        sd.pop("_controlled_step_calls", None)
        sd.pop("_controlled_last_poll_ts", None)
        self._sched.load_state_dict(sd)

    def _poll_and_apply(self):
        self._last_poll_ts = time.time()

        is_dist = dist.is_available() and dist.is_initialized()
        rank = dist.get_rank() if is_dist else 0

        commands: list[dict[str, Any]] = []
        if rank == 0:
            commands = self.queue.pop_all()

        if is_dist:
            obj_list = [commands]
            dist.broadcast_object_list(obj_list, src=0)
            commands = obj_list[0]

        for raw in commands:
            try:
                kind, value = normalize_command(raw)
            except Exception:
                continue

            if kind == "set_lr_scale":
                self.lr_scale = value
            elif kind == "mul_lr_scale":
                self.lr_scale *= value
