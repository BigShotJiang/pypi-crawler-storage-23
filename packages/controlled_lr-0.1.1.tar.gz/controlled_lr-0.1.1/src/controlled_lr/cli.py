from __future__ import annotations

import argparse
import json
import time
import uuid
from pathlib import Path


def _emit(run_dir: Path, kind: str, value: float):
    run_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "kind": kind,
        "value": float(value),
    }
    ts = int(time.time() * 1000)
    name = f"{ts:013d}-{uuid.uuid4().hex}.json"
    path = run_dir / name
    path.write_text(json.dumps(payload), encoding="utf-8")
    print(path)


def main():
    parser = argparse.ArgumentParser(prog="lrctl", description="Emit controlled-lr queue commands")
    parser.add_argument("--run_dir", required=True, help="Queue directory watched by ControlledLambdaLR")

    sub = parser.add_subparsers(dest="cmd", required=True)

    p_set = sub.add_parser("set-scale", help="Set absolute lr scale")
    p_set.add_argument("value", type=float)

    p_mul = sub.add_parser("mul-scale", help="Multiply lr scale")
    p_mul.add_argument("value", type=float)

    args = parser.parse_args()
    run_dir = Path(args.run_dir)

    if args.cmd == "set-scale":
        _emit(run_dir, "set_lr_scale", args.value)
    elif args.cmd == "mul-scale":
        _emit(run_dir, "mul_lr_scale", args.value)


if __name__ == "__main__":
    main()
