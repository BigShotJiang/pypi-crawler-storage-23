<div align="center">
  <img src="assets/mosaicx_hero.png" alt="MOSAICX" width="700"/>
</div>

<p align="center">
  <a href="https://pypi.org/project/mosaicx/"><img alt="PyPI" src="https://img.shields.io/pypi/v/mosaicx.svg?label=PyPI&style=flat-square&logo=python&logoColor=white&color=bd93f9"></a>
  <a href="https://doi.org/10.5281/zenodo.17601890"><img alt="DOI" src="https://img.shields.io/badge/DOI-10.5281%2Fzenodo.17601890-ff79c6?style=flat-square&labelColor=282a36&logo=zenodo&logoColor=white"></a>
  <a href="https://www.python.org/downloads/"><img alt="Python" src="https://img.shields.io/badge/Python-3.11%2B-50fa7b?style=flat-square&logo=python&logoColor=white"></a>
  <a href="https://www.apache.org/licenses/LICENSE-2.0"><img alt="License" src="https://img.shields.io/badge/License-Apache--2.0-ff79c6?style=flat-square&logo=apache&logoColor=white"></a>
  <a href="https://pepy.tech/project/mosaicx"><img alt="Downloads" src="https://img.shields.io/pepy/dt/mosaicx?style=flat-square&color=8be9fd&label=Downloads"></a>
</p>

<p align="center">
  <strong><a href="https://www.linkedin.com/company/digitx-lmu/">DIGIT-X Lab</a> &middot; LMU Munich</strong><br>
  Turn unstructured medical documents into validated, machine-readable JSON.<br>
  Runs locally &mdash; no PHI leaves your machine.
</p>

---

## How It Works

```mermaid
flowchart LR
    A["PDF / Image / Text"] --> B["Dual-Engine OCR"]
    B --> C["DSPy Pipeline"]
    C --> D["Validated JSON"]

    style A fill:#B5A89A,stroke:#8a7e72,color:#fff
    style B fill:#E87461,stroke:#c25a49,color:#fff
    style C fill:#E87461,stroke:#c25a49,color:#fff
    style D fill:#B5A89A,stroke:#8a7e72,color:#fff
```

MOSAICX ships with specialized pipelines for **radiology** and **pathology** reports, a **generic extraction** mode that adapts to any document, plus **de-identification** and **patient timeline summarization**. Every pipeline is a DSPy module -- meaning it can be optimized with labeled data for your specific use case.

**Why MOSAICX?** -- Fully local (no PHI leaves your machine), schema-driven (define exactly what to extract), dual-engine OCR (handles scans and handwriting), and DSPy-optimizable (improve accuracy with your own labeled data). One CLI for radiology, pathology, de-identification, and summarization.

## Quick Start

**One-line install** (Mac or Linux):

```bash
curl -fsSL https://raw.githubusercontent.com/DIGIT-X-Lab/MOSAICX/master/scripts/setup.sh | bash
```

Or install manually and let the setup wizard configure everything:

```bash
pip install mosaicx
mosaicx setup
```

Then extract structured data from a report:

```bash
mosaicx extract --document report.pdf --mode radiology
```

Check health anytime with `mosaicx doctor`. See the full [Quickstart guide](docs/quickstart.md) for details.

### Install Extras

```bash
pip install 'mosaicx[mcp]'       # + MCP server for AI agents
pip install 'mosaicx[query]'     # + fast tabular query stack (duckdb + polars)
pip install 'mosaicx[all]'       # everything
```

### Developer Fast Loop (Mac + vLLM-MLX, 120B)

```bash
# 1) serve your local model (already downloaded)
vllm-mlx serve mlx-community/gpt-oss-120b-4bit --port 8000

# 2) point MOSAICX to that server
export MOSAICX_LM=openai/mlx-community/gpt-oss-120b-4bit
export MOSAICX_API_BASE=http://127.0.0.1:8000/v1
export MOSAICX_API_KEY=dummy

# 3) verify the endpoint
curl -sS --max-time 5 http://127.0.0.1:8000/v1/models

# 4) run extraction + claim verify + query
mosaicx extract --document report.pdf --mode radiology -o output.json
mosaicx verify --document report.pdf --claim "patient BP is 128/82" --level thorough
mosaicx query --document report.pdf --chat --trace
```

> [!TIP]
> **Not on Apple Silicon?** Use [Ollama](https://ollama.com), [vLLM](https://docs.vllm.ai), or any OpenAI-compatible server. See the [Getting Started guide](docs/getting-started.md) for all backend options.

> [!TIP]
> **Want the fastest first success?** Follow [docs/quickstart.md](docs/quickstart.md) to run `extract`, `verify`, and `query` end-to-end in ~10 minutes.

## What You Can Do

| Capability | Commands | Guide |
|------------|----------|-------|
| **Extract structured data** from clinical documents | `mosaicx extract` | [Pipelines](docs/pipelines.md) |
| **Create and manage templates** for custom extraction targets | `mosaicx template create / list / refine` | [Schemas & Templates](docs/schemas-and-templates.md) |
| **Verify claims and outputs** against source evidence | `mosaicx verify` | [CLI Reference](docs/cli-reference.md) |
| **Query sources conversationally** with citations | `mosaicx query` | [CLI Reference](docs/cli-reference.md) |
| **De-identify** reports (LLM + regex belt-and-suspenders) | `mosaicx deidentify` | [CLI Reference](docs/cli-reference.md) |
| **Summarize patient timelines** across multiple reports | `mosaicx summarize` | [CLI Reference](docs/cli-reference.md) |
| **Optimize pipelines** with labeled data (DSPy) | `mosaicx optimize`, `mosaicx eval` | [Optimization](docs/optimization.md) |
| **Extend** with custom pipelines, MCP server, Python SDK | `mosaicx pipeline new`, `mosaicx mcp serve` | [Developer Guide](docs/developer-guide.md) |

Run any command with `--help` for full options. Complete reference: [docs/cli-reference.md](docs/cli-reference.md)

## Recipes

```bash
# Radiology report -> structured JSON
mosaicx extract --document ct_chest.pdf --mode radiology

# Template-driven extraction (define your own fields)
mosaicx template create --describe "echo report with LVEF, valve grades, impression"
mosaicx extract --document echo.pdf --template EchoReport

# Batch-process a folder of reports
mosaicx extract --dir ./reports --output-dir ./structured --mode radiology --format jsonl

# De-identify a clinical note
mosaicx deidentify --document note.txt

# Patient timeline from multiple reports
mosaicx summarize --dir ./patient_001/ --patient P001
```

See the full [CLI Reference](docs/cli-reference.md) for every flag and option.

## Privacy

> [!IMPORTANT]
> **Data stays on your machine.** MOSAICX runs against a local inference server by default -- no external API calls, no cloud uploads. For HIPAA/GDPR compliance guidance and cloud backend caveats, see [Configuration](docs/configuration.md).

## LLM Backends

MOSAICX talks to any OpenAI-compatible endpoint via DSPy + litellm. Pick the backend that fits your hardware -- override with env vars.

| Backend | Port | Example |
|---------|------|---------|
| **Ollama** | 11434 | Works out-of-the-box, no config needed |
| **llama.cpp** | 8080 | `llama-server -m model.gguf --port 8080` |
| **vLLM** | 8000 | `vllm serve gpt-oss:120b` |
| **SGLang** | 30000 | `python -m sglang.launch_server --model-path gpt-oss:120b` |
| **vLLM-MLX** | 8000 | `vllm-mlx serve mlx-community/gpt-oss-20b-MXFP4-Q8` (Apple Silicon) |

```bash
export MOSAICX_LM=openai/gpt-oss:120b
export MOSAICX_API_BASE=http://localhost:8000/v1   # point at your server
export MOSAICX_API_KEY=dummy                       # or your real key for cloud APIs
```

SSH tunneling, vLLM-MLX setup, batch tuning, and benchmarking: [docs/configuration.md](docs/configuration.md)

## OCR Engines

| Engine | Approach | Best for |
|--------|----------|----------|
| **Surya** | Layout detection + recognition | Clean printed text, fast |
| **Chandra** | Vision-Language Model (Qwen3-VL 9B) | Handwriting, complex layouts, tables |

By default both engines run in parallel, score each page, and pick the best result. Override with `MOSAICX_OCR_ENGINE=surya` or `chandra`.

## Configuration

```bash
# Essential vars -- point at your local server
export MOSAICX_LM=openai/mlx-community/gpt-oss-20b-MXFP4-Q8   # model name
export MOSAICX_API_BASE=http://localhost:8000/v1                # server URL
export MOSAICX_API_KEY=dummy                                    # or real key for cloud

# View active config
mosaicx config show
```

Full variable reference, `.env` file setup, and backend scenarios: [docs/configuration.md](docs/configuration.md)

## Documentation

| Guide | Description |
|-------|-------------|
| [Quickstart](docs/quickstart.md) | Fast setup and first successful run in ~10 minutes |
| [Getting Started](docs/getting-started.md) | Install, first extraction, basics |
| [Verify Guide](docs/verify.md) | Truth/adjudication workflows for claims and extraction output |
| [Query Guide](docs/query.md) | Grounded multi-turn querying with evidence and confidence |
| [Troubleshooting](docs/troubleshooting.md) | Debug slow query, wrong stats, fallback, and runtime issues |
| [Production Checklist](docs/production-checklist.md) | Deploy with reproducibility, gating, and auditability controls |
| [CLI Reference](docs/cli-reference.md) | Every command, every flag, examples |
| [Pipelines](docs/pipelines.md) | Pipeline inputs/outputs, JSONL formats |
| [Schemas & Templates](docs/schemas-and-templates.md) | Create and manage extraction schemas |
| [Optimization](docs/optimization.md) | Improve accuracy with DSPy optimizers |
| [Configuration](docs/configuration.md) | Env vars, backends, OCR, export formats |
| [MCP Server](docs/mcp-server.md) | AI agent integration via MCP |
| [Developer Guide](docs/developer-guide.md) | Custom pipelines, Python SDK |
| [Architecture](docs/architecture.md) | System design, key decisions |

## Development

```bash
git clone https://github.com/DIGIT-X-Lab/MOSAICX.git
cd MOSAICX
pip install -e ".[dev]"          # or: uv sync --group dev
pytest tests/ -q
```

See [Developer Guide](docs/developer-guide.md) for custom pipelines and the Python SDK.

## Citation

```bibtex
@software{mosaicx2025,
  title   = {MOSAICX: Medical cOmputational Suite for Advanced Intelligent eXtraction},
  author  = {Sundar, Lalith Kumar Shiyam and DIGIT-X Lab},
  year    = {2025},
  url     = {https://github.com/DIGIT-X-Lab/MOSAICX},
  doi     = {10.5281/zenodo.17601890}
}
```

## License

Apache 2.0 -- see [LICENSE](LICENSE).

## Contact

**Research:** [lalith.shiyam@med.uni-muenchen.de](mailto:lalith.shiyam@med.uni-muenchen.de) | **Commercial:** [lalith@zenta.solutions](mailto:lalith@zenta.solutions) | **Issues:** [github.com/DIGIT-X-Lab/MOSAICX/issues](https://github.com/DIGIT-X-Lab/MOSAICX/issues)
