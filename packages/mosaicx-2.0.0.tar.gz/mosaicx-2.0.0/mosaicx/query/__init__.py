"""Query engine for conversational Q&A over documents and data."""
