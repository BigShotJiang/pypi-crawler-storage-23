"""OCR engine implementations."""
