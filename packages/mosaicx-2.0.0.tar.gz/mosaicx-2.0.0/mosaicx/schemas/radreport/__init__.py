"""RadReport template models and registry."""
