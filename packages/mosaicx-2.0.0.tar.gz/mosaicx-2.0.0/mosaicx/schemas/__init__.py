"""Schema management — template compiler, ontology resolution, FHIR export."""
