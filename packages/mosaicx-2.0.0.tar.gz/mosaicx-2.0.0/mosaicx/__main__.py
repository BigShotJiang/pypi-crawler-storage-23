"""MOSAICX Module Entrypoint - ``python -m mosaicx`` Launcher."""

from mosaicx.cli import cli

if __name__ == "__main__":
    cli()
