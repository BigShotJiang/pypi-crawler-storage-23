"""Provenance tracking for MOSAICX extractions."""
