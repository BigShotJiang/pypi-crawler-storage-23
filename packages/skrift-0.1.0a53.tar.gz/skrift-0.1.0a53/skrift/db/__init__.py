from skrift.db.base import Base

__all__ = ["Base"]
