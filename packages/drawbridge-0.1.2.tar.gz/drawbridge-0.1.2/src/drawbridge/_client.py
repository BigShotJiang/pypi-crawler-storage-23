from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from typing import Any

import httpx

from drawbridge._exceptions import ResponseTooLargeError, TooManyRedirectsError
from drawbridge._policy import Policy, get_default_policy
from drawbridge._transport import SafeTransport

# Sentinel for "use the client's default timeout"
_USE_CLIENT_DEFAULT = object()


def _normalize_timeout(timeout: Any) -> dict[str, float | None]:
    """Convert a timeout value to the dict format httpx uses in request.extensions."""
    if isinstance(timeout, httpx.Timeout):
        return {
            "connect": timeout.connect,
            "read": timeout.read,
            "write": timeout.write,
            "pool": timeout.pool,
        }
    t = float(timeout)
    return {"connect": t, "read": t, "write": t, "pool": t}


class DrawbridgeResponse(httpx.Response):
    """httpx.Response with resolved_ip from SafeTransport."""

    @property
    def resolved_ip(self) -> str | None:
        return self.request.extensions.get("drawbridge_resolved_ip")


class Client:
    """SSRF-safe HTTP client. Wraps httpx.AsyncClient with SafeTransport.

    Redirects are handled manually — each hop is re-resolved and re-validated
    through SafeTransport. httpx's built-in redirect following is disabled.
    """

    def __init__(
        self,
        policy: Policy | None = None,
        /,
        *,
        base_url: str = "",
        **kwargs: Any,
    ) -> None:
        if kwargs:
            if policy is not None:
                raise TypeError(
                    "Cannot pass both a Policy and keyword arguments to Client()"
                )
            policy = Policy(**kwargs)
        self._policy = policy if policy is not None else get_default_policy()
        self._transport = SafeTransport(self._policy)
        self._httpx_client = httpx.AsyncClient(
            transport=self._transport,
            timeout=self._policy._httpx_timeout(),
            follow_redirects=False,
            headers={"user-agent": self._policy.user_agent},
            base_url=base_url,
            # Custom transport causes httpx to skip proxy loading (httpx checks
            # `transport is None` before reading HTTP_PROXY/HTTPS_PROXY). This is
            # intentional: proxy routing is architecturally incompatible with
            # client-side SSRF protection — the proxy makes the real connection,
            # not SafeTransport. For proxy environments, use a server-side solution
            # like Smokescreen where the proxy IS the enforcement point.
            trust_env=False,
        )

    async def __aenter__(self) -> Client:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._httpx_client.aclose()

    async def request(
        self,
        method: str,
        url: str,
        *,
        content: bytes | None = None,
        data: dict[str, Any] | None = None,
        files: Any = None,
        json: Any = None,
        params: Any = None,
        headers: dict[str, str] | None = None,
        cookies: Any = None,
        timeout: Any = _USE_CLIENT_DEFAULT,
    ) -> DrawbridgeResponse:
        """Send an HTTP request with full SSRF protection.

        Raises drawbridge exceptions for blocked addresses, domains, ports,
        and schemes. httpx exceptions (timeouts, connection errors) propagate
        unchanged.
        """
        request = self._httpx_client.build_request(
            method, url,
            content=content, data=data, files=files, json=json,
            params=params, headers=headers, cookies=cookies,
        )
        response = await self._follow_redirects(request, timeout=timeout)
        await _aread_bounded(response, self._policy.max_response_bytes)
        await response.aclose()
        return response

    async def get(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("POST", url, **kwargs)

    async def put(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("PUT", url, **kwargs)

    async def patch(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("PATCH", url, **kwargs)

    async def delete(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("DELETE", url, **kwargs)

    async def head(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("HEAD", url, **kwargs)

    async def options(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return await self.request("OPTIONS", url, **kwargs)

    @contextlib.asynccontextmanager
    async def stream(
        self,
        method: str,
        url: str,
        *,
        content: bytes | None = None,
        data: dict[str, Any] | None = None,
        files: Any = None,
        json: Any = None,
        params: Any = None,
        headers: dict[str, str] | None = None,
        cookies: Any = None,
        timeout: Any = _USE_CLIENT_DEFAULT,
    ) -> AsyncIterator[DrawbridgeResponse]:
        """Stream a response with SSRF protection.

        Use as an async context manager:
            async with client.stream("GET", url) as response:
                async for chunk in response.aiter_bytes():
                    ...
        """
        request = self._httpx_client.build_request(
            method, url,
            content=content, data=data, files=files, json=json,
            params=params, headers=headers, cookies=cookies,
        )
        response = await self._follow_redirects(request, timeout=timeout)
        try:
            yield response
        finally:
            await response.aclose()

    # ── Internal ──────────────────────────────────────────────

    async def _follow_redirects(
        self,
        request: httpx.Request,
        timeout: Any = _USE_CLIENT_DEFAULT,
    ) -> DrawbridgeResponse:
        """Follow redirects manually, re-validating each hop through SafeTransport.

        Returns the final httpx.Response (still streaming). Caller is responsible
        for reading the body (or iterating) and closing.
        """
        redirects_followed = 0

        while True:
            # Save original URL and headers before send — SafeTransport
            # rewrites request.url to the resolved IP and mutates headers
            # (e.g. host). Redirects must use the originals, not the
            # transport-mutated versions.
            original_url = request.url
            original_headers = dict(request.headers)

            if timeout is not _USE_CLIENT_DEFAULT:
                request.extensions["timeout"] = _normalize_timeout(timeout)
            response = await self._httpx_client.send(
                request, follow_redirects=False, stream=True,
            )

            if not response.is_redirect or self._policy.max_redirects == 0:
                # Restore hostname URL (SafeTransport rewrites to resolved IP)
                response.request.url = original_url
                response.__class__ = DrawbridgeResponse
                return response  # type: ignore[return-value]

            if redirects_followed >= self._policy.max_redirects:
                await response.aclose()
                raise TooManyRedirectsError(redirects_followed)

            # Extract redirect target. Headers are available even with stream=True.
            location = response.headers.get("location")

            if not location:
                # Malformed redirect — no Location header. Treat as final response.
                response.request.url = original_url
                response.__class__ = DrawbridgeResponse
                return response  # type: ignore[return-value]

            status_code = response.status_code
            await response.aclose()

            redirect_url = original_url.join(location)
            method, preserve_body = _redirect_method_and_body(
                request.method, status_code
            )

            # Headers: forward all on same-origin, strip sensitive on cross-origin
            cross_origin = _is_cross_origin(original_url, redirect_url)
            if cross_origin:
                redirect_headers = _strip_sensitive_headers(original_headers)
            else:
                redirect_headers = original_headers

            # Body: only preserve for same-origin 307/308
            if preserve_body and not cross_origin:
                request = self._httpx_client.build_request(
                    method,
                    str(redirect_url),
                    content=request.content,
                    headers=redirect_headers,
                )
            else:
                # Strip body-related headers (Content-Length, Content-Type)
                # since the body is dropped.
                request = self._httpx_client.build_request(
                    method,
                    str(redirect_url),
                    headers=_strip_body_headers(redirect_headers),
                )

            redirects_followed += 1


def _check_content_length(response: httpx.Response, limit: int | None) -> None:
    """Reject early if Content-Length exceeds limit (before reading body)."""
    if limit is None:
        return
    cl = response.headers.get("content-length")
    if cl is not None:
        try:
            if int(cl) > limit:
                raise ResponseTooLargeError(limit)
        except ValueError:
            pass  # Malformed Content-Length — enforce during read


async def _aread_bounded(
    response: httpx.Response, limit: int | None
) -> None:
    """Read response body with a byte cap.

    Raises ResponseTooLargeError if the body exceeds ``limit`` bytes.
    If ``limit`` is None, reads without restriction.
    """
    _check_content_length(response, limit)
    if limit is None:
        await response.aread()
        return
    chunks: list[bytes] = []
    total = 0
    async for chunk in response.aiter_bytes():
        total += len(chunk)
        if total > limit:
            await response.aclose()
            raise ResponseTooLargeError(limit)
        chunks.append(chunk)
    response._content = b"".join(chunks)


def _read_bounded(response: httpx.Response, limit: int | None) -> None:
    """Sync version of _aread_bounded."""
    _check_content_length(response, limit)
    if limit is None:
        response.read()
        return
    chunks: list[bytes] = []
    total = 0
    for chunk in response.iter_bytes():
        total += len(chunk)
        if total > limit:
            response.close()
            raise ResponseTooLargeError(limit)
        chunks.append(chunk)
    response._content = b"".join(chunks)


def _redirect_method_and_body(method: str, status_code: int) -> tuple[str, bool]:
    """Determine redirect method and whether to preserve body.

    Returns (method, preserve_body).
    - 303: always GET, drop body
    - 301/302 with non-GET/HEAD: convert to GET, drop body
    - 307/308: preserve method and body
    """
    if status_code == 303 or (
        status_code in {301, 302} and method not in {"GET", "HEAD"}
    ):
        return "GET", False
    # 307/308 or 301/302 with GET/HEAD: preserve method
    return method, status_code in {307, 308}


# Headers safe to forward on cross-origin redirects. Everything else
# (Authorization, Cookie, X-Api-Key, etc.) is stripped to prevent leakage.
_CROSS_ORIGIN_SAFE_HEADERS = frozenset({
    "accept",
    "accept-encoding",
    "accept-language",
    "cache-control",
    "user-agent",
})


def _strip_sensitive_headers(headers: dict[str, str]) -> dict[str, str]:
    """Keep only safe headers for cross-origin redirects."""
    return {
        k: v for k, v in headers.items()
        if k.lower() in _CROSS_ORIGIN_SAFE_HEADERS
    }


# Headers tied to the request body — must be stripped when body is dropped
# (e.g., POST→GET conversion on 301/302/303).
_BODY_HEADERS = frozenset({
    "content-length",
    "content-type",
    "content-encoding",
    "transfer-encoding",
})


def _strip_body_headers(headers: dict[str, str]) -> dict[str, str]:
    """Remove body-related headers when the request body is dropped."""
    return {
        k: v for k, v in headers.items()
        if k.lower() not in _BODY_HEADERS
    }


def _effective_port(url: httpx.URL) -> int:
    """Return the effective port, defaulting to 80/443 for http/https."""
    if url.port is not None:
        return url.port
    return 443 if url.scheme == "https" else 80


def _is_cross_origin(source: httpx.URL, target: httpx.URL) -> bool:
    """Check if redirect crosses origin (scheme + host + port).

    Normalizes default ports so that http://x and http://x:80
    are considered same-origin.
    """
    return (
        source.scheme != target.scheme
        or source.host != target.host
        or _effective_port(source) != _effective_port(target)
    )
