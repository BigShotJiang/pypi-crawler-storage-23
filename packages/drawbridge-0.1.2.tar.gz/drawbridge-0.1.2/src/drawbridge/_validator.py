from __future__ import annotations

import asyncio
import ipaddress
import socket
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from drawbridge._policy import Policy

from drawbridge._exceptions import (
    BlockedAddressError,
    BlockedDomainError,
    DrawbridgeDNSError,
    UnsafePortError,
)

# Comprehensive denylist: union of Sentry, Discourse, and Advocate.
# See research.md Part 3 for per-range rationale.
PRIVATE_IP_RANGES: frozenset[ipaddress.IPv4Network | ipaddress.IPv6Network] = frozenset(
    {
        # IPv4
        ipaddress.IPv4Network("0.0.0.0/8"),
        ipaddress.IPv4Network("10.0.0.0/8"),
        ipaddress.IPv4Network("100.64.0.0/10"),
        ipaddress.IPv4Network("127.0.0.0/8"),
        ipaddress.IPv4Network("169.254.0.0/16"),
        ipaddress.IPv4Network("172.16.0.0/12"),
        ipaddress.IPv4Network("192.0.0.0/24"),
        ipaddress.IPv4Network("192.0.2.0/24"),
        ipaddress.IPv4Network("192.168.0.0/16"),
        ipaddress.IPv4Network("192.175.48.0/24"),
        ipaddress.IPv4Network("198.18.0.0/15"),
        ipaddress.IPv4Network("198.51.100.0/24"),
        ipaddress.IPv4Network("203.0.113.0/24"),
        ipaddress.IPv4Network("224.0.0.0/4"),  # Multicast
        ipaddress.IPv4Network("240.0.0.0/4"),
        ipaddress.IPv4Network("255.255.255.255/32"),
        # IPv6
        ipaddress.IPv6Network("::1/128"),
        ipaddress.IPv6Network("::/128"),
        ipaddress.IPv6Network("64:ff9b::/96"),
        ipaddress.IPv6Network("64:ff9b:1::/48"),
        ipaddress.IPv6Network("100::/64"),
        ipaddress.IPv6Network("2001::/23"),  # IETF protocol assignments (includes Teredo 2001:0000::/32)
        ipaddress.IPv6Network("2001:2::/48"),  # Benchmarking
        ipaddress.IPv6Network("2001:db8::/32"),  # Documentation
        ipaddress.IPv6Network("2002::/16"),  # 6to4 — can embed arbitrary IPv4 addresses
        ipaddress.IPv6Network("fc00::/7"),
        ipaddress.IPv6Network("fe80::/10"),
        ipaddress.IPv6Network("ff00::/8"),  # Multicast
    }
)


def _normalize_ip(
    ip: ipaddress.IPv4Address | ipaddress.IPv6Address,
) -> ipaddress.IPv4Address | ipaddress.IPv6Address:
    """Unpack IPv4-mapped IPv6 addresses so they're checked against IPv4 rules."""
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        return ip.ipv4_mapped
    return ip


def check_ip(
    hostname: str,
    ip: ipaddress.IPv4Address | ipaddress.IPv6Address,
    policy: Policy,
) -> None:
    """Validate a single resolved IP against the policy.

    Raises BlockedAddressError if the IP is not allowed.
    """
    ip = _normalize_ip(ip)

    # Allowlist takes precedence — lets users punch holes for specific infra
    if any(ip in net for net in policy.ip_allowlist):
        return

    # Custom blocklist
    if any(ip in net for net in policy.ip_blocklist):
        raise BlockedAddressError(hostname, ip, "in custom blocklist")

    # Private range check (unless allow_private=True)
    if not policy.allow_private:
        for net in PRIVATE_IP_RANGES:
            if ip in net:
                raise BlockedAddressError(hostname, ip, f"private IP ({net})")


def check_domain(hostname: str, policy: Policy) -> None:
    """Validate hostname against allow_domains / block_domains.

    Raises BlockedDomainError if the domain is not permitted.
    """
    normalized = _normalize_domain(hostname)

    # If allow_domains is set, hostname must match at least one entry
    if policy.allow_domains is not None:
        if not any(
            _domain_matches(normalized, pattern) for pattern in policy.allow_domains
        ):
            raise BlockedDomainError(hostname, "not in allow_domains")

    # block_domains always applies
    if any(_domain_matches(normalized, pattern) for pattern in policy.block_domains):
        raise BlockedDomainError(hostname, "matched block_domains")


def _normalize_domain(name: str) -> str:
    """Normalize a domain to lowercase ASCII (punycode) form.

    Ensures that IDN domains match regardless of whether the user
    provides Unicode ("éxample.com") or punycode ("xn--xample-9ua.com").
    Falls back to raw lowercase if IDNA encoding fails.
    """
    name = name.lower().rstrip(".")
    try:
        return name.encode("idna").decode("ascii")
    except (UnicodeError, UnicodeDecodeError):
        return name


def _domain_matches(hostname: str, pattern: str) -> bool:
    """Single-level wildcard matching (Smokescreen approach).

    *.example.com matches foo.example.com but NOT bar.foo.example.com.
    example.com matches only example.com exactly.

    Both hostname and pattern are normalized to ASCII (punycode) form
    so that IDN domains match regardless of representation.
    """
    hostname = _normalize_domain(hostname)
    pattern = pattern.lower().rstrip(".")

    if pattern.startswith("*."):
        # *.example.com → match if hostname is <one-label>.example.com
        suffix = _normalize_domain(pattern[2:])
        if hostname == suffix:
            return True
        # hostname must be exactly one label + suffix
        if hostname.endswith("." + suffix):
            prefix = hostname[: -(len(suffix) + 1)]
            return "." not in prefix
        return False

    return hostname == _normalize_domain(pattern)


def check_port(port: int, policy: Policy) -> None:
    """Validate destination port against allow_ports.

    Raises UnsafePortError if the port is not in the allowlist.
    """
    if port not in policy.allow_ports:
        raise UnsafePortError(port, policy.allow_ports)


async def resolve_and_validate(
    hostname: str,
    port: int,
    policy: Policy,
) -> str:
    """Resolve DNS, validate ALL IPs, return first valid IP.

    This is the core SSRF protection: single DNS resolution used for both
    validation and connection. Prevents DNS rebinding by construction.

    Uses aggressive multi-record rejection: if ANY resolved IP is blocked,
    the entire request is rejected (Sentry's approach).

    Raises BlockedAddressError if any resolved IP is in a blocked range.
    """
    check_port(port, policy)
    check_domain(hostname, policy)

    # If hostname is already an IP literal, validate it directly
    try:
        ip = ipaddress.ip_address(hostname)
        check_ip(hostname, ip, policy)
        return str(ip)
    except ValueError:
        pass

    # DNS resolution — the single call that prevents rebinding
    try:
        addrinfo = await _async_getaddrinfo(hostname, port)
    except socket.gaierror as exc:
        raise DrawbridgeDNSError(hostname, exc) from exc

    if not addrinfo:
        raise DrawbridgeDNSError(hostname, None)

    # Validate ALL resolved IPs (aggressive approach)
    for family, _type, _proto, _canonname, sockaddr in addrinfo:
        ip = ipaddress.ip_address(sockaddr[0])
        check_ip(hostname, ip, policy)

    # Return first IP for connection pinning
    return addrinfo[0][4][0]


# DNS resolution timeout — prevents attacker-chosen slow hostnames from
# tying up executor threads indefinitely.
_DNS_TIMEOUT_SECONDS = 5.0

# Bounded thread pool for DNS resolution. Limits concurrent getaddrinfo
# threads to prevent exhaustion from many slow/attacker-controlled hostnames.
# asyncio.wait_for() only cancels the await — the blocking thread keeps running.
# A bounded pool ensures at most N threads are consumed at any time.
_DNS_EXECUTOR = ThreadPoolExecutor(max_workers=8, thread_name_prefix="drawbridge-dns")


async def _async_getaddrinfo(
    hostname: str, port: int
) -> list[
    tuple[
        socket.AddressFamily,
        socket.SocketKind,
        int,
        str,
        tuple[str, int] | tuple[str, int, int, int],
    ]
]:
    """Async wrapper around socket.getaddrinfo with a timeout."""
    loop = asyncio.get_running_loop()
    try:
        return await asyncio.wait_for(
            loop.run_in_executor(
                _DNS_EXECUTOR,
                socket.getaddrinfo,
                hostname,
                port,
                socket.AF_UNSPEC,
                socket.SOCK_STREAM,
            ),
            timeout=_DNS_TIMEOUT_SECONDS,
        )
    except TimeoutError:
        raise DrawbridgeDNSError(hostname, None) from None


def resolve_and_validate_sync(
    hostname: str,
    port: int,
    policy: Policy,
) -> str:
    """Synchronous version of resolve_and_validate.

    Same SSRF protection: resolves DNS, validates ALL IPs, returns first valid IP.
    Uses the shared thread pool with a timeout to prevent slow DNS from blocking.

    Raises BlockedAddressError, BlockedDomainError, UnsafePortError, DrawbridgeDNSError.
    """
    check_port(port, policy)
    check_domain(hostname, policy)

    # If hostname is already an IP literal, validate it directly
    try:
        ip = ipaddress.ip_address(hostname)
        check_ip(hostname, ip, policy)
        return str(ip)
    except ValueError:
        pass

    # DNS resolution with timeout via thread pool
    try:
        addrinfo = _sync_getaddrinfo(hostname, port)
    except socket.gaierror as exc:
        raise DrawbridgeDNSError(hostname, exc) from exc

    if not addrinfo:
        raise DrawbridgeDNSError(hostname, None)

    # Validate ALL resolved IPs (aggressive approach)
    for family, _type, _proto, _canonname, sockaddr in addrinfo:
        ip = ipaddress.ip_address(sockaddr[0])
        check_ip(hostname, ip, policy)

    # Return first IP for connection pinning
    return addrinfo[0][4][0]


def _sync_getaddrinfo(
    hostname: str, port: int
) -> list[
    tuple[
        socket.AddressFamily,
        socket.SocketKind,
        int,
        str,
        tuple[str, int] | tuple[str, int, int, int],
    ]
]:
    """Blocking getaddrinfo with a timeout via the shared DNS thread pool."""
    future = _DNS_EXECUTOR.submit(
        socket.getaddrinfo, hostname, port, socket.AF_UNSPEC, socket.SOCK_STREAM,
    )
    try:
        return future.result(timeout=_DNS_TIMEOUT_SECONDS)
    except TimeoutError:
        future.cancel()
        raise DrawbridgeDNSError(hostname, None) from None


