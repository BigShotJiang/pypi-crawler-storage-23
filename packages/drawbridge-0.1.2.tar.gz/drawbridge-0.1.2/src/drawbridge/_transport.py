from __future__ import annotations

import httpx

from drawbridge._exceptions import UnsafeSchemeError
from drawbridge._policy import Policy
from drawbridge._validator import resolve_and_validate, resolve_and_validate_sync

_ALLOWED_SCHEMES = frozenset({b"http", b"https"})


def _build_host_header(hostname: str, url: httpx.URL) -> str:
    """Build Host header, including port only for non-default ports.

    IPv6 literals are wrapped in brackets per RFC 2732.
    IDN hostnames are kept as-is (httpx sends them decoded).
    """
    if ":" in hostname:
        hostname = f"[{hostname}]"
    port = url.port
    if port is None:
        return hostname
    scheme = url.scheme
    if (scheme == "http" and port == 80) or (scheme == "https" and port == 443):
        return hostname
    return f"{hostname}:{port}"


def _get_effective_port(url: httpx.URL) -> int:
    if url.port is not None:
        return url.port
    return 443 if url.scheme == "https" else 80


def _prepare_request(
    request: httpx.Request,
    validated_ip: str,
    hostname: str,
) -> None:
    """Rewrite request URL to validated IP and set Host/SNI headers.

    Shared by both async and sync transports.
    """
    request.url = request.url.copy_with(host=validated_ip)
    request.headers["host"] = _build_host_header(hostname, request.url)

    if request.url.scheme == "https":
        try:
            request.extensions["sni_hostname"] = hostname.encode("idna")
        except UnicodeError:
            # Labels >63 chars or invalid IDNA characters — fall back to
            # ASCII encoding. The TLS handshake will likely fail with a
            # certificate mismatch, which is safe (no SSRF bypass).
            request.extensions["sni_hostname"] = hostname.encode("ascii", errors="replace")

    request.extensions["drawbridge_resolved_ip"] = validated_ip


class SafeTransport(httpx.AsyncBaseTransport):
    """httpx async transport that prevents SSRF via DNS-pinning.

    For every request:
    1. Resolves DNS (single getaddrinfo call)
    2. Validates all resolved IPs against the policy
    3. Rewrites the URL to connect to the validated IP
    4. Sets Host header and SNI to the original hostname

    The IP that was validated is the IP that gets connected to.
    This eliminates DNS rebinding by construction.
    """

    def __init__(self, policy: Policy) -> None:
        self._policy = policy
        # Disable keepalive to prevent TLS connection reuse across hostnames.
        # URL rewriting (hostname→IP) causes httpcore to key connections on IP:port,
        # allowing connections for hostname-A to be reused for hostname-B when
        # both resolve to the same IP — skipping SNI/certificate validation.
        self._inner = httpx.AsyncHTTPTransport(
            verify=policy.verify_ssl,
            limits=httpx.Limits(max_keepalive_connections=0),
        )

    async def handle_async_request(
        self,
        request: httpx.Request,
    ) -> httpx.Response:
        if request.url.raw_scheme not in _ALLOWED_SCHEMES:
            raise UnsafeSchemeError(request.url.scheme)

        hostname = request.url.host
        port = _get_effective_port(request.url)

        validated_ip = await resolve_and_validate(hostname, port, self._policy)
        _prepare_request(request, validated_ip, hostname)

        return await self._inner.handle_async_request(request)

    async def aclose(self) -> None:
        await self._inner.aclose()


class SyncSafeTransport(httpx.BaseTransport):
    """httpx sync transport that prevents SSRF via DNS-pinning.

    Synchronous equivalent of SafeTransport. Same validation logic,
    uses blocking DNS resolution with timeout.
    """

    def __init__(self, policy: Policy) -> None:
        self._policy = policy
        self._inner = httpx.HTTPTransport(
            verify=policy.verify_ssl,
            limits=httpx.Limits(max_keepalive_connections=0),
        )

    def handle_request(
        self,
        request: httpx.Request,
    ) -> httpx.Response:
        if request.url.raw_scheme not in _ALLOWED_SCHEMES:
            raise UnsafeSchemeError(request.url.scheme)

        hostname = request.url.host
        port = _get_effective_port(request.url)

        validated_ip = resolve_and_validate_sync(hostname, port, self._policy)
        _prepare_request(request, validated_ip, hostname)

        return self._inner.handle_request(request)

    def close(self) -> None:
        self._inner.close()
