from __future__ import annotations

import dataclasses
import ipaddress
from collections.abc import Iterable
from typing import Any

import httpx

_DEFAULT_USER_AGENT = "drawbridge/0.1.0"  # TODO: derive from __version__ after 1.0


@dataclasses.dataclass(frozen=True)
class Policy:
    """Configuration for drawbridge's SSRF protection and response validation.

    Every field has a safe default. Construct with no arguments for maximum safety.

    Accepts plain lists, sets, or tuples for collection fields — they are
    coerced to frozensets internally.
    """

    # ── Where can I connect? ──────────────────────────────────

    allow_private: bool = False
    """Allow connections to private/reserved IP ranges. Default: False (safe)."""

    allow_domains: frozenset[str] | None = None
    """If set, ONLY these domains are permitted. Supports single-level wildcards:
    ["*.example.com", "api.stripe.com"].
    None = any public domain allowed."""

    block_domains: frozenset[str] = dataclasses.field(default_factory=frozenset)
    """Always block these domains. Supports wildcards. Applied after allow_domains."""

    allow_ports: frozenset[int] = frozenset({80, 443, 8080, 8443})
    """Only these destination ports are allowed."""

    ip_allowlist: frozenset[ipaddress.IPv4Network | ipaddress.IPv6Network] = (
        dataclasses.field(default_factory=frozenset)
    )
    """Specific IP ranges to allow even when allow_private=False."""

    ip_blocklist: frozenset[ipaddress.IPv4Network | ipaddress.IPv6Network] = (
        dataclasses.field(default_factory=frozenset)
    )
    """Additional IP ranges to block beyond the default private ranges."""

    # ── How should I connect? ─────────────────────────────────

    timeout: float | httpx.Timeout = 10.0
    """Total timeout in seconds (float), or fine-grained httpx.Timeout."""

    max_redirects: int = 5
    """Maximum redirect hops. Each hop is re-validated through SafeTransport.
    0 = no redirects followed."""

    user_agent: str = _DEFAULT_USER_AGENT
    """User-Agent header. Some servers block requests without one."""

    max_response_bytes: int | None = 1024 * 1024  # 1 MB
    """Maximum response body size in bytes. None = no limit.
    Checked against Content-Length header (when present) before reading,
    and enforced during body consumption. Default: 1 MB."""

    verify_ssl: bool = True
    """Verify TLS certificates. Default: True (safe)."""

    def __post_init__(self) -> None:
        _coerce_frozenset(self, "allow_domains", optional=True)
        _coerce_frozenset(self, "block_domains")
        _coerce_frozenset(self, "allow_ports")
        _coerce_frozenset(self, "ip_allowlist")
        _coerce_frozenset(self, "ip_blocklist")

    def _httpx_timeout(self) -> httpx.Timeout:
        if isinstance(self.timeout, httpx.Timeout):
            return self.timeout
        return httpx.Timeout(self.timeout)


_default_policy: Policy | None = None

# Policy field names, used by convenience functions to split mixed kwargs
_POLICY_FIELD_NAMES: frozenset[str] = frozenset(
    f.name for f in dataclasses.fields(Policy)
)


def _policy_from_kwargs(kwargs: dict[str, Any]) -> Policy:
    """Build a Policy by merging kwargs over the current global default.

    This way ``drawbridge.get(url, max_redirects=0)`` overrides just
    ``max_redirects`` while keeping the rest of the configured policy.
    """
    base = get_default_policy()
    merged = {f.name: getattr(base, f.name) for f in dataclasses.fields(base)}
    merged.update(kwargs)
    return Policy(**merged)


_REQUEST_KWARG_NAMES: frozenset[str] = frozenset({
    "content", "data", "files", "json", "params", "headers", "cookies", "timeout",
})


def _split_kwargs(
    kwargs: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Split mixed kwargs into (policy_kwargs, request_kwargs).

    ``timeout`` is treated as a request kwarg since it's the common per-request
    use case.  Users who need a policy-level timeout can pass ``policy=Policy(timeout=...)``.

    Raises TypeError for unknown kwargs to catch typos like ``allow_domain``
    (missing 's').
    """
    policy_kw: dict[str, Any] = {}
    request_kw: dict[str, Any] = {}
    for k, v in kwargs.items():
        if k in _REQUEST_KWARG_NAMES:
            request_kw[k] = v
        elif k in _POLICY_FIELD_NAMES:
            policy_kw[k] = v
        else:
            raise TypeError(
                f"Unknown keyword argument: {k!r}. "
                f"Policy fields: {sorted(_POLICY_FIELD_NAMES)}. "
                f"Request fields: {sorted(_REQUEST_KWARG_NAMES)}."
            )
    return policy_kw, request_kw


def configure(policy: Policy | None = None, /, **kwargs: Any) -> None:
    """Set the global default policy, or reset to safe defaults.

    Accepts either a Policy object or policy keyword arguments:

        drawbridge.configure(block_domains=["metadata.google.internal"])
        drawbridge.configure(None)  # reset

    Raises TypeError if both a Policy and keyword arguments are provided.
    """
    if kwargs:
        if policy is not None:
            raise TypeError(
                "Cannot pass both a Policy and keyword arguments to configure()"
            )
        policy = Policy(**kwargs)
    global _default_policy
    _default_policy = policy


def get_default_policy() -> Policy:
    """Return the global default policy, or Policy() if none configured."""
    return _default_policy if _default_policy is not None else Policy()


def _coerce_frozenset(obj: Any, field: str, *, optional: bool = False) -> None:
    """Coerce a field value to frozenset if it's any other collection.

    Rejects bare strings (iterating "evil.com" gives individual characters),
    bare bytes, and non-collection iterables like IPv4Network (which iterates
    into individual host addresses, silently creating a broken config).
    """
    value = getattr(obj, field)
    if value is None and optional:
        return
    if not isinstance(value, (frozenset, set, list, tuple)):
        raise TypeError(
            f"Policy.{field} must be a list, set, or frozenset, not {type(value).__name__}. "
            f"Use [{value!r}] to wrap a single value."
        )
    if not isinstance(value, frozenset):
        object.__setattr__(obj, field, frozenset(value))
