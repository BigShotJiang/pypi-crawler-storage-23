"""Drawbridge exceptions."""

from __future__ import annotations

import ipaddress


class DrawbridgeError(Exception):
    """Base exception for all drawbridge errors."""


# ── Network validation errors ────────────────────────────────


class BlockedAddressError(DrawbridgeError):
    """Resolved IP is in a blocked range (private, loopback, etc.)."""

    def __init__(
        self,
        hostname: str,
        ip: ipaddress.IPv4Address | ipaddress.IPv6Address,
        reason: str,
    ) -> None:
        self.hostname = hostname
        self.ip = ip
        self.reason = reason
        super().__init__(f"{hostname} blocked: {ip} is {reason}")


class BlockedDomainError(DrawbridgeError):
    """Domain not permitted by allow_domains / block_domains policy."""

    def __init__(self, hostname: str, reason: str) -> None:
        self.hostname = hostname
        self.reason = reason
        super().__init__(f"Domain blocked: {hostname} ({reason})")


class UnsafePortError(DrawbridgeError):
    """Port not in allow_ports."""

    def __init__(self, port: int, allowed: frozenset[int]) -> None:
        self.port = port
        self.allowed = allowed
        super().__init__(f"Port not allowed: {port}")


class UnsafeSchemeError(DrawbridgeError):
    """URL scheme is not http or https."""

    def __init__(self, scheme: str) -> None:
        self.scheme = scheme
        super().__init__(f"Scheme not allowed: {scheme}")


class DrawbridgeDNSError(DrawbridgeError):
    """DNS resolution failed."""

    def __init__(self, hostname: str, cause: Exception | None) -> None:
        self.hostname = hostname
        msg = f"DNS resolution failed: {hostname}"
        if cause is not None:
            msg += f" ({cause})"
        super().__init__(msg)


# ── Response errors ──────────────────────────────────────────


class TooManyRedirectsError(DrawbridgeError):
    """Exceeded max_redirects."""

    def __init__(self, count: int) -> None:
        self.count = count
        super().__init__(f"Too many redirects: {count}")


class ResponseTooLargeError(DrawbridgeError):
    """Response body exceeds max_response_bytes."""

    def __init__(self, limit: int) -> None:
        self.limit = limit
        super().__init__(f"Response body exceeds {limit} bytes")
