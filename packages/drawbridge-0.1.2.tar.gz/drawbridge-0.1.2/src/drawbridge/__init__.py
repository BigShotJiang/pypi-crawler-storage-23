"""Drawbridge — SSRF-safe HTTP client for Python.

Opinionated httpx wrapper that blocks private IPs, prevents DNS rebinding,
and validates redirects.

    import drawbridge

    response = await drawbridge.get("https://example.com/api/data")
    print(response.json())
"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from typing import Any

from drawbridge._client import Client, DrawbridgeResponse
from drawbridge._sync_client import SyncClient
from drawbridge._exceptions import (
    BlockedAddressError,
    BlockedDomainError,
    DrawbridgeDNSError,
    DrawbridgeError,
    ResponseTooLargeError,
    TooManyRedirectsError,
    UnsafePortError,
    UnsafeSchemeError,
)
from drawbridge._policy import Policy, _policy_from_kwargs, _split_kwargs, configure

__version__ = "0.1.0"

__all__ = [
    # Core
    "Client",
    "SyncClient",
    "Policy",
    "DrawbridgeResponse",
    "configure",
    # Exceptions
    "DrawbridgeError",
    "BlockedAddressError",
    "BlockedDomainError",
    "UnsafePortError",
    "TooManyRedirectsError",
    "ResponseTooLargeError",
    "DrawbridgeDNSError",
    "UnsafeSchemeError",
    # Convenience functions
    "get",
    "post",
    "put",
    "patch",
    "delete",
    "head",
    "options",
    "request",
    "stream",
]


async def request(
    method: str,
    url: str,
    *,
    policy: Policy | None = None,
    **kwargs: Any,
) -> DrawbridgeResponse:
    """Send an HTTP request with SSRF protection.

    Accepts policy keyword arguments (``max_redirects``, ``allow_domains``, etc.)
    mixed with request arguments (``headers``, ``json``, ``timeout``, etc.):

        await drawbridge.post(url, json=event, max_redirects=0)

    Creates a temporary Client for the request. For connection reuse,
    use Client directly as an async context manager.
    """
    policy_kw, request_kw = _split_kwargs(kwargs)
    if policy_kw:
        if policy is not None:
            raise TypeError(
                "Cannot pass both 'policy' and policy keyword arguments"
            )
        policy = _policy_from_kwargs(policy_kw)
    async with Client(policy) as client:
        return await client.request(method, url, **request_kw)


@contextlib.asynccontextmanager
async def stream(
    method: str,
    url: str,
    *,
    policy: Policy | None = None,
    **kwargs: Any,
) -> AsyncIterator[DrawbridgeResponse]:
    """Stream a response with SSRF protection.

        async with drawbridge.stream("GET", url) as response:
            async for chunk in response.aiter_bytes():
                process(chunk)

    Creates a temporary Client. For connection reuse, use Client directly.
    """
    policy_kw, request_kw = _split_kwargs(kwargs)
    if policy_kw:
        if policy is not None:
            raise TypeError(
                "Cannot pass both 'policy' and policy keyword arguments"
            )
        policy = _policy_from_kwargs(policy_kw)
    async with Client(policy) as client:
        async with client.stream(method, url, **request_kw) as response:
            yield response


async def get(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("GET", url, policy=policy, **kwargs)


async def post(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("POST", url, policy=policy, **kwargs)


async def put(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("PUT", url, policy=policy, **kwargs)


async def patch(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("PATCH", url, policy=policy, **kwargs)


async def delete(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("DELETE", url, policy=policy, **kwargs)


async def head(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("HEAD", url, policy=policy, **kwargs)


async def options(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return await request("OPTIONS", url, policy=policy, **kwargs)
