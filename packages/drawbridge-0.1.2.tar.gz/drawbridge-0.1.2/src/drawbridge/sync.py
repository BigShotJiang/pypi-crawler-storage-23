"""Synchronous convenience functions for drawbridge.

    import drawbridge.sync

    response = drawbridge.sync.get("https://example.com/api/data")
    print(response.json())

For connection reuse, use SyncClient directly as a context manager:

    from drawbridge import SyncClient

    with SyncClient() as client:
        r1 = client.get("https://example.com/users")
        r2 = client.get("https://example.com/posts")
"""

from __future__ import annotations

import contextlib
from collections.abc import Iterator
from typing import Any

from drawbridge._client import DrawbridgeResponse
from drawbridge._policy import Policy, _policy_from_kwargs, _split_kwargs
from drawbridge._sync_client import SyncClient

__all__ = [
    "request",
    "get",
    "post",
    "put",
    "patch",
    "delete",
    "head",
    "options",
    "stream",
]


def request(
    method: str,
    url: str,
    *,
    policy: Policy | None = None,
    **kwargs: Any,
) -> DrawbridgeResponse:
    """Send an HTTP request with SSRF protection.

    Accepts policy keyword arguments (``max_redirects``, ``allow_domains``, etc.)
    mixed with request arguments (``headers``, ``json``, ``timeout``, etc.):

        drawbridge.sync.post(url, json=event, max_redirects=0)

    Creates a temporary SyncClient for the request. For connection reuse,
    use SyncClient directly as a context manager.
    """
    policy_kw, request_kw = _split_kwargs(kwargs)
    if policy_kw:
        if policy is not None:
            raise TypeError(
                "Cannot pass both 'policy' and policy keyword arguments"
            )
        policy = _policy_from_kwargs(policy_kw)
    with SyncClient(policy) as client:
        return client.request(method, url, **request_kw)


@contextlib.contextmanager
def stream(
    method: str,
    url: str,
    *,
    policy: Policy | None = None,
    **kwargs: Any,
) -> Iterator[DrawbridgeResponse]:
    """Stream a response with SSRF protection.

        with drawbridge.sync.stream("GET", url) as response:
            for chunk in response.iter_bytes():
                process(chunk)

    Creates a temporary SyncClient. For connection reuse, use SyncClient directly.
    """
    policy_kw, request_kw = _split_kwargs(kwargs)
    if policy_kw:
        if policy is not None:
            raise TypeError(
                "Cannot pass both 'policy' and policy keyword arguments"
            )
        policy = _policy_from_kwargs(policy_kw)
    with SyncClient(policy) as client:
        with client.stream(method, url, **request_kw) as response:
            yield response


def get(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("GET", url, policy=policy, **kwargs)


def post(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("POST", url, policy=policy, **kwargs)


def put(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("PUT", url, policy=policy, **kwargs)


def patch(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("PATCH", url, policy=policy, **kwargs)


def delete(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("DELETE", url, policy=policy, **kwargs)


def head(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("HEAD", url, policy=policy, **kwargs)


def options(url: str, *, policy: Policy | None = None, **kwargs: Any) -> DrawbridgeResponse:
    return request("OPTIONS", url, policy=policy, **kwargs)
