from __future__ import annotations

import contextlib
from collections.abc import Iterator
from typing import Any

import httpx

from drawbridge._client import (
    DrawbridgeResponse,
    _USE_CLIENT_DEFAULT,
    _is_cross_origin,
    _normalize_timeout,
    _read_bounded,
    _redirect_method_and_body,
    _strip_body_headers,
    _strip_sensitive_headers,
)
from drawbridge._exceptions import TooManyRedirectsError
from drawbridge._policy import Policy, get_default_policy
from drawbridge._transport import SyncSafeTransport


class SyncClient:
    """SSRF-safe synchronous HTTP client. Wraps httpx.Client with SyncSafeTransport.

    Redirects are handled manually — each hop is re-resolved and re-validated
    through SyncSafeTransport. httpx's built-in redirect following is disabled.
    """

    def __init__(
        self,
        policy: Policy | None = None,
        /,
        *,
        base_url: str = "",
        **kwargs: Any,
    ) -> None:
        if kwargs:
            if policy is not None:
                raise TypeError(
                    "Cannot pass both a Policy and keyword arguments to SyncClient()"
                )
            policy = Policy(**kwargs)
        self._policy = policy if policy is not None else get_default_policy()
        self._transport = SyncSafeTransport(self._policy)
        self._httpx_client = httpx.Client(
            transport=self._transport,
            timeout=self._policy._httpx_timeout(),
            follow_redirects=False,
            headers={"user-agent": self._policy.user_agent},
            base_url=base_url,
            trust_env=False,
        )

    def __enter__(self) -> SyncClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        self._httpx_client.close()

    def request(
        self,
        method: str,
        url: str,
        *,
        content: bytes | None = None,
        data: dict[str, Any] | None = None,
        files: Any = None,
        json: Any = None,
        params: Any = None,
        headers: dict[str, str] | None = None,
        cookies: Any = None,
        timeout: Any = _USE_CLIENT_DEFAULT,
    ) -> DrawbridgeResponse:
        """Send an HTTP request with full SSRF protection.

        Raises drawbridge exceptions for blocked addresses, domains, ports,
        and schemes. httpx exceptions (timeouts, connection errors) propagate
        unchanged.
        """
        request = self._httpx_client.build_request(
            method, url,
            content=content, data=data, files=files, json=json,
            params=params, headers=headers, cookies=cookies,
        )
        response = self._follow_redirects(request, timeout=timeout)
        _read_bounded(response, self._policy.max_response_bytes)
        response.close()
        return response

    def get(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("PUT", url, **kwargs)

    def patch(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("PATCH", url, **kwargs)

    def delete(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("DELETE", url, **kwargs)

    def head(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("HEAD", url, **kwargs)

    def options(self, url: str, **kwargs: Any) -> DrawbridgeResponse:
        return self.request("OPTIONS", url, **kwargs)

    @contextlib.contextmanager
    def stream(
        self,
        method: str,
        url: str,
        *,
        content: bytes | None = None,
        data: dict[str, Any] | None = None,
        files: Any = None,
        json: Any = None,
        params: Any = None,
        headers: dict[str, str] | None = None,
        cookies: Any = None,
        timeout: Any = _USE_CLIENT_DEFAULT,
    ) -> Iterator[DrawbridgeResponse]:
        """Stream a response with SSRF protection.

        Use as a context manager:
            with client.stream("GET", url) as response:
                for chunk in response.iter_bytes():
                    ...
        """
        request = self._httpx_client.build_request(
            method, url,
            content=content, data=data, files=files, json=json,
            params=params, headers=headers, cookies=cookies,
        )
        response = self._follow_redirects(request, timeout=timeout)
        try:
            yield response
        finally:
            response.close()

    # ── Internal ──────────────────────────────────────────────

    def _follow_redirects(
        self,
        request: httpx.Request,
        timeout: Any = _USE_CLIENT_DEFAULT,
    ) -> DrawbridgeResponse:
        """Follow redirects manually, re-validating each hop through SyncSafeTransport."""
        redirects_followed = 0

        while True:
            original_url = request.url
            original_headers = dict(request.headers)

            if timeout is not _USE_CLIENT_DEFAULT:
                request.extensions["timeout"] = _normalize_timeout(timeout)
            response = self._httpx_client.send(
                request, follow_redirects=False, stream=True,
            )

            if not response.is_redirect or self._policy.max_redirects == 0:
                response.request.url = original_url
                response.__class__ = DrawbridgeResponse
                return response  # type: ignore[return-value]

            if redirects_followed >= self._policy.max_redirects:
                response.close()
                raise TooManyRedirectsError(redirects_followed)

            location = response.headers.get("location")

            if not location:
                response.request.url = original_url
                response.__class__ = DrawbridgeResponse
                return response  # type: ignore[return-value]

            status_code = response.status_code
            response.close()

            redirect_url = original_url.join(location)
            method, preserve_body = _redirect_method_and_body(
                request.method, status_code
            )

            cross_origin = _is_cross_origin(original_url, redirect_url)
            if cross_origin:
                redirect_headers = _strip_sensitive_headers(original_headers)
            else:
                redirect_headers = original_headers

            if preserve_body and not cross_origin:
                request = self._httpx_client.build_request(
                    method,
                    str(redirect_url),
                    content=request.content,
                    headers=redirect_headers,
                )
            else:
                request = self._httpx_client.build_request(
                    method,
                    str(redirect_url),
                    headers=_strip_body_headers(redirect_headers),
                )

            redirects_followed += 1
