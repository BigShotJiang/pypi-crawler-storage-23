from __future__ import annotations

from pathlib import Path
from typing import TypedDict

import yaml

CURATED_DIR = Path(__file__).resolve().parent / "curated"


class CuratedInfo(TypedDict):
    description: str
    humor: str
    when_to_use: str
    lines: dict[str, str]
    tips: str
    tags: list[str]


_cache: dict[str, CuratedInfo] | None = None


def _load_all() -> dict[str, CuratedInfo]:
    global _cache
    if _cache is not None:
        return _cache

    curated: dict[str, CuratedInfo] = {}
    if not CURATED_DIR.exists():
        _cache = curated
        return curated

    for path in sorted(CURATED_DIR.glob("*.yml")):
        meme_id = path.stem
        with open(path) as f:
            data = yaml.safe_load(f)
        if data:
            curated[meme_id] = data

    _cache = curated
    return curated


def get_curated(meme_id: str) -> CuratedInfo | None:
    return _load_all().get(meme_id)


def get_all_curated() -> dict[str, CuratedInfo]:
    return _load_all()
