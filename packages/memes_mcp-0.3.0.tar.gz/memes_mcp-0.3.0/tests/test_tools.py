from memes_mcp.tools import gen_meme, get_meme, list_memes


def test_list_memes_all():
    results = list_memes()
    assert len(results) > 100
    ids = [r["id"] for r in results]
    assert "drake" in ids
    assert "fry" in ids


def test_list_memes_query():
    results = list_memes(query="drake")
    assert len(results) >= 1
    assert results[0]["id"] == "drake"


def test_list_memes_curated_tag_search():
    results = list_memes(query="facepalm")
    ids = [r["id"] for r in results]
    assert "facepalm" in ids


def test_get_meme_curated():
    result = get_meme("drake")
    assert result["id"] == "drake"
    assert "description" in result
    assert "humor" in result
    assert "when_to_use" in result
    assert "line_descriptions" in result
    assert "tips" in result


def test_get_meme_uncurated():
    result = get_meme("ackbar")
    assert result["id"] == "ackbar"
    assert "description" in result
    assert "line_descriptions" in result


def test_get_meme_not_found():
    result = get_meme("nonexistent_xyz")
    assert "error" in result


def test_gen_meme_numbered_keys():
    img = gen_meme("drake", text={"1": "tests", "2": "memes"})
    assert isinstance(img, bytes)
    assert len(img) > 1000


def test_gen_meme_top_bottom_keys():
    img = gen_meme("fry", text={"top": "not sure if", "bottom": "or just"})
    assert isinstance(img, bytes)
    assert len(img) > 1000
