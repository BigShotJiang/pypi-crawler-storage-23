from memes_mcp.curated import get_all_curated
from memes_mcp.templates import get_template


def test_curated_has_entries():
    assert len(get_all_curated()) >= 200


def test_curated_entries_have_required_fields():
    required_fields = {"description", "humor", "when_to_use", "lines", "tips", "tags"}
    for meme_id, info in get_all_curated().items():
        for field in required_fields:
            assert field in info, f"Missing '{field}' in curated entry for '{meme_id}'"


def test_curated_templates_exist():
    for meme_id in get_all_curated():
        t = get_template(meme_id)
        assert t is not None, f"Curated meme '{meme_id}' not found in templates"


def test_curated_tags_are_lists():
    for meme_id, info in get_all_curated().items():
        assert isinstance(info["tags"], list), f"Tags for '{meme_id}' should be a list"
        assert len(info["tags"]) > 0, f"Tags for '{meme_id}' should not be empty"
