from memes_mcp.templates import (
    get_all_templates,
    get_font_path,
    get_template,
    get_template_image_path,
    search_templates,
)


def test_load_all_templates():
    templates = get_all_templates()
    assert len(templates) > 100
    assert "drake" in templates
    assert "fry" in templates


def test_get_template():
    t = get_template("drake")
    assert t is not None
    assert t.name == "Drakeposting"
    assert len(t.lines) == 2
    assert t.lines[0].style == "upper"


def test_get_template_not_found():
    assert get_template("nonexistent_template_xyz") is None


def test_search_templates():
    results = search_templates("drake")
    assert len(results) >= 1
    assert any(r.id == "drake" for r in results)


def test_search_by_keyword():
    results = search_templates("fry")
    assert len(results) >= 1
    ids = [r.id for r in results]
    assert "fry" in ids


def test_get_template_image_path():
    path = get_template_image_path("drake")
    assert path.exists()
    assert path.suffix in (".png", ".jpg", ".jpeg")


def test_get_font_path():
    path = get_font_path("thick")
    assert path.exists()
    assert path.name == "TitilliumWeb-Black.ttf"


def test_get_font_path_alias():
    path = get_font_path("impact")
    assert path.exists()
    assert path.name == "TitilliumWeb-Black.ttf"


def test_template_has_example():
    t = get_template("fry")
    assert t is not None
    assert len(t.example) >= 2
