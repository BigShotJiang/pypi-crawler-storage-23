# Publishing csdoc to PyPI

## Prerequisites

1.  **PyPI Account**: You must have an account on [PyPI](https://pypi.org/).
2.  **API Token**: Create an API token on PyPI.
    *   Go to **Account Settings** -> **API Tokens**.
    *   Create a new token (scope it to "Entire account" if `csdoc` doesn't exist yet, or just for `csdoc` if it does).
    *   **Copy the token** (it starts with `pypi-`).

## Publishing with `uv` (Recommended)

Since this project uses `uv`, you can publish directly with it.

1.  **Build the package**:
    ```bash
    uv build
    ```
    This creates `dist/csdoc-0.1.0.tar.gz` and `dist/csdoc-0.1.0-py3-none-any.whl`.

2.  **Publish**:
    ```bash
    uv publish --token <your-pypi-token>
    ```
    *   Replace `<your-pypi-token>` with your actual token.
    *   Alternatively, set the `UV_PUBLISH_TOKEN` environment variable.

## Publishing with `twine` (Alternative)

If you prefer standard tools:

1.  Install twine:
    ```bash
    uv pip install twine  # or pip install twine
    ```

2.  Upload:
    ```bash
    twine upload dist/*
    ```
    You will be prompted for your username (`__token__`) and password (the API token).
