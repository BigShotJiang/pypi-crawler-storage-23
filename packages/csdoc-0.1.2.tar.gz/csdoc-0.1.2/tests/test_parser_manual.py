import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../src')))

from csdoc.parser.csound import CsoundParser
from csdoc.models import UDOEntry, InstrumentEntry, StructEntry

def test_parser():
    parser = CsoundParser()
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures/sample.csd')
    entries = parser.parse_project(fixture_path)
    
    print(f"Found {len(entries)} entries.")
    
    for entry in entries:
        print(f"Entry: {entry.name} ({type(entry).__name__})")
        print(f"  Description: {entry.description}")
        for param in entry.params:
            print(f"  Param: {param.name} - {param.description}")
        for ret in entry.returns:
            print(f"  Return: {ret.description}")
        print("-" * 20)

    # Assertions
    assert len(entries) == 4
    
    # 0: IncOp, 1: MyOsc, 2: Reverb, 3: MyStruct
    assert entries[0].name == "IncOp"
    assert entries[1].name == "MyOsc"
    
    udo = entries[1]
    assert len(udo.params) == 2
    assert udo.params[0].name == "kamp"
    
    instr = entries[2]
    assert isinstance(instr, InstrumentEntry)
    assert instr.name == "Reverb"
    
    struct = entries[3]
    assert isinstance(struct, StructEntry)
    assert struct.name == "MyStruct"

if __name__ == "__main__":
    test_parser()
