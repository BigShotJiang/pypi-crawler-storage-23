import re
from typing import Dict, List, Tuple
from ..models import DocParam, DocReturn

def parse_docblock(content: str) -> Tuple[str, List[DocParam], List[DocReturn]]:
    """
    Parses the content of a docblock (inside /** ... */).
    Returns (description, params, returns)
    """
    lines = content.splitlines()
    cleaned_lines = []
    
    # Strip leading * from each line
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('*'):
            # Remove the first * and maybe one space
            line = stripped[1:]
            if line.startswith(' '):
                line = line[1:]
        else:
            # Maybe it didn't start with *, just use stripped or original?
            # Standard JSDoc often has * aligned. 
            # If we stripped it, we lose indentation for code blocks.
            # Let's try to be smart: remove optional whitespace then optional * then optional space.
            # actually usually:
            # /**
            #  * desc
            #  */
            # so we just match ^\s*\*\s?
            m = re.match(r'^\s*\*\s?(.*)', line)
            if m:
                line = m.group(1)
            else:
                line = line.strip()
        cleaned_lines.append(line)
        
    full_text = '\n'.join(cleaned_lines).strip()
    
    # Now split by tags
    # We look for @param, @return at start of lines (logically)
    # But since we joined them, we can use regex or iterate lines again.
    # Iterating lines is safer for context.
    
    description_lines = []
    params = []
    returns = []
    
    current_tag = None # None (desc), 'param', 'return'
    current_buffer = [] 
    
    # Helper to flush current buffer
    def flush():
        nonlocal current_tag, current_buffer
        text = '\n'.join(current_buffer).strip()
        if not text:
            return

        if current_tag is None:
            description_lines.append(text)
        elif current_tag == 'param':
            # Parse param: @param {type} name description
            # or @param name description
            # text starts after @param
            # We need to handle the content we've collected
            
            # Regex for param:
            # ^(\{.*?\})?\s*(\S+)\s*(.*)
            # group 1: type (optional)
            # group 2: name
            # group 3: desc
            m = re.match(r'^(?:\{([^\}]+)\})?\s*(\S+)\s*(.*)', text, re.DOTALL)
            if m:
                type_info = m.group(1) or ""
                name = m.group(2)
                desc = m.group(3)
                params.append(DocParam(name=name, description=desc, type_info=type_info))
            else:
                # Fallback
                params.append(DocParam(name="?", description=text))
                
        elif current_tag == 'return':
            # @return {type} name description
            # or @return name description
            # Try to match {type} name desc first
            m = re.match(r'^(?:\{([^\}]+)\})?\s*(\S+)\s*(.*)', text, re.DOTALL)
            if m:
                type_info = m.group(1) or ""
                name = m.group(2)
                desc = m.group(3)
                returns.append(DocReturn(name=name, description=desc, type_info=type_info))
            else:
                returns.append(DocReturn(description=text))
        
        current_buffer = []

    for line in cleaned_lines:
        # Check for tag
        m = re.match(r'^@(\w+)(?:\s+(.*))?$', line)
        if m:
            flush()
            tag_name = m.group(1)
            content_start = m.group(2) or ""
            
            if tag_name == 'param':
                current_tag = 'param'
                current_buffer = [content_start]
            elif tag_name in ('return', 'returns'):
                current_tag = 'return'
                current_buffer = [content_start]
            else:
                # Unknown tag, treat as part of description or ignore?
                # JSDoc usually keeps them or hides them. 
                # For now let's append to description if it was checking description,
                # or just ignore. 
                # Let's treat unknown tags as description for now?
                # Or skipping. Let's skip unknown tags for now to keep clean.
                current_tag = 'unknown' 
                current_buffer = [line]
        else:
            if current_tag != 'unknown':
                current_buffer.append(line)
            
    flush()
    
    return '\n'.join(description_lines).strip(), params, returns
