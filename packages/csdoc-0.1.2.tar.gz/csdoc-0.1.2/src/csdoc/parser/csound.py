import re
import os
from typing import List, Set, Optional
from .docblock import parse_docblock
from ..models import DocEntry, UDOEntry, InstrumentEntry, StructEntry, DocParam, DocReturn

class CsoundParser:
    def __init__(self):
        self.entries: List[DocEntry] = []
        self.visited_files: Set[str] = set()

    def parse_project(self, root_file: str) -> List[DocEntry]:
        """
        Parses a Csound project starting from a root file (e.g. .csd or .orc).
        """
        self.entries = []
        self.visited_files = set()
        
        abs_path = os.path.abspath(root_file)
        if not os.path.exists(abs_path):
            raise FileNotFoundError(f"File not found: {root_file}")
            
        self._parse_file(abs_path)
        return self.entries

    def _parse_file(self, file_path: str):
        if file_path in self.visited_files:
            return
        self.visited_files.add(file_path)
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"Warning: Could not read {file_path}: {e}")
            return

        # 1. Handle Includes
        # Regex for #include "..." or #include <...>
        # Csound usually uses #include "file"
        include_iter = re.finditer(r'^\s*#include\s+"([^"]+)"', content, re.MULTILINE)
        for match in include_iter:
            inc_path = match.group(1)
            # Resolve path relative to current file
            current_dir = os.path.dirname(file_path)
            full_inc_path = os.path.join(current_dir, inc_path)
            self._parse_file(os.path.abspath(full_inc_path))

        # 2. Parse DocBlocks and Entries
        # We assume docblocks are /** ... */
        # We iterate through the file looking for docblocks.
        # When we find one, we look ahead for the definition.
        
        # Regex for docblock
        docblock_pattern = re.compile(r'/\*\*(.*?)\*/', re.DOTALL)
        
        last_pos = 0
        matches = list(docblock_pattern.finditer(content))
        
        for m in matches:
            block_content = m.group(1)
            end_pos = m.end()
            
            # Find the line number of the start of the block
            # (Crude approximation or accurate calculation)
            preceeding_text = content[:m.start()]
            line_number = preceeding_text.count('\n') + 1
            
            # Look ahead for the next definition
            # We look from end_pos until we find a definition or another docblock or end of file
            # Actually, just look for the *next* definition pattern.
            # If there is a huge gap or another docblock, maybe it's a detached comment?
            # But standard behavior: take the *first* matching declaration after the comment.
            # We should probably limit the search distance or stop at next comment.
            
            # Let's get the text chunk after the comment
            chunk_start = end_pos
            # Use a limited chunk to avoid scanning whole file? Or just regex search from pos
            
            # Regexes for definitions
            # 1. Old-style: opcode name, out, in
            opcode_old_re = re.compile(r'\bopcode\b\s+([\w\d_]+)\s*,\s*(\S+)\s*,\s*(\S+)')
            # 2. New-style (Csound 7): opcode name(arg list):ret types
            # Example: opcode MyOp(k1:k, i1:i):k
            opcode_new_re = re.compile(r'\bopcode\b\s+([\w\d_]+)\s*\((.*?)\)\s*(?::\s*([ \t\w\d_,]+))?')
            
            # instr name
            instr_re = re.compile(r'\binstr\b\s+([\w\d_]+)')
            # struct name
            struct_re = re.compile(r'\bstruct\b\s+(\w+)')
            
            # Search in the remaining content
            search_text = content[chunk_start:]
            next_docblock = docblock_pattern.search(search_text)
            limit_pos = next_docblock.start() if next_docblock else len(search_text)
            candidate_text = search_text[:limit_pos]
            
            # Find the earliest match
            matches_found = []
            m_opcode_old = opcode_old_re.search(candidate_text)
            if m_opcode_old: matches_found.append((m_opcode_old.start(), 'opcode_old', m_opcode_old))
            
            m_opcode_new = opcode_new_re.search(candidate_text)
            if m_opcode_new: matches_found.append((m_opcode_new.start(), 'opcode_new', m_opcode_new))

            m_instr = instr_re.search(candidate_text)
            if m_instr: matches_found.append((m_instr.start(), 'instr', m_instr))
            
            m_struct = struct_re.search(candidate_text)
            if m_struct: matches_found.append((m_struct.start(), 'struct', m_struct))
            
            matches_found.sort(key=lambda x: x[0])
            
            if not matches_found:
                continue
                
            match_type = matches_found[0][1]
            match_obj = matches_found[0][2]
            desc, params, returns = parse_docblock(block_content)
            
            entry = None
            if match_type.startswith('opcode'):
                if match_type == 'opcode_old':
                    name = match_obj.group(1)
                    outs = match_obj.group(2)
                    ins = match_obj.group(3)
                else: # opcode_new
                    name = match_obj.group(1)
                    arg_list = match_obj.group(2)
                    ret_list = match_obj.group(3) or ""
                    
                    # Convert arg_list (e.g. "a1:a, k1:k") to types string (e.g. "ak")
                    # Or if it's just "a1, k1", we can't really know unless we parse types.
                    # Common Csound 7 style often omits types if they are default, but 
                    # usually they are explicit in UDOs. 
                    # If they are just names, maybe we just list names?
                    # Let's try to extract types if present.
                    in_types = []
                    arg_names = []
                    for arg in arg_list.split(','):
                        arg = arg.strip()
                        if not arg:
                            continue
                            
                        # Extract name and type
                        if ':' in arg:
                            parts = arg.split(':')
                            arg_name = parts[0].strip()
                            type_ = parts[-1].strip()
                        else:
                            arg_name = arg
                            # Heuristic: first character of name?
                            type_ = arg[0] if arg else ""
                            
                        arg_names.append(arg_name)
                        in_types.append(type_)
                    
                    out_types = []
                    for ret in ret_list.split(','):
                        ret = ret.strip()
                        if ret:
                            out_types.append(ret)
                    
                    ins = "".join(in_types)
                    outs = "".join(out_types)
                    
                # Scan for xout and xin in the opcode body
                xout_names = []
                # old style opcodes usually rely on xin
                # Let's search from the match position until 'endop'
                body_text = search_text[matches_found[0][0]:]
                endop_match = re.search(r'\bendop\b', body_text)
                if endop_match:
                    body_text = body_text[:endop_match.end()]
                    for b_line in body_text.split('\n'):
                        b_line = b_line.strip()
                        if 'xout' in b_line and not b_line.startswith(';'):
                            # Extremely simple parsing: xout arg1, arg2
                            parts = b_line.split('xout')
                            if len(parts) > 1:
                                xouts = parts[1].split(',')
                                xout_names = [x.strip() for x in xouts if x.strip()]
                        elif 'xin' in b_line and not b_line.startswith(';') and match_type == 'opcode_old':
                            # Extract what comes before xin usually, wait. 
                            # The old script did: `udo['xin'] = line[:-3]` which implies it assigned the LHS of xin.
                            # Usually old style is: `a1, a2 xin` 
                            parts = b_line.split('xin')
                            if parts[0].strip():
                                xins = parts[0].split(',')
                                arg_names = [x.strip() for x in xins if x.strip()]
                                
                entry = UDOEntry(
                    name=name,
                    description=desc,
                    params=params,
                    returns=returns,
                    inputs=ins,
                    outputs=outs,
                    arg_names=arg_names if match_type != 'opcode_old' else [],
                    line_number=line_number,
                    file_path=file_path,
                    raw_docblock=block_content
                )
            elif match_type == 'instr':
                name = match_obj.group(1)
                entry = InstrumentEntry(
                    name=name, # name field in DocEntry
                    id=name,
                    description=desc,
                    params=params,
                    returns=returns,
                    line_number=line_number,
                    file_path=file_path,
                    raw_docblock=block_content
                )
            elif match_type == 'struct':
                name = match_obj.group(1)
                entry = StructEntry(
                    name=name,
                    description=desc,
                    params=params, # struct params? Members?
                    returns=returns,
                    line_number=line_number,
                    file_path=file_path,
                    raw_docblock=block_content
                )
                
            if entry:
                self.entries.append(entry)

