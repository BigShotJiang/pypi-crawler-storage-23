from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class DocParam:
    """Represents a @param tag"""
    name: str = ""
    description: str = ""
    type_info: str = "" # e.g. from {type} if supported, or inferred

@dataclass
class DocReturn:
    """Represents a @return tag"""
    name: str = ""
    type_info: str = ""
    description: str = ""

@dataclass
class DocEntry:
    """Base class for all documented entities"""
    name: str = ""
    description: str = "" # Main description from the docblock
    line_number: int = 0
    file_path: str = ""
    params: List[DocParam] = field(default_factory=list)
    returns: List[DocReturn] = field(default_factory=list)
    raw_docblock: str = "" # The original comment block

@dataclass
class UDOEntry(DocEntry):
    """Represents a User Defined Opcode"""
    inputs: str = ""  # The input string, e.g. "a, k"
    outputs: str = "" # The output string, e.g. "a"
    arg_names: List[str] = field(default_factory=list) # Extracted argument names
    xout_names: List[str] = field(default_factory=list) # Extracted xout names
    deprecated: bool = False

@dataclass
class InstrumentEntry(DocEntry):
    """Represents a Csound Instrument"""
    id: str = "" # Can be number or name
    # Instruments might have p-fields described in params

@dataclass
class StructEntry(DocEntry):
    """Represents a typedef/struct"""
    members: List[str] = field(default_factory=list) 
