import typer
from typing import Optional
from pathlib import Path
from .parser.csound import CsoundParser
from .generator.builder import SiteBuilder

app = typer.Typer()

@app.command()
def build(
    source: Path = typer.Argument(..., exists=True, help="The Csound source file (e.g. main.csd or .orc)"),
    output: Path = typer.Option(Path("dist"), "--output", "-o", help="Output directory for the documentation site")
):
    """
    Build documentation for a Csound project.
    """
    typer.echo(f"Parsing project from {source}...")
    
    parser = CsoundParser()
    try:
        entries = parser.parse_project(str(source))
    except Exception as e:
        typer.echo(f"Error parsing project: {e}", err=True)
        raise typer.Exit(code=1)
        
    typer.echo(f"Found {len(entries)} documented entries.")
    
    typer.echo(f"Building site in {output}...")
    # Use the parent directory of the source as the base path for relativization
    base_path = str(source.resolve().parent)
    builder = SiteBuilder(str(output), base_path=base_path)
    builder.build(entries)
    
    typer.echo("Done!")

@app.command()
def json(
    source: Path = typer.Argument(..., exists=True, help="The Csound source file"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output JSON file")
):
    """
    Export parsed documentation as JSON.
    """
    import json
    import dataclasses
    
    parser = CsoundParser()
    entries = parser.parse_project(str(source))
    
    data = [dataclasses.asdict(e) for e in entries]
    
    if output:
        with open(output, 'w') as f:
            json.dump(data, f, indent=2)
        typer.echo(f"JSON written to {output}")
    else:
        typer.echo(json.dumps(data, indent=2))

if __name__ == "__main__":
    app()
