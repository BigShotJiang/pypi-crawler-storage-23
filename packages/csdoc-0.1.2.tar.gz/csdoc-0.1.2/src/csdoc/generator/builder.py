import os
import shutil
from typing import List, Optional, Dict, Tuple
from jinja2 import Environment, FileSystemLoader, select_autoescape
import markdown
from ..models import DocEntry

class SiteBuilder:
    def __init__(self, output_dir: str, base_path: Optional[str] = None):
        self.output_dir = output_dir
        self.base_path = base_path or os.getcwd()
        self.template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        self.env = Environment(
            loader=FileSystemLoader(self.template_dir),
            autoescape=select_autoescape(['html', 'xml'])
        )
        # Register markdown filter
        self.env.filters['markdown'] = lambda text: markdown.markdown(text) if text else ""

    def build(self, entries: List[DocEntry]):
        """
        Builds the documentation site.
        """
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            
        # Relativize paths for display
        for entry in entries:
            if os.path.isabs(entry.file_path):
                entry.file_path = os.path.relpath(entry.file_path, self.base_path)

        # Group entries by name and type (for overloads)
        # We group by (name, type) so that an instrument and UDO with same name are separate
        grouped: Dict[Tuple[str, str], List[DocEntry]] = {}
        for entry in entries:
            key = (entry.name, type(entry).__name__)
            if key not in grouped:
                grouped[key] = []
            grouped[key].append(entry)

        # Convert to a list for Jinja2
        entry_groups = []
        for (name, entry_type), items in grouped.items():
            entry_groups.append({
                "name": name,
                "type": entry_type.replace('Entry', ''),
                "entries": items
            })

        template = self.env.get_template('index.html')
        
        # Collect all entry names for type linking
        documented_names = {entry.name for entry in entries}
        
        output_content = template.render(
            entry_groups=entry_groups,
            documented_names=documented_names
        )
        
        with open(os.path.join(self.output_dir, 'index.html'), 'w', encoding='utf-8') as f:
            f.write(output_content)
        
        print(f"Documentation generated in {self.output_dir}")
