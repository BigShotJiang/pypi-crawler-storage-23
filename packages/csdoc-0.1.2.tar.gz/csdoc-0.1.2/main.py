def main():
    print("Hello from csdoc!")


if __name__ == "__main__":
    main()
