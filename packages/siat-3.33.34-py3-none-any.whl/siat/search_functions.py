# -*- coding: utf-8 -*-
"""
本模块功能：搜索一个模块中符合条件的函数，并生成文档
所属工具包：证券投资分析工具SIAT 
SIAT：Security Investment Analysis Tool
创建日期：2026年1月16日
最新修订日期：2026年1月17日
作者：王德宏 (WANG Dehong, Peter)
作者单位：北京外国语大学国际商学院
版权所有：王德宏
用途限制：仅限研究与教学使用，不可商用！商用需要额外授权。
特别声明：作者不对使用本工具进行证券投资导致的任何损益负责！
"""

#==============================================================================
#关闭所有警告
import warnings; warnings.filterwarnings('ignore')
#==============================================================================
import importlib
import inspect
import pkgutil
import os
import re

def find_functions(module='akshare', words=None, use_regex=False):
    """
    在指定模块及其子模块中查找函数。words可为字符串列表，须同时满足。
    快速搜索，可搜索下属子模块、模糊匹配、正则表达式。
    但不能生成文档。
    
    参数：
        module: 顶层模块名（字符串）
        words: 关键词列表；为空或 None 时列出所有函数
        use_regex: 是否使用正则匹配（默认 False）
    
    返回：
        按升序排列的字符串列表：
        function_name (module.submodule - filename.py)
    """

    if words is None:
        words = []

    # 动态导入顶层模块
    top_mod = importlib.import_module(module)

    results = []

    # 遍历模块及其所有子模块
    for finder, name, ispkg in pkgutil.walk_packages(top_mod.__path__, top_mod.__name__ + "."):
        try:
            mod = importlib.import_module(name)
        except Exception:
            continue  # 某些模块可能无法导入，跳过

        # 获取模块中的所有函数
        functions = inspect.getmembers(mod, inspect.isfunction)

        for func_name, func_obj in functions:
            # 获取函数所在文件
            file_path = inspect.getsourcefile(func_obj)
            if not file_path:
                continue
            file_name = os.path.basename(file_path)

            # 匹配逻辑
            if words:
                if use_regex:
                    # 正则匹配：所有 words 都必须匹配
                    if all(re.search(w, func_name, re.IGNORECASE) for w in words):
                        results.append(f"{func_name} ({name} - {file_name})")
                else:
                    # 普通包含匹配
                    if all(w.lower() in func_name.lower() for w in words):
                        results.append(f"{func_name} ({name} - {file_name})")
            else:
                # words 为空 → 列出所有函数
                results.append(f"{func_name} ({name} - {file_name})")

    # 升序排序
    results.sort()
    return results

if __name__ =="__main__":
    find_functions(module='akshare', words=['option', 'sz'])
    find_functions(module='siat', words=['option'])

#==============================================================================
import importlib
import inspect
import pkgutil
import os
import re
import contextlib
import io
from collections import defaultdict
from IPython.display import Markdown, display

def find_functions2(
    module='akshare',
    words=None,
    use_regex=False,
    show_signature=True,
    show_doc=False,
    markdown=False
    ):
    """
    在指定模块及其子模块中查找函数，并以美观格式输出。
    自动屏蔽 akshare 的 token 提示。
    """

    if words is None:
        words = []

    top_mod = importlib.import_module(module)
    grouped = defaultdict(list)

    # 遍历模块及其所有子模块
    for finder, name, ispkg in pkgutil.walk_packages(top_mod.__path__, top_mod.__name__ + "."):

        # 屏蔽 akshare 的 token 提示
        with contextlib.redirect_stdout(io.StringIO()):
            try:
                mod = importlib.import_module(name)
            except Exception:
                continue

        functions = inspect.getmembers(mod, inspect.isfunction)

        for func_name, func_obj in functions:
            file_path = inspect.getsourcefile(func_obj)
            if not file_path:
                continue
            file_name = os.path.basename(file_path)

            # 匹配逻辑
            if words:
                if use_regex:
                    if not all(re.search(w, func_name, re.IGNORECASE) for w in words):
                        continue
                else:
                    if not all(w.lower() in func_name.lower() for w in words):
                        continue

            # 构造 Markdown 格式内容
            block = f"### `{func_name}`\n"

            if show_signature:
                try:
                    sig = str(inspect.signature(func_obj))
                    block += f"**签名：** `{func_name}{sig}`\n\n"
                except Exception:
                    pass

            block += f"**文件：** `{file_name}`\n\n"

            if show_doc:
                doc = inspect.getdoc(func_obj)
                if doc:
                    """
                    #仅显示docstring的第一行
                    first_line = doc.split("\n")[0]
                    block += f"**说明：** {first_line}\n\n"
                    """
                    """
                    # 保留完整 docstring，并让 Markdown 正确渲染换行
                    full_doc = doc.strip().replace("\n", "\n\n")
                    block += f"**说明：**\n\n{full_doc}\n\n"
                    """
                    # 保留所有行，但用 <br> 实现紧凑行间距
                    compact_doc = doc.strip().replace("\n", "<br>")
                    block += f"**说明：**<br>{compact_doc}\n\n"
                    
            grouped[name].append(block)

    # Markdown 输出
    if markdown or show_doc:
        md_text = ""
        for mod_name in sorted(grouped.keys()):
            md_text += f"## 模块：{mod_name}\n\n"
            for block in grouped[mod_name]:
                md_text += block + "\n"
        display(Markdown(md_text))
        return  # 不返回列表，直接渲染

    # 普通文本输出（保持兼容）
    results = []
    for mod_name in sorted(grouped.keys()):
        for block in grouped[mod_name]:
            results.append(block)
    return results


if __name__ =="__main__":
    
    # 生成 Markdown 文档（最强功能）
    md = find_functions2('akshare', ['option','szse'], markdown=True)
    print(md)
    
    # 列出所有函数（含签名）
    find_functions2('akshare', words=[], show_signature=True)
    
    # 使用正则匹配
    find_functions2('akshare', ['^stock'], use_regex=True)
    
    # 显示 docstring 摘要
    find_functions2('akshare', ['option'], show_doc=True)
    find_functions2('siat', ['option'], show_doc=True)




    
    
    
    
    
    
#==============================================================================
#==============================================================================
#==============================================================================
#==============================================================================
#==============================================================================
#==============================================================================


















