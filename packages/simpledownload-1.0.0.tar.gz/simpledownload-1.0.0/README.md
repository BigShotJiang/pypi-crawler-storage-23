# 🚀 SimpleDownload CLI

Ferramenta de Estudo Livre  
Feito por Tiago Rabelo

---

Criei esse app para ajudar estudantes a conseguirem baixar o que precisam de fontes com API pública sem precisar passar por nenhuma burocracia enfadonha.

O nosso tempo é precioso e temos que aproveitar cada segundo.

Espero que esse app ajude você a economizar seu precioso tempo e assim contribua para o avanço científico!

---

## 📦 Instalação

```bash
pip install simpledownload
