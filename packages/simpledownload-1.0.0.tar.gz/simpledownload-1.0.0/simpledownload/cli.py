import os
import re

# --- FUNÇÕES DE UTILIDADE (LIMPEZA E INTERFACE) ---

def limpar_tela():
    # Funciona no Pydroid (Linux/Android) e no Windows
    os.system('cls' if os.name == 'nt' else 'clear')

def mostrar_resultado(servico, link):
    print("\n\033[1;32m" + "═"*55)
    print(f"  MOTOR {servico.upper()} ATIVADO COM SUCESSO!")
    print(f"  LINK: \033[1;37m{link}")
    print("\033[1;32m" + "═"*55 + "\033[0m")
    print("\n\033[1;33mPróximos passos:\033[0m")
    print("1. Clique no link acima para abrir no navegador.")
    print("2. O site processará o arquivo automaticamente.")
    print("3. Clique em 'Download PDF' quando o botão aparecer.")
    input("\n\033[1;36mPressione ENTER para voltar ao menu...\033[0m")

# --- MOTORES DE EXTRAÇÃO ---

def motor_scribd():
    limpar_tela()
    print("\033[1;36m" + "╔" + "═"*43 + "╗")
    print("║          EXTRAÇÃO DE DOCS SCRIBD          ║")
    print("╚" + "═"*43 + "╝" + "\033[0m")
    url = input("\nCole o link do Scribd: ").strip()
    
    # Busca o ID numérico (8 a 12 dígitos)
    busca_id = re.search(r'(\d{8,12})', url)
    
    if busca_id:
        doc_id = busca_id.group(1)
        # Link de bypass via VPDFS (Direto pelo ID)
        link_final = f"https://scribd.vpdfs.com/document/{doc_id}/"
        mostrar_resultado("Scribd", link_final)
    else:
        print("\n\033[1;31m[ERRO] Não encontrei um ID de documento válido neste link!\033[0m")
        input("Pressione ENTER para tentar novamente...")

def motor_slideshare():
    limpar_tela()
    print("\033[1;33m" + "╔" + "═"*43 + "╗")
    print("║        EXTRAÇÃO DE SLIDES SLIDESHARE      ║")
    print("╚" + "═"*43 + "╝" + "\033[0m")
    url = input("\nCole o link do SlideShare: ").strip()
    
    if "slideshare.net" in url.lower():
        # Motor DocDownloader: já cai na página de geração com a URL injetada
        link_final = f"https://docdownloader.com/slideshare-downloader?url={url}"
        mostrar_resultado("SlideShare", link_final)
    else:
        print("\n\033[1;31m[ERRO] Isso não parece um link do SlideShare!\033[0m")
        input("Pressione ENTER para tentar novamente...")

# --- MENU PRINCIPAL (SIMPLEDOWNLOAD) ---

def menu():
    while True:
        limpar_tela()
        # Cores: Azul (\033[1;34m), Amarelo (\033[1;33m), Vermelho (\033[1;31m)
        print("\033[1;34m" + "╔" + "═"*43 + "╗")
        print("║          SIMPLEDOWNLOAD CLI v1.0          ║")
        print("║        'Ferramenta de Estudo Livre - feito por Tiago Rabelo'       ║")
        print("╚" + "═"*43 + "╝" + "\033[0m")
        print("\n\033[1;37mEscolha o motor de download:\033[0m")
        print("-" * 45)
        print("\033[1;36m( 1 )\033[0m Scribd (PDFs e Documentos)")
        print("\033[1;33m( 2 )\033[0m SlideShare (Apresentações)")
        print("\033[1;30m( 3 ) [ Upgrade Futuro: Issuu/Academia ]\033[0m")
        print("-" * 45)
        print("\033[1;31m( 0 ) Sair do App\033[0m")
        print("-" * 45)
        
        opcao = input("\nOpção desejada: ")
        
        if opcao == "1":
            motor_scribd()
        elif opcao == "2":
            motor_slideshare()
        elif opcao == "0":
            print("\n\033[1;32mEncerrando SimpleDownload... Bons estudos!\033[0m")
            break
        else:
            print("\n\033[1;31mOpção inválida! Tente de 0 a 2.\033[0m")
            input("Pressione ENTER...")

# --- PONTO DE ENTRADA ---
def main():
    menu()

if __name__ == "__main__":
    main()
