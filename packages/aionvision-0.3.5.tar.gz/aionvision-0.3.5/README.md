# aion — Aionvision Python SDK

The official Python SDK for the [Aionvision](https://aionvision.tech) Vision AI API.

Aion is a powerful platform for visual intelligence and agentic AI infrastructure.

## This Release (v0.3.5)

This release provides the stable foundation of the SDK:

- **Full configuration management** — API key validation, HTTPS enforcement, proxy support, env var loading
- **Complete exception hierarchy** — 20 typed exception classes covering every error case
- **`AionVision` constructor** — the full public API signature, validated on construction
- **`from_env()` classmethod** — reads `AIONVISION_API_KEY` and all `AIONVISION_*` env vars
- **Async context manager** — `async with AionVision(...) as client` protocol

Resource operations (`client.uploads`, `client.describe`, etc.) are available in the upcoming full SDK release. Accessing a resource property in this version raises `NotImplementedError` with a link to the docs.

## Installation

```bash
pip install aionvision
```

With `.env` file support:

```bash
pip install aionvision[dotenv]
```

## Usage

### Create a client

```python
from aion import AionVision

# Validates key format, HTTPS, and all config
client = AionVision(api_key="aion_...")

# From environment variables
import os
os.environ["AIONVISION_API_KEY"] = "aion_..."
client = AionVision.from_env()
```

### With a `.env` file

```python
from aion import load_dotenv, AionVision

load_dotenv()  # reads AIONVISION_API_KEY from .env
client = AionVision.from_env()
```

### Async context manager

```python
import asyncio
from aion import AionVision

async def main():
    async with AionVision(api_key="aion_...") as client:
        # client is ready — resource calls available in the full SDK
        pass

asyncio.run(main())
```

### Exception handling

```python
from aion.exceptions import (
    AionvisionError,       # Base exception
    AuthenticationError,   # Invalid API key
    RateLimitError,        # Rate limit exceeded
    QuotaExceededError,    # Usage quota exceeded
    ValidationError,       # Invalid request
    ResourceNotFoundError, # Resource not found
    AionvisionTimeoutError,# Operation timed out
    ServerError,           # Server-side error (5xx)
    UploadError,           # Upload failed
    DescriptionError,      # Description generation failed
)

# Exception classes also accessible without a separate import:
# except AionVision.AuthenticationError
```

## Configuration

```python
from aion import AionVision

client = AionVision(
    api_key="aion_...",
    base_url="https://api.aionvision.tech/api/v2",  # default, must use HTTPS
    timeout=300.0,
    max_retries=3,
    retry_delay=1.0,
    polling_interval=2.0,
    polling_timeout=360.0,
    tenant_id="my-tenant",             # or set AIONVISION_TENANT_ID
    proxy_url="https://proxy.host",    # or set AIONVISION_PROXY_URL
)
```

All settings can be provided via environment variables:

| Environment Variable          | Parameter          |
|-------------------------------|--------------------|
| `AIONVISION_API_KEY`          | `api_key`          |
| `AIONVISION_BASE_URL`         | `base_url`         |
| `AIONVISION_TIMEOUT`          | `timeout`          |
| `AIONVISION_MAX_RETRIES`      | `max_retries`      |
| `AIONVISION_RETRY_DELAY`      | `retry_delay`      |
| `AIONVISION_POLLING_INTERVAL` | `polling_interval` |
| `AIONVISION_POLLING_TIMEOUT`  | `polling_timeout`  |
| `AIONVISION_TENANT_ID`        | `tenant_id`        |
| `AIONVISION_PROXY_URL`        | `proxy_url`        |
| `AIONVISION_ENABLE_TRACING`   | `enable_tracing`   |

## Resources (Full SDK)

The following resources are available in the upcoming full SDK release. See [aionvision.tech/docs](https://aionvision.tech/docs) for the complete API reference.

| Resource               | Description                                  |
|------------------------|----------------------------------------------|
| `client.uploads`       | Upload images (streaming, batch)             |
| `client.describe`      | Generate AI descriptions                     |
| `client.verify`        | Visual verification against rules            |
| `client.files`         | Manage uploaded files                        |
| `client.folders`       | Folder organization                          |
| `client.documents`     | Document upload and text extraction          |
| `client.batch`         | Batch AI processing jobs                     |
| `client.chat`          | Agentic chat over your image library         |
| `client.colors`        | Color extraction and analysis                |
| `client.links`         | Shareable link management                    |
| `client.audit`         | Audit log access                             |
| `client.cloud_storage` | Cloud storage integration                    |
| `client.agent_operations` | Agentic organize/synthesize operations    |
| `client.agent_search`  | Semantic and visual search                   |
| `client.video_uploads` | Video upload (chunked)                       |
| `client.video_analysis`| Video scene analysis                         |
| `client.video_scenes`  | Video scene management                       |
| `client.settings`      | Account settings                             |
| `client.tenant`        | Tenant management                            |

## Links

- **Website**: [aionvision.tech](https://aionvision.tech)
- **Docs**: [aionvision.tech/docs](https://aionvision.tech/docs)

## License

Apache 2.0 — see [LICENSE](LICENSE) for details.
