"""Tracing stub — full OpenTelemetry integration available in the full SDK release."""

from typing import Any


def is_tracing_available() -> bool:
    """Returns False in this release. Full tracing available in the complete SDK."""
    return False


def configure_tracing(**kwargs: Any) -> bool:
    """No-op stub. Returns False — full OpenTelemetry tracing available in the complete SDK."""
    return False


def set_correlation_id(correlation_id: str) -> None:
    """No-op stub. Full correlation ID support available in the complete SDK."""
    pass
