"""Aionvision Python SDK — slim distribution.

Provides the AionVision client, full configuration management, and the complete
exception hierarchy. See https://aionvision.tech/docs for the full API reference.
"""

from ._version import __version__
from ._tracing import configure_tracing, is_tracing_available, set_correlation_id
from .client import AionVision
from .config import (
    ClientConfig,
    InsecureTransportWarning,
    load_dotenv,
    ENV_API_KEY,
    ENV_BASE_URL,
    ENV_ENABLE_TRACING,
    ENV_MAX_RETRIES,
    ENV_POLLING_INTERVAL,
    ENV_POLLING_TIMEOUT,
    ENV_PROXY_URL,
    ENV_RETRY_DELAY,
    ENV_TENANT_ID,
    ENV_TIMEOUT,
)
from .exceptions import (
    AionvisionConnectionError,
    AionvisionError,
    AionvisionPermissionError,
    AionvisionTimeoutError,
    AuthenticationError,
    BatchError,
    ChatError,
    CircuitBreakerError,
    CloudStorageError,
    DescriptionError,
    DocumentProcessingError,
    QuotaExceededError,
    RateLimitError,
    ResourceNotFoundError,
    ServerError,
    SSEStreamError,
    UploadError,
    ValidationError,
    VideoAnalysisError,
    VideoUploadError,
)

__all__ = [
    "__version__",
    # Client
    "AionVision",
    # Config
    "ClientConfig",
    "InsecureTransportWarning",
    "load_dotenv",
    "ENV_API_KEY",
    "ENV_BASE_URL",
    "ENV_ENABLE_TRACING",
    "ENV_MAX_RETRIES",
    "ENV_POLLING_INTERVAL",
    "ENV_POLLING_TIMEOUT",
    "ENV_PROXY_URL",
    "ENV_RETRY_DELAY",
    "ENV_TENANT_ID",
    "ENV_TIMEOUT",
    # Tracing stubs
    "configure_tracing",
    "is_tracing_available",
    "set_correlation_id",
    # Exceptions
    "AionvisionError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "QuotaExceededError",
    "ResourceNotFoundError",
    "AionvisionTimeoutError",
    "ServerError",
    "AionvisionPermissionError",
    "UploadError",
    "DescriptionError",
    "DocumentProcessingError",
    "ChatError",
    "BatchError",
    "AionvisionConnectionError",
    "CircuitBreakerError",
    "CloudStorageError",
    "SSEStreamError",
    "VideoUploadError",
    "VideoAnalysisError",
]
