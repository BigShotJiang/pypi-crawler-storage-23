"""AionVision client — slim distribution.

Provides the full constructor signature, configuration validation, async context
manager protocol, and exception hierarchy. Resource methods are available in the
complete SDK. See https://aionvision.tech/docs for the full API reference.
"""

from __future__ import annotations

from typing import Any, NoReturn, Optional

from .config import ClientConfig
from .exceptions import (  # re-export for AionVision.ErrorName access
    AionvisionConnectionError,
    AionvisionError,
    AionvisionPermissionError,
    AionvisionTimeoutError,
    AuthenticationError,
    BatchError,
    ChatError,
    CircuitBreakerError,
    CloudStorageError,
    DescriptionError,
    DocumentProcessingError,
    QuotaExceededError,
    RateLimitError,
    ResourceNotFoundError,
    ServerError,
    SSEStreamError,
    UploadError,
    ValidationError,
    VideoAnalysisError,
    VideoUploadError,
)


class AionVision:
    """
    Async Python client for the Aionvision Vision AI API.

    Validates configuration and exposes the full public API surface.
    Resource operations are available in the complete SDK release.
    See https://aionvision.tech/docs for full documentation.

    This release provides configuration validation, the complete exception
    hierarchy, and the full constructor signature so you can write code against
    the stable public API today. Resource operations (``client.uploads``,
    ``client.describe``, etc.) are available in the full SDK release.

    Usage::

        from aion import AionVision
        client = AionVision(api_key="aion_...")   # validates key + config
        client = AionVision.from_env()            # reads AIONVISION_API_KEY

    Exception classes are also accessible as ``AionVision.AuthenticationError``
    etc. for convenient catch patterns without separate imports.
    """

    # Exception classes available as class attributes for convenient access
    AionvisionError = AionvisionError
    AuthenticationError = AuthenticationError
    RateLimitError = RateLimitError
    ValidationError = ValidationError
    QuotaExceededError = QuotaExceededError
    ResourceNotFoundError = ResourceNotFoundError
    AionvisionTimeoutError = AionvisionTimeoutError
    ServerError = ServerError
    AionvisionPermissionError = AionvisionPermissionError
    UploadError = UploadError
    DescriptionError = DescriptionError
    DocumentProcessingError = DocumentProcessingError
    ChatError = ChatError
    BatchError = BatchError
    AionvisionConnectionError = AionvisionConnectionError
    CircuitBreakerError = CircuitBreakerError
    CloudStorageError = CloudStorageError
    SSEStreamError = SSEStreamError
    VideoUploadError = VideoUploadError
    VideoAnalysisError = VideoAnalysisError

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.aionvision.tech/api/v2",
        timeout: float = 300.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        polling_interval: float = 2.0,
        polling_timeout: float = 360.0,
        tenant_id: Optional[str] = None,
        proxy_url: Optional[str] = None,
        enable_tracing: bool = False,
    ) -> None:
        """
        Create an AionVision client.

        Args:
            api_key: Your Aionvision API key (format: ``aion_<key>``).
            base_url: API base URL. Defaults to the production endpoint.
                Must use HTTPS (HTTP is only allowed for localhost).
            timeout: Request timeout in seconds. Default: 300.
            max_retries: Maximum retry attempts for transient failures. Default: 3.
            retry_delay: Initial delay between retries in seconds (exponential
                backoff applied). Default: 1.0.
            polling_interval: Interval for polling async operations. Default: 2.0.
            polling_timeout: Maximum wait time for polling operations. Default: 360.
            tenant_id: Optional tenant ID for multi-tenant deployments.
            proxy_url: Optional HTTP/HTTPS proxy URL.
            enable_tracing: Enable OpenTelemetry tracing. Default: False.

        Raises:
            ValueError: If ``api_key`` is missing, malformed, or ``base_url``
                uses an insecure scheme for a non-localhost host.
        """
        # Only pass tenant_id/proxy_url when explicitly provided so that
        # ClientConfig's default_factory can read them from env vars otherwise.
        config_kwargs: dict[str, Any] = dict(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            retry_delay=retry_delay,
            polling_interval=polling_interval,
            polling_timeout=polling_timeout,
            enable_tracing=enable_tracing,
        )
        if tenant_id is not None:
            config_kwargs["tenant_id"] = tenant_id
        if proxy_url is not None:
            config_kwargs["proxy_url"] = proxy_url
        self._config = ClientConfig(**config_kwargs)

    @classmethod
    def from_env(cls, **overrides: Any) -> "AionVision":
        """
        Create a client from environment variables.

        Reads ``AIONVISION_API_KEY`` and other ``AIONVISION_*`` variables.
        Any keyword argument overrides the corresponding environment variable.

        Args:
            **overrides: Keyword arguments matching ``__init__`` parameters
                (``api_key``, ``base_url``, ``timeout``, etc.).

        Returns:
            Configured ``AionVision`` instance.

        Raises:
            ValueError: If ``AIONVISION_API_KEY`` is not set and ``api_key``
                is not in ``overrides``.
        """
        config = ClientConfig.from_env(**overrides)
        return cls(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout,
            max_retries=config.max_retries,
            retry_delay=config.retry_delay,
            polling_interval=config.polling_interval,
            polling_timeout=config.polling_timeout,
            tenant_id=config.tenant_id,
            proxy_url=config.proxy_url,
            enable_tracing=config.enable_tracing,
        )

    async def __aenter__(self) -> "AionVision":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass

    def _resource_not_available(self, name: str) -> NoReturn:
        raise NotImplementedError(
            f"'{name}' resource is not available in this release. "
            "See https://aionvision.tech/docs for the full SDK."
        )

    # --- Resource properties ---

    @property
    def uploads(self) -> Any:
        """Image upload operations."""
        return self._resource_not_available("uploads")

    @property
    def describe(self) -> Any:
        """AI description generation."""
        return self._resource_not_available("describe")

    @property
    def verify(self) -> Any:
        """Visual verification against rules."""
        return self._resource_not_available("verify")

    @property
    def files(self) -> Any:
        """File management."""
        return self._resource_not_available("files")

    @property
    def folders(self) -> Any:
        """Folder management."""
        return self._resource_not_available("folders")

    @property
    def documents(self) -> Any:
        """Document upload and text extraction."""
        return self._resource_not_available("documents")

    @property
    def batch(self) -> Any:
        """Batch AI processing jobs."""
        return self._resource_not_available("batch")

    @property
    def chat(self) -> Any:
        """Agentic chat over your image library."""
        return self._resource_not_available("chat")

    @property
    def colors(self) -> Any:
        """Color extraction and analysis."""
        return self._resource_not_available("colors")

    @property
    def links(self) -> Any:
        """Shareable link management."""
        return self._resource_not_available("links")

    @property
    def audit(self) -> Any:
        """Audit log access."""
        return self._resource_not_available("audit")

    @property
    def cloud_storage(self) -> Any:
        """Cloud storage integration."""
        return self._resource_not_available("cloud_storage")

    @property
    def agent_operations(self) -> Any:
        """Agentic organize and synthesize operations."""
        return self._resource_not_available("agent_operations")

    @property
    def agent_search(self) -> Any:
        """Semantic and visual search."""
        return self._resource_not_available("agent_search")

    @property
    def video_uploads(self) -> Any:
        """Video upload (chunked)."""
        return self._resource_not_available("video_uploads")

    @property
    def video_analysis(self) -> Any:
        """Video scene analysis."""
        return self._resource_not_available("video_analysis")

    @property
    def video_scenes(self) -> Any:
        """Video scene management."""
        return self._resource_not_available("video_scenes")

    @property
    def settings(self) -> Any:
        """Account settings."""
        return self._resource_not_available("settings")

    @property
    def tenant(self) -> Any:
        """Tenant management."""
        return self._resource_not_available("tenant")
