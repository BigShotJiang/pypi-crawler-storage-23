"""Configuration for the Aionvision SDK."""

from __future__ import annotations

import os
import re
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Union
from urllib.parse import urlparse

# Environment variable names for SDK configuration
ENV_API_KEY = "AIONVISION_API_KEY"
ENV_BASE_URL = "AIONVISION_BASE_URL"
ENV_TIMEOUT = "AIONVISION_TIMEOUT"
ENV_MAX_RETRIES = "AIONVISION_MAX_RETRIES"
ENV_TENANT_ID = "AIONVISION_TENANT_ID"
ENV_PROXY_URL = "AIONVISION_PROXY_URL"
ENV_ENABLE_TRACING = "AIONVISION_ENABLE_TRACING"

# Environment variables for timing/retry settings
ENV_RETRY_DELAY = "AIONVISION_RETRY_DELAY"
ENV_POLLING_INTERVAL = "AIONVISION_POLLING_INTERVAL"
ENV_POLLING_TIMEOUT = "AIONVISION_POLLING_TIMEOUT"


def _get_env_float(name: str, default: float) -> float:
    """Get a float value from environment variable with fallback."""
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _get_env_int(name: str, default: int) -> int:
    """Get an integer value from environment variable with fallback."""
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _get_env_bool(name: str, default: bool) -> bool:
    """Get a boolean value from environment variable with fallback."""
    value = os.environ.get(name)
    if value is None:
        return default
    return value.lower() in ("true", "1", "yes", "on")


def load_dotenv(
    dotenv_path: Optional[Union[str, Path]] = None,
    *,
    override: bool = False,
) -> bool:
    """
    Load environment variables from a .env file.

    This is a convenience wrapper that requires python-dotenv to be installed.
    If python-dotenv is not installed, this function returns False silently.

    Args:
        dotenv_path: Path to .env file (str or Path). If None, searches for
                    .env in current directory and parent directories.
        override: If True, override existing environment variables.

    Returns:
        True if .env file was loaded, False otherwise.

    Example:
        ```python
        from aion import load_dotenv, AionVision

        # Load .env file before creating client
        load_dotenv()

        # Now use from_env() - it will pick up values from .env
        async with AionVision.from_env() as client:
            result = await client.upload_one("photo.jpg")
        ```

    Note:
        Install python-dotenv with: pip install python-dotenv
        Or install SDK with dotenv extra: pip install aionvision[dotenv]
    """
    try:
        from dotenv import load_dotenv as _load_dotenv
    except ImportError:
        return False

    result = _load_dotenv(dotenv_path, override=override)
    # load_dotenv returns None if file not found, True if loaded
    return result is not False


# Pattern validates API key structure without hardcoding specific brand
# Format: {brand}_{random_key} where brand is lowercase letters
# Examples: aion_AbCd1234..., supra_AbCd1234..., acme_XyZ789...
API_KEY_PATTERN = re.compile(r"^[a-z]+_[A-Za-z0-9_-]{20,}$")


class InsecureTransportWarning(UserWarning):
    """Warning for insecure HTTP transport usage."""
    pass


@dataclass
class ClientConfig:
    """
    Configuration for the Aionvision client.

    Attributes:
        api_key: Your Aionvision API key (e.g., aion_AbCd1234...)
        base_url: API base URL (default: production)
        timeout: Request timeout in seconds
        max_retries: Maximum retry attempts for transient failures
        retry_delay: Initial delay between retries (exponential backoff)
        polling_interval: Interval for polling operations (auto-describe)
        polling_timeout: Maximum time to wait for polling operations
        tenant_id: Optional tenant ID for multi-tenant deployments
        proxy_url: Optional proxy URL for network requests
        circuit_breaker_enabled: Enable circuit breaker for resilience
        circuit_breaker_failure_threshold: Failures before opening circuit
        circuit_breaker_success_threshold: Successes to close circuit
        circuit_breaker_timeout: Seconds before attempting recovery
        enable_logging: Enable structured logging for HTTP requests
        enable_tracing: Enable OpenTelemetry tracing (requires tracing extra)
        tracing_service_name: Service name for tracing spans
        propagate_trace_context: Send W3C traceparent/tracestate headers
        send_correlation_id: Send X-Correlation-ID header with requests
        send_request_id: Send X-Request-ID header with requests
    """

    api_key: str
    base_url: str = "https://api.aionvision.tech/api/v2"
    timeout: float = 300.0
    max_retries: int = 3
    retry_delay: float = 1.0
    polling_interval: float = 2.0
    polling_timeout: float = 360.0
    tenant_id: Optional[str] = field(
        default_factory=lambda: os.environ.get(ENV_TENANT_ID)
    )
    proxy_url: Optional[str] = field(
        default_factory=lambda: os.environ.get(ENV_PROXY_URL)
    )
    circuit_breaker_enabled: bool = True
    circuit_breaker_failure_threshold: int = 5
    circuit_breaker_success_threshold: int = 2
    circuit_breaker_timeout: float = 30.0
    enable_logging: bool = True
    # Tracing configuration
    enable_tracing: bool = False
    tracing_service_name: str = "aionvision-sdk"
    propagate_trace_context: bool = True
    send_correlation_id: bool = True
    send_request_id: bool = True

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        if not self.api_key:
            raise ValueError("API key is required")
        if not API_KEY_PATTERN.match(self.api_key):
            raise ValueError(
                "Invalid API key format. API key should be in format '<prefix>_<key>' "
                "(e.g., 'aion_AbCd1234...'). Minimum 20 characters after prefix."
            )
        if self.timeout <= 0:
            raise ValueError("Timeout must be positive")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if self.polling_interval <= 0:
            raise ValueError("polling_interval must be positive")
        if self.polling_timeout <= 0:
            raise ValueError("polling_timeout must be positive")
        if self.retry_delay <= 0:
            raise ValueError("retry_delay must be positive")

        # HTTPS enforcement for API security
        self._validate_base_url_security()

        # Validate proxy URL if provided
        if self.proxy_url:
            self._validate_proxy_url()

        # Validate circuit breaker settings
        if self.circuit_breaker_failure_threshold < 1:
            raise ValueError("circuit_breaker_failure_threshold must be at least 1")
        if self.circuit_breaker_success_threshold < 1:
            raise ValueError("circuit_breaker_success_threshold must be at least 1")
        if self.circuit_breaker_timeout <= 0:
            raise ValueError("circuit_breaker_timeout must be positive")

        # Validate tracing configuration
        if self.enable_tracing:
            from ._tracing import is_tracing_available

            if not is_tracing_available():
                warnings.warn(
                    "enable_tracing=True but OpenTelemetry tracing is not available "
                    "in this release. See https://aionvision.tech/docs for the full SDK.",
                    UserWarning,
                    stacklevel=4,
                )

    def _validate_base_url_security(self) -> None:
        """Validate that base_url uses HTTPS for secure API communication."""
        if self.base_url.startswith("https://"):
            return  # Secure - all good

        if self.base_url.startswith("http://"):
            # Allow localhost for local development only
            if self._is_localhost_url(self.base_url):
                warnings.warn(
                    "Using insecure HTTP for localhost development. "
                    "Never use HTTP in production - your API key would be exposed in plaintext. "
                    "Always use HTTPS for production deployments.",
                    InsecureTransportWarning,
                    stacklevel=4
                )
                return
            else:
                raise ValueError(
                    "base_url must use HTTPS for security. "
                    "Using HTTP would expose your API key in plaintext over the network. "
                    f"Got: {self.base_url}\n"
                    "Use https:// instead, or http://localhost for local development only."
                )
        else:
            raise ValueError(
                f"base_url must start with https:// (or http://localhost for development). "
                f"Got: {self.base_url}"
            )

    def _is_localhost_url(self, url: str) -> bool:
        """Check if URL points to localhost (for development exception)."""
        try:
            parsed = urlparse(url)
            host = (parsed.hostname or "").lower()
            return host in ("localhost", "127.0.0.1", "::1") or host.startswith("127.")
        except Exception:
            return False

    def _validate_proxy_url(self) -> None:
        """Validate proxy URL format and scheme."""
        if not self.proxy_url:
            return
        try:
            parsed = urlparse(self.proxy_url)
            if parsed.scheme not in ("http", "https"):
                raise ValueError(
                    f"Invalid proxy URL scheme: '{parsed.scheme}'. "
                    "Supported schemes: http, https"
                )
            if not parsed.hostname:
                raise ValueError("Proxy URL must include a hostname")
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Invalid proxy URL format: {e}")

    @property
    def auth_header(self) -> dict[str, str]:
        """Get the authorization header for API requests."""
        return {"Authorization": f"Bearer {self.api_key}"}

    @property
    def default_headers(self) -> dict[str, str]:
        """Get default headers including authorization and tenant ID."""
        headers = {"Authorization": f"Bearer {self.api_key}"}
        if self.tenant_id:
            headers["X-Tenant-ID"] = self.tenant_id
        return headers

    @classmethod
    def from_env(
        cls,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_delay: Optional[float] = None,
        polling_interval: Optional[float] = None,
        polling_timeout: Optional[float] = None,
        tenant_id: Optional[str] = None,
        proxy_url: Optional[str] = None,
        enable_tracing: Optional[bool] = None,
        **kwargs,
    ) -> ClientConfig:
        """
        Create configuration from environment variables with optional overrides.

        Environment variables:
            AIONVISION_API_KEY: API key (required if not provided)
            AIONVISION_BASE_URL: Base URL (optional)
            AIONVISION_TIMEOUT: Request timeout in seconds (optional)
            AIONVISION_MAX_RETRIES: Maximum retry attempts (optional)
            AIONVISION_RETRY_DELAY: Initial retry delay in seconds (optional)
            AIONVISION_POLLING_INTERVAL: Polling interval in seconds (optional)
            AIONVISION_POLLING_TIMEOUT: Polling timeout in seconds (optional)
            AIONVISION_TENANT_ID: Tenant ID for multi-tenant (optional)
            AIONVISION_PROXY_URL: Proxy URL (optional)
            AIONVISION_ENABLE_TRACING: Enable OpenTelemetry tracing (optional)

        Args:
            api_key: Override for API key
            base_url: Override for base URL
            timeout: Override for timeout
            max_retries: Override for max retries
            retry_delay: Override for retry delay
            polling_interval: Override for polling interval
            polling_timeout: Override for polling timeout
            tenant_id: Override for tenant ID
            proxy_url: Override for proxy URL
            enable_tracing: Override for enable_tracing
            **kwargs: Additional configuration options

        Returns:
            ClientConfig instance

        Raises:
            ValueError: If API key not provided and not in environment
        """
        # API key: explicit > env > error
        resolved_api_key = api_key or os.environ.get(ENV_API_KEY)
        if not resolved_api_key:
            raise ValueError(
                f"API key required. Provide api_key parameter or set {ENV_API_KEY} "
                "environment variable."
            )

        # Build config with explicit values overriding env vars
        return cls(
            api_key=resolved_api_key,
            base_url=base_url or os.environ.get(ENV_BASE_URL, "https://api.aionvision.tech/api/v2"),
            timeout=timeout if timeout is not None else _get_env_float(ENV_TIMEOUT, 300.0),
            max_retries=max_retries if max_retries is not None else _get_env_int(ENV_MAX_RETRIES, 3),
            retry_delay=retry_delay if retry_delay is not None else _get_env_float(ENV_RETRY_DELAY, 1.0),
            polling_interval=polling_interval if polling_interval is not None else _get_env_float(ENV_POLLING_INTERVAL, 2.0),
            polling_timeout=polling_timeout if polling_timeout is not None else _get_env_float(ENV_POLLING_TIMEOUT, 360.0),
            tenant_id=tenant_id or os.environ.get(ENV_TENANT_ID),
            proxy_url=proxy_url or os.environ.get(ENV_PROXY_URL),
            enable_tracing=enable_tracing if enable_tracing is not None else _get_env_bool(ENV_ENABLE_TRACING, False),
            **kwargs,
        )
