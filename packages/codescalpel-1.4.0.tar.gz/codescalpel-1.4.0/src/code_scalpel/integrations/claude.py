"""Claude API integration for Code Scalpel."""
