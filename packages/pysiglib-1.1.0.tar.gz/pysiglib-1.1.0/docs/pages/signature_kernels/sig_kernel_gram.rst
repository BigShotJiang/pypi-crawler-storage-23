pysiglib.sig_kernel_gram
==========================

.. versionadded:: v0.2.1

.. autofunction:: pysiglib.sig_kernel_gram