pysiglib.expected_sig_score
===============================

.. versionadded:: v0.2.1

.. autofunction:: pysiglib.expected_sig_score