Log sig functions
===================

set_cache_dir
---------------

.. doxygenfunction:: set_cache_dir

prepare_log_sig
-----------------

.. doxygenfunction:: prepare_log_sig

clear_cache
---------------

.. doxygenfunction:: clear_cache

sig_to_log_sig
---------------

.. doxygengroup:: sig_to_log_sig_functions
   :content-only:

batch_sig_to_log_sig
----------------------

.. doxygengroup:: batch_sig_to_log_sig_functions
   :content-only:

sig_to_log_sig_backprop
-------------------------

.. doxygengroup:: sig_to_log_sig_backprop_functions
   :content-only:

batch_sig_to_log_sig_backprop
-------------------------------

.. doxygengroup:: batch_sig_to_log_sig_backprop_functions
   :content-only:
