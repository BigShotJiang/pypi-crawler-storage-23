Sig length functions
=====================

sig_length
-----------

.. doxygenfunction:: sig_length

log_sig_length
---------------

.. doxygenfunction:: log_sig_length
