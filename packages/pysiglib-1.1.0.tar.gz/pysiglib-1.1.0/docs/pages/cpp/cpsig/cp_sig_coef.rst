Sig coef functions
===================

sig_coef
----------

.. doxygengroup:: sig_coef_functions
   :content-only:

batch_sig_coef
----------------

.. doxygengroup:: batch_sig_coef_functions
   :content-only:

sig_coef_backprop
------------------

.. doxygengroup:: sig_coef_backprop_functions
   :content-only:

batch_sig_coef_backprop
------------------------

.. doxygengroup:: batch_sig_coef_backprop_functions
   :content-only:
