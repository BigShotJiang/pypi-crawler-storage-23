cuSIG
========================

Brief documentation for the ``cuSIG`` C++ library. We omit details
of the mathematical operations, for which we refer the user to the corresponding python documentation.

.. toctree::
   :titlesonly:

   cusig/cu_transform_path
   cusig/cu_sig_kernel
