pysiglib.sig_to_log_sig
=========================

.. versionadded:: v1.0.0

.. autofunction:: pysiglib.sig_to_log_sig
