pysiglib.prepare_log_sig
=========================

.. versionadded:: v1.0.0

.. autofunction:: pysiglib.prepare_log_sig
