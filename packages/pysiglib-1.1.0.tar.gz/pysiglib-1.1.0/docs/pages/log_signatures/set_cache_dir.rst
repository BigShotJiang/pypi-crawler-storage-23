pysiglib.set_cache_dir
=========================

.. versionadded:: v1.0.0

.. autofunction:: pysiglib.set_cache_dir
