pysiglib.log_sig_length
========================

.. versionadded:: v1.0.0

.. autofunction:: pysiglib.log_sig_length
