pysiglib.log_sig
=========================

.. versionadded:: v1.0.0

.. autofunction:: pysiglib.log_sig
