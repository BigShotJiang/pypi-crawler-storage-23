pysiglib.clear_cache
=========================

.. versionadded:: v1.0.0

.. autofunction:: pysiglib.clear_cache
