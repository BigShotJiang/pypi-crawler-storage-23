pysiglib.sig_length
========================

.. autofunction:: pysiglib.sig_length