pysiglib.sig
========================

.. autofunction:: pysiglib.sig
