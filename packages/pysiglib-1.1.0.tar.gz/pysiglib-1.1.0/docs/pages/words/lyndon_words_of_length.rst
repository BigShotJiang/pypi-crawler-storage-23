pysiglib.lyndon_words_of_length
=================================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.lyndon_words_of_length
