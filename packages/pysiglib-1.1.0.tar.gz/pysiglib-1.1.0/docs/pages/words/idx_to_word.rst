pysiglib.idx_to_word
=====================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.idx_to_word
