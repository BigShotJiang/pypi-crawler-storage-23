pysiglib.word_to_idx
=====================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.word_to_idx
