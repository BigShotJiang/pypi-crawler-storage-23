pysiglib.lyndon_words
=======================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.lyndon_words
