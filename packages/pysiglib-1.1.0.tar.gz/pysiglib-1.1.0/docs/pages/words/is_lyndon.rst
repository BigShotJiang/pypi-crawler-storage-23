pysiglib.is_lyndon
====================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.is_lyndon
