pysiglib.sig_coef
==========================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.sig_coef
