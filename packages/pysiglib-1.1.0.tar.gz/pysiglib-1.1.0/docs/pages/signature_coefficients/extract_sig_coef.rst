pysiglib.extract_sig_coef
==========================

.. versionadded:: v1.1.0

.. autofunction:: pysiglib.extract_sig_coef
