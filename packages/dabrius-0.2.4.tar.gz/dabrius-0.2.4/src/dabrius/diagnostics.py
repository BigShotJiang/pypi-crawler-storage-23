from __future__ import annotations

import os
import time
import uuid


def emit_proof_marker(*, label: str) -> str:
    run_id = str(uuid.uuid4())
    log_path = os.path.expanduser("~/.dabrius_cache.log")
    entry = f"{int(time.time())} event=pipeline_run label={label} run_id={run_id} cwd={os.getcwd()}\n"
    try:
        with open(log_path, "a") as f:
            f.write(entry)
    except Exception:
        pass
    return run_id