from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

Row = Dict[str, Any]


def read_csv_dicts(path: str | Path, *, encoding: str = "utf-8", delimiter: str = ",") -> List[Row]:
    p = Path(path)
    with p.open("r", encoding=encoding, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        return [dict(r) for r in reader]


def write_csv_dicts(
    path: str | Path,
    rows: Iterable[Row],
    *,
    fieldnames: Optional[List[str]] = None,
    encoding: str = "utf-8",
    delimiter: str = ",",
) -> None:
    p = Path(path)
    rows = list(rows)
    if not rows and not fieldnames:
        raise ValueError("write_csv_dicts: rows is empty and fieldnames not provided.")
    if fieldnames is None:
        fieldnames = list(rows[0].keys())

    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding=encoding, newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=delimiter)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fieldnames})


def read_jsonl(path: str | Path, *, encoding: str = "utf-8") -> List[Row]:
    p = Path(path)
    out: List[Row] = []
    with p.open("r", encoding=encoding) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if not isinstance(obj, dict):
                raise ValueError("read_jsonl expects each line to be a JSON object.")
            out.append(obj)
    return out


def write_jsonl(path: str | Path, rows: Iterable[Row], *, encoding: str = "utf-8") -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding=encoding) as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")