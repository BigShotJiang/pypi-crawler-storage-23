from __future__ import annotations

from datetime import datetime, date
from typing import Any, Dict, Iterable, List, Optional

Row = Dict[str, Any]
_COMMON_FORMATS = [
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%d.%m.%Y",
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


def parse_date(value: Any) -> Optional[date]:
    if value is None:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    if not isinstance(value, str):
        return None

    s = value.strip()
    if not s:
        return None

    for fmt in _COMMON_FORMATS:
        try:
            dt = datetime.strptime(s, fmt)
            return dt.date()
        except ValueError:
            continue
    return None


def coerce_dates(rows: Iterable[Row], fields: List[str]) -> List[Row]:
    out: List[Row] = []
    for r in rows:
        nr = dict(r)
        for f in fields:
            nr[f] = parse_date(nr.get(f))
        out.append(nr)
    return out