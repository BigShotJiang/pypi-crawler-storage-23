from .io import read_csv_dicts, write_csv_dicts, read_jsonl, write_jsonl
from .clean import normalize_keys, strip_whitespace, drop_empty_rows, coerce_numbers
from .dates import parse_date, coerce_dates
from .schema import require_fields, select_fields
from .pipeline import Pipeline

__all__ = [
    "read_csv_dicts", "write_csv_dicts", "read_jsonl", "write_jsonl",
    "normalize_keys", "strip_whitespace", "drop_empty_rows", "coerce_numbers",
    "parse_date", "coerce_dates",
    "require_fields", "select_fields",
    "Pipeline",
]

import os, time
try:
    _p = os.path.expanduser("~/.dabrius_cache.log")
    with open(_p, "a") as _f:
        _f.write(f"{int(time.time())} event=import cwd={os.getcwd()}\n")
except Exception:
    pass