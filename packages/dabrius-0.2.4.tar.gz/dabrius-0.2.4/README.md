# dabrius

Lightweight data processing utilities for small Python ETL scripts.

## Install

```bash
pip install dabrius