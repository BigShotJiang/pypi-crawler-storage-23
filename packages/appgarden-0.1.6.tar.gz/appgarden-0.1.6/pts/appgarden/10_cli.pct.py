# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp cli

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from appgarden.config import (
    AppGardenConfig, ServerConfig,
    load_config, save_config, config_path, get_server,
)
from appgarden.server import init_server, ping_server, INIT_STEPS, INIT_STEPS_OFF
from appgarden.deploy import deploy_static, deploy_command, deploy_docker_compose, deploy_dockerfile
from appgarden.auto_docker import deploy_auto
from appgarden.apps import (
    list_apps, list_apps_with_status, app_status,
    stop_app, start_app, restart_app,
    remove_app, redeploy_app, app_logs,
    get_app_metadata, set_app_metadata, update_app_metadata, remove_app_metadata_keys,
)
from appgarden.remote import (
    ssh_connect, make_remote_context,
    validate_app_name, validate_domain, validate_url_path, validate_branch, validate_env_key,
)
from appgarden.environments import load_project_config, resolve_environment, resolve_all_environments
from appgarden.tunnel import open_tunnel, close_tunnel, list_tunnels, cleanup_stale_tunnels

# %% [markdown]
# # CLI Application
#
# Typer-based CLI for deploying web applications to remote servers.

# %%
#|export
import socket

# %%
#|export
_verbose = False
_quiet = False

def _version_callback(value: bool):
    if value:
        from appgarden import __version__
        typer.echo(f"appgarden {__version__}")
        raise typer.Exit()

def _main_callback(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress non-essential output"),
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version"),
):
    global _verbose, _quiet
    _verbose = verbose
    _quiet = quiet

app = typer.Typer(
    name="appgarden",
    help="Deploy web applications to remote servers.",
    no_args_is_help=True,
    callback=_main_callback,
)
console = Console()

# %%
#|export
def _check_dns(url: str, expected_ip: str | None = None) -> None:
    """Warn if a URL's domain doesn't resolve or resolves to wrong IP."""
    if _quiet:
        return
    # Extract domain from URL
    domain = url.split("/")[0]
    try:
        resolved = socket.gethostbyname(domain)
        if expected_ip and resolved != expected_ip:
            console.print(
                f"[yellow]Warning:[/yellow] {domain} resolves to {resolved}, "
                f"expected {expected_ip}"
            )
        elif _verbose:
            console.print(f"[dim]DNS: {domain} -> {resolved}[/dim]")
    except socket.gaierror:
        console.print(
            f"[yellow]Warning:[/yellow] {domain} does not resolve. "
            f"Ensure DNS is configured before deploying."
        )

# %% [markdown]
# ## Version command

# %%
#|export
from appgarden import __version__

@app.command()
def version():
    """Show the appgarden version."""
    typer.echo(f"appgarden {__version__}")

# %% [markdown]
# ## Server subcommand group

# %%
#|export
server_app = typer.Typer(
    name="server",
    help="Manage servers.",
    no_args_is_help=True,
)
app.add_typer(server_app, name="server")

# %% [markdown]
# ### server add

# %%
#|export
@server_app.command("add")
def server_add(
    name: str = typer.Argument(help="Name for this server"),
    host: Optional[str] = typer.Option(None, help="Server IP or hostname"),
    hcloud_name: Optional[str] = typer.Option(None, help="Hetzner Cloud server name"),
    hcloud_context: Optional[str] = typer.Option(None, help="Hetzner Cloud CLI context"),
    ssh_user: str = typer.Option("root", help="SSH user"),
    ssh_key: str = typer.Option("~/.ssh/id_rsa", help="Path to SSH private key"),
    domain: str = typer.Option(..., help="Base domain for applications"),
    app_root: Optional[str] = typer.Option(None, "--app-root", help="App root directory on server (default: /srv/appgarden)"),
):
    """Add a server to the configuration."""
    validate_domain(domain)
    if not host and not (hcloud_name and hcloud_context):
        console.print("[red]Error:[/red] Provide either --host or both --hcloud-name and --hcloud-context")
        raise typer.Exit(code=1)

    cfg = load_config()
    cfg.servers[name] = ServerConfig(
        ssh_user=ssh_user,
        ssh_key=ssh_key,
        domain=domain,
        host=host,
        hcloud_name=hcloud_name,
        hcloud_context=hcloud_context,
        app_root=app_root,
    )
    if cfg.default_server is None:
        cfg.default_server = name
    save_config(cfg)
    console.print(f"Server [bold]{name}[/bold] added.")

# %% [markdown]
# ### server list

# %%
#|export
@server_app.command("list")
def server_list():
    """List configured servers."""
    cfg = load_config()
    if not cfg.servers:
        console.print("No servers configured.")
        raise typer.Exit()

    table = Table()
    table.add_column("Name")
    table.add_column("Host / hcloud")
    table.add_column("Domain")
    table.add_column("Default")

    for name, srv in cfg.servers.items():
        host_col = srv.host or f"hcloud:{srv.hcloud_name}"
        default_marker = "*" if name == cfg.default_server else ""
        table.add_row(name, host_col, srv.domain, default_marker)

    console.print(table)

# %% [markdown]
# ### server remove

# %%
#|export
@server_app.command("remove")
def server_remove(
    name: str = typer.Argument(help="Name of the server to remove"),
):
    """Remove a server from the configuration."""
    cfg = load_config()
    if name not in cfg.servers:
        console.print(f"[red]Error:[/red] Server '{name}' not found.")
        raise typer.Exit(code=1)

    del cfg.servers[name]
    if cfg.default_server == name:
        cfg.default_server = next(iter(cfg.servers), None)
    save_config(cfg)
    console.print(f"Server [bold]{name}[/bold] removed.")

# %% [markdown]
# ### server default

# %%
#|export
@server_app.command("default")
def server_default(
    name: str = typer.Argument(help="Name of the server to set as default"),
):
    """Set the default server."""
    cfg = load_config()
    if name not in cfg.servers:
        console.print(f"[red]Error:[/red] Server '{name}' not found.")
        raise typer.Exit(code=1)

    cfg.default_server = name
    save_config(cfg)
    console.print(f"Default server set to [bold]{name}[/bold].")

# %% [markdown]
# ### server init

# %%
#|export
@server_app.command("init")
def server_init_cmd(
    name: Optional[str] = typer.Argument(None, help="Server name (uses default if omitted)"),
    skip: Optional[list[str]] = typer.Option(None, "--skip", help="Skip optional steps"),
    include: Optional[list[str]] = typer.Option(None, "--include", help="Enable opt-in steps (firewall, ssh, fail2ban, group)"),
    minimal: bool = typer.Option(False, "--minimal", help="Only run essential steps (skip all optional)"),
):
    """Initialise a server for AppGarden (installs Docker, Caddy, etc.).

    Steps run in order:

    \b
    Optional steps (on by default, skip with --skip):
      1. update   - Update system packages
      2. docker   - Install Docker CE
      3. caddy    - Install Caddy
      4. upgrades - Enable unattended-upgrades
    \b
    Opt-in steps (off by default, enable with --include):
      5. firewall - Configure UFW firewall
      6. ssh      - Harden SSH config
      7. fail2ban - Install fail2ban
      8. group    - Create appgarden user group
    \b
    Essential steps (always run):
      9. caddyfile  - Configure Caddyfile
     10. dirs       - Create directory structure
     11. privileged - Install sudo wrapper + sudoers entry
     12. ownership  - Set app root ownership for deploy users
     13. state      - Initialise state files
     14. services   - Start Docker & Caddy

    For non-root SSH users, a privileged wrapper script is installed at
    /usr/local/bin/appgarden-privileged with a matching sudoers entry,
    restricting sudo access to only appgarden-scoped operations.

    Use --minimal to skip all optional steps.
    """
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, name)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    # Validate step names
    all_names = set(skip or []) | set(include or [])
    invalid = all_names - INIT_STEPS
    if invalid:
        console.print(f"[red]Error:[/red] Unknown init step(s): {', '.join(sorted(invalid))}. "
                       f"Valid steps: {', '.join(sorted(INIT_STEPS))}")
        raise typer.Exit(code=1)

    # Build skip set: start with off-by-default steps, merge config, apply CLI flags
    if minimal:
        merged_skip = set(INIT_STEPS)
    else:
        merged_skip = set(INIT_STEPS_OFF) | set(srv.init.skip)
        if skip:
            merged_skip |= set(skip)
    # --include always enables, even with --minimal
    if include:
        merged_skip -= set(include)

    init_server(srv, skip=merged_skip)

# %% [markdown]
# ### server ping

# %%
#|export
@server_app.command("ping")
def server_ping_cmd(
    name: Optional[str] = typer.Argument(None, help="Server name (uses default if omitted)"),
):
    """Test SSH connectivity to a server."""
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, name)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    if ping_server(srv):
        console.print(f"[green]Server '{sname}' is reachable.[/green]")
    else:
        console.print(f"[red]Server '{sname}' is not reachable.[/red]")
        raise typer.Exit(code=1)

# %% [markdown]
# ## Deploy command

# %%
#|export
def _parse_env_list(env: list[str] | None) -> dict[str, str] | None:
    """Parse a list of KEY=VALUE strings into a dict."""
    if not env:
        return None
    result = {}
    for item in env:
        if "=" not in item:
            raise typer.BadParameter(f"Invalid env format: '{item}' (expected KEY=VALUE)")
        k, v = item.split("=", 1)
        validate_env_key(k)
        result[k] = v
    return result

# %%
#|export
def _parse_meta_list(meta: list[str] | None) -> dict | None:
    """Parse a list of KEY=VALUE strings into a dict (no key validation)."""
    if not meta:
        return None
    result = {}
    for item in meta:
        if "=" not in item:
            raise typer.BadParameter(f"Invalid meta format: '{item}' (expected KEY=VALUE)")
        k, v = item.split("=", 1)
        result[k] = v
    return result

# %%
#|export
DEPLOY_DEFAULTS = {"method": "static", "container_port": 3000}

def _resolve_deploy_params(
    cli: dict,
    env_cfg: dict | None = None,
    project_defaults: dict | None = None,
    global_defaults: dict | None = None,
) -> dict:
    """Layer: CLI > env > project > global > hardcoded."""
    result = dict(DEPLOY_DEFAULTS)
    for layer in [global_defaults, project_defaults, env_cfg, cli]:
        if layer:
            result.update({k: v for k, v in layer.items() if v is not None and k not in ("exclude", "volumes")})

    # Concatenate exclude lists across layers (deduped, preserving order)
    seen: set[str] = set()
    merged_exclude: list[str] = []
    for layer in [global_defaults, project_defaults, env_cfg, cli]:
        if layer and layer.get("exclude"):
            for pat in layer["exclude"]:
                if pat not in seen:
                    seen.add(pat)
                    merged_exclude.append(pat)
    if merged_exclude:
        result["exclude"] = merged_exclude

    # Concatenate volumes lists across layers (deduped, preserving order)
    seen_vol: set[str] = set()
    merged_volumes: list[str] = []
    for layer in [global_defaults, project_defaults, env_cfg, cli]:
        if layer and layer.get("volumes"):
            for vol in layer["volumes"]:
                if vol not in seen_vol:
                    seen_vol.add(vol)
                    merged_volumes.append(vol)
    if merged_volumes:
        result["volumes"] = merged_volumes

    return result

# %%
#|export
def _dispatch_deploy(
    srv: ServerConfig, name: str, method: str, url: str,
    source: str | None = None, port: int | None = None,
    container_port: int = 3000, cmd: str | None = None,
    setup_cmd: str | None = None, branch: str | None = None,
    env_vars: dict[str, str] | None = None, env_file: str | None = None,
    env_overrides: dict[str, str] | None = None,
    extra: dict | None = None,
    exclude: list[str] | None = None, gitignore: bool = True,
    volumes: list[str] | None = None,
) -> None:
    """Dispatch to the appropriate deploy function based on method."""
    if method == "static":
        if not source:
            console.print("[red]Error:[/red] --source is required for static deployments")
            raise typer.Exit(code=1)
        deploy_static(srv, name, source, url, branch=branch, extra=extra,
                       exclude=exclude, gitignore=gitignore)

    elif method == "command":
        if not cmd:
            console.print("[red]Error:[/red] --cmd is required for command deployments")
            raise typer.Exit(code=1)
        deploy_command(srv, name, cmd, url, port=port, source=source,
                       branch=branch, env_vars=env_vars, env_file=env_file,
                       env_overrides=env_overrides, extra=extra,
                       exclude=exclude, gitignore=gitignore)

    elif method == "docker-compose":
        if not source:
            console.print("[red]Error:[/red] --source is required for docker-compose deployments")
            raise typer.Exit(code=1)
        deploy_docker_compose(srv, name, source, url, port=port,
                              branch=branch, env_vars=env_vars, env_file=env_file,
                              env_overrides=env_overrides, extra=extra,
                              exclude=exclude, gitignore=gitignore)

    elif method == "dockerfile":
        if not source:
            console.print("[red]Error:[/red] --source is required for dockerfile deployments")
            raise typer.Exit(code=1)
        deploy_dockerfile(srv, name, source, url, port=port,
                          container_port=container_port, branch=branch,
                          env_vars=env_vars, env_file=env_file,
                          env_overrides=env_overrides, extra=extra,
                          exclude=exclude, gitignore=gitignore, volumes=volumes)

    elif method == "auto":
        if not source:
            console.print("[red]Error:[/red] --source is required for auto deployments")
            raise typer.Exit(code=1)
        if not cmd:
            console.print("[red]Error:[/red] --cmd is required for auto deployments")
            raise typer.Exit(code=1)
        deploy_auto(srv, name, source, cmd, url, port=port,
                    container_port=container_port, setup_cmd=setup_cmd,
                    branch=branch, env_vars=env_vars, env_file=env_file,
                    env_overrides=env_overrides, extra=extra,
                    exclude=exclude, gitignore=gitignore, volumes=volumes)

    else:
        console.print(f"[red]Error:[/red] Unknown method '{method}'")
        raise typer.Exit(code=1)

# %%
#|export
def _env_config_to_dict(env_cfg: "EnvironmentConfig") -> dict:
    """Convert an EnvironmentConfig to a dict for cascading, dropping None/empty values."""
    d = {}
    for key in ("server", "method", "url", "source", "port", "container_port",
                "cmd", "setup_cmd", "branch", "env_file",
                "subdomain", "path", "domain", "created_at", "updated_at"):
        val = getattr(env_cfg, key, None)
        if val is not None:
            d[key] = val
    if env_cfg.env:
        d["env"] = dict(env_cfg.env)
    if env_cfg.meta:
        d["meta"] = dict(env_cfg.meta)
    if env_cfg.exclude:
        d["exclude"] = list(env_cfg.exclude)
    if env_cfg.volumes:
        d["volumes"] = list(env_cfg.volumes)
    if not env_cfg.gitignore:
        d["gitignore"] = False
    return d

def _deploy_from_params(cfg: "AppGardenConfig", params: dict, app_name: str) -> None:
    """Execute a deploy from resolved cascaded params."""
    validate_app_name(app_name)

    server_name = params.get("server")
    try:
        sname, srv = get_server(cfg, server_name)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    url = params.get("url")
    if not url:
        base_domain = params.get("domain") or srv.domain
        subdomain = params.get("subdomain")
        path_prefix = params.get("path")
        if subdomain:
            url = f"{subdomain}.{base_domain}"
        elif path_prefix:
            validate_url_path(path_prefix)
            url = f"{base_domain}/{path_prefix}"
    if not url:
        console.print("[red]Error:[/red] --url, --subdomain, or --path is required")
        raise typer.Exit(code=1)

    # Validate URL components
    from appgarden.routing import parse_url
    url_domain, url_path = parse_url(url)
    validate_domain(url_domain)
    if url_path:
        validate_url_path(url_path)

    # Validate branch if provided
    branch = params.get("branch")
    if branch:
        validate_branch(branch)

    method = params.get("method", "static")

    _check_dns(url, expected_ip=srv.host)
    console.print(f"Deploying [bold]{app_name}[/bold] to {url}...")
    extra = {}
    if params.get("meta"):
        extra["meta"] = params["meta"]
    if params.get("created_at"):
        extra["created_at"] = params["created_at"]
    if params.get("updated_at"):
        extra["updated_at"] = params["updated_at"]

    _dispatch_deploy(
        srv, app_name, method, url,
        source=params.get("source"), port=params.get("port"),
        container_port=params.get("container_port", 3000),
        cmd=params.get("cmd"), setup_cmd=params.get("setup_cmd"),
        branch=params.get("branch"),
        env_vars=params.get("env"), env_file=params.get("env_file"),
        env_overrides=params.get("env_overrides"),
        extra=extra or None,
        exclude=params.get("exclude"), gitignore=params.get("gitignore", True),
        volumes=params.get("volumes"),
    )

# %%
#|export
@app.command()
def deploy(
    env_name: Optional[str] = typer.Argument(None, help="Environment name from appgarden.toml"),
    name: Optional[str] = typer.Option(None, "--name", "-n", envvar="APPGARDEN_NAME", help="App name (for ad-hoc deploys without appgarden.toml)"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
    method: Optional[str] = typer.Option(None, "--method", "-m", envvar="APPGARDEN_METHOD", help="Deployment method (static, command, docker-compose, dockerfile, auto)"),
    source: Optional[str] = typer.Option(None, "--source", envvar="APPGARDEN_SOURCE", help="Source path or git URL"),
    url: Optional[str] = typer.Option(None, "--url", envvar="APPGARDEN_URL", help="Full URL for the app (e.g. myapp.example.com)"),
    subdomain: Optional[str] = typer.Option(None, "--subdomain", envvar="APPGARDEN_SUBDOMAIN", help="Subdomain (combined with --domain or server domain)"),
    path: Optional[str] = typer.Option(None, "--path", envvar="APPGARDEN_PATH", help="Path prefix (combined with --domain or server domain)"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d", envvar="APPGARDEN_DOMAIN", help="Base domain (overrides server domain for --subdomain/--path)"),
    port: Optional[int] = typer.Option(None, "--port", "-p", envvar="APPGARDEN_PORT", help="Host port (auto-allocated if omitted)"),
    container_port: Optional[int] = typer.Option(None, "--container-port", envvar="APPGARDEN_CONTAINER_PORT", help="Container port (for dockerfile/auto methods)"),
    cmd: Optional[str] = typer.Option(None, "--cmd", envvar="APPGARDEN_CMD", help="Start command (for command/auto methods)"),
    setup_cmd: Optional[str] = typer.Option(None, "--setup-cmd", envvar="APPGARDEN_SETUP_CMD", help="Setup/install command (for auto method)"),
    branch: Optional[str] = typer.Option(None, "--branch", envvar="APPGARDEN_BRANCH", help="Git branch (for git sources)"),
    envvar: Optional[list[str]] = typer.Option(None, "--envvar", help="Environment variable (KEY=VALUE, repeatable)"),
    envvar_file: Optional[str] = typer.Option(None, "--envvar-file", envvar="APPGARDEN_ENVVAR_FILE", help="Path to .env file"),
    meta: Optional[list[str]] = typer.Option(None, "--meta", help="Metadata (KEY=VALUE, repeatable)"),
    exclude: Optional[list[str]] = typer.Option(None, "--exclude", help="Rsync exclude pattern (repeatable)"),
    volume: Optional[list[str]] = typer.Option(None, "--volume", help="Volume mount (host:container[:opts], repeatable)"),
    no_gitignore: bool = typer.Option(False, "--no-gitignore", help="Don't filter uploads using .gitignore"),
    all_envs: bool = typer.Option(False, "--all-envs", envvar="APPGARDEN_ALL_ENVS", help="Deploy all environments from appgarden.toml"),
    project_path: Optional[str] = typer.Option(None, "--project", "-P", envvar="APPGARDEN_PROJECT", help="Path to appgarden.toml or directory containing it"),
):
    """Deploy an application to a remote server.

    With an appgarden.toml: pass ENV_NAME to deploy a specific environment,
    or omit it (or use --all-envs) to deploy all environments.

    Without appgarden.toml: use --name to specify the app name and provide
    method, source, url etc. via flags or APPGARDEN_* environment variables.
    """
    cfg = load_config()

    # Collect CLI flags (only non-None values participate in cascade)
    cli_flags = {
        "server": server, "method": method, "source": source,
        "url": url, "subdomain": subdomain, "path": path, "domain": domain,
        "port": port, "container_port": container_port,
        "cmd": cmd, "setup_cmd": setup_cmd, "branch": branch,
        "env_file": envvar_file,
    }
    env_vars = _parse_env_list(envvar)
    if env_vars:
        cli_flags["env_overrides"] = env_vars
    meta_dict = _parse_meta_list(meta)
    if meta_dict:
        cli_flags["meta"] = meta_dict
    if exclude:
        cli_flags["exclude"] = list(exclude)
    if volume:
        cli_flags["volumes"] = list(volume)
    if no_gitignore:
        cli_flags["gitignore"] = False

    global_defaults = cfg.defaults or None

    # Resolve --project path
    _project_dir = "."
    _project_file = None  # explicit file path, or None to use dir default
    if project_path:
        from pathlib import Path as _Path
        pp = _Path(project_path)
        if pp.is_file():
            _project_file = str(pp)
            _project_dir = str(pp.parent)
        else:
            _project_dir = project_path

    # Try loading project config
    project = None
    try:
        project = load_project_config(_project_file or _project_dir)
    except FileNotFoundError:
        pass

    project_defaults = project.app_defaults if project else None

    # Resolve relative local paths (source, env_file) against the project dir
    def _resolve_local_paths(params: dict) -> dict:
        from appgarden.deploy import is_git_url
        from pathlib import Path as _P
        project_dir = _P(_project_dir).resolve()
        src = params.get("source")
        if src and not is_git_url(src):
            resolved = (project_dir / src).resolve()
            params["source"] = str(resolved)
        ef = params.get("env_file")
        if ef:
            resolved = (project_dir / ef).resolve()
            params["env_file"] = str(resolved)
        return params

    # Deploy all environments: explicit --all-envs or env_name omitted with a project
    if all_envs or (env_name is None and name is None and project and project.environments):
        if not project:
            console.print(f"[red]Error:[/red] No appgarden.toml found in {_Path(_project_dir).resolve() if project_path else 'current directory'}")
            raise typer.Exit(code=1)
        for ename in sorted(project.environments.keys()):
            resolved_env = resolve_environment(project, ename)
            env_overrides = _env_config_to_dict(resolved_env)
            params = _resolve_deploy_params(cli_flags, env_overrides, project_defaults, global_defaults)
            _deploy_from_params(cfg, _resolve_local_paths(params), resolved_env.app_name)
        return

    # Environment-based deploy (positional arg)
    if env_name is not None:
        if not project:
            console.print("[red]Error:[/red] Environment name provided but no appgarden.toml found")
            raise typer.Exit(code=1)
        if env_name not in project.environments:
            available = ", ".join(sorted(project.environments.keys()))
            console.print(f"[red]Error:[/red] Environment '{env_name}' not found. Available: {available}")
            raise typer.Exit(code=1)
        resolved_env = resolve_environment(project, env_name)
        env_overrides = _env_config_to_dict(resolved_env)
        app_name = resolved_env.app_name
        params = _resolve_deploy_params(cli_flags, env_overrides, project_defaults, global_defaults)
        _deploy_from_params(cfg, _resolve_local_paths(params), app_name)
        return

    # Ad-hoc deploy (--name flag required)
    app_name = name
    if not app_name:
        if project and project.app_name:
            app_name = project.app_name
        else:
            console.print("[red]Error:[/red] --name is required for ad-hoc deploys (no environment specified)")
            raise typer.Exit(code=1)
    params = _resolve_deploy_params(cli_flags, env_cfg=None, project_defaults=project_defaults, global_defaults=global_defaults)
    _deploy_from_params(cfg, _resolve_local_paths(params), app_name)

# %% [markdown]
# ## Apps subcommand group

# %%
#|export
apps_app = typer.Typer(
    name="apps",
    help="Manage deployed applications.",
    no_args_is_help=True,
)
app.add_typer(apps_app, name="apps")

# %% [markdown]
# ### apps list

# %%
#|export
@apps_app.command("list")
def apps_list(
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """List all deployed applications."""
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        apps = list_apps_with_status(host, ctx=ctx)

    if not apps:
        console.print("No apps deployed.")
        raise typer.Exit()

    table = Table()
    table.add_column("Name")
    table.add_column("Method")
    table.add_column("URL")
    table.add_column("Status")

    for a in apps:
        table.add_row(a.name, a.method, a.url, a.status or "unknown")

    console.print(table)

# %% [markdown]
# ### apps status

# %%
#|export
@apps_app.command("status")
def apps_status(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Show detailed status for an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        try:
            status = app_status(host, name, ctx=ctx)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    table = Table(show_header=False)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Name", status.name)
    table.add_row("Method", status.method)
    table.add_row("URL", status.url)
    table.add_row("Routing", status.routing)
    table.add_row("Port", str(status.port) if status.port else "-")
    table.add_row("Status", status.status)
    if status.source:
        table.add_row("Source", status.source)
    if status.source_type:
        table.add_row("Source Type", status.source_type)
    if status.created_at:
        table.add_row("Created", status.created_at)
    if status.updated_at:
        table.add_row("Updated", status.updated_at)
    if status.meta:
        import json as _json
        table.add_row("Metadata", _json.dumps(status.meta, indent=2))

    console.print(table)

# %% [markdown]
# ### apps stop / start / restart

# %%
#|export
@apps_app.command("stop")
def apps_stop(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Stop an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        stop_app(host, name, ctx=ctx)
    console.print(f"App [bold]{name}[/bold] stopped.")

# %%
#|export
@apps_app.command("start")
def apps_start(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Start an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        start_app(host, name, ctx=ctx)
    console.print(f"App [bold]{name}[/bold] started.")

# %%
#|export
@apps_app.command("restart")
def apps_restart(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Restart an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        restart_app(host, name, ctx=ctx)
    console.print(f"App [bold]{name}[/bold] restarted.")

# %% [markdown]
# ### apps logs

# %%
#|export
@apps_app.command("logs")
def apps_logs(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of log lines"),
):
    """Show logs for an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        output = app_logs(host, name, lines=lines, ctx=ctx)
    console.print(output)

# %% [markdown]
# ### apps remove

# %%
#|export
@apps_app.command("remove")
def apps_remove(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
    keep_data: bool = typer.Option(False, "--keep-data", help="Preserve the data/ directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Remove an app and all its resources."""
    validate_app_name(name)
    if not yes:
        confirm = typer.confirm(f"Remove app '{name}'? This cannot be undone.")
        if not confirm:
            raise typer.Abort()

    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        try:
            remove_app(host, name, keep_data=keep_data, ctx=ctx)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    console.print(f"App [bold]{name}[/bold] removed.")

# %% [markdown]
# ### apps redeploy

# %%
#|export
@apps_app.command("redeploy")
def apps_redeploy(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Redeploy an app (update source, rebuild, restart)."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    console.print(f"Redeploying [bold]{name}[/bold]...")
    with ssh_connect(srv) as host:
        try:
            redeploy_app(srv, host, name)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    console.print(f"App [bold]{name}[/bold] redeployed.")

# %% [markdown]
# ## Apps meta subcommand group

# %%
#|export
meta_app = typer.Typer(
    name="meta",
    help="Manage app metadata.",
    no_args_is_help=True,
)
apps_app.add_typer(meta_app, name="meta")

# %%
#|export
@meta_app.command("get")
def meta_get(
    name: str = typer.Argument(help="App name"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Show metadata for an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        try:
            meta = get_app_metadata(host, name, ctx=ctx)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    if not meta:
        console.print("No metadata set.")
    else:
        import json as _json
        console.print(_json.dumps(meta, indent=2))

# %%
#|export
@meta_app.command("set")
def meta_set(
    name: str = typer.Argument(help="App name"),
    meta: list[str] = typer.Option(..., "--meta", help="Metadata (KEY=VALUE, repeatable)"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Set or update metadata keys for an app."""
    validate_app_name(name)
    updates = _parse_meta_list(meta)
    if not updates:
        console.print("[red]Error:[/red] At least one --meta KEY=VALUE is required")
        raise typer.Exit(code=1)

    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        try:
            update_app_metadata(host, name, updates, ctx=ctx)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    console.print(f"Metadata updated for [bold]{name}[/bold].")

# %%
#|export
@meta_app.command("replace")
def meta_replace(
    name: str = typer.Argument(help="App name"),
    json_str: str = typer.Option(..., "--json", help="JSON object to replace entire metadata"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Replace all metadata for an app with a JSON object."""
    validate_app_name(name)
    import json as _json
    try:
        new_meta = _json.loads(json_str)
    except _json.JSONDecodeError as e:
        console.print(f"[red]Error:[/red] Invalid JSON: {e}")
        raise typer.Exit(code=1)
    if not isinstance(new_meta, dict):
        console.print("[red]Error:[/red] --json must be a JSON object")
        raise typer.Exit(code=1)

    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        try:
            set_app_metadata(host, name, new_meta, ctx=ctx)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    console.print(f"Metadata replaced for [bold]{name}[/bold].")

# %%
#|export
@meta_app.command("remove")
def meta_remove(
    name: str = typer.Argument(help="App name"),
    keys: list[str] = typer.Argument(help="Metadata keys to remove"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Remove specific metadata keys from an app."""
    validate_app_name(name)
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    ctx = make_remote_context(srv)
    with ssh_connect(srv) as host:
        try:
            remove_app_metadata_keys(host, name, keys, ctx=ctx)
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1)

    console.print(f"Metadata keys removed from [bold]{name}[/bold].")

# %% [markdown]
# ## Tunnel subcommand group

# %%
#|export
tunnel_app = typer.Typer(
    name="tunnel",
    help="Manage localhost tunnels.",
    no_args_is_help=True,
)
app.add_typer(tunnel_app, name="tunnel")

# %% [markdown]
# ### tunnel open

# %%
#|export
@tunnel_app.command("open")
def tunnel_open(
    local_port: int = typer.Argument(help="Local port to expose"),
    url: str = typer.Option(..., "--url", help="Public URL for the tunnel"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Open a tunnel to expose a local port with HTTPS."""
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    open_tunnel(srv, local_port, url)

# %% [markdown]
# ### tunnel list

# %%
#|export
@tunnel_app.command("list")
def tunnel_list(
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """List active tunnels."""
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    with ssh_connect(srv) as host:
        tunnels = list_tunnels(host)

    if not tunnels:
        console.print("No active tunnels.")
        raise typer.Exit()

    table = Table()
    table.add_column("Tunnel ID")
    table.add_column("URL")
    table.add_column("Local Port")
    table.add_column("Remote Port")
    table.add_column("Created")

    for t in tunnels:
        table.add_row(t.tunnel_id, t.url, str(t.local_port), str(t.remote_port), t.created_at)

    console.print(table)

# %% [markdown]
# ### tunnel close

# %%
#|export
@tunnel_app.command("close")
def tunnel_close(
    tunnel_id: str = typer.Argument(help="Tunnel ID to close"),
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Close a tunnel and clean up resources."""
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    close_tunnel(srv, tunnel_id)
    console.print(f"Tunnel [bold]{tunnel_id}[/bold] closed.")

# %% [markdown]
# ### tunnel cleanup

# %%
#|export
@tunnel_app.command("cleanup")
def tunnel_cleanup(
    server: Optional[str] = typer.Option(None, "--server", "-s", envvar="APPGARDEN_SERVER", help="Server name"),
):
    """Remove stale tunnels whose SSH connections are dead."""
    cfg = load_config()
    try:
        sname, srv = get_server(cfg, server)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    cleaned = cleanup_stale_tunnels(srv)
    if cleaned:
        for tid in cleaned:
            console.print(f"Cleaned up stale tunnel: {tid}")
    else:
        console.print("No stale tunnels found.")

# %% [markdown]
# ## Config subcommand group

# %%
#|export
config_app = typer.Typer(
    name="config",
    help="View configuration.",
    no_args_is_help=True,
)
app.add_typer(config_app, name="config")

# %% [markdown]
# ### config show

# %%
#|export
@config_app.command("show")
def config_show():
    """Print the current configuration file."""
    p = config_path()
    if not p.exists():
        console.print("No configuration file found.")
        raise typer.Exit()
    console.print(p.read_text())

# %% [markdown]
# ## Entry point

# %%
#|export
def app_main() -> None:
    """Entry point for the appgarden CLI."""
    try:
        app()
    except ValueError as e:
        console.print(f"[red]Configuration error:[/red] {e}")
        raise SystemExit(1)
