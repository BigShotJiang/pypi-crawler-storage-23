# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp server

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %% [markdown]
# # Server Management
#
# Initialise a fresh server for AppGarden use and test connectivity.

# %%
#|export
import json
import shlex
from pathlib import Path

from rich.console import Console

from appgarden.config import ServerConfig, resolve_host
from appgarden.ports import empty_ports_state
from appgarden.remote import (
    APPGARDEN_ROOT, GARDEN_STATE_PATH, PORTS_PATH,
    PRIVILEGED_HELPER_PATH,
    RemoteContext, make_remote_context,
    ssh_connect, run_remote_command, write_remote_file,
    run_sudo_command, write_system_file,
    garden_state_path, ports_path,
)

TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

console = Console()

# %% [markdown]
# ## ping_server

# %%
#|export
def ping_server(server: ServerConfig) -> bool:
    """Test SSH connectivity to a server. Returns True if reachable."""
    try:
        with ssh_connect(server) as host:
            run_remote_command(host, "echo ok")
        return True
    except Exception:
        return False

# %% [markdown]
# ## init_server
#
# Prepares a fresh Ubuntu/Debian server:
#
# 1. System updates
# 2. Docker CE + compose plugin
# 3. Caddy web server
# 4. UFW firewall
# 5. SSH hardening
# 6. fail2ban
# 7. unattended-upgrades
# 8. AppGarden directory structure + state files

# %%
#|export
CADDYFILE_TEMPLATE = """\
import {app_root}/caddy/apps/*.caddy
import {app_root}/caddy/tunnels/*.caddy
"""

# Keep for backwards compat in tests
CADDYFILE_CONTENT = CADDYFILE_TEMPLATE.format(app_root=APPGARDEN_ROOT)

CADDYFILE_MARKER_BEGIN = "# BEGIN APPGARDEN MANAGED BLOCK"
CADDYFILE_MARKER_END = "# END APPGARDEN MANAGED BLOCK"

INIT_STEPS = {"update", "docker", "caddy", "firewall", "ssh", "fail2ban", "upgrades", "group"}
INIT_STEPS_OFF = {"firewall", "ssh", "fail2ban", "group"}

SSH_HARDENING_CONTENT = """\
PasswordAuthentication no
MaxAuthTries 3
X11Forwarding no
"""

# %%
#|export
def _run(host, cmd: str, label: str, ctx: RemoteContext | None = None, timeout: int = 300) -> None:
    """Run a command on the remote, printing a status label. Uses sudo if needed."""
    console.print(f"  [dim]{label}[/dim]")
    run_sudo_command(host, cmd, ctx=ctx, timeout=timeout)

# %%
#|export
def _ensure_caddyfile_block(host, block_content: str, ctx: RemoteContext | None = None) -> None:
    """Add or update the AppGarden managed block in /etc/caddy/Caddyfile.

    If the file doesn't exist or doesn't contain the markers, the block is
    appended.  If the markers already exist, the content between them is
    replaced.  Existing content outside the markers is never modified.
    """
    caddyfile_path = "/etc/caddy/Caddyfile"
    managed_block = f"{CADDYFILE_MARKER_BEGIN}\n{block_content}{CADDYFILE_MARKER_END}\n"

    # Try to read existing Caddyfile
    try:
        current = run_sudo_command(host, f"cat {shlex.quote(caddyfile_path)}", ctx=ctx)
    except RuntimeError:
        # File doesn't exist yet — just write the block
        write_system_file(host, caddyfile_path, managed_block, ctx=ctx)
        return

    if CADDYFILE_MARKER_BEGIN in current:
        # Replace existing block
        before = current[:current.index(CADDYFILE_MARKER_BEGIN)]
        after_marker = current[current.index(CADDYFILE_MARKER_END) + len(CADDYFILE_MARKER_END):]
        # Strip leading newline from after_marker
        if after_marker.startswith("\n"):
            after_marker = after_marker[1:]
        new_content = before + managed_block + after_marker
    else:
        # Append block to end
        new_content = current.rstrip("\n") + "\n\n" + managed_block if current.strip() else managed_block

    write_system_file(host, caddyfile_path, new_content, ctx=ctx)

# %%
#|export
def init_server(server: ServerConfig, *, skip: set[str] | None = None) -> None:
    """Initialise a remote server for AppGarden use.

    Optional steps can be skipped via the ``skip`` parameter.  Valid step
    names are defined in ``INIT_STEPS``: update, docker, caddy, firewall,
    ssh, fail2ban, upgrades.  Essential steps (directory structure, Caddyfile
    block, state files, service starts) always run.
    """
    skip = skip or set()
    ctx = make_remote_context(server)
    console.print(f"[bold]Initialising server[/bold] ({resolve_host(server)})")

    with ssh_connect(server) as host:
        # 1. System updates (optional)
        if "update" not in skip:
            _run(host, "apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get upgrade -y -qq",
                 "Updating system packages", ctx=ctx)

        # 2. Install Docker CE (optional)
        if "docker" not in skip:
            _run(host,
                 "apt-get install -y -qq ca-certificates curl gnupg && "
                 "install -m 0755 -d /etc/apt/keyrings && "
                 ". /etc/os-release && "
                 "curl -fsSL https://download.docker.com/linux/$ID/gpg -o /etc/apt/keyrings/docker.asc && "
                 "chmod a+r /etc/apt/keyrings/docker.asc && "
                 'echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] '
                 'https://download.docker.com/linux/$ID $VERSION_CODENAME stable" '
                 "> /etc/apt/sources.list.d/docker.list && "
                 "apt-get update -qq && "
                 "apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin",
                 "Installing Docker CE", ctx=ctx)

        # 3. Install Caddy (optional)
        if "caddy" not in skip:
            _run(host,
                 "apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https curl && "
                 "curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | "
                 "gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg && "
                 "curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | "
                 "tee /etc/apt/sources.list.d/caddy-stable.list && "
                 "apt-get update -qq && "
                 "apt-get install -y -qq caddy",
                 "Installing Caddy", ctx=ctx)

        # 4. Configure Caddyfile (essential, but additive)
        caddyfile_content = CADDYFILE_TEMPLATE.format(app_root=ctx.app_root)
        _ensure_caddyfile_block(host, caddyfile_content, ctx=ctx)
        console.print("  [dim]Configured Caddyfile[/dim]")

        # 5. UFW firewall (optional)
        if "firewall" not in skip:
            _run(host,
                 "apt-get install -y -qq ufw && "
                 "ufw default deny incoming && "
                 "ufw default allow outgoing && "
                 "ufw allow ssh && "
                 "ufw allow http && "
                 "ufw allow https && "
                 "ufw --force enable",
                 "Configuring firewall (UFW)", ctx=ctx)

        # 6. SSH hardening (optional)
        if "ssh" not in skip:
            write_system_file(host, "/etc/ssh/sshd_config.d/hardening.conf", SSH_HARDENING_CONTENT, ctx=ctx)
            _run(host, "systemctl reload sshd", "Hardening SSH", ctx=ctx)

        # 7. fail2ban (optional)
        if "fail2ban" not in skip:
            _run(host, "apt-get install -y -qq fail2ban && systemctl enable fail2ban && systemctl start fail2ban",
                 "Installing fail2ban", ctx=ctx)

        # 8. unattended-upgrades (optional)
        if "upgrades" not in skip:
            _run(host, "apt-get install -y -qq unattended-upgrades && "
                 "dpkg-reconfigure -f noninteractive unattended-upgrades",
                 "Enabling unattended-upgrades", ctx=ctx)

        # 9. AppGarden directory structure (essential, idempotent)
        app_root = ctx.app_root
        dirs = [
            f"{app_root}/apps",
            f"{app_root}/caddy/apps",
            f"{app_root}/caddy/tunnels",
            f"{app_root}/tunnels",
        ]
        _run(host, f"mkdir -p {' '.join(dirs)}", "Creating directory structure", ctx=ctx)

        # 10. Create appgarden group (optional, opt-in)
        if "group" not in skip:
            _run(host,
                 f"groupadd -f appgarden && "
                 f"chgrp -R appgarden {app_root} && "
                 f"chmod -R g+rwX {app_root} && "
                 f"find {app_root} -type d -exec chmod g+s {{}} +",
                 "Creating appgarden group", ctx=ctx)

        # 10b. Install privileged wrapper and sudoers entry (essential)
        wrapper_src = TEMPLATES_DIR / "appgarden-privileged"
        wrapper_content = wrapper_src.read_text()
        write_system_file(host, PRIVILEGED_HELPER_PATH, wrapper_content, ctx=ctx)
        _run(host, f"chmod 755 {PRIVILEGED_HELPER_PATH} && chown root:root {PRIVILEGED_HELPER_PATH}",
             "Installing privileged wrapper", ctx=ctx)
        sudoers_line = f"%appgarden ALL=(ALL) NOPASSWD: {PRIVILEGED_HELPER_PATH}\n"
        write_system_file(host, "/etc/sudoers.d/appgarden", sudoers_line, ctx=ctx)
        _run(host, "chmod 440 /etc/sudoers.d/appgarden",
             "Configuring sudoers for appgarden", ctx=ctx)

        # 11. Set app root ownership for deploy users (essential)
        if "group" not in skip:
            _run(host, f"chown -R root:appgarden {app_root}",
                 "Setting app root ownership", ctx=ctx)
        elif ctx.needs_sudo:
            _run(host, f"chown -R {server.ssh_user}:{server.ssh_user} {app_root}",
                 "Setting app root ownership", ctx=ctx)
        if ctx.needs_sudo and "docker" not in skip:
            _run(host, f"usermod -aG docker {server.ssh_user}",
                 "Adding user to docker group", ctx=ctx)

        # 11. Initialise state files (essential, but only if missing)
        try:
            run_remote_command(host, f"test -f {shlex.quote(garden_state_path(ctx))}")
            console.print("  [dim]State files already exist, preserving[/dim]")
        except RuntimeError:
            write_remote_file(host, garden_state_path(ctx), json.dumps({"apps": {}}, indent=2))
            write_remote_file(host, ports_path(ctx), json.dumps(empty_ports_state(), indent=2))
            console.print("  [dim]Initialised state files[/dim]")

        # 12. Start Docker (conditional on docker being present)
        try:
            run_sudo_command(host, "command -v docker", ctx=ctx)
            _run(host, "systemctl enable docker && systemctl start docker", "Starting Docker", ctx=ctx)
        except RuntimeError:
            pass

        # 13. Start Caddy (essential)
        _run(host, "systemctl enable caddy && systemctl restart caddy", "Starting Caddy", ctx=ctx)

    console.print("[bold green]Server initialised successfully.[/bold green]")
