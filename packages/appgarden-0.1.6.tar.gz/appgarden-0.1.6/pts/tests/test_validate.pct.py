# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp test_validate

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %% [markdown]
# # Validation Tests
#
# Tests for input validation functions and security hardening.

# %%
#|export
import pytest

from appgarden.remote import (
    validate_app_name,
    validate_domain,
    validate_url_path,
    validate_branch,
    validate_env_key,
)

# %% [markdown]
# ## validate_app_name

# %%
#|export
@pytest.mark.parametrize("name", [
    "myapp", "my-app", "my_app", "my.app", "app123", "A1",
])
def test_validate_app_name_valid(name):
    assert validate_app_name(name) == name

# %%
#|export
@pytest.mark.parametrize("name", [
    "", "-app", ".app", "_app",
    "app;rm -rf /", "app$(whoami)", "app`id`",
    "../etc/passwd", "app\nname", "app name",
    "app{inject}", "app\x00null",
])
def test_validate_app_name_invalid(name):
    with pytest.raises(ValueError, match="Invalid app name"):
        validate_app_name(name)

# %% [markdown]
# ## validate_domain

# %%
#|export
@pytest.mark.parametrize("domain", [
    "example.com", "sub.example.com", "my-app.apps.example.com",
    "localhost", "a.b.c.d.e",
])
def test_validate_domain_valid(domain):
    assert validate_domain(domain) == domain

# %%
#|export
@pytest.mark.parametrize("domain", [
    "", "-bad.com", "bad-.com", ".bad.com",
    "evil.com { import /etc/passwd }",
    "evil.com\n{ respond 200 }",
    "a" * 254,
])
def test_validate_domain_invalid(domain):
    with pytest.raises(ValueError, match="Invalid domain"):
        validate_domain(domain)

# %% [markdown]
# ## validate_url_path

# %%
#|export
@pytest.mark.parametrize("path", [
    "myapp", "my-app", "app123", "my_app",
])
def test_validate_url_path_valid(path):
    assert validate_url_path(path) == path

# %%
#|export
@pytest.mark.parametrize("path", [
    "", "../etc", "a/b", "path;inject",
    "-path", "path with spaces", "path\nnewline",
])
def test_validate_url_path_invalid(path):
    with pytest.raises(ValueError, match="Invalid URL path"):
        validate_url_path(path)

# %% [markdown]
# ## validate_branch

# %%
#|export
@pytest.mark.parametrize("branch", [
    "main", "develop", "feature/my-feature", "v1.0.0",
    "release/2024.01", "fix_bug",
])
def test_validate_branch_valid(branch):
    assert validate_branch(branch) == branch

# %%
#|export
@pytest.mark.parametrize("branch", [
    "", "branch;rm -rf /", "branch$(cmd)", "../../etc",
    "branch name", "branch\n",
])
def test_validate_branch_invalid(branch):
    with pytest.raises(ValueError, match="Invalid branch"):
        validate_branch(branch)

# %% [markdown]
# ## validate_env_key

# %%
#|export
@pytest.mark.parametrize("key", [
    "PORT", "MY_VAR", "_PRIVATE", "a", "A1_B2",
])
def test_validate_env_key_valid(key):
    assert validate_env_key(key) == key

# %%
#|export
@pytest.mark.parametrize("key", [
    "", "1BAD", "MY-VAR", "MY VAR", "KEY;inject",
    "KEY=value", "KEY\n",
])
def test_validate_env_key_invalid(key):
    with pytest.raises(ValueError, match="Invalid env var key"):
        validate_env_key(key)

# %% [markdown]
# ## Env file quoting

# %%
#|export
from unittest.mock import MagicMock, patch, call
from appgarden.deploy import _write_env_file

def test_env_file_quotes_values():
    """Env var values with special chars are properly quoted."""
    host = MagicMock()
    host.put_file.return_value = True
    output_mock = MagicMock()
    output_mock.stdout = ""
    host.run_shell_command.return_value = (True, output_mock)

    _write_env_file(host, "testapp", env_vars={"MY_KEY": "simple", "COMPLEX": 'has "quotes" and $vars'})

    # Check the written content
    put_calls = host.put_file.call_args_list
    written = put_calls[-1].kwargs["filename_or_io"].getvalue().decode()
    assert 'MY_KEY="simple"' in written
    assert 'COMPLEX="has \\"quotes\\" and $vars"' in written

# %% [markdown]
# ## Systemd Environment quoting

# %%
#|export
from appgarden.routing import render_template

def test_systemd_env_quoting():
    """Environment lines in systemd units are quoted."""
    content = render_template(
        "systemd.service.j2",
        name="test",
        method="command",
        working_dir="/srv/appgarden/apps/test",
        env_file=None,
        env_vars={"PORT": "3000", "SECRET": "has spaces"},
        exec_start="node server.js",
        exec_stop=None,
    )
    assert 'Environment="PORT=3000"' in content
    assert 'Environment="SECRET=has spaces"' in content
