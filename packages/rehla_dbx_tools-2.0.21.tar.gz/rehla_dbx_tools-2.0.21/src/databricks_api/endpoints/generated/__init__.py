"""Generated endpoint constants."""
