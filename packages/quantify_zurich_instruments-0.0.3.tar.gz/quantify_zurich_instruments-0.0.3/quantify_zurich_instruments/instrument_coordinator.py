"""Instrument coordinator component for the Zurich Instruments backend."""

import logging
from typing import TYPE_CHECKING

import numpy as np
import xarray as xr
from laboneq.dsl.device.device_setup import DeviceSetup
from laboneq.dsl.session import Session
from qcodes.instrument import InstrumentBase
from quantify.enums import BinMode
from quantify.instrument_coordinator.components.base import (
    InstrumentCoordinatorComponentBase,
)

if TYPE_CHECKING:
    from collections.abc import Hashable


class ZIInstrumentCoordinatorComponent(InstrumentCoordinatorComponentBase):
    """Instrument coordinator component for the Zurich Instruments backend."""

    def __new__(
        cls, device_setup: DeviceSetup, do_emulation: bool = False
    ) -> InstrumentCoordinatorComponentBase:
        """Create a dummy instrument to be compatible with ICCBase.__new__."""
        instrument = InstrumentBase(name=device_setup.uid)
        instance = super().__new__(cls, instrument)
        return instance

    def __init__(self, device_setup: DeviceSetup, do_emulation: bool = False):
        """Initialize LabOneQ session, and create dummy instrument for ZI cluster."""
        # Create a dummy instrument to be compatible with ICCBase.__init__
        instrument = InstrumentBase(name=device_setup.uid)
        super().__init__(instrument)

        self.device_setup = device_setup
        self.session = None
        self.experiment = None
        self.result = None
        self.do_emulation = do_emulation
        self.acquisition_config = None

    def get_hardware_log(self, compiled_schedule):
        """Retrieve the hardware logs of the instrument associated to this component."""
        pass

    @property
    def is_running(self) -> bool:
        """Check if the LabOneQ session is running."""
        return True

    def prepare(self, program: dict) -> None:
        """Prepare the LabOneQ session and experiment."""
        experiment = program["experiment"]

        self.acquisition_config = program["acquisition_config"]

        self.session = Session(device_setup=self.device_setup, log_level=logging.ERROR)
        self.session.connect(do_emulation=self.do_emulation)
        self.experiment = experiment

    def start(self) -> None:
        """Start the LabOneQ experiment."""
        if self.session is None:
            raise RuntimeError("Session is not initialized. Call prepare().")
        self.result = self.session.run(self.experiment)

        if self.result.execution_errors:
            raise Exception(self.result.execution_errors)

    def retrieve_acquisition(self) -> xr.Dataset:
        """Retrieve acquisition results as an xarray Dataset."""
        assert self.result is not None
        assert self.acquisition_config is not None

        acq_channel_results: list[dict[Hashable, xr.DataArray]] = []
        for acq_channel, acq_protocol in self.acquisition_config.acq_protocols.items():
            # Get data arrays
            data = np.array(
                self.result.acquired_results[f"ACQ_CHANNEL_{acq_channel}"].data
            )

            if acq_protocol == "Trace":
                if self.acquisition_config.bin_mode == BinMode.AVERAGE:
                    acq_channel_results.append(
                        {
                            acq_channel: xr.DataArray(
                                # Should be one averaged array
                                data.reshape((1, -1)),
                                dims=(
                                    f"acq_index_{acq_channel}",
                                    f"trace_index_{acq_channel}",
                                ),
                                attrs={"acq_protocol": acq_protocol},
                            )
                        }
                    )
                elif self.acquisition_config.bin_mode == BinMode.APPEND:
                    raise NotImplementedError(
                        "Append mode not yet implemented for the ZI backend"
                    )

            elif acq_protocol in ("SSBIntegrationComplex", "WeightedIntegratedComplex"):
                if self.acquisition_config.bin_mode == BinMode.AVERAGE:
                    acq_channel_results.append(
                        {
                            acq_channel: xr.DataArray(
                                # data size must be equal to n_acquisitions
                                data.reshape((self.acquisition_config.n_acquisitions,)),
                                dims=(f"acq_index_{acq_channel}",),
                                attrs={"acq_protocol": acq_protocol},
                            )
                        }
                    )
                elif self.acquisition_config.bin_mode == BinMode.APPEND:
                    acq_channel_results.append(
                        {
                            acq_channel: xr.DataArray(
                                data.reshape(
                                    (-1, self.acquisition_config.n_acquisitions)
                                ),
                                dims=("repetition", f"acq_index_{acq_channel}"),
                                attrs={"acq_protocol": acq_protocol},
                            )
                        }
                    )
            else:
                raise NotImplementedError(f"{acq_protocol=} not implemented.")

        return xr.merge(acq_channel_results, compat="no_conflicts")

        # TODO: figure out how this should work for different acquisition protocols.
        # In other backends, a separate acq_config is compiled which is then
        # used here to map the results onto the correct xarray Dataset.

    def stop(self) -> None:
        """Stop the LabOneQ session."""
        pass

    def wait_done(self, timeout_sec: int = 10) -> None:
        """Wait until the experiment is done."""
        pass
