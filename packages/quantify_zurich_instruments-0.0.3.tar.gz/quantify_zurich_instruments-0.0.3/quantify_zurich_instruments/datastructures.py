"""Datastructures for the ZI backend."""

from __future__ import annotations

from typing import Literal, Union

from laboneq.core.types.enums.acquisition_type import AcquisitionType  # noqa: TC002
from laboneq.dsl.device.instruments.zi_standard_instrument import (
    ZIStandardInstrument,  # noqa: TC002
)
from pydantic import ConfigDict, Field
from quantify.backends.graph_compilation import (
    SimpleNodeConfig,  # noqa: TC002
)
from quantify.backends.types.common import (
    HardwareCompilationConfig,
    HardwareDescription,
    HardwareOptions,
)
from quantify.enums import BinMode  # noqa: TC002
from quantify.structure.model import DataStructure


class ZIDeviceSetupDescription(HardwareDescription):
    """Specify HardwareDescription for ZIDeviceSetup."""

    # Arbitrary types are required for the ZIStandardInstrument
    model_config = ConfigDict(arbitrary_types_allowed=True)

    instrument_type: str = "ZIDeviceSetup"

    dataserver: tuple[str, str]
    """The IP address and port of the dataserver to connect to."""
    instruments: dict[str, ZIStandardInstrument] = {}
    """The instruments to add to the device setup."""


class ZIHardwareOptions(HardwareOptions):
    """Specify HardwareOptions for ZI backend."""

    output_att: dict[str, int] | None = None
    """
    Dictionary containing the attenuation settings (values) that should be applied
    to the outputs that are connected to a certain port-clock combination (keys).
    """


class ZIHardwareCompilationConfig(HardwareCompilationConfig):
    """Define datastructure to compile to a LabOne Q Experiment."""

    hardware_description: dict[str, ZIDeviceSetupDescription]  # type: ignore
    hardware_options: ZIHardwareOptions  # type: ignore
    compilation_passes: list[SimpleNodeConfig] = Field(  # type: ignore[valid-type]
        default=[
            {
                "name": "flatten_schedule",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".flatten_schedule",
            },
            {
                "name": "initialize_compiled_instructions",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".initialize_compiled_instructions",
            },
            {
                "name": "compile_experiment_signals",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".compile_experiment_signals",
            },
            {
                "name": "compile_operations",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".compile_operations",
            },
            {
                "name": "compile_calibration",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".compile_calibration",
            },
            {
                "name": "compile_acquisition_config",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".compile_acquisition_config",
            },
            {
                "name": "snap_timing_to_system_grid",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".snap_timing_to_system_grid",
            },
            {
                "name": "compile_experiment",
                "compilation_func": "quantify_zurich_instruments.compilation"
                + ".compile_experiment",
            },
        ],
        validate_default=True,
    )


class AcquisitionConfig(DataStructure):
    """Acquisition Config used to format acquired data in the InstrumentCoordinator."""

    bin_mode: Union[BinMode, None]  # noqa: UP007
    # The following acquisition types are supported
    acq_protocols: dict[
        int, Literal["Trace", "SSBIntegrationComplex", "WeightedIntegratedComplex"]
    ]
    n_acquisitions: int
    acquisition_type: AcquisitionType
