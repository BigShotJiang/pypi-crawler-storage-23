"""Zurich Instruments backend for Quantify."""

# Version handling
try:
    from importlib.metadata import version

    __version__ = version("quantify-zurich-instruments")
except Exception:
    __version__ = "unknown"

__all__ = [
    "__version__",
]
