"""
Indy Hub - An industrial management application for Alliance Auth
"""

__title__ = "IndyHub"
__version__ = "1.14.4"
__url__ = "https://github.com/Erkaek/aa-Indy_Hub"
__app_name_ua__ = "aa-Indy_Hub"
__esi_compatibility_date__ = "2025-09-30"
