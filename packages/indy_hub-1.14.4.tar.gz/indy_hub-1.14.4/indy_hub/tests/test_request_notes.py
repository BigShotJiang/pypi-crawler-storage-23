"""Legacy request note tests removed with history timeline."""


def test_placeholder_noop():
    """Maintain module discovery without exercising removed behaviour."""
    pass
