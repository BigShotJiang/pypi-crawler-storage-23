from setuptools import setup, Extension, find_packages
from os import environ
from setuptools.command.build_ext import build_ext
import sys, os, subprocess


class CustomBuildExt(build_ext):
    def run(self):
        super().run()
        self.fix_rpath()

    def fix_rpath(self):
        if sys.platform != "darwin":
            return

        conda_lib = os.path.join(sys.prefix, "lib")

        for ext in self.extensions:
            so_path = self.get_ext_fullpath(ext.name)
            if not os.path.exists(so_path):
                continue

            subprocess.run(
                ["install_name_tool", "-delete_rpath", conda_lib, so_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            subprocess.run(
                ["install_name_tool", "-delete_rpath", "@loader_path", so_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            subprocess.run(
                ["install_name_tool", "-delete_rpath", "@loader_path", so_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )


extra_compile_args = []
extra_link_args = []
if 'darwin' in sys.platform:
    extra_compile_args = ['-fopenmp']
    extra_link_args = ['-fopenmp']
    # clang
    # os.environ["CC"] = '/usr/bin/gcc'
    os.environ["CC"] = '/opt/homebrew/bin/gcc-12'

else:
    if environ.get('CC') and 'clang' in environ['CC']:
        # clang
        extra_compile_args = ['-fopenmp=libomp']
        extra_link_args = ['-fopenmp=libomp']
    else:
        # GNU
        extra_compile_args = ['-fopenmp']
        extra_link_args = ['-fopenmp']

MOD1 = 'kssdtool'
sources1 = ['co2mco.c',
            'iseq2comem.c',
            'command_dist_wrapper.c',
            'mytime.c',
            'global_basic.c',
            'command_set.c',
            'command_dist.c',
            'command_shuffle.c',
            'command_composite.c',
            'mman.c',
            'pykssd.c']
include_dirs1 = ['kssdheaders']

setup(
    name='kssdutils',
    version='1.1.8',
    author='Hang Yang',
    author_email='yhlink1207@gmail.com',
    description="kssdutils is a Python package for genome analysis, such as sketch, dist.",
    ext_modules=[
        Extension(MOD1, sources=sources1, include_dirs=include_dirs1, libraries=['z'],
                  extra_compile_args=extra_compile_args,
                  extra_link_args=extra_link_args)
    ],
    packages=find_packages(),
    dependency_links=['https://pypi.python.org/simple/'],
    zip_safe=False,
    include_package_data=True,
    scripts=['kssdutils.py'],
    cmdclass={
        "build_ext": CustomBuildExt,
    }
)
