import os
import time
import kssdtool
import argparse
import pkgutil


def allowedFile(filename):
    allowed_extensions = ['.fa', '.fa.gz', '.fasta', '.fasta.gz', '.fna', '.fna.gz', '.fastq', '.fastq.gz', '.fq',
                          'fq.gz']
    return any(filename.endswith(ext) for ext in allowed_extensions)


def createMatrix(filename):
    qrys = []
    refs = []
    dists = []
    with open('distout/distance.out', 'r') as file:
        lines = file.readlines()
        for line in lines:
            parts = line.split()
            if '.fq' in parts[0]:
                if '/' in parts[0]:
                    qry = parts[0].split('/')[-1].split('.fq')[0]
                else:
                    qry = parts[0].split('.fq')[0]
            elif '.fastq' in parts[0]:
                if '/' in parts[0]:
                    qry = parts[0].split('/')[-1].split('.fastq')[0]
                else:
                    qry = parts[0].split('.fastq')[0]
            elif '.fq.gz' in parts[0]:
                if '/' in parts[0]:
                    qry = parts[0].split('/')[-1].split('.fq.gz')[0]
                else:
                    qry = parts[0].split('.fq.gz')[0]
            elif '.fastq.gz' in parts[0]:
                if '/' in parts[0]:
                    qry = parts[0].split('/')[-1].split('.fastq.gz')[0]
                else:
                    qry = parts[0].split('.fastq.gz')[0]
            elif '.fa' in parts[0]:
                if '/' in parts[0]:
                    qry = parts[0].split('/')[-1].split('.fa')[0]
                else:
                    qry = parts[0].split('.fa')[0]
            elif '.fasta' in parts[0]:
                if '/' in parts[0]:
                    qry = parts[0].split('/')[-1].split('.fasta')[0]
                else:
                    qry = parts[0].split('.fasta')[0]
            else:
                qry = parts[0]

            if '.fa' in parts[1]:
                if '/' in parts[1]:
                    ref = parts[1].split('/')[-1].split('.fa')[0]
                else:
                    ref = parts[1].split('.fa')[0]
            elif '.fasta' in parts[1]:
                if '/' in parts[1]:
                    ref = parts[1].split('/')[-1].split('.fasta')[0]
                else:
                    ref = parts[1].split('.fasta')[0]
            else:
                ref = parts[1]
            dist = parts[4]
            qrys.append(qry)
            refs.append(ref)
            dists.append(dist)
    qrys = qrys[1:]
    refs = refs[1:]
    dists = dists[1:]
    qrys_set = list(set(qrys))
    refs_set = list(set(refs))
    distance_matrix = {}
    for q in qrys_set:
        distance_matrix[q] = {}
        for r in refs_set:
            distance_matrix[q][r] = None
    for q, r, d in zip(qrys, refs, dists):
        distance_matrix[q][r] = d
    if os.path.exists(filename):
        os.remove(filename)
    with open(filename, 'w') as output_file:
        output_file.write("\t".join([""] + refs_set) + "\n")
        for q in qrys_set:
            row = [q] + [distance_matrix[q][r] for r in refs_set]
            output_file.write("\t".join(map(str, row)) + "\n")


def sketch(shuf_file=None, genome_files=None, output=None, abundance=None):
    if shuf_file is not None and genome_files is not None and output is not None:
        if not os.path.exists(genome_files):
            print('No such file or directory: ', genome_files)
            return False
        if not allowedFile(genome_files):
            for filename in os.listdir(genome_files):
                if not allowedFile(filename):
                    print('Genome format error for file:', filename)
                    return False
        if not os.path.exists(shuf_file):
            print('No such file: ', shuf_file)
            return False
        print('Sketching...')
        start = time.time()

        if abundance:
            kssdtool.dist_dispatch(shuf_file, genome_files, output, 1, 0, 0, '', 'abundance')
        else:
            kssdtool.dist_dispatch(shuf_file, genome_files, output, 1, 0, 0, '', '')

        end = time.time()
        print('Sketch spend time：%.2fs' % (end - start))
        print('Sketch finished!')
        return True
    else:
        print('Args error!!!')
        return False


def dist(ref_sketch=None, qry_sketch=None, output=None, metric=None, N=None, flag=None):
    if ref_sketch is not None and qry_sketch is not None and output is not None:
        if not os.path.exists(ref_sketch):
            print('No such file or directory: ', ref_sketch)
            return False
        if not os.path.exists(qry_sketch):
            print('No such file or directory: ', qry_sketch)
            return False
        if flag is None:
            flag = 0
        if metric is None:
            metric = 'mash'

        print('Disting...')
        start = time.time()
        if '/' in output:
            output_dir = os.path.dirname(output)
            output_name = output.split('/')[-1]
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
                print("Created directory:", output_dir)
        else:
            output_name = output
        if output_name.endswith(".phy") or output_name.endswith(".phylip"):
            if metric not in ['mash', 'aaf']:
                print('Metric type error, only supports mash or aaf distance')
                return False
            else:
                if ref_sketch == qry_sketch:
                    if N is not None:
                        print('Error: N is None when ref_sketch and qry_sketch is same.')
                        return False
                    kssdtool.dist_dispatch(ref_sketch, output, qry_sketch, 2, 0, flag, metric, '')
                    end = time.time()
                    print('Dist spend time：%.2fs' % (end - start))
                    print('Dist finished!')
                    return True
                else:
                    print('Error: ref_sketch and qry_sketch must be same in .phylip (.phy) format.')
                    return False
        elif output_name.endswith(".mat"):
            if metric not in ['mash', 'aaf']:
                print('Metric type error, only supports mash or aaf distance')
                return False
            else:
                if N is not None:
                    kssdtool.dist_dispatch(ref_sketch, output, qry_sketch, 2, N, flag, metric, '')
                else:
                    kssdtool.dist_dispatch(ref_sketch, output, qry_sketch, 2, 0, flag, metric, '')
                end = time.time()
                print('Dist spend time：%.2fs' % (end - start))
                print('Dist finished!')
                if ref_sketch != qry_sketch:
                    os.remove(output)
                    createMatrix(output)
                return True
        else:
            print('Output type error, only supports .mat and .phylip (.phy) format:', output_name)
            return False
    else:
        print('Args error!!!')
        return False


def main():
    parser = argparse.ArgumentParser(
        description='kssdutils is a Python package for genome analysis, such as sketch, dist.')
    subparsers = parser.add_subparsers(
        dest='command',
        required=True,
        help='sketch or dist'
    )
    parser_sketch = subparsers.add_parser('sketch', help='sketch genomes')
    parser_sketch.add_argument(
        "-s", "--shuf",
        required=True,
        type=str,
        dest="shuf",
        help="shuffle file (L2K11.shuf/L3K10.shuf/L3K11.shuf)"
    )

    parser_sketch.add_argument(
        "-i", "--input",
        required=True,
        type=str,
        dest="input",
        help="input folder of fasta/fastq genomes files"
    )

    parser_sketch.add_argument(
        "-o", "--output",
        required=False,
        default='output_sketch',
        type=str,
        dest="output",
        help="output folder of sketch results"
    )

    parser_sketch.add_argument(
        "-a", "--abundance",
        required=False,
        action="store_true",
        dest="abundance",
        help="enable abundance analysis for fastq file"
             "(optional, default: disabled)"
    )

    args = parser.parse_args()
    # kssdutils sketch -s L3K10.shuf -i genomes -o output_sketch
    if args.abundance:
        sketch(
            shuf_file=args.shuf,
            genome_files=args.input,
            output=args.output,
            abundance = True
        )
    else:
        sketch(
            shuf_file=args.shuf,
            genome_files=args.input,
            output=args.output
        )


if __name__ == '__main__':
    main()
