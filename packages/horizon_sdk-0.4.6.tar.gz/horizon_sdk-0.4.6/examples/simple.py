"""Minimal 20-line Horizon example."""

import horizon as hz


def fair_value(ctx: hz.Context) -> float:
    """Simple fair value: just return 0.5 (coin flip)."""
    return 0.50


def quoter(ctx: hz.Context, fair: float) -> list[hz.Quote]:
    """Quote around the fair value with a fixed spread."""
    return hz.quotes(fair, spread=0.06, size=5)


hz.run(
    name="simple_mm",
    markets=["test-market"],
    pipeline=[fair_value, quoter],
    risk=hz.Risk(max_position=100, max_drawdown_pct=5),
    interval=1.0,
    mode="paper",
)
