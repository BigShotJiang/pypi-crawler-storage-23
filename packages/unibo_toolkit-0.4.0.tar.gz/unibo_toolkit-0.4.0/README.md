# UniBo Toolkit

Python toolkit for University of Bologna data scraping.
