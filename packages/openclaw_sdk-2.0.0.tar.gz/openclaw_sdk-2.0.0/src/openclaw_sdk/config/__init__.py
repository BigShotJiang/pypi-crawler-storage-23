"""OpenClaw runtime configuration manager."""

from openclaw_sdk.config.manager import ConfigManager

__all__ = ["ConfigManager"]
