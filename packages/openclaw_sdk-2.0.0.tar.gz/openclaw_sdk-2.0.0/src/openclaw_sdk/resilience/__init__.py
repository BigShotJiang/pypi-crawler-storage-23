"""Resilience utilities: retry, circuit breaker, and rate limiting."""
