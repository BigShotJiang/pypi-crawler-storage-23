"""HeyLead CLI entry point.

This module allows running HeyLead as:
    python -m heylead          # Start MCP server
    python -m heylead init     # First-time setup
    python -m heylead version  # Show version
    python -m heylead reset    # Delete all data
"""

from __future__ import annotations

import sys


def main() -> None:
    """CLI router — simple arg parsing without pulling in click for MCP mode."""
    args = sys.argv[1:]

    if not args:
        # Default: start MCP server
        from .server import main as serve
        serve()
        return

    cmd = args[0].lower()

    if cmd == "version" or cmd == "--version" or cmd == "-v":
        from . import __version__
        print(f"HeyLead v{__version__}")

    elif cmd == "init":
        from . import config
        config.ensure_dirs()
        cfg = config.load_config()
        print("✅ HeyLead initialized!")
        print(f"   Config: {config.config_path()}")
        print(f"   Database: {config.db_path()}")
        print(f"   Logs: {config.log_path()}")
        print()
        print("Next steps:")
        print('1. In Cursor, open AI chat (Cmd+L) and say: "Set up my HeyLead profile"')
        print("2. The AI will give you a link — sign in with Google, connect LinkedIn, paste token.")
        print("   No API keys needed!")
        print()
        print("Not using Cursor yet? Install HeyLead with one click:")
        print("   cursor://anysphere.cursor-deeplink/mcp/install?name=heylead&config=eyJjb21tYW5kIjoidXZ4IiwiYXJncyI6WyJoZXlsZWFkIl19")

    elif cmd == "reset":
        confirm = input("⚠️  This will delete ALL HeyLead data. Continue? (yes/no): ")
        if confirm.strip().lower() == "yes":
            from . import config
            from .db.schema import reset_db
            import shutil

            reset_db()

            # Remove legacy cookie file if it exists
            cookie_path = config.cookie_path()
            if cookie_path.exists():
                cookie_path.unlink()

            # Remove config
            cfg_path = config.config_path()
            if cfg_path.exists():
                cfg_path.unlink()

            # Remove logs
            log_dir = config._heylead_home() / "logs"
            if log_dir.exists():
                shutil.rmtree(log_dir)

            print("✅ All HeyLead data deleted.")
        else:
            print("Cancelled.")

    elif cmd == "help" or cmd == "--help" or cmd == "-h":
        print("HeyLead — MCP-native autonomous LinkedIn SDR")
        print()
        print("Usage:")
        print("  heylead            Start the MCP server (stdio transport)")
        print("  heylead init       Initialize HeyLead (create config + dirs)")
        print("  heylead version    Show version")
        print("  heylead reset      Delete all data")
        print()
        print("Add to Cursor (one click):")
        print("  cursor://anysphere.cursor-deeplink/mcp/install?name=heylead&config=eyJjb21tYW5kIjoidXZ4IiwiYXJncyI6WyJoZXlsZWFkIl19")
        print()
        print("Or add manually:")
        print("  Cursor:     Settings → MCP → Add → Name: heylead, Command: uvx heylead")
        print("  Claude Code: claude mcp add heylead -- uvx heylead")

    else:
        print(f"Unknown command: {cmd}")
        print("Run 'heylead help' for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
