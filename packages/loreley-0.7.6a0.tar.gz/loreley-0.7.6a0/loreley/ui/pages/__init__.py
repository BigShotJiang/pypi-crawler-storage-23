"""Streamlit pages for the Loreley UI.

Each page exposes a `render()` callable to be used by the main router.
"""

from __future__ import annotations

__all__ = []


