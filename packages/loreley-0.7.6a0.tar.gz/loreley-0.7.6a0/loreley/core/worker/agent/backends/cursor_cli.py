from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from time import monotonic

from loguru import logger

from loreley.config import get_settings
from loreley.core.worker.agent.contracts import AgentInvocation, AgentTask
from loreley.core.worker.agent.utils import validate_workdir

log = logger.bind(module="worker.agent.backends.cursor_cli")

DEFAULT_CURSOR_MODEL = "gpt-5.2-high"


@dataclass(slots=True)
class CursorCliBackend:
    """AgentBackend implementation that delegates to the Cursor Agent CLI.

    This backend runs ``cursor-agent`` in non-interactive mode, forwarding the
    prompt via ``-p`` and capturing plain-text (typically Markdown) output.
    """

    bin: str = "cursor-agent"
    model: str | None = DEFAULT_CURSOR_MODEL
    timeout_seconds: int = 1800
    extra_env: dict[str, str] = field(default_factory=dict)
    output_format: str = "text"
    force: bool = True
    error_cls: type[RuntimeError] = RuntimeError

    def run(
        self,
        task: AgentTask,
        *,
        working_dir: Path,
    ) -> AgentInvocation:
        worktree = validate_workdir(
            working_dir,
            error_cls=self.error_cls,
            agent_name=task.name or "Agent",
        )

        command: list[str] = [self.bin]

        if task.prompt:
            command.extend(["-p", task.prompt])

        if self.model:
            command.extend(["--model", self.model])

        if self.output_format:
            command.extend(["--output-format", self.output_format])

        if self.force:
            command.append("--force")

        command_for_log = command.copy()
        if task.prompt:
            try:
                prompt_index = command_for_log.index("-p")
                if prompt_index + 1 < len(command_for_log):
                    command_for_log[prompt_index + 1] = f"<prompt:{len(task.prompt)} chars>"
            except ValueError:
                pass

        env = os.environ.copy()
        env.update(self.extra_env or {})

        start = monotonic()
        log.debug(
            "Running Cursor CLI command: {} (cwd={}) for task={}",
            command_for_log,
            worktree,
            task.name,
        )
        try:
            result = subprocess.run(
                command,
                cwd=str(worktree),
                env=env,
                text=True,
                capture_output=True,
                timeout=self.timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise self.error_cls(
                f"cursor-agent timed out after {self.timeout_seconds}s.",
            ) from exc

        duration = monotonic() - start
        stdout = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()

        log.debug(
            "Cursor CLI finished (exit_code={}, duration={:.2f}s) for task={}",
            result.returncode,
            duration,
            task.name,
        )

        if result.returncode != 0:
            raise self.error_cls(
                f"cursor-agent failed with exit code {result.returncode}. "
                f"stderr: {stderr or 'N/A'}",
            )

        if not stdout:
            log.warning(
                "Cursor CLI produced an empty stdout payload for task={} (command={})",
                task.name,
                command_for_log,
            )

        return AgentInvocation(
            command=tuple(command),
            stdout=stdout,
            stderr=stderr,
            duration_seconds=duration,
        )


def cursor_backend() -> CursorCliBackend:
    """Factory to build a Cursor backend using env-only settings."""

    settings = get_settings()
    model = getattr(settings, "worker_cursor_model", DEFAULT_CURSOR_MODEL)
    force = getattr(settings, "worker_cursor_force", True)
    return CursorCliBackend(
        model=model or DEFAULT_CURSOR_MODEL,
        force=bool(force),
    )


def cursor_planning_backend() -> CursorCliBackend:
    """Factory to build a Cursor backend for the planning agent.

    Uses the planning agent's error type so the shared retry loop can capture
    failures, emit debug artifacts, and retry when appropriate.
    """

    from loreley.core.worker.planning import PlanningError

    settings = get_settings()
    model = getattr(settings, "worker_cursor_model", DEFAULT_CURSOR_MODEL)
    force = getattr(settings, "worker_cursor_force", True)
    return CursorCliBackend(
        model=model or DEFAULT_CURSOR_MODEL,
        force=bool(force),
        error_cls=PlanningError,
    )


def cursor_coding_backend() -> CursorCliBackend:
    """Factory to build a Cursor backend for the coding agent.

    Uses the coding agent's error type so the shared retry loop can capture
    failures, emit debug artifacts, and retry when appropriate.
    """

    from loreley.core.worker.coding import CodingError

    settings = get_settings()
    model = getattr(settings, "worker_cursor_model", DEFAULT_CURSOR_MODEL)
    force = getattr(settings, "worker_cursor_force", True)
    return CursorCliBackend(
        model=model or DEFAULT_CURSOR_MODEL,
        force=bool(force),
        error_cls=CodingError,
    )


__all__ = [
    "CursorCliBackend",
    "DEFAULT_CURSOR_MODEL",
    "cursor_backend",
    "cursor_coding_backend",
    "cursor_planning_backend",
]

