"""Networking helpers for Loreley."""

