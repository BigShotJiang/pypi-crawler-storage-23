"""Service layer for the UI API (read-only)."""

from __future__ import annotations

__all__ = []


