"""API routers grouped by domain."""

from __future__ import annotations

__all__ = []


