# loreley.core.map_elites.dimension_reduction

PCA-based dimensionality reduction of commit embeddings before they are fed into the MAP-Elites archive. In repo-state mode, the commit embedding is the repo-state code vector.

## Data structures

- **`PcaHistoryEntry`**: commit-level embedding recorded in PCA history. It stores the raw commit vector plus the embedding model name used to produce it.
- **`PCAProjection`**: serialisable wrapper around a fitted `sklearn.decomposition.PCA` model, capturing the mean vector, components, explained variance, explained variance ratio, whiten flag, and sample metadata. Each projection also carries an `epoch` counter and may include an optional orthogonal `rotation` matrix computed via orthogonal Procrustes alignment to reduce coordinate jitter between refits (it may include a reflection when PCA axes flip). `transform()` projects new vectors, applies whitening when enabled, and then applies the optional alignment.
- **`FinalEmbedding`**: low-dimensional vector that sits on the MAP-Elites grid for a commit, along with the originating `PcaHistoryEntry` and optional `PCAProjection` used.

## Reducer

- **`DimensionReducer`**: maintains a rolling history of PCA inputs and an optional PCA projection to keep the behaviour space stable.
  - Configured via `Settings` map-elites dimensionality options (`MAPELITES_DIMENSION_REDUCTION_*`) plus `MAPELITES_FEATURE_NORMALIZATION_WARMUP_SAMPLES`: target dimensions, minimum sample count (takes the max of the dimensionality minimum and the warmup), history size, refit interval, and whether to normalise input vectors.
  - `build_history_entry(...)` prepares the commit embedding from the code embedding, normalises when enabled, and returns a `PcaHistoryEntry` or `None` when no embeddings are available.
  - `reduce(entry, refit=None)` records the embedding in history, (re)fits PCA with `whiten=True` when needed, and projects into the target space, returning a `FinalEmbedding` and logging issues via `loguru` when projection cannot be computed.

## Convenience API

- **`reduce_commit_embeddings(...)`**: helper that runs the full reduction pipeline once. By default it constructs a fresh `DimensionReducer`, builds a PCA history entry from a commit's code embedding, and returns the `FinalEmbedding` together with the updated history, updated projection, and the updated `samples_since_fit` counter. Callers must persist `samples_since_fit` alongside history/projection so `MAPELITES_DIMENSION_REDUCTION_REFIT_INTERVAL` works across repeated calls.
  - When an existing `DimensionReducer` is supplied via `reducer=...`, the helper reuses it instead of reconstructing PCA state. This is useful for long-lived ingest loops that can keep reducer state in memory between commits.
