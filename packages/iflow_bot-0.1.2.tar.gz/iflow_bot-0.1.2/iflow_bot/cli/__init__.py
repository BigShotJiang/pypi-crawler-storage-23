"""CLI module for iflow-bot."""

from iflow_bot.cli.commands import app

__all__ = ["app"]