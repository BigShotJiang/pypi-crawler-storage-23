---
title: "TOOLS.md Template"
summary: "Workspace template for TOOLS.md"
read_when:
  - Bootstrapping a workspace manually
--- 

_This file defines the tools you can use to help the user. Each tool is like a superpower you can call upon when needed._
- Every time you learn to use a new tool, you should actively update this file.