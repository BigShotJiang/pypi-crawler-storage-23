from types import MappingProxyType
from typing import Any

import pytest

from osp_provider_contracts.conformance import assert_provider_conforms
from osp_provider_contracts.types import ProviderRequest, ProviderResult, RequestContext


class ConformingProvider:
    def capabilities(self) -> dict[str, Any]:
        return {
            "provider": "dummy",
            "version": "0.1.0",
            "resources": [{"kind": "bucket", "actions": ["create", "delete"]}],
        }

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True)


class MappingCapabilitiesProvider:
    def capabilities(self) -> Any:
        return MappingProxyType(
            {
                "provider": "dummy",
                "version": "0.1.0",
                "resources": [{"kind": "bucket", "actions": ["create", "delete"]}],
            }
        )

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True)


class MissingExecute:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "x", "version": "0.1.0", "resources": []}


class BadCapabilities:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "x", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True)


class BadCapabilitiesArity:
    def capabilities(self, _unexpected: str) -> dict[str, Any]:
        return {"provider": "x", "version": "0.1.0", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True)


class BadExecuteArity:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "x", "version": "0.1.0", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
        extra: str,
    ) -> ProviderResult:
        _ = extra
        return ProviderResult(success=True)


def test_assert_provider_conforms_for_valid_provider() -> None:
    assert_provider_conforms(ConformingProvider())


def test_assert_provider_conforms_accepts_mapping_capabilities() -> None:
    assert_provider_conforms(MappingCapabilitiesProvider())


def test_assert_provider_conforms_fails_on_missing_execute() -> None:
    with pytest.raises(AssertionError):
        assert_provider_conforms(MissingExecute())


def test_assert_provider_conforms_fails_on_bad_capabilities() -> None:
    with pytest.raises(ValueError):
        assert_provider_conforms(BadCapabilities())


def test_assert_provider_conforms_fails_on_bad_capabilities_arity() -> None:
    with pytest.raises(AssertionError):
        assert_provider_conforms(BadCapabilitiesArity())


def test_assert_provider_conforms_fails_on_bad_execute_arity() -> None:
    with pytest.raises(AssertionError):
        assert_provider_conforms(BadExecuteArity())
