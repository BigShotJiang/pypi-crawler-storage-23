from typing import Any

from osp_provider_contracts.protocol import Provider
from osp_provider_contracts.types import ProviderRequest, ProviderResult, RequestContext


class DummyProvider:
    def capabilities(self) -> dict[str, Any]:
        return {
            "provider": "dummy",
            "version": "0.1.0",
            "resources": [{"kind": "bucket", "actions": ["create", "delete"]}],
        }

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        message = f"{action}:{request.resource_kind}:{context.task_id}"
        return ProviderResult(success=True, message=message)


def test_dummy_is_runtime_provider_protocol() -> None:
    provider = DummyProvider()
    assert isinstance(provider, Provider)
