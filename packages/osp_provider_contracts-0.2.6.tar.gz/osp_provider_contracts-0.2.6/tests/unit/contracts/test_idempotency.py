from osp_provider_contracts.idempotency import build_idempotency_key
from osp_provider_contracts.types import RequestContext


def test_idempotency_key_is_deterministic() -> None:
    ctx = RequestContext(task_id="task-1", task_ref="task-1")
    first = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo")
    second = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo")
    assert first == second


def test_idempotency_key_avoids_delimiter_collisions() -> None:
    a = RequestContext(task_id="a|b", task_ref="c")
    b = RequestContext(task_id="a", task_ref="b|c")

    key_a = build_idempotency_key(context=a, action="x", resource_key="y")
    key_b = build_idempotency_key(context=b, action="x", resource_key="y")

    assert key_a != key_b


def test_idempotency_key_changes_with_action() -> None:
    ctx = RequestContext(task_id="task-1", task_ref="task-1")
    first = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo")
    second = build_idempotency_key(context=ctx, action="destroy", resource_key="bucket:demo")
    assert first != second


def test_idempotency_key_changes_with_resource_key() -> None:
    ctx = RequestContext(task_id="task-1", task_ref="task-1")
    first = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo-a")
    second = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo-b")
    assert first != second


def test_idempotency_key_supports_non_ascii_inputs() -> None:
    ctx = RequestContext(task_id="tåsk-1", task_ref="réq-1")
    first = build_idempotency_key(context=ctx, action="provisión", resource_key="bøtte:demo")
    second = build_idempotency_key(context=ctx, action="provisión", resource_key="bøtte:demo")
    assert first == second
