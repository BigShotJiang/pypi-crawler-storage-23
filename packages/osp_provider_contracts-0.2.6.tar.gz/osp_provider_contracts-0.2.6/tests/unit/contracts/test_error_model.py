from osp_provider_contracts.errors import (
    AuthError,
    ConflictError,
    DependencyError,
    NotFoundError,
    ProviderError,
    RateLimitError,
    TransientError,
    ValidationError,
)


def test_provider_error_shape() -> None:
    err = ProviderError(
        "boom",
        code="example",
        retryable=True,
        detail="details",
        extra={"x": 1},
    )
    assert err.code == "example"
    assert err.retryable is True
    assert err.as_dict()["extra"] == {"x": 1}


def test_subclass_defaults() -> None:
    assert AuthError("x").retryable is False
    assert NotFoundError("x").code == "not_found"
    assert ConflictError("x").code == "conflict"
    assert ValidationError("x").code == "validation_error"
    assert RateLimitError("x").retryable is True
    assert DependencyError("x").retryable is True
    assert TransientError("x").retryable is True


def test_subclass_as_dict_includes_extra_fields() -> None:
    err = ValidationError(
        "bad input",
        detail="approval_required",
        extra={"gate_reason": "provider_approval_required", "importance": 2},
    )
    payload = err.as_dict()
    assert payload["code"] == "validation_error"
    assert payload["retryable"] is False
    assert payload["detail"] == "approval_required"
    assert payload["extra"] == {"gate_reason": "provider_approval_required", "importance": 2}


def test_subclass_kwargs_passthrough() -> None:
    err = DependencyError(
        "provider backend unavailable",
        detail="upstream_unavailable",
        extra={"endpoint": "https://api.example"},
    )
    assert err.detail == "upstream_unavailable"
    assert err.extra == {"endpoint": "https://api.example"}
