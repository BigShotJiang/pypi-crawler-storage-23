import pytest

from osp_provider_contracts.capabilities import validate_capabilities


def test_validate_capabilities_rejects_string_resources() -> None:
    capabilities = {
        "provider": "dummy",
        "version": "0.1.0",
        "resources": "all",
    }
    with pytest.raises(ValueError):
        validate_capabilities(capabilities)


def test_validate_capabilities_rejects_string_actions() -> None:
    capabilities = {
        "provider": "dummy",
        "version": "0.1.0",
        "resources": [{"kind": "bucket", "actions": "create"}],
    }
    with pytest.raises(ValueError):
        validate_capabilities(capabilities)


def test_validate_capabilities_accepts_empty_resources() -> None:
    capabilities = {
        "provider": "dummy",
        "version": "0.1.0",
        "resources": [],
    }
    validate_capabilities(capabilities)
