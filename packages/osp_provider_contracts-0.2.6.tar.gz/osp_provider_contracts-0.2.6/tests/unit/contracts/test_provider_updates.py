"""Contract tests for provider update envelope helpers."""

import pytest

from osp_provider_contracts.provider_updates import (
    PROVIDER_UPDATE_KIND_TASK_EVENT,
    build_provider_update_envelope,
    parse_provider_update_envelope,
)


def test_build_provider_update_envelope_uses_contract_shape() -> None:
    """Build helper should emit normalized contract envelope fields."""
    envelope = build_provider_update_envelope(
        envelope_version="1.0",
        contract_version="1.0",
        message_id="evt-1",
        task_ref="task-42",
        task_id=42,
        status_code=160,
        severity=20,
        message="running",
        payload={"step": "clone"},
    )

    assert envelope["kind"] == PROVIDER_UPDATE_KIND_TASK_EVENT
    assert envelope["task_id"] == "42"
    assert envelope["payload"]["status_code"] == 160
    assert envelope["payload"]["severity"] == 20
    assert envelope["payload"]["message"] == "running"
    assert envelope["payload"]["payload"] == {"step": "clone"}


def test_parse_provider_update_envelope_derives_task_id_from_task_ref() -> None:
    task_id, _event = parse_provider_update_envelope(
        {
            "envelope_version": "1.0",
            "contract_version": "1.0",
            "message_id": "evt-2",
            "task_ref": "task-77",
            "kind": "task_event",
            "payload": {
                "status_code": 200,
                "severity": 20,
                "message": "done",
                "payload": {},
            },
        }
    )
    assert task_id == 77


def test_parse_provider_update_envelope_coerces_task_id_and_payload() -> None:
    """Parse helper should normalize task_id and event payload values."""
    task_id, event = parse_provider_update_envelope(
        {
            "envelope_version": "1.0",
            "contract_version": "1.0",
            "message_id": "evt-1",
            "task_ref": "task-42",
            "task_id": "42",
            "kind": "task_event",
            "payload": {
                "status_code": 200,
                "severity": 20,
                "message": "done",
                "payload": {"x": 1},
            },
        }
    )

    assert task_id == 42
    assert event["status_code"] == 200
    assert event["severity"] == 20
    assert event["message"] == "done"
    assert event["payload"] == {"x": 1}


def test_parse_provider_update_envelope_rejects_invalid_shape() -> None:
    """Parser should fail closed for non-contract or malformed envelopes."""
    with pytest.raises(ValueError):
        parse_provider_update_envelope({"kind": "legacy"})

    with pytest.raises(ValueError):
        parse_provider_update_envelope(
            {
                "envelope_version": "1.0",
                "contract_version": "1.0",
                "message_id": "evt-1",
                "task_ref": "task-42",
                "task_id": "not-an-int",
                "kind": "task_event",
                "payload": {
                    "status_code": 200,
                    "severity": 20,
                    "message": "done",
                    "payload": {},
                },
            }
        )

    with pytest.raises(ValueError):
        parse_provider_update_envelope(
            {
                "envelope_version": "1.0",
                "contract_version": "1.0",
                "message_id": "evt-1",
                "task_ref": "task-42",
                "task_id": "41",
                "kind": "task_event",
                "payload": {
                    "status_code": 200,
                    "severity": 20,
                    "message": "done",
                    "payload": {},
                },
            }
        )
