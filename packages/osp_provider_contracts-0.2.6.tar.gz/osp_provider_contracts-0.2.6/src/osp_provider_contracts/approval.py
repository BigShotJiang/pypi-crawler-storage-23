"""Approval gate protocol types with provider-agnostic gate reasons.

When a provider needs human approval before proceeding, it raises ValidationError
with detail="approval_required" and includes a structured extra payload conforming
to the types in this module. The orchestrator uses gate_reason and importance to
determine approval authority and quorum requirements.

Contracts:
    - GateReason values are stable strings.
    - ApprovalRequiredExtra.gate_reason and .importance control approval routing.
    - Importance 1 (VERY_HIGH) requires 2 approvers; importance 2-5 requires 1.
    - ApprovalDetails.violations array contains provider-specific gate violation details.

Usage:
    Providers construct ApprovalRequiredExtra and raise ValidationError:

        extra = ApprovalRequiredExtra(
            gate_reason=GateReason.POLICY_EXCEPTION_REQUIRED,
            importance=2,
            reason="vlan_outside_policy",
            details=ApprovalDetails(...),
        )
        raise ValidationError("VLAN not permitted", detail="approval_required", extra=extra)
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal, TypedDict


class GateReason(StrEnum):
    """Provider-agnostic gate reason keys."""

    APPROVAL_REQUIRED = "approval_required"
    PROVIDER_APPROVAL_REQUIRED = "provider_approval_required"
    LIMITS_EXCEEDED = "limits_exceeded"
    PLACEMENT_VIOLATION = "placement_violation"
    REQUESTED_STATE_INVALID = "requested_state_invalid"
    POLICY_EXCEPTION_REQUIRED = "policy_exception_required"
    AUTHZ_REQUIRED = "authz_required"
    EXTRA_EYES_REQUIRED = "extra_eyes_required"


CommentKind = Literal["planned", "requested", "effective", "comment"]
"""Category of status comment line for rendering approval details."""


class GateViolation(TypedDict, total=False):
    """Single gate violation detail for approval audit trail.

    Providers include violations in ApprovalDetails to explain why approval is needed.
    The fingerprint field enables deduplication across multiple gate evaluations.
    """

    layer: str
    message: str
    reason: str
    reason_code: str
    gate_reason: GateReason
    importance: int
    fingerprint: str
    details: dict[str, Any]


class ApprovalTargets(TypedDict, total=False):
    """Routing hint for who should approve this gate.

    Providers may suggest authority (ORCHESTRATOR or PROVIDER), netgroups, or contacts.
    The orchestrator makes the final routing decision based on gate_reason.
    """

    authority: str
    groups: list[str]
    contacts: list[str]


class ApprovalDetails(TypedDict, total=False):
    """Structured payload for approval-required errors.

    This payload surfaces in the orchestrator UI and audit logs. status_comment_lines
    are rendered as human-readable text; violations provide structured audit data.
    """

    schema_version: int
    status_comment_lines: list[str]
    approval_targets: ApprovalTargets
    violations: list[GateViolation]
    violation_count_total: int
    truncated: bool


class ApprovalRequiredExtra(TypedDict, total=False):
    """Top-level extra payload for ValidationError with detail='approval_required'.

    The orchestrator reads gate_reason and importance to determine approval authority
    and quorum. Providers must include at least gate_reason and reason.

    Fields:
        gate_reason: Preferred stable string reason key controlling approval routing.
        importance: Integer 1-5; importance 1 requires 2 approvers, 2-5 requires 1.
        reason: Stable machine-readable reason string for filtering/reporting.
        reason_code: Optional legacy alias for reason.
        details: Structured payload with violations and status comments.
        progress_events: Optional provider-emitted progress updates for the UI.
    """

    gate_reason: GateReason
    importance: int
    reason: str
    reason_code: str
    details: ApprovalDetails
    progress_events: list[dict[str, Any]]
