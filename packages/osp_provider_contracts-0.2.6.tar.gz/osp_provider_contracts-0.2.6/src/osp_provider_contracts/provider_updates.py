"""Shared provider update envelope contract.

This module defines the wire shape for provider lifecycle updates emitted by
``osp-provider-runtime`` and consumed by orchestrator update workers.

Usage:
    - Runtime builds update envelopes with ``build_provider_update_envelope``.
    - Orchestrator parses inbound envelopes with ``parse_provider_update_envelope``.

Contracts:
    - ``kind`` must be ``"task_event"``.
    - ``task_id`` is encoded as a string on the wire.
    - Event payload contains ``status_code``, ``severity``, ``message``,
      and nested provider payload.

Failure modes:
    - ``parse_provider_update_envelope`` raises ``ValueError`` for malformed
      or incomplete envelopes.
"""

import re
from collections.abc import Mapping
from typing import Any, Literal, NotRequired, TypedDict

PROVIDER_UPDATE_KIND_TASK_EVENT: Literal["task_event"] = "task_event"


class ProviderTaskEvent(TypedDict):
    """Contract payload for a single provider task event."""

    status_code: int
    severity: int
    message: str
    payload: dict[str, Any]


class ProviderUpdateEnvelope(TypedDict):
    """Contract envelope emitted by providers for task lifecycle updates."""

    envelope_version: str
    contract_version: str
    message_id: str
    task_ref: str
    task_id: NotRequired[str]
    kind: Literal["task_event"]
    payload: ProviderTaskEvent


def build_provider_update_envelope(
    *,
    envelope_version: str,
    contract_version: str,
    message_id: str,
    task_ref: str,
    task_id: int | str | None = None,
    status_code: int,
    severity: int,
    message: str,
    payload: Mapping[str, Any] | None = None,
) -> ProviderUpdateEnvelope:
    """Build a provider update envelope in the shared contract shape."""
    event: ProviderTaskEvent = {
        "status_code": int(status_code),
        "severity": int(severity),
        "message": str(message),
        "payload": dict(payload or {}),
    }
    envelope: ProviderUpdateEnvelope = {
        "envelope_version": str(envelope_version),
        "contract_version": str(contract_version),
        "message_id": str(message_id),
        "task_ref": str(task_ref),
        "kind": PROVIDER_UPDATE_KIND_TASK_EVENT,
        "payload": event,
    }
    if task_id is not None:
        envelope["task_id"] = str(task_id)
    return envelope


_TASK_REF_ID_RE = re.compile(r"^task-(\d+)$")


def _derive_task_id_from_ref(task_ref: str) -> int | None:
    match = _TASK_REF_ID_RE.match(task_ref.strip())
    if not match:
        return None
    return int(match.group(1))


def parse_provider_update_envelope(data: Mapping[str, Any]) -> tuple[int, ProviderTaskEvent]:
    """Validate and normalize a provider update envelope.

    Args:
        data: Parsed JSON mapping for an inbound provider update.

    Returns:
        ``(task_id, event)`` where ``task_id`` is coerced to ``int`` and
        ``event`` is a normalized ``ProviderTaskEvent`` mapping.

    Raises:
        ValueError: If envelope fields are missing or invalid.
    """
    for field in (
        "envelope_version",
        "contract_version",
        "message_id",
        "task_ref",
        "kind",
        "payload",
    ):
        if field not in data:
            raise ValueError(f"missing '{field}'")

    if data["kind"] != PROVIDER_UPDATE_KIND_TASK_EVENT:
        raise ValueError("unsupported update kind")

    task_ref = str(data["task_ref"])
    derived_task_id = _derive_task_id_from_ref(task_ref)

    task_id: int | None = None
    if "task_id" in data:
        raw_task_id = data["task_id"]
        if isinstance(raw_task_id, int):
            task_id = raw_task_id
        elif isinstance(raw_task_id, str) and raw_task_id.isdigit():
            task_id = int(raw_task_id)
        else:
            raise ValueError("task_id must be int or digit string when provided")
        if derived_task_id is not None and int(task_id) != int(derived_task_id):
            raise ValueError("task_id does not match task_ref")
    else:
        task_id = derived_task_id
    if task_id is None:
        raise ValueError("task_ref must encode numeric task id when task_id omitted")

    raw_event = data["payload"]
    if not isinstance(raw_event, Mapping):
        raise ValueError("payload must be an object")

    raw_status_code = raw_event.get("status_code")
    if not isinstance(raw_status_code, int):
        raise ValueError("payload.status_code must be an int")

    raw_severity = raw_event.get("severity")
    if not isinstance(raw_severity, int):
        raise ValueError("payload.severity must be an int")

    raw_message = raw_event.get("message")
    if not isinstance(raw_message, str):
        raise ValueError("payload.message must be a string")

    raw_payload = raw_event.get("payload")
    event_payload = dict(raw_payload) if isinstance(raw_payload, Mapping) else {}

    event: ProviderTaskEvent = {
        "status_code": raw_status_code,
        "severity": raw_severity,
        "message": raw_message,
        "payload": event_payload,
    }
    return task_id, event


__all__ = [
    "PROVIDER_UPDATE_KIND_TASK_EVENT",
    "ProviderTaskEvent",
    "ProviderUpdateEnvelope",
    "build_provider_update_envelope",
    "parse_provider_update_envelope",
]
