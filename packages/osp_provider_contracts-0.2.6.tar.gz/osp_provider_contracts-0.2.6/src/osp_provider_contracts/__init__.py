"""Shared contracts library for OSP providers and orchestrator.

This package defines the stable interface between OSP providers (VMware, NREC, etc.)
and the central orchestrator service. It provides typed request/result structures,
canonical error taxonomy, capabilities validation, and the approval-gate protocol.

Usage:
    Import directly from the package root:

        from osp_provider_contracts import Provider, ProviderRequest, ProviderResult
        from osp_provider_contracts import ValidationError, build_idempotency_key

Contracts:
    - Provider implementations must conform to the Provider protocol (capabilities, execute).
    - All errors inherit from ProviderError and carry retry metadata.
    - Approval-required flows use ValidationError with detail="approval_required" and
      structured extra payload (gate_reason, importance, reason, details).
    - Idempotency keys are stable SHA256 hashes of (task_id, task_ref, action, resource_key).

Notes:
    - This library has no external dependencies beyond Python 3.12+ stdlib.
    - The testing subpackage provides conformance assertions for provider test suites.

"""

from .approval import (
    ApprovalDetails,
    ApprovalRequiredExtra,
    ApprovalTargets,
    CommentKind,
    GateReason,
    GateViolation,
)
from .errors import (
    AuthError,
    ConflictError,
    DependencyError,
    NotFoundError,
    ProviderError,
    RateLimitError,
    TransientError,
    ValidationError,
)
from .idempotency import build_idempotency_key
from .protocol import Provider
from .provider_updates import (
    PROVIDER_UPDATE_KIND_TASK_EVENT,
    ProviderTaskEvent,
    ProviderUpdateEnvelope,
    build_provider_update_envelope,
    parse_provider_update_envelope,
)
from .types import ProviderRequest, ProviderResult, RequestContext
from .version import __version__

__all__ = [
    "__version__",
    "AuthError",
    "ApprovalDetails",
    "ApprovalRequiredExtra",
    "ApprovalTargets",
    "CommentKind",
    "ConflictError",
    "DependencyError",
    "GateReason",
    "GateViolation",
    "NotFoundError",
    "Provider",
    "ProviderError",
    "ProviderRequest",
    "ProviderResult",
    "ProviderTaskEvent",
    "ProviderUpdateEnvelope",
    "RateLimitError",
    "RequestContext",
    "PROVIDER_UPDATE_KIND_TASK_EVENT",
    "TransientError",
    "ValidationError",
    "build_idempotency_key",
    "build_provider_update_envelope",
    "parse_provider_update_envelope",
]
