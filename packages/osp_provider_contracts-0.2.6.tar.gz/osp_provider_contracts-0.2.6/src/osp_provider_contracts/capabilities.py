"""Schema validation for provider capabilities documents.

Providers advertise their supported resource kinds and actions via a capabilities
document. This module validates that the document conforms to the expected structure
required by the orchestrator for routing and authorization decisions.

Contracts:
    - Capabilities must include provider (str), version (str), resources (sequence).
    - Each resource must include kind (str) and actions (list of str).
    - Validation raises ValueError immediately on first schema violation.

Usage:
    Called by the orchestrator during provider registration and by test suites to
    verify provider conformance.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


def validate_capabilities(capabilities: Mapping[str, Any]) -> None:
    """Validate provider capabilities document against the expected schema.

    The capabilities document declares which resource kinds and actions the provider
    supports. The orchestrator uses this during task routing and permission checks.

    Args:
        capabilities: Mapping containing provider metadata and resource definitions.
            Must include keys: provider (str), version (str), resources (sequence).
            Each resource in the sequence must be a mapping with kind (str) and
            actions (sequence of str).

    Raises:
        ValueError: When required keys are missing, types are incorrect, or values
            are empty strings. The error message identifies the specific violation.

    Example:
        >>> validate_capabilities({
        ...     "provider": "vmware",
        ...     "version": "1.0.0",
        ...     "resources": [
        ...         {"kind": "vm", "actions": ["create", "delete"]},
        ...     ]
        ... })

    """
    required = ("provider", "version", "resources")
    missing = [name for name in required if name not in capabilities]
    if missing:
        raise ValueError(f"capabilities missing required keys: {missing}")

    if not isinstance(capabilities["provider"], str) or not capabilities["provider"]:
        raise ValueError("capabilities.provider must be a non-empty string")
    if not isinstance(capabilities["version"], str) or not capabilities["version"]:
        raise ValueError("capabilities.version must be a non-empty string")

    resources = capabilities["resources"]
    if not isinstance(resources, Sequence) or isinstance(resources, str):
        raise ValueError("capabilities.resources must be a sequence")

    for index, resource in enumerate(resources):
        if not isinstance(resource, Mapping):
            raise ValueError(f"resources[{index}] must be a mapping")
        if "kind" not in resource or "actions" not in resource:
            raise ValueError(f"resources[{index}] must include 'kind' and 'actions'")
        if not isinstance(resource["kind"], str) or not resource["kind"]:
            raise ValueError(f"resources[{index}].kind must be a non-empty string")
        if (
            not isinstance(resource["actions"], Sequence)
            or isinstance(resource["actions"], str)
            or any(not isinstance(action, str) for action in resource["actions"])
        ):
            raise ValueError(f"resources[{index}].actions must be a sequence of strings")
