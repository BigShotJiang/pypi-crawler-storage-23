"""Canonical error taxonomy for OSP providers.

All provider errors inherit from ProviderError and carry structured retry metadata.
The orchestrator uses the `retryable` flag to decide whether to retry the task and
serializes errors via as_dict() for TaskEvent storage and API responses.

Contracts:
    - All errors include code, retryable, detail, and extra fields.
    - Retryable errors (TransientError, RateLimitError, DependencyError) trigger retry.
    - Non-retryable errors (AuthError, NotFoundError, ConflictError, ValidationError)
      move the task to FAILED status immediately.
    - ValidationError with detail="approval_required" and structured extra payload
      triggers the approval gate flow (see approval module).

Usage:
    Providers raise specific error subclasses during execute():

        if not authorized:
            raise AuthError("Token expired", detail="token_refresh_needed")
        if resource_missing:
            raise NotFoundError(f"VM {vm_id} not found")
        if rate_limited:
            raise RateLimitError("API quota exceeded", detail="retry_after_60s")
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


# DOCS:BEGIN provider_error_base
class ProviderError(Exception):
    """Base exception for all provider errors.

    Carries structured metadata for retry logic, error codes, and orchestrator
    serialization. All subclasses set appropriate defaults for code and retryable.

    Args:
        message: Human-readable error description for logs and UI.
        code: Machine-readable error code (default: "provider_error").
        retryable: Whether the orchestrator should retry this task (default: False).
        detail: Optional additional context (e.g., "token_expired", "quota_exceeded").
        extra: Optional provider-specific metadata (e.g., approval payloads, diagnostics).

    Attributes:
        message: The error message string.
        code: Stable error code for filtering and categorization.
        retryable: Retry eligibility flag.
        detail: Optional detail string.
        extra: Optional metadata dictionary.

    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "provider_error",
        retryable: bool = False,
        detail: str | None = None,
        extra: Mapping[str, Any] | None = None,
    ) -> None:
        """Initialize provider error with message and metadata (see class docstring for details)."""
        super().__init__(message)
        self.message = message
        self.code = code
        self.retryable = retryable
        self.detail = detail
        self.extra = dict(extra or {})

    def as_dict(self) -> dict[str, Any]:
        """Serialize error to dictionary for TaskEvent storage and API responses.

        Returns:
            Dictionary with message, code, retryable, detail, and extra keys.

        """
        return {
            "message": self.message,
            "code": self.code,
            "retryable": self.retryable,
            "detail": self.detail,
            "extra": self.extra,
        }


# DOCS:END provider_error_base


# DOCS:BEGIN provider_error_subclasses
class AuthError(ProviderError):
    """Authentication or authorization failure (non-retryable).

    Use when credentials are invalid, expired, or insufficient permissions exist.
    The orchestrator does not retry these errors; operators must fix auth config.

    Args:
        message: Description of the auth failure.
        **kwargs: Forwarded to ProviderError (detail, extra).

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize auth error with message and optional detail/extra."""
        super().__init__(message, code="auth_error", retryable=False, **kwargs)


class NotFoundError(ProviderError):
    """Resource not found (non-retryable).

    Use when a requested resource (VM, network, datastore) does not exist and
    cannot be created implicitly. Not retryable unless the resource is expected
    to appear later (use DependencyError instead in that case).

    Args:
        message: Description of what was not found.
        **kwargs: Forwarded to ProviderError (detail, extra).

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize not-found error with message and optional detail/extra."""
        super().__init__(message, code="not_found", retryable=False, **kwargs)


class ConflictError(ProviderError):
    """Resource conflict or constraint violation (non-retryable).

    Use when the operation cannot proceed due to existing state (e.g., duplicate
    name, resource already exists, immutable field modified). Not retryable.

    Args:
        message: Description of the conflict.
        **kwargs: Forwarded to ProviderError (detail, extra).

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize conflict error with message and optional detail/extra."""
        super().__init__(message, code="conflict", retryable=False, **kwargs)


class ValidationError(ProviderError):
    """Request validation failure or approval required (non-retryable).

    Use for malformed payloads, invalid parameters, or when human approval is needed.
    For approval flows, set detail="approval_required" and include structured extra
    payload (see ApprovalRequiredExtra in approval module).

    Args:
        message: Validation failure description or approval reason.
        **kwargs: Forwarded to ProviderError (detail, extra).

    Example:
        >>> extra = {"gate_reason": "policy_exception_required", "importance": 2}
        >>> raise ValidationError("VLAN not permitted", detail="approval_required", extra=extra)

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize validation error with message and optional detail/extra."""
        super().__init__(message, code="validation_error", retryable=False, **kwargs)


class RateLimitError(ProviderError):
    """API rate limit exceeded (retryable).

    Use when the provider API returns 429 or quota-exceeded errors. The orchestrator
    will retry these errors with exponential backoff.

    Args:
        message: Rate limit description.
        **kwargs: Forwarded to ProviderError (detail, extra).

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize rate-limit error with message and optional detail/extra."""
        super().__init__(message, code="rate_limited", retryable=True, **kwargs)


class DependencyError(ProviderError):
    """External dependency unavailable or blocking operation (retryable).

    Use when the operation cannot proceed due to missing external state that may
    appear later (e.g., waiting for DNS propagation, pending VM power state).

    Args:
        message: Dependency failure description.
        **kwargs: Forwarded to ProviderError (detail, extra).

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize dependency error with message and optional detail/extra."""
        super().__init__(message, code="dependency_error", retryable=True, **kwargs)


class TransientError(ProviderError):
    """Temporary failure expected to resolve on retry (retryable).

    Use for transient network errors, temporary API unavailability, or other
    ephemeral failures. The orchestrator will retry with exponential backoff.

    Args:
        message: Transient error description.
        **kwargs: Forwarded to ProviderError (detail, extra).

    """

    def __init__(self, message: str, **kwargs: Any) -> None:
        """Initialize transient error with message and optional detail/extra."""
        super().__init__(message, code="transient_error", retryable=True, **kwargs)


# DOCS:END provider_error_subclasses
