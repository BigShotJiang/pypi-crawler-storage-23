# Source Tree Overview

This directory contains the `osp_provider_contracts` package. The top-level
package is `src/osp_provider_contracts/`.

## Audience

Maintainers and contributors working on contract internals.

## TL;DR (Critical Invariants)

- Root exports define the supported API surface for consumers.
- Wire-level enums/error codes must remain stable after release.
- Conformance helpers are shipped library code, not the package's own test suite.

## Structure

- `src/osp_provider_contracts/__init__.py`
  - Public API surface for core contracts. Import core types/errors/helpers
    from here; use `conformance/` directly for test helpers.
- `src/osp_provider_contracts/types.py`
  - Core frozen dataclasses: `RequestContext`, `ProviderRequest`, `ProviderResult`.
- `src/osp_provider_contracts/protocol.py`
  - `Provider` runtime-checkable protocol. All providers must implement
    `capabilities()` and `execute()`.
- `src/osp_provider_contracts/errors.py`
  - Canonical error taxonomy. All errors inherit `ProviderError` and carry
    retry metadata.
- `src/osp_provider_contracts/approval.py`
  - Approval gate types: `GateReason`, `ApprovalRequiredExtra`, `ApprovalDetails`,
    `GateViolation`, `ApprovalTargets`.
- `src/osp_provider_contracts/capabilities.py`
  - `validate_capabilities()` — validates a provider capabilities document.
- `src/osp_provider_contracts/idempotency.py`
  - `build_idempotency_key()` — deterministic SHA256 key for deduplication.
- `src/osp_provider_contracts/conformance/`
  - `assert_provider_conforms()` — smoke-test assertion for provider test suites.
  - More: `src/osp_provider_contracts/conformance/README.md`

## Tutorial: implement a minimal provider

```python
from osp_provider_contracts import (
    Provider,
    ProviderRequest,
    ProviderResult,
    RequestContext,
    build_idempotency_key,
    NotFoundError,
)


class MyProvider:
    def capabilities(self):
        return {
            "provider": "my-provider",
            "version": "1.0.0",
            "resources": [
                {"kind": "vm", "actions": ["create", "delete"]},
            ],
        }

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        key = build_idempotency_key(
            context=context,
            action=action,
            resource_key=request.payload["hostname"],
        )
        # Deduplicate via key, then perform operation...
        if action == "create":
            return ProviderResult(success=True, external_id="vm-abc123")
        raise NotFoundError(f"Unknown action: {action}")
```

Use `assert_provider_conforms(provider)` in tests to verify protocol conformance.

## Tutorial: raise an approval gate

Providers that require human approval raise `ValidationError` with
`detail="approval_required"` and a structured extra payload:

```python
from osp_provider_contracts import ValidationError, GateReason
from osp_provider_contracts.approval import ApprovalRequiredExtra, ApprovalDetails

extra: ApprovalRequiredExtra = {
    "gate_reason": GateReason.POLICY_EXCEPTION_REQUIRED,
    "importance": 2,
    "reason": "vlan_outside_policy",
    "details": ApprovalDetails(
        schema_version=1,
        status_comment_lines=["VLAN 42 is not in the permitted list."],
        violations=[
            {
                "layer": "network_policy",
                "message": "VLAN 42 not permitted",
                "reason_code": "vlan_not_permitted",
                "gate_reason": GateReason.POLICY_EXCEPTION_REQUIRED,
                "importance": 2,
            }
        ],
    ),
}
raise ValidationError("VLAN not permitted", detail="approval_required", extra=extra)
```

The orchestrator reads `gate_reason` and `importance` to determine approval
authority and quorum (importance=1 requires 2 approvers, 2–5 requires 1).

For details on each module, see `src/osp_provider_contracts/README.md`.
