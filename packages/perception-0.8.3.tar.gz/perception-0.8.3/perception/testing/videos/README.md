Video from https://www.youtube.com/watch?v=84Er4LnWXtI under Creative Commons Attribution License.

Notes
- v1 is a fairly short, slow moving video
- v2 is a longer but faster-paced video
- v2s is the same as v2 but with a snippet removed in the middle (simulates a scene or cut)