quests package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   quests.cli
   quests.tools

Submodules
----------

quests.descriptor module
------------------------

.. automodule:: quests.descriptor
   :members:
   :undoc-members:
   :show-inheritance:

quests.entropy module
---------------------

.. automodule:: quests.entropy
   :members:
   :undoc-members:
   :show-inheritance:

quests.geometry module
----------------------

.. automodule:: quests.geometry
   :members:
   :undoc-members:
   :show-inheritance:

quests.matrix module
--------------------

.. automodule:: quests.matrix
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: quests
   :members:
   :undoc-members:
   :show-inheritance:
