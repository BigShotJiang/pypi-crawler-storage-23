"""
Django system checks for nimoh-be-django-base.
================================================

These checks run automatically via ``./manage.py check`` and integrate
with the standard Django system-check framework.  Run only these checks
with::

    ./manage.py check --tag nimoh_base

Checks implemented
------------------
E001 — ``NIMOH_BASE`` dict is absent from settings entirely.
E002 — One or more required ``NIMOH_BASE`` keys are missing.
W001 — ``AUTH_USER_MODEL`` does not sub-class ``AbstractNimohUser``.
W002 — Core ``nimoh_base`` apps are missing from ``INSTALLED_APPS``.
W003 — Default throttle-rate keys are missing from ``REST_FRAMEWORK``.
"""

from django.core.checks import (
    Error,
    register,
)
from django.core.checks import Warning as DjangoWarning

_TAG = "nimoh_base"


@register(_TAG)
def check_nimoh_base_dict(app_configs, **kwargs):
    """E001 / E002 — NIMOH_BASE presence and required-key validation."""
    from django.conf import settings

    errors = []
    nimoh = getattr(settings, "NIMOH_BASE", None)

    if nimoh is None:
        errors.append(
            Error(
                "NIMOH_BASE settings dict is not configured.",
                hint=(
                    "Add NIMOH_BASE = {'SITE_NAME': '...', 'SUPPORT_EMAIL': '...', "
                    "'NOREPLY_EMAIL': '...'} to your Django settings, or use "
                    "nimoh_base.conf.defaults.NIMOH_BASE_DEFAULTS as a starting point."
                ),
                id="nimoh_base.E001",
            )
        )
        return errors  # Can't validate keys if the dict is absent

    from nimoh_base.conf.defaults import NIMOH_BASE_REQUIRED_KEYS

    missing = sorted(k for k in NIMOH_BASE_REQUIRED_KEYS if k not in nimoh)
    if missing:
        errors.append(
            Error(
                f"Required NIMOH_BASE key(s) are missing: {', '.join(missing)}",
                hint=(
                    "Add the missing keys to the NIMOH_BASE dict in your settings. "
                    "See docs/SETTINGS.md for descriptions and acceptable values."
                ),
                id="nimoh_base.E002",
            )
        )

    return errors


@register(_TAG)
def check_installed_apps(app_configs, **kwargs):
    """W002 — Core nimoh_base apps should be in INSTALLED_APPS."""
    from django.conf import settings

    warnings = []
    installed = set(getattr(settings, "INSTALLED_APPS", []))
    required_apps = ["nimoh_base.core", "nimoh_base.auth"]

    for app in required_apps:
        if app not in installed:
            warnings.append(
                DjangoWarning(
                    f"'{app}' is not in INSTALLED_APPS.",
                    hint=(
                        f"Add '{app}' to INSTALLED_APPS or use "
                        "NimohBaseSettings.get_base_apps() to build your app list."
                    ),
                    id="nimoh_base.W002",
                )
            )

    return warnings


@register(_TAG)
def check_auth_user_model(app_configs, **kwargs):
    """W001 — AUTH_USER_MODEL should sub-class AbstractNimohUser."""
    from django.apps import apps
    from django.conf import settings

    warnings = []
    auth_user_model = getattr(settings, "AUTH_USER_MODEL", "auth.User")

    if auth_user_model == "auth.User":
        warnings.append(
            DjangoWarning(
                "AUTH_USER_MODEL is the default Django 'auth.User'.",
                hint=(
                    "nimoh-be-django-base expects a custom user model that inherits "
                    "from nimoh_base.auth.models.AbstractNimohUser. "
                    "Define 'class User(AbstractNimohUser): pass' in your app and set "
                    "AUTH_USER_MODEL = 'myapp.User'."
                ),
                id="nimoh_base.W001",
            )
        )
        return warnings

    try:
        UserModel = apps.get_model(auth_user_model)
        from nimoh_base.auth.models import AbstractNimohUser

        if not issubclass(UserModel, AbstractNimohUser):
            warnings.append(
                DjangoWarning(
                    f"AUTH_USER_MODEL '{auth_user_model}' does not sub-class AbstractNimohUser.",
                    hint=(
                        "For full nimoh-be-django-base functionality your user model should "
                        "inherit from nimoh_base.auth.models.AbstractNimohUser."
                    ),
                    id="nimoh_base.W001",
                )
            )
    except LookupError:
        # Model not yet registered — can happen when check runs with a subset of
        # app_configs (e.g. during migrations).  Skip silently.
        pass

    return warnings


@register(_TAG)
def check_throttle_rates(app_configs, **kwargs):
    """W003 — Expected throttle-rate keys should be in REST_FRAMEWORK."""
    from django.conf import settings

    warnings = []
    drf = getattr(settings, "REST_FRAMEWORK", {})
    rates = drf.get("DEFAULT_THROTTLE_RATES", {})

    required_rates = ["anon", "user", "authentication", "registration"]
    missing = [r for r in required_rates if r not in rates]

    if missing:
        warnings.append(
            DjangoWarning(
                f"REST_FRAMEWORK['DEFAULT_THROTTLE_RATES'] is missing key(s): {', '.join(missing)}",
                hint=(
                    "Add the missing rate-limit keys, e.g. "
                    "{'authentication': '5/min', 'registration': '5/hour'}. "
                    "Use NimohBaseSettings.get_base_rest_framework() as a starting point."
                ),
                id="nimoh_base.W003",
            )
        )

    return warnings
