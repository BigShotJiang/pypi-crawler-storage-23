"""Turns FHIR data into de-identified & aggregated records"""

__version__ = "4.0.0"
