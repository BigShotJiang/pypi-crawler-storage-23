# Sometimes I develop on Windows. When that happens I don't have pyfuse3, and having this mock helps.
ROOT_INODE = 1
