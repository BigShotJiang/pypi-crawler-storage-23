# Output writers for container images
