# Input modules for reading container images from various sources
