# LLM planning documents

I am playing with a more formal style of planning for LLM assisted
coding sessions. This directory contains plans negotiated by myself
and a LLM before implementation starts.

* [Implementation plan for the info and check subcommands](PLAN-info-check.md).