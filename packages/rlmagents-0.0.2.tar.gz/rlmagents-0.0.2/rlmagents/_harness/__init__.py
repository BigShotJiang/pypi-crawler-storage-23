"""Agent harness incorporated into rlmagents.

This module contains the necessary agent harness code (backends, middleware)
incorporated directly into rlmagents to make it standalone.
"""
