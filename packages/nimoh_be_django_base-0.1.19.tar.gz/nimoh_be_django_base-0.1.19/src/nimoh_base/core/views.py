"""Base ViewSet and common view utilities.

Provides standardized CRUD with consistent permissions,
pagination, and exception handling across all apps.
"""

import logging

from rest_framework.viewsets import ModelViewSet

logger = logging.getLogger(__name__)


class BaseModelViewSet(ModelViewSet):
    """Project-wide base ViewSet.

    Inherits all DRF defaults from ``REST_FRAMEWORK`` in settings
    (JWT auth, ``IsAuthenticated``, page-number pagination, filter
    backends, and the custom exception handler).

    Subclasses only need to set:
        * ``queryset``
        * ``serializer_class``

    Override ``permission_classes``, ``throttle_classes``, etc. at the
    view level when the defaults are not appropriate.
    """

    def perform_create(self, serializer):
        """Log object creation and delegate to the serializer."""
        instance = serializer.save()
        logger.info(
            "Object created",
            extra={
                "model": instance.__class__.__name__,
                "pk": str(instance.pk),
                "user": str(getattr(self.request, "user", None)),
            },
        )

    def perform_update(self, serializer):
        """Log object update and delegate to the serializer."""
        instance = serializer.save()
        logger.info(
            "Object updated",
            extra={
                "model": instance.__class__.__name__,
                "pk": str(instance.pk),
                "user": str(getattr(self.request, "user", None)),
            },
        )

    def perform_destroy(self, instance):
        """Log object deletion and then delete."""
        logger.info(
            "Object deleted",
            extra={
                "model": instance.__class__.__name__,
                "pk": str(instance.pk),
                "user": str(getattr(self.request, "user", None)),
            },
        )
        instance.delete()
