"""
Structured, human-friendly logging formatters for nimoh-be-django-base.

Formatters
----------
DevConsoleFormatter
    Coloured, aligned output designed for local and Docker development logs.
    Format per line::

        HH:MM:SS  LEVEL     module          message

    Colours:
      DEBUG    - dim/grey
      INFO     - green
      WARNING  - yellow (entire line)
      ERROR    - red (entire line)
      CRITICAL - bold red (entire line)

JsonFormatter
    Single-line JSON output for production / log-aggregation pipelines.
    Every record emits::

        {"time": "ISO8601", "level": "INFO", "logger": "...", "message": "..."}

Filters
-------
SensitiveDataFilter
    Strips passwords, tokens, secrets and other PII before the record is
    emitted by *any* handler that attaches this filter.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime

# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------


class SensitiveDataFilter(logging.Filter):
    """Redact passwords, tokens and API keys from log messages."""

    # Matches ``key=value`` and ``key: value`` patterns (case-insensitive).
    _PATTERN = re.compile(
        r"(?i)(?P<key>\b(?:password|passwd|pwd|secret|token|api_?key|auth(?:orization)?|access_?key|private_?key))"
        r"(?P<sep>\s*[:=]\s*)"
        r"(?P<val>\S+)",
    )
    _REPLACEMENT = r"\g<key>\g<sep>[REDACTED]"

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._redact(str(record.msg))
        if record.args:
            if isinstance(record.args, dict):
                record.args = {k: self._redact(str(v)) for k, v in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(self._redact(str(a)) for a in record.args)
        return True

    def _redact(self, text: str) -> str:
        return self._PATTERN.sub(self._REPLACEMENT, text)


# ---------------------------------------------------------------------------
# Dev console formatter
# ---------------------------------------------------------------------------


class DevConsoleFormatter(logging.Formatter):
    """
    Coloured, fixed-column formatter for development / Docker dev output.

    Example output::

        10:17:12  INFO      performance   GET /api/v1/schema/docs/ — 19.65ms
        10:17:13  WARNING   views         CSP Violation Detected | ...
        10:17:13  DEBUG     views         Full CSP Report: { ... }
    """

    # ANSI escape sequences
    _RESET = "\033[0m"
    _BOLD = "\033[1m"
    _DIM = "\033[2m"
    _CYAN = "\033[36m"
    _GREEN = "\033[32m"
    _YELLOW = "\033[33m"
    _RED = "\033[31m"
    _BRED = "\033[1;31m"
    _GREY = "\033[37m"

    # Colour applied to the entire line per level
    _LINE_COLOUR: dict[str, str] = {
        "DEBUG": _DIM + _GREY,
        "INFO": "",  # default terminal colour
        "WARNING": _YELLOW,
        "ERROR": _RED,
        "CRITICAL": _BRED,
    }

    # Colour applied to the level badge only
    _LEVEL_COLOUR: dict[str, str] = {
        "DEBUG": _DIM + _GREY,
        "INFO": _BOLD + _GREEN,
        "WARNING": _BOLD + _YELLOW,
        "ERROR": _BOLD + _RED,
        "CRITICAL": _BRED,
    }

    # Column widths
    _LEVEL_W = 8  # field width for level name
    _MODULE_W = 16  # field width for module/logger name

    def format(self, record: logging.LogRecord) -> str:
        level = record.levelname
        line_col = self._LINE_COLOUR.get(level, "")
        lvl_col = self._LEVEL_COLOUR.get(level, "")
        r = self._RESET

        # ── timestamp ───────────────────────────────────────────────────────
        time_str = self.formatTime(record, "%H:%M:%S")
        time_part = f"{self._DIM}{time_str}{r}"

        # ── level badge ─────────────────────────────────────────────────────
        level_part = f"{lvl_col}{level:<{self._LEVEL_W}}{r}"

        # ── module / logger name ────────────────────────────────────────────
        # Prefer the short module name; fall back to logger hierarchy leaf
        module_name = record.module or record.name.rsplit(".", 1)[-1]
        module_part = f"{self._CYAN}{module_name:<{self._MODULE_W}}{r}"

        # ── message ─────────────────────────────────────────────────────────
        msg = record.getMessage()
        if record.exc_info:
            msg += "\n" + self.formatException(record.exc_info)
        if record.stack_info:
            msg += "\n" + self.formatStack(record.stack_info)

        # Colour warnings / errors / critical messages for readability
        if line_col:
            msg_part = f"{line_col}{msg}{r}"
        else:
            msg_part = msg

        return f"{time_part}  {level_part}  {module_part}  {msg_part}"


# ---------------------------------------------------------------------------
# JSON formatter (production / log aggregation)
# ---------------------------------------------------------------------------


class JsonFormatter(logging.Formatter):
    """
    Single-line JSON log records for production pipelines and log aggregators.

    Each record emits::

        {"time":"2026-01-01T12:00:00.123Z","level":"INFO","logger":"django","message":"..."}

    Extra structured fields attached to the record (e.g. ``extra={'request_id': …}``)
    are included automatically.
    """

    # Standard LogRecord fields that we re-map under our own keys
    _RESERVED = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__.keys()) | {"message", "asctime"}

    def format(self, record: logging.LogRecord) -> str:
        record.message = record.getMessage()

        payload: dict = {
            "time": datetime.fromtimestamp(record.created, tz=UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "module": record.module,
            "message": record.message,
        }

        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        # Attach any extra fields added via ``logger.info("...", extra={...})``
        for key, value in record.__dict__.items():
            if key not in self._RESERVED and not key.startswith("_"):
                try:
                    json.dumps(value)  # only include JSON-serialisable values
                    payload[key] = value
                except (TypeError, ValueError):
                    payload[key] = str(value)

        return json.dumps(payload, ensure_ascii=False)
