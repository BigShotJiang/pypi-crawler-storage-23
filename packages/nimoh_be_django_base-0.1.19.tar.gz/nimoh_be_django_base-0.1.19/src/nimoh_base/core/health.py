"""
Core health check utilities.

Provides a single source of truth for dependency health checks
(database, cache, email, Celery) used across the application.
"""

import logging
import time
from typing import Any

from django.core.cache import cache
from django.db import connections

logger = logging.getLogger(__name__)


def check_database(alias: str = "default") -> dict[str, Any]:
    """
    Check database connectivity and measure response time.

    Args:
        alias: Database alias to check (default: 'default').

    Returns:
        Dict with 'status', 'response_time_ms', and 'details'.
    """
    start = time.perf_counter()
    try:
        db_conn = connections[alias]
        with db_conn.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return {
            "status": "healthy",
            "response_time_ms": elapsed,
            "details": f"{db_conn.vendor.title()} connection successful",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.error("Database health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "details": f"Database connection failed: {type(e).__name__}",
        }


def check_cache() -> dict[str, Any]:
    """
    Check Redis cache connectivity with a write/read/delete cycle.

    Returns:
        Dict with 'status', 'response_time_ms', and 'details'.
    """
    start = time.perf_counter()
    try:
        test_key = f"health_check_{int(time.time())}"
        test_value = "ok"
        cache.set(test_key, test_value, timeout=10)
        retrieved = cache.get(test_key)
        cache.delete(test_key)
        if retrieved != test_value:
            raise ValueError("Cache write/read mismatch")
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return {
            "status": "healthy",
            "response_time_ms": elapsed,
            "details": "Redis cache connection successful",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.warning("Cache health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "details": f"Cache connection failed: {type(e).__name__}",
        }


def check_email() -> dict[str, Any]:
    """
    Check email backend connectivity.

    Returns:
        Dict with 'status', 'response_time_ms', and 'details'.
    """
    start = time.perf_counter()
    try:
        from django.core.mail import get_connection

        conn = get_connection()
        conn.open()
        conn.close()
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return {
            "status": "healthy",
            "response_time_ms": elapsed,
            "details": "Email service connection successful",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.warning("Email health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "details": f"Email service connection failed: {type(e).__name__}",
        }


def check_celery(timeout: float = 2.0) -> dict[str, Any]:
    """
    Check Celery broker reachability and worker availability.

    Verifies broker connectivity first using a hard connection timeout
    (``max_retries=0``) before attempting the worker inspect, so the call
    fails fast instead of retrying for several seconds.

    Args:
        timeout: Seconds allowed for both the broker connection and the
                 worker-inspect reply (default: 2.0).

    Returns:
        Dict with 'status', 'response_time_ms', 'workers', and 'details'.

        Possible status values:

        - ``healthy``  -- broker reachable and at least one active worker.
        - ``degraded`` -- broker reachable but no workers responded.
        - ``unhealthy`` -- broker unreachable or connection timed out.
    """
    start = time.perf_counter()
    try:
        from celery import current_app

        # Verify broker is reachable first with a strict connection timeout.
        # inspect.active() alone does not bound the TCP connect time — kombu
        # retries for several seconds before raising, regardless of the
        # inspect `timeout` arg (which only limits the worker-reply wait).
        with current_app.connection(connect_timeout=timeout) as conn:
            conn.ensure_connection(max_retries=0)
            inspect = current_app.control.inspect(timeout=timeout)
            active_workers = inspect.active()

        elapsed = round((time.perf_counter() - start) * 1000, 2)
        if active_workers:
            return {
                "status": "healthy",
                "response_time_ms": elapsed,
                "workers": len(active_workers),
                "details": f"{len(active_workers)} active worker(s)",
            }
        return {
            "status": "degraded",
            "response_time_ms": elapsed,
            "workers": 0,
            "details": "Broker reachable but no active Celery workers found",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.warning("Celery health check failed: %s", type(e).__name__)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "workers": 0,
            "details": f"Celery broker unreachable: {type(e).__name__}",
        }
