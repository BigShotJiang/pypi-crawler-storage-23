"""
Management command to run startup checks with enhanced logging.
"""

from django.core.management.base import BaseCommand

from nimoh_base.core.startup import display_server_info, run_startup_checks


class Command(BaseCommand):
    help = "Run startup checks and display system information"

    def add_arguments(self, parser):
        parser.add_argument(
            "--host",
            default="0.0.0.0",  # nosec B104 - Intentional for containerized deployment
            help="Server host (default: 0.0.0.0)",
        )
        parser.add_argument(
            "--port",
            type=int,
            default=8004,
            help="Server port (default: 8000)",
        )

    def handle(self, *args, **options):
        """Execute the command."""
        host = options["host"]
        port = options["port"]

        # Run all startup checks
        all_ok = run_startup_checks()

        # Display server info
        display_server_info(host=host, port=port)

        if not all_ok:
            self.stdout.write(self.style.WARNING("Some startup checks failed but continuing..."))
