"""
nimoh_base.cli.config
======================
Load project configuration from a YAML file (``--config`` / ``--no-input`` mode).

Example YAML file
-----------------
.. code-block:: yaml

    project_name: My API
    project_slug: my_api
    description: "Backend for My Application"
    author: "Jane Smith"
    author_email: "jane@example.com"
    site_name: "My API"
    support_email: "support@myapi.example"
    noreply_email: "noreply@myapi.example"
    cache_key_prefix: "myapi"
    celery_app_name: "my_api"
    db_engine: postgresql
    db_name: my_api_db
    db_user: my_api_user
    db_password: changeme
    db_host: localhost
    db_port: 5432
    redis_url: "redis://localhost:6379/0"
    frontend_url: "http://localhost:3000"
    use_celery: true
    use_channels: true
    use_sendgrid: false
    use_monitoring: true
    use_privacy: true
    output_dir: "."
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nimoh_base.cli.prompts import ProjectConfig


def load_config(path: str | Path) -> ProjectConfig:
    """
    Parse *path* (YAML) and return a populated ``ProjectConfig``.

    Raises
    ------
    FileNotFoundError
        If *path* does not exist.
    ValueError
        If the YAML is invalid or contains unknown keys.
    """
    try:
        import yaml
    except ImportError as exc:
        raise ImportError("PyYAML is required for --config mode: pip install PyYAML") from exc

    from nimoh_base.cli.prompts import ProjectConfig

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with config_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    if not isinstance(data, dict):
        raise ValueError(f"Config file must be a YAML mapping, got {type(data).__name__}")

    valid_fields = {f.name for f in ProjectConfig.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    unknown = set(data.keys()) - valid_fields
    if unknown:
        raise ValueError(
            f"Unknown config keys: {', '.join(sorted(unknown))}. Valid keys: {', '.join(sorted(valid_fields))}"
        )

    cfg = ProjectConfig(**{k: v for k, v in data.items() if k in valid_fields})
    if not cfg.project_slug and cfg.project_name:
        cfg.project_slug = _auto_slug(cfg.project_name)
    return cfg


def _auto_slug(name: str) -> str:
    """Convert a human-readable project name to a Python identifier slug."""
    import re

    slug = re.sub(r"[^\w\s-]", "", name.lower())
    slug = re.sub(r"[\s-]+", "_", slug).strip("_")
    return slug or "my_app"


def dump_config_template(output_path: str | Path | None = None) -> str:
    """
    Return (and optionally write) a documented YAML config template with all fields.
    """
    from nimoh_base.cli.prompts import ProjectConfig, _gen_secret_key

    template_lines = [
        "# nimoh-base init configuration file",
        "# Pass to CLI with:  nimoh-base init --config this-file.yml",
        "",
    ]
    example = ProjectConfig(
        project_name="My Nimoh App",
        project_slug="my_nimoh_app",
        description="A Django project powered by nimoh-be-django-base",
        author="Your Name",
        author_email="you@example.com",
        django_secret_key=_gen_secret_key(),
        site_name="My Nimoh App",
        support_email="support@mynimohapp.example",
        noreply_email="noreply@mynimohapp.example",
        cache_key_prefix="mynimoh",
        celery_app_name="my_nimoh_app",
        db_engine="postgresql",
        db_name="my_nimoh_app_db",
        db_user="my_nimoh_app_user",
        db_password="changeme",
        db_host="localhost",
        db_port=5432,
        redis_url="redis://localhost:6379/0",
        frontend_url="http://localhost:3000",
        use_celery=True,
        use_channels=True,
        use_sendgrid=False,
        use_monitoring=True,
        use_privacy=True,
        output_dir=".",
    )
    # Produce simple YAML by hand to avoid a yaml dep at render time
    for f_name in example.__dataclass_fields__:  # type: ignore[attr-defined]
        val = getattr(example, f_name)
        if isinstance(val, bool):
            template_lines.append(f"{f_name}: {'true' if val else 'false'}")
        elif isinstance(val, int):
            template_lines.append(f"{f_name}: {val}")
        elif isinstance(val, str):
            safe = val.replace('"', '\\"')
            template_lines.append(f'{f_name}: "{safe}"')
        else:
            template_lines.append(f"{f_name}: {val!r}")

    content = "\n".join(template_lines) + "\n"

    if output_path is not None:
        Path(output_path).write_text(content, encoding="utf-8")

    return content
