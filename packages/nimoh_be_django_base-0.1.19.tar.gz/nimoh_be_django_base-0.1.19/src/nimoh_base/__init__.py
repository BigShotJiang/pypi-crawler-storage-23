"""
nimoh-be-django-base
====================
A reusable Django backend foundation providing authentication, monitoring,
privacy, security headers, and project-scaffolding tooling.

All package configuration is namespaced under a single ``NIMOH_BASE`` dict
in the consumer project's Django settings::

    NIMOH_BASE = {
        'SITE_NAME': 'My Application',
        'SUPPORT_EMAIL': 'support@example.com',
        'NOREPLY_EMAIL': 'noreply@example.com',
        # …see nimoh_base.conf for the full reference
    }
"""

__version__ = "0.1.0"
__author__ = "nimoh"
