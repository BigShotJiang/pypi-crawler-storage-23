from vectorDBpipe.config.config_manager import ConfigManager

__all__ = ["ConfigManager"]
