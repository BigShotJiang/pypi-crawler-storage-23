from nwon_baseline.import_helper.import_from_file import import_data_from_file

__all__ = ["import_data_from_file"]
