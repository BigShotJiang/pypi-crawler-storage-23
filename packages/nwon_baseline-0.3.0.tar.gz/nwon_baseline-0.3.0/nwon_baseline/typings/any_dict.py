from typing import Any, Dict

AnyDict = Dict[Any, Any]

__all__ = ["AnyDict"]
