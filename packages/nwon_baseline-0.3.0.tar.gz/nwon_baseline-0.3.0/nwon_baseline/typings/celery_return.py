from typing import Union

CeleryReturn = Union[str, int, None]
