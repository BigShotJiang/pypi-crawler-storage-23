# OoF
Python package for running Orbital Torus Imaging analysis on stellar data from the Latte suite of Feedback in Realistic Environments (FIRE) cosmological zoom-in simulations. 
