package_name = 'sgraph_ai_app_send'
path         = __path__[0]