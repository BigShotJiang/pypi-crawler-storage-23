Version 0.1 Updates
/////////////////////////


Version 0.1.1
===============

Fixes
+++++++++++++++

- fixed issue when nans were not propagated when computing quantiles with ``method=sort``


Version 0.1.0
===============

New features
+++++++++++++++

- added new submodules: :py:mod:`meteo.extreme`, :py:mod:`meteo.score` , :py:mod:`meteo.stats`, :py:mod:`meteo.thermo` and :py:mod:`meteo.wind`
