.. _examples:

Examples
============

Here is a list of example notebooks to illustrate how to use earthkit-meteo.


.. toctree::
    :maxdepth: 1

    return_period.ipynb
