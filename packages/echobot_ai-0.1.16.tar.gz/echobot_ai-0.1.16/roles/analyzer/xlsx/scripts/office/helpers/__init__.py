# 中文注释：
# 文件：roles/analyzer/xlsx/scripts/office/helpers/__init__.py
# 说明：Office/XLSX 处理脚本与校验逻辑。

