# 中文注释：
# 文件：roles/analyzer/xlsx/scripts/office/validators/__init__.py
# 说明：Office/XLSX 处理脚本与校验逻辑。

"""
Validation modules for Word document processing.
"""

from .base import BaseSchemaValidator
from .docx import DOCXSchemaValidator
from .pptx import PPTXSchemaValidator
from .redlining import RedliningValidator

__all__ = [
    "BaseSchemaValidator",
    "DOCXSchemaValidator",
    "PPTXSchemaValidator",
    "RedliningValidator",
]
