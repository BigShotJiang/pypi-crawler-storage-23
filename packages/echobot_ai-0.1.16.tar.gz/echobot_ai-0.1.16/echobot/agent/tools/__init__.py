# 中文注释：
# 文件：echobot/agent/tools/__init__.py
# 说明：智能体工具层，实现文件、Shell、网络与消息等工具调用能力。

"""Agent Tools Module - 工具模块
=================================================

此模块定义了 Agent 可用的工具（Tools）。

工具是什么：
- 工具是 Agent 与外部世界交互的接口
- 每个工具对应一种能力（读文件、执行命令、搜索等）
- 工具通过注册机制动态管理

内置工具：
1. 文件工具：
   - read_file: 读取文件内容
   - write_file: 写入文件
   - edit_file: 编辑文件
   - list_dir: 列出目录

2. Shell 工具：
   - exec: 执行 Shell 命令

3. Web 工具：
   - web_search: 搜索网络
   - web_fetch: 获取网页内容

4. 消息工具：
   - message: 发送消息给用户

5. 任务工具：
   - spawn: 创建后台子任务

主要类：
- Tool: 工具基类
- ToolRegistry: 工具注册表

使用示例：
    from echobot.agent.tools.base import Tool
    from echobot.agent.tools.registry import ToolRegistry
    
    registry = ToolRegistry()
    registry.register(ReadFileTool())
    
    result = await registry.execute("read_file", {"path": "test.txt"})
"""

from echobot.agent.tools.base import Tool
from echobot.agent.tools.registry import ToolRegistry

__all__ = ["Tool", "ToolRegistry"]
