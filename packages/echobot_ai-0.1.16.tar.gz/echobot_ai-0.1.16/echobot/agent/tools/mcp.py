# 中文注释：
# 文件：echobot/agent/tools/mcp.py
# 说明：MCP 工具适配器

"""MCP Tool adapter for integrating MCP servers with echobot tools."""

from typing import Any

from echobot.agent.mcp.client import MCPClient
from echobot.agent.tools.base import Tool


class MCPTool(Tool):
    """Tool adapter for MCP server tools."""

    def __init__(self, mcp_client: MCPClient, tool_definition: dict[str, Any]):
        """
        Initialize MCP tool.

        Args:
            mcp_client: The MCP client instance
            tool_definition: Tool definition from MCP server
        """
        self._mcp_client = mcp_client
        self._definition = tool_definition

    @property
    def name(self) -> str:
        """Tool name."""
        return self._definition["name"]

    @property
    def description(self) -> str:
        """Tool description."""
        return self._definition.get("description", "")

    @property
    def parameters(self) -> dict[str, Any]:
        """Tool parameters in JSON Schema format."""
        return self._definition.get("inputSchema", {
            "type": "object",
            "properties": {},
        })

    async def execute(self, **kwargs: Any) -> str:
        """Execute the MCP tool."""
        return await self._mcp_client.call_tool(self.name, kwargs)
