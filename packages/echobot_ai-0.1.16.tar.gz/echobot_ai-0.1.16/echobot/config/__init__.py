# 中文注释：
# 文件：echobot/config/__init__.py
# 说明：配置加载与配置模型定义。

"""Configuration module for echobot."""

from echobot.config.loader import (
    load_config,
    get_config_path,
    load_agents_config,
    get_agents_config_path,
    save_agents_config,
)
from echobot.config.schema import (
    Config,
    DingTalkConfig,
    MultiAgentsConfig,
    AgentInstanceConfig,
    AgentBinding,
    AgentBindingMatch,
    CollaborationConfig,
)

__all__ = [
    "Config",
    "DingTalkConfig",
    "load_config",
    "get_config_path",
    "load_agents_config",
    "get_agents_config_path",
    "save_agents_config",
    "MultiAgentsConfig",
    "AgentInstanceConfig",
    "AgentBinding",
    "AgentBindingMatch",
    "CollaborationConfig",
]
