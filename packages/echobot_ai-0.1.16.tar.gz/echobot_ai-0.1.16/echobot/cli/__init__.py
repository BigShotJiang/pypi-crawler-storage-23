# 中文注释：
# 文件：echobot/cli/__init__.py
# 说明：命令行入口与运维命令实现。

"""CLI module for echobot."""
