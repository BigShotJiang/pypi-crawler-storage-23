# frac.py - 0依赖分数类
from smath import fract
def _gcd(a, b):
    """自己实现最大公约数"""
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a

def is_int(floater):
    return int(floater) == floater
    
class frac:
    """轻量分数类 - 0依赖"""
    
    def __init__(self, numerator, denominator=None):
        if denominator is None:
             numerator, denominator = int(self._to_frac(numerator).n), int(self._to_frac(numerator).d)
        if denominator == 0:
            raise ValueError("分母不能为0")
        
        # 处理负号
        if denominator < 0:
            numerator = -numerator
            denominator = -denominator
        
        # 自己约分，不用 math
        g = _gcd(numerator, denominator)
        self.n = numerator // g
        self.d = denominator // g

    def __pow__(self, other):
        return float(self) ** float(self._to_frac(other))

    def __rpow__(self, other):
        """右幂运算：other ** self"""
        return float(other) ** float(self)
    
    def __add__(self, other):
        other = self._to_frac(other)
        return frac(
            self.n * other.d + other.n * self.d,
            self.d * other.d
        )
    
    def __sub__(self, other):
        other = self._to_frac(other)
        return frac(
            self.n * other.d - other.n * self.d,
            self.d * other.d
        )
    
    def __mul__(self, other):
        other = self._to_frac(other)
        return frac(self.n * other.n, self.d * other.d)
    
    def __truediv__(self, other):
        other = self._to_frac(other)
        if float(other) == 0:
            raise ZeroDivisionError("除数不能为0")
        return frac(self.n * other.d, self.d * other.n)
    
    def __eq__(self, other):
        other = self._to_frac(other)
        return self.n == other.n and self.d == other.d

    def __radd__(self, other):
        """右加法：other + self"""
        return self + other  # 直接复用 __add__
    
    def __rsub__(self, other):
        """右减法：other - self"""
        # 注意顺序：other - self
        return -self + other
    
    def __rmul__(self, other):
        """右乘法：other * self"""
        return self * other
    
    def __rtruediv__(self, other):
        """右除法：other / self"""
        # other / self = other * (1/self)
        return self._to_frac(other) * ~self
    
    def __rpow__(self, other):
        """右幂：other ** self"""
        return float(other) ** float(self)
    
    def __neg__(self):
        """负数：-self"""
        return frac(-self.n, self.d)
    
    def __pos__(self):
        """正数：+self"""
        return self
    
    def __abs__(self):
        """绝对值：abs(self)"""
        return frac(abs(self.n), self.d)

    def __invert__(self):
        """~frac 返回倒数"""
        return frac(self.d, self.n)
    
    def __float__(self):
        return self.n / self.d
    
    def __str__(self):
        return str(float(self))
    
    def __repr__(self):
        return f"{self.n}/{self.d}" if self.d != 1 else str(self.n)
    
    def _to_frac(self, other):
        if isinstance(other, frac):
            return other
        if isinstance(other, str) and not "e+" in other:
            other = float(other)
        elif isinstance(other, str) and "e+" in other:
            other = int(float(other))
        if isinstance(other, float) and is_int(other):
            return frac(other, 1)
        if isinstance(other, (float, int)):
            if isinstance(other, (float)):
                # 转成整数处理 (1.23 -> 123/100)
                s = str(other)
                if 'e' not in s:  # 不考虑科学计数法
                    parts = s.split('.')
                    if len(parts) == 2:
                        whole, dec = parts
                        n = int(whole + dec)
                        d = 10 ** len(dec)
                        return frac(n, d)
                else:
                    if "-" in s:
                        n = float(str(float(frac(s.split("e")[0]))).replace(".", ""))
                        n_tool = float(frac(s.split("e")[0]))
                        d = 10**(int(s.split("e")[1].split("-")[1])+len(str(n_tool).split(".")[1]))
                    return frac(n, d)
            return frac(other, 1)
        raise TypeError(f"不支持的类型: {type(other)}")
