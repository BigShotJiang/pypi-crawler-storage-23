"""Pretorin CLI and MCP server for Pretorin Compliance API."""

__version__ = "0.5.2"
