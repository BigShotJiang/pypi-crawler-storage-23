"""Pretorin autonomous compliance agent (requires `pip install pretorin[agent]`)."""
