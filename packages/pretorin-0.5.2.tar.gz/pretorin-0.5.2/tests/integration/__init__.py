"""Integration tests for Pretorin CLI.

These tests require a valid PRETORIN_API_KEY environment variable
and will make real API calls to the Pretorin platform.
"""
