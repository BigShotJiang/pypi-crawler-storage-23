"""Module to create and manage A2A clients for remote agents."""

import asyncio

import httpx
from a2a.client import (
    AuthInterceptor,
    ClientCallContext,
    ClientCallInterceptor,
    ClientConfig,
    ClientFactory,
    CredentialService,
)
from a2a.types import AgentCard, PushNotificationConfig

from aixtools.a2a.google_sdk.config import DEFAULT_A2A_TIMEOUT
from aixtools.a2a.google_sdk.remote_agent_connection import RemoteAgentConnection
from aixtools.a2a.google_sdk.utils import get_agent_card
from aixtools.auth_client.client import ClientAccessTokenProvider
from aixtools.context import SessionIdTuple
from aixtools.logging.logging_config import get_logger
from aixtools.server.utils import create_session_headers

logger = get_logger(__name__)


class _BearerCredentialService(CredentialService):
    """
    Bearer credential service providing a bearer type token if the security scheme is Bearer
    """

    def __init__(self):
        self.token_provider = ClientAccessTokenProvider()

    async def get_credentials(self, security_scheme_name: str, _: ClientCallContext):
        return self.token_provider.get_access_token()


class _AgentCardResolver:
    """Helper class to resolve and manage agent cards and their connections."""

    def __init__(
        self,
        client: httpx.AsyncClient,
        push_notification_configs: list[PushNotificationConfig] | None = None,
        interceptors: list[ClientCallInterceptor] | None = None,
    ):
        self._httpx_client = client
        self._a2a_client_factory = ClientFactory(
            ClientConfig(
                httpx_client=self._httpx_client,
                polling=True,
                streaming=False,  # TODO: re-enable streaming when supported
                push_notification_configs=push_notification_configs or [],
            )
        )
        self._interceptors = interceptors
        self.clients: dict[str, RemoteAgentConnection] = {}

    def register_agent_card(self, card: AgentCard):
        """Create a RemoteAgentConnection for the given agent card"""
        remote_connection = RemoteAgentConnection(
            card, client=self._a2a_client_factory.create(card, interceptors=self._interceptors)
        )
        self.clients[card.name] = remote_connection

    async def retrieve_card(self, address: str):
        """Retrieve and register the agent card from the given address."""
        try:
            card = await get_agent_card(self._httpx_client, address)
            self.register_agent_card(card)
            return
        except Exception as e:
            logger.error("Error retrieving agent card from %s: %s", address, str(e))
            return

    async def get_a2a_clients(self, agent_hosts: list[str]) -> dict[str, RemoteAgentConnection]:
        """Retrieve A2A clients for the given agent hosts."""
        async with asyncio.TaskGroup() as task_group:
            for address in agent_hosts:
                task_group.create_task(self.retrieve_card(address))

        return self.clients


def _build_interceptors(with_sso_interceptor: bool) -> list[ClientCallInterceptor]:
    """Adds AuthInterceptor if SSO is enabled and no auth token is provided."""
    return [AuthInterceptor(credential_service=_BearerCredentialService())] if with_sso_interceptor else []


async def get_a2a_clients(
    agent_hosts: list[str],
    session_id_tuple: SessionIdTuple,
    auth_token: str | None = None,
    push_notification_config_url: str | None = None,
    *,
    timeout: float = DEFAULT_A2A_TIMEOUT,
    with_sso_interceptor: bool = False,
) -> dict[str, RemoteAgentConnection]:
    """Get A2A clients for all agents defined in the configuration."""
    if with_sso_interceptor and auth_token:
        raise ValueError("Cannot use both SSO interceptor and auth token simultaneously.")

    push_notification_configs = (
        [PushNotificationConfig(url=push_notification_config_url)] if push_notification_config_url else None
    )

    headers = create_session_headers(session_id_tuple, auth_token)
    httpx_client = httpx.AsyncClient(headers=headers, timeout=timeout, follow_redirects=True)
    clients = await _AgentCardResolver(
        httpx_client,
        push_notification_configs=push_notification_configs,
        interceptors=_build_interceptors(with_sso_interceptor),
    ).get_a2a_clients(agent_hosts)
    for client in clients.values():
        logger.info("Using A2A server at: %s", client.get_agent_card().url)
    return clients
