"""Types for Google SDK integration in A2A."""

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from typing import TypedDict

from a2a.server.agent_execution import AgentExecutor
from a2a.types import AgentCard, Artifact, Part, TaskState
from pydantic import BaseModel, ConfigDict, Field
from pydantic_ai import AbstractToolset
from pydantic_ai.tools import ToolFuncEither
from sqlalchemy.ext.asyncio import AsyncEngine

from aixtools.a2a.google_sdk.remote_agent_connection import RemoteAgentConnection
from aixtools.skills.registry import SkillRegistry

AgentExecutorFactory = Callable[[AsyncEngine | None], AgentExecutor]
SystemPromptFactory = Callable[[SkillRegistry | None], str]
SkillRegistryFactory = Callable[[], SkillRegistry]
RemoteAgentsFactory = Callable[[], dict[str, RemoteAgentConnection]]


class TaskRegistry(ABC):
    """Interface for A2A Task Registry."""

    @abstractmethod
    def register_task(self, conversation_id: str, task_id: str | None, client: RemoteAgentConnection) -> None:
        """Register a task for a conversation. Being called when task is submitted."""

    @abstractmethod
    def unregister_task(self, conversation_id: str, task_id: str | None) -> None:
        """Unregister a task for a conversation. Being called when task is finished."""


class AgentParameters(BaseModel):
    """Parameters for configuring the Pydantic AI agent."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    system_prompt: str | None = Field(None, description="Static system prompt for the agent")
    system_prompt_fn: SystemPromptFactory | None = Field(
        None, description="Function to generate system prompt dynamically"
    )
    mcp_servers: list[str]
    skills_registry_factory: SkillRegistryFactory | None = Field(None, description="Skill registry factory")
    remote_agents_factory: RemoteAgentsFactory | None = Field(
        None, description="Factory function to provide remote agent connections"
    )
    task_registry: TaskRegistry | None = Field(None, description="Task registry for A2A task tracking")
    tools: list[ToolFuncEither] = Field(default_factory=list, description="Additional tools for the agent")
    toolsets: list[AbstractToolset] = Field(default_factory=list, description="Toolsets for the agent")


class RunOutput(BaseModel):
    """Output of the pydantic ai agent run."""

    is_task_failed: bool = Field(
        description="True only for unrecoverable errors (e.g., critical tool failure, missing required data that "
        "cannot be obtained). False for all normal interactions."
    )
    is_task_in_progress: bool = Field(
        description="True when there are more workflow steps remaining or further interaction is expected. False "
        "when the entire requested task is fully complete."
    )
    is_input_required: bool = Field(
        description="True when asking the user a question, presenting choices, or needing any information before "
        "proceeding. False when reporting results or providing final output with no pending question."
    )
    output: str = Field(description="The text message to show to the user.")
    created_artifacts_paths: list[str] = Field(
        description="File paths of artifacts created during this step (e.g., reports, spreadsheets, charts). "
        "Empty list when no files were created."
    )


class GetAgentCardResult(BaseModel):
    """Result of getting an agent card."""

    is_error: bool = Field(default=False, description="Indicates if there was an error with retrieving the agent card")
    agent_card: AgentCard | None = Field(..., description="The agent card that was retrieved")
    error: str | None = Field(default=None, description="Error message if operation failed")


class InvokeAgentResult(BaseModel):
    """Result of invoking a remote agent."""

    task_id: str = Field(..., description="The ID of the invoked remote agent task")
    state: TaskState = Field(..., description="The state of the invoked remote agent task")
    artifacts: list[Artifact] | None = Field(
        default=[],
        description="The artifacts generated during the remote agent task run",
    )
    text_message: str | None = Field(None, description="The text parts of the result of the remote agent task run")


class A2ATools(TypedDict):
    """Container for A2A tools."""

    invoke_agent: Callable[[str, list[Part], dict | None], Awaitable[InvokeAgentResult | None]]
    get_agent_card: Callable[[str], GetAgentCardResult]
