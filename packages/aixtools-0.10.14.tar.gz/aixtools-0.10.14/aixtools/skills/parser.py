"""Parser for SKILL.md files."""

import string
from dataclasses import dataclass
from pathlib import Path

import frontmatter

from aixtools.skills.manifest import SkillValidationError

SKILL_FILE_NAME = "SKILL.md"


@dataclass
class ParsedSkillMd:
    """Parsed content from a SKILL.md file."""

    name: str
    description: str
    instructions: str
    version: str | None
    metadata: dict[str, str]


MAX_NAME_LENGTH = 64
MAX_DESCRIPTION_LENGTH = 1024


def _validate_name(name: str) -> None:
    """Validate skill name according to Agent Skills specification.

    Name must be:
    - 1-64 characters
    - ASCII lowercase alphanumeric and hyphens only ([a-z0-9-])
    - Must not start or end with hyphen
    - Must not contain consecutive hyphens

    Raises:
        SkillValidationError: If name is invalid
    """
    if len(name) > MAX_NAME_LENGTH:
        raise SkillValidationError(f"Invalid skill name '{name}': exceeds {MAX_NAME_LENGTH} characters")

    allowed_chars = string.ascii_lowercase + string.digits + "-"
    if not all(c in allowed_chars for c in name):
        raise SkillValidationError(f"Invalid skill name '{name}': only lowercase letters, numbers, and hyphens allowed")

    if name.startswith("-") or name.endswith("-"):
        raise SkillValidationError(f"Invalid skill name '{name}': must not start or end with hyphen")

    if "--" in name:
        raise SkillValidationError(f"Invalid skill name '{name}': consecutive hyphens not allowed")


def _validate_description(description: str) -> None:
    """Validate skill description according to Agent Skills specification.

    Description must be 1-1024 characters.

    Raises:
        SkillValidationError: If description is invalid
    """
    if len(description) > MAX_DESCRIPTION_LENGTH:
        raise SkillValidationError(f"Invalid skill description: exceeds {MAX_DESCRIPTION_LENGTH} characters")


def parse_skill_md(skill_dir: Path) -> ParsedSkillMd:
    """Parse SKILL.md and return structured data.

    Args:
        skill_dir: Directory containing SKILL.md

    Returns:
        ParsedSkillMd with extracted fields

    Raises:
        SkillValidationError: If file missing, invalid format, or invalid fields
    """
    skill_file = skill_dir / SKILL_FILE_NAME
    if not skill_file.exists():
        raise SkillValidationError(f"Missing {SKILL_FILE_NAME}")

    try:
        data = frontmatter.load(str(skill_file))
    except Exception as e:
        raise SkillValidationError(f"Invalid {SKILL_FILE_NAME} format: {e}") from e

    name = data.metadata.get("name")
    description = data.metadata.get("description")

    # Validate name field
    if name is None:
        raise SkillValidationError("SKILL.md missing required 'name' field")
    if not isinstance(name, str):
        raise SkillValidationError(f"SKILL.md 'name' field must be a string, got {type(name).__name__}")
    if not name:
        raise SkillValidationError("SKILL.md 'name' field must not be empty")
    _validate_name(name)

    # Validate description field
    if description is None:
        raise SkillValidationError("SKILL.md missing required 'description' field")
    if not isinstance(description, str):
        raise SkillValidationError(f"SKILL.md 'description' field must be a string, got {type(description).__name__}")
    if not description:
        raise SkillValidationError("SKILL.md 'description' field must not be empty")
    _validate_description(description)

    raw_metadata = data.metadata.get("metadata", {})
    metadata = {k: str(v) for k, v in raw_metadata.items()} if isinstance(raw_metadata, dict) else {}

    # Coerce version to string if present (YAML may parse numeric versions as float/int)
    raw_version = data.metadata.get("version")
    version = str(raw_version) if raw_version is not None else None

    return ParsedSkillMd(
        name=name,
        description=description,
        instructions=data.content.strip(),
        version=version,
        metadata=metadata,
    )
