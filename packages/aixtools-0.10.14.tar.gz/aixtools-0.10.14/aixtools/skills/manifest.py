"""Models and storage for user skill manifests."""

import uuid
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path

from pydantic import BaseModel, Field


class SkillSource(str, Enum):
    """Source type for user skills."""

    UPLOAD = "upload"  # uploaded via ZIP
    # GITHUB = "github"  # TODO: future support


class UserSkillEntry(BaseModel):
    """Entry in the user's skills manifest."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), description="Unique skill identifier")
    name: str = Field(description="Skill name (from SKILL.md)")
    source: SkillSource = Field(default=SkillSource.UPLOAD)
    description: str = Field(description="Skill description (from SKILL.md)")
    installed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    version: str | None = Field(default=None, description="Version if specified in SKILL.md")
    has_custom_image: bool = Field(
        default=False, description="Whether skill specifies a custom sandbox_image (vs default)"
    )
    sandbox_image: str | None = Field(
        default=None, description="Custom sandbox image if configured, None means use default"
    )


class UserSkillsManifest(BaseModel):
    """User's skills manifest schema."""

    version: str = Field(default="1.0")
    skills: list[UserSkillEntry] = Field(default_factory=list)

    def get_skill_by_id(self, skill_id: str) -> UserSkillEntry | None:
        """Get a skill entry by ID."""
        return next((s for s in self.skills if s.id == skill_id), None)

    def get_skill_by_name(self, name: str) -> UserSkillEntry | None:
        """Get a skill entry by name."""
        return next((s for s in self.skills if s.name == name), None)

    def add_skill(self, entry: UserSkillEntry) -> None:
        """Add or update a skill entry. Updates existing skill with same ID."""
        self.skills = [s for s in self.skills if s.id != entry.id]
        self.skills.append(entry)

    def remove_skill_by_id(self, skill_id: str) -> bool:
        """Remove a skill entry by ID. Returns True if found and removed."""
        original_len = len(self.skills)
        self.skills = [s for s in self.skills if s.id != skill_id]
        return len(self.skills) < original_len


class ManifestStore:
    """Generic filesystem-based manifest storage.

    This store is path-agnostic - callers provide the full path
    to the manifest file. This allows different applications to
    use their own directory conventions.
    """

    def load(self, path: Path) -> UserSkillsManifest:
        """Load manifest from path, returning empty manifest if doesn't exist."""
        if path.exists():
            return UserSkillsManifest.model_validate_json(path.read_text())
        return UserSkillsManifest()

    def save(self, path: Path, manifest: UserSkillsManifest) -> None:
        """Save manifest to path, creating parent directories if needed."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(manifest.model_dump_json(indent=2))


class SkillValidationError(Exception):
    """Raised when skill validation fails."""


class SkillNotFoundError(Exception):
    """Raised when skill is not found."""
