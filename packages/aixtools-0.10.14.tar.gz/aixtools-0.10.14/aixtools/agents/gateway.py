"""
AI Gateway integration for AIXtools.

Provides unified access to multiple cloud AI providers through an AI Gateway
proxy service. Supports AWS Bedrock, Azure OpenAI, and Google Vertex AI backends.

Configuration
=============

Set these environment variables::

    MODEL_FAMILY=ai-gateway
    AI_GATEWAY_URL=https://your-gateway.example.net
    AI_GATEWAY_KEY=your-subscription-key
    AI_GATEWAY_MODEL_NAME=us.anthropic.claude-sonnet-4-5-20250929-v1:0

The backend provider is auto-detected from the model name. Override with AI_GATEWAY_PROVIDER
if auto-detection fails (bedrock | azure | vertex-openai).
"""

import os

import boto3
from botocore.config import Config
from openai import AsyncAzureOpenAI, AsyncOpenAI
from pydantic_ai.models.bedrock import BedrockConverseModel
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.bedrock import BedrockProvider
from pydantic_ai.providers.openai import OpenAIProvider

from aixtools.logging.logging_config import get_logger

logger = get_logger(__name__)


def infer_gateway_provider(model_name: str) -> str:
    """Infer the gateway backend provider from model name patterns.

    - Bedrock: anthropic.*, amazon.*, meta.*, cohere.*, google.gemma-* prefixes
    - Azure: gpt-*, o1/o3/o4-*, deepseek-*, grok-*, text-embedding-* models
    - Vertex AI: gemini-*, google/* models
    """
    model_lower = model_name.lower()

    # Bedrock: AWS-hosted models (Anthropic, Amazon, Meta, Cohere, Google Gemma)
    bedrock_prefixes = ("anthropic.", "amazon.", "meta.", "cohere.", "us.", "google.gemma")
    if model_lower.startswith(bedrock_prefixes):
        return "bedrock"

    # Azure: OpenAI models, DeepSeek, Grok, and embeddings
    azure_prefixes = ("gpt-", "o1", "o3", "o4-", "deepseek", "grok-", "text-embedding-")
    if model_lower.startswith(azure_prefixes):
        return "azure"

    # Vertex AI: Google Gemini models (native and OpenAI-compatible)
    if model_lower.startswith(("gemini-", "google/")):
        return "vertex-openai"

    raise ValueError(
        f"Cannot infer AI_GATEWAY_PROVIDER from model '{model_name}'. "
        "Set AI_GATEWAY_PROVIDER explicitly (bedrock | azure | vertex-openai)"
    )


def get_model_gateway_bedrock(gateway_url: str, gateway_key: str, model_name: str):
    """Create Bedrock model via AI Gateway proxy.

    Note: Sets AWS_BEARER_TOKEN_BEDROCK environment variable which is process-global.
    Concurrent calls with different gateway keys may experience race conditions.
    """
    logger.debug("Bedrock gateway_url: %s", gateway_url)
    logger.debug("Bedrock gateway_key set: %s", bool(gateway_key))
    logger.debug("Bedrock model_name: %s", model_name)

    os.environ["AWS_BEARER_TOKEN_BEDROCK"] = gateway_key
    bedrock_client = boto3.client(
        service_name="bedrock-runtime",
        region_name="us-east-1",
        endpoint_url=f"{gateway_url}/bedrock",
        aws_access_key_id="",
        aws_secret_access_key="",
        config=Config(retries={"max_attempts": 0}),
    )
    return BedrockConverseModel(model_name=model_name, provider=BedrockProvider(bedrock_client=bedrock_client))


def get_model_gateway_azure(gateway_url: str, gateway_key: str, model_name: str):
    """Create Azure OpenAI model via AI Gateway proxy."""
    client = AsyncAzureOpenAI(
        azure_endpoint=f"{gateway_url}/azure-openai",
        api_version="2025-01-01-preview",
        api_key=gateway_key,
    )
    return OpenAIChatModel(model_name, provider=OpenAIProvider(openai_client=client))


def get_model_gateway_vertex_openai(gateway_url: str, gateway_key: str, model_name: str):
    """Create Vertex AI model via AI Gateway proxy using OpenAI-compatible endpoint."""
    client = AsyncOpenAI(
        base_url=f"{gateway_url}/vertex-ai-openai/v1",
        api_key=gateway_key,
    )
    return OpenAIChatModel(model_name, provider=OpenAIProvider(openai_client=client))


def get_model_ai_gateway(
    gateway_url=None,
    gateway_key=None,
    gateway_provider=None,
    model_name=None,
):
    """Create model via AI Gateway proxy with auto-detected provider.

    Args:
        gateway_url: AI Gateway base URL (default: AI_GATEWAY_URL env var)
        gateway_key: API subscription key (default: AI_GATEWAY_KEY env var)
        gateway_provider: Override auto-detection (bedrock | azure | vertex-openai)
        model_name: Model ID (default: AI_GATEWAY_MODEL_NAME env var)

    Returns:
        PydanticAI model instance configured for the gateway
    """
    # Read from env at call time (not import time) to allow runtime overrides
    gateway_url = gateway_url or os.environ.get("AI_GATEWAY_URL")
    gateway_key = gateway_key or os.environ.get("AI_GATEWAY_KEY")
    gateway_provider = gateway_provider or os.environ.get("AI_GATEWAY_PROVIDER")
    model_name = model_name or os.environ.get("AI_GATEWAY_MODEL_NAME")

    logger.debug("AI Gateway - URL: %s", gateway_url)
    logger.debug("AI Gateway - Key set: %s", bool(gateway_key))
    logger.debug("AI Gateway - Model: %s, Provider: %s", model_name, gateway_provider or "auto-detect")

    assert gateway_url, "AI_GATEWAY_URL is not set"
    assert gateway_key, "AI_GATEWAY_KEY is not set"
    assert model_name, "AI_GATEWAY_MODEL_NAME is not set"

    # Auto-detect provider if not explicitly set
    if not gateway_provider:
        gateway_provider = infer_gateway_provider(model_name)

    match gateway_provider:
        case "bedrock":
            return get_model_gateway_bedrock(gateway_url, gateway_key, model_name)
        case "azure":
            return get_model_gateway_azure(gateway_url, gateway_key, model_name)
        case "vertex-openai":
            return get_model_gateway_vertex_openai(gateway_url, gateway_key, model_name)
        case _:
            raise ValueError(f"AI_GATEWAY_PROVIDER '{gateway_provider}' not supported")
