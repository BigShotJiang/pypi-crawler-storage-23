# SPDX-FileCopyrightText: Copyright (c) 2024-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

from ._assets import AssetLocatedCallback, AssetProgress, AssetProgressCallback, AssetType, AssetValidatedCallback
from ._atomic_asset_checker import AnchoredAssetPathsChecker, SupportedFileTypesChecker, UsdzUdimLimitationChecker
from ._base_rule_checker import BaseRuleChecker
from ._base_rules import (
    ByteAlignmentChecker,
    CompressionChecker,
    ExtentsChecker,
    KindChecker,
    MissingReferenceChecker,
    NormalMapTextureChecker,
    PortableAssetPathChecker,
    PrimEncapsulationChecker,
    StageMetadataChecker,
    TextureChecker,
    TypeChecker,
    UsdzPackageValidator,
)
from ._capabilities import Capability, CapabilityRegistry
from ._categories import (
    CategoryRuleRegistry,
    add_registry_rule_callback,
    get_category_rules_registry,
    register_rule,
)
from ._cli import ValidationArgsExec, ValidationNamespaceExec, cli_main, create_validation_parser
from ._compliance_checker import ComplianceChecker
from ._compliance_runners import (
    AsyncComplianceCheckerRunner,
    ComplianceCheckerEvent,
    ComplianceCheckerEventRule,
    ComplianceCheckerEventType,
)
from ._context_managers import (
    MAXIMUM_BATCH_SIZE,
    MAXIMUM_COUNT_SIZE,
    AsyncBatchRunner,
    AsyncCounter,
    DelegateContextManager,
    PeriodicCallback,
)
from ._csv_reports import IssueCSVData
from ._default_categories import DefaultCategoryRules
from ._engine import ValidationEngine
from ._events import EventListener, EventStream, create_event_stream
from ._expression import _common_pattern, _PatternTree
from ._features import Feature, FeatureRegistry
from ._fix import AuthoringLayers, FixResult, FixResultList, FixStatus, IssueFixer
from ._geometry_checker import (
    IndexedPrimvarChecker,
    ManifoldChecker,
    NormalsExistChecker,
    NormalsValidChecker,
    NormalsWindingsChecker,
    SubdivisionSchemeChecker,
    UnusedMeshTopologyChecker,
    UnusedPrimvarChecker,
    ValidateTopologyChecker,
    WeldChecker,
    ZeroAreaFaceChecker,
    _AssetOriginPositioningChecker,
    _ContainsMeshChecker,
)
from ._hierarchy_rules import _HierarchyHasRootChecker, _RootPrimXformableChecker
from ._identifiers import (
    AttributeId,
    AtType,
    EditTargetId,
    EditTargetIdList,
    Identifier,
    LayerId,
    PrimId,
    PrimvarId,
    PropertyId,
    SchemaBaseId,
    SpecId,
    SpecIdList,
    StageId,
    VariantIdMixin,
    to_identifier,
    to_identifiers,
)
from ._import_utils import default_implementation, default_implementation_method
from ._issues import (
    Issue,
    IssueGroupBy,
    IssueGroupsBy,
    IssuePredicate,
    IssuePredicates,
    IssueSeverity,
    IssuesList,
    Suggestion,
)
from ._json_reports import IssueJSONEncoder, export_json_file
from ._layer_checker import LayerSpecChecker, UsdAsciiPerformanceChecker
from ._layout_checker import DanglingOverPrimChecker, DefaultPrimChecker
from ._material_checker import (
    MaterialOldMdlSchemaChecker,
    MaterialOutOfScopeChecker,
    MaterialPathChecker,
    MaterialUsdPreviewSurfaceChecker,
    ShaderImplementationSourceChecker,
    UsdDanglingMaterialBinding,
    UsdMaterialBindingApi,
)
from ._mesh_tools import (
    RepeatedValuesSet,
    check_manifold_elements,
    has_empty_faces,
    has_indexable_values,
    has_invalid_indices,
    has_invalid_primvar_indices,
    has_unreferenced_primvar,
    has_unreferenced_values,
    has_weldable_points,
    is_typename_array,
    remove_unused_values_and_remap_indices,
)
from ._misc_checker import SkelBindingAPIAppliedChecker, UsdGeomSubsetChecker, UsdLuxSchemaChecker
from ._omni_utils import is_omni_path
from ._parameters import Parameter, ParameterMapping, ParameterType, UserParameter
from ._performance_checker import (
    AlmostExtremeExtentChecker,
    BaseBoundsChecker,
    BoundsLimit,
    PointsPrecisionChecker,
    PointsPrecisionErrorChecker,
    PointsPrecisionWarningChecker,
    PrecisionLimit,
)
from ._physics_checker import ArticulationChecker, ColliderChecker, MassChecker, PhysicsJointChecker, RigidBodyChecker
from ._profiles import Profile, ProfileRegistry
from ._requirements import (
    Requirement,
    RequirementsRegistry,
    add_registry_requirement_callback,
    register_requirements,
    unregister_requirements,
)
from ._results import Results, ResultsList, to_issues_list
from ._semver import SemVer
from ._stats import ValidationStats
from ._units_rules import _UnitsInMetersChecker, _UpAxisZChecker
from ._url_utils import make_relative_url_if_possible, normalize_url
from ._usd_utils import get_sdf_type_for_shader_property
from ._usd_validator_adapter import (
    UsdValidatorAdapter,
    ValidatorErrorProtocol,
    ValidatorErrorSiteProtocol,
    ValidatorProtocol,
)
from ._utf8_checker import UnicodeNameChecker
from ._version import __version__, get_version

__all__ = [
    "AlmostExtremeExtentChecker",
    "AnchoredAssetPathsChecker",
    "ArticulationChecker",
    "AssetLocatedCallback",
    "AssetProgress",
    "AssetProgressCallback",
    "AssetType",
    "AssetValidatedCallback",
    "AsyncComplianceCheckerRunner",
    "AtType",
    "AttributeId",
    "AuthoringLayers",
    "BaseBoundsChecker",
    "BaseRuleChecker",
    "BoundsLimit",
    "ByteAlignmentChecker",
    "Capability",
    "CapabilityRegistry",
    "CategoryRuleRegistry",
    "ColliderChecker",
    "ComplianceChecker",
    "ComplianceCheckerEvent",
    "ComplianceCheckerEventRule",
    "ComplianceCheckerEventType",
    "CompressionChecker",
    "DanglingOverPrimChecker",
    "DefaultCategoryRules",
    "DefaultPrimChecker",
    "EditTargetId",
    "EditTargetIdList",
    "EventListener",
    "EventStream",
    "ExtentsChecker",
    "Feature",
    "FeatureRegistry",
    "FixResult",
    "FixResultList",
    "FixStatus",
    "Identifier",
    "IndexedPrimvarChecker",
    "Issue",
    "IssueCSVData",
    "IssueFixer",
    "IssueGroupBy",
    "IssueGroupsBy",
    "IssueJSONEncoder",
    "IssuePredicate",
    "IssuePredicates",
    "IssueSeverity",
    "IssuesList",
    "KindChecker",
    "LayerId",
    "LayerSpecChecker",
    "ManifoldChecker",
    "MassChecker",
    "MaterialOldMdlSchemaChecker",
    "MaterialOutOfScopeChecker",
    "MaterialPathChecker",
    "MaterialUsdPreviewSurfaceChecker",
    "MissingReferenceChecker",
    "NormalMapTextureChecker",
    "NormalsExistChecker",
    "NormalsValidChecker",
    "NormalsWindingsChecker",
    "Parameter",
    "ParameterMapping",
    "ParameterType",
    "PhysicsJointChecker",
    "PointsPrecisionChecker",
    "PointsPrecisionErrorChecker",
    "PointsPrecisionWarningChecker",
    "PortableAssetPathChecker",
    "PrecisionLimit",
    "PrimEncapsulationChecker",
    "PrimId",
    "PrimvarId",
    "Profile",
    "ProfileRegistry",
    "PropertyId",
    "RepeatedValuesSet",
    "Requirement",
    "RequirementsRegistry",
    "Results",
    "ResultsList",
    "RigidBodyChecker",
    "SchemaBaseId",
    "SemVer",
    "ShaderImplementationSourceChecker",
    "SkelBindingAPIAppliedChecker",
    "SpecId",
    "SpecIdList",
    "StageId",
    "StageMetadataChecker",
    "SubdivisionSchemeChecker",
    "Suggestion",
    "SupportedFileTypesChecker",
    "TextureChecker",
    "TypeChecker",
    "UnicodeNameChecker",
    "UnusedMeshTopologyChecker",
    "UnusedPrimvarChecker",
    "UsdAsciiPerformanceChecker",
    "UsdDanglingMaterialBinding",
    "UsdGeomSubsetChecker",
    "UsdLuxSchemaChecker",
    "UsdMaterialBindingApi",
    "UsdValidatorAdapter",
    "UsdzPackageValidator",
    "UsdzUdimLimitationChecker",
    "UserParameter",
    "ValidateTopologyChecker",
    "ValidationArgsExec",
    "ValidationEngine",
    "ValidationNamespaceExec",
    "ValidationStats",
    "ValidatorErrorProtocol",
    "ValidatorErrorSiteProtocol",
    "ValidatorProtocol",
    "VariantIdMixin",
    "WeldChecker",
    "ZeroAreaFaceChecker",
    "_AssetOriginPositioningChecker",
    "_ContainsMeshChecker",
    "_HierarchyHasRootChecker",
    "_PatternTree",
    "_RootPrimXformableChecker",
    "_UnitsInMetersChecker",
    "_UpAxisZChecker",
    "__version__",
    "_common_pattern",
    "add_registry_requirement_callback",
    "add_registry_rule_callback",
    "check_manifold_elements",
    "cli_main",
    "create_event_stream",
    "create_validation_parser",
    "default_implementation",
    "default_implementation_method",
    "export_json_file",
    "get_category_rules_registry",
    "get_sdf_type_for_shader_property",
    "get_version",
    "has_empty_faces",
    "has_indexable_values",
    "has_invalid_indices",
    "has_invalid_primvar_indices",
    "has_unreferenced_primvar",
    "has_unreferenced_values",
    "has_weldable_points",
    "is_omni_path",
    "is_typename_array",
    "make_relative_url_if_possible",
    "normalize_url",
    "register_requirements",
    "register_rule",
    "remove_unused_values_and_remap_indices",
    "to_identifier",
    "to_identifiers",
    "to_issues_list",
    "unregister_requirements",
]
