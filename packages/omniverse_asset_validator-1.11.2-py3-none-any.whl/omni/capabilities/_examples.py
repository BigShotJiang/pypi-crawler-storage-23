# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

from dataclasses import dataclass
from enum import Enum
from functools import cached_property
from importlib.resources import files


class ExampleResult(str, Enum):
    """
    Args:
        SUCCESS: The example succeeded.
        FAILURE: The example failed.
    """

    SUCCESS = "success"
    FAILURE = "failure"


class ExampleSnippetLanguage(str, Enum):
    """
    Args:
        PYTHON: The example snippet is in Python.
        USD: The example snippet is in USD.
    """

    PYTHON = "python"
    USD = "usd"


@dataclass(frozen=True)
class ExampleSnippet:
    """
    Args:
        language: The language of the example snippet.
        content: The content of the example snippet (lazy-loaded from file).
    """

    language: ExampleSnippetLanguage
    path: str

    @cached_property
    def content(self) -> str:
        resource_files = files(__package__) / "resources" / "examples" / self.path
        return resource_files.read_text(encoding='utf-8')


@dataclass(frozen=True)
class Example:
    """
    Args:
        snippet: The snippet of code in a specific language.
        name: The name of the example.
        result: The result of the example.
    """

    snippet: ExampleSnippet
    display_name: str
    result: ExampleResult


class Examples(Example, Enum):
    """
    An enumeration of all examples.
    """
    WRONG_SCHEMA_NAME_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/c536337f94d6.usd"),
        "Wrong schema name",
        ExampleResult.FAILURE,
    )
    MISSING_SCHEMA_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/5f9fcf60e7fa.usd"),
        "Missing schema",
        ExampleResult.FAILURE,
    )
    CORRECT_SCHEMA_USAGE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/d5b20f0af146.usd"),
        "Correct schema usage",
        ExampleResult.SUCCESS,
    )
    NO_API_INSTANCE_NAME_TAXONOMY__NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/d22af09d4d2e.usd"),
        "No API instance name (taxonomy)",
        ExampleResult.FAILURE,
    )
    TIME_SAMPLED_SEMANTIC_LABELS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/015426938bd9.usd"),
        "Time-sampled semantic labels",
        ExampleResult.FAILURE,
    )
    CONSTANT_SEMANTIC_LABELS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/f59a1e074f6a.usd"),
        "Constant semantic labels",
        ExampleResult.SUCCESS,
    )
    NO_SEMANTIC_LABELS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/2f2fa557aa97.usd"),
        "No semantic labels",
        ExampleResult.FAILURE,
    )
    LABELED_WITH_WIKIDATA_Q_CODE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/4c581f66ec9f.usd"),
        "Labeled with Wikidata Q-Code",
        ExampleResult.SUCCESS,
    )
    NON_EXISTENT_Q_CODE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/eaf0928d41d1.usd"),
        "Non-existent Q-Code",
        ExampleResult.FAILURE,
    )
    Q_CODE_FOR_WRONG_CONCEPT_TYPE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/3a5112836bdc.usd"),
        "Q-Code for wrong concept type",
        ExampleResult.FAILURE,
    )
    INCORRECT_Q_CODE_FORMAT_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/d77805a3c964.usd"),
        "Incorrect Q-Code format",
        ExampleResult.FAILURE,
    )
    EMPTY_ARRAY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/fea09720eddf.usd"),
        "Empty array",
        ExampleResult.FAILURE,
    )
    EXISTING_AND_APPROPRIATE_Q_CODE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="00/a6615727dcbd.usd"),
        "Existing and appropriate Q-Code",
        ExampleResult.SUCCESS,
    )
    ATTRIBUTES_ON_GEOMETRY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/42d548491dea.usd"),
        "Attributes on geometry",
        ExampleResult.FAILURE,
    )
    ATTRIBUTES_ON_BOUND_MATERIAL_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/e14977912bb8.usd"),
        "Attributes on bound material",
        ExampleResult.SUCCESS,
    )
    NO_COATING_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/9ea469e25c80.usd"),
        "No coating specified",
        ExampleResult.FAILURE,
    )
    COATING_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/db78319c95eb.usd"),
        "Coating specified",
        ExampleResult.SUCCESS,
    )
    TIME_VARYING_PROPERTIES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/6a9646b37dd0.usd"),
        "Time-varying properties",
        ExampleResult.FAILURE,
    )
    STATIC_PROPERTIES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/a86d845b778b.usd"),
        "Static properties",
        ExampleResult.SUCCESS,
    )
    INCONSISTENT_ATTRIBUTES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/d1e3cac25d86.usd"),
        "Inconsistent attributes",
        ExampleResult.FAILURE,
    )
    CONSISTENT_ATTRIBUTES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/82e8138d517e.usd"),
        "Consistent attributes",
        ExampleResult.SUCCESS,
    )
    NO_BASE_MATERIAL_TYPE_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/838d5944f69c.usd"),
        "No base material type specified",
        ExampleResult.FAILURE,
    )
    BASE_MATERIAL_TYPE_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/db78319c95eb.usd"),
        "Base material type specified",
        ExampleResult.SUCCESS,
    )
    NO_ATTRIBUTES_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/edcb672a6776.usd"),
        "No attributes specified",
        ExampleResult.FAILURE,
    )
    ATTRIBUTES_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/ebd273a1eb51.usd"),
        "Attributes specified",
        ExampleResult.SUCCESS,
    )
    COINCIDENT_MESHES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="01/120b882a9833.usd"),
        "Coincident meshes",
        ExampleResult.FAILURE,
    )
    MESHES_WITH_PROPER_SPACING_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/5479443d3f56.usd"),
        "Meshes with proper spacing",
        ExampleResult.SUCCESS,
    )
    DEGENERATE_FACES_AND_INVALID_INDICES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/2ebd0d916c9b.usd"),
        "Degenerate faces and invalid indices",
        ExampleResult.FAILURE,
    )
    PROPER_TOPOLOGY_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/b6e495b692f5.usd"),
        "Proper topology",
        ExampleResult.SUCCESS,
    )
    TRIANGLE_WITH_INCONSISTENT_WINDING_ORDER_AND_NORMALS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/c334b91c9672.usd"),
        "Triangle with inconsistent winding order and normals",
        ExampleResult.FAILURE,
    )
    ZERO_EXTENT_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/82fa6f3b3ac1.usd"),
        "Zero extent",
        ExampleResult.FAILURE,
    )
    MESH_HAS_NONZERO_EXTENT_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/792d2542acaa.usd"),
        "Mesh has nonzero extent",
        ExampleResult.SUCCESS,
    )
    NON_MANIFOLD_EDGE_DUE_TO_INCONSISTENT_WINDING_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/3d5baf1c77b8.usd"),
        "Non-manifold edge due to inconsistent winding",
        ExampleResult.FAILURE,
    )
    MANIFOLD_MESH_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/90b35f9ae887.usd"),
        "Manifold mesh",
        ExampleResult.SUCCESS,
    )
    INVISIBLE_PRIM_CONSUMING_RESOURCES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/61159d4ac695.usd"),
        "Invisible prim consuming resources",
        ExampleResult.FAILURE,
    )
    DEACTIVATED_PRIM_EXCLUDED_FROM_TRAVERSAL_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/8438e5579a1a.usd"),
        "Deactivated prim excluded from traversal",
        ExampleResult.SUCCESS,
    )
    INCONSISTENT_WINDING_ORDER_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/7dfd94ef0098.usd"),
        "Inconsistent winding order",
        ExampleResult.FAILURE,
    )
    UNNECESSARY_SUBDIVISION_ON_SIMPLE_SHAPE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/73d14a824a24.usd"),
        "Unnecessary subdivision on simple shape",
        ExampleResult.FAILURE,
    )
    NO_SUBDIVISION_FOR_SIMPLE_SHAPE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="02/d73c83879ffe.usd"),
        "No subdivision for simple shape",
        ExampleResult.SUCCESS,
    )
    SOFT_EDGE_BETWEEN_TWO_FACES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/8254eb4eedd8.usd"),
        "Soft edge between two faces",
        ExampleResult.SUCCESS,
    )
    HARD_EDGE_BETWEEN_TWO_FACES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/719a688b955c.usd"),
        "Hard edge between two faces",
        ExampleResult.SUCCESS,
    )
    NO_NORMALS_TO_DEFINE_SOFT_OR_HARD_EDGE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/02af8fef4c08.usd"),
        "No normals to define soft or hard edge",
        ExampleResult.FAILURE,
    )
    BOTH_NORMALS_AND_PRIMVARS_NORMALS_EXIST_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/d9afe93fedea.usd"),
        "Both `normals` and `primvars:normals` exist",
        ExampleResult.FAILURE,
    )
    ONLY_PRIMVARS_NORMALS_EXISTS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/088c32bfae76.usd"),
        "Only `primvars:normals` exists",
        ExampleResult.SUCCESS,
    )
    IDENTICAL_TIME_SAMPLES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/e8a658439f16.usd"),
        "Identical time samples",
        ExampleResult.FAILURE,
    )
    NO_TIME_SAMPLES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/59e4d07a6d7d.usd"),
        "No time samples",
        ExampleResult.SUCCESS,
    )
    SOME_IDENTICAL_TIME_SAMPLES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/054e31dbb16e.usd"),
        "Some identical time samples",
        ExampleResult.FAILURE,
    )
    NO_SEQUENTIAL_IDENTICAL_TIME_SAMPLES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/83b58e415ca8.usd"),
        "No sequential identical time samples",
        ExampleResult.SUCCESS,
    )
    ONLY_ONE_TIME_SAMPLE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/59a6ec7a03ef.usd"),
        "Only one time sample",
        ExampleResult.FAILURE,
    )
    MESH_WITH_UNUSED_VERTICES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/72fcbd86aac3.usd"),
        "Mesh with unused vertices",
        ExampleResult.FAILURE,
    )
    CLEAN_TOPOLOGY_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/fdc43961451d.usd"),
        "Clean topology",
        ExampleResult.SUCCESS,
    )
    INCORRECT_EXTENT_ON_STATIC_GEOMETRY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="03/2b61e74a3e88.usd"),
        "Incorrect extent on static geometry",
        ExampleResult.FAILURE,
    )
    MISSING_EXTENT_ON_TIME_VARYING_GEOMETRY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/75539e535b9d.usd"),
        "Missing extent on time-varying geometry",
        ExampleResult.FAILURE,
    )
    EXTENT_AUTHORED_ONLY_WHEN_IT_CHANGES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/64d05bd08943.usd"),
        "Extent authored only when it changes",
        ExampleResult.SUCCESS,
    )
    STANDARD_MESH_GEOMETRY_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/706032040b61.usd"),
        "Standard mesh geometry",
        ExampleResult.SUCCESS,
    )
    TRIANGULATED_MESH_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/281c37e748b9.usd"),
        "Triangulated mesh",
        ExampleResult.SUCCESS,
    )
    ZERO_AREA_FACES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/d53866b4a643.usd"),
        "Zero area faces",
        ExampleResult.FAILURE,
    )
    ALL_FACES_HAVE_AREA_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/77b339f0b2b5.usd"),
        "All faces have area",
        ExampleResult.SUCCESS,
    )
    LAMINA_FACES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/75accf7692de.usd"),
        "Lamina faces",
        ExampleResult.FAILURE,
    )
    NO_LAMINA_FACES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/7c2551dd5b8e.usd"),
        "No lamina faces",
        ExampleResult.SUCCESS,
    )
    ASSET_POSITIONED_CORRECTLY_AT_ORIGIN_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/aeb059656113.usd"),
        "Asset positioned correctly at origin",
        ExampleResult.SUCCESS,
    )
    ASSET_WITH_NON_IDENTITY_TRANSLATION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/8b27eeb796b3.usd"),
        "Asset with non-identity translation",
        ExampleResult.FAILURE,
    )
    ASSET_WITH_NON_IDENTITY_ROTATION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/3add5da75b2f.usd"),
        "Asset with non-identity rotation",
        ExampleResult.FAILURE,
    )
    ASSET_WITH_NON_IDENTITY_SCALE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/f624d6678ddf.usd"),
        "Asset with non-identity scale",
        ExampleResult.FAILURE,
    )
    ASSET_WITH_NON_IDENTITY_TRANSLATION_AND_ROTATION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="04/94a45a0666bc.usd"),
        "Asset with non-identity translation and rotation",
        ExampleResult.FAILURE,
    )
    ASSET_WITH_NON_IDENTITY_TRANSLATION_ROTATION_AND_SCALE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/5fa8d56cc0bc.usd"),
        "Asset with non-identity translation, rotation and scale",
        ExampleResult.FAILURE,
    )
    MESH_WITH_UNUSED_PRIMVARS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/8bcb6159d05d.usd"),
        "Mesh with unused primvars",
        ExampleResult.FAILURE,
    )
    ONLY_USED_PRIMVARS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/8921a503eb51.usd"),
        "Only used primvars",
        ExampleResult.SUCCESS,
    )
    CO_LOCATED_POINTS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/6b64e42eb8ea.usd"),
        "Co-located points",
        ExampleResult.FAILURE,
    )
    NO_CO_LOCATED_POINTS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/e151d7f67362.usd"),
        "No co-located points",
        ExampleResult.SUCCESS,
    )
    NO_DENSE_CAPTION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/67b2df583c67.usd"),
        "No dense caption",
        ExampleResult.FAILURE,
    )
    DENSE_CAPTION_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/74114ce8c7f7.usd"),
        "Dense caption",
        ExampleResult.SUCCESS,
    )
    PART_WITHOUT_DENSE_CAPTIONS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/9c0ba66799b1.usd"),
        "Part without dense captions",
        ExampleResult.FAILURE,
    )
    PART_WITH_DENSE_CAPTIONS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/0b55f29c3ad4.usd"),
        "Part with dense captions",
        ExampleResult.SUCCESS,
    )
    USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_A_KINEMATIC_BODY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/79f7e607bccc.usd"),
        "UsdPhysicsArticulationRootAPI applied to a kinematic body",
        ExampleResult.FAILURE,
    )
    USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_AN_ENABLED_RIGID_BODY_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/4e3f9359fd1c.usd"),
        "UsdPhysicsArticulationRootAPI applied to an enabled rigid body",
        ExampleResult.SUCCESS,
    )
    ONE_OF_THE_BODY_RELATIONSHIPS_HAVE_MORE_THAN_ONE_TARGET_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/7221a6f87568.usd"),
        "One of the Body relationships have more than one target",
        ExampleResult.FAILURE,
    )
    BOTH_RELATIONSHIPS_HAVE_AT_MOST_ONE_TARGET_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="05/8b7bf5824da2.usd"),
        "Both relationships have at most one target",
        ExampleResult.SUCCESS,
    )
    JOINT_PRIM_S_TARGET_DOES_NOT_EXIST_IN_THE_STAGE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/bbe44b74e0f7.usd"),
        "Joint prim's target does not exist in the stage",
        ExampleResult.FAILURE,
    )
    JOINT_PRIM_S_TARGET_EXISTS_IN_THE_STAGE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/30f1cdc37598.usd"),
        "Joint prim's target exists in the stage",
        ExampleResult.SUCCESS,
    )
    NESTED_ARTICULATION_ROOT_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/3ff310969c95.usd"),
        "Nested articulation root",
        ExampleResult.FAILURE,
    )
    NON_NESTED_ARTICULATION_ROOT_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/210351a9aa2d.usd"),
        "Non-nested articulation root",
        ExampleResult.SUCCESS,
    )
    NO_JOINT_BETWEEN_RIGID_BODIES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/6a72b4df46a1.usd"),
        "No joint between rigid bodies",
        ExampleResult.FAILURE,
    )
    JOINT_BETWEEN_RIGID_BODIES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/506aa9882eff.usd"),
        "Joint between rigid bodies",
        ExampleResult.SUCCESS,
    )
    JOINT_BETWEEN_RIGID_BODY_AND_WORLD_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/0663731da3b1.usd"),
        "Joint between rigid body and World",
        ExampleResult.SUCCESS,
    )
    NO_ARTICULATION_CAPABILITY_ON_ROOT_JOINT_OF_A_FIXED_ARTICULATION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/327844431d93.usd"),
        "No articulation capability on root joint of a fixed articulation",
        ExampleResult.FAILURE,
    )
    ARTICULATION_CAPABILITY_ON_ROOT_JOINT_OF_A_FIXED_ARTICULATION_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/fd2b9c6f7425.usd"),
        "Articulation capability on root joint of a fixed articulation",
        ExampleResult.SUCCESS,
    )
    NO_ARTICULATION_CAPABILITY_ON_ROOT_BODY_OF_A_FLOATING_ARTICULATION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/3b5ccc0bccf8.usd"),
        "No articulation capability on root body of a floating articulation",
        ExampleResult.FAILURE,
    )
    ARTICULATION_CAPABILITY_ON_ROOT_BODY_OF_A_FLOATING_ARTICULATION_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/ddd69d178f70.usd"),
        "Articulation capability on root body of a floating articulation",
        ExampleResult.SUCCESS,
    )
    USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_A_STATIC_BODY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/5aa805c2ad4a.usd"),
        "UsdPhysicsArticulationRootAPI applied to a static body",
        ExampleResult.FAILURE,
    )
    NESTED_RIGID_BODIES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="06/f4fcea4fc846.usd"),
        "Nested rigid bodies",
        ExampleResult.FAILURE,
    )
    RIGID_BODIES_NESTED_BUT_WITH_XFORMOP_STACK_RESET_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/edb67c6299cc.usd"),
        "Rigid bodies nested but with xformOp stack reset",
        ExampleResult.SUCCESS,
    )
    COLLISION_THAT_SHOULD_BE_STATIC_BUT_INCLUDES_A_RIGID_BODY_API_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/7cf0027fa259.usd"),
        "Collision that should be static but includes a rigid body API",
        ExampleResult.FAILURE,
    )
    STATIC_COLLISION_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/8661669793e5.usd"),
        "Static collision",
        ExampleResult.SUCCESS,
    )
    NON_UNIFORM_SCALE_ON_A_SPHERE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/b6cd230b3dae.usd"),
        "Non-Uniform scale on a Sphere",
        ExampleResult.FAILURE,
    )
    UNIFORM_SCALE_ON_A_SPHERE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/2c583ce006e8.usd"),
        "Uniform scale on a Sphere",
        ExampleResult.SUCCESS,
    )
    USDPHYSICSRIGIDBODYAPI_APPLIED_TO_A_SCOPE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/48231d3dd720.usd"),
        "UsdPhysicsRigidBodyAPI applied to a Scope",
        ExampleResult.FAILURE,
    )
    RIGID_BODY_AND_COLLISION_ON_USDGEOMXFORMABLE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/7cf0027fa259.usd"),
        "Rigid body and collision on UsdGeomXformable",
        ExampleResult.SUCCESS,
    )
    MESH_COLLISION_API_ON_A_MESH_DOES_NOT_DEFINE_A_COLLISION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/bea446a82e13.usd"),
        "Mesh collision API on a mesh does not define a collision",
        ExampleResult.FAILURE,
    )
    MESH_COLLISION_API_ON_A_CUBE_IS_NOT_VALID_AS_IT_DEFINES_ONLY_MESH_PROPERTIES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/d359b91aa14d.usd"),
        "Mesh collision API on a cube is not valid as it defines only mesh properties",
        ExampleResult.FAILURE,
    )
    MESH_COLLISION_API_TOGETHER_WITH_COLLISION_API_DEFINE_A_PROPER_MESH_COLLIDER_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/3cd3e440196a.usd"),
        "Mesh collision API together with Collision API define a proper mesh collider",
        ExampleResult.SUCCESS,
    )
    JUST_COLLISION_ON_USDGEOMGPRIM_THAT_SHOULD_MOVE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/8661669793e5.usd"),
        "Just Collision on UsdGeomGPrim that should move",
        ExampleResult.FAILURE,
    )
    RIGID_BODY_AND_COLLISION_ON_USDGEOMGPRIM_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/7cf0027fa259.usd"),
        "Rigid body and collision on UsdGeomGPrim",
        ExampleResult.SUCCESS,
    )
    NO_MASS_OR_INERTIA_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="07/194e40325329.usd"),
        "No mass or inertia specified",
        ExampleResult.FAILURE,
    )
    ILLEGAL_MASS_AND_INERTIA_VALUES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/82e29477b866.usd"),
        "Illegal mass and inertia values",
        ExampleResult.FAILURE,
    )
    MASS_INERTIA_FULLY_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/61999acd7ef8.usd"),
        "Mass & inertia fully specified",
        ExampleResult.SUCCESS,
    )
    MASS_SPECIFIED_ON_RIGID_BODY_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/7cf88b803519.usd"),
        "Mass specified on Rigid Body",
        ExampleResult.SUCCESS,
    )
    COLLISION_ON_NON_USDGEOMGPRIM_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/843069bdea5d.usd"),
        "Collision on non UsdGeomGPrim",
        ExampleResult.FAILURE,
    )
    COLLISION_ON_USDGEOMGPRIM_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/8661669793e5.usd"),
        "Collision on UsdGeomGPrim",
        ExampleResult.SUCCESS,
    )
    RIGID_BODY_PART_OF_A_SCENE_GRAPH_INSTANCE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/89f6053199b2.usd"),
        "Rigid body part of a scene graph instance",
        ExampleResult.FAILURE,
    )
    RIGID_BODY_APPLIED_TO_THE_SCENE_GRAPH_INSTANCE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/5b5b555687aa.usd"),
        "Rigid body applied to the scene graph instance",
        ExampleResult.SUCCESS,
    )
    USING_USDGEOMXFORMCOMMONAPI_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/7fcb32c2828c.usd"),
        "Using UsdGeomXformCommonAPI",
        ExampleResult.SUCCESS,
    )
    USAGE_OF_TRANSFORM_XFORMOP_FOR_PRIMS_THAT_ARE_NOT_INTENDED_TO_BE_TRANSLATED_ROTATED_OR_SCALED_BY_USERS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/61e7932c800a.usd"),
        "Usage of transform xformOp for prims that are not intended to be translated, rotated or scaled by users",
        ExampleResult.FAILURE,
    )
    MANY_CHILDREN_UNDER_A_SINGLE_PRIM_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/78a1d7eb6c15.usd"),
        "Many children under a single prim",
        ExampleResult.FAILURE,
    )
    CHILDREN_DISTRIBUTED_AMONG_MULTIPLE_PRIMS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/7a4d2458d7ea.usd"),
        "Children distributed among multiple prims",
        ExampleResult.SUCCESS,
    )
    ROOT_IS_AN_XFORM_PRIM_NATURALLY_TRANSFORMABLE__OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/4896a3fc137f.usd"),
        "Root is an Xform prim (naturally transformable)",
        ExampleResult.SUCCESS,
    )
    ROOT_IS_A_MATERIAL_PRIM_NOT_TRANSFORMABLE__NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="08/fba14ee4cdf3.usd"),
        "Root is a Material prim (not transformable)",
        ExampleResult.FAILURE,
    )
    NO_DEFAULTPRIM_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/45669ab9dd09.usd"),
        "No defaultPrim specified",
        ExampleResult.FAILURE,
    )
    DEFAULTPRIM_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/ca3906cd7380.usd"),
        "defaultPrim specified",
        ExampleResult.SUCCESS,
    )
    LOGICAL_GROUPING_OF_CHAIR_COMPONENTS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/a018f1762b78.usd"),
        "Logical grouping of chair components",
        ExampleResult.SUCCESS,
    )
    POOR_GROUPING_WITH_UNNECESSARY_COMPLEXITY_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/533092c966dd.usd"),
        "Poor grouping with unnecessary complexity",
        ExampleResult.FAILURE,
    )
    ALL_XFORMS_UNDER_SINGLE_ROOT_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/d1e740ab553d.usd"),
        "All Xforms under single root",
        ExampleResult.SUCCESS,
    )
    PRIMS_THAT_ARE_NOT_PART_OF_THE_REFERENCEABLE_ASSET_ARE_PERMITTED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/b376fbb51d87.usd"),
        "Prims that are not part of the referenceable asset are permitted",
        ExampleResult.SUCCESS,
    )
    UNNECESSARY_EMPTY_LEAF_PRIMS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/fc3b97f9b696.usd"),
        "Unnecessary, empty leaf prims",
        ExampleResult.FAILURE,
    )
    PRIM_HIERARCHY_WITHOUT_UNNECESSARY_LEAF_PRIMS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/0a19ac9d7a5d.usd"),
        "Prim hierarchy without unnecessary leaf prims",
        ExampleResult.SUCCESS,
    )
    CUBE_SHAPED_MESH_SITTING_ON_THE_GROUND_PLANE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/fafd55b35003.usd"),
        "Cube shaped mesh sitting on the ground plane",
        ExampleResult.SUCCESS,
    )
    CEILING_FAN_WITH_ORIGIN_AT_THE_TOP_OF_THE_DOWN_ROD_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/98e9917af76b.usd"),
        "Ceiling fan with origin at the top of the down rod",
        ExampleResult.SUCCESS,
    )
    DOOR_PANEL_WITH_ORIGIN_AT_THE_HINGE_POINT_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/ce676dd7e665.usd"),
        "Door panel with origin at the hinge point",
        ExampleResult.SUCCESS,
    )
    ROBOT_ARM_WITH_KINEMATIC_CHAIN_HIERARCHY_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/9767384c2c07.usd"),
        "Robot arm with kinematic chain hierarchy",
        ExampleResult.SUCCESS,
    )
    FLAT_HIERARCHY_IGNORING_KINEMATIC_RELATIONSHIPS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="09/c2d5688e153e.usd"),
        "Flat hierarchy ignoring kinematic relationships",
        ExampleResult.FAILURE,
    )
    MESH_PRIM_INHERITS_USDGEOMXFORMABLE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/87f39d3a0ffe.usd"),
        "Mesh prim inherits UsdGeomXformable",
        ExampleResult.SUCCESS,
    )
    XFORM_PRIM_INHERITS_USDGEOMXFORMABLE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/74cb537131a9.usd"),
        "Xform prim inherits UsdGeomXformable",
        ExampleResult.SUCCESS,
    )
    LIGHT_PRIM_INHERITS_USDGEOMXFORMABLE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/05b659d1f160.usd"),
        "Light prim inherits UsdGeomXformable",
        ExampleResult.SUCCESS,
    )
    MATERIAL_PRIM_DOES_NOT_INHERIT_USDGEOMXFORMABLE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/02b23309ee4a.usd"),
        "Material prim does not inherit UsdGeomXformable",
        ExampleResult.FAILURE,
    )
    SUBLAYER_PATH_WITH_FORWARD_SLASHES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/068985dfa562.usd"),
        "Sublayer path with forward slashes",
        ExampleResult.SUCCESS,
    )
    REFERENCE_PATH_WITH_FORWARD_SLASHES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/854e68429163.usd"),
        "Reference path with forward slashes",
        ExampleResult.SUCCESS,
    )
    ASSET_ATTRIBUTE_PATH_WITH_FORWARD_SLASHES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/281148c05f7d.usd"),
        "Asset attribute path with forward slashes",
        ExampleResult.SUCCESS,
    )
    SUBLAYER_PATH_WITH_BACKSLASHES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/605418b688ae.usd"),
        "Sublayer path with backslashes",
        ExampleResult.FAILURE,
    )
    REFERENCE_PATH_WITH_BACKSLASHES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/9ea9a6ab4f4b.usd"),
        "Reference path with backslashes",
        ExampleResult.FAILURE,
    )
    ADD_REFERENCE_PATH_WITH_BACKSLASHES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/4064d5be6f9d.usd"),
        "Add reference path with backslashes",
        ExampleResult.FAILURE,
    )
    ASSET_ATTRIBUTE_PATH_WITH_BACKSLASHES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/f3fae83e2685.usd"),
        "Asset attribute path with backslashes",
        ExampleResult.FAILURE,
    )
    USING_ANCHORED_PATHS_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/17ffd2f1e7da.usd"),
        "Using anchored paths",
        ExampleResult.SUCCESS,
    )
    USING_SEARCH_PATH_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0a/648eed8228b7.usd"),
        "Using search path",
        ExampleResult.FAILURE,
    )
    USING_ABSOLUTE_PATH_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/138f1f201473.usd"),
        "Using absolute path",
        ExampleResult.FAILURE,
    )
    USING_ASSET_ROOT_PATH_THAT_TARGETS_A_LOCATION_ABOVE_THE_ASSET_ROOT_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/32cfaa0e3280.usd"),
        "Using asset root path that targets a location above the asset root",
        ExampleResult.FAILURE,
    )
    NO_METERSPERUNIT_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/a80e5ec526a5.usd"),
        "No metersPerUnit specified",
        ExampleResult.FAILURE,
    )
    METERSPERUNIT_NOT_SET_TO_1_0_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/f564eeaf18ff.usd"),
        "metersPerUnit not set to 1.0",
        ExampleResult.FAILURE,
    )
    METERSPERUNIT_1_0_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/4a04f5d9b830.usd"),
        "metersPerUnit = 1.0",
        ExampleResult.SUCCESS,
    )
    NO_UPAXIS_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/a80e5ec526a5.usd"),
        "No upAxis specified",
        ExampleResult.FAILURE,
    )
    Y_UP_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/cffa17b140ea.usd"),
        "Y-up specified",
        ExampleResult.FAILURE,
    )
    Z_UP_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/9f506b1db128.usd"),
        "Z-up specified",
        ExampleResult.SUCCESS,
    )
    NO_TIMECODESPERSECOND_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/4074296992d8.usd"),
        "No timeCodesPerSecond specified",
        ExampleResult.FAILURE,
    )
    TIMECODESPERSECOND_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/75c7001ad571.usd"),
        "timeCodesPerSecond specified",
        ExampleResult.SUCCESS,
    )
    NO_CORRECTIVE_TRANSFORM_FOR_DIFFERENT_UNITS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/26eb65906442.usd"),
        "No corrective transform for different units",
        ExampleResult.FAILURE,
    )
    COMPENSATING_TRANSFORM_APPLIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/ecbadd46db8c.usd"),
        "Compensating transform applied",
        ExampleResult.SUCCESS,
    )
    UPAXIS_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0b/9f506b1db128.usd"),
        "upAxis specified",
        ExampleResult.SUCCESS,
    )
    METERSPERUNIT_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/f564eeaf18ff.usd"),
        "metersPerUnit specified",
        ExampleResult.SUCCESS,
    )
    NO_KILOGRAMSPERUNIT_SPECIFIED_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/f564eeaf18ff.usd"),
        "No kilogramsPerUnit specified",
        ExampleResult.FAILURE,
    )
    KILOGRAMSPERUNIT_SPECIFIED_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/38cf2e8cb400.usd"),
        "kilogramsPerUnit specified",
        ExampleResult.SUCCESS,
    )
    MISSING_MDL_PATH_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/48b1c5ad267b.usd"),
        "Missing MDL path",
        ExampleResult.FAILURE,
    )
    WRONG_EXTENSION_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/9de07f8ca5ef.usd"),
        "Wrong extension",
        ExampleResult.FAILURE,
    )
    RELATIVE_PATH_WITHOUT__NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/37e50e2cc5e8.usd"),
        "Relative path without ./",
        ExampleResult.FAILURE,
    )
    NON_EXISTENT_MDL_FILE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/09523f6f9331.usd"),
        "Non-existent MDL file",
        ExampleResult.FAILURE,
    )
    PROPER_RELATIVE_PATH_TO_EXISTING_MDL_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/1dcd01fcc830.usd"),
        "Proper relative path to existing MDL",
        ExampleResult.SUCCESS,
    )
    DUPLICATE_MATERIALS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/6397793faf00.usd"),
        "Duplicate materials",
        ExampleResult.FAILURE,
    )
    REUSING_THE_SAME_MATERIAL_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/9fba68d1fc41.usd"),
        "Reusing the same material",
        ExampleResult.SUCCESS,
    )
    NON_COMPLIANT_ATTRIBUTES_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/21714600c604.usd"),
        "Non-compliant attributes",
        ExampleResult.FAILURE,
    )
    WRONG_TYPE_AND_TIME_SAMPLED_TOKENS_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/fceedef3aeb0.usd"),
        "Wrong type and time-sampled tokens",
        ExampleResult.FAILURE,
    )
    COMPLIANT_ATTRIBUTES_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0c/22ca9e12942b.usd"),
        "Compliant attributes",
        ExampleResult.SUCCESS,
    )
    MATERIAL_BINDING_REFERENCES_OUTSIDE_PAYLOAD_SCOPE_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0d/e95f1b332fea.usd"),
        "Material binding references outside payload scope",
        ExampleResult.FAILURE,
    )
    MATERIAL_BINDING_REFERENCES_WITHIN_PAYLOAD_SCOPE_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0d/3476de1647c0.usd"),
        "Material binding references within payload scope",
        ExampleResult.SUCCESS,
    )
    USING_DEPRECATED_MDL_SCHEMA_FORMAT_NOK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0d/f71ef7ff2bfd.usd"),
        "Using deprecated MDL schema format",
        ExampleResult.FAILURE,
    )
    USING_CURRENT_MDL_SCHEMA_FORMAT_OK = (
        ExampleSnippet(language=ExampleSnippetLanguage.USD, path="0d/e236731fa5b7.usd"),
        "Using current MDL schema format",
        ExampleResult.SUCCESS,
    )