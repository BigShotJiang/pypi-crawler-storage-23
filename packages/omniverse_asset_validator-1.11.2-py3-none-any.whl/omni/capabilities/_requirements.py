# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

from dataclasses import dataclass
from enum import Enum

from ._parameters import Parameter, Parameters
from ._examples import Example, Examples


@dataclass(frozen=True)
class Requirement:
    """
    Args:
        code: A unique identifier of the requirement
        display_name: A human-readable name of the requirement
        message: A basic description of the requirement
        path: Relative path in documentation
        compatibility: Compatibility of the requirement
        tags: Tags of the requirement
        parameters: Parameters of the requirement
    """
    code: str
    version: str | None = None
    display_name: str | None = None
    message: str | None = None
    path: str | None = None
    compatibility: str | None = None
    tags: tuple[str, ...] = ()
    parameters: tuple[Parameter, ...] = ()
    examples: tuple[Example, ...] = ()

class Requirements(Requirement, Enum):
    """
    An enumeration of all requirements.
    """
    SL_003_V1_0_0 = (
        "SL.003", 
        "1.0.0",
        "semantic-label-schema",
        "Semantic labels must use the SemanticsLabelsAPI schema", 
        "capabilities/semantic_labels/requirements/semantic-label-schema.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.WRONG_SCHEMA_NAME_NOK,
            Examples.MISSING_SCHEMA_NOK,
            Examples.CORRECT_SCHEMA_USAGE_OK,
            Examples.NO_API_INSTANCE_NAME_TAXONOMY__NOK,
        ),
    )
    SL_NV_002_V1_0_0 = (
        "SL.NV.002", 
        "1.0.0",
        "semantic-label-time",
        "Semantic label attributes must not contain time samples", 
        "capabilities/semantic_labels/requirements/semantic-label-time.html",
        "rtx",
        ("limitation",),
        (),
        (
            Examples.TIME_SAMPLED_SEMANTIC_LABELS_NOK,
            Examples.CONSTANT_SEMANTIC_LABELS_OK,
        ),
    )
    SL_001_V1_0_0 = (
        "SL.001", 
        "1.0.0",
        "semantic-label-capability",
        "All geometry prims must be semantically labeled.", 
        "capabilities/semantic_labels/requirements/semantic-label-capability.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.NO_SEMANTIC_LABELS_NOK,
            Examples.LABELED_WITH_WIKIDATA_Q_CODE_OK,
        ),
    )
    SL_QCODE_001_V1_0_0 = (
        "SL.QCODE.001", 
        "1.0.0",
        "semantic-label-qcode-valid",
        "If the Wikidata ontology is used, Q-Codes must be valid, properly formatted, and retrievable from wikidata.org.", 
        "capabilities/semantic_labels/requirements/semantic-label-qcode-valid.html",
        "omniverse",
        ("correctness",),
        (),
        (
            Examples.NON_EXISTENT_Q_CODE_NOK,
            Examples.Q_CODE_FOR_WRONG_CONCEPT_TYPE_NOK,
            Examples.INCORRECT_Q_CODE_FORMAT_NOK,
            Examples.EMPTY_ARRAY_NOK,
            Examples.EXISTING_AND_APPROPRIATE_Q_CODE_OK,
        ),
    )
    NVM_004_V1_0_0 = (
        "NVM.004", 
        "1.0.0",
        "material-binding",
        "Attributes must be on bound materials", 
        "capabilities/nonvisual_sensors/nonvisual_materials/requirements/material-binding.html",
        "rtx",
        ("correctness",),
        (),
        (
            Examples.ATTRIBUTES_ON_GEOMETRY_NOK,
            Examples.ATTRIBUTES_ON_BOUND_MATERIAL_OK,
        ),
    )
    NVM_003_V1_0_0 = (
        "NVM.003", 
        "1.0.0",
        "material-coating",
        "Materials must specify surface coating", 
        "capabilities/nonvisual_sensors/nonvisual_materials/requirements/material-coating.html",
        "rtx",
        ("correctness",),
        (),
        (
            Examples.NO_COATING_SPECIFIED_NOK,
            Examples.COATING_SPECIFIED_OK,
        ),
    )
    NVM_006_V1_0_0 = (
        "NVM.006", 
        "1.0.0",
        "material-time",
        "Properties must not be time-varying", 
        "capabilities/nonvisual_sensors/nonvisual_materials/requirements/material-time.html",
        "rtx",
        ("correctness",),
        (),
        (
            Examples.TIME_VARYING_PROPERTIES_NOK,
            Examples.STATIC_PROPERTIES_OK,
        ),
    )
    NVM_005_V1_0_0 = (
        "NVM.005", 
        "1.0.0",
        "material-consistency",
        "Properties must be consistent with visual materials", 
        "capabilities/nonvisual_sensors/nonvisual_materials/requirements/material-consistency.html",
        "rtx",
        ("correctness",),
        (),
        (
            Examples.INCONSISTENT_ATTRIBUTES_NOK,
            Examples.CONSISTENT_ATTRIBUTES_OK,
        ),
    )
    NVM_002_V1_0_0 = (
        "NVM.002", 
        "1.0.0",
        "material-base",
        "Materials must specify a base material type", 
        "capabilities/nonvisual_sensors/nonvisual_materials/requirements/material-base.html",
        "rtx",
        ("correctness",),
        (),
        (
            Examples.NO_BASE_MATERIAL_TYPE_SPECIFIED_NOK,
            Examples.BASE_MATERIAL_TYPE_SPECIFIED_OK,
        ),
    )
    NVM_001_V1_0_0 = (
        "NVM.001", 
        "1.0.0",
        "material-attributes",
        "Materials must specify additional \"non-visual\" material attributes", 
        "capabilities/nonvisual_sensors/nonvisual_materials/requirements/material-attributes.html",
        "rtx",
        ("essential",),
        (),
        (
            Examples.NO_ATTRIBUTES_SPECIFIED_NOK,
            Examples.ATTRIBUTES_SPECIFIED_OK,
        ),
    )
    VG_033_V1_0_0 = (
        "VG.033", 
        "1.0.0",
        "usdgeom-unused-uvs",
        "Do not author unused texture coordinates.", 
        "capabilities/geometry/requirements/usdgeom-unused-uvs.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_008_V1_0_0 = (
        "VG.008", 
        "1.0.0",
        "usdgeom-mesh-coincident",
        "Meshes should not share the exact same space", 
        "capabilities/geometry/requirements/usdgeom-mesh-coincident.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.COINCIDENT_MESHES_NOK,
            Examples.MESHES_WITH_PROPER_SPACING_OK,
        ),
    )
    VG_014_V1_0_0 = (
        "VG.014", 
        "1.0.0",
        "usdgeom-mesh-topology",
        "Mesh topology must be valid", 
        "capabilities/geometry/requirements/usdgeom-mesh-topology.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.DEGENERATE_FACES_AND_INVALID_INDICES_NOK,
            Examples.PROPER_TOPOLOGY_OK,
        ),
    )
    VG_005_V1_0_0 = (
        "VG.005", 
        "1.0.0",
        "usdgeom-boundable-size",
        "Meshes should maintain appropriate scale and boundary volumes", 
        "capabilities/geometry/requirements/usdgeom-boundable-size.html",
        "rtx",
        ("performance",),
        (),
        (),
    )
    VG_028_V1_0_0 = (
        "VG.028", 
        "1.0.0",
        "usdgeom-mesh-normals-must-be-valid",
        "Mesh normals values must be valid to produce correct shading.", 
        "capabilities/geometry/requirements/usdgeom-mesh-normals-must-be-valid.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.TRIANGLE_WITH_INCONSISTENT_WINDING_ORDER_AND_NORMALS_NOK,
        ),
    )
    VG_009_V1_0_0 = (
        "VG.009", 
        "1.0.0",
        "usdgeom-mesh-primvar-indexing",
        "Use indexed primvars when values are repeated", 
        "capabilities/geometry/requirements/usdgeom-mesh-primvar-indexing.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_030_V1_0_0 = (
        "VG.030", 
        "1.0.0",
        "usdgeom-zero-extent",
        "Boundable geometry should have non-zero extents in at least one dimension.", 
        "capabilities/geometry/requirements/usdgeom-zero-extent.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.ZERO_EXTENT_NOK,
            Examples.MESH_HAS_NONZERO_EXTENT_OK,
        ),
    )
    VG_004_V1_0_0 = (
        "VG.004", 
        "1.0.0",
        "usdgeom-mesh-empty-spaces",
        "Use efficient mesh boundaries for performance", 
        "capabilities/geometry/requirements/usdgeom-mesh-empty-spaces.html",
        "rtx",
        ("performance",),
        (),
        (),
    )
    VG_007_V1_0_0 = (
        "VG.007", 
        "1.0.0",
        "usdgeom-mesh-manifold",
        "Mesh geometry must be manifold", 
        "capabilities/geometry/requirements/usdgeom-mesh-manifold.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.NON_MANIFOLD_EDGE_DUE_TO_INCONSISTENT_WINDING_NOK,
            Examples.MANIFOLD_MESH_OK,
        ),
    )
    VG_020_V1_0_0 = (
        "VG.020", 
        "1.0.0",
        "usdgeom-pointbased-points-precision",
        "The values of the points attribute  must not exceed the limit at which a given precision can be represented using 32-bit floats.", 
        "capabilities/geometry/requirements/usdgeom-pointbased-points-precision.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_024_V1_0_0 = (
        "VG.024", 
        "1.0.0",
        "identical-mesh-consistency",
        "Repeated occurrences of identically shaped objects should have identical mesh connectivity", 
        "capabilities/geometry/requirements/identical-mesh-consistency.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_034_V1_0_0 = (
        "VG.034", 
        "1.0.0",
        "usdgeom-invisible-prims",
        "Avoid invisible prims when deactivation is more appropriate.", 
        "capabilities/geometry/requirements/usdgeom-invisible-prims.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.INVISIBLE_PRIM_CONSUMING_RESOURCES_NOK,
            Examples.DEACTIVATED_PRIM_EXCLUDED_FROM_TRAVERSAL_OK,
        ),
    )
    VG_003_V1_0_0 = (
        "VG.003", 
        "1.0.0",
        "usdgeom-mesh-internal-geometry",
        "Only include geometry that contributes to visualization or simulation", 
        "capabilities/geometry/requirements/usdgeom-mesh-internal-geometry.html",
        "open-usd",
        ("performance",),
        (
            Parameters.USE_GPU,
            Parameters.CHECK_TRANSPARENCY,
        ),
        (),
    )
    VG_RTX_002_V1_0_0 = (
        "VG.RTX.002", 
        "1.0.0",
        "usdgeom-mesh-count",
        "Use appropriate mesh count for scene", 
        "capabilities/geometry/requirements/usdgeom-mesh-count.html",
        "rtx",
        ("performance",),
        (),
        (),
    )
    VG_029_V1_0_0 = (
        "VG.029", 
        "1.0.0",
        "usdgeom-mesh-winding-order",
        "The winding order of faces in a mesh must correctly represent the orientation (front/back) of the face.", 
        "capabilities/geometry/requirements/usdgeom-mesh-winding-order.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.INCONSISTENT_WINDING_ORDER_NOK,
        ),
    )
    VG_017_V1_0_0 = (
        "VG.017", 
        "1.0.0",
        "usdgeom-mesh-primitive-tessellation",
        "Avoid tessellating primitive shapes", 
        "capabilities/geometry/requirements/usdgeom-mesh-primitive-tessellation.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_010_V1_0_0 = (
        "VG.010", 
        "1.0.0",
        "usdgeom-mesh-subdivision",
        "Do not subdivide meshes with Normals.", 
        "capabilities/geometry/requirements/usdgeom-mesh-subdivision.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.UNNECESSARY_SUBDIVISION_ON_SIMPLE_SHAPE_NOK,
            Examples.NO_SUBDIVISION_FOR_SIMPLE_SHAPE_OK,
        ),
    )
    VG_RTX_001_V1_0_0 = (
        "VG.RTX.001", 
        "1.0.0",
        "usdgeom-boundable-size-rtx-limit",
        "World space bounds must not exceed RTX limit.", 
        "capabilities/geometry/requirements/usdgeom-boundable-size-rtx-limit.html",
        "rtx",
        ("limitation",),
        (),
        (),
    )
    VG_031_V1_0_0 = (
        "VG.031", 
        "1.0.0",
        "usdgeom-mesh-non-opaque-must-have-thickness",
        "Meshes made from non opaque materials shall have thickness", 
        "capabilities/geometry/requirements/usdgeom-mesh-non-opaque-must-have-thickness.html",
        "core-usd",
        ("correctness",),
        (),
        (),
    )
    VG_027_V1_0_0 = (
        "VG.027", 
        "1.0.0",
        "usdgeom-mesh-normals-exist",
        "All non-subdivided meshes must have normals.", 
        "capabilities/geometry/requirements/usdgeom-mesh-normals-exist.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.SOFT_EDGE_BETWEEN_TWO_FACES_OK,
            Examples.HARD_EDGE_BETWEEN_TWO_FACES_OK,
            Examples.NO_NORMALS_TO_DEFINE_SOFT_OR_HARD_EDGE_NOK,
            Examples.BOTH_NORMALS_AND_PRIMVARS_NORMALS_EXIST_NOK,
            Examples.ONLY_PRIMVARS_NORMALS_EXISTS_OK,
        ),
    )
    VG_015_V1_0_0 = (
        "VG.015", 
        "1.0.0",
        "usdgeom-mesh-identical-timesamples",
        "Use time samples only when attribute values change", 
        "capabilities/geometry/requirements/usdgeom-mesh-identical-timesamples.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.IDENTICAL_TIME_SAMPLES_NOK,
            Examples.NO_TIME_SAMPLES_OK,
            Examples.SOME_IDENTICAL_TIME_SAMPLES_NOK,
            Examples.NO_SEQUENTIAL_IDENTICAL_TIME_SAMPLES_OK,
            Examples.ONLY_ONE_TIME_SAMPLE_NOK,
        ),
    )
    VG_018_V1_0_0 = (
        "VG.018", 
        "1.0.0",
        "usdgeom-mesh-unused-topology",
        "Mesh topology should be without unused vertices, edges, or faces.", 
        "capabilities/geometry/requirements/usdgeom-mesh-unused-topology.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.MESH_WITH_UNUSED_VERTICES_NOK,
            Examples.CLEAN_TOPOLOGY_OK,
        ),
    )
    VG_021_V1_0_0 = (
        "VG.021", 
        "1.0.0",
        "usdgeom-mesh-vertex-count",
        "Use appropriate vertex count for geometry", 
        "capabilities/geometry/requirements/usdgeom-mesh-vertex-count.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_002_V1_0_0 = (
        "VG.002", 
        "1.0.0",
        "usdgeom-extent",
        "Boundable geometry primitives should have valid extent values.", 
        "capabilities/geometry/requirements/usdgeom-extent.html",
        "open-usd",
        ("performance",),
        (),
        (
            Examples.INCORRECT_EXTENT_ON_STATIC_GEOMETRY_NOK,
            Examples.MISSING_EXTENT_ON_TIME_VARYING_GEOMETRY_NOK,
            Examples.EXTENT_AUTHORED_ONLY_WHEN_IT_CHANGES_OK,
        ),
    )
    VG_MESH_001_V1_0_0 = (
        "VG.MESH.001", 
        "1.0.0",
        "geom-shall-be-mesh",
        "All geometry shall be represented as non-subdivided mesh primitives using the UsdGeomMesh schema.", 
        "capabilities/geometry/requirements/geom-shall-be-mesh.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.STANDARD_MESH_GEOMETRY_OK,
            Examples.TRIANGULATED_MESH_OK,
        ),
    )
    VG_019_V1_0_0 = (
        "VG.019", 
        "1.0.0",
        "usdgeom-mesh-zero-area-faces",
        "Faces should have non-zero area.", 
        "capabilities/geometry/requirements/usdgeom-mesh-zero-area-faces.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.ZERO_AREA_FACES_NOK,
            Examples.ALL_FACES_HAVE_AREA_OK,
        ),
    )
    VG_023_V1_0_0 = (
        "VG.023", 
        "1.0.0",
        "mesh-xform-positioning",
        "Meshes should be positioned using xform ops, not by embedding positions into point positions.", 
        "capabilities/geometry/requirements/mesh-xform-positioning.html",
        "core-usd",
        ("correctness",),
        (),
        (),
    )
    VG_032_V1_0_0 = (
        "VG.032", 
        "1.0.0",
        "usdgeom-mesh-lamina-faces",
        "Faces should not be lamina.", 
        "capabilities/geometry/requirements/usdgeom-mesh-lamina-faces.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.LAMINA_FACES_NOK,
            Examples.NO_LAMINA_FACES_OK,
        ),
    )
    VG_012_V1_0_0 = (
        "VG.012", 
        "1.0.0",
        "usdgeom-mesh-small",
        "Remove meshes from the scene that are below the extent size threshold.", 
        "capabilities/geometry/requirements/usdgeom-mesh-small.html",
        "core-usd",
        ("performance",),
        (
            Parameters.SIZE_THRESHOLD,
        ),
        (),
    )
    VG_025_V1_0_0 = (
        "VG.025", 
        "1.0.0",
        "asset-at-origin",
        "Geometry shall be defined as such that the asset is correctly positioned and oriented at the origin (0,0,0).", 
        "capabilities/geometry/requirements/asset-at-origin.html",
        "core-usd",
        ("essential",),
        (
            Parameters.TRANSFORM_TOLERANCE,
        ),
        (
            Examples.ASSET_POSITIONED_CORRECTLY_AT_ORIGIN_OK,
            Examples.ASSET_WITH_NON_IDENTITY_TRANSLATION_NOK,
            Examples.ASSET_WITH_NON_IDENTITY_ROTATION_NOK,
            Examples.ASSET_WITH_NON_IDENTITY_SCALE_NOK,
            Examples.ASSET_WITH_NON_IDENTITY_TRANSLATION_AND_ROTATION_NOK,
            Examples.ASSET_WITH_NON_IDENTITY_TRANSLATION_ROTATION_AND_SCALE_NOK,
        ),
    )
    VG_006_V1_0_0 = (
        "VG.006", 
        "1.0.0",
        "usdgeom-mesh-overlap",
        "Meshes should not overlap unnecessarily", 
        "capabilities/geometry/requirements/usdgeom-mesh-overlap.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_022_V1_0_0 = (
        "VG.022", 
        "1.0.0",
        "usdgeom-mesh-duplicate",
        "Meshes should use instancing if they are identical apart from their world space location", 
        "capabilities/geometry/requirements/usdgeom-mesh-duplicate.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_013_V1_0_0 = (
        "VG.013", 
        "1.0.0",
        "usdgeom-mesh-tessellation-density",
        "Use appropriate tessellation density for geometry", 
        "capabilities/geometry/requirements/usdgeom-mesh-tessellation-density.html",
        "core-usd",
        ("performance",),
        (),
        (),
    )
    VG_011_V1_0_0 = (
        "VG.011", 
        "1.0.0",
        "usdgeom-mesh-primvar-usage",
        "Only include primvars that are actively used", 
        "capabilities/geometry/requirements/usdgeom-mesh-primvar-usage.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.MESH_WITH_UNUSED_PRIMVARS_NOK,
            Examples.ONLY_USED_PRIMVARS_OK,
        ),
    )
    VG_016_V1_0_0 = (
        "VG.016", 
        "1.0.0",
        "usdgeom-mesh-colocated-points",
        "Each vertex position should be unique", 
        "capabilities/geometry/requirements/usdgeom-mesh-colocated-points.html",
        "core-usd",
        ("performance",),
        (),
        (
            Examples.CO_LOCATED_POINTS_NOK,
            Examples.NO_CO_LOCATED_POINTS_OK,
        ),
    )
    DC_001_V1_0_0 = (
        "DC.001", 
        "1.0.0",
        "dense-caption-capability",
        "The Root Prim must inlcude documentation metadata that describes the 3D Asset.", 
        "capabilities/dense_captions/requirements/dense-caption-capability.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.NO_DENSE_CAPTION_NOK,
            Examples.DENSE_CAPTION_OK,
        ),
    )
    DC_002_V1_0_0 = (
        "DC.002", 
        "1.0.0",
        "additional-dense-captions",
        "Prims representing sub-objects or parts within the asset should be documented with additional dense captions.", 
        "capabilities/dense_captions/requirements/additional-dense-captions.html",
        "core-usd",
        ("high-quality",),
        (),
        (
            Examples.PART_WITHOUT_DENSE_CAPTIONS_NOK,
            Examples.PART_WITH_DENSE_CAPTIONS_OK,
        ),
    )
    JT_ART_003_V1_0_0 = (
        "JT.ART.003", 
        "1.0.0",
        "articulation-not-on-kinematic-body",
        "In PhysX based simulators, like Omniverse Isaac Sim, Articulations are not allowed on kinematic bodies.", 
        "capabilities/physics_bodies/physics_joints/requirements/articulation-not-on-kinematic-body.html",
        "physx",
        ("limitation",),
        (),
        (
            Examples.USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_A_KINEMATIC_BODY_NOK,
            Examples.USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_AN_ENABLED_RIGID_BODY_OK,
        ),
    )
    JT_003_V1_0_0 = (
        "JT.003", 
        "1.0.0",
        "joint-no-multiple-body-targets",
        "Body0 and Body1 relationships must not have more than one target.", 
        "capabilities/physics_bodies/physics_joints/requirements/joint-no-multiple-body-targets.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.ONE_OF_THE_BODY_RELATIONSHIPS_HAVE_MORE_THAN_ONE_TARGET_NOK,
            Examples.BOTH_RELATIONSHIPS_HAVE_AT_MOST_ONE_TARGET_OK,
        ),
    )
    JT_002_V1_0_0 = (
        "JT.002", 
        "1.0.0",
        "joint-body-target-exists",
        "Targets set to Body0 and Body1 relationships must exist.", 
        "capabilities/physics_bodies/physics_joints/requirements/joint-body-target-exists.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.JOINT_PRIM_S_TARGET_DOES_NOT_EXIST_IN_THE_STAGE_NOK,
            Examples.JOINT_PRIM_S_TARGET_EXISTS_IN_THE_STAGE_OK,
        ),
    )
    JT_ART_002_V1_0_0 = (
        "JT.ART.002", 
        "1.0.0",
        "articulation-no-nesting",
        "Articulation roots cannot be nested.", 
        "capabilities/physics_bodies/physics_joints/requirements/articulation-no-nesting.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.NESTED_ARTICULATION_ROOT_NOK,
            Examples.NON_NESTED_ARTICULATION_ROOT_OK,
        ),
    )
    JT_001_V1_0_0 = (
        "JT.001", 
        "1.0.0",
        "joint-capability",
        "Rigid bodies which are not free floating should be connected using joints.", 
        "capabilities/physics_bodies/physics_joints/requirements/joint-capability.html",
        "open-usd",
        ("essential",),
        (),
        (
            Examples.NO_JOINT_BETWEEN_RIGID_BODIES_NOK,
            Examples.JOINT_BETWEEN_RIGID_BODIES_OK,
            Examples.JOINT_BETWEEN_RIGID_BODY_AND_WORLD_OK,
        ),
    )
    JT_ART_001_V1_0_0 = (
        "JT.ART.001", 
        "1.0.0",
        "articulation",
        "For stable and fast simulations of kinematic chains, an asset should define an articulation.", 
        "capabilities/physics_bodies/physics_joints/requirements/articulation.html",
        "open-usd",
        ("high-quality",),
        (),
        (
            Examples.NO_ARTICULATION_CAPABILITY_ON_ROOT_JOINT_OF_A_FIXED_ARTICULATION_NOK,
            Examples.ARTICULATION_CAPABILITY_ON_ROOT_JOINT_OF_A_FIXED_ARTICULATION_OK,
            Examples.NO_ARTICULATION_CAPABILITY_ON_ROOT_BODY_OF_A_FLOATING_ARTICULATION_NOK,
            Examples.ARTICULATION_CAPABILITY_ON_ROOT_BODY_OF_A_FLOATING_ARTICULATION_OK,
        ),
    )
    JT_ART_004_V1_0_0 = (
        "JT.ART.004", 
        "1.0.0",
        "articulation-not-on-static-body",
        "Articulations are not allowed on static bodies.", 
        "capabilities/physics_bodies/physics_joints/requirements/articulation-not-on-static-body.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_A_STATIC_BODY_NOK,
            Examples.USDPHYSICSARTICULATIONROOTAPI_APPLIED_TO_AN_ENABLED_RIGID_BODY_OK,
        ),
    )
    RB_006_V1_0_0 = (
        "RB.006", 
        "1.0.0",
        "rigid-body-no-nesting",
        "In PhysX based simulators, like Omniverse Isaac Sim, Rigid bodies can not be nested unless xformOp reset xform stack is used.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/rigid-body-no-nesting.html",
        "physx",
        ("limitation",),
        (),
        (
            Examples.NESTED_RIGID_BODIES_NOK,
            Examples.RIGID_BODIES_NESTED_BUT_WITH_XFORMOP_STACK_RESET_OK,
        ),
    )
    RB_COL_002_V1_0_0 = (
        "RB.COL.002", 
        "1.0.0",
        "static-collider",
        "If an asset is expected to be static (no movement happens), it can not contain a rigid body, only a Collider body.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/static-collider.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.COLLISION_THAT_SHOULD_BE_STATIC_BUT_INCLUDES_A_RIGID_BODY_API_NOK,
            Examples.STATIC_COLLISION_OK,
        ),
    )
    RB_009_V1_0_0 = (
        "RB.009", 
        "1.0.0",
        "rigid-body-schema-no-skew-matrix",
        "Rigid bodies have to be UsdGeomXformable prims without skew matrix.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/rigid-body-schema-no-skew-matrix.html",
        "open-usd",
        ("correctness",),
        (),
        (),
    )
    RB_COL_004_V1_0_0 = (
        "RB.COL.004", 
        "1.0.0",
        "collider-non-uniform-scale",
        "The collision shape scale must be uniform for the following geometries: Sphere, Capsule, Cylinder, Cone \u0026 Points.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/collider-non-uniform-scale.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.NON_UNIFORM_SCALE_ON_A_SPHERE_NOK,
            Examples.UNIFORM_SCALE_ON_A_SPHERE_OK,
        ),
    )
    RB_003_V1_0_0 = (
        "RB.003", 
        "1.0.0",
        "rigid-body-schema-application",
        "Rigid bodies have to be UsdGeomXformable prims.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/rigid-body-schema-application.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.USDPHYSICSRIGIDBODYAPI_APPLIED_TO_A_SCOPE_NOK,
            Examples.RIGID_BODY_AND_COLLISION_ON_USDGEOMXFORMABLE_OK,
        ),
    )
    RB_COL_003_V1_0_0 = (
        "RB.COL.003", 
        "1.0.0",
        "collider-mesh",
        "The Mesh Collision API can only be assigned to Mesh Prims.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/collider-mesh.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.MESH_COLLISION_API_ON_A_MESH_DOES_NOT_DEFINE_A_COLLISION_NOK,
            Examples.MESH_COLLISION_API_ON_A_CUBE_IS_NOT_VALID_AS_IT_DEFINES_ONLY_MESH_PROPERTIES_NOK,
            Examples.MESH_COLLISION_API_TOGETHER_WITH_COLLISION_API_DEFINE_A_PROPER_MESH_COLLIDER_OK,
        ),
    )
    RB_001_V1_0_0 = (
        "RB.001", 
        "1.0.0",
        "rigid-body-capability",
        "Assets must contain at least one rigid body", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/rigid-body-capability.html",
        "open-usd",
        ("essential",),
        (),
        (
            Examples.JUST_COLLISION_ON_USDGEOMGPRIM_THAT_SHOULD_MOVE_NOK,
            Examples.RIGID_BODY_AND_COLLISION_ON_USDGEOMGPRIM_OK,
        ),
    )
    RB_007_V1_0_0 = (
        "RB.007", 
        "1.0.0",
        "rigid-body-mass",
        "Rigid bodies _or_ their descendent collision shapes should have a mass \u0026 their other inertial properties explicitly specified.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/rigid-body-mass.html",
        "open-usd",
        ("high-quality",),
        (),
        (
            Examples.NO_MASS_OR_INERTIA_SPECIFIED_NOK,
            Examples.ILLEGAL_MASS_AND_INERTIA_VALUES_NOK,
            Examples.MASS_INERTIA_FULLY_SPECIFIED_OK,
            Examples.MASS_SPECIFIED_ON_RIGID_BODY_OK,
        ),
    )
    RB_COL_001_V1_0_0 = (
        "RB.COL.001", 
        "1.0.0",
        "collider-capability",
        "Colliding Gprims must apply the Collision API.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/collider-capability.html",
        "open-usd",
        ("essential",),
        (),
        (
            Examples.COLLISION_ON_NON_USDGEOMGPRIM_NOK,
            Examples.COLLISION_ON_USDGEOMGPRIM_OK,
        ),
    )
    RB_005_V1_0_0 = (
        "RB.005", 
        "1.0.0",
        "rigid-body-no-instancing",
        "Rigid bodies cannot be part of a scene graph instance.", 
        "capabilities/physics_bodies/physics_rigid_bodies/requirements/rigid-body-no-instancing.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.RIGID_BODY_PART_OF_A_SCENE_GRAPH_INSTANCE_NOK,
            Examples.RIGID_BODY_APPLIED_TO_THE_SCENE_GRAPH_INSTANCE_OK,
        ),
    )
    HI_005_V1_0_0 = (
        "HI.005", 
        "1.0.0",
        "xform-common-api-usage",
        "Transformations on prims representing objects or groups that require placement should conform to the UsdGeomXformCommonAPI.", 
        "capabilities/hierarchy/requirements/xform-common-api-usage.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.USING_USDGEOMXFORMCOMMONAPI_OK,
            Examples.USAGE_OF_TRANSFORM_XFORMOP_FOR_PRIMS_THAT_ARE_NOT_INTENDED_TO_BE_TRANSLATED_ROTATED_OR_SCALED_BY_USERS_NOK,
        ),
    )
    HI_011_V1_0_0 = (
        "HI.011", 
        "1.0.0",
        "many-children",
        "Avoid large numbers of child prims under a parent xform", 
        "capabilities/hierarchy/requirements/many-children.html",
        "open-usd",
        ("performance",),
        (),
        (
            Examples.MANY_CHILDREN_UNDER_A_SINGLE_PRIM_NOK,
            Examples.CHILDREN_DISTRIBUTED_AMONG_MULTIPLE_PRIMS_OK,
        ),
    )
    HI_003_V1_0_0 = (
        "HI.003", 
        "1.0.0",
        "root-is-xformable",
        "The root prim of the asset hierarchy must be transformable", 
        "capabilities/hierarchy/requirements/root-is-xformable.html",
        "other",
        ("essential",),
        (),
        (
            Examples.ROOT_IS_AN_XFORM_PRIM_NATURALLY_TRANSFORMABLE__OK,
            Examples.ROOT_IS_A_MATERIAL_PRIM_NOT_TRANSFORMABLE__NOK,
        ),
    )
    HI_004_V1_0_0 = (
        "HI.004", 
        "1.0.0",
        "stage-has-default-prim",
        "Stage must specify a default prim to define the root entry point.", 
        "capabilities/hierarchy/requirements/stage-has-default-prim.html",
        "open-usd",
        ("essential",),
        (),
        (
            Examples.NO_DEFAULTPRIM_SPECIFIED_NOK,
            Examples.DEFAULTPRIM_SPECIFIED_OK,
        ),
    )
    HI_008_V1_0_0 = (
        "HI.008", 
        "1.0.0",
        "logical-geometry-grouping",
        "Geometry should be grouped in a way that is logical for the object\u0027s structure.", 
        "capabilities/hierarchy/requirements/logical-geometry-grouping.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.LOGICAL_GROUPING_OF_CHAIR_COMPONENTS_OK,
            Examples.POOR_GROUPING_WITH_UNNECESSARY_COMPLEXITY_NOK,
        ),
    )
    HI_001_V1_0_0 = (
        "HI.001", 
        "1.0.0",
        "hierarchy-has-root",
        "Prim hierarchy must have a single root prim.", 
        "capabilities/hierarchy/requirements/hierarchy-has-root.html",
        "open-usd",
        ("essential",),
        (),
        (
            Examples.ALL_XFORMS_UNDER_SINGLE_ROOT_OK,
            Examples.PRIMS_THAT_ARE_NOT_PART_OF_THE_REFERENCEABLE_ASSET_ARE_PERMITTED_OK,
        ),
    )
    HI_012_V1_0_0 = (
        "HI.012", 
        "1.0.0",
        "empty-leaves",
        "Avoid empty leaf nodes in scene hierarchy", 
        "capabilities/hierarchy/requirements/empty-leaves.html",
        "open-usd",
        ("performance",),
        (),
        (
            Examples.UNNECESSARY_EMPTY_LEAF_PRIMS_NOK,
            Examples.PRIM_HIERARCHY_WITHOUT_UNNECESSARY_LEAF_PRIMS_OK,
        ),
    )
    HI_010_V1_0_0 = (
        "HI.010", 
        "1.0.0",
        "intentional-origin-positioning",
        "Origins of prims representing objects or groups that require placement should be positioned intentionally", 
        "capabilities/hierarchy/requirements/intentional-origin-positioning.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.CUBE_SHAPED_MESH_SITTING_ON_THE_GROUND_PLANE_OK,
            Examples.CEILING_FAN_WITH_ORIGIN_AT_THE_TOP_OF_THE_DOWN_ROD_OK,
            Examples.DOOR_PANEL_WITH_ORIGIN_AT_THE_HINGE_POINT_OK,
        ),
    )
    HI_009_V1_0_0 = (
        "HI.009", 
        "1.0.0",
        "kinematic-chain-hierarchy",
        "For articulated assets without joint definitions, the prim hierarchy should reflect the kinematic chain.", 
        "capabilities/hierarchy/requirements/kinematic-chain-hierarchy.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.ROBOT_ARM_WITH_KINEMATIC_CHAIN_HIERARCHY_OK,
            Examples.FLAT_HIERARCHY_IGNORING_KINEMATIC_RELATIONSHIPS_NOK,
        ),
    )
    HI_006_V1_0_0 = (
        "HI.006", 
        "1.0.0",
        "placeable-posable-are-xformable",
        "Prims representing objects or groups that require placement (including the asset root) shall be xformable.", 
        "capabilities/hierarchy/requirements/placeable-posable-are-xformable.html",
        "open-usd",
        ("essential",),
        (),
        (
            Examples.MESH_PRIM_INHERITS_USDGEOMXFORMABLE_OK,
            Examples.XFORM_PRIM_INHERITS_USDGEOMXFORMABLE_OK,
            Examples.LIGHT_PRIM_INHERITS_USDGEOMXFORMABLE_OK,
            Examples.MATERIAL_PRIM_DOES_NOT_INHERIT_USDGEOMXFORMABLE_NOK,
        ),
    )
    AA_002_V1_0_0 = (
        "AA.002", 
        "1.0.0",
        "supported-file-types",
        "Asset must use only supported file types", 
        "capabilities/core/atomic_asset/requirements/supported-file-types.html",
        "open-usd",
        ("essential",),
        (),
        (),
    )
    AA_OV_001_V1_0_0 = (
        "AA.OV.001", 
        "1.0.0",
        "ov-usdz-udim-limitation",
        "Texture UDIMs are not supported in USDZ files in NVIDIA Omniverse", 
        "capabilities/core/atomic_asset/requirements/ov-usdz-udim-limitation.html",
        "kit",
        ("limitation",),
        (),
        (),
    )
    AA_003_V1_0_0 = (
        "AA.003", 
        "1.0.0",
        "portable-asset-paths",
        "Asset paths should use forward slashes for cross-platform portability", 
        "capabilities/core/atomic_asset/requirements/portable-asset-paths.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.SUBLAYER_PATH_WITH_FORWARD_SLASHES_OK,
            Examples.REFERENCE_PATH_WITH_FORWARD_SLASHES_OK,
            Examples.ASSET_ATTRIBUTE_PATH_WITH_FORWARD_SLASHES_OK,
            Examples.SUBLAYER_PATH_WITH_BACKSLASHES_NOK,
            Examples.REFERENCE_PATH_WITH_BACKSLASHES_NOK,
            Examples.ADD_REFERENCE_PATH_WITH_BACKSLASHES_NOK,
            Examples.ASSET_ATTRIBUTE_PATH_WITH_BACKSLASHES_NOK,
        ),
    )
    AA_001_V1_0_0 = (
        "AA.001", 
        "1.0.0",
        "anchored-asset-paths",
        "Asset references should use anchored paths", 
        "capabilities/core/atomic_asset/requirements/anchored-asset-paths.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.USING_ANCHORED_PATHS_OK,
            Examples.USING_SEARCH_PATH_NOK,
            Examples.USING_ABSOLUTE_PATH_NOK,
            Examples.USING_ASSET_ROOT_PATH_THAT_TARGETS_A_LOCATION_ABOVE_THE_ASSET_ROOT_NOK,
        ),
    )
    UN_007_V1_0_0 = (
        "UN.007", 
        "1.0.0",
        "meters-per-unit-1",
        "Stage must specify metersPerUnit = 1.0 to define the linear unit scale", 
        "capabilities/core/units/requirements/meters-per-unit-1.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.NO_METERSPERUNIT_SPECIFIED_NOK,
            Examples.METERSPERUNIT_NOT_SET_TO_1_0_NOK,
            Examples.METERSPERUNIT_1_0_OK,
        ),
    )
    UN_006_V1_0_0 = (
        "UN.006", 
        "1.0.0",
        "upaxis-z",
        "Stage must specify upAxis = \"Z\" to define the orientation of the stage", 
        "capabilities/core/units/requirements/upaxis-z.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.NO_UPAXIS_SPECIFIED_NOK,
            Examples.Y_UP_SPECIFIED_NOK,
            Examples.Z_UP_SPECIFIED_OK,
        ),
    )
    UN_005_V1_0_0 = (
        "UN.005", 
        "1.0.0",
        "timecodes-per-second",
        "Stage must specify timeCodesPerSecond, if timesamples are present in the stage.", 
        "capabilities/core/units/requirements/timecodes-per-second.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.NO_TIMECODESPERSECOND_SPECIFIED_NOK,
            Examples.TIMECODESPERSECOND_SPECIFIED_OK,
        ),
    )
    UN_004_V1_0_0 = (
        "UN.004", 
        "1.0.0",
        "corrective-transforms",
        "Must apply corrective transforms for different units", 
        "capabilities/core/units/requirements/corrective-transforms.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.NO_CORRECTIVE_TRANSFORM_FOR_DIFFERENT_UNITS_NOK,
            Examples.COMPENSATING_TRANSFORM_APPLIED_OK,
        ),
    )
    UN_001_V1_0_0 = (
        "UN.001", 
        "1.0.0",
        "upaxis",
        "Stage must specify upAxis to define the orientation of the stage", 
        "capabilities/core/units/requirements/upaxis.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.NO_UPAXIS_SPECIFIED_NOK,
            Examples.UPAXIS_SPECIFIED_OK,
        ),
    )
    UN_002_V1_0_0 = (
        "UN.002", 
        "1.0.0",
        "meters-per-unit",
        "Stage must specify metersPerUnit to define the linear unit scale", 
        "capabilities/core/units/requirements/meters-per-unit.html",
        "core-usd",
        ("essential",),
        (),
        (
            Examples.NO_METERSPERUNIT_SPECIFIED_NOK,
            Examples.METERSPERUNIT_SPECIFIED_OK,
        ),
    )
    UN_003_V1_0_0 = (
        "UN.003", 
        "1.0.0",
        "kilograms-per-unit",
        "Stage must specify kilogramsPerUnit to define the mass unit scale, if physics objects are present in the stage.", 
        "capabilities/core/units/requirements/kilograms-per-unit.html",
        "core-usd",
        ("correctness",),
        (),
        (
            Examples.NO_KILOGRAMSPERUNIT_SPECIFIED_NOK,
            Examples.KILOGRAMSPERUNIT_SPECIFIED_OK,
        ),
    )
    VM_MDL_001_V1_0_0 = (
        "VM.MDL.001", 
        "1.0.0",
        "material-mdl-source-asset",
        "MDL material source assets must be properly referenced and accessible to ensure material loading and rendering.", 
        "capabilities/materials/requirements/material-mdl-source-asset.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.MISSING_MDL_PATH_NOK,
            Examples.WRONG_EXTENSION_NOK,
            Examples.RELATIVE_PATH_WITHOUT__NOK,
            Examples.NON_EXISTENT_MDL_FILE_NOK,
            Examples.PROPER_RELATIVE_PATH_TO_EXISTING_MDL_OK,
        ),
    )
    VM_D_001_V1_0_0 = (
        "VM.D.001", 
        "1.0.0",
        "material-duplicates",
        "Using fewer materials can result in better performance.", 
        "capabilities/materials/requirements/material-duplicates.html",
        "open-usd",
        ("performance",),
        (),
        (
            Examples.DUPLICATE_MATERIALS_NOK,
            Examples.REUSING_THE_SAME_MATERIAL_OK,
        ),
    )
    VM_PS_001_V1_0_0 = (
        "VM.PS.001", 
        "1.0.0",
        "material-preview-surface",
        "Material attributes must comply with the UsdPreviewSurface specification to ensure consistent rendering and viewer compatibility.", 
        "capabilities/materials/requirements/material-preview-surface.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.NON_COMPLIANT_ATTRIBUTES_NOK,
            Examples.WRONG_TYPE_AND_TIME_SAMPLED_TOKENS_NOK,
            Examples.COMPLIANT_ATTRIBUTES_OK,
        ),
    )
    VM_BIND_001_V1_0_0 = (
        "VM.BIND.001", 
        "1.0.0",
        "material-bind-scope",
        "Material bindings must use appropriate scope to ensure proper material assignment and inheritance.", 
        "capabilities/materials/requirements/material-bind-scope.html",
        "open-usd",
        ("correctness",),
        (),
        (
            Examples.MATERIAL_BINDING_REFERENCES_OUTSIDE_PAYLOAD_SCOPE_NOK,
            Examples.MATERIAL_BINDING_REFERENCES_WITHIN_PAYLOAD_SCOPE_OK,
        ),
    )
    VM_MDL_002_V1_0_0 = (
        "VM.MDL.002", 
        "1.0.0",
        "material-mdl-schema",
        "MDL Shaders must standard OpenUSD shader source attributes to ensure compatibility.", 
        "capabilities/materials/requirements/material-mdl-schema.html",
        "kit-107+",
        ("correctness",),
        (),
        (
            Examples.USING_DEPRECATED_MDL_SCHEMA_FORMAT_NOK,
            Examples.USING_CURRENT_MDL_SCHEMA_FORMAT_OK,
        ),
    )
    # Aliases for latest values
    SL_003 = SL_003_V1_0_0
    SL_NV_002 = SL_NV_002_V1_0_0
    SL_001 = SL_001_V1_0_0
    SL_QCODE_001 = SL_QCODE_001_V1_0_0
    NVM_004 = NVM_004_V1_0_0
    NVM_003 = NVM_003_V1_0_0
    NVM_006 = NVM_006_V1_0_0
    NVM_005 = NVM_005_V1_0_0
    NVM_002 = NVM_002_V1_0_0
    NVM_001 = NVM_001_V1_0_0
    VG_033 = VG_033_V1_0_0
    VG_008 = VG_008_V1_0_0
    VG_014 = VG_014_V1_0_0
    VG_005 = VG_005_V1_0_0
    VG_028 = VG_028_V1_0_0
    VG_009 = VG_009_V1_0_0
    VG_030 = VG_030_V1_0_0
    VG_004 = VG_004_V1_0_0
    VG_007 = VG_007_V1_0_0
    VG_020 = VG_020_V1_0_0
    VG_024 = VG_024_V1_0_0
    VG_034 = VG_034_V1_0_0
    VG_003 = VG_003_V1_0_0
    VG_RTX_002 = VG_RTX_002_V1_0_0
    VG_029 = VG_029_V1_0_0
    VG_017 = VG_017_V1_0_0
    VG_010 = VG_010_V1_0_0
    VG_RTX_001 = VG_RTX_001_V1_0_0
    VG_031 = VG_031_V1_0_0
    VG_027 = VG_027_V1_0_0
    VG_015 = VG_015_V1_0_0
    VG_018 = VG_018_V1_0_0
    VG_021 = VG_021_V1_0_0
    VG_002 = VG_002_V1_0_0
    VG_MESH_001 = VG_MESH_001_V1_0_0
    VG_019 = VG_019_V1_0_0
    VG_023 = VG_023_V1_0_0
    VG_032 = VG_032_V1_0_0
    VG_012 = VG_012_V1_0_0
    VG_025 = VG_025_V1_0_0
    VG_006 = VG_006_V1_0_0
    VG_022 = VG_022_V1_0_0
    VG_013 = VG_013_V1_0_0
    VG_011 = VG_011_V1_0_0
    VG_016 = VG_016_V1_0_0
    DC_001 = DC_001_V1_0_0
    DC_002 = DC_002_V1_0_0
    JT_ART_003 = JT_ART_003_V1_0_0
    JT_003 = JT_003_V1_0_0
    JT_002 = JT_002_V1_0_0
    JT_ART_002 = JT_ART_002_V1_0_0
    JT_001 = JT_001_V1_0_0
    JT_ART_001 = JT_ART_001_V1_0_0
    JT_ART_004 = JT_ART_004_V1_0_0
    RB_006 = RB_006_V1_0_0
    RB_COL_002 = RB_COL_002_V1_0_0
    RB_009 = RB_009_V1_0_0
    RB_COL_004 = RB_COL_004_V1_0_0
    RB_003 = RB_003_V1_0_0
    RB_COL_003 = RB_COL_003_V1_0_0
    RB_001 = RB_001_V1_0_0
    RB_007 = RB_007_V1_0_0
    RB_COL_001 = RB_COL_001_V1_0_0
    RB_005 = RB_005_V1_0_0
    HI_005 = HI_005_V1_0_0
    HI_011 = HI_011_V1_0_0
    HI_003 = HI_003_V1_0_0
    HI_004 = HI_004_V1_0_0
    HI_008 = HI_008_V1_0_0
    HI_001 = HI_001_V1_0_0
    HI_012 = HI_012_V1_0_0
    HI_010 = HI_010_V1_0_0
    HI_009 = HI_009_V1_0_0
    HI_006 = HI_006_V1_0_0
    AA_002 = AA_002_V1_0_0
    AA_OV_001 = AA_OV_001_V1_0_0
    AA_003 = AA_003_V1_0_0
    AA_001 = AA_001_V1_0_0
    UN_007 = UN_007_V1_0_0
    UN_006 = UN_006_V1_0_0
    UN_005 = UN_005_V1_0_0
    UN_004 = UN_004_V1_0_0
    UN_001 = UN_001_V1_0_0
    UN_002 = UN_002_V1_0_0
    UN_003 = UN_003_V1_0_0
    VM_MDL_001 = VM_MDL_001_V1_0_0
    VM_D_001 = VM_D_001_V1_0_0
    VM_PS_001 = VM_PS_001_V1_0_0
    VM_BIND_001 = VM_BIND_001_V1_0_0
    VM_MDL_002 = VM_MDL_002_V1_0_0