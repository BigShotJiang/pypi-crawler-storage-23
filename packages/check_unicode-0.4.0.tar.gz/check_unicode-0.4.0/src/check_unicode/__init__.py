"""Pre-commit hook to detect and fix non-ASCII Unicode characters."""

__version__ = "0.4.0"
