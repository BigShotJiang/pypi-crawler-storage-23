do_base_url = "https://api.digitalocean.com"
swarmpit_base_url = "https://swarmpit.doc.endevel.cz"
