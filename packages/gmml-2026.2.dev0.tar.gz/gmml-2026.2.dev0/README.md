# Gaussian Mixture Modeling Layer

This package contains the original Pytorch implementation of the
**Gaussian mixture modeling layer**.
