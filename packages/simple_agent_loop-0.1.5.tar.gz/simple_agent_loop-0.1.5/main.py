def main():
    print("Hello from agent-loop!")


if __name__ == "__main__":
    main()
