"""Ivy Language Server Protocol implementation."""

__version__ = "0.5.5"
