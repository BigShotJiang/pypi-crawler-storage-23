"""Documentation review agent for documentation quality analysis.

This module provides DocsAgent, which analyzes code for documentation
quality, including docstring coverage, README completeness, and API
documentation using LLM-powered semantic analysis.

Checks Performed:
    - Module/file documentation presence
    - Function/class docstring coverage
    - Parameter and return documentation
    - README file presence and completeness
    - API documentation quality
    - Test result verification (when test results provided)

Scoring Dimensions:
    - docstring_coverage: Percentage of public items with documentation
    - readme_complete: README file presence and completeness
    - api_documented: Public API documentation quality

Test Result Verification:
    - When test_results parameter is provided, DocsAgent verifies
      documentation claims against actual test execution results
    - No test results -> test_status: "unknown"
    - Test failures -> test_status: "failed" with failure count
    - All tests pass -> test_status: "passed"

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/agents/prompts/docs_analysis.txt
    - obra/agents/test_execution.py
"""

import logging
import time
from pathlib import Path

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.registry import register_agent
from obra.agents.tier_config import resolve_agent_tier_config
from obra.api.protocol import AgentType, Priority
from obra.llm.content_chunker import ContentChunker
from obra.review.quality_tiers import IssueCountTier

logger = logging.getLogger(__name__)

# Prompt template directory
PROMPTS_DIR = Path(__file__).parent / "prompts"

# Metadata value types used in agent results
DocMetadataValue = bool | int | float | str | dict[str, float]
DocMetadata = dict[str, DocMetadataValue]


def _load_prompt_template(name: str) -> str:
    """Load a prompt template from the prompts directory.

    Args:
        name: Template filename (e.g., "docs_analysis.txt")

    Returns:
        Template content as string

    Raises:
        FileNotFoundError: If template doesn't exist
    """
    template_path = PROMPTS_DIR / name
    return template_path.read_text(encoding="utf-8")


# Required sections for a complete README (with alternative phrasings)
# Each entry is a tuple of (canonical_name, list_of_patterns)
README_REQUIRED_SECTIONS = [
    (
        "installation",
        [
            "install",
            "installation",
            "installing",
            "setup",
            "getting started",
            "quick start",
            "quickstart",
        ],
    ),
    ("usage", ["usage", "how to use", "using", "basic usage", "example", "examples"]),
]

README_OPTIONAL_SECTIONS = [
    (
        "contributing",
        ["contributing", "contribute", "development", "how to contribute"],
    ),
    ("license", ["license", "licensing"]),
    ("requirements", ["requirements", "prerequisites", "dependencies", "deps"]),
    ("features", ["features", "capabilities", "what it does"]),
    ("api", ["api", "api reference", "reference", "documentation", "docs"]),
]


@register_agent(AgentType.DOCS)
class DocsAgent(BaseAgent):
    """Documentation review agent with LLM-powered analysis.

    Uses LLM-based analysis for comprehensive documentation quality review.
    Works with any programming language (Python, JavaScript, Go, etc.).

    When no LLM config is provided, returns empty result with warning.

    Test Result Verification:
        Pass test_results from TestExecutionAgent to verify documentation
        claims against actual test execution. The agent will include
        test_status in metadata:
        - "unknown": No test results provided
        - "passed": All tests passed
        - "failed": Some tests failed (includes failure_count)

    Example:
        >>> agent = DocsAgent(Path("/workspace"), llm_config=llm_config)
        >>> result = agent.analyze(
        ...     item_id="T1",
        ...     changed_files=["src/auth.py"],
        ...     timeout_ms=60000
        ... )
        >>> print(f"Docstring coverage: {result.scores['docstring_coverage']}")
        >>> print(f"Test status: {result.metadata.get('test_status')}")
    """

    agent_type = AgentType.DOCS

    def __init__(
        self,
        working_dir: Path,
        llm_config=None,
        log_event=None,
        test_results: AgentResult | None = None,
    ) -> None:
        """Initialize documentation review agent.

        Args:
            working_dir: Working directory containing code to analyze
            llm_config: Optional LLM configuration dict for CLI-based analysis
            log_event: Optional callback for event logging
            test_results: Optional test execution results from TestExecutionAgent.
                         When provided, DocsAgent verifies documentation claims
                         against actual test outcomes.
        """
        super().__init__(working_dir, llm_config=llm_config, log_event=log_event)
        self._test_results = test_results

    def get_test_status(self) -> dict[str, str | int]:
        """Query test execution status from provided test results.

        Returns a dictionary with test status information based on
        TestExecutionAgent results:
        - No results: {"status": "unknown"}
        - Failures: {"status": "failed", "failure_count": N}
        - All pass: {"status": "passed"}

        Returns:
            Dictionary with test status and optional failure count
        """
        if self._test_results is None:
            return {"status": "unknown"}

        # Check if test results are from TEST_EXECUTION agent type
        if self._test_results.agent_type != AgentType.TEST_EXECUTION:
            logger.warning(
                f"Test results are from {self._test_results.agent_type.value}, "
                "expected TEST_EXECUTION"
            )
            return {"status": "unknown"}

        # Check test execution status
        if self._test_results.status != "complete":
            # Test execution didn't complete (timeout, error, pending)
            return {"status": "unknown", "reason": self._test_results.status}

        # Check for test failures
        metadata = self._test_results.metadata or {}
        if metadata.get("tests_passed") is True:
            return {"status": "passed"}

        # Tests failed - count failures
        failure_count = metadata.get("failure_count", len(self._test_results.issues))
        return {"status": "failed", "failure_count": failure_count}

    def _build_test_verification_metadata(self) -> dict[str, str | int]:
        """Build test verification metadata for result.

        Returns metadata dict with test_status and optionally failure_count.
        This metadata is included in all successful DocsAgent results to
        inform downstream consumers about test verification status.

        Returns:
            Dictionary with test verification fields
        """
        test_status = self.get_test_status()

        result: dict[str, str | int] = {"test_status": test_status["status"]}

        # Include failure count if tests failed
        if test_status["status"] == "failed" and "failure_count" in test_status:
            result["test_failure_count"] = test_status["failure_count"]

        # Include reason if test status is unknown due to incomplete execution
        if test_status["status"] == "unknown" and "reason" in test_status:
            result["test_status_reason"] = test_status["reason"]

        return result

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code for documentation quality.

        Uses LLM-based analysis when invoker is available. Analyzes
        any programming language, not just Python.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches [A-Z]+-[0-9]+ format.
            changed_files: If None, analyzes all files in working_dir.
                          If provided, only analyzes specified files.
                          Uses blocklist approach to analyze all code files.
            timeout_ms: If None, uses config-based timeout via get_review_agent_timeout().
                       If provided, MUST be positive integer. Typical range: [5000-300000].

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed
            timeout_ms: Maximum execution time (None = use config default)

        Returns:
            AgentResult with documentation issues and scores
        """
        # Resolve timeout from config if not provided
        timeout_ms = self._resolve_timeout_ms(timeout_ms)

        # Validate parameters (ADR-042)
        self._validate_analyze_params(item_id, timeout_ms)

        start_time = time.time()
        logger.info(f"DocsAgent analyzing {item_id}")

        # Get files to analyze - use blocklist approach for language-agnostic analysis
        files = self.get_files_to_analyze(changed_files=changed_files)
        logger.debug(f"Analyzing {len(files)} files for documentation")

        # Use LLM-based analysis if config is available
        if self._llm_config:
            return self._analyze_with_llm(
                item_id=item_id,
                files=files,
                start_time=start_time,
                timeout_ms=timeout_ms,
            )

        # Fallback: No config available, return empty result with warning
        logger.warning("DocsAgent: No LLM config available, skipping analysis")
        execution_time = int((time.time() - start_time) * 1000)

        # Build metadata with test verification
        metadata: dict[str, str | int] = {
            "files_analyzed": 0,
            "mode": "no_invoker",
        }
        metadata.update(self._build_test_verification_metadata())

        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=[],
            scores={
                "docstring_coverage": 1.0,
                "readme_complete": 1.0,
                "api_documented": 1.0,
            },
            execution_time_ms=execution_time,
            metadata=metadata,
        )

    def _analyze_with_llm(
        self,
        # TODO: Will be used for item-specific analysis configuration and result
        # correlation in multi-item analysis batches
        item_id: str,
        files: list[Path],
        start_time: float,
        timeout_ms: int,
    ) -> AgentResult:
        """Perform LLM-based documentation analysis.

        Args:
            item_id: Plan item ID
            files: List of files to analyze
            start_time: Analysis start time
            timeout_ms: Maximum execution time

        Returns:
            AgentResult with issues from LLM analysis
        """
        deadline = start_time + (timeout_ms / 1000)

        # Load tier configuration and prompt template
        try:
            docs_template = _load_prompt_template("docs_analysis.txt")
        except FileNotFoundError as e:
            logger.exception("Failed to load prompt template")
            return self._error_result(f"Missing prompt template: {e}", start_time)

        llm_config = resolve_agent_tier_config("doc_audit")

        # Check README (quick, non-LLM based)
        readme_issues, readme_score = self._check_readme(deadline)

        # Collect file contents for analysis
        files_content, collection_stats = self._collect_files_for_analysis(files, deadline)

        if not files_content:
            return self._empty_files_result(
                files, collection_stats, readme_issues, readme_score, start_time
            )

        # Run LLM analysis
        return self._run_llm_analysis(
            files_content=files_content,
            template=docs_template,
            llm_config=llm_config,
            timeout_ms=timeout_ms,
            start_time=start_time,
            readme_issues=readme_issues,
            readme_score=readme_score,
        )

    def _collect_files_for_analysis(
        self,
        files: list[Path],
        deadline: float,
    ) -> tuple[dict[str, str], dict[str, int | bool]]:
        """Collect file contents for analysis, filtering test/excluded/init files.

        Args:
            files: List of files to process
            deadline: Timeout deadline

        Returns:
            Tuple of (files_content dict, collection_stats dict)
        """
        files_content: dict[str, str] = {}
        stats: dict[str, int | bool] = {
            "excluded_count": 0,
            "test_file_count": 0,
            "init_file_count": 0,
            "read_fail_count": 0,
            "timeout_during_collection": False,
        }

        for file_path in files:
            if time.time() > deadline:
                logger.warning("DocsAgent timed out during file collection")
                stats["timeout_during_collection"] = True
                break

            if self.is_test_file(file_path):
                stats["test_file_count"] = int(stats["test_file_count"]) + 1
                continue
            if file_path.name == "__init__.py":
                stats["init_file_count"] = int(stats["init_file_count"]) + 1
                continue
            if self.is_excluded_file(file_path):
                stats["excluded_count"] = int(stats["excluded_count"]) + 1
                continue

            content = self.read_file(file_path)
            if content:
                try:
                    rel_path = str(file_path.relative_to(self._working_dir))
                except ValueError:
                    rel_path = str(file_path)
                files_content[rel_path] = content
            else:
                stats["read_fail_count"] = int(stats["read_fail_count"]) + 1

        return files_content, stats

    def _empty_files_result(
        self,
        files: list[Path],
        stats: dict[str, int | bool],
        readme_issues: list[AgentIssue],
        readme_score: float,
        start_time: float,
    ) -> AgentResult:
        """Build result when no files remain after filtering.

        Args:
            files: Original file list
            stats: Collection statistics
            readme_issues: Issues from README check
            readme_score: README completeness score
            start_time: Analysis start time

        Returns:
            AgentResult with appropriate status
        """
        has_readme_findings = len(readme_issues) > 0
        status = "complete" if has_readme_findings else "skipped"

        if not has_readme_findings:
            logger.warning(
                "DocsAgent: No analyzable files and no README findings. "
                "working_dir=%s, files_scanned=%d, test_files=%d, init_files=%d, "
                "excluded=%d, read_failed=%d, timeout=%s",
                self._working_dir,
                len(files),
                stats["test_file_count"],
                stats["init_file_count"],
                stats["excluded_count"],
                stats["read_fail_count"],
                stats["timeout_during_collection"],
            )
        else:
            logger.info(
                "DocsAgent: No files for LLM analysis, but README check found %d issues.",
                len(readme_issues),
            )

        skip_metadata: DocMetadata = {
            "files_analyzed": 0,
            "mode": "llm",
            "skip_reason": "no_files_after_filter",
            "readme_checked": True,
            "readme_findings": len(readme_issues),
            "working_dir": str(self._working_dir),
            "files_scanned": len(files),
            "files_test": stats["test_file_count"],
            "files_init": stats["init_file_count"],
            "files_excluded": stats["excluded_count"],
            "files_read_failed": stats["read_fail_count"],
            "timeout_during_collection": stats["timeout_during_collection"],
        }
        skip_metadata.update(self._build_test_verification_metadata())

        return AgentResult(
            agent_type=self.agent_type,
            status=status,
            issues=readme_issues,
            scores={
                "docstring_coverage": 1.0,
                "readme_complete": readme_score,
                "api_documented": 1.0,
            },
            execution_time_ms=int((time.time() - start_time) * 1000),
            metadata=skip_metadata,
        )

    def _error_result(self, error: str, start_time: float) -> AgentResult:
        """Build an error result.

        Args:
            error: Error message
            start_time: Analysis start time

        Returns:
            AgentResult with error status
        """
        return AgentResult(
            agent_type=self.agent_type,
            status="error",
            error=error,
            execution_time_ms=int((time.time() - start_time) * 1000),
        )

    def _run_llm_analysis(
        self,
        files_content: dict[str, str],
        template: str,
        llm_config: dict,
        timeout_ms: int,
        start_time: float,
        readme_issues: list[AgentIssue],
        readme_score: float,
    ) -> AgentResult:
        """Run LLM analysis and build result.

        Args:
            files_content: Dict mapping file paths to contents
            template: Prompt template
            llm_config: LLM configuration
            timeout_ms: Maximum execution time
            start_time: Analysis start time
            readme_issues: Issues from README check
            readme_score: README completeness score

        Returns:
            AgentResult with analysis findings
        """
        all_issues = list(readme_issues)
        code_content = self._format_code_for_prompt(files_content)
        logger.info(f"Running docs analysis with {llm_config['provider']}/{llm_config['model']}")

        analysis_prompt = template.format(code_content=code_content)
        analysis_prompt = self._inject_intent_context(analysis_prompt)

        try:
            response_text = self._invoke_cli(
                call_site="docs_analysis",
                prompt=analysis_prompt,
                timeout_ms=timeout_ms,
            )

            if not response_text:
                logger.warning("LLM invocation returned empty response")
                return self._error_result("LLM invocation returned empty response", start_time)

            issues = self.parse_structured_response(response_text, prefix="DOC")
            all_issues.extend(issues)
            logger.info(f"Found {len(issues)} documentation issues from LLM")

        except Exception as e:
            logger.exception(f"Documentation analysis failed: {e}")
            return self._error_result(f"Analysis failed: {e}", start_time)

        scores = self._calculate_scores_from_issues(all_issues, readme_score)
        execution_time = int((time.time() - start_time) * 1000)
        logger.info(f"DocsAgent complete: {len(all_issues)} issues found in {execution_time}ms")

        metadata: DocMetadata = {
            "files_analyzed": len(files_content),
            "mode": "llm",
            "provider": llm_config["provider"],
            "model": llm_config["model"],
            "issues_found": len(all_issues),
            "scores": scores,
        }
        metadata.update(self._build_test_verification_metadata())

        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=all_issues,
            scores=scores,
            execution_time_ms=execution_time,
            metadata=metadata,
        )

    def _format_code_for_prompt(self, files_content: dict[str, str]) -> str:
        """Format file contents for LLM prompt.

        Args:
            files_content: Dict mapping file paths to contents

        Returns:
            Formatted string with file headers
        """
        # Get model from agent config for content chunking
        model = "sonnet"  # Default model
        provider = "anthropic"  # Default provider
        if self._llm_config:
            model = self._llm_config.get("model", model)
            provider = self._llm_config.get("provider", provider)
        chunker = ContentChunker(model=model, provider=provider)

        parts = []
        for file_path, content in files_content.items():
            # Limit content size to avoid token limits (model-aware)
            truncated = chunker.truncate(content)
            numbered = "\n".join(
                f"{line_no:>4}: {line}"
                for line_no, line in enumerate(truncated.splitlines(), start=1)
            )
            parts.append(f"=== FILE: {file_path} ===\n{numbered}")
        return "\n\n".join(parts)

    def _check_readme(
        self,
        # TODO: Will be used for timeout-aware README analysis (e.g., skip expensive
        # checks if deadline is near)
        _deadline: float,
    ) -> tuple[list[AgentIssue], float]:
        """Check README file presence and completeness.

        Args:
            deadline: Timeout deadline

        Returns:
            Tuple of (issues, score)
        """
        issues: list[AgentIssue] = []
        issue_index = 0

        # Look for README
        readme_files = list(self._working_dir.glob("README*"))
        if not readme_files:
            issues.append(
                AgentIssue(
                    id=self._generate_issue_id("DOC", issue_index + 1),
                    title="Missing README file",
                    description="Project should have a README.md file with installation and usage instructions.",
                    priority=Priority.P1,
                    dimension="readme_complete",
                    suggestion="Create README.md with project description, installation, and usage sections",
                )
            )
            return issues, 0.0

        readme_files_sorted = sorted(
            readme_files,
            key=lambda path: (path.name.lower() != "readme.md", path.name.lower()),
        )
        readme_path = readme_files_sorted[0]
        content = self.read_file(readme_path).lower()

        # Check required sections using fuzzy matching
        found_sections: set[str] = set()
        for section_name, patterns in README_REQUIRED_SECTIONS:
            for pattern in patterns:
                if pattern in content:
                    found_sections.add(section_name)
                    break

        # Find missing required sections
        required_section_names = {name for name, _ in README_REQUIRED_SECTIONS}
        missing_sections = required_section_names - found_sections
        for section in missing_sections:
            issue_index += 1
            issues.append(
                AgentIssue(
                    id=self._generate_issue_id("DOC", issue_index),
                    title=f"README missing '{section}' section",
                    description=f"README should include a '{section}' section.",
                    priority=Priority.P2,
                    file_path="README.md",
                    dimension="readme_complete",
                    suggestion=f"Add a '{section}' section to README.md",
                )
            )

        # Calculate score
        required_found = len(found_sections)
        required_total = len(README_REQUIRED_SECTIONS)

        # Check optional sections for bonus using fuzzy matching
        optional_found = 0
        for _, patterns in README_OPTIONAL_SECTIONS:
            if any(pattern in content for pattern in patterns):
                optional_found += 1
        optional_bonus = min(optional_found / len(README_OPTIONAL_SECTIONS) * 0.2, 0.2)

        score = (required_found / required_total * 0.8) + optional_bonus

        return issues, score

    def _calculate_scores_from_issues(
        self,
        issues: list[AgentIssue],
        readme_score: float,
    ) -> dict[str, float]:
        """Calculate dimension scores based on issues.

        Args:
            issues: All issues found
            readme_score: README completeness score from _check_readme

        Returns:
            Dict of dimension scores
        """
        docstring_issues = 0
        api_issues = 0

        for issue in issues:
            dim = issue.dimension
            if dim == "docstring_coverage":
                docstring_issues += 1
            elif dim == "api_documented":
                api_issues += 1
            elif dim == "readme_complete":
                # README issues counted via readme_score
                pass
            # Map priority to dimension for LLM issues without explicit dimension
            elif issue.priority in (Priority.P0, Priority.P1):
                docstring_issues += 1
            else:
                api_issues += 1

        def score(issue_count: int) -> float:
            return IssueCountTier.from_count(issue_count).base_score

        return {
            "docstring_coverage": score(docstring_issues),
            "readme_complete": round(readme_score, 2),
            "api_documented": score(api_issues),
        }


__all__ = ["DocsAgent"]
