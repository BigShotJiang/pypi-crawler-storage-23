"""Prompts for plan examination operations.

Contains prompts extracted from obra/hybrid/handlers/examine.py as part of
the prompt library refactoring (REFACTOR-PROMPT-LIBRARY-001).

Prompts:
    build_fallback_examine_prompt: Builder for fallback examination prompts
"""

from __future__ import annotations

__all__ = ["build_fallback_examine_prompt"]


def build_fallback_examine_prompt(
    plan_items: list[dict],
    valid_categories: list[str],
) -> str:
    """Build the fallback examination prompt for plan review.

    Args:
        plan_items: List of plan item dicts with 'id', 'type', 'title' (or 'description')
        valid_categories: List of valid issue category strings

    Returns:
        Formatted examination prompt string
    """
    plan_items_text = []
    for item in plan_items:
        item_id = item.get("id", "unknown")
        item_type = item.get("type", "task")
        title = item.get("title", item.get("description", "Untitled"))
        plan_items_text.append(f"- [{item_id}] ({item_type}) {title}")

    plan_text = "\n".join(plan_items_text) if plan_items_text else "(no items)"

    return f"""Examine the following implementation plan for potential issues.

## Plan Items
{plan_text}

## Examination Criteria
Identify any issues in the following categories:
{", ".join(valid_categories)}

For each issue found, provide:
1. A unique issue ID (e.g., EXAM-001)
2. The category from the list above
3. Severity level (P0=critical, P1=high, P2=medium, P3=low)
4. A clear description of the issue
5. Which plan item IDs are affected

Focus on:
- Missing requirements or unclear specifications
- Potential blockers or dependencies not addressed
- Security or testing gaps
- Feasibility concerns

If the plan looks complete and well-structured, it's acceptable to report zero issues.
"""
