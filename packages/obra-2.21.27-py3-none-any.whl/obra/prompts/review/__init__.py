"""Review and quality assessment prompts.

This package contains prompts for plan examination and quality review:
- examine: Fallback examination prompts
- quality: Quality assessment prompts
- alignment: Plan/story intent alignment prompts
- gap_check: Story and epic gap detection prompts
"""

from __future__ import annotations

# Define lazy-loaded exports
_SUBMODULE_EXPORTS = {
    # examine.py exports
    "build_fallback_examine_prompt": ".examine",
    # quality.py exports
    "build_quality_assessment_prompt": ".quality",
    # alignment.py exports
    "build_plan_intent_alignment_prompt": ".alignment",
    "build_story_intent_alignment_prompt": ".alignment",
    "build_gap_detection_prompt": ".alignment",
    # gap_check.py exports
    "build_story_gap_prompt": ".gap_check",
    "build_epic_gap_prompt": ".gap_check",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name, package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
