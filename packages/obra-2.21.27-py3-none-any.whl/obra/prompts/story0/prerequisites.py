"""Prompt builder for Story 0 derivation.

This module provides prompts for analyzing execution plans to identify
environment prerequisites needed before implementation can begin.

Functions:
    build_story0_derivation_prompt: Build prerequisite analysis prompt
    build_story0_manifest_prompt: Build manifest generation prompt

Related:
    - obra/hybrid/handlers/story0.py (Story0Handler)
    - obra/story0/models.py (PrerequisiteCategory)
"""

from __future__ import annotations

import json

__all__ = ["build_story0_derivation_prompt", "build_story0_manifest_prompt"]

STORY0_DERIVATION_PROMPT_TEMPLATE = """## Environment Prerequisites Analysis

Analyze the following execution plan and identify all environment prerequisites
needed before implementation can begin.

### Execution Plan
{plan}

### Objective
{objective}

### Current Environment
- Manifest: {manifest_type}
- Existing dependencies: {existing_dependencies}
- Working directory: {working_dir}

### Task
Identify prerequisites NOT already present:
1. Dependencies the plan requires (libraries, tools)
2. Credentials/API keys mentioned or implied
3. Services (databases, caches, queues) needed
4. Testing/verification tools required

Categorize each as: AUTO, AUTO_CONFIRM, CREDENTIAL, SERVICE, USER_ACTION, ACCOUNT, LOCAL_CAPABILITY

LOCAL_CAPABILITY - Host environment features (display server, audio output, GPU).
NOT network services. Examples: GUI display (X11/Wayland), audio output, filesystem
permissions. Use for prerequisites that are OS/host features, not containerizable services.

For each prerequisite, include:
- id
- name
- category
- source (MANIFEST or INFERRED)
- reason (short evidence for why it is required and why the source applies)
- ecosystem (optional, string): One of python, node, rust, go, ruby, system. Use the language ecosystem for installable packages. Use "system" for OS-level tools (git, docker, make, gcc, curl, etc.) that are NOT language packages.

If no prerequisites are needed beyond what's already present, return an empty list.

### Output Format
Return JSON only (no markdown):

{{
  "prerequisites": [
    {{
      "id": "pytest",
      "name": "pytest",
      "category": "AUTO",
      "source": "MANIFEST",
      "reason": "Listed in pyproject.toml dev dependencies",
      "ecosystem": "python"
    }},
    {{
      "id": "STRIPE_API_KEY",
      "name": "Stripe API key",
      "category": "CREDENTIAL",
      "source": "INFERRED",
      "reason": "Tasks mention Stripe integration"
    }},
    {{
      "id": "gui_display",
      "name": "GUI display server",
      "category": "LOCAL_CAPABILITY",
      "source": "INFERRED",
      "reason": "Tasks require rendering a graphical window"
    }}
  ]
}}
"""

STORY0_MANIFEST_PROMPT_TEMPLATE = """## Manifest Generation Contract

You are generating project manifests for a new or partially scaffolded repository.
Analyze the objective, tooling discovery output, and repository structure.

Objective:
{objective}

Tooling discovery:
{tooling_info}

Repository structure (relative paths):
{repo_structure}

Return ONLY valid JSON with this schema:
{{
  "manifests": [
    {{
      "type": "pyproject.toml|package.json|Cargo.toml|go.mod|Gemfile",
      "path": ".",
      "contents": "<complete manifest contents>",
      "rationale": "<short explanation>"
    }}
  ]
}}

Rules:
- Use minimal dependencies plus dev tools required for the objective.
- Use relative paths. Use "." for repo root.
- Each manifest must be syntactically valid and complete for its ecosystem.
- If multiple ecosystems are required, output multiple manifests.

Schema validation requirements:
- pyproject.toml must include a [project] section with name.
- package.json must include name and version.

Example (Python):
{{
  "manifests": [
    {{
      "type": "pyproject.toml",
      "path": ".",
      "contents": "[project]\\nname = \\"demo\\"\\nversion = \\"0.1.0\\"\\ndependencies = [\\"fastapi\\"]\\n\\n[project.optional-dependencies]\\ndev = [\\"pytest\\", \\"ruff\\"]\\n",
      "rationale": "Python backend with FastAPI and test tools."
    }}
  ]
}}

Example (Node):
{{
  "manifests": [
    {{
      "type": "package.json",
      "path": ".",
      "contents": "{{\\n  \\"name\\": \\"demo\\",\\n  \\"version\\": \\"0.1.0\\",\\n  \\"scripts\\": {{\\"test\\": \\"vitest\\"}},\\n  \\"devDependencies\\": {{\\"vitest\\": \\"^1.0.0\\"}}\\n}}",
      "rationale": "Frontend with Vitest setup."
    }}
  ]
}}
"""


def build_story0_derivation_prompt(
    plan: str | dict,
    objective: str,
    manifest_type: str,
    existing_deps: list[str],
    working_dir: str,
) -> str:
    """Build the Story 0 derivation prompt.

    Args:
        plan: Execution plan text (YAML/JSON or prose)
        objective: Original user objective
        manifest_type: Manifest type (pyproject.toml, package.json, etc.)
        existing_deps: Dependencies detected from manifest
        working_dir: Working directory path

    Returns:
        Prompt string for Story 0 derivation
    """
    deps_text = ", ".join(existing_deps) if existing_deps else "None detected"
    plan_text = json.dumps(plan, indent=2, ensure_ascii=True) if isinstance(plan, dict) else plan
    return STORY0_DERIVATION_PROMPT_TEMPLATE.format(
        plan=plan_text,
        objective=objective,
        manifest_type=manifest_type,
        existing_dependencies=deps_text,
        working_dir=working_dir,
    )


def build_story0_manifest_prompt(
    objective: str,
    tooling_info: dict | None,
    repo_structure: list[str],
) -> str:
    """Build the Story 0 manifest generation prompt."""
    tooling_text = json.dumps(tooling_info or {}, indent=2, ensure_ascii=True)
    structure_text = "\n".join(repo_structure) if repo_structure else "None"
    return STORY0_MANIFEST_PROMPT_TEMPLATE.format(
        objective=objective,
        tooling_info=tooling_text,
        repo_structure=structure_text,
    )
