"""Debug & Advanced View widget.

Provides an interface for developer/debug settings that are otherwise
only accessible through the raw Full Config tree (Menu 7).

Sections:
- Prompt & Template Retention
- Logging & Observability
- Breakpoints & Guards
- Resilience & Timeouts
- Rate Limits & Parallelism
- Monitoring
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Collapsible, Input, Select, Static, Switch

from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin


# Setting definitions: (config_path, label, description, type, extra)
# type: "bool", "int", "select"
# extra: for "select" -> list of options; for "int" -> (min, max, default)

SECTION_DEFINITIONS: list[dict[str, Any]] = [
    {
        "id": "prompts",
        "title": "Prompt & Template Retention",
        "description": "Control whether prompt and template files are kept on disk for debugging.",
        "settings": [
            {
                "path": "orchestration.prompts.retain",
                "label": "Retain Prompt Files",
                "description": "Keep prompt files on disk after execution",
                "type": "bool",
                "default": False,
            },
            {
                "path": "orchestration.template_retention.keep_on_success",
                "label": "Keep Templates on Success",
                "description": "Keep template-edit JSON files after successful validation",
                "type": "bool",
                "default": False,
            },
            {
                "path": "orchestration.template_retention.keep_on_error",
                "label": "Keep Templates on Error",
                "description": "Keep template-edit JSON files when validation fails",
                "type": "bool",
                "default": True,
            },
            {
                "path": "orchestration.prompts.max_files",
                "label": "Max Prompt Files",
                "description": "Maximum prompt files to retain (used by cleanup command)",
                "type": "int",
                "min": 10,
                "max": 1000,
                "default": 200,
            },
            {
                "path": "orchestration.prompts.cleanup_age_hours",
                "label": "Cleanup Age (hours)",
                "description": "Prompt files older than this are eligible for cleanup",
                "type": "int",
                "min": 1,
                "max": 168,
                "default": 24,
            },
        ],
    },
    {
        "id": "logging",
        "title": "Logging & Observability",
        "description": "Debug mode, verbose logging, and interaction saving.",
        "settings": [
            {
                "path": "features.development_debug.enabled",
                "label": "Development Debug Mode",
                "description": "Master toggle for development debug features",
                "type": "bool",
                "default": False,
            },
            {
                "path": "features.development_debug.debug_features.verbose_logging",
                "label": "Verbose Logging",
                "description": "Enable extra-verbose debug logging output",
                "type": "bool",
                "default": False,
            },
            {
                "path": "features.development_debug.debug_features.save_interactions",
                "label": "Save LLM Interactions",
                "description": "Persist all LLM request/response pairs for debugging",
                "type": "bool",
                "default": False,
            },
            {
                "path": "features.development_debug.debug_features.audit_logging",
                "label": "Audit Logging",
                "description": "Log destructive operations for audit trail",
                "type": "bool",
                "default": False,
            },
        ],
    },
    {
        "id": "breakpoints",
        "title": "Breakpoints & Guards",
        "description": "Fail-safe intervention points and interactive prompt detection.",
        "settings": [
            {
                "path": "features.development_debug.breakpoints.enabled",
                "label": "Breakpoints Enabled",
                "description": "Enable fail-safe intervention points during execution",
                "type": "bool",
                "default": False,
            },
            {
                "path": "features.development_debug.breakpoints.triggers.validation_failed",
                "label": "Trigger: Validation Failed",
                "description": "Break on validation failures",
                "type": "bool",
                "default": True,
            },
            {
                "path": "features.development_debug.breakpoints.triggers.rate_limit_hit",
                "label": "Trigger: Rate Limit Hit",
                "description": "Break on LLM rate limit errors",
                "type": "bool",
                "default": True,
            },
            {
                "path": "features.development_debug.breakpoints.triggers.unexpected_error",
                "label": "Trigger: Unexpected Error",
                "description": "Break on unexpected errors",
                "type": "bool",
                "default": True,
            },
            {
                "path": "orchestration.watchdog.enabled",
                "label": "Session Watchdog",
                "description": "Detect stalled sessions with no progress",
                "type": "bool",
                "default": True,
            },
            {
                "path": "orchestration.watchdog.stall_timeout_s",
                "label": "Stall Timeout (seconds)",
                "description": "Seconds of no events before session is considered stalled",
                "type": "int",
                "min": 60,
                "max": 1800,
                "default": 300,
            },
            {
                "path": "orchestration.interactive_guard.enabled",
                "label": "Interactive Guard",
                "description": "Detect and block interactive shell prompts during execution",
                "type": "bool",
                "default": True,
            },
            {
                "path": "orchestration.interactive_guard.retry_max",
                "label": "Guard Retry Max",
                "description": "Maximum retries after interactive guard triggers",
                "type": "int",
                "min": 0,
                "max": 5,
                "default": 1,
            },
        ],
    },
    {
        "id": "resilience",
        "title": "Resilience & Timeouts",
        "description": "Timeout and retry policies for orchestration operations.",
        "settings": [
            {
                "path": "orchestration.timeouts.agent_execution_s",
                "label": "Agent Execution Timeout (s)",
                "description": "Seconds for agent task completion (0 = no limit)",
                "type": "int",
                "min": 0,
                "max": 14400,
                "default": 5400,
            },
            {
                "path": "orchestration.timeouts.review_agent_s",
                "label": "Review Agent Timeout (s)",
                "description": "Seconds per review agent run",
                "type": "int",
                "min": 0,
                "max": 7200,
                "default": 1800,
            },
            {
                "path": "orchestration.timeouts.cli_runner_s",
                "label": "CLI Runner Timeout (s)",
                "description": "Fallback timeout for CLI LLM operations",
                "type": "int",
                "min": 0,
                "max": 14400,
                "default": 7200,
            },
            {
                "path": "orchestration.timeouts.llm_stream_idle_s",
                "label": "LLM Stream Idle Timeout (s)",
                "description": "Kill subprocess if no output within this window (0 = disable)",
                "type": "int",
                "min": 0,
                "max": 1800,
                "default": 300,
            },
            {
                "path": "orchestration.resilience.default.max_retries",
                "label": "Default Max Retries",
                "description": "Maximum retry attempts for unspecified handlers",
                "type": "int",
                "min": 0,
                "max": 10,
                "default": 3,
            },
        ],
    },
    {
        "id": "rate_limits",
        "title": "Rate Limits & Parallelism",
        "description": (
            "Control staggering of parallel LLM calls to avoid provider rate limits. "
            "Applies across all pipeline phases (derivation, intent alignment, review agents)."
        ),
        "settings": [
            {
                "path": "orchestration.parallel.worker_delay_s",
                "label": "Default Worker Delay (seconds)",
                "description": "Delay between starting each parallel worker (0 = no stagger)",
                "type": "float",
                "min": 0.0,
                "max": 60.0,
                "default": 1.0,
            },
            {
                "path": "orchestration.parallel.provider_overrides.anthropic",
                "label": "Anthropic Override (seconds)",
                "description": "Provider-specific delay for Claude API (blank = use default)",
                "type": "float",
                "min": 0.0,
                "max": 60.0,
                "default": None,
            },
            {
                "path": "orchestration.parallel.provider_overrides.openai",
                "label": "OpenAI Override (seconds)",
                "description": "Provider-specific delay for OpenAI/Codex API (blank = use default)",
                "type": "float",
                "min": 0.0,
                "max": 60.0,
                "default": None,
            },
            {
                "path": "orchestration.parallel.provider_overrides.google",
                "label": "Google Override (seconds)",
                "description": "Provider-specific delay for Gemini API (blank = use default)",
                "type": "float",
                "min": 0.0,
                "max": 60.0,
                "default": 10.0,
            },
            {
                "path": "orchestration.parallel.provider_overrides.ollama",
                "label": "Ollama Override (seconds)",
                "description": "Provider-specific delay for local Ollama models (blank = use default)",
                "type": "float",
                "min": 0.0,
                "max": 60.0,
                "default": None,
            },
        ],
    },
    {
        "id": "monitoring",
        "title": "Monitoring",
        "description": "File watchers, output monitors, production logging, and telemetry.",
        "settings": [
            {
                "path": "features.development_debug.monitoring.file_watcher",
                "label": "File Watcher",
                "description": "Monitor file system changes during execution (CLI only)",
                "type": "bool",
                "default": False,
            },
            {
                "path": "features.development_debug.monitoring.output_monitor",
                "label": "Output Monitor",
                "description": "Monitor agent output streams during execution",
                "type": "bool",
                "default": False,
            },
            {
                "path": "features.development_debug.production_logging.enabled",
                "label": "Production Logging",
                "description": "Always-on structured logging for production diagnostics",
                "type": "bool",
                "default": False,
            },
            {
                "path": "advanced.telemetry.enabled",
                "label": "Telemetry",
                "description": "Send anonymous usage statistics to improve Obra",
                "type": "bool",
                "default": True,
            },
        ],
    },
]

# Flat list of all config paths managed by this view
ALL_DEBUG_SETTINGS: list[str] = []
for _section in SECTION_DEFINITIONS:
    for _setting in _section["settings"]:
        ALL_DEBUG_SETTINGS.append(_setting["path"])


class DebugAdvancedView(SaveableViewMixin, Static):
    """Debug & Advanced configuration view.

    Shows developer/debug settings organized by category:
    - Prompt & Template Retention
    - Logging & Observability
    - Breakpoints & Guards
    - Resilience & Timeouts
    - Rate Limits & Parallelism
    - Monitoring

    Emits:
        Changed: When any setting value changes.
    """

    DEFAULT_CSS = """
    DebugAdvancedView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    DebugAdvancedView > Vertical {
        width: 100%;
        height: 100%;
    }

    DebugAdvancedView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    DebugAdvancedView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    DebugAdvancedView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    DebugAdvancedView .section-description {
        color: $text-muted;
        padding: 0 1;
        margin-bottom: 1;
    }

    DebugAdvancedView .setting-row {
        width: 100%;
        height: auto;
        padding: 0 1;
        margin-bottom: 1;
    }

    DebugAdvancedView .setting-info {
        width: 2fr;
        height: auto;
    }

    DebugAdvancedView .setting-label {
        text-style: bold;
    }

    DebugAdvancedView .setting-description {
        color: $text-muted;
    }

    DebugAdvancedView .setting-control {
        width: 1fr;
        height: auto;
        align: right middle;
    }

    DebugAdvancedView Switch {
        width: auto;
    }

    DebugAdvancedView Select {
        width: 100%;
    }

    DebugAdvancedView Input {
        width: 100%;
    }

    DebugAdvancedView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }

    DebugAdvancedView Collapsible {
        width: 100%;
    }
    """

    class Changed(Message):
        """Message emitted when a debug/advanced setting changes."""

        def __init__(self, path: str, value: Any) -> None:
            super().__init__()
            self.path = path
            self.value = value

    def __init__(
        self,
        current_values: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._current_values: dict[str, Any] = current_values.copy() if current_values else {}

        # Ensure defaults for missing paths
        self._ensure_defaults()

        # Suppress change emissions during initial mount
        self._initializing = True
        self._snapshot_state()

    def on_mount(self) -> None:
        """Allow change emissions after mount completes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued widget Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "DebugAdvancedView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def _ensure_defaults(self) -> None:
        """Fill in default values for any missing config paths."""
        for section in SECTION_DEFINITIONS:
            for setting in section["settings"]:
                path = setting["path"]
                if path not in self._current_values:
                    self._current_values[path] = setting.get("default")

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("debug_advanced")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            with ScrollableContainer(id="content-scroll"):
                for section in SECTION_DEFINITIONS:
                    with Collapsible(
                        title=section["title"],
                        collapsed=False,
                        id=f"section-{section['id']}",
                    ):
                        yield Static(section["description"], classes="section-description")
                        for setting in section["settings"]:
                            yield from self._compose_setting_row(setting)

            yield Static(
                "Changes are applied when you save. Use 's' to save.",
                classes="help-text",
            )

    def _compose_setting_row(self, setting: dict[str, Any]) -> ComposeResult:
        """Compose a single setting row."""
        path = setting["path"]
        label = setting["label"]
        description = setting["description"]
        setting_type = setting["type"]
        current_value = self._current_values.get(path, setting.get("default"))

        # Create unique widget ID from path
        widget_id = path.replace(".", "-")

        with Horizontal(classes="setting-row", id=f"setting-{widget_id}"):
            with Vertical(classes="setting-info"):
                yield Static(label, classes="setting-label")
                yield Static(description, classes="setting-description")

            with Vertical(classes="setting-control"):
                if setting_type == "bool":
                    yield Switch(
                        value=bool(current_value) if current_value is not None else False,
                        id=f"switch-{widget_id}",
                    )
                elif setting_type == "int":
                    default = setting.get("default", 0)
                    yield Input(
                        value=str(current_value) if current_value is not None else str(default),
                        id=f"input-{widget_id}",
                        type="integer",
                    )
                elif setting_type == "float":
                    default = setting.get("default")
                    yield Input(
                        value=str(current_value) if current_value is not None else (str(default) if default is not None else ""),
                        placeholder="(use default)",
                        id=f"input-{widget_id}",
                        type="number",
                    )
                elif setting_type == "select":
                    options = setting.get("options", [])
                    select_options = [(opt.capitalize(), opt) for opt in options]
                    yield Select(
                        select_options,
                        id=f"select-{widget_id}",
                        value=str(current_value) if current_value else options[0],
                        allow_blank=False,
                    )

    def _emit_change(self, path: str, value: Any) -> None:
        """Emit a change message if not initializing."""
        if self._initializing:
            return
        self.post_message(self.Changed(path, value))

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle switch toggle changes."""
        if self._initializing:
            return

        switch_id = event.switch.id
        if not switch_id or not switch_id.startswith("switch-"):
            return

        path = switch_id.replace("switch-", "").replace("-", ".")
        self._current_values[path] = event.value
        self._emit_change(path, event.value)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input field changes."""
        if self._initializing:
            return

        input_id = event.input.id
        if not input_id or not input_id.startswith("input-"):
            return

        path = input_id.replace("input-", "").replace("-", ".")

        # Determine expected type from setting definition
        setting_type = self._get_setting_type(path)

        try:
            if not event.value:
                value: int | float | None = None if setting_type == "float" else 0
            elif setting_type == "float":
                value = float(event.value)
            else:
                value = int(event.value)
        except ValueError:
            return

        self._current_values[path] = value
        self._emit_change(path, value)

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select dropdown changes."""
        if self._initializing:
            return

        select_id = event.select.id
        if not select_id or not select_id.startswith("select-"):
            return

        if event.value is Select.BLANK:
            return

        path = select_id.replace("select-", "").replace("-", ".")
        value = str(event.value)
        self._current_values[path] = value
        self._emit_change(path, value)

    def _get_setting_type(self, path: str) -> str:
        """Look up the setting type for a config path."""
        for section in SECTION_DEFINITIONS:
            for setting in section["settings"]:
                if setting["path"] == path:
                    return setting["type"]
        return "int"

    def get_current_values(self) -> dict[str, Any]:
        """Get all current setting values."""
        return self._current_values.copy()

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking."""
        return dict(self._current_values)

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._current_values = state.copy()
        for section in SECTION_DEFINITIONS:
            for setting in section["settings"]:
                path = setting["path"]
                widget_id = path.replace(".", "-")
                value = self._current_values.get(path)

                try:
                    if setting["type"] == "bool":
                        switch = self.query_one(f"#switch-{widget_id}", Switch)
                        switch.value = bool(value) if value is not None else False
                    elif setting["type"] == "int":
                        input_widget = self.query_one(f"#input-{widget_id}", Input)
                        input_widget.value = str(value) if value is not None else "0"
                    elif setting["type"] == "float":
                        input_widget = self.query_one(f"#input-{widget_id}", Input)
                        input_widget.value = str(value) if value is not None else ""
                    elif setting["type"] == "select":
                        select = self.query_one(f"#select-{widget_id}", Select)
                        select.value = str(value) if value else ""
                except Exception:
                    pass
