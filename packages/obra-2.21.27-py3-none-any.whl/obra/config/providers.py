"""LLM provider definitions and health checking for Obra.

Handles provider configuration, CLI availability checks, and installation guidance.

Example:
    from obra.config.providers import check_provider_status, validate_provider_ready

    status = check_provider_status("anthropic")
    if not status.installed:
        print(f"Install with: {status.install_hint}")
"""

import logging
import shutil
import subprocess
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from obra.ollama_runtime import normalize_ollama_runtime_issue
from obra.model_registry import get_provider_models

logger = logging.getLogger(__name__)

# =============================================================================
# LLM Provider Definitions
# =============================================================================

# Supported LLM providers
# Provider model lists are derived from obra.model_registry to avoid drift.
# Keep "default" for provider-auto behavior and retain "auto" for Gemini CLI compatibility.
LLM_PROVIDERS = {
    "anthropic": {
        "name": "Anthropic",
        "description": "Claude models",
        "cli": "claude",  # Claude Code CLI
        "models": ["default", *[m.id for m in get_provider_models("anthropic")]],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login
        "api_key_env_var": "ANTHROPIC_API_KEY",  # pragma: allowlist secret
    },
    "google": {
        "name": "Google",
        "description": "Gemini models",
        "cli": "gemini",  # Gemini CLI
        "models": ["default", "auto", *[m.id for m in get_provider_models("google")]],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (gemini auth login)
        "api_key_env_var": "GEMINI_API_KEY",  # pragma: allowlist secret
    },
    "openai": {
        "name": "OpenAI",
        "description": "Codex / GPT models",
        "cli": "codex",  # OpenAI Codex CLI
        "models": ["default", *[m.id for m in get_provider_models("openai")]],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (codex --login)
        "api_key_env_var": "OPENAI_API_KEY",  # pragma: allowlist secret
    },
    "ollama": {
        "name": "Ollama",
        "description": "Local models via Codex OSS provider",
        "cli": "codex",  # Codex CLI with --oss --local-provider ollama
        "models": ["default", *[m.id for m in get_provider_models("ollama")]],
        "default_model": "default",
        "oauth_env_var": None,  # Local provider mode, no OAuth required
        "api_key_env_var": None,  # Local provider mode, no API key required
    },
}

# Auth methods
LLM_AUTH_METHODS = {
    "oauth": {
        "name": "OAuth (Flat Rate)",
        "description": "Subscription-based, fixed monthly cost",
        "recommended_model": "default",
        "note": "Recommended - inherits provider's optimal model",
    },
    "api_key": {
        "name": "API Key (Token Billing)",
        "description": "Pay per token usage",
        "recommended_model": None,  # User should choose
        "note": "Warning: API Key method is currently untested",
    },
}

# Default provider settings
DEFAULT_PROVIDER = "anthropic"
DEFAULT_AUTH_METHOD = "oauth"
DEFAULT_MODEL = "default"

# =============================================================================
# Provider Health Check
# =============================================================================


@dataclass
class ProviderStatus:
    """Status of an LLM provider's CLI availability.

    Attributes:
        provider: Provider name (anthropic, openai, google)
        installed: Whether the CLI is installed and accessible
        cli_command: The CLI command name
        cli_path: Full path to CLI executable (if installed)
        install_hint: Installation instructions
        docs_url: Documentation URL
    """

    provider: str
    installed: bool
    cli_command: str
    cli_path: str | None = None
    install_hint: str = ""
    docs_url: str = ""


# Provider CLI information for health checking
PROVIDER_CLI_INFO: dict[str, dict[str, str]] = {
    "anthropic": {
        "cli": "claude",
        "install_hint": "npm install -g @anthropic-ai/claude-code",
        "docs_url": "https://docs.anthropic.com/en/docs/claude-code",
        "auth_hint": "claude login",
        "version_arg": "--version",
    },
    "openai": {
        "cli": "codex",
        "install_hint": "npm install -g @openai/codex",
        "docs_url": "https://platform.openai.com/docs/codex-cli",
        "auth_hint": "codex --login",
        "version_arg": "--version",
    },
    "google": {
        "cli": "gemini",
        "install_hint": "npm install -g @google/gemini-cli",
        "docs_url": "https://ai.google.dev/gemini-api/docs/gemini-cli",
        "auth_hint": "gemini auth login",
        "version_arg": "--version",
    },
    "ollama": {
        "cli": "codex",
        "install_hint": (
            "Install Codex CLI: npm install -g @openai/codex; "
            "install/start Ollama and pull your model (ollama serve, ollama pull <model>)"
        ),
        "docs_url": "https://platform.openai.com/docs/codex-cli",
        "auth_hint": "",
        "version_arg": "--version",
    },
}

# Timeout for functional health check subprocess (seconds)
_CLI_HEALTH_CHECK_TIMEOUT_S = 10


def check_provider_status(provider: str) -> ProviderStatus:
    """Check if an LLM provider's CLI is installed and accessible.

    Uses shutil.which() to locate the CLI executable in PATH.

    Args:
        provider: Provider name (anthropic, openai, google)

    Returns:
        ProviderStatus with installation details

    Examples:
        >>> status = check_provider_status("anthropic")
        >>> if status.installed:
        ...     print(f"Claude CLI at: {status.cli_path}")
        ... else:
        ...     print(f"Install with: {status.install_hint}")
    """
    cli_info = PROVIDER_CLI_INFO.get(provider, {})
    cli_command_raw = cli_info.get("cli", LLM_PROVIDERS.get(provider, {}).get("cli", ""))
    cli_command = str(cli_command_raw)

    if not cli_command:
        return ProviderStatus(
            provider=provider,
            installed=False,
            cli_command="unknown",
            install_hint=f"Unknown provider: {provider}",
        )

    # Check if CLI is in PATH
    cli_path = shutil.which(cli_command)

    return ProviderStatus(
        provider=provider,
        installed=cli_path is not None,
        cli_command=cli_command,
        cli_path=cli_path,
        install_hint=cli_info.get("install_hint", ""),
        docs_url=cli_info.get("docs_url", ""),
    )


def _run_cli_health_check(cli_path: str, version_arg: str) -> tuple[bool, str]:
    """Run a functional health check on a CLI binary.

    Executes ``<cli> <version_arg>`` and verifies it exits cleanly (rc 0).

    Args:
        cli_path: Full path to the CLI executable.
        version_arg: Argument to invoke a lightweight probe (e.g. ``--version``).

    Returns:
        (success, detail) – *detail* contains version output on success
        or the error description on failure.
    """
    try:
        result = subprocess.run(
            [cli_path, version_arg],
            capture_output=True,
            text=True,
            timeout=_CLI_HEALTH_CHECK_TIMEOUT_S,
        )
        if result.returncode == 0:
            version_output = (result.stdout or result.stderr or "").strip()
            return True, version_output
        # Non-zero exit — CLI is broken
        error_detail = (result.stderr or result.stdout or "").strip()
        return False, f"exited with code {result.returncode}: {error_detail}"
    except subprocess.TimeoutExpired:
        return False, f"timed out after {_CLI_HEALTH_CHECK_TIMEOUT_S}s"
    except OSError as exc:
        return False, str(exc)


def validate_provider_ready(provider: str) -> None:
    """Validate that a provider's CLI is installed and functional.

    Performs two checks:
    1. Binary exists on PATH (shutil.which)
    2. Functional probe (``<cli> --version``) exits cleanly

    Raises ConfigurationError with installation hints on failure.

    Args:
        provider: Provider name to validate (anthropic, openai, google)

    Raises:
        ConfigurationError: If provider CLI is not installed or non-functional

    Example:
        >>> try:
        ...     validate_provider_ready("openai")
        ... except ConfigurationError as e:
        ...     print(f"Setup required: {e}")
    """
    from obra.exceptions import ConfigurationError

    status = check_provider_status(provider)

    if not status.installed:
        provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
        cli_info = PROVIDER_CLI_INFO.get(provider, {})

        error_msg = f"{provider_name} CLI ({status.cli_command}) not found in PATH."
        details = []

        if status.install_hint:
            details.append(f"Install with: {status.install_hint}")

        auth_hint = cli_info.get("auth_hint")
        if auth_hint:
            details.append(f"Then authenticate: {auth_hint}")

        if status.docs_url:
            details.append(f"See: {status.docs_url}")

        if details:
            error_msg = f"{error_msg}\n\n" + "\n".join(details)

        if provider == "ollama":
            issue = normalize_ollama_runtime_issue(
                error_msg,
                source="codex_preflight",
            )
            logger.warning(
                "ollama_runtime_failure source=%s class=%s detail=%s",
                issue.source,
                issue.error_class.value,
                issue.detail,
            )
            raise ConfigurationError(issue.actionable_message)

        raise ConfigurationError(error_msg)

    # Functional health check — verify the CLI actually runs
    cli_info = PROVIDER_CLI_INFO.get(provider, {})
    version_arg = cli_info.get("version_arg", "--version")
    ok, detail = _run_cli_health_check(status.cli_path, version_arg)  # type: ignore[arg-type]

    if ok:
        logger.debug(
            "Provider %s CLI health check passed: %s", provider, detail
        )
    else:
        provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
        error_msg = (
            f"{provider_name} CLI ({status.cli_command}) found at "
            f"{status.cli_path} but failed health check: {detail}"
        )
        details = []
        if status.install_hint:
            details.append(f"Try reinstalling: {status.install_hint}")
        if status.docs_url:
            details.append(f"See: {status.docs_url}")
        if details:
            error_msg = f"{error_msg}\n\n" + "\n".join(details)

        if provider == "ollama":
            issue = normalize_ollama_runtime_issue(
                error_msg,
                source="codex_preflight",
            )
            logger.warning(
                "ollama_runtime_failure source=%s class=%s detail=%s",
                issue.source,
                issue.error_class.value,
                issue.detail,
            )
            raise ConfigurationError(issue.actionable_message)

        raise ConfigurationError(error_msg)

    if provider == "ollama":
        try:
            _validate_ollama_endpoint_ready()
        except ConfigurationError as exc:
            issue = normalize_ollama_runtime_issue(
                str(exc),
                source="codex_preflight",
            )
            logger.warning(
                "ollama_runtime_failure source=%s class=%s detail=%s",
                issue.source,
                issue.error_class.value,
                issue.detail,
            )
            raise ConfigurationError(issue.actionable_message) from exc


def _validate_ollama_endpoint_ready(timeout_s: int = _CLI_HEALTH_CHECK_TIMEOUT_S) -> None:
    """Validate that the configured Ollama endpoint is reachable."""
    from obra.exceptions import ConfigurationError
    from obra.llm.ollama_endpoint import resolve_ollama_endpoint

    endpoint = resolve_ollama_endpoint()
    tags_url = f"{endpoint.rstrip('/')}/api/tags"
    request = urllib.request.Request(tags_url, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout_s) as response:
            status = getattr(response, "status", None)
            if status != 200:
                issue = normalize_ollama_runtime_issue(
                    (
                        f"Ollama endpoint check failed at {tags_url}: HTTP {status}. "
                        "Ensure Ollama is running and reachable."
                    ),
                    source="codex_preflight",
                    endpoint=tags_url,
                )
                logger.warning(
                    "ollama_runtime_failure source=%s class=%s detail=%s",
                    issue.source,
                    issue.error_class.value,
                    issue.detail,
                )
                raise ConfigurationError(issue.actionable_message)
    except urllib.error.URLError as exc:
        issue = normalize_ollama_runtime_issue(
            (
                f"Ollama endpoint is not reachable at {tags_url}. "
                "Start Ollama and verify llm.ollama.endpoint/OLLAMA_HOST configuration. "
                f"(detail: {exc})"
            ),
            source="codex_preflight",
            endpoint=tags_url,
        )
        logger.warning(
            "ollama_runtime_failure source=%s class=%s detail=%s",
            issue.source,
            issue.error_class.value,
            issue.detail,
        )
        raise ConfigurationError(issue.actionable_message) from exc


def _is_model_not_found_error(message: str) -> bool:
    """Detect provider/model lookup failures from CLI/API error text."""
    text = message.lower()
    return (
        "model_not_found" in text
        or ("requested model" in text and "does not exist" in text)
        or "unknown model" in text
        or "try pulling it first" in text
        or ("model" in text and "not found" in text)
    )


def _coerce_string_list(value: object) -> list[str]:
    """Coerce config values to a de-duplicated non-empty string list."""
    if not isinstance(value, list):
        return []
    normalized: list[str] = []
    seen: set[str] = set()
    for item in value:
        if not isinstance(item, str):
            continue
        entry = item.strip()
        if not entry or entry in seen:
            continue
        seen.add(entry)
        normalized.append(entry)
    return normalized


def validate_provider_model_ready(
    provider: str,
    model: str,
    *,
    auth_method: str = "oauth",
    cwd: Path | None = None,
    timeout_s: int = 30,
) -> None:
    """Validate that a provider+model pair is invokable end-to-end.

    This performs a lightweight live probe via provider CLI/API, catching model
    availability drift that static config/registry checks cannot detect.
    """
    from obra.exceptions import ConfigurationError
    from obra.llm.cli_runner import invoke_llm_via_cli

    validate_provider_ready(provider)

    model_text = str(model or "").strip()
    if not model_text or model_text in {"default", "auto"}:
        return

    probe_cwd = cwd or Path.cwd()
    skip_git_check = False
    bypass_sandbox = False
    approval_mode: str | None = None
    codex_enable_features: list[str] | None = None
    codex_disable_features: list[str] | None = None

    if provider in {"openai", "ollama"}:
        from obra.config.llm import resolve_llm_config

        # Preflight must use the same codex/git runtime flags as normal execution.
        resolved_runtime = resolve_llm_config(
            "implementation",
            override_provider=provider,
        )
        resolved_git = resolved_runtime.get("git", {})
        resolved_codex = resolved_runtime.get("codex", {})

        if isinstance(resolved_git, dict):
            skip_git_check = bool(resolved_git.get("skip_check"))
        if isinstance(resolved_codex, dict):
            bypass_sandbox = bool(resolved_codex.get("bypass_sandbox"))
            raw_approval_mode = resolved_codex.get("approval_mode")
            if isinstance(raw_approval_mode, str) and raw_approval_mode.strip():
                approval_mode = raw_approval_mode.strip()
            codex_enable_features = _coerce_string_list(
                resolved_codex.get("enable_features")
            )
            codex_disable_features = _coerce_string_list(
                resolved_codex.get("disable_features")
            )

    try:
        if provider == "ollama":
            _probe_ollama_model_with_codex(
                model=model_text,
                cwd=probe_cwd,
                timeout_s=timeout_s,
                skip_git_check=skip_git_check,
                approval_mode=approval_mode,
                codex_enable_features=codex_enable_features,
                codex_disable_features=codex_disable_features,
            )
            return
        invoke_llm_via_cli(
            prompt="Reply with exactly: OK",
            cwd=probe_cwd,
            provider=provider,
            model=model_text,
            reasoning_level="low",
            auth_method=auth_method,
            timeout_s=timeout_s,
            retry_enabled=False,
            mode="text",
            response_format="text",
            skip_git_check=skip_git_check,
            bypass_sandbox=bypass_sandbox,
            approval_mode=approval_mode,
            codex_enable_features=codex_enable_features,
            codex_disable_features=codex_disable_features,
        )
    except Exception as exc:
        detail = str(exc)
        if provider == "ollama":
            issue = normalize_ollama_runtime_issue(
                detail,
                source="codex_preflight",
                model=model_text,
            )
            logger.warning(
                "ollama_runtime_failure source=%s class=%s model=%s detail=%s",
                issue.source,
                issue.error_class.value,
                model_text,
                issue.detail,
            )
            raise ConfigurationError(issue.actionable_message) from exc
        if _is_model_not_found_error(detail):
            raise ConfigurationError(
                f"Model '{model_text}' is not available for provider '{provider}'. "
                "Update model config to an available model and retry. "
                f"(detail: {detail})"
            ) from exc
        raise ConfigurationError(
            f"Model preflight failed for provider '{provider}', model '{model_text}'. "
            f"(detail: {detail})"
        ) from exc


def _probe_ollama_model_with_codex(
    *,
    model: str,
    cwd: Path,
    timeout_s: int,
    skip_git_check: bool = False,
    approval_mode: str | None = None,
    codex_enable_features: list[str] | None = None,
    codex_disable_features: list[str] | None = None,
) -> None:
    """Probe an Ollama model through Codex local-provider mode."""
    from obra.exceptions import ConfigurationError

    status = check_provider_status("ollama")
    cli = status.cli_path or status.cli_command
    if not cli:
        issue = normalize_ollama_runtime_issue(
            "Ollama Codex runtime is unavailable: codex CLI not found.",
            source="codex_preflight",
            model=model,
        )
        raise ConfigurationError(issue.actionable_message)

    with tempfile.NamedTemporaryFile(mode="w+", delete=False, encoding="utf-8") as tmp:
        output_path = tmp.name

    cmd = [
        cli,
        "exec",
        "-C",
        str(cwd),
        "--oss",
        "--local-provider",
        "ollama",
        "--sandbox",
        "read-only",
    ]
    if approval_mode:
        cmd.extend(["--config", f"defaults.approval_mode={approval_mode}"])
    if skip_git_check:
        cmd.append("--skip-git-repo-check")
    for feature_name in codex_enable_features or []:
        cmd.extend(["--enable", feature_name])
    for feature_name in codex_disable_features or []:
        cmd.extend(["--disable", feature_name])
    cmd.extend(
        [
            "--model",
            model,
            "--output-last-message",
            output_path,
            "Reply with exactly: OK",
        ]
    )
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_s,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip() or "Unknown error"
            issue = normalize_ollama_runtime_issue(
                (
                    f"Model preflight failed for provider 'ollama', model '{model}'. "
                    f"(detail: {detail})"
                ),
                source="codex_preflight",
                model=model,
            )
            raise ConfigurationError(issue.actionable_message)
    finally:
        try:
            Path(output_path).unlink(missing_ok=True)
        except OSError:
            logger.debug("Failed cleaning ollama probe output file: %s", output_path)


# Public exports
__all__ = [
    "DEFAULT_AUTH_METHOD",
    "DEFAULT_MODEL",
    "DEFAULT_PROVIDER",
    "LLM_AUTH_METHODS",
    # Provider definitions
    "LLM_PROVIDERS",
    "PROVIDER_CLI_INFO",
    # Provider health check
    "ProviderStatus",
    "check_provider_status",
    "validate_provider_model_ready",
    "validate_provider_ready",
]
