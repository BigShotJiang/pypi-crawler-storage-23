"""Derivation engine for breaking down objectives into implementation plans.

This module provides the DerivationEngine class that uses LLM invocation
to transform high-level objectives into structured implementation plans.

The engine:
    1. Gathers project context (files, structure, README)
    2. Builds a derivation prompt with context and constraints
    3. Invokes LLM with optional extended thinking
    4. Parses structured output into plan items

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/hybrid/handlers/derive.py (handler layer)
    - obra/llm/invoker.py (LLM invocation)
    - src/derivation/engine.py (CLI implementation reference)
"""

import json
import logging
import os
import re
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_derivation_epic_item_rederive_threshold,
    get_derivation_epic_output_token_limit,
    get_derivation_preview_config,
    get_derivation_serialize_max_concurrent,
    get_derivation_story_range,
    get_derivation_strict_story_range,
    get_derivation_strict_task_range,
    get_derivation_task_range,
    get_derivation_serialize_worker_delay_s,
    get_derivation_step3_tier,
)

# ISSUE-DERIVE-001: Removed get_derivation_step_timeout import.
# Post-hoc timeout checks cannot detect actual stalls (only duration after completion).
# Real stall detection is handled by MonitoringThread during subprocess execution.
from obra.core.interrupts import interrupt_requested
from obra.exceptions import DerivationStallError, ObraError
from obra.hybrid.json_utils import parse_planning_json_response
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.prompts.derive.derivation import (
    build_derivation_prompt,
    build_four_phase_guidance,
    build_refinement_prompt,
    build_step1_epics_only_prompt,
    build_step1_epics_template,
    build_step2_per_epic_prompt,
    build_step2_per_epic_template,
    build_step2_repair_prompt,
    build_step2_repair_template,
    build_step2_prompt,
    build_step3_per_epic_prompt,
    build_step3_per_epic_prompt_strict,
    build_step3_prompt,
    get_pattern_guidance,
)

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker

logger = logging.getLogger(__name__)

# Work type detection patterns (aligned with CLI src/derivation/engine.py)
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "feature_implementation": [
        "implement",
        "create",
        "build",
        "add feature",
        "new feature",
    ],
    "bug_fix": ["fix", "bug", "issue", "error", "broken", "failing"],
    "refactoring": ["refactor", "restructure", "reorganize", "clean up", "simplify"],
    "documentation": ["docs", "doc", "documentation", "readme", "guide"],
    "integration": ["integrate", "connect", "api", "external", "third-party"],
    "database": ["database", "schema", "migration", "table", "column", "index"],
}

ITEM_COUNT_WARNING_THRESHOLDS = (25, 50, 100, 200, 500, 1000)

# DEPRECATED: Use get_derivation_preview_config() from obra.config.loaders
# These constants are kept for backwards compatibility only
_preview_config = get_derivation_preview_config()
README_PREVIEW_LIMIT = _preview_config["readme_limit"]
RAW_RESPONSE_PREVIEW_LIMIT = _preview_config["raw_response_limit"]
RAW_RESPONSE_WARN_LIMIT = _preview_config["raw_response_warn_limit"]

# DEPRECATED: Use config values from obra.config.loaders
# Kept for backwards compatibility only
EXPLORATION_LOOKBACK_MINUTES = 180  # Now in derivation.exploration_lookback_minutes

COMPOUND_VIOLATION_MARKER = "Title contains compound action word"

# DEPRECATED: Use get_derivation_epic_item_rederive_threshold() from obra.config.loaders
EPIC_ITEM_REDERIVE_THRESHOLD = get_derivation_epic_item_rederive_threshold()

EPIC_OUTPUT_TOKEN_LIMIT = get_derivation_epic_output_token_limit()

# S7.T5: Max depth limit for hierarchical derivation
# When a derived item would exceed this depth, it is created as a sibling
# of its parent instead of as a child. This prevents unbounded nesting
# while preserving context inheritance.
MAX_DERIVATION_DEPTH = 3

# SIZING_GUIDANCE is now imported from obra.prompts.derive.derivation

# Work phases (4-phase workflow)
VALID_PHASES = ["explore", "plan", "implement", "commit"]

# Work types that benefit from exploration phase
WORK_TYPES_NEEDING_EXPLORATION = [
    "feature_implementation",
    "refactoring",
    "integration",
]

# Phase-to-agent mapping (used when LLM doesn't specify agent)
# Aligned with Claude Code 4-phase workflow: Explore -> Plan -> Implement -> Commit
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",  # Use Explore subagent for codebase research
    "plan": None,  # Planning is orchestrator's job
    "implement": None,  # Normal Claude Code execution
    "commit": None,  # Finalization (test, commit, docs)
}


def detect_recent_exploration(
    working_dir: Path,
    *,
    lookback_minutes: int = EXPLORATION_LOOKBACK_MINUTES,
    log_paths: Sequence[Path] | None = None,
) -> dict[str, Any]:
    """Detect whether exploration or plan mode activity occurred recently.

    Checks a set of JSON/JSONL log files for entries indicating either an
    explore agent run or Plan Mode activity inside a configurable lookback
    window. Returns a small report that can be used for nudging the user.
    """
    cutoff = datetime.now(UTC) - timedelta(minutes=lookback_minutes)
    candidates = (
        list(log_paths)
        if log_paths is not None
        else [
            working_dir / ".obra" / "activity.log",
            working_dir / ".obra" / "session_history.jsonl",
            Path.home() / ".obra" / "memory" / "activity.log",
            Path.home() / ".obra" / "last-session.json",
        ]
    )

    signals: list[dict[str, str]] = []
    for path in candidates:
        signals.extend(_collect_exploration_signals(path, cutoff))

    signals.sort(key=lambda signal: signal["timestamp"], reverse=True)
    return {
        "recent_exploration": bool(signals),
        "signals": signals,
    }


def _collect_exploration_signals(path: Path, cutoff: datetime) -> list[dict[str, str]]:
    """Parse a log file and collect exploration signals within cutoff."""
    if not path.exists() or not path.is_file():
        return []

    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return []

    entries: list[Any] = []
    try:
        stripped = content.strip()
        if not stripped:
            return []
        loaded = json.loads(stripped)
        if isinstance(loaded, list):
            entries = loaded
        elif isinstance(loaded, dict):
            entries = [loaded]
    except json.JSONDecodeError:
        for line in content.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            entries.append(entry)

    signals: list[dict[str, str]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if not _is_exploration_entry(entry):
            continue

        ts = _extract_timestamp(entry) or datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        if ts < cutoff:
            continue

        signals.append(
            {
                "source": str(path),
                "timestamp": ts.isoformat(),
                "reason": _extract_reason(entry),
            }
        )
    return signals


def _is_exploration_entry(entry: dict[str, Any]) -> bool:
    """Determine if an entry represents exploration or plan mode activity."""
    action = str(entry.get("action", "")).lower()
    mode = str(entry.get("mode", "")).lower()
    agent = str(entry.get("agent", "")).lower()
    tags = entry.get("tags", [])
    tag_values = tags if isinstance(tags, list) else ([tags] if tags else [])

    tagged_exploration = any(
        str(tag).lower() in {"explore", "exploration", "plan_mode"} for tag in tag_values
    )

    return bool(
        tagged_exploration
        or action in {"explore", "exploration", "plan_mode"}
        or agent == "explore"
        or entry.get("plan_mode") is True
        or "plan_mode" in mode
    )


def _extract_timestamp(entry: dict[str, Any]) -> datetime | None:
    """Extract a timestamp from common log fields."""
    candidates = [
        entry.get("timestamp"),
        entry.get("created_at"),
        entry.get("ts"),
        entry.get("time"),
    ]
    for value in candidates:
        if value is None:
            continue
        if isinstance(value, (int, float)):
            try:
                return datetime.fromtimestamp(float(value), tz=UTC)
            except (OSError, ValueError):
                continue
        if isinstance(value, str):
            parsed = _parse_iso_timestamp(value)
            if parsed:
                return parsed
    return None


def _parse_iso_timestamp(value: str) -> datetime | None:
    """Parse ISO timestamp strings, including those ending with Z."""
    try:
        normalized = value.replace("Z", "+00:00") if value.endswith("Z") else value
        parsed = datetime.fromisoformat(normalized)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except ValueError:
        return None


def _extract_reason(entry: dict[str, Any]) -> str:
    """Extract a human-friendly reason for the detected signal."""
    for key in ["action", "mode", "agent"]:
        value = entry.get(key)
        if value:
            return str(value)
    return "exploration"


@dataclass
class DerivationResult:
    """Result from plan derivation.

    Attributes:
        plan_items: List of derived plan items
        raw_response: Raw LLM response for debugging
        work_type: Detected work type
        duration_seconds: Time taken for derivation
        first_pass_duration_seconds: Duration of first validation passes (hierarchical)
        total_pass_duration_seconds: Total duration across validation passes (hierarchical)
        pass_count: Total validation passes executed (hierarchical)
        leaf_total: Number of leaf items validated (hierarchical)
        leaf_compliant: Number of compliant leaf items (hierarchical)
        tokens_used: Estimated tokens used
        success: Whether derivation succeeded
        error_message: Error message if failed
    """

    plan_items: list[dict[str, Any]] = field(default_factory=list)
    raw_response: str = ""
    work_type: str = "general"
    duration_seconds: float = 0.0
    first_pass_duration_seconds: float | None = None
    total_pass_duration_seconds: float | None = None
    pass_count: int | None = None
    leaf_total: int | None = None
    leaf_compliant: int | None = None
    tokens_used: int = 0
    success: bool = True
    error_message: str = ""

    @property
    def item_count(self) -> int:
        """Number of derived plan items."""
        return len(self.plan_items)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "plan_items": self.plan_items,
            "raw_response": self.raw_response,
            "work_type": self.work_type,
            "duration_seconds": self.duration_seconds,
            "first_pass_duration_seconds": self.first_pass_duration_seconds,
            "total_pass_duration_seconds": self.total_pass_duration_seconds,
            "pass_count": self.pass_count,
            "leaf_total": self.leaf_total,
            "leaf_compliant": self.leaf_compliant,
            "tokens_used": self.tokens_used,
            "success": self.success,
            "error_message": self.error_message,
            "item_count": self.item_count,
        }


class DerivationEngine:
    """Engine for deriving implementation plans from objectives.

    Uses LLM invocation to break down high-level objectives into
    structured plan items (tasks/stories) with proper sequencing
    and dependencies.

    Example:
        >>> from obra.llm.invoker import LLMInvoker
        >>> invoker = LLMInvoker()
        >>> engine = DerivationEngine(
        ...     working_dir=Path("/path/to/project"),
        ...     llm_invoker=invoker,
        ... )
        >>> result = engine.derive("Add user authentication")
        >>> for item in result.plan_items:
        ...     print(f"{item['id']}: {item['title']}")

    Thread-safety:
        Thread-safe through LLMInvoker's thread safety guarantees.

    Related:
        - obra/hybrid/handlers/derive.py (handler layer)
        - obra/llm/invoker.py (LLM invocation)
    """

    def __init__(
        self,
        working_dir: Path,
        llm_invoker: Optional["LLMInvoker"] = None,
        thinking_enabled: bool = True,
        reasoning_level: str = "high",
        max_items: int = 20,
    ) -> None:
        """Initialize DerivationEngine.

        Args:
            working_dir: Working directory for file access
            llm_invoker: LLMInvoker instance for LLM calls
            thinking_enabled: Whether to use extended thinking
            reasoning_level: Reasoning level (off, minimal, standard, high, maximum)
            max_items: Advisory target for plan item count (prompt guidance only; no truncation)
        """
        self._working_dir = working_dir
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._reasoning_level = reasoning_level
        self._max_items = max_items
        self._strategic_prompt: str | None = None
        self._intent_markdown: str | None = None

        logger.debug(
            f"DerivationEngine initialized: working_dir={working_dir}, "
            f"thinking_enabled={thinking_enabled}, reasoning_level={reasoning_level}"
        )

    def derive(
        self,
        objective: str,
        project_context: dict[str, Any] | None = None,
        constraints: dict[str, Any] | None = None,
        provider: str = "anthropic",
        strategic_prompt: str | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> DerivationResult:
        """Derive implementation plan from objective using unified 3-step pipeline.

        The unified pipeline breaks derivation into three sequential steps:
        1. Structure: Derive high-level Epics and Stories (prose)
        2. Tasks: Add task-level detail to each story (prose)
        3. Serialize: Convert complete prose plan to structured JSON

        Args:
            objective: Task objective to plan for
            project_context: Optional project context (languages, frameworks)
            constraints: Optional derivation constraints
            provider: LLM provider to use
            strategic_prompt: Optional strategic guidance prompt
            intent_markdown: Optional intent markdown for context
            exploration_context: Optional exploration context markdown
            progress_callback: Optional callback for progress events

        Returns:
            DerivationResult with plan items and metadata

        Example:
            >>> result = engine.derive(
            ...     "Add user authentication",
            ...     project_context={"languages": ["python"]},
            ...     constraints={"max_items": 10},
            ... )
        """
        start_time = time.time()
        self._strategic_prompt = strategic_prompt
        self._intent_markdown = intent_markdown
        self._exploration_context = exploration_context
        emit_progress = progress_callback

        def _emit(action: str, payload: dict[str, Any]) -> None:
            if not emit_progress:
                return
            try:
                emit_progress(action, payload)
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Progress callback failed: %s", exc)

        try:
            # Detect work type
            work_type = self._detect_work_type(objective)

            # Gather local context
            context = self._gather_context(project_context or {})

            # Format context for prompt
            context_str = self._build_context_section(context)
            constraints_str = self._render_constraints(constraints)

            # Use unified 3-step derivation pipeline
            logger.info("Using unified 3-step derivation pipeline")
            plan_items, tokens_used = self._derive_multi_step_plan(
                objective=objective,
                project_context=context_str,
                constraints=constraints_str,
                provider=provider,
                progress_callback=_emit,
                validation_intensity=validation_intensity,
            )

            raw_response = json.dumps({"plan_items": plan_items})
            duration = time.time() - start_time

            logger.info(
                f"Derivation completed: {len(plan_items)} items, "
                f"{duration:.2f}s, work_type={work_type}"
            )

            return DerivationResult(
                plan_items=plan_items,
                raw_response=raw_response,
                work_type=work_type,
                duration_seconds=duration,
                tokens_used=tokens_used,
                success=True,
            )

        except Exception as exc:
            duration = time.time() - start_time
            logger.exception("Derivation failed")

            # Structured logging for pipeline failure (S5.T1)
            error_extra: dict[str, Any] = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            }

            # Extract step info if DerivationStallError
            if isinstance(exc, DerivationStallError):
                error_extra["failed_at_step"] = exc.step
                error_extra["step_name"] = exc.step_name
            else:
                # Generic failure - step unknown
                error_extra["failed_at_step"] = 0
                error_extra["step_name"] = "unknown"

            logger.exception(
                "derivation_pipeline_failed",
                extra=error_extra,
            )

            return DerivationResult(
                success=False,
                error_message=str(exc),
                duration_seconds=duration,
            )

    def _detect_work_type(self, objective: str) -> str:
        """Detect work type from objective text.

        Args:
            objective: Task objective

        Returns:
            Work type string
        """
        text = objective.lower()

        for work_type, keywords in WORK_TYPE_KEYWORDS.items():
            if any(keyword in text for keyword in keywords):
                logger.debug("Detected work type: %s", work_type)
                return work_type

        return "general"

    @staticmethod
    def _render_constraints(constraints: dict[str, Any] | str | None) -> str:
        if constraints is None:
            return ""
        if isinstance(constraints, dict):
            constraints_markdown = constraints.get("constraints_markdown")
            if isinstance(constraints_markdown, str) and constraints_markdown.strip():
                return constraints_markdown
            return json.dumps(constraints)
        if isinstance(constraints, str):
            return constraints
        return json.dumps(constraints)

    @staticmethod
    def _validate_step1_epics(content: dict, min_epics: int) -> tuple[bool, str | None]:
        """Validate Step 1 epic identification output.

        Checks that the epics array contains valid epic objects with all required
        fields populated (no placeholder markers).

        Args:
            content: Dictionary containing epics array
            min_epics: Minimum number of epics required

        Returns:
            Tuple of (is_valid, error_message). error_message is None on success.
        """
        # Check epics key exists and is list
        if "epics" not in content:
            return (False, "Missing 'epics' field")

        if not isinstance(content["epics"], list):
            return (False, "'epics' field must be an array")

        epics = content["epics"]

        # Check minimum count
        if len(epics) < min_epics:
            return (
                False,
                f"Need at least {min_epics} epics, got {len(epics)}"
            )

        # Check each epic has required fields
        required_fields = {"id", "title", "description", "acceptance_criteria"}
        for i, epic in enumerate(epics):
            if not isinstance(epic, dict):
                return (False, f"Epic {i} is not an object")

            if not required_fields.issubset(epic.keys()):
                missing = required_fields - epic.keys()
                return (False, f"Epic {i} missing fields: {missing}")

            # Check for unfilled placeholders
            for field in ["title", "description"]:
                value = epic.get(field, "")
                if isinstance(value, str) and "<FILL:" in value:
                    return (
                        False,
                        f"Epic {i} has unfilled placeholder in '{field}' field"
                    )

            # Check acceptance_criteria is list and has no placeholders
            criteria = epic.get("acceptance_criteria")
            if not isinstance(criteria, list):
                return (False, f"Epic {i} acceptance_criteria must be an array")

            for j, criterion in enumerate(criteria):
                if isinstance(criterion, str) and "<FILL:" in criterion:
                    return (
                        False,
                        f"Epic {i} has unfilled placeholder in criterion {j}"
                    )

        return (True, None)

    def _gather_context(self, project_context: dict[str, Any]) -> dict[str, Any]:
        """Gather local context for derivation.

        Args:
            project_context: Base project context

        Returns:
            Enhanced context dictionary
        """
        context = dict(project_context)

        # Add file structure summary
        try:
            structure = self._summarize_structure()
            context["file_structure"] = structure
        except Exception as e:
            logger.warning(f"Failed to gather file structure: {e}")

        # Add README if exists
        readme_path = self._working_dir / "README.md"
        if readme_path.exists():
            try:
                content = readme_path.read_text(encoding="utf-8")
                # Truncate to first README_PREVIEW_LIMIT chars
                context["readme"] = content[:README_PREVIEW_LIMIT] + (
                    "..." if len(content) > README_PREVIEW_LIMIT else ""
                )
            except Exception:
                pass

        return context

    def _summarize_structure(self) -> list[str]:
        """Summarize project file structure.

        Returns:
            List of important file paths
        """
        important_files: list[str] = []
        important_patterns = [
            "*.py",
            "*.js",
            "*.ts",
            "*.tsx",
            "*.jsx",
            "package.json",
            "pyproject.toml",
            "requirements.txt",
            "Cargo.toml",
            "go.mod",
            "README.md",
            "Makefile",
            "Dockerfile",
        ]

        max_files = 50
        skip_dirs = {
            ".git",
            "node_modules",
            "__pycache__",
            ".venv",
            "venv",
            "dist",
            "build",
        }

        for pattern in important_patterns:
            for path in self._working_dir.rglob(pattern):
                if any(skip_dir in path.parts for skip_dir in skip_dirs):
                    continue

                try:
                    rel_path = path.relative_to(self._working_dir)
                    important_files.append(str(rel_path))
                except ValueError:
                    continue

                if len(important_files) >= max_files:
                    break

            if len(important_files) >= max_files:
                break

        return sorted(important_files)[:max_files]

    def _build_prompt(
        self,
        objective: str,
        context: dict[str, Any],
        constraints: dict[str, Any],
        work_type: str,
    ) -> str:
        """Build derivation prompt.

        Args:
            objective: Task objective
            context: Project context
            constraints: Derivation constraints
            work_type: Detected work type

        Returns:
            Prompt string for LLM
        """
        # Build context section
        context_parts = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        context_section = (
            "\n".join(context_parts) if context_parts else "No project context available."
        )

        # Build constraints section
        max_items = constraints.get("max_items", self._max_items)
        constraint_lines = []
        if max_items:
            constraint_lines.append(
                f"- Advisory: Aim for ~{max_items} plan items if they stay small and testable; no hard cap—split oversized work instead of dropping items."
            )

        if constraints.get("scope_boundaries"):
            constraint_lines.append(
                f"- Scope boundaries: {', '.join(constraints['scope_boundaries'])}"
            )

        constraints_section = ("\n".join(constraint_lines) + "\n") if constraint_lines else ""

        # Get pattern guidance
        pattern_guidance = self._get_pattern_guidance(work_type)

        # 4-phase guidance for complex work types
        four_phase_guidance = ""
        if work_type in WORK_TYPES_NEEDING_EXPLORATION:
            four_phase_guidance = build_four_phase_guidance()

        # Delegate to imported prompt builder
        return build_derivation_prompt(
            objective=objective,
            context_section=context_section,
            work_type=work_type,
            pattern_guidance=pattern_guidance,
            constraints_section=constraints_section,
            four_phase_guidance=four_phase_guidance,
        )

    def _build_context_section(self, context: dict[str, Any]) -> str:
        """Format project context for prompt injection."""
        context_parts: list[str] = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        return "\n".join(context_parts) if context_parts else "No project context available."

    def _resolve_hierarchy_config(self, constraints: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve hierarchy configuration from config and constraints."""
        hierarchy: dict[str, Any] = {}
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            hierarchy = config.get("derivation", {}).get("hierarchy", {}) or {}
        except Exception as exc:
            logger.warning("Failed to load hierarchy config; defaulting to disabled: %s", exc)
            hierarchy = {}

        if constraints and isinstance(constraints.get("hierarchy"), dict):
            override = constraints["hierarchy"]
            hierarchy = {**hierarchy, **override}

        if hierarchy.get("enabled"):
            required_keys = ["max_depth", "epic", "story", "task", "subtask"]
            missing = [key for key in required_keys if key not in hierarchy]
            if missing:
                msg = f"Hierarchy config missing required keys: {', '.join(missing)}"
                logger.error(msg)
                raise ValueError(msg)

        return hierarchy

    def _get_pattern_guidance(self, work_type: str) -> str:
        """Get decomposition guidance for work type.

        Args:
            work_type: Detected work type

        Returns:
            Pattern guidance string
        """
        # Delegate to imported function from prompts module
        return get_pattern_guidance(work_type)

    def _invoke_llm(
        self,
        prompt: str,
        provider: str,
        _work_type: str,
        response_format: str = "text",
    ) -> tuple[str, int]:
        """Invoke LLM to generate plan.

        Uses extended thinking (high reasoning_level) for supported models to
        improve plan quality. Falls back gracefully for models without extended
        thinking support.

        Args:
            prompt: Derivation prompt
            provider: LLM provider name
            work_type: Detected work type
            response_format: Expected response format ("text" or "json")

        Returns:
            Tuple of (raw_response, tokens_used)
        """
        if self._llm_invoker is None:
            logger.warning("No LLM invoker configured, returning placeholder")
            return self._placeholder_response(), 0

        # Determine reasoning level based on model capability
        reasoning_level = None
        if self._thinking_enabled:
            # Check if model supports extended thinking
            effective_reasoning_level = self._resolve_reasoning_level(provider)
            if effective_reasoning_level:
                reasoning_level = effective_reasoning_level
                logger.debug(
                    "Using %s reasoning level for derivation (provider=%s)",
                    reasoning_level,
                    provider,
                )

        # Invoke LLM
        result = self._llm_invoker.invoke(
            prompt=prompt,
            provider=provider,
            reasoning_level=reasoning_level,
            response_format=response_format,
        )

        # Log thinking token usage if available
        if result.thinking_tokens > 0:
            logger.debug(
                "Derivation used %d thinking tokens (total: %d tokens)",
                result.thinking_tokens,
                result.tokens_used,
            )

        return result.content, result.tokens_used

    def _build_step1_prompt(self, objective: str, constraints: str, context: str) -> str:
        """Build Step 1 prompt for planning epics only.

        Step 1 asks the LLM to decompose the objective into epics only.
        Output is expected to be JSON, but parsing tolerates prose fallbacks.

        Args:
            objective: The task objective to plan for
            constraints: Constraints and non-goals
            context: Project context (languages, frameworks, etc.)

        Returns:
            Prompt string for Step 1 (structure planning)
        """
        # Delegate to imported prompt builder
        return build_step1_epics_only_prompt(
            objective=objective,
            constraints=constraints,
            context=context,
            intent_markdown=self._intent_markdown,
            exploration_context=self._exploration_context,
            strategic_prompt=self._strategic_prompt,
        )

    def _build_step2_prompt(self, objective: str, prose_from_step_1: str) -> str:
        """Build Step 2 prompt for deriving stories and tasks (prose).

        Step 2 asks the LLM to derive stories and implementation tasks for each epic,
        with full epic structure visible. Output is still prose, not JSON.

        Args:
            objective: The original task objective
            prose_from_step_1: The prose output from Step 1 (epics only)

        Returns:
            Prompt string for Step 2 (task derivation)
        """
        # Delegate to imported prompt builder
        return build_step2_prompt(
            objective=objective,
            prose_from_step_1=prose_from_step_1,
            intent_markdown=self._intent_markdown,
            exploration_context=self._exploration_context,
        )

    def _build_step3_prompt(self, prose_from_step_2: str) -> str:
        """Build Step 3 prompt for JSON serialization.

        Step 3 asks the LLM to convert the complete prose plan (from Step 2)
        into structured JSON matching the plan_items schema.

        Args:
            prose_from_step_2: The prose output from Step 2 (with tasks added)

        Returns:
            Prompt string for Step 3 (JSON serialization)
        """
        # Delegate to imported prompt builder
        return build_step3_prompt(prose_from_step_2=prose_from_step_2)

    def _normalize_epics(self, epics_data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize epic data from template edit output.

        Args:
            epics_data: List of epic dictionaries from template edit pipeline

        Returns:
            List of normalized epic dictionaries with id, title, description
        """
        if not isinstance(epics_data, list):
            return []

        normalized: list[dict[str, Any]] = []
        for idx, entry in enumerate(epics_data):
            if not isinstance(entry, dict):
                continue

            raw_id = entry.get("id")
            epic_id = str(raw_id).strip() if raw_id else f"E{idx + 1}"
            title = str(entry.get("title") or "").strip()
            description = str(entry.get("description") or "").strip()

            if not title:
                continue

            normalized.append({
                "id": epic_id,
                "title": title,
                "description": description,
            })

        return normalized

    def _parse_epics_from_prose(self, epics_prose: str) -> list[dict[str, Any]]:
        """Parse epics from Step 1 output into structured metadata."""
        cleaned = epics_prose.strip()
        if not cleaned:
            return []

        parsed, error_reason = parse_planning_json_response(cleaned)
        if parsed is not None:
            if isinstance(parsed, dict):
                epics_data = parsed.get("epics", [])
            elif isinstance(parsed, list):
                epics_data = parsed
            else:
                epics_data = []

            if isinstance(epics_data, list) and epics_data:
                epics: list[dict[str, Any]] = []
                for idx, entry in enumerate(epics_data):
                    if not isinstance(entry, dict):
                        continue
                    raw_id = entry.get("id")
                    epic_id = str(raw_id).strip() if raw_id else f"E{idx + 1}"
                    title = str(entry.get("title") or "").strip()
                    description = str(entry.get("description") or "").strip()
                    if not title:
                        continue
                    epics.append(
                        {
                            "id": epic_id,
                            "title": title,
                            "description": description,
                        }
                    )
                return epics

            logger.warning(
                "Step 1 JSON parsed but contained no epics; proceeding with phased derivation."
            )
            return []

        epics = self._extract_epics_from_prose(cleaned)
        if epics:
            if error_reason:
                logger.info(
                    "Step 1 JSON parse failed (%s); parsed epics from prose.",
                    error_reason,
                )
            return epics

        if error_reason:
            logger.warning(
                "Step 1 JSON parsing failed (%s) and no epics found in prose.",
                error_reason,
            )
        else:
            logger.warning("Step 1 output did not contain epics JSON or prose headers.")
        return []

    @staticmethod
    def _extract_epics_from_prose(epics_prose: str) -> list[dict[str, Any]]:
        """Extract epic metadata from prose output."""
        header_re = re.compile(
            r"^E(?P<num>\d+)\s*(?:EPIC\s*)?[:\-]\s*(?P<title>.+)$",
            re.IGNORECASE,
        )
        story_re = re.compile(r"^E\d+\.S\d+\b", re.IGNORECASE)

        epics: list[dict[str, Any]] = []
        current: dict[str, Any] | None = None
        description_lines: list[str] = []

        for raw_line in epics_prose.splitlines():
            line = raw_line.strip()
            if not line:
                if current and description_lines:
                    description_lines.append("")
                continue

            header_match = header_re.match(line)
            if header_match:
                if current is not None:
                    current["description"] = "\n".join(
                        ln for ln in description_lines if ln is not None
                    ).strip()
                    epics.append(current)
                epic_id = f"E{header_match.group('num')}"
                title = header_match.group("title").strip()
                current = {
                    "id": epic_id,
                    "title": title,
                    "description": "",
                }
                description_lines = []
                continue

            if story_re.match(line):
                if current is not None:
                    current["description"] = "\n".join(
                        ln for ln in description_lines if ln is not None
                    ).strip()
                    epics.append(current)
                current = None
                description_lines = []
                continue

            if current is not None:
                description_lines.append(line)

        if current is not None:
            current["description"] = "\n".join(
                ln for ln in description_lines if ln is not None
            ).strip()
            epics.append(current)

        return [epic for epic in epics if epic.get("title")]

    @staticmethod
    def _render_epics_prose(epics: list[dict[str, Any]]) -> str:
        """Render epics into the prose format expected by Step 2."""
        lines: list[str] = []
        for epic in epics:
            epic_id = str(epic.get("id", "")).strip()
            title = str(epic.get("title", "")).strip() or "Untitled"
            description = str(epic.get("description", "")).strip()
            header = f"{epic_id}: {title}" if epic_id else f"E?: {title}"
            lines.append(header)
            if description:
                lines.append(description)
            lines.append("")
        return "\n".join(lines).strip()

    @staticmethod
    def _extract_epic_story_task_titles(
        epic_detail_prose: str, epic_id: str
    ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
        """Extract story/task titles for a single epic from Step 2 prose."""
        stories: list[dict[str, str]] = []
        tasks: list[dict[str, str]] = []
        seen_story_ids: set[str] = set()
        seen_task_ids: set[str] = set()

        story_pattern = re.compile(rf"\b({re.escape(epic_id)}\.S\d+):\s*(.+)$")
        task_pattern = re.compile(rf"\b({re.escape(epic_id)}\.S\d+\.T\d+):\s*(.+)$")

        for raw_line in epic_detail_prose.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            task_match = task_pattern.search(line)
            if task_match:
                task_id = task_match.group(1).strip()
                title = task_match.group(2).strip()
                if task_id not in seen_task_ids and title:
                    tasks.append({"id": task_id, "title": title})
                    seen_task_ids.add(task_id)
                continue

            story_match = story_pattern.search(line)
            if story_match:
                story_id = story_match.group(1).strip()
                title = story_match.group(2).strip()
                if story_id not in seen_story_ids and title:
                    stories.append({"id": story_id, "title": title})
                    seen_story_ids.add(story_id)

        return stories, tasks

    @staticmethod
    def _build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        """Build minimal plan items for partial plan snapshots."""
        plan_items: list[dict[str, Any]] = []
        plan_items.append(
            {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "parent_id": None,
                "depth": 0,
                "order": 0,
            }
        )

        task_map: dict[str, list[dict[str, str]]] = {}
        for task in tasks:
            task_id = task.get("id", "")
            story_id = task_id.split(".T", 1)[0] if ".T" in task_id else ""
            if not story_id:
                continue
            task_map.setdefault(story_id, []).append(task)

        for story_index, story in enumerate(stories, start=1):
            story_id = story.get("id", "")
            story_title = story.get("title", "")
            if not story_id:
                continue
            plan_items.append(
                {
                    "id": story_id,
                    "item_type": "story",
                    "title": story_title,
                    "parent_id": epic_id,
                    "depth": 1,
                    "order": story_index,
                }
            )
            for task_index, task in enumerate(task_map.get(story_id, []), start=1):
                task_id = task.get("id", "")
                task_title = task.get("title", "")
                if not task_id:
                    continue
                plan_items.append(
                    {
                        "id": task_id,
                        "item_type": "task",
                        "title": task_title,
                        "parent_id": story_id,
                        "depth": 2,
                        "order": task_index,
                    }
                )
        return plan_items

    @staticmethod
    def _estimate_output_tokens(text: str) -> int:
        """Estimate output tokens from text length (rough heuristic)."""
        return max(1, len(text) // 4)

    @staticmethod
    def _validate_epic_prose(content: str, epic_id: str) -> tuple[bool, str | None]:
        """Validate prose output from per-epic template editing.

        Checks that the LLM populated the template with meaningful content
        for the target epic.

        Args:
            content: Raw file content after LLM editing.
            epic_id: Target epic identifier (e.g., "E2").

        Returns:
            Tuple of (is_valid, error_message). (True, None) when valid.
        """
        if not content or not content.strip():
            return (False, "Empty response")

        if "<FILL:" in content:
            return (False, "Template placeholders not filled")

        all_story_ids = set(re.findall(r"\b(E\d+\.S\d+):", content))
        all_task_ids = set(re.findall(r"\b(E\d+\.S\d+\.T\d+):", content))
        target_story_ids = sorted(story_id for story_id in all_story_ids if story_id.startswith(f"{epic_id}."))
        target_task_ids = sorted(task_id for task_id in all_task_ids if task_id.startswith(f"{epic_id}."))

        if not target_story_ids:
            return (False, f"No structural content found for {epic_id}")

        wrong_epic_story_ids = sorted(story_id for story_id in all_story_ids if not story_id.startswith(f"{epic_id}."))
        wrong_epic_task_ids = sorted(task_id for task_id in all_task_ids if not task_id.startswith(f"{epic_id}."))
        if wrong_epic_story_ids or wrong_epic_task_ids:
            wrong_ids = wrong_epic_story_ids + wrong_epic_task_ids
            preview = ", ".join(wrong_ids[:3])
            return (False, f"Found IDs for non-target epic(s): {preview}")

        story_count, task_count = DerivationEngine._count_epic_story_task_ids(content, epic_id)
        if story_count == 0:
            return (False, f"No structural content found for {epic_id}")
        if task_count == 0:
            return (False, f"No task IDs found for {epic_id} (expected {epic_id}.S#.T#:)")

        story_to_tasks: dict[str, set[str]] = {story_id: set() for story_id in target_story_ids}
        orphan_tasks: list[str] = []
        for task_id in target_task_ids:
            story_id = task_id.rsplit(".T", 1)[0]
            if story_id in story_to_tasks:
                story_to_tasks[story_id].add(task_id)
            else:
                orphan_tasks.append(task_id)

        if orphan_tasks:
            orphan_task = orphan_tasks[0]
            orphan_story = orphan_task.rsplit(".T", 1)[0]
            return (
                False,
                f"Task {orphan_task} references missing story {orphan_story} in {epic_id}",
            )

        stories_missing_tasks = [story_id for story_id, tasks in story_to_tasks.items() if not tasks]
        if stories_missing_tasks:
            return (
                False,
                f"Story {stories_missing_tasks[0]} has no task IDs (expected {stories_missing_tasks[0]}.T#:)",
            )

        return (True, None)

    @staticmethod
    def _count_epic_story_task_ids(epic_detail_prose: str, epic_id: str) -> tuple[int, int]:
        """Count unique story/task IDs for a specific epic in prose content."""
        story_ids = set(re.findall(rf"\b{epic_id}\.S\d+:", epic_detail_prose))
        task_ids = set(re.findall(rf"\b{epic_id}\.S\d+\.T\d+:", epic_detail_prose))
        return len(story_ids), len(task_ids)

    @staticmethod
    def _count_epic_items(epic_detail_prose: str, epic_id: str | None = None) -> int:
        """Count story/task items in epic detail prose.

        Uses regex with word boundaries to avoid false matches.
        Counts unique IDs to avoid double-counting.
        """
        if epic_id:
            # Count items for a specific epic
            story_count, task_count = DerivationEngine._count_epic_story_task_ids(
                epic_detail_prose, epic_id
            )
            return story_count + task_count
        else:
            # Count all epic items (multi-epic prose)
            story_ids = set(re.findall(r"\bE\d+\.S\d+:", epic_detail_prose))
            task_ids = set(re.findall(r"\bE\d+\.S\d+\.T\d+:", epic_detail_prose))
            return len(story_ids) + len(task_ids)

    @staticmethod
    def _extract_reason_codes_for_epic(
        epic_detail_prose: str,
        epic_id: str,
        *,
        status: str = "",
        item_count: int | None = None,
        output_tokens: int | None = None,
    ) -> list[str]:
        """Infer structured reason codes for epic derivation quality/recovery."""
        reason_codes: list[str] = []
        if status in {"template_fallback", "template_error", "validation_failed"}:
            reason_codes.append("template_fallback")

        all_story_ids = set(re.findall(r"\b(E\d+\.S\d+):", epic_detail_prose))
        all_task_ids = set(re.findall(r"\b(E\d+\.S\d+\.T\d+):", epic_detail_prose))
        target_story_ids = sorted(story_id for story_id in all_story_ids if story_id.startswith(f"{epic_id}."))
        target_task_ids = sorted(task_id for task_id in all_task_ids if task_id.startswith(f"{epic_id}."))

        if not target_story_ids:
            reason_codes.append("no_stories")
        if not target_task_ids:
            reason_codes.append("no_tasks")

        if any(not story_id.startswith(f"{epic_id}.") for story_id in all_story_ids) or any(
            not task_id.startswith(f"{epic_id}.") for task_id in all_task_ids
        ):
            reason_codes.append("wrong_epic_ids")

        story_to_tasks: dict[str, set[str]] = {story_id: set() for story_id in target_story_ids}
        orphan_tasks: list[str] = []
        for task_id in target_task_ids:
            story_id = task_id.rsplit(".T", 1)[0]
            if story_id in story_to_tasks:
                story_to_tasks[story_id].add(task_id)
            else:
                orphan_tasks.append(task_id)
        if orphan_tasks:
            reason_codes.append("orphan_tasks")
        if any(not tasks for tasks in story_to_tasks.values()):
            reason_codes.append("no_tasks_for_story")

        if item_count is not None and item_count > EPIC_ITEM_REDERIVE_THRESHOLD:
            reason_codes.append("oversized_items")
        if output_tokens is not None and output_tokens > EPIC_OUTPUT_TOKEN_LIMIT:
            reason_codes.append("oversized_tokens")

        deduped: list[str] = []
        for code in reason_codes:
            if code not in deduped:
                deduped.append(code)
        return deduped

    @staticmethod
    def _write_epic_failure_artifact(
        working_dir: Path,
        *,
        epic_id: str,
        story_count: int,
        task_count: int,
        reason_codes: list[str],
        retry_metadata: dict[str, Any],
        output_preview: str,
    ) -> str | None:
        """Persist terminal derivation failure details for remote diagnostics."""
        try:
            debug_dir = working_dir / ".obra" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            path = debug_dir / f"derivation_epic_failure_{epic_id}_{timestamp}.json"
            payload = {
                "epic_id": epic_id,
                "story_count": story_count,
                "task_count": task_count,
                "reason_codes": reason_codes,
                "retry_metadata": retry_metadata,
                "output_preview": output_preview[:240],
                "session_id": os.getenv("OBRA_SESSION_ID"),
                "created_at": datetime.now(UTC).isoformat(),
            }
            path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            return str(path)
        except Exception as exc:
            logger.warning("Failed to write epic failure artifact for %s: %s", epic_id, exc)
            return None

    def _merge_epic_details(self, epics_prose: str, all_epic_details: list[str]) -> str:
        """Merge epic-only prose with per-epic story/task details."""
        merged = [epics_prose.strip()]
        if all_epic_details:
            merged.append("")
            for detail in all_epic_details:
                merged.append(detail.strip())
                merged.append("")
        return "\n".join(merged).strip()

    def _serialize_per_epic(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Serialize each epic's stories/tasks to JSON in parallel, then merge.

        Epic items are constructed directly from parsed_epics (no LLM needed).
        Only stories and tasks require LLM serialization. Uses ThreadPoolExecutor
        for parallel execution since Step 3 has no cross-epic dependencies.

        This approach:
        - ~4x faster than sequential (11 epics with 4 workers = ~3 batches)
        - Provides per-epic progress visibility
        - Reduces risk of truncation/validation failure
        - Handles partial failures gracefully

        Args:
            all_epic_details: List of per-epic prose (stories and tasks)
            parsed_epics: List of epic dicts with id, title, description
            provider: LLM provider to use
            progress_callback: Optional callback for progress events

        Returns:
            Tuple of (all_plan_items, total_tokens)
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        max_workers = get_derivation_serialize_max_concurrent()
        worker_delay_s = get_derivation_serialize_worker_delay_s(provider=provider)
        epic_count = len(parsed_epics)

        if progress_callback:
            progress_callback(
                "epic_serialization_batch_started",
                {
                    "epic_count": epic_count,
                    "max_concurrent": max_workers,
                },
            )

        def serialize_one(
            args: tuple[int, dict[str, Any], str],
        ) -> tuple[int, dict[str, Any], list[dict[str, Any]], int]:
            """Serialize a single epic's stories/tasks to JSON with bounded recovery.

            Recovery path (mirrors Step 2 pattern):
            - Attempt 1: Standard prompt + template-edit pipeline (3 internal retries)
            - Attempt 2: Strict retry with item-count constraints (3 internal retries)
            - Terminal: Debug artifact + structured error
            """
            i, epic, epic_prose = args
            epic_id = epic.get("id", f"E{i + 1}")
            epic_title = epic.get("title", "Untitled")

            # Epic item constructed directly (no LLM needed - already structured)
            epic_item: dict[str, Any] = {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "description": epic.get("description", ""),
                "acceptance_criteria": [],
                "dependencies": [],
                "parent_id": None,
                "depth": 0,
                "work_phase": "implement",
                "suggested_agent": None,
            }

            # Attempt 1: Standard prompt
            prompt = build_step3_per_epic_prompt(epic_prose, epic_id)
            epic_items = self._parse_flat_response_via_pipeline(prompt, provider)

            if epic_items:
                if progress_callback:
                    progress_callback(
                        "epic_serialization_recovery",
                        {
                            "epic_id": epic_id,
                            "attempt_stage": "initial",
                            "status": "success",
                            "outcome": "completed",
                        },
                    )
                tokens_est = len(prompt) // 4 + len(json.dumps(epic_items)) // 4
                return (i, epic_item, epic_items, tokens_est)

            # Attempt 1 failed — emit recovery event and try strict retry
            story_count, task_count = self._count_epic_story_task_ids(epic_prose, epic_id)
            if progress_callback:
                progress_callback(
                    "epic_serialization_recovery",
                    {
                        "epic_id": epic_id,
                        "attempt_stage": "initial",
                        "status": "template_fallback",
                        "stories_expected": story_count,
                        "tasks_expected": task_count,
                        "outcome": "retry",
                    },
                )

            # Attempt 2: Strict retry with item-count constraints
            logger.warning(
                "Epic %s Step 3 initial attempt failed, retrying with strict prompt "
                "(expected %d stories, %d tasks)",
                epic_id, story_count, task_count,
            )
            strict_prompt = build_step3_per_epic_prompt_strict(
                epic_prose, epic_id,
                expected_story_count=story_count,
                expected_task_count=task_count,
            )
            epic_items = self._parse_flat_response_via_pipeline(strict_prompt, provider)

            if epic_items:
                if progress_callback:
                    progress_callback(
                        "epic_serialization_recovery",
                        {
                            "epic_id": epic_id,
                            "attempt_stage": "strict_retry",
                            "status": "success",
                            "outcome": "completed",
                        },
                    )
                tokens_est = (len(prompt) + len(strict_prompt)) // 4 + len(json.dumps(epic_items)) // 4
                return (i, epic_item, epic_items, tokens_est)

            # Terminal failure — write debug artifact
            if progress_callback:
                progress_callback(
                    "epic_serialization_recovery",
                    {
                        "epic_id": epic_id,
                        "attempt_stage": "strict_retry",
                        "status": "template_fallback",
                        "stories_expected": story_count,
                        "tasks_expected": task_count,
                        "outcome": "failed",
                    },
                )

            preview = re.sub(r"\s+", " ", epic_prose).strip()[:240]
            artifact_path = self._write_epic_failure_artifact(
                self._working_dir,
                epic_id=epic_id,
                story_count=story_count,
                task_count=task_count,
                reason_codes=["step3_template_fallback"],
                retry_metadata={
                    "initial_status": "template_fallback",
                    "retry_status": "template_fallback",
                    "attempt_stage": "strict_retry",
                },
                output_preview=preview,
            )
            msg = (
                f"No stories/tasks parsed for {epic_id} during per-epic serialization "
                f"(expected {story_count} stories, {task_count} tasks). "
                f"Both standard and strict retry failed."
            )
            if artifact_path:
                msg += f" Artifact: {artifact_path}"
            raise ValueError(msg)

        # Build work items
        work = [
            (i, epic, prose)
            for i, (epic, prose) in enumerate(zip(parsed_epics, all_epic_details, strict=False))
        ]
        results: list[tuple[int, dict[str, Any], list[dict[str, Any]], int]] = []
        errors: list[tuple[int, str, Exception]] = []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Stagger worker starts to avoid simultaneous API calls
            # that exhaust provider rate limits
            futures: dict[Any, Any] = {}
            for idx, w in enumerate(work):
                if idx > 0 and worker_delay_s > 0:
                    time.sleep(worker_delay_s)
                futures[executor.submit(serialize_one, w)] = w
            for future in as_completed(futures):
                work_item = futures[future]
                i, epic, _ = work_item
                epic_id = epic.get("id", f"E{i + 1}")
                epic_title = epic.get("title", "Untitled")

                try:
                    result = future.result()
                    results.append(result)

                    if progress_callback:
                        progress_callback(
                            "epic_serialization_completed",
                            {
                                "epic_index": i + 1,
                                "epic_count": epic_count,
                                "epic_id": epic_id,
                                "epic_title": epic_title,
                                "items_serialized": len(result[2]) + 1,  # +1 for epic
                            },
                        )

                    logger.debug(
                        "Epic %s serialized: %d items, ~%d tokens",
                        epic_id,
                        len(result[2]) + 1,
                        result[3],
                    )
                except Exception as e:
                    logger.warning("Epic %s serialization failed: %s", epic_id, e)
                    errors.append((i, epic_id, e))

        # Handle errors
        if errors:
            from obra.exceptions import ObraError

            details = "; ".join(f"{epic_id}: {err}" for _, epic_id, err in errors[:3])
            msg = (
                f"{len(errors)}/{epic_count} epics failed serialization. "
                f"Aborting to avoid incomplete plan. {details}"
            )
            raise ObraError(msg)

        # Merge results in epic order
        results.sort(key=lambda x: x[0])
        all_plan_items: list[dict[str, Any]] = []
        total_tokens = 0
        for _, epic_item, epic_items, tokens in results:
            all_plan_items.append(epic_item)
            all_plan_items.extend(epic_items)
            total_tokens += tokens

        return all_plan_items, total_tokens

    def _derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        """Derive stories + tasks per-epic with cumulative global context.

        Uses TemplateEditPipeline with prose templates to eliminate preamble
        contamination from LLM text responses.

        Returns:
            Tuple of (merged_prose, per_epic_details_list, total_tokens).
            The per_epic_details_list is used by Step 3 for per-epic serialization.
        """
        import threading
        import time

        all_epic_details: list[str] = []
        total_tokens = 0

        # Build LLM config from provider and tier config
        tier_config = resolve_tier_config("high", role="orchestrator")
        llm_config = {
            "provider": provider,
            "model": tier_config.get("model", ""),
            "reasoning_level": tier_config.get("reasoning_level", "off"),
            "auth": tier_config.get("auth", "oauth"),
        }
        story_range = get_derivation_story_range()
        task_range = get_derivation_task_range()
        strict_story_range = get_derivation_strict_story_range()
        strict_task_range = get_derivation_strict_task_range()

        for i, epic in enumerate(parsed_epics):
            epic_id = epic.get("id", f"E{i + 1}")
            epic_title = epic.get("title", "Untitled")

            if progress_callback:
                progress_callback(
                    "epic_derivation_started",
                    {
                        "epic_index": i + 1,
                        "epic_count": len(parsed_epics),
                        "epic_id": epic_id,
                        "epic_title": epic_title,
                    },
                )

            heartbeat_stop = threading.Event()
            heartbeat_thread: threading.Thread | None = None
            if progress_callback:
                start_ts = time.perf_counter()

                def _heartbeat(
                    _stop: threading.Event = heartbeat_stop,
                    _start: float = start_ts,
                    _idx: int = i,
                    _title: str = epic_title,
                ) -> None:
                    while not _stop.wait(30.0):
                        elapsed = int(time.perf_counter() - _start)
                        progress_callback(
                            "epic_derivation_heartbeat",
                            {
                                "epic_index": _idx + 1,
                                "epic_count": len(parsed_epics),
                                "epic_title": _title,
                                "items_so_far": 0,
                                "elapsed_s": elapsed,
                            },
                        )

                heartbeat_thread = threading.Thread(target=_heartbeat, daemon=True)
                heartbeat_thread.start()

            try:
                prompt = build_step2_per_epic_prompt(
                    objective=objective,
                    all_epics_prose=epics_prose,
                    completed_epic_details=all_epic_details,
                    target_epic=epic.get("prose", ""),
                    target_epic_id=epic_id,
                    intent_markdown=intent_markdown,
                    exploration_context=exploration_context,
                    story_range=story_range,
                    task_range=task_range,
                    strict=False,
                )

                pipeline = TemplateEditPipeline(
                    working_dir=self._working_dir,
                    action_name="derivation_per_epic",
                    output_format="text",
                )
                template_content = build_step2_per_epic_template(
                    target_epic_id=epic_id,
                    story_range=story_range,
                    task_range=task_range,
                )

                epic_detail_prose, meta = pipeline.execute(
                    base_prompt=prompt,
                    template_content=template_content,
                    validator=lambda content, _eid=epic_id: self._validate_epic_prose(content, _eid),
                    fallback_fn=lambda: "",
                    llm_config=llm_config,
                )

                status = str(meta.get("status", ""))
                story_count, task_count = self._count_epic_story_task_ids(epic_detail_prose, epic_id)
                item_count = story_count + task_count
                output_tokens = self._estimate_output_tokens(epic_detail_prose)
                reason_codes = self._extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                    status=status,
                    item_count=item_count,
                    output_tokens=output_tokens,
                )
                if progress_callback:
                    progress_callback(
                        "epic_derivation_recovery",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "attempt_stage": "initial",
                            "status": status,
                            "reason_codes": reason_codes,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "continue",
                        },
                    )

                retry_stage = "initial"
                retry_status = status
                retry_meta: dict[str, Any] = {}

                branch_a_repair = story_count > 0 and task_count == 0
                branch_b_strict = story_count == 0 or status in {
                    "template_fallback",
                    "template_error",
                    "validation_failed",
                }
                branch_c_strict = (
                    story_count > 0
                    and task_count > 0
                    and (
                        item_count > EPIC_ITEM_REDERIVE_THRESHOLD
                        or output_tokens > EPIC_OUTPUT_TOKEN_LIMIT
                    )
                )

                if branch_a_repair:
                    retry_stage = "targeted_repair"
                    stories, tasks = self._extract_epic_story_task_titles(epic_detail_prose, epic_id)
                    task_story_ids = {task["id"].split(".T", 1)[0] for task in tasks if task.get("id")}
                    missing_story_ids = [story["id"] for story in stories if story.get("id") not in task_story_ids]
                    repair_prompt = build_step2_repair_prompt(
                        objective=objective,
                        target_epic_id=epic_id,
                        incomplete_output=epic_detail_prose,
                        missing_stories=missing_story_ids or [story["id"] for story in stories if story.get("id")],
                    )
                    repair_template = build_step2_repair_template(
                        target_epic_id=epic_id,
                        existing_stories=stories,
                    )
                    repair_pipeline = TemplateEditPipeline(
                        working_dir=self._working_dir,
                        action_name="derivation_per_epic",
                        output_format="text",
                    )
                    epic_detail_prose, retry_meta = repair_pipeline.execute(
                        base_prompt=repair_prompt,
                        template_content=repair_template,
                        validator=lambda content, _eid=epic_id: self._validate_epic_prose(content, _eid),
                        fallback_fn=lambda: "",
                        llm_config=llm_config,
                    )
                    retry_status = str(retry_meta.get("status", ""))
                    story_count, task_count = self._count_epic_story_task_ids(epic_detail_prose, epic_id)
                    item_count = story_count + task_count
                    output_tokens = self._estimate_output_tokens(epic_detail_prose)
                elif branch_b_strict or branch_c_strict:
                    retry_stage = "strict_retry"
                    retry_prompt = build_step2_per_epic_prompt(
                        objective=objective,
                        all_epics_prose=epics_prose,
                        completed_epic_details=all_epic_details,
                        target_epic=epic.get("prose", ""),
                        target_epic_id=epic_id,
                        intent_markdown=intent_markdown,
                        exploration_context=exploration_context,
                        story_range=strict_story_range,
                        task_range=strict_task_range,
                        strict=True,
                    )
                    strict_template = build_step2_per_epic_template(
                        target_epic_id=epic_id,
                        story_range=strict_story_range,
                        task_range=strict_task_range,
                    )

                    strict_pipeline = TemplateEditPipeline(
                        working_dir=self._working_dir,
                        action_name="derivation_per_epic",
                        output_format="text",
                    )
                    epic_detail_prose, retry_meta = strict_pipeline.execute(
                        base_prompt=retry_prompt,
                        template_content=strict_template,
                        validator=lambda content, _eid=epic_id: self._validate_epic_prose(content, _eid),
                        fallback_fn=lambda: "",
                        llm_config=llm_config,
                    )
                    retry_status = str(retry_meta.get("status", ""))
                    story_count, task_count = self._count_epic_story_task_ids(epic_detail_prose, epic_id)
                    item_count = story_count + task_count
                    output_tokens = self._estimate_output_tokens(epic_detail_prose)
                    if (
                        item_count > EPIC_ITEM_REDERIVE_THRESHOLD
                        or output_tokens > EPIC_OUTPUT_TOKEN_LIMIT
                    ):
                        logger.warning(
                            "Epic %s still oversized after strict retry (%d items, ~%d tokens).",
                            epic_id,
                            item_count,
                            output_tokens,
                        )

                reason_codes = self._extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                    status=retry_status,
                    item_count=item_count,
                    output_tokens=output_tokens,
                )
                failed_recovery = any(
                    code in reason_codes
                    for code in [
                        "template_fallback",
                        "no_stories",
                        "no_tasks",
                        "no_tasks_for_story",
                        "wrong_epic_ids",
                        "orphan_tasks",
                    ]
                )

                if progress_callback:
                    progress_callback(
                        "epic_derivation_recovery",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "attempt_stage": retry_stage,
                            "status": retry_status,
                            "reason_codes": reason_codes,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "failed" if failed_recovery else "completed",
                        },
                    )

                if failed_recovery:
                    preview = re.sub(r"\s+", " ", epic_detail_prose).strip()[:240]
                    artifact_path = self._write_epic_failure_artifact(
                        self._working_dir,
                        epic_id=epic_id,
                        story_count=story_count,
                        task_count=task_count,
                        reason_codes=reason_codes,
                        retry_metadata={
                            "initial_status": status,
                            "retry_status": retry_status,
                            "attempt_stage": retry_stage,
                            "meta": retry_meta,
                        },
                        output_preview=preview,
                    )
                    msg = (
                        f"Epic {epic_id} derivation failed "
                        f"(stage={retry_stage}, status={retry_status}, stories={story_count}, "
                        f"tasks={task_count}, reasons={','.join(reason_codes) or 'unknown'}). "
                        f"Preview: {preview or '<empty>'}"
                    )
                    if artifact_path:
                        msg += f" Artifact: {artifact_path}"
                    raise ObraError(msg)
            finally:
                if heartbeat_thread:
                    heartbeat_stop.set()
                    heartbeat_thread.join(timeout=5)

            all_epic_details.append(epic_detail_prose)

            if progress_callback:
                story_count, task_count = self._count_epic_story_task_ids(epic_detail_prose, epic_id)

                # Extract full story/task data for plan snapshot if stories exist
                stories, tasks = self._extract_epic_story_task_titles(epic_detail_prose, epic_id)
                if stories:
                    progress_callback(
                        "plan_snapshot",
                        {
                            "source": "derive",
                            "mode": "partial",
                            "plan_items": self._build_partial_plan_items(
                                epic_id, epic_title, stories, tasks
                            ),
                        },
                    )
                progress_callback(
                    "epic_derivation_completed",
                    {
                        "epic_index": i + 1,
                        "epic_count": len(parsed_epics),
                        "epic_id": epic_id,
                        "epic_title": epic_title,
                        "stories_derived": story_count,
                        "tasks_derived": task_count,
                        "outcome": "completed",
                        "reason_codes": self._extract_reason_codes_for_epic(
                            epic_detail_prose,
                            epic_id,
                        ),
                    },
                )

        merged = self._merge_epic_details(epics_prose, all_epic_details)
        return merged, all_epic_details, total_tokens

    def _derive_multi_step_plan(
        self,
        objective: str,
        project_context: str,
        constraints: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> tuple[list[dict[str, Any]], int]:
        """Derive implementation plan using 3-step pipeline.

        Executes three sequential LLM calls:
        1. Plan Structure (epics only in prose)
        2. Story + Task Derivation (per-epic or one-shot, global context preserved)
        3. JSON Serialization (convert prose to structured JSON)

        Args:
            objective: Task objective to plan for
            project_context: Project context (languages, frameworks, etc.)
            constraints: Constraints and non-goals
            provider: LLM provider to use
            progress_callback: Optional callback for progress events

        Returns:
            Tuple of (plan_items, total_tokens_used)
        """
        import time

        pipeline_start = time.perf_counter()
        total_tokens = 0
        step_tokens = {}  # Track tokens per step for structured logging

        # Log pipeline start (S5.T1)
        logger.info(
            "derivation_pipeline_started",
            extra={
                "objective_length": len(objective),
            },
        )

        # Step 1: Plan Structure
        if progress_callback:
            progress_callback("derivation_step_started", {"step": 1, "step_name": "structure"})

        step1_start = time.perf_counter()

        # Use template edit pipeline for Step 1 (epic identification)
        import threading

        # Heartbeat thread for Step 1
        heartbeat_stop = threading.Event()
        heartbeat_thread: threading.Thread | None = None
        if progress_callback:
            heartbeat_start = time.perf_counter()

            def _step1_heartbeat(
                _stop: threading.Event = heartbeat_stop,
                _start: float = heartbeat_start,
            ) -> None:
                while not _stop.wait(30.0):
                    progress_callback(
                        "derivation_step_heartbeat",
                        {
                            "step": 1,
                            "step_name": "structure",
                            "elapsed_s": int(time.perf_counter() - _start),
                        },
                    )

            heartbeat_thread = threading.Thread(target=_step1_heartbeat, daemon=True)
            heartbeat_thread.start()

        try:
            # Build LLM config from provider
            tier_config = resolve_tier_config(
                tier="fast",  # Step 1 is fast tier (epic identification)
                role="orchestrator",
                override_provider=provider,
            )
            llm_config = {
                "provider": provider,
                "model": tier_config.get("model"),
                "thinking_enabled": self._thinking_enabled,
            }

            # Build template and validator
            story_range = "3-6"  # Default epic range
            template = build_step1_epics_template(story_range)
            min_epics = int(story_range.split("-")[0])

            def validator(content: dict) -> tuple[bool, str | None]:
                return self._validate_step1_epics(content, min_epics)

            # Build prompt (without JSON output format section)
            base_prompt = self._build_step1_prompt(
                objective=objective,
                constraints=constraints,
                context=project_context,
            )

            # Execute template edit pipeline
            pipeline = TemplateEditPipeline(
                working_dir=self._working_dir,
                action_name="derivation_step1",
                output_format="json",
            )

            data, metadata = pipeline.execute(
                base_prompt=base_prompt,
                template_content=template,
                validator=validator,
                fallback_fn=lambda: {"epics": []},
                llm_config=llm_config,
            )

            # Extract and normalize epics
            parsed_epics = self._normalize_epics(data.get("epics", []))
            epics_prose = self._render_epics_prose(parsed_epics) if parsed_epics else ""
            prose_step1 = epics_prose
            epic_count = len(parsed_epics)
            items_step1 = epic_count

            # Extract tokens from metadata
            tokens1 = metadata.get("tokens", 0)
            total_tokens += tokens1

        finally:
            # Stop heartbeat thread
            if heartbeat_thread:
                heartbeat_stop.set()
                heartbeat_thread.join(timeout=5)

        # ISSUE-DERIVE-001: Removed post-hoc timeout check.
        # Post-hoc checks cannot detect actual stalls - only duration after completion.
        # Real stall detection is handled by MonitoringThread during CLI subprocess execution.
        step1_duration_ms = int((time.perf_counter() - step1_start) * 1000)

        # Track step tokens (S5.T2)
        step_tokens["structure"] = {"total_tokens": tokens1}

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 1,
                    "step_name": "structure",
                    "duration_ms": step1_duration_ms,
                    "items_produced": items_step1,
                    "prose": prose_step1,  # Include prose for DEBUG verbosity
                },
            )

        # Structured logging for step completion (S5.T1)
        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 1,
                "step_name": "structure",
                "duration_ms": step1_duration_ms,
                "tokens": tokens1,
                "items_produced": items_step1,
            },
        )
        logger.debug("Step 1 (structure) completed: %d tokens", tokens1)

        # Step 2: Task Derivation
        if progress_callback:
            progress_callback("derivation_step_started", {"step": 2, "step_name": "tasks"})

        step2_start = time.perf_counter()
        use_per_epic = epic_count > 2
        if not parsed_epics:
            logger.warning(
                "No epics parsed from Step 1 JSON; using phased derivation with default epic scaffolding"
            )
            use_per_epic = False

        logger.info(
            "Complexity routing: %d epics -> %s mode",
            epic_count,
            "per-epic" if use_per_epic else "one-shot",
        )

        all_epic_details: list[str] = []
        if use_per_epic:
            prose_step2, all_epic_details, tokens2 = self._derive_per_epic(
                objective=objective,
                epics_prose=epics_prose,
                parsed_epics=parsed_epics,
                provider=provider,
                progress_callback=progress_callback,
                intent_markdown=self._intent_markdown,
                exploration_context=self._exploration_context,
            )
        else:
            step2_prompt = self._build_step2_prompt(
                objective=objective,
                prose_from_step_1=epics_prose,
            )
            prose_step2, tokens2 = self._invoke_llm(
                prompt=step2_prompt,
                provider=provider,
                _work_type="feature_implementation",
            )
        total_tokens += tokens2

        # ISSUE-DERIVE-001: Removed post-hoc timeout check (see step 1 comment).
        step2_duration_ms = int((time.perf_counter() - step2_start) * 1000)

        # Count tasks added: count ".T" patterns in prose
        task_count = prose_step2.count(".T")
        items_step2 = task_count

        # Track step tokens (S5.T2)
        step_tokens["tasks"] = {"total_tokens": tokens2}

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 2,
                    "step_name": "tasks",
                    "duration_ms": step2_duration_ms,
                    "items_produced": items_step2,
                    "prose": prose_step2,  # Include prose for DEBUG verbosity
                },
            )

        # Structured logging for step completion (S5.T1)
        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 2,
                "step_name": "tasks",
                "duration_ms": step2_duration_ms,
                "tokens": tokens2,
                "items_produced": items_step2,
            },
        )
        logger.debug("Step 2 (tasks) completed: %d tokens", tokens2)

        # Convergence gate: Step 3 must not run if any epic is structurally incomplete.
        convergence_failures: list[dict[str, Any]] = []
        if parsed_epics:
            if all_epic_details:
                if len(all_epic_details) != len(parsed_epics):
                    convergence_failures.append(
                        {
                            "epic_id": "unknown",
                            "reason_codes": ["missing_epic_details"],
                            "stories": len(all_epic_details),
                            "tasks": 0,
                        }
                    )
                for epic, epic_detail in zip(parsed_epics, all_epic_details, strict=False):
                    epic_id = str(epic.get("id", "")).strip()
                    if not epic_id:
                        continue
                    stories, tasks = self._count_epic_story_task_ids(epic_detail, epic_id)
                    reason_codes = self._extract_reason_codes_for_epic(epic_detail, epic_id)
                    structural_reasons = [
                        code
                        for code in reason_codes
                        if code
                        in {
                            "no_stories",
                            "no_tasks",
                            "no_tasks_for_story",
                            "wrong_epic_ids",
                            "orphan_tasks",
                        }
                    ]
                    if structural_reasons:
                        convergence_failures.append(
                            {
                                "epic_id": epic_id,
                                "reason_codes": structural_reasons,
                                "stories": stories,
                                "tasks": tasks,
                            }
                        )
            else:
                for epic in parsed_epics:
                    epic_id = str(epic.get("id", "")).strip()
                    if not epic_id:
                        continue
                    stories, tasks = self._count_epic_story_task_ids(prose_step2, epic_id)
                    reason_codes = self._extract_reason_codes_for_epic(prose_step2, epic_id)
                    structural_reasons = [
                        code
                        for code in reason_codes
                        if code
                        in {
                            "no_stories",
                            "no_tasks",
                            "no_tasks_for_story",
                            "wrong_epic_ids",
                            "orphan_tasks",
                        }
                    ]
                    if structural_reasons:
                        convergence_failures.append(
                            {
                                "epic_id": epic_id,
                                "reason_codes": structural_reasons,
                                "stories": stories,
                                "tasks": tasks,
                            }
                        )

        if convergence_failures:
            if progress_callback:
                progress_callback(
                    "derivation_convergence_failed",
                    {
                        "step": 2,
                        "step_name": "tasks",
                        "failures": convergence_failures,
                    },
                )
            failure = convergence_failures[0]
            raise ObraError(
                "Step 2 convergence failed before serialization for "
                f"{failure['epic_id']} (stories={failure['stories']}, tasks={failure['tasks']}, "
                f"reasons={','.join(failure['reason_codes'])})."
            )

        # Step 3: JSON Serialization
        if progress_callback:
            progress_callback("derivation_step_started", {"step": 3, "step_name": "serialize"})

        step3_start = time.perf_counter()

        # Use per-epic serialization when we have per-epic details (faster, better progress)
        if all_epic_details and parsed_epics:
            plan_items, tokens3 = self._serialize_per_epic(
                all_epic_details=all_epic_details,
                parsed_epics=parsed_epics,
                provider=provider,
                progress_callback=progress_callback,
            )
        else:
            # Fallback to single-call serialization for one-shot derivation
            step3_prompt = self._build_step3_prompt(prose_from_step_2=prose_step2)
            plan_items = self._parse_flat_response_via_pipeline(step3_prompt, provider)
            tokens3 = len(step3_prompt) // 4 + len(json.dumps(plan_items)) // 4

        total_tokens += tokens3

        step3_duration_ms = int((time.perf_counter() - step3_start) * 1000)
        logger.debug("Step 3 (serialize) completed: estimated %d tokens", tokens3)

        # Step 3 completed successfully
        items_step3 = len(plan_items)

        # Track step tokens (S5.T2)
        step_tokens["serialize"] = {"total_tokens": tokens3}

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 3,
                    "step_name": "serialize",
                    "duration_ms": step3_duration_ms,
                    "items_produced": items_step3,
                    "raw_json": json.dumps(plan_items),  # Include JSON for DEBUG verbosity
                },
            )

        # Structured logging for step completion (S5.T1)
        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 3,
                "step_name": "serialize",
                "duration_ms": step3_duration_ms,
                "tokens": tokens3,
                "items_produced": items_step3,
            },
        )

        # Validation & Refinement (S4.T0, S4.T1)
        if validation_intensity == "none":
            # Skip validation entirely
            logger.debug("Validation skipped (intensity=none)")
        else:
            # Determine max refinement passes based on intensity
            max_passes = 2 if validation_intensity == "thorough" else 1
            pass_count = 0
            violations = self._validate_plan_items(plan_items)

            while violations and pass_count < max_passes:
                pass_count += 1

                # Emit validation started event (S4.T3)
                if progress_callback:
                    progress_callback(
                        "derivation_validation_started",
                        {
                            "pass": pass_count,
                            "max_passes": max_passes,
                        },
                    )

                logger.info(
                    "Plan validation failed (pass %d/%d): %d violations",
                    pass_count,
                    max_passes,
                    len(violations),
                )
                logger.debug("Violations: %s", violations)

                # Build refinement prompt with validation errors
                refinement_prompt = build_refinement_prompt(prose_step2, violations)

                # Use pipeline for refinement (handles LLM invocation + parsing)
                try:
                    plan_items = self._parse_flat_response_via_pipeline(refinement_prompt, provider)
                    # Estimate tokens for tracking
                    tokens_refine = len(refinement_prompt) // 4 + len(json.dumps(plan_items)) // 4
                    total_tokens += tokens_refine
                    logger.debug(
                        "Refinement pass %d: estimated %d tokens",
                        pass_count,
                        tokens_refine,
                    )

                    violations = self._validate_plan_items(plan_items)

                    # Emit validation completed event (S4.T3)
                    if progress_callback:
                        progress_callback(
                            "derivation_validation_completed",
                            {
                                "pass": pass_count,
                                "violations": len(violations),
                                "passed": len(violations) == 0,
                            },
                        )

                    if not violations:
                        logger.info(
                            "Plan validation passed after %d refinement pass(es)",
                            pass_count,
                        )
                        break
                except Exception as e:
                    logger.warning("Refinement pass %d failed: %s", pass_count, str(e))
                    # Keep previous plan_items, break to avoid infinite loop
                    break

            # After max passes, use best-effort plan (don't raise error)
            if violations:
                logger.warning(
                    "Plan validation failed after %d pass(es), using best-effort plan with %d violations",
                    max_passes,
                    len(violations),
                )

        logger.info(
            "Multi-step derivation completed: %d items, %d total tokens",
            len(plan_items),
            total_tokens,
        )

        # Log pipeline completion (S5.T1)
        pipeline_duration_ms = int((time.perf_counter() - pipeline_start) * 1000)
        logger.info(
            "derivation_pipeline_completed",
            extra={
                "total_duration_ms": pipeline_duration_ms,
                "total_tokens": total_tokens,
                "item_count": len(plan_items),
                "step_tokens": step_tokens,
            },
        )

        return plan_items, total_tokens

    def _parse_flat_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        """Parse flat derivation response using TemplateEditPipeline.

        Uses file editing pattern to eliminate preamble contamination issues
        where LLMs add explanatory prose before JSON output.

        Args:
            prompt: The derivation prompt (Step 3 serialization prompt)
            provider: LLM provider name (e.g., 'anthropic', 'openai')

        Returns:
            List of normalized plan items. Empty list on validation failure.
        """
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="derivation_flat",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                "Derive plan items as an array. Each item must have:\n"
                '- id: string (e.g., "E1", "E1.S1", "E1.S1.T1")\n'
                "- title: string (concise action description)\n"
                '- item_type: "epic", "story", or "task"\n'
                "- description: string (detailed explanation)\n"
                "- acceptance_criteria: list of strings\n"
                "- dependencies: list of item IDs this depends on"
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            if len(plan_items) == 0:
                return (False, "plan_items must not be empty")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "title", "item_type", "description"):
                    if req_field not in item:
                        return (
                            False,
                            f"Item {idx} missing required field: {req_field}",
                        )
            return (True, None)

        def fallback() -> dict[str, list]:
            return {"plan_items": []}

        # Resolve Step 3 tier to get provider and model
        # Step 3 (JSON serialization) defaults to 'fast' tier
        # resolve_tier_config now uses role-aware defaults (ROLE_TIER_DEFAULTS)
        step3_tier = get_derivation_step3_tier()
        tier_config = resolve_tier_config(step3_tier, role="orchestrator")

        llm_config = {
            "provider": tier_config["provider"],
            "model": tier_config["model"],
            "reasoning_level": tier_config.get("reasoning_level", self._reasoning_level),
            "auth": tier_config.get("auth_method", "oauth"),
        }

        logger.debug(
            "Step 3 serialization using tier=%s, provider=%s, model=%s",
            step3_tier,
            llm_config["provider"],
            llm_config["model"],
        )

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=llm_config,
            allow_unchanged=False,
        )

        if metadata.get("status") in ("template_fallback", "template_error", "validation_failed"):
            logger.warning(
                "Flat derivation parsing failed after %d attempts (status=%s), using fallback",
                metadata.get("attempts", 0),
                metadata.get("status"),
            )
            return []

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return []

        return self._normalize_flat_plan_items(plan_items)

    def _normalize_flat_plan_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize flat plan items to ensure required fields and correct values.

        Sets:
        - depth based on item_type (epic=0, story=1, task=2)
        - parent_id based on hierarchy (stories→E1, tasks→parent story)
        - work_phase defaults to 'implement' if not specified
        - suggested_agent based on work_phase if not specified
        """
        normalized: list[dict[str, Any]] = []

        # First pass: collect items by type for parent resolution
        stories_by_id: dict[str, dict[str, Any]] = {}

        for item in items:
            if not isinstance(item, dict):
                continue

            item_id = item.get("id", "")
            item_type = item.get("item_type", "task")
            title = item.get("title", "Untitled")
            description = item.get("description", "") or title

            # Normalize acceptance_criteria
            acceptance = item.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                acceptance = [acceptance] if acceptance else []

            # Normalize dependencies
            deps = item.get("dependencies", [])
            if not isinstance(deps, list):
                deps = [deps] if deps else []

            # Set depth based on item_type
            if item_type == "epic":
                depth = 0
            elif item_type == "story":
                depth = 1
            else:  # task, subtask
                depth = 2

            # Set parent_id
            parent_id = item.get("parent_id")
            if item_type == "epic":
                parent_id = None
            elif item_type == "story" and not parent_id:
                parent_id = "E1"
            elif item_type == "task" and not parent_id:
                # Try to infer parent from ID (e.g., S1.T1 -> S1)
                if "." in item_id:
                    parent_id = item_id.rsplit(".", 1)[0]
                elif stories_by_id:
                    # Default to first story if can't determine
                    parent_id = next(iter(stories_by_id.keys()), "S1")
                else:
                    parent_id = "S1"

            # Validate work_phase
            raw_phase = item.get("work_phase", "implement")
            work_phase = raw_phase if raw_phase in VALID_PHASES else "implement"

            # Set suggested_agent
            raw_agent = item.get("suggested_agent")
            suggested_agent = raw_agent if raw_agent is not None else PHASE_TO_AGENT.get(work_phase)

            normalized_item = {
                "id": item_id or f"T{len(normalized) + 1}",
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": acceptance,
                "dependencies": deps,
                "parent_id": parent_id,
                "depth": depth,
                "work_phase": work_phase,
                "suggested_agent": suggested_agent,
            }

            normalized.append(normalized_item)

            if item_type == "story":
                stories_by_id[normalized_item["id"]] = normalized_item

        return normalized

    def _parse_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        """Parse hierarchical derivation response using TemplateEditPipeline.

        Uses file editing pattern to eliminate preamble contamination issues
        where LLMs add explanatory prose before JSON output.

        Args:
            prompt: The derivation prompt (hierarchical serialization prompt)
            provider: LLM provider name (e.g., 'anthropic', 'openai')

        Returns:
            List of normalized plan items. Diagnostic fallback on failure.
        """
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="derivation_hierarchical",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                "Derive plan items with full hierarchy. Each item needs:\n"
                '- id: string (e.g., "T1", "E1", "E1.S1", "E1.S1.T1")\n'
                '- item_type: "epic", "story", "task", "subtask", or "milestone"\n'
                "- title: string (concise action description)\n"
                "- description: string (detailed explanation)\n"
                "- acceptance_criteria: list of strings\n"
                "- dependencies: list of item IDs this depends on\n"
                '- work_phase: "explore", "plan", "implement", or "commit" (default: implement)'
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "item_type", "title"):
                    if req_field not in item:
                        return (
                            False,
                            f"Item {idx} missing required field: {req_field}",
                        )
            return (True, None)

        def fallback() -> dict[str, list]:
            # Return structure that will trigger diagnostic fallback
            return {"plan_items": None}  # type: ignore[dict-item]

        # Build llm_config from provider
        llm_config = {
            "provider": provider,
            "model": None,  # Use provider default
            "reasoning_level": self._reasoning_level,
            "auth": "oauth",
        }

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=llm_config,
        )

        if metadata.get("status") == "template_fallback":
            logger.warning(
                "Hierarchical derivation parsing failed after %d attempts, using diagnostic fallback",
                metadata.get("attempts", 0),
            )
            return self._create_diagnostic_fallback(
                "Pipeline parse failed",
                "Template edit parsing failed after retries",
                "",
            )

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return self._create_diagnostic_fallback(
                "Invalid plan_items type",
                f"Expected list, got {type(plan_items).__name__}",
                "",
            )

        # Apply normalization logic
        return self._normalize_hierarchical_plan_items(plan_items)

    def _normalize_hierarchical_plan_items(
        self, items: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Normalize hierarchical plan items to ensure required fields and correct values.

        Similar to _normalize_flat_plan_items but with additional validation
        for hierarchical item types (epic/story/task/subtask/milestone).
        """
        normalized: list[dict[str, Any]] = []

        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue

            # Coerce item_type to supported values
            raw_item_type = item.get("item_type", "task")
            item_type = (
                raw_item_type
                if raw_item_type in {"epic", "story", "task", "subtask", "milestone"}
                else "task"
            )

            # Extract work_phase with validation (default to "implement")
            raw_work_phase = item.get("work_phase", "implement")
            work_phase = raw_work_phase if raw_work_phase in VALID_PHASES else "implement"

            # Extract suggested_agent or derive from work_phase
            raw_suggested_agent = item.get("suggested_agent")
            suggested_agent = (
                raw_suggested_agent
                if raw_suggested_agent is not None
                else PHASE_TO_AGENT.get(work_phase)
            )

            normalized_item = {
                "id": item.get("id", f"T{i + 1}"),
                "item_type": item_type,
                "title": item.get("title", "Untitled"),
                "description": item.get("description", "") or item.get("title", "Untitled"),
                "acceptance_criteria": item.get("acceptance_criteria", []),
                "dependencies": item.get("dependencies", []),
                "work_phase": work_phase,
                "suggested_agent": suggested_agent,
            }
            normalized.append(normalized_item)

        self._log_item_count_warning(len(normalized))
        return normalized

    def _validate_plan_items(self, plan_items: list[dict[str, Any]]) -> list[str]:
        """Validate plan items for structural correctness.

        Checks:
        - Required fields present (id, item_type, title, parent_id, depth)
        - parent_id references valid item or is None for epics
        - depth matches hierarchy (epic=0, story=1, task=2)
        - No duplicate IDs

        Args:
            plan_items: List of plan items to validate

        Returns:
            List of validation error strings (empty if valid)
        """
        violations: list[str] = []
        seen_ids: set[str] = set()
        item_ids: set[str] = {item.get("id", "") for item in plan_items if item.get("id")}

        for idx, item in enumerate(plan_items):
            if not isinstance(item, dict):
                violations.append(f"Item {idx}: not a dict")
                continue

            # Check required fields
            item_id = item.get("id")
            if not item_id:
                violations.append(f"Item {idx}: missing 'id' field")
                continue

            if "item_type" not in item:
                violations.append(f"Item {item_id}: missing 'item_type' field")
            if "title" not in item:
                violations.append(f"Item {item_id}: missing 'title' field")
            if "parent_id" not in item:
                violations.append(f"Item {item_id}: missing 'parent_id' field")
            if "depth" not in item:
                violations.append(f"Item {item_id}: missing 'depth' field")

            # Check for duplicate IDs
            if item_id in seen_ids:
                violations.append(f"Item {item_id}: duplicate ID")
            seen_ids.add(item_id)

            # Validate parent_id references
            item_type = item.get("item_type")
            parent_id = item.get("parent_id")

            if item_type == "epic":
                if parent_id is not None:
                    violations.append(
                        f"Item {item_id}: epic should have parent_id=None, got '{parent_id}'"
                    )
            # story or task must have parent
            elif not parent_id:
                violations.append(f"Item {item_id}: {item_type} missing parent_id")
            elif parent_id not in item_ids:
                violations.append(f"Item {item_id}: parent_id '{parent_id}' not found in plan")

            # Validate depth matches item_type
            depth = item.get("depth")
            expected_depth = {"epic": 0, "story": 1, "task": 2, "subtask": 3}.get(
                str(item_type) if item_type else "", -1
            )
            if expected_depth >= 0 and depth != expected_depth:
                violations.append(
                    f"Item {item_id}: depth {depth} does not match {item_type} (expected {expected_depth})"
                )

        return violations

    def _resolve_reasoning_level(self, provider: str) -> str | None:
        """Resolve the effective reasoning level for derivation.

        Checks if the model supports extended thinking and returns the
        appropriate reasoning level. Falls back gracefully for unsupported
        models.

        For supported models (Claude Opus/Sonnet), uses the configured
        reasoning_level (default: "high") to enable deep reasoning.

        For unsupported models (Haiku, other providers), returns None to
        disable extended thinking and avoid API errors.

        Args:
            provider: LLM provider name

        Returns:
            Reasoning level string ("high", "standard", etc.) or None if
            extended thinking is not supported/enabled.
        """
        if not self._thinking_enabled:
            return None

        # Check model capability if provider advertises support probing
        if self._llm_invoker is None:
            return None

        try:
            llm_provider = self._llm_invoker._get_provider(provider)
            if llm_provider is not None:
                # Get model name - either from invoker default or provider default
                model = llm_provider.default_model

                # Check if model supports extended thinking
                if hasattr(llm_provider, "supports_extended_thinking"):
                    if llm_provider.supports_extended_thinking(model):
                        logger.debug(
                            "Model %s supports extended thinking, using level=%s",
                            model,
                            self._reasoning_level,
                        )
                        return self._reasoning_level
                    logger.debug(
                        "Model %s does not support extended thinking, disabling",
                        model,
                    )
                    return None
        except Exception as e:
            logger.warning(
                "Failed to check extended thinking support: %s. "
                "Falling back to configured reasoning_level=%s",
                e,
                self._reasoning_level,
            )
            # Fall through to default behavior

        # For other providers or if capability check fails, use configured level
        # This maintains backward compatibility
        return self._reasoning_level

    def _placeholder_response(self) -> str:
        """Generate placeholder response when no LLM available.

        Returns:
            Placeholder JSON response
        """
        return json.dumps(
            {
                "plan_items": [
                    {
                        "id": "T1",
                        "item_type": "task",
                        "title": "Placeholder task",
                        "description": "LLM invoker not configured - configure via obra/llm/invoker.py",
                        "acceptance_criteria": ["LLM invocation implemented"],
                        "dependencies": [],
                        "work_phase": "implement",
                    }
                ]
            }
        )

    def _parse_response_legacy(self, raw_response: str) -> list[dict[str, Any]]:
        """Parse LLM response into plan items.

        DEPRECATED: Use _parse_response_via_pipeline instead for preamble-safe parsing.
        Kept for backward compatibility with tests.

        Args:
            raw_response: Raw LLM response

        Returns:
            List of plan item dictionaries
        """
        try:
            response = raw_response.strip()

            # Check for empty response
            if not response:
                # FIX-GRACEFUL-INTERRUPT-001: Check if empty due to interrupt
                if interrupt_requested():
                    logger.info("Empty response due to user interrupt")
                    msg = "Operation interrupted by user"
                    raise KeyboardInterrupt(msg)
                logger.error("Received empty response from LLM")
                return self._create_diagnostic_fallback(
                    "Empty response",
                    "LLM returned empty content. Check LLM provider configuration and API key.",
                    raw_response,
                )

            # Handle markdown code blocks
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])
            response = response.strip()

            # Parse JSON
            data = json.loads(response)

            # Extract plan_items
            if isinstance(data, dict) and "plan_items" in data:
                items = data["plan_items"]
            elif isinstance(data, list):
                items = data
            else:
                logger.warning("Unexpected response format")
                items = [data]

            # Validate and normalize items
            normalized = []
            for i, item in enumerate(items):
                # Coerce item_type to supported values
                raw_item_type = item.get("item_type", "task")
                item_type = (
                    raw_item_type if raw_item_type in {"task", "subtask", "milestone"} else "task"
                )

                # Extract work_phase with validation (default to "implement")
                raw_work_phase = item.get("work_phase", "implement")
                work_phase = raw_work_phase if raw_work_phase in VALID_PHASES else "implement"

                # Extract suggested_agent or derive from work_phase
                raw_suggested_agent = item.get("suggested_agent")
                suggested_agent = (
                    raw_suggested_agent
                    if raw_suggested_agent is not None
                    else PHASE_TO_AGENT.get(work_phase)
                )

                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item_type,
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", "") or item.get("title", "Untitled"),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                    "work_phase": work_phase,
                    "suggested_agent": suggested_agent,
                }
                normalized.append(normalized_item)

            self._log_item_count_warning(len(normalized))

        except json.JSONDecodeError as e:
            logger.exception(
                "Failed to parse plan JSON. Raw response (first 500 chars): %s",
                raw_response[:500],
            )
            return self._create_diagnostic_fallback(
                f"JSON parse error: {e!s}",
                self._generate_parse_error_diagnostic(e, raw_response),
                raw_response,
            )
        else:
            return normalized

    # Alias for backward compatibility with tests
    _parse_response = _parse_response_legacy

    def _log_item_count_warning(self, item_count: int) -> None:
        """Log tiered warnings for large derived plans."""
        for threshold in sorted(ITEM_COUNT_WARNING_THRESHOLDS, reverse=True):
            if item_count >= threshold:
                logger.warning(
                    "Large derived plan: %s items (>= %s). Ensure items stay small, single-action, and self-contained; no hard cap applied.",
                    item_count,
                    threshold,
                )
                return

    def _create_diagnostic_fallback(
        self, error_type: str, diagnostic: str, raw_response: str
    ) -> list[dict[str, Any]]:
        """Create diagnostic fallback task with detailed information.

        Args:
            error_type: Type of error encountered
            diagnostic: Detailed diagnostic message
            raw_response: Raw LLM response for reference

        Returns:
            List containing single diagnostic task
        """
        # Truncate raw response for description (keep it manageable)
        response_preview = raw_response[:RAW_RESPONSE_PREVIEW_LIMIT] if raw_response else "(empty)"
        if len(raw_response) > RAW_RESPONSE_PREVIEW_LIMIT:
            response_preview += "... (truncated)"

        # Save full response to a debug file for investigation
        try:
            debug_dir = Path.home() / ".obra" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            debug_file = debug_dir / f"parse_error_{int(time.time())}.txt"
            debug_file.write_text(
                f"Error Type: {error_type}\n\n"
                f"Diagnostic: {diagnostic}\n\n"
                f"Raw Response:\n{raw_response}\n",
                encoding="utf-8",
            )
            logger.info(f"Full parse error details saved to: {debug_file}")
            debug_path_info = f"\n\nFull response saved to: {debug_file}"
        except Exception as e:
            logger.warning(f"Could not save debug file: {e}")
            debug_path_info = ""

        return [
            {
                "id": "T1",
                "item_type": "task",
                "title": "LLM Response Parse Error - Manual Review Required",
                "description": (
                    f"**Error**: {error_type}\n\n"
                    f"**Diagnostic**: {diagnostic}\n\n"
                    f"**Raw Response Preview**:\n```\n{response_preview}\n```"
                    f"{debug_path_info}\n\n"
                    f"**Next Steps**:\n"
                    f"1. Review the raw response in the debug file above\n"
                    f"2. Check LLM provider configuration (API key, model, endpoint)\n"
                    f"3. Verify the prompt format is compatible with the LLM\n"
                    f"4. Check for rate limiting or quota issues\n"
                    f"5. If using extended thinking, try without it\n"
                ),
                "acceptance_criteria": [
                    "Root cause identified",
                    "LLM returns valid JSON response",
                    "Plan items parse successfully",
                ],
                "dependencies": [],
                "work_phase": "explore",
            }
        ]

    def _generate_parse_error_diagnostic(
        self, error: json.JSONDecodeError, raw_response: str
    ) -> str:
        """Generate detailed diagnostic for JSON parse errors.

        Args:
            error: JSONDecodeError exception
            raw_response: Raw LLM response

        Returns:
            Diagnostic message
        """
        diagnostics = []

        # Check for common issues
        if not raw_response:
            diagnostics.append("• Response is completely empty")
        elif raw_response.strip().startswith("<"):
            diagnostics.append("• Response appears to be HTML/XML, not JSON")
        elif "error" in raw_response.lower() and "rate" in raw_response.lower():
            diagnostics.append("• Response may indicate rate limiting")
        elif "error" in raw_response.lower() and "auth" in raw_response.lower():
            diagnostics.append("• Response may indicate authentication failure")
        elif not raw_response.strip().startswith(("{", "[")):
            diagnostics.append(
                f"• Response starts with unexpected character: '{raw_response[0] if raw_response else 'N/A'}'"
            )

        # Add JSON error details
        diagnostics.append(f"• JSON error at line {error.lineno}, column {error.colno}")
        diagnostics.append(f"• Error message: {error.msg}")

        # Check response length
        if len(raw_response) > RAW_RESPONSE_WARN_LIMIT:
            diagnostics.append(
                f"• Response is very large ({len(raw_response)} chars) - may have exceeded output limits"
            )

        return "\n".join(diagnostics) if diagnostics else "No specific diagnostic available"


__all__ = [
    "EXPLORATION_LOOKBACK_MINUTES",
    "MAX_DERIVATION_DEPTH",
    "PHASE_TO_AGENT",
    "VALID_PHASES",
    "WORK_TYPES_NEEDING_EXPLORATION",
    "WORK_TYPE_KEYWORDS",
    "DerivationEngine",
    "DerivationResult",
    "detect_recent_exploration",
]
