"""Domain module loader and registry.

This module provides functions to discover and load domain modules.
Domains are auto-discovered from the obra/domains/ directory.

Architecture:
    - get_available_domains(): Lists all available domain names
    - load_domain(): Loads and caches a domain module by name
    - DomainNotFoundError: Raised when domain doesn't exist
    - DomainValidationError: Raised when domain is malformed

Related:
    - obra/domains/interface.py (protocol definition)
    - obra/domains/software/ (software development domain)
    - obra/domains/business/ (business workflow domain)
"""

import importlib
import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .interface import DomainModule

logger = logging.getLogger(__name__)

# Thread safety: Race conditions during initial load are benign since
# domain modules are immutable singletons. Worst case: duplicate load
# which is wasteful but not incorrect. No lock needed.
_domain_cache: dict[str, "DomainModule"] = {}


class DomainNotFoundError(ValueError):
    """Raised when requested domain does not exist."""


class DomainValidationError(ValueError):
    """Raised when domain module is malformed."""


def get_available_domains() -> list[str]:
    """Return list of available domain names.

    Discovers domains by scanning the obra/domains/ directory for
    subdirectories containing __init__.py files.

    Returns:
        List of domain names (lowercase)
    """
    domains_dir = Path(__file__).parent
    return sorted(
        d.name
        for d in domains_dir.iterdir()
        if d.is_dir() and not d.name.startswith("_") and (d / "__init__.py").exists()
    )


def load_domain(name: str) -> "DomainModule":
    """Load and return a domain module by name.

    Domain names are case-insensitive - 'SOFTWARE' and 'software' both
    load the software domain.

    Args:
        name: Domain name (e.g., 'software', 'business')

    Returns:
        DomainModule instance

    Raises:
        DomainNotFoundError: If domain does not exist
        DomainValidationError: If domain is malformed

    Example:
        >>> domain = load_domain("software")
        >>> print(domain.name)
        software
        >>> domain = load_domain("SOFTWARE")  # Case-insensitive
        >>> print(domain.name)
        software
    """
    # Normalize to lowercase (Finding 5: case insensitivity)
    name = name.lower()

    if name in _domain_cache:
        return _domain_cache[name]

    available = get_available_domains()
    if name not in available:
        available_str = ", ".join(available) if available else "(none)"
        msg = f"Domain '{name}' not found. Available domains: {available_str}"
        raise DomainNotFoundError(msg)

    try:
        module = importlib.import_module(f"obra.domains.{name}")
    except ImportError as e:
        msg = f"Failed to import domain '{name}': {e}"
        raise DomainValidationError(msg) from e

    # Get the domain class (convention: {Name}Domain)
    class_name = f"{name.title()}Domain"
    if not hasattr(module, class_name):
        msg = f"Domain '{name}' missing required class '{class_name}'"
        raise DomainValidationError(msg)

    domain_class = getattr(module, class_name)
    domain = domain_class()

    # Validate required methods
    required_methods = [
        "get_work_type_patterns",
        "get_quality_prompts",
        "get_file_filters",
        "get_derivation_keywords",
        "get_sizing_guidance",
    ]
    for method in required_methods:
        if not callable(getattr(domain, method, None)):
            msg = f"Domain '{name}' missing required method '{method}'"
            raise DomainValidationError(msg)

    _domain_cache[name] = domain
    logger.debug("Loaded domain '%s' from obra.domains.%s", name, name)
    return domain


def clear_domain_cache() -> None:
    """Clear the domain cache.

    Useful for testing or when domain files have been modified.
    """
    _domain_cache.clear()
    logger.debug("Domain cache cleared")
