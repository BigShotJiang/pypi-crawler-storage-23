"""
Recovery domain message templates.

Templates for authentication, session recovery, config troubleshooting,
network issues, and execution recovery guidance.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    MessageDomain,
    MessageTemplate,
    RecoveryCategory,
)

__all__ = [
    "TEMPLATES",
    "build_auth_hints",
    "build_repair_hints",
    "build_resume_hints",
    "build_state_actions",
    "get_recovery",
]

# =============================================================================
# Recovery Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Auth Category
    # -------------------------------------------------------------------------
    "recovery.auth.login": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.AUTH,
        template="Run 'obra login' to authenticate.",
        verbose_template=(
            "Run 'obra login' to authenticate with your Obra account.\n"
            "This will open a browser for authentication."
        ),
    ),
    "recovery.auth.setup": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.AUTH,
        template="Run 'obra setup' to configure your environment.",
        verbose_template=(
            "Run 'obra setup' to configure your Obra environment.\n"
            "This will guide you through initial setup."
        ),
    ),
    "recovery.auth.terms": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.AUTH,
        template="Run 'obra setup' to accept terms and continue.",
        verbose_template=(
            "Run 'obra setup' to accept terms and continue.\n"
            "You must accept the beta terms of service before using Obra."
        ),
    ),
    # -------------------------------------------------------------------------
    # Session Category
    # -------------------------------------------------------------------------
    "recovery.session.resume": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.SESSION,
        template="obra run --resume {short_id}",
        verbose_template=(
            "Resume:\n"
            "  obra run --resume {short_id}\n\n"
            "Continue (re-derive, skip completed; uses original objective):\n"
            "  obra run --continue-from {short_id}"
        ),
        placeholders=("short_id",),
    ),
    "recovery.session.continue": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.SESSION,
        template="obra run --continue-from {short_id}",
        placeholders=("short_id",),
    ),
    "recovery.session.repair": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.SESSION,
        template="obra sessions repair {short_id}",
        placeholders=("short_id",),
    ),
    "recovery.session.force_complete": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.SESSION,
        template="obra sessions force-complete {short_id}",
        placeholders=("short_id",),
    ),
    "recovery.session.reset_review": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.SESSION,
        template="obra sessions reset-review {short_id}",
        placeholders=("short_id",),
    ),
    "recovery.session.show": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.SESSION,
        template="obra status {short_id}",
        placeholders=("short_id",),
    ),
    # -------------------------------------------------------------------------
    # Config Category
    # -------------------------------------------------------------------------
    "recovery.config.config": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.CONFIG,
        template="Run 'obra config' to review configuration.",
    ),
    "recovery.config.doctor": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.CONFIG,
        template="Run 'obra doctor' to diagnose issues.",
    ),
    "recovery.config.llm_setup": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.CONFIG,
        template="Install an LLM CLI (claude, codex, or gemini) and ensure it's in PATH.",
    ),
    # -------------------------------------------------------------------------
    # Network Category
    # -------------------------------------------------------------------------
    "recovery.network.retry": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.NETWORK,
        template="Check network connection and try again.",
    ),
    "recovery.network.timeout": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.NETWORK,
        template="Request timed out. Try again or check network.",
    ),
    "recovery.network.server_error": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.NETWORK,
        template="Server error. Your work is saved.",
    ),
    # -------------------------------------------------------------------------
    # Execution Category
    # -------------------------------------------------------------------------
    "recovery.execution.breakpoint": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.EXECUTION,
        template="Session paused at breakpoint. Resume with: obra run --resume {short_id}",
        placeholders=("short_id",),
    ),
    "recovery.execution.stalled": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.EXECUTION,
        template="Session may be stalled. Try: obra sessions repair {short_id}",
        placeholders=("short_id",),
    ),
    "recovery.execution.failed": MessageTemplate(
        domain=MessageDomain.RECOVERY,
        category=RecoveryCategory.EXECUTION,
        template="Execution failed. Check logs and try: obra sessions repair {short_id}",
        placeholders=("short_id",),
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_recovery(key: str, **kwargs: Any) -> str:
    """
    Get a recovery message with automatic domain prefix.

    Args:
        key: Key without 'recovery.' prefix (e.g., 'auth.login')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"recovery.{key}", **kwargs)


def build_resume_hints(session_id: str) -> str:
    """
    Build verbose resume hints for a session.

    Args:
        session_id: Full session ID (short_id extracted automatically)

    Returns:
        Multi-line resume guidance
    """
    from obra.messages.registry import get_message

    short_id = session_id.split("-")[0] if "-" in session_id else session_id
    return get_message("recovery.session.resume", short_id=short_id, verbose=True)


def build_auth_hints() -> str:
    """
    Build verbose authentication hints.

    Returns:
        Multi-line authentication guidance
    """
    from obra.messages.registry import get_message

    return get_message("recovery.auth.login", verbose=True)


def build_repair_hints(session_id: str) -> str:
    """
    Build multi-line repair hints combining repair, force_complete, and reset_review.

    Args:
        session_id: Full session ID

    Returns:
        Multi-line repair guidance
    """
    from obra.messages.registry import get_message

    short_id = session_id.split("-")[0] if "-" in session_id else session_id
    return (
        "Recovery options:\n"
        f"  {get_message('recovery.session.repair', short_id=short_id)}\n"
        f"  {get_message('recovery.session.force_complete', short_id=short_id)}\n"
        f"  {get_message('recovery.session.reset_review', short_id=short_id)}"
    )


def build_state_actions(state: str, session_id: str) -> str | None:
    """
    Build state-specific recovery actions.

    Args:
        state: Session state (complete, escalated, failed, etc.)
        session_id: Full session ID

    Returns:
        Recovery guidance or None if no action needed
    """
    state_lower = state.lower()

    if state_lower == "complete":
        return None

    if state_lower in ("escalated", "failed"):
        return build_repair_hints(session_id)

    if state_lower == "paused":
        return build_resume_hints(session_id)

    return build_repair_hints(session_id)
