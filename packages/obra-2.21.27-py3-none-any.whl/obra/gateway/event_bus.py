"""Per-session event bus bridging synchronous orchestrator callbacks to async consumers."""

from __future__ import annotations

import asyncio
import threading
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, AsyncIterator

if TYPE_CHECKING:
    pass

from obra.api.protocol import EscalationDecision, EscalationNotice, UserDecisionChoice


class SessionEventBus:
    """Bridges sync HybridOrchestrator callbacks to async transport consumers.

    Thread-safe for producers (push_event, push_escalation called from orchestrator thread).
    Async for consumers (consume() used by SSE/WebSocket handlers).

    Args:
        session_id: Unique session identifier.
        escalation_timeout_s: Max seconds to wait for escalation decision before auto-resolving.
    """

    def __init__(self, session_id: str, escalation_timeout_s: float = 300.0) -> None:
        self.session_id = session_id
        self._escalation_timeout_s = escalation_timeout_s
        self._queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
        self._escalation_notice = threading.Event()
        self._escalation_data: EscalationDecision | None = None
        self._escalation_pending = False
        self._closed = False

    def push_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Push an event onto the queue. Thread-safe (called from orchestrator thread)."""
        if self._closed:
            return
        event = {
            "event_type": event_type,
            "payload": payload,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }
        self._queue.put_nowait(event)

    def push_escalation(self, notice: EscalationNotice) -> EscalationDecision:
        """Push escalation notice and block until client resolves or timeout.

        Called from the orchestrator thread (synchronous, blocking).

        Returns:
            EscalationDecision from client, or FORCE_COMPLETE on timeout.
        """
        # Reset state for this escalation
        self._escalation_notice.clear()
        self._escalation_data = None
        self._escalation_pending = True

        # Push escalation event for consumers
        self.push_event("escalation_notice", {
            "escalation_id": notice.escalation_id,
            "reason": notice.reason.value if hasattr(notice.reason, "value") else str(notice.reason),
            "reason_text": notice.reason_text,
            "options": notice.options,
            "blocking_issues": notice.blocking_issues,
        })

        # Block until resolved or timeout
        resolved = self._escalation_notice.wait(timeout=self._escalation_timeout_s)
        self._escalation_pending = False

        if not resolved or self._escalation_data is None:
            return EscalationDecision(
                choice=UserDecisionChoice.FORCE_COMPLETE,
                was_timeout=True,
            )

        return self._escalation_data

    def resolve_escalation(self, decision: EscalationDecision) -> bool:
        """Resolve a pending escalation with the given decision.

        Called from transport layer when client submits a decision.

        Returns:
            True if escalation was pending and resolved, False otherwise.
        """
        if not self._escalation_pending:
            return False

        self._escalation_data = decision
        self._escalation_notice.set()
        return True

    async def consume(self) -> AsyncIterator[dict[str, Any]]:
        """Yield events from the queue. Stops when bus is closed and queue is empty."""
        while True:
            event = await self._queue.get()
            if event is None:
                # Sentinel — bus closed
                break
            yield event
            if self._closed and self._queue.empty():
                break

    def close(self) -> None:
        """Close the bus. Puts sentinel to unblock consumers."""
        self._closed = True
        # Unblock any pending escalation
        if self._escalation_pending:
            self._escalation_notice.set()
        # Sentinel to unblock consume()
        self._queue.put_nowait(None)
