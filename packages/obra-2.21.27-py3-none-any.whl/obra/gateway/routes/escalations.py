"""Escalation resolution endpoint."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel

from obra.api.protocol import EscalationDecision, UserDecisionChoice
from obra.gateway.session_manager import SessionNotFoundError

router = APIRouter(prefix="/v1/sessions", tags=["escalations"])


class EscalationRequest(BaseModel):
    """Request body for resolving an escalation."""

    choice: Literal["force_complete", "continue_fixing", "skip_issues", "abandon"]
    was_timeout: bool = False


@router.post("/{session_id}/escalation")
async def resolve_escalation(
    session_id: str, body: EscalationRequest, request: Request
) -> dict[str, object]:
    """Submit a decision for a pending escalation."""
    sm = request.app.state.session_manager
    try:
        event_bus = sm.get_event_bus(session_id)
    except SessionNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    decision = EscalationDecision(
        choice=UserDecisionChoice(body.choice),
        was_timeout=body.was_timeout,
    )
    resolved = event_bus.resolve_escalation(decision)

    if not resolved:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="No pending escalation for this session",
        )

    return {"session_id": session_id, "escalation_resolved": True}
