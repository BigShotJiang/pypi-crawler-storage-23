"""Derivation utilities for Obra hybrid orchestration.

This module provides derivation analysis tools including:
- Parallelization analysis: Identify independent items for concurrent execution

Related:
    - obra/hybrid/handlers/derive.py (main derive handler)
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md
"""

from obra.hybrid.derivation.parallelization import (
    ParallelizationAnalyzer,
    ParallelizationResult,
)

# Statuses indicating template-based derivation fallback. Used by pre_filter and sizing_gate.
TEMPLATE_FALLBACK_STATUSES: set[str] = {
    "template_fallback",
    "template_error",
    "validation_failed",
}

__all__ = [
    "TEMPLATE_FALLBACK_STATUSES",
    "ParallelizationAnalyzer",
    "ParallelizationResult",
]
