"""Dependency resolver implementing the 8-step dependency resolution protocol.

Steps: DETECT -> PRESENT -> PROMPT -> EXECUTE -> VERIFY -> REPORT -> LOOP -> CONTINUE/FAIL.

The resolver orchestrates the scanner, verifier, and presenter components
and returns a structured result indicating resolution status.
"""

from __future__ import annotations

import copy
import errno
import logging
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from obra.config.loaders import get_story0_timeout
from obra.display.prompting import prompt_input
from obra.hybrid.dependency_manifest import DependencyManifest
from obra.hybrid.dependency_presenter import DependencyPresenter
from obra.hybrid.dependency_scanner import DependencyScanner
from obra.hybrid.dependency_verifier import DependencyVerifier

logger = logging.getLogger(__name__)


@dataclass
class DependencyResolverResult:
    """Outcome of the dependency resolution protocol."""

    status: str  # "complete" | "partial" | "failed"
    manifest: DependencyManifest
    blocking_unresolved: list[str] = field(default_factory=list)
    iterations_used: int = 0
    # Maps dependency_id → original LLM prereq id for cross-reference
    prereq_mapping: dict[str, str] = field(default_factory=dict)


class DependencyResolver:
    """Orchestrate the 8-step dependency resolution protocol."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        scanner: DependencyScanner,
        verifier: DependencyVerifier,
        presenter: DependencyPresenter,
        is_tty: bool,
        on_progress: Callable[[str, dict[str, Any]], None] | None,
        install_with_llm_retry: Callable[..., tuple[str, str]] | None = None,
    ) -> None:
        self._working_dir = Path(working_dir)
        self._config = config
        self._scanner = scanner
        self._verifier = verifier
        self._presenter = presenter
        self._is_tty = is_tty
        self._on_progress = on_progress
        self._install_with_llm_retry = install_with_llm_retry
        self._story0_config = dict(config.get("story0", {}))
        self._depres_config = dict(
            self._story0_config.get("dependency_resolution", {})
        )
        self._max_attempts = int(
            self._depres_config.get("max_attempts_per_dependency", 3)
        )
        self._continue_non_blocking = bool(
            self._depres_config.get("continue_on_non_blocking", True)
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve(
        self,
        prerequisites: list[dict[str, Any]],
        mode: str,
        mock_credentials: bool = False,
        cached_manifest: DependencyManifest | None = None,
    ) -> DependencyResolverResult:
        """Execute the 8-step dependency resolution protocol.

        Args:
            prerequisites: LLM-inferred prerequisite list.
            mode: One of "auto_full", "auto_safe", "guided", "off".
            mock_credentials: If True, service entries become non-blocking.
            cached_manifest: Pre-built manifest from session resume (skip detect).

        Returns:
            DependencyResolverResult with resolution status and manifest.
        """
        max_loops = int(self._depres_config.get("max_loops", 3))

        # Step 1: DETECT
        if cached_manifest is not None:
            manifest = cached_manifest
        else:
            manifest = self._step_detect(prerequisites)

        # Build prereq_mapping: dependency_id → original LLM prereq id
        prereq_mapping = self._build_prereq_mapping(prerequisites, manifest)

        # Apply mock_credentials override before loop
        if mock_credentials:
            for entry in manifest.entries:
                if entry.kind == "service":
                    entry.blocking = False

        iterations = 0
        prev_snapshot: dict[str, str] | None = None

        for iteration in range(max_loops):
            iterations = iteration + 1

            # Step 2: PRESENT
            self._step_present(manifest)

            # Step 3: PROMPT
            action = self._step_prompt(manifest, mode)
            if action == "abort":
                return DependencyResolverResult(
                    status="failed",
                    manifest=manifest,
                    blocking_unresolved=[
                        e.dependency_id
                        for e in manifest.entries
                        if e.blocking and e.status != "installed"
                    ],
                    iterations_used=iterations,
                    prereq_mapping=prereq_mapping,
                )
            if action == "rescan":
                self._verifier.verify(manifest)
                continue

            # Take a snapshot before execute for diff reporting
            prev_manifest = copy.deepcopy(manifest)

            # Step 4: EXECUTE (skipped in "off" mode)
            if mode != "off":
                self._step_execute(manifest, mode)

            # Step 5: VERIFY
            self._step_verify(manifest)

            # Step 6: REPORT
            self._step_report(prev_manifest, manifest)

            # Step 7: LOOP check
            current_snapshot = self._snapshot_statuses(manifest)
            if prev_snapshot is not None and current_snapshot == prev_snapshot:
                # Invariant 4: no change -> terminate
                break

            prev_snapshot = current_snapshot

            # Check if all blocking are resolved
            blocking_unresolved = [
                e.dependency_id
                for e in manifest.entries
                if e.blocking and e.status in ("missing", "unverified", "unexecutable")
            ]
            if not blocking_unresolved:
                # Continue for non-blocking entries with remaining attempt budget
                if self._continue_non_blocking:
                    retryable = any(
                        e.status in ("missing", "unverified", "unexecutable")
                        and getattr(e, "attempt_count", 0)
                        < getattr(e, "attempt_budget", 0)
                        for e in manifest.entries
                    )
                    if retryable:
                        continue
                break

        # Emit mission summary before classification
        self._emit_progress(
            "dependency_mission_summary",
            {
                "total_entries": len(manifest.entries),
                "installed_count": sum(
                    1 for e in manifest.entries if e.status == "installed"
                ),
                "failed_count": sum(
                    1
                    for e in manifest.entries
                    if e.status in ("missing", "unverified", "unexecutable")
                ),
                "total_attempts": sum(
                    getattr(e, "attempt_count", 0) for e in manifest.entries
                ),
                "llm_assisted_count": sum(
                    1
                    for e in manifest.entries
                    if getattr(e, "decision_source", None) == "llm"
                ),
                "entries": [
                    {
                        "name": e.name,
                        "status": e.status,
                        "attempts": getattr(e, "attempt_count", 0),
                        "terminal_reason": getattr(e, "terminal_reason", None),
                    }
                    for e in manifest.entries
                ],
            },
        )

        # Step 8: CONTINUE or FAIL
        return self._classify_result(manifest, iterations, prereq_mapping)

    # ------------------------------------------------------------------
    # Step implementations
    # ------------------------------------------------------------------

    def _step_detect(
        self,
        prerequisites: list[dict[str, Any]],
    ) -> DependencyManifest:
        """Step 1: DETECT — scan project and build manifest."""
        self._emit_progress("dependency_detect", {
            "step": "detect",
            "working_dir": str(self._working_dir),
        })
        return self._scanner.detect(prerequisites)

    def _step_present(self, manifest: DependencyManifest) -> None:
        """Step 2: PRESENT — render and display dependency table."""
        self._emit_progress("dependency_present", {
            "step": "present",
            "entry_count": len(manifest.entries),
        })
        if self._depres_config.get("present_table", True):
            table = self._presenter.render_table(manifest)
            print(table, file=sys.stderr)

    def _step_prompt(
        self,
        manifest: DependencyManifest,
        mode: str,
    ) -> str:
        """Step 3: PROMPT — determine action based on mode and user input.

        Returns:
            Action string: "execute", "rescan", or "abort".
        """
        self._emit_progress("dependency_prompt", {
            "step": "prompt",
            "mode": mode,
        })

        entry_count = len(manifest.entries)
        elevated_count = sum(1 for e in manifest.entries if e.requires_elevation)

        # Early exit: skip prompt when all dependencies are already installed
        all_installed = entry_count > 0 and all(
            e.status == "installed" for e in manifest.entries
        )
        if all_installed:
            print(
                f"  All {entry_count} dependencies satisfied — nothing to install.",
                file=sys.stderr,
            )
            self._emit_progress("prompt_skipped_reason", {
                "reason": "all_dependencies_satisfied",
                "mode": mode,
                "entry_count": entry_count,
            })
            return "execute"

        if mode == "auto_full":
            self._emit_progress("prompt_skipped_reason", {
                "reason": "auto_full_mode",
                "mode": mode,
                "entry_count": entry_count,
            })
            return "execute"

        if mode == "off":
            if not self._is_tty:
                self._emit_progress("prompt_skipped_reason", {
                    "reason": "no_tty",
                    "mode": mode,
                    "entry_count": entry_count,
                })
            else:
                self._emit_progress("prompt_displayed", {
                    "mode": mode,
                    "entry_count": entry_count,
                    "prompt_type": "off_mode",
                })
            return self._handle_off_mode_prompt(manifest)

        if mode == "auto_safe":
            if not elevated_count:
                self._emit_progress("prompt_skipped_reason", {
                    "reason": "no_elevated_commands",
                    "mode": mode,
                    "entry_count": entry_count,
                })
            elif not self._is_tty:
                self._emit_progress("prompt_skipped_reason", {
                    "reason": "no_tty",
                    "mode": mode,
                    "entry_count": entry_count,
                    "elevated_count": elevated_count,
                })
            else:
                self._emit_progress("prompt_displayed", {
                    "mode": mode,
                    "entry_count": entry_count,
                    "prompt_type": "auto_safe_elevated",
                    "elevated_count": elevated_count,
                })
            return self._handle_auto_safe_prompt(manifest)

        # mode == "guided"
        if not self._is_tty:
            self._emit_progress("prompt_skipped_reason", {
                "reason": "no_tty",
                "mode": mode,
                "entry_count": entry_count,
            })
            # Fall back to auto_safe behavior
            return self._handle_auto_safe_prompt(manifest)

        self._emit_progress("prompt_displayed", {
            "mode": mode,
            "entry_count": entry_count,
            "prompt_type": "guided_full",
        })
        return self._handle_guided_prompt(manifest)

    def _step_execute(
        self,
        manifest: DependencyManifest,
        mode: str,
    ) -> None:
        """Step 4: EXECUTE — run install commands with adaptive retry."""
        self._emit_progress("dependency_execute", {"step": "execute"})
        timeout = get_story0_timeout()

        # Backfill attempt_budget for entries not created by updated scanner
        for entry in manifest.entries:
            if getattr(entry, "attempt_budget", 0) == 0:
                entry.attempt_budget = self._max_attempts

        for entry in manifest.entries:
            if entry.status == "installed":
                continue

            # (A) Budget-exhaustion skip
            if (
                getattr(entry, 'attempt_count', 0) >= getattr(entry, 'attempt_budget', 0)
                and getattr(entry, 'attempt_budget', 0) > 0
            ):
                continue

            effective_cmd = entry.effective_command
            if effective_cmd is None:
                entry.status = "unexecutable"
                entry.detail = "no valid install command available"
                entry.execute_detail = entry.detail
                self._emit_command_result(
                    entry=entry,
                    command=None,
                    return_code=None,
                    phase_status="skipped",
                )
                continue

            # Skip elevated commands in auto_safe non-TTY
            if mode == "auto_safe" and not self._is_tty and entry.requires_elevation:
                entry.detail = (
                    "requires elevation; no interactive terminal available"
                )
                entry.execute_detail = entry.detail
                self._emit_command_result(
                    entry=entry,
                    command=effective_cmd,
                    return_code=None,
                    phase_status="skipped",
                )
                continue

            # Direct command execution (deterministic attempt)
            try:
                result = subprocess.run(
                    effective_cmd,
                    cwd=self._working_dir,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    check=False,
                )
            except FileNotFoundError:
                entry.status = "missing"
                entry.detail = f"Executable not found: {effective_cmd[0]!r}"
                entry.execute_detail = entry.detail
                # (B) Failure classification
                entry.last_failure_class = "executable_missing"
                if entry.attempt_count == 0:
                    entry.attempt_count = 1
                    entry.decision_source = "deterministic"
                self._emit_command_result(
                    entry=entry,
                    command=effective_cmd,
                    return_code=None,
                    phase_status="failed",
                )
                # (C) LLM retry after FileNotFoundError
                self._attempt_llm_retry(entry)
                continue
            except OSError as exc:
                entry.status = "missing"
                entry.detail = f"OS error running {effective_cmd[0]!r}: {exc}"
                entry.execute_detail = entry.detail
                # (B) Failure classification
                entry.last_failure_class = (
                    "permission_error" if exc.errno == errno.EACCES else "unknown"
                )
                if entry.attempt_count == 0:
                    entry.attempt_count = 1
                    entry.decision_source = "deterministic"
                self._emit_command_result(
                    entry=entry,
                    command=effective_cmd,
                    return_code=None,
                    phase_status="failed",
                )
                # (C) LLM retry after OSError
                self._attempt_llm_retry(entry)
                continue

            if result.returncode == 0:
                # (D) Success path tracking
                entry.status = "installed"
                entry.detail = result.stdout.strip() or "installed successfully"
                entry.execute_detail = entry.detail
                entry.override_command = None
                if entry.attempt_count == 0:
                    entry.attempt_count = 1
                entry.decision_source = "deterministic"
                entry.terminal_reason = "installed"
                self._emit_command_result(
                    entry=entry,
                    command=effective_cmd,
                    return_code=result.returncode,
                    phase_status="succeeded",
                )
            else:
                # (B) Failure classification for nonzero returncode
                entry.status = "missing"
                stderr = result.stderr.strip()
                entry.detail = stderr or result.stdout.strip() or "install failed"
                self._enrich_permission_error(entry, stderr)
                entry.execute_detail = entry.detail
                lower_stderr = stderr.lower()
                if "permission" in lower_stderr:
                    entry.last_failure_class = "permission_error"
                elif "not found" in lower_stderr or "no matching" in lower_stderr:
                    entry.last_failure_class = "name_mismatch"
                else:
                    entry.last_failure_class = "unknown"
                if entry.attempt_count == 0:
                    entry.attempt_count = 1
                    entry.decision_source = "deterministic"
                self._emit_command_result(
                    entry=entry,
                    command=effective_cmd,
                    return_code=result.returncode,
                    phase_status="failed",
                )
                # (C) LLM retry after failed install
                self._attempt_llm_retry(entry)

    def _attempt_llm_retry(self, entry: Any) -> None:
        """Run LLM-assisted install retry loop within the entry's attempt budget."""
        while (
            self._install_with_llm_retry is not None
            and entry.attempt_count < entry.attempt_budget
            and entry.status != "installed"
        ):
            remaining = max(0, entry.attempt_budget - entry.attempt_count)
            cb_status, cb_detail = self._install_with_llm_retry(
                entry.install_key or entry.name,
                entry.ecosystem,
                remaining,
            )
            entry.attempt_count += 1
            entry.decision_source = "llm"
            entry.detail = cb_detail

            # Status mapping: callback returns PrerequisiteStatus values
            # ('installed', 'failed', 'skipped') but resolver uses
            # ('installed', 'missing', 'unverified', 'unexecutable')
            if cb_status == "installed":
                entry.status = "installed"
                entry.terminal_reason = "installed"
            elif cb_status == "skipped":
                entry.status = "missing"
                entry.terminal_reason = "llm_skip"
                break
            else:  # 'failed' or any other
                entry.status = "missing"
                entry.last_failure_class = "unknown"

            self._emit_command_result(
                entry=entry,
                command=None,
                return_code=None,
                phase_status="failed" if entry.status != "installed" else "succeeded",
            )

        # After loop: budget exhausted without success
        if (
            entry.status != "installed"
            and entry.attempt_count >= entry.attempt_budget
            and entry.attempt_budget > 0
        ):
            entry.terminal_reason = "budget_exhausted"

    def _step_verify(self, manifest: DependencyManifest) -> None:
        """Step 5: VERIFY — update entry statuses via probes."""
        self._emit_progress("dependency_verify", {"step": "verify"})
        self._verifier.verify(manifest)
        for entry in manifest.entries:
            if entry.verify_detail:
                if (
                    entry.status != "installed"
                    and entry.execute_detail
                    and entry.execute_detail != entry.verify_detail
                ):
                    entry.detail = f"{entry.verify_detail} | execute: {entry.execute_detail}"
                else:
                    entry.detail = entry.verify_detail
            elif entry.execute_detail:
                entry.detail = entry.execute_detail

    def _step_report(
        self,
        before: DependencyManifest,
        after: DependencyManifest,
    ) -> None:
        """Step 6: REPORT — show diff between iterations."""
        self._emit_progress("dependency_report", {"step": "report"})
        diff = self._presenter.render_diff(before, after)
        print(diff, file=sys.stderr)

    # ------------------------------------------------------------------
    # Prompt handlers
    # ------------------------------------------------------------------

    def _handle_off_mode_prompt(
        self,
        manifest: DependencyManifest,
    ) -> str:
        """Off mode: present table, offer re-scan or abort only."""
        if not self._is_tty:
            self._emit_progress("prompt_response", {
                "choice": "abort",
                "reason": "no_tty",
            })
            return "abort"

        prompt = self._presenter.render_prompt(manifest, "off")
        print(prompt, file=sys.stderr, end="")

        while True:
            try:
                choice = prompt_input().strip().upper()
            except (EOFError, KeyboardInterrupt):
                self._emit_progress("prompt_response", {
                    "choice": "abort",
                    "reason": "interrupted",
                })
                return "abort"

            if choice == "R":
                self._emit_progress("prompt_response", {"choice": "rescan"})
                return "rescan"
            if choice == "X":
                self._emit_progress("prompt_response", {"choice": "abort"})
                return "abort"
            print("  Please choose [R] Re-scan or [X] Abort", file=sys.stderr)

    def _handle_auto_safe_prompt(
        self,
        manifest: DependencyManifest,
    ) -> str:
        """Auto-safe: auto-approve non-elevated, handle elevated per TTY."""
        if not self._is_tty:
            # Non-TTY: skip elevated with warning, execute non-elevated
            for entry in manifest.entries:
                if entry.requires_elevation and entry.status != "installed":
                    entry.detail = (
                        "requires elevation; no interactive terminal available"
                    )
            return "execute"

        # TTY: prompt only for elevated commands
        elevated = [
            e for e in manifest.entries
            if e.requires_elevation and e.status != "installed"
        ]
        if not elevated:
            return "execute"

        print(
            f"\n  {len(elevated)} command(s) require elevated permissions (sudo).",
            file=sys.stderr,
        )
        print("  [A] Allow all  [S] Skip elevated  [X] Abort", file=sys.stderr)
        print("> ", file=sys.stderr, end="")

        try:
            choice = prompt_input().strip().upper()
        except (EOFError, KeyboardInterrupt):
            self._emit_progress("prompt_response", {
                "choice": "abort",
                "reason": "interrupted",
            })
            return "abort"

        if choice == "X":
            self._emit_progress("prompt_response", {"choice": "abort"})
            return "abort"
        if choice == "S":
            self._emit_progress("prompt_response", {"choice": "skip_elevated"})
            for entry in elevated:
                entry.detail = "skipped elevated command per user choice"
        else:
            self._emit_progress("prompt_response", {"choice": "allow_all"})
        return "execute"

    def _handle_guided_prompt(
        self,
        manifest: DependencyManifest,
    ) -> str:
        """Guided mode: full interactive prompt."""
        prompt = self._presenter.render_prompt(manifest, "guided")
        print(prompt, file=sys.stderr, end="")

        while True:
            try:
                choice = prompt_input().strip().upper()
            except (EOFError, KeyboardInterrupt):
                self._emit_progress("prompt_response", {
                    "choice": "abort",
                    "reason": "interrupted",
                })
                return "abort"

            if choice == "A":
                self._emit_progress("prompt_response", {"choice": "auto_install"})
                return "execute"
            if choice == "E":
                self._emit_progress("prompt_response", {"choice": "edit"})
                self._handle_edit_commands(manifest)
                return "execute"
            if choice == "R":
                self._emit_progress("prompt_response", {"choice": "rescan"})
                return "rescan"
            if choice == "X":
                self._emit_progress("prompt_response", {"choice": "abort"})
                return "abort"
            print(
                "  Please choose [A] Auto-install, [E] Edit, [R] Re-scan, or [X] Abort",
                file=sys.stderr,
            )

    def _handle_edit_commands(self, manifest: DependencyManifest) -> None:
        """Interactive command editor for guided mode."""
        editable = [
            e for e in manifest.entries
            if e.status != "installed"
        ]
        if not editable:
            print("  No entries to edit.", file=sys.stderr)
            return

        for entry in editable:
            current = entry.effective_command
            cmd_display = " ".join(current) if current else "(none)"
            blocking_label = "BLOCKING" if entry.blocking else "non-blocking"

            print(
                f"\n  [{entry.name}] ({entry.ecosystem}, {blocking_label})",
                file=sys.stderr,
            )
            print(f"  Current command: {cmd_display}", file=sys.stderr)
            print(
                "  Enter new command (or press Enter to keep, 'b' to toggle blocking):",
                file=sys.stderr,
            )
            print("  > ", file=sys.stderr, end="")

            try:
                user_input = prompt_input().strip()
            except (EOFError, KeyboardInterrupt):
                continue

            if not user_input:
                continue
            if user_input.lower() == "b":
                entry.blocking = not entry.blocking
                new_label = "BLOCKING" if entry.blocking else "non-blocking"
                print(f"  -> Toggled to {new_label}", file=sys.stderr)
            else:
                entry.override_command = user_input.split()
                print(
                    f"  -> Override set: {' '.join(entry.override_command)}",
                    file=sys.stderr,
                )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _snapshot_statuses(manifest: DependencyManifest) -> dict[str, str]:
        """Capture entry statuses for loop termination check."""
        return {e.dependency_id: e.status for e in manifest.entries}

    def _emit_command_result(
        self,
        entry: Any,
        command: list[str] | None,
        return_code: int | None,
        phase_status: str,
    ) -> None:
        """Emit per-command execution outcome for Story0 dependency installs."""
        self._emit_progress(
            "dependency_command_result",
            {
                "dependency_id": entry.dependency_id,
                "name": entry.name,
                "ecosystem": entry.ecosystem,
                "kind": entry.kind,
                "status": entry.status,
                "phase_status": phase_status,
                "command": command,
                "return_code": return_code,
                "detail": entry.detail,
                "execute_detail": entry.execute_detail,
                "verify_detail": entry.verify_detail,
                "attempt_no": getattr(entry, "attempt_count", 0),
                "failure_class": getattr(entry, "last_failure_class", None),
                "decision_source": getattr(entry, "decision_source", None),
                "terminal_reason": getattr(entry, "terminal_reason", None),
                "attempt_budget": getattr(entry, "attempt_budget", 0),
            },
        )

    @staticmethod
    def _enrich_permission_error(entry: Any, stderr_or_detail: str) -> None:
        """Append sudo hint if stderr indicates a permission error."""
        if not stderr_or_detail:
            return
        lower = stderr_or_detail.lower()
        if "permission denied" in lower or "eacces" in lower:
            if "elevated permissions" not in entry.detail:
                entry.detail += (
                    " This command may require elevated permissions (sudo)."
                )

    def _build_prereq_mapping(
        self,
        prerequisites: list[dict[str, Any]],
        manifest: DependencyManifest,
    ) -> dict[str, str]:
        """Build mapping from dependency_id → original LLM prereq id.

        This enables cross-reference between scanner-generated dependency_ids
        (SHA256 hashes) and the original LLM prereq identifiers used by the
        orchestrator snapshot builder.
        """
        mapping: dict[str, str] = {}
        for entry in manifest.entries:
            if entry.source not in ("llm_inferred", "manifest+llm_inferred"):
                continue
            # Find the matching prerequisite by entry.name
            for prereq in prerequisites:
                prereq_id = str(prereq.get("id", "")).strip()
                prereq_name = str(prereq.get("name", "")).strip()
                if entry.name in (prereq_id, prereq_id.lower(), prereq_name, prereq_name.lower()):
                    mapping[entry.dependency_id] = prereq_id or prereq_name
                    break
            else:
                # Fallback: use entry.name as the mapping value
                mapping[entry.dependency_id] = entry.name
        return mapping

    def _classify_result(
        self,
        manifest: DependencyManifest,
        iterations: int,
        prereq_mapping: dict[str, str] | None = None,
    ) -> DependencyResolverResult:
        """Step 8: Classify final result as complete, partial, or failed."""
        blocking_unresolved = [
            e.dependency_id
            for e in manifest.entries
            if e.blocking and e.status in ("missing", "unverified", "unexecutable")
        ]
        non_blocking_unresolved = [
            e.dependency_id
            for e in manifest.entries
            if not e.blocking and e.status in ("missing", "unverified", "unexecutable")
        ]

        if blocking_unresolved:
            status = "failed"
        elif non_blocking_unresolved:
            status = "partial"
        else:
            status = "complete"

        return DependencyResolverResult(
            status=status,
            manifest=manifest,
            blocking_unresolved=blocking_unresolved,
            iterations_used=iterations,
            prereq_mapping=prereq_mapping or {},
        )

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Emit a progress event if callback is registered."""
        if self._on_progress is not None:
            self._on_progress(action, payload)
