# Changelog

## 0.1.0 (2025-02-25)

- Initial release
- `ModelDiffMixin`: track unsaved changes and recent updates on Django models via `__dict__` snapshotting
