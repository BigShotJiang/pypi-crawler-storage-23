ALTER TABLE tensorzero_auth_api_key
ADD COLUMN expires_at TIMESTAMPTZ;
