/// Default organization name used when no specific organization is provided
pub const DEFAULT_ORGANIZATION: &str = "default";

/// Default workspace name used when no specific workspace is provided
pub const DEFAULT_WORKSPACE: &str = "default";
