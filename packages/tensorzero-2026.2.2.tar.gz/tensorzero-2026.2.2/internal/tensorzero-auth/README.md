## Adding new `sqlx::query!` macro calls

This crate currently uses an alpha version of `sqlx`, so you'll need to update your `sqlx` binary (`cargo install sqlx-cli --version 0.9.0-alpha.1`) before running `cargo sqlx prepare --workspace -- --all-features --all-targets` from repository root.
