//! Inference queries for Postgres.
//!
//! This module implements read and write operations for inference tables in Postgres.

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde_json::Value;
use sqlx::QueryBuilder;
use sqlx::Row;
use sqlx::types::Json;
use sqlx::{PgPool, postgres::PgRow};
use std::collections::HashMap;
use uuid::Uuid;

use crate::config::snapshot::SnapshotHash;
use crate::config::{
    Config, MetricConfig, MetricConfigLevel, MetricConfigOptimize, MetricConfigType,
};
use crate::db::TimeWindow;
use crate::db::clickhouse::query_builder::{OrderByTerm, OrderDirection};
use crate::db::inferences::{
    CountByVariant, CountInferencesForFunctionParams, CountInferencesParams,
    CountInferencesWithFeedbackParams, FunctionInferenceCount, FunctionInfo,
    GetFunctionThroughputByVariantParams, InferenceMetadata, InferenceOutputSource,
    InferenceQueries, ListInferenceMetadataParams, ListInferencesParams, PaginationParams,
    VariantThroughput,
};
use crate::db::postgres::inference_filter_helpers::{MetricJoinRegistry, apply_inference_filter};
use crate::db::query_helpers::{json_double_escape_string_without_quotes, uuid_to_datetime};
use crate::endpoints::inference::InferenceParams;
use crate::endpoints::stored_inferences::v1::types::{
    FloatComparisonOperator, TimeComparisonOperator,
};
use crate::error::{Error, ErrorDetails};
use crate::function::FunctionConfigType;
use crate::inference::types::ContentBlockChatOutput;
use crate::inference::types::JsonInferenceOutput;
use crate::inference::types::extra_body::UnfilteredInferenceExtraBody;
use crate::inference::types::stored_input::StoredInput;
use crate::inference::types::{
    ChatInferenceDatabaseInsert, FunctionType, JsonInferenceDatabaseInsert,
};
use crate::stored_inference::{
    StoredChatInferenceDatabase, StoredInferenceDatabase, StoredJsonInference,
};
use crate::tool::ToolCallConfigDatabaseInsert;
use crate::tool::config::AllowedTools;
use crate::tool::types::{ProviderTool, Tool};
use crate::tool::wire::ToolChoice;

use super::PostgresConnectionInfo;

impl FloatComparisonOperator {
    pub(super) fn to_postgres_operator(self) -> &'static str {
        match self {
            FloatComparisonOperator::LessThan => "<",
            FloatComparisonOperator::LessThanOrEqual => "<=",
            FloatComparisonOperator::Equal => "=",
            FloatComparisonOperator::GreaterThan => ">",
            FloatComparisonOperator::GreaterThanOrEqual => ">=",
            FloatComparisonOperator::NotEqual => "!=",
        }
    }
}

impl TimeComparisonOperator {
    pub(super) fn to_postgres_operator(self) -> &'static str {
        match self {
            TimeComparisonOperator::LessThan => "<",
            TimeComparisonOperator::LessThanOrEqual => "<=",
            TimeComparisonOperator::Equal => "=",
            TimeComparisonOperator::GreaterThan => ">",
            TimeComparisonOperator::GreaterThanOrEqual => ">=",
            TimeComparisonOperator::NotEqual => "!=",
        }
    }
}

#[async_trait]
impl InferenceQueries for PostgresConnectionInfo {
    // ===== Read methods =====

    async fn list_inferences(
        &self,
        config: &Config,
        params: &ListInferencesParams<'_>,
    ) -> Result<Vec<StoredInferenceDatabase>, Error> {
        params.validate_pagination()?;

        let pool = self.get_pool_result()?;

        // Determine which table(s) to query based on function_name
        let function_config_type = match params.function_name {
            Some(fn_name) => Some(config.get_function(fn_name)?.config_type()),
            None => None,
        };

        let mut results = match function_config_type {
            Some(FunctionConfigType::Chat) => {
                // Single-table query for chat inferences
                let chat_results =
                    query_chat_inferences(pool, config, params, params.limit, params.offset)
                        .await?;
                chat_results
                    .into_iter()
                    .map(StoredInferenceDatabase::Chat)
                    .collect()
            }
            Some(FunctionConfigType::Json) => {
                // Single-table query for json inferences
                let json_results =
                    query_json_inferences(pool, config, params, params.limit, params.offset)
                        .await?;
                json_results
                    .into_iter()
                    .map(StoredInferenceDatabase::Json)
                    .collect()
            }
            None => {
                // Multi-table query using UNION ALL
                query_inferences_union(pool, config, params).await?
            }
        };

        // Reverse the list for "After" pagination, we queried with inverted ordering to get results after the cursor,
        // but we want to return them in original order (most recent first).
        if matches!(params.pagination, Some(PaginationParams::After { .. })) {
            results.reverse();
        }

        Ok(results)
    }

    async fn list_inference_metadata(
        &self,
        params: &ListInferenceMetadataParams,
    ) -> Result<Vec<InferenceMetadata>, Error> {
        let pool = self.get_pool_result()?;

        // Determine ORDER BY direction based on pagination
        let order_direction = match &params.pagination {
            Some(PaginationParams::After { .. }) => "ASC",
            Some(PaginationParams::Before { .. }) | None => "DESC",
        };

        let mut query_builder = build_inference_metadata_query(params, order_direction);

        let mut results: Vec<InferenceMetadata> =
            query_builder.build_query_as().fetch_all(pool).await?;

        // Reverse for "After" pagination
        if matches!(params.pagination, Some(PaginationParams::After { .. })) {
            results.reverse();
        }

        Ok(results)
    }

    async fn count_inferences(
        &self,
        config: &Config,
        params: &CountInferencesParams<'_>,
    ) -> Result<u64, Error> {
        let pool = self.get_pool_result()?;

        // Determine which table(s) to query based on function_name
        // If the function doesn't exist in config, query both tables since we don't know
        let function_config_type = match params.function_name {
            Some(fn_name) => config.get_function(fn_name).ok().map(|f| f.config_type()),
            None => None,
        };

        let count = match function_config_type {
            Some(FunctionConfigType::Chat) => {
                count_single_table_inferences(
                    pool,
                    config,
                    params,
                    "tensorzero.chat_inferences",
                    "tensorzero.chat_inference_data",
                )
                .await?
            }
            Some(FunctionConfigType::Json) => {
                count_single_table_inferences(
                    pool,
                    config,
                    params,
                    "tensorzero.json_inferences",
                    "tensorzero.json_inference_data",
                )
                .await?
            }
            None => {
                // Use UNION ALL to count both tables in a single query
                count_inferences_union(pool, config, params).await?
            }
        };

        Ok(count)
    }

    async fn get_function_info(
        &self,
        target_id: &Uuid,
        level: MetricConfigLevel,
    ) -> Result<Option<FunctionInfo>, Error> {
        let pool = self.get_pool_result()?;

        // Use a single UNION query to search both tables
        let mut query_builder: QueryBuilder<sqlx::Postgres> = match level {
            MetricConfigLevel::Inference => {
                let mut qb: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
                    r"
                    SELECT
                        function_name,
                        variant_name,
                        episode_id,
                        'chat' as function_type
                    FROM tensorzero.chat_inferences
                    WHERE id = ",
                );
                qb.push_bind(*target_id);
                qb.push(
                    r"
                    UNION ALL
                    SELECT
                        function_name,
                        variant_name,
                        episode_id,
                        'json' as function_type
                    FROM tensorzero.json_inferences
                    WHERE id = ",
                );
                qb.push_bind(*target_id);
                qb.push(" LIMIT 1");
                qb
            }
            MetricConfigLevel::Episode => {
                let mut qb: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
                    r"
                    SELECT
                        function_name,
                        variant_name,
                        episode_id,
                        function_type
                    FROM (
                        SELECT function_name, variant_name, episode_id, created_at, 'chat' as function_type
                        FROM tensorzero.chat_inferences
                        WHERE episode_id = ",
                );
                qb.push_bind(*target_id);
                qb.push(
                    r"
                        UNION ALL
                        SELECT function_name, variant_name, episode_id, created_at, 'json' as function_type
                        FROM tensorzero.json_inferences
                        WHERE episode_id = ",
                );
                qb.push_bind(*target_id);
                qb.push(
                    r"
                    ) combined
                    ORDER BY created_at DESC
                    LIMIT 1",
                );
                qb
            }
        };

        let result: Option<FunctionInfo> =
            query_builder.build_query_as().fetch_optional(pool).await?;

        Ok(result)
    }

    async fn get_chat_inference_tool_params(
        &self,
        function_name: &str,
        inference_id: Uuid,
    ) -> Result<Option<ToolCallConfigDatabaseInsert>, Error> {
        let pool = self.get_pool_result()?;

        let result = sqlx::query!(
            r"
            SELECT
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls
            FROM tensorzero.chat_inferences i
            INNER JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE i.function_name = $1 AND i.id = $2
            LIMIT 1
            ",
            function_name,
            inference_id
        )
        .fetch_optional(pool)
        .await?;

        match result {
            Some(row) => {
                // Deserialize the tool params from the stored JSON columns
                let dynamic_tools: Vec<Tool> = serde_json::from_value(row.dynamic_tools)?;
                let dynamic_provider_tools: Vec<ProviderTool> =
                    serde_json::from_value(row.dynamic_provider_tools)?;
                let allowed_tools: Option<AllowedTools> =
                    row.allowed_tools.map(serde_json::from_value).transpose()?;
                let tool_choice: Option<ToolChoice> =
                    row.tool_choice.map(serde_json::from_value).transpose()?;

                let tool_params = ToolCallConfigDatabaseInsert::from_stored_values(
                    dynamic_tools,
                    dynamic_provider_tools,
                    allowed_tools,
                    tool_choice,
                    row.parallel_tool_calls,
                );
                Ok(tool_params)
            }
            None => Ok(None),
        }
    }

    async fn get_json_inference_output_schema(
        &self,
        function_name: &str,
        inference_id: Uuid,
    ) -> Result<Option<Value>, Error> {
        let pool = self.get_pool_result()?;

        let result = sqlx::query!(
            r"
            SELECT io.output_schema
            FROM tensorzero.json_inferences i
            INNER JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE i.function_name = $1 AND i.id = $2
            LIMIT 1
            ",
            function_name,
            inference_id
        )
        .fetch_optional(pool)
        .await?;

        Ok(result.map(|r| r.output_schema))
    }

    // TODO(#5691): Change this to return either a Value or a typed output.
    async fn get_inference_output(
        &self,
        function_info: &FunctionInfo,
        inference_id: Uuid,
    ) -> Result<Option<String>, Error> {
        let pool = self.get_pool_result()?;

        match function_info.function_type {
            FunctionType::Chat => {
                let result = sqlx::query!(
                    r"
                    SELECT io.output
                    FROM tensorzero.chat_inferences i
                    INNER JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
                    WHERE i.id = $1
                      AND i.episode_id = $2
                      AND i.function_name = $3
                      AND i.variant_name = $4
                    LIMIT 1
                    ",
                    inference_id,
                    function_info.episode_id,
                    function_info.function_name,
                    function_info.variant_name
                )
                .fetch_optional(pool)
                .await?;

                // Convert JSONB to string
                Ok(result.map(|r| r.output.to_string()))
            }
            FunctionType::Json => {
                let result = sqlx::query!(
                    r"
                    SELECT io.output
                    FROM tensorzero.json_inferences i
                    INNER JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at
                    WHERE i.id = $1
                      AND i.episode_id = $2
                      AND i.function_name = $3
                      AND i.variant_name = $4
                    LIMIT 1
                    ",
                    inference_id,
                    function_info.episode_id,
                    function_info.function_name,
                    function_info.variant_name
                )
                .fetch_optional(pool)
                .await?;

                // Convert JSONB to string
                Ok(result.map(|r| r.output.to_string()))
            }
        }
    }

    // ===== Write methods =====

    async fn insert_chat_inferences(
        &self,
        rows: &[ChatInferenceDatabaseInsert],
    ) -> Result<(), Error> {
        if rows.is_empty() {
            return Ok(());
        }

        if let Some(batch_sender) = self.batch_sender() {
            return batch_sender.send_chat_inferences(rows);
        }

        let pool = self.get_pool_result()?;
        let mut metadata_qb = build_insert_chat_inferences_query(rows)?;
        metadata_qb.build().execute(pool).await?;
        let mut io_qb = build_insert_chat_inference_data_query(rows)?;
        io_qb.build().execute(pool).await?;

        Ok(())
    }

    async fn insert_json_inferences(
        &self,
        rows: &[JsonInferenceDatabaseInsert],
    ) -> Result<(), Error> {
        if rows.is_empty() {
            return Ok(());
        }

        if let Some(batch_sender) = self.batch_sender() {
            return batch_sender.send_json_inferences(rows);
        }

        let pool = self.get_pool_result()?;
        let mut metadata_qb = build_insert_json_inferences_query(rows)?;
        metadata_qb.build().execute(pool).await?;
        let mut io_qb = build_insert_json_inference_data_query(rows)?;
        io_qb.build().execute(pool).await?;

        Ok(())
    }

    // ===== Inference count methods (merged from InferenceCountQueries trait) =====

    async fn count_inferences_by_variant(
        &self,
        params: CountInferencesForFunctionParams<'_>,
    ) -> Result<Vec<CountByVariant>, Error> {
        let pool = self.get_pool_result()?;
        count_by_variant_impl(
            pool,
            params.function_type,
            params.function_name,
            params.variant_name,
        )
        .await
        .map_err(Error::from)
    }

    async fn count_inferences_with_feedback(
        &self,
        params: CountInferencesWithFeedbackParams<'_>,
    ) -> Result<u64, Error> {
        let pool = self.get_pool_result()?;
        count_inferences_with_metric_feedback(
            pool,
            params.function_name,
            params.function_type,
            params.metric_name,
            params.metric_config,
            params.metric_threshold,
        )
        .await
    }

    async fn get_function_throughput_by_variant(
        &self,
        params: GetFunctionThroughputByVariantParams<'_>,
    ) -> Result<Vec<VariantThroughput>, Error> {
        let pool = self.get_pool_result()?;
        throughput_by_variant_impl(
            pool,
            params.function_name,
            params.time_window,
            params.max_periods,
        )
        .await
    }

    async fn list_functions_with_inference_count(
        &self,
    ) -> Result<Vec<FunctionInferenceCount>, Error> {
        let pool = self.get_pool_result()?;

        // Query the pre-aggregated rollup table instead of scanning chat_inferences/json_inferences.
        // MAX(minute) gives minute-level precision (vs. exact timestamp), acceptable for dashboard listing.
        // The rollup table is refreshed every 5 minutes by pg_cron; data may lag up to ~15 minutes.
        let rows = sqlx::query(
            r"
            SELECT
                function_name,
                MAX(minute) AS last_inference_timestamp,
                SUM(inference_count)::INT AS inference_count
            FROM tensorzero.inference_by_function_statistics
            GROUP BY function_name
            ORDER BY last_inference_timestamp DESC
            ",
        )
        .fetch_all(pool)
        .await
        .map_err(Error::from)?;

        let results = rows
            .into_iter()
            .map(|row| {
                let function_name: String = row.get("function_name");
                let last_inference_timestamp: DateTime<Utc> = row.get("last_inference_timestamp");
                let inference_count: i32 = row.get("inference_count");
                FunctionInferenceCount {
                    function_name,
                    last_inference_timestamp,
                    inference_count: inference_count as u32,
                }
            })
            .collect();

        Ok(results)
    }
}

// ===== Query builder functions for insert operations =====

/// Builds a query to insert chat inference metadata.
pub(super) fn build_insert_chat_inferences_query(
    rows: &[ChatInferenceDatabaseInsert],
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    // Pre-compute timestamps to propagate errors before entering push_values
    let timestamps: Vec<DateTime<Utc>> = rows
        .iter()
        .map(|row| uuid_to_datetime(row.id))
        .collect::<Result<_, _>>()?;

    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
        r"
        INSERT INTO tensorzero.chat_inferences (
            id, function_name, variant_name, episode_id,
            processing_time_ms, ttft_ms, tags,
            snapshot_hash, created_at
        ) ",
    );

    query_builder.push_values(rows.iter().zip(&timestamps), |mut b, (row, created_at)| {
        b.push_bind(row.id)
            .push_bind(&row.function_name)
            .push_bind(&row.variant_name)
            .push_bind(row.episode_id)
            .push_bind(row.processing_time_ms.map(|v| v as i32))
            .push_bind(row.ttft_ms.map(|v| v as i32))
            .push_bind(Json::from(&row.tags))
            .push_bind(row.snapshot_hash.as_ref())
            .push_bind(created_at);
    });

    Ok(query_builder)
}

/// Builds a query to insert chat inference IO data.
pub(super) fn build_insert_chat_inference_data_query(
    rows: &[ChatInferenceDatabaseInsert],
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    let timestamps: Vec<DateTime<Utc>> = rows
        .iter()
        .map(|row| uuid_to_datetime(row.id))
        .collect::<Result<_, _>>()?;

    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
        r"
        INSERT INTO tensorzero.chat_inference_data (
            id, input, output, inference_params,
            extra_body, dynamic_tools, dynamic_provider_tools,
            allowed_tools, tool_choice, parallel_tool_calls, created_at
        ) ",
    );

    query_builder.push_values(rows.iter().zip(&timestamps), |mut b, (row, created_at)| {
        let tool_params_ref = row.tool_params.as_ref();
        let empty_tools: Vec<Tool> = vec![];
        let empty_provider_tools: Vec<ProviderTool> = vec![];

        b.push_bind(row.id)
            .push_bind(Json::from(&row.input))
            .push_bind(Json::from(&row.output))
            .push_bind(Json::from(&row.inference_params))
            .push_bind(Json::from(&row.extra_body))
            .push_bind(Json::from(
                tool_params_ref
                    .map(|tp| &tp.dynamic_tools)
                    .unwrap_or(&empty_tools),
            ))
            .push_bind(Json::from(
                tool_params_ref
                    .map(|tp| &tp.dynamic_provider_tools)
                    .unwrap_or(&empty_provider_tools),
            ))
            .push_bind(tool_params_ref.map(|tp| Json::from(&tp.allowed_tools)))
            .push_bind(tool_params_ref.map(|tp| Json::from(&tp.tool_choice)))
            .push_bind(tool_params_ref.and_then(|tp| tp.parallel_tool_calls))
            .push_bind(created_at);
    });

    Ok(query_builder)
}

/// Builds a query to insert json inference metadata.
pub(super) fn build_insert_json_inferences_query(
    rows: &[JsonInferenceDatabaseInsert],
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    // Pre-compute timestamps to propagate errors before entering push_values
    let timestamps: Vec<DateTime<Utc>> = rows
        .iter()
        .map(|row| uuid_to_datetime(row.id))
        .collect::<Result<_, _>>()?;

    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
        r"
        INSERT INTO tensorzero.json_inferences (
            id, function_name, variant_name, episode_id,
            processing_time_ms, ttft_ms, tags, snapshot_hash, created_at
        ) ",
    );

    query_builder.push_values(rows.iter().zip(&timestamps), |mut b, (row, created_at)| {
        b.push_bind(row.id)
            .push_bind(&row.function_name)
            .push_bind(&row.variant_name)
            .push_bind(row.episode_id)
            .push_bind(row.processing_time_ms.map(|v| v as i32))
            .push_bind(row.ttft_ms.map(|v| v as i32))
            .push_bind(Json::from(&row.tags))
            .push_bind(row.snapshot_hash.as_ref())
            .push_bind(created_at);
    });

    Ok(query_builder)
}

/// Builds a query to insert json inference IO data.
pub(super) fn build_insert_json_inference_data_query(
    rows: &[JsonInferenceDatabaseInsert],
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    let timestamps: Vec<DateTime<Utc>> = rows
        .iter()
        .map(|row| uuid_to_datetime(row.id))
        .collect::<Result<_, _>>()?;

    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
        r"
        INSERT INTO tensorzero.json_inference_data (
            id, input, output, output_schema, inference_params,
            extra_body, auxiliary_content, created_at
        ) ",
    );

    query_builder.push_values(rows.iter().zip(&timestamps), |mut b, (row, created_at)| {
        b.push_bind(row.id)
            .push_bind(Json::from(&row.input))
            .push_bind(Json::from(&row.output))
            .push_bind(&row.output_schema)
            .push_bind(Json::from(&row.inference_params))
            .push_bind(Json::from(&row.extra_body))
            .push_bind(Json::from(&row.auxiliary_content))
            .push_bind(created_at);
    });

    Ok(query_builder)
}

// ===== Helper types =====

/// A single ORDER BY term.
enum OrderByTermResolved {
    /// A static column expression like "i.created_at" or "metric_alias.value".
    Column(String),
}

/// Result of building ORDER BY clause, including any required JOINs.
struct OrderByResult {
    /// Validated ORDER BY terms with their direction (e.g., "DESC NULLS LAST").
    terms: Vec<(OrderByTermResolved, String)>,
    /// The id tie-breaker clause, e.g., "i.id DESC".
    id_tiebreaker: String,
    /// JOIN clauses needed for metric ordering.
    metric_joins: String,
}

impl OrderByResult {
    /// Pushes the ORDER BY clause onto the query builder.
    fn push_order_by(&self, qb: &mut QueryBuilder<sqlx::Postgres>) {
        qb.push(" ORDER BY ");
        for (i, (term, direction)) in self.terms.iter().enumerate() {
            if i > 0 {
                qb.push(", ");
            }
            match term {
                OrderByTermResolved::Column(expr) => {
                    qb.push(format!("{expr} {direction}"));
                }
            }
        }
        if !self.terms.is_empty() {
            qb.push(", ");
        }
        qb.push(&self.id_tiebreaker);
    }
}

/// Builds the ORDER BY clause based on params.
/// For "After" pagination, we invert the direction since we'll reverse results in memory.
/// Returns both the ORDER BY terms and any required metric JOINs.
fn build_order_by_clause(
    params: &ListInferencesParams<'_>,
    config: &Config,
) -> Result<OrderByResult, Error> {
    let should_invert_directions =
        matches!(params.pagination, Some(PaginationParams::After { .. }));

    // Build id tie-breaker direction
    let id_direction = if let Some(ref pagination) = params.pagination {
        match pagination {
            PaginationParams::After { .. } => OrderDirection::Asc,
            PaginationParams::Before { .. } => OrderDirection::Desc,
        }
    } else {
        OrderDirection::Desc // Default: most recent first
    };

    let mut terms = Vec::new();
    let mut join_registry = MetricJoinRegistry::new();

    // Add user-specified ordering if present
    if let Some(order_by) = params.order_by {
        for o in order_by {
            let term = match &o.term {
                OrderByTerm::Timestamp => OrderByTermResolved::Column("i.created_at".to_string()),
                OrderByTerm::Metric { name } => {
                    let metric_config = config.metrics.get(name).ok_or_else(|| {
                        Error::new(ErrorDetails::InvalidMetricName {
                            metric_name: name.clone(),
                        })
                    })?;

                    let alias = join_registry.register_metric_join(
                        name,
                        metric_config.r#type,
                        metric_config.level.clone(),
                    );
                    OrderByTermResolved::Column(format!("{alias}.value"))
                }
                // TODO(#6441): Implement proper search relevance ordering for Postgres.
                OrderByTerm::SearchRelevance => {
                    // Validate that search_query_experimental is provided
                    if params.search_query_experimental.is_none() {
                        return Err(Error::new(ErrorDetails::InvalidRequest {
                            message: "ORDER BY search_relevance requires search_query_experimental to be provided".to_string(),
                        }));
                    }
                    OrderByTermResolved::Column("i.id".to_string())
                }
            };

            let effective_direction = if should_invert_directions {
                o.direction.inverted()
            } else {
                o.direction
            };

            terms.push((
                term,
                format!(
                    "{} NULLS LAST",
                    effective_direction.to_clickhouse_direction()
                ),
            ));
        }
    }

    Ok(OrderByResult {
        terms,
        id_tiebreaker: format!("i.id {}", id_direction.to_clickhouse_direction()),
        metric_joins: join_registry.get_joins_sql(),
    })
}

// ===== Query builder functions for list_inference_metadata =====

/// Builds the query for listing inference metadata (UNION ALL of chat and json tables).
/// The `order_direction` parameter should be "ASC" for After pagination, "DESC" otherwise.
fn build_inference_metadata_query(
    params: &ListInferenceMetadataParams,
    order_direction: &str,
) -> QueryBuilder<sqlx::Postgres> {
    let order_by_clause = format!("ORDER BY id {order_direction}");

    let mut qb = QueryBuilder::new(
        r"
        SELECT * FROM (
            (SELECT
                'chat'::text as function_type,
                id,
                function_name,
                variant_name,
                episode_id,
                snapshot_hash
            FROM tensorzero.chat_inferences
            WHERE 1=1",
    );

    // Add chat filters
    apply_metadata_filters(&mut qb, params);

    qb.push(" ");
    qb.push(&order_by_clause);
    qb.push(" LIMIT ");
    qb.push_bind(params.limit as i64);

    // UNION ALL with json subquery
    qb.push(
        r")
            UNION ALL
            (SELECT
                'json'::text as function_type,
                id,
                function_name,
                variant_name,
                episode_id,
                snapshot_hash
            FROM tensorzero.json_inferences
            WHERE 1=1",
    );

    // Add json filters
    apply_metadata_filters(&mut qb, params);

    qb.push(" ");
    qb.push(&order_by_clause);
    qb.push(" LIMIT ");
    qb.push_bind(params.limit as i64);

    // Close subqueries and add outer ORDER BY + LIMIT
    qb.push(
        ")
        ) AS combined
        ",
    );
    qb.push(&order_by_clause);
    qb.push(" LIMIT ");
    qb.push_bind(params.limit as i64);

    qb
}

// ===== Helper functions for chat inference queries =====

/// Builds the query for listing chat inferences.
/// This is separated from execution to allow unit testing of the generated SQL.
fn build_chat_inferences_query(
    config: &Config,
    params: &ListInferencesParams<'_>,
    limit: u32,
    offset: u32,
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    // Build ORDER BY clause first to get any required metric JOINs
    let order_by_result = build_order_by_clause(params, config)?;

    // Build the SELECT clause based on output_source
    let output_select = match params.output_source {
        InferenceOutputSource::None | InferenceOutputSource::Inference => {
            "io.output, NULL::jsonb as dispreferred_output"
        }
        InferenceOutputSource::Demonstration => {
            "demo_f.value AS output, io.output as dispreferred_output"
        }
    };

    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(format!(
        r"
        SELECT
            i.id,
            i.function_name,
            i.variant_name,
            i.episode_id,
            i.created_at as timestamp,
            io.input,
            {output_select},
            io.dynamic_tools,
            io.dynamic_provider_tools,
            io.allowed_tools,
            io.tool_choice,
            io.parallel_tool_calls,
            i.tags,
            io.extra_body,
            io.inference_params,
            i.processing_time_ms,
            i.ttft_ms,
            i.snapshot_hash
        FROM tensorzero.chat_inferences i
        LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
        "
    ));

    // Add JOIN for demonstration output source
    if params.output_source == InferenceOutputSource::Demonstration {
        query_builder.push(
            r"
            JOIN (
                SELECT DISTINCT ON (inference_id)
                    inference_id,
                    value
                FROM tensorzero.demonstration_feedback
                ORDER BY inference_id, created_at DESC
            ) AS demo_f ON i.id = demo_f.inference_id
            ",
        );
    }

    // Add metric JOINs for ORDER BY
    if !order_by_result.metric_joins.is_empty() {
        query_builder.push(&order_by_result.metric_joins);
    }

    query_builder.push(" WHERE TRUE");

    // Add filters
    if let Some(function_name) = params.function_name {
        query_builder.push(" AND i.function_name = ");
        query_builder.push_bind(function_name);
    }

    if let Some(variant_name) = params.variant_name {
        query_builder.push(" AND i.variant_name = ");
        query_builder.push_bind(variant_name);
    }

    if let Some(episode_id) = params.episode_id {
        query_builder.push(" AND i.episode_id = ");
        query_builder.push_bind(*episode_id);
    }

    if let Some(ids) = params.ids {
        query_builder.push(" AND i.id = ANY(");
        query_builder.push_bind(ids);
        query_builder.push(")");
    }

    // Apply inference filter (e.g., DemonstrationFeedback, metric filters, etc.)
    apply_inference_filter(&mut query_builder, params.filters, config)?;

    if let Some(search_query) = params.search_query_experimental {
        let json_escaped_query = json_double_escape_string_without_quotes(search_query)?;
        let search_pattern = format!("%{json_escaped_query}%");
        query_builder.push(" AND (io.input::text ILIKE ");
        query_builder.push_bind(search_pattern.clone());
        query_builder.push(" OR io.output::text ILIKE ");
        query_builder.push_bind(search_pattern);
        query_builder.push(")");
    }

    // Handle pagination cursor
    match &params.pagination {
        Some(PaginationParams::Before { id }) => {
            query_builder.push(" AND i.id < ");
            query_builder.push_bind(*id);
        }
        Some(PaginationParams::After { id }) => {
            query_builder.push(" AND i.id > ");
            query_builder.push_bind(*id);
        }
        None => {}
    }

    // Add ORDER BY clause
    order_by_result.push_order_by(&mut query_builder);

    // Add LIMIT
    query_builder.push(" LIMIT ");
    query_builder.push_bind(limit as i64);

    // Add OFFSET
    query_builder.push(" OFFSET ");
    query_builder.push_bind(offset as i64);

    Ok(query_builder)
}

async fn query_chat_inferences(
    pool: &sqlx::PgPool,
    config: &Config,
    params: &ListInferencesParams<'_>,
    limit: u32,
    offset: u32,
) -> Result<Vec<StoredChatInferenceDatabase>, Error> {
    let mut query_builder = build_chat_inferences_query(config, params, limit, offset)?;

    let results: Vec<StoredChatInferenceDatabase> =
        query_builder.build_query_as().fetch_all(pool).await?;

    Ok(results)
}

/// Builds the query for listing JSON inferences.
/// This is separated from execution to allow unit testing of the generated SQL.
fn build_json_inferences_query(
    config: &Config,
    params: &ListInferencesParams<'_>,
    limit: u32,
    offset: u32,
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    // Build ORDER BY clause first to get any required metric JOINs
    let order_by_result = build_order_by_clause(params, config)?;

    // Build the SELECT clause based on output_source
    let output_select = match params.output_source {
        InferenceOutputSource::None | InferenceOutputSource::Inference => {
            "io.output, NULL::jsonb as dispreferred_output"
        }
        InferenceOutputSource::Demonstration => {
            "demo_f.value AS output, io.output as dispreferred_output"
        }
    };

    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(format!(
        r"
        SELECT
            i.id,
            i.function_name,
            i.variant_name,
            i.episode_id,
            i.created_at as timestamp,
            io.input,
            {output_select},
            io.output_schema,
            i.tags,
            io.extra_body,
            io.inference_params,
            i.processing_time_ms,
            i.ttft_ms,
            i.snapshot_hash
        FROM tensorzero.json_inferences i
        LEFT JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at
        "
    ));

    // Add JOIN for demonstration output source
    if params.output_source == InferenceOutputSource::Demonstration {
        query_builder.push(
            r"
            JOIN (
                SELECT DISTINCT ON (inference_id)
                    inference_id,
                    value
                FROM tensorzero.demonstration_feedback
                ORDER BY inference_id, created_at DESC
            ) AS demo_f ON i.id = demo_f.inference_id
            ",
        );
    }

    // Add metric JOINs for ORDER BY
    if !order_by_result.metric_joins.is_empty() {
        query_builder.push(&order_by_result.metric_joins);
    }

    query_builder.push(" WHERE TRUE");

    // Add filters
    if let Some(function_name) = params.function_name {
        query_builder.push(" AND i.function_name = ");
        query_builder.push_bind(function_name);
    }

    if let Some(variant_name) = params.variant_name {
        query_builder.push(" AND i.variant_name = ");
        query_builder.push_bind(variant_name);
    }

    if let Some(episode_id) = params.episode_id {
        query_builder.push(" AND i.episode_id = ");
        query_builder.push_bind(*episode_id);
    }

    if let Some(ids) = params.ids {
        query_builder.push(" AND i.id = ANY(");
        query_builder.push_bind(ids);
        query_builder.push(")");
    }

    // Apply inference filter (e.g., DemonstrationFeedback, metric filters, etc.)
    apply_inference_filter(&mut query_builder, params.filters, config)?;

    if let Some(search_query) = params.search_query_experimental {
        let json_escaped_query = json_double_escape_string_without_quotes(search_query)?;
        let search_pattern = format!("%{json_escaped_query}%");
        query_builder.push(" AND (io.input::text ILIKE ");
        query_builder.push_bind(search_pattern.clone());
        query_builder.push(" OR io.output::text ILIKE ");
        query_builder.push_bind(search_pattern);
        query_builder.push(")");
    }

    // Handle pagination cursor
    match &params.pagination {
        Some(PaginationParams::Before { id }) => {
            query_builder.push(" AND i.id < ");
            query_builder.push_bind(*id);
        }
        Some(PaginationParams::After { id }) => {
            query_builder.push(" AND i.id > ");
            query_builder.push_bind(*id);
        }
        None => {}
    }

    // Add ORDER BY clause
    order_by_result.push_order_by(&mut query_builder);

    // Add LIMIT
    query_builder.push(" LIMIT ");
    query_builder.push_bind(limit as i64);

    // Add OFFSET
    query_builder.push(" OFFSET ");
    query_builder.push_bind(offset as i64);

    Ok(query_builder)
}

async fn query_json_inferences(
    pool: &sqlx::PgPool,
    config: &Config,
    params: &ListInferencesParams<'_>,
    limit: u32,
    offset: u32,
) -> Result<Vec<StoredJsonInference>, Error> {
    let mut query_builder = build_json_inferences_query(config, params, limit, offset)?;

    let results: Vec<StoredJsonInference> = query_builder.build_query_as().fetch_all(pool).await?;

    Ok(results)
}

// ===== UNION ALL query for multi-table inference queries =====

/// Manual implementation of FromRow for StoredInferenceDatabase to handle UNION ALL queries.
/// Uses the `inference_type` column ('chat' or 'json') to determine which variant to construct.
impl<'r> sqlx::FromRow<'r, sqlx::postgres::PgRow> for StoredInferenceDatabase {
    fn from_row(row: &'r sqlx::postgres::PgRow) -> Result<Self, sqlx::Error> {
        let inference_type: String = row.try_get("inference_type")?;

        match inference_type.as_str() {
            "chat" => {
                let chat = StoredChatInferenceDatabase::from_row(row)?;
                Ok(StoredInferenceDatabase::Chat(chat))
            }
            "json" => {
                let json = StoredJsonInference::from_row(row)?;
                Ok(StoredInferenceDatabase::Json(json))
            }
            _ => Err(sqlx::Error::ColumnDecode {
                index: "inference_type".to_string(),
                source: Box::new(Error::new(ErrorDetails::PostgresResult {
                    result_type: "inference",
                    message: format!("Unknown inference type: {inference_type}"),
                })),
            }),
        }
    }
}

/// Manual implementation of FromRow for StoredChatInferenceDatabase.
/// This allows direct deserialization from Postgres rows without an intermediate struct.
impl<'r> sqlx::FromRow<'r, sqlx::postgres::PgRow> for StoredChatInferenceDatabase {
    fn from_row(row: &'r sqlx::postgres::PgRow) -> Result<Self, sqlx::Error> {
        let id: Uuid = row.try_get("id")?;
        let function_name: String = row.try_get("function_name")?;
        let variant_name: String = row.try_get("variant_name")?;
        let episode_id: Uuid = row.try_get("episode_id")?;
        let timestamp: DateTime<Utc> = row.try_get("timestamp")?;
        let input: Option<Json<StoredInput>> = row.try_get("input")?;
        let output: Option<Json<Vec<ContentBlockChatOutput>>> = row.try_get("output")?;
        let dispreferred_output: Option<Json<Vec<ContentBlockChatOutput>>> =
            row.try_get("dispreferred_output")?;
        let tags: Json<HashMap<String, String>> = row.try_get("tags")?;
        let extra_body: Option<Json<UnfilteredInferenceExtraBody>> = row.try_get("extra_body")?;
        let inference_params: Option<Json<InferenceParams>> = row.try_get("inference_params")?;
        let processing_time_ms: Option<i32> = row.try_get("processing_time_ms")?;
        let ttft_ms: Option<i32> = row.try_get("ttft_ms")?;
        let snapshot_hash: Option<SnapshotHash> = row.try_get("snapshot_hash")?;

        // Get chat-specific fields for tool_params reconstruction
        let dynamic_tools: Option<Json<Vec<Tool>>> = row.try_get("dynamic_tools")?;
        let dynamic_provider_tools: Option<Json<Vec<ProviderTool>>> =
            row.try_get("dynamic_provider_tools")?;
        let allowed_tools: Option<Json<AllowedTools>> = row.try_get("allowed_tools")?;
        let tool_choice: Option<Json<ToolChoice>> = row.try_get("tool_choice")?;
        let parallel_tool_calls: Option<bool> = row.try_get("parallel_tool_calls")?;

        // Only construct tool_params if any tool-related field is present
        let tool_params = if dynamic_tools.is_some()
            || dynamic_provider_tools.is_some()
            || allowed_tools.is_some()
            || tool_choice.is_some()
        {
            // These intentionally use unwrap_or_default.
            ToolCallConfigDatabaseInsert::from_stored_values(
                dynamic_tools.map(|dt| dt.0).unwrap_or_default(),
                dynamic_provider_tools.map(|v| v.0).unwrap_or_default(),
                allowed_tools.map(|v| v.0),
                tool_choice.map(|v| v.0),
                parallel_tool_calls,
            )
        } else {
            None
        };

        let dispreferred_outputs = dispreferred_output.map(|d| vec![d.0]).unwrap_or_default();

        Ok(StoredChatInferenceDatabase {
            function_name,
            variant_name,
            input: input.map(|v| v.0),
            output: output.map(|v| v.0),
            dispreferred_outputs,
            timestamp,
            episode_id,
            inference_id: id,
            tool_params,
            tags: tags.0,
            extra_body: extra_body.map(|v| v.0),
            inference_params: inference_params.map(|v| v.0),
            processing_time_ms: processing_time_ms.map(|v| v as u64),
            ttft_ms: ttft_ms.map(|v| v as u64),
            snapshot_hash: snapshot_hash.map(|h| h.to_hex_string()),
        })
    }
}

/// Manual implementation of FromRow for StoredJsonInference.
/// This allows direct deserialization from Postgres rows without an intermediate struct.
impl<'r> sqlx::FromRow<'r, sqlx::postgres::PgRow> for StoredJsonInference {
    fn from_row(row: &'r sqlx::postgres::PgRow) -> Result<Self, sqlx::Error> {
        let id: Uuid = row.try_get("id")?;
        let function_name: String = row.try_get("function_name")?;
        let variant_name: String = row.try_get("variant_name")?;
        let episode_id: Uuid = row.try_get("episode_id")?;
        let timestamp: DateTime<Utc> = row.try_get("timestamp")?;
        let input: Option<Json<StoredInput>> = row.try_get("input")?;
        let output: Option<Json<JsonInferenceOutput>> = row.try_get("output")?;
        let dispreferred_output: Option<Json<JsonInferenceOutput>> =
            row.try_get("dispreferred_output")?;
        let output_schema: Option<Value> = row.try_get("output_schema")?;
        let tags: Json<HashMap<String, String>> = row.try_get("tags")?;
        let extra_body: Option<Json<UnfilteredInferenceExtraBody>> = row.try_get("extra_body")?;
        let inference_params: Option<Json<InferenceParams>> = row.try_get("inference_params")?;
        let processing_time_ms: Option<i32> = row.try_get("processing_time_ms")?;
        let ttft_ms: Option<i32> = row.try_get("ttft_ms")?;
        let snapshot_hash: Option<SnapshotHash> = row.try_get("snapshot_hash")?;

        let dispreferred_outputs = dispreferred_output.map(|d| vec![d.0]).unwrap_or_default();

        Ok(StoredJsonInference {
            function_name,
            variant_name,
            input: input.map(|v| v.0),
            output: output.map(|v| v.0),
            dispreferred_outputs,
            timestamp,
            episode_id,
            inference_id: id,
            output_schema,
            tags: tags.0,
            extra_body: extra_body.map(|v| v.0),
            inference_params: inference_params.map(|v| v.0),
            processing_time_ms: processing_time_ms.map(|v| v as u64),
            ttft_ms: ttft_ms.map(|v| v as u64),
            snapshot_hash: snapshot_hash.map(|h| h.to_hex_string()),
        })
    }
}

/// Builds a query for inferences from both tables using UNION ALL.
/// Returns a QueryBuilder that can be executed against a Postgres connection.
fn build_inferences_union_query(
    config: &Config,
    params: &ListInferencesParams<'_>,
) -> Result<QueryBuilder<sqlx::Postgres>, Error> {
    // Build ORDER BY clause for the inner and outer queries
    let should_invert_directions =
        matches!(params.pagination, Some(PaginationParams::After { .. }));

    let id_direction = if let Some(ref pagination) = params.pagination {
        match pagination {
            PaginationParams::After { .. } => OrderDirection::Asc,
            PaginationParams::Before { .. } => OrderDirection::Desc,
        }
    } else {
        OrderDirection::Desc // Default: most recent first
    };

    let mut order_clauses = Vec::new();

    if let Some(order_by) = params.order_by {
        for o in order_by {
            let column = match &o.term {
                OrderByTerm::Timestamp => "timestamp",
                // TODO(#6441): Implement proper search relevance ordering for Postgres.
                OrderByTerm::SearchRelevance => {
                    if params.search_query_experimental.is_none() {
                        return Err(Error::new(ErrorDetails::InvalidRequest {
                            message:
                                "ORDER BY search_relevance requires search_query_experimental to be provided"
                                    .to_string(),
                        }));
                    }
                    "id"
                }
                OrderByTerm::Metric { name } => {
                    return Err(Error::new(ErrorDetails::InvalidRequest {
                        message: format!(
                            "ORDER BY metric `{name}` is not supported when querying without function_name"
                        ),
                    }));
                }
            };
            let effective_direction = if should_invert_directions {
                o.direction.inverted()
            } else {
                o.direction
            };
            order_clauses.push(format!(
                "{column} {} NULLS LAST",
                effective_direction.to_clickhouse_direction()
            ));
        }
    }

    // Always add id as tie-breaker for deterministic ordering
    order_clauses.push(format!("id {}", id_direction.to_clickhouse_direction()));

    let order_by_clause = format!("ORDER BY {}", order_clauses.join(", "));

    // Inner limit is (limit + offset) to ensure we fetch enough rows before applying outer offset
    let inner_limit = (params.limit + params.offset) as i64;

    // Build the SELECT clause based on output_source
    let (chat_output_select, json_output_select) = match params.output_source {
        InferenceOutputSource::None | InferenceOutputSource::Inference => (
            "io.output, NULL::jsonb as dispreferred_output",
            "io.output, NULL::jsonb as dispreferred_output",
        ),
        InferenceOutputSource::Demonstration => (
            "demo_f.value AS output, io.output as dispreferred_output",
            "demo_f.value AS output, io.output as dispreferred_output",
        ),
    };

    // Demonstration JOIN clause
    let demo_join = if params.output_source == InferenceOutputSource::Demonstration {
        r"
        JOIN (
            SELECT DISTINCT ON (inference_id)
                inference_id,
                value
            FROM tensorzero.demonstration_feedback
            ORDER BY inference_id, created_at DESC
        ) AS demo_f ON i.id = demo_f.inference_id
        "
    } else {
        ""
    };

    // Build the entire query using a single QueryBuilder to properly handle bind parameters
    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(format!(
        r"
        SELECT * FROM (
            (SELECT
                'chat'::text as inference_type,
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                {chat_output_select},
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls,
                NULL::jsonb as output_schema,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.chat_inferences i
            LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            {demo_join}
            WHERE TRUE"
    ));

    // Add chat filters
    apply_union_filters(&mut query_builder, config, params)?;

    query_builder.push(" ");
    query_builder.push(&order_by_clause);
    query_builder.push(" LIMIT ");
    query_builder.push_bind(inner_limit);

    // UNION ALL with json subquery
    query_builder.push(format!(
        r")
            UNION ALL
            (SELECT
                'json'::text as inference_type,
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                {json_output_select},
                NULL::jsonb as dynamic_tools,
                NULL::jsonb as dynamic_provider_tools,
                NULL::jsonb as allowed_tools,
                NULL::jsonb as tool_choice,
                NULL::boolean as parallel_tool_calls,
                io.output_schema,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.json_inferences i
            LEFT JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            {demo_join}
            WHERE TRUE"
    ));

    // Add json filters
    apply_union_filters(&mut query_builder, config, params)?;

    query_builder.push(" ");
    query_builder.push(&order_by_clause);
    query_builder.push(" LIMIT ");
    query_builder.push_bind(inner_limit);

    // Close subqueries and add outer ORDER BY + LIMIT + OFFSET
    query_builder.push(
        ")
        ) AS combined
        ",
    );
    query_builder.push(&order_by_clause);
    query_builder.push(" LIMIT ");
    query_builder.push_bind(params.limit as i64);
    query_builder.push(" OFFSET ");
    query_builder.push_bind(params.offset as i64);

    Ok(query_builder)
}

/// Query inferences from both tables using UNION ALL.
/// This pushes sorting and pagination to the database.
async fn query_inferences_union(
    pool: &sqlx::PgPool,
    config: &Config,
    params: &ListInferencesParams<'_>,
) -> Result<Vec<StoredInferenceDatabase>, Error> {
    let mut query_builder = build_inferences_union_query(config, params)?;

    let results: Vec<StoredInferenceDatabase> =
        query_builder.build_query_as().fetch_all(pool).await?;

    Ok(results)
}

/// Apply filters common to both chat and json subqueries in UNION ALL.
fn apply_union_filters(
    query_builder: &mut QueryBuilder<sqlx::Postgres>,
    config: &Config,
    params: &ListInferencesParams<'_>,
) -> Result<(), Error> {
    // Note: function_name filter is not applied here since UNION ALL queries
    // don't have function_name specified (that's the whole point)

    if let Some(variant_name) = params.variant_name {
        query_builder.push(" AND i.variant_name = ");
        query_builder.push_bind(variant_name);
    }

    if let Some(episode_id) = params.episode_id {
        query_builder.push(" AND i.episode_id = ");
        query_builder.push_bind(*episode_id);
    }

    if let Some(ids) = params.ids {
        query_builder.push(" AND i.id = ANY(");
        query_builder.push_bind(ids);
        query_builder.push(")");
    }

    // Apply inference filter (e.g., DemonstrationFeedback, metric filters, etc.)
    apply_inference_filter(query_builder, params.filters, config)?;

    // Apply search query filter (input/output are in IO tables)
    if let Some(search_query) = params.search_query_experimental {
        let json_escaped_query = json_double_escape_string_without_quotes(search_query)?;
        let search_pattern = format!("%{json_escaped_query}%");
        query_builder.push(" AND (io.input::text ILIKE ");
        query_builder.push_bind(search_pattern.clone());
        query_builder.push(" OR io.output::text ILIKE ");
        query_builder.push_bind(search_pattern);
        query_builder.push(")");
    }

    // Handle pagination cursor
    match &params.pagination {
        Some(PaginationParams::Before { id }) => {
            query_builder.push(" AND i.id < ");
            query_builder.push_bind(*id);
        }
        Some(PaginationParams::After { id }) => {
            query_builder.push(" AND i.id > ");
            query_builder.push_bind(*id);
        }
        None => {}
    }

    Ok(())
}

// ===== Helper functions for inference metadata queries =====

/// Manual implementation of FromRow for InferenceMetadata to handle UNION ALL queries.
/// Converts `snapshot_hash` bytes to string via SnapshotHash.
impl<'r> sqlx::FromRow<'r, sqlx::postgres::PgRow> for InferenceMetadata {
    fn from_row(row: &'r sqlx::postgres::PgRow) -> Result<Self, sqlx::Error> {
        let snapshot_hash: Option<SnapshotHash> = row.try_get("snapshot_hash")?;

        Ok(InferenceMetadata {
            id: row.try_get("id")?,
            function_name: row.try_get("function_name")?,
            variant_name: row.try_get("variant_name")?,
            episode_id: row.try_get("episode_id")?,
            function_type: row.try_get("function_type")?,
            snapshot_hash: snapshot_hash.map(|h| h.to_hex_string()),
        })
    }
}

/// Apply filters for metadata queries.
fn apply_metadata_filters(
    query_builder: &mut QueryBuilder<sqlx::Postgres>,
    params: &ListInferenceMetadataParams,
) {
    if let Some(ref function_name) = params.function_name {
        query_builder.push(" AND function_name = ");
        query_builder.push_bind(function_name);
    }

    if let Some(ref variant_name) = params.variant_name {
        query_builder.push(" AND variant_name = ");
        query_builder.push_bind(variant_name);
    }

    if let Some(episode_id) = params.episode_id {
        query_builder.push(" AND episode_id = ");
        query_builder.push_bind(episode_id);
    }

    // Handle pagination cursor
    match &params.pagination {
        Some(PaginationParams::Before { id }) => {
            query_builder.push(" AND id < ");
            query_builder.push_bind(*id);
        }
        Some(PaginationParams::After { id }) => {
            query_builder.push(" AND id > ");
            query_builder.push_bind(*id);
        }
        None => {}
    }
}

// ===== Helper functions for count queries =====

/// Count inferences from a single table (chat or json).
async fn count_single_table_inferences(
    pool: &sqlx::PgPool,
    config: &Config,
    params: &CountInferencesParams<'_>,
    table_name: &str,
    io_table_name: &str,
) -> Result<u64, Error> {
    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(format!(
        r"
        SELECT COUNT(*)::BIGINT
        FROM {table_name} i
        "
    ));

    // JOIN with IO table when search requires input/output columns
    if params.search_query_experimental.is_some() {
        query_builder.push(format!(
            " JOIN {io_table_name} io ON io.id = i.id AND io.created_at = i.created_at"
        ));
    }

    query_builder.push(" WHERE 1=1");

    if let Some(function_name) = params.function_name {
        query_builder.push(" AND i.function_name = ");
        query_builder.push_bind(function_name);
    }

    if let Some(variant_name) = params.variant_name {
        query_builder.push(" AND i.variant_name = ");
        query_builder.push_bind(variant_name);
    }

    if let Some(episode_id) = params.episode_id {
        query_builder.push(" AND i.episode_id = ");
        query_builder.push_bind(*episode_id);
    }

    // Apply inference filter (e.g., DemonstrationFeedback, metric filters, etc.)
    apply_inference_filter(&mut query_builder, params.filters, config)?;

    if let Some(search_query) = params.search_query_experimental {
        let json_escaped_query = json_double_escape_string_without_quotes(search_query)?;
        let search_pattern = format!("%{json_escaped_query}%");
        query_builder.push(" AND (io.input::text ILIKE ");
        query_builder.push_bind(search_pattern.clone());
        query_builder.push(" OR io.output::text ILIKE ");
        query_builder.push_bind(search_pattern);
        query_builder.push(")");
    }

    let query = query_builder.build_query_scalar::<i64>();
    let count: i64 = query.fetch_one(pool).await?;

    Ok(count as u64)
}

/// Count inferences from both tables using UNION ALL.
async fn count_inferences_union(
    pool: &sqlx::PgPool,
    config: &Config,
    params: &CountInferencesParams<'_>,
) -> Result<u64, Error> {
    let needs_io_join = params.search_query_experimental.is_some();

    // Build the entire query using a single QueryBuilder
    let mut query_builder: QueryBuilder<sqlx::Postgres> = QueryBuilder::new(
        r"
        SELECT COUNT(*)::BIGINT FROM (
            (SELECT i.id FROM tensorzero.chat_inferences i",
    );

    if needs_io_join {
        query_builder.push(
            " JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at",
        );
    }

    query_builder.push(" WHERE 1=1");

    // Add chat filters (no function_name filter since we're querying both tables)
    apply_count_filters(&mut query_builder, config, params)?;

    // UNION ALL with json subquery
    query_builder.push(
        r")
            UNION ALL
            (SELECT i.id FROM tensorzero.json_inferences i",
    );

    if needs_io_join {
        query_builder.push(
            " JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at",
        );
    }

    query_builder.push(" WHERE 1=1");

    // Add json filters
    apply_count_filters(&mut query_builder, config, params)?;

    // Close subqueries
    query_builder.push(
        ")
        ) AS combined
    ",
    );

    let query = query_builder.build_query_scalar::<i64>();
    let count: i64 = query.fetch_one(pool).await?;

    Ok(count as u64)
}

/// Build a query to count inferences with metric feedback.
/// If `metric_threshold` is Some, filters to only count feedbacks meeting the threshold criteria
/// based on metric type and optimize direction.
fn build_count_inferences_with_metric_feedback_query(
    function_name: &str,
    function_type: FunctionConfigType,
    metric_name: &str,
    metric_config: &MetricConfig,
    metric_threshold: Option<f64>,
) -> QueryBuilder<sqlx::Postgres> {
    let inference_table = function_type.postgres_table_name();
    let feedback_table = match metric_config.r#type {
        MetricConfigType::Float => "tensorzero.float_metric_feedback",
        MetricConfigType::Boolean => "tensorzero.boolean_metric_feedback",
    };
    let join_column = metric_config.level.inference_column_name();

    // Build the query using DISTINCT ON to get the latest feedback per target
    let mut qb: QueryBuilder<sqlx::Postgres> = QueryBuilder::new("SELECT COUNT(*)::BIGINT FROM ");
    qb.push(inference_table);
    qb.push(" i JOIN (SELECT DISTINCT ON (target_id) target_id, value FROM ");
    qb.push(feedback_table);
    qb.push(" WHERE metric_name = ");
    qb.push_bind(metric_name);
    qb.push(" ORDER BY target_id, created_at DESC) f ON i.");
    qb.push(join_column);
    qb.push(" = f.target_id WHERE i.function_name = ");
    qb.push_bind(function_name);

    // Add value condition based on threshold and metric type
    if let Some(threshold) = metric_threshold {
        match metric_config.r#type {
            MetricConfigType::Boolean => {
                // For boolean metrics, optimize direction determines which value to filter for
                match metric_config.optimize {
                    MetricConfigOptimize::Max => qb.push(" AND f.value = TRUE"),
                    MetricConfigOptimize::Min => qb.push(" AND f.value = FALSE"),
                };
            }
            MetricConfigType::Float => {
                // For float metrics, use the threshold with appropriate operator
                match metric_config.optimize {
                    MetricConfigOptimize::Max => qb.push(" AND f.value > "),
                    MetricConfigOptimize::Min => qb.push(" AND f.value < "),
                };
                qb.push_bind(threshold);
            }
        }
    }

    qb
}

/// Count inferences with metric feedback.
async fn count_inferences_with_metric_feedback(
    pool: &PgPool,
    function_name: &str,
    function_type: FunctionConfigType,
    metric_name: &str,
    metric_config: &MetricConfig,
    metric_threshold: Option<f64>,
) -> Result<u64, Error> {
    let mut qb = build_count_inferences_with_metric_feedback_query(
        function_name,
        function_type,
        metric_name,
        metric_config,
        metric_threshold,
    );

    let count: i64 = qb
        .build_query_scalar::<i64>()
        .fetch_one(pool)
        .await
        .map_err(|e| {
            Error::new(ErrorDetails::PostgresQuery {
                message: format!("Failed to count inferences with metric feedback: {e}"),
            })
        })?;

    Ok(count as u64)
}

/// Apply filters for count queries.
fn apply_count_filters(
    query_builder: &mut QueryBuilder<sqlx::Postgres>,
    config: &Config,
    params: &CountInferencesParams<'_>,
) -> Result<(), Error> {
    if let Some(function_name) = params.function_name {
        query_builder.push(" AND i.function_name = ");
        query_builder.push_bind(function_name);
    }

    if let Some(variant_name) = params.variant_name {
        query_builder.push(" AND i.variant_name = ");
        query_builder.push_bind(variant_name);
    }

    if let Some(episode_id) = params.episode_id {
        query_builder.push(" AND i.episode_id = ");
        query_builder.push_bind(*episode_id);
    }

    // Apply inference filter (e.g., DemonstrationFeedback, metric filters, etc.)
    apply_inference_filter(query_builder, params.filters, config)?;

    if let Some(search_query) = params.search_query_experimental {
        let json_escaped_query = json_double_escape_string_without_quotes(search_query)?;
        let search_pattern = format!("%{json_escaped_query}%");
        query_builder.push(" AND (io.input::text ILIKE ");
        query_builder.push_bind(search_pattern.clone());
        query_builder.push(" OR io.output::text ILIKE ");
        query_builder.push_bind(search_pattern);
        query_builder.push(")");
    }

    Ok(())
}

// ===== Inference count helper functions (merged from inference_count module) =====

/// Builds and executes a count-by-variant query using the rollup table.
async fn count_by_variant_impl(
    pool: &PgPool,
    function_type: FunctionConfigType,
    function_name: &str,
    variant_name: Option<&str>,
) -> Result<Vec<CountByVariant>, sqlx::Error> {
    let function_type_str = match function_type {
        FunctionConfigType::Chat => "chat",
        FunctionConfigType::Json => "json",
    };

    let mut qb = QueryBuilder::new(
        r#"SELECT
            variant_name,
            SUM(inference_count)::BIGINT AS inference_count,
            to_char(MAX(minute), 'YYYY-MM-DD"T"HH24:MI:SS.000"Z"') AS last_used_at
        FROM tensorzero.inference_by_function_statistics
        WHERE function_name = "#,
    );
    qb.push_bind(function_name);
    qb.push(" AND function_type = ");
    qb.push_bind(function_type_str);

    if let Some(variant) = variant_name {
        qb.push(" AND variant_name = ");
        qb.push_bind(variant);
    }

    qb.push(" GROUP BY variant_name ORDER BY inference_count DESC");

    let rows = qb.build().fetch_all(pool).await?;

    Ok(rows
        .into_iter()
        .map(|row: PgRow| {
            let variant_name: String = row.get("variant_name");
            let inference_count: i64 = row.get("inference_count");
            let last_used_at: String = row.get("last_used_at");
            CountByVariant {
                variant_name,
                inference_count: inference_count as u64,
                last_used_at,
            }
        })
        .collect())
}

/// Builds and executes a throughput-by-variant query using the rollup table.
async fn throughput_by_variant_impl(
    pool: &PgPool,
    function_name: &str,
    time_window: TimeWindow,
    max_periods: u32,
) -> Result<Vec<VariantThroughput>, Error> {
    let rows = if time_window == TimeWindow::Cumulative {
        // For cumulative, return all-time data grouped by variant with fixed epoch start
        let mut qb = QueryBuilder::new(
            r"SELECT
                '1970-01-01T00:00:00.000Z'::text AS period_start,
                variant_name,
                SUM(inference_count)::INT AS count
            FROM tensorzero.inference_by_function_statistics
            WHERE function_name = ",
        );
        qb.push_bind(function_name);
        qb.push(" GROUP BY variant_name ORDER BY variant_name DESC");

        qb.build().fetch_all(pool).await?
    } else {
        let unit = time_window.to_postgres_time_unit();

        let mut qb = QueryBuilder::new(
            "WITH max_time AS (
                SELECT MAX(minute) AS max_ts
                FROM tensorzero.inference_by_function_statistics
                WHERE function_name = ",
        );
        qb.push_bind(function_name);
        qb.push(
            ")
            SELECT
                to_char(date_trunc('",
        );
        qb.push(unit);
        qb.push(
            r#"', s.minute), 'YYYY-MM-DD"T"HH24:MI:SS.000"Z"') AS period_start,
                s.variant_name,
                SUM(s.inference_count)::INT AS count
            FROM tensorzero.inference_by_function_statistics s, max_time m
            WHERE s.function_name = "#,
        );
        qb.push_bind(function_name);
        qb.push(" AND s.minute >= m.max_ts - INTERVAL '1 ");
        qb.push(unit);
        qb.push("' * (");
        qb.push_bind(max_periods as i32);
        qb.push(" + 1) GROUP BY date_trunc('");
        qb.push(unit);
        qb.push("', s.minute), s.variant_name ORDER BY period_start DESC, variant_name DESC");

        qb.build().fetch_all(pool).await?
    };

    let variant_throughputs = rows
        .into_iter()
        .map(|row: PgRow| {
            let period_start_str: String = row.get("period_start");
            let period_start = DateTime::parse_from_rfc3339(&period_start_str)
                .map(|dt| dt.with_timezone(&Utc))
                .map_err(|err| {
                    Error::new(ErrorDetails::PostgresResult {
                        result_type: "variant_throughput",
                        message: format!(
                            "Failed to parse `period_start` value `{period_start_str}`: {err}"
                        ),
                    })
                })?;
            let variant_name: String = row.get("variant_name");
            let count: i32 = row.get("count");
            Ok(VariantThroughput {
                period_start,
                variant_name,
                count: count as u32,
            })
        })
        .collect::<Result<Vec<VariantThroughput>, Error>>()?;
    Ok(variant_throughputs)
}

#[cfg(test)]
mod tests {
    use std::path::Path;

    use super::*;
    use crate::config::ConfigFileGlob;
    use crate::db::clickhouse::query_builder::{
        InferenceFilter, OrderBy, OrderByTerm, OrderDirection,
    };
    use crate::db::inferences::ListInferencesParams;
    use crate::db::test_helpers::{assert_query_contains, assert_query_equals};

    fn make_test_config() -> Config {
        Config::default()
    }

    async fn get_test_config() -> Config {
        Config::load_from_path_optional_verify_credentials(
            &ConfigFileGlob::new_from_path(Path::new("tests/e2e/config/tensorzero.*.toml"))
                .unwrap(),
            false,
        )
        .await
        .unwrap()
        .into_config_without_writing_for_tests()
    }

    #[test]
    fn test_build_chat_inferences_query_basic() {
        let config = make_test_config();
        let params = ListInferencesParams {
            function_name: Some("test_function"),
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let query_builder = build_chat_inferences_query(&config, &params, 10, 0)
            .expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                io.output, NULL::jsonb as dispreferred_output,
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.chat_inferences i
            LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE TRUE AND i.function_name = $1
            ORDER BY i.id DESC
            LIMIT $2 OFFSET $3
            ",
        );
    }

    #[test]
    fn test_build_chat_inferences_query_with_demonstration_output_source() {
        let config = make_test_config();
        let params = ListInferencesParams {
            function_name: Some("test_function"),
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Demonstration,
            search_query_experimental: None,
        };

        let query_builder = build_chat_inferences_query(&config, &params, 10, 0)
            .expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                demo_f.value AS output, io.output as dispreferred_output,
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.chat_inferences i
            LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            JOIN (
                SELECT DISTINCT ON (inference_id)
                    inference_id,
                    value
                FROM tensorzero.demonstration_feedback
                ORDER BY inference_id, created_at DESC
            ) AS demo_f ON i.id = demo_f.inference_id
            WHERE TRUE AND i.function_name = $1
            ORDER BY i.id DESC
            LIMIT $2 OFFSET $3
            ",
        );
    }

    #[test]
    fn test_build_chat_inferences_query_with_pagination_before() {
        let config = make_test_config();
        let cursor_id = Uuid::now_v7();
        let params = ListInferencesParams {
            function_name: Some("test_function"),
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: Some(PaginationParams::Before { id: cursor_id }),
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let query_builder = build_chat_inferences_query(&config, &params, 10, 0)
            .expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                io.output, NULL::jsonb as dispreferred_output,
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.chat_inferences i
            LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE TRUE AND i.function_name = $1 AND i.id < $2
            ORDER BY i.id DESC
            LIMIT $3 OFFSET $4
            ",
        );
    }

    #[test]
    fn test_build_chat_inferences_query_with_pagination_after() {
        let config = make_test_config();
        let cursor_id = Uuid::now_v7();
        let params = ListInferencesParams {
            function_name: Some("test_function"),
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: Some(PaginationParams::After { id: cursor_id }),
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let query_builder = build_chat_inferences_query(&config, &params, 10, 0)
            .expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                io.output, NULL::jsonb as dispreferred_output,
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.chat_inferences i
            LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE TRUE AND i.function_name = $1 AND i.id > $2
            ORDER BY i.id ASC
            LIMIT $3 OFFSET $4
            ",
        );
    }

    #[test]
    fn test_build_chat_inferences_query_with_search() {
        let config = make_test_config();
        let params = ListInferencesParams {
            function_name: Some("test_function"),
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: Some("test query"),
        };

        let query_builder = build_chat_inferences_query(&config, &params, 10, 0)
            .expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                io.output, NULL::jsonb as dispreferred_output,
                io.dynamic_tools,
                io.dynamic_provider_tools,
                io.allowed_tools,
                io.tool_choice,
                io.parallel_tool_calls,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.chat_inferences i
            LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE TRUE AND i.function_name = $1
            AND (io.input::text ILIKE $2 OR io.output::text ILIKE $3)
            ORDER BY i.id DESC
            LIMIT $4 OFFSET $5
            ",
        );
    }

    #[test]
    fn test_build_json_inferences_query_basic() {
        let config = make_test_config();
        let params = ListInferencesParams {
            function_name: Some("test_function"),
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let query_builder = build_json_inferences_query(&config, &params, 10, 0)
            .expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT
                i.id,
                i.function_name,
                i.variant_name,
                i.episode_id,
                i.created_at as timestamp,
                io.input,
                io.output, NULL::jsonb as dispreferred_output,
                io.output_schema,
                i.tags,
                io.extra_body,
                io.inference_params,
                i.processing_time_ms,
                i.ttft_ms,
                i.snapshot_hash
            FROM tensorzero.json_inferences i
            LEFT JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at
            WHERE TRUE AND i.function_name = $1
            ORDER BY i.id DESC
            LIMIT $2 OFFSET $3
            ",
        );
    }

    #[test]
    fn test_build_inferences_union_query_basic() {
        let config = make_test_config();
        let params = ListInferencesParams {
            function_name: None, // UNION query is used when function_name is None
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: None,
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let query_builder =
            build_inferences_union_query(&config, &params).expect("Query building should succeed");
        let sql = query_builder.sql();
        assert_query_equals(
            sql.as_str(),
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as inference_type,
                    i.id,
                    i.function_name,
                    i.variant_name,
                    i.episode_id,
                    i.created_at as timestamp,
                    io.input,
                    io.output, NULL::jsonb as dispreferred_output,
                    io.dynamic_tools,
                    io.dynamic_provider_tools,
                    io.allowed_tools,
                    io.tool_choice,
                    io.parallel_tool_calls,
                    NULL::jsonb as output_schema,
                    i.tags,
                    io.extra_body,
                    io.inference_params,
                    i.processing_time_ms,
                    i.ttft_ms,
                    i.snapshot_hash
                FROM tensorzero.chat_inferences i
                LEFT JOIN tensorzero.chat_inference_data io ON io.id = i.id AND io.created_at = i.created_at
                WHERE TRUE ORDER BY id DESC LIMIT $1)
                UNION ALL
                (SELECT
                    'json'::text as inference_type,
                    i.id,
                    i.function_name,
                    i.variant_name,
                    i.episode_id,
                    i.created_at as timestamp,
                    io.input,
                    io.output, NULL::jsonb as dispreferred_output,
                    NULL::jsonb as dynamic_tools,
                    NULL::jsonb as dynamic_provider_tools,
                    NULL::jsonb as allowed_tools,
                    NULL::jsonb as tool_choice,
                    NULL::boolean as parallel_tool_calls,
                    io.output_schema,
                    i.tags,
                    io.extra_body,
                    io.inference_params,
                    i.processing_time_ms,
                    i.ttft_ms,
                    i.snapshot_hash
                FROM tensorzero.json_inferences i
                LEFT JOIN tensorzero.json_inference_data io ON io.id = i.id AND io.created_at = i.created_at
                WHERE TRUE ORDER BY id DESC LIMIT $2)
            ) AS combined
            ORDER BY id DESC LIMIT $3 OFFSET $4
            ",
        );
    }

    #[test]
    fn test_build_inferences_union_query_rejects_metric_order() {
        let config = make_test_config();
        let order_by = [OrderBy {
            term: OrderByTerm::Metric {
                name: "some_metric".to_string(),
            },
            direction: OrderDirection::Desc,
        }];
        let params = ListInferencesParams {
            function_name: None,
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: Some(&order_by),
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let result = build_inferences_union_query(&config, &params);
        let err = match result {
            Ok(_) => panic!("UNION query should reject metric ordering"),
            Err(e) => e,
        };
        assert!(
            err.to_string().contains(
                "ORDER BY metric `some_metric` is not supported when querying without function_name"
            ),
            "Error message should indicate metric ordering is not supported: {err}"
        );
    }

    #[test]
    fn test_build_inferences_union_query_rejects_search_relevance_without_query() {
        let config = make_test_config();
        let order_by = [OrderBy {
            term: OrderByTerm::SearchRelevance,
            direction: OrderDirection::Desc,
        }];
        let params = ListInferencesParams {
            function_name: None,
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: Some(&order_by),
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let result = build_inferences_union_query(&config, &params);
        let err = match result {
            Ok(_) => panic!("UNION query should reject search_relevance without search_query"),
            Err(e) => e,
        };
        assert!(
            err.to_string()
                .contains("ORDER BY search_relevance requires search_query_experimental"),
            "Error message should indicate search_query is required: {err}"
        );
    }

    #[test]
    fn test_build_inferences_union_query_with_timestamp_order() {
        let config = make_test_config();
        let order_by = [OrderBy {
            term: OrderByTerm::Timestamp,
            direction: OrderDirection::Asc,
        }];
        let params = ListInferencesParams {
            function_name: None,
            variant_name: None,
            episode_id: None,
            ids: None,
            filters: None,
            order_by: Some(&order_by),
            limit: 10,
            offset: 0,
            pagination: None,
            output_source: InferenceOutputSource::Inference,
            search_query_experimental: None,
        };

        let query_builder =
            build_inferences_union_query(&config, &params).expect("Query building should succeed");
        let sql = query_builder.sql();

        // Should have ORDER BY with timestamp ASC
        assert_query_contains(sql.as_str(), "ORDER BY timestamp ASC");
    }

    #[tokio::test]
    async fn test_build_inferences_union_query_with_float_metric_filter() {
        use crate::db::clickhouse::query_builder::{FloatComparisonOperator, FloatMetricFilter};

        let config = get_test_config().await;
        let filter = InferenceFilter::FloatMetric(FloatMetricFilter {
            metric_name: "brevity_score".to_string(),
            comparison_operator: FloatComparisonOperator::GreaterThan,
            value: 0.5,
        });
        let params = ListInferencesParams {
            function_name: None,
            filters: Some(&filter),
            ..Default::default()
        };

        let query_builder =
            build_inferences_union_query(&config, &params).expect("Query building should succeed");
        let sql = query_builder.sql();

        // Both subqueries should have the metric filter via EXISTS subquery
        assert_query_contains(
            sql.as_str(),
            "EXISTS (SELECT 1 FROM tensorzero.float_metric_feedback f WHERE f.target_id = i.id AND f.metric_name =",
        );
    }

    #[tokio::test]
    async fn test_build_inferences_union_query_with_boolean_metric_filter() {
        use crate::db::clickhouse::query_builder::BooleanMetricFilter;

        let config = get_test_config().await;
        let filter = InferenceFilter::BooleanMetric(BooleanMetricFilter {
            metric_name: "task_success".to_string(),
            value: true,
        });
        let params = ListInferencesParams {
            function_name: None,
            filters: Some(&filter),
            ..Default::default()
        };

        let query_builder =
            build_inferences_union_query(&config, &params).expect("Query building should succeed");
        let sql = query_builder.sql();

        // Both subqueries should have the metric filter via EXISTS subquery
        assert_query_contains(
            sql.as_str(),
            "EXISTS (SELECT 1 FROM tensorzero.boolean_metric_feedback f WHERE f.target_id = i.id AND f.metric_name =",
        );
    }

    #[tokio::test]
    async fn test_build_inferences_union_query_with_demonstration_filter() {
        use crate::db::clickhouse::query_builder::DemonstrationFeedbackFilter;

        let config = get_test_config().await;
        let filter = InferenceFilter::DemonstrationFeedback(DemonstrationFeedbackFilter {
            has_demonstration: true,
        });
        let params = ListInferencesParams {
            function_name: None,
            filters: Some(&filter),
            ..Default::default()
        };

        let query_builder =
            build_inferences_union_query(&config, &params).expect("Query building should succeed");
        let sql = query_builder.sql();

        // Both subqueries should have the demonstration filter via EXISTS subquery
        assert_query_contains(
            sql.as_str(),
            "EXISTS (SELECT 1 FROM tensorzero.demonstration_feedback WHERE inference_id = i.id)",
        );
    }

    #[tokio::test]
    async fn test_build_inferences_union_query_rejects_invalid_metric_name() {
        use crate::db::clickhouse::query_builder::{FloatComparisonOperator, FloatMetricFilter};

        let config = get_test_config().await;
        let filter = InferenceFilter::FloatMetric(FloatMetricFilter {
            metric_name: "nonexistent_metric".to_string(),
            comparison_operator: FloatComparisonOperator::GreaterThan,
            value: 0.5,
        });
        let params = ListInferencesParams {
            function_name: None,
            filters: Some(&filter),
            ..Default::default()
        };

        let result = build_inferences_union_query(&config, &params);
        let err = match result {
            Err(e) => e,
            Ok(_) => panic!("Should reject invalid metric name"),
        };
        assert!(
            err.to_string().contains("nonexistent_metric"),
            "Error should mention the invalid metric name: {err}"
        );
    }

    #[tokio::test]
    async fn test_build_inferences_union_query_with_episode_level_metric_filter() {
        use crate::db::clickhouse::query_builder::{FloatComparisonOperator, FloatMetricFilter};

        let config = get_test_config().await;
        // user_rating is an episode-level metric
        let filter = InferenceFilter::FloatMetric(FloatMetricFilter {
            metric_name: "user_rating".to_string(),
            comparison_operator: FloatComparisonOperator::GreaterThanOrEqual,
            value: 4.0,
        });
        let params = ListInferencesParams {
            function_name: None,
            filters: Some(&filter),
            ..Default::default()
        };

        let query_builder =
            build_inferences_union_query(&config, &params).expect("Query building should succeed");
        let sql = query_builder.sql();

        // Episode-level metrics should join on episode_id
        assert_query_contains(sql.as_str(), "f.target_id = i.episode_id");
    }

    // ===== build_inference_metadata_query tests =====

    #[test]
    fn test_build_inference_metadata_query_no_filters() {
        let params = ListInferenceMetadataParams {
            function_name: None,
            variant_name: None,
            episode_id: None,
            pagination: None,
            limit: 100,
        };

        let qb = build_inference_metadata_query(&params, "DESC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 ORDER BY id DESC LIMIT $1)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 ORDER BY id DESC LIMIT $2)
            ) AS combined
            ORDER BY id DESC LIMIT $3
            ",
        );
    }

    #[test]
    fn test_build_inference_metadata_query_with_function_name() {
        let params = ListInferenceMetadataParams {
            function_name: Some("test_function".to_string()),
            variant_name: None,
            episode_id: None,
            pagination: None,
            limit: 50,
        };

        let qb = build_inference_metadata_query(&params, "DESC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 AND function_name = $1 ORDER BY id DESC LIMIT $2)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 AND function_name = $3 ORDER BY id DESC LIMIT $4)
            ) AS combined
            ORDER BY id DESC LIMIT $5
            ",
        );
    }

    #[test]
    fn test_build_inference_metadata_query_with_variant_name() {
        let params = ListInferenceMetadataParams {
            function_name: None,
            variant_name: Some("test_variant".to_string()),
            episode_id: None,
            pagination: None,
            limit: 50,
        };

        let qb = build_inference_metadata_query(&params, "DESC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 AND variant_name = $1 ORDER BY id DESC LIMIT $2)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 AND variant_name = $3 ORDER BY id DESC LIMIT $4)
            ) AS combined
            ORDER BY id DESC LIMIT $5
            ",
        );
    }

    #[test]
    fn test_build_inference_metadata_query_with_episode_id() {
        let episode_id = Uuid::now_v7();
        let params = ListInferenceMetadataParams {
            function_name: None,
            variant_name: None,
            episode_id: Some(episode_id),
            pagination: None,
            limit: 50,
        };

        let qb = build_inference_metadata_query(&params, "DESC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 AND episode_id = $1 ORDER BY id DESC LIMIT $2)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 AND episode_id = $3 ORDER BY id DESC LIMIT $4)
            ) AS combined
            ORDER BY id DESC LIMIT $5
            ",
        );
    }

    #[test]
    fn test_build_inference_metadata_query_pagination_before() {
        let before_id = Uuid::now_v7();
        let params = ListInferenceMetadataParams {
            function_name: None,
            variant_name: None,
            episode_id: None,
            pagination: Some(PaginationParams::Before { id: before_id }),
            limit: 50,
        };

        let qb = build_inference_metadata_query(&params, "DESC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 AND id < $1 ORDER BY id DESC LIMIT $2)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 AND id < $3 ORDER BY id DESC LIMIT $4)
            ) AS combined
            ORDER BY id DESC LIMIT $5
            ",
        );
    }

    #[test]
    fn test_build_inference_metadata_query_pagination_after() {
        let after_id = Uuid::now_v7();
        let params = ListInferenceMetadataParams {
            function_name: None,
            variant_name: None,
            episode_id: None,
            pagination: Some(PaginationParams::After { id: after_id }),
            limit: 50,
        };

        let qb = build_inference_metadata_query(&params, "ASC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 AND id > $1 ORDER BY id ASC LIMIT $2)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 AND id > $3 ORDER BY id ASC LIMIT $4)
            ) AS combined
            ORDER BY id ASC LIMIT $5
            ",
        );
    }

    #[test]
    fn test_build_inference_metadata_query_all_filters() {
        let episode_id = Uuid::now_v7();
        let before_id = Uuid::now_v7();
        let params = ListInferenceMetadataParams {
            function_name: Some("my_function".to_string()),
            variant_name: Some("my_variant".to_string()),
            episode_id: Some(episode_id),
            pagination: Some(PaginationParams::Before { id: before_id }),
            limit: 25,
        };

        let qb = build_inference_metadata_query(&params, "DESC");
        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        assert_query_equals(
            sql,
            r"
            SELECT * FROM (
                (SELECT
                    'chat'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.chat_inferences
                WHERE 1=1 AND function_name = $1 AND variant_name = $2 AND episode_id = $3 AND id < $4 ORDER BY id DESC LIMIT $5)
                UNION ALL
                (SELECT
                    'json'::text as function_type,
                    id,
                    function_name,
                    variant_name,
                    episode_id,
                    snapshot_hash
                FROM tensorzero.json_inferences
                WHERE 1=1 AND function_name = $6 AND variant_name = $7 AND episode_id = $8 AND id < $9 ORDER BY id DESC LIMIT $10)
            ) AS combined
            ORDER BY id DESC LIMIT $11
            ",
        );
    }

    // Tests for count_inferences_with_metric_feedback query building

    #[test]
    fn test_build_count_metric_feedback_query_float_inference_level_no_threshold() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Float,
            optimize: MetricConfigOptimize::Max,
            level: MetricConfigLevel::Inference,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Chat,
            "test_metric",
            &metric_config,
            None,
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.chat_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.float_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.id = f.target_id
            WHERE i.function_name = $2
        ";

        assert_query_equals(sql, expected);
    }

    #[test]
    fn test_build_count_metric_feedback_query_float_inference_level_with_threshold_max() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Float,
            optimize: MetricConfigOptimize::Max,
            level: MetricConfigLevel::Inference,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Json,
            "test_metric",
            &metric_config,
            Some(0.5),
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.json_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.float_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.id = f.target_id
            WHERE i.function_name = $2
            AND f.value > $3
        ";

        assert_query_equals(sql, expected);
    }

    #[test]
    fn test_build_count_metric_feedback_query_float_inference_level_with_threshold_min() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Float,
            optimize: MetricConfigOptimize::Min,
            level: MetricConfigLevel::Inference,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Chat,
            "test_metric",
            &metric_config,
            Some(0.5),
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.chat_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.float_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.id = f.target_id
            WHERE i.function_name = $2
            AND f.value < $3
        ";

        assert_query_equals(sql, expected);
    }

    #[test]
    fn test_build_count_metric_feedback_query_float_episode_level_no_threshold() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Float,
            optimize: MetricConfigOptimize::Max,
            level: MetricConfigLevel::Episode,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Chat,
            "episode_metric",
            &metric_config,
            None,
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.chat_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.float_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.episode_id = f.target_id
            WHERE i.function_name = $2
        ";

        assert_query_equals(sql, expected);
    }

    #[test]
    fn test_build_count_metric_feedback_query_boolean_inference_level_no_threshold() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Boolean,
            optimize: MetricConfigOptimize::Max,
            level: MetricConfigLevel::Inference,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Json,
            "exact_match",
            &metric_config,
            None,
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.json_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.boolean_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.id = f.target_id
            WHERE i.function_name = $2
        ";

        assert_query_equals(sql, expected);
    }

    #[test]
    fn test_build_count_metric_feedback_query_boolean_inference_level_with_threshold_max() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Boolean,
            optimize: MetricConfigOptimize::Max,
            level: MetricConfigLevel::Inference,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Json,
            "exact_match",
            &metric_config,
            Some(0.5), // threshold value is ignored for boolean, only presence matters
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.json_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.boolean_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.id = f.target_id
            WHERE i.function_name = $2
            AND f.value = TRUE
        ";

        assert_query_equals(sql, expected);
    }

    #[test]
    fn test_build_count_metric_feedback_query_boolean_inference_level_with_threshold_min() {
        let metric_config = MetricConfig {
            r#type: MetricConfigType::Boolean,
            optimize: MetricConfigOptimize::Min,
            level: MetricConfigLevel::Inference,
            description: None,
        };

        let qb = build_count_inferences_with_metric_feedback_query(
            "test_function",
            FunctionConfigType::Json,
            "exact_match",
            &metric_config,
            Some(0.5),
        );

        let sql_str = qb.sql();
        let sql = sql_str.as_str();

        let expected = r"
            SELECT COUNT(*)::BIGINT FROM tensorzero.json_inferences i
            JOIN (SELECT DISTINCT ON (target_id) target_id, value
                  FROM tensorzero.boolean_metric_feedback
                  WHERE metric_name = $1
                  ORDER BY target_id, created_at DESC) f
            ON i.id = f.target_id
            WHERE i.function_name = $2
            AND f.value = FALSE
        ";

        assert_query_equals(sql, expected);
    }
}
