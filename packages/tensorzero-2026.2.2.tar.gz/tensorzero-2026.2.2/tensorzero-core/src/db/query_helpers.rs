use chrono::{DateTime, Utc};
use uuid::Uuid;

use crate::error::{Error, ErrorDetails};

/// Escapes a string for JSON, without the surrounding quotes.
///
/// This is used to escape the text query when doing a substring match on input and output strings, because
/// input and output strings are JSON-escaped in ClickHouse (and json::text is also JSON-escaped in Postgres).
pub fn json_escape_string_without_quotes(s: &str) -> Result<String, Error> {
    let mut json_escaped = serde_json::to_string(s)?;
    json_escaped.remove(0);
    json_escaped.pop();
    Ok(json_escaped)
}

/// Double-escapes a string for JSON, without the surrounding quotes.
///
/// For searching in input and output strings in ClickHouse and Postgres, we need to double-escape the string,
/// because input and output are JSON objects where any quoted search query will be escaped twice.
/// (something like {"input": "\"quoted text\""} will be stored as {\"input\": \"\\\"quoted text\\\"\"}).
pub fn json_double_escape_string_without_quotes(s: &str) -> Result<String, Error> {
    let json_escaped = json_escape_string_without_quotes(s)?;
    json_escape_string_without_quotes(&json_escaped)
}

/// Converts a UUIDv7 to a DateTime<Utc> by extracting its embedded timestamp.
pub fn uuid_to_datetime(uuid: Uuid) -> Result<DateTime<Utc>, Error> {
    let timestamp = uuid.get_timestamp().ok_or_else(|| {
        Error::new(ErrorDetails::InvalidUuid {
            raw_uuid: uuid.to_string(),
        })
    })?;
    let (secs, nanos) = timestamp.to_unix();
    DateTime::from_timestamp(secs as i64, nanos).ok_or_else(|| {
        Error::new(ErrorDetails::InvalidUuid {
            raw_uuid: uuid.to_string(),
        })
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_json_escape_string_without_quotes() {
        assert_eq!(
            json_escape_string_without_quotes("").unwrap(),
            String::new()
        );
        assert_eq!(
            json_escape_string_without_quotes("test").unwrap(),
            "test".to_string()
        );
        assert_eq!(
            json_escape_string_without_quotes("123").unwrap(),
            "123".to_string()
        );
        assert_eq!(
            json_escape_string_without_quotes("he's").unwrap(),
            "he's".to_string()
        );
    }

    #[test]
    fn test_json_escape_string_escapes_correctly() {
        assert_eq!(
            json_escape_string_without_quotes(r#""test""#).unwrap(),
            r#"\"test\""#.to_string()
        );

        assert_eq!(
            json_escape_string_without_quotes(r"end of line\next line").unwrap(),
            r"end of line\\next line".to_string()
        );
    }

    #[test]
    fn test_json_double_escape_string_without_quotes() {
        assert_eq!(
            json_double_escape_string_without_quotes(r#""test""#).unwrap(),
            r#"\\\"test\\\""#.to_string()
        );
    }
}
