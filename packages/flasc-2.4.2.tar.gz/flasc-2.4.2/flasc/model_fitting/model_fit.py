"""Modular Class for computing a fitness evaluation of a FLORIS model to SCADA data."""

from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd
from floris import FlorisModel, ParFlorisModel, UncertainFlorisModel

from flasc.data_processing import dataframe_manipulations as dfm
from flasc.flasc_dataframe import FlascDataFrame
from flasc.model_fitting.cost_library import CostFunctionBase
from flasc.utilities.tuner_utilities import replicate_nan_values


class ModelFit:
    """Fit a FlorisModel to SCADA data.

    A modular class for computing fitness evaluation of a FLORIS model to SCADA data.
    Provides methods to run FLORIS simulations, evaluate cost functions, and manage
    parameter optimization for model calibration.
    """

    def __init__(
        self,
        df: pd.DataFrame | FlascDataFrame,
        fmodel: FlorisModel | ParFlorisModel | UncertainFlorisModel,
        cost_function: CostFunctionBase,
        parameter_list: List[List] | List[Tuple] = [],
        parameter_name_list: List[str] = [],
        parameter_range_list: List[List] | List[Tuple] = [],
        parameter_index_list: List[int] = [],
        yaw_angles: np.ndarray | None = None,
        use_non_default_wd_sample_points: bool = False,
    ):
        """Initialize the ModelFit class.

        Args:
            df (pd.DataFrame | FlascDataFrame): DataFrame containing SCADA data.
            fmodel (FlorisModel | ParFlorisModel | UncertainFlorisModel):
                FLORIS model to calibrate.
            cost_function (CostFunctionBase): Instance of a cost function class that inherits from
                CostFunctionBase.
            parameter_list (List[List] | List[Tuple], optional): List of FLORIS parameters to
                calibrate. If empty, no parameters are calibrated. Defaults to [].
            parameter_name_list (List[str], optional): List of names for the parameters.
                If empty, no names are provided. Defaults to [].
            parameter_range_list (List[List] | List[Tuple], optional): List of parameter ranges.
                If empty, no ranges are provided. Defaults to [].
            parameter_index_list (List[int], optional): List of parameter indices. Defaults to [].
            yaw_angles (np.ndarray | None, optional): Array of yaw angles. Defaults to None.
            use_non_default_wd_sample_points (bool, optional): Whether to use non-default wind
                direction sample points. If True, the wind direction sample points will be set to
                the sample points in the FLORIS model will be recorded in units of wd_std and
                rescaled with the new wd_std. If False, the default wind direction sample points
                will be used ([-2 * wd_std, -1 * wd_std, 0, wd_std, 2 * wd_std]).
                Defaults to False.
        """
        # Save the dataframe as a FlascDataFrame
        self.df = FlascDataFrame(df)

        # Make sure the dataframe index is simple
        self.df = self.df.reset_index(drop=True)

        # Check the dataframe
        self._check_flasc_dataframe(self.df)

        # Check if fmodel if FlorisModel or ParallelFlorisModel
        if not isinstance(fmodel, (FlorisModel, ParFlorisModel, UncertainFlorisModel)):
            raise ValueError(
                "fmodel must be a FlorisModel, ParallelFlorisModel or UncertainFlorisModel."
            )

        # Check that cost_function is an instance of CostFunctionBase
        if not isinstance(cost_function, CostFunctionBase):
            raise TypeError("cost_function must be an instantiated subclass of CostFunctionBase.")
        if not hasattr(cost_function, "cost"):
            raise NotImplementedError(
                "The cost_function must have a cost() method implemented that takes a dataframe "
                "(df_floris) as an input and returns a float."
            )

        # Save the fmodel
        self.fmodel = fmodel

        # Get the number of turbines and confirm that
        # the dataframe and floris model have the same number of turbines
        n_turbines_data = dfm.get_num_turbines(self.df)

        if n_turbines_data != self.fmodel.n_turbines:
            print(
                "WARNING: The number of turbines in the dataframe and the "
                "Floris model do not match."
            )

        # Store the use_non_default_wd_sample_points flag
        self.use_non_default_wd_sample_points = use_non_default_wd_sample_points

        # If the user requests to use non-default wind direction sample points,
        # learn what these should be from the floris model in units of wd_std
        if use_non_default_wd_sample_points:
            self.wd_sample_points_in_wd_std = [
                wdsp / fmodel.wd_std for wdsp in fmodel.wd_sample_points
            ]

        # If yaw angles are provided, check that they are the same length as the number of turbines
        if yaw_angles is not None:
            if yaw_angles.ndim != 2:
                raise ValueError("yaw_angles must be a 2D array.")
            if yaw_angles.shape[0] != len(self.df):
                raise ValueError(
                    "yaw_angles must have the same length as the number of rows in df."
                )
            if yaw_angles.shape[1] != self.df.n_turbines:
                raise ValueError(
                    "yaw_angles must have the same num cols as the number of turbines."
                )
            self.yaw_angles = yaw_angles
        else:
            self.yaw_angles = None

        # Assign the dataframe to the cost object
        cost_function.assign_df_scada(self.df)

        # Save the cost function handle
        self.cost_function = cost_function

        # Confirm that parameter_list, parameter_name_list, and parameter_range_list and
        # parameter_index_list are lists
        if not isinstance(parameter_list, list):
            raise ValueError("parameter_list must be a list.")
        if not isinstance(parameter_name_list, list):
            raise ValueError("parameter_name_list must be a list.")
        if not isinstance(parameter_range_list, list):
            raise ValueError("parameter_range_list must be a list.")
        if not isinstance(parameter_index_list, list):
            raise ValueError("parameter_index_list must be a list.")

        # Confirm that parameter_list, parameter_name_list,
        # and parameter_range_list are the same length
        if len(parameter_list) != len(parameter_name_list) or len(parameter_list) != len(
            parameter_range_list
        ):
            raise ValueError(
                "parameter_list, parameter_name_list, and parameter_range_list"
                " must be the same length."
            )

        # If any of parameter_list, parameter_name_list, or parameter_range_list are provided,
        # (in that they have lengths greater than 0) then all must be provided
        if len(parameter_list) > 0 or len(parameter_name_list) > 0 or len(parameter_range_list) > 0:
            if (
                len(parameter_list) == 0
                or len(parameter_name_list) == 0
                or len(parameter_range_list) == 0
            ):
                raise ValueError(
                    "If any of parameter_list, parameter_name_list, or parameter_range_list"
                    " are provided, all must be provided."
                )

        # Save the parameter list, name list, and range list
        self.parameter_list = parameter_list
        self.parameter_name_list = parameter_name_list
        self.parameter_range_list = parameter_range_list

        # Save the number of parameters
        self.n_parameters = len(parameter_list)

        # If parameter_index_list is empty, set as a list of None equal to the number of parameters
        if len(parameter_index_list) == 0:
            self.parameter_index_list = [None] * self.n_parameters

        # Else ensure it is the same length as parameter_list
        else:
            if len(parameter_index_list) != self.n_parameters:
                raise ValueError("parameter_index_list must be the same length as parameter_list.")
            self.parameter_index_list = parameter_index_list

        # Initialize the initial parameter values
        self.initial_parameter_values = self.get_parameter_values()

    def _check_flasc_dataframe(self, df: FlascDataFrame) -> None:
        """Check that the provided FlascDataFrame is valid.

        Args:
            df (FlascDataFrame): DataFrame to check.
        """
        # Data frame must contain a 'ws' and 'wd' column
        if "ws" not in df.columns or "wd" not in df.columns:
            raise ValueError("DataFrame must contain 'ws' and 'wd' columns.")

    def _form_flasc_dataframe(
        self,
        time: np.ndarray,
        wind_directions: np.ndarray,
        wind_speeds: np.ndarray,
        powers: np.ndarray,
    ) -> FlascDataFrame:
        """Form a FlascDataFrame from wind directions, wind speeds, and powers.

        Args:
            time (np.ndarray): Array of time values.
            wind_directions (np.ndarray): Array of wind directions.
            wind_speeds (np.ndarray): Array of wind speeds.
            powers (np.ndarray): Array of powers.  Must be (n_findex, n_turbines).

        Returns:
            FlascDataFrame: FlascDataFrame containing the wind directions, wind speeds, and powers.
        """
        # Check that lengths of time, wind directions
        if time.shape[0] != wind_directions.shape[0]:
            raise ValueError("time and wind_directions must have the same length.")

        # Check that the shapes of the arrays are correct
        if wind_directions.shape[0] != wind_speeds.shape[0]:
            raise ValueError("wind_directions and wind_speeds must have the same length.")

        if wind_directions.shape[0] != powers.shape[0]:
            raise ValueError("wind_directions and powers (0th axis) must have the same length.")

        if powers.ndim != 2:
            raise ValueError("powers must be a 2D array.")

        # Name the power columns
        pow_cols = [f"pow_{i:>03}" for i in range(powers.shape[1])]

        # Assign the powers
        _df = pd.DataFrame(data=powers, columns=pow_cols)
        # Assign the wind directions and wind speeds
        _df = _df.assign(time=time, wd=wind_directions, ws=wind_speeds)

        # Re-order the columns
        _df = _df[["time", "wd", "ws"] + pow_cols]

        return FlascDataFrame(_df)

    def run_floris_model(self, **kwargs) -> FlascDataFrame:
        """Run the FLORIS model with the current parameter values.

        Given the provided FLORIS model and SCADA data, run the FLORIS model
        and generate a FlascDataFrame of FLORIS values.  Note **kwargs are
        provided to allow additional settings to be passed to the
        set method.

        Args:
            **kwargs: Additional keyword arguments to pass to the
                set method.

        Returns:
            FlascDataFrame: FlascDataFrame containing FLORIS simulation results with wind
                directions, wind speeds, and turbine powers.
        """
        # Get the wind speeds, wind directions and turbulence intensities
        time = self.df["time"].values
        wind_speeds = self.df["ws"].values
        wind_directions = self.df["wd"].values

        # TI is used direcly if included in the dataframe
        # Else the first value of the current model is used
        if "ti" in self.df.columns:
            turbulence_intensities = self.df["ti"].values
        else:
            turbulence_intensities = (
                np.ones_like(wind_speeds) * self.fmodel.turbulence_intensities[0]
            )

        # Set the FlorisModel
        self.fmodel.set(
            wind_speeds=wind_speeds,
            wind_directions=wind_directions,
            turbulence_intensities=turbulence_intensities,
            **kwargs,
        )

        # if yaw angles are not None, set the yaw angles
        if self.yaw_angles is not None:
            self.fmodel.set(yaw_angles=self.yaw_angles)

        # Run the model
        self.fmodel.run()

        # Get the turbines in kW
        turbine_powers = self.fmodel.get_turbine_powers() / 1000

        # Generate FLORIS dataframe
        df_floris = self._form_flasc_dataframe(time, wind_directions, wind_speeds, turbine_powers)

        # Make sure the NaN values in the SCADA data appear in the same locations in the
        # FLORIS data
        df_floris = replicate_nan_values(self.df, df_floris)

        # Make sure floris dataframe has an index identical to the SCADA dataframe
        df_floris.index = self.df.index

        # Save the floris result frame for debugging
        self._df_floris = df_floris

        # Return df_floris
        return df_floris

    def set_wd_std(self, wd_std: float) -> None:
        """Set the standard deviation of the wind direction within the UncertainFlorisModel.

        Args:
            wd_std (float): Standard deviation of the wind direction.
        """
        # Check if the model is an UncertainFlorisModel
        if not isinstance(self.fmodel, UncertainFlorisModel):
            raise ValueError("The floris model must be an UncertainFlorisModel.")

        # If the user requests to use non-default wind direction sample points,
        # learn what these should be from the floris model in units of wd_std
        if self.use_non_default_wd_sample_points:
            wd_sample_points = np.array(self.wd_sample_points_in_wd_std) * wd_std
        else:
            # Default to None which will use the default wd_sample_points
            # [-2 * wd_std, -1 * wd_std, 0, wd_std, 2 * wd_std]
            wd_sample_points = None

        # Update the UncertainFlorisModel
        self.fmodel = UncertainFlorisModel(
            self.fmodel.fmodel_unexpanded,
            wd_resolution=self.fmodel.wd_resolution,
            ws_resolution=self.fmodel.ws_resolution,
            ti_resolution=self.fmodel.ti_resolution,
            yaw_resolution=self.fmodel.yaw_resolution,
            power_setpoint_resolution=self.fmodel.power_setpoint_resolution,
            awc_amplitude_resolution=self.fmodel.awc_amplitude_resolution,
            wd_std=wd_std,
            wd_sample_points=wd_sample_points,
            fix_yaw_to_nominal_direction=self.fmodel.fix_yaw_to_nominal_direction,
            verbose=self.fmodel.verbose,
        )

    def evaluate_floris(self, **kwargs) -> float:
        """Evaluate the FLORIS model.

        Given the current parameter values, run the FLORIS model and evaluate the cost function.

        Args:
            **kwargs: Additional keyword arguments to pass to the run_floris_model method.

        Returns:
            float: Cost value.
        """
        # Run the FLORIS model
        df_floris = self.run_floris_model(**kwargs)

        # Evaluate the cost function passing the FlorisModel
        return self.cost_function(df_floris)

    def set_parameter_and_evaluate(
        self,
        parameter_values: np.ndarray,
        **kwargs,
    ) -> float:
        """Internal function to evaluate the cost function with a given set of parameters.

        Args:
            parameter_values (np.ndarray): Array of parameter values.
            **kwargs: Additional keyword arguments to pass to the optimization algorithm.

        Returns:
            float: Cost value.
        """
        # Set the parameter values
        self.set_parameter_values(parameter_values)

        # Evaluate the cost function
        return self.evaluate_floris(**kwargs)

    def get_parameter_values(
        self,
    ) -> np.ndarray:
        """Get the current parameter values from the FLORIS model.

        Returns:
            np.ndarray: Array of parameter values.
        """
        parameter_values = np.zeros(self.n_parameters)

        for i, (parameter, parameter_index) in enumerate(
            zip(self.parameter_list, self.parameter_index_list)
        ):
            parameter_values[i] = self.fmodel.get_param(parameter, parameter_index)

        return parameter_values

    def set_parameter_values(
        self,
        parameter_values: np.ndarray,
    ) -> None:
        """Set the parameter values in the FLORIS model.

        Args:
            parameter_values (np.ndarray): Array of parameter values.
        """
        # Check that parameters values is len(parameter_list) long
        if len(parameter_values) != self.n_parameters:
            raise ValueError("parameter_values must have length equal to the number of parameters.")

        for i, (parameter, parameter_index) in enumerate(
            zip(self.parameter_list, self.parameter_index_list)
        ):
            self.fmodel.set_param(parameter, parameter_values[i], parameter_index)
