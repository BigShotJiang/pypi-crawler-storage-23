# -*- coding: utf-8 -*-

"""Modular model fitting for FLASC."""

__author__ = """Paul Fleming, Michael Sinner, Bart Doekemeijer"""
__email__ = "paul.fleming@nlr.gov, michael.sinner@nlr.gov"

from pathlib import Path
