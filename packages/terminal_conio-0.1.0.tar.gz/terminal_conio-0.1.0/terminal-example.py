"""
demo_terminal.py — Shows in-place terminal rendering.

Run from a real terminal:
    python demo_terminal.py

Press Q to quit.
"""

import time
import math
import threading
from datetime import datetime
from terminal import Terminal, Color
from conio import getch, kbhit


def draw_frame(t: Terminal, frame: int, bx: float, by: float,
               score: int, elapsed: float):
    W, H = t.width, t.height

    # ── background ──────────────────────────────────────────────────────────
    t.clear(bg=Color.BLACK)

    # ── outer border ────────────────────────────────────────────────────────
    t.box(0, 0, W, H, fg=Color.DARK_GRAY, style='double')

    # ── title bar ───────────────────────────────────────────────────────────
    title = " TERMINAL RENDERER DEMO "
    tx = (W - len(title)) // 2
    t.fill(1, 1, W - 2, 1, ' ', fg=Color.BLACK, bg=Color.BLUE)
    t.print(tx, 1, title, fg=Color.BRIGHT_WHITE, bg=Color.BLUE, bold=True)

    # ── clock (top-right) ───────────────────────────────────────────────────
    clock = datetime.now().strftime(" %H:%M:%S ")
    t.print(W - len(clock) - 1, 1, clock, fg=Color.YELLOW, bg=Color.BLUE, bold=True)

    # ── info panel ──────────────────────────────────────────────────────────
    panel_x, panel_y = 2, 3
    t.box(panel_x, panel_y, 26, 7, fg=Color.CYAN)
    t.print(panel_x + 1, panel_y,     " Stats ", fg=Color.CYAN)
    t.print(panel_x + 2, panel_y + 1, f"Frame   : {frame:>6}",  fg=Color.WHITE)
    t.print(panel_x + 2, panel_y + 2, f"Elapsed : {elapsed:>5.1f}s", fg=Color.WHITE)
    t.print(panel_x + 2, panel_y + 3, f"Ball X  : {bx:>6.1f}", fg=Color.LIGHT_GREEN)
    t.print(panel_x + 2, panel_y + 4, f"Ball Y  : {by:>6.1f}", fg=Color.LIGHT_GREEN)
    t.print(panel_x + 2, panel_y + 5, f"Score   : {score:>6}", fg=Color.YELLOW, bold=True)

    # ── play field ──────────────────────────────────────────────────────────
    field_x, field_y = 30, 3
    field_w = W - field_x - 2
    field_h = H - 6
    t.box(field_x, field_y, field_w, field_h, fg=Color.DARK_GRAY)
    t.print(field_x + 1, field_y, " Play Field ", fg=Color.DARK_GRAY)

    # bouncing ball (clamped to field interior)
    bxi = field_x + 1 + int(bx) % (field_w - 2)
    byi = field_y + 1 + int(by) % (field_h - 2)
    t.put(bxi, byi, '●', fg=Color.LIGHT_RED)

    # sine wave across the field
    for cx in range(field_x + 1, field_x + field_w - 1):
        norm = (cx - field_x - 1) / (field_w - 2)
        wave_y = int((math.sin(norm * 2 * math.pi + frame * 0.1) + 1) / 2 * (field_h - 3))
        wy = field_y + 1 + wave_y
        if wy != byi or cx != bxi:   # don't overwrite ball
            t.put(cx, wy, '·', fg=Color.BLUE)

    # ── progress bar ────────────────────────────────────────────────────────
    bar_y = H - 2
    bar_w = W - 4
    filled = int((frame % 100) / 100 * bar_w)
    t.print(2, bar_y, '[', fg=Color.WHITE)
    t.print(3, bar_y, '█' * filled + '░' * (bar_w - filled),
            fg=Color.LIGHT_GREEN, bg=Color.BLACK)
    t.print(3 + bar_w, bar_y, ']', fg=Color.WHITE)

    # ── footer ──────────────────────────────────────────────────────────────
    hint = " Press Q to quit "
    t.print((W - len(hint)) // 2, H - 1, hint, fg=Color.DARK_GRAY)


def main():
    with Terminal() as t:
        frame = 0
        bx, by = 0.0, 0.0
        vx, vy = 0.7, 0.4
        score  = 0
        start  = time.time()
        W, H   = t.width, t.height

        field_w = W - 32 - 2
        field_h = H - 6

        while True:
            # Input (non-blocking)
            if kbhit():
                ch = getch()
                if ch.lower() == 'q' or ch == '\x1b':
                    break

            # Physics
            bx += vx
            by += vy
            if bx < 0 or bx >= field_w - 2:
                vx *= -1
                score += 1
            if by < 0 or by >= field_h - 2:
                vy *= -1
                score += 1
            bx = max(0, min(bx, field_w - 2))
            by = max(0, min(by, field_h - 2))

            # Draw into back buffer
            draw_frame(t, frame, bx, by, score, time.time() - start)

            # Flush only dirty cells to terminal
            t.render()

            frame += 1
            time.sleep(0.033)   # ~30 fps


if __name__ == "__main__":
    main()