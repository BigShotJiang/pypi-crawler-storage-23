"""
conio.py — A Python library mimicking the functionality of conio.h / platform_conio.h.

Supports Windows (msvcrt) and Unix/macOS (termios).
"""

import sys
import os

# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------
_IS_WINDOWS = sys.platform == "win32"

if _IS_WINDOWS:
    import msvcrt
    import ctypes
    from ctypes import wintypes
else:
    import tty
    import termios
    import select
    import fcntl


# ---------------------------------------------------------------------------
# ANSI color codes (used on Unix; mapped to Windows API on Windows)
# ---------------------------------------------------------------------------
class Color:
    BLACK   = 0
    BLUE    = 1
    GREEN   = 2
    CYAN    = 3
    RED     = 4
    MAGENTA = 5
    BROWN   = 6   # YELLOW on some systems
    WHITE   = 7
    # Bright variants
    DARK_GRAY      = 8
    LIGHT_BLUE     = 9
    LIGHT_GREEN    = 10
    LIGHT_CYAN     = 11
    LIGHT_RED      = 12
    LIGHT_MAGENTA  = 13
    YELLOW         = 14
    BRIGHT_WHITE   = 15


# ANSI foreground / background escape sequences
_ANSI_FG = [
    "\033[0;30m",  # BLACK
    "\033[0;34m",  # BLUE
    "\033[0;32m",  # GREEN
    "\033[0;36m",  # CYAN
    "\033[0;31m",  # RED
    "\033[0;35m",  # MAGENTA
    "\033[0;33m",  # BROWN/YELLOW
    "\033[0;37m",  # WHITE
    "\033[1;30m",  # DARK_GRAY
    "\033[1;34m",  # LIGHT_BLUE
    "\033[1;32m",  # LIGHT_GREEN
    "\033[1;36m",  # LIGHT_CYAN
    "\033[1;31m",  # LIGHT_RED
    "\033[1;35m",  # LIGHT_MAGENTA
    "\033[1;33m",  # YELLOW
    "\033[1;37m",  # BRIGHT_WHITE
]

_ANSI_BG = [
    "\033[40m",  # BLACK
    "\033[44m",  # BLUE
    "\033[42m",  # GREEN
    "\033[46m",  # CYAN
    "\033[41m",  # RED
    "\033[45m",  # MAGENTA
    "\033[43m",  # BROWN/YELLOW
    "\033[47m",  # WHITE
    "\033[100m", # DARK_GRAY
    "\033[104m", # LIGHT_BLUE
    "\033[102m", # LIGHT_GREEN
    "\033[106m", # LIGHT_CYAN
    "\033[101m", # LIGHT_RED
    "\033[105m", # LIGHT_MAGENTA
    "\033[103m", # YELLOW
    "\033[107m", # BRIGHT_WHITE
]

_ANSI_RESET = "\033[0m"

_current_fg = Color.WHITE
_current_bg = Color.BLACK


# ---------------------------------------------------------------------------
# Keyboard input
# ---------------------------------------------------------------------------

def getch() -> str:
    """
    Read a single character from the keyboard without waiting for Enter.
    The character is NOT echoed to the screen.
    Returns a string (one or more chars; two chars for special keys on Windows).
    """
    if _IS_WINDOWS:
        ch = msvcrt.getch()
        # Special keys (arrows, F-keys, etc.) send a two-byte sequence
        if ch in (b'\x00', b'\xe0'):
            ch2 = msvcrt.getch()
            return ch.decode('latin-1') + ch2.decode('latin-1')
        return ch.decode('latin-1')
    else:
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            # Handle escape sequences (arrows, etc.)
            if ch == '\x1b':
                # Try to read up to 2 more bytes without blocking
                old_flags = fcntl.fcntl(fd, fcntl.F_GETFL)
                fcntl.fcntl(fd, fcntl.F_SETFL, old_flags | os.O_NONBLOCK)
                try:
                    rest = sys.stdin.read(2)
                    ch += rest
                except BlockingIOError:
                    pass
                finally:
                    fcntl.fcntl(fd, fcntl.F_SETFL, old_flags)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return ch


def getche() -> str:
    """
    Read a single character from the keyboard without waiting for Enter.
    The character IS echoed to the screen.
    """
    ch = getch()
    sys.stdout.write(ch[0])  # only echo the printable part
    sys.stdout.flush()
    return ch


def kbhit() -> bool:
    """
    Returns True if a keypress is waiting in the input buffer, False otherwise.
    """
    if _IS_WINDOWS:
        return msvcrt.kbhit()
    else:
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ready, _, _ = select.select([sys.stdin], [], [], 0)
            return bool(ready)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ---------------------------------------------------------------------------
# Screen control
# ---------------------------------------------------------------------------

def clrscr():
    """Clear the terminal screen."""
    if _IS_WINDOWS:
        os.system("cls")
    else:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def gotoxy(x: int, y: int):
    """
    Move the cursor to column x, row y (1-based, like conio.h).
    """
    if _IS_WINDOWS:
        _win_gotoxy(x, y)
    else:
        sys.stdout.write(f"\033[{y};{x}H")
        sys.stdout.flush()


def wherex() -> int:
    """Return the current cursor column (1-based)."""
    x, _ = _get_cursor_pos()
    return x


def wherey() -> int:
    """Return the current cursor row (1-based)."""
    _, y = _get_cursor_pos()
    return y


def _get_cursor_pos():
    """Return (col, row) of the current cursor position (1-based)."""
    if _IS_WINDOWS:
        return _win_get_cursor_pos()
    else:
        # Use ANSI DSR (Device Status Report)
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            sys.stdout.write("\033[6n")
            sys.stdout.flush()
            buf = ""
            while True:
                ch = sys.stdin.read(1)
                buf += ch
                if ch == 'R':
                    break
            # Response format: \033[row;colR
            buf = buf.strip("\033[R")
            row, col = buf.split(";")
            return int(col), int(row)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ---------------------------------------------------------------------------
# Color control
# ---------------------------------------------------------------------------

def textcolor(color: int):
    """Set the foreground (text) color. Use Color.* constants."""
    global _current_fg
    _current_fg = color & 0x0F
    if _IS_WINDOWS:
        _win_set_color()
    else:
        sys.stdout.write(_ANSI_FG[_current_fg])
        sys.stdout.flush()


def textbackground(color: int):
    """Set the background color. Use Color.* constants."""
    global _current_bg
    _current_bg = color & 0x07  # background only supports 8 colors in classic conio
    if _IS_WINDOWS:
        _win_set_color()
    else:
        sys.stdout.write(_ANSI_BG[_current_bg])
        sys.stdout.flush()


def normvideo():
    """Reset colors to terminal defaults."""
    global _current_fg, _current_bg
    _current_fg = Color.WHITE
    _current_bg = Color.BLACK
    if _IS_WINDOWS:
        _win_set_color()
    else:
        sys.stdout.write(_ANSI_RESET)
        sys.stdout.flush()


def highvideo():
    """Enable high-intensity (bright) text."""
    textcolor(_current_fg | 8)


def lowvideo():
    """Disable high-intensity (switch to dark variant)."""
    textcolor(_current_fg & 7)


# ---------------------------------------------------------------------------
# Colored output
# ---------------------------------------------------------------------------

def cprintf(text: str, fg: int = None, bg: int = None, end: str = ""):
    """
    Print text with optional foreground and background colors.
    After printing, colors are restored to what they were before the call.
    """
    prev_fg, prev_bg = _current_fg, _current_bg
    if fg is not None:
        textcolor(fg)
    if bg is not None:
        textbackground(bg)
    sys.stdout.write(text + end)
    sys.stdout.flush()
    # Restore previous colors
    textcolor(prev_fg)
    textbackground(prev_bg)


def cputs(text: str):
    """Write a string to the console (no newline, like conio cputs)."""
    sys.stdout.write(text)
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Windows-specific helpers (using ctypes / Win32 Console API)
# ---------------------------------------------------------------------------

if _IS_WINDOWS:
    _STDOUT_HANDLE = ctypes.windll.kernel32.GetStdHandle(-11)

    class _COORD(ctypes.Structure):
        _fields_ = [("X", wintypes.SHORT), ("Y", wintypes.SHORT)]

    class _CONSOLE_SCREEN_BUFFER_INFO(ctypes.Structure):
        _fields_ = [
            ("dwSize",              _COORD),
            ("dwCursorPosition",    _COORD),
            ("wAttributes",         wintypes.WORD),
            ("srWindow",            ctypes.c_int * 4),
            ("dwMaximumWindowSize", _COORD),
        ]

    def _win_gotoxy(x: int, y: int):
        coord = _COORD(x - 1, y - 1)
        ctypes.windll.kernel32.SetConsoleCursorPosition(_STDOUT_HANDLE, coord)

    def _win_get_cursor_pos():
        info = _CONSOLE_SCREEN_BUFFER_INFO()
        ctypes.windll.kernel32.GetConsoleScreenBufferInfo(_STDOUT_HANDLE, ctypes.byref(info))
        return info.dwCursorPosition.X + 1, info.dwCursorPosition.Y + 1

    def _win_set_color():
        attr = _current_fg | (_current_bg << 4)
        ctypes.windll.kernel32.SetConsoleTextAttribute(_STDOUT_HANDLE, attr)


# ---------------------------------------------------------------------------
# Convenience / extra utilities
# ---------------------------------------------------------------------------

def getpass_conio(prompt: str = "Password: ") -> str:
    """Read a password without echoing characters (like getpass but via getch)."""
    sys.stdout.write(prompt)
    sys.stdout.flush()
    chars = []
    while True:
        ch = getch()
        if ch in ('\r', '\n'):
            break
        elif ch in ('\x08', '\x7f'):  # backspace
            if chars:
                chars.pop()
                sys.stdout.write('\b \b')
                sys.stdout.flush()
        elif ch.isprintable():
            chars.append(ch)
    sys.stdout.write('\n')
    return ''.join(chars)


def putch(ch: str):
    """Write a single character to stdout (like conio putch)."""
    sys.stdout.write(ch[0])
    sys.stdout.flush()


def ungetch(ch: str):
    """Push a character back into the input buffer."""
    if _IS_WINDOWS:
        msvcrt.ungetch(ch.encode('latin-1'))
    else:
        # Unix: use termios to push into stdin — limited support
        fd = sys.stdin.fileno()
        fcntl.ioctl(fd, termios.TIOCSTI, ch.encode())


# ---------------------------------------------------------------------------
# __all__
# ---------------------------------------------------------------------------
__all__ = [
    "Color",
    "getch", "getche", "kbhit",
    "clrscr", "gotoxy", "wherex", "wherey",
    "textcolor", "textbackground", "normvideo", "highvideo", "lowvideo",
    "cprintf", "cputs", "putch", "ungetch",
    "getpass_conio",
]