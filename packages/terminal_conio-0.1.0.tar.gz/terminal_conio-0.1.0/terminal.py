"""
terminal.py — In-place terminal renderer.

Instead of clearing and redrawing everything each frame, this maintains a
front/back buffer pair. Only cells that actually changed are written to the
terminal, keeping flicker and cursor movement to a minimum.

Usage:
    from terminal import Terminal, Cell, Color

    t = Terminal()
    t.print(0, 0, "Hello, world!", fg=Color.YELLOW)
    t.print(0, 1, "Score: 42",     fg=Color.CYAN)
    t.render()   # only writes changed cells

    # next frame — only "42" region gets redrawn
    t.print(0, 1, "Score: 99",     fg=Color.CYAN)
    t.render()
"""

import sys
import os
import shutil
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# Platform
# ---------------------------------------------------------------------------
_IS_WINDOWS = sys.platform == "win32"

if _IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    _STDOUT_HANDLE = ctypes.windll.kernel32.GetStdHandle(-11)

    class _COORD(ctypes.Structure):
        _fields_ = [("X", wintypes.SHORT), ("Y", wintypes.SHORT)]

    def _win_gotoxy(x: int, y: int):
        ctypes.windll.kernel32.SetConsoleCursorPosition(_STDOUT_HANDLE, _COORD(x, y))

    def _win_set_attr(fg: int, bg: int):
        ctypes.windll.kernel32.SetConsoleTextAttribute(_STDOUT_HANDLE, fg | (bg << 4))

    def _win_hide_cursor():
        class _CCI(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("bVisible", wintypes.BOOL)]
        cci = _CCI(1, False)
        ctypes.windll.kernel32.SetConsoleCursorInfo(_STDOUT_HANDLE, ctypes.byref(cci))

    def _win_show_cursor():
        class _CCI(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("bVisible", wintypes.BOOL)]
        cci = _CCI(25, True)
        ctypes.windll.kernel32.SetConsoleCursorInfo(_STDOUT_HANDLE, ctypes.byref(cci))

else:
    import termios, tty

# ---------------------------------------------------------------------------
# Color constants (4-bit, classic conio palette)
# ---------------------------------------------------------------------------
class Color:
    BLACK          = 0
    BLUE           = 1
    GREEN          = 2
    CYAN           = 3
    RED            = 4
    MAGENTA        = 5
    YELLOW         = 6
    WHITE          = 7
    DARK_GRAY      = 8
    LIGHT_BLUE     = 9
    LIGHT_GREEN    = 10
    LIGHT_CYAN     = 11
    LIGHT_RED      = 12
    LIGHT_MAGENTA  = 13
    BRIGHT_YELLOW  = 14
    BRIGHT_WHITE   = 15

# ANSI escape mappings (Unix)
_FG = [
    "\033[30m", "\033[34m", "\033[32m", "\033[36m",
    "\033[31m", "\033[35m", "\033[33m", "\033[37m",
    "\033[90m", "\033[94m", "\033[92m", "\033[96m",
    "\033[91m", "\033[95m", "\033[93m", "\033[97m",
]
_BG = [
    "\033[40m",  "\033[44m",  "\033[42m",  "\033[46m",
    "\033[41m",  "\033[45m",  "\033[43m",  "\033[47m",
    "\033[100m", "\033[104m", "\033[102m", "\033[106m",
    "\033[101m", "\033[105m", "\033[103m", "\033[107m",
]
_RESET = "\033[0m"

# ---------------------------------------------------------------------------
# Cell — one character slot in the buffer
# ---------------------------------------------------------------------------
@dataclass
class Cell:
    char: str  = ' '
    fg:   int  = Color.WHITE
    bg:   int  = Color.BLACK
    bold: bool = False

    def __eq__(self, other):
        return (self.char == other.char and
                self.fg   == other.fg   and
                self.bg   == other.bg   and
                self.bold == other.bold)

    def copy(self):
        return Cell(self.char, self.fg, self.bg, self.bold)

# ---------------------------------------------------------------------------
# Terminal — the main renderer
# ---------------------------------------------------------------------------
class Terminal:
    """
    Double-buffered, dirty-cell terminal renderer.

    Coordinates are 0-based (col, row).
    """

    def __init__(self, width: int = None, height: int = None):
        tw, th = shutil.get_terminal_size()
        self.width  = width  or tw
        self.height = height or th

        # back  = what we want to show
        # front = what is currently on screen
        self._back  = self._make_buffer()
        self._front = self._make_buffer(char='\x00')  # sentinel — forces full first draw

        self._cursor_hidden = False
        self._out = sys.stdout

        # Cursor tracking to avoid redundant gotoxy calls
        self._cur_x: Optional[int] = None
        self._cur_y: Optional[int] = None
        # Last color written (avoid redundant escape sequences)
        self._cur_fg: Optional[int] = None
        self._cur_bg: Optional[int] = None

    # ------------------------------------------------------------------
    # Buffer helpers
    # ------------------------------------------------------------------
    def _make_buffer(self, char=' '):
        return [[Cell(char) for _ in range(self.width)]
                for _ in range(self.height)]

    def _back_cell(self, col: int, row: int) -> Cell:
        return self._back[row][col]

    # ------------------------------------------------------------------
    # Public draw API
    # ------------------------------------------------------------------
    def put(self, col: int, row: int, char: str,
            fg: int = Color.WHITE, bg: int = Color.BLACK, bold: bool = False):
        """Write a single character into the back buffer."""
        if 0 <= col < self.width and 0 <= row < self.height:
            c = self._back[row][col]
            c.char = char
            c.fg   = fg
            c.bg   = bg
            c.bold = bold

    def print(self, col: int, row: int, text: str,
              fg: int = Color.WHITE, bg: int = Color.BLACK, bold: bool = False):
        """Write a string into the back buffer starting at (col, row)."""
        for i, ch in enumerate(text):
            self.put(col + i, row, ch, fg, bg, bold)

    def hline(self, col: int, row: int, length: int, char: str = '─',
              fg: int = Color.WHITE, bg: int = Color.BLACK):
        """Draw a horizontal line."""
        self.print(col, row, char * length, fg, bg)

    def vline(self, col: int, row: int, length: int, char: str = '│',
              fg: int = Color.WHITE, bg: int = Color.BLACK):
        """Draw a vertical line."""
        for i in range(length):
            self.put(col, row + i, char, fg, bg)

    def box(self, col: int, row: int, w: int, h: int,
            fg: int = Color.WHITE, bg: int = Color.BLACK,
            style: str = 'single'):
        """
        Draw a box.  style='single' or 'double'.
        """
        if style == 'double':
            tl,tr,bl,br,hz,vt = '╔','╗','╚','╝','═','║'
        else:
            tl,tr,bl,br,hz,vt = '┌','┐','└','┘','─','│'

        self.put(col,         row,       tl, fg, bg)
        self.put(col + w - 1, row,       tr, fg, bg)
        self.put(col,         row + h-1, bl, fg, bg)
        self.put(col + w - 1, row + h-1, br, fg, bg)
        self.hline(col + 1, row,       w - 2, hz, fg, bg)
        self.hline(col + 1, row + h-1, w - 2, hz, fg, bg)
        self.vline(col,       row + 1, h - 2, vt, fg, bg)
        self.vline(col + w-1, row + 1, h - 2, vt, fg, bg)

    def fill(self, col: int, row: int, w: int, h: int,
             char: str = ' ', fg: int = Color.WHITE, bg: int = Color.BLACK):
        """Fill a rectangular region."""
        for r in range(row, row + h):
            self.print(col, r, char * w, fg, bg)

    def clear(self, fg: int = Color.WHITE, bg: int = Color.BLACK):
        """Clear the entire back buffer."""
        self.fill(0, 0, self.width, self.height, ' ', fg, bg)

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def render(self):
        """
        Flush the back buffer to the terminal.
        Only cells that differ from the front buffer are written.
        Cursor movements and color changes are batched to minimise writes.
        """
        buf = []          # build one big string and write once
        self._cur_x = None
        self._cur_y = None
        self._cur_fg = None
        self._cur_bg = None

        for row in range(self.height):
            for col in range(self.width):
                back  = self._back[row][col]
                front = self._front[row][col]

                if back == front:
                    continue  # skip — nothing changed

                # Move cursor (only if not already at the right position)
                if self._cur_x != col or self._cur_y != row:
                    buf.append(self._escape_gotoxy(col, row))
                    self._cur_x = col
                    self._cur_y = row

                # Set color (only if changed)
                if self._cur_fg != back.fg or self._cur_bg != back.bg:
                    buf.append(self._escape_color(back.fg, back.bg, back.bold))
                    self._cur_fg = back.fg
                    self._cur_bg = back.bg

                buf.append(back.char)
                self._cur_x += 1

                # Update front buffer
                front.char = back.char
                front.fg   = back.fg
                front.bg   = back.bg
                front.bold = back.bold

        if buf:
            buf.append(_RESET)
            self._out.write(''.join(buf))
            self._out.flush()

    def _escape_gotoxy(self, col: int, row: int) -> str:
        # ANSI uses 1-based rows/cols
        return f"\033[{row+1};{col+1}H"

    def _escape_color(self, fg: int, bg: int, bold: bool = False) -> str:
        b = "\033[1m" if bold else "\033[22m"
        return f"{b}{_FG[fg & 15]}{_BG[bg & 7]}"

    # ------------------------------------------------------------------
    # Cursor visibility
    # ------------------------------------------------------------------
    def hide_cursor(self):
        if not self._cursor_hidden:
            if _IS_WINDOWS:
                _win_hide_cursor()
            else:
                self._out.write("\033[?25l")
                self._out.flush()
            self._cursor_hidden = True

    def show_cursor(self):
        if self._cursor_hidden:
            if _IS_WINDOWS:
                _win_show_cursor()
            else:
                self._out.write("\033[?25h")
                self._out.flush()
            self._cursor_hidden = False

    # ------------------------------------------------------------------
    # Context manager — hides cursor, restores on exit
    # ------------------------------------------------------------------
    def __enter__(self):
        self.hide_cursor()
        return self

    def __exit__(self, *_):
        self.show_cursor()
        # Move cursor below the drawn area
        self._out.write(f"\033[{self.height+1};1H")
        self._out.write(_RESET)
        self._out.flush()

    # ------------------------------------------------------------------
    # Resize
    # ------------------------------------------------------------------
    def resize(self, width: int = None, height: int = None):
        """Re-detect terminal size and rebuild buffers."""
        tw, th = shutil.get_terminal_size()
        self.width  = width  or tw
        self.height = height or th
        self._back  = self._make_buffer()
        self._front = self._make_buffer(char='\x00')