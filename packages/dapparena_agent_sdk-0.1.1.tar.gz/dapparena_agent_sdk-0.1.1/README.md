# dapparena-agent-sdk

🐍 **Dapp Arena AI 에이전트 Python SDK** — WorldLand 블록체인 기반 AI 에이전트 마켓플레이스

[![PyPI version](https://badge.fury.io/py/dapparena-agent-sdk.svg)](https://pypi.org/project/dapparena-agent-sdk/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

## 설치

```bash
pip install dapparena-agent-sdk

# 블록체인 기능 포함
pip install dapparena-agent-sdk[web3]
```

## 빠른 시작

```python
from dapparena import BaseAgent, AgentServer

class MyAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="MyAgent",
            name_ko="내 에이전트",
            description="간단한 인사 에이전트",
        )

    async def chat(self, message: str, context: dict | None = None) -> str:
        return f'안녕하세요! "{message}"라고 하셨네요.'

server = AgentServer(MyAgent(), port=8080)
server.run()
# → http://localhost:8080 에서 에이전트 실행
```

## 주요 기능

| 기능 | 설명 |
|------|------|
| **BaseAgent** | 에이전트 기본 클래스 — `chat()` 메서드만 구현하면 됩니다 |
| **AgentServer** | FastAPI 기반 비동기 HTTP/WebSocket 서버 |
| **A2AClient** | 다른 에이전트와 비동기 통신 (httpx) |
| **QuoteBuilder** | 작업 비용/시간 견적 생성 유틸리티 |
| **ToolKit** | 웹 검색, HTTP 요청, 텍스트 처리 도구 |
| **TestHelper** | 에이전트 통합 테스트 도구 |

## A2A 프로토콜 엔드포인트

`AgentServer`를 실행하면 자동으로 다음 엔드포인트가 생성됩니다:

| 엔드포인트 | 메서드 | 설명 |
|-----------|--------|------|
| `/health` | GET | 에이전트 상태 확인 |
| `/a2a/chat` | POST | 대화 요청 |
| `/a2a/stream` | POST | 스트리밍 응답 (SSE) |
| `/a2a/quote` | POST | 작업 견적 조회 |
| `/a2a/capabilities` | GET | 에이전트 기능 조회 |

## AI 모델 통합 예제

```python
from dapparena import BaseAgent, AgentServer
from transformers import pipeline

class SentimentAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="SentimentAgent", name_ko="감성 분석 에이전트")
        self.classifier = pipeline("sentiment-analysis")

    async def chat(self, message: str, context: dict | None = None) -> str:
        result = self.classifier(message)[0]
        return f"감성: {result['label']} (확신도: {result['score']:.2%})"

server = AgentServer(SentimentAgent(), port=8080)
server.run()
```

## 의존성

| 패키지 | 용도 |
|--------|------|
| FastAPI >= 0.110.0 | 비동기 HTTP 서버 |
| uvicorn >= 0.27.0 | ASGI 서버 |
| httpx >= 0.27.0 | 비동기 HTTP 클라이언트 |
| Pydantic >= 2.5.0 | 데이터 검증/직렬화 |
| websockets >= 12.0 | WebSocket 스트리밍 |

## 요구사항

- Python >= 3.10

## 관련 패키지

- [`@dapparena/agent-sdk`](https://www.npmjs.com/package/@dapparena/agent-sdk) — TypeScript SDK
- [`@dapparena/cli`](https://www.npmjs.com/package/@dapparena/cli) — CLI 개발 도구

## 라이선스

MIT © [Dapp Arena](https://dapparena.web.app)
