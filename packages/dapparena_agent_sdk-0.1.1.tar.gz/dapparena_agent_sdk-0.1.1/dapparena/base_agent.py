"""BaseAgent — Abstract base class for Dapp Arena agents."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import AsyncGenerator

from .types import AgentCapabilities, AgentInfo, ChatRequest, QuoteRequest, QuoteResponse


class BaseAgent(ABC):
    """
    Base class for all Dapp Arena agents.

    Developers must subclass this and implement at minimum the `chat()` method.
    Optionally override `chat_stream()` for streaming support and
    `get_quote()` for cost estimation.

    Example:
        class MyAgent(BaseAgent):
            def __init__(self):
                super().__init__(
                    name="MyAgent",
                    name_ko="내 에이전트",
                    description="A helpful assistant",
                )

            async def chat(self, message: str, context: dict | None = None) -> str:
                return f"You said: {message}"
    """

    def __init__(
        self,
        name: str = "DappArenaAgent",
        name_ko: str = "",
        description: str = "",
        version: str = "1.0.0",
        capabilities: AgentCapabilities | None = None,
        price_range: str = "1~5 WL",
        owner_address: str = "",
    ):
        self.info = AgentInfo(
            name=name,
            name_ko=name_ko or name,
            description=description,
            version=version,
            capabilities=capabilities or AgentCapabilities(),
            price_range=price_range,
            owner_address=owner_address,
        )

    @abstractmethod
    async def chat(self, message: str, context: dict | None = None) -> str:
        """
        Handle a chat message and return a response.

        Args:
            message: The user's message.
            context: Optional session context (session_id, history, etc.)

        Returns:
            The agent's response as a string.
        """
        ...

    async def chat_stream(
        self, message: str, context: dict | None = None
    ) -> AsyncGenerator[str, None]:
        """
        Handle a chat message and yield response tokens for streaming.

        Default implementation calls `chat()` and yields the full response.
        Override for true token-by-token streaming.

        Args:
            message: The user's message.
            context: Optional session context.

        Yields:
            Response tokens as strings.
        """
        response = await self.chat(message, context)
        yield response

    async def get_quote(self, request: QuoteRequest) -> QuoteResponse:
        """
        Generate a cost/time estimate for a task.

        Default implementation returns a generic quote.
        Override for accurate pricing.

        Args:
            request: The quote request with task description.

        Returns:
            A QuoteResponse with cost and duration.
        """
        return QuoteResponse(
            task=request.task_description[:60],
            cost=self.info.price_range.split("~")[0].strip() + " WL",
            duration="약 10분",
            deadline_seconds=600,
        )

    def get_capabilities(self) -> AgentCapabilities:
        """Return this agent's capabilities."""
        return self.info.capabilities

    def get_info(self) -> AgentInfo:
        """Return full agent metadata."""
        return self.info
