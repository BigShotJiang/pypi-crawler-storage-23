"""QuoteBuilder — Helper for generating accurate task cost estimates."""

from __future__ import annotations

from .types import QuoteResponse


class QuoteBuilder:
    """
    Helper to build structured task quotes.

    Example:
        builder = QuoteBuilder(base_rate_wl=2.0, per_minute_wl=0.1)
        quote = builder.build(
            task="법률 문서 분석",
            estimated_minutes=15,
            complexity_multiplier=1.5,
        )
        # QuoteResponse(task="법률 문서 분석", cost="3.25 WL", duration="약 15분", ...)
    """

    def __init__(
        self,
        base_rate_wl: float = 1.0,
        per_minute_wl: float = 0.1,
        min_cost_wl: float = 0.5,
        max_cost_wl: float = 50.0,
    ):
        self.base_rate = base_rate_wl
        self.per_minute = per_minute_wl
        self.min_cost = min_cost_wl
        self.max_cost = max_cost_wl

    def build(
        self,
        task: str,
        estimated_minutes: int = 10,
        complexity_multiplier: float = 1.0,
        extra_details: dict | None = None,
    ) -> QuoteResponse:
        """
        Build a quote for a task.

        Args:
            task: Task description (will be truncated to 60 chars).
            estimated_minutes: Estimated time in minutes.
            complexity_multiplier: 1.0 = normal, 1.5 = complex, 2.0 = very complex.
            extra_details: Additional quote metadata.

        Returns:
            A complete QuoteResponse.
        """
        raw_cost = (self.base_rate + self.per_minute * estimated_minutes) * complexity_multiplier
        cost = max(self.min_cost, min(self.max_cost, raw_cost))
        cost_rounded = round(cost, 2)

        # Convert to wei (1 WL = 10^18 wei)
        cost_wei = int(cost_rounded * 10**18)

        deadline_seconds = max(300, estimated_minutes * 60 + 120)  # min 5 min + 2 min buffer

        return QuoteResponse(
            task=task[:60] if len(task) > 60 else task,
            cost=f"{cost_rounded} WL",
            duration=f"약 {estimated_minutes}분",
            cost_wei=cost_wei,
            deadline_seconds=deadline_seconds,
            details=extra_details or {},
        )

    def estimate_minutes(
        self,
        text_length: int = 0,
        num_documents: int = 1,
        base_minutes: int = 5,
    ) -> int:
        """
        Estimate processing time based on input size.

        Args:
            text_length: Total input text characters.
            num_documents: Number of documents to process.
            base_minutes: Minimum processing time.

        Returns:
            Estimated minutes.
        """
        text_minutes = text_length // 2000  # ~2 min per 2000 chars
        doc_minutes = num_documents * 2
        return max(base_minutes, text_minutes + doc_minutes)
