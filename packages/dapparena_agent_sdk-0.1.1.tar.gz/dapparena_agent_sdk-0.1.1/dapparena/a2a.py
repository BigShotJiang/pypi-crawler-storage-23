"""A2AClient — Client for communicating with other Dapp Arena agents."""

from __future__ import annotations

from typing import AsyncGenerator

import httpx

from .types import A2AMessage, A2AResponse, ChatResponse, HealthResponse, QuoteRequest, QuoteResponse, StreamChunk


class A2AClient:
    """
    Client for Agent-to-Agent communication.

    Enables your agent to call other agents in the Dapp Arena ecosystem.

    Example:
        client = A2AClient()

        # Chat with another agent
        response = await client.chat("http://other-agent:8080", "Analyze this data")

        # Stream response
        async for token in client.chat_stream("http://other-agent:8080", "Summarize"):
            print(token, end="")

        # Get a quote
        quote = await client.get_quote("http://other-agent:8080", "Write a report")
    """

    def __init__(
        self,
        timeout: float = 60.0,
        api_key: str = "",
    ):
        self._timeout = timeout
        self._api_key = api_key

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["X-API-Key"] = self._api_key
        return headers

    async def health(self, agent_url: str) -> HealthResponse:
        """Check if an agent is healthy."""
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{agent_url}/health", headers=self._headers())
            resp.raise_for_status()
            return HealthResponse(**resp.json())

    async def chat(
        self,
        agent_url: str,
        message: str,
        context: dict | None = None,
        session_id: str = "",
    ) -> ChatResponse:
        """Send a chat message to another agent and get a response."""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{agent_url}/a2a/chat",
                json={
                    "message": message,
                    "context": context or {},
                    "session_id": session_id,
                },
                headers=self._headers(),
            )
            resp.raise_for_status()
            return ChatResponse(**resp.json())

    async def chat_stream(
        self,
        agent_url: str,
        message: str,
        context: dict | None = None,
    ) -> AsyncGenerator[str, None]:
        """Stream a chat response from another agent."""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            async with client.stream(
                "POST",
                f"{agent_url}/a2a/stream",
                json={"message": message, "context": context or {}},
                headers=self._headers(),
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if line.startswith("data: "):
                        import json
                        data = json.loads(line[6:])
                        chunk = StreamChunk(**data)
                        if chunk.done:
                            break
                        yield chunk.token

    async def get_quote(
        self,
        agent_url: str,
        task_description: str,
        context: dict | None = None,
    ) -> QuoteResponse:
        """Request a quote from another agent."""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{agent_url}/a2a/quote",
                json={"task_description": task_description, "context": context or {}},
                headers=self._headers(),
            )
            resp.raise_for_status()
            return QuoteResponse(**resp.json())

    async def capabilities(self, agent_url: str) -> dict:
        """Get another agent's capabilities."""
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{agent_url}/a2a/capabilities",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return resp.json()
