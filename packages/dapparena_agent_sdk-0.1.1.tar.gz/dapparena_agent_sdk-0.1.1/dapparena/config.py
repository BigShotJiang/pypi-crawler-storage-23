"""
DappArenaConfig — 설정 관리 모듈

dapparena.config.json + .env + 환경변수를 통합 관리합니다.

Example:
    from dapparena.config import DappArenaConfig

    config = DappArenaConfig.load()
    print(config.name)
    print(config.server.port)
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8080


@dataclass
class RegistryConfig:
    rpc_url: str = "https://seoul.worldland.foundation"
    registry_address: str = "0xCD49067f656d7c0e3d3eb72407906e55334e3600"
    escrow_address: str = "0xE362a851C3B8410D356330dF3dfcbB0078a9d747"
    agent_nft_address: str = "0xa89AF1E0b96fa6635A3f4bccb37E6C4232dA7222"
    chain_id: int = 103


@dataclass
class Phase2Config:
    erc6551_registry: str = "0x1d30D454805b803251f26333F5A03F5c91A2feB2"
    agent_tba: str = "0x6085900C3f88F9DC8AA14E26F3aCB5c40079c4F9"
    did_registry: str = "0xae843650c599537c6a773D867A0387e1E989342C"
    x402_payment: str = "0xcaC1a0530C256b127BA2df36c61aafFaDeA92952"
    spending_guard: str = "0x9eCB3eC6479f5Ee82F13dE526d653b5623dAb432"


@dataclass
class GatewayConfig:
    url: str = "http://localhost:9000"
    nj_server_url: str = "https://api.worldland.net"
    nj_server_url_local: str = "http://localhost:9100"


@dataclass
class HostingConfig:
    type: str = "external"
    endpoint_url: str = ""
    a2a_url: str = ""
    heartbeat_interval: int = 300
    cors_origins: list[str] = field(
        default_factory=lambda: ["https://dapparena.web.app", "http://localhost:3000"]
    )


@dataclass
class RoleConfig:
    name: str = ""
    desc: str = ""
    color: str = "#818cf8"


@dataclass
class DappArenaConfig:
    """DappArena 에이전트 프로젝트 설정"""

    name: str = "MyAgent"
    name_ko: str = ""
    description: str = "A custom AI agent on Dapp Arena"
    category: str = "custom"
    category_ko: str = ""
    emoji: str = "🤖"
    version: str = "1.0.0"
    language: str = "python"
    price_range: str = "1~5 WL"
    owner_address: str = ""
    roles: list[RoleConfig] = field(default_factory=list)
    server: ServerConfig = field(default_factory=ServerConfig)
    registry: RegistryConfig = field(default_factory=RegistryConfig)
    phase2: Phase2Config = field(default_factory=Phase2Config)
    gateway: GatewayConfig = field(default_factory=GatewayConfig)
    hosting: HostingConfig = field(default_factory=HostingConfig)
    developer_api_key: str = ""

    @classmethod
    def load(cls, config_path: Optional[str] = None) -> "DappArenaConfig":
        """
        dapparena.config.json을 로드합니다.

        Args:
            config_path: 설정 파일 경로. None이면 현재 디렉토리에서 검색.

        Returns:
            DappArenaConfig 인스턴스
        """
        if config_path is None:
            config_path = cls._find_config()
        if config_path is None:
            raise FileNotFoundError(
                "dapparena.config.json을 찾을 수 없습니다. "
                "dapparena init 으로 프로젝트를 생성하세요."
            )

        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        config = cls()
        config.name = data.get("name", config.name)
        config.name_ko = data.get("nameKo", config.name_ko)
        config.description = data.get("description", config.description)
        config.category = data.get("category", config.category)
        config.category_ko = data.get("categoryKo", config.category_ko)
        config.emoji = data.get("emoji", config.emoji)
        config.version = data.get("version", config.version)
        config.language = data.get("language", config.language)
        config.price_range = data.get("priceRange", config.price_range)
        config.owner_address = data.get("ownerAddress", config.owner_address)

        # Server
        if "server" in data:
            s = data["server"]
            config.server = ServerConfig(
                host=s.get("host", "0.0.0.0"),
                port=s.get("port", 8080),
            )

        # Registry
        if "registry" in data:
            r = data["registry"]
            config.registry = RegistryConfig(
                rpc_url=r.get("rpcUrl", config.registry.rpc_url),
                registry_address=r.get("registryAddress", config.registry.registry_address),
                escrow_address=r.get("escrowAddress", config.registry.escrow_address),
                agent_nft_address=r.get("agentNFTAddress", config.registry.agent_nft_address),
                chain_id=r.get("chainId", config.registry.chain_id),
            )

        # Phase2
        if "phase2" in data:
            p = data["phase2"]
            config.phase2 = Phase2Config(
                erc6551_registry=p.get("erc6551Registry", config.phase2.erc6551_registry),
                agent_tba=p.get("agentTBA", config.phase2.agent_tba),
                did_registry=p.get("didRegistry", config.phase2.did_registry),
                x402_payment=p.get("x402Payment", config.phase2.x402_payment),
                spending_guard=p.get("spendingGuard", config.phase2.spending_guard),
            )

        # Gateway
        if "gateway" in data:
            g = data["gateway"]
            config.gateway = GatewayConfig(
                url=g.get("url", config.gateway.url),
                nj_server_url=g.get("njServerUrl", config.gateway.nj_server_url),
                nj_server_url_local=g.get("njServerUrlLocal", config.gateway.nj_server_url_local),
            )

        # Roles
        if "roles" in data:
            config.roles = [
                RoleConfig(name=r.get("name", ""), desc=r.get("desc", ""), color=r.get("color", "#818cf8"))
                for r in data["roles"]
            ]

        # Developer API key — 환경변수 폴백
        config.developer_api_key = data.get("developerApiKey", "") or os.getenv("DAPPARENA_API_KEY", "")

        return config

    @staticmethod
    def _find_config() -> Optional[str]:
        """현재 디렉토리에서 상위로 올라가며 dapparena.config.json을 찾습니다."""
        current = Path.cwd()
        while True:
            config_path = current / "dapparena.config.json"
            if config_path.exists():
                return str(config_path)
            parent = current.parent
            if parent == current:
                break
            current = parent
        return None

    def get_nj_server_url(self) -> str:
        """NJ Server URL을 반환합니다 (환경에 따라 로컬/프로덕션)."""
        if os.getenv("DAPPARENA_LOCAL"):
            return self.gateway.nj_server_url_local
        return self.gateway.nj_server_url
