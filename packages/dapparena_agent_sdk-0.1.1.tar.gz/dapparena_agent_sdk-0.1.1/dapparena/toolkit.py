"""ToolKit — Built-in tools for Dapp Arena agents (MCP-compatible wrappers)."""

from __future__ import annotations

import httpx


class ToolKit:
    """
    Collection of ready-to-use tools for agents.

    Provides web search, HTTP requests, and text processing helpers
    that agents can use during task execution.

    Example:
        toolkit = ToolKit()

        # Web search
        results = await toolkit.web_search("WorldLand blockchain")

        # Fetch a webpage
        content = await toolkit.fetch_url("https://example.com")

        # Summarize text
        summary = toolkit.truncate_text(long_text, max_chars=500)
    """

    def __init__(self, timeout: float = 30.0):
        self._timeout = timeout

    async def web_search(
        self, query: str, max_results: int = 5
    ) -> list[dict[str, str]]:
        """
        Search the web using DuckDuckGo Instant Answer API.

        Args:
            query: Search query.
            max_results: Maximum results to return.

        Returns:
            List of dicts with 'title', 'url', 'snippet' keys.
        """
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(
                "https://api.duckduckgo.com/",
                params={"q": query, "format": "json", "no_html": "1"},
            )
            resp.raise_for_status()
            data = resp.json()

        results = []
        # Related topics
        for topic in data.get("RelatedTopics", [])[:max_results]:
            if "Text" in topic and "FirstURL" in topic:
                results.append({
                    "title": topic.get("Text", "")[:80],
                    "url": topic["FirstURL"],
                    "snippet": topic.get("Text", ""),
                })
        return results

    async def fetch_url(self, url: str, max_chars: int = 10000) -> str:
        """
        Fetch text content from a URL.

        Args:
            url: The URL to fetch.
            max_chars: Maximum characters to return.

        Returns:
            Text content of the page (truncated if necessary).
        """
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True
        ) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            text = resp.text[:max_chars]
            return text

    async def post_json(
        self, url: str, data: dict, headers: dict | None = None
    ) -> dict:
        """
        Make a POST request with JSON body.

        Args:
            url: Target URL.
            data: JSON payload.
            headers: Optional headers.

        Returns:
            Response JSON as dict.
        """
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(url, json=data, headers=headers or {})
            resp.raise_for_status()
            return resp.json()

    @staticmethod
    def truncate_text(text: str, max_chars: int = 500, suffix: str = "...") -> str:
        """Truncate text to max_chars with a suffix."""
        if len(text) <= max_chars:
            return text
        return text[: max_chars - len(suffix)] + suffix

    @staticmethod
    def chunk_text(text: str, chunk_size: int = 2000) -> list[str]:
        """Split text into chunks of approximately equal size."""
        if len(text) <= chunk_size:
            return [text]

        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            # Try to break at a sentence boundary
            if end < len(text):
                for sep in [". ", ".\n", "\n\n", "\n", " "]:
                    last_sep = text.rfind(sep, start, end)
                    if last_sep > start:
                        end = last_sep + len(sep)
                        break
            chunks.append(text[start:end])
            start = end
        return chunks

    @staticmethod
    def extract_keywords(text: str, top_n: int = 10) -> list[str]:
        """Extract top keywords from text by word frequency (simple heuristic)."""
        import re
        words = re.findall(r"\b[a-zA-Z가-힣]{2,}\b", text.lower())
        # Common stopwords
        stopwords = {
            "the", "is", "at", "which", "on", "and", "or", "to", "in", "of",
            "for", "with", "this", "that", "are", "was", "were", "be", "has",
            "have", "had", "do", "does", "did", "will", "would", "could",
            "should", "may", "might", "can", "shall", "a", "an", "but", "if",
            "not", "no", "so", "as", "by", "from", "it", "its", "they",
        }
        filtered = [w for w in words if w not in stopwords]
        freq: dict[str, int] = {}
        for w in filtered:
            freq[w] = freq.get(w, 0) + 1
        sorted_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)
        return [w for w, _ in sorted_words[:top_n]]
