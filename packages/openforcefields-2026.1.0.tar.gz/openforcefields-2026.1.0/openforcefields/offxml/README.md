# Force Field Files

This directory contains the `offxml` forcefield files that are installed with the package to be used with the openforcefield toolkit.
