"""
Unit Tests for Intent Engine
"""

import pytest
from pathlib import Path
from altrus.core.kernel import AltrusKernel
from altrus.core.registry.module import Module
from altrus.core.intent.intent import Intent, IntentPriority
from altrus.core.observability.server import stop_metrics_server

@pytest.fixture
def kernel(tmp_path):
    stop_metrics_server()
    k = AltrusKernel(storage_dir=tmp_path)
    yield k
    stop_metrics_server()

def test_module_registration(kernel):
    """Test registering modules in intent engine context"""
    kernel.registry.register(
        Module(
            module_id="nav01",
            name="Navigation",
            version="1.0",
            capabilities=["navigation.move"]
        )
    )

    modules = kernel.registry.list_modules()
    assert any(m.module_id == "nav01" for m in modules)

def test_intent_submission(kernel):
    """Test submitting intents to the engine"""
    intent = Intent("i001", "move_robot", "navigation.move", IntentPriority.NORMAL)
    kernel.intent_engine.submit_intent(intent)

    intents = kernel.intent_engine.list_intents()
    assert any(i.intent_id == "i001" for i in intents)
