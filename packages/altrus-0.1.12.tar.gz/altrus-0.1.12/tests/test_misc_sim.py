"""
Unit tests for Ledger Verifier and Resource Simulation
"""
import pytest
from altrus.core.ledger.verifier import LedgerVerifier
from altrus.core.ledger.blockchain import BlockchainLedger
from altrus.simulation.resource_sim import ResourceSimulator
from altrus.core.kernel import AltrusKernel
from altrus.core.observability.server import stop_metrics_server

@pytest.fixture
def kernel(tmp_path):
    k = AltrusKernel(storage_dir=tmp_path)
    yield k
    k.shutdown()
    stop_metrics_server()

def test_ledger_verifier(tmp_path):
    """Test ledger integrity verification"""
    ledger = BlockchainLedger(storage_dir=tmp_path)
    ledger.add_block({"data": "test"})

    # LedgerVerifier.verify is a static method
    assert LedgerVerifier.verify(ledger) is True

def test_resource_simulator(kernel):
    """Test resource consumption simulation"""
    sim = ResourceSimulator(kernel)

    # These methods trigger handle_fault in fault_engine
    sim.simulate_cpu_pressure(load_percent=90, duration=1)
    sim.simulate_memory_exhaustion(mb=200)
    sim.simulate_network_latency(latency_ms=100)

    # Check that faults were recorded in history
    history = kernel.fault_engine.fault_history
    types = [f["fault_type"] for f in history if f["detector"] == "MANUAL_SIGNAL"]
    assert "HIGH_CPU_PRESSURE" in types
    assert "LOW_MEMORY_WARNING" in types
    assert "NETWORK_DELAY_SPIKE" in types
