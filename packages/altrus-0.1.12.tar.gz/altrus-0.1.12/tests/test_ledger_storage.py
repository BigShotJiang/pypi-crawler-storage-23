"""
Unit tests for Ledger Storage persistence
"""
import pytest
from pathlib import Path
from altrus.core.ledger.storage import LedgerStorage
from altrus.core.ledger.block import Block

def test_ledger_storage_load_save(tmp_path):
    """Test saving and loading blocks"""
    storage = LedgerStorage(storage_dir=tmp_path)

    b1 = Block(0, "0", {"data": "genesis"})
    storage.save([b1])

    loaded = storage.load()
    assert len(loaded) == 1
    assert loaded[0].hash == b1.hash

def test_ledger_storage_corruption(tmp_path):
    """Test handling of corrupted ledger file"""
    storage = LedgerStorage(storage_dir=tmp_path)
    storage.path.write_text("not json")

    assert storage.load() == []
