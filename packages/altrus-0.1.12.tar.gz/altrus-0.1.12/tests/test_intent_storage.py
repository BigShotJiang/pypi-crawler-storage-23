"""
Unit tests for Intent Storage persistence
"""
import pytest
import json
from pathlib import Path
from altrus.core.intent.storage import IntentStorage
from altrus.core.intent.intent import Intent, IntentPriority

def test_intent_storage_load_save(tmp_path):
    """Test saving and loading intents"""
    storage = IntentStorage(storage_dir=tmp_path)

    i1 = Intent("i1", "n1", "c1", IntentPriority.NORMAL)
    storage.save([i1])

    loaded = storage.load()
    assert len(loaded) == 1
    assert loaded[0].intent_id == "i1"

def test_intent_storage_corruption(tmp_path):
    """Test handling of corrupted JSON storage"""
    storage = IntentStorage(storage_dir=tmp_path)

    # Write invalid JSON
    storage.path.write_text("{ invalid json")

    loaded = storage.load()
    assert loaded == []

def test_intent_storage_empty(tmp_path):
    """Test loading from non-existent or empty file"""
    storage = IntentStorage(storage_dir=tmp_path)
    assert storage.load() == []

    storage.path.touch()
    assert storage.load() == []
