from abc import ABC, abstractmethod


class RecoveryStrategy(ABC):
    """
    Base class for fault recovery strategies.
    """

    @abstractmethod
    def execute(self) -> None:
        pass


class RestartModuleStrategy(RecoveryStrategy):
    def __init__(self, registry=None, module_id: str = None):
        self.registry = registry
        self._module_id = module_id

    def execute(self) -> None:
        if self.registry and self._module_id:
            print(f"[Recovery] Restarting module {self._module_id}...")
            try:
                self.registry.activate(self._module_id)
            except Exception as e:
                print(f"[Recovery] Failed to restart module {self._module_id}: {e}")
        else:
            print("[Recovery] Generic restart triggered (no specific module).")


class SafeModeStrategy(RecoveryStrategy):
    def __init__(self, ledger=None):
        self.ledger = ledger

    def execute(self) -> None:
        print("[Recovery] Switching system to safe mode...")
        if self.ledger:
            self.ledger.log_event(
                event_type="SYSTEM_SAFE_MODE",
                actor_type="SYSTEM",
                actor_id="recovery_manager",
                data={"reason": "UNRECOVERABLE_FAULT"}
            )
