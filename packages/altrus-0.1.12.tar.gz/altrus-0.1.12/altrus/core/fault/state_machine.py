from enum import Enum


class FaultState(Enum):
    NORMAL = "NORMAL"
    DEGRADED = "DEGRADED"
    FAILED = "FAILED"
    RECOVERING = "RECOVERING"

class FaultSeverity(Enum):
    SOFT = 1
    HARD = 5
    CRITICAL = 10
