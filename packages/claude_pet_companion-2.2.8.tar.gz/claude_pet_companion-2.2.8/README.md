# Claude Pet Companion

![Version](https://img.shields.io/badge/version-2.2.4-blue)
![Python](https://img.shields.io/badge/python-3.8+-green)
![License](https://img.shields.io/badge/license-MIT-green)

A virtual pet for Claude Code with evolution system, memory tracking, and productivity features.

---

## What's New in v2.2

### 3D Evolution System

- **10 Evolution Stages** - From Egg to Ancient with unique visual appearances
- **5 Evolution Paths** - Coder, Warrior, Social, Night Owl, Balanced
- **3D Pseudo-Rendering** - Multi-layer depth simulation with dynamic lighting
- **Evolution Items** - Collect special items to trigger evolutions
- **Memory System** - Pet remembers your coding activities and patterns

---

## Installation

```bash
pip install claude-pet-companion
```

---

## Usage

### 1. Desktop Pet Mode

Launch a standalone desktop pet that responds to your coding activities:

```bash
claude-pet
# or
pet-companion
```

The desktop pet features:
- Floating animated character on your screen
- Mouse eye tracking
- Drag to reposition
- Right-click menu for interactions
- Theme switching (5 color schemes)

### 2. Claude Code Plugin Mode

Install as a Claude Code plugin for in-chat commands:

```bash
claude-pet install
```

Then restart Claude Code and use these commands in your conversation:

```
/pet:status - View pet stats and evolution stage
/pet:feed   - Feed your pet
/pet:play   - Play with your pet
/pet:sleep  - Toggle sleep mode
```

**Plugin Location:**

| Platform | Directory |
|----------|-----------|
| Windows | `%APPDATA%\Claude\plugins\claude-pet-companion\` |
| macOS | `~/.claude/plugins/claude-pet-companion/` |
| Linux | `~/.claude/plugins/claude-pet-companion/` |

---

## Evolution System

### 10 Stages

Egg → Hatchling → Baby → Child → Pre-Teen → Teen → Young Adult → Adult → Elder → Ancient

### 5 Evolution Paths

| Path | Style | Special Features |
|------|-------|------------------|
| **Coder** | Tech | Blue/Green, pixel eyes, binary particles |
| **Warrior** | Battle | Orange/Red, sharp eyes, flame aura |
| **Social** | Cute | Pink/Heart, round body, heart particles |
| **Night Owl** | Mystery | Purple/Yellow, glowing eyes, stardust trail |
| **Balanced** | Harmony | Green/Teal, gentle eyes, nature aura |

### Evolution Items

| Item | Use | How to Get |
|------|-----|------------|
| Code Fragment | Stages 1-3 | Create 5 files |
| Bug Slayer | Stages 4-6 | Fix 10 errors |
| Wisdom Crystal | Stages 7-8 | 90%+ productivity |
| Ancient Relic | Stage 9 | All achievements |
| Friendship Badge | Social boost | 50 interactions |
| Moonstone | Night Owl boost | 10hrs night coding |

---

## Features

### Theme System

Switch between 5 color schemes via right-click menu:
- **Blue (Default)** - Classic Claude blue tones
- **Pink** - Warm rose and magenta
- **Green** - Fresh nature greens
- **Dark** - Sleek monochrome
- **Purple** - Mystical violet vibes

### Productivity Tracking

| Metric | Description |
|--------|-------------|
| **Productivity Score** | Based on success rate and activity frequency |
| **Focus Score** | Measures continuous work time vs breaks |
| **Combo/Streak** | Bonus XP for rapid consecutive actions |
| **Flow State** | Special effects when focus >= 80% |

### Dynamic Expressions

| State | Expression |
|-------|-----------|
| Idle | 😊 Happy with smile |
| Thinking | 🤔 Eyes shift with question mark |
| Working | ⚡ Focused with sweat drop |
| Error | 😵 X eyes with worry |
| Success | ✨ Sparkling star eyes |

---

## Desktop Pet Controls

### Right-Click Menu

```
Feed      - Restore hunger (+30)
Play      - Increase happiness (+25)
Interact  - Quick happiness (+10)
──────────────────────────
Sleep/Wake - Toggle sleep mode
Status     - View detailed stats
Theme      - Change colors
──────────────────────────
Exit       - Close pet
```

### Mouse Actions

- **Double click** - Pet jumps + hearts
- **Right click** - Open menu
- **Drag** - Move pet

---

## Configuration

Edit `~/.claude-pet-companion/config.json`:

```json
{
  "theme": "default",
  "animation_speed": 1.0,
  "pet_name": "Buddy",
  "target_fps": 40
}
```

---

## Uninstall

```bash
# Uninstall Claude Code plugin
claude-pet uninstall

# Uninstall entire package
pip uninstall claude-pet-companion
```

---

## Requirements

- Python 3.8+
- tkinter (usually included with Python)

---

## License

MIT License

---

## Credits

Made with ❤️ for the Claude Code community
