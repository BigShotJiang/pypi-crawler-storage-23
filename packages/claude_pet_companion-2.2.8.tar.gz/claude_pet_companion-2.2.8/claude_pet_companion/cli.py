#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Claude Code Pet Companion - CLI

Command-line interface for the pet companion.
"""
import sys
import os
import shutil
import json
from pathlib import Path


class PetPluginInstaller:
    """Handle Claude Code plugin installation."""

    def __init__(self):
        self.package_dir = Path(__file__).parent
        self.plugin_dir = self.get_claude_plugin_dir()

    def get_claude_plugin_dir(self):
        """Get the Claude Code plugins directory."""
        env_path = os.environ.get('CLAUDE_PLUGINS_PATH')
        if env_path:
            return Path(env_path)

        home = Path.home()
        if sys.platform == "darwin":  # macOS
            return home / ".claude" / "plugins"
        elif sys.platform == "win32":  # Windows
            return home / "AppData" / "Roaming" / "Claude" / "plugins"
        else:  # Linux
            return home / ".claude" / "plugins"

    def install_plugin(self):
        """Install plugin to Claude Code plugins directory."""
        print("Installing Claude Code Pet Companion plugin...")

        # Create plugin directory
        self.plugin_dir.mkdir(parents=True, exist_ok=True)
        dest_dir = self.plugin_dir / "claude-pet-companion"

        # Remove existing
        if dest_dir.exists():
            shutil.rmtree(dest_dir)

        dest_dir.mkdir(parents=True, exist_ok=True)

        # Copy plugin components
        items_to_copy = [
            ('.claude-plugin', '.claude-plugin'),
            ('skills', 'skills'),
            ('agents', 'agents'),
            ('hooks', 'hooks'),
            ('render', 'render'),
            ('items', 'items'),
            ('memories', 'memories'),
            ('scripts', 'scripts'),
            ('webview', 'webview'),
            ('data', 'data'),
        ]

        for src_name, dst_name in items_to_copy:
            src = self.package_dir / src_name
            dst = dest_dir / dst_name
            if src.exists():
                if src.is_dir():
                    shutil.copytree(src, dst, ignore=shutil.ignore_patterns('__pycache__'))
                else:
                    shutil.copy2(src, dst)
                print(f"  [OK] Copied {src_name}")

        # Copy main module files
        for py_file in ['config.py', 'themes.py', 'claude_pet_hd.py', '__init__.py']:
            src = self.package_dir / py_file
            if src.exists():
                shutil.copy2(src, dest_dir / py_file)
                print(f"  [OK] Copied {py_file}")

        print(f"\n[OK] Plugin installed to: {dest_dir}")
        print("\nPlease restart Claude Code to use the plugin.")
        print("\nAvailable commands:")
        print("  /pet:status - Check pet status")
        print("  /pet:feed   - Feed your pet")
        print("  /pet:play   - Play with your pet")
        print("  /pet:sleep  - Toggle sleep mode")

        return True

    def uninstall_plugin(self):
        """Uninstall plugin from Claude Code."""
        dest_dir = self.plugin_dir / "claude-pet-companion"
        if dest_dir.exists():
            shutil.rmtree(dest_dir)
            print(f"[OK] Plugin uninstalled from: {dest_dir}")
            return True
        else:
            print("Plugin is not installed.")
            return False


class PetState:
    """宠物状态类"""
    def __init__(self):
        self.name = 'Claude'
        self.mood = 'happy'
        self.hunger = 100
        self.happiness = 100
        self.energy = 100
        self.level = 1
        self.xp = 0
        self.xp_to_next = 100

    def print_status(self):
        """打印状态"""
        print(f"""
🤖 {self.name} - Level {self.level}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Mood: {self.mood}
   Hunger: {self.hunger}/100
   Happiness: {self.happiness}/100
   Energy: {self.energy}/100
   XP: {self.xp}/{self.xp_to_next}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")


def print_status():
    """打印宠物状态"""
    state = PetState()
    state.print_status()


def launch_desktop_pet():
    """启动桌面宠物"""
    try:
        from claude_pet_companion.claude_pet_hd import ClaudeCodePetHD
        print("Starting Claude Code Pet HD Enhanced...")
        pet = ClaudeCodePetHD()
        pet.run()
    except ImportError as e:
        print(f"Error: {e}")
        print("Please install tkinter (usually included with Python)")


def main():
    """主入口"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Claude Code Pet Companion",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  (none)       Launch the desktop pet
  status       Show pet status
  install      Install Claude Code plugin
  uninstall    Uninstall Claude Code plugin

Examples:
  claude-pet              # Launch desktop pet
  claude-pet install      # Install Claude Code plugin
  claude-pet status       # Show status
        """
    )

    parser.add_argument(
        'command',
        nargs='?',
        choices=['launch', 'status', 'install', 'uninstall'],
        default='launch',
        help='Command to run'
    )

    args = parser.parse_args()

    if args.command == 'launch' or args.command == 'status':
        if args.command == 'status':
            print_status()
        else:
            launch_desktop_pet()
    elif args.command == 'install':
        installer = PetPluginInstaller()
        installer.install_plugin()
    elif args.command == 'uninstall':
        installer = PetPluginInstaller()
        installer.uninstall_plugin()


if __name__ == "__main__":
    main()
