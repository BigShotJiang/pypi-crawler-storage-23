# DynamicML 🚀  
**Dynamic, model‑aware classical machine learning for image classification**

**CREATED BY SUNKARA SAI GANESH , KARROTHU MOURYA , KUDIRELLA SANMUKA SAI**

DynamicML is a lightweight Python library built on top of **scikit‑learn** that enables **binary image classification using classical machine learning models**, with a strong focus on **dynamic, model‑aware preprocessing**. The library is designed to automatically adapt preprocessing pipelines based on image characteristics and model requirements, making it easy to experiment, benchmark, and deploy classical ML solutions for image data. Typically in just 2-4 lines of code.

---

## ✨ Key Features

- ✅ Binary image classification using classical ML models  
- ✅ Dynamic preprocessing tailored to each model  
- ✅ Strong support for k‑Nearest Neighbors (kNN)  
- ✅ Multiple feature extraction strategies (pixels, HOG, PCA)  
- ✅ Modular, extensible, and deployment‑ready  
- ✅ No deep‑learning dependencies (lightweight & fast)

---

## 🎯 Project Goals

DynamicML is designed to:

- Provide **clear, principled preprocessing pipelines** for image‑based ML
- Avoid one‑size‑fits‑all preprocessing
- Make classical ML viable for image classification tasks
- Enable rapid experimentation and reproducibility
- Serve as a learning and benchmarking framework for image ML

---

## 📦 Supported Models

DynamicML supports most classical classifiers available in **scikit‑learn**, including:

### Linear Models
- Logistic Regression
- SGDClassifier
- Perceptron
- RidgeClassifier

### Distance‑Based Models
- k‑Nearest Neighbors (kNN)
- Radius Neighbors
- Nearest Centroid

### Support Vector Machines
- Linear SVM
- Kernel SVM (RBF, Poly, Sigmoid)

### Probabilistic Models
- Gaussian Naive Bayes
- Multinomial Naive Bayes
- Complement Naive Bayes
- Bernoulli Naive Bayes

### Tree‑Based Models
- Decision Tree
- Random Forest
- Extra Trees

### Boosting & Ensembles
- AdaBoost
- Gradient Boosting
- HistGradientBoosting
- Bagging
- Voting
- Stacking

### Neural & Bayesian
- MLPClassifier
- GaussianProcessClassifier

---

## 🖼️ Image Preprocessing Philosophy

DynamicML follows one core principle:

> **Preprocessing depends on both the image type and the model type.**

Instead of applying the same pipeline to every model, DynamicML dynamically selects preprocessing steps such as:

- Image resizing
- Color conversion (RGB → Grayscale)
- Feature extraction
- Feature scaling
- Dimensionality reduction

---

## 🧠 Feature Extraction Strategies

DynamicML supports multiple feature representations:

### 1. Flattened Pixels
- Best for very small images
- Used mainly for baselines

### 2. Histogram of Oriented Gradients (HOG)
- Captures shape and edge information
- Illumination‑invariant
- Highly effective for kNN and SVM

### 3. PCA‑Compressed Features
- Reduces dimensionality
- Improves speed and generalization
- Strongly recommended for distance‑based models

### 4. Binary / Thresholded Features
- Useful for masks, silhouettes, and edge maps

---

## 🔄 Dynamic Preprocessing Logic

DynamicML automatically adapts preprocessing based on:

- Image size
- Image type (grayscale, binary, color)
- Feature dimensionality
- Model requirements (scaling, PCA, distance metrics)

Example logic:
```text
If model is distance‑based → scaling required  
If feature dimension is high → apply PCA  
If image is large → use HOG instead of raw pixels  
If model is tree‑based → skip scaling