# JAI SHREE RAM

from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
import joblib
import os
from dataset_loader_g import Preprocessing_Scikit_Img_Classif_Supervised_MN


class Scikit_Img_Classif_Supervised:

    # =========================
    # Common helpers
    # =========================
    @staticmethod
    def _save_bundle(bundle, prefix, save_dir):
        if save_dir is None:
            save_dir = os.getcwd()

        os.makedirs(save_dir, exist_ok=True)

        path = os.path.join(save_dir, f"{prefix}.joblib")

        joblib.dump(bundle, path)
        print(f"Model saved at: {path}")
        return path

    @staticmethod
    def _evaluate(y_test, y_pred):
        print("Accuracy:", accuracy_score(y_test, y_pred))
        print("\nClassification Report:\n", classification_report(y_test, y_pred))
        print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))




    
    @staticmethod
    def GaussianNB(dataset_path , test_size_val = 0.2,random_state=42,priors_val = None , var_smoothing_val = 1e-9 , save_dir = None, save_name="GaussianNB_MN",pca_n_components = 30, pca_random_state = 40):
        from sklearn.naive_bayes import GaussianNB
        try:
            print("Loading and Preprocessing data....")
            X, y , pca , label_encoder = Preprocessing_Scikit_Img_Classif_Supervised_MN.GaussianNB_MN(dataset_path=dataset_path,pca_n_components=pca_n_components,pca_random_state=pca_random_state)
            X_train ,X_test , y_train , y_test = train_test_split(X, y , test_size=test_size_val,random_state=random_state)
            print("Training the model......")
            gnb = GaussianNB(priors=priors_val,
                             var_smoothing= var_smoothing_val,
                             )
            print("Fitting the model....")
            gnb.fit(X_train,y_train)
            print("Model training completed....")
            y_pred = gnb.predict(X_test)
            Scikit_Img_Classif_Supervised._evaluate(y_test,y_pred)
            bundle = {
                "model": gnb,
                "pca": pca,
                "label_encoder": label_encoder
            }
            Scikit_Img_Classif_Supervised._save_bundle(bundle=bundle,prefix=save_name,save_dir=save_dir)
            return bundle
        except Exception as e:
            print(f"Unknown Exception happened: {e}")
        finally:
            print("Model Called Successfully...")

    
    @staticmethod
    def RidgeClassifier(dataset_path, test_size_val=0.2, split_random_state_val=42, shuffle_val=True,save_name = "RidgeClassifier_MN",
                                                alpha_val=1.0, fit_intercept_val=True, copy_X_val=True, max_iter_val=None,
                                                tol_val=0.0001, class_weight_val=None, solver_val='auto',
                                                positive_val=False, random_state_val=None, save_dir=None):
        from sklearn.linear_model import RidgeClassifier
        try:
            print("Loading and pre-processing data....")
            X , y , pca , label_encoder , Scaler =Preprocessing_Scikit_Img_Classif_Supervised_MN.Ridge_Classifier_MN(dataset_path)
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size_val, random_state=split_random_state_val,
                stratify=y, shuffle=shuffle_val
            )
            print("Training the Model....")
            rc = RidgeClassifier(
                alpha=alpha_val,
                fit_intercept=fit_intercept_val,
                copy_X=copy_X_val,
                max_iter=max_iter_val,
                tol=tol_val,
                class_weight=class_weight_val,
                solver=solver_val,
                positive=positive_val,
                random_state=random_state_val
            )
            print("Fitting the Model....")
            rc.fit(X_train, y_train)
            print("Model Training Completed!")
            y_pred = rc.predict(X_test)

            print("Accuracy score:",accuracy_score(y_test,y_pred))
            print("\nClassification Report:\n",classification_report(y_test,y_pred))

            print("Saving the Model....")
            bundle = {
                "model": rc,
                "pca": pca,
                "label_encoder": label_encoder,
                "scaler": Scaler
            }
            Scikit_Img_Classif_Supervised._save_bundle(bundle=bundle,save_name=save_name,save_dir=save_dir)
            print(f"Model saved at: {save_dir}")
            print("Model saving completed.")
            print("Ridge Classifier process finished!")
            return rc
        except Exception as e:
            print(f"An error occured: {e}")
            return None



    @staticmethod
    def LinearSVC(dataset_path,test_size_val=0.2,split_random_state_val=42,shuffle_val=True,save_name="LinearSVC_MN",
                  penalty_val='l2', loss_val='squared_hinge', dual_val='auto', tol_val=0.0001,
                  C_val=1.0, multi_class_val='ovr', fit_intercept_val=True, intercept_scaling_val=1,
                  class_weight_val=None, verbose_val=0, random_state_val=None, max_iter_val=1000, save_dir=None
            ):
        
        from sklearn.svm import LinearSVC

        try:
            print("Loading and pre-processing data....")
            X , y , pca, label_encoder , scaler =Preprocessing_Scikit_Img_Classif_Supervised_MN.LinearSVC_MN(dataset_path)
            X_train, X_test, y_train, y_test = train_test_split(
                X , y , test_size=test_size_val, random_state=split_random_state_val,
                stratify=y , shuffle=shuffle_val
            )
            print("Training the Model....")
            model= LinearSVC(
                penalty=penalty_val,
                loss=loss_val,
                dual=dual_val,
                tol=tol_val,
                C=C_val,
                multi_class=multi_class_val,
                fit_intercept=fit_intercept_val,
                intercept_scaling=intercept_scaling_val,
                class_weight=class_weight_val,
                verbose=verbose_val,
                random_state=random_state_val,
                max_iter=max_iter_val
            )
            print("Fitting the Model....")
            model.fit(X_train,y_train)
            print("Model Training Completed!")
            y_pred = model.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test,y_pred)

            bundle = {
                "model": model,
                "pca":pca,
                "label_encoder": label_encoder,
                "scaler":scaler
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle , save_name ,save_dir
            )
            return model
        except Exception as e:
            print(f"An error occurred: {e}")
            return None



    @staticmethod
    def SVC(dataset_path, test_size_val=0.2,split_random_state_val=42, shuffle_val=True,
                                    C_val=5.0, kernel_val='rbf', degree_val=3, gamma_val='scale', coef0_val=0.0,
                                    shrinking_val=True, probability_val=False, tol_val=1e-3, cache_size_val=200,
                                    class_weight_val='balanced', verbose_val=False, max_iter_val=-1, 
                                    decision_function_shape_val='ovr', break_ties_val=False,random_state_val=None, save_dir=None):
        
        from sklearn.svm import SVC

        try:
            print("Loading and pre-processing data....")
            X , y , pca , label_encoder =Preprocessing_Scikit_Img_Classif_Supervised_MN.svc_MN(dataset_path)
            X_train, X_test, y_train, y_test = train_test_split(
                X , y , test_size=test_size_val, random_state=split_random_state_val,
                stratify=y , shuffle=shuffle_val
            )
            print("Training the Model....")
            svc= SVC(
                C=C_val,
                kernel=kernel_val,
                degree=degree_val,
                gamma=gamma_val,
                coef0=coef0_val,
                shrinking=shrinking_val,
                probability=probability_val,
                tol=tol_val,
                cache_size=cache_size_val,
                class_weight=class_weight_val,
                verbose=verbose_val,
                max_iter=max_iter_val,
                decision_function_shape=decision_function_shape_val,
                break_ties=break_ties_val,
                random_state=random_state_val
            )
            print("Fitting the Model....")
            svc.fit(X_train,y_train)
            print("Model Training Completed!")
            y_pred = svc.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test,y_pred)

            bundle = {
                "model": svc,
                "pca": pca,
                "label_encoder": label_encoder
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle , "SVC_MN",save_dir
            )
            return svc
        except Exception as e:
            print(f"An error occurred: {e}")
            return None



    @staticmethod
    def RandomForest_Classifier(dataset_path, split_random_state_val=42, test_size_val=0.2, shuffle_val=True,save_name ="RandomForestClassifier_MN",
                                                            n_estimators_val=100, criterion_val='gini', max_depth_val=None,
                                                            min_samples_split_val=2, min_samples_leaf_val=1, min_weight_fraction_leaf_val=0.0,
                                                            max_features_val='sqrt', max_leaf_nodes_val=None, min_impurity_decrease_val=0.0,
                                                            bootstrap_val=True, oob_score_val=False, n_jobs_val=None,random_state_val=None,
                                                            verbose_val=0, warm_start_val=False, class_weight_val=None,ccp_alpha_val=0.0,
                                                            max_samples_val=None, monotonic_cst_val=None,save_dir=None):
        
        from sklearn.ensemble import RandomForestClassifier

        
        try:
            print("Loading and pre-processing data....")
            X , y , label_encoder= Preprocessing_Scikit_Img_Classif_Supervised_MN.RandomForest_Classifier_MN(dataset_path)
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size_val, random_state=split_random_state_val,
                stratify=y , shuffle=shuffle_val
            )
            print("Training the Model....")
            model = RandomForestClassifier(
                n_estimators=n_estimators_val,
                criterion=criterion_val,
                max_depth=max_depth_val,
                min_samples_split=min_samples_split_val,
                min_samples_leaf=min_samples_leaf_val,
                min_weight_fraction_leaf=min_weight_fraction_leaf_val,
                max_features=max_features_val,
                max_leaf_nodes=max_leaf_nodes_val,
                min_impurity_decrease=min_impurity_decrease_val,
                bootstrap=bootstrap_val,
                oob_score=oob_score_val,
                n_jobs=n_jobs_val,
                random_state=random_state_val,
                verbose=verbose_val,
                warm_start=warm_start_val,
                class_weight=class_weight_val,
                ccp_alpha=ccp_alpha_val,
                max_samples=max_samples_val,
                monotonic_cst=monotonic_cst_val
                )
            print("Fitting the Model....")
            model.fit(X_train, y_train)
            print("Model Training Completed!")
            y_pred = model.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test,y_pred)

            bundle = {
                "model": model,
                "label_encoder": label_encoder
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle , save_name ,save_dir
            )
            return model
        except Exception as e:
            print(f"An error occurred: {e}")
            return None


    
    @staticmethod
    def NuSVC(dataset_path, test_size_val = 0.2, save_name="NuSVC_MN", random_state_val = 42, kernel_val= 'rbf',
                                        nu_val = 0.2, degree_val=3,gamma_val ='scale',coef0_val=0.0,shrinking_val=True,
                                        probability_val=False,tol_val=1e-3,cache_size_val=200,class_weight_val=None,
                                        verbose_val=False,max_iter_val=-1,decision_function_shape_val='ovr',break_ties=False,save_dir=None
                                            ):

        from sklearn.svm import NuSVC

        try:
            print("Loading and pre-processing data....")
            X, y , pca , label_encoder = Preprocessing_Scikit_Img_Classif_Supervised_MN.svc_MN(dataset_path)
            print("Samples:", X.shape[0])
            print("Features per image:", X.shape[1])
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size_val, random_state=random_state_val
            )
            print("Training the Model....")
            nusvc = NuSVC(
                kernel=kernel_val,
                nu=nu_val,
                degree=degree_val,
                gamma=gamma_val,
                coef0=coef0_val,
                shrinking=shrinking_val,
                probability=probability_val,
                tol=tol_val,
                cache_size=cache_size_val,
                class_weight=class_weight_val,
                verbose=verbose_val,
                max_iter=max_iter_val,
                decision_function_shape=decision_function_shape_val,
                break_ties=break_ties
            )
            print("Fitting the Model....")
            nusvc.fit(X_train, y_train)
            print("Model Training Completed!")
            y_pred = nusvc.predict(X_test)

            print("Accuracy:", accuracy_score(y_test, y_pred))
            print("Classification Report:")
            print(classification_report(y_test, y_pred))

            Scikit_Img_Classif_Supervised._evaluate(y_test , y_pred)

            bundle={
                "model": nusvc,
                "pca" : pca,
                "label_encoder":label_encoder,
                
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle, save_name , save_dir
            )
            return bundle
        except Exception as e:
            print(f"An error occured:{e}")
            return None


    @staticmethod
    def Bagging_Classifier(dataset_path, test_size_val=0.2, split_random_state_val=42, shuffle_val=True,
                                                    estimator_val=None, n_estimators_val=10, max_samples_value=1.0, max_features_val=1.0,
                                                    bootstrap_val=True, bootstrap_features_val=False, oob_score_val=False, warm_start_val=False,
                                                    n_jobs_val=None, random_state_val=None, verbose_val=0,save_dir=None,save_name = "BaggingClassifier_MN"):
        
        
        from sklearn.ensemble import BaggingClassifier

        try:
            print("Loading and pre-processing data....")
            X , y ,pca,label_encoder= Preprocessing_Scikit_Img_Classif_Supervised_MN.bagging_MN(dataset_path=dataset_path, mode="train")
            X_train, X_test, y_train, y_test =train_test_split(
                X , y, test_size=test_size_val, random_state=split_random_state_val,
                stratify=y, shuffle=shuffle_val
            )
            print("Training the model....")
            bc =  BaggingClassifier(
                estimator=estimator_val,
                n_estimators=n_estimators_val,
                max_samples=max_samples_value,
                max_features=max_features_val,
                bootstrap=bootstrap_val,
                bootstrap_features=bootstrap_features_val,
                oob_score=oob_score_val,
                warm_start=warm_start_val,
                n_jobs=n_jobs_val,
                random_state=random_state_val,
                verbose=verbose_val
            )
            print("Fitting the Model....")
            bc.fit(X_train,y_train)
            print("Model Training Completed!")
            y_pred = bc.predict(X_test)

            print("Accuracy score:",accuracy_score(y_test,y_pred))
            print("Classification report:",classification_report(y_test,y_pred))

            bundle = {
                "model": bc,
                "pca": pca,
                "label_encoder": label_encoder
            }
            print("Saving the Model....")
            Scikit_Img_Classif_Supervised._save_bundle(
                bundle, save_name, save_dir
            )
            print("Bagging Classifier process finished!")

            

            return bundle
        except Exception as e:
             print(f"An error occured: {e}")
             return None

    @staticmethod
    def KNeighbors_Classifier(dataset_path, random_state_val=42, test_size_val=0.2, n_neighbors_val=3, weights_val ='distance', algorithm_val ='brute', leaf_size_val =30,p_val=2, metric_val='euclidean', metric_params_val =None, n_jobs_val=-1,save_dir=None ,save_name = "KNNClassifier_MN"):
        
        from sklearn.neighbors import KNeighborsClassifier
        
        try:
            print("Loading and pre-processing data....")
            X , y ,pca , label_encoder= Preprocessing_Scikit_Img_Classif_Supervised_MN.knn_MN(dataset_path=dataset_path, mode="train")
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size_val, random_state=random_state_val,
                stratify=y  
            )

            print("Training the Model....")
            knn = KNeighborsClassifier(
                n_neighbors=n_neighbors_val,
                weights=weights_val,
                algorithm=algorithm_val,
                leaf_size=leaf_size_val,
                p=p_val,
                metric=metric_val,
                metric_params=metric_params_val,
                n_jobs=n_jobs_val
                )
            print("Fitting the Model....")
            knn.fit(X_train, y_train)
            print("Model Training Completed!")
            y_pred = knn.predict(X_test)

            print("Accuracy:", accuracy_score(y_test, y_pred))
            print("\nClassification Report:\n", classification_report(y_test, y_pred))
            bundle = {
                 "model": knn,
                 "pca": pca,
                 "label_encoder": label_encoder
            }
            print("Saving the Model....")
            Scikit_Img_Classif_Supervised._save_bundle(bundle, save_name, save_dir)
            print("Model saving completed.")
            print("KNeighbors Classifier process finished!")
            return bundle
        except Exception as e:
            print(f"An error occured: {e}")
            return None
        

    @staticmethod
    def DecisionTreeClassifier(dataset_path, test_size_val=0.2,split_random_state_val=42, shuffle_val=True,
                               criterion_val='gini', splitter_val='best', max_depth_val=None, min_samples_split_val=2,
                               min_samples_leaf_val=1, min_weight_fraction_leaf_val=0.0, max_features_val=None,
                               random_state_val=None, max_leaf_nodes_val=None, min_impurity_decrease_val=0.0,
                               class_weight_val=None, ccp_alpha_val=0.0, monotonic_cst_val=None, save_dir=None):
        
        from sklearn.tree import DecisionTreeClassifier

        try:
            print("Loading and pre-processing data....")
            X , y , pca , label_encoder , scaler =Preprocessing_Scikit_Img_Classif_Supervised_MN.DecisionTreeClassifier_MN(dataset_path)
            X_train, X_test, y_train, y_test = train_test_split(
                X , y , test_size=test_size_val, random_state=split_random_state_val,
                stratify=y , shuffle=shuffle_val
            )
            print("Training the Model....")
            model= DecisionTreeClassifier(
                criterion=criterion_val,
                splitter=splitter_val,
                max_depth=max_depth_val,
                min_samples_split=min_samples_split_val,
                min_samples_leaf=min_samples_leaf_val,
                min_weight_fraction_leaf=min_weight_fraction_leaf_val,
                max_features=max_features_val,
                random_state=random_state_val,
                max_leaf_nodes=max_leaf_nodes_val,
                min_impurity_decrease=min_impurity_decrease_val,
                class_weight=class_weight_val,
                ccp_alpha=ccp_alpha_val,
                monotonic_cst=monotonic_cst_val
                
            )
            print("Fitting the Model....")
            model.fit(X_train,y_train)
            print("Model Training Completed!")
            y_pred = model.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test,y_pred)

            bundle = {
                "model": model,
                "pca": pca,
                "label_encoder": label_encoder,
                "scaler":scaler
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle , "DecisionTreeClassifier_MN",save_dir
            )
            return model
        except Exception as e:
            print(f"An error occurred: {e}")
            return None


    @staticmethod
    def GaussianProcess(
        dataset_path,
        test_size_val=0.2,
        split_random_state_val=42,
        shuffle_val=True,
        kernel_val=None,
        optimizer_val="fmin_l_bfgs_b",
        n_restarts_optimizer_val=0,
        max_iter_predict_val=100,
        warm_start_val=False,
        copy_X_train_val=True,
        random_state_val=None,
        multi_class_val="one_vs_rest",
        n_jobs_val=None,
        save_dir=None,
        save_name="GaussianProcessClassifier_MN"
    ):
        from sklearn.gaussian_process import GaussianProcessClassifier

        try:
            print("Loading and preprocessing data...")
            X, y, pca, label_encoder = Preprocessing_Scikit_Img_Classif_Supervised_MN.gaussianprocess_MN(
                dataset_path=dataset_path,
                mode="train"
            )

            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=test_size_val,
                random_state=split_random_state_val,
                stratify=y,
                shuffle=shuffle_val
            )

            print("Training Gaussian Process Classifier...")
            model = GaussianProcessClassifier(
                kernel=kernel_val,
                optimizer=optimizer_val,
                n_restarts_optimizer=n_restarts_optimizer_val,
                max_iter_predict=max_iter_predict_val,
                warm_start=warm_start_val,
                copy_X_train=copy_X_train_val,
                random_state=random_state_val,
                multi_class=multi_class_val,
                n_jobs=n_jobs_val
            )

            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test, y_pred)

            bundle = {
                "model": model,
                "pca": pca,
                "label_encoder": label_encoder
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle, save_name, save_dir
            )

            return bundle

        except Exception as e:
            print(f"An error occurred: {e}")
            return None


    # =========================
    # Gradient Boosting
    # =========================
    @staticmethod
    def GradientBoosting(
        dataset_path,
        test_size_val=0.2,
        random_state_val=42,
        n_estimators_val=100,
        learning_rate_val=0.1,
        loss_val="log_loss",
        max_depth_val=3,
        min_samples_split_val=10,
        min_samples_leaf_val=5,
        max_features_val="sqrt",
        sub_sample_val=0.8,
        save_dir=None,
        save_name="GradientBoostingClassifier_MN"
    ):
        from sklearn.ensemble import GradientBoostingClassifier

        try:
            print("Loading and preprocessing data...")
            X, y, pca, label_encoder = Preprocessing_Scikit_Img_Classif_Supervised_MN.gradientboosting_MN(
                dataset_path=dataset_path,
                mode="train"
            )

            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=test_size_val,
                random_state=random_state_val,
                stratify=y
            )

            print("Training Gradient Boosting Classifier...")
            model = GradientBoostingClassifier(
                n_estimators=n_estimators_val,
                learning_rate=learning_rate_val,
                loss=loss_val,
                max_depth=max_depth_val,
                min_samples_split=min_samples_split_val,
                min_samples_leaf=min_samples_leaf_val,
                max_features=max_features_val,
                subsample=sub_sample_val,
                random_state=random_state_val
            )

            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test, y_pred)

            bundle = {
                "model": model,
                "pca": pca,
                "label_encoder": label_encoder
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle, save_name, save_dir
            )

            return bundle

        except Exception as e:
            print(f"An error occurred: {e}")
            return None


    # =========================
    # AdaBoost
    # =========================
    @staticmethod
    def AdaBoost_Classifier(
        dataset_path,
        split_random_state_val=42,
        test_size_val=0.2,
        shuffle_val=True,
        estimator_val=None,
        n_estimators_val=50,
        learning_rate_val=1.0,
        random_state_val=None,
        save_dir=None,
        save_name="AdaBoostClassifier_MN"
    ):
        from sklearn.ensemble import AdaBoostClassifier

        try:
            print("Loading and preprocessing data...")
            X, y, pca, label_encoder = Preprocessing_Scikit_Img_Classif_Supervised_MN.Adaboost_MN(
                dataset_path=dataset_path,
                mode="train"
            )

            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=test_size_val,
                random_state=split_random_state_val,
                stratify=y,
                shuffle=shuffle_val
            )

            print("Training AdaBoost Classifier...")
            model = AdaBoostClassifier(
                estimator=estimator_val,
                n_estimators=n_estimators_val,
                learning_rate=learning_rate_val,
                random_state=random_state_val
            )

            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)

            Scikit_Img_Classif_Supervised._evaluate(y_test, y_pred)

            bundle = {
                "model": model,
                "pca": pca,
                "label_encoder": label_encoder
            }

            Scikit_Img_Classif_Supervised._save_bundle(
                bundle, save_name, save_dir
            )

            return bundle

        except Exception as e:
            print(f"An error occurred: {e}")
            return None