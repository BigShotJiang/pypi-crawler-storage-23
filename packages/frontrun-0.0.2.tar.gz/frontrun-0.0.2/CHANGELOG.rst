Changelog
=========

All releases: https://github.com/lucaswiman/frontrun/releases

0.0.2 (2026-02-17)
------------------

Change all references to new library name s/interlace/frontrun/.

0.0.1 (2026-02-17)
-------------------

Initial release.
