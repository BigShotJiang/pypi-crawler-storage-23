"""Module containing the class for extracting plans from and writing to databases."""

# import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Literal
from uuid import UUID

from alembic import command, config, script
from geoalchemy2 import load_spatialite_gpkg
from geoalchemy2.admin.dialects.sqlite import load_spatialite_driver
from sqlalchemy import (
    CTE,
    Column,
    Engine,
    Executable,
    MetaData,
    Subquery,
    Table,
    create_engine,
    delete,
    exists,
    func,
    insert,
    inspect,
    literal,
    select,
    text,
    values,
)
from sqlalchemy.dialects.postgresql import insert as pg_upsert
from sqlalchemy.dialects.sqlite import insert as sqlite_upsert
from sqlalchemy.engine import URL, make_url

# from sqlalchemy.dialects.sqlite.base import SQLiteCompiler
from sqlalchemy.event import listen, listens_for, remove

# from sqlalchemy.ext.compiler import compiles
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import Select

# from sqlalchemy.sql.expression import BindParameter
from xplan_tools.model import model_factory
from xplan_tools.model.base import BaseCollection, BaseFeature
from xplan_tools.model.orm import Base, Feature, Geometry, Refs
from xplan_tools.settings import get_settings

# from xplan_tools.util import linearize_geom
from .base import BaseRepository

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _TraversalConfig:
    root_id: UUID
    walk_children: bool
    walk_parents: bool
    depth: int


class DBRepository(BaseRepository):
    """Repository class for loading from and writing to databases."""

    def __init__(
        self,
        datasource: str = "",
    ) -> None:
        """Initializes the DB Repository.

        During initialization, a connection is established and the existence of required tables is tested.
        If an alembic revision is found, automatic migration is executed for PostgreSQL DBs.
        For other DBs, an Exception is raised if the revision does not correspond to the current model.
        If no revision and tables are found, they are automatically created.

        Args:
            datasource: A connection string which will be transformed to a URL instance.
        """
        settings = get_settings()
        self.datasource: URL = make_url(datasource)
        self.content = None
        self.schema = settings.db_schema
        self.srid = settings.db_srid
        self.dialect = self.datasource.get_dialect().name
        self.Session = sessionmaker(bind=self._engine)

        self.alembic_cfg = config.Config()
        self.alembic_cfg.set_main_option(
            "script_location", "xplan_tools:model:migrations"
        )
        self.alembic_cfg.set_main_option(
            "sqlalchemy.url",
            datasource.replace("gpkg:", "sqlite:").replace(
                "postgresql:", "postgresql+psycopg:"
            ),
        )
        self._ensure_repo()

    def _ensure_repo(self) -> None:
        """Runs initial connection/schema tests and ensures DB revision."""

        def _check_schema_accessibility(privilege: Literal["USAGE", "CREATE"]) -> None:
            """Raises an exception if the schema does not exist or is not accessible to the current user."""
            # Check if the schema exists and is accessible
            user = conn.execute(text("SELECT current_user")).scalar()
            result = conn.execute(
                text("""
                    SELECT has_schema_privilege(:user, :schema, :privilege)
                """),
                {
                    "user": user,
                    "schema": self.schema,
                    "privilege": privilege,
                },
            )
            if not result.scalar():
                raise RuntimeError(
                    f"User {user} lacks {privilege} on schema '{self.schema}'"
                )

        def _check_db_srid() -> None:
            """Raises an exception if the DB SRID differs from the one of the repo."""
            if self.dialect == "geopackage":
                geometry_columns = Table(
                    "gpkg_geometry_columns",
                    MetaData(),
                    Column("table_name"),
                    Column("srs_id"),
                )
                stmt = select(geometry_columns.c.srs_id).where(
                    geometry_columns.c.table_name == "coretable"
                )
            else:
                geometry_columns = Table(
                    "geometry_columns",
                    MetaData(),
                    Column("f_table_name"),
                    Column("srid"),
                )
                stmt = select(geometry_columns.c.srid).where(
                    geometry_columns.c.f_table_name == "coretable"
                )
                if self.dialect == "postgresql":
                    geometry_columns.append_column(Column("f_table_schema"))
                    stmt = stmt.where(
                        geometry_columns.c.f_table_schema == (self.schema or "public")
                    )
            srid = conn.execute(stmt).scalar_one()
            if srid != self.srid:
                raise RuntimeError(
                    f"DB SRID '{srid}' and configured SRID '{self.srid}' must identical"
                )

        current_version = script.ScriptDirectory.from_config(
            self.alembic_cfg
        ).get_heads()
        # test for tables and revision
        with self._engine.connect() as conn:
            if self.schema and self.dialect == "postgresql":
                _check_schema_accessibility("USAGE")
            inspector = inspect(conn)
            tables = inspector.get_table_names(schema=self.schema)
            is_coretable = {"coretable", "refs"}.issubset(set(tables))
            if "alembic_version" in tables:
                alembic_table = Table(
                    "alembic_version",
                    MetaData(schema=self.schema),
                    Column("version_num"),
                )
                stmt = select(alembic_table.c.version_num)
                db_version = conn.execute(stmt).scalars().all()
            else:
                db_version = []
            if db_version:
                _check_db_srid()
            is_current_version = set(db_version) == set(current_version)
            if is_current_version:
                logger.info("Database is at current revision")
                return
            elif self.schema and self.dialect == "postgresql":
                _check_schema_accessibility("CREATE")
        # handle schema upgrade or table creation
        if is_coretable and not db_version:
            e = RuntimeError("Coretable with no revision found in database")
            e.add_note(
                "it is likely that the database was set up with an older version of this library which didn't use revisions yet"
            )
            e.add_note(
                "please set up a new database or add a revision corresponding to the current model manually"
            )
            raise e
        # if postgresql, run alembic and return
        elif self.dialect == "postgresql":
            logger.info(
                "Running database migrations"
                if db_version
                else "Creating new database schema"
            )
            command.upgrade(self.alembic_cfg, "head")
            return
        elif db_version:
            e = NotImplementedError(
                f"Incompatible database revision and automatic migration not implemented for {self.dialect}"
            )
            e.add_note(
                "please set up a new database with the current version of this library"
            )
            raise e
        else:
            # create tables if it's a fresh file-based DB and set it to current revision
            logger.info("Creating new database schema")
            self.create_tables()
            command.stamp(self.alembic_cfg, "head")

    @property
    def _engine(self) -> Engine:
        """Return the synchronous SQLAlchemy engine for the configured datasource."""
        url = (
            self.datasource.set(drivername="postgresql+psycopg")
            if self.dialect == "postgresql"
            else self.datasource
        )
        connect_args: dict[str, str] = {}
        if self.dialect == "postgresql":
            connect_args["connect_timeout"] = 5
            if self.schema:
                connect_args["options"] = f"-csearch_path={self.schema},public"
        engine = create_engine(url, connect_args=connect_args)
        if self.dialect == "geopackage":
            listen(engine, "connect", load_spatialite_gpkg)
        elif self.dialect == "sqlite":
            listen(
                engine,
                "connect",
                load_spatialite_driver,
            )
        return engine

    def get_plan_by_id(self, id: str) -> BaseCollection:
        logger.debug(f"retrieving plan with id {id}")
        with self.Session() as session:
            plan_feature = self._require_plan_feature(session.get(Feature, id), id)
            related = session.scalars(
                self.get_feature_graph(plan_feature.id, depth=2).where(
                    Feature.id != plan_feature.id
                )
            ).all()
            return self._plan_collection_from_features(plan_feature, related)

    def get(self, id: str) -> BaseFeature:
        logger.debug(f"retrieving feature with id {id}")
        with self.Session() as session:
            feature = self._require_feature(session.get(Feature, id), id)
            return self._feature_model(feature)

    def save(self, db_feature: BaseFeature) -> None:
        logger.debug(f"saving feature with id {db_feature.id}")
        with self.Session() as session:
            db_feature = db_feature.model_dump_coretable()
            session.add(db_feature)
            session.commit()

    def delete_plan_by_id(self, id: str) -> BaseFeature:
        logger.debug(f"deleting plan with id {id}")
        with self.Session() as session:
            plan_feature = self._require_plan_feature(session.get(Feature, id), id)
            plan_model = self._feature_model(plan_feature)
            feature_select = self.get_feature_graph(plan_feature.id, depth=2)
            stmt = delete(Feature).where(Feature.id == feature_select.c.id)
            session.execute(stmt)
            session.commit()
            return plan_model

    def delete(self, id: str) -> BaseFeature:
        logger.debug(f"deleting feature with id {id}")
        with self.Session() as session:
            feature = self._require_feature(session.get(Feature, id), id)
            session.delete(feature)
            session.commit()
            return self._feature_model(feature)

    def save_all(
        self, features: BaseCollection | Iterable[BaseFeature], **kwargs
    ) -> None:
        logger.debug("saving collection")
        with self.Session() as session:
            feature_list, refs_list, refs_inv_list = self._serialize_bulk_features(
                features
            )
            if feature_list:
                session.execute(insert(Feature), feature_list)
            refs_list.extend(
                [ref_inv for ref_inv in refs_inv_list if ref_inv not in refs_list]
            )
            if refs_list:
                session.execute(
                    insert(Refs),
                    refs_list,
                )
            session.commit()

    def update_all(
        self, features: BaseCollection | Iterable[BaseFeature], **kwargs
    ) -> None:
        logger.debug("updating collection")
        with self.Session() as session:
            feature_list, refs_list, refs_inv_list = self._serialize_bulk_features(
                features
            )
            for stmt in self._prepare_stmts_for_update(
                feature_list, refs_list, refs_inv_list
            ):
                session.execute(stmt)
            session.commit()

    def update(self, id: str, feature: BaseFeature) -> BaseFeature:
        logger.debug(f"updating feature with id {id}")
        with self.Session() as session:
            self._require_feature(session.get(Feature, id), id)
            feature_data, refs, refs_inv = feature.model_dump_coretable_bulk()
            for stmt in self._prepare_stmts_for_update([feature_data], refs, refs_inv):
                session.execute(stmt)
            session.commit()
            return feature

    def patch(self, id: str, partial_update: dict) -> BaseFeature:
        logger.debug(f"patching feature with id {id}: {partial_update}")
        with self.Session() as session:
            db_feature = self._require_feature(session.get(Feature, id), id)
            patched_feature = self._build_patched_feature(db_feature, partial_update)
            feature_data, refs, refs_inv = patched_feature.model_dump_coretable_bulk()
            for stmt in self._prepare_stmts_for_update([feature_data], refs, refs_inv):
                session.execute(stmt)
            session.commit()
            return patched_feature

    def _prepare_stmts_for_update(
        self,
        feature_list: list[dict],
        refs_list: list[dict],
        refs_inv_list: list[dict],
    ) -> list[Executable]:
        """Build batched DML statements that upsert features and synchronize refs.

        Removes stale inverse references that are owned by the feature (i.e., `rel_inv` is present),
        inserts new ones, and upserts the affected `coretable` rows in a deterministic order.
        """

        def get_refs_as_selectable(ref_data: list[dict]) -> Subquery | CTE:
            """Turns a list of dicts into a selectable."""
            if not ref_data:
                # zero-row selectable
                return (
                    select(
                        *[
                            literal(None, c.type).label(c.name)
                            for c in Refs.__table__.columns
                            if c.name != "pk"
                        ]
                    )
                    .where(False)
                    .alias("src")
                )
            else:
                return (
                    values(*[c for c in Refs.__table__.columns if c.name != "pk"])
                    .data([tuple(r.values()) for r in ref_data])
                    .cte("src")
                )

        stmts = []
        feature_ids = [f["id"] for f in feature_list]

        upsert = pg_upsert if self.dialect == "postgresql" else sqlite_upsert

        if feature_ids:
            forward_delete = delete(Refs).where(Refs.base_id.in_(feature_ids))
            if refs_list:
                subq = get_refs_as_selectable(refs_list)
                forward_delete = forward_delete.where(
                    ~exists(
                        select(1).where(
                            (Refs.base_id == subq.c.base_id)
                            & (Refs.related_id == subq.c.related_id)
                        )
                    )
                )
            stmts.append(forward_delete)

            inverse_delete = delete(Refs).where(
                Refs.related_id.in_(feature_ids) & Refs.rel_inv.is_not(None)
            )
            if refs_inv_list:
                subq_inv = get_refs_as_selectable(refs_inv_list)
                inverse_delete = inverse_delete.where(
                    ~exists(
                        select(1).where(
                            (Refs.base_id == subq_inv.c.base_id)
                            & (Refs.related_id == subq_inv.c.related_id)
                        )
                    )
                )
            stmts.append(inverse_delete)

            if refs_list or refs_inv_list:
                refs_stmt = upsert(Refs).values(
                    refs_list + [ref for ref in refs_inv_list if ref not in refs_list]
                )
                refs_stmt = refs_stmt.on_conflict_do_update(
                    index_elements=[Refs.base_id, Refs.related_id],
                    set_={
                        col.name: getattr(refs_stmt.excluded, col.name)
                        for col in Refs.__table__.columns
                        if col.name in ["rel", "rel_inv"]
                    },
                )
                stmts.append(refs_stmt)

        feature_stmt = upsert(Feature).values(feature_list)
        feature_stmt = feature_stmt.on_conflict_do_update(
            index_elements=[Feature.id],
            set_={
                col.name: getattr(feature_stmt.excluded, col.name)
                for col in Feature.__table__.columns
                if col.name
                in [
                    "featuretype",
                    "properties",
                    "geometry",
                    "appschema",
                    "version",
                ]
            },
        )
        stmts.append(feature_stmt)

        return stmts

    def _require_feature(self, feature: Feature | None, feature_id: str) -> Feature:
        """Ensure the given ORM feature exists.

        Args:
            feature: ORM instance retrieved from the session.
            feature_id: Identifier used for error reporting.

        Returns:
            The validated ORM feature.

        Raises:
            ValueError: If no feature instance was provided.
        """
        if not feature:
            raise ValueError(f"no feature found with id {feature_id}")
        return feature

    def _require_plan_feature(
        self, feature: Feature | None, feature_id: str
    ) -> Feature:
        """Ensure the feature exists and represents a plan object.

        Args:
            feature: ORM instance retrieved from the session.
            feature_id: Identifier used for error reporting.

        Returns:
            The validated ORM feature.

        Raises:
            ValueError: If the feature is missing or not a plan entity.
        """
        feature = self._require_feature(feature, feature_id)
        if "Plan" not in feature.featuretype:
            raise ValueError(f"{feature.featuretype} is not a plan object")
        return feature

    def _feature_model(self, feature: Feature) -> BaseFeature:
        """Instantiate the Pydantic model that matches the ORM feature.

        Args:
            feature: ORM entity fetched from the database.

        Returns:
            Deserialized `BaseFeature` instance of the correct subtype.
        """
        return model_factory(
            feature.featuretype,
            feature.version,
            feature.appschema,
        ).model_validate(feature)

    def _plan_collection_from_features(
        self,
        plan_feature: Feature,
        related_features: Iterable[Feature],
    ) -> BaseCollection:
        """Build a collection with the plan feature and its related items.

        Args:
            plan_feature: Root plan ORM entity.
            related_features: Iterable of related ORM entities.

        Returns:
            A populated `BaseCollection` containing plan plus related features.
        """
        plan_model = self._feature_model(plan_feature)
        collection: dict[str, BaseFeature] = {str(plan_feature.id): plan_model}
        for feature in related_features:
            collection[str(feature.id)] = self._feature_model(feature)
        return BaseCollection(
            features=collection,
            srid=plan_model.get_geom_srid(),
            version=plan_feature.version,
            appschema=plan_feature.appschema,
        )

    def _serialize_bulk_features(
        self, features: BaseCollection | Iterable[BaseFeature]
    ) -> tuple[list[dict], list[dict], list[dict]]:
        """Prepare bulk insert payloads for features and refs tables.

        Args:
            features: Either a collection wrapper or a bare iterable of models.

        Returns:
            Tuple of (feature rows, refs rows) ready for SQLAlchemy bulk insert.
        """
        feature_list = []
        refs_list: list = []
        refs_inv_list: list = []
        for feature in (
            features.get_features()
            if isinstance(features, BaseCollection)
            else features
        ):
            feature_row, refs, refs_inv = feature.model_dump_coretable_bulk()
            feature_list.append(feature_row)
            for ref in refs:
                if ref not in refs_list:
                    refs_list.append(ref)
            for ref_inv in refs_inv:
                if ref_inv not in refs_inv_list:
                    refs_inv_list.append(ref_inv)
        return feature_list, refs_list, refs_inv_list

    def _build_patched_feature(
        self, db_feature: Feature, partial_update: dict
    ) -> BaseFeature:
        """Apply a partial update dict to an existing ORM feature model.

        Args:
            db_feature: Persisted ORM entity to serve as merge base.
            partial_update: Dict of field overrides.

        Returns:
            A new feature model representing the patched state.
        """
        base_model = self._feature_model(db_feature)
        feature_dict = base_model.model_dump()
        return model_factory(
            db_feature.featuretype,
            db_feature.version,
            db_feature.appschema,
        ).model_validate(feature_dict | partial_update)

    @staticmethod
    def _normalize_uuid(value: str | UUID) -> UUID:
        """Normalize UUID input that might be strings.

        Args:
            value: UUID or string representation.

        Returns:
            UUID instance for consistent comparisons.
        """
        return value if isinstance(value, UUID) else UUID(str(value))

    def _uuid_sequence_for_dialect(
        self,
        values: Iterable[str | UUID],
    ) -> tuple[str | UUID, ...]:
        """Normalize UUID iterables for dialect-aware parameter binding.

        Args:
            values: Collection of UUID instances or string representations.

        Returns:
            Tuple with UUID objects for dialects that support them natively and
            string representations for text-only dialects.
        """
        requires_string = self.dialect in {"sqlite", "geopackage"}
        converted: list[str | UUID] = []
        for value in values:
            uuid_value = self._normalize_uuid(value)
            converted.append(str(uuid_value) if requires_string else uuid_value)
        return tuple(converted)

    def get_feature_graph(
        self,
        feature_id: str | UUID,
        *,
        direction: Literal["children", "parents", "both"] = "both",
        depth: int = 0,
    ) -> Select[tuple[Feature]]:
        """Returns a statement to collect the feature graph for a given feature id.

        Args:
            feature_id: UUID or string identifying the root feature.
            direction: Controls traversal direction (children, parents, or both).
            depth: Maximum traversal depth; 0 or None traverses until exhaustion.

        Returns:
            A `Select` statement to collect ORM `Feature` rows that satisfy traversal constraints.
        """
        if depth < 0:
            return []

        traversal = _TraversalConfig(
            root_id=self._normalize_uuid(feature_id),
            walk_children=direction in ("children", "both"),
            walk_parents=direction in ("parents", "both"),
            depth=depth,
        )

        if self.dialect == "postgresql":
            stmt = self._collect_feature_graph_db(
                traversal,
            )
        else:
            stmt = self._collect_feature_graph_python(
                traversal,
            )

        return stmt

    def _collect_feature_graph_python(
        self,
        traversal: _TraversalConfig,
    ) -> Select[tuple[Feature]]:
        """Build a feature result set via SQLAlchemy when server CTEs are unavailable.

        Args:
            traversal: Normalized traversal settings.

        Returns:
            Select statement yielding `Feature` rows that satisfy the traversal.
        """
        visited: set[UUID] = {traversal.root_id}
        related_ids: set[UUID] = set()
        frontier: set[UUID] = {traversal.root_id}
        depth_level = 0

        with self.Session() as session:
            while frontier:
                if traversal.depth and depth_level >= traversal.depth:
                    break

                next_frontier: set[UUID] = set()
                frontier_tuple = self._uuid_sequence_for_dialect(frontier)

                if traversal.walk_children and frontier_tuple:
                    child_query = select(Refs.related_id).where(
                        Refs.base_id.in_(frontier_tuple)
                    )
                    for child_id in session.scalars(child_query):
                        normalized = self._normalize_uuid(child_id)
                        if normalized in visited:
                            continue
                        visited.add(normalized)
                        next_frontier.add(normalized)
                        related_ids.add(normalized)

                if traversal.walk_parents and frontier_tuple:
                    parent_query = select(Refs.base_id).where(
                        Refs.related_id.in_(frontier_tuple)
                    )
                    for parent_id in session.scalars(parent_query):
                        normalized = self._normalize_uuid(parent_id)
                        if normalized in visited:
                            continue
                        visited.add(normalized)
                        next_frontier.add(normalized)
                        related_ids.add(normalized)

                frontier = next_frontier
                depth_level += 1

        id_tuple = self._uuid_sequence_for_dialect(related_ids)

        stmt = select(Feature).where(Feature.id.in_(id_tuple))

        return stmt

    def _collect_feature_graph_db(
        self,
        traversal: _TraversalConfig,
    ) -> Select[tuple[Feature]]:
        """Use the database helper function to gather related `Feature` rows."""
        if not (traversal.walk_children or traversal.walk_parents):
            raise ValueError("direction must include at least one traversal path")

        feature_graph = func.coretable_feature_graph(
            traversal.root_id,
            traversal.depth,
            traversal.walk_children,
            traversal.walk_parents,
        ).table_valued(*Feature.__table__.c)

        stmt = select(Feature).where(exists().where(Feature.id == feature_graph.c.id))

        return stmt

    def create_tables(self) -> None:
        """Creates coretable and related/spatial tables in the database.

        Args:
            srid: the EPSG code for spatial data
        """

        @listens_for(Base.metadata, "before_create")
        def pre_creation(_, conn, **kwargs):
            if self.dialect == "sqlite":
                conn.execute(text("SELECT InitSpatialMetaData('EMPTY')"))
                conn.execute(text("SELECT InsertEpsgSrid(:srid)"), {"srid": self.srid})

        @listens_for(Base.metadata, "after_create")
        def post_creation(_, conn, **kwargs):
            if self.dialect == "geopackage":
                conn.execute(
                    text(
                        """
                        INSERT INTO gpkg_extensions (table_name, extension_name, definition, scope)
                        VALUES
                            ('gpkg_data_columns', 'gpkg_schema', 'http://www.geopackage.org/spec/#extension_schema', 'read-write'),
                            ('gpkg_data_column_constraints', 'gpkg_schema', 'http://www.geopackage.org/spec/#extension_schema', 'read-write'),
                            ('gpkgext_relations', 'related_tables', 'http://www.opengis.net/doc/IS/gpkg-rte/1.0', 'read-write'),
                            ('refs', 'related_tables', 'http://www.opengis.net/doc/IS/gpkg-rte/1.0', 'read-write')
                        """
                    )
                )
                conn.execute(
                    text(
                        """
                        INSERT INTO gpkgext_relations (base_table_name, base_primary_column, related_table_name, related_primary_column, relation_name, mapping_table_name)
                        VALUES
                            ('coretable', 'id', 'coretable', 'id', 'features', 'refs')
                        """
                    )
                )
                conn.execute(
                    text(
                        """
                        INSERT INTO gpkg_data_columns (table_name, column_name, mime_type)
                        VALUES
                            ('coretable', 'properties', 'application/json')
                        """
                    )
                )

        logger.debug(f"creating tables with srid {self.srid}")
        tables = Base.metadata.sorted_tables
        if not self.dialect == "geopackage":
            tables.pop(1)
        tables[0].append_column(
            Column(
                "geometry",
                Geometry(
                    srid=self.srid,
                    spatial_index=True,
                ),
                nullable=True,
            ),
            replace_existing=True,
        )

        try:
            Base.metadata.create_all(self._engine, tables)
            remove(Base.metadata, "before_create", pre_creation)
            remove(Base.metadata, "after_create", post_creation)

        except Exception as e:
            if self.dialect in ["sqlite", "geopackage"]:
                file = self._engine.url.database
                Path(file).unlink(missing_ok=True)
            raise e

    def delete_tables(self) -> None:
        """Deletes coretable and related/spatial tables from the database."""
        logger.debug("deleting tables")
        if self.dialect == "postgresql":
            command.downgrade(self.alembic_cfg, "base")
        else:
            Base.metadata.drop_all(self._engine)


class AsyncDBRepository(DBRepository):
    """Async PostgreSQL-backed repository that reuses synchronous migrations."""

    def __init__(self, datasource: str = "") -> None:
        super().__init__(datasource=datasource)
        if self.dialect != "postgresql":
            raise ValueError(
                "Async DBRepository is only supported for PostgreSQL datasources"
            )

        self._async_engine_instance: AsyncEngine | None = None
        self.AsyncSession: async_sessionmaker[AsyncSession] = async_sessionmaker(
            bind=self._async_engine,
            expire_on_commit=False,
        )

    @property
    def _async_engine(self) -> AsyncEngine:
        """Lazily instantiate the async engine bound to the configured schema."""
        if self._async_engine_instance is None:
            self._async_engine_instance = self._create_async_engine()
        return self._async_engine_instance

    def _create_async_engine(self) -> AsyncEngine:
        """Create a PostgreSQL async engine mirroring the sync configuration."""
        url = self.datasource.set(drivername="postgresql+psycopg_async")
        connect_args: dict[str, str] = {"connect_timeout": 5}
        if self.schema:
            connect_args["options"] = f"-csearch_path={self.schema},public"
        return create_async_engine(url, connect_args=connect_args)

    async def get_plan_by_id(self, id: str) -> BaseCollection:
        logger.debug(f"retrieving plan with id {id}")
        async with self.AsyncSession() as session:
            plan_feature = self._require_plan_feature(
                await session.get(Feature, id),
                id,
            )
            related = await session.scalars(
                self.get_feature_graph(
                    plan_feature.id,
                    depth=2,
                ).where(Feature.id != plan_feature.id)
            )
            return self._plan_collection_from_features(plan_feature, related.all())

    async def get(self, id: str) -> BaseFeature:
        logger.debug(f"retrieving feature with id {id}")
        async with self.AsyncSession() as session:
            feature = self._require_feature(await session.get(Feature, id), id)
            return self._feature_model(feature)

    async def save(self, feature: BaseFeature) -> None:
        logger.debug(f"saving feature with id {feature.id}")
        async with self.AsyncSession() as session:
            db_feature = feature.model_dump_coretable()
            await session.add(db_feature)
            await session.commit()

    async def delete_plan_by_id(self, id: str) -> BaseFeature:
        logger.debug(f"deleting plan with id {id}")
        async with self.AsyncSession() as session:
            plan_feature = self._require_plan_feature(
                await session.get(Feature, id),
                id,
            )
            plan_model = self._feature_model(plan_feature)
            feature_stmt = self.get_feature_graph(plan_feature.id, depth=2)
            stmt = delete(Feature).where(Feature.id == feature_stmt.c.id)
            await session.execute(stmt)
            await session.commit()
            return plan_model

    async def delete(self, id: str) -> BaseFeature:
        logger.debug(f"deleting feature with id {id}")
        async with self.AsyncSession() as session:
            feature = self._require_feature(await session.get(Feature, id), id)
            await session.delete(feature)
            await session.commit()
            return self._feature_model(feature)

    async def save_all(
        self, features: BaseCollection | Iterable[BaseFeature], **kwargs
    ) -> None:
        logger.debug("saving collection")
        async with self.AsyncSession() as session:
            feature_list, refs_list, refs_inv_list = self._serialize_bulk_features(
                features
            )
            if feature_list:
                await session.execute(insert(Feature), feature_list)
            refs_list.extend(
                [ref_inv for ref_inv in refs_inv_list if ref_inv not in refs_list]
            )
            if refs_list:
                await session.execute(
                    insert(Refs),
                    refs_list,
                )
            await session.commit()

    async def update_all(
        self, features: BaseCollection | Iterable[BaseFeature], **kwargs
    ) -> None:
        logger.debug("updating collection")
        async with self.AsyncSession() as session:
            feature_list, refs_list, refs_inv_list = self._serialize_bulk_features(
                features
            )
            for stmt in self._prepare_stmts_for_update(
                feature_list, refs_list, refs_inv_list
            ):
                await session.execute(stmt)
            await session.commit()

    async def update(self, id: str, feature: BaseFeature) -> BaseFeature:
        logger.debug(f"updating feature with id {id}")
        async with self.AsyncSession() as session:
            self._require_feature(await session.get(Feature, id), id)
            feature_data, refs, refs_inv = feature.model_dump_coretable_bulk()
            for stmt in self._prepare_stmts_for_update([feature_data], refs, refs_inv):
                await session.execute(stmt)
            await session.commit()
            return feature

    async def patch(self, id: str, partial_update: dict) -> BaseFeature:
        logger.debug(f"patching feature with id {id}: {partial_update}")
        async with self.AsyncSession() as session:
            db_feature = self._require_feature(await session.get(Feature, id), id)
            patched_feature = self._build_patched_feature(db_feature, partial_update)
            feature_data, refs, refs_inv = patched_feature.model_dump_coretable_bulk()
            for stmt in self._prepare_stmts_for_update([feature_data], refs, refs_inv):
                await session.execute(stmt)
            await session.commit()
            return patched_feature
