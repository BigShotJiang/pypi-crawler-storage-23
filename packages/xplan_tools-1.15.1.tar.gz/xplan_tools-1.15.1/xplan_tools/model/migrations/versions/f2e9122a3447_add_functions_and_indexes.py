"""Adds DB-side functions and more indexes.

The added functions allow efficient collection and deletion related features using CTEs.
A unique index on (Refs.base_id, Refs.related_id) allows for `ON CONFLICT` checks.

Revision ID: f2e9122a3447
Revises: f8b74c08ec07
Create Date: 2026-02-09 09:58:14.813386

"""

from typing import Sequence, Union

from alembic import op

from xplan_tools.settings import get_settings

settings = get_settings()
schema = settings.db_schema

# revision identifiers, used by Alembic.
revision: str = "f2e9122a3447"
down_revision: Union[str, Sequence[str], None] = "f8b74c08ec07"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.create_index(
        op.f("ix_refs_base_id_related_id"),
        "refs",
        ["base_id", "related_id"],
        schema=schema,
        unique=True,
        if_not_exists=True,
    )
    op.execute(f"""
        CREATE OR REPLACE
        FUNCTION {schema or "public"}.coretable_feature_graph(
            start_id UUID,
            depth_limit INTEGER DEFAULT 0,
            include_forward BOOLEAN DEFAULT TRUE,
            include_backward BOOLEAN DEFAULT TRUE
        )
        RETURNS SETOF coretable
        LANGUAGE SQL
        PARALLEL SAFE
        STABLE
        AS $$
        WITH RECURSIVE graph_ids(id, depth) AS (
        -- Anchor - start_id
        SELECT id, 0::INTEGER AS depth
        FROM {schema or "public"}.coretable
        WHERE id = start_id
        UNION ALL
        -- Recursive term - traverse forward and/or inverse edges until depth limit is reached
        SELECT
            edge.id,
            g.depth + 1 AS depth
        FROM graph_ids g
        JOIN LATERAL (
            SELECT r.related_id AS id
            FROM {schema or "public"}.refs r
            WHERE include_forward
            AND r.base_id = g.id
            UNION ALL
            SELECT r.base_id AS id
            FROM {schema or "public"}.refs r
            WHERE include_backward
            AND r.related_id = g.id
        ) edge ON TRUE
        WHERE
            depth_limit = 0
            OR g.depth < depth_limit
        ) CYCLE id SET is_cycle	USING id_path
        SELECT c.*
        FROM {schema or "public"}.coretable c
        WHERE EXISTS (
            SELECT 1
            FROM graph_ids g
            WHERE NOT g.is_cycle
            AND g.id = c.id
        );

        $$;
    """)
    op.execute(f"""
        CREATE OR REPLACE
        FUNCTION {schema or "public"}.coretable_delete_recursive(
            start_id UUID,
            dry_run BOOLEAN DEFAULT FALSE,
            include_forward BOOLEAN DEFAULT TRUE,
            include_backward BOOLEAN DEFAULT FALSE
        )
        RETURNS SETOF coretable
        LANGUAGE plpgsql
        AS $$
        BEGIN
        RETURN QUERY

        WITH candidates AS (
        SELECT
            g.*
        FROM
            {schema or "public"}.coretable_feature_graph(
                    start_id,
                    include_forward,
                    include_backward
                ) g
            ),
        -- Lock candidate rows
        locked_candidates AS (
        SELECT
            c.*
        FROM
            {schema or "public"}.coretable c
        JOIN candidates cand ON
            c.id = cand.id
                FOR
            UPDATE
                ),
        -- Lock referencing edges
        locked_edges AS (
        SELECT
            r.*
        FROM
            {schema or "public"}.refs r
        JOIN locked_candidates lc
                    ON
            r.related_id = lc.id
                FOR SHARE
            ),
        -- Safe-to-delete guard - exclude when referenced by others
        safe_to_delete AS (
        SELECT
            lc.*
        FROM
            locked_candidates lc
        WHERE
            lc.id = start_id
            OR NOT EXISTS (
            SELECT
                1
            FROM
                {schema or "public"}.refs r
            WHERE
                r.related_id = lc.id
                AND r.base_id NOT IN (
                SELECT
                    id
                FROM
                    locked_candidates
                        )
                )
            ),

            deleted_rows AS (
        DELETE
        FROM
            {schema or "public"}.coretable c
                USING safe_to_delete s
        WHERE
            c.id = s.id
            AND NOT dry_run
                RETURNING c.*
            )
        -- Return safe rows (whether dry-run or real delete)
            SELECT
            s.*
        FROM
            safe_to_delete s;
        END;

        $$;
    """)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f("ix_refs_base_id_related_id"), table_name="refs", schema=schema)
    op.execute(
        f"DROP FUNCTION IF EXISTS {schema or 'public'}.coretable_feature_graph(UUID, INTEGER, BOOLEAN, BOOLEAN);"
    )
    op.execute(
        f"DROP FUNCTION IF EXISTS {schema or 'public'}.coretable_delete_recursive(UUID, BOOLEAN, BOOLEAN, BOOLEAN);"
    )
