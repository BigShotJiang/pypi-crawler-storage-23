"""Module defining the ResultReport class for collecting errors, warnings, and output during migrations, transformations and validations via official xplan validation api."""

from contextlib import contextmanager
from enum import Enum
from typing import Any, Dict, List, Optional, Type

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from xplan_tools.model import model_factory
from xplan_tools.model.base import BaseCollection


class _WarnCodes(Enum):
    # migration/transformation related codes
    WARN_ATTRIBUTE_DROPPED = ("ATTRIBUTE_DROPPED", "ATTRIBUT_ÜBERSPRUNGEN")
    WARN_OBJECT_NOT_SUPPORTED = ("OBJECT_NOT_SUPPORTED", "OBJEKT_NICHT_UNTERSTÜTZT")
    WARN_VALUE_NOT_MAPPED = ("VALUE_NOT_MAPPED", "WERT_NICHT_ZUORDNUNGSFÄHIG")
    WARN_OBJECT_DROPPED = ("OBJECT_DROPPED", "OBJEKT_ÜBERSPRUNGEN")
    WARN_RP_PLAN_NOT_SUPPORTED = ("RP_PLAN_NOT_SUPPORTED", "RP_PLAN_NICHT_UNTERSTÜTZT")
    WARN_MANUAL_CHECK = ("MANUAL_CHECK_REQUIRED", "MANUELLE_ÜBERPRÜFUNG_ERFORDERLICH")
    WARN_LP_NOT_TRANSFORMABLE = (
        "LP_OBJECT_NOT_TRANSFORMABLE",
        "LP_OBJECT_NICHT_TRANSFORMIERBAR",
    )
    WARN_PROPERTY_NOT_TRANSFORMABLE = (
        "PROPERTY_NOT_TRANSFORMABLE",
        "PROPERTY_NICHT_TRANSFORMIERBAR",
    )
    WARN_INVALID_GEOMETRY = ("INVALID_GEOMETRY", "UNGÜLTIGE_GEOMETRIE")
    WARN_MISSING_DATES = ("MISSING_DATES", "FEHLENDE_DATUMSANGABEN")
    WARN_MISSING_REQUIRED_ATTRIBUTE = (
        "MISSING_REQUIRED_ATTRIBUTE",
        "FEHLENDES_ERFORDERLICHES_ATTRIBUT",
    )
    WARN_NO_ATTRIBUTE_OR_MATCHING_CODE_FOUND = (
        "NO_ATTRIBUTE_OR_MATCHING_CODE_FOUND",
        "KEIN_ATTRIBUT_ODER_PASSENDER_CODE_GEFUNDEN",
    )
    WARN_FEATURE_NOT_MAPPABLE = (
        "FEATURE_NOT_MAPPABLE",
        "FEATURE_NICHT_ZUORDNUNGSFÄHIG",
    )
    WARN_BEREICH_SKIPPED_PARENT_PLAN = (
        "BEREICH_SKIPPED_PARENT_PLAN",
        "BEREICH_ÜBERSPRUNGEN_ELTERNPLAN",
    )
    WARN_FEATURE_SKIPPED_NO_MAPPING = (
        "FEATURE_SKIPPED_NO_MAPPING",
        "FEATURE_ÜBERSPRUNGEN_KEINE_ZUORDNUNG",
    )

    # repository related codes
    WARN_REPLACE_ID = ("REPLACE_ID", "ID_ERSETZEN")

    # jsonfg encoding related codes
    WARN_SRID_DETECTION_FALLBACK = (
        "JSONFG_SRID_DETECTION_FALLBACK",
        "JSONFG_SRID_DETEKTION_FALLBACK",
    )

    # shape encoding related codes
    WARN_SHAPE_SKIPPED_FIELD = ("SHAPE_SKIPPED_FIELD", "SHAPE_FEHLENDES_FELD")
    WARN_SHAPE_SKIPPED_DATE = ("SHAPE_SKIPPED_DATE", "SHAPE_FEHLENDES_DATUM")
    WARN_INVALID_URL = ("INVALID_URL", "UNGÜLTIGE_URL")

    # xplan validator related codes
    WARN_SEMANTIC_VALIDATION = (
        "SEMANTIC_VALIDATION_WARNING",
        "SEMANTISCHE_VALIDIERUNG_WARNUNG",
    )
    WARN_GEOMETRIC_VALIDATION = (
        "GEOMETRIC_VALIDATION_WARNING",
        "GEOMETRISCHE_VALIDIERUNG_WARNUNG",
    )
    WARN_SYNTACTIC_VALIDATION = (
        "SYNTACTIC_VALIDATION_WARNING",
        "SYNTAKTISCHE_VALIDIERUNG_WARNUNG",
    )


class _ErrorCodes(Enum):
    ERR_VALIDATION_ERROR = ("VALIDATION_ERROR", "VALIDIERUNGSFEHLER")
    ERR_TRANSFORMATION_ERROR = ("TRANSFORMATION_ERROR", "TRANSFORMATIONSFEHLER")
    ERR_INVALID_REF_URL = ("INVALID_REF_URL", "UNGÜLTIGE_REFERENZ_URL")

    # repository related codes
    ERR_VERSION_DETECTION_FAILED = (
        "VERSION_DETECTION_FAILED",
        "VERSION_DETEKTION_FEHLGESCHLAGEN",
    )
    ERR_APPSCHEMA_DETECTION_FAILED = (
        "APPSCHEMA_DETECTION_FAILED",
        "APPSCHEMA_DETEKTION_FEHLGESCHLAGEN",
    )
    ERR_ASSOC_UPDATE_FAILED = (
        "ASSOC_UPDATE_FAILED",
        "AKTUALISIERUNG_ASSOZIATIONEN_FEHLGESCHLAGEN",
    )

    # gml encoding related codes
    ERR_GML_PARSING_FAILED = ("GML_PARSING_FAILED", "GML_PARSING_FEHLER")
    ERR_GML_SRS_NOT_FOUND = ("GML_SRS_NOT_FOUND", "GML_SRS_NICHT_GEFUNDEN")

    # jsonfg encoding related codes
    ERR_JSONFG_UNSUPPORTED_DATASOURCE = (
        "JSONFG_UNSUPPORTED_DATASOURCE",
        "JSONFG_NICHT_UNTERSTÜTZTE_DATENQUELLE",
    )
    ERR_JSONFG_PARSING_FAILED = ("JSONFG_PARSING_FAILED", "JSONFG_PARSING_FEHLER")

    # coretable related codes
    ERR_DB_FEATURE_NOT_FOUND = ("DB_FEATURE_NOT_FOUND", "DB_FEATURE_NICHT_GEFUNDEN")
    ERR_DB_INVALID_PLAN_ID = ("DB_INVALID_PLAN_ID", "DB_FEHLERHAFTE_PLAN_ID")

    # shape encoding related codes
    ERR_SHAPE_MISSING_FIELD = ("SHAPE_MISSING_FIELD", "SHAPE_FEHLENDES_FELD")
    ERR_SHAPE_MISSING_DATE_FIELD = (
        "SHAPE_MISSING_DATE_FIELD",
        "SHAPE_FEHLENDES_DATUMSFELD",
    )
    ERR_SHAPE_GEOM_PARSING_ERROR = (
        "SHAPE_GEOM_PARSING_ERROR",
        "SHAPE_GEOM_PARSING_FEHLER",
    )
    ERR_SHAPE_PLANART_MAPPING_NOT_FOUND = (
        "SHAPE_PLANART_MAPPING_NOT_FOUND",
        "SHAPE_PLANART_MAPPING_NICHT_GEFUNDEN",
    )
    ERR_SHAPE_SRS_NOT_FOUND = ("SHAPE_SRS_NOT_FOUND", "SHAPE_SRS_NICHT_GEFUNDEN")

    # xplan validator related codes
    ERR_VALIDATION_REQUEST_FAILED = (
        "VALIDATION_REQUEST_FAILED",
        "VALIDIERUNGSANFRAGE_FEHLGESCHLAGEN",
    )
    ERR_SEMANTIC_VALIDATION = (
        "SEMANTIC_VALIDATION_ERROR",
        "SEMANTISCHER_VALIDIERUNGSFEHLER",
    )
    ERR_GEOMETRIC_VALIDATION = (
        "GEOMETRIC_VALIDATION_ERROR",
        "GEOMETRISCHER_VALIDIERUNGSFEHLER",
    )
    ERR_SYNTACTIC_VALIDATION = (
        "SYNTACTIC_VALIDATION_ERROR",
        "SYNTAKTISCHER_VALIDIERUNGSFEHLER",
    )


class Issue(BaseModel):
    """Base class for errors and warnings in ResultReport."""

    code: _WarnCodes | _ErrorCodes
    message: str
    location: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="forbid")


class ErrorIssue(Issue):
    """Represents an error issue in ResultReport."""

    code: _ErrorCodes


class WarningIssue(Issue):
    """Represents a warning issue in ResultReport."""

    code: _WarnCodes


class ResultReport(BaseModel):
    """Represents the result report for a transformation or validation process."""

    success: bool = True
    errors: List[ErrorIssue] = Field(default_factory=list)
    warnings: List[WarningIssue] = Field(default_factory=list)
    feature_list: List = []
    output: Optional[BaseCollection] = None
    validation_report: Optional[List[dict]] = None

    exc_type: Optional[Type[Exception]] = None

    model_config = ConfigDict(extra="forbid")

    def add_error(
        self,
        code: _ErrorCodes,
        message: str,
        location: Optional[str] = None,
        **meta: Any,
    ) -> None:
        """Add an error issue to the report and set success to False."""
        self.errors.append(
            ErrorIssue(
                code=code,
                message=message,
                location=location,
                meta=meta,
            )
        )
        self.success = False

    def add_warning(
        self,
        code: _WarnCodes,
        message: str,
        location: Optional[str] = None,
        **meta: Any,
    ) -> None:
        """Add a warning issue to the report."""
        self.warnings.append(
            WarningIssue(
                code=code,
                message=message,
                location=location,
                meta=meta,
            )
        )

    def validate_model(
        self,
        feature,
        feature_type,
        *,
        version,
        appschema,
        context: dict | None = None,
        code: _ErrorCodes,
        message: str,
        location: str,
    ):
        """Safely validate a single feature model."""
        try:
            model = model_factory(
                feature_type,
                version,
                appschema,
            ).model_validate(
                feature,
                context=context,
            )

        except ValidationError as e:
            self.add_error(
                code=code,
                message=message,
                location=location,
                errors=e.errors(),
            )
            return None
        # catch miscellaneous exceptions like geometry parsing errors
        except Exception as e:
            self.add_error(
                code=code,
                message=message,
                location=location,
                errors=str(e),
            )
            return None
        else:
            if getattr(model, "id", None):
                self.feature_list.append(str(model.id))
            return model

    def validate_collection(
        self,
        *,
        features: dict,
        srid: int,
        version: str,
        appschema: str,
        code: _ErrorCodes = _ErrorCodes.ERR_VALIDATION_ERROR,
        message: str = "Collection validation failed",
    ):
        """Safely validate and build a feature collection."""
        try:
            return BaseCollection(
                features=features,
                srid=srid,
                version=version,
                appschema=appschema,
            )

        except ValidationError as e:
            self.add_error(
                code=code,
                message=message,
                errors=e.errors(),
            )

            return None

        except ValueError as e:
            # Raised by model_validator(after) in BaseCollection
            self.add_error(
                code=code,
                message=message,
                errors=str(e),
            )
            return None

        except Exception as e:
            self.add_error(
                code=code,
                message=message,
                errors=str(e),
            )
            return None

    def evaluate_validation_report(self, validation_report: dict):
        """Evaluate a validation report from the XPlanValidator API and update ResultReport accordingly."""
        self.validation_report: dict = validation_report

        if not self.validation_report.get("valid"):
            self.success = False

        for rule in (
            self.validation_report.get("validationResult")
            .get("semantisch")
            .get("rules")
        ):
            if rule.get("warnedFeatures"):
                self.add_warning(
                    code=_WarnCodes.WARN_SEMANTIC_VALIDATION,
                    message=rule.get("message"),
                    name=rule.get("name"),
                    warnedFeatures=rule.get("warnedFeatures"),
                )
            if rule.get("erroredFeatures") or not rule.get("isValid"):
                self.add_error(
                    code=_ErrorCodes.ERR_SEMANTIC_VALIDATION,
                    message=rule.get("message"),
                    name=rule.get("name"),
                    erroredFeatures=rule.get("erroredFeatures"),
                )

        for geom_warning in (
            self.validation_report.get("validationResult")
            .get("geometrisch")
            .get("warnings")
        ):
            self.add_warning(
                code=_WarnCodes.WARN_GEOMETRIC_VALIDATION,
                message=geom_warning,
            )
        for geom_error in (
            self.validation_report.get("validationResult")
            .get("geometrisch")
            .get("errors")
        ):
            self.add_error(
                code=_ErrorCodes.ERR_GEOMETRIC_VALIDATION,
                message=geom_error,
            )

        for message in (
            self.validation_report.get("validationResult")
            .get("syntaktisch")
            .get("messages")
        ):
            if (
                self.validation_report.get("validationResult")
                .get("syntaktisch")
                .get("valid")
            ):
                self.add_warning(
                    code=_WarnCodes.WARN_SYNTACTIC_VALIDATION,
                    message=message,
                )
            else:
                self.add_error(
                    code=_ErrorCodes.ERR_SYNTACTIC_VALIDATION,
                    message=message,
                )

    @property
    def has_errors(self) -> bool:
        """Check if the report contains any errors."""
        return bool(self.errors)

    @property
    def has_warnings(self) -> bool:
        """Check if the report contains any warnings."""
        return bool(self.warnings)

    def finalize(self) -> None:
        """Ensure success flag is consistent."""
        self.success = not self.has_errors


class TransformationValidationError(Exception):
    """Exception raised when a transformation fails, encapsulating the ValidationReport."""

    def __init__(self, result: ResultReport):
        self.result = result
        super().__init__(
            "Transformation failed, see `TransformationValidationError.result.errors` for details."
        )


@contextmanager
def report_guard(
    report: ResultReport,
    code: _ErrorCodes,
    message: str,
    location: Optional[str] = None,
    catch: tuple[Type[Exception], ...] = (Exception,),
    include_exception: bool = True,
):
    """Context manager that catches exceptions and writes them into ResultReport.

    Example:
        with report_guard(result,
                          code=ERR_X,
                          message="Parsing failed"):
            do_something()
    """
    try:
        yield

    except catch as exc:
        meta: Dict[str, Any] = {}

        # Separate handling for pydantic
        if isinstance(exc, ValidationError):
            meta["pydantic_errors"] = exc.errors()

        if include_exception:
            meta["exception"] = str(exc)

        report.add_error(
            code=code,
            message=message,
            location=location,
            **meta,
        )


def raise_if_failed(
    report: ResultReport,
    exc_type: Type[Exception],
) -> None:
    """Raise an exception if the report contains any errors."""
    if report.has_errors:
        raise exc_type(report)
