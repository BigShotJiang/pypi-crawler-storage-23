"""Module, containing the explicit transformation and mapping rules for XPlan 6.0 to XPlan 6.1."""

from xplan_tools.model.result.result_report import _ErrorCodes, _WarnCodes
from xplan_tools.transform import ResultMixin


class rules_60_61(ResultMixin):
    """Base class, containing transformations for all XPlan Data types for version 6.0 to 6.1."""

    warn_codes = _WarnCodes
    error_codes = _ErrorCodes

    def _bpdachgestaltung(self, object: dict) -> None:
        for attr in ["dachform", "detaillierteDachform", "hoehenangabe"]:
            if object.get(attr, None):
                object[attr] = [object[attr]]

    def _sosichtflaeche(self, object: dict) -> None:
        if v := object.get("geschwindigkeit", None):
            object["geschwindigkeit"] = {"value": v.value, "uom": "km/h"}
