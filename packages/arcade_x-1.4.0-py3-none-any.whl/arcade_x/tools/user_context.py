"""User context tools for X (Twitter) toolkit."""

from typing import Annotated

import httpx
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import X
from arcade_tdk.errors import ToolExecutionError

from arcade_x.tools.utils import (
    expand_urls_in_user_description,
    expand_urls_in_user_url,
    get_headers_with_token,
)


@tool(
    requires_auth=X(scopes=["users.read", "tweet.read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOCIAL_MEDIA],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: ToolContext,
) -> Annotated[dict, "Authenticated user's profile information"]:
    """
    Get information about the authenticated X (Twitter) user.

    Returns the current user's profile including their username, name, description,
    follower counts, and other account information.
    """
    headers = get_headers_with_token(context)

    # User fields to retrieve
    user_fields = ",".join([
        "created_at",
        "description",
        "id",
        "location",
        "most_recent_tweet_id",
        "name",
        "pinned_tweet_id",
        "profile_image_url",
        "protected",
        "public_metrics",
        "url",
        "username",
        "verified",
        "verified_type",
        "withheld",
        "entities",
    ])

    # Use the /2/users/me endpoint to get authenticated user's information
    # API Reference: https://developer.x.com/en/docs/x-api/users/lookup/api-reference/get-users-me
    # Returns user object with fields: id, name, username, and optional expansions
    url = f"https://api.x.com/2/users/me?user.fields={user_fields}"

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers, timeout=10)
            response.raise_for_status()
    except httpx.HTTPStatusError as e:
        raise ToolExecutionError(
            f"X API returned an error: {e.response.status_code} {e.response.reason_phrase}"
        ) from e

    except httpx.RequestError as e:
        raise ToolExecutionError(f"Failed to connect to X API: {e}") from e

    # Parse the response JSON
    response_data = response.json()
    user_data = response_data.get("data")

    if not user_data:
        raise ToolExecutionError(f"X API response missing 'data' field. Response: {response_data}")

    # Expand URLs in the user description and profile URL
    user_data = expand_urls_in_user_description(user_data, delete_entities=False)
    user_data = expand_urls_in_user_url(user_data, delete_entities=True)

    return {"data": user_data}
