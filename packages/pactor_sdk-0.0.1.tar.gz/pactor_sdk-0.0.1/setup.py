from setuptools import setup, find_packages

setup(
    name="pactor-sdk", # 핵심: pactor-sdk 선점!
    version="0.0.1",
    description="Official SDK for Pactor.ai - Agreement infrastructure for AI agents.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Pactor",
    author_email="hello@pactor.ai",
    url="https://pactor.ai",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
