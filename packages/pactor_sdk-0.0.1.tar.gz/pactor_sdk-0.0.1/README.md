# Pactor SDK

Official Python SDK for Pactor.ai.
Agreement infrastructure for AI agents to negotiate with a shared, auditable state.

*Coming soon.*
