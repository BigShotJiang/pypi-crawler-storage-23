"""
Sistema de Roteamento automático inspirado no DRF.

Características:
- Auto-registro de ViewSets
- Geração automática de rotas REST
- Nomes previsíveis
- OpenAPI consistente com schemas tipados para request/response
- Exportação rica para Postman (campos pré-configurados)
- Override manual quando necessário
- Integração nativa com FastAPI
"""

from __future__ import annotations

from typing import Any, ClassVar, Optional, TYPE_CHECKING, get_args, get_origin
from collections.abc import Callable
import inspect
import logging
import os

from fastapi import APIRouter, Request, Depends, Body
from pydantic import BaseModel, ValidationError as PydanticValidationError, create_model
from sqlalchemy.ext.asyncio import AsyncSession

from strider.dependencies import get_db, get_optional_user
from strider.serializers import (
    InputSchema,
    OutputSchema,
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse,
    DeleteResponse,
    ValidationErrorResponse,
    NotFoundResponse,
    ConflictResponse,
)
from strider.openapi_examples import build_schema_example, build_response_example

if TYPE_CHECKING:
    from strider.views import ViewSet, APIView

logger = logging.getLogger("strider.routing")


# =============================================================================
# Helpers para OpenAPI / Schema resolution
# =============================================================================

# Cache para modelos parciais (PATCH)
_partial_model_cache: dict[type, type] = {}

# Cache for model-based fallback schemas (OpenAPI docs when user does not set input_schema/output_schema)
_fallback_schemas_cache: dict[type, tuple[type[BaseModel], type[BaseModel]]] = {}

# SQLAlchemy column type -> Python type for OpenAPI fallback schemas
_SA_TYPE_MAP: dict[str, type] = {
    "INTEGER": int,
    "BIGINT": int,
    "SMALLINT": int,
    "VARCHAR": str,
    "STRING": str,
    "TEXT": str,
    "CHAR": str,
    "BOOLEAN": bool,
    "FLOAT": float,
    "NUMERIC": float,
    "DECIMAL": float,
    "JSON": dict,
    "JSONB": dict,
}


def _openapi_python_type_for_column(col: Any) -> type:
    """Resolve Python type for a SQLAlchemy column (for doc-only fallback schemas)."""
    type_str = str(col.type).upper()
    for key, py_type in _SA_TYPE_MAP.items():
        if key in type_str:
            return py_type
    if "UUID" in type_str:
        from uuid import UUID
        return UUID
    if "DATETIME" in type_str or "TIMESTAMP" in type_str or "DATE" in type_str:
        from datetime import datetime
        return datetime
    return str


def _build_fallback_schemas_from_model(
    model: type,
) -> tuple[type[InputSchema], type[OutputSchema]]:
    """
    Build input/output Pydantic schemas from a SQLAlchemy model for OpenAPI docs.
    Used when the ViewSet does not define input_schema/output_schema.
    """
    if model in _fallback_schemas_cache:
        return _fallback_schemas_cache[model]
    try:
        table = getattr(model, "__table__", None)
        if table is None:
            raise ValueError("Model has no __table__")
    except Exception:
        # Return minimal placeholder schemas so docs still show something
        inp = create_model(
            f"{getattr(model, '__name__', 'Model')}InputFallback",
            __base__=InputSchema,
            body=(dict[str, Any], ...),
        )
        out = create_model(
            f"{getattr(model, '__name__', 'Model')}OutputFallback",
            __base__=OutputSchema,
            id=(int, ...),
            data=(dict[str, Any], ...),
        )
        _fallback_schemas_cache[model] = (inp, out)
        return inp, out

    name = getattr(model, "__name__", "Model")
    out_fields: dict[str, Any] = {}
    in_fields: dict[str, Any] = {}

    for col in table.columns:
        py_type = _openapi_python_type_for_column(col)
        ann = py_type if not col.nullable else Optional[py_type]
        default = None if col.nullable else ...
        out_fields[col.name] = (ann, default)

        # Input: skip PK and autoincrement
        if getattr(col, "primary_key", False) or getattr(col, "autoincrement", False):
            continue
        in_ann = py_type if not col.nullable and col.default is None and col.server_default is None else Optional[py_type]
        in_default = None if (col.nullable or col.default is not None or col.server_default is not None) else ...
        in_fields[col.name] = (in_ann, in_default)

    if not in_fields:
        in_fields["body"] = (dict[str, Any], ...)
    out_schema = create_model(
        f"{name}OutputFallback",
        __base__=OutputSchema,
        **out_fields,
    )
    in_schema = create_model(
        f"{name}InputFallback",
        __base__=InputSchema,
        **in_fields,
    )
    _fallback_schemas_cache[model] = (in_schema, out_schema)
    return in_schema, out_schema


def _make_partial_model(schema: type[BaseModel]) -> type[BaseModel]:
    """
    Cria um modelo Pydantic com todos os campos opcionais.
    
    Usado para endpoints PATCH onde apenas alguns campos são enviados.
    O resultado é cacheado por classe de schema.
    
    Herda do schema original para preservar:
    - model_config (extra="forbid", str_strip_whitespace, etc.)
    - Validators customizados
    - Métodos e propriedades
    
    Args:
        schema: Modelo Pydantic original com campos obrigatórios
    
    Returns:
        Novo modelo com todos os campos Optional e default None
    """
    if schema in _partial_model_cache:
        return _partial_model_cache[schema]
    
    fields = {}
    for field_name, field_info in schema.model_fields.items():
        annotation = field_info.annotation
        if annotation is not None:
            fields[field_name] = (Optional[annotation], None)
        else:
            fields[field_name] = (Optional[Any], None)
    
    # Herda do schema original para preservar model_config e validators
    partial_model = create_model(
        f"Partial{schema.__name__}",
        __base__=schema,
        **fields,
    )
    
    _partial_model_cache[schema] = partial_model
    return partial_model


def _resolve_schemas(
    viewset_class: type,
) -> tuple[type[InputSchema] | None, type[OutputSchema] | None]:
    """
    Resolve input and output schemas from a ViewSet class.
    Uses serializer_class if set; falls back to model-based schemas for OpenAPI docs when missing.
    """
    input_schema = getattr(viewset_class, "input_schema", None)
    output_schema = getattr(viewset_class, "output_schema", None)

    serializer_class = getattr(viewset_class, "serializer_class", None)
    if not input_schema and serializer_class:
        input_schema = getattr(serializer_class, "input_schema", None)
    if not output_schema and serializer_class:
        output_schema = getattr(serializer_class, "output_schema", None)

    # Fallback for OpenAPI: when user did not set schemas, build from model so docs are not null
    model = getattr(viewset_class, "model", None)
    if model is not None:
        if input_schema is None or output_schema is None:
            fallback_in, fallback_out = _build_fallback_schemas_from_model(model)
            if input_schema is None:
                input_schema = fallback_in
            if output_schema is None:
                output_schema = fallback_out

    return input_schema, output_schema


def _is_dynamic_path_segment(segment: str) -> bool:
    """Return True when segment represents a dynamic parameter."""
    if segment.startswith("{") and segment.endswith("}"):
        return True
    # Regex-style FastAPI segments (e.g. (?P<id>[^/]+))
    return "(?P<" in segment


def _default_custom_action_sort_key(
    action_name: str,
    url_path: str,
    detail: bool,
) -> tuple[int, int, int, int, int, str]:
    """
    Automatic route ordering:
    - more static segments first
    - fewer dynamic segments first
    - path wildcards / regex segments last
    - longer paths first
    """
    segments = [seg for seg in (url_path or "").strip("/").split("/") if seg]
    static_count = 0
    dynamic_count = 0
    wildcard_count = 0
    regex_count = 0

    for segment in segments:
        if segment.startswith("{") and segment.endswith("}"):
            dynamic_count += 1
            inner = segment[1:-1]
            if ":" in inner:
                _, converter = inner.split(":", 1)
                if converter.strip().lower() == "path":
                    wildcard_count += 1
            continue

        if _is_dynamic_path_segment(segment):
            dynamic_count += 1
            regex_count += 1
            continue

        static_count += 1

    return (
        -static_count,
        dynamic_count,
        wildcard_count,
        regex_count,
        -len(segments),
        action_name,
    )


def _iter_sorted_custom_actions(
    viewset_class: type["ViewSet"],
    detail_filter: bool | None = None,
) -> list[tuple[str, Callable]]:
    """
    Collect custom actions and return them in deterministic priority order.
    """
    items: list[tuple[tuple[Any, ...], str, Callable]] = []
    custom_sorter = getattr(viewset_class, "custom_action_sort_key", None)

    for name, method in inspect.getmembers(viewset_class, predicate=inspect.isfunction):
        if not getattr(method, "is_action", False):
            continue

        detail = method.detail
        if detail_filter is not None and detail != detail_filter:
            continue

        url_path = method.url_path
        if callable(custom_sorter):
            try:
                key = custom_sorter(name, url_path, detail)
            except Exception as exc:
                logger.warning(
                    "custom_action_sort_key failed in %s.%s (%s); using default sorter",
                    viewset_class.__name__,
                    name,
                    exc,
                )
                key = _default_custom_action_sort_key(name, url_path, detail)
        else:
            key = _default_custom_action_sort_key(name, url_path, detail)

        items.append((key, name, method))

    items.sort(key=lambda item: item[0])
    return [(name, method) for _, name, method in items]


def _build_error_responses(
    include_404: bool = False,
    include_409: bool = False,
    include_422: bool = True,
) -> dict[int, dict[str, Any]]:
    """
    Constrói respostas de erro comuns para documentação OpenAPI.
    
    Args:
        include_404: Incluir resposta 404 Not Found
        include_409: Incluir resposta 409 Conflict
        include_422: Incluir resposta 422 Validation Error
    
    Returns:
        Dict de status_code → schema para OpenAPI responses
    """
    responses: dict[int, dict[str, Any]] = {}
    
    if include_422:
        responses[422] = {
            "description": "Erro de validação nos dados enviados",
            "model": ValidationErrorResponse,
        }
    
    if include_404:
        responses[404] = {
            "description": "Recurso não encontrado",
            "model": NotFoundResponse,
        }
    
    if include_409:
        responses[409] = {
            "description": "Conflito - registro com valor duplicado",
            "model": ConflictResponse,
        }
    
    return responses


def _get_openapi_example_settings() -> Any:
    """Load settings lazily to avoid import-time coupling."""
    try:
        from strider.config import get_settings

        return get_settings()
    except Exception:
        return None


def _merge_response_specs(
    base: dict[int, dict[str, Any]] | None,
    extra: dict[int, dict[str, Any]] | None,
) -> dict[int, dict[str, Any]]:
    merged: dict[int, dict[str, Any]] = dict(base or {})
    for code, spec in (extra or {}).items():
        existing = merged.get(code)
        if isinstance(existing, dict):
            patched = dict(existing)
            patched.update(spec)
            merged[code] = patched
        else:
            merged[code] = spec
    return merged


def _build_openapi_examples(
    *,
    input_schema: type[BaseModel] | None = None,
    output_schema: type[BaseModel] | None = None,
    success_status: int = 200,
    settings: Any = None,
) -> tuple[dict[str, Any] | None, dict[int, dict[str, Any]]]:
    request_example = build_schema_example(input_schema, settings=settings) if input_schema else None
    response_example = build_response_example(output_schema, settings=settings) if output_schema else None

    openapi_extra: dict[str, Any] | None = None
    if request_example is not None:
        openapi_extra = {
            "requestBody": {
                "content": {
                    "application/json": {
                        "example": request_example,
                    },
                },
            },
        }

    responses: dict[int, dict[str, Any]] = {}
    if response_example is not None:
        responses[success_status] = {
            "description": "Exemplo de resposta",
            "content": {
                "application/json": {
                    "example": response_example,
                },
            },
        }

    return openapi_extra, responses


def _annotation_contains_basemodel(annotation: Any) -> bool:
    """Return True when annotation references a Pydantic BaseModel."""
    if annotation in (inspect._empty, Any, None):
        return False
    if isinstance(annotation, type):
        try:
            return issubclass(annotation, BaseModel)
        except TypeError:
            return False
    origin = get_origin(annotation)
    if origin is None:
        return False
    return any(_annotation_contains_basemodel(arg) for arg in get_args(annotation))


def _annotation_accepts_mapping(annotation: Any) -> bool:
    """Return True when annotation accepts a dict-like payload."""
    if annotation in (inspect._empty, Any):
        return True
    if annotation is dict:
        return True
    origin = get_origin(annotation)
    if origin is dict:
        return True
    if origin is None:
        return False
    return any(_annotation_accepts_mapping(arg) for arg in get_args(annotation))


def _extract_first_basemodel_type(annotation: Any) -> type[BaseModel] | None:
    """Extract first BaseModel type found in an annotation tree."""
    if annotation in (inspect._empty, Any, None):
        return None
    if isinstance(annotation, type):
        try:
            if issubclass(annotation, BaseModel):
                return annotation
        except TypeError:
            return None
    origin = get_origin(annotation)
    if origin is None:
        return None
    for arg in get_args(annotation):
        model_type = _extract_first_basemodel_type(arg)
        if model_type is not None:
            return model_type
    return None


def _pick_body_param_name(
    target_callable: Callable,
    *,
    path_params: dict[str, Any],
) -> tuple[str | None, bool, dict[str, inspect.Parameter]]:
    """
    Resolve which callable parameter should receive request body.
    Returns (target_param_name, has_var_kwargs, method_params).
    """
    method_sig = inspect.signature(target_callable)
    method_params = method_sig.parameters
    has_var_kwargs = any(
        p.kind == inspect.Parameter.VAR_KEYWORD
        for p in method_params.values()
    )
    candidate_body_params = [
        p.name
        for p in method_params.values()
        if p.name not in {"self", "request", "db", "_user"}
        and p.kind in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        )
    ]
    preferred_names = ("data", "payload", "body", "input", "dto", "schema")

    for preferred in preferred_names:
        if preferred in candidate_body_params and preferred not in path_params:
            return preferred, has_var_kwargs, method_params
    for candidate in candidate_body_params:
        if candidate not in path_params:
            return candidate, has_var_kwargs, method_params
    return None, has_var_kwargs, method_params


def _build_body_call_kwargs(
    target_callable: Callable,
    *,
    path_params: dict[str, Any],
    body: Any,
    default_name: str = "data",
    exclude_unset: bool = False,
) -> dict[str, Any]:
    """Build kwargs for a callable, injecting body into the most suitable parameter."""
    kwargs: dict[str, Any] = dict(path_params)
    if body is None:
        return kwargs

    target_param, has_var_kwargs, method_params = _pick_body_param_name(
        target_callable,
        path_params=path_params,
    )

    body_value = body
    if target_param is not None:
        target_annotation = method_params[target_param].annotation
        if not hasattr(body_value, "model_dump"):
            target_model_type = _extract_first_basemodel_type(target_annotation)
            if target_model_type is not None:
                try:
                    body_value = target_model_type.model_validate(body_value)
                except PydanticValidationError:
                    # Let FastAPI/global exception handlers render structured 422
                    raise
        if (
            hasattr(body, "model_dump")
            and _annotation_accepts_mapping(target_annotation)
            and not _annotation_contains_basemodel(target_annotation)
        ):
            body_value = body.model_dump(exclude_unset=exclude_unset)
    elif hasattr(body, "model_dump"):
        body_value = body.model_dump(exclude_unset=exclude_unset)

    if target_param is not None:
        kwargs[target_param] = body_value
    elif has_var_kwargs:
        kwargs[default_name] = body_value
    return kwargs


# =============================================================================
# Router
# =============================================================================

class Router(APIRouter):
    """
    Router estendido com funcionalidades extras.
    
    Compatível com FastAPI APIRouter, mas com métodos adicionais
    para registro de ViewSets com documentação OpenAPI rica.
    
    Inclui proteção contra registro duplicado de rotas.
    
    Exemplo:
        router = Router(prefix="/api/v1", tags=["api"])
        router.register_viewset("/users", UserViewSet)
    """
    
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._viewsets: list[tuple[str, type]] = []
        self._ws_routes: list = []
        # Rastreia rotas registradas para prevenir duplicação
        self._registered_routes: set[tuple[str, str]] = set()  # (path, method)
        self._route_conflict_policy = os.getenv(
            "STRIDER_ROUTE_CONFLICT_POLICY",
            "raise",
        ).lower()
        if self._route_conflict_policy not in {"raise", "warn", "ignore"}:
            logger.warning(
                "Invalid STRIDER_ROUTE_CONFLICT_POLICY=%r; using 'raise'",
                self._route_conflict_policy,
            )
            self._route_conflict_policy = "raise"
    
    def add_api_route(
        self,
        path: str,
        endpoint: Callable,
        *,
        methods: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Override para prevenir registro duplicado de rotas.
        
        Se uma rota com o mesmo (path, method) já foi registrada,
        emite um warning e ignora o registro duplicado.
        """
        import warnings
        
        route_methods = methods or ["GET"]
        
        # Verifica duplicatas
        duplicates = []
        for m in route_methods:
            key = (path, m.upper())
            if key in self._registered_routes:
                duplicates.append(m.upper())
            else:
                self._registered_routes.add(key)
        
        if duplicates:
            route_name = kwargs.get("name", endpoint.__name__)
            message = (
                f"Rota duplicada detectada: {duplicates} {path} (name={route_name}). "
                "Verifique includes, auto-discovery e registro duplicado de ViewSet/router."
            )
            if self._route_conflict_policy == "raise":
                raise RuntimeError(message)
            if self._route_conflict_policy == "warn":
                warnings.warn(message, UserWarning, stacklevel=2)
            return
        
        super().add_api_route(path, endpoint, methods=methods, **kwargs)

    def include_router(self, router: "APIRouter", **kwargs: Any) -> None:
        """Include another router, propagating WebSocket routes with prefix."""
        super().include_router(router, **kwargs)
        extra_prefix = kwargs.get("prefix", "")
        router_prefix = getattr(router, "prefix", "")
        combined = extra_prefix + router_prefix
        child_ws = getattr(router, "_ws_routes", [])
        if child_ws:
            from starlette.routing import WebSocketRoute
            for r in child_ws:
                full_path = combined + r.path
                self._ws_routes.append(
                    WebSocketRoute(full_path, r.endpoint, name=r.name)
                )

    def register_viewset(
        self,
        prefix: str,
        viewset_class: type["ViewSet"],
        basename: str | None = None,
        tags: list[str] | None = None,
        include_crud: bool | None = None,
    ) -> None:
        """
        Registra um ViewSet com rotas REST automáticas e OpenAPI tipado.
        
        Gera documentação OpenAPI completa com:
        - Request body schemas (campos de entrada tipados)
        - Response schemas (campos de saída tipados)
        - Modelo parcial automático para PATCH
        - Respostas de erro documentadas (422, 404, 409)
        
        Para ViewSet com model: cria rotas CRUD + actions customizadas.
        Para ViewSet sem model: cria apenas actions customizadas.
        
        Args:
            prefix: Prefixo da URL (ex: "/users")
            viewset_class: Classe do ViewSet
            basename: Nome base para as rotas (default: nome do model)
            tags: Tags para OpenAPI
            include_crud: Forçar criação de rotas CRUD (default: auto-detecta por model)
        """
        viewset = viewset_class()
        openapi_settings = _get_openapi_example_settings()
        
        # Detecta se tem model (para decidir sobre CRUD routes)
        has_model = hasattr(viewset_class, "model") and viewset_class.model is not None
        
        # Respeita _exclude_crud do ViewSet (ex: AuthViewSet nunca cria CRUD)
        exclude_crud = getattr(viewset_class, "_exclude_crud", False)
        
        # Auto-detecta include_crud baseado em model, ou usa valor explícito
        if include_crud is None:
            include_crud = has_model and not exclude_crud
        
        # Infer basename from model or class name
        if basename is None:
            model = getattr(viewset_class, "model", None)
            if model is not None:
                basename = getattr(model, "__tablename__", None) or model.__name__.lower()
            else:
                class_name = viewset_class.__name__
                basename = class_name.lower().replace("viewset", "").replace("view", "") or "api"
        
        tags = tags or viewset_class.tags or [basename]
        
        lookup_field = viewset_class.lookup_field
        lookup_url_kwarg = viewset_class.lookup_url_kwarg or lookup_field
        
        # Normaliza o prefixo
        prefix = prefix.rstrip("/")
        
        # Se não tem model e não forçou CRUD, registra apenas actions customizadas
        if not include_crud:
            self._register_custom_actions(
                prefix, viewset_class, basename, tags, lookup_url_kwarg,
                detail_filter=None  # Registra todas as actions
            )
            return
        
        # ==================================================================
        # Resolve schemas para documentação OpenAPI tipada
        # ==================================================================
        input_schema, output_schema = _resolve_schemas(viewset_class)
        partial_input_schema = _make_partial_model(input_schema) if input_schema else None
        
        # Response models
        list_response_model = PaginatedResponse[output_schema] if output_schema else None
        detail_response_model = output_schema
        
        # Nome do model para descrições
        model_cls = getattr(viewset_class, "model", None)
        model_label = model_cls.__name__ if model_cls else basename.title()
        
        # ==================================================================
        # 1. LIST (GET) - Lista paginada
        # ==================================================================
        async def list_route(
            request, db=Depends(get_db), _user=Depends(get_optional_user),
            page=1, page_size=viewset_class.page_size,
        ):
            vs = viewset_class()
            return await vs.list(request, db, page=page, page_size=page_size)
        
        # Annotations programáticas (bypass de __future__.annotations)
        list_route.__annotations__ = {
            "request": Request,
            "db": AsyncSession,
            "_user": Any,
            "page": int,
            "page_size": int,
        }
        
        list_openapi_extra, list_success_responses = _build_openapi_examples(
            output_schema=list_response_model,
            success_status=200,
            settings=openapi_settings,
        )
        self.add_api_route(
            f"{prefix}/",
            list_route,
            methods=["GET"],
            tags=tags,
            name=f"{basename}-list",
            summary=f"List {basename}s",
            description=(
                f"Retorna lista paginada de **{model_label}**.\n\n"
                f"Suporta paginação via query params `page` e `page_size`.\n"
                f"O `page_size` máximo é {viewset_class.max_page_size}."
            ),
            response_model=list_response_model,
            responses=_merge_response_specs(
                _build_error_responses(include_422=False),
                list_success_responses,
            ),
            openapi_extra=list_openapi_extra,
        )
        
        # ==================================================================
        # 2. CREATE (POST) - Criação com schema tipado
        # ==================================================================
        async def create_route(
            request, data=Body(...), db=Depends(get_db),
            _user=Depends(get_optional_user),
        ):
            vs = viewset_class()
            call_kwargs = _build_body_call_kwargs(
                vs.create,
                path_params={},
                body=data,
            )
            return await vs.create(request, db, **call_kwargs)
        
        create_route.__annotations__ = {
            "request": Request,
            "data": input_schema if input_schema else dict[str, Any],
            "db": AsyncSession,
            "_user": Any,
        }
        
        create_openapi_extra, create_success_responses = _build_openapi_examples(
            input_schema=input_schema,
            output_schema=detail_response_model,
            success_status=201,
            settings=openapi_settings,
        )
        self.add_api_route(
            f"{prefix}/",
            create_route,
            methods=["POST"],
            tags=tags,
            name=f"{basename}-create",
            summary=f"Create {basename}",
            description=f"Cria um novo **{model_label}**.",
            status_code=201,
            response_model=detail_response_model,
            responses=_merge_response_specs(
                _build_error_responses(include_422=True, include_409=True),
                create_success_responses,
            ),
            openapi_extra=create_openapi_extra,
        )
        
        # ==================================================================
        # 3. Actions detail=False (ANTES das rotas {id} para evitar conflitos)
        #    Ex: /users/me deve ser registrada antes de /users/{id}
        # ==================================================================
        self._register_custom_actions(
            prefix, viewset_class, basename, tags, lookup_url_kwarg,
            detail_filter=False  # Só registra detail=False
        )
        
        # ==================================================================
        # 4. RETRIEVE (GET detail) - Detalhes com response tipado
        # ==================================================================
        async def retrieve_route(
            request, db=Depends(get_db), _user=Depends(get_optional_user),
        ):
            vs = viewset_class()
            path_params = request.path_params
            return await vs.retrieve(request, db, **path_params)
        
        retrieve_route.__annotations__ = {
            "request": Request,
            "db": AsyncSession,
            "_user": Any,
        }
        
        retrieve_openapi_extra, retrieve_success_responses = _build_openapi_examples(
            output_schema=detail_response_model,
            success_status=200,
            settings=openapi_settings,
        )
        self.add_api_route(
            f"{prefix}/{{{lookup_url_kwarg}}}",
            retrieve_route,
            methods=["GET"],
            tags=tags,
            name=f"{basename}-detail",
            summary=f"Get {basename} by {lookup_url_kwarg}",
            description=f"Retorna detalhes de um **{model_label}** específico pelo `{lookup_url_kwarg}`.",
            response_model=detail_response_model,
            responses=_merge_response_specs(
                _build_error_responses(include_404=True, include_422=False),
                retrieve_success_responses,
            ),
            openapi_extra=retrieve_openapi_extra,
        )
        
        # ==================================================================
        # 5. UPDATE (PUT) - Atualização completa com schema tipado
        # ==================================================================
        async def update_route(
            request, data=Body(...), db=Depends(get_db),
            _user=Depends(get_optional_user),
        ):
            vs = viewset_class()
            path_params = request.path_params
            call_kwargs = _build_body_call_kwargs(
                vs.update,
                path_params=path_params,
                body=data,
            )
            return await vs.update(request, db, **call_kwargs)
        
        update_route.__annotations__ = {
            "request": Request,
            "data": input_schema if input_schema else dict[str, Any],
            "db": AsyncSession,
            "_user": Any,
        }
        
        update_openapi_extra, update_success_responses = _build_openapi_examples(
            input_schema=input_schema,
            output_schema=detail_response_model,
            success_status=200,
            settings=openapi_settings,
        )
        self.add_api_route(
            f"{prefix}/{{{lookup_url_kwarg}}}",
            update_route,
            methods=["PUT"],
            tags=tags,
            name=f"{basename}-update",
            summary=f"Update {basename}",
            description=(
                f"Atualiza completamente um **{model_label}** existente.\n\n"
                f"Todos os campos obrigatórios devem ser enviados."
            ),
            response_model=detail_response_model,
            responses=_merge_response_specs(
                _build_error_responses(
                    include_404=True, include_409=True, include_422=True,
                ),
                update_success_responses,
            ),
            openapi_extra=update_openapi_extra,
        )
        
        # ==================================================================
        # 6. PARTIAL UPDATE (PATCH) - Atualização parcial com modelo parcial
        # ==================================================================
        async def partial_update_route(
            request, data=Body(...), db=Depends(get_db),
            _user=Depends(get_optional_user),
        ):
            vs = viewset_class()
            path_params = request.path_params
            call_kwargs = _build_body_call_kwargs(
                vs.partial_update,
                path_params=path_params,
                body=data,
                exclude_unset=True,
            )
            return await vs.partial_update(request, db, **call_kwargs)
        
        partial_update_route.__annotations__ = {
            "request": Request,
            "data": partial_input_schema if partial_input_schema else dict[str, Any],
            "db": AsyncSession,
            "_user": Any,
        }
        
        patch_openapi_extra, patch_success_responses = _build_openapi_examples(
            input_schema=partial_input_schema if partial_input_schema else input_schema,
            output_schema=detail_response_model,
            success_status=200,
            settings=openapi_settings,
        )
        self.add_api_route(
            f"{prefix}/{{{lookup_url_kwarg}}}",
            partial_update_route,
            methods=["PATCH"],
            tags=tags,
            name=f"{basename}-partial-update",
            summary=f"Partial update {basename}",
            description=(
                f"Atualiza parcialmente um **{model_label}**.\n\n"
                f"Apenas os campos enviados serão atualizados. "
                f"Campos omitidos permanecem inalterados."
            ),
            response_model=detail_response_model,
            responses=_merge_response_specs(
                _build_error_responses(
                    include_404=True, include_409=True, include_422=True,
                ),
                patch_success_responses,
            ),
            openapi_extra=patch_openapi_extra,
        )
        
        # ==================================================================
        # 7. DELETE - Deleção com response tipado
        # ==================================================================
        async def destroy_route(
            request, db=Depends(get_db), _user=Depends(get_optional_user),
        ):
            vs = viewset_class()
            path_params = request.path_params
            return await vs.destroy(request, db, **path_params)
        
        destroy_route.__annotations__ = {
            "request": Request,
            "db": AsyncSession,
            "_user": Any,
        }
        
        delete_openapi_extra, delete_success_responses = _build_openapi_examples(
            output_schema=DeleteResponse,
            success_status=200,
            settings=openapi_settings,
        )
        self.add_api_route(
            f"{prefix}/{{{lookup_url_kwarg}}}",
            destroy_route,
            methods=["DELETE"],
            tags=tags,
            name=f"{basename}-delete",
            summary=f"Delete {basename}",
            description=f"Remove permanentemente um **{model_label}** pelo `{lookup_url_kwarg}`.",
            response_model=DeleteResponse,
            responses=_merge_response_specs(
                _build_error_responses(include_404=True, include_422=False),
                delete_success_responses,
            ),
            openapi_extra=delete_openapi_extra,
        )
        
        # ==================================================================
        # 8. Actions detail=True (DEPOIS das rotas {id})
        #    Ex: /users/{id}/activate
        # ==================================================================
        self._register_custom_actions(
            prefix, viewset_class, basename, tags, lookup_url_kwarg,
            detail_filter=True  # Só registra detail=True
        )
        
        # Guarda referência
        self._viewsets.append((prefix, viewset_class))
    
    def _register_custom_actions(
        self,
        prefix: str,
        viewset_class: type["ViewSet"],
        basename: str,
        tags: list[str],
        lookup_url_kwarg: str,
        detail_filter: bool | None = None,
    ) -> None:
        """
        Registra actions customizadas decoradas com @action.
        
        Suporta schemas tipados para request/response via parâmetros
        do decorator @action(input_schema=..., output_schema=...).
        
        Args:
            prefix: Prefixo da URL
            viewset_class: Classe do ViewSet
            basename: Nome base para as rotas
            tags: Tags para OpenAPI
            lookup_url_kwarg: Nome do parâmetro de URL para lookup
            detail_filter: Se especificado, filtra actions por detail:
                          - True: só registra actions com detail=True
                          - False: só registra actions com detail=False
                          - None: registra todas as actions
        """
        viewset_input_schema, viewset_output_schema = _resolve_schemas(viewset_class)
        openapi_settings = _get_openapi_example_settings()

        registered_signatures: set[tuple[str, str]] = set()
        conflict_policy = str(getattr(viewset_class, "route_conflict_policy", "warn")).lower()
        if conflict_policy not in {"warn", "raise", "ignore"}:
            logger.warning(
                "Invalid route_conflict_policy=%r in %s; using 'warn'",
                conflict_policy,
                viewset_class.__name__,
            )
            conflict_policy = "warn"

        for name, method in _iter_sorted_custom_actions(viewset_class, detail_filter):
            action_methods = method.methods
            detail = method.detail
            url_path = method.url_path

            if detail:
                path = f"{prefix}/{{{lookup_url_kwarg}}}/{url_path}"
            else:
                path = f"{prefix}/{url_path}"

            # Action schemas: from @action or fallback to viewset/model so OpenAPI docs are not null
            action_input_schema = getattr(method, "action_input_schema", None)
            action_output_schema = getattr(method, "action_output_schema", None)
            if action_input_schema is None and viewset_input_schema is not None:
                action_input_schema = viewset_input_schema
            if action_output_schema is None and viewset_output_schema is not None:
                action_output_schema = viewset_output_schema

            # Cria endpoint para cada método HTTP
            for http_method in action_methods:
                method_upper = http_method.upper()
                signature = (path, method_upper)
                if signature in registered_signatures:
                    msg = (
                        f"Duplicate custom action route detected in {viewset_class.__name__}: "
                        f"{method_upper} {path} (action={name})"
                    )
                    if conflict_policy == "raise":
                        raise ValueError(msg)
                    if conflict_policy == "warn":
                        logger.warning(msg)
                else:
                    registered_signatures.add(signature)

                route_name = f"{basename}-{name}"
                
                # Get action-specific permission_classes
                action_permission_classes = getattr(method, "permission_classes", None)
                
                # Determina se o método HTTP suporta body
                method_has_body = http_method.upper() in ("POST", "PUT", "PATCH")
                
                # Captura method em closure para evitar late binding
                def make_action_endpoint(
                    action_method: Callable,
                    perm_classes: list | None = None,
                    a_input_schema: type | None = None,
                    with_body: bool = True,
                ) -> Callable:
                    if with_body:
                        # Endpoint COM body (POST, PUT, PATCH)
                        async def action_endpoint(
                            request,
                            db=Depends(get_db),
                            _user=Depends(get_optional_user),
                            data=Body(None),
                        ):
                            vs = viewset_class()
                            
                            if perm_classes:
                                from strider.permissions import check_permissions
                                perms = [p() if isinstance(p, type) else p for p in perm_classes]
                                await check_permissions(perms, request, vs)
                            
                            path_params = request.path_params
                            if data is not None:
                                call_kwargs = _build_body_call_kwargs(
                                    action_method,
                                    path_params=path_params,
                                    body=data,
                                )
                                return await action_method(vs, request, db, **call_kwargs)
                            return await action_method(vs, request, db, **path_params)
                        
                        # Typed annotations para OpenAPI
                        if a_input_schema:
                            data_type = Optional[a_input_schema]
                        else:
                            data_type = Optional[dict[str, Any]]
                        
                        action_endpoint.__annotations__ = {
                            "request": Request,
                            "db": AsyncSession,
                            "_user": Any,
                            "data": data_type,
                        }
                    else:
                        # Endpoint SEM body (GET, DELETE) - limpo no OpenAPI
                        async def action_endpoint(
                            request,
                            db=Depends(get_db),
                            _user=Depends(get_optional_user),
                        ):
                            vs = viewset_class()
                            
                            if perm_classes:
                                from strider.permissions import check_permissions
                                perms = [p() if isinstance(p, type) else p for p in perm_classes]
                                await check_permissions(perms, request, vs)
                            
                            path_params = request.path_params
                            return await action_method(vs, request, db, **path_params)
                        
                        action_endpoint.__annotations__ = {
                            "request": Request,
                            "db": AsyncSession,
                            "_user": Any,
                        }
                    
                    return action_endpoint
                
                action_openapi_extra, action_success_responses = _build_openapi_examples(
                    input_schema=action_input_schema if method_has_body else None,
                    output_schema=action_output_schema,
                    success_status=200,
                    settings=openapi_settings,
                )
                self.add_api_route(
                    path,
                    make_action_endpoint(
                        method, action_permission_classes,
                        action_input_schema, with_body=method_has_body,
                    ),
                    methods=[method_upper],
                    tags=tags,
                    name=route_name,
                    summary=f"{name.replace('_', ' ').title()}",
                    response_model=action_output_schema,
                    responses=action_success_responses if action_success_responses else None,
                    openapi_extra=action_openapi_extra,
                )
    
    def register_view(
        self,
        path: str,
        view_class: type["APIView"],
        methods: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Registra uma APIView.
        
        Args:
            path: Caminho da rota
            view_class: Classe da view
            methods: Métodos HTTP permitidos
            **kwargs: Argumentos extras para a rota
        """
        view = view_class()
        methods = methods or ["GET", "POST", "PUT", "PATCH", "DELETE"]
        tags = kwargs.pop("tags", view_class.tags or [])
        input_schema = getattr(view_class, "input_schema", None)
        output_schema = getattr(view_class, "output_schema", None)
        openapi_settings = _get_openapi_example_settings()
        
        async def endpoint(
            request: Request,
            db: AsyncSession = Depends(get_db),
            _user: Any = Depends(get_optional_user),
            data: Any = Body(None),
        ) -> Any:
            method = request.method.lower()
            handler = getattr(view, method, None)
            
            if handler is None:
                from fastapi import HTTPException
                raise HTTPException(status_code=405, detail="Method not allowed")
            
            await view.check_permissions(request, method)
            path_params = request.path_params
            if request.method.upper() in {"POST", "PUT", "PATCH"} and data is not None:
                call_kwargs = _build_body_call_kwargs(
                    handler,
                    path_params=path_params,
                    body=data,
                )
                return await handler(request, db=db, **call_kwargs)
            return await handler(request, db=db, **path_params)
        
        view_openapi_extra, view_success_responses = _build_openapi_examples(
            input_schema=input_schema,
            output_schema=output_schema,
            success_status=200,
            settings=openapi_settings,
        )
        existing_responses = kwargs.pop("responses", None)
        merged_responses = _merge_response_specs(existing_responses, view_success_responses)
        self.add_api_route(
            path,
            endpoint,
            methods=methods,
            tags=tags,
            responses=merged_responses if merged_responses else None,
            openapi_extra=view_openapi_extra,
            **kwargs,
        )

    def register_websocket(
        self,
        path: str,
        view_class: type,
    ) -> None:
        """
        Register a ``WebSocketView`` subclass on this router.

        The route is stored as a Starlette ``WebSocketRoute`` and collected
        by ``StrideApp`` at startup so it can be served **outside** the HTTP
        middleware stack (which would otherwise crash on WebSocket scopes).

        Args:
            path: URL path (may contain path parameters, e.g. ``/ws/{room}``)
            view_class: A ``WebSocketView`` subclass
        """
        from strider.realtime import WebSocketView
        route = view_class.as_route(path)
        if not hasattr(self, "_ws_routes"):
            self._ws_routes: list = []
        self._ws_routes.append(route)

    def register_sse(
        self,
        path: str,
        view_class: type,
        **kwargs: Any,
    ) -> None:
        """
        Register an ``SSEView`` subclass as a standard GET route.

        SSE is plain HTTP so it goes through the normal middleware stack.

        Args:
            path: URL path (may contain path parameters)
            view_class: An ``SSEView`` subclass
        """
        from strider.realtime import SSEView
        from starlette.responses import StreamingResponse as _SR
        from starlette.requests import Request as _Req

        async def endpoint(request: _Req) -> _SR:
            view = view_class()
            params = request.path_params or {}
            return _SR(
                view._generate(request, params),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                    **view.headers,
                },
            )

        tags = kwargs.pop("tags", [])
        self.add_api_route(path, endpoint, methods=["GET"], tags=tags, **kwargs)


class AutoRouter:
    """
    Router automático que descobre e registra ViewSets.
    
    Similar ao DefaultRouter do DRF.
    
    Tags são resolvidas UMA vez no register(), sem duplicação no OpenAPI:
    - tags explícitas em register() → prioridade máxima
    - tags do AutoRouter(tags=...) → fallback padrão
    - ViewSet.tags → fallback da classe
    - [basename] → último recurso
    
    Exemplo:
        auto_router = AutoRouter(tags=["Auth"])
        auto_router.register("/login", LoginViewSet)                    # → tags=["Auth"]
        auto_router.register("/users", UserViewSet, tags=["Users"])     # → tags=["Users"]
        
        app.include_router(auto_router.router)
    """
    
    def __init__(
        self,
        prefix: str = "",
        tags: list[str] | None = None,
    ) -> None:
        self._default_tags = tags or []
        # Tags NÃO são passadas ao Router — resolução acontece em register()
        # para evitar que FastAPI acumule router-tags + route-tags no OpenAPI
        self.router = Router(prefix=prefix)
        self._registry: list[tuple[str, type, dict[str, Any]]] = []
    
    def _resolve_tags(
        self,
        explicit_tags: list[str] | None,
        viewset_or_view: type | None = None,
    ) -> list[str] | None:
        """
        Resolve tags com prioridade, sem duplicação.
        
        Ordem: explicit > AutoRouter default > ViewSet/APIView.tags > None
        Retorna None para deixar register_viewset usar [basename] como último recurso.
        """
        if explicit_tags is not None:
            return explicit_tags
        if self._default_tags:
            return self._default_tags
        if viewset_or_view is not None:
            cls_tags = getattr(viewset_or_view, "tags", None)
            if cls_tags:
                return cls_tags
        return None
    
    def register(
        self,
        prefix: str,
        viewset_class: type["ViewSet"],
        basename: str | None = None,
        tags: list[str] | None = None,
    ) -> None:
        """
        Registra um ViewSet.
        
        Tags são resolvidas aqui com prioridade:
        1. tags (argumento explícito)
        2. AutoRouter._default_tags
        3. ViewSet.tags
        4. [basename] (resolvido em register_viewset)
        
        Args:
            prefix: Prefixo da URL
            viewset_class: Classe do ViewSet
            basename: Nome base para as rotas
            tags: Tags para OpenAPI (prioridade máxima)
        """
        resolved_tags = self._resolve_tags(tags, viewset_class)
        
        self._registry.append((prefix, viewset_class, {
            "basename": basename,
            "tags": resolved_tags,
        }))
        self.router.register_viewset(prefix, viewset_class, basename, resolved_tags)
    
    def register_view(
        self,
        path: str,
        view_class: type["APIView"],
        **kwargs: Any,
    ) -> None:
        """Registra uma APIView, aplicando tags padrão do AutoRouter se não fornecidas."""
        if "tags" not in kwargs:
            resolved = self._resolve_tags(None, view_class)
            if resolved:
                kwargs["tags"] = resolved
        self.router.register_view(path, view_class, **kwargs)

    def register_websocket(
        self,
        path: str,
        view_class: type,
    ) -> None:
        """Register a ``WebSocketView`` on the inner router."""
        self.router.register_websocket(path, view_class)

    def register_sse(
        self,
        path: str,
        view_class: type,
        **kwargs: Any,
    ) -> None:
        """Register an ``SSEView`` on the inner router."""
        if "tags" not in kwargs:
            resolved = self._resolve_tags(None, view_class)
            if resolved:
                kwargs["tags"] = resolved
        self.router.register_sse(path, view_class, **kwargs)

    def include_router(
        self,
        router: "AutoRouter | Router",
        prefix: str = "",
        tags: list[str] | None = None,
    ) -> None:
        """
        Inclui outro router neste router.
        
        Args:
            router: Router a incluir (AutoRouter ou Router)
            prefix: Prefixo adicional para as rotas
            tags: Tags adicionais para OpenAPI
        """
        # Se for AutoRouter, pega o router interno
        if isinstance(router, AutoRouter):
            inner_router = router.router
        else:
            inner_router = router
        
        # Inclui no router interno — tags já foram resolvidas em register(),
        # só passa tags aqui se explicitamente fornecidas pelo caller
        self.router.include_router(inner_router, prefix=prefix, tags=tags or [])
    
    @property
    def urls(self) -> list[dict[str, Any]]:
        """Retorna lista de URLs registradas."""
        return [
            {
                "path": route.path,
                "name": route.name,
                "methods": route.methods,
            }
            for route in self.router.routes
        ]
    
    def get_api_root_view(self) -> Callable:
        """
        Retorna uma view que lista todas as URLs da API.
        
        Similar ao api_root do DRF.
        """
        registry = self._registry
        
        async def api_root(request: Request) -> dict[str, str]:
            return {
                basename or viewset.__name__.lower(): str(request.url_for(f"{basename or viewset.__name__.lower()}-list"))
                for prefix, viewset, opts in registry
                for basename in [opts.get("basename")]
            }
        
        return api_root


def include_router(
    app_or_router: Any,
    router: Router | AutoRouter,
    prefix: str = "",
    tags: list[str] | None = None,
) -> None:
    """
    Inclui um router em uma aplicação ou outro router.
    
    Função utilitária para simplificar a inclusão de routers.
    
    Args:
        app_or_router: FastAPI app ou APIRouter
        router: Router ou AutoRouter a incluir
        prefix: Prefixo adicional
        tags: Tags adicionais
    """
    actual_router = router.router if isinstance(router, AutoRouter) else router
    app_or_router.include_router(actual_router, prefix=prefix, tags=tags or [])
