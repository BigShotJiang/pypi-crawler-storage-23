"""Type aliases used across simpy_stats."""

from __future__ import annotations

from typing import Union

# Simulation time — either int or float
SimTime = Union[int, float]
