"""Publishing functionality for jamb."""
