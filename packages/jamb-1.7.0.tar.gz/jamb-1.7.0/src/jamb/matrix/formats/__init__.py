"""Matrix output format implementations."""
