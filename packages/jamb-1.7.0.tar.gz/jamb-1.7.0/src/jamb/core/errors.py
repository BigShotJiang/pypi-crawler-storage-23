"""Exception hierarchy for jamb."""


class JambError(Exception):
    """Base exception for all expected jamb errors."""
