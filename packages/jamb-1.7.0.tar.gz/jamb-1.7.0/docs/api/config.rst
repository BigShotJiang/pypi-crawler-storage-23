Configuration
=============

.. module:: jamb.config.loader

Configuration loading and schema for jamb.

JambConfig
----------

.. autoclass:: JambConfig
   :members:

load_config
-----------

.. autofunction:: load_config
