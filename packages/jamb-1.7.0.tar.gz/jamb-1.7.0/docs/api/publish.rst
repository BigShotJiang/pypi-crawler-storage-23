Publishing
==========

Document rendering for regulatory submissions.

HTML Renderer
-------------

.. module:: jamb.publish.formats.html

.. autofunction:: render_html

DOCX Renderer
--------------

.. module:: jamb.publish.formats.docx

.. autofunction:: render_docx
