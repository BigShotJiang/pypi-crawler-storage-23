# User Guide

Detailed documentation for using jamb in your projects.

```{toctree}
:maxdepth: 2

concepts
configuration
commands
publishing
yaml-format
pytest-integration
ci-cd
design
```
