"""RT82 Display - Upload GIFs to Epomaker RT82 keyboard LCD screen."""

__version__ = "0.1.0"
