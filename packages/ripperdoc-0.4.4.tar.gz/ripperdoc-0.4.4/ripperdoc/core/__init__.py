"""Core functionality for Ripperdoc."""
