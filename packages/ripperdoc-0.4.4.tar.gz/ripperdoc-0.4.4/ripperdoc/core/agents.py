"""Agent definitions and helpers for Ripperdoc subagents."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import yaml

from ripperdoc.core.hooks.config import HooksConfig, parse_hooks_config
from ripperdoc.core.plugins import discover_plugins
from ripperdoc.utils.coerce import parse_boolish
from ripperdoc.utils.log import get_logger
from ripperdoc.tools.ask_user_question_tool import AskUserQuestionTool
from ripperdoc.tools.bash_output_tool import BashOutputTool
from ripperdoc.tools.bash_tool import BashTool
from ripperdoc.tools.enter_plan_mode_tool import EnterPlanModeTool
from ripperdoc.tools.exit_plan_mode_tool import ExitPlanModeTool
from ripperdoc.tools.file_edit_tool import FileEditTool
from ripperdoc.tools.file_read_tool import FileReadTool
from ripperdoc.tools.file_write_tool import FileWriteTool
from ripperdoc.tools.glob_tool import GlobTool
from ripperdoc.tools.grep_tool import GrepTool
from ripperdoc.tools.kill_bash_tool import KillBashTool
from ripperdoc.tools.ls_tool import LSTool
from ripperdoc.tools.lsp_tool import LspTool
from ripperdoc.tools.multi_edit_tool import MultiEditTool
from ripperdoc.tools.notebook_edit_tool import NotebookEditTool
from ripperdoc.tools.skill_tool import SkillTool
from ripperdoc.tools.todo_tool import TodoReadTool, TodoWriteTool
from ripperdoc.tools.tool_search_tool import ToolSearchTool
from ripperdoc.tools.mcp_tools import (
    ListMcpResourcesTool,
    ListMcpServersTool,
    ReadMcpResourceTool,
)


logger = get_logger()


def _safe_tool_name(factory: Any, fallback: str) -> str:
    try:
        name = getattr(factory(), "name", None)
        return str(name) if name else fallback
    except (TypeError, ValueError, RuntimeError, AttributeError):
        return fallback


GLOB_TOOL_NAME = _safe_tool_name(GlobTool, "Glob")
GREP_TOOL_NAME = _safe_tool_name(GrepTool, "Grep")
READ_TOOL_NAME = _safe_tool_name(FileReadTool, "Read")
FILE_EDIT_TOOL_NAME = _safe_tool_name(FileEditTool, "FileEdit")
MULTI_EDIT_TOOL_NAME = _safe_tool_name(MultiEditTool, "MultiEdit")
NOTEBOOK_EDIT_TOOL_NAME = _safe_tool_name(NotebookEditTool, "NotebookEdit")
FILE_WRITE_TOOL_NAME = _safe_tool_name(FileWriteTool, "FileWrite")
LS_TOOL_NAME = _safe_tool_name(LSTool, "LS")
BASH_TOOL_NAME = _safe_tool_name(BashTool, "Bash")
BASH_OUTPUT_TOOL_NAME = _safe_tool_name(BashOutputTool, "BashOutput")
KILL_BASH_TOOL_NAME = _safe_tool_name(KillBashTool, "KillBash")
TODO_READ_TOOL_NAME = _safe_tool_name(TodoReadTool, "TodoRead")
TODO_WRITE_TOOL_NAME = _safe_tool_name(TodoWriteTool, "TodoWrite")
ASK_USER_QUESTION_TOOL_NAME = _safe_tool_name(AskUserQuestionTool, "AskUserQuestion")
ENTER_PLAN_MODE_TOOL_NAME = _safe_tool_name(EnterPlanModeTool, "EnterPlanMode")
EXIT_PLAN_MODE_TOOL_NAME = _safe_tool_name(ExitPlanModeTool, "ExitPlanMode")
TOOL_SEARCH_TOOL_NAME = _safe_tool_name(ToolSearchTool, "ToolSearch")
MCP_LIST_SERVERS_TOOL_NAME = _safe_tool_name(ListMcpServersTool, "ListMcpServers")
MCP_LIST_RESOURCES_TOOL_NAME = _safe_tool_name(ListMcpResourcesTool, "ListMcpResources")
MCP_READ_RESOURCE_TOOL_NAME = _safe_tool_name(ReadMcpResourceTool, "ReadMcpResource")
LSP_TOOL_NAME = _safe_tool_name(LspTool, "LSP")
SKILL_TOOL_NAME = _safe_tool_name(SkillTool, "Skill")
TASK_TOOL_NAME = "Task"


AGENT_DIR_NAME = "agents"


class AgentLocation(str, Enum):
    """Where an agent definition is sourced from."""

    BUILT_IN = "built-in"
    USER = "user"
    PROJECT = "project"
    PLUGIN = "plugin"


@dataclass
class AgentDefinition:
    """A parsed agent definition."""

    agent_type: str
    when_to_use: str
    tools: List[str]
    system_prompt: str
    location: AgentLocation
    model: Optional[str] = None
    color: Optional[str] = None
    filename: Optional[str] = None
    fork_context: bool = False
    hooks: HooksConfig = field(default_factory=HooksConfig)
    plugin_name: Optional[str] = None


@dataclass
class AgentLoadResult:
    """Result of loading agent definitions."""

    active_agents: List[AgentDefinition]
    all_agents: List[AgentDefinition]
    failed_files: List[Tuple[Path, str]]


GENERAL_AGENT_PROMPT = (
    "You are a general-purpose subagent for Ripperdoc. Work autonomously on the task "
    "provided by the parent agent. Use the allowed tools to research, edit files, and "
    "run commands as needed. When you finish, provide a concise report describing what "
    "you changed, what you investigated, and any follow-ups the parent agent should "
    "share with the user."
)

CODE_REVIEW_AGENT_PROMPT = (
    "You are a code review subagent. Inspect the code and summarize risks, bugs, "
    "missing tests, security concerns, and regressions. Do not make code changes. "
    "Provide clear, actionable feedback that the parent agent can relay to the user."
)


def _tool_available(agent_tools: Iterable[str], tool_name: str) -> bool:
    names = {name for name in agent_tools if isinstance(name, str)}
    return "*" in names or tool_name in names


def _format_tool_list(tool_names: List[str]) -> str:
    if not tool_names:
        return ""
    if len(tool_names) == 1:
        return tool_names[0]
    if len(tool_names) == 2:
        return f"{tool_names[0]} and {tool_names[1]}"
    return ", ".join(tool_names[:-1]) + f", and {tool_names[-1]}"


def _read_only_shell_guidelines(agent_tools: Iterable[str], prefix: str = "") -> List[str]:
    if _tool_available(agent_tools, BASH_TOOL_NAME):
        return [
            f"{prefix}- Use {BASH_TOOL_NAME} ONLY for read-only operations (ls, git status, git log, git diff, find, cat, head, tail)",
            f"{prefix}- NEVER use {BASH_TOOL_NAME} for: mkdir, touch, rm, cp, mv, git add, git commit, npm install, pip install, or any file creation/modification",
        ]
    return [
        f"{prefix}- No {BASH_TOOL_NAME} tool is available in this subagent session. Do not claim to run shell, git, or gh commands."
    ]


def _build_explore_agent_prompt(agent_tools: Iterable[str]) -> str:
    strengths: List[str] = []
    guidelines: List[str] = []

    if _tool_available(agent_tools, GLOB_TOOL_NAME):
        strengths.append("Rapidly finding files using glob patterns")
        guidelines.append(f"- Use {GLOB_TOOL_NAME} for broad file pattern matching")
    if _tool_available(agent_tools, GREP_TOOL_NAME):
        strengths.append("Searching code and text with powerful regex patterns")
        guidelines.append(f"- Use {GREP_TOOL_NAME} for searching file contents with regex")
    if _tool_available(agent_tools, READ_TOOL_NAME):
        strengths.append("Reading and analyzing file contents")
        guidelines.append(
            f"- Use {READ_TOOL_NAME} when you know the specific file path you need to read"
        )

    if not strengths:
        strengths.append("Analyzing existing code and reporting findings clearly")
    if not guidelines:
        guidelines.append("- Use available read-only tools to locate files and inspect code")

    guidelines.extend(_read_only_shell_guidelines(agent_tools))
    guidelines.extend(
        [
            "- Adapt your search approach based on the thoroughness level specified by the caller",
            "- Return file paths as absolute paths in your final response",
            "- For clear communication, avoid using emojis",
            "- Communicate your final report directly as a regular message - do NOT attempt to create files",
        ]
    )

    strength_lines = "\n".join(f"- {line}" for line in strengths)
    guideline_lines = "\n".join(guidelines)

    return (
        "You are a file search specialist. "
        "You excel at thoroughly navigating and exploring codebases.\n\n"
        "=== CRITICAL: READ-ONLY MODE - NO FILE MODIFICATIONS ===\n"
        "This is a READ-ONLY exploration task. You are STRICTLY PROHIBITED from:\n"
        "- Creating new files (no Write, touch, or file creation of any kind)\n"
        "- Modifying existing files (no Edit operations)\n"
        "- Deleting files (no rm or deletion)\n"
        "- Moving or copying files (no mv or cp)\n"
        "- Creating temporary files anywhere, including /tmp\n"
        "- Using redirect operators (>, >>, |) or heredocs to write to files\n"
        "- Running ANY commands that change system state\n\n"
        "Your role is EXCLUSIVELY to search and analyze existing code. You do NOT have access "
        "to file editing tools - attempting to edit files will fail.\n\n"
        "Your strengths:\n"
        f"{strength_lines}\n\n"
        "Guidelines:\n"
        f"{guideline_lines}\n\n"
        "NOTE: You are meant to be a fast agent that returns output as quickly as possible. In order to achieve this you must:\n"
        "- Make efficient use of the tools that you have at your disposal: be smart about how you search for files and implementations\n"
        "- Wherever possible you should try to spawn multiple parallel tool calls for grepping and reading files\n\n"
        "Complete the user's search request efficiently and report your findings clearly."
    )


def _build_plan_agent_prompt(agent_tools: Iterable[str]) -> str:
    explore_lines = [
        "   - Read any files provided to you in the initial prompt",
    ]
    explore_tools: List[str] = []
    if _tool_available(agent_tools, GLOB_TOOL_NAME):
        explore_tools.append(GLOB_TOOL_NAME)
    if _tool_available(agent_tools, GREP_TOOL_NAME):
        explore_tools.append(GREP_TOOL_NAME)
    if _tool_available(agent_tools, READ_TOOL_NAME):
        explore_tools.append(READ_TOOL_NAME)

    if explore_tools:
        explore_lines.append(
            f"   - Find existing patterns and conventions using {_format_tool_list(explore_tools)}"
        )
    else:
        explore_lines.append(
            "   - Find existing patterns and conventions using available read-only tools"
        )

    explore_lines.extend(
        [
            "   - Understand the current architecture",
            "   - Identify similar features as reference",
            "   - Trace through relevant code paths",
        ]
    )
    explore_lines.extend(_read_only_shell_guidelines(agent_tools, prefix="   "))
    explore_section = "\n".join(explore_lines)

    return (
        "You are a software architect and planning specialist. Your role is "
        "to explore the codebase and design implementation plans.\n\n"
        "=== CRITICAL: READ-ONLY MODE - NO FILE MODIFICATIONS ===\n"
        "This is a READ-ONLY planning task. You are STRICTLY PROHIBITED from:\n"
        "- Creating new files (no Write, touch, or file creation of any kind)\n"
        "- Modifying existing files (no Edit operations)\n"
        "- Deleting files (no rm or deletion)\n"
        "- Moving or copying files (no mv or cp)\n"
        "- Creating temporary files anywhere, including /tmp\n"
        "- Using redirect operators (>, >>, |) or heredocs to write to files\n"
        "- Running ANY commands that change system state\n\n"
        "Your role is EXCLUSIVELY to explore the codebase and design implementation plans. "
        "You do NOT have access to file editing tools - attempting to edit files will fail.\n\n"
        "You will be provided with a set of requirements and optionally a perspective on how "
        "to approach the design process.\n\n"
        "## Your Process\n\n"
        "1. **Understand Requirements**: Focus on the requirements provided and apply your "
        "assigned perspective throughout the design process.\n\n"
        "2. **Explore Thoroughly**:\n"
        f"{explore_section}\n\n"
        "3. **Design Solution**:\n"
        "   - Create implementation approach based on your assigned perspective\n"
        "   - Consider trade-offs and architectural decisions\n"
        "   - Follow existing patterns where appropriate\n\n"
        "4. **Detail the Plan**:\n"
        "   - Provide step-by-step implementation strategy\n"
        "   - Identify dependencies and sequencing\n"
        "   - Anticipate potential challenges\n\n"
        "## Required Output\n\n"
        "End your response with:\n\n"
        "### Critical Files for Implementation\n"
        "List 3-5 files most critical for implementing this plan:\n"
        '- path/to/file1.ts - [Brief reason: e.g., "Core logic to modify"]\n'
        '- path/to/file2.ts - [Brief reason: e.g., "Interfaces to implement"]\n'
        '- path/to/file3.ts - [Brief reason: e.g., "Pattern to follow"]\n\n'
        "REMEMBER: You can ONLY explore and plan. You CANNOT and MUST NOT write, edit, or "
        "modify any files. You do NOT have access to file editing tools."
    )


DEFAULT_READ_ONLY_SUBAGENT_TOOLS = [READ_TOOL_NAME, GLOB_TOOL_NAME, GREP_TOOL_NAME]
EXPLORE_AGENT_PROMPT = _build_explore_agent_prompt(DEFAULT_READ_ONLY_SUBAGENT_TOOLS)
PLAN_AGENT_PROMPT = _build_plan_agent_prompt(DEFAULT_READ_ONLY_SUBAGENT_TOOLS)


def _built_in_agents() -> List[AgentDefinition]:
    read_only_tools = list(DEFAULT_READ_ONLY_SUBAGENT_TOOLS)
    return [
        AgentDefinition(
            agent_type="general-purpose",
            when_to_use=(
                "General-purpose agent for multi-step coding tasks, deep searches, and "
                "investigations that need their own context window."
            ),
            tools=["*"],
            system_prompt=GENERAL_AGENT_PROMPT,
            location=AgentLocation.BUILT_IN,
            color="cyan",
        ),
        AgentDefinition(
            agent_type="code-reviewer",
            when_to_use=(
                "Run after implementing non-trivial code changes to review for correctness, "
                "testing gaps, security issues, and regressions."
            ),
            tools=list(read_only_tools),
            system_prompt=CODE_REVIEW_AGENT_PROMPT,
            location=AgentLocation.BUILT_IN,
            color="yellow",
        ),
        AgentDefinition(
            agent_type="explore",
            when_to_use=(
                "Fast agent specialized for exploring codebases. Use this when you need to quickly find "
                'files by patterns (eg. "src/components/**/*.tsx"), search code for keywords (eg. "API endpoints"), '
                'or answer questions about the codebase (eg. "how do API endpoints work?"). When calling this agent, '
                'specify the desired thoroughness level: "quick" for basic searches, "medium" for moderate exploration, '
                'or "very thorough" for comprehensive analysis across multiple locations and naming conventions.'
            ),
            tools=list(read_only_tools),
            system_prompt=_build_explore_agent_prompt(read_only_tools),
            location=AgentLocation.BUILT_IN,
            color="green",
            model="main",
        ),
        AgentDefinition(
            agent_type="plan",
            when_to_use=(
                "Software architect agent for designing implementation plans. Use this when "
                "you need to plan the implementation strategy for a task. Returns step-by-step "
                "plans, identifies critical files, and considers architectural trade-offs."
            ),
            tools=list(read_only_tools),
            system_prompt=_build_plan_agent_prompt(read_only_tools),
            location=AgentLocation.BUILT_IN,
            color="blue",
            model=None,
        ),
    ]


def _agent_dirs(
    project_path: Optional[Path] = None, home: Optional[Path] = None
) -> List[Tuple[Path, AgentLocation]]:
    home_dir = (home or Path.home()) / ".ripperdoc" / AGENT_DIR_NAME
    project_dir = (project_path or Path.cwd()).resolve() / ".ripperdoc" / AGENT_DIR_NAME
    return [
        (home_dir, AgentLocation.USER),
        (project_dir, AgentLocation.PROJECT),
    ]


def _agent_dir_for_location(
    location: AgentLocation,
    project_path: Optional[Path] = None,
    home: Optional[Path] = None,
) -> Path:
    for path, loc in _agent_dirs(project_path=project_path, home=home):
        if loc == location:
            return path
    raise ValueError(f"Unsupported agent location: {location}")


def _split_frontmatter(raw_text: str) -> Tuple[Dict[str, Any], str]:
    """Extract YAML frontmatter and body content."""
    lines = raw_text.splitlines()
    if len(lines) >= 3 and lines[0].strip() == "---":
        for idx in range(1, len(lines)):
            if lines[idx].strip() == "---":
                frontmatter_text = "\n".join(lines[1:idx])
                body = "\n".join(lines[idx + 1 :])
                try:
                    frontmatter = yaml.safe_load(frontmatter_text) or {}
                except (
                    yaml.YAMLError,
                    ValueError,
                    TypeError,
                ) as exc:  # pragma: no cover - defensive
                    logger.warning(
                        "Invalid frontmatter in agent file: %s: %s",
                        type(exc).__name__,
                        exc,
                        extra={"error": str(exc)},
                    )
                    return {"__error__": f"Invalid frontmatter: {exc}"}, body
                return frontmatter, body
    return {}, raw_text


def _normalize_tools(value: object) -> List[str]:
    if value is None:
        return ["*"]
    if isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()] or ["*"]
    if isinstance(value, Iterable):
        tools: List[str] = []
        for item in value:
            if isinstance(item, str) and item.strip():
                tools.append(item.strip())
        return tools or ["*"]
    return ["*"]


def _convert_stop_hook_to_subagent(hooks_data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert Stop hooks to SubagentStop for subagent-scoped hooks."""
    if "Stop" not in hooks_data:
        return hooks_data
    converted = dict(hooks_data)
    stop_matchers = converted.pop("Stop")
    existing = converted.get("SubagentStop")
    if existing is None:
        converted["SubagentStop"] = stop_matchers
    elif isinstance(existing, list) and isinstance(stop_matchers, list):
        converted["SubagentStop"] = existing + stop_matchers
    elif isinstance(stop_matchers, list):
        converted["SubagentStop"] = stop_matchers
    return converted


def _normalize_agent_hooks(raw_hooks: object) -> object:
    if not isinstance(raw_hooks, dict):
        return raw_hooks
    if "hooks" in raw_hooks and isinstance(raw_hooks.get("hooks"), dict):
        wrapped = dict(raw_hooks)
        wrapped["hooks"] = _convert_stop_hook_to_subagent(wrapped["hooks"])
        return wrapped
    return _convert_stop_hook_to_subagent(raw_hooks)


def _parse_agent_file(
    path: Path,
    location: AgentLocation,
    *,
    namespace_prefix: Optional[str] = None,
    plugin_name: Optional[str] = None,
) -> Tuple[Optional[AgentDefinition], Optional[str]]:
    """Parse a single agent file."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, IOError, UnicodeDecodeError) as exc:
        logger.warning(
            "Failed to read agent file: %s: %s",
            type(exc).__name__,
            exc,
            extra={"error": str(exc), "path": str(path)},
        )
        return None, f"Failed to read agent file {path}: {exc}"

    frontmatter, body = _split_frontmatter(text)
    error = frontmatter.get("__error__")
    if error is not None:
        return None, str(error)

    agent_name = frontmatter.get("name")
    description = frontmatter.get("description")
    resolved_agent_name = (
        agent_name.strip() if isinstance(agent_name, str) and agent_name.strip() else path.stem
    )
    if not resolved_agent_name:
        return None, 'Missing required "name" field in frontmatter'
    if not isinstance(description, str) or not description.strip():
        return None, 'Missing required "description" field in frontmatter'
    full_agent_name = (
        f"{namespace_prefix}:{resolved_agent_name}" if namespace_prefix else resolved_agent_name
    )

    tools = _normalize_tools(frontmatter.get("tools"))
    model_value = frontmatter.get("model")
    color_value = frontmatter.get("color")
    model = model_value if isinstance(model_value, str) else None
    color = color_value if isinstance(color_value, str) else None
    fork_context = parse_boolish(frontmatter.get("fork_context") or frontmatter.get("fork-context"))
    hooks = parse_hooks_config(
        _normalize_agent_hooks(frontmatter.get("hooks")), source=f"agent:{full_agent_name}"
    )

    agent = AgentDefinition(
        agent_type=full_agent_name,
        when_to_use=description.replace("\\n", "\n").strip(),
        tools=tools,
        system_prompt=body.strip(),
        location=location,
        model=model,
        color=color,
        filename=path.stem,
        fork_context=fork_context,
        hooks=hooks,
        plugin_name=plugin_name,
    )
    return agent, None


def _load_agent_dir(
    path: Path,
    location: AgentLocation,
    *,
    namespace_prefix: Optional[str] = None,
    plugin_name: Optional[str] = None,
) -> Tuple[List[AgentDefinition], List[Tuple[Path, str]]]:
    agents: List[AgentDefinition] = []
    errors: List[Tuple[Path, str]] = []
    if not path.exists():
        return agents, errors

    for file_path in sorted(path.glob("*.md")):
        agent, error = _parse_agent_file(
            file_path,
            location,
            namespace_prefix=namespace_prefix,
            plugin_name=plugin_name,
        )
        if agent:
            agents.append(agent)
        elif error:
            errors.append((file_path, error))
    return agents, errors


def _load_agent_path(
    path: Path,
    location: AgentLocation,
    *,
    namespace_prefix: Optional[str] = None,
    plugin_name: Optional[str] = None,
) -> Tuple[List[AgentDefinition], List[Tuple[Path, str]]]:
    if path.is_file():
        if path.suffix.lower() != ".md":
            return [], []
        parsed, error = _parse_agent_file(
            path,
            location,
            namespace_prefix=namespace_prefix,
            plugin_name=plugin_name,
        )
        if parsed:
            return [parsed], []
        if error:
            return [], [(path, error)]
        return [], []
    if path.is_dir():
        return _load_agent_dir(
            path,
            location,
            namespace_prefix=namespace_prefix,
            plugin_name=plugin_name,
        )
    return [], []


def load_agent_definitions(
    project_path: Optional[Path] = None, home: Optional[Path] = None
) -> AgentLoadResult:
    """Load built-in, user, and project agents."""
    built_ins = _built_in_agents()
    collected_agents = list(built_ins)
    errors: List[Tuple[Path, str]] = []

    for directory, location in _agent_dirs(project_path=project_path, home=home):
        loaded, dir_errors = _load_agent_dir(directory, location)
        collected_agents.extend(loaded)
        errors.extend(dir_errors)

    plugin_result = discover_plugins(project_path=project_path, home=home)
    for plugin_error in plugin_result.errors:
        errors.append((plugin_error.path, plugin_error.reason))
    for plugin in plugin_result.plugins:
        for agent_path in plugin.agents_paths:
            loaded, dir_errors = _load_agent_path(
                agent_path,
                AgentLocation.PLUGIN,
                namespace_prefix=plugin.name,
                plugin_name=plugin.name,
            )
            collected_agents.extend(loaded)
            errors.extend(dir_errors)

    agent_map: Dict[str, AgentDefinition] = {}
    for agent in collected_agents:
        agent_map[agent.agent_type] = agent

    active_agents = list(agent_map.values())
    return AgentLoadResult(
        active_agents=active_agents,
        all_agents=collected_agents,
        failed_files=errors,
    )


def clear_agent_cache() -> None:
    """Reset cached agent definitions."""
    # No-op. Agent loading is intentionally uncached so plugin updates are visible immediately.
    return


def summarize_agent(agent: AgentDefinition) -> str:
    """Short human-readable summary."""
    tool_label = "all tools" if "*" in agent.tools else ", ".join(agent.tools)
    location = getattr(agent.location, "value", agent.location)
    details = [f"tools: {tool_label}"]
    if agent.fork_context:
        details.append("context: forked")
    if agent.model:
        details.append(f"model: {agent.model}")
    return f"- {agent.agent_type} ({location}): {agent.when_to_use} [{'; '.join(details)}]"


def resolve_agent_tools(
    agent: AgentDefinition, available_tools: Iterable[object], task_tool_name: str
) -> Tuple[List[object], List[str]]:
    """Map tool names from an agent to Tool instances, filtering out the task tool itself."""
    tool_map: Dict[str, object] = {}
    ordered_tools: List[object] = []
    for tool in available_tools:
        name = getattr(tool, "name", None)
        if not name:
            continue
        if name == task_tool_name:
            continue
        tool_map[name] = tool
        ordered_tools.append(tool)

    if "*" in agent.tools:
        return ordered_tools, []

    resolved: List[object] = []
    missing: List[str] = []
    seen = set()
    for tool_name in agent.tools:
        if tool_name in seen:
            continue
        seen.add(tool_name)
        tool = tool_map.get(tool_name)
        if tool:
            resolved.append(tool)
        else:
            missing.append(tool_name)
    return resolved, missing


def save_agent_definition(
    agent_type: str,
    description: str,
    tools: List[str],
    system_prompt: str,
    location: AgentLocation = AgentLocation.USER,
    model: Optional[str] = None,
    color: Optional[str] = None,
    overwrite: bool = False,
) -> Path:
    """Persist an agent markdown file."""
    agent_dir = _agent_dir_for_location(location)
    agent_dir.mkdir(parents=True, exist_ok=True)
    target_path = agent_dir / f"{agent_type}.md"
    if target_path.exists() and not overwrite:
        raise FileExistsError(f"Agent file already exists: {target_path}")

    escaped_description = description.replace("\n", "\\n")
    lines = [
        "---",
        f"name: {agent_type}",
        f"description: {escaped_description}",
    ]

    if not (len(tools) == 1 and tools[0] == "*"):
        joined_tools = ", ".join(tools)
        lines.append(f"tools: {joined_tools}")
    if model:
        lines.append(f"model: {model}")
    if color:
        lines.append(f"color: {color}")
    lines.append("---")
    lines.append("")
    lines.append(system_prompt.strip())
    target_path.write_text("\n".join(lines), encoding="utf-8")
    clear_agent_cache()
    return target_path


def delete_agent_definition(agent_type: str, location: AgentLocation = AgentLocation.USER) -> Path:
    """Delete an agent markdown file."""
    agent_dir = _agent_dir_for_location(location)
    target_path = agent_dir / f"{agent_type}.md"
    if target_path.exists():
        target_path.unlink()
        clear_agent_cache()
        return target_path
    raise FileNotFoundError(f"Agent file not found: {target_path}")
