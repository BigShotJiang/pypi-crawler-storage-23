"""Packaged data assets for ripperdoc."""

