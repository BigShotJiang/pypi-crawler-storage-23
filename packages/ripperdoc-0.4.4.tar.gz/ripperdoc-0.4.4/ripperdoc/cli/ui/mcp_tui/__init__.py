"""Textual MCP UI entrypoint."""

from .textual_app import run_mcp_tui

__all__ = ["run_mcp_tui"]
