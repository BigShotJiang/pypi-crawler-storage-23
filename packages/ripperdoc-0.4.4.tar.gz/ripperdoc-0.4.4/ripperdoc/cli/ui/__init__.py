"""UI components for the Ripperdoc CLI."""
