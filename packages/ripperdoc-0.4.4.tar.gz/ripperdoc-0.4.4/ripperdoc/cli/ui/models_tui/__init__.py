"""Textual-based models TUI."""

from .textual_app import run_models_tui

__all__ = ["run_models_tui"]
