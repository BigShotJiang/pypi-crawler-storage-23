from .textual_app import run_permissions_tui

__all__ = ["run_permissions_tui"]
