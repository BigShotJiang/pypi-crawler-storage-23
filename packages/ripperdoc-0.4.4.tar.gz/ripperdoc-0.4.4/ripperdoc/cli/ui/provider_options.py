"""
Provider metadata used by interactive UI flows.

Each provider option represents exactly one protocol endpoint. Vendors that
offer multiple protocols (for example, DeepSeek exposing both OpenAI-style and
Anthropic-style APIs on different URLs) should be modeled as distinct provider
options so that protocol-specific defaults stay unambiguous.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple
from urllib.parse import urlparse

from ripperdoc.core.config import ModelProfile, ProtocolType
from ripperdoc.core.provider_metadata import Provider


def _derive_website(key: str, base_url: Optional[str]) -> str:
    """Best-effort provider website from base_url or provider key."""
    if base_url:
        parsed = urlparse(base_url)
        if parsed.scheme and parsed.netloc:
            return f"{parsed.scheme}://{parsed.netloc}"
    return f"https://{key}"


@dataclass(frozen=True)
class ProviderOption:
    """Provider option keyed for onboarding selection."""

    key: str
    provider: Provider

    def __init__(
        self,
        key: str,
        provider: Optional[Provider] = None,
        *,
        protocol: Optional[ProtocolType] = None,
        default_model: str = "",
        model_suggestions: Tuple[str, ...] = (),
        default_api_base: Optional[str] = None,
        website: Optional[str] = None,
        description: Optional[str] = None,
    ) -> None:
        resolved_provider = provider
        if resolved_provider is None:
            resolved_protocol = protocol or ProtocolType.OPENAI_COMPATIBLE
            suggestion_list = tuple(model_suggestions) if model_suggestions else ()
            fallback_model = default_model or default_model_for_protocol(resolved_protocol)
            if not suggestion_list:
                suggestion_list = (fallback_model,)
            elif fallback_model and suggestion_list[0] != fallback_model:
                suggestion_list = (fallback_model, *tuple(m for m in suggestion_list if m != fallback_model))

            resolved_provider = Provider(
                protocol=resolved_protocol,
                website=website or _derive_website(key, default_api_base),
                description=description or f"{key} provider",
                base_url=default_api_base,
                model_list=tuple(
                    ModelProfile(protocol=resolved_protocol, model=model_name)
                    for model_name in suggestion_list
                ),
            )
        object.__setattr__(self, "key", key)
        object.__setattr__(self, "provider", resolved_provider)

    @property
    def label(self) -> str:
        """Display label shown to the user."""
        return self.key

    @property
    def protocol(self) -> ProtocolType:
        return self.provider.protocol

    @property
    def default_model(self) -> str:
        if self.provider.model_list:
            return self.provider.model_list[0].model
        return default_model_for_protocol(self.provider.protocol)

    @property
    def model_suggestions(self) -> Tuple[str, ...]:
        return tuple(profile.model for profile in self.provider.model_list)

    @property
    def default_api_base(self) -> Optional[str]:
        return self.provider.base_url

    def with_api_base(self, api_base: Optional[str]) -> "ProviderOption":
        """Return a copy that overrides the default API base."""
        provider = Provider(
            protocol=self.provider.protocol,
            website=self.provider.website,
            description=self.provider.description,
            base_url=api_base if api_base else self.provider.base_url,
            model_list=self.provider.model_list,
        )
        return ProviderOption(
            key=self.key,
            provider=provider,
        )


class ProviderRegistry:
    """Registry for known providers to keep wizard logic declarative."""

    def __init__(self, providers: Sequence[ProviderOption], default_key: str) -> None:
        if not providers:
            raise ValueError("Provider registry cannot be empty")
        self._providers: List[ProviderOption] = list(providers)
        self._index: Dict[str, ProviderOption] = {p.key: p for p in providers}
        if default_key not in self._index:
            raise ValueError(f"Default provider '{default_key}' not found in registry")
        self._default_key = default_key

    @property
    def providers(self) -> List[ProviderOption]:
        """Return providers in display order."""
        return list(self._providers)

    @property
    def default_choice(self) -> ProviderOption:
        """Return the default provider selection."""
        return self._index[self._default_key]

    def get(self, key: str) -> Optional[ProviderOption]:
        """Look up a provider option by key."""
        return self._index.get(key)

    def keys(self) -> List[str]:
        """Return provider keys in display order."""
        return [p.key for p in self._providers]


def default_model_for_protocol(protocol: ProtocolType) -> str:
    """Reasonable default model per protocol family."""
    if protocol == ProtocolType.ANTHROPIC:
        return "claude-3-5-sonnet-20241022"
    if protocol == ProtocolType.GEMINI:
        return "gemini-1.5-pro"
    return "gpt-4o-mini"


KNOWN_PROVIDERS = ProviderRegistry(
    providers=[
        # === Major Cloud Providers ===
        ProviderOption(
            key="openai",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="gpt-4o-mini",
            model_suggestions=(
                "gpt-4o",
                "gpt-4o-mini",
                "gpt-4-turbo",
                "o1-preview",
                "o1-mini",
            ),
            default_api_base="https://api.openai.com/v1",
        ),
        ProviderOption(
            key="anthropic",
            protocol=ProtocolType.ANTHROPIC,
            default_model="claude-3-5-sonnet-20241022",
            model_suggestions=(
                "claude-3-5-sonnet-20241022",
                "claude-3-5-haiku-20241022",
                "claude-3-opus-20240229",
            ),
            default_api_base=None,
        ),
        ProviderOption(
            key="google",
            protocol=ProtocolType.GEMINI,
            default_model="gemini-1.5-pro",
            model_suggestions=(
                "gemini-2.0-flash-exp",
                "gemini-1.5-pro",
                "gemini-1.5-flash",
            ),
            default_api_base="https://generativelanguage.googleapis.com/v1beta",
        ),
        # === Aggregators & Open Router ===
        ProviderOption(
            key="openrouter",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="openai/gpt-4o-mini",
            model_suggestions=(
                "openai/gpt-4o-mini",
                "anthropic/claude-3.5-sonnet",
                "google/gemini-flash-1.5",
                "meta-llama/llama-3.1-70b-instruct",
            ),
            default_api_base="https://openrouter.ai/api/v1",
        ),
        ProviderOption(
            key="poe",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="gpt-4o",
            model_suggestions=(
                "gpt-4o",
                "claude-3.5-sonnet",
                "gemini-1.5-pro",
                "mistral-large",
            ),
            default_api_base="https://api.poe.com/v1",
        ),
        # === Chinese Providers ===
        ProviderOption(
            key="deepseek",
            protocol=ProtocolType.ANTHROPIC,
            default_model="deepseek-chat",
            model_suggestions=(
                "deepseek-chat",
                "deepseek-reasoner",
            ),
            default_api_base="https://api.deepseek.com/v1",
        ),
        ProviderOption(
            key="zhipu",
            protocol=ProtocolType.ANTHROPIC,
            default_model="glm-5",
            model_suggestions=(
                "glm-5",
                "glm-4-plus",
                "glm-4.7",
                "glm-4.6",
                "glm-4.5",
                "glm-4.5-air",
                "glm-4-air",
                "glm-4-flash",
            ),
            default_api_base="https://open.bigmodel.cn/api/anthropic",
        ),
        ProviderOption(
            key="moonshot",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="kimi-k2.5",
            model_suggestions=(
                "kimi-k2.5",
                "kimi-k2-0905-preview",
                "kimi-k2-0711-preview",
                "kimi-k2-turbo-preview",
                "kimi-k2-thinking",
                "kimi-k2-thinking-turbo",
            ),
            default_api_base="https://api.moonshot.cn/v1",
        ),
        ProviderOption(
            key="volcengine",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="doubao-pro-32k",
            model_suggestions=(
                # Doubao Pro series
                "doubao-pro-32k",
                "doubao-pro-256k",
                "doubao-pro-32k-functioncall-241028",
                "doubao-pro-32k-character-241215",
                # Doubao 1.5 series
                "Doubao-1.5-pro",
                "doubao-1.5-pro-32k",
                "doubao-1.5-pro-32k-character",
                "Doubao-1.5-pro-256k",
                "Doubao-1.5-vision-pro",
                "doubao-1.5-vision-pro",
                "Doubao-1.5-lite-32k",
                # Doubao Lite series
                "Doubao-lite-32k",
                "Doubao-lite-128k",
                "Doubao-lite-4k-character-240828",
                "Doubao-lite-32k-character-241015",
                # DeepSeek series
                "DeepSeek-V3",
                "DeepSeek-R1",
                "DeepSeek-R1-Distill-Qwen-32B",
                "DeepSeek-R1-Distill-Qwen-7B",
                # Vision series
                "Doubao-vision-lite-32k",
            ),
            default_api_base="https://ark.cn-beijing.volces.com/api/v3",
        ),
        ProviderOption(
            key="aliyun",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="qwen-plus",
            model_suggestions=(
                "qwen-plus",
                "qwen-turbo",
                "qwen-max",
                "qwen-coder-plus",
            ),
            default_api_base="https://dashscope.aliyuncs.com/compatible-mode/v1",
        ),
        ProviderOption(
            key="minimax",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="MiniMax-M2.5",
            model_suggestions=(
                # M2 series
                "MiniMax-M2.5",
                "MiniMax-M2.1",
                "MiniMax-M2.1-lightning",
                "MiniMax-M2",
                # 01 series
                "minimax-01",
                # abab series
                "abab6.5g",
                "abab6.5s",
                "abab6.5t",
                "abab6",
                "abab5.5s",
                "abab5",
            ),
            default_api_base="https://api.minimax.chat/v1",
        ),
        ProviderOption(
            key="z.ai",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="glm-5",
            model_suggestions=(
                "glm-5",
                "glm-4-plus",
                "glm-4.6",
                "glm-4.5-air",
                "glm-4-flash",
            ),
            default_api_base="https://api.z.ai/api/paas/v4",
        ),
        # === Western AI Companies ===
        ProviderOption(
            key="mistralai",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="mistral-large-latest",
            model_suggestions=(
                # Mistral Chat series
                "mistral-large-latest",
                "mistral-small-latest",
                "mistral-nemo",
                "mistral-mini",
                # Free models
                "mistral-7b",
                "mistral-8b",
                # Mistral Code series
                "codestral-latest",
                # Multimodal
                "pixtral-large-latest",
            ),
            default_api_base="https://api.mistral.ai/v1",
        ),
        ProviderOption(
            key="groq",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="llama-3.3-70b-versatile",
            model_suggestions=(
                # Llama series
                "llama-3.3-70b-versatile",
                "llama-3.1-8b-instant",
                "llama3-70b-8192",
                "llama3-8b-8192",
                # Gemma series
                "gemma2-9b-it",
                "gemma-7b-it",
                # Mistral series
                "mistral-saba-24b",
                "mixtral-8x7b-32768",
            ),
            default_api_base="https://api.groq.com/openai/v1",
        ),
        ProviderOption(
            key="grok",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="grok-3",
            model_suggestions=(
                "grok-4",
                "grok-3",
                "grok-3-fast",
                "grok-3-mini",
                "grok-3-mini-fast",
            ),
            default_api_base="https://api.x.ai/v1",
        ),
        ProviderOption(
            key="cohere",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="command-r-plus-08-2024",
            model_suggestions=(
                "command-r-plus-08-2024",
                "command-r-08-2024",
                "command-r7b-12-2024",
            ),
            default_api_base="https://api.cohere.ai/v1",
        ),
        ProviderOption(
            key="together",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
            model_suggestions=(
                "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
                "Qwen/Qwen2.5-72B-Instruct-Turbo",
                "mistralai/Mixtral-8x7B-Instruct-v0.1",
            ),
            default_api_base="https://api.together.xyz/v1",
        ),
        ProviderOption(
            key="perplexity",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="llama-3.1-sonar-small-128k-online",
            model_suggestions=(
                "llama-3.1-sonar-small-128k-online",
                "llama-3.1-sonar-large-128k-online",
            ),
            default_api_base="https://api.perplexity.ai",
        ),
        ProviderOption(
            key="siliconflow",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="Qwen/Qwen2.5-72B-Instruct",
            model_suggestions=(
                "Qwen/Qwen2.5-72B-Instruct",
                "deepseek-ai/DeepSeek-V3",
                "01-ai/Yi-1.5-34B-Chat",
            ),
            default_api_base="https://api.siliconflow.cn/v1",
        ),
        # === Generic / Custom ===
        ProviderOption(
            key="openai_compatible",
            protocol=ProtocolType.OPENAI_COMPATIBLE,
            default_model="gpt-4o-mini",
            model_suggestions=(
                "gpt-4o-mini",
                "gpt-4o",
                "llama-3.1-70b",
            ),
            default_api_base=None,
        ),
        ProviderOption(
            key="anthropic_compatible",
            protocol=ProtocolType.ANTHROPIC,
            default_model="claude-3-5-sonnet-20241022",
            model_suggestions=(
                "claude-3-5-sonnet-20241022",
                "claude-3-5-haiku-20241022",
            ),
            default_api_base=None,
        ),
    ],
    default_key="deepseek",
)


__all__ = [
    "KNOWN_PROVIDERS",
    "Provider",
    "ProviderOption",
    "ProviderRegistry",
    "default_model_for_protocol",
]
