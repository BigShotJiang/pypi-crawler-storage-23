from .textual_app import run_hooks_tui

__all__ = ["run_hooks_tui"]
