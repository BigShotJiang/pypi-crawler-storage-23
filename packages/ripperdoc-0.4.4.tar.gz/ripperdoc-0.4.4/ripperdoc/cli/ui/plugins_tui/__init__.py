"""Textual plugins UI entrypoint."""

from .textual_app import run_plugins_tui

__all__ = ["run_plugins_tui"]
