"""CLI interface for Ripperdoc."""
