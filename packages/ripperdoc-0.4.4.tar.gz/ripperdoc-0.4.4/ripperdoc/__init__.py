"""Ripperdoc - AI-powered coding agent."""

__version__ = "0.4.4"
