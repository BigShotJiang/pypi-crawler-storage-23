"""Tests for analyst template."""
