

::: inline_snapshot.get_snapshot_value
    options:
      heading_level: 1
      show_root_heading: true
      show_root_full_path: false
      show_source: false
      annotations_path: brief
