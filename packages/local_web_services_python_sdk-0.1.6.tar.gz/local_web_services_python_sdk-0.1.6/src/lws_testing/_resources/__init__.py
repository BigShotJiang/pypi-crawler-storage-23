"""Resource helpers for seeding and asserting AWS service state."""
