# coding=utf-8
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_core.store.execution import BaseExecutionStore


@dataclass
class _ConversationState:
    conversation_id: str
    trace_id: str
    status: str = "created"
    input_data: Optional[Dict[str, Any]] = None
    error: Optional[Any] = None
    usage: Optional[Any] = None


@dataclass
class _MessageState:
    message_id: str
    trace_id: str
    run_id: str
    executor_id: Optional[str]
    role: str
    mode: str
    json_schema: Optional[Dict[str, Any]]
    content: str = ""
    finished_text: Optional[str] = None


@dataclass
class _ActionState:
    action_record_id: str
    action_id: str
    trace_id: str
    run_id: str
    message_id: str
    index: int
    name: str
    is_client: bool
    intent: Optional[str]

    # 增量字段（先用字符串累积，后续可接入 JSONAssembler）
    thought: str = ""
    args_delta: str = ""

    full_arguments: Dict[str, Any] = field(default_factory=dict)

    result_status: Optional[str] = None
    result_title: str = ""
    result_summary: str = ""
    result_output: str = ""
    result_error: str = ""
    full_result: Any = None
    images: Optional[list[str]] = None
    files: Optional[list[str]] = None


class InMemoryExecutionStore(BaseExecutionStore):
    """内存 ExecutionStore（用于单测/调试/降级）。

    说明：
    - 不做持久化
    - 只保证接口可用与最小幂等（以 id 做覆盖/更新）
    """

    def __init__(self):
        self.conversations: Dict[str, _ConversationState] = {}
        self.messages: Dict[str, _MessageState] = {}
        self.actions: Dict[str, _ActionState] = {}

    async def connect(self) -> None:
        return

    async def disconnect(self) -> None:
        return

    async def upsert_conversation_from_run_created(self, event: BaseEvent) -> str:
        input_data = getattr(getattr(event, "payload", None), "input_data", None)
        conversation_id = None
        if isinstance(input_data, dict):
            conversation_id = input_data.get("conversation_id")

        if not conversation_id:
            conversation_id = event.trace_id

        state = self.conversations.get(conversation_id)
        if state is None:
            state = _ConversationState(conversation_id=conversation_id, trace_id=event.trace_id)
            self.conversations[conversation_id] = state

        state.status = "created"
        if isinstance(input_data, dict):
            state.input_data = input_data

        return conversation_id

    async def update_conversation_from_run_lifecycle(self, event: BaseEvent) -> None:
        # 尽量复用 created 的 upsert 逻辑，保证 conversation 一定存在
        conversation_id = await self.upsert_conversation_from_run_created(event)
        state = self.conversations[conversation_id]
        event_type = str(getattr(event, "type", ""))
        if event_type.startswith("run.lifecycle."):
            state.status = event_type.split(".")[-1]
        else:
            state.status = event_type or "unknown"

        payload = getattr(event, "payload", None)
        state.error = getattr(payload, "error", None)
        state.usage = getattr(payload, "usage", None)

    async def upsert_text_message_start(
        self,
        *,
        trace_id: str,
        run_id: str,
        executor_id: Optional[str],
        role: str,
        mode: str,
        json_schema: Optional[Dict[str, Any]],
    ) -> str:
        message_id = trace_id
        st = self.messages.get(message_id)
        if st is None:
            st = _MessageState(
                message_id=message_id,
                trace_id=trace_id,
                run_id=run_id,
                executor_id=executor_id,
                role=role,
                mode=mode,
                json_schema=json_schema,
            )
            self.messages[message_id] = st
        else:
            st.role = role
            st.mode = mode
            st.json_schema = json_schema
        return message_id

    async def append_text_message_delta(
        self,
        *,
        message_id: str,
        delta: str,
        key_path: Optional[list[Any]] = None,
    ) -> None:
        st = self.messages.get(message_id)
        if st is None:
            logger.warning("追加文本 delta 失败：message_id 不存在：{}", message_id)
            return
        st.content += delta

    async def finish_text_message(self, *, message_id: str, full_text: str) -> None:
        st = self.messages.get(message_id)
        if st is None:
            logger.warning("完成文本消息失败：message_id 不存在：{}", message_id)
            return
        st.finished_text = full_text
        st.content = full_text

    async def upsert_action_start(
        self,
        *,
        trace_id: str,
        run_id: str,
        message_id: str,
        action_id: str,
        index: int,
        name: str,
        is_client: bool,
        intent: Optional[str],
    ) -> str:
        action_record_id = action_id
        st = self.actions.get(action_record_id)
        if st is None:
            st = _ActionState(
                action_record_id=action_record_id,
                action_id=action_id,
                trace_id=trace_id,
                run_id=run_id,
                message_id=message_id,
                index=index,
                name=name,
                is_client=is_client,
                intent=intent,
            )
            self.actions[action_record_id] = st
        else:
            st.index = index
            st.name = name
            st.is_client = is_client
            st.intent = intent
        return action_record_id

    async def append_action_delta(
        self,
        *,
        action_record_id: str,
        part: str,
        delta: str,
        key_path: Optional[list[Any]] = None,
    ) -> None:
        st = self.actions.get(action_record_id)
        if st is None:
            logger.warning("追加 action delta 失败：action_record_id 不存在：{}", action_record_id)
            return

        if part == "intent":
            st.intent = (st.intent or "") + delta
        elif part == "thought":
            st.thought += delta
        elif part == "args":
            st.args_delta += delta

    async def finish_action(self, *, action_record_id: str, full_arguments: Dict[str, Any]) -> None:
        st = self.actions.get(action_record_id)
        if st is None:
            logger.warning("完成 action 失败：action_record_id 不存在：{}", action_record_id)
            return
        st.full_arguments = full_arguments

    async def start_action_result(self, *, action_record_id: str, status: str) -> None:
        st = self.actions.get(action_record_id)
        if st is None:
            logger.warning("开始 action result 失败：action_record_id 不存在：{}", action_record_id)
            return
        st.result_status = status

    async def append_action_result_delta(
        self,
        *,
        action_record_id: str,
        part: str,
        delta: str,
        key_path: Optional[list[Any]] = None,
    ) -> None:
        st = self.actions.get(action_record_id)
        if st is None:
            logger.warning("追加 action result delta 失败：action_record_id 不存在：{}", action_record_id)
            return

        if part == "title":
            st.result_title += delta
        elif part == "summary":
            st.result_summary += delta
        elif part == "output":
            st.result_output += delta
        elif part == "error":
            st.result_error += delta

    async def finish_action_result(
        self,
        *,
        action_record_id: str,
        status: str,
        full_result: Any,
        images: Optional[list[str]] = None,
        files: Optional[list[str]] = None,
    ) -> None:
        st = self.actions.get(action_record_id)
        if st is None:
            logger.warning("完成 action result 失败：action_record_id 不存在：{}", action_record_id)
            return
        st.result_status = status
        st.full_result = full_result
        st.images = images
        st.files = files
