# coding=utf-8
from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Optional

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_core.store.broker import BaseEventBroker


@dataclass
class _QueueMessage:
    stream: str
    event_json: str


class MemoryQueueEventBroker(BaseEventBroker):
    """内存事件队列（降级用）。

    说明：
    - 只用于本地/边缘场景的短期缓冲与调试。
    - 不提供消费者组/XACK 语义。
    """

    def __init__(self, maxsize: int = 10_000):
        self._queue: asyncio.Queue[_QueueMessage] = asyncio.Queue(maxsize=maxsize)

    async def publish(self, stream: str, event: BaseEvent) -> Optional[str]:
        try:
            payload = json.dumps(event.model_dump(mode="json"), ensure_ascii=False)
            self._queue.put_nowait(_QueueMessage(stream=stream, event_json=payload))
            return None
        except asyncio.QueueFull:
            logger.warning("MemoryQueueEventBroker 队列已满，丢弃事件：type={}, trace_id={}", event.type, event.trace_id)
            return None

    async def healthcheck(self) -> bool:
        return True

    async def pop(self, timeout_s: float = 0.1) -> Optional[_QueueMessage]:
        """调试用：弹出一条消息。"""
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=timeout_s)
        except asyncio.TimeoutError:
            return None
