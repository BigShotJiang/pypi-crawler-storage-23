import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic_settings import BaseSettings
from pytz import timezone

# Load .env file with deterministic precedence:
# 1) backend/.env
# 2) backend/packages/turbo-agent-store/.env
# 3) current working directory .env
_current_dir = Path(__file__).resolve().parent
_backend_env_path = _current_dir.parent.parent.parent.parent / ".env"
_package_env_path = _current_dir.parent.parent / ".env"
_cwd_env_path = Path(os.getcwd()) / ".env"

if _backend_env_path.exists():
    load_dotenv(dotenv_path=_backend_env_path)
elif _package_env_path.exists():
    load_dotenv(dotenv_path=_package_env_path)
elif _cwd_env_path.exists():
    load_dotenv(dotenv_path=_cwd_env_path)
else:
    load_dotenv()
    

class Settings(BaseSettings):
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    REDIS_CACHE_URL: str = os.getenv("REDIS_CACHE_URL", "redis://localhost:6379/1")
    REDIS_RESULT_URL: str = os.getenv("REDIS_RESULT_URL", "redis://localhost:6379/2")
    DATABASE_URL: str
    MEILISEARCH_URL: str
    MEILISEARCH_API_KEY: str
    MEILISEARCH_EMBEDDER_SERVER: str
    DOCLING_SERVER: str
    DOCLING_API_KEY: str
    
    # Manticore Search 配置
    MANTICORE_HOST: str = "http://127.0.0.1:9308"
    MANTICORE_API_KEY: str = ""

    # 索引名称 (支持 Meilisearch 和 Manticore)
    # 行为记录索引名称, 用于存储工具调用的行为记录
    MEILISEARCH_ACTION_RECORDS_INDEX: str = "turboagent-action-records"
    MANTICORE_ACTION_INDEX: str = "turboagent_action_records"
    # RAG 知识库索引名称
    MEILISEARCH_KNOWLEDGE_INDEX: str = "turboagent-knowledges"
    MANTICORE_KNOWLEDGE_INDEX: str = "turboagent_knowledge"
    # 工作集索引名称, 用于存储对话产生的上下文
    MEILISEARCH_WORKSET_INDEX: str = "turboagent-workset"
    MANTICORE_WORKSET_INDEX: str = "turboagent_workset"
    # 测试阶段可选：强制每次初始化前删除并重建索引
    MANTICORE_FORCE_RECREATE: bool = False
    # 调试：创建或获取索引时是否输出 DESCRIBE 结果 (DEBUG 级别)
    MANTICORE_LOG_DESCRIBE: bool = True
    # JSON 检查模型配置，用于验证 并修正 JSON 格式
    JSON_CHECK_MODEL: str
    JSON_CHECK_MODEL_API_KEY: str
    JSON_CHECK_MODEL_API_URL: str
    CHUNCK_MODEL: str
    CHUNCK_MODEL_API_KEY: str
    CHUNCK_MODEL_API_URL: str
    EMBEDDING_DIM: int = 1024  # 向量维度，默认1024，可在 .env 中配置，如 1536, 2048 等
    MINERU_URL: str
    MINERU_API_KEY: str 
    MINIO_URL:str
    MINIO_ACCESS_KEY: str
    MINIO_SECRET_KEY: str
    MINIO_PUBLIC_BUCKET: str = "qiyuan-agent-public"
    MINIO_PRIVATE_BUCKET: str = "qiyuan-agent"
    TIMEZONE: str = "Asia/Shanghai"
    TEMPLATE_MODEL: str = "Qwen/Qwen3-235B-A22B-Instruct-2507-tput"
    TEMPLATE_MODEL_API_KEY: str
    TEMPLATE_MODEL_API_URL: str ="http://120.53.87.17:8091/v1"

    class Config:
            env_file = ".env"

settings = Settings()
tz = timezone(settings.TIMEZONE)
