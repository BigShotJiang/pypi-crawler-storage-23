"""turbo-agent-store

存储模块的技术实现层，面向不同需求提供实现：

1. **Cache** - 内存缓存实现
   - 用途：运行时缓存、临时数据存储
   - 实现：InMemoryCacheStore, InMemoryExecutionStore

2. **Config** - 结构化数据导出
   - 用途：基于 core schema 的结构化导出
   - 实现：YAMLConfigStore

3. **Git** - 工作空间文件版本管理
   - 用途：Agent 工作空间文件的版本管理
   - 实现：GitFileStore, LocalGitWorkspaceStore

4. **Resource** - 知识资源文件管理
   - 用途：KnowledgeResource 文件存储、解析
   - 实现：KnowledgeResourceManager, AnalysisWorker

5. **Workspace** - 工作区文件管理
   - 用途：Workset/Workspace Git 操作
   - 实现：LocalGitWorkspaceStore

6. **Worker** - 执行环境管理
   - 用途：Worker 环境准备与清理
   - 实现：WorkerEnvironmentBuilder, WorkerEnvironment

7. **GitServer** - Git 服务器管理
   - 用途：本地 Git 服务器初始化与管理
   - 实现：GitServer, GitWorkspaceSync

注意：
- 纯抽象定义在 turbo_agent_core.store 中
- 持久化存储由 cloud 模块实现（MinIO, Prisma）
"""

from turbo_agent_core.store import (
    BaseFileStore,
    BaseExecutionStore,
    BaseCacheStore,
    BaseEventBroker,
    BaseAssembler,
    # 新增文件存储抽象
    ResourceStore,
    ResourceInfo,
    WorkspaceStore,
    FileInfo,
    CommitInfo,
    TagInfo,
)

# Data 存储能力
from .data.cache.cache import InMemoryCacheStore
from .data.cache.execution import InMemoryExecutionStore
from .data.cache.event_broker import MemoryQueueEventBroker

# Files 存储能力
from .files.git.file import GitFileStore
from .files.resource import (
    KnowledgeType,
    FileType,
    ResourceStatus,
    AnalysisStatus,
    AnalysisJob,
    ResourceMetadata,
    KnowledgeResourceUploadRequest,
    KnowledgeResourceManager,
    AnalysisWorker,
    process_knowledge_resource_analysis,
)
from .files.workspace import LocalGitWorkspaceStore

# Runtime 执行环境能力
from .runtime.worker import (
    WorkerEnvironment,
    WorkerEnvironmentBuilder,
    WorkerEnvironmentContext,
    ResourceRef,
    WorkspaceRef,
)
from .runtime.git_server import GitServer, GitServerConfig, GitWorkspaceSync

__all__ = [
    # 纯抽象 (from core)
    "BaseFileStore",
    "BaseExecutionStore",
    "BaseCacheStore",
    "BaseEventBroker",
    "BaseAssembler",
    # 新增抽象
    "ResourceStore",
    "ResourceInfo",
    "WorkspaceStore",
    "FileInfo",
    "CommitInfo",
    "TagInfo",
    # Cache 实现
    "InMemoryCacheStore",
    "InMemoryExecutionStore",
    "MemoryQueueEventBroker",
    # Git 实现（旧版）
    "GitFileStore",
    # Resource 知识资源管理
    "KnowledgeType",
    "FileType",
    "ResourceStatus",
    "AnalysisStatus",
    "AnalysisJob",
    "ResourceMetadata",
    "KnowledgeResourceUploadRequest",
    "KnowledgeResourceManager",
    "AnalysisWorker",
    "process_knowledge_resource_analysis",
    # Workspace
    "LocalGitWorkspaceStore",
    # Worker 环境管理
    "WorkerEnvironment",
    "WorkerEnvironmentBuilder",
    "WorkerEnvironmentContext",
    "ResourceRef",
    "WorkspaceRef",
    # Git 服务器管理
    "GitServer",
    "GitServerConfig",
    "GitWorkspaceSync",
]
