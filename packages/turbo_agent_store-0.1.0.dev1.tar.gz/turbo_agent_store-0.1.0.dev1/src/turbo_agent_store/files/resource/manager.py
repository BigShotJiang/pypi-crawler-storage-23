"""
知识资源管理器

负责知识资源的上传、元数据管理和解析任务下发。
"""

import hashlib
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
import mimetypes

from loguru import logger

from turbo_agent_core.schema.enums import ResourceStatus
from turbo_agent_core.store.resource import ResourceStore

from .models import (
    KnowledgeResourceUploadRequest,
    ResourceMetadata,
    AnalysisJob,
    AnalysisStatus,
)


class KnowledgeResourceManager:
    """
    知识资源管理器。
    
    职责：
    1. 接收上传请求，验证文件
    2. 上传文件到 MinIO，按规则生成路径
    3. 创建 metadata.json
    4. 下发解析任务（dramatiq）
    
    路径规则：
        {user_id}/{context_id}/{resource_id}/
        ├── original/{filename}     # 原文件
        ├── metadata.json           # 元数据
        └── analyze_cache/          # 解析结果
    """
    
    def __init__(
        self,
        resource_store: ResourceStore,
        analysis_queue,  # dramatiq queue
        docling_enabled: bool = True,
    ):
        self.store = resource_store
        self.analysis_queue = analysis_queue
        self.docling_enabled = docling_enabled
    
    async def upload(
        self,
        request: KnowledgeResourceUploadRequest,
    ) -> ResourceMetadata:
        """
        上传知识资源。
        
        流程：
        1. 验证请求
        2. 计算文件 MD5
        3. 上传文件到 MinIO
        4. 创建 metadata.json
        5. 下发解析任务
        
        Args:
            request: 上传请求
            
        Returns:
            ResourceMetadata: 资源元数据
        """
        # 1. 验证请求
        request.validate()
        local_path = Path(request.local_file_path)
        
        logger.info(f"开始上传知识资源: {request.resource_id}, 文件: {local_path}")
        
        # 2. 计算文件 MD5 和大小
        file_md5 = await self._calculate_md5(local_path)
        file_size = local_path.stat().st_size
        mime_type, _ = mimetypes.guess_type(str(local_path))
        
        # 3. 确定 context_id（绑定关系）
        # 优先级：workset_id > conversation_id > setting_id > org_project_id > "default"
        context_id = self._determine_context_id(request)
        
        # 4. 上传原文件（使用 core 接口）
        with open(local_path, "rb") as f:
            file_data = f.read()
        
        original_file_path = await self.store.upload_original(
            user_id=request.user_id,
            context_id=context_id,
            resource_id=request.resource_id,
            filename=request.filename,
            data=file_data,
            content_type=mime_type or "application/octet-stream",
        )
        logger.info(f"原文件已上传: {original_file_path}")
        
        # 5. 创建解析任务列表
        analysis_jobs: List[AnalysisJob] = []
        
        # Docling 解析（如果启用且配置）
        if request.enable_docling and self.docling_enabled:
            analysis_jobs.append(AnalysisJob(method="docling"))
        
        # Markdown 转换（备选方案）
        if request.enable_markdown:
            analysis_jobs.append(AnalysisJob(method="markdown"))
        
        # 6. 构建元数据
        metadata = ResourceMetadata(
            resource_id=request.resource_id,
            name=request.filename,
            filename=request.filename,
            type=request.knowledge_type,
            status=ResourceStatus.UPLOADED,
            fileType=request.file_type,
            uploaded_at=datetime.now(),
            uploaded_by=request.username,
            user_id=request.user_id,
            original_file_path=original_file_path,
            file_size=file_size,
            file_md5=file_md5,
            mime_type=mime_type,
            workset_id=request.workset_id,
            conversation_id=request.conversation_id,
            setting_id=request.setting_id,
            org_project_id=request.org_project_id,
            analysis_jobs=analysis_jobs,
        )
        
        # 7. 上传 metadata.json（作为 parsed 内容）
        metadata_bytes = json.dumps(metadata.to_dict(), ensure_ascii=False, indent=2).encode("utf-8")
        metadata_path = await self._upload_metadata(
            user_id=request.user_id,
            context_id=context_id,
            resource_id=request.resource_id,
            data=metadata_bytes,
        )
        logger.info(f"元数据已上传: {metadata_path}")
        
        # 8. 下发解析任务
        if analysis_jobs:
            await self._dispatch_analysis_tasks(metadata, context_id)
            metadata.status = ResourceStatus.HANDLING
            # 更新 metadata.json
            await self._update_metadata(metadata, context_id)
        else:
            metadata.status = ResourceStatus.READY
            await self._update_metadata(metadata, context_id)
        
        logger.info(f"知识资源上传完成: {request.resource_id}, 状态: {metadata.status.value}")
        return metadata
    
    async def get_metadata(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
    ) -> Optional[ResourceMetadata]:
        """获取资源元数据"""
        metadata_path = f"{user_id}/{context_id}/{resource_id}/metadata.json"
        try:
            data = await self.store.download(metadata_path)
            return ResourceMetadata.from_dict(json.loads(data.decode("utf-8")))
        except Exception as e:
            logger.warning(f"获取元数据失败: {resource_id}, {e}")
            return None
    
    async def update_analysis_status(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        method: str,
        status: AnalysisStatus,
        result_path: Optional[str] = None,
        result_md5: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> ResourceMetadata:
        """
        更新解析任务状态。
        
        由解析 worker 调用，更新任务状态并保存结果。
        """
        metadata = await self.get_metadata(user_id, context_id, resource_id)
        if not metadata:
            raise ValueError(f"资源不存在: {resource_id}")
        
        # 查找并更新对应任务
        for job in metadata.analysis_jobs:
            if job.method == method:
                job.status = status
                job.result_path = result_path
                job.result_md5 = result_md5
                job.error_message = error_message
                
                if status == AnalysisStatus.PROCESSING:
                    job.started_at = datetime.now()
                elif status in (AnalysisStatus.COMPLETED, AnalysisStatus.FAILED):
                    job.completed_at = datetime.now()
                break
        
        # 检查所有任务是否完成
        all_completed = all(
            job.status in (AnalysisStatus.COMPLETED, AnalysisStatus.FAILED)
            for job in metadata.analysis_jobs
        )
        any_failed = any(
            job.status == AnalysisStatus.FAILED
            for job in metadata.analysis_jobs
        )
        
        if all_completed:
            if any_failed:
                metadata.status = ResourceStatus.FAILED
            else:
                metadata.status = ResourceStatus.READY
        
        # 更新 metadata.json
        await self._update_metadata(metadata, context_id)
        logger.info(f"解析状态已更新: {resource_id}, method: {method}, status: {status.value}")
        
        return metadata
    
    def _determine_context_id(self, request: KnowledgeResourceUploadRequest) -> str:
        """确定 context_id（基于绑定关系）"""
        if request.workset_id:
            return f"workset_{request.workset_id}"
        elif request.conversation_id:
            return f"session_{request.conversation_id}"
        elif request.setting_id:
            return f"setting_{request.setting_id}"
        elif request.org_project_id:
            return f"project_{request.org_project_id}"
        else:
            return "default"
    
    async def _upload_metadata(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        data: bytes,
    ) -> str:
        """上传 metadata.json（使用通用上传方法）"""
        # 使用 upload_original 上传 metadata.json
        return await self.store.upload_original(
            user_id=user_id,
            context_id=context_id,
            resource_id=resource_id,
            filename="metadata.json",
            data=data,
            content_type="application/json",
        )
    
    async def _update_metadata(self, metadata: ResourceMetadata, context_id: str) -> None:
        """更新 metadata.json"""
        metadata_bytes = json.dumps(metadata.to_dict(), ensure_ascii=False, indent=2).encode("utf-8")
        # 删除旧的 metadata.json 然后重新上传
        metadata_path = f"{metadata.user_id}/{context_id}/{metadata.resource_id}/metadata.json"
        await self.store.delete_file(metadata_path)
        await self._upload_metadata(
            user_id=metadata.user_id,
            context_id=context_id,
            resource_id=metadata.resource_id,
            data=metadata_bytes,
        )
    
    async def _calculate_md5(self, file_path: Path) -> str:
        """计算文件 MD5"""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    
    async def _dispatch_analysis_tasks(
        self,
        metadata: ResourceMetadata,
        context_id: str,
    ) -> None:
        """下发解析任务"""
        for job in metadata.analysis_jobs:
            # 创建任务 payload
            task_payload = {
                "resource_id": metadata.resource_id,
                "user_id": metadata.user_id,
                "context_id": context_id,
                "method": job.method,
                "file_path": metadata.original_file_path,
                "file_type": metadata.fileType.value if metadata.fileType else None,
                "knowledge_type": metadata.type.value,
                "mime_type": metadata.mime_type,
            }
            
            # 发送到 dramatiq queue
            self.analysis_queue.send(task_payload)
            logger.info(f"解析任务已下发: {metadata.resource_id}, method: {job.method}")
