"""
LocalResourceStore - 本地文件系统实现的 ResourceStore

用于开发测试环境，生产环境使用 MinIO 实现。

路径结构:
    {base_path}/{user_id}/{context_id}/{resource_id}/
    ├── original/{filename}
    ├── parsed/
    └── chunks/

注意: 在 Worker 环境中，ResourceStore 是只读的。
"""

import os
import shutil
from pathlib import Path
from typing import Optional, AsyncIterator
from datetime import datetime

from turbo_agent_core.store.resource import ResourceStore, ResourceInfo


class LocalResourceStore(ResourceStore):
    """
    本地文件系统实现的 ResourceStore。
    
    Args:
        base_path: 基础存储路径
    """
    
    def __init__(self, base_path: str = "/tmp/turbo_agent/resources"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
    
    def _get_resource_dir(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> Path:
        """获取资源目录路径。"""
        return self.base_path / user_id / context_id / resource_id
    
    def _get_original_dir(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> Path:
        """获取原始文件目录路径。"""
        return self._get_resource_dir(user_id, context_id, resource_id) / "original"
    
    # ===== 写操作（通常由 Server 端调用）=====
    
    async def upload_original(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        filename: str,
        data: bytes,
        content_type: Optional[str] = None
    ) -> str:
        """
        上传原始文件。
        
        路径: {user_id}/{context_id}/{resource_id}/original/{filename}
        """
        # 安全检查：防止路径穿越
        if ".." in filename or filename.startswith("/"):
            raise ValueError(f"Invalid filename: {filename}")
        
        original_dir = self._get_original_dir(user_id, context_id, resource_id)
        original_dir.mkdir(parents=True, exist_ok=True)
        
        file_path = original_dir / filename
        file_path.write_bytes(data)
        
        # 保存元数据
        meta_path = original_dir / ".meta.json"
        import json
        meta = {
            "filename": filename,
            "content_type": content_type,
            "size": len(data),
            "uploaded_at": datetime.now().isoformat()
        }
        meta_path.write_text(json.dumps(meta))
        
        # 返回相对路径
        return f"{user_id}/{context_id}/{resource_id}/original/{filename}"
    
    async def save_parsed(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        data: bytes,
        format: str = "json"
    ) -> str:
        """保存解析后的内容。"""
        parsed_dir = self._get_resource_dir(user_id, context_id, resource_id) / "parsed"
        parsed_dir.mkdir(parents=True, exist_ok=True)
        
        filename = f"content.{format}"
        file_path = parsed_dir / filename
        file_path.write_bytes(data)
        
        return f"{user_id}/{context_id}/{resource_id}/parsed/{filename}"
    
    async def save_chunks(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        data: bytes
    ) -> str:
        """保存分块后的数据。"""
        chunks_dir = self._get_resource_dir(user_id, context_id, resource_id) / "chunks"
        chunks_dir.mkdir(parents=True, exist_ok=True)
        
        filename = "chunks.json"
        file_path = chunks_dir / filename
        file_path.write_bytes(data)
        
        return f"{user_id}/{context_id}/{resource_id}/chunks/{filename}"
    
    async def delete_resource(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> bool:
        """删除整个资源目录。"""
        resource_dir = self._get_resource_dir(user_id, context_id, resource_id)
        if resource_dir.exists():
            shutil.rmtree(resource_dir)
            return True
        return False
    
    async def delete_file(self, path: str) -> bool:
        """删除指定路径的文件。"""
        file_path = self.base_path / path
        # 安全检查
        if not str(file_path.resolve()).startswith(str(self.base_path.resolve())):
            raise ValueError(f"Invalid path: {path}")
        
        if file_path.exists() and file_path.is_file():
            file_path.unlink()
            return True
        return False
    
    # ===== 读操作（Worker 使用）=====
    
    async def download(self, path: str) -> bytes:
        """
        下载文件。
        
        Args:
            path: 相对路径 或 完整路径
        """
        # 如果 path 是绝对路径且包含 base_path，直接使用
        if path.startswith(str(self.base_path)):
            file_path = Path(path)
        else:
            file_path = self.base_path / path
        
        # 安全检查
        if not str(file_path.resolve()).startswith(str(self.base_path.resolve())):
            raise ValueError(f"Invalid path: {path}")
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        return file_path.read_bytes()
    
    async def download_stream(self, path: str, chunk_size: int = 8192) -> AsyncIterator[bytes]:
        """
        流式下载文件。
        
        Args:
            path: 相对路径
            chunk_size: 每次读取的字节数
        """
        file_path = self.base_path / path
        
        # 安全检查
        if not str(file_path.resolve()).startswith(str(self.base_path.resolve())):
            raise ValueError(f"Invalid path: {path}")
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        with open(file_path, 'rb') as f:
            while chunk := f.read(chunk_size):
                yield chunk
    
    async def exists(self, path: str) -> bool:
        """检查文件是否存在。"""
        file_path = self.base_path / path
        
        # 安全检查
        if not str(file_path.resolve()).startswith(str(self.base_path.resolve())):
            return False
        
        return file_path.exists()
    
    async def get_size(self, path: str) -> int:
        """获取文件大小。"""
        file_path = self.base_path / path
        
        # 安全检查
        if not str(file_path.resolve()).startswith(str(self.base_path.resolve())):
            raise ValueError(f"Invalid path: {path}")
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        return file_path.stat().st_size
    
    async def get_parsed(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        format: str = "json"
    ) -> Optional[bytes]:
        """获取解析后的内容。"""
        parsed_dir = self._get_resource_dir(user_id, context_id, resource_id) / "parsed"
        file_path = parsed_dir / f"content.{format}"
        
        if file_path.exists():
            return file_path.read_bytes()
        return None
    
    async def get_chunks(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> Optional[bytes]:
        """获取分块后的数据。"""
        chunks_dir = self._get_resource_dir(user_id, context_id, resource_id) / "chunks"
        file_path = chunks_dir / "chunks.json"
        
        if file_path.exists():
            return file_path.read_bytes()
        return None
    
    # ===== 辅助方法 =====
    
    async def get_resource_info(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> Optional[ResourceInfo]:
        """获取资源信息。"""
        original_dir = self._get_original_dir(user_id, context_id, resource_id)
        meta_path = original_dir / ".meta.json"
        
        if not meta_path.exists():
            return None
        
        import json
        meta = json.loads(meta_path.read_text())
        filename = meta["filename"]
        file_path = original_dir / filename
        
        if not file_path.exists():
            return None
        
        stat = file_path.stat()
        return ResourceInfo(
            resource_id=resource_id,
            name=filename,
            path=f"{user_id}/{context_id}/{resource_id}/original/{filename}",
            size=stat.st_size,
            content_type=meta.get("content_type"),
            created_at=datetime.fromtimestamp(stat.st_ctime),
            updated_at=datetime.fromtimestamp(stat.st_mtime)
        )
    
    async def list_resources(
        self,
        user_id: str,
        context_id: Optional[str] = None
    ) -> list[ResourceInfo]:
        """列出用户的资源。"""
        resources = []
        
        if context_id:
            # 列出特定 context 的资源
            context_dir = self.base_path / user_id / context_id
            if context_dir.exists():
                for resource_dir in context_dir.iterdir():
                    if resource_dir.is_dir():
                        info = await self.get_resource_info(
                            user_id, context_id, resource_dir.name
                        )
                        if info:
                            resources.append(info)
        else:
            # 列出用户所有资源
            user_dir = self.base_path / user_id
            if user_dir.exists():
                for context_dir in user_dir.iterdir():
                    if context_dir.is_dir():
                        for resource_dir in context_dir.iterdir():
                            if resource_dir.is_dir():
                                info = await self.get_resource_info(
                                    user_id, context_dir.name, resource_dir.name
                                )
                                if info:
                                    resources.append(info)
        
        return resources
