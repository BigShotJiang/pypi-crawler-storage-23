"""
Git Server 初始化与管理

用于在本地环境中启动和管理 Git 服务器，支持：
1. 本地裸仓库管理
2. Git daemon 启动（可选）
3. SSH 服务配置（可选）

典型使用场景：
- 单机开发：直接使用本地文件路径
- 局域网协作：启动 git daemon
- 远程访问：配置 SSH 或 HTTP 服务
"""

import os
import subprocess
import shutil
from pathlib import Path
from typing import Optional, List
from dataclasses import dataclass


@dataclass
class GitServerConfig:
    """Git 服务器配置"""
    # 基础配置
    base_path: str = "/tmp/turbo_agent/git_server"  # 裸仓库根目录
    
    # Git Daemon 配置
    enable_daemon: bool = False
    daemon_port: int = 9418
    daemon_bind: str = "0.0.0.0"
    
    # SSH 配置
    enable_ssh: bool = False
    ssh_port: int = 22
    
    # HTTP 配置 (git http-backend)
    enable_http: bool = False
    http_port: int = 8080


class GitServer:
    """
    Git 服务器管理器。
    
    负责：
    1. 创建和管理裸仓库
    2. 启动/停止 Git 服务
    3. 用户权限管理
    
    Example:
        >>> config = GitServerConfig(base_path="/data/git")
        >>> server = GitServer(config)
        >>> 
        >>> # 创建用户仓库
        >>> repo_path = server.create_bare_repository("user_123", "workspace_001")
        >>> 
        >>> # 启动 daemon（如果需要网络访问）
        >>> server.start_daemon()
    """
    
    def __init__(self, config: Optional[GitServerConfig] = None):
        self.config = config or GitServerConfig()
        self.base_path = Path(self.config.base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self._daemon_process: Optional[subprocess.Popen] = None
    
    def _get_user_dir(self, user_id: str) -> Path:
        """获取用户目录。"""
        return self.base_path / user_id
    
    def _get_bare_repo_path(self, user_id: str, workspace_id: str) -> Path:
        """获取裸仓库路径。"""
        return self.base_path / user_id / f"{workspace_id}.git"
    
    # ===== 仓库管理 =====
    
    def create_bare_repository(
        self,
        user_id: str,
        workspace_id: str,
        initialize: bool = True
    ) -> Path:
        """
        创建裸仓库。
        
        Args:
            user_id: 用户ID
            workspace_id: 工作区ID
            initialize: 是否初始化仓库
            
        Returns:
            裸仓库路径
        """
        repo_path = self._get_bare_repo_path(user_id, workspace_id)
        
        if repo_path.exists():
            return repo_path
        
        repo_path.mkdir(parents=True, exist_ok=True)
        
        if initialize:
            # 初始化裸仓库
            subprocess.run(
                ["git", "init", "--bare"],
                cwd=repo_path,
                check=True,
                capture_output=True
            )
            
            # 配置仓库
            self._configure_repository(repo_path, user_id)
        
        return repo_path
    
    def _configure_repository(self, repo_path: Path, user_id: str):
        """配置仓库。"""
        # 设置描述
        description_path = repo_path / "description"
        description_path.write_text(f"Workspace repository for user {user_id}\n")
        
        # 启用 receive.denyNonFastForwards
        config_path = repo_path / "config"
        config_content = config_path.read_text()
        if "receive.denyNonFastForwards" not in config_content:
            with open(config_path, "a") as f:
                f.write("\n[receive]\n\tdenyNonFastForwards = true\n")
    
    def delete_repository(self, user_id: str, workspace_id: str) -> bool:
        """删除仓库。"""
        repo_path = self._get_bare_repo_path(user_id, workspace_id)
        
        if repo_path.exists():
            shutil.rmtree(repo_path)
            return True
        return False
    
    def list_repositories(self, user_id: Optional[str] = None) -> List[dict]:
        """
        列出仓库。
        
        Args:
            user_id: 筛选特定用户的仓库
            
        Returns:
            仓库信息列表
        """
        repos = []
        
        if user_id:
            user_dirs = [self._get_user_dir(user_id)]
        else:
            user_dirs = [d for d in self.base_path.iterdir() if d.is_dir()]
        
        for user_dir in user_dirs:
            uid = user_dir.name
            for repo_dir in user_dir.glob("*.git"):
                if repo_dir.is_dir():
                    repos.append({
                        "user_id": uid,
                        "workspace_id": repo_dir.name.replace(".git", ""),
                        "path": str(repo_dir),
                        "git_url": self.get_git_url(uid, repo_dir.name.replace(".git", ""))
                    })
        
        return repos
    
    def repository_exists(self, user_id: str, workspace_id: str) -> bool:
        """检查仓库是否存在。"""
        repo_path = self._get_bare_repo_path(user_id, workspace_id)
        return repo_path.exists()
    
    def get_repository_path(self, user_id: str, workspace_id: str) -> Path:
        """获取仓库路径。"""
        return self._get_bare_repo_path(user_id, workspace_id)
    
    # ===== URL 生成 =====
    
    def get_git_url(self, user_id: str, workspace_id: str, protocol: str = "file") -> str:
        """
        获取 Git URL。
        
        Args:
            protocol: 协议类型 (file, git, ssh, http)
            
        Returns:
            Git URL
        """
        if protocol == "file":
            return str(self._get_bare_repo_path(user_id, workspace_id))
        elif protocol == "git":
            return f"git://{self.config.daemon_bind}:{self.config.daemon_port}/{user_id}/{workspace_id}.git"
        elif protocol == "ssh":
            return f"ssh://git@{self.config.daemon_bind}:{self.config.ssh_port}/{user_id}/{workspace_id}.git"
        elif protocol == "http":
            return f"http://{self.config.daemon_bind}:{self.config.http_port}/{user_id}/{workspace_id}.git"
        else:
            raise ValueError(f"Unsupported protocol: {protocol}")
    
    # ===== 服务管理 =====
    
    def start_daemon(self) -> subprocess.Popen:
        """
        启动 Git Daemon。
        
        Returns:
            daemon 进程
        """
        if not self.config.enable_daemon:
            raise RuntimeError("Git daemon is not enabled in config")
        
        if self._daemon_process is not None:
            return self._daemon_process
        
        # 创建 git-daemon-export-ok 文件
        for user_dir in self.base_path.iterdir():
            if user_dir.is_dir():
                for repo_dir in user_dir.glob("*.git"):
                    export_ok = repo_dir / "git-daemon-export-ok"
                    export_ok.touch(exist_ok=True)
        
        # 启动 daemon
        cmd = [
            "git", "daemon",
            f"--port={self.config.daemon_port}",
            f"--bind={self.config.daemon_bind}",
            f"--base-path={self.base_path}",
            "--export-all",
            "--enable=receive-pack",  # 允许 push
            "--reuseaddr",
            "--verbose"
        ]
        
        self._daemon_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        return self._daemon_process
    
    def stop_daemon(self):
        """停止 Git Daemon。"""
        if self._daemon_process is not None:
            self._daemon_process.terminate()
            self._daemon_process.wait()
            self._daemon_process = None
    
    def is_daemon_running(self) -> bool:
        """检查 Daemon 是否在运行。"""
        if self._daemon_process is None:
            return False
        return self._daemon_process.poll() is None
    
    # ===== 导入/导出 =====
    
    def import_from_local(
        self,
        user_id: str,
        workspace_id: str,
        local_path: Path,
        branch: str = "main"
    ):
        """
        从本地仓库导入到裸仓库。
        
        Args:
            local_path: 本地工作区路径
            branch: 要推送的分支
        """
        # 创建裸仓库
        bare_path = self.create_bare_repository(user_id, workspace_id)
        
        # 在本地仓库添加 remote 并推送
        remote_name = f"temp_{workspace_id}"
        subprocess.run(
            ["git", "remote", "add", remote_name, str(bare_path)],
            cwd=local_path,
            check=False,
            capture_output=True
        )
        
        subprocess.run(
            ["git", "push", remote_name, branch],
            cwd=local_path,
            check=True,
            capture_output=True
        )
        
        # 删除临时 remote
        subprocess.run(
            ["git", "remote", "remove", remote_name],
            cwd=local_path,
            check=False,
            capture_output=True
        )
    
    def export_to_local(
        self,
        user_id: str,
        workspace_id: str,
        local_path: Path,
        branch: str = "main"
    ):
        """
        从裸仓库导出到本地。
        
        Args:
            local_path: 目标本地路径
            branch: 要拉取的分支
        """
        bare_path = self._get_bare_repo_path(user_id, workspace_id)
        
        if not bare_path.exists():
            raise FileNotFoundError(f"Repository not found: {bare_path}")
        
        # 克隆到本地
        if local_path.exists():
            # 如果已存在，添加 remote 并拉取
            subprocess.run(
                ["git", "remote", "add", "origin", str(bare_path)],
                cwd=local_path,
                check=False,
                capture_output=True
            )
            subprocess.run(
                ["git", "pull", "origin", branch],
                cwd=local_path,
                check=True,
                capture_output=True
            )
        else:
            # 克隆新仓库
            subprocess.run(
                ["git", "clone", str(bare_path), str(local_path)],
                check=True,
                capture_output=True
            )


class GitWorkspaceSync:
    """
    Git 工作区同步管理器。
    
    管理本地工作区与 Git 服务器的同步。
    """
    
    def __init__(self, git_server: GitServer, local_base_path: str = "/tmp/turbo_agent/workspaces"):
        self.git_server = git_server
        self.local_base_path = Path(local_base_path)
    
    def push_to_server(
        self,
        user_id: str,
        workspace_id: str,
        branch: str = "main",
        force: bool = False
    ):
        """
        推送本地工作区到服务器。
        
        如果服务器上不存在仓库，会自动创建。
        """
        local_path = self.local_base_path / user_id / workspace_id
        
        if not local_path.exists():
            raise FileNotFoundError(f"Local workspace not found: {local_path}")
        
        # 确保服务器上有裸仓库
        if not self.git_server.repository_exists(user_id, workspace_id):
            self.git_server.create_bare_repository(user_id, workspace_id)
        
        bare_path = self.git_server.get_repository_path(user_id, workspace_id)
        
        # 添加或更新 remote
        subprocess.run(
            ["git", "remote", "remove", "server"],
            cwd=local_path,
            check=False,
            capture_output=True
        )
        
        subprocess.run(
            ["git", "remote", "add", "server", str(bare_path)],
            cwd=local_path,
            check=True,
            capture_output=True
        )
        
        # 推送
        cmd = ["git", "push", "server", branch]
        if force:
            cmd.append("--force")
        
        subprocess.run(cmd, cwd=local_path, check=True, capture_output=True)
    
    def pull_from_server(
        self,
        user_id: str,
        workspace_id: str,
        branch: str = "main"
    ):
        """从服务器拉取到本地工作区。"""
        local_path = self.local_base_path / user_id / workspace_id
        
        if not local_path.exists():
            raise FileNotFoundError(f"Local workspace not found: {local_path}")
        
        bare_path = self.git_server.get_repository_path(user_id, workspace_id)
        
        if not bare_path.exists():
            raise FileNotFoundError(f"Server repository not found: {bare_path}")
        
        # 添加或更新 remote
        subprocess.run(
            ["git", "remote", "remove", "server"],
            cwd=local_path,
            check=False,
            capture_output=True
        )
        
        subprocess.run(
            ["git", "remote", "add", "server", str(bare_path)],
            cwd=local_path,
            check=True,
            capture_output=True
        )
        
        # 拉取
        subprocess.run(
            ["git", "pull", "server", branch],
            cwd=local_path,
            check=True,
            capture_output=True
        )
    
    def clone_from_server(
        self,
        user_id: str,
        workspace_id: str,
        target_path: Optional[Path] = None,
        branch: str = "main"
    ) -> Path:
        """从服务器克隆到新目录。"""
        bare_path = self.git_server.get_repository_path(user_id, workspace_id)
        
        if not bare_path.exists():
            raise FileNotFoundError(f"Server repository not found: {bare_path}")
        
        if target_path is None:
            target_path = self.local_base_path / user_id / f"{workspace_id}_clone"
        
        # 克隆
        subprocess.run(
            ["git", "clone", str(bare_path), str(target_path)],
            check=True,
            capture_output=True
        )
        
        return target_path
