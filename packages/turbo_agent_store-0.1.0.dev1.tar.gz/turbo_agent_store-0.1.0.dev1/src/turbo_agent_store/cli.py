"""
Store 模块 CLI

提供 YAML 格式的配置导出/导入功能。
注意：数据库相关的命令已移动到 turbo-agent-cloud 模块。
"""

import os
import typer
import yaml
import json
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional
from rich.console import Console
from rich.table import Table
from loguru import logger

from turbo_agent_store.services.package_loader import PackageLoader

app = typer.Typer()
console = Console()


# ===== Verify Command =====

@app.command()
def verify(
    package_path: str = typer.Argument(..., help="Zip 包路径"),
):
    """
    验证 Zip 包并尝试加载到内存。
    检查包内 YAML 文件的格式和依赖关系。
    """
    if not os.path.exists(package_path):
        console.print(f"[red]文件不存在: {package_path}[/red]")
        raise typer.Exit(code=1)

    try:
        loader = PackageLoader()
        entities = loader.load(package_path)
        
        table = Table(title=f"包内容: {os.path.basename(package_path)}")
        table.add_column("Type", style="cyan")
        table.add_column("ID", style="magenta")
        table.add_column("Name")
        table.add_column("Dependencies")
        
        for entity in entities:
            deps = []
            if hasattr(entity, 'model') and entity.model:
                deps.append(f"Model:{entity.model.name}")
            if hasattr(entity, 'tools') and entity.tools:
                deps.append(f"Tools:{len(entity.tools)}")
            
            table.add_row(
                entity.__class__.__name__,
                entity.id,
                entity.name,
                ", ".join(deps)
            )
            
        console.print(table)
        console.print(f"[green]成功加载 {len(entities)} 个实体[/green]")
        
    except Exception as e:
        console.print(f"[red]加载失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        raise typer.Exit(code=1)


# ===== Convert Command =====

@app.command()
def convert(
    input_path: str = typer.Argument(..., help="输入 YAML/JSON 文件路径"),
    output_path: str = typer.Argument(..., help="输出文件路径"),
    format: str = typer.Option("yaml", help="输出格式: yaml 或 json"),
):
    """
    在不同格式间转换配置文件。
    用于格式标准化和数据迁移。
    """
    input_file = Path(input_path)
    if not input_file.exists():
        console.print(f"[red]输入文件不存在: {input_path}[/red]")
        raise typer.Exit(code=1)
    
    try:
        # 读取输入
        with open(input_file, 'r', encoding='utf-8') as f:
            if input_path.endswith('.json'):
                data = json.load(f)
            else:
                data = yaml.safe_load(f)
        
        # 写入输出
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            if format.lower() == 'json':
                json.dump(data, f, indent=2, ensure_ascii=False)
            else:
                yaml.dump(data, f, allow_unicode=True, sort_keys=False)
        
        console.print(f"[green]已转换: {input_path} -> {output_path}[/green]")
        
    except Exception as e:
        console.print(f"[red]转换失败: {e}[/red]")
        raise typer.Exit(code=1)


# ===== Package Command =====

pack_app = typer.Typer()
app.add_typer(pack_app, name="pack", help="打包/解包配置")


@pack_app.command("create")
def pack_create(
    source_dir: str = typer.Argument(..., help="源目录路径（包含 YAML 文件）"),
    output: str = typer.Option("export.zip", help="输出 Zip 文件路径"),
):
    """
    将 YAML 配置目录打包为 Zip 包。
    """
    source_path = Path(source_dir)
    if not source_path.exists():
        console.print(f"[red]源目录不存在: {source_dir}[/red]")
        raise typer.Exit(code=1)
    
    try:
        output_file = Path(output)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            yaml_files = list(source_path.rglob("*.yaml")) + list(source_path.rglob("*.yml"))
            
            for file_path in yaml_files:
                rel_path = file_path.relative_to(source_path)
                zf.write(file_path, arcname=str(rel_path))
                console.print(f"  添加: {rel_path}")
        
        console.print(f"[green]已创建包: {output}[/green]")
        console.print(f"  共 {len(yaml_files)} 个 YAML 文件")
        
    except Exception as e:
        console.print(f"[red]打包失败: {e}[/red]")
        raise typer.Exit(code=1)


@pack_app.command("extract")
def pack_extract(
    package_path: str = typer.Argument(..., help="Zip 包路径"),
    output_dir: str = typer.Option("./extracted", help="输出目录"),
):
    """
    解压 Zip 包到目录。
    """
    package_file = Path(package_path)
    if not package_file.exists():
        console.print(f"[red]包文件不存在: {package_path}[/red]")
        raise typer.Exit(code=1)
    
    try:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        with zipfile.ZipFile(package_file, 'r') as zf:
            zf.extractall(output_path)
        
        console.print(f"[green]已解压到: {output_dir}[/green]")
        
    except Exception as e:
        console.print(f"[red]解压失败: {e}[/red]")
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
