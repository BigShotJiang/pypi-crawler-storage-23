from typing import Dict, List, Any, Set, Optional, Union
import httpx
import os
import urllib.parse
from pathlib import Path
from loguru import logger
from turbo_agent_core.schema.agents import Agent, Tool, Character, LLMModel, BasicAgent, LLMTool, APITool
from turbo_agent_core.schema.external import Platform, Secret
from turbo_agent_core.schema.resources import Project
from turbo_agent_core.store.config import BaseConfigStore

class ExportService:
    def __init__(self, store: BaseConfigStore, resource_base_url: Optional[str] = None, resource_output_dir: Optional[str] = None):
        self.store = store
        self.resource_base_url = resource_base_url
        self.resource_output_dir = resource_output_dir

    async def export_agent(self, agent_id: str) -> Dict[str, Any]:
        agent = await self.store.get_agent(agent_id)
        if not agent:
            raise ValueError(f"未找到智能体 (Agent): {agent_id}")
        return await self._package(agent)

    async def export_character(self, char_id: str) -> Dict[str, Any]:
        char = await self.store.get_character(char_id)
        if not char:
            raise ValueError(f"未找到角色 (Character): {char_id}")
        return await self._package(char)
        
    async def export_tool(self, tool_id: str) -> Dict[str, Any]:
        tool = await self.store.get_tool(tool_id)
        if not tool:
            raise ValueError(f"未找到工具 (Tool): {tool_id}")
        return await self._package(tool)

    async def export_model(self, model_id: str) -> Dict[str, Any]:
        model = await self.store.get_model(model_id)
        if not model:
            raise ValueError(f"未找到模型 (Model): {model_id}")
        return await self._package(model)

    async def export_platform(self, platform_id: str) -> Dict[str, Any]:
        platform = await self.store.get_platform(platform_id)
        if not platform:
            raise ValueError(f"未找到平台 (Platform): {platform_id}")
        return await self._package(platform)

    async def export_batch(self, agents: List[Agent] = None, characters: List[Character] = None, tools: List[Tool] = None) -> Dict[str, Any]:
        collected = {}
        if agents:
            for agent in agents:
                await self._collect_recursive(agent, collected)
        if characters:
            for char in characters:
                await self._collect_recursive(char, collected)
        if tools:
            for tool in tools:
                await self._collect_recursive(tool, collected)
        
        # 处理资源下载 (Process resources like avatar)
        if self.resource_output_dir:
            await self._process_resources(collected)
            
        return self._build_package(collected)

    async def _package(self, root_entity: Any) -> Dict[str, Any]:
        collected = {} # id -> entity
        await self._collect_recursive(root_entity, collected)
        
        # 处理资源下载 (Process resources like avatar)
        if self.resource_output_dir:
            await self._process_resources(collected)
            
        return self._build_package(collected)

    async def _process_resources(self, collected: Dict[str, Any]):
        """
        遍历所有实体，下载 avatar_uri 等资源到本地，并重写 URI。
        """
        if not self.resource_output_dir:
            return

        # 确保目录存在
        avatar_dir = Path(self.resource_output_dir) / "resources" / "avatar"
        avatar_dir.mkdir(parents=True, exist_ok=True)

        async with httpx.AsyncClient() as client:
            for entity in collected.values():
                # 检查 avatar_uri
                if hasattr(entity, "avatar_uri") and entity.avatar_uri:
                    original_uri = entity.avatar_uri
                    if not original_uri:
                        continue
                        
                    # 目前只处理 http/https 或相对路径
                    # 如果是 file:// 开头，假设已经是本地路径或处理过的，跳过 (或者根据需求处理)
                    if original_uri.startswith("file://"):
                        continue
                    
                    target_url = original_uri
                    # 如果是相对路径且提供了 base_url，则拼接
                    if not (original_uri.startswith("http://") or original_uri.startswith("https://")):
                         if self.resource_base_url:
                             target_url = urllib.parse.urljoin(self.resource_base_url, original_uri)
                         else:
                             # 相对路径但没有 base_url，无法下载，跳过
                             logger.warning(f"Entity {entity.id} has relative avatar_uri '{original_uri}' but no base_url provided. Skipping download.")
                             continue

                    try:
                        # 下载图片
                        logger.info(f"Downloading avatar for {entity.id}: {target_url}")
                        response = await client.get(target_url, timeout=10.0)
                        if response.status_code == 200:
                            # 确定文件名 (使用 url 结尾或 entity id)
                            # 尝试从 url path 获取文件名，没有后缀则默认 png
                            # 注意：需要 unquote 解码 URL 编码的文件名 (例如 %E6%B5%8B.png -> 测.png)
                            parsed = urllib.parse.urlparse(original_uri)
                            filename = os.path.basename(urllib.parse.unquote(parsed.path))
                            
                            if not filename or "." not in filename:
                                # 尝试从 Content-Type 猜测
                                content_type = response.headers.get("content-type", "")
                                ext = ".png"
                                if "jpeg" in content_type or "jpg" in content_type:
                                    ext = ".jpg"
                                elif "gif" in content_type:
                                    ext = ".gif"
                                elif "webp" in content_type:
                                    ext = ".webp"
                                filename = f"{entity.id}{ext}"
                            
                            # 保存文件
                            file_path = avatar_dir / filename
                            with open(file_path, "wb") as f:
                                f.write(response.content)
                            
                            # 重写 URI (file://./resources/avatar/filename)
                            # Export 包的根目录是 zip 根，resources 在根下
                            entity.avatar_uri = f"file://./resources/avatar/{filename}"
                        else:
                            logger.warning(f"Failed to download avatar from {target_url}, status: {response.status_code}")
                    except Exception as e:
                        logger.warning(f"Error downloading avatar for {entity.id}: {e}")

    def _build_package(self, collected: Dict[str, Any]) -> Dict[str, Any]:
        # 按类型分组 (Group by type)
        # ... (same as before)
        result = {
            "version": "1.0",
            "agents": [],
            "characters": [],
            "tools": [],
            "models": [],
            "platforms": [],
            "secrets": [],
            "projects": []
        }
        
        for entity in collected.values():
            flat = self._flatten(entity)
            if isinstance(entity, Agent):
                result["agents"].append(flat)
            elif isinstance(entity, Character):
                result["characters"].append(flat)
            elif isinstance(entity, Tool):
                result["tools"].append(flat)
            elif isinstance(entity, LLMModel):
                result["models"].append(flat)
            elif isinstance(entity, Platform):
                result["platforms"].append(flat)
            elif isinstance(entity, Secret):
                result["secrets"].append(flat)
            elif isinstance(entity, Project):
                result["projects"].append(flat)
                
        return result

    async def _collect_recursive(self, entity: Any, collected: Dict[str, Any]):
        if not entity or not hasattr(entity, "id"):
            return
        if entity.id in collected:
            return
        
        collected[entity.id] = entity
        
        # 收集 Project (如果实体有 belongToProjectId)
        if hasattr(entity, "belongToProjectId") and entity.belongToProjectId:
            # 只有当 entity 不是 Project 自己时才去搜
            if not isinstance(entity, Project):
                 # belongToProjectId 是 ID
                 pid = entity.belongToProjectId
                 if pid and pid not in collected:
                     project = await self.store.get_project(pid)
                     if project:
                        # 确保以 id 存入 collected，避免重复
                         # 注意: get_project 实现中我们返回了 Project 对象，id 是数据库主键
                         # 如果 pid 是 orgProjectId, 但我们 collected key用 id?
                         # 这里的 pid 可能是 orgProjectId。
                         # 为了去重，我们需要确保 consistently 使用 Project.id 作为 key。
                         # 上面: collected[entity.id] = entity
                         # 如果 pid != project.id, 可能会重复加载？
                         # get_project 实现: find by org_projectid OR id.
                         # 让我们用 project.id 做 key。
                         if project.id not in collected:
                             collected[project.id] = project

        # 递归遍历子对象 (Traverse children)
        # Agent
        if isinstance(entity, Agent):
            if entity.model:
                await self._collect_recursive(entity.model, collected)
            for t in entity.tools:
                await self._collect_recursive(t, collected)
            for c in entity.actAsCharacters:
                await self._collect_recursive(c, collected)
            for a in entity.assistantAgents:
                await self._collect_recursive(a, collected)
            for s in entity.accountSecrets:
                await self._collect_recursive(s, collected)
                
        # Character
        elif isinstance(entity, Character):
            if entity.model:
                await self._collect_recursive(entity.model, collected)
            for t in entity.tools:
                await self._collect_recursive(t, collected)
                
        # Tool (LLMTool / APITool)
        elif isinstance(entity, Tool):
             # 检查是否有模型 (LLMTool)
             if hasattr(entity, "model") and entity.model:
                 await self._collect_recursive(entity.model, collected)
             # 检查是否有 BusinessSetting (LLMTool)
             if hasattr(entity, "setting") and entity.setting:
                 pass # BusinessSetting 不是独立实体，是直接嵌入的，不需要递归收集ID，flatten 时会自动导出
             # 检查是否有平台 (APITool)
             if isinstance(entity, APITool) and entity.platform:
                 await self._collect_recursive(entity.platform, collected)

        # Secret
        elif isinstance(entity, Secret):
             if entity.platformId and entity.platformId not in collected:
                 try:
                     platform = await self.store.get_platform(entity.platformId)
                     if platform:
                         await self._collect_recursive(platform, collected)
                 except Exception:
                     pass # Ignore if platform not found or error
                     
    def _flatten(self, entity: Any) -> Dict[str, Any]:
        # 转为字典 (Dump to dict)
        data = entity.model_dump(mode='json', exclude_none=True)
        
        # Ensure run_type is string (fix for potential enum serialization issues if not using mode='json' or custom encoder)
        # Although model_dump(mode='json') handles Enum, we ensure it here to be safe as per request.
        if "run_type" in data and not isinstance(data["run_type"], str):
             # This handles case where value might be Enum member object
             data["run_type"] = str(data["run_type"].value if hasattr(data["run_type"], "value") else data["run_type"])
        elif "run_type" in data and isinstance(data["run_type"], str) and "." in data["run_type"]:
             # If it accidentally serialized as "RunType.Character" (e.g. str(Enum) behavior in some versions)
             # We split and take the last part. 
             # But RunType(str, Enum) str() behavior is tricky. 
             # Let's trust model_dump but if user says "RunType.Character" appears, maybe they saw it somewhere else?
             # Or maybe pydantic v2 dump of str-enum behaves differently in some edge case.
             # If value is literally "RunType.Character", we fix it.
             if data["run_type"].startswith("RunType."):
                 data["run_type"] = data["run_type"].split(".")[-1]

        # 将嵌套对象替换为 ID (Replace objects with IDs)
        if isinstance(entity, Agent):
            if entity.model:
                data['model'] = entity.model.id
            if entity.tools:
                data['tools'] = [t.id for t in entity.tools]
            if entity.actAsCharacters:
                data['actAsCharacters'] = [c.id for c in entity.actAsCharacters]
            if entity.assistantAgents:
                data['assistantAgents'] = [a.id for a in entity.assistantAgents]
            if entity.accountSecrets:
                data['accountSecrets'] = [s.id for s in entity.accountSecrets]
            
        elif isinstance(entity, Character):
            if entity.model:
                data['model'] = entity.model.id
            if entity.tools:
                data['tools'] = [t.id for t in entity.tools]
                
        elif isinstance(entity, Tool):
            if hasattr(entity, "model") and entity.model:
                data['model'] = entity.model.id
            if isinstance(entity, APITool) and entity.platform:
                data['platform'] = entity.platform.id

        elif isinstance(entity, Platform):
            # Platform holds secrets, we should reference them by ID in the flattened structure
            # to avoid duplication with top-level 'secrets' list
            if entity.secrets:
                data['secrets'] = [s.id for s in entity.secrets]
            # AuthMethods are usually nested within Platform, no global list for them, so we keep them.
                
        return data
