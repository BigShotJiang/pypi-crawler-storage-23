from json import tool
import pandas as pd
import json
from tqdm import tqdm
from urllib import parse
import time
from dotenv import load_dotenv
import hashlib
import dateutil.parser
from loguru import logger
import os
import tempfile
import shutil
from prisma.models import ToolCallRecord,Tool,ToolVersion,User,Agent,Agent,KnowledgeResource
from prisma.enums import ToolCallStatus,ToolType
from typing import List
from datetime import datetime
from turbo_agent_store.rag.schema import UserInfo, KnowledgeChunk,ToolRecordChunk, ChunkFieldType, ToolVersionInfo, AgentInfo
from turbo_agent_store.settings import settings
from turbo_agent_store.utils.cos_access import download_file_from_cos
from enum import Enum
from ..utils.rag_chunk import chunk_data_on_schema,string_chunking,document_chunking
from turbo_agent_store.utils.docling_client import DoclingClient
from docling_core.types import DoclingDocument
import requests

# Import Manticore Search client instead of Meilisearch
from turbo_agent_store.utils.manticore_search import ManticoreSearchClient, wait_task, wait_tasks, IndexNotFoundError, ManticoreApiError

def check_tasks():
    client = ManticoreSearchClient(settings.MANTICORE_HOST, settings.MANTICORE_API_KEY)
    res = client.get_tasks()
    for result in res.results:
        logger.info(result)

def initial_index(
        index_id,primary_key,
        documentTemplate="",        
        searchable_attributes=[],
        filterable_attributes =[]
    ):
    client = ManticoreSearchClient(settings.MANTICORE_HOST, settings.MANTICORE_API_KEY)
    force_recreate = getattr(settings, 'MANTICORE_FORCE_RECREATE', False)
    # Set document template for this index if provided
    if documentTemplate:
        client.set_template(index_id, documentTemplate)
    if searchable_attributes:
        client.set_searchable_attributes(index_id, searchable_attributes)
    if force_recreate:
        try:
            client.delete_index(index_id)
            logger.info(f"Force recreate enabled: dropped existing index {index_id}")
        except Exception as e:
            logger.info(f"Force recreate: index {index_id} did not previously exist or drop failed: {e}")
    try:
        if not force_recreate:
            index = client.get_index(index_id)
            if index:
                return index
        raise IndexNotFoundError('force create')
    except IndexNotFoundError as e:
        logger.info(f" index {index_id} not exists (or force), creating a new one")
        # Define schema based on the index type
        schema = _get_index_schema(index_id, searchable_attributes, filterable_attributes)
        task_info = client.create_index(index_id, schema)
        wait_task(task_info)
        index = client.index(index_id)
    # These operations are handled automatically by Manticore
    task_info = index.update_searchable_attributes(searchable_attributes)
    wait_task(task_info)
    task_info = index.update_filterable_attributes(filterable_attributes)
    wait_task(task_info)
    task_info = index.update_pagination_settings({'maxTotalHits': 20000})
    wait_task(task_info)
    return index

def _get_index_schema(index_id: str, searchable_attributes: List[str], filterable_attributes: List[str]) -> dict:
    """Generate Manticore schema based on index type and attributes"""
    
    # Common fields for all indices
    base_schema = {
        '_id': {'type': 'string'},
        'content': {'type': 'text'},
        # Proper vector field config for KNN search and quantization
        'content_vector': {
            'type': 'float_vector',
            'knn_type': 'hnsw',
            'knn_dims': int(getattr(settings, 'EMBEDDING_DIM', 1024)),
            'hnsw_similarity': 'cosine',
            'quantization': '1bit'
        },
        'created_at': {'type': 'integer'},
        'updated_at': {'type': 'integer'},
    }
    
    # Action index specific fields
    if 'action' in index_id.lower():
        base_schema.update({
            'type': {'type': 'string'},
            'tool_call_record_id': {'type': 'string'},
            'tool_info': {'type': 'json'},
            'agent_info': {'type': 'json'},
            'root_caller': {'type': 'json'},
            'status': {'type': 'string'},
            'intent': {'type': 'text'},
            'chunk_sub_field_paths': {'type': 'json'},
            'chunk_index': {'type': 'integer'},
            'error': {'type': 'text'},
            'tags': {'type': 'json'},
            'workset_ids': {'type': 'json'},
            'message_action_ids': {'type': 'json'},
            'next_record_ids': {'type': 'json'},
            'pre_record_ids': {'type': 'json'},
            'metadata': {'type': 'json'},
        })
    
    # Knowledge index specific fields
    elif 'knowledge' in index_id.lower():
        base_schema.update({
            'type': {'type': 'string'},
            'mime_type': {'type': 'string'},
            'file_type': {'type': 'string'},
            'name': {'type': 'text'},
            'filename': {'type': 'string'},
            'tags': {'type': 'json'},
            'knowledge_id': {'type': 'string'},
            'chunk_index': {'type': 'integer'},
            'projects': {'type': 'json'},
            'settings': {'type': 'json'},
            'worksets': {'type': 'json'},
            'user_ids': {'type': 'json'},
            'creatorId': {'type': 'string'},
            'metadata': {'type': 'json'},
            'setting_ids': {'type': 'json'},
            'project_ids': {'type': 'json'},
            'workset_ids': {'type': 'json'},
        })
    
    return base_schema

def init_action_index():
    """
    初始化工具调用记录索引，基于 ToolRecordChunk 结构
    """
    index_id = getattr(settings, 'MANTICORE_ACTION_INDEX', 'turboagent-action')
    
    searchable_attributes = [
        "content", "error", "tags", "intent", "tool_info",
        "agent_info", "root_caller"
    ]
    filterable_attributes = [
        "type", "tool_call_record_id", "status", "chunk_index", "tags", "workset_ids", 
        "message_action_ids","next_record_ids", "created_at", "updated_at"
    ]

    documentTemplate = (
        "【工具名称】{{doc.tool_info.name}}\n"
        "【工具类型】{{doc.tool_info.type}}\n"
        "【记录字段】{{doc.type}}\n"
        "【调用意图】{{doc.intent}}\n"
        "【分块内容】{{doc.content}}\n"
        "【错误信息】{{doc.error}}\n"
        "【标签】{{doc.tags}}\n"
    )

    index = initial_index(
        index_id=index_id,
        primary_key="id",
        documentTemplate=documentTemplate,
        searchable_attributes=searchable_attributes,
        filterable_attributes=filterable_attributes
    )
    return index

def init_knowledge_index():
    """
    初始化知识索引，基于 KnowledgeChunk 结构
    """
    index_id = getattr(settings, 'MANTICORE_KNOWLEDGE_INDEX', 'turboagent-knowledges')
    
    searchable_attributes = [
        "content", "tags", "filename", "name", "projects", "settings", "worksets", "type"
    ]
    filterable_attributes = [
        "type", "mime_type","file_type","tags", "knowledge_id", "chunk_index", "projects", "settings", "worksets","user_ids",
        "creatorId", "created_at", "updated_at"
    ]
    documentTemplate = (
        "【文件名称】{{doc.name}}\n"
        "【文件部分内容】{{doc.content}}\n"
        "【知识类型】{{doc.type}}\n"
        "【标签】{{doc.tags}}\n"
        "【文件类型】{{doc.type}}\n"
    )
    index = initial_index(
        index_id=index_id,
        primary_key="id",
        documentTemplate=documentTemplate,
        searchable_attributes=searchable_attributes,
        filterable_attributes=filterable_attributes
    )
    return index

class IndexType(str,Enum):
    KNOWLEDGE = "KNOWLEDGE"
    WORKSET = "WORKSET"
    ACTION = "ACTION"

def get_index(indexType:IndexType, documentTemplate: str = None, searchable_attributes: list = None, filterable_attributes: list = None):
    """
    获取指定类型的索引，如果不存在则创建。
    :param indexType: 索引类型
    :param documentTemplate: 文档模板字符串
    :param searchable_attributes: 可搜索字段列表
    :param filterable_attributes: 可过滤字段列表
    :return: Manticore Index 对象
    """
    if indexType == IndexType.ACTION:
        index_id = getattr(settings, 'MANTICORE_ACTION_INDEX', 'turboagent-action')
        default_template = (
            "【工具名称】{{doc.tool_info.name}}\n"
            "【工具类型】{{doc.tool_info.type}}\n"
            "【记录字段】{{doc.type}}\n"
            "【调用意图】{{doc.intent}}\n"
            "【分块内容】{{doc.content}}\n"
            "【错误信息】{{doc.error}}\n"
            "【标签】{{doc.tags}}\n"
        )
        default_searchable = [
            "content", "error", "tags", "intent", "tool_info",
            "agent_info", "root_caller"
        ]
        default_filterable = [
            "type", "tool_call_record_id", "status", "chunk_index", "tags", "workset_ids",
            "message_action_ids", "next_record_ids", "created_at", "updated_at"
        ]
    elif indexType == IndexType.KNOWLEDGE:
        index_id = getattr(settings, 'MANTICORE_KNOWLEDGE_INDEX', 'turboagent-knowledges')
        default_template = (
            "【文件名称】{{doc.name}}\n"
            "【文件部分内容】{{doc.content}}\n"
            "【知识类型】{{doc.type}}\n"
            "【标签】{{doc.tags}}\n"
            "【文件类型】{{doc.type}}\n"
        )
        default_searchable = [
            "content", "tags", "filename", "name", "projects", "settings", "worksets", "type"
        ]
        default_filterable = [
            "type", "mime_type","file_type","tags", "knowledge_id", "chunk_index", "projects", "settings", "worksets","user_ids",
            "creatorId", "created_at", "updated_at"
        ]
    else:
        raise ValueError("Unsupported index type")

    client = ManticoreSearchClient(settings.MANTICORE_HOST, settings.MANTICORE_API_KEY)
    force_recreate = getattr(settings, 'MANTICORE_FORCE_RECREATE', False)
    # Always set template and attributes before returning index
    client.set_template(index_id, documentTemplate or default_template)
    client.set_searchable_attributes(index_id, (searchable_attributes or default_searchable))
    # Optionally, could store searchable/filterable attributes if needed for future use
    # (Manticore does not store these, so just pass them as needed)
    if force_recreate:
        try:
            client.delete_index(index_id)
            logger.info(f"Force recreate enabled: dropped existing index {index_id}")
        except Exception as e:
            logger.info(f"Force recreate drop attempt for {index_id} (may not exist): {e}")
    try:
        if not force_recreate:
            index = client.get_index(index_id)
            return index
        raise IndexNotFoundError('force create')
    except IndexNotFoundError:
        logger.info(f"Index {index_id} not found (or force), creating a new one.")
        schema = _get_index_schema(index_id, searchable_attributes or default_searchable, filterable_attributes or default_filterable)
        task_info = client.create_index(index_id, schema)
        wait_task(task_info)
        return client.index(index_id)
    except Exception as e:
        logger.error(f"Error getting/creating index {index_id}: {e}")
        raise

def update_action_record_index(record_id, workset_ids: list[str], message_ids: list[str]):
    """
    在索引中更新动作记录的工作集和消息ID
    """
    tool_record_index = get_index(IndexType.ACTION)
    res = tool_record_index.search("*", {"filter": [f'tool_call_record_id = "{record_id}"']})
    if "hits" in res and len(res['hits'])>0:
        docs = res["hits"]
        task = tool_record_index.update_documents([
            {
                "_id": doc.get("_id") or doc.get("id"),
                "workset_ids": list(set(doc.get("workset_ids", []) + workset_ids)),
                "message_action_ids": list(set(doc.get("message_action_ids", []) + message_ids))
            }
            for doc in docs
        ])
        wait_task(task)

def parse_file(knowledge_resource: KnowledgeResource) -> DoclingDocument:
    file_id = knowledge_resource.id
    file_uri = knowledge_resource.uri
    file_content = knowledge_resource.content
    tempfile = download_file_from_cos(file_uri,private=True)
    client = DoclingClient()
    task_info = client.convert_files_async(file_paths=[tempfile], timeout=300)
    logger.info(f"Docling task started: {task_info}")
    for doc in client.wait_task():
        docling_doc = DoclingDocument.model_validate_json(json.dumps(doc["json_content"]))
        return docling_doc
    return None

def index_knowledge_file(knowledge_resource:KnowledgeResource,docling_doc:DoclingDocument):
    file_id = knowledge_resource.id
    file_uri = knowledge_resource.uri
    file_content = knowledge_resource.content
    try:
        # 建立文件索引
        chunks = []
        if file_uri:
            for index,node in enumerate(string_chunking(docling_doc.export_to_markdown(),chunk_limit=4000)):
                chunk = KnowledgeChunk(
                    _id=f"{file_id}_content_{index}",
                    knowledge_id=knowledge_resource.id,
                    chunk_index=index,
                    content=node.get_content(),
                    type=knowledge_resource.type,
                    file_type=knowledge_resource.fileType,
                    mime_type=knowledge_resource.mime_type,
                    name=knowledge_resource.name,
                    tags=knowledge_resource.tags or [],
                    metadata={},
                    filename=knowledge_resource.filename,
                    setting_ids=[setting.settingId for setting in knowledge_resource.settings ] if knowledge_resource.settings else [],
                    project_ids=[project.projectId for project in knowledge_resource.projects ] if knowledge_resource.projects else [],
                    workset_ids=[workset.worksetId for workset in knowledge_resource.worksets ] if knowledge_resource.worksets else [],
                    user_ids= [],
                    created_at=int(knowledge_resource.createdAt.timestamp()),
                    updated_at=int(knowledge_resource.updatedAt.timestamp()),
                    creatorId=knowledge_resource.creatorId
                )
                chunks.append(chunk)
        elif file_content:
            for index,node in enumerate(string_chunking(file_content,chunk_limit=4000)):
                chunk = KnowledgeChunk(
                    _id=f"{file_id}_content_{index}",
                    knowledge_id=knowledge_resource.id,
                    chunk_index=index,
                    content=node.get_content(),
                    type=knowledge_resource.type,
                    file_type=knowledge_resource.fileType,
                    mime_type=knowledge_resource.mimeType,
                    name=knowledge_resource.name,
                    tags=knowledge_resource.tags or [],
                    metadata=knowledge_resource.metadata or {},
                    filename=knowledge_resource.filename,
                    setting_ids=[setting.settingId for setting in knowledge_resource.settings ] if knowledge_resource.settings else [],
                    project_ids=[project.projectId for project in knowledge_resource.projects ] if knowledge_resource.projects else [],
                    workset_ids=[workset.worksetId for workset in knowledge_resource.worksets ] if knowledge_resource.worksets else [],
                    user_ids=[user.userId for user in knowledge_resource.users ] if knowledge_resource.users else [],
                    created_at=int(knowledge_resource.createdAt.timestamp()),
                    updated_at=int(knowledge_resource.updatedAt.timestamp()),
                    creatorId=knowledge_resource.creatorId
                )
                chunks.append(chunk)
        
        tool_record_index = get_index(IndexType.KNOWLEDGE)
        logger.debug(f"Indexing {len(chunks)} knowledge chunks for knowledge ID {knowledge_resource.id}")
        # 添加至索引，统一 id -> _id
        docs = []
        for c in chunks:
            d = c.model_dump()
            if '_id' not in d and 'id' in d:
                d['_id'] = d.pop('id')
            docs.append(d)
        task = tool_record_index.add_documents(docs)
        wait_task(task)

        return {"indexed":chunks}

    except Exception as e:
        logger.error(f"Error indexing knowledge file: {file_id}")
        logger.exception(e)
        return {"error": str(e)}


def update_knowledge_file_index(knowledge_id, setting_ids: list[str]=[], project_ids: list[str]=[], workset_ids: list[str]=[]):
    """
    在索引中更新知识文件的设置ID、项目ID和工作集ID
    """
    knowledge_index = get_index(IndexType.KNOWLEDGE)
    res = knowledge_index.search("*", {"filter":f'knowledge_id = "{knowledge_id}"'})
    if "hits" in res and len(res['hits'])>0:
        docs = res["hits"]
        task = knowledge_index.update_documents([
            {
                "_id": doc.get("_id") or doc.get("id"),
                "worksets": list(set(doc.get("workset_ids", []) + workset_ids)),
                "settings": list(set(doc.get("setting_ids", []) + setting_ids)),
                "projects": list(set(doc.get("project_ids", []) + project_ids))
            }
            for doc in docs
        ])
        wait_task(task)
    else:
        logger.warning(f"No knowledge chunks found for knowledge_id {knowledge_id} to update.")
    

def unbind_knowledge_file(knowledge_id: str, setting_ids: list[str] = [], project_ids: list[str] = [], workset_ids: list[str] = []):
    """
    在索引中解绑知识文件的设置ID、项目ID和工作集ID
    """
    knowledge_index = get_index(IndexType.KNOWLEDGE)
    res = knowledge_index.search("*", {"filter": f'knowledge_id = "{knowledge_id}"'})
    if "hits" in res and len(res['hits']) > 0:
        docs = res["hits"]
        task = knowledge_index.update_documents([
            {
                "_id": doc.get("_id") or doc.get("id"),
                "worksets": list(set(doc.get("workset_ids", []))-set(workset_ids)),
                "settings": list(set(doc.get("setting_ids", []))-set(setting_ids)),
                "projects": list(set(doc.get("project_ids", []))-set(project_ids))
            }
            for doc in docs
        ])
        wait_task(task)
    else:
        logger.warning(f"No knowledge chunks found for knowledge_id {knowledge_id} to unbind.")


def index_action_record_attention(
        intent:str,
        summary: str,
        workset_ids: list[str],
        record: ToolCallRecord) -> ToolRecordChunk:
    """
    解析单个工具调用记录的摘要，转换为 ToolRecordChunk（摘要类型）。
    """
    root_caller_info = record.rootCaller
    agent_caller_info = record.agentCaller
    # 构建工具版本信息
    tool_info = ToolVersionInfo(
        name_id=record.toolNameId or "",
        name=record.tool.name,
        version_id=record.toolVersionId or "",
        project_id=record.toolProjectId or "",
        type=record.tool.type
    )
    
    # 构建Agent信息
    agent_info = AgentInfo(
        id=record.agentCallerId or None,
        name_en=agent_caller_info.name_id if agent_caller_info else None,
        name=agent_caller_info.name if agent_caller_info else None,
        project_id=record.agentProjectId or None
    ) if agent_caller_info else None
    root_caller_info = UserInfo(
        id=record.rootUserId or None,
        username=record.rootCaller.username if record.rootCaller else None,
        email=record.rootCaller.email if record.rootCaller else None,
        firstname=record.rootCaller.first_name if record.rootCaller else None,
        lastname=record.rootCaller.last_name if record.rootCaller else None
    ) if root_caller_info else None
    chunks = []
    time_str = str(int(time.time()))
    for index, node in enumerate(string_chunking(summary)):
        chunk = ToolRecordChunk(
            _id=f"{record.id}_{ChunkFieldType.ATTENTION.value}_{time_str}_{index}",
            type=ChunkFieldType.ATTENTION,  # 摘要类型
            tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
            tool_info=tool_info,
            agent_info=agent_info,
            root_caller=root_caller_info,
            status=ToolCallStatus(record.status),
            intent=intent,  # 使用实际的 intent 字段
            chunk_sub_field_paths=[],
            chunk_index=index,  # 输出的索引为1
            content=node.get_content(),
            error=None,
            tags=[],
            workset_ids=workset_ids if workset_ids else [],
            message_action_ids=[],
            next_record_ids=[],
            pre_record_ids=[],
            metadata={},
            created_at=int(time_str),
            updated_at=int(time_str)
        )
        chunks.append(chunk)
    
    
    # 将chunk转为json并post至索引
    #获取工具记录索引
    tool_record_index = get_index(IndexType.ACTION)
    logger.debug(f"Indexing {[chunk.model_dump() for chunk in chunks]} attention chunks for ToolCallRecord ID {record.id}")
    # 添加至索引，统一 id -> _id
    docs = []
    for c in chunks:
        d = c.model_dump()
        if '_id' not in d and 'id' in d:
            d['_id'] = d.pop('id')
        docs.append(d)
    task = tool_record_index.add_documents(docs)
    wait_task(task)

    return chunks

def query_knowledge_record(
    prompt: str,
    setting_ids: List[str] = [],
    project_ids: List[str] = [],
    workset_ids: List[str] = [],
    top_k: int = 5,
    use_knn: bool = True,
    k_override: int | None = None,
    semantic_ratio: float = 1.0
):
    """
    查询知识记录（统一使用 Manticore SearchRequest 语法 + KNN 语义检索）。
    """
    knowledge_index = get_index(IndexType.KNOWLEDGE)
    # Build structured filter list (Manticore client will pass through)
    structured_filters = []
    if setting_ids:
        structured_filters.append({"equals": {"settings": setting_ids}})
    if project_ids:
        structured_filters.append({"equals": {"projects": project_ids}})
    if workset_ids:
        structured_filters.append({"equals": {"worksets": workset_ids}})
    final_k = k_override if k_override else top_k
    options = {
        'limit': final_k,
    }
    if structured_filters:
        options['filter'] = structured_filters
    # Include KNN only if enabled and prompt provided
    if use_knn and prompt:
        options['knn'] = {
            'var_field': 'content_vector',
            'k': final_k
        }
    # Attach semantic ratio (0..1). If ==1 and knn, we do pure vector search by sending '*' prompt (skip MATCH internally)
    options['semantic_ratio'] = semantic_ratio
    effective_prompt = '*' if (use_knn and semantic_ratio == 1) else prompt
    logger.info(f"Knowledge query prompt={prompt} effective_prompt={effective_prompt} use_knn={use_knn} k={final_k} semantic_ratio={semantic_ratio} options={options}")
    res = knowledge_index.search(effective_prompt, options)
    hits = res.get('hits', []) if isinstance(res, dict) else []
    return hits

def index_action_record(
        record: ToolCallRecord,
        fieldtype: ChunkFieldType,
        tool_name: str,
        tool_type: ToolType,
        data_schema: dict|None =None
        ) -> ToolRecordChunk:
    """
    解析单个工具调用记录，转换为 ToolRecordChunk（输出类型）。
    """
    root_caller_info = record.rootCaller
    agent_caller_info = record.agentCaller
    # 构建工具版本信息
    tool_info = ToolVersionInfo(
        name_id=record.toolNameId or "",
        name=tool_name,
        version_id=record.toolVersionId or "",
        project_id=record.toolProjectId or "",
        type=tool_type.value
    )
    
    # 构建Agent信息
    agent_info = AgentInfo(
        id=record.agentCallerId or None,
        name_en=agent_caller_info.name_id if agent_caller_info else None,
        name=agent_caller_info.name if agent_caller_info else None,
        project_id=record.agentProjectId or None
    ) if agent_caller_info else None
    root_caller_info = UserInfo(
        id=record.rootUserId or None,
        username=record.rootCaller.username if record.rootCaller else None,
        email=record.rootCaller.email if record.rootCaller else None,
        firstname=record.rootCaller.first_name if record.rootCaller else None,
        lastname=record.rootCaller.last_name if record.rootCaller else None
    ) if root_caller_info else None
    chunks = []
    if fieldtype == ChunkFieldType.OUTPUT:
        if record.error_message:
            chunk = ToolRecordChunk(
                _id=f"{record.id}_{ChunkFieldType.ERROR.value}_0_0",
                type=ChunkFieldType.ERROR,  # 输出类型
                tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                tool_info=tool_info,
                agent_info=agent_info,
                root_caller=root_caller_info,
                status=ToolCallStatus(record.status),
                intent=record.intent or "",  # 使用实际的 intent 字段
                chunk_sub_field_paths=[],
                chunk_index=0,  
                content=None,
                error=json.dumps(record.error_message, ensure_ascii=False) if record.error_message else None,
                tags=[],  # ToolCallRecord 模型中没有 tags 字段
                workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                next_record_ids=[],
                metadata={
                    "title": record.title,
                    "summary": record.summary,
                    "time_cost": record.time_cost,
                    "user_caller_id": record.userCallerId,
                },
                created_at=int(record.createdAt.timestamp()),
                updated_at=int(record.updatedAt.timestamp())
            )
            chunks = [chunk]
        else:
            data = record.result
            if not data_schema:
                raise ValueError("data_schema is required when indexing output records without error_message.")
            for index, node in enumerate(chunk_data_on_schema(data, data_schema)):
                chunk = ToolRecordChunk(
                    _id=f"{record.id}_{ChunkFieldType.OUTPUT.value}_0_{index}",
                    type=ChunkFieldType.OUTPUT,  # 输出类型
                    tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                    tool_info=tool_info,
                    agent_info=agent_info,
                    root_caller=root_caller_info,
                    status=ToolCallStatus(record.status),
                    intent=record.intent or "",  # 使用实际的 intent 字段
                    chunk_sub_field_paths=[],
                    chunk_index=index,  # 输出的索引为1
                    content=node.get_content(),
                    error=json.dumps(record.error_message, ensure_ascii=False) if record.error_message else None,
                    tags=[],  # ToolCallRecord 模型中没有 tags 字段
                    workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                    message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                    next_record_ids=[],
                    pre_record_ids=[],
                    metadata={},
                    created_at=int(record.createdAt.timestamp()),
                    updated_at=int(record.updatedAt.timestamp())
                )
                chunks.append(chunk)
    elif fieldtype == ChunkFieldType.INPUT:
        data = record.input
        if not data_schema:
            raise ValueError("data_schema is required when indexing input records.")
        for index, node in enumerate(chunk_data_on_schema(data, data_schema)):
            chunk = ToolRecordChunk(
                _id=f"{record.id}_{ChunkFieldType.INPUT.value}_0_{index}",
                type=ChunkFieldType.INPUT,  # 输入类型
                tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                tool_info=tool_info,
                agent_info=agent_info,
                root_caller=root_caller_info,
                status=ToolCallStatus(record.status),
                intent=record.intent or "",  # 使用实际的 intent 字段
                chunk_sub_field_paths=[],
                chunk_index=index,  # 输入的索引为0
                content=node.get_content(),
                error= None,
                tags=[],  # ToolCallRecord 模型中没有 tags 字段
                workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                next_record_ids=[],
                pre_record_ids=[],
                metadata={},
                created_at=int(record.createdAt.timestamp()),
                updated_at=int(record.updatedAt.timestamp())
            )
            chunks.append(chunk)
    elif fieldtype == ChunkFieldType.ERROR:
        if record.error_message:
            chunk = ToolRecordChunk(
                _id=f"{record.id}_{ChunkFieldType.ERROR.value}_0_0",
                type=ChunkFieldType.ERROR,  # 输出类型
                tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                tool_info=tool_info,
                agent_info=agent_info,
                root_caller=root_caller_info,
                status=ToolCallStatus(record.status),
                intent=record.intent or "",  # 使用实际的 intent 字段
                chunk_sub_field_paths=[],
                chunk_index=0,  
                content=None,
                error=json.dumps(record.error_message, ensure_ascii=False) if record.error_message else None,
                tags=[],  # ToolCallRecord 模型中没有 tags 字段
                workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                next_record_ids=[],
                metadata={
                    "title": record.title,
                    "summary": record.summary,
                    "time_cost": record.time_cost,
                    "user_caller_id": record.userCallerId,
                },
                created_at=int(record.createdAt.timestamp()),
                updated_at=int(record.updatedAt.timestamp())
            )
            chunks = [chunk]
    #获取工具记录索引
    tool_record_index = get_index(IndexType.ACTION)
    logger.debug(f"Indexing {[chunk.model_dump() for chunk in chunks]} chunks for ToolCallRecord ID {record.id}")
    # 添加至索引，统一 id -> _id
    docs = []
    for c in chunks:
        d = c.model_dump()
        if '_id' not in d and 'id' in d:
            d['_id'] = d.pop('id')
        docs.append(d)
    task = tool_record_index.add_documents(docs)
    wait_task(task)
    return chunks

def query_action_record(
    prompt: str,
    record_ids: List[str] = [],
    statuses: List[str] = [],
    intents: List[str] = [],
    tags: List[str] = [],
    workset_ids: List[str] = [],
    top_k: int = 5,
    use_knn: bool = True,
    k_override: int | None = None,
    semantic_ratio: float = 1.0
):
    """Query action records with optional semantic KNN retrieval."""
    action_index = get_index(IndexType.ACTION)
    structured_filters = []
    if record_ids:
        structured_filters.append({"equals": {"tool_call_record_id": record_ids}})
    if statuses:
        structured_filters.append({"equals": {"status": statuses}})
    if intents:
        structured_filters.append({"equals": {"intent": intents}})
    if tags:
        structured_filters.append({"equals": {"tags": tags}})
    if workset_ids:
        structured_filters.append({"equals": {"workset_ids": workset_ids}})
    final_k = k_override if k_override else top_k
    options = {'limit': final_k}
    if structured_filters:
        options['filter'] = structured_filters
    if use_knn and prompt:
        options['knn'] = {
            'var_field': 'content_vector',
            'k': final_k
        }
    options['semantic_ratio'] = semantic_ratio
    effective_prompt = '*' if (use_knn and semantic_ratio == 1) else prompt
    logger.info(f"Action query prompt={prompt} effective_prompt={effective_prompt} use_knn={use_knn} k={final_k} semantic_ratio={semantic_ratio} options={options}")
    res = action_index.search(effective_prompt, options)
    return res.get('hits', []) if isinstance(res, dict) else []

# ========== Manticore Search 索引初始化 ========== #
def init_manticore_indices():
    """
    初始化 Manticore Search 索引（action records, knowledge），如不存在则创建。
    """
    logger.info("Initializing Manticore Search indices...")
    try:
        init_action_index()
        init_knowledge_index()
    except Exception as e:
        logger.error(f"Error initializing Manticore Search indices: {e}")

if __name__ == "__main__":
    # 初始化 Manticore Search 索引
    init_manticore_indices()