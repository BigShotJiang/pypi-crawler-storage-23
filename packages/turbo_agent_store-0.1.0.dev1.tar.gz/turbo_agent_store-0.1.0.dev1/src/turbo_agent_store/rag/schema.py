from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, model_validator
from datetime import datetime
from prisma.models import ToolCallRecord, Workset
from prisma.enums import KnowledgeType, ToolCallStatus, FileType
from enum import Enum

class KnowledgeChunk(BaseModel):
    _id: str
    knowledge_id: str
    chunk_index: int
    content: str
    type: KnowledgeType
    file_type: Optional[FileType]|None = None  # 修正拼写 filte_type -> file_type
    mime_type:str|None = None
    name: str
    tags:List[str]  =   []  # 标签列表
    metadata: Optional[Dict[str, Any]] = None  # 元数据
    filename: Optional[str]|None = None  # 文件名
    setting_ids: List[str] = []
    project_ids: List[str] = []
    workset_ids: List[str] = []
    user_ids:List[str] = []
    created_at: int = int(datetime.now().timestamp())
    updated_at: int = int(datetime.now().timestamp())
    creatorId: str  # 创建者 ID

class ToolVersionInfo(BaseModel):
    name_id: str
    name: str
    version_id: str
    project_id: str
    type: str

class AgentInfo(BaseModel):
    id: str
    name_en: str
    name: str
    project_id: str

class UserInfo(BaseModel):
    id: str
    username: str
    email: str
    firstname: str
    lastname: str

# tool record 类型有 输入、输出、错误信息、压缩解读
class ChunkFieldType(str, Enum):
    INPUT = "input"
    OUTPUT = "output"
    ERROR = "error"
    ATTENTION = "attention"

class ToolRecordChunk(BaseModel):
    _id: str|None = None
    type: ChunkFieldType
    tool_call_record_id: str
    tool_info: ToolVersionInfo
    agent_info: AgentInfo|None = None
    root_caller: UserInfo
    status: ToolCallStatus
    intent: str
    chunk_sub_field_paths: List[str] = []
    chunk_index: int
    content: Optional[str] = None
    error: Optional[str] = None
    tags: List[str] = []  # 标签列表
    workset_ids: Optional[List[str]]= []  # 所属工作集 ID 列表
    message_action_ids: Optional[List[str]] = None  # 属于消息动作 ID
    next_record_ids: Optional[List[str]] = None  # 本条记录的输出用于下一个记录的输入 ID
    pre_record_ids: Optional[List[str]] = None  # 本条记录的输入来源于上一个记录的输出 ID
    metadata: Optional[Dict[str, Any]] = None  # 元数据
    created_at: int = int(datetime.now().timestamp())
    updated_at: int = int(datetime.now().timestamp())