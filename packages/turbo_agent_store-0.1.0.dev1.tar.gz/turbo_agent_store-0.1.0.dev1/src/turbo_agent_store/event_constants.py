# coding=utf-8

"""事件流相关常量。

与 docs/backend-refactor/event_design.md 与 store/job 设计文档保持一致。
"""

from __future__ import annotations

GLOBAL_LIFECYCLE_STREAM_KEY = "ta.result.lifecycle"


def trace_lifecycle_stream_key(trace_id: str) -> str:
    return f"ta.result.lifecycle.{trace_id}"
