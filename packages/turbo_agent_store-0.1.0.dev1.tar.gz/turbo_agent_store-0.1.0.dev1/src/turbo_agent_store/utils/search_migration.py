"""Manticore Search utility helpers (cleaned of Meilisearch migration logic)."""
from loguru import logger
from turbo_agent_store.settings import settings
from turbo_agent_store.rag.init_index_manticore import (
    init_action_index,
    init_knowledge_index,
    get_index,
    IndexType,
    update_action_record_index,
    parse_file,
    index_knowledge_file,
    update_knowledge_file_index,
    unbind_knowledge_file,
    index_action_record_attention,
    query_knowledge_record,
    query_action_record,
    index_action_record,
    init_action_index as init_search_indices,  # alias for compatibility
    check_tasks,
    wait_task,
    wait_tasks
)
USE_MANTICORE = True  # retained for compatibility with external checks

def validate_embedding_configuration():
    """Validate required embedding settings for Manticore (simplified)."""
    required = ['CHUNCK_MODEL', 'CHUNCK_MODEL_API_KEY', 'CHUNCK_MODEL_API_URL']
    missing = [name for name in required if not getattr(settings, name, None)]
    if missing:
        logger.error(f"Missing embedding settings: {missing}")
        return False
    return True

def migrate_data_to_manticore():
    logger.warning("migrate_data_to_manticore deprecated: Meilisearch support removed.")
    return False


def test_search_functionality():
    """
    Test basic search functionality to ensure the current search engine is working
    """
    logger.info("Testing Manticore search functionality")
    if not validate_embedding_configuration():
        logger.error("Embedding configuration validation failed")
        return False
    # Knowledge index
    try:
        knowledge_index = get_index(IndexType.KNOWLEDGE)
        result = knowledge_index.search("test", {"hitsPerPage": 1})
        logger.info(f"Knowledge search test: {len(result.get('hits', []))} results")
    except Exception as e:
        logger.error(f"Knowledge search test failed: {e}")
    # Action index
    try:
        action_index = get_index(IndexType.ACTION)
        result = action_index.search("test", {"hitsPerPage": 1})
        logger.info(f"Action search test: {len(result.get('hits', []))} results")
    except Exception as e:
        logger.error(f"Action search test failed: {e}")
    logger.info("Search functionality test completed")
    return True


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Search engine migration and testing utility")
    parser.add_argument("--migrate", action="store_true", help="Migrate data from Meilisearch to Manticore")
    parser.add_argument("--test", action="store_true", help="Test search functionality")
    parser.add_argument("--init", action="store_true", help="Initialize search indices")
    parser.add_argument("--validate-embedding", action="store_true", help="Validate embedding configuration")
    
    args = parser.parse_args()
    
    if args.migrate:
        migrate_data_to_manticore()
    elif args.test:
        test_search_functionality()
    elif args.init:
        init_search_indices()
    elif args.validate_embedding:
        if validate_embedding_configuration():
            print("✅ Embedding configuration is valid")
        else:
            print("❌ Embedding configuration is invalid")
    else:
        print("Use --migrate, --test, --init, or --validate-embedding")