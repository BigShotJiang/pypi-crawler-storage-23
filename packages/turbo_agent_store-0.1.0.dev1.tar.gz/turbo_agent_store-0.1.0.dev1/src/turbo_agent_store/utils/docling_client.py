from turbo_agent_store.settings import settings
import requests
from pathlib import Path
from typing import Any, Dict, Optional, Iterator, List, Tuple
import time
from loguru import logger
import json
import os
from docling_core.types import DoclingDocument

class DoclingClient:
    """Client for interacting with Docling conversion service.

    Provides both JSON-based conversion trigger (existing) and direct file
    multipart upload. Prefer ``convert_file`` for local files so the server
    receives the binary content instead of only a path that might be invalid
    remotely.
    """

    def __init__(self):
        self.base_url = settings.DOCLING_SERVER.rstrip("/")
        self.auth_header = {"X-Api-Key": f"{settings.DOCLING_API_KEY}"}
        # 未完成任务缓存: task_id -> 初始/最新状态信息
        self.tasks = {}

    def convert_files_async(
        self,
        file_paths: list[str],
        timeout: int = 30,
        do_formula_enrichment: bool = True,
        do_code_enrichment: bool = True,
        image_export_mode: str = "embedded"
    ) -> Dict[str, Any]:
        """调用异步批量转换接口 /v1/convert/file/async 并缓存任务信息。

        Args:
            file_paths: 本地文件路径列表.
            endpoint: 固定异步端点。
            timeout: 请求超时秒.
            do_formula_enrichment: 是否进行公式富化。
            do_code_enrichment: 是否进行代码富化。
        Returns: 任务初始响应 JSON。
        """
        endpoint = "/v1/convert/file/async"
        if not file_paths:
            raise ValueError("file_paths 不能为空")
        paths = [Path(fp) for fp in file_paths]
        for p in paths:
            if not p.is_file():
                raise FileNotFoundError(f"File not found: {p}")

        url = f"{self.base_url}{endpoint}" if not endpoint.startswith("http") else endpoint

        files_payload = [("files", (p.name, p.open("rb"), "application/octet-stream")) for p in paths]
        # 仅保留规定的两个标志位
        data: Dict[str, Any] = {
            "do_formula_enrichment": str(do_formula_enrichment).lower(),
            "do_code_enrichment": str(do_code_enrichment).lower(),
            "image_export_mode": image_export_mode,
            "to_formats":"json"
        }

        try:
            resp = requests.post(
                url,
                headers=self.auth_header,
                files=files_payload,
                data=data,
                timeout=timeout,
            )
        finally:
            for _, ft in files_payload:
                try:
                    ft[1].close()
                except Exception:
                    pass

        resp.raise_for_status()
        payload = resp.json()
        task_id = payload.get("task_id")
        if task_id:
            self.tasks[task_id] = payload  # 初始状态缓存
        return payload
    
    def wait_task(
        self,
        interval: float = 2.0,
        timeout: int = 600,
        success_status: Optional[set[str]] = None,
    ) -> Iterator[Dict[str, Any]]:
        """轮询当前 client 中已登记的所有任务, 成功后 yield document。

        Args:
            interval: 轮询间隔秒。
            timeout: 总超时时间秒。
            success_status: 认为成功的 task_status 集合, 默认 {"succeeded","success","completed","finished"}.

        Yields:
            每个已完成任务的 result['document'] 字段 (dict)。

        Raises:
            HTTPError: 状态/结果接口返回 4xx/5xx。
            TimeoutError: 超时仍未全部完成。
        """
        if success_status is None:
            # 新的状态集合: success|partial_success|skipped|failure
            # 其中 success 与 partial_success 视为可获取结果
            success_status = {"success", "partial_success"}
        if not self.tasks:
            return  # 没有任务, 直接结束 (空生成器)

        start = time.time()
        pending: set[str] = set(self.tasks.keys())
        while pending:
            now = time.time()
            if now - start > timeout:
                raise TimeoutError(f"等待任务超时: {sorted(pending)}")

            finished_this_round: list[str] = []
            for task_id in list(pending):
                status_url = f"{self.base_url}/v1/status/poll/{task_id}"
                status_resp = requests.get(status_url, headers=self.auth_header, timeout=30)
                if status_resp.status_code >= 400:
                    status_resp.raise_for_status()
                status_json = status_resp.json()
                self.tasks[task_id] = status_json  # 更新状态

                t_status = (status_json.get("task_status") or status_json.get("status") or "").lower()
                # 判定成功: status 在 success_status 或 processed == docs 并且 docs>0
                meta = status_json.get("task_meta") or {}
                num_docs = meta.get("num_docs") or 0
                num_processed = meta.get("num_processed") or 0
                success_by_meta = num_docs > 0 and num_processed >= num_docs
                if (t_status in success_status) or success_by_meta:
                    # 获取结果
                    result_url = f"{self.base_url}/v1/result/{task_id}"
                    result_resp = requests.get(result_url, headers=self.auth_header, timeout=60)
                    if result_resp.status_code >= 400:
                        result_resp.raise_for_status()
                    result_json = result_resp.json()
                    # logger.info(f"任务完成 task_id={task_id}: {result_json}")
                    document = result_json.get("document") or result_json
                    finished_this_round.append(task_id)
                    yield document
                elif t_status == "failure":
                    finished_this_round.append(task_id)
                    raise RuntimeError(f"任务失败 task_id={task_id}: {status_json}")
                elif t_status == "skipped":
                    # 跳过: 直接标记完成，不抛错，不取结果
                    finished_this_round.append(task_id)
            for tid in finished_this_round:
                pending.discard(tid)
                self.tasks.pop(tid, None)
            if pending:
                time.sleep(interval)


def _ensure_unique(base_path: Path) -> Path:
    """Ensure a unique file path by appending numeric suffix if needed."""
    if not base_path.exists():
        return base_path
    stem, suffix = base_path.stem, base_path.suffix
    parent = base_path.parent
    i = 1
    while True:
        candidate = parent / f"{stem}_{i}{suffix}"
        if not candidate.exists():
            return candidate
        i += 1


def _extract_basename_from_result(item: Dict[str, Any]) -> Optional[str]:
    """Try to infer original filename stem from docling result item."""
    # Common fields to try
    candidates = [
        item.get("file_name"),
        item.get("filename"),
        item.get("name"),
    ]
    # Sometimes source path-like fields exist
    if not any(candidates):
        path_like = (
            item.get("source_path")
            or item.get("original_path")
            or item.get("file_path")
            or item.get("path")
            or item.get("source")
        )
        if path_like:
            try:
                return Path(str(path_like)).stem
            except Exception:
                pass
    for v in candidates:
        if v:
            try:
                return Path(str(v)).stem
            except Exception:
                return os.path.splitext(str(v))[0]
    return None


def convert_path_and_save(
    input_path: str | os.PathLike,
    output_dir: str | os.PathLike,
    batch_size: int = 8,
    timeout: int = 300,
    do_formula_enrichment: bool = True,
    do_code_enrichment: bool = True,
) -> List[Dict[str, str]]:
    """Traverse files under input_path, submit to Docling, and save .md and .json.

    Args:
        input_path: File or directory path to process.
        output_dir: Directory to write outputs. Will be created if missing.
        batch_size: Number of files per async docling request.
        timeout: Overall timeout seconds for all tasks.
        do_formula_enrichment: Whether to enable formula enrichment.
        do_code_enrichment: Whether to enable code enrichment.

    Returns:
        A list of dicts with keys: 'basename', 'md_path', 'json_path'.
    """
    in_path = Path(input_path)
    if not in_path.exists():
        raise FileNotFoundError(f"Input path not found: {in_path}")
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Collect files
    if in_path.is_file():
        files = [in_path]
        base_input_dir = in_path.parent
    else:
        files = [p for p in in_path.rglob("*") if p.is_file()]
        base_input_dir = in_path
    if not files:
        logger.warning(f"No files found under: {in_path}")
        return []

    results: List[Dict[str, str]] = []
    overall_start = time.time()

    # Process files strictly one-by-one
    for file_path in files:
        # Respect overall timeout budget across all files
        elapsed = time.time() - overall_start
        remaining = 600
        if timeout and remaining <= 0:
            raise TimeoutError("convert_path_and_save exceeded overall timeout before processing all files.")

        client = DoclingClient()  # fresh client per file to ensure isolation
        task_info = client.convert_files_async(
            file_paths=[str(file_path)],
            timeout=30,
            do_formula_enrichment=do_formula_enrichment,
            do_code_enrichment=do_code_enrichment,
        )
        logger.info(f"Docling task started for file: {file_path} -> {task_info}")
        try:
            docs = client.wait_task(interval=2.0, timeout=remaining)
        except Exception as e:
            logger.error(f"Docling task failed or timed out for file {file_path}: {e}")
            continue
        for doc in docs:
            # doc may be a wrapper or a single document item
            items: List[Dict[str, Any]] = []
            if isinstance(doc, dict) and "documents" in doc and isinstance(doc["documents"], list):
                items = [d for d in doc["documents"] if isinstance(d, dict)]
            elif isinstance(doc, list):
                items = [d for d in doc if isinstance(d, dict)]
            elif isinstance(doc, dict):
                # Single
                if "json_content" in doc or "json" in doc:
                    items = [doc]
                else:
                    # Sometimes the actual doc might be nested under 'document'
                    inner = doc.get("document")
                    if isinstance(inner, dict):
                        items = [inner]
                    elif isinstance(inner, list):
                        items = [d for d in inner if isinstance(d, dict)]

            for item in items:
                # Determine filename stem
                basename = _extract_basename_from_result(item)
                if not basename:
                    basename = Path(file_path).stem

                # Calculate relative path to preserve directory structure
                try:
                    rel_path = Path(file_path).relative_to(base_input_dir)
                    output_subdir = out_dir / rel_path.parent
                    output_subdir.mkdir(parents=True, exist_ok=True)
                except ValueError:
                    # Fallback if relative_to fails
                    output_subdir = out_dir

                # Prepare JSON string for DoclingDocument
                dl_json_obj = item.get("json_content") or item.get("json") or item
                json_str: str
                if isinstance(dl_json_obj, str):
                    json_str = dl_json_obj
                else:
                    try:
                        json_str = json.dumps(dl_json_obj)
                    except Exception:
                        # Fallback: dump the item itself
                        json_str = json.dumps(item)

                # Validate to DoclingDocument and export markdown
                try:
                    docling_doc = DoclingDocument.model_validate_json(json_str)
                    markdown_content = docling_doc.export_to_markdown()
                    raw_markdown_content = docling_doc.export_to_markdown(image_mode="embedded")
                except Exception as e:
                    logger.error(f"Failed to build DoclingDocument for {basename}: {e}")
                    # Still save raw JSON for troubleshooting
                    markdown_content = ""

                # Save outputs with preserved directory structure
                md_path = _ensure_unique(output_subdir / f"{basename}.md")
                raw_md_path = _ensure_unique(output_subdir / f"{basename}_raw.md")
                json_path = _ensure_unique(output_subdir / f"{basename}_doclin_doc.json")

                try:
                    if markdown_content:
                        md_path.write_text(markdown_content, encoding="utf-8")
                    if raw_markdown_content:
                        raw_md_path.write_text(raw_markdown_content, encoding="utf-8")
                    # Always persist JSON
                    with json_path.open("w", encoding="utf-8") as f:
                        if isinstance(dl_json_obj, str):
                            # Try to pretty print string JSON
                            try:
                                f.write(json.dumps(json.loads(dl_json_obj), ensure_ascii=False, indent=2))
                            except Exception:
                                f.write(dl_json_obj)
                        else:
                            json.dump(dl_json_obj, f, ensure_ascii=False, indent=2)
                    logger.info(f"Saved outputs: md={md_path}, json={json_path}")
                    results.append({
                        "basename": basename,
                        "md_path": str(md_path),
                        "json_path": str(json_path),
                    })
                except Exception as e:
                    logger.error(f"Failed saving outputs for {basename}: {e}")

        # At this point, the single file's task has finished (wait_task drained), continue to next

    return results