from urllib.parse import quote_plus
from typing import Any, Dict, List, Union
from enum import Enum
import json

def convert_to_query_params(
    obj: Union[Dict, List, str, int, float, bool],
    parent_key: str = ""
) -> List[str]:
    """递归将字典/列表转换为 URL 查询参数列表"""
    items = []
    
    if isinstance(obj, (list, tuple)):
        for idx, value in enumerate(obj):
            new_key = f"{parent_key}[]" if parent_key else ""
            items.extend(convert_to_query_params(value, new_key))
    elif isinstance(obj, dict):
        for key, value in obj.items():
            new_key = f"{parent_key}[{key}]" if parent_key else key
            items.extend(convert_to_query_params(value, new_key))
    else:
        # 处理布尔值和 None
        value = "true" if obj is True else "false" if obj is False else ""
        value = str(value) if obj is not None else ""
        
        # 对特殊类型进行 JSON 序列化（模仿 JS 行为）
        if isinstance(obj, (dict, list, tuple)):
            value = json.dumps(obj, separators=(',', ':'))
            
        # URL 编码（模仿 JS 的 encodeURIComponent）
        encoded_value = quote_plus(
            str(value),
            safe="-._~",
            encoding="utf-8",
            errors="strict"
        )
        
        items.append(f"{parent_key}={encoded_value}" if parent_key else encoded_value)
    
    return items

def build_query_string(query_dict: Dict) -> str:
    """将字典转换为 URL 查询字符串（类似 JS URLSearchParams）"""
    if not query_dict:
        return ""
    
    # 处理顶层键值对
    params = []
    for key, value in query_dict.items():
        # 处理数组和对象（展开形式）
        if isinstance(value, (list, tuple)):
            for item in value:
                params.append(f"{key}={quote_plus(str(item))}")
        elif isinstance(value, dict):
            # 递归处理嵌套对象
            nested_params = convert_to_query_params({key: value})
            params.extend(nested_params)
        else:
            # 处理基本类型
            encoded_value = quote_plus(
                str(value),
                safe="-._~",
                encoding="utf-8",
                errors="strict"
            )
            params.append(f"{key}={encoded_value}")
    
    return "&".join(params)