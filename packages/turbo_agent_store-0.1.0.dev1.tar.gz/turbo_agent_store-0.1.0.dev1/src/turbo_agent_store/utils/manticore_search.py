import time
import json
import hashlib
from typing import List, Dict, Any, Optional, Union
from loguru import logger
from manticoresearch import ApiClient, Configuration, IndexApi, SearchApi, UtilsApi
from manticoresearch.exceptions import ApiException
import numpy as np
from openai import OpenAI
from turbo_agent_store.settings import settings
from manticoresearch.models.search_request import SearchRequest
from manticoresearch.models.knn_query import KnnQuery
from manticoresearch.models.query_filter import QueryFilter
from manticoresearch.models.insert_document_request import InsertDocumentRequest
from manticoresearch.models.search_query import SearchQuery
from manticoresearch.models.highlight import Highlight
from manticoresearch.models.replace_document_request import ReplaceDocumentRequest

class ManticoreSearchClient:
    """Manticore Search client wrapper using official ApiClient context pattern."""

    def __init__(self, host: str = None, api_key: str = None):
        self.host = host or getattr(settings, 'MANTICORE_HOST', 'http://127.0.0.1:9308')
        self.api_key = api_key or getattr(settings, 'MANTICORE_API_KEY', '')
        config = Configuration()
        config.host = self.host
        if self.api_key:
            config.api_key = {'ApiKeyAuth': self.api_key}
        # Hold configuration; lazily create ApiClient per call (with 'with' pattern) when needed.
        self._config = config
        self.embedding_client = None
        self.template_map: Dict[str, str] = {}
        self.searchable_map: Dict[str, List[str]] = {}
        # Cache for external_id -> internal numeric id per index
        self.id_cache: Dict[str, Dict[str, int]] = {}
        if hasattr(settings, 'CHUNCK_MODEL_API_KEY') and getattr(settings, 'CHUNCK_MODEL_API_KEY'):
            self.embedding_client = OpenAI(
                api_key=settings.CHUNCK_MODEL_API_KEY,
                base_url=settings.CHUNCK_MODEL_API_URL
            )

    def set_template(self, index_name: str, template: str):
        """Set document template for an index"""
        self.template_map[index_name] = template
    
    def set_searchable_attributes(self, index_name: str, searchable: List[str]):
        """Register searchable attributes (not persisted in Manticore)."""
        self.searchable_map[index_name] = searchable

    # --- Template rendering (Mustache-like {{doc.field}} / dotted paths) ---
    def _render_template(self, template: str, doc: Dict[str, Any]) -> str:
        """Render a simple mustache-style template with placeholders like:
        {{doc.field}}, {{ doc.nested.value }}, {{doc.tool_info.name}}
        Dotted paths are resolved against nested dicts/lists. Complex (dict/list) values
        are JSON-dumped (UTF-8) for readability.
        This avoids using Python str.format so that braces in Chinese copy are safe.
        """
        import re

        def resolve(path: str):
            cur: Any = doc
            for part in path.split('.'):
                if isinstance(cur, dict):
                    cur = cur.get(part, '')
                else:
                    return ''
            if isinstance(cur, (dict, list)):
                try:
                    return json.dumps(cur, ensure_ascii=False)
                except Exception:
                    return str(cur)
            if cur is None:
                return ''
            return str(cur)

        pattern = re.compile(r"\{\{\s*doc\.([a-zA-Z0-9_\.]+)\s*\}\}")
        return pattern.sub(lambda m: resolve(m.group(1)), template)

    def get_template(self, index_name: str) -> Optional[str]:
        return self.template_map.get(index_name)
    
    def generate_embedding(self, text: str, model: str = None) -> List[float]:
        """Generate embedding for text using chunk embedding API (OpenAI compatible)"""
        if not self.embedding_client:
            dim = int(getattr(settings, 'EMBEDDING_DIM', 1024))
            logger.warning("Embedding client not configured, returning zero vector")
            return [0.0] * dim  # Default dimension
        
        # Use the configured chunk model or default
        model = model or getattr(settings, 'CHUNCK_MODEL', 'text-embedding-3-small')
        
        try:
            response = self.embedding_client.embeddings.create(
                model=model,
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            logger.error(f"Error generating embedding with chunk API: {e}")
            dim = int(getattr(settings, 'EMBEDDING_DIM', 1024))
            return [0.0] * dim
    
    def generate_embeddings_batch(self, texts: List[str], model: str = None) -> List[List[float]]:
        """Generate embeddings for multiple texts in batch using chunk embedding API"""
        if not self.embedding_client:
            dim = int(getattr(settings, 'EMBEDDING_DIM', 1024))
            logger.warning("Embedding client not configured, returning zero vectors")
            return [[0.0] * dim] * len(texts)
        
        # Use the configured chunk model or default
        model = model or getattr(settings, 'CHUNCK_MODEL', 'text-embedding-3-small')
        
        try:
            response = self.embedding_client.embeddings.create(
                model=model,
                input=texts
            )
            return [data.embedding for data in response.data]
        except Exception as e:
            logger.error(f"Error generating batch embeddings with chunk API: {e}")
            dim = int(getattr(settings, 'EMBEDDING_DIM', 1024))
            return [[0.0] * dim] * len(texts)
    
    def create_index(self, index_name: str, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new Manticore index with given schema"""
        try:
            # Build CREATE TABLE statement
            fields = []
            vector_fields = []
            
            for field_name, field_config in schema.items():
                ftype = field_config.get('type')
                if ftype == 'text':
                    fields.append(f"{field_name} text")
                elif ftype == 'string':
                    fields.append(f"{field_name} string")
                elif ftype == 'integer':
                    fields.append(f"{field_name} int")
                elif ftype == 'float':
                    fields.append(f"{field_name} float")
                elif ftype == 'json':
                    fields.append(f"{field_name} json")
                elif ftype in ('vector','float_vector'):
                    # Unified handling for vector/float_vector schema entries (Manticore syntax)
                    dimension = field_config.get('knn_dims') or field_config.get('dimension') or int(getattr(settings, 'EMBEDDING_DIM', 1024))
                    knn_type = field_config.get('knn_type', 'hnsw')
                    similarity = field_config.get('hnsw_similarity', field_config.get('knn_hnsw_similarity', 'cosine'))
                    quantization = field_config.get('quantization') or field_config.get('knn_quantization')
                    vec_parts = [
                        f"{field_name} float_vector",
                        f"knn_type='{knn_type}'",
                        f"knn_dims='{int(dimension)}'",
                        f"hnsw_similarity='{similarity}'"
                    ]
                    if quantization:
                        vec_parts.append(f"quantization='{quantization}'")
                    vector_fields.append(' '.join(vec_parts))
            
            # Combine all fields
            all_fields = fields + vector_fields
            
            sql = f"CREATE TABLE {index_name} ({', '.join(all_fields)})"
            vector_defs = [f for f in all_fields if 'float_vector' in f]
            logger.info(f"Creating index with SQL: {sql} | Vector fields: {vector_defs}")
            if not any('content_vector' in f for f in all_fields):
                logger.warning(f"Schema for {index_name} missing content_vector after build: schema={schema}")
            
            # Execute the CREATE TABLE command
            with ApiClient(self._config) as api_client:
                utils_api = UtilsApi(api_client)
                result = utils_api.sql(sql)
                if getattr(settings, 'MANTICORE_LOG_DESCRIBE', False):
                    try:
                        desc = utils_api.sql(f"DESCRIBE {index_name}")
                        logger.debug(f"DESCRIBE {index_name} => {desc}")
                    except Exception as de:
                        logger.debug(f"DESCRIBE failed for {index_name}: {de}")
            
            return {"task_uid": int(time.time()), "status": "succeeded", "index_name": index_name}
            
        except ApiException as e:
            if "already exists" in str(e):
                logger.info(f"Index {index_name} already exists")
                return {"task_uid": int(time.time()), "status": "succeeded", "index_name": index_name}
            logger.error(f"Error creating index {index_name}: {e}")
            raise
    
    def get_index(self, index_name: str):
        """Check if index exists via DESCRIBE; return wrapper."""
        try:
            with ApiClient(self._config) as api_client:
                utils_api = UtilsApi(api_client)
                desc = utils_api.sql(f"DESCRIBE {index_name}")
                if getattr(settings, 'MANTICORE_LOG_DESCRIBE', False):
                    logger.debug(f"DESCRIBE {index_name} => {desc}")
            return ManticoreIndex(index_name, self)
        except ApiException as e:
            if "no such table" in str(e).lower() or "doesn't exist" in str(e).lower():
                raise IndexNotFoundError(f"Index {index_name} not found")
            raise
    
    def index(self, index_name: str):
        return ManticoreIndex(index_name, self)
    
    def delete_index(self, index_name: str):
        try:
            with ApiClient(self._config) as api_client:
                utils_api = UtilsApi(api_client)
                utils_api.sql(f"DROP TABLE {index_name}")
            return {"task_uid": int(time.time()), "status": "succeeded"}
        except ApiException as e:
            logger.error(f"Error deleting index {index_name}: {e}")
            raise
    
    def get_tasks(self):
        """Mock task management for compatibility"""
        return {"results": []}
    
    def get_task(self, task_uid: int):
        """Mock task status for compatibility"""
        return {"task_uid": task_uid, "status": "succeeded", "error": None}


class ManticoreIndex:
    """Manticore index operations wrapper (uses per-call ApiClient context)."""

    def __init__(self, index_name: str, parent_client: ManticoreSearchClient):
        self.index_name = index_name
        self.parent_client = parent_client
    
    def add_documents(self, documents: List[Dict[str, Any]], primary_key: str = "_id", bulk: bool = False) -> Dict[str, Any]:
        """Add documents.
        - Default: official InsertDocumentRequest per doc (schema validation)
        - bulk=True: attempt single SQL multi-value insert for speed (skips SDK validation)
        """
        if not documents:
            return {"task_uid": int(time.time()), "status": "succeeded", "details": {"indexedDocuments": 0}}
        template = self.parent_client.get_template(self.index_name)
        # Prepare processed docs with embedding first
        processed: List[Dict[str, Any]] = []
        for doc in documents:
            processed_doc = doc.copy()
            # Normalize id -> _id
            if '_id' not in processed_doc and 'ext_id' in processed_doc:
                processed_doc['_id'] = processed_doc.pop('ext_id')
            if '_id' not in processed_doc and 'id' in processed_doc:
                processed_doc['_id'] = processed_doc.pop('id')
            # Render template (mustache style) if provided
            if template:
                try:
                    doc_str = self.parent_client._render_template(template, processed_doc)
                except Exception as e:
                    logger.warning(f"Template rendering failed: {e}, fallback to content field")
                    doc_str = processed_doc.get('content', '')
            else:
                doc_str = processed_doc.get('content', '')
            logger.info(f"Generating embedding for doc id={processed_doc.get('_id','<no-id>')} content length={len(doc_str)}")
            logger.info(f"Document snippet: {doc_str[:100]}{'...' if len(doc_str)>100 else ''}")
            processed_doc['content_vector'] = self.parent_client.generate_embedding(doc_str)
            processed.append(processed_doc)
        if bulk and len(processed) > 1:
            try:
                # Build multi insert SQL (best-effort). Only primitive + vector handled; lists/dicts JSON dumped.
                columns = list(processed[0].keys())
                value_rows = []
                for doc in processed:
                    vals = []
                    for c in columns:
                        v = doc.get(c)
                        if isinstance(v, str):
                            vals.append(f"'{v.replace("'", "''")}'")
                        elif isinstance(v, (list, dict)) and c != 'content_vector':
                            j = json.dumps(v, ensure_ascii=False).replace("'", "''")
                            vals.append(f"'{j}'")
                        elif isinstance(v, list):  # vector (shouldn't reach because of above, but kept)
                            vec = ','.join(map(str, v))
                            vals.append(f"({vec})")
                        elif v is None:
                            vals.append("NULL")
                        else:
                            vals.append(str(v))
                    value_rows.append(f"({','.join(vals)})")
                sql = f"INSERT INTO {self.index_name} ({','.join(columns)}) VALUES {','.join(value_rows)}"
                with ApiClient(self.parent_client._config) as api_client:
                    utils_api = UtilsApi(api_client)
                    utils_api.sql(sql)
                return {"task_uid": int(time.time()), "status": "succeeded", "details": {"indexedDocuments": len(processed), "mode": "bulk-sql"}}
            except Exception as e:
                logger.warning(f"Bulk insert failed, falling back to per-doc insert: {e}")
        # Fallback per-doc official insertion
        try:
            with ApiClient(self.parent_client._config) as api_client:
                index_api = IndexApi(api_client)
                success = 0
                for doc in processed:
                    insert_req = InsertDocumentRequest(table=self.index_name, doc=doc)
                    try:
                        index_api.insert(insert_req)
                        success += 1
                    except ApiException as api_e:
                        msg = str(api_e)
                        if "unknown column" in msg.lower():
                            import re
                            m = re.search(r"unknown column: '?`?([a-zA-Z0-9_]+)`?'?", msg) or re.search(r"unknown column: '([^']+)'", msg)
                            unknown = m.group(1) if m else '<unparsed>'
                            logger.error(f"Schema mismatch: unknown column '{unknown}' when inserting doc _id={doc.get('_id')}. Refusing to mutate document. Update index schema instead.")
                            raise ManticoreApiError(f"Unknown column '{unknown}' for index {self.index_name}. Update schema.")
                        # re-raise other errors
                        raise
            return {"task_uid": int(time.time()), "status": "succeeded", "details": {"indexedDocuments": success, "mode": "per-doc"}}
        except Exception as e:
            logger.error(f"Error adding documents to {self.index_name} via IndexApi: {e}")
            raise
    
    def _resolve_internal_id(self, external_id: str) -> Optional[int]:
        """Lookup internal numeric doc id by searching stored '_id' field (string). Returns None if not found."""
        try:
            with ApiClient(self.parent_client._config) as api_client:
                search_api = SearchApi(api_client)
                query = SearchQuery(query_string=f"@_id {external_id}")
                req = SearchRequest(table=self.index_name, query=query, limit=1)
                resp = search_api.search(req)
            hits = resp.get('hits', {}).get('hits', [])
            if hits:
                internal = hits[0].get('_id')
                cache = self.parent_client.id_cache.setdefault(self.index_name, {})
                cache[external_id] = internal
                return internal
        except Exception as e:
            logger.debug(f"Internal id resolution failed for {external_id}: {e}")
        return None

    def partial_replace_document(self, external_id: str, fields: Dict[str, Any]) -> bool:
        """Perform a partial replace using official API by external string id (best-effort)."""
        try:
            # Try cache first
            internal_id = self.parent_client.id_cache.get(self.index_name, {}).get(external_id)
            if internal_id is None:
                internal_id = self._resolve_internal_id(external_id)
            if internal_id is None:
                logger.warning(f"Cannot partial_replace: no internal id found for external id={external_id}")
                return False
            # Re-embed if content provided
            if 'content' in fields and fields['content']:
                fields['content_vector'] = self.parent_client.generate_embedding(fields['content'])
            with ApiClient(self.parent_client._config) as api_client:
                index_api = IndexApi(api_client)
                replace_req = {"doc": fields}
                index_api.partial_replace(self.index_name, internal_id, replace_req)
            return True
        except Exception as e:
            logger.error(f"partial_replace failed for {external_id}: {e}")
            return False

    def update_documents(self, documents: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Update documents preferring partial_replace; fallback to SQL when needed."""
        updated = 0
        fallback = 0
        try:
            for doc in documents:
                ext_id = doc.get('_id') or doc.get('ext_id') or doc.get('id')
                if not ext_id:
                    continue
                fields = {k: v for k, v in doc.items() if k not in ('id','ext_id','_id')}
                # Attempt partial replace (small field set heuristic)
                if self.partial_replace_document(ext_id, fields):
                    updated += 1
                    continue
                # Fallback to SQL update path
                logger.warning(f"Falling back to SQL update for {ext_id}")
                updates = []
                if 'content' in fields and fields['content']:
                    fields['content_vector'] = self.parent_client.generate_embedding(fields['content'])
                for key, value in fields.items():
                    if isinstance(value, str):
                        updates.append(f"{key} = '{value.replace(chr(39), chr(39)+chr(39))}'")
                    elif isinstance(value, (list, dict)) and key != 'content_vector':
                        updates.append(f"{key} = '{json.dumps(value, ensure_ascii=False)}'")
                    elif isinstance(value, list):
                        vector_str = ','.join(map(str, value))    
                        updates.append(f"{key} = ({vector_str})")
                    elif value is None:
                        updates.append(f"{key} = NULL")
                    else:
                        updates.append(f"{key} = {value}")
                if updates:
                    with ApiClient(self.parent_client._config) as api_client:
                        utils_api = UtilsApi(api_client)
                        sql = f"UPDATE {self.index_name} SET {','.join(updates)} WHERE _id = '{ext_id}'"
                        utils_api.sql(sql)
                    fallback += 1
            return {"task_uid": int(time.time()), "status": "succeeded", "details": {"partial_replaced": updated, "sql_fallback": fallback}}
        except Exception as e:
            logger.error(f"Error updating documents in {self.index_name}: {e}")
            raise
    def search(self, query: Optional[str] = None, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Unified search using SearchRequest and searchable attribute list."""
        options = options or {}
        table_name = self.index_name
        # Official SDK model expects 'table' field.
        search_request: Dict[str, Any] = {"table": table_name}
        semantic_ratio = options.get('semantic_ratio')
        knn_opts_preview = options.get('knn')
        # Hybrid path
        if semantic_ratio is not None and 0 < semantic_ratio < 1 and knn_opts_preview and query and query != '*':
            return self._hybrid_search(query, options, semantic_ratio)
        skip_text_match = bool(knn_opts_preview) and semantic_ratio == 1
        limit = options.get('hitsPerPage', options.get('limit', 20))
        offset = options.get('offset', 0)
        search_request['limit'] = limit
        if offset:
            search_request['offset'] = offset
        if query and query != '*' and not skip_text_match:
            searchable = self.parent_client.searchable_map.get(self.index_name)
            if searchable:
                safe_q = query.replace("'", "''")
                field_list = ','.join([f for f in searchable if f != 'content_vector'])
                search_request['query'] = {"query_string": f"@({field_list}) {safe_q}"}
            else:
                search_request['query'] = {"query_string": query}
        if 'filter' in options and options['filter']:
            search_request['filter'] = options['filter']
        knn_opts = options.get('knn')
        if knn_opts:
            knn_field = knn_opts.get('var_field', 'content_vector')
            k = knn_opts.get('k', limit)
            qv = knn_opts.get('query_vector')
            if not qv and query and query != '*':
                qv = self.parent_client.generate_embedding(query)
            if qv:
                search_request['knn'] = {'field': knn_field, 'k': k, 'query_vector': qv}
        for key in ['sort','highlight','aggs','expressions','max_matches','source','track_scores','profile']:
            if key in options:
                search_request[key] = options[key]
        logger.debug(f"Executing Manticore SearchRequest: {search_request}")
        try:
            with ApiClient(self.parent_client._config) as api_client:
                api = SearchApi(api_client)
                try:
                    model_req = SearchRequest(**search_request)
                    result = api.search(model_req)
                except Exception:
                    result = api.search(search_request)
            # --- Robust unwrap for SearchResponse objects (SDK model) or dicts ---
            def _unwrap(res):
                # Convert SDK response to a plain dict if needed
                if isinstance(res, dict):
                    return res
                if hasattr(res, 'to_dict'):
                    try:
                        return res.to_dict()
                    except Exception:
                        pass
                # Fallback: build dict from known attributes
                data = {}
                for attr in ['hits', 'took', 'time', 'time_ms']:
                    if hasattr(res, attr):
                        data[attr] = getattr(res, attr)
                return data
            result_dict = _unwrap(result)
            hits_section = result_dict.get('hits', {}) if isinstance(result_dict.get('hits', {}), dict) else {}
            # Some SDK versions structure as {'hits': {'hits': [...], 'total': X}}
            hits_raw = hits_section.get('hits', []) if isinstance(hits_section, dict) else []
            total_hits = hits_section.get('total', 0) if isinstance(hits_section, dict) else 0
            took = result_dict.get('took') or result_dict.get('time') or result_dict.get('time_ms') or 0
            docs = []
            for h in hits_raw:
                if isinstance(h, dict):
                    src = h.get('_source') or {}
                else:
                    # SDK hit model? attempt attribute access
                    src = getattr(h, '_source', {}) or {}
                    if hasattr(src, 'to_dict'):
                        try:
                            src = src.to_dict()
                        except Exception:
                            src = {}
                if '_id' in src and 'id' not in src:
                    src['id'] = src['_id']
                docs.append(src)
            return {
                'hits': docs,
                'estimatedTotalHits': total_hits,
                'processingTimeMs': took,
                'query': query
            }
        except Exception as e:
            logger.error(f"Manticore search error: {e}")
            return {'hits': [], 'estimatedTotalHits': 0, 'processingTimeMs': 0, 'query': query}

    def _hybrid_search(self, query: str, options: Dict[str, Any], semantic_ratio: float) -> Dict[str, Any]:
        """Perform dual search (text + vector) and fuse scores with linear weighting.
        fused = (semantic_ratio * vector_norm) + ((1 - semantic_ratio) * text_norm)
        """
        limit = options.get('hitsPerPage', options.get('limit', 20))
        # Build text-only options
        text_opts = {k: v for k, v in options.items() if k != 'knn'}
        vector_opts = dict(options)
        # Force pure vector: pass '*' to trigger skip text inside normal path
        vector_opts['semantic_ratio'] = 1
        # Execute text search (no knn)
        text_res = self.search(query, text_opts)  # recursion path without hybrid since knn removed
        # Execute vector search (pure vector)
        vector_res = self.search('*', vector_opts)
        # Extract raw hits with optional scores (we lost _score earlier). Need rerun low-level to capture _score.
        # To avoid refactor, we re-query using internal helper capturing _score.
        text_hits_raw = self._low_level_hits(query, text_opts, include_text=True)
        vector_hits_raw = self._low_level_hits(query, options, include_text=False)  # original options includes knn
        # Score normalization
        def norm(scores: List[float]) -> Dict[str, float]:
            if not scores:
                return {}
            mn = min(scores)
            mx = max(scores)
            if mx - mn == 0:
                return {i: 1.0 for i in range(len(scores))}
            return {i: (s - mn)/(mx - mn) for i, s in enumerate(scores)}
        text_scores = [h.get('_score', 0.0) for h in text_hits_raw]
        vec_scores = [h.get('_score', 0.0) for h in vector_hits_raw]
        text_norm_map = norm(text_scores)
        vec_norm_map = norm(vec_scores)
        fused: Dict[str, Dict[str, Any]] = {}
        def add_hits(hits_raw, norm_map, weight, is_vector):
            for idx, h in enumerate(hits_raw):
                src = h.get('_source', {})
                doc_id = src.get('_id') or src.get('id') or h.get('_id') or f"_anon_{idx}_{'v' if is_vector else 't'}"
                if '_id' in src and 'id' not in src:
                    src['id'] = src['_id']
                entry = fused.setdefault(doc_id, {'_source': h.get('_source', {}).copy(), '_text':0.0,'_vec':0.0})
                if is_vector:
                    entry['_vec'] = norm_map.get(idx,0.0)
                else:
                    entry['_text'] = norm_map.get(idx,0.0)
        add_hits(text_hits_raw, text_norm_map, 1 - semantic_ratio, False)
        add_hits(vector_hits_raw, vec_norm_map, semantic_ratio, True)
        # Compute fused score
        fused_list = []
        for doc_id, data in fused.items():
            fscore = semantic_ratio * data['_vec'] + (1 - semantic_ratio) * data['_text']
            src = data['_source']
            src['_fused_score'] = fscore
            src['_vec_score_norm'] = data['_vec']
            src['_text_score_norm'] = data['_text']
            fused_list.append(src)
        fused_list.sort(key=lambda d: d.get('_fused_score', 0), reverse=True)
        fused_list = fused_list[:limit]
        return {
            'hits': fused_list,
            'estimatedTotalHits': len(fused_list),
            'processingTimeMs': 0,
            'query': query,
            'hybrid': True,
            'semantic_ratio': semantic_ratio
        }

    def _low_level_hits(self, query: str, options: Dict[str, Any], include_text: bool) -> List[Dict[str, Any]]:
        """Internal helper to get raw hits with _score for hybrid fusion."""
        # Build minimal search_request similarly to main path but preserving _score.
        request_opts = dict(options)
        limit = request_opts.get('hitsPerPage', request_opts.get('limit', 20))
        search_request: Dict[str, Any] = {"table": self.index_name, 'limit': limit}
        semantic_ratio = request_opts.get('semantic_ratio')
        knn_opts_preview = request_opts.get('knn')
        skip_text_match = bool(knn_opts_preview) and semantic_ratio == 1
        if query and query != '*' and not skip_text_match and include_text:
            searchable = self.parent_client.searchable_map.get(self.index_name)
            if searchable:
                field_list = ','.join([f for f in searchable if f != 'content_vector'])
                safe_q = query.replace("'", "''")
                search_request['query'] = {"query_string": f"@({field_list}) {safe_q}"}
            else:
                search_request['query'] = {"query_string": query}
        if 'filter' in request_opts and request_opts['filter']:
            search_request['filter'] = request_opts['filter']
        if knn_opts_preview:
            k = knn_opts_preview.get('k', limit)
            qv = knn_opts_preview.get('query_vector')
            if not qv and query and query != '*':
                qv = self.parent_client.generate_embedding(query)
            if qv:
                search_request['knn'] = {'field': knn_opts_preview.get('var_field','content_vector'), 'k': k, 'query_vector': qv}
        with ApiClient(self.parent_client._config) as api_client:
            api = SearchApi(api_client)
            try:
                model_req = SearchRequest(**search_request)
                result = api.search(model_req)
            except Exception:
                result = api.search(search_request)
        # Unwrap like in main search
        def _unwrap(res):
            if isinstance(res, dict):
                return res
            if hasattr(res, 'to_dict'):
                try:
                    return res.to_dict()
                except Exception:
                    pass
            data = {}
            if hasattr(res, 'hits'):
                data['hits'] = getattr(res, 'hits')
            return data
        result_dict = _unwrap(result)
        hits_section = result_dict.get('hits', {}) if isinstance(result_dict.get('hits', {}), dict) else {}
        hits_raw = hits_section.get('hits', []) if isinstance(hits_section, dict) else []
        return hits_raw
    
    def update_searchable_attributes(self, attributes: List[str]):
        """Mock method for compatibility - Manticore handles this automatically"""
        return {"task_uid": int(time.time()), "status": "succeeded"}
    
    def update_filterable_attributes(self, attributes: List[str]):
        """Mock method for compatibility - Manticore handles this automatically"""
        return {"task_uid": int(time.time()), "status": "succeeded"}
    
    def update_pagination_settings(self, settings: Dict[str, Any]):
        """Mock method for compatibility"""
        return {"task_uid": int(time.time()), "status": "succeeded"}


class IndexNotFoundError(Exception):
    """Exception raised when index is not found"""
    def __init__(self, message):
        self.message = message
        self.code = 'index_not_found'
        super().__init__(self.message)


class ManticoreApiError(Exception):
    """Exception for Manticore API errors"""
    def __init__(self, message, code=None):
        self.message = message
        self.code = code
        super().__init__(self.message)


def wait_task(task_info):
    """Mock task waiting for compatibility - Manticore operations are synchronous"""
    return {"task_uid": task_info.get("task_uid"), "status": "succeeded", "error": None}


def wait_tasks(tasks):
    """Mock task waiting for multiple tasks"""
    for task in tasks:
        wait_task(task)
