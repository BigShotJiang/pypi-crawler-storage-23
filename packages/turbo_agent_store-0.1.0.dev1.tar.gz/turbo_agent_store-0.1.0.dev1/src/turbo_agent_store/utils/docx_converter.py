from pathlib import Path
from typing import List, Dict, Any
import pypandoc
from loguru import logger
import os
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH


def convert_markdown_to_docx(
    input_path: str | os.PathLike,
    output_dir: str | os.PathLike,
) -> List[Dict[str, str]]:
    """Convert all Markdown files in input_path to DOCX, preserving directory structure.

    Args:
        input_path: File or directory path to process (.md/.markdown files).
        output_dir: Directory to write DOCX outputs. Will be created if missing.

    Returns:
        A list of dicts with keys: 'source_path', 'output_path', 'basename'.
    """
    in_path = Path(input_path)
    if not in_path.exists():
        raise FileNotFoundError(f"Input path not found: {in_path}")
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Collect markdown files
    if in_path.is_file():
        if in_path.suffix.lower() in ['.md', '.markdown']:
            files = [in_path]
            base_input_dir = in_path.parent
        else:
            logger.warning(f"File {in_path} is not a markdown file")
            return []
    else:
        files = list(in_path.rglob("*.md")) + list(in_path.rglob("*.markdown"))
        base_input_dir = in_path

    if not files:
        logger.warning(f"No markdown files found under: {in_path}")
        return []

    results: List[Dict[str, str]] = []

    for md_file in files:
        try:
            # Calculate relative path to preserve directory structure
            try:
                rel_path = md_file.relative_to(base_input_dir)
                output_subdir = out_dir / rel_path.parent
                output_subdir.mkdir(parents=True, exist_ok=True)
            except ValueError:
                # Fallback if relative_to fails
                output_subdir = out_dir

            # Generate output filename
            basename = md_file.stem
            output_file = output_subdir / f"{basename}.docx"

            # Convert using pypandoc
            logger.info(f"Converting {md_file} -> {output_file}")
            pypandoc.convert_file(
                source_file=str(md_file),
                to='docx',
                outputfile=str(output_file),
                extra_args=['--reference-doc=None']  # Use default Word template
            )

            apply_styles_to_docx(str(output_file))

            results.append({
                'source_path': str(md_file),
                'output_path': str(output_file),
                'basename': basename
            })
            logger.info(f"Successfully converted: {md_file} -> {output_file}")

        except Exception as e:
            logger.error(f"Failed to convert {md_file}: {e}")
            continue

    logger.info(f"Conversion completed. Processed {len(results)}/{len(files)} files successfully.")
    return results


def _ensure_unique_docx(base_path: Path) -> Path:
    """Ensure a unique DOCX file path by appending numeric suffix if needed."""
    if not base_path.exists():
        return base_path
    stem, suffix = base_path.stem, base_path.suffix
    parent = base_path.parent
    i = 1
    while True:
        candidate = parent / f"{stem}_{i}{suffix}"
        if not candidate.exists():
            return candidate
        i += 1


def convert_markdown_to_docx_safe(
    input_path: str | os.PathLike,
    output_dir: str | os.PathLike,
    avoid_overwrite: bool = True,
) -> List[Dict[str, str]]:
    """Convert Markdown files to DOCX with collision avoidance option.

    Args:
        input_path: File or directory path to process (.md/.markdown files).
        output_dir: Directory to write DOCX outputs. Will be created if missing.
        avoid_overwrite: If True, append numeric suffix to avoid overwriting existing files.

    Returns:
        A list of dicts with keys: 'source_path', 'output_path', 'basename'.
    """
    in_path = Path(input_path)
    if not in_path.exists():
        raise FileNotFoundError(f"Input path not found: {in_path}")
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Collect markdown files
    if in_path.is_file():
        if in_path.suffix.lower() in ['.md', '.markdown']:
            files = [in_path]
            base_input_dir = in_path.parent
        else:
            logger.warning(f"File {in_path} is not a markdown file")
            return []
    else:
        files = list(in_path.rglob("*.md")) + list(in_path.rglob("*.markdown"))
        base_input_dir = in_path

    if not files:
        logger.warning(f"No markdown files found under: {in_path}")
        return []

    results: List[Dict[str, str]] = []

    for md_file in files:
        try:
            # Calculate relative path to preserve directory structure
            try:
                rel_path = md_file.relative_to(base_input_dir)
                output_subdir = out_dir / rel_path.parent
                output_subdir.mkdir(parents=True, exist_ok=True)
            except ValueError:
                # Fallback if relative_to fails
                output_subdir = out_dir

            # Generate output filename
            basename = md_file.stem
            output_file = output_subdir / f"{basename}.docx"
            
            # Handle filename collisions if requested
            if avoid_overwrite:
                output_file = _ensure_unique_docx(output_file)

            # Convert using pypandoc
            logger.info(f"Converting {md_file} -> {output_file}")
            pypandoc.convert_file(
                source_file=str(md_file),
                to='docx',
                outputfile=str(output_file)
            )

            apply_styles_to_docx(str(output_file))

            results.append({
                'source_path': str(md_file),
                'output_path': str(output_file),
                'basename': basename
            })
            logger.info(f"Successfully converted: {md_file} -> {output_file}")

        except Exception as e:
            logger.error(f"Failed to convert {md_file}: {e}")
            continue

    logger.info(f"Conversion completed. Processed {len(results)}/{len(files)} files successfully.")
    return results


def to_main_title(run):
    run.font.name = 'Times New Roman'
    run.font.element.rPr.rFonts.set(qn('w:eastAsia'),'方正小标宋简体')
    run.font.size = Pt(22)
    run.font.color.rgb=RGBColor(0,0,0)

from docx.shared import Pt, RGBColor, Inches
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
# ...existing code...
def to_heading_1_sytle(run):
    run.font.name = 'Times New Roman'
    run.font.element.rPr.rFonts.set(qn('w:eastAsia'),'黑体')
    run.font.size = Pt(16)
    run.font.color.rgb=RGBColor(0,0,0)

def to_heading_2_sytle(run):
    run.font.name = 'Times New Roman'
    run.font.element.rPr.rFonts.set(qn('w:eastAsia'),'楷体_GB2312')
    run.font.size = Pt(16)
    run.font.color.rgb=RGBColor(0,0,0)

def to_heading_3_sytle(run):
    run.font.name = 'Times New Roman'
    run.font.element.rPr.rFonts.set(qn('w:eastAsia'),'仿宋_GB2312')
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.color.rgb=RGBColor(0,0,0)

def to_normal_syle(run):
    run.font.name = 'Times New Roman'
    run.font.element.rPr.rFonts.set(qn('w:eastAsia'),'仿宋_GB2312')
    run.font.size = Pt(16)  
    run.font.color.rgb=RGBColor(0,0,0)

def apply_styles_to_docx(docx_path: str):
    """Apply custom styles to a DOCX file."""
    try:
        doc = Document(docx_path)
        
        # Assuming the first paragraph is the main title
        if doc.paragraphs:
            title_p = doc.paragraphs[0]
            if title_p.style.name.startswith('Heading'):
                for run in title_p.runs:
                    to_main_title(run)
                title_p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for p in doc.paragraphs:
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = Pt(28.5)

            style_name = p.style.name
            if style_name.startswith('Heading 1'):
                for run in p.runs:
                    to_heading_1_sytle(run)
            elif style_name.startswith('Heading 2'):
                for run in p.runs:
                    to_heading_2_sytle(run)
            elif style_name.startswith('Heading 3'):
                for run in p.runs:
                    to_heading_3_sytle(run)
            else: # Normal text
                p.paragraph_format.first_line_indent = Pt(32)
                for run in p.runs:
                    to_normal_syle(run)

        doc.save(docx_path)
        logger.info(f"Applied styles to {docx_path}")
    except Exception as e:
        logger.error(f"Failed to apply styles to {docx_path}: {e}")