# coding=utf-8
from __future__ import annotations

import pytest

from turbo_agent_core.schema.events import RunLifecycleEvent, RunLifecyclePayload
from turbo_agent_store.impl.memory.event_broker import MemoryQueueEventBroker


@pytest.mark.asyncio
async def test_memory_event_broker_publish_and_pop():
    broker = MemoryQueueEventBroker(maxsize=10)
    event = RunLifecycleEvent(
        trace_id="trace_1",
        run_id="run_1",
        payload=RunLifecyclePayload(status="created", input_data={"conversation_id": "c1"}),
    )

    await broker.publish("s", event)
    msg = await broker.pop(timeout_s=0.2)
    assert msg is not None
    assert msg.stream == "s"
    assert "trace_1" in msg.event_json
