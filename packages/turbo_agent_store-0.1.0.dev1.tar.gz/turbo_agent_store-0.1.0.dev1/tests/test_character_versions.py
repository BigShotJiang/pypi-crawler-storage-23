import asyncio, os, sys, time
sys.path.append(os.path.abspath("src"))
sys.path.append(os.path.abspath("../turbo-agent-core/src"))
from turbo_agent_store.provider.prisma_sqlite import PrismaSQLiteConfigProvider

async def main():
    db_path = os.path.abspath("prisma/data.db")
    provider = PrismaSQLiteConfigProvider(sqlite_path=db_path)
    await provider.connect()
    # 这里假设已有一个 Character 记录，用户需替换成实际存在的ID
    character_id = os.environ.get("TEST_CHARACTER_ID") or "non-existent"
    print("Fetching default version only:")
    c_default = await provider.get_character(character_id)
    print(c_default)
    print("Fetching all versions:")
    c_all = await provider.get_character(character_id, versions="all")
    print(c_all)
    print("Fetching first 2 versions:")
    c_limit = await provider.get_character(character_id, versions=2)
    print(c_limit)
    await provider.close()

if __name__ == "__main__":
    asyncio.run(main())
