import asyncio
import sys
import os
import time

# Add src to path
sys.path.append(os.path.abspath("src"))
sys.path.append(os.path.abspath("../turbo-agent-core/src"))

from turbo_agent_store.provider.prisma_sqlite import PrismaSQLiteConfigProvider
from turbo_agent_core.schema.agents import Agent

async def main():
    db_path = os.path.abspath("prisma/data.db")
    provider = PrismaSQLiteConfigProvider(sqlite_path=db_path)
    await provider.connect()

    try:
        # Create Agent
        agent_id = f"test-agent-{int(time.time())}"
        agent = Agent(
            id=agent_id,
            name="Test Agent",
            name_id="test_agent",
            description="A test agent",
            modelParameter={"temperature": 0.7},
            refSet={"tag1", "tag2"}
        )
        
        print(f"Creating agent: {agent.name}")
        created_agent = await provider.create_agent(agent)
        print(f"Created agent: {created_agent}")

        # Read Agent
        print(f"Reading agent: {agent.id}")
        read_agent = await provider.get_agent(agent.id)
        print(f"Read agent: {read_agent}")
        
        assert read_agent.id == agent.id
        assert read_agent.name == agent.name
        assert read_agent.modelParameter == agent.modelParameter
        # Sets might be lists in JSON, check logic
        
        # Update Agent
        read_agent.description = "Updated description"
        print(f"Updating agent: {read_agent.id}")
        updated_agent = await provider.update_agent(read_agent)
        print(f"Updated agent: {updated_agent}")
        assert updated_agent.description == "Updated description"

        # Delete Agent
        print(f"Deleting agent: {agent.id}")
        await provider.delete_agent(agent.id)
        deleted_agent = await provider.get_agent(agent.id)
        print(f"Deleted agent check: {deleted_agent}")
        assert deleted_agent is None

    finally:
        await provider.close()

if __name__ == "__main__":
    asyncio.run(main())
