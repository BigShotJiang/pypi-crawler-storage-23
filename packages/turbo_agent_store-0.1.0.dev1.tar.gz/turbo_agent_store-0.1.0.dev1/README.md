# Turbo Agent Store

存储模块的技术实现层，面向四个不同层次的需求提供实现。

## 设计哲学

> **重要说明**：四个技术路线面向不同层次的需求，**不是并行的存储后端选择**。

### 1. Memory - 内存缓存

**用途**：运行时缓存、临时数据存储

**实现**：
- `InMemoryCacheStore` - BaseCacheStore 的内存实现
- `InMemoryExecutionStore` - BaseExecutionStore 的内存降级实现
- `MemoryQueueEventBroker` - BaseEventBroker 的内存队列实现

**特点**：
- 不持久化，进程重启后数据丢失
- 用于单元测试、本地调试、临时缓存降级
- 保证接口可用与最小幂等（以 id 做覆盖/更新）

**不是**：持久化存储方案

### 2. YAML - 结构化数据导出

**用途**：基于 core schema 的结构化导出/导入

**实现**：
- `YAMLConfigStore` - BaseConfigStore 的 YAML 文件实现

**特点**：
- 保持与 core schema 的一致性
- 用于配置备份、跨环境数据迁移
- 版本控制友好（文本格式、可读性强）
- 实现数据在不同业务线产品间的流转

**不是**：持久化存储后端，而是**数据流转格式**

### 3. Resource - 文件资源管理

**用途**：KnowledgeResource 文件存储（上传资源、解析结果）

**实现**：
- `LocalResourceStore` - 本地文件系统实现
- `MinIOResourceStore` (cloud 模块) - MinIO 对象存储实现

**存储路径**：
```
{user_id}/{context_id}/{resource_id}/
├── original/{filename}     # 原始上传文件
├── parsed/                  # 解析结果（预留）
└── chunks/                  # 分块数据（预留）
```

**Context 类型**：
- `session_{id}` - 对话临时文件
- `project_{id}` - 项目文件
- `temp_{id}` - 临时目录

**特点**：
- Worker 只读访问
- Server 可写
- 用于上传文档、图片、数据文件等

### 4. Workspace - 工作区版本管理

**用途**：代码/文件的 Git 版本管理

**实现**：
- `LocalGitWorkspaceStore` - 本地 Git 实现
- `RemoteGitWorkspaceStore` (cloud 模块，规划中) - 远程 Git 服务器

**场景**：
- 用户上传工作区（zip 包）
- 在线编辑代码文件
- Agent 生成代码/配置文件
- 开发 Tool/Character 的代码逻辑

**目录结构**：
```
{base_path}/{user_id}/{workspace_id}/
├── .git/                       # Git 版本控制
├── files/                      # 工作文件（Git 跟踪）
│   ├── main.py
│   └── config.yaml
└── .meta/                      # 元数据索引
    └── manifest.json
```

**特点**：
- 完整 Git 版本控制
- Worker 可读写
- 支持历史追溯、版本回退、分支标签

---

## 架构关系

```
turbo-agent-core (纯抽象)
    │
    ├── BaseConfigStore ──┬──> [cloud] PrismaConfigStore (持久化)
    │                     └──> [store] YAMLConfigStore (导出)
    │
    ├── BaseFileStore ────┬──> [cloud] 对象存储实现
    │                     └──> [store] GitFileStore (旧版工作空间)
    │
    ├── BaseCacheStore ───┬──> [cloud] RedisCacheStore
    │                     └──> [store] InMemoryCacheStore (降级)
    │
    ├── BaseExecutionStore ──> [store] InMemoryExecutionStore (降级)
    │
    ├── ResourceStore ────┬──> [cloud] MinIOResourceStore (生产)
    │                     └──> [store] LocalResourceStore (开发)
    │
    └── WorkspaceStore ───┬──> [cloud] RemoteGitWorkspaceStore (规划)
                          └──> [store] LocalGitWorkspaceStore (本地)
```

**依赖规则**：
- `turbo-agent-store` 只依赖 `turbo-agent-core`
- 具体业务 DTOs 由各产品线自行定义
- 持久化存储由各场景模块自行实现（如 cloud 模块的 Prisma/MinIO 实现）

---

## Worker 环境管理

### 使用场景

Worker 执行任务前需要准备执行环境：
1. 下载 KnowledgeResource 文件（只读）
2. 检出 Workspace 文件（可读写）
3. 生成环境配置

### 环境目录结构

```
/tmp/worker_{task_id}/
├── resources/           # KnowledgeResource 文件（只读）
│   └── {resource_id}/
│       └── {filename}
├── workspace/           # Workspace 文件（可读写）
│   ├── .git/
│   └── files/
│       ├── main.py
│       └── config.yaml
├── output/              # 输出目录
├── manifest.json        # 环境清单
└── .env                 # 环境变量
```

### 使用示例

```python
from turbo_agent_store import (
    LocalResourceStore,
    LocalGitWorkspaceStore,
    WorkerEnvironmentBuilder,
    ResourceRef,
    WorkspaceRef,
)

# 创建 Builder
builder = WorkerEnvironmentBuilder(
    resource_store=LocalResourceStore("/data/resources"),
    workspace_store_factory=lambda wid, uid: LocalGitWorkspaceStore(wid, uid, "/data/workspaces")
)

# 准备环境
env = await builder.prepare(
    task_id="task_001",
    resource_refs=[
        ResourceRef(
            resource_id="res_123",
            user_id="user_001",
            context_id="session_abc",
            filename="document.pdf",
            path="user_001/session_abc/res_123/original/document.pdf"
        )
    ],
    workspace_ref=WorkspaceRef(
        workspace_id="ws_001",
        user_id="user_001",
        ref="HEAD",
        files=["main.py", "config.yaml"]  # 或 None 表示全部
    )
)

# 使用环境
print(f"Resources: {env.resources_path}")
print(f"Workspace: {env.workspace_path}")

# CharacterRuntime 使用
runtime = CharacterRuntime(
    resources_path=env.resources_path,
    workspace_path=env.workspace_path
)
result = await runtime.execute(task)

# 归档输出
await builder.archive_output(env, workspace_store)

# 清理环境
await builder.cleanup(env)
```

### 上下文管理器

```python
# 使用 async with 自动管理生命周期
async with WorkerEnvironmentContext(
    builder=builder,
    task_id="task_001",
    resource_refs=[...],
    workspace_ref=WorkspaceRef(...)
) as env:
    # 环境已准备好
    result = await runtime.execute(env)
    # 自动清理
```

---

## Git 服务器

本地运行时可启动 Git 服务器供远程访问。

### 使用示例

```python
from turbo_agent_store import GitServer, GitServerConfig, GitWorkspaceSync

# 配置 Git 服务器
config = GitServerConfig(
    base_path="/data/git_server",
    enable_daemon=True,
    daemon_port=9418
)

# 创建服务器
server = GitServer(config)

# 创建裸仓库
repo_path = server.create_bare_repository("user_123", "workspace_001")

# 启动 daemon
server.start_daemon()

# 获取 Git URL
url = server.get_git_url("user_123", "workspace_001", protocol="git")
# 返回: git://0.0.0.0:9418/user_123/workspace_001.git

# 同步本地工作区到服务器
sync = GitWorkspaceSync(server)
sync.push_to_server("user_123", "workspace_001")

# 停止 daemon
server.stop_daemon()
```

---

## 安装

```bash
# 基础安装
pip install turbo-agent-store

# 包含 Git 支持
pip install turbo-agent-store[git]

# 包含所有依赖
pip install turbo-agent-store[all]
```

---

## CLI 使用

```bash
# 验证 Zip 包
ta-store verify package.zip

# 格式转换
ta-store convert input.yaml output.json --format json

# 打包配置
ta-store pack create ./configs --output export.zip

# 解压配置
ta-store pack extract export.zip --output-dir ./extracted
```

**注意**：数据库相关的命令（如 `init-db`, `export agent`）已移动到 `turbo-agent-cloud` 模块。

---

## 与其他模块的关系

| 模块 | 职责 | 依赖 |
|------|------|------|
| `turbo-agent-core` | 纯抽象定义、Schema | 无 |
| `turbo-agent-store` | 技术实现层（Memory/YAML/Git/Resource/Workspace） | core |
| `turbo-agent-cloud` | 云场景持久化实现（Prisma/MinIO/RemoteGit） | core + store |
| `turbo-agent-server` | HTTP API 服务 | cloud + store |
| `turbo-agent-job` | 任务调度与执行 | core + store + runtime |

---

## 迁移指南

从旧版本迁移：

1. **Prisma 相关功能** → 使用 `turbo-agent-cloud`
2. **YAML 导出/导入** → 继续使用 `turbo-agent-store`
3. **文件上传下载** → 使用新的 `ResourceStore` 接口
4. **工作区版本管理** → 使用新的 `WorkspaceStore` 接口
5. **GitFileStore** → 继续使用（旧版），或迁移到 `LocalGitWorkspaceStore`（新版）
