"""Auth state management for the MCP server.

Holds the current authentication context — either an agent API key
(from env) or a session token (from OTP login flow).
"""

from __future__ import annotations

import os


class AuthState:
    """Tracks authentication across the MCP session lifetime."""

    def __init__(self):
        self.agent_key: str | None = os.environ.get("AMROOD_AGENT_KEY")
        self.agent_id: str | None = os.environ.get("AMROOD_AGENT_ID")
        self.session_token: str | None = None
        self.owner_id: str | None = None

    @property
    def has_agent_key(self) -> bool:
        return bool(self.agent_key)

    @property
    def has_session(self) -> bool:
        return bool(self.session_token)

    @property
    def is_authenticated(self) -> bool:
        return self.has_agent_key or self.has_session

    def set_session(self, token: str, owner_id: str):
        self.session_token = token
        self.owner_id = owner_id

    def set_agent(self, agent_key: str, agent_id: str):
        self.agent_key = agent_key
        self.agent_id = agent_id
