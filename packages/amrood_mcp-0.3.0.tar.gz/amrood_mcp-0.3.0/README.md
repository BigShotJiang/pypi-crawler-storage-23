# amrood-mcp

MCP server for [Amrood](https://amrood.io) — compliant payment infrastructure for AI agents.

## Quick Start

### With an existing agent key

```json
{
  "mcpServers": {
    "amrood": {
      "command": "uvx",
      "args": ["amrood-mcp"],
      "env": {
        "AMROOD_AGENT_KEY": "agk_live_xxx"
      }
    }
  }
}
```

### Fresh onboarding (no key yet)

```json
{
  "mcpServers": {
    "amrood": {
      "command": "uvx",
      "args": ["amrood-mcp"]
    }
  }
}
```

Then ask the AI to "register me on Amrood" and follow the OTP flow.

## Available Tools

### Agent Tools
- **amrood_balance** — Check wallet balance
- **amrood_pay** — Pay another agent by handle or ID
- **amrood_transactions** — View transaction history
- **amrood_fund** — Get a payment link to add funds

### Identity & Verification
- **amrood_proof** — Generate a platform-signed proof of network membership
- **amrood_verify_agent** — Check if an agent exists (by handle or ID)
- **amrood_identity** — View own handle, name, and status

### Escrow Tools
- **amrood_escrow_hold** — Hold funds in escrow (basic, timed, or attested)
- **amrood_escrow_release** — Release escrowed funds to a recipient
- **amrood_escrow_refund** — Refund escrowed funds back to sender
- **amrood_escrow_status** — Check status of an escrow

### Onboarding Tools
- **amrood_register** — Start signup with phone OTP
- **amrood_verify** — Verify OTP code
- **amrood_kyc** — Submit KYC (PAN + bank/UPI)
- **amrood_create_agent** — Create agent with a unique handle

### Utility
- **amrood_status** — Check auth status and connectivity

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `AMROOD_AGENT_KEY` | No | Agent API key (skip onboarding) |
| `AMROOD_AGENT_ID` | No | Agent ID (auto-resolved from key) |
| `AMROOD_BASE_URL` | No | API base URL (default: `https://amrood.io`) |

## Development

```bash
cd mcp
pip install -e .
amrood-mcp
```
