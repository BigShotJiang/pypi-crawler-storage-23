from collections.abc import Mapping, Sequence
from typing import Any, cast

import pytest
from dagster import DefaultScheduleStatus, RunConfig
from dagster._core.definitions.asset_selection import AndAssetSelection
from dagster._core.definitions.unresolved_asset_job_definition import UnresolvedAssetJobDefinition
from dagster_dbt import DbtManifestAssetSelection, build_schedule_from_dbt_selection, dbt_assets


@pytest.mark.parametrize(
    [
        "job_name",
        "cron_schedule",
        "dbt_select",
        "dbt_exclude",
        "dbt_selector",
        "schedule_name",
        "tags",
        "config",
        "execution_timezone",
        "default_status",
    ],
    [
        (
            "test_job",
            "0 0 * * *",
            "fqn:*",
            "",
            "",
            None,
            None,
            None,
            None,
            DefaultScheduleStatus.STOPPED,
        ),
        (
            "test_job",
            "0 * * * *",
            "fqn:*",
            "fqn:staging.*",
            "",
            "my_custom_schedule",
            {"my": "tag"},
            RunConfig(ops={"my_op": {"config": "value"}}),
            "America/Vancouver",
            DefaultScheduleStatus.RUNNING,
        ),
        (
            "test_job",
            "0 * * * *",
            "fqn:*",
            "",
            "raw_customer_child_models",
            "my_custom_schedule",
            {"my": "tag"},
            RunConfig(ops={"my_op": {"config": "value"}}),
            "America/Vancouver",
            DefaultScheduleStatus.RUNNING,
        ),
    ],
)
def test_dbt_build_schedule(
    test_jaffle_shop_manifest: dict[str, Any],
    job_name: str,
    cron_schedule: str,
    dbt_select: str,
    dbt_exclude: str,
    dbt_selector: str,
    schedule_name: str | None,
    tags: Mapping[str, str] | None,
    config: RunConfig | None,
    execution_timezone: str | None,
    default_status: DefaultScheduleStatus,
) -> None:
    @dbt_assets(manifest=test_jaffle_shop_manifest)
    def my_dbt_assets(): ...

    test_daily_schedule = build_schedule_from_dbt_selection(
        [my_dbt_assets],
        job_name=job_name,
        cron_schedule=cron_schedule,
        dbt_select=dbt_select,
        schedule_name=schedule_name,
        dbt_exclude=dbt_exclude,
        dbt_selector=dbt_selector,
        tags=tags,
        config=config,
        execution_timezone=execution_timezone,
        default_status=default_status,
    )

    assert test_daily_schedule.name == schedule_name or f"{job_name}_schedule"
    assert test_daily_schedule.job.name == job_name
    assert test_daily_schedule.execution_timezone == execution_timezone
    assert test_daily_schedule.default_status == default_status

    job = test_daily_schedule.job

    assert isinstance(job, UnresolvedAssetJobDefinition)
    assert job.tags == (tags or {})
    assert job.config == (config.to_config_dict() if config else None)

    assert isinstance(job.selection, AndAssetSelection)
    assert len(job.selection.operands) == 2

    [dbt_assets_selection, job_selection] = cast(
        "Sequence[DbtManifestAssetSelection]", job.selection.operands
    )
    assert dbt_assets_selection.select == "fqn:*"
    assert dbt_assets_selection.exclude == ""
    assert dbt_assets_selection.selector == ""
    assert job_selection.select == (dbt_select or "fqn:*")
    assert job_selection.exclude == (dbt_exclude or "")
    assert job_selection.selector == (dbt_selector or "")
