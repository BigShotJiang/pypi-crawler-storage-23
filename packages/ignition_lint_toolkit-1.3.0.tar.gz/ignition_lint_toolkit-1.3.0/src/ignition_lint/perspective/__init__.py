"""Perspective linting utilities."""

from .linter import IgnitionPerspectiveLinter

__all__ = ["IgnitionPerspectiveLinter"]
