"""Tag/UDT linting utilities."""

from .linter import IgnitionTagLinter

__all__ = ["IgnitionTagLinter"]
