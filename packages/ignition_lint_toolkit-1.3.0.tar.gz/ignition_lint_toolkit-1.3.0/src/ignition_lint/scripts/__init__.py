"""Script linting utilities."""

from .linter import IgnitionScriptLinter

__all__ = ["IgnitionScriptLinter"]
