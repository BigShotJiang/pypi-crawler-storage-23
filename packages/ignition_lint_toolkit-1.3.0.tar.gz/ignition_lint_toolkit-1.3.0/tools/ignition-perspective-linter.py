#!/usr/bin/env python3
"""Wrapper script for invoking the packaged Perspective linter."""

from ignition_lint.perspective.linter import main

if __name__ == "__main__":
    main()
