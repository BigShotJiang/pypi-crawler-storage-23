#!/usr/bin/env python3
"""Wrapper script for invoking the packaged script linter."""

from ignition_lint.scripts.linter import main

if __name__ == "__main__":
    main()
