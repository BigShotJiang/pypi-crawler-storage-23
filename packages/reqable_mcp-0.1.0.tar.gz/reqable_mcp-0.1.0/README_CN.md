# Reqable MCP Server

`reqable-mcp` 用于把本地 Reqable 抓包数据暴露给 MCP 客户端（Windsurf/Cursor/Claude/Codex）。

默认是本地模式：

1. Reqable 把 HAR(JSON) 上报到 `http://127.0.0.1:18765/report`
2. `reqable-mcp` 在本地 SQLite 落库
3. MCP 工具只读取本地数据，不走云端

## 启动

### npm 分发方式

```bash
npx -y reqable-mcp@latest
```

> 说明：`npx` 启动器依赖 PyPI 上已有 `reqable-mcp` 包。

### 本地开发运行

```bash
uv run reqable-mcp
```

## MCP 配置示例

```json
{
  "mcpServers": {
    "reqable": {
      "command": "npx",
      "args": ["-y", "reqable-mcp@latest"]
    }
  }
}
```

## Reqable 配置

把 Report Server URL 设为：

```txt
http://127.0.0.1:18765/report
```

## 可用工具

1. `ingest_status`
2. `import_har`
3. `list_requests`
4. `get_request`
5. `search_requests`
6. `get_domains`
7. `analyze_api`
8. `generate_code`

## 环境变量

1. `REQABLE_INGEST_HOST`（默认 `127.0.0.1`）
2. `REQABLE_INGEST_PORT`（默认 `18765`）
3. `REQABLE_INGEST_PATH`（默认 `/report`）
4. `REQABLE_DATA_DIR`
5. `REQABLE_DB_PATH`
6. `REQABLE_MAX_BODY_SIZE`（默认 `102400`）
7. `REQABLE_MAX_REPORT_SIZE`（默认 `10485760`，即 10MB）
8. `REQABLE_RETENTION_DAYS`（默认 `7`）
9. `REQABLE_INGEST_TOKEN`（可选）
