# Reqable MCP Server

Reqable MCP Server exposes local Reqable capture data to MCP clients (Windsurf/Cursor/Claude/Codex).

Default mode is local-only:

- Reqable posts HAR(JSON) payload to `http://127.0.0.1:18765/report`
- `reqable-mcp` stores parsed requests in local SQLite
- MCP tools query local data only

## Install / Run

### From package manager

```bash
npx -y reqable-mcp@latest
```

> Note: `npx` launcher depends on `reqable-mcp` being published on PyPI.

### Local development

```bash
uv run reqable-mcp
```

## MCP config example

```json
{
  "mcpServers": {
    "reqable": {
      "command": "npx",
      "args": ["-y", "reqable-mcp@latest"]
    }
  }
}
```

## Reqable config

Set Reqable Report Server URL to:

```txt
http://127.0.0.1:18765/report
```

## Tools

- `ingest_status`
- `import_har`
- `list_requests`
- `get_request`
- `search_requests`
- `get_domains`
- `analyze_api`
- `generate_code`

## Environment variables

- `REQABLE_INGEST_HOST` (default: `127.0.0.1`)
- `REQABLE_INGEST_PORT` (default: `18765`)
- `REQABLE_INGEST_PATH` (default: `/report`)
- `REQABLE_DATA_DIR` (default: platform app data dir)
- `REQABLE_DB_PATH` (default: `${REQABLE_DATA_DIR}/requests.db`)
- `REQABLE_MAX_BODY_SIZE` (default: `102400`)
- `REQABLE_MAX_REPORT_SIZE` (default: `10485760`)
- `REQABLE_RETENTION_DAYS` (default: `7`)
- `REQABLE_INGEST_TOKEN` (optional local token)
