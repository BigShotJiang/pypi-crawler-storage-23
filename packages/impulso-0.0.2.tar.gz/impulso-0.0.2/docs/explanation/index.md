# Explanation

Background theory and design decisions behind Impulso.

*Explanations will be added as features are implemented.*
