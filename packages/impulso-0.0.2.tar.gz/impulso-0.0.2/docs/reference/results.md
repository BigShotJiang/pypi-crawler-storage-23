# Results

::: impulso.results
