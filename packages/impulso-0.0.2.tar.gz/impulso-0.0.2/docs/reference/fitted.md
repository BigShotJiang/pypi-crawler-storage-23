# FittedVAR

::: impulso.fitted
