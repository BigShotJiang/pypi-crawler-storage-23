# Samplers

::: impulso.samplers
