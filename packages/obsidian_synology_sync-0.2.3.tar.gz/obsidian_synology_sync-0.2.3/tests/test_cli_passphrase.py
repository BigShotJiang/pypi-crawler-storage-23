from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

from obsidian_sync.cli import main
from obsidian_sync.config import write_default_config
from obsidian_sync.crypto import encrypted_vault_path

HAS_CRYPTO = importlib.util.find_spec("cryptography") is not None


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _enable_vault_encryption(cfg_path: Path, env_name: str) -> None:
    content = cfg_path.read_text(encoding="utf-8")
    content = content.replace("vault_encryption_enabled = false", "vault_encryption_enabled = true")
    content = content.replace(
        'encryption_passphrase_env = "OBSIDIAN_SYNC_PASSPHRASE"',
        f'encryption_passphrase_env = "{env_name}"',
    )
    cfg_path.write_text(content, encoding="utf-8")


@pytest.mark.skipif(not HAS_CRYPTO, reason="cryptography is not installed")
def test_sync_now_accepts_passphrase_flag(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    src = tmp_path / "src"
    tgt = tmp_path / "tgt"
    src.mkdir()
    tgt.mkdir()
    cfg = tmp_path / "obsidian-sync.toml"
    write_default_config(cfg, source_vault=src, synology_vault=tgt, windows_synology_vault="C:\\x", force=True)
    _enable_vault_encryption(cfg, "OSYNC_TEST_PASS")

    _write(src / "note.md", "hello from cli flag\n")
    monkeypatch.delenv("OSYNC_TEST_PASS", raising=False)

    rc = main(["--config", str(cfg), "sync-now", "--passphrase", "unit-test-secret"])
    assert rc == 0
    assert not (tgt / "note.md").exists()
    enc = encrypted_vault_path(tgt / "note.md")
    assert enc.exists()
    assert b"hello from cli flag" not in enc.read_bytes()


@pytest.mark.skipif(not HAS_CRYPTO, reason="cryptography is not installed")
def test_sync_now_accepts_passphrase_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    src = tmp_path / "src"
    tgt = tmp_path / "tgt"
    src.mkdir()
    tgt.mkdir()
    cfg = tmp_path / "obsidian-sync.toml"
    write_default_config(cfg, source_vault=src, synology_vault=tgt, windows_synology_vault="C:\\x", force=True)
    _enable_vault_encryption(cfg, "OSYNC_TEST_PASS_FILE")

    pass_file = tmp_path / ".passphrase"
    pass_file.write_text("unit-test-secret\n", encoding="utf-8")
    _write(src / "note.md", "hello from passphrase file\n")
    monkeypatch.delenv("OSYNC_TEST_PASS_FILE", raising=False)

    rc = main(["--config", str(cfg), "sync-now", "--passphrase-file", str(pass_file)])
    assert rc == 0
    assert not (tgt / "note.md").exists()
    enc = encrypted_vault_path(tgt / "note.md")
    assert enc.exists()
    assert b"hello from passphrase file" not in enc.read_bytes()


def test_parser_rejects_both_passphrase_options() -> None:
    with pytest.raises(SystemExit) as exc:
        main(["sync-now", "--passphrase", "a", "--passphrase-file", "b"])
    assert exc.value.code == 2
