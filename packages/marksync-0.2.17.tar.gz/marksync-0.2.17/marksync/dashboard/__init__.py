"""marksync.dashboard — Full graphical dashboard for contract lifecycle management."""

from marksync.dashboard.app import create_dashboard_app

__all__ = ["create_dashboard_app"]
