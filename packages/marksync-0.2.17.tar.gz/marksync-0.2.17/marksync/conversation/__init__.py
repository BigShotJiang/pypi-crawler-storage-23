"""marksync.conversation — AI ↔ Human ↔ Script conversation engine."""

from marksync.conversation.engine import ConversationEngine, ConversationMessage

__all__ = ["ConversationEngine", "ConversationMessage"]
