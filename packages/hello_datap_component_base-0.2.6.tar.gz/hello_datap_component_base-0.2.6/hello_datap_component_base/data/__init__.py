"""
数据服务模块

提供数据获取相关的服务类
"""

from .bag_data_service import BagDataService, BagJsonResult

__all__ = [
    "BagDataService",
    "BagJsonResult",
]
