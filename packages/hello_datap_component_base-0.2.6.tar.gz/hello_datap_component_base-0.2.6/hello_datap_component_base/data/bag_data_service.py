"""
BagData 服务 - 获取 Bag 数据的 OSS 地址

环境变量配置：
    - BAG_DATA_APP_KEY: API 密钥（必需）
    - BAG_DATA_API_URL: API 地址（必需）
    - SKIP_SSL_VERIFY: 是否跳过 SSL 验证（可选，默认 false）
"""

import json
import logging
import os
from typing import Optional
from dataclasses import dataclass

import requests

logger = logging.getLogger(__name__)


def _get_env_or_raise(key: str, default: Optional[str] = None) -> str:
    """获取环境变量，如果未设置且无默认值则抛出异常"""
    value = os.environ.get(key, default)
    if value is None:
        raise ValueError(
            f"环境变量 {key} 未设置。请设置该环境变量后重试。\n"
            f"示例: export {key}=your_value"
        )
    return value


# 从环境变量获取配置（延迟加载，在实际使用时才读取）
def _get_app_key() -> str:
    """获取 API 密钥"""
    return _get_env_or_raise("BAG_DATA_APP_KEY")


def _get_api_url() -> str:
    """获取 API 地址"""
    return _get_env_or_raise("BAG_DATA_API_URL")


# 目标 OSS 配置（固定值）
TARGET_OSS_BUCKET = "infra-hads-artifacts"
TARGET_OSS_PREFIX = "bag_essential"

# JSON 文件类型（相对路径，不含敏感信息）
JSON_TYPES = {
    "camera_forward_wide": "camera_forward_wide/camera_forward_wide.json",
    "localization": "localization/localization.json",
}


# SSL 验证配置
def _skip_ssl_verify() -> bool:
    """是否跳过 SSL 验证"""
    return os.environ.get("SKIP_SSL_VERIFY", "").lower() in ("true", "1", "yes")


@dataclass
class BagJsonResult:
    """Bag JSON 结果 - 只包含 OSS 地址"""
    bag_name: str
    camera_forward_wide_url: Optional[str] = None
    localization_url: Optional[str] = None
    errors: Optional[list] = None
    
    def to_dict(self) -> dict:
        return {
            "bag_name": self.bag_name,
            "camera_forward_wide_url": self.camera_forward_wide_url,
            "localization_url": self.localization_url,
            "errors": self.errors,
        }


class BagDataService:
    """
    Bag 数据服务
    
    用于根据 bag_name 获取对应的 JSON 文件 OSS 地址
    
    环境变量配置：
        - BAG_DATA_APP_KEY: API 密钥（必需）
        - BAG_DATA_API_URL: API 地址（必需）
        - SKIP_SSL_VERIFY: 是否跳过 SSL 验证（可选，默认 false）
    
    使用示例:
        # 首先设置环境变量
        # export BAG_DATA_APP_KEY=your_app_key
        # export BAG_DATA_API_URL=https://your-api-url.com
        
        from hello_datap_component_base.data import BagDataService
        
        service = BagDataService()
        
        # 获取单个 bag 的 OSS 地址
        result = service.get_bag_json("2_033_20260123-225631_0")
        print(result.camera_forward_wide_url)  # OSS 地址
        print(result.localization_url)         # OSS 地址
        
        # 批量获取
        results = service.get_bag_json_batch(["bag1", "bag2"])
    """
    
    def __init__(self, app_key: Optional[str] = None, api_url: Optional[str] = None):
        """
        初始化服务
        
        Args:
            app_key: API 密钥（可选，默认从环境变量 BAG_DATA_APP_KEY 获取）
            api_url: API 地址（可选，默认从环境变量 BAG_DATA_API_URL 获取）
        """
        # 延迟验证：只有在实际使用时才验证环境变量
        self._app_key = app_key
        self._api_url = api_url
        self._initialized = False
    
    def _ensure_initialized(self):
        """确保服务已初始化（延迟加载配置）"""
        if self._initialized:
            return
        
        # 从环境变量获取配置
        if self._app_key is None:
            self._app_key = _get_app_key()
        if self._api_url is None:
            self._api_url = _get_api_url()
        
        self._initialized = True
    
    @property
    def app_key(self) -> str:
        """获取 API 密钥"""
        self._ensure_initialized()
        return self._app_key
    
    @property
    def _api_base_url(self) -> str:
        """获取 API 地址"""
        self._ensure_initialized()
        return self._api_url
    
    def _query_rawdata_by_bag_name(self, bag_name: str) -> Optional[dict]:
        """通过 bag_name 查询原始数据信息"""
        url = f"{self._api_base_url}/api/rawdata/query"
        headers = {
            "Content-Type": "application/json",
            "x-data-appkey": self.app_key,
        }
        payload = {
            "pageNum": 1,
            "pageSize": 10,
            "bagName": bag_name,
            "sortDesc": True,
            "returnQualityField": True,
            "status": 1,
        }
        
        try:
            verify = not _skip_ssl_verify()
            response = requests.post(url, json=payload, headers=headers, timeout=30, verify=verify)
            response.raise_for_status()
            result = response.json()
            
            data_list = result.get("data", {}).get("dataList", [])
            if data_list:
                return data_list[0]
            return None
        except Exception as e:
            logger.error(f"查询 rawdata 失败: {e}")
            return None
    
    def _parse_bag_info(self, bag_oss_url: str, bag_name: str) -> dict:
        """
        从 bagOssUrl 解析出日期和车辆信息
        """
        # 从 bag_name 解析：格式为 {车辆}_{日期}-{时间}_{序号}，如 2_033_20260123-225631_0
        parts = bag_name.split("_")
        if len(parts) >= 4:
            # 车辆号：前两部分，如 2_033
            car_name = f"{parts[0]}_{parts[1]}"
            # 日期：第三部分的前8位，如 20260123
            date_time_part = parts[2]
            dt = date_time_part.split("-")[0] if "-" in date_time_part else date_time_part[:8]
            return {"dt": dt, "car_name": car_name}
        
        # 备用：从 URL 解析
        try:
            # 移除协议前缀
            path = bag_oss_url.replace("s3://", "").replace("oss://", "")
            path_parts = path.split("/")
            # 查找日期格式的部分（8位数字）
            for part in path_parts:
                if len(part) == 8 and part.isdigit():
                    dt = part
                    # 日期后面通常是车辆号
                    idx = path_parts.index(part)
                    if idx + 1 < len(path_parts):
                        car_name = path_parts[idx + 1]
                        return {"dt": dt, "car_name": car_name}
        except Exception as e:
            logger.warning(f"解析 bag_oss_url 失败: {e}")
        
        return {}
    
    def _build_target_oss_urls(self, bag_name: str, dt: str, car_name: str) -> dict:
        """
        构建目标 OSS 地址
        
        目标路径格式: oss://{bucket}/{prefix}/{日期}/{车辆}/{bag_name}/{json文件}
        """
        base_path = f"oss://{TARGET_OSS_BUCKET}/{TARGET_OSS_PREFIX}/{dt}/{car_name}/{bag_name}"
        
        return {
            "camera_forward_wide": f"{base_path}/camera_forward_wide/camera_forward_wide.json",
            "localization": f"{base_path}/localization/localization.json",
        }
    
    def get_bag_json(
        self,
        bag_name: str,
        output_dir: Optional[str] = None,
        print_output: bool = False,
    ) -> BagJsonResult:
        """
        根据 bag_name 获取对应的 JSON 文件 OSS 地址
        
        Args:
            bag_name: 数据包名称，如 "2_033_20260123-225631_0"
            output_dir: 输出目录，如果指定则保存 JSON 文件到该目录
            print_output: 是否打印输出
            
        Returns:
            BagJsonResult 对象，包含 camera_forward_wide_url 和 localization_url
        """
        errors = []
        
        # 查询 bag 信息
        raw_data = self._query_rawdata_by_bag_name(bag_name)
        if not raw_data:
            errors.append(f"未找到 bag: {bag_name}")
            return BagJsonResult(bag_name=bag_name, errors=errors)
        
        bag_oss_url = raw_data.get("bagOssUrl") or raw_data.get("bagS3Path")
        
        # 解析日期和车辆信息
        bag_info = self._parse_bag_info(bag_oss_url or "", bag_name)
        dt = bag_info.get("dt") or raw_data.get("dt")
        car_name = bag_info.get("car_name") or raw_data.get("carName")
        
        if not dt or not car_name:
            errors.append(f"无法解析 bag 信息: dt={dt}, car_name={car_name}")
            return BagJsonResult(bag_name=bag_name, errors=errors)
        
        # 构建目标 OSS 地址
        oss_urls = self._build_target_oss_urls(bag_name, dt, car_name)
        
        result = BagJsonResult(
            bag_name=bag_name,
            camera_forward_wide_url=oss_urls["camera_forward_wide"],
            localization_url=oss_urls["localization"],
            errors=errors if errors else None,
        )
        
        # 打印输出
        if print_output:
            print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
        
        # 保存到文件
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            output_file = os.path.join(output_dir, f"{bag_name}.json")
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)
        
        return result
    
    def get_bag_json_batch(
        self,
        bag_names: list[str],
        output_dir: Optional[str] = None,
        print_output: bool = False,
    ) -> dict[str, BagJsonResult]:
        """
        批量获取多个 bag 的 JSON 文件 OSS 地址
        
        Args:
            bag_names: 数据包名称列表
            output_dir: 输出目录
            print_output: 是否打印输出
            
        Returns:
            字典，key 为 bag_name，value 为 BagJsonResult
        """
        results = {}
        for bag_name in bag_names:
            results[bag_name] = self.get_bag_json(
                bag_name,
                output_dir=output_dir,
                print_output=print_output,
            )
        return results
    
    def get_bag_info(self, bag_name: str) -> Optional[dict]:
        """获取 bag 的基本信息"""
        raw_data = self._query_rawdata_by_bag_name(bag_name)
        if not raw_data:
            return None
        
        bag_oss_url = raw_data.get("bagOssUrl") or raw_data.get("bagS3Path")
        bag_info = self._parse_bag_info(bag_oss_url or "", bag_name)
        dt = bag_info.get("dt") or raw_data.get("dt")
        car_name = bag_info.get("car_name") or raw_data.get("carName")
        
        oss_urls = self._build_target_oss_urls(bag_name, dt, car_name) if dt and car_name else {}
        
        return {
            "bag_name": bag_name,
            "bag_key": raw_data.get("bagKey"),
            "car_name": raw_data.get("carName"),
            "city_name": raw_data.get("cityName"),
            "dt": raw_data.get("dt"),
            "bag_oss_url": bag_oss_url,
            "target_oss_urls": oss_urls,
        }

    def query_and_export(
        self,
        output_dir: Optional[str] = None,
        page_num: int = 1,
        page_size: int = 20,
        car_nos: Optional[list[str]] = None,
        data_version: Optional[str] = None,
        begin_time_from: Optional[int] = None,
        begin_time_to: Optional[int] = None,
        **kwargs,
    ) -> dict:
        """
        查询 Bag 数据并获取 OSS 地址
        
        Args:
            output_dir: 输出目录，如果指定则保存 JSON 文件
            page_num: 页码
            page_size: 每页数量
            car_nos: 车辆号列表，如 ["1_023", "1_036"]
            data_version: 数据版本，如 "V1.4.1"
            begin_time_from: 开始时间（毫秒时间戳）
            begin_time_to: 结束时间（毫秒时间戳）
            **kwargs: 其他查询参数
            
        Returns:
            字典，包含 query_result（查询结果）和 export_results（导出结果）
            
        Example:
            service = BagDataService()
            
            result = service.query_and_export(
                output_dir="./output",
                car_nos=["2_033"],
                page_size=10,
            )
            
            for bag_name, data in result['export_results'].items():
                print(f"{bag_name}:")
                print(f"  前广角: {data.camera_forward_wide_url}")
                print(f"  定位: {data.localization_url}")
        """
        # 构建查询参数
        query_params = {
            "pageNum": page_num,
            "pageSize": page_size,
            "sortDesc": True,
            "returnQualityField": True,
            "status": 1,
        }
        
        if car_nos:
            query_params["carNos"] = car_nos
        if data_version:
            query_params["dataVersion"] = data_version
        if begin_time_from:
            query_params["beginTimeFrom"] = begin_time_from
        if begin_time_to:
            query_params["beginTimeTo"] = begin_time_to
        query_params.update(kwargs)
        
        # 执行查询
        url = f"{self._api_base_url}/api/rawdata/query"
        headers = {
            "Content-Type": "application/json",
            "x-data-appkey": self.app_key,
        }
        
        verify = not _skip_ssl_verify()
        response = requests.post(url, json=query_params, headers=headers, timeout=30, verify=verify)
        response.raise_for_status()
        api_result = response.json()
        
        data_list = api_result.get("data", {}).get("dataList", [])
        total_count = api_result.get("data", {}).get("totalCount", -1)
        
        # 获取 OSS 地址
        export_results = {}
        
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        for item in data_list:
            bag_name = item.get("bagName")
            if not bag_name:
                continue
            
            result = self.get_bag_json(bag_name, output_dir=output_dir, print_output=False)
            export_results[bag_name] = result
        
        return {
            "query_result": data_list,
            "total_count": total_count,
            "export_results": export_results,
            "output_dir": output_dir,
        }
