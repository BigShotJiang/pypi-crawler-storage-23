"""
阿里云 MNS 消息队列客户端

消息发送流程：
    结果 JSON → 上传到 OSS → MNS 发送包含 OSS 地址的通知消息
    如果 OSS 上传失败，降级为直接发送完整结果（inline 模式）
"""
import json
import os
import time
from typing import Dict, Any, Optional, Union
import logging

logger = logging.getLogger(__name__)


class MNSClient:
    """阿里云 MNS 消息队列客户端"""
    
    def __init__(
        self, 
        queue_name: str = "aiinfra-data-process-component-result-queue",
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_backoff: float = 2.0
    ):
        """
        初始化 MNS 客户端
        
        Args:
            queue_name: 队列名称，默认为 aiinfra-data-process-component-result-queue
            max_retries: 最大重试次数，默认 3 次（可通过环境变量 MNS_MAX_RETRIES 配置）
            retry_delay: 初始重试延迟（秒），默认 1.0 秒（可通过环境变量 MNS_RETRY_DELAY 配置）
            retry_backoff: 重试延迟的指数退避倍数，默认 2.0（可通过环境变量 MNS_RETRY_BACKOFF 配置）
        """
        self.queue_name = queue_name
        
        # 从环境变量读取重试配置，如果没有则使用默认值
        self.max_retries = int(os.environ.get('MNS_MAX_RETRIES', max_retries))
        self.retry_delay = float(os.environ.get('MNS_RETRY_DELAY', retry_delay))
        self.retry_backoff = float(os.environ.get('MNS_RETRY_BACKOFF', retry_backoff))
        
        self._client = None
        self._queue = None
        self._initialized = False
        self._Message = None  # Message 类，延迟加载
        
    def _init_client(self):
        """初始化 MNS 客户端（延迟加载）"""
        if self._initialized:
            return
            
        try:
            # 尝试导入阿里云 MNS SDK
            from mns.account import Account
            from mns.queue import Queue, Message
            
            # 保存 Message 类供后续使用
            self._Message = Message
            
            # 从环境变量获取 MNS 配置
            endpoint = os.environ.get('MNS_ENDPOINT')
            access_key_id = os.environ.get('MNS_ACCESS_KEY_ID')
            access_key_secret = os.environ.get('MNS_ACCESS_KEY_SECRET')
            
            if not all([endpoint, access_key_id, access_key_secret]):
                # 如果 MNS_ENDPOINT 不存在，静默跳过（已在 get_mns_client 中检查）
                # 如果 MNS_ENDPOINT 存在但其他配置不完整，记录警告
                if endpoint:
                    logger.warning(
                        "MNS 配置不完整，无法发送消息到队列。"
                        "需要设置环境变量: MNS_ACCESS_KEY_ID, MNS_ACCESS_KEY_SECRET"
                    )
                self._initialized = True  # 标记为已初始化，避免重复警告
                return
            
            # 创建 MNS 账户
            account = Account(endpoint, access_key_id, access_key_secret)
            # 获取队列（使用 get_queue 方法）
            self._queue = account.get_queue(self.queue_name)
            self._client = account
            self._initialized = True
            logger.info(f"MNS 客户端初始化成功，队列: {self.queue_name}")
            
        except ImportError:
            logger.warning(
                "未安装阿里云 MNS SDK，无法发送消息到队列。"
                "请安装: pip install aliyun-mns"
            )
            self._initialized = True  # 标记为已初始化，避免重复警告
        except Exception as e:
            logger.error(f"初始化 MNS 客户端失败: {e}")
            self._initialized = True  # 标记为已初始化，避免重复警告
    
    def _is_retryable_exception(self, exception: Exception) -> bool:
        """
        判断异常是否可重试
        
        Args:
            exception: 异常对象
            
        Returns:
            是否可重试
        """
        exception_str = str(exception)
        exception_type = type(exception).__name__
        
        # 网络相关异常，可重试
        retryable_keywords = [
            'NetworkException',
            'NetWorkException',
            'Connection reset',
            'Connection refused',
            'Connection timeout',
            'timeout',
            'ConnectionError',
            'ConnectTimeout',
            'ReadTimeout',
            'Errno 104',  # Connection reset by peer
            'Errno 111',  # Connection refused
            'Errno 110',  # Connection timed out
        ]
        
        # 检查异常类型和消息中是否包含可重试的关键词
        for keyword in retryable_keywords:
            if keyword in exception_type or keyword in exception_str:
                return True
        
        return False
    
    def _send_message_once(self, message_body: str) -> bool:
        """
        发送消息的单次尝试
        
        Args:
            message_body: JSON 格式的消息字符串
            
        Returns:
            是否发送成功
        """
        # 创建 Message 对象（MNS SDK 要求使用 Message 对象）
        if self._Message is None:
            from mns.queue import Message
            self._Message = Message
        
        msg = self._Message(message_body)
        
        # 发送消息
        self._queue.send_message(msg)
        return True
    
    def send_message(self, message: Union[str, Dict[str, Any]]) -> bool:
        """
        发送消息到队列（带重试逻辑）
        
        Args:
            message: 要发送的消息，可以是字符串或字典
            
        Returns:
            是否发送成功
        """
        self._init_client()
        
        if not self._queue:
            logger.warning("MNS 队列未初始化，跳过消息发送")
            return False
        
        # 转换为字符串
        if isinstance(message, dict):
            message_body = json.dumps(message, ensure_ascii=False)
        else:
            message_body = str(message)
        
        # 重试逻辑
        last_exception = None
        delay = self.retry_delay
        
        for attempt in range(self.max_retries + 1):  # 总共尝试 max_retries + 1 次
            try:
                success = self._send_message_once(message_body)
                if success:
                    if attempt > 0:
                        logger.info(
                            f"消息已成功发送到队列 {self.queue_name} "
                            f"（第 {attempt + 1} 次尝试）"
                        )
                    else:
                        logger.info(f"消息已发送到队列 {self.queue_name}")
                    return True
                    
            except Exception as e:
                last_exception = e
                
                # 判断是否可重试
                if not self._is_retryable_exception(e):
                    # 不可重试的异常，直接返回失败
                    logger.error(
                        f"发送消息到队列失败（不可重试的异常）: {e}",
                        exc_info=True
                    )
                    return False
                
                # 可重试的异常
                if attempt < self.max_retries:
                    # 还有重试机会
                    logger.warning(
                        f"发送消息到队列失败（第 {attempt + 1} 次尝试）: {e}，"
                        f"{delay:.2f} 秒后重试..."
                    )
                    time.sleep(delay)
                    delay *= self.retry_backoff  # 指数退避
                else:
                    # 已用完所有重试机会
                    logger.error(
                        f"发送消息到队列失败（已重试 {self.max_retries} 次）: {e}",
                        exc_info=True
                    )
        
        # 所有重试都失败了
        if last_exception:
            logger.error(
                f"发送消息到队列最终失败（共尝试 {self.max_retries + 1} 次）: {last_exception}",
                exc_info=True
            )
        return False


def get_mns_client(queue_name: Optional[str] = None) -> Optional[MNSClient]:
    """
    获取 MNS 客户端实例
    
    Args:
        queue_name: 队列名称，如果为 None 则使用默认队列名
        
    Returns:
        MNSClient 实例，如果配置不完整则返回 None
    """
    # 如果环境变量中没有 MNS_ENDPOINT 配置，则不发送 MNS，直接返回 None
    if not os.environ.get('MNS_ENDPOINT'):
        return None
    
    if queue_name is None:
        queue_name = os.environ.get('MNS_QUEUE_NAME', 'aiinfra-data-process-component-result-queue')
    
    client = MNSClient(queue_name)
    client._init_client()
    
    # 如果客户端未正确初始化，返回 None
    if not client._queue:
        return None
    
    return client

