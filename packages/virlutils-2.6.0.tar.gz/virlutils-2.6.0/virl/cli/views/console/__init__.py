from .console_views import console_table  # noqa
