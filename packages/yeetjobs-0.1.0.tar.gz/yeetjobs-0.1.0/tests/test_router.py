"""Tests for resource-aware routing."""

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from yeetjobs.config import ClusterConfig, PartitionConfig
from yeetjobs.router import (
    RouteResult,
    find_route,
    _parse_time_minutes,
    _score_partition,
)


# --- _parse_time_minutes ---


class TestParseTimeMinutes:
    def test_hms(self):
        assert _parse_time_minutes("4:00:00") == 240

    def test_hms_with_seconds(self):
        assert _parse_time_minutes("4:30:15") == 271  # 4*60 + 30 + 1 (ceil)

    def test_hm(self):
        assert _parse_time_minutes("4:30") == 270

    def test_minutes_only(self):
        assert _parse_time_minutes("120") == 120


# --- _score_partition ---


class TestScorePartition:
    def _gpu_partition(self):
        return PartitionConfig(
            name="gpu", gpus=["a100", "v100"], max_memory="256G", max_time="72:00:00"
        )

    def _cpu_partition(self):
        return PartitionConfig(
            name="cpu", gpus=[], max_memory="128G", max_time="168:00:00"
        )

    def test_gpu_match(self):
        p = self._gpu_partition()
        score = _score_partition(p, gpu="a100", memory=None, time=None)
        assert score is not None

    def test_gpu_no_match(self):
        p = self._gpu_partition()
        score = _score_partition(p, gpu="h100", memory=None, time=None)
        assert score is None

    def test_gpu_on_cpu_partition(self):
        p = self._cpu_partition()
        score = _score_partition(p, gpu="a100", memory=None, time=None)
        assert score is None

    def test_memory_too_small(self):
        p = self._cpu_partition()
        score = _score_partition(p, gpu=None, memory="256G", time=None)
        assert score is None

    def test_memory_sufficient(self):
        p = self._cpu_partition()
        score = _score_partition(p, gpu=None, memory="64G", time=None)
        assert score is not None

    def test_time_too_long(self):
        p = self._gpu_partition()
        score = _score_partition(p, gpu=None, memory=None, time="100:00:00")
        assert score is None

    def test_no_gpu_penalty_for_gpu_partition(self):
        """CPU-only job on GPU partition should get penalized."""
        p = self._gpu_partition()
        score = _score_partition(p, gpu=None, memory=None, time=None)
        assert score is not None
        assert score >= 100.0  # gpu_penalty


# --- find_route (with mocked cluster configs) ---


def _make_clusters():
    return {
        "sprint": ClusterConfig(
            name="sprint",
            host="sprint.uni.de",
            user="u",
            partitions={
                "gpu": PartitionConfig(
                    name="gpu", gpus=["a100"], max_memory="256G", max_time="72:00:00"
                ),
                "cpu": PartitionConfig(
                    name="cpu", gpus=[], max_memory="128G", max_time="168:00:00"
                ),
            },
        ),
        "cispa": ClusterConfig(
            name="cispa",
            host="cispa.de",
            user="u",
            partitions={
                "gpu": PartitionConfig(
                    name="gpu", gpus=["v100"], max_memory="128G", max_time="48:00:00"
                ),
            },
        ),
        "jureca": ClusterConfig(
            name="jureca",
            host="jureca.fzj.de",
            user="u",
            partitions={
                "gpu": PartitionConfig(
                    name="gpu", gpus=["a100"], max_memory="512G", max_time="24:00:00"
                ),
            },
        ),
    }


class TestFindRoute:
    @patch("yeetjobs.router.load_all_clusters")
    def test_routes_to_a100(self, mock_load):
        mock_load.return_value = _make_clusters()
        result = find_route(gpu="a100")
        assert result.partition.supports_gpu("a100")
        assert result.cluster.name in ("sprint", "jureca")

    @patch("yeetjobs.router.load_all_clusters")
    def test_routes_to_v100(self, mock_load):
        mock_load.return_value = _make_clusters()
        result = find_route(gpu="v100")
        assert result.cluster.name == "cispa"
        assert result.partition.name == "gpu"

    @patch("yeetjobs.router.load_all_clusters")
    def test_explicit_cluster(self, mock_load):
        mock_load.return_value = _make_clusters()
        result = find_route(gpu="a100", cluster="jureca")
        assert result.cluster.name == "jureca"

    @patch("yeetjobs.router.load_all_clusters")
    def test_explicit_cluster_not_found(self, mock_load):
        mock_load.return_value = _make_clusters()
        with pytest.raises(RuntimeError, match="not found"):
            find_route(cluster="nonexistent")

    @patch("yeetjobs.router.load_all_clusters")
    def test_no_match(self, mock_load):
        mock_load.return_value = _make_clusters()
        with pytest.raises(RuntimeError, match="No cluster/partition"):
            find_route(gpu="h100")

    @patch("yeetjobs.router.load_all_clusters")
    def test_no_clusters(self, mock_load):
        mock_load.return_value = {}
        with pytest.raises(RuntimeError, match="No clusters configured"):
            find_route()

    @patch("yeetjobs.router.load_all_clusters")
    def test_memory_routing(self, mock_load):
        mock_load.return_value = _make_clusters()
        result = find_route(memory="400G")
        assert result.cluster.name == "jureca"  # only one with 512G

    @patch("yeetjobs.router.load_all_clusters")
    def test_cpu_job_avoids_gpu_partition(self, mock_load):
        mock_load.return_value = _make_clusters()
        result = find_route(memory="64G")
        # Should prefer the cpu partition on sprint over gpu partitions
        assert result.cluster.name == "sprint"
        assert result.partition.name == "cpu"

    @patch("yeetjobs.router.load_all_clusters")
    def test_explicit_partition(self, mock_load):
        mock_load.return_value = _make_clusters()
        result = find_route(cluster="sprint", partition="cpu")
        assert result.partition.name == "cpu"
