"""Tests for cluster configuration loading and parsing."""

import tempfile
from pathlib import Path

import pytest
import yaml

from yeetjobs.config import (
    ClusterConfig,
    PartitionConfig,
    load_cluster,
    list_clusters,
    load_all_clusters,
    parse_memory,
    _parse_cluster_config,
)


# --- parse_memory ---


class TestParseMemory:
    def test_gigabytes(self):
        assert parse_memory("32G") == 32 * 1024

    def test_megabytes(self):
        assert parse_memory("512M") == 512

    def test_terabytes(self):
        assert parse_memory("1T") == 1024 * 1024

    def test_lowercase(self):
        assert parse_memory("32g") == 32 * 1024

    def test_float(self):
        assert parse_memory("1.5G") == int(1.5 * 1024)

    def test_invalid(self):
        with pytest.raises(ValueError, match="Cannot parse memory"):
            parse_memory("32X")


# --- PartitionConfig ---


class TestPartitionConfig:
    def test_has_gpus(self):
        p = PartitionConfig(name="gpu", gpus=["a100", "v100"])
        assert p.has_gpus is True

    def test_no_gpus(self):
        p = PartitionConfig(name="cpu", gpus=[])
        assert p.has_gpus is False

    def test_supports_gpu_case_insensitive(self):
        p = PartitionConfig(name="gpu", gpus=["A100", "V100"])
        assert p.supports_gpu("a100") is True
        assert p.supports_gpu("A100") is True
        assert p.supports_gpu("h100") is False

    def test_max_memory_mb(self):
        p = PartitionConfig(name="gpu", max_memory="256G")
        assert p.max_memory_mb == 256 * 1024


# --- ClusterConfig ---


class TestClusterConfig:
    def _make_cluster(self, **overrides):
        defaults = dict(
            name="test",
            host="test.example.com",
            user="testuser",
            partitions={
                "gpu": PartitionConfig(name="gpu", gpus=["a100"], max_memory="256G"),
                "cpu": PartitionConfig(name="cpu", gpus=[], max_memory="128G"),
            },
            volumes={"datasets": "/data/datasets", "checkpoints": "/data/ckpts"},
            reachable={"other": "other-host"},
        )
        defaults.update(overrides)
        return ClusterConfig(**defaults)

    def test_get_volume_path(self):
        cfg = self._make_cluster()
        assert cfg.get_volume_path("datasets") == "/data/datasets"

    def test_get_volume_path_missing(self):
        cfg = self._make_cluster()
        with pytest.raises(KeyError, match="not configured"):
            cfg.get_volume_path("nonexistent")

    def test_can_reach(self):
        cfg = self._make_cluster()
        assert cfg.can_reach("other") == "other-host"
        assert cfg.can_reach("unreachable") is None

    def test_find_partition_gpu(self):
        cfg = self._make_cluster()
        p = cfg.find_partition(gpu="a100")
        assert p is not None
        assert p.name == "gpu"

    def test_find_partition_no_match(self):
        cfg = self._make_cluster()
        p = cfg.find_partition(gpu="h100")
        assert p is None

    def test_find_partition_memory(self):
        cfg = self._make_cluster()
        p = cfg.find_partition(memory="200G")
        assert p is not None
        assert p.name == "gpu"  # only gpu partition has 256G

    def test_find_partition_cpu_prefers_smaller(self):
        cfg = self._make_cluster()
        p = cfg.find_partition(memory="64G")
        assert p is not None
        assert p.name == "cpu"  # cpu has 128G, smaller than gpu's 256G


# --- YAML loading ---


class TestLoadCluster:
    def _write_cluster_yaml(self, tmpdir: Path, name: str, data: dict):
        clusters_dir = tmpdir / "clusters"
        clusters_dir.mkdir(parents=True, exist_ok=True)
        path = clusters_dir / f"{name}.yaml"
        with open(path, "w") as f:
            yaml.dump(data, f)
        return clusters_dir

    def test_load_cluster(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmpdir = Path(tmp)
            data = {
                "name": "sprint",
                "host": "sprint.uni.de",
                "user": "dariush",
                "partitions": {
                    "gpu": {
                        "gpus": ["a100"],
                        "max_memory": "256G",
                        "max_time": "72:00:00",
                    },
                },
                "volumes": {
                    "datasets": "/scratch/datasets",
                },
                "setup_commands": ["module load cuda/12.1"],
                "reachable": {"cispa": "cispa"},
            }
            clusters_dir = self._write_cluster_yaml(tmpdir, "sprint", data)

            cfg = load_cluster("sprint", config_dir=clusters_dir)
            assert cfg.name == "sprint"
            assert cfg.host == "sprint.uni.de"
            assert cfg.user == "dariush"
            assert "gpu" in cfg.partitions
            assert cfg.partitions["gpu"].gpus == ["a100"]
            assert cfg.volumes["datasets"] == "/scratch/datasets"
            assert cfg.setup_commands == ["module load cuda/12.1"]
            assert cfg.can_reach("cispa") == "cispa"

    def test_load_cluster_not_found(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError, match="No cluster config"):
                load_cluster("nonexistent", config_dir=Path(tmp))

    def test_list_clusters(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmpdir = Path(tmp)
            for name in ["alpha", "bravo", "charlie"]:
                self._write_cluster_yaml(tmpdir, name, {"host": "h", "user": "u"})
            clusters_dir = tmpdir / "clusters"
            names = list_clusters(config_dir=clusters_dir)
            assert names == ["alpha", "bravo", "charlie"]

    def test_list_clusters_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            names = list_clusters(config_dir=Path(tmp))
            assert names == []

    def test_load_all_clusters(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmpdir = Path(tmp)
            for name in ["x", "y"]:
                self._write_cluster_yaml(
                    tmpdir, name, {"host": f"{name}.example.com", "user": "u"}
                )
            clusters_dir = tmpdir / "clusters"
            all_cfg = load_all_clusters(config_dir=clusters_dir)
            assert set(all_cfg.keys()) == {"x", "y"}
            assert all_cfg["x"].host == "x.example.com"

    def test_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmpdir = Path(tmp)
            # Minimal config — should use all defaults
            self._write_cluster_yaml(tmpdir, "minimal", {"host": "h.com", "user": "u"})
            clusters_dir = tmpdir / "clusters"
            cfg = load_cluster("minimal", config_dir=clusters_dir)
            assert cfg.remote_dir == "~/yeet_jobs"
            assert cfg.python == "uv"
            assert cfg.setup_commands == []
            assert cfg.reachable == {}
            assert cfg.partitions == {}
            assert cfg.volumes == {}
            assert cfg.account is None
