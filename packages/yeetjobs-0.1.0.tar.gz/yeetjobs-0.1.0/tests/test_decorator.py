"""Tests for the @run decorator and RemoteFunction."""

import pytest

from yeetjobs.decorator import run, RemoteFunction


class TestRunDecorator:
    def test_creates_remote_function(self):
        @run(gpu="a100", memory="32G")
        def train(lr: float = 0.001):
            return lr

        assert isinstance(train, RemoteFunction)

    def test_preserves_function_name(self):
        @run(gpu="v100")
        def my_training_function():
            pass

        assert my_training_function.__name__ == "my_training_function"

    def test_preserves_docstring(self):
        @run(gpu="a100")
        def train():
            """Train the model."""
            pass

        assert train.__doc__ == "Train the model."

    def test_local_call(self):
        """Calling the decorated function directly should run it locally."""

        @run(gpu="a100")
        def add(a: int = 1, b: int = 2):
            return a + b

        result = add(a=3, b=4)
        assert result == 7

    def test_stores_resource_hints(self):
        @run(gpu="a100", n_gpus=2, memory="64G", time="8:00:00", n_cpus=4)
        def train():
            pass

        assert train._gpu == "a100"
        assert train._n_gpus == 2
        assert train._memory == "64G"
        assert train._time == "8:00:00"
        assert train._n_cpus == 4

    def test_defaults(self):
        @run()
        def simple():
            pass

        assert simple._gpu is None
        assert simple._n_gpus == 1
        assert simple._memory is None
        assert simple._time is None
        assert simple._n_cpus == 1

    def test_has_submit_method(self):
        @run(gpu="a100")
        def train():
            pass

        assert hasattr(train, "submit")
        assert callable(train.submit)
