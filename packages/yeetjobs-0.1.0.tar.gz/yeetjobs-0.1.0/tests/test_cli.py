"""Tests for CLI commands."""

import tempfile
from pathlib import Path
from unittest.mock import patch

import yaml
from click.testing import CliRunner

from yeetjobs.cli import cli


def _setup_clusters(tmpdir: Path):
    """Create test cluster configs in a temp directory."""
    clusters_dir = tmpdir / "clusters"
    clusters_dir.mkdir(parents=True, exist_ok=True)

    sprint_data = {
        "name": "sprint",
        "host": "sprint.uni.de",
        "user": "dariush",
        "partitions": {
            "gpu": {"gpus": ["a100"], "max_memory": "256G", "max_time": "72:00:00"},
            "cpu": {"gpus": [], "max_memory": "128G", "max_time": "168:00:00"},
        },
        "volumes": {"datasets": "/scratch/datasets", "checkpoints": "/scratch/ckpts"},
        "reachable": {"cispa": "cispa"},
    }
    with open(clusters_dir / "sprint.yaml", "w") as f:
        yaml.dump(sprint_data, f)

    cispa_data = {
        "name": "cispa",
        "host": "cispa.de",
        "user": "dariush",
        "partitions": {
            "gpu": {"gpus": ["v100"], "max_memory": "128G", "max_time": "48:00:00"},
        },
        "volumes": {"datasets": "/data/datasets"},
        "reachable": {"sprint": "sprint"},
    }
    with open(clusters_dir / "cispa.yaml", "w") as f:
        yaml.dump(cispa_data, f)

    return clusters_dir


class TestClusters:
    def test_clusters_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            clusters_dir = _setup_clusters(Path(tmp))
            with patch("yeetjobs.config.CLUSTERS_DIR", clusters_dir):
                runner = CliRunner()
                result = runner.invoke(cli, ["clusters"])
                assert result.exit_code == 0
                assert "sprint" in result.output
                assert "cispa" in result.output
                assert "a100" in result.output
                assert "v100" in result.output

    def test_clusters_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            empty_dir = Path(tmp) / "clusters"
            empty_dir.mkdir()
            with patch("yeetjobs.config.CLUSTERS_DIR", empty_dir):
                runner = CliRunner()
                result = runner.invoke(cli, ["clusters"])
                assert result.exit_code == 0
                assert "No clusters configured" in result.output


class TestCliBasic:
    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "yeet" in result.output.lower()

    def test_clusters_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["clusters", "--help"])
        assert result.exit_code == 0

    def test_ls_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["ls", "--help"])
        assert result.exit_code == 0

    def test_sync_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["sync", "--help"])
        assert result.exit_code == 0
        assert "--from" in result.output
        assert "--to" in result.output
        assert "--volume" in result.output
