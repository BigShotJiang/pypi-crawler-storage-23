"""Tests for Volume abstraction."""

import os
from pathlib import PurePosixPath

import pytest

from yeetjobs.volume import Volume, register_volumes, _VOLUME_PATHS, _ENV_PREFIX


class TestVolume:
    def setup_method(self):
        """Clean up volume registry between tests."""
        _VOLUME_PATHS.clear()

    def test_resolve_from_registry(self):
        register_volumes({"datasets": "/scratch/data"})
        v = Volume("datasets")
        assert v.path == "/scratch/data"
        assert str(v) == "/scratch/data"

    def test_resolve_from_env(self, monkeypatch):
        monkeypatch.setenv("YEET_VOLUME_MODELS", "/opt/models")
        v = Volume("models")
        assert v.path == "/opt/models"

    def test_resolve_registry_takes_precedence(self, monkeypatch):
        register_volumes({"data": "/from/registry"})
        monkeypatch.setenv("YEET_VOLUME_DATA", "/from/env")
        v = Volume("data")
        assert v.path == "/from/registry"

    def test_resolve_fails_when_not_registered(self):
        v = Volume("nonexistent")
        with pytest.raises(RuntimeError, match="cannot be resolved"):
            v.path

    def test_truediv(self):
        register_volumes({"datasets": "/scratch/data"})
        v = Volume("datasets")
        result = v / "imagenet" / "train"
        assert isinstance(result, PurePosixPath)
        assert str(result) == "/scratch/data/imagenet/train"

    def test_fspath(self):
        register_volumes({"ckpts": "/data/checkpoints"})
        v = Volume("ckpts")
        assert os.fspath(v) == "/data/checkpoints"

    def test_repr(self):
        v = Volume("datasets")
        assert repr(v) == "Volume('datasets')"

    def test_name_property(self):
        v = Volume("myvolume")
        assert v.name == "myvolume"
