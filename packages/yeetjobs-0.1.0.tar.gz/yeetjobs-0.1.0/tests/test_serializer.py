"""Tests for function serialization."""

import json
import pickle
import tempfile
from dataclasses import dataclass
from pathlib import Path

import pytest

from yeetjobs.serializer import (
    extract_function_source,
    generate_wrapper_script,
    write_job_script,
)


# --- extract_function_source ---


class TestExtractFunctionSource:
    def test_basic_function(self):
        def hello(name: str = "world"):
            print(f"Hello, {name}!")

        source = extract_function_source(hello)
        assert "def hello" in source
        assert 'print(f"Hello, {name}!")' in source

    def test_strips_decorator(self):
        """Decorators should be stripped from the extracted source."""
        source = """@some_decorator(x=1)\n@another\ndef foo():\n    pass"""
        lines = source.split("\n")
        func_start = 0
        for i, line in enumerate(lines):
            if line.strip().startswith("def "):
                func_start = i
                break
        result = "\n".join(lines[func_start:])
        assert result == "def foo():\n    pass"

    def test_multiline_function(self):
        def compute(x: int, y: int):
            result = x + y
            result *= 2
            return result

        source = extract_function_source(compute)
        assert "def compute" in source
        assert "result = x + y" in source
        assert "result *= 2" in source
        assert "return result" in source


# --- generate_wrapper_script ---


class TestGenerateWrapperScript:
    def test_generates_valid_python(self):
        fn_source = 'def train(lr: float = 0.001):\n    print(f"lr={lr}")\n    return {"lr": lr}'
        script, kwargs_pkl = generate_wrapper_script(
            fn_source=fn_source,
            fn_name="train",
            kwargs={"lr": 0.0003},
            volumes={"datasets": "/data/ds"},
        )
        # Should be valid Python
        compile(script, "<test>", "exec")

    def test_contains_volume_setup(self):
        script, _ = generate_wrapper_script(
            fn_source="def f(): pass",
            fn_name="f",
            kwargs={},
            volumes={"datasets": "/data/ds", "checkpoints": "/data/ckpts"},
        )
        assert "YEET_VOLUME" in script
        assert "/data/ds" in script
        assert "/data/ckpts" in script

    def test_contains_function_call(self):
        script, _ = generate_wrapper_script(
            fn_source="def f(x=1): return x",
            fn_name="f",
            kwargs={"x": 42},
            volumes={},
        )
        assert "f(**_kwargs)" in script

    def test_includes_volume_shim(self):
        script, _ = generate_wrapper_script(
            fn_source="def f(): pass",
            fn_name="f",
            kwargs={},
            volumes={},
        )
        assert "class Volume:" in script
        assert "register_volumes" in script

    def test_kwargs_pickled_correctly(self):
        _, kwargs_pkl = generate_wrapper_script(
            fn_source="def f(a=1, b='hello'): pass",
            fn_name="f",
            kwargs={"a": 1, "b": "hello"},
            volumes={},
        )
        loaded = pickle.loads(kwargs_pkl)
        assert loaded == {"a": 1, "b": "hello"}

    def test_kwargs_supports_complex_types(self):
        """cloudpickle can handle dataclasses, unlike JSON."""

        @dataclass
        class Config:
            lr: float = 0.001
            layers: list[int] = None

        cfg = Config(lr=0.01, layers=[64, 128, 256])
        _, kwargs_pkl = generate_wrapper_script(
            fn_source="def f(config=None): pass",
            fn_name="f",
            kwargs={"config": cfg},
            volumes={},
        )
        loaded = pickle.loads(kwargs_pkl)
        assert loaded["config"].lr == 0.01
        assert loaded["config"].layers == [64, 128, 256]

    def test_loads_from_pkl_file(self):
        script, _ = generate_wrapper_script(
            fn_source="def f(): pass",
            fn_name="f",
            kwargs={},
            volumes={},
        )
        assert "pickle.load" in script
        assert '.with_suffix(".pkl")' in script


# --- write_job_script ---


class TestWriteJobScript:
    def test_writes_script_and_pkl(self):
        def my_func(x: int = 5):
            return x * 2

        with tempfile.TemporaryDirectory() as tmp:
            path = write_job_script(
                fn=my_func,
                kwargs={"x": 10},
                volumes={"data": "/scratch/data"},
                output_dir=Path(tmp),
                script_name="test_job.py",
            )
            assert path.exists()
            assert path.name == "test_job.py"

            # Check pkl file exists alongside
            pkl_path = path.with_suffix(".pkl")
            assert pkl_path.exists()

            # Verify pkl content
            loaded = pickle.loads(pkl_path.read_bytes())
            assert loaded == {"x": 10}

            # Check script content
            content = path.read_text()
            assert "def my_func" in content
            assert "/scratch/data" in content
            # Should be executable
            assert path.stat().st_mode & 0o111

    def test_generated_script_is_valid_python(self):
        def add(a: int = 1, b: int = 2):
            return a + b

        with tempfile.TemporaryDirectory() as tmp:
            path = write_job_script(
                fn=add,
                kwargs={"a": 3, "b": 4},
                volumes={},
                output_dir=Path(tmp),
            )
            content = path.read_text()
            compile(content, str(path), "exec")

    def test_complex_kwargs(self):
        """End-to-end: dataclass arg through write_job_script."""

        @dataclass
        class TrainConfig:
            batch_size: int = 32
            lr: float = 0.001

        def train(config: TrainConfig = None):
            return config

        with tempfile.TemporaryDirectory() as tmp:
            path = write_job_script(
                fn=train,
                kwargs={"config": TrainConfig(batch_size=64, lr=0.01)},
                volumes={},
                output_dir=Path(tmp),
            )
            pkl_path = path.with_suffix(".pkl")
            loaded = pickle.loads(pkl_path.read_bytes())
            assert loaded["config"].batch_size == 64
            assert loaded["config"].lr == 0.01
