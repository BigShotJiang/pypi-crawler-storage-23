"""Tests for sync routing logic (without actual SSH/rsync)."""

from unittest.mock import patch, MagicMock

import pytest

from yeetjobs.config import ClusterConfig, PartitionConfig
from yeetjobs.sync import _build_rsync_cmd, _rsync_path


def _make_cluster(name, host, user="u", volumes=None, reachable=None):
    return ClusterConfig(
        name=name,
        host=host,
        user=user,
        volumes=volumes or {},
        reachable=reachable or {},
    )


class TestBuildRsyncCmd:
    def test_basic(self):
        cmd = _build_rsync_cmd("/src/", "user@host:/dst/")
        assert cmd[0] == "rsync"
        assert "-avz" in cmd
        assert "--progress" in cmd
        assert "/src/" in cmd
        assert "user@host:/dst/" in cmd

    def test_exclude(self):
        cmd = _build_rsync_cmd("/src/", "/dst/", exclude=[".git/", "__pycache__/"])
        assert "--exclude" in cmd
        idx = cmd.index("--exclude")
        assert cmd[idx + 1] == ".git/"

    def test_include_pattern(self):
        cmd = _build_rsync_cmd("/src/", "/dst/", include_pattern="*.pt")
        assert "--include" in cmd
        assert "*.pt" in cmd
        # Should also exclude everything else
        exclude_idx = cmd.index("--exclude")
        assert cmd[exclude_idx + 1] == "*"

    def test_delete(self):
        cmd = _build_rsync_cmd("/src/", "/dst/", delete=True)
        assert "--delete" in cmd


class TestRsyncPath:
    def test_builds_path(self):
        cfg = _make_cluster("test", "test.example.com")
        result = _rsync_path(cfg, "/data/stuff/")
        assert result == "u@test.example.com:/data/stuff/"


class TestSyncRouting:
    """Test the sync routing logic (source→dest reachability).

    These tests mock _run_rsync_with_progress to avoid actual SSH calls.
    """

    def _sprint(self):
        return _make_cluster(
            "sprint",
            "sprint.uni.de",
            volumes={"checkpoints": "/scratch/ckpts"},
            reachable={"cispa": "cispa", "jureca": "jureca"},
        )

    def _cispa(self):
        return _make_cluster(
            "cispa",
            "cispa.de",
            volumes={"checkpoints": "/data/ckpts"},
            reachable={"sprint": "sprint", "jureca": "jureca"},
        )

    def _jureca(self):
        return _make_cluster(
            "jureca",
            "jureca.fzj.de",
            volumes={"checkpoints": "/scratch/ckpts"},
            reachable={},  # Can't reach anyone
        )

    @patch("yeetjobs.sync._run_rsync_with_progress")
    @patch("yeetjobs.sync.get_cluster")
    def test_source_can_reach_dest(self, mock_get, mock_rsync):
        """sprint → cispa: sprint can reach cispa, so SSH into sprint and push."""
        mock_get.side_effect = lambda name: {
            "sprint": self._sprint(),
            "cispa": self._cispa(),
        }[name]

        from yeetjobs.sync import sync

        sync("sprint", "cispa", "checkpoints")

        # Should SSH into sprint and rsync to cispa
        mock_rsync.assert_called_once()
        cmd = mock_rsync.call_args[0][0]
        assert "ssh" in cmd[0]
        assert "sprint.uni.de" in cmd[1]

    @patch("yeetjobs.sync._run_rsync_with_progress")
    @patch("yeetjobs.sync.get_cluster")
    def test_dest_can_reach_source(self, mock_get, mock_rsync):
        """jureca → cispa: jureca can't reach cispa, but cispa can reach jureca."""
        mock_get.side_effect = lambda name: {
            "jureca": self._jureca(),
            "cispa": self._cispa(),
        }[name]

        from yeetjobs.sync import sync

        sync("jureca", "cispa", "checkpoints")

        # jureca can't reach cispa, but cispa can reach jureca → pull from cispa
        mock_rsync.assert_called_once()
        cmd = mock_rsync.call_args[0][0]
        assert "cispa.de" in cmd[1]  # SSH into cispa

    @patch("yeetjobs.sync.upload")
    @patch("yeetjobs.sync.download")
    @patch("yeetjobs.sync.get_cluster")
    def test_fallback_to_local_relay(self, mock_get, mock_download, mock_upload):
        """Two clusters that can't reach each other → relay through local."""
        isolated_a = _make_cluster(
            "a",
            "a.example.com",
            volumes={"data": "/data"},
            reachable={},
        )
        isolated_b = _make_cluster(
            "b",
            "b.example.com",
            volumes={"data": "/data"},
            reachable={},
        )
        mock_get.side_effect = lambda name: {"a": isolated_a, "b": isolated_b}[name]

        from yeetjobs.sync import sync

        sync("a", "b", "data")

        # Should download then upload
        mock_download.assert_called_once()
        mock_upload.assert_called_once()

    @patch("yeetjobs.sync._run_rsync_with_progress")
    @patch("yeetjobs.sync.get_cluster")
    def test_sync_with_pattern(self, mock_get, mock_rsync):
        """Syncing with a pattern should include the subdirectory."""
        mock_get.side_effect = lambda name: {
            "sprint": self._sprint(),
            "cispa": self._cispa(),
        }[name]

        from yeetjobs.sync import sync

        sync("sprint", "cispa", "checkpoints", pattern="run_42")

        mock_rsync.assert_called_once()
        cmd_str = mock_rsync.call_args[0][0]
        # The rsync command (second arg to ssh) should contain the pattern
        assert any("run_42" in str(c) for c in cmd_str)
