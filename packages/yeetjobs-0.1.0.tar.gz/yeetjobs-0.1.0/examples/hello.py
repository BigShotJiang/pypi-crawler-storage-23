"""Smoke test: submit a simple function to sprint via the @run decorator."""

from yeetjobs import run


@run(gpu="a40", n_gpus=1)
def hello(name: str = "world"):
    import os
    import socket

    hostname = socket.gethostname()
    gpu_info = (
        os.popen("nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null")
        .read()
        .strip()
    )
    print(f"Hello, {name}!")
    print(f"Running on: {hostname}")
    print(f"GPU: {gpu_info or 'none detected'}")
    print(f"Working dir: {os.getcwd()}")
    return {"hostname": hostname, "gpu": gpu_info}


if __name__ == "__main__":
    job = hello.submit(name="yeet", cluster="sprint")
    print(f"\nJob submitted: {job}")
    print(f"Status: {job.status()}")
    print(f"\nTo check logs later:")
    print(f"  uv run yeet logs {job.slurm_job_id} -c sprint")
