"""Test that arguments are correctly serialized and passed to the remote function."""

from yeetjobs import run


@run(gpu="a40", n_gpus=1)
def train(lr: float = 0.001, epochs: int = 10, tags: list = None):
    print(f"Training with lr={lr}, epochs={epochs}, tags={tags}")
    print(
        f"Types: lr={type(lr).__name__}, epochs={type(epochs).__name__}, tags={type(tags).__name__}"
    )
    return {"lr": lr, "epochs": epochs, "tags": tags}


if __name__ == "__main__":
    job = train.submit(
        lr=0.0003, epochs=50, tags=["exp1", "baseline"], cluster="sprint"
    )
    print(f"Job: {job}")
    print(f"Slurm ID: {job.slurm_job_id}")
    print(f"\nCheck logs with:")
    print(f"  uv run yeet logs {job.job_name} -c sprint")
