"""Test cloudpickle: pass a dataclass config object to a remote function."""

from dataclasses import dataclass

from yeetjobs import run


@dataclass
class TrainConfig:
    lr: float = 0.001
    batch_size: int = 32
    layers: tuple = (64, 128, 256)
    optimizer: str = "adam"


@run(gpu="a40", n_gpus=1)
def train(config: TrainConfig = None, extra: dict = None):
    print(f"Config type: {type(config).__name__}")
    print(f"Config: {config}")
    print(f"Extra: {extra}")
    print(f"lr={config.lr}, batch_size={config.batch_size}")
    print(f"layers={config.layers}, optimizer={config.optimizer}")
    return {
        "lr": config.lr,
        "batch_size": config.batch_size,
        "layers": list(config.layers),
    }


if __name__ == "__main__":
    cfg = TrainConfig(lr=0.01, batch_size=64, layers=(128, 256, 512), optimizer="adamw")
    job = train.submit(
        config=cfg,
        extra={"tags": ["test", "cloudpickle"], "seed": 42},
        cluster="sprint",
    )
    print(f"\nJob: {job}")
    print(f"Check: uv run yeet logs {job.job_name} -c sprint")
