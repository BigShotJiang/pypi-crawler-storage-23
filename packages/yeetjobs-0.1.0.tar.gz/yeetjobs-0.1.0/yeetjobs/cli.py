"""CLI for yeet — manage Slurm jobs across clusters.

Commands:
    yeet clusters       Show configured clusters and capabilities
    yeet ls             List jobs across all clusters
    yeet status <job>   Check job status
    yeet logs <job>     View job logs
    yeet cancel <job>   Cancel a job
    yeet upload         Upload data to a cluster volume
    yeet sync           Sync a volume between clusters
"""

from __future__ import annotations

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.group()
def cli() -> None:
    """yeet — Yeet code at Slurm clusters."""
    pass


@cli.command()
def clusters() -> None:
    """Show configured clusters and their capabilities."""
    from yeetjobs.config import load_all_clusters

    all_clusters = load_all_clusters()

    if not all_clusters:
        console.print(
            "[yellow]No clusters configured.[/] "
            "Create cluster configs in ~/.yeet/clusters/"
        )
        return

    table = Table(title="Configured Clusters")
    table.add_column("Cluster", style="bold")
    table.add_column("Host")
    table.add_column("Partitions")
    table.add_column("GPUs")
    table.add_column("Volumes")
    table.add_column("Reachable")

    for name, cfg in sorted(all_clusters.items()):
        partitions = ", ".join(cfg.partitions.keys())
        gpus = set()
        for p in cfg.partitions.values():
            gpus.update(p.gpus)
        gpu_str = ", ".join(sorted(gpus)) if gpus else "(none)"
        volumes = ", ".join(cfg.volumes.keys()) if cfg.volumes else "(none)"
        reachable = ", ".join(cfg.reachable.keys()) if cfg.reachable else "(none)"

        table.add_row(name, cfg.host, partitions, gpu_str, volumes, reachable)

    console.print(table)


@cli.command(name="ls")
@click.option("-n", "--limit", default=20, help="Number of recent jobs to show.")
@click.option("-c", "--cluster", default=None, help="Filter by cluster name.")
def list_jobs(limit: int, cluster: str | None) -> None:
    """List recent jobs across all clusters."""
    from yeetjobs.config import load_all_clusters
    import subprocess

    all_clusters = load_all_clusters()
    if cluster:
        if cluster not in all_clusters:
            console.print(f"[red]Unknown cluster: {cluster}[/]")
            return
        all_clusters = {cluster: all_clusters[cluster]}

    table = Table(title="Recent Jobs")
    table.add_column("Job ID", style="bold")
    table.add_column("Cluster")
    table.add_column("Status")
    table.add_column("Name")

    for cname, cfg in sorted(all_clusters.items()):
        try:
            result = subprocess.run(
                [
                    "ssh",
                    f"{cfg.user}@{cfg.host}",
                    f"sacct -u {cfg.user} -n --format=JobID,JobName%30,State%15 "
                    f"--parsable2 2>/dev/null | head -n {limit}",
                ],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode == 0 and result.stdout.strip():
                for line in result.stdout.strip().split("\n"):
                    parts = line.split("|")
                    if len(parts) >= 3:
                        job_id, job_name, status = parts[0], parts[1], parts[2]
                        # Skip sub-jobs (e.g., 12345.batch)
                        if "." in job_id:
                            continue
                        table.add_row(job_id, cname, status.strip(), job_name.strip())
        except Exception as e:
            console.print(f"[yellow]Could not reach {cname}: {e}[/]")

    console.print(table)


@cli.command()
@click.argument("job")
@click.option("-c", "--cluster", required=True, help="Cluster the job is on.")
def status(job: str, cluster: str) -> None:
    """Check the status of a job.

    JOB can be a Slurm job ID (numeric) or a yeet job name.
    """
    from yeetjobs.config import get_cluster

    cfg = get_cluster(cluster)
    slurm_id = job if job.isdigit() else None
    job_obj = _make_job_stub(job, cluster, cfg, slurm_job_id=slurm_id)
    s = job_obj.status()
    console.print(f"Job [bold]{job}[/] on [bold]{cluster}[/]: [bold]{s}[/]")


@cli.command()
@click.argument("job")
@click.option("-c", "--cluster", required=True, help="Cluster the job is on.")
@click.option("-n", "--tail", default=None, type=int, help="Show last N lines.")
def logs(job: str, cluster: str, tail: int | None) -> None:
    """View logs for a job.

    JOB is the yeet job name (directory name). Use 'yeet ls' to find job names.
    A numeric Slurm ID also works if you pass the job name via the directory convention.
    """
    from yeetjobs.config import get_cluster

    cfg = get_cluster(cluster)
    job_obj = _make_job_stub(job, cluster, cfg)
    output = job_obj.logs(tail=tail)
    console.print(output)


@cli.command()
@click.argument("job")
@click.option("-c", "--cluster", required=True, help="Cluster the job is on.")
def cancel(job: str, cluster: str) -> None:
    """Cancel a running job.

    JOB can be a Slurm job ID (numeric) or a yeet job name.
    """
    from yeetjobs.config import get_cluster

    cfg = get_cluster(cluster)
    slurm_id = job if job.isdigit() else None
    job_obj = _make_job_stub(job, cluster, cfg, slurm_job_id=slurm_id)
    job_obj.cancel()


@cli.command()
@click.argument("local_path")
@click.argument("volume")
@click.option("-c", "--cluster", required=True, help="Target cluster.")
@click.option("--name", default=None, help="Subdirectory name within the volume.")
def upload(local_path: str, volume: str, cluster: str, name: str | None) -> None:
    """Upload local data to a cluster volume."""
    from yeetjobs.sync import upload as sync_upload

    sync_upload(local_path=local_path, volume=volume, name=name, cluster=cluster)


@cli.command(name="download")
@click.argument("volume")
@click.argument("local_path")
@click.option("-c", "--cluster", required=True, help="Source cluster.")
@click.option("--pattern", default=None, help="Glob pattern to filter files.")
def download_cmd(
    volume: str, local_path: str, cluster: str, pattern: str | None
) -> None:
    """Download data from a cluster volume."""
    from yeetjobs.sync import download as sync_download

    sync_download(cluster=cluster, volume=volume, pattern=pattern, local=local_path)


@cli.command()
@click.option("--from", "from_cluster", required=True, help="Source cluster.")
@click.option("--to", "to_cluster", required=True, help="Destination cluster.")
@click.option("--volume", required=True, help="Volume to sync.")
@click.option("--pattern", default=None, help="Subdirectory/pattern to sync.")
def sync(from_cluster: str, to_cluster: str, volume: str, pattern: str | None) -> None:
    """Sync a volume between two clusters."""
    from yeetjobs.sync import sync as do_sync

    do_sync(
        from_cluster=from_cluster,
        to_cluster=to_cluster,
        volume=volume,
        pattern=pattern,
    )


def _make_job_stub(
    job: str,
    cluster_name: str,
    cfg: "ClusterConfig",
    slurm_job_id: str | None = None,
) -> "Job":
    """Create a minimal Job object for CLI commands.

    Args:
        job: Job name (directory name) or Slurm job ID.
        cluster_name: Cluster name.
        cfg: Cluster config.
        slurm_job_id: Explicit Slurm job ID (if job is a name, not an ID).
    """
    from yeetjobs.config import ClusterConfig
    from yeetjobs.job import Job

    # If job looks numeric and no explicit slurm_id, it's a slurm ID
    sid = slurm_job_id or (job if job.isdigit() else None)

    return Job(
        job_id=job,
        job_name=job,
        cluster_name=cluster_name,
        cluster_config=cfg,
        remote_dir=f"{cfg.remote_dir}/{job}",
        slurm_job_id=sid,
    )
