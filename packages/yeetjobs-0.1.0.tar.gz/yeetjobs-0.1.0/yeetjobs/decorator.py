"""Decorator API for yeeting functions at Slurm clusters.

Provides the @run decorator that creates a RemoteFunction,
which can be submitted to a cluster with .submit().
"""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from rich.console import Console

from yeetjobs.config import ClusterConfig
from yeetjobs.job import Job
from yeetjobs.router import find_route
from yeetjobs.serializer import write_job_script
from yeetjobs.sync import upload_code

console = Console()


class RemoteFunction:
    """A function wrapped with resource requirements, ready to be submitted.

    Created by the @run decorator. Call .submit() to yeet it at a cluster.
    """

    def __init__(
        self,
        fn: Callable,
        gpu: str | None = None,
        n_gpus: int = 1,
        memory: str | None = None,
        time: str | None = None,
        n_cpus: int = 1,
        setup_commands: list[str] | None = None,
    ) -> None:
        self._fn = fn
        self._gpu = gpu
        self._n_gpus = n_gpus
        self._memory = memory
        self._time = time
        self._n_cpus = n_cpus
        self._setup_commands = setup_commands or []

        # Preserve function metadata
        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__
        self.__module__ = fn.__module__

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Call the function locally (for testing/debugging)."""
        return self._fn(*args, **kwargs)

    def submit(
        self,
        cluster: str | None = None,
        partition: str | None = None,
        job_name: str | None = None,
        sync_dir: str | Path | None = None,
        env: dict[str, str] | None = None,
        exclude_sync: list[str] | None = None,
        **kwargs: Any,
    ) -> Job:
        """Submit this function to a Slurm cluster.

        Args:
            cluster: Force a specific cluster. None for auto-routing.
            partition: Force a specific partition.
            job_name: Custom job name. Auto-generated if None.
            sync_dir: Local directory to sync. Defaults to cwd.
            env: Extra environment variables.
            exclude_sync: Patterns to exclude from code sync.
            **kwargs: Arguments to pass to the function.

        Returns:
            A Job object for tracking.
        """
        from yeetjobs.remote import _create_sbatch_script, _submit_via_ssh

        # Route
        actual_n_gpus = self._n_gpus if self._gpu else 0
        route = find_route(
            gpu=self._gpu,
            memory=self._memory,
            time=self._time,
            cluster=cluster,
            partition=partition,
        )

        console.print(
            f"Routing [bold]{self.__name__}[/] → "
            f"[bold]{route.cluster.name}[/] / [bold]{route.partition.name}[/]"
        )

        # Generate job name
        name = job_name or f"{self.__name__}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        remote_job_dir = f"{route.cluster.remote_dir}/{name}"

        # Sync code directory
        code_dir = Path(sync_dir) if sync_dir else Path.cwd()
        upload_code(code_dir, route.cluster, name, exclude=exclude_sync)

        # Generate the Python script from function source
        volumes = route.cluster.volumes
        script_path = write_job_script(
            fn=self._fn,
            kwargs=kwargs,
            volumes=volumes,
            output_dir=code_dir / ".yeet_tmp",
            script_name=f"{self.__name__}_yeet.py",
        )

        # Upload the generated script and kwargs pickle
        import subprocess

        scp_target = f"{route.cluster.user}@{route.cluster.host}:{remote_job_dir}/"
        files_to_upload = [str(script_path)]

        # Also upload the .pkl file with kwargs
        pkl_path = script_path.with_suffix(".pkl")
        if pkl_path.exists():
            files_to_upload.append(str(pkl_path))

        subprocess.run(
            ["scp", *files_to_upload, scp_target],
            check=True,
            capture_output=True,
        )

        # Generate sbatch script
        sbatch = _create_sbatch_script(
            job_name=name,
            route=route,
            entrypoint=script_path.name,
            remote_job_dir=remote_job_dir,
            n_cpus=self._n_cpus,
            n_gpus=actual_n_gpus,
            memory=self._memory,
            time_limit=self._time,
            env=env,
        )

        # Submit
        slurm_id = _submit_via_ssh(route.cluster, remote_job_dir, sbatch)

        console.print(
            f"Submitted [bold]{name}[/] → Slurm job [bold cyan]{slurm_id}[/] "
            f"on [bold]{route.cluster.name}[/]"
        )

        # Clean up temp files
        try:
            script_path.unlink()
            pkl_path = script_path.with_suffix(".pkl")
            if pkl_path.exists():
                pkl_path.unlink()
            script_path.parent.rmdir()
        except OSError:
            pass

        return Job(
            job_id=name,
            job_name=name,
            cluster_name=route.cluster.name,
            cluster_config=route.cluster,
            remote_dir=remote_job_dir,
            slurm_job_id=slurm_id,
            metadata={
                "function": self.__name__,
                "kwargs": kwargs,
                "gpu": self._gpu,
                "n_gpus": actual_n_gpus,
                "memory": self._memory,
                "time": self._time,
                "submitted_at": datetime.now().isoformat(),
            },
        )


def run(
    gpu: str | None = None,
    n_gpus: int = 1,
    memory: str | None = None,
    time: str | None = None,
    n_cpus: int = 1,
    setup_commands: list[str] | None = None,
) -> Callable[[Callable], RemoteFunction]:
    """Decorator to mark a function for remote execution on a Slurm cluster.

    Usage:
        @run(gpu="a100", memory="32G", time="4:00:00")
        def train(lr: float = 0.001):
            import torch
            # ... self-contained training code ...

        job = train.submit(lr=0.0003)
        job = train.submit(lr=0.0003, cluster="bigboy")

    The function must be self-contained: all imports inside the body.
    Volume("name") can be used to reference cluster-local data paths.

    Args:
        gpu: GPU type needed (e.g. "a100", "v100"). None for CPU-only.
        n_gpus: Number of GPUs (default 1).
        memory: Memory requirement (e.g. "32G").
        time: Wall time limit (e.g. "4:00:00").
        n_cpus: Number of CPUs per task (default 1).
        setup_commands: Extra shell commands to run before the job.

    Returns:
        A decorator that wraps the function in a RemoteFunction.
    """

    def decorator(fn: Callable) -> RemoteFunction:
        return RemoteFunction(
            fn=fn,
            gpu=gpu,
            n_gpus=n_gpus,
            memory=memory,
            time=time,
            n_cpus=n_cpus,
            setup_commands=setup_commands,
        )

    return decorator
