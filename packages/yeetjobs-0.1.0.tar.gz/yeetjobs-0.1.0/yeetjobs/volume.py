"""Volume abstraction for cluster-local data paths.

Volumes provide a way to reference cluster-specific paths by logical name.
Inside a yeeted function, Volume("datasets") resolves to the actual path
configured for that volume on the executing cluster.

At serialization time, Volume references are resolved to concrete paths.
At runtime on the cluster, Volume is a thin wrapper around pathlib.Path.
"""

from __future__ import annotations

import os
from pathlib import PurePosixPath


# Set by the yeet runtime wrapper before calling user code
_VOLUME_PATHS: dict[str, str] = {}

# Environment variable prefix for volume paths
_ENV_PREFIX = "YEET_VOLUME_"


def _resolve_volume(name: str) -> str:
    """Resolve a volume name to its path.

    Resolution order:
    1. In-process registry (_VOLUME_PATHS) — set by serializer wrapper
    2. Environment variable YEET_VOLUME_<NAME>
    3. Error
    """
    if name in _VOLUME_PATHS:
        return _VOLUME_PATHS[name]

    env_key = f"{_ENV_PREFIX}{name.upper()}"
    env_val = os.environ.get(env_key)
    if env_val is not None:
        return env_val

    raise RuntimeError(
        f"Volume {name!r} cannot be resolved. "
        f"This usually means the code is not running inside a yeet job, "
        f"or the volume is not configured for the target cluster."
    )


def register_volumes(volumes: dict[str, str]) -> None:
    """Register volume paths for the current process. Used by the runtime wrapper."""
    _VOLUME_PATHS.update(volumes)


class Volume:
    """A path-like reference to a named volume on the executing cluster.

    Usage inside a yeeted function:

        data_dir = Volume("datasets") / "imagenet"
        checkpoint_dir = Volume("checkpoints")

    The actual path is resolved at runtime based on the cluster config.
    """

    def __init__(self, name: str) -> None:
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @property
    def path(self) -> str:
        """Resolve to the actual filesystem path."""
        return _resolve_volume(self._name)

    def __truediv__(self, other: str | PurePosixPath) -> PurePosixPath:
        """Support Volume("x") / "subdir" syntax."""
        return PurePosixPath(self.path) / str(other)

    def __str__(self) -> str:
        return self.path

    def __repr__(self) -> str:
        return f"Volume({self._name!r})"

    def __fspath__(self) -> str:
        """Support os.fspath() and open(Volume("x"))."""
        return self.path
