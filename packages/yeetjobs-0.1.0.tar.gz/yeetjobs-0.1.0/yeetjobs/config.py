"""Cluster configuration loading and validation.

Reads cluster configs from ~/.yeet/clusters/*.yaml and provides
a typed interface for accessing cluster properties.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


CONFIG_DIR = Path(os.environ.get("YEET_CONFIG_DIR", "~/.yeet")).expanduser()
CLUSTERS_DIR = CONFIG_DIR / "clusters"


def parse_memory(mem: str) -> int:
    """Parse a memory string like '32G' or '128M' into megabytes."""
    mem = mem.strip().upper()
    if mem.endswith("G"):
        return int(float(mem[:-1]) * 1024)
    elif mem.endswith("M"):
        return int(float(mem[:-1]))
    elif mem.endswith("T"):
        return int(float(mem[:-1]) * 1024 * 1024)
    else:
        raise ValueError(
            f"Cannot parse memory string: {mem!r}. Use e.g. '32G', '128M', '1T'."
        )


@dataclass
class PartitionConfig:
    """Configuration for a single Slurm partition."""

    name: str
    gpus: list[str] = field(default_factory=list)
    max_memory: str = "64G"
    max_time: str = "24:00:00"

    @property
    def max_memory_mb(self) -> int:
        return parse_memory(self.max_memory)

    @property
    def has_gpus(self) -> bool:
        return len(self.gpus) > 0

    def supports_gpu(self, gpu_type: str) -> bool:
        """Check if this partition has a specific GPU type (case-insensitive)."""
        return gpu_type.lower() in [g.lower() for g in self.gpus]


@dataclass
class ClusterConfig:
    """Configuration for a single Slurm cluster."""

    name: str
    host: str
    user: str
    partitions: dict[str, PartitionConfig] = field(default_factory=dict)
    volumes: dict[str, str] = field(default_factory=dict)
    remote_dir: str = "~/yeet_jobs"
    python: str = "uv"
    setup_commands: list[str] = field(default_factory=list)
    reachable: dict[str, str] = field(default_factory=dict)
    account: str | None = None
    default_partition: str | None = None

    def get_volume_path(self, volume_name: str) -> str:
        """Get the absolute path for a named volume on this cluster."""
        if volume_name not in self.volumes:
            available = ", ".join(self.volumes.keys()) if self.volumes else "(none)"
            raise KeyError(
                f"Volume {volume_name!r} not configured on cluster {self.name!r}. "
                f"Available volumes: {available}"
            )
        return self.volumes[volume_name]

    def can_reach(self, other_cluster: str) -> str | None:
        """Return the SSH alias to reach another cluster, or None."""
        return self.reachable.get(other_cluster)

    def find_partition(
        self,
        gpu: str | None = None,
        memory: str | None = None,
    ) -> PartitionConfig | None:
        """Find the best matching partition for the given requirements."""
        candidates = list(self.partitions.values())

        if gpu:
            candidates = [p for p in candidates if p.supports_gpu(gpu)]

        if memory:
            required_mb = parse_memory(memory)
            candidates = [p for p in candidates if p.max_memory_mb >= required_mb]

        if not candidates:
            return None

        # Prefer GPU partitions if GPU requested, otherwise prefer smallest sufficient
        if gpu:
            return candidates[0]

        # Sort by memory (prefer smaller / more appropriate)
        candidates.sort(key=lambda p: p.max_memory_mb)
        return candidates[0]


def _parse_cluster_config(data: dict[str, Any], name: str) -> ClusterConfig:
    """Parse a raw YAML dict into a ClusterConfig."""
    partitions = {}
    for pname, pdata in data.get("partitions", {}).items():
        partitions[pname] = PartitionConfig(
            name=pname,
            gpus=pdata.get("gpus", []),
            max_memory=pdata.get("max_memory", "64G"),
            max_time=pdata.get("max_time", "24:00:00"),
        )

    return ClusterConfig(
        name=data.get("name", name),
        host=data["host"],
        user=data["user"],
        partitions=partitions,
        volumes=data.get("volumes", {}),
        remote_dir=data.get("remote_dir", "~/yeet_jobs"),
        python=data.get("python", "uv"),
        setup_commands=data.get("setup_commands", []),
        reachable=data.get("reachable", {}),
        account=data.get("account"),
        default_partition=data.get("default_partition"),
    )


def load_cluster(name: str, config_dir: Path | None = None) -> ClusterConfig:
    """Load a single cluster config by name."""
    clusters_dir = config_dir or CLUSTERS_DIR
    path = clusters_dir / f"{name}.yaml"
    if not path.exists():
        raise FileNotFoundError(
            f"No cluster config found at {path}. "
            f"Create it with a YAML file defining host, user, partitions, etc."
        )
    with open(path) as f:
        data = yaml.safe_load(f)
    return _parse_cluster_config(data, name)


def list_clusters(config_dir: Path | None = None) -> list[str]:
    """List all configured cluster names."""
    clusters_dir = config_dir or CLUSTERS_DIR
    if not clusters_dir.exists():
        return []
    return sorted(p.stem for p in clusters_dir.glob("*.yaml"))


def get_cluster(name: str, config_dir: Path | None = None) -> ClusterConfig:
    """Get a cluster config by name. Alias for load_cluster."""
    return load_cluster(name, config_dir)


def load_all_clusters(config_dir: Path | None = None) -> dict[str, ClusterConfig]:
    """Load all cluster configs."""
    names = list_clusters(config_dir)
    return {name: load_cluster(name, config_dir) for name in names}
