"""Job class for tracking and managing submitted Slurm jobs.

Wraps SlurmPilot's job tracking with additional features like
artifact download and volume-aware file retrieval.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rich.console import Console

from yeetjobs.config import ClusterConfig

console = Console()


@dataclass
class Job:
    """A submitted Slurm job.

    Provides methods to check status, view logs, download artifacts,
    and cancel the job.
    """

    job_id: str
    job_name: str
    cluster_name: str
    cluster_config: ClusterConfig
    remote_dir: str
    slurm_job_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def _ssh_cmd(self, command: str) -> str:
        """Run a command on the cluster via SSH and return stdout."""
        ssh = [
            "ssh",
            f"{self.cluster_config.user}@{self.cluster_config.host}",
            command,
        ]
        result = subprocess.run(ssh, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            raise RuntimeError(
                f"SSH command failed on {self.cluster_name}: {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def status(self) -> str:
        """Get the current job status from Slurm.

        Returns one of: PENDING, RUNNING, COMPLETED, FAILED, CANCELLED,
        TIMEOUT, or UNKNOWN.
        """
        if not self.slurm_job_id:
            return "UNKNOWN"

        try:
            # Try squeue first (for running/pending jobs)
            output = self._ssh_cmd(
                f"squeue -j {self.slurm_job_id} -h -o '%T' 2>/dev/null || "
                f"sacct -j {self.slurm_job_id} -n -o State --parsable2 2>/dev/null | head -1"
            )
            if output:
                return output.strip().upper()
            return "UNKNOWN"
        except Exception:
            return "UNKNOWN"

    def logs(self, tail: int | None = None) -> str:
        """Get job stdout and stderr logs.

        Args:
            tail: If set, only return the last N lines.
        """
        log_dir = f"{self.remote_dir}/logs"
        tail_cmd = f"tail -n {tail}" if tail else "cat"

        try:
            stdout = self._ssh_cmd(
                f"{tail_cmd} {log_dir}/stdout 2>/dev/null || echo '(no stdout yet)'"
            )
            stderr = self._ssh_cmd(
                f"{tail_cmd} {log_dir}/stderr 2>/dev/null || echo '(no stderr yet)'"
            )
        except Exception as e:
            return f"Error fetching logs: {e}"

        parts = []
        if stdout and stdout != "(no stdout yet)":
            parts.append(f"--- stdout ---\n{stdout}")
        if stderr and stderr != "(no stderr yet)":
            parts.append(f"--- stderr ---\n{stderr}")
        if not parts:
            return "(no logs available yet)"
        return "\n\n".join(parts)

    def download(
        self,
        remote_path: str | None = None,
        pattern: str | None = None,
        local: str | Path = ".",
        volume: str | None = None,
    ) -> None:
        """Download files from the job's remote directory or a volume.

        Args:
            remote_path: Path relative to the job's remote dir.
            pattern: Glob pattern to filter files.
            local: Local destination directory.
            volume: Volume name to download from instead of job dir.
        """
        from yeetjobs.sync import download as sync_download

        if volume:
            sync_download(
                cluster=self.cluster_name,
                volume=volume,
                pattern=pattern,
                local=local,
                cluster_config=self.cluster_config,
            )
        else:
            full_remote = self.remote_dir
            if remote_path:
                full_remote = f"{self.remote_dir}/{remote_path}"

            sync_download(
                cluster=self.cluster_name,
                remote_path=full_remote,
                pattern=pattern,
                local=local,
                cluster_config=self.cluster_config,
            )

    def cancel(self) -> None:
        """Cancel the job."""
        if not self.slurm_job_id:
            console.print("[yellow]No Slurm job ID — cannot cancel.[/]")
            return

        try:
            self._ssh_cmd(f"scancel {self.slurm_job_id}")
            console.print(
                f"Cancelled job [bold]{self.slurm_job_id}[/] on [bold]{self.cluster_name}[/]"
            )
        except Exception as e:
            console.print(f"[red]Failed to cancel job: {e}[/]")

    def __repr__(self) -> str:
        return (
            f"Job(name={self.job_name!r}, cluster={self.cluster_name!r}, "
            f"slurm_id={self.slurm_job_id!r})"
        )

    def _repr_html_(self) -> str:
        """Rich display for Jupyter notebooks."""
        status = self.status()
        return (
            f"<b>Job</b> {self.job_name}<br>"
            f"Cluster: {self.cluster_name}<br>"
            f"Slurm ID: {self.slurm_job_id}<br>"
            f"Status: {status}"
        )
