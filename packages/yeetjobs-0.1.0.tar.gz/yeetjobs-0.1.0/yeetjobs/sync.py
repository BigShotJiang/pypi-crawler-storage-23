"""File synchronization: local↔remote and cluster↔cluster.

Uses rsync over SSH for all transfers, with rich progress bars.
"""

from __future__ import annotations

import subprocess
import re
import tempfile
from pathlib import Path

from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    DownloadColumn,
    TransferSpeedColumn,
    TimeRemainingColumn,
)
from rich.console import Console

from yeetjobs.config import ClusterConfig, get_cluster, load_all_clusters

console = Console()


def _build_rsync_cmd(
    src: str,
    dst: str,
    exclude: list[str] | None = None,
    include_pattern: str | None = None,
    ssh_host: str | None = None,
    delete: bool = False,
) -> list[str]:
    """Build an rsync command with standard flags."""
    cmd = [
        "rsync",
        "-avz",
        "--progress",
    ]
    if delete:
        cmd.append("--delete")
    if exclude:
        for pattern in exclude:
            cmd.extend(["--exclude", pattern])
    if include_pattern:
        cmd.extend(["--include", include_pattern, "--exclude", "*"])
    cmd.extend([src, dst])
    return cmd


def _run_rsync_with_progress(cmd: list[str], description: str) -> None:
    """Run an rsync command and display a rich progress bar."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task(description, total=None)

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )

        output_lines = []
        assert proc.stdout is not None
        for line in proc.stdout:
            output_lines.append(line)
            # Parse rsync --progress per-file output like:
            #   1,234,567  45%   12.34MB/s    0:00:10
            match = re.search(r"(\d+)%", line)
            if match:
                pct = int(match.group(1))
                if progress.tasks[task].total is None:
                    progress.update(task, total=100)
                progress.update(task, completed=pct)

        proc.wait()
        if proc.returncode != 0:
            output = "".join(output_lines[-20:])  # last 20 lines for debugging
            raise RuntimeError(
                f"rsync failed with exit code {proc.returncode}:\n{output}"
            )

        # Ensure bar shows complete
        if progress.tasks[task].total is not None:
            progress.update(task, completed=progress.tasks[task].total)


def _rsync_path(cluster: ClusterConfig, remote_path: str) -> str:
    """Build a user@host:path string for rsync."""
    return f"{cluster.user}@{cluster.host}:{remote_path}"


def upload(
    local_path: str | Path,
    volume: str,
    name: str | None = None,
    cluster: str | None = None,
    cluster_config: ClusterConfig | None = None,
    exclude: list[str] | None = None,
) -> None:
    """Upload a local directory/file to a volume on a cluster.

    Args:
        local_path: Local path to upload.
        volume: Volume name on the target cluster.
        name: Subdirectory name within the volume. If None, uploads to volume root.
        cluster: Cluster name (looked up from config).
        cluster_config: Direct cluster config (alternative to name lookup).
        exclude: Patterns to exclude from rsync.
    """
    cfg = cluster_config or get_cluster(cluster)  # type: ignore[arg-type]
    volume_path = cfg.get_volume_path(volume)

    local_str = str(Path(local_path).resolve())
    if not local_str.endswith("/"):
        local_str += "/"

    remote = volume_path
    if name:
        remote = f"{volume_path}/{name}"

    dst = _rsync_path(cfg, f"{remote}/")
    cmd = _build_rsync_cmd(local_str, dst, exclude=exclude)

    console.print(
        f"Uploading [bold]{local_path}[/] → [bold]{cfg.name}:{volume}/{name or ''}[/]"
    )
    _run_rsync_with_progress(cmd, f"Uploading to {cfg.name}")


def download(
    cluster: str | None = None,
    volume: str | None = None,
    pattern: str | None = None,
    local: str | Path = ".",
    remote_path: str | None = None,
    cluster_config: ClusterConfig | None = None,
) -> None:
    """Download files from a cluster to local.

    Args:
        cluster: Cluster name.
        volume: Volume name to download from.
        pattern: Optional glob pattern to filter files.
        local: Local destination directory.
        remote_path: Direct remote path (alternative to volume).
        cluster_config: Direct cluster config.
    """
    cfg = cluster_config or get_cluster(cluster)  # type: ignore[arg-type]

    if volume:
        src_path = cfg.get_volume_path(volume)
    elif remote_path:
        src_path = remote_path
    else:
        raise ValueError("Either 'volume' or 'remote_path' must be specified.")

    if not src_path.endswith("/"):
        src_path += "/"

    src = _rsync_path(cfg, src_path)
    local_str = str(Path(local).resolve())
    if not local_str.endswith("/"):
        local_str += "/"

    cmd = _build_rsync_cmd(src, local_str, include_pattern=pattern)

    desc = f"Downloading from {cfg.name}"
    console.print(
        f"Downloading [bold]{cfg.name}:{volume or remote_path}[/] → [bold]{local}[/]"
    )
    _run_rsync_with_progress(cmd, desc)


def upload_code(
    local_dir: str | Path,
    cluster_config: ClusterConfig,
    job_name: str,
    exclude: list[str] | None = None,
) -> str:
    """Upload project code to the cluster's job directory.

    Returns the remote job directory path.
    """
    remote_job_dir = f"{cluster_config.remote_dir}/{job_name}"
    local_str = str(Path(local_dir).resolve())
    if not local_str.endswith("/"):
        local_str += "/"

    # Ensure remote directory exists
    ssh_target = f"{cluster_config.user}@{cluster_config.host}"
    subprocess.run(
        ["ssh", ssh_target, f"mkdir -p {remote_job_dir}"],
        check=True,
        capture_output=True,
        text=True,
    )

    dst = _rsync_path(cluster_config, f"{remote_job_dir}/")

    default_exclude = [
        ".git/",
        "__pycache__/",
        "*.pyc",
        ".venv/",
        "node_modules/",
        ".mypy_cache/",
        ".ruff_cache/",
        ".yeet_tmp/",
    ]
    all_exclude = default_exclude + (exclude or [])

    cmd = _build_rsync_cmd(local_str, dst, exclude=all_exclude)
    _run_rsync_with_progress(cmd, f"Syncing code to {cluster_config.name}")

    return remote_job_dir


def sync(
    from_cluster: str,
    to_cluster: str,
    volume: str,
    pattern: str | None = None,
) -> None:
    """Sync a volume between two clusters.

    Routing logic:
    1. If source can reach destination → SSH into source, push via rsync
    2. If destination can reach source → SSH into destination, pull via rsync
    3. Neither → relay through local machine (download + upload)
    """
    from_cfg = get_cluster(from_cluster)
    to_cfg = get_cluster(to_cluster)

    from_vol_path = from_cfg.get_volume_path(volume)
    to_vol_path = to_cfg.get_volume_path(volume)

    # Ensure trailing slashes for directory sync
    from_path = from_vol_path.rstrip("/") + "/"
    to_path = to_vol_path.rstrip("/") + "/"

    # Add pattern as subdirectory if specified
    if pattern:
        from_path = f"{from_vol_path.rstrip('/')}/{pattern}"
        to_path = f"{to_vol_path.rstrip('/')}/{pattern}"
        # Ensure target parent exists
        if not to_path.endswith("/"):
            to_path += "/"
        if not from_path.endswith("/"):
            from_path += "/"

    # Strategy 1: source can reach destination directly
    dest_alias = from_cfg.can_reach(to_cluster)
    if dest_alias:
        console.print(
            f"Direct sync: [bold]{from_cluster}[/] → [bold]{to_cluster}[/] "
            f"(via SSH alias [cyan]{dest_alias}[/] on {from_cluster})"
        )
        # SSH into source, rsync to destination using its SSH alias
        rsync_cmd = (
            f"rsync -avz --progress {from_path} {to_cfg.user}@{dest_alias}:{to_path}"
        )
        ssh_cmd = ["ssh", f"{from_cfg.user}@{from_cfg.host}", rsync_cmd]

        _run_rsync_with_progress(ssh_cmd, f"Syncing {from_cluster} → {to_cluster}")
        return

    # Strategy 2: destination can reach source directly
    src_alias = to_cfg.can_reach(from_cluster)
    if src_alias:
        console.print(
            f"Direct sync: [bold]{to_cluster}[/] pulls from [bold]{from_cluster}[/] "
            f"(via SSH alias [cyan]{src_alias}[/] on {to_cluster})"
        )
        rsync_cmd = (
            f"rsync -avz --progress {from_cfg.user}@{src_alias}:{from_path} {to_path}"
        )
        ssh_cmd = ["ssh", f"{to_cfg.user}@{to_cfg.host}", rsync_cmd]

        _run_rsync_with_progress(ssh_cmd, f"Syncing {from_cluster} → {to_cluster}")
        return

    # Strategy 3: relay through local machine
    console.print(
        f"No direct path between [bold]{from_cluster}[/] and [bold]{to_cluster}[/]. "
        f"Relaying through local machine."
    )
    with tempfile.TemporaryDirectory(prefix="yeet_sync_") as tmp:
        download(
            cluster=from_cluster,
            volume=volume,
            pattern=pattern,
            local=tmp,
        )
        upload(
            local_path=tmp,
            volume=volume,
            cluster=to_cluster,
        )
