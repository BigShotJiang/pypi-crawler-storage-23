"""Resource-aware cluster and partition routing.

Given resource requirements (GPU type, memory, time), finds the best
cluster and partition that can satisfy them.
"""

from __future__ import annotations

from dataclasses import dataclass

from yeetjobs.config import (
    ClusterConfig,
    PartitionConfig,
    load_all_clusters,
    parse_memory,
)


@dataclass
class RouteResult:
    """The result of routing: a specific cluster + partition."""

    cluster: ClusterConfig
    partition: PartitionConfig

    def __repr__(self) -> str:
        return f"RouteResult(cluster={self.cluster.name!r}, partition={self.partition.name!r})"


def _parse_time_minutes(time_str: str) -> int:
    """Parse a time string like '4:00:00', '72:00:00', or '6-23:30:00' into minutes.

    Also handles 'infinite' / 'unlimited' → returns a very large number.
    """
    if time_str.lower() in ("infinite", "unlimited"):
        return 999_999_999

    # Handle D-HH:MM:SS format (e.g. "6-23:30:00")
    if "-" in time_str:
        day_part, time_part = time_str.split("-", 1)
        day_minutes = int(day_part) * 24 * 60
        return day_minutes + _parse_time_minutes(time_part)

    parts = time_str.split(":")
    if len(parts) == 3:
        h, m, s = parts
        return int(h) * 60 + int(m) + (1 if int(s) > 0 else 0)
    elif len(parts) == 2:
        h, m = parts
        return int(h) * 60 + int(m)
    elif len(parts) == 1:
        return int(parts[0])
    else:
        raise ValueError(f"Cannot parse time string: {time_str!r}")


def _score_partition(
    partition: PartitionConfig,
    gpu: str | None,
    memory: str | None,
    time: str | None,
) -> float | None:
    """Score a partition for given requirements. Returns None if incompatible.

    Lower score = better match (less wasted resources).
    """
    # GPU check
    if gpu and not partition.supports_gpu(gpu):
        return None
    if gpu and not partition.has_gpus:
        return None

    # Memory check
    if memory:
        required_mb = parse_memory(memory)
        if partition.max_memory_mb < required_mb:
            return None
        # Score: prefer partitions that don't over-provision too much
        memory_ratio = partition.max_memory_mb / required_mb
    else:
        memory_ratio = 1.0

    # Time check
    if time:
        required_min = _parse_time_minutes(time)
        max_min = _parse_time_minutes(partition.max_time)
        if max_min < required_min:
            return None
        time_ratio = max_min / required_min
    else:
        time_ratio = 1.0

    # Prefer GPU partitions only when GPUs are requested
    gpu_penalty = 0.0
    if not gpu and partition.has_gpus:
        gpu_penalty = 100.0  # Don't waste GPUs on CPU jobs

    # Lower is better: minimize over-provisioning
    return memory_ratio + time_ratio + gpu_penalty


def find_route(
    gpu: str | None = None,
    memory: str | None = None,
    time: str | None = None,
    cluster: str | None = None,
    partition: str | None = None,
) -> RouteResult:
    """Find the best cluster and partition for the given requirements.

    Args:
        gpu: GPU type needed (e.g. "a100", "v100"). None for CPU-only.
        memory: Memory needed (e.g. "32G"). None for no preference.
        time: Wall time needed (e.g. "4:00:00"). None for no preference.
        cluster: Force a specific cluster. None for auto-selection.
        partition: Force a specific partition. None for auto-selection.

    Returns:
        RouteResult with the selected cluster and partition.

    Raises:
        RuntimeError: If no cluster/partition can satisfy the requirements.
    """
    clusters = load_all_clusters()

    if not clusters:
        raise RuntimeError(
            "No clusters configured. Create cluster configs in ~/.yeet/clusters/"
        )

    # Filter to specific cluster if requested
    if cluster:
        if cluster not in clusters:
            available = ", ".join(clusters.keys())
            raise RuntimeError(f"Cluster {cluster!r} not found. Available: {available}")
        clusters = {cluster: clusters[cluster]}

    # Score all (cluster, partition) combinations
    candidates: list[tuple[float, ClusterConfig, PartitionConfig]] = []

    for cfg in clusters.values():
        # If partition explicitly specified
        if partition:
            if partition not in cfg.partitions:
                continue
            p = cfg.partitions[partition]
            score = _score_partition(p, gpu, memory, time)
            if score is not None:
                candidates.append((score, cfg, p))
            continue

        # Try all partitions
        for p in cfg.partitions.values():
            score = _score_partition(p, gpu, memory, time)
            if score is not None:
                candidates.append((score, cfg, p))

    if not candidates:
        reqs = []
        if gpu:
            reqs.append(f"gpu={gpu}")
        if memory:
            reqs.append(f"memory={memory}")
        if time:
            reqs.append(f"time={time}")
        if cluster:
            reqs.append(f"cluster={cluster}")
        if partition:
            reqs.append(f"partition={partition}")
        req_str = ", ".join(reqs) if reqs else "(none)"
        raise RuntimeError(
            f"No cluster/partition can satisfy requirements: {req_str}. "
            f"Check your cluster configs in ~/.yeet/clusters/"
        )

    # Sort by score (lower is better)
    candidates.sort(key=lambda x: x[0])
    best_score, best_cluster, best_partition = candidates[0]

    return RouteResult(cluster=best_cluster, partition=best_partition)
