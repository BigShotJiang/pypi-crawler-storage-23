"""yeet — Yeet code at Slurm clusters."""

from yeetjobs.decorator import run
from yeetjobs.volume import Volume
from yeetjobs.job import Job
from yeetjobs.remote import submit
from yeetjobs.sync import upload, download, sync
from yeetjobs.config import get_cluster, list_clusters

__all__ = [
    "run",
    "Volume",
    "Job",
    "submit",
    "upload",
    "download",
    "sync",
    "get_cluster",
    "list_clusters",
]
