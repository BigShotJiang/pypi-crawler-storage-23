"""Remote job submission via SlurmPilot.

Wraps SlurmPilot's SlurmPilot class for SSH-based sbatch submission,
adding uv environment sync and yeet-specific job management.
"""

from __future__ import annotations

import json
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from rich.console import Console

from yeetjobs.config import ClusterConfig, get_cluster
from yeetjobs.job import Job
from yeetjobs.router import RouteResult, find_route
from yeetjobs.sync import upload_code

console = Console()


def _generate_job_name(prefix: str = "yeet") -> str:
    """Generate a unique job name."""
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{prefix}-{ts}"


def _get_local_python_version() -> str:
    """Get the current Python major.minor version for remote consistency."""
    import sys

    return f"{sys.version_info.major}.{sys.version_info.minor}"


def _create_sbatch_script(
    job_name: str,
    route: RouteResult,
    entrypoint: str,
    remote_job_dir: str,
    n_cpus: int = 1,
    n_gpus: int = 0,
    memory: str | None = None,
    time_limit: str | None = None,
    env: dict[str, str] | None = None,
) -> str:
    """Generate an sbatch script for the job."""
    cfg = route.cluster
    partition = route.partition

    lines = ["#!/bin/bash"]
    lines.append(f"#SBATCH --job-name={job_name}")
    lines.append(f"#SBATCH --partition={partition.name}")
    lines.append(f"#SBATCH --cpus-per-task={n_cpus}")

    if n_gpus > 0:
        lines.append(f"#SBATCH --gres=gpu:{n_gpus}")

    if memory:
        lines.append(f"#SBATCH --mem={memory}")

    time_str = time_limit or partition.max_time
    if time_str.lower() not in ("infinite", "unlimited"):
        lines.append(f"#SBATCH --time={time_str}")

    if cfg.account:
        lines.append(f"#SBATCH --account={cfg.account}")

    # Log output
    lines.append(f"#SBATCH --output={remote_job_dir}/logs/stdout")
    lines.append(f"#SBATCH --error={remote_job_dir}/logs/stderr")

    lines.append("")
    lines.append("set -e")
    lines.append("")

    # Ensure ~/.local/bin is on PATH (where uv is typically installed)
    lines.append('export PATH="$HOME/.local/bin:$PATH"')
    lines.append("")

    # Create logs directory
    lines.append(f"mkdir -p {remote_job_dir}/logs")
    lines.append("")

    # Working directory
    lines.append(f"cd {remote_job_dir}")
    lines.append("")

    # Setup commands (module loads, etc.)
    for cmd in cfg.setup_commands:
        lines.append(cmd)
    if cfg.setup_commands:
        lines.append("")

    # Pin Python version to match local environment (for pickle compatibility)
    py_version = _get_local_python_version()

    # uv sync if pyproject.toml exists
    lines.append("# Auto uv sync")
    lines.append("if [ -f pyproject.toml ] && command -v uv &>/dev/null; then")
    lines.append(
        f"    uv sync --python {py_version} 2>&1 || echo 'Warning: uv sync failed'"
    )
    lines.append("fi")
    lines.append("")

    # Environment variables
    if env:
        for key, val in env.items():
            lines.append(f"export {key}={val!r}")
        lines.append("")

    # Run the entrypoint
    lines.append("# Run entrypoint")
    if entrypoint.endswith(".py"):
        lines.append("if command -v uv &>/dev/null && [ -f pyproject.toml ]; then")
        lines.append(f"    uv run --python {py_version} python {entrypoint}")
        lines.append("else")
        lines.append(f"    python3 {entrypoint}")
        lines.append("fi")
    else:
        lines.append(f"bash {entrypoint}")

    return "\n".join(lines) + "\n"


def _submit_via_ssh(
    cluster_config: ClusterConfig,
    remote_job_dir: str,
    sbatch_script: str,
) -> str:
    """Submit a job via SSH + sbatch and return the Slurm job ID."""
    import subprocess

    # Write sbatch script to remote
    sbatch_remote_path = f"{remote_job_dir}/slurm_script.sh"

    # Create remote dirs and write script via SSH
    setup_cmd = f"mkdir -p {remote_job_dir}/logs"
    ssh_base = f"{cluster_config.user}@{cluster_config.host}"

    # Create dirs
    subprocess.run(
        ["ssh", ssh_base, setup_cmd],
        check=True,
        capture_output=True,
        text=True,
    )

    # Write sbatch script via stdin
    proc = subprocess.run(
        ["ssh", ssh_base, f"cat > {sbatch_remote_path}"],
        input=sbatch_script,
        check=True,
        capture_output=True,
        text=True,
    )

    # Submit with sbatch
    result = subprocess.run(
        ["ssh", ssh_base, f"cd {remote_job_dir} && sbatch {sbatch_remote_path}"],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"sbatch failed on {cluster_config.name}: {result.stderr.strip()}"
        )

    # Parse "Submitted batch job 12345"
    output = result.stdout.strip()
    parts = output.split()
    if len(parts) >= 4 and parts[0] == "Submitted":
        slurm_id = parts[-1]
    else:
        slurm_id = output

    return slurm_id


def submit(
    script: str | Path | None = None,
    args: list[str] | None = None,
    gpu: str | None = None,
    n_gpus: int = 1,
    memory: str | None = None,
    time: str | None = None,
    n_cpus: int = 1,
    cluster: str | None = None,
    partition: str | None = None,
    sync_dir: str | Path | None = None,
    env: dict[str, str] | None = None,
    job_name: str | None = None,
    exclude_sync: list[str] | None = None,
) -> Job:
    """Submit a script to a Slurm cluster.

    This is the explicit (non-decorator) API for submitting jobs.

    Args:
        script: Path to the script to run.
        args: Command-line arguments for the script.
        gpu: GPU type needed (e.g. "a100"). None for CPU-only.
        n_gpus: Number of GPUs (default 1 if gpu is specified).
        memory: Memory requirement (e.g. "32G").
        time: Wall time limit (e.g. "4:00:00").
        n_cpus: Number of CPUs per task.
        cluster: Force a specific cluster.
        partition: Force a specific partition.
        sync_dir: Local directory to sync to the remote. Defaults to cwd.
        env: Extra environment variables.
        job_name: Custom job name. Auto-generated if None.
        exclude_sync: Patterns to exclude from code sync.

    Returns:
        A Job object for tracking the submission.
    """
    if script is None:
        raise ValueError("Must provide a script path for explicit submission.")

    script_path = Path(script)
    if not script_path.exists():
        raise FileNotFoundError(f"Script not found: {script}")

    # Route to cluster + partition
    actual_n_gpus = n_gpus if gpu else 0
    route = find_route(
        gpu=gpu, memory=memory, time=time, cluster=cluster, partition=partition
    )

    console.print(
        f"Routing to [bold]{route.cluster.name}[/] / [bold]{route.partition.name}[/]"
    )

    # Generate job name
    name = job_name or _generate_job_name(prefix=script_path.stem)
    remote_job_dir = f"{route.cluster.remote_dir}/{name}"

    # Sync code
    code_dir = Path(sync_dir) if sync_dir else Path.cwd()
    upload_code(code_dir, route.cluster, name, exclude=exclude_sync)

    # Build entrypoint with args
    entrypoint = script_path.name
    if args:
        entrypoint = f"{entrypoint} {' '.join(args)}"

    # Generate and submit sbatch
    sbatch = _create_sbatch_script(
        job_name=name,
        route=route,
        entrypoint=entrypoint,
        remote_job_dir=remote_job_dir,
        n_cpus=n_cpus,
        n_gpus=actual_n_gpus,
        memory=memory,
        time_limit=time,
        env=env,
    )

    slurm_id = _submit_via_ssh(route.cluster, remote_job_dir, sbatch)

    console.print(
        f"Submitted [bold]{name}[/] → Slurm job [bold cyan]{slurm_id}[/] "
        f"on [bold]{route.cluster.name}[/]"
    )

    return Job(
        job_id=name,
        job_name=name,
        cluster_name=route.cluster.name,
        cluster_config=route.cluster,
        remote_dir=remote_job_dir,
        slurm_job_id=slurm_id,
        metadata={
            "script": str(script),
            "args": args,
            "gpu": gpu,
            "n_gpus": actual_n_gpus,
            "memory": memory,
            "time": time,
            "submitted_at": datetime.now().isoformat(),
        },
    )
