{% if assisted %}
bash assisted-service.sh
{% endif %}
