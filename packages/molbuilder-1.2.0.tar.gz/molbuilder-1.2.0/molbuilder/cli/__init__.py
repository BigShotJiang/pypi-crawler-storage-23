"""Command-line interface: menus, demos, interactive wizard."""
