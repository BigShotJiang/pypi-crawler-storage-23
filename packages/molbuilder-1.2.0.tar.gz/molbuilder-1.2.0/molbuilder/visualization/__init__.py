"""Visualization: Bohr models, orbital clouds, molecule rendering,
and extreme slow-motion atomic interaction animations."""
