"""Peptide construction: bond formation, phi/psi, secondary structure.

The implementation lives in amino_acids.py. This module provides
convenient direct imports.
"""
