"""Interactive 3D GUI for molecule building and analysis."""
from molbuilder.gui.app import launch
