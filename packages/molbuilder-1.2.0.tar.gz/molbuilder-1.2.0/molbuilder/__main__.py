"""Entry point for `python -m molbuilder`."""

from molbuilder.cli.menu import main

if __name__ == "__main__":
    main()
