from . import text_files as txt

__all__ = ["txt"]
