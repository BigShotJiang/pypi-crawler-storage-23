"""Tests for hytop.net.render helpers."""

from __future__ import annotations

from hytop.net.render import format_iface_name, format_rate, split_iface_key


class TestFormatIfaceName:
    def test_keep_name_when_up(self):
        assert format_iface_name("eth0", "up") == "eth0"

    def test_mark_down_state(self):
        assert format_iface_name("eth0", "down") == "eth0 (down)"

    def test_mark_init_state(self):
        assert format_iface_name("mlx5_0/p1", "init") == "mlx5_0/p1 (down)"


class TestFormatRate:
    def test_zero(self):
        assert format_rate(0.0) == "   0.00 B/s"

    def test_bytes(self):
        assert format_rate(512.0) == " 512.00 B/s"

    def test_kilobytes(self):
        result = format_rate(1500.0)
        assert "kB/s" in result

    def test_megabytes(self):
        result = format_rate(2_000_000.0)
        assert "MB/s" in result

    def test_gigabytes(self):
        result = format_rate(3_000_000_000.0)
        assert "GB/s" in result

    def test_iec_kibibytes(self):
        result = format_rate(2048.0, iec=True)
        assert "KiB/s" in result

    def test_iec_mebibytes(self):
        result = format_rate(2 * 1024 * 1024.0, iec=True)
        assert "MiB/s" in result

    def test_iec_gibibytes(self):
        result = format_rate(2 * 1024**3, iec=True)
        assert "GiB/s" in result


class TestSplitIfaceKey:
    def test_eth(self):
        assert split_iface_key("eth:eth0") == ("eth", "eth0")

    def test_ib(self):
        assert split_iface_key("ib:mlx5_0/p1") == ("ib", "mlx5_0/p1")
