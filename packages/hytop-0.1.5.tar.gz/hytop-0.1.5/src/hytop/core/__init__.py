"""Core shared utilities for hytop commands."""
