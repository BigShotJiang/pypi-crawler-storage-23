from __future__ import annotations


def fmt_window(window_s: float) -> str:
    """Format a window duration for display.

    Args:
        window_s: Window duration in seconds.

    Returns:
        Human-readable duration string.
    """
    return f"{int(window_s)}s" if window_s.is_integer() else f"{window_s:.1f}s"


def fmt_elapsed(elapsed_s: float) -> str:
    """Format elapsed seconds as HH:MM:SS.

    Args:
        elapsed_s: Elapsed seconds.

    Returns:
        Formatted time string.
    """
    total_seconds = max(0, int(elapsed_s))
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
