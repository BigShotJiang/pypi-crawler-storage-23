"""Network monitoring commands for hytop."""
