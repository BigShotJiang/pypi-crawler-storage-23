"""
Entry point for running root_engine as a module: python -m root_engine
"""

from root_engine.cli.commands import app

if __name__ == "__main__":
    app()
