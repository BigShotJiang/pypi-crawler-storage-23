ADDON_MAP = {
    "addon_nowcast_enabled": "nowfy_nowcast",
    "addon_floatity_enabled": "nowfy_floatify",
}

THEME_ALIAS_MAP = {
    "core_theme_spotlight_enabled": "spotlight",
    "core_theme_nowv_enabled": "nowv",
}


def _get_setting(plugin, key, default=None):
    try:
        return plugin.get_setting(str(key), default)
    except Exception:
        return default


def is_addon_enabled(plugin, addon_key, default_value=False):
    key = str(addon_key or "").strip()
    if not key:
        return bool(default_value)
    try:
        # If host exposes plugin-file probe, respect it for optional addons.
        pid = ADDON_MAP.get(key)
        if pid and hasattr(plugin, "_is_plugin_file_present"):
            try:
                if not bool(plugin._is_plugin_file_present(pid)):
                    return False
            except Exception:
                pass
        return bool(_get_setting(plugin, key, bool(default_value)))
    except Exception:
        return bool(default_value)


def is_theme_enabled(plugin, theme_key, default_value=False, core_enabled_optional_themes=""):
    key = str(theme_key or "").strip()
    if not key:
        return bool(default_value)
    try:
        raw = str(core_enabled_optional_themes or "").strip()
        if not raw:
            raw = str(_get_setting(plugin, "core_enabled_optional_themes", "") or "").strip()
        if raw:
            enabled = set([x.strip().lower() for x in raw.split(",") if str(x).strip()])
            marker = THEME_ALIAS_MAP.get(key, "")
            if marker:
                return marker in enabled
        return bool(_get_setting(plugin, key, bool(default_value)))
    except Exception:
        return bool(default_value)
