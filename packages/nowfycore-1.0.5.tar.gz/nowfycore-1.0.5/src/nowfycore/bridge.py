def invoke_action(plugin, action_name):
    """Invoke a runtime method on host plugin during staged migration."""
    try:
        name = str(action_name or "").strip()
        if not name:
            return False
        fn = getattr(plugin, name, None)
        if not callable(fn):
            return False
        fn()
        return True
    except Exception:
        return False
