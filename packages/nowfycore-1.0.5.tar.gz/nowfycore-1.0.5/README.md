# nowfycore

Pure Python core runtime for Nowfy.

## Local build

```bash
python -m build packages/nowfycore
```

Artifacts:
- `packages/nowfycore/dist/nowfycore-1.0.2-py3-none-any.whl`
- `packages/nowfycore/dist/nowfycore-1.0.2.tar.gz`

## Release helper

```bash
python packages/nowfycore/scripts/release_nowfycore.py
python packages/nowfycore/scripts/release_nowfycore.py --upload --repository pypi
```

Optional:
- `--repository testpypi`
- `--skip-existing`

## Runtime usage in Nowfy plugin

`nowfy.plugin` uses:

```python
__requirements__ = ["nowfycore>=1.0.2"]
```

So only `nowfy.plugin` needs to be installed by the user; core runtime is resolved through requirements.
