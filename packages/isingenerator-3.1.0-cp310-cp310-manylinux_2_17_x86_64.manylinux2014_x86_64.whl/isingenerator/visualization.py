"""
==============================================================================
ISINGenerator Visualization, "Graphical" (:mod: `isingenerator.visualization`)
==============================================================================
This module provides high-quality visualizations for the 2D Ising model 
simulations performed by ISINGenerator. It includes functions to plot 
key physical quantities such as magnetization, energy, domain statistics, 
and Forman-Ricci curvature, as well as a comprehensive dashboard summarizing 
all metrics.

Classes
-------
.. autosummary::
    :toctree: generated/
    
    IsingVisualization

Methods
-------
.. autosummary::
    :toctree: generated/
    IsingVisualization.plot_magnetization
    IsingVisualization.plot_energy
    IsingVisualization.plot_domains
    IsingVisualization.plot_domain_sizes
    IsingVisualization.plot_forman_ricci
    IsingVisualization.plot_curvature_components
    IsingVisualization.plot_lattice
    IsingVisualization.plot_dashboard
    IsingVisualization.plot_magnetization_and_energy
    IsingVisualization.save_all

See also
--------
- :mod:`isingenerator.simulation` for running the simulations that produce the data.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import AutoMinorLocator
from matplotlib import gridspec


class Palette:
    """Colours for the plot
    """
    red         = "#CC2529"
    blue        = "#396AB1"
    green       = "#3E9651"
    orange      = "#DA7C30"
    purple      = "#6B4C9A"
    teal        = "#22827C"
    gray        = "#535154"
    light_gray  = "#D0D0D0"
    grid_color  = "#E8E8E8"
    background  = "#FFFFFF"
    panel_bg    = "#F9F9F9"

    cycle = [blue, red, green, orange, purple, teal, gray]

# Marker styles cycled per series
_MARKERS = ["o", "s", "^", "D", "v", "P", "X"]

def _set_style() -> None:
    """Style for the plot.
    """
    plt.rcdefaults()
    mpl.rcParams.update({
        "text.usetex": True,
        "text.latex.preamble": r"\usepackage{amsmath}\usepackage{amssymb}",
        "font.family": "serif",
        "font.serif": ["Computer Modern Roman", "DejaVu Serif"],
        "mathtext.fontset": "cm",

        # Figure
        "figure.figsize": (7.0, 4.5),
        "figure.dpi": 150,
        "figure.facecolor": Palette.background,
        "figure.edgecolor": Palette.background,

        # Axes
        "axes.facecolor": Palette.background,
        "axes.edgecolor": "#AAAAAA",
        "axes.linewidth": 0.8,
        "axes.labelsize": 13,
        "axes.titlesize": 14,
        "axes.titlepad": 10,
        "axes.labelpad": 6,
        "axes.spines.top": True,
        "axes.spines.right": True,
        "axes.prop_cycle": mpl.cycler(color=Palette.cycle),

        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "xtick.major.size": 5,
        "ytick.major.size": 5,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.minor.width": 0.5,
        "ytick.minor.width": 0.5,
        "xtick.top": True,
        "ytick.right": True,

        # Grid
        "axes.grid": True,
        "grid.color": Palette.grid_color,
        "grid.linewidth": 0.6,
        "grid.linestyle": "-",
        "grid.alpha": 1.0,

        # Lines & markers
        "lines.linewidth": 1.0,
        "lines.markersize": 4.5,
        "lines.markeredgewidth": 0.6,
        "lines.solid_capstyle": "round",
        "lines.solid_joinstyle": "round",

        # Legend
        "legend.fontsize": 10,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.edgecolor": "#CCCCCC",
        "legend.fancybox": False,
        "legend.borderpad": 0.5,
        "legend.labelspacing": 0.3,

        # Save
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.08,
        "savefig.facecolor": Palette.background,
        "savefig.dpi": 300,
    })


_set_style()

TC = 2.0 / np.log(1.0 + np.sqrt(2.0))


def _n_markers(n: int, target: int = 30) -> int:
    """Return a sensible markevery stride so ~target markers appear."""
    return max(1, n // target)


def _plot_line(ax, x, y, color, label, marker="o", linestyle="-") -> None:
    """
    Plot a line with markers at every data point (or thinned if dense).
    Lines are thin; markers are solid with a white edge for readability.
    """
    n = len(x)
    me = _n_markers(n)
    ax.plot(
        x, y,
        color=color,
        linewidth=0.9,
        linestyle=linestyle,
        marker=marker,
        markevery=me,
        markersize=4.5,
        markerfacecolor=color,
        markeredgecolor="white",
        markeredgewidth=0.6,
        label=label,
        zorder=3,
    )


def _add_tc_line(ax, label: bool = True, color: str = "#999999") -> None:
    """Draw a vertical dashed line at T_c

    Args:
        ax (plt.axes): The matplotlib axes to draw on.
        label (bool, optional): Whether to label the line. Defaults to True.
        color (str, optional): The color of the line. Defaults to "#999999".
    """
    ax.axvline(TC, color=color, linewidth=0.9, linestyle="--", zorder=1)
    if label:
        ax.text(
            TC + 0.03, ax.get_ylim()[1] * 0.97,
            r"$T_c$",
            fontsize=10,
            color=color,
            va="top",
            ha="left",
        )


def _style_axes(ax, xlabel: str, ylabel: str, title: str = "") -> None:
    """Apply styles for the axes.

    Args:
        ax (plt.axes): The matplotlib axes to style.
        xlabel (str): The label for the x-axis.
        ylabel (str): The label for the y-axis.
        title (str, optional): The title for the axes. Defaults to "".
    """
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title, pad=10)
    ax.xaxis.set_minor_locator(AutoMinorLocator(4))
    ax.yaxis.set_minor_locator(AutoMinorLocator(4))
    ax.set_axisbelow(True)


def _finalize(fig, tight: bool = True) -> None:
    """Finalize the figure by applying tight_layout and any other final adjustments.

    Args:
        fig (plt.Figure): The matplotlib.Figure object to finalize.
        tight (bool, optional): Whether to call tight_layout(). Defaults to True.
    """
    if tight:
        fig.tight_layout()

class IsingVisualization:
    """
    Visualization for simulation data.

    Parameters
    ----------
    data : dict returned by Simulation.run_temperature_range()
    """

    def __init__(self, data: dict):
        self.T = np.asarray(data["temperature"])
        self.beta = np.asarray(data["beta"])

        self.M = np.asarray(data["magnetization"])
        self.E = np.asarray(data["energy"])

        self.domains_total = np.asarray(data["total_domains"])
        self.domains_pos = np.asarray(data["positive_domains"])
        self.domains_neg = np.asarray(data["negative_domains"])

        self.avg_pos = np.asarray(data["positive_avg_size"])
        self.avg_neg = np.asarray(data["negative_avg_size"])

        self.frc_total = np.asarray(data["frc_total_curvature"])
        self.frc_mean  = np.asarray(data["frc_mean_curvature"])
        self.frc_nodes = np.asarray(data["frc_positive_nodes"])
        self.frc_edges = np.asarray(data["frc_edges"])

    def plot_magnetization(self, save: str | None = None) -> plt.Figure:
        """Method for plotting the magnetization for the Ising 2D model.

        Args:
            save (str | None, optional): The folder to store the image. Defaults to None.

        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots()
        _plot_line(
            ax, 
            self.T, 
            np.abs(self.M),
            color=Palette.blue,
            label=r"$|\langle m \rangle|$",
            marker="o"
        )
        _style_axes(
            ax,
            xlabel=r"Temperature $T$",
            ylabel=r"Magnetization $|\langle m \rangle|$",
            title=r"Magnetization vs.\ Temperature",
        )
        _add_tc_line(ax)
        ax.legend()
        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_energy(self, save: str | None = None) -> plt.Figure:
        """Plot the internal energy of the Ising 2D model.

        Args:
            save (str | None, optional): If provided, save the figure to this path.

        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots()
        _plot_line(
            ax,
            self.T,
            self.E,
            color=Palette.red,
            label=r"$\langle E \rangle / N$",
            marker="s"
        )
        _style_axes(
            ax,
            xlabel=r"Temperature $T$",
            ylabel=r"Energy per spin $\langle E \rangle / N$",
            title=r"Internal Energy vs.\ Temperature",
        )
        _add_tc_line(ax)
        ax.legend()
        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_domains(self, save: str | None = None) -> plt.Figure:
        """Plot the total number of domains and the breakdown into 
        positive and negative domains as a function of temperature.

        Args:
            save (str | None, optional): If provided, save the figure to this path.

        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots()
        _plot_line(
            ax,
            self.T,
            self.domains_total,
            color=Palette.gray,
            label=r"Total domains",
            marker="o"
        )
        _plot_line(
            ax,
            self.T,
            self.domains_pos,
            color=Palette.blue,
            label=r"Positive ($\sigma=+1$)",
            marker="s"
        )
        _plot_line(
            ax,
            self.T,
            self.domains_neg,
            color=Palette.red,
            label=r"Negative ($\sigma=-1$)",
            marker="^"
        )
        _style_axes(
            ax,
            xlabel=r"Temperature $T$",
            ylabel=r"Number of domains",
            title=r"Magnetic Domain Statistics",
        )
        _add_tc_line(ax)
        ax.legend()
        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_domain_sizes(self, save: str | None = None) -> plt.Figure:
        """Plot the average domain size for positive and negative spins.

        Args:
            save (str | None, optional): If provided, save the figure to this path.

        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots()
        _plot_line(
            ax,
            self.T,
            self.avg_pos,
            color=Palette.blue,
            label=r"$\langle s \rangle_{+}$",
            marker="o"
        )
        _plot_line(
            ax,
            self.T,
            self.avg_neg,
            color=Palette.red,
            label=r"$\langle s \rangle_{-}$",
            marker="s"
        )
        _style_axes(
            ax,
            xlabel=r"Temperature $T$",
            ylabel=r"Average domain size",
            title=r"Average Domain Size vs.\ Temperature",
        )
        _add_tc_line(ax)
        ax.legend()
        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_forman_ricci(self, save: str | None = None) -> plt.Figure:
        """Plot the total and mean Forman--Ricci curvature of the spin 
        lattice as a function of temperature.

        Args:
            save (str | None, optional): If provided, save the figure to this path.

        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots()
        _plot_line(
            ax,
            self.T,
            self.frc_total,
            color=Palette.purple, marker="o",
            label=r"Total curvature $\sum_e \mathcal{F}(e)$"
        )
        _plot_line(
            ax,
            self.T,
            self.frc_mean,
            color=Palette.teal,
            marker="s",
            linestyle="--",
            label=r"Mean curvature $\langle \mathcal{F} \rangle$"
        )
        _style_axes(
            ax,
            xlabel=r"Temperature $T$",
            ylabel=r"Forman--Ricci curvature",
            title=r"Forman--Ricci Curvature vs.\ Temperature",
        )
        _add_tc_line(ax)
        ax.legend()
        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_curvature_components(self, save: str | None = None) -> plt.Figure:
        """Plot the node and edge contributions to the Forman--Ricci curvature separately.

        Args:
            save (str | None, optional): If provided, save the figure to this path.

        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots()
        _plot_line(ax, self.T, self.frc_nodes,
                   color=Palette.orange, label=r"Positive nodes $n_+$",   marker="o")
        _plot_line(ax, self.T, self.frc_edges,
                   color=Palette.teal,   label=r"Edges $|E|$",            marker="s")
        _style_axes(
            ax,
            xlabel=r"Temperature $T$",
            ylabel=r"Count",
            title=r"Forman--Ricci Graph Components",
        )
        _add_tc_line(ax)
        ax.legend()
        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_lattice(
        self,
        lattice: np.ndarray,
        temperature: float | None = None,
        save: str | None = None,
    ) -> plt.Figure:
        """
        Render the spin lattice as a high-quality binary heatmap.
        
        Args:
            lattice (np.ndarray): 2D array of shape (N, N) with values in {-1, +1}.
            temperature (float | None, optional): If provided, include T in the title.
            save (str | None, optional): If provided, save the figure to this path.
        
        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax = plt.subplots(figsize=(5.5, 5.5))

        cmap = mpl.colors.ListedColormap([Palette.blue, "#FAFAFA"])
        ax.imshow(
            lattice,
            cmap=cmap,
            interpolation="nearest",
            aspect="equal",
            vmin=-1,
            vmax=1,
        )

        ax.set_xticks([])
        ax.set_yticks([])

        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(0.8)
            spine.set_edgecolor("#AAAAAA")

        title = r"Spin Configuration"
        if temperature is not None:
            title += rf" \ \ $(T = {temperature:.3f})$"
        ax.set_title(title, pad=10)

        n = lattice.shape[0]
        ax.text(
            0.02, 0.02,
            rf"$N = {n} \times {n}$",
            transform=ax.transAxes,
            fontsize=9,
            color=Palette.gray,
            va="bottom",
        )

        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_dashboard(self, save: str | None = None) -> plt.Figure:
        """Six-panel summary figure.
            
        Args:    
            save (str | None, optional): If provided, save the figure to this path.
            
        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig = plt.figure(figsize=(13, 9))
        fig.patch.set_facecolor(Palette.background)

        gs = gridspec.GridSpec(
            3, 2,
            figure=fig,
            hspace=0.50,
            wspace=0.35,
            left=0.08,
            right=0.97,
            top=0.93,
            bottom=0.07,
        )

        panels = [
            (0, 0, self.T, np.abs(self.M), Palette.blue, "o", r"$|\langle m \rangle|$", r"Magnetization"),
            (0, 1, self.T, self.E, Palette.red, "s", r"$\langle E \rangle / N$", r"Internal Energy"),
            (1, 0, self.T, self.domains_total, Palette.gray, "o", r"Domains", r"Total Domains"),
            (1, 1, self.T, self.avg_pos, Palette.teal, "^", r"$\langle s \rangle_+$", r"Avg.\ Domain Size~$(+)$"),
            (2, 0, self.T, self.frc_total, Palette.purple, "D", r"$\sum \mathcal{F}$", r"Total Curvature"),
            (2, 1, self.T, self.frc_mean, Palette.orange, "v", r"$\langle \mathcal{F} \rangle$", r"Mean Curvature"),
        ]

        for (row, col, xd, yd, color, marker, ylabel, title) in panels:
            ax = fig.add_subplot(gs[row, col])
            n = len(xd)
            me = _n_markers(n)
            ax.plot(
                xd,
                yd,
                color=color,
                linewidth=0.9,
                marker=marker,
                markevery=me,
                markersize=4.0,
                markerfacecolor=color,
                markeredgecolor="white",
                markeredgewidth=0.5,
            )
            ax.set_xlabel(r"$T$", labelpad=3)
            ax.set_ylabel(ylabel, labelpad=4)
            ax.set_title(title, pad=7)
            ax.xaxis.set_minor_locator(AutoMinorLocator(4))
            ax.yaxis.set_minor_locator(AutoMinorLocator(4))
            ax.set_axisbelow(True)
            ax.axvline(
                TC,
                color="#AAAAAA",
                linewidth=0.8,
                linestyle="--",
                zorder=1
            )

        fig.suptitle(
            r"ISINGenerator --- 2D Ising Model Summary",
            fontsize=16,
            y=0.975,
            color="#222222",
        )

        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def plot_magnetization_and_energy(self, save: str | None = None) -> plt.Figure:
        """Dual-axis plot: magnetization (left) and energy (right).
        
        Args:
            save (str | None, optional): If provided, save the figure to this path.
        
        Returns:
            plt.Figure: The matplotlib figure object.
        """
        fig, ax1 = plt.subplots(figsize=(7.5, 4.5))
        ax2 = ax1.twinx()

        n = len(self.T)
        me = _n_markers(n)

        l1, = ax1.plot(
            self.T, 
            np.abs(self.M),
            color=Palette.blue,
            linewidth=0.9,
            marker="o",
            markevery=me,
            markersize=4.5,
            markerfacecolor=Palette.blue,
            markeredgecolor="white",
            markeredgewidth=0.6,
            label=r"$|\langle m \rangle|$",
        )
        l2, = ax2.plot(
            self.T,
            self.E,
            color=Palette.red,
            linewidth=0.9,
            linestyle="--",
            marker="s",
            markevery=me,
            markersize=4.5,
            markerfacecolor=Palette.red,
            markeredgecolor="white",
            markeredgewidth=0.6,
            label=r"$\langle E \rangle / N$",
        )

        ax1.set_xlabel(r"Temperature $T$")
        ax1.set_ylabel(
            r"Magnetization $|\langle m \rangle|$",
            color=Palette.blue
        )
        ax2.set_ylabel(
            r"Energy per spin $\langle E \rangle / N$",
            color=Palette.red
        )

        ax1.tick_params(axis="y", colors=Palette.blue)
        ax2.tick_params(axis="y", colors=Palette.red)

        ax1.xaxis.set_minor_locator(AutoMinorLocator(4))
        ax1.yaxis.set_minor_locator(AutoMinorLocator(4))
        ax2.yaxis.set_minor_locator(AutoMinorLocator(4))

        ax1.set_title(r"Magnetization \& Energy vs.\ Temperature")
        ax1.axvline(
            TC, 
            color="#AAAAAA",
            linewidth=0.9,
            linestyle="--",
            zorder=1
        )
        ax1.text(
            TC + 0.03,
            0.97,
            r"$T_c$",
            transform=ax1.get_xaxis_transform(),
            fontsize=10,
            color="#999999",
            va="top"
        )

        lines = [l1, l2]
        labels = [l.get_label() for l in lines]
        ax1.legend(lines, labels, loc="upper right")
        ax1.set_axisbelow(True)

        _finalize(fig)
        if save:
            fig.savefig(save)
        plt.show()
        return fig

    def save_all(self, directory: str = "figures", fmt: str = "pdf"):
        """Save every standard figure to directory

        Args:
            directory (str, optional): Path to store the figures. Defaults to "figures".
            fmt (str, optional): File format for saving figures. Defaults to "pdf".
        """
        out = Path(directory)
        out.mkdir(parents=True, exist_ok=True)

        self.plot_magnetization(save=str(out / f"magnetization.{fmt}"))
        self.plot_energy(save=str(out / f"energy.{fmt}"))
        self.plot_domains(save=str(out / f"domains.{fmt}"))
        self.plot_domain_sizes(save=str(out / f"domain_sizes.{fmt}"))
        self.plot_forman_ricci(save=str(out / f"forman_ricci.{fmt}"))
        self.plot_curvature_components(save=str(out / f"curvature_components.{fmt}"))
        self.plot_magnetization_and_energy(save=str(out / f"mag_energy.{fmt}"))
        self.plot_dashboard(save=str(out / f"dashboard.{fmt}"))
        