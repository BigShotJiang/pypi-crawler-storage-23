"""
ISINGenerator
=============

High-performance 2D Ising model Monte Carlo simulation.

Quick start
-----------
>>> from isingenerator import Simulation
>>> sim = Simulation(rows=500, cols=500, J=1.0)
>>> result = sim.run_single_temperature(
...     temperature=2.3,
...     equilibration_sweeps=100_000,
...     measurement_blocks=1000,
...     sweeps_per_block=100,
...     threads=4,
... )
>>> print(result["magnetization"], result["forman_ricci_mean_curvature"])
"""

from .simulation import Simulation, SimulationParameters
from .visualization import IsingVisualization

# Low-level C++ classes (for advanced users / testing)
from ._core import (
    Lattice,
    DomainResult,
    FormanRicciResult,
    FormanRicci,
)

__version__ = "3.1.0"

__all__ = [
    # High-level Python API
    "Simulation",
    "SimulationParameters",
    "IsingVisualization",
    # Low-level C++ bindings
    "Lattice",
    "DomainResult",
    "FormanRicciResult",
    "FormanRicci",
]