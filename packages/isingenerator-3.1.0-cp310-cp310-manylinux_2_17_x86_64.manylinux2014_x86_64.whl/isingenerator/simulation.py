"""
======================================================================
ISINGenerator Simulation, "Physics" (:mod: `isingenerator.simulation`)
======================================================================

This module provides a Python wrapper over the C++ Simulation class.

Classes
-------
.. autosummary::
    :toctree: generated
    
    SimulationParameters
    Simulation
    
Methods
-------
.. autosummary::
    :toctree: generated
    
    Simulation.from_parameters
    Simulation.run_with_parameters
    Simulation.save_frames
    Simulation.save_frames_forman_ricci
    Simulation.run_single_temperature
    Simulation.run_temperature_range
    Simulation.get_lattice
    Simulation.randomize

See also
--------
- :mod:`isingenerator._core` — C++ backend implementation (not for direct use)

"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import datetime

from . import _core

@dataclass
class SimulationParameters:
    """
    All parameters for an Ising simulation. 
    Lattice
    -------
    rows, cols: lattice dimensions
    p: Probability for (spin=+1) for random initialisation (default 0.5)
    seed: RNG seed for reproducibility (0 = random)

    Physics
    -------
    J: Ferromagnetic coupling constant (J > 0)
    B: External magnetic field

    Temperature scan
    ----------------
    min_temperature: Start of temperature sweep
    max_temperature: End of temperature sweep
    temperature_step: Increment between temperatures

    Sampling
    --------
    equilibration_sweeps: Sweeps before measuring (discard transient)
    measurement_blocks: Number of measurement blocks
    sweeps_per_block: Sweeps between measurements

    Performance
    -----------
    threads: OpenMP thread count
    output_csv: path for CSV output (auto-named if None)
    """

    rows: int = 100
    cols: int = 100
    p: float = 0.5
    seed: int = 0

    J: float = 1.0
    B: float = 0.0

    min_temperature: float = 1.0
    max_temperature: float = 4.0
    temperature_step: float = 0.1

    equilibration_sweeps: int = 10_000
    measurement_blocks: int = 1_000
    sweeps_per_block: int = 100

    threads: int = 1
    output_csv: str = None

    def __post_init__(self):
        if self.output_csv is None:
            date = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            self.output_csv = f"ising_output_{date}.csv"

class Simulation:
    """
    High-level interface to the ISINGenerator C++ backend.

    The Simulation class provides the standard Ising numerical simulation methods
    as well as additional observables related to domain structure and Forman-Ricci curvature.
    """

    def __init__(
        self,
        rows: int = 100,
        cols: int = 100,
        J: float = 1.0,
        B: float = 0.0,
        p: float = 0.5,
        seed: int = 0,
    ) -> None:
        """Constructor for the Simulation class.

        Args:
            rows (int, optional): The number of rows in the lattice. Defaults to 100.
            cols (int, optional): The number of columns in the lattice. Defaults to 100.
            J (float, optional): The ferromagnetic coupling constant. Defaults to 1.0.
            B (float, optional): The external magnetic field strength. Defaults to 0.0.
            p (float, optional): The probability of a spin being +1 in random initialisation. Defaults to 0.5.
            seed (int, optional): The random number generator seed for reproducibility. Defaults to 0.
        """
        self._sim = _core.Simulation(
            rows             = rows,
            cols             = cols,
            probability      = p,
            interaction_coeff= J,
            external_field   = B,
            seed             = seed,
        )
        self.rows = rows
        self.cols = cols
        self.J = J
        self.B = B
        self.p = p

    def get_lattice(self):
        """Numpy int8 view of spins, shape (rows, cols).
        
        Returns:
            np.ndarray: 2D array of spins, where each element is either +1 or -1.
        """
        return self._sim.get_lattice()

    def randomize(self, p: float = 0.5, seed: int = 0) -> None:
        """Randomize the lattice with probability p for spin = +1.
        
        Args:
            p (float, optional): The probability of a spin being +1. Defaults to 0.5.
            seed (int, optional): The random number generator seed for reproducibility. Defaults to 0.
        """
        self._sim.randomize(p, seed)

    def run_single_temperature(
        self,
        temperature:          float,
        equilibration_sweeps: int   = 10_000,
        measurement_blocks:   int   = 1_000,
        sweeps_per_block:     int   = 100,
        threads:              int   = 1,
    ) -> dict:
        """Equilibrate then measure at a single temperature.

        Args:
            temperature (float): The temperature at which to run the simulation.
            equilibration_sweeps (int, optional): The number of sweeps to run for equilibration. Defaults to 10_000.
            measurement_blocks (int, optional): The number of measurement blocks to run. Defaults to 1_000.
            sweeps_per_block (int, optional): The number of sweeps per measurement block. Defaults to 100.
            threads (int, optional): The number of threads to use for parallel execution. Defaults to 1.

        Returns:
            dict: A dictionary containing the measured observables at the given
            temperature. The keys include "temperature", "beta", 
            "magnetization", "energy", "total_domains", "positive_domains", 
            "negative_domains", "positive_avg_size", "negative_avg_size",
            "forman_ricci_total_curvature", "forman_ricci_mean_curvature",
            "forman_ricci_positive_nodes", and "forman_ricci_edges".
        """
        return self._sim.run_single_temperature(
            temperature,
            equilibration_sweeps,
            measurement_blocks,
            sweeps_per_block,
            threads,
        )

    def run_temperature_range(
        self,
        min_temperature:      float = 1.0,
        max_temperature:      float = 4.0,
        temperature_step:     float = 0.1,
        equilibration_sweeps: int   = 10_000,
        measurement_blocks:   int   = 1_000,
        sweeps_per_block:     int   = 100,
        threads:              int   = 1,
        output_csv:           str   = None,
    ) -> dict:
        """Method to implement Monte Carlo simulation for the Ising model 2D.
        

        Args:
            min_temperature (float, optional): The minimum temperature to run the simulation at. Defaults to 1.0.
            max_temperature (float, optional): The maximum temperature to run the simulation at. Defaults to 4.0.
            temperature_step (float, optional): The step size for the temperature range. Defaults to 0.1.
            equilibration_sweeps (int, optional): The number of sweeps to run for equilibration at each temperature. Defaults to 10_000.
            measurement_blocks (int, optional): The number of measurement blocks to run at each temperature. Defaults to 1_000.
            sweeps_per_block (int, optional): The number of sweeps per measurement block. Defaults to 100.
            threads (int, optional): The number of threads to use for parallel execution. Defaults to 1.
            output_csv (str, optional): The path to the output CSV file. If None, an auto-generated filename is used. Defaults to None.

        Returns:
            dict: A dictionary containing the measured observables at each
            temperature. The keys include "temperature", "beta", 
            "magnetization", "energy", "total_domains", "positive_domains", 
            "negative_domains", "positive_avg_size", "negative_avg_size",
            "forman_ricci_total_curvature", "forman_ricci_mean_curvature",
            "forman_ricci_positive_nodes", "forman_ricci_edges" for each temperature
            in the specified range. Additionally, the results are saved to a CSV file if
            output is specified (or auto-named if None)
        """
        if output_csv is None:
            date = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            output_csv = f"ising_output_{date}.csv"

        return self._sim.run_temperature_range(
            min_temperature,
            max_temperature,
            temperature_step,
            equilibration_sweeps,
            measurement_blocks,
            sweeps_per_block,
            threads,
            output_csv,
        )

    @classmethod
    def from_parameters(cls, params: SimulationParameters) -> Simulation:
        """Equilibrate then measure at a single temperature.

        Args:
            params (SimulationParameters): The parameters for the simulation.

        Returns:
            dict: A dictionary containing the measured observables at the given
            temperature. The keys include "temperature", "beta", 
            "magnetization", "energy", "total_domains", "positive_domains", 
            "negative_domains", "positive_avg_size", "negative_avg_size",
            "forman_ricci_total_curvature", "forman_ricci_mean_curvature",
            "forman_ricci_positive_nodes", and "forman_ricci_edges".
        """
        return cls(
            rows=params.rows,
            cols=params.cols,
            J=params.J,
            B=params.B,
            p=params.p,
            seed=params.seed,
        )

    def run_with_parameters(self, params: SimulationParameters) -> dict:
        """Run a full temperature sweep from a SimulationParameters object.
        
        Args:
            params (SimulationParameters): The parameters for the simulation.
        
        Returns:
            dict: A dictionary containing the measured observables at each
            temperature. The keys include "temperature", "beta",
            "magnetization", "energy", "total_domains", "positive_domains",
            "negative_domains", "positive_avg_size", "negative_avg_size",
            "forman_ricci_total_curvature", "forman_ricci_mean_curvature",
            "forman_ricci_positive_nodes", "forman_ricci_edges" for each temperature
            in the specified range. Additionally, the results are saved to a CSV file if
            output is specified (or auto-named if None)
        """
        return self.run_temperature_range(
            min_temperature      = params.min_temperature,
            max_temperature      = params.max_temperature,
            temperature_step     = params.temperature_step,
            equilibration_sweeps = params.equilibration_sweeps,
            measurement_blocks   = params.measurement_blocks,
            sweeps_per_block     = params.sweeps_per_block,
            threads              = params.threads,
            output_csv           = params.output_csv,
        )

    def save_frames(
        self,
        temperature:          float,
        equilibration_sweeps: int   = 10_000,
        measurement_blocks:   int   = 500,
        sweeps_per_block:     int   = 100,
        threads:              int   = 1,
        folder:               str   = "frames",
    ) -> None:
        """
        Save spin PPM frames at fixed temperature.
        <folder>/frame_XXXXXX.ppm.
        Args:
        
            temperature (float): The temperature at which to run the simulation.
            equilibration_sweeps (int, optional): The number of sweeps to run for
            equilibration. Defaults to 10_000.
            measurement_blocks (int, optional): The number of measurement blocks to run. Defaults to 500.
            sweeps_per_block (int, optional): The number of sweeps per measurement block. Defaults to 100.
            threads (int, optional): The number of threads to use for parallel execution. Defaults to 1.
            folder (str, optional): The folder to save the frames in. Defaults to "frames".
        """
        Path(folder).mkdir(parents=True, exist_ok=True)
        self._sim.save_frames(
            temperature, equilibration_sweeps,
            measurement_blocks, sweeps_per_block,
            threads, folder,
        )

    def save_frames_forman_ricci(
        self,
        temperature:          float,
        equilibration_sweeps: int   = 10_000,
        measurement_blocks:   int   = 500,
        sweeps_per_block:     int   = 100,
        threads:              int   = 1,
        folder:               str   = "frames_ricci",
    ) -> None:
        """
        Save Forman-Ricci degree PPM frames at fixed temperature.
        <folder>/frame_XXXXXX.ppm
        Args:
            temperature (float): The temperature at which to run the simulation.
            equilibration_sweeps (int, optional): The number of sweeps to run for
            equilibration. Defaults to 10_000.
            measurement_blocks (int, optional): The number of measurement blocks to run. Defaults to 500.
            sweeps_per_block (int, optional): The number of sweeps per measurement block. Defaults to 100.
            threads (int, optional): The number of threads to use for parallel execution. Defaults to 1.
            folder (str, optional): The folder to save the frames in. Defaults to "frames_ricci".
        """
        Path(folder).mkdir(parents=True, exist_ok=True)
        self._sim.save_frames_forman_ricci(
            temperature, equilibration_sweeps,
            measurement_blocks, sweeps_per_block,
            threads, folder,
        )