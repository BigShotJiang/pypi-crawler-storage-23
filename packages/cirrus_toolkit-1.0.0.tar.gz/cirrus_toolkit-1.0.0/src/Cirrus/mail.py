"""
Mail Class Wrapper
A lightweight Python wrapper for sending emails via SMTP using smtplib.
Features
Simple object-oriented interface.
Supports plain text messages.
Handles SMTP server connection and cleanup.
Usage
python
from mail_script import Mail

# Initialize the Mailer
mailer = Mail(
    host="://example.com",
    port=587,
    authenticate="true",
    user_name="Your Name",
    user_email="your@email.com",
    password="yourpassword"
)

# Send an email
mailer.SendMail(
    to_name="Recipient Name",
    to_email="recipient@example.com",
    subject="Hello from Python",
    message="This is a test email sent using the Mail class."
)
Use code with caution.

Constructor Parameters
host: The SMTP server address.
port: The port number (e.g., 587 or 25).
authenticate: A string "true" or "false" to toggle authentication.
user_name: Name of the sender.
user_email: Email address of the sender.
password: Password for the SMTP server.
Note
The current version of this script uses smtplib.SMTP for standard connections. For secure connections (SSL/TLS), ensure your host and port settings are compatible with your email provider's requirements.

import smtplib, sys
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


class Mail:
	_error = False

	_host = ""
	_port = ""
	_authenticate = False
	_user_name = ""
	_user_email = ""
	_password = ""
"""

	#== Constructor ===============================================================================


	def __init__(this, host, port, authenticate, user_name, user_email, password):
		this._host = host
		this._authenticate = True if authenticate == "true" else False
		this._user_name = user_name
		this._user_email = user_email
		this._password = password

		#this.DisplayHelp()		


	#== Methods ===================================================================================


	def SendMail(this, to_name, to_email, subject, message):
		msg = MIMEMultipart()
		msg["From"] = this._user_email
		msg["To"] = to_email
		msg["Subject"] = subject

		body = message
		msg.attach(MIMEText(body, "plain"))

		try:
			server = smtplib.SMTP(this._host, this._port)
			server.sendmail(this._user_email, to_email, msg.as_string())

		except Exception as e:
			print(f"Error sending email: {e}")

		finally:
			if server:
				server.quit()