"""
# Cirrus.App Automation Tool

A Python automation class for managing application info, executing shell commands (DOS/PowerShell), and handling file compression.

## Functions & Methods

### Initialization & Info
*   `__init__(name, version, copyright)`: Initializes the application, sets the start time, prints app info, and checks for help arguments.
*   `WriteAppInfo()`: Displays the application name, version, and copyright.
*   `DisplayHelp()`: Checks `sys.argv` for `?`, `-h`, or `help` to trigger `HelpScreen()`.
*   `HelpScreen()`: Prints usage instructions.
*   `QuitApp(runningTime)`: Prints the elapsed execution time.

### Shell & Command Execution
*   `dos(cmd)`: Runs a command in the Windows DOS (`cmd.exe`) shell using `subprocess` [7].
*   `ps1(cmd)`: Runs a command in PowerShell (`powershell.exe`) using `subprocess`.
*   `sh(cmd)`: Executes a command directly via the system shell.

### Compression
*   `ZipFolders(source_dir, zip_path)`: Compresses a directory into a ZIP file using `zipfile` and `os.walk` to traverse files.
*   `ZipFile(source_file, zip_path)`: Placeholder method for zipping a single file.

## Usage
```python
app = App("MyApp", "1.0")
app.dos("dir")
app.ZipFolders("./data", "backup.zip")
app.QuitApp()
"""

from datetime import datetime
import getopt, os, subprocess, sys, zipfile


class App:
	_startDate = ""	
	_exitScript = False


	#== Constructor ===============================================================================


	def __init__(this, name="Cirrus.App", version="1.0.0", copyright = "2024"):
		this._startDate = datetime.now()

		this.name = name
		this.version = version
		this.copyright = copyright

		this.WriteAppInfo()
		this.DisplayHelp()		


	#== App Info Methods ==========================================================================


	def DisplayHelp(this):
		if (("?" in sys.argv) or ("-h" in sys.argv) or ("help" in sys.argv)):
			this.HelpScreen()
			this._exitScript = True
	
	def HelpScreen(this):
		print("Help Screen")

	def WriteAppInfo(this):
		print(f"\n{this.name} {this.version}")
		print(f"Copyright (C) {this.copyright}")
		print("---\n")

	def QuitApp(this, runningTime = True):
		if (runningTime):
			print(f"\n\033[0;34mRunning time: {datetime.now() - this._startDate}\033[0;37m \n")


	#== Shell Methods =============================================================================


	#
	# SUMMARY: run a command in the DOS shell.
	#
	# PARAMETERS: cmd - the command to run.
	#
	def dos(this, cmd):
		subprocess.call('cmd.exe /c ' + cmd, shell=True)


	#
	# SUMMARY: run a command in 
	#
	# PARAMETERS: cmd - the command to run.
	#
	def ps1(this, cmd):
		subprocess.call('powershell.exe ' + cmd, shell=True)


	#
	# SUMMARY: run a command in the DOS shell.
	#
	# PARAMETERS: cmd - the command to run.
	#
	def sh(this, cmd):
		subprocess.call(cmd, shell=True)


	#== Compression Methods =======================================================================


	#
	# SUMMARY:
	# Zip a single file.
	#
	def ZipFile(this, source_file, zip_path):
		pass

	#
	# SUMMARY:
	# Zip website folders.
	#
	def ZipFolders(this, source_dir, zip_path):
		with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
			for root, _, files in os.walk(source_dir):
				for file in files:
					file_path = os.path.join(root, file)
					arc_name = os.path.relpath(file_path, source_dir)
					zf.write(file_path, arcname=arc_name)