# Sendgrid changelog

## [0.1.0] - 2026-02-25
- Updated connector definition (YAML version 1.0.1)
- Source commit: bcb024e5
- SDK version: 0.1.0
