Welcome to Pyfive Documentation!
================================

This is the documentation page for Pyfive; please also check out our `GitHub repository <https://github.com/NCAS-CMS/pyfive>`_.

.. include:: _sidebar.rst.inc

.. _fig_how_it_works:
.. figure:: /figures/Pyfive-logo.png
   :align: center
   :width: 80%

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
