"""Test pyfive's abililty to index Datasets."""

import os

import numpy as np
from numpy.testing import assert_array_equal
import pytest

import pyfive

DIRNAME = os.path.dirname(__file__)
DATASET_CHUNKED_FILE = os.path.join(DIRNAME, "data/chunked.hdf5")
DATASET_CONTIGUOUS_FILE = os.path.join(DIRNAME, "data/dataset_multidim.hdf5")


# Define a fixture that opens the chunked file once
@pytest.fixture(scope="module")
def chunked_file():
    with pyfive.File(DATASET_CHUNKED_FILE) as hfile:
        yield hfile


# Define a fixture that opens the contiguous file once
@pytest.fixture(scope="module")
def contiguous_file():
    with pyfive.File(DATASET_CONTIGUOUS_FILE) as hfile:
        yield hfile


@pytest.mark.parametrize(
    "index",
    [
        (slice(None, None, -1), slice(None, None, -1)),
        (slice(None), slice(1000, 1, -2)),
        (..., slice(None, None, -2)),
        (slice(None, None, -2), ...),
        (0, slice(-1, None, -3)),
        (slice(-1, None, -3), 0),
    ],
)
def test_dataset_indexing_chunked_negative_step_slices(chunked_file, index):
    """Test orthogonal chunked indexing with negative step slices"""
    d = chunked_file["dataset1"]
    assert d.shape == (21, 16)

    array = d[...]
    assert array.shape == d.shape

    assert_array_equal(d[index], array[index])


def test_dataset_indexing_replace_negative_slices():
    """Test pyfive.indexing.replace_negative_slices"""
    func = pyfive.indexing.replace_negative_slices

    r = list(range(8))
    assert func((0, slice(6, 0, -2)), (7, 8, 9)) == ((0, slice(2, 7, 2)), (0,))
    assert r[slice(6, 0, -2)] == list(reversed(r[slice(2, 7, 2)]))

    assert func(([1, 2], slice(600, 1, -3), 0), (7, 8, 9)) == (
        ([1, 2], slice(4, 8, 3), 0),
        (1,),
    )
    assert r[slice(600, None, -3)] == list(reversed(r[slice(1, 8, 3)]))

    r = list(range(9))
    assert func((0, slice(None), slice(6, 0, -2)), (7, 8, 9)) == (
        (0, slice(None), slice(2, 7, 2)),
        (1,),
    )
    assert r[slice(6, 0, -2)] == list(reversed(r[slice(2, 7, 2)]))

    # Can't pass in in Ellipsis
    with pytest.raises(ValueError) as error:
        func((0, slice(6, 0, -2), ...), (7, 8, 9))


def test_dataset_orthogonal_indexing(chunked_file, contiguous_file):
    assert chunked_file["dataset1"].__orthogonal_indexing__ is True
    assert contiguous_file["d"].__orthogonal_indexing__ is False
