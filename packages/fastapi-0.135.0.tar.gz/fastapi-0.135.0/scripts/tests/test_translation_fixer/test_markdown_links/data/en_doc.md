# Header 1 { #header-1 }

Some text with a link to [FastAPI](https://fastapi.tiangolo.com).

## Header 2 { #header-2 }

Two links here: [How to](https://fastapi.tiangolo.com/how-to/) and [Project Generators](project-generation.md){.internal-link target=_blank}.

### Header 3 { #header-3 }

Another link: [**FastAPI** Project Generators](project-generation.md "Link title"){.internal-link target=_blank} with title.

# Header 4 { #header-4 }

Link to anchor: [Header 2](#header-2)

# Header with [link](http://example.com) { #header-with-link }

Some text
