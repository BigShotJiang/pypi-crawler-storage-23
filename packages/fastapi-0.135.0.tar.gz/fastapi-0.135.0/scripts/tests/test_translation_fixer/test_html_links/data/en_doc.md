# Header 1 { #header-1 }

Some text with a link to <a href="https://fastapi.tiangolo.com">FastAPI</a>.

## Header 2 { #header-2 }

Two links here: <a href="https://fastapi.tiangolo.com/how-to/">How to</a> and <a href="project-generation.md" class="internal-link" target="_blank">Project Generators</a>.

### Header 3 { #header-3 }

Another link: <a href="project-generation.md" class="internal-link" target="_blank" title="Link title">**FastAPI** Project Generators</a> with title.

# Header 4 { #header-4 }

Link to anchor: <a href="#header-2">Header 2</a>

# Header with <a href="http://example.com">link</a> { #header-with-link }

Some text
