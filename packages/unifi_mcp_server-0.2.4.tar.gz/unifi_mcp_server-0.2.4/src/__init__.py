"""UniFi MCP Server - Model Context Protocol server for UniFi Network API."""

__version__ = "0.2.1"
