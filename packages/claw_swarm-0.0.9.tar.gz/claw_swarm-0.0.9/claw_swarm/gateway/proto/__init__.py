# gRPC generated code for MessagingGateway
from . import messaging_gateway_pb2
from . import messaging_gateway_pb2_grpc

__all__ = ["messaging_gateway_pb2", "messaging_gateway_pb2_grpc"]
