"""H5MD backend for asebytes."""

from asebytes.h5md._backend import H5MDBackend

__all__ = ["H5MDBackend"]
