"""Zarr backend for asebytes."""

from asebytes.zarr._backend import ZarrBackend

__all__ = ["ZarrBackend"]
