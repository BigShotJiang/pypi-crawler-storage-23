from __future__ import annotations

from typing import Any

import ase
import ase.constraints
import numpy as np
from ase.calculators.singlepoint import SinglePointCalculator
from ase.cell import Cell

_SKIP_KEYS = frozenset(("cell", "pbc", "arrays.numbers"))


def atoms_to_dict(atoms: ase.Atoms) -> dict[str, Any]:
    """Convert an ASE Atoms object to a logical dict.

    Parameters
    ----------
    atoms : ase.Atoms
        Atoms object to convert.

    Returns
    -------
    dict[str, Any]
        Keys like "cell", "pbc", "arrays.positions", "info.smiles", "calc.energy".
        Values are numpy arrays, scalars, or Python objects — no serialization.

    Raises
    ------
    TypeError
        If input is not an ase.Atoms object.
    """
    if not isinstance(atoms, ase.Atoms):
        raise TypeError("Input must be an ase.Atoms object.")

    if hasattr(atoms, "_celldisp") and atoms._celldisp.any():
        raise ValueError(
            "Atoms object has a non-zero cell displacement (_celldisp), "
            "which is not supported by asebytes serialization."
        )

    data: dict[str, Any] = {}
    data["cell"] = atoms.get_cell().array
    data["pbc"] = atoms.get_pbc()

    for key, value in atoms.arrays.items():
        data[f"arrays.{key}"] = value

    for key, value in atoms.info.items():
        data[f"info.{key}"] = value

    if atoms.calc is not None:
        for key, value in atoms.calc.results.items():
            data[f"calc.{key}"] = value

    if atoms.constraints:
        constraints_data = []
        for constraint in atoms.constraints:
            if not isinstance(constraint, ase.constraints.FixConstraint):
                raise TypeError(
                    f"Constraint {type(constraint).__name__} does not inherit "
                    f"from ase.constraints.FixConstraint and cannot be serialized."
                )
            constraints_data.append(constraint.todict())
        if constraints_data:
            data["constraints"] = constraints_data

    return data


def dict_to_atoms(data: dict[str, Any], fast: bool = True) -> ase.Atoms:
    """Convert a logical dict back to an ASE Atoms object.

    Parameters
    ----------
    data : dict[str, Any]
        Dictionary with string keys and Python/numpy values.
    fast : bool, default=True
        If True, bypass Atoms constructor for ~6x speedup.

    Returns
    -------
    ase.Atoms
        Reconstructed Atoms object.

    Notes
    -----
    Arrays are referenced, not copied. For LMDB backends this is safe
    (deserialization creates fresh arrays). In-memory backends should
    copy if mutation is a concern.
    """
    numbers = data.get("arrays.numbers", np.array([], dtype=int))
    if not isinstance(numbers, np.ndarray):
        numbers = np.asarray(numbers)

    cell = data.get("cell")
    pbc = data.get("pbc", np.array([False, False, False], dtype=bool))

    if fast:
        atoms = ase.Atoms.__new__(ase.Atoms)
        if cell is not None:
            atoms._cellobj = Cell(cell)
        else:
            atoms._cellobj = Cell(np.zeros((3, 3)))
        atoms._pbc = pbc if isinstance(pbc, np.ndarray) else np.asarray(pbc)
        atoms.arrays = {"numbers": numbers}
        if "arrays.positions" not in data:
            n_atoms = len(numbers)
            atoms.arrays["positions"] = np.zeros((n_atoms, 3))
        atoms.info = {}
        atoms.constraints = []
        atoms._celldisp = np.zeros(3)
        atoms._calc = None
    else:
        atoms = ase.Atoms(numbers=numbers, cell=cell, pbc=pbc)

    _calc = None
    for key, value in data.items():
        if key in _SKIP_KEYS:
            continue

        if key.startswith("arrays."):
            array_name = key[7:]  # len("arrays.") == 7
            atoms.arrays[array_name] = (
                value if isinstance(value, np.ndarray) else np.asarray(value)
            )
        elif key.startswith("info."):
            info_key = key[5:]  # len("info.") == 5
            atoms.info[info_key] = value
        elif key.startswith("calc."):
            if _calc is None:
                if fast:
                    # Bypass SinglePointCalculator.__init__ which calls
                    # atoms.copy() — a full deep copy we don't need.
                    _calc = SinglePointCalculator.__new__(SinglePointCalculator)
                    _calc.results = {}
                    _calc.atoms = atoms
                    _calc.parameters = None
                    _calc._directory = None
                    _calc.prefix = None
                    _calc.use_cache = False
                    atoms._calc = _calc
                else:
                    _calc = SinglePointCalculator(atoms)
                    atoms.calc = _calc
            calc_key = key[5:]  # len("calc.") == 5
            _calc.results[calc_key] = value
        elif key == "constraints":
            constraints = [
                ase.constraints.dict2constraint(cd)
                for cd in value
            ]
            atoms.set_constraint(constraints)

    return atoms
