class BaseEnum:
    def verify(self):
        var = vars(self)
        val = list(map(bool, var.values()))
        if val.count(True) != 1:
                raise TypeError('Bad enum. please set one of them "True".')
        
        return_obj = list(var.keys())[val.index(True)]
        return return_obj if return_obj != 'none' else 'None'
    
    get_ = text = verify

class ChatTypeEnum(BaseEnum):
    def __init__(
            self,
            User: bool = None,
            Bot: bool = None,
            Group: bool = None,
            Channel: bool = None,
    ):
        self.User = User
        self.Bot = Bot
        self.Group = Group
        self.Channel = Channel
        
class ForwardedFromEnum(BaseEnum):
    def __init__(
            self,
            User: bool = None,
            Channel: bool = None,
            Bot: bool = None,
    ):
        self.User = User
        self.Channel = Channel
        self.Bot = Bot

class PollStatusEnum(BaseEnum):
    def __init__(
            self,
            Open: bool = None,
            Closed: bool = None,
            
    ):
        self.Open = Open
        self.Closed = Closed

class ButtonSelectionTypeEnum(BaseEnum):
    def __init__(
            self,
            TextOnly: bool = None,
            TextImgThu: bool = None,
            TextImgBig: bool = None,
    ):
        self.TextOnly = TextOnly
        self.TextImgThu = TextImgThu
        self.TextImgBig = TextImgBig

class ButtonCalendarTypeEnum(BaseEnum):
    def __init__(
            self,
            DatePersian: bool = None,
            DateGregorian: bool = None,
            
    ):
        self.DatePersian = DatePersian
        self.DateGregorian = DateGregorian

class ButtonTextboxTypeLineEnum(BaseEnum):
    def __init__(
            self,
            SingleLine: bool = None,
            MultiLine: bool = None,
            
    ):
        self.SingleLine = SingleLine
        self.MultiLine = MultiLine

class ButtonTextboxTypeKeypadEnum(BaseEnum):
    def __init__(
            self,
            String: bool = None,
            Number: bool = None,
            
    ):
        self.String = String
        self.Number = Number

class ButtonLocationTypeEnum(BaseEnum):
    def __init__(
            self,
            Picker: bool = None,
            View: bool = None,
            
    ):
        self.Picker = Picker
        self.View = View

class ButtonTypeEnum(BaseEnum):
    def __init__(
            self,
            Simple: bool = None,
            Selection: bool = None,
            Calendar: bool = None,
            NumberPicker: bool = None,
            StringPicker: bool = None,
            Location: bool = None,
            CameraImage: bool = None,
            CameraVideo: bool = None,
            GalleryImage: bool = None,
            GalleryVideo: bool = None,
            File: bool = None,
            Audio: bool = None,
            RecordAudio: bool = None,
            Textbox: bool = None,
            Link: bool = None,
            AskMyPhoneNumber: bool = None,
            AskMyLocation: bool = None,
            Barcode: bool = None,
            
    ):
        self.Simple = Simple
        self.Selection = Selection
        self.Calendar = Calendar
        self.NumberPicker = NumberPicker
        self.StringPicker = StringPicker
        self.Location = Location
        self.CameraImage = CameraImage
        self.CameraVideo = CameraVideo
        self.GalleryImage = GalleryImage
        self.GalleryVideo = GalleryVideo
        self.File = File
        self.Audio = Audio
        self.RecordAudio = RecordAudio
        self.Textbox = Textbox
        self.Link = Link
        self.AskMyPhoneNumber = AskMyPhoneNumber
        self.AskMyLocation = AskMyLocation
        self.Barcode = Barcode

class FileTypeEnum(BaseEnum):
    def __init__(
            self,
            File: bool = None,
            Image: bool = None,
            Voice: bool = None,
            Video: bool = None,
            Music: bool = None,
            Gif: bool = None,
            
    ):
        self.File = File
        self.Image = Image
        self.Voice = Voice
        self.Video = Video
        self.Music = Music
        self.Gif = Gif

class ButtonSelectionSearchEnum(BaseEnum):
    def __init__(
            self,
            none: bool = None,
            Local: bool = None,
            Api: bool = None,
            
    ):
        self.none = none
        self.Local = Local
        self.Api = Api

class ButtonSelectionGetEnum(BaseEnum):
    def __init__(
            self,
            Local: bool = None,
            Api: bool = None,
            
    ):
        self.Local = Local
        self.Api = Api

class MessageSenderEnum(BaseEnum):
    def __init__(
            self,
            User: bool = None,
            Bot: bool = None,
            
    ):
        self.User = User
        self.Bot = Bot

class UpdateTypeEnum(BaseEnum):
    def __init__(
            self,
            UpdatedMessage: bool = None,
            NewMessage: bool = None,
            RemovedMessage: bool = None,
            StartedBot: bool = None,
            StoppedBot: bool = None,
            
    ):
        self.UpdatedMessage = UpdatedMessage
        self.NewMessage = NewMessage
        self.RemovedMessage = RemovedMessage
        self.StartedBot = StartedBot
        self.StoppedBot = StoppedBot

class ChatKeypadTypeEnum(BaseEnum):
    def __init__(
            self,
            none: bool = None,
            New: bool = None,
            Remove: bool = None,
            
    ):
        self.none = none
        self.New = New
        self.Remove = Remove

class UpdateEndpointTypeEnum(BaseEnum):
    def __init__(
            self,
            ReceiveUpdate: bool = None,
            ReceiveInlineMessage: bool = None,
            ReceiveQuery: bool = None,
            GetSelectionItem: bool = None,
            SearchSelectionItems: bool = None,
    ):
        self.ReceiveUpdate = ReceiveUpdate
        self.ReceiveInlineMessage = ReceiveInlineMessage
        self.ReceiveQuery = ReceiveQuery
        self.GetSelectionItem = GetSelectionItem
        self.SearchSelectionItems = SearchSelectionItems
