from .handler import *

class Handlers(
    onStop,
    onStart,
    onDeletedMessage,
    onEditedMessage,
    onMessage,
    onCallbackQuery
):
    pass