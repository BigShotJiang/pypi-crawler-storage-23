from ...models import Message
from ..creator import new_condition

@new_condition(use=(Message,))
def bot(event: Message):
    if event.sender_type.lower() == 'bot':
        return True
    return False