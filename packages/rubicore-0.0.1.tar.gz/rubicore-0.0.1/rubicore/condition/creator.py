class Condition:
    def __init__(self, func, *, use=None):
        self.func = func
        self.use = use

    def __call__(self, event, **kwargs):
        if self.use and not isinstance(event, self.use):
            return False
        return self.func(event, **kwargs)

    def __and__(self, other):
        return Condition(lambda e, **kw: self(e, **kw) and other(e, **kw))

    def __or__(self, other):
        return Condition(lambda e, **kw: self(e, **kw) or other(e, **kw))

    def __invert__(self):
        return Condition(lambda e, **kw: not self(e, **kw))

def new_condition(*, use=None):
    def wrapper(func):
        return Condition(func, use=use)
    return wrapper
