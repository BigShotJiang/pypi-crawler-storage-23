from ...models import Message
from ..creator import new_condition

def at_state(required_state):
    @new_condition(use=(Message,))
    def checker(event, *, states):
        user_id = event.sender_id
        return states.get(user_id) == required_state
    return checker