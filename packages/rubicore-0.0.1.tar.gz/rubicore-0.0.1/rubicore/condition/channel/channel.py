from ...models import Message, Callback_Query
from ..creator import new_condition

@new_condition(use=(Message, Callback_Query))
def channel(event: Message | Callback_Query):
    if isinstance(event, Message):
        if event.chat.type.lower() == 'channel':
            return True
        return False
    elif isinstance(event, Callback_Query):
        if event.message.chat.type.lower() == 'channel':
            return True
        return False