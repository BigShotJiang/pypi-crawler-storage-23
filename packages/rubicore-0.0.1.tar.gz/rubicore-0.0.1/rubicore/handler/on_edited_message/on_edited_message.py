class onEditedMessage:
    def on_edited_message(self, *conditions, **kwargs):
        def decorator(func):
            async def wrapper(event):
                if conditions:
                    if not all(cond(event, **kwargs) for cond in conditions):
                        return
                await func(event, **kwargs)

            self.handlers["UpdatedMessage"].append(wrapper)
            return wrapper

        return decorator
