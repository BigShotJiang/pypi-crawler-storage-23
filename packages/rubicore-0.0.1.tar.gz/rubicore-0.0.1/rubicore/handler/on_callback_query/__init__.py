from .on_callback_query import onCallbackQuery

__all__ = ['onCallbackQuery']