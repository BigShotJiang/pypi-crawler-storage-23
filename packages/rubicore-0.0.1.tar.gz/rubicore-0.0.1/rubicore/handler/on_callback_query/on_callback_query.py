class onCallbackQuery:
    def on_callback_query(self, *conditions, **kwargs):
        def decorator(func, **kwargs):
            async def wrapper(event, **kwargs):
                if conditions:
                    if not all(cond(event, **kwargs) for cond in conditions):
                        return
                await func(event, **kwargs)

            self.handlers["InlineQuery"].append(wrapper)
            return wrapper

        return decorator
