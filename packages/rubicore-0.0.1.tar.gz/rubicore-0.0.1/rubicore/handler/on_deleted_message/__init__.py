from .on_deleted_message import onDeletedMessage

__all__ = [
    "onDeletedMessage"
]
