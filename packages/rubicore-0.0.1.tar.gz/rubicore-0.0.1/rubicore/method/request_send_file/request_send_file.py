from ... import enums

class requestSendFile:
    async def request_send_file(
            self,
            type: enums.FileTypeEnum,
    ):
        type = type.get_()
        row = await self.call_method(self.client, "requestSendFile", locals())
        res = row.json()["data"]
        upload_url = res["upload_url"]
        return upload_url
