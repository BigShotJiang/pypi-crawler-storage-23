class editMessageText:
    async def edit_message_text(
            self,
            chat_id: str,
            message_id: str,
            text: str,
    ):
        
        await self.call_method(self.client, "editMessageText", locals())
