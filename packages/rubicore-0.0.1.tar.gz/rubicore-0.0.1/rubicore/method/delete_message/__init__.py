from .delete_message import deleteMessage

__all__ = [
    "deleteMessage"
]