class deleteMessage:
    async def delete_message(
            self,
            chat_id: str,
            message_id: str,
    ):
        await self.call_method(self.client, "deleteMessage", locals())
