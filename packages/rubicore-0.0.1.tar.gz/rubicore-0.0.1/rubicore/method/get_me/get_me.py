from ...models import Bot

class getMe:
    async def get_me(
            self
    ):
        row = await self.call_method(self.client, 'getMe', {})
        res = row.json()['data']['bot']
        bot = Bot()
        bot._builder(res)
    
        return bot
