from ... import models
from typing import List

class setCommand:
    async def set_command(
            self,
            bot_commands: List[models.BotCommand],
    ):
        await self.call_method(self.client, "setCommand", locals())
