from ...models import Update
from typing import Optional

class getUpdates:
    async def get_updates(
            self, 
            offset_id: Optional[str] = None,
            limit: int = 10
    ):
        
        row = await self.call_method(self.client, "getUpdates", {"offset_id": offset_id, "limit": limit})

        data: dict = row.json().get("data", {})
        updates_raw = data.get("updates", [])
        next_offset_id = data.get("next_offset_id", offset_id)
        
        updates = []
        for update in updates_raw:
            obj = Update()
            obj._builder(update)
            updates.append(obj)

        return updates, next_offset_id
