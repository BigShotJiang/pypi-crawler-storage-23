class banChatMember:
    async def ban_chat_member(
            self,
            chat_id: str,
            user_id: str,
    ):
        await self.call_method(self.client, "banChatMember", locals())
