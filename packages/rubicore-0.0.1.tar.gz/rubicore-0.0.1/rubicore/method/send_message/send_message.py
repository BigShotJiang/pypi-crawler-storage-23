from ...returner import reTurner
from ... import models

class sendMessage:
    async def send_message(
            self,
            chat_id: str,
            text: str,
            chat_keypad: models.Keypad = None,
            disable_notification: bool = False,
            inline_keypad: models.Keypad = None,
            reply_to_message_id: str = None,
            chat_keypad_type: models.enums.ChatKeypadTypeEnum = None,
    ):
        row = await self.call_method(self.client, "sendMessage", locals())
        res = row.json()["data"]
        message_id = res["message_id"]
        return message_id
