from typing import BinaryIO

class uploadFile:
    async def upload_file(
            self,
            upload_url: str,
            file: BinaryIO,
            file_name: str
    ):
        row = await self.client.post(upload_url, headers={'Content-Type': 'multipart/form-data'}, files={"file": (file_name, file)})
        res = row.json()["data"]
        url = res["url"]
        return url
