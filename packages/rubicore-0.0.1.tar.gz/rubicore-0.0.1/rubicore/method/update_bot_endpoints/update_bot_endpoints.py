from ... import enums

class updateBotEndpoints:
    async def update_bot_endpoints(
            self,
            url: str,
            type: enums.UpdateEndpointTypeEnum,
    ):
        await self.call_method(self.client, "updateBotEndpoints", locals())

