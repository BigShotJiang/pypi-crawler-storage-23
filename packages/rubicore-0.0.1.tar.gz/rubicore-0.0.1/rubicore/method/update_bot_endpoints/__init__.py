from .update_bot_endpoints import updateBotEndpoints

__all__ = [
    "updateBotEndpoints"
]