from ... import models, enums

class sendFile:
    async def send_file(
            self,
            chat_id: str,
            file_id: str,
            text: str,
            reply_to_message_id: str,
            disable_notification: bool,
            chat_keypad: models.Keypad,
            inline_keypad: models.Keypad,
            chat_keypad_type: models.enums.ChatKeypadTypeEnum,

    ):
        chat_keypad_type = chat_keypad_type.get_()
        row = await self.call_method(self.client, "sendFile", locals())
        res = row.json()["data"]
        message_id = res["message_id"]
        _me = await self.get_me()
        mess_obj = models.Message(None, message_id, text, None, False, enums.MessageSenderEnum(Bot=True), _me, None, models.File(file_id, None, None), reply_to_message_id)
        async with self._lock_ch:
            chat = self.ch_ids.get(chat_id)
        return mess_obj
