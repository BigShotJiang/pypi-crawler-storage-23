from ...models import Message

class forwardMessage:
    async def forward_message(
            self,
            from_chat_id: str,
            message_id: str,
            to_chat_id: str,
            disable_notification: bool = False,
    ):
        row = await self.call_method(self.client, "forwardMessage", locals())
        res = row.json()["data"]
        new_message_id = res['new_message_id']
        chat = await self.get_chat(to_chat_id)
        mess_obj = Message(chat, message_id)

        return mess_obj
