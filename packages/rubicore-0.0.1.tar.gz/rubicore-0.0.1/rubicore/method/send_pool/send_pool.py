from typing import List

class sendPoll:
    async def send_poll(
            self,
            chat_id: str,
            question: str,
            options: List[str],
    ):
        row = await self.call_method(self.client, "sendPoll", locals())
        res = row.json()["data"]
        message_id = res["message_id"]
        return message_id
