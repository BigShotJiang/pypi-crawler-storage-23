from ...models import Chat

class getChat:
    async def get_chat(
            self,
            chat_id: str,
    ):
        row = await self.call_method(self.client, "getChat", locals())
        res = row.json()["data"]
        
        chat = Chat()
        chat._builder(res['chat'])
        return chat
