from ...models import Keypad

class editMessageKeypad:
    async def edit_message_keypad(
            self,
            chat_id: str,
            message_id: str,
            inline_keypad: Keypad,
    ):
        await self.call_method(self.client, "editMessageKeypad", locals())
