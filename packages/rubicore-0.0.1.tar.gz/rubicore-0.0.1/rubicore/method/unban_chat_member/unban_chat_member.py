class unbanChatMember:
    async def unban_chat_member(
            self,
            chat_id: str,
            user_id: str,
    ):
        await self.call_method(self.client, "unbanChatMember", locals())

