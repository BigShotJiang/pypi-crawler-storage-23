from ...returner import reTurner
from ... import models

class sendLocation:
    async def send_location(
            self,
            chat_id: str,
            latitude: str,
            longitude: str,
            chat_keypad: models.Keypad = None,
            disable_notification: bool = False,
            inline_keypad: models.Keypad = None,
            reply_to_message_id: str = None,
            chat_keypad_type: models.enums.ChatKeypadTypeEnum = None,
    ):
        chat_keypad_type = chat_keypad_type.get_() if chat_keypad_type else None
        row = await self.call_method(self.client, "sendLocation", locals())
        res = row.json()["data"]
        message_id = res["message_id"]
        return message_id