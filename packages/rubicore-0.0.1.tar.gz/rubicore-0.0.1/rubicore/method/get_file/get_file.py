class getFile:
    async def get_file(
            self,
            file_id: str,
    ):
        row = await self.call_method(self.client, "editChatKeypad", locals())
        res = row.json()["data"]
        download_url = res["download_url"]
        return download_url
