from .get_file import getFile

__all__ = [
    "getFile"
]