from ...models import Keypad, enums

class editChatKeypad:
    async def edit_chat_keypad(
            self,
            chat_id: str,
            chat_keypad: Keypad,
            chat_keypad_type: enums.ChatKeypadTypeEnum,
    ):
        chat_keypad_type = chat_keypad_type.get_()
        await self.call_method(self.client, "editChatKeypad", locals())
