from .delete_chat_keypad import deleteChatKeypad

__all__ = [
    "deleteChatKeypad"
]