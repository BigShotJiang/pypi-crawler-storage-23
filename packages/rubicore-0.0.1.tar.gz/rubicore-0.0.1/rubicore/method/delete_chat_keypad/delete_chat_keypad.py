from ...enums import ChatKeypadTypeEnum

class deleteChatKeypad:
    async def delete_chat_keypad(
            self,
            chat_id: str,
    ):
        chat_keypad_type = ChatKeypadTypeEnum(Remove=True).get_()
        await self.call_method(self.client, "editChatKeypad", locals())
