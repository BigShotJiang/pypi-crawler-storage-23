# rubicore

A lightweight async wrapper for rubika API.

## Installation

```bash
pip install rubicore

## License

MIT License. See the LICENSE file for details.