.. currentmodule:: hrap

API Reference
=============

Build-in motor configuration
----------------------------
.. autosummary::
   :toctree: _autosummary
   
   tank.SatTank

.. Oxidizer and Fuel Models
.. -----------------
.. .. autosummary::
..    :toctree: _autosummary

..    .. hrap
..    .. tank
..    tank.make_sat_tank