Contributor Guide
=================
