HRAP: Propulsion Analysis for Amateur Rocketry
==============================================

.. grid:: 3
   :class-container: product-offerings
   :margin: 0
   :padding: 0
   :gutter: 0

   .. grid-item-card:: Simple yet flexible
      :columns: 12 6 6 4
      :class-card: sd-border-0
      :shadow: None

      For basic usage, the API offers text-based configuration. Remaining flexible, advanced users can customize readily.

   .. grid-item-card:: Performant
      :columns: 12 6 6 4
      :class-card: sd-border-0
      :shadow: None

      Thanks to JIT compilation, HRAP executes with performance comperable to similar C++ based software.

   .. grid-item-card:: Monolithic
      :columns: 12 6 6 4
      :class-card: sd-border-0
      :shadow: None

      Through JAX, our Python code executes on both CPU (all major OS) and GPU (linux only).

.. TODO: fix, not showing up but no errors...
.. grid:: 3
    :class-container: color-cards

    .. grid-item-card:: :material-regular:`laptop_chromebook;2em` Installation
      :columns: 12 6 6 4
      :link: installation
      :link-type: ref
      .. :class-card: installation

    .. grid-item-card:: :material-regular:`rocket_launch;2em` Getting started
      :columns: 12 6 6 4
      :link: beginner_guide
      :link-type: ref
      .. :class-card: getting-started

    .. grid-item-card:: :material-regular:`library_books;2em` Validation
      :columns: 12 6 6 4
      :link: validation
      :link-type: ref
      .. :class-card: 

.. Shows up on the sidebar
.. toctree::
   :hidden:
   :maxdepth: 1
   :caption: Getting started

   installation
   beginner_guide

.. toctree::
   :hidden:
   :maxdepth: 1
   :caption: Resources, guides, and references

   api
   theory
   validation
   contributor_guide


.. .. toctree::
..    :maxdepth: 2
..    :caption: Contents:

