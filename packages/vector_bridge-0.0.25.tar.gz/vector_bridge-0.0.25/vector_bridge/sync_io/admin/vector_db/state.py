from typing import Any

from vector_bridge import VectorBridgeClient
from vector_bridge.schema.errors.vectordb import raise_for_vectordb_detail


class VectorDBStateAdmin:
    """Admin client for vector database schema management endpoints."""

    def __init__(self, client: VectorBridgeClient):
        self.client = client

    def get_schema(self, integration_name: str | None = None) -> list[dict[str, Any]]:
        """
        Get VectorDB schema.

        Args:
            integration_name: Specifies the name of the integration module being queried

        Returns:
            List of collection configurations (Weaviate CollectionConfigSimple dicts)
        """
        url = f"{self.client.base_url}/v1/admin/vector-db/schema"
        params = {}
        if integration_name:
            params["integration_name"] = integration_name

        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers, params=params)
        return self.client._handle_response(response=response, error_callable=raise_for_vectordb_detail)

    def is_schema_ready(self, integration_name: str | None = None) -> bool:
        """
        Check if VectorDB schema is ready.

        Args:
            integration_name: Specifies the name of the integration module being queried

        Returns:
            True if schema is ready, False otherwise
        """
        url = f"{self.client.base_url}/v1/admin/vector-db/schema-ready"
        params = {}
        if integration_name:
            params["integration_name"] = integration_name

        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers, params=params)
        return self.client._handle_response(response=response, error_callable=raise_for_vectordb_detail)
