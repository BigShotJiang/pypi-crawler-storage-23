"""Vendored dependencies for gguf-clone."""
