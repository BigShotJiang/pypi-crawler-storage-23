import './views/EditCollectionWidget';
import './views/CollectionInfoWidget';
import './models/CollectionModel';
import './routes';
