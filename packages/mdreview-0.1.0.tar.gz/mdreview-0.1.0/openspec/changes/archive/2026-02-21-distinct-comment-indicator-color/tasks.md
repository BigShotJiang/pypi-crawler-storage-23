## 1. Gutter indicator colors

- [x] 1.1 In `src/mdreview/markdown.py`, change `.has-comment` border and background from `$warning` to `$secondary`
- [x] 1.2 In `src/mdreview/markdown.py`, change `.cursor.has-comment` border and background from `$warning` to `$secondary`

## 2. Comment popover colors

- [x] 2.1 In `src/mdreview/widgets/comment_popover.py`, change `CommentCard` border and background from `$warning` to `$secondary`
- [x] 2.2 In `src/mdreview/widgets/comment_popover.py`, change `CommentPopover` border from `$warning` to `$secondary`
