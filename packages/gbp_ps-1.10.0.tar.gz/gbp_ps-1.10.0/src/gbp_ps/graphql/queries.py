"""Query GraphQL resolver for gbp-ps"""

from typing import Any, Iterable

from ariadne import ObjectType
from graphql import GraphQLResolveInfo

from gbp_ps.repository import Repo
from gbp_ps.settings import Settings
from gbp_ps.types import BuildProcess

type Info = GraphQLResolveInfo
QUERY = ObjectType("Query")


get_processes = Repo(Settings.from_environ()).get_processes


@QUERY.field("buildProcesses")
def build_processes(
    _obj: Any, _info: Info, *, include_final: bool = False, machine: str
) -> Iterable[BuildProcess]:
    """Return the list of BuildProcesses

    If include_final is True also include processes in their "final" phase. The default
    value is False.
    """
    return get_processes(include_final=include_final, machine=machine)
