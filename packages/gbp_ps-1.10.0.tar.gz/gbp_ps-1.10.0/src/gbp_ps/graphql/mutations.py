"""Mutation GraphQL type for gbp-ps"""

from typing import Any

from ariadne import ObjectType
from graphql import GraphQLResolveInfo

from gbp_ps.repository import Repo, add_or_update_process
from gbp_ps.settings import Settings
from gbp_ps.types import BuildProcess

type Info = GraphQLResolveInfo
MUTATION = ObjectType("Mutation")

ADD_BUILD_FIELDS = {"machine", "id", "package", "phase"}


@MUTATION.field("addBuildProcess")
def add_build_process(_obj: Any, _info: Info, process: dict[str, Any]) -> None:
    """Add the given process to the process table

    If the process already exists in the table, it is updated with the new value
    """
    # Don't bother when required fields are empty.
    if not all(process[field] for field in ADD_BUILD_FIELDS):
        return

    process["build_id"] = process.pop("id")
    add_or_update_process(Repo(Settings.from_environ()), BuildProcess(**process))
