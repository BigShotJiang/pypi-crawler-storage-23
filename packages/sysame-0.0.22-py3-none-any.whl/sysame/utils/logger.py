"""
Module Description: Briefly describe the module's purpose.
"""

##### IMPORTS #####
# Standard imports
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional


# Third-party imports

# Local imports

# Import Rules

##### CONSTANTS #####
# Define constants here

##### GLOBALS #####
# Define global variables here (use with caution)

##### CLASSES #####
# Define classes here

##### FUNCTIONS #####
# Define functions here


##### CLASSES #####
@dataclass(frozen=True)
class LogColors:
    DEBUG: str = "\033[90m"
    INFO: str = "\033[97m"
    WARN: str = "\033[1;33m"
    ERROR: str = "\033[1;91m"
    RESET: str = "\033[0m"


class Logger:
    def __init__(
        self,
        file_path: Optional[str | Path] = None,
        *,
        name: str = "",
        console: bool = True,
        colors: LogColors = LogColors(),
        dt_format: str = "%Y-%m-%d %H:%M:%S",
        level_width: int = 5,
        delimiter: str = "|",
    ) -> None:
        if file_path is None and not console:
            raise ValueError(
                "At least one output must be enabled: set file_path and/or console=True"
            )
        self.file_path = Path(file_path) if file_path is not None else None
        self.name = name
        self.console = console
        self.colors = colors
        self.dt_format = dt_format
        self.level_width = level_width
        self.delimiter = delimiter
        self.name_width = len(name) if name else 0
        if self.file_path is not None:
            self._ensure_path()

    def _ensure_path(self) -> None:
        directory = self.file_path.resolve().parent
        if not directory.exists() or not directory.is_dir():
            raise FileNotFoundError(f"Log directory does not exist: {directory}")
        try:
            self.file_path.touch(exist_ok=True)
        except PermissionError as e:
            raise PermissionError(f"No write permission for: {directory}") from e

    def _timestamp(self) -> str:
        return datetime.now().strftime(self.dt_format)

    def _format_line(self, level: str, message: str) -> str:
        d = self.delimiter
        name_part = f"{self.name:<{self.name_width}} {d} " if self.name else ""
        return f"{self._timestamp()} {d} {level:<{self.level_width}} {d} {name_part}{message}"

    def _write_line(self, line: str, color: Optional[str] = None) -> None:
        if self.file_path is not None:
            with self.file_path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        if self.console:
            print(f"{color or ''}{line}{self.colors.RESET if color else ''}")

    def debug(self, message: str) -> None:
        line = self._format_line("DEBUG", message)
        self._write_line(line, self.colors.DEBUG)

    def info(self, message: str) -> None:
        line = self._format_line("INFO", message)
        self._write_line(line, self.colors.INFO)

    def warn(self, message: str) -> None:
        line = self._format_line("WARN", message)
        self._write_line(line, self.colors.WARN)

    def error(self, message: str) -> None:
        line = self._format_line("ERROR", message)
        self._write_line(line, self.colors.ERROR)

    def separator(self, marker: str = "----") -> None:
        self._write_line(marker)
