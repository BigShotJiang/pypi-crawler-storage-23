"""
Orakel: A small library of regression models of interest to the life sciences.

Subpackages
-----------
predict
    The model functions and the wrapper class to perform non-linear regression.
metrics
    Auxiliary functions to calculate coefficients.

Metadata
--------
__author__
    The author's name.
__copyright__
    The copyright notice.
__license__
    The SPDX license identifier of the license valid for Orakel.
__version__
    Orakel version string.
"""

__author__ = 'culpeo'
__copyright__ = 'Copyright (C) 2025 culpeo <culpeo@dismail.de>'
__license__ = 'LGPL-3.0-only'
__version__ = '1.0.0'

from . import predict
from . import metrics
