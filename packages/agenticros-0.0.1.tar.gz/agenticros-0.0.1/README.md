# agenticros

Placeholder package to reserve the PyPI name **agenticros**.

This package is not intended for use. Install it only if you need the name reserved for a future project.

## Publishing to PyPI (reserve the name)

1. Create an account at [pypi.org](https://pypi.org/account/register/) if needed.
2. Install build and twine: `pip install build twine`
3. From the project root:
   ```bash
   python -m build
   twine upload dist/*
   ```
4. Use your PyPI username and password (or token). For first-time upload, the name `agenticros` will be reserved.

## License

MIT
