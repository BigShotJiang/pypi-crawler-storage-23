"""Placeholder package to reserve the PyPI name 'agenticros'."""

__version__ = "0.0.1"
