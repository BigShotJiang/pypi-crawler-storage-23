"""Promptfoo Python provider that mirrors _humanize_message LLM call logic.

Reconstructs the same system prompt, user query, and structured output call
that soprano_sdk.core.engine.WorkflowEngine._humanize_message builds,
without needing to instantiate a full WorkflowEngine.

Constants and the Pydantic schema are imported directly from the SDK so
changes to the source prompts are automatically picked up by evals.
"""

import json
import os
import sys
from pathlib import Path

# Ensure the project root is on sys.path so soprano_sdk is importable
# regardless of which Python executable promptfoo uses.
_project_root = str(Path(__file__).resolve().parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from langchain_openai import ChatOpenAI  # noqa: E402
from pydantic import BaseModel, SecretStr  # noqa: E402
from typing import List, Optional  # noqa: E402

from soprano_sdk.core.constants import (  # noqa: E402
    DEFAULT_HUMANIZATION_SYSTEM_PROMPT,
    DEFAULT_LOCALIZATION_INSTRUCTIONS,
    HUMANIZATION_OPTIONS_GUIDANCE,
)


# OpenAI strict structured output rejects Dict[str, Any] (needs additionalProperties: false).
# Define a concrete model matching the option shape used by the SDK.
class OptionItem(BaseModel):
    text: str
    subtext: str


class EvalHumanizedResponse(BaseModel):
    message: str
    options: Optional[List[OptionItem]] = None
    is_selectable: Optional[bool] = None


def call_api(prompt: str, options: dict, context: dict) -> dict:
    config = options.get("config", {})
    vars_ = context.get("vars", {})

    model_name = config.get("model_name", "gpt-4o-mini")
    api_key = config.get("api_key") or os.environ.get("OPENROUTER_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
    base_url = config.get("base_url")

    reference_message = vars_["reference_message"]
    opt = vars_.get("options")
    is_selectable = vars_.get("is_selectable")
    conversation_history = vars_.get("conversation_history")
    language = vars_.get("language")
    script = vars_.get("script")
    custom_instructions = vars_.get("custom_instructions")

    # Parse JSON strings (promptfoo passes vars as strings)
    if isinstance(opt, str):
        opt = json.loads(opt) if opt else None
    if isinstance(conversation_history, str):
        conversation_history = json.loads(conversation_history) if conversation_history else None
    if isinstance(is_selectable, str):
        is_selectable = is_selectable.lower() == "true"

    # --- Build system prompt (mirrors engine.py:311-324) ---
    system_prompt = custom_instructions if custom_instructions else DEFAULT_HUMANIZATION_SYSTEM_PROMPT
    system_prompt += HUMANIZATION_OPTIONS_GUIDANCE

    if language:
        localization_prompt = DEFAULT_LOCALIZATION_INSTRUCTIONS.format(
            language=language,
            script=script or "the appropriate script",
        )
        system_prompt = f"{localization_prompt}\n\n{system_prompt}"

    # --- Build user query (mirrors engine.py:335-343) ---
    user_query = (
        f"Humanize this message based on the prior context:\n\n"
        f"```\n{reference_message}\n```"
    )
    if opt:
        user_query += f"\n\nSelectable options: {opt}"
        user_query += f"\nMust select from options: {is_selectable}"
        user_query += (
            "\n\nReturn these exact options and is_selectable values in your "
            "structured response. Do NOT add, remove, or modify any options."
        )
    else:
        user_query += (
            "\n\nOnly include options if they are explicitly present "
            "in the reference message above."
        )

    # --- Assemble messages (mirrors engine.py:345-348) ---
    messages = [{"role": "system", "content": system_prompt}]
    if conversation_history:
        messages.extend(conversation_history)
    messages.append({"role": "user", "content": user_query})

    # --- Call LLM with structured output (mirrors get_model + invoke) ---
    llm_kwargs = {"model": model_name, "api_key": SecretStr(api_key)}
    if base_url:
        llm_kwargs["base_url"] = base_url

    llm = ChatOpenAI(**llm_kwargs)
    try:
        structured_llm = llm.with_structured_output(EvalHumanizedResponse)
        humanized: EvalHumanizedResponse = structured_llm.invoke(messages)
    except Exception:
        # Fallback: JSON mode for models that don't support function-calling structured output
        structured_llm = llm.with_structured_output(EvalHumanizedResponse, method="json_mode")
        humanized: EvalHumanizedResponse = structured_llm.invoke(messages)

    # Convert OptionItem models back to dicts for JSON output
    options_out = None
    if humanized.options is not None:
        options_out = [{"text": o.text, "subtext": o.subtext} for o in humanized.options]

    return {
        "output": json.dumps({
            "message": humanized.message,
            "options": options_out,
            "is_selectable": humanized.is_selectable,
        }, ensure_ascii=False),
    }
