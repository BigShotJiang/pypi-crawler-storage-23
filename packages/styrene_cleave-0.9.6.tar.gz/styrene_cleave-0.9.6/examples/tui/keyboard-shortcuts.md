# Keyboard Shortcuts Reference

Complete keyboard shortcut guide for the Cleave TUI.

## Input Area

| Shortcut | Action | Description |
|----------|--------|-------------|
| `Enter` | Submit | Submit current message |
| `Shift+Enter` | New Line | Insert newline in message |
| `Up` | History Previous | Navigate to previous input |
| `Down` | History Next | Navigate to next input |
| `Ctrl+A` | Line Start | Move cursor to start of line |
| `Ctrl+E` | Line End | Move cursor to end of line |
| `Ctrl+K` | Delete to End | Delete from cursor to end of line |
| `Ctrl+U` | Delete to Start | Delete from cursor to start of line |
| `Ctrl+W` | Delete Word | Delete word before cursor |

## Chat Panel

| Shortcut | Action | Description |
|----------|--------|-------------|
| `Ctrl+L` | Clear Chat | Clear conversation history |
| `Escape` | Cancel | Cancel current LLM operation |
| `PgUp` | Scroll Up | Scroll chat panel up |
| `PgDown` | Scroll Down | Scroll chat panel down |
| `Home` | Jump to Top | Jump to top of chat |
| `End` | Jump to Bottom | Jump to bottom of chat |

## Session Management

| Shortcut | Action | Description |
|----------|--------|-------------|
| `Ctrl+S` | Save Session | Save current session |
| `Ctrl+O` | Open Session | Open existing session (future) |
| `Ctrl+N` | New Session | Start new session (future) |

## Navigation

| Shortcut | Action | Description |
|----------|--------|-------------|
| `Tab` | Focus Next | Move focus to next panel |
| `Shift+Tab` | Focus Previous | Move focus to previous panel |

## Global

| Shortcut | Action | Description |
|----------|--------|-------------|
| `q` | Quit | Exit TUI (prompts to save) |
| `Ctrl+C` | Force Quit | Force exit without saving |

## Input History

The TUI maintains a history of your submitted messages.

- **Up Arrow**: Navigate to previous message
- **Down Arrow**: Navigate to next message
- **History Persistence**: Saved with session
- **History Size**: Last 100 messages

### Example Usage

```
[Input 1]: Add JWT auth
[Press Up]
[Input shows]: Add JWT auth
[Edit to]: Add JWT auth with refresh tokens
[Press Enter]
```

## Multi-Line Input

Use `Shift+Enter` to create multi-line directives:

```
Add JWT authentication with the following features:
[Shift+Enter]
- Access token (15min expiry)
[Shift+Enter]
- Refresh token (7day expiry)
[Shift+Enter]
- Token blacklist for logout
[Enter to submit]
```

## Chat Interaction

### Canceling Operations

Press `Escape` at any time to cancel:
- LLM response generation
- Tool execution
- Long-running operations

The TUI will gracefully stop streaming and return to input.

### Clearing History

`Ctrl+L` clears the chat panel but preserves:
- Session state
- Workspace files
- Execution history

Use this for a clean view without losing work.

## Control Panel Shortcuts

While focused on the control panel:

| Shortcut | Action |
|----------|--------|
| `r` | Retry last message |
| `e` | Export conversation |
| `s` | Show session info |

## Context Menu (Future)

Right-click on messages (when supported):
- Copy message
- Edit and retry
- Export message
- View tool details

## Accessibility

### Screen Reader Support
The TUI aims for screen reader compatibility via Textual's accessibility features.

### High Contrast Mode
```bash
cleave config set tui.theme default
```

The `default` theme provides better contrast than the `crt` theme.

### Font Size
Terminal font size is controlled by your terminal emulator settings, not the TUI.

## Advanced: Custom Keybindings

Create `~/.cleave/keybindings.toml`:

```toml
[input]
submit = "enter"
newline = "shift+enter"
clear = "ctrl+u"

[chat]
clear = "ctrl+l"
cancel = "escape"

[global]
quit = "q"
force_quit = "ctrl+c"
```

Reload keybindings:
```bash
cleave tui --reload-keybindings
```

Note: Custom keybindings are a planned feature, not yet implemented.

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────┐
│ CLEAVE TUI - QUICK REFERENCE                            │
├─────────────────────────────────────────────────────────┤
│ INPUT                                                   │
│   Enter          Submit message                         │
│   Shift+Enter    New line                               │
│   Up/Down        History navigation                     │
│                                                          │
│ CHAT                                                    │
│   Ctrl+L         Clear chat                             │
│   Escape         Cancel operation                       │
│   PgUp/PgDown    Scroll                                 │
│                                                          │
│ SESSION                                                 │
│   Ctrl+S         Save session                           │
│                                                          │
│ GLOBAL                                                  │
│   Tab            Next panel                             │
│   q              Quit (with prompt)                     │
│   Ctrl+C         Force quit                             │
└─────────────────────────────────────────────────────────┘
```

Print this reference:
```bash
cat ~/.cleave/examples/tui/keyboard-shortcuts.md | grep -A 100 "Quick Reference"
```
