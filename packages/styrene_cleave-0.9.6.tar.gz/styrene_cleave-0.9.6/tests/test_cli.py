"""Tests for CLI argument parsing and commands."""

from __future__ import annotations

import subprocess
import sys

import pytest

from cleave import __version__


def test_version_flag_long():
    """Test that --version flag outputs correct version."""
    result = subprocess.run(
        [sys.executable, "-m", "cleave", "--version"],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert f"cleave {__version__}" in result.stdout


def test_version_flag_short():
    """Test that -v flag outputs correct version."""
    result = subprocess.run(
        [sys.executable, "-m", "cleave", "-v"],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert f"cleave {__version__}" in result.stdout


def test_no_command_shows_error():
    """Test that running cleave without a command shows an error."""
    result = subprocess.run(
        [sys.executable, "-m", "cleave"],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "the following arguments are required: command" in result.stderr


def test_help_flag():
    """Test that --help flag shows usage information."""
    result = subprocess.run(
        [sys.executable, "-m", "cleave", "--help"],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert "Cleave CLI - Task decomposition automation" in result.stdout
    assert "Examples:" in result.stdout
