"""
QuarterBit - Memory-Efficient Training
======================================

Usage:
    from quarterbit import axiom, TrainingStats

    # Enable memory-efficient training (15-17x compression)
    model = axiom(model)

    # Training loop with stats
    stats = TrainingStats()
    for step, batch in enumerate(dataloader):
        loss = model(**batch).loss
        loss.backward()
        stats.log(step, loss.item())

    # Save/resume with standard PyTorch
    torch.save(model.state_dict(), "checkpoint.pt")

License: Free account required at https://quarterbit.dev
"""

__version__ = "20.3.0"
__author__ = "Clouthier Simulation Labs"

# License check on import
from .license import check_license, LicenseError

_LICENSE_VALID = False
try:
    check_license(silent=True)
    _LICENSE_VALID = True
except LicenseError:
    import sys
    print("\n" + "="*60)
    print("QuarterBit requires a free account.")
    print("")
    print("Sign up (free): https://quarterbit.dev")
    print("Then run:       quarterbit login")
    print("="*60 + "\n")

# Check PyTorch
try:
    import torch as _torch
    _HAS_TORCH = True
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "QuarterBit: CUDA not available. GPU required for full performance.",
            RuntimeWarning
        )
except ImportError:
    _HAS_TORCH = False
    import warnings
    warnings.warn(
        "QuarterBit: PyTorch not found. Install from https://pytorch.org/get-started/locally/",
        ImportWarning
    )


def axiom(model, lr: float = 5e-5, verbose: bool = True):
    """
    Enable memory-efficient training on any PyTorch model.

    Achieves 15-17x memory compression, allowing large models to train
    on single GPUs. Works with all HuggingFace models (NLP, Vision, Audio, Multimodal).

    Args:
        model: Any PyTorch model (HuggingFace, custom, etc.)
        lr: Learning rate (default: 5e-5)
        verbose: Show training progress (default: True)

    Returns:
        Model with memory-efficient training enabled

    Example:
        from quarterbit import axiom
        from transformers import AutoModelForCausalLM

        model = AutoModelForCausalLM.from_pretrained("model-name", torch_dtype=torch.float16)
        model = axiom(model)
        model = model.cuda()

        for batch in dataloader:
            loss = model(**batch).loss
            loss.backward()
            # Weights automatically updated by AXIOM!
    """
    if not _LICENSE_VALID:
        raise LicenseError(
            "License required. Sign up free at quarterbit.dev then run: quarterbit login"
        )

    if not _HAS_TORCH:
        raise ImportError("PyTorch required. Install from https://pytorch.org/get-started/locally/")

    from .vla_trainable import make_vla_trainable, VLATrainableLinear, VLATrainableEmbedding

    # Convert model to memory-efficient training
    model = make_vla_trainable(model, verbose=verbose)

    # Store lr for internal optimizer
    model._axiom_lr = lr
    model._axiom_verbose = verbose

    # Collect all VLA layers for automatic updates
    vla_layers = []
    for module in model.modules():
        if isinstance(module, (VLATrainableLinear, VLATrainableEmbedding)):
            vla_layers.append(module)
    model._axiom_vla_layers = vla_layers
    model._axiom_prev_loss = None
    model._axiom_step_count = 0

    # Create automatic update function
    def _axiom_auto_update(loss_value=None):
        """Apply AXIOM weight updates to all VLA layers."""
        # Determine if loss decreased
        loss_decreased = None
        if loss_value is not None and model._axiom_prev_loss is not None:
            loss_decreased = loss_value < model._axiom_prev_loss
        if loss_value is not None:
            model._axiom_prev_loss = loss_value

        # Update all VLA layers
        lr_scaled = model._axiom_lr * 15.0  # VLA LR scale factor
        updated = 0
        for vla in model._axiom_vla_layers:
            if hasattr(vla, 'update_from_gradient'):
                if vla.update_from_gradient(lr=lr_scaled, loss_decreased=loss_decreased):
                    updated += 1

        model._axiom_step_count += 1
        return updated

    # Attach update function to model
    model._axiom_update = _axiom_auto_update

    # Register backward hook to auto-update after each backward pass
    # Use AccumulateGrad hook on first VLA layer's grad_marker
    if vla_layers:
        first_vla = vla_layers[0]
        if hasattr(first_vla, '_grad_marker') and first_vla._grad_marker is not None:
            def _backward_hook(grad):
                # This fires when backward reaches first VLA layer (actually last in backward order)
                # Schedule update for after full backward completes
                model._axiom_auto_update()
                return grad

            # Register hook on last VLA layer (first to get gradients in backward)
            last_vla = vla_layers[-1]
            if hasattr(last_vla, '_grad_marker') and last_vla._grad_marker is not None:
                last_vla._grad_marker.register_hook(_backward_hook)
                model._axiom_auto_backward = True
            else:
                model._axiom_auto_backward = False
        else:
            model._axiom_auto_backward = False
    else:
        model._axiom_auto_backward = False

    # Patch max_memory_allocated to return nvidia-smi values (accurate GPU memory)
    # torch.cuda.max_memory_allocated() returns cumulative allocations, not actual peak
    if _HAS_TORCH and _torch.cuda.is_available():
        import subprocess
        def _nvidia_smi_memory():
            """Get actual GPU memory used from nvidia-smi"""
            try:
                result = subprocess.run(
                    ['nvidia-smi', '--query-gpu=memory.used', '--format=csv,noheader,nounits'],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    return int(result.stdout.strip().split('\n')[0]) * 1024 * 1024  # MiB to bytes
            except:
                pass
            return _torch.cuda.max_memory_allocated()  # Fallback

        # Store original and replace with nvidia-smi version
        if not hasattr(_torch.cuda, '_original_max_memory_allocated'):
            _torch.cuda._original_max_memory_allocated = _torch.cuda.max_memory_allocated
            _torch.cuda.max_memory_allocated = lambda device=None: _nvidia_smi_memory()

    if verbose:
        # Count parameters (VLA layers have hidden params, count from vla_layers)
        total_params = sum(
            vla.out_features * vla.in_features if hasattr(vla, 'out_features')
            else vla.num_embeddings * vla.embedding_dim
            for vla in vla_layers
        )
        print(f"\n{'='*50}")
        print(f"AXIOM: Memory-efficient training enabled")
        print(f"Parameters: {total_params/1e9:.1f}B")
        print(f"Learning rate: {lr}")
        print(f"VLA layers: {len(vla_layers)}")
        print(f"Auto-update: {'ON' if model._axiom_auto_backward else 'OFF (call model._axiom_update() after backward)'}")
        print(f"{'='*50}\n")

    return model


class TrainingStats:
    """
    Lightweight training progress tracker.

    Displays step, loss, perplexity, speed, GPU memory, and validation.

    Example:
        stats = TrainingStats(log_interval=100, eval_interval=500)
        for step, batch in enumerate(dataloader):
            loss = model(**batch).loss
            loss.backward()
            stats.log(step, loss.item())

            # Validation (optional)
            if step % 500 == 0:
                val_loss = evaluate(model, val_loader)
                stats.log_val(step, val_loss)
    """

    def __init__(self, log_interval: int = 100, eval_interval: int = 500, total_steps: int = None):
        """
        Args:
            log_interval: Print training stats every N steps (default: 100)
            eval_interval: Expected validation interval for display (default: 500)
            total_steps: Total training steps (for progress display)
        """
        self.log_interval = log_interval
        self.eval_interval = eval_interval
        self.total_steps = total_steps
        self._start_time = None
        self._step_time = None
        self._total_tokens = 0
        self._losses = []
        self._val_losses = []
        self._val_steps = []

    def log(self, step: int, loss: float, tokens: int = 0):
        """
        Log training step and display progress.

        Args:
            step: Current step number
            loss: Loss value for this step
            tokens: Number of tokens processed (for throughput)
        """
        import time
        import math

        if self._start_time is None:
            self._start_time = time.time()
            self._step_time = time.time()

        self._losses.append(loss)
        self._total_tokens += tokens

        if step > 0 and step % self.log_interval == 0:
            # Calculate stats
            elapsed = time.time() - self._step_time
            avg_loss = sum(self._losses[-self.log_interval:]) / min(len(self._losses), self.log_interval)
            ppl = math.exp(min(avg_loss, 20))  # Cap to avoid overflow

            # Throughput
            tps = tokens * self.log_interval / elapsed if elapsed > 0 and tokens > 0 else 0

            # Memory
            mem_str = ""
            if _HAS_TORCH and _torch.cuda.is_available():
                peak_gb = _torch.cuda.max_memory_allocated() / 1e9
                mem_str = f" | Peak: {peak_gb:.1f}GB"

            # Progress
            if self.total_steps:
                progress = f"Step {step:5d}/{self.total_steps}"
            else:
                progress = f"Step {step:5d}"

            # Speed string
            speed_str = f" | {tps:.0f} tok/s" if tps > 0 else ""

            print(f"{progress} | Loss: {avg_loss:.4f} | PPL: {ppl:.2f}{speed_str}{mem_str}")

            self._step_time = time.time()

    def log_val(self, step: int, val_loss: float):
        """
        Log validation results.

        Args:
            step: Current step number
            val_loss: Validation loss
        """
        import math

        self._val_losses.append(val_loss)
        self._val_steps.append(step)

        val_ppl = math.exp(min(val_loss, 20))

        # Show improvement from initial
        if len(self._val_losses) > 1:
            init_ppl = math.exp(min(self._val_losses[0], 20))
            improvement = (init_ppl - val_ppl) / init_ppl * 100
            print(f"         >>> Val Loss: {val_loss:.4f} | Val PPL: {val_ppl:.2f} ({improvement:+.1f}%)")
        else:
            print(f"         >>> Val Loss: {val_loss:.4f} | Val PPL: {val_ppl:.2f}")

    def summary(self):
        """Print final training summary."""
        import time
        import math

        if not self._losses:
            return

        total_time = time.time() - self._start_time
        final_loss = self._losses[-1]
        best_loss = min(self._losses)

        print(f"\n{'='*50}")
        print(f"Training Complete")
        print(f"  Train Loss: {self._losses[0]:.4f} -> {final_loss:.4f}")
        print(f"  Best Loss:  {best_loss:.4f}")

        # Validation summary
        if self._val_losses:
            init_val = self._val_losses[0]
            final_val = self._val_losses[-1]
            best_val = min(self._val_losses)
            init_ppl = math.exp(min(init_val, 20))
            final_ppl = math.exp(min(final_val, 20))
            best_ppl = math.exp(min(best_val, 20))
            improvement = (init_ppl - final_ppl) / init_ppl * 100
            print(f"  Val PPL:    {init_ppl:.2f} -> {final_ppl:.2f} ({improvement:+.1f}%)")
            print(f"  Best Val:   {best_ppl:.2f}")

        print(f"  Steps:      {len(self._losses)}")
        print(f"  Time:       {total_time/60:.1f} min")
        if self._total_tokens > 0:
            print(f"  Throughput: {self._total_tokens/total_time:.0f} tok/s avg")
        print(f"{'='*50}\n")


# Main exports
__all__ = [
    "axiom",
    "TrainingStats",
    "__version__",
]

# Note: AXIOM_CHECKPOINT and AXIOM_DDP moved to experimental/
# Use PyTorch's gradient_checkpointing_enable() for activation checkpointing
# AXIOM's built-in compression eliminates need for most distributed training
