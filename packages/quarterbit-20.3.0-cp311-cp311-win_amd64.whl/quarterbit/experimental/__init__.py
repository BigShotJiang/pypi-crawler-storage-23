"""
QuarterBit Experimental
=======================

Archived modules - not actively maintained.

- optimizer.py: Original AXIOM optimizer (replaced by VLA built-in)
- trainer.py: AXIOM_Trainer wrapper (replaced by simple axiom() function)
- modular_grad.py: Modular gradient handling (unused)
- vla_grad.py: VLA gradient compression (untested, may be integrated later)
"""
