# CLAUDE.md

## Project overview

artificer-dispatcher — programmatic-only library that polls task queues, dispatches agent subprocesses, and exposes an HTTP API for agents. Python 3.13+, uses `uv` for dependency management.

## Commands

- Tests: `.venv/bin/pytest`
- Install dev deps: `uv pip install -e ".[dev]"`

## Project structure

- Public API: `artificer/__init__.py`
- Backend convenience: `artificer/dispatch_backends.py` (`PlankaBackend`)
- Entry point: `AgentDispatcher` class with `@route()` decorator API in `artificer/dispatcher.py`
- Config dataclasses: `artificer/config.py`
- Entry point: `v2.py`

## Conventions

- Keep `README.md` in sync when adding/changing constructor args, endpoints, or backend adapters
- Backend adapters implement the `TaskAdapter` protocol in `artificer/adapters/base.py`
- Agent adapters implement the `AgentAdapter` protocol in `artificer/agents/base.py`
