from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from artificer.adapters.base import Task, TaskAdapter
    from artificer.config import RouteConfig
    from artificer.router import AgentProcess


class AgentAdapter(Protocol):
    """Protocol for agent-specific behavior adapters.

    Allows the router to delegate agent-specific operations without knowing
    which agent type it's dealing with. This enables future agent support
    without modifying core router code.
    """

    def augment_command(self, cmd: list[str], route: RouteConfig) -> list[str]:
        """Modify command before execution (e.g., add agent-specific flags).

        Args:
            cmd: The formatted command from route.format_command()
            route: The route configuration

        Returns:
            The augmented command list
        """
        ...

    def process_stdout_line(
        self, line: str, agent: AgentProcess, task: Task, adapter: TaskAdapter
    ) -> None:
        """Handle agent stdout line by line.

        Called for each line of stdout. Can extract session IDs, parse output,
        post comments, etc.

        Args:
            line: A single line of stdout (stripped)
            agent: The agent process being monitored
            task: The task being worked on
            adapter: The task adapter for posting comments, etc.
        """
        ...

    def format_spawn_comment(self, command_str: str) -> str:
        """Format the comment posted when spawning an agent.

        Args:
            command_str: The command as a space-joined string

        Returns:
            The comment text
        """
        ...

    def format_exit_comment(
        self,
        agent: AgentProcess,
        timed_out: bool,
        timeout: int | None,
        error_snippet: str,
        last_message: str,
    ) -> str:
        """Format the comment posted when an agent exits.

        Args:
            agent: The agent process that exited
            timed_out: Whether the agent timed out
            timeout: The timeout value in seconds (if any)
            error_snippet: Stderr output snippet (if any)
            last_message: Last message from the agent (if any)

        Returns:
            The comment text
        """
        ...

    def get_status_extras(self, agent: AgentProcess) -> dict[str, Any]:
        """Return agent-specific status fields.

        Args:
            agent: The agent process

        Returns:
            Dict of additional status fields to include in status endpoint
        """
        ...
