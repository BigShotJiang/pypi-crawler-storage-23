from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from artificer.adapters.base import Task, TaskAdapter
    from artificer.config import RouteConfig
    from artificer.router import AgentProcess


class DefaultAgentAdapter:
    """Default agent adapter with pass-through behavior.

    Used for non-Claude agents. Does not modify commands or parse output.
    """

    def augment_command(self, cmd: list[str], route: RouteConfig) -> list[str]:
        """Return command unchanged."""
        return cmd

    def process_stdout_line(
        self, line: str, agent: AgentProcess, task: Task, adapter: TaskAdapter
    ) -> None:
        """No-op for default adapter."""
        pass

    def format_spawn_comment(self, command_str: str) -> str:
        """Format generic spawn comment."""
        return f"Spawning agent with command `{command_str}`"

    def format_exit_comment(
        self,
        agent: AgentProcess,
        timed_out: bool,
        timeout: int | None,
        error_snippet: str,
        last_message: str,
    ) -> str:
        """Format generic exit comment."""
        if timed_out:
            return f"Agent session ended: timed out after {timeout}s"
        elif agent.process.returncode is None:
            return "Agent session ended: cancelled"
        elif agent.process.returncode == 0:
            return "Agent session ended normally (exit 0)"
        else:
            return f"Agent session ended: exit code {agent.process.returncode}: {error_snippet}"

    def get_status_extras(self, agent: AgentProcess) -> dict[str, Any]:
        """Return empty dict for default adapter."""
        return {}
