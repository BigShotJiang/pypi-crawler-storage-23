from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import dataclass, field


@dataclass
class RouteConfig:
    queue_name: str
    command: str
    args: list[str] = field(default_factory=list)
    in_progress_queue: str = "In Progress"
    timeout: int | None = None  # timeout in seconds, None = no timeout
    poll_interval: int | None = None  # per-queue poll interval in seconds, None = use global
    priority: int | None = None  # dispatch priority, lower = higher priority, None = use registration index
    prompt_fn: Callable[[str, str], str] | None = None  # (task_id, task_name) -> prompt string

    def format_command(
        self,
        task_id: str,
        task_name: str,
        task_url: str = "",
    ) -> list[str]:
        replacements = {
            "{task_id}": task_id,
            "{task_name}": task_name,
            "{task_url}": task_url,
        }
        formatted_args = []
        for arg in self.args:
            for placeholder, value in replacements.items():
                arg = arg.replace(placeholder, value)
            formatted_args.append(arg)

        cmd = [self.command, *formatted_args]

        if self.prompt_fn is not None:
            prompt = self.prompt_fn(task_id, task_name)
            cmd.append(prompt)

        return cmd


@dataclass
class PlankaCredentials:
    token: str | None = None
    username: str | None = None
    password: str | None = None

    @classmethod
    def from_env(cls) -> PlankaCredentials:
        token = os.environ.get("PLANKA_TOKEN")
        if token:
            return cls(token=token)
        username = os.environ.get("PLANKA_USER")
        password = os.environ.get("PLANKA_PASSWORD")
        if username and password:
            return cls(username=username, password=password)
        raise EnvironmentError(
            "Set PLANKA_TOKEN or both PLANKA_USER and PLANKA_PASSWORD"
        )
