from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Protocol


@dataclass
class TaskComment:
    author: str
    text: str
    created_at: str = ""


@dataclass
class Queue:
    name: str
    task_count: int


@dataclass
class Task:
    id: str
    name: str
    description: str = ""
    url: str = ""
    source_queue: str = ""
    labels: list[str] = field(default_factory=list)
    assignees: list[str] = field(default_factory=list)
    comments: list[TaskComment] = field(default_factory=list)


class TaskAdapter(Protocol):
    def get_ready_tasks(self, queue_names: Sequence[str]) -> list[Task]: ...

    def get_task(self, task_id: str) -> Task: ...

    def move_task(self, task_id: str, target_queue: str) -> None: ...

    def add_comment(self, task_id: str, text: str) -> None: ...

    def update_task(
        self,
        task_id: str,
        *,
        assignees: list[str] | None = None,
        name: str | None = None,
        description: str | None = None,
        labels: list[str] | None = None,
    ) -> None:
        """Update one or more fields on a task.

        Each parameter defaults to ``None``, meaning "don't change this field".
        When a value is provided (even an empty list), it replaces the current
        value (replacement semantics, not append).

        The special string ``"me"`` in the *assignees* list means "the
        currently authenticated user", resolved by each adapter implementation.
        """
        ...

    def create_task(self, queue_name: str, name: str, description: str = "") -> Task: ...

    def list_queues(self) -> list[Queue]: ...

    def get_queue(self, queue_name: str) -> Queue: ...

    def create_queue(self, queue_name: str) -> Queue: ...

    def update_queue(self, queue_name: str, *, new_name: str | None = None) -> Queue: ...

    def delete_queue(self, queue_name: str) -> None: ...
