from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from artificer.adapters.base import TaskAdapter


class PlankaBackend:
    """Convenience wrapper for configuring the Planka task backend.

    Credentials can be supplied directly or resolved from environment
    variables at ``create_adapter()`` time (i.e. when ``dispatcher.run()``
    is called).

    Args:
        url: The Planka server URL (e.g. ``"http://localhost:3000"``).
        token: Optional API token for authentication.
        username: Optional username for password authentication.
        password: Optional password for password authentication.
    """

    def __init__(
        self,
        url: str,
        *,
        token: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self.url = url
        self._token = token
        self._username = username
        self._password = password

    def create_adapter(self) -> TaskAdapter:
        from artificer.config import PlankaCredentials
        from artificer.adapters.planka import PlankaAdapter

        if self._token or self._username:
            credentials = PlankaCredentials(
                token=self._token,
                username=self._username,
                password=self._password,
            )
        else:
            credentials = PlankaCredentials.from_env()
        return PlankaAdapter(self.url, credentials)
