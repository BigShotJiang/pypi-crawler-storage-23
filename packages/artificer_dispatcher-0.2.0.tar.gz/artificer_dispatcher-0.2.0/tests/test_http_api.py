from __future__ import annotations

import json

import pytest
from starlette.testclient import TestClient

from artificer.adapters.json_file import JsonFileAdapter
from artificer.http_api import create_app


@pytest.fixture
def adapter(tmp_path) -> JsonFileAdapter:
    board_data = {
        "queues": {
            "Bugs": [
                {
                    "id": "1",
                    "name": "Fix crash",
                    "description": "App crashes",
                    "labels": ["urgent"],
                    "assignees": ["alice"],
                    "comments": [
                        {
                            "author": "bob",
                            "text": "Confirmed",
                            "created_at": "2025-01-01T00:00:00Z",
                        }
                    ],
                    "tasks": [
                        {"name": "Write test", "is_completed": False},
                        {"name": "Fix code", "is_completed": True},
                    ],
                },
            ],
            "In Progress": [],
            "Done": [],
        }
    }
    path = tmp_path / "board.json"
    path.write_text(json.dumps(board_data))
    return JsonFileAdapter(path)


@pytest.fixture
def client(adapter) -> TestClient:
    return TestClient(create_app(adapter))


class TestGetTaskDetails:
    def test_returns_task(self, client):
        resp = client.get("/tasks/1")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == "1"
        assert data["name"] == "Fix crash"
        assert "App crashes" in data["description"]
        assert data["labels"] == ["urgent"]
        assert data["assignees"] == ["alice"]

    def test_not_found(self, client):
        resp = client.get("/tasks/999")
        assert resp.status_code == 404
        assert "error" in resp.json()


class TestCommentsInTaskDetails:
    def test_comments_included(self, client):
        resp = client.get("/tasks/1")
        data = resp.json()
        assert len(data["comments"]) == 1
        assert data["comments"][0]["author"] == "bob"
        assert data["comments"][0]["text"] == "Confirmed"


class TestAddComment:
    def test_adds_comment(self, client):
        resp = client.post("/tasks/1/comments", json={"comment": "Working on it"})
        assert resp.status_code == 200
        assert "message" in resp.json()

        # Verify comment was persisted via task details
        resp = client.get("/tasks/1")
        comments = resp.json()["comments"]
        assert any(c["text"] == "Working on it" for c in comments)

    def test_missing_comment_field(self, client):
        resp = client.post("/tasks/1/comments", json={})
        assert resp.status_code == 400
        assert "comment" in resp.json()["error"]

    def test_not_found(self, client):
        resp = client.post("/tasks/999/comments", json={"comment": "test"})
        assert resp.status_code == 404


class TestMoveTask:
    def test_moves_task(self, client):
        resp = client.post("/tasks/1/move", json={"target_queue": "In Progress"})
        assert resp.status_code == 200
        assert "In Progress" in resp.json()["message"]

        # Verify task moved
        resp = client.get("/tasks/1")
        assert resp.json()["source_queue"] == "In Progress"

    def test_missing_target_queue(self, client):
        resp = client.post("/tasks/1/move", json={})
        assert resp.status_code == 400
        assert "target_queue" in resp.json()["error"]

    def test_not_found_task(self, client):
        resp = client.post("/tasks/999/move", json={"target_queue": "Done"})
        assert resp.status_code == 404

    def test_not_found_queue(self, client):
        resp = client.post("/tasks/1/move", json={"target_queue": "Nonexistent"})
        assert resp.status_code == 404


class TestUpdateTask:
    def test_patch_updates_name(self, client):
        resp = client.patch("/tasks/1", json={"name": "New name"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "New name"

    def test_patch_updates_assignees(self, client):
        resp = client.patch("/tasks/1", json={"assignees": ["bob"]})
        assert resp.status_code == 200
        data = resp.json()
        assert data["assignees"] == ["bob"]

    def test_patch_updates_labels(self, client):
        resp = client.patch("/tasks/1", json={"labels": ["bug", "critical"]})
        assert resp.status_code == 200
        data = resp.json()
        assert data["labels"] == ["bug", "critical"]

    def test_patch_updates_description(self, client):
        resp = client.patch("/tasks/1", json={"description": "New desc"})
        assert resp.status_code == 200
        data = resp.json()
        assert "New desc" in data["description"]

    def test_patch_empty_body_returns_400(self, client):
        resp = client.patch("/tasks/1", json={})
        assert resp.status_code == 400
        assert "No updatable fields" in resp.json()["error"]

    def test_patch_not_found_returns_404(self, client):
        resp = client.patch("/tasks/999", json={"name": "Nope"})
        assert resp.status_code == 404

    def test_patch_returns_full_task(self, client):
        resp = client.patch("/tasks/1", json={"name": "Updated"})
        assert resp.status_code == 200
        data = resp.json()
        assert "id" in data
        assert "name" in data
        assert "description" in data
        assert "labels" in data
        assert "assignees" in data
        assert "comments" in data
        assert "url" in data
        assert "source_queue" in data


class TestCreateTask:
    def test_creates_task(self, client):
        resp = client.post(
            "/tasks",
            json={
                "queue_name": "Bugs",
                "name": "New bug",
                "description": "Something broke",
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "New bug"
        assert data["description"] == "Something broke"
        assert data["source_queue"] == "Bugs"
        assert data["id"]  # should have an id

    def test_missing_fields(self, client):
        resp = client.post("/tasks", json={"queue_name": "Bugs"})
        assert resp.status_code == 400
        assert "name" in resp.json()["error"]

    def test_not_found_queue(self, client):
        resp = client.post(
            "/tasks",
            json={
                "queue_name": "Nonexistent",
                "name": "task",
                "description": "desc",
            },
        )
        assert resp.status_code == 404
