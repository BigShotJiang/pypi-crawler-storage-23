from __future__ import annotations

import json

import pytest

from artificer.adapters.base import Task
from artificer.adapters.json_file import JsonFileAdapter


@pytest.fixture
def json_board_data() -> dict:
    return {
        "queues": {
            "Bugs": [
                {
                    "id": "1",
                    "name": "Fix login crash",
                    "description": "App crashes on login",
                    "labels": ["urgent"],
                    "assignees": ["alice"],
                    "comments": [
                        {"author": "bob", "text": "Reproduced on staging", "created_at": "2025-01-01T00:00:00Z"}
                    ],
                    "tasks": [
                        {"name": "Write test", "is_completed": False},
                        {"name": "Fix code", "is_completed": False},
                    ],
                },
                {
                    "id": "2",
                    "name": "Fix timeout error",
                    "description": "API times out after 30s",
                    "labels": [],
                    "assignees": [],
                    "comments": [],
                    "tasks": [],
                },
            ],
            "Features": [
                {
                    "id": "3",
                    "name": "Add dark mode",
                    "description": "Support dark theme",
                    "labels": ["enhancement"],
                    "assignees": ["charlie"],
                    "comments": [],
                    "tasks": [],
                },
            ],
            "In Progress": [],
            "Done": [],
        }
    }


@pytest.fixture
def json_adapter(tmp_path, json_board_data) -> JsonFileAdapter:
    path = tmp_path / "board.json"
    path.write_text(json.dumps(json_board_data))
    return JsonFileAdapter(path)


@pytest.fixture
def sample_tasks() -> list[Task]:
    return [
        Task(id="1", name="Fix login crash", description="App crashes on login", source_queue="Bugs", labels=["urgent"], assignees=["alice"]),
        Task(id="2", name="Fix timeout error", description="API times out after 30s", source_queue="Bugs"),
        Task(id="3", name="Add dark mode", description="Support dark theme", source_queue="Features", labels=["enhancement"], assignees=["charlie"]),
    ]
