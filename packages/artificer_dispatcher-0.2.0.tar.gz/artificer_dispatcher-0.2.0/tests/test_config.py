from __future__ import annotations

import pytest

from artificer.config import (
    PlankaCredentials,
    RouteConfig,
)


class TestRouteConfig:
    def test_format_command(self):
        route = RouteConfig(
            queue_name="Bugs",
            command="claude",
            args=["-p", "Fix bug #{task_id}: {task_name}"],
        )
        result = route.format_command(
            task_id="42",
            task_name="Login crash",
            task_url="http://example.com/cards/42",
        )
        assert result == [
            "claude",
            "-p",
            "Fix bug #42: Login crash",
        ]

    def test_format_command_with_prompt_fn(self):
        """When prompt_fn is set, its return value is appended to the command."""
        def my_prompt(task_id: str, task_name: str) -> str:
            return f"Work on task {task_id}: {task_name}."

        route = RouteConfig(
            queue_name="Bugs",
            command="claude",
            args=["--agent", "engineer", "-p"],
            prompt_fn=my_prompt,
        )
        result = route.format_command(
            task_id="42",
            task_name="Login crash",
            task_url="http://example.com/cards/42",
        )
        assert result == [
            "claude",
            "--agent",
            "engineer",
            "-p",
            "Work on task 42: Login crash.",
        ]

    def test_format_command_prompt_fn_none_no_append(self):
        """When prompt_fn is None, nothing extra is appended."""
        route = RouteConfig(
            queue_name="Bugs",
            command="echo",
            args=["hello"],
            prompt_fn=None,
        )
        result = route.format_command(task_id="1", task_name="Test")
        assert result == ["echo", "hello"]

    def test_format_command_template_and_prompt_fn_coexist(self):
        """Template substitution still works alongside prompt_fn."""
        def my_prompt(task_id: str, task_name: str) -> str:
            return f"Prompt for {task_id}"

        route = RouteConfig(
            queue_name="Bugs",
            command="claude",
            args=["-p", "Bug {task_id}"],
            prompt_fn=my_prompt,
        )
        result = route.format_command(task_id="99", task_name="Crash")
        # Template args are substituted, then prompt_fn result is appended
        assert result == ["claude", "-p", "Bug 99", "Prompt for 99"]

    def test_format_command_with_task_url_placeholder(self):
        route = RouteConfig(
            queue_name="Bugs",
            command="echo",
            args=["{task_url}"],
        )
        result = route.format_command(
            task_id="1",
            task_name="Test",
            task_url="http://example.com/1",
        )
        assert result == ["echo", "http://example.com/1"]

    def test_prompt_fn_default_is_none(self):
        """RouteConfig defaults prompt_fn to None."""
        route = RouteConfig(queue_name="Q", command="echo")
        assert route.prompt_fn is None

    def test_priority_default_is_none(self):
        """RouteConfig defaults priority to None."""
        route = RouteConfig(queue_name="Q", command="echo")
        assert route.priority is None

    def test_priority_field_stored(self):
        """RouteConfig stores an explicit priority value."""
        route = RouteConfig(queue_name="Q", command="echo", priority=5)
        assert route.priority == 5


class TestRouteConfigResearch:
    def test_research_route_command_formatting(self):
        """Test that the Research route formats commands correctly."""
        route = RouteConfig(
            queue_name="Artificer Dispatcher.Research.Todo",
            command="claude",
            args=["--agent", "research", "-p", "Work on task {task_id}: {task_name}."],
            in_progress_queue="Artificer Dispatcher.Research.In Progress",
        )
        result = route.format_command(
            task_id="123",
            task_name="Investigate API performance",
            task_url="http://example.com/cards/123",
        )
        assert result == [
            "claude",
            "--agent",
            "research",
            "-p",
            "Work on task 123: Investigate API performance.",
        ]


class TestPlankaCredentials:
    def test_from_env_token(self, monkeypatch):
        monkeypatch.setenv("PLANKA_TOKEN", "my-token")
        monkeypatch.delenv("PLANKA_USER", raising=False)
        monkeypatch.delenv("PLANKA_PASSWORD", raising=False)
        creds = PlankaCredentials.from_env()
        assert creds.token == "my-token"
        assert creds.username is None

    def test_from_env_password(self, monkeypatch):
        monkeypatch.delenv("PLANKA_TOKEN", raising=False)
        monkeypatch.setenv("PLANKA_USER", "admin")
        monkeypatch.setenv("PLANKA_PASSWORD", "secret")
        creds = PlankaCredentials.from_env()
        assert creds.token is None
        assert creds.username == "admin"
        assert creds.password == "secret"

    def test_from_env_missing(self, monkeypatch):
        monkeypatch.delenv("PLANKA_TOKEN", raising=False)
        monkeypatch.delenv("PLANKA_USER", raising=False)
        monkeypatch.delenv("PLANKA_PASSWORD", raising=False)
        with pytest.raises(EnvironmentError):
            PlankaCredentials.from_env()
