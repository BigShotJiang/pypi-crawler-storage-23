from __future__ import annotations

import json

import pytest

from artificer.adapters.json_file import JsonFileAdapter
from artificer.task_operations import (
    _add_comment,
    _create_task,
    _get_task_details,
    _move_task,
    _update_task,
)


def _make_adapter(tmp_path) -> JsonFileAdapter:
    board_data = {
        "queues": {
            "Bugs": [
                {
                    "id": "1",
                    "name": "Fix crash",
                    "description": "App crashes",
                    "labels": ["urgent"],
                    "assignees": ["alice"],
                    "comments": [
                        {"author": "bob", "text": "Confirmed", "created_at": "2025-01-01T00:00:00Z"}
                    ],
                    "tasks": [
                        {"name": "Write test", "is_completed": False},
                        {"name": "Fix code", "is_completed": True},
                    ],
                },
            ],
            "In Progress": [],
            "Done": [],
        }
    }
    path = tmp_path / "board.json"
    path.write_text(json.dumps(board_data))
    return JsonFileAdapter(path)


class TestGetTaskDetails:
    def test_returns_task_fields(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _get_task_details(adapter, "1")
        assert result["id"] == "1"
        assert result["name"] == "Fix crash"
        assert "App crashes" in result["description"]
        assert result["labels"] == ["urgent"]
        assert result["assignees"] == ["alice"]

    def test_not_found_raises_key_error(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        with pytest.raises(KeyError):
            _get_task_details(adapter, "999")


class TestCommentsInTaskDetails:
    def test_comments_included(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _get_task_details(adapter, "1")
        assert len(result["comments"]) == 1
        assert result["comments"][0]["author"] == "bob"
        assert result["comments"][0]["text"] == "Confirmed"


class TestAddComment:
    def test_comment_appears_in_task(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _add_comment(adapter, "1", "Working on it")
        assert "Comment added" in result

        task = adapter.get_task("1")
        assert any(c.text == "Working on it" for c in task.comments)


class TestMoveTask:
    def test_moves_to_target_queue(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _move_task(adapter, "1", "In Progress")
        assert "In Progress" in result

        task = adapter.get_task("1")
        assert task.source_queue == "In Progress"


class TestUpdateTask:
    def test_update_returns_updated_task(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _update_task(adapter, "1", name="Updated crash")
        assert result["id"] == "1"
        assert result["name"] == "Updated crash"
        assert result["labels"] == ["urgent"]
        assert result["assignees"] == ["alice"]
        assert "comments" in result

    def test_update_partial_fields(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _update_task(adapter, "1", name="New name")
        assert result["name"] == "New name"
        # Other fields should remain unchanged
        assert result["labels"] == ["urgent"]
        assert result["assignees"] == ["alice"]


class TestCreateTask:
    def test_creates_task_in_queue(self, tmp_path):
        adapter = _make_adapter(tmp_path)
        result = _create_task(adapter, "Bugs", "New bug", "Something broke")
        assert result["name"] == "New bug"
        assert result["description"] == "Something broke"
        assert result["source_queue"] == "Bugs"
        assert result["id"]  # should have an id
