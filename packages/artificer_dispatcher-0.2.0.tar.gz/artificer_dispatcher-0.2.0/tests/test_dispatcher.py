from __future__ import annotations

import asyncio
import json
from unittest.mock import MagicMock, patch

import pytest

from artificer.adapters.json_file import JsonFileAdapter
from artificer.agents.default import DefaultAgentAdapter
from artificer.config import RouteConfig
from artificer.dispatcher import AgentDispatcher
from artificer.router import Router


def _make_board(tmp_path) -> tuple[str, JsonFileAdapter]:
    board_data = {
        "queues": {
            "Bugs": [
                {
                    "id": "1",
                    "name": "Bug one",
                    "description": "d1",
                    "labels": [],
                    "assignees": [],
                    "comments": [],
                    "tasks": [],
                },
            ],
            "In Progress": [],
            "Done": [],
        }
    }
    path = tmp_path / "board.json"
    path.write_text(json.dumps(board_data))
    return str(path), JsonFileAdapter(path)


# ---------------------------------------------------------------------------
# Public API imports
# ---------------------------------------------------------------------------


class TestPublicAPIImports:
    """Verify all expected names are importable from the new artificer package."""

    def test_artificer_package_imports(self):
        from artificer import (
            AgentAdapter,
            AgentDispatcher,
            ClaudeAgentAdapter,
            DefaultAgentAdapter,
            JsonFileAdapter,
            PlankaAdapter,
            PlankaCredentials,
            Queue,
            Task,
            TaskAdapter,
            TaskComment,
        )
        assert AgentDispatcher is not None
        assert AgentAdapter is not None
        assert ClaudeAgentAdapter is not None
        assert DefaultAgentAdapter is not None
        assert JsonFileAdapter is not None
        assert PlankaAdapter is not None
        assert PlankaCredentials is not None
        assert Queue is not None
        assert Task is not None
        assert TaskAdapter is not None
        assert TaskComment is not None

    def test_artificer_all_matches_expected(self):
        import artificer

        expected = {
            "AgentDispatcher",
            "AgentAdapter",
            "ClaudeAgentAdapter",
            "DefaultAgentAdapter",
            "JsonFileAdapter",
            "PlankaAdapter",
            "PlankaCredentials",
            "Queue",
            "Task",
            "TaskAdapter",
            "TaskComment",
        }
        assert set(artificer.__all__) == expected

    def test_dispatch_backends_import(self):
        from artificer.dispatch_backends import PlankaBackend

        assert PlankaBackend is not None


# ---------------------------------------------------------------------------
# AgentDispatcher construction
# ---------------------------------------------------------------------------


class TestAgentDispatcherConstruction:
    def test_stores_command(self):
        d = AgentDispatcher(command="echo")
        assert d._command == "echo"

    def test_stores_all_kwargs(self):
        d = AgentDispatcher(
            command="claude",
            poll_interval=10,
            agent_timeout=300,
            max_concurrent_agents=5,
            api_host="0.0.0.0",
            api_port=9000,
            enable_queue_management=True,
        )
        assert d._poll_interval == 10
        assert d._agent_timeout == 300
        assert d._max_concurrent_agents == 5
        assert d._api_host == "0.0.0.0"
        assert d._api_port == 9000
        assert d._enable_queue_management is True

    def test_defaults(self):
        d = AgentDispatcher(command="echo")
        assert d._poll_interval == 30
        assert d._agent_timeout is None
        assert d._max_concurrent_agents == 3
        assert d._api_host == "127.0.0.1"
        assert d._api_port == 8000
        assert d._queue_backend is None
        assert d._agent_adapters is None
        assert d._enable_queue_management is False

    def test_stores_queue_backend(self, tmp_path):
        _, adapter = _make_board(tmp_path)
        d = AgentDispatcher(command="echo", queue_backend=adapter)
        assert d._queue_backend is adapter

    def test_stores_agent_adapters(self):
        custom = DefaultAgentAdapter()
        d = AgentDispatcher(command="echo", agent_adapters={"custom": custom})
        assert d._agent_adapters == {"custom": custom}


# ---------------------------------------------------------------------------
# Decorator route API
# ---------------------------------------------------------------------------


class TestRouteDecorator:
    def test_single_route_collected(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs", in_progress_queue="In Progress")
        def handle_bug(task_id: str, task_name: str) -> str:
            return f"Fix bug {task_id}: {task_name}"

        assert len(d._routes) == 1
        route = d._routes[0]
        assert route.queue_name == "Bugs"
        assert route.command == "claude"
        assert route.in_progress_queue == "In Progress"
        assert route.prompt_fn is handle_bug

    def test_multiple_routes_collected_in_order(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs")
        def handle_bug(task_id: str, task_name: str) -> str:
            return "bug"

        @d.route(queue_name="Features")
        def handle_feature(task_id: str, task_name: str) -> str:
            return "feature"

        assert len(d._routes) == 2
        assert d._routes[0].queue_name == "Bugs"
        assert d._routes[1].queue_name == "Features"

    def test_route_stores_args(self):
        d = AgentDispatcher(command="claude")

        @d.route(
            queue_name="Bugs",
            args=["--agent", "engineer", "-p"],
        )
        def handle(task_id: str, task_name: str) -> str:
            return "prompt"

        assert d._routes[0].args == ["--agent", "engineer", "-p"]

    def test_route_stores_timeout_and_poll_interval(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs", timeout=120, poll_interval=5)
        def handle(task_id: str, task_name: str) -> str:
            return "prompt"

        route = d._routes[0]
        assert route.timeout == 120
        assert route.poll_interval == 5

    def test_route_stores_priority(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs", priority=3)
        def handle(task_id: str, task_name: str) -> str:
            return "prompt"

        assert d._routes[0].priority == 3

    def test_route_priority_default_none(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs")
        def handle(task_id: str, task_name: str) -> str:
            return "prompt"

        assert d._routes[0].priority is None

    def test_decorator_returns_original_function(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs")
        def handle_bug(task_id: str, task_name: str) -> str:
            return "prompt"

        # The original function is returned, not a wrapper
        assert handle_bug("1", "Test") == "prompt"

    def test_route_config_has_prompt_fn(self):
        d = AgentDispatcher(command="claude")

        @d.route(queue_name="Bugs", args=["--agent", "eng", "-p"])
        def my_prompt(task_id: str, task_name: str) -> str:
            return f"Work on {task_id}: {task_name}."

        route = d._routes[0]
        # Verify format_command calls prompt_fn and appends result
        cmd = route.format_command(task_id="42", task_name="Crash")
        assert cmd == ["claude", "--agent", "eng", "-p", "Work on 42: Crash."]


# ---------------------------------------------------------------------------
# _resolve_adapter
# ---------------------------------------------------------------------------


class TestResolveAdapter:
    def test_resolve_task_adapter_directly(self, tmp_path):
        """A TaskAdapter passed directly is used as-is."""
        _, adapter = _make_board(tmp_path)
        d = AgentDispatcher(command="echo", queue_backend=adapter)
        assert d._resolve_adapter() is adapter

    def test_resolve_planka_backend(self):
        """A PlankaBackend is resolved via create_adapter()."""
        mock_backend = MagicMock()
        mock_adapter = MagicMock()
        mock_backend.create_adapter.return_value = mock_adapter

        d = AgentDispatcher(command="echo", queue_backend=mock_backend)
        result = d._resolve_adapter()
        assert result is mock_adapter
        mock_backend.create_adapter.assert_called_once()

    def test_resolve_none_raises(self):
        """No queue_backend raises ValueError."""
        d = AgentDispatcher(command="echo")
        with pytest.raises(ValueError, match="No queue_backend configured"):
            d._resolve_adapter()


# ---------------------------------------------------------------------------
# Custom agent adapters (through Router)
# ---------------------------------------------------------------------------


class TestCustomAgentAdapters:
    """Tests for custom agent adapter registration through AgentDispatcher -> Router."""

    def test_custom_adapter_used_for_command(self, tmp_path):
        """A custom agent adapter is returned by Router for its command."""
        _, adapter = _make_board(tmp_path)
        router_kwargs = _make_router_kwargs()

        class MyAdapter:
            def augment_command(self, cmd, route):
                return cmd

            def process_stdout_line(self, line, agent, task, adapter):
                pass

            def format_spawn_comment(self, command_str):
                return f"Running: {command_str}"

            def format_exit_comment(self, agent, timed_out, timeout, error_snippet, last_message):
                return "Done"

            def get_status_extras(self, agent):
                return {}

        custom = MyAdapter()
        router = Router(adapter, **router_kwargs, agent_adapters={"my-agent": custom})
        assert router._adapter_for_command("my-agent") is custom

    def test_custom_adapter_overrides_builtin(self, tmp_path):
        """Registering 'claude' overrides the built-in ClaudeAgentAdapter."""
        _, adapter = _make_board(tmp_path)
        custom = DefaultAgentAdapter()
        router = Router(adapter, **_make_router_kwargs(), agent_adapters={"claude": custom})
        assert router._adapter_for_command("claude") is custom

    def test_default_adapter_for_unknown_command(self, tmp_path):
        """Unknown commands fall back to the default agent adapter."""
        _, adapter = _make_board(tmp_path)
        router = Router(adapter, **_make_router_kwargs())
        result = router._adapter_for_command("unknown-command")
        assert isinstance(result, DefaultAgentAdapter)
        assert result is router._default_agent_adapter

    def test_builtin_claude_adapter_without_overrides(self, tmp_path):
        """Without custom adapters, 'claude' uses the built-in ClaudeAgentAdapter."""
        from artificer.agents.claude import ClaudeAgentAdapter

        _, adapter = _make_board(tmp_path)
        router = Router(adapter, **_make_router_kwargs())
        result = router._adapter_for_command("claude")
        assert isinstance(result, ClaudeAgentAdapter)


# ---------------------------------------------------------------------------
# run_async
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestAgentDispatcherRunAsync:
    async def test_run_async_starts_and_stops(self, tmp_path):
        """AgentDispatcher.run_async() starts and can be cancelled cleanly."""
        _, adapter = _make_board(tmp_path)
        d = AgentDispatcher(
            command="echo",
            api_port=19876,
            queue_backend=adapter,
        )

        @d.route(queue_name="Bugs", in_progress_queue="In Progress")
        def handle(task_id, task_name):
            return "p"

        with (
            patch("uvicorn.Config") as mock_uvicorn_config,
            patch("uvicorn.Server") as mock_uvicorn_server,
        ):
            mock_server = MagicMock()
            mock_server.run = MagicMock(return_value=None)
            mock_uvicorn_server.return_value = mock_server

            task = asyncio.create_task(d.run_async())
            await asyncio.sleep(0.1)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    async def test_run_async_passes_agent_adapters_to_router(self, tmp_path):
        """AgentDispatcher forwards agent_adapters to Router."""
        _, adapter = _make_board(tmp_path)
        custom = DefaultAgentAdapter()

        d = AgentDispatcher(
            command="echo",
            api_port=19877,
            queue_backend=adapter,
            agent_adapters={"custom-cmd": custom},
        )

        @d.route(queue_name="Bugs")
        def handle(task_id, task_name):
            return "p"

        with (
            patch("uvicorn.Config"),
            patch("uvicorn.Server") as mock_uvicorn_server,
            patch(
                "artificer.router.Router", wraps=Router
            ) as mock_router_cls,
        ):
            mock_server = MagicMock()
            mock_server.run = MagicMock(return_value=None)
            mock_uvicorn_server.return_value = mock_server

            task = asyncio.create_task(d.run_async())
            await asyncio.sleep(0.1)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

            mock_router_cls.assert_called_once()
            call_kwargs = mock_router_cls.call_args
            assert call_kwargs.kwargs["agent_adapters"] == {"custom-cmd": custom}

    async def test_run_async_passes_enable_queue_management(self, tmp_path):
        """AgentDispatcher forwards enable_queue_management to create_app."""
        _, adapter = _make_board(tmp_path)

        d = AgentDispatcher(
            command="echo",
            api_port=19878,
            queue_backend=adapter,
            enable_queue_management=True,
        )

        @d.route(queue_name="Bugs")
        def handle(task_id, task_name):
            return "p"

        with (
            patch("uvicorn.Config"),
            patch("uvicorn.Server") as mock_uvicorn_server,
            patch(
                "artificer.http_api.create_app"
            ) as mock_create_app,
        ):
            mock_server = MagicMock()
            mock_server.run = MagicMock(return_value=None)
            mock_uvicorn_server.return_value = mock_server
            mock_create_app.return_value = MagicMock()

            task = asyncio.create_task(d.run_async())
            await asyncio.sleep(0.1)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

            mock_create_app.assert_called_once()
            call_kwargs = mock_create_app.call_args
            assert call_kwargs.kwargs.get("enable_queue_management") is True


# ---------------------------------------------------------------------------
# run (blocking)
# ---------------------------------------------------------------------------


class TestAgentDispatcherRun:
    def test_run_handles_keyboard_interrupt(self, tmp_path):
        """AgentDispatcher.run() catches KeyboardInterrupt gracefully."""
        _, adapter = _make_board(tmp_path)
        d = AgentDispatcher(command="echo", queue_backend=adapter)

        with patch("asyncio.run", side_effect=KeyboardInterrupt):
            # Should not raise
            d.run()


# ---------------------------------------------------------------------------
# PlankaBackend
# ---------------------------------------------------------------------------


class TestPlankaBackend:
    def test_stores_url(self):
        from artificer.dispatch_backends import PlankaBackend

        backend = PlankaBackend(url="http://localhost:3000")
        assert backend.url == "http://localhost:3000"

    def test_create_adapter_calls_planka(self, monkeypatch):
        from artificer.dispatch_backends import PlankaBackend

        mock_adapter = MagicMock()
        with (
            patch(
                "artificer.config.PlankaCredentials.from_env"
            ) as mock_creds,
            patch(
                "artificer.adapters.planka.PlankaAdapter",
                return_value=mock_adapter,
            ) as mock_cls,
        ):
            mock_creds.return_value = MagicMock()
            backend = PlankaBackend(url="http://localhost:3000")
            result = backend.create_adapter()

            assert result is mock_adapter
            mock_creds.assert_called_once()
            mock_cls.assert_called_once()
            # Verify the url string was passed directly
            call_args = mock_cls.call_args
            assert call_args[0][0] == "http://localhost:3000"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_router_kwargs() -> dict:
    return {
        "poll_interval": 1,
        "max_concurrent_agents": 2,
        "routes": [
            RouteConfig(
                queue_name="Bugs",
                command="echo",
                args=["bug"],
                in_progress_queue="In Progress",
            ),
        ],
    }
