from __future__ import annotations

import json

import pytest

from artificer.adapters.json_file import JsonFileAdapter


class TestGetReadyTasks:
    def test_returns_tasks_from_matching_queues(self, json_adapter):
        tasks = json_adapter.get_ready_tasks(["Bugs"])
        assert len(tasks) == 2
        assert tasks[0].id == "1"
        assert tasks[0].name == "Fix login crash"
        assert tasks[0].source_queue == "Bugs"
        assert tasks[1].id == "2"

    def test_returns_tasks_from_multiple_queues(self, json_adapter):
        tasks = json_adapter.get_ready_tasks(["Bugs", "Features"])
        assert len(tasks) == 3

    def test_ignores_missing_queues(self, json_adapter):
        tasks = json_adapter.get_ready_tasks(["Nonexistent"])
        assert tasks == []


class TestGetTask:
    def test_finds_task_by_id(self, json_adapter):
        task = json_adapter.get_task("1")
        assert task.name == "Fix login crash"
        assert "App crashes on login" in task.description
        assert task.labels == ["urgent"]
        assert task.assignees == ["alice"]

    def test_finds_task_in_any_queue(self, json_adapter):
        task = json_adapter.get_task("3")
        assert task.name == "Add dark mode"
        assert task.source_queue == "Features"

    def test_not_found_raises_key_error(self, json_adapter):
        with pytest.raises(KeyError, match="Task not found"):
            json_adapter.get_task("999")


class TestMoveTask:
    def test_moves_task_between_queues(self, json_adapter):
        json_adapter.move_task("1", "In Progress")
        task = json_adapter.get_task("1")
        assert task.source_queue == "In Progress"

        bugs = json_adapter.get_ready_tasks(["Bugs"])
        assert all(t.id != "1" for t in bugs)

        in_progress = json_adapter.get_ready_tasks(["In Progress"])
        assert any(t.id == "1" for t in in_progress)

    def test_persists_to_file(self, json_adapter):
        json_adapter.move_task("1", "In Progress")
        data = json.loads(json_adapter._path.read_text())
        bug_ids = [t["id"] for t in data["queues"]["Bugs"]]
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        assert "1" not in bug_ids
        assert "1" in ip_ids

    def test_target_not_found_raises_key_error(self, json_adapter):
        with pytest.raises(KeyError, match="Target queue not found"):
            json_adapter.move_task("1", "Nonexistent")


class TestAddComment:
    def test_appends_comment(self, json_adapter):
        json_adapter.add_comment("1", "Working on it")
        task = json_adapter.get_task("1")
        assert len(task.comments) == 2
        assert task.comments[-1].text == "Working on it"
        assert task.comments[-1].author == "system"

    def test_persists_to_file(self, json_adapter):
        json_adapter.add_comment("2", "Hello")
        data = json.loads(json_adapter._path.read_text())
        task = next(t for t in data["queues"]["Bugs"] if t["id"] == "2")
        assert len(task["comments"]) == 1
        assert task["comments"][0]["text"] == "Hello"


class TestCommentsInTask:
    def test_returns_comments(self, json_adapter):
        task = json_adapter.get_task("1")
        assert len(task.comments) == 1
        assert task.comments[0].author == "bob"
        assert task.comments[0].text == "Reproduced on staging"

    def test_returns_empty_for_no_comments(self, json_adapter):
        task = json_adapter.get_task("2")
        assert task.comments == []


class TestUpdateTask:
    def test_update_name(self, json_adapter):
        json_adapter.update_task("1", name="New name")
        task = json_adapter.get_task("1")
        assert task.name == "New name"

    def test_update_description(self, json_adapter):
        json_adapter.update_task("1", description="New description")
        task = json_adapter.get_task("1")
        assert "New description" in task.description

    def test_update_assignees(self, json_adapter):
        json_adapter.update_task("1", assignees=["bob", "charlie"])
        task = json_adapter.get_task("1")
        assert task.assignees == ["bob", "charlie"]

    def test_update_assignees_me_resolves_to_system(self, json_adapter):
        json_adapter.update_task("2", assignees=["me"])
        task = json_adapter.get_task("2")
        assert task.assignees == ["system"]

    def test_update_labels(self, json_adapter):
        json_adapter.update_task("1", labels=["bug", "critical"])
        task = json_adapter.get_task("1")
        assert task.labels == ["bug", "critical"]

    def test_update_multiple_fields(self, json_adapter):
        json_adapter.update_task("1", name="Updated", labels=["new-label"])
        task = json_adapter.get_task("1")
        assert task.name == "Updated"
        assert task.labels == ["new-label"]

    def test_update_noop_when_all_none(self, json_adapter):
        task_before = json_adapter.get_task("1")
        json_adapter.update_task("1")
        task_after = json_adapter.get_task("1")
        assert task_before.name == task_after.name
        assert task_before.labels == task_after.labels
        assert task_before.assignees == task_after.assignees

    def test_update_persists_to_file(self, json_adapter):
        json_adapter.update_task("1", name="Persisted name")
        data = json.loads(json_adapter._path.read_text())
        task = next(t for t in data["queues"]["Bugs"] if t["id"] == "1")
        assert task["name"] == "Persisted name"

    def test_update_not_found_raises_key_error(self, json_adapter):
        with pytest.raises(KeyError, match="Task not found"):
            json_adapter.update_task("999", name="Nope")


class TestListQueues:
    def test_returns_all_queues(self, json_adapter):
        queues = json_adapter.list_queues()
        names = {q.name for q in queues}
        assert names == {"Bugs", "Features", "In Progress", "Done"}

    def test_correct_task_counts(self, json_adapter):
        queues = json_adapter.list_queues()
        by_name = {q.name: q for q in queues}
        assert by_name["Bugs"].task_count == 2
        assert by_name["Features"].task_count == 1
        assert by_name["In Progress"].task_count == 0
        assert by_name["Done"].task_count == 0


class TestGetQueue:
    def test_returns_queue(self, json_adapter):
        q = json_adapter.get_queue("Bugs")
        assert q.name == "Bugs"
        assert q.task_count == 2

    def test_not_found_raises_key_error(self, json_adapter):
        with pytest.raises(KeyError, match="Queue not found"):
            json_adapter.get_queue("Nonexistent")


class TestCreateQueue:
    def test_creates_empty_queue(self, json_adapter):
        q = json_adapter.create_queue("New Queue")
        assert q.name == "New Queue"
        assert q.task_count == 0

    def test_duplicate_raises_value_error(self, json_adapter):
        with pytest.raises(ValueError, match="Queue already exists"):
            json_adapter.create_queue("Bugs")

    def test_persists_to_file(self, json_adapter):
        json_adapter.create_queue("New Queue")
        data = json.loads(json_adapter._path.read_text())
        assert "New Queue" in data["queues"]
        assert data["queues"]["New Queue"] == []


class TestUpdateQueue:
    def test_renames_queue(self, json_adapter):
        q = json_adapter.update_queue("In Progress", new_name="Working")
        assert q.name == "Working"

    def test_preserves_tasks_after_rename(self, json_adapter):
        json_adapter.update_queue("Bugs", new_name="Issues")
        q = json_adapter.get_queue("Issues")
        assert q.task_count == 2

    def test_persists_to_file(self, json_adapter):
        json_adapter.update_queue("In Progress", new_name="Working")
        data = json.loads(json_adapter._path.read_text())
        assert "Working" in data["queues"]
        assert "In Progress" not in data["queues"]

    def test_not_found_raises_key_error(self, json_adapter):
        with pytest.raises(KeyError, match="Queue not found"):
            json_adapter.update_queue("Nonexistent", new_name="New")

    def test_name_conflict_raises_value_error(self, json_adapter):
        with pytest.raises(ValueError, match="Queue already exists"):
            json_adapter.update_queue("In Progress", new_name="Bugs")

    def test_noop_when_no_new_name(self, json_adapter):
        q = json_adapter.update_queue("Bugs")
        assert q.name == "Bugs"
        assert q.task_count == 2


class TestDeleteQueue:
    def test_deletes_empty_queue(self, json_adapter):
        json_adapter.delete_queue("Done")
        with pytest.raises(KeyError):
            json_adapter.get_queue("Done")

    def test_persists_to_file(self, json_adapter):
        json_adapter.delete_queue("Done")
        data = json.loads(json_adapter._path.read_text())
        assert "Done" not in data["queues"]

    def test_not_found_raises_key_error(self, json_adapter):
        with pytest.raises(KeyError, match="Queue not found"):
            json_adapter.delete_queue("Nonexistent")

    def test_non_empty_raises_value_error(self, json_adapter):
        with pytest.raises(ValueError, match="Queue is not empty"):
            json_adapter.delete_queue("Bugs")


class TestChecklistInDescription:
    def test_checklist_appended_to_description(self, json_adapter):
        task = json_adapter.get_task("1")
        assert "## Checklist" in task.description
        assert "- [ ] Write test" in task.description
        assert "- [ ] Fix code" in task.description

    def test_no_checklist_when_empty(self, json_adapter):
        task = json_adapter.get_task("2")
        assert "## Checklist" not in task.description
