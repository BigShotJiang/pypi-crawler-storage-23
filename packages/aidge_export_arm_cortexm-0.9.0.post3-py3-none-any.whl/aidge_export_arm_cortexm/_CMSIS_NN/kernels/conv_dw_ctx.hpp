#ifndef CONV_DW_CTX_H
#define CONV_DW_CTX_H

#include "arm_nnfunctions.h"
#include <cstdlib>

class conv_dw_ctx {

  public:
    // Ctor
    conv_dw_ctx(const int in_batch,
                const int in_height,
                const int in_width,
                const int in_chan,
                const int out_batch,
                const int out_height,
                const int out_width,
                const int out_chan,
                const int kernel_height,
                const int kernel_width,
                const int stride_y,
                const int stride_x,
                const int dilation_y,
                const int dilation_x,
                const int padding_y,
                const int padding_x,
                const int activation_min,
                const int activation_max,
                const int32_t *multiplier,
                const int32_t *shift)
        : input_dims{.n = in_batch,
                     .h = in_height,
                     .w = in_width,
                     .c = in_chan},
          output_dims{
              .n = out_batch, .h = out_height, .w = out_width, .c = in_chan},
          weight_dims{
              .n = 1, .h = kernel_height, .w = kernel_width, .c = in_chan},
          bias_dims{.n = 1, .h = 1, .w = 1, .c = out_chan},
          conv_params{
              .input_offset = 0,
              .output_offset = 0,
              .ch_mult = 1,
              .stride = {.w = stride_x, .h = stride_y},
              .padding = {.w = padding_x, .h = padding_y},
              .dilation = {.w = dilation_x, .h = dilation_y},
              .activation = {.min = activation_min, .max = activation_max}},
          quant_params{.multiplier = (int32_t *)multiplier,
                       .shift = (int32_t *)shift}
    {
        buffer_size = arm_depthwise_conv_wrapper_s8_get_buffer_size(
            &conv_params, &input_dims, &weight_dims, &output_dims);
    }

    void run(int8_t *inputs,
             const int8_t *weights,
             const int32_t *biases,
             int8_t *outputs)
    {
        // Context Buffer
        int8_t *scratch_buffer = (int8_t *)malloc(buffer_size);
        if (scratch_buffer == nullptr) {
            // Handle allocation failure
            return;
        }

        const cmsis_nn_context context_buffer = {.buf = scratch_buffer,
                                                 .size = buffer_size};

        // Run the kernel
        arm_depthwise_conv_wrapper_s8(&context_buffer,
                                      &conv_params,
                                      &quant_params,
                                      &input_dims,
                                      inputs,
                                      &weight_dims,
                                      weights,
                                      &bias_dims,
                                      biases,
                                      &output_dims,
                                      outputs);

        // Clean up
        free(scratch_buffer);
    }

  private:
    // Dimensions
    const cmsis_nn_dims input_dims;
    const cmsis_nn_dims output_dims;
    const cmsis_nn_dims weight_dims;
    const cmsis_nn_dims bias_dims;

    // Layer params
    const cmsis_nn_dw_conv_params conv_params;

    // Quantization params
    const cmsis_nn_per_channel_quant_params quant_params;

    // Context Buffer
    int32_t buffer_size;
};

#endif // CONV_DW_CTX_H
