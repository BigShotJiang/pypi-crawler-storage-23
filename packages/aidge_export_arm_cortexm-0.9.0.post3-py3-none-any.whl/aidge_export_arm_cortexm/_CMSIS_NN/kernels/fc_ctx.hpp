#ifndef FC_CTX_H
#define FC_CTX_H

#include "arm_nnfunctions.h"
#include <cstdlib>

class fc_ctx {

  public:
    // Ctor
    fc_ctx(const int in_size,
           const int in_batch,
           const int in_height,
           const int in_width,
           const int in_chan,
           const int out_batch,
           const int out_chan,
           const int activation_min,
           const int activation_max,
           const int32_t coef_value,
           const int32_t shift_value)
        : input_dims{.n = in_batch,
                     .h = in_height,
                     .w = in_width,
                     .c = in_chan},
          output_dims{.n = out_batch, .h = 1, .w = 1, .c = out_chan},
          weight_dims{.n = in_size, .h = 1, .w = 1, .c = out_chan},
          bias_dims{.n = 1, .h = 1, .w = 1, .c = out_chan},
          fc_params{
              .input_offset = 0,
              .output_offset = 0,
              .activation = {.min = activation_min, .max = activation_max}},
          quant_params{.multiplier = coef_value, .shift = shift_value}
    {
        buffer_size = arm_fully_connected_s8_get_buffer_size(&input_dims);
    }

    void run(int8_t *inputs,
             const int8_t *weights,
             const int32_t *biases,
             int8_t *outputs)
    {
        // Context Buffer
        int8_t *scratch_buffer = (int8_t *)malloc(buffer_size);
        if (scratch_buffer == nullptr) {
            // Handle allocation failure
            return;
        }

        const cmsis_nn_context context_buffer = {.buf = scratch_buffer,
                                                 .size = buffer_size};

        // Run the kernel
        arm_fully_connected_s8(&context_buffer,
                               &fc_params,
                               &quant_params,
                               &input_dims,
                               inputs,
                               &weight_dims,
                               weights,
                               &bias_dims,
                               biases,
                               &output_dims,
                               outputs);

        // Clean up
        free(scratch_buffer);
    }

  private:
    // Dimensions
    const cmsis_nn_dims input_dims;
    const cmsis_nn_dims output_dims;
    const cmsis_nn_dims weight_dims;
    const cmsis_nn_dims bias_dims;

    // Layer params
    const cmsis_nn_fc_params fc_params;

    // Quantization params
    const cmsis_nn_per_tensor_quant_params quant_params;

    // Context Buffer
    int32_t buffer_size;
};

#endif // FC_CTX_H
