#ifndef MAX_POOL_CTX_H
#define MAX_POOL_CTX_H

#include "arm_nnfunctions.h"

class max_pool_ctx {

  public:
    // Ctor
    max_pool_ctx(const int in_height,
                 const int in_width,
                 const int in_chan,
                 const int out_height,
                 const int out_width,
                 const int out_chan,
                 const int kernel_height,
                 const int kernel_width,
                 const int stride_y,
                 const int stride_x,
                 const int padding_y,
                 const int padding_x,
                 const int activation_min,
                 const int activation_max)
        : input_dims{.n = 1, .h = in_height, .w = in_width, .c = in_chan},
          output_dims{.n = 1, .h = out_height, .w = out_width, .c = out_chan},
          filter_dims{.n = 1, .h = kernel_height, .w = kernel_width, .c = 1},
          pool_params{
              .stride = {.w = stride_x, .h = stride_y},
              .padding = {.w = padding_x, .h = padding_y},
              .activation = {.min = activation_min, .max = activation_max}}
    {
    }

    void run(int8_t *inputs, int8_t *outputs)
    {
        const cmsis_nn_context context_buffer = nullptr;

        // Run the kernel
        arm_max_pool_s8(&context_buffer,
                        &pool_params,
                        &input_dims,
                        inputs,
                        &filter_dims,
                        &output_dims,
                        outputs);
    }

  private:
    // Dimensions
    const cmsis_nn_dims input_dims;
    const cmsis_nn_dims output_dims;
    const cmsis_nn_dims filter_dims;

    // Layer params
    const cmsis_nn_pool_params pool_params;
};

#endif // MAX_POOL_CTX_H
