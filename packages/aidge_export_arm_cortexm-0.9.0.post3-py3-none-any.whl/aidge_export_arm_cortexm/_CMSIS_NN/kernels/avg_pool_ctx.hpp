#ifndef AVG_POOL_CTX_H
#define AVG_POOL_CTX_H

#include "arm_nnfunctions.h"
#include <cstdlib>

class avg_pool_ctx {

  public:
    // Ctor
    avg_pool_ctx(const int in_height,
                 const int in_width,
                 const int in_chan,
                 const int out_height,
                 const int out_width,
                 const int out_chan,
                 const int kernel_height,
                 const int kernel_width,
                 const int stride_y,
                 const int stride_x,
                 const int padding_y,
                 const int padding_x,
                 const int activation_min,
                 const int activation_max)
        : input_dims{.n = 1, .h = in_height, .w = in_width, .c = in_chan},
          output_dims{.n = 1, .h = out_height, .w = out_width, .c = out_chan},
          filter_dims{.n = 1, .h = kernel_height, .w = kernel_width, .c = 1},
          pool_params{
              .stride = {.w = stride_x, .h = stride_y},
              .padding = {.w = padding_x, .h = padding_y},
              .activation = {.min = activation_min, .max = activation_max}}
    {
        buffer_size = arm_avgpool_s8_get_buffer_size(out_width, in_chan);
    }

    void run(int8_t *inputs, int8_t *outputs)
    {
        // Context Buffer
        int8_t *scratch_buffer = (int8_t *)malloc(buffer_size);
        if (scratch_buffer == nullptr) {
            // Handle allocation failure
            return;
        }

        const cmsis_nn_context context_buffer = {.buf = scratch_buffer,
                                                 .size = buffer_size};

        // Run the kernel
        arm_avgpool_s8(&context_buffer,
                       &pool_params,
                       &input_dims,
                       inputs,
                       &filter_dims,
                       &output_dims,
                       outputs);

        // Clean up
        free(scratch_buffer);
    }

  private:
    // Dimensions
    const cmsis_nn_dims input_dims;
    const cmsis_nn_dims output_dims;
    const cmsis_nn_dims filter_dims;

    // Layer params
    const cmsis_nn_pool_params pool_params;

    // Context Buffer
    int32_t buffer_size;
};

#endif // AVG_POOL_CTX_H
