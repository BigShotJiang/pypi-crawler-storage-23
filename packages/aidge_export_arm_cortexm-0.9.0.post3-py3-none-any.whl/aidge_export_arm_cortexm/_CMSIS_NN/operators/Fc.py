import aidge_core
from aidge_core.export_utils import ExportNodeCpp, get_node_from_metaop
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT, ExportLibCMSISNN
from aidge_export_arm_cortexm.export_utils import convert_cmsis_scaling
from aidge_export_cpp.export_utils import set_scaling_attributes


@ExportLibCMSISNN.register_metaop(
    "QFC",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any)
        ],
    ),
)
class CMSIS_QFC(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Initialize kernel attributes
        self.attributes["activation"] = "Linear"

        ## Scaling
        set_scaling_attributes(self, node)

        ### Adapt to CMSIS-NN
        if self.attributes["coef_value"] != 1:
            aidge_core.Log.fatal(
                f"coef_value ({self.attributes['coef_value']}) should be equal to 1"
            )
            exit()

        self.attributes["coef_value"] = "0x7FFFFFFF"

        # Template for layer configuration file generation
        self.config_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "configuration"
            / "fc_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "kernel_forward"
            / "fc_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = ["arm_nnfunctions.h"]

        ## Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")

        # Path to the kernel(s) files to copy
        ## The whole CMSIS-NN library is exported
        self.kernels_to_copy = []  # Clear kernel_to_copy list
        self.add_kernel_to_copy(
            ARM_CORTEXM_ROOT / "_CMSIS_NN" / "kernels" / "fc_ctx.hpp",
            "include/kernels/cmsis",
            fwd_include=False,
        )


@ExportLibCMSISNN.register_metaop(
    "FCAct",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any)
        ],
    ),
)
class CMSIS_FCAct(CMSIS_QFC):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Browse the metaop to update kernel attributes
        if get_node_from_metaop(node, "ReLU"):
            self.attributes["activation"] = "Rectifier"
        else:
            aidge_core.Log.error(f"{node.type()} activation is not yet supported.")
