import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT, ExportLibCMSISNN
from aidge_export_cpp import get_node_from_metaop, set_scaling_attributes


@ExportLibCMSISNN.register_metaop(
    "QAdd",
    aidge_core.ImplSpec(
        [  # Input specification
            aidge_core.IOSpec(aidge_core.dtype.int8),
            aidge_core.IOSpec(aidge_core.dtype.int8),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.int8)],  # Output specification
    ),
    aidge_core.ProdConso.in_place_model,
)
class CMSIS_QAdd(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Initialize kernel attributes
        self.attributes["activation"] = "Linear"

        ## Scaling
        self.attributes["rescaling"] = "NoScaling"
        self.attributes["shift_value"] = 0
        self.attributes["coef_value"] = 1

        # Browse the metaop to update kernel attributes (shift_value and coef_value)
        set_scaling_attributes(self, node)

        # Template for layer configuration file generation
        self.config_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "configuration"
            / "add_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "kernel_forward"
            / "add_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = ["arm_nnfunctions.h"]

        # Path to the kernel(s) files to copy
        ## The whole CMSIS-NN library is exported
        self.kernels_to_copy = []

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")


@ExportLibCMSISNN.register_metaop(
    "QAddAct",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
    aidge_core.ProdConso.in_place_model,
)
class CMSIS_AddAct(CMSIS_QAdd):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Browse the metaop to update kernel attributes
        if get_node_from_metaop(node, "ReLU"):
            self.attributes["activation"] = "Rectifier"
        else:
            aidge_core.Log.error(f"{node.type()} activation is not yet supported.")
