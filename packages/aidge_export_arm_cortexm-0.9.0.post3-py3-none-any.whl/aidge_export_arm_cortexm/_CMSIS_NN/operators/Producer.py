import aidge_core
from aidge_export_arm_cortexm import ExportLibCMSISNN
from aidge_export_cpp.operators.Producer import ProducerCPP


@ExportLibCMSISNN.register(
    "Producer", aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any))
)
class CMSIS_Producer(ProducerCPP):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
