import aidge_core
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT, ExportLibCMSISNN
from aidge_export_cpp.operators.ConvDw import *


@ExportLibCMSISNN.register_metaop(
    "QConvDw",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc),
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.chwn),
            aidge_core.IOSpec(aidge_core.dtype.int32, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc)
        ],
    ),
)
class CMSIS_QConvDw(QConvDw):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Scaling
        if self.attributes["coef_value"] != 1:
            aidge_core.Log.fatal(
                f"coef_value ({self.attributes['coef_value']}) should be equal to 1"
            )
            exit()

        self.attributes["coef_value"] = "0x7FFFFFFF"

        # Template for layer configuration file generation
        self.config_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "configuration"
            / "conv_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "kernel_forward"
            / "conv_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list.append("arm_nnfunctions.h")

        # Path to the kernel(s) files to copy
        ## The whole CMSIS-NN library is exported
        self.kernels_to_copy = []  # Clear kernel_to_copy list
        self.add_kernel_to_copy(
            ARM_CORTEXM_ROOT / "_CMSIS_NN" / "kernels" / "conv_dw_ctx.hpp",
            "include/kernels/cmsis",
            fwd_include=False,
        )


@ExportLibCMSISNN.register_metaop(
    "PadConvDw",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc),
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.chwn),
            aidge_core.IOSpec(aidge_core.dtype.int32, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc)
        ],
    ),
)
class CMSIS_PadConvDw(CMSIS_QConvDw, PadConvDw):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "ConvDwAct",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc),
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.chwn),
            aidge_core.IOSpec(aidge_core.dtype.int32, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc)
        ],
    ),
)
class CMSIS_ConvDwAct(CMSIS_QConvDw, ConvDwAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "PadConvDwAct",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc),
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.chwn),
            aidge_core.IOSpec(aidge_core.dtype.int32, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.int8, aidge_core.dformat.nhwc)
        ],
    ),
)
class CMSIS_PadConvAct(CMSIS_PadConvDw, CMSIS_ConvDwAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
