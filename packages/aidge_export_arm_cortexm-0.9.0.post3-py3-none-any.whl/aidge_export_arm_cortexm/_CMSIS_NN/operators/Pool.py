import aidge_core
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT, ExportLibCMSISNN
from aidge_export_cpp.operators.Pool import *


class CMSIS_Pool(Pool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Template for layer configuration file generation
        self.config_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "configuration"
            / "pool_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            ARM_CORTEXM_ROOT
            / "_CMSIS_NN"
            / "templates"
            / "kernel_forward"
            / "pool_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = ["arm_nnfunctions.h"]

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")

        # Path to the kernel(s) files to copy
        ## The whole CMSIS-NN library is exported
        self.kernels_to_copy = []  # Clear kernel_to_copy list
        pool_filename = (
            "avg_pool_ctx.hpp"
            if self.attributes["pool_type"] == "Average"
            else "max_pool_ctx.hpp"
        )
        self.add_kernel_to_copy(
            ARM_CORTEXM_ROOT / "_CMSIS_NN" / "kernels" / pool_filename,
            "include/kernels/cmsis",
            fwd_include=False,
        )


@ExportLibCMSISNN.register(
    "MaxPooling2D",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_MaxPool(CMSIS_Pool, MaxPool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    ["PaddedMaxPooling2D", "PadMaxPool"],
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_PadMaxPool(CMSIS_MaxPool, PadPool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "MaxPoolAct",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_MaxPoolAct(CMSIS_MaxPool, PoolAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "PadMaxPoolAct",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_PadMaxPoolAct(CMSIS_PadMaxPool, CMSIS_MaxPoolAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register(
    "AvgPooling2D",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_AvgPool(CMSIS_Pool, AvgPool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    ["PaddedAvgPooling2D", "PadAvgPool"],
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_PadAvgPool(CMSIS_AvgPool, PadPool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "AvgPoolAct",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_AvgPoolAct(CMSIS_AvgPool, PoolAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "PadAvgPoolAct",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_PadAvgPoolAct(CMSIS_PadAvgPool, CMSIS_AvgPoolAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register(
    "GlobalAveragePooling",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_GlobalAvgPool(CMSIS_Pool, GlobalAvgPool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        self.attributes["pool_type"] = "Average"
        self.attributes["kernel_dims"] = [
            self.attributes["in_width"][0],
            self.attributes["in_height"][0],
        ]


@ExportLibCMSISNN.register_metaop(
    "PadGlobalAvgPool",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_PadGlobalAvgPool(CMSIS_GlobalAvgPool, PadPool):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "GlobalAvgPoolAct",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_GlobalAvgPoolAct(CMSIS_GlobalAvgPool, PoolAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCMSISNN.register_metaop(
    "PadGlobalAvgPoolAct",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
    ),
)
class CMSIS_PadGlobalAvgPoolAct(CMSIS_PadGlobalAvgPool, CMSIS_GlobalAvgPoolAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
