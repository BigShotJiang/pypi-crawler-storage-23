"""Aidge Export for ARM CortexM

Use this module to generate CPP exports for ARM CortexM boards.
This module has to be used with the Aidge suite
"""

from pathlib import Path

FILE = Path(__file__).resolve()
ARM_CORTEXM_ROOT = FILE.parents[0]

from .export_registry import *
from .export_utils import *
from .export import *

from ._Aidge_Arm.operators import *
from ._CMSIS_NN.operators import *
