import os
import shutil
from pathlib import Path

import aidge_core
import aidge_export_cpp
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT

BOARD_PATH: str = ARM_CORTEXM_ROOT / "boards"

BOARDS_MAP: dict[str, Path] = {
    "stm32h7": BOARD_PATH / "stm32" / "H7",
    "stm32f7": BOARD_PATH / "stm32" / "F7",
    "stm32l4": BOARD_PATH / "stm32" / "L4",
}


def supported_boards() -> list[str]:
    return BOARDS_MAP.keys()


def gen_board_files(path: str, board: str) -> None:
    if board not in supported_boards():
        joint_board_str = "\n\t-".join(supported_boards())
        raise ValueError(
            f"Board {board} is not supported, supported board are:\n\t-{joint_board_str}"
        )

    if isinstance(path, str):
        path = Path(path)
    # Create dnn directory if not exist
    dnn_folder = path / "dnn"
    os.makedirs(str(dnn_folder), exist_ok=True)

    # Determine which board the user wants
    # to select correct config
    # Copy all static files in the export
    shutil.copytree(BOARDS_MAP[board], str(path), dirs_exist_ok=True)


def convert_cmsis_scaling(export_node: aidge_core.export_utils.ExportNode):
    """
    TODO
    In Aidge, quantized rescaling is expressed as:
        output = (input * coef_value) >> shift_value

    where `coef_value` is a signed 32-bit integer (`int32_t`).

    In CMSIS-NN, rescaling is represented using a fixed-point multiplier in Q31
    format and a power-of-two shift. The multiplier encodes a real-valued scale
    in the range [-1, 1[ using a signed 32-bit integer.

    This function converts the Aidge scaling parameters (`coef_value`,
    `shift_value`) into their equivalent CMSIS-NN representation
    (`multiplier`, `shift`), such that:

        coef_value * 2^(-shift_value)
        ≈ (multiplier / 2^31) * 2^(shift)

    while preserving the numerical behavior of the original rescaling.
    """

    coef_value = export_node.attributes["coef_value"]
    shift_value = export_node.attributes["shift_value"]

    # Fixed point not currently supported
    if coef_value != 1:
        aidge_core.Log.fatal(
            f"coef_value != 1 ({coef_value}) in ExportNode {export_node.name} not currently supported."
        )
        exit()

    # Set the new values
    export_node.attributes["coef_value"] = "0x7FFFFFFF"  # <=> 1
    export_node.attributes["shift_value"] = shift_value
