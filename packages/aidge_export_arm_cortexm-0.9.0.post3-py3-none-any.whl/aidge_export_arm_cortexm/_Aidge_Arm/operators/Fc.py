import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT
from aidge_export_arm_cortexm.export_registry import ExportLibAidgeARM
from aidge_export_cpp.operators.Fc import *


@ExportLibAidgeARM.register(
    "FC",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any)
        ],
    ),
)
class ArmFC(FC):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Replace the CPP macs.hpp file with the ARM optimized one
        ## Remove the macs.hpp file related to the CPP Export
        for i, kernel in enumerate(self.kernels_to_copy):
            if "macs.hpp" in str(kernel["src_path"]):
                self.kernels_to_copy.pop(i)
                break

        ## Add the macs.hpp file related to the Arm Export instead
        self.add_kernel_to_copy(
            ARM_CORTEXM_ROOT / "_Aidge_Arm" / "static" / "macs.hpp",
            "include/utils/cpp",
            fwd_include=False,
        )


@ExportLibAidgeARM.register_metaop(
    "QFC",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any)
        ],
    ),
)
class ArmQFC(QFC, ArmFC):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibAidgeARM.register_metaop(
    "FCAct",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any)
        ],
    ),
)
class ArmFCAct(FCAct, ArmFC):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
