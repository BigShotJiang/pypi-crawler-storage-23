import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT
from aidge_export_arm_cortexm.export_registry import ExportLibAidgeARM
from aidge_export_cpp.operators.Transpose import *


@ExportLibAidgeARM.register(
    "Transpose", aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any))
)
class ArmTranspose(TransposeCPP):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
