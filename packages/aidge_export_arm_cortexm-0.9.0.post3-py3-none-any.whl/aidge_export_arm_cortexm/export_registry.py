from aidge_core.export_utils import ExportLib
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT
from aidge_export_cpp import CPP_ROOT


class ExportLibAidgeARM(ExportLib):
    _name = "aidge_arm"
    mem_section = ".nn_buffer_d1"
    static_files = {
        str(CPP_ROOT / "static" / "typedefs.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "utils.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "rescaling_utils.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "activation_utils.hpp"): "dnn/include/utils/cpp",
    }


class ExportLibCMSISNN(ExportLib):
    _name = "export_cmsisnn"
    static_folders = {
        str(
            ARM_CORTEXM_ROOT / "_CMSIS_NN" / "CMSIS-NN" / "Include"
        ): "Middlewares/CMSIS-NN/Include",
        str(
            ARM_CORTEXM_ROOT / "_CMSIS_NN" / "CMSIS-NN" / "Source"
        ): "Middlewares/CMSIS-NN/Source",
    }

    static_files = {
        str(CPP_ROOT / "static" / "typedefs.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "utils.hpp"): "dnn/include/utils/cpp",
    }
