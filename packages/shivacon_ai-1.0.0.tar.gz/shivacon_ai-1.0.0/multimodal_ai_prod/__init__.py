"""
Shivacon AI - Production Package

A production-grade multi-modal AI framework supporting:
- Text, Image, Audio, Video, and Music modalities
- Cross-modal attention and fusion
- Training with mixed precision
- Inference pipeline
- REST API server
- Agentic capabilities with ReAct reasoning

Usage:
    python -m shivacon_ai.train --help
    python -m shivacon_ai.inference --help

Installation:
    pip install shivacon-ai
"""

__version__ = "1.0.0"
__author__ = "Shiva @ VisionQuantTech"
