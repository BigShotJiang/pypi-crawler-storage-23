"""v2.2.3 端到端测试

测试用例覆盖：
- F-CONTEXT-001: .a 文件机制
- F-TASK-001: 任务状态同步
- F-UI-001: 状态增强显示

版本: v2.2.3
创建日期: 2026-02-08
状态: ✅ CLI 命令已实现

"""

import pytest
import tempfile
import subprocess
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


def run_oc_collab_command(args, cwd=None):
    """运行 oc-collab 命令（带 PYTHONPATH）"""
    env = os.environ.copy()
    env['PYTHONPATH'] = str(Path(__file__).parent.parent)
    result = subprocess.run(
        [sys.executable, "-m", "src.cli.main"] + args,
        cwd=cwd or Path(__file__).parent.parent,
        capture_output=True,
        text=True,
        env=env
    )
    return result


class TestE2EContextManagement:
    """F-CONTEXT-001: .a 文件机制端到端测试"""

    @pytest.fixture
    def temp_project(self):
        """创建临时项目目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_init_creates_config(self, temp_project):
        """init 命令创建配置文件 - 需要修改init命令支持 --agent 参数"""
        result = run_oc_collab_command(
            ["init", "TestProject", "--type", "python"],
            cwd=temp_project
        )
        assert result.returncode == 0

    def test_dot_a_command_shows_info(self, temp_project):
        """.a 命令显示项目信息 - 未实现"""
        config_file = temp_project / ".oc-collab.yaml"
        config_file.write_text(
            "project: TestProject\npath: /test\nagent: 1\nversion: 2.2.3\n"
        )
        result = run_oc_collab_command([".a"], cwd=temp_project)
        assert result.returncode == 0
        assert "TestProject" in result.stdout


class TestE2ETodoSync:
    """F-TASK-001: 任务状态同步端到端测试"""

    @pytest.fixture
    def temp_project(self):
        """创建临时项目目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_todowrite_creates_todo(self, temp_project):
        """todowrite 创建待办 - 未实现"""
        result = run_oc_collab_command(
            ["todowrite", "--content", "完成设计", "--priority", "high"],
            cwd=temp_project
        )
        assert result.returncode == 0

    def test_todoedit_updates_status(self, temp_project):
        """todoedit 更新待办 - 需要先创建待办"""
        run_oc_collab_command(
            ["todowrite", "--content", "待更新任务"],
            cwd=temp_project
        )
        result = run_oc_collab_command(
            ["todoedit", "TODO-001", "--status", "completed"],
            cwd=temp_project
        )
        assert result.returncode == 0


class TestE2EStatusDisplay:
    """F-UI-001: 状态增强显示端到端测试"""

    @pytest.fixture
    def temp_project(self):
        """创建临时项目目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_status_shows_summary(self, temp_project):
        """status 显示待办摘要 - 需要 project_state.yaml"""
        config_file = temp_project / ".oc-collab.yaml"
        config_file.write_text(
            "project: TestProject\npath: /test\nagent: 1\nversion: 2.2.3\n"
        )
        state_file = temp_project / "state" / "project_state.yaml"
        state_file.parent.mkdir(parents=True)
        state_file.write_text(
            "current_agent: agent1\nphase: development\nproject:\n  name: TestProject\n"
        )
        result = run_oc_collab_command(["status"], cwd=temp_project)
        assert result.returncode == 0


class TestE2EIntegration:
    """集成端到端测试"""

    @pytest.fixture
    def temp_project(self):
        """创建临时项目目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_full_workflow(self, temp_project):
        """完整工作流测试 - 需要所有CLI命令支持"""
        state_file = temp_project / "state" / "project_state.yaml"
        state_file.parent.mkdir(parents=True)
        state_file.write_text(
            "current_agent: agent1\nphase: development\nproject:\n  name: FullTest\n"
        )

        result1 = run_oc_collab_command([".a"], cwd=temp_project)
        assert result1.returncode == 0

        result2 = run_oc_collab_command(
            ["todowrite", "--content", "完整测试任务", "--priority", "high"],
            cwd=temp_project
        )
        assert result2.returncode == 0

        result3 = run_oc_collab_command(["status"], cwd=temp_project)
        assert result3.returncode == 0
