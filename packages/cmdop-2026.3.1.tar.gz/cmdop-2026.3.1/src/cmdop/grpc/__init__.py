"""
CMDOP gRPC layer.

Contains proto definitions and generated gRPC code.
"""

from cmdop.grpc.generated import TerminalStreamingServiceStub

__all__ = ["TerminalStreamingServiceStub"]
