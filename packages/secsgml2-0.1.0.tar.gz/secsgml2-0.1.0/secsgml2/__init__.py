from ._core import parse_sgml_content_into_memory

__all__ = ["parse_sgml_content_into_memory"]
