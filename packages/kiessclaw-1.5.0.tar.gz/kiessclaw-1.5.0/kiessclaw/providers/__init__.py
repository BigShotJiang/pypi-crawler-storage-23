"""Provider plugin system exports."""

from kiessclaw.providers.base import BaseProvider
from kiessclaw.providers.hubspot import HubSpotProvider
from kiessclaw.providers.models import ProviderResult
from kiessclaw.providers.registry import (
    active_provider,
    get_provider,
    list_providers,
    register_builtin_providers,
    register_provider,
)

register_builtin_providers()

__all__ = [
    "BaseProvider",
    "ProviderResult",
    "HubSpotProvider",
    "register_provider",
    "get_provider",
    "list_providers",
    "active_provider",
    "register_builtin_providers",
]
