"""Abstract provider interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from kiessclaw.providers.models import ProviderResult


class BaseProvider(ABC):
    """Base class for pluggable enrichment and contact providers."""

    name: str = "base"
    kind: str = "enrichment"

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize provider with runtime config."""
        self.config = config or {}

    @abstractmethod
    def find_email(self, first: str, last: str, domain: str) -> ProviderResult:
        """Find an email address for a person at a domain."""

    @abstractmethod
    def enrich_contact(self, email: str) -> ProviderResult:
        """Return enrichment data for an email address."""

    @abstractmethod
    def health_check(self) -> bool:
        """Return provider health status."""
