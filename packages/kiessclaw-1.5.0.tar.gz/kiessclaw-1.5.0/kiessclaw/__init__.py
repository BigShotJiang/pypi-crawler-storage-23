"""
KIESSCLAW - Autonomous AI Sales/SDR Agent System
Built on OpenClaw architecture.
"""

__version__ = "1.5.0"
__author__ = "Erwin Kiess-Alfonso"
