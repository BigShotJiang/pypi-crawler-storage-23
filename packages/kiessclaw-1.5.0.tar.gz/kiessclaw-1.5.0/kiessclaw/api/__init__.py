"""FastAPI service layer for KIESSCLAW."""

