"""KSCO SEO scout agent."""

from __future__ import annotations

from typing import Any

from kiessclaw.core.agent import BaseAgent
from kiessclaw.core.memory import MemoryEngine


class KiessScoutAgent(BaseAgent):
    """Generate backlink prospecting and competitor link-gap outputs."""

    codename = "KSCO"
    name = "KiessScout"
    description = "Backlink prospecting and competitor link-gap scouting"

    def __init__(self, config: dict[str, Any], memory: MemoryEngine):
        """Initialize scout agent."""
        super().__init__(config, memory)

    def run(self, task: str, **kwargs: Any) -> str:
        """Execute backlink scouting tasks."""
        self.update_status("running", task)
        try:
            if task == "prospect" or "backlink" in task.lower():
                domain = kwargs.get("domain", "example.com")
                return self._prospects(domain)
            return self.think(task).content
        finally:
            self.update_status("idle")

    def _prospects(self, domain: str) -> str:
        """Return deterministic backlink prospect targets."""
        return (
            "**KSCO Backlink Prospects**\n\n"
            f"- Target domain: {domain}\n"
            "- Prospect types: niche directories, partner pages, integration pages, guest posts\n"
            "- Priority order: high-authority relevant domains first"
        )

