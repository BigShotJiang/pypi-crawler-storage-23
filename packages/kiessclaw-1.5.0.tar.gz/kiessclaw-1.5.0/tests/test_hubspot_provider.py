"""Tests for HubSpot CRM provider fallback behavior."""

from __future__ import annotations

import os
import unittest

from kiessclaw.models.contact import Contact
from kiessclaw.providers.hubspot import HubSpotProvider
from kiessclaw.providers.models import ProviderResult


class HubSpotProviderTest(unittest.TestCase):
    """Validate HubSpot adapter behavior without network dependencies."""

    def setUp(self) -> None:
        """Clear HubSpot credentials to force deterministic mock fallback."""
        os.environ.pop("HUBSPOT_API_KEY", None)

    def test_hubspot_without_key_falls_back_to_mock(self) -> None:
        """Provider should silently fallback when API key is unavailable."""
        provider = HubSpotProvider({})
        result = provider.enrich_contact("alex@acme.com")
        self.assertTrue(result.ok)
        self.assertEqual("mock", result.provider)

    def test_create_contact_returns_provider_result_schema(self) -> None:
        """create_contact should return normalized ProviderResult payload."""
        provider = HubSpotProvider({})
        contact = Contact(email="sam@acme.com", first_name="Sam", last_name="Lee", title="CTO")
        result = provider.create_contact(contact)
        self.assertIsInstance(result, ProviderResult)
        self.assertIsInstance(result.ok, bool)
        self.assertIsInstance(result.data, dict)

    def test_find_contact_returns_provider_result_schema(self) -> None:
        """find_contact should always return ProviderResult even in fallback mode."""
        provider = HubSpotProvider({})
        result = provider.find_contact("sam@acme.com")
        self.assertIsInstance(result, ProviderResult)
        self.assertIsInstance(result.ok, bool)
        self.assertIsInstance(result.data, dict)

    def test_health_check_on_mock_fallback_is_true(self) -> None:
        """Fallback health status should be healthy."""
        provider = HubSpotProvider({})
        self.assertTrue(provider.health_check())


if __name__ == "__main__":
    unittest.main()
