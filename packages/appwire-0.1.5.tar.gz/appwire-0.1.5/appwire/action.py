class Action:
    def __init__(
        self,
        name: str,
        method: str,
        endpoint: str,
        description: str = "",
        handler=None,
        params: list = None,
        response_mapping: dict = None,
    ):
        self.name = name
        self.method = method.upper()
        self.endpoint = endpoint
        self.description = description
        self.handler = handler
        self.params = params or []
        self.response_mapping = response_mapping

    def execute(self, **kwargs):
        if self.handler:
            return self.handler(**kwargs)
        return {}

    def to_dict(self) -> dict:
        d = {
            "name": self.name,
            "method": self.method,
            "endpoint": self.endpoint,
            "description": self.description,
            "params": self.params,
        }
        if self.response_mapping:
            d["response_mapping"] = self.response_mapping
        return d

    def __repr__(self):
        return f"Action(name='{self.name}', method='{self.method}', endpoint='{self.endpoint}')"
