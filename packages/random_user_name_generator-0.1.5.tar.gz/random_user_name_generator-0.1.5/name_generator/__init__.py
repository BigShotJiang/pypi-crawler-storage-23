from .core import get_random_name

__version__ = "0.1.0"
__all__ = ["get_random_name"]
