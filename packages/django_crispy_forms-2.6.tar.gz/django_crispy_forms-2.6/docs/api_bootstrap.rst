.. _`bootstrap api`:

===================================
API Bootstrap
===================================


.. automodule:: crispy_forms.bootstrap
   :members:
