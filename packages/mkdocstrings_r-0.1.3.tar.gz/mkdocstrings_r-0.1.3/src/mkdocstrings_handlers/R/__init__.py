"""R handler for mkdocstrings."""

from mkdocstrings_handlers.R._internal.handler import RHandler, get_handler

__all__ = [
    "RHandler",
    "get_handler",
]
