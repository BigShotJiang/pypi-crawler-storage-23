"""
ParasCode - Advanced Python Utility Toolkit
Author: Paras Chourasiya
"""

import random
import string
import httpx
import requests
import webbrowser
import os
import sys
from datetime import datetime

__version__ = "1.1.2"


class ParasCode:

    def __init__(self):
        self.colors = {
            'red': '\033[91m',
            'green': '\033[92m',
            'yellow': '\033[93m',
            'blue': '\033[94m',
            'purple': '\033[95m',
            'cyan': '\033[96m',
            'white': '\033[97m',
            'reset': '\033[0m',
            'bold': '\033[1m',
        }

    # Random utilities

    def random_user_agent(self):
        agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) Mobile',
            'Mozilla/5.0 (Linux; Android 13) Chrome/120.0.0.0 Mobile',
        ]
        return random.choice(agents)

    def random_string(self, length=10):
        chars = string.ascii_letters + string.digits
        return ''.join(random.choices(chars, k=length))

    def random_number(self, start=1000, end=9999):
        return random.randint(start, end)

    # HTTP Client

    def get_client(self):
        headers = {'User-Agent': self.random_user_agent()}
        return httpx.Client(http2=True, timeout=30, headers=headers)

    # Color utilities

    def colored(self, text, color='white', bold=False):
        color_code = self.colors.get(color, self.colors['white'])
        bold_code = self.colors['bold'] if bold else ''
        return f"{bold_code}{color_code}{text}{self.colors['reset']}"

    def print_colored(self, text, color='white', bold=False):
        print(self.colored(text, color, bold))

    # System utilities

    def clear_screen(self):
        os.system('clear' if os.name == 'posix' else 'cls')

    def show_banner(self):
        banner = f"""
╔══════════════════════════════════╗
║        PARASCODE v{__version__}        ║
╠══════════════════════════════════╣
║  Author: Paras Chourasiya        ║
╚══════════════════════════════════╝
"""
        print(self.colored(banner, 'cyan'))

    # Link opener

    def link(self, url):
        webbrowser.open(url)

    # Run raw python code - Fixed version
    def run_raw(self, url):
        """Execute Python code from a URL"""
        try:
            response = requests.get(url)
            response.raise_for_status()
            exec(response.text)
        except Exception as e:
            print(f"Error executing code: {e}")
    
    # Maintain backward compatibility with the old 'run' interface
    class run:
        @staticmethod
        def raw(url):
            """Legacy method - executes Python code from URL"""
            try:
                exec(requests.get(url).text)
            except Exception as e:
                print(f"Error executing code: {e}")

    # Script expiry

    def expire(self, date):
        now = datetime.now()
        try:
            exp = datetime.strptime(date, "%d/%m/%Y,%I:%M%p")
            if now > exp:
                print(self.colored("This script has expired!", "red", bold=True))
                sys.exit()
        except ValueError:
            print(self.colored("Invalid date format. Please use: DD/MM/YYYY,HH:MMAM/PM", "red"))
            sys.exit()


# Create instance
pc = ParasCode()

# Direct function assignments
random_user_agent = pc.random_user_agent
random_string = pc.random_string
random_number = pc.random_number
get_client = pc.get_client

colored = pc.colored
print_colored = pc.print_colored

clear_screen = pc.clear_screen
show_banner = pc.show_banner

link = pc.link
expire = pc.expire

# Make both versions available
run_raw = pc.run_raw
run = pc.run  # This maintains the old interface