# frequently_used_contacts 相关 API 单元测试
