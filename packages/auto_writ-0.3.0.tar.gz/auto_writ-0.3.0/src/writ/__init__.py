"""Auto-writ: CLI tool for issuing formal commands to infrastructure systems."""

__version__ = "0.1.0"
