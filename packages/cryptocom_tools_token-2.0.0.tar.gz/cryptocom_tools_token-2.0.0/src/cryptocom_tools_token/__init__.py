"""
Crypto.com Tools Token - Token tools for Crypto.com Developer Platform.

This package provides token-related tools for the CDP:

Read tools (no signer required):
- GetNativeBalanceTool: Query native CRO balance
- GetERC20BalanceTool: Query ERC20 token balance

Write tools (signer required):
- TransferNativeTool: Transfer native CRO tokens
- TransferERC20Tool: Transfer ERC20 tokens
- SwapTokenTool: Swap tokens via DEX aggregator
- WrapTokenTool: Wrap CRO to WCRO
- UnwrapTokenTool: Unwrap WCRO to CRO

Example:
    from cryptocom_tools_token import (
        GetNativeBalanceTool,
        TransferNativeTool,
    )
    from cryptocom_tools_wallet import PrivateKeySigner

    # Read tool - no signer needed
    balance_tool = GetNativeBalanceTool()
    result = balance_tool.invoke({"address": "0x..."})

    # Write tool - signer required
    signer = PrivateKeySigner.from_env()
    transfer_tool = TransferNativeTool(signer=signer)
    result = transfer_tool.invoke({"to": "0x...", "amount": 1.5})
"""

from __future__ import annotations

__version__ = "0.1.0"

from .read import (
    BalanceResult,
    GetERC20BalanceInput,
    GetERC20BalanceTool,
    GetNativeBalanceInput,
    GetNativeBalanceTool,
)
from .write import (
    WCRO_ADDRESS,
    SwapResult,
    SwapTokenInput,
    SwapTokenTool,
    TransferERC20Input,
    TransferERC20Tool,
    TransferNativeInput,
    TransferNativeTool,
    TransferResult,
    UnwrapTokenInput,
    UnwrapTokenTool,
    WrapResult,
    WrapTokenInput,
    WrapTokenTool,
)

__all__ = [
    "__version__",
    # Read tools
    "BalanceResult",
    "GetERC20BalanceInput",
    "GetERC20BalanceTool",
    "GetNativeBalanceInput",
    "GetNativeBalanceTool",
    # Write tools
    "SwapResult",
    "SwapTokenInput",
    "SwapTokenTool",
    "TransferERC20Input",
    "TransferERC20Tool",
    "TransferNativeInput",
    "TransferNativeTool",
    "TransferResult",
    "UnwrapTokenInput",
    "UnwrapTokenTool",
    "WCRO_ADDRESS",
    "WrapResult",
    "WrapTokenInput",
    "WrapTokenTool",
]
