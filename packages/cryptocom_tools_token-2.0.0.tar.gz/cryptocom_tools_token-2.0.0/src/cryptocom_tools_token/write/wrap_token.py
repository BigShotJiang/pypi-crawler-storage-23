"""WrapTokenTool - Wrap native CRO tokens to WCRO."""

from __future__ import annotations

from cryptocom_tools_core import Signer
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from ._constants import WCRO_ADDRESS
from ._encoding import NATIVE_TOKEN_DECIMALS, encode_selector, to_base_units
from ._results import WrapResult


class WrapTokenInput(BaseModel):
    """Input schema for WrapTokenTool."""

    amount: float = Field(description="Amount of native CRO tokens to wrap")


class WrapTokenTool(BaseTool):
    """
    Wrap native CRO tokens to WCRO (Wrapped CRO).

    Requires a Signer instance that implements the Signer protocol.

    Example:
        from cryptocom_tools_wallet import PrivateKeySigner

        signer = PrivateKeySigner.from_env()
        tool = WrapTokenTool(signer=signer)
        result = tool.invoke({"amount": 100})
    """

    name: str = "wrap_native_token"
    description: str = "Wrap native CRO tokens to WCRO (Wrapped CRO)"
    args_schema: type[BaseModel] = WrapTokenInput  # type: ignore[assignment]

    # Required signer (excluded from LLM schema)
    signer: Signer = Field(exclude=True)

    def _run(self, amount: float) -> str:  # type: ignore[override]
        """Execute native token wrapping."""
        if amount <= 0:
            return "Error: amount must be positive"

        try:
            # WCRO deposit function: deposit()
            function_selector = encode_selector("deposit()")

            # Build transaction
            tx = {
                "to": WCRO_ADDRESS,
                "value": to_base_units(amount, NATIVE_TOKEN_DECIMALS),
                "data": f"0x{function_selector}",
            }

            # Send via signer
            tx_hash = self.signer.send_transaction(tx)

            result = WrapResult(
                tx_hash=tx_hash,
                amount=amount,
                operation="wrap",
            )
            return str(result)

        except Exception as e:
            return f"Error: Wrap failed: {e}"


__all__ = ["WrapTokenInput", "WrapTokenTool"]
