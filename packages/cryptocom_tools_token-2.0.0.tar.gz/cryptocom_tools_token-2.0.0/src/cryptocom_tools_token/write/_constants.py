"""Constants for token write tools."""

# WCRO contract address on Cronos mainnet
WCRO_ADDRESS = "0x5C7F8A570d578ED84E63fdFA7b1eE72dEae1AE23"

__all__ = ["WCRO_ADDRESS"]
