"""TransferNativeTool - Transfer native tokens (CRO) to an address."""

from __future__ import annotations

from cryptocom_tools_core import Signer
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from ._encoding import NATIVE_TOKEN_DECIMALS, to_base_units
from ._results import TransferResult


class TransferNativeInput(BaseModel):
    """Input schema for TransferNativeTool."""

    to: str = Field(description="Recipient blockchain address")
    amount: float = Field(description="Amount of native tokens to transfer")


class TransferNativeTool(BaseTool):
    """
    Transfer native tokens (CRO) to an address.

    Requires a Signer instance that implements the Signer protocol.

    Example:
        from cryptocom_tools_wallet import PrivateKeySigner

        signer = PrivateKeySigner.from_env()
        tool = TransferNativeTool(signer=signer)
        result = tool.invoke({"to": "0x...", "amount": 1.5})
    """

    name: str = "transfer_native_token"
    description: str = "Transfer native tokens (CRO) to an address"
    args_schema: type[BaseModel] = TransferNativeInput  # type: ignore[assignment]

    # Required signer (excluded from LLM schema)
    signer: Signer = Field(exclude=True)

    def _run(self, to: str, amount: float) -> str:  # type: ignore[override]
        """Execute native token transfer."""
        if amount <= 0:
            return "Error: amount must be positive"

        try:
            # Build transaction
            tx = {
                "to": to,
                "value": to_base_units(amount, NATIVE_TOKEN_DECIMALS),
                "data": "0x",
            }

            # Send via signer
            tx_hash = self.signer.send_transaction(tx)

            result = TransferResult(
                tx_hash=tx_hash,
                from_address=self.signer.address,
                to_address=to,
                amount=amount,
                token_type="CRO",
            )
            return str(result)

        except Exception as e:
            return f"Error: Transfer failed: {e}"


__all__ = ["TransferNativeInput", "TransferNativeTool"]
