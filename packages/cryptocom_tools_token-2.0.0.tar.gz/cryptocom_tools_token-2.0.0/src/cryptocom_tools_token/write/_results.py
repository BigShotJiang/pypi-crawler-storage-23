"""Shared result classes for token write tools."""

from __future__ import annotations

from dataclasses import dataclass

from cryptocom_tools_core import ToolResult


@dataclass
class TransferResult(ToolResult):
    """Result from a transfer operation."""

    tx_hash: str
    from_address: str
    to_address: str
    amount: float
    token_type: str

    def _format_result(self) -> str:
        return (
            f"Transfer successful!\n"
            f"From: {self.from_address}\n"
            f"To: {self.to_address}\n"
            f"Amount: {self.amount} {self.token_type}\n"
            f"TX Hash: {self.tx_hash}"
        )


@dataclass
class SwapResult(ToolResult):
    """Result from a swap operation."""

    tx_hash: str
    amount_in: float
    amount_out: float
    token_in: str
    token_out: str

    def _format_result(self) -> str:
        return (
            f"Swap completed!\n"
            f"From: {self.amount_in} {self.token_in}\n"
            f"To: {self.amount_out} {self.token_out}\n"
            f"TX Hash: {self.tx_hash}"
        )


@dataclass
class WrapResult(ToolResult):
    """Result from a wrap/unwrap operation."""

    tx_hash: str
    amount: float
    operation: str  # "wrap" or "unwrap"

    def _format_result(self) -> str:
        return (
            f"{self.operation.capitalize()} successful!\n"
            f"Amount: {self.amount}\n"
            f"TX Hash: {self.tx_hash}"
        )


__all__ = ["TransferResult", "SwapResult", "WrapResult"]
