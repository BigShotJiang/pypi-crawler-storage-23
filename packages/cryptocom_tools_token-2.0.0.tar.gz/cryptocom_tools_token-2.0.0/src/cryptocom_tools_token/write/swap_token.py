"""SwapTokenTool - Swap one token for another using DEX aggregator."""

from __future__ import annotations

from cryptocom_tools_core import Signer
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from ._encoding import NATIVE_TOKEN_DECIMALS, encode_selector, to_base_units
from ._results import SwapResult


class SwapTokenInput(BaseModel):
    """Input schema for SwapTokenTool."""

    token_in: str = Field(description="Source token address or 'native' for CRO")
    token_out: str = Field(description="Destination token address or 'native' for CRO")
    amount: float = Field(description="Amount of source tokens to swap")
    slippage: float | None = Field(
        default=None, description="Maximum slippage tolerance in percentage (default 0.5)"
    )


class SwapTokenTool(BaseTool):
    """
    Swap one token for another using DEX aggregator.

    Requires a Signer instance that implements the Signer protocol.

    Example:
        from cryptocom_tools_wallet import PrivateKeySigner

        signer = PrivateKeySigner.from_env()
        tool = SwapTokenTool(signer=signer)
        result = tool.invoke({
            "token_in": "native",  # or token address
            "token_out": "0x5C7F8...",  # USDC address
            "amount": 100
        })
    """

    name: str = "swap_token"
    description: str = "Swap one token for another using DEX aggregator"
    args_schema: type[BaseModel] = SwapTokenInput  # type: ignore[assignment]

    # Required signer (excluded from LLM schema)
    signer: Signer = Field(exclude=True)

    # DEX router address (placeholder - should be configured per chain)
    router_address: str = Field(
        default="0x145677FC4d9b8F19B5D56d1820c48e0443049a30",  # VVS Router on Cronos
        exclude=True,
    )

    def _run(  # type: ignore[override]
        self, token_in: str, token_out: str, amount: float, slippage: float | None = None
    ) -> str:
        """Execute token swap."""
        slippage = slippage or 0.5

        if amount <= 0:
            return "Error: amount must be positive"

        try:
            # Convert amount to wei
            amount_wei = to_base_units(amount, NATIVE_TOKEN_DECIMALS)

            # Build swap path
            is_native_in = token_in.lower() == "native"
            is_native_out = token_out.lower() == "native"

            # Encode swap function call based on token types
            # Using Uniswap V2 style router interface
            if is_native_in:
                # swapExactETHForTokens(uint256 amountOutMin, address[] path, address to, uint256 deadline)
                function_sig = "swapExactETHForTokens(uint256,address[],address,uint256)"
                function_selector = encode_selector(function_sig)
                # Simplified encoding - real implementation would use web3.py contract encoding
                value = amount_wei
            elif is_native_out:
                # swapExactTokensForETH(uint256 amountIn, uint256 amountOutMin, address[] path, address to, uint256 deadline)
                function_sig = "swapExactTokensForETH(uint256,uint256,address[],address,uint256)"
                function_selector = encode_selector(function_sig)
                value = 0
            else:
                # swapExactTokensForTokens(uint256 amountIn, uint256 amountOutMin, address[] path, address to, uint256 deadline)
                function_sig = "swapExactTokensForTokens(uint256,uint256,address[],address,uint256)"
                function_selector = encode_selector(function_sig)
                value = 0

            # Build transaction (simplified - real implementation would encode params properly)
            tx = {
                "to": self.router_address,
                "value": value,
                "data": f"0x{function_selector}",  # Would need full encoding
            }

            # Send via signer
            tx_hash = self.signer.send_transaction(tx)

            # Estimate output (simplified)
            estimated_output = amount * (100 - slippage) / 100

            result = SwapResult(
                tx_hash=tx_hash,
                amount_in=amount,
                amount_out=estimated_output,
                token_in=token_in,
                token_out=token_out,
            )
            return str(result)

        except Exception as e:
            return f"Error: Swap failed: {e}"


__all__ = ["SwapTokenInput", "SwapTokenTool"]
