"""TransferERC20Tool - Transfer ERC20 tokens to an address."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import Signer
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from ._encoding import encode_selector, to_base_units
from ._results import TransferResult


class TransferERC20Input(BaseModel):
    """Input schema for TransferERC20Tool."""

    to: str = Field(description="Recipient blockchain address")
    token_address: str = Field(description="ERC20 token contract address")
    amount: float = Field(description="Amount of tokens to transfer")
    token_decimals: int | None = Field(
        default=None,
        description=(
            "Optional token decimals override. If omitted, the tool reads decimals() from "
            "the token contract using the signer's Web3 provider."
        ),
    )


class TransferERC20Tool(BaseTool):
    """
    Transfer ERC20 tokens to an address.

    Requires a Signer instance that implements the Signer protocol.

    Example:
        from cryptocom_tools_wallet import PrivateKeySigner

        signer = PrivateKeySigner.from_env()
        tool = TransferERC20Tool(signer=signer)
        result = tool.invoke({
            "to": "0x...",
            "token_address": "0x...",
            "amount": 100
        })
    """

    name: str = "transfer_erc20_token"
    description: str = "Transfer ERC20 tokens to an address"
    args_schema: type[BaseModel] = TransferERC20Input  # type: ignore[assignment]

    # Required signer (excluded from LLM schema)
    signer: Signer = Field(exclude=True)

    def _run(  # type: ignore[override]
        self, to: str, token_address: str, amount: float, token_decimals: int | None = None
    ) -> str:
        """Execute ERC20 token transfer."""
        if amount <= 0:
            return "Error: amount must be positive"

        try:
            # ERC20 transfer function signature: transfer(address,uint256)
            # Build the data for the transfer call
            from web3 import Web3

            if not Web3.is_address(to):
                return "Error: invalid recipient address"
            if not Web3.is_address(token_address):
                return "Error: invalid token contract address"

            to_address = Web3.to_checksum_address(to)
            token_contract_address = Web3.to_checksum_address(token_address)

            decimals = (
                token_decimals
                if token_decimals is not None
                else self._fetch_token_decimals(token_contract_address)
            )
            amount_wei = to_base_units(amount, decimals)

            # Encode transfer function call
            # transfer(address to, uint256 amount)
            function_selector = encode_selector("transfer(address,uint256)")
            to_padded = to_address.lower().replace("0x", "").zfill(64)
            amount_hex = hex(amount_wei)[2:].zfill(64)
            data = f"0x{function_selector}{to_padded}{amount_hex}"

            # Build transaction
            tx = {
                "to": token_contract_address,
                "value": 0,
                "data": data,
            }

            # Send via signer
            tx_hash = self.signer.send_transaction(tx)

            result = TransferResult(
                tx_hash=tx_hash,
                from_address=self.signer.address,
                to_address=to,
                amount=amount,
                token_type=f"ERC20@{token_address}",
            )
            return str(result)

        except Exception as e:
            return f"Error: ERC20 transfer failed: {e}"

    def _fetch_token_decimals(self, token_address: str) -> int:
        """Fetch ERC20 decimals() from chain using the signer's Web3 provider."""
        web3_client: Any = getattr(self.signer, "_web3", None) or getattr(self.signer, "web3", None)
        if web3_client is None:
            raise ValueError(
                "token_decimals is required when signer does not expose a Web3 provider"
            )

        contract = web3_client.eth.contract(
            address=token_address,
            abi=[
                {
                    "constant": True,
                    "inputs": [],
                    "name": "decimals",
                    "outputs": [{"name": "", "type": "uint8"}],
                    "stateMutability": "view",
                    "type": "function",
                }
            ],
        )
        decimals = contract.functions.decimals().call()
        if not isinstance(decimals, int) or decimals < 0:
            raise ValueError("invalid token decimals response")
        return decimals


__all__ = ["TransferERC20Input", "TransferERC20Tool"]
