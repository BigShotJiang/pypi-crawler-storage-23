"""UnwrapTokenTool - Unwrap WCRO back to native CRO."""

from __future__ import annotations

from cryptocom_tools_core import Signer
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from ._constants import WCRO_ADDRESS
from ._encoding import NATIVE_TOKEN_DECIMALS, encode_selector, to_base_units
from ._results import WrapResult


class UnwrapTokenInput(BaseModel):
    """Input schema for UnwrapTokenTool."""

    amount: float = Field(description="Amount of WCRO tokens to unwrap")


class UnwrapTokenTool(BaseTool):
    """
    Unwrap WCRO (Wrapped CRO) back to native CRO.

    Requires a Signer instance that implements the Signer protocol.

    Example:
        from cryptocom_tools_wallet import PrivateKeySigner

        signer = PrivateKeySigner.from_env()
        tool = UnwrapTokenTool(signer=signer)
        result = tool.invoke({"amount": 100})
    """

    name: str = "unwrap_token"
    description: str = "Unwrap WCRO (Wrapped CRO) back to native CRO"
    args_schema: type[BaseModel] = UnwrapTokenInput  # type: ignore[assignment]

    # Required signer (excluded from LLM schema)
    signer: Signer = Field(exclude=True)

    def _run(self, amount: float) -> str:  # type: ignore[override]
        """Execute token unwrapping."""
        if amount <= 0:
            return "Error: amount must be positive"

        try:
            # WCRO withdraw function: withdraw(uint256)
            function_selector = encode_selector("withdraw(uint256)")
            amount_wei = to_base_units(amount, NATIVE_TOKEN_DECIMALS)
            amount_hex = hex(amount_wei)[2:].zfill(64)

            # Build transaction
            tx = {
                "to": WCRO_ADDRESS,
                "value": 0,
                "data": f"0x{function_selector}{amount_hex}",
            }

            # Send via signer
            tx_hash = self.signer.send_transaction(tx)

            result = WrapResult(
                tx_hash=tx_hash,
                amount=amount,
                operation="unwrap",
            )
            return str(result)

        except Exception as e:
            return f"Error: Unwrap failed: {e}"


__all__ = ["UnwrapTokenInput", "UnwrapTokenTool"]
