"""Helpers for deterministic amount conversion and calldata encoding."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation

from web3 import Web3

NATIVE_TOKEN_DECIMALS = 18


def to_base_units(amount: float, decimals: int) -> int:
    """Convert a user-facing token amount to base units without float precision loss."""
    if decimals < 0:
        raise ValueError("decimals must be non-negative")

    try:
        normalized_amount = Decimal(str(amount))
    except InvalidOperation as exc:
        raise ValueError("amount must be numeric") from exc

    if not normalized_amount.is_finite():
        raise ValueError("amount must be finite")

    scaled_amount = normalized_amount * (Decimal(10) ** decimals)
    if scaled_amount != scaled_amount.to_integral_value():
        raise ValueError(f"amount has more than {decimals} decimal places")

    return int(scaled_amount)


def encode_selector(function_signature: str) -> str:
    """Return the 4-byte function selector as hex without 0x prefix."""
    return Web3.keccak(text=function_signature)[:4].hex()
