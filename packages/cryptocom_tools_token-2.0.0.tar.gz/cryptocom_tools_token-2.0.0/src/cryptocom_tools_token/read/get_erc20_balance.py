"""GetERC20BalanceTool - Get ERC20 token balance for a blockchain address."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import BalanceResult


class GetERC20BalanceInput(BaseModel):
    """Input schema for GetERC20BalanceTool."""

    address: str = Field(description="The blockchain address to query")
    contract_address: str = Field(description="The ERC20 token contract address")
    decimal_places: int | None = Field(
        default=None,
        description="Number of decimal places to show in the result",
        ge=0,
        le=18,
    )


class GetERC20BalanceTool(CDPTool):
    """
    Get ERC20 token balance for a blockchain address.

    Works natively with LangChain/LangGraph. Can be exported to
    OpenAI/Anthropic SDKs via adapters.

    Example:
        tool = GetERC20BalanceTool()
        result = tool.invoke({
            "address": "0x...",
            "contract_address": "0x..."
        })
    """

    name: str = "get_erc20_balance"
    description: str = "Get the ERC20 token balance for a wallet address and token contract"
    args_schema: type[BaseModel] = GetERC20BalanceInput  # type: ignore[assignment]

    def _run(  # type: ignore[override]
        self,
        address: str,
        contract_address: str,
        decimal_places: int | None = None,
    ) -> str:
        """Get ERC20 token balance for an address."""
        from crypto_com_developer_platform_client import Token
        from web3 import Web3

        # Normalize addresses
        address = self._normalize_address(address)
        contract_address = self._normalize_address(contract_address)

        if not Web3.is_address(address):
            return f"Error: Invalid address: {address}"
        if not Web3.is_address(contract_address):
            return f"Error: Invalid token contract: {contract_address}"

        # Get balance from CDP (use named args like original)
        try:
            response: Any = Token.get_erc20_balance(
                wallet_address=address,
                contract_address=contract_address,
            )
        except Exception as exc:
            return f"Error retrieving ERC20 balance for {address}: {exc}"

        # Extract balance from response
        if isinstance(response, dict) and response.get("status") == "Success":
            balance_raw = response["data"]["balance"]
        else:
            return f"Error retrieving ERC20 balance for {address}"

        # Get token info (decimals, symbol) if available
        token_info = self._get_token_info(contract_address)
        token_decimals = token_info.get("decimals", 18)
        token_symbol = token_info.get("symbol", "TOKEN")

        # Convert from smallest unit to token units
        balance_decimal = Decimal(balance_raw) / Decimal(10**token_decimals)

        if decimal_places is not None:
            balance_str = f"{float(balance_decimal):.{decimal_places}f}"
        else:
            balance_str = str(balance_decimal)

        result = BalanceResult(address=address, balance=balance_str, unit=token_symbol)
        return str(result)

    @staticmethod
    def _normalize_address(address: str) -> str:
        """Normalize address to checksum format."""
        import re

        from web3 import Web3

        match = re.search(r"0x[a-fA-F0-9]{40}", address)
        candidate = match.group(0) if match else address

        if Web3.is_address(candidate):
            return Web3.to_checksum_address(candidate)
        return candidate

    @staticmethod
    def _get_token_info(contract_address: str) -> dict[str, Any]:
        """Get token information from contract."""
        from crypto_com_developer_platform_client import Token

        try:
            get_token_info = getattr(Token, "get_token_info", None)
            if get_token_info is not None:
                response: Any = get_token_info(contract_address)
                if isinstance(response, dict) and response.get("status") == "Success":
                    return response["data"]
        except Exception:
            pass

        return {"decimals": 18, "symbol": "TOKEN", "name": "Unknown Token"}


__all__ = ["GetERC20BalanceInput", "GetERC20BalanceTool"]
