"""Shared result classes for token read tools."""

from __future__ import annotations

from dataclasses import dataclass

from cryptocom_tools_core import ToolResult


@dataclass
class BalanceResult(ToolResult):
    """Result from balance query tools."""

    address: str
    balance: str
    unit: str

    def _format_result(self) -> str:
        return f"The balance for address {self.address} is {self.balance} {self.unit}."


__all__ = ["BalanceResult"]
