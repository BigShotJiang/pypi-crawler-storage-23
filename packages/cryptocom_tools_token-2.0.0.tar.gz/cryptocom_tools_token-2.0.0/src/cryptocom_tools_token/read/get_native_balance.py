"""GetNativeBalanceTool - Get native token balance for a blockchain address."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import BalanceResult


class GetNativeBalanceInput(BaseModel):
    """Input schema for GetNativeBalanceTool."""

    address: str = Field(description="The blockchain address to query")
    use_wei: bool = Field(
        default=True,
        description="If true, returns balance in WEI. If false, returns in CRO.",
    )
    decimal_places: int | None = Field(
        default=None,
        description="Number of decimal places for CRO format (when use_wei=false)",
        ge=0,
        le=18,
    )


class GetNativeBalanceTool(CDPTool):
    """
    Get native token balance for a blockchain address.

    Works natively with LangChain/LangGraph. Can be exported to
    OpenAI/Anthropic SDKs via adapters.

    Example:
        tool = GetNativeBalanceTool()

        # Direct call
        result = tool.invoke({"address": "0x..."})

        # With LangChain agent
        agent = create_agent("openai:gpt-4o", tools=[tool])

        # With OpenAI SDK (via adapter)
        openai_tool = to_openai_function(tool)
    """

    name: str = "get_native_balance"
    description: str = "Get the native token balance of a blockchain address on Cronos"
    args_schema: type[BaseModel] = GetNativeBalanceInput  # type: ignore[assignment]

    def _run(  # type: ignore[override]
        self,
        address: str,
        use_wei: bool = True,
        decimal_places: int | None = None,
    ) -> str:
        """Get native token balance for an address."""
        from crypto_com_developer_platform_client import Token
        from web3 import Web3

        # Normalize address to checksum format
        address = self._normalize_address(address)

        if not Web3.is_address(address):
            return f"Error: Invalid address: {address}"

        # Get balance from CDP
        try:
            response: Any = Token.get_native_balance(address)
        except Exception as exc:
            return f"Error retrieving balance for {address}: {exc}"

        # Extract balance from response
        if isinstance(response, dict) and response.get("status") == "Success":
            balance_wei = response["data"]["balance"]
        else:
            return f"Error retrieving balance for {address}"

        if use_wei:
            balance_str = str(balance_wei)
            unit = "WEI"
        else:
            # Convert WEI to CRO (1 CRO = 10^18 WEI)
            balance_cro = Decimal(str(balance_wei)) / Decimal(10**18)

            if decimal_places is not None:
                quantized = balance_cro.quantize(Decimal("0." + "0" * decimal_places))
                balance_str = f"{quantized:.{decimal_places}f}"
            else:
                balance_str = str(balance_cro)

            unit = "CRO"

        result = BalanceResult(address=address, balance=balance_str, unit=unit)
        return str(result)

    @staticmethod
    def _normalize_address(address: str) -> str:
        """Normalize address to checksum format."""
        import re

        from web3 import Web3

        match = re.search(r"0x[a-fA-F0-9]{40}", address)
        candidate = match.group(0) if match else address

        if Web3.is_address(candidate):
            return Web3.to_checksum_address(candidate)
        return candidate


__all__ = ["GetNativeBalanceInput", "GetNativeBalanceTool"]
