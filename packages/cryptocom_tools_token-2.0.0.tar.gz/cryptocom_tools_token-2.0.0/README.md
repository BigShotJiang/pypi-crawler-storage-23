# cryptocom-tools-token

Token tools for Crypto.com Developer Platform.

## Installation

```bash
pip install cryptocom-tools-token
```

## Read Tools (No Signer Required)

Query token balances without signing transactions.

```python
from cryptocom_tools_token import GetNativeBalanceTool, GetERC20BalanceTool

# Query native CRO balance
balance_tool = GetNativeBalanceTool()
result = balance_tool.invoke({"address": "0x..."})

# Query ERC20 token balance
erc20_tool = GetERC20BalanceTool()
result = erc20_tool.invoke({
    "address": "0x...",
    "contract_address": "0x..."
})
```

## Write Tools (Signer Required)

Execute token operations that require transaction signing.

```python
from cryptocom_tools_token import TransferNativeTool, SwapTokenTool, WrapTokenTool
from cryptocom_tools_wallet import PrivateKeySigner

# Create a signer (implements Signer protocol)
signer = PrivateKeySigner.from_env()

# Transfer native tokens
transfer_tool = TransferNativeTool(signer=signer)
result = transfer_tool.invoke({"to": "0x...", "amount": 1.5})

# Swap tokens
swap_tool = SwapTokenTool(signer=signer)
result = swap_tool.invoke({
    "token_in": "native",  # or token address
    "token_out": "0x5C7F8...",  # USDC address
    "amount": 100
})

# Wrap CRO to WCRO
wrap_tool = WrapTokenTool(signer=signer)
result = wrap_tool.invoke({"amount": 50})
```

## License

MIT
