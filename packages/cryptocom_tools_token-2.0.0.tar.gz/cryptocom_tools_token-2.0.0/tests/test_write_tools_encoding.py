"""Regression tests for token write tool encoding and amount conversion."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from cryptocom_tools_token import (
    SwapTokenTool,
    TransferERC20Tool,
    TransferNativeTool,
    UnwrapTokenTool,
    WrapTokenTool,
)


@dataclass
class DummySigner:
    """Minimal signer test double that records the submitted transaction."""

    address: str = "0x1111111111111111111111111111111111111111"
    chain_id: int = 25
    last_tx: dict[str, Any] | None = None

    def send_transaction(self, tx: dict[str, Any]) -> str:
        self.last_tx = tx
        return "0xdeadbeef"


class _MockDecimalsCall:
    def __init__(self, decimals: int):
        self._decimals = decimals

    def call(self) -> int:
        return self._decimals


class _MockContractFunctions:
    def __init__(self, decimals: int):
        self._decimals = decimals

    def decimals(self) -> _MockDecimalsCall:
        return _MockDecimalsCall(self._decimals)


class _MockContract:
    def __init__(self, decimals: int):
        self.functions = _MockContractFunctions(decimals)


class _MockEth:
    def __init__(self, decimals: int):
        self._decimals = decimals

    def contract(self, address: str, abi: list[dict[str, Any]]) -> _MockContract:
        _ = address, abi
        return _MockContract(self._decimals)


class _MockWeb3:
    def __init__(self, decimals: int):
        self.eth = _MockEth(decimals)


def test_transfer_native_uses_exact_wei_conversion() -> None:
    signer = DummySigner()
    tool = TransferNativeTool(signer=signer)

    result = tool.invoke({"to": "0x2222222222222222222222222222222222222222", "amount": 0.1})

    assert "Transfer successful!" in result
    assert signer.last_tx is not None
    assert signer.last_tx["value"] == 100000000000000000


def test_wrap_and_unwrap_keep_full_selectors_and_exact_amounts() -> None:
    signer = DummySigner()
    wrap_tool = WrapTokenTool(signer=signer)
    unwrap_tool = UnwrapTokenTool(signer=signer)

    wrap_result = wrap_tool.invoke({"amount": 0.1})
    assert "Wrap successful!" in wrap_result
    assert signer.last_tx is not None
    assert signer.last_tx["data"] == "0xd0e30db0"
    assert signer.last_tx["value"] == 100000000000000000

    unwrap_result = unwrap_tool.invoke({"amount": 0.1})
    assert "Unwrap successful!" in unwrap_result
    assert signer.last_tx is not None
    assert signer.last_tx["data"].startswith("0x2e1a7d4d")
    assert signer.last_tx["data"].endswith("16345785d8a0000".zfill(64))


def test_swap_tool_keeps_full_selector_and_exact_native_amount() -> None:
    signer = DummySigner()
    tool = SwapTokenTool(signer=signer)

    result = tool.invoke(
        {
            "token_in": "native",
            "token_out": "0x3333333333333333333333333333333333333333",
            "amount": 0.1,
        }
    )

    assert "Swap completed!" in result
    assert signer.last_tx is not None
    assert signer.last_tx["data"] == "0x7ff36ab5"
    assert signer.last_tx["value"] == 100000000000000000


def test_transfer_erc20_uses_token_decimals_for_amount_encoding() -> None:
    signer = DummySigner()
    tool = TransferERC20Tool(signer=signer)

    result = tool.invoke(
        {
            "to": "0x2222222222222222222222222222222222222222",
            "token_address": "0x4444444444444444444444444444444444444444",
            "amount": 0.1,
            "token_decimals": 6,
        }
    )

    assert "Transfer successful!" in result
    assert signer.last_tx is not None
    assert signer.last_tx["data"].startswith("0xa9059cbb")
    assert signer.last_tx["data"].endswith(hex(100000)[2:].zfill(64))


def test_transfer_erc20_reads_decimals_from_signer_web3() -> None:
    signer = DummySigner()
    signer._web3 = _MockWeb3(decimals=6)  # type: ignore[attr-defined]
    tool = TransferERC20Tool(signer=signer)

    result = tool.invoke(
        {
            "to": "0x2222222222222222222222222222222222222222",
            "token_address": "0x4444444444444444444444444444444444444444",
            "amount": 1.234567,
        }
    )

    assert "Transfer successful!" in result
    assert signer.last_tx is not None
    assert signer.last_tx["data"].endswith(hex(1234567)[2:].zfill(64))


def test_transfer_erc20_requires_decimals_when_signer_has_no_web3() -> None:
    signer = DummySigner()
    tool = TransferERC20Tool(signer=signer)

    result = tool.invoke(
        {
            "to": "0x2222222222222222222222222222222222222222",
            "token_address": "0x4444444444444444444444444444444444444444",
            "amount": 1.0,
        }
    )

    assert "Error: ERC20 transfer failed" in result
    assert "token_decimals is required" in result
