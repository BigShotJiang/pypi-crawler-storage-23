"""Base exception classes for LLM Lab library."""

from __future__ import annotations


class LLMLabError(Exception):
    """Base exception for all LLM Lab library errors."""


class ConfigurationError(LLMLabError):
    """Raised for invalid or missing configuration values."""


class RuntimeEnvironmentError(LLMLabError):
    """Raised when required runtime environment or dependencies are not available."""


class FileTextIOError(LLMLabError):
    """Base exception for `llm_lab.filetextio` domain."""


class UnsupportedFileTypeError(FileTextIOError):
    """Raised when a file extension is not supported by the parser registry."""


class ParseError(FileTextIOError):
    """Raised when a parser fails to extract text from a file."""
