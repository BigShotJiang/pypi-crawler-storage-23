from __future__ import annotations
from .string_similarity import check_similarity

__all__ = ["check_similarity"]

