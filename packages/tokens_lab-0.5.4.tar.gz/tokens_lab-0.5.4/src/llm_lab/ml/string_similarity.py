"""String similarity functions."""

from __future__ import annotations

from difflib import SequenceMatcher

from ..utils import normalize_name

def similarity(a: str, b: str) -> float:
    """Calculate sequence similarity ratio.
    
    Args:
        a: First string.
        b: Second string.
        
    Returns:
        Similarity ratio 0-1.
    """
    return SequenceMatcher(None, a, b).ratio()


def char_ngrams(s: str, n: int = 3) -> set:
    """Generate character n-grams from string.
    
    Args:
        s: Input string.
        n: N-gram size (default: 3).
        
    Returns:
        Set of n-grams.
    """
    s2 = s.replace(" ", "")
    return {s2[i:i+n] for i in range(max(0, len(s2) - n + 1))} if s2 else set()


def jaccard(a: set, b: set) -> float:
    """Calculate Jaccard similarity between sets.
    
    Args:
        a: First set.
        b: Second set.
        
    Returns:
        Jaccard coefficient 0-1.
    """
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    inter = len(a & b)
    union = len(a | b)
    return inter / union if union else 0.0


def check_similarity(a_name: str, b_name: str) -> float:
    """Calculate name similarity score.
    
    Combines sequence matching and n-gram Jaccard with length penalty.
    
    Args:
        a_name: First name.
        b_name: Second name.
        
    Returns:
        Similarity score 0-1.
    """
    a_norm = normalize_name(a_name)
    b_norm = normalize_name(b_name)
    seq = similarity(a_norm, b_norm)
    jac = jaccard(char_ngrams(a_norm, 3), char_ngrams(b_norm, 3))
    # penalize very different lengths
    la, lb = len(a_norm), len(b_norm)
    length_ratio = (min(la, lb) / max(la, lb)) if max(la, lb) else 1.0
    penalty = 0.9 if length_ratio < 0.6 else 1.0
    conf = (0.55 * seq + 0.45 * jac) * penalty
    return conf