"""LLM Lab — LLM utilities with agents, file parsing, and preprocessing."""

from __future__ import annotations

__version__ = "0.3.4"

# ---------------------------------------------------------------------------
# Public API — lazy imports keep startup fast and avoid pulling in heavy
# dependencies until they are actually needed.
# ---------------------------------------------------------------------------

def __getattr__(name: str):
    """Lazy-load public symbols on first access."""
    _imports: dict[str, tuple[str, str]] = {
        # agent
        "Agent": (".agent", "Agent"),
        "LLMClient": (".agent", "LLMClient"),
        "make_litellm_http_client": (".agent", "make_litellm_http_client"),
        "LAST_LLM_COST": (".agent", "LAST_LLM_COST"),
        "LAST_REQUEST_ID": (".agent", "LAST_REQUEST_ID"),
        # exceptions
        "LLMLabError": (".exceptions", "LLMLabError"),
        "ConfigurationError": (".exceptions", "ConfigurationError"),
        "RuntimeEnvironmentError": (".exceptions", "RuntimeEnvironmentError"),
        "FileTextIOError": (".exceptions", "FileTextIOError"),
        "UnsupportedFileTypeError": (".exceptions", "UnsupportedFileTypeError"),
        "ParseError": (".exceptions", "ParseError"),
        "MissingConfigError": (".exceptions", "MissingConfigError"),
        "InvalidConfigError": (".exceptions", "InvalidConfigError"),
        # filetextio
        "load_text": (".filetextio", "load_text"),
        "FileParser": (".filetextio", "FileParser"),
        "get_parser_for": (".filetextio", "get_parser_for"),
        "is_supported_file": (".filetextio", "is_supported_file"),
        "get_supported_types": (".filetextio", "get_supported_types"),
        # preprocessing
        "normalize_text": (".preprocessing", "normalize_text"),
        # utils
        "normalize_date": (".utils", "normalize_date"),
        "normalize_string": (".utils", "normalize_string"),
        "normalize_name": (".utils", "normalize_name"),
        # ml
        "check_similarity": (".ml", "check_similarity"),
        # logging
        "Logger": (".logging", "Logger"),
    }

    if name in _imports:
        module_path, attr = _imports[name]
        import importlib
        mod = importlib.import_module(module_path, __name__)
        return getattr(mod, attr)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "__version__",
    # agent
    "Agent",
    "LLMClient",
    "make_litellm_http_client",
    "LAST_LLM_COST",
    "LAST_REQUEST_ID",
    # exceptions
    "LLMLabError",
    "ConfigurationError",
    "RuntimeEnvironmentError",
    "FileTextIOError",
    "UnsupportedFileTypeError",
    "ParseError",
    "MissingConfigError",
    "InvalidConfigError",
    # filetextio
    "load_text",
    "FileParser",
    "get_parser_for",
    "is_supported_file",
    "get_supported_types",
    # preprocessing
    "normalize_text",
    # utils
    "normalize_date",
    "normalize_string",
    "normalize_name",
    # ml
    "check_similarity",
    # logging
    "Logger",
]
