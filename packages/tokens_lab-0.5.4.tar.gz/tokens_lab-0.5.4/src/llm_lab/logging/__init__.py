"""Logging module — structured logging with optional Azure backend."""

from __future__ import annotations

from .logger import Logger

__all__ = ["Logger"]
