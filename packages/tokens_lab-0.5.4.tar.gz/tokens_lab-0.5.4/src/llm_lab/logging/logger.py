import os
import logging
from logging.handlers import RotatingFileHandler
from ..azure.azure_storage import AzureStorage
from ..utils.date import get_today_folder_name

class Logger(AzureStorage):
    """Logger with file rotation and optional Azure upload.
    
    Features:
        - Daily log folders
        - Per-run segregation
        - Separate debug/info/error logs
        - Azure Blob Storage integration
    """

    def __init__(
        self,
        name: str = "llm_lab",
        azure_connection_string: str | None = None,
        azure_container_name: str | None = None,
        local_log: bool = True,
        azure_log: bool = False,
    ):
        """Initialize logger.
        
        Args:
            name: Logger name (default: llm_lab).
            azure_connection_string: Azure connection string.
            azure_container_name: Azure container name.
            local_log: Enable local file logging (default: True).
            azure_log: Enable Azure upload (default: False).
        """
        super().__init__(conn_string=azure_connection_string,container_name=azure_container_name)

        self.name = name
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        self.logger.propagate = False

        if self.logger.hasHandlers():
            self.logger.handlers.clear()

        self.run_folder = None

        if local_log:
            self.setup_local_logger()
        if azure_log:
            self.upload_logs_to_azure()
            

    def _create_run_folder(self, base_log_folder: str) -> str:
        date_folder = os.path.join(base_log_folder, get_today_folder_name())
        os.makedirs(date_folder, exist_ok=True)

        existing_runs = [
            d for d in os.listdir(date_folder)
            if os.path.isdir(os.path.join(date_folder, d)) and d.startswith("run")
        ]

        run_number = len(existing_runs) + 1
        run_folder = os.path.join(date_folder, f"run{run_number}")
        os.makedirs(run_folder, exist_ok=True)

        return run_folder



    def setup_local_logger(self, log_folder: str = "logs") -> str:
        """
        Creates:
            logs/DD_M_YYYY/runX/
                debug.log
                info.log
                error.log
        """
        self.run_folder = self._create_run_folder(log_folder)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

        # Debug
        debug_handler = RotatingFileHandler(
            os.path.join(self.run_folder, "debug.log"),
            maxBytes=10 * 1024 * 1024,
            backupCount=3,
        )
        debug_handler.setLevel(logging.DEBUG)
        debug_handler.setFormatter(formatter)

        # Info
        info_handler = RotatingFileHandler(
            os.path.join(self.run_folder, "info.log"),
            maxBytes=10 * 1024 * 1024,
            backupCount=3,
        )
        info_handler.setLevel(logging.INFO)
        info_handler.setFormatter(formatter)

        # Error
        error_handler = RotatingFileHandler(
            os.path.join(self.run_folder, "error.log"),
            maxBytes=10 * 1024 * 1024,
            backupCount=3,
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)

        self.logger.addHandler(debug_handler)
        self.logger.addHandler(info_handler)
        self.logger.addHandler(error_handler)

        self.logger.info(f"Logger initialized in {self.run_folder}")

        return self.run_folder



    def upload_logs_to_azure(self):
        """
        Uploads the entire run folder to Azure
        preserving folder structure:
        DD_M_YYYY/runX/file.log
        """
        if not self.container_client:
            raise ValueError("Azure is not configured.")

        if not self.run_folder:
            raise ValueError("Local logger not initialized.")

        base_folder_name = os.path.basename(
            os.path.dirname(self.run_folder)
        )
        run_folder_name = os.path.basename(self.run_folder)

        for file_name in os.listdir(self.run_folder):
            local_file_path = os.path.join(self.run_folder, file_name)
            blob_path = f"{base_folder_name}/{run_folder_name}/{file_name}"

            with open(local_file_path, "rb") as f:
                self.upload_to_blob(blob_path, f.read(), content_type="text/plain")

        self.logger.info("Logs uploaded to Azure successfully.")


    def get_logger(self) -> logging.Logger:
        return self.logger
