"""Generic agent wrapper around a graph-based workflow engine."""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from langgraph.graph import StateGraph



class Agent:
    """Graph-based workflow agent built on LangGraph.
    
    Build stateful agent workflows using nodes, edges, and conditional logic.
    """

    def __init__(self, state_type: Optional[type] = None) -> None:
        """Initialize agent with optional state type.
        
        Args:
            state_type: Custom state class. Defaults to dict.
        """
        self._state_type = state_type or dict
        self._sg = StateGraph(self._state_type)
        self._compiled = None

    def reset(self, state_type: Optional[type] = None) -> "Agent":
        """Reset the agent graph to initial state.
        
        Args:
            state_type: Optional new state type.
            
        Returns:
            Self for method chaining.
        """
        self._state_type = state_type or self._state_type
        self._sg = StateGraph(self._state_type)
        self._compiled = None
        return self

    def add_node(self, name: str, func: Callable[[Dict[str, Any]], Dict[str, Any]]) -> "Agent":
        """Add a processing node to the graph.
        
        Args:
            name: Node identifier.
            func: Function that processes and returns state.
            
        Returns:
            Self for method chaining.
        """
        self._sg.add_node(name, func)
        return self

    def set_entry_point(self, name: str) -> "Agent":
        """Set the starting node for workflow execution.
        
        Args:
            name: Node name to start from.
            
        Returns:
            Self for method chaining.
        """
        self._sg.set_entry_point(name)
        return self

    def add_edge(self, start: str, end: str) -> "Agent":
        """Add a direct edge between two nodes.
        
        Args:
            start: Source node name.
            end: Target node name.
            
        Returns:
            Self for method chaining.
        """
        self._sg.add_edge(start, end)
        return self

    def add_conditional_edges(
        self,
        current: str,
        condition: Callable[[Dict[str, Any]], str],
        mapping: Dict[str, str],
    ) -> "Agent":
        """Add conditional routing from a node.
        
        Args:
            current: Source node name.
            condition: Function that returns next node name.
            mapping: Map of condition outputs to node names.
            
        Returns:
            Self for method chaining.
        """
        self._sg.add_conditional_edges(current, condition, mapping)
        return self

    def compile(self) -> "Agent":
        """Compile the graph for execution.
        
        Returns:
            Self for method chaining.
        """
        self._compiled = self._sg.compile()
        return self

    def invoke(self, initial_state: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the workflow with initial state.
        
        Args:
            initial_state: Starting state dictionary.
            
        Returns:
            Final state after workflow completion.
            
        Raises:
            RuntimeError: If graph not compiled.
        """
        if not self._compiled:
            raise RuntimeError("Graph is not compiled. Call compile() first.")
        return self._compiled.invoke(initial_state)
