"""HTTP client with LiteLLM cost tracking and Azure integration."""

import os
import httpx
from datetime import datetime
from typing import Any, Optional
import logging


class LiteLLMHttpClient(httpx.Client):
    """HTTP client that tracks LiteLLM costs and uploads to Azure.
    
    Extends httpx.Client with automatic cost capture from response headers.
    
    Args:
        azure_storage: Optional AzureStorage for cost uploads.
        logger: Optional logger instance.
        timeout: Request timeout in seconds (default: 60).
        **kwargs: Additional httpx.Client arguments.
    """
    
    def __init__(
        self,
        azure_storage: Optional[Any] = None,
        logger: Optional[logging.Logger] = None,
        timeout: float = 60.0,
        **kwargs: Any
    ) -> None:
        self._azure_storage = azure_storage
        self._logger = logger
        
        super().__init__(
            timeout=timeout,
            event_hooks={"response": [self._capture_litellm_headers]},
            follow_redirects=True,
            **kwargs
        )
    
    def _capture_litellm_headers(self, response: httpx.Response) -> None:
        """Capture and log LiteLLM cost headers.
        
        Args:
            response: HTTP response object.
        """
        if "text/event-stream" in response.headers.get("content-type", ""):
            return

        cost = response.headers.get("x-litellm-response-cost")
        request_id = response.headers.get("x-request-id")

        if cost is None:
            return

        self._logger.info(f"LiteLLM cost captured: {cost} (request_id: {request_id})")

        # print("=== LITELLM COST ===")
        # print(f"cost: {cost}")
        # print(f"request_id: {request_id}")
        # print(f"status_code: {response.status_code}")
        
        if self._azure_storage:
            try:
                model = os.getenv("MODEL", "unknown")
                cost_entry = {
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "cost": cost,
                    "request_id": request_id,
                    "status_code": response.status_code,
                    "model": model,
                }
                self._azure_storage.append_to_azure(
                    content=cost_entry,
                    blob_name="cost.log"
                )
            except Exception as e:
                self._logger.debug(f"Failed to upload cost to Azure: {e}")
