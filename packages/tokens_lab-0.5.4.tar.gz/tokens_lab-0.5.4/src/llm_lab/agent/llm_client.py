"""Thin wrapper around the OpenAI client for chat and response generation."""

from __future__ import annotations

from typing import Any

import httpx
from openai import OpenAI


class LLMClient:
    """OpenAI-compatible LLM client.

    Args:
        api_key: API authentication key.
        base_url: LLM endpoint base URL.
        model_name: Model identifier.
        timeout: Request timeout in seconds (default: 60).
        max_retries: Retry attempts on failures (default: 2).
        http_client: Optional custom httpx client.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model_name: str,
        timeout: float = 60.0,
        max_retries: int = 2,
        http_client: httpx.Client | None = None,
    ) -> None:
        try:
            self.client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
                http_client=http_client,
            )
            self.model_name = model_name
        except Exception as e:
            raise RuntimeError(f"Failed to initialize LLM client: {e}") from e

    def complete_chat(
        self,
        prompt: list[dict[str, Any]],
        temperature: float = 0.7,
        reasoning: dict[str, Any] | None = None,
    ) -> str:
        """Send chat completion request.

        Args:
            prompt: List of message dicts in OpenAI format.
            temperature: Sampling temperature 0-2 (default: 0.7).
            reasoning: Optional reasoning config.

        Returns:
            Assistant's text response.
        """
        try:
            kwargs: dict[str, Any] = dict(
                model=self.model_name,
                messages=prompt,
                temperature=temperature,
            )
            if reasoning is not None:
                kwargs["reasoning"] = reasoning
            response = self.client.chat.completions.create(**kwargs)
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"LLM request failed: {e}") from e

    def generate_response(
        self,
        prompt: str,
        reasoning: dict[str, Any] | None = None,
    ) -> str:
        """Generate text response using responses API.

        Args:
            prompt: User prompt.
            reasoning: Optional reasoning config.

        Returns:
            Generated text.
        """
        try:
            kwargs: dict[str, Any] = dict(
                model=self.model_name,
                input=prompt,
            )
            if reasoning is not None:
                kwargs["reasoning"] = reasoning
            response = self.client.responses.create(**kwargs)
            return response.output_text
        except Exception as e:
            raise RuntimeError(f"LLM request failed: {e}") from e
