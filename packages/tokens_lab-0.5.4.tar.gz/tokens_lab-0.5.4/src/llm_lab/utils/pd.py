"""Pandas utilities."""

import pandas as pd
from io import BytesIO



def load_excel_from_bytes(bytes_data: bytes) -> pd.DataFrame:
    """Load Excel file from bytes.
    
    Args:
        bytes_data: Excel file as bytes.
        
    Returns:
        DataFrame with Excel content.
        
    Raises:
        Exception: If Excel loading fails.
    """
    try:
        return pd.read_excel(BytesIO(bytes_data), engine="openpyxl")
    except:
        raise