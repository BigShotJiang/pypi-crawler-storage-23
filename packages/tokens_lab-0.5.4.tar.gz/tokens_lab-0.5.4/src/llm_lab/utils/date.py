"""Date normalization — convert various date representations to ISO 8601."""

from __future__ import annotations

import datetime as _dt_module
from datetime import datetime as _datetime
from typing import Any

import pandas as pd
from dateutil import parser as date_parser

_EXPLICIT_FORMATS = [
    "%Y-%m-%d %H:%M:%S",     
    "%Y-%m-%d %H:%M:%S.%f",  
    "%Y-%m-%d",              
    "%Y/%m/%d",              
    "%d/%m/%Y",              
    "%d/%m/%y",              
    "%d-%m-%Y",              
    "%d-%m-%y",              
    "%d.%m.%Y",              
    "%d.%m.%y",              
    "%m/%d/%Y",              
    "%m/%d/%y",              
    "%m-%d-%Y",              
    "%m-%d-%y",              
    "%Y%m%d",                
    "%d%m%Y",                
    "%d %b %Y",              
    "%d %B %Y",              
    "%b %d, %Y",             
    "%B %d, %Y",             
]


def normalize_date(date_val: Any) -> str:
    """Normalize date to YYYY-MM-DD format.
    
    Args:
        date_val: Date value (string, datetime, Timestamp, etc.).
    
    Returns:
        ISO date string or empty string if unparseable.
    """
    if date_val is None or date_val == "":
        return ""
    
    try:
        if pd.isna(date_val):
            return ""
    except (TypeError, ValueError):
        pass

    if hasattr(date_val, "date") and callable(date_val.date):
        try:
            return date_val.date().isoformat()
        except Exception:
            pass

    date_str = str(date_val).strip()
    if not date_str:
        return ""

    # Strip sub-second parts that confuse some format strings
    clean_str = (
        date_str.split(".")[0]
        if "." in date_str and len(date_str.split(".")[-1]) > 4
        else date_str
    )

    # --- Explicit format parsing (fast, predictable) ---
    for fmt in _EXPLICIT_FORMATS:
        try:
            dt = _datetime.strptime(clean_str, fmt)
            return dt.date().isoformat()
        except ValueError:
            continue

    # --- Fallback: dateutil (very flexible, slower) ---
    try:
        dt = date_parser.parse(date_str, dayfirst=True)
        return dt.date().isoformat()
    except (ValueError, TypeError, date_parser.ParserError):
        pass

    # Already looks like YYYY-MM-DD?
    if len(date_str) >= 10 and date_str[4] == "-" and date_str[7] == "-":
        return date_str[:10]

    return ""


def get_today_folder_name() -> str:
    """Get folder name for today's date.
    
    Returns:
        Folder name in format 'DD_MM_YYYY'.
    """
    today = _datetime.now()
    return f"{today.day}_{today.month}_{today.year}"

def is_date(s: Any) -> tuple[bool, str | None]:
    """Check if value is a date type.
    
    Args:
        s: Value to check.
        
    Returns:
        Tuple of (is_date: bool, iso_string: str).
    """
    if isinstance(s, (pd.Timestamp, _datetime, _dt_module.date)):
        return True, s.date().isoformat() if hasattr(s, 'date') else s.isoformat()
    return False, None
