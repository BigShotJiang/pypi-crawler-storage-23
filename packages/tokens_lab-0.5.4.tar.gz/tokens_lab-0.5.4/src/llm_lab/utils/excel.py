"""Excel file utilities using openpyxl."""

from io import BytesIO
from openpyxl import Workbook
from openpyxl.worksheet.worksheet import Worksheet


def auto_adjust_column_widths(ws: Worksheet, max_width: int = 50) -> None:
    """Auto-adjust column widths based on content.
    
    Args:
        ws: Worksheet object.
        max_width: Maximum column width (default: 50).
    """
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                cell_len = len(str(cell.value)) if cell.value else 0
                if cell_len > max_length:
                    max_length = cell_len
            except Exception:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, max_width)


def write_data_rows(ws: Worksheet, data: list[dict], columns: list[str], 
                    start_row: int = 2, text_format: bool = True) -> None:
    """Write data rows to worksheet.
    
    Args:
        ws: Worksheet object.
        data: List of row dictionaries.
        columns: Column keys in order.
        start_row: Starting row number (default: 2).
        text_format: Format cells as text (default: True).
    """
    for row_idx, record in enumerate(data, start_row):
        for col_idx, field in enumerate(columns, 1):
            value = record.get(field)
            cell = ws.cell(row=row_idx, column=col_idx)
            
            if value is None or value == "null" or value == "":
                cell.value = ""
            else:
                cell.value = str(value)
            
            if text_format:
                cell.number_format = "@"


def write_data_rows_with_formatting(ws: Worksheet, data: list[dict], columns: list[str],
                                    text_fields: set[str] | None = None,
                                    start_row: int = 2) -> None:
    """Write data rows with selective text formatting.
    
    Args:
        ws: Worksheet object.
        data: List of row dictionaries.
        columns: Column keys in order.
        text_fields: Fields to format as text.
        start_row: Starting row number (default: 2).
    """
    text_fields = text_fields or set()
    
    for row_idx, record in enumerate(data, start_row):
        for col_idx, field in enumerate(columns, 1):
            value = record.get(field)
            cell = ws.cell(row=row_idx, column=col_idx)
            
            if value is None or value == "null":
                cell.value = ""
                cell.number_format = "@"
            elif field in text_fields:
                cell.value = str(value)
                cell.number_format = "@"
            else:
                cell.value = str(value) if value != "" else ""
                cell.number_format = "@"


def create_workbook_with_headers(title: str, headers: list[str]) -> tuple[Workbook, object]:
    """Create workbook with headers.
    
    Args:
        title: Worksheet title.
        headers: Column header names.
    
    Returns:
        Tuple of (Workbook, worksheet).
    """
    wb = Workbook()
    ws = wb.active
    ws.title = title
    ws.append(headers)
    return wb, ws


def save_workbook_to_buffer(wb: Workbook) -> BytesIO:
    """Save workbook to BytesIO buffer.
    
    Args:
        wb: openpyxl Workbook object
    
    Returns:
        BytesIO buffer with Excel file content
    """
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer
