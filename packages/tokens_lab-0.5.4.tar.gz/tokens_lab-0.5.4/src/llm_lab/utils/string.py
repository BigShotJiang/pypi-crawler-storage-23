"""String normalization helpers."""

from __future__ import annotations

import re
import pandas as pd
from typing import Any
from .date import is_date, normalize_date


def normalize_name(name: str) -> str:
    """Normalize name for similarity comparison.
    
    Lowercases, removes punctuation/digits/diacritics, strips honorifics.
    
    Args:
        name: Name string.
        
    Returns:
        Normalized name.
    """
    if not isinstance(name, str):
        return ""
    s = name.strip().lower()
    s = re.sub(r"[^A-Za-z_\s\-\u0621-\u064A]", " ", s)
    s = re.sub(r"\d+", " ", s)
    s = re.sub(r"[\u064B-\u0652]", "", s)
    honorifics = [
        r"\bmr\.?\b", r"\bmrs\.?\b", r"\bms\.?\b", r"\bmiss\b",
        r"\bdr\.?\b", r"\bprof\.?\b", r"\bsir\b", r"\bmadam\b",
        r"\bالسيد\b", r"\bالسيدة\b", r"\bالأستاذ\b", r"\bالدكتور\b",
    ]
    for h in honorifics:
        s = re.sub(h, " ", s)
    s = re.sub(r"(.)\1{2,}", r"\1\1", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def normalize_string(label: str) -> str:
    """Normalize string to lowercase and strip whitespace.
    
    Args:
        label: Input string.
        
    Returns:
        Normalized string.
    """
    return str(label).strip().lower()

     
def normalize_value(v: Any) -> str:
    """Normalize various value types to string.
    
    Handles dates, numbers, and strings with appropriate formatting.
    
    Args:
        v: Value to normalize.
        
    Returns:
        Normalized string value.
    """
    try:
        if pd.isna(v):
            return ""
    except Exception:
        pass
    
    date_check, date = is_date(v)
    if date_check:
        return date

    if isinstance(v, (int, float)):
        return f"{round(float(v), 2):.2f}"
    
    if isinstance(v, str):
        v_stripped = v.strip()
        date_normalized = normalize_date(v_stripped)
        if date_normalized and date_normalized != v_stripped:
            return date_normalized
        
        try:
            num_str = v_stripped.replace(',', '')
            num = float(num_str)
            return f"{round(num, 2):.2f}"
        except (ValueError, AttributeError):
            return v_stripped.lower()
    
    return str(v).strip().lower()


def values_match(v1: str, v2: str, threshold: float) -> bool:
    """Check if two values match with numeric threshold.
    
    Args:
        v1: First value.
        v2: Second value.
        threshold: Numeric difference threshold.
        
    Returns:
        True if values match.
    """
    if str(v1).lower() == str(v2).lower():
        return True

    date1 = normalize_date(v1)
    date2 = normalize_date(v2)

    if date1 and date2 and date1 == date2:
        return True
    
    try:
        num1 = float(str(v1).replace(',', ''))
        num2 = float(str(v2).replace(',', ''))
        return abs(num1 - num2) <= threshold
    except (ValueError, AttributeError):
        return False

