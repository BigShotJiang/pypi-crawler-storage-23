"""JSON cleaning utilities for LLM output."""

import re

def _clean_llm_json_output(llm_output: str, logger) -> str:
        """Clean LLM JSON output by removing markdown and prefixes.
        
        Args:
            llm_output: Raw LLM output string.
            logger: Logger instance.
            
        Returns:
            Cleaned JSON string.
        """
        if not llm_output:
            return llm_output
        
        logger.debug(f"Cleaning LLM JSON output: {len(llm_output)} chars")
        # Remove markdown code blocks (```json ... ``` or ``` ... ```)
        llm_output = re.sub(r'```json\s*', '', llm_output)
        llm_output = re.sub(r'```\s*', '', llm_output)
        
        # Remove common LLM prefixes
        llm_output = re.sub(r'^(here is|here\'s|the json is|json:)\s*', '', llm_output, flags=re.IGNORECASE)
        
        # Strip whitespace
        llm_output = llm_output.strip()
        
        # Find the first { or [ and last } or ] to extract just the JSON
        start_idx = -1
        end_idx = -1
        
        for i, char in enumerate(llm_output):
            if char in '{[':
                start_idx = i
                break
        
        for i in range(len(llm_output) - 1, -1, -1):
            if llm_output[i] in '}]':
                end_idx = i + 1
                break
        
        if start_idx != -1 and end_idx != -1 and start_idx < end_idx:
            llm_output = llm_output[start_idx:end_idx]
            logger.debug(f"Cleaned JSON output: {len(llm_output)} chars")
        
        return llm_output
