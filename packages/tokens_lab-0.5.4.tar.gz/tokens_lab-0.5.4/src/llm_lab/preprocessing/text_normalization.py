"""Text normalization helpers."""

from __future__ import annotations

import re


def normalize_text(text: str) -> str:
    """Normalize text by cleaning whitespace and line breaks.
    
    Args:
        text: Input text.
        
    Returns:
        Normalized text.
        
    Raises:
        TypeError: If text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError("text must be str")
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = "\n".join(line.strip() for line in text.splitlines())
    return text.strip()
