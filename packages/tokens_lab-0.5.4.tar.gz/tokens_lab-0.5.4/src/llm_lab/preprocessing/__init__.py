"""Text preprocessing utilities."""

from __future__ import annotations

from .text_normalization import normalize_text

__all__ = ["normalize_text"]
