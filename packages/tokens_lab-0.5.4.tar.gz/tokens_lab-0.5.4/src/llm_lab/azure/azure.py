"""Azure service client base class."""

from typing import Optional
from azure.storage.blob import BlobServiceClient

class Azure:
    """Base class for Azure service integration.
    
    Args:
        conn_string: Azure connection string.
        account_name: Optional storage account name.
        account_key: Optional storage account key.
    """
    
    def __init__(self, conn_string: Optional[str], account_name: Optional[str] = None, account_key: Optional[str] = None) -> None:
        self.conn_string = conn_string
        self.account_name = account_name
        self.account_key = account_key
        self.blob_service_client = self.get_blob_service_client()

    def get_blob_service_client(self) -> Optional[BlobServiceClient]:
        """Create Azure Blob Service Client.
        
        Returns:
            BlobServiceClient or None if not configured.
        """
        try:
            if self.conn_string:
                return BlobServiceClient.from_connection_string(self.conn_string)
            
            if self.account_name and self.account_key:
                account_url = f"https://{self.account_name}.blob.core.windows.net"
                return BlobServiceClient(account_url=account_url, credential=self.account_key)
            
            return None
        except Exception as e:
            return None