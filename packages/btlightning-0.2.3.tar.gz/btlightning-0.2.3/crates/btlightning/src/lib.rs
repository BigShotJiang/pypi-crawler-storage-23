#![doc = include_str!("../README.md")]

pub mod client;
pub mod error;
#[cfg(feature = "subtensor")]
pub mod metagraph;
pub(crate) mod registry;
pub mod server;
pub mod signing;
pub mod types;
pub mod util;

pub use client::{
    LightningClient, LightningClientConfig, LightningClientConfigBuilder, StreamingResponse,
};
pub use error::{LightningError, Result};
#[cfg(feature = "subtensor")]
pub use metagraph::{
    is_valid_ip, Metagraph, MetagraphMonitorConfig, NeuronInfo, FINNEY_ENDPOINT, TESTNET_ENDPOINT,
};
pub use server::{
    typed_async_handler, typed_handler, AsyncSynapseHandler, LightningServer,
    LightningServerConfig, LightningServerConfigBuilder, StreamingSynapseHandler, SynapseHandler,
    ValidatorPermitResolver,
};
#[cfg(feature = "btwallet")]
pub use signing::BtWalletSigner;
pub use signing::{CallbackSigner, Signer, Sr25519Signer};
pub use types::{
    parse_frame_header, HandshakeRequest, HandshakeResponse, MessageType, PeerAddr, QuicAxonInfo,
    QuicRequest, QuicResponse, SynapsePacket, SynapseResponse, DEFAULT_MAX_FRAME_PAYLOAD,
};
