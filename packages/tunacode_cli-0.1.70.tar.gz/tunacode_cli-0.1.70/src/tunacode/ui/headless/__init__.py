"""Headless mode utilities."""

from tunacode.ui.headless.output import resolve_output

__all__ = ["resolve_output"]
