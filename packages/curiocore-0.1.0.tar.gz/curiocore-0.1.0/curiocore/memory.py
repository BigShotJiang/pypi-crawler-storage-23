"""CurioClaw memory management.

JSONL-based persistent storage with rolling compression.
Zero external dependencies — uses stdlib json for serialization.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any

from curiocore.types import MemoryEntry


class MemoryStore:
    """JSONL-backed memory store with rolling compression support."""

    def __init__(self, filepath: str = "curiosity_memory.jsonl") -> None:
        self._filepath = Path(filepath)
        self._ensure_file()

    def _ensure_file(self) -> None:
        """Create the memory file if it doesn't exist."""
        if not self._filepath.exists():
            self._filepath.parent.mkdir(parents=True, exist_ok=True)
            self._filepath.touch()

    @property
    def filepath(self) -> Path:
        return self._filepath

    # ── Write operations ──────────────────────────────────

    def append(self, entry: MemoryEntry) -> None:
        """Append a single entry to the memory file."""
        with open(self._filepath, "a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(entry), ensure_ascii=False) + "\n")

    def append_raw(self, data: dict[str, Any]) -> None:
        """Append a raw dict as a memory entry."""
        entry = MemoryEntry(
            entry_type=data.get("entry_type", "unknown"),
            data=data,
        )
        self.append(entry)

    # ── Read operations ───────────────────────────────────

    def read_all(self) -> list[MemoryEntry]:
        """Read all entries from the memory file."""
        entries: list[MemoryEntry] = []
        if not self._filepath.exists():
            return entries
        with open(self._filepath, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    raw = json.loads(line)
                    entries.append(
                        MemoryEntry(
                            id=raw.get("id", ""),
                            entry_type=raw.get("entry_type", ""),
                            data=raw.get("data", {}),
                            timestamp=raw.get("timestamp", ""),
                        )
                    )
                except json.JSONDecodeError:
                    continue
        return entries

    def read_recent(self, n: int = 50) -> list[MemoryEntry]:
        """Read the most recent N entries."""
        all_entries = self.read_all()
        return all_entries[-n:]

    def read_by_type(self, entry_type: str) -> list[MemoryEntry]:
        """Read all entries of a specific type."""
        return [e for e in self.read_all() if e.entry_type == entry_type]

    def count(self) -> int:
        """Count total entries in the memory file."""
        if not self._filepath.exists():
            return 0
        count = 0
        with open(self._filepath, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    count += 1
        return count

    # ── Explored topics ───────────────────────────────────

    def get_explored_topics(self) -> list[str]:
        """Extract a list of previously explored topics."""
        topics: list[str] = []
        for entry in self.read_by_type("exploration"):
            query = entry.data.get("query", "")
            if query:
                topics.append(query)
        return topics

    # ── Compression ───────────────────────────────────────

    def needs_compression(self, threshold: int = 500) -> bool:
        """Check if the memory store needs compression."""
        return self.count() > threshold

    def compress(
        self,
        compressed_summary: dict[str, Any],
        keep_recent: int = 50,
    ) -> int:
        """Replace old entries with a compression summary.

        Keeps the most recent `keep_recent` entries and replaces
        everything else with a single compression entry.

        Args:
            compressed_summary: The LLM-generated compression of old entries.
            keep_recent: Number of recent entries to preserve.

        Returns:
            Number of entries removed.
        """
        all_entries = self.read_all()
        total = len(all_entries)
        if total <= keep_recent:
            return 0

        # Split into old (to compress) and recent (to keep)
        recent = all_entries[-keep_recent:]

        # Create compression entry
        compression_entry = MemoryEntry(
            entry_type="compression",
            data=compressed_summary,
        )

        # Atomic write: write to temp file, then replace
        tmp_path = self._filepath.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(asdict(compression_entry), ensure_ascii=False) + "\n")
            for entry in recent:
                f.write(json.dumps(asdict(entry), ensure_ascii=False) + "\n")

        shutil.move(str(tmp_path), str(self._filepath))
        return total - keep_recent

    def get_entries_for_compression(self, keep_recent: int = 50) -> str:
        """Get old entries formatted as text for the compression prompt."""
        all_entries = self.read_all()
        if len(all_entries) <= keep_recent:
            return ""
        old_entries = all_entries[:-keep_recent]
        lines: list[str] = []
        for entry in old_entries:
            lines.append(
                json.dumps(
                    {"type": entry.entry_type, "data": entry.data},
                    ensure_ascii=False,
                )
            )
        return "\n".join(lines)

    # ── Maintenance ───────────────────────────────────────

    def clear(self) -> None:
        """Clear all entries (destructive!)."""
        with open(self._filepath, "w", encoding="utf-8") as f:
            f.write("")

    def export(self, output_path: str) -> None:
        """Export the memory file to another location."""
        if not self._filepath.exists():
            msg = f"Memory file not found: {self._filepath}"
            raise FileNotFoundError(msg)
        target = Path(output_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(self._filepath), str(target))

    def __len__(self) -> int:
        return self.count()

    def __repr__(self) -> str:
        return f"MemoryStore(filepath={self._filepath!r}, entries={self.count()})"
