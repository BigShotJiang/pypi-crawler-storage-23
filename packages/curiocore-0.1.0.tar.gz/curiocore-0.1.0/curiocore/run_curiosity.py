"""CurioClaw CLI tool — the Agent calls these subcommands via exec / shell.

Subcommands:
    score    — Compute hard metric scores for a signal
    store    — Write an entry to JSONL memory
    compress — Compress old memories (dry-run or with summary)
    status   — Show memory stats and exploration summary
    dedup    — Filter duplicate signals against memory

All operations are pure computation / IO. No LLM calls.
"""

from __future__ import annotations

import argparse
import json
import sys

from curiocore.memory import MemoryStore
from curiocore.scorer import score_signal
from curiocore.signals import deduplicate_signals
from curiocore.types import MemoryEntry


def cmd_score(args: argparse.Namespace) -> None:
    """Compute hard metric scores for a signal."""
    signal = json.loads(args.signal)
    directions = json.loads(args.directions)

    # Load past topics from memory
    store = MemoryStore(args.memory_file)
    past_topics = store.get_explored_topics()

    result = score_signal(signal, past_topics, directions)
    print(json.dumps(result, ensure_ascii=False))


def cmd_store(args: argparse.Namespace) -> None:
    """Write an entry to JSONL memory."""
    data = json.loads(args.data)
    store = MemoryStore(args.memory_file)

    entry = MemoryEntry(entry_type=args.entry_type, data=data)
    store.append(entry)

    print(json.dumps({"status": "ok", "id": entry.id}, ensure_ascii=False))


def cmd_compress(args: argparse.Namespace) -> None:
    """Compress old memories."""
    store = MemoryStore(args.memory_file)

    if args.dry_run:
        # Return old entries as text for the Agent to summarize
        old_text = store.get_entries_for_compression(args.keep_recent)
        if not old_text:
            print(json.dumps({"status": "nothing_to_compress"}))
        else:
            count = store.count()
            keep = min(args.keep_recent, count)
            to_compress = count - keep
            print(
                json.dumps(
                    {
                        "status": "ready",
                        "entries_to_compress": to_compress,
                        "entries_to_keep": keep,
                        "old_entries_text": old_text,
                    },
                    ensure_ascii=False,
                )
            )
    else:
        # Execute compression with Agent-provided summary
        if not args.summary:
            print(
                json.dumps({"error": "Provide --summary JSON for compression"}),
                file=sys.stderr,
            )
            sys.exit(1)

        summary = json.loads(args.summary)
        removed = store.compress(summary, args.keep_recent)
        print(
            json.dumps(
                {"status": "compressed", "entries_removed": removed},
                ensure_ascii=False,
            )
        )


def cmd_status(args: argparse.Namespace) -> None:
    """Show memory stats and exploration summary."""
    store = MemoryStore(args.memory_file)
    total = store.count()
    topics = store.get_explored_topics()
    needs = store.needs_compression(threshold=args.compression_threshold)

    # Count by entry type and find last cycle marker
    type_counts: dict[str, int] = {}
    last_cycle_timestamp = ""
    for entry in store.read_all():
        t = entry.entry_type or "unknown"
        type_counts[t] = type_counts.get(t, 0) + 1
        if t == "cycle_marker" and entry.timestamp > last_cycle_timestamp:
            last_cycle_timestamp = entry.timestamp

    status = {
        "total_entries": total,
        "needs_compression": needs,
        "compression_threshold": args.compression_threshold,
        "entry_types": type_counts,
        "explored_topics_count": len(topics),
        "recent_topics": topics[-10:] if topics else [],
        "last_cycle_timestamp": last_cycle_timestamp or None,
    }
    print(json.dumps(status, ensure_ascii=False, indent=2))


def cmd_dedup(args: argparse.Namespace) -> None:
    """Filter duplicate signals against memory."""
    signals = json.loads(args.signals)
    result = deduplicate_signals(signals, args.memory_file, args.threshold)
    print(json.dumps(result, ensure_ascii=False))


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="CurioClaw — CLI tools for the curiosity engine")
    sub = parser.add_subparsers(dest="command")

    # ── score ─────────────────────────────────────
    score_p = sub.add_parser("score", help="Compute hard metric scores")
    score_p.add_argument("--signal", required=True, help="JSON signal object")
    score_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    score_p.add_argument(
        "--directions",
        default="[]",
        help="JSON array of Direction objects",
    )

    # ── store ─────────────────────────────────────
    store_p = sub.add_parser("store", help="Write entry to JSONL memory")
    store_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    store_p.add_argument(
        "--entry-type",
        required=True,
        help="Entry type: signal, exploration, feedback, compression",
    )
    store_p.add_argument("--data", required=True, help="JSON data object")

    # ── compress ──────────────────────────────────
    compress_p = sub.add_parser("compress", help="Compress old memories")
    compress_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    compress_p.add_argument(
        "--keep-recent",
        type=int,
        default=50,
        help="Number of recent entries to keep",
    )
    compress_p.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be compressed (returns old entries as text)",
    )
    compress_p.add_argument(
        "--summary",
        default="",
        help="JSON compression summary (required unless --dry-run)",
    )

    # ── status ────────────────────────────────────
    status_p = sub.add_parser("status", help="Show memory stats")
    status_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    status_p.add_argument(
        "--compression-threshold",
        type=int,
        default=500,
        help="Entry count threshold for compression",
    )

    # ── dedup ─────────────────────────────────────
    dedup_p = sub.add_parser("dedup", help="Deduplicate signals")
    dedup_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    dedup_p.add_argument("--signals", required=True, help="JSON array of signal objects")
    dedup_p.add_argument(
        "--threshold",
        type=float,
        default=0.7,
        help="Similarity threshold (0-1, default 0.7)",
    )

    args = parser.parse_args()

    commands = {
        "score": cmd_score,
        "store": cmd_store,
        "compress": cmd_compress,
        "status": cmd_status,
        "dedup": cmd_dedup,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
