"""CurioClaw data types.

All core data structures used throughout the curiosity engine.
Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class GovernanceLevel(str, Enum):
    """Three-tier governance model for curiosity exploration."""

    AUTONOMOUS = "autonomous"  # Agent explores freely
    GUIDED = "guided"  # Human sets directions, agent chooses topics
    SUPERVISED = "supervised"  # Agent proposes, human approves


class SignalSource(str, Enum):
    """Where a curiosity signal originated."""

    CONVERSATION = "conversation"  # From agent dialogue history
    WEB_SEARCH = "web_search"  # From web search results
    MANUAL = "manual"  # Manually injected by human


class ExplorationStatus(str, Enum):
    """Lifecycle of an exploration."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class Signal:
    """A raw curiosity signal detected from some source."""

    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    content: str = ""
    source: SignalSource = SignalSource.CONVERSATION
    context: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CuriosityScore:
    """Scoring result for a signal.

    Each dimension has two sub-scores:
    - hard: computed from deterministic metrics (embedding similarity, etc.)
    - soft: LLM-judged semantic assessment
    The final dimension score is a weighted blend of the two.
    """

    signal_id: str = ""

    # Final blended scores (0-1)
    novelty: float = 0.0  # How new is this?
    relevance: float = 0.0  # How relevant to current direction?
    learnability: float = 0.0  # Can we actually learn something?
    composite: float = 0.0  # Weighted combination

    # Hard metric sub-scores (deterministic, computed from data)
    novelty_hard: float = 0.0  # Based on embedding similarity to past topics
    relevance_hard: float = 0.0  # Based on keyword/embedding match to directions
    learnability_hard: float = 0.0  # Based on structural heuristics

    # Soft metric sub-scores (LLM-judged)
    novelty_soft: float = 0.0
    relevance_soft: float = 0.0
    learnability_soft: float = 0.0

    reasoning: str = ""

    def compute_composite(
        self,
        w_novelty: float = 0.4,
        w_relevance: float = 0.35,
        w_learnability: float = 0.25,
    ) -> float:
        """Compute weighted composite score."""
        self.composite = (
            w_novelty * self.novelty
            + w_relevance * self.relevance
            + w_learnability * self.learnability
        )
        return self.composite


@dataclass
class Exploration:
    """A single exploration attempt."""

    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    signal_id: str = ""
    query: str = ""
    findings: str = ""
    status: ExplorationStatus = ExplorationStatus.PENDING
    started_at: str = ""
    completed_at: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Feedback:
    """Human or agent feedback on an exploration."""

    exploration_id: str = ""
    useful: bool = False
    comment: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class Direction:
    """A human-set exploration direction / interest area."""

    topic: str = ""
    description: str = ""
    priority: float = 0.5  # 0-1
    active: bool = True


@dataclass
class MemoryEntry:
    """A single entry in the curiosity memory store."""

    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    entry_type: str = ""  # "signal", "exploration", "feedback", "compression"
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
