"""CurioClaw signal deduplication.

Pure computation — no LLM calls. Compares new signals against past signals
in memory using cosine + Jaccard similarity to filter duplicates.

CLI usage:
    python curiocore/signals.py dedup \\
        --memory-file curiosity_memory.jsonl \\
        --signals '[{"content":"...", "context":"..."}]'
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from curiocore.scorer import (
    _clamp,
    _term_vector,
    _tokenize,
    cosine_similarity,
    jaccard_similarity,
)


def _load_past_signal_texts(memory_file: str) -> list[str]:
    """Load content of past signals from JSONL memory."""
    texts: list[str] = []
    path = Path(memory_file)
    if not path.exists():
        return texts
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if entry.get("entry_type") == "signal":
                    content = entry.get("data", {}).get("content", "")
                    if content:
                        texts.append(content)
            except json.JSONDecodeError:
                continue
    return texts


def is_duplicate(
    signal_text: str,
    past_texts: list[str],
    threshold: float = 0.7,
) -> bool:
    """Check if a signal is a duplicate of any past signal.

    Uses a blend of cosine and Jaccard similarity. If the best match
    exceeds the threshold, the signal is considered a duplicate.
    """
    if not past_texts:
        return False

    signal_tokens = _tokenize(signal_text)
    if not signal_tokens:
        return False

    signal_vec = _term_vector(signal_tokens)
    signal_set = set(signal_tokens)

    for past in past_texts:
        past_tokens = _tokenize(past)
        if not past_tokens:
            continue
        past_vec = _term_vector(past_tokens)
        past_set = set(past_tokens)

        cos_sim = cosine_similarity(signal_vec, past_vec)
        jac_sim = jaccard_similarity(signal_set, past_set)
        combined = _clamp(0.6 * cos_sim + 0.4 * jac_sim)

        if combined >= threshold:
            return True

    return False


def deduplicate_signals(
    signals: list[dict],
    memory_file: str,
    threshold: float = 0.7,
) -> list[dict]:
    """Filter out signals that are duplicates of past signals in memory.

    Args:
        signals: List of signal dicts with at least "content".
        memory_file: Path to the JSONL memory file.
        threshold: Similarity threshold for deduplication (0-1).

    Returns:
        List of signals that are NOT duplicates.
    """
    past_texts = _load_past_signal_texts(memory_file)
    novel: list[dict] = []

    for sig in signals:
        content = sig.get("content", "")
        if not content:
            continue
        if not is_duplicate(content, past_texts, threshold):
            novel.append(sig)
            # Also check against other new signals in this batch
            past_texts.append(content)

    return novel


def main() -> None:
    """CLI entry point for signal deduplication."""
    parser = argparse.ArgumentParser(description="CurioClaw signal dedup")
    sub = parser.add_subparsers(dest="command")

    dedup_p = sub.add_parser("dedup", help="Deduplicate signals against memory")
    dedup_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    dedup_p.add_argument("--signals", required=True, help="JSON array of signal objects")
    dedup_p.add_argument(
        "--threshold",
        type=float,
        default=0.7,
        help="Similarity threshold (0-1, default 0.7)",
    )

    args = parser.parse_args()

    if args.command == "dedup":
        signals = json.loads(args.signals)
        result = deduplicate_signals(signals, args.memory_file, args.threshold)
        print(json.dumps(result, ensure_ascii=False))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
