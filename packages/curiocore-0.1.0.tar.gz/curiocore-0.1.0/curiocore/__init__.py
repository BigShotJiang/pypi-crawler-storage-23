"""CurioClaw — The curiosity engine for AI agents.

Curiosity never rests.

Architecture: SKILL.md tells the Agent how to think and act.
Python scripts handle only deterministic computation (scoring, I/O, dedup).
No LLM calls in any Python module.
"""

from curiocore.config import CurioClawConfig

__version__ = "0.2.0"
__all__ = ["CurioClawConfig"]
