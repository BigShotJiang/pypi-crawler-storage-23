"""CurioClaw curiosity scorer — pure deterministic hard metrics.

Computes novelty, relevance, and learnability using bag-of-words similarity,
Jaccard overlap, and structural heuristics. No LLM calls — the Agent handles
soft scoring and blending via SKILL.md instructions.



CLI usage:
    python curiocore/scorer.py score \\
        --signal '{"content":"...", "context":"..."}' \\
        --memory-file curiosity_memory.jsonl \\
        --directions '[{"topic":"...", "description":"...", "priority":0.8, "active":true}]'
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import Counter

# ──────────────────────────────────────────────────────────
# Text similarity utilities (stdlib only, no numpy)
# ──────────────────────────────────────────────────────────

_STOPWORDS = frozenset(
    [
        "a",
        "an",
        "the",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "shall",
        "should",
        "may",
        "might",
        "can",
        "could",
        "of",
        "in",
        "to",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "about",
        "between",
        "after",
        "before",
        "above",
        "below",
        "and",
        "or",
        "but",
        "not",
        "no",
        "nor",
        "so",
        "yet",
        "both",
        "either",
        "neither",
        "each",
        "every",
        "all",
        "any",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "than",
        "too",
        "very",
        "it",
        "its",
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "him",
        "his",
        "she",
        "her",
        "they",
        "them",
        "their",
        "this",
        "that",
        "these",
        "those",
        "what",
        "which",
        "who",
        "whom",
        "how",
        "when",
        "where",
        "why",
    ]
)


def _tokenize(text: str) -> list[str]:
    """Tokenize text into lowercase words, filtering stopwords."""
    words = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return [w for w in words if w not in _STOPWORDS and len(w) > 1]


def _term_vector(tokens: list[str]) -> Counter[str]:
    """Build a term-frequency vector from tokens."""
    return Counter(tokens)


def cosine_similarity(vec_a: Counter[str], vec_b: Counter[str]) -> float:
    """Compute cosine similarity between two term-frequency vectors.

    Returns a value in [0, 1]. Returns 0.0 if either vector is empty.
    """
    if not vec_a or not vec_b:
        return 0.0

    common_keys = set(vec_a.keys()) & set(vec_b.keys())
    dot_product = sum(vec_a[k] * vec_b[k] for k in common_keys)

    if dot_product == 0:
        return 0.0

    mag_a = math.sqrt(sum(v * v for v in vec_a.values()))
    mag_b = math.sqrt(sum(v * v for v in vec_b.values()))

    if mag_a == 0 or mag_b == 0:
        return 0.0

    return dot_product / (mag_a * mag_b)


def jaccard_similarity(set_a: set[str], set_b: set[str]) -> float:
    """Compute Jaccard similarity between two sets of tokens."""
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamp a value to [lo, hi]."""
    try:
        return max(lo, min(hi, float(value)))
    except (TypeError, ValueError):
        return 0.5


# ──────────────────────────────────────────────────────────
# Hard metric computers
# ──────────────────────────────────────────────────────────


def compute_novelty_hard(
    signal_content: str,
    signal_context: str,
    past_topics: list[str],
) -> float:
    """Compute novelty using bag-of-words embedding distance.

    Uses bag-of-words cosine similarity as a lightweight proxy:
        novelty = 1 - max_similarity_to_any_past_topic

    Familiar signals → low novelty. Unfamiliar → high novelty.
    """
    if not past_topics:
        return 1.0  # Nothing explored yet -> maximum novelty

    signal_text = f"{signal_content} {signal_context}"
    signal_tokens = _tokenize(signal_text)
    if not signal_tokens:
        return 0.5  # Can't evaluate -> neutral

    signal_vec = _term_vector(signal_tokens)

    max_sim = 0.0
    for topic in past_topics:
        topic_vec = _term_vector(_tokenize(topic))
        sim = cosine_similarity(signal_vec, topic_vec)
        max_sim = max(max_sim, sim)

    return 1.0 - max_sim


def compute_relevance_hard(
    signal_content: str,
    signal_context: str,
    directions: list[dict],
) -> float:
    """Compute relevance using keyword match to directions.

    Blends cosine similarity and Jaccard for robustness.
    Weights by each direction's priority.
    """
    if not directions:
        return 0.5  # No directions -> neutral (autonomous mode)

    active_dirs = [d for d in directions if d.get("active", True)]
    if not active_dirs:
        return 0.5

    signal_text = f"{signal_content} {signal_context}"
    signal_tokens = _tokenize(signal_text)
    if not signal_tokens:
        return 0.0

    signal_vec = _term_vector(signal_tokens)
    signal_set = set(signal_tokens)

    best_score = 0.0
    for d in active_dirs:
        dir_text = f"{d.get('topic', '')} {d.get('description', '')}"
        dir_tokens = _tokenize(dir_text)
        dir_vec = _term_vector(dir_tokens)
        dir_set = set(dir_tokens)

        cos_sim = cosine_similarity(signal_vec, dir_vec)
        jac_sim = jaccard_similarity(signal_set, dir_set)
        sim = 0.6 * cos_sim + 0.4 * jac_sim

        priority = float(d.get("priority", 0.5))
        weighted = sim * priority
        best_score = max(best_score, weighted)

    return _clamp(best_score)


def compute_learnability_hard(
    signal_content: str,
    signal_context: str,
) -> float:
    """Compute learnability using structural heuristics.

    Factors:
    1. Specificity: token count (longer = more specific, capped at 10)
    2. Questionness: presence of question markers
    3. Concreteness: numbers, long words, technical terms
    """
    text = f"{signal_content} {signal_context}"
    tokens = _tokenize(text)

    if not tokens:
        return 0.0

    # Factor 1: Specificity
    token_count = len(tokens)
    specificity = min(token_count / 10.0, 1.0)

    # Factor 2: Questionness
    question_markers = {
        "what",
        "how",
        "why",
        "when",
        "where",
        "which",
        "who",
        "difference",
        "compare",
        "versus",
        "vs",
        "between",
    }
    question_tokens = set(tokens) & question_markers
    questionness = min(len(question_tokens) / 2.0, 1.0)

    if "?" in signal_content:
        questionness = max(questionness, 0.8)

    # Factor 3: Concreteness
    has_numbers = any(tok.isdigit() or any(c.isdigit() for c in tok) for tok in tokens)
    has_long_words = sum(1 for t in tokens if len(t) > 6) / max(len(tokens), 1)
    concreteness = 0.3 * float(has_numbers) + 0.7 * min(has_long_words * 2, 1.0)

    score = 0.4 * specificity + 0.35 * questionness + 0.25 * concreteness
    return _clamp(score)


def score_signal(
    signal: dict,
    past_topics: list[str],
    directions: list[dict],
) -> dict:
    """Score a single signal on all hard metrics.

    Args:
        signal: Dict with at least "content" and optionally "context".
        past_topics: List of previously explored topic strings.
        directions: List of direction dicts with topic, description, priority, active.

    Returns:
        Dict with novelty_hard, relevance_hard, learnability_hard.
    """
    content = signal.get("content", "")
    context = signal.get("context", "")

    return {
        "signal_id": signal.get("id", ""),
        "novelty_hard": round(compute_novelty_hard(content, context, past_topics), 4),
        "relevance_hard": round(compute_relevance_hard(content, context, directions), 4),
        "learnability_hard": round(compute_learnability_hard(content, context), 4),
    }


# ──────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────


def _load_past_topics(memory_file: str) -> list[str]:
    """Extract explored topics from a JSONL memory file."""
    from pathlib import Path

    topics: list[str] = []
    path = Path(memory_file)
    if not path.exists():
        return topics
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if entry.get("entry_type") == "exploration":
                    query = entry.get("data", {}).get("query", "")
                    if query:
                        topics.append(query)
            except json.JSONDecodeError:
                continue
    return topics


def main() -> None:
    """CLI entry point for hard metric scoring."""
    parser = argparse.ArgumentParser(description="CurioClaw hard metric scorer")
    sub = parser.add_subparsers(dest="command")

    score_p = sub.add_parser("score", help="Score a signal on hard metrics")
    score_p.add_argument("--signal", required=True, help="JSON signal object")
    score_p.add_argument(
        "--memory-file",
        default="curiosity_memory.jsonl",
        help="Path to JSONL memory file",
    )
    score_p.add_argument("--directions", default="[]", help="JSON array of Direction objects")

    args = parser.parse_args()

    if args.command == "score":
        signal = json.loads(args.signal)
        directions = json.loads(args.directions)
        past_topics = _load_past_topics(args.memory_file)
        result = score_signal(signal, past_topics, directions)
        print(json.dumps(result, ensure_ascii=False))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
