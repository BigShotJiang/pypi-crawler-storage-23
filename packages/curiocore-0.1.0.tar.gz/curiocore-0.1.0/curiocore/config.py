"""CurioClaw configuration management.

Handles engine settings, governance level, and human-set exploration directions.

No LLM configuration — the Agent handles all LLM calls natively.
Python scripts are pure computation; they never call an LLM.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from curiocore.types import Direction, GovernanceLevel


@dataclass
class TriggerConfig:
    """When the curiosity engine fires."""

    mode: str = "heartbeat"  # "heartbeat" or "post_conversation"
    heartbeat_interval_seconds: int = 3600  # Default: 1 hour
    max_explorations_per_cycle: int = 3
    min_score_threshold: float = 0.4


@dataclass
class MemoryConfig:
    """Memory / storage settings."""

    memory_file: str = "curiosity_memory.jsonl"
    max_entries_before_compression: int = 500
    compression_keep_recent: int = 50


@dataclass
class ScoringConfig:
    """Weights and blend parameters for curiosity scoring."""

    novelty_weight: float = 0.4
    relevance_weight: float = 0.35
    learnability_weight: float = 0.25
    hard_weight: float = 0.5  # Blend: 0=pure soft, 1=pure hard


@dataclass
class CurioClawConfig:
    """Top-level configuration for the CurioClaw engine."""

    governance: GovernanceLevel = GovernanceLevel.GUIDED
    directions: list[Direction] = field(default_factory=list)
    trigger: TriggerConfig = field(default_factory=TriggerConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    scoring: ScoringConfig = field(default_factory=ScoringConfig)

    @classmethod
    def default(cls) -> CurioClawConfig:
        """Return a sensible default configuration."""
        return cls(
            governance=GovernanceLevel.GUIDED,
            directions=[
                Direction(
                    topic="AI agents",
                    description="Latest developments in AI agent architectures",
                    priority=0.8,
                ),
            ],
        )
