# OpenClaw Adapter

This adapter connects CurioClaw to the [OpenClaw](https://openclaw.ai) agent framework.

## Files

- `SKILL.md` — OpenClaw Skill format entry point
- `adapter.py` — Integration code (heartbeat + post-conversation triggers)
- `install.md` — Step-by-step installation guide

## Usage

See [install.md](install.md) for detailed instructions.
