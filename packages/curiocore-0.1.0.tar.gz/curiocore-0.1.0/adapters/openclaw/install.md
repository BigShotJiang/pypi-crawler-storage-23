# Installing CurioClaw for OpenClaw

## Prerequisites

- Python 3.10+
- An OpenClaw agent setup
- An API key for Anthropic or any OpenAI-compatible LLM provider

## Installation

```bash
pip install curiocore
```

Or install from source:

```bash
git clone https://github.com/your-org/CurioClaw.git
cd CurioClaw
pip install -e .
```

## Integration

### 1. Create a config

```python
from curiocore import CurioClawConfig
from curiocore.config import LLMConfig
from curiocore.types import Direction

config = CurioClawConfig(
    llm=LLMConfig(
        backend="anthropic",
        model="claude-sonnet-4-20250514",
        api_key="sk-ant-...",
    ),
    directions=[
        Direction(topic="AI safety", description="Latest AI safety research"),
    ],
)
```

### 2. Create the adapter

```python
from adapters.openclaw.adapter import OpenClawAdapter

adapter = OpenClawAdapter(config)
```

### 3. Hook into your agent

```python
# In your OpenClaw agent's post-conversation handler:
def on_conversation_complete(conversation_text: str):
    results = adapter.on_conversation_end(conversation_text)
    for r in results:
        print(f"Explored: {r['signal']}")
        print(f"Findings: {r['findings']}")
```

### 4. (Optional) Start heartbeat

```python
adapter.start_heartbeat()  # Runs in background
# ... later ...
adapter.stop_heartbeat()
```
