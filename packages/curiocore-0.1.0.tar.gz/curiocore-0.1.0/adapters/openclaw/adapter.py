"""CurioClaw adapter for OpenClaw.

Integrates the curiosity engine with OpenClaw's Skill system
and heartbeat mechanism. Two trigger modes:

1. Heartbeat: The adapter hooks into OpenClaw's heartbeat system
   to run curiosity loops at regular intervals.
2. Post-conversation: Call `on_conversation_end()` after each
   agent conversation to trigger reflection.

Usage with OpenClaw:
    from curiocore import CurioClawConfig
    from adapters.openclaw.adapter import OpenClawAdapter

    config = CurioClawConfig.default()
    config.llm.api_key = "sk-..."
    adapter = OpenClawAdapter(config)

    # Hook into heartbeat
    adapter.start_heartbeat()

    # Or trigger after conversation
    results = adapter.on_conversation_end(conversation_text)
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from curiocore.engine import CurioClawEngine

if TYPE_CHECKING:
    from curiocore.config import CurioClawConfig
    from curiocore.signals import LLMCallable, WebSearchCallable

logger = logging.getLogger("curiocore.adapters.openclaw")


class OpenClawAdapter:
    """Adapter that connects CurioClaw to the OpenClaw framework.

    OpenClaw uses a Skill-based architecture where each capability
    is a self-contained unit. This adapter wraps CurioClawEngine
    to expose it as an OpenClaw-compatible component.
    """

    def __init__(
        self,
        config: CurioClawConfig,
        llm_call: LLMCallable | None = None,
        web_search_fn: WebSearchCallable | None = None,
    ) -> None:
        self._config = config
        self._engine = CurioClawEngine(
            config=config,
            llm_call=llm_call,
            web_search_fn=web_search_fn,
        )

    @property
    def engine(self) -> CurioClawEngine:
        """Access the underlying CurioClaw engine."""
        return self._engine

    # ── Trigger: Post-conversation ────────────────────────

    def on_conversation_end(
        self,
        conversation_text: str,
        metadata: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Trigger curiosity loop after an agent conversation ends.

        This is the primary integration point for OpenClaw agents.
        Call this method in your agent's post-conversation hook.

        Args:
            conversation_text: The full conversation transcript.
            metadata: Optional metadata about the conversation.

        Returns:
            List of exploration results.
        """
        logger.info("Post-conversation curiosity trigger fired.")
        results = self._engine.run(conversation_text=conversation_text)

        if metadata:
            logger.debug("Conversation metadata: %s", json.dumps(metadata))

        return results

    # ── Trigger: Heartbeat ────────────────────────────────

    def start_heartbeat(self) -> None:
        """Start periodic curiosity exploration via heartbeat.

        Uses the engine's built-in threading-based heartbeat.
        The interval is configured via `config.trigger.heartbeat_interval_seconds`.
        """
        self._engine.start_heartbeat()

    def stop_heartbeat(self) -> None:
        """Stop the heartbeat."""
        self._engine.stop_heartbeat()

    # ── OpenClaw Skill interface ──────────────────────────

    def as_skill_info(self) -> dict[str, Any]:
        """Return metadata suitable for an OpenClaw SKILL.md entry.

        This can be used to dynamically register CurioClaw as
        an OpenClaw Skill at runtime.
        """
        return {
            "name": "CurioClaw",
            "version": "0.1.0",
            "description": "Curiosity engine — autonomous exploration and learning",
            "triggers": ["heartbeat", "post_conversation"],
            "governance": self._config.governance.value,
            "directions": [
                {"topic": d.topic, "priority": d.priority}
                for d in self._config.directions
                if d.active
            ],
        }

    # ── Feedback passthrough ──────────────────────────────

    def submit_feedback(
        self,
        exploration_id: str,
        useful: bool,
        comment: str = "",
    ) -> None:
        """Submit feedback on an exploration result."""
        self._engine.submit_feedback(exploration_id, useful, comment)

    # ── Status ────────────────────────────────────────────

    def status(self) -> dict[str, Any]:
        """Return current adapter status."""
        return {
            "engine": "CurioClaw",
            "version": "0.1.0",
            "governance": self._config.governance.value,
            "memory_entries": len(self._engine.memory),
            "trigger_mode": self._config.trigger.mode,
            "active_directions": [d.topic for d in self._config.directions if d.active],
            "pending_approvals": len(self._engine.get_pending_approvals()),
        }
