MANDATORY: Execute ALL steps below. Do NOT return HEARTBEAT_OK without completing them.

## CurioClaw Curiosity Check

Step 1 — Run status check:
python -m curiocore.run_curiosity status --memory-file curiosity_memory.jsonl

Step 2 — Evaluate timing:
- If last cycle was more than 10 minutes ago, go to Step 3
- If last cycle was less than 10 minutes ago, return HEARTBEAT_OK

Step 3 — Check user activity:
- If the user's last message was more than 10 minutes ago, go to Step 4
- If the user sent a message less than 10 minutes ago, return HEARTBEAT_OK (do not disturb)

Step 4 — Execute curiosity cycle:
- Read the CurioClaw SKILL.md in your workspace
- Follow Steps 1-7 of the Curiosity Cycle
- Step 7 determines whether to notify the user or return HEARTBEAT_OK

Always run Step 1. Never skip it.
