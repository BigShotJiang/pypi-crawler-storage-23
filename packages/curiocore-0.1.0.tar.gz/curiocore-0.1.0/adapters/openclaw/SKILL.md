# CurioClaw — Curiosity Engine for AI Agents

## What Is This?

CurioClaw gives you — the AI agent — an **intrinsic curiosity drive**.
After conversations or on a regular heartbeat, you reflect on what was said,
detect knowledge gaps, score them, explore the most promising ones via web
search, and record your findings in persistent JSONL memory.

**Architecture principle**: You (the Agent) handle all reasoning and LLM work.
The Python scripts in `curiocore/` handle only deterministic computation
(scoring math, JSONL I/O, deduplication, compression). You call them via
`exec` / shell when you need their outputs.

**Python path**: `python`
**CLI prefix**: `python -m curiocore.run_curiosity`

> **⚠️ Virtual environment users**: If you installed curiocore in a virtual
> environment, replace every occurrence of `python -m curiocore.run_curiosity`
> in this file with the full path to your venv Python binary. For example:
> `/home/youruser/curiocore-venv/bin/python -m curiocore.run_curiosity`
> There are approximately 12 occurrences to replace.
> See [install.md](install.md) Step 3 for details.

---

## When To Trigger

| Trigger | When |
|---------|------|
| **Heartbeat (auto)** | When the Heartbeat wakes you and ≥ 10 minutes have passed since your last curiosity cycle |
| **Post-conversation** | After a substantive conversation ends (3+ turns, not small talk) |
| **Manual** | When the user says "explore", "what's new", or "curiosity check" |

### Heartbeat Auto-Trigger Logic

When the Heartbeat wakes you, **before doing anything else**, run this check:

```bash
python -m curiocore.run_curiosity status \
  --memory-file curiosity_memory.jsonl
```

Read the `last_cycle_timestamp` from the status output.

**Decision rule:**
- If the last curiosity cycle was **more than 10 minutes ago** →
  **run the curiosity cycle** (follow Steps 1–7 below)
- Otherwise → skip this heartbeat

When running via heartbeat, **work silently**: do not output anything to the
user unless the Proactive Notification rule triggers (Step 7 below).

---

## The Curiosity Cycle — Step by Step

### Step 1: PERCEIVE — Detect Curiosity Signals

Reflect on recent conversations and extract **1–5 curiosity signals** —
topics, questions, unknowns, or surprising claims that deserve deeper
exploration.

For each signal, determine:
- **content**: The core topic or question (concise, specific)
- **context**: Why it came up (1 sentence of surrounding context)
- **source**: `"conversation"`, `"web_search"`, or `"manual"`
- **reasoning**: Why this is worth exploring (1 sentence)

**Rules for good signals:**
- Prefer topics aligned with your exploration directions (see Step 0)
- Avoid vague or overly broad signals ("AI is interesting" ✗)
- Avoid pure factual lookups with no depth ("when was Python released" ✗)
- Focus on: knowledge gaps, surprising claims, emerging ideas, contradictions

**After extracting signals**, deduplicate them against past signals:

```bash
python -m curiocore.run_curiosity dedup \
  --memory-file curiosity_memory.jsonl \
  --signals '<JSON array of signals>'
```

This returns the signals that are genuinely new (not duplicates of past ones).

---

### Step 2: SCORE — Evaluate Each Signal

For each surviving signal, you produce **two kinds of scores**:

#### 2a. Hard Metrics (deterministic — computed by Python)

```bash
python -m curiocore.run_curiosity score \
  --signal '<JSON signal object>' \
  --memory-file curiosity_memory.jsonl \
  --directions '<JSON array of Direction objects>'
```

This returns a JSON object with:
- `novelty_hard` (0–1): Cosine similarity to past topics, inverted. High = new.
- `relevance_hard` (0–1): Keyword match to exploration directions.
- `learnability_hard` (0–1): Structural heuristics (specificity, questionness, concreteness).

#### 2b. Soft Scores (your own judgment as an LLM)

For each signal, assess these three dimensions yourself (0.0–1.0):

- **Novelty**: How new or unexplored is this topic relative to past explorations?
  - 1.0 = completely new, never explored
  - 0.0 = already explored in depth
- **Relevance**: How aligned is this with the exploration directions?
  - 1.0 = directly matches a high-priority direction
  - 0.0 = completely unrelated
- **Learnability**: Can we realistically learn something useful by searching?
  - 1.0 = clear path to actionable insight
  - 0.0 = too vague, too broad, or unfalsifiable

Provide brief reasoning for your scores.

#### 2c. Blend Scores

Combine hard and soft scores using **50/50 blend** (configurable):

```
final_novelty     = 0.5 * novelty_hard     + 0.5 * novelty_soft
final_relevance   = 0.5 * relevance_hard   + 0.5 * relevance_soft
final_learnability = 0.5 * learnability_hard + 0.5 * learnability_soft
```

Apply **CERMIC-inspired calibration**: if hard and soft disagree by > 0.3,
apply a small penalty (up to 0.15) to the blended score. This filters noise.

Compute **composite score**:
```
composite = 0.40 * novelty + 0.35 * relevance + 0.25 * learnability
```

#### 2d. Rank and Filter

Select the top signals (up to `max_explorations_per_cycle`, default 3) with
composite score ≥ `min_score_threshold` (default 0.4).

---

### Step 3: GOVERN — Check Governance Level

```bash
python -m curiocore.run_curiosity status \
  --memory-file curiosity_memory.jsonl
```

| Level | What you do |
|-------|-------------|
| `autonomous` | Proceed to explore without asking |
| `guided` | Follow the configured directions, explore without asking |
| `supervised` | Present the top signals to the user and ask for approval before exploring |

If supervised, format the signals as a clear numbered list with scores and
wait for the user to approve which ones to explore.

**Exception**: When triggered by Heartbeat, always behave as `autonomous` or
`guided` — never interrupt the user to ask for approval. If governance is
`supervised`, downgrade to `guided` for Heartbeat-triggered cycles.

---

### Step 4: EXPLORE — Investigate via Web Search

For each approved signal:

1. **Generate 1–3 focused search queries** (3–8 words each, specific,
   targeting authoritative sources: papers, docs, official blogs)

2. **Execute the searches** using your built-in web search tool

3. **Synthesize findings** into a structured result:
   - **Key finding**: The most important thing learned (1–2 sentences)
   - **Details**: Supporting details and nuances (2–4 sentences)
   - **Open questions**: What remains unknown or worth exploring next
   - **Confidence**: low / medium / high

---

### Step 5: RECORD — Save to Memory

Store each exploration result:

```bash
python -m curiocore.run_curiosity store \
  --memory-file curiosity_memory.jsonl \
  --entry-type exploration \
  --data '<JSON object with signal_id, query, findings, status, etc.>'
```

Also store the original signals:

```bash
python -m curiocore.run_curiosity store \
  --memory-file curiosity_memory.jsonl \
  --entry-type signal \
  --data '<JSON signal object>'
```

Record the cycle itself (for Heartbeat tracking):

```bash
python -m curiocore.run_curiosity store \
  --memory-file curiosity_memory.jsonl \
  --entry-type cycle_marker \
  --data '{"trigger":"heartbeat","signals_count":N,"explorations_count":N}'
```

---

### Step 6: COMPRESS — Maintain Memory Health

Check if compression is needed (the `status` output includes `needs_compression`).

If `needs_compression` is true (> 500 entries by default):

1. Get the old entries:
   ```bash
   python -m curiocore.run_curiosity compress \
     --memory-file curiosity_memory.jsonl \
     --keep-recent 50 \
     --dry-run
   ```

2. The script returns the old entries as text. **You** (the Agent) read them
   and produce a compression summary:
   - Key themes explored
   - Most important findings
   - Patterns in curiosity (what topics keep coming up?)

3. Execute the compression with your summary:
   ```bash
   python -m curiocore.run_curiosity compress \
     --memory-file curiosity_memory.jsonl \
     --keep-recent 50 \
     --summary '<your JSON compression summary>'
   ```

---

### Step 7: NOTIFY — Proactive User Notification

After exploration completes, check whether any findings are **directly
valuable to the user right now**.

**Decision rule**: For each exploration, look at the `composite` score
computed in Step 2c:

- If `composite > 0.7` → **proactively notify the user**
- Otherwise → stay silent (the user can check memory later)

**Notification format** (adapt the wording naturally, do not copy verbatim):

```
💡 I just explored the [topic direction] space in the background and found something you might find interesting:

[1–2 sentence summary of the key finding]

Want me to go into more detail?
```

**Rules for proactive notifications:**
- **At most 1 notification per curiosity cycle.** Pick the single most relevant
  finding. Never spam the user with multiple notifications.
- **During an active conversation**, deliver the notification naturally
  as part of the conversation flow.
- **Respect "don't disturb".** If the user has previously said they don't want
  proactive notifications, remember that preference and stop notifying.
- **Be concise.** The notification is a teaser, not a full report. Let the user
  pull more detail if they want.
- If the user responds with interest ("sure", "go on", "tell me more"), then
  present the full exploration details.
- If the user ignores or dismisses it, record that as negative feedback:
  ```bash
  python -m curiocore.run_curiosity store \
    --memory-file curiosity_memory.jsonl \
    --entry-type feedback \
    --data '{"exploration_id":"...","useful":false,"comment":"user dismissed notification"}'
  ```

---

## Step 0: CONFIGURE — Exploration Directions

Directions are human-set interest areas that guide your curiosity. They are
stored in the config or set by the user.

Each direction has:
- `topic`: The area of interest (e.g. "AI interpretability")
- `description`: More detail on what's interesting about it
- `priority`: 0.0–1.0 (higher = prefer signals matching this)
- `active`: Whether to use this direction

If no directions are set, explore freely (autonomous curiosity).

---

## Output Format

After each **manually triggered** curiosity cycle, present a brief summary:

```
🔍 Curiosity Cycle Complete
━━━━━━━━━━━━━━━━━━━━━━━━━━

Signals detected: 4 (2 new after dedup)
Top signal: "Attention sink tokens in long-context LLMs" (score: 0.82)

Explored:
1. Attention sink tokens — Key finding: Recent work shows first-token
   attention patterns persist across model families...
2. ...

Memory: 127 entries (compression not needed)
```

For **Heartbeat-triggered** cycles, stay silent unless Step 7 (Proactive
Notification) fires.

---

## Available CLI Commands

All commands use the prefix:
```
python -m curiocore.run_curiosity <subcommand>
```

| Command | Purpose |
|---------|---------|
| `score --signal JSON --memory-file PATH [--directions JSON]` | Compute hard metric scores |
| `store --memory-file PATH --entry-type TYPE --data JSON` | Write entry to JSONL |
| `compress --memory-file PATH --keep-recent N [--dry-run] [--summary JSON]` | Compress old memories |
| `status --memory-file PATH` | Show stats, last cycle timestamp, compression status |
| `dedup --memory-file PATH --signals JSON` | Filter out duplicate signals |

---

## File Layout

```
adapters/openclaw/
  SKILL.md          ← This file (Agent instructions)
  HEARTBEAT.md      ← Heartbeat configuration for OpenClaw
  install.md        ← Step-by-step installation guide
  README.md         ← Adapter overview and architecture
curiocore/
  types.py          ← Data types (Signal, CuriosityScore, etc.)
  memory.py         ← JSONL read/write
  config.py         ← Configuration dataclasses
  scorer.py         ← Hard metric computation (cosine sim, Jaccard, learnability)
  signals.py        ← Signal deduplication logic
  run_curiosity.py  ← CLI tool (score, store, compress, status, dedup)
```

**No file in `curiocore/` makes LLM API calls.** All LLM reasoning is done
by you, the Agent, following this SKILL.md.
