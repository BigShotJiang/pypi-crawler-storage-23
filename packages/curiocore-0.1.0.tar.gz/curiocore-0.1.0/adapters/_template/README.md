# Adapter Template

Use this template to build a CurioClaw adapter for a new agent framework.

## Steps

1. Copy this `_template/` directory to `adapters/your_framework/`
2. Rename `TemplateAdapter` to `YourFrameworkAdapter`
3. Implement the integration hooks for your framework
4. Add a `SKILL.md` describing the integration
5. Add a `README.md` with usage instructions
6. Submit a PR with the `adapter_request` template

## Required methods

- `on_conversation_end(text)` — Post-conversation trigger
- `start_heartbeat()` / `stop_heartbeat()` — Periodic trigger

## Optional enhancements

- Custom signal sources specific to your framework
- Framework-native event hooks
- Dashboard / UI integration
