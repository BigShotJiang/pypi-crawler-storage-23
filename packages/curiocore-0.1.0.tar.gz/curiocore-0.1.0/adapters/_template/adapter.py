"""Adapter template for integrating CurioClaw with a new agent framework.

To create an adapter for your framework:
1. Copy this _template/ directory
2. Rename it to your framework name (e.g., adapters/langraph/)
3. Implement the methods below
4. Add a SKILL.md and README.md
5. Submit a PR!
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from curiocore.engine import CurioClawEngine

if TYPE_CHECKING:
    from curiocore.config import CurioClawConfig
    from curiocore.signals import LLMCallable, WebSearchCallable


class TemplateAdapter:
    """Template adapter — copy and customize for your framework."""

    def __init__(
        self,
        config: CurioClawConfig,
        llm_call: LLMCallable | None = None,
        web_search_fn: WebSearchCallable | None = None,
    ) -> None:
        self._engine = CurioClawEngine(
            config=config,
            llm_call=llm_call,
            web_search_fn=web_search_fn,
        )

    def on_conversation_end(self, conversation_text: str) -> list[dict[str, Any]]:
        """Hook: called after a conversation ends."""
        return self._engine.run(conversation_text=conversation_text)

    def start_heartbeat(self) -> None:
        """Hook: start periodic curiosity loops."""
        self._engine.start_heartbeat()

    def stop_heartbeat(self) -> None:
        """Hook: stop periodic curiosity loops."""
        self._engine.stop_heartbeat()
