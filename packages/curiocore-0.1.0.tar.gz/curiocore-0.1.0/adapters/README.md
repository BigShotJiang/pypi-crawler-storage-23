# CurioClaw Adapters

Adapters are thin integration layers that connect the CurioClaw curiosity engine
to specific agent frameworks. The core engine (`curiocore/`) is framework-agnostic;
adapters handle the framework-specific wiring.

## Available adapters

| Adapter | Framework | Status |
|---------|-----------|--------|
| `openclaw/` | [OpenClaw](https://openclaw.ai) | v0.1 ✅ |

## Writing a new adapter

1. Copy `_template/` to a new directory
2. Implement the integration hooks
3. Add documentation
4. Submit a PR using the `adapter_request` issue template

See `_template/README.md` for detailed instructions.
