# Changelog

All notable changes to CurioClaw will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-XX-XX

### Added
- Core curiosity engine with 5-step loop (perceive → score → explore → record → compress)
- Prompt-first design with all templates in `curiocore/prompts.py`
- Dual LLM backend support: Anthropic Messages API and OpenAI-compatible Chat Completions
- Two trigger modes: heartbeat (timer) and post-conversation
- Two signal sources: agent conversation history and web search
- Three-tier governance model: autonomous, guided, supervised
- JSONL-based memory with rolling compression
- Curiosity scoring on three dimensions: novelty, relevance, learnability
- OpenClaw adapter (`adapters/openclaw/`)
- Adapter template for community contributions
- Full test suite
- Comprehensive documentation
