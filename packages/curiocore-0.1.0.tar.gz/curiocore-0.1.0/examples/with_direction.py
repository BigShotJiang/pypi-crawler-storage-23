"""CurioClaw example — human-set exploration directions.

Demonstrates the three governance levels and how directions
influence curiosity scoring.
"""

from __future__ import annotations

import os

from curiocore import CurioClawConfig, CurioClawEngine
from curiocore.config import LLMConfig
from curiocore.types import Direction, GovernanceLevel


def main() -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        print("Set ANTHROPIC_API_KEY to run this example.")
        return

    # ── Example 1: Guided mode (default) ──────────────────
    print("=== Guided Mode ===")
    print("Human sets directions, agent chooses topics.\n")

    config = CurioClawConfig(
        governance=GovernanceLevel.GUIDED,
        llm=LLMConfig(backend="anthropic", api_key=api_key),
        directions=[
            Direction(
                topic="WebAssembly",
                description="WebAssembly beyond the browser: server-side, edge, plugins",
                priority=0.9,
            ),
            Direction(
                topic="database internals",
                description="Novel storage engines, query optimizers, MVCC",
                priority=0.6,
            ),
        ],
    )

    engine = CurioClawEngine(config)
    results = engine.run(
        conversation_text="""
        User: We should look into using WebAssembly for our plugin system.
        Assistant: That's interesting. WASM's sandboxing model would give us
        security isolation, and the component model proposal could let plugins
        compose safely.
        User: What about performance compared to native plugins?
        """
    )
    for r in results:
        print(f"  Explored: {r['signal']} (score={r['score']:.2f})")

    # ── Example 2: Supervised mode ────────────────────────
    print("\n=== Supervised Mode ===")
    print("Agent proposes, human approves.\n")

    config.governance = GovernanceLevel.SUPERVISED
    engine2 = CurioClawEngine(config)
    engine2.run(
        conversation_text="""
        User: I heard SQLite is getting vector search support.
        Assistant: Yes, there are several extensions being developed.
        """
    )

    pending = engine2.get_pending_approvals()
    print(f"  Pending approvals: {len(pending)}")
    for p in pending:
        sig = p["signal"]
        score = p["score"]
        print(f"  - {sig['content']} (score={score['composite']:.2f})")
        print("    [In production, human would approve/reject here]")

    # ── Example 3: Autonomous mode ────────────────────────
    print("\n=== Autonomous Mode ===")
    print("Agent explores freely, no directions.\n")

    auto_config = CurioClawConfig(
        governance=GovernanceLevel.AUTONOMOUS,
        llm=LLMConfig(backend="anthropic", api_key=api_key),
        directions=[],  # No directions — full freedom
    )

    engine3 = CurioClawEngine(auto_config)
    results = engine3.run(
        conversation_text="""
        User: What's the difference between Raft and Paxos?
        Assistant: Both are consensus algorithms. Raft was designed to be
        more understandable than Paxos. The key differences are in leader
        election and log replication approaches.
        """
    )
    for r in results:
        print(f"  Explored: {r['signal']} (score={r['score']:.2f})")


if __name__ == "__main__":
    main()
