"""CurioClaw example — standalone mode.

Demonstrates running CurioClaw completely independently,
without any agent framework. Useful for:
- Testing the curiosity engine
- Running as a standalone research assistant
- Batch processing conversation logs
"""

from __future__ import annotations

import json
import os
import sys

from curiocore import CurioClawConfig, CurioClawEngine
from curiocore.config import LLMConfig
from curiocore.types import Direction


def main() -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        print("Set ANTHROPIC_API_KEY to run this example.")
        return

    config = CurioClawConfig(
        llm=LLMConfig(backend="anthropic", api_key=api_key),
        directions=[
            Direction(
                topic="open source AI",
                description="Open source AI models, tools, and community trends",
                priority=0.8,
            ),
        ],
        enable_web_search=False,  # No web search in standalone
    )

    engine = CurioClawEngine(config)

    # Read conversation from stdin or use a sample
    if not sys.stdin.isatty():
        conversation = sys.stdin.read()
    else:
        conversation = """
        User: Have you seen the new Llama model release?
        Assistant: Yes, Meta released Llama 3.2 with multimodal capabilities.
        The smaller models are particularly interesting for edge deployment.
        User: How does it compare to Mistral's latest?
        Assistant: Both are competitive. Mistral focuses on efficiency and
        the mixture-of-experts architecture, while Llama emphasizes broad
        capability across modalities.
        User: I'm curious about the training data differences.
        """

    print("Processing conversation...")
    results = engine.run(conversation_text=conversation)

    # Output as JSON for piping
    output = {
        "explorations": results,
        "memory_entries": len(engine.memory),
    }
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
