"""CurioClaw example — custom signal sources.

Demonstrates how to inject a custom web search function
so that web-based signal detection actually works.

This example uses a stub. Replace `my_web_search` with
your preferred search provider (SerpAPI, Tavily, etc.).
"""

from __future__ import annotations

import os

from curiocore import CurioClawConfig, CurioClawEngine
from curiocore.config import LLMConfig
from curiocore.types import Direction


def my_web_search(query: str) -> str:
    """Stub web search function.

    Replace this with a real implementation, e.g.:
    - SerpAPI: https://serpapi.com
    - Tavily: https://tavily.com
    - Brave Search API: https://brave.com/search/api/

    The function must accept a query string and return
    a string of search results.
    """
    # Stub: return a fake result for demonstration
    return f"""
    Search results for: {query}

    1. "New Research on Curiosity-Driven Exploration in RL"
       Summary: A new paper from DeepMind explores intrinsic motivation
       as a reward signal for reinforcement learning agents...

    2. "OpenAI Releases Agent Framework Update"
       Summary: The latest update includes improved tool use and
       a new planning module based on Monte Carlo tree search...
    """


def main() -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        print("Set ANTHROPIC_API_KEY to run this example.")
        return

    config = CurioClawConfig(
        llm=LLMConfig(backend="anthropic", api_key=api_key),
        directions=[
            Direction(
                topic="reinforcement learning",
                description="Curiosity and intrinsic motivation in RL",
                priority=0.9,
            ),
            Direction(
                topic="agent frameworks",
                description="New agent framework releases and updates",
                priority=0.7,
            ),
        ],
        enable_web_search=True,
        enable_conversation_signals=False,  # Web-only this time
    )

    engine = CurioClawEngine(
        config=config,
        web_search_fn=my_web_search,
    )

    print("Running web-only curiosity loop...")
    results = engine.run()

    for r in results:
        print(f"\nSignal: {r['signal']}")
        print(f"Score:  {r['score']:.2f}")

    print(f"\nTotal memory entries: {len(engine.memory)}")


if __name__ == "__main__":
    main()
