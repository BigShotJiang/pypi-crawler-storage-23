"""CurioClaw quickstart — minimal example.

Run with:
    ANTHROPIC_API_KEY=sk-... python examples/quickstart.py

Or with OpenAI-compatible backend:
    OPENAI_API_KEY=sk-... python examples/quickstart.py --backend openai
"""

from __future__ import annotations

import argparse
import os

from curiocore import CurioClawConfig, CurioClawEngine
from curiocore.config import LLMConfig
from curiocore.types import Direction


def main() -> None:
    parser = argparse.ArgumentParser(description="CurioClaw quickstart")
    parser.add_argument(
        "--backend",
        default="anthropic",
        choices=["anthropic", "openai"],
        help="LLM backend to use",
    )
    parser.add_argument("--model", default=None, help="Model name override")
    args = parser.parse_args()

    # Resolve API key
    if args.backend == "anthropic":
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        model = args.model or "claude-sonnet-4-20250514"
    else:
        api_key = os.environ.get("OPENAI_API_KEY", "")
        model = args.model or "gpt-4o-mini"

    if not api_key:
        print("Error: Set ANTHROPIC_API_KEY or OPENAI_API_KEY env var.")
        return

    # Configure
    config = CurioClawConfig(
        llm=LLMConfig(
            backend=args.backend,
            model=model,
            api_key=api_key,
        ),
        directions=[
            Direction(
                topic="AI agents",
                description="Latest developments in autonomous AI agent architectures",
                priority=0.9,
            ),
        ],
    )

    # Create engine
    engine = CurioClawEngine(config)

    # Simulate a conversation that just ended
    conversation = """
    User: I've been reading about ReAct agents. How do they compare to
    plan-and-execute architectures?

    Assistant: ReAct combines reasoning and acting in an interleaved loop,
    while plan-and-execute separates planning from execution. ReAct is more
    flexible but can get stuck in loops. Plan-and-execute is more structured
    but less adaptive to unexpected situations.

    User: Interesting. What about the new "tree of thoughts" approach?

    Assistant: Tree of Thoughts extends chain-of-thought by exploring multiple
    reasoning paths simultaneously. It's particularly useful for tasks that
    require backtracking or exploring alternatives. However, it's more
    computationally expensive.

    User: I wonder how these could be combined with curiosity-driven learning.
    """

    # Run one curiosity cycle
    print("Running curiosity loop...")
    print("-" * 50)
    results = engine.run(conversation_text=conversation)

    if not results:
        print("No explorations triggered this cycle.")
    else:
        for i, r in enumerate(results, 1):
            print(f"\nExploration {i}:")
            print(f"  Signal: {r['signal']}")
            print(f"  Score:  {r['score']:.2f}")
            print(f"  Findings: {r['findings'][:300]}...")

    print(f"\nMemory entries: {len(engine.memory)}")


if __name__ == "__main__":
    main()
