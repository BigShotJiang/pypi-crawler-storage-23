# Architecture

## System Overview

```
┌─────────────────────────────────────────────────┐
│                  CurioClaw Engine                │
│                                                  │
│  ┌──────────┐  ┌─────────┐  ┌──────────┐       │
│  │ Signals  │→ │ Scorer  │→ │ Explorer │       │
│  │ Detector │  │         │  │          │       │
│  └──────────┘  └─────────┘  └──────────┘       │
│       ↑                          │              │
│       │         ┌────────┐       │              │
│       └─────────│ Memory │←──────┘              │
│                 │ Store  │                      │
│                 └────────┘                      │
│                      ↑                          │
│                 ┌────────┐                      │
│                 │Prompts │ ← Core IP            │
│                 └────────┘                      │
└──────────────────────┬──────────────────────────┘
                       │
            ┌──────────┴──────────┐
            │                     │
      ┌─────┴──────┐      ┌──────┴─────┐
      │  OpenClaw  │      │  Template  │
      │  Adapter   │      │  Adapter   │
      └────────────┘      └────────────┘
```

## Module Relationships

### Core (`curiocore/`)

- **`engine.py`** — Orchestrates the curiosity loop. Depends on all other core modules.
- **`prompts.py`** — Pure functions that return prompt strings. No dependencies except `types.py`.
- **`signals.py`** — Signal detection. Depends on `prompts.py` and `types.py`.
- **`scorer.py`** — Curiosity scoring. Depends on `prompts.py` and `types.py`.
- **`explorer.py`** — Exploration execution. Depends on `prompts.py` and `types.py`.
- **`memory.py`** — JSONL persistence. Depends on `types.py`.
- **`config.py`** — Configuration dataclasses. Depends on `types.py`.
- **`types.py`** — Base data structures. No internal dependencies.

### Adapters (`adapters/`)

Each adapter wraps `CurioClawEngine` and exposes framework-specific hooks. Adapters are thin — typically under 100 lines of code.

## Data Flow

```
Conversation text ──→ SignalDetector ──→ [Signal, Signal, ...]
                                              │
Web search results ──→ SignalDetector ────────┘
                                              │
                                              ▼
                                     CuriosityScorer
                                              │
                                     [CuriosityScore, ...]
                                              │
                                     (filter by threshold)
                                              │
                                              ▼
                                         Explorer
                                              │
                                     [Exploration, ...]
                                              │
                                              ▼
                                        MemoryStore
                                          (JSONL)
```

## LLM Integration

Two backends, both using stdlib `urllib`:

- **Anthropic**: `POST /v1/messages` with `x-api-key` header
- **OpenAI-compatible**: `POST /v1/chat/completions` with `Bearer` auth

The engine creates an `LLMCallable` (a simple `str → str` function) at startup based on the config. All modules receive this callable — they don't know which backend is in use.

## Storage Format

Memory is stored as newline-delimited JSON (JSONL):

```jsonl
{"id":"abc123","entry_type":"signal","data":{"content":"..."},"timestamp":"..."}
{"id":"def456","entry_type":"score","data":{"novelty":0.8,...},"timestamp":"..."}
{"id":"ghi789","entry_type":"exploration","data":{"findings":"..."},"timestamp":"..."}
```

Each line is a self-contained JSON object. This format is append-only friendly, human-readable, and easy to process with standard tools (`jq`, `grep`, etc.).
