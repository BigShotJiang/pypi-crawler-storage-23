# CurioClaw Documentation

Welcome to the CurioClaw docs. Start here and follow the links.

## For Users

- [How It Works](how-it-works.md) — Understand the curiosity loop
- [FAQ](faq.md) — Common questions

## For Developers

- [Architecture](architecture.md) — System design, data flow, module relationships
- [Curiosity Scoring](curiosity-scoring.md) — How signals are scored
- [Governance](governance.md) — Three-tier control model
- [Memory Compression](memory-compression.md) — How memory stays lean
- [Prompt Design](prompt-design.md) — The core competitive advantage

## Other Languages

- [Chinese (Simplified)](i18n/README.zh-CN.md)
