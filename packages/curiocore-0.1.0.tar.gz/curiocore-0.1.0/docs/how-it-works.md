# How CurioClaw Works

CurioClaw implements a **curiosity loop** — a repeating cycle that gives AI agents the ability to autonomously discover and explore topics of interest.

## The Curiosity Loop

Every cycle runs five steps:

### 1. Perceive

The engine scans for **curiosity signals** — topics, questions, unknowns, or surprising claims that deserve exploration. Two signal sources are supported in v0.1:

- **Conversation history**: After an agent conversation ends, the engine reflects on the dialogue and extracts interesting threads.
- **Web search**: The engine proactively searches the web based on configured exploration directions and identifies emerging or surprising topics.

Signal detection is entirely LLM-driven. The prompts in `curiocore/prompts.py` determine what the engine finds interesting.

### 2. Score

Each detected signal is scored on three dimensions:

- **Novelty** (0–1): How new or unexplored is this topic? Signals about previously explored topics score lower.
- **Relevance** (0–1): How aligned is this with the human-set exploration directions? Signals matching high-priority directions score higher.
- **Learnability** (0–1): Can we realistically learn something useful? Vague or unfalsifiable topics score lower.

The three scores are combined into a weighted composite score. Only signals above a configurable threshold proceed to exploration.

### 3. Explore

For each selected signal, the engine:
1. Generates focused web search queries using the LLM
2. Executes the searches
3. Synthesizes the results into a concise finding with key insights, details, open questions, and confidence level

### 4. Record

Everything is saved to a JSONL memory file: the original signal, its score, and the exploration findings. This creates a persistent knowledge trail that grows over time.

### 5. Compress

When the memory file grows beyond a threshold, old entries are compressed into a summary. The most recent entries are preserved, and everything else is replaced by a single compression entry. This keeps memory lean without losing important patterns.

## Trigger Modes

The curiosity loop can be triggered in two ways:

- **Post-conversation**: Call `engine.run(conversation_text=...)` after each agent conversation. Best for interactive agents.
- **Heartbeat**: Call `engine.start_heartbeat()` to run the loop on a timer in a background thread. Best for long-running agents or research bots.

## What Makes It Different

CurioClaw is not a RAG system, not a knowledge graph, and not a memory layer. It's an **intrinsic motivation system** — the AI equivalent of curiosity. The key insight is that the quality of curiosity is determined by the quality of the prompts, not by the code logic. That's why the project is prompt-first.
