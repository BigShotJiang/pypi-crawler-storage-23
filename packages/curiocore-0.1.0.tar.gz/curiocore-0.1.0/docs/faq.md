# FAQ

## General

**Q: What is CurioClaw?**
A: An independent curiosity engine for AI agents. It gives agents the ability to autonomously discover, evaluate, and explore topics of interest.

**Q: Is it a RAG system?**
A: No. RAG retrieves information to answer a specific question. CurioClaw generates questions and explores them proactively.

**Q: Does it require an agent framework?**
A: No. CurioClaw can run standalone. Adapters are optional integrations for specific frameworks.

## Technical

**Q: What LLM providers are supported?**
A: Anthropic (Claude) and any OpenAI-compatible API (OpenAI, Ollama, vLLM, Together, etc.).

**Q: Are there any external dependencies?**
A: No. CurioClaw uses Python stdlib only. The dev dependencies (pytest, ruff) are for development only.

**Q: How is data stored?**
A: JSONL (newline-delimited JSON) files. One JSON object per line. Human-readable and easy to process with standard tools.

**Q: How does memory compression work?**
A: When the memory file exceeds a threshold, old entries are summarized by the LLM and replaced by a single compression entry. Recent entries are preserved.

## Usage

**Q: How do I add a web search function?**
A: Pass a `web_search_fn` to the engine constructor. It must accept a query string and return a string of results. See `examples/custom_sources.py`.

**Q: Can I use it with Ollama / local models?**
A: Yes. Set `backend="openai"` and `base_url="http://localhost:11434"` with the appropriate model name.

**Q: How do I control what the engine explores?**
A: Use the governance model. Set directions for `guided` mode, or use `supervised` mode for full human control. See [governance.md](governance.md).
