# Prompt Design

## Philosophy

CurioClaw is a **prompt-first** project. The engine's intelligence — what it finds interesting, how it scores signals, how it synthesizes findings — lives entirely in the prompts. The Python code is plumbing; the prompts are the product.

This means:
- Improving CurioClaw usually means improving prompts, not code
- The prompts are the core intellectual property
- Contributors who improve prompts have the highest impact

## Design Principles

### 1. Structured Output

Every prompt requests a specific JSON format. This makes parsing reliable and keeps the engine deterministic. All prompts include the exact JSON schema the LLM should return.

### 2. Role Assignment

Each prompt begins with a clear role: "You are a curiosity signal detector", "You are a curiosity scoring engine", etc. This grounds the LLM's behavior.

### 3. Context Injection

Prompts use XML-style tags (`<exploration_directions>`, `<conversation>`, etc.) to clearly delimit injected context. This reduces prompt injection risk and helps the LLM distinguish instructions from data.

### 4. Explicit Rules

Each prompt ends with a "Rules" section that constrains the output. These rules are discovered through iteration — each one addresses a failure mode we observed.

### 5. Minimal Ambiguity

Scoring prompts define what 0.0 and 1.0 mean for each dimension. Synthesis prompts specify the exact structure of findings. This reduces variance in LLM outputs.

## Prompt Inventory

| Prompt | File Location | Purpose |
|--------|--------------|---------|
| `signal_extraction_prompt` | `prompts.py` | Extract curiosity signals from conversations |
| `web_search_signal_prompt` | `prompts.py` | Extract signals from web search results |
| `scoring_prompt` | `prompts.py` | Score signals on novelty/relevance/learnability |
| `exploration_query_prompt` | `prompts.py` | Generate web search queries |
| `synthesis_prompt` | `prompts.py` | Synthesize search results into findings |
| `compression_prompt` | `prompts.py` | Compress old memory entries |

## Contributing Prompt Improvements

1. Identify a failure mode (e.g., "signals are too vague")
2. Create a test case that reproduces it
3. Modify the relevant prompt
4. Verify the fix with the test case
5. Check that existing tests still pass
6. Submit a PR with before/after examples

## Tips

- Keep prompts under 1000 tokens of instruction (excluding injected context)
- Use concrete examples in rules when possible
- Test with both Anthropic and OpenAI backends — they respond differently
- Watch for JSON parsing failures in logs — they often indicate prompt issues
