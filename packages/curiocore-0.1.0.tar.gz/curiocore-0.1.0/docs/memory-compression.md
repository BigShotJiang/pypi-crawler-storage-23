# Memory Compression

## Why Compress?

CurioClaw records every signal, score, and exploration to a JSONL file. Over hundreds of cycles, this file grows large. Compression keeps it manageable while preserving the most important patterns.

## How It Works

When the memory file exceeds a threshold (default: 500 entries), the engine triggers compression:

1. The most recent N entries (default: 50) are preserved as-is
2. All older entries are fed to the LLM via the compression prompt
3. The LLM produces a structured summary capturing key themes, top findings, and patterns
4. The old entries are replaced by a single "compression" entry containing the summary
5. The write is atomic (temp file + rename) to prevent data loss

## What Gets Preserved

The compression prompt asks the LLM to capture:

- **Key themes** explored over time
- **Most important findings** from explorations
- **Curiosity patterns** — what topics keep coming up?
- **Feedback patterns** — what was useful vs. not?

## Configuration

```python
from curiocore.config import MemoryConfig

memory_config = MemoryConfig(
    memory_file="curiosity_memory.jsonl",
    max_entries_before_compression=500,
    compression_keep_recent=50,
)
```

## Manual Operations

```python
# Export memory to a backup
engine.memory.export("backup.jsonl")

# Check if compression is needed
engine.memory.needs_compression(threshold=500)

# Clear all memory (destructive!)
engine.memory.clear()
```

## Format

After compression, the memory file looks like:

```jsonl
{"id":"...","entry_type":"compression","data":{"summary":"...","key_themes":[...],...},"timestamp":"..."}
{"id":"...","entry_type":"signal","data":{...},"timestamp":"..."}
{"id":"...","entry_type":"exploration","data":{...},"timestamp":"..."}
... (50 most recent entries)
```
