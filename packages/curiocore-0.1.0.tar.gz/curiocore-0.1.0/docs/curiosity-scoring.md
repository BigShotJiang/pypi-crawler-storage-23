# Curiosity Scoring

## Overview

Every curiosity signal is scored on three dimensions before the engine decides whether to explore it. This prevents the engine from chasing noise or rehashing old topics.

## Dimensions

### Novelty (weight: 0.40)

How new or unexplored is this topic relative to the agent's memory?

- **1.0** — Completely new concept, never encountered before
- **0.5** — Somewhat familiar but with new angles
- **0.0** — Already explored in depth, appears in memory

The scorer checks the signal against the list of previously explored topics stored in memory.

### Relevance (weight: 0.35)

How aligned is this signal with the human-set exploration directions?

- **1.0** — Directly matches a high-priority active direction
- **0.5** — Tangentially related to a direction
- **0.0** — Completely unrelated to any direction

In `autonomous` governance mode with no directions set, relevance is scored based on general interestingness.

### Learnability (weight: 0.25)

Can we realistically learn something useful by exploring this topic?

- **1.0** — Clear, specific question with likely findable answers
- **0.5** — Broad topic that could yield some insights
- **0.0** — Too vague, too philosophical, or unfalsifiable

## Composite Score

The composite score is a weighted sum:

```
composite = 0.40 × novelty + 0.35 × relevance + 0.25 × learnability
```

Weights are configurable via `CurioClawConfig.scoring`.

## Threshold

Only signals with a composite score above the threshold (default: 0.40) proceed to exploration. The threshold is configurable via `CurioClawConfig.trigger.min_score_threshold`.

## Scoring Process

Scoring is LLM-driven. The prompt in `curiocore/prompts.py::scoring_prompt()` presents the signal, the exploration directions, and the list of past topics, then asks the LLM to rate each dimension with reasoning.

This means scoring quality improves as the prompts improve — no code changes needed.
