# 🦀 CurioClaw

**AI Agent 的好奇心引擎。**

*好奇心，永不停歇。*

---

## 解决什么问题？

AI Agent 是**被动的**。它们等待指令、执行任务、然后停下。
它们从不会想"我还应该了解什么？"或"昨天有什么变化？"

CurioClaw 给 Agent 一个**内在的探索驱动力**。它不是技能、不是插件、不是框架扩展——
它是一个独立的好奇心引擎，让 Agent 主动学习和进化。

## 工作原理

CurioClaw 运行一个 5 步**好奇心循环**：

1. **感知** — 从对话和网页搜索中检测好奇信号
2. **打分** — 评估新颖性、相关性、可学习性
3. **探索** — 通过网页搜索调查高分信号
4. **记录** — 将发现保存到 JSONL 记忆文件
5. **压缩** — 定期压缩旧记忆

## 快速开始

```bash
pip install curiocore
```

```python
from curiocore import CurioClawConfig, CurioClawEngine
from curiocore.config import LLMConfig
from curiocore.types import Direction

config = CurioClawConfig(
    llm=LLMConfig(backend="anthropic", api_key="sk-ant-..."),
    directions=[
        Direction(topic="AI agents", description="最新的 Agent 架构发展"),
    ],
)

engine = CurioClawEngine(config)
results = engine.run(conversation_text="用户: ReAct 是怎么工作的？...")
```

## 特性

- **零外部依赖** — 仅使用 Python 标准库
- **Prompt-first 设计** — 智能在 prompt 里，不在代码逻辑里
- **双 LLM 后端** — 支持 Anthropic 和 OpenAI 兼容接口
- **三级治理** — 自主、引导、监督三种模式

## 文档

完整文档请参阅 [docs/](../README.md)。

## 许可

[MIT](../../LICENSE)
