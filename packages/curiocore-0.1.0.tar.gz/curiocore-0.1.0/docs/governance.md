# Governance Model

CurioClaw implements a three-tier governance model that controls how much autonomy the curiosity engine has.

## Levels

### Autonomous

The engine explores freely with no human oversight. Signals are detected, scored, and explored automatically. Best for background research bots or experimental setups.

```python
config = CurioClawConfig(governance=GovernanceLevel.AUTONOMOUS)
```

### Guided (default)

The human sets exploration **directions** — broad topic areas with priorities. The engine detects and scores signals within (and outside) these directions, but the directions influence what gets explored.

```python
config = CurioClawConfig(
    governance=GovernanceLevel.GUIDED,
    directions=[
        Direction(topic="quantum computing", description="...", priority=0.9),
        Direction(topic="biotech", description="...", priority=0.6),
    ],
)
```

### Supervised

The engine detects and scores signals, but does **not** explore them automatically. Instead, signals are queued for human approval. The human reviews each proposal and explicitly approves or rejects it.

```python
config = CurioClawConfig(governance=GovernanceLevel.SUPERVISED)
engine = CurioClawEngine(config)

# Signals are queued, not explored
engine.run(conversation_text="...")

# Human reviews
for item in engine.get_pending_approvals():
    print(item["signal"]["content"], item["score"]["composite"])

# Human approves
engine.approve(signal_id="abc123")

# Or rejects
engine.reject(signal_id="def456")
```

## Choosing a Level

- Use **autonomous** when you trust the engine and want hands-off operation
- Use **guided** (recommended) when you want to steer the engine's curiosity
- Use **supervised** in production systems where unexpected explorations could be costly

## Directions

Directions are the primary steering mechanism in `guided` mode. Each direction has:

- **topic**: A short label (e.g., "AI safety")
- **description**: What to look for in this area
- **priority**: 0.0–1.0, influences scoring relevance
- **active**: Boolean, can be toggled on/off

Multiple directions can coexist. The engine balances exploration across them based on priority.
