---
name: Bug Report
about: Report a bug in CurioClaw
title: "[BUG] "
labels: bug
---

## Description

A clear description of the bug.

## Steps to Reproduce

1. ...
2. ...
3. ...

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened.

## Environment

- Python version:
- CurioClaw version:
- LLM backend (anthropic/openai):
- OS:

## Logs

```
Paste relevant logs here
```
