---
name: Adapter Request
about: Request or propose an adapter for a new agent framework
title: "[ADAPTER] "
labels: adapter
---

## Framework

Name and link to the agent framework.

## Why?

Why would CurioClaw + this framework be useful?

## Integration Points

How would the adapter hook into the framework?
- Heartbeat / scheduler mechanism:
- Conversation end hook:
- Other:

## Willing to Contribute?

- [ ] I'm willing to build this adapter
- [ ] I can help test it
- [ ] I'm just requesting it
