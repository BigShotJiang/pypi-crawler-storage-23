---
name: Feature Request
about: Suggest a new feature for CurioClaw
title: "[FEATURE] "
labels: enhancement
---

## Problem

What problem does this feature solve?

## Proposed Solution

How should it work?

## Alternatives Considered

What other approaches did you consider?

## Additional Context

Any other information that would help.
