## What does this PR do?

Brief description of the change.

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Prompt improvement
- [ ] New adapter
- [ ] Documentation
- [ ] Other

## Checklist

- [ ] Tests pass (`pytest`)
- [ ] Linter passes (`ruff check .`)
- [ ] Documentation updated (if applicable)
- [ ] CHANGELOG.md updated

## Related Issues

Closes #
