"""Tests for curiocore.signals — signal deduplication."""

from __future__ import annotations

from curiocore.memory import MemoryStore
from curiocore.signals import deduplicate_signals, is_duplicate
from curiocore.types import MemoryEntry


class TestIsDuplicate:
    def test_no_past(self):
        assert not is_duplicate("quantum computing", [])

    def test_exact_match(self):
        assert is_duplicate(
            "attention mechanisms in transformers",
            ["attention mechanisms in transformers"],
        )

    def test_near_match(self):
        # combo similarity ~0.50; use a lower threshold
        assert is_duplicate(
            "attention mechanisms in transformer models",
            ["attention mechanisms in transformers"],
            threshold=0.45,
        )

    def test_unrelated(self):
        assert not is_duplicate(
            "quantum error correction",
            ["medieval cooking recipes", "dog training tips"],
        )

    def test_empty_signal(self):
        assert not is_duplicate("", ["something"])

    def test_high_threshold_rejects(self):
        # With a very high threshold, even similar things don't match
        assert not is_duplicate(
            "deep learning optimization",
            ["machine learning optimization"],
            threshold=0.95,
        )


class TestDeduplicateSignals:
    def test_all_novel(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signals = [
            {"content": "quantum computing"},
            {"content": "marine biology"},
        ]
        result = deduplicate_signals(signals, str(mem))
        assert len(result) == 2

    def test_filters_known(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        store.append(
            MemoryEntry(
                entry_type="signal",
                data={"content": "RLHF reward modeling techniques"},
            )
        )

        signals = [
            {"content": "RLHF reward modeling techniques overview"},
            {"content": "quantum error correction codes"},
        ]
        result = deduplicate_signals(signals, str(mem), threshold=0.6)
        assert len(result) == 1
        assert "quantum" in result[0]["content"]

    def test_within_batch_dedup(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signals = [
            {"content": "RLHF reward modeling techniques"},
            {"content": "RLHF reward modeling approaches"},
        ]
        # combo ~0.69, so threshold=0.65 catches it
        result = deduplicate_signals(signals, str(mem), threshold=0.65)
        assert len(result) == 1

    def test_empty_content_skipped(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signals = [{"content": ""}, {"content": "real signal"}]
        result = deduplicate_signals(signals, str(mem))
        assert len(result) == 1
        assert result[0]["content"] == "real signal"

    def test_empty_signals(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        assert deduplicate_signals([], str(mem)) == []

    def test_custom_threshold(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        store.append(
            MemoryEntry(
                entry_type="signal",
                data={"content": "deep learning optimization methods"},
            )
        )
        signals = [{"content": "deep learning training optimization"}]

        # Low threshold: more aggressive dedup
        strict = deduplicate_signals(signals, str(mem), threshold=0.3)
        assert len(strict) == 0

        # High threshold: more permissive
        loose = deduplicate_signals(signals, str(mem), threshold=0.95)
        assert len(loose) == 1
