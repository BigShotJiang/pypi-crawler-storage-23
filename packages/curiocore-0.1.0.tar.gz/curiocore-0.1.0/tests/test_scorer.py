"""Tests for curiocore.scorer — pure hard metric computation."""

from __future__ import annotations

from collections import Counter

import pytest

from curiocore.scorer import (
    _clamp,
    _tokenize,
    compute_learnability_hard,
    compute_novelty_hard,
    compute_relevance_hard,
    cosine_similarity,
    jaccard_similarity,
    score_signal,
)

# ── Tokenizer ─────────────────────────────────────────────


class TestTokenize:
    def test_basic(self):
        tokens = _tokenize("How does RLHF work in LLMs?")
        assert "rlhf" in tokens
        assert "llms" in tokens
        # stopwords removed
        assert "how" not in tokens
        assert "does" not in tokens
        assert "in" not in tokens

    def test_empty(self):
        assert _tokenize("") == []

    def test_single_char_filtered(self):
        tokens = _tokenize("I a x go")
        # "i", "a", "x" are single char or stopwords
        assert "go" in tokens

    def test_numbers_preserved(self):
        tokens = _tokenize("GPT4 has 175B parameters")
        assert "gpt4" in tokens
        assert "175b" in tokens


# ── Cosine Similarity ─────────────────────────────────────


class TestCosineSimilarity:
    def test_identical(self):
        v = Counter({"hello": 2, "world": 1})
        assert cosine_similarity(v, v) == pytest.approx(1.0)

    def test_disjoint(self):
        a = Counter({"hello": 1})
        b = Counter({"world": 1})
        assert cosine_similarity(a, b) == 0.0

    def test_empty(self):
        assert cosine_similarity(Counter(), Counter({"a": 1})) == 0.0
        assert cosine_similarity(Counter(), Counter()) == 0.0

    def test_partial_overlap(self):
        a = Counter({"ai": 2, "ml": 1, "deep": 1})
        b = Counter({"ai": 1, "ml": 1, "bio": 1})
        sim = cosine_similarity(a, b)
        assert 0.0 < sim < 1.0


# ── Jaccard Similarity ────────────────────────────────────


class TestJaccardSimilarity:
    def test_identical(self):
        s = {"a", "b", "c"}
        assert jaccard_similarity(s, s) == 1.0

    def test_disjoint(self):
        assert jaccard_similarity({"a"}, {"b"}) == 0.0

    def test_empty(self):
        assert jaccard_similarity(set(), {"a"}) == 0.0

    def test_partial(self):
        sim = jaccard_similarity({"a", "b", "c"}, {"b", "c", "d"})
        # intersection=2, union=4
        assert sim == pytest.approx(0.5)


# ── Clamp ─────────────────────────────────────────────────


class TestClamp:
    def test_in_range(self):
        assert _clamp(0.5) == 0.5

    def test_below(self):
        assert _clamp(-0.3) == 0.0

    def test_above(self):
        assert _clamp(1.5) == 1.0

    def test_invalid(self):
        assert _clamp("not_a_number") == 0.5


# ── Novelty Hard ──────────────────────────────────────────


class TestNoveltyHard:
    def test_no_past_topics(self):
        score = compute_novelty_hard("quantum computing", "", [])
        assert score == 1.0

    def test_identical_topic(self):
        score = compute_novelty_hard(
            "quantum computing applications",
            "",
            ["quantum computing applications"],
        )
        assert score < 0.3  # Very low novelty

    def test_unrelated_topic(self):
        score = compute_novelty_hard("quantum computing", "", ["medieval cooking recipes"])
        assert score > 0.7  # High novelty

    def test_empty_signal(self):
        score = compute_novelty_hard("", "", ["something"])
        assert score == 0.5  # Neutral


# ── Relevance Hard ────────────────────────────────────────


class TestRelevanceHard:
    def test_no_directions(self):
        score = compute_relevance_hard("anything", "", [])
        assert score == 0.5

    def test_matching_direction(self):
        dirs = [
            {
                "topic": "AI interpretability",
                "description": "Understanding transformer internals",
                "priority": 0.9,
                "active": True,
            }
        ]
        score = compute_relevance_hard("transformer attention interpretability", "", dirs)
        assert score > 0.2

    def test_unrelated_direction(self):
        dirs = [
            {
                "topic": "marine biology",
                "description": "Deep sea organisms",
                "priority": 0.8,
                "active": True,
            }
        ]
        score = compute_relevance_hard("quantum computing algorithms", "", dirs)
        assert score < 0.3

    def test_inactive_directions_ignored(self):
        dirs = [
            {
                "topic": "AI agents",
                "description": "Agent architectures",
                "priority": 1.0,
                "active": False,
            }
        ]
        score = compute_relevance_hard("AI agents", "", dirs)
        assert score == 0.5  # Falls through to no-active default


# ── Learnability Hard ─────────────────────────────────────


class TestLearnabilityHard:
    def test_empty(self):
        assert compute_learnability_hard("", "") == 0.0

    def test_question_high(self):
        score = compute_learnability_hard(
            "How does retrieval augmented generation compare to fine-tuning?",
            "",
        )
        assert score > 0.5

    def test_vague_low(self):
        score = compute_learnability_hard("stuff", "")
        assert score < 0.3

    def test_concrete_with_numbers(self):
        score = compute_learnability_hard("GPT4 achieves 86% accuracy on MMLU benchmark", "")
        assert score > 0.3


# ── score_signal (integration) ────────────────────────────


class TestScoreSignal:
    def test_basic_output_shape(self):
        signal = {"id": "s1", "content": "attention mechanisms", "context": ""}
        result = score_signal(signal, [], [])
        assert "signal_id" in result
        assert "novelty_hard" in result
        assert "relevance_hard" in result
        assert "learnability_hard" in result
        assert result["signal_id"] == "s1"

    def test_scores_in_range(self):
        signal = {
            "id": "s2",
            "content": "How does RLHF work?",
            "context": "User curious about alignment",
        }
        dirs = [
            {
                "topic": "AI alignment",
                "description": "RLHF and reward modeling",
                "priority": 0.8,
                "active": True,
            }
        ]
        result = score_signal(signal, ["old topic about cooking"], dirs)
        for key in ("novelty_hard", "relevance_hard", "learnability_hard"):
            assert 0.0 <= result[key] <= 1.0

    def test_novelty_decreases_with_past(self):
        signal = {"content": "transformer architecture", "context": ""}
        fresh = score_signal(signal, [], [])
        repeated = score_signal(signal, ["transformer architecture internals"], [])
        assert fresh["novelty_hard"] > repeated["novelty_hard"]
