"""Tests for curiocore.memory — JSONL read/write and compression."""

from __future__ import annotations

import json

import pytest

from curiocore.memory import MemoryStore
from curiocore.types import MemoryEntry


@pytest.fixture()
def store(tmp_path):
    """Create a MemoryStore backed by a temp file."""
    path = tmp_path / "test_memory.jsonl"
    return MemoryStore(str(path))


class TestMemoryStoreBasic:
    def test_empty_store(self, store):
        assert store.count() == 0
        assert store.read_all() == []
        assert len(store) == 0

    def test_append_and_read(self, store):
        entry = MemoryEntry(entry_type="signal", data={"content": "test"})
        store.append(entry)
        assert store.count() == 1

        entries = store.read_all()
        assert len(entries) == 1
        assert entries[0].entry_type == "signal"
        assert entries[0].data["content"] == "test"

    def test_append_raw(self, store):
        store.append_raw({"entry_type": "exploration", "query": "rlhf"})
        entries = store.read_all()
        assert len(entries) == 1
        assert entries[0].entry_type == "exploration"

    def test_multiple_entries(self, store):
        for i in range(5):
            store.append(MemoryEntry(entry_type="signal", data={"index": i}))
        assert store.count() == 5


class TestMemoryStoreRead:
    def test_read_recent(self, store):
        for i in range(10):
            store.append(MemoryEntry(entry_type="signal", data={"index": i}))
        recent = store.read_recent(3)
        assert len(recent) == 3
        # Should be the last 3
        assert recent[0].data["index"] == 7
        assert recent[2].data["index"] == 9

    def test_read_by_type(self, store):
        store.append(MemoryEntry(entry_type="signal", data={"a": 1}))
        store.append(MemoryEntry(entry_type="exploration", data={"b": 2}))
        store.append(MemoryEntry(entry_type="signal", data={"c": 3}))

        signals = store.read_by_type("signal")
        assert len(signals) == 2
        explorations = store.read_by_type("exploration")
        assert len(explorations) == 1

    def test_read_by_type_empty(self, store):
        assert store.read_by_type("nonexistent") == []


class TestExploredTopics:
    def test_no_explorations(self, store):
        store.append(MemoryEntry(entry_type="signal", data={"content": "x"}))
        assert store.get_explored_topics() == []

    def test_extracts_queries(self, store):
        store.append(
            MemoryEntry(
                entry_type="exploration",
                data={"query": "attention mechanisms"},
            )
        )
        store.append(
            MemoryEntry(
                entry_type="exploration",
                data={"query": "RLHF techniques"},
            )
        )
        topics = store.get_explored_topics()
        assert topics == ["attention mechanisms", "RLHF techniques"]

    def test_skips_empty_queries(self, store):
        store.append(MemoryEntry(entry_type="exploration", data={"query": ""}))
        assert store.get_explored_topics() == []


class TestCompression:
    def test_needs_compression_false(self, store):
        for i in range(10):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))
        assert not store.needs_compression(threshold=500)

    def test_needs_compression_true(self, store):
        for i in range(20):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))
        assert store.needs_compression(threshold=15)

    def test_compress_reduces_entries(self, store):
        for i in range(100):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        summary = {"summary": "compressed 90 entries", "key_themes": ["ai"]}
        removed = store.compress(summary, keep_recent=10)
        assert removed == 90
        # 1 compression entry + 10 recent
        assert store.count() == 11

    def test_compress_preserves_recent(self, store):
        for i in range(50):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        store.compress({"summary": "old stuff"}, keep_recent=10)
        entries = store.read_all()
        # First entry is the compression summary
        assert entries[0].entry_type == "compression"
        # Last entry should be original index 49
        assert entries[-1].data["i"] == 49

    def test_compress_noop_when_small(self, store):
        for i in range(5):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))
        removed = store.compress({"summary": "x"}, keep_recent=10)
        assert removed == 0
        assert store.count() == 5

    def test_get_entries_for_compression(self, store):
        for i in range(20):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))
        text = store.get_entries_for_compression(keep_recent=5)
        assert text  # Non-empty
        # Should contain 15 entries as text lines
        lines = [ln for ln in text.split("\n") if ln.strip()]
        assert len(lines) == 15

    def test_get_entries_for_compression_empty(self, store):
        for i in range(3):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))
        text = store.get_entries_for_compression(keep_recent=10)
        assert text == ""


class TestMaintenance:
    def test_clear(self, store):
        store.append(MemoryEntry(entry_type="signal", data={"x": 1}))
        assert store.count() == 1
        store.clear()
        assert store.count() == 0

    def test_export(self, store, tmp_path):
        store.append(MemoryEntry(entry_type="signal", data={"x": 1}))
        export_path = tmp_path / "exported.jsonl"
        store.export(str(export_path))
        assert export_path.exists()
        with open(export_path) as f:
            data = json.loads(f.readline())
        assert data["entry_type"] == "signal"

    def test_export_missing_file_raises(self, tmp_path):
        s = MemoryStore(str(tmp_path / "nonexistent.jsonl"))
        # Force the file to not exist
        s._filepath.unlink(missing_ok=True)
        with pytest.raises(FileNotFoundError):
            s.export(str(tmp_path / "out.jsonl"))

    def test_repr(self, store):
        r = repr(store)
        assert "MemoryStore" in r
        assert "entries=0" in r
