"""Tests for curiocore.run_curiosity — CLI tool subcommands.

Replaces the old test_engine.py. Tests score, store, compress, status,
and dedup subcommands end-to-end via subprocess.
"""

from __future__ import annotations

import json
import subprocess
import sys

from curiocore.memory import MemoryStore
from curiocore.types import MemoryEntry

# Helper to run CLI commands
_CLI = [sys.executable, "-m", "curiocore.run_curiosity"]


def _run(args: list[str], cwd: str | None = None) -> dict:
    """Run a CLI subcommand and parse JSON output."""
    result = subprocess.run(
        [*_CLI, *args],
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    assert result.returncode == 0, f"CLI failed: {result.stderr}\nstdout: {result.stdout}"
    return json.loads(result.stdout)


# ── score ─────────────────────────────────────────────────


class TestCLIScore:
    def test_basic_score(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signal = json.dumps({"id": "s1", "content": "attention sinks", "context": ""})
        result = _run(
            [
                "score",
                "--signal",
                signal,
                "--memory-file",
                str(mem),
            ]
        )
        assert result["signal_id"] == "s1"
        assert 0.0 <= result["novelty_hard"] <= 1.0
        assert 0.0 <= result["relevance_hard"] <= 1.0
        assert 0.0 <= result["learnability_hard"] <= 1.0

    def test_score_with_directions(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signal = json.dumps({"content": "transformer interpretability", "context": ""})
        dirs = json.dumps(
            [
                {
                    "topic": "AI interpretability",
                    "description": "Understanding transformer internals",
                    "priority": 0.9,
                    "active": True,
                }
            ]
        )
        result = _run(
            [
                "score",
                "--signal",
                signal,
                "--memory-file",
                str(mem),
                "--directions",
                dirs,
            ]
        )
        assert result["relevance_hard"] > 0.0

    def test_score_novelty_with_past(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        store.append(
            MemoryEntry(
                entry_type="exploration",
                data={"query": "attention mechanisms in transformers"},
            )
        )

        signal = json.dumps({"content": "attention mechanisms in transformers", "context": ""})
        result = _run(
            [
                "score",
                "--signal",
                signal,
                "--memory-file",
                str(mem),
            ]
        )
        # Should have low novelty since it matches a past exploration
        assert result["novelty_hard"] < 0.5


# ── store ─────────────────────────────────────────────────


class TestCLIStore:
    def test_store_signal(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        data = json.dumps({"content": "test signal", "source": "conversation"})
        result = _run(
            [
                "store",
                "--memory-file",
                str(mem),
                "--entry-type",
                "signal",
                "--data",
                data,
            ]
        )
        assert result["status"] == "ok"
        assert "id" in result

        # Verify persisted
        store = MemoryStore(str(mem))
        assert store.count() == 1
        entries = store.read_by_type("signal")
        assert len(entries) == 1
        assert entries[0].data["content"] == "test signal"

    def test_store_exploration(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        data = json.dumps(
            {
                "signal_id": "s1",
                "query": "RLHF techniques 2025",
                "findings": "Found several new approaches",
                "status": "completed",
            }
        )
        result = _run(
            [
                "store",
                "--memory-file",
                str(mem),
                "--entry-type",
                "exploration",
                "--data",
                data,
            ]
        )
        assert result["status"] == "ok"

    def test_store_multiple(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        for i in range(5):
            _run(
                [
                    "store",
                    "--memory-file",
                    str(mem),
                    "--entry-type",
                    "signal",
                    "--data",
                    json.dumps({"index": i}),
                ]
            )
        store = MemoryStore(str(mem))
        assert store.count() == 5


# ── status ────────────────────────────────────────────────


class TestCLIStatus:
    def test_empty_status(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        result = _run(
            [
                "status",
                "--memory-file",
                str(mem),
            ]
        )
        assert result["total_entries"] == 0
        assert result["needs_compression"] is False
        assert result["explored_topics_count"] == 0

    def test_status_with_entries(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        store.append(MemoryEntry(entry_type="signal", data={"c": "x"}))
        store.append(
            MemoryEntry(
                entry_type="exploration",
                data={"query": "test topic"},
            )
        )

        result = _run(["status", "--memory-file", str(mem)])
        assert result["total_entries"] == 2
        assert result["entry_types"]["signal"] == 1
        assert result["entry_types"]["exploration"] == 1
        assert result["explored_topics_count"] == 1
        assert "test topic" in result["recent_topics"]

    def test_status_compression_threshold(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        for i in range(10):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        result = _run(
            [
                "status",
                "--memory-file",
                str(mem),
                "--compression-threshold",
                "5",
            ]
        )
        assert result["needs_compression"] is True


# ── dedup ─────────────────────────────────────────────────


class TestCLIDedup:
    def test_no_duplicates(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signals = json.dumps(
            [
                {"content": "quantum computing"},
                {"content": "marine biology"},
            ]
        )
        result = _run(
            [
                "dedup",
                "--memory-file",
                str(mem),
                "--signals",
                signals,
            ]
        )
        assert len(result) == 2

    def test_filters_duplicates(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        store.append(
            MemoryEntry(
                entry_type="signal",
                data={"content": "RLHF reward modeling techniques"},
            )
        )

        signals = json.dumps(
            [
                {"content": "RLHF reward modeling techniques overview"},
                {"content": "quantum error correction codes"},
            ]
        )
        result = _run(
            [
                "dedup",
                "--memory-file",
                str(mem),
                "--signals",
                signals,
                "--threshold",
                "0.6",
            ]
        )
        # First should be filtered (duplicate), second kept
        assert len(result) == 1
        assert "quantum" in result[0]["content"]

    def test_dedup_within_batch(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        signals = json.dumps(
            [
                {"content": "RLHF reward modeling techniques"},
                {"content": "RLHF reward modeling approaches"},
            ]
        )
        result = _run(
            [
                "dedup",
                "--memory-file",
                str(mem),
                "--signals",
                signals,
                "--threshold",
                "0.65",
            ]
        )
        # These are very similar (combo ~0.69) — second should be filtered
        assert len(result) == 1

    def test_dedup_empty_signals(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        mem.touch()
        result = _run(
            [
                "dedup",
                "--memory-file",
                str(mem),
                "--signals",
                "[]",
            ]
        )
        assert result == []


# ── compress ──────────────────────────────────────────────


class TestCLICompress:
    def test_dry_run_nothing(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        for i in range(3):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        result = _run(
            [
                "compress",
                "--memory-file",
                str(mem),
                "--keep-recent",
                "10",
                "--dry-run",
            ]
        )
        assert result["status"] == "nothing_to_compress"

    def test_dry_run_with_data(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        for i in range(20):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        result = _run(
            [
                "compress",
                "--memory-file",
                str(mem),
                "--keep-recent",
                "5",
                "--dry-run",
            ]
        )
        assert result["status"] == "ready"
        assert result["entries_to_compress"] == 15
        assert result["entries_to_keep"] == 5
        assert "old_entries_text" in result

    def test_compress_execute(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        for i in range(30):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        summary = json.dumps(
            {
                "summary": "Compressed 25 entries about AI topics",
                "key_themes": ["transformers", "rlhf"],
            }
        )
        result = _run(
            [
                "compress",
                "--memory-file",
                str(mem),
                "--keep-recent",
                "5",
                "--summary",
                summary,
            ]
        )
        assert result["status"] == "compressed"
        assert result["entries_removed"] == 25

        # Verify file state
        store2 = MemoryStore(str(mem))
        assert store2.count() == 6  # 1 compression + 5 recent

    def test_compress_no_summary_fails(self, tmp_path):
        mem = tmp_path / "mem.jsonl"
        store = MemoryStore(str(mem))
        for i in range(20):
            store.append(MemoryEntry(entry_type="signal", data={"i": i}))

        result = subprocess.run(
            [*_CLI, "compress", "--memory-file", str(mem), "--keep-recent", "5"],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0


# ── CLI help / unknown command ────────────────────────────


class TestCLIMisc:
    def test_no_command_shows_help(self):
        result = subprocess.run(
            _CLI,
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0

    def test_unknown_command(self):
        result = subprocess.run(
            [*_CLI, "nonexistent"],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
