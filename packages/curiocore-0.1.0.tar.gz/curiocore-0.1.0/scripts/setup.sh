#!/usr/bin/env bash
set -euo pipefail

echo "Setting up CurioClaw development environment..."

# Check Python version
python3 -c "import sys; assert sys.version_info >= (3, 10), 'Python 3.10+ required'" 2>/dev/null || {
    echo "Error: Python 3.10+ is required."
    exit 1
}

# Install in dev mode
pip install -e ".[dev]"

# Run checks
echo ""
echo "Running lint..."
ruff check .

echo ""
echo "Running tests..."
pytest -v

echo ""
echo "Setup complete! CurioClaw is ready."
echo ""
echo "Quick start:"
echo "  export ANTHROPIC_API_KEY=sk-ant-..."
echo "  python examples/quickstart.py"
