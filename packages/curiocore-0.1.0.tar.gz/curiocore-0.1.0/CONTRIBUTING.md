# Contributing to CurioClaw

Thank you for your interest in contributing! Here's how to get started.

## Development Setup

```bash
git clone https://github.com/your-org/CurioClaw.git
cd CurioClaw
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest
```

## Code Style

We use [ruff](https://docs.astral.sh/ruff/) for linting and formatting:

```bash
ruff check .
ruff format .
```

All code must pass `ruff check` before merging.

## What to Contribute

### High-impact areas

- **Prompt improvements** (`curiocore/prompts.py`) — This is the project's core IP. Better prompts directly improve the engine's curiosity quality.
- **New adapters** (`adapters/`) — Help CurioClaw work with more agent frameworks.
- **Signal sources** — Add new ways to detect curiosity signals (RSS feeds, code repos, etc.).
- **Tests** — More test coverage is always welcome.

### How to submit

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-change`
3. Make your changes
4. Run tests: `pytest`
5. Run linter: `ruff check .`
6. Commit with a clear message
7. Open a Pull Request

## Writing an Adapter

1. Copy `adapters/_template/` to `adapters/your_framework/`
2. Implement the integration hooks
3. Add `SKILL.md`, `README.md`, and `install.md`
4. Add tests in `tests/`
5. Submit a PR

## PR Guidelines

- Keep PRs focused — one feature or fix per PR
- Include tests for new functionality
- Update documentation if behavior changes
- Reference related issues in the PR description

## Code of Conduct

Please read and follow our [Code of Conduct](CODE_OF_CONDUCT.md).
