"""Metadata Extractor Application"""

