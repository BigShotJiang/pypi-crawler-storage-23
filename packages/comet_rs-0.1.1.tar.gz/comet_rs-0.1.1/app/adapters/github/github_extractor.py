"""
Layer 3: Adapters - GitHub
GitHub extractor - implements PlatformExtractor protocol
"""
from typing import Optional, TYPE_CHECKING
from app.core.entities.repository_metadata import RepositoryMetadata, VersionControlSystem, License
from app.adapters.github.github_client import GitHubClient
from app.adapters.github.github_file_fetcher import GitHubFileFetcher
from app.domain.services.url_pattern_matcher import URLPatternMatcher
from app.domain.extraction_sources import SOURCE_GITHUB_API, CONFIDENCE_PLATFORM

if TYPE_CHECKING:
    from app.application.use_cases.extract_metadata import ExtractionMetadataCollector


class GitHubExtractor:
    """
    GitHub platform extractor.
    Implements the PlatformExtractor protocol from Layer 2.
    """
    
    def __init__(self, access_token: Optional[str] = None):
        """
        Initialize GitHub extractor.
        
        Args:
            access_token: GitHub access token
        """
        self.client = GitHubClient(access_token)
        self.file_fetcher = GitHubFileFetcher(access_token)
        self.url_matcher = URLPatternMatcher()
    
    def extract_platform_metadata(
        self,
        repo_url: str,
        access_token: Optional[str] = None,
        extraction_metadata: Optional["ExtractionMetadataCollector"] = None,
    ) -> RepositoryMetadata:
        """
        Extract metadata from GitHub API.
        
        Args:
            repo_url: GitHub repository URL
            access_token: Access token (if not set in constructor)
            extraction_metadata: Optional collector for source/confidence per property
            
        Returns:
            RepositoryMetadata object
        """
        def record(field: str) -> None:
            if extraction_metadata is not None:
                extraction_metadata.record(field, SOURCE_GITHUB_API, CONFIDENCE_PLATFORM)

        if access_token and not self.client.access_token:
            self.client = GitHubClient(access_token)
            self.file_fetcher = GitHubFileFetcher(access_token)
        
        owner, repo = self.url_matcher.extract_repo_info(repo_url)
        if not owner or not repo:
            raise ValueError(f"Invalid GitHub repository URL: {repo_url}")
        
        repo_data = self.client.get_repo(owner, repo)
        metadata = RepositoryMetadata()
        
        # Basic information
        metadata.name = repo_data.get("name")
        metadata.description = repo_data.get("description")
        metadata.url = repo_data.get("html_url")
        metadata.codeRepository = f"{repo_data.get('html_url')}.git"
        if metadata.name is not None:
            record("name")
        if metadata.description is not None:
            record("description")
        if metadata.url is not None:
            record("url")
        if metadata.codeRepository is not None:
            record("codeRepository")
        
        # Dates
        if repo_data.get("created_at"):
            metadata.dateCreated = repo_data.get("created_at")[:10]
            record("dateCreated")
        if repo_data.get("updated_at"):
            metadata.dateModified = repo_data.get("updated_at")[:10]
            record("dateModified")
        if repo_data.get("pushed_at"):
            metadata.datePublished = repo_data.get("pushed_at")[:10]
            record("datePublished")
        
        # Access information
        is_private = repo_data.get("private", False)
        metadata.conditionsOfAccess = "Private" if is_private else "Public"
        metadata.isAccessibleForFree = str(not is_private)
        record("conditionsOfAccess")
        record("isAccessibleForFree")
        
        # Issue tracker and discussion
        metadata.issueTracker = f"{repo_data.get('html_url')}/issues"
        metadata.codemeta_issueTracker = metadata.issueTracker
        record("issueTracker")
        record("codemeta_issueTracker")
        if repo_data.get("has_discussions"):
            metadata.discussionUrl = f"{repo_data.get('html_url')}/discussions"
            record("discussionUrl")
        
        # Download URL
        archive_url = repo_data.get("archive_url", "")
        if archive_url:
            metadata.downloadUrl = archive_url.replace("{archive_format}{/ref}", "zipball/master")
            record("downloadUrl")
        
        # Source code
        metadata.hasSourceCode = f"{repo_data.get('html_url')}#id"
        metadata.codemeta_hasSourceCode = metadata.hasSourceCode
        record("hasSourceCode")
        record("codemeta_hasSourceCode")
        
        # Keywords (topics) — merge with any existing from other sources
        topics = repo_data.get("topics") or []
        if topics:
            existing = metadata.keywords or []
            metadata.keywords = list(set(existing) | set(topics))
            record("keywords")
        
        # Version control system
        metadata.masmp_versionControlSystem = VersionControlSystem.create_git(
            vcs_type="SoftwareSourceCode"
        )
        record("masmp_versionControlSystem")
        
        # Programming languages
        try:
            languages_data = self.client.get_languages(owner, repo)
            if languages_data:
                metadata.programmingLanguage = list(languages_data.keys())
                record("programmingLanguage")
        except Exception:
            pass
        
        # Contributors
        try:
            contributors_data = self.client.get_contributors(owner, repo)
            if contributors_data:
                metadata.contributor = [
                    {"@type": "Person", "url": c.get("html_url")}
                    for c in contributors_data
                ]
                record("contributor")
        except Exception:
            pass
        
        # License
        try:
            license_data = self.client.get_license(owner, repo)
            if license_data and license_data.get("license"):
                license_info = license_data["license"]
                metadata.license = License(
                    name=license_info.get("name"),
                    url=license_info.get("url")
                )
                record("license")
        except Exception:
            pass
        
        # README
        for branch in ["main", "master"]:
            readme_url = f"https://github.com/{owner}/{repo}/blob/{branch}/README.md"
            if self.file_fetcher.is_file_reachable(readme_url):
                metadata.codemeta_readme = readme_url
                record("codemeta_readme")
                break
        
        # CHANGELOG
        for branch in ["main", "master"]:
            changelog_url = f"https://github.com/{owner}/{repo}/blob/{branch}/CHANGELOG.md"
            if self.file_fetcher.is_file_reachable(changelog_url):
                metadata.masmp_changelog = changelog_url
                record("masmp_changelog")
                break

        # Software requirements files (root-level and nested)
        requirement_files = {
            "requirements.txt",
            "environment.yml",
            "environment.yaml",
            "Pipfile",
            "pyproject.toml",
            "setup.cfg",
            "setup.py",
            "package.json",
            "package-lock.json",
            "pnpm-lock.yaml",
        }
        requirement_urls: list[str] = []
        seen_paths: set[str] = set()

        list_contents = getattr(self.file_fetcher, "list_repo_contents", None)

        def _walk_requirements(path: str, depth: int) -> None:
            # Limit recursion depth to avoid traversing huge trees
            if depth > 3 or not callable(list_contents):
                return
            try:
                contents = list_contents(owner, repo, path)  # type: ignore[misc]
            except Exception:
                return
            if not contents:
                return
            for item in contents:
                item_type = item.get("type")
                name = item.get("name")
                item_path = item.get("path") or name
                if not name or not item_path:
                    continue
                if item_type in ("file", "blob") and (
                    name in requirement_files or name.endswith(".lock")
                ):
                    if item_path in seen_paths:
                        continue
                    for branch in ["main", "master"]:
                        file_url = f"https://github.com/{owner}/{repo}/blob/{branch}/{item_path}"
                        if self.file_fetcher.is_file_reachable(file_url):
                            requirement_urls.append(file_url)
                            seen_paths.add(item_path)
                            break
                elif item_type in ("dir", "tree") and depth < 3:
                    _walk_requirements(item_path, depth + 1)

        if callable(list_contents):
            _walk_requirements("", 0)
        else:
            # Fallback: only probe common filenames at repository root
            for branch in ["main", "master"]:
                for filename in requirement_files:
                    if filename in seen_paths:
                        continue
                    file_url = f"https://github.com/{owner}/{repo}/blob/{branch}/{filename}"
                    if self.file_fetcher.is_file_reachable(file_url):
                        requirement_urls.append(file_url)
                        seen_paths.add(filename)

        if requirement_urls:
            metadata.softwareRequirements = requirement_urls
            record("softwareRequirements")
        
        # Release information
        try:
            release_data = self.client.get_latest_release(owner, repo)
            if release_data:
                metadata.softwareVersion = release_data.get("tag_name")
                record("softwareVersion")
                if release_data.get("published_at"):
                    release_date = release_data.get("published_at")[:10]
                    try:
                        commits_data = self.client.get_commits(owner, repo, per_page=1)
                        if commits_data:
                            commit_date = commits_data[0]["commit"]["committer"]["date"][:10]
                            if commit_date <= release_date:
                                metadata.version = release_data.get("tag_name")
                                record("version")
                    except Exception:
                        pass
                metadata.has_release = True
        except Exception:
            metadata.has_release = False
        
        return metadata

