"""
Layer 3: Adapters - GitLab
GitLab extractor - implements PlatformExtractor protocol
"""
from typing import Optional, TYPE_CHECKING
from urllib.parse import quote

from app.core.entities.repository_metadata import (
    RepositoryMetadata,
    VersionControlSystem,
    License,
)
from app.adapters.gitlab.gitlab_client import GitLabClient
from app.adapters.gitlab.gitlab_file_fetcher import GitLabFileFetcher
from app.domain.services.url_pattern_matcher import URLPatternMatcher
from app.domain.extraction_sources import SOURCE_GITLAB_API, CONFIDENCE_PLATFORM

if TYPE_CHECKING:
    from app.application.use_cases.extract_metadata import ExtractionMetadataCollector


class GitLabExtractor:
    """
    GitLab platform extractor.
    Implements the PlatformExtractor protocol from Layer 2.
    """

    def __init__(self, access_token: Optional[str] = None):
        """
        Initialize GitLab extractor.

        Args:
            access_token (str | None): GitLab personal access token
        """
        self.client = GitLabClient(access_token)
        self.file_fetcher = GitLabFileFetcher(access_token)
        self.url_matcher = URLPatternMatcher()

    # -------------------------------------------------------------------------
    # Main extraction entry point
    # -------------------------------------------------------------------------
    def extract_platform_metadata(
        self,
        repo_url: str,
        access_token: Optional[str] = None,
        extraction_metadata: Optional["ExtractionMetadataCollector"] = None,
    ) -> RepositoryMetadata:
        """
        Extract metadata from GitLab via the GitLab API.

        Args:
            repo_url: GitLab repository URL.
            access_token: Optional access token override.
            extraction_metadata: Optional collector for source/confidence per property.

        Returns:
            RepositoryMetadata: Populated metadata object.
        """
        def record(field: str) -> None:
            if extraction_metadata is not None:
                extraction_metadata.record(field, SOURCE_GITLAB_API, CONFIDENCE_PLATFORM)

        if access_token and not self.client.access_token:
            self.client = GitLabClient(access_token)
            self.file_fetcher = GitLabFileFetcher(access_token)

        owner, repo = self.url_matcher.extract_repo_info(repo_url)
        if not owner or not repo:
            raise ValueError(f"Invalid GitLab repository URL: {repo_url}")

        project_id = quote(f"{owner}/{repo}", safe="")
        project = self.client.get_project(project_id)
        metadata = RepositoryMetadata()

        # Basic information
        metadata.name = project.get("name")
        metadata.description = project.get("description")
        metadata.url = project.get("web_url")
        metadata.codeRepository = project.get("http_url_to_repo")
        if metadata.name is not None:
            record("name")
        if metadata.description is not None:
            record("description")
        if metadata.url is not None:
            record("url")
        if metadata.codeRepository is not None:
            record("codeRepository")

        # Dates
        if project.get("created_at"):
            metadata.dateCreated = project["created_at"][:10]
            record("dateCreated")
        if project.get("last_activity_at"):
            metadata.dateModified = project["last_activity_at"][:10]
            record("dateModified")
        try:
            commits = self.client.get_commits(project_id, per_page=1)
            if commits:
                metadata.datePublished = commits[0]["committed_date"][:10]
                record("datePublished")
        except Exception:
            metadata.datePublished = None

        # Access control
        visibility = project.get("visibility", "").lower()
        metadata.conditionsOfAccess = visibility.capitalize()
        metadata.isAccessibleForFree = str(visibility == "public")
        record("conditionsOfAccess")
        record("isAccessibleForFree")

        # Issue tracker and discussions
        metadata.issueTracker = project.get("web_url") + "/-/issues"
        metadata.codemeta_issueTracker = metadata.issueTracker
        record("issueTracker")
        record("codemeta_issueTracker")
        if project.get("operations_access_level") == "enabled":
            metadata.discussionUrl = project.get("web_url") + "/-/discussions"
            record("discussionUrl")

        # Download archive
        metadata.downloadUrl = f"{project.get('web_url')}/-/archive/master/{project['name']}-master.zip"
        record("downloadUrl")

        # Source code reference
        if metadata.url is not None:
            source_url = str(metadata.url)
            metadata.hasSourceCode = source_url
            metadata.codemeta_hasSourceCode = source_url
            record("hasSourceCode")
            record("codemeta_hasSourceCode")

        # Keywords / Tags — merge with any existing from other sources
        tag_list = project.get("tag_list") or []
        if tag_list:
            existing = metadata.keywords or []
            metadata.keywords = list(set(existing) | set(tag_list))
            record("keywords")

        # Version control system
        metadata.masmp_versionControlSystem = VersionControlSystem.create_git(
            vcs_type="SoftwareSourceCode"
        )
        record("masmp_versionControlSystem")

        # Programming languages
        try:
            languages_data = self.client.get_languages(project_id)
            if languages_data:
                metadata.programmingLanguage = list(languages_data.keys())
                record("programmingLanguage")
        except Exception:
            pass

        # Contributors
        try:
            contributors = self.client.get_contributors(project_id)
            if contributors:
                metadata.contributor = [
                    {"@type": "Person", "name": c.get("name"), "email": c.get("email")}
                    for c in contributors
                ]
                record("contributor")
        except Exception:
            pass

        # License
        try:
            license_data = self.client.get_license(project_id)
            if license_data and license_data.get("license"):
                l = license_data["license"]
                metadata.license = License(name=l.get("name"), url=l.get("url"))
                record("license")
        except Exception:
            pass

        # README file
        for branch in ["main", "master"]:
            readme_url = f"https://gitlab.com/{owner}/{repo}/-/blob/{branch}/README.md"
            if self.file_fetcher.is_file_reachable(readme_url):
                metadata.codemeta_readme = readme_url
                record("codemeta_readme")
                break

        # CHANGELOG
        for branch in ["main", "master"]:
            changelog_url = f"https://gitlab.com/{owner}/{repo}/-/blob/{branch}/CHANGELOG.md"
            if self.file_fetcher.is_file_reachable(changelog_url):
                metadata.masmp_changelog = changelog_url
                record("masmp_changelog")
                break

        # Software requirements files (root-level and nested)
        requirement_files = {
            "requirements.txt",
            "environment.yml",
            "environment.yaml",
            "Pipfile",
            "pyproject.toml",
            "setup.cfg",
            "setup.py",
            "package.json",
            "package-lock.json",
            "pnpm-lock.yaml",
        }
        requirement_urls: list[str] = []
        seen_paths: set[str] = set()

        list_contents = getattr(self.file_fetcher, "list_repo_contents", None)

        def _walk_requirements(path: str, depth: int) -> None:
            # Limit recursion depth to avoid traversing huge trees
            if depth > 3 or not callable(list_contents):
                return
            try:
                contents = list_contents(owner, repo, path)  # type: ignore[misc]
            except Exception:
                return
            if not contents:
                return
            for item in contents:
                item_type = item.get("type")
                name = item.get("name")
                item_path = item.get("path") or name
                if not name or not item_path:
                    continue
                if item_type in ("file", "blob") and (
                    name in requirement_files or name.endswith(".lock")
                ):
                    if item_path in seen_paths:
                        continue
                    for branch in ["main", "master"]:
                        file_url = f"https://gitlab.com/{owner}/{repo}/-/blob/{branch}/{item_path}"
                        if self.file_fetcher.is_file_reachable(file_url):
                            requirement_urls.append(file_url)
                            seen_paths.add(item_path)
                            break
                elif item_type in ("dir", "tree") and depth < 3:
                    _walk_requirements(item_path, depth + 1)

        if callable(list_contents):
            _walk_requirements("", 0)
        else:
            # Fallback: only probe common filenames at repository root
            for branch in ["main", "master"]:
                for filename in requirement_files:
                    if filename in seen_paths:
                        continue
                    file_url = f"https://gitlab.com/{owner}/{repo}/-/blob/{branch}/{filename}"
                    if self.file_fetcher.is_file_reachable(file_url):
                        requirement_urls.append(file_url)
                        seen_paths.add(filename)

        if requirement_urls:
            metadata.softwareRequirements = requirement_urls
            record("softwareRequirements")

        # Releases
        try:
            latest_release = self.client.get_latest_release(project_id)
            if latest_release:
                metadata.softwareVersion = latest_release.get("tag_name")
                metadata.version = latest_release.get("tag_name")
                record("softwareVersion")
                record("version")
                metadata.has_release = True
            else:
                metadata.has_release = False
        except Exception:
            metadata.has_release = False

        # Author
        try:
            author = project.get("namespace", {})
            if author:
                metadata.author = [{"@type": "Person", "name": author.get("name"), "email": author.get("email")}]
                record("author")
        except Exception:
            pass

        return metadata