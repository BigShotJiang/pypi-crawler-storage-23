"""Core layer - entities only"""

