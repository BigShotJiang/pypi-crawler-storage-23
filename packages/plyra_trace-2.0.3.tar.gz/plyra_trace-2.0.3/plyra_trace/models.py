"""Pydantic models for plyra-trace."""

from typing import Any

from pydantic import BaseModel, Field


class GuardResult(BaseModel):
    """Return type for @guard-decorated functions."""

    policy: str
    action: str  # "allow" | "block" | "redact" | "flag" | "modify"
    triggered: bool
    confidence: float | None = None
    details: dict[str, Any] | None = None
    modified_input: str | None = None  # For "redact" or "modify" actions
    provider: str = "plyra-guard"


class TraceContext(BaseModel):
    """Extracted trace context for cross-process propagation."""

    trace_id: str
    span_id: str
    trace_flags: int = 1
    agent_from: str | None = None
    handoff_reason: str | None = None
    handoff_protocol: str = "http"
    raw_carrier: dict[str, str] = Field(default_factory=dict)


class SpanLink(BaseModel):
    """A link from one span to a span in another trace."""

    trace_id: str
    span_id: str
    attributes: dict[str, Any] = Field(default_factory=dict)
