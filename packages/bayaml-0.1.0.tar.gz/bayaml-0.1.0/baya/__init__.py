"""Baya - Structured ML Orchestration Framework."""

from __future__ import annotations


from .automl import baya
from .project import Project
from .registry import list_models, register_model
from .simple import Baya, quick_train

from .project import Project

from .simple import Baya, quick_train



from .version import __version__

__author__ = "Aditya Sarode"
__license__ = "MIT"
__GitHub__ = "https://github.com/adityassarode"
__buy_me_a_coffee__ = "https://buymeacoffee.com/adityasarode or https://ko-fi.com/adityassarode"


def info(open_website: bool = False) -> None:
    import webbrowser

    print("Baya ML Framework")
    print(f"Version : {__version__}")
    print(f"Author  : {__author__}")
    print(f"GitHub : {__GitHub__}")
    print(f"Support : {__buy_me_a_coffee__}")
    print("Built with ❤️ by Aditya Sarode")
    if open_website:
        webbrowser.open(__GitHub__)



__all__ = ["Project", "Baya", "quick_train", "baya", "register_model", "list_models", "__version__", "info"]

__all__ = ["Project", "Baya", "quick_train", "__version__", "info"]

__all__ = ["Project", "__version__", "info"]


