class Scheduler:
    """Minimal serial scheduler placeholder for future parallel execution."""

    def schedule(self, steps):
        return list(steps)
