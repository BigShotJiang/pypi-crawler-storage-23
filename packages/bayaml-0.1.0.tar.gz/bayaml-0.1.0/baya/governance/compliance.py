class ComplianceCheck:
    def validate(self) -> bool:
        return True
