def generate_fastapi_stub(model_path: str) -> str:
    return f"# FastAPI stub for model at {model_path}\n"
