from .core import BayaError


class ConfigError(BayaError):
    pass
