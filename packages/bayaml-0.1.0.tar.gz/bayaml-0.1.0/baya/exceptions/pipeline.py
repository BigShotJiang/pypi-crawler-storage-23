from .core import BayaError


class PipelineError(BayaError):
    pass
