from yta_editor_parameters.values.abstract import VideoEditorParameterValue
from yta_editor_parameters.values import ConstantVideoEditorParameterValue
from yta_validation import PythonValidator


def parse_parameters(
    parameters: dict
) -> dict[str, 'VideoEditorParameterValue']:
    """
    Parse the `parameters` provided and raise an exception
    if some of them is unaccepted. It will transform the
    basic types into `ConstantVideoEditorParameterValue`
    instances, and return the new dict with the values
    transformed.

    These types will be transformed into constant values:
    - `int`
    - `float`
    - `bool`
    - `str`
    - `None`
    """
    parameters_parsed = {}

    for name, value in parameters.items():
        try:
            parameters_parsed[name] = parse_parameter(value)
        except:
            raise Exception(f'The "{name}" parameter is not a "VideoEditorParameterValue" nor a basic and non iterable type') 

    return parameters_parsed

def parse_parameter(
    parameter: VideoEditorParameterValue
) -> VideoEditorParameterValue:
    """
    Parse the `parameter` provided and raise an exception
    if it is not accepted. It will transform the basic
    types into `ConstantVideoEditorParameterValue` instances,
    and return the parameter but casted.

    These types will be transformed into constant values:
    - `int`
    - `float`
    - `bool`
    - `str`
    - `None`
    """
    if PythonValidator.is_instance_of(parameter, VideoEditorParameterValue):
        return parameter

    if (
        PythonValidator.is_basic_non_iterable_type(parameter) or
        parameter is None
    ):
        return ConstantVideoEditorParameterValue(parameter)
        
    raise Exception(f'The parameter is not a "VideoEditorParameterValue" nor a basic and non iterable type')

def is_this_constant_value(
    parameter: VideoEditorParameterValue,
    value: 'BASIC_NON_ITERABLE_TYPE'
) -> bool:
    """
    Check if the `parameter` provided is a 
    `ConstantVideoEditorParameterValue` and has the
    `value` provided.

    This is useful to check if a parameter is
    the default value and we don't need to apply
    any change because of this.
    """
    # TODO: We could add an Eased but with the
    # same 'start_value' and 'end_value' because
    # the evaluation will be the same always
    return (
        PythonValidator.is_instance_of(parameter, ConstantVideoEditorParameterValue) and
        parameter.value == value
    )