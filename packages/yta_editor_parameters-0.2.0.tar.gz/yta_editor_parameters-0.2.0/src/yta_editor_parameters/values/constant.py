from yta_editor_parameters.values.abstract import VideoEditorParameterValue
from yta_editor_time.evaluation_context import EvaluationContext


class ConstantVideoEditorParameterValue(VideoEditorParameterValue):
    """
    A parameter value that has always the same value
    and is unaware of the context.
    """

    def __init__(
        self,
        value: 'BASIC_NON_ITERABLE_TYPE'
    ):
        self.value: 'BASIC_NON_ITERABLE_TYPE' = value
        """
        The constant value of this parameter.
        """

    def evaluate(
        self,
        # This is mandatory, even though it is not used
        evaluation_context: EvaluationContext
    ):
        return self.value