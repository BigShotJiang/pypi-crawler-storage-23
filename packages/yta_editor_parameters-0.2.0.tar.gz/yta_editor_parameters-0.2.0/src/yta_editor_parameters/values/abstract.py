from yta_editor_time.evaluation_context import EvaluationContext
from abc import abstractmethod, ABC


class VideoEditorParameterValue(ABC):
    """
    A parameter value that uses a video editor
    context to be evaluated.
    """

    @abstractmethod
    def evaluate(
        self,
        # This is mandatory, even though it is not used
        evaluation_context: EvaluationContext
    ):
        pass