"""
Module to include the functionality related to the
parameter values and how we define them to be used
in our 'yta-editor' video editor library.
"""
from yta_editor_parameters.values.constant import ConstantVideoEditorParameterValue
from yta_editor_parameters.values.eased import EasedVideoEditorParameterValue


__all__ = [
    'ConstantVideoEditorParameterValue',
    'EasedVideoEditorParameterValue'
]