"""
Module to include the functionality related to the
parameter specifications and the parameter values
and how we define them to be used in our 'yta-editor'
video editor library.
"""