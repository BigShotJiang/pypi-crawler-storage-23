from dataclasses import dataclass


@dataclass(frozen=True)
class RetryContext:
    exception: BaseException
    event_id: str
