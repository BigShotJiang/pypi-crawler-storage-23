from dataclasses import dataclass
import dataclasses

from buz.message import Message, MessageId

EventId = MessageId


@dataclass(frozen=True)
class Event(Message):
    @classmethod
    def fqn(cls) -> str:
        return f"event.{super().fqn()}"

    def partition_key(self) -> str:
        return str(self.id)

    def extract_event_payload(self) -> dict:
        event_payload = dataclasses.asdict(self)
        event_payload.pop("id")
        event_payload.pop("created_at")
        event_payload.pop("metadata")
        return event_payload
