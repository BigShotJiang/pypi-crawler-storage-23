from typing import Any
from uuid import UUID

from buz.claim_check.domain.async_claim_check_manager import AsyncClaimCheckManager
from buz.claim_check.domain.async_claim_check_repository import AsyncClaimCheckEventRepository
from buz.event import Event
from buz.event.transactional_outbox.asynchronous.async_event_to_outbox_record_translator import (
    AsyncEventToOutboxRecordTranslator,
)
from buz.event.transactional_outbox.outbox_record import OutboxRecord


EventPayload = dict[str, Any]


class AsyncEventToOutboxRecordClaimCheckTranslator(AsyncEventToOutboxRecordTranslator):
    def __init__(
        self,
        claim_check_manager: AsyncClaimCheckManager,
        claim_check_repository: AsyncClaimCheckEventRepository,
    ) -> None:
        self.__claim_check_manager = claim_check_manager
        self.__claim_check_repository = claim_check_repository

    async def translate(self, event: Event) -> OutboxRecord:
        partition_key = event.partition_key()

        event_payload = await self.__claim_check_event_and_get_payload(event)

        return OutboxRecord(
            event_id=UUID(event.id),
            event_fqn=event.fqn(),
            created_at=event.parsed_created_at(),
            event_payload=event_payload,
            event_metadata=dict(event.metadata),
            partition_key=partition_key,
        )

    async def __claim_check_event_and_get_payload(self, event: Event) -> EventPayload:
        if await self.__claim_check_manager.is_event_stored_externally(event.metadata):
            return {}

        if await self.__claim_check_manager.should_store_event_externally(event):
            await self.__claim_check_repository.save(event)
            return {}

        return event.extract_event_payload()
