from buz.event import Event
from buz.event.transactional_outbox.asynchronous.async_event_to_outbox_record_translator import (
    AsyncEventToOutboxRecordTranslator,
)
from buz.event.transactional_outbox.basic_event_to_outbox_record_translator import BasicEventToOutboxRecordTranslator
from buz.event.transactional_outbox.outbox_record import OutboxRecord


class AsyncBasicEventToOutboxRecordTranslator(AsyncEventToOutboxRecordTranslator):
    def __init__(self) -> None:
        self.__basic_event_to_outbox_record_translator = BasicEventToOutboxRecordTranslator()

    async def translate(self, event: Event) -> OutboxRecord:
        return self.__basic_event_to_outbox_record_translator.translate(event)
