from abc import ABC, abstractmethod

from buz.event import Event
from buz.event.transactional_outbox.outbox_record import OutboxRecord


class AsyncEventToOutboxRecordTranslator(ABC):
    @abstractmethod
    async def translate(self, event: Event) -> OutboxRecord:
        pass
