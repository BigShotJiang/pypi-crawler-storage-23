from abc import ABC, abstractmethod
from typing import Sequence, Iterable

from buz.event.transactional_outbox.outbox_criteria.outbox_criteria import OutboxCriteria
from buz.event.transactional_outbox.outbox_record import OutboxRecord


class AsyncOutboxRepository(ABC):
    @abstractmethod
    async def save(self, outbox_record: OutboxRecord) -> None:
        pass

    @abstractmethod
    async def bulk_create(self, outbox_records: Iterable[OutboxRecord]) -> None:
        pass

    @abstractmethod
    async def find(self, criteria: OutboxCriteria) -> Sequence[OutboxRecord]:
        pass

    @abstractmethod
    async def bulk_delete(self, outbox_record_ids: Sequence[str]) -> None:
        pass
