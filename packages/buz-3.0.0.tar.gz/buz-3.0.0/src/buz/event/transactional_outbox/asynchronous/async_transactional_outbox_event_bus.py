from typing import Collection, Optional

from buz.event import Event
from buz.event.async_event_bus import AsyncEventBus
from buz.event.middleware.async_publish_middleware import AsyncPublishMiddleware
from buz.event.middleware.async_publish_middleware_chain_resolver import AsyncPublishMiddlewareChainResolver
from buz.event.transactional_outbox.asynchronous.async_event_to_outbox_record_translator import (
    AsyncEventToOutboxRecordTranslator,
)
from buz.event.transactional_outbox.asynchronous.async_outbox_repository import AsyncOutboxRepository
from buz.event.transactional_outbox.outbox_record import OutboxRecord
from buz.event.transactional_outbox.outbox_record_validation.outbox_record_validator import OutboxRecordValidator


class AsyncTransactionalOutboxEventBus(AsyncEventBus):
    def __init__(
        self,
        outbox_repository: AsyncOutboxRepository,
        event_to_outbox_record_translator: AsyncEventToOutboxRecordTranslator,
        outbox_record_validator: Optional[OutboxRecordValidator] = None,
        publish_middlewares: Optional[list[AsyncPublishMiddleware]] = None,
    ) -> None:
        self.__outbox_repository = outbox_repository
        self.__event_to_outbox_record_translator = event_to_outbox_record_translator
        self.__outbox_record_validator = outbox_record_validator
        self.__publish_middlewares = publish_middlewares
        self.__publish_middleware_chain_resolver = AsyncPublishMiddlewareChainResolver(
            self.__publish_middlewares or []
        )

    async def connect(self) -> None:
        return

    async def disconnect(self) -> None:
        return

    async def publish(self, event: Event) -> None:
        await self.__publish_middleware_chain_resolver.resolve(event, self._publish_middleware_chain_last_callable)
        await self.__perform_publish(event)

    async def _publish_middleware_chain_last_callable(self, event: Event) -> None:
        return

    async def __perform_publish(self, event: Event) -> None:
        outbox_record = await self.__process_event(event)
        await self.__outbox_repository.save(outbox_record)

    async def bulk_publish(self, events: Collection[Event]) -> None:
        chain_resolver = AsyncPublishMiddlewareChainResolver(self.__publish_middlewares or [])
        outbox_records: list[OutboxRecord] = []

        for event in events:
            await chain_resolver.resolve(event, self._publish_middleware_chain_last_callable)
            outbox_records.append(await self.__process_event(event))

        if len(outbox_records) == 0:
            return

        await self.__outbox_repository.bulk_create(outbox_records)

    async def __process_event(self, event: Event) -> OutboxRecord:
        outbox_record = await self.__translate_event(event)
        self.__validate_outbox_record(outbox_record)
        return outbox_record

    async def __translate_event(self, event: Event) -> OutboxRecord:
        return await self.__event_to_outbox_record_translator.translate(event)

    def __validate_outbox_record(self, outbox_record: OutboxRecord) -> None:
        if self.__outbox_record_validator is not None:
            self.__outbox_record_validator.validate(record=outbox_record)
