from abc import ABC, abstractmethod

from buz.event import Event
from buz.event.transactional_outbox.outbox_record import OutboxRecord


class OutboxRecordToEventTranslator(ABC):
    @abstractmethod
    def translate(self, outbox_record: OutboxRecord) -> Event:
        pass
