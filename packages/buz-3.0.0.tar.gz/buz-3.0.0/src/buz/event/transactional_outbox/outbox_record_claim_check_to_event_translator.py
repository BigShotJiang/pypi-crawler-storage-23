from typing import Any, cast

from buz.claim_check.domain.claim_check_manager import ClaimCheckManager
from buz.event import Event
from buz.event.transactional_outbox.fqn_to_event_mapper import FqnToEventMapper
from buz.event.transactional_outbox.outbox_record import OutboxRecord
from buz.event.transactional_outbox.outbox_record_to_event_translator import OutboxRecordToEventTranslator
from buz.claim_check.domain.claim_check_repository import ClaimCheckEventRepository
from buz.kafka.infrastructure.deserializers.sync_byte_deserializer import SyncByteDeserializer
from buz.metadata import Metadata


class OutboxRecordClaimCheckToEventTranslator(OutboxRecordToEventTranslator):
    def __init__(
        self,
        fqn_to_event_mapper: FqnToEventMapper,
        claim_check_repository: ClaimCheckEventRepository,
        claim_check_manager: ClaimCheckManager,
        event_payload_deserializer: SyncByteDeserializer[dict[str, Any]],
    ):
        self.__fqn_to_event_mapper = fqn_to_event_mapper
        self.__claim_check_repository = claim_check_repository
        self.__claim_check_manager = claim_check_manager
        self.__event_payload_deserializer = event_payload_deserializer

    def translate(self, outbox_record: OutboxRecord) -> Event:
        event_klass = self.__fqn_to_event_mapper.get_message_klass_by_fqn(outbox_record.event_fqn)
        raw_metadata: Any = outbox_record.event_metadata if outbox_record.event_metadata is not None else {}
        event_metadata = Metadata(**raw_metadata)
        event_payload = self.__extract_event_payload(outbox_record, event_metadata)

        return cast(
            Event,
            event_klass.restore(
                id=str(outbox_record.event_id),
                created_at=outbox_record.parsed_created_at(),
                metadata=event_metadata,
                **event_payload,
            ),
        )

    def __extract_event_payload(
        self,
        outbox_record: OutboxRecord,
        event_metadata: Metadata,
    ) -> dict[str, Any]:
        if self.__claim_check_manager.is_event_stored_externally(event_metadata):
            raw_event_payload = self.__claim_check_repository.get(event_metadata)
            return self.__event_payload_deserializer.deserialize(raw_event_payload)
        else:
            return outbox_record.event_payload
