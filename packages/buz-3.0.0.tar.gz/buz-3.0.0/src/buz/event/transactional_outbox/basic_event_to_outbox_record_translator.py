from uuid import UUID

from buz.event import Event
from buz.event.transactional_outbox.event_to_outbox_record_translator import EventToOutboxRecordTranslator
from buz.event.transactional_outbox.outbox_record import OutboxRecord


class BasicEventToOutboxRecordTranslator(EventToOutboxRecordTranslator):
    def translate(self, event: Event) -> OutboxRecord:
        payload = event.extract_event_payload()
        partition_key = event.partition_key()
        return OutboxRecord(
            event_id=UUID(event.id),
            event_fqn=event.fqn(),
            created_at=event.parsed_created_at(),
            event_payload=payload,
            event_metadata=dict(event.metadata),
            partition_key=partition_key,
        )
