from abc import ABC, abstractmethod

from buz.event.event import Event
from buz.metadata import Metadata


class ClaimCheckEventRepository(ABC):
    @abstractmethod
    def save(self, event: Event) -> None:
        pass

    @abstractmethod
    def get(self, metadata: Metadata) -> bytes:
        pass
