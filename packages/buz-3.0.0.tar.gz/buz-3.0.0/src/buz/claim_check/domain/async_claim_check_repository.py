from abc import ABC, abstractmethod

from buz.event.event import Event
from buz.metadata import Metadata


class AsyncClaimCheckEventRepository(ABC):
    @abstractmethod
    async def save(self, event: Event) -> None:
        pass

    @abstractmethod
    async def get(self, metadata: Metadata) -> bytes:
        pass
