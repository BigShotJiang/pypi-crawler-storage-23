from abc import ABC, abstractmethod

from buz.event.event import Event
from buz.metadata import Metadata


class AsyncClaimCheckManager(ABC):
    @abstractmethod
    async def should_store_event_externally(self, event: Event) -> bool:
        pass

    @abstractmethod
    async def is_event_stored_externally(self, metadata: Metadata) -> bool:
        pass
