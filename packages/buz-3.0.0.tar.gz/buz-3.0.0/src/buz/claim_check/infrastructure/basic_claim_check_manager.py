import dataclasses

import orjson
from pympler.asizeof import asizeof

from buz.claim_check.domain.claim_check_manager import ClaimCheckManager
from buz.event.event import Event

from buz.metadata import Metadata


class BasicClaimCheckManager(ClaimCheckManager):
    CLAIM_CHECK_REF_KEY = "event_payload_source"

    def __init__(
        self,
        event_size_threshold_in_bytes: int,
        allowed_fqn_for_claim_check: list[str] | None = None,
    ) -> None:
        self.__event_size_threshold_in_bytes = event_size_threshold_in_bytes
        self.__allowed_fqn_for_claim_check = allowed_fqn_for_claim_check

    def should_store_event_externally(self, event: Event) -> bool:
        return self.__is_big_event(event) and self.__is_allowed_event(event)

    def __is_allowed_event(self, event: Event) -> bool:
        if self.__allowed_fqn_for_claim_check is None:
            return True
        return event.fqn() in self.__allowed_fqn_for_claim_check

    def __is_big_event(self, event: Event) -> bool:
        payload_size = self.__extract_event_event_size(event)
        return payload_size >= self.__event_size_threshold_in_bytes

    def is_event_stored_externally(self, metadata: Metadata) -> bool:
        external_storage_metadata = metadata.get(self.CLAIM_CHECK_REF_KEY)
        return isinstance(external_storage_metadata, dict)

    # TODO: for the moment is the best way that we have to calculate the size of the event, it is only an estimation.
    def __extract_event_event_size(self, event: Event) -> int:
        payload = dataclasses.asdict(event)
        return asizeof(orjson.dumps(payload))
