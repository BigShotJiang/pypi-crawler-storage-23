from buz.claim_check.domain.async_claim_check_manager import AsyncClaimCheckManager
from buz.claim_check.infrastructure.basic_claim_check_manager import BasicClaimCheckManager
from buz.event.event import Event

from buz.metadata import Metadata


class AsyncBasicClaimCheckManager(AsyncClaimCheckManager):
    "This class is a wrapper around the BasicClaimCheckManager to make it async. in the future we can have a more complex claim check manager that is async but for the moment this is not necessary."

    CLAIM_CHECK_REF_KEY = "event_payload_source"

    def __init__(
        self,
        event_size_threshold_in_bytes: int,
        allowed_fqn_for_claim_check: list[str] | None = None,
    ) -> None:
        self.__claim_check_manager = BasicClaimCheckManager(
            event_size_threshold_in_bytes=event_size_threshold_in_bytes,
            allowed_fqn_for_claim_check=allowed_fqn_for_claim_check,
        )

    async def should_store_event_externally(self, event: Event) -> bool:
        return self.__claim_check_manager.should_store_event_externally(event)

    async def is_event_stored_externally(self, metadata: Metadata) -> bool:
        return self.__claim_check_manager.is_event_stored_externally(metadata)
