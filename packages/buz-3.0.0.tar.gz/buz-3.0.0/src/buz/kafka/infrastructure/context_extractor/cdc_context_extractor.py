from logging import Logger

from buz.event.infrastructure.buz_kafka.models.cdc_process_context import CDCProcessContext
from buz.event.infrastructure.models.process_context import ProcessContext
from buz.kafka.domain.services.context_extractor import ContextExtractor
from buz.kafka.infrastructure.deserializers.implementations.cdc.cdc_record_bytes_to_cdc_payload_deserializer import (
    CDCRecordBytesToCDCPayloadDeserializer,
)


class CDCContextExtractor(ContextExtractor):
    def __init__(
        self,
        *,
        cdc_payload_deserializer: CDCRecordBytesToCDCPayloadDeserializer,
        logger: Logger,
    ) -> None:
        self.__cdc_payload_deserializer = cdc_payload_deserializer
        self.__logger = logger

    async def extract_process_context(self, data: bytes) -> ProcessContext:
        deserialized_cdc_payload = await self.__cdc_payload_deserializer.deserialize(data)
        return CDCProcessContext(
            captured_at_ms=deserialized_cdc_payload.captured_at_ms,
        )
