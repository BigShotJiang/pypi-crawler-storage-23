from __future__ import annotations

from datetime import datetime
from logging import Logger
from typing import Optional, TypeVar, Type, Generic

import orjson

from buz.claim_check.domain.async_claim_check_repository import AsyncClaimCheckEventRepository
from buz.event import Event
from buz.kafka.infrastructure.cdc.cdc_message import CDCPayload
from buz.kafka.infrastructure.deserializers.bytes_to_message_deserializer import BytesToMessageDeserializer
from buz.claim_check.domain.async_claim_check_manager import AsyncClaimCheckManager
from buz.kafka.infrastructure.deserializers.implementations.cdc.cannot_restore_event_from_cdc_payload_exception import (
    CannotRestoreEventFromCDCPayloadException,
)
from buz.kafka.infrastructure.deserializers.implementations.cdc.cdc_record_bytes_to_cdc_payload_deserializer import (
    CDCRecordBytesToCDCPayloadDeserializer,
)
from buz.metadata import Metadata

T = TypeVar("T", bound=Event)


class CDCRecordBytesClaimCheckToEventDeserializer(BytesToMessageDeserializer[Event], Generic[T]):
    __STRING_ENCODING = "utf-8"

    def __init__(
        self,
        logger: Logger,
        event_class: Type[T],
        cdc_payload_deserializer: CDCRecordBytesToCDCPayloadDeserializer,
        claim_check_manager: AsyncClaimCheckManager,
        claim_check_repository: AsyncClaimCheckEventRepository,
    ) -> None:
        self.__event_class = event_class
        self.__cdc_record_bytes_to_cdc_payload_deserializer = cdc_payload_deserializer
        self.__claim_check_manager = claim_check_manager
        self.__claim_check_repository = claim_check_repository
        self.__logger = logger

    async def deserialize(self, data: bytes) -> T:
        cdc_payload = await self.__cdc_record_bytes_to_cdc_payload_deserializer.deserialize(data)
        try:
            metadata = self.__extract_metadata(cdc_payload.metadata)
            payload = await self.__extract_event_payload(cdc_payload, metadata)

            return self.__event_class.restore(
                id=cdc_payload.event_id,
                created_at=self.__get_created_at_in_event_format(cdc_payload.created_at),
                metadata=metadata,
                **payload,
            )
        except Exception as exception:
            self.__logger.error(f"Error deserializing event: {exception}")
            raise CannotRestoreEventFromCDCPayloadException(cdc_payload, exception) from exception

    def __get_created_at_in_event_format(self, cdc_payload_created_at: str) -> str:
        created_at_datetime = datetime.strptime(cdc_payload_created_at, CDCPayload.DATE_TIME_FORMAT)
        return created_at_datetime.strftime(Event.DATE_TIME_FORMAT)

    def __extract_metadata(self, metadata: Optional[str]) -> Metadata:
        if metadata is None:
            return {}
        raw_metadata = orjson.loads(metadata)

        return Metadata(**raw_metadata)

    async def __extract_event_payload(self, cdc_payload: CDCPayload, metadata: Metadata) -> dict:
        if await self.__claim_check_manager.is_event_stored_externally(metadata):
            raw_payload = await self.__claim_check_repository.get(metadata)
            return orjson.loads(raw_payload)

        return orjson.loads(cdc_payload.payload)
