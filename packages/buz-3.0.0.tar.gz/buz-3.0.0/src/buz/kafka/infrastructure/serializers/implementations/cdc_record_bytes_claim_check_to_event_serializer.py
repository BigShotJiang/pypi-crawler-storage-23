from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
from typing import Optional

from buz.claim_check.domain.claim_check_manager import ClaimCheckManager
from buz.claim_check.domain.claim_check_repository import ClaimCheckEventRepository
from buz.event import Event
from buz.kafka.infrastructure.cdc.cdc_message import CDCMessage, CDCPayload
from buz.kafka.infrastructure.cdc.cdc_schema import generate_cdc_schema
from buz.kafka.infrastructure.serializers.byte_serializer import ByteSerializer
from buz.kafka.infrastructure.serializers.implementations.json_byte_serializer import JSONByteSerializer


class CDCRecordBytesClaimCheckToEventSerializer(ByteSerializer):
    def __init__(
        self,
        claim_check_manager: ClaimCheckManager,
        claim_check_repository: ClaimCheckEventRepository,
    ) -> None:
        self.__json_serializer = JSONByteSerializer()
        self.__claim_check_manager = claim_check_manager
        self.__claim_check_repository = claim_check_repository

    def serialize(self, data: Event) -> bytes:
        cdc_message: CDCMessage = CDCMessage(
            payload=CDCPayload(
                event_id=data.id,
                created_at=self.__adapt_created_to_cdc_format(data.created_at),
                event_fqn=data.fqn(),
                payload=self.__serialize_payload(data),
                metadata=self.__serialize_metadata(data),
            ),
            schema=generate_cdc_schema(data),
        )
        return self.__json_serializer.serialize(asdict(cdc_message))

    def __adapt_created_to_cdc_format(self, created_at: str) -> str:
        created_at_datetime = datetime.strptime(created_at, Event.DATE_TIME_FORMAT)
        return created_at_datetime.strftime(CDCPayload.DATE_TIME_FORMAT)

    def __serialize_payload(self, event: Event) -> str:
        if self.__claim_check_manager.should_store_event_externally(event):
            if self.__claim_check_manager.is_event_stored_externally(event.metadata):
                return self.__json_serializer.serialize_as_json({})

            self.__claim_check_repository.save(event)
            return self.__json_serializer.serialize_as_json({})

        payload = event.extract_event_payload()
        return self.__json_serializer.serialize_as_json(payload)

    def __serialize_metadata(self, event: Event) -> Optional[str]:
        return self.__json_serializer.serialize_as_json(event.metadata)  # type: ignore[arg-type]
