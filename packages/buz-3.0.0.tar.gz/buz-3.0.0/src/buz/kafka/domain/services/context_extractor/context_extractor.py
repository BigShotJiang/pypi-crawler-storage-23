from abc import ABC, abstractmethod
from buz.event.infrastructure.models.process_context import ProcessContext


class ContextExtractor(ABC):
    @abstractmethod
    async def extract_process_context(self, data: bytes) -> ProcessContext:
        pass
