from diona.firstmeet.hello import hello_diona

def test_hello_diona():
    hello_diona()

if __name__ == "__main__":
    test_hello_diona()