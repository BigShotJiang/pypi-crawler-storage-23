#!/usr/bin/env python3
"""
Test script for HashFS encapsulation
"""

import os
import sys
import tempfile

# Add src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from diona.storage.hashfs import HashFS, HashAddress

def test_hashfs_encapsulation():
    """Test HashFS encapsulation"""
    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        print(f"Testing HashFS in temporary directory: {temp_dir}")
        
        # Test 1: Create HashFS instance
        fs = HashFS(temp_dir)
        print("✓ HashFS instance created successfully")
        
        # Test 2: Store a file
        test_content = b"Hello, HashFS!"
        test_file = os.path.join(temp_dir, "test.txt")
        with open(test_file, "wb") as f:
            f.write(test_content)
        
        address = fs.put(test_file)
        print(f"✓ File stored successfully, ID: {address.id}")
        print(f"  Relative path: {address.relpath}")
        print(f"  Absolute path: {address.abspath}")
        
        # Test 3: Get the file
        retrieved_address = fs.get(address.id)
        print(f"✓ File retrieved successfully, ID: {retrieved_address.id}")
        
        # Test 4: Open the file
        with fs.open(address.id, "rb") as f:
            content = f.read()
        print(f"✓ File opened successfully, content: {content.decode()}")
        
        # Test 5: Check if file exists
        exists = fs.exists(address.id)
        print(f"✓ File existence check: {exists}")
        
        # Test 6: Get file count
        count = fs.count()
        print(f"✓ File count: {count}")
        
        # Test 7: Get file size
        size = fs.size()
        print(f"✓ Total size: {size} bytes")
        
        # Test 8: Delete the file
        fs.delete(address.id)
        print("✓ File deleted successfully")
        
        # Test 9: Check if file no longer exists
        exists_after_delete = fs.exists(address.id)
        print(f"✓ File existence check after delete: {exists_after_delete}")
        
        print("\nAll tests passed successfully!")

if __name__ == "__main__":
    test_hashfs_encapsulation()