# diona

A Python package named diona.

## Installation

```bash
pip install diona
```

## Usage

```python
import diona

print(diona.__version__)
```

## Development

```bash
pip install -e .
```
