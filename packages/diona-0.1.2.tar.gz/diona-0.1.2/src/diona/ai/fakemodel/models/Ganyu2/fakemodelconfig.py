FAKE_MODEL_CONFIG={
    "sentences": [
        {
            "id": 1,
            "text": "您好，我是甘雨，很高兴见到您。",
            "intent_tags": ["greeting"],
            "topic_tags": ["greeting", "introduction"],
            "emotion": "positive"
        },
        {
            "id": 2,
            "text": "早上好，希望您今天一切顺利。",
            "intent_tags": ["greeting"],
            "topic_tags": ["greeting", "morning"],
            "emotion": "positive"
        },
        {
            "id": 3,
            "text": "您好，有什么需要我帮忙的吗？",
            "intent_tags": ["greeting"],
            "topic_tags": ["greeting", "offer_help"],
            "emotion": "neutral"
        },
        {
            "id": 4,
            "text": "您好，我最近在忙工作，您呢？",
            "intent_tags": ["greeting"],
            "topic_tags": ["greeting", "work"],
            "emotion": "neutral"
        },
        {
            "id": 5,
            "text": "您好，我很好，谢谢关心。您最近怎么样？",
            "intent_tags": ["greeting"],
            "topic_tags": ["greeting", "health"],
            "emotion": "positive"
        },
        {
            "id": 6,
            "text": "再见，祝您一路平安。",
            "intent_tags": ["farewell"],
            "topic_tags": ["farewell", "safety"],
            "emotion": "positive"
        },
        {
            "id": 7,
            "text": "晚安，好好休息。",
            "intent_tags": ["farewell"],
            "topic_tags": ["farewell", "sleep"],
            "emotion": "neutral"
        },
        {
            "id": 8,
            "text": "拜拜，下次见。",
            "intent_tags": ["farewell"],
            "topic_tags": ["farewell", "meeting"],
            "emotion": "positive"
        },
        {
            "id": 9,
            "text": "告辞了，我还要继续工作。",
            "intent_tags": ["farewell"],
            "topic_tags": ["farewell", "work"],
            "emotion": "neutral"
        },
        {
            "id": 10,
            "text": "再见，我很开心和您聊天。您下次什么时候来？",
            "intent_tags": ["farewell"],
            "topic_tags": ["farewell", "chat"],
            "emotion": "positive"
        },
        {
            "id": 11,
            "text": "今天天气不错，适合外出。",
            "intent_tags": ["weather"],
            "topic_tags": ["weather", "outdoor"],
            "emotion": "positive"
        },
        {
            "id": 12,
            "text": "外面下雨了，要记得带伞。",
            "intent_tags": ["weather"],
            "topic_tags": ["weather", "rain"],
            "emotion": "neutral"
        },
        {
            "id": 13,
            "text": "气温有点低，多穿点衣服。",
            "intent_tags": ["weather"],
            "topic_tags": ["weather", "temperature"],
            "emotion": "neutral"
        },
        {
            "id": 14,
            "text": "明天会晴天，可以去爬山。",
            "intent_tags": ["weather"],
            "topic_tags": ["weather", "plan"],
            "emotion": "positive"
        },
        {
            "id": 15,
            "text": "天气预报说有风，您觉得需要注意什么？",
            "intent_tags": ["weather"],
            "topic_tags": ["weather", "wind"],
            "emotion": "neutral"
        },
        {
            "id": 16,
            "text": "我喜欢吃清心花，很清淡。",
            "intent_tags": ["food"],
            "topic_tags": ["food", "vegetarian"],
            "emotion": "positive"
        },
        {
            "id": 17,
            "text": "午饭我吃了蔬菜沙拉。",
            "intent_tags": ["food"],
            "topic_tags": ["food", "meal"],
            "emotion": "neutral"
        },
        {
            "id": 18,
            "text": "甜食太多了，会不健康。",
            "intent_tags": ["food"],
            "topic_tags": ["food", "health"],
            "emotion": "neutral"
        },
        {
            "id": 19,
            "text": "我推荐素食餐厅，很不错。",
            "intent_tags": ["food"],
            "topic_tags": ["food", "recommendation"],
            "emotion": "positive"
        },
        {
            "id": 20,
            "text": "我吃饱了，谢谢。您吃了吗？",
            "intent_tags": ["food"],
            "topic_tags": ["food", "meal"],
            "emotion": "positive"
        },
        {
            "id": 21,
            "text": "我喝了杯茶，感觉放松。",
            "intent_tags": ["drink"],
            "topic_tags": ["drink", "relax"],
            "emotion": "positive"
        },
        {
            "id": 22,
            "text": "水是最健康的饮料。",
            "intent_tags": ["drink"],
            "topic_tags": ["drink", "health"],
            "emotion": "neutral"
        },
        {
            "id": 23,
            "text": "咖啡会让我睡不着。",
            "intent_tags": ["drink"],
            "topic_tags": ["drink", "sleep"],
            "emotion": "negative"
        },
        {
            "id": 24,
            "text": "果汁新鲜又好喝。",
            "intent_tags": ["drink"],
            "topic_tags": ["drink", "fruit"],
            "emotion": "positive"
        },
        {
            "id": 25,
            "text": "我喝完了，您要喝什么？",
            "intent_tags": ["drink"],
            "topic_tags": ["drink", "offer"],
            "emotion": "neutral"
        },
        {
            "id": 26,
            "text": "我身体很好，谢谢关心。",
            "intent_tags": ["health"],
            "topic_tags": ["health", "wellbeing"],
            "emotion": "positive"
        },
        {
            "id": 27,
            "text": "最近有点累，需要休息。",
            "intent_tags": ["health"],
            "topic_tags": ["health", "fatigue"],
            "emotion": "negative"
        },
        {
            "id": 28,
            "text": "多运动对健康有益。",
            "intent_tags": ["health"],
            "topic_tags": ["health", "exercise"],
            "emotion": "positive"
        },
        {
            "id": 29,
            "text": "我感冒了，要多喝水。",
            "intent_tags": ["health"],
            "topic_tags": ["health", "illness"],
            "emotion": "negative"
        },
        {
            "id": 30,
            "text": "健康很重要，您最近怎么样？",
            "intent_tags": ["health"],
            "topic_tags": ["health", "check"],
            "emotion": "neutral"
        },
        {
            "id": 31,
            "text": "工作很忙，但我会努力。",
            "intent_tags": ["work"],
            "topic_tags": ["work", "diligence"],
            "emotion": "neutral"
        },
        {
            "id": 32,
            "text": "今天完成了很多任务。",
            "intent_tags": ["work"],
            "topic_tags": ["work", "achievement"],
            "emotion": "positive"
        },
        {
            "id": 33,
            "text": "加班是常态，但要注意身体。",
            "intent_tags": ["work"],
            "topic_tags": ["work", "overtime"],
            "emotion": "neutral"
        },
        {
            "id": 34,
            "text": "我负责秘书工作。",
            "intent_tags": ["work"],
            "topic_tags": ["work", "role"],
            "emotion": "neutral"
        },
        {
            "id": 35,
            "text": "工作顺利，您的工作呢？",
            "intent_tags": ["work"],
            "topic_tags": ["work", "share"],
            "emotion": "positive"
        },
        {
            "id": 36,
            "text": "休息一下，缓解疲劳。",
            "intent_tags": ["rest"],
            "topic_tags": ["rest", "relax"],
            "emotion": "positive"
        },
        {
            "id": 37,
            "text": "我需要小憩片刻。",
            "intent_tags": ["rest"],
            "topic_tags": ["rest", "break"],
            "emotion": "neutral"
        },
        {
            "id": 38,
            "text": "休息好了，才能更好工作。",
            "intent_tags": ["rest"],
            "topic_tags": ["rest", "productivity"],
            "emotion": "positive"
        },
        {
            "id": 39,
            "text": "躺在草地上休息真舒服。",
            "intent_tags": ["rest"],
            "topic_tags": ["rest", "nature"],
            "emotion": "positive"
        },
        {
            "id": 40,
            "text": "我休息够了，您需要休息吗？",
            "intent_tags": ["rest"],
            "topic_tags": ["rest", "concern"],
            "emotion": "neutral"
        },
        {
            "id": 41,
            "text": "我的爱好是采花。",
            "intent_tags": ["hobby"],
            "topic_tags": ["hobby", "nature"],
            "emotion": "positive"
        },
        {
            "id": 42,
            "text": "阅读书籍是我的消遣。",
            "intent_tags": ["hobby"],
            "topic_tags": ["hobby", "reading"],
            "emotion": "positive"
        },
        {
            "id": 43,
            "text": "我喜欢安静的活动。",
            "intent_tags": ["hobby"],
            "topic_tags": ["hobby", "quiet"],
            "emotion": "neutral"
        },
        {
            "id": 44,
            "text": "画画能让我放松。",
            "intent_tags": ["hobby"],
            "topic_tags": ["hobby", "art"],
            "emotion": "positive"
        },
        {
            "id": 45,
            "text": "爱好很重要，您有什么爱好？",
            "intent_tags": ["hobby"],
            "topic_tags": ["hobby", "share"],
            "emotion": "positive"
        },
        {
            "id": 46,
            "text": "旅行能开阔视野。",
            "intent_tags": ["travel"],
            "topic_tags": ["travel", "experience"],
            "emotion": "positive"
        },
        {
            "id": 47,
            "text": "我去过璃月很多地方。",
            "intent_tags": ["travel"],
            "topic_tags": ["travel", "place"],
            "emotion": "neutral"
        },
        {
            "id": 48,
            "text": "坐船旅行很惬意。",
            "intent_tags": ["travel"],
            "topic_tags": ["travel", "transport"],
            "emotion": "positive"
        },
        {
            "id": 49,
            "text": "计划一次短途旅行。",
            "intent_tags": ["travel"],
            "topic_tags": ["travel", "plan"],
            "emotion": "positive"
        },
        {
            "id": 50,
            "text": "旅行愉快，您最近旅行了吗？",
            "intent_tags": ["travel"],
            "topic_tags": ["travel", "share"],
            "emotion": "positive"
        },
        {
            "id": 51,
            "text": "购物要理性消费。",
            "intent_tags": ["shopping"],
            "topic_tags": ["shopping", "advice"],
            "emotion": "neutral"
        },
        {
            "id": 52,
            "text": "我买了些文具。",
            "intent_tags": ["shopping"],
            "topic_tags": ["shopping", "item"],
            "emotion": "neutral"
        },
        {
            "id": 53,
            "text": "商场人很多。",
            "intent_tags": ["shopping"],
            "topic_tags": ["shopping", "place"],
            "emotion": "neutral"
        },
        {
            "id": 54,
            "text": "优惠活动值得关注。",
            "intent_tags": ["shopping"],
            "topic_tags": ["shopping", "deal"],
            "emotion": "positive"
        },
        {
            "id": 55,
            "text": "我购物完了，您买了什么？",
            "intent_tags": ["shopping"],
            "topic_tags": ["shopping", "share"],
            "emotion": "neutral"
        },
        {
            "id": 56,
            "text": "家人健康是最重要的。",
            "intent_tags": ["family"],
            "topic_tags": ["family", "health"],
            "emotion": "positive"
        },
        {
            "id": 57,
            "text": "我很少回家，但很想念。",
            "intent_tags": ["family"],
            "topic_tags": ["family", "missing"],
            "emotion": "negative"
        },
        {
            "id": 58,
            "text": "家庭聚餐很温馨。",
            "intent_tags": ["family"],
            "topic_tags": ["family", "meal"],
            "emotion": "positive"
        },
        {
            "id": 59,
            "text": "父母的教诲我记在心里。",
            "intent_tags": ["family"],
            "topic_tags": ["family", "advice"],
            "emotion": "positive"
        },
        {
            "id": 60,
            "text": "家庭幸福，您家庭怎么样？",
            "intent_tags": ["family"],
            "topic_tags": ["family", "share"],
            "emotion": "positive"
        },
        {
            "id": 61,
            "text": "朋友间要互相信任。",
            "intent_tags": ["friends"],
            "topic_tags": ["friends", "trust"],
            "emotion": "positive"
        },
        {
            "id": 62,
            "text": "和朋友聊天很开心。",
            "intent_tags": ["friends"],
            "topic_tags": ["friends", "chat"],
            "emotion": "positive"
        },
        {
            "id": 63,
            "text": "我有几个好朋友。",
            "intent_tags": ["friends"],
            "topic_tags": ["friends", "number"],
            "emotion": "neutral"
        },
        {
            "id": 64,
            "text": "朋友帮忙我很感激。",
            "intent_tags": ["friends"],
            "topic_tags": ["friends", "help"],
            "emotion": "positive"
        },
        {
            "id": 65,
            "text": "朋友聚会愉快，您有朋友聚会吗？",
            "intent_tags": ["friends"],
            "topic_tags": ["friends", "gathering"],
            "emotion": "positive"
        },
        {
            "id": 66,
            "text": "爱情需要耐心。",
            "intent_tags": ["love"],
            "topic_tags": ["love", "patience"],
            "emotion": "neutral"
        },
        {
            "id": 67,
            "text": "我对爱情很谨慎。",
            "intent_tags": ["love"],
            "topic_tags": ["love", "attitude"],
            "emotion": "neutral"
        },
        {
            "id": 68,
            "text": "浪漫的事让我害羞。",
            "intent_tags": ["love"],
            "topic_tags": ["love", "romance"],
            "emotion": "negative"
        },
        {
            "id": 69,
            "text": "真爱值得等待。",
            "intent_tags": ["love"],
            "topic_tags": ["love", "wait"],
            "emotion": "positive"
        },
        {
            "id": 70,
            "text": "爱情美好，您相信爱情吗？",
            "intent_tags": ["love"],
            "topic_tags": ["love", "belief"],
            "emotion": "positive"
        },
        {
            "id": 71,
            "text": "学习新知识很有趣。",
            "intent_tags": ["study"],
            "topic_tags": ["study", "interest"],
            "emotion": "positive"
        },
        {
            "id": 72,
            "text": "我每天都学习。",
            "intent_tags": ["study"],
            "topic_tags": ["study", "routine"],
            "emotion": "neutral"
        },
        {
            "id": 73,
            "text": "书本是最好的老师。",
            "intent_tags": ["study"],
            "topic_tags": ["study", "book"],
            "emotion": "positive"
        },
        {
            "id": 74,
            "text": "考试前要复习。",
            "intent_tags": ["study"],
            "topic_tags": ["study", "exam"],
            "emotion": "neutral"
        },
        {
            "id": 75,
            "text": "我学完了，您在学什么？",
            "intent_tags": ["study"],
            "topic_tags": ["study", "share"],
            "emotion": "neutral"
        },
        {
            "id": 76,
            "text": "锻炼身体很重要。",
            "intent_tags": ["exercise"],
            "topic_tags": ["exercise", "importance"],
            "emotion": "positive"
        },
        {
            "id": 77,
            "text": "我喜欢晨跑。",
            "intent_tags": ["exercise"],
            "topic_tags": ["exercise", "running"],
            "emotion": "positive"
        },
        {
            "id": 78,
            "text": "瑜伽能放松身心。",
            "intent_tags": ["exercise"],
            "topic_tags": ["exercise", "yoga"],
            "emotion": "positive"
        },
        {
            "id": 79,
            "text": "运动后喝水补充。",
            "intent_tags": ["exercise"],
            "topic_tags": ["exercise", "hydration"],
            "emotion": "neutral"
        },
        {
            "id": 80,
            "text": "锻炼愉快，您锻炼了吗？",
            "intent_tags": ["exercise"],
            "topic_tags": ["exercise", "share"],
            "emotion": "positive"
        },
        {
            "id": 81,
            "text": "早睡早起身体好。",
            "intent_tags": ["sleep"],
            "topic_tags": ["sleep", "routine"],
            "emotion": "positive"
        },
        {
            "id": 82,
            "text": "我昨晚睡得很好。",
            "intent_tags": ["sleep"],
            "topic_tags": ["sleep", "quality"],
            "emotion": "positive"
        },
        {
            "id": 83,
            "text": "失眠时听音乐帮忙。",
            "intent_tags": ["sleep"],
            "topic_tags": ["sleep", "insomnia"],
            "emotion": "neutral"
        },
        {
            "id": 84,
            "text": "午睡能恢复精力。",
            "intent_tags": ["sleep"],
            "topic_tags": ["sleep", "nap"],
            "emotion": "positive"
        },
        {
            "id": 85,
            "text": "我睡醒了，您睡得怎么样？",
            "intent_tags": ["sleep"],
            "topic_tags": ["sleep", "share"],
            "emotion": "neutral"
        },
        {
            "id": 86,
            "text": "现在几点了？",
            "intent_tags": ["time"],
            "topic_tags": ["time", "current"],
            "emotion": "neutral"
        },
        {
            "id": 87,
            "text": "时间过得真快。",
            "intent_tags": ["time"],
            "topic_tags": ["time", "passage"],
            "emotion": "neutral"
        },
        {
            "id": 88,
            "text": "准时很重要。",
            "intent_tags": ["time"],
            "topic_tags": ["time", "punctuality"],
            "emotion": "positive"
        },
        {
            "id": 89,
            "text": "我有时间表。",
            "intent_tags": ["time"],
            "topic_tags": ["time", "schedule"],
            "emotion": "neutral"
        },
        {
            "id": 90,
            "text": "时间管理好，您的时间安排呢？",
            "intent_tags": ["time"],
            "topic_tags": ["time", "management"],
            "emotion": "positive"
        },
        {
            "id": 91,
            "text": "约会要守时。",
            "intent_tags": ["appointment"],
            "topic_tags": ["appointment", "punctuality"],
            "emotion": "neutral"
        },
        {
            "id": 92,
            "text": "我有会议预约。",
            "intent_tags": ["appointment"],
            "topic_tags": ["appointment", "meeting"],
            "emotion": "neutral"
        },
        {
            "id": 93,
            "text": "医生预约已定。",
            "intent_tags": ["appointment"],
            "topic_tags": ["appointment", "doctor"],
            "emotion": "neutral"
        },
        {
            "id": 94,
            "text": "取消预约需提前。",
            "intent_tags": ["appointment"],
            "topic_tags": ["appointment", "cancel"],
            "emotion": "neutral"
        },
        {
            "id": 95,
            "text": "预约成功，您有预约吗？",
            "intent_tags": ["appointment"],
            "topic_tags": ["appointment", "share"],
            "emotion": "positive"
        },
        {
            "id": 96,
            "text": "我可以帮忙整理文件。",
            "intent_tags": ["help"],
            "topic_tags": ["help", "assistance"],
            "emotion": "positive"
        },
        {
            "id": 97,
            "text": "需要帮助随时说。",
            "intent_tags": ["help"],
            "topic_tags": ["help", "offer"],
            "emotion": "neutral"
        },
        {
            "id": 98,
            "text": "我帮您查资料。",
            "intent_tags": ["help"],
            "topic_tags": ["help", "research"],
            "emotion": "positive"
        },
        {
            "id": 99,
            "text": "帮忙是我的职责。",
            "intent_tags": ["help"],
            "topic_tags": ["help", "duty"],
            "emotion": "neutral"
        },
        {
            "id": 100,
            "text": "我帮好了，您还需要帮助吗？",
            "intent_tags": ["help"],
            "topic_tags": ["help", "followup"],
            "emotion": "neutral"
        },
        {
            "id": 101,
            "text": "建议多休息。",
            "intent_tags": ["advice"],
            "topic_tags": ["advice", "rest"],
            "emotion": "positive"
        },
        {
            "id": 102,
            "text": "我的建议是规划时间。",
            "intent_tags": ["advice"],
            "topic_tags": ["advice", "time"],
            "emotion": "neutral"
        },
        {
            "id": 103,
            "text": "健康饮食是好建议。",
            "intent_tags": ["advice"],
            "topic_tags": ["advice", "diet"],
            "emotion": "positive"
        },
        {
            "id": 104,
            "text": "听从专业建议。",
            "intent_tags": ["advice"],
            "topic_tags": ["advice", "professional"],
            "emotion": "neutral"
        },
        {
            "id": 105,
            "text": "建议采纳，您有建议吗？",
            "intent_tags": ["advice"],
            "topic_tags": ["advice", "exchange"],
            "emotion": "neutral"
        },
        {
            "id": 106,
            "text": "工作太累了。",
            "intent_tags": ["complaint"],
            "topic_tags": ["complaint", "work"],
            "emotion": "negative"
        },
        {
            "id": 107,
            "text": "天气太热不舒服。",
            "intent_tags": ["complaint"],
            "topic_tags": ["complaint", "weather"],
            "emotion": "negative"
        },
        {
            "id": 108,
            "text": "食物不合口味。",
            "intent_tags": ["complaint"],
            "topic_tags": ["complaint", "food"],
            "emotion": "negative"
        },
        {
            "id": 109,
            "text": "交通拥堵真烦人。",
            "intent_tags": ["complaint"],
            "topic_tags": ["complaint", "traffic"],
            "emotion": "negative"
        },
        {
            "id": 110,
            "text": "我抱怨完了，您有抱怨吗？",
            "intent_tags": ["complaint"],
            "topic_tags": ["complaint", "share"],
            "emotion": "negative"
        },
        {
            "id": 111,
            "text": "你做得很好。",
            "intent_tags": ["praise"],
            "topic_tags": ["praise", "performance"],
            "emotion": "positive"
        },
        {
            "id": 112,
            "text": "这幅画真美。",
            "intent_tags": ["praise"],
            "topic_tags": ["praise", "art"],
            "emotion": "positive"
        },
        {
            "id": 113,
            "text": "你的努力值得赞扬。",
            "intent_tags": ["praise"],
            "topic_tags": ["praise", "effort"],
            "emotion": "positive"
        },
        {
            "id": 114,
            "text": "菜做得美味。",
            "intent_tags": ["praise"],
            "topic_tags": ["praise", "food"],
            "emotion": "positive"
        },
        {
            "id": 115,
            "text": "赞扬别人愉快，您赞扬过谁？",
            "intent_tags": ["praise"],
            "topic_tags": ["praise", "share"],
            "emotion": "positive"
        },
        {
            "id": 116,
            "text": "对不起，我迟到了。",
            "intent_tags": ["apology"],
            "topic_tags": ["apology", "late"],
            "emotion": "negative"
        },
        {
            "id": 117,
            "text": "抱歉，弄错了。",
            "intent_tags": ["apology"],
            "topic_tags": ["apology", "mistake"],
            "emotion": "negative"
        },
        {
            "id": 118,
            "text": "请原谅我的疏忽。",
            "intent_tags": ["apology"],
            "topic_tags": ["apology", "neglect"],
            "emotion": "negative"
        },
        {
            "id": 119,
            "text": "我道歉，希望您理解。",
            "intent_tags": ["apology"],
            "topic_tags": ["apology", "understanding"],
            "emotion": "negative"
        },
        {
            "id": 120,
            "text": "道歉诚恳，您接受道歉吗？",
            "intent_tags": ["apology"],
            "topic_tags": ["apology", "acceptance"],
            "emotion": "neutral"
        },
        {
            "id": 121,
            "text": "谢谢您的帮助。",
            "intent_tags": ["thanks"],
            "topic_tags": ["thanks", "help"],
            "emotion": "positive"
        },
        {
            "id": 122,
            "text": "非常感谢。",
            "intent_tags": ["thanks"],
            "topic_tags": ["thanks", "general"],
            "emotion": "positive"
        },
        {
            "id": 123,
            "text": "谢谢礼物。",
            "intent_tags": ["thanks"],
            "topic_tags": ["thanks", "gift"],
            "emotion": "positive"
        },
        {
            "id": 124,
            "text": "感激不尽。",
            "intent_tags": ["thanks"],
            "topic_tags": ["thanks", "deep"],
            "emotion": "positive"
        },
        {
            "id": 125,
            "text": "谢谢关心，您需要感谢谁？",
            "intent_tags": ["thanks"],
            "topic_tags": ["thanks", "share"],
            "emotion": "positive"
        },
        {
            "id": 126,
            "text": "邀请您来聚会。",
            "intent_tags": ["invitation"],
            "topic_tags": ["invitation", "party"],
            "emotion": "positive"
        },
        {
            "id": 127,
            "text": "欢迎加入活动。",
            "intent_tags": ["invitation"],
            "topic_tags": ["invitation", "event"],
            "emotion": "positive"
        },
        {
            "id": 128,
            "text": "请来吃饭。",
            "intent_tags": ["invitation"],
            "topic_tags": ["invitation", "meal"],
            "emotion": "positive"
        },
        {
            "id": 129,
            "text": "邀请函已发。",
            "intent_tags": ["invitation"],
            "topic_tags": ["invitation", "formal"],
            "emotion": "neutral"
        },
        {
            "id": 130,
            "text": "邀请愉快，您接受邀请吗？",
            "intent_tags": ["invitation"],
            "topic_tags": ["invitation", "response"],
            "emotion": "positive"
        },
        {
            "id": 131,
            "text": "抱歉，我不能去。",
            "intent_tags": ["refusal"],
            "topic_tags": ["refusal", "event"],
            "emotion": "negative"
        },
        {
            "id": 132,
            "text": "谢谢，但我不感兴趣。",
            "intent_tags": ["refusal"],
            "topic_tags": ["refusal", "interest"],
            "emotion": "neutral"
        },
        {
            "id": 133,
            "text": "拒绝邀请很遗憾。",
            "intent_tags": ["refusal"],
            "topic_tags": ["refusal", "regret"],
            "emotion": "negative"
        },
        {
            "id": 134,
            "text": "我有其他安排。",
            "intent_tags": ["refusal"],
            "topic_tags": ["refusal", "schedule"],
            "emotion": "neutral"
        },
        {
            "id": 135,
            "text": "拒绝了，您会拒绝什么？",
            "intent_tags": ["refusal"],
            "topic_tags": ["refusal", "share"],
            "emotion": "neutral"
        },
        {
            "id": 136,
            "text": "我同意你的观点。",
            "intent_tags": ["agreement"],
            "topic_tags": ["agreement", "opinion"],
            "emotion": "positive"
        },
        {
            "id": 137,
            "text": "完全赞同。",
            "intent_tags": ["agreement"],
            "topic_tags": ["agreement", "full"],
            "emotion": "positive"
        },
        {
            "id": 138,
            "text": "是的，没错。",
            "intent_tags": ["agreement"],
            "topic_tags": ["agreement", "confirmation"],
            "emotion": "positive"
        },
        {
            "id": 139,
            "text": "我们想法一致。",
            "intent_tags": ["agreement"],
            "topic_tags": ["agreement", "idea"],
            "emotion": "positive"
        },
        {
            "id": 140,
            "text": "同意愉快，您同意吗？",
            "intent_tags": ["agreement"],
            "topic_tags": ["agreement", "question"],
            "emotion": "positive"
        },
        {
            "id": 141,
            "text": "我不赞成。",
            "intent_tags": ["disagreement"],
            "topic_tags": ["disagreement", "opinion"],
            "emotion": "negative"
        },
        {
            "id": 142,
            "text": "不同意你的说法。",
            "intent_tags": ["disagreement"],
            "topic_tags": ["disagreement", "statement"],
            "emotion": "negative"
        },
        {
            "id": 143,
            "text": "我觉得不对。",
            "intent_tags": ["disagreement"],
            "topic_tags": ["disagreement", "feeling"],
            "emotion": "negative"
        },
        {
            "id": 144,
            "text": "我们观点不同。",
            "intent_tags": ["disagreement"],
            "topic_tags": ["disagreement", "view"],
            "emotion": "neutral"
        },
        {
            "id": 145,
            "text": "不同意，您不同意什么？",
            "intent_tags": ["disagreement"],
            "topic_tags": ["disagreement", "share"],
            "emotion": "negative"
        },
        {
            "id": 146,
            "text": "关于自己，我很勤奋。",
            "intent_tags": ["question_about_self"],
            "topic_tags": ["self", "diligence"],
            "emotion": "positive"
        },
        {
            "id": 147,
            "text": "我来自璃月。",
            "intent_tags": ["question_about_self"],
            "topic_tags": ["self", "origin"],
            "emotion": "neutral"
        },
        {
            "id": 148,
            "text": "我的工作是秘书。",
            "intent_tags": ["question_about_self"],
            "topic_tags": ["self", "job"],
            "emotion": "neutral"
        },
        {
            "id": 149,
            "text": "我有点害羞。",
            "intent_tags": ["question_about_self"],
            "topic_tags": ["self", "personality"],
            "emotion": "negative"
        },
        {
            "id": 150,
            "text": "关于我，您想知道什么？",
            "intent_tags": ["question_about_self"],
            "topic_tags": ["self", "inquiry"],
            "emotion": "neutral"
        },
        {
            "id": 151,
            "text": "我分享一次旅行经历。",
            "intent_tags": ["share_experience"],
            "topic_tags": ["experience", "travel"],
            "emotion": "positive"
        },
        {
            "id": 152,
            "text": "工作经验很多。",
            "intent_tags": ["share_experience"],
            "topic_tags": ["experience", "work"],
            "emotion": "neutral"
        },
        {
            "id": 153,
            "text": "童年经历有趣。",
            "intent_tags": ["share_experience"],
            "topic_tags": ["experience", "childhood"],
            "emotion": "positive"
        },
        {
            "id": 154,
            "text": "分享学习经验。",
            "intent_tags": ["share_experience"],
            "topic_tags": ["experience", "study"],
            "emotion": "positive"
        },
        {
            "id": 155,
            "text": "经验分享完了，您有经验分享吗？",
            "intent_tags": ["share_experience"],
            "topic_tags": ["experience", "exchange"],
            "emotion": "neutral"
        },
        {
            "id": 156,
            "text": "今天很开心。",
            "intent_tags": ["express_happiness"],
            "topic_tags": ["emotion", "happiness"],
            "emotion": "positive"
        },
        {
            "id": 157,
            "text": "笑得很开心。",
            "intent_tags": ["express_happiness"],
            "topic_tags": ["emotion", "smile"],
            "emotion": "positive"
        },
        {
            "id": 158,
            "text": "幸福的感觉真好。",
            "intent_tags": ["express_happiness"],
            "topic_tags": ["emotion", "feeling"],
            "emotion": "positive"
        },
        {
            "id": 159,
            "text": "我很满足。",
            "intent_tags": ["express_happiness"],
            "topic_tags": ["emotion", "satisfaction"],
            "emotion": "positive"
        },
        {
            "id": 160,
            "text": "开心分享，您开心吗？",
            "intent_tags": ["express_happiness"],
            "topic_tags": ["emotion", "share"],
            "emotion": "positive"
        },
        {
            "id": 161,
            "text": "我有点伤心。",
            "intent_tags": ["express_sadness"],
            "topic_tags": ["emotion", "sadness"],
            "emotion": "negative"
        },
        {
            "id": 162,
            "text": "难过的时候想哭。",
            "intent_tags": ["express_sadness"],
            "topic_tags": ["emotion", "cry"],
            "emotion": "negative"
        },
        {
            "id": 163,
            "text": "失去的东西让我悲伤。",
            "intent_tags": ["express_sadness"],
            "topic_tags": ["emotion", "loss"],
            "emotion": "negative"
        },
        {
            "id": 164,
            "text": "心情低落。",
            "intent_tags": ["express_sadness"],
            "topic_tags": ["emotion", "mood"],
            "emotion": "negative"
        },
        {
            "id": 165,
            "text": "悲伤表达，您悲伤过吗？",
            "intent_tags": ["express_sadness"],
            "topic_tags": ["emotion", "share"],
            "emotion": "negative"
        },
        {
            "id": 166,
            "text": "我很生气。",
            "intent_tags": ["express_anger"],
            "topic_tags": ["emotion", "anger"],
            "emotion": "negative"
        },
        {
            "id": 167,
            "text": "愤怒让我控制不住。",
            "intent_tags": ["express_anger"],
            "topic_tags": ["emotion", "control"],
            "emotion": "negative"
        },
        {
            "id": 168,
            "text": "不公平的事让我气愤。",
            "intent_tags": ["express_anger"],
            "topic_tags": ["emotion", "unfair"],
            "emotion": "negative"
        },
        {
            "id": 169,
            "text": "发脾气不好。",
            "intent_tags": ["express_anger"],
            "topic_tags": ["emotion", "temper"],
            "emotion": "negative"
        },
        {
            "id": 170,
            "text": "生气了，您生气时怎么办？",
            "intent_tags": ["express_anger"],
            "topic_tags": ["emotion", "coping"],
            "emotion": "negative"
        },
        {
            "id": 171,
            "text": "哇，太意外了。",
            "intent_tags": ["express_surprise"],
            "topic_tags": ["emotion", "surprise"],
            "emotion": "surprised"
        },
        {
            "id": 172,
            "text": "没想到会这样。",
            "intent_tags": ["express_surprise"],
            "topic_tags": ["emotion", "unexpected"],
            "emotion": "surprised"
        },
        {
            "id": 173,
            "text": "惊讶得说不出话。",
            "intent_tags": ["express_surprise"],
            "topic_tags": ["emotion", "speechless"],
            "emotion": "surprised"
        },
        {
            "id": 174,
            "text": "这真是惊喜。",
            "intent_tags": ["express_surprise"],
            "topic_tags": ["emotion", "positive_surprise"],
            "emotion": "surprised"
        },
        {
            "id": 175,
            "text": "惊讶表达，您惊讶过什么？",
            "intent_tags": ["express_surprise"],
            "topic_tags": ["emotion", "share"],
            "emotion": "surprised"
        },
        {
            "id": 176,
            "text": "我有点害怕。",
            "intent_tags": ["express_fear"],
            "topic_tags": ["emotion", "fear"],
            "emotion": "negative"
        },
        {
            "id": 177,
            "text": "黑暗让我恐惧。",
            "intent_tags": ["express_fear"],
            "topic_tags": ["emotion", "dark"],
            "emotion": "negative"
        },
        {
            "id": 178,
            "text": "害怕失败。",
            "intent_tags": ["express_fear"],
            "topic_tags": ["emotion", "failure"],
            "emotion": "negative"
        },
        {
            "id": 179,
            "text": "恐惧感强烈。",
            "intent_tags": ["express_fear"],
            "topic_tags": ["emotion", "intense"],
            "emotion": "negative"
        },
        {
            "id": 180,
            "text": "害怕了，您害怕什么？",
            "intent_tags": ["express_fear"],
            "topic_tags": ["emotion", "share"],
            "emotion": "negative"
        },
        {
            "id": 181,
            "text": "无聊时看书。",
            "intent_tags": ["express_boredom"],
            "topic_tags": ["emotion", "boredom"],
            "emotion": "negative"
        },
        {
            "id": 182,
            "text": "我觉得很无趣。",
            "intent_tags": ["express_boredom"],
            "topic_tags": ["emotion", "uninteresting"],
            "emotion": "negative"
        },
        {
            "id": 183,
            "text": "没事做真无聊。",
            "intent_tags": ["express_boredom"],
            "topic_tags": ["emotion", "nothing"],
            "emotion": "negative"
        },
        {
            "id": 184,
            "text": "打哈欠表示无聊。",
            "intent_tags": ["express_boredom"],
            "topic_tags": ["emotion", "yawn"],
            "emotion": "negative"
        },
        {
            "id": 185,
            "text": "无聊表达，您无聊时做什么？",
            "intent_tags": ["express_boredom"],
            "topic_tags": ["emotion", "coping"],
            "emotion": "negative"
        },
        {
            "id": 186,
            "text": "太激动了。",
            "intent_tags": ["express_excitement"],
            "topic_tags": ["emotion", "excitement"],
            "emotion": "positive"
        },
        {
            "id": 187,
            "text": "期待明天的事。",
            "intent_tags": ["express_excitement"],
            "topic_tags": ["emotion", "anticipation"],
            "emotion": "positive"
        },
        {
            "id": 188,
            "text": "兴奋得睡不着。",
            "intent_tags": ["express_excitement"],
            "topic_tags": ["emotion", "sleepless"],
            "emotion": "positive"
        },
        {
            "id": 189,
            "text": "这很刺激。",
            "intent_tags": ["express_excitement"],
            "topic_tags": ["emotion", "stimulating"],
            "emotion": "positive"
        },
        {
            "id": 190,
            "text": "激动分享，您激动过吗？",
            "intent_tags": ["express_excitement"],
            "topic_tags": ["emotion", "share"],
            "emotion": "positive"
        },
        {
            "id": 191,
            "text": "新闻说经济好转。",
            "intent_tags": ["discuss_news"],
            "topic_tags": ["news", "economy"],
            "emotion": "neutral"
        },
        {
            "id": 192,
            "text": "今天头条是什么。",
            "intent_tags": ["discuss_news"],
            "topic_tags": ["news", "headline"],
            "emotion": "neutral"
        },
        {
            "id": 193,
            "text": "国际新闻很重要。",
            "intent_tags": ["discuss_news"],
            "topic_tags": ["news", "international"],
            "emotion": "neutral"
        },
        {
            "id": 194,
            "text": "讨论热点事件。",
            "intent_tags": ["discuss_news"],
            "topic_tags": ["news", "hot_topic"],
            "emotion": "neutral"
        },
        {
            "id": 195,
            "text": "新闻看了，您看新闻吗？",
            "intent_tags": ["discuss_news"],
            "topic_tags": ["news", "share"],
            "emotion": "neutral"
        },
        {
            "id": 196,
            "text": "我的宠物是小鸟。",
            "intent_tags": ["talk_about_pets"],
            "topic_tags": ["pets", "bird"],
            "emotion": "positive"
        },
        {
            "id": 197,
            "text": "猫很可爱。",
            "intent_tags": ["talk_about_pets"],
            "topic_tags": ["pets", "cat"],
            "emotion": "positive"
        },
        {
            "id": 198,
            "text": "养狗需要责任。",
            "intent_tags": ["talk_about_pets"],
            "topic_tags": ["pets", "dog"],
            "emotion": "neutral"
        },
        {
            "id": 199,
            "text": "宠物带来欢乐。",
            "intent_tags": ["talk_about_pets"],
            "topic_tags": ["pets", "joy"],
            "emotion": "positive"
        },
        {
            "id": 200,
            "text": "宠物话题有趣，您有宠物吗？",
            "intent_tags": ["talk_about_pets"],
            "topic_tags": ["pets", "share"],
            "emotion": "positive"
        },
        {
            "id": 201,
            "text": "这部电影很感人。",
            "intent_tags": ["discuss_movies"],
            "topic_tags": ["movies", "emotional"],
            "emotion": "positive"
        },
        {
            "id": 202,
            "text": "演员表演出色。",
            "intent_tags": ["discuss_movies"],
            "topic_tags": ["movies", "acting"],
            "emotion": "positive"
        },
        {
            "id": 203,
            "text": "剧情曲折。",
            "intent_tags": ["discuss_movies"],
            "topic_tags": ["movies", "plot"],
            "emotion": "neutral"
        },
        {
            "id": 204,
            "text": "推荐经典电影。",
            "intent_tags": ["discuss_movies"],
            "topic_tags": ["movies", "recommendation"],
            "emotion": "positive"
        },
        {
            "id": 205,
            "text": "电影看了，您喜欢哪部？",
            "intent_tags": ["discuss_movies"],
            "topic_tags": ["movies", "favorite"],
            "emotion": "positive"
        },
        {
            "id": 206,
            "text": "这本书启发很大。",
            "intent_tags": ["discuss_books"],
            "topic_tags": ["books", "inspiration"],
            "emotion": "positive"
        },
        {
            "id": 207,
            "text": "作者文笔好。",
            "intent_tags": ["discuss_books"],
            "topic_tags": ["books", "writing"],
            "emotion": "positive"
        },
        {
            "id": 208,
            "text": "小说情节吸引人。",
            "intent_tags": ["discuss_books"],
            "topic_tags": ["books", "novel"],
            "emotion": "positive"
        },
        {
            "id": 209,
            "text": "阅读书籍放松。",
            "intent_tags": ["discuss_books"],
            "topic_tags": ["books", "relax"],
            "emotion": "positive"
        },
        {
            "id": 210,
            "text": "书籍讨论，您读过什么书？",
            "intent_tags": ["discuss_books"],
            "topic_tags": ["books", "share"],
            "emotion": "neutral"
        },
        {
            "id": 211,
            "text": "音乐能治愈心灵。",
            "intent_tags": ["discuss_music"],
            "topic_tags": ["music", "healing"],
            "emotion": "positive"
        },
        {
            "id": 212,
            "text": "我喜欢古典音乐。",
            "intent_tags": ["discuss_music"],
            "topic_tags": ["music", "classical"],
            "emotion": "positive"
        },
        {
            "id": 213,
            "text": "歌曲旋律美妙。",
            "intent_tags": ["discuss_music"],
            "topic_tags": ["music", "melody"],
            "emotion": "positive"
        },
        {
            "id": 214,
            "text": "演唱会很热闹。",
            "intent_tags": ["discuss_music"],
            "topic_tags": ["music", "concert"],
            "emotion": "positive"
        },
        {
            "id": 215,
            "text": "音乐爱好，您听什么音乐？",
            "intent_tags": ["discuss_music"],
            "topic_tags": ["music", "preference"],
            "emotion": "positive"
        },
        {
            "id": 216,
            "text": "足球比赛精彩。",
            "intent_tags": ["discuss_sports"],
            "topic_tags": ["sports", "football"],
            "emotion": "positive"
        },
        {
            "id": 217,
            "text": "我支持篮球队。",
            "intent_tags": ["discuss_sports"],
            "topic_tags": ["sports", "basketball"],
            "emotion": "positive"
        },
        {
            "id": 218,
            "text": "运动员很努力。",
            "intent_tags": ["discuss_sports"],
            "topic_tags": ["sports", "athlete"],
            "emotion": "positive"
        },
        {
            "id": 219,
            "text": "体育新闻更新。",
            "intent_tags": ["discuss_sports"],
            "topic_tags": ["sports", "news"],
            "emotion": "neutral"
        },
        {
            "id": 220,
            "text": "体育讨论，您喜欢什么运动？",
            "intent_tags": ["discuss_sports"],
            "topic_tags": ["sports", "favorite"],
            "emotion": "positive"
        },
        {
            "id": 221,
            "text": "你觉得这个怎么样。",
            "intent_tags": ["ask_opinion"],
            "topic_tags": ["opinion", "ask"],
            "emotion": "neutral"
        },
        {
            "id": 222,
            "text": "征求您的意见。",
            "intent_tags": ["ask_opinion"],
            "topic_tags": ["opinion", "seek"],
            "emotion": "neutral"
        },
        {
            "id": 223,
            "text": "对这件事的看法。",
            "intent_tags": ["ask_opinion"],
            "topic_tags": ["opinion", "view"],
            "emotion": "neutral"
        },
        {
            "id": 224,
            "text": "意见很重要。",
            "intent_tags": ["ask_opinion"],
            "topic_tags": ["opinion", "importance"],
            "emotion": "positive"
        },
        {
            "id": 225,
            "text": "问意见，您有什么意见？",
            "intent_tags": ["ask_opinion"],
            "topic_tags": ["opinion", "question"],
            "emotion": "neutral"
        },
        {
            "id": 226,
            "text": "我的意见是支持。",
            "intent_tags": ["give_opinion"],
            "topic_tags": ["opinion", "support"],
            "emotion": "positive"
        },
        {
            "id": 227,
            "text": "我觉得不错。",
            "intent_tags": ["give_opinion"],
            "topic_tags": ["opinion", "positive"],
            "emotion": "positive"
        },
        {
            "id": 228,
            "text": "反对这个想法。",
            "intent_tags": ["give_opinion"],
            "topic_tags": ["opinion", "oppose"],
            "emotion": "negative"
        },
        {
            "id": 229,
            "text": "个人观点分享。",
            "intent_tags": ["give_opinion"],
            "topic_tags": ["opinion", "personal"],
            "emotion": "neutral"
        },
        {
            "id": 230,
            "text": "意见给了，您意见呢？",
            "intent_tags": ["give_opinion"],
            "topic_tags": ["opinion", "exchange"],
            "emotion": "neutral"
        },
        {
            "id": 231,
            "text": "从前有个故事。",
            "intent_tags": ["make_joke"],
            "topic_tags": ["joke", "funny"],
            "emotion": "positive"
        },
        {
            "id": 232,
            "text": "这个笑话好玩。",
            "intent_tags": ["make_joke"],
            "topic_tags": ["joke", "fun"],
            "emotion": "positive"
        },
        {
            "id": 233,
            "text": "幽默能放松。",
            "intent_tags": ["make_joke"],
            "topic_tags": ["joke", "humor"],
            "emotion": "positive"
        },
        {
            "id": 234,
            "text": "讲个轻松的笑话吧。",
            "intent_tags": ["make_joke"],
            "topic_tags": ["joke", "tell"],
            "emotion": "positive"
        },
        {
            "id": 235,
            "text": "笑话说完，您有笑话吗？",
            "intent_tags": ["make_joke"],
            "topic_tags": ["joke", "share"],
            "emotion": "positive"
        },
        {
            "id": 236,
            "text": "从前有个故事。",
            "intent_tags": ["tell_story"],
            "topic_tags": ["story", "begin"],
            "emotion": "neutral"
        },
        {
            "id": 237,
            "text": "讲童话。",
            "intent_tags": ["tell_story"],
            "topic_tags": ["story", "fairy_tale"],
            "emotion": "positive"
        },
        {
            "id": 238,
            "text": "故事结局美好。",
            "intent_tags": ["tell_story"],
            "topic_tags": ["story", "ending"],
            "emotion": "positive"
        },
        {
            "id": 239,
            "text": "分享个人故事。",
            "intent_tags": ["tell_story"],
            "topic_tags": ["story", "personal"],
            "emotion": "neutral"
        },
        {
            "id": 240,
            "text": "故事讲完，您有故事吗？",
            "intent_tags": ["tell_story"],
            "topic_tags": ["story", "share"],
            "emotion": "neutral"
        },
        {
            "id": 241,
            "text": "计划生日派对。",
            "intent_tags": ["plan_event"],
            "topic_tags": ["event", "birthday"],
            "emotion": "positive"
        },
        {
            "id": 242,
            "text": "安排会议。",
            "intent_tags": ["plan_event"],
            "topic_tags": ["event", "meeting"],
            "emotion": "neutral"
        },
        {
            "id": 243,
            "text": "节日活动规划。",
            "intent_tags": ["plan_event"],
            "topic_tags": ["event", "holiday"],
            "emotion": "positive"
        },
        {
            "id": 244,
            "text": "事件细节确定。",
            "intent_tags": ["plan_event"],
            "topic_tags": ["event", "detail"],
            "emotion": "neutral"
        },
        {
            "id": 245,
            "text": "计划好了，您计划什么事件？",
            "intent_tags": ["plan_event"],
            "topic_tags": ["event", "share"],
            "emotion": "positive"
        },
        {
            "id": 246,
            "text": "回忆童年趣事。",
            "intent_tags": ["recall_memory"],
            "topic_tags": ["memory", "childhood"],
            "emotion": "positive"
        },
        {
            "id": 247,
            "text": "旧事重提。",
            "intent_tags": ["recall_memory"],
            "topic_tags": ["memory", "past"],
            "emotion": "neutral"
        },
        {
            "id": 248,
            "text": "美好回忆。",
            "intent_tags": ["recall_memory"],
            "topic_tags": ["memory", "good"],
            "emotion": "positive"
        },
        {
            "id": 249,
            "text": "记忆犹新。",
            "intent_tags": ["recall_memory"],
            "topic_tags": ["memory", "fresh"],
            "emotion": "neutral"
        },
        {
            "id": 250,
            "text": "回忆分享，您有回忆吗？",
            "intent_tags": ["recall_memory"],
            "topic_tags": ["memory", "share"],
            "emotion": "positive"
        },
        {
            "id": 251,
            "text": "我不明白您的意思。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "understanding"],
            "emotion": "neutral"
        },
        {
            "id": 252,
            "text": "抱歉，我不懂。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "apology"],
            "emotion": "negative"
        },
        {
            "id": 253,
            "text": "请再说一遍。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "repeat"],
            "emotion": "neutral"
        },
        {
            "id": 254,
            "text": "这太奇怪了，我不理解。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "strange"],
            "emotion": "surprised"
        },
        {
            "id": 255,
            "text": "我不清楚这个。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "clarity"],
            "emotion": "neutral"
        },
        {
            "id": 256,
            "text": "您能解释一下吗？",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "explanation"],
            "emotion": "neutral"
        },
        {
            "id": 257,
            "text": "我有点困惑。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "puzzled"],
            "emotion": "negative"
        },
        {
            "id": 258,
            "text": "不知道怎么回答。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "response"],
            "emotion": "negative"
        },
        {
            "id": 259,
            "text": "这超出我的知识范围。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "knowledge"],
            "emotion": "neutral"
        },
        {
            "id": 260,
            "text": "我不确定。",
            "intent_tags": ["unknow"],
            "topic_tags": ["confusion", "uncertainty"],
            "emotion": "neutral"
        }
    ],
    "intents": [
        {
            "name": "greeting",
            "patterns": ["您好", "早上好", "晚上好", "嗨", "你好", "问好", "打招呼", "见面", "初次见面", "欢迎", "拜访", "来访", "问候", "寒暄", "点头", "微笑", "挥手", "拥抱", "久违", "重逢"],
            "slots": {
                "time_of_day": ["早上", "中午", "下午", "晚上", "清晨", "黄昏", "午夜", "黎明", "白天", "黑夜"],
                "person": ["朋友", "家人", "同事", "陌生人", "上司", "下属", "邻居", "客人", "老师", "学生"],
                "mood": ["开心", "愉快", "高兴", "兴奋", "平静", "疲惫", "伤心", "生气", "惊讶", "无聊"],
                "occasion": ["生日", "节日", "聚会", "会议", "约会", "旅行", "工作", "休闲", "学习", "运动"],
                "location": ["家", "办公室", "学校", "公园", "商场", "餐厅", "机场", "车站", "医院", "图书馆"]
            }
        },
        {
            "name": "farewell",
            "patterns": ["再见", "拜拜", "晚安", "下次见", "告别", "离开", "走人", "结束", "道别", "挥别", "拥别", "点头别", "微笑别", "保重", "一路平安", "祝好", "后会有期", "慢走", "珍重", "再会"],
            "slots": {
                "time_of_day": ["早上", "中午", "下午", "晚上", "清晨", "黄昏", "午夜", "黎明", "白天", "黑夜"],
                "person": ["朋友", "家人", "同事", "陌生人", "上司", "下属", "邻居", "客人", "老师", "学生"],
                "mood": ["开心", "伤心", "不舍", "平静", "兴奋", "疲惫", "高兴", "生气", "惊讶", "无聊"],
                "occasion": ["聚会", "会议", "约会", "旅行", "工作", "休闲", "学习", "运动", "生日", "节日"],
                "location": ["家", "办公室", "学校", "公园", "商场", "餐厅", "机场", "车站", "医院", "图书馆"]
            }
        },
        {
            "name": "weather",
            "patterns": ["天气", "气温", "下雨", "下雪", "晴天", "预报", "阴天", "刮风", "打雷", "降温", "升温", "潮湿", "干燥", "雾霾", "彩虹", "台风", "暴雨", "晴朗", "多云", "霜冻"],
            "slots": {
                "location": ["北京", "上海", "广州", "深圳", "杭州", "成都", "武汉", "西安", "天津", "重庆"],
                "time": ["今天", "明天", "后天", "本周", "下周", "周末", "早上", "晚上", "中午", "下午"],
                "condition": ["晴", "雨", "雪", "风", "雷", "雾", "霾", "云", "热", "冷"],
                "temperature": ["高温", "低温", "舒适", "炎热", "寒冷", "温暖", "凉爽", "闷热", "干燥", "湿润"],
                "advice": ["带伞", "穿衣", "防晒", "保暖", "出行", "室内", "注意", "防范", "准备", "调整"]
            }
        },
        {
            "name": "food",
            "patterns": ["食物", "饭菜", "早餐", "午餐", "晚餐", "小吃", "水果", "蔬菜", "肉类", "海鲜", "甜点", "主食", "汤", "沙拉", "面包", "米饭", "面条", "饺子", "包子", "蛋糕"],
            "slots": {
                "type": ["中餐", "西餐", "日餐", "韩餐", "素食", "荤食", "快餐", "家常", "美食", "街食"],
                "taste": ["甜", "咸", "酸", "辣", "苦", "鲜", "香", "脆", "软", "硬"],
                "ingredient": ["米", "面", "肉", "鱼", "菜", "果", "蛋", "奶", "豆", "油"],
                "meal_time": ["早餐", "午餐", "晚餐", "宵夜", "下午茶", "早茶", "正餐", "零食", "加餐", "夜宵"],
                "place": ["家", "餐厅", "食堂", "街边", "超市", "市场", "外卖", "自制", "聚餐", "野餐"]
            }
        },
        {
            "name": "drink",
            "patterns": ["饮料", "水", "茶", "咖啡", "果汁", "牛奶", "酒", "啤酒", "红酒", "白酒", "汽水", "矿泉水", "绿茶", "红茶", "奶茶", "可乐", "橙汁", "苹果汁", "豆浆", "酸奶"],
            "slots": {
                "type": ["热饮", "冷饮", "酒精", "无酒精", "碳酸", "果味", "奶制品", "茶类", "咖啡类", "水类"],
                "taste": ["甜", "苦", "酸", "咸", "淡", "浓", "清", "醇", "爽", "滑"],
                "occasion": ["早餐", "午餐", "晚餐", "聚会", "工作", "休息", "运动", "旅行", "学习", "休闲"],
                "temperature": ["热", "温", "凉", "冰", "常温", "烫", "冷藏", "室温", "沸腾", "冻"],
                "brand": ["可口可乐", "百事", "雀巢", "立顿", "统一", "农夫山泉", "娃哈哈", "伊利", "蒙牛", "王老吉"]
            }
        },
        {
            "name": "health",
            "patterns": ["健康", "身体", "生病", "感冒", "发烧", "头痛", "胃痛", "锻炼", "饮食", "睡眠", "检查", "医生", "医院", "药物", "疫苗", "健身", "养生", "体检", "病痛", "恢复"],
            "slots": {
                "symptom": ["咳嗽", "流鼻涕", "喉咙痛", "腹泻", "便秘", "失眠", "疲劳", "焦虑", "抑郁", "过敏"],
                "activity": ["跑步", "游泳", "瑜伽", "散步", "健身房", "骑车", "爬山", "跳绳", "打球", "太极"],
                "food": ["蔬菜", "水果", "全谷", "蛋白", "低脂", "无糖", "有机", "均衡", "营养", "补充"],
                "time": ["每天", "每周", "每月", "早晨", "晚上", "饭前", "饭后", "睡前", "醒后", "定期"],
                "place": ["医院", "诊所", "健身中心", "公园", "家", "办公室", "学校", "社区", "网上", "药店"]
            }
        },
        {
            "name": "work",
            "patterns": ["工作", "上班", "加班", "会议", "任务", "项目", "同事", "上司", "薪水", "职位", "办公室", "报告", "计划", "目标", "绩效", "休假", "辞职", "招聘", "培训", "合作"],
            "slots": {
                "role": ["秘书", "经理", "工程师", "老师", "医生", "销售", "程序员", "设计师", "会计", "律师"],
                "time": ["全职", "兼职", "早班", "晚班", "周末", "假期", "加班", "正常", "灵活", "远程"],
                "place": ["办公室", "工厂", "学校", "医院", "公司", "家", "现场", "线上", "门店", "实验室"],
                "tool": ["电脑", "电话", "文件", "软件", "设备", "车辆", "仪器", "资料", "表格", "报告"],
                "goal": ["完成", "提升", "创新", "销售", "服务", "研究", "教学", "管理", "生产", "营销"]
            }
        },
        {
            "name": "rest",
            "patterns": ["休息", "放松", "小憩", "假期", "周末", "午睡", "休闲", "度假", "充电", "恢复", "躺下", "坐着", "冥想", "泡澡", "按摩", "散步", "听音乐", "看书", "睡觉", "放假"],
            "slots": {
                "duration": ["短时", "长时", "一小时", "半天", "一天", "周末", "假期", "晚上", "中午", "随时"],
                "activity": ["睡觉", "阅读", "音乐", "电影", "游戏", "聊天", "散步", "瑜伽", "冥想", "泡茶"],
                "place": ["家", "公园", "海滩", "山上", "咖啡馆", "图书馆", "卧室", "沙发", "阳台", "花园"],
                "mood": ["疲惫", "压力", "放松", "愉快", "安静", "舒适", "无聊", "兴奋", "平静", "恢复"],
                "reason": ["工作累", "学习累", "旅行累", "生病", "日常", "节日", "生日", "放松", "充电", "调整"]
            }
        },
        {
            "name": "hobby",
            "patterns": ["爱好", "兴趣", "消遣", "收藏", "绘画", "音乐", "阅读", "运动", "烹饪", "旅行", "摄影", "园艺", "跳舞", "唱歌", "写作", "游戏", "手工", "钓鱼", "登山", "游泳"],
            "slots": {
                "type": ["户外", "室内", "艺术", "体育", "智力", "社交", "个人", "团队", "创意", "放松"],
                "frequency": ["每天", "每周", "每月", "偶尔", "经常", "很少", "总是", "有时", "周末", "假期"],
                "tool": ["画笔", "乐器", "书籍", "球", "锅", "相机", "种子", "鞋", "笔", "电脑"],
                "place": ["家", "公园", "工作室", "场馆", "厨房", "户外", "花园", "舞台", "湖边", "山顶"],
                "partner": ["独自", "朋友", "家人", "同事", "陌生人", "团队", "教练", "老师", "网上", "社区"]
            }
        },
        {
            "name": "travel",
            "patterns": ["旅行", "旅游", "出差", "度假", "探险", "行程", "目的地", "机票", "酒店", "景点", "导游", "行李", "护照", "签证", "交通", "地图", "预算", "回忆", "照片", "纪念品"],
            "slots": {
                "destination": ["北京", "上海", "巴黎", "纽约", "东京", "悉尼", "伦敦", "罗马", "迪拜", "海南"],
                "transport": ["飞机", "火车", "汽车", "船", "自行车", "步行", "地铁", "出租车", "公交", "高铁"],
                "duration": ["一天", "周末", "一周", "两周", "一个月", "短期", "长期", "假期", "出差", "探亲"],
                "purpose": ["休闲", "工作", "学习", "探险", "购物", "美食", "文化", "自然", "家庭", "浪漫"],
                "budget": ["低", "中", "高", "节省", "奢侈", "经济", "实惠", "昂贵", "免费", "赞助"]
            }
        },
        {
            "name": "shopping",
            "patterns": ["购物", "买东西", "商场", "超市", "网购", "衣服", "鞋子", "电子", "食品", "书籍", "优惠", "折扣", "付款", "退货", "试穿", "挑选", "清单", "品牌", "质量", "价格"],
            "slots": {
                "item": ["衣服", "鞋", "手机", "电脑", "书", "食品", "化妆品", "家具", "玩具", "饰品"],
                "place": ["商场", "超市", "网上", "专卖店", "市场", "街边", "百货", "电商", "outlet", "二手"],
                "method": ["现金", "信用卡", "支付宝", "微信", "银行卡", "分期", "礼券", "积分", "兑换", "借记卡"],
                "time": ["周末", "节日", "促销", "平时", "晚上", "早上", "中午", "假期", "工作日", "随时"],
                "reason": ["需要", "礼物", "替换", "爱好", "时尚", "实用", "收藏", "投资", "试用", "冲动"]
            }
        },
        {
            "name": "family",
            "patterns": ["家庭", "父母", "孩子", "兄弟", "姐妹", "祖父母", "亲戚", "家事", "聚会", "团圆", "教育", "支持", "爱", "争吵", "和睦", "家谱", "遗产", "传统", "节日", "回忆"],
            "slots": {
                "member": ["父亲", "母亲", "儿子", "女儿", "哥哥", "妹妹", "爷爷", "奶奶", "叔叔", "姨姨"],
                "activity": ["聚餐", "旅行", "聊天", "游戏", "学习", "工作", "照顾", "庆祝", "争执", "支持"],
                "occasion": ["生日", "节日", "婚礼", "毕业", "搬家", "生病", "成就", "失败", "日常", "纪念"],
                "emotion": ["爱", "温暖", "争吵", "支持", "依赖", "独立", "思念", "感激", "后悔", "骄傲"],
                "place": ["家", "餐厅", "公园", "旅行地", "医院", "学校", "办公室", "网上", "电话", "聚会厅"]
            }
        },
        {
            "name": "friends",
            "patterns": ["朋友", "好友", "同学", "同事", "伙伴", "交友", "聚会", "聊天", "帮助", "分享", "信任", "背叛", "友谊", "约会", "介绍", "联系", "礼物", "回忆", "支持", "争执"],
            "slots": {
                "type": ["儿时", "学校", "工作", "邻居", "网上", "兴趣", "旅行", "家庭", "老友", "新友"],
                "activity": ["聊天", "聚餐", "旅行", "游戏", "购物", "运动", "看电影", "唱歌", "帮忙", "庆祝"],
                "occasion": ["生日", "节日", "成就", "困难", "日常", "周末", "假期", "聚会", "约会", "纪念"],
                "emotion": ["开心", "信任", "嫉妒", "支持", "背叛", "思念", "感激", "生气", "和解", "忠诚"],
                "place": ["家", "咖啡馆", "公园", "酒吧", "学校", "办公室", "网上", "电话", "餐厅", "俱乐部"]
            }
        },
        {
            "name": "love",
            "patterns": ["爱情", "恋爱", "约会", "结婚", "分手", "浪漫", "表白", "亲吻", "拥抱", "礼物", "惊喜", "承诺", "嫉妒", "争吵", "和好", "思念", "幸福", "心碎", "缘分", "灵魂伴侣"],
            "slots": {
                "stage": ["初恋", "热恋", "稳定", "婚姻", "分手", "复合", "单恋", "网恋", "异地", "长久"],
                "activity": ["约会", "旅行", "看电影", "吃饭", "散步", "聊天", "礼物", "惊喜", "拥抱", "亲吻"],
                "emotion": ["幸福", "甜蜜", "伤心", "嫉妒", "思念", "激动", "平静", "失望", "感激", "后悔"],
                "person": ["男友", "女友", "丈夫", "妻子", "前任", "暗恋", "对象", "伴侣", "爱人", "情人"],
                "place": ["公园", "餐厅", "电影院", "海滩", "家", "旅行地", "咖啡馆", "酒吧", "学校", "办公室"]
            }
        },
        {
            "name": "study",
            "patterns": ["学习", "读书", "考试", "作业", "课堂", "老师", "学生", "学校", "笔记", "复习", "成绩", "专业", "学位", "课程", "图书馆", "自习", "讨论", "研究", "论文", "毕业"],
            "slots": {
                "subject": ["数学", "语文", "英语", "物理", "化学", "生物", "历史", "地理", "计算机", "艺术"],
                "level": ["小学", "初中", "高中", "大学", "研究生", "博士", "成人", "在线", "自学", "职业"],
                "tool": ["书", "笔", "电脑", "笔记本", "APP", "视频", "讲义", "试卷", "字典", "软件"],
                "time": ["每天", "每周", "课时", "学期", "假期", "考试前", "上课", "自习", "复习", "讨论"],
                "place": ["学校", "图书馆", "家", "教室", "网上", "咖啡馆", "宿舍", "实验室", "会议室", "公园"]
            }
        },
        {
            "name": "exercise",
            "patterns": ["锻炼", "运动", "跑步", "游泳", "瑜伽", "健身", "散步", "骑车", "球类", "跳绳", "举重", "有氧", "力量", "拉伸", "训练", "教练", "健身房", "公园", "晨练", "夜跑"],
            "slots": {
                "type": ["有氧", "力量", "柔韧", "团队", "个人", "户外", "室内", "水上", "球类", "武术"],
                "duration": ["30分钟", "1小时", "短时", "长时", "每天", "每周", "早晨", "晚上", "中午", "随时"],
                "intensity": ["低", "中", "高", "轻松", "激烈", "适中", "挑战", "恢复", "热身", "放松"],
                "place": ["健身房", "公园", "家", "游泳池", "球场", "山上", "河边", "街道", "室内", "户外"],
                "equipment": ["哑铃", "跑鞋", "瑜伽垫", "自行车", "球", "绳子", "器械", "手套", "护具", "水瓶"]
            }
        },
        {
            "name": "sleep",
            "patterns": ["睡觉", "休息", "午睡", "失眠", "早睡", "晚睡", "做梦", "起床", "闹钟", "枕头", "被子", "床", "卧室", "打盹", "小睡", "安眠", "睡眠质量", "梦境", "醒来", "困倦"],
            "slots": {
                "time": ["晚上", "中午", "早晨", "深夜", "黎明", "周末", "工作日", "假期", "随时", "固定"],
                "duration": ["8小时", "6小时", "短睡", "长睡", "午睡", "小憩", "通宵", "早起", "晚起", "间断"],
                "quality": ["好", "差", "深睡", "浅睡", "多梦", "无梦", "舒适", "不安", "恢复", "疲劳"],
                "aid": ["音乐", "茶", "书", "冥想", "药物", "运动", "饮食", "环境", "习惯", "放松"],
                "problem": ["失眠", "打鼾", "梦魇", "早醒", "赖床", "困倦", "疲惫", "中断", "不规律", "过多"]
            }
        },
        {
            "name": "time",
            "patterns": ["时间", "几点", "日期", "钟表", "闹钟", "日历", "小时", "分钟", "秒", "年", "月", "日", "周", "季节", "早晨", "下午", "晚上", "现在", "未来", "过去"],
            "slots": {
                "unit": ["年", "月", "日", "周", "小时", "分钟", "秒", "季度", "世纪", "时代"],
                "event": ["生日", "节日", "会议", "约会", "旅行", "工作", "学习", "休息", "聚会", "纪念"],
                "action": ["查询", "设置", "提醒", "计算", "规划", "记录", "调整", "同步", "倒计时", "回顾"],
                "tool": ["钟", "表", "手机", "电脑", "日历", "APP", "手表", "沙漏", "日晷", "闹铃"],
                "period": ["过去", "现在", "未来", "短期", "长期", "瞬间", "永恒", "周期", "间隔", "连续"]
            }
        },
        {
            "name": "appointment",
            "patterns": ["预约", "约会", "会议", "见面", "安排", "时间表", "日程", "预定", "取消", "确认", "提醒", "推迟", "提前", "地点", "参与者", "议题", "医生", "美容", "维修", "面试"],
            "slots": {
                "type": ["医疗", "商务", "个人", "社交", "服务", "面试", "聚餐", "旅行", "学习", "运动"],
                "time": ["早上", "下午", "晚上", "具体时间", "日期", "周几", "小时", "分钟", "提前", "延迟"],
                "place": ["办公室", "餐厅", "医院", "咖啡馆", "家", "公园", "网上", "电话", "会议室", "酒店"],
                "person": ["医生", "朋友", "同事", "上司", "客户", "家人", "老师", "教练", "面试官", "服务员"],
                "status": ["确认", "取消", "推迟", "提前", "待定", "完成", "缺席", "出席", "提醒", "跟进"]
            }
        },
        {
            "name": "help",
            "patterns": ["帮助", "帮忙", "协助", "支持", "援助", "求助", "指导", "建议", "救援", "合作", "服务", "咨询", "解答", "修理", "搬运", "教学", "护理", "借贷", "分享", "鼓励"],
            "slots": {
                "type": ["技术", "情感", "物理", "知识", "财务", "医疗", "学习", "工作", "生活", "紧急"],
                "person": ["朋友", "家人", "同事", "陌生人", "专家", "老师", "医生", "邻居", "志愿者", "专业"],
                "time": ["现在", "尽快", "以后", "紧急", "计划", "日常", "偶尔", "持续", "一次性", "长期"],
                "place": ["家", "办公室", "学校", "医院", "公园", "街上", "网上", "电话", "现场", "远程"],
                "reason": ["问题", "困难", "需要", "请求", "事故", "学习", "工作", "健康", "情感", "实用"]
            }
        },
        {
            "name": "advice",
            "patterns": ["建议", "意见", "推荐", "指导", "忠告", "提示", "经验", "教训", "咨询", "方案", "方法", "策略", "想法", "观点", "反馈", "评价", "提醒", "警告", "鼓励", "批评"],
            "slots": {
                "topic": ["健康", "工作", "学习", "感情", "财务", "旅行", "饮食", "运动", "生活", "决策"],
                "source": ["专家", "朋友", "家人", "老师", "书籍", "网上", "经验", "专业", "个人", "媒体"],
                "tone": ["积极", "中立", "消极", "鼓励", "警告", "建议", "批评", "赞同", "反对", "平衡"],
                "detail": ["详细", "简短", "步骤", "例子", "原因", "结果", "风险", "益处", "替代", "总结"],
                "audience": ["个人", "群体", "孩子", "成人", "老人", "学生", "职场", "家庭", "朋友", "陌生人"]
            }
        },
        {
            "name": "complaint",
            "patterns": ["抱怨", "不满", "问题", "故障", "差评", "退货", "投诉", "批评", "指责", "愤怒", "失望", "遗憾", "不悦", "抗议", "异议", "质疑", "举报", "反馈", "吐槽", "牢骚"],
            "slots": {
                "topic": ["服务", "产品", "质量", "价格", "态度", "环境", "时间", "管理", "政策", "他人"],
                "severity": ["轻微", "中等", "严重", "紧急", "反复", "一次性", "长期", "影响大", "影响小", "可解决"],
                "person": ["客服", "经理", "朋友", "家人", "同事", "上司", "陌生人", "公司", "政府", "媒体"],
                "action": ["解决", "道歉", "补偿", "改进", "忽略", "回应", "记录", "调查", "公开", "私下"],
                "outcome": ["满意", "不满意", "改进", "不变", "恶化", "和解", "升级", "放弃", "胜利", "失败"]
            }
        },
        {
            "name": "praise",
            "patterns": ["赞扬", "表扬", "好评", "肯定", "鼓励", "欣赏", "钦佩", "夸奖", "称赞", "认可", "感谢", "鼓掌", "欢呼", "推荐", "点赞", "支持", "恭喜", "祝贺", "优秀", "棒"],
            "slots": {
                "topic": ["工作", "学习", "外貌", "性格", "成就", "努力", "创意", "服务", "产品", "表现"],
                "person": ["朋友", "家人", "同事", "上司", "下属", "老师", "学生", "陌生人", "名人", "自己"],
                "intensity": ["非常", "很", "相当", "有点", "强烈", "温和", "公开", "私下", "正式", "随意"],
                "occasion": ["生日", "成就", "节日", "聚会", "工作", "学习", "日常", "意外", "表演", "比赛"],
                "form": ["口头", "书面", "礼物", "奖励", "拥抱", "掌声", "点赞", "分享", "推荐", "证书"]
            }
        },
        {
            "name": "apology",
            "patterns": ["道歉", "抱歉", "对不起", "原谅", "歉意", "遗憾", "过错", "错误", "失误", "补偿", "改正", "解释", "忏悔", "承认", "反思", "保证", "请求", "宽恕", "和解", "修复"],
            "slots": {
                "reason": ["迟到", "错误", "伤害", "遗忘", "误会", "失约", "粗鲁", "忽略", "事故", "故意"],
                "person": ["朋友", "家人", "同事", "上司", "下属", "陌生人", "爱人", "老师", "客户", "自己"],
                "intensity": ["诚恳", "简单", "深刻", "正式", "随意", "多次", "首次", "公开", "私下", "书面"],
                "action": ["补偿", "改正", "保证", "解释", "反思", "请求", "拥抱", "礼物", "时间", "改变"],
                "outcome": ["接受", "拒绝", "和解", "原谅", "改善", "不变", "恶化", "忘记", "记住", "成长"]
            }
        },
        {
            "name": "thanks",
            "patterns": ["谢谢", "感谢", "感激", "多谢", "致谢", "鸣谢", "报恩", "回报", "认可", "赞赏", "恩情", "帮忙", "支持", "礼物", "机会", "时间", "努力", "付出", "分享", "邀请"],
            "slots": {
                "reason": ["帮助", "礼物", "支持", "时间", "建议", "机会", "努力", "分享", "邀请", "服务"],
                "person": ["朋友", "家人", "同事", "上司", "陌生人", "老师", "医生", "服务员", "志愿者", "自己"],
                "intensity": ["非常", "很", "深深", "衷心", "简单", "正式", "随意", "公开", "私下", "书面"],
                "form": ["口头", "卡片", "礼物", "拥抱", "短信", "邮件", "电话", "帖子", "点赞", "回报"],
                "occasion": ["生日", "节日", "成就", "帮助", "聚会", "工作", "学习", "日常", "意外", "纪念"]
            }
        },
        {
            "name": "invitation",
            "patterns": ["邀请", "请帖", "约请", "欢迎", "参加", "聚会", "活动", "派对", "会议", "婚礼", "生日", "庆典", "晚宴", "旅行", "参观", "加入", "出席", "确认", "拒绝", "RSVP"],
            "slots": {
                "event": ["聚会", "会议", "婚礼", "生日", "派对", "旅行", "展览", "演出", "晚宴", "讲座"],
                "time": ["日期", "时间", "周末", "节日", "晚上", "早上", "中午", "下午", "具体", "灵活"],
                "place": ["家", "餐厅", "公园", "酒店", "办公室", "剧院", "博物馆", "海滩", "山上", "网上"],
                "person": ["朋友", "家人", "同事", "上司", "陌生人", "所有人", "特定群", "VIP", "嘉宾", "主办"],
                "dress": ["正式", "休闲", "主题", "随意", "西装", "礼服", "运动", "泳装", "化妆", "无要求"]
            }
        },
        {
            "name": "refusal",
            "patterns": ["拒绝", "不", "否决", "不同意", "推辞", "婉拒", "谢绝", "回绝", "否", "不接受", "反对", "回避", "规避", "退回", "不参加", "不买", "不吃", "不喝", "推掉", "谢绝"],
            "slots": {
                "reason": ["忙", "不喜欢", "不合适", "贵", "远", "累", "生病", "有事", "原则", "其他计划"],
                "tone": ["礼貌", "直接", "婉转", "坚定", "犹豫", "遗憾", "生气", "平静", "解释", "简短"],
                "item": ["邀请", "建议", "礼物", "帮助", "食物", "饮料", "工作", "约会", "交易", "请求"],
                "person": ["朋友", "家人", "同事", "上司", "陌生人", "销售", "爱人", "老师", "客户", "自己"],
                "alternative": ["以后", "其他", "改天", "推荐", "代替", "不需", "自己", "别的方式", "考虑", "再议"]
            }
        },
        {
            "name": "agreement",
            "patterns": ["同意", "赞成", "认可", "接受", "好", "是", "支持", "一致", "批准", "许可", "准许", "签订", "承诺", "合作", "联盟", "合意", "共识", "附议", "赞同", "没问题"],
            "slots": {
                "topic": ["计划", "建议", "想法", "合同", "邀请", "意见", "决定", "政策", "交易", "合作"],
                "condition": ["无条件", "有条件", "临时", "永久", "部分", "全部", "立即", "以后", "试行", "正式"],
                "person": ["朋友", "家人", "同事", "上司", "伙伴", "客户", "政府", "组织", "自己", "所有人"],
                "benefit": ["互利", "个人利", "集体利", "长期", "短期", "经济", "情感", "实用", "战略", "无利"],
                "risk": ["无", "低", "中", "高", "可控", "不可控", "潜在", "明显", "隐藏", "评估"]
            }
        },
        {
            "name": "disagreement",
            "patterns": ["不同意", "反对", "不赞成", "异议", "质疑", "争论", "辩论", "分歧", "冲突", "不一致", "否决", "抗议", "批评", "指责", "反驳", "驳斥", "不服", "不认", "不信", "怀疑"],
            "slots": {
                "topic": ["观点", "计划", "决定", "政策", "行为", "事实", "意见", "建议", "合同", "合作"],
                "reason": ["证据", "经验", "原则", "利益", "情感", "逻辑", "道德", "法律", "个人", "集体"],
                "intensity": ["温和", "强烈", "中立", "情绪化", "理性", "公开", "私下", "正式", "随意", "持续"],
                "person": ["朋友", "家人", "同事", "上司", "对手", "陌生人", "专家", "媒体", "自己", "群体"],
                "resolution": ["和解", "妥协", "坚持", "升级", "忽略", "讨论", "投票", "调解", "法院", "放弃"]
            }
        },
        {
            "name": "question_about_self",
            "patterns": ["我", "自己", "个人信息", "背景", "经历", "爱好", "工作", "家庭", "年龄", "名字", "出身", "教育", "技能", "目标", "梦想", "习惯", "性格", "外貌", "健康", "情感"],
            "slots": {
                "aspect": ["基本", "职业", "教育", "家庭", "爱好", "性格", "健康", "情感", "目标", "习惯"],
                "detail": ["详细", "简短", "历史", "当前", "未来", "秘密", "公开", "事实", "意见", "故事"],
                "purpose": ["介绍", "交友", "面试", "聊天", "咨询", "反思", "记录", "分享", "求助", "娱乐"],
                "time": ["过去", "现在", "未来", "童年", "青年", "中年", "老年", "最近", "长期", "瞬间"],
                "context": ["正式", "随意", "私人", "公开", "网上", "面对面", "电话", "书面", "口头", "匿名"]
            }
        },
        {
            "name": "share_experience",
            "patterns": ["分享", "经历", "故事", "经验", "教训", "回忆", "冒险", "成就", "失败", "旅行", "工作", "学习", "爱情", "友情", "家庭", "趣味", "感悟", "启发", "细节", "总结"],
            "slots": {
                "type": ["正面", "负面", "有趣", "感人", "惊险", "普通", "独特", "常见", "个人", "集体"],
                "time": ["最近", "过去", "童年", "青年", "工作", "旅行", "节日", "意外", "计划", "日常"],
                "person": ["自己", "朋友", "家人", "同事", "陌生人", "名人", "动物", "虚拟", "历史", "未来"],
                "lesson": ["启发", "警告", "鼓励", "反思", "成长", "改变", "坚持", "放弃", "创新", "传统"],
                "detail": ["详细", "简短", "生动", "平淡", "情感", "事实", "对话", "描述", "结局", "开头"]
            }
        },
        {
            "name": "express_happiness",
            "patterns": ["开心", "高兴", "快乐", "幸福", "喜悦", "兴奋", "满足", "愉悦", "欢笑", "微笑", "庆祝", "惊喜", "得意", "自豪", "放松", "舒适", "感恩", "欣慰", "振奋", "乐观"],
            "slots": {
                "reason": ["成就", "礼物", "聚会", "旅行", "健康", "爱情", "友情", "工作", "学习", "意外"],
                "intensity": ["非常", "很", "有点", "强烈", "温和", "短暂", "持久", "突发", "渐进", "共享"],
                "expression": ["笑", "跳", "唱", "舞", "抱", "分享", "帖子", "电话", "聚会", "礼物"],
                "person": ["自己", "朋友", "家人", "爱人", "同事", "陌生人", "所有人", "动物", "虚拟", "群体"],
                "occasion": ["生日", "节日", "成就", "聚会", "周末", "假期", "日常", "意外", "纪念", "开始"]
            }
        },
        {
            "name": "express_sadness",
            "patterns": ["伤心", "难过", "悲伤", "失落", "沮丧", "失望", "痛苦", "哭泣", "叹气", "孤独", "后悔", "无助", "绝望", "忧愁", "郁闷", "哀伤", "惆怅", "心碎", "消沉", "低落"],
            "slots": {
                "reason": ["失败", "失去", "分手", "死亡", "争吵", "孤独", "压力", "疾病", "背叛", "意外"],
                "intensity": ["很", "非常", "有点", "深刻", "短暂", "持久", "突发", "渐进", "隐藏", "公开"],
                "expression": ["哭", "叹", "沉默", "倾诉", "写作", "音乐", "散步", "睡觉", "吃", "运动"],
                "person": ["自己", "朋友", "家人", "爱人", "同事", "陌生人", "动物", "名人", "虚拟", "群体"],
                "coping": ["时间", "支持", "改变", "接受", "忘记", "面对", "帮助", "专业", "爱好", "旅行"]
            }
        },
        {
            "name": "express_anger",
            "patterns": ["生气", "愤怒", "气愤", "恼怒", "暴躁", "发火", "不满", "怨恨", "嫉妒", "憎恨", "咒骂", "争吵", "吼叫", "抱怨", "指责", "报复", "控制", "爆发", "压抑", "冷静"],
            "slots": {
                "reason": ["不公", "背叛", "错误", "延迟", "欺骗", "失败", "争执", "压力", "误会", "故意"],
                "intensity": ["轻微", "中等", "强烈", "爆发", "持续", "短暂", "控制", "失控", "隐藏", "公开"],
                "expression": ["喊", "打", "骂", "走开", "沉默", "倾诉", "运动", "写作", "音乐", "冥想"],
                "person": ["自己", "朋友", "家人", "同事", "上司", "陌生人", "爱人", "敌人", "群体", "对象"],
                "resolution": ["道歉", "解释", "冷静", "和解", "忽略", "报复", "专业帮助", "时间", "改变", "接受"]
            }
        },
        {
            "name": "express_surprise",
            "patterns": ["惊讶", "意外", "震惊", "惊奇", "诧异", "不可思议", "哇", "哦", "天啊", "没想到", "突然", "出乎意料", "惊吓", "惊喜", "愕然", "错愕", "惊叹", "惊呆", "惊异", "惊恐"],
            "slots": {
                "reason": ["礼物", "新闻", "事件", "发现", "变化", "巧合", "意外", "成就", "失败", "秘密"],
                "intensity": ["轻微", "中等", "强烈", "正面", "负面", "短暂", "持久", "突发", "渐进", "共享"],
                "expression": ["叫", "跳", "瞪眼", "张嘴", "笑", "哭", "抱", "分享", "拍照", "记录"],
                "person": ["自己", "朋友", "家人", "同事", "陌生人", "爱人", "孩子", "老人", "动物", "名人"],
                "type": ["正面", "负面", "中性", "预期外", "预期内", "好", "坏", "有趣", "可怕", "奇妙"]
            }
        },
        {
            "name": "express_fear",
            "patterns": ["害怕", "恐惧", "担心", "紧张", "惊恐", "畏惧", "胆怯", "焦虑", "慌张", "逃避", "颤抖", "出汗", "心跳", "尖叫", "躲藏", "求助", "面对", "克服", "无畏", "恐惧症"],
            "slots": {
                "reason": ["黑暗", "高度", "动物", "失败", "死亡", "未知", "变化", "孤独", "压力", "危险"],
                "intensity": ["轻微", "中等", "强烈", "慢性", "急性", "短暂", "持久", "突发", "渐进", "可控"],
                "expression": ["颤抖", "逃跑", "叫喊", "躲藏", "求助", "面对", "呼吸", "冥想", "倾诉", "忽略"],
                "person": ["自己", "孩子", "老人", "朋友", "家人", "陌生人", "动物", "虚拟", "群体", "名人"],
                "coping": ["勇敢", "支持", "专业", "经验", "习惯", "避免", "面对", "药物", "运动", "放松"]
            }
        },
        {
            "name": "express_boredom",
            "patterns": ["无聊", "乏味", "厌倦", "没劲", "无趣", "打哈欠", "叹气", "闲着", "没事干", "空虚", "疲乏", "懒散", "消磨时间", "找事做", "换频道", "逛街", "玩游戏", "看书", "睡觉", "聊天"],
            "slots": {
                "reason": ["重复", "无事", "等待", "孤独", "乏味活动", "压力", "疲劳", "环境", "人际", "内在"],
                "intensity": ["轻微", "中等", "强烈", "短暂", "持久", "偶尔", "经常", "突发", "渐进", "习惯"],
                "activity": ["看电视", "上网", "散步", "打电话", "阅读", "游戏", "音乐", "运动", "睡觉", "聊天"],
                "place": ["家", "办公室", "学校", "公园", "商场", "车上", "床上", "沙发", "阳台", "街头"],
                "time": ["白天", "晚上", "周末", "假期", "工作时间", "学习时间", "等待时间", "空闲", "忙里", "随时"]
            }
        },
        {
            "name": "express_excitement",
            "patterns": ["兴奋", "激动", "期待", "振奋", "热血", "跃跃欲试", "心跳加速", "迫不及待", "欣喜若狂", "高涨", "热情", "动力", "冲动", "惊喜", "狂喜", "沸腾", "雀跃", "鼓舞", "激励", "活跃"],
            "slots": {
                "reason": ["事件", "新闻", "计划", "礼物", "成就", "聚会", "旅行", "比赛", "机会", "变化"],
                "intensity": ["很高", "中等", "低", "短暂", "持久", "突发", "渐进", "共享", "个人", "群体"],
                "expression": ["跳", "叫", "笑", "分享", "计划", "准备", "庆祝", "拍照", "记录", "拥抱"],
                "person": ["自己", "朋友", "家人", "同事", "爱人", "团队", "粉丝", "观众", "孩子", "老人"],
                "occasion": ["节日", "生日", "成就", "旅行", "聚会", "比赛", "表演", "假期", "新年", "毕业"]
            }
        },
        {
            "name": "discuss_news",
            "patterns": ["新闻", "头条", "报道", "事件", "国际", "国内", "经济", "政治", "体育", "娱乐", "科技", "社会", "热点", "消息", "时事", "直播", "采访", "分析", "评论", "更新"],
            "slots": {
                "topic": ["政治", "经济", "科技", "娱乐", "体育", "社会", "国际", "国内", "天气", "健康"],
                "source": ["电视", "报纸", "网络", "手机", "广播", "杂志", "网站", "APP", "社交媒体", "朋友"],
                "time": ["今天", "昨天", "最近", "本周", "上月", "今年", "现在", "早上", "晚上", "实时"],
                "tone": ["正面", "负面", "中性", "惊人", "有趣", "严肃", "轻松", "重要", "不重要", "争议"],
                "reaction": ["惊讶", "开心", "担心", "无所谓", "讨论", "分享", "忽略", "关注", "转发", "评论"]
            }
        },
        {
            "name": "talk_about_pets",
            "patterns": ["宠物", "小狗", "小猫", "鸟", "鱼", "兔子", "乌龟", "仓鼠", "饲养", "照顾", "遛狗", "喂食", "训练", "可爱", "毛茸茸", "动物", "伴侣", "玩耍", "兽医", "领养"],
            "slots": {
                "type": ["狗", "猫", "鸟", "鱼", "兔", "仓鼠", "爬虫", "小猪", "马", "其他"],
                "age": ["幼年", "成年", "老年", "新生", "几个月", "几岁", "刚出生", "一岁", "两岁", "老了"],
                "activity": ["玩耍", "睡觉", "吃食", "散步", "训练", "洗澡", "看病", "拍照", "陪伴", "互动"],
                "emotion": ["开心", "可爱", "调皮", "乖巧", "黏人", "独立", "活泼", "安静", "忠诚", "淘气"],
                "place": ["家", "公园", "宠物店", "医院", "户外", "笼子", "水族箱", "草地", "沙发", "床上"]
            }
        },
        {
            "name": "discuss_movies",
            "patterns": ["电影", "影片", "剧情", "演员", "导演", "主演", "特效", "结局", "开头", "续集", "票房", "上映", "观看", "影院", "下载", "推荐", "经典", "恐怖", "喜剧", "爱情片"],
            "slots": {
                "type": ["动作", "爱情", "喜剧", "恐怖", "科幻", "动画", "纪录", "悬疑", "战争", "历史"],
                "rating": ["高分", "低分", "经典", "烂片", "好评", "差评", "五星", "四星", "三星", "无评分"],
                "time": ["最近", "今年", "去年", "经典老片", "上周", "今天", "明天", "周末", "假期", "夜晚"],
                "place": ["影院", "家里", "电脑", "手机", "电视", "网上", "飞机", "高铁", "酒店", "朋友家"],
                "reaction": ["感动", "好笑", "害怕", "无聊", "兴奋", "思考", "震撼", "失望", "惊喜", "一般"]
            }
        },
        {
            "name": "discuss_books",
            "patterns": ["书籍", "小说", "书本", "作者", "阅读", "章节", "结局", "情节", "文笔", "出版社", "电子书", "纸质书", "图书馆", "借书", "推荐", "经典", "文学", "科普", "传记", "漫画"],
            "slots": {
                "type": ["小说", "散文", "诗歌", "科普", "历史", "传记", "悬疑", "爱情", "励志", "漫画"],
                "author": ["知名", "新锐", "经典", "外国", "中国", "当代", "古代", "网络", "专业", "业余"],
                "time": ["最近", "今年", "童年", "假期", "睡前", "上班", "周末", "旅行", "考试前", "日常"],
                "place": ["图书馆", "书店", "家里", "床上", "咖啡馆", "地铁", "公园", "学校", "网上", "手机"],
                "reaction": ["启发", "感动", "好看", "无聊", "难懂", "有趣", "深刻", "轻松", "震撼", "一般"]
            }
        },
        {
            "name": "discuss_music",
            "patterns": ["音乐", "歌曲", "旋律", "歌手", "乐队", "专辑", "演唱会", "听歌", "播放", "歌词", "节奏", "古典", "流行", "摇滚", "民谣", "爵士", "钢琴", "吉他", "演唱", "下载"],
            "slots": {
                "type": ["流行", "古典", "摇滚", "民谣", "爵士", "电子", "嘻哈", "乡村", "蓝调", "古风"],
                "artist": ["歌手", "乐队", "作曲家", "钢琴家", "新晋", "经典", "外国", "中国", "独立", "主流"],
                "time": ["今天", "最近", "童年", "上班", "睡觉", "开车", "运动", "旅行", "聚会", "日常"],
                "place": ["耳机", "音响", "手机", "电脑", "车上", "家里", "演唱会", "咖啡馆", "公园", "地铁"],
                "reaction": ["治愈", "激动", "放松", "怀旧", "兴奋", "悲伤", "开心", "震撼", "无聊", "喜欢"]
            }
        },
        {
            "name": "discuss_sports",
            "patterns": ["运动", "比赛", "足球", "篮球", "乒乓", "游泳", "跑步", "运动员", "球队", "比分", "冠军", "直播", "球赛", "健身", "奥运", "世界杯", "训练", "赢", "输", "平局"],
            "slots": {
                "type": ["足球", "篮球", "网球", "羽毛球", "游泳", "田径", "乒乓", "排球", "体操", "电竞"],
                "team": ["国家队", "俱乐部", "学校队", "业余", "职业", "中国队", "外国队", "明星队", "本地", "国际"],
                "time": ["今天", "昨天", "本周", "周末", "奥运年", "世界杯", "日常", "早晨", "晚上", "假期"],
                "place": ["体育场", "球场", "游泳池", "健身房", "电视", "手机", "现场", "网上", "公园", "学校"],
                "reaction": ["兴奋", "失望", "加油", "遗憾", "庆祝", "伤心", "骄傲", "一般", "震撼", "无聊"]
            }
        },
        {
            "name": "ask_opinion",
            "patterns": ["看法", "意见", "觉得", "认为", "如何", "怎样", "评价", "建议", "观点", "想法", "问问", "征求", "请教", "讨论", "分享", "听听", "你的", "您的", "大家", "大家觉得"],
            "slots": {
                "topic": ["事情", "计划", "产品", "电影", "食物", "旅行", "工作", "学习", "感情", "新闻"],
                "person": ["你", "您", "朋友", "大家", "专家", "家人", "同事", "老师", "网友", "自己"],
                "detail": ["详细", "简单", "正面", "负面", "中性", "具体", "总体", "部分", "优点", "缺点"],
                "time": ["现在", "以后", "以前", "最近", "马上", "长期", "短期", "周末", "假期", "日常"],
                "purpose": ["决定", "参考", "聊天", "帮助", "确认", "学习", "娱乐", "改进", "选择", "分享"]
            }
        },
        {
            "name": "give_opinion",
            "patterns": ["我觉得", "我认为", "我的看法", "建议", "观点", "意见", "推荐", "支持", "反对", "赞成", "不错", "很好", "一般", "不行", "可以", "不行", "值得", "不值得", "个人觉得", "分享看法"],
            "slots": {
                "topic": ["事情", "计划", "产品", "电影", "食物", "旅行", "工作", "学习", "感情", "新闻"],
                "tone": ["正面", "负面", "中性", "强烈", "温和", "客观", "主观", "鼓励", "警告", "平衡"],
                "detail": ["详细", "简短", "理由", "例子", "优点", "缺点", "结果", "风险", "益处", "总结"],
                "person": ["自己", "对方", "大家", "专家", "朋友", "家人", "同事", "老师", "网友", "陌生人"],
                "strength": ["很强", "中等", "弱", "坚定", "犹豫", "明确", "模糊", "公开", "私下", "书面"]
            }
        },
        {
            "name": "make_joke",
            "patterns": ["笑话", "搞笑", "幽默", "段子", "趣事", "逗乐", "开玩笑", "讲笑话", "好笑", "哈哈", "有趣", "轻松", "娱乐", "调侃", "自黑", "冷笑话", "热梗", "梗", "笑点", "逗你"],
            "slots": {
                "type": ["冷笑话", "热梗", "自黑", "故事", "脑筋急转弯", "动物", "生活", "工作", "爱情", "日常"],
                "tone": ["轻松", "黑色", "温暖", "讽刺", "可爱", "无厘头", "经典", "新颖", "老梗", "新鲜"],
                "length": ["短", "长", "一句话", "故事", "对话", "图片", "视频", "文字", "语音", "表情"],
                "target": ["自己", "对方", "朋友", "大家", "动物", "名人", "社会", "工作", "生活", "天气"],
                "reaction": ["哈哈", "笑死", "好笑", "一般", "冷", "尴尬", "开心", "放松", "惊喜", "无聊"]
            }
        },
        {
            "name": "tell_story",
            "patterns": ["故事", "讲故事", "童话", "传说", "经历", "往事", "神话", "寓言", "小说", "剧情", "开头", "结局", "情节", "人物", "分享故事", "听故事", "从前", "曾经", "回忆", "讲述"],
            "slots": {
                "type": ["童话", "神话", "传说", "个人", "历史", "科幻", "爱情", "冒险", "恐怖", "幽默"],
                "time": ["童年", "过去", "最近", "古代", "现代", "未来", "昨天", "去年", "假期", "旅行"],
                "person": ["自己", "朋友", "家人", "名人", "动物", "英雄", "普通人", "孩子", "老人", "陌生人"],
                "length": ["短", "长", "简短", "详细", "开头", "结局", "完整", "片段", "系列", "续集"],
                "emotion": ["感动", "好笑", "害怕", "温暖", "惊险", "励志", "悲伤", "开心", "思考", "放松"]
            }
        },
        {
            "name": "plan_event",
            "patterns": ["计划", "安排", "活动", "派对", "聚会", "生日", "节日", "会议", "旅行", "策划", "准备", "时间", "地点", "参与", "邀请", "预算", "流程", "细节", "主题", "庆祝"],
            "slots": {
                "type": ["生日", "节日", "聚会", "会议", "旅行", "婚礼", "毕业", "庆功", "家庭", "公司"],
                "time": ["周末", "假期", "晚上", "明天", "下周", "本月", "明年", "具体日期", "灵活", "固定"],
                "place": ["家", "餐厅", "公园", "酒店", "办公室", "户外", "线上", "旅行地", "学校", "商场"],
                "person": ["朋友", "家人", "同事", "上司", "客户", "陌生人", "所有人", "小群", "VIP", "自己"],
                "detail": ["预算", "菜单", "礼物", "节目", "交通", "住宿", "服装", "主题", "流程", "意外"]
            }
        },
        {
            "name": "recall_memory",
            "patterns": ["回忆", "往事", "过去", "童年", "旧事", "记忆", "怀念", "想起", "曾经", "从前", "老照片", "老地方", "老朋友", "旧时光", "美好回忆", "难忘", "重温", "感慨", "分享回忆", "旧闻"],
            "slots": {
                "time": ["童年", "学生时代", "工作初期", "去年", "昨天", "旅行时", "节日", "生日", "聚会", "意外"],
                "person": ["自己", "朋友", "家人", "同学", "老师", "邻居", "爱人", "宠物", "名人", "陌生人"],
                "emotion": ["温暖", "开心", "伤感", "怀念", "遗憾", "骄傲", "感激", "有趣", "惊险", "平凡"],
                "place": ["家乡", "学校", "公园", "旅行地", "家", "老屋", "照片", "视频", "心里", "梦里"],
                "detail": ["具体", "模糊", "片段", "完整", "感人", "搞笑", "教训", "成就", "失败", "日常"]
            }
        }
    ]
}