class FakeModelForFake:
    """
    用于存储每个fakemodel的信息
    """
    def __init__(self, name, config_package, instance=None):
        """
        初始化FakeModelForFake
        
        Args:
            name: 模型名称
            config_package: 配置文件FAKE_MODEL_CONFIG的全包名
            instance: FakeModel实例
        """
        self.name = name
        self.config_package = config_package
        self.instance = instance

class FakeModelRegistry:
    """
    全局唯一单例，用于注册和管理FakeModelForFake实例
    """
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._models = {}
        return cls._instance
    
    def register(self, model):
        """
        注册一个FakeModelForFake实例
        
        Args:
            model: FakeModelForFake实例
        """
        self._models[model.name] = model
    
    def get(self, name):
        """
        获取指定名称的FakeModel实例（懒加载）
        
        Args:
            name: 模型名称
        
        Returns:
            FakeModel实例
        """
        model = self._models.get(name)
        if not model:
            raise ValueError(f"Model {name} not found")
        
        # 懒加载：需要时才创建实例
        if not model.instance:
            # 动态导入配置包
            import importlib
            config_module = importlib.import_module(model.config_package)
            
            # 动态导入FakeModelExpander类
            from ..core import FakeModelExpander
            
            # 创建FakeModelExpander实例，传递配置模块
            model.instance = FakeModelExpander.get_default(config_module=config_module)
        
        return model.instance