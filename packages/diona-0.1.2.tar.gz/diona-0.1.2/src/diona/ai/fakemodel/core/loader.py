from .corpus.manager import CorpusManager
from .models.data_models import Sentence

class Loader:
    @staticmethod
    def load_corpus(corpus_path=None, config_module=None):
        # 从指定的配置模块加载数据
        if config_module:
            data = config_module.FAKE_MODEL_CONFIG['sentences']
        else:
            # 向后兼容：从本地fakemodelconfig加载
            from .fakemodelconfig import FAKE_MODEL_CONFIG
            data = FAKE_MODEL_CONFIG['sentences']
        
        sentences = []
        for item in data:
            sentence = Sentence(
                id=item['id'],
                text=item['text'],
                intent_tags=item['intent_tags'],
                topic_tags=item['topic_tags'],
                emotion=item['emotion']
            )
            sentences.append(sentence)
        
        return CorpusManager(sentences)
    
    @staticmethod
    def load_intent_rules(rules_path=None, config_module=None):
        # 从指定的配置模块加载数据
        if config_module:
            data = config_module.FAKE_MODEL_CONFIG['intents']
        else:
            # 向后兼容：从本地fakemodelconfig加载
            from .fakemodelconfig import FAKE_MODEL_CONFIG
            data = FAKE_MODEL_CONFIG['intents']
        
        # 构建规则字典
        rules = {}
        for item in data:
            intent_name = item['name']
            rules[intent_name] = {
                'patterns': item.get('patterns', []),
                'slots': item.get('slots', {})
            }
        
        return rules