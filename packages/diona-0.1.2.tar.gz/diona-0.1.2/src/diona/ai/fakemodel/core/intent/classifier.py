from ..models.data_models import Intent
from ..loader import Loader

class IntentClassifier:
    def __init__(self, rules=None, config_module=None):
        if rules:
            self.rules = rules
        else:
            self.rules = Loader.load_intent_rules(config_module=config_module)
    
    def classify(self, text):
        best_intent = None
        best_score = 0
        
        for intent_name, rule in self.rules.items():
            score = 0
            slots = {}
            
            for pattern in rule['patterns']:
                if pattern in text:
                    score += 1
            
            for slot_name, slot_values in rule['slots'].items():
                for value in slot_values:
                    if value in text:
                        slots[slot_name] = value
                        score += 0.5

            
            
            if score > best_score:
                best_score = score
                best_intent = intent_name
                best_slots = slots
        
        if best_intent:
            confidence = min(1.0, best_score / 3.0)
            return Intent(name=best_intent, confidence=confidence, slots=best_slots)
        else:
            return Intent(name='unknown', confidence=0.0, slots={})