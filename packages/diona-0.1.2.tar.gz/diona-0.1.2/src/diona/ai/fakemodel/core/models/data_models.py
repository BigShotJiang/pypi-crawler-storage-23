class Sentence:
    def __init__(self, id, text, intent_tags, topic_tags, emotion):
        self.id = id
        self.text = text
        self.intent_tags = intent_tags
        self.topic_tags = topic_tags
        self.emotion = emotion

class Intent:
    def __init__(self, name, confidence, slots):
        self.name = name
        self.confidence = confidence
        self.slots = slots