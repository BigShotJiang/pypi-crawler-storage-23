import jieba
import logging

# 禁用jieba的日志输出
jieba.setLogLevel(logging.INFO)

class IntentAnalyzer:
    @staticmethod
    def analyze_intent_rules(rules_path=None, config_module=None):
        """
        对配置模块中的intents的patterns进行分词，并将结果写回到配置模块
        
        Args:
            rules_path: 保留参数，保持兼容性
            config_module: 配置模块，包含FAKE_MODEL_CONFIG
        
        Returns:
            None
        """
        # 从指定的配置模块加载数据
        if config_module:
            data = config_module.FAKE_MODEL_CONFIG['intents']
        else:
            # 尝试从默认配置模块加载
            try:
                from ..models.default.fakemodelconfig import FAKE_MODEL_CONFIG
                data = FAKE_MODEL_CONFIG['intents']
            except ImportError:
                print("错误：找不到配置模块")
                return
        
        # 对每个intent的patterns进行分词
        for intent in data:
            patterns = intent['patterns']
            segmented_patterns = set()  # 使用set去重
            for pattern in patterns:
                # 使用jieba精确模式分词
                words = jieba.cut(pattern, cut_all=False)
                # 将每个词语单独添加到patterns集合中
                for word in words:
                    if word.strip():
                        segmented_patterns.add(word.strip())
            # 将set转换为列表并替换原patterns
            intent['patterns'] = list(segmented_patterns)
        
        # 结果已经直接修改到配置模块中
        print("分词完成，结果已更新到配置模块")