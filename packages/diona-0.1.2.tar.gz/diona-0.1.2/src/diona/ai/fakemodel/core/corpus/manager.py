import random

class CorpusManager:
    def __init__(self, sentences):
        self.sentences = sentences
        self._build_indexes()
    
    def _build_indexes(self):
        self.intent_to_sentences = {}
        
        for sentence in self.sentences:
            for intent in sentence.intent_tags:
                if intent not in self.intent_to_sentences:
                    self.intent_to_sentences[intent] = []
                self.intent_to_sentences[intent].append(sentence)
    
    def get_sentences_by_intent(self, intent):
        return self.intent_to_sentences.get(intent, [])
    
    def random_item(self, items):
        if items:
            return random.choice(items)
        return None