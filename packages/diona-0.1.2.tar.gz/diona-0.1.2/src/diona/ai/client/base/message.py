class SingleChatMessage:
    def __init__(self, role, content, metadata=None):
        self.role = role
        self.content = content
        self.metadata = metadata or {}
    
    @classmethod
    def from_text(cls, text, role='user'):
        return cls(role, text)
    
    def to_ai_message(self):
        return {
            'role': self.role,
            'content': self.content
        }

class ChatMessage:
    def __init__(self, messages):
        self.messages = messages
    
    def to_ai_messages(self):
        return [msg.to_ai_message() for msg in self.messages]

class StreamingChatMessage:
    def __init__(self, role=None):
        self.role = role
        self.content = ""
        self.metadata = {}
    
    def add_chunk(self, chunk):
        self.content += chunk
    
    def set_role(self, role):
        self.role = role
    
    def set_metadata(self, metadata):
        self.metadata = metadata
    
    def to_single_chat_message(self):
        return SingleChatMessage(self.role, self.content, self.metadata)