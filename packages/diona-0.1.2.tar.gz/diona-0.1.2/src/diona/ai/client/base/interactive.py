from .base_client import BaseClient

def interactive_chat():
    client = BaseClient.create()
    session_id = "default"
    
    print("Welcome to Diona AI Chat!")
    print("Type 'exit' to quit.")
    
    while True:
        user_input = input("<diona@user> ")
        if user_input.strip().lower() == "exit":
            print("Goodbye!")
            break
        
        print("<@assistant> ", end="", flush=True)
        
        # Use streaming chat
        for chunk in client.chat_stream(session_id, user_input):
            if isinstance(chunk, str):
                # This is a content chunk, print it immediately
                print(chunk, end="", flush=True)
        
        print()
        print()