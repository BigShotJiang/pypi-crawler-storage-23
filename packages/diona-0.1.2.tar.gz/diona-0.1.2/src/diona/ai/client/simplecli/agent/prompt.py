"""Agent prompt builder"""

from typing import Dict, Any, List


class AgentPromptBuilder:
    """Agent prompt builder for creating system prompts with tool information"""
    
    def __init__(self, system_prompt: str):
        """Initialize prompt builder
        
        Args:
            system_prompt: Base system prompt
        """
        self.system_prompt = system_prompt
    
    def build_prompt(self, tools: List[Dict[str, Any]]) -> str:
        """Build system prompt with tool information
        
        Args:
            tools: List of tool schemas
            
        Returns:
            Complete system prompt
        """
        prompt = self.system_prompt
        prompt += "\n\nYou have access to the following tools:"
        
        for tool in tools:
            prompt += f"\n\nTool: {tool['name']}"
            prompt += f"\nDescription: {tool['description']}"
            prompt += "\nParameters:"
            
            if 'parameters' in tool and 'properties' in tool['parameters']:
                properties = tool['parameters']['properties']
                for param_name, param_info in properties.items():
                    prompt += f"\n  - {param_name}: {param_info.get('description', '')}"
                    if 'enum' in param_info:
                        prompt += f" (options: {', '.join(param_info['enum'])})"
        
        prompt += """\n\nWhen you need to use a tool, format your response as:\n\n```tool_call\n{\n  "tool": "tool_name",\n  "params": {\n    "param1": "value1",\n    "param2": "value2"\n  }\n}\n```\n\nAfter receiving the tool result, format your response as:\n\n```tool_result\n{\n  "tool": "tool_name",\n  "result": "tool_result"\n}\n```\n\nIf you don't need to use a tool, just provide your direct answer."""
        
        return prompt
