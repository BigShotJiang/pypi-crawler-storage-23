"""Tool manager implementation"""

from typing import Dict, Any, Optional, List
from diona.ai.client.simplecli.tools.filesystem import FileSystemTool
from diona.ai.client.simplecli.tools.shell import ShellTool
from diona.ai.client.simplecli.tools.git import GitTool
from diona.ai.client.simplecli.tools.websearch import WebSearchTool


class ToolManager:
    """Tool manager for registering and executing tools"""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize tool manager
        
        Args:
            config: Tool configuration
        """
        self.config = config
        self.tools: Dict[str, Any] = {}
        self._register_tools()
    
    def _register_tools(self):
        """Register built-in tools"""
        # Register filesystem tool
        if self.config.get('filesystem', {}).get('enabled', True):
            filesystem_config = self.config.get('filesystem', {})
            self.tools['filesystem'] = FileSystemTool(filesystem_config)
        
        # Register shell tool
        if self.config.get('shell', {}).get('enabled', True):
            shell_config = self.config.get('shell', {})
            self.tools['shell'] = ShellTool(shell_config)
        
        # Register git tool
        if self.config.get('git', {}).get('enabled', True):
            git_config = self.config.get('git', {})
            self.tools['git'] = GitTool(git_config)
        
        # Register websearch tool
        if self.config.get('websearch', {}).get('enabled', True):
            websearch_config = self.config.get('websearch', {})
            self.tools['websearch'] = WebSearchTool(websearch_config)
    
    def register_tool(self, tool_name: str, tool):
        """Register a new tool
        
        Args:
            tool_name: Tool name
            tool: Tool instance
        """
        self.tools[tool_name] = tool
    
    def execute_tool(self, tool_name: str, **params) -> Any:
        """Execute a tool
        
        Args:
            tool_name: Tool name
            params: Tool parameters
            
        Returns:
            Tool execution result
        """
        if tool_name in self.tools:
            tool = self.tools[tool_name]
            try:
                return tool.execute(**params)
            except Exception as e:
                return f"Error executing tool: {str(e)}"
        else:
            return f"Tool {tool_name} not found"
    
    def get_available_tools(self) -> List[str]:
        """Get list of available tools
        
        Returns:
            List of tool names
        """
        return list(self.tools.keys())
    
    def get_tool_schema(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """Get tool JSON Schema
        
        Args:
            tool_name: Tool name
            
        Returns:
            Tool schema or None
        """
        if tool_name in self.tools:
            tool = self.tools[tool_name]
            return tool.get_schema()
        return None
    
    def get_tool_description(self, tool_name: str) -> Optional[str]:
        """Get tool description
        
        Args:
            tool_name: Tool name
            
        Returns:
            Tool description or None
        """
        if tool_name in self.tools:
            tool = self.tools[tool_name]
            return tool.description
        return None
