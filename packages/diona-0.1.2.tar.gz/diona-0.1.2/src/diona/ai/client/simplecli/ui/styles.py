"""UI styles and themes"""

from dataclasses import dataclass


@dataclass
class Theme:
    """Theme configuration data class"""
    # Text colors
    primary: str = "cyan"
    secondary: str = "green"
    error: str = "red"
    warning: str = "yellow"
    info: str = "blue"
    success: str = "green"
    
    # Background colors
    bg_primary: str = ""
    bg_secondary: str = ""
    
    # Styles
    bold: bool = True
    italic: bool = False
    underline: bool = False
    
    # Spacing
    padding: int = 2
    margin: int = 1
    
    # Borders
    border: bool = True
    border_style: str = "single"


# Default theme
default_theme = Theme()

# Dark theme
dark_theme = Theme(
    primary="bright_cyan",
    secondary="bright_green",
    error="bright_red",
    warning="bright_yellow",
    info="bright_blue",
    success="bright_green"
)
