"""Main entry point for the diona command"""

import argparse
import sys
from diona.project.diona.registry import CommandRegistry

# Initialize registry (commands will be registered only when needed)
registry = CommandRegistry()

# Add commands here (uncomment and modify as needed)
# registry.add_command('diona.ai.client.simplecli.command.SimpleCLICommand')
# registry.add_command('path.to.another.CommandModel')


def main():
    """Main function for the diona command"""
    parser = argparse.ArgumentParser(
        prog='diona',
        description='Diona project command-line tool',
        epilog='For more information, visit https://diona.dev'
    )
    
    # Add global options
    parser.add_argument('--list-commands', action='store_true', help='List all registered commands')
    parser.add_argument('--command-detail', type=str, metavar='COMMAND', help='Show detailed information about a command')
    
    # Parse arguments with nargs='*' to allow subcommands
    args, remaining_args = parser.parse_known_args()
    
    # Only register commands when needed
    if args.list_commands or args.command_detail or len(remaining_args) > 0:
        # Register commands
        registry.register_commands()
        
    # Get command manager instance from registry
    command_manager = registry.get_command_manager()
    
    # Handle global options
    # --help is handled automatically by argparse
    
    if args.list_commands:
        commands = command_manager.list_commands()
        if not commands:
            print('No commands registered.')
            return
        
        print('Registered commands:')
        print('-' * 60)
        for name, command in commands.items():
            print(f'{name:<20} {command.description}')
        print('-' * 60)
        return
    
    if args.command_detail:
        command = command_manager.get_command(args.command_detail)
        if not command:
            print(f'Command "{args.command_detail}" not found.')
            return
        
        print(f'Command: {command.name}')
        print(f'Description: {command.description}')
        print('Parameters:')
        if not command.parameters:
            print('  No parameters')
        else:
            for param in command.parameters:
                required = ' (required)' if param.required else ''
                default = f' (default: {param.default})' if param.default is not None else ''
                print(f'  {param.name:<20} {param.type:<10} {param.description}{required}{default}')
        return
    
    # Handle command execution
    if len(remaining_args) < 1:
        parser.print_help()
        return
    
    # Get command name and arguments
    command_name = remaining_args[0]
    command_args = remaining_args[1:]
    
    # Get command
    command = command_manager.get_command(command_name)
    if not command:
        print(f'Command "{command_name}" not found.')
        print('Use --list-commands to see available commands.')
        return
    
    # Execute command
    try:
        command.implementation(*command_args)
    except Exception as e:
        print(f'Error executing command: {e}')
        return


if __name__ == '__main__':
    main()
