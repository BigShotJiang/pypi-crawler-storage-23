"""Command registry center"""

from diona.project.command import CommandManager
from diona.project.diona.registry_config import RegistryCommandConfig


class CommandRegistry:
    """Command registry singleton for loading commands from registry configuration"""
    _instance = None
    
    def __new__(cls):
        """Create a singleton instance"""
        if cls._instance is None:
            cls._instance = super(CommandRegistry, cls).__new__(cls)
            cls._instance._command_manager = CommandManager()
            cls._instance._config = RegistryCommandConfig()
            # Add default commands
            cls._instance._add_default_commands()
        return cls._instance
    
    def _add_default_commands(self):
        """Add default commands to the registry"""
        # No default commands added - commands will be added manually
        self.add_command('diona.ai.client.simplecli.command.SimpleCLICommand')
        pass
    
    def add_command(self, command_path):
        """Add a command to the registry
        
        Args:
            command_path: Command model path in format 'module_path.ClassName'
        """
        self._config.add_command(command_path)
    
    def remove_command(self, command_path):
        """Remove a command from the registry
        
        Args:
            command_path: Command model path to remove
        """
        self._config.remove_command(command_path)
    
    def register_commands(self):
        """Register all commands from the configuration"""
        command_paths = self._config.get_commands()
        for command_path in command_paths:
            try:
                # Import the command model
                module_path, class_name = command_path.rsplit('.', 1)
                module = __import__(module_path, fromlist=[class_name])
                command_model = getattr(module, class_name)
                
                # Register the command
                if not self._command_manager.has_command(command_model.name):
                    self._command_manager.register_command(command_model)
                    print(f"Registered command: {command_model.name}")
            except Exception as e:
                print(f"Error loading command from {command_path}: {e}")
    
    def get_command_manager(self):
        """Get the command manager instance
        
        Returns:
            CommandManager instance
        """
        return self._command_manager
    
    def get_config(self):
        """Get the registry configuration
        
        Returns:
            RegistryCommandConfig instance
        """
        return self._config
