"""Command models for the project tool system"""

from typing import List, Optional, Callable, Dict, Any
from dataclasses import dataclass


@dataclass
class CommandParameter:
    """Command parameter model"""
    name: str
    """Parameter name"""
    type: str
    """Parameter type (str, int, bool, etc.)"""
    description: str
    """Parameter description"""
    required: bool = False
    """Whether the parameter is required"""
    default: Optional[Any] = None
    """Default value for the parameter"""


@dataclass
class CommandModel:
    """Command model"""
    name: str
    """Command name"""
    description: str
    """Command description"""
    implementation: Callable
    """Command implementation function"""
    parameters: List[CommandParameter] = None
    """List of command parameters"""
    
    def __post_init__(self):
        """Initialize default values"""
        if self.parameters is None:
            self.parameters = []
