"""Command manager for managing registered commands"""

from typing import Dict, Optional
from .models import CommandModel


class CommandManager:
    """Command manager singleton for managing registered commands"""
    _instance = None
    
    def __new__(cls):
        """Create a singleton instance"""
        if cls._instance is None:
            cls._instance = super(CommandManager, cls).__new__(cls)
            cls._instance._commands = {}
        return cls._instance
    
    def register_command(self, command: CommandModel):
        """Register a command
        
        Args:
            command: Command model to register
        """
        self._commands[command.name] = command
    
    def get_command(self, name: str) -> Optional[CommandModel]:
        """Get a registered command
        
        Args:
            name: Command name
            
        Returns:
            Command model or None if not found
        """
        return self._commands.get(name)
    
    def list_commands(self) -> Dict[str, CommandModel]:
        """List all registered commands
        
        Returns:
            Dictionary of command names to command models
        """
        return self._commands
    
    def has_command(self, name: str) -> bool:
        """Check if a command is registered
        
        Args:
            name: Command name
            
        Returns:
            True if command is registered, False otherwise
        """
        return name in self._commands
