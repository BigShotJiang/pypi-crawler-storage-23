from enum import Enum


class DescriptionTypeEnum(str, Enum):
    HTML = "html"
    MD = "md"
    PLAIN = "plain"
