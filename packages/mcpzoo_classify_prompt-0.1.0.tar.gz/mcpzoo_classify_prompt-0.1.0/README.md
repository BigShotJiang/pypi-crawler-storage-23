# mcpzoo-classify-prompt

> 分类提示词 — 生成文本分类的提示词模板

## Installation

```bash
uvx mcpzoo-classify-prompt
```

## uvx JSON

```json
{
  "mcpServers": {
    "classify-prompt": {
      "args": ["mcpzoo-classify-prompt"],
      "command": "uvx"
    }
  }
}
```
