from mcp.server.fastmcp import FastMCP

mcp = FastMCP("classify-prompt")

@mcp.tool()
def gen_classify(text: str, categories: str) -> str:
    """生成文本分类（如情感分析、主题分类）的提示词模板。"""
    cats = categories.split(";")
    prompt = "请将以下文本归类到唯一的类别中。\n\n"
    
    prompt += f"可选的类别列表：[{', '.join(cats)}]\n\n"
    
    prompt += "分类要求：\n"
    prompt += "1. 只能从可选的类别列表中选择，严禁自创类别。\n"
    prompt += "2. 只输出类别的名称本身，不需要解释你的分类理由。\n"
    prompt += "3. 如果文本不属于任何类别或无法判断，请输出 '无法分类'。\n\n"
    prompt += f"待分类文本：\n{text}"
    
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
