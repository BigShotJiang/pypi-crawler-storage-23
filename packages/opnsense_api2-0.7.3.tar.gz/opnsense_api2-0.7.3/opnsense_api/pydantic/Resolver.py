from pydantic import BaseModel


class Resolver(BaseModel):
    pass