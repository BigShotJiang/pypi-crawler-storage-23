from pydantic import BaseModel


class ErrorFile(BaseModel):
    pass
