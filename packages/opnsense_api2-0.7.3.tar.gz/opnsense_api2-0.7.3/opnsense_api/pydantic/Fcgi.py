from pydantic import BaseModel


class Fcgi(BaseModel):
    pass
