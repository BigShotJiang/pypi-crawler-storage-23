"""
Claude Code Pet Companion

A pixel-art virtual pet plugin for Claude Code.
"""

__version__ = "2.3.4"
__author__ = "Claude Code Community"
__license__ = "MIT"

__all__ = [
    "ClaudeCodePetHD",
]
