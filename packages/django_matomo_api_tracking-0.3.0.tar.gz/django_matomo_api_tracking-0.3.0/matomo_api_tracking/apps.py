from django.apps import AppConfig


class MatomoApiTrackingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "matomo_api_tracking"
