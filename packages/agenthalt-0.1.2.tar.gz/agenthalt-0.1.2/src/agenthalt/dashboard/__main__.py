"""Run the AgentHalt dashboard as a module: python -m agenthalt.dashboard"""

from agenthalt.dashboard.server import run_dashboard

if __name__ == "__main__":
    run_dashboard()
