.. _{{MAJOR}}_{{MINOR}}_0:

RP {{MAJOR}}.{{MINOR}}.0
=========

code quality
------------

before
~~~~~~

* Total coverage: {{COVERAGE}}%
* Your code has been rated: {{LINTER}}/10
