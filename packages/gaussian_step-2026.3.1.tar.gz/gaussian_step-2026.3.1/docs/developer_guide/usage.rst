=====
Usage
=====

To use the Gaussian plug-in in a project::

    import gaussian_step
