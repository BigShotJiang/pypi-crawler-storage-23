from .client import get_sp_context

__all__ = ["get_sp_context"]
