from cms.app_base import CMSAppConfig, CMSAppExtension


class CMSConfigConfig(CMSAppConfig):
    pass


class CMSConfigConfig2(CMSAppConfig):
    pass


class CMSExtension(CMSAppExtension):
    pass
