from django.apps import AppConfig


class CMSConfigConfig(AppConfig):
    name = 'cms.test_utils.project.app_with_cms_config'
    label = 'app_with_cms_config'
