from django.apps import AppConfig


class BadCMSFileConfig(AppConfig):
    name = 'cms.test_utils.project.app_with_bad_cms_file'
    label = 'bad_cms_file'
