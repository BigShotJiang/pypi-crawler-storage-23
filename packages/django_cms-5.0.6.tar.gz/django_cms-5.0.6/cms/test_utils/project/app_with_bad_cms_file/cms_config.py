# Use this app to test what happens when exceptions are raised in this
# file. RuntimeError is just an example exception
raise RuntimeError
