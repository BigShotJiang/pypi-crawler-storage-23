from cms.app_base import CMSAppExtension


class CMSSomeFeatureConfig(CMSAppExtension):
    pass
