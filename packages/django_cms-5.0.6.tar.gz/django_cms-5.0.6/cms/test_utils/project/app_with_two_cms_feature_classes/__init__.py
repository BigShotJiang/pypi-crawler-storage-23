default_app_config = 'cms.test_utils.project.app_with_two_cms_feature_classes.apps.TwoCMSAppClassesConfig'
