from django.apps import AppConfig


class WithoutCMSFileConfig(AppConfig):
    name = 'cms.test_utils.project.app_without_cms_file'
    label = 'app_without_cms_file'
