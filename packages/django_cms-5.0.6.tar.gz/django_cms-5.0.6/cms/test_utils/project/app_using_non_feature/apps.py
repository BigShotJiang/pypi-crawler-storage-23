from django.apps import AppConfig


class NonFeatureCMSConfig(AppConfig):
    name = 'cms.test_utils.project.app_using_non_feature'
    label = 'app_using_non_feature'
