"""Shared Rich console instance."""

from rich.console import Console

console = Console()
