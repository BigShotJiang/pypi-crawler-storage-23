"""Cross-platform Python installation support scripts for DTU."""

__version__ = "0.1.0"

from pis_utils.cli import app

__all__ = ["app", "__version__"]
