
# pyannotators_duckling

[![license](https://img.shields.io/github/license/oterrier/pyannotators_duckling)](https://github.com/oterrier/pyannotators_duckling/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyannotators_duckling/workflows/tests/badge.svg)](https://github.com/oterrier/pyannotators_duckling/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyannotators_duckling)](https://codecov.io/gh/oterrier/pyannotators_duckling)
[![docs](https://img.shields.io/readthedocs/pyannotators_duckling)](https://pyannotators_duckling.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyannotators_duckling)](https://pypi.org/project/pyannotators_duckling/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyannotators_duckling)](https://pypi.org/project/pyannotators_duckling/)

Annotator based on Facebook's Duckling

## Installation

You can simply `pip install pyannotators_duckling`.

## Developing

### Pre-requisites

You will need to install `uv` (for building and running the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyannotators_duckling
```

### Running the test suite

You can run the full test suite against Python 3.12 with:

```
uv run pytest
```

### Linting and formatting

Check linting and formatting with:

```
uv run ruff check .
uv run ruff format --check .
```

Auto-fix formatting with:

```
uv run ruff format .
```

### Building the documentation

You can build the HTML documentation with:

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.
