# Authors

Contributors to pyannotators_duckling include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
