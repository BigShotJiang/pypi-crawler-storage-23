from google_analytics_mcp.server import main

main()
