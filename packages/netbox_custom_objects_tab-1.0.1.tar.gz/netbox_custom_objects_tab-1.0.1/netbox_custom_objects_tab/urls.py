# Tab URLs live under the parent model's namespace (e.g., /dcim/devices/<pk>/custom-objects/).
# This plugin registers no pages of its own; urlpatterns must still exist for the plugin loader.
app_name = "netbox_custom_objects_tab"
urlpatterns = []
