# cmd2.clipboard

::: cmd2.clipboard
