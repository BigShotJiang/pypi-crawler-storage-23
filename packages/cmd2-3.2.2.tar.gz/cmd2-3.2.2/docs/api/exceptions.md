# cmd2.exceptions

::: cmd2.exceptions
