import numpy as np
import pandas as pd
import h5py
import os
import gzip
from scipy.sparse import csr_matrix
import scipy.sparse as sp
from scipy.io import mmwrite
from .rotate import rotateXY


def get_cells(inDir, outDir, SN, segmentation = 'ssDNA', genome='unknown', theta=0, anticlockwise=False, center=(0,0), flip='none', flip_offset=30000, decimals=2 ):
    os.makedirs(outDir + '/raw', exist_ok=True)
    os.makedirs(outDir + '/cell_feature_matrix', exist_ok=True)

    cells = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cell'][:]
    cells = pd.DataFrame(cells)

    # barcode
    cell_names = cells['id']
    pd.Series(cell_names).to_csv(outDir + '/cell_feature_matrix/barcodes.tsv.gz', header=False, index=False, sep='\t', compression='gzip')

    # feature
    tGene = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/gene'][:]
    tGene = pd.DataFrame({
        field: (np.char.decode(tGene[field], 'utf-8') if tGene.dtype[field].kind == 'S' else tGene[field])
        for field in tGene.dtype.names})
    tGene = pd.DataFrame(tGene)[['geneID', 'geneName']]
    tGene = tGene.rename(columns={'geneID': 'gene_id', 'geneName': 'gene_symbol'})
    tGene['feature_type'] = 'Gene Expression'
    tGene = tGene[['gene_id', 'gene_symbol', 'feature_type']]
    tGene.to_csv(outDir + '/cell_feature_matrix/features.tsv.gz', header=False, index=False, sep='\t', compression='gzip')

    # matrix
    exp_array = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cellExp'][:]  # cell(行)Xgene(列)
    indptr = np.append(cells['offset'], len(exp_array))  # indptr 为每行起始 + 总记录数
    exp_matrix = csr_matrix((exp_array['count'], exp_array['geneID'], indptr), shape=(len(cells), len(tGene)),
                            dtype=np.int32)
    exp_matrix = exp_matrix.astype(np.int32).tocsc()  # 转变成column压缩的稀疏矩阵
    exp_matrix = exp_matrix.transpose()  # 转置矩阵：从(cells × genes) 变为 (genes × cells)
    mmwrite(gzip.open(os.path.join(outDir, 'cell_feature_matrix/matrix.mtx.gz'), 'wb'), exp_matrix)

    # control gene
    vGene = pd.DataFrame({
        'gene_id': [f'NegativeControl{i + 1}' for i in range(10)] + [f'GenomicControl{i + 1}' for i in range(10)],
        'gene_symbol': [f'NegativeControl{i + 1}' for i in range(10)] + [f'GenomicControl{i + 1}' for i in range(10)],
        'feature_type': ['Negative Control Codeword'] * 10 + ['Genomic Control'] * 10})

    geneTV = pd.concat([tGene, vGene], axis=0)

    # control matrix
    np.random.seed(123)
    n_rows = len(vGene)  # 行数 = vGene的行数
    n_cols = exp_matrix.shape[1]  # 列数 = 细胞数
    denMTX = np.random.choice([0, 1, 2], size=(n_rows, n_cols), p=[0.8, 0.18, 0.02])  # 以概率p随机生成值 (0,1,2), 并创建矩阵
    vMTX = sp.csc_matrix(denMTX)  # 转化成稀疏矩阵

    mtxTV = sp.vstack([exp_matrix, vMTX]).tocsc()

    # save h5
    dirH5 = os.path.join(outDir, 'cell_feature_matrix.h5')
    if os.path.exists(dirH5):
        os.remove(dirH5)

    with h5py.File(dirH5, 'w') as f:
        m = f.create_group('matrix')

        m.create_dataset('data', data=mtxTV.data)  # 存储非零元素的值。
        m.create_dataset('indices', data=mtxTV.indices.astype(np.int32))  # 存储每行中非零元素的列索引。
        m.create_dataset('indptr', data=mtxTV.indptr.astype(np.int32))  # 存储每行非零元素在data数组中起始位置的索引。
        m.create_dataset('shape', data=mtxTV.shape)  # 矩阵的形状（行数，列数）

        m.create_dataset('barcodes', data=np.array(cell_names, dtype='S'))
        fts = m.create_group('features')
        fts.create_dataset('_all_tag_keys', data=np.array(['genome'], dtype='S'))
        fts.create_dataset('id', data=geneTV['gene_id'].values.astype('S'))
        fts.create_dataset('name', data=geneTV['gene_symbol'].values.astype('S'))
        fts.create_dataset('feature_type', data=geneTV['feature_type'].values.astype('S'))
        fts.create_dataset('genome', data=np.repeat(genome.encode(), len(geneTV)))

    print("\n✅ cell_feature_matrix are retrieved successfully!")
    print(f"✅ cell_feature_matrix saved as CSV and HDF5")


    # cell centroid
    if theta != 0: # 旋转centroid
        cells = rotateXY(df=cells, theta=theta, anticlockwise=anticlockwise, center=center, x_col='x', y_col='y', decimals=decimals)
    if flip == 'lr': # 左右翻转centroid
        cells['x'] = flip_offset - cells['x']
    if flip == 'ud': # 上下翻转centroid
        cells['y'] = flip_offset - cells['y']

    cells["segmentation_method"] = segmentation ###
    cells = cells.rename(columns={'area': 'cell_area', 'id': 'cell_id', 'x': 'x_centroid', 'y': 'y_centroid'})
    cells = cells[["cell_id", "x_centroid", "y_centroid", "cell_area", "segmentation_method", "dnbCount"]] # 排列
    cells.to_csv(outDir + '/raw/cells.csv.gz', index=False, sep=',', compression='gzip')  # 保存成csv格式
    cells.to_parquet(outDir + '/cells.parquet', index=False)
    print("\n✅ cell centroids are retrieved successfully!")
    print(f"✅ cell centroids saved as CSV and parquet")

    # cell boundaries
    cellBorder = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cellBorder'][:]
    # cells中的centroid坐标,已经是旋转以后的,
    # 此处用原始未旋转的centroid坐标, 求得细胞boundary坐标,然后对细胞boundary进行旋转
    cells_ori = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cell'][:]
    cells_ori = pd.DataFrame(cells_ori)

    label_id = cells_ori['id']
    boundary_list = []
    for i in label_id:
        cell_data = cellBorder[i]
        valid_points = [(x, y) for x, y in cell_data if not (x == 32767 and y == 32767)]
        df = pd.DataFrame(valid_points, columns=['vertex_x', 'vertex_y'])
        df['vertex_x'] = df['vertex_x'] + cells_ori.iloc[i]['x']
        df['vertex_y'] = df['vertex_y'] + cells_ori.iloc[i]['y']
        df['cell_id'] = i
        boundary_list.append(df)

    cellboundary = pd.concat(boundary_list, ignore_index=True)

    if theta != 0: # 旋转cell boundary
        cellboundary = rotateXY(df=cellboundary, theta=theta, anticlockwise=anticlockwise, center=center, x_col='vertex_x', y_col='vertex_y', decimals=decimals)

    if flip == 'lr':
        cellboundary['vertex_x'] = flip_offset - cellboundary['vertex_x']

    if flip == 'ud':
        cellboundary['vertex_y'] = flip_offset - cellboundary['vertex_y']

    cellboundary = cellboundary[["cell_id", "vertex_x", "vertex_y"]]  # 排序成Xenium格式

    cellboundary.to_csv(outDir + '/raw/cell_boundaries.csv.gz', index=False, compression='gzip')  # 保存成csv格式
    print("\n✅ cell boundareis are retrieved successfully!")
    cellboundary.to_parquet(outDir + '/cell_boundaries.parquet', index=False)
    print(f"✅ cell boundaries saved as CSV and parquet")


def get_transcripts(inDir, SN, outDir, cellbin_gem=False, theta=0, anticlockwise=False, center=(0,0), flip='none', flip_offset=30000, decimals=2 ):
    os.makedirs(outDir + '/raw', exist_ok=True)
    # 从.tissue.gef读入transcripts的x,y,count, 以gene为顺序
    transcripts_ori = h5py.File(inDir + "/" + SN + ".tissue.gef", 'r')['geneExp/bin1/expression'][:]
    transcripts_ori = pd.DataFrame(transcripts_ori)
    transcripts = transcripts_ori.copy()

    # 从.tissue.gef读入transcripts的gene meta, gene count表示检测到该基因的DNB总数
    moles = h5py.File(inDir + "/" + SN + ".tissue.gef", 'r')['geneExp/bin1/gene'][:]
    moles = pd.DataFrame({field: (np.char.decode(moles[field], 'utf-8') if moles.dtype[field].kind == 'S' else moles[field]) for field in moles.dtype.names})

    transcripts['feature_name'] = np.repeat(moles['geneName'].values, moles['count'].values.astype(int))
    transcripts['gene_id'] = np.repeat(moles['geneID'].values, moles['count'].values.astype(int))

    transcripts["transcript_id"] = [f'M{i}' for i in range(len(transcripts))]
    transcripts = transcripts.assign(xy=lambda df: df['x'].astype(str) + ':' + df['y'].astype(str)) # xy=x:y 每个唯一的x:y对应每个DNB

    if theta != 0: # 旋转transcripts
        transcripts = rotateXY(df=transcripts, theta=theta, anticlockwise=anticlockwise, center=center, x_col='x', y_col='y', decimals=decimals)

    if flip == 'lr':
        transcripts['x'] = flip_offset - transcripts['x']

    if flip == 'ud':
        transcripts['y'] = flip_offset - transcripts['y']

    transcripts = transcripts.rename(columns={'x': 'x_location', 'y': 'y_location'})
    transcripts = transcripts[["transcript_id", "gene_id", "feature_name", "x_location", "y_location", "xy", "count"]]

    transcripts.to_csv(outDir + '/raw/transcripts.csv.gz', index=False, compression='gzip')  # 保存成csv格式
    print("\n✅ transcripts are retrieved successfully!")
    transcripts.to_parquet(outDir + '/transcripts.parquet', index=False)  # 保存成parquet格式
    print(f"✅ Transcripts saved as CSV and parquet")


    if cellbin_gem:
        # 注意: transcripts的坐标是旋转之后的, 而x:y是初始未旋转的坐标
        # 从adjusted.cellbin.gem读入包含在细胞内的transcripts
        # 获取包含在细胞内的DNB坐标,及其所属细胞的ID
        moles_inCell = pd.read_csv(inDir + "/" + SN + ".adjusted.cellbin.gem.gz", compression='gzip', sep='\t', comment='#')
        DNB_inCell = moles_inCell[['x', 'y', 'CellID']].assign(xy=lambda df: df['x'].astype(str) + ':' + df['y'].astype(str)) # xy=x:y
        DNB_inCell = DNB_inCell.rename(columns={'CellID': 'cell_id'})
        DNB_inCell = DNB_inCell.drop_duplicates(subset=['xy'], keep='first')  # 去重,获取DNB的唯一坐标

        # 从transcripts中获取全部DNB的坐标
        DNB_all = transcripts[['x_location', 'y_location', 'xy']]
        DNB_all = DNB_all.drop_duplicates(subset=['xy'], keep='first')  # 去除重复的DNB坐标

        # 用DNB的坐标信息x:y,将全部DNB和cell DNB进行join
        DNB_cell = pd.merge(DNB_all, DNB_inCell[['cell_id', 'xy']].astype('str'), on='xy', how='left').fillna('-1') # 对DNB进行cell注释
        DNB_cell.to_csv(outDir + '/raw/DNB_cell.csv.gz', sep='\t', index=False, compression='gzip') # 保存DNB和细胞的对应关系

        # 用DNB的坐标信息x:y, 将transcripts和DNB进行join
        transcripts_cell = pd.merge(transcripts, DNB_cell[['xy', 'cell_id']].astype('str'), on='xy', how='left')
        transcripts_cell.to_csv(outDir + '/raw/transcripts_cell.csv.gz', index=False, compression='gzip')  # 保存成csv格式
        transcripts_cell.to_parquet(outDir + '/transcripts_cell.parquet', index=False)  # 保存成parquet格式
        print("\n✅ transcripts are mapped to each cell successfully!")

    print(f"Output directory: {outDir}")


def h5_view(h5File):
    def h5_tree(val, pre=''):
        items = len(val)
        for key, val in val.items():
            items -= 1
            if isinstance(val, h5py.Group):  # 列出Group
                print(pre + ('└── ' if items == 0 else '├── ') + key + '/')
                h5_tree(val, pre + ('    ' if items == 0 else '│   '))
            else:
                print(pre + ('└── ' if items == 0 else '├── ') + key + f' {val.shape} {val.dtype}')  # 列出datase

    with h5py.File(h5File, 'r') as f:
        print("Keys:", list(f.keys()))  # 列出所有 keys
        h5_tree(f)


# 使用示例
if __name__ == "__main__":
    # 设置参数
    inDir = "/media/dell/scRNA/spatial/Stereo/brainC04042E3/outs/visualization"  # 替换为您的输入目录
    outDir = "/media/dell/scRNA/spatial/Stereo/brainC04042E3/toXenium"  # 替换为您的输出目录
    SN = "C04042E3"  # 样本名称

    h5File = inDir + "/" + SN + ".adjusted.cellbin.gef"

    # 运行函数
    get_transcripts(inDir=inDir, SN=SN, outDir=outDir, cellbin_gem=True, anticlockwise=True, theta= 130)
    # h5_view(h5File)



