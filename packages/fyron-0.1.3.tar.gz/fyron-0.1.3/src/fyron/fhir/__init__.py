"""FHIR functionality: auth, REST, SQL, types, and utilities."""

from .auth import Auth, TokenAuth
from .rest import FHIRRestClient
try:
    from .sql import FHIRSQLClient
except ImportError:  # optional psycopg / DB not needed for REST-only use
    FHIRSQLClient = None  # type: ignore
from .types import FHIRObj
from .utils import (
    extract_condition,
    extract_diagnostic_report,
    extract_encounter,
    extract_imaging_study,
    extract_observation,
    extract_patient,
    extract_procedure,
    process_condition_bundle,
    process_diagnostic_report_bundle,
    process_encounter_bundle,
    process_imaging_study_bundle,
    process_observation_bundle,
    process_patient_bundle,
    process_procedure_bundle,
    safe_get,
)

__all__ = [
    "Auth",
    "TokenAuth",
    "FHIRRestClient",
    "FHIRSQLClient",
    "FHIRObj",
    "extract_condition",
    "extract_diagnostic_report",
    "extract_encounter",
    "extract_imaging_study",
    "extract_observation",
    "extract_patient",
    "extract_procedure",
    "process_condition_bundle",
    "process_diagnostic_report_bundle",
    "process_encounter_bundle",
    "process_imaging_study_bundle",
    "process_observation_bundle",
    "process_patient_bundle",
    "process_procedure_bundle",
    "safe_get",
]
