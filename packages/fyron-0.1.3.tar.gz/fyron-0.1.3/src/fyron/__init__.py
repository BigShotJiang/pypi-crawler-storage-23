"""Fyron: interoperable healthcare data and AI workflows."""

from __future__ import annotations

def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("fyron")
    except Exception:
        return "0.1.0"

from .fhir.auth import Auth

from .fhir.rest import FHIRRestClient
try:
    from .fhir.sql import FHIRSQLClient
except ImportError:  # optional psycopg / DB not needed for REST-only use
    FHIRSQLClient = None  # type: ignore
from .dicom.client import DICOMDownloader
from .llm.agent import LLMAgent
from .documents.client import DocumentDownloader
from .fhir.types import FHIRObj
from .fhir.utils import (
    extract_condition,
    extract_diagnostic_report,
    extract_encounter,
    extract_imaging_study,
    extract_observation,
    extract_patient,
    extract_procedure,
    process_condition_bundle,
    process_diagnostic_report_bundle,
    process_encounter_bundle,
    process_imaging_study_bundle,
    process_observation_bundle,
    process_patient_bundle,
    process_procedure_bundle,
    safe_get,
)
from .core.io import DataIO, TeableClient, read_csv, read_excel, write_csv, write_excel
from .core.env import load_env

__all__ = [
    "Auth",
    "FHIRRestClient",
    "FHIRSQLClient",
    "DICOMDownloader",
    "LLMAgent",
    "DocumentDownloader",
    "FHIRObj",
    "extract_condition",
    "extract_diagnostic_report",
    "extract_encounter",
    "extract_imaging_study",
    "extract_observation",
    "extract_patient",
    "extract_procedure",
    "process_condition_bundle",
    "process_diagnostic_report_bundle",
    "process_encounter_bundle",
    "process_imaging_study_bundle",
    "process_observation_bundle",
    "process_patient_bundle",
    "process_procedure_bundle",
    "safe_get",
    "DataIO",
    "TeableClient",
    "load_env",
    "read_csv",
    "read_excel",
    "write_csv",
    "write_excel",
]
__version__ = _get_version()
