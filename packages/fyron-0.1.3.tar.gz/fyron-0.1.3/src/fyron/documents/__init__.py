"""Document download functionality."""

from .client import DocumentDownloader

__all__ = ["DocumentDownloader"]
