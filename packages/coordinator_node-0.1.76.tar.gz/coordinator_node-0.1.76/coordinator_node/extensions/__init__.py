"""Extension points resolved from config-defined callable paths."""
