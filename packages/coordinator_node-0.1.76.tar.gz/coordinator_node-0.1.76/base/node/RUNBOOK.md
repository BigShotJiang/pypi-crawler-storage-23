# RUNBOOK - starter-challenge

## Start
```bash
make deploy
```

## Verify
```bash
make verify-e2e
```

## Stop
```bash
make down
```

## Common issues

### Ports already in use
Preflight will halt if required ports are busy.

Inspect:
```bash
lsof -nP -iTCP:3000 -sTCP:LISTEN
lsof -nP -iTCP:8000 -sTCP:LISTEN
lsof -nP -iTCP:9091 -sTCP:LISTEN
lsof -nP -iTCP:5432 -sTCP:LISTEN
```

### BAD_IMPLEMENTATION / model runner failures
- Confirm `MODEL_BASE_CLASSNAME=tracker.TrackerBase` in `.local.env`.
- Ensure challenge package path is wired in `pyproject.toml` under `[tool.uv.sources]`.

### Clean reset
```bash
make down
rm -rf .venv
make deploy
make verify-e2e
```

## Local paths
- Node workspace: `node`
- Challenge package: `../challenge`
