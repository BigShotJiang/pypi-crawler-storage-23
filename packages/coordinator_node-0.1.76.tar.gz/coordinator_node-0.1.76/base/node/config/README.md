# config

- `callables.env`: scoring function callable path (e.g. `SCORING_FUNCTION=crunch_mycrunch.scoring:score_prediction`)
- `scheduled_prediction_configs.json`: prediction schedule and scope configuration
