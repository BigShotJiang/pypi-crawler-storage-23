#!/bin/bash

rm -rf deployment/model-orchestrator-local/data
rm -rf deployment/postgres
rm -rf deployment/report-ui

echo "Data have been successfully removed."