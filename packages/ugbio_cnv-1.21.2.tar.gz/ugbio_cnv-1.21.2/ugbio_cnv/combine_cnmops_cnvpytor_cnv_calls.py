import argparse
import logging
import os
import subprocess
import sys
import tempfile
from os.path import join as pjoin

import pysam
import ugbio_core.misc_utils as mu
from pyfaidx import Fasta
from ugbio_cnv.analyze_cnv_breakpoint_reads import analyze_cnv_breakpoints
from ugbio_cnv.analyze_cnv_breakpoint_reads import get_parser as get_breakpoint_parser
from ugbio_cnv.cnv_vcf_consts import INFO_TAG_REGISTRY
from ugbio_cnv.combine_cnv_vcf_utils import (
    cnv_vcf_to_bed,
    combine_vcf_headers_for_cnv,
    merge_cnvs_in_vcf,
    update_vcf_contig,
    write_vcf_records_with_source,
)
from ugbio_core.bed_utils import BedUtils
from ugbio_core.logger import logger
from ugbio_core.vcf_utils import VcfUtils


def run_cmd(cmd):
    logger.info(cmd)
    subprocess.run(cmd, shell=True, check=True)  # noqa: S602


def __parse_args_concat(parser: argparse.ArgumentParser) -> None:
    """Add arguments specific to the concat tool."""
    parser.add_argument(
        "--cnmops_vcf",
        help="input VCF file(s) holding cn.mops CNV calls",
        required=False,
        type=str,
        nargs="*",
        default=[],
    )
    parser.add_argument(
        "--cnvpytor_vcf",
        help="input VCF file(s) holding cnvpytor CNV calls",
        required=False,
        type=str,
        nargs="*",
        default=[],
    )
    parser.add_argument("--output_vcf", help="output combined VCF file", required=True, type=str)
    parser.add_argument("--fasta_index", help="fasta.fai file", required=True, type=str)
    parser.add_argument("--out_directory", help="output directory", required=False, type=str)
    parser.add_argument(
        "--make_ids_unique",
        help="ensure all variant IDs are unique by appending suffixes (e.g., ID_1, ID_2) when duplicates exist",
        action="store_true",
        default=False,
    )


def __parse_args_gaps_perc(parser: argparse.ArgumentParser) -> None:
    """Add arguments specific to the gaps percentage filter tool."""
    parser.add_argument("--calls_vcf", help="VCF file with CNV calls", required=True, type=str)
    parser.add_argument("--output_vcf", help="Output VCF file", required=True, type=str)
    parser.add_argument("--ref_fasta", help="Reference genome FASTA file", required=True, type=str)


def __parse_args_annotate_regions(parser: argparse.ArgumentParser) -> None:
    """Add arguments specific to the region annotation tool."""
    parser.add_argument("--input_vcf", help="Input VCF file with CNV calls", required=True, type=str)
    parser.add_argument("--output_vcf", help="Output VCF file with region annotations", required=True, type=str)
    parser.add_argument(
        "--annotation_bed",
        help="BED file with region annotations (chr, start, end, annotation)",
        required=True,
        type=str,
    )
    parser.add_argument(
        "--overlap_fraction",
        help="Minimum fraction of CNV that must overlap with annotation region (0.0-1.0)",
        required=False,
        type=float,
        default=0.5,
    )
    parser.add_argument(
        "--genome",
        help="Genome file (chr tab length or .fai)",
        required=True,
        type=str,
    )


def __parse_args_merge_records(parser: argparse.ArgumentParser) -> None:
    """Add arguments specific to the merge records tool."""
    parser.add_argument("--input_vcf", help="Input VCF file with CNV calls to merge", required=True, type=str)
    parser.add_argument("--output_vcf", help="Output VCF file with merged CNV calls", required=True, type=str)
    parser.add_argument(
        "--distance",
        help="Distance threshold for merging CNV segments (default: 0)",
        required=False,
        type=int,
        default=0,
    )


def __parse_args(argv: list[str]) -> argparse.Namespace:
    """
    Parse command-line arguments using subparsers for different tools.

    This allows each tool to have its own set of arguments while sharing
    common options like verbosity.

    To add a new tool:
    1. Create a new __parse_args_<toolname>() function with tool-specific arguments
    2. Add a new subparser below for the tool
    3. Add a new elif block in the run() function to handle the tool
    """
    # Main parser
    parser = argparse.ArgumentParser(
        prog="combine_cnmops_cnvpytor_cnv_calls.py",
        description="CNV processing toolkit - runs various CNV-related tools.",
    )

    # Common arguments across all tools
    parser.add_argument("--verbosity", help="Verbosity: ERROR, WARNING, INFO, DEBUG", required=False, default="INFO")

    # Create subparsers for different tools
    subparsers = parser.add_subparsers(dest="tool", help="Tool to run", required=True)

    # Concat tool subparser
    concat_parser = subparsers.add_parser(
        "concat",
        help="Combine CNV VCFs from different callers (cn.mops and cnvpytor)",
        description="Combines CNV VCF files from cn.mops and cnvpytor into a single sorted and indexed VCF.",
    )
    __parse_args_concat(concat_parser)

    gaps_perc_parser = subparsers.add_parser(
        "annotate_gaps",
        help="Annotate CNV calls with percentage of gaps (Ns) from reference genome",
        description="Annotates CNV calls in a VCF with the percentage of gaps (Ns) in the reference genome.",
    )
    __parse_args_gaps_perc(gaps_perc_parser)

    annotate_regions_parser = subparsers.add_parser(
        "annotate_regions",
        help="Annotate CNV calls with region annotations from BED file",
        description="Annotates CNV calls in a VCF with region-based annotations"
        " (e.g., telomere, centromere, low coverage).",
    )
    __parse_args_annotate_regions(annotate_regions_parser)

    merge_records_parser = subparsers.add_parser(
        "merge_records",
        help="Merge adjacent or nearby CNV records in a VCF file",
        description="Merges CNV records that are within a specified distance threshold.",
    )
    __parse_args_merge_records(merge_records_parser)

    analyze_breakpoints_parser = subparsers.add_parser(
        "analyze_breakpoint_reads",
        help="Analyze reads at CNV breakpoints for DUP/DEL evidence",
        description="Annotates CNV VCF with breakpoint read support information.",
    )
    # Reuse argument definitions from analyze_cnv_breakpoint_reads module
    get_breakpoint_parser(analyze_breakpoints_parser)

    return parser.parse_args(argv[1:])


def annotate_vcf_with_gap_perc(input_vcf: str, ref_fasta: str, output_vcf: str) -> None:
    """
    Annotate CNV VCF records with GAP_PERCENTAGE INFO field representing the fraction of 'N' bases in the CNV region.

    Parameters
    ----------
    input_vcf : str
        Path to input VCF file containing CNV calls.
    ref_fasta : str
        Path to reference genome FASTA file. Should have .fai index.
    output_vcf : str
        Path to output VCF file with GAP_PERCENTAGE annotation.
    """

    genome = Fasta(ref_fasta, rebuild=False, build_index=False)

    with pysam.VariantFile(input_vcf) as vcf_in:
        header = vcf_in.header
        if "GAP_PERCENTAGE" not in header.info:
            header.info.add(*INFO_TAG_REGISTRY["GAP_PERCENTAGE"][:-1])
        with pysam.VariantFile(output_vcf, "w", header=header) as vcf_out:
            for record in vcf_in:
                chrom = record.chrom
                start = record.start
                end = record.stop
                try:
                    seq_obj = genome[chrom][start : end + 1]
                    seq = seq_obj.seq if seq_obj is not None else ""
                    n_count = seq.upper().count("N")
                    region_len = end - start + 1
                    gap_perc = n_count / region_len if region_len > 0 else 0.0
                except Exception as e:
                    logger.warning(f"Could not retrieve sequence for {chrom}:{start}-{end}: {e}")
                    gap_perc = 0.0
                record.info["GAP_PERCENTAGE"] = round(gap_perc, 5)
                vcf_out.write(record)
    VcfUtils().index_vcf(output_vcf)


def annotate_vcf_with_regions(
    input_vcf: str, annotation_bed: str, output_vcf: str, genome: str, overlap_fraction: float = 0.5
) -> None:
    """
    Annotate CNV VCF records with region annotations from a BED file.

    For each CNV record, identifies overlapping annotation regions and collects their
    annotations. If the overlap fraction exceeds the threshold, all unique annotations
    are added to the REGION_ANNOTATIONS INFO field.

    Parameters
    ----------
    input_vcf : str
        Path to input VCF file containing CNV calls. Each record must have start and stop fields.
    annotation_bed : str
        Path to BED file with region annotations in format: chr, start, end, annotation.
        Annotations can contain multiple values separated by '|' (e.g., "Telomere_Centromere|Coverage-Mappability").
    output_vcf : str
        Path to output VCF file with REGION_ANNOTATIONS added to INFO field.
    overlap_fraction : float, optional
        Minimum fraction of CNV length that must overlap with annotation regions to
        collect annotations. Must be between 0.0 and 1.0. Default is 0.5.
    genome: str
        Genome file (chr tab length or .fai)

    Notes
    -----
    - For each CNV record, calculates overlap with all annotation regions in the BED file
    - Collects annotations from regions where overlap exceeds overlap_fraction * CNV_length
    - All annotation values (split by '|') are collected and made unique
    - Final unique annotations are joined with '|' and added to REGION_ANNOTATIONS INFO field
    - If no annotations meet the threshold, REGION_ANNOTATIONS will be empty or not added

    Examples
    --------
    >>> annotate_vcf_with_regions(
    ...     input_vcf="cnv_calls.vcf.gz",
    ...     annotation_bed="genome_regions.bed",
    ...     output_vcf="cnv_calls.annotated.vcf.gz",
    ...     geome = "Homo_sapiens_assembly38.fasta",
    ...     overlap_fraction=0.5
    ... )
    """
    # Create temporary directory in the same directory as output_vcf
    output_dir = os.path.dirname(output_vcf) or "."
    with tempfile.TemporaryDirectory(dir=output_dir) as tmpdir:
        # Step 1: Convert VCF to BED format with unique index-based identifiers
        logger.info("Converting VCF to BED format")
        vcf_bed = pjoin(tmpdir, "input_cnvs.bed")
        cnv_vcf_to_bed(input_vcf, vcf_bed, assign_id=True)

        # Step 2: Run bedtools coverage to calculate total overlap statistics
        # bedtools coverage output adds these columns to each interval in A:
        # - Number of features in B that overlapped
        # - Number of bases in A that had coverage from B
        # - Length of A interval
        # - Fraction of A that had coverage from B (this is what we need!)
        logger.info("Running bedtools coverage to calculate total overlaps")
        coverage_bed = pjoin(tmpdir, "coverage.bed")
        bed_utils = BedUtils()
        bed_utils.bedtools_coverage(vcf_bed, annotation_bed, coverage_bed)

        # Step 3: Parse coverage results to identify CNVs meeting the overlap threshold
        logger.info("Identifying CNVs meeting overlap threshold")
        cnv_indices_meeting_threshold = set()
        with open(coverage_bed) as cov_fh:
            for line in cov_fh:
                fields = line.rstrip().split("\t")
                record_id = fields[3]  # The unique identifier (e.g., CNV_000000001)
                idx = int(record_id.split("_")[1])  # Extract numeric index
                overlap_fraction_actual = float(fields[7])  # Fraction of bases in A with coverage from all B features

                if overlap_fraction_actual >= overlap_fraction:
                    cnv_indices_meeting_threshold.add(idx)

        # Step 4: Collect annotations for CNVs meeting threshold using bedtools map
        # bedtools map will aggregate all annotation values from overlapping B features
        logger.info("Collecting annotations for CNVs meeting threshold")
        map_bed = pjoin(tmpdir, "map.bed")
        # Use collapse operation to collect all annotation values (4th column) separated by '|'
        bed_utils.bedtools_map(
            vcf_bed, annotation_bed, map_bed, column=4, operation="collapse", additional_args=f'-delim "|" -g {genome}'
        )

        # Parse map results to collect annotations only for CNVs meeting threshold
        cnv_annotations = {}  # Maps record_index -> set of annotation values
        with open(map_bed) as map_fh:
            for line in map_fh:
                fields = line.rstrip().split("\t")
                record_id = fields[3]  # From A (CNV) - format: CNV_000000001
                idx = int(record_id.split("_")[1])  # Extract the numeric index

                # Only collect annotations for CNVs that met the threshold
                if idx not in cnv_indices_meeting_threshold:
                    continue

                # The mapped column contains '|'-separated annotation values
                mapped_values = fields[4]
                if mapped_values != ".":  # bedtools map uses "." for no overlap
                    cnv_annotations[idx] = set(mapped_values.split("|"))

        # Step 5: Write output VCF with REGION_ANNOTATIONS
        logger.info("Writing annotated VCF")
        with pysam.VariantFile(input_vcf) as vcf_in:
            header = vcf_in.header

            # Add REGION_ANNOTATIONS INFO field if not present
            if "REGION_ANNOTATIONS" not in header.info:
                header.info.add(*INFO_TAG_REGISTRY["REGION_ANNOTATIONS"][:-1])

            with pysam.VariantFile(output_vcf, "w", header=header) as vcf_out:
                for record_index, record in enumerate(vcf_in):
                    # Add annotations if this CNV has any
                    if record_index in cnv_annotations and cnv_annotations[record_index]:
                        # Get existing annotations if present
                        existing_annotations = set()
                        if "REGION_ANNOTATIONS" in record.info:
                            existing_annotations = set(record.info["REGION_ANNOTATIONS"])

                        # Combine existing and new annotations
                        all_annotations = sorted(existing_annotations | cnv_annotations[record_index])
                        record.info["REGION_ANNOTATIONS"] = all_annotations

                    vcf_out.write(record)

    VcfUtils().index_vcf(output_vcf)
    logger.info(f"Successfully annotated VCF with regions: {output_vcf}")


def combine_cnv_vcfs(
    cnmops_vcf: list[str],
    cnvpytor_vcf: list[str],
    fasta_index: str,
    output_vcf: str,
    output_directory: str | None = None,
    *,
    make_ids_unique: bool = False,
) -> str:
    """
    Concatenates VCF files from cn.mops and CNVpytor into a single sorted and indexed VCF.

    This function performs the following steps:
    1. Updates headers of all VCFs to contain the same contigs from the FASTA index
    2. Combines the headers from all updated files (excluding FILTER fields)
    3. Adds an INFO tag for the source (CNV_SOURCE) to identify the caller
    4. Writes records from all VCF files to the combined output
    5. Sorts and indexes the final VCF

    Note: This function does NOT merge overlapping CNV records - it simply concatenates
    all records from all input files.

    Parameters
    ----------
    cnmops_vcf : list[str]
        List of paths to cn.mops VCF files (.vcf.gz). Can be empty.
    cnvpytor_vcf : list[str]
        List of paths to CNVpytor VCF files (.vcf.gz). Can be empty.
    fasta_index : str
        Path to the reference genome FASTA index file (.fai)
    output_vcf : str
        Path to the output combined VCF file (.vcf.gz)
    output_directory : str, optional
        Directory for storing temporary files
    make_ids_unique : bool, optional
        If True, assign unique IDs to all variants (default: False)

    Returns
    -------
    str
        Path to the final sorted and indexed combined VCF file

    Raises
    ------
    FileNotFoundError
        If any of the input files do not exist
    ValueError
        If both cnmops_vcf and cnvpytor_vcf are empty
    RuntimeError
        If VCF processing fails

    Examples
    --------
    >>> combined_vcf = combine_cnv_vcfs(
    ...     cnmops_vcf=["cnmops.vcf.gz"],
    ...     cnvpytor_vcf=["cnvpytor1.vcf.gz", "cnvpytor2.vcf.gz"],
    ...     fasta_index="genome.fa.fai",
    ...     output_vcf="combined.vcf.gz",
    ...     output_directory="/tmp/cnv_combine",
    ...     make_ids_unique=True
    ... )
    """
    # Validate that at least one VCF list is not empty
    if not cnmops_vcf and not cnvpytor_vcf:
        raise ValueError("At least one of cnmops_vcf or cnvpytor_vcf must be non-empty")

    # Create output directory if it doesn't exist
    if output_directory is None:
        output_directory = os.path.dirname(os.path.abspath(output_vcf))
    if output_directory:  # file with no directory evaluates to ""
        os.makedirs(output_directory, exist_ok=True)

    vcf_utils = VcfUtils()

    # Step 1: Update headers to contain same contigs from FASTA index
    logger.info("Updating VCF headers to match FASTA index contigs")
    updated_vcfs = []
    vcf_metadata = []  # List of (updated_path, source_name) tuples

    # Collect all VCF files with their source labels
    all_vcf_sources = [(vcf, "cn.mops") for vcf in cnmops_vcf] + [(vcf, "cnvpytor") for vcf in cnvpytor_vcf]

    # Update headers for all VCFs
    for idx, (vcf_file, source) in enumerate(all_vcf_sources):
        updated_vcf = update_vcf_contig(vcf_utils, vcf_file, fasta_index, output_directory, index=idx)
        updated_vcfs.append(updated_vcf)
        vcf_metadata.append((updated_vcf, source))

    # Step 2: Open updated VCF files, combine headers (excluding FILTER fields), and add CNV_SOURCE tag
    logger.info("Combining VCF headers and adding CNV_SOURCE INFO tag")

    # Open all VCF files
    vcf_handles = [pysam.VariantFile(vcf_path) for vcf_path, _ in vcf_metadata]

    try:
        # Combine headers from all files
        combined_header = vcf_handles[0].header.copy()
        for vcf_handle in vcf_handles[1:]:
            combined_header = combine_vcf_headers_for_cnv(combined_header, vcf_handle.header)

        # Add INFO tag for source if not already present
        if "CNV_SOURCE" not in combined_header.info:
            combined_header.info.add(*INFO_TAG_REGISTRY["CNV_SOURCE"][:-1])

        # Step 3: Write records from all VCF files
        logger.info(f"Writing records from {len(vcf_handles)} VCF files to temporary combined VCF")
        temp_combined_vcf = pjoin(output_directory, "temp_combined.vcf.gz")

        with pysam.VariantFile(temp_combined_vcf, "w", header=combined_header) as vcf_out:
            # Write records from each VCF with appropriate source annotation
            seen_ids = set()
            for vcf_handle, (_, source_name) in zip(vcf_handles, vcf_metadata, strict=False):
                seen_ids = write_vcf_records_with_source(
                    vcf_handle,
                    vcf_out,
                    combined_header,
                    source_name,
                    make_ids_unique=make_ids_unique,
                    seen_ids=seen_ids,
                )
    finally:
        # Close all VCF handles
        for vcf_handle in vcf_handles:
            vcf_handle.close()

    # Step 4: Sort and index the VCF
    logger.info("Sorting and indexing the combined VCF")
    vcf_utils.sort_vcf(temp_combined_vcf, output_vcf)
    vcf_utils.index_vcf(output_vcf)

    # Clean up temporary files
    mu.cleanup_temp_files(updated_vcfs + [temp_combined_vcf])

    logger.info(f"Successfully created combined VCF: {output_vcf}")
    return output_vcf


def run(argv: list[str]):
    """
    Driver function for CNV processing tools.

    This function routes execution to the appropriate tool based on the first argument.
    Currently supported tools:
    - concat: Combines CNV VCFs from cn.mops and cnvpytor into a single sorted VCF

    The function can be called:
    1. As a standalone script: python combine_cnmops_cnvpytor_cnv_calls.py concat --cnmops_vcf ... --cnvpytor_vcf ...
    2. As part of combine_cnmops_cnvpytor_cnv_calls: combine_cnmops_cnvpytor_cnv_calls concat --cnmops_vcf ...

    Parameters
    ----------
    argv : list of str
        Command-line arguments where argv[1] is the tool name (e.g., 'concat')
        and remaining arguments are tool-specific parameters.

    Examples
    --------
    >>> run(['prog', 'concat', '--cnmops_vcf', 'cnmops.vcf.gz',
    ...      '--cnvpytor_vcf', 'cnvpytor1.vcf.gz', 'cnvpytor2.vcf.gz',
    ...      '--output_vcf', 'combined.vcf.gz',
    ...      '--fasta_index', 'genome.fa.fai', '--out_directory', '/tmp'])
    """
    args = __parse_args(argv)
    logger.setLevel(getattr(logging, args.verbosity))

    if args.tool == "concat":
        combine_cnv_vcfs(
            cnmops_vcf=args.cnmops_vcf,
            cnvpytor_vcf=args.cnvpytor_vcf,
            fasta_index=args.fasta_index,
            output_vcf=args.output_vcf,
            output_directory=args.out_directory,
            make_ids_unique=args.make_ids_unique,
        )
    elif args.tool == "annotate_gaps":
        annotate_vcf_with_gap_perc(
            input_vcf=args.calls_vcf,
            ref_fasta=args.ref_fasta,
            output_vcf=args.output_vcf,
        )
    elif args.tool == "annotate_regions":
        annotate_vcf_with_regions(
            input_vcf=args.input_vcf,
            annotation_bed=args.annotation_bed,
            output_vcf=args.output_vcf,
            overlap_fraction=args.overlap_fraction,
            genome=args.genome,
        )
    elif args.tool == "merge_records":
        merge_cnvs_in_vcf(
            input_vcf=args.input_vcf,
            output_vcf=args.output_vcf,
            distance=args.distance,
            ignore_filter=False,
            ignore_sv_type=True,
            pick_best=True,
        )
    elif args.tool == "analyze_breakpoint_reads":
        analyze_cnv_breakpoints(
            bam_file=args.bam_file,
            vcf_file=args.vcf_file,
            cushion=args.cushion,
            output_file=args.output_file,
            reference_fasta=args.reference_fasta,
        )
    else:
        raise ValueError(f"Unknown tool: {args.tool}")


def main():
    run(sys.argv)


def main_concat():
    """
    Entry point for standalone combine_cnv_vcfs script.

    This allows running the concat tool directly without specifying the tool name:
    combine_cnv_vcfs --cnmops_vcf ... --cnvpytor_vcf ...

    Instead of:
    combine_cnmops_cnvpytor_cnv_calls concat --cnmops_vcf ... --cnvpytor_vcf ...
    """
    # Insert 'concat' as the tool argument
    argv = [sys.argv[0], "concat"] + sys.argv[1:]
    run(argv)


def main_gaps_perc():
    """
    Entry point for standalone annotate_vcf_with_gap_perc script.

    This allows running the annotate_gaps tool directly without specifying the tool name:
    annotate_gaps --input_vcf ... --ref_fasta ... --output_vcf ...

    Instead of:
    combine_cnmops_cnvpytor_cnv_calls annotate_gaps --input_vcf ... --ref_fasta ... --output_vcf ...
    """
    # Insert 'annotate_gaps' as the tool argument
    argv = [sys.argv[0], "annotate_gaps"] + sys.argv[1:]
    run(argv)


def main_annotate_regions():
    """
    Entry point for standalone annotate_vcf_with_regions script.

    This allows running the annotate_regions tool directly without specifying the tool name:
    annotate_regions --input_vcf ... --annotation_bed ... --output_vcf ... --overlap_fraction ...

    Instead of:
    combine_cnmops_cnvpytor_cnv_calls annotate_regions --input_vcf ... --annotation_bed ... --output_vcf ...
    """
    # Insert 'annotate_regions' as the tool argument
    argv = [sys.argv[0], "annotate_regions"] + sys.argv[1:]
    run(argv)


def main_merge_records():
    """
    Entry point for standalone merge_cnvs_in_vcf script.

    This allows running the merge_records tool directly without specifying the tool name:
    merge_records --input_vcf ... --output_vcf ... --distance ...

    Instead of:
    combine_cnmops_cnvpytor_cnv_calls merge_records --input_vcf ... --output_vcf ... --distance ...
    """
    # Insert 'merge_records' as the tool argument
    argv = [sys.argv[0], "merge_records"] + sys.argv[1:]
    run(argv)


def main_analyze_breakpoints():
    """
    Entry point for standalone analyze_breakpoint_reads script.

    This allows running the analyze_breakpoint_reads tool directly without specifying the tool name:
    analyze_cnv_breakpoint_reads --bam-file ... --vcf-file ... --output-file ...

    Instead of:
    combine_cnmops_cnvpytor_cnv_calls analyze_breakpoint_reads --bam-file ... --vcf-file ...
    """
    # Insert 'analyze_breakpoint_reads' as the tool argument
    argv = [sys.argv[0], "analyze_breakpoint_reads"] + sys.argv[1:]
    run(argv)


if __name__ == "__main__":
    main()
