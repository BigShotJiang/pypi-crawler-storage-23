# ipeds_wrangler/__init__.py

"""
ipeds_wrangler - a Python package for wrangling IPEDS data
"""

from .download_ipeds_databases import download_ipeds_databases

__version__ = "0.0.8"
__all__ = ['download_ipeds_databases']

def describe():
    """Print the package description."""
    description = (
        "ipeds_wrangler\n"
        f"version: {__version__}\n"
        "a Python package for wrangling IPEDS data"
    )
    print(description)