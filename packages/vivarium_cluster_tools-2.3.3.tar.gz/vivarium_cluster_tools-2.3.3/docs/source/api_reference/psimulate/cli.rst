.. automodule:: vivarium_cluster_tools.psimulate.cli
