implement combat mechanics
round-up or round-down
input manually, alternatively
attack (self, aenemy, weapon, terrain)
