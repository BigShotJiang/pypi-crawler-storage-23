"""
Unit tests for SSSP (Soil Salinity Stress Parameter)
"""

import pytest
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from palma.parameters.sssp import SSSP
from palma.parameters.base import AlertLevel


class TestSSSP:
    """Test suite for SSSP parameter"""
    
    def setup_method(self):
        """Setup before each test"""
        self.sssp = SSSP(ec_critical=8.4, ec_baseline=1.2)
        
    def test_initialization(self):
        """Test SSSP initialization"""
        assert self.sssp.ec_critical == 8.4
        assert self.sssp.ec_baseline == 1.2
        assert len(self.sssp.sampling_depths) == 4
        
    def test_compute(self):
        """Test compute with sample data"""
        # Sample EC measurements at different depths
        data = {
            'ec_measurements': [1.5, 2.1, 3.2, 4.8],
            'depths': [15, 30, 60, 90]
        }
        
        result = self.sssp.compute(data)
        
        # Should be in moderate range
        assert 0.4 < result.value < 0.6
        assert 0 <= result.normalized <= 1
        
    def test_normalize(self):
        """Test normalization"""
        # Values already normalized
        assert self.sssp.normalize(0.3) == 0.3
        assert self.sssp.normalize(1.2) == 1.0  # Clipped
        
    def test_osmotic_potential(self):
        """Test osmotic potential calculation"""
        ec = 8.4
        osmotic = -0.036 * ec
        assert osmotic == -0.3024  # MPa
        
    def test_depth_weights(self):
        """Test depth weighting"""
        depths = [15, 30, 60, 90]
        weights = self.sssp._calculate_depth_weights(depths)
        
        # Should sum to 1
        assert abs(sum(weights) - 1.0) < 1e-6
        
        # Shallower depths should have higher weights
        assert weights[0] > weights[1] > weights[2] > weights[3]
        
    def test_time_to_threshold(self):
        """Test time to critical threshold prediction"""
        current_ec = 5.0
        irrigation_ec = 1.0
        annual_irrigation = 1000  # mm
        
        years = self.sssp.predict_time_to_threshold(
            current_ec, irrigation_ec, annual_irrigation
        )
        
        assert years > 0
        assert years < 20  # Reasonable range
        
        # Already at critical
        years = self.sssp.predict_time_to_threshold(
            8.5, irrigation_ec, annual_irrigation
        )
        assert years == 0
        
    def test_leaching_requirement(self):
        """Test leaching requirement calculation"""
        # This would be in the result metadata
        data = {'ec_measurements': [5.0, 5.5, 6.0, 6.5]}
        result = self.sssp.compute(data, irrigation_ec=1.0)
        
        assert 'leaching_requirement' in result.metadata
        assert result.metadata['leaching_requirement'] >= 0
        
    def test_alert_levels(self):
        """Test alert level determination"""
        test_cases = [
            (0.1, AlertLevel.EXCELLENT),
            (0.3, AlertLevel.GOOD),
            (0.5, AlertLevel.MODERATE),
            (0.8, AlertLevel.CRITICAL),
            (0.95, AlertLevel.COLLAPSE)
        ]
        
        for value, expected in test_cases:
            level = self.sssp.get_alert_level(value)
            assert level == expected, f"Failed for value {value}"
            
    def test_edge_cases(self):
        """Test edge cases"""
        # Very low EC
        result = self.sssp.compute({'ec_measurements': [0.1, 0.1, 0.1, 0.1]})
        assert result.normalized < 0.1
        
        # Very high EC
        result = self.sssp.compute({'ec_measurements': [20.0, 20.0, 20.0, 20.0]})
        assert result.normalized == 1.0


if __name__ == "__main__":
    pytest.main([__file__])
