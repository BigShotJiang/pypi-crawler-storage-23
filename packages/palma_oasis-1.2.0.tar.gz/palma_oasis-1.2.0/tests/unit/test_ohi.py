"""
Unit tests for OHI (Oasis Health Index) Composite
"""

import pytest
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from palma.ohi.composite import OHIComposite, OHIStatus
from palma.parameters.base import ParameterResult, AlertLevel


class TestOHI:
    """Test suite for OHI composite"""
    
    def setup_method(self):
        """Setup before each test"""
        self.ohi = OHIComposite()
        
    def test_initialization(self):
        """Test OHI initialization"""
        # Default weights from paper
        assert abs(self.ohi.weights['ARVC'] - 0.22) < 1e-6
        assert abs(self.ohi.weights['PTSI'] - 0.18) < 1e-6
        assert abs(self.ohi.weights['SSSP'] - 0.17) < 1e-6
        assert abs(self.ohi.weights['CMBF'] - 0.16) < 1e-6
        assert abs(self.ohi.weights['SVRI'] - 0.14) < 1e-6
        assert abs(self.ohi.weights['WEPR'] - 0.08) < 1e-6
        assert abs(self.ohi.weights['BST'] - 0.05) < 1e-6
        
        # Sum to 1
        total = sum(self.ohi.weights.values())
        assert abs(total - 1.0) < 1e-6
        
    def test_compute(self):
        """Test OHI computation"""
        # Sample parameter values (normalized)
        param_values = {
            'ARVC': 0.22,   # Excellent
            'PTSI': 0.18,   # Excellent
            'SSSP': 0.17,   # Excellent
            'CMBF': 0.16,   # Excellent
            'SVRI': 0.14,   # Excellent
            'WEPR': 0.08,   # Excellent
            'BST': 0.05     # Excellent
        }
        
        result = self.ohi.compute(param_values)
        
        assert result.value < 0.25  # Excellent
        assert result.status == OHIStatus.EXCELLENT
        assert result.lead_time_days > 80
        
    def test_moderate_ohi(self):
        """Test moderate OHI scenario"""
        param_values = {
            'ARVC': 0.5,
            'PTSI': 0.5,
            'SSSP': 0.5,
            'CMBF': 0.5,
            'SVRI': 0.5,
            'WEPR': 0.5,
            'BST': 0.5
        }
        
        result = self.ohi.compute(param_values)
        
        assert 0.45 < result.value < 0.65  # Moderate
        assert result.status == OHIStatus.MODERATE
        assert 20 < result.lead_time_days < 40
        
    def test_critical_ohi(self):
        """Test critical OHI scenario"""
        param_values = {
            'ARVC': 0.8,
            'PTSI': 0.8,
            'SSSP': 0.8,
            'CMBF': 0.8,
            'SVRI': 0.8,
            'WEPR': 0.8,
            'BST': 0.8
        }
        
        result = self.ohi.compute(param_values)
        
        assert 0.65 < result.value < 0.80  # Critical
        assert result.status == OHIStatus.CRITICAL
        assert result.lead_time_days < 20
        
    def test_collapse_ohi(self):
        """Test collapse OHI scenario"""
        param_values = {
            'ARVC': 0.9,
            'PTSI': 0.9,
            'SSSP': 0.9,
            'CMBF': 0.9,
            'SVRI': 0.9,
            'WEPR': 0.9,
            'BST': 0.9
        }
        
        result = self.ohi.compute(param_values)
        
        assert result.value > 0.80  # Collapse
        assert result.status == OHIStatus.COLLAPSE
        assert result.lead_time_days == 0
        
    def test_compute_from_raw(self):
        """Test computation from raw data"""
        # Mock raw data
        raw_data = {
            'arvc': {'heads': [25.0] * 10},
            'ptsi': {'t_ambient': 45.0, 't_subcanopy': 33.6},
            'sssp': {'ec_measurements': [2.0, 3.0, 4.0, 5.0]},
            'cmbf': {'oasis': {'temperature': 33.6}, 'desert': {'temperature': 45.0}},
            'svri': {'ndvi': 0.65, 'ndre': 0.45},
            'wepr': {'et_transpiration': 840, 'et_total': 1200},
            'bst': {'shannon_observed': 1.8, 'shannon_reference': 2.5}
        }
        
        result = self.ohi.compute_from_raw(raw_data)
        
        assert 0 <= result.value <= 1
        assert isinstance(result.status, OHIStatus)
        assert len(result.parameters) == 7
        
    def test_recommendations(self):
        """Test recommendation generation"""
        # Excellent case
        param_values = {p: 0.1 for p in self.ohi.weights.keys()}
        result = self.ohi.compute(param_values)
        recs = self.ohi.get_recommendations(result)
        assert len(recs) > 0
        
        # Critical case
        param_values = {p: 0.7 for p in self.ohi.weights.keys()}
        result = self.ohi.compute(param_values)
        recs = self.ohi.get_recommendations(result)
        assert "EMERGENCY" in recs[0]
        
    def test_invalid_weights(self):
        """Test invalid weights"""
        with pytest.raises(ValueError):
            OHIComposite(weights={'ARVC': 1.0})  # Doesn't sum to 1


if __name__ == "__main__":
    pytest.main([__file__])
