"""
Unit tests for PTSI (Phyto-Thermal Shielding Index)
"""

import pytest
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from palma.parameters.ptsi import PTSI
from palma.parameters.base import AlertLevel


class TestPTSI:
    """Test suite for PTSI parameter"""
    
    def setup_method(self):
        """Setup before each test"""
        self.ptsi = PTSI(k_extinction=0.52, layer_attenuation=0.41, leaf_area_index=4.8)
        
    def test_initialization(self):
        """Test PTSI initialization"""
        assert self.ptsi.k_extinction == 0.52
        assert self.ptsi.layer_attenuation == 0.41
        assert self.ptsi.leaf_area_index == 4.8
        
    def test_compute(self):
        """Test compute with sample data"""
        # Sample thermal data
        result = self.ptsi.compute(t_ambient=45.0, t_subcanopy=33.6)
        
        # Mean ΔT = 11.4°C from paper
        assert 10.0 < result.value < 13.0
        assert 0 <= result.normalized <= 1
        
    def test_normalize(self):
        """Test normalization function"""
        # Excellent range (>28%)
        assert self.ptsi.normalize(30.0) == 0.0
        assert self.ptsi.normalize(28.0) == 0.0
        
        # Collapse range (<10%)
        assert self.ptsi.normalize(8.0) == 1.0
        assert self.ptsi.normalize(5.0) == 1.0
        
        # Linear range
        assert 0 < self.ptsi.normalize(20.0) < 1
        
    def test_layer_attenuation(self):
        """Test multi-layer attenuation"""
        # 4-layer attenuation factor should be ~0.194
        atten = self.ptsi.calculate_layer_attenuation(4)
        assert 0.18 < atten < 0.20
        
        # Test with layer temperatures
        layer_temps = [45.0, 40.0, 35.0, 32.0]
        result = self.ptsi.compute(t_ambient=45.0, t_subcanopy=32.0, 
                                   layer_temperatures=layer_temps)
        
        assert result.value > 0
        
    def test_beer_lambert(self):
        """Test Beer-Lambert radiation attenuation"""
        # Test with different solar angles
        i0 = 1000
        lai = 4.8
        
        # Noon (θ=0)
        i_ground = self.ptsi._beer_lambert(i0, lai, 0)
        assert i_ground < i0
        
        # Morning (θ=60°)
        i_ground_morning = self.ptsi._beer_lambert(i0, lai, 60)
        assert i_ground_morning > i_ground  # More radiation reaches ground
        
    def test_lai_estimation(self):
        """Test LAI estimation from NDVI"""
        ndvi = 0.65
        lai = self.ptsi.estimate_lai_from_ndvi(ndvi)
        assert 3.0 < lai < 4.0
        
    def test_alert_levels(self):
        """Test alert level determination"""
        test_cases = [
            (8.0, AlertLevel.COLLAPSE),
            (12.0, AlertLevel.CRITICAL),
            (18.0, AlertLevel.MODERATE),
            (24.0, AlertLevel.GOOD),
            (30.0, AlertLevel.EXCELLENT)
        ]
        
        for value, expected in test_cases:
            normalized = self.ptsi.normalize(value)
            level = self.ptsi.get_alert_level(normalized)
            assert level == expected, f"Failed for value {value}"


if __name__ == "__main__":
    pytest.main([__file__])
