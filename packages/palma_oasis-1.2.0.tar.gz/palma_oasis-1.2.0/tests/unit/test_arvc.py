"""
Unit tests for ARVC (Aquifer Recharge Velocity Coefficient)
"""

import pytest
import numpy as np
from pathlib import Path
import sys
import os

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from palma.parameters.arvc import ARVC
from palma.parameters.base import AlertLevel


class TestARVC:
    """Test suite for ARVC parameter"""
    
    def setup_method(self):
        """Setup before each test"""
        self.arvc = ARVC(hydraulic_conductivity=12.4, head_gradient=0.003)
        
    def test_initialization(self):
        """Test ARVC initialization"""
        assert self.arvc.hydraulic_conductivity == 12.4
        assert self.arvc.head_gradient == 0.003
        assert self.arvc.alpha == 0.68
        
    def test_compute_with_data(self):
        """Test compute with sample data"""
        # Sample piezometer data
        data = {
            'heads': [25.1, 25.3, 25.0, 24.8, 24.7, 24.9, 25.2, 25.4, 25.1, 24.9],
            'quality': 0.85
        }
        
        result = self.arvc.compute(data)
        
        assert result.value > 0
        assert 0 <= result.normalized <= 1
        assert isinstance(result.alert_level, AlertLevel)
        assert 0 <= result.confidence <= 1
        
    def test_normalize(self):
        """Test normalization function"""
        # Excellent range
        assert self.arvc.normalize(1.20) == 0.0
        assert self.arvc.normalize(1.10) == 0.0
        
        # Good range
        assert 0 < self.arvc.normalize(0.95) < 0.5
        
        # Collapse range
        assert self.arvc.normalize(0.50) == 1.0
        assert self.arvc.normalize(0.30) == 1.0
        
    def test_alert_levels(self):
        """Test alert level determination"""
        # Test each threshold
        test_cases = [
            (0.20, AlertLevel.COLLAPSE),
            (0.65, AlertLevel.CRITICAL),
            (0.80, AlertLevel.MODERATE),
            (0.95, AlertLevel.GOOD),
            (1.15, AlertLevel.EXCELLENT)
        ]
        
        for value, expected_level in test_cases:
            normalized = self.arvc.normalize(value)
            level = self.arvc.get_alert_level(normalized)
            assert level == expected_level, f"Failed for value {value}"
    
    def test_invalid_input(self):
        """Test handling of invalid input"""
        with pytest.raises(Exception):
            self.arvc.compute(None)
    
    def test_retention_law(self):
        """Test non-linear retention law calculation"""
        # Test with distance
        data = {'heads': [25.0] * 10}
        result = self.arvc.compute(data, distance=50)
        
        assert result.value > 0
        assert 'alpha' in result.metadata
    
    def test_edge_cases(self):
        """Test edge cases"""
        # Very low values
        result = self.arvc.compute({'heads': [0.1]})
        assert result.normalized == 1.0
        
        # Very high values
        result = self.arvc.compute({'heads': [100.0]})
        assert result.normalized <= 1.0


if __name__ == "__main__":
    pytest.main([__file__])
