"""
Integration tests for full PALMA pipeline
Tests end-to-end functionality from data loading to alert generation
"""

import pytest
import numpy as np
import json
from pathlib import Path
import sys
import tempfile
import shutil
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from palma import PALMA
from palma.parameters.arvc import ARVC
from palma.parameters.ptsi import PTSI
from palma.parameters.sssp import SSSP
from palma.parameters.cmbf import CMBF
from palma.parameters.svri import SVRI
from palma.parameters.wepr import WEPR
from palma.parameters.bst import BST
from palma.ohi.composite import OHIComposite
from palma.alerts.threshold_monitor import ThresholdMonitor
from palma.io.piezometer import PiezometerReader
from palma.io.soil_ec import SoilECReader
from palma.utils.config import ConfigLoader


class TestFullPipeline:
    """Test complete PALMA pipeline"""
    
    @classmethod
    def setup_class(cls):
        """Setup test environment"""
        # Create temporary directories
        cls.test_dir = Path(tempfile.mkdtemp())
        cls.data_dir = cls.test_dir / "data"
        cls.data_dir.mkdir()
        cls.reports_dir = cls.test_dir / "reports"
        cls.reports_dir.mkdir()
        
        # Create sample configuration
        cls.config_path = cls.test_dir / "test_config.yaml"
        cls._create_sample_config()
        
        # Create sample data files
        cls._create_sample_data()
        
    @classmethod
    def teardown_class(cls):
        """Clean up test environment"""
        shutil.rmtree(cls.test_dir)
        
    @classmethod
    def _create_sample_config(cls):
        """Create sample configuration file"""
        config = {
            'system': {
                'version': '1.0.0',
                'log_level': 'DEBUG',
                'data_dir': str(cls.data_dir),
                'reports_dir': str(cls.reports_dir)
            },
            'parameters': {
                'arvc': {'alpha': 0.68, 'darcy_correction': True},
                'ptsi': {'k_extinction': 0.52},
                'sssp': {'ec_critical': 8.4},
                'cmbf': {'weights': {'temperature': 0.35, 'humidity': 0.28}},
                'svri': {'weights': {'ndvi': 0.40, 'ndre': 0.25}},
                'wepr': {'productive_fraction': 0.75},
                'bst': {'collapse_threshold': 0.60}
            },
            'ohi': {
                'weights': {
                    'ARVC': 0.22, 'PTSI': 0.18, 'SSSP': 0.17,
                    'CMBF': 0.16, 'SVRI': 0.14, 'WEPR': 0.08, 'BST': 0.05
                }
            },
            'alerts': {
                'channels': {'email': False, 'sms': False, 'webhook': False},
                'lead_time_warning_days': 14
            }
        }
        
        import yaml
        with open(cls.config_path, 'w') as f:
            yaml.dump(config, f)
    
    @classmethod
    def _create_sample_data(cls):
        """Create sample data files for testing"""
        # Piezometer data
        dates = [datetime.now() - timedelta(days=i) for i in range(100)]
        piezo_data = []
        for i, date in enumerate(dates):
            piezo_data.append({
                'datetime': date.isoformat(),
                'water_level_m': 25.0 + 0.5 * np.sin(i/10) + np.random.normal(0, 0.1)
            })
        
        with open(cls.data_dir / 'piezometer_sample.json', 'w') as f:
            json.dump(piezo_data, f)
        
        # Soil EC data
        ec_data = []
        depths = [15, 30, 60, 90]
        for i, date in enumerate(dates[:50]):
            ec_data.append({
                'datetime': date.isoformat(),
                'ec_measurements': [1.5 + 0.1*i, 2.0 + 0.1*i, 2.5 + 0.1*i, 3.0 + 0.1*i],
                'depths': depths
            })
        
        with open(cls.data_dir / 'soil_ec_sample.json', 'w') as f:
            json.dump(ec_data, f)
        
        # Create a sample site
        site_config = {
            'name': 'test_oasis',
            'country': 'Testland',
            'coordinates': {'lat': 30.0, 'lon': -5.0},
            'type': 'artesian',
            'parameters': {
                'arvc': {'alpha': 0.68},
                'sssp': {'ec_critical': 8.4}
            }
        }
        
        sites_dir = cls.test_dir / 'sites'
        sites_dir.mkdir(exist_ok=True)
        with open(sites_dir / 'test_oasis.yaml', 'w') as f:
            import yaml
            yaml.dump(site_config, f)
    
    def test_config_loading(self):
        """Test configuration loading"""
        config = ConfigLoader.load(self.config_path)
        assert config['system']['version'] == '1.0.0'
        assert 'parameters' in config
        assert 'ohi' in config
    
    def test_parameter_instantiation(self):
        """Test parameter instantiation"""
        arvc = ARVC()
        assert arvc.alpha == 0.68
        
        ptsi = PTSI()
        assert ptsi.k_extinction == 0.52
        
        sssp = SSSP()
        assert sssp.ec_critical == 8.4
    
    def test_data_loading(self):
        """Test data loading from files"""
        piezo_reader = PiezometerReader(data_dir=str(self.data_dir))
        # Would need actual file reading - simplified
        assert piezo_reader.data_dir == self.data_dir
    
    def test_parameter_computation(self):
        """Test parameter computation with sample data"""
        arvc = ARVC()
        
        # Create simple test data
        data = {'heads': [25.0 + i*0.1 for i in range(20)]}
        result = arvc.compute(data)
        
        assert result.value > 0
        assert 'v_observed' in result.metadata
    
    def test_ohi_computation(self):
        """Test OHI computation with mock parameters"""
        ohi = OHIComposite()
        
        param_values = {
            'ARVC': 0.3,
            'PTSI': 0.3,
            'SSSP': 0.3,
            'CMBF': 0.3,
            'SVRI': 0.3,
            'WEPR': 0.3,
            'BST': 0.3
        }
        
        result = ohi.compute(param_values)
        assert 0.25 < result.value < 0.45  # GOOD range
        assert result.status.name == "GOOD"
    
    def test_threshold_monitoring(self):
        """Test alert threshold monitoring"""
        monitor = ThresholdMonitor()
        
        # Test with critical value
        alert = monitor.check_ohi(
            site='test_oasis',
            ohi_value=0.75,
            parameters={'ARVC': 0.8, 'SSSP': 0.7}
        )
        
        assert alert is not None
        assert alert.level == "CRITICAL"
        assert len(alert.parameters_at_risk) > 0
        
        # Test with normal value
        alert = monitor.check_ohi(
            site='test_oasis',
            ohi_value=0.20,
            parameters={'ARVC': 0.2, 'SSSP': 0.2}
        )
        
        assert alert is None
    
    def test_full_workflow(self):
        """Test complete workflow from data to alert"""
        # 1. Load configuration
        config = ConfigLoader.load(self.config_path)
        
        # 2. Initialize parameters
        arvc = ARVC(alpha=config['parameters']['arvc']['alpha'])
        
        # 3. Load data (simulated)
        test_data = {'heads': [25.0] * 30}
        
        # 4. Compute parameter
        result = arvc.compute(test_data)
        
        # 5. Compute OHI (with other parameters mocked)
        ohi = OHIComposite(weights=config['ohi']['weights'])
        param_values = {
            'ARVC': result.normalized,
            'PTSI': 0.3,
            'SSSP': 0.3,
            'CMBF': 0.3,
            'SVRI': 0.3,
            'WEPR': 0.3,
            'BST': 0.3
        }
        
        ohi_result = ohi.compute(param_values)
        
        # 6. Check alerts
        monitor = ThresholdMonitor()
        alert = monitor.check_ohi(
            site='test_oasis',
            ohi_value=ohi_result.value,
            parameters=param_values
        )
        
        # Verify workflow completed
        assert result.value > 0
        assert ohi_result.value > 0
        # Alert may or may not trigger depending on values


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
