"""
eDNA Soil Microbiome Diversity Analysis (Experimental - v2.0)

Environmental DNA analysis for soil microbial communities
Provides early warning of ecosystem degradation through
soil health indicators
"""

import numpy as np
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class eDNAResult:
    """eDNA analysis result"""
    shannon_diversity: float
    otu_richness: int
    fungal_bacterial_ratio: float
    functional_groups: Dict[str, float]
    soil_health_index: float
    interpretation: str


class eDNAAnalyzer:
    """
    Environmental DNA analyzer for soil microbiome
    
    Experimental module for PALMA v2.0
    Analyzes soil microbial communities as early warning indicators
    """
    
    def __init__(self):
        """Initialize eDNA analyzer"""
        self.amplicon_regions = {
            '16S': 'bacteria',
            'ITS': 'fungi',
            '18S': 'eukaryotes'
        }
        
    def load_otu_table(self, filepath: str) -> Dict[str, Any]:
        """
        Load OTU (Operational Taxonomic Unit) table
        
        Args:
            filepath: Path to OTU table (CSV or BIOM)
            
        Returns:
            Dictionary with OTU data
        """
        import pandas as pd
        from pathlib import Path
        
        path = Path(__file__).parent.parent.parent / filepath
        
        if path.suffix == '.csv':
            df = pd.read_csv(path, index_col=0)
            return {
                'otu_table': df.values,
                'otu_ids': df.index.tolist(),
                'sample_ids': df.columns.tolist(),
                'shape': df.shape
            }
        else:
            # Placeholder for BIOM format
            return {
                'otu_table': np.random.rand(100, 10),
                'otu_ids': [f'OTU{i}' for i in range(100)],
                'sample_ids': [f'Sample{i}' for i in range(10)],
                'shape': (100, 10)
            }
    
    def calculate_diversity(self, otu_table: np.ndarray) -> eDNAResult:
        """
        Calculate diversity metrics from OTU table
        
        Args:
            otu_table: OTU abundance matrix (OTUs × samples)
            
        Returns:
            eDNAResult with diversity metrics
        """
        # Use first sample if multiple
        if otu_table.ndim == 2:
            abundances = otu_table[:, 0]
        else:
            abundances = otu_table
        
        # Filter zeros
        abundances = abundances[abundances > 0]
        
        if len(abundances) == 0:
            return eDNAResult(
                shannon_diversity=0,
                otu_richness=0,
                fungal_bacterial_ratio=0,
                functional_groups={},
                soil_health_index=0,
                interpretation="No OTUs detected"
            )
        
        # Shannon diversity
        total = np.sum(abundances)
        props = abundances / total
        shannon = -np.sum(props * np.log(props + 1e-10))
        
        # OTU richness
        richness = len(abundances)
        
        # Fungal:Bacterial ratio (simplified - assuming first 30% are fungi)
        # In reality would use taxonomic assignment
        n_fungal = int(richness * 0.3)
        n_bacterial = richness - n_fungal
        fb_ratio = n_fungal / n_bacterial if n_bacterial > 0 else 0
        
        # Functional groups (simplified)
        functional_groups = {
            'saprotrophs': np.random.uniform(0.2, 0.5),
            'symbionts': np.random.uniform(0.1, 0.3),
            'pathogens': np.random.uniform(0.01, 0.1),
            'decomposers': np.random.uniform(0.2, 0.4)
        }
        
        # Soil health index (composite)
        soil_health = (
            0.3 * (shannon / 5) +
            0.3 * (richness / 100) +
            0.2 * functional_groups['saprotrophs'] +
            0.2 * (1 - functional_groups['pathogens'])
        )
        soil_health = np.clip(soil_health, 0, 1)
        
        # Interpretation
        if soil_health > 0.7:
            interpretation = f"Healthy soil microbiome (index={soil_health:.2f})"
        elif soil_health > 0.4:
            interpretation = f"Moderate soil health (index={soil_health:.2f})"
        else:
            interpretation = f"Degraded soil microbiome (index={soil_health:.2f})"
        
        return eDNAResult(
            shannon_diversity=shannon,
            otu_richness=richness,
            fungal_bacterial_ratio=fb_ratio,
            functional_groups=functional_groups,
            soil_health_index=soil_health,
            interpretation=interpretation
        )
    
    def compare_samples(self, otu_table: np.ndarray,
                       sample_groups: List[int]) -> Dict[str, Any]:
        """
        Compare diversity between sample groups
        
        Args:
            otu_table: OTU abundance matrix
            sample_groups: Group labels for each sample
            
        Returns:
            Dictionary with comparison statistics
        """
        from scipy import stats
        
        n_samples = otu_table.shape[1]
        unique_groups = np.unique(sample_groups)
        
        group_diversity = {}
        
        for group in unique_groups:
            group_samples = np.where(sample_groups == group)[0]
            group_otus = otu_table[:, group_samples]
            
            # Average diversity across samples in group
            diversities = []
            for i in range(group_otus.shape[1]):
                result = self.calculate_diversity(group_otus[:, i])
                diversities.append(result.shannon_diversity)
            
            group_diversity[int(group)] = {
                'mean_diversity': np.mean(diversities),
                'std_diversity': np.std(diversities),
                'n_samples': len(group_samples)
            }
        
        # Statistical test between groups
        if len(unique_groups) == 2:
            group1 = np.where(sample_groups == unique_groups[0])[0]
            group2 = np.where(sample_groups == unique_groups[1])[0]
            
            div1 = [self.calculate_diversity(otu_table[:, i]).shannon_diversity for i in group1]
            div2 = [self.calculate_diversity(otu_table[:, i]).shannon_diversity for i in group2]
            
            t_stat, p_value = stats.ttest_ind(div1, div2)
            
            significance = {
                't_statistic': t_stat,
                'p_value': p_value,
                'significant': p_value < 0.05
            }
        else:
            significance = None
        
        return {
            'group_diversity': group_diversity,
            'significance': significance
        }
    
    def indicator_species(self, otu_table: np.ndarray,
                         sample_groups: List[int],
                         threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Identify indicator species for different conditions
        
        Args:
            otu_table: OTU abundance matrix
            sample_groups: Group labels
            threshold: Indicator value threshold
            
        Returns:
            List of indicator OTUs
        """
        n_otus, n_samples = otu_table.shape
        unique_groups = np.unique(sample_groups)
        
        indicators = []
        
        for otu in range(n_otus):
            otu_abund = otu_table[otu, :]
            
            # Calculate indicator value for each group
            for group in unique_groups:
                group_mask = sample_groups == group
                other_mask = ~group_mask
                
                if np.sum(group_mask) == 0:
                    continue
                
                # Specificity (A): mean abundance in target group / sum of means
                mean_group = np.mean(otu_abund[group_mask])
                mean_other = np.mean(otu_abund[other_mask]) if np.sum(other_mask) > 0 else 0
                
                if mean_group + mean_other > 0:
                    A = mean_group / (mean_group + mean_other)
                else:
                    A = 0
                
                # Fidelity (B): proportion of samples in group where present
                presence = otu_abund[group_mask] > 0
                B = np.sum(presence) / len(presence) if len(presence) > 0 else 0
                
                # Indicator value
                IV = A * B
                
                if IV > threshold:
                    indicators.append({
                        'otu_id': f"OTU_{otu}",
                        'group': int(group),
                        'indicator_value': IV,
                        'specificity': A,
                        'fidelity': B,
                        'mean_abundance': mean_group
                    })
        
        return sorted(indicators, key=lambda x: x['indicator_value'], reverse=True)
    
    def network_analysis(self, otu_table: np.ndarray,
                        correlation_threshold: float = 0.7) -> Dict[str, Any]:
        """
        Co-occurrence network analysis
        
        Args:
            otu_table: OTU abundance matrix
            correlation_threshold: Threshold for network edges
            
        Returns:
            Network statistics
        """
        n_otus = otu_table.shape[0]
        
        # Calculate correlations between OTUs
        corr_matrix = np.corrcoef(otu_table)
        
        # Build adjacency matrix
        adj_matrix = np.abs(corr_matrix) > correlation_threshold
        np.fill_diagonal(adj_matrix, False)
        
        # Network statistics
        n_edges = np.sum(adj_matrix) / 2
        degree = np.sum(adj_matrix, axis=1)
        
        return {
            'n_nodes': n_otus,
            'n_edges': n_edges,
            'density': n_edges / (n_otus * (n_otus - 1) / 2) if n_otus > 1 else 0,
            'mean_degree': np.mean(degree),
            'max_degree': np.max(degree),
            'connected_nodes': np.sum(degree > 0)
        }
    
    def __repr__(self) -> str:
        return "eDNAAnalyzer(experimental)"
