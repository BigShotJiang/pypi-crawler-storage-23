"""
Ecosystem Collapse Probability Model

P_collapse(t) = 1 - exp[-(BST/BST_crit)^β · t/T_ref]
where:
- BST_crit = 0.60
- β = 1.73
- T_ref = 5 years

Validated with 28-year dataset from 31 oasis sites
"""

import numpy as np
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class CollapseRisk:
    """Ecosystem collapse risk assessment"""
    probability: float  # Collapse probability (0-1)
    time_horizon: float  # Years considered
    bst_value: float  # Current BST
    risk_level: str  # Risk level description
    confidence: float  # Confidence in estimate (0-1)


class CollapseProbability:
    """
    Ecosystem collapse probability model
    
    Based on empirical validation from PALMA research
    Predicts likelihood of ecosystem collapse over time
    """
    
    def __init__(self, critical_threshold: float = 0.60,
                 exponent: float = 1.73,
                 time_reference: float = 5.0):
        """
        Initialize collapse probability model
        
        Args:
            critical_threshold: BST_crit (default 0.60)
            exponent: β exponent (default 1.73)
            time_reference: T_ref reference time (years)
        """
        self.critical_threshold = critical_threshold
        self.exponent = exponent
        self.time_reference = time_reference
        
    def calculate(self, bst_value: float, 
                 time_horizon: float = 5.0) -> CollapseRisk:
        """
        Calculate collapse probability over time horizon
        
        P = 1 - exp[-(BST/BST_crit)^β · t/T_ref]
        
        Args:
            bst_value: Current BST (0-1)
            time_horizon: Years to consider
            
        Returns:
            CollapseRisk with probability and risk level
        """
        if bst_value <= 0:
            probability = 0.0
        elif bst_value >= self.critical_threshold:
            # Use formula but ensure reasonable
            ratio = bst_value / self.critical_threshold
            exponent_term = (ratio ** self.exponent) * (time_horizon / self.time_reference)
            probability = 1 - np.exp(-exponent_term)
        else:
            # Below threshold, lower probability
            ratio = bst_value / self.critical_threshold
            exponent_term = (ratio ** self.exponent) * (time_horizon / self.time_reference)
            probability = 1 - np.exp(-exponent_term)
        
        probability = np.clip(probability, 0, 1)
        
        # Determine risk level
        if probability < 0.1:
            risk_level = "LOW"
        elif probability < 0.3:
            risk_level = "MODERATE"
        elif probability < 0.6:
            risk_level = "HIGH"
        else:
            risk_level = "VERY HIGH"
        
        # Confidence based on BST value
        if bst_value > 0.8:
            confidence = 0.9  # High confidence near collapse
        elif bst_value > 0.4:
            confidence = 0.7
        else:
            confidence = 0.5
        
        return CollapseRisk(
            probability=probability,
            time_horizon=time_horizon,
            bst_value=bst_value,
            risk_level=risk_level,
            confidence=confidence
        )
    
    def time_to_probability(self, bst_value: float,
                           target_probability: float = 0.5) -> float:
        """
        Calculate time to reach target collapse probability
        
        t = -T_ref * ln(1-p) / (BST/BST_crit)^β
        """
        if bst_value <= 0:
            return float('inf')
        
        ratio = bst_value / self.critical_threshold
        
        if ratio <= 0:
            return float('inf')
        
        time = -self.time_reference * np.log(1 - target_probability) / (ratio ** self.exponent)
        
        return max(0, time)
    
    def probability_curve(self, bst_value: float,
                         max_years: int = 50) -> Dict[str, Any]:
        """
        Generate probability curve over time
        
        Args:
            bst_value: Current BST
            max_years: Maximum years to consider
            
        Returns:
            Dictionary with time and probability arrays
        """
        years = np.arange(0, max_years + 1)
        probabilities = []
        
        for t in years:
            risk = self.calculate(bst_value, t)
            probabilities.append(risk.probability)
        
        # Find when probability exceeds thresholds
        p25 = None
        p50 = None
        p75 = None
        
        for t, p in zip(years, probabilities):
            if p25 is None and p >= 0.25:
                p25 = t
            if p50 is None and p >= 0.50:
                p50 = t
            if p75 is None and p >= 0.75:
                p75 = t
        
        return {
            'years': years.tolist(),
            'probabilities': probabilities,
            'p25_year': p25,
            'p50_year': p50,
            'p75_year': p75
        }
    
    def ensemble_forecast(self, bst_samples: List[float],
                         time_horizon: float = 5.0,
                         n_iterations: int = 1000) -> Dict[str, Any]:
        """
        Ensemble forecast with uncertainty
        
        Args:
            bst_samples: List of BST values (e.g., from bootstrap)
            time_horizon: Years to forecast
            n_iterations: Number of iterations
            
        Returns:
            Dictionary with ensemble statistics
        """
        probabilities = []
        
        for _ in range(n_iterations):
            # Sample BST with replacement
            bst = np.random.choice(bst_samples)
            
            # Add uncertainty
            bst_with_error = bst + np.random.normal(0, 0.05)
            bst_with_error = np.clip(bst_with_error, 0, 1)
            
            risk = self.calculate(bst_with_error, time_horizon)
            probabilities.append(risk.probability)
        
        probabilities = np.array(probabilities)
        
        return {
            'mean_probability': np.mean(probabilities),
            'median_probability': np.median(probabilities),
            'std_probability': np.std(probabilities),
            'q25': np.percentile(probabilities, 25),
            'q75': np.percentile(probabilities, 75),
            'q05': np.percentile(probabilities, 5),
            'q95': np.percentile(probabilities, 95),
            'p_critical': np.mean(probabilities > 0.5)  # Probability of >50% collapse risk
        }
    
    def risk_assessment(self, bst_value: float) -> Dict[str, Any]:
        """
        Comprehensive risk assessment
        
        Args:
            bst_value: Current BST
            
        Returns:
            Dictionary with risk metrics
        """
        # Current risk (5-year)
        risk_5yr = self.calculate(bst_value, 5)
        
        # Current risk (10-year)
        risk_10yr = self.calculate(bst_value, 10)
        
        # Time to 50% probability
        time_to_50 = self.time_to_probability(bst_value, 0.5)
        
        # Criticality level
        if bst_value >= self.critical_threshold:
            criticality = "CRITICAL - Above threshold"
        elif bst_value >= self.critical_threshold * 0.8:
            criticality = "WARNING - Approaching threshold"
        else:
            criticality = "STABLE - Below threshold"
        
        return {
            'bst_value': bst_value,
            'risk_5yr': risk_5yr.probability,
            'risk_5yr_level': risk_5yr.risk_level,
            'risk_10yr': risk_10yr.probability,
            'time_to_50pct': time_to_50,
            'criticality': criticality,
            'management_priority': self._management_priority(risk_5yr.probability)
        }
    
    def _management_priority(self, probability: float) -> str:
        """Determine management priority based on probability"""
        if probability < 0.1:
            return "LOW - Continue monitoring"
        elif probability < 0.3:
            return "MEDIUM - Develop contingency plans"
        elif probability < 0.6:
            return "HIGH - Implement conservation measures"
        else:
            return "IMMEDIATE - Emergency intervention required"
    
    def __repr__(self) -> str:
        return f"CollapseProbability(critical={self.critical_threshold}, β={self.exponent})"
