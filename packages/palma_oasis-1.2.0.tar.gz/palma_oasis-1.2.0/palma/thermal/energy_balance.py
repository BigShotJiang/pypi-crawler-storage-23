"""
Surface Energy Balance for Oasis Systems

R_n = H + LE + G
where:
- R_n: Net radiation (W/m²)
- H: Sensible heat flux (W/m²)
- LE: Latent heat flux (W/m²)
- G: Ground heat flux (W/m²)

Oasis Bowen ratio: β = H/LE = 0.18-0.42
Desert Bowen ratio: β = 4-15
"""

import numpy as np
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class EnergyFluxes:
    """Surface energy balance components"""
    net_radiation: float  # R_n (W/m²)
    sensible_heat: float  # H (W/m²)
    latent_heat: float    # LE (W/m²)
    ground_heat: float    # G (W/m²)
    bowen_ratio: float    # β = H/LE
    evaporative_fraction: float  # EF = LE/(R_n - G)
    closure_error: float  # R_n - (H + LE + G)


class EnergyBalance:
    """
    Surface energy balance solver for oasis ecosystems
    
    Implements full energy balance with Penman-Monteith
    equation for evapotranspiration
    """
    
    def __init__(self, 
                 albedo: float = 0.20,
                 emissivity: float = 0.98,
                 roughness_length: float = 0.1,
                 zero_plane_displacement: float = 0.67):
        """
        Initialize energy balance model
        
        Args:
            albedo: Surface albedo (0-1)
            emissivity: Surface emissivity for longwave
            roughness_length: Aerodynamic roughness length (m)
            zero_plane_displacement: Zero plane displacement height (m)
        """
        self.albedo = albedo
        self.emissivity = emissivity
        self.z0 = roughness_length
        self.d = zero_plane_displacement
        
        # Constants
        self.sigma = 5.67e-8  # Stefan-Boltzmann constant (W/m²/K⁴)
        self.cp = 1005  # Specific heat of air (J/kg/K)
        self.rho = 1.2  # Air density (kg/m³)
        self.lv = 2.45e6  # Latent heat of vaporization (J/kg)
        self.karman = 0.41  # von Karman constant
        
    def net_radiation(self, sw_down: float, sw_up: float,
                     lw_down: float, lw_up: float) -> float:
        """
        Calculate net radiation
        
        R_n = SW↓ - SW↑ + LW↓ - LW↑
        """
        return (sw_down - sw_up) + (lw_down - lw_up)
    
    def net_shortwave(self, sw_down: float) -> float:
        """Net shortwave radiation (SW↓ - SW↑ = SW↓·(1 - albedo))"""
        return sw_down * (1 - self.albedo)
    
    def net_longwave(self, t_surface: float, lw_down: float) -> float:
        """
        Net longwave radiation
        
        LW↑ = ε·σ·T⁴
        LW↓ from atmosphere or clouds
        """
        lw_up = self.emissivity * self.sigma * (t_surface + 273.15) ** 4
        return lw_down - lw_up
    
    def aerodynamic_resistance(self, wind_speed: float,
                              height: float = 2.0,
                              measurement_height: float = 10.0) -> float:
        """
        Calculate aerodynamic resistance (ra)
        
        ra = [ln((z - d)/z0) · ln((z - d)/z0v)] / (k²·u)
        Simplified: ra = (ln(z/z0))² / (k²·u)
        """
        if wind_speed <= 0:
            return float('inf')
        
        # Effective height
        z_eff = max(height - self.d, self.z0)
        
        # Logarithmic profile
        ra = (np.log(z_eff / self.z0) ** 2) / (self.karman ** 2 * wind_speed)
        
        return max(ra, 1.0)  # Minimum resistance 1 s/m
    
    def surface_resistance(self, lai: float, 
                          stomatal_resistance: float = 100,
                          solar_radiation: Optional[float] = None) -> float:
        """
        Calculate surface (canopy) resistance (rs)
        
        rs = rs_min / (LAI · f(R_s) · f(VPD) · f(T))
        Simplified: rs = rs_min / LAI_effective
        """
        if lai <= 0:
            return float('inf')
        
        # Light response (optional)
        if solar_radiation is not None:
            light_factor = solar_radiation / (solar_radiation + 200)  # Michaelis-Menten
        else:
            light_factor = 1.0
        
        # Effective LAI for resistance
        lai_effective = lai * light_factor
        
        rs = stomatal_resistance / max(lai_effective, 0.1)
        
        return rs
    
    def penman_monteith_et(self, rn: float, g: float,
                          t_air: float, vpd: float,
                          ra: float, rs: float) -> float:
        """
        Penman-Monteith equation for evapotranspiration
        
        λET = [Δ(R_n - G) + ρ·c_p·VPD/ra] / [Δ + γ(1 + rs/ra)]
        
        Returns:
            Latent heat flux (W/m²)
        """
        # Psychrometric constant (kPa/°C)
        gamma = 0.065
        
        # Slope of saturation vapor pressure curve (kPa/°C)
        delta = 4098 * (0.6108 * np.exp(17.27 * t_air / (t_air + 237.3))) / (t_air + 237.3) ** 2
        
        # Convert VPD from kPa to Pa for energy units
        vpd_pa = vpd * 1000
        
        # Penman-Monteith
        numerator = delta * (rn - g) + self.rho * self.cp * vpd_pa / ra
        denominator = delta + gamma * (1 + rs / ra)
        
        le = numerator / denominator
        
        return max(le, 0)  # No negative ET
    
    def bowen_ratio_et(self, rn: float, g: float, beta: float) -> float:
        """
        Estimate ET from Bowen ratio
        
        LE = (R_n - G) / (1 + β)
        """
        if beta < 0:
            return 0
        
        return (rn - g) / (1 + beta)
    
    def residual_method(self, rn: float, g: float, h: float) -> float:
        """
        Estimate LE as residual of energy balance
        
        LE = R_n - G - H
        """
        return rn - g - h
    
    def solve_energy_balance(self,
                            sw_down: float,
                            lw_down: float,
                            t_air: float,
                            t_surface: float,
                            wind_speed: float,
                            vpd: float,
                            lai: float,
                            g: Optional[float] = None,
                            **kwargs) -> EnergyFluxes:
        """
        Solve complete surface energy balance
        
        Args:
            sw_down: Downwelling shortwave (W/m²)
            lw_down: Downwelling longwave (W/m²)
            t_air: Air temperature (°C)
            t_surface: Surface temperature (°C)
            wind_speed: Wind speed (m/s)
            vpd: Vapor pressure deficit (kPa)
            lai: Leaf Area Index
            g: Ground heat flux (if None, estimate)
            
        Returns:
            EnergyFluxes object with all components
        """
        # Net shortwave
        sw_net = self.net_shortwave(sw_down)
        
        # Net longwave
        lw_net = self.net_longwave(t_surface, lw_down)
        
        # Net radiation
        rn = sw_net + lw_net
        
        # Estimate ground heat flux if not provided
        if g is None:
            g = 0.1 * rn  # Simple approximation
        
        # Aerodynamic resistance
        ra = self.aerodynamic_resistance(wind_speed)
        
        # Surface resistance
        rs = self.surface_resistance(lai)
        
        # Penman-Monteith ET
        le = self.penman_monteith_et(rn, g, t_air, vpd, ra, rs)
        
        # Sensible heat as residual
        h = rn - le - g
        
        # Bowen ratio
        if le > 0:
            beta = h / le
        else:
            beta = float('inf')
        
        # Evaporative fraction
        if (rn - g) > 0:
            ef = le / (rn - g)
        else:
            ef = 0
        
        # Energy balance closure
        closure = rn - (h + le + g)
        
        return EnergyFluxes(
            net_radiation=rn,
            sensible_heat=h,
            latent_heat=le,
            ground_heat=g,
            bowen_ratio=beta,
            evaporative_fraction=ef,
            closure_error=closure
        )
    
    def oasis_vs_desert_comparison(self,
                                   oasis_params: Dict[str, float],
                                   desert_params: Dict[str, float]) -> Dict[str, Any]:
        """
        Compare energy balance between oasis and adjacent desert
        
        Args:
            oasis_params: Parameters for oasis site
            desert_params: Parameters for desert site
            
        Returns:
            Dictionary with comparison metrics
        """
        # Solve for oasis
        oasis = self.solve_energy_balance(**oasis_params)
        
        # Solve for desert (with different albedo, LAI=0)
        desert = self.solve_energy_balance(**desert_params)
        
        # Calculate differences
        delta_t = desert_params.get('t_surface', 45) - oasis_params.get('t_surface', 33)
        
        return {
            'oasis': oasis,
            'desert': desert,
            'differences': {
                'net_radiation': oasis.net_radiation - desert.net_radiation,
                'sensible_heat': oasis.sensible_heat - desert.sensible_heat,
                'latent_heat': oasis.latent_heat - desert.latent_heat,
                'ground_heat': oasis.ground_heat - desert.ground_heat,
                'bowen_ratio': oasis.bowen_ratio - desert.bowen_ratio,
                'surface_temperature': delta_t
            },
            'cooling_effect': delta_t,
            'energy_partitioning_shift': {
                'oasis_h_fraction': oasis.sensible_heat / oasis.net_radiation,
                'desert_h_fraction': desert.sensible_heat / desert.net_radiation,
                'oasis_le_fraction': oasis.latent_heat / oasis.net_radiation,
                'desert_le_fraction': desert.latent_heat / desert.net_radiation
            }
        }
    
    def daily_cycle(self, hours: int = 24,
                   latitude: float = 30,
                   day_of_year: int = 180,
                   **base_params) -> Dict[str, Any]:
        """
        Simulate diurnal cycle of energy balance
        
        Args:
            hours: Number of hours to simulate
            latitude: Latitude (degrees)
            day_of_year: Day of year (1-365)
            base_params: Base parameters for solver
            
        Returns:
            Dictionary with hourly fluxes
        """
        # Solar geometry
        from datetime import datetime, timedelta
        
        # Simplified solar radiation model
        declination = 23.45 * np.sin(np.radians(360 * (284 + day_of_year) / 365))
        
        time = np.arange(hours)
        solar_time = time - 12  # Solar noon at hour 12
        
        # Solar elevation
        sin_elev = (np.sin(np.radians(latitude)) * np.sin(np.radians(declination)) +
                   np.cos(np.radians(latitude)) * np.cos(np.radians(declination)) *
                   np.cos(np.radians(15 * solar_time)))
        
        elevation = np.degrees(np.arcsin(np.clip(sin_elev, 0, 1)))
        
        # Clear sky radiation (simplified)
        sw_down = 1000 * sin_elev * np.exp(-0.1 / np.maximum(sin_elev, 0.01))
        sw_down = np.maximum(sw_down, 0)
        
        # Results arrays
        rn = np.zeros(hours)
        h = np.zeros(hours)
        le = np.zeros(hours)
        g = np.zeros(hours)
        t_surface = np.zeros(hours)
        
        # Base temperature cycle
        t_air_base = base_params.get('t_air', 30)
        t_amplitude = 10
        
        for i, hour in enumerate(time):
            # Hourly temperature
            t_air = t_air_base - t_amplitude * np.cos(np.radians(15 * (hour - 14)))
            
            # Update parameters
            params = base_params.copy()
            params['sw_down'] = sw_down[i]
            params['t_air'] = t_air
            
            # Estimate surface temperature (simplified)
            params['t_surface'] = t_air + 5 * (sw_down[i] / 1000)
            
            # Solve
            result = self.solve_energy_balance(**params)
            
            rn[i] = result.net_radiation
            h[i] = result.sensible_heat
            le[i] = result.latent_heat
            g[i] = result.ground_heat
            t_surface[i] = params['t_surface']
        
        return {
            'time': time,
            'sw_down': sw_down,
            't_air': t_air_base - t_amplitude * np.cos(np.radians(15 * (time - 14))),
            't_surface': t_surface,
            'net_radiation': rn,
            'sensible_heat': h,
            'latent_heat': le,
            'ground_heat': g,
            'daily_total_et': np.trapz(le / self.lv, time * 3600)  # mm/day
        }
    
    def __repr__(self) -> str:
        return f"EnergyBalance(albedo={self.albedo:.2f}, emissivity={self.emissivity:.2f})"
