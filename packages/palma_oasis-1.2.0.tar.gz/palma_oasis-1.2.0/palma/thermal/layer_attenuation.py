"""
Multi-layer canopy thermal attenuation model

T_n = T_ambient·exp(-κ·n) where κ = 0.41 per layer
Validated with 4-layer thermocouple profiles across 31 sites
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass


@dataclass
class LayerProfile:
    """Temperature profile through canopy layers"""
    layer_names: List[str]
    layer_heights: List[float]
    temperatures: List[float]
    cumulative_attenuation: List[float]
    ground_temperature: float


class LayerAttenuation:
    """
    Multi-layer canopy thermal attenuation model
    
    Based on empirical validation from PALMA research:
    κ = 0.41 per layer for oasis canopies
    Mean ΔT = 11.4°C (range 8.3-14.7°C)
    """
    
    def __init__(self, kappa: float = 0.41, n_layers: int = 4):
        """
        Initialize layer attenuation model
        
        Args:
            kappa: Attenuation coefficient per layer (default 0.41 from paper)
            n_layers: Number of canopy layers (palm, fruit tree, shrub, ground)
        """
        self.kappa = kappa
        self.n_layers = n_layers
        
        # Layer names and typical heights (from paper)
        self.layer_names = ['palm_fronds', 'fruit_tree', 'shrub', 'ground_cover']
        self.layer_heights = [6.0, 3.0, 1.2, 0.3]  # meters
        
    def temperature_at_layer(self, t_ambient: float, layer: int) -> float:
        """
        Calculate temperature at specific layer
        
        Args:
            t_ambient: Ambient desert temperature (°C)
            layer: Layer number (0 = top, n_layers-1 = bottom)
            
        Returns:
            Temperature at layer (°C)
        """
        # Layer number starts at 1 for top layer
        return t_ambient * np.exp(-self.kappa * (layer + 1))
    
    def full_profile(self, t_ambient: float) -> LayerProfile:
        """
        Calculate complete temperature profile through all layers
        
        Args:
            t_ambient: Ambient desert temperature (°C)
            
        Returns:
            LayerProfile with all layers
        """
        temperatures = []
        cumulative = []
        
        for i in range(self.n_layers):
            t = self.temperature_at_layer(t_ambient, i)
            temperatures.append(t)
            cumulative.append(np.exp(-self.kappa * (i + 1)))
        
        # Ground temperature (below all layers)
        t_ground = self.temperature_at_layer(t_ambient, self.n_layers)
        
        return LayerProfile(
            layer_names=self.layer_names[:self.n_layers],
            layer_heights=self.layer_heights[:self.n_layers],
            temperatures=temperatures,
            cumulative_attenuation=cumulative,
            ground_temperature=t_ground
        )
    
    def temperature_at_height(self, t_ambient: float, 
                             height: float) -> float:
        """
        Estimate temperature at specific height within canopy
        
        Uses interpolation between layers
        """
        if height >= self.layer_heights[0]:
            return t_ambient
        if height <= self.layer_heights[-1]:
            return self.temperature_at_layer(t_ambient, self.n_layers - 1)
        
        # Find surrounding layers
        for i in range(self.n_layers - 1):
            if self.layer_heights[i] >= height >= self.layer_heights[i+1]:
                t_top = self.temperature_at_layer(t_ambient, i)
                t_bottom = self.temperature_at_layer(t_ambient, i+1)
                
                # Linear interpolation in log space
                log_t_top = np.log(t_top)
                log_t_bottom = np.log(t_bottom)
                
                frac = (self.layer_heights[i] - height) / (self.layer_heights[i] - self.layer_heights[i+1])
                log_t = log_t_top + frac * (log_t_bottom - log_t_top)
                
                return np.exp(log_t)
        
        return t_ambient
    
    def cumulative_attenuation(self, n_layers: Optional[int] = None) -> float:
        """
        Calculate cumulative attenuation through n layers
        
        Attenuation factor = exp(-κ·n)
        """
        if n_layers is None:
            n_layers = self.n_layers
        
        return np.exp(-self.kappa * n_layers)
    
    def radiation_reaching_ground(self, t_ambient: float) -> float:
        """
        Calculate equivalent temperature at ground level
        """
        return self.temperature_at_layer(t_ambient, self.n_layers)
    
    def ground_fraction(self, t_ambient: float) -> float:
        """
        Fraction of ambient temperature reaching ground
        """
        return self.radiation_reaching_ground(t_ambient) / t_ambient
    
    def cooling_efficiency(self, t_ambient: float) -> float:
        """
        Calculate cooling efficiency relative to ambient
        
        Efficiency = (T_ambient - T_ground) / T_ambient * 100 (%)
        """
        t_ground = self.radiation_reaching_ground(t_ambient)
        
        if t_ambient <= 0:
            return 0
        
        return (t_ambient - t_ground) / t_ambient * 100
    
    def optimal_layer_count(self, target_temperature: float,
                           t_ambient: float) -> int:
        """
        Calculate number of layers needed to reach target temperature
        
        Solve: target = T_ambient·exp(-κ·n)
        => n = -ln(target/T_ambient) / κ
        """
        if target_temperature >= t_ambient:
            return 0
        
        ratio = target_temperature / t_ambient
        if ratio <= 0:
            return 100  # Practical maximum
        
        n = -np.log(ratio) / self.kappa
        return int(np.ceil(n))
    
    def compare_with_monoculture(self, t_ambient: float) -> Dict[str, float]:
        """
        Compare multi-layer system with single-layer monoculture
        
        From paper: "Single-layer plantations achieve only first layer of
        attenuation: exp(-0.41×1) = 66.4% radiation transmission"
        
        Returns:
            Dictionary with comparison metrics
        """
        # Traditional multi-layer (4 layers)
        t_multi = self.radiation_reaching_ground(t_ambient)
        atten_multi = self.cumulative_attenuation(4)
        
        # Monoculture (single layer)
        t_mono = self.temperature_at_layer(t_ambient, 0)
        atten_mono = self.cumulative_attenuation(1)
        
        # Difference
        t_diff = t_mono - t_multi
        atten_ratio = atten_mono / atten_multi
        
        return {
            'multi_layer_temperature': t_multi,
            'monoculture_temperature': t_mono,
            'temperature_difference': t_diff,
            'multi_layer_attenuation': atten_multi,
            'monoculture_attenuation': atten_mono,
            'attenuation_ratio': atten_ratio,
            'multi_layer_efficiency': self.cooling_efficiency(t_ambient),
            'monoculture_efficiency': (t_ambient - t_mono) / t_ambient * 100,
            'improvement_factor': (t_ambient - t_multi) / (t_ambient - t_mono) if t_ambient > t_mono else 1
        }
    
    def layer_contribution(self, layer: int, t_ambient: float) -> float:
        """
        Calculate temperature reduction contributed by a specific layer
        
        Returns:
            Temperature reduction from this layer (°C)
        """
        if layer == 0:
            t_before = t_ambient
        else:
            t_before = self.temperature_at_layer(t_ambient, layer - 1)
        
        t_after = self.temperature_at_layer(t_ambient, layer)
        
        return t_before - t_after
    
    def optimal_layer_heights(self, target_profile: List[float],
                             t_ambient: float) -> List[float]:
        """
        Estimate optimal layer heights to achieve target temperature profile
        
        Args:
            target_profile: Target temperatures at each layer
            t_ambient: Ambient temperature
            
        Returns:
            Adjusted layer heights
        """
        if len(target_profile) != self.n_layers:
            raise ValueError(f"Target profile must have {self.n_layers} layers")
        
        adjusted_heights = []
        
        for i, t_target in enumerate(target_profile):
            # Required attenuation for this layer
            required_atten = t_target / t_ambient
            
            # Layer number needed
            n_needed = -np.log(required_atten) / self.kappa
            
            # Height proportional to layer number (simplified)
            height = (n_needed / self.n_layers) * self.layer_heights[0]
            adjusted_heights.append(height)
        
        return adjusted_heights
    
    def validate_with_measurements(self, measured_temps: List[float],
                                  t_ambient: float) -> Dict[str, float]:
        """
        Validate model against measured temperature profile
        
        Args:
            measured_temps: Measured temperatures at each layer
            t_ambient: Ambient temperature
            
        Returns:
            Validation metrics
        """
        if len(measured_temps) != self.n_layers:
            raise ValueError(f"Expected {self.n_layers} measurements")
        
        predicted_temps = []
        for i in range(self.n_layers):
            predicted_temps.append(self.temperature_at_layer(t_ambient, i))
        
        # Calculate errors
        errors = [abs(p - m) for p, m in zip(predicted_temps, measured_temps)]
        rmse = np.sqrt(np.mean(np.array(errors) ** 2))
        mae = np.mean(errors)
        r2 = self._calculate_r2(measured_temps, predicted_temps)
        
        return {
            'rmse': rmse,
            'mae': mae,
            'r2': r2,
            'max_error': max(errors),
            'mean_bias': np.mean(np.array(predicted_temps) - np.array(measured_temps))
        }
    
    def _calculate_r2(self, measured: List[float], predicted: List[float]) -> float:
        """Calculate R² between measured and predicted"""
        measured = np.array(measured)
        predicted = np.array(predicted)
        
        ss_res = np.sum((measured - predicted) ** 2)
        ss_tot = np.sum((measured - np.mean(measured)) ** 2)
        
        if ss_tot == 0:
            return 1.0
        
        return 1 - (ss_res / ss_tot)
    
    def __repr__(self) -> str:
        return f"LayerAttenuation(κ={self.kappa:.3f}, layers={self.n_layers})"
