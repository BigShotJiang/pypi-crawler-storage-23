"""
Beer-Lambert law for radiation attenuation through vegetation canopy

I_z = I₀·exp(-k·LAI·cos θ_z)
where:
- k: extinction coefficient (0.42-0.61 for date palm)
- LAI: Leaf Area Index
- θ_z: solar zenith angle
"""

import numpy as np
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class RadiationProfile:
    """Radiation profile through canopy layers"""
    height: float
    incoming_sw: float  # Shortwave radiation (W/m²)
    incoming_lw: float  # Longwave radiation (W/m²)
    net_radiation: float  # Net radiation (W/m²)
    par: float  # Photosynthetically Active Radiation (μmol/m²/s)
    temperature: float  # Air temperature (°C)


class BeerLambertAttenuation:
    """
    Beer-Lambert radiation attenuation model for oasis canopies
    
    Validated for date palm canopies with k = 0.42-0.61
    Mean k = 0.52 from 89 UAV missions across 31 sites
    """
    
    def __init__(self, k_extinction: float = 0.52,
                 leaf_reflectance: float = 0.25,
                 leaf_transmittance: float = 0.15):
        """
        Initialize Beer-Lambert model
        
        Args:
            k_extinction: Extinction coefficient (default 0.52 from paper)
            leaf_reflectance: Leaf reflectance for PAR (0-1)
            leaf_transmittance: Leaf transmittance for PAR (0-1)
        """
        self.k = k_extinction
        self.leaf_reflectance = leaf_reflectance
        self.leaf_transmittance = leaf_transmittance
        self.leaf_absorbance = 1 - leaf_reflectance - leaf_transmittance
        
    def radiation_at_height(self, i0: float, lai_cumulative: float,
                           solar_zenith: float = 0) -> float:
        """
        Calculate radiation at height with cumulative LAI above
        
        Args:
            i0: Incident radiation above canopy (W/m²)
            lai_cumulative: Cumulative LAI above current height
            solar_zenith: Solar zenith angle (degrees)
            
        Returns:
            Radiation at height (W/m²)
        """
        cos_theta = np.cos(np.radians(solar_zenith))
        if cos_theta <= 0:
            return 0
            
        return i0 * np.exp(-self.k * lai_cumulative / cos_theta)
    
    def canopy_profile(self, i0: float, lai_total: float,
                      n_layers: int = 10,
                      solar_zenith: float = 0,
                      layer_heights: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Calculate radiation profile through canopy layers
        
        Args:
            i0: Incident radiation above canopy (W/m²)
            lai_total: Total canopy LAI
            n_layers: Number of layers for profile
            solar_zenith: Solar zenith angle (degrees)
            layer_heights: Optional height of each layer (m)
            
        Returns:
            Dictionary with radiation at each layer
        """
        if layer_heights is None:
            layer_heights = np.linspace(0, 10, n_layers)
        
        # Cumulative LAI from top
        lai_per_layer = lai_total / n_layers
        cumulative_lai = np.cumsum(np.ones(n_layers) * lai_per_layer)
        
        # Radiation at each layer
        radiation = np.zeros(n_layers)
        for i in range(n_layers):
            radiation[i] = self.radiation_at_height(i0, cumulative_lai[i], solar_zenith)
        
        # Radiation reaching ground
        ground_radiation = self.radiation_at_height(i0, lai_total, solar_zenith)
        
        return {
            'layer_heights': layer_heights,
            'cumulative_lai': cumulative_lai,
            'radiation': radiation,
            'ground_radiation': ground_radiation,
            'fraction_reaching_ground': ground_radiation / i0 if i0 > 0 else 0,
            'total_attenuation': 1 - ground_radiation / i0 if i0 > 0 else 1
        }
    
    def par_at_height(self, par0: float, lai_cumulative: float,
                     solar_zenith: float = 0) -> float:
        """
        Calculate Photosynthetically Active Radiation (PAR) at height
        
        PAR is typically 45-50% of shortwave radiation
        """
        return self.radiation_at_height(par0, lai_cumulative, solar_zenith)
    
    def absorbed_par(self, par_incident: float, lai: float,
                    solar_zenith: float = 0) -> float:
        """
        Calculate PAR absorbed by canopy
        
        APAR = PAR_incident * (1 - exp(-k * LAI / cos θ)) * leaf_absorbance
        """
        fraction_intercepted = 1 - np.exp(-self.k * lai / np.cos(np.radians(solar_zenith)))
        return par_incident * fraction_intercepted * self.leaf_absorbance
    
    def light_extinction_profile(self, lai: float, n_points: int = 100) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate light extinction profile through canopy
        
        Returns:
            (depth_fraction, relative_light) arrays
        """
        depth = np.linspace(0, 1, n_points)
        cumulative_lai = depth * lai
        
        relative_light = np.exp(-self.k * cumulative_lai)
        
        return depth, relative_light
    
    def sunlit_fraction(self, lai: float, solar_zenith: float = 0) -> float:
        """
        Calculate fraction of sunlit leaves in canopy
        
        f_sunlit = exp(-k * LAI / cos θ) / (k * LAI / cos θ)
        """
        cos_theta = np.cos(np.radians(solar_zenith))
        if cos_theta <= 0 or lai <= 0:
            return 0
            
        k_lai = self.k * lai / cos_theta
        return (1 - np.exp(-k_lai)) / k_lai
    
    def canopy_albedo(self, lai: float, soil_albedo: float = 0.3,
                     solar_zenith: float = 0) -> float:
        """
        Calculate canopy albedo using two-stream approximation
        
        α_canopy = α_leaf + (α_soil - α_leaf) * exp(-2k·LAI/cos θ)
        """
        cos_theta = np.cos(np.radians(solar_zenith))
        leaf_albedo = self.leaf_reflectance
        
        alpha = leaf_albedo + (soil_albedo - leaf_albedo) * np.exp(-2 * self.k * lai / cos_theta)
        
        return np.clip(alpha, 0, 1)
    
    def estimate_lai_from_fpar(self, fpar: float, solar_zenith: float = 0) -> float:
        """
        Estimate LAI from Fraction of PAR absorbed (FPAR)
        
        FPAR = 1 - exp(-k·LAI/cos θ)
        => LAI = -ln(1 - FPAR) * cos θ / k
        """
        cos_theta = np.cos(np.radians(solar_zenith))
        
        if fpar >= 0.99:
            return 10.0  # Maximum reasonable LAI
        
        lai = -np.log(1 - fpar) * cos_theta / self.k
        return max(0, lai)
    
    def multiple_scattering(self, lai: float, n_scattering: int = 3) -> float:
        """
        Calculate contribution from multiple scattering
        
        Simplified model: each scattering adds reflectance * transmittance^n
        """
        total = 0
        for n in range(1, n_scattering + 1):
            contribution = (self.leaf_reflectance * self.leaf_transmittance) ** n
            total += contribution * np.exp(-self.k * lai / n)
        
        return total
    
    def __repr__(self) -> str:
        return f"BeerLambertAttenuation(k={self.k:.3f}, absorbance={self.leaf_absorbance:.3f})"


class LayerAttenuation:
    """
    Multi-layer canopy thermal attenuation model
    
    T_n = T_ambient·exp(-κ·n) where κ = 0.41 per layer
    Validated with 4-layer thermocouple profiles across 31 sites
    """
    
    def __init__(self, kappa: float = 0.41, n_layers: int = 4):
        """
        Initialize layer attenuation model
        
        Args:
            kappa: Attenuation coefficient per layer (default 0.41 from paper)
            n_layers: Number of canopy layers (palm, fruit tree, shrub, ground)
        """
        self.kappa = kappa
        self.n_layers = n_layers
        
        # Layer names (from paper)
        self.layer_names = ['palm', 'fruit_tree', 'shrub', 'ground_cover']
        
    def temperature_at_layer(self, t_ambient: float, layer: int) -> float:
        """
        Calculate temperature at specific layer
        
        Args:
            t_ambient: Ambient desert temperature (°C)
            layer: Layer number (0 = top, n_layers-1 = bottom)
            
        Returns:
            Temperature at layer (°C)
        """
        return t_ambient * np.exp(-self.kappa * (layer + 1))
    
    def layer_profile(self, t_ambient: float) -> Dict[str, float]:
        """
        Calculate temperature profile through all layers
        
        Returns:
            Dictionary with layer_name: temperature
        """
        profile = {}
        for i, name in enumerate(self.layer_names[:self.n_layers]):
            profile[name] = self.temperature_at_layer(t_ambient, i)
        
        # Ground temperature (below all layers)
        profile['ground'] = self.temperature_at_layer(t_ambient, self.n_layers)
        
        return profile
    
    def cumulative_attenuation(self, n_layers: Optional[int] = None) -> float:
        """
        Calculate cumulative attenuation through n layers
        
        Attenuation factor = exp(-κ·n)
        """
        if n_layers is None:
            n_layers = self.n_layers
        
        return np.exp(-self.kappa * n_layers)
    
    def radiation_reaching_ground(self, t_ambient: float) -> float:
        """
        Calculate equivalent temperature at ground level
        """
        return self.temperature_at_layer(t_ambient, self.n_layers)
    
    def cooling_efficiency(self, t_ambient: float, t_ground: float) -> float:
        """
        Calculate cooling efficiency relative to ambient
        
        Efficiency = (T_ambient - T_ground) / T_ambient * 100 (%)
        """
        if t_ambient <= 0:
            return 0
        return (t_ambient - t_ground) / t_ambient * 100
    
    def optimal_layer_count(self, target_temperature: float,
                           t_ambient: float) -> int:
        """
        Calculate number of layers needed to reach target temperature
        
        Solve: target = T_ambient·exp(-κ·n)
        => n = -ln(target/T_ambient) / κ
        """
        if target_temperature >= t_ambient:
            return 0
        
        ratio = target_temperature / t_ambient
        if ratio <= 0:
            return 100  # Practical maximum
        
        n = -np.log(ratio) / self.kappa
        return int(np.ceil(n))
    
    def compare_with_monoculture(self, t_ambient: float) -> Dict[str, float]:
        """
        Compare multi-layer system with single-layer monoculture
        
        Returns:
            Dictionary with temperatures for different systems
        """
        # Traditional multi-layer (4 layers)
        t_multi = self.radiation_reaching_ground(t_ambient)
        
        # Monoculture (single layer)
        t_mono = self.temperature_at_layer(t_ambient, 0)
        
        # Difference
        t_diff = t_mono - t_multi
        
        return {
            'multi_layer_temperature': t_multi,
            'monoculture_temperature': t_mono,
            'difference': t_diff,
            'multi_layer_attenuation': self.cumulative_attenuation(4),
            'monoculture_attenuation': self.cumulative_attenuation(1),
            'improvement_factor': (t_ambient - t_multi) / (t_ambient - t_mono) if t_ambient > t_mono else 1
        }
    
    def __repr__(self) -> str:
        return f"LayerAttenuation(κ={self.kappa:.3f}, n_layers={self.n_layers})"
