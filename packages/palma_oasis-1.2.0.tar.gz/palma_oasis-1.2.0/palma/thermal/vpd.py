"""
Vapor Pressure Deficit (VPD) Calculator

VPD = e_s - e_a
where:
- e_s: Saturation vapor pressure at air temperature
- e_a: Actual vapor pressure

Oasis VPD reduction: ΔVPD = 1.2-2.8 kPa relative to desert
"""

import numpy as np
from typing import Optional, Dict, Any, Union
from dataclasses import dataclass


@dataclass
class VPDResult:
    """Vapor Pressure Deficit calculation result"""
    vpd: float  # kPa
    es: float  # Saturation vapor pressure (kPa)
    ea: float  # Actual vapor pressure (kPa)
    t_dewpoint: Optional[float]  # Dew point temperature (°C)
    rh: Optional[float]  # Relative humidity (%)


class VaporPressureDeficit:
    """
    Vapor Pressure Deficit calculator for oasis microclimate
    
    Uses Tetens formula for saturation vapor pressure:
    e_s = 0.6108 * exp(17.27 * T / (T + 237.3))
    """
    
    def __init__(self):
        """Initialize VPD calculator"""
        # Constants
        self.a = 17.27
        self.b = 237.3  # °C
        self.c = 0.6108  # kPa
        
    def saturation_vapor_pressure(self, t_air: float) -> float:
        """
        Calculate saturation vapor pressure at air temperature
        
        e_s = 0.6108 * exp(17.27 * T / (T + 237.3))
        
        Args:
            t_air: Air temperature (°C)
            
        Returns:
            Saturation vapor pressure (kPa)
        """
        return self.c * np.exp((self.a * t_air) / (t_air + self.b))
    
    def actual_vapor_pressure(self, t_air: float, rh: float) -> float:
        """
        Calculate actual vapor pressure from relative humidity
        
        e_a = e_s(T) * (RH / 100)
        """
        es = self.saturation_vapor_pressure(t_air)
        return es * (rh / 100)
    
    def from_rh(self, t_air: float, rh: float) -> VPDResult:
        """
        Calculate VPD from air temperature and relative humidity
        
        Args:
            t_air: Air temperature (°C)
            rh: Relative humidity (%)
            
        Returns:
            VPDResult
        """
        es = self.saturation_vapor_pressure(t_air)
        ea = es * (rh / 100)
        vpd = es - ea
        
        # Estimate dew point (simplified)
        t_dewpoint = self.dewpoint_from_rh(t_air, rh)
        
        return VPDResult(
            vpd=vpd,
            es=es,
            ea=ea,
            t_dewpoint=t_dewpoint,
            rh=rh
        )
    
    def from_dewpoint(self, t_air: float, t_dewpoint: float) -> VPDResult:
        """
        Calculate VPD from air temperature and dew point temperature
        
        e_a = e_s(T_dewpoint)
        """
        es = self.saturation_vapor_pressure(t_air)
        ea = self.saturation_vapor_pressure(t_dewpoint)
        vpd = es - ea
        
        # Calculate RH
        rh = (ea / es) * 100 if es > 0 else 0
        
        return VPDResult(
            vpd=vpd,
            es=es,
            ea=ea,
            t_dewpoint=t_dewpoint,
            rh=rh
        )
    
    def from_specific_humidity(self, t_air: float, q: float,
                              pressure: float = 101.3) -> VPDResult:
        """
        Calculate VPD from specific humidity
        
        e_a = (q * p) / (0.622 + 0.378 * q)
        
        Args:
            t_air: Air temperature (°C)
            q: Specific humidity (kg/kg)
            pressure: Atmospheric pressure (kPa)
            
        Returns:
            VPDResult
        """
        # Convert specific humidity to vapor pressure
        ea = (q * pressure) / (0.622 + 0.378 * q)
        
        es = self.saturation_vapor_pressure(t_air)
        vpd = es - ea
        
        # Calculate RH
        rh = (ea / es) * 100 if es > 0 else 0
        
        return VPDResult(
            vpd=vpd,
            es=es,
            ea=ea,
            t_dewpoint=None,
            rh=rh
        )
    
    def dewpoint_from_rh(self, t_air: float, rh: float) -> float:
        """
        Estimate dew point temperature from air temperature and RH
        
        T_dew = (b * α(T, RH)) / (a - α(T, RH))
        where α(T, RH) = ln(RH/100) + aT/(b+T)
        """
        alpha = np.log(rh / 100) + (self.a * t_air) / (self.b + t_air)
        
        t_dew = (self.b * alpha) / (self.a - alpha)
        
        return t_dew
    
    def rh_from_vpd(self, t_air: float, vpd: float) -> float:
        """
        Calculate relative humidity from VPD
        
        RH = (1 - VPD/e_s) * 100
        """
        es = self.saturation_vapor_pressure(t_air)
        
        if vpd >= es:
            return 0
        
        return (1 - vpd / es) * 100
    
    def vpd_stress_level(self, vpd: float, crop_type: str = 'date_palm') -> str:
        """
        Determine plant stress level from VPD
        
        For date palm (from paper):
        - Low stress: VPD < 1.5 kPa
        - Moderate: 1.5-2.5 kPa
        - High: 2.5-4.0 kPa
        - Extreme: > 4.0 kPa
        """
        if crop_type == 'date_palm':
            if vpd < 1.5:
                return "Low stress"
            elif vpd < 2.5:
                return "Moderate stress"
            elif vpd < 4.0:
                return "High stress"
            else:
                return "Extreme stress"
        else:
            # Generic thresholds
            if vpd < 1.0:
                return "Low"
            elif vpd < 2.0:
                return "Moderate"
            else:
                return "High"
    
    def oasis_vs_desert(self, t_oasis: float, rh_oasis: float,
                        t_desert: float, rh_desert: float) -> Dict[str, float]:
        """
        Compare VPD between oasis and desert
        
        Returns:
            Dictionary with VPD values and reduction
        """
        oasis = self.from_rh(t_oasis, rh_oasis)
        desert = self.from_rh(t_desert, rh_desert)
        
        return {
            'oasis_vpd': oasis.vpd,
            'desert_vpd': desert.vpd,
            'vpd_reduction': desert.vpd - oasis.vpd,
            'oasis_rh': oasis.rh,
            'desert_rh': desert.rh,
            'reduction_percent': (desert.vpd - oasis.vpd) / desert.vpd * 100 if desert.vpd > 0 else 0
        }
    
    def transpiration_factor(self, vpd: float, 
                            vpd_ref: float = 1.5) -> float:
        """
        Calculate transpiration reduction factor due to VPD
        
        f = 1 for VPD < VPD_ref
        f = VPD_ref / VPD for VPD > VPD_ref
        """
        if vpd <= vpd_ref:
            return 1.0
        else:
            return vpd_ref / vpd
    
    def daily_profile(self, t_min: float, t_max: float,
                     rh_min: float, rh_max: float,
                     hours: int = 24) -> Dict[str, np.ndarray]:
        """
        Generate diurnal VPD profile
        
        Args:
            t_min: Minimum temperature (°C)
            t_max: Maximum temperature (°C)
            rh_min: Minimum RH (%) (typically at max temperature)
            rh_max: Maximum RH (%) (typically at min temperature)
            hours: Number of hours
            
        Returns:
            Dictionary with hourly T, RH, VPD
        """
        time = np.arange(hours)
        
        # Temperature cycle (peak at 14-15h)
        t_cycle = t_min + (t_max - t_min) * (1 - np.cos(2 * np.pi * (time - 2) / 24)) / 2
        
        # RH cycle (inverse of temperature)
        rh_cycle = rh_max - (rh_max - rh_min) * (1 - np.cos(2 * np.pi * (time - 2) / 24)) / 2
        rh_cycle = np.clip(rh_cycle, 0, 100)
        
        # Calculate VPD
        vpd = np.zeros(hours)
        for i in range(hours):
            result = self.from_rh(t_cycle[i], rh_cycle[i])
            vpd[i] = result.vpd
        
        return {
            'time': time,
            'temperature': t_cycle,
            'relative_humidity': rh_cycle,
            'vpd': vpd,
            'mean_vpd': np.mean(vpd),
            'max_vpd': np.max(vpd)
        }
    
    def __repr__(self) -> str:
        return f"VaporPressureDeficit(a={self.a}, b={self.b})"
