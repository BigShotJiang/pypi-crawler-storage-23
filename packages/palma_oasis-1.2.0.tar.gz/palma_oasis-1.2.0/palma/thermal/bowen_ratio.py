"""
Bowen Ratio (β = H/LE) for oasis energy partitioning

Oasis Bowen ratio: 0.18-0.42
Desert Bowen ratio: 4-15
"""

import numpy as np
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class BowenRatioResult:
    """Bowen ratio calculation result"""
    value: float  # β = H/LE
    h: float  # Sensible heat flux (W/m²)
    le: float  # Latent heat flux (W/m²)
    method: str  # Method used
    quality: float  # Quality flag (0-1)


class BowenRatio:
    """
    Bowen ratio estimator for surface energy partitioning
    
    β = H/LE = γ·ΔT/Δe
    where:
    - γ: Psychrometric constant (kPa/°C)
    - ΔT: Temperature gradient (K)
    - Δe: Vapor pressure gradient (kPa)
    """
    
    def __init__(self, psychrometric_constant: float = 0.065):
        """
        Initialize Bowen ratio calculator
        
        Args:
            psychrometric_constant: γ in kPa/°C (default 0.065)
        """
        self.gamma = psychrometric_constant
        
    def from_gradients(self, delta_t: float, delta_e: float,
                      method: str = 'standard') -> BowenRatioResult:
        """
        Calculate Bowen ratio from temperature and vapor pressure gradients
        
        β = γ·ΔT/Δe
        
        Args:
            delta_t: Temperature difference between two heights (K)
            delta_e: Vapor pressure difference between two heights (kPa)
            method: Calculation method
            
        Returns:
            BowenRatioResult
        """
        if delta_e == 0:
            return BowenRatioResult(
                value=float('inf'),
                h=0,
                le=0,
                method=method,
                quality=0
            )
        
        beta = self.gamma * delta_t / delta_e
        
        # Quality based on gradient magnitude
        quality = min(1.0, abs(delta_e) / 0.1)
        
        return BowenRatioResult(
            value=beta,
            h=0,  # Will be computed later
            le=0,
            method=method,
            quality=quality
        )
    
    def from_fluxes(self, h: float, le: float) -> BowenRatioResult:
        """
        Calculate Bowen ratio from flux measurements
        
        β = H/LE
        """
        if le == 0:
            return BowenRatioResult(
                value=float('inf'),
                h=h,
                le=le,
                method='flux',
                quality=1.0 if le > 0 else 0
            )
        
        beta = h / le
        
        return BowenRatioResult(
            value=beta,
            h=h,
            le=le,
            method='flux',
            quality=1.0
        )
    
    def from_energy_balance(self, rn: float, g: float, le: float) -> float:
        """
        Calculate Bowen ratio from energy balance residual
        
        H = R_n - G - LE
        β = (R_n - G - LE) / LE
        """
        if le == 0:
            return float('inf')
        
        h = rn - g - le
        return h / le
    
    def classify_surface(self, beta: float) -> str:
        """
        Classify surface type based on Bowen ratio
        
        Returns:
            Surface type classification
        """
        if beta < 0:
            return "Advection (negative β)"
        elif beta < 0.2:
            return "Wetland/Open water"
        elif beta < 0.4:
            return "Oasis/Irrigated crop"
        elif beta < 1.0:
            return "Well-watered vegetation"
        elif beta < 2.0:
            return "Dryland agriculture"
        elif beta < 5.0:
            return "Semi-arid shrubland"
        elif beta < 10.0:
            return "Arid desert"
        else:
            return "Extreme desert"
    
    def evaporative_fraction(self, beta: float) -> float:
        """
        Calculate evaporative fraction from Bowen ratio
        
        EF = LE/(R_n - G) = 1/(1 + β)
        """
        if beta < 0:
            return 1.0
        
        return 1 / (1 + beta)
    
    def available_energy_to_le(self, rn_g: float, beta: float) -> float:
        """
        Calculate latent heat flux from available energy and Bowen ratio
        
        LE = (R_n - G) / (1 + β)
        """
        return rn_g / (1 + beta)
    
    def available_energy_to_h(self, rn_g: float, beta: float) -> float:
        """
        Calculate sensible heat flux from available energy and Bowen ratio
        
        H = (R_n - G) · β / (1 + β)
        """
        return rn_g * beta / (1 + beta)
    
    def oasis_signature(self, beta: float) -> bool:
        """
        Check if Bowen ratio indicates oasis conditions
        
        Oasis β = 0.18-0.42 from paper
        """
        return 0.18 <= beta <= 0.42
    
    def desert_signature(self, beta: float) -> bool:
        """
        Check if Bowen ratio indicates desert conditions
        
        Desert β = 4-15 from paper
        """
        return 4 <= beta <= 15
    
    def stress_indicator(self, beta: float, 
                        beta_optimal: float = 0.3) -> float:
        """
        Calculate water stress indicator from Bowen ratio
        
        0 = no stress, 1 = extreme stress
        """
        if beta <= beta_optimal:
            return 0
        
        # Normalized stress
        stress = (beta - beta_optimal) / (10 - beta_optimal)
        return min(stress, 1.0)
    
    def estimate_et_from_bowen(self, rn: float, g: float, 
                               beta: float) -> float:
        """
        Estimate evapotranspiration from Bowen ratio
        
        Returns:
            Latent heat flux (W/m²)
        """
        return (rn - g) / (1 + beta)
    
    def uncertainty(self, beta: float, 
                   delta_t_error: float = 0.1,
                   delta_e_error: float = 0.01) -> float:
        """
        Estimate uncertainty in Bowen ratio
        
        Propagates errors in temperature and vapor pressure gradients
        """
        if beta == float('inf'):
            return float('inf')
        
        # Relative error = sqrt((dβ/dΔT·σ_ΔT)² + (dβ/dΔe·σ_Δe)²) / β
        rel_error_t = delta_t_error / abs(beta / self.gamma)
        rel_error_e = delta_e_error / abs(1 / beta)
        
        total_rel_error = np.sqrt(rel_error_t**2 + rel_error_e**2)
        
        return beta * total_rel_error
    
    def __repr__(self) -> str:
        return f"BowenRatio(γ={self.gamma:.3f})"


class BowenRatioProfile:
    """
    Vertical profile of Bowen ratio through canopy layers
    """
    
    def __init__(self, n_layers: int = 4):
        self.n_layers = n_layers
        self.layer_names = ['palm', 'fruit_tree', 'shrub', 'ground']
        
    def calculate_profile(self, t_profile: np.ndarray,
                         e_profile: np.ndarray,
                         gamma: float = 0.065) -> Dict[str, Any]:
        """
        Calculate Bowen ratio at each layer
        
        Args:
            t_profile: Temperature at each layer (°C)
            e_profile: Vapor pressure at each layer (kPa)
            gamma: Psychrometric constant
            
        Returns:
            Dictionary with layer Bowen ratios
        """
        if len(t_profile) != self.n_layers + 1:
            raise ValueError(f"Expected {self.n_layers + 1} levels")
        
        beta_layers = []
        
        for i in range(self.n_layers):
            delta_t = t_profile[i] - t_profile[i+1]
            delta_e = e_profile[i] - e_profile[i+1]
            
            if delta_e != 0:
                beta = gamma * delta_t / delta_e
            else:
                beta = float('inf')
            
            beta_layers.append(beta)
        
        return {
            'layer_names': self.layer_names,
            'bowen_ratios': beta_layers,
            'mean_bowen': np.mean([b for b in beta_layers if b != float('inf')]),
            'profile': dict(zip(self.layer_names, beta_layers))
        }
    
    def canopy_integrated(self, beta_layers: list,
                         layer_weights: Optional[np.ndarray] = None) -> float:
        """
        Calculate canopy-integrated Bowen ratio
        
        Args:
            beta_layers: Bowen ratio for each layer
            layer_weights: Weight for each layer (e.g., LAI contribution)
            
        Returns:
            Integrated Bowen ratio
        """
        if layer_weights is None:
            layer_weights = np.ones(len(beta_layers)) / len(beta_layers)
        
        # Filter out infinite values
        valid = [i for i, b in enumerate(beta_layers) if b != float('inf')]
        
        if not valid:
            return float('inf')
        
        weights = np.array([layer_weights[i] for i in valid])
        weights = weights / weights.sum()
        
        beta_valid = [beta_layers[i] for i in valid]
        
        return np.average(beta_valid, weights=weights)
