"""
GBIF (Global Biodiversity Information Facility) Client

Fetches biodiversity records for BST parameter
Provides species occurrence data for oasis sites
"""

import numpy as np
from typing import Optional, Dict, Any, List
from pathlib import Path
import datetime


class GBIFClient:
    """
    Client for GBIF API
    
    Provides:
    - Species occurrence records
    - Biodiversity metrics
    - Historical survey data
    """
    
    def __init__(self, api_key: Optional[str] = None,
                 data_dir: Optional[str] = None):
        """
        Initialize GBIF client
        
        Args:
            api_key: GBIF API key
            data_dir: Directory for cached data
        """
        self.api_key = api_key
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/gbif")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.base_url = "https://api.gbif.org/v1"
        
    def search_species(self, scientific_name: str) -> List[Dict[str, Any]]:
        """
        Search for species by scientific name
        
        Args:
            scientific_name: Scientific name (e.g., 'Phoenix dactylifera')
            
        Returns:
            List of species matches
        """
        # Mock response
        return [{
            'key': 123456,
            'scientificName': scientific_name,
            'kingdom': 'Plantae',
            'phylum': 'Tracheophyta',
            'class': 'Liliopsida',
            'order': 'Arecales',
            'family': 'Arecaceae',
            'genus': 'Phoenix'
        }]
    
    def get_occurrences(self, species_key: int,
                       bbox: List[float],
                       year_from: Optional[int] = None,
                       year_to: Optional[int] = None,
                       limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get species occurrence records
        
        Args:
            species_key: GBIF species key
            bbox: [min_lon, min_lat, max_lon, max_lat]
            year_from: Start year
            year_to: End year
            limit: Maximum records
            
        Returns:
            List of occurrence records
        """
        # Mock occurrences
        occurrences = []
        
        for i in range(min(limit, 50)):
            year = year_from or 2000
            if year_to:
                year = np.random.randint(year_from or 2000, year_to)
            
            occurrences.append({
                'key': f"occ_{i}",
                'speciesKey': species_key,
                'decimalLatitude': np.random.uniform(bbox[1], bbox[3]),
                'decimalLongitude': np.random.uniform(bbox[0], bbox[2]),
                'year': year,
                'month': np.random.randint(1, 13),
                'day': np.random.randint(1, 29),
                'basisOfRecord': 'HUMAN_OBSERVATION',
                'occurrenceStatus': 'PRESENT'
            })
        
        return occurrences
    
    def get_site_biodiversity(self, site_name: str,
                             bbox: List[float],
                             start_year: int = 1998,
                             end_year: int = 2026) -> Dict[str, Any]:
        """
        Get biodiversity data for monitoring site
        
        Args:
            site_name: Site name
            bbox: [min_lon, min_lat, max_lon, max_lat]
            start_year: Start year
            end_year: End year
            
        Returns:
            Dictionary with biodiversity data
        """
        # Mock biodiversity data
        species_list = [
            'Phoenix dactylifera',
            'Olea europaea',
            'Punica granatum',
            'Ficus carica',
            'Acacia tortilis',
            'Tamarix aphylla',
            'Ziziphus lotus',
            'Retama raetam'
        ]
        
        all_occurrences = []
        
        for species in species_list:
            species_info = self.search_species(species)
            if species_info:
                occurrences = self.get_occurrences(
                    species_info[0]['key'],
                    bbox,
                    year_from=start_year,
                    year_to=end_year,
                    limit=20
                )
                all_occurrences.extend(occurrences)
        
        # Group by year
        yearly_counts = {}
        for occ in all_occurrences:
            year = occ.get('year', 2000)
            if year not in yearly_counts:
                yearly_counts[year] = []
            yearly_counts[year].append(occ['speciesKey'])
        
        # Calculate yearly richness
        yearly_richness = {}
        for year, occs in yearly_counts.items():
            yearly_richness[year] = len(set(occs))
        
        return {
            'site': site_name,
            'total_occurrences': len(all_occurrences),
            'unique_species': len(set([occ['speciesKey'] for occ in all_occurrences])),
            'yearly_richness': yearly_richness,
            'species_list': species_list,
            'occurrences': all_occurrences[:10]  # Return first 10 as sample
        }
    
    def download_site_data(self, site_name: str,
                          bbox: List[float],
                          output_file: Optional[str] = None) -> str:
        """
        Download biodiversity data for site
        
        Args:
            site_name: Site name
            bbox: [min_lon, min_lat, max_lon, max_lat]
            output_file: Output file path
            
        Returns:
            Path to downloaded data
        """
        if output_file is None:
            output_file = self.data_dir / f"{site_name}_biodiversity.json"
        
        data = self.get_site_biodiversity(site_name, bbox)
        
        import json
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return str(output_file)
    
    def biodiversity_trend(self, site_name: str,
                          bbox: List[float],
                          start_year: int = 1998,
                          end_year: int = 2026) -> Dict[str, Any]:
        """
        Analyze biodiversity trend over time
        
        Args:
            site_name: Site name
            bbox: Bounding box
            start_year: Start year
            end_year: End year
            
        Returns:
            Trend analysis
        """
        data = self.get_site_biodiversity(site_name, bbox, start_year, end_year)
        
        yearly_richness = data['yearly_richness']
        
        years = sorted(yearly_richness.keys())
        richness = [yearly_richness[y] for y in years]
        
        # Calculate trend
        if len(years) > 1:
            from scipy import stats
            x = np.array(years)
            y = np.array(richness)
            
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            trend = {
                'slope_per_year': slope,
                'r_squared': r_value**2,
                'p_value': p_value,
                'significant': p_value < 0.05
            }
        else:
            trend = None
        
        return {
            'site': site_name,
            'years': years,
            'richness': richness,
            'trend': trend,
            'mean_richness': np.mean(richness) if richness else 0,
            'max_richness': max(richness) if richness else 0,
            'min_richness': min(richness) if richness else 0
        }
    
    def __repr__(self) -> str:
        return f"GBIFClient(data_dir={self.data_dir})"
