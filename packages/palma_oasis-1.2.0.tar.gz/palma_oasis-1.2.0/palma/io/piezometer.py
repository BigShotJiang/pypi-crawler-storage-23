"""
Piezometer Data Reader for Solinst Levelogger

Reads groundwater level data from Solinst Levelogger 3001
Provides ARVC parameter input
"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, Any, List
from pathlib import Path
import datetime


class PiezometerReader:
    """
    Reader for Solinst Levelogger piezometer data
    
    Handles:
    - CSV exports from Levelogger software
    - Water level time series
    - Temperature and conductivity (if available)
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize piezometer reader
        
        Args:
            data_dir: Directory for piezometer data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/piezometers")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
    def read_csv(self, filepath: str) -> pd.DataFrame:
        """
        Read Levelogger CSV file
        
        Args:
            filepath: Path to CSV file
            
        Returns:
            DataFrame with time series data
        """
        path = Path(filepath)
        if not path.is_absolute():
            path = self.data_dir / path
        
        # Try different CSV formats
        try:
            # Standard Levelogger export
            df = pd.read_csv(path, skiprows=1)
            
            # Rename columns to standard names
            column_map = {
                'Date': 'date',
                'Time': 'time',
                'Date Time': 'datetime',
                'Level': 'water_level_m',
                'Temperature': 'temperature_c',
                'Conductivity': 'conductivity_us_cm'
            }
            
            df = df.rename(columns=column_map)
            
            # Create datetime column
            if 'datetime' not in df.columns:
                if 'date' in df.columns and 'time' in df.columns:
                    df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'])
                elif 'date' in df.columns:
                    df['datetime'] = pd.to_datetime(df['date'])
            
            return df
            
        except Exception as e:
            raise IOError(f"Error reading piezometer file {filepath}: {e}")
    
    def read_levelogger(self, filepath: str) -> pd.DataFrame:
        """
        Read native Levelogger format (.lev)
        
        Args:
            filepath: Path to .lev file
            
        Returns:
            DataFrame with time series
        """
        # Levelogger binary format is complex
        # This is a placeholder - would need proper parser
        return self.read_csv(filepath)
    
    def load_site_data(self, site_name: str, 
                       start_date: Optional[str] = None,
                       end_date: Optional[str] = None) -> pd.DataFrame:
        """
        Load all piezometer data for a site
        
        Args:
            site_name: Site name (e.g., 'draa_valley')
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            Combined DataFrame for site
        """
        site_dir = self.data_dir / site_name
        
        if not site_dir.exists():
            raise FileNotFoundError(f"Site directory not found: {site_dir}")
        
        # Find all CSV files
        csv_files = list(site_dir.glob("*.csv"))
        lev_files = list(site_dir.glob("*.lev"))
        
        all_files = csv_files + lev_files
        
        if not all_files:
            raise FileNotFoundError(f"No data files found for site {site_name}")
        
        # Read and combine all files
        dfs = []
        for filepath in all_files:
            try:
                if filepath.suffix == '.csv':
                    df = self.read_csv(filepath)
                else:
                    df = self.read_levelogger(filepath)
                
                # Add source file column
                df['source_file'] = filepath.name
                dfs.append(df)
            except Exception as e:
                print(f"Warning: Could not read {filepath}: {e}")
        
        if not dfs:
            raise ValueError(f"No valid data files for site {site_name}")
        
        # Combine all data
        combined = pd.concat(dfs, ignore_index=True)
        
        # Sort by datetime
        if 'datetime' in combined.columns:
            combined = combined.sort_values('datetime')
        
        # Filter by date range
        if start_date and 'datetime' in combined.columns:
            start = pd.to_datetime(start_date)
            combined = combined[combined['datetime'] >= start]
        
        if end_date and 'datetime' in combined.columns:
            end = pd.to_datetime(end_date)
            combined = combined[combined['datetime'] <= end]
        
        return combined
    
    def calculate_daily_means(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate daily mean water levels
        
        Args:
            df: DataFrame with datetime and water_level_m
            
        Returns:
            DataFrame with daily means
        """
        if 'datetime' not in df.columns:
            raise ValueError("DataFrame must have datetime column")
        
        if 'water_level_m' not in df.columns:
            raise ValueError("DataFrame must have water_level_m column")
        
        # Extract date
        df['date'] = df['datetime'].dt.date
        
        # Group by date and calculate mean
        daily = df.groupby('date').agg({
            'water_level_m': 'mean',
            'temperature_c': 'mean' if 'temperature_c' in df.columns else None,
            'conductivity_us_cm': 'mean' if 'conductivity_us_cm' in df.columns else None
        }).reset_index()
        
        daily['date'] = pd.to_datetime(daily['date'])
        
        return daily
    
    def calculate_hydraulic_head(self, df: pd.DataFrame,
                                elevation: float) -> pd.DataFrame:
        """
        Calculate hydraulic head from water level
        
        Head = elevation + water_level
        
        Args:
            df: DataFrame with water_level_m
            elevation: Well elevation (m above datum)
            
        Returns:
            DataFrame with hydraulic_head column
        """
        df = df.copy()
        df['hydraulic_head_m'] = elevation + df['water_level_m']
        return df
    
    def detect_anomalies(self, df: pd.DataFrame,
                        window: int = 7,
                        threshold: float = 3.0) -> pd.DataFrame:
        """
        Detect anomalies in water level time series
        
        Args:
            df: DataFrame with water_level_m
            window: Rolling window size (days)
            threshold: Standard deviation threshold
            
        Returns:
            DataFrame with anomaly flags
        """
        if 'datetime' not in df.columns:
            raise ValueError("DataFrame must have datetime column")
        
        # Set datetime as index
        df = df.set_index('datetime')
        
        # Calculate rolling statistics
        rolling_mean = df['water_level_m'].rolling(window, center=True).mean()
        rolling_std = df['water_level_m'].rolling(window, center=True).std()
        
        # Detect anomalies
        df['anomaly'] = np.abs(df['water_level_m'] - rolling_mean) > threshold * rolling_std
        
        # Reset index
        df = df.reset_index()
        
        return df
    
    def export_for_arvc(self, df: pd.DataFrame, 
                       output_path: str) -> None:
        """
        Export data in format suitable for ARVC calculation
        
        Args:
            df: Processed DataFrame
            output_path: Output file path
        """
        # Select relevant columns
        export_cols = ['datetime', 'water_level_m', 'hydraulic_head_m']
        export_cols = [col for col in export_cols if col in df.columns]
        
        export_df = df[export_cols].copy()
        
        # Format datetime
        export_df['datetime'] = export_df['datetime'].dt.strftime('%Y-%m-%d %H:%M:%S')
        
        # Save to CSV
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        export_df.to_csv(path, index=False)
    
    def __repr__(self) -> str:
        return f"PiezometerReader(data_dir={self.data_dir})"
