"""
Thermocouple Data Reader for Campbell Scientific T-type

Reads temperature data from multi-level thermocouple arrays
Provides PTSI and CMBF parameter input
"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, Any, List
from pathlib import Path


class ThermocoupleReader:
    """
    Reader for Campbell Scientific thermocouple data
    
    Handles:
    - Multi-level temperature profiles
    - Data from Campbell dataloggers (TOA5 format)
    - Temperature gradients for PTSI and CMBF
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize thermocouple reader
        
        Args:
            data_dir: Directory for thermocouple data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/thermocouples")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Typical measurement heights (m)
        self.default_heights = [0.5, 1.5, 3.0, 4.5, 6.0]
        
    def read_toa5(self, filepath: str) -> pd.DataFrame:
        """
        Read Campbell TOA5 format data
        
        Args:
            filepath: Path to TOA5 file
            
        Returns:
            DataFrame with time series
        """
        path = Path(filepath)
        if not path.is_absolute():
            path = self.data_dir / path
        
        try:
            # TOA5 format has 4 header rows
            df = pd.read_csv(path, skiprows=4, header=0)
            
            # Parse timestamp
            if 'TIMESTAMP' in df.columns:
                df['datetime'] = pd.to_datetime(df['TIMESTAMP'])
            
            return df
            
        except Exception as e:
            raise IOError(f"Error reading TOA5 file {filepath}: {e}")
    
    def read_csv(self, filepath: str) -> pd.DataFrame:
        """
        Read generic CSV thermocouple data
        
        Args:
            filepath: Path to CSV file
            
        Returns:
            DataFrame with time series
        """
        path = Path(filepath)
        if not path.is_absolute():
            path = self.data_dir / path
        
        try:
            df = pd.read_csv(path)
            
            # Try to parse datetime
            if 'datetime' in df.columns:
                df['datetime'] = pd.to_datetime(df['datetime'])
            elif 'timestamp' in df.columns:
                df['datetime'] = pd.to_datetime(df['timestamp'])
            
            return df
            
        except Exception as e:
            raise IOError(f"Error reading CSV file {filepath}: {e}")
    
    def load_profile_data(self, site_name: str,
                          heights: Optional[List[float]] = None) -> Dict[float, pd.DataFrame]:
        """
        Load temperature profile data for multiple heights
        
        Args:
            site_name: Site name
            heights: List of measurement heights (m)
                    If None, use default_heights
            
        Returns:
            Dictionary mapping height -> DataFrame
        """
        site_dir = self.data_dir / site_name
        
        if not site_dir.exists():
            raise FileNotFoundError(f"Site directory not found: {site_dir}")
        
        if heights is None:
            heights = self.default_heights
        
        profile_data = {}
        
        for height in heights:
            # Look for files with height in name
            pattern = f"*{height:04.1f}m*.csv"
            height_files = list(site_dir.glob(pattern))
            
            # Also try without decimal
            if not height_files:
                pattern = f"*{int(height)}m*.csv"
                height_files = list(site_dir.glob(pattern))
            
            if height_files:
                dfs = []
                for filepath in height_files:
                    try:
                        if filepath.suffix == '.csv':
                            df = self.read_csv(filepath)
                        else:
                            df = self.read_toa5(filepath)
                        
                        df['height_m'] = height
                        dfs.append(df)
                    except Exception as e:
                        print(f"Warning: Could not read {filepath}: {e}")
                
                if dfs:
                    combined = pd.concat(dfs, ignore_index=True)
                    if 'datetime' in combined.columns:
                        combined = combined.sort_values('datetime')
                    profile_data[height] = combined
        
        return profile_data
    
    def calculate_temperature_gradient(self, profile_data: Dict[float, pd.DataFrame],
                                      time_window: str = '1H') -> pd.DataFrame:
        """
        Calculate temperature gradients between heights
        
        Args:
            profile_data: Dictionary from load_profile_data
            time_window: Resampling time window
            
        Returns:
            DataFrame with gradients
        """
        if len(profile_data) < 2:
            raise ValueError("Need at least 2 heights for gradient calculation")
        
        # Resample all data to common time grid
        heights = sorted(profile_data.keys())
        resampled = {}
        
        for height in heights:
            df = profile_data[height]
            if 'datetime' in df.columns and 'temperature_c' in df.columns:
                df = df.set_index('datetime')
                resampled[height] = df['temperature_c'].resample(time_window).mean()
        
        # Combine into single DataFrame
        temp_df = pd.DataFrame(resampled)
        temp_df = temp_df.sort_index()
        
        # Calculate gradients
        gradients = {}
        for i in range(len(heights) - 1):
            h1 = heights[i]
            h2 = heights[i + 1]
            delta_h = h2 - h1
            
            gradient_name = f"gradient_{h1:.1f}m_{h2:.1f}m"
            gradients[gradient_name] = (temp_df[h2] - temp_df[h1]) / delta_h
        
        gradient_df = pd.DataFrame(gradients)
        
        return gradient_df
    
    def calculate_ptsi(self, profile_data: Dict[float, pd.DataFrame],
                      ambient_temp: pd.Series) -> pd.Series:
        """
        Calculate Phyto-Thermal Shielding Index
        
        PTSI = (T_ambient - T_subcanopy) / T_ambient * 100
        
        Args:
            profile_data: Temperature profile
            ambient_temp: Ambient desert temperature series
            
        Returns:
            PTSI time series
        """
        # Get subcanopy temperature (lowest measurement)
        heights = sorted(profile_data.keys())
        if not heights:
            raise ValueError("No profile data")
        
        subcanopy_height = heights[0]
        subcanopy_df = profile_data[subcanopy_height]
        
        if 'datetime' not in subcanopy_df.columns or 'temperature_c' not in subcanopy_df.columns:
            raise ValueError("Subcanopy data missing required columns")
        
        # Align with ambient temperature
        subcanopy = subcanopy_df.set_index('datetime')['temperature_c']
        
        # Align indices
        common_index = subcanopy.index.intersection(ambient_temp.index)
        
        if len(common_index) == 0:
            raise ValueError("No overlapping timestamps")
        
        t_sub = subcanopy.loc[common_index]
        t_amb = ambient_temp.loc[common_index]
        
        # Calculate PTSI
        ptsi = (t_amb - t_sub) / t_amb * 100
        ptsi = ptsi.clip(0, 100)
        
        return ptsi
    
    def detect_inversion(self, profile_data: Dict[float, pd.DataFrame]) -> pd.DataFrame:
        """
        Detect temperature inversions in profile
        
        Returns:
            DataFrame with inversion indicators
        """
        heights = sorted(profile_data.keys())
        
        # Resample all data
        resampled = {}
        for height in heights:
            df = profile_data[height]
            if 'datetime' in df.columns and 'temperature_c' in df.columns:
                df = df.set_index('datetime')
                resampled[height] = df['temperature_c']
        
        temp_df = pd.DataFrame(resampled)
        temp_df = temp_df.sort_index()
        
        # Check if temperature increases with height (inversion)
        inversions = pd.DataFrame(index=temp_df.index)
        
        for i in range(len(heights) - 1):
            h_low = heights[i]
            h_high = heights[i + 1]
            
            inversion = temp_df[h_high] > temp_df[h_low]
            inversions[f'inversion_{h_low:.1f}m_{h_high:.1f}m'] = inversion
        
        inversions['any_inversion'] = inversions.any(axis=1)
        inversions['inversion_strength'] = inversions.sum(axis=1) / len(heights)
        
        return inversions
    
    def calculate_daily_cycle(self, profile_data: Dict[float, pd.DataFrame]) -> Dict[str, Any]:
        """
        Calculate average daily temperature cycle
        
        Returns:
            Dictionary with hourly averages by height
        """
        heights = sorted(profile_data.keys())
        
        hourly_profiles = {}
        
        for height in heights:
            df = profile_data[height]
            if 'datetime' in df.columns and 'temperature_c' in df.columns:
                df = df.set_index('datetime')
                
                # Extract hour
                df['hour'] = df.index.hour
                
                # Average by hour
                hourly = df.groupby('hour')['temperature_c'].agg(['mean', 'std', 'count'])
                hourly_profiles[height] = hourly
        
        return hourly_profiles
    
    def export_for_ptsi(self, ptsi_series: pd.Series,
                       output_path: str) -> None:
        """
        Export PTSI data
        
        Args:
            ptsi_series: PTSI time series
            output_path: Output file path
        """
        df = pd.DataFrame({
            'datetime': ptsi_series.index,
            'ptsi': ptsi_series.values
        })
        
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(path, index=False)
    
    def __repr__(self) -> str:
        return f"ThermocoupleReader(data_dir={self.data_dir})"
