"""
Soil EC Sensor Reader for Decagon 5TE

Reads soil electrical conductivity, temperature, and moisture
Provides SSSP parameter input
"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, Any, List
from pathlib import Path


class SoilECReader:
    """
    Reader for Decagon 5TE soil sensor data
    
    Measures:
    - Electrical conductivity (dS/m)
    - Soil temperature (°C)
    - Volumetric water content (m³/m³)
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize soil EC reader
        
        Args:
            data_dir: Directory for soil sensor data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/soil_ec")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Sensor depth mapping (typical installations)
        self.depth_mapping = {
            'shallow': 0.15,  # 15 cm
            'medium': 0.30,    # 30 cm
            'deep': 0.60,      # 60 cm
            'very_deep': 0.90  # 90 cm
        }
        
    def read_csv(self, filepath: str) -> pd.DataFrame:
        """
        Read Decagon 5TE CSV file
        
        Args:
            filepath: Path to CSV file
            
        Returns:
            DataFrame with sensor data
        """
        path = Path(filepath)
        if not path.is_absolute():
            path = self.data_dir / path
        
        try:
            # Read CSV with Decagon format
            df = pd.read_csv(path, skiprows=1)
            
            # Rename columns to standard names
            column_map = {
                'Date': 'date',
                'Time': 'time',
                'Date Time': 'datetime',
                'EC (dS/m)': 'ec_ds_m',
                'Temperature (C)': 'temperature_c',
                'VWC (m3/m3)': 'vwc_m3_m3'
            }
            
            df = df.rename(columns=column_map)
            
            # Create datetime column
            if 'datetime' not in df.columns:
                if 'date' in df.columns and 'time' in df.columns:
                    df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'])
                elif 'date' in df.columns:
                    df['datetime'] = pd.to_datetime(df['date'])
            
            return df
            
        except Exception as e:
            raise IOError(f"Error reading soil EC file {filepath}: {e}")
    
    def load_profile_data(self, site_name: str,
                          depths: Optional[List[str]] = None) -> Dict[str, pd.DataFrame]:
        """
        Load soil profile data from multiple depths
        
        Args:
            site_name: Site name
            depths: List of depth categories (e.g., ['shallow', 'medium'])
                   If None, load all available
            
        Returns:
            Dictionary mapping depth -> DataFrame
        """
        site_dir = self.data_dir / site_name
        
        if not site_dir.exists():
            raise FileNotFoundError(f"Site directory not found: {site_dir}")
        
        if depths is None:
            depths = list(self.depth_mapping.keys())
        
        profile_data = {}
        
        for depth in depths:
            depth_dir = site_dir / depth
            if depth_dir.exists():
                csv_files = list(depth_dir.glob("*.csv"))
                
                if csv_files:
                    dfs = []
                    for filepath in csv_files:
                        try:
                            df = self.read_csv(filepath)
                            df['depth'] = self.depth_mapping[depth]
                            df['depth_category'] = depth
                            dfs.append(df)
                        except Exception as e:
                            print(f"Warning: Could not read {filepath}: {e}")
                    
                    if dfs:
                        combined = pd.concat(dfs, ignore_index=True)
                        if 'datetime' in combined.columns:
                            combined = combined.sort_values('datetime')
                        profile_data[depth] = combined
        
        return profile_data
    
    def calculate_profile_statistics(self, profile_data: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        Calculate statistics for soil profile
        
        Args:
            profile_data: Dictionary from load_profile_data
            
        Returns:
            Statistics by depth and overall
        """
        stats = {}
        
        # Statistics by depth
        for depth, df in profile_data.items():
            depth_m = self.depth_mapping.get(depth, 0)
            
            stats[depth] = {
                'depth_m': depth_m,
                'mean_ec': df['ec_ds_m'].mean() if 'ec_ds_m' in df.columns else None,
                'std_ec': df['ec_ds_m'].std() if 'ec_ds_m' in df.columns else None,
                'mean_vwc': df['vwc_m3_m3'].mean() if 'vwc_m3_m3' in df.columns else None,
                'mean_temp': df['temperature_c'].mean() if 'temperature_c' in df.columns else None,
                'n_measurements': len(df)
            }
        
        # Overall profile statistics (weighted by depth)
        if profile_data:
            all_data = []
            for depth, df in profile_data.items():
                df_copy = df.copy()
                df_copy['depth_m'] = self.depth_mapping.get(depth, 0)
                all_data.append(df_copy)
            
            if all_data:
                combined = pd.concat(all_data, ignore_index=True)
                
                # Weight by inverse depth (surface more important)
                weights = 1 / (combined['depth_m'] + 0.1)
                weights = weights / weights.sum()
                
                stats['overall'] = {
                    'weighted_mean_ec': np.average(combined['ec_ds_m'], weights=weights) if 'ec_ds_m' in combined.columns else None,
                    'mean_ec': combined['ec_ds_m'].mean() if 'ec_ds_m' in combined.columns else None,
                    'max_ec': combined['ec_ds_m'].max() if 'ec_ds_m' in combined.columns else None,
                    'min_ec': combined['ec_ds_m'].min() if 'ec_ds_m' in combined.columns else None,
                    'n_depths': len(profile_data)
                }
        
        return stats
    
    def calculate_salinity_stress(self, df: pd.DataFrame,
                                 ec_critical: float = 8.4,
                                 ec_baseline: float = 1.2) -> pd.DataFrame:
        """
        Calculate salinity stress parameters
        
        Args:
            df: DataFrame with ec_ds_m
            ec_critical: Critical EC threshold
            ec_baseline: Baseline EC
            
        Returns:
            DataFrame with stress indicators
        """
        df = df.copy()
        
        if 'ec_ds_m' not in df.columns:
            raise ValueError("DataFrame must have ec_ds_m column")
        
        # SSSP formula
        df['sssp'] = (df['ec_ds_m'] - ec_baseline) / (ec_critical - ec_baseline)
        df['sssp'] = df['sssp'].clip(0, 1)
        
        # Stress level
        conditions = [
            df['sssp'] < 0.2,
            df['sssp'] < 0.45,
            df['sssp'] < 0.70,
            df['sssp'] < 0.90,
            df['sssp'] >= 0.90
        ]
        choices = ['LOW', 'MODERATE', 'HIGH', 'SEVERE', 'CRITICAL']
        
        df['stress_level'] = np.select(conditions, choices, default='UNKNOWN')
        
        # Osmotic potential (MPa)
        df['osmotic_potential_mpa'] = -0.036 * df['ec_ds_m']
        
        return df
    
    def detect_salinity_trend(self, df: pd.DataFrame,
                              window: int = 30) -> Dict[str, Any]:
        """
        Detect trend in salinity over time
        
        Args:
            df: DataFrame with datetime and ec_ds_m
            window: Rolling window for trend
            
        Returns:
            Dictionary with trend information
        """
        if 'datetime' not in df.columns:
            raise ValueError("DataFrame must have datetime column")
        
        # Set datetime as index
        df = df.set_index('datetime')
        df = df.sort_index()
        
        # Calculate rolling mean
        rolling_mean = df['ec_ds_m'].rolling(window, center=True).mean()
        
        # Linear trend
        if len(df) > 1:
            x = np.arange(len(df))
            y = df['ec_ds_m'].values
            
            slope, intercept = np.polyfit(x, y, 1)
            
            # Trend direction
            if slope > 0.01:
                trend = 'INCREASING'
            elif slope < -0.01:
                trend = 'DECREASING'
            else:
                trend = 'STABLE'
            
            # Time to critical threshold
            current_ec = y[-1]
            critical_ec = 8.4
            
            if slope > 0 and current_ec < critical_ec:
                years_to_critical = (critical_ec - current_ec) / (slope * 365)
            else:
                years_to_critical = None
        else:
            slope = 0
            trend = 'UNKNOWN'
            years_to_critical = None
        
        return {
            'current_ec': df['ec_ds_m'].iloc[-1] if len(df) > 0 else None,
            'mean_ec': df['ec_ds_m'].mean(),
            'max_ec': df['ec_ds_m'].max(),
            'trend_slope_per_day': slope,
            'trend_direction': trend,
            'years_to_critical': years_to_critical,
            'n_measurements': len(df)
        }
    
    def export_for_sssp(self, df: pd.DataFrame,
                       output_path: str) -> None:
        """
        Export data in format suitable for SSSP calculation
        
        Args:
            df: Processed DataFrame
            output_path: Output file path
        """
        export_cols = ['datetime', 'ec_ds_m', 'depth', 'sssp', 'stress_level']
        export_cols = [col for col in export_cols if col in df.columns]
        
        export_df = df[export_cols].copy()
        
        if 'datetime' in export_df.columns:
            export_df['datetime'] = pd.to_datetime(export_df['datetime']).dt.strftime('%Y-%m-%d %H:%M:%S')
        
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        export_df.to_csv(path, index=False)
    
    def __repr__(self) -> str:
        return f"SoilECReader(data_dir={self.data_dir})"
