"""
Zenodo Dataset Archive Interface

Provides access to PALMA published datasets
DOI: 10.5281/zenodo.palma.2026
"""

import numpy as np
from typing import Optional, Dict, Any, List
from pathlib import Path
import json


class ZenodoClient:
    """
    Client for Zenodo dataset archive
    
    Provides:
    - Dataset download
    - Metadata access
    - Version management
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize Zenodo client
        
        Args:
            data_dir: Directory for downloaded data
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/zenodo")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.base_url = "https://zenodo.org/api"
        self.doi = "10.5281/zenodo.palma.2026"
        
    def get_record_info(self) -> Dict[str, Any]:
        """
        Get information about PALMA Zenodo record
        
        Returns:
            Record metadata
        """
        return {
            'doi': self.doi,
            'title': 'PALMA Oasis Monitoring Dataset: 31 sites, 28 years (1998–2026)',
            'authors': ['Baladi, S.', 'Nassar, L.', 'Al-Rashidi, T.', 'Oufkir, A.', 'Hamdan, Y.'],
            'version': '1.0.0',
            'publication_date': '2026-02-19',
            'license': 'CC-BY-4.0',
            'size': '4.2 TB',
            'formats': ['CSV', 'NetCDF', 'GeoTIFF', 'JSON'],
            'files': [
                'site_data/',
                'timeseries/',
                'satellite/',
                'biodiversity/',
                'documentation/'
            ]
        }
    
    def list_datasets(self) -> List[Dict[str, Any]]:
        """
        List available datasets
        
        Returns:
            List of dataset descriptions
        """
        return [
            {
                'name': 'groundwater_piezometers',
                'description': 'Groundwater level data from 31 sites',
                'size': '850 GB',
                'format': 'CSV',
                'sites': 31,
                'years': '1998-2026'
            },
            {
                'name': 'soil_ec',
                'description': 'Soil electrical conductivity profiles',
                'size': '320 GB',
                'format': 'CSV',
                'sites': 31,
                'years': '1998-2026'
            },
            {
                'name': 'thermal_profiles',
                'description': 'Multi-level temperature data',
                'size': '180 GB',
                'format': 'CSV',
                'sites': 31,
                'years': '1998-2026'
            },
            {
                'name': 'satellite_indices',
                'description': 'Processed satellite vegetation indices',
                'size': '1.2 TB',
                'format': 'GeoTIFF',
                'sites': 31,
                'years': '1998-2026'
            },
            {
                'name': 'biodiversity_surveys',
                'description': 'Annual biodiversity survey data',
                'size': '45 GB',
                'format': 'JSON',
                'sites': 31,
                'years': '1998-2026'
            }
        ]
    
    def download_dataset(self, dataset_name: str,
                        site: Optional[str] = None,
                        year_range: Optional[tuple] = None,
                        output_dir: Optional[str] = None) -> str:
        """
        Download specific dataset
        
        Args:
            dataset_name: Dataset name
            site: Site name filter
            year_range: (start_year, end_year) filter
            output_dir: Output directory
            
        Returns:
            Path to downloaded data
        """
        if output_dir is None:
            output_dir = self.data_dir / dataset_name
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Mock download - would actually download from Zenodo
        info_file = output_path / "info.json"
        with open(info_file, 'w') as f:
            json.dump({
                'dataset': dataset_name,
                'site': site,
                'year_range': year_range,
                'download_date': '2026-02-19',
                'files': ['sample_data.csv']
            }, f, indent=2)
        
        # Create sample data file
        if dataset_name == 'groundwater_piezometers':
            import pandas as pd
            dates = pd.date_range('2020-01-01', '2024-12-31', freq='D')
            df = pd.DataFrame({
                'date': dates,
                'water_level_m': np.random.normal(25, 2, len(dates))
            })
            df.to_csv(output_path / 'sample_data.csv', index=False)
        
        return str(output_path)
    
    def download_site_data(self, site_name: str,
                          output_dir: Optional[str] = None) -> Dict[str, str]:
        """
        Download all data for a specific site
        
        Args:
            site_name: Site name
            output_dir: Output directory
            
        Returns:
            Dictionary mapping dataset -> file path
        """
        if output_dir is None:
            output_dir = self.data_dir / site_name
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        downloaded = {}
        
        # Download each dataset for this site
        datasets = self.list_datasets()
        for ds in datasets:
            ds_path = self.download_dataset(
                ds['name'],
                site=site_name,
                output_dir=output_path / ds['name']
            )
            downloaded[ds['name']] = ds_path
        
        return downloaded
    
    def get_citation(self) -> str:
        """
        Get citation for PALMA dataset
        
        Returns:
            Citation string
        """
        return (
            "Baladi, S., Nassar, L., Al-Rashidi, T., Oufkir, A., & Hamdan, Y. (2026). "
            "PALMA Oasis Monitoring Dataset: 31 sites, 28 years (1998–2026) [Data set]. "
            f"Zenodo. https://doi.org/{self.doi}"
        )
    
    def verify_integrity(self, dataset_path: str) -> bool:
        """
        Verify dataset integrity (checksums)
        
        Args:
            dataset_path: Path to downloaded dataset
            
        Returns:
            True if valid
        """
        # Mock verification
        return True
    
    def __repr__(self) -> str:
        return f"ZenodoClient(doi={self.doi})"
