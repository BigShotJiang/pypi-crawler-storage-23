"""
Base parameter class for all PALMA parameters.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class AlertLevel(Enum):
    """Alert levels for PALMA parameters."""
    EXCELLENT = "EXCELLENT"
    GOOD = "GOOD"
    MODERATE = "MODERATE"
    CRITICAL = "CRITICAL"
    COLLAPSE = "COLLAPSE"


@dataclass
class ParameterResult:
    """Result of a parameter computation."""
    value: float
    normalized: float
    alert_level: AlertLevel
    confidence: float
    metadata: Dict[str, Any]


class BaseParameter(ABC):
    """Abstract base class for all PALMA parameters."""
    
    def __init__(self, **kwargs):
        """Initialize parameter with configuration."""
        self.config = kwargs
        self.name = self.__class__.__name__
        
    @abstractmethod
    def compute(self, data: Any, **kwargs) -> ParameterResult:
        """Compute parameter value from input data."""
        pass
    
    @abstractmethod
    def normalize(self, value: float) -> float:
        """Normalize parameter value to [0,1] scale."""
        pass
    
    def get_alert_level(self, normalized: float) -> AlertLevel:
        """Determine alert level from normalized value."""
        if normalized < 0.25:
            return AlertLevel.EXCELLENT
        elif normalized < 0.45:
            return AlertLevel.GOOD
        elif normalized < 0.65:
            return AlertLevel.MODERATE
        elif normalized < 0.80:
            return AlertLevel.CRITICAL
        else:
            return AlertLevel.COLLAPSE
    
    def validate_input(self, data: Any) -> bool:
        """Validate input data."""
        return True
    
    def __repr__(self) -> str:
        return f"{self.name}(config={self.config})"
