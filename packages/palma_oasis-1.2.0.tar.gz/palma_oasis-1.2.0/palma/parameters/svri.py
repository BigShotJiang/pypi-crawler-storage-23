"""
SVRI: Spectral Vegetation Resilience Index
Equation: SVRI = 0.40·NDVI + 0.25·NDRE + 0.20·SWIR_stress + 0.15·EVI

Anti-correlation with SSSP: ρ = -0.887 (p < 0.001)
Spectral energy transfer: dE_harm/dt = γ·E_fund·(1 - SVRI)
"""

import numpy as np
from typing import Optional, Dict, Any, List
from pathlib import Path

from palma.parameters.base import BaseParameter, ParameterResult, AlertLevel


class SVRI(BaseParameter):
    """
    Spectral Vegetation Resilience Index
    
    Multi-spectral stress indicator combining NDVI, NDRE, SWIR, and EVI.
    Provides 30-90 days advance warning before visible symptoms.
    """
    
    def __init__(self, 
                 weights: Optional[Dict[str, float]] = None,
                 **kwargs):
        super().__init__(**kwargs)
        
        # Default weights from research paper
        self.weights = weights or {
            'ndvi': 0.40,
            'ndre': 0.25,
            'swir': 0.20,
            'evi': 0.15
        }
        
        self.gamma = kwargs.get('gamma', 0.12)  # Energy transfer coefficient
        
    def compute(self, data: Optional[Dict] = None, **kwargs) -> ParameterResult:
        """
        Compute SVRI from spectral indices
        
        Args:
            data: Spectral indices or band reflectances
            
        Returns:
            ParameterResult with SVRI value and alert level
        """
        # Extract or calculate indices
        if data and 'indices' in data:
            ndvi = data['indices'].get('ndvi', 0.65)
            ndre = data['indices'].get('ndre', 0.45)
            swir = data['indices'].get('swir_stress', 0.30)
            evi = data['indices'].get('evi', 0.55)
        else:
            # Calculate from bands if provided
            if data and 'bands' in data:
                bands = data['bands']
                ndvi = self._calculate_ndvi(bands)
                ndre = self._calculate_ndre(bands)
                swir = self._calculate_swir_stress(bands)
                evi = self._calculate_evi(bands)
            else:
                # Default values from paper
                ndvi = kwargs.get('ndvi', 0.65)
                ndre = kwargs.get('ndre', 0.45)
                swir = kwargs.get('swir_stress', 0.30)
                evi = kwargs.get('evi', 0.55)
        
        # Weighted composite
        svri_value = (
            self.weights['ndvi'] * ndvi +
            self.weights['ndre'] * ndre +
            self.weights['swir'] * (1 - swir) +  # SWIR stress inverted (higher = more stress)
            self.weights['evi'] * evi
        )
        
        # Clip to valid range
        svri_value = np.clip(svri_value, 0.0, 1.0)
        
        # Calculate energy transfer to stress harmonics
        if 'previous_svri' in kwargs:
            prev_svri = kwargs['previous_svri']
            dt = kwargs.get('dt', 30)  # days
            e_fund = kwargs.get('e_fundamental', 1.0)
            
            de_dt = self.gamma * e_fund * (1 - svri_value)
            stress_energy = prev_svri - svri_value + de_dt * dt
        else:
            stress_energy = 1.0 - svri_value
        
        # Normalize
        normalized = self.normalize(svri_value)
        
        # Alert level
        alert_level = self.get_alert_level(normalized)
        
        return ParameterResult(
            value=float(svri_value),
            normalized=float(normalized),
            alert_level=alert_level,
            confidence=0.92,
            metadata={
                'ndvi': float(ndvi),
                'ndre': float(ndre),
                'swir_stress': float(swir),
                'evi': float(evi),
                'stress_energy': float(stress_energy),
                'weights': self.weights
            }
        )
    
    def normalize(self, value: float) -> float:
        """
        Normalize SVRI to [0,1] scale where 0 is healthy, 1 is stressed
        
        SVRI > 0.70 → EXCELLENT (0.0)
        SVRI < 0.25 → COLLAPSE (1.0)
        """
        if value >= 0.70:
            return 0.0
        elif value <= 0.25:
            return 1.0
        else:
            return (0.70 - value) / (0.70 - 0.25)
    
    def _calculate_ndvi(self, bands: Dict[str, float]) -> float:
        """NDVI = (NIR - Red) / (NIR + Red)"""
        nir = bands.get('B08', bands.get('nir', 0.4))
        red = bands.get('B04', bands.get('red', 0.1))
        
        if nir + red == 0:
            return 0
        return (nir - red) / (nir + red)
    
    def _calculate_ndre(self, bands: Dict[str, float]) -> float:
        """NDRE = (RE1 - Red) / (RE1 + Red)"""
        re1 = bands.get('B05', bands.get('red_edge', 0.3))
        red = bands.get('B04', bands.get('red', 0.1))
        
        if re1 + red == 0:
            return 0
        return (re1 - red) / (re1 + red)
    
    def _calculate_swir_stress(self, bands: Dict[str, float]) -> float:
        """SWIR stress index = (NIR - SWIR) / (NIR + SWIR)"""
        nir = bands.get('B08', bands.get('nir', 0.4))
        swir = bands.get('B11', bands.get('swir', 0.2))
        
        if nir + swir == 0:
            return 0
        stress = (nir - swir) / (nir + swir)
        return max(0, stress)  # Higher = less stress
    
    def _calculate_evi(self, bands: Dict[str, float]) -> float:
        """Enhanced Vegetation Index"""
        nir = bands.get('B08', bands.get('nir', 0.4))
        red = bands.get('B04', bands.get('red', 0.1))
        blue = bands.get('B02', bands.get('blue', 0.05))
        
        # EVI = 2.5 * ((NIR - Red) / (NIR + 6*Red - 7.5*Blue + 1))
        numerator = nir - red
        denominator = nir + 6*red - 7.5*blue + 1
        
        if denominator == 0:
            return 0
        return 2.5 * numerator / denominator
