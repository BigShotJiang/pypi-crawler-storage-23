"""
SSSP: Soil Salinity Stress Parameter
"""

import numpy as np
from typing import Optional, Dict, Any

from palma.parameters.base import BaseParameter, ParameterResult, AlertLevel


class SSSP(BaseParameter):
    """Soil Salinity Stress Parameter"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ec_critical = kwargs.get('ec_critical', 8.4)
        self.ec_baseline = kwargs.get('ec_baseline', 1.2)
        
    def compute(self, data: Any = None, **kwargs) -> ParameterResult:
        """Compute SSSP from data"""
        # Get EC values from kwargs or use defaults
        ec_values = kwargs.get('ec_values', [2.1, 3.4, 4.2, 5.1])
        
        # Calculate average EC
        ec_obs = np.mean(ec_values)
        
        # Calculate SSSP
        value = (ec_obs - self.ec_baseline) / (self.ec_critical - self.ec_baseline)
        value = np.clip(value, 0.0, 1.0)
        
        normalized = self.normalize(value)
        alert_level = self.get_alert_level(normalized)
        
        return ParameterResult(
            value=float(value),
            normalized=float(normalized),
            alert_level=alert_level,
            confidence=0.9,
            metadata={
                'ec_observed': float(ec_obs),
                'osmotic_potential': -0.036 * ec_obs
            }
        )
    
    def normalize(self, value: float) -> float:
        """Normalize SSSP value"""
        return min(value, 1.0)
