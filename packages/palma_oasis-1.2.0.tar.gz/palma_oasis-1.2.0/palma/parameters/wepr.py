"""
WEPR: Water-Energy Partition Ratio
Equation: WEPR = ET_c / ET_total = T_plant / (T_plant + E_soil)

Energy balance: R_n = H + LE + G
Bowen ratio: β = H/LE (oasis: 0.18-0.42, desert: 4-15)
"""

import numpy as np
from typing import Optional, Dict, Any

from palma.parameters.base import BaseParameter, ParameterResult, AlertLevel


class WEPR(BaseParameter):
    """
    Water-Energy Partition Ratio
    
    Characterizes water use efficiency in oasis systems.
    Healthy oasis: WEPR = 0.65-0.82
    Degraded oasis: WEPR < 0.40
    """
    
    def __init__(self, productive_fraction: float = 0.75, **kwargs):
        super().__init__(**kwargs)
        self.productive_fraction = productive_fraction
        
    def compute(self, data: Optional[Dict] = None, **kwargs) -> ParameterResult:
        """
        Compute WEPR from evapotranspiration partitioning
        
        Args:
            data: ET partitioning data or energy balance measurements
            
        Returns:
            ParameterResult with WEPR value and alert level
        """
        # Extract ET components
        if data and 'et' in data:
            et_total = data['et'].get('total', 1200)
            et_transpiration = data['et'].get('transpiration', 840)
            et_evaporation = data['et'].get('evaporation', 360)
        else:
            et_total = kwargs.get('et_total', 1200)  # mm/year
            et_transpiration = kwargs.get('et_transpiration', 840)
            et_evaporation = kwargs.get('et_evaporation', 360)
        
        # Calculate WEPR
        if et_total > 0:
            wepr_value = et_transpiration / et_total
        else:
            wepr_value = 0.5
        
        # Calculate Bowen ratio if energy data available
        if data and 'energy' in data:
            h = data['energy'].get('sensible_heat', 100)
            le = data['energy'].get('latent_heat', 300)
            
            if le > 0:
                bowen_ratio = h / le
            else:
                bowen_ratio = float('inf')
        else:
            bowen_ratio = kwargs.get('bowen_ratio', 0.30)
        
        # Water balance components
        precipitation = kwargs.get('precipitation', 50)
        irrigation = kwargs.get('irrigation', 1150)
        drainage = kwargs.get('drainage', 100)
        storage_change = kwargs.get('storage_change', 0)
        
        # Verify water balance
        water_balance = (precipitation + irrigation) - (et_total + drainage + storage_change)
        
        # Normalize
        normalized = self.normalize(wepr_value)
        
        # Alert level
        alert_level = self.get_alert_level(normalized)
        
        return ParameterResult(
            value=float(wepr_value),
            normalized=float(normalized),
            alert_level=alert_level,
            confidence=0.85,
            metadata={
                'et_total': float(et_total),
                'et_transpiration': float(et_transpiration),
                'et_evaporation': float(et_evaporation),
                'bowen_ratio': float(bowen_ratio) if bowen_ratio != float('inf') else None,
                'water_balance': float(water_balance),
                'irrigation_efficiency': float(et_transpiration / irrigation) if irrigation > 0 else 0
            }
        )
    
    def normalize(self, value: float) -> float:
        """
        Normalize WEPR to [0,1] scale
        
        WEPR > 0.75 → EXCELLENT (0.0)
        WEPR < 0.30 → COLLAPSE (1.0)
        """
        if value >= 0.75:
            return 0.0
        elif value <= 0.30:
            return 1.0
        else:
            return (0.75 - value) / (0.75 - 0.30)
    
    def estimate_from_bowen(self, bowen_ratio: float) -> float:
        """
        Estimate WEPR from Bowen ratio
        
        β = H/LE, and LE ≈ λ·ET
        For well-watered vegetation, β ≈ 0.2-0.4
        """
        if bowen_ratio <= 0:
            return 0.8
        
        # Empirical relationship
        wepr = 0.8 * np.exp(-0.5 * bowen_ratio)
        return np.clip(wepr, 0.2, 0.9)
    
    def calculate_irrigation_requirement(self, 
                                         target_wepr: float,
                                         current_et: float,
                                         rainfall: float) -> float:
        """
        Calculate irrigation needed to maintain target WEPR
        """
        if target_wepr <= 0:
            return 0
        
        # Desired transpiration
        desired_transpiration = target_wepr * current_et
        
        # Account for rainfall contribution to transpiration
        rainfall_effective = rainfall * 0.7  # 70% effective
        
        irrigation_needed = max(0, desired_transpiration - rainfall_effective)
        
        return irrigation_needed
