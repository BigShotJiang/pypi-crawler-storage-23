"""
BST: Biodiversity Stability Threshold
Equation: BST = 1 - [H'_obs / H'_ref]

Shannon diversity index: H' = -Σ pᵢ·ln(pᵢ)
Collapse probability: P_collapse(t) = 1 - exp[-(BST/BST_crit)^β · t/T_ref]
BST_crit = 0.60, β = 1.73, T_ref = 5 years
"""

import numpy as np
from typing import Optional, Dict, Any, List
from pathlib import Path

from palma.parameters.base import BaseParameter, ParameterResult, AlertLevel


class BST(BaseParameter):
    """
    Biodiversity Stability Threshold
    
    Tracks biodiversity loss relative to reference state.
    Based on Shannon diversity index from annual surveys.
    """
    
    def __init__(self, 
                 collapse_threshold: float = 0.60,
                 collapse_exponent: float = 1.73,
                 time_reference: float = 5.0,
                 **kwargs):
        super().__init__(**kwargs)
        self.collapse_threshold = collapse_threshold  # BST_crit
        self.collapse_exponent = collapse_exponent  # β
        self.time_reference = time_reference  # T_ref (years)
        
    def compute(self, data: Optional[Dict] = None, **kwargs) -> ParameterResult:
        """
        Compute BST from biodiversity survey data
        
        Args:
            data: Species abundance data or diversity indices
            
        Returns:
            ParameterResult with BST value and alert level
        """
        # Extract or calculate Shannon diversity
        if data and 'shannon' in data:
            h_obs = data['shannon']['observed']
            h_ref = data['shannon'].get('reference', 2.5)
        else:
            # Calculate from species abundances
            if data and 'species' in data:
                abundances = data['species']
                h_obs = self._calculate_shannon(abundances)
                h_ref = data.get('reference_diversity', 2.5)
            else:
                # Default values from paper
                h_obs = kwargs.get('shannon_observed', 1.8)
                h_ref = kwargs.get('shannon_reference', 2.5)
        
        # Calculate BST
        bst_value = 1 - (h_obs / h_ref)
        bst_value = np.clip(bst_value, 0.0, 1.0)
        
        # Calculate collapse probability
        time_horizon = kwargs.get('time_horizon', 5)  # years
        collapse_prob = self._calculate_collapse_probability(bst_value, time_horizon)
        
        # Calculate species loss rate
        if 'historical' in kwargs:
            historical = kwargs['historical']
            years = kwargs.get('years', 10)
            loss_rate = (historical - h_obs) / years
        else:
            loss_rate = 0.02  # Default 2% per year
        
        # Normalize (BST is already 0-1)
        normalized = bst_value
        
        # Alert level
        alert_level = self.get_alert_level(normalized)
        
        return ParameterResult(
            value=float(bst_value),
            normalized=float(normalized),
            alert_level=alert_level,
            confidence=0.82,
            metadata={
                'shannon_observed': float(h_obs),
                'shannon_reference': float(h_ref),
                'collapse_probability': float(collapse_prob),
                'species_loss_rate': float(loss_rate),
                'time_to_collapse': self._time_to_collapse(bst_value)
            }
        )
    
    def normalize(self, value: float) -> float:
        """
        BST is already normalized to [0,1]
        """
        return value
    
    def _calculate_shannon(self, abundances: List[float]) -> float:
        """Calculate Shannon diversity index H' = -Σ pᵢ·ln(pᵢ)"""
        total = sum(abundances)
        if total == 0:
            return 0
        
        proportions = [a / total for a in abundances if a > 0]
        
        shannon = -sum(p * np.log(p) for p in proportions)
        return shannon
    
    def _calculate_collapse_probability(self, bst: float, years: float) -> float:
        """
        P_collapse(t) = 1 - exp[-(BST/BST_crit)^β · t/T_ref]
        """
        if bst <= 0:
            return 0
        
        ratio = bst / self.collapse_threshold
        exponent = (ratio ** self.collapse_exponent) * (years / self.time_reference)
        
        probability = 1 - np.exp(-exponent)
        return np.clip(probability, 0, 1)
    
    def _time_to_collapse(self, bst: float) -> float:
        """
        Estimate years until ecosystem collapse
        """
        if bst >= self.collapse_threshold:
            return 0
        
        # Solve for t when probability = 0.5
        target_prob = 0.5
        
        # t = -T_ref * ln(1-p) / (BST/BST_crit)^β
        ratio = bst / self.collapse_threshold
        if ratio <= 0:
            return float('inf')
        
        time = -self.time_reference * np.log(1 - target_prob) / (ratio ** self.collapse_exponent)
        return max(0, time)
    
    def estimate_from_ndvi(self, ndvi: float, ndvi_ref: float = 0.7) -> float:
        """
        Rough BST estimate from NDVI (for sites without biodiversity data)
        """
        # Empirical relationship from paper
        bst_estimate = 1.2 * (1 - ndvi / ndvi_ref)
        return np.clip(bst_estimate, 0, 1)
