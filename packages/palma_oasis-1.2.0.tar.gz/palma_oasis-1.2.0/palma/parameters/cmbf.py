"""
CMBF: Canopy Microclimate Buffering Factor
Equation: CMBF = w_T·(ΔT/ΔT_ref) + w_H·(ΔRH/ΔRH_ref) + w_V·(ΔWS/ΔWS_ref) + w_VPD·(ΔVPD/ΔVPD_ref)

Weights: w_T=0.35, w_H=0.28, w_V=0.18, w_VPD=0.19
Wind reduction: U_z(oasis) = U_ref·exp(-a·LAI·z/h) with a=0.8
"""

import numpy as np
from typing import Optional, Dict, Any

from palma.parameters.base import BaseParameter, ParameterResult, AlertLevel


class CMBF(BaseParameter):
    """
    Canopy Microclimate Buffering Factor
    
    Integrates temperature, humidity, wind, and VPD modification.
    Validated across 31 sites with 4-layer microclimate stations.
    """
    
    def __init__(self, 
                 weights: Optional[Dict[str, float]] = None,
                 reference_values: Optional[Dict[str, float]] = None,
                 **kwargs):
        super().__init__(**kwargs)
        
        # Default weights from research paper
        self.weights = weights or {
            'temperature': 0.35,
            'humidity': 0.28,
            'wind': 0.18,
            'vpd': 0.19
        }
        
        # Reference values for normalization
        self.reference_values = reference_values or {
            'delta_t_ref': 11.4,  # °C (mean shielding)
            'delta_rh_ref': 25.0,  # % humidity increase
            'delta_ws_ref': 4.5,   # m/s wind reduction
            'delta_vpd_ref': 2.0    # kPa VPD reduction
        }
        
    def compute(self, data: Optional[Dict] = None, **kwargs) -> ParameterResult:
        """
        Compute CMBF from microclimate data
        
        Args:
            data: Microclimate measurements (oasis and desert)
            
        Returns:
            ParameterResult with CMBF value and alert level
        """
        # Extract measurements
        if data:
            oasis = data.get('oasis', {})
            desert = data.get('desert', {})
        else:
            # Default values from paper
            oasis = kwargs.get('oasis', {
                'temperature': 33.6,
                'humidity': 45.0,
                'wind_speed': 0.8,
                'vpd': 1.2
            })
            desert = kwargs.get('desert', {
                'temperature': 45.0,
                'humidity': 20.0,
                'wind_speed': 5.2,
                'vpd': 3.5
            })
        
        # Calculate deltas
        delta_t = desert['temperature'] - oasis['temperature']
        delta_rh = oasis['humidity'] - desert['humidity']
        delta_ws = desert.get['wind_speed'] - oasis['wind_speed']

        delta_vpd = desert.get('vpd', 3.5) - oasis.get('vpd', 1.2)
        
        # Normalize by reference values
        t_norm = delta_t / self.reference_values['delta_t_ref']
        rh_norm = delta_rh / self.reference_values['delta_rh_ref']
        ws_norm = delta_ws / self.reference_values['delta_ws_ref']
        vpd_norm = delta_vpd / self.reference_values['delta_vpd_ref']
        
        # Clip to reasonable range
        t_norm = np.clip(t_norm, 0, 2)
        rh_norm = np.clip(rh_norm, 0, 2)
        ws_norm = np.clip(ws_norm, 0, 2)
        vpd_norm = np.clip(vpd_norm, 0, 2)
        
        # Weighted composite
        cmbf_value = (
            self.weights['temperature'] * t_norm +
            self.weights['humidity'] * rh_norm +
            self.weights['wind'] * ws_norm +
            self.weights['vpd'] * vpd_norm
        )
        
        # Apply wind reduction model if LAI provided
        if 'leaf_area_index' in kwargs:
            lai = kwargs['leaf_area_index']
            height = kwargs.get('measurement_height', 1.5)
            canopy_height = kwargs.get('canopy_height', 6.0)
            
            # U_z = U_ref·exp(-a·LAI·z/h)
            a = 0.8  # empirical coefficient
            wind_reduction = np.exp(-a * lai * height / canopy_height)
            ws_norm *= wind_reduction
            
        # Normalize to [0,1] scale for alert levels
        normalized = self.normalize(cmbf_value)
        
        # Alert level
        alert_level = self.get_alert_level(normalized)
        
        return ParameterResult(
            value=float(cmbf_value),
            normalized=float(normalized),
            alert_level=alert_level,
            confidence=0.87,
            metadata={
                'delta_t': float(delta_t),
                'delta_rh': float(delta_rh),
                'delta_ws': float(delta_ws),
                'delta_vpd': float(delta_vpd),
                't_norm': float(t_norm),
                'rh_norm': float(rh_norm),
                'ws_norm': float(ws_norm),
                'vpd_norm': float(vpd_norm),
                'weights': self.weights
            }
        )
    
    def normalize(self, value: float) -> float:
        """
        Normalize CMBF to [0,1] scale
        
        CMBF > 0.80 → EXCELLENT (0.0)
        CMBF < 0.35 → COLLAPSE (1.0)
        """
        if value >= 0.80:
            return 0.0
        elif value <= 0.35:
            return 1.0
        else:
            return (0.80 - value) / (0.80 - 0.35)
    
    def calculate_vpd(self, temperature: float, humidity: float) -> float:
        """
        Calculate Vapor Pressure Deficit (kPa)
        
        VPD = es - ea
        es = 0.6108 * exp(17.27*T/(T+237.3))
        """
        # Saturation vapor pressure (kPa)
        es = 0.6108 * np.exp(17.27 * temperature / (temperature + 237.3))
        
        # Actual vapor pressure
        ea = es * (humidity / 100)
        
        return es - ea
