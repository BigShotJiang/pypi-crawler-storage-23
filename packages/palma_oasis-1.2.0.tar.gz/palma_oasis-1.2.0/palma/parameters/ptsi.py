"""
PTSI: Phyto-Thermal Shielding Index
"""

import numpy as np
from typing import Optional, Dict, Any

from palma.parameters.base import BaseParameter, ParameterResult, AlertLevel


class PTSI(BaseParameter):
    """Phyto-Thermal Shielding Index"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.k_extinction = kwargs.get('k_extinction', 0.52)
        
    def compute(self, data: Any = None, **kwargs) -> ParameterResult:
        """Compute PTSI from data"""
        # Get temperatures from kwargs or use defaults
        t_ambient = kwargs.get('t_ambient', 45.0)
        t_subcanopy = kwargs.get('t_subcanopy', 33.6)
        
        # Calculate PTSI
        value = (t_ambient - t_subcanopy) / t_ambient * 100
        
        normalized = self.normalize(value)
        alert_level = self.get_alert_level(normalized)
        
        return ParameterResult(
            value=float(value),
            normalized=float(normalized),
            alert_level=alert_level,
            confidence=0.9,
            metadata={
                't_ambient': t_ambient,
                't_subcanopy': t_subcanopy,
                'delta_t': t_ambient - t_subcanopy
            }
        )
    
    def normalize(self, value: float) -> float:
        """Normalize PTSI value"""
        if value >= 28.0:
            return 0.0
        elif value <= 10.0:
            return 1.0
        else:
            return (28.0 - value) / (28.0 - 10.0)
