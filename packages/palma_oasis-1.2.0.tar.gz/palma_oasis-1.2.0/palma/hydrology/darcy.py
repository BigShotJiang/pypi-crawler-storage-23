"""
Darcy flow and Richards equation solvers for unsaturated flow

Based on van Genuchten-Mualem model for hydraulic conductivity
K(θ) = K_sat·(θ/θ_sat)^n where n is pore-size distribution parameter
"""

import numpy as np
from typing import Optional, Tuple, Dict, Any, Callable
from scipy.integrate import odeint, solve_ivp
from scipy.optimize import fsolve, root
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
import warnings


class DarcyFlow:
    """
    Darcy flow calculator for saturated/unsaturated conditions
    
    Implements: V = -K(dh/dl)
    """
    
    def __init__(self, hydraulic_conductivity: float = 12.4):
        """
        Initialize Darcy flow model
        
        Args:
            hydraulic_conductivity: K_sat in m/d
        """
        self.k_sat = hydraulic_conductivity
        
    def velocity(self, head_gradient: float, 
                 saturation: float = 1.0,
                 **kwargs) -> float:
        """
        Compute Darcy velocity
        
        Args:
            head_gradient: dh/dl
            saturation: Relative saturation (0-1)
            **kwargs: Additional parameters
            
        Returns:
            Darcy velocity (m/d)
        """
        # Unsaturated conductivity reduction
        if saturation < 1.0:
            k_unsat = self._unsaturated_conductivity(saturation, **kwargs)
        else:
            k_unsat = self.k_sat
        
        return -k_unsat * head_gradient
    
    def _unsaturated_conductivity(self, saturation: float,
                                   n: float = 2.11,
                                   **kwargs) -> float:
        """
        van Genuchten-Mualem unsaturated conductivity
        
        K(θ) = K_sat·(θ/θ_sat)^n
        n = pore-size distribution parameter (mean 2.11 from paper)
        """
        return self.k_sat * (saturation ** n)
    
    def flux(self, area: float, head_gradient: float,
             saturation: float = 1.0) -> float:
        """Compute total flux (m³/d)"""
        v = self.velocity(head_gradient, saturation)
        return v * area
    
    def travel_time(self, distance: float, head_gradient: float,
                   saturation: float = 1.0) -> float:
        """Compute travel time over distance (days)"""
        v = self.velocity(head_gradient, saturation)
        if v <= 0:
            return float('inf')
        return distance / abs(v)
    
    def hydraulic_head(self, elevation: float, pressure_head: float) -> float:
        """Calculate total hydraulic head"""
        return elevation + pressure_head
    
    def gradient(self, head1: float, head2: float, distance: float) -> float:
        """Calculate hydraulic gradient between two points"""
        if distance == 0:
            return 0
        return (head2 - head1) / distance


class RichardsEquation:
    """
    1D Richards equation solver for unsaturated flow
    
    ∂θ/∂t = ∂/∂z[K(θ)·(∂ψ/∂z + 1)] - S_root
    
    Full implementation with numerical solvers for transient and steady states
    """
    
    def __init__(self, depth: float = 2.0, n_nodes: int = 100):
        """
        Initialize Richards equation solver
        
        Args:
            depth: Soil profile depth (m)
            n_nodes: Number of spatial nodes
        """
        self.depth = depth
        self.n_nodes = n_nodes
        self.z = np.linspace(0, depth, n_nodes)
        self.dz = depth / (n_nodes - 1)
        
        # van Genuchten parameters (typical for oasis soils)
        self.theta_sat = 0.45  # Saturated water content
        self.theta_res = 0.05  # Residual water content
        self.alpha_vg = 1.5    # van Genuchten α (1/m)
        self.n_vg = 2.11       # van Genuchten n (pore-size distribution)
        self.m_vg = 1 - 1/self.n_vg  # m parameter
        self.k_sat = 12.4      # Saturated conductivity (m/d)
        
        # Soil compressibility (optional)
        self.specific_storage = 1e-5  # 1/m
        
    def water_content(self, pressure_head: np.ndarray) -> np.ndarray:
        """
        van Genuchten water retention curve
        
        θ(ψ) = θ_res + (θ_sat - θ_res) / [1 + (α|ψ|)^n]^m
        where m = 1 - 1/n
        """
        # Convert to positive suction
        suction = np.maximum(-pressure_head, 0)
        
        # van Genuchten formula
        denominator = (1 + (self.alpha_vg * suction) ** self.n_vg) ** self.m_vg
        theta = self.theta_res + (self.theta_sat - self.theta_res) / denominator
        
        # Ensure within bounds
        return np.clip(theta, self.theta_res, self.theta_sat)
    
    def pressure_head(self, theta: np.ndarray) -> np.ndarray:
        """
        Inverse van Genuchten: compute pressure head from water content
        
        ψ(θ) = - (1/α) · [( (θ - θ_res)/(θ_sat - θ_res) )^(-1/m) - 1]^(1/n)
        """
        theta_eff = (theta - self.theta_res) / (self.theta_sat - self.theta_res)
        theta_eff = np.clip(theta_eff, 0.001, 0.999)
        
        psi = - (1/self.alpha_vg) * (theta_eff ** (-1/self.m_vg) - 1) ** (1/self.n_vg)
        
        return psi
    
    def hydraulic_conductivity(self, theta: np.ndarray) -> np.ndarray:
        """
        van Genuchten-Mualem hydraulic conductivity
        
        K(θ) = K_sat · (θ_eff)^0.5 · [1 - (1 - θ_eff^(1/m))^m]^2
        where θ_eff = (θ - θ_res)/(θ_sat - θ_res)
        """
        theta_eff = (theta - self.theta_res) / (self.theta_sat - self.theta_res)
        theta_eff = np.clip(theta_eff, 0, 1)
        
        # Mualem's model
        term1 = theta_eff ** 0.5
        term2 = (1 - (1 - theta_eff ** (1/self.m_vg)) ** self.m_vg) ** 2
        
        return self.k_sat * term1 * term2
    
    def specific_capacity(self, pressure_head: np.ndarray) -> np.ndarray:
        """
        Specific moisture capacity C(ψ) = dθ/dψ
        
        Used in pressure head-based Richards equation
        """
        suction = np.maximum(-pressure_head, 1e-6)
        
        # Derivative of van Genuchten function
        dtheta_dpsi = - (self.theta_sat - self.theta_res) * self.m_vg * self.n_vg * \
                      self.alpha_vg ** self.n_vg * suction ** (self.n_vg - 1) / \
                      ((1 + (self.alpha_vg * suction) ** self.n_vg) ** (self.m_vg + 1))
        
        # Ensure non-negative
        return np.maximum(dtheta_dpsi, 1e-10)
    
    def solve_steady(self, bottom_flux: float = 0.0,
                    root_uptake: Optional[np.ndarray] = None,
                    top_pressure: float = 0.0) -> Dict[str, Any]:
        """
        Solve steady-state Richards equation
        
        ∂/∂z[K(θ)·(∂ψ/∂z + 1)] = S_root
        
        Args:
            bottom_flux: Bottom boundary flux (m/d), positive upward
            root_uptake: Root water uptake array (1/d)
            top_pressure: Top boundary pressure head (m)
            
        Returns:
            Dictionary with solution
        """
        from scipy.integrate import solve_bvp
        
        if root_uptake is None:
            root_uptake = np.zeros(self.n_nodes)
        
        def ode(z, y):
            """y[0] = pressure head, y[1] = flux"""
            psi, q = y
            
            # Current water content
            theta = self.water_content(np.array([psi]))[0]
            k = self.hydraulic_conductivity(np.array([theta]))[0]
            
            # Handle near-zero conductivity
            if k < 1e-12:
                k = 1e-12
            
            # Derivatives
            dpsi_dz = q/k - 1
            
            # Find index for root uptake
            idx = int(z/self.depth * (self.n_nodes-1))
            idx = min(idx, self.n_nodes-1)
            idx = max(idx, 0)
            
            dq_dz = -root_uptake[idx]
            
            return [dpsi_dz, dq_dz]
        
        def bc(ya, yb):
            # Bottom boundary (z=0): q = bottom_flux
            # Top boundary (z=depth): psi = top_pressure
            return [ya[1] - bottom_flux, yb[0] - top_pressure]
        
        # Initial guess
        z_mesh = self.z
        y_init = np.zeros((2, self.n_nodes))
        
        # Linear pressure gradient from top to bottom
        y_init[0] = top_pressure - np.linspace(0, 2, self.n_nodes)
        
        # Initial flux guess (constant)
        y_init[1] = np.ones(self.n_nodes) * bottom_flux
        
        # Solve
        try:
            sol = solve_bvp(ode, bc, z_mesh, y_init, max_nodes=5000, tol=1e-6)
            
            if not sol.success:
                return {
                    'success': False, 
                    'message': sol.message,
                    'pressure_head': y_init[0],
                    'flux': y_init[1]
                }
            
            psi = sol.y[0]
            q = sol.y[1]
            theta = self.water_content(psi)
            k = self.hydraulic_conductivity(theta)
            
            # Calculate total head
            total_head = psi + self.z
            
            return {
                'success': True,
                'pressure_head': psi,
                'flux': q,
                'water_content': theta,
                'conductivity': k,
                'total_head': total_head,
                'z': sol.x,
                'root_uptake': root_uptake
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': str(e),
                'pressure_head': y_init[0],
                'flux': y_init[1],
                'z': self.z
            }
    
    def solve_transient(self, initial_pressure: np.ndarray,
                        dt: float, n_steps: int,
                        bottom_flux: float = 0.0,
                        root_uptake_func: Optional[Callable] = None,
                        surface_flux: Optional[Callable] = None,
                        **kwargs) -> Dict[str, Any]:
        """
        Solve transient Richards equation using implicit Euler
        
        Args:
            initial_pressure: Initial pressure head profile
            dt: Time step (days)
            n_steps: Number of time steps
            bottom_flux: Bottom boundary flux (m/d)
            root_uptake_func: Function of (t, z) returning root uptake
            surface_flux: Function of (t) returning surface flux
            
        Returns:
            Dictionary with time series solutions
        """
        # Initialize arrays
        n_nodes = self.n_nodes
        pressure = np.zeros((n_steps + 1, n_nodes))
        pressure[0] = initial_pressure
        
        water_content = np.zeros((n_steps + 1, n_nodes))
        water_content[0] = self.water_content(initial_pressure)
        
        flux = np.zeros((n_steps + 1, n_nodes))
        
        # Time stepping
        for n in range(n_steps):
            t = n * dt
            
            # Get current root uptake
            if root_uptake_func is not None:
                S_root = root_uptake_func(t, self.z)
            else:
                S_root = np.zeros(n_nodes)
            
            # Get surface flux
            if surface_flux is not None:
                q_surface = surface_flux(t)
            else:
                q_surface = 0.0
            
            # Solve for new pressure using Newton iteration
            psi_n = pressure[n].copy()
            psi_np1 = psi_n.copy()
            
            for newton_iter in range(10):
                # Compute hydraulic properties at current estimate
                theta_np1 = self.water_content(psi_np1)
                k_np1 = self.hydraulic_conductivity(theta_np1)
                c_np1 = self.specific_capacity(psi_np1)
                
                # Build matrix for implicit Euler
                # C·(ψ^{n+1} - ψ^n)/dt = ∂/∂z[K(∂ψ/∂z + 1)] - S_root
                
                # Flux terms
                # K_{i+1/2} ≈ (K_i + K_{i+1})/2
                k_half = np.zeros(n_nodes + 1)
                k_half[1:-1] = (k_np1[:-1] + k_np1[1:]) / 2
                k_half[0] = k_np1[0]  # Bottom boundary
                k_half[-1] = k_np1[-1]  # Top boundary
                
                # Build coefficient matrix (tridiagonal)
                main_diag = np.zeros(n_nodes)
                upper_diag = np.zeros(n_nodes - 1)
                lower_diag = np.zeros(n_nodes - 1)
                
                # Interior nodes
                for i in range(1, n_nodes - 1):
                    # d/dz term: (K_{i+1/2}(ψ_{i+1}-ψ_i) - K_{i-1/2}(ψ_i-ψ_{i-1}))/dz^2
                    # + (K_{i+1/2} - K_{i-1/2})/dz
                    
                    # Coefficients for ψ_{i-1}, ψ_i, ψ_{i+1}
                    lower_diag[i-1] = -k_half[i] / self.dz**2
                    upper_diag[i] = -k_half[i+1] / self.dz**2
                    main_diag[i] = c_np1[i] / dt + (k_half[i] + k_half[i+1]) / self.dz**2
                
                # Bottom boundary (z=0)
                # Flux boundary: q = -K(∂ψ/∂z + 1) = bottom_flux
                # => (ψ_1 - ψ_0)/dz = -bottom_flux/K_0 - 1
                i = 0
                main_diag[i] = 1.0
                upper_diag[i] = -1.0
                
                # Top boundary (z=depth)
                # Flux boundary: q = surface_flux
                i = n_nodes - 1
                main_diag[i] = 1.0
                lower_diag[i-1] = -1.0
                
                # Build RHS
                rhs = np.zeros(n_nodes)
                
                # Interior nodes
                for i in range(1, n_nodes - 1):
                    rhs[i] = c_np1[i] * psi_n[i] / dt - S_root[i] - \
                             (k_half[i+1] - k_half[i]) / self.dz
                
                # Bottom boundary
                rhs[0] = -self.dz * (bottom_flux / k_np1[0] + 1)
                
                # Top boundary
                rhs[-1] = self.dz * (q_surface / k_np1[-1] - 1)
                
                # Solve linear system
                from scipy.sparse import diags
                from scipy.sparse.linalg import spsolve
                
                diagonals = [main_diag, upper_diag, lower_diag]
                A = diags(diagonals, [0, 1, -1], format='csr')
                
                try:
                    psi_new = spsolve(A, rhs)
                except:
                    # Fall back to dense solver
                    A_dense = np.diag(main_diag) + np.diag(upper_diag, 1) + np.diag(lower_diag, -1)
                    psi_new = np.linalg.solve(A_dense, rhs)
                
                # Check convergence
                change = np.max(np.abs(psi_new - psi_np1))
                psi_np1 = psi_new
                
                if change < 1e-6:
                    break
            
            # Store results
            pressure[n+1] = psi_np1
            water_content[n+1] = self.water_content(psi_np1)
            
            # Compute fluxes
            theta = water_content[n+1]
            k = self.hydraulic_conductivity(theta)
            
            for i in range(1, n_nodes):
                flux[n+1, i] = -k[i] * ((pressure[n+1, i] - pressure[n+1, i-1]) / self.dz + 1)
            flux[n+1, 0] = bottom_flux
        
        # Calculate cumulative terms
        cumulative_flux = np.cumsum(flux[:, -1]) * dt
        
        return {
            'success': True,
            'pressure': pressure,
            'water_content': water_content,
            'flux': flux,
            'cumulative_flux': cumulative_flux,
            'z': self.z,
            't': np.arange(n_steps + 1) * dt,
            'n_steps': n_steps,
            'dt': dt
        }
    
    def root_uptake_profile(self, root_depth: float = 0.5,
                           stress_factor: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Generate root water uptake profile
        
        S_root(z) = α(ψ)·S_p·b(z)
        where b(z) is root density distribution
        
        Args:
            root_depth: Characteristic root depth (m)
            stress_factor: Water stress factor α(ψ) (0-1)
            
        Returns:
            Normalized root uptake distribution
        """
        # Exponential root distribution (common for crops)
        b = np.exp(-self.z / root_depth)
        
        # Normalize so integral equals 1
        b = b / np.trapz(b, self.z)
        
        # Apply stress factor if provided
        if stress_factor is not None:
            b = b * stress_factor
        
        return b
    
    def feddes_stress(self, pressure_head: np.ndarray) -> np.ndarray:
        """
        Feddes water stress reduction function
        
        α(ψ) = 0 for ψ > ψ1 (too wet)
        α(ψ) = linear decrease for ψ1 > ψ > ψ2
        α(ψ) = 1 for ψ2 > ψ > ψ3 (optimal)
        α(ψ) = linear decrease for ψ3 > ψ > ψ4
        α(ψ) = 0 for ψ < ψ4 (too dry)
        
        Typical values for date palm (m):
        ψ1 = -0.1, ψ2 = -0.5, ψ3 = -5.0, ψ4 = -15.0
        """
        psi1 = -0.1   # Anaerobiosis point
        psi2 = -0.5   # Optimal upper
        psi3 = -5.0   # Optimal lower
        psi4 = -15.0  # Wilting point
        
        alpha = np.ones_like(pressure_head)
        
        # Too wet
        alpha[pressure_head > psi1] = 0.0
        
        # Transition wet to optimal
        wet_transition = (pressure_head > psi2) & (pressure_head <= psi1)
        alpha[wet_transition] = (pressure_head[wet_transition] - psi1) / (psi2 - psi1)
        
        # Too dry
        alpha[pressure_head < psi4] = 0.0
        
        # Transition optimal to dry
        dry_transition = (pressure_head < psi3) & (pressure_head >= psi4)
        alpha[dry_transition] = (pressure_head[dry_transition] - psi4) / (psi3 - psi4)
        
        return np.clip(alpha, 0, 1)
    
    def estimate_parameters_from_texture(self, sand: float, clay: float) -> Dict[str, float]:
        """
        Estimate van Genuchten parameters from soil texture
        
        Args:
            sand: Sand percentage (0-100)
            clay: Clay percentage (0-100)
            
        Returns:
            Dictionary with estimated parameters
        """
        # Pedotransfer functions (simplified)
        silt = 100 - sand - clay
        
        # Rawls et al. (1982) estimates
        theta_res = 0.01 + 0.01 * clay
        theta_sat = 0.50 - 0.01 * sand
        
        # van Genuchten parameters
        alpha = np.exp(-2.5 + 0.02 * sand - 0.015 * clay)
        n = np.exp(0.5 + 0.01 * sand)
        k_sat = np.exp(1.5 + 0.02 * sand - 0.03 * clay)
        
        return {
            'theta_res': theta_res,
            'theta_sat': theta_sat,
            'alpha_vg': alpha,
            'n_vg': n,
            'k_sat': k_sat
        }
    
    def capillary_rise(self, water_table_depth: float, time_days: float = 30) -> float:
        """
        Estimate capillary rise from water table
        
        Args:
            water_table_depth: Depth to water table (m)
            time_days: Time period (days)
            
        Returns:
            Cumulative capillary rise (m)
        """
        # Simplified model based on soil type
        if water_table_depth > 2.0:
            return 0.0
        
        # Maximum capillary rise rate (m/d)
        max_rate = 0.005 * np.exp(-water_table_depth / 0.5)
        
        return max_rate * time_days
    
    def drainage_rate(self, water_content: float, time_days: float = 1.0) -> float:
        """
        Estimate drainage rate below root zone
        
        Args:
            water_content: Current water content
            time_days: Time period
            
        Returns:
            Drainage volume (m)
        """
        theta_eff = (water_content - self.theta_res) / (self.theta_sat - self.theta_res)
        
        # Drainage rate (m/d) - simplified
        if theta_eff > 0.7:
            rate = 0.01 * (theta_eff - 0.7) / 0.3
        else:
            rate = 0.0
        
        return rate * time_days
