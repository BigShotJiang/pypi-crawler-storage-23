"""
Parameter normalization module for OHI

Maps raw parameter values to [0,1] scale where 0 = excellent, 1 = collapse
"""

import numpy as np
from typing import Dict, Any, Optional, Callable
from enum import Enum


class NormalizationMethod(Enum):
    """Normalization methods"""
    LINEAR = "linear"
    LOG = "logarithmic"
    EXPONENTIAL = "exponential"
    THRESHOLD = "threshold"


class Normalizer:
    """
    Normalizes raw parameter values to [0,1] scale
    
    Each parameter has specific normalization functions
    based on physical thresholds from the research paper.
    """
    
    def __init__(self):
        self.normalizers = {
            'ARVC': self._normalize_arvc,
            'PTSI': self._normalize_ptsi,
            'SSSP': self._normalize_sssp,
            'CMBF': self._normalize_cmbf,
            'SVRI': self._normalize_svri,
            'WEPR': self._normalize_wepr,
            'BST': self._normalize_bst
        }
    
    def normalize(self, param_name: str, value: float, 
                  **kwargs) -> float:
        """
        Normalize a parameter value
        
        Args:
            param_name: Parameter name (ARVC, PTSI, etc.)
            value: Raw parameter value
            **kwargs: Additional parameters for normalization
            
        Returns:
            Normalized value in [0,1] (0=excellent, 1=collapse)
        """
        normalizer = self.normalizers.get(param_name)
        if normalizer is None:
            raise ValueError(f"Unknown parameter: {param_name}")
        
        return normalizer(value, **kwargs)
    
    def _normalize_arvc(self, value: float, **kwargs) -> float:
        """
        ARVC normalization
        
        ARVC > 1.10 → 0.0 (EXCELLENT)
        ARVC < 0.60 → 1.0 (COLLAPSE)
        """
        if value >= 1.10:
            return 0.0
        elif value <= 0.60:
            return 1.0
        else:
            return (1.10 - value) / (1.10 - 0.60)
    
    def _normalize_ptsi(self, value: float, **kwargs) -> float:
        """
        PTSI normalization (percentage)
        
        PTSI > 28% → 0.0 (EXCELLENT)
        PTSI < 10% → 1.0 (COLLAPSE)
        """
        if value >= 28.0:
            return 0.0
        elif value <= 10.0:
            return 1.0
        else:
            return (28.0 - value) / (28.0 - 10.0)
    
    def _normalize_sssp(self, value: float, **kwargs) -> float:
        """
        SSSP normalization (already 0-1 scale)
        
        Values > 1.0 are possible but clipped to 1.0
        """
        return min(value, 1.0)
    
    def _normalize_cmbf(self, value: float, **kwargs) -> float:
        """
        CMBF normalization
        
        CMBF > 0.80 → 0.0 (EXCELLENT)
        CMBF < 0.35 → 1.0 (COLLAPSE)
        """
        if value >= 0.80:
            return 0.0
        elif value <= 0.35:
            return 1.0
        else:
            return (0.80 - value) / (0.80 - 0.35)
    
    def _normalize_svri(self, value: float, **kwargs) -> float:
        """
        SVRI normalization (0-1 scale, higher = healthier)
        
        SVRI > 0.70 → 0.0 (EXCELLENT)
        SVRI < 0.25 → 1.0 (COLLAPSE)
        """
        if value >= 0.70:
            return 0.0
        elif value <= 0.25:
            return 1.0
        else:
            return (0.70 - value) / (0.70 - 0.25)
    
    def _normalize_wepr(self, value: float, **kwargs) -> float:
        """
        WEPR normalization
        
        WEPR > 0.75 → 0.0 (EXCELLENT)
        WEPR < 0.30 → 1.0 (COLLAPSE)
        """
        if value >= 0.75:
            return 0.0
        elif value <= 0.30:
            return 1.0
        else:
            return (0.75 - value) / (0.75 - 0.30)
    
    def _normalize_bst(self, value: float, **kwargs) -> float:
        """
        BST normalization (already 0-1 scale)
        """
        return min(value, 1.0)
    
    def denormalize(self, param_name: str, normalized: float,
                   **kwargs) -> float:
        """
        Convert normalized value back to raw scale
        
        Useful for interpreting results
        """
        if param_name == 'ARVC':
            return 1.10 - normalized * (1.10 - 0.60)
        elif param_name == 'PTSI':
            return 28.0 - normalized * (28.0 - 10.0)
        elif param_name == 'SSSP':
            return normalized  # Already on same scale
        elif param_name == 'CMBF':
            return 0.80 - normalized * (0.80 - 0.35)
        elif param_name == 'SVRI':
            return 0.70 - normalized * (0.70 - 0.25)
        elif param_name == 'WEPR':
            return 0.75 - normalized * (0.75 - 0.30)
        elif param_name == 'BST':
            return normalized
        else:
            raise ValueError(f"Unknown parameter: {param_name}")
    
    def get_thresholds(self, param_name: str) -> Dict[str, float]:
        """Get threshold values for a parameter"""
        thresholds = {
            'ARVC': {'excellent': 1.10, 'good': 0.90, 'moderate': 0.75, 'critical': 0.60},
            'PTSI': {'excellent': 28.0, 'good': 22.0, 'moderate': 16.0, 'critical': 10.0},
            'SSSP': {'excellent': 0.20, 'good': 0.45, 'moderate': 0.70, 'critical': 0.90},
            'CMBF': {'excellent': 0.80, 'good': 0.65, 'moderate': 0.50, 'critical': 0.35},
            'SVRI': {'excellent': 0.70, 'good': 0.55, 'moderate': 0.40, 'critical': 0.25},
            'WEPR': {'excellent': 0.75, 'good': 0.60, 'moderate': 0.45, 'critical': 0.30},
            'BST':  {'excellent': 0.15, 'good': 0.35, 'moderate': 0.55, 'critical': 0.75}
        }
        return thresholds.get(param_name, {})
