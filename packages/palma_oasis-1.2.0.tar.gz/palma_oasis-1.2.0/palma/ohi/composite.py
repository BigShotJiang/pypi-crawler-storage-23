"""
OHI: Oasis Health Index Composite
Equation: OHI = 0.22·ARVC* + 0.18·PTSI* + 0.17·SSSP* + 0.16·CMBF* + 0.14·SVRI* + 0.08·WEPR* + 0.05·BST*

Validation: 93.1% accuracy, RMSE = 9.8%
"""

import numpy as np
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from enum import Enum

from palma.parameters.base import ParameterResult, AlertLevel
from palma.parameters.arvc import ARVC
from palma.parameters.ptsi import PTSI
from palma.parameters.sssp import SSSP
from palma.parameters.cmbf import CMBF
from palma.parameters.svri import SVRI
from palma.parameters.wepr import WEPR
from palma.parameters.bst import BST


class OHIStatus(Enum):
    """OHI status levels"""
    EXCELLENT = "EXCELLENT"
    GOOD = "GOOD"
    MODERATE = "MODERATE"
    CRITICAL = "CRITICAL"
    COLLAPSE = "COLLAPSE"


@dataclass
class OHIResult:
    """OHI computation result"""
    value: float
    status: OHIStatus
    lead_time_days: float
    parameters: Dict[str, ParameterResult]
    confidence: float
    metadata: Dict[str, Any]


class OHIComposite:
    """
    Oasis Health Index Composite Calculator
    
    Combines seven parameters with weights determined by PCA analysis:
    ARVC: 22%, PTSI: 18%, SSSP: 17%, CMBF: 16%, SVRI: 14%, WEPR: 8%, BST: 5%
    """
    
    def __init__(self, weights: Optional[Dict[str, float]] = None):
        # Default weights from research paper
        self.weights = weights or {
            'ARVC': 0.22,
            'PTSI': 0.18,
            'SSSP': 0.17,
            'CMBF': 0.16,
            'SVRI': 0.14,
            'WEPR': 0.08,
            'BST': 0.05
        }
        
        # Validate weights sum to 1.0
        total = sum(self.weights.values())
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"Weights must sum to 1.0, got {total}")
        
        # Initialize parameter calculators
        self.parameters = {
            'ARVC': ARVC(),
            'PTSI': PTSI(),
            'SSSP': SSSP(),
            'CMBF': CMBF(),
            'SVRI': SVRI(),
            'WEPR': WEPR(),
            'BST': BST()
        }
    
    def compute(self, 
                param_values: Dict[str, float],
                param_results: Optional[Dict[str, ParameterResult]] = None,
                **kwargs) -> OHIResult:
        """
        Compute OHI from normalized parameter values
        
        Args:
            param_values: Dictionary of normalized parameter values (0-1 scale)
            param_results: Optional full ParameterResult objects
            **kwargs: Additional metadata
            
        Returns:
            OHIResult with composite value and status
        """
        # Validate all parameters present
        for param in self.weights.keys():
            if param not in param_values:
                raise ValueError(f"Missing parameter: {param}")
        
        # Calculate weighted sum
        ohi_value = 0.0
        confidence_sum = 0.0
        
        for param, weight in self.weights.items():
            normalized = param_values[param]
            ohi_value += weight * normalized
            
            # Aggregate confidence if available
            if param_results and param in param_results:
                confidence_sum += param_results[param].confidence * weight
        
        # Determine status
        status = self._get_status(ohi_value)
        
        # Estimate lead time
        lead_time = self._estimate_lead_time(ohi_value, param_values)
        
        # Overall confidence
        if param_results:
            confidence = confidence_sum
        else:
            confidence = 0.85  # Default confidence
        
        return OHIResult(
            value=float(ohi_value),
            status=status,
            lead_time_days=float(lead_time),
            parameters=param_results or {},
            confidence=float(confidence),
            metadata={
                'weights': self.weights,
                'param_values': param_values,
                'status_thresholds': {
                    'excellent': 0.25,
                    'good': 0.45,
                    'moderate': 0.65,
                    'critical': 0.80
                }
            }
        )
    
    def compute_from_raw(self, raw_data: Dict[str, Any], **kwargs) -> OHIResult:
        """
        Compute OHI from raw sensor data
        
        Args:
            raw_data: Dictionary with raw data for each parameter
            **kwargs: Additional arguments
            
        Returns:
            OHIResult
        """
        param_results = {}
        param_values = {}
        
        # Compute each parameter
        for param_name, calculator in self.parameters.items():
            param_data = raw_data.get(param_name.lower(), {})
            result = calculator.compute(param_data, **kwargs)
            param_results[param_name] = result
            param_values[param_name] = result.normalized
        
        # Compute composite
        return self.compute(param_values, param_results, **kwargs)
    
    def _get_status(self, ohi_value: float) -> OHIStatus:
        """Determine OHI status from value"""
        if ohi_value < 0.25:
            return OHIStatus.EXCELLENT
        elif ohi_value < 0.45:
            return OHIStatus.GOOD
        elif ohi_value < 0.65:
            return OHIStatus.MODERATE
        elif ohi_value < 0.80:
            return OHIStatus.CRITICAL
        else:
            return OHIStatus.COLLAPSE
    
    def _estimate_lead_time(self, ohi_value: float, 
                           param_values: Dict[str, float]) -> float:
        """
        Estimate early warning lead time in days
        
        Based on empirical relationship from 31-site validation:
        Mean lead time = 52 days
        """
        if ohi_value < 0.25:
            return 90.0  # EXCELLENT: long lead time
        elif ohi_value < 0.45:
            # GOOD: 52 days mean
            return 52.0 * (1 - (ohi_value - 0.25) / 0.2)
        elif ohi_value < 0.65:
            # MODERATE: decreasing lead time
            return 30.0 * (1 - (ohi_value - 0.45) / 0.2)
        elif ohi_value < 0.80:
            # CRITICAL: short lead time
            return 14.0 * (1 - (ohi_value - 0.65) / 0.15)
        else:
            # COLLAPSE: imminent
            return 0.0
    
    def get_recommendations(self, ohi_result: OHIResult) -> List[str]:
        """Get management recommendations based on OHI"""
        recommendations = []
        
        status = ohi_result.status
        
        if status == OHIStatus.EXCELLENT:
            recommendations.append("Continue standard monitoring protocols")
            recommendations.append("Document successful management practices")
            
        elif status == OHIStatus.GOOD:
            recommendations.append("Review seasonal management practices")
            recommendations.append("Monitor parameters with highest normalized values")
            
        elif status == OHIStatus.MODERATE:
            recommendations.append("Begin intervention planning")
            recommendations.append("Increase monitoring frequency")
            recommendations.append("Target parameters with highest contribution")
            
            # Check specific parameters
            for param, result in ohi_result.parameters.items():
                if result.normalized > 0.65:
                    recommendations.append(f"Priority: Investigate {param} stress")
                    
        elif status == OHIStatus.CRITICAL:
            recommendations.append("EMERGENCY: Implement water allocation adjustments")
            recommendations.append("Activate rapid response team")
            recommendations.append("Prepare for possible emergency interventions")
            
        elif status == OHIStatus.COLLAPSE:
            recommendations.append("EMERGENCY: Activate restoration protocol")
            recommendations.append("Consider managed retreat if irreversible")
            recommendations.append("Document collapse for scientific record")
        
        return recommendations
