"""
Alert threshold definitions for PALMA parameters

Based on empirical validation from 31 sites over 28 years
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from enum import Enum


class AlertLevel(Enum):
    """Alert levels"""
    EXCELLENT = "🟢 EXCELLENT"
    GOOD = "🟡 GOOD"
    MODERATE = "🟠 MODERATE"
    CRITICAL = "🔴 CRITICAL"
    COLLAPSE = "⚫ COLLAPSE"


@dataclass
class AlertThreshold:
    """Threshold definition for a parameter"""
    excellent: float
    good: float
    moderate: float
    critical: float
    collapse: float
    
    def get_level(self, value: float) -> AlertLevel:
        """Determine alert level from value"""
        if value < self.excellent:
            return AlertLevel.EXCELLENT
        elif value < self.good:
            return AlertLevel.GOOD
        elif value < self.moderate:
            return AlertLevel.MODERATE
        elif value < self.critical:
            return AlertLevel.CRITICAL
        else:
            return AlertLevel.COLLAPSE


class ThresholdManager:
    """
    Manages alert thresholds for all PALMA parameters
    
    Thresholds are from Appendix C of the research paper
    """
    
    def __init__(self):
        # OHI thresholds (composite index)
        self.ohi_thresholds = AlertThreshold(
            excellent=0.25,
            good=0.45,
            moderate=0.65,
            critical=0.80,
            collapse=1.0
        )
        
        # Parameter thresholds (raw values, not normalized)
        self.param_thresholds = {
            'ARVC': AlertThreshold(
                excellent=1.10,
                good=0.90,
                moderate=0.75,
                critical=0.60,
                collapse=0.0
            ),
            'PTSI': AlertThreshold(
                excellent=28.0,
                good=22.0,
                moderate=16.0,
                critical=10.0,
                collapse=0.0
            ),
            'SSSP': AlertThreshold(
                excellent=0.20,
                good=0.45,
                moderate=0.70,
                critical=0.90,
                collapse=1.0
            ),
            'CMBF': AlertThreshold(
                excellent=0.80,
                good=0.65,
                moderate=0.50,
                critical=0.35,
                collapse=0.0
            ),
            'SVRI': AlertThreshold(
                excellent=0.70,
                good=0.55,
                moderate=0.40,
                critical=0.25,
                collapse=0.0
            ),
            'WEPR': AlertThreshold(
                excellent=0.75,
                good=0.60,
                moderate=0.45,
                critical=0.30,
                collapse=0.0
            ),
            'BST': AlertThreshold(
                excellent=0.15,
                good=0.35,
                moderate=0.55,
                critical=0.75,
                collapse=1.0
            )
        }
    
    def get_ohi_level(self, ohi_value: float) -> AlertLevel:
        """Get alert level for OHI value"""
        return self.ohi_thresholds.get_level(ohi_value)
    
    def get_parameter_level(self, param_name: str, value: float) -> AlertLevel:
        """Get alert level for a parameter"""
        thresholds = self.param_thresholds.get(param_name)
        if thresholds is None:
            raise ValueError(f"Unknown parameter: {param_name}")
        return thresholds.get_level(value)
    
    def get_action(self, level: AlertLevel) -> str:
        """Get recommended action for alert level"""
        actions = {
            AlertLevel.EXCELLENT: "Standard monitoring",
            AlertLevel.GOOD: "Seasonal management review",
            AlertLevel.MODERATE: "Intervention planning required",
            AlertLevel.CRITICAL: "Emergency water allocation",
            AlertLevel.COLLAPSE: "Emergency restoration protocol"
        }
        return actions.get(level, "Unknown")
    
    def is_critical(self, level: AlertLevel) -> bool:
        """Check if level requires immediate action"""
        return level in [AlertLevel.CRITICAL, AlertLevel.COLLAPSE]
    
    def get_parameters_at_risk(self, 
                               param_values: Dict[str, float]) -> List[str]:
        """Get list of parameters at MODERATE level or worse"""
        at_risk = []
        for param, value in param_values.items():
            level = self.get_parameter_level(param, value)
            if level in [AlertLevel.MODERATE, AlertLevel.CRITICAL, AlertLevel.COLLAPSE]:
                at_risk.append(param)
        return at_risk
    
    def load_from_file(self, filepath: str) -> None:
        """Load custom thresholds from YAML file"""
        import yaml
        from pathlib import Path
        
        path = Path(__file__).parent.parent.parent / filepath
        if path.exists():
            with open(path, 'r') as f:
                data = yaml.safe_load(f)
                # Update thresholds from file
                # Implementation depends on file format
                pass
