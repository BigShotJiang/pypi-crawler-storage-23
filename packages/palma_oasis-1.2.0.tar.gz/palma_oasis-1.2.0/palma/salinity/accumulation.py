"""
Long-term Salt Accumulation Model for Oasis Systems

Simulates salt buildup in root zone over decades
Based on mass balance and leaching efficiency
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass
from scipy.optimize import curve_fit


@dataclass
class AccumulationResult:
    """Salt accumulation simulation result"""
    years: np.ndarray
    ec_profile: np.ndarray
    final_ec: float
    time_to_critical: Optional[float]
    total_salt_accumulated: float
    leaching_required: float


class SaltAccumulation:
    """
    Long-term salt accumulation model
    
    Simulates salinity buildup over years to decades
    Based on PALMA validation with 28-year dataset
    """
    
    def __init__(self, root_zone_depth: float = 1.0,
                 initial_ec: float = 1.0,
                 critical_ec: float = 8.4):
        """
        Initialize accumulation model
        
        Args:
            root_zone_depth: Depth of root zone (m)
            initial_ec: Initial soil EC (dS/m)
            critical_ec: Critical EC threshold (dS/m)
        """
        self.root_depth = root_zone_depth
        self.initial_ec = initial_ec
        self.critical_ec = critical_ec
        
        # Soil parameters
        self.bulk_density = 1.3  # g/cm³
        self.field_capacity = 0.25  # m³/m³
        self.wilting_point = 0.10  # m³/m³
        
        # Conversion factors
        self.ec_to_concentration = 0.64  # kg/m³ per dS/m
        
    def simulate_yearly(self, years: int,
                       ec_irrigation: float,
                       irrigation_depth: float,
                       leaching_fraction: float,
                       rainfall_ec: float = 0.1,
                       rainfall_depth: float = 50,
                       efficiency: float = 0.7) -> AccumulationResult:
        """
        Simulate yearly salt accumulation
        
        Args:
            years: Number of years to simulate
            ec_irrigation: Irrigation water EC (dS/m)
            irrigation_depth: Annual irrigation depth (mm)
            leaching_fraction: Fraction of irrigation for leaching
            rainfall_ec: Rainfall EC (dS/m)
            rainfall_depth: Annual rainfall (mm)
            efficiency: Leaching efficiency
            
        Returns:
            AccumulationResult with time series
        """
        time = np.arange(years + 1)
        ec = np.zeros(years + 1)
        ec[0] = self.initial_ec
        
        # Total water input
        total_water = irrigation_depth + rainfall_depth
        
        # Weighted average EC of input water
        input_ec = (ec_irrigation * irrigation_depth + rainfall_ec * rainfall_depth) / total_water
        
        for year in range(years):
            current_ec = ec[year]
            
            # Calculate leaching achieved
            leaching_achieved = leaching_fraction * efficiency
            
            # Salt input
            salt_input = input_ec * total_water * self.ec_to_concentration / 1000  # kg/m²
            
            # Salt output (leaching)
            # Assumes leaching water reaches EC equilibrium with soil
            salt_output = current_ec * total_water * leaching_achieved * self.ec_to_concentration / 1000 * 0.5
            
            # Net accumulation
            delta_salt = salt_input - salt_output  # kg/m²
            
            # Convert salt to EC change
            # ΔEC = Δsalt / (root_depth * porosity * conversion)
            porosity = self.field_capacity
            delta_ec = delta_salt / (self.root_depth * porosity * self.ec_to_concentration)
            
            ec[year + 1] = current_ec + delta_ec
            
            # Ensure non-negative
            ec[year + 1] = max(ec[year + 1], 0.1)
        
        # Find time to critical threshold
        time_to_critical = None
        for year, ec_value in enumerate(ec):
            if ec_value >= self.critical_ec:
                time_to_critical = year
                break
        
        # Total salt accumulated
        final_salt = ec[-1] * self.root_depth * self.field_capacity * self.ec_to_concentration
        
        # Leaching required to reach initial
        required_lr = self._required_leaching(ec[-1], self.initial_ec)
        
        return AccumulationResult(
            years=time,
            ec_profile=ec,
            final_ec=ec[-1],
            time_to_critical=time_to_critical,
            total_salt_accumulated=final_salt,
            leaching_required=required_lr
        )
    
    def simulate_detailed(self, years: int,
                         monthly_data: List[Dict[str, float]]) -> Dict[str, Any]:
        """
        Detailed monthly simulation
        
        Args:
            years: Number of years
            monthly_data: List of monthly dictionaries with:
                - irrigation: monthly irrigation (mm)
                - ec_irrigation: monthly irrigation EC (dS/m)
                - rainfall: monthly rainfall (mm)
                - et: monthly evapotranspiration (mm)
                - leaching_fraction: monthly leaching fraction
                
        Returns:
            Dictionary with monthly results
        """
        n_months = years * 12
        if len(monthly_data) < n_months:
            # Repeat data if needed
            monthly_data = monthly_data * (n_months // len(monthly_data) + 1)
            monthly_data = monthly_data[:n_months]
        
        # Initialize arrays
        time = np.arange(n_months + 1) / 12  # Years
        ec = np.zeros(n_months + 1)
        ec[0] = self.initial_ec
        
        salt_mass = np.zeros(n_months + 1)
        salt_mass[0] = self.initial_ec * self.root_depth * self.field_capacity * self.ec_to_concentration
        
        water_balance = np.zeros(n_months)
        salt_input = np.zeros(n_months)
        salt_output = np.zeros(n_months)
        
        for month in range(n_months):
            data = monthly_data[month]
            
            irrigation = data.get('irrigation', 0)
            ec_irr = data.get('ec_irrigation', 0.5)
            rainfall = data.get('rainfall', 0)
            ec_rain = data.get('ec_rainfall', 0.1)
            et = data.get('et', 100)
            lr_frac = data.get('leaching_fraction', 0.1)
            efficiency = data.get('efficiency', 0.7)
            
            current_ec = ec[month]
            
            # Total water
            total_in = irrigation + rainfall
            
            # Weighted input EC
            if total_in > 0:
                input_ec = (ec_irr * irrigation + ec_rain * rainfall) / total_in
            else:
                input_ec = 0
            
            # Water balance (simplified)
            drainage = max(0, total_in - et)
            actual_leaching = drainage * lr_frac * efficiency
            
            # Salt input
            salt_in = input_ec * total_in * self.ec_to_concentration / 1000
            salt_input[month] = salt_in
            
            # Salt output
            if actual_leaching > 0:
                # Leaching water reaches partial equilibrium
                leaching_ec = current_ec * 0.5  # Simplified
                salt_out = leaching_ec * actual_leaching * self.ec_to_concentration / 1000
            else:
                salt_out = 0
            salt_output[month] = salt_out
            
            # Net change
            delta_salt = salt_in - salt_out
            salt_mass[month + 1] = salt_mass[month] + delta_salt
            
            # Convert to EC
            ec[month + 1] = salt_mass[month + 1] / (self.root_depth * self.field_capacity * self.ec_to_concentration)
            
            # Water balance
            water_balance[month] = total_in - et - drainage
        
        return {
            'time': time,
            'ec': ec,
            'salt_mass': salt_mass,
            'water_balance': water_balance,
            'salt_input': salt_input,
            'salt_output': salt_output,
            'cumulative_input': np.cumsum(salt_input),
            'cumulative_output': np.cumsum(salt_output),
            'final_ec': ec[-1],
            'time_to_critical': self._find_critical_time(ec)
        }
    
    def _required_leaching(self, current_ec: float, target_ec: float) -> float:
        """
        Calculate leaching required to reduce EC from current to target
        
        Based on dilution: LR = 1 - target/current
        """
        if current_ec <= target_ec:
            return 0.0
        
        return 1 - target_ec / current_ec
    
    def _find_critical_time(self, ec_series: np.ndarray) -> Optional[float]:
        """Find time when EC first exceeds critical threshold"""
        for i, ec in enumerate(ec_series):
            if ec >= self.critical_ec:
                return i / 12  # Convert months to years
        return None
    
    def fit_to_observations(self, years: np.ndarray,
                           observed_ec: np.ndarray,
                           irrigation_data: Dict[str, Any]) -> Dict[str, float]:
        """
        Fit model parameters to observed salinity data
        
        Args:
            years: Years of observations
            observed_ec: Observed EC values
            irrigation_data: Irrigation parameters
            
        Returns:
            Fitted parameters
        """
        def model(y, initial_ec, accumulation_rate, efficiency):
            ec = np.zeros_like(y)
            ec[0] = initial_ec
            
            for i in range(1, len(y)):
                dt = y[i] - y[i-1]
                # Simple exponential accumulation/decay
                ec[i] = ec[i-1] + accumulation_rate * dt - efficiency * ec[i-1] * dt
            
            return ec
        
        # Initial guess
        p0 = [self.initial_ec, 0.1, 0.05]
        
        try:
            popt, pcov = curve_fit(model, years, observed_ec, p0=p0)
            
            # Calculate R²
            fitted = model(years, *popt)
            residuals = observed_ec - fitted
            ss_res = np.sum(residuals**2)
            ss_tot = np.sum((observed_ec - np.mean(observed_ec))**2)
            r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
            
            return {
                'initial_ec': popt[0],
                'accumulation_rate': popt[1],
                'efficiency': popt[2],
                'r_squared': r_squared,
                'std_errors': np.sqrt(np.diag(pcov)) if pcov is not None else None
            }
        except:
            return {
                'initial_ec': self.initial_ec,
                'accumulation_rate': 0.1,
                'efficiency': 0.05,
                'r_squared': 0,
                'error': 'Fitting failed'
            }
    
    def steady_state_ec(self, ec_irrigation: float,
                       irrigation_depth: float,
                       leaching_fraction: float,
                       efficiency: float = 0.7) -> float:
        """
        Calculate steady-state EC under constant management
        
        At steady state: salt_in = salt_out
        """
        if leaching_fraction <= 0:
            return float('inf')
        
        # Steady state solution
        ec_ss = (ec_irrigation * irrigation_depth) / (leaching_fraction * efficiency * irrigation_depth * 5)
        
        return ec_ss
    
    def recovery_time(self, current_ec: float,
                     target_ec: float,
                     leaching_fraction: float,
                     efficiency: float = 0.7) -> float:
        """
        Estimate time to recover from current EC to target
        
        Assuming first-order decay: dEC/dt = -k·EC
        """
        if current_ec <= target_ec:
            return 0.0
        
        # Decay constant
        k = leaching_fraction * efficiency * 0.5  # per year
        
        if k <= 0:
            return float('inf')
        
        # t = -ln(target/current) / k
        time = -np.log(target_ec / current_ec) / k
        
        return time
    
    def __repr__(self) -> str:
        return f"SaltAccumulation(root_depth={self.root_depth}m, critical={self.critical_ec}dS/m)"
