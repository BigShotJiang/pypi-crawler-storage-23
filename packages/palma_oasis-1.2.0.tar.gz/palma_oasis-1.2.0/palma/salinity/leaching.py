"""
Leaching Requirement Calculator for Salinity Management

LR = EC_i / (5·EC_e - EC_i)
where:
- EC_i: Electrical conductivity of irrigation water (dS/m)
- EC_e: Target electrical conductivity of saturated extract (dS/m)

From Rhoades et al. (1992) FAO Irrigation and Drainage Paper 48
"""

import numpy as np
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class LeachingRequirement:
    """Leaching requirement calculation result"""
    lr_fraction: float  # Leaching requirement (fraction of irrigation)
    lr_depth: float  # Leaching requirement as depth (mm)
    ec_irrigation: float  # Irrigation water EC (dS/m)
    ec_target: float  # Target soil EC (dS/m)
    irrigation_depth: float  # Irrigation depth (mm)
    leaching_efficiency: float  # Leaching efficiency factor


class LeachingCalculator:
    """
    Calculate leaching requirements for salinity control
    
    Based on FAO guidelines and validated for oasis systems
    """
    
    def __init__(self, leaching_efficiency: float = 0.7):
        """
        Initialize leaching calculator
        
        Args:
            leaching_efficiency: Efficiency of leaching (0-1)
                                Lower in layered soils
        """
        self.leaching_efficiency = leaching_efficiency
        
    def requirement(self, ec_irrigation: float, 
                   ec_target: float,
                   irrigation_depth: Optional[float] = None) -> LeachingRequirement:
        """
        Calculate leaching requirement fraction
        
        LR = EC_i / (5·EC_e - EC_i)
        
        Args:
            ec_irrigation: EC of irrigation water (dS/m)
            ec_target: Target EC of saturated extract (dS/m)
            irrigation_depth: Irrigation depth (mm) - optional
            
        Returns:
            LeachingRequirement object
        """
        denominator = 5 * ec_target - ec_irrigation
        
        if denominator <= 0:
            lr_fraction = 0.0
        else:
            lr_fraction = ec_irrigation / denominator
        
        # Apply efficiency factor
        lr_fraction = lr_fraction / self.leaching_efficiency
        
        # Clip to reasonable range
        lr_fraction = np.clip(lr_fraction, 0.0, 0.5)
        
        # Calculate depth if irrigation provided
        if irrigation_depth is not None:
            lr_depth = lr_fraction * irrigation_depth
        else:
            lr_depth = None
        
        return LeachingRequirement(
            lr_fraction=lr_fraction,
            lr_depth=lr_depth,
            ec_irrigation=ec_irrigation,
            ec_target=ec_target,
            irrigation_depth=irrigation_depth,
            leaching_efficiency=self.leaching_efficiency
        )
    
    def seasonal_requirement(self, ec_irrigation: float,
                            current_ec: float,
                            target_ec: float,
                            irrigation_season_depth: float,
                            root_zone_depth: float = 1.0) -> Dict[str, float]:
        """
        Calculate seasonal leaching requirement
        
        Accounts for current salinity levels
        """
        # Salt mass in root zone
        current_salt = current_ec * root_zone_depth * 10  # Approximate conversion
        
        # Target salt mass
        target_salt = target_ec * root_zone_depth * 10
        
        # Salt to remove
        salt_to_remove = max(0, current_salt - target_salt)
        
        # Salt input from irrigation
        salt_input = ec_irrigation * irrigation_season_depth * 10 / 1000  # kg/ha
        
        # Total salt to leach
        total_salt_leach = salt_to_remove + salt_input * 0.3  # 30% retention
        
        # Water needed for leaching (assuming 1 dS/m ≈ 0.64 kg/m³)
        # 1 kg salt requires approximately 1.5 m³ water for leaching
        leaching_water = total_salt_leach * 1.5  # m³/ha
        
        leaching_depth = leaching_water / 10  # Convert to mm
        
        # Leaching fraction
        lr_fraction = leaching_depth / irrigation_season_depth if irrigation_season_depth > 0 else 0
        
        return {
            'current_salt_mass': current_salt,
            'target_salt_mass': target_salt,
            'salt_to_remove': salt_to_remove,
            'salt_input': salt_input,
            'total_salt_leach': total_salt_leach,
            'leaching_water': leaching_water,
            'leaching_depth': leaching_depth,
            'lr_fraction': lr_fraction,
            'leaching_efficiency': self.leaching_efficiency
        }
    
    def irrigation_schedule(self, ec_irrigation: float,
                           ec_target: float,
                           growing_season_days: int,
                           irrigation_interval: int,
                           daily_et: float) -> Dict[str, Any]:
        """
        Generate irrigation schedule with leaching
        
        Args:
            ec_irrigation: Irrigation water EC (dS/m)
            ec_target: Target soil EC (dS/m)
            growing_season_days: Length of growing season
            irrigation_interval: Days between irrigations
            daily_et: Daily evapotranspiration (mm)
            
        Returns:
            Dictionary with irrigation schedule
        """
        # Base leaching requirement
        lr = self.requirement(ec_irrigation, ec_target)
        
        # Number of irrigations
        n_irrigations = growing_season_days // irrigation_interval
        
        # ET between irrigations
        et_period = daily_et * irrigation_interval
        
        # Net irrigation requirement (to meet ET)
        net_irrigation = et_period / (1 - lr.lr_fraction)
        
        # Leaching portion
        leaching_portion = net_irrigation * lr.lr_fraction
        
        schedule = []
        cumulative_leaching = 0
        
        for i in range(n_irrigations):
            irrigation = {
                'day': (i + 1) * irrigation_interval,
                'net_irrigation': net_irrigation,
                'leaching_portion': leaching_portion,
                'total_water': net_irrigation + leaching_portion,
                'cumulative_leaching': cumulative_leaching + leaching_portion
            }
            schedule.append(irrigation)
            cumulative_leaching += leaching_portion
        
        return {
            'schedule': schedule,
            'total_net_irrigation': net_irrigation * n_irrigations,
            'total_leaching': cumulative_leaching,
            'total_water': net_irrigation * n_irrigations + cumulative_leaching,
            'average_lr_fraction': lr.lr_fraction,
            'leaching_efficiency': self.leaching_efficiency
        }
    
    def critical_ec_from_lr(self, ec_irrigation: float,
                           lr_fraction: float) -> float:
        """
        Calculate achievable soil EC given leaching fraction
        
        EC_e = EC_i / (5·LR)
        """
        if lr_fraction <= 0:
            return float('inf')
        
        return ec_irrigation / (5 * lr_fraction)
    
    def salt_mass_balance(self, ec_irrigation: float,
                         irrigation_depth: float,
                         drainage_ec: float,
                         drainage_depth: float,
                         initial_salt: float,
                         area: float = 1.0) -> Dict[str, float]:
        """
        Calculate salt mass balance for an area
        
        Args:
            ec_irrigation: Irrigation water EC (dS/m)
            irrigation_depth: Irrigation depth (mm)
            drainage_ec: Drainage water EC (dS/m)
            drainage_depth: Drainage depth (mm)
            initial_salt: Initial salt mass in soil (kg/ha)
            area: Area (ha)
            
        Returns:
            Dictionary with salt balance components
        """
        # Convert EC to salt concentration (approximate)
        # 1 dS/m ≈ 0.64 kg/m³ for typical salts
        conv_factor = 0.64
        
        # Salt input
        salt_in = ec_irrigation * irrigation_depth * 10 * conv_factor / 1000  # kg/ha
        
        # Salt output
        salt_out = drainage_ec * drainage_depth * 10 * conv_factor / 1000  # kg/ha
        
        # Net change
        delta_salt = salt_in - salt_out
        
        # Final salt mass
        final_salt = initial_salt + delta_salt
        
        # Leaching efficiency
        if salt_in > 0:
            leaching_achieved = salt_out / salt_in
        else:
            leaching_achieved = 1.0
        
        return {
            'salt_input': salt_in,
            'salt_output': salt_out,
            'delta_salt': delta_salt,
            'initial_salt': initial_salt,
            'final_salt': final_salt,
            'leaching_achieved': leaching_achieved,
            'leaching_required': self.requirement(ec_irrigation, drainage_ec).lr_fraction
        }
    
    def time_to_threshold(self, ec_irrigation: float,
                         current_ec: float,
                         target_ec: float,
                         annual_irrigation: float,
                         leaching_applied: float = 0) -> float:
        """
        Estimate years to reach target EC
        
        Args:
            ec_irrigation: Irrigation water EC (dS/m)
            current_ec: Current soil EC (dS/m)
            target_ec: Target soil EC (dS/m)
            annual_irrigation: Annual irrigation depth (mm)
            leaching_applied: Leaching fraction actually applied
            
        Returns:
            Years to reach target (negative if decreasing, positive if increasing)
        """
        # Net accumulation rate
        if leaching_applied <= 0:
            lr = self.requirement(ec_irrigation, current_ec)
            required_lr = lr.lr_fraction
        else:
            required_lr = leaching_applied
        
        # Salt balance
        salt_input = ec_irrigation * annual_irrigation * 10 * 0.64 / 1000
        salt_output = current_ec * annual_irrigation * required_lr * 10 * 0.64 / 1000 * 5
        
        net_annual_change = (salt_input - salt_output) / 10  # Convert to EC change
        
        if abs(net_annual_change) < 1e-6:
            return float('inf')
        
        years = (target_ec - current_ec) / net_annual_change
        
        return years
    
    def __repr__(self) -> str:
        return f"LeachingCalculator(efficiency={self.leaching_efficiency})"
