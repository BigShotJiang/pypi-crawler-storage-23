"""
Salt Transport in Soil - Convection-Dispersion Equation

∂(θ·C)/∂t = ∂/∂z[θ·D·∂C/∂z - q·C] - S_root·C

where:
- θ: Volumetric water content
- C: Salt concentration
- D: Dispersion coefficient
- q: Water flux
- S_root: Root water uptake
"""

import numpy as np
from typing import Optional, Dict, Any, Tuple, Callable
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve


class SaltTransport:
    """
    1D Salt transport solver using convection-dispersion equation
    
    Simulates salt movement and accumulation in soil profile
    """
    
    def __init__(self, depth: float = 2.0, n_nodes: int = 100):
        """
        Initialize salt transport model
        
        Args:
            depth: Soil profile depth (m)
            n_nodes: Number of spatial nodes
        """
        self.depth = depth
        self.n_nodes = n_nodes
        self.z = np.linspace(0, depth, n_nodes)
        self.dz = depth / (n_nodes - 1)
        
        # Default parameters
        self.dispersivity = 0.05  # m
        self.molecular_diffusion = 1e-9  # m²/s
        self.bulk_density = 1.3  # g/cm³
        
    def dispersion_coefficient(self, velocity: float, 
                               water_content: float) -> float:
        """
        Calculate hydrodynamic dispersion coefficient
        
        D = α·|v| + D_0·τ
        where:
        - α: Dispersivity
        - v: Pore water velocity
        - D_0: Molecular diffusion coefficient
        - τ: Tortuosity factor
        """
        # Pore water velocity
        if water_content > 0:
            v_pore = velocity / water_content
        else:
            v_pore = 0
        
        # Mechanical dispersion
        D_mech = self.dispersivity * abs(v_pore)
        
        # Molecular diffusion with tortuosity
        # Millington-Quirk tortuosity model
        tortuosity = water_content ** (7/3) / (0.45 ** 2)  # Relative to saturation
        D_diff = self.molecular_diffusion * tortuosity * 86400  # Convert to m²/d
        
        return D_mech + D_diff
    
    def solve_steady(self, water_flux: np.ndarray,
                    water_content: np.ndarray,
                    boundary_conditions: Dict[str, float],
                    root_uptake: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Solve steady-state salt transport
        
        ∂/∂z[θ·D·∂C/∂z - q·C] = S_root·C
        
        Args:
            water_flux: Water flux at each node (m/d)
            water_content: Water content at each node
            boundary_conditions: Dictionary with 'top' and 'bottom' concentrations
            root_uptake: Root uptake at each node (1/d)
            
        Returns:
            Dictionary with concentration profile
        """
        if root_uptake is None:
            root_uptake = np.zeros(self.n_nodes)
        
        # Calculate dispersion at each node
        D = np.zeros(self.n_nodes)
        for i in range(self.n_nodes):
            D[i] = self.dispersion_coefficient(water_flux[i], water_content[i])
        
        # Build coefficient matrix (tridiagonal)
        main_diag = np.zeros(self.n_nodes)
        upper_diag = np.zeros(self.n_nodes - 1)
        lower_diag = np.zeros(self.n_nodes - 1)
        rhs = np.zeros(self.n_nodes)
        
        # Interior nodes
        for i in range(1, self.n_nodes - 1):
            # Advection-dispersion terms
            theta_i = water_content[i]
            theta_ip1 = water_content[i + 1]
            theta_im1 = water_content[i - 1]
            
            D_i = D[i]
            D_ip1 = D[i + 1]
            D_im1 = D[i - 1]
            
            q_i = water_flux[i]
            
            # Discretization (upwind for advection)
            # -d/dz[θD dC/dz] + d/dz[qC] + S_root·C = 0
            
            # Dispersion term
            a_ip1 = -theta_ip1 * D_ip1 / self.dz**2
            a_im1 = -theta_im1 * D_im1 / self.dz**2
            a_i = (theta_ip1 * D_ip1 + theta_im1 * D_im1) / self.dz**2
            
            # Advection term (upwind)
            if q_i >= 0:  # Flow downward
                a_i += q_i / self.dz
                a_im1 += -q_i / self.dz
            else:  # Flow upward
                a_i += -q_i / self.dz
                a_ip1 += q_i / self.dz
            
            # Root uptake
            a_i += root_uptake[i]
            
            main_diag[i] = a_i
            upper_diag[i] = a_ip1
            lower_diag[i-1] = a_im1
            
            rhs[i] = 0
        
        # Top boundary (z=0) - Dirichlet
        i = 0
        main_diag[i] = 1.0
        upper_diag[i] = 0.0
        rhs[i] = boundary_conditions.get('top', 0.0)
        
        # Bottom boundary (z=depth) - Dirichlet or Neumann
        i = self.n_nodes - 1
        bc_type = boundary_conditions.get('bottom_type', 'dirichlet')
        
        if bc_type == 'dirichlet':
            main_diag[i] = 1.0
            lower_diag[i-1] = 0.0
            rhs[i] = boundary_conditions.get('bottom', 0.0)
        else:  # Neumann (zero gradient)
            main_diag[i] = 1.0
            lower_diag[i-1] = -1.0
            rhs[i] = 0.0
        
        # Solve system
        from scipy.sparse import diags
        
        diagonals = [main_diag, upper_diag, lower_diag]
        A = diags(diagonals, [0, 1, -1], format='csr')
        
        try:
            concentration = spsolve(A, rhs)
        except:
            # Fall back to dense solver
            A_dense = np.diag(main_diag) + np.diag(upper_diag, 1) + np.diag(lower_diag, -1)
            concentration = np.linalg.solve(A_dense, rhs)
        
        # Calculate salt mass
        salt_mass = np.trapz(concentration * water_content, self.z)
        
        return {
            'concentration': concentration,
            'depth': self.z,
            'salt_mass': salt_mass,
            'mean_concentration': np.mean(concentration),
            'max_concentration': np.max(concentration)
        }
    
    def solve_transient(self, initial_concentration: np.ndarray,
                        water_flux_func: Callable,
                        water_content_func: Callable,
                        dt: float, n_steps: int,
                        boundary_conditions: Dict[str, Any],
                        root_uptake_func: Optional[Callable] = None) -> Dict[str, Any]:
        """
        Solve transient salt transport
        
        ∂(θ·C)/∂t = ∂/∂z[θ·D·∂C/∂z - q·C] - S_root·C
        
        Args:
            initial_concentration: Initial concentration profile
            water_flux_func: Function of (t, z) returning water flux
            water_content_func: Function of (t, z) returning water content
            dt: Time step (days)
            n_steps: Number of time steps
            boundary_conditions: Boundary condition specifications
            root_uptake_func: Function of (t, z) returning root uptake
            
        Returns:
            Dictionary with time series of concentration
        """
        # Initialize arrays
        n_nodes = self.n_nodes
        concentration = np.zeros((n_steps + 1, n_nodes))
        concentration[0] = initial_concentration
        
        time = np.arange(n_steps + 1) * dt
        
        for n in range(n_steps):
            t = n * dt
            
            # Get current state
            C_n = concentration[n]
            
            # Get water flux and content at this time
            q = np.array([water_flux_func(t, z) for z in self.z])
            theta = np.array([water_content_func(t, z) for z in self.z])
            
            if root_uptake_func is not None:
                S_root = np.array([root_uptake_func(t, z) for z in self.z])
            else:
                S_root = np.zeros(n_nodes)
            
            # Calculate dispersion coefficients
            D = np.zeros(n_nodes)
            for i in range(n_nodes):
                D[i] = self.dispersion_coefficient(q[i], theta[i])
            
            # Build matrix for implicit scheme
            main_diag = np.zeros(n_nodes)
            upper_diag = np.zeros(n_nodes - 1)
            lower_diag = np.zeros(n_nodes - 1)
            rhs = np.zeros(n_nodes)
            
            # Interior nodes
            for i in range(1, n_nodes - 1):
                theta_i = theta[i]
                theta_ip1 = theta[i + 1]
                theta_im1 = theta[i - 1]
                
                D_i = D[i]
                D_ip1 = D[i + 1]
                D_im1 = D[i - 1]
                
                q_i = q[i]
                
                # Storage term
                storage = theta_i / dt
                
                # Dispersion terms
                disp_ip1 = -theta_ip1 * D_ip1 / self.dz**2
                disp_im1 = -theta_im1 * D_im1 / self.dz**2
                disp_i = (theta_ip1 * D_ip1 + theta_im1 * D_im1) / self.dz**2
                
                # Advection terms (upwind)
                if q_i >= 0:
                    adv_i = q_i / self.dz
                    adv_im1 = -q_i / self.dz
                    adv_ip1 = 0.0
                else:
                    adv_i = -q_i / self.dz
                    adv_ip1 = q_i / self.dz
                    adv_im1 = 0.0
                
                # Root uptake
                uptake = S_root[i]
                
                main_diag[i] = storage + disp_i + adv_i + uptake
                upper_diag[i] = disp_ip1 + adv_ip1
                lower_diag[i-1] = disp_im1 + adv_im1
                
                rhs[i] = storage * C_n[i]
            
            # Top boundary
            i = 0
            bc_top_type = boundary_conditions.get('top_type', 'dirichlet')
            
            if bc_top_type == 'dirichlet':
                main_diag[i] = 1.0
                upper_diag[i] = 0.0
                rhs[i] = boundary_conditions.get('top_concentration', 0.0)
            elif bc_top_type == 'flux':
                # Flux boundary: -θD dC/dz + qC = q_top * C_top
                q_top = boundary_conditions.get('top_flux', 0.0)
                C_top = boundary_conditions.get('top_concentration', 0.0)
                
                main_diag[i] = q[i] / self.dz + theta[i] * D[i] / self.dz**2 + theta[i] / dt
                upper_diag[i] = -theta[i] * D[i] / self.dz**2
                rhs[i] = q_top * C_top / self.dz + theta[i] * C_n[i] / dt
            
            # Bottom boundary
            i = n_nodes - 1
            bc_bottom_type = boundary_conditions.get('bottom_type', 'dirichlet')
            
            if bc_bottom_type == 'dirichlet':
                main_diag[i] = 1.0
                lower_diag[i-1] = 0.0
                rhs[i] = boundary_conditions.get('bottom_concentration', 0.0)
            elif bc_bottom_type == 'neumann':
                # Zero gradient
                main_diag[i] = 1.0
                lower_diag[i-1] = -1.0
                rhs[i] = 0.0
            elif bc_bottom_type == 'free_drainage':
                # Free drainage: ∂C/∂z = 0
                main_diag[i] = 1.0
                lower_diag[i-1] = -1.0
                rhs[i] = 0.0
            
            # Solve system
            from scipy.sparse import diags
            
            diagonals = [main_diag, upper_diag, lower_diag]
            A = diags(diagonals, [0, 1, -1], format='csr')
            
            try:
                C_new = spsolve(A, rhs)
            except:
                A_dense = np.diag(main_diag) + np.diag(upper_diag, 1) + np.diag(lower_diag, -1)
                C_new = np.linalg.solve(A_dense, rhs)
            
            concentration[n + 1] = C_new
        
        # Calculate salt mass over time
        salt_mass = np.zeros(n_steps + 1)
        for n in range(n_steps + 1):
            theta_n = np.array([water_content_func(time[n], z) for z in self.z])
            salt_mass[n] = np.trapz(concentration[n] * theta_n, self.z)
        
        return {
            'concentration': concentration,
            'time': time,
            'depth': self.z,
            'salt_mass': salt_mass,
            'final_profile': concentration[-1]
        }
    
    def salt_balance(self, concentration: np.ndarray,
                    water_flux_top: float,
                    water_flux_bottom: float,
                    irrigation_concentration: float,
                    dt: float) -> Dict[str, float]:
        """
        Calculate salt balance for a time period
        
        Returns:
            Dictionary with salt inputs, outputs, and change in storage
        """
        # Salt input from irrigation
        salt_in = water_flux_top * irrigation_concentration * dt
        
        # Salt output from drainage
        salt_out = water_flux_bottom * concentration[-1] * dt
        
        # Change in storage
        delta_storage = salt_in - salt_out
        
        # Leaching efficiency
        if salt_in > 0:
            leaching_efficiency = salt_out / salt_in
        else:
            leaching_efficiency = 1.0
        
        return {
            'salt_input': salt_in,
            'salt_output': salt_out,
            'delta_storage': delta_storage,
            'leaching_efficiency': leaching_efficiency,
            'net_accumulation': delta_storage > 0
        }
    
    def __repr__(self) -> str:
        return f"SaltTransport(depth={self.depth}m, nodes={self.n_nodes})"
