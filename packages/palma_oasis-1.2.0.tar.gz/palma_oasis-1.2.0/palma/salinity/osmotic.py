"""
Osmotic Potential Calculator for Soil Salinity

Ψ_osmotic = -0.036·EC [MPa]
where EC is electrical conductivity in dS/m

Critical threshold for date palm: EC_crit = 8.4 dS/m
"""

import numpy as np
from typing import Optional, Dict, Any, Union
from dataclasses import dataclass


@dataclass
class OsmoticResult:
    """Osmotic potential calculation result"""
    osmotic_potential: float  # MPa
    ec: float  # Electrical conductivity (dS/m)
    water_potential: float  # Total water potential (MPa)
    stress_level: str  # Stress level description
    available_water_fraction: float  # Fraction of available water


class OsmoticPotential:
    """
    Calculate osmotic potential from electrical conductivity
    
    Ψ_osmotic = -0.036·EC [MPa]
    Based on Robinson & Stokes (1954)
    """
    
    def __init__(self, conversion_factor: float = 0.036):
        """
        Initialize osmotic potential calculator
        
        Args:
            conversion_factor: EC to osmotic potential factor (MPa per dS/m)
        """
        self.conversion_factor = conversion_factor
        self.ec_critical = 8.4  # dS/m for date palm (from paper)
        
    def from_ec(self, ec: float, temperature: Optional[float] = None) -> OsmoticResult:
        """
        Calculate osmotic potential from electrical conductivity
        
        Args:
            ec: Electrical conductivity (dS/m)
            temperature: Temperature (°C) for temperature correction
            
        Returns:
            OsmoticResult with osmotic potential
        """
        # Temperature correction if provided
        if temperature is not None:
            ec = self._temperature_correction(ec, temperature)
        
        osmotic_potential = -self.conversion_factor * ec
        
        # Determine stress level
        stress_level = self._stress_level(ec)
        
        # Available water fraction (simplified)
        if ec <= 2.0:
            aw_fraction = 1.0
        elif ec >= self.ec_critical:
            aw_fraction = 0.0
        else:
            aw_fraction = 1 - (ec - 2.0) / (self.ec_critical - 2.0)
        
        return OsmoticResult(
            osmotic_potential=osmotic_potential,
            ec=ec,
            water_potential=osmotic_potential,  # Assuming matric potential is separate
            stress_level=stress_level,
            available_water_fraction=aw_fraction
        )
    
    def from_solution(self, concentration: float, 
                     molar_mass: float,
                     temperature: float = 25) -> OsmoticResult:
        """
        Calculate osmotic potential from solute concentration
        
        Ψ = -i·C·R·T
        where:
        - i: van 't Hoff factor
        - C: concentration (mol/L)
        - R: gas constant
        - T: temperature (K)
        
        Args:
            concentration: Solute concentration (mol/L)
            molar_mass: Molar mass (g/mol)
            temperature: Temperature (°C)
            
        Returns:
            OsmoticResult
        """
        R = 8.314  # J/mol/K
        T = temperature + 273.15  # K
        
        # Convert to MPa (1 J/L = 0.001 MPa)
        osmotic_potential = -concentration * R * T / 1000
        
        # Estimate EC from concentration (rough approximation)
        # For NaCl: 1 mol/L ≈ 100 dS/m
        ec = concentration * 100
        
        return self.from_ec(ec, temperature)
    
    def total_water_potential(self, osmotic: float, 
                              matric: float,
                              gravitational: float = 0) -> float:
        """
        Calculate total water potential
        
        Ψ_total = Ψ_osmotic + Ψ_matric + Ψ_gravitational
        """
        return osmotic + matric + gravitational
    
    def _temperature_correction(self, ec: float, temperature: float) -> float:
        """
        Correct EC to reference temperature (25°C)
        
        EC_25 = EC_T / (1 + α(T - 25))
        where α ≈ 0.02 for most soil solutions
        """
        alpha = 0.02  # Temperature coefficient
        return ec / (1 + alpha * (temperature - 25))
    
    def _stress_level(self, ec: float) -> str:
        """
        Determine plant stress level from EC
        
        Based on paper thresholds:
        - Excellent: EC < 2.0
        - Good: 2.0-4.0
        - Moderate: 4.0-6.0
        - Critical: 6.0-8.4
        - Collapse: > 8.4
        """
        if ec < 2.0:
            return "Excellent - No stress"
        elif ec < 4.0:
            return "Good - Mild stress"
        elif ec < 6.0:
            return "Moderate - Significant stress"
        elif ec < self.ec_critical:
            return "Critical - Severe stress"
        else:
            return "Collapse - Beyond tolerance"
    
    def yield_reduction(self, ec: float, crop: str = 'date_palm') -> float:
        """
        Estimate crop yield reduction due to salinity
        
        For date palm (from paper):
        0% reduction at EC < 4.0
        50% reduction at EC = 8.4
        100% reduction at EC > 12.0
        
        Returns:
            Yield reduction fraction (0-1)
        """
        if crop == 'date_palm':
            if ec <= 4.0:
                return 0.0
            elif ec >= 12.0:
                return 1.0
            else:
                # Linear interpolation
                return (ec - 4.0) / (12.0 - 4.0)
        else:
            # Generic Maas-Hoffman model
            threshold = 1.5  # dS/m
            slope = 0.1  # % per dS/m above threshold
            
            if ec <= threshold:
                return 0.0
            else:
                return min((ec - threshold) * slope / 100, 1.0)
    
    def leaching_requirement(self, ec_irrigation: float, 
                            ec_target: float) -> float:
        """
        Calculate leaching requirement
        
        LR = EC_irrigation / (5·EC_target - EC_irrigation)
        
        From Rhoades et al. (1992)
        """
        denominator = 5 * ec_target - ec_irrigation
        
        if denominator <= 0:
            return 0.0
        
        return ec_irrigation / denominator
    
    def salt_tolerance_index(self, ec: float) -> float:
        """
        Calculate salt tolerance index (0-1)
        
        1 = fully tolerant, 0 = intolerant
        """
        if ec <= 2.0:
            return 1.0
        elif ec >= self.ec_critical:
            return 0.0
        else:
            return 1 - (ec - 2.0) / (self.ec_critical - 2.0)
    
    def __repr__(self) -> str:
        return f"OsmoticPotential(conversion={self.conversion_factor}, EC_crit={self.ec_critical})"
