"""
Spectral Indices Calculator for Vegetation and Stress Detection

Comprehensive set of indices for oasis health monitoring
"""

import numpy as np
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class IndexResult:
    """Spectral index calculation result"""
    name: str
    value: np.ndarray
    mean: float
    std: float
    valid_fraction: float
    interpretation: str


class SpectralIndices:
    """
    Calculator for various spectral indices used in oasis monitoring
    
    Includes:
    - Vegetation indices: NDVI, EVI, SAVI, MSAVI
    - Stress indices: NDRE, PRI, SIPI
    - Water indices: NDWI, MNDWI
    - Soil indices: NDSI, BI
    """
    
    def __init__(self):
        """Initialize spectral indices calculator"""
        pass
    
    def ndvi(self, nir: np.ndarray, red: np.ndarray) -> IndexResult:
        """
        Normalized Difference Vegetation Index
        
        NDVI = (NIR - Red) / (NIR + Red)
        """
        numerator = nir - red
        denominator = nir + red
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        valid_mask = ~np.isnan(result)
        valid_fraction = np.sum(valid_mask) / valid_mask.size
        
        return IndexResult(
            name='NDVI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=valid_fraction,
            interpretation=self._interpret_ndvi(np.nanmean(result))
        )
    
    def evi(self, nir: np.ndarray, red: np.ndarray, 
           blue: np.ndarray) -> IndexResult:
        """
        Enhanced Vegetation Index
        
        EVI = 2.5 * ((NIR - Red) / (NIR + 6*Red - 7.5*Blue + 1))
        """
        numerator = nir - red
        denominator = nir + 6*red - 7.5*blue + 1
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = 2.5 * numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='EVI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"EVI = {np.nanmean(result):.3f}"
        )
    
    def ndre(self, nir: np.ndarray, red_edge: np.ndarray) -> IndexResult:
        """
        Red Edge NDVI
        
        NDRE = (NIR - RedEdge) / (NIR + RedEdge)
        """
        numerator = nir - red_edge
        denominator = nir + red_edge
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='NDRE',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=self._interpret_ndre(np.nanmean(result))
        )
    
    def savi(self, nir: np.ndarray, red: np.ndarray, 
            L: float = 0.5) -> IndexResult:
        """
        Soil-Adjusted Vegetation Index
        
        SAVI = ((NIR - Red) / (NIR + Red + L)) * (1 + L)
        """
        numerator = nir - red
        denominator = nir + red + L
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = (numerator[mask] / denominator[mask]) * (1 + L)
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='SAVI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"SAVI (L={L}) = {np.nanmean(result):.3f}"
        )
    
    def msavi(self, nir: np.ndarray, red: np.ndarray) -> IndexResult:
        """
        Modified Soil-Adjusted Vegetation Index
        
        MSAVI = (2*NIR + 1 - sqrt((2*NIR + 1)² - 8*(NIR - Red))) / 2
        """
        term = 2 * nir + 1
        sqrt_term = term**2 - 8 * (nir - red)
        sqrt_term = np.maximum(sqrt_term, 0)
        
        result = (term - np.sqrt(sqrt_term)) / 2
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='MSAVI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"MSAVI = {np.nanmean(result):.3f}"
        )
    
    def ndwi(self, green: np.ndarray, nir: np.ndarray) -> IndexResult:
        """
        Normalized Difference Water Index
        
        NDWI = (Green - NIR) / (Green + NIR)
        """
        numerator = green - nir
        denominator = green + nir
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='NDWI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=self._interpret_water(np.nanmean(result))
        )
    
    def mndwi(self, green: np.ndarray, swir: np.ndarray) -> IndexResult:
        """
        Modified Normalized Difference Water Index
        
        MNDWI = (Green - SWIR) / (Green + SWIR)
        """
        numerator = green - swir
        denominator = green + swir
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='MNDWI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"MNDWI = {np.nanmean(result):.3f}"
        )
    
    def ndsi(self, swir1: np.ndarray, swir2: np.ndarray) -> IndexResult:
        """
        Normalized Difference Snow/Ice Index
        
        NDSI = (Green - SWIR) / (Green + SWIR)
        Actually uses different bands, but naming convention
        """
        numerator = swir1 - swir2
        denominator = swir1 + swir2
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='NDSI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"NDSI = {np.nanmean(result):.3f}"
        )
    
    def pri(self, green: np.ndarray, blue: np.ndarray) -> IndexResult:
        """
        Photochemical Reflectance Index
        
        PRI = (Green - Blue) / (Green + Blue)
        """
        numerator = green - blue
        denominator = green + blue
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='PRI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"PRI = {np.nanmean(result):.3f}"
        )
    
    def sipi(self, nir: np.ndarray, red: np.ndarray, 
            blue: np.ndarray) -> IndexResult:
        """
        Structure Insensitive Pigment Index
        
        SIPI = (NIR - Blue) / (NIR - Red)
        """
        numerator = nir - blue
        denominator = nir - red
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        return IndexResult(
            name='SIPI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"SIPI = {np.nanmean(result):.3f}"
        )
    
    def ndti(self, swir1: np.ndarray, swir2: np.ndarray) -> IndexResult:
        """
        Normalized Difference Tillage Index
        
        NDTI = (SWIR1 - SWIR2) / (SWIR1 + SWIR2)
        """
        numerator = swir1 - swir2
        denominator = swir1 + swir2
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='NDTI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"NDTI = {np.nanmean(result):.3f}"
        )
    
    def bi(self, swir1: np.ndarray, nir: np.ndarray, 
          red: np.ndarray) -> IndexResult:
        """
        Bare Soil Index
        
        BSI = ((SWIR + Red) - (NIR + Blue)) / ((SWIR + Red) + (NIR + Blue))
        """
        numerator = (swir1 + red) - (nir + red)  # Simplified
        denominator = (swir1 + red) + (nir + red)
        
        result = np.zeros_like(numerator)
        mask = denominator > 0
        result[mask] = numerator[mask] / denominator[mask]
        
        result = np.clip(result, -1, 1)
        
        return IndexResult(
            name='BSI',
            value=result,
            mean=np.nanmean(result),
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=f"BSI = {np.nanmean(result):.3f}"
        )
    
    def svri_composite(self, ndvi: np.ndarray, ndre: np.ndarray,
                      swir_stress: np.ndarray, evi: np.ndarray,
                      weights: Optional[Dict[str, float]] = None) -> IndexResult:
        """
        Spectral Vegetation Resilience Index composite
        
        SVRI = w1·NDVI + w2·NDRE + w3·(1-SWIR_stress) + w4·EVI
        """
        if weights is None:
            weights = {'ndvi': 0.40, 'ndre': 0.25, 'swir': 0.20, 'evi': 0.15}
        
        # Normalize SWIR stress (inverted)
        swir_norm = 1 - np.clip(swir_stress, 0, 1)
        
        result = (weights['ndvi'] * ndvi + 
                 weights['ndre'] * ndre + 
                 weights['swir'] * swir_norm + 
                 weights['evi'] * evi)
        
        result = np.clip(result, 0, 1)
        
        mean_svri = np.nanmean(result)
        
        return IndexResult(
            name='SVRI',
            value=result,
            mean=mean_svri,
            std=np.nanstd(result),
            valid_fraction=np.sum(~np.isnan(result)) / result.size,
            interpretation=self._interpret_svri(mean_svri)
        )
    
    def _interpret_ndvi(self, ndvi: float) -> str:
        """Interpret NDVI value"""
        if ndvi < 0:
            return "Water or snow"
        elif ndvi < 0.2:
            return "Bare soil or sparse vegetation"
        elif ndvi < 0.4:
            return "Moderate vegetation"
        elif ndvi < 0.6:
            return "Dense vegetation"
        else:
            return "Very dense vegetation"
    
    def _interpret_ndre(self, ndre: float) -> str:
        """Interpret NDRE value"""
        if ndre < 0.1:
            return "Stressed vegetation"
        elif ndre < 0.2:
            return "Moderate stress"
        elif ndre < 0.3:
            return "Healthy vegetation"
        else:
            return "Very healthy vegetation"
    
    def _interpret_water(self, ndwi: float) -> str:
        """Interpret NDWI value"""
        if ndwi > 0.3:
            return "Open water"
        elif ndwi > 0.1:
            return "Wet soil or flooded"
        elif ndwi > -0.1:
            return "Dry soil"
        else:
            return "Vegetation or built-up"
    
    def _interpret_svri(self, svri: float) -> str:
        """Interpret SVRI value based on paper"""
        if svri > 0.70:
            return "Excellent - Healthy oasis"
        elif svri > 0.55:
            return "Good - Minor stress"
        elif svri > 0.40:
            return "Moderate - Significant stress"
        elif svri > 0.25:
            return "Critical - Severe stress"
        else:
            return "Collapse - Ecosystem failure"
    
    def all_indices(self, bands: Dict[str, np.ndarray]) -> Dict[str, IndexResult]:
        """
        Calculate all available indices from bands
        
        Args:
            bands: Dictionary with band names and arrays
            
        Returns:
            Dictionary of index name -> IndexResult
        """
        results = {}
        
        # Check which bands are available
        has_nir = 'nir' in bands or 'B08' in bands
        has_red = 'red' in bands or 'B04' in bands
        has_blue = 'blue' in bands or 'B02' in bands
        has_green = 'green' in bands or 'B03' in bands
        has_swir = 'swir1' in bands or 'B11' in bands
        has_red_edge = 'red_edge' in bands or 'B05' in bands
        
        # Normalize band names
        nir = bands.get('nir', bands.get('B08'))
        red = bands.get('red', bands.get('B04'))
        blue = bands.get('blue', bands.get('B02'))
        green = bands.get('green', bands.get('B03'))
        swir = bands.get('swir1', bands.get('B11'))
        red_edge = bands.get('red_edge', bands.get('B05'))
        
        if has_nir and has_red:
            results['NDVI'] = self.ndvi(nir, red)
            
            if has_blue:
                results['EVI'] = self.evi(nir, red, blue)
            
            results['SAVI'] = self.savi(nir, red)
            results['MSAVI'] = self.msavi(nir, red)
        
        if has_nir and has_red_edge:
            results['NDRE'] = self.ndre(nir, red_edge)
        
        if has_green and has_nir:
            results['NDWI'] = self.ndwi(green, nir)
        
        if has_green and has_swir:
            results['MNDWI'] = self.mndwi(green, swir)
        
        if has_swir:
            if 'swir2' in bands:
                results['NDSI'] = self.ndsi(swir, bands['swir2'])
        
        if has_green and has_blue:
            results['PRI'] = self.pri(green, blue)
        
        if has_nir and has_red and has_blue:
            results['SIPI'] = self.sipi(nir, red, blue)
        
        # SVRI composite if all components available
        if all(k in results for k in ['NDVI', 'NDRE', 'EVI']):
            # Create SWIR stress index
            if has_nir and has_swir:
                swir_stress = (nir - swir) / (nir + swir)
                swir_stress = np.clip(swir_stress, -1, 1)
                
                results['SVRI'] = self.svri_composite(
                    results['NDVI'].value,
                    results['NDRE'].value,
                    swir_stress,
                    results['EVI'].value
                )
        
        return results
