"""
SVRI: Spectral Vegetation Resilience Index Composite Builder

SVRI = 0.40·NDVI + 0.25·NDRE + 0.20·SWIR_stress + 0.15·EVI

Validated against 31 oasis sites with 93.1% accuracy
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
import json

from palma.remote_sensing.indices import SpectralIndices, IndexResult


class SVRIComposite:
    """
    Spectral Vegetation Resilience Index composite builder
    
    Combines multiple spectral indices into integrated stress indicator
    Provides 30-90 day early warning of vegetation stress
    """
    
    def __init__(self, weights: Optional[Dict[str, float]] = None):
        """
        Initialize SVRI composite
        
        Args:
            weights: Dictionary with weights for each component
                    Default: {'ndvi': 0.40, 'ndre': 0.25, 'swir': 0.20, 'evi': 0.15}
        """
        self.weights = weights or {
            'ndvi': 0.40,
            'ndre': 0.25,
            'swir': 0.20,
            'evi': 0.15
        }
        
        # Validate weights sum to 1.0
        total = sum(self.weights.values())
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"Weights must sum to 1.0, got {total}")
        
        self.indices = SpectralIndices()
        
    def compute(self, bands: Dict[str, np.ndarray]) -> IndexResult:
        """
        Compute SVRI from satellite bands
        
        Args:
            bands: Dictionary with band arrays (B02, B04, B05, B08, B11)
            
        Returns:
            IndexResult with SVRI values and interpretation
        """
        # Calculate component indices
        nir = bands.get('B08', bands.get('nir'))
        red = bands.get('B04', bands.get('red'))
        blue = bands.get('B02', bands.get('blue'))
        red_edge = bands.get('B05', bands.get('red_edge'))
        swir = bands.get('B11', bands.get('swir1'))
        
        if nir is None or red is None:
            raise ValueError("Missing required bands: NIR (B08) and Red (B04)")
        
        # NDVI
        ndvi_result = self.indices.ndvi(nir, red)
        ndvi = ndvi_result.value
        
        # NDRE (if available)
        if red_edge is not None:
            ndre_result = self.indices.ndre(nir, red_edge)
            ndre = ndre_result.value
        else:
            ndre = np.zeros_like(ndvi)
            print("Warning: Red edge band not available, NDRE set to 0")
        
        # EVI (if blue available)
        if blue is not None:
            evi_result = self.indices.evi(nir, red, blue)
            evi = evi_result.value
        else:
            evi = np.zeros_like(ndvi)
            print("Warning: Blue band not available, EVI set to 0")
        
        # SWIR stress index
        if swir is not None:
            swir_stress = (nir - swir) / (nir + swir + 1e-10)
            swir_stress = np.clip(swir_stress, -1, 1)
            # Invert so higher = more stress
            swir_norm = 1 - (swir_stress + 1) / 2
        else:
            swir_norm = np.zeros_like(ndvi)
            print("Warning: SWIR band not available, SWIR component set to 0")
        
        # Weighted composite
        svri = (self.weights['ndvi'] * ndvi +
                self.weights['ndre'] * ndre +
                self.weights['swir'] * swir_norm +
                self.weights['evi'] * evi)
        
        svri = np.clip(svri, 0, 1)
        
        mean_svri = np.nanmean(svri)
        
        return IndexResult(
            name='SVRI',
            value=svri,
            mean=mean_svri,
            std=np.nanstd(svri),
            valid_fraction=np.sum(~np.isnan(svri)) / svri.size,
            interpretation=self._interpret(mean_svri)
        )
    
    def compute_from_indices(self, ndvi: np.ndarray, ndre: np.ndarray,
                            evi: np.ndarray, swir_stress: np.ndarray) -> IndexResult:
        """
        Compute SVRI from pre-calculated indices
        
        Args:
            ndvi: NDVI array
            ndre: NDRE array
            evi: EVI array
            swir_stress: SWIR stress index array
            
        Returns:
            IndexResult with SVRI values
        """
        # Normalize SWIR stress (invert so higher = healthier)
        swir_norm = 1 - np.clip((swir_stress + 1) / 2, 0, 1)
        
        svri = (self.weights['ndvi'] * ndvi +
                self.weights['ndre'] * ndre +
                self.weights['swir'] * swir_norm +
                self.weights['evi'] * evi)
        
        svri = np.clip(svri, 0, 1)
        
        return IndexResult(
            name='SVRI',
            value=svri,
            mean=np.nanmean(svri),
            std=np.nanstd(svri),
            valid_fraction=np.sum(~np.isnan(svri)) / svri.size,
            interpretation=self._interpret(np.nanmean(svri))
        )
    
    def time_series_analysis(self, svri_series: List[np.ndarray],
                            dates: List[str]) -> Dict[str, Any]:
        """
        Analyze SVRI time series for trend and anomalies
        
        Args:
            svri_series: List of SVRI arrays over time
            dates: List of dates corresponding to each array
            
        Returns:
            Dictionary with trend analysis and anomalies
        """
        n_scenes = len(svri_series)
        
        # Calculate mean SVRI for each scene
        scene_means = [np.nanmean(svri) for svri in svri_series]
        
        # Overall statistics
        overall_mean = np.mean(scene_means)
        overall_std = np.std(scene_means)
        
        # Detect anomalies (> 2 std from mean)
        anomalies = []
        for i, mean in enumerate(scene_means):
            if abs(mean - overall_mean) > 2 * overall_std:
                anomalies.append({
                    'date': dates[i],
                    'svri': mean,
                    'z_score': (mean - overall_mean) / overall_std,
                    'type': 'low' if mean < overall_mean else 'high'
                })
        
        # Linear trend
        if n_scenes > 1:
            from scipy import stats
            x = np.arange(n_scenes)
            y = np.array(scene_means)
            
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            trend = {
                'slope_per_scene': slope,
                'slope_per_year': slope * (365 / self._average_interval(dates)),
                'r_squared': r_value**2,
                'p_value': p_value,
                'significant': p_value < 0.05
            }
        else:
            trend = None
        
        # Calculate stress duration (time with SVRI < 0.40)
        stress_duration = 0
        for mean in scene_means:
            if mean < 0.40:
                stress_duration += 1
        
        return {
            'scene_means': scene_means,
            'dates': dates,
            'overall_mean': overall_mean,
            'overall_std': overall_std,
            'trend': trend,
            'anomalies': anomalies,
            'n_scenes': n_scenes,
            'stress_duration': stress_duration,
            'stress_fraction': stress_duration / n_scenes if n_scenes > 0 else 0,
            'min_svri': min(scene_means),
            'max_svri': max(scene_means)
        }
    
    def _average_interval(self, dates: List[str]) -> float:
        """Calculate average interval between dates in days"""
        from datetime import datetime
        
        if len(dates) < 2:
            return 30  # Default
        
        date_objs = [datetime.strptime(d, '%Y-%m-%d') for d in dates]
        intervals = [(date_objs[i+1] - date_objs[i]).days for i in range(len(dates)-1)]
        
        return np.mean(intervals)
    
    def _interpret(self, svri: float) -> str:
        """Interpret SVRI value based on paper thresholds"""
        if svri > 0.70:
            return f"EXCELLENT ({svri:.3f}) - Healthy oasis, no stress"
        elif svri > 0.55:
            return f"GOOD ({svri:.3f}) - Minor stress, monitor"
        elif svri > 0.40:
            return f"MODERATE ({svri:.3f}) - Significant stress, plan intervention"
        elif svri > 0.25:
            return f"CRITICAL ({svri:.3f}) - Severe stress, immediate action required"
        else:
            return f"COLLAPSE ({svri:.3f}) - Ecosystem failure, restoration needed"
    
    def spatial_statistics(self, svri: np.ndarray, 
                          zones: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Calculate spatial statistics for SVRI
        
        Args:
            svri: SVRI array
            zones: Optional zone labels for zonal statistics
            
        Returns:
            Dictionary with spatial statistics
        """
        valid = ~np.isnan(svri)
        
        stats = {
            'mean': np.nanmean(svri),
            'std': np.nanstd(svri),
            'min': np.nanmin(svri),
            'max': np.nanmax(svri),
            'median': np.nanmedian(svri),
            'q25': np.nanpercentile(svri, 25),
            'q75': np.nanpercentile(svri, 75),
            'valid_pixels': np.sum(valid),
            'total_pixels': svri.size,
            'valid_fraction': np.sum(valid) / svri.size
        }
        
        # Calculate area by class
        class_areas = {
            'excellent': np.sum((svri > 0.70) & valid),
            'good': np.sum((svri > 0.55) & (svri <= 0.70) & valid),
            'moderate': np.sum((svri > 0.40) & (svri <= 0.55) & valid),
            'critical': np.sum((svri > 0.25) & (svri <= 0.40) & valid),
            'collapse': np.sum((svri <= 0.25) & valid)
        }
        
        # Convert to percentages
        total_valid = stats['valid_pixels']
        if total_valid > 0:
            for key in class_areas:
                class_areas[f'{key}_pct'] = class_areas[key] / total_valid * 100
        
        stats['class_areas'] = class_areas
        
        # Zonal statistics if zones provided
        if zones is not None:
            unique_zones = np.unique(zones[~np.isnan(zones)])
            zonal_stats = {}
            
            for zone in unique_zones:
                mask = (zones == zone) & valid
                if np.sum(mask) > 0:
                    zonal_stats[int(zone)] = {
                        'mean': np.nanmean(svri[mask]),
                        'std': np.nanstd(svri[mask]),
                        'area_pixels': np.sum(mask)
                    }
            
            stats['zonal_stats'] = zonal_stats
        
        return stats
    
    def export_to_geotiff(self, svri: np.ndarray, 
                         transform: Any,
                         crs: Any,
                         output_path: str) -> None:
        """
        Export SVRI to GeoTIFF
        
        Args:
            svri: SVRI array
            transform: Geotransform
            crs: Coordinate reference system
            output_path: Output file path
        """
        import rasterio
        from rasterio.transform import from_origin
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with rasterio.open(
            output_file,
            'w',
            driver='GTiff',
            height=svri.shape[0],
            width=svri.shape[1],
            count=1,
            dtype=svri.dtype,
            crs=crs,
            transform=transform,
            nodata=np.nan
        ) as dst:
            dst.write(svri, 1)
    
    def __repr__(self) -> str:
        weights_str = ", ".join([f"{k}={v}" for k, v in self.weights.items()])
        return f"SVRIComposite({weights_str})"
