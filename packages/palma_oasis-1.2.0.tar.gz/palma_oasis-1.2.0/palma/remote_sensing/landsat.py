"""
Landsat 4/5/8/9 Time Series Handler

Processes Landsat imagery for long-term trend analysis (1998-2026)
Bands:
- Landsat 4-5 TM: B1-B5, B7
- Landsat 8-9 OLI: B2-B7
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
import datetime


class LandsatProcessor:
    """
    Landsat time series processor for long-term oasis monitoring
    
    Handles:
    - Multi-sensor harmonization (TM, ETM+, OLI)
    - Cloud masking (CFMask)
    - Vegetation indices time series
    - Trend analysis
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize Landsat processor
        
        Args:
            data_dir: Directory for Landsat data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/landsat")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Sensor band mapping
        self.bands = {
            'TM': {  # Landsat 4-5
                'blue': 1,
                'green': 2,
                'red': 3,
                'nir': 4,
                'swir1': 5,
                'swir2': 7,
                'thermal': 6
            },
            'ETM': {  # Landsat 7
                'blue': 1,
                'green': 2,
                'red': 3,
                'nir': 4,
                'swir1': 5,
                'swir2': 7,
                'thermal': 6
            },
            'OLI': {  # Landsat 8-9
                'blue': 2,
                'green': 3,
                'red': 4,
                'nir': 5,
                'swir1': 6,
                'swir2': 7,
                'thermal': 10  # or 11
            }
        }
        
    def load_mtl(self, mtl_path: str) -> Dict[str, Any]:
        """
        Load Landsat MTL metadata file
        
        Args:
            mtl_path: Path to MTL.txt file
            
        Returns:
            Dictionary with metadata
        """
        metadata = {}
        
        with open(mtl_path, 'r') as f:
            for line in f:
                if '=' in line:
                    key, value = line.strip().split('=')
                    key = key.strip()
                    value = value.strip().strip('"')
                    metadata[key] = value
        
        # Extract key information
        result = {
            'sensor': metadata.get('SENSOR_ID', ''),
            'satellite': metadata.get('SPACECRAFT_ID', ''),
            'date': metadata.get('DATE_ACQUIRED', ''),
            'scene_center_time': metadata.get('SCENE_CENTER_TIME', ''),
            'sun_elevation': float(metadata.get('SUN_ELEVATION', 0)),
            'sun_azimuth': float(metadata.get('SUN_AZIMUTH', 0)),
            'cloud_cover': float(metadata.get('CLOUD_COVER', 100)),
            'full_metadata': metadata
        }
        
        return result
    
    def load_band(self, band_file: str) -> np.ndarray:
        """
        Load Landsat band GeoTIFF
        
        Args:
            band_file: Path to band file
            
        Returns:
            numpy array
        """
        import rasterio
        
        with rasterio.open(band_file) as src:
            band = src.read(1)
            meta = {
                'transform': src.transform,
                'crs': src.crs,
                'bounds': src.bounds,
                'nodata': src.nodata
            }
        
        return band, meta
    
    def load_all_bands(self, scene_dir: str, 
                      sensor: str = 'OLI') -> Dict[str, np.ndarray]:
        """
        Load all bands for a Landsat scene
        
        Args:
            scene_dir: Directory containing band files
            sensor: 'TM', 'ETM', or 'OLI'
            
        Returns:
            Dictionary with band name -> array
        """
        scene_path = Path(scene_dir)
        bands = {}
        
        band_map = self.bands[sensor]
        
        for band_name, band_num in band_map.items():
            # Find band file
            pattern = f"*_B{band_num}.TIF"
            band_files = list(scene_path.glob(pattern))
            
            if band_files:
                band, meta = self.load_band(str(band_files[0]))
                bands[band_name] = band
                bands[f'{band_name}_meta'] = meta
        
        return bands
    
    def dn_to_reflectance(self, dn: np.ndarray,
                          metadata: Dict[str, Any],
                          band_name: str) -> np.ndarray:
        """
        Convert DN to top-of-atmosphere reflectance
        
        Args:
            dn: Digital numbers
            metadata: MTL metadata
            band_name: Band name
            
        Returns:
            Reflectance (0-1)
        """
        # Get gain/offset from metadata
        gain_key = f'REFLECTANCE_MULT_BAND_{band_name}'
        offset_key = f'REFLECTANCE_ADD_BAND_{band_name}'
        
        if gain_key in metadata and offset_key in metadata:
            gain = float(metadata[gain_key])
            offset = float(metadata[offset_key])
            
            reflectance = dn * gain + offset
        else:
            # Fallback to old method
            radiance = self.dn_to_radiance(dn, metadata, band_name)
            
            # Solar irradiance (simplified)
            esun = self._get_esun(band_name, metadata.get('SATELLITE', ''))
            
            sun_elevation = float(metadata.get('SUN_ELEVATION', 45))
            cos_theta = np.sin(np.radians(sun_elevation))
            
            if cos_theta > 0:
                reflectance = (np.pi * radiance) / (esun * cos_theta)
            else:
                reflectance = np.zeros_like(dn)
        
        return np.clip(reflectance, 0, 1)
    
    def dn_to_radiance(self, dn: np.ndarray,
                       metadata: Dict[str, Any],
                       band_name: str) -> np.ndarray:
        """
        Convert DN to at-sensor radiance
        
        L = ML * DN + AL
        """
        gain_key = f'RADIANCE_MULT_BAND_{band_name}'
        offset_key = f'RADIANCE_ADD_BAND_{band_name}'
        
        if gain_key in metadata and offset_key in metadata:
            gain = float(metadata[gain_key])
            offset = float(metadata[offset_key])
            
            radiance = dn * gain + offset
        else:
            # Use old LMAX/LMIN method
            lmax_key = f'LMAX_BAND{band_name}'
            lmin_key = f'LMIN_BAND{band_name}'
            qcalmax_key = f'QCALMAX_BAND{band_name}'
            qcalmin_key = f'QCALMIN_BAND{band_name}'
            
            if all(k in metadata for k in [lmax_key, lmin_key, qcalmax_key, qcalmin_key]):
                lmax = float(metadata[lmax_key])
                lmin = float(metadata[lmin_key])
                qcalmax = float(metadata[qcalmax_key])
                qcalmin = float(metadata[qcalmin_key])
                
                radiance = ((lmax - lmin) / (qcalmax - qcalmin)) * (dn - qcalmin) + lmin
            else:
                radiance = dn * 0.1  # Rough approximation
        
        return radiance
    
    def _get_esun(self, band_name: str, satellite: str) -> float:
        """Get solar irradiance for band (W/m²/μm)"""
        # Simplified values
        esun_values = {
            'blue': 2000,
            'green': 1850,
            'red': 1600,
            'nir': 1100,
            'swir1': 250,
            'swir2': 120
        }
        
        return esun_values.get(band_name, 1000)
    
    def cloud_mask(self, bands: Dict[str, np.ndarray],
                  method: str = 'cfmask') -> np.ndarray:
        """
        Create cloud mask for Landsat scene
        
        Args:
            bands: Dictionary of bands
            method: 'cfmask' or 'fmask' or 'simple'
            
        Returns:
            Boolean mask (True = cloud)
        """
        if method == 'simple':
            # Simple cloud detection using blue band and temperature
            if 'blue' in bands and 'thermal' in bands:
                blue = bands['blue']
                thermal = bands['thermal']
                
                # Clouds are bright in blue and cold
                blue_threshold = np.percentile(blue, 80)
                thermal_threshold = np.percentile(thermal, 20)
                
                cloud_mask = (blue > blue_threshold) & (thermal < thermal_threshold)
                
                return cloud_mask
        
        # Return empty mask if no method available
        return np.zeros(bands[list(bands.keys())[0]].shape, dtype=bool)
    
    def calculate_ndvi(self, bands: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Calculate NDVI from Landsat bands
        """
        if 'nir' not in bands or 'red' not in bands:
            raise ValueError("Missing NIR or red bands")
        
        nir = bands['nir'].astype(float)
        red = bands['red'].astype(float)
        
        numerator = nir - red
        denominator = nir + red
        
        ndvi = np.zeros_like(numerator)
        mask = denominator > 0
        ndvi[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndvi, -1, 1)
    
    def calculate_ndwi(self, bands: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Calculate NDWI (water index)
        """
        if 'green' not in bands or 'nir' not in bands:
            raise ValueError("Missing green or NIR bands")
        
        green = bands['green'].astype(float)
        nir = bands['nir'].astype(float)
        
        numerator = green - nir
        denominator = green + nir
        
        ndwi = np.zeros_like(numerator)
        mask = denominator > 0
        ndwi[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndwi, -1, 1)
    
    def time_series_analysis(self, scene_list: List[str],
                            years: List[int]) -> Dict[str, Any]:
        """
        Analyze long-term time series of Landsat scenes
        
        Args:
            scene_list: List of scene directories
            years: Corresponding years
            
        Returns:
            Dictionary with trend analysis
        """
        ndvi_means = []
        valid_years = []
        
        for scene_dir, year in zip(scene_list, years):
            try:
                # Find MTL file
                scene_path = Path(scene_dir)
                mtl_files = list(scene_path.glob("*MTL.txt"))
                
                if not mtl_files:
                    continue
                
                # Determine sensor
                with open(mtl_files[0], 'r') as f:
                    content = f.read()
                    if 'LANDSAT_8' in content or 'LANDSAT_9' in content:
                        sensor = 'OLI'
                    elif 'LANDSAT_7' in content:
                        sensor = 'ETM'
                    else:
                        sensor = 'TM'
                
                # Load bands
                bands = self.load_all_bands(scene_dir, sensor)
                
                if 'nir' in bands and 'red' in bands:
                    ndvi = self.calculate_ndvi(bands)
                    ndvi_means.append(np.nanmean(ndvi))
                    valid_years.append(year)
                    
            except Exception as e:
                print(f"Error processing {scene_dir}: {e}")
                continue
        
        # Calculate trend
        if len(valid_years) > 1:
            from scipy import stats
            
            x = np.array(valid_years)
            y = np.array(ndvi_means)
            
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            trend = {
                'slope_per_year': slope,
                'intercept': intercept,
                'r_squared': r_value**2,
                'p_value': p_value,
                'std_err': std_err
            }
        else:
            trend = None
        
        return {
            'years': valid_years,
            'ndvi_means': ndvi_means,
            'n_scenes': len(valid_years),
            'trend': trend,
            'mean_ndvi': np.mean(ndvi_means) if ndvi_means else None,
            'ndvi_change': ndvi_means[-1] - ndvi_means[0] if len(ndvi_means) > 1 else None
        }
    
    def __repr__(self) -> str:
        return f"LandsatProcessor(data_dir={self.data_dir})"
