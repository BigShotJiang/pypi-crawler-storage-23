"""
Cloud Masking and Gap-filling for Satellite Imagery

Implements:
- Multi-spectral cloud detection
- Cloud shadow detection
- Savitzky-Golay gap filling
- Time series interpolation
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from scipy import ndimage
from scipy.signal import savgol_filter
from scipy.interpolate import interp1d


class CloudMask:
    """
    Cloud and cloud shadow detection for optical satellite imagery
    
    Uses multiple criteria:
    - Brightness in visible bands
    - Temperature (if available)
    - NDVI thresholds
    - Temporal consistency
    """
    
    def __init__(self, cloud_threshold: float = 0.2,
                 shadow_threshold: float = 0.1):
        """
        Initialize cloud mask
        
        Args:
            cloud_threshold: Cloud probability threshold
            shadow_threshold: Shadow detection threshold
        """
        self.cloud_threshold = cloud_threshold
        self.shadow_threshold = shadow_threshold
        
    def detect_clouds(self, bands: Dict[str, np.ndarray],
                     thermal: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Detect clouds using multiple criteria
        
        Args:
            bands: Dictionary of optical bands
            thermal: Optional thermal band
            
        Returns:
            Boolean mask (True = cloud)
        """
        # Start with all clear
        height, width = bands[list(bands.keys())[0]].shape
        cloud_mask = np.zeros((height, width), dtype=bool)
        
        # Brightness test (clouds are bright)
        if 'B02' in bands and 'B03' in bands and 'B04' in bands:
            # Use visible bands
            brightness = (bands['B02'] + bands['B03'] + bands['B04']) / 3
            
            # Normalize to 0-1
            brightness_norm = (brightness - np.nanmin(brightness)) / (np.nanmax(brightness) - np.nanmin(brightness) + 1e-10)
            
            bright_cloud = brightness_norm > 0.8
            cloud_mask = cloud_mask | bright_cloud
        
        # Whiteness test (clouds are white - similar in all bands)
        if 'B02' in bands and 'B03' in bands and 'B04' in bands:
            blue = bands['B02']
            green = bands['B03']
            red = bands['B04']
            
            # Standard deviation across bands
            band_stack = np.stack([blue, green, red], axis=2)
            band_std = np.std(band_stack, axis=2)
            
            # Normalize
            band_std_norm = (band_std - np.nanmin(band_std)) / (np.nanmax(band_std) - np.nanmin(band_std) + 1e-10)
            
            # Clouds have low spectral variability
            white_cloud = band_std_norm < 0.2
            cloud_mask = cloud_mask | white_cloud
        
        # Temperature test (if thermal available)
        if thermal is not None:
            # Clouds are cold
            cold_cloud = thermal < np.nanpercentile(thermal, 20)
            cloud_mask = cloud_mask | cold_cloud
        
        # NDVI test (clouds have low NDVI)
        if 'B04' in bands and 'B08' in bands:
            nir = bands['B08']
            red = bands['B04']
            
            ndvi = (nir - red) / (nir + red + 1e-10)
            low_ndvi = ndvi < 0.1
            
            cloud_mask = cloud_mask & low_ndvi  # Only count if also low NDVI
        
        # Morphological cleaning
        cloud_mask = ndimage.binary_erosion(cloud_mask, structure=np.ones((3,3)))
        cloud_mask = ndimage.binary_dilation(cloud_mask, structure=np.ones((5,5)))
        
        return cloud_mask
    
    def detect_shadows(self, bands: Dict[str, np.ndarray],
                      cloud_mask: np.ndarray,
                      sun_azimuth: float,
                      sun_elevation: float) -> np.ndarray:
        """
        Detect cloud shadows based on geometry
        
        Args:
            bands: Dictionary of bands
            cloud_mask: Detected cloud mask
            sun_azimuth: Sun azimuth angle (degrees)
            sun_elevation: Sun elevation angle (degrees)
            
        Returns:
            Boolean shadow mask
        """
        if np.sum(cloud_mask) == 0:
            return np.zeros_like(cloud_mask)
        
        # Estimate shadow displacement
        # Shadow distance = cloud_height / tan(sun_elevation)
        # Assume cloud height ~ 2 km (typical)
        cloud_height = 2000  # meters
        
        # Convert angles to radians
        sun_az_rad = np.radians(sun_azimuth)
        sun_el_rad = np.radians(sun_elevation)
        
        # Shadow displacement (pixels)
        # This is simplified - would need pixel size
        shadow_distance = cloud_height / np.tan(sun_el_rad)
        
        # Direction (opposite of sun)
        dx = -shadow_distance * np.sin(sun_az_rad)
        dy = -shadow_distance * np.cos(sun_az_rad)
        
        # Shift cloud mask to get shadow candidate
        from scipy.ndimage import shift
        shadow_candidate = shift(cloud_mask.astype(float), (dy, dx), order=0) > 0.5
        
        # Shadows are dark
        if 'B04' in bands:
            red = bands['B04']
            dark = red < np.nanpercentile(red, 30)
            shadow_mask = shadow_candidate & dark
        else:
            shadow_mask = shadow_candidate
        
        return shadow_mask
    
    def fmask(self, bands: Dict[str, np.ndarray],
             thermal: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
        """
        Fmask (Function of mask) algorithm implementation
        
        Returns:
            Dictionary with cloud, shadow, and water masks
        """
        # Initialize
        cloud_mask = self.detect_clouds(bands, thermal)
        
        # Shadow mask (simplified)
        shadow_mask = np.zeros_like(cloud_mask)
        
        # Water detection
        water_mask = np.zeros_like(cloud_mask)
        if 'B03' in bands and 'B08' in bands:
            green = bands['B03']
            nir = bands['B08']
            
            ndwi = (green - nir) / (green + nir + 1e-10)
            water_mask = ndwi > 0.3
        
        # Snow detection (simplified)
        snow_mask = np.zeros_like(cloud_mask)
        if 'B03' in bands and 'B04' in bands:
            green = bands['B03']
            red = bands['B04']
            
            ndsi = (green - red) / (green + red + 1e-10)
            snow_mask = (ndsi > 0.4) & (red > 0.2)
        
        # Combine
        clear_mask = ~(cloud_mask | shadow_mask | snow_mask)
        
        return {
            'cloud': cloud_mask,
            'shadow': shadow_mask,
            'water': water_mask,
            'snow': snow_mask,
            'clear': clear_mask
        }
    
    def apply_mask(self, array: np.ndarray, mask: np.ndarray,
                  fill_value: float = np.nan) -> np.ndarray:
        """
        Apply mask to array
        
        Args:
            array: Input array
            mask: Boolean mask (True = masked)
            fill_value: Value to fill masked pixels
            
        Returns:
            Masked array
        """
        result = array.copy()
        result[mask] = fill_value
        return result


class GapFilling:
    """
    Gap filling for time series of satellite data
    
    Methods:
    - Savitzky-Golay smoothing
    - Linear interpolation
    - Harmonic analysis
    - Spatial-temporal filling
    """
    
    def __init__(self):
        """Initialize gap filling"""
        pass
    
    def savitzky_golay(self, series: np.ndarray,
                       window_length: int = 7,
                       polyorder: int = 2) -> np.ndarray:
        """
        Savitzky-Golay filter for time series smoothing
        
        Args:
            series: 1D time series with possible NaNs
            window_length: Length of filter window (odd)
            polyorder: Polynomial order
            
        Returns:
            Smoothed series
        """
        # Handle NaNs by interpolation first
        filled = self.linear_interpolation(series)
        
        # Apply Savitzky-Golay
        try:
            smoothed = savgol_filter(filled, window_length, polyorder)
        except:
            # If window too large, return original
            smoothed = filled
        
        return smoothed
    
    def linear_interpolation(self, series: np.ndarray) -> np.ndarray:
        """
        Linear interpolation for missing values
        
        Args:
            series: 1D time series with NaNs
            
        Returns:
            Interpolated series
        """
        x = np.arange(len(series))
        mask = ~np.isnan(series)
        
        if np.sum(mask) < 2:
            return series
        
        interp_func = interp1d(x[mask], series[mask], 
                               kind='linear', 
                               bounds_error=False,
                               fill_value='extrapolate')
        
        return interp_func(x)
    
    def harmonic_analysis(self, series: np.ndarray,
                         n_harmonics: int = 3) -> np.ndarray:
        """
        Harmonic analysis for seasonal time series
        
        Args:
            series: 1D time series
            n_harmonics: Number of harmonics to fit
            
        Returns:
            Reconstructed series
        """
        n = len(series)
        t = np.arange(n)
        
        # Remove mean
        mean_val = np.nanmean(series)
        series_detrend = series - mean_val
        
        # Handle NaNs
        mask = ~np.isnan(series_detrend)
        t_valid = t[mask]
        y_valid = series_detrend[mask]
        
        if len(y_valid) < 2 * n_harmonics + 1:
            return series
        
        # Build harmonic model
        A = np.zeros((len(y_valid), 2 * n_harmonics + 1))
        A[:, 0] = 1
        
        for i in range(1, n_harmonics + 1):
            A[:, 2*i-1] = np.sin(2 * np.pi * i * t_valid / 365)
            A[:, 2*i] = np.cos(2 * np.pi * i * t_valid / 365)
        
        # Solve least squares
        coeffs, _, _, _ = np.linalg.lstsq(A, y_valid, rcond=None)
        
        # Reconstruct
        A_full = np.zeros((n, 2 * n_harmonics + 1))
        A_full[:, 0] = 1
        
        for i in range(1, n_harmonics + 1):
            A_full[:, 2*i-1] = np.sin(2 * np.pi * i * t / 365)
            A_full[:, 2*i] = np.cos(2 * np.pi * i * t / 365)
        
        reconstructed = A_full @ coeffs + mean_val
        
        return reconstructed
    
    def whittaker_smooth(self, series: np.ndarray,
                        lambda_param: float = 1.0) -> np.ndarray:
        """
        Whittaker smoother (penalized least squares)
        
        Args:
            series: 1D time series with NaNs
            lambda_param: Smoothing parameter
            
        Returns:
            Smoothed series
        """
        n = len(series)
        
        # Handle NaNs
        w = (~np.isnan(series)).astype(float)
        y = np.nan_to_num(series, nan=0)
        
        # Build difference matrix
        import scipy.sparse as sp
        from scipy.sparse.linalg import spsolve
        
        E = sp.eye(n)
        D = sp.diags([-1, 2, -1], [-1, 0, 1], shape=(n-2, n))
        
        # Solve (W + λ D'D) z = W y
        W = sp.diags(w)
        A = W + lambda_param * D.T @ D
        b = W @ y
        
        z = spsolve(A, b)
        
        return z
    
    def spatial_temporal_fill(self, data_3d: np.ndarray,
                             mask_3d: np.ndarray,
                             method: str = 'nearest') -> np.ndarray:
        """
        Fill gaps using spatial-temporal information
        
        Args:
            data_3d: 3D array (time, y, x)
            mask_3d: Boolean mask (True = gap)
            method: Interpolation method
            
        Returns:
            Filled array
        """
        from scipy.interpolate import griddata
        
        filled = data_3d.copy()
        n_time, ny, nx = data_3d.shape
        
        for t in range(n_time):
            data = data_3d[t]
            mask = mask_3d[t]
            
            if np.sum(mask) == 0:
                continue
            
            # Get valid points
            valid_y, valid_x = np.where(~mask)
            valid_values = data[~mask]
            
            if len(valid_values) < 3:
                continue
            
            # Get gap points
            gap_y, gap_x = np.where(mask)
            
            # Interpolate
            if method == 'nearest':
                from scipy.spatial import cKDTree
                tree = cKDTree(np.column_stack([valid_y, valid_x]))
                dist, idx = tree.query(np.column_stack([gap_y, gap_x]), k=1)
                filled[t, gap_y, gap_x] = valid_values[idx]
            
            elif method == 'linear':
                points = np.column_stack([valid_y, valid_x])
                values = valid_values
                xi = np.column_stack([gap_y, gap_x])
                
                interpolated = griddata(points, values, xi, method='linear')
                filled[t, gap_y, gap_x] = interpolated
            
            elif method == 'cubic':
                points = np.column_stack([valid_y, valid_x])
                values = valid_values
                xi = np.column_stack([gap_y, gap_x])
                
                interpolated = griddata(points, values, xi, method='cubic')
                filled[t, gap_y, gap_x] = interpolated
        
        return filled
    
    def temporal_median_fill(self, data_3d: np.ndarray,
                            mask_3d: np.ndarray,
                            window: int = 3) -> np.ndarray:
        """
        Fill gaps using temporal median
        
        Args:
            data_3d: 3D array (time, y, x)
            mask_3d: Boolean mask
            window: Temporal window size
            
        Returns:
            Filled array
        """
        filled = data_3d.copy()
        n_time, ny, nx = data_3d.shape
        
        for t in range(n_time):
            for i in range(ny):
                for j in range(nx):
                    if mask_3d[t, i, j]:
                        # Get temporal neighbors
                        t_start = max(0, t - window)
                        t_end = min(n_time, t + window + 1)
                        
                        neighbor_values = []
                        for t2 in range(t_start, t_end):
                            if t2 != t and not mask_3d[t2, i, j]:
                                neighbor_values.append(data_3d[t2, i, j])
                        
                        if neighbor_values:
                            filled[t, i, j] = np.median(neighbor_values)
        
        return filled
    
    def __repr__(self) -> str:
        return "GapFilling()"
