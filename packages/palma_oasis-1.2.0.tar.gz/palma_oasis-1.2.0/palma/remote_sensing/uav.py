"""
UAV Thermal and Multispectral Processor for Oasis Monitoring

Processes:
- Thermal imagery (FLIR Zenmuse XT2)
- Multispectral (Micasense RedEdge)
- RGB photogrammetry
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
import json


class UAVProcessor:
    """
    Unmanned Aerial Vehicle data processor
    
    Handles:
    - Thermal orthomosaics
    - Multispectral reflectance
    - Canopy height models
    - Temperature validation
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize UAV processor
        
        Args:
            data_dir: Directory for UAV data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/uav")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Thermal camera parameters (FLIR Zenmuse XT2)
        self.thermal_params = {
            'emissivity': 0.98,
            'reflected_temp': 25.0,  # °C
            'air_temp': 25.0,
            'relative_humidity': 50,
            'distance': 30  # meters
        }
        
    def load_thermal_image(self, image_path: str) -> Dict[str, Any]:
        """
        Load thermal image with metadata
        
        Args:
            image_path: Path to thermal image (TIFF or JPG)
            
        Returns:
            Dictionary with temperature array and metadata
        """
        import rasterio
        from PIL import Image
        import exifread
        
        path = Path(image_path)
        
        if path.suffix.lower() in ['.tif', '.tiff']:
            # GeoTIFF with thermal data
            with rasterio.open(path) as src:
                thermal_raw = src.read(1)
                meta = {
                    'transform': src.transform,
                    'crs': src.crs,
                    'bounds': src.bounds,
                    'nodata': src.nodata
                }
        else:
            # JPEG with EXIF
            img = Image.open(path)
            thermal_raw = np.array(img)
            
            # Extract EXIF metadata
            with open(path, 'rb') as f:
                tags = exifread.process_file(f)
            
            meta = {'exif': {str(k): str(v) for k, v in tags.items()}}
        
        return {
            'raw': thermal_raw,
            'metadata': meta
        }
    
    def raw_to_temperature(self, raw: np.ndarray,
                          params: Optional[Dict] = None) -> np.ndarray:
        """
        Convert raw thermal values to temperature (°C)
        
        Args:
            raw: Raw thermal image values
            params: Camera parameters
            
        Returns:
            Temperature array (°C)
        """
        if params is None:
            params = self.thermal_params
        
        # FLIR radiometric conversion (simplified)
        # Raw to radiance
        R = 17340  # FLIR constant
        B = 1430   # FLIR constant
        F = 1.0    # FLIR constant
        J1 = 16383 # FLIR constant
        
        # Raw to temperature
        # T = B / ln(R / (raw - J1 * F) + F)
        
        # Simplified linear approximation for common range
        # 0-65535 raw -> -40 to 160°C
        temperature = -40 + 200 * (raw / 65535)
        
        # Apply corrections
        # Emissivity correction
        if params['emissivity'] != 1.0:
            # Simplified correction
            temperature = temperature / params['emissivity']
        
        return temperature
    
    def create_thermal_orthomosaic(self, image_list: List[str],
                                   outputs_dir: str) -> Dict[str, Any]:
        """
        Create thermal orthomosaic from multiple images
        
        Args:
            image_list: List of thermal image paths
            outputs_dir: Output directory
            
        Returns:
            Dictionary with orthomosaic info
        """
        # This would typically use photogrammetry software
        # Simplified version - just load and merge
        
        temperatures = []
        
        for img_path in image_list:
            data = self.load_thermal_image(img_path)
            temp = self.raw_to_temperature(data['raw'])
            temperatures.append(temp)
        
        # Simple average (would need proper georeferencing)
        if temperatures:
            mosaic = np.mean(temperatures, axis=0)
        else:
            mosaic = np.array([])
        
        output_path = Path(outputs_dir) / "thermal_mosaic.tif"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save (simplified - would need georeferencing)
        np.save(output_path.with_suffix('.npy'), mosaic)
        
        return {
            'mosaic': mosaic,
            'n_images': len(image_list),
            'output_path': str(output_path),
            'mean_temp': np.mean(mosaic),
            'max_temp': np.max(mosaic),
            'min_temp': np.min(mosaic)
        }
    
    def load_multispectral(self, image_path: str) -> Dict[str, np.ndarray]:
        """
        Load multispectral image (Micasense RedEdge)
        
        Args:
            image_path: Path to multispectral image
            
        Returns:
            Dictionary with bands
        """
        import rasterio
        
        bands = {}
        
        with rasterio.open(image_path) as src:
            for i in range(1, src.count + 1):
                band_name = f'B{i:02d}'
                bands[band_name] = src.read(i)
                bands[f'{band_name}_meta'] = {
                    'transform': src.transform,
                    'crs': src.crs
                }
        
        # Standard band mapping for RedEdge
        # B1: Blue (475 nm)
        # B2: Green (560 nm)
        # B3: Red (668 nm)
        # B4: Red Edge (717 nm)
        # B5: NIR (842 nm)
        
        return bands
    
    def calculate_ndvi_from_uav(self, bands: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Calculate NDVI from UAV multispectral
        
        NDVI = (NIR - Red) / (NIR + Red)
        """
        nir = bands.get('B05')  # RedEdge NIR band
        red = bands.get('B03')  # RedEdge red band
        
        if nir is None or red is None:
            raise ValueError("Missing NIR or red bands")
        
        numerator = nir - red
        denominator = nir + red
        
        ndvi = np.zeros_like(numerator)
        mask = denominator > 0
        ndvi[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndvi, -1, 1)
    
    def calculate_canopy_height(self, point_cloud: np.ndarray,
                               dtm: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Calculate canopy height from LiDAR or photogrammetry point cloud
        
        Args:
            point_cloud: Nx3 array of points (x, y, z)
            dtm: Digital Terrain Model (if None, use minimum z)
            
        Returns:
            Canopy height model
        """
        if dtm is None:
            # Use minimum z as ground
            ground_z = np.min(point_cloud[:, 2])
        else:
            ground_z = dtm
        
        canopy_height = point_cloud[:, 2] - ground_z
        
        return canopy_height
    
    def extract_canopy_temperature(self, thermal: np.ndarray,
                                  canopy_mask: np.ndarray) -> Dict[str, float]:
        """
        Extract canopy temperature statistics
        
        Args:
            thermal: Thermal image
            canopy_mask: Boolean mask of canopy pixels
            
        Returns:
            Temperature statistics
        """
        canopy_temps = thermal[canopy_mask]
        
        return {
            'mean': np.mean(canopy_temps),
            'std': np.std(canopy_temps),
            'max': np.max(canopy_temps),
            'min': np.min(canopy_temps),
            'q25': np.percentile(canopy_temps, 25),
            'q75': np.percentile(canopy_temps, 75),
            'canopy_area_pixels': np.sum(canopy_mask)
        }
    
    def validate_satellite_lst(self, uav_thermal: np.ndarray,
                              satellite_lst: np.ndarray,
                              uav_resolution: float = 0.1,
                              satellite_resolution: float = 30) -> Dict[str, float]:
        """
        Validate satellite LST using UAV thermal data
        
        Args:
            uav_thermal: High-resolution UAV thermal
            satellite_lst: Coarse satellite LST
            uav_resolution: UAV pixel size (m)
            satellite_resolution: Satellite pixel size (m)
            
        Returns:
            Validation metrics
        """
        from scipy.ndimage import zoom
        
        # Aggregate UAV to satellite resolution
        scale_factor = satellite_resolution / uav_resolution
        uav_aggregated = zoom(uav_thermal, 1/scale_factor, order=1)
        
        # Match sizes
        min_h = min(uav_aggregated.shape[0], satellite_lst.shape[0])
        min_w = min(uav_aggregated.shape[1], satellite_lst.shape[1])
        
        uav_crop = uav_aggregated[:min_h, :min_w]
        sat_crop = satellite_lst[:min_h, :min_w]
        
        # Calculate metrics
        valid = ~(np.isnan(uav_crop) | np.isnan(sat_crop))
        
        if np.sum(valid) == 0:
            return {'error': 'No valid pixels'}
        
        bias = np.mean(uav_crop[valid] - sat_crop[valid])
        rmse = np.sqrt(np.mean((uav_crop[valid] - sat_crop[valid])**2))
        r2 = np.corrcoef(uav_crop[valid], sat_crop[valid])[0, 1]**2
        
        return {
            'bias': bias,
            'rmse': rmse,
            'r2': r2,
            'n_pixels': np.sum(valid),
            'uav_mean': np.mean(uav_crop[valid]),
            'satellite_mean': np.mean(sat_crop[valid])
        }
    
    def detect_water_stress(self, thermal: np.ndarray,
                           ndvi: np.ndarray,
                           threshold_temp: float = 35.0) -> np.ndarray:
        """
        Detect water stress using thermal and NDVI
        
        Args:
            thermal: Canopy temperature (°C)
            ndvi: NDVI array
            threshold_temp: Temperature threshold for stress
            
        Returns:
            Stress mask
        """
        # Vegetation pixels only
        veg_mask = ndvi > 0.3
        
        # Hot vegetation = stressed
        stress_mask = veg_mask & (thermal > threshold_temp)
        
        return stress_mask
    
    def flight_plan_coverage(self, waypoints: List[Tuple[float, float]],
                            footprint_width: float = 100) -> Dict[str, Any]:
        """
        Calculate coverage from UAV flight plan
        
        Args:
            waypoints: List of (lat, lon) waypoints
            footprint_width: Image footprint width (m)
            
        Returns:
            Coverage statistics
        """
        if len(waypoints) < 2:
            return {'error': 'Need at least 2 waypoints'}
        
        # Calculate total distance
        from haversine import haversine
        
        total_distance = 0
        for i in range(len(waypoints) - 1):
            total_distance += haversine(waypoints[i], waypoints[i+1]) * 1000  # km to m
        
        # Estimated coverage area
        coverage_area = total_distance * footprint_width  # m²
        
        # Flight time (assuming 5 m/s)
        flight_time = total_distance / 5  # seconds
        
        return {
            'waypoints': len(waypoints),
            'total_distance_m': total_distance,
            'coverage_area_ha': coverage_area / 10000,
            'flight_time_min': flight_time / 60,
            'estimated_images': int(total_distance / 50)  # Assume image every 50m
        }
    
    def __repr__(self) -> str:
        return f"UAVProcessor(data_dir={self.data_dir})"
