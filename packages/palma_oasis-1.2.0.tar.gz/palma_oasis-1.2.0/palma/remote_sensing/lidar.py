"""
LiDAR Processor for Canopy Height Model and LAI Inversion

Processes:
- Point cloud classification
- Digital Terrain Model (DTM)
- Digital Surface Model (DSM)
- Canopy Height Model (CHM)
- Leaf Area Index (LAI) inversion
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
import json


class LiDARProcessor:
    """
    LiDAR data processor for canopy structure analysis
    
    Handles:
    - Point cloud filtering
    - Ground classification
    - Canopy height extraction
    - LAI estimation from lidar
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize LiDAR processor
        
        Args:
            data_dir: Directory for LiDAR data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/lidar")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
    def load_las(self, filepath: str) -> Dict[str, np.ndarray]:
        """
        Load LAS/LAZ point cloud file
        
        Args:
            filepath: Path to LAS file
            
        Returns:
            Dictionary with point cloud data
        """
        import laspy
        
        las = laspy.read(filepath)
        
        # Extract basic fields
        points = {
            'x': las.x,
            'y': las.y,
            'z': las.z,
            'intensity': las.intensity,
            'classification': las.classification,
            'return_number': las.return_number,
            'number_of_returns': las.number_of_returns,
            'scan_angle': las.scan_angle,
            'gps_time': las.gps_time if hasattr(las, 'gps_time') else None
        }
        
        # Add RGB if available
        if hasattr(las, 'red'):
            points['red'] = las.red
            points['green'] = las.green
            points['blue'] = las.blue
        
        return points
    
    def classify_ground(self, points: Dict[str, np.ndarray],
                       cell_size: float = 1.0,
                       max_slope: float = 0.1) -> np.ndarray:
        """
        Classify ground points using simple slope filter
        
        Args:
            points: Point cloud dictionary
            cell_size: Grid cell size for DTM
            max_slope: Maximum slope for ground classification
            
        Returns:
            Boolean mask of ground points
        """
        x = points['x']
        y = points['y']
        z = points['z']
        
        # Create grid
        x_min, x_max = np.min(x), np.max(x)
        y_min, y_max = np.min(y), np.max(y)
        
        nx = int((x_max - x_min) / cell_size) + 1
        ny = int((y_max - y_min) / cell_size) + 1
        
        # Initialize grid with minimum z
        grid_min = np.full((ny, nx), np.inf)
        grid_count = np.zeros((ny, nx))
        
        for i in range(len(x)):
            xi = int((x[i] - x_min) / cell_size)
            yi = int((y[i] - y_min) / cell_size)
            
            if 0 <= xi < nx and 0 <= yi < ny:
                if z[i] < grid_min[yi, xi]:
                    grid_min[yi, xi] = z[i]
                grid_count[yi, xi] += 1
        
        # Classify points as ground if within threshold of grid minimum
        ground_mask = np.zeros(len(x), dtype=bool)
        
        for i in range(len(x)):
            xi = int((x[i] - x_min) / cell_size)
            yi = int((y[i] - y_min) / cell_size)
            
            if 0 <= xi < nx and 0 <= yi < ny:
                if grid_min[yi, xi] != np.inf:
                    if z[i] - grid_min[yi, xi] < max_slope * cell_size:
                        ground_mask[i] = True
        
        return ground_mask
    
    def create_dtm(self, points: Dict[str, np.ndarray],
                  ground_mask: np.ndarray,
                  resolution: float = 1.0) -> np.ndarray:
        """
        Create Digital Terrain Model from ground points
        
        Args:
            points: Point cloud dictionary
            ground_mask: Boolean mask of ground points
            resolution: Grid resolution (m)
            
        Returns:
            DTM array
        """
        x = points['x'][ground_mask]
        y = points['y'][ground_mask]
        z = points['z'][ground_mask]
        
        if len(x) == 0:
            return np.array([])
        
        # Create grid
        x_min, x_max = np.min(x), np.max(x)
        y_min, y_max = np.min(y), np.max(y)
        
        nx = int((x_max - x_min) / resolution) + 1
        ny = int((y_max - y_min) / resolution) + 1
        
        dtm = np.full((ny, nx), np.nan)
        count = np.zeros((ny, nx))
        
        # Simple binning with mean
        from scipy.spatial import cKDTree
        
        # Build KD-tree for interpolation
        tree = cKDTree(np.column_stack([x, y]))
        
        for yi in range(ny):
            for xi in range(nx):
                center_x = x_min + xi * resolution + resolution/2
                center_y = y_min + yi * resolution + resolution/2
                
                # Find points within radius
                indices = tree.query_ball_point([center_x, center_y], resolution)
                
                if indices:
                    dtm[yi, xi] = np.mean(z[indices])
                    count[yi, xi] = len(indices)
        
        return dtm
    
    def create_dsm(self, points: Dict[str, np.ndarray],
                  resolution: float = 1.0) -> np.ndarray:
        """
        Create Digital Surface Model (highest returns)
        
        Args:
            points: Point cloud dictionary
            resolution: Grid resolution (m)
            
        Returns:
            DSM array
        """
        x = points['x']
        y = points['y']
        z = points['z']
        
        # Create grid
        x_min, x_max = np.min(x), np.max(x)
        y_min, y_max = np.min(y), np.max(y)
        
        nx = int((x_max - x_min) / resolution) + 1
        ny = int((y_max - y_min) / resolution) + 1
        
        dsm = np.full((ny, nx), np.nan)
        
        # For each point, update grid cell with max z
        for i in range(len(x)):
            xi = int((x[i] - x_min) / resolution)
            yi = int((y[i] - y_min) / resolution)
            
            if 0 <= xi < nx and 0 <= yi < ny:
                if np.isnan(dsm[yi, xi]) or z[i] > dsm[yi, xi]:
                    dsm[yi, xi] = z[i]
        
        return dsm
    
    def create_chm(self, dsm: np.ndarray, dtm: np.ndarray) -> np.ndarray:
        """
        Create Canopy Height Model
        
        CHM = DSM - DTM
        """
        if dsm.shape != dtm.shape:
            raise ValueError("DSM and DTM must have same shape")
        
        chm = dsm - dtm
        chm[chm < 0] = 0  # Height can't be negative
        
        return chm
    
    def extract_tree_crowns(self, chm: np.ndarray,
                           min_height: float = 2.0,
                           resolution: float = 1.0) -> Dict[str, Any]:
        """
        Extract individual tree crowns from CHM
        
        Args:
            chm: Canopy Height Model
            min_height: Minimum height for tree
            resolution: Pixel resolution (m)
            
        Returns:
            Dictionary with tree statistics
        """
        from scipy import ndimage
        from skimage import measure
        
        # Mask for vegetation
        veg_mask = chm > min_height
        
        # Label connected components
        labeled, n_trees = ndimage.label(veg_mask)
        
        # Extract tree properties
        trees = []
        heights = []
        areas = []
        
        for i in range(1, n_trees + 1):
            tree_mask = labeled == i
            tree_height = np.max(chm[tree_mask])
            tree_area = np.sum(tree_mask) * resolution**2
            
            if tree_area > 0:
                trees.append({
                    'id': i,
                    'height': tree_height,
                    'area_m2': tree_area,
                    'centroid': ndimage.center_of_mass(tree_mask)
                })
                heights.append(tree_height)
                areas.append(tree_area)
        
        return {
            'n_trees': n_trees,
            'trees': trees,
            'mean_height': np.mean(heights) if heights else 0,
            'max_height': np.max(heights) if heights else 0,
            'total_canopy_area': np.sum(areas),
            'canopy_cover': np.sum(veg_mask) / chm.size * 100
        }
    
    def estimate_lai(self, chm: np.ndarray,
                    method: str = 'beer_lambert',
                    k_extinction: float = 0.52) -> np.ndarray:
        """
        Estimate Leaf Area Index from canopy height
        
        Args:
            chm: Canopy Height Model
            method: Inversion method
            k_extinction: Beer-Lambert extinction coefficient
            
        Returns:
            LAI array
        """
        if method == 'beer_lambert':
            # Simple Beer-Lambert inversion
            # Assumes exponential relationship between height and LAI
            lai = k_extinction * chm / 2  # Simplified
            lai[chm < 0.5] = 0
            
        elif method == 'empirical':
            # Empirical relationship from field measurements
            # LAI = a * ln(height) + b
            a = 2.5
            b = 1.0
            lai = a * np.log(np.maximum(chm, 1)) + b
            
        elif method == 'allometric':
            # Allometric relationship
            # LAI = c * height^d
            c = 0.8
            d = 0.7
            lai = c * chm ** d
            
        else:
            lai = np.zeros_like(chm)
        
        return np.clip(lai, 0, 8)
    
    def calculate_gap_fraction(self, points: Dict[str, np.ndarray],
                              grid_size: float = 10.0) -> np.ndarray:
        """
        Calculate gap fraction from point cloud
        
        Args:
            points: Point cloud dictionary
            grid_size: Grid size for analysis (m)
            
        Returns:
            Gap fraction array
        """
        x = points['x']
        y = points['y']
        z = points['z']
        
        # Create grid
        x_min, x_max = np.min(x), np.max(x)
        y_min, y_max = np.min(y), np.max(y)
        
        nx = int((x_max - x_min) / grid_size) + 1
        ny = int((y_max - y_min) / grid_size) + 1
        
        gap_fraction = np.zeros((ny, nx))
        
        # For each grid cell
        for yi in range(ny):
            for xi in range(nx):
                x_start = x_min + xi * grid_size
                x_end = x_start + grid_size
                y_start = y_min + yi * grid_size
                y_end = y_start + grid_size
                
                # Points in this cell
                mask = ((x >= x_start) & (x < x_end) & 
                       (y >= y_start) & (y < y_end))
                
                if np.sum(mask) == 0:
                    gap_fraction[yi, xi] = 1.0  # Complete gap
                else:
                    # Count returns above 2m as vegetation
                    veg_mask = mask & (z > 2.0)
                    gap_fraction[yi, xi] = 1 - np.sum(veg_mask) / np.sum(mask)
        
        return gap_fraction
    
    def vertical_profile(self, points: Dict[str, np.ndarray],
                        z_bins: np.ndarray) -> np.ndarray:
        """
        Calculate vertical profile of vegetation
        
        Args:
            points: Point cloud dictionary
            z_bins: Height bins
            
        Returns:
            Profile of point density by height
        """
        z = points['z']
        classification = points.get('classification', np.zeros_like(z))
        
        # Vegetation returns (class 3-5 typically)
        veg_mask = (classification >= 3) & (classification <= 5)
        veg_z = z[veg_mask]
        
        profile, _ = np.histogram(veg_z, bins=z_bins)
        
        return profile
    
    def export_to_raster(self, array: np.ndarray,
                        bounds: Tuple[float, float, float, float],
                        resolution: float,
                        output_path: str) -> None:
        """
        Export array to GeoTIFF
        
        Args:
            array: 2D array
            bounds: (xmin, ymin, xmax, ymax)
            resolution: Pixel resolution
            output_path: Output file path
        """
        import rasterio
        from rasterio.transform import from_origin
        
        xmin, ymin, xmax, ymax = bounds
        transform = from_origin(xmin, ymax, resolution, resolution)
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with rasterio.open(
            output_file,
            'w',
            driver='GTiff',
            height=array.shape[0],
            width=array.shape[1],
            count=1,
            dtype=array.dtype,
            crs='EPSG:4326',  # Assume WGS84
            transform=transform,
            nodata=np.nan
        ) as dst:
            dst.write(array, 1)
    
    def __repr__(self) -> str:
        return f"LiDARProcessor(data_dir={self.data_dir})"
