"""
MODIS Processor for Daily ET and Land Surface Temperature

Products:
- MOD11A1: Daily Land Surface Temperature
- MOD16A2: Evapotranspiration
- MOD13Q1: Vegetation Indices
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
import datetime


class MODISProcessor:
    """
    MODIS Terra/Aqua data processor
    
    Handles:
    - Daily LST (MOD11A1)
    - 8-day ET (MOD16A2)
    - 16-day vegetation indices (MOD13Q1)
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize MODIS processor
        
        Args:
            data_dir: Directory for MODIS data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/modis")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Product names
        self.products = {
            'lst': 'MOD11A1',      # Land Surface Temperature
            'et': 'MOD16A2',        # Evapotranspiration
            'ndvi': 'MOD13Q1',      # Vegetation Indices
            'lst_night': 'MYD11A1',  # Aqua night LST
        }
        
    def load_hdf(self, filepath: str, dataset_name: str) -> np.ndarray:
        """
        Load dataset from MODIS HDF file
        
        Args:
            filepath: Path to HDF file
            dataset_name: Name of dataset to load
            
        Returns:
            numpy array
        """
        import h5py
        
        with h5py.File(filepath, 'r') as f:
            # Navigate to dataset
            if dataset_name in f:
                data = f[dataset_name][()]
            else:
                # Try to find in subdirectories
                for key in f.keys():
                    if dataset_name in f[key]:
                        data = f[key][dataset_name][()]
                        break
                else:
                    raise ValueError(f"Dataset {dataset_name} not found")
        
        return data
    
    def load_geotiff(self, filepath: str, band: int = 1) -> np.ndarray:
        """
        Load GeoTIFF file
        
        Args:
            filepath: Path to GeoTIFF
            band: Band number
            
        Returns:
            numpy array
        """
        import rasterio
        
        with rasterio.open(filepath) as src:
            data = src.read(band)
            meta = {
                'transform': src.transform,
                'crs': src.crs,
                'bounds': src.bounds,
                'nodata': src.nodata
            }
        
        return data, meta
    
    def lst_from_hdf(self, filepath: str) -> Dict[str, Any]:
        """
        Extract Land Surface Temperature from MOD11A1 HDF
        
        Args:
            filepath: Path to MOD11A1 HDF file
            
        Returns:
            Dictionary with LST data and metadata
        """
        # Load LST (Kelvin * 0.02 scale)
        lst_data = self.load_hdf(filepath, 'LST_Day_1km')
        
        # Load QC flags
        qc_data = self.load_hdf(filepath, 'QC_Day')
        
        # Scale factor
        lst_kelvin = lst_data * 0.02
        
        # Convert to Celsius
        lst_celsius = lst_kelvin - 273.15
        
        # Apply QC mask (good data only)
        # QC bits: 0 = good, 1 = other
        good_quality = (qc_data & 1) == 0
        lst_celsius[~good_quality] = np.nan
        
        return {
            'lst_kelvin': lst_kelvin,
            'lst_celsius': lst_celsius,
            'qc': qc_data,
            'good_quality_fraction': np.sum(good_quality) / good_quality.size
        }
    
    def et_from_hdf(self, filepath: str) -> Dict[str, Any]:
        """
        Extract Evapotranspiration from MOD16A2 HDF
        
        Args:
            filepath: Path to MOD16A2 HDF file
            
        Returns:
            Dictionary with ET data
        """
        # Load ET (kg/m²/8day * 0.1 scale)
        et_data = self.load_hdf(filepath, 'ET_500m')
        
        # Load quality
        qc_data = self.load_hdf(filepath, 'QC_ET')
        
        # Scale factor
        et_8day = et_data * 0.1  # kg/m²/8day ≈ mm/8day
        
        # Daily average
        et_daily = et_8day / 8  # mm/day
        
        return {
            'et_8day': et_8day,
            'et_daily': et_daily,
            'qc': qc_data,
            'total_et_8day': np.nansum(et_daily)
        }
    
    def ndvi_from_hdf(self, filepath: str) -> Dict[str, Any]:
        """
        Extract NDVI from MOD13Q1 HDF
        
        Args:
            filepath: Path to MOD13Q1 HDF file
            
        Returns:
            Dictionary with NDVI data
        """
        # Load NDVI (scale factor 0.0001)
        ndvi_data = self.load_hdf(filepath, '250m 16 days NDVI')
        
        # Load EVI
        evi_data = self.load_hdf(filepath, '250m 16 days EVI')
        
        # Load quality
        qc_data = self.load_hdf(filepath, '250m 16 days pixel reliability')
        
        # Scale NDVI
        ndvi = ndvi_data * 0.0001
        
        # Scale EVI
        evi = evi_data * 0.0001
        
        # Mask bad pixels (qc != 0)
        good_quality = qc_data == 0
        ndvi[~good_quality] = np.nan
        evi[~good_quality] = np.nan
        
        return {
            'ndvi': ndvi,
            'evi': evi,
            'qc': qc_data,
            'good_quality_fraction': np.sum(good_quality) / good_quality.size
        }
    
    def time_series_analysis(self, product: str,
                            date_range: Tuple[str, str],
                            roi: Optional[Tuple] = None) -> Dict[str, Any]:
        """
        Analyze time series of MODIS products
        
        Args:
            product: 'lst', 'et', or 'ndvi'
            date_range: (start_date, end_date) as YYYY-MM-DD
            roi: Region of interest bounds
            
        Returns:
            Dictionary with time series
        """
        from glob import glob
        
        start_date = datetime.datetime.strptime(date_range[0], '%Y-%m-%d')
        end_date = datetime.datetime.strptime(date_range[1], '%Y-%m-%d')
        
        # Find matching files
        pattern = f"{self.data_dir}/{self.products[product]}*.hdf"
        files = sorted(glob(pattern))
        
        dates = []
        values = []
        
        for filepath in files:
            # Extract date from filename
            # MOD11A1.A2026001.hdf -> 2026-001
            import re
            date_match = re.search(r'A(\d{7})', filepath)
            if date_match:
                year = int(date_match.group(1)[:4])
                doy = int(date_match.group(1)[4:7])
                file_date = datetime.datetime(year, 1, 1) + datetime.timedelta(days=doy-1)
                
                if start_date <= file_date <= end_date:
                    # Load appropriate product
                    if product == 'lst':
                        data = self.lst_from_hdf(filepath)
                        value = np.nanmean(data['lst_celsius'])
                    elif product == 'et':
                        data = self.et_from_hdf(filepath)
                        value = np.nanmean(data['et_daily'])
                    elif product == 'ndvi':
                        data = self.ndvi_from_hdf(filepath)
                        value = np.nanmean(data['ndvi'])
                    
                    dates.append(file_date)
                    values.append(value)
        
        return {
            'dates': dates,
            'values': values,
            'product': product,
            'mean': np.mean(values) if values else None,
            'std': np.std(values) if values else None,
            'trend': self._calculate_trend(dates, values) if len(values) > 1 else None
        }
    
    def _calculate_trend(self, dates: List, values: List) -> Dict[str, float]:
        """Calculate linear trend in time series"""
        from scipy import stats
        
        # Convert dates to numeric (days since first)
        x = np.array([(d - dates[0]).days for d in dates])
        y = np.array(values)
        
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
        
        return {
            'slope_per_day': slope,
            'slope_per_year': slope * 365,
            'intercept': intercept,
            'r_squared': r_value**2,
            'p_value': p_value,
            'std_err': std_err
        }
    
    def downscale_lst(self, lst_coarse: np.ndarray,
                     ndvi_high: np.ndarray,
                     method: str = 'tsharp') -> np.ndarray:
        """
        Downscale coarse LST using high-resolution NDVI
        
        Args:
            lst_coarse: Coarse LST array
            ndvi_high: High-resolution NDVI
            method: 'tsharp' or 'disaggregation'
            
        Returns:
            Downscaled LST
        """
        from scipy.ndimage import zoom
        
        if method == 'tsharp':
            # T sharp method: use NDVI-LST relationship
            zoom_factors = (
                ndvi_high.shape[0] / lst_coarse.shape[0],
                ndvi_high.shape[1] / lst_coarse.shape[1]
            )
            
            # Resample LST to high resolution
            lst_resampled = zoom(lst_coarse, zoom_factors, order=1)
            
            # Calculate residuals from NDVI relationship
            # (simplified - would need calibration)
            ndvi_norm = (ndvi_high - np.nanmin(ndvi_high)) / (np.nanmax(ndvi_high) - np.nanmin(ndvi_high))
            lst_correction = ndvi_norm * 2 - 1  # -1 to +1°C correction
            
            lst_downscaled = lst_resampled + lst_correction
            
            return lst_downscaled
        
        else:
            # Simple bilinear interpolation
            zoom_factors = (
                ndvi_high.shape[0] / lst_coarse.shape[0],
                ndvi_high.shape[1] / lst_coarse.shape[1]
            )
            return zoom(lst_coarse, zoom_factors, order=1)
    
    def __repr__(self) -> str:
        return f"MODISProcessor(data_dir={self.data_dir})"
