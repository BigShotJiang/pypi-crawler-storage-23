"""
Sentinel-2 MSI Processor for Oasis Monitoring

Processes Sentinel-2 imagery for SVRI and vegetation indices
Bands: 
- B02: Blue (490 nm)
- B03: Green (560 nm)
- B04: Red (665 nm)
- B05: Red Edge 1 (705 nm)
- B06: Red Edge 2 (740 nm)
- B07: Red Edge 3 (783 nm)
- B08: NIR (842 nm)
- B8A: NIR narrow (865 nm)
- B11: SWIR 1 (1610 nm)
- B12: SWIR 2 (2190 nm)
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
import json
import warnings


class Sentinel2Processor:
    """
    Sentinel-2 MSI image processor for oasis monitoring
    
    Handles:
    - Cloud masking
    - Vegetation indices calculation
    - Time series analysis
    - SVRI composite generation
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize Sentinel-2 processor
        
        Args:
            data_dir: Directory for satellite data (relative path)
        """
        self.data_dir = Path(__file__).parent.parent.parent / (data_dir or "data/sentinel2")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Band mapping
        self.bands = {
            'B02': 2,   # Blue
            'B03': 3,   # Green
            'B04': 4,   # Red
            'B05': 5,   # Red Edge 1
            'B06': 6,   # Red Edge 2
            'B07': 7,   # Red Edge 3
            'B08': 8,   # NIR
            'B8A': 9,   # NIR narrow
            'B11': 11,  # SWIR 1
            'B12': 12,  # SWIR 2
        }
        
        # Band wavelengths (nm)
        self.wavelengths = {
            'B02': 490,
            'B03': 560,
            'B04': 665,
            'B05': 705,
            'B06': 740,
            'B07': 783,
            'B08': 842,
            'B8A': 865,
            'B11': 1610,
            'B12': 2190,
        }
        
    def load_bands(self, scene_path: str, 
                   band_list: Optional[List[str]] = None) -> Dict[str, np.ndarray]:
        """
        Load Sentinel-2 bands from SAFE format or GeoTIFF
        
        Args:
            scene_path: Path to Sentinel-2 scene
            band_list: List of bands to load (e.g., ['B04', 'B08'])
            
        Returns:
            Dictionary with band name -> array
        """
        import rasterio
        
        if band_list is None:
            band_list = list(self.bands.keys())
        
        bands = {}
        scene_dir = Path(scene_path)
        
        if scene_dir.suffix == '.SAFE':
            # SAFE format (ESA standard)
            for band in band_list:
                # Find band file (could be in GRANULE subdirectory)
                band_pattern = f"*_{band}.jp2"
                band_files = list(scene_dir.rglob(band_pattern))
                
                if band_files:
                    with rasterio.open(band_files[0]) as src:
                        bands[band] = src.read(1)
                        bands[f'{band}_meta'] = {
                            'transform': src.transform,
                            'crs': src.crs,
                            'bounds': src.bounds
                        }
        else:
            # Assume GeoTIFF files named by band
            for band in band_list:
                band_file = scene_dir / f"{band}.tif"
                if band_file.exists():
                    with rasterio.open(band_file) as src:
                        bands[band] = src.read(1)
                        bands[f'{band}_meta'] = {
                            'transform': src.transform,
                            'crs': src.crs,
                            'bounds': src.bounds
                        }
        
        return bands
    
    def calculate_ndvi(self, red: np.ndarray, nir: np.ndarray) -> np.ndarray:
        """
        Calculate Normalized Difference Vegetation Index
        
        NDVI = (NIR - Red) / (NIR + Red)
        """
        numerator = nir - red
        denominator = nir + red
        
        # Avoid division by zero
        ndvi = np.zeros_like(numerator)
        mask = denominator > 0
        ndvi[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndvi, -1, 1)
    
    def calculate_ndre(self, red: np.ndarray, red_edge: np.ndarray) -> np.ndarray:
        """
        Calculate Red Edge NDVI
        
        NDRE = (RE - Red) / (RE + Red)
        """
        numerator = red_edge - red
        denominator = red_edge + red
        
        ndre = np.zeros_like(numerator)
        mask = denominator > 0
        ndre[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndre, -1, 1)
    
    def calculate_evi(self, blue: np.ndarray, red: np.ndarray, 
                     nir: np.ndarray) -> np.ndarray:
        """
        Calculate Enhanced Vegetation Index
        
        EVI = 2.5 * ((NIR - Red) / (NIR + 6*Red - 7.5*Blue + 1))
        """
        numerator = nir - red
        denominator = nir + 6 * red - 7.5 * blue + 1
        
        evi = np.zeros_like(numerator)
        mask = denominator > 0
        evi[mask] = 2.5 * numerator[mask] / denominator[mask]
        
        return np.clip(evi, -1, 1)
    
    def calculate_savi(self, red: np.ndarray, nir: np.ndarray,
                       L: float = 0.5) -> np.ndarray:
        """
        Calculate Soil-Adjusted Vegetation Index
        
        SAVI = ((NIR - Red) / (NIR + Red + L)) * (1 + L)
        """
        numerator = nir - red
        denominator = nir + red + L
        
        savi = np.zeros_like(numerator)
        mask = denominator > 0
        savi[mask] = (numerator[mask] / denominator[mask]) * (1 + L)
        
        return np.clip(savi, -1, 1)
    
    def calculate_msavi(self, red: np.ndarray, nir: np.ndarray) -> np.ndarray:
        """
        Calculate Modified Soil-Adjusted Vegetation Index
        
        MSAVI = (2*NIR + 1 - sqrt((2*NIR + 1)² - 8*(NIR - Red))) / 2
        """
        term = 2 * nir + 1
        sqrt_term = term**2 - 8 * (nir - red)
        sqrt_term = np.maximum(sqrt_term, 0)
        
        msavi = (term - np.sqrt(sqrt_term)) / 2
        
        return np.clip(msavi, -1, 1)
    
    def calculate_ndwi(self, green: np.ndarray, nir: np.ndarray) -> np.ndarray:
        """
        Calculate Normalized Difference Water Index
        
        NDWI = (Green - NIR) / (Green + NIR)
        """
        numerator = green - nir
        denominator = green + nir
        
        ndwi = np.zeros_like(numerator)
        mask = denominator > 0
        ndwi[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndwi, -1, 1)
    
    def calculate_ndbi(self, swir: np.ndarray, nir: np.ndarray) -> np.ndarray:
        """
        Calculate Normalized Difference Built-up Index
        
        NDBI = (SWIR - NIR) / (SWIR + NIR)
        """
        numerator = swir - nir
        denominator = swir + nir
        
        ndbi = np.zeros_like(numerator)
        mask = denominator > 0
        ndbi[mask] = numerator[mask] / denominator[mask]
        
        return np.clip(ndbi, -1, 1)
    
    def calculate_lai(self, ndvi: np.ndarray) -> np.ndarray:
        """
        Estimate Leaf Area Index from NDVI
        
        LAI = 4.0 * NDVI + 1.0 (simplified empirical)
        """
        lai = 4.0 * ndvi + 1.0
        return np.clip(lai, 0, 8)
    
    def calculate_fpar(self, ndvi: np.ndarray) -> np.ndarray:
        """
        Estimate Fraction of PAR absorbed from NDVI
        
        FPAR = 1.2 * NDVI + 0.1 (simplified)
        """
        fpar = 1.2 * ndvi + 0.1
        return np.clip(fpar, 0, 1)
    
    def cloud_mask(self, bands: Dict[str, np.ndarray],
                  threshold: float = 0.2) -> np.ndarray:
        """
        Create cloud mask using multiple criteria
        
        Args:
            bands: Dictionary of bands
            threshold: Cloud probability threshold
            
        Returns:
            Boolean mask (True = cloud)
        """
        # Simple cloud detection using blue band
        if 'B02' in bands:
            blue = bands['B02']
            
            # Clouds are bright in blue
            cloud_candidate = blue > np.percentile(blue, 90) * 0.8
            
            # Additional criteria if available
            if 'B08' in bands and 'B04' in bands:
                ndvi = self.calculate_ndvi(bands['B04'], bands['B08'])
                # Clouds have low NDVI
                cloud_candidate = cloud_candidate & (ndvi < 0.2)
            
            return cloud_candidate
        
        return np.zeros(bands[list(bands.keys())[0]].shape, dtype=bool)
    
    def mask_clouds(self, bands: Dict[str, np.ndarray],
                   mask: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
        """
        Mask clouds in all bands
        
        Args:
            bands: Dictionary of bands
            mask: Cloud mask (if None, calculate)
            
        Returns:
            Dictionary with masked bands
        """
        if mask is None:
            mask = self.cloud_mask(bands)
        
        masked_bands = {}
        for key, array in bands.items():
            if not key.endswith('_meta'):
                masked = array.copy()
                masked[mask] = np.nan
                masked_bands[key] = masked
            else:
                masked_bands[key] = array
        
        return masked_bands
    
    def extract_roi(self, bands: Dict[str, np.ndarray],
                   bounds: Tuple[float, float, float, float]) -> Dict[str, np.ndarray]:
        """
        Extract region of interest from bands
        
        Args:
            bands: Dictionary of bands
            bounds: (minx, miny, maxx, maxy) in pixel coordinates
            
        Returns:
            Dictionary with cropped bands
        """
        minx, miny, maxx, maxy = map(int, bounds)
        
        roi = {}
        for key, array in bands.items():
            if not key.endswith('_meta'):
                roi[key] = array[miny:maxy, minx:maxx]
            else:
                roi[key] = array
        
        return roi
    
    def resample_to_common(self, bands: Dict[str, np.ndarray],
                          target_resolution: str = '10m') -> Dict[str, np.ndarray]:
        """
        Resample all bands to common resolution
        
        Args:
            bands: Dictionary of bands
            target_resolution: '10m', '20m', or '60m'
            
        Returns:
            Dictionary with resampled bands
        """
        from scipy.ndimage import zoom
        
        # Resolution mapping
        resolutions = {
            '10m': {'B02', 'B03', 'B04', 'B08'},
            '20m': {'B05', 'B06', 'B07', 'B8A', 'B11', 'B12'},
            '60m': set()
        }
        
        target_size = None
        
        # Determine target shape
        for band in resolutions[target_resolution]:
            if band in bands:
                target_size = bands[band].shape
                break
        
        if target_size is None:
            return bands
        
        resampled = {}
        for key, array in bands.items():
            if key.endswith('_meta'):
                resampled[key] = array
            else:
                if array.shape != target_size:
                    # Calculate zoom factors
                    zy = target_size[0] / array.shape[0]
                    zx = target_size[1] / array.shape[1]
                    resampled[key] = zoom(array, (zy, zx), order=1)
                else:
                    resampled[key] = array.copy()
        
        return resampled
    
    def time_series_analysis(self, scene_list: List[str],
                            roi: Optional[Tuple] = None) -> Dict[str, Any]:
        """
        Analyze time series of Sentinel-2 scenes
        
        Args:
            scene_list: List of scene paths
            roi: Region of interest bounds
            
        Returns:
            Dictionary with time series statistics
        """
        dates = []
        ndvi_means = []
        ndvi_stds = []
        ndre_means = []
        
        for scene_path in scene_list:
            # Extract date from scene name (simplified)
            import re
            date_match = re.search(r'\d{8}', str(scene_path))
            if date_match:
                dates.append(date_match.group())
            
            # Load bands
            bands = self.load_bands(str(scene_path), ['B04', 'B05', 'B08'])
            
            if roi:
                bands = self.extract_roi(bands, roi)
            
            # Calculate indices
            if all(b in bands for b in ['B04', 'B08']):
                ndvi = self.calculate_ndvi(bands['B04'], bands['B08'])
                ndvi_means.append(np.nanmean(ndvi))
                ndvi_stds.append(np.nanstd(ndvi))
            
            if all(b in bands for b in ['B04', 'B05']):
                ndre = self.calculate_ndre(bands['B04'], bands['B05'])
                ndre_means.append(np.nanmean(ndre))
        
        return {
            'dates': dates,
            'ndvi_mean': ndvi_means,
            'ndvi_std': ndvi_stds,
            'ndre_mean': ndre_means,
            'n_scenes': len(scene_list)
        }
    
    def svri_composite(self, bands: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Calculate SVRI composite
        
        SVRI = 0.40·NDVI + 0.25·NDRE + 0.20·SWIR_stress + 0.15·EVI
        """
        # Ensure required bands
        required = ['B04', 'B08', 'B05', 'B11', 'B02']
        if not all(b in bands for b in required):
            missing = [b for b in required if b not in bands]
            raise ValueError(f"Missing bands for SVRI: {missing}")
        
        # Calculate components
        ndvi = self.calculate_ndvi(bands['B04'], bands['B08'])
        ndre = self.calculate_ndre(bands['B04'], bands['B05'])
        evi = self.calculate_evi(bands['B02'], bands['B04'], bands['B08'])
        
        # SWIR stress index
        swir_stress = (bands['B08'] - bands['B11']) / (bands['B08'] + bands['B11'])
        swir_stress = np.clip(swir_stress, -1, 1)
        
        # Composite
        svri = (0.40 * ndvi + 0.25 * ndre + 0.20 * (1 - swir_stress) + 0.15 * evi)
        
        return np.clip(svri, 0, 1)
    
    def __repr__(self) -> str:
        return f"Sentinel2Processor(data_dir={self.data_dir})"
