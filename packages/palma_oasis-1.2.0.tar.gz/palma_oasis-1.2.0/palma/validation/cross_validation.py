"""
Leave-one-site-out Cross-validation for PALMA Framework

Validates OHI predictions across 31 oasis sites
Provides accuracy metrics and uncertainty estimates
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass
import pandas as pd


@dataclass
class ValidationResult:
    """Cross-validation result"""
    site: str
    observed_ohi: float
    predicted_ohi: float
    error: float
    relative_error: float
    within_confidence: bool


class CrossValidator:
    """
    Leave-one-site-out cross-validation for PALMA
    
    Validates model predictions by training on 30 sites
    and testing on the held-out site
    """
    
    def __init__(self, sites: List[str] = None):
        """
        Initialize cross-validator
        
        Args:
            sites: List of site names (31 sites from paper)
        """
        if sites is None:
            self.sites = [
                'tafilalet', 'draa_valley', 'al_fayum', 'al_ahsa', 'dunhuang',
                'dakhla', 'ghardaia', 'fergana_valley', 'san_pedro', 'pica',
                'liwa', 'hofuf', 'merv', 'tier3_site1', 'tier3_site2',
                'tier3_site3', 'tier3_site4', 'tier3_site5', 'tier3_site6',
                'tier3_site7', 'tier3_site8', 'tier3_site9', 'tier3_site10',
                'tier3_site11', 'tier3_site12', 'tier3_site13', 'tier3_site14',
                'tier3_site15', 'tier3_site16', 'tier3_site17', 'tier3_site18'
            ]
        else:
            self.sites = sites
        
        self.n_sites = len(self.sites)
        
    def validate(self, data: Dict[str, Dict[str, float]]) -> Dict[str, Any]:
        """
        Perform leave-one-site-out cross-validation
        
        Args:
            data: Dictionary mapping site -> {param: value} for all parameters
            
        Returns:
            Validation statistics
        """
        results = []
        
        for test_site in self.sites:
            # Training data (all other sites)
            train_data = {site: values for site, values in data.items() 
                         if site != test_site}
            
            # Test data
            test_data = data[test_site]
            
            # Train model (simplified - would use actual model)
            model = self._train_model(train_data)
            
            # Predict for test site
            predicted = self._predict(model, test_site, test_data)
            
            # Observed OHI
            observed = self._calculate_ohi(test_data)
            
            # Calculate error
            error = predicted - observed
            rel_error = abs(error) / observed if observed > 0 else abs(error)
            
            # Check if within confidence interval
            within_95 = abs(error) < 0.1  # Simplified 95% CI
            
            results.append(ValidationResult(
                site=test_site,
                observed_ohi=observed,
                predicted_ohi=predicted,
                error=error,
                relative_error=rel_error,
                within_confidence=within_95
            ))
        
        # Aggregate statistics
        errors = [r.error for r in results]
        rel_errors = [r.relative_error for r in results]
        
        # RMSE
        rmse = np.sqrt(np.mean(np.array(errors)**2))
        
        # MAE
        mae = np.mean(np.abs(errors))
        
        # Accuracy (within 0.1)
        accuracy = np.mean([r.within_confidence for r in results])
        
        # Bias
        bias = np.mean(errors)
        
        # Site-specific results
        site_results = {r.site: {
            'observed': r.observed_ohi,
            'predicted': r.predicted_ohi,
            'error': r.error,
            'rel_error': r.relative_error
        } for r in results}
        
        return {
            'n_sites': self.n_sites,
            'rmse': rmse,
            'mae': mae,
            'accuracy': accuracy,
            'bias': bias,
            'std_error': np.std(errors),
            'max_error': np.max(np.abs(errors)),
            'site_results': site_results,
            'all_results': results
        }
    
    def _train_model(self, train_data: Dict) -> Any:
        """Train prediction model"""
        # Simplified - would use actual ML model
        return {'weights': self._estimate_weights(train_data)}
    
    def _estimate_weights(self, data: Dict) -> Dict[str, float]:
        """Estimate parameter weights from training data"""
        # Default weights from paper
        return {
            'ARVC': 0.22,
            'PTSI': 0.18,
            'SSSP': 0.17,
            'CMBF': 0.16,
            'SVRI': 0.14,
            'WEPR': 0.08,
            'BST': 0.05
        }
    
    def _predict(self, model: Any, site: str, 
                test_data: Dict[str, float]) -> float:
        """Predict OHI for test site"""
        # Weighted sum
        ohi = 0.0
        weights = model['weights']
        
        for param, value in test_data.items():
            if param in weights:
                ohi += weights[param] * value
        
        return ohi
    
    def _calculate_ohi(self, data: Dict[str, float]) -> float:
        """Calculate observed OHI"""
        weights = {
            'ARVC': 0.22, 'PTSI': 0.18, 'SSSP': 0.17,
            'CMBF': 0.16, 'SVRI': 0.14, 'WEPR': 0.08, 'BST': 0.05
        }
        
        ohi = 0.0
        for param, value in data.items():
            if param in weights:
                ohi += weights[param] * value
        
        return ohi
    
    def accuracy_by_site_type(self, results: List[ValidationResult],
                              site_types: Dict[str, str]) -> Dict[str, Any]:
        """
        Calculate accuracy by oasis type
        
        Args:
            results: Validation results
            site_types: Dictionary mapping site -> type
            
        Returns:
            Accuracy metrics by type
        """
        types = {}
        
        for result in results:
            site_type = site_types.get(result.site, 'unknown')
            
            if site_type not in types:
                types[site_type] = {
                    'sites': [],
                    'errors': [],
                    'rel_errors': []
                }
            
            types[site_type]['sites'].append(result.site)
            types[site_type]['errors'].append(result.error)
            types[site_type]['rel_errors'].append(result.relative_error)
        
        # Calculate statistics by type
        type_stats = {}
        for site_type, data in types.items():
            type_stats[site_type] = {
                'n_sites': len(data['sites']),
                'sites': data['sites'],
                'rmse': np.sqrt(np.mean(np.array(data['errors'])**2)),
                'mae': np.mean(np.abs(data['errors'])),
                'accuracy': np.mean([abs(e) < 0.1 for e in data['errors']])
            }
        
        return type_stats
    
    def temporal_validation(self, data: Dict[str, Dict[int, float]],
                          years: List[int]) -> Dict[str, Any]:
        """
        Validate temporal predictions
        
        Args:
            data: Dictionary mapping site -> {year: OHI}
            years: List of years
            
        Returns:
            Temporal validation metrics
        """
        yearly_results = {}
        
        for year in years:
            # Use all data except current year for training
            train_data = {}
            test_data = {}
            
            for site, site_data in data.items():
                if year in site_data:
                    test_data[site] = site_data[year]
                else:
                    train_data[site] = {y: v for y, v in site_data.items() 
                                       if y != year}
            
            # Validate for this year
            results = self.validate(test_data)
            yearly_results[year] = {
                'rmse': results['rmse'],
                'accuracy': results['accuracy'],
                'n_sites': len(test_data)
            }
        
        # Trend in accuracy over time
        years_list = sorted(yearly_results.keys())
        accuracies = [yearly_results[y]['accuracy'] for y in years_list]
        
        if len(years_list) > 1:
            from scipy import stats
            slope, intercept, r_value, p_value, _ = stats.linregress(years_list, accuracies)
            trend = {
                'slope': slope,
                'r_squared': r_value**2,
                'p_value': p_value,
                'significant': p_value < 0.05
            }
        else:
            trend = None
        
        return {
            'yearly': yearly_results,
            'trend': trend,
            'mean_accuracy': np.mean(accuracies),
            'min_accuracy': np.min(accuracies),
            'max_accuracy': np.max(accuracies)
        }
    
    def __repr__(self) -> str:
        return f"CrossValidator(n_sites={self.n_sites})"
