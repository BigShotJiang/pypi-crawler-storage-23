"""
Bootstrap Uncertainty Quantification for PALMA Parameters

Monte Carlo simulation for uncertainty estimation
Propagates measurement errors through parameter calculations
"""

import numpy as np
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass
from scipy import stats


@dataclass
class UncertaintyResult:
    """Bootstrap uncertainty result"""
    parameter: str
    mean: float
    std: float
    ci_lower: float  # 95% confidence interval lower
    ci_upper: float  # 95% confidence interval upper
    distribution: np.ndarray


class BootstrapUncertainty:
    """
    Bootstrap uncertainty quantification for PALMA
    
    Uses Monte Carlo resampling to estimate uncertainty
    in parameter estimates and OHI predictions
    """
    
    def __init__(self, n_iterations: int = 1000, 
                 random_seed: int = 42):
        """
        Initialize bootstrap
        
        Args:
            n_iterations: Number of bootstrap iterations
            random_seed: Random seed for reproducibility
        """
        self.n_iterations = n_iterations
        np.random.seed(random_seed)
        
    def parameter_uncertainty(self, data: np.ndarray,
                             param_name: str,
                             measurement_error: float = 0.05) -> UncertaintyResult:
        """
        Estimate uncertainty for a single parameter
        
        Args:
            data: Original measurements
            param_name: Parameter name
            measurement_error: Relative measurement error (std)
            
        Returns:
            UncertaintyResult with bootstrap distribution
        """
        n_samples = len(data)
        bootstrap_samples = []
        
        for _ in range(self.n_iterations):
            # Resample with replacement
            indices = np.random.randint(0, n_samples, n_samples)
            sample = data[indices]
            
            # Add measurement noise
            noise = np.random.normal(0, measurement_error * np.mean(sample), n_samples)
            sample_noisy = sample + noise
            
            # Calculate statistic (mean for simplicity)
            bootstrap_samples.append(np.mean(sample_noisy))
        
        bootstrap_samples = np.array(bootstrap_samples)
        
        # Calculate statistics
        mean = np.mean(bootstrap_samples)
        std = np.std(bootstrap_samples)
        ci_lower = np.percentile(bootstrap_samples, 2.5)
        ci_upper = np.percentile(bootstrap_samples, 97.5)
        
        return UncertaintyResult(
            parameter=param_name,
            mean=mean,
            std=std,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            distribution=bootstrap_samples
        )
    
    def ohi_uncertainty(self, param_values: Dict[str, float],
                       param_uncertainties: Dict[str, float],
                       weights: Dict[str, float]) -> UncertaintyResult:
        """
        Propagate uncertainty to OHI
        
        Args:
            param_values: Best estimates for each parameter
            param_uncertainties: Uncertainty (std) for each parameter
            weights: Parameter weights in OHI
            
        Returns:
            UncertaintyResult for OHI
        """
        ohi_samples = []
        
        for _ in range(self.n_iterations):
            ohi = 0.0
            
            for param, value in param_values.items():
                if param in weights and param in param_uncertainties:
                    # Sample with uncertainty
                    param_sample = np.random.normal(
                        value, 
                        param_uncertainties[param]
                    )
                    # Clip to valid range
                    param_sample = np.clip(param_sample, 0, 1)
                    
                    ohi += weights[param] * param_sample
            
            ohi_samples.append(ohi)
        
        ohi_samples = np.array(ohi_samples)
        
        return UncertaintyResult(
            parameter='OHI',
            mean=np.mean(ohi_samples),
            std=np.std(ohi_samples),
            ci_lower=np.percentile(ohi_samples, 2.5),
            ci_upper=np.percentile(ohi_samples, 97.5),
            distribution=ohi_samples
        )
    
    def sensitivity_analysis(self, param_values: Dict[str, float],
                            base_uncertainty: float = 0.1) -> Dict[str, float]:
        """
        Sensitivity analysis: how much each parameter contributes to OHI uncertainty
        
        Args:
            param_values: Parameter values
            base_uncertainty: Base relative uncertainty
            
        Returns:
            Sensitivity indices
        """
        sensitivities = {}
        
        # Baseline OHI
        weights = {'ARVC': 0.22, 'PTSI': 0.18, 'SSSP': 0.17,
                  'CMBF': 0.16, 'SVRI': 0.14, 'WEPR': 0.08, 'BST': 0.05}
        
        baseline_ohi = sum(weights[p] * param_values[p] for p in param_values if p in weights)
        
        # Vary each parameter individually
        for param in param_values:
            if param not in weights:
                continue
                
            # Create perturbed values
            perturbed_values = param_values.copy()
            perturbed_values[param] *= (1 + base_uncertainty)
            
            # Calculate perturbed OHI
            perturbed_ohi = sum(weights[p] * perturbed_values[p] 
                               for p in perturbed_values if p in weights)
            
            # Sensitivity = relative change in OHI / relative change in parameter
            rel_change_ohi = (perturbed_ohi - baseline_ohi) / baseline_ohi
            rel_change_param = base_uncertainty
            
            sensitivities[param] = abs(rel_change_ohi / rel_change_param)
        
        # Normalize to sum to 1
        total = sum(sensitivities.values())
        if total > 0:
            sensitivities = {k: v/total for k, v in sensitivities.items()}
        
        return sensitivities
    
    def uncertainty_propagation(self, func: Callable,
                               inputs: Dict[str, float],
                               input_errors: Dict[str, float],
                               n_iterations: int = None) -> Dict[str, Any]:
        """
        General uncertainty propagation through any function
        
        Args:
            func: Function that takes inputs and returns output
            inputs: Input parameter values
            input_errors: Standard deviations for inputs
            n_iterations: Number of iterations
            
        Returns:
            Output distribution statistics
        """
        if n_iterations is None:
            n_iterations = self.n_iterations
        
        output_samples = []
        
        for _ in range(n_iterations):
            # Sample inputs with uncertainty
            sampled_inputs = {}
            for name, value in inputs.items():
                if name in input_errors:
                    sample = np.random.normal(value, input_errors[name])
                    sampled_inputs[name] = sample
                else:
                    sampled_inputs[name] = value
            
            # Compute function
            try:
                output = func(**sampled_inputs)
                output_samples.append(output)
            except:
                pass
        
        output_samples = np.array(output_samples)
        
        return {
            'mean': np.mean(output_samples),
            'std': np.std(output_samples),
            'ci_lower': np.percentile(output_samples, 2.5),
            'ci_upper': np.percentile(output_samples, 97.5),
            'median': np.median(output_samples),
            'distribution': output_samples
        }
    
    def prediction_interval(self, predictions: np.ndarray,
                           observations: np.ndarray,
                           confidence: float = 0.95) -> Dict[str, float]:
        """
        Calculate prediction intervals from validation data
        
        Args:
            predictions: Model predictions
            observations: Observed values
            confidence: Confidence level (default 0.95)
            
        Returns:
            Prediction interval statistics
        """
        errors = predictions - observations
        mean_error = np.mean(errors)
        std_error = np.std(errors)
        
        # Calculate prediction interval
        alpha = 1 - confidence
        z = stats.norm.ppf(1 - alpha/2)
        
        lower = mean_error - z * std_error
        upper = mean_error + z * std_error
        
        return {
            'mean_error': mean_error,
            'std_error': std_error,
            'pi_lower': lower,
            'pi_upper': upper,
            'coverage': np.mean((errors >= lower) & (errors <= upper))
        }
    
    def report(self, results: Dict[str, UncertaintyResult]) -> str:
        """
        Generate uncertainty report
        
        Args:
            results: Dictionary of UncertaintyResult objects
            
        Returns:
            Formatted report string
        """
        report = []
        report.append("=" * 60)
        report.append("PALMA UNCERTAINTY ANALYSIS REPORT")
        report.append("=" * 60)
        report.append(f"Method: Bootstrap ({self.n_iterations} iterations)")
        report.append("")
        
        for name, result in results.items():
            report.append(f"\n{name}:")
            report.append(f"  Mean: {result.mean:.4f}")
            report.append(f"  Std:  {result.std:.4f}")
            report.append(f"  95% CI: [{result.ci_lower:.4f}, {result.ci_upper:.4f}]")
            report.append(f"  CV:    {result.std/result.mean:.2%}")
        
        report.append("")
        report.append("=" * 60)
        
        return "\n".join(report)
    
    def __repr__(self) -> str:
        return f"BootstrapUncertainty(n_iter={self.n_iterations})"
