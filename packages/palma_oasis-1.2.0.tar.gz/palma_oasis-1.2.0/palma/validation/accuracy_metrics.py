"""
Accuracy Metrics for PALMA Validation

Calculates:
- RMSE (Root Mean Square Error)
- Detection Rate (True Positive Rate)
- False Alert Rate (False Positive Rate)
- Precision, Recall, F1 Score
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass


@dataclass
class AccuracyMetrics:
    """Accuracy metrics for PALMA predictions"""
    rmse: float
    mae: float
    r2: float
    detection_rate: float  # True Positive Rate
    false_alert_rate: float  # False Positive Rate
    precision: float
    recall: float
    f1_score: float
    accuracy: float
    missed_events: float
    n_samples: int


class MetricsCalculator:
    """
    Calculate accuracy metrics for PALMA validation
    
    Implements metrics from paper:
    - OHI Prediction Accuracy: 93.1%
    - Detection Rate: 97.2%
    - False Alert Rate: 2.8%
    """
    
    def __init__(self):
        """Initialize metrics calculator"""
        pass
    
    def regression_metrics(self, observed: np.ndarray,
                          predicted: np.ndarray) -> Dict[str, float]:
        """
        Calculate regression metrics for continuous values
        
        Args:
            observed: Observed values
            predicted: Predicted values
            
        Returns:
            Dictionary with regression metrics
        """
        # Remove NaNs
        mask = ~(np.isnan(observed) | np.isnan(predicted))
        obs = observed[mask]
        pred = predicted[mask]
        
        if len(obs) == 0:
            return {
                'rmse': np.nan,
                'mae': np.nan,
                'mse': np.nan,
                'mape': np.nan,
                'r2': np.nan,
                'n': 0
            }
        
        # RMSE
        mse = np.mean((obs - pred)**2)
        rmse = np.sqrt(mse)
        
        # MAE
        mae = np.mean(np.abs(obs - pred))
        
        # MAPE (Mean Absolute Percentage Error)
        with np.errstate(divide='ignore', invalid='ignore'):
            mape = np.mean(np.abs((obs - pred) / obs)) * 100
        
        # R²
        ss_res = np.sum((obs - pred)**2)
        ss_tot = np.sum((obs - np.mean(obs))**2)
        r2 = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
        
        # Bias
        bias = np.mean(pred - obs)
        
        return {
            'rmse': rmse,
            'mae': mae,
            'mse': mse,
            'mape': mape,
            'r2': r2,
            'bias': bias,
            'n': len(obs)
        }
    
    def classification_metrics(self, observed: np.ndarray,
                              predicted: np.ndarray,
                              threshold: float = 0.65) -> Dict[str, float]:
        """
        Calculate classification metrics for stress detection
        
        Args:
            observed: Observed OHI values
            predicted: Predicted OHI values
            threshold: Threshold for stress (CRITICAL = 0.65)
            
        Returns:
            Confusion matrix and derived metrics
        """
        # Convert to binary: 1 = stress (OHI > threshold)
        obs_stress = (observed > threshold).astype(int)
        pred_stress = (predicted > threshold).astype(int)
        
        # Remove NaNs
        mask = ~(np.isnan(obs_stress) | np.isnan(pred_stress))
        obs_stress = obs_stress[mask]
        pred_stress = pred_stress[mask]
        
        if len(obs_stress) == 0:
            return {
                'tp': 0, 'tn': 0, 'fp': 0, 'fn': 0,
                'detection_rate': 0,
                'false_alert_rate': 0,
                'precision': 0,
                'recall': 0,
                'f1': 0,
                'accuracy': 0,
                'n': 0
            }
        
        # Confusion matrix
        tp = np.sum((pred_stress == 1) & (obs_stress == 1))
        tn = np.sum((pred_stress == 0) & (obs_stress == 0))
        fp = np.sum((pred_stress == 1) & (obs_stress == 0))
        fn = np.sum((pred_stress == 0) & (obs_stress == 1))
        
        # Derived metrics
        detection_rate = tp / (tp + fn) if (tp + fn) > 0 else 0  # Recall
        false_alert_rate = fp / (fp + tn) if (fp + tn) > 0 else 0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = detection_rate
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
        
        return {
            'tp': int(tp),
            'tn': int(tn),
            'fp': int(fp),
            'fn': int(fn),
            'detection_rate': detection_rate,
            'false_alert_rate': false_alert_rate,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'accuracy': accuracy,
            'n': len(obs_stress)
        }
    
    def lead_time_metrics(self, lead_times: np.ndarray,
                         min_lead: float = 30) -> Dict[str, float]:
        """
        Calculate metrics for early warning lead time
        
        Args:
            lead_times: Array of lead times (days)
            min_lead: Minimum useful lead time (days)
            
        Returns:
            Lead time statistics
        """
        lead_times = lead_times[~np.isnan(lead_times)]
        
        if len(lead_times) == 0:
            return {
                'mean_lead': 0,
                'median_lead': 0,
                'max_lead': 0,
                'min_lead': 0,
                'useful_warnings': 0,
                'pct_useful': 0
            }
        
        mean_lead = np.mean(lead_times)
        median_lead = np.median(lead_times)
        max_lead = np.max(lead_times)
        min_lead_time = np.min(lead_times)
        
        # Warnings with sufficient lead time
        useful = np.sum(lead_times >= min_lead)
        pct_useful = useful / len(lead_times) * 100
        
        return {
            'mean_lead': mean_lead,
            'median_lead': median_lead,
            'max_lead': max_lead,
            'min_lead': min_lead_time,
            'useful_warnings': int(useful),
            'pct_useful': pct_useful,
            'n_events': len(lead_times)
        }
    
    def site_comparison(self, site_metrics: Dict[str, AccuracyMetrics]) -> Dict[str, Any]:
        """
        Compare accuracy across sites
        
        Args:
            site_metrics: Dictionary mapping site -> AccuracyMetrics
            
        Returns:
            Site comparison statistics
        """
        sites = list(site_metrics.keys())
        
        # Extract metrics
        rmse_values = [site_metrics[s].rmse for s in sites]
        detection_values = [site_metrics[s].detection_rate for s in sites]
        false_alert_values = [site_metrics[s].false_alert_rate for s in sites]
        
        return {
            'best_site_rmse': sites[np.argmin(rmse_values)],
            'worst_site_rmse': sites[np.argmax(rmse_values)],
            'best_site_detection': sites[np.argmax(detection_values)],
            'worst_site_detection': sites[np.argmin(detection_values)],
            'best_site_false_alert': sites[np.argmin(false_alert_values)],
            'worst_site_false_alert': sites[np.argmax(false_alert_values)],
            'mean_rmse': np.mean(rmse_values),
            'std_rmse': np.std(rmse_values),
            'mean_detection': np.mean(detection_values),
            'std_detection': np.std(detection_values),
            'mean_false_alert': np.mean(false_alert_values),
            'std_false_alert': np.std(false_alert_values)
        }
    
    def temporal_accuracy(self, observed: np.ndarray,
                         predicted: np.ndarray,
                         times: np.ndarray,
                         window: int = 30) -> Dict[str, Any]:
        """
        Calculate accuracy over time (rolling window)
        
        Args:
            observed: Observed values
            predicted: Predicted values
            times: Time points
            window: Rolling window size
            
        Returns:
            Temporal accuracy trends
        """
        n = len(observed)
        rolling_rmse = []
        rolling_detection = []
        window_centers = []
        
        for i in range(0, n - window + 1, max(1, window // 10)):
            obs_window = observed[i:i+window]
            pred_window = predicted[i:i+window]
            
            # Regression metrics
            reg = self.regression_metrics(obs_window, pred_window)
            
            # Classification metrics
            clf = self.classification_metrics(obs_window, pred_window)
            
            rolling_rmse.append(reg['rmse'])
            rolling_detection.append(clf['detection_rate'])
            window_centers.append(times[i + window//2])
        
        # Trend in accuracy
        if len(rolling_rmse) > 1:
            from scipy import stats
            x = np.arange(len(rolling_rmse))
            
            slope_rmse, _, r_rmse, p_rmse, _ = stats.linregress(x, rolling_rmse)
            slope_det, _, r_det, p_det, _ = stats.linregress(x, rolling_detection)
            
            rmse_trend = {
                'slope': slope_rmse,
                'r_squared': r_rmse**2,
                'p_value': p_rmse,
                'significant': p_rmse < 0.05
            }
            
            detection_trend = {
                'slope': slope_det,
                'r_squared': r_det**2,
                'p_value': p_det,
                'significant': p_det < 0.05
            }
        else:
            rmse_trend = detection_trend = None
        
        return {
            'window_centers': window_centers,
            'rolling_rmse': rolling_rmse,
            'rolling_detection': rolling_detection,
            'rmse_trend': rmse_trend,
            'detection_trend': detection_trend
        }
    
    def comprehensive_validation(self, observed: np.ndarray,
                                predicted: np.ndarray,
                                lead_times: Optional[np.ndarray] = None) -> AccuracyMetrics:
        """
        Calculate comprehensive validation metrics
        
        Args:
            observed: Observed OHI values
            predicted: Predicted OHI values
            lead_times: Lead times for events (optional)
            
        Returns:
            AccuracyMetrics object
        """
        # Regression metrics
        reg = self.regression_metrics(observed, predicted)
        
        # Classification metrics
        clf = self.classification_metrics(observed, predicted)
        
        # Lead time metrics if available
        if lead_times is not None:
            lead = self.lead_time_metrics(lead_times)
            mean_lead = lead['mean_lead']
        else:
            mean_lead = 0
        
        return AccuracyMetrics(
            rmse=reg['rmse'],
            mae=reg['mae'],
            r2=reg['r2'],
            detection_rate=clf['detection_rate'],
            false_alert_rate=clf['false_alert_rate'],
            precision=clf['precision'],
            recall=clf['recall'],
            f1_score=clf['f1'],
            accuracy=clf['accuracy'],
            missed_events=clf['fn'],
            n_samples=clf['n']
        )
    
    def report(self, metrics: AccuracyMetrics) -> str:
        """
        Generate formatted report
        
        Args:
            metrics: AccuracyMetrics object
            
        Returns:
            Formatted report string
        """
        report = []
        report.append("=" * 60)
        report.append("PALMA VALIDATION REPORT")
        report.append("=" * 60)
        report.append(f"Number of samples: {metrics.n_samples}")
        report.append("")
        report.append("REGRESSION METRICS:")
        report.append(f"  RMSE: {metrics.rmse:.4f}")
        report.append(f"  MAE:  {metrics.mae:.4f}")
        report.append(f"  R²:   {metrics.r2:.4f}")
        report.append("")
        report.append("CLASSIFICATION METRICS:")
        report.append(f"  Detection Rate:  {metrics.detection_rate:.2%}")
        report.append(f"  False Alert Rate: {metrics.false_alert_rate:.2%}")
        report.append(f"  Precision:        {metrics.precision:.2%}")
        report.append(f"  Recall:           {metrics.recall:.2%}")
        report.append(f"  F1 Score:         {metrics.f1_score:.3f}")
        report.append(f"  Accuracy:         {metrics.accuracy:.2%}")
        report.append(f"  Missed Events:    {metrics.missed_events}")
        report.append("")
        report.append("=" * 60)
        
        return "\n".join(report)
    
    def __repr__(self) -> str:
        return "MetricsCalculator()"
