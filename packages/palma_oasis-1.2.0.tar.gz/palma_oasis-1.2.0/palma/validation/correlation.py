"""
Inter-parameter Correlation Matrix for PALMA

Calculates Pearson and Spearman correlations between
the seven PALMA parameters across 31 sites
"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class CorrelationResult:
    """Correlation analysis result"""
    pearson_matrix: np.ndarray
    spearman_matrix: np.ndarray
    p_values: np.ndarray
    parameters: List[str]
    significant_correlations: List[Dict[str, Any]]


class CorrelationMatrix:
    """
    Calculate inter-parameter correlation matrix
    
    From paper:
    - ARVC-Productivity: r = +0.913
    - SSSP-SVRI: ρ = -0.887 (p < 0.001)
    - CMBF-WEPR: ρ = +0.741 (p < 0.001)
    - ARVC-WEPR: ρ = +0.850 (p < 0.001)
    """
    
    def __init__(self):
        """Initialize correlation calculator"""
        self.parameters = ['ARVC', 'PTSI', 'SSSP', 'CMBF', 'SVRI', 'WEPR', 'BST']
        
    def calculate(self, data: pd.DataFrame) -> CorrelationResult:
        """
        Calculate correlation matrices
        
        Args:
            data: DataFrame with columns for each parameter
                 and rows for each site/year
                 
        Returns:
            CorrelationResult with matrices
        """
        # Check required columns
        missing = [p for p in self.parameters if p not in data.columns]
        if missing:
            raise ValueError(f"Missing parameters: {missing}")
        
        # Extract parameter data
        param_data = data[self.parameters].values
        
        # Pearson correlation
        pearson_matrix = np.corrcoef(param_data.T)
        
        # Spearman correlation (rank-based)
        from scipy.stats import spearmanr
        spearman_matrix, p_matrix = spearmanr(param_data)
        
        # Reshape p_matrix if needed
        if p_matrix.ndim == 1:
            p_matrix = p_matrix.reshape(len(self.parameters), len(self.parameters))
        
        # Find significant correlations (p < 0.05)
        significant = []
        for i in range(len(self.parameters)):
            for j in range(i+1, len(self.parameters)):
                p_val = p_matrix[i, j]
                if p_val < 0.05:
                    significant.append({
                        'param1': self.parameters[i],
                        'param2': self.parameters[j],
                        'pearson': pearson_matrix[i, j],
                        'spearman': spearman_matrix[i, j],
                        'p_value': p_val
                    })
        
        return CorrelationResult(
            pearson_matrix=pearson_matrix,
            spearman_matrix=spearman_matrix,
            p_values=p_matrix,
            parameters=self.parameters,
            significant_correlations=significant
        )
    
    def calculate_site_correlations(self, site_data: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        Calculate correlations for each site separately
        
        Args:
            site_data: Dictionary mapping site -> DataFrame
            
        Returns:
            Site-specific correlation statistics
        """
        site_results = {}
        
        for site, df in site_data.items():
            try:
                result = self.calculate(df)
                site_results[site] = {
                    'pearson': result.pearson_matrix,
                    'spearman': result.spearman_matrix,
                    'significant': result.significant_correlations,
                    'n_samples': len(df)
                }
            except Exception as e:
                site_results[site] = {'error': str(e)}
        
        # Calculate consistency across sites
        pearson_matrices = [r['pearson'] for r in site_results.values() 
                           if 'pearson' in r]
        
        if pearson_matrices:
            mean_pearson = np.mean(pearson_matrices, axis=0)
            std_pearson = np.std(pearson_matrices, axis=0)
        else:
            mean_pearson = std_pearson = None
        
        return {
            'site_results': site_results,
            'mean_pearson': mean_pearson,
            'std_pearson': std_pearson,
            'n_sites': len(site_results)
        }
    
    def temporal_correlation(self, data: pd.DataFrame,
                            time_col: str = 'year') -> Dict[str, Any]:
        """
        Calculate correlation with time (trends)
        
        Args:
            data: DataFrame with parameters and time column
            time_col: Column name for time
            
        Returns:
            Trends for each parameter
        """
        if time_col not in data.columns:
            raise ValueError(f"Time column {time_col} not found")
        
        trends = {}
        
        for param in self.parameters:
            if param in data.columns:
                # Remove NaNs
                mask = ~(data[param].isna() | data[time_col].isna())
                x = data.loc[mask, time_col].values
                y = data.loc[mask, param].values
                
                if len(x) > 1:
                    from scipy import stats
                    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
                    
                    trends[param] = {
                        'slope': slope,
                        'intercept': intercept,
                        'correlation': r_value,
                        'p_value': p_value,
                        'significant': p_value < 0.05,
                        'n': len(x)
                    }
                else:
                    trends[param] = {'error': 'Insufficient data'}
        
        return trends
    
    def plot_correlation_matrix(self, matrix: np.ndarray,
                               title: str = "Parameter Correlation Matrix",
                               figsize: tuple = (10, 8)) -> Any:
        """
        Create correlation matrix plot
        
        Args:
            matrix: Correlation matrix
            title: Plot title
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Create mask for upper triangle
        mask = np.triu(np.ones_like(matrix, dtype=bool), k=1)
        
        # Plot heatmap
        sns.heatmap(matrix, 
                   mask=mask,
                   annot=True, 
                   fmt='.2f',
                   cmap='RdBu_r',
                   vmin=-1, vmax=1,
                   xticklabels=self.parameters,
                   yticklabels=self.parameters,
                   ax=ax)
        
        ax.set_title(title)
        plt.tight_layout()
        
        return fig
    
    def network_graph(self, correlation_result: CorrelationResult,
                     threshold: float = 0.5) -> Dict[str, Any]:
        """
        Create network graph of significant correlations
        
        Args:
            correlation_result: CorrelationResult object
            threshold: Minimum correlation to include
            
        Returns:
            Network structure for visualization
        """
        nodes = [{'id': p, 'group': 1} for p in self.parameters]
        
        links = []
        for i in range(len(self.parameters)):
            for j in range(i+1, len(self.parameters)):
                corr = correlation_result.pearson_matrix[i, j]
                p_val = correlation_result.p_values[i, j]
                
                if abs(corr) >= threshold and p_val < 0.05:
                    links.append({
                        'source': self.parameters[i],
                        'target': self.parameters[j],
                        'value': abs(corr),
                        'sign': 'positive' if corr > 0 else 'negative'
                    })
        
        return {
            'nodes': nodes,
            'links': links,
            'n_nodes': len(nodes),
            'n_links': len(links)
        }
    
    def report(self, correlation_result: CorrelationResult) -> str:
        """
        Generate formatted correlation report
        
        Args:
            correlation_result: CorrelationResult object
            
        Returns:
            Formatted report string
        """
        report = []
        report.append("=" * 60)
        report.append("PALMA CORRELATION ANALYSIS REPORT")
        report.append("=" * 60)
        report.append("")
        
        # Pearson matrix
        report.append("PEARSON CORRELATION MATRIX:")
        report.append("-" * 40)
        
        # Header
        header = "          " + " ".join([f"{p:>6}" for p in self.parameters])
        report.append(header)
        
        for i, p1 in enumerate(self.parameters):
            row = [f"{p1:>6}"]
            for j, p2 in enumerate(self.parameters):
                if j <= i:
                    row.append(f"{correlation_result.pearson_matrix[i, j]:6.2f}")
                else:
                    row.append("     ")
            report.append(" ".join(row))
        
        report.append("")
        
        # Significant correlations
        report.append("SIGNIFICANT CORRELATIONS (p < 0.05):")
        report.append("-" * 40)
        
        if correlation_result.significant_correlations:
            for corr in correlation_result.significant_correlations:
                report.append(
                    f"  {corr['param1']} - {corr['param2']}: "
                    f"r = {corr['pearson']:.3f}, "
                    f"ρ = {corr['spearman']:.3f}, "
                    f"p = {corr['p_value']:.4f}"
                )
        else:
            report.append("  No significant correlations found")
        
        report.append("")
        report.append("=" * 60)
        
        return "\n".join(report)
    
    def __repr__(self) -> str:
        return "CorrelationMatrix()"
