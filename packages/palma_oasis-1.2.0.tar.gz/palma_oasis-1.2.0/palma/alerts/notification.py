"""
Notification Dispatcher for PALMA Alerts

Sends alerts via:
- Email
- SMS
- Webhook
- Slack
"""

import smtplib
import requests
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from pathlib import Path


@dataclass
class NotificationConfig:
    """Notification configuration"""
    email_enabled: bool = True
    sms_enabled: bool = False
    webhook_enabled: bool = True
    slack_enabled: bool = False
    
    # Email settings
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    email_sender: str = "alerts@palma.org"
    email_recipients: List[str] = None
    
    # SMS settings (using Twilio)
    twilio_account_sid: str = None
    twilio_auth_token: str = None
    twilio_from_number: str = None
    sms_recipients: List[str] = None
    
    # Webhook settings
    webhook_url: str = None
    webhook_headers: Dict[str, str] = None
    
    # Slack settings
    slack_webhook_url: str = None


class NotificationDispatcher:
    """
    Dispatch alerts through multiple channels
    
    Supports email, SMS, webhook, and Slack notifications
    """
    
    def __init__(self, config: Optional[NotificationConfig] = None):
        """
        Initialize notification dispatcher
        
        Args:
            config: Notification configuration
        """
        self.config = config or NotificationConfig()
        
        # Load from environment if available
        self._load_from_env()
        
    def _load_from_env(self):
        """Load configuration from environment variables"""
        import os
        
        if os.getenv('PALMA_EMAIL_HOST'):
            self.config.smtp_host = os.getenv('PALMA_EMAIL_HOST')
        
        if os.getenv('PALMA_EMAIL_PORT'):
            self.config.smtp_port = int(os.getenv('PALMA_EMAIL_PORT'))
        
        if os.getenv('PALMA_EMAIL_USER'):
            self.config.email_sender = os.getenv('PALMA_EMAIL_USER')
        
        if os.getenv('PALMA_EMAIL_PASSWORD'):
            self.email_password = os.getenv('PALMA_EMAIL_PASSWORD')
        
        if os.getenv('PALMA_WEBHOOK_URL'):
            self.config.webhook_url = os.getenv('PALMA_WEBHOOK_URL')
        
        if os.getenv('PALMA_SLACK_WEBHOOK'):
            self.config.slack_webhook_url = os.getenv('PALMA_SLACK_WEBHOOK')
    
    def send_alert(self, alert_message: str, 
                  alert_level: str,
                  site: str,
                  details: Optional[Dict] = None) -> Dict[str, bool]:
        """
        Send alert through all enabled channels
        
        Args:
            alert_message: Alert message text
            alert_level: Alert level (MODERATE, CRITICAL, COLLAPSE)
            site: Site name
            details: Additional details
            
        Returns:
            Dictionary with success status per channel
        """
        results = {}
        
        if self.config.email_enabled:
            results['email'] = self.send_email(alert_message, alert_level, site, details)
        
        if self.config.sms_enabled:
            results['sms'] = self.send_sms(alert_message, site)
        
        if self.config.webhook_enabled and self.config.webhook_url:
            results['webhook'] = self.send_webhook(alert_message, alert_level, site, details)
        
        if self.config.slack_enabled and self.config.slack_webhook_url:
            results['slack'] = self.send_slack(alert_message, alert_level, site, details)
        
        return results
    
    def send_email(self, message: str, level: str,
                  site: str, details: Optional[Dict] = None) -> bool:
        """
        Send email alert
        
        Args:
            message: Alert message
            level: Alert level
            site: Site name
            details: Additional details
            
        Returns:
            True if successful
        """
        if not self.config.email_recipients:
            return False
        
        try:
            # Create message
            msg = MIMEMultipart()
            msg['From'] = self.config.email_sender
            msg['To'] = ', '.join(self.config.email_recipients)
            msg['Subject'] = f"[PALMA] {level} ALERT - {site}"
            
            # Create body
            body = f"""
            <h2>PALMA Alert - {level}</h2>
            <p><strong>Site:</strong> {site}</p>
            <p><strong>Time:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p><strong>Message:</strong> {message}</p>
            """
            
            if details:
                body += "<h3>Details:</h3><pre>"
                body += json.dumps(details, indent=2)
                body += "</pre>"
            
            msg.attach(MIMEText(body, 'html'))
            
            # Send email
            server = smtplib.SMTP(self.config.smtp_host, self.config.smtp_port)
            server.starttls()
            
            if hasattr(self, 'email_password'):
                server.login(self.config.email_sender, self.email_password)
            
            server.send_message(msg)
            server.quit()
            
            return True
            
        except Exception as e:
            print(f"Email sending failed: {e}")
            return False
    
    def send_sms(self, message: str, site: str) -> bool:
        """
        Send SMS alert using Twilio
        
        Args:
            message: Alert message
            site: Site name
            
        Returns:
            True if successful
        """
        if not all([self.config.twilio_account_sid, 
                   self.config.twilio_auth_token,
                   self.config.twilio_from_number,
                   self.config.sms_recipients]):
            return False
        
        try:
            from twilio.rest import Client
            
            client = Client(self.config.twilio_account_sid, 
                           self.config.twilio_auth_token)
            
            sms_body = f"PALMA Alert - {site}: {message[:140]}"
            
            for recipient in self.config.sms_recipients:
                client.messages.create(
                    body=sms_body,
                    from_=self.config.twilio_from_number,
                    to=recipient
                )
            
            return True
            
        except Exception as e:
            print(f"SMS sending failed: {e}")
            return False
    
    def send_webhook(self, message: str, level: str,
                    site: str, details: Optional[Dict] = None) -> bool:
        """
        Send webhook alert
        
        Args:
            message: Alert message
            level: Alert level
            site: Site name
            details: Additional details
            
        Returns:
            True if successful
        """
        if not self.config.webhook_url:
            return False
        
        try:
            payload = {
                'alert': {
                    'site': site,
                    'level': level,
                    'message': message,
                    'timestamp': datetime.now().isoformat(),
                    'details': details or {}
                }
            }
            
            headers = {'Content-Type': 'application/json'}
            if self.config.webhook_headers:
                headers.update(self.config.webhook_headers)
            
            response = requests.post(
                self.config.webhook_url,
                json=payload,
                headers=headers,
                timeout=10
            )
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"Webhook sending failed: {e}")
            return False
    
    def send_slack(self, message: str, level: str,
                  site: str, details: Optional[Dict] = None) -> bool:
        """
        Send Slack alert
        
        Args:
            message: Alert message
            level: Alert level
            site: Site name
            details: Additional details
            
        Returns:
            True if successful
        """
        if not self.config.slack_webhook_url:
            return False
        
        # Color coding by level
        colors = {
            'MODERATE': '#FFA500',  # Orange
            'CRITICAL': '#FF0000',   # Red
            'COLLAPSE': '#800080'    # Purple
        }
        
        try:
            payload = {
                'attachments': [{
                    'color': colors.get(level, '#808080'),
                    'title': f"PALMA {level} Alert - {site}",
                    'text': message,
                    'fields': [
                        {'title': 'Site', 'value': site, 'short': True},
                        {'title': 'Level', 'value': level, 'short': True},
                        {'title': 'Time', 'value': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'short': True}
                    ],
                    'footer': 'PALMA Monitoring System',
                    'ts': int(datetime.now().timestamp())
                }]
            }
            
            if details:
                payload['attachments'][0]['fields'].append({
                    'title': 'Details',
                    'value': f"```{json.dumps(details, indent=2)}```",
                    'short': False
                })
            
            response = requests.post(
                self.config.slack_webhook_url,
                json=payload,
                timeout=10
            )
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"Slack notification failed: {e}")
            return False
    
    def test_connections(self) -> Dict[str, bool]:
        """Test all notification channels"""
        test_message = "PALMA system test notification"
        test_site = "test_site"
        
        return self.send_alert(test_message, "TEST", test_site)
    
    def load_config_from_file(self, filepath: str) -> bool:
        """Load configuration from JSON file"""
        path = Path(filepath)
        if not path.exists():
            return False
        
        with open(path, 'r') as f:
            config_data = json.load(f)
        
        self.config = NotificationConfig(**config_data)
        return True
    
    def __repr__(self) -> str:
        channels = []
        if self.config.email_enabled:
            channels.append('email')
        if self.config.sms_enabled:
            channels.append('sms')
        if self.config.webhook_enabled:
            channels.append('webhook')
        if self.config.slack_enabled:
            channels.append('slack')
        
        return f"NotificationDispatcher(channels={channels})"


# Import for datetime
from datetime import datetime
