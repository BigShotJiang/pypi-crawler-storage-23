"""
Threshold Monitor for Real-time OHI Alerts

Monitors Oasis Health Index against predefined thresholds
Triggers alerts when critical levels are reached
"""

import numpy as np
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime, timedelta
import json


@dataclass
class Alert:
    """Alert information"""
    site: str
    level: str  # MODERATE, CRITICAL, COLLAPSE
    ohi_value: float
    timestamp: datetime
    message: str
    parameters_at_risk: List[str]
    lead_time_estimate: float  # days
    acknowledged: bool = False


class ThresholdMonitor:
    """
    Real-time monitor for OHI thresholds
    
    Thresholds from paper:
    - EXCELLENT: < 0.25
    - GOOD: 0.25-0.45
    - MODERATE: 0.45-0.65
    - CRITICAL: 0.65-0.80
    - COLLAPSE: > 0.80
    """
    
    def __init__(self, thresholds: Optional[Dict[str, float]] = None):
        """
        Initialize threshold monitor
        
        Args:
            thresholds: Custom threshold values
        """
        self.thresholds = thresholds or {
            'excellent': 0.25,
            'good': 0.45,
            'moderate': 0.65,
            'critical': 0.80
        }
        
        self.alerts = []
        self.alert_history = []
        
    def check_ohi(self, site: str, ohi_value: float,
                 parameters: Dict[str, float],
                 timestamp: Optional[datetime] = None) -> Optional[Alert]:
        """
        Check OHI against thresholds and generate alert if needed
        
        Args:
            site: Site name
            ohi_value: Current OHI value
            parameters: Individual parameter values
            timestamp: Current time
            
        Returns:
            Alert object if threshold exceeded, None otherwise
        """
        if timestamp is None:
            timestamp = datetime.now()
        
        # Determine level
        if ohi_value < self.thresholds['excellent']:
            level = "EXCELLENT"
        elif ohi_value < self.thresholds['good']:
            level = "GOOD"
        elif ohi_value < self.thresholds['moderate']:
            level = "MODERATE"
        elif ohi_value < self.thresholds['critical']:
            level = "CRITICAL"
        else:
            level = "COLLAPSE"
        
        # Check if alert needed (MODERATE or worse)
        if level in ["MODERATE", "CRITICAL", "COLLAPSE"]:
            # Find parameters at risk
            at_risk = self._parameters_at_risk(parameters)
            
            # Estimate lead time
            lead_time = self._estimate_lead_time(ohi_value, parameters)
            
            # Create message
            message = self._create_message(site, level, ohi_value, at_risk, lead_time)
            
            alert = Alert(
                site=site,
                level=level,
                ohi_value=ohi_value,
                timestamp=timestamp,
                message=message,
                parameters_at_risk=at_risk,
                lead_time_estimate=lead_time
            )
            
            self.alerts.append(alert)
            self.alert_history.append(alert)
            
            return alert
        
        return None
    
    def _parameters_at_risk(self, parameters: Dict[str, float]) -> List[str]:
        """Identify parameters contributing to high OHI"""
        at_risk = []
        
        # Parameter thresholds (normalized)
        thresholds = {
            'ARVC': 0.75,  # Above this is concerning
            'PTSI': 0.65,
            'SSSP': 0.65,
            'CMBF': 0.65,
            'SVRI': 0.65,
            'WEPR': 0.65,
            'BST': 0.65
        }
        
        for param, value in parameters.items():
            if param in thresholds and value > thresholds[param]:
                at_risk.append(param)
        
        return at_risk
    
    def _estimate_lead_time(self, ohi: float, 
                           parameters: Dict[str, float]) -> float:
        """Estimate lead time until critical threshold"""
        if ohi > self.thresholds['critical']:
            return 0.0
        
        # Calculate rate of change (simplified)
        # Would use historical data in practice
        rate = 0.01  # Assumed rate per day
        
        time_to_critical = (self.thresholds['critical'] - ohi) / rate
        
        return max(0, time_to_critical)
    
    def _create_message(self, site: str, level: str, 
                       ohi: float, at_risk: List[str],
                       lead_time: float) -> str:
        """Create alert message"""
        messages = {
            "MODERATE": "⚠️ MODERATE ALERT: Intervention planning required",
            "CRITICAL": "🔴 CRITICAL ALERT: Emergency water allocation needed",
            "COLLAPSE": "⚫ COLLAPSE ALERT: Emergency restoration protocol"
        }
        
        base_msg = messages.get(level, f"Alert: {level}")
        
        details = [
            f"Site: {site}",
            f"OHI: {ohi:.3f}",
            f"Lead time: {lead_time:.1f} days"
        ]
        
        if at_risk:
            details.append(f"Parameters at risk: {', '.join(at_risk)}")
        
        return f"{base_msg}\n" + "\n".join(details)
    
    def get_active_alerts(self) -> List[Alert]:
        """Get currently active alerts"""
        # Consider alerts from last 24 hours as active
        cutoff = datetime.now() - timedelta(hours=24)
        active = [a for a in self.alerts if a.timestamp > cutoff and not a.acknowledged]
        return active
    
    def acknowledge_alert(self, alert_index: int) -> bool:
        """Acknowledge an alert"""
        if 0 <= alert_index < len(self.alerts):
            self.alerts[alert_index].acknowledged = True
            return True
        return False
    
    def clear_alerts(self) -> None:
        """Clear all active alerts"""
        self.alerts = []
    
    def alert_summary(self) -> Dict[str, Any]:
        """Get summary of recent alerts"""
        active = self.get_active_alerts()
        
        return {
            'active_count': len(active),
            'by_level': {
                'MODERATE': len([a for a in active if a.level == "MODERATE"]),
                'CRITICAL': len([a for a in active if a.level == "CRITICAL"]),
                'COLLAPSE': len([a for a in active if a.level == "COLLAPSE"])
            },
            'by_site': self._count_by_site(active),
            'oldest_alert': min([a.timestamp for a in active]) if active else None,
            'total_history': len(self.alert_history)
        }
    
    def _count_by_site(self, alerts: List[Alert]) -> Dict[str, int]:
        """Count alerts by site"""
        site_counts = {}
        for alert in alerts:
            site_counts[alert.site] = site_counts.get(alert.site, 0) + 1
        return site_counts
    
    def export_alerts(self, filepath: str) -> None:
        """Export alerts to JSON file"""
        data = []
        for alert in self.alert_history:
            data.append({
                'site': alert.site,
                'level': alert.level,
                'ohi_value': alert.ohi_value,
                'timestamp': alert.timestamp.isoformat(),
                'message': alert.message,
                'parameters_at_risk': alert.parameters_at_risk,
                'lead_time_estimate': alert.lead_time_estimate,
                'acknowledged': alert.acknowledged
            })
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def __repr__(self) -> str:
        return f"ThresholdMonitor(active={len(self.get_active_alerts())})"
