"""
Lead Time Estimator for Early Warning System

Predicts time until critical threshold crossing
Based on empirical relationships from 31-site validation
Mean lead time: 52 days, Max: 118 days
"""

import numpy as np
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class LeadTimeEstimate:
    """Lead time estimation result"""
    days: float
    confidence: float  # 0-1
    method: str
    contributing_factors: Dict[str, float]


class LeadTimeEstimator:
    """
    Early warning lead time predictor
    
    Estimates days until ecosystem reaches critical threshold
    Based on PALMA validation across 31 sites
    """
    
    def __init__(self):
        """Initialize lead time estimator"""
        # Empirical parameters from paper
        self.mean_lead_time = 52  # days
        self.max_lead_time = 118  # days
        self.min_lead_time = 8    # days (acute events)
        
    def estimate_from_ohi(self, current_ohi: float,
                         trend: Optional[float] = None,
                         site_type: str = 'artesian') -> LeadTimeEstimate:
        """
        Estimate lead time from current OHI
        
        Args:
            current_ohi: Current OHI value
            trend: Rate of change (per day)
            site_type: Type of oasis (artesian, wadi, aquifer, fog)
            
        Returns:
            Lead time estimate
        """
        critical_threshold = 0.65
        
        if current_ohi >= critical_threshold:
            return LeadTimeEstimate(
                days=0,
                confidence=0.9,
                method='threshold_exceeded',
                contributing_factors={'current_ohi': current_ohi}
            )
        
        # Use trend if available
        if trend is not None and trend > 0:
            days = (critical_threshold - current_ohi) / trend
        else:
            # Empirical relationship from paper
            # Higher OHI = shorter lead time
            normalized = current_ohi / critical_threshold
            
            if normalized < 0.5:
                days = self.max_lead_time
            elif normalized < 0.8:
                days = self.mean_lead_time * (1 - (normalized - 0.5) / 0.3)
            else:
                days = self.min_lead_time * (1 - normalized) / 0.2
        
        # Adjust by site type
        site_multipliers = {
            'artesian': 1.2,    # Longer lead time
            'wadi': 1.0,
            'aquifer': 0.9,
            'fog': 0.6,         # Shorter lead time
            'agricultural': 1.1
        }
        
        multiplier = site_multipliers.get(site_type, 1.0)
        days *= multiplier
        
        # Confidence based on data quality
        if trend is not None:
            confidence = 0.8
        else:
            confidence = 0.6
        
        return LeadTimeEstimate(
            days=max(0, days),
            confidence=confidence,
            method='ohi_based',
            contributing_factors={
                'current_ohi': current_ohi,
                'trend': trend if trend is not None else 0,
                'site_type': site_type,
                'multiplier': multiplier
            }
        )
    
    def estimate_from_parameters(self, parameters: Dict[str, float],
                                site_type: str = 'artesian') -> LeadTimeEstimate:
        """
        Estimate lead time from individual parameters
        
        Uses parameter-specific early warning signals
        """
        # Parameter weights for early warning
        param_weights = {
            'ARVC': 0.35,  # Aquifer gives earliest warning
            'SSSP': 0.25,  # Salinity accumulates slowly
            'SVRI': 0.20,  # Spectral changes
            'PTSI': 0.10,
            'CMBF': 0.05,
            'WEPR': 0.03,
            'BST': 0.02
        }
        
        # Parameter-specific lead times (days)
        param_lead_times = {
            'ARVC': 90,
            'SSSP': 60,
            'SVRI': 45,
            'PTSI': 30,
            'CMBF': 25,
            'WEPR': 20,
            'BST': 15
        }
        
        # Calculate weighted lead time
        weighted_lead = 0
        total_weight = 0
        
        for param, value in parameters.items():
            if param in param_weights and param in param_lead_times:
                # Normalize parameter value (higher = more stress)
                weight = param_weights[param] * (1 + value)
                weighted_lead += weight * param_lead_times[param]
                total_weight += weight
        
        if total_weight > 0:
            lead_days = weighted_lead / total_weight
        else:
            lead_days = self.mean_lead_time
        
        # Adjust by site type
        site_multipliers = {
            'artesian': 1.3,
            'wadi': 1.0,
            'aquifer': 0.9,
            'fog': 0.5
        }
        
        lead_days *= site_multipliers.get(site_type, 1.0)
        
        return LeadTimeEstimate(
            days=lead_days,
            confidence=0.7,
            method='parameter_ensemble',
            contributing_factors={
                'weighted_lead': weighted_lead,
                'total_weight': total_weight,
                'parameters': parameters
            }
        )
    
    def ensemble_estimate(self, current_ohi: float,
                         parameters: Dict[str, float],
                         historical_data: Optional[np.ndarray] = None,
                         site_type: str = 'artesian') -> LeadTimeEstimate:
        """
        Ensemble estimate combining multiple methods
        
        Args:
            current_ohi: Current OHI
            parameters: Current parameters
            historical_data: Historical OHI time series
            site_type: Site type
            
        Returns:
            Combined lead time estimate
        """
        estimates = []
        
        # Method 1: OHI-based
        if current_ohi is not None:
            est1 = self.estimate_from_ohi(current_ohi, site_type=site_type)
            estimates.append(est1)
        
        # Method 2: Parameter-based
        if parameters:
            est2 = self.estimate_from_parameters(parameters, site_type)
            estimates.append(est2)
        
        # Method 3: Trend-based from historical data
        if historical_data is not None and len(historical_data) > 1:
            # Calculate trend
            x = np.arange(len(historical_data))
            y = historical_data
            slope = np.polyfit(x, y, 1)[0]
            
            if slope > 0:
                days_to_critical = (0.65 - y[-1]) / slope
                est3 = LeadTimeEstimate(
                    days=max(0, days_to_critical),
                    confidence=0.75,
                    method='trend',
                    contributing_factors={'slope': slope}
                )
                estimates.append(est3)
        
        if not estimates:
            return LeadTimeEstimate(
                days=self.mean_lead_time,
                confidence=0.3,
                method='default',
                contributing_factors={}
            )
        
        # Combine estimates (weighted by confidence)
        total_days = 0
        total_confidence = 0
        
        for est in estimates:
            total_days += est.days * est.confidence
            total_confidence += est.confidence
        
        ensemble_days = total_days / total_confidence if total_confidence > 0 else self.mean_lead_time
        
        return LeadTimeEstimate(
            days=ensemble_days,
            confidence=min(0.9, total_confidence / len(estimates)),
            method='ensemble',
            contributing_factors={
                'n_methods': len(estimates),
                'individual_estimates': [e.days for e in estimates]
            }
        )
    
    def calculate_confidence(self, lead_time: float,
                           data_quality: float = 0.8) -> float:
        """Calculate confidence in lead time estimate"""
        # Longer lead times have lower confidence
        confidence = data_quality * np.exp(-lead_time / 200)
        return min(0.95, confidence)
    
    def get_warning_level(self, lead_time: float) -> str:
        """Get warning level based on lead time"""
        if lead_time <= 0:
            return "IMMEDIATE"
        elif lead_time < 14:
            return "SHORT_TERM"
        elif lead_time < 30:
            return "MEDIUM_TERM"
        elif lead_time < 60:
            return "LONG_TERM"
        else:
            return "EXTENDED"
    
    def actionable_recommendations(self, lead_time: float,
                                  site_type: str) -> List[str]:
        """Generate recommendations based on lead time"""
        recommendations = []
        
        if lead_time < 14:
            recommendations.append("EMERGENCY: Immediate intervention required")
            recommendations.append("Activate emergency water allocation")
            recommendations.append("Prepare for possible evacuation if collapse imminent")
        elif lead_time < 30:
            recommendations.append("URGENT: Implement rapid response measures")
            recommendations.append("Increase monitoring frequency to daily")
            recommendations.append("Begin public notification if needed")
        elif lead_time < 60:
            recommendations.append("PLANNING: Develop intervention strategy")
            recommendations.append("Schedule stakeholder meetings")
            recommendations.append("Review water allocation policies")
        else:
            recommendations.append("MONITORING: Continue regular observation")
            recommendations.append("Update risk assessments")
            recommendations.append("Maintain preparedness measures")
        
        return recommendations
    
    def __repr__(self) -> str:
        return f"LeadTimeEstimator(mean={self.mean_lead_time} days)"
