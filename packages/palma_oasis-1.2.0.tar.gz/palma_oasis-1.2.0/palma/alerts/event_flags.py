"""
Extreme Event Flagging for PALMA

Flags extreme events:
- Flash floods
- Dust storms
- Heat waves
- Drought events

Prevents false alerts during extreme conditions
"""

import numpy as np
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class EventFlag:
    """Extreme event flag"""
    event_type: str
    start_time: datetime
    end_time: Optional[datetime]
    intensity: float  # 0-1 scale
    description: str
    affected_sites: List[str]


class EventFlagging:
    """
    Extreme event detection and flagging
    
    Flags events that cause temporary anomalies in parameters
    Prevents false alerts during extreme conditions
    """
    
    def __init__(self):
        """Initialize event flagging"""
        self.active_events = []
        self.event_history = []
        
        # Thresholds for detection
        self.thresholds = {
            'flash_flood': {
                'rainfall_rate': 50,  # mm/hour
                'duration_hours': 6
            },
            'dust_storm': {
                'aerosol_index': 2.0,
                'visibility_km': 1.0
            },
            'heat_wave': {
                'temp_threshold': 45,  # °C
                'min_days': 3
            },
            'drought': {
                'precip_anomaly': -0.5,  # 50% below normal
                'min_months': 3
            }
        }
        
    def check_flash_flood(self, rainfall_data: Dict[str, Any]) -> Optional[EventFlag]:
        """
        Check for flash flood conditions
        
        Args:
            rainfall_data: Rainfall measurements
            
        Returns:
            EventFlag if flash flood detected
        """
        if 'rainfall_rate' not in rainfall_data:
            return None
        
        rate = rainfall_data['rainfall_rate']  # mm/hour
        
        if rate > self.thresholds['flash_flood']['rainfall_rate']:
            return EventFlag(
                event_type='FLASH_FLOOD',
                start_time=datetime.now(),
                end_time=None,
                intensity=min(1.0, rate / 100),
                description=f"Flash flood with {rate:.1f} mm/hr rainfall",
                affected_sites=rainfall_data.get('sites', [])
            )
        
        return None
    
    def check_dust_storm(self, aerosol_data: Dict[str, Any]) -> Optional[EventFlag]:
        """
        Check for dust storm conditions
        
        Args:
            aerosol_data: Aerosol index or visibility data
            
        Returns:
            EventFlag if dust storm detected
        """
        if 'aerosol_index' in aerosol_data:
            ai = aerosol_data['aerosol_index']
            if ai > self.thresholds['dust_storm']['aerosol_index']:
                return EventFlag(
                    event_type='DUST_STORM',
                    start_time=datetime.now(),
                    end_time=None,
                    intensity=min(1.0, ai / 3.0),
                    description=f"Dust storm with aerosol index {ai:.2f}",
                    affected_sites=aerosol_data.get('sites', [])
                )
        
        if 'visibility' in aerosol_data:
            vis = aerosol_data['visibility']  # km
            if vis < self.thresholds['dust_storm']['visibility_km']:
                return EventFlag(
                    event_type='DUST_STORM',
                    start_time=datetime.now(),
                    end_time=None,
                    intensity=min(1.0, 1 - vis/10),
                    description=f"Dust storm with visibility {vis:.1f} km",
                    affected_sites=aerosol_data.get('sites', [])
                )
        
        return None
    
    def check_heat_wave(self, temperature_data: Dict[str, Any]) -> Optional[EventFlag]:
        """
        Check for heat wave conditions
        
        Args:
            temperature_data: Temperature time series
            
        Returns:
            EventFlag if heat wave detected
        """
        if 'temperatures' not in temperature_data:
            return None
        
        temps = np.array(temperature_data['temperatures'])
        threshold = self.thresholds['heat_wave']['temp_threshold']
        min_days = self.thresholds['heat_wave']['min_days']
        
        # Count consecutive days above threshold
        above = temps > threshold
        consecutive = 0
        max_consecutive = 0
        
        for val in above:
            if val:
                consecutive += 1
                max_consecutive = max(max_consecutive, consecutive)
            else:
                consecutive = 0
        
        if max_consecutive >= min_days:
            return EventFlag(
                event_type='HEAT_WAVE',
                start_time=datetime.now() - timedelta(days=max_consecutive),
                end_time=datetime.now(),
                intensity=min(1.0, max_consecutive / 10),
                description=f"Heat wave: {max_consecutive} days above {threshold}°C",
                affected_sites=temperature_data.get('sites', [])
            )
        
        return None
    
    def check_drought(self, climate_data: Dict[str, Any]) -> Optional[EventFlag]:
        """
        Check for drought conditions
        
        Args:
            climate_data: Precipitation and climate indices
            
        Returns:
            EventFlag if drought detected
        """
        if 'precipitation_anomaly' not in climate_data:
            return None
        
        anomaly = climate_data['precipitation_anomaly']  # Fraction of normal
        
        if anomaly < self.thresholds['drought']['precip_anomaly']:
            duration = climate_data.get('duration_months', 3)
            
            if duration >= self.thresholds['drought']['min_months']:
                return EventFlag(
                    event_type='DROUGHT',
                    start_time=datetime.now() - timedelta(days=30*duration),
                    end_time=datetime.now(),
                    intensity=min(1.0, -anomaly),
                    description=f"Drought: {duration} months with {anomaly*100:.0f}% of normal precip",
                    affected_sites=climate_data.get('sites', [])
                )
        
        return None
    
    def check_all(self, data: Dict[str, Any]) -> List[EventFlag]:
        """
        Check all event types
        
        Args:
            data: Dictionary with all relevant data
            
        Returns:
            List of detected events
        """
        events = []
        
        # Check each event type
        if 'rainfall' in data:
            flood = self.check_flash_flood(data['rainfall'])
            if flood:
                events.append(flood)
        
        if 'aerosol' in data:
            dust = self.check_dust_storm(data['aerosol'])
            if dust:
                events.append(dust)
        
        if 'temperature' in data:
            heat = self.check_heat_wave(data['temperature'])
            if heat:
                events.append(heat)
        
        if 'climate' in data:
            drought = self.check_drought(data['climate'])
            if drought:
                events.append(drought)
        
        # Update active events
        for event in events:
            self.active_events.append(event)
            self.event_history.append(event)
        
        return events
    
    def resolve_event(self, event_type: str) -> bool:
        """Mark an event as resolved"""
        for event in self.active_events:
            if event.event_type == event_type and event.end_time is None:
                event.end_time = datetime.now()
                self.active_events.remove(event)
                return True
        return False
    
    def is_active(self, event_type: str) -> bool:
        """Check if event type is currently active"""
        return any(e.event_type == event_type for e in self.active_events)
    
    def get_active_events(self) -> List[EventFlag]:
        """Get currently active events"""
        return self.active_events
    
    def flag_anomaly(self, param_name: str, value: float,
                    normal_range: tuple) -> bool:
        """
        Check if value is anomalous due to extreme event
        
        Args:
            param_name: Parameter name
            value: Current value
            normal_range: (min, max) normal range
            
        Returns:
            True if likely event-related anomaly
        """
        if not self.active_events:
            return False
        
        # Check if any active event could affect this parameter
        for event in self.active_events:
            if event.event_type == 'FLASH_FLOOD' and param_name in ['ARVC', 'WEPR']:
                # Floods cause temporary ARVC spikes
                if value > normal_range[1] * 1.5:
                    return True
            
            elif event.event_type == 'DUST_STORM' and param_name in ['SVRI', 'PTSI']:
                # Dust affects spectral and thermal
                if value < normal_range[0] * 0.7:
                    return True
            
            elif event.event_type == 'HEAT_WAVE' and param_name in ['PTSI', 'CMBF']:
                # Heat affects thermal parameters
                if value > normal_range[1] * 1.3:
                    return True
            
            elif event.event_type == 'DROUGHT' and param_name in ['ARVC', 'WEPR', 'SVRI']:
                # Drought affects multiple parameters
                if value < normal_range[0] * 0.8:
                    return True
        
        return False
    
    def get_event_summary(self) -> Dict[str, Any]:
        """Get summary of recent events"""
        return {
            'active_count': len(self.active_events),
            'active_types': [e.event_type for e in self.active_events],
            'total_history': len(self.event_history),
            'by_type': self._count_by_type(),
            'last_event': self.event_history[-1] if self.event_history else None
        }
    
    def _count_by_type(self) -> Dict[str, int]:
        """Count events by type"""
        counts = {}
        for event in self.event_history:
            counts[event.event_type] = counts.get(event.event_type, 0) + 1
        return counts
    
    def export_events(self, filepath: str) -> None:
        """Export events to JSON"""
        import json
        
        data = []
        for event in self.event_history:
            data.append({
                'event_type': event.event_type,
                'start_time': event.start_time.isoformat(),
                'end_time': event.end_time.isoformat() if event.end_time else None,
                'intensity': event.intensity,
                'description': event.description,
                'affected_sites': event.affected_sites
            })
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def __repr__(self) -> str:
        return f"EventFlagging(active={len(self.active_events)})"
