# PALMA Authors and Contributors

## Core Development Team

| Name | Role | Affiliation | ORCID | Contact |
|------|------|-------------|-------|---------|
| **Samir Baladi** | Principal Investigator, Framework Design, Software Architecture | Ronin Institute / Rite of Renaissance | [0009-0003-8903-0029](https://orcid.org/0009-0003-8903-0029) | gitdeeper@gmail.com |
| **Dr. Leila Nassar** | PTSI & CMBF Thermal Parameterization, Saharan Field Campaigns | Desert Ecology Research Center, Ouargla, Algeria | [0000-0002-1845-6789](https://orcid.org/0000-0002-1845-6789) | l.nassar@desert-ecology.dz |
| **Prof. Tariq Al-Rashidi** | ARVC Aquifer Modeling, Arabian Peninsula Sites | Arabian Peninsula Environmental Sciences Institute, Riyadh | [0000-0001-2345-6789](https://orcid.org/0000-0001-2345-6789) | t.alrashidi@apei.edu.sa |
| **Dr. Amina Oufkir** | SSSP Salinity Validation, Draa-Tafilalet Network | Moroccan Royal Institute for Desert Studies | [0000-0003-4567-8901](https://orcid.org/0000-0003-4567-8901) | a.oufkir@moroccan-oasis.ma |
| **Dr. Youssef Hamdan** | SVRI Spectral Calibration, BST Biodiversity Surveys | MENA Sustainable Agriculture Center, Cairo | [0000-0002-3456-7890](https://orcid.org/0000-0002-3456-7890) | y.hamdan@mena-sac.eg |

## Contributing Researchers

| Name | Contribution | Affiliation |
|------|--------------|-------------|
| Dr. Fatima Zahra El Mansouri | Soil Chemistry Laboratory Analysis | Cadi Ayyad University, Marrakech |
| Dr. Abdullah Al-Saud | LiDAR Processing, Dunhuang Case Study | King Saud University, Riyadh |
| Prof. Ahmed Belbachir | Historical Oasis Documentation | University of Algiers |
| Dr. Elena Rodriguez | Atacama Desert Field Coordinator | University of Chile, Santiago |
| Dr. Wei Zhang | Karez System Hydraulic Modeling | Dunhuang Academy, China |
| Dr. Karim Ben Salem | Remote Sensing Validation | Institut des Régions Arides, Tunisia |

## Technical Contributors

- **Maria Gonzalez** - Dashboard UI/UX Design
- **Youssef El Kharraz** - Database Architecture
- **Omar Al-Jassim** - API Development
- **Sara Mahmoud** - Testing Automation
- **Ahmed Hassan** - Documentation

## Institutional Partners

- **Ronin Institute** - Project Host Institution
- **Desert Ecology Research Center (CRED)** - Algeria
- **Arabian Peninsula Environmental Sciences Institute (APEI)** - Saudi Arabia
- **Moroccan Royal Institute for Desert Studies (INREM)** - Morocco
- **MENA Sustainable Agriculture Center (MENSAC)** - Egypt
- **Dunhuang Academy** - China
- **UNESCO-IHP** - International Hydrological Programme
- **FAO** - Food and Agriculture Organization

## Field Station Networks

- Tafilalet Oasis Network (Morocco) - 12 stations
- Draa Valley Monitoring Network (Morocco) - 8 stations
- Al-Ahsa Oasis Network (Saudi Arabia) - 22 stations
- Al-Fayum Network (Egypt) - 14 stations
- Dunhuang Karez Network (China) - 16 stations
- Ghardaïa Network (Algeria) - 7 stations
- Atacama Network (Chile) - 5 stations
- Fergana Valley Network (Uzbekistan) - 9 stations

## Acknowledgments

The PALMA project acknowledges the traditional ecological knowledge of oasis farming communities across North Africa, the Arabian Peninsula, Central Asia, and the Atacama Desert, whose sustainable practices over millennia have preserved these irreplaceable ecosystems.

Special thanks to the water managers, farmers, and local authorities who granted access to monitoring sites and shared their ancestral knowledge of oasis systems.

## How to Contribute

We welcome contributions from researchers, developers, and practitioners. Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Contact

For correspondence regarding the PALMA framework:
- **Project Lead**: Samir Baladi - gitdeeper@gmail.com
- **Scientific Inquiries**: Dr. Leila Nassar - l.nassar@desert-ecology.dz
- **Technical Support**: palma-dev@googlegroups.com

---

**Last Updated**: February 2026
