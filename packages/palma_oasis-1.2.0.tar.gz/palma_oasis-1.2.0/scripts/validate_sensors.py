#!/usr/bin/env python3
"""
Sensor Network Health Checker
Validates sensor data quality and identifies issues
"""

import os
import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import argparse


class SensorValidator:
    """Validate sensor network health"""
    
    def __init__(self, site_name: str, data_dir: str = "data"):
        """
        Initialize sensor validator
        
        Args:
            site_name: Name of site to validate
            data_dir: Data directory (relative)
        """
        self.site_name = site_name
        self.data_dir = Path(__file__).parent.parent / data_dir
        self.site_data_dir = self.data_dir / site_name
        self.results = {}
        
    def validate_all(self) -> Dict[str, Any]:
        """Run all validation checks"""
        print(f"\n🔍 Validating sensors for site: {self.site_name}")
        print("="*60)
        
        # Check directory exists
        if not self.site_data_dir.exists():
            print(f"❌ Site data directory not found: {self.site_data_dir}")
            return {'error': 'Directory not found'}
        
        # Validate each sensor type
        self.results['piezometers'] = self._validate_piezometers()
        self.results['soil_ec'] = self._validate_soil_ec()
        self.results['thermocouples'] = self._validate_thermocouples()
        
        # Overall status
        all_healthy = all(r.get('healthy', False) for r in self.results.values())
        self.results['overall_healthy'] = all_healthy
        
        # Generate report
        self._print_summary()
        
        return self.results
    
    def _validate_piezometers(self) -> Dict[str, Any]:
        """Validate piezometer data"""
        result = {
            'type': 'Piezometer',
            'files_found': 0,
            'healthy': False,
            'issues': []
        }
        
        # Find piezometer data files
        piezo_files = list(self.site_data_dir.glob("*piezometer*.csv")) + \
                      list(self.site_data_dir.glob("*level*.csv"))
        
        result['files_found'] = len(piezo_files)
        
        if not piezo_files:
            result['issues'].append("No piezometer data files found")
            return result
        
        # Check each file
        for filepath in piezo_files:
            file_result = self._check_csv_file(filepath, ['water_level', 'level', 'head'])
            if not file_result['valid']:
                result['issues'].append(f"{filepath.name}: {file_result['message']}")
        
        # Check data recency
        latest = self._get_latest_timestamp(piezo_files)
        if latest:
            days_old = (datetime.now() - latest).days
            result['latest_data'] = latest.isoformat()
            result['days_old'] = days_old
            
            if days_old > 7:
                result['issues'].append(f"Data is {days_old} days old (>7 days)")
        
        result['healthy'] = len(result['issues']) == 0
        return result
    
    def _validate_soil_ec(self) -> Dict[str, Any]:
        """Validate soil EC sensor data"""
        result = {
            'type': 'Soil EC',
            'files_found': 0,
            'healthy': False,
            'issues': []
        }
        
        # Find soil EC data files
        ec_files = list(self.site_data_dir.glob("*ec*.csv")) + \
                   list(self.site_data_dir.glob("*salinity*.csv"))
        
        result['files_found'] = len(ec_files)
        
        if not ec_files:
            result['issues'].append("No soil EC data files found")
            return result
        
        # Check each file
        for filepath in ec_files:
            file_result = self._check_csv_file(filepath, ['ec', 'conductivity'])
            if not file_result['valid']:
                result['issues'].append(f"{filepath.name}: {file_result['message']}")
        
        result['healthy'] = len(result['issues']) == 0
        return result
    
    def _validate_thermocouples(self) -> Dict[str, Any]:
        """Validate thermocouple data"""
        result = {
            'type': 'Thermocouple',
            'files_found': 0,
            'healthy': False,
            'issues': []
        }
        
        # Find thermocouple data files
        temp_files = list(self.site_data_dir.glob("*temp*.csv")) + \
                     list(self.site_data_dir.glob("*thermal*.csv"))
        
        result['files_found'] = len(temp_files)
        
        if not temp_files:
            result['issues'].append("No temperature data files found")
            return result
        
        # Check each file
        for filepath in temp_files:
            file_result = self._check_csv_file(filepath, ['temperature', 'temp', '°C'])
            if not file_result['valid']:
                result['issues'].append(f"{filepath.name}: {file_result['message']}")
        
        result['healthy'] = len(result['issues']) == 0
        return result
    
    def _check_csv_file(self, filepath: Path, required_columns: List[str]) -> Dict[str, Any]:
        """Check CSV file for required columns and basic validity"""
        result = {'valid': False, 'message': ''}
        
        try:
            df = pd.read_csv(filepath, nrows=10)
            
            # Check for required columns
            found_columns = [col for col in df.columns 
                           if any(req in col.lower() for req in required_columns)]
            
            if not found_columns:
                result['message'] = f"Missing required columns: {required_columns}"
                return result
            
            # Check for datetime column
            datetime_cols = [col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()]
            if not datetime_cols:
                result['message'] = "No datetime column found"
                return result
            
            result['valid'] = True
            
        except Exception as e:
            result['message'] = f"Error reading file: {str(e)}"
        
        return result
    
    def _get_latest_timestamp(self, files: List[Path]) -> Optional[datetime]:
        """Get latest timestamp from data files"""
        latest = None
        
        for filepath in files:
            try:
                df = pd.read_csv(filepath)
                # Try to find datetime column
                for col in df.columns:
                    if 'date' in col.lower() or 'time' in col.lower():
                        try:
                            timestamps = pd.to_datetime(df[col])
                            file_latest = timestamps.max()
                            if latest is None or file_latest > latest:
                                latest = file_latest
                        except:
                            continue
            except:
                continue
        
        return latest
    
    def _print_summary(self):
        """Print validation summary"""
        print("\n📊 VALIDATION SUMMARY")
        print("-"*60)
        
        for sensor_type, result in self.results.items():
            if sensor_type == 'overall_healthy':
                continue
                
            status = "✅ HEALTHY" if result.get('healthy') else "❌ ISSUES"
            print(f"\n{result.get('type', sensor_type)}: {status}")
            print(f"  Files found: {result.get('files_found', 0)}")
            
            if 'days_old' in result:
                print(f"  Latest data: {result.get('days_old')} days old")
            
            if result.get('issues'):
                print("  Issues:")
                for issue in result['issues']:
                    print(f"    • {issue}")
        
        print("\n" + "="*60)
        if self.results.get('overall_healthy'):
            print("✅ ALL SYSTEMS HEALTHY - Ready for monitoring")
        else:
            print("⚠️  ISSUES DETECTED - Check sensor network")
    
    def export_report(self, output_dir: str = "reports/alerts") -> str:
        """Export validation report as JSON"""
        report_dir = Path(__file__).parent.parent / output_dir
        report_dir.mkdir(parents=True, exist_ok=True)
        
        filename = report_dir / f"sensor_validation_{self.site_name}_{datetime.now():%Y%m%d_%H%M%S}.json"
        
        report = {
            'site': self.site_name,
            'timestamp': datetime.now().isoformat(),
            'results': self.results
        }
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"\n📄 Report saved to: {filename}")
        return str(filename)


def main():
    parser = argparse.ArgumentParser(description="Validate sensor network health")
    parser.add_argument('--site', required=True, help='Site name to validate')
    parser.add_argument('--data-dir', default='data', help='Data directory')
    parser.add_argument('--export', action='store_true', help='Export report to JSON')
    
    args = parser.parse_args()
    
    validator = SensorValidator(args.site, args.data_dir)
    results = validator.validate_all()
    
    if args.export:
        validator.export_report()


if __name__ == "__main__":
    main()
