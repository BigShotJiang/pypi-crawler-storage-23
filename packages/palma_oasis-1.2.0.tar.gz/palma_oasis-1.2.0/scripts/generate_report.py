#!/usr/bin/env python3
"""
PALMA Report Generator
Generates daily, weekly, monthly, and alert reports in TXT and MD formats
"""

import os
import sys
import json
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import argparse
from typing import Dict, Any, List, Optional


class ReportGenerator:
    """Generate PALMA reports in TXT and MD formats"""
    
    def __init__(self, reports_dir: str = "reports"):
        """
        Initialize report generator
        
        Args:
            reports_dir: Base directory for reports (relative)
        """
        self.reports_dir = Path(__file__).parent.parent / reports_dir
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        self.daily_dir = self.reports_dir / "daily"
        self.weekly_dir = self.reports_dir / "weekly"
        self.monthly_dir = self.reports_dir / "monthly"
        self.alerts_dir = self.reports_dir / "alerts"
        
        for d in [self.daily_dir, self.weekly_dir, self.monthly_dir, self.alerts_dir]:
            d.mkdir(exist_ok=True)
    
    def generate_daily_report(self, site: str, date: str = None) -> str:
        """
        Generate daily report in TXT and MD formats
        
        Args:
            site: Site name
            date: Date in YYYY-MM-DD format (default: today)
            
        Returns:
            Path to generated report
        """
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        print(f"📊 Generating daily report for {site} on {date}")
        
        # Mock data - in real implementation, would fetch from database
        report_data = self._generate_mock_data(site, date)
        
        # Generate TXT report
        txt_content = self._format_txt(report_data)
        txt_filename = self.daily_dir / f"{site}_{date}.txt"
        with open(txt_filename, 'w') as f:
            f.write(txt_content)
        
        # Generate MD report
        md_content = self._format_md(report_data)
        md_filename = self.daily_dir / f"{site}_{date}.md"
        with open(md_filename, 'w') as f:
            f.write(md_content)
        
        # Also save JSON for compatibility
        json_filename = self.daily_dir / f"{site}_{date}.json"
        with open(json_filename, 'w') as f:
            json.dump(report_data, f, indent=2)
        
        print(f"✅ Reports saved:")
        print(f"   📄 TXT: {txt_filename}")
        print(f"   📝 MD:  {md_filename}")
        print(f"   📋 JSON: {json_filename}")
        
        return str(txt_filename)
    
    def generate_weekly_report(self, site: str, week_start: str = None) -> str:
        """Generate weekly report in TXT and MD formats"""
        if week_start is None:
            today = datetime.now()
            week_start = (today - timedelta(days=today.weekday())).strftime('%Y-%m-%d')
        
        week_end = (datetime.strptime(week_start, '%Y-%m-%d') + timedelta(days=6)).strftime('%Y-%m-%d')
        
        print(f"📊 Generating weekly report for {site}: {week_start} to {week_end}")
        
        # Generate mock data
        daily_values = [round(np.random.uniform(0.2, 0.8), 3) for _ in range(7)]
        
        report_data = {
            'report_type': 'weekly',
            'site': site,
            'week_start': week_start,
            'week_end': week_end,
            'generated_at': datetime.now().isoformat(),
            'summary': {
                'mean_ohi': round(np.mean(daily_values), 3),
                'min_ohi': min(daily_values),
                'max_ohi': max(daily_values),
                'trend': np.random.choice(['improving', 'stable', 'declining']),
                'status': np.random.choice(['EXCELLENT', 'GOOD', 'MODERATE', 'CRITICAL', 'COLLAPSE'])
            },
            'daily_ohi': {f"day_{i+1}": v for i, v in enumerate(daily_values)},
            'parameter_means': {
                'ARVC': round(np.random.uniform(0.1, 1.0), 3),
                'PTSI': round(np.random.uniform(0.1, 1.0), 3),
                'SSSP': round(np.random.uniform(0.1, 1.0), 3),
                'CMBF': round(np.random.uniform(0.1, 1.0), 3),
                'SVRI': round(np.random.uniform(0.1, 1.0), 3),
                'WEPR': round(np.random.uniform(0.1, 1.0), 3),
                'BST': round(np.random.uniform(0.1, 1.0), 3)
            },
            'alerts_this_week': np.random.randint(0, 5),
            'critical_events': np.random.randint(0, 2),
            'recommendations': [
                "Review weekly trends",
                "Schedule maintenance if needed",
                "Prepare monthly summary"
            ]
        }
        
        report_data['timestamp'] = datetime.now().isoformat()
        
        # Save TXT
        txt_filename = self.weekly_dir / f"{site}_{week_start}_to_{week_end}.txt"
        with open(txt_filename, 'w') as f:
            f.write(self._format_txt(report_data))
        
        # Save MD
        md_filename = self.weekly_dir / f"{site}_{week_start}_to_{week_end}.md"
        with open(md_filename, 'w') as f:
            f.write(self._format_md(report_data))
        
        # Save JSON
        json_filename = self.weekly_dir / f"{site}_{week_start}_to_{week_end}.json"
        with open(json_filename, 'w') as f:
            json.dump(report_data, f, indent=2)
        
        print(f"✅ Weekly reports saved")
        return str(txt_filename)
    
    def generate_monthly_report(self, site: str, month: str = None) -> str:
        """Generate monthly report in TXT and MD formats"""
        if month is None:
            month = datetime.now().strftime('%Y-%m')
        
        print(f"📊 Generating monthly report for {site}: {month}")
        
        report_data = {
            'report_type': 'monthly',
            'site': site,
            'month': month,
            'generated_at': datetime.now().isoformat(),
            'summary': {
                'mean_ohi': round(np.random.uniform(0.3, 0.7), 3),
                'ohi_trend': round(np.random.uniform(-0.1, 0.1), 3),
                'status': np.random.choice(['EXCELLENT', 'GOOD', 'MODERATE', 'CRITICAL', 'COLLAPSE']),
                'days_in_month': 30
            },
            'parameter_trends': {
                'ARVC': round(np.random.uniform(-0.05, 0.05), 3),
                'PTSI': round(np.random.uniform(-0.05, 0.05), 3),
                'SSSP': round(np.random.uniform(-0.02, 0.08), 3),
                'CMBF': round(np.random.uniform(-0.05, 0.05), 3),
                'SVRI': round(np.random.uniform(-0.05, 0.03), 3),
                'WEPR': round(np.random.uniform(-0.03, 0.03), 3),
                'BST': round(np.random.uniform(-0.02, 0.04), 3)
            },
            'alerts_summary': {
                'total_alerts': np.random.randint(0, 10),
                'critical_alerts': np.random.randint(0, 3),
                'moderate_alerts': np.random.randint(0, 5)
            },
            'recommendations': [
                "Continue current management practices",
                "Monitor salinity trends",
                "Prepare for seasonal changes"
            ]
        }
        
        report_data['timestamp'] = datetime.now().isoformat()
        
        # Save TXT
        txt_filename = self.monthly_dir / f"{site}_{month}.txt"
        with open(txt_filename, 'w') as f:
            f.write(self._format_txt(report_data))
        
        # Save MD
        md_filename = self.monthly_dir / f"{site}_{month}.md"
        with open(md_filename, 'w') as f:
            f.write(self._format_md(report_data))
        
        # Save JSON
        json_filename = self.monthly_dir / f"{site}_{month}.json"
        with open(json_filename, 'w') as f:
            json.dump(report_data, f, indent=2)
        
        print(f"✅ Monthly reports saved")
        return str(txt_filename)
    
    def _generate_mock_data(self, site: str, date: str) -> Dict[str, Any]:
        """Generate mock report data"""
        return {
            'report_type': 'daily',
            'site': site,
            'date': date,
            'generated_at': datetime.now().isoformat(),
            'summary': {
                'ohi_value': round(np.random.uniform(0.2, 0.8), 3),
                'status': np.random.choice(['EXCELLENT', 'GOOD', 'MODERATE', 'CRITICAL', 'COLLAPSE']),
                'lead_time_days': round(np.random.uniform(10, 90), 1)
            },
            'parameters': {
                'ARVC': round(np.random.uniform(0.1, 1.0), 3),
                'PTSI': round(np.random.uniform(0.1, 1.0), 3),
                'SSSP': round(np.random.uniform(0.1, 1.0), 3),
                'CMBF': round(np.random.uniform(0.1, 1.0), 3),
                'SVRI': round(np.random.uniform(0.1, 1.0), 3),
                'WEPR': round(np.random.uniform(0.1, 1.0), 3),
                'BST': round(np.random.uniform(0.1, 1.0), 3)
            },
            'alerts': {
                'active': np.random.randint(0, 3),
                'critical': np.random.randint(0, 2),
                'moderate': np.random.randint(0, 2)
            },
            'weather': {
                'temperature_c': round(np.random.uniform(25, 45), 1),
                'humidity_pct': round(np.random.uniform(10, 60), 1),
                'wind_speed_ms': round(np.random.uniform(0, 10), 1),
                'precipitation_mm': round(np.random.uniform(0, 5), 1)
            },
            'recommendations': [
                "Continue standard monitoring",
                "Check irrigation schedules",
                "Review parameter trends"
            ]
        }
    
    def _format_txt(self, data: Dict[str, Any]) -> str:
        """Format report as plain text"""
        lines = []
        lines.append("="*60)
        lines.append(f"PALMA {data.get('report_type', 'REPORT').upper()}")
        lines.append("="*60)
        lines.append("")
        lines.append(f"Site: {data.get('site', 'Unknown')}")
        lines.append(f"Date: {data.get('date', data.get('month', 'Unknown'))}")
        lines.append(f"Generated: {data.get('generated_at', data.get('timestamp', 'Unknown'))}")
        lines.append("")
        
        if 'summary' in data:
            lines.append("SUMMARY:")
            for key, value in data['summary'].items():
                lines.append(f"  {key}: {value}")
            lines.append("")
        
        if 'parameters' in data:
            lines.append("PARAMETERS:")
            for key, value in data['parameters'].items():
                lines.append(f"  {key}: {value}")
            lines.append("")
        
        if 'parameter_means' in data:
            lines.append("PARAMETER MEANS:")
            for key, value in data['parameter_means'].items():
                lines.append(f"  {key}: {value}")
            lines.append("")
        
        if 'weather' in data:
            lines.append("WEATHER:")
            for key, value in data['weather'].items():
                lines.append(f"  {key}: {value}")
            lines.append("")
        
        if 'alerts' in data:
            lines.append("ALERTS:")
            for key, value in data['alerts'].items():
                lines.append(f"  {key}: {value}")
            lines.append("")
        
        if 'recommendations' in data:
            lines.append("RECOMMENDATIONS:")
            for rec in data['recommendations']:
                lines.append(f"  • {rec}")
            lines.append("")
        
        lines.append("="*60)
        return "\n".join(lines)
    
    def _format_md(self, data: Dict[str, Any]) -> str:
        """Format report as Markdown"""
        lines = []
        lines.append(f"# PALMA {data.get('report_type', 'REPORT').upper()}")
        lines.append("")
        lines.append(f"**Site:** {data.get('site', 'Unknown')}")
        lines.append(f"**Date:** {data.get('date', data.get('month', 'Unknown'))}")
        lines.append(f"**Generated:** {data.get('generated_at', data.get('timestamp', 'Unknown'))}")
        lines.append("")
        
        if 'summary' in data:
            lines.append("## Summary")
            for key, value in data['summary'].items():
                lines.append(f"- **{key}:** {value}")
            lines.append("")
        
        if 'parameters' in data:
            lines.append("## Parameters")
            lines.append("| Parameter | Value |")
            lines.append("|-----------|-------|")
            for key, value in data['parameters'].items():
                lines.append(f"| {key} | {value} |")
            lines.append("")
        
        if 'parameter_means' in data:
            lines.append("## Parameter Means")
            lines.append("| Parameter | Value |")
            lines.append("|-----------|-------|")
            for key, value in data['parameter_means'].items():
                lines.append(f"| {key} | {value} |")
            lines.append("")
        
        if 'weather' in data:
            lines.append("## Weather")
            lines.append("| Metric | Value |")
            lines.append("|--------|-------|")
            for key, value in data['weather'].items():
                lines.append(f"| {key} | {value} |")
            lines.append("")
        
        if 'alerts' in data:
            lines.append("## Alerts")
            for key, value in data['alerts'].items():
                lines.append(f"- **{key}:** {value}")
            lines.append("")
        
        if 'recommendations' in data:
            lines.append("## Recommendations")
            for rec in data['recommendations']:
                lines.append(f"- {rec}")
            lines.append("")
        
        lines.append("---")
        lines.append(f"*Report generated by PALMA v1.0.0*")
        
        return "\n".join(lines)
    
    def list_reports(self, report_type: str = None) -> List[Path]:
        """List available reports"""
        if report_type == 'daily':
            reports = list(self.daily_dir.glob("*.txt")) + list(self.daily_dir.glob("*.md"))
        elif report_type == 'weekly':
            reports = list(self.weekly_dir.glob("*.txt")) + list(self.weekly_dir.glob("*.md"))
        elif report_type == 'monthly':
            reports = list(self.monthly_dir.glob("*.txt")) + list(self.monthly_dir.glob("*.md"))
        elif report_type == 'alerts':
            reports = list(self.alerts_dir.glob("*.txt")) + list(self.alerts_dir.glob("*.md"))
        else:
            reports = (list(self.daily_dir.glob("*.txt")) + list(self.daily_dir.glob("*.md")) +
                      list(self.weekly_dir.glob("*.txt")) + list(self.weekly_dir.glob("*.md")) +
                      list(self.monthly_dir.glob("*.txt")) + list(self.monthly_dir.glob("*.md")) +
                      list(self.alerts_dir.glob("*.txt")) + list(self.alerts_dir.glob("*.md")))
        
        return sorted(reports, reverse=True)


def main():
    parser = argparse.ArgumentParser(description="Generate PALMA reports in TXT and MD formats")
    parser.add_argument('--site', required=True, help='Site name')
    parser.add_argument('--type', choices=['daily', 'weekly', 'monthly'], 
                       default='daily', help='Report type')
    parser.add_argument('--date', help='Date (YYYY-MM-DD for daily, YYYY-MM for monthly)')
    parser.add_argument('--list', action='store_true', help='List available reports')
    
    args = parser.parse_args()
    
    generator = ReportGenerator()
    
    if args.list:
        reports = generator.list_reports(args.type)
        print(f"\n📋 Available {args.type} reports:")
        for report in reports[:20]:
            print(f"  • {report.name}")
        return
    
    if args.type == 'daily':
        generator.generate_daily_report(args.site, args.date)
    elif args.type == 'weekly':
        generator.generate_weekly_report(args.site, args.date)
    elif args.type == 'monthly':
        generator.generate_monthly_report(args.site, args.date)


if __name__ == "__main__":
    main()
