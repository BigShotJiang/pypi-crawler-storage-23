#!/usr/bin/env python3
"""
Bulk Import Tool for Historical Data
Imports large datasets into PALMA database
"""

import os
import sys
import json
import csv
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import argparse
from typing import Dict, Any, List, Optional


class BulkImporter:
    """Bulk import historical data"""
    
    def __init__(self, data_dir: str = "data", db_url: Optional[str] = None):
        """
        Initialize bulk importer
        
        Args:
            data_dir: Data directory (relative)
            db_url: Database connection URL (optional)
        """
        self.data_dir = Path(__file__).parent.parent / data_dir
        self.db_url = db_url
        self.stats = {
            'files_processed': 0,
            'records_imported': 0,
            'errors': 0,
            'skipped': 0
        }
        
    def import_piezometer_data(self, filepath: Path, site: str) -> Dict[str, Any]:
        """Import piezometer data from CSV"""
        result = {
            'file': str(filepath),
            'site': site,
            'records': 0,
            'errors': []
        }
        
        try:
            df = pd.read_csv(filepath)
            
            # Standardize columns
            df.columns = [c.lower().strip() for c in df.columns]
            
            # Check for required columns
            required = ['datetime', 'water_level']
            found = [c for c in required if any(r in c for r in df.columns)]
            
            if not found:
                result['errors'].append("Missing required columns")
                return result
            
            # Parse datetime
            if 'datetime' in df.columns:
                df['datetime'] = pd.to_datetime(df['datetime'])
            else:
                # Try to find date/time columns
                date_col = next((c for c in df.columns if 'date' in c), None)
                time_col = next((c for c in df.columns if 'time' in c), None)
                
                if date_col and time_col:
                    df['datetime'] = pd.to_datetime(df[date_col] + ' ' + df[time_col])
                elif date_col:
                    df['datetime'] = pd.to_datetime(df[date_col])
            
            # Find water level column
            level_col = next((c for c in df.columns if 'level' in c or 'head' in c), None)
            if level_col:
                df.rename(columns={level_col: 'water_level'}, inplace=True)
            
            # Remove duplicates
            if 'datetime' in df.columns:
                df = df.drop_duplicates(subset=['datetime'])
            
            result['records'] = len(df)
            self.stats['records_imported'] += len(df)
            
            # Save processed file
            output_dir = self.data_dir / site / "processed"
            output_dir.mkdir(parents=True, exist_ok=True)
            output_file = output_dir / f"piezometer_{datetime.now():%Y%m%d_%H%M%S}.csv"
            df.to_csv(output_file, index=False)
            
        except Exception as e:
            result['errors'].append(str(e))
            self.stats['errors'] += 1
        
        return result
    
    def import_soil_ec_data(self, filepath: Path, site: str) -> Dict[str, Any]:
        """Import soil EC data from CSV"""
        result = {
            'file': str(filepath),
            'site': site,
            'records': 0,
            'errors': []
        }
        
        try:
            df = pd.read_csv(filepath)
            
            # Standardize columns
            df.columns = [c.lower().strip() for c in df.columns]
            
            # Check for required columns
            required = ['ec', 'depth']
            found = [c for c in required if any(r in c for r in df.columns)]
            
            if not found:
                result['errors'].append("Missing required columns")
                return result
            
            # Parse datetime if present
            if 'datetime' in df.columns:
                df['datetime'] = pd.to_datetime(df['datetime'])
            
            result['records'] = len(df)
            self.stats['records_imported'] += len(df)
            
            # Save processed file
            output_dir = self.data_dir / site / "processed"
            output_dir.mkdir(parents=True, exist_ok=True)
            output_file = output_dir / f"soil_ec_{datetime.now():%Y%m%d_%H%M%S}.csv"
            df.to_csv(output_file, index=False)
            
        except Exception as e:
            result['errors'].append(str(e))
            self.stats['errors'] += 1
        
        return result
    
    def import_weather_data(self, filepath: Path, site: str) -> Dict[str, Any]:
        """Import weather data from CSV"""
        result = {
            'file': str(filepath),
            'site': site,
            'records': 0,
            'errors': []
        }
        
        try:
            df = pd.read_csv(filepath)
            
            # Standardize columns
            df.columns = [c.lower().strip() for c in df.columns]
            
            # Parse datetime
            if 'datetime' in df.columns:
                df['datetime'] = pd.to_datetime(df['datetime'])
            elif 'date' in df.columns:
                df['datetime'] = pd.to_datetime(df['date'])
            
            result['records'] = len(df)
            self.stats['records_imported'] += len(df)
            
            # Save processed file
            output_dir = self.data_dir / site / "processed"
            output_dir.mkdir(parents=True, exist_ok=True)
            output_file = output_dir / f"weather_{datetime.now():%Y%m%d_%H%M%S}.csv"
            df.to_csv(output_file, index=False)
            
        except Exception as e:
            result['errors'].append(str(e))
            self.stats['errors'] += 1
        
        return result
    
    def import_directory(self, directory: Path, site: str) -> List[Dict[str, Any]]:
        """Import all supported files from directory"""
        results = []
        
        for filepath in directory.glob("*.*"):
            if filepath.suffix.lower() not in ['.csv', '.txt', '.xlsx']:
                continue
            
            print(f"Processing: {filepath.name}")
            
            # Detect file type from name
            name_lower = filepath.name.lower()
            
            if 'piezometer' in name_lower or 'water' in name_lower or 'level' in name_lower:
                result = self.import_piezometer_data(filepath, site)
            elif 'ec' in name_lower or 'salinity' in name_lower or 'conductivity' in name_lower:
                result = self.import_soil_ec_data(filepath, site)
            elif 'weather' in name_lower or 'climate' in name_lower or 'met' in name_lower:
                result = self.import_weather_data(filepath, site)
            else:
                # Skip unknown file types
                self.stats['skipped'] += 1
                continue
            
            results.append(result)
            self.stats['files_processed'] += 1
            
            if result['errors']:
                print(f"  ⚠️  Errors: {result['errors']}")
            else:
                print(f"  ✅ Imported {result['records']} records")
        
        return results
    
    def print_summary(self):
        """Print import summary"""
        print("\n" + "="*60)
        print("IMPORT SUMMARY")
        print("="*60)
        print(f"Files processed: {self.stats['files_processed']}")
        print(f"Records imported: {self.stats['records_imported']}")
        print(f"Errors: {self.stats['errors']}")
        print(f"Skipped: {self.stats['skipped']}")
        print("="*60)


def main():
    parser = argparse.ArgumentParser(description="Bulk import historical data")
    parser.add_argument('--site', required=True, help='Site name')
    parser.add_argument('--input-dir', required=True, help='Input directory with data files')
    parser.add_argument('--data-dir', default='data', help='PALMA data directory')
    
    args = parser.parse_args()
    
    input_dir = Path(args.input_dir)
    if not input_dir.exists():
        print(f"❌ Input directory not found: {input_dir}")
        sys.exit(1)
    
    importer = BulkImporter(data_dir=args.data_dir)
    
    print(f"\n📦 Bulk importing data for site: {args.site}")
    print(f"From: {input_dir}")
    print("-"*60)
    
    results = importer.import_directory(input_dir, args.site)
    
    importer.print_summary()


if __name__ == "__main__":
    main()
