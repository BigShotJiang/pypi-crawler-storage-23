#!/usr/bin/env python3
"""
OHI Accuracy Benchmark Runner
Runs benchmarks to validate OHI prediction accuracy
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
import argparse
from typing import Dict, Any, List, Tuple


class OHIBenchmark:
    """Benchmark OHI prediction accuracy"""
    
    def __init__(self, results_dir: str = "reports/benchmarks"):
        """
        Initialize benchmark
        
        Args:
            results_dir: Directory for benchmark results
        """
        self.results_dir = Path(__file__).parent.parent / results_dir
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Expected metrics from paper
        self.target_metrics = {
            'accuracy': 0.931,  # 93.1%
            'rmse': 0.098,       # 9.8%
            'detection_rate': 0.972,  # 97.2%
            'false_alert_rate': 0.028,  # 2.8%
            'mean_lead_time': 52  # days
        }
        
    def run_benchmark(self, n_iterations: int = 1000) -> Dict[str, Any]:
        """
        Run OHI accuracy benchmark
        
        Args:
            n_iterations: Number of Monte Carlo iterations
            
        Returns:
            Benchmark results
        """
        print(f"\n🏃 Running OHI benchmark ({n_iterations} iterations)")
        print("="*60)
        
        # Simulate predictions vs observations
        predictions = []
        observations = []
        lead_times = []
        
        for i in range(n_iterations):
            # Simulate OHI values (0-1)
            true_ohi = np.random.beta(2, 2)  # Beta distribution
            
            # Add noise to simulate prediction error
            noise = np.random.normal(0, 0.05)
            pred_ohi = np.clip(true_ohi + noise, 0, 1)
            
            predictions.append(pred_ohi)
            observations.append(true_ohi)
            
            # Simulate lead time (days)
            if true_ohi > 0.65:  # Critical events
                lead = np.random.exponential(30)
                lead_times.append(min(lead, 118))  # Cap at max 118 days
        
        # Calculate metrics
        metrics = self._calculate_metrics(
            np.array(observations),
            np.array(predictions),
            np.array(lead_times)
        )
        
        # Compare with targets
        comparison = self._compare_with_targets(metrics)
        
        # Save results
        results = {
            'timestamp': datetime.now().isoformat(),
            'n_iterations': n_iterations,
            'metrics': metrics,
            'comparison': comparison,
            'target_metrics': self.target_metrics
        }
        
        self._save_results(results)
        self._print_results(results)
        
        return results
    
    def _calculate_metrics(self, observed: np.ndarray, 
                          predicted: np.ndarray,
                          lead_times: np.ndarray) -> Dict[str, float]:
        """Calculate benchmark metrics"""
        
        # RMSE
        rmse = np.sqrt(np.mean((observed - predicted) ** 2))
        
        # MAE
        mae = np.mean(np.abs(observed - predicted))
        
        # R²
        ss_res = np.sum((observed - predicted) ** 2)
        ss_tot = np.sum((observed - np.mean(observed)) ** 2)
        r2 = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
        
        # Classification metrics (threshold = 0.65)
        threshold = 0.65
        obs_stress = observed > threshold
        pred_stress = predicted > threshold
        
        tp = np.sum(pred_stress & obs_stress)
        tn = np.sum(~pred_stress & ~obs_stress)
        fp = np.sum(pred_stress & ~obs_stress)
        fn = np.sum(~pred_stress & obs_stress)
        
        detection_rate = tp / (tp + fn) if (tp + fn) > 0 else 0
        false_alert_rate = fp / (fp + tn) if (fp + tn) > 0 else 0
        accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
        
        # Lead time metrics
        if len(lead_times) > 0:
            mean_lead = np.mean(lead_times)
            max_lead = np.max(lead_times)
            min_lead = np.min(lead_times)
        else:
            mean_lead = max_lead = min_lead = 0
        
        return {
            'rmse': float(rmse),
            'mae': float(mae),
            'r2': float(r2),
            'accuracy': float(accuracy),
            'detection_rate': float(detection_rate),
            'false_alert_rate': float(false_alert_rate),
            'mean_lead_time': float(mean_lead),
            'max_lead_time': float(max_lead),
            'min_lead_time': float(min_lead),
            'confusion_matrix': {
                'tp': int(tp), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn)
            }
        }
    
    def _compare_with_targets(self, metrics: Dict[str, float]) -> Dict[str, Any]:
        """Compare metrics with target values"""
        comparison = {}
        
        for metric, target in self.target_metrics.items():
            if metric in metrics:
                achieved = metrics[metric]
                diff = achieved - target
                pct_diff = (diff / target) * 100 if target != 0 else 0
                
                comparison[metric] = {
                    'target': target,
                    'achieved': achieved,
                    'difference': diff,
                    'percent_difference': pct_diff,
                    'meets_target': abs(diff) < 0.01 if metric == 'rmse' else achieved >= target
                }
        
        return comparison
    
    def _save_results(self, results: Dict[str, Any]):
        """Save benchmark results"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = self.results_dir / f"benchmark_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n📄 Results saved to: {filename}")
    
    def _print_results(self, results: Dict[str, Any]):
        """Print benchmark results"""
        metrics = results['metrics']
        comparison = results['comparison']
        
        print("\n" + "="*60)
        print("BENCHMARK RESULTS")
        print("="*60)
        print(f"Iterations: {results['n_iterations']}")
        print()
        
        print("REGRESSION METRICS:")
        print(f"  RMSE: {metrics['rmse']:.4f} (target: {self.target_metrics['rmse']:.4f})")
        print(f"   MAE: {metrics['mae']:.4f}")
        print(f"    R²: {metrics['r2']:.4f}")
        print()
        
        print("CLASSIFICATION METRICS:")
        print(f"  Accuracy: {metrics['accuracy']:.2%} (target: {self.target_metrics['accuracy']:.2%})")
        print(f"  Detection Rate: {metrics['detection_rate']:.2%} (target: {self.target_metrics['detection_rate']:.2%})")
        print(f"  False Alert Rate: {metrics['false_alert_rate']:.2%} (target: {self.target_metrics['false_alert_rate']:.2%})")
        print()
        
        print("CONFUSION MATRIX:")
        cm = metrics['confusion_matrix']
        print(f"  TP: {cm['tp']:5d}  FP: {cm['fp']:5d}")
        print(f"  FN: {cm['fn']:5d}  TN: {cm['tn']:5d}")
        print()
        
        print("LEAD TIME (days):")
        print(f"  Mean: {metrics['mean_lead_time']:.1f} (target: {self.target_metrics['mean_lead_time']})")
        print(f"  Max:  {metrics['max_lead_time']:.1f}")
        print(f"  Min:  {metrics['min_lead_time']:.1f}")
        print()
        
        print("TARGET COMPARISON:")
        for metric, comp in comparison.items():
            status = "✅" if comp['meets_target'] else "❌"
            print(f"  {status} {metric}: {comp['achieved']:.3f} vs {comp['target']:.3f} "
                  f"({comp['percent_difference']:+.1f}%)")
        
        print("="*60)
    
    def list_benchmarks(self) -> List[Path]:
        """List previous benchmark results"""
        benchmarks = list(self.results_dir.glob("benchmark_*.json"))
        return sorted(benchmarks, reverse=True)
    
    def compare_benchmarks(self, benchmark_files: List[Path]) -> pd.DataFrame:
        """Compare multiple benchmark runs"""
        results = []
        
        for filepath in benchmark_files:
            with open(filepath, 'r') as f:
                data = json.load(f)
            
            results.append({
                'timestamp': data['timestamp'],
                'iterations': data['n_iterations'],
                'accuracy': data['metrics']['accuracy'],
                'detection_rate': data['metrics']['detection_rate'],
                'false_alert_rate': data['metrics']['false_alert_rate'],
                'rmse': data['metrics']['rmse'],
                'mean_lead': data['metrics']['mean_lead_time']
            })
        
        return pd.DataFrame(results)


def main():
    parser = argparse.ArgumentParser(description="Run OHI accuracy benchmark")
    parser.add_argument('--iterations', type=int, default=1000,
                       help='Number of Monte Carlo iterations')
    parser.add_argument('--list', action='store_true',
                       help='List previous benchmarks')
    parser.add_argument('--compare', nargs='+',
                       help='Compare benchmark files')
    
    args = parser.parse_args()
    
    benchmark = OHIBenchmark()
    
    if args.list:
        benchmarks = benchmark.list_benchmarks()
        print("\n📋 Previous benchmarks:")
        for b in benchmarks[:10]:
            print(f"  • {b.name}")
    
    elif args.compare:
        files = [Path(f) for f in args.compare]
        df = benchmark.compare_benchmarks(files)
        print("\n📊 Benchmark Comparison:")
        print(df.to_string(index=False))
    
    else:
        benchmark.run_benchmark(args.iterations)


if __name__ == "__main__":
    main()
