#!/usr/bin/env python3
"""
PALMA Site Setup Wizard
Creates configuration for a new monitoring site
"""

import os
import sys
import json
import yaml
from pathlib import Path
from datetime import datetime
import argparse
from typing import Dict, Any


class SiteSetupWizard:
    """Interactive wizard for setting up a new monitoring site"""
    
    def __init__(self, sites_dir: str = "config/sites"):
        """
        Initialize site setup wizard
        
        Args:
            sites_dir: Directory for site configurations (relative)
        """
        self.sites_dir = Path(__file__).parent.parent / sites_dir
        self.sites_dir.mkdir(parents=True, exist_ok=True)
        
    def run(self, interactive: bool = True):
        """
        Run the setup wizard
        
        Args:
            interactive: If True, prompt for input; otherwise use defaults
        """
        print("\n" + "="*60)
        print("🌴 PALMA SITE SETUP WIZARD")
        print("="*60)
        
        if interactive:
            site_config = self._interactive_setup()
        else:
            site_config = self._default_setup()
        
        # Save configuration
        filename = self.sites_dir / f"{site_config['name']}.yaml"
        with open(filename, 'w') as f:
            yaml.dump(site_config, f, default_flow_style=False)
        
        print(f"\n✅ Site configuration saved to: {filename}")
        print("\nNext steps:")
        print("  1. Place sensor data in data/ directory")
        print("  2. Run validation: python scripts/validate_sensors.py --site {}".format(site_config['name']))
        print("  3. Start monitoring: python -m palma monitor --site {}".format(site_config['name']))
        
        return site_config
    
    def _interactive_setup(self) -> Dict[str, Any]:
        """Interactive setup with user prompts"""
        config = {}
        
        # Basic information
        print("\n📋 SITE INFORMATION")
        config['name'] = input("Site name (e.g., draa_valley): ").strip()
        config['display_name'] = input("Display name (e.g., Draa Valley): ").strip()
        config['country'] = input("Country: ").strip()
        
        # Coordinates
        print("\n📍 LOCATION")
        try:
            config['latitude'] = float(input("Latitude (decimal degrees): "))
            config['longitude'] = float(input("Longitude (decimal degrees): "))
        except ValueError:
            print("Invalid coordinates, using defaults")
            config['latitude'] = 0.0
            config['longitude'] = 0.0
        
        config['elevation_m'] = float(input("Elevation (meters): ") or "500")
        config['area_ha'] = float(input("Area (hectares): ") or "100")
        
        # Site type
        print("\n🏜️ SITE TYPE")
        print("Types: artesian, wadi, aquifer, fog, agricultural")
        config['type'] = input("Site type: ").strip().lower()
        
        # Monitoring tier
        print("\n📊 MONITORING TIER")
        print("Tier 1: Full sensor network (≥20 sensors)")
        print("Tier 2: Standard monitoring (10-19 sensors)")
        print("Tier 3: Satellite + surveys (5-9 sensors)")
        config['tier'] = int(input("Tier (1-3): ") or "2")
        
        # Sensor configuration
        print("\n🔌 SENSOR CONFIGURATION")
        config['sensors'] = {}
        
        # Piezometers
        n_piezo = int(input("Number of piezometers: ") or "5")
        config['sensors']['piezometers'] = {
            'count': n_piezo,
            'depths': [15, 30, 60, 90][:min(4, n_piezo)]
        }
        
        # Soil EC sensors
        n_ec = int(input("Number of soil EC sensors: ") or "8")
        config['sensors']['soil_ec'] = {
            'count': n_ec,
            'depths': [15, 30, 60, 90]
        }
        
        # Thermocouples
        n_thermo = int(input("Number of thermocouples: ") or "4")
        config['sensors']['thermocouples'] = {
            'count': n_thermo,
            'heights': [0.5, 1.5, 3.0, 4.5, 6.0][:n_thermo]
        }
        
        # Parameter configuration
        print("\n⚙️ PARAMETER CONFIGURATION")
        config['parameters'] = {
            'arvc': {
                'alpha': 0.68,
                'k_sat_mean': float(input("Mean hydraulic conductivity (m/d): ") or "12.4")
            },
            'sssp': {
                'ec_critical': 8.4,
                'ec_baseline': float(input("Baseline soil EC (dS/m): ") or "1.2")
            },
            'ptsi': {
                'k_extinction': 0.52,
                'leaf_area_index': float(input("Mean LAI: ") or "4.8")
            }
        }
        
        # Monitoring period
        print("\n📅 MONITORING PERIOD")
        config['start_date'] = input("Start date (YYYY-MM-DD): ") or "2026-01-01"
        config['end_date'] = input("End date (YYYY-MM-DD): ") or "2026-12-31"
        
        # Metadata
        config['setup_date'] = datetime.now().isoformat()
        config['setup_by'] = input("Your name/email: ") or "unknown"
        
        return config
    
    def _default_setup(self) -> Dict[str, Any]:
        """Create default configuration for testing"""
        return {
            'name': 'test_site',
            'display_name': 'Test Oasis',
            'country': 'Testland',
            'latitude': 30.0,
            'longitude': -5.0,
            'elevation_m': 500,
            'area_ha': 100,
            'type': 'artesian',
            'tier': 2,
            'sensors': {
                'piezometers': {'count': 5, 'depths': [15, 30, 60, 90]},
                'soil_ec': {'count': 8, 'depths': [15, 30, 60, 90]},
                'thermocouples': {'count': 4, 'heights': [0.5, 1.5, 3.0, 4.5]}
            },
            'parameters': {
                'arvc': {'alpha': 0.68, 'k_sat_mean': 12.4},
                'sssp': {'ec_critical': 8.4, 'ec_baseline': 1.2},
                'ptsi': {'k_extinction': 0.52, 'leaf_area_index': 4.8}
            },
            'start_date': '2026-01-01',
            'end_date': '2026-12-31',
            'setup_date': datetime.now().isoformat(),
            'setup_by': 'auto'
        }
    
    def list_sites(self) -> None:
        """List all configured sites"""
        sites = list(self.sites_dir.glob("*.yaml"))
        
        if not sites:
            print("No sites configured yet.")
            return
        
        print("\n📋 CONFIGURED SITES:")
        for site_file in sites:
            with open(site_file, 'r') as f:
                config = yaml.safe_load(f)
                print(f"  • {config.get('display_name', site_file.stem)}")
                print(f"    File: {site_file.name}")
                print(f"    Type: {config.get('type', 'unknown')}")
                print(f"    Tier: {config.get('tier', 'unknown')}")
                print()


def main():
    parser = argparse.ArgumentParser(description="PALMA Site Setup Wizard")
    parser.add_argument('--non-interactive', action='store_true',
                       help='Run with default values (for testing)')
    parser.add_argument('--list', action='store_true',
                       help='List existing sites')
    parser.add_argument('--sites-dir', default='config/sites',
                       help='Sites configuration directory')
    
    args = parser.parse_args()
    
    wizard = SiteSetupWizard(sites_dir=args.sites_dir)
    
    if args.list:
        wizard.list_sites()
    else:
        wizard.run(interactive=not args.non_interactive)


if __name__ == "__main__":
    main()
