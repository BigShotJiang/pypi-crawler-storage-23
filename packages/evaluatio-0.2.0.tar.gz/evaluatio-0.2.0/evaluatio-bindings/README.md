# evaluatio-bindings

This component contains the PyO3 bindings for [evaluatio-core](../evaluatio-core/README.md).
The bindings are exported to a single module located at `evaluatio._bindings`.
These bindings are used/wrapped by functions in the main [Python package](../python-src/).
