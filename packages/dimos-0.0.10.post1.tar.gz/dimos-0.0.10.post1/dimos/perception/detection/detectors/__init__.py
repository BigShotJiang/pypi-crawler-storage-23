# from dimos.perception.detection.detectors.detic import Detic2DDetector
from dimos.perception.detection.detectors.types import Detector
from dimos.perception.detection.detectors.yolo import Yolo2DDetector

__all__ = [
    "Detector",
    "Yolo2DDetector",
]
