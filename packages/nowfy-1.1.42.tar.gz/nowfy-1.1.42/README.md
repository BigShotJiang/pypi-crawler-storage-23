﻿# Nowfy

Single PyPI package containing Nowfy plugin runtime and internal core.
