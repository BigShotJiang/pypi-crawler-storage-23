"""Pydantic models for System API responses."""

from pydantic import BaseModel


class SystemHealth(BaseModel):
    """Response model for system health check.

    Represents the health status of the API and its dependencies including
    database and cache connectivity.
    """

    database_status: str
    cache_status: str
    version: str
