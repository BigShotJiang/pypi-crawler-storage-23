"""Appeal report generation (Markdown and PDF with randomized styling)."""

from __future__ import annotations

from typing import Optional

import logging
from datetime import date, datetime
from importlib.resources import files as pkg_files
from pathlib import Path

from jinja2 import Template

from appeal.config import SF_ASSESSOR_PORTAL_URL
from appeal.models import AppealReport, ValuationResult

logger = logging.getLogger(__name__)

# ── Markdown template (kept for --format md) ──

REPORT_TEMPLATE = """\
# Proposition 8 Decline-in-Value Appeal Report

**Generated:** {{ report.generated_at.strftime('%B %d, %Y') }}
**Filing Deadline:** {{ report.filing_deadline.strftime('%B %d, %Y') }} ({{ report.filing_type }})

---

## Subject Property

| Field | Value |
|-------|-------|
| Address | {{ v.subject.address }} |
| Parcel Number | {{ v.subject.parcel_number }} (Block {{ v.subject.block }}, Lot {{ v.subject.lot }}) |
| Property Type | {{ v.subject.use_definition or v.subject.use_code }} |
| Bedrooms | {{ v.subject.bedrooms }} |
| Bathrooms | {{ v.subject.bathrooms }} |
| Living Area | {{ "{:,.0f}".format(v.subject.property_area) }} sqft |
| Lot Area | {{ "{:,.0f}".format(v.subject.lot_area) }} sqft |
| Year Built | {{ v.subject.year_built }} |
| Neighborhood | {{ v.subject.assessor_neighborhood or v.subject.analysis_neighborhood }} |

### Current Assessment (Roll Year {{ v.subject.roll_year }})

| Component | Value |
|-----------|-------|
| Land | ${{ "{:,.0f}".format(v.subject.assessed_land_value) }} |
| Improvements | ${{ "{:,.0f}".format(v.subject.assessed_improvement_value) }} |
| **Total Assessed Value** | **${{ "{:,.0f}".format(v.assessed_value) }}** |
| Assessed $/sqft | ${{ "{:,.0f}".format(v.subject.assessed_price_per_sqft) if v.subject.assessed_price_per_sqft else "N/A" }} |

---

## Written Rationale

{{ v.rationale_summary }}

---

## Comparable Sales Analysis

{% for comp in v.selected_comps %}
### Comp {{ loop.index }}: {{ comp.address }}

| Field | Value |
|-------|-------|
| Sale Price | ${{ "{:,.0f}".format(comp.sale_price) }} |
| Sale Date | {{ comp.sale_date.strftime('%B %d, %Y') if comp.sale_date else "N/A" }} |
| Bedrooms / Bathrooms | {{ comp.bedrooms }} / {{ comp.bathrooms }} |
| Living Area | {{ "{:,.0f}".format(comp.property_area) }} sqft |
{% if comp.lot_area %}| Lot Area | {{ "{:,.0f}".format(comp.lot_area) }} sqft |
{% endif %}{% if comp.distance_miles is not none %}| Distance from Subject | {{ "{:.2f}".format(comp.distance_miles) }} miles |
{% endif %}| Raw $/sqft | ${{ "{:,.0f}".format(comp.raw_price_per_sqft) if comp.raw_price_per_sqft else "N/A" }} |
| **Adjusted $/sqft** | **${{ "{:,.0f}".format(comp.adjusted_price_per_sqft) if comp.adjusted_price_per_sqft else "N/A" }}** |
| Data Source | {{ comp.source }} |

{% if comp.adjustments %}**Adjustments Applied:**
{% for adj in comp.adjustments %}
- {{ adj.description }}: {{ "{:+.0f}".format(adj.amount_per_sqft) }} $/sqft
{% endfor %}
{% else %}No adjustments applied.
{% endif %}
{% endfor %}

---

## Valuation Summary

| Metric | Value |
|--------|-------|
| Median Adjusted $/sqft | ${{ "{:,.0f}".format(v.median_adjusted_price_per_sqft) }} |
| Subject Living Area | {{ "{:,.0f}".format(v.subject.property_area) }} sqft |
| **Estimated Market Value** | **${{ "{:,.0f}".format(v.estimated_market_value) }}** |
| Current Assessed Value | ${{ "{:,.0f}".format(v.assessed_value) }} |
{% if v.appeal_recommended %}| Potential Overassessment | ${{ "{:,.0f}".format(v.assessed_value - v.estimated_market_value) }} |
| **Potential Annual Tax Savings** | **${{ "{:,.0f}".format(v.potential_savings_annual) }}** |
{% endif %}

{% if v.appeal_recommended %}
### Recommendation: FILE AN APPEAL

Your property appears to be overassessed by ${{ "{:,.0f}".format(v.assessed_value - v.estimated_market_value) }}, \
which could save you approximately **${{ "{:,.0f}".format(v.potential_savings_annual) }} per year** in property taxes.
{% else %}
### Recommendation: No Appeal Recommended

Your assessed value (${{ "{:,.0f}".format(v.assessed_value) }}) is at or below the estimated \
market value (${{ "{:,.0f}".format(v.estimated_market_value) }}).
{% endif %}

---

## How to File

### Option 1: Informal Review (Recommended First Step)

1. Go to the **SF Assessor Online Portal**: [{{ portal_url }}]({{ portal_url }})
2. Log in or create an account, then select "Decline in Value"
3. Enter your property address and parcel number: **{{ v.subject.parcel_number }}**
4. Upload this report and/or enter your comparable sales evidence
5. Include the written rationale summary above in the "Comments" field
6. **Deadline:** January 2 - March 31, {{ filing_year }}
7. **Cost:** Free

### Option 2: Formal Appeal

1. File online at [sfgov.org/aab](https://sfgov.org/aab/online-appeal-application)
2. Submit Application for Changed Assessment (BOE-305-AH)
3. Include this report as supporting evidence
4. **Deadline:** July 2 - September 15, {{ filing_year }}
5. **Cost:** $120 filing fee (non-refundable)
6. **Contact:** Assessment Appeals Board, City Hall Room 405, (415) 554-6778

### Tips for a Successful Appeal

- Submit **3-5 comparable sales** that are similar to your property in size, type, and location
- Comps should be within **15-20% of your property's square footage**
- Recent sales (within 6 months of January 1) carry more weight
- Include your **written rationale** explaining why the market value is lower
- Note any factors that negatively affect your property (e.g., no parking, poor condition, no outdoor space)
- The assessor evaluates your property's value **as of January 1** of the assessment year

---

## Methodology

{{ v.methodology_notes }}

Comparable sales were selected using a scoring system that prioritizes: (1) properties within \
15-20% of the subject's square footage, (2) sales closest to the January 1 valuation date, \
(3) properties in the same neighborhood, and (4) the same property type.

The **median** adjusted price per square foot was used rather than the mean, as it is more \
robust against outlier sales and is consistent with standard appraisal methodology. Adjustments \
were applied for differences in bedrooms, bathrooms, living area, lot size, and building age.

Additional factors such as parking, renovations, outdoor space, and HOA fees may further \
affect value but require manual assessment and should be noted in the written rationale \
if applicable to your property.

*Disclaimer: This report is for informational purposes only and does not constitute \
professional appraisal advice. Consult a licensed appraiser for a formal valuation.*
"""


# ── Shared helpers ──


def _compute_filing_deadline(today: date) -> tuple[date, str]:
    """Return (filing_deadline, filing_type) based on today's date."""
    if today.month <= 3:
        return date(today.year, 3, 31), "informal"
    elif today.month <= 9 and today.day <= 15:
        return date(today.year, 9, 15), "formal"
    else:
        return date(today.year + 1, 3, 31), "informal"


def _build_report_obj(valuation: ValuationResult) -> AppealReport:
    """Create the AppealReport shell with filing info."""
    today = date.today()
    filing_deadline, filing_type = _compute_filing_deadline(today)

    return AppealReport(
        valuation=valuation,
        generated_at=datetime.now(),
        filing_deadline=filing_deadline,
        filing_type=filing_type,
        assessor_contact="SF Assessor-Recorder, City Hall Room 190, assessor@sfgov.org",
    )


# ── Markdown report (original path) ──


def generate_report(valuation: ValuationResult) -> AppealReport:
    """Generate the appeal report as Markdown."""
    report = _build_report_obj(valuation)
    filing_year = report.filing_deadline.year

    template = Template(REPORT_TEMPLATE)
    report.report_markdown = template.render(
        report=report,
        v=valuation,
        portal_url=SF_ASSESSOR_PORTAL_URL,
        filing_year=filing_year,
    )

    return report


def save_report(report: AppealReport, output_path: Optional[str] = None) -> Path:
    """Save the report to a Markdown file."""
    if output_path is None:
        parcel = report.valuation.subject.parcel_number.replace("/", "-")
        today = date.today().isoformat()
        output_path = f"appeal_report_{parcel}_{today}.md"

    path = Path(output_path)
    path.write_text(report.report_markdown)
    return path


# ── PDF report (randomized styling) ──


def _generate_language(rng, wording_style: str) -> dict:
    """Generate randomized labels and phrasing based on wording style.

    10 wording styles: formal, professional, concise, technical, narrative,
    plain, academic, legal, brief, conversational.
    """

    # ── Per-style word banks ──
    # Each key maps to a dict of {style_name: [options]} or a flat list (random pick)

    TITLES = {
        "formal":         ["Proposition 8 Decline-in-Value Appeal", "Formal Request for Assessment Reduction"],
        "professional":   ["Property Tax Appeal: Decline in Value", "Assessment Appeal: Market Value Analysis"],
        "concise":        ["Decline-in-Value Analysis", "Prop 8 Appeal"],
        "technical":      ["Comparable Sales & Valuation Analysis", "CMA-Based Prop 8 Assessment"],
        "narrative":      ["Property Value Assessment Report", "An Analysis of Market Value"],
        "plain":          ["Property Tax Appeal", "Request for Lower Property Tax Assessment"],
        "academic":       ["Empirical Analysis of Property Valuation", "Comparative Market Value Study"],
        "legal":          ["Petition for Reassessment Pursuant to Proposition 8", "Application for Decline-in-Value Reassessment"],
        "brief":          ["Prop 8 Appeal", "Value Appeal"],
        "conversational": ["Why My Property Tax Should Be Lower", "Property Tax Reassessment Request"],
    }

    DATE_LABELS = {
        "formal": ["Date Prepared", "Report Date"], "professional": ["Date", "Prepared"],
        "concise": ["Date", "As of"], "technical": ["Analysis Date", "Date"],
        "narrative": ["Prepared on", "Date"], "plain": ["Date", "Today"],
        "academic": ["Date of Analysis", "Report Date"], "legal": ["Date Filed", "Prepared"],
        "brief": ["Date", "As of"], "conversational": ["Date", "Prepared"],
    }

    PARCEL_LABELS = {
        "formal": ["Parcel Number", "APN"], "professional": ["Parcel", "Parcel No."],
        "concise": ["APN", "Parcel"], "technical": ["APN", "Parcel ID"],
        "narrative": ["Parcel Number", "Parcel"], "plain": ["Parcel", "Parcel Number"],
        "academic": ["Parcel Identifier", "APN"], "legal": ["Assessor\u2019s Parcel Number", "APN"],
        "brief": ["APN", "Parcel"], "conversational": ["Parcel", "Parcel No."],
    }

    DATE_FORMATS = {
        "formal": ["%B %d, %Y"], "professional": ["%B %d, %Y", "%b %d, %Y"],
        "concise": ["%m/%d/%Y", "%m/%d/%y"], "technical": ["%Y-%m-%d", "%m/%d/%Y"],
        "narrative": ["%B %d, %Y"], "plain": ["%B %d, %Y", "%b %d, %Y"],
        "academic": ["%d %B %Y", "%B %Y"], "legal": ["%B %d, %Y"],
        "brief": ["%m/%d/%y", "%m/%Y"], "conversational": ["%B %d, %Y", "%b %d, %Y"],
    }

    SUBJECT_HEADINGS = {
        "formal": ["Subject Property", "Subject Property Information"],
        "professional": ["Subject Property", "Property Details"],
        "concise": ["Property", "Subject"],
        "technical": ["Subject Property Data", "Property Characteristics"],
        "narrative": ["About the Property", "The Property in Question"],
        "plain": ["Your Property", "Property Details"],
        "academic": ["Subject Property Overview", "Property Under Analysis"],
        "legal": ["Subject Property", "Property at Issue"],
        "brief": ["Property", "Subject"],
        "conversational": ["Your Property", "Property Summary"],
    }

    RATIONALE_HEADINGS = {
        "formal": ["Written Rationale", "Statement of Value"],
        "professional": ["Analysis Summary", "Rationale"],
        "concise": ["Summary", "Rationale"],
        "technical": ["Value Indication Summary", "Analysis"],
        "narrative": ["Why the Value Is Lower", "Our Findings"],
        "plain": ["Why We Think It\u2019s Worth Less", "Summary"],
        "academic": ["Analytical Summary", "Findings"],
        "legal": ["Supporting Argument", "Basis for Appeal"],
        "brief": ["Summary", "Rationale"],
        "conversational": ["What We Found", "The Bottom Line"],
    }

    COMPS_HEADINGS = {
        "formal": ["Comparable Sales Analysis", "Comparable Property Sales"],
        "professional": ["Comparable Sales", "Recent Comparable Transactions"],
        "concise": ["Comps", "Sales Data"],
        "technical": ["Market Comparables", "CMA: Comparable Transactions"],
        "narrative": ["Similar Properties That Sold Recently", "Nearby Sales"],
        "plain": ["Comparable Sales", "Similar Homes That Sold"],
        "academic": ["Comparative Sales Data", "Empirical Comparable Transactions"],
        "legal": ["Evidence of Comparable Sales", "Supporting Sales Data"],
        "brief": ["Comps", "Sales"],
        "conversational": ["Similar Homes That Sold Nearby", "Comparable Sales"],
    }

    VALUATION_HEADINGS = {
        "formal": ["Valuation Summary", "Summary of Value"],
        "professional": ["Value Conclusion", "Valuation Analysis"],
        "concise": ["Valuation", "Value"],
        "technical": ["Indicated Value", "Value Reconciliation"],
        "narrative": ["What the Numbers Show", "Estimated Value"],
        "plain": ["Market Value Estimate", "What It\u2019s Worth"],
        "academic": ["Value Determination", "Empirical Valuation"],
        "legal": ["Determination of Fair Market Value", "Value Finding"],
        "brief": ["Value", "Result"],
        "conversational": ["The Numbers", "Value Estimate"],
    }

    METHODOLOGY_HEADINGS = {
        "formal": ["Methodology", "Valuation Methodology"],
        "professional": ["Approach & Methodology", "Method of Analysis"],
        "concise": ["Method", "Approach"],
        "technical": ["Analytical Framework", "Sales Comparison Approach"],
        "narrative": ["How We Arrived at This Value", "Our Approach"],
        "plain": ["How This Was Calculated", "Methodology"],
        "academic": ["Research Methodology", "Analytical Approach"],
        "legal": ["Basis of Valuation", "Methodology Employed"],
        "brief": ["Method", "Approach"],
        "conversational": ["How We Did This", "Our Method"],
    }

    ASSESSMENT_HEADINGS = {
        "formal": ["Current Assessment", "Current Assessed Value"],
        "professional": ["Assessment", "Assessed Value"],
        "concise": ["Assessment", "Current Value"],
        "technical": ["Current Roll Value", "Assessed Valuation"],
        "narrative": ["What the County Says It\u2019s Worth", "Current Assessment"],
        "plain": ["Current Tax Assessment", "Assessed Value"],
        "academic": ["Present Assessment", "Current Assessed Valuation"],
        "legal": ["Assessment Under Review", "Current Assessment"],
        "brief": ["Assessment", "Assessed"],
        "conversational": ["Your Current Assessment", "What You\u2019re Being Taxed On"],
    }

    # ── Helper to pick from style-specific list ──
    def pick(bank):
        options = bank.get(wording_style, bank.get("professional", ["?"]))
        return rng.choice(options)

    # ── Build common labels (also wording-style-aware) ──
    w = wording_style

    if w in ("concise", "brief", "technical"):
        field_l, value_l = rng.choice(["Item", "Field"]), rng.choice(["Value", "Data"])
        metric_l, comp_l = rng.choice(["Metric", "Item"]), rng.choice(["Item", "Element"])
        addr_l = rng.choice(["Address", "Addr"])
        type_l = rng.choice(["Type", "Use"])
        bed_l, bath_l = rng.choice(["Bd", "Beds"]), rng.choice(["Ba", "Baths"])
        living_l = rng.choice(["Sqft", "Area", "SF"])
        lot_l = rng.choice(["Lot", "Land"])
        year_l = rng.choice(["Built", "Yr Built"])
        hood_l = rng.choice(["Nbhd", "Area"])
        sp_l = rng.choice(["Price", "Sale $"])
        sd_l = rng.choice(["Date", "Sold"])
        bb_l = rng.choice(["Bd/Ba", "Beds/Baths"])
        raw_l = rng.choice(["Raw PSF", "Raw $/sf"])
        adj_l = rng.choice(["Adj PSF", "Adj $/sf", "Net PSF"])
        sqft_w = rng.choice(["sf", "SF", "sqft"])
        miles_w = rng.choice(["mi", "mi."])
        bed_w, bath_w = "bd", "ba"
        and_w = rng.choice(["&", "/"])
    elif w in ("formal", "legal", "academic"):
        field_l, value_l = rng.choice(["Field", "Attribute"]), rng.choice(["Value", "Amount"])
        metric_l, comp_l = rng.choice(["Metric", "Measure"]), rng.choice(["Component", "Category"])
        addr_l = rng.choice(["Property Address", "Street Address"])
        type_l = rng.choice(["Property Type", "Classification"])
        bed_l, bath_l = "Bedrooms", "Bathrooms"
        living_l = rng.choice(["Living Area", "Gross Living Area"])
        lot_l = rng.choice(["Lot Area", "Land Area"])
        year_l = rng.choice(["Year Built", "Construction Year"])
        hood_l = rng.choice(["Neighborhood", "District"])
        sp_l = rng.choice(["Sale Price", "Transaction Price"])
        sd_l = rng.choice(["Sale Date", "Transaction Date"])
        bb_l = "Bedrooms / Bathrooms"
        raw_l = rng.choice(["Unadjusted $/sqft", "Raw Price per Square Foot"])
        adj_l = rng.choice(["Adjusted $/sqft", "Adjusted Price per Square Foot"])
        sqft_w = rng.choice(["square feet", "sq ft"])
        miles_w = "miles"
        bed_w, bath_w = "bedrooms", "bathrooms"
        and_w = "and"
    elif w in ("narrative", "conversational", "plain"):
        field_l, value_l = rng.choice(["Detail", "Field"]), rng.choice(["Value", "Info"])
        metric_l, comp_l = rng.choice(["Measure", "Item"]), rng.choice(["Part", "Item"])
        addr_l = rng.choice(["Address", "Location"])
        type_l = rng.choice(["Type", "Property Type"])
        bed_l, bath_l = rng.choice(["Bedrooms", "Beds"]), rng.choice(["Bathrooms", "Baths"])
        living_l = rng.choice(["Living Space", "Interior Size", "Floor Area"])
        lot_l = rng.choice(["Lot Size", "Land Area"])
        year_l = rng.choice(["Year Built", "Built"])
        hood_l = rng.choice(["Neighborhood", "Area"])
        sp_l = rng.choice(["Sale Price", "Sold For", "Price"])
        sd_l = rng.choice(["Sale Date", "Date Sold", "When It Sold"])
        bb_l = rng.choice(["Beds / Baths", "Bedrooms / Bathrooms"])
        raw_l = rng.choice(["Raw $/sqft", "Price per Sqft"])
        adj_l = rng.choice(["Adjusted $/sqft", "Adj. $/sqft"])
        sqft_w = rng.choice(["sqft", "square feet", "sq ft"])
        miles_w = rng.choice(["miles", "mi"])
        bed_w = rng.choice(["bedrooms", "beds"])
        bath_w = rng.choice(["bathrooms", "baths"])
        and_w = rng.choice(["and", "&"])
    else:  # professional and fallback
        field_l, value_l = rng.choice(["Field", "Item"]), rng.choice(["Value", "Amount", "Data"])
        metric_l, comp_l = rng.choice(["Metric", "Measure"]), rng.choice(["Component", "Item"])
        addr_l = rng.choice(["Address", "Property Address"])
        type_l = rng.choice(["Property Type", "Type"])
        bed_l, bath_l = rng.choice(["Bedrooms", "Beds"]), rng.choice(["Bathrooms", "Baths"])
        living_l = rng.choice(["Living Area", "Floor Area", "Interior Sqft"])
        lot_l = rng.choice(["Lot Area", "Lot Size"])
        year_l = rng.choice(["Year Built", "Built"])
        hood_l = rng.choice(["Neighborhood", "Area", "District"])
        sp_l = rng.choice(["Sale Price", "Price", "Sold For"])
        sd_l = rng.choice(["Sale Date", "Date Sold", "Close Date"])
        bb_l = rng.choice(["Bedrooms / Bathrooms", "Beds / Baths", "Bd / Ba"])
        raw_l = rng.choice(["Raw $/sqft", "Unadjusted $/sqft", "Price/Sqft"])
        adj_l = rng.choice(["Adjusted $/sqft", "Adj. $/sqft", "Net $/sqft"])
        sqft_w = rng.choice(["sqft", "sq ft", "square feet"])
        miles_w = rng.choice(["miles", "mi"])
        bed_w = rng.choice(["bedrooms", "beds"])
        bath_w = rng.choice(["bathrooms", "baths"])
        and_w = rng.choice(["and", "&"])

    # ── Methodology text (per wording style) ──
    METHOD_SELECTION = {
        "formal": [
            "Comparable sales were selected by prioritizing: (1) properties within 15\u201320% of the subject\u2019s square footage, (2) sales closest to the January 1 valuation date, (3) properties in the same neighborhood, and (4) the same property type.",
        ],
        "professional": [
            "The selection of comparables focused on sales of similar-sized properties (within 15\u201320% of subject square footage) in the same neighborhood, of the same property type, with preference for transactions nearest the January 1 valuation date.",
        ],
        "concise": [
            "Comps selected by: size (15\u201320% of subject), proximity to Jan 1, same neighborhood, same property type.",
        ],
        "technical": [
            "Selection criteria: \u226420% GLA variance, same property type (URAR classification), same market area, sales proximate to the January 1 lien date. Distance-weighted ring sampling applied.",
        ],
        "narrative": [
            "We looked for homes that recently sold near the subject that are similar in size, type, and location. We focused on sales closest to January 1, since that\u2019s the date the assessor uses to determine value.",
        ],
        "plain": [
            "We found similar homes that sold recently nearby. They\u2019re about the same size and type as your property, and sold close to January 1 (the date used for tax assessments).",
        ],
        "academic": [
            "Comparables were identified through a multi-criteria selection framework prioritizing spatial proximity, temporal proximity to the January 1 assessment date, gross living area similarity (15\u201320% tolerance), and property type concordance.",
        ],
        "legal": [
            "Pursuant to standard appraisal practice, comparable sales were selected based on similarity to the subject property in size (within 15\u201320%), property type, location, and recency of sale relative to the January 1 assessment date.",
        ],
        "brief": [
            "Comps: same type, similar size (\u00b120%), nearby, recent sales near Jan 1.",
        ],
        "conversational": [
            "We picked similar homes that sold recently in your area\u2014same type of property, close in size, and ideally sold near January 1 (the date the county uses to set your tax value).",
        ],
    }

    METHOD_MEDIAN = {
        "formal": [
            "The median adjusted price per square foot was used rather than the mean, as it is more robust against outlier sales and is consistent with standard appraisal methodology. Adjustments were applied for differences in bedrooms, bathrooms, living area, lot size, and building age.",
        ],
        "professional": [
            "A median-based approach was used for the adjusted price per square foot, which reduces the influence of outlier transactions. Standard adjustments were made for bedroom count, bathroom count, living area, lot size, and age of construction.",
        ],
        "concise": [
            "Median adjusted $/sqft used (outlier-resistant). Adjustments: bedrooms, bathrooms, size, lot, age.",
        ],
        "technical": [
            "Value indication derived via median of adjusted sale prices per square foot of GLA. Paired sales adjustments applied for bedroom count differential, bathroom count differential, GLA variance, site area differential, and effective age difference.",
        ],
        "narrative": [
            "We used the middle value (median) of the adjusted prices per square foot rather than the average, because it\u2019s less affected by unusually high or low sales. We adjusted each comparable for differences in bedrooms, bathrooms, living area, lot size, and age.",
        ],
        "plain": [
            "We took the middle price per square foot from our comparable sales (the median), which is more reliable than the average. Each sale was adjusted for differences in size, bedrooms, bathrooms, lot, and age.",
        ],
        "academic": [
            "The valuation employs median-based central tendency of adjusted comparable prices per unit area, which demonstrates superior robustness to outlier observations relative to arithmetic mean. Paired-comparison adjustments account for heterogeneity in bedroom count, bathroom count, gross living area, lot dimensions, and structural age.",
        ],
        "legal": [
            "The market value indication is based on the median adjusted price per square foot across selected comparables, a methodology recognized as robust against outlier influence. Adjustments reflect measurable differences in physical characteristics including bedroom count, bathroom count, living area, lot size, and building age.",
        ],
        "brief": [
            "Median adj. $/sqft (outlier-resistant). Adjusted for: beds, baths, size, lot, age.",
        ],
        "conversational": [
            "We used the median (middle value) of the adjusted prices\u2014it\u2019s more reliable than an average because one really expensive or cheap sale doesn\u2019t throw it off. Each comparable was adjusted to account for differences in size, bedrooms, bathrooms, lot, and age.",
        ],
    }

    # ── Prose connectors (per wording style) ──
    SOLD_PHRASES = {
        "formal": ["This property sold for", "This comparable sold at"],
        "professional": ["Sold for", "This property sold for"],
        "concise": ["Sold:", "Price:"],
        "technical": ["Transaction recorded at", "Sale price:"],
        "narrative": ["This home sold for", "This comparable was purchased for"],
        "plain": ["This place sold for", "Sold for"],
        "academic": ["The recorded transaction price was", "This property transacted at"],
        "legal": ["The recorded sale price was", "This property transferred at"],
        "brief": ["Sold", "Price"],
        "conversational": ["This one sold for", "It went for"],
    }

    ON_PHRASES = {
        "formal": ["on", "dated"], "professional": ["on", "on"],
        "concise": ["on", ""], "technical": ["closing", "recorded"],
        "narrative": ["on", "back on"], "plain": ["on", "on"],
        "academic": ["on", "dated"], "legal": ["on or about", "dated"],
        "brief": ["", "on"], "conversational": ["on", "on"],
    }

    PROP_PHRASES = {
        "formal": ["The property comprises", "This residence contains"],
        "professional": ["It features", "The property contains"],
        "concise": ["Features:", "Details:"],
        "technical": ["Property data:", "GLA and features:"],
        "narrative": ["It\u2019s a", "This home has"],
        "plain": ["This home has", "It has"],
        "academic": ["The property encompasses", "This dwelling comprises"],
        "legal": ["The property consists of", "The premises contain"],
        "brief": ["Size:", "Specs:"],
        "conversational": ["It\u2019s got", "This place has"],
    }

    LOCATED_PHRASES = {
        "formal": ["It is situated approximately", "Located approximately"],
        "professional": ["Located", "Situated approximately"],
        "concise": ["Distance:", "Dist:"],
        "technical": ["Spatial offset:", "Linear distance:"],
        "narrative": ["It\u2019s about", "This home is roughly"],
        "plain": ["It\u2019s about", "Located about"],
        "academic": ["The spatial distance is approximately", "Located"],
        "legal": ["The property is situated approximately", "Located approximately"],
        "brief": ["Dist:", ""],
        "conversational": ["It\u2019s about", "This one is about"],
    }

    RAW_PHRASES = {
        "formal": ["The unadjusted price per square foot is", "Raw price per square foot:"],
        "professional": ["Raw $/sqft comes to", "The raw price per square foot is"],
        "concise": ["Raw:", "Raw PSF:"],
        "technical": ["Unadjusted unit price:", "Base $/GLA:"],
        "narrative": ["Before adjustments, the price per square foot is", "The starting price per sqft is"],
        "plain": ["Price per sqft before adjustments:", "Raw price per sqft:"],
        "academic": ["The unadjusted sale price per unit area is", "Pre-adjustment price per sqft:"],
        "legal": ["The unadjusted price per square foot is", "Base price per square foot:"],
        "brief": ["Raw:", "Base:"],
        "conversational": ["Before we adjust anything, it\u2019s", "Starting price per sqft:"],
    }

    ADJ_PHRASES = {
        "formal": [", yielding an adjusted value of", ". After adjustments:"],
        "professional": [", adjusting to", "; adjusted to"],
        "concise": [" \u2192", " \u2192 adj:"],
        "technical": [". Net adjusted:", ". Reconciled unit price:"],
        "narrative": [", which after adjustments comes to", ". After accounting for differences:"],
        "plain": [". After adjusting for differences:", ", adjusted to"],
        "academic": [". The adjusted indication is", ". Post-adjustment unit price:"],
        "legal": [". The adjusted comparable price is", ", adjusted to reflect"],
        "brief": [" \u2192", " adj:"],
        "conversational": [". After adjusting, that\u2019s", ", which comes out to"],
    }

    SUBJECT_INTROS = {
        "formal": ["The subject property is located at", "This analysis pertains to the property at"],
        "professional": ["The property under review is", "This analysis concerns"],
        "concise": ["Subject:", "Property:"],
        "technical": ["Subject property identifier:", "Subject data for"],
        "narrative": ["The property we\u2019re looking at is", "This is about the home at"],
        "plain": ["Your property is at", "The property at"],
        "academic": ["The subject of this analysis is the property located at", "Under examination is"],
        "legal": ["The subject property, situated at", "The property at issue is located at"],
        "brief": ["Subject:", "Prop:"],
        "conversational": ["Your home at", "We\u2019re looking at"],
    }

    SUBJECT_TYPES = {
        "formal": [" It is classified as a ", " The property type is "],
        "professional": [" This is a ", " Property type: "],
        "concise": [" Type: ", " "],
        "technical": [" Classification: ", " URAR type: "],
        "narrative": [" It\u2019s a ", " This is a "],
        "plain": [" It\u2019s a ", " Type: "],
        "academic": [" The property is classified as ", " Categorized as "],
        "legal": [" Said property is classified as a ", " The property type is "],
        "brief": [" ", " Type: "],
        "conversational": [" It\u2019s a ", " This is a "],
    }

    SUBJECT_WITHS = {
        "formal": [" with ", " comprising "],
        "professional": [" with ", ", featuring "],
        "concise": [" w/ ", ", "],
        "technical": [" containing ", " with "],
        "narrative": [" with ", " that has "],
        "plain": [" with ", " that has "],
        "academic": [" encompassing ", " comprising "],
        "legal": [" containing ", " with "],
        "brief": [", ", " w/ "],
        "conversational": [" with ", " and it has "],
    }

    SUBJECT_LOTS = {
        "formal": [" on a lot of ", ". The lot area is "],
        "professional": [" with a lot size of ", ". Lot area: "],
        "concise": [". Lot: ", ", lot "],
        "technical": [". Site area: ", ". Lot: "],
        "narrative": [" on a ", ". The lot is "],
        "plain": [" on a lot of ", ". Lot size: "],
        "academic": [". The parcel comprises ", ". Site area: "],
        "legal": [" on a parcel of ", ". The lot area is "],
        "brief": [", lot ", ". Lot: "],
        "conversational": [" on a ", ". The lot is "],
    }

    return {
        "title": pick(TITLES),
        "date_label": pick(DATE_LABELS),
        "parcel_label": pick(PARCEL_LABELS),
        "date_format": pick(DATE_FORMATS),
        "subject_heading": pick(SUBJECT_HEADINGS),
        "assessment_heading": pick(ASSESSMENT_HEADINGS),
        "rationale_heading": pick(RATIONALE_HEADINGS),
        "comps_heading": pick(COMPS_HEADINGS),
        "valuation_heading": pick(VALUATION_HEADINGS),
        "methodology_heading": pick(METHODOLOGY_HEADINGS),
        "field_label": field_l,
        "value_label": value_l,
        "metric_label": metric_l,
        "component_label": comp_l,
        "address_label": addr_l,
        "type_label": type_l,
        "bedrooms_label": bed_l,
        "bathrooms_label": bath_l,
        "living_area_label": living_l,
        "lot_area_label": lot_l,
        "year_built_label": year_l,
        "neighborhood_label": hood_l,
        "roll_year_label": rng.choice(["Roll Year", "Tax Year", "Assessment Year"]),
        "land_label": rng.choice(["Land", "Land Value"]),
        "improvements_label": rng.choice(["Improvements", "Structure", "Building"]),
        "total_assessed_label": rng.choice(["Total Assessed Value", "Total Assessment"]),
        "assessed_per_sqft_label": rng.choice(["Assessed $/sqft", "Assessment PSF"]),
        "sale_price_label": sp_l,
        "sale_date_label": sd_l,
        "bed_bath_label": bb_l,
        "distance_label": rng.choice(["Distance", "Distance from Subject", "Proximity"]),
        "raw_psf_label": raw_l,
        "adj_psf_label": adj_l,
        "adjustments_label": rng.choice(["Adjustments", "Value Adjustments", "Applied Adjustments"]),
        "no_adjustments": rng.choice(["No adjustments applied.", "No adjustments were necessary.", "None required.", "No adjustment needed."]),
        "median_psf_label": rng.choice(["Median Adjusted $/sqft", "Median Adj. PSF", "Median $/sqft (Adjusted)"]),
        "subject_area_label": rng.choice(["Subject Living Area", "Subject Sqft", "Subject Floor Area"]),
        "estimated_mv_label": rng.choice(["Estimated Market Value", "Market Value Estimate", "Indicated Value"]),
        "current_av_label": rng.choice(["Current Assessed Value", "Assessment", "Assessed Value"]),
        "overassessment_label": rng.choice(["Overassessment", "Excess Assessment", "Decline in Value"]),
        "methodology_selection": pick(METHOD_SELECTION),
        "methodology_median": pick(METHOD_MEDIAN),
        "prose_comp_sold": pick(SOLD_PHRASES),
        "prose_comp_on": pick(ON_PHRASES),
        "prose_comp_property": pick(PROP_PHRASES),
        "prose_comp_located": pick(LOCATED_PHRASES),
        "prose_comp_raw": pick(RAW_PHRASES),
        "prose_comp_adjusted": pick(ADJ_PHRASES),
        "subject_prose_intro": pick(SUBJECT_INTROS),
        "subject_prose_type": pick(SUBJECT_TYPES),
        "subject_prose_with": pick(SUBJECT_WITHS),
        "subject_prose_lot": pick(SUBJECT_LOTS),
        "sqft_word": sqft_w,
        "miles_word": miles_w,
        "bedrooms_word": bed_w,
        "bathrooms_word": bath_w,
        "and_word": and_w,
        "of_living_space": rng.choice([" of living space", " of interior space", "", " of floor area"]),
        "on_a_word": rng.choice(["on a", "with a", "on"]),
        "lot_word": rng.choice(["lot", "parcel", "site"]),
        "built_in": rng.choice(["Built in", "Constructed in", "Year built:", "Built"]),
        "located_in": rng.choice(["Located in", "Neighborhood:", "Situated in", "In"]),
        "from_subject": rng.choice(["from the subject", "away", "from subject property"]),
    }


def generate_html_report(
    valuation: ValuationResult, seed: Optional[str] = None
) -> AppealReport:
    """Generate the appeal report with randomized HTML styling for PDF output."""
    from appeal.pdf_styles import StyleRandomizer

    report = _build_report_obj(valuation)
    filing_year = report.filing_deadline.year

    # Compute seed
    if seed is None:
        seed = StyleRandomizer.default_seed(valuation.subject.parcel_number)

    # Generate randomized style, language, and metadata
    randomizer = StyleRandomizer(seed)
    style = randomizer.generate()
    meta = randomizer.generate_metadata()
    lang = _generate_language(randomizer._rng, style.wording_style)

    logger.info(
        f"PDF style: layout={style.layout_mode}, font={style.body_font}, "
        f"accent={style.accent_color}, table={style.table_style} (seed={seed})"
    )

    # Load and render HTML template
    template_str = (
        pkg_files("appeal.templates").joinpath("report.html").read_text()
    )
    template = Template(template_str)
    report.report_html = template.render(
        report=report,
        v=valuation,
        portal_url=SF_ASSESSOR_PORTAL_URL,
        filing_year=filing_year,
        style=style,
        lang=lang,
        meta=meta,
    )

    # Also generate markdown for backward compat
    md_template = Template(REPORT_TEMPLATE)
    report.report_markdown = md_template.render(
        report=report,
        v=valuation,
        portal_url=SF_ASSESSOR_PORTAL_URL,
        filing_year=filing_year,
    )

    return report


def save_report_pdf(
    report: AppealReport,
    output_path: Optional[str] = None,
    seed: Optional[str] = None,
) -> Path:
    """Render the HTML report to PDF using WeasyPrint."""
    try:
        from weasyprint import HTML
    except ImportError:
        raise ImportError(
            "WeasyPrint is required for PDF output. "
            "Install it with: pip install 'appeal[pdf]'"
        )
    import pydyf
    from appeal.pdf_styles import StyleRandomizer

    if output_path is None:
        parcel = report.valuation.subject.parcel_number.replace("/", "-")
        today = date.today().isoformat()
        output_path = f"appeal_report_{parcel}_{today}.pdf"

    # Generate randomized metadata to prevent fingerprinting
    if seed is None:
        seed = StyleRandomizer.default_seed(
            report.valuation.subject.parcel_number
        )
    randomizer = StyleRandomizer(seed)
    # Consume the same RNG calls as generate() so metadata stays deterministic
    randomizer.generate()
    meta = randomizer.generate_metadata()

    def _set_metadata(document, pdf):
        """Override PDF metadata with randomized values."""
        pdf.info["Producer"] = pydyf.String(meta["Producer"])
        pdf.info["Creator"] = pydyf.String(meta["Creator"])
        if meta["Author"]:
            pdf.info["Author"] = pydyf.String(meta["Author"])
        elif "Author" in pdf.info:
            del pdf.info["Author"]
        # Strip timestamps that could correlate reports
        for key in ("CreationDate", "ModDate"):
            if key in pdf.info:
                del pdf.info[key]

    path = Path(output_path)
    html = HTML(string=report.report_html)
    html.write_pdf(path, finisher=_set_metadata)
    return path
