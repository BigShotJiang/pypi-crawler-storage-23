"""DataSF SODA API client for SF Assessor property tax roll data."""

from __future__ import annotations

from typing import List, Optional

import httpx
import logging
from appeal.models import SubjectProperty, GeoPoint
from appeal.config import DATASF_BASE_URL, DATASF_ROLL_YEARS
from appeal.address import parse_user_address, match_address, format_datasf_address

logger = logging.getLogger(__name__)


class DataSFClient:
    def __init__(self):
        self.client = httpx.Client(timeout=30)
        self.base_url = DATASF_BASE_URL

    def search_property(
        self, address: str, roll_years: Optional[List[str]] = None
    ) -> list[dict]:
        """Search for a property by address text.

        Tries multiple roll years in order (newest first) since
        DataSF data publication lags by ~1 year.
        """
        if roll_years is None:
            roll_years = DATASF_ROLL_YEARS

        parsed = parse_user_address(address)
        street = parsed.get("street", "")
        number = parsed.get("number", "")

        if not street:
            return []

        for roll_year in roll_years:
            results = self._search_for_year(parsed, street, number, roll_year)
            if results:
                return results

        return []

    def _search_for_year(
        self, parsed: dict, street: str, number: str, roll_year: str
    ) -> list[dict]:
        """Search for a property in a specific roll year."""
        # When we have a street number, search specifically for it.
        # DataSF property_location format: "NNNN NNNN STREET   ST UNIT"
        # where the second 4-digit group is the street number (zero-padded).
        # e.g. "0000 1318 PAGE               ST0000"
        if number:
            padded = number.zfill(4)
            where = (
                f"upper(property_location) like '% {padded} {street.upper()}%' "
                f"AND closed_roll_year='{roll_year}'"
            )
            params = {"$where": where, "$limit": 20}
            response = self.client.get(self.base_url, params=params)
            response.raise_for_status()
            results = response.json()

            if results:
                # Narrow further by matching the parsed address
                matched = match_address(parsed, results)
                if matched:
                    return [matched]
                return results

        # Fallback: broad street name search (no number or number search failed)
        where = (
            f"upper(property_location) like '%{street.upper()}%' "
            f"AND closed_roll_year='{roll_year}'"
        )
        params = {"$where": where, "$limit": 50}
        response = self.client.get(self.base_url, params=params)
        response.raise_for_status()
        results = response.json()

        if number and results:
            matched = match_address(parsed, results)
            if matched:
                return [matched]

        return results

    def get_property_by_parcel(
        self, parcel_number: str, roll_year: str = DATASF_ROLL_YEARS[0]
    ) -> Optional[dict]:
        """Get a specific property by parcel number."""
        params = {
            "$where": f"parcel_number='{parcel_number}' AND closed_roll_year='{roll_year}'",
            "$limit": 1,
        }
        response = self.client.get(self.base_url, params=params)
        response.raise_for_status()
        results = response.json()
        return results[0] if results else None

    def get_property_by_geo(
        self, lat: float, lon: float, roll_year: str = DATASF_ROLL_YEARS[0]
    ) -> list[dict]:
        """Find properties near exact coordinates (50m radius)."""
        params = {
            "$where": (
                f"within_circle(the_geom, {lat}, {lon}, 50) "
                f"AND closed_roll_year='{roll_year}'"
            ),
            "$limit": 10,
        }
        response = self.client.get(self.base_url, params=params)
        response.raise_for_status()
        return response.json()

    def find_nearby_properties(
        self,
        lat: float,
        lon: float,
        radius_meters: int = 800,
        roll_year: str = DATASF_ROLL_YEARS[0],
        use_code: Optional[str] = None,
    ) -> list[dict]:
        """Find nearby properties for comparable analysis.

        Fetches current and previous year to detect assessment jumps.
        """
        years = [roll_year, str(int(roll_year) - 1)]
        all_results = []

        for year in years:
            where = (
                f"within_circle(the_geom, {lat}, {lon}, {radius_meters}) "
                f"AND closed_roll_year='{year}'"
            )
            if use_code:
                where += f" AND use_code='{use_code}'"

            params = {
                "$where": where,
                "$limit": 500,
                "$select": (
                    "parcel_number,property_location,closed_roll_year,"
                    "assessed_land_value,assessed_improvement_value,"
                    "property_area,lot_area,number_of_bedrooms,number_of_bathrooms,"
                    "year_property_built,number_of_stories,the_geom,"
                    "assessor_neighborhood"
                ),
            }
            try:
                response = self.client.get(self.base_url, params=params)
                response.raise_for_status()
                all_results.extend(response.json())
            except Exception as e:
                logger.warning(f"DataSF nearby search failed for year {year}: {e}")

        return all_results

    def close(self):
        self.client.close()


def record_to_subject(record: dict) -> SubjectProperty:
    """Convert a DataSF record dict to a SubjectProperty model."""
    geo = None
    if "the_geom" in record and record["the_geom"]:
        try:
            coords = record["the_geom"]["coordinates"]
            geo = GeoPoint(latitude=coords[1], longitude=coords[0])
        except (KeyError, IndexError, TypeError):
            pass

    return SubjectProperty(
        address=format_datasf_address(record.get("property_location", "")),
        parcel_number=record.get("parcel_number", ""),
        block=record.get("block", ""),
        lot=record.get("lot", ""),
        geo=geo,
        bedrooms=_int(record.get("number_of_bedrooms", 0)),
        bathrooms=_float(record.get("number_of_bathrooms", 0)),
        property_area=_float(record.get("property_area", 0)),
        lot_area=_float(record.get("lot_area", 0)),
        year_built=_int(record.get("year_property_built", 0)),
        stories=_float(record.get("number_of_stories", 0)),
        units=_int(record.get("number_of_units", 1)),
        use_code=record.get("use_code", ""),
        use_definition=record.get("use_definition", ""),
        construction_type=record.get("construction_type", ""),
        roll_year=record.get("closed_roll_year", ""),
        assessed_land_value=_float(record.get("assessed_land_value", 0)),
        assessed_improvement_value=_float(record.get("assessed_improvement_value", 0)),
        assessor_neighborhood=record.get("assessor_neighborhood", ""),
        analysis_neighborhood=record.get("analysis_neighborhood", ""),
    )


def _int(val) -> int:
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return 0


def _float(val) -> float:
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0
