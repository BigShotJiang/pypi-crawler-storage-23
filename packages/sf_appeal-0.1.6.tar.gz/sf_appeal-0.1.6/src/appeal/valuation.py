"""Market value calculation and savings estimate."""

from __future__ import annotations

import statistics
from datetime import date
from appeal.models import SubjectProperty, ComparableSale, ValuationResult
from appeal.config import SF_TAX_RATE


def calculate_valuation(
    subject: SubjectProperty,
    selected_comps: list[ComparableSale],
    all_comps: list[ComparableSale],
) -> ValuationResult:
    """Calculate estimated market value and potential tax savings.

    Methodology (per blog guidance):
    1. Take the **median** adjusted $/sqft of selected comps
    2. Multiply by subject's living area
    3. Compare to current assessed value
    4. Calculate potential annual savings at SF tax rate (~1.2%)

    Using median rather than mean because:
    - More robust against outliers
    - Standard practice in property tax appeals
    - Assessor's office uses similar methodology
    """
    if not selected_comps:
        raise ValueError("No comparable sales available for valuation")

    adj_values = [c.adjusted_price_per_sqft for c in selected_comps]
    median_adj_ppsf = statistics.median(adj_values)
    estimated_value = median_adj_ppsf * subject.property_area
    assessed_value = subject.total_assessed_value

    savings = None
    savings_pct = None
    appeal_recommended = False

    if estimated_value < assessed_value:
        reduction = assessed_value - estimated_value
        savings = reduction * SF_TAX_RATE
        savings_pct = reduction / assessed_value if assessed_value > 0 else 0
        appeal_recommended = True

    # Generate written rationale summary (1-3 sentences per blog guidance)
    rationale = _generate_rationale(
        subject, selected_comps, median_adj_ppsf, estimated_value, assessed_value
    )

    return ValuationResult(
        subject=subject,
        all_comps=all_comps,
        selected_comps=selected_comps,
        median_adjusted_price_per_sqft=median_adj_ppsf,
        estimated_market_value=estimated_value,
        assessed_value=assessed_value,
        potential_savings_annual=savings,
        potential_savings_pct=savings_pct,
        appeal_recommended=appeal_recommended,
        valuation_date=date.today(),
        rationale_summary=rationale,
        methodology_notes=(
            f"Market value estimated using the median adjusted price per square foot "
            f"from {len(selected_comps)} comparable recent sales. "
            f"Median adjusted $/sqft: ${median_adj_ppsf:,.0f}. "
            f"Subject living area: {subject.property_area:,.0f} sqft."
        ),
    )


def _generate_rationale(
    subject: SubjectProperty,
    comps: list[ComparableSale],
    median_ppsf: float,
    estimated_value: float,
    assessed_value: float,
) -> str:
    """Generate a 1-3 sentence written rationale for the appeal.

    Per blog: the appeal should include a brief written summary explaining
    the estimated market value and the comparable sales that support it.
    """
    neighborhood = subject.assessor_neighborhood or subject.analysis_neighborhood or "the area"

    # Date range of comp sales
    sale_dates = [c.sale_date for c in comps if c.sale_date]
    if sale_dates:
        earliest = min(sale_dates).strftime("%B %Y")
        latest = max(sale_dates).strftime("%B %Y")
        date_range = f"from {earliest} to {latest}" if earliest != latest else f"in {earliest}"
    else:
        date_range = "from recent months"

    rationale = (
        f"Based on {len(comps)} comparable sales {date_range} in {neighborhood}, "
        f"the estimated market value of {subject.address} is ${estimated_value:,.0f} "
        f"(${median_ppsf:,.0f}/sqft median adjusted price). "
    )

    if estimated_value < assessed_value:
        overassessment = assessed_value - estimated_value
        rationale += (
            f"The current assessed value of ${assessed_value:,.0f} exceeds this "
            f"market estimate by ${overassessment:,.0f}, indicating a decline in value "
            f"that warrants a Proposition 8 reduction."
        )
    else:
        rationale += (
            f"The current assessed value of ${assessed_value:,.0f} does not exceed "
            f"the estimated market value."
        )

    return rationale
