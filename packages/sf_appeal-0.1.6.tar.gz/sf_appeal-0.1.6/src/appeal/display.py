"""Rich terminal display for property data, comps, and valuations."""

from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from appeal.models import SubjectProperty, ComparableSale, ValuationResult

console = Console()


def display_property(subject: SubjectProperty):
    """Display subject property details."""
    table = Table(title="Subject Property", show_header=True, header_style="bold cyan")
    table.add_column("Field", style="cyan", min_width=20)
    table.add_column("Value", style="white")

    table.add_row("Address", subject.address)
    table.add_row("Parcel", f"{subject.parcel_number} (Block {subject.block}, Lot {subject.lot})")
    table.add_row("Type", subject.use_definition or subject.use_code)
    table.add_row("Bed / Bath", f"{subject.bedrooms} bed / {subject.bathrooms} bath")
    table.add_row("Living Area", f"{subject.property_area:,.0f} sqft")
    table.add_row("Lot Area", f"{subject.lot_area:,.0f} sqft")
    table.add_row("Year Built", str(subject.year_built) if subject.year_built else "N/A")
    table.add_row("Stories", str(subject.stories) if subject.stories else "N/A")
    table.add_row("Neighborhood", subject.assessor_neighborhood or subject.analysis_neighborhood)
    table.add_row("", "")
    table.add_row("Assessed Land", f"${subject.assessed_land_value:,.0f}")
    table.add_row("Assessed Improvements", f"${subject.assessed_improvement_value:,.0f}")
    table.add_row("[bold]Total Assessed Value[/bold]", f"[bold]${subject.total_assessed_value:,.0f}[/bold]")
    if subject.assessed_price_per_sqft:
        table.add_row("Assessed $/sqft", f"${subject.assessed_price_per_sqft:,.0f}")
    table.add_row("Roll Year", subject.roll_year)

    console.print()
    console.print(table)
    console.print()


def display_comps_table(comps: list[ComparableSale], title: Optional[str] = None):
    """Display comparables in a summary table."""
    table = Table(title=title or f"Comparable Sales ({len(comps)} found)", expand=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Address", min_width=20, ratio=3)
    table.add_column("Sale Price", justify="right", min_width=12)
    table.add_column("Date", width=10)
    table.add_column("Sqft", justify="right", width=7)
    table.add_column("Bd/Ba", width=6)
    table.add_column("$/sqft", justify="right", width=8)
    table.add_column("Adj $/sf", justify="right", style="bold", width=9)
    table.add_column("Dist", justify="right", width=7)

    for i, c in enumerate(comps, 1):
        table.add_row(
            str(i),
            c.address,
            f"${c.sale_price:,.0f}",
            c.sale_date.strftime("%m/%d/%y") if c.sale_date else "-",
            f"{c.property_area:,.0f}",
            f"{c.bedrooms}/{c.bathrooms:.0f}",
            f"${c.raw_price_per_sqft:,.0f}" if c.raw_price_per_sqft else "-",
            f"${c.adjusted_price_per_sqft:,.0f}" if c.adjusted_price_per_sqft else "-",
            f"{c.distance_miles:.1f}mi" if c.distance_miles else "-",
        )

    console.print()
    console.print(table)
    console.print()


def display_comp_detail(comp: ComparableSale, index: int):
    """Display detailed adjustments for a single comp."""
    console.print(f"\n[bold]Comp {index}: {comp.address}[/bold]")
    console.print(f"  Sale: ${comp.sale_price:,.0f} on {comp.sale_date}")
    console.print(f"  Size: {comp.property_area:,.0f} sqft | {comp.bedrooms}bd/{comp.bathrooms:.0f}ba")
    if comp.raw_price_per_sqft:
        console.print(f"  Raw $/sqft: ${comp.raw_price_per_sqft:,.0f}")

    if comp.adjustments:
        console.print("  Adjustments:")
        for adj in comp.adjustments:
            sign = "+" if adj.amount_per_sqft >= 0 else ""
            console.print(f"    {adj.description}: {sign}${adj.amount_per_sqft:.0f}/sqft")

    if comp.adjusted_price_per_sqft:
        console.print(f"  [bold]Adjusted $/sqft: ${comp.adjusted_price_per_sqft:,.0f}[/bold]")


def display_valuation(result: ValuationResult):
    """Display the valuation result in a prominent panel."""
    lines = []
    lines.append(f"Median Adjusted $/sqft:    ${result.median_adjusted_price_per_sqft:>12,.0f}")
    lines.append(f"Your Living Area:          {result.subject.property_area:>12,.0f} sqft")
    lines.append(f"Estimated Market Value:     ${result.estimated_market_value:>12,.0f}")
    lines.append("")
    lines.append(f"Current Assessed Value:     ${result.assessed_value:>12,.0f}")

    if result.appeal_recommended:
        overassessment = result.assessed_value - result.estimated_market_value
        lines.append(f"Potential Overassessment:   ${overassessment:>12,.0f}")
        lines.append(f"Potential Annual Savings:   ${result.potential_savings_annual:>12,.0f} /yr")
        lines.append("")
        lines.append("[bold green]APPEAL RECOMMENDED[/bold green]")
        border_style = "green"
    else:
        lines.append("")
        lines.append("[bold yellow]NO APPEAL RECOMMENDED[/bold yellow]")
        lines.append("Your assessed value is at or below estimated market value.")
        border_style = "yellow"

    panel = Panel(
        "\n".join(lines),
        title="[bold]YOUR PROPERTY VALUATION[/bold]",
        border_style=border_style,
        padding=(1, 2),
    )
    console.print()
    console.print(panel)
    console.print()


def display_address_choices(records: list[dict]):
    """Display multiple address matches for user selection."""
    from appeal.address import format_datasf_address

    table = Table(title="Multiple Properties Found")
    table.add_column("#", style="dim", width=3)
    table.add_column("Address")
    table.add_column("Parcel")
    table.add_column("Type")

    for i, r in enumerate(records, 1):
        table.add_row(
            str(i),
            format_datasf_address(r.get("property_location", "")),
            r.get("parcel_number", ""),
            r.get("use_definition", r.get("use_code", "")),
        )

    console.print()
    console.print(table)
    console.print()
