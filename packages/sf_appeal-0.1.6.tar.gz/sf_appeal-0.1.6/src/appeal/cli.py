"""CLI interface for the SF Prop 8 Property Tax Appeal Tool."""

from __future__ import annotations

import logging
import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from datetime import date
from appeal.config import DEFAULT_COMP_RADIUS_MILES, DEFAULT_COMP_MONTHS_BACK, DEFAULT_NUM_COMPS, SF_ASSESSOR_PORTAL_URL

# Suppress noisy library warnings from console output
logging.basicConfig(level=logging.ERROR)
logging.getLogger("appeal").setLevel(logging.ERROR)
logging.getLogger("httpx").setLevel(logging.ERROR)
logging.getLogger("httpcore").setLevel(logging.ERROR)

app = typer.Typer(
    name="appeal",
    help="SF Prop 8 Property Tax Appeal Tool - Analyze your property and find potential tax savings.",
    no_args_is_help=False,
)
console = Console()


def _lookup_property(address: str):
    """Look up and confirm a property from DataSF."""
    from appeal.datasf import DataSFClient, record_to_subject
    from appeal.geocode import geocode_address
    from appeal.display import display_property, display_address_choices

    client = DataSFClient()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Looking up property...", total=None)
        results = client.search_property(address)

    if not results:
        # Try geocoding fallback
        console.print("[yellow]Address not found in assessor records. Trying geocoding...[/yellow]")
        coords = geocode_address(address)
        if coords:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
                transient=True,
            ) as progress:
                progress.add_task("Searching by location...", total=None)
                results = client.get_property_by_geo(coords[0], coords[1])

    client.close()

    if not results:
        console.print("[red]Could not find property. Please check the address and try again.[/red]")
        raise typer.Exit(1)

    if len(results) == 1:
        subject = record_to_subject(results[0])
    else:
        # Multiple matches - let user choose
        display_address_choices(results)
        choice = typer.prompt("Select property number", type=int, default=1)
        if choice < 1 or choice > len(results):
            console.print("[red]Invalid selection.[/red]")
            raise typer.Exit(1)
        subject = record_to_subject(results[choice - 1])

    # Geocode if we don't have coordinates
    if not subject.geo:
        coords = geocode_address(subject.address + ", San Francisco, CA")
        if coords:
            from appeal.models import GeoPoint
            subject.geo = GeoPoint(latitude=coords[0], longitude=coords[1])

    display_property(subject)
    return subject


def _fetch_and_analyze(
    subject,
    radius: float = DEFAULT_COMP_RADIUS_MILES,
    months: int = DEFAULT_COMP_MONTHS_BACK,
    num_comps: int = DEFAULT_NUM_COMPS,
):
    """Fetch comps, calculate adjustments, and produce valuation."""
    from appeal.comps import fetch_comparable_sales, select_best_comps
    from appeal.valuation import calculate_valuation
    from appeal.display import display_comps_table, display_comp_detail, display_valuation

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Searching for comparable sales...", total=None)

        def update_status(msg):
            progress.update(task, description=msg)

        all_comps = fetch_comparable_sales(
            subject,
            radius_miles=radius,
            months_back=months,
            status_callback=update_status,
        )

    if not all_comps:
        console.print("[red]No comparable sales found. Try increasing the search radius (--radius).[/red]")
        console.print("[dim]Tip: For unique properties, you may need a wider radius (e.g., --radius 1.0).[/dim]")
        raise typer.Exit(1)

    if len(all_comps) < 3:
        console.print(
            f"[yellow]Only {len(all_comps)} comp(s) found. For a strong appeal, "
            f"3-5 comps are recommended. Try --radius 1.0 for a wider search.[/yellow]\n"
        )

    # Select best comps and apply adjustments
    selected = select_best_comps(all_comps, subject, n=num_comps)

    if not selected:
        console.print("[red]No valid comps after filtering. Try adjusting parameters.[/red]")
        raise typer.Exit(1)

    # Also apply adjustments to all comps for display
    from appeal.comps import apply_adjustments
    all_adjusted = [apply_adjustments(c, subject) for c in all_comps]
    all_adjusted.sort(key=lambda c: c.adjusted_price_per_sqft or float("inf"))

    # Display all comps
    display_comps_table(all_adjusted)

    # Display selected comp details
    console.print(f"[bold]Selected {len(selected)} comps with lowest adjusted $/sqft:[/bold]")
    for i, comp in enumerate(selected, 1):
        display_comp_detail(comp, i)

    # Calculate valuation
    valuation = calculate_valuation(subject, selected, all_adjusted)
    display_valuation(valuation)

    # Display written rationale
    if valuation.rationale_summary:
        console.print("[bold]Written Rationale (for your appeal):[/bold]")
        console.print(f"  {valuation.rationale_summary}")
        console.print()

    return valuation


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """Interactive property tax appeal analysis."""
    if ctx.invoked_subcommand is not None:
        return

    console.print()
    console.print("[bold]SF Prop 8 Property Tax Appeal Tool[/bold]")
    console.print("Analyze your property value and find potential tax savings.\n")

    # Show filing deadline info
    today = date.today()
    if today.month <= 3:
        console.print(f"[green]Informal review deadline: March 31, {today.year}[/green]")
    elif today.month <= 9:
        console.print(f"[green]Formal appeal deadline: September 15, {today.year}[/green]")
    else:
        console.print(f"[green]Next informal review deadline: March 31, {today.year + 1}[/green]")
    console.print()

    # Step 1: Address
    address = typer.prompt("Enter your San Francisco property address")

    # Step 2: Radius
    radius_str = typer.prompt(
        "Search radius in miles",
        default=str(DEFAULT_COMP_RADIUS_MILES),
    )
    radius = float(radius_str)

    # Step 3: Lookup
    subject = _lookup_property(address)

    if not typer.confirm("Is this your property?", default=True):
        console.print("Please try again with the correct address.")
        raise typer.Exit()

    # Step 4-5: Comps and Valuation
    valuation = _fetch_and_analyze(subject, radius=radius)

    # Step 6: Report
    if valuation.appeal_recommended and typer.confirm(
        "Generate appeal report?", default=True
    ):
        try:
            from appeal.report import generate_html_report, save_report_pdf

            report_obj = generate_html_report(valuation)
            path = save_report_pdf(report_obj)
            console.print(f"\n[green]PDF report saved to: {path}[/green]")
        except ImportError:
            from appeal.report import generate_report, save_report

            console.print("[yellow]WeasyPrint not installed. Generating Markdown report.[/yellow]")
            console.print("[dim]Install PDF support: pip install 'appeal[pdf]'[/dim]")
            report_obj = generate_report(valuation)
            path = save_report(report_obj)
            console.print(f"\n[green]Report saved to: {path}[/green]")

        console.print(f"\n  File your appeal at: [bold cyan]{SF_ASSESSOR_PORTAL_URL}[/bold cyan]")
        console.print(f"  Block: [bold]{valuation.subject.block}[/bold]  Lot: [bold]{valuation.subject.lot}[/bold]")
        console.print("  Goto: [italic]Other Filings > Informal Assessment Review Request[/italic]")
        console.print("\n  [dim]Disclaimer: This report is for informational purposes only and does not constitute professional appraisal advice.[/dim]")


@app.command()
def analyze(
    address: str = typer.Argument(..., help="Property address in San Francisco"),
    radius: float = typer.Option(DEFAULT_COMP_RADIUS_MILES, help="Search radius in miles"),
    months: int = typer.Option(DEFAULT_COMP_MONTHS_BACK, help="Months back to search for sales"),
    num_comps: int = typer.Option(DEFAULT_NUM_COMPS, "--comps", help="Number of comps to select"),
):
    """Analyze a property and estimate market value."""
    subject = _lookup_property(address)
    _fetch_and_analyze(subject, radius=radius, months=months, num_comps=num_comps)


@app.command()
def lookup(
    address: str = typer.Argument(..., help="Property address in San Francisco"),
):
    """Look up property details from the SF Assessor."""
    _lookup_property(address)


@app.command()
def comps(
    address: str = typer.Argument(..., help="Property address in San Francisco"),
    radius: float = typer.Option(DEFAULT_COMP_RADIUS_MILES, help="Search radius in miles"),
    months: int = typer.Option(DEFAULT_COMP_MONTHS_BACK, help="Months back to search for sales"),
):
    """Find comparable recent sales near a property."""
    from appeal.comps import fetch_comparable_sales, apply_adjustments
    from appeal.display import display_comps_table

    subject = _lookup_property(address)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Searching for comparable sales...", total=None)
        all_comps = fetch_comparable_sales(
            subject,
            radius_miles=radius,
            months_back=months,
            status_callback=lambda msg: progress.update(task, description=msg),
        )

    if not all_comps:
        console.print("[red]No comparable sales found.[/red]")
        raise typer.Exit(1)

    all_adjusted = [apply_adjustments(c, subject) for c in all_comps]
    all_adjusted.sort(key=lambda c: c.adjusted_price_per_sqft or float("inf"))
    display_comps_table(all_adjusted)


@app.command()
def report(
    address: str = typer.Argument(..., help="Property address in San Francisco"),
    output: str = typer.Option(None, "--output", "-o", help="Output file path"),
    fmt: str = typer.Option("pdf", "--format", "-f", help="Output format: pdf or md"),
    seed: str = typer.Option(None, "--seed", "-s", help="Style randomization seed (default: parcel+date)"),
    radius: float = typer.Option(DEFAULT_COMP_RADIUS_MILES, help="Search radius in miles"),
    months: int = typer.Option(DEFAULT_COMP_MONTHS_BACK, help="Months back to search for sales"),
    num_comps: int = typer.Option(DEFAULT_NUM_COMPS, "--comps", help="Number of comps to select"),
):
    """Full analysis with generated appeal report (PDF by default)."""
    subject = _lookup_property(address)
    valuation = _fetch_and_analyze(subject, radius=radius, months=months, num_comps=num_comps)

    if fmt.lower() == "pdf":
        from appeal.report import generate_html_report, save_report_pdf

        report_obj = generate_html_report(valuation, seed=seed)
        path = save_report_pdf(report_obj, output_path=output, seed=seed)
        console.print(f"\n[green]PDF report saved to: {path}[/green]")
    elif fmt.lower() == "md":
        from appeal.report import generate_report, save_report

        report_obj = generate_report(valuation)
        path = save_report(report_obj, output_path=output)
        console.print(f"\n[green]Markdown report saved to: {path}[/green]")
    else:
        console.print(f"[red]Unknown format '{fmt}'. Use 'pdf' or 'md'.[/red]")
        raise typer.Exit(1)

    console.print(f"\n  File your appeal at: [bold cyan]{SF_ASSESSOR_PORTAL_URL}[/bold cyan]")
    console.print(f"  Block: [bold]{valuation.subject.block}[/bold]  Lot: [bold]{valuation.subject.lot}[/bold]")
    console.print("  Goto: [italic]Other Filings > Informal Assessment Review Request[/italic]")
    console.print("\n  [dim]Disclaimer: This report is for informational purposes only and does not constitute professional appraisal advice.[/dim]")


@app.command()
def config():
    """Configure API keys."""
    from pathlib import Path

    env_path = Path.home() / ".appeal" / ".env"
    console.print("[bold]API Configuration[/bold]\n")
    console.print("RentCast API key (optional, 50 free calls/month):")
    console.print("  Get one at: https://www.rentcast.io/api\n")

    key = typer.prompt("Enter RentCast API key (or press Enter to skip)", default="")
    if key:
        env_path.parent.mkdir(parents=True, exist_ok=True)
        env_path.write_text(f"RENTCAST_API_KEY={key}\n")
        console.print(f"[green]Saved to {env_path}[/green]")
    else:
        console.print("Skipped. You can set RENTCAST_API_KEY in your environment later.")


@app.command()
def info():
    """Show filing deadlines, forms, and instructions."""
    today = date.today()

    console.print("\n[bold]SF Prop 8 Property Tax Appeal Information[/bold]\n")

    console.print("[bold cyan]What is Proposition 8?[/bold cyan]")
    console.print(
        "Under California Proposition 8, if your property's current market value\n"
        "has declined below its assessed value (Prop 13 factored base year value),\n"
        "you can request a temporary reduction in your property tax assessment.\n"
    )

    console.print("[bold cyan]Filing Deadlines (2026)[/bold cyan]")
    console.print(f"  Informal Review:  January 2 - March 31, {today.year}")
    console.print(f"  Formal Appeal:    July 2 - September 15, {today.year}")
    console.print(f"  Online Portal:    https://online.sfassessor.org\n")

    console.print("[bold cyan]Informal Review (Free)[/bold cyan]")
    console.print("  File at: https://online.sfassessor.org")
    console.print("  Cost: Free")
    console.print("  What to submit: 3-5 comparable sales with adjustment grid")
    console.print("  Plus: 1-3 sentence written rationale of estimated market value\n")

    console.print("[bold cyan]Formal Appeal ($120)[/bold cyan]")
    console.print("  File at: sfgov.org/aab/online-appeal-application")
    console.print("  Form: Application for Changed Assessment (BOE-305-AH)")
    console.print("  Cost: $120 non-refundable filing fee")
    console.print("  Contact: Assessment Appeals Board, City Hall Room 405")
    console.print("  Phone: (415) 554-6778\n")

    console.print("[bold cyan]What You Need[/bold cyan]")
    console.print("  - 3-5 comparable recent sales within 15-20% of your sqft")
    console.print("  - Adjustment grid explaining differences")
    console.print("  - Written rationale (1-3 sentences) explaining market value")
    console.print("  - Property photos (helpful but not required)")
    console.print("  - This tool generates all of the above!\n")

    console.print("[bold cyan]Tips for Best Results[/bold cyan]")
    console.print("  - Comps should be the same property type (condo vs SFR)")
    console.print("  - Sales closest to January 1 carry the most weight")
    console.print("  - Note differences in parking, condition, outdoor space")
    console.print("  - The assessor values your property as of January 1\n")


if __name__ == "__main__":
    app()
