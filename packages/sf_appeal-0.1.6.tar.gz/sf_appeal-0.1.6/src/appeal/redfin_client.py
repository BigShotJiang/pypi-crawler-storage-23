"""Redfin client for comparable sales data via GIS-CSV endpoint."""

from __future__ import annotations

from typing import Optional

import csv
import io
import logging
import time
from datetime import date, datetime
import requests as req_lib
from appeal.models import ComparableSale, GeoPoint

logger = logging.getLogger(__name__)

REDFIN_BASE = "https://www.redfin.com"
BROWSER_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# Redfin region ID for San Francisco (city-level)
SF_REGION_ID = 17151
SF_REGION_TYPE = 6  # city

# Map our property type categories to Redfin uipt codes
PROPERTY_TYPE_TO_UIPT = {
    "sfr": "1",          # houses only
    "condo": "2",         # condos only
    "multi": "1,4",       # houses + multi-family
    "other": "1,2,3,4",   # all types
}


class RedfinClient:
    def __init__(self):
        self.session = req_lib.Session()
        self.session.headers.update({
            "user-agent": BROWSER_UA,
            "referer": "https://www.redfin.com/city/17151/CA/San-Francisco/recently-sold",
            "accept": "*/*",
        })
        self._initialized = False

    def _ensure_session(self):
        """Visit homepage once to get cookies."""
        if not self._initialized:
            try:
                self.session.get(REDFIN_BASE, timeout=10)
                self._initialized = True
            except Exception:
                pass

    def get_sold_homes_nearby(
        self,
        lat: float,
        lon: float,
        radius_miles: float = 0.5,
        days_back: int = 365,
        max_homes: int = 350,
        property_type: str = "other",
        max_pages: int = 3,
    ) -> list[ComparableSale]:
        """Search for recently sold homes using the GIS-CSV endpoint.

        Uses the region-based CSV download API which returns actual
        sold (closed) transactions with real sale prices, not active
        listings.

        Args:
            lat/lon: Center point for distance calculation (not used in query)
            radius_miles: Used for post-fetch distance filtering
            days_back: How many days back to search
            max_homes: Max homes per page (Redfin max is 350)
            property_type: One of 'sfr', 'condo', 'multi', 'other'
            max_pages: Max pages to fetch
        """
        self._ensure_session()

        uipt = PROPERTY_TYPE_TO_UIPT.get(property_type, "1,2,3,4")
        all_comps = []

        for page in range(1, max_pages + 1):
            params = {
                "al": 1,
                "market": "sanfrancisco",
                "region_id": SF_REGION_ID,
                "region_type": SF_REGION_TYPE,
                "status": 9,  # sold
                "num_homes": min(max_homes, 350),
                "uipt": uipt,
                "v": 8,
                "sold_within_days": days_back,
                "page_number": page,
            }

            try:
                response = self.session.get(
                    f"{REDFIN_BASE}/stingray/api/gis-csv",
                    params=params,
                    timeout=20,
                )
                response.raise_for_status()

                comps = self._parse_csv(response.text, lat, lon)
                logger.info(
                    f"Redfin CSV page {page}: {len(comps)} sold homes "
                    f"(uipt={uipt})"
                )

                if not comps:
                    break

                all_comps.extend(comps)

                # If fewer than requested, no more pages
                if len(comps) < max_homes:
                    break

                # Rate limit between pages
                if page < max_pages:
                    time.sleep(1.0)

            except Exception as e:
                logger.debug(f"Redfin CSV page {page} failed: {e}")
                break

        logger.info(f"Redfin total: {len(all_comps)} sold comps")
        return all_comps

    def _parse_csv(
        self, text: str, center_lat: float, center_lon: float
    ) -> list[ComparableSale]:
        """Parse the Redfin GIS-CSV response into ComparableSale objects.

        CSV columns:
        SALE TYPE, SOLD DATE, PROPERTY TYPE, ADDRESS, CITY, STATE,
        ZIP, PRICE, BEDS, BATHS, LOCATION, SQUARE FEET, LOT SIZE,
        YEAR BUILT, DAYS ON MARKET, $/SQUARE FEET, HOA/MONTH, STATUS,
        ..., LATITUDE, LONGITUDE
        """
        lines = text.strip().split("\n")
        if len(lines) < 3:
            return []

        # Line 0 = header, Line 1 = MLS disclaimer, Lines 2+ = data
        header = lines[0]
        data_lines = [l for l in lines[2:] if l.strip()]

        if not data_lines:
            return []

        reader = csv.DictReader(io.StringIO(header + "\n" + "\n".join(data_lines)))
        comps = []

        for row in reader:
            try:
                comp = self._row_to_comp(row)
                if comp:
                    comps.append(comp)
            except Exception as e:
                logger.debug(f"Skipping CSV row: {e}")

        return comps

    def _row_to_comp(self, row: dict) -> Optional[ComparableSale]:
        """Convert a CSV row to a ComparableSale."""
        # Only include sold properties
        status = (row.get("STATUS") or "").strip()
        if status and status != "Sold":
            return None

        # Must be in San Francisco
        city = (row.get("CITY") or "").strip()
        if city and "San Francisco" not in city:
            return None

        address = (row.get("ADDRESS") or "").strip()
        if not address:
            return None

        # Price
        price_str = (row.get("PRICE") or "").strip()
        try:
            price = float(price_str)
        except (ValueError, TypeError):
            return None
        if price <= 0:
            return None

        # Square footage
        sqft_str = (row.get("SQUARE FEET") or "").strip()
        try:
            sqft = float(sqft_str)
        except (ValueError, TypeError):
            sqft = 0
        if sqft <= 0:
            return None

        # Beds / Baths
        beds = _safe_int(row.get("BEDS"))
        baths = _safe_float(row.get("BATHS"))

        # Lot size
        lot_str = (row.get("LOT SIZE") or "").strip()
        lot_size = _safe_float(lot_str) if lot_str else None

        # Year built
        year_built = _safe_int(row.get("YEAR BUILT")) or None

        # Days on market
        dom = _safe_int(row.get("DAYS ON MARKET")) or None

        # Sold date (format: "March-20-2025" or "November-19-2025")
        sale_date = None
        sold_str = (row.get("SOLD DATE") or "").strip()
        if sold_str:
            try:
                sale_date = datetime.strptime(sold_str, "%B-%d-%Y").date()
            except ValueError:
                # Try alternate formats
                for fmt in ["%b-%d-%Y", "%m/%d/%Y", "%Y-%m-%d"]:
                    try:
                        sale_date = datetime.strptime(sold_str, fmt).date()
                        break
                    except ValueError:
                        continue

        # Skip if no sold date
        if not sale_date:
            return None

        # Geo coordinates
        geo = None
        lat_str = (row.get("LATITUDE") or "").strip()
        lon_str = (row.get("LONGITUDE") or "").strip()
        if lat_str and lon_str:
            try:
                lat = float(lat_str)
                lon = float(lon_str)
                if lat != 0 and lon != 0:
                    geo = GeoPoint(latitude=lat, longitude=lon)
            except (ValueError, TypeError):
                pass

        # Property type classification
        prop_type_str = (row.get("PROPERTY TYPE") or "").strip().lower()
        if "single family" in prop_type_str:
            prop_type = "sfr"
        elif "condo" in prop_type_str or "co-op" in prop_type_str:
            prop_type = "condo"
        elif "multi-family" in prop_type_str or "multi family" in prop_type_str:
            prop_type = "multi"
        elif "townhouse" in prop_type_str:
            prop_type = "sfr"  # townhouses treated like SFR for comp purposes
        else:
            prop_type = ""

        return ComparableSale(
            address=address,
            source="redfin",
            property_type=prop_type,
            bedrooms=beds,
            bathrooms=baths,
            property_area=sqft,
            lot_area=lot_size,
            year_built=year_built,
            sale_price=price,
            sale_date=sale_date,
            days_on_market=dom,
            geo=geo,
        )


def _safe_int(val) -> int:
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return 0


def _safe_float(val) -> float:
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0
