"""Comparable sales fetching, adjustment, and selection logic."""

from __future__ import annotations

import logging
import statistics
from datetime import date
from math import radians, sin, cos, sqrt, atan2
from appeal.models import (
    SubjectProperty,
    ComparableSale,
    Adjustment,
    AdjustmentType,
    GeoPoint,
)
from appeal.redfin_client import RedfinClient
from appeal.rentcast_client import RentCastClient
from appeal.datasf import DataSFClient
from appeal.address import format_datasf_address
from appeal.config import DEFAULT_SQFT_TOLERANCE

logger = logging.getLogger(__name__)

# Adjustment rates ($/sqft per unit of difference)
ADJ_BEDROOM = 15.0
ADJ_BATHROOM = 10.0
ADJ_SIZE_PCT_THRESHOLD = 0.15  # Blog: 15-20% size difference triggers adjustment
ADJ_SIZE_PER_PCT = 0.5
ADJ_AGE_PER_DECADE = 5.0
ADJ_LOT_PER_1000SQFT = 3.0
ADJ_PARKING = 10.0  # $/sqft per parking space difference
ADJ_CONDITION = 20.0  # $/sqft for major renovation differences


def fetch_comparable_sales(
    subject: SubjectProperty,
    radius_miles: float = 0.5,
    months_back: int = 12,
    status_callback=None,
) -> list[ComparableSale]:
    """Fetch comps from all available sources and deduplicate.

    Sources tried in order: Redfin -> RentCast -> DataSF heuristic.
    """
    all_comps: list[ComparableSale] = []

    def _status(msg: str):
        if status_callback:
            status_callback(msg)

    # Determine subject property type for targeted Redfin search
    subject_type = _property_type_category(subject.use_code, subject.use_definition)

    # Source 1: Redfin GIS (sold homes in bounding box)
    if subject.geo:
        _status("Searching Redfin for recent sales...")
        try:
            redfin = RedfinClient()
            redfin_comps = redfin.get_sold_homes_nearby(
                lat=subject.geo.latitude,
                lon=subject.geo.longitude,
                radius_miles=radius_miles,
                days_back=months_back * 30,
                max_homes=350,
                property_type=subject_type,
            )
            logger.info(f"Redfin returned {len(redfin_comps)} comps (type={subject_type})")
            all_comps.extend(redfin_comps)
        except Exception as e:
            logger.debug(f"Redfin failed: {e}")

    # Source 2: RentCast (if Redfin returned < 5)
    if len(all_comps) < 5:
        _status("Searching RentCast for additional sales...")
        try:
            rentcast = RentCastClient()
            rc_comps = rentcast.get_comparable_sales(
                subject.address + ", San Francisco, CA",
                comp_count=15,
                max_radius=radius_miles,
                days_old=months_back * 30,
            )
            logger.info(f"RentCast returned {len(rc_comps)} comps")
            all_comps.extend(rc_comps)
        except Exception as e:
            logger.warning(f"RentCast failed: {e}")

    # Source 3: DataSF heuristic (always run to supplement with nearby data)
    if subject.geo:
        _status("Analyzing assessor records for recent sales...")
        try:
            datasf_comps = _fetch_from_datasf_heuristic(subject, radius_miles)
            logger.info(f"DataSF heuristic found {len(datasf_comps)} likely sales")
            all_comps.extend(datasf_comps)
        except Exception as e:
            logger.warning(f"DataSF heuristic failed: {e}")

    # Calculate distance from subject for all comps
    if subject.geo:
        for comp in all_comps:
            if comp.geo and comp.distance_miles is None:
                comp.distance_miles = haversine_distance(
                    subject.geo.latitude,
                    subject.geo.longitude,
                    comp.geo.latitude,
                    comp.geo.longitude,
                )

    # Deduplicate
    all_comps = _deduplicate(all_comps)

    # Filter by distance, property type, and reasonable parameters
    # Allow up to 2 miles to get enough comps in dense SF neighborhoods
    all_comps = _filter_comps(all_comps, subject, max_distance_miles=max(radius_miles * 3, 2.0))

    return all_comps


def _fetch_from_datasf_heuristic(
    subject: SubjectProperty, radius_miles: float
) -> list[ComparableSale]:
    """Detect likely recent sales via year-over-year assessment jumps.

    Under Prop 13, assessed values increase max 2%/year. A jump >10%
    strongly indicates a sale (property reassessed to purchase price).
    """
    if not subject.geo:
        return []

    client = DataSFClient()
    radius_meters = int(radius_miles * 1609.34)

    try:
        nearby = client.find_nearby_properties(
            subject.geo.latitude,
            subject.geo.longitude,
            radius_meters=radius_meters,
            use_code=subject.use_code or None,
        )
    finally:
        client.close()

    # Group by parcel number
    by_parcel: dict[str, list[dict]] = {}
    for record in nearby:
        pn = record.get("parcel_number", "")
        if pn:
            by_parcel.setdefault(pn, []).append(record)

    comps = []
    for parcel, records in by_parcel.items():
        if parcel == subject.parcel_number:
            continue

        records.sort(key=lambda r: r.get("closed_roll_year", ""), reverse=True)
        if len(records) < 2:
            continue

        current = records[0]
        previous = records[1]

        curr_total = _fval(current, "assessed_land_value") + _fval(
            current, "assessed_improvement_value"
        )
        prev_total = _fval(previous, "assessed_land_value") + _fval(
            previous, "assessed_improvement_value"
        )

        if prev_total <= 0 or curr_total <= 0:
            continue

        pct_change = (curr_total - prev_total) / prev_total

        # Jump >10% likely indicates a sale
        if pct_change > 0.10:
            area = _fval(current, "property_area")
            if area <= 0:
                continue

            geo = None
            if current.get("the_geom"):
                try:
                    coords = current["the_geom"]["coordinates"]
                    geo = GeoPoint(latitude=coords[1], longitude=coords[0])
                except (KeyError, IndexError, TypeError):
                    pass

            roll_year = int(current.get("closed_roll_year", 0))

            # Determine property type from DataSF use code
            ds_use_code = current.get("use_code", "")
            ds_use_def = current.get("use_definition", "")
            ds_prop_type = _property_type_category(ds_use_code, ds_use_def)

            comps.append(
                ComparableSale(
                    address=format_datasf_address(
                        current.get("property_location", "")
                    ),
                    parcel_number=parcel,
                    geo=geo,
                    source="datasf",
                    property_type=ds_prop_type if ds_prop_type != "other" else "",
                    bedrooms=int(_fval(current, "number_of_bedrooms")),
                    bathrooms=_fval(current, "number_of_bathrooms"),
                    property_area=area,
                    lot_area=_fval(current, "lot_area") or None,
                    year_built=int(_fval(current, "year_property_built")) or None,
                    sale_price=curr_total,
                    sale_date=date(roll_year, 1, 1) if roll_year else None,
                    distance_miles=None,
                )
            )

    return comps


def calculate_adjustments(
    subject: SubjectProperty, comp: ComparableSale
) -> list[Adjustment]:
    """Calculate $/sqft adjustments for differences between subject and comp.

    Convention: if comp is SUPERIOR, apply NEGATIVE adjustment (our property
    is worth less than this comp). If comp is INFERIOR, apply POSITIVE.
    """
    adjustments = []

    # Bedrooms
    bed_diff = comp.bedrooms - subject.bedrooms
    if bed_diff != 0:
        adjustments.append(
            Adjustment(
                type=AdjustmentType.BEDROOMS,
                description=f"Comp has {bed_diff:+d} bedroom(s)",
                amount_per_sqft=-bed_diff * ADJ_BEDROOM,
            )
        )

    # Bathrooms
    bath_diff = comp.bathrooms - subject.bathrooms
    if abs(bath_diff) >= 0.5:
        adjustments.append(
            Adjustment(
                type=AdjustmentType.BATHROOMS,
                description=f"Comp has {bath_diff:+.1f} bathroom(s)",
                amount_per_sqft=-bath_diff * ADJ_BATHROOM,
            )
        )

    # Size (living area)
    if subject.property_area > 0 and comp.property_area > 0:
        size_diff_pct = (comp.property_area - subject.property_area) / subject.property_area
        if abs(size_diff_pct) > ADJ_SIZE_PCT_THRESHOLD:
            adjustments.append(
                Adjustment(
                    type=AdjustmentType.SIZE,
                    description=(
                        f"Comp is {size_diff_pct:+.0%} in size "
                        f"({comp.property_area:,.0f} vs {subject.property_area:,.0f} sqft)"
                    ),
                    amount_per_sqft=-(size_diff_pct * 100) * ADJ_SIZE_PER_PCT,
                )
            )

    # Age
    if comp.year_built and subject.year_built:
        age_diff_decades = (subject.year_built - comp.year_built) / 10
        if abs(age_diff_decades) > 0.5:
            adjustments.append(
                Adjustment(
                    type=AdjustmentType.AGE,
                    description=(
                        f"Comp built {comp.year_built} vs subject {subject.year_built}"
                    ),
                    amount_per_sqft=age_diff_decades * ADJ_AGE_PER_DECADE,
                )
            )

    # Lot size
    if comp.lot_area and subject.lot_area:
        lot_diff_1000 = (comp.lot_area - subject.lot_area) / 1000
        if abs(lot_diff_1000) > 0.5:
            adjustments.append(
                Adjustment(
                    type=AdjustmentType.LOT_SIZE,
                    description=(
                        f"Comp lot {comp.lot_area:,.0f} vs subject {subject.lot_area:,.0f} sqft"
                    ),
                    amount_per_sqft=-lot_diff_1000 * ADJ_LOT_PER_1000SQFT,
                )
            )

    # Note: Parking, condition/renovations, and outdoor space adjustments
    # are supported by the model (AdjustmentType.PARKING, CONDITION,
    # OUTDOOR_SPACE) but require data that isn't reliably available from
    # our automated data sources. When filing an appeal, homeowners should
    # manually note these differences in their written rationale if applicable.

    return adjustments


def apply_adjustments(
    comp: ComparableSale, subject: SubjectProperty
) -> ComparableSale:
    """Calculate and apply adjustments, setting adjusted $/sqft."""
    if comp.property_area > 0:
        comp.raw_price_per_sqft = comp.sale_price / comp.property_area
    else:
        comp.raw_price_per_sqft = 0

    comp.adjustments = calculate_adjustments(subject, comp)
    total_adj = sum(a.amount_per_sqft for a in comp.adjustments)
    comp.adjusted_price_per_sqft = comp.raw_price_per_sqft + total_adj
    return comp


def select_best_comps(
    comps: list[ComparableSale],
    subject: SubjectProperty,
    n: int = 5,
) -> list[ComparableSale]:
    """Select the N best comps: radiate outward, picking cheapest stat matches.

    Strategy (radiate-out, then fill):
    1. Radiate outward from subject in distance rings:
       0-0.25 mi → 0.25-0.5 mi → 0.5-1.0 mi → 1.0-2.0 mi → 2.0+ mi
    2. From each ring, pick the single cheapest stat-matched comp.
       This scans outward to find low-price pockets in nearby areas.
    3. Fill remaining slots (up to N) from the global pool, ranked by
       cheapest price + closest stats — so we always end up with the
       best appeal-worthy comps regardless of distance.

    Result: geographic diversity from ring picks + globally cheapest comps.
    """
    adjusted = [apply_adjustments(c, subject) for c in comps]
    valid = [
        c
        for c in adjusted
        if c.adjusted_price_per_sqft and c.adjusted_price_per_sqft > 0
    ]

    if not valid:
        return []

    subject_type = _property_type_category(subject.use_code, subject.use_definition)

    # ── Pass 1: Radiate outward, take 1 cheapest stat-matched comp per ring ──
    RINGS = [0.25, 0.5, 1.0, 2.0, float("inf")]
    selected: list[ComparableSale] = []
    selected_addrs: set[str] = set()

    for ring_max in RINGS:
        ring_min = 0.0 if ring_max == RINGS[0] else RINGS[RINGS.index(ring_max) - 1]

        # Get comps in this distance ring
        ring_comps = []
        for c in valid:
            dist = c.distance_miles if c.distance_miles is not None else 0.0
            if ring_min <= dist < ring_max and c.address not in selected_addrs:
                ring_comps.append(c)

        if not ring_comps:
            continue

        # Score and pick the single best (cheapest + closest stats) from this ring
        best_comp = min(
            ring_comps,
            key=lambda c: _score_comp_stats_price(c, subject, subject_type),
        )
        selected.append(best_comp)
        selected_addrs.add(best_comp.address)

    # ── Pass 2: Fill remaining slots from global cheapest stat-matched comps ──
    if len(selected) < n:
        remaining = [c for c in valid if c.address not in selected_addrs]

        # Score all remaining comps (stats + price, cheapest wins)
        scored = [
            (_score_comp_stats_price(c, subject, subject_type), c)
            for c in remaining
        ]
        scored.sort(key=lambda x: (x[0], x[1].adjusted_price_per_sqft))

        for _, c in scored:
            if len(selected) >= n:
                break
            selected.append(c)
            selected_addrs.add(c.address)

    # Sort final selection by adjusted $/sqft for display
    selected.sort(key=lambda c: c.adjusted_price_per_sqft)

    return selected[:n]


def _score_comp_stats_price(
    comp: ComparableSale, subject: SubjectProperty, subject_type: str
) -> float:
    """Score a comp for appeal suitability (lower = better).

    Goal: find comps that are the closest match by physical stats but
    the furthest below assessed value in price — the ideal appeal comp.

    Distance is handled by the ring logic in select_best_comps, so this
    function only scores stats similarity + price.

    Stats similarity (0-55 points):
    - Square footage match (0-30)
    - Bedroom match (0-15)
    - Bathroom match (0-10)

    Price bias (dominant):
    - Adjusted $/sqft / 15 — aggressively favors cheaper comps.
      Among comps with identical stats, the cheapest always wins.

    Sale date proximity to Jan 1 (0-10 points) as tiebreaker.
    """
    score = 0.0

    # ── Stats similarity (0-55 points total) ──

    # Square footage match (0-30 points)
    if subject.property_area > 0 and comp.property_area > 0:
        size_diff_pct = abs(comp.property_area - subject.property_area) / subject.property_area
        if size_diff_pct <= 0.10:
            score += 0  # Near-identical size
        elif size_diff_pct <= 0.15:
            score += 3  # Blog ideal range
        elif size_diff_pct <= 0.20:
            score += 8
        elif size_diff_pct <= 0.30:
            score += 18
        else:
            score += 30

    # Bedroom match (0-15 points)
    bed_diff = abs(comp.bedrooms - subject.bedrooms)
    if bed_diff == 0:
        score += 0  # Exact match
    elif bed_diff == 1:
        score += 5
    elif bed_diff == 2:
        score += 10
    else:
        score += 15

    # Bathroom match (0-10 points)
    bath_diff = abs(comp.bathrooms - subject.bathrooms)
    if bath_diff <= 0.5:
        score += 0  # Close enough
    elif bath_diff <= 1.0:
        score += 3
    elif bath_diff <= 2.0:
        score += 7
    else:
        score += 10

    # Property type match (0 or 25 points)
    # Even if the filter didn't catch it (e.g., unknown type), penalize mismatches
    if comp.property_type and subject_type and subject_type != "other":
        if comp.property_type != subject_type:
            score += 25  # Strong penalty: wrong property type

    # ── Price bias (dominant: aggressively favors cheapest comps) ──
    # The whole point is to find comps that LOWER the assessed value.
    # Among stat-matched comps, the cheapest one is always best.
    if comp.adjusted_price_per_sqft:
        # $1000/sqft → +67 pts, $1500/sqft → +100 pts
        # A $500/sqft gap between comps ≈ 33 point swing — enough to
        # override minor stat differences (a perfect stats match with
        # bed/bath/sqft only saves ~15 points max)
        score += comp.adjusted_price_per_sqft / 15

    # ── Sale date proximity to Jan 1 (tiebreaker: 0-10 points) ──
    if comp.sale_date:
        jan1 = date(comp.sale_date.year, 1, 1)
        days_from_jan1 = abs((comp.sale_date - jan1).days)
        next_jan1 = date(comp.sale_date.year + 1, 1, 1)
        days_from_next = abs((comp.sale_date - next_jan1).days)
        days_from_valuation = min(days_from_jan1, days_from_next)

        if days_from_valuation <= 90:
            score += 0
        elif days_from_valuation <= 180:
            score += 5
        else:
            score += 10

    return score


def _deduplicate(comps: list[ComparableSale]) -> list[ComparableSale]:
    """Remove duplicate comps by normalized address."""
    seen: set[str] = set()
    unique = []
    for c in comps:
        key = c.address.upper().strip().replace(",", "").replace(".", "")
        # Simplify to just numbers + street name for dedup
        parts = key.split()
        if len(parts) >= 2:
            key = f"{parts[0]}_{parts[1]}"
        if key not in seen:
            seen.add(key)
            unique.append(c)
    return unique


def _filter_comps(
    comps: list[ComparableSale],
    subject: SubjectProperty,
    max_distance_miles: float = 1.5,
    sqft_tolerance: float = DEFAULT_SQFT_TOLERANCE,
    max_age_years: int = 3,
) -> list[ComparableSale]:
    """Filter out clearly incompatible comps per blog methodology.

    Blog criteria:
    - Same property type (SFR with SFR, condo with condo, TIC with TIC)
    - Within 15-20% of subject's square footage
    - Within the neighborhood (not separated by freeways, etc.)
    - Sales ideally within 90 days of Jan 1 (handled by scoring, not hard filter)
    - Sales within last few years (hard cutoff)
    """
    cutoff_date = date(date.today().year - max_age_years, 1, 1)
    subject_type = _property_type_category(subject.use_code, subject.use_definition)

    filtered = []
    for c in comps:
        # Must have positive sqft and price
        if c.property_area <= 0 or c.sale_price <= 0:
            continue

        # Property type filter: must match (SFR with SFR, condo with condo, etc.)
        # Skip filter if either side has unknown type
        if c.property_type and subject_type and subject_type != "other":
            if c.property_type != subject_type:
                continue

        # Date filter: reject very old sales
        if c.sale_date and c.sale_date < cutoff_date:
            continue

        # Size within tolerance (blog: 15-20%) — use relaxed outer bound for initial filter
        # The tighter tolerance is used for scoring/ranking in select_best_comps
        if subject.property_area > 0:
            ratio = c.property_area / subject.property_area
            outer_tolerance = sqft_tolerance * 2  # Allow 2x tolerance for initial pool
            if ratio < (1 - outer_tolerance) or ratio > (1 + outer_tolerance):
                continue

        # Value filter: only include comps BELOW assessed value (we're appealing
        # to lower taxes), but no more than 75% reduction (floor at 25%)
        assessed = subject.assessed_land_value + subject.assessed_improvement_value
        if assessed > 0 and c.sale_price > 0:
            ratio = c.sale_price / assessed
            if ratio > 1.0:
                continue  # Comp sold above our assessed value — hurts the appeal
            if ratio < 0.25:
                continue  # Too cheap to be a credible comp

        # Distance filter (Redfin GIS returns city-wide results)
        if c.distance_miles is not None and c.distance_miles > max_distance_miles:
            continue

        filtered.append(c)
    return filtered


def _property_type_category(use_code: str, use_definition: str = "") -> str:
    """Categorize property type for comp matching.

    Returns: 'condo', 'sfr', 'multi', or 'other'

    Important: TICs and condos are grouped together as 'condo' because they
    are comparable ownership types. SFR includes townhouses.

    Data sources:
    - DataSF: SRES (single family), MRES (multi-family).
      DataSF lumps condos under SRES, so we use use_definition hints.
    - Redfin CSV: 'Single Family Residential', 'Condo/Co-op',
      'Multi-Family (2-4 Unit)', 'Multi-Family (5+ Unit)' —
      parsed directly in redfin_client.py.
    """
    code = (use_code or "").upper().strip()
    defn = (use_definition or "").upper()

    # Condo / TIC / coop — all grouped together
    if any(x in defn for x in [
        "CONDO", "CONDOMINIUM", "TIC", "TENANCY IN COMMON",
        "COOPERATIVE", "CO-OP", "COOP",
    ]):
        return "condo"
    if code in ("C", "CC", "CL", "T"):
        return "condo"

    # Multi-unit (2-4+ units) — check before SFR since MRES is specific
    if any(x in defn for x in [
        "2 FAMILY", "3 FAMILY", "4 FAMILY", "5 FAMILY",
        "DUPLEX", "TRIPLEX", "QUADPLEX",
    ]):
        return "multi"
    if code in ("MRES", "2", "3", "4", "F"):
        return "multi"
    if "MULTI" in defn:
        return "multi"

    # Single family (includes townhouses)
    if any(x in defn for x in ["SINGLE FAMILY", "1 FAMILY", "ONE FAMILY", "SFR", "TOWNHOUSE"]):
        return "sfr"
    if code in ("SRES", "D", "DW"):
        return "sfr"

    return "other"


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance in miles between two lat/lon points."""
    R = 3959  # Earth radius in miles
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c


def _fval(record: dict, key: str) -> float:
    """Safely extract float from a dict."""
    try:
        return float(record.get(key, 0) or 0)
    except (ValueError, TypeError):
        return 0.0
