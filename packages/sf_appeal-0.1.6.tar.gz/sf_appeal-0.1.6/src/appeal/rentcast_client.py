"""RentCast API client for comparable sales data (50 free calls/month)."""

from __future__ import annotations

from typing import Optional

import httpx
import logging
from datetime import date, datetime
from appeal.models import ComparableSale, GeoPoint
from appeal.config import get_rentcast_api_key

logger = logging.getLogger(__name__)

BASE_URL = "https://api.rentcast.io/v1"


class RentCastClient:
    def __init__(self):
        self.api_key = get_rentcast_api_key()

    @property
    def is_available(self) -> bool:
        return self.api_key is not None

    def get_comparable_sales(
        self,
        address: str,
        comp_count: int = 15,
        max_radius: float = 1.0,
        days_old: int = 365,
    ) -> list[ComparableSale]:
        """Get comparable sales from RentCast AVM endpoint."""
        if not self.is_available:
            logger.info("RentCast API key not configured, skipping")
            return []

        try:
            response = httpx.get(
                f"{BASE_URL}/avm/value",
                params={
                    "address": address,
                    "compCount": comp_count,
                    "maxRadius": max_radius,
                    "daysOld": days_old,
                },
                headers={"X-Api-Key": self.api_key},
                timeout=30,
            )
            response.raise_for_status()
            data = response.json()
            return self._parse_comps(data.get("comparables", []))
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:
                logger.warning("RentCast rate limit reached (50/month)")
            else:
                logger.warning(f"RentCast API error: {e.response.status_code}")
            return []
        except Exception as e:
            logger.warning(f"RentCast request failed: {e}")
            return []

    def _parse_comps(self, raw_comps: list[dict]) -> list[ComparableSale]:
        """Parse RentCast comparables into ComparableSale models."""
        comps = []
        for c in raw_comps:
            try:
                geo = None
                if c.get("latitude") and c.get("longitude"):
                    geo = GeoPoint(latitude=c["latitude"], longitude=c["longitude"])

                sale_date = None
                for date_field in ("lastSaleDate", "removedDate", "listedDate"):
                    if c.get(date_field):
                        sale_date = _parse_date(c[date_field])
                        if sale_date:
                            break

                sqft = c.get("squareFootage", 0) or 0
                price = c.get("price", 0) or c.get("lastSalePrice", 0) or 0

                if sqft <= 0 or price <= 0:
                    continue

                comps.append(
                    ComparableSale(
                        address=c.get("formattedAddress", "Unknown"),
                        source="rentcast",
                        bedrooms=c.get("bedrooms", 0) or 0,
                        bathrooms=c.get("bathrooms", 0) or 0,
                        property_area=sqft,
                        lot_area=c.get("lotSize"),
                        year_built=c.get("yearBuilt"),
                        sale_price=price,
                        sale_date=sale_date or date.today(),
                        distance_miles=c.get("distance"),
                        geo=geo,
                    )
                )
            except Exception as e:
                logger.debug(f"Skipping RentCast comp: {e}")
        return comps


def _parse_date(date_str: str) -> Optional[date]:
    """Parse a date string from RentCast."""
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(date_str.split(".")[0], fmt).date()
        except (ValueError, AttributeError):
            continue
    return None
