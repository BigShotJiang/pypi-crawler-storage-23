"""Data models for the property tax appeal tool."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field, computed_field
from datetime import date, datetime
from enum import Enum


class GeoPoint(BaseModel):
    latitude: float
    longitude: float


class SubjectProperty(BaseModel):
    """The user's property being appealed."""

    address: str
    parcel_number: str
    block: str
    lot: str
    geo: Optional[GeoPoint] = None

    # Physical characteristics
    bedrooms: int = 0
    bathrooms: float = 0
    property_area: float = 0  # living area sqft
    lot_area: float = 0
    year_built: int = 0
    stories: float = 0
    units: int = 1
    use_code: str = ""
    use_definition: str = ""
    construction_type: str = ""

    # Assessment data
    roll_year: str = ""
    assessed_land_value: float = 0
    assessed_improvement_value: float = 0
    assessor_neighborhood: str = ""
    analysis_neighborhood: str = ""

    @computed_field
    @property
    def total_assessed_value(self) -> float:
        return self.assessed_land_value + self.assessed_improvement_value

    @computed_field
    @property
    def assessed_price_per_sqft(self) -> Optional[float]:
        if self.property_area and self.property_area > 0:
            return self.total_assessed_value / self.property_area
        return None


class AdjustmentType(str, Enum):
    BEDROOMS = "bedrooms"
    BATHROOMS = "bathrooms"
    SIZE = "size"
    LOT_SIZE = "lot_size"
    AGE = "age"
    PARKING = "parking"
    CONDITION = "condition"
    OUTDOOR_SPACE = "outdoor_space"


class Adjustment(BaseModel):
    """A single $/sqft adjustment applied to a comparable."""

    type: AdjustmentType
    description: str
    amount_per_sqft: float


class ComparableSale(BaseModel):
    """A comparable property that recently sold."""

    address: str
    parcel_number: Optional[str] = None
    geo: Optional[GeoPoint] = None
    source: str  # "redfin", "rentcast", or "datasf"
    property_type: str = ""  # "sfr", "condo", "multi", or "" if unknown

    # Physical characteristics
    bedrooms: int = 0
    bathrooms: float = 0
    property_area: float = 0  # living area sqft
    lot_area: Optional[float] = None
    year_built: Optional[int] = None
    stories: Optional[float] = None

    # Sale data
    sale_price: float = 0
    sale_date: Optional[date] = None
    days_on_market: Optional[int] = None
    distance_miles: Optional[float] = None

    # Calculated fields (populated by comps.py)
    raw_price_per_sqft: Optional[float] = None
    adjustments: List[Adjustment] = Field(default_factory=list)
    adjusted_price_per_sqft: Optional[float] = None


class ValuationResult(BaseModel):
    """Final valuation output."""

    subject: SubjectProperty
    all_comps: List[ComparableSale]
    selected_comps: List[ComparableSale]

    median_adjusted_price_per_sqft: float
    estimated_market_value: float
    assessed_value: float
    potential_savings_annual: Optional[float] = None
    potential_savings_pct: Optional[float] = None
    appeal_recommended: bool

    valuation_date: date
    methodology_notes: str = ""
    rationale_summary: str = ""  # 1-3 sentence written summary for the appeal


class AppealReport(BaseModel):
    """Complete appeal package."""

    valuation: ValuationResult
    generated_at: datetime
    filing_deadline: date
    filing_type: str  # "informal" or "formal"
    assessor_contact: str
    report_markdown: str = ""
    report_html: str = ""
