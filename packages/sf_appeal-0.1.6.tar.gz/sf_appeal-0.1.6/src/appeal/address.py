"""Address parsing and normalization for SF properties."""

from __future__ import annotations

from typing import Optional

import re

# DataSF street type abbreviations
STREET_TYPES = {
    "STREET": "ST",
    "AVENUE": "AV",
    "BOULEVARD": "BL",
    "DRIVE": "DR",
    "LANE": "LN",
    "COURT": "CT",
    "PLACE": "PL",
    "TERRACE": "TR",
    "WAY": "WY",
    "CIRCLE": "CR",
    "ROAD": "RD",
    "HIGHWAY": "HY",
    "ALLEY": "AL",
    "PLAZA": "PZ",
    "PATH": "PA",
    "WALK": "WK",
    "ST": "ST",
    "AVE": "AV",
    "AV": "AV",
    "BLVD": "BL",
    "BL": "BL",
    "DR": "DR",
    "LN": "LN",
    "CT": "CT",
    "PL": "PL",
    "TR": "TR",
    "WY": "WY",
    "CR": "CR",
    "RD": "RD",
}


def parse_user_address(raw: str) -> dict:
    """Parse a user-entered SF address into components.

    Examples:
        "320 Cornwall St" -> {"number": "320", "street": "CORNWALL", "type": "ST"}
        "275 Arguello Blvd, San Francisco, CA" -> {"number": "275", "street": "ARGUELLO", "type": "BL"}
    """
    # Strip city/state/zip
    cleaned = re.split(r",\s*(?:San Francisco|SF)", raw, flags=re.IGNORECASE)[0].strip()
    cleaned = cleaned.upper()

    # Extract street number
    match = re.match(r"^(\d+)\s+(.+)$", cleaned)
    if not match:
        return {"number": "", "street": cleaned, "type": "", "raw": raw}

    number = match.group(1)
    rest = match.group(2).strip()

    # Split off street type from the end
    parts = rest.split()
    street_type = ""
    street_name = rest

    if len(parts) >= 2:
        last = parts[-1]
        if last in STREET_TYPES:
            street_type = STREET_TYPES[last]
            street_name = " ".join(parts[:-1])
        elif last in STREET_TYPES.values():
            street_type = last
            street_name = " ".join(parts[:-1])

    # Handle unit/apt suffixes
    street_name = re.sub(r"\s*(#|APT|UNIT|STE)\s*\S*$", "", street_name)

    return {
        "number": number,
        "street": street_name,
        "type": street_type,
        "raw": raw,
    }


def parse_datasf_location(location: str) -> dict:
    """Parse DataSF's property_location format.

    Actual format observed:
        '0000 0320 CORNWALL            ST0000'
        '0327 0325 CORNWALL            ST0000'
        '0000 1250 JONES               ST1101'
        '1140 1138 TAYLOR              ST0000'

    Structure:
        - Chars 0-3: secondary/alternate address number (0000 = none)
        - Space
        - Chars 5-8: primary street number (leading zeros)
        - Space
        - Street name (space-padded to fixed width)
        - Street type (2 chars, e.g. ST, AV, BL)
        - Unit number (4 chars, 0000 = no unit)
    """
    if not location:
        return {"number": "", "alt_number": "", "street": "", "type": "", "unit": ""}

    loc = location.strip()

    # Use regex to match the known pattern:
    # (4 digits) (4 digits) (street name + spaces)(2-letter type)(4-digit unit)
    m = re.match(
        r"^(\d{4})\s+(\d{4})\s+(.+?)\s+((?:ST|AV|BL|DR|LN|CT|PL|TR|WY|CR|RD|HY|AL|PZ|PA|WK))(\d{4})$",
        loc,
    )
    if m:
        alt = str(int(m.group(1)))  # strip leading zeros
        number = str(int(m.group(2)))
        street = m.group(3).strip()
        street_type = m.group(4)
        unit = m.group(5)
        # If alt is "0", there's no alternate number
        if alt == "0":
            alt = ""
        return {
            "number": number,
            "alt_number": alt,
            "street": street,
            "type": street_type,
            "unit": unit,
        }

    # Fallback: try simpler parsing
    # Extract unit (last 4 digits)
    unit_match = re.search(r"(\d{4})$", loc)
    unit = unit_match.group(1) if unit_match else "0000"
    if unit_match:
        loc = loc[: unit_match.start()]

    # Extract street type (2-letter code at the end)
    type_match = re.search(r"\s*([A-Z]{2})$", loc)
    street_type = type_match.group(1) if type_match else ""
    if type_match:
        loc = loc[: type_match.start()]

    loc = loc.strip()

    # Try to extract two leading numbers
    two_nums = re.match(r"^(\d+)\s+(\d+)\s+(.*)$", loc)
    if two_nums:
        alt = str(int(two_nums.group(1)))
        number = str(int(two_nums.group(2)))
        street = two_nums.group(3).strip()
        if alt == "0":
            alt = ""
        return {
            "number": number,
            "alt_number": alt,
            "street": street,
            "type": street_type,
            "unit": unit,
        }

    # Single number
    one_num = re.match(r"^(\d+)\s+(.*)$", loc)
    if one_num:
        return {
            "number": str(int(one_num.group(1))),
            "alt_number": "",
            "street": one_num.group(2).strip(),
            "type": street_type,
            "unit": unit,
        }

    return {"number": "", "alt_number": "", "street": loc, "type": street_type, "unit": unit}


def format_datasf_address(location: str) -> str:
    """Convert DataSF property_location to a human-readable address."""
    parsed = parse_datasf_location(location)
    parts = []
    if parsed["number"]:
        parts.append(parsed["number"])
    if parsed["street"]:
        parts.append(parsed["street"])
    if parsed["type"]:
        parts.append(parsed["type"])

    addr = " ".join(parts)

    if parsed.get("unit") and parsed["unit"] != "0000":
        addr += f" #{int(parsed['unit'])}"

    return addr.title()


def match_address(user_addr: dict, datasf_records: list[dict]) -> Optional[dict]:
    """Find the best matching DataSF record for a user's parsed address."""
    user_num = user_addr.get("number", "")
    user_street = user_addr.get("street", "").upper()

    best = None
    for record in datasf_records:
        loc = record.get("property_location", "")
        parsed = parse_datasf_location(loc)

        # Match street number (against primary number)
        if parsed["number"] != user_num:
            continue

        # Match street name
        if user_street and user_street in parsed["street"]:
            # Prefer unit 0000 (main property) over units
            if parsed.get("unit", "0000") == "0000":
                return record
            if best is None:
                best = record
        elif parsed["street"] and parsed["street"] in user_street:
            if parsed.get("unit", "0000") == "0000":
                return record
            if best is None:
                best = record

    return best
