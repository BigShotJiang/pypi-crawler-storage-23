"""Configuration and constants."""

from __future__ import annotations

from typing import Optional

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
load_dotenv(Path.home() / ".appeal" / ".env")


def get_rentcast_api_key() -> Optional[str]:
    return os.getenv("RENTCAST_API_KEY")


# SF effective property tax rate (~1.2% for 2025-2026)
SF_TAX_RATE = 0.012

# Comp search defaults (blog: 15-20% sqft, 90-day window preferred, 6 months max)
DEFAULT_COMP_RADIUS_MILES = 0.5
DEFAULT_COMP_MONTHS_BACK = 12  # search 12 months, scoring prefers recent sales near Jan 1
DEFAULT_NUM_COMPS = 5  # select 3-5 comps per blog guidance
DEFAULT_SQFT_TOLERANCE = 0.20  # 20% size tolerance for comps

# Assessment valuation date — values are assessed as of January 1
ASSESSMENT_VALUATION_MONTH_DAY = (1, 1)

# DataSF
DATASF_BASE_URL = "https://data.sfgov.org/resource/wv5m-vpq2.json"
# Try latest roll years in order (data lags by ~1 year)
DATASF_ROLL_YEARS = ["2025", "2024", "2023"]

# Online filing portal
SF_ASSESSOR_PORTAL_URL = "https://online.sfassessor.org"

# Redfin rate limit
REDFIN_RATE_LIMIT_DELAY = 1.0
