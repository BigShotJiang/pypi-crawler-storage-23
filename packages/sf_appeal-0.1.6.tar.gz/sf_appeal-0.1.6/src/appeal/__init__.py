"""SF Prop 8 Property Tax Appeal Tool."""

__version__ = "0.1.0"
