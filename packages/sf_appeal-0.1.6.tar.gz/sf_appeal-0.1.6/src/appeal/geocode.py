"""Address geocoding using free services."""

from __future__ import annotations

from typing import Optional, Tuple

import httpx
import logging

logger = logging.getLogger(__name__)


def geocode_address(address: str) -> Optional[Tuple[float, float]]:
    """Geocode an address to (lat, lon).

    Tries US Census Geocoder first, then Nominatim as fallback.
    """
    # Ensure "San Francisco" is in the address for better results
    if "san francisco" not in address.lower() and "sf" not in address.lower():
        address = f"{address}, San Francisco, CA"

    result = _census_geocode(address)
    if result:
        return result
    return _nominatim_geocode(address)


def _census_geocode(address: str) -> Optional[Tuple[float, float]]:
    """US Census Bureau geocoder (free, no key)."""
    try:
        response = httpx.get(
            "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress",
            params={
                "address": address,
                "benchmark": "Public_AR_Current",
                "format": "json",
            },
            timeout=15,
        )
        response.raise_for_status()
        data = response.json()
        matches = data.get("result", {}).get("addressMatches", [])
        if matches:
            coords = matches[0]["coordinates"]
            return (coords["y"], coords["x"])  # lat, lon
    except Exception as e:
        logger.debug(f"Census geocoder failed: {e}")
    return None


def _nominatim_geocode(address: str) -> Optional[Tuple[float, float]]:
    """OpenStreetMap Nominatim geocoder (free, no key)."""
    try:
        response = httpx.get(
            "https://nominatim.openstreetmap.org/search",
            params={
                "q": address,
                "format": "json",
                "limit": 1,
            },
            headers={"User-Agent": "sf-tax-appeal-tool/0.1"},
            timeout=15,
        )
        response.raise_for_status()
        results = response.json()
        if results:
            return (float(results[0]["lat"]), float(results[0]["lon"]))
    except Exception as e:
        logger.debug(f"Nominatim geocoder failed: {e}")
    return None
