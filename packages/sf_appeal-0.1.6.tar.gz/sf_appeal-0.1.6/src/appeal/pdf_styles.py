"""Randomized PDF styling for appeal reports.

Uses a deterministic seed so the same seed always produces the same
visual style, but different seeds produce noticeably different reports.
Without a seed, each run generates a unique look.
"""

from __future__ import annotations

import hashlib
import random
import uuid
from dataclasses import dataclass, asdict
from datetime import date


# ── Font pools ──

# ── 10 body font stacks (cross-platform: Mac, Windows, Linux fallbacks) ──
BODY_FONTS = [
    "'Georgia', 'Noto Serif', serif",                                         # 1
    "'Palatino Linotype', 'Palatino', 'Book Antiqua', 'Noto Serif', serif",  # 2
    "'Times New Roman', 'Times', 'Noto Serif', serif",                       # 3
    "'Garamond', 'EB Garamond', 'Noto Serif', serif",                        # 4
    "'Cambria', 'Georgia', 'Noto Serif', serif",                              # 5
    "'Book Antiqua', 'Palatino', 'Noto Serif', serif",                       # 6
    "'Arial', 'Helvetica', 'Liberation Sans', sans-serif",                    # 7
    "'Helvetica Neue', 'Helvetica', 'Arial', 'Liberation Sans', sans-serif", # 8
    "'Verdana', 'Geneva', 'Liberation Sans', sans-serif",                     # 9
    "'Calibri', 'Carlito', 'Arial', 'Liberation Sans', sans-serif",          # 10
]

# ── 10 heading font stacks (cross-platform: Mac, Windows, Linux fallbacks) ──
HEADING_FONTS = [
    "'Arial', 'Helvetica', 'Liberation Sans', sans-serif",                    # 1
    "'Helvetica Neue', 'Helvetica', 'Arial', 'Liberation Sans', sans-serif", # 2
    "'Trebuchet MS', 'Lucida Grande', 'Liberation Sans', sans-serif",         # 3
    "'Gill Sans', 'Gill Sans MT', 'Calibri', 'Liberation Sans', sans-serif", # 4
    "'Verdana', 'Geneva', 'Liberation Sans', sans-serif",                     # 5
    "'Segoe UI', 'Roboto', 'Helvetica', 'Liberation Sans', sans-serif",      # 6
    "'Georgia', 'Noto Serif', serif",                                         # 7
    "'Palatino Linotype', 'Palatino', 'Noto Serif', serif",                  # 8
    "'Garamond', 'EB Garamond', 'Noto Serif', serif",                        # 9
    "'Times New Roman', 'Times', 'Noto Serif', serif",                       # 10
]

# ── 10 color themes ──
COLOR_THEMES = [
    {"accent": "#1B3A5C", "body_text": "#2C2C2C", "heading_text": "#1B3A5C"},  # 1 navy
    {"accent": "#2C5F4A", "body_text": "#333333", "heading_text": "#2C5F4A"},  # 2 forest
    {"accent": "#4A3728", "body_text": "#3C3C3C", "heading_text": "#4A3728"},  # 3 brown
    {"accent": "#3D3D6B", "body_text": "#2E2E2E", "heading_text": "#3D3D6B"},  # 4 indigo
    {"accent": "#4A235A", "body_text": "#333333", "heading_text": "#4A235A"},  # 5 plum
    {"accent": "#7B241C", "body_text": "#333333", "heading_text": "#7B241C"},  # 6 crimson
    {"accent": "#000000", "body_text": "#222222", "heading_text": "#000000"},  # 7 black
    {"accent": "#800020", "body_text": "#333333", "heading_text": "#800020"},  # 8 burgundy
    {"accent": "#2F4F4F", "body_text": "#2C2C2C", "heading_text": "#2F4F4F"},  # 9 dark slate
    {"accent": "#36454F", "body_text": "#2C2C2C", "heading_text": "#36454F"},  # 10 charcoal
]

# ── 10 layout modes ──
LAYOUT_MODES = [
    "tables",            # 1  each comp in its own two-column table
    "prose",             # 2  comps described in paragraph form
    "summary_table",     # 3  all comps in one big comparison grid
    "cards",             # 4  comps in bordered card boxes
    "definition_list",   # 5  comps as dt/dd pairs
    "text_only",         # 6  plain text, no tables/boxes at all
    "concise",           # 7  minimal: one-line per comp, tiny footprint
    "bullet_list",       # 8  comps as bullet-point lists
    "numbered_prose",    # 9  numbered paragraphs with inline data
    "grid",              # 10 two-column card grid
]

# ── 10 table/visual style presets ──
TABLE_STYLES = [
    "minimal",           # 1  thin top/bottom borders only
    "full_borders",      # 2  1px borders on all cells
    "header_shaded",     # 3  shaded header row + horizontal lines
    "alternating",       # 4  alternating row backgrounds
    "boxed_header",      # 5  bold header with bottom border
    "invisible",         # 6  no borders at all, just spacing
    "double_line",       # 7  double-line header separator
    "rounded",           # 8  soft gray background on cells
    "accent_rows",       # 9  accent-colored even rows
    "compact",           # 10 tight padding, small font
]

# ── 10 heading decoration styles ──
HEADING_STYLES = [
    "underline",         # 1  bottom border
    "plain",             # 2  no decoration
    "small_caps",        # 3  small caps on h2
    "accent_bar",        # 4  left border bar
    "all_caps",          # 5  uppercase transform
    "italic_accent",     # 6  italic + colored
    "heavy_underline",   # 7  thick bottom border
    "background_bar",    # 8  light accent background
    "dotted_underline",  # 9  dotted bottom border
    "minimal",           # 10 just weight/size, same color as body
]

# ── 10 wording format styles (controls how verbose/formal the language is) ──
WORDING_STYLES = [
    "formal",            # 1  full formal appraisal language
    "professional",      # 2  standard professional but not stiff
    "concise",           # 3  short labels, abbreviated terms
    "technical",         # 4  appraisal jargon, acronyms
    "narrative",         # 5  flowing paragraph-style descriptions
    "plain",             # 6  simple everyday language
    "academic",          # 7  scholarly/analytical tone
    "legal",             # 8  legal/statutory language
    "brief",             # 9  telegraphic, minimal words
    "conversational",    # 10 approachable, explaining as it goes
]

SUBJECT_LAYOUTS = [
    "table", "prose", "two_column", "inline",
]

DIVIDER_STYLES = [
    "hr_line", "spacing", "accent_line", "dots", "none",
]

# ── PDF metadata pools (to prevent fingerprinting) ──
PDF_PRODUCERS = [
    "Microsoft Word 16.0",
    "Adobe PDF Library 21.7",
    "LibreOffice 7.6",
    "Google Docs",
    "Pages 14.0",
    "wkhtmltopdf 0.12.6",
    "Prince 15.2",
    "PDF-XChange Editor 10.1",
    "Foxit PDF Editor 13.0",
    "Nitro Pro 14",
    "Bullzip PDF Printer 14.1",
    "doPDF 11",
    "CutePDF Writer 4.0",
    "Sejda PDF Desktop 7.6",
]

PDF_CREATORS = [
    "Microsoft Word",
    "Adobe Acrobat Pro",
    "LibreOffice Writer",
    "Google Docs",
    "Apple Pages",
    "LaTeX with hyperref",
    "Adobe InDesign 19.0",
    "Corel WordPerfect",
    "WPS Office Writer",
    "Scribus 1.5",
    "Apache OpenOffice Writer",
    "Quark XPress 2024",
]

PDF_AUTHORS = [
    "",  # blank (common for many tools)
    "",
    "",
]


@dataclass
class ReportStyle:
    """All CSS variable values for a single report."""

    body_font: str
    heading_font: str
    base_font_size: str
    h1_size: str
    h2_size: str
    h3_size: str
    line_height: str
    paragraph_spacing: str
    page_margin_top: str
    page_margin_bottom: str
    page_margin_left: str
    page_margin_right: str
    accent_color: str
    accent_light: str
    body_text_color: str
    heading_text_color: str
    table_style: str
    heading_style: str
    text_align: str
    heading_align: str
    table_header_bg: str
    table_alt_row_bg: str
    hr_style: str
    hr_width: str
    indent_first_line: str
    layout_mode: str
    subject_layout: str
    divider_style: str
    show_header_banner: bool
    show_section_numbers: bool
    comp_numbering: str
    wording_style: str

    def as_dict(self) -> dict:
        return asdict(self)


class StyleRandomizer:
    """Deterministic style randomizer using a seed string."""

    def __init__(self, seed: str):
        self.seed = seed
        seed_hash = hashlib.sha256(seed.encode()).hexdigest()
        self._rng = random.Random(int(seed_hash[:16], 16))

    def generate(self) -> ReportStyle:
        """Generate a complete randomized style from the seed."""
        rng = self._rng

        body_font_stack = rng.choice(BODY_FONTS)
        heading_font_stack = rng.choice(HEADING_FONTS)

        base_size = rng.uniform(10.0, 13.5)
        h1_ratio = rng.uniform(1.5, 2.3)
        h2_ratio = rng.uniform(1.15, 1.55)
        h3_ratio = rng.uniform(0.95, 1.2)

        line_height = rng.uniform(1.25, 1.75)
        para_spacing = rng.uniform(0.2, 1.0)

        margin_top = rng.uniform(0.5, 1.4)
        margin_bottom = rng.uniform(0.5, 1.3)
        margin_left = rng.uniform(0.6, 1.4)
        margin_right = rng.uniform(0.6, 1.3)

        theme = rng.choice(COLOR_THEMES)
        accent = theme["accent"]
        accent_light = _lighten_color(accent, rng.uniform(0.78, 0.94))

        table_style = rng.choice(TABLE_STYLES)
        heading_style = rng.choice(HEADING_STYLES)

        text_align = rng.choice(["justify", "justify", "left", "left", "left"])
        heading_align = rng.choice(["left", "left", "left", "center"])

        hr_style = rng.choice(["solid", "solid", "dashed", "dotted", "double"])
        hr_width = rng.choice(["0.5px", "1px", "1px", "2px", "1.5px"])
        _unused_indent = rng.choice(["0", "0", "0", "0.2in", "0.3in", "1em"])  # consumed for RNG sequence compat
        indent = "0"

        layout_mode = rng.choice(LAYOUT_MODES)
        subject_layout = rng.choice(SUBJECT_LAYOUTS)
        divider_style = rng.choice(DIVIDER_STYLES)
        show_banner = rng.choice([True, False, False, False, False])
        show_section_nums = rng.choice([True, True, False, False, False])
        comp_numbering = rng.choice([
            "Comp {n}:", "#{n}", "{n}.", "{alpha}.",
            "Sale {n}:", "Property {n}:", "Comparable {n}:",
        ])
        wording_style = rng.choice(WORDING_STYLES)

        return ReportStyle(
            body_font=body_font_stack,
            heading_font=heading_font_stack,
            base_font_size=f"{base_size:.1f}pt",
            h1_size=f"{base_size * h1_ratio:.1f}pt",
            h2_size=f"{base_size * h2_ratio:.1f}pt",
            h3_size=f"{base_size * h3_ratio:.1f}pt",
            line_height=f"{line_height:.2f}",
            paragraph_spacing=f"{para_spacing:.1f}em",
            page_margin_top=f"{margin_top:.2f}in",
            page_margin_bottom=f"{margin_bottom:.2f}in",
            page_margin_left=f"{margin_left:.2f}in",
            page_margin_right=f"{margin_right:.2f}in",
            accent_color=accent,
            accent_light=accent_light,
            body_text_color=theme["body_text"],
            heading_text_color=theme["heading_text"],
            table_style=table_style,
            heading_style=heading_style,
            text_align=text_align,
            heading_align=heading_align,
            table_header_bg=accent,
            table_alt_row_bg=accent_light,
            hr_style=hr_style,
            hr_width=hr_width,
            indent_first_line=indent,
            layout_mode=layout_mode,
            subject_layout=subject_layout,
            divider_style=divider_style,
            show_header_banner=show_banner,
            show_section_numbers=show_section_nums,
            comp_numbering=comp_numbering,
            wording_style=wording_style,
        )

    def generate_metadata(self) -> dict:
        """Generate randomized PDF metadata to prevent fingerprinting."""
        rng = self._rng
        return {
            "Producer": rng.choice(PDF_PRODUCERS),
            "Creator": rng.choice(PDF_CREATORS),
            "Author": rng.choice(PDF_AUTHORS),
        }

    @staticmethod
    def default_seed(parcel_number: str) -> str:
        """Generate a unique random seed for each run."""
        return f"{parcel_number}-{uuid.uuid4().hex[:8]}"


def _lighten_color(hex_color: str, factor: float) -> str:
    """Lighten a hex color toward white by factor (0.0=unchanged, 1.0=white)."""
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    r = int(r + (255 - r) * factor)
    g = int(g + (255 - g) * factor)
    b = int(b + (255 - b) * factor)
    return f"#{r:02X}{g:02X}{b:02X}"
