from bex_hooks.exec.cli import main

if __name__ == "__main__":
    main()
