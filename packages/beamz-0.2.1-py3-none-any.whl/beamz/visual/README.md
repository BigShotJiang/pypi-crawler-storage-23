# Visual

Handles user interactions through plotting, animation, and the command line interface.