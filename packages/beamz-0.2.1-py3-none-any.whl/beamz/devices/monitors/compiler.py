"""Compile Monitor objects into static packed monitor specs."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import jax.numpy as jnp
import numpy as np

from beamz.devices.monitors.monitors import Monitor


@dataclass(frozen=True)
class CompiledMonitorSpec:
    """Packed monitor descriptor consumed by compiled step kernels."""

    name: str
    monitor_index: int
    is_3d: bool
    record_interval: int
    accumulate_power: bool
    power_scale: float
    normal_axis: int = -1
    accumulate_frequency: bool = False
    freq_record_interval: int = 1
    freq_count: int = 0
    freq_hz: jnp.ndarray | None = None
    freq_rot_re: jnp.ndarray | None = None
    freq_rot_im: jnp.ndarray | None = None
    dft_enabled: bool = False
    dft_record_interval: int = 1
    dft_t_start: float = 0.0
    dft_t_end: float = np.inf
    dft_window_code: int = 0  # 0=rect, 1=hann
    dft_point_count: int = 0
    dft_component_mask: jnp.ndarray | None = None

    # 2D fields
    x_ex: jnp.ndarray | None = None
    y_ex: jnp.ndarray | None = None
    valid_ex: jnp.ndarray | None = None
    x_ey: jnp.ndarray | None = None
    y_ey: jnp.ndarray | None = None
    valid_ey: jnp.ndarray | None = None
    x_ez: jnp.ndarray | None = None
    y_ez: jnp.ndarray | None = None
    valid_ez: jnp.ndarray | None = None
    x_hx: jnp.ndarray | None = None
    y_hx: jnp.ndarray | None = None
    valid_hx: jnp.ndarray | None = None
    x_hy: jnp.ndarray | None = None
    y_hy: jnp.ndarray | None = None
    valid_hy: jnp.ndarray | None = None
    x_hz: jnp.ndarray | None = None
    y_hz: jnp.ndarray | None = None
    valid_hz: jnp.ndarray | None = None

    # 3D fields
    ex_idx: tuple[Any, ...] | None = None
    ey_idx: tuple[Any, ...] | None = None
    ez_idx: tuple[Any, ...] | None = None
    hx_idx: tuple[Any, ...] | None = None
    hy_idx: tuple[Any, ...] | None = None
    hz_idx: tuple[Any, ...] | None = None
    min_dim0: int = 0
    min_dim1: int = 0


@dataclass(frozen=True)
class BatchedMonitorData:
    """Stacked 3D monitor data for fori_loop-based power computation.

    Pre-computed raveled indices allow uniform gather ops inside a
    fori_loop body, keeping HLO size constant regardless of monitor count.
    """

    n_monitors: int
    monitor_indices: jnp.ndarray  # (n,) int32 — maps batch idx → monitor_state row
    record_intervals: jnp.ndarray  # (n,) int32
    accumulate_flags: jnp.ndarray  # (n,) bool
    power_scales: jnp.ndarray  # (n,) float32
    # Raveled indices per component: (n, max_points) int32
    ex_flat_idx: jnp.ndarray
    ey_flat_idx: jnp.ndarray
    ez_flat_idx: jnp.ndarray
    hx_flat_idx: jnp.ndarray
    hy_flat_idx: jnp.ndarray
    hz_flat_idx: jnp.ndarray
    valid_mask: jnp.ndarray  # (n, max_points) float32
    normal_axes: jnp.ndarray  # (n,) int32; 0=x,1=y,2=z, -1=unknown
    # Frequency-domain in-loop accumulation metadata
    freq_enabled: jnp.ndarray  # (n,) bool
    freq_record_intervals: jnp.ndarray  # (n,) int32
    freq_hz: jnp.ndarray  # (n, max_freq) float32
    freq_rot_re: jnp.ndarray  # (n, max_freq) float32
    freq_rot_im: jnp.ndarray  # (n, max_freq) float32
    freq_mask: jnp.ndarray  # (n, max_freq) float32
    dft_enabled: jnp.ndarray  # (n,) bool
    dft_record_intervals: jnp.ndarray  # (n,) int32
    dft_t_start: jnp.ndarray  # (n,) float32
    dft_t_end: jnp.ndarray  # (n,) float32
    dft_window_code: jnp.ndarray  # (n,) int32
    dft_component_mask: jnp.ndarray  # (n, 6) float32


def compile_batched_monitor_data(
    specs: tuple[CompiledMonitorSpec, ...],
    field_shapes: dict[str, tuple[int, ...]],
) -> BatchedMonitorData | None:
    """Compile 3D monitors into batched form for fori_loop update."""
    specs_3d = [s for s in specs if s.is_3d]
    if not specs_3d:
        return None

    n = len(specs_3d)
    components = [
        ("Ex", "ex_idx"),
        ("Ey", "ey_idx"),
        ("Ez", "ez_idx"),
        ("Hx", "hx_idx"),
        ("Hy", "hy_idx"),
        ("Hz", "hz_idx"),
    ]

    all_flat: dict[str, list[np.ndarray]] = {c: [] for c, _ in components}
    all_n_points: list[int] = []

    for spec in specs_3d:
        n_pts = spec.min_dim0 * spec.min_dim1
        all_n_points.append(n_pts)
        for comp, attr in components:
            shape = field_shapes[comp]
            idx = getattr(spec, attr)
            dummy = np.arange(int(np.prod(shape)), dtype=np.int32).reshape(shape)
            sliced = dummy[idx][: spec.min_dim0, : spec.min_dim1]
            all_flat[comp].append(sliced.ravel())

    max_points = max(all_n_points) if all_n_points else 0
    if max_points == 0:
        return None

    max_freq = max(int(s.freq_count) for s in specs_3d) if specs_3d else 0

    def _pad_stack(flat_list: list[np.ndarray]) -> jnp.ndarray:
        padded = []
        for flat in flat_list:
            p = np.zeros(max_points, dtype=np.int32)
            p[: len(flat)] = flat
            padded.append(p)
        return jnp.array(np.stack(padded))

    valid = np.zeros((n, max_points), dtype=np.float32)
    for i, n_pts in enumerate(all_n_points):
        valid[i, :n_pts] = 1.0

    freq_mask = np.zeros((n, max_freq), dtype=np.float32)
    freq_hz = np.zeros((n, max_freq), dtype=np.float32)
    freq_rot_re = np.ones((n, max_freq), dtype=np.float32)
    freq_rot_im = np.zeros((n, max_freq), dtype=np.float32)
    dft_enabled = np.zeros((n,), dtype=bool)
    dft_record_intervals = np.ones((n,), dtype=np.int32)
    dft_t_start = np.zeros((n,), dtype=np.float32)
    dft_t_end = np.full((n,), np.inf, dtype=np.float32)
    dft_window_code = np.zeros((n,), dtype=np.int32)
    dft_component_mask = np.zeros((n, 6), dtype=np.float32)
    for i, spec in enumerate(specs_3d):
        if (
            spec.freq_count > 0
            and spec.freq_hz is not None
            and spec.freq_rot_re is not None
            and spec.freq_rot_im is not None
        ):
            cnt = int(spec.freq_count)
            freq_mask[i, :cnt] = 1.0
            freq_hz[i, :cnt] = np.asarray(spec.freq_hz, dtype=np.float32)[:cnt]
            freq_rot_re[i, :cnt] = np.asarray(spec.freq_rot_re, dtype=np.float32)[:cnt]
            freq_rot_im[i, :cnt] = np.asarray(spec.freq_rot_im, dtype=np.float32)[:cnt]
        dft_enabled[i] = bool(spec.dft_enabled and spec.freq_count > 0)
        dft_record_intervals[i] = int(max(1, spec.dft_record_interval))
        dft_t_start[i] = float(spec.dft_t_start)
        dft_t_end[i] = float(spec.dft_t_end)
        dft_window_code[i] = int(spec.dft_window_code)
        if spec.dft_component_mask is not None:
            dft_component_mask[i, :] = np.asarray(
                spec.dft_component_mask, dtype=np.float32
            )[:6]

    return BatchedMonitorData(
        n_monitors=n,
        monitor_indices=jnp.array([s.monitor_index for s in specs_3d], dtype=jnp.int32),
        record_intervals=jnp.array(
            [s.record_interval for s in specs_3d], dtype=jnp.int32
        ),
        accumulate_flags=jnp.array([s.accumulate_power for s in specs_3d]),
        power_scales=jnp.array([s.power_scale for s in specs_3d], dtype=jnp.float32),
        ex_flat_idx=_pad_stack(all_flat["Ex"]),
        ey_flat_idx=_pad_stack(all_flat["Ey"]),
        ez_flat_idx=_pad_stack(all_flat["Ez"]),
        hx_flat_idx=_pad_stack(all_flat["Hx"]),
        hy_flat_idx=_pad_stack(all_flat["Hy"]),
        hz_flat_idx=_pad_stack(all_flat["Hz"]),
        valid_mask=jnp.array(valid),
        normal_axes=jnp.array([int(s.normal_axis) for s in specs_3d], dtype=jnp.int32),
        freq_enabled=jnp.array([bool(s.accumulate_frequency) for s in specs_3d]),
        freq_record_intervals=jnp.array(
            [max(1, int(s.freq_record_interval)) for s in specs_3d], dtype=jnp.int32
        ),
        freq_hz=jnp.array(freq_hz, dtype=jnp.float32),
        freq_rot_re=jnp.array(freq_rot_re, dtype=jnp.float32),
        freq_rot_im=jnp.array(freq_rot_im, dtype=jnp.float32),
        freq_mask=jnp.array(freq_mask, dtype=jnp.float32),
        dft_enabled=jnp.array(dft_enabled),
        dft_record_intervals=jnp.array(dft_record_intervals, dtype=jnp.int32),
        dft_t_start=jnp.array(dft_t_start, dtype=jnp.float32),
        dft_t_end=jnp.array(dft_t_end, dtype=jnp.float32),
        dft_window_code=jnp.array(dft_window_code, dtype=jnp.int32),
        dft_component_mask=jnp.array(dft_component_mask, dtype=jnp.float32),
    )


def _clip_indices(x_idx: np.ndarray, y_idx: np.ndarray, shape: tuple[int, int]):
    h, w = shape
    valid = (x_idx >= 0) & (x_idx < w) & (y_idx >= 0) & (y_idx < h)
    x = np.clip(x_idx, 0, max(w - 1, 0)).astype(np.int32)
    y = np.clip(y_idx, 0, max(h - 1, 0)).astype(np.int32)
    return x, y, valid.astype(np.float32)


def _clamp_3d_index(idx, limit: int):
    if isinstance(idx, int):
        return int(min(max(0, idx), limit - 1))
    start = idx.start if idx.start is not None else 0
    stop = idx.stop if idx.stop is not None else limit
    start = max(0, min(start, limit - 1))
    stop = max(start, min(stop, limit))
    return slice(start, stop)


def _compile_monitor_3d_indices(
    monitor: Monitor, resolution: float, shape_3d: dict[str, tuple[int, ...]]
):
    idx_map: dict[str, tuple[Any, ...]] = {}
    dim0 = []
    dim1 = []

    for name, shape in shape_3d.items():
        z_idx, y_idx, x_idx = monitor.get_grid_slice_3d(
            resolution,
            resolution,
            resolution,
            shape,
        )
        z_idx = _clamp_3d_index(z_idx, shape[0])
        y_idx = _clamp_3d_index(y_idx, shape[1])
        x_idx = _clamp_3d_index(x_idx, shape[2])
        idx = (z_idx, y_idx, x_idx)
        idx_map[name] = idx

        # infer resulting 2D slice shape
        arr = np.zeros(shape, dtype=np.float32)
        sliced = arr[idx]
        if sliced.ndim != 2:
            sliced = np.atleast_2d(sliced)
        dim0.append(sliced.shape[0])
        dim1.append(sliced.shape[1])

    return idx_map, int(min(dim0)), int(min(dim1))


def compile_monitor_specs(
    devices: list,
    fields,
    resolution: float,
    num_steps: int,
    dt: float,
) -> tuple[tuple[CompiledMonitorSpec, ...], int]:
    """Compile monitor devices into packed monitor specs.

    Returns
    -------
    specs:
        Tuple of monitor specs.
    max_records:
        Maximum number of records per monitor row in monitor-state buffers.
    """
    monitors = [d for d in devices if isinstance(d, Monitor)]
    if not monitors:
        return tuple(), 0

    specs: list[CompiledMonitorSpec] = []
    max_records = 0

    for mon_idx, monitor in enumerate(monitors):
        interval = max(1, int(monitor.record_interval))
        records = int(math.ceil(num_steps / interval))
        max_records = max(max_records, records)

        dft_enabled = bool(getattr(monitor, "dft_enabled", False))
        dft_freqs = np.asarray(
            getattr(monitor, "dft_frequencies", np.zeros((0,))), dtype=np.float64
        ).ravel()
        if dft_freqs.size > 0 and not np.all(np.isfinite(dft_freqs)):
            raise ValueError("Monitor dft_frequencies must be finite values in Hz")
        if dft_freqs.size > 0 and np.any(dft_freqs <= 0.0):
            raise ValueError("Monitor dft_frequencies must be strictly positive")

        flux_freqs = np.asarray(
            getattr(monitor, "frequency_points", np.zeros((0,))), dtype=np.float64
        ).ravel()
        if flux_freqs.size > 0 and not np.all(np.isfinite(flux_freqs)):
            raise ValueError("Monitor frequency_points must be finite values in Hz")
        if dft_enabled and dft_freqs.size > 0:
            freq_points = dft_freqs
            freq_interval = (
                1 if bool(getattr(monitor, "dft_record_every_step", True)) else interval
            )
        else:
            freq_points = flux_freqs
            freq_interval = max(
                1, int(getattr(monitor, "frequency_record_interval", 1))
            )
        theta = -2.0 * np.pi * freq_points * float(dt) * float(freq_interval)
        freq_rot_re = np.cos(theta).astype(np.float32, copy=False)
        freq_rot_im = np.sin(theta).astype(np.float32, copy=False)
        dft_window = str(getattr(monitor, "dft_window", "rect")).lower()
        if dft_window in {"none", "rectangular"}:
            dft_window = "rect"
        dft_window_code = 1 if dft_window == "hann" else 0
        dft_t_end_val = float(
            np.inf
            if getattr(monitor, "dft_t_end", None) is None
            else getattr(monitor, "dft_t_end")
        )
        if dft_window_code == 1 and not np.isfinite(dft_t_end_val):
            dft_window_code = 0
        dft_components = getattr(monitor, "dft_components", None)
        if dft_components is None:
            dft_component_mask = np.ones((6,), dtype=np.float32)
        else:
            wanted = {str(c) for c in dft_components}
            ordered = ("Ex", "Ey", "Ez", "Hx", "Hy", "Hz")
            dft_component_mask = np.asarray(
                [1.0 if c in wanted else 0.0 for c in ordered], dtype=np.float32
            )

        if not monitor.is_3d:
            points = monitor.get_grid_points_2d(resolution, resolution)
            if points:
                x_raw = np.asarray([p[0] for p in points], dtype=np.int32)
                y_raw = np.asarray([p[1] for p in points], dtype=np.int32)
            else:
                x_raw = np.zeros((0,), dtype=np.int32)
                y_raw = np.zeros((0,), dtype=np.int32)

            x_ex, y_ex, v_ex = _clip_indices(x_raw, y_raw, tuple(fields.Ex.shape))
            x_ey, y_ey, v_ey = _clip_indices(x_raw, y_raw, tuple(fields.Ey.shape))
            x_ez, y_ez, v_ez = _clip_indices(x_raw, y_raw, tuple(fields.Ez.shape))
            x_hx, y_hx, v_hx = _clip_indices(x_raw, y_raw, tuple(fields.Hx.shape))
            x_hy, y_hy, v_hy = _clip_indices(x_raw, y_raw, tuple(fields.Hy.shape))
            x_hz, y_hz, v_hz = _clip_indices(x_raw, y_raw, tuple(fields.Hz.shape))

            specs.append(
                CompiledMonitorSpec(
                    name=monitor.name or f"monitor_{mon_idx}",
                    monitor_index=mon_idx,
                    is_3d=False,
                    record_interval=interval,
                    accumulate_power=bool(monitor.accumulate_power),
                    power_scale=float(resolution * resolution),
                    normal_axis=-1,
                    accumulate_frequency=bool(freq_points.size > 0),
                    freq_record_interval=freq_interval,
                    freq_count=int(freq_points.size),
                    freq_hz=jnp.asarray(freq_points.astype(np.float32, copy=False)),
                    freq_rot_re=jnp.asarray(freq_rot_re),
                    freq_rot_im=jnp.asarray(freq_rot_im),
                    dft_enabled=bool(dft_enabled and dft_freqs.size > 0),
                    dft_record_interval=(
                        1
                        if bool(getattr(monitor, "dft_record_every_step", True))
                        else interval
                    ),
                    dft_t_start=float(getattr(monitor, "dft_t_start", 0.0)),
                    dft_t_end=float(dft_t_end_val),
                    dft_window_code=dft_window_code,
                    dft_point_count=int(x_ez.size),
                    dft_component_mask=jnp.asarray(dft_component_mask),
                    x_ex=jnp.asarray(x_ex),
                    y_ex=jnp.asarray(y_ex),
                    valid_ex=jnp.asarray(v_ex),
                    x_ey=jnp.asarray(x_ey),
                    y_ey=jnp.asarray(y_ey),
                    valid_ey=jnp.asarray(v_ey),
                    x_ez=jnp.asarray(x_ez),
                    y_ez=jnp.asarray(y_ez),
                    valid_ez=jnp.asarray(v_ez),
                    x_hx=jnp.asarray(x_hx),
                    y_hx=jnp.asarray(y_hx),
                    valid_hx=jnp.asarray(v_hx),
                    x_hy=jnp.asarray(x_hy),
                    y_hy=jnp.asarray(y_hy),
                    valid_hy=jnp.asarray(v_hy),
                    x_hz=jnp.asarray(x_hz),
                    y_hz=jnp.asarray(y_hz),
                    valid_hz=jnp.asarray(v_hz),
                )
            )
        else:
            shape_3d = {
                "Ex": tuple(fields.Ex.shape),
                "Ey": tuple(fields.Ey.shape),
                "Ez": tuple(fields.Ez.shape),
                "Hx": tuple(fields.Hx.shape),
                "Hy": tuple(fields.Hy.shape),
                "Hz": tuple(fields.Hz.shape),
            }
            idx_map, min_dim0, min_dim1 = _compile_monitor_3d_indices(
                monitor,
                resolution,
                shape_3d,
            )

            specs.append(
                CompiledMonitorSpec(
                    name=monitor.name or f"monitor_{mon_idx}",
                    monitor_index=mon_idx,
                    is_3d=True,
                    record_interval=interval,
                    accumulate_power=bool(monitor.accumulate_power),
                    power_scale=float(resolution * resolution),
                    normal_axis={"x": 0, "y": 1, "z": 2}.get(
                        str(getattr(monitor, "plane_normal", "z")).lower(), -1
                    ),
                    accumulate_frequency=bool(freq_points.size > 0),
                    freq_record_interval=freq_interval,
                    freq_count=int(freq_points.size),
                    freq_hz=jnp.asarray(freq_points.astype(np.float32, copy=False)),
                    freq_rot_re=jnp.asarray(freq_rot_re),
                    freq_rot_im=jnp.asarray(freq_rot_im),
                    dft_enabled=bool(dft_enabled and dft_freqs.size > 0),
                    dft_record_interval=(
                        1
                        if bool(getattr(monitor, "dft_record_every_step", True))
                        else interval
                    ),
                    dft_t_start=float(getattr(monitor, "dft_t_start", 0.0)),
                    dft_t_end=float(dft_t_end_val),
                    dft_window_code=dft_window_code,
                    dft_point_count=int(min_dim0 * min_dim1),
                    dft_component_mask=jnp.asarray(dft_component_mask),
                    ex_idx=idx_map["Ex"],
                    ey_idx=idx_map["Ey"],
                    ez_idx=idx_map["Ez"],
                    hx_idx=idx_map["Hx"],
                    hy_idx=idx_map["Hy"],
                    hz_idx=idx_map["Hz"],
                    min_dim0=min_dim0,
                    min_dim1=min_dim1,
                )
            )

    return tuple(specs), max_records
