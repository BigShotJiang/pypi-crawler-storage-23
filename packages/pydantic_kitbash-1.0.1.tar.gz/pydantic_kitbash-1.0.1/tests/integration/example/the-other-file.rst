.. _the-other-file:

The other file
==============

Wow, you can put cross-references in docstrings now? What a great feature!
