from .personaplex import PersonaPlexTTS

__all__ = ["PersonaPlexTTS"]
