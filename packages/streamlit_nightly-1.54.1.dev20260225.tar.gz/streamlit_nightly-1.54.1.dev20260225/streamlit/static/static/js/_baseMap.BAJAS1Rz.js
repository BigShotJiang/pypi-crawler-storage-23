import{w as u,x as b}from"./index.D-NUf2mx.js";function p(r,s){var e=-1,a=u(r)?Array(r.length):[];return b(r,function(n,t,i){a[++e]=s(n,t,i)}),a}export{p as b};
