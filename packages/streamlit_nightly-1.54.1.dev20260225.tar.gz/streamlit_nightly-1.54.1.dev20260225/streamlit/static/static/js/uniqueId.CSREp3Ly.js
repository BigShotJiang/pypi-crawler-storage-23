import{I as i}from"./index.D-NUf2mx.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
