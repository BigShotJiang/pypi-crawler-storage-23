## `reforge_core.calibration.api`

### `ReforgeAPIManager` class
The `ReforgeAPIManager` class manages calls to the Reforge cloud API.

#### def __init__(reforge_api_token: str, robot_id: str):
```
Initializes the Reforge Cloud API.

:param reforge_api_token: Reforge cloud API string token for the user, generated on api.reforgerobotics.com
:param robot_id: Robot ID string for the robot the data was generated on. This parameter is required for model version control and predictive maintenance features.
```

#### def run_identification(self, data_folder: str):
```
Calls the Reforge Cloud API to generate models using the given calibration data to generate models for control and store them locally in the 'robot/models/current' folder.

:param data_folder: String representing the folder where the calibration data is stored.
```

#### def run_fine_tuning(self, data_folder: str):
```
Calls the Reforge Cloud API to generate a fine tune the current model (in the 'robot/models/current' folder) with the given calibration data.

:param data_folder: String representing the folder where the calibration data is stored.
```

#### def __save_models_locally(self, models_cloud_folder: str):
```
Internal method used by the run_identification and run_fine_tuning methods to store the cloud models in the 'robot/models/current' folder.

:param models_cloud_folder: String representing the folder where the calibration data is stored in the cloud.
```

#### def __compress_data(self, data_folder: str, temp_folder: str = "temp_calibration_data.zip"):
```
Internal method used by the run_identification and run_fine_tuning methods to store the compress data during upload from local computer to the cloud.

:param data_folder: String representing the folder where the calibration data is stored. This folder is compressed before upload.
:optional param temp_folder: Temporary compressed folder to be pushed to the cloud.
```
