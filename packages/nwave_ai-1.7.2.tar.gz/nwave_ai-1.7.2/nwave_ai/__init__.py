"""nwave-ai: CLI installer for the nWave methodology framework."""

__version__ = "1.7.2"
