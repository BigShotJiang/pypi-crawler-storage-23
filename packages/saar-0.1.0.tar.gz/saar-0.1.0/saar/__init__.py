"""Saar -- extract the essence of your codebase."""

__version__ = "0.1.0"
