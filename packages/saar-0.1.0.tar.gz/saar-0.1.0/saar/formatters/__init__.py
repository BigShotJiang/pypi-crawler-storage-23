"""Output formatters for different AI config file formats.

Each formatter takes a CodebaseDNA and returns a string in the
target format. The render() function dispatches to the right one.
"""
from saar.models import CodebaseDNA
from saar.formatters.markdown import render_markdown
from saar.formatters.claude_md import render_claude_md
from saar.formatters.cursorrules import render_cursorrules
from saar.formatters.copilot import render_copilot


_RENDERERS = {
    "markdown": render_markdown,
    "claude": render_claude_md,
    "cursorrules": render_cursorrules,
    "copilot": render_copilot,
}


def render(dna: CodebaseDNA, format: str) -> str:
    """Render DNA in the given format. Raises KeyError for unknown formats."""
    renderer = _RENDERERS.get(format)
    if renderer is None:
        raise KeyError(f"Unknown format: {format}. Options: {list(_RENDERERS.keys())}")
    return renderer(dna)
