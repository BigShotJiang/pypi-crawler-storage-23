# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## 0.1.0 - 2026-03-04

### Added
- Initial release of Affinity MCP Server, which integrates with Affinity's APIs

#### Persons Tools
- `search_persons` - Search for persons by name or email with optional interaction date filtering
- `get_person_info` - Retrieve detailed information about a person including current organization and job title
- `get_person_list_entries` - View which lists a person appears on

#### Companies Tools
- `search_companies` - Search for companies by name or domain with optional interaction history filtering
- `get_company_info` - Retrieve detailed information about a company including location and description
- `get_company_list_entries` - View which lists a company appears on

#### Opportunities Tools
- `search_opportunities` - Search for opportunities by keyword or list all opportunities

#### Notes Tools
- `create_note` - Create HTML notes and attach them to persons, companies, or opportunities
- `get_notes` - Find notes with filtering by ID, creator, or creation date
- `get_notes_for_entity` - Retrieve all notes attached to a specific person, company, or opportunity
- `get_entities_attached_to_note` - Find all persons, companies, or opportunities linked to a specific note

#### Lists Tools
- `get_lists` - View all lists in your organization that you have access to
- `get_list_info` - Retrieve metadata about a specific list
- `get_list_entries` - Retrieve list entries from a specific list with pagination
- `get_single_list_entry` - Retrieve metadata about a single list entry from a specific list
- `get_list_fields` - View metadata about available fields for a specific list

#### Meetings Tools
- `get_meetings` - Retrieve past and future meetings with filtering by meeting ID, start time, creation time, or update time
- `get_meetings_for_entity` - Retrieve meetings for a specific company, person, or opportunity with filtering by internal person and logging type

#### Fields Tools
- `get_entity_fields` - View metadata about available fields for companies or persons

#### Auth Tools
- `get_current_user` - Get information about the current user and organization

#### Semantic Search
- `semantic_search` - Perform natural language semantic searches across Affinity entities

#### Feedback
- `solicit_feedback` - Submit feedback about missing capabilities or limitations

#### Dependencies
- Python: >=3.13
- MCP SDK (`mcp[cli]` >=1.25.0) for Model Context Protocol implementation
- `loguru` (>=0.7.3) for structured logging
- `httpx` for async HTTP client communication with Affinity API
- Development dependencies:
  - `pytest` (>=8.4.1) framework for testing
  - `pytest-mock` (>=3.14.1) for mocking
  - `pytest-asyncio` (>=1.3.0) for testing code that uses asyncio library
  - `pytest-cov` (>=7.0.0) for test coverage reporting
  - `mypy` (>=1.14.1) for static type checking
  - `ruff` (>=0.9.4) for linting and formatting

#### Documentation
- Feature documentation for all tool categories
- Setup and configuration guides for MCP clients:
  - Claude CLI
  - Claude Desktop
  - ChatGPT (via ngrok)
  - Gemini CLI
  - GitHub Copilot (VSCode and CLI)
- Troubleshooting guide with common issues and solutions
- Development setup instructions including local testing with MCP Inspector
- Security vulnerability disclosure
