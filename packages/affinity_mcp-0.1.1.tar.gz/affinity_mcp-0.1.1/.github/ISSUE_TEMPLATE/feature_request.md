---
name: Feature request
about: Suggest a new capability or improvement
title: ''
labels: feature
assignees: ''

---

**If applicable, which Affinity API area does this relate to?**
e.g., Companies, Persons, Lists, Notes, Meetings, Opportunities, Fields

**Problem/Use Case**
What workflow is currently painful or impossible? What are you trying to accomplish?

**Desired Solution**
What feature or capability would solve this problem? Be specific about what you want to see added or changed.

**Alternatives Considered**
Are there any workarounds or alternative approaches you've tried? Why aren't they sufficient?

**Additional Context**
Add any other context about the feature request here.
