from typing import Any

from ..utils.affinity_api import AffinityAPI
from ..filters import DateFiltersApiV1, clean_date_filters
from ..types import FieldType


async def search_persons(
    term: str | None = None,
    with_interaction_dates: bool = False,
    with_interaction_persons: bool = False,
    with_opportunities: bool = False,
    with_current_organizations: bool = False,
    date_filters: DateFiltersApiV1 | None = None,
    page_size: int | None = None,
    page_token: str | None = None,
) -> dict[str, Any]:
    """Searches for persons in the Affinity CRM by name or email. Also allows filtering persons based on their interaction history, such as the dates of the first/last emails or meetings.

    Args:
        term: A string used to search all the persons in your team's address book. This could be an email address, a first name or a last name.
        with_interaction_dates: When true, interaction dates will be present on the returned resources. Only persons that have interactions will be returned.
        with_interaction_persons: When true, persons for each interaction will be returned. Used in conjunction with with_interaction_dates.
        with_opportunities: When true, opportunity IDs will be returned for each person.
        with_current_organizations: When true, the organization IDs of each person's current organizations (according to the Affinity Data: Current Organizations column) will be returned.
        date_filters: Optional dictionary to filter by interaction dates. Keys can be 'min_first_email_date', 'max_last_interaction_date', etc. Dates must be in ISO 8601 format (e.g. '2024-01-01T12:00:00Z').
        page_size: Number of results per page. If not specified, defaults to 10 when searching with a term, otherwise 100.
        page_token: The next_page_token from the previous response required to retrieve the next page of results.

    Returns:
        Structured data containing the list of matching persons and pagination token.
    """
    if page_size is None:
        page_size = 10 if term else 100

    params = {
        "term": term,
        "with_interaction_dates": with_interaction_dates or None,
        "with_interaction_persons": with_interaction_persons or None,
        "with_opportunities": with_opportunities or None,
        "with_current_organizations": with_current_organizations or None,
        "page_size": page_size,
        "page_token": page_token,
    }

    # Filter out None values
    params = {k: v for k, v in params.items() if v is not None}

    if date_filters:
        params.update(clean_date_filters(date_filters))

    async with AffinityAPI() as client:
        return await client.get("/persons", params=params)


async def get_person_list_entries(
    person_id: int, cursor: str | None = None, limit: int = 100
) -> dict[str, Any]:
    """Fetches list entries for the given person.

    Args:
        person_id (required): The ID of the person
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 100

    Returns:
        Structured data containing the matching list entries
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        response = await client.get(
            f"/v2/persons/{person_id}/list-entries", params=params
        )

        # Remove field data to reduce token usage and focus response on list membership
        for entry in response["data"]:
            entry.pop("fields", None)
        return response


async def get_person_info(
    person_id: int,
    field_ids: list[str] | None = None,
    field_types: list[FieldType] | None = None,
) -> dict[str, Any]:
    """Returns basic information and non-list specific field data on the requested person.
    By default, returns all field data including current organization, job title, and more.
    Use get_entity_fields tool if you need to filter to specific fields.

    IMPORTANT: field_ids and field_types are mutually exclusive. They cannot be used together.

    Args:
        person_id (required): The ID of the person
        field_ids: list of field IDs to return.
        field_types: List of field types to return. Defaults to ['enriched', 'global', 'relationship-intelligence']

    Returns:
        Metadata about the specified person including field data
    """
    field_types_str = (
        [ft.value for ft in field_types if ft != FieldType.LIST]
        if field_types
        else (FieldType.entity_field_types() if field_ids is None else None)
    )

    params = {
        k: v
        for k, v in {
            "fieldIds": field_ids,
            "fieldTypes": field_types_str,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.get(f"/v2/persons/{person_id}", params=params)
