from typing import Any, Literal

from ..types import EntityType
from ..utils.affinity_api import AffinityAPI


async def get_entity_fields(
    entity_type: Literal[EntityType.COMPANY, EntityType.PERSON],
    cursor: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """Returns metadata on non-list specific company or person fields.

    Args:
        entity_type: Type of entity to return fields for. Options: "company", "person"
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 100.

    Returns:
        Field metadata
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(f"/v2/{entity_type.to_plural()}/fields", params=params)


async def get_list_fields(
    list_id: int, cursor: str | None = None, limit: int = 100
) -> dict[str, Any]:
    """Returns metadata on fields available for a given list.

    Args:
        list_id: ID of list to return fields for.
        cursor: Cursor for the next or previous page.
        limit: The number of items to include in the page. Default is 100.

    Returns:
        Field metadata
    """
    params = {
        k: v
        for k, v in {
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }
    async with AffinityAPI() as client:
        return await client.get(f"/v2/lists/{list_id}/fields", params=params)
