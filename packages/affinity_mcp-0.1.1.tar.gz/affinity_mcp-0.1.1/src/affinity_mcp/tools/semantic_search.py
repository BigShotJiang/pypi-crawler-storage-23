from typing import Any
from ..utils.affinity_api import AffinityAPI
from ..types import EntityType


async def semantic_search(
    prompt: str,
    limit: int = 10,
    entity_type: EntityType = EntityType.COMPANY,
) -> dict[str, Any]:
    """Performs a semantic search. Currently only supports companies.

    CRITICAL: Use this tool when:
    1. The user's query is broad, ambiguous, or with natural language (e.g., "companies like OpenAI").
    2. You are unsure which specific tool to use.
    3. Specific search tools (search_companies) return no results or fail.

    Args:
        prompt: The prompt to search for. Must be between 1 and 500 characters.
        limit: The number of companies to return. Default is 10. Minimum is 1 and maximum is 100.
        entity_type: The type of entity to search for when the user wants to search for a specific type of entity. Currently only supports "company".

    Returns:
        A list of entities that match the prompt with an explanation of the search. You can hide the scores in the results.
    """
    body = {
        "prompt": prompt,
        "limit": limit,
        "entityType": entity_type.to_plural(),
    }

    async with AffinityAPI() as client:
        return await client.post("/v2/semantic-search", body=body)
