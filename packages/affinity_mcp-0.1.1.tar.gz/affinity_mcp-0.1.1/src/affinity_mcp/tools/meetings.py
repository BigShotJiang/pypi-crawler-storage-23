from typing import Any
import httpx
from ..utils.affinity_api import AffinityAPI
from ..types import EntityType, LoggingType, InteractionType


class MeetingsV2AccessError(Exception):
    """Raised when user tries to access V2 meetings but hasn't been onboarded to unified events."""

    pass


async def get_meetings(
    filter_expr: str | None = None,
    cursor: str | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    """Get information about past and future meeting interactions and their attendees.

    Args:
        filter_expr: Filter expression using Affinity query language. Available fields:
            - id: unique identifier for the meeting (operators: =)
              Example: "id=1" or "(id=1 | id=2)"
            - startTime: When the meeting was scheduled (operators: >, <, >=, <=)
              Format: ISO 8601 timestamp
              Example: "startTime>2025-01-01T01:00:00Z"
            - createdAt: When the meeting was created in Affinity (operators: >, <, >=, <=)
              Format: ISO 8601 timestamp
              Example: "createdAt>=2025-01-01T00:00:00Z"
            - updatedAt: When the meeting was last updated (operators: >, <, >=, <=)
              Format: ISO 8601 timestamp
              Example: "updatedAt<=2025-12-31T23:59:59Z"

            Complex examples:
            - Date range: "startTime>=2025-01-01T00:00:00Z & startTime<2025-02-01T00:00:00Z"
            - Multiple date filters: "startTime>2025-01-01T00:00:00Z & createdAt>=2024-12-01T00:00:00Z"

            Boolean logic: & (AND), | (OR), () for grouping
            Full filtering spec: https://developer.affinity.co/pages/external-api-v2/filtering

        cursor: Cursor for the next or previous page.
        limit: Number of items to include in the page. Default is 20, max is 100.

    Returns:
        Structured data containing the list of meetings and pagination information.

    Raises:
        MeetingsV2AccessError: If the user does not have access to V2 meetings endpoint
    """
    params = {
        k: v
        for k, v in {
            "filter": filter_expr,
            "cursor": cursor,
            "limit": limit,
        }.items()
        if v is not None
    }

    try:
        async with AffinityAPI() as client:
            return await client.get("/v2/meetings", params=params)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise MeetingsV2AccessError(
                "You do not have access to meetings. Please reach out to your Affinity Admin."
            ) from e
        raise


async def get_meetings_for_entity(
    entity_id: int,
    entity_type: EntityType,
    start_time: str,
    end_time: str,
    internal_person_id: int | None = None,
    logging_type: LoggingType | None = None,
    page_size: int = 10,
    page_token: str | None = None,
) -> dict[str, Any]:
    """Get information about meetings for a specific company, person, or opportunity.

    IMPORTANT: The date range between start_time and end_time cannot exceed 365 days. Be mindful of leap years.

    Args:
        entity_id: The ID of the company, external person, or opportunity
        entity_type: What type of entity this ID refers to. Options: "company", "person", "opportunity"
        start_time: ISO 8601 formatted timestamp to filter meetings starting from this time. Must be before end_time
            Format: "2025-01-01T00:00:00Z"
        end_time: ISO 8601 formatted timestamp to filter meetings ending before this time. Must be after start_time
            Format: "2025-01-01T00:00:00Z"
            Maximum 365 day range examples:
            ✓ VALID: start_time: "2025-02-25T00:00:00Z", end_time: "2026-02-25T00:00:00Z"
            ✓ VALID: start_time: "2025-01-01T00:00:00Z", end_time: "2025-12-31T23:59:59Z"
            ✓ VALID (leap year): start_time: "2024-01-01T00:00:00Z", end_time: "2024-12-31T00:00:00Z" (365 days, not 366)
            ✗ INVALID: start_time: "2025-02-25T00:00:00Z", end_time: "2026-02-25T23:59:59Z" (exceeds 1 year by 23:59:59)
        internal_person_id: ID of an internal person that was involved in the meetings. This parameter filters
            down the set of interactions related to the given entity to only those in which this internal
            person was involved. Cannot be used to find all of an internal person's interactions.
        logging_type: Filter by logging classification. When not supplied, returns all logging types. Options:
            - LoggingType.ALL (0): Both automatically and manually logged interactions
            - LoggingType.MANUAL (1): Only manually logged interactions
        page_size: Number of results per page. Default is 10, maximum is 100.
        page_token: The next_page_token from the previous response required to retrieve the next page of results.

    Returns:
        Structured data containing an array of meetings and pagination for retrieving more results
    """
    entity_param_map = {
        EntityType.COMPANY: "organization_id",
        EntityType.PERSON: "person_id",
        EntityType.OPPORTUNITY: "opportunity_id",
    }

    params = {
        k: v
        for k, v in {
            "type": InteractionType.MEETING,
            entity_param_map[entity_type]: entity_id,
            "internal_person_id": internal_person_id,
            "start_time": start_time,
            "end_time": end_time,
            "logging_type": logging_type,
            "page_size": page_size,
            "page_token": page_token,
        }.items()
        if v is not None
    }

    async with AffinityAPI() as client:
        return await client.get("/interactions", params=params)
