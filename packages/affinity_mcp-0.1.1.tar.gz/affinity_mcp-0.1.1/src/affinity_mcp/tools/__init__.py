from collections.abc import Callable, Awaitable
from typing import Any

from .auth import get_current_user
from .companies import search_companies, get_company_info, get_company_list_entries
from .feedback import send_feedback
from .fields import get_entity_fields, get_list_fields
from .lists import get_lists, get_list_entries, get_single_list_entry, get_list_info
from .meetings import get_meetings, get_meetings_for_entity
from .notes import (
    get_notes,
    get_notes_for_entity,
    get_entities_attached_to_note,
    create_note,
)
from .opportunities import search_opportunities
from .persons import search_persons, get_person_info, get_person_list_entries
from .semantic_search import semantic_search

read_only_tools: list[Callable[..., Awaitable[Any]]] = [
    # Auth
    get_current_user,
    # Companies
    search_companies,
    get_company_info,
    get_company_list_entries,
    # Fields
    get_entity_fields,
    get_list_fields,
    # Lists
    get_lists,
    get_list_entries,
    get_single_list_entry,
    get_list_info,
    # Meetings
    get_meetings,
    get_meetings_for_entity,
    # Notes
    get_notes,
    get_notes_for_entity,
    get_entities_attached_to_note,
    # Opportunities
    search_opportunities,
    # Persons
    search_persons,
    get_person_info,
    get_person_list_entries,
    # Semantic Search
    semantic_search,
]

write_tools: list[Callable[..., Awaitable[Any]]] = [
    # Feedback
    send_feedback,
    # Notes
    create_note,
]
