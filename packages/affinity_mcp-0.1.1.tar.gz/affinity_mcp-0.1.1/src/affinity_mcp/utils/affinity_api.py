from json import JSONDecodeError
from typing import Any

import httpx
import importlib.metadata
from loguru import logger

from ..settings import settings

APP_NAME = "affinity-mcp"


class AffinityAPIError(Exception):
    """Error from Affinity API request."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


class AffinityAPI:
    """Async client for Affinity API v1 and v2 endpoints.

    Uses Bearer token authentication.

    Usage:
        async with AffinityAPI() as client:
            return await client.get("/v2/persons")
    """

    def __init__(self):
        """Initialize the Affinity API client."""
        self._api_key = settings.api_key.get_secret_value()
        self._client = httpx.AsyncClient(
            base_url=str(settings.api_url),
            headers=self._headers,
            timeout=30.0,
        )

    @property
    def _headers(self) -> dict[str, str]:
        """Get headers with Bearer token authentication."""
        version = importlib.metadata.version(APP_NAME)
        return {
            "Accept": "application/json",
            "Authorization": f"Bearer {self._api_key}",
            "User-Agent": f"{APP_NAME}/{version}",
            "X-Client-Id": APP_NAME,
            "X-Client-Version": version,
        }

    async def __aenter__(self):
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context manager."""
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def get(
        self, endpoint: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a GET request to the Affinity API.

        Args:
            endpoint: The API endpoint path (e.g. '/v2/persons')
            params: Optional query parameters for the request.

        Returns:
            Dictionary containing the API response, or None for empty responses.

        Raises:
            AffinityAPIError: For Affinity API errors
            httpx.RequestError: For connection/timeout errors
            json.JSONDecodeError: For invalid JSON in response body
        """
        logger.debug(f"GET request to {endpoint} with params: {params}")

        response = await self._client.get(endpoint, params=params)
        return self._handle_response("GET", endpoint, response)

    async def post(
        self, endpoint: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make a POST request to the Affinity API.

        Args:
            endpoint: The API endpoint path (e.g. '/notes')
            body: Dictionary of data to send in the body of the request.

        Returns:
            Dictionary containing the API response, or None for empty responses.

        Raises:
            AffinityAPIError: For Affinity API errors
            httpx.RequestError: For connection/timeout errors
            json.JSONDecodeError: For invalid JSON in response body
        """
        logger.debug(f"POST request to {endpoint} with body: {body}")

        response = await self._client.post(endpoint, json=body)
        return self._handle_response("POST", endpoint, response)

    def _handle_response(
        self, method: str, endpoint: str, response: httpx.Response
    ) -> dict[str, Any] | None:
        """Handle HTTP response by raising error if present, otherwise return JSON.

        Args:
            method: HTTP method used (e.g. 'GET')
            endpoint: API endpoint that was called
            response: The HTTP response from httpx

        Returns:
            Dictionary containing the API response, or None for empty responses.

        Raises:
            AffinityAPIError: For Affinity API errors
            httpx.RequestError: For connection/timeout errors
            json.JSONDecodeError: For invalid JSON in response body
        """
        if response.is_error:
            error_message = self._parse_error_message(response)

            logger.error(
                f"HTTP error {response.status_code} on {method} {endpoint}: {error_message}"
            )

            if response.status_code == 403:
                error_message = f"{error_message}. Please contact your Affinity Admin for help gaining access."

            raise AffinityAPIError(error_message, response.status_code)

        logger.info(f"Success: {method} {endpoint} -> {response.status_code}")
        if response.status_code == 204:
            return None

        return response.json()

    def _parse_error_message(self, response: httpx.Response) -> str:
        """Parse error message from HTTP response.

        Handles both v1 and v2 API error formats:
        - v1 - list of error messages: ["error string 1", "error string 2", ...]
        - v2 - list of error objects: {"errors": [{"message": "...", "code": "..."}, ...]}

        Args:
            response: The HTTP response

        Returns:
            String containing all error messages joined with "; "
        """
        try:
            error_data = response.json()

            # Handles API v2 format: {"errors": [{"message": "...", "code": "..."}, ...]}
            if isinstance(error_data, dict) and "errors" in error_data:
                error_messages = [
                    err.get("message", str(err)) for err in error_data["errors"]
                ]
                return "; ".join(error_messages)

            # Handles API v1 format: ["error string 1", "error string 2", ...]
            elif isinstance(error_data, list):
                return "; ".join(str(err) for err in error_data)
            else:
                return response.text

        except JSONDecodeError:
            return response.text
