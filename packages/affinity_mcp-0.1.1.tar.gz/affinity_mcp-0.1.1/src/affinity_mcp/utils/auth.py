from typing import Any
from .affinity_api import AffinityAPI

_user_cache: dict[str, Any] | None = None


async def fetch_current_user() -> dict[str, Any]:
    """Fetch current user information with caching.

    Makes an API call to the V2 whoami endpoint on first invocation and caches
    the result. Subsequent calls return the cached data without additional API requests.

    Returns:
        Current user information including tenant details and API permissions.
    """
    global _user_cache
    if _user_cache is None:
        async with AffinityAPI() as client:
            _user_cache = await client.get("/v2/auth/whoami")
    return _user_cache
