import os
from abc import ABC, abstractmethod

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from collections.abc import Callable, Awaitable
from typing import Any, Literal, cast
from .tools import read_only_tools, write_tools
from starlette.requests import Request
from starlette.responses import PlainTextResponse


def add_read_only_tool(
    mcp_instance: FastMCP, tool: Callable[..., Awaitable[Any]]
) -> None:
    """Add a read-only tool to the MCP server. Annotations indicate to the
    client that this tool is read-only, non-destructive, and idempotent.

    Args:
        mcp_instance: The MCP server instance
        tool: The tool to register
    """
    annotations = ToolAnnotations(
        readOnlyHint=True, destructiveHint=False, idempotentHint=True
    )
    mcp_instance.add_tool(tool, annotations=annotations)


def add_write_tool(mcp_instance: FastMCP, tool: Callable[..., Awaitable[Any]]) -> None:
    """Add a write tool to the MCP server. Annotations indicate to the
    client that this tool is destructive (not read-only, not idempotent)
    and requires user confirmation before execution.

    Args:
        mcp_instance: The MCP server instance
        tool: The tool to register
    """
    annotations = ToolAnnotations(
        readOnlyHint=False, destructiveHint=True, idempotentHint=False
    )
    mcp_instance.add_tool(tool, annotations=annotations)


def add_tools(mcp_instance: FastMCP) -> None:
    """Add read-only and write tools with annotations to the MCP server."""
    for read_only_tool in read_only_tools:
        add_read_only_tool(mcp_instance, read_only_tool)

    for write_tool in write_tools:
        add_write_tool(mcp_instance, write_tool)


class TransportStrategy(ABC):
    @abstractmethod
    def create_server(self) -> FastMCP: ...


class StdioTransport(TransportStrategy):
    def create_server(self) -> FastMCP:
        return FastMCP("Affinity MCP")


class StreamableHttpTransport(TransportStrategy):
    def create_server(self) -> FastMCP:
        port_str = os.environ.get("MCP_PORT", "8000")

        try:
            port = int(port_str)
        except ValueError as exc:
            raise ValueError(f"Invalid MCP_PORT: {port_str}") from exc

        mcp = FastMCP(
            "Affinity MCP",
            host=os.environ.get("MCP_HOST", "127.0.0.1"),
            port=port,
        )

        @mcp.custom_route("/healthz", methods=["GET"])
        async def health_check(request: Request) -> PlainTextResponse:
            return PlainTextResponse("OK")

        return mcp


TRANSPORT_STRATEGIES: dict[str, type[TransportStrategy]] = {
    "stdio": StdioTransport,
    "streamable-http": StreamableHttpTransport,
}


def create_server(transport: str) -> FastMCP:
    """Create and configure the MCP server instance.

    Args:
        transport: Transport mechanism to use for the server. Must be one of
            "stdio" or "streamable-http".

    Returns:
        FastMCP: Configured server instance with all tools registered.

    Raises:
        ValueError: If an invalid transport value is provided.
    """
    strategy_cls = TRANSPORT_STRATEGIES.get(transport)
    if strategy_cls is None:
        raise ValueError(
            f"Invalid MCP_TRANSPORT: {transport}. "
            f"Must be one of: {', '.join(TRANSPORT_STRATEGIES)}"
        )
    mcp = strategy_cls().create_server()
    add_tools(mcp)
    return mcp


def main() -> None:
    """Entry point for the MCP server."""
    transport = os.environ.get("MCP_TRANSPORT", "stdio")
    mcp = create_server(transport)
    mcp.run(transport=cast(Literal["stdio", "streamable-http"], transport))


if __name__ == "__main__":
    main()
