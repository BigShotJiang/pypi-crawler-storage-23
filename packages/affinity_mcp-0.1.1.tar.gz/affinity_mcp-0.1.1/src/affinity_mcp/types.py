from enum import StrEnum, IntEnum


class EntityType(StrEnum):
    """Entity types for company, person, and opportunity."""

    COMPANY = "company"
    PERSON = "person"
    OPPORTUNITY = "opportunity"

    def to_plural(self) -> str:
        return {
            EntityType.COMPANY: "companies",
            EntityType.PERSON: "persons",
            EntityType.OPPORTUNITY: "opportunities",
        }[self]


class FieldType(StrEnum):
    """Available field types for entity queries."""

    ENRICHED = "enriched"
    GLOBAL = "global"
    RELATIONSHIP_INTELLIGENCE = "relationship-intelligence"
    LIST = "list"

    @classmethod
    def all(cls) -> list[str]:
        return [ft.value for ft in cls]

    @classmethod
    def entity_field_types(cls) -> list[str]:
        """Get field types applicable to entities (person/company).

        Excludes 'list' as it's only applicable to list entries.
        """
        return [ft.value for ft in cls if ft != cls.LIST]


class LoggingType(IntEnum):
    """Logging type classification for interactions."""

    ALL = 0
    MANUAL = 1


class InteractionType(IntEnum):
    """Types of interactions"""

    MEETING = 0
