import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.fields import get_entity_fields, get_list_fields
from affinity_mcp.types import EntityType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_fields_api = mocker.patch("affinity_mcp.tools.fields.AffinityAPI")
    mock_fields_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.fixture
def mock_get_list_fields_response():
    return {
        "data": [
            {
                "id": "field-1",
                "name": "Custom global field",
                "type": "global",
                "valueType": "text",
                "enrichmentSource": None,
            },
            {
                "id": "field-2",
                "name": "Custom list field",
                "type": "list",
                "valueType": "text",
                "enrichmentSource": None,
            },
            {
                "id": "first-chat-message",
                "name": "First Chat Message",
                "type": "relationship-intelligence",
                "valueType": "interaction",
                "enrichmentSource": None,
            },
        ],
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/lists/1/fields?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": "https://api.affinity.co/v2/lists/1/fields?cursor=JnPgICAgIGFmdGVyOjo6NA",
        },
    }


@pytest.mark.asyncio
async def test_get_entity_fields_for_company_with_defaults(mock_affinity_api):
    mock_response = {
        "data": [
            {
                "id": "affinity-data-location",
                "name": "Location",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "valueType": "location",
            },
            {
                "id": "global-field-1",
                "name": "Industry",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "valueType": "text",
            },
        ],
        "pagination": {
            "nextUrl": None,
            "prevUrl": None,
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_entity_fields(EntityType.COMPANY)

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/fields", params={"limit": 100}
    )


@pytest.mark.asyncio
async def test_get_entity_fields_for_person_with_defaults(mock_affinity_api):
    mock_response = {
        "data": [
            {
                "id": "affinity-data-job-title",
                "name": "Job Title",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "valueType": "text",
            },
            {
                "id": "global-field-2",
                "name": "LinkedIn",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "valueType": "text",
            },
        ],
        "pagination": {
            "nextUrl": None,
            "prevUrl": None,
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_entity_fields(EntityType.PERSON)

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/fields", params={"limit": 100}
    )


@pytest.mark.asyncio
async def test_get_entity_fields_with_limit(mock_affinity_api):
    mock_response = {
        "data": [
            {
                "id": "field-1",
                "name": "Field 1",
                "type": "enriched",
                "enrichmentSource": "affinity-data",
                "valueType": "text",
            }
        ],
        "pagination": {
            "nextUrl": "https://api.affinity.co/v2/companies/fields?cursor=next",
            "prevUrl": None,
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_entity_fields(EntityType.COMPANY, limit=50)

    assert mock_response == result
    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/fields", params={"limit": 50}
    )


@pytest.mark.asyncio
async def test_get_entity_fields_with_cursor(mock_affinity_api):
    mock_response = {
        "data": [
            {
                "id": "field-2",
                "name": "Field 2",
                "type": "global",
                "enrichmentSource": "affinity-data",
                "valueType": "number",
            }
        ],
        "pagination": {
            "nextUrl": None,
            "prevUrl": "https://api.affinity.co/v2/persons/fields?cursor=prev",
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_entity_fields(EntityType.PERSON, cursor="ICAgICAgIGFmdGVyOjo6NA")

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/persons/fields", params={"cursor": "ICAgICAgIGFmdGVyOjo6NA", "limit": 100}
    )


@pytest.mark.asyncio
async def test_get_entity_fields_with_cursor_and_limit(mock_affinity_api):
    mock_response = {
        "data": [],
        "pagination": {
            "nextUrl": None,
            "prevUrl": "https://api.affinity.co/v2/companies/fields?cursor=KCBgIHAg3b5mb3plOk06CV",
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_entity_fields(
        EntityType.COMPANY, cursor="ICAgICAgYmVmb3JlOjo6Nw", limit=25
    )

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/companies/fields",
        params={"cursor": "ICAgICAgYmVmb3JlOjo6Nw", "limit": 25},
    )


@pytest.mark.asyncio
async def test_get_list_fields_with_defaults(
    mock_affinity_api, mock_get_list_fields_response
):
    mock_affinity_api.get.return_value = mock_get_list_fields_response

    result = await get_list_fields(1)

    assert mock_get_list_fields_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/fields",
        params={"limit": 100},
    )


@pytest.mark.asyncio
async def test_get_list_fields_with_limit(
    mock_affinity_api, mock_get_list_fields_response
):
    mock_affinity_api.get.return_value = mock_get_list_fields_response

    result = await get_list_fields(1, limit=10)

    assert mock_get_list_fields_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/fields",
        params={"limit": 10},
    )


@pytest.mark.asyncio
async def test_get_list_fields_with_cursor(
    mock_affinity_api, mock_get_list_fields_response
):
    mock_get_list_fields_response["pagination"]["nextUrl"] = (
        "https://api.affinity.co/v2/lists/1/fields?cursor=K2mgICAgIQFmdGVyOlo60b"
    )
    mock_affinity_api.get.return_value = mock_get_list_fields_response

    result = await get_list_fields(1, cursor="JnPgICAgIGFmdGVyOjo6NA")

    assert mock_get_list_fields_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/fields",
        params={"cursor": "JnPgICAgIGFmdGVyOjo6NA", "limit": 100},
    )


@pytest.mark.asyncio
async def test_get_list_fields_with_cursor_and_limit(
    mock_affinity_api, mock_get_list_fields_response
):
    mock_get_list_fields_response["pagination"]["nextUrl"] = (
        "https://api.affinity.co/v2/lists/1/fields?cursor=K2mgICAgIQFmdGVyOlo60b"
    )
    mock_affinity_api.get.return_value = mock_get_list_fields_response

    result = await get_list_fields(1, cursor="JnPgICAgIGFmdGVyOjo6NA", limit=25)

    assert mock_get_list_fields_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/fields",
        params={"cursor": "JnPgICAgIGFmdGVyOjo6NA", "limit": 25},
    )
