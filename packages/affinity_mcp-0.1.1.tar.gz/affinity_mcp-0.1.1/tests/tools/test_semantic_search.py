import pytest
import httpx
from unittest.mock import AsyncMock
from affinity_mcp.tools.semantic_search import (
    semantic_search,
)
from affinity_mcp.types import EntityType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_semantic_search_api = mocker.patch(
        "affinity_mcp.tools.semantic_search.AffinityAPI"
    )
    mock_semantic_search_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.mark.asyncio
async def test_semantic_search(mock_affinity_api):
    mock_response = {
        "explanation": "Find companies similar to OpenAI based on their business model and focus areas.",
        "data": [
            {
                "id": 1040,
                "name": "OpenAI",
                "domain": "openai.com",
                "enrichmentSource": "none",
                "isEnriched": False,
                "photoUrl": "https://rustfs.dev.affinity.vc/affinity-persons-public-photos-dev/companies/openai.com",
                "affinityIndustries": ["Artificial Intelligence", "Machine Learning"],
                "score": "0.6959389374244556",
            }
        ],
    }
    mock_affinity_api.post.return_value = mock_response

    result = await semantic_search("Find companies like OpenAI")

    assert mock_response == result
    mock_affinity_api.post.assert_called_once_with(
        "/v2/semantic-search",
        body={
            "prompt": "Find companies like OpenAI",
            "limit": 10,
            "entityType": "companies",
        },
    )


@pytest.mark.asyncio
async def test_semantic_search_with_limit(mock_affinity_api):
    mock_response = {
        "explanation": "Find companies similar to OpenAI based on their business model and focus areas.",
        "data": [
            {
                "id": 1040,
                "name": "OpenAI",
                "domain": "openai.com",
                "enrichmentSource": "none",
                "isEnriched": False,
                "photoUrl": "https://rustfs.dev.affinity.vc/affinity-persons-public-photos-dev/companies/openai.com",
                "affinityIndustries": ["Artificial Intelligence", "Machine Learning"],
                "score": "0.6959389374244556",
            }
        ],
    }
    mock_affinity_api.post.return_value = mock_response

    result = await semantic_search("Find companies like OpenAI", limit=100)

    assert mock_response == result
    mock_affinity_api.post.assert_called_once_with(
        "/v2/semantic-search",
        body={
            "prompt": "Find companies like OpenAI",
            "limit": 100,
            "entityType": "companies",
        },
    )


@pytest.mark.asyncio
async def test_semantic_search_with_limit_less_than_1_passed_to_api(mock_affinity_api):
    request = httpx.Request("POST", "https://api.affinity.co/")
    response = httpx.Response(400, request=request, json={"error": "Invalid limit"})
    error = httpx.HTTPStatusError("Bad Request", request=request, response=response)

    mock_affinity_api.post.side_effect = error

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        await semantic_search(
            prompt="Find companies like OpenAI", limit=0, entity_type=EntityType.COMPANY
        )

    assert exc_info.value.response.status_code == 400

    mock_affinity_api.post.assert_called_once_with(
        "/v2/semantic-search",
        body={
            "prompt": "Find companies like OpenAI",
            "limit": 0,
            "entityType": "companies",
        },
    )


@pytest.mark.asyncio
async def test_semantic_search_with_limit_greater_than_1000_passed_to_api(
    mock_affinity_api,
):
    request = httpx.Request("POST", "https://api.affinity.co/")
    response = httpx.Response(400, request=request, json={"error": "Invalid limit"})
    error = httpx.HTTPStatusError("Bad Request", request=request, response=response)

    mock_affinity_api.post.side_effect = error

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        await semantic_search(
            prompt="Find companies like OpenAI",
            limit=1001,
            entity_type=EntityType.COMPANY,
        )

    assert exc_info.value.response.status_code == 400

    mock_affinity_api.post.assert_called_once_with(
        "/v2/semantic-search",
        body={
            "prompt": "Find companies like OpenAI",
            "limit": 1001,
            "entityType": "companies",
        },
    )
