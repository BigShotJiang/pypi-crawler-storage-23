import pytest
import httpx
from unittest.mock import AsyncMock
from affinity_mcp.tools import meetings
from affinity_mcp.tools.meetings import MeetingsV2AccessError
from affinity_mcp.types import EntityType, LoggingType, InteractionType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()
    mock_api_class = mocker.patch("affinity_mcp.tools.meetings.AffinityAPI")
    mock_api_class.return_value.__aenter__.return_value = mock_api_instance
    return mock_api_instance


@pytest.fixture
def mock_meetings_response():
    return {
        "data": [
            {
                "id": 1,
                "startTime": "2025-01-15T10:00:00Z",
                "endTime": "2025-01-15T11:00:00Z",
                "title": "Team meeting",
                "allDay": False,
                "creator": {
                    "emailAddress": "jsmith@example.com",
                    "person": {
                        "id": 4503599627370496,
                        "firstName": "Joe",
                        "lastName": "Smith",
                        "primaryEmailAddress": "jsmith@example.com",
                        "type": "internal",
                    },
                },
                "organizer": {
                    "emailAddress": "jsmith@example.com",
                    "person": {
                        "id": 4503599627370496,
                        "firstName": "Joe",
                        "lastName": "Smith",
                        "primaryEmailAddress": "jsmith@example.com",
                        "type": "internal",
                    },
                },
                "createdAt": "2025-01-14T16:22:56Z",
                "updatedAt": "2025-01-14T16:22:56Z",
                "attendeesPreview": {
                    "data": [
                        {
                            "emailAddress": "jsmith@example.com",
                            "person": {
                                "id": 4503599627370496,
                                "firstName": "<string>",
                                "lastName": "<string>",
                                "primaryEmailAddress": "jsmith@example.com",
                                "type": "internal",
                            },
                        }
                    ],
                    "totalCount": 4503599627370495,
                },
            }
        ],
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/meetings?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": "https://api.affinity.co/v2/meetings?cursor=test_page_token_123",
        },
    }


@pytest.fixture
def mock_meetings_for_entity_response():
    return {
        "events": [
            {
                "date": "2024-03-21T13:30:00.000-07:00",
                "id": 22996875,
                "attendees": ["john.smith@contoso.com", "jane.doe@example.com"],
                "start_time": "2024-03-21T13:30:00.000-07:00",
                "end_time": "2024-03-21T14:00:00.000-07:00",
                "updated_at": "2026-01-15T12:35:00.447-08:00",
                "manual_creator_id": None,
                "title": "Test Meeting",
                "type": 0,
                "notes": [],
                "persons": [
                    {
                        "id": 1,
                        "type": 1,
                        "first_name": "John",
                        "last_name": "Smith",
                        "primary_email": "john.smith@contoso.com",
                        "emails": ["john.smith@contoso.com"],
                    },
                    {
                        "id": 2,
                        "type": 0,
                        "first_name": "Jane",
                        "last_name": "Doe",
                        "primary_email": "jane.doe@example.com",
                        "emails": ["jane.doe@example.com"],
                    },
                ],
                "ical_uid": "123456",
            }
        ],
        "next_page_token": "test_page_token_123",
    }


@pytest.mark.asyncio
async def test_get_meetings_use_defaults(mock_affinity_api, mock_meetings_response):
    mock_affinity_api.get.return_value = mock_meetings_response

    result = await meetings.get_meetings()
    assert mock_meetings_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/meetings", params={"limit": 20})


@pytest.mark.asyncio
async def test_get_meetings_with_filter_expr(mock_affinity_api, mock_meetings_response):
    mock_affinity_api.get.return_value = mock_meetings_response

    filter_expr = "startTime>=2025-01-01T00:00:00Z & startTime<2025-02-01T00:00:00Z"
    result = await meetings.get_meetings(filter_expr=filter_expr)
    assert mock_meetings_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/meetings", params={"filter": filter_expr, "limit": 20}
    )


@pytest.mark.asyncio
async def test_get_meetings_with_pagination(mock_affinity_api, mock_meetings_response):
    mock_affinity_api.get.return_value = mock_meetings_response

    result = await meetings.get_meetings(cursor="test_page_token_123", limit=50)
    assert mock_meetings_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/meetings", params={"cursor": "test_page_token_123", "limit": 50}
    )


@pytest.mark.asyncio
async def test_get_meetings_with_all_parameters(
    mock_affinity_api, mock_meetings_response
):
    mock_affinity_api.get.return_value = mock_meetings_response

    result = await meetings.get_meetings(
        filter_expr="startTime>2025-01-01T00:00:00Z",
        cursor="test_page_token_123",
        limit=100,
    )
    assert mock_meetings_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/meetings",
        params={
            "filter": "startTime>2025-01-01T00:00:00Z",
            "cursor": "test_page_token_123",
            "limit": 100,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_raises_access_error_on_404(mock_affinity_api):
    mock_response = AsyncMock()
    mock_response.status_code = 404
    error = httpx.HTTPStatusError(
        "Not found", request=AsyncMock(), response=mock_response
    )
    mock_affinity_api.get.side_effect = error

    with pytest.raises(MeetingsV2AccessError) as exc_info:
        await meetings.get_meetings()

    expected_error_msg = (
        "You do not have access to meetings. Please reach out to your Affinity Admin."
    )
    assert expected_error_msg == str(exc_info.value)
    mock_affinity_api.get.assert_called_once_with("/v2/meetings", params={"limit": 20})


@pytest.mark.asyncio
async def test_get_meetings_reraises_non_404(mock_affinity_api):
    mock_response = AsyncMock()
    mock_response.status_code = 500
    error_msg = "Internal server error"
    error = httpx.HTTPStatusError(
        error_msg, request=AsyncMock(), response=mock_response
    )
    mock_affinity_api.get.side_effect = error

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        await meetings.get_meetings()

    assert error_msg == str(exc_info.value)
    mock_affinity_api.get.assert_called_once_with("/v2/meetings", params={"limit": 20})


@pytest.mark.asyncio
async def test_get_meetings_for_entity_company(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=123,
        entity_type=EntityType.COMPANY,
        start_time="2024-01-01T00:00:00Z",
        end_time="2024-12-31T23:59:59Z",
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "organization_id": 123,
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-12-31T23:59:59Z",
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_person(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=2,
        entity_type=EntityType.PERSON,
        start_time="2024-01-01T00:00:00Z",
        end_time="2024-12-31T23:59:59Z",
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "person_id": 2,
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-12-31T23:59:59Z",
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_opportunity(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=789,
        entity_type=EntityType.OPPORTUNITY,
        start_time="2024-01-01T00:00:00Z",
        end_time="2024-12-31T23:59:59Z",
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "opportunity_id": 789,
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-12-31T23:59:59Z",
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_with_internal_person_id(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=123,
        entity_type=EntityType.COMPANY,
        start_time="2024-01-01T00:00:00Z",
        end_time="2024-12-31T23:59:59Z",
        internal_person_id=1,
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "organization_id": 123,
            "internal_person_id": 1,
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-12-31T23:59:59Z",
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_with_time_filters(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=123,
        entity_type=EntityType.COMPANY,
        start_time="2026-02-01T00:00:00Z",
        end_time="2026-02-28T23:59:59Z",
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "organization_id": 123,
            "start_time": "2026-02-01T00:00:00Z",
            "end_time": "2026-02-28T23:59:59Z",
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_with_logging_type(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=123,
        entity_type=EntityType.COMPANY,
        start_time="2024-01-01T00:00:00Z",
        end_time="2024-12-31T23:59:59Z",
        logging_type=LoggingType.MANUAL,
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "organization_id": 123,
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-12-31T23:59:59Z",
            "logging_type": 1,
            "page_size": 10,
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_with_pagination(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=2,
        entity_type=EntityType.PERSON,
        start_time="2024-01-01T00:00:00Z",
        end_time="2024-12-31T23:59:59Z",
        page_size=50,
        page_token="test_page_token_123",
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "person_id": 2,
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-12-31T23:59:59Z",
            "page_size": 50,
            "page_token": "test_page_token_123",
        },
    )


@pytest.mark.asyncio
async def test_get_meetings_for_entity_with_all_parameters(
    mock_affinity_api, mock_meetings_for_entity_response
):
    mock_affinity_api.get.return_value = mock_meetings_for_entity_response

    result = await meetings.get_meetings_for_entity(
        entity_id=123,
        entity_type=EntityType.COMPANY,
        internal_person_id=999,
        start_time="2026-02-01T00:00:00Z",
        end_time="2026-02-28T23:59:59Z",
        logging_type=LoggingType.ALL,
        page_size=100,
        page_token="token123",
    )

    assert result == mock_meetings_for_entity_response
    mock_affinity_api.get.assert_called_once_with(
        "/interactions",
        params={
            "type": InteractionType.MEETING,
            "organization_id": 123,
            "internal_person_id": 999,
            "start_time": "2026-02-01T00:00:00Z",
            "end_time": "2026-02-28T23:59:59Z",
            "logging_type": 0,
            "page_size": 100,
            "page_token": "token123",
        },
    )
