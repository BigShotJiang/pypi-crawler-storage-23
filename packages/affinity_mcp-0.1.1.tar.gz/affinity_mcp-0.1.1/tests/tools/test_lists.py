import pytest
from unittest.mock import AsyncMock
from affinity_mcp.tools.lists import (
    get_lists,
    get_list_info,
    get_list_entries,
    get_single_list_entry,
)
from affinity_mcp.types import FieldType


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()

    mock_lists_api = mocker.patch("affinity_mcp.tools.lists.AffinityAPI")
    mock_lists_api.return_value.__aenter__.return_value = mock_api_instance

    return mock_api_instance


@pytest.fixture
def mock_construct_tenant_url(mocker):
    mock = mocker.patch("affinity_mcp.tools.lists.construct_tenant_url")
    mock.return_value = "https://contoso.affinity.co"
    return mock


@pytest.fixture
def mock_get_list_entries_response():
    return {
        "data": [
            {
                "id": 1,
                "type": "company",
                "listId": 1,
                "entity": {
                    "id": 1,
                    "name": "Acme",
                    "domain": "acme.co",
                    "domains": ["acme.co"],
                    "isGlobal": True,
                    "fields": [
                        {
                            "id": "affinity-data-description",
                            "name": "Description",
                            "type": "enriched",
                            "enrichmentSource": "affinity-data",
                            "value": {
                                "type": "text",
                                "data": "Acme is a mega-corporation that manufactures everything from anvils to earthquake pills.",
                            },
                        },
                        {
                            "id": "affinity-data-industry",
                            "name": "Industry",
                            "type": "enriched",
                            "enrichmentSource": "affinity-data",
                            "value": {
                                "type": "filterable-text-multi",
                                "data": ["Aerospace", "Construction", "Consumer Goods"],
                            },
                        },
                    ],
                },
                "creatorId": 1,
                "createdAt": "2023-01-01T00:00:00Z",
            }
        ],
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/lists/1/list-entries?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": "https://api.affinity.co/v2/lists/1/list-entries?cursor=ICAgICAgIGFmdGVyOjo6NA",
        },
    }


@pytest.mark.asyncio
async def test_get_lists(mock_affinity_api):
    mock_response = {
        "data": [
            {
                "id": 1,
                "name": "My Companies",
                "type": "company",
                "isPublic": False,
                "ownerId": 1,
                "creatorId": 1,
            },
            {
                "id": 2,
                "name": "My Persons",
                "type": "person",
                "isPublic": False,
                "ownerId": 1,
                "creatorId": 1,
            },
        ],
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/lists?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": "https://api.affinity.co/v2/lists?cursor=ICAgICAgIGFmdGVyOjo6NA",
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_lists()

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with("/v2/lists", params={"limit": 100})


@pytest.mark.asyncio
async def test_get_lists_with_pagination(mock_affinity_api):
    mock_response = {
        "data": [
            {
                "id": 1,
                "name": "My Companies",
                "type": "company",
                "isPublic": False,
                "ownerId": 1,
                "creatorId": 1,
            }
        ],
        "pagination": {
            "prevUrl": "https://api.affinity.co/v2/lists?cursor=ICAgICAgYmVmb3JlOjo6Nw",
            "nextUrl": None,
        },
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_lists("ICAgICAgIGFmdGVyOjo6NA", 1)

    assert mock_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists", params={"cursor": "ICAgICAgIGFmdGVyOjo6NA", "limit": 1}
    )


@pytest.mark.asyncio
async def test_get_list_info(mock_affinity_api, mock_construct_tenant_url):
    mock_response = {
        "id": 1,
        "name": "My Companies",
        "type": "company",
        "isPublic": False,
        "ownerId": 1,
        "creatorId": 1,
    }

    mock_affinity_api.get.return_value = mock_response

    result = await get_list_info(1)
    expected_result = {
        **mock_response,
        "list_url": "https://contoso.affinity.co/lists/1",
    }
    assert expected_result == result

    mock_affinity_api.get.assert_called_once_with("/v2/lists/1")


@pytest.mark.asyncio
async def test_get_list_entries_with_defaults(
    mock_affinity_api, mock_get_list_entries_response
):
    mock_affinity_api.get.return_value = mock_get_list_entries_response

    result = await get_list_entries(list_id=1)

    assert mock_get_list_entries_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries",
        params={
            "limit": 10,
            "fieldTypes": ["list"],
        },
    )


@pytest.mark.asyncio
async def test_get_list_entries_with_pagination(
    mock_affinity_api, mock_get_list_entries_response
):
    mock_get_list_entries_response["pagination"]["nextUrl"] = None
    mock_affinity_api.get.return_value = mock_get_list_entries_response

    result = await get_list_entries(
        list_id=1, cursor="ICAgICAgIGFmdGVyOjo6NA", limit=20
    )

    assert mock_get_list_entries_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries",
        params={
            "cursor": "ICAgICAgIGFmdGVyOjo6NA",
            "limit": 20,
            "fieldTypes": ["list"],
        },
    )


@pytest.mark.asyncio
async def test_get_list_entries_with_field_types(
    mock_affinity_api, mock_get_list_entries_response
):
    mock_affinity_api.get.return_value = mock_get_list_entries_response

    result = await get_list_entries(
        list_id=1, field_types=[FieldType.ENRICHED, FieldType.LIST]
    )

    assert mock_get_list_entries_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries",
        params={"limit": 10, "fieldTypes": ["enriched", "list"]},
    )


@pytest.mark.asyncio
async def test_get_list_entries_with_field_ids(
    mock_affinity_api, mock_get_list_entries_response
):
    mock_affinity_api.get.return_value = mock_get_list_entries_response

    result = await get_list_entries(
        list_id=1,
        field_ids=["affinity-data-description", "affinity-data-industry"],
    )

    assert mock_get_list_entries_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries",
        params={
            "limit": 10,
            "fieldIds": ["affinity-data-description", "affinity-data-industry"],
        },
    )


@pytest.mark.asyncio
async def test_get_list_entries_with_field_ids_and_field_types(
    mock_affinity_api, mock_get_list_entries_response
):
    mock_affinity_api.get.return_value = mock_get_list_entries_response

    result = await get_list_entries(
        list_id=1,
        field_ids=["affinity-data-description", "affinity-data-industry"],
        field_types=[FieldType.ENRICHED],
    )

    assert mock_get_list_entries_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries",
        params={
            "limit": 10,
            "fieldIds": ["affinity-data-description", "affinity-data-industry"],
            "fieldTypes": ["enriched"],
        },
    )


@pytest.fixture
def mock_get_single_list_entry_response():
    return {
        "id": 1,
        "type": "company",
        "listId": 1,
        "entity": {
            "id": 1,
            "name": "Acme",
            "domain": "acme.co",
            "domains": ["acme.co"],
            "isGlobal": True,
            "fields": [
                {
                    "id": "affinity-data-description",
                    "name": "Description",
                    "type": "enriched",
                    "enrichmentSource": "affinity-data",
                    "value": {
                        "type": "text",
                        "data": "Acme is a mega-corporation that manufactures everything from anvils to earthquake pills.",
                    },
                },
                {
                    "id": "affinity-data-industry",
                    "name": "Industry",
                    "type": "enriched",
                    "enrichmentSource": "affinity-data",
                    "value": {
                        "type": "filterable-text-multi",
                        "data": ["Aerospace", "Construction", "Consumer Goods"],
                    },
                },
            ],
        },
        "creatorId": 1,
        "createdAt": "2023-01-01T00:00:00Z",
    }


@pytest.mark.asyncio
async def test_get_single_list_entry_with_defaults(
    mock_affinity_api, mock_get_single_list_entry_response
):
    mock_affinity_api.get.return_value = mock_get_single_list_entry_response

    result = await get_single_list_entry(list_id=1, list_entry_id=1)

    assert mock_get_single_list_entry_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries/1",
        params={
            "fieldTypes": ["list"],
        },
    )


@pytest.mark.asyncio
async def test_get_single_list_entry_with_field_types(
    mock_affinity_api, mock_get_single_list_entry_response
):
    mock_affinity_api.get.return_value = mock_get_single_list_entry_response

    result = await get_single_list_entry(
        list_id=1, list_entry_id=1, field_types=[FieldType.ENRICHED, FieldType.LIST]
    )

    assert mock_get_single_list_entry_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries/1",
        params={"fieldTypes": ["enriched", "list"]},
    )


@pytest.mark.asyncio
async def test_get_single_list_entry_with_field_ids(
    mock_affinity_api, mock_get_single_list_entry_response
):
    mock_affinity_api.get.return_value = mock_get_single_list_entry_response

    result = await get_single_list_entry(
        list_id=1,
        list_entry_id=1,
        field_ids=["affinity-data-description", "affinity-data-industry"],
    )

    assert mock_get_single_list_entry_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries/1",
        params={
            "fieldIds": ["affinity-data-description", "affinity-data-industry"],
        },
    )


@pytest.mark.asyncio
async def test_get_single_list_entry_with_field_ids_and_field_types(
    mock_affinity_api, mock_get_single_list_entry_response
):
    mock_affinity_api.get.return_value = mock_get_single_list_entry_response

    result = await get_single_list_entry(
        list_id=1,
        list_entry_id=1,
        field_ids=["affinity-data-description", "affinity-data-industry"],
        field_types=[FieldType.ENRICHED],
    )

    assert mock_get_single_list_entry_response == result

    mock_affinity_api.get.assert_called_once_with(
        "/v2/lists/1/list-entries/1",
        params={
            "fieldIds": ["affinity-data-description", "affinity-data-industry"],
            "fieldTypes": ["enriched"],
        },
    )
