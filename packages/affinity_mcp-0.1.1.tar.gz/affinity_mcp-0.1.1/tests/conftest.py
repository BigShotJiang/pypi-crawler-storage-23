"""Pytest configuration and shared fixtures."""

import os

# Set ENV_FILE before any imports that might load Settings
os.environ["ENV_FILE"] = ".env.test"
