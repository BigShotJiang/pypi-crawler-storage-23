import pytest
from affinity_mcp.server import create_server, main
from affinity_mcp.tools import read_only_tools, write_tools
from mcp.types import ToolAnnotations
from unittest.mock import MagicMock

from mcp.server.fastmcp import FastMCP
from starlette.testclient import TestClient


def test_no_duplicate_tools_between_read_and_write():
    read_names = {t.__name__ for t in read_only_tools}
    write_names = {t.__name__ for t in write_tools}

    duplicates = read_names & write_names
    assert len(duplicates) == 0


@pytest.mark.asyncio
async def test_create_server_registers_all_tools():
    server = create_server("stdio")
    registered_tools = await server.list_tools()

    registered_tool_names = {tool.name for tool in registered_tools}
    expected_tool_names = {tool.__name__ for tool in read_only_tools + write_tools}
    assert expected_tool_names == registered_tool_names


@pytest.mark.asyncio
async def test_create_server_registers_tools_with_correct_annotations():
    server = create_server("stdio")
    registered_tools = await server.list_tools()

    tools_by_name = {tool.name: tool for tool in registered_tools}
    for tool_func in read_only_tools:
        tool_name = tool_func.__name__
        tool = tools_by_name[tool_name]
        annotations = tool.annotations
        assert_read_only_annotations(annotations)

    for tool_func in write_tools:
        tool_name = tool_func.__name__
        tool = tools_by_name[tool_name]
        annotations = tool.annotations
        assert_write_annotations(annotations)


def assert_read_only_annotations(annotations):
    assert isinstance(annotations, ToolAnnotations)
    assert annotations.readOnlyHint is True
    assert annotations.destructiveHint is False
    assert annotations.idempotentHint is True


def assert_write_annotations(annotations):
    assert isinstance(annotations, ToolAnnotations)
    assert annotations.readOnlyHint is False
    assert annotations.destructiveHint is True
    assert annotations.idempotentHint is False


async def mock_tool():
    pass


def test_main_invalid_transport_raises(monkeypatch):
    monkeypatch.setenv("MCP_TRANSPORT", "invalid")
    with pytest.raises(ValueError, match="Invalid MCP_TRANSPORT"):
        main()


def test_main_invalid_port_raises(monkeypatch):
    monkeypatch.setenv("MCP_TRANSPORT", "streamable-http")
    monkeypatch.setenv("MCP_PORT", "not_a_number")
    with pytest.raises(ValueError, match="Invalid MCP_PORT"):
        main()


def test_main_stdio_default(monkeypatch, mocker):
    monkeypatch.delenv("MCP_TRANSPORT", raising=False)
    mock_mcp = MagicMock()
    mock_fastmcp_cls = mocker.patch(
        "affinity_mcp.server.FastMCP", return_value=mock_mcp
    )
    mocker.patch("affinity_mcp.server.add_tools")

    main()

    mock_fastmcp_cls.assert_called_once_with("Affinity MCP")
    mock_mcp.run.assert_called_once_with(transport="stdio")


def test_main_stdio_explicit(monkeypatch, mocker):
    monkeypatch.setenv("MCP_TRANSPORT", "stdio")
    mock_mcp = MagicMock()
    mock_fastmcp_cls = mocker.patch(
        "affinity_mcp.server.FastMCP", return_value=mock_mcp
    )
    mocker.patch("affinity_mcp.server.add_tools")

    main()

    mock_fastmcp_cls.assert_called_once_with("Affinity MCP")
    mock_mcp.run.assert_called_once_with(transport="stdio")


def test_main_streamable_http_defaults(monkeypatch, mocker):
    monkeypatch.setenv("MCP_TRANSPORT", "streamable-http")
    monkeypatch.delenv("MCP_HOST", raising=False)
    monkeypatch.delenv("MCP_PORT", raising=False)
    mock_mcp = MagicMock()
    mock_fastmcp_cls = mocker.patch(
        "affinity_mcp.server.FastMCP", return_value=mock_mcp
    )
    mocker.patch("affinity_mcp.server.add_tools")

    main()

    mock_fastmcp_cls.assert_called_once_with(
        "Affinity MCP", host="127.0.0.1", port=8000
    )
    mock_mcp.run.assert_called_once_with(transport="streamable-http")


def test_main_streamable_http_custom_host_port(monkeypatch, mocker):
    monkeypatch.setenv("MCP_TRANSPORT", "streamable-http")
    monkeypatch.setenv("MCP_HOST", "0.0.0.0")
    monkeypatch.setenv("MCP_PORT", "9090")
    mock_mcp = MagicMock()
    mock_fastmcp_cls = mocker.patch(
        "affinity_mcp.server.FastMCP", return_value=mock_mcp
    )
    mocker.patch("affinity_mcp.server.add_tools")

    main()

    mock_fastmcp_cls.assert_called_once_with("Affinity MCP", host="0.0.0.0", port=9090)
    mock_mcp.run.assert_called_once_with(transport="streamable-http")


def test_healthz_returns_ok(monkeypatch):
    monkeypatch.setenv("MCP_TRANSPORT", "streamable-http")

    captured_mcp = None

    def stub_run(self, **kwargs):
        nonlocal captured_mcp
        captured_mcp = self

    monkeypatch.setattr(FastMCP, "run", stub_run)

    main()

    app = captured_mcp.streamable_http_app()
    client = TestClient(app)

    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.text == "OK"
