import pytest
from unittest.mock import AsyncMock
import affinity_mcp.utils.auth
from affinity_mcp.utils.auth import fetch_current_user


@pytest.fixture
def mock_affinity_api(mocker):
    mock_api_instance = AsyncMock()
    mock_api_class = mocker.patch("affinity_mcp.utils.auth.AffinityAPI")
    mock_api_class.return_value.__aenter__.return_value = mock_api_instance
    return mock_api_instance


@pytest.fixture(autouse=True)
def reset_user_cache():
    affinity_mcp.utils.auth._user_cache = None
    yield
    affinity_mcp.utils.auth._user_cache = None


@pytest.mark.asyncio
async def test_fetch_current_user_calls_api(mock_affinity_api):
    mock_response = {
        "grant": {
            "createdAt": "2023-01-01T00:00:00Z",
            "scopes": ["api"],
            "type": "api-key",
        },
        "user": {
            "firstName": "John",
            "lastName": "Smith",
            "emailAddress": "john.smith@test-org.com",
            "id": 1,
        },
        "tenant": {"name": "Contoso Ltd.", "subdomain": "contoso", "id": 1},
    }
    mock_affinity_api.get.return_value = mock_response

    result = await fetch_current_user()

    assert result == mock_response
    mock_affinity_api.get.assert_called_once_with("/v2/auth/whoami")


@pytest.mark.asyncio
async def test_fetch_current_user_returns_cached_value(mock_affinity_api):
    cached_response = {
        "grant": {
            "createdAt": "2023-01-01T00:00:00Z",
            "scopes": ["api"],
            "type": "api-key",
        },
        "user": {
            "firstName": "John",
            "lastName": "Smith",
            "emailAddress": "john.smith@contoso.com",
            "id": 1,
        },
        "tenant": {"name": "Contoso Ltd.", "subdomain": "contoso", "id": 1},
    }

    affinity_mcp.utils.auth._user_cache = cached_response

    result = await fetch_current_user()

    assert result == cached_response
    mock_affinity_api.get.assert_not_called()
