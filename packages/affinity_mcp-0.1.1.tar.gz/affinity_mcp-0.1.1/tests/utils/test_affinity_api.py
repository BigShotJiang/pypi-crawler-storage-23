"""Tests for Affinity API client."""

import json
from unittest.mock import AsyncMock, Mock

import httpx
import pytest
import importlib.metadata

from affinity_mcp.utils.affinity_api import AffinityAPI, APP_NAME, AffinityAPIError


class TestAffinityAPI:
    def test_init_sets_api_key(self):
        client = AffinityAPI()

        assert client._api_key == "test_api_key"

    def test_init_creates_http_client(self):
        api_client = AffinityAPI()
        assert isinstance(api_client._client, httpx.AsyncClient)
        assert api_client._client._base_url == httpx.URL("https://api.affinity.co/")
        assert api_client._client._timeout.read == 30.0

    def test_headers_property(self):
        api_client = AffinityAPI()
        headers = api_client._headers
        version = importlib.metadata.version(APP_NAME)

        expected_headers = {
            "Accept": "application/json",
            "Authorization": "Bearer test_api_key",
            "User-Agent": f"{APP_NAME}/{version}",
            "X-Client-Id": APP_NAME,
            "X-Client-Version": version,
        }
        assert expected_headers == headers

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        api_client = AffinityAPI()
        async with api_client as client:
            assert client is api_client

    @pytest.mark.asyncio
    async def test_aclose_called_on_exit(self, mocker):
        api_client = AffinityAPI()
        mock_aclose = mocker.patch.object(api_client, "aclose", new_callable=AsyncMock)
        async with api_client:
            pass

        mock_aclose.assert_called_once()

    def test_handle_response_raises_affinity_api_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = True
        mock_response.status_code = 500
        mock_response.text = "Internal server error"
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "500 Internal Server Error", request=Mock(), response=mock_response
        )

        with pytest.raises(AffinityAPIError) as exc_info:
            api_client._handle_response("GET", "/v2/persons", mock_response)

        assert exc_info.value.status_code == 500
        assert str(exc_info.value) == "Internal server error"

    def test_handle_response_return_enhanced_403_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = True
        mock_response.status_code = 403
        mock_response.text = "User does not have access to this feature"
        mock_response.request = Mock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "403 Forbidden", request=Mock(), response=mock_response
        )

        with pytest.raises(AffinityAPIError) as exc_info:
            api_client._handle_response("GET", "/v2/persons/1", mock_response)

        error_message = "User does not have access to this feature. Please contact your Affinity Admin for help gaining access."
        assert exc_info.value.status_code == 403
        assert str(exc_info.value) == error_message

    def test_handle_response_returns_none_for_status_code_204(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 204
        mock_response.text = None

        result = api_client._handle_response("GET", "/get-endpoint", mock_response)

        assert result is None

    def test_handle_response_returns_json_on_success(self):
        api_client = AffinityAPI()
        expected_data = {"id": 123, "name": "Test"}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        result = api_client._handle_response("GET", "/v2/persons", mock_response)

        assert result == expected_data
        mock_response.json.assert_called_once()

    def test_handle_response_raises_json_decode_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.text = "Invalid JSON"
        mock_response.json = lambda: json.loads(mock_response.text)

        with pytest.raises(json.JSONDecodeError):
            api_client._handle_response("GET", "/v2/persons", mock_response)

    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["get", "post"])
    async def test_network_timeout_raises_request_error(self, mocker, method):
        api_client = AffinityAPI()
        mocker.patch.object(
            api_client._client,
            method,
            new_callable=AsyncMock,
            side_effect=httpx.TimeoutException("Request timed out"),
        )
        with pytest.raises(httpx.TimeoutException):
            await getattr(api_client, method)("/v2/persons")

    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["get", "post"])
    async def test_connection_error_raises_request_error(self, mocker, method):
        api_client = AffinityAPI()
        mocker.patch.object(
            api_client._client,
            method,
            new_callable=AsyncMock,
            side_effect=httpx.ConnectError("Connection failed"),
        )
        with pytest.raises(httpx.ConnectError):
            await getattr(api_client, method)("/v2/persons")

    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["get", "post"])
    async def test_raises_json_decode_error(self, mocker, method):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.text = "Invalid JSON"
        mock_response.json = lambda: json.loads(mock_response.text)

        mocker.patch.object(
            api_client._client,
            method,
            new_callable=AsyncMock,
            return_value=mock_response,
        )

        with pytest.raises(json.JSONDecodeError):
            await getattr(api_client, method)("/v2/persons")

    @pytest.mark.asyncio
    async def test_successful_get_request_returns_data(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"id": 123, "name": "Test Person"}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mocker.patch.object(
            api_client._client,
            "get",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.get("/v2/persons/123")

        assert result == expected_data
        mock_response.json.assert_called_once()

    @pytest.mark.asyncio
    async def test_successful_get_request_returns_none(self, mocker):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 204
        mock_response.json.return_value = None

        mocker.patch.object(
            api_client._client,
            "get",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.get("/get-endpoint")

        assert result is None

    @pytest.mark.asyncio
    async def test_successful_get_request_with_query_params(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"results": []}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_get = mocker.patch.object(
            api_client._client,
            "get",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.get(
            "/v2/persons", params={"page_size": 10, "cursor": "abc"}
        )

        assert result == expected_data
        mock_get.assert_called_once_with(
            "/v2/persons", params={"page_size": 10, "cursor": "abc"}
        )

    @pytest.mark.asyncio
    async def test_successful_post_request_returns_data(self, mocker):
        api_client = AffinityAPI()
        expected_data = {"id": 123}
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mocker.patch.object(
            api_client._client,
            "post",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.post("/post-endpoint")

        assert result == expected_data
        mock_response.json.assert_called_once()

    @pytest.mark.asyncio
    async def test_successful_post_request_returns_none(self, mocker):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 204

        mocker.patch.object(
            api_client._client,
            "post",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        result = await api_client.post("/post-endpoint")

        assert result is None

    @pytest.mark.asyncio
    async def test_successful_post_request_with_body(self, mocker):
        api_client = AffinityAPI()
        expected_data = {
            "id": 123,
            "creator_id": 1,
            "person_ids": [2],
            "content": "this is a note",
            "type": 2,
        }
        mock_response = Mock(spec=httpx.Response)
        mock_response.is_error = False
        mock_response.status_code = 200
        mock_response.json.return_value = expected_data

        mock_post = mocker.patch.object(
            api_client._client,
            "post",
            new_callable=AsyncMock,
            return_value=mock_response,
        )
        body = {
            "creator_id": 1,
            "person_ids": [2],
            "content": "this is a note",
            "type": 2,
        }
        result = await api_client.post("/notes", body=body)

        assert result == expected_data
        mock_post.assert_called_once_with("/notes", json=body)

    def test_parse_error_message_from_api_v2_format_single_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {
            "errors": [{"message": "Malformed field", "code": "VALIDATION_ERROR"}]
        }

        result = api_client._parse_error_message(mock_response)

        assert result == "Malformed field"

    def test_parse_error_message_from_api_v2_format_multiple_errors(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {
            "errors": [
                {"message": "Malformed field", "code": "VALIDATION_ERROR"},
                {"message": "Missing required field", "code": "VALIDATION_ERROR"},
            ]
        }

        result = api_client._parse_error_message(mock_response)

        assert result == "Malformed field; Missing required field"

    def test_parse_error_message_from_api_v2_format_error_without_message(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {"errors": [{"code": "UNKNOWN_ERROR"}]}

        result = api_client._parse_error_message(mock_response)

        assert result == "{'code': 'UNKNOWN_ERROR'}"

    def test_parse_error_message_from_api_v1_format_single_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = ["Invalid API key"]

        result = api_client._parse_error_message(mock_response)

        assert result == "Invalid API key"

    def test_parse_error_message_from_api_v1_format_multiple_errors(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = [
            "Invalid API key",
            "Missing required field",
        ]

        result = api_client._parse_error_message(mock_response)

        assert result == "Invalid API key; Missing required field"

    def test_parse_error_message_unknown_format(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {"error": "Something went wrong"}
        mock_response.text = "Something went wrong"

        result = api_client._parse_error_message(mock_response)

        assert result == "Something went wrong"

    def test_parse_error_message_json_decode_error(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.side_effect = json.JSONDecodeError("error", "doc", 0)
        mock_response.text = "Internal Server Error"

        result = api_client._parse_error_message(mock_response)

        assert result == "Internal Server Error"

    def test_parse_error_message_empty_v2_errors_list(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = {"errors": []}

        result = api_client._parse_error_message(mock_response)

        assert result == ""

    def test_parse_error_message_empty_v1_errors_list(self):
        api_client = AffinityAPI()
        mock_response = Mock(spec=httpx.Response)
        mock_response.json.return_value = []

        result = api_client._parse_error_message(mock_response)

        assert result == ""
