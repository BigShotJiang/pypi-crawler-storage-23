# Security Policy

**⚠️ Please do not open public GitHub issues for security vulnerabilities.**

Security is of utmost importance to us at Affinity. In pursuit of the best possible security for our service, we welcome responsible disclosure of any vulnerability you find in Affinity. We use HackerOne to triage, track, and potentially reward all vulnerabilities found by external researchers.

If you believe you've discovered a potential vulnerability or if you have any questions about our scope and bug bounty policies, please request an invite to our HackerOne program by sending us a note at **security@affinity.co**.

Happy hunting!
