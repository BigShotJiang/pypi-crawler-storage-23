# Feature: git-catcher, Property 8: Exponential backoff with cap
"""Property 8: Exponential backoff with cap

**Validates: Requirements 5.2, 5.3**

For any 초기 delay d와 최대 delay max_d에 대해,
n번 연속 실패 후 재연결 대기 시간은 min(d * 2^n, max_d)이어야 한다.
"""
from hypothesis import given, settings, strategies as st

from git_catcher.smee_client import calculate_backoff


@settings(max_examples=200)
@given(
    attempt=st.integers(min_value=0, max_value=20),
    initial_delay=st.integers(min_value=1, max_value=60),
    max_delay=st.integers(min_value=1, max_value=3600),
)
def test_exponential_backoff_with_cap(attempt, initial_delay, max_delay):
    """Property 8: delay == min(initial_delay * 2^attempt, max_delay)

    **Validates: Requirements 5.2, 5.3**
    """
    # max_delay는 initial_delay 이상이어야 의미 있는 설정
    if max_delay < initial_delay:
        max_delay = initial_delay

    result = calculate_backoff(attempt, initial_delay, max_delay)
    expected = min(initial_delay * (2 ** attempt), max_delay)

    assert result == expected, (
        f"attempt={attempt}, initial_delay={initial_delay}, max_delay={max_delay}: "
        f"got {result}, expected {expected}"
    )
