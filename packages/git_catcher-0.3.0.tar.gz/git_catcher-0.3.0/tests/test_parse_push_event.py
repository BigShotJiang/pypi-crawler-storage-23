"""Property-based tests for parse_push_event.

# Feature: git-catcher, Property 4: Push 이벤트 파싱 round-trip
**Validates: Requirements 3.1, 3.3**
"""
from hypothesis import given, settings
from hypothesis import strategies as st

from git_catcher.smee_client import parse_push_event

# 전략: 유효한 git 브랜치명 (non-empty, 슬래시 허용하되 git ref 규칙 준수)
# refs/heads/ 제거 후 round-trip이 성립하려면 printable ASCII 중 안전한 문자 사용
_branch_chars = st.sampled_from(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "-_/"
)
branch_strategy = (
    st.text(alphabet=_branch_chars, min_size=1, max_size=100)
    .filter(lambda b: not b.startswith("/"))
    .filter(lambda b: not b.endswith("/"))
    .filter(lambda b: "//" not in b)
)

# 전략: 커밋 메시지 (임의의 텍스트, 빈 문자열 포함하지 않음 — 실제 커밋은 메시지 필수)
message_strategy = st.text(min_size=1, max_size=500)


@given(branch=branch_strategy, message=message_strategy)
@settings(max_examples=200)
def test_push_event_parsing_roundtrip(branch: str, message: str):
    """Property 4: Push 이벤트 파싱 round-trip

    # Feature: git-catcher, Property 4: Push 이벤트 파싱 round-trip
    **Validates: Requirements 3.1, 3.3**

    For any 유효한 브랜치명과 커밋 메시지에 대해,
    {"ref": "refs/heads/<branch>", "head_commit": {"message": "<message>"}}를
    parse_push_event에 전달하면 (branch, message) tuple을 반환해야 한다.
    """
    # Arrange: push 이벤트 payload 구성
    payload = {
        "ref": f"refs/heads/{branch}",
        "head_commit": {"message": message},
    }

    # Act
    result = parse_push_event(payload)

    # Assert: round-trip 성립 — 입력한 branch와 message가 그대로 반환
    assert result is not None
    assert result == (branch, message)


# --- Property 5: Non-branch ref 무시 ---

# 전략: refs/heads/ 로 시작하지 않는 ref 문자열 생성
_non_branch_prefixes = st.sampled_from(["refs/tags/", "refs/pull/", "refs/remotes/", ""])
_suffix = st.text(min_size=0, max_size=100)
non_branch_ref_strategy = st.one_of(
    # 알려진 non-branch prefix + 임의 suffix
    st.tuples(_non_branch_prefixes, _suffix).map(lambda t: t[0] + t[1]),
    # 완전 임의 텍스트 중 refs/heads/ 로 시작하지 않는 것만
    st.text(min_size=0, max_size=200).filter(lambda s: not s.startswith("refs/heads/")),
)


@given(ref=non_branch_ref_strategy)
@settings(max_examples=200)
def test_non_branch_ref_ignored(ref: str):
    """Property 5: Non-branch ref 무시

    # Feature: git-catcher, Property 5: Non-branch ref 무시
    **Validates: Requirements 3.2**

    For any refs/heads/로 시작하지 않는 ref 문자열에 대해,
    parse_push_event는 None을 반환해야 한다.
    """
    payload = {"ref": ref, "head_commit": {"message": "some commit"}}

    result = parse_push_event(payload)

    assert result is None
