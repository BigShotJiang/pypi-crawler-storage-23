"""Property-based tests for config module.

# Feature: git-catcher, Property 9: ALLOWED_BRANCHES 파싱 round-trip
**Validates: Requirements 6.2**
"""
from hypothesis import given, settings
from hypothesis import strategies as st

from git_catcher.config import parse_allowed_branches

# 전략: 유효한 브랜치명 (쉼표 없음, 앞뒤 공백 없음, 비어있지 않음)
# parse_allowed_branches는 strip() 후 빈 문자열을 필터링하므로,
# round-trip이 성립하려면 입력 브랜치명이 이미 trim된 상태여야 한다.
_branch_chars = st.sampled_from(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "-_/."
)
branch_name_strategy = (
    st.text(alphabet=_branch_chars, min_size=1, max_size=80)
    .filter(lambda b: b == b.strip())  # 앞뒤 공백 없음 (이미 보장되지만 명시적으로)
)

# 전략: 1개 이상의 브랜치명 리스트
branch_list_strategy = st.lists(branch_name_strategy, min_size=1, max_size=20)


@given(branches=branch_list_strategy)
@settings(max_examples=200)
def test_allowed_branches_parse_roundtrip(branches: list[str]):
    """Property 9: ALLOWED_BRANCHES 파싱 round-trip

    # Feature: git-catcher, Property 9: ALLOWED_BRANCHES 파싱 round-trip
    **Validates: Requirements 6.2**

    For any 브랜치명 리스트에 대해, 쉼표로 join한 문자열을 다시 split하면
    원래 리스트와 동일해야 한다.
    """
    # Arrange: 브랜치 리스트를 쉼표로 join
    raw = ",".join(branches)

    # Act: parse_allowed_branches로 다시 파싱
    result = parse_allowed_branches(raw)

    # Assert: round-trip 성립
    assert result == branches


# ---------------------------------------------------------------------------
# Unit tests: config edge cases (Task 7.3)
# ---------------------------------------------------------------------------
import importlib
import os
import sys
from unittest.mock import patch

import pytest


class TestSmeeUrlPlaceholderExit:
    """SMEE_URL placeholder 감지 시 sys.exit(1) 호출 확인.

    **Validates: Requirements 6.3**
    """

    def test_main_exits_when_smee_url_has_placeholder(self):
        """기본 SMEE_URL(YOUR_CHANNEL_ID 포함) 상태에서 main() 호출 시 exit(1)."""
        import git_catcher.main as main_module

        with (
            patch.dict(os.environ, {}, clear=True),
            patch("dotenv.load_dotenv"),
            patch.object(main_module.sys, "exit", side_effect=SystemExit(1)) as mock_exit,
        ):
            import git_catcher.config as config_module

            importlib.reload(config_module)
            importlib.reload(main_module)

            with pytest.raises(SystemExit):
                main_module.main([])

            mock_exit.assert_called_once_with(1)

    def test_main_does_not_exit_when_smee_url_is_valid(self):
        """유효한 SMEE_URL 설정 시 exit 호출 없이 listen 단계로 진행."""
        env = {"SMEE_URL": "https://smee.io/valid-channel-id"}

        import git_catcher.main as main_module

        with (
            patch.dict(os.environ, env, clear=True),
            patch("dotenv.load_dotenv"),
            patch.object(main_module.sys, "exit") as mock_exit,
        ):
            import git_catcher.config as config_module

            importlib.reload(config_module)
            importlib.reload(main_module)

            # listen은 블로킹이므로 mock 처리
            with patch.object(main_module, "listen"):
                main_module.main([])

            mock_exit.assert_not_called()


class TestDefaultConfigValues:
    """환경변수 미설정 시 DeployConfig 기본값 확인.

    **Validates: Requirements 6.1**
    """

    def test_defaults_without_env_vars(self):
        """환경변수가 없을 때 모든 필드가 설계 문서의 기본값과 일치해야 한다."""
        import git_catcher.config as config_module

        with patch.dict(os.environ, {}, clear=True), patch("dotenv.load_dotenv"):
            importlib.reload(config_module)
            cfg = config_module.DeployConfig()

        assert cfg.smee_url == "https://smee.io/YOUR_CHANNEL_ID"
        assert cfg.webhook_secret == ""
        assert cfg.repo_path == "/path/to/your/repo"
        assert cfg.allowed_branches == ["main", "master"]
        assert cfg.post_pull_command == ""
        assert cfg.reconnect_delay == 1
        assert cfg.max_reconnect_delay == 300

    def test_env_vars_override_defaults(self):
        """환경변수가 설정되면 해당 값이 기본값을 덮어써야 한다."""
        env = {
            "SMEE_URL": "https://smee.io/custom-channel",
            "WEBHOOK_SECRET": "my-secret",
            "REPO_PATH": "/opt/app",
            "ALLOWED_BRANCHES": "develop,release",
            "POST_PULL_COMMAND": "make build",
            "RECONNECT_DELAY": "10",
            "MAX_RECONNECT_DELAY": "600",
        }

        import git_catcher.config as config_module

        with patch.dict(os.environ, env, clear=True):
            importlib.reload(config_module)
            cfg = config_module.DeployConfig()

        assert cfg.smee_url == "https://smee.io/custom-channel"
        assert cfg.webhook_secret == "my-secret"
        assert cfg.repo_path == "/opt/app"
        assert cfg.allowed_branches == ["develop", "release"]
        assert cfg.post_pull_command == "make build"
        assert cfg.reconnect_delay == 10
        assert cfg.max_reconnect_delay == 600
