"""Property-based tests for verify_signature.

Feature: git-catcher, Property 1: 서명 검증 round-trip
**Validates: Requirements 2.1, 2.2**

Feature: git-catcher, Property 2: 잘못된 서명 거부
**Validates: Requirements 2.3**
"""
import hashlib
import hmac

from hypothesis import assume, given, settings
from hypothesis import strategies as st

from git_catcher.smee_client import verify_signature


# 전략: 임의의 payload bytes와 non-empty secret 문자열
payload_strategy = st.binary(min_size=0, max_size=1024)
secret_strategy = st.text(min_size=1, max_size=128).filter(lambda s: len(s.strip()) > 0)


@given(payload=payload_strategy, secret=secret_strategy)
@settings(max_examples=200)
def test_signature_roundtrip(payload: bytes, secret: str):
    """Property 1: 올바르게 생성한 서명은 항상 검증을 통과해야 한다.

    For any payload bytes와 secret 문자열에 대해,
    hmac.new(secret, payload, sha256).hexdigest()로 생성한 서명을
    verify_signature에 전달하면 항상 True를 반환해야 한다.
    """
    # Arrange: 올바른 서명 생성
    signature = "sha256=" + hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()

    # Act & Assert
    assert verify_signature(payload, signature, secret) is True


@given(payload=payload_strategy, secret=secret_strategy, wrong_sig=st.text(
    alphabet=st.characters(codec="ascii", categories=("L", "N", "P", "S")),
    min_size=1, max_size=256,
))
@settings(max_examples=200)
def test_wrong_signature_rejected(payload: bytes, secret: str, wrong_sig: str):
    """Property 2: 잘못된 서명 거부

    # Feature: git-catcher, Property 2: 잘못된 서명 거부
    **Validates: Requirements 2.3**

    For any payload bytes, secret 문자열, 그리고 올바른 서명과 다른
    임의의 문자열에 대해, verify_signature는 항상 False를 반환해야 한다.
    """
    # Arrange: 올바른 서명 계산
    correct_signature = "sha256=" + hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()

    # wrong_sig가 올바른 서명과 같으면 스킵
    assume(wrong_sig != correct_signature)

    # Act & Assert
    assert verify_signature(payload, wrong_sig, secret) is False


# Feature: git-catcher, Property 3: 빈 secret 시 모든 이벤트 수락
# **Validates: Requirements 2.4**

# 전략: 임의의 signature 문자열 (빈 문자열 포함)
any_signature_strategy = st.text(
    alphabet=st.characters(codec="ascii"),
    min_size=0,
    max_size=256,
)


@given(payload=payload_strategy, signature=any_signature_strategy)
@settings(max_examples=200)
def test_empty_secret_accepts_all(payload: bytes, signature: str):
    """Property 3: 빈 secret 시 모든 이벤트 수락

    # Feature: git-catcher, Property 3: 빈 secret 시 모든 이벤트 수락
    **Validates: Requirements 2.4**

    For any payload bytes와 임의의 signature 문자열에 대해,
    secret이 빈 문자열이면 verify_signature는 항상 True를 반환해야 한다.
    """
    # Act & Assert: secret이 빈 문자열이면 항상 True
    assert verify_signature(payload, signature, "") is True
