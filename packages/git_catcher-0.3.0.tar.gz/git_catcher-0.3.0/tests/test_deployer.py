"""Property-based tests for deployer branch filtering.

# Feature: git-catcher, Property 6: 브랜치 필터링
**Validates: Requirements 4.1, 4.2**
"""
from hypothesis import given, settings
from hypothesis import strategies as st

from git_catcher.deployer import should_deploy

# 전략: 브랜치명 — git 브랜치에 사용 가능한 안전한 문자
_branch_chars = (
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "-_/"
)
branch_strategy = (
    st.text(alphabet=_branch_chars, min_size=1, max_size=80)
    .filter(lambda b: not b.startswith("/"))
    .filter(lambda b: not b.endswith("/"))
    .filter(lambda b: "//" not in b)
)

# 전략: 허용 브랜치 목록 — 0~10개의 브랜치명 리스트
allowed_branches_strategy = st.lists(branch_strategy, min_size=0, max_size=10)


@given(branch=branch_strategy, allowed=allowed_branches_strategy)
@settings(max_examples=200)
def test_should_deploy_iff_branch_in_allowed(branch: str, allowed: list[str]):
    """Property 6: 브랜치 필터링

    # Feature: git-catcher, Property 6: 브랜치 필터링
    **Validates: Requirements 4.1, 4.2**

    For any 브랜치명과 허용 브랜치 목록에 대해,
    should_deploy 반환값은 해당 브랜치가 허용 목록에 포함되어 있는지 여부와 동치여야 한다.
    """
    result = should_deploy(branch, allowed)

    assert result == (branch in allowed)


# ---------------------------------------------------------------------------
# Feature: git-catcher, Property 7: Git 명령 실패 시 중단
# ---------------------------------------------------------------------------

import subprocess
from unittest.mock import patch, MagicMock
from pathlib import Path

from hypothesis import strategies as st

from git_catcher.config import DeployConfig


def _make_config(repo_path: str) -> DeployConfig:
    """테스트용 DeployConfig 생성."""
    return DeployConfig(
        smee_url="https://smee.io/test",
        webhook_secret="",
        repo_path=repo_path,
        allowed_branches=["main"],
        post_pull_command="",
        reconnect_delay=5,
        max_reconnect_delay=300,
    )


# 실패 단계 인덱스 전략: 0(fetch), 1(checkout), 2(pull)
fail_step_strategy = st.integers(min_value=0, max_value=2)


@given(branch=branch_strategy, fail_at=fail_step_strategy)
@settings(max_examples=200)
def test_git_pull_stops_on_failure(branch: str, fail_at: int):
    """Property 7: Git 명령 실패 시 중단

    # Feature: git-catcher, Property 7: Git 명령 실패 시 중단
    **Validates: Requirements 4.4**

    For any 3단계 git 명령 시퀀스(fetch, checkout, pull)에서
    k번째 단계가 실패하면, k+1번째 이후 단계는 실행되지 않아야 하며
    git_pull은 False를 반환해야 한다.
    """
    import asyncio
    import tempfile
    from git_catcher.deployer import git_pull

    with tempfile.TemporaryDirectory() as tmp_dir:
        config = _make_config(tmp_dir)
        call_count = 0

        async def mock_run_command(cmd, cwd):
            nonlocal call_count
            idx = call_count
            call_count += 1
            if idx == fail_at:
                return (1, "", "error")
            return (0, "ok", "")

        with patch("git_catcher.deployer.run_command", side_effect=mock_run_command):
            result = asyncio.run(git_pull(config, branch))

        # git_pull은 반드시 False를 반환해야 한다
        assert result is False, f"fail_at={fail_at}, branch={branch!r}"

        # 실패 단계까지만 실행되어야 한다 (fail_at + 1 번 호출)
        assert call_count == fail_at + 1, (
            f"expected {fail_at + 1} calls, got {call_count}"
        )


# ---------------------------------------------------------------------------
# Unit tests: deployer edge cases (Task 5.4)
# ---------------------------------------------------------------------------

import tempfile


class TestRunPostPullSkipsWhenEmpty:
    """Req 4.6: post_pull_command 미설정(빈 문자열) 시 run_command 호출 없이 True 반환."""

    def test_empty_string_skips(self, tmp_path):
        """post_pull_command가 빈 문자열이면 스킵하고 True 반환."""
        import asyncio
        from git_catcher.deployer import run_post_pull

        config = _make_config(str(tmp_path))
        assert config.post_pull_command == ""

        with patch("git_catcher.deployer.run_command") as mock_cmd:
            result = asyncio.run(run_post_pull(config))

        assert result is True
        mock_cmd.assert_not_called()


class TestGitPullRepoNotExists:
    """Req 4.4: 저장소 경로가 존재하지 않으면 즉시 False 반환."""

    def test_nonexistent_path_returns_false(self):
        """존재하지 않는 경로 → git_pull False, run_command 호출 없음."""
        import asyncio
        from git_catcher.deployer import git_pull

        config = _make_config("/nonexistent/path/that/does/not/exist")

        with patch("git_catcher.deployer.run_command") as mock_cmd:
            result = asyncio.run(git_pull(config, "main"))

        assert result is False
        mock_cmd.assert_not_called()


class TestGitCommandOrder:
    """Req 4.3: git 명령이 fetch → checkout → pull 순서로 실행되어야 한다."""

    def test_commands_execute_in_order(self, tmp_path):
        """모든 git 명령 성공 시 fetch → checkout → pull 순서 검증."""
        import asyncio
        from unittest.mock import AsyncMock
        from git_catcher.deployer import git_pull

        config = _make_config(str(tmp_path))
        ok = (0, "ok", "")

        with patch("git_catcher.deployer.run_command", new_callable=AsyncMock, return_value=ok) as mock_cmd:
            result = asyncio.run(git_pull(config, "main"))

        assert result is True
        assert mock_cmd.call_count == 3

        calls = mock_cmd.call_args_list
        assert calls[0].args[0] == ["git", "fetch", "origin"]
        assert calls[1].args[0] == ["git", "checkout", "main"]
        assert calls[2].args[0] == ["git", "pull", "origin", "main"]

        # cwd가 모두 repo_path인지 확인
        for call in calls:
            assert call.kwargs["cwd"] == str(tmp_path)
