"""Unit tests for _handle_raw_event — SSE 이벤트 처리

Validates: Requirements 1.2, 1.3, 1.4
"""
import asyncio
from unittest.mock import AsyncMock, MagicMock

from git_catcher.config import DeployConfig
from git_catcher.smee_client import _handle_raw_event


def _make_config(**overrides) -> DeployConfig:
    """테스트용 DeployConfig 생성 (서명 검증 스킵을 위해 webhook_secret="" 기본)"""
    defaults = dict(
        smee_url="https://smee.io/test",
        webhook_secret="",
        repo_path="/tmp/repo",
        allowed_branches=["main"],
        post_pull_command="",
        reconnect_delay=5,
        max_reconnect_delay=300,
    )
    defaults.update(overrides)
    return DeployConfig(**defaults)


class TestPingEventIgnored:
    """Req 1.3: ping 이벤트는 무시해야 한다."""

    def test_ping_event_does_not_call_on_push(self):
        config = _make_config()
        on_push = MagicMock()

        raw = "event: ping\ndata: {}"
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_not_called()

    def test_ping_event_with_payload_still_ignored(self):
        config = _make_config()
        on_push = MagicMock()

        raw = 'event: ping\ndata: {"ref": "refs/heads/main", "head_commit": {"message": "x"}}'
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_not_called()


class TestInvalidJsonHandling:
    """Req 1.4: invalid JSON은 에러 없이 무시해야 한다."""

    def test_invalid_json_does_not_raise(self):
        config = _make_config()
        on_push = MagicMock()

        raw = "data: not-valid-json{{"
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_not_called()

    def test_truncated_json_does_not_raise(self):
        config = _make_config()
        on_push = MagicMock()

        raw = 'data: {"ref": "refs/heads/main"'
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_not_called()


class TestValidPushEvent:
    """Req 1.2: 유효한 push 이벤트 수신 시 on_push 콜백이 호출되어야 한다."""

    def test_valid_push_calls_on_push_with_branch_and_message(self):
        config = _make_config()
        on_push = AsyncMock()

        body = '{"ref": "refs/heads/main", "head_commit": {"message": "test commit"}}'
        raw = f'data: {{"body": {body}}}'
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_called_once_with("main", "test commit", "")

    def test_valid_push_different_branch(self):
        config = _make_config()
        on_push = AsyncMock()

        body = '{"ref": "refs/heads/develop", "head_commit": {"message": "feat: new"}}'
        raw = f'data: {{"body": {body}}}'
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_called_once_with("develop", "feat: new", "")

    def test_no_data_lines_does_not_call_on_push(self):
        """data: 라인이 없는 SSE 이벤트는 무시"""
        config = _make_config()
        on_push = MagicMock()

        raw = "event: message\nid: 123"
        asyncio.run(_handle_raw_event(raw, config, on_push))

        on_push.assert_not_called()
