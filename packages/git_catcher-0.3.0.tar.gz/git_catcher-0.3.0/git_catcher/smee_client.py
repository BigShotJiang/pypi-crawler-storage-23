"""Smee.io SSE 클라이언트 — webhook 이벤트를 실시간 수신 (async)"""
import asyncio
import hashlib
import hmac
import json
import logging

import httpx

from .config import DeployConfig

logger = logging.getLogger(__name__)


def verify_signature(payload: bytes, signature: str, secret: str) -> bool:
    """GitHub webhook HMAC-SHA256 서명 검증"""
    if not secret:
        logger.warning("webhook_secret 미설정 — 서명 검증 스킵")
        return True

    expected = "sha256=" + hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


def parse_push_event(data: dict) -> tuple[str, str] | None:
    """push 이벤트에서 (branch, commit_message) 추출. push가 아니면 None."""
    ref = data.get("ref", "")
    if not ref.startswith("refs/heads/"):
        return None

    branch = ref.removeprefix("refs/heads/")
    head_commit = data.get("head_commit") or {}
    message = head_commit.get("message", "(no message)")
    return branch, message

def calculate_backoff(attempt: int, initial_delay: int, max_delay: int) -> int:
    """n번째 재연결 시도의 대기 시간을 계산한다.

    delay = min(initial_delay * 2^attempt, max_delay)
    """
    return min(initial_delay * (2 ** attempt), max_delay)




async def listen(config: DeployConfig, on_push, on_connect=None):
    """
    Smee.io SSE 스트림을 구독하고, push 이벤트 수신 시 on_push 콜백 호출.
    연결 끊김 시 exponential backoff로 재연결.
    on_connect가 주어지면 SSE 연결 성공 시마다 호출.

    on_push(branch: str, commit_message: str, repo_name: str) -> None (async)
    on_connect() -> None (async, optional)
    """
    attempt = 0
    state = {"last_event_id": None}

    while True:
        try:
            logger.info(f"Smee.io 연결 중: {config.smee_url}")
            await _stream_events(config, on_push, state, on_connect)
            logger.info("SSE 스트림 종료 — 즉시 재연결")
            attempt = 0
            continue
        except (httpx.ConnectError, httpx.ReadTimeout, httpx.ReadError,
                httpx.RemoteProtocolError) as e:
            logger.warning(f"연결 오류: {e}")
        except httpx.HTTPStatusError as e:
            logger.warning(f"HTTP 오류 {e.response.status_code}: {e}")
        except Exception as e:
            logger.error(f"예상치 못한 오류: {e}", exc_info=True)

        delay = calculate_backoff(attempt, config.reconnect_delay, config.max_reconnect_delay)
        logger.info(f"{delay}초 후 재연결 (시도 #{attempt + 1})...")
        await asyncio.sleep(delay)
        attempt += 1






async def _stream_events(config: DeployConfig, on_push, state: dict, on_connect=None):
    """SSE 스트림을 읽고 이벤트를 처리하는 내부 함수. state['last_event_id']를 갱신."""
    headers = {"Accept": "text/event-stream"}
    if state["last_event_id"]:
        headers["Last-Event-ID"] = state["last_event_id"]
        logger.info(f"Last-Event-ID: {state['last_event_id']} 이후부터 수신")

    # read=90s: Smee.io는 ~30초마다 ping 전송, 2회 연속 미수신 시 죽은 연결로 판단
    timeout = httpx.Timeout(connect=10.0, read=90.0, write=10.0, pool=10.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        async with client.stream("GET", config.smee_url, headers=headers) as resp:
            resp.raise_for_status()
            logger.info("SSE 스트림 연결 성공")

            # 연결 성공 시 catch-up — SSE 스트림 블로킹 방지를 위해 백그라운드 실행
            if on_connect:
                asyncio.create_task(on_connect())

            buffer = ""
            async for chunk in resp.aiter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    raw_event, buffer = buffer.split("\n\n", 1)
                    event_id = await _handle_raw_event(raw_event, config, on_push)
                    if event_id is not None:
                        state["last_event_id"] = event_id





async def _handle_raw_event(raw: str, config: DeployConfig, on_push) -> str | None:
    """SSE 원시 이벤트 파싱 및 처리. event ID를 반환."""
    if config.verbose >= 4:
        logger.debug(f"[RAW WEBHOOK]\n{raw}")

    data_lines = []
    event_type = "message"
    event_id = None

    for line in raw.strip().split("\n"):
        if line.startswith("data:"):
            data_lines.append(line[5:].strip())
        elif line.startswith("event:"):
            event_type = line[6:].strip()
        elif line.startswith("id:"):
            event_id = line[3:].strip()

    if not data_lines or event_type in ("ping", "ready"):
        return None

    raw_data = "\n".join(data_lines)
    try:
        data = json.loads(raw_data)
    except json.JSONDecodeError:
        logger.debug(f"JSON 파싱 실패 (무시): {raw_data[:100]}")
        return event_id

    # 서명 검증 — Smee.io 프록시는 body를 JSON 재직렬화하므로 원본 바이트 복원 불가
    is_smee = "smee.io" in config.smee_url
    signature = data.get("x-hub-signature-256", "")
    body = data.get("body", {})

    # body 원본 보존: string이면 원본 바이트로 서명 검증 가능
    if isinstance(body, str):
        body_bytes = body.encode()
        try:
            body = json.loads(body)
        except json.JSONDecodeError:
            return event_id
    else:
        body_bytes = json.dumps(body, separators=(",", ":")).encode()

    logger.debug(f"이벤트 수신: type={event_type}, signature={signature[:30]}...")
    logger.debug(f"body keys: {list(body.keys()) if isinstance(body, dict) else 'N/A'}")

    if is_smee:
        if config.webhook_secret and signature:
            logger.debug("Smee.io 프록시 — 서명 검증 스킵 (원본 바이트 복원 불가)")
    elif not verify_signature(body_bytes, signature, config.webhook_secret):
        logger.warning("서명 검증 실패 — 이벤트 무시")
        logger.debug(f"payload_bytes 길이: {len(body_bytes)}, signature: {signature}")
        return event_id

    # repo 필터링 + push 이벤트 처리
    repo_name = (body.get("repository") or {}).get("full_name", "")
    result = parse_push_event(body)

    # --show-all-events: 모든 push 로그 출력
    if result and config.show_all_events:
        branch, message = result
        logger.info(f"[ALL] [{repo_name}] [{branch}] {message}")

    if config.allowed_repos and repo_name not in config.allowed_repos:
        logger.debug(f"저장소 [{repo_name}]는 허용 목록에 없음 — 스킵")
        return event_id

    if result:
        branch, message = result
        logger.info(f"Push 감지: [{repo_name}] [{branch}] {message}")
        await on_push(branch, message, repo_name)

    return event_id
