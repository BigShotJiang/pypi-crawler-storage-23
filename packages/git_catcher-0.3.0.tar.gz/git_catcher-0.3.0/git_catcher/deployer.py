"""Git pull + 배포 스크립트 실행 (async)"""
import asyncio
import logging
from pathlib import Path

from .config import DeployConfig

async def check_behind(config: DeployConfig, branch: str) -> tuple[bool, str]:
    """로컬 브랜치가 origin보다 뒤처져 있는지 확인. (is_behind, commit_message) 반환."""
    repo = config.repo_path
    if not Path(repo).is_dir():
        return False, ""

    rc, _, _ = await run_command(["git", "fetch", "origin"], cwd=repo)
    if rc != 0:
        return False, ""

    _, local_hash, _ = await run_command(["git", "rev-parse", branch], cwd=repo)
    _, remote_hash, _ = await run_command(["git", "rev-parse", f"origin/{branch}"], cwd=repo)

    if local_hash.strip() == remote_hash.strip():
        return False, ""

    _, message, _ = await run_command(
        ["git", "log", "--format=%s", "-1", f"origin/{branch}"], cwd=repo
    )
    return True, message.strip()



logger = logging.getLogger(__name__)


async def run_command(cmd: list[str], cwd: str) -> tuple[int, str, str]:
    """명령어 비동기 실행 후 (returncode, stdout, stderr) 반환"""
    proc = await asyncio.create_subprocess_exec(
        *cmd, cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
    return proc.returncode, stdout.decode(), stderr.decode()


def should_deploy(branch: str, allowed_branches: list[str]) -> bool:
    """브랜치가 허용 목록에 포함되어 있으면 True 반환."""
    return branch in allowed_branches


async def git_pull(config: DeployConfig, branch: str) -> bool:
    """git pull 실행. 성공 시 True 반환."""
    repo = config.repo_path
    if not Path(repo).is_dir():
        logger.error(f"저장소 경로가 존재하지 않음: {repo}")
        return False

    # fetch → checkout → pull 순서로 안전하게 처리
    steps = [
        (["git", "fetch", "origin"], "fetch"),
        (["git", "checkout", branch], "checkout"),
        (["git", "pull", "origin", branch], "pull"),
    ]

    for cmd, label in steps:
        returncode, stdout, stderr = await run_command(cmd, cwd=repo)
        if returncode != 0:
            logger.error(f"git {label} 실패: {stderr.strip()}")
            return False
        logger.info(f"git {label} 완료: {stdout.strip()}")

    return True


async def run_post_pull(config: DeployConfig) -> bool:
    """배포 후 명령어 실행. 설정이 비어있으면 스킵."""
    if not config.post_pull_command:
        logger.info("post_pull_command 미설정, 스킵")
        return True

    logger.info(f"배포 명령 실행: {config.post_pull_command}")
    returncode, stdout, stderr = await run_command(
        ["sh", "-c", config.post_pull_command], cwd=config.repo_path
    )

    if returncode != 0:
        logger.error(f"배포 명령 실패: {stderr.strip()}")
        return False

    logger.info(f"배포 명령 완료: {stdout.strip()}")
    return True


async def deploy(config: DeployConfig, branch: str) -> bool:
    """git pull + 배포 명령 실행. 전체 성공 시 True."""
    if not await git_pull(config, branch):
        return False
    return await run_post_pull(config)
