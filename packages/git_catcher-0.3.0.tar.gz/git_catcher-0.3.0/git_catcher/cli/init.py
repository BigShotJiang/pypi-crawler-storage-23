"""git-catcher init — Interactive setup"""
import os
import secrets
import webbrowser
from pathlib import Path

from InquirerPy.resolver import prompt
from InquirerPy.validator import PathValidator


def load_existing_env(env_path: Path | None = None) -> dict[str, str]:
    """기존 .env 파일과 환경변수에서 설정값을 읽어온다.

    우선순위: 환경변수 > .env 파일 값
    """
    existing: dict[str, str] = {}
    path = env_path or Path(".env")

    # .env 파일 파싱
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                existing[key.strip()] = value.strip()

    # 환경변수로 오버라이드 (환경변수가 우선)
    env_overrides = []
    for key in (
        "SMEE_URL", "WEBHOOK_SECRET", "REPO_PATH", "ALLOWED_BRANCHES",
        "POST_PULL_COMMAND", "SLACK_WEBHOOK_URL", "POLL_INTERVAL",
    ):
        env_val = os.environ.get(key)
        if env_val is not None:
            existing[key] = env_val
            env_overrides.append(key)

    # 환경변수 오버라이드 알림
    if env_overrides:
        print(f"⚠️  환경변수로 오버라이드된 항목: {', '.join(env_overrides)}")

    return existing


def generate_secret() -> str:
    """랜덤 webhook secret 생성"""
    return secrets.token_urlsafe(32)


def run_init(non_interactive: bool = False, template: str = "docker"):
    """Interactive setup for git-catcher"""
    # 기존 .env / 환경변수에서 설정값 로드
    existing = load_existing_env()
    has_existing = bool(existing)

    print("\n🚀 git-catcher 초기 설정을 시작합니다.")
    if has_existing:
        print("📋 기존 설정값을 감지했습니다. 각 항목의 기본값으로 사용됩니다.\n")
    else:
        print()

    if non_interactive:
        # 기존 값 우선, 없으면 기본값
        config = {
            "smee_url": existing.get("SMEE_URL", "https://smee.io/YOUR_CHANNEL_ID"),
            "webhook_secret": existing.get("WEBHOOK_SECRET") or generate_secret(),
            "repo_path": existing.get("REPO_PATH", "./repo"),
            "allowed_branches": existing.get("ALLOWED_BRANCHES", "main,master"),
            "post_pull_command": existing.get("POST_PULL_COMMAND", ""),
            "slack_webhook_url": existing.get("SLACK_WEBHOOK_URL", ""),
            "poll_interval": existing.get("POLL_INTERVAL", "0"),
        }
    else:
        # --- REPO_PATH: 기존 값이 있으면 confirm 먼저 ---
        existing_repo = existing.get("REPO_PATH")
        if existing_repo:
            use_existing = prompt([{
                "type": "confirm",
                "name": "use",
                "message": f"REPO_PATH={existing_repo} 를 사용하시겠습니까?",
                "default": True,
            }])["use"]
            if use_existing:
                repo_path = existing_repo
            else:
                repo_path = prompt([{
                    "type": "filepath",
                    "name": "path",
                    "message": "배포 대상 저장소 경로:",
                    "default": existing_repo,
                    "validate": PathValidator(is_dir=True, message="유효한 디렉토리를 입력하세요"),
                }])["path"]
        else:
            repo_path = prompt([{
                "type": "filepath",
                "name": "path",
                "message": "배포 대상 저장소 경로:",
                "default": str(Path.cwd()),
                "validate": PathValidator(is_dir=True, message="유효한 디렉토리를 입력하세요"),
            }])["path"]

        # --- Smee.io URL ---
        existing_smee = existing.get("SMEE_URL", "")
        is_real_smee = existing_smee.startswith("https://smee.io/") and "YOUR_CHANNEL_ID" not in existing_smee

        if is_real_smee:
            smee_choice = prompt([{
                "type": "list",
                "name": "smee_choice",
                "message": f"Smee.io URL (현재: {existing_smee}):",
                "choices": [
                    {"name": f"기존 값 사용 ({existing_smee})", "value": "keep"},
                    {"name": "새로 생성 (브라우저에서 열기)", "value": "new"},
                    {"name": "직접 입력", "value": "manual"},
                ],
            }])["smee_choice"]
        else:
            smee_choice = prompt([{
                "type": "list",
                "name": "smee_choice",
                "message": "Smee.io URL:",
                "choices": [
                    {"name": "새로 생성 (브라우저에서 열기)", "value": "new"},
                    {"name": "직접 입력", "value": "manual"},
                ],
            }])["smee_choice"]

        if smee_choice == "keep":
            smee_url = existing_smee
        elif smee_choice == "new":
            print("브라우저에서 https://smee.io/new 를 엽니다...")
            webbrowser.open("https://smee.io/new")
            smee_url = prompt([{
                "type": "input",
                "name": "url",
                "message": "생성된 Smee.io URL을 입력하세요:",
                "validate": lambda x: x.startswith("https://smee.io/") or "https://smee.io/로 시작해야 합니다",
            }])["url"]
        else:
            smee_url = prompt([{
                "type": "input",
                "name": "url",
                "message": "Smee.io URL:",
                "default": existing_smee or "https://smee.io/YOUR_CHANNEL_ID",
            }])["url"]

        # --- Webhook Secret ---
        existing_secret = existing.get("WEBHOOK_SECRET", "")
        if existing_secret:
            secret_choice = prompt([{
                "type": "list",
                "name": "choice",
                "message": f"Webhook Secret (현재: {existing_secret[:8]}...):",
                "choices": [
                    {"name": "기존 값 유지", "value": "keep"},
                    {"name": "랜덤 재생성", "value": "random"},
                    {"name": "직접 입력", "value": "manual"},
                ],
            }])["choice"]
        else:
            secret_choice = prompt([{
                "type": "list",
                "name": "choice",
                "message": "Webhook Secret:",
                "choices": [
                    {"name": "랜덤 생성 (권장)", "value": "random"},
                    {"name": "직접 입력", "value": "manual"},
                ],
            }])["choice"]

        if secret_choice == "keep":
            webhook_secret = existing_secret
        elif secret_choice == "random":
            webhook_secret = generate_secret()
        else:
            webhook_secret = prompt([{
                "type": "input",
                "name": "secret",
                "message": "Webhook Secret 입력:",
            }])["secret"]

        # --- Allowed Branches ---
        existing_branches = existing.get("ALLOWED_BRANCHES", "")
        existing_branch_list = [b.strip() for b in existing_branches.split(",") if b.strip()] if existing_branches else []

        # 기본 choices + 기존 브랜치 중 choices에 없는 것 추가
        base_choices = ["main", "master", "develop", "devel"]
        extra_branches = [b for b in existing_branch_list if b not in base_choices]
        all_choices = base_choices + extra_branches + [{"name": "커스텀 입력", "value": "custom"}]

        branches_result = prompt([{
            "type": "checkbox",
            "name": "branches",
            "message": "허용할 브랜치 (스페이스로 선택, 엔터로 확인):",
            "choices": all_choices,
            "default": existing_branch_list or ["main"],
        }])["branches"]

        allowed_branches_list: list[str] = []
        if isinstance(branches_result, list):
            allowed_branches_list = [str(b) for b in branches_result]
        else:
            allowed_branches_list = [str(branches_result)]

        if "custom" in allowed_branches_list:
            allowed_branches_list.remove("custom")
            custom = prompt([{
                "type": "input",
                "name": "custom",
                "message": "커스텀 브랜치 (쉼표 구분):",
            }])["custom"]
            if isinstance(custom, str):
                allowed_branches_list.extend([b.strip() for b in custom.split(",") if b.strip()])

        allowed_branches = ",".join(allowed_branches_list)

        # --- Post Pull Command ---
        post_pull_command = prompt([{
            "type": "input",
            "name": "cmd",
            "message": "배포 명령어 (빈 문자열이면 git pull만):",
            "default": existing.get("POST_PULL_COMMAND", ""),
        }])["cmd"]

        # --- Slack Webhook URL ---
        slack_webhook_url = prompt([{
            "type": "input",
            "name": "url",
            "message": "Slack Webhook URL (선택사항):",
            "default": existing.get("SLACK_WEBHOOK_URL", ""),
        }])["url"]

        # --- Poll Interval ---
        poll_interval = prompt([{
            "type": "input",
            "name": "interval",
            "message": "Git poll 간격 (초, 0=비활성):",
            "default": existing.get("POLL_INTERVAL", "0"),
            "validate": lambda x: x.isdigit() or "숫자를 입력하세요",
        }])["interval"]

        config = {
            "smee_url": smee_url,
            "webhook_secret": webhook_secret,
            "repo_path": repo_path,
            "allowed_branches": allowed_branches,
            "post_pull_command": post_pull_command,
            "slack_webhook_url": slack_webhook_url,
            "poll_interval": poll_interval,
        }

    # .env 파일 생성
    env_path = Path(".env")
    if env_path.exists():
        overwrite = non_interactive or prompt([{
            "type": "confirm",
            "name": "overwrite",
            "message": ".env 파일이 이미 존재합니다. 덮어쓰시겠습니까?",
            "default": False,
        }])["overwrite"]
        if not overwrite:
            print("❌ .env 생성을 건너뜁니다.")
            return

    env_content = f"""# git-catcher configuration
SMEE_URL={config['smee_url']}
WEBHOOK_SECRET={config['webhook_secret']}
REPO_PATH={config['repo_path']}
ALLOWED_BRANCHES={config['allowed_branches']}
POST_PULL_COMMAND={config['post_pull_command']}
SLACK_WEBHOOK_URL={config['slack_webhook_url']}
NOTIFY_ON_START=true
POLL_INTERVAL={config['poll_interval']}
LOG_LEVEL=INFO
LOG_FILE=
SHOW_ALL_EVENTS=false
"""

    env_path.write_text(env_content)
    print(f"✅ .env 파일 생성 완료: {env_path.absolute()}")

    # docker-compose.yml 생성 (선택사항)
    if template == "docker":
        create_compose = non_interactive or prompt([{
            "type": "confirm",
            "name": "create",
            "message": "docker-compose.yml을 생성하시겠습니까?",
            "default": True,
        }])["create"]

        if create_compose:
            compose_path = Path("docker-compose.yml")
            if compose_path.exists():
                overwrite = non_interactive or prompt([{
                    "type": "confirm",
                    "name": "overwrite",
                    "message": "docker-compose.yml이 이미 존재합니다. 덮어쓰시겠습니까?",
                    "default": False,
                }])["overwrite"]
                if not overwrite:
                    print("❌ docker-compose.yml 생성을 건너뜁니다.")
                    return

            compose_content = f"""services:
  git-catcher:
    image: git-catcher:latest
    volumes:
      - {config['repo_path']}:/repo
      - ./.env:/app/.env:ro
    restart: unless-stopped
    environment:
      - REPO_PATH=/repo
"""

            compose_path.write_text(compose_content)
            print(f"✅ docker-compose.yml 생성 완료: {compose_path.absolute()}")

    print("\n🎉 초기 설정이 완료되었습니다!")
    print("\n다음 단계:")
    print("1. GitHub에서 webhook 설정 (Payload URL: Smee.io URL, Secret: WEBHOOK_SECRET)")
    print("2. git-catcher 실행: python -m git_catcher.main")
    if template == "docker":
        print("   또는 Docker: docker compose up -d")
