"""Git Auto Deploy — Smee.io 기반 자동 배포 진입점 (async)"""
import asyncio
import logging
import socket
import sys
from datetime import datetime, timezone

import httpx

from .config import DeployConfig, detect_repo_name
from .deployer import check_behind, deploy, should_deploy
from .smee_client import listen
from . import __version__

logger = logging.getLogger("auto-deploy")

# 외부 IP API — 첫 번째 실패 시 fallback 1회
_EXTERNAL_IP_APIS = [
    "https://api.ipify.org",
    "https://checkip.amazonaws.com",
]


async def fetch_external_ip() -> str:
    """외부 IP를 가져온다. 첫 API 실패 시 fallback 1회, 모두 실패 시 'unknown'."""
    async with httpx.AsyncClient(timeout=5) as client:
        for url in _EXTERNAL_IP_APIS:
            try:
                resp = await client.get(url)
                resp.raise_for_status()
                return resp.text.strip()
            except Exception:
                continue
    return "unknown"




async def notify_slack(
    config: DeployConfig, repo: str, branch: str, message: str,
    success: bool, trigger: str = "push",
):
    """Slack Incoming Webhook으로 Block Kit 배포 알림 전송 (async)

    trigger: "push" | "catch-up" | "poll" | "start"
    """
    if not config.slack_webhook_url:
        return

    emoji = "✅" if success else "❌"
    status = "Success" if success else "Failed"
    trigger_labels = {
        "push": "Push",
        "catch-up": "🔄 Catch-up",
        "poll": "⏰ Poll",
        "start": "🚀 Start",
    }
    trigger_label = trigger_labels.get(trigger, trigger)

    hostname = socket.gethostname()
    external_ip = await fetch_external_ip()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": f"{emoji} Deploy {status}", "emoji": True},
        },
        {"type": "divider"},
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Repository*\n{repo}"},
                {"type": "mrkdwn", "text": f"*Branch*\n{branch}"},
            ],
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Commit*\n{message}"},
                {"type": "mrkdwn", "text": f"*Trigger*\n{trigger_label}"},
            ],
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Host*\n`{hostname}`"},
                {"type": "mrkdwn", "text": f"*IP*\n`{external_ip}`"},
            ],
        },
        {
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": f"🕐 {now}"}],
        },
    ]

    fallback = f"{emoji} Deploy {status} [{trigger_label}] | {repo}/{branch} | {hostname}({external_ip})"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                config.slack_webhook_url,
                json={"text": fallback, "blocks": blocks},
            )
    except Exception as e:
        logger.warning(f"Slack notification failed: {e}")


async def notify_slack_start(config: DeployConfig, repo: str):
    """시작 시 Slack 알림 전송"""
    if not config.slack_webhook_url or not config.notify_on_start:
        return

    hostname = socket.gethostname()
    external_ip = await fetch_external_ip()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": "🚀 git-catcher Started", "emoji": True},
        },
        {"type": "divider"},
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Repository*\n{repo}"},
                {"type": "mrkdwn", "text": f"*Branches*\n{', '.join(config.allowed_branches)}"},
            ],
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Host*\n`{hostname}`"},
                {"type": "mrkdwn", "text": f"*IP*\n`{external_ip}`"},
            ],
        },
        {
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": f"🕐 {now}"}],
        },
    ]

    fallback = f"🚀 git-catcher Started | {repo} | {hostname}({external_ip})"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                config.slack_webhook_url,
                json={"text": fallback, "blocks": blocks},
            )
    except Exception as e:
        logger.warning(f"Slack start notification failed: {e}")





LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"



def setup_logging(level: str = "INFO", log_file: str | None = None):
    """stdout(rich) + 파일 핸들러 로깅 설정

    level: DEBUG, INFO, WARNING, ERROR
    """
    from rich.logging import RichHandler
    from rich.text import Text

    root = logging.getLogger()
    root.handlers.clear()

    log_level = getattr(logging, level.upper(), logging.INFO)
    root.setLevel(log_level)

    def _fmt_time(dt):
        return Text(dt.strftime("%H:%M:%S.") + f"{dt.microsecond // 1000:03d}")

    console = RichHandler(
        rich_tracebacks=True,
        show_time=True,
        show_path=True,
        markup=False,
        log_time_format=_fmt_time,
    )
    console.setLevel(log_level)
    root.addHandler(console)

    # 파일 핸들러 (plain text, 항상 DEBUG)
    if log_file:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT))
        fh.setLevel(logging.DEBUG)
        root.addHandler(fh)
        logger.info(f"로그 파일: {log_file}")







async def async_main(config: DeployConfig):
    """비동기 메인 루프 — SSE 구독 + catch-up + poll + Slack 알림"""

    # ALLOWED_REPOS 미설정 시 REPO_PATH에서 자동 감지
    if not config.allowed_repos:
        detected = detect_repo_name(config.repo_path)
        if detected:
            config.allowed_repos = [detected]
            logger.info(f"저장소 자동 감지: {detected}")

    # 필수 설정 검증
    if "YOUR_CHANNEL_ID" in config.smee_url:
        logger.error("SMEE_URL을 설정해주세요. https://smee.io/new 에서 채널 생성")
        sys.exit(1)

    repo_name = config.allowed_repos[0] if config.allowed_repos else ""

    logger.info(f"대상 저장소: {config.repo_path}")
    logger.info(f"허용 브랜치: {config.allowed_branches}")
    logger.info(f"허용 저장소: {config.allowed_repos or '(전체)'}")
    logger.info(f"Smee 채널: {config.smee_url}")
    if config.poll_interval > 0:
        logger.info(f"Git poll 활성: {config.poll_interval}초 간격")

    # 시작 알림 전송
    await notify_slack_start(config, repo_name)

    async def deploy_if_behind(trigger: str):
        """허용 브랜치별로 origin과 비교, 뒤처져 있으면 배포."""
        for branch in config.allowed_branches:
            is_behind, message = await check_behind(config, branch)
            if not is_behind:
                logger.info(f"({trigger}) [{branch}] 이미 최신 상태")
                continue
            logger.info(f"배포 시작 ({trigger}): [{branch}] {message}")
            success = await deploy(config, branch)
            logger.info(f"배포 {'성공' if success else '실패'} ({trigger}): [{branch}]")
            await notify_slack(config, repo_name, branch, message, success, trigger)

    async def on_connect():
        """SSE 연결 성공 시 catch-up 배포"""
        await deploy_if_behind("catch-up")

    async def on_push(branch: str, commit_message: str, push_repo: str = ""):
        if not should_deploy(branch, config.allowed_branches):
            logger.info(f"브랜치 [{branch}]는 허용 목록에 없음 — 스킵")
            return
        logger.info(f"배포 시작 (push): [{branch}] {commit_message}")
        success = await deploy(config, branch)
        logger.info(f"배포 {'성공' if success else '실패'} (push): [{branch}]")
        await notify_slack(config, push_repo or repo_name, branch, commit_message, success, "push")

    async def poll_loop():
        """주기적으로 git 상태를 확인하여 놓친 push를 감지"""
        while True:
            await asyncio.sleep(config.poll_interval)
            logger.debug("poll: 로컬 vs origin 비교 중...")
            await deploy_if_behind("poll")

    # poll_interval > 0이면 백그라운드 태스크로 실행
    if config.poll_interval > 0:
        asyncio.create_task(poll_loop())

    # SSE 스트림 구독 시작 (비동기, 자동 재연결, 연결 시 catch-up)
    await listen(config, on_push, on_connect)


def main(argv=None):
    import argparse

    parser = argparse.ArgumentParser(
        description="Git Auto Deploy — Smee.io 기반 자동 배포",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="사용 가능한 명령어")

    # init subcommand
    init_parser = subparsers.add_parser("init", help="Interactive 초기 설정")
    init_parser.add_argument(
        "--non-interactive", action="store_true",
        help="기본값으로 자동 생성 (interactive 질문 스킵)",
    )
    init_parser.add_argument(
        "--template", choices=["docker", "bare"], default="docker",
        help="생성할 템플릿 (docker: docker-compose.yml 포함, bare: .env만)",
    )

    # run subcommand (기본 동작)
    run_parser = subparsers.add_parser("run", help="git-catcher 실행 (기본)")
    run_parser.add_argument(
        "-v", "--verbose", action="count", default=0,
        help="로그 상세도 (-v: DEBUG). --log-level보다 우선",
    )
    run_parser.add_argument(
        "--log-level", default=None,
        help="로그 레벨 (DEBUG, INFO, WARNING, ERROR). 환경변수 LOG_LEVEL보다 우선",
    )
    run_parser.add_argument(
        "--log-file", default=None,
        help="로그 파일 경로. 환경변수 LOG_FILE보다 우선",
    )
    run_parser.add_argument(
        "--show-all-events", action="store_true", default=None,
        help="모든 push 이벤트 로그 출력. 환경변수 SHOW_ALL_EVENTS보다 우선",
    )

    # 인자 없이 실행 시 run으로 간주
    args = parser.parse_args(argv)
    if args.command is None:
        args.command = "run"
        args.verbose = 0
        args.log_level = None
        args.log_file = None
        args.show_all_events = None

    if args.command == "init":
        from .cli.init import run_init
        run_init(non_interactive=args.non_interactive, template=args.template)
        return

    # run 명령어
    config = DeployConfig()

    # 우선순위: -v > --log-level > LOG_LEVEL 환경변수
    if args.verbose >= 1:
        log_level = "DEBUG"
    else:
        log_level = args.log_level or config.log_level
    log_file = args.log_file or config.log_file or None
    if args.show_all_events is not None:
        config.show_all_events = args.show_all_events

    setup_logging(level=log_level, log_file=log_file)

    # ASCII art + version
    print("""
   _____ _ _            _____      _       _
  / ____(_) |          / ____|    | |     | |
 | |  __ _| |_ ______ | |     __ _| |_ ___| |__   ___ _ __
 | | |_ | | __|______|| |    / _` | __/ __| '_ \\ / _ \\ '__|
 | |__| | | |_        | |___| (_| | || (__| | | |  __/ |
  \\_____|_|\\__|        \\_____\\__,_|\\__\\___|_| |_|\\___|_|
    """)
    logger.info(f"git-catcher v{__version__}")
    asyncio.run(async_main(config))



if __name__ == "__main__":
    main()
