"""배포 설정"""
import logging
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# 현재 작업 디렉토리의 .env만 로드 (상위 디렉토리 탐색 방지)
load_dotenv(dotenv_path=Path.cwd() / ".env", verbose=False)

logger = logging.getLogger(__name__)


def parse_allowed_branches(raw: str) -> list[str]:
    """쉼표로 구분된 브랜치 문자열을 파싱하여 리스트로 반환한다.

    각 브랜치명의 앞뒤 공백을 제거하고, 빈 문자열은 필터링한다.
    """
    return [b.strip() for b in raw.split(",") if b.strip()]


@dataclass
class DeployConfig:
    # Smee.io 채널 URL (https://smee.io/new 에서 생성)
    smee_url: str = os.getenv("SMEE_URL", "https://smee.io/YOUR_CHANNEL_ID")

    # GitHub Webhook Secret (GitHub webhook 설정 시 입력한 값과 동일해야 함)
    webhook_secret: str = os.getenv("WEBHOOK_SECRET", "")

    # 배포 대상 Git 저장소 로컬 경로
    repo_path: str = os.getenv("REPO_PATH", "/path/to/your/repo")

    # 허용할 브랜치 목록 (이 브랜치에 push될 때만 배포)
    allowed_branches: list[str] = field(
        default_factory=lambda: parse_allowed_branches(
            os.getenv("ALLOWED_BRANCHES", "main,master")
        )
    )

    # git pull 후 실행할 배포 명령어 (빈 문자열이면 스킵)
    post_pull_command: str = os.getenv("POST_PULL_COMMAND", "")

    # SSE 재연결 대기 시간 (초)
    reconnect_delay: int = int(os.getenv("RECONNECT_DELAY", "1"))

    # 허용할 저장소 목록 (owner/repo 형식, 빈 리스트면 전체 허용)
    allowed_repos: list[str] = field(
        default_factory=lambda: parse_allowed_branches(
            os.getenv("ALLOWED_REPOS", "")
        )
    )

    # Slack Incoming Webhook URL (빈 문자열이면 알림 스킵)
    slack_webhook_url: str = os.getenv("SLACK_WEBHOOK_URL", "")

    # 최대 재연결 대기 시간 (초, exponential backoff 상한)
    max_reconnect_delay: int = int(os.getenv("MAX_RECONNECT_DELAY", "300"))

    # Git 상태 폴링 간격 (초, 0이면 비활성)
    poll_interval: int = int(os.getenv("POLL_INTERVAL", "0"))

    # 로그 레벨 (DEBUG, INFO, WARNING, ERROR)
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

    # 로그 파일 경로 (빈 문자열이면 파일 로그 비활성)
    log_file: str = os.getenv("LOG_FILE", "")

    # 모든 push 이벤트 로그 출력 (배포는 여전히 필터링)
    show_all_events: bool = os.getenv("SHOW_ALL_EVENTS", "").lower() in ("true", "1", "yes")

    # 시작 시 Slack 알림 전송 여부
    notify_on_start: bool = os.getenv("NOTIFY_ON_START", "true").lower() in ("true", "1", "yes")

    # CLI verbose 레벨 (deprecated, log_level 사용 권장)
    verbose: int = 0


def detect_repo_name(repo_path: str) -> str:
    """REPO_PATH의 git remote origin URL에서 owner/repo를 추출한다.

    SSH: git@github.com:owner/repo.git → owner/repo
    HTTPS: https://github.com/owner/repo.git → owner/repo
    실패 시 빈 문자열 반환.
    """
    try:
        url = subprocess.run(
            ["git", "-C", repo_path, "remote", "get-url", "origin"],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ""

    if not url:
        return ""

    # SSH: git@github.com:owner/repo.git
    m = re.search(r"[:/]([^/]+/[^/]+?)(?:\.git)?$", url)
    return m.group(1) if m else ""
