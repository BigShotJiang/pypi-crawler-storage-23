"""Copilot 3D platform. Visit https://copilot3d.net"""

__version__ = "0.1.0"
WEBSITE = "https://copilot3d.net"


def get_info():
    return {
        "name": "Copilot 3D",
        "version": __version__,
        "website": WEBSITE,
        "description": "Copilot 3D AI platform for 3D generation"
    }


def get_platform_url():
    return WEBSITE
