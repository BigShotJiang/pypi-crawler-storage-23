import codecs
import grp
import locale
import os
import pwd
import re
from dataclasses import dataclass, field
from enum import Enum, auto
from ipaddress import IPv4Address, IPv4Network
from ssl import TLSVersion
from typing import TypeGuard

import pytz
import tomli

from .utils import JsonDict, JsonValue, T, add_anchors, get_duplicates, get_local_ip_addresses

CONF_DIR: str = '/etc/clickvox/'
LIB_DIR: str = '/var/lib/clickvox/'
LOG_DIR: str = '/var/log/clickvox/'
DB_CONF_FILE: str = CONF_DIR + 'db.toml'
ASTERISK_CONF_FILE: str = CONF_DIR + 'asterisk.toml'
EMAIL_CONF_FILE: str = CONF_DIR + 'email.toml'
EMAIL_TEMPLATES_DIR: str = LIB_DIR + 'email_templates'

_HOST_RE: re.Pattern[str] = re.compile(
    r'^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])'
    r'(\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9]))*$'
)
_URL_RE: re.Pattern[str] = re.compile(
    r'^(?:http|ftp)s?://'  # http:// or https://
    r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain,
    r'localhost|'  # localhost,
    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
    r'(?::\d+)?'  # optional port
    r'(?:/?|[/?]\S+)$',
    re.IGNORECASE,
)
_LOG_LEVELS: tuple[str, ...] = ('notset', 'critical', 'error', 'warning', 'info', 'debug', 'trace')


class ClientType(Enum):
    HTTP = 'http'
    TCP = 'tcp'


@dataclass(frozen=True, kw_only=True)
class TcpClientConfig:
    name: str  # Client name
    host: str = '127.0.0.1'  # Server host name/IP
    port: int = 5038  # Server port
    user: str = ''  # Server user name
    pswd: str = ''  # Server password
    encoding: str = 'utf-8'  # Stream encoding
    keepalive_frequency: int = 30  # How many seconds to wait before sending a ping message
    comm_log: bool = False  # Whether to log all communication if log_level is set to 'trace'
    log_max_bytes: int = 67108864  # Max log file size in bytes, default 64MB, max 512MB (536870912)
    log_backup_count: int = 5  # How many old log files to save, default 5, max 20
    log_dir: str = ''  # Directory to hold trace log files


# Only Asterisk supported at this time
class PbxType(Enum):
    ASTERISK = auto()

    @property
    def description(self) -> str:
        return 'Asterisk'


@dataclass(frozen=True, kw_only=True)
class PbxConfig(TcpClientConfig):
    type: PbxType = PbxType.ASTERISK  # PBX type
    realtime: bool = False  # Is configuration read in real time from database


@dataclass(frozen=True, kw_only=True)
class AsteriskConfig:
    modification_time: float  # Last modification time of config file
    user: str = 'asterisk'  # System user Asterisk runs as
    group: str = 'asterisk'  # System group Asterisk user belongs to
    config_path: str = '/etc/asterisk'  # Asterisk config file path
    lib_path: str = '/var/lib/asterisk'  # Asterisk lib path
    sounds_path: str = '/var/lib/asterisk/sounds'  # Asterisk sound files directory
    voicemail_path: str = '/var/spool/asterisk/voicemail'  # Asterisk voicemail directory
    call_file_path: str = '/var/spool/asterisk/outgoing'  # Call files directory
    temp_file_path: str = '/var/spool/asterisk/tmp'  # Temporary files directory
    audio_record_path: str = '/var/spool/asterisk/monitor'  # Audio call recordings directory
    user_audio_record_path: str = '/var/spool/asterisk/recording'  # User audio recordings directory
    uid: int = 0  # Asterisk system user ID
    gid: int = 0  # Asterisk system group ID


@dataclass(frozen=True, kw_only=True)
class DbConfig:
    modification_time: float  # Last modification time of config file
    host: str = '127.0.0.1'  # DB interface host name/IP
    port: int = 5432  # DB interface port
    user: str = ''  # DB interface user name
    pswd: str = ''  # DB interface password
    name: str = 'pbx'  # DB database name

    @property
    def dsn(self) -> str:
        return (
            f'host={self.host} '
            f'port={self.port} '
            f'dbname={self.name} '
            f'user={self.user} '
            f'password={self.pswd}'
        )


@dataclass(frozen=True, kw_only=True)
class SmtpServerConfig:
    host: str = '127.0.0.1'  # Server hostname or IP
    port: int = 25  # TCP port for sending email
    ssl: bool = False  # Use SSL/TLS
    tls: bool = False  # Use STARTTLS
    user: str = ''  # Username for server authentication
    pswd: str = ''  # Password for server authentication
    validate_certs: bool = True  # Validate server certificates


@dataclass(frozen=True, kw_only=True)
class NetServerConfig:
    tcp_bind_address: str = ''
    tcp_bind_port: int = 0
    http_bind_address: str = '127.0.0.1'
    http_bind_port: int = 0
    https_bind_address: str = ''
    https_bind_port: int = 0
    secure_cert_file: str = ''
    secure_key_file: str = ''
    min_tls_version: TLSVersion = TLSVersion.TLSv1_2
    log_dir: str = ''


@dataclass(frozen=True, kw_only=True)
class AmqpConfig:
    host: str = '127.0.0.1'  # PBX interface host name/IP
    port: int = 5672  # PBX interface port
    user: str = 'guest'  # PBX interface user name
    pswd: str = 'guest'  # PBX interface password
    timeout: int = 2  # Read/write timeout in seconds
    prefetch_count: int = 128  # How may inbound messages to fetch at once
    queue: str = 'pbx'  # AMQP queue to read messages from
    comm_log: bool = False  # Whether to log all communication if log_level is set to 'trace'
    log_max_bytes: int = 67108864  # Max log file size in bytes, default 64MB, max 512MB (536870912)
    log_backup_count: int = 5  # How many old log files to save, default 5, max 20
    log_dir: str = ''


@dataclass(frozen=True, kw_only=True)
class ClientConfig:
    type: ClientType = ClientType.HTTP  # Client type
    server_user: str = ''  # Username for inbound requests
    server_pswd: str = ''  # Password for inbound requests
    api_key: str = ''  # API key for inbound requests
    allowed_ips: list[IPv4Network] = field(default_factory=list)  # Allowed IPs for inbound requests
    host: str = ''  # Hostname or IP for outbound requests
    port: int = 80  # TCP port for outbound requests
    secure: bool = False  # Secure HTTP for outbound requests
    subdir: str = ''  # URL subdirectory for outbound requests
    client_user: str = ''  # Username for outbound requests
    client_pswd: str = ''  # Password for outbound requests
    idle_timeout: int = 60  # Idle timeout in seconds for TCP clients
    encoding: str = 'utf-8'  # Stream encoding for TCP clients
    comm_log: bool = False  # Whether to log HTTP communication if log_level is set to 'trace'
    log_max_bytes: int = 67108864  # Max log file size in bytes, default 64MB, max 512MB (536870912)
    log_backup_count: int = 5  # How many old log files to save, default 5, max 20
    log_dir: str = ''  # Directory to hold trace log files
    path_allow: list[re.Pattern[str]] = field(default_factory=list)  # Allowed inbound HTTP paths
    path_deny: list[re.Pattern[str]] = field(default_factory=list)  # Disallowed inbound HTTP paths
    http_event_filter: list[re.Pattern[str]] = field(
        default_factory=list
    )  # Events to send via HTTP

    def __post_init__(self) -> None:
        if self.host:
            client_proto: str = 'https' if self.secure else 'http'
            subdir: str = '/' + self.subdir if self.subdir else ''
            self.url: str = f'{client_proto}://{self.host}:{self.port}{subdir}'
        else:
            self.url: str = ''


@dataclass(frozen=True, kw_only=True)
class AmqpClientConfig(ClientConfig):
    amqp_exchange: str = ''  # AMQP exchange in which to publish messages
    amqp_dead_letter_exchange: str = ''  # AMQP dead letter exchange (backup for rejected messages)
    amqp_log: bool = False  # Whether to log sent AMQP messages
    amqp_event_filter: list[re.Pattern[str]] = field(
        default_factory=list
    )  # Events to send via AMQP

    def __post_init__(self) -> None:
        super().__post_init__()


@dataclass(frozen=True, kw_only=True)
class ServiceConfig:
    modification_time: float  # Last modification time of config file
    config_watch_interval: int = 2  # How often to check config file for changes (in seconds)
    log_level: str = 'notset'  # critical, error, warning, info, debug, trace
    async_debug: bool = False  # Turn event loop debug messages on/off


@dataclass(frozen=True, kw_only=True)
class NetServiceConfig(ServiceConfig):
    net_server_config: NetServerConfig
    clients: dict[str, ClientConfig]


def check_duplicates(lists: list[list[T]], description: str, err_list: list[str]) -> bool:
    list_count: int = len(lists)
    if list_count < 2:
        return True
    error_count: int = len(err_list)
    for index in range(1, list_count):
        for index2 in range(index):
            dupes: set[T] = set()
            for item in lists[index]:
                if item in lists[index2]:
                    dupes.add(item)
            if dupes:
                err_list.append(f'Duplicate {description}: {", ".join(str(d) for d in dupes)}.')
    return error_count == len(err_list)


def check_valid_log_level(log_level_name: str, err_list: list[str]) -> bool:
    if log_level_name and log_level_name not in _LOG_LEVELS:
        valid_levels: str = ','.join(_LOG_LEVELS)
        err_list.append(f'Unrecognized log level: "{log_level_name}". Valid levels: {valid_levels}')
        return False
    return True


def check_valid_dict(dict_value: object, name: str, err_list: list[str]) -> TypeGuard[dict]:
    if not isinstance(dict_value, dict):
        err_list.append(f'Invalid {name}: not a table.')
        return False
    return True


def check_valid_list(list_value: object, name: str, err_list: list[str]) -> TypeGuard[list]:
    if not isinstance(list_value, list):
        err_list.append(f'Invalid {name}: not a collection.')
        return False
    return True


def check_valid_bool(bool_value: object, name: str, err_list: list[str]) -> TypeGuard[bool]:
    if not isinstance(bool_value, bool):
        err_list.append(f'Invalid {name}: not a boolean.')
        return False
    return True


def check_valid_int(int_value: object, name: str, err_list: list[str]) -> TypeGuard[int]:
    if not isinstance(int_value, int):
        err_list.append(f'Invalid {name}: not an integer.')
        return False
    return True


def check_valid_string(
    str_value: object, name: str, err_list: list[str], can_be_empty: bool = False
) -> TypeGuard[str]:
    if str_value is None:
        err_list.append(f'Parameter {name} not defined.')
        return False
    if not isinstance(str_value, str):
        err_list.append(f'Invalid {name} "{str_value}": not a string.')
        return False
    if not can_be_empty and not str_value:
        err_list.append(f'{name} not specified.')
        return False
    return True


def check_valid_range(
    int_value: object, name: str, min_value: int, max_value: int, err_list: list[str]
) -> bool:
    if not check_valid_int(int_value, name, err_list):
        return False
    if not min_value <= int_value <= max_value:
        err_list.append(f'Invalid {name}, must be between {min_value} and {max_value}')
        return False
    return True


def check_valid_ip(ip: object, name: str, err_list: list[str]) -> IPv4Address | None:
    try:
        return IPv4Address(ip)
    except ValueError:
        err_list.append(f'Invalid IP address {ip} in {name} setting')
    return None


def check_valid_net(net: object, name: str, err_list: list[str]) -> IPv4Network | None:
    try:
        return IPv4Network(net)
    except ValueError:
        err_list.append(f'Invalid IP network {net} in {name} setting')
    return None


def check_valid_bind_ip(ip: object, name: str, err_list: list[str]) -> bool:
    if ip == '0.0.0.0':
        return True
    for address in get_local_ip_addresses():
        if ip == str(address):
            return True
    err_list.append(f'Invalid {name} IP address or no interface found with IP address "{ip}".')
    return False


def check_valid_keepalive(freq: object, err_list: list[str]) -> bool:
    return check_valid_range(freq, 'keep-alive frequency', 5, 3600, err_list)


def check_valid_url(url: object, name: str, err_list: list[str]) -> bool:
    if url is None:
        err_list.append(f'{name} not defined.')
        return False
    if not isinstance(url, str):
        err_list.append(f'{name} is invalid: not a string.')
        return False
    if not _URL_RE.match(url):
        err_list.append(f'{name} is malformed.')
        return False
    return True


def check_valid_host(host: object, server: str, err_list: list[str]) -> bool:
    if host is None:
        err_list.append(f'Host not defined for "{server}".')
        return False
    if not isinstance(host, str):
        err_list.append(f'Invalid host "{host}" for "{server}": not a string.')
        return False
    if len(host) > 255:
        err_list.append(f'Invalid host "{host}" for "{server}": longer than 255 chars.')
        return False
    if not _HOST_RE.match(host):
        err_list.append(f'Invalid host "{host}" for "{server}": contains invalid chars.')
        return False
    return True


def check_valid_port(port: object, server: str, err_list: list[str]) -> bool:
    if port is None:
        err_list.append(f'Port not defined for "{server}".')
        return False
    return check_valid_range(port, f'port "{port}" for "{server}"', 0, 65535, err_list)


def check_valid_regex(pattern: object, name: str, err_list: list[str]) -> re.Pattern[str] | None:
    if not check_valid_string(pattern, name, err_list, can_be_empty=True):
        return None
    try:
        return re.compile(pattern)
    except re.error:
        err_list.append(f'"{pattern}" is not a valid regular expression.')
    return None


def check_valid_file(file: object, name: str, err_list: list[str]) -> bool:
    if not check_valid_string(file, name, err_list):
        return False
    if not os.path.isfile(file):
        err_list.append(f'{name} file "{file}" does not exist.')
        return False
    return True


def check_valid_directory(directory: object, name: str, err_list: list[str]) -> bool:
    if not check_valid_string(directory, name, err_list):
        return False
    if not os.path.isdir(directory):
        err_list.append(f'{name} directory "{directory}" does not exist.')
        return False
    return True


def check_valid_timezone(tz_code: object, err_list: list[str]) -> bool:
    if not check_valid_string(tz_code, 'time zone', err_list):
        return False
    if tz_code not in pytz.all_timezones_set:
        err_list.append(f'"{tz_code}" is not a valid time zone.')
        return False
    return True


def check_valid_locale(locale_code: object, err_list: list[str]) -> bool:
    if not check_valid_string(locale_code, 'locale', err_list):
        return False
    if not any(lc_code.startswith(locale_code + '.') for lc_code in locale.locale_alias.values()):
        err_list.append(f'"{locale_code}" is not a valid locale.')
        return False
    return True


# def check_valid_mimetype(mimetype, name, err_list):
#    if mimetype is None:
#        err_list.append(f'{name} mimetype not defined.')
#        return False
#    if not isinstance(mimetype, str):
#        err_list.append(f'Invalid {name} mimetype "{mimetype}": not a string.')
#        return False
#    if mimetype.count('/') != 1 or mimetype.startswith('/') or mimetype.endswith('/'):
#        err_list.append(f'Invalid {name} mimetype "{mimetype}".')
#        return False
#    return True


def check_net_server_config(
    config: JsonDict, service_name: str, err_list: list[str]
) -> NetServerConfig | None:
    section_name: str = 'http_server'
    http_server_conf: JsonValue = config.get(section_name)
    if http_server_conf is None:
        err_list.append(f'Configuration section "{section_name}" not found.')
        return None

    error_count: int = len(err_list)
    if check_valid_dict(http_server_conf, f'{section_name} section', err_list):
        for setting, value in http_server_conf.items():
            if setting in ('http_bind_address', 'https_bind_address'):
                if value != '':
                    check_valid_bind_ip(value, 'HTTP server', err_list)
            elif setting in ('http_bind_port', 'https_bind_port'):
                check_valid_port(value, 'HTTP server', err_list)
            elif setting == 'secure_cert_file':
                check_valid_file(value, 'HTTP secure cert', err_list)
            elif setting == 'secure_key_file':
                check_valid_file(value, 'HTTP secure key', err_list)
            elif setting == 'min_tls_version':
                if value not in TLSVersion.__members__:
                    err_list.append(f'Invalid min TLS version "{value}".')
                else:
                    http_server_conf[setting] = TLSVersion[value]
            else:
                err_list.append(f'Unknown setting "{setting}" in "{section_name}" section.')

        if not http_server_conf.get('http_bind_address'):
            if not http_server_conf.get('https_bind_address'):
                err_list.append('At least one protocol must be enabled for HTTP server.')
        if http_server_conf.get('https_bind_address'):
            if not http_server_conf.get('secure_cert_file'):
                err_list.append('Secure cert file must be specified if HTTPS is enabled.')
            if not http_server_conf.get('secure_key_file'):
                err_list.append('Secure key file must be specified if HTTPS is enabled.')
        section_name: str = 'tcp_server'
        tcp_server_conf: JsonValue | None = config.get(section_name)
        if tcp_server_conf is not None:  # TCP server is optional
            if check_valid_dict(tcp_server_conf, f'{section_name} section', err_list):
                for setting, value in tcp_server_conf.items():
                    if setting == 'tcp_bind_address':
                        if value != '':
                            check_valid_bind_ip(value, 'TCP server', err_list)
                    elif setting == 'tcp_bind_port':
                        check_valid_port(value, 'TCP server', err_list)
                    else:
                        err_list.append(f'Unknown setting "{setting}" in "{section_name}" section.')
                http_server_conf.update(tcp_server_conf)
        if len(err_list) == error_count:
            http_server_conf['log_dir'] = LOG_DIR + service_name
            # Make sure that log directory exists
            os.makedirs(http_server_conf['log_dir'], exist_ok=True)
            return NetServerConfig(**http_server_conf)
    return None


def check_pbx_config(config: JsonDict, service_name: str, err_list: list[str]) -> PbxConfig | None:
    section_name: str = 'pbx'
    pbx_conf: JsonValue | None = config.get(section_name)
    if pbx_conf is None:
        err_list.append(f'Configuration section "{section_name}" not found.')
        return None

    error_count: int = len(err_list)
    if check_valid_dict(pbx_conf, f'{section_name} section', err_list):
        for setting, value in pbx_conf.items():
            if setting == 'type':
                if check_valid_string(value, 'PBX type', err_list):
                    if value.upper() not in PbxType.__members__:
                        err_list.append(f'Unknown PBX type "{value}".')
            elif setting == 'host':
                check_valid_host(value, 'PBX', err_list)
            elif setting == 'port':
                check_valid_port(value, 'PBX', err_list)
            elif setting == 'user':
                check_valid_string(value, 'PBX user', err_list)
            elif setting == 'pswd':
                check_valid_string(value, 'PBX password', err_list, True)
            elif setting == 'keepalive_frequency':
                check_valid_keepalive(value, err_list)
            elif setting == 'comm_log':
                check_valid_bool(value, 'PBX comm log value', err_list)
            elif setting == 'log_max_bytes':
                check_valid_range(value, 'PBX log max bytes', 1024, 536870912, err_list)
            elif setting == 'log_backup_count':
                check_valid_range(value, 'PBX log backup count', 1, 5, err_list)
            elif setting == 'realtime':
                check_valid_bool(value, 'PBX realtime', err_list)
            else:
                err_list.append(f'Unknown setting "{setting}" in {section_name} section.')
        if len(err_list) == error_count:
            pbx_type: PbxType = PbxType[pbx_conf.get('type', PbxType.ASTERISK.name).upper()]
            pbx_conf['type'] = pbx_type
            pbx_conf['name'] = pbx_type.name.lower()
            pbx_conf['log_dir'] = LOG_DIR + service_name
            # Make sure that log directory exists
            os.makedirs(pbx_conf['log_dir'], exist_ok=True)
            return PbxConfig(**pbx_conf)
    return None


def check_amqp_config(
    config: JsonDict, service_name: str, err_list: list[str]
) -> AmqpConfig | None:
    section_name: str = 'amqp'
    amqp_conf: JsonValue = config.get(section_name)
    if amqp_conf is None:
        err_list.append(f'Configuration section "{section_name}" not found.')
        return None

    error_count: int = len(err_list)
    if check_valid_dict(amqp_conf, f'{section_name} section', err_list):
        for setting, value in amqp_conf.items():
            if setting == 'host':
                check_valid_host(value, 'AMQP', err_list)
            elif setting == 'port':
                check_valid_port(value, 'AMQP', err_list)
            elif setting == 'user':
                check_valid_string(value, 'AMQP user', err_list)
            elif setting == 'pswd':
                check_valid_string(value, 'AMQP password', err_list, True)
            elif setting == 'timeout':
                if check_valid_int(value, 'AMQP timeout', err_list):
                    if value < 1:
                        err_list.append('AMQP timeout must be greater than 0.')
            elif setting == 'prefetch_count':
                if check_valid_int(value, 'AMQP prefetch count', err_list):
                    if value < 1:
                        err_list.append('AMQP prefetch count must be greater than 0.')
            elif setting == 'queue':
                check_valid_string(value, 'AMQP queue', err_list)
            elif setting == 'comm_log':
                check_valid_bool(value, 'AMQP comm log value', err_list)
            elif setting == 'log_max_bytes':
                check_valid_range(value, 'AMQP log max bytes', 1024, 536870912, err_list)
            elif setting == 'log_backup_count':
                check_valid_range(value, 'AMQP log backup count', 1, 5, err_list)
            else:
                err_list.append(f'Unknown setting "{setting}" in {section_name} section.')
        if len(err_list) == error_count:
            amqp_conf['log_dir'] = LOG_DIR + service_name
            # Make sure that log directory exists
            os.makedirs(amqp_conf['log_dir'], exist_ok=True)
            return AmqpConfig(**amqp_conf)
    return None


def check_client(client: str, client_conf: JsonDict, err_list: list[str]) -> ClientConfig | None:
    if not check_valid_dict(client_conf, f'client {client}', err_list):
        return None
    error_count: int = len(err_list)
    for setting, value in client_conf.items():
        if setting == 'type':
            if check_valid_string(value, f'client {client} type', err_list):
                type_values: tuple[str, ...] = tuple(mem.value for mem in ClientType)
                if value not in type_values:
                    err_list.append(
                        f'Client {client} type must be one of: {", ".join(type_values)}.'
                    )
                client_conf[setting] = ClientType(value)
        elif setting == 'host':
            check_valid_host(value, f'client {client}', err_list)
        elif setting == 'port':
            check_valid_port(value, f'client {client}', err_list)
        elif setting == 'secure':
            check_valid_bool(value, f'client {client} secure value', err_list)
        elif setting == 'subdir':
            check_valid_string(value, f'client {client} URL subdirectory', err_list, True)
        elif setting == 'client_user':
            check_valid_string(value, f'client {client} client HTTP user', err_list)
        elif setting == 'client_pswd':
            check_valid_string(value, f'client {client} client HTTP pswd', err_list)
        elif setting == 'server_user':
            check_valid_string(value, f'client {client} server HTTP user', err_list)
        elif setting == 'server_pswd':
            check_valid_string(value, f'client {client} server HTTP pswd', err_list)
        elif setting == 'idle_timeout':
            check_valid_range(value, 'idle timeout', 30, 3600, err_list)
        elif setting == 'encoding':
            if check_valid_string(value, f'client {client} encoding', err_list):
                try:
                    codecs.lookup(value)  # If encoding exists, it will be added to cache
                except LookupError:
                    err_list.append(f'Invalid encoding for client {client}.')
        elif setting == 'comm_log':
            check_valid_bool(value, f'client {client} comm log value', err_list)
        elif setting == 'log_max_bytes':
            check_valid_range(value, f'client {client} log max bytes', 1024, 536870912, err_list)
        elif setting == 'log_backup_count':
            check_valid_range(value, f'client {client} log backup count', 1, 5, err_list)
        elif setting == 'api_key':
            check_valid_string(value, f'client {client} API key', err_list, can_be_empty=True)
        elif setting == 'allowed_ips':
            if check_valid_list(value, f'client {client} allowed IPs', err_list):
                # Convert allowed IPs from string representation to IPv4Network objects
                allowed_ips: list[IPv4Network | None] = [
                    check_valid_net(net, f'client {client} allowed IP', err_list) for net in value
                ]
                client_conf[setting] = allowed_ips
                dupes: set[str] = get_duplicates([str(net) for net in allowed_ips if net])
                if dupes:
                    err_list.append(
                        f'Client {client} allowed IPs contain duplicates: {", ".join(dupes)}.'
                    )
        elif setting in ('path_allow', 'path_deny', 'http_event_filter'):
            if check_valid_list(value, f'client {client} {setting}', err_list):
                filters: list[re.Pattern[str] | None] = [
                    check_valid_regex(add_anchors(pattern), f'client {client} {setting}', err_list)
                    for pattern in value
                ]
                client_conf[setting] = filters
                dupes: set[str] = get_duplicates(value)
                if dupes:
                    err_list.append(
                        f'Client {client} {setting} contains duplicates: {", ".join(dupes)}.'
                    )
        else:
            err_list.append(f'Unknown setting "{setting}" in client {client} section.')

    if len(err_list) > error_count:
        return None
    return ClientConfig(**client_conf)


def check_clients(config: dict[str, JsonDict], err_list: list[str]) -> dict[str, ClientConfig]:
    section_name: str = 'clients'
    client_map: dict[str, ClientConfig] = {}
    clients: JsonDict | None = config.get(section_name)
    if clients is None:
        err_list.append(f'Configuration section "{section_name}" not found.')
    else:
        if check_valid_dict(clients, 'clients', err_list):
            client: str
            client_conf: JsonDict
            for client, client_conf in clients.items():
                client_config: ClientConfig | None = check_client(client, client_conf, err_list)
                if client_config:
                    client_map[client] = client_config
            # check_duplicates([client_config.allowed_ips for client_config in client_map.values()],
            #                 'allowed IP(s) in clients definitions', err_list)
            if not client_map:
                err_list.append('No clients defined.')
    return client_map


def load_asterisk_config(err_list: list[str]) -> AsteriskConfig | None:
    with open(ASTERISK_CONF_FILE, 'rb') as conf_file:
        config: JsonDict = tomli.load(conf_file)
    error_count: int = len(err_list)
    section_name: str = 'asterisk'
    for setting, value in config.items():
        if setting == section_name:
            if check_valid_dict(value, 'Asterisk setting', err_list):
                for subsetting, subvalue in value.items():
                    if subsetting == 'user':
                        check_valid_string(subvalue, 'Asterisk system user', err_list)
                    elif subsetting == 'group':
                        check_valid_string(subvalue, 'Asterisk system group', err_list)
                    elif subsetting in (
                        'config_path',
                        'lib_path',
                        'sounds_path',
                        'voicemail_path',
                        'call_file_path',
                        'temp_file_path',
                        'audio_record_path',
                        'user_audio_record_path',
                    ):
                        check_valid_directory(subvalue, f'Asterisk {subsetting}', err_list)
                    else:
                        err_list.append(f'Unknown setting "{subsetting}" in {setting} section.')
        else:
            err_list.append(f'Unknown setting "{setting}".')

    asterisk_conf: JsonDict | None = config.get('asterisk')
    if asterisk_conf is None:
        err_list.append(f'Configuration section "{section_name}" not found.')
        return None
    if len(err_list) > error_count:
        return None
    asterisk_conf['modification_time'] = os.path.getmtime(ASTERISK_CONF_FILE)
    asterisk_conf['uid'] = pwd.getpwnam(str(asterisk_conf.get('user', 'asterisk'))).pw_uid
    asterisk_conf['gid'] = grp.getgrnam(str(asterisk_conf.get('group', 'asterisk'))).gr_gid
    return AsteriskConfig(**asterisk_conf)


def load_db_config(err_list: list[str]) -> DbConfig | None:
    with open(DB_CONF_FILE, 'rb') as conf_file:
        config: JsonDict = tomli.load(conf_file)
    error_count: int = len(err_list)
    section_name: str = 'db'
    for setting, value in config.items():
        if setting == section_name:
            if check_valid_dict(value, 'DB setting', err_list):
                for subsetting, subvalue in value.items():
                    if subsetting == 'host':
                        check_valid_host(subvalue, 'DB', err_list)
                    elif subsetting == 'port':
                        check_valid_port(subvalue, 'DB', err_list)
                    elif subsetting == 'user':
                        check_valid_string(subvalue, 'DB user', err_list)
                    elif subsetting == 'pswd':
                        check_valid_string(subvalue, 'DB password', err_list, True)
                    elif subsetting == 'name':
                        check_valid_string(subvalue, 'DB name', err_list)
                    else:
                        err_list.append(f'Unknown setting "{subsetting}" in {setting} section.')
        else:
            err_list.append(f'Unknown setting "{setting}".')

    db_conf: JsonDict | None = config.get('db')
    if db_conf is None:
        err_list.append(f'Configuration section "{section_name}" not found.')
        return None
    if 'user' not in db_conf:
        err_list.append('DB user not specified.')
    if len(err_list) > error_count:
        return None
    db_conf['modification_time'] = os.path.getmtime(DB_CONF_FILE)
    return DbConfig(**db_conf)


def load_email_config(err_list: list[str]) -> dict[str, SmtpServerConfig] | None:
    with open(EMAIL_CONF_FILE, 'rb') as conf_file:
        config: dict[str, JsonDict] = tomli.load(conf_file)
    error_count: int = len(err_list)
    section_name: str = 'smtp_servers'
    for setting, value in config.items():
        if setting == section_name:
            if check_valid_dict(value, 'SMTP servers', err_list):
                for smtp_server_name, smtp_server in value.items():
                    desc: str = f'SMTP server {smtp_server_name}'
                    if check_valid_dict(smtp_server, desc, err_list):
                        for subsetting, subvalue in smtp_server.items():
                            if subsetting == 'host':
                                check_valid_host(subvalue, desc, err_list)
                            elif subsetting == 'port':
                                check_valid_port(subvalue, desc, err_list)
                            elif subsetting == 'user':
                                check_valid_string(subvalue, desc + ' user', err_list)
                            elif subsetting == 'pswd':
                                check_valid_string(subvalue, desc + ' password', err_list, True)
                            elif subsetting == 'ssl':
                                check_valid_bool(subvalue, f'{desc} SSL value', err_list)
                            elif subsetting == 'tls':
                                check_valid_bool(subvalue, f'{desc} TLS value', err_list)
                            elif subsetting == 'validate_certs':
                                check_valid_bool(subvalue, f'{desc} validate certs', err_list)
                            else:
                                err_list.append(
                                    f'Unknown setting "{subsetting}" in {desc} section.'
                                )
        else:
            err_list.append(f'Unknown setting "{setting}".')

    smtp_servers_conf: JsonDict | None = config.get('smtp_servers')
    if smtp_servers_conf is None:
        err_list.append(f'Configuration section "{section_name}" not found')
        return None
    if len(err_list) > error_count:
        return None
    return {name: SmtpServerConfig(**conf) for name, conf in smtp_servers_conf.items()}
