# Error class indicating invalid request
class ArgumentError(Exception):
    pass


# Error class indicating that requested resource is currently unavailable
class ResourceError(Exception):
    pass


# Error class indicating that database conflict has occured
class DataIntegrityError(Exception):
    pass


# Error class indicating internal failure - probably a bug that should be fixed
class InternalError(Exception):
    pass


# Error class indicating failed authorization
class AuthorizationError(Exception):
    pass
