VALID_PBX_TYPES: dict[str, str] = {
    # type name: display name
    'asterisk': 'Asterisk',
}
