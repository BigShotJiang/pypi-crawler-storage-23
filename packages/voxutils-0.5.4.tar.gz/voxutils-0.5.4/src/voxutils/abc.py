import os
import signal
import ssl
import sys
import traceback
from abc import ABC, abstractmethod
from asyncio import (
    FIRST_COMPLETED,
    AbstractEventLoop,
    AbstractServer,
    CancelledError,
    Event,
    Future,
    IncompleteReadError,
    Queue,
    StreamReader,
    StreamWriter,
    Task,
    all_tasks,
    create_task,
    get_event_loop,
    new_event_loop,
    set_event_loop,
    sleep,
    start_server,
    wait,
    wait_for,
)
from collections.abc import AsyncIterable, Awaitable, Callable, Collection, Coroutine, Sequence
from dataclasses import dataclass
from enum import IntEnum, auto
from functools import partial, reduce
from ipaddress import IPv4Address, ip_address
from itertools import repeat
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Generic, TypeAlias, TypeVar, cast

import aiopg
import aiormq
import magic
import orjson
import psycopg2
import uvloop
from aiohttp import (
    BasicAuth,
    ClientConnectorError,
    ClientOSError,
    ClientSession,
    ClientTimeout,
    ServerDisconnectedError,
    hdrs,
    web,
)
from aiopg.pool import _PoolCursorContextManager
from aiormq.abc import ArgumentsType, DeliveredMessage
from aiormq.channel import Channel
from aiormq.connection import Connection
from pamqp.exceptions import PAMQPException
from psycopg2 import Error as PostgresError
from psycopg2.extras import RealDictCursor

from .asyncutils import end_task, run_task, socket_operation
from .config import (
    AmqpClientConfig,
    AmqpConfig,
    ClientConfig,
    ClientType,
    NetServiceConfig,
    ServiceConfig,
    TcpClientConfig,
)
from .exceptions import (
    ArgumentError,
    AuthorizationError,
    DataIntegrityError,
    InternalError,
    ResourceError,
)
from .log import INFO, TRACE, StructuredLogger
from .utils import JsonDict, JsonValue, T

_SOCKET_TIMEOUT: int = 15  # In seconds
_HttpPreHook: TypeAlias = Callable[[web.Request], Awaitable[web.StreamResponse | None]]
_HttpPostHook: TypeAlias = Callable[[web.Request, web.StreamResponse], Awaitable[None]]
# HTTP method, HTTP path, JSON payload, metadata
HttpRequestData: TypeAlias = tuple[str, str, JsonDict | None, JsonDict | None]
HttpHandler: TypeAlias = Callable[[web.Request], Awaitable[JsonValue]]
HttpRoute: TypeAlias = tuple[str, str, HttpHandler | None]  # HTTP method, HTTP path, handler
_AMQP_CONNECTION_EXCEPTIONS: tuple[type[Exception], ...] = (
    RuntimeError,
    ConnectionError,
    PAMQPException,
    aiormq.exceptions.AMQPError,
)
C = TypeVar('C', bound=ServiceConfig)


class ClientStatus(IntEnum):
    UNINITIALIZED = auto()
    CONNECTING = auto()
    CONNECTED = auto()
    ERROR = auto()
    CRITICAL_ERROR = auto()


@dataclass
class Communicator(ABC, Generic[T]):
    name: str  # Client name
    queue: Queue[T]  # Outbound message queue

    def __post_init__(self) -> None:
        self.connect_attempted_event: Event = Event()

    @abstractmethod
    async def start(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    async def stop(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    def is_running(self) -> bool:
        raise NotImplementedError()


class AbstractRetryTimer(ABC):
    """
    This class is used for timing consecutive retries in case of failure.
    User implementations should inherit this class and implement the
    :func:`wait <AbstractRetryTimer.wait>`, :func:`reset <AbstractRetryTimer.reset>`
    and :func:`reset <AbstractRetryTimer.next_delay>` methods.
    """

    @abstractmethod
    async def wait(self) -> float:
        """
        Wait for some time, based on timer algorithm.
        Returns number of seconds waited.
        """
        raise NotImplementedError()

    @abstractmethod
    def reset(self) -> None:
        """
        Reset the timer to default.
        """
        raise NotImplementedError()

    @abstractmethod
    def next(self) -> float:
        """
        Advances the timer and returns the time the timer would have waited in seconds.
        """
        raise NotImplementedError()

    @abstractmethod
    def next_delay(self) -> float:
        """
        Returns the next delay time in seconds.
        """
        raise NotImplementedError()


class SimpleExponentialBackoff(AbstractRetryTimer):
    """
    This is an implementation of AbstractRetryTimer using simple truncated exponential backoff.
    Retry delay starts at the minimum and is doubled up to the maximum.
    """

    def __init__(self, min_delay: int = 1000, max_increases: int = 5) -> None:
        """
        Parameters:
            min_delay: Minimum (starting) delay in milliseconds.
            max_increases: Maximum times to double the initial (minimum) delay.
        """
        if min_delay < 1:
            raise ValueError('Parameter `min_delay` must be larger than zero.')
        if max_increases < 0:
            raise ValueError('Parameter `max_increases` must not be negative.')

        self._min_delay: int = min_delay
        self._max_delay: int = reduce(int.__mul__, repeat(2, max_increases), min_delay)
        self._next_delay: int = 0

    def _advance(self) -> float:
        wait_time: float = self._next_delay / 1000
        if self._next_delay == 0:
            self._next_delay = self._min_delay
            return 0.0
        if self._next_delay < self._max_delay:
            self._next_delay *= 2
        return wait_time

    async def wait(self) -> float:
        wait_time: float = self._advance()
        await sleep(wait_time)  # Sleep even if time is 0, to release control to the event loop
        return wait_time

    def reset(self) -> None:
        self._next_delay = 0

    def next(self) -> float:
        return self._advance()

    def next_delay(self) -> float:
        return self._next_delay / 1000


@dataclass
class HttpClient(Communicator[HttpRequestData | None]):
    config: ClientConfig  # Client configuration
    logger: StructuredLogger  # Logger instance
    retry_timer: AbstractRetryTimer  # Retry timer for connection attempts
    timeout: int = 0  # Request timeout (in seconds)
    converter: Callable[[HttpRequestData], Awaitable[HttpRequestData]] | None = (
        None  # Message converter
    )
    init: Callable[['HttpClient'], Awaitable[None]] | None = None  # Initializer coroutine
    hook: Callable[[JsonValue, JsonDict], Awaitable[None]] | None = (
        None  # Coroutine to handle request result
    )

    def __post_init__(self) -> None:
        super().__post_init__()
        self._status: ClientStatus = ClientStatus.UNINITIALIZED
        kwargs = {}
        if self.timeout:
            kwargs['timeout'] = ClientTimeout(total=self.timeout)  # In seconds
        if self.config.client_user:
            kwargs['auth'] = BasicAuth(self.config.client_user, self.config.client_pswd, 'utf-8')
        self._session = ClientSession(**kwargs)
        self._request_counter = 0
        self._logger_trace: StructuredLogger | None = None
        if self.logger.isEnabledFor(TRACE) and self.config.comm_log:
            logger_name: str = 'http_' + self.name
            self._logger_trace = StructuredLogger(
                logger_name=logger_name,
                level=TRACE,
                handler=RotatingFileHandler(
                    filename=os.path.join(self.config.log_dir, logger_name),
                    maxBytes=self.config.log_max_bytes,
                    backupCount=self.config.log_backup_count,
                    encoding='utf-8',
                ),
                include_timestamp=False,
                include_level=False,
            )

    @property
    def status(self) -> ClientStatus:
        return self._status

    async def request(self, request_data: HttpRequestData) -> JsonValue:
        """
        Sends HTTP request and returns text or JSON payload if available.
        """
        seq: int = self._request_counter
        self._request_counter += 1
        method, path, msg, metadata = request_data
        if path:
            url: str = '/'.join((self.config.url, path))
        else:
            url: str = self.config.url
        if path == 'status':
            url = url.replace('api/sms/', 'api/')  # TODO: Hack until getting rid of legacy mode
        if self._logger_trace:
            self._logger_trace.trace(
                'Sending HTTP request', seq=seq, method=method, url=url, json=msg
            )
        try:
            async with self._session.request(method, url, json=msg) as resp:
                if not 200 <= resp.status <= 299:
                    error_msg: str = await resp.text()
                    self.logger.error(
                        'HTTP request denied',
                        seq=seq,
                        client=self.name,
                        method=method,
                        url=url,
                        json=msg,
                        status=resp.status,
                        message=error_msg,
                    )
                    raise RuntimeError('HTTP request denied: ' + error_msg)
                force_json: bool = bool(metadata and metadata.get('force_json'))
                if force_json or resp.content_type == 'application/json':
                    json_result: JsonValue = orjson.loads(await resp.read())
                    if self._logger_trace:
                        self._logger_trace.trace(
                            'Received JSON response',
                            seq=seq,
                            client=self.name,
                            status=resp.status,
                            message=json_result,
                        )
                    return json_result
                if resp.content_type.startswith('text/'):
                    text: str = await resp.text()
                    if self._logger_trace:
                        self._logger_trace.trace(
                            'Received text response',
                            seq=seq,
                            client=self.name,
                            status=resp.status,
                            message=text,
                        )
                    return text
                if self._logger_trace:
                    self._logger_trace.trace(
                        'Received response', seq=seq, client=self.name, status=resp.status
                    )
        except ClientConnectorError:
            self.logger.exception(
                'Error while connecting to web server',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except ServerDisconnectedError:
            self.logger.exception(
                'Web server disconnected unexpectedly',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except ClientOSError:
            self.logger.exception(
                'HTTP transport error', seq=seq, client=self.name, method=method, url=url, json=msg
            )
            raise
        except TimeoutError:
            self.logger.exception(
                'Timeout while connecting to web server',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except ConnectionResetError:
            self.logger.exception(
                'HTTP server connection lost',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except OSError:
            self.logger.exception(
                'Unexpected exception', seq=seq, client=self.name, method=method, url=url, json=msg
            )
            raise

        return None

    async def start(self) -> None:
        self.logger.debug('Starting HTTP client task', client=self.name)

        self._status = ClientStatus.CONNECTING
        current_data: HttpRequestData | None = None
        self.connect_attempted_event.set()  # No initial connection, so set immediately
        while True:
            try:
                if self.init and self._status != ClientStatus.CONNECTED:
                    # Should raise exception on error
                    await self.init(self)
                if not current_data:
                    current_data = await self.queue.get()
                    if current_data is None:
                        break
                    if self.converter:
                        current_data = await self.converter(current_data)
                request_result: JsonValue = await self.request(current_data)
                if self.hook:
                    await self.hook(request_result, current_data[3])  # Result, metadata
                self.queue.task_done()
                current_data = None
                if self._status != ClientStatus.CONNECTED:
                    self.retry_timer.reset()
                    self._status = ClientStatus.CONNECTED
                continue
            except Exception as exc:  # pylint: disable=broad-except
                self._status = ClientStatus.ERROR
                if self.hook and current_data:
                    await self.hook(exc, current_data[3])  # Exception, metadata
                    self.queue.task_done()
                    current_data = None

            if self.logger.isEnabledFor(INFO):
                delay: float = self.retry_timer.next_delay()
                if delay > 0.0:
                    self.logger.info('Delaying next connect attempt', delay=delay, client=self.name)
            await self.retry_timer.wait()

        await self._session.close()
        self.logger.debug('HTTP client task stopped', client=self.name)

    async def stop(self) -> None:
        self.logger.debug('Stopping HTTP client task', client=self.name)
        await self.queue.put(None)
        self._status = ClientStatus.UNINITIALIZED
        self.connect_attempted_event.clear()

    def is_running(self) -> bool:
        return self.status == ClientStatus.CONNECTED


@dataclass
class AmqpClient:
    config: AmqpConfig  # AMQP configuration
    clients: Collection[AmqpClientConfig]  # list of AMQP clients
    logger: StructuredLogger  # Logger instance
    retry_timer: AbstractRetryTimer  # Retry timer for connection attempts
    processor: Callable[[JsonDict], Awaitable[None]]  # AMQP message processor coroutine
    trace_ignore_in: dict[str, list[str]] | None = None  # Don't log messages with these values
    trace_ignore_out: dict[str, list[str]] | None = None  # Don't log messages with these values

    def __post_init__(self) -> None:
        self._status: ClientStatus = ClientStatus.UNINITIALIZED
        self._ready_event: Event = Event()
        self._processing_event: Event = Event()
        self._is_shutting_down: bool = False
        self._connection: Connection | None = None
        self._channel_in: Channel | None = None
        self._channel_out: Channel | None = None
        self._logger_in: StructuredLogger | None = None
        self._loggers_client: dict[str, StructuredLogger] = {}
        if self.logger.isEnabledFor(TRACE):
            if self.config.comm_log:
                logger_name: str = 'amqp_in_' + self.config.queue
                self._logger_in = StructuredLogger(
                    logger_name=logger_name,
                    level=TRACE,
                    handler=RotatingFileHandler(
                        filename=os.path.join(self.config.log_dir, logger_name),
                        maxBytes=self.config.log_max_bytes,
                        backupCount=self.config.log_backup_count,
                        encoding='utf-8',
                    ),
                    include_timestamp=False,
                    include_level=False,
                )
            for client_config in (conf for conf in self.clients if conf.amqp_log):
                logger_name: str = 'amqp_out_' + client_config.amqp_exchange
                self._loggers_client[client_config.amqp_exchange] = StructuredLogger(
                    logger_name=logger_name,
                    level=TRACE,
                    handler=RotatingFileHandler(
                        filename=os.path.join(self.config.log_dir, logger_name),
                        maxBytes=client_config.log_max_bytes,
                        backupCount=client_config.log_backup_count,
                        encoding='utf-8',
                    ),
                    include_timestamp=False,
                    include_level=False,
                )

    @property
    def status(self) -> ClientStatus:
        return self._status

    @property
    def ready(self) -> Event:
        return self._ready_event

    def _reconnect(self, closing: Future[T]) -> None:
        # pylint: disable=unused-argument
        loop: AbstractEventLoop = get_event_loop()
        # loop.run_until_complete(self._disconnect())
        self.logger.info('AMQP connection closed', host=self.config.host)
        if self._is_shutting_down:
            return
        self._status = ClientStatus.ERROR
        self._channel_in = None
        self._channel_out = None
        self._connection = None
        self._ready_event.clear()
        loop.create_task(end_task(f'{self.config.queue} AMQP consumer'))
        loop.create_task(self.start())

    async def _consumer(self, message: DeliveredMessage) -> None:
        await self._processing_event.wait()
        self._processing_event.clear()
        event_data: JsonDict = orjson.loads(message.body)
        if self._logger_in:
            if self.trace_ignore_in:
                ignore: bool = any(
                    event_data.get(key) in val for key, val in self.trace_ignore_in.items()
                )
            else:
                ignore: bool = False
            if not ignore:
                trace: bytes = orjson.dumps(event_data, option=orjson.OPT_INDENT_2)
                self._logger_in.trace(trace.decode('utf-8'))
        await self.processor(event_data)
        # Acknowledge reception
        assert message.delivery_tag is not None  # For type checkers
        await message.channel.basic_ack(message.delivery_tag)
        self._processing_event.set()

    async def _consumer_monitor(self) -> None:
        queue_name: str = self.config.queue
        timeout: int = self.config.timeout
        while True:
            try:
                await self._ready_event.wait()
                assert self._channel_in is not None
                if queue_name not in self._channel_in.consumers:
                    await self._channel_in.basic_consume(
                        queue_name, self._consumer, timeout=timeout, consumer_tag=queue_name
                    )
                    self.logger.debug('AMQP consumer started', host=self.config.host)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('AMQP consumer error', host=self.config.host)
            if self._is_shutting_down:
                return
            await sleep(5)

    async def publish(self, message: JsonValue, routing_key: str, exchange: str) -> bool:
        await self._ready_event.wait()
        client_logger: StructuredLogger | None = self._loggers_client.get(exchange)
        if client_logger:
            if self.trace_ignore_out and isinstance(message, dict):
                ignore: bool = any(
                    message.get(key) in val
                    for key, val in self.trace_ignore_out.items()
                )
            else:
                ignore: bool = False
            if not ignore:
                trace: bytes = orjson.dumps(message, option=orjson.OPT_INDENT_2)
                client_logger.trace(trace.decode('utf-8'))
        try:
            assert self._channel_out is not None  # For type checkers
            await self._channel_out.basic_publish(
                orjson.dumps(message),
                routing_key=routing_key,
                exchange=exchange,
                timeout=self.config.timeout,
            )
            await self._channel_out.confirm_delivery(timeout=self.config.timeout)
        except Exception:  # pylint: disable=broad-except
            self.logger.exception(
                'Error while publihing to AMQP', routing_key=routing_key, exchange=exchange
            )
            await self._disconnect()
            return False
        return True

    async def start(self) -> None:
        if self._status in (ClientStatus.CONNECTED, ClientStatus.CONNECTING):
            raise RuntimeError('AMQP client already started')

        self._processing_event.set()  # Event is cleared initially
        prefetch_count: int = self.config.prefetch_count
        timeout: int = self.config.timeout
        queue_name: str = self.config.queue
        host: str = self.config.host
        port: int = self.config.port
        user: str = self.config.user
        pswd: str = self.config.pswd
        amqp_url: str = f'amqp://{user}:{pswd}@{host}:{port}?heartbeat=1'

        self._status = ClientStatus.CONNECTING
        run_task(self._consumer_monitor(), f'{queue_name} AMQP consumer')
        while True:
            try:
                self.logger.debug('Trying connection to AMQP', host=self.config.host)
                self._connection = Connection(amqp_url)
                await wait_for(self._connection.connect(), _SOCKET_TIMEOUT)
                self._channel_in = cast(Channel, await self._connection.channel())
                await self._channel_in.basic_qos(prefetch_count=prefetch_count, timeout=timeout)
                await self._channel_in.queue_declare(queue_name, durable=True)
                self._channel_out = cast(Channel, await self._connection.channel())
                for client in self.clients:
                    await self._channel_out.exchange_declare(
                        exchange=client.amqp_exchange, exchange_type='fanout', durable=True
                    )
                    arguments: ArgumentsType = {}
                    if client.amqp_dead_letter_exchange:
                        arguments['x-dead-letter-exchange'] = client.amqp_dead_letter_exchange
                    # Queue is assumed to have the same name as the exchange
                    await self._channel_out.queue_declare(
                        client.amqp_exchange, durable=True, arguments=arguments
                    )
                    await self._channel_out.queue_bind(client.amqp_exchange, client.amqp_exchange)
                self._connection.closing.add_done_callback(self._reconnect)
                self._status = ClientStatus.CONNECTED
                self.retry_timer.reset()
                self._ready_event.set()
                self.logger.info('AMQP connection established')
                return
            except TimeoutError:
                self.logger.error('AMQP connection attempt timed out', host=self.config.host)
                self._status = ClientStatus.ERROR
            except _AMQP_CONNECTION_EXCEPTIONS as err:
                self.logger.error('AMQP connection error', err=str(err), host=self.config.host)
                self._status = ClientStatus.ERROR
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Unexpected AMQP connection error', host=self.config.host)
                self._status = ClientStatus.ERROR
            except CancelledError:
                self._status = ClientStatus.ERROR
                if not self._is_shutting_down:
                    create_task(self.start())
                raise

            if self._is_shutting_down:
                return

            if self.logger.isEnabledFor(INFO):
                delay: float = self.retry_timer.next_delay()
                if delay > 0.0:
                    self.logger.info(
                        'Delaying next connect attempt', delay=delay, host=self.config.host
                    )
            await self.retry_timer.wait()

    async def stop(self) -> None:
        self.logger.debug('Stopping AMQP client', host=self.config.host)

        self._is_shutting_down = True
        await end_task(f'{self.config.queue} AMQP consumer')
        await self._disconnect()

    def is_running(self) -> bool:
        return self.status == ClientStatus.CONNECTED

    async def _disconnect(self) -> None:
        self._ready_event.clear()
        if self._channel_in:
            try:
                await wait_for(self._channel_in.close(), _SOCKET_TIMEOUT)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Error while closing input channel', host=self.config.host)
            else:
                self.logger.debug('AMQP input channel closed', host=self.config.host)
            self._channel_in = None
        if self._channel_out:
            try:
                await wait_for(self._channel_out.close(), _SOCKET_TIMEOUT)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Error while closing output channel', host=self.config.host)
            else:
                self.logger.debug('AMQP output channel closed', host=self.config.host)
            self._channel_out = None
        if self._connection:
            self._status = ClientStatus.UNINITIALIZED
            try:
                await wait_for(self._connection.close(), _SOCKET_TIMEOUT)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Error while closing connection', host=self.config.host)


@dataclass
class TcpClient(Generic[T], Communicator[T]):
    config: TcpClientConfig
    logger: StructuredLogger
    retry_timer: AbstractRetryTimer

    def __post_init__(self) -> None:
        super().__post_init__()
        self._logger_trace: StructuredLogger | None = None
        if self.logger.isEnabledFor(TRACE) and self.config.comm_log:
            logger_name: str = self.config.name.lower()
            self._logger_trace = StructuredLogger(
                logger_name=logger_name,
                level=TRACE,
                handler=RotatingFileHandler(
                    filename=os.path.join(self.config.log_dir, logger_name),
                    maxBytes=self.config.log_max_bytes,
                    backupCount=self.config.log_backup_count,
                    encoding='utf-8',
                ),
                include_timestamp=True,
                include_level=False,
            )
        self._ready_event: Event = Event()
        self._data_received_event: Event = Event()
        self._shut_down: Event = Event()
        self._is_shutting_down: bool = False
        self._reader: StreamReader | None = None
        self._writer: StreamWriter | None = None

    @property
    def ready(self) -> Event:
        return self._ready_event

    async def start(self) -> None:
        name: str = self.config.name
        self.logger.info('Starting %s client', name)
        error_message: str = ''
        conn_error: Exception | None
        tasks: set[Task[None]] = set()
        while True:
            try:
                conn_error = None
                tasks = await self._connect()  # Should raise error if not successful
                tasks.update(
                    {
                        create_task(self._connection_keeper(), name=f'[{self.config.name}] Keeper'),
                        create_task(self._sender(), name=f'[{self.config.name}] Sender'),
                        create_task(self._receiver(), name=f'[{self.config.name}] Receiver'),
                    }
                )
                self.retry_timer.reset()
                self.connect_attempted_event.set()
                self._ready_event.set()  # Inform anyone interested that the service is ready
                # Wait until any task fails
                done_tasks: set[Task[None]] = set()
                pending_tasks: set[Task[None]] = set()
                done_tasks, pending_tasks = await wait(tasks, return_when=FIRST_COMPLETED)
                task: Task[None]
                for task in done_tasks:
                    await self._end_task(task)
                for task in pending_tasks:
                    await self._end_task(task)
            except RuntimeError as err:
                self.logger.critical(
                    'Permanently aborting communication with TCP server',
                    server=name,
                    reason=str(err),
                )
                break
            except ConnectionResetError as err:
                error_message = 'Connection lost'
                conn_error = err
            except TimeoutError as err:
                error_message = 'Timed out'
                conn_error = err
            except (IncompleteReadError, OSError, ValueError) as err:
                error_message = 'Error while reading from network'
                conn_error = err
            except CancelledError:
                self.logger.debug('%s client cancelled', name)
                await self._disconnect()
                for task in tasks:
                    await self._end_task(task)
                self._shut_down.set()
                raise
            finally:
                self.connect_attempted_event.set()

            if self._is_shutting_down:
                break
            if conn_error:
                self.logger.error(error_message, exception=repr(conn_error), server=name)
            if conn_error and self.logger.isEnabledFor(INFO):
                delay: float = self.retry_timer.next_delay()
                if delay > 0.0:
                    self.logger.info('Delaying next connect attempt', delay=delay, server=name)
            await self.retry_timer.wait()
        self._shut_down.set()

    async def stop(self) -> None:
        """
        Cleanly shutdown the TCP client.
        """
        name: str = self.config.name
        self.logger.info('Shutting down TCP client', server=name)
        self._is_shutting_down = True
        await self._disconnect()
        await self._shut_down.wait()
        self.connect_attempted_event.clear()
        self.logger.info('TCP client is shut down', server=name)

    def is_running(self) -> bool:
        return self._ready_event.is_set()

    @abstractmethod
    async def _connect(self) -> set[Task[None]]:
        raise NotImplementedError()

    @abstractmethod
    async def _ping(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    async def _receiver(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    async def _sender(self) -> None:
        raise NotImplementedError()

    async def _disconnect(self) -> None:
        if self._writer is None:
            return  # Already disconnected
        name: str = self.config.name
        self.logger.debug('Closing network connection to TCP server', server=name)
        try:
            self._writer.transport.set_write_buffer_limits(0)  # pytype: disable=attribute-error
            await self._writer.drain()
            self._writer.write_eof()
            self._writer = None
        except (OSError, TimeoutError, IncompleteReadError, RuntimeError):
            self.logger.exception('Error while shutting down TCP connection', server=name)
        self.logger.debug('Closed network connection to TCP server', server=name)

    async def _end_task(self, task: Task[T]) -> None:
        """
        Ends a top-level task after error or shutdown.
        """
        task_name: str = task.get_name()
        self.logger.debug('Ending task', task=task_name)
        try:
            await wait_for(task, 0.5)  # Give task a chance to end gracefully
        except TimeoutError:
            await end_task(task)
            return
        except (ConnectionResetError, TimeoutError, IncompleteReadError, OSError, ValueError):
            # We are ending a task so we don't care about errors
            pass
        self.logger.debug('Ended task', task=task_name)

    async def _connection_keeper(self) -> None:
        """
        Keeps TCP connection to server alive, and exits in case of broken connection.
        """
        interval: int = self.config.keepalive_frequency
        sleep_task: Task[None] | None = None
        event_task: Task[bool] | None = None
        try:
            while True:
                # Wait for interval to expire or data event to be triggered, whichever comes first.
                # Receiver function will trigger the event after data is received.
                sleep_task = run_task(sleep(interval))
                event_task = run_task(self._data_received_event.wait())
                done: set[Task[None | bool]]
                done, _pending = await wait({sleep_task, event_task}, return_when=FIRST_COMPLETED)
                await next(iter(done))  # There must be only one element

                if self._is_shutting_down:
                    break

                if sleep_task in done:
                    # Interval expired, send keep-alive message
                    run_task(self._ping())
                    # Wait for data for predefined time, after which TimeoutError will be raised
                    await socket_operation(event_task)
                else:
                    # Data was received, cancel sleep task and start over
                    await end_task(sleep_task)

                if self._is_shutting_down:
                    break

                self._data_received_event.clear()
        except TimeoutError:
            # This error is expected so we don't include it in logging
            self.logger.error('Timed out while waiting for ping response')
        except CancelledError:
            if sleep_task:
                await end_task(sleep_task)
            if event_task:
                await end_task(event_task)
            raise


@dataclass
class PbxClient(TcpClient):
    event_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None
    start_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None
    stop_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None
    reload_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None

    def __post_init__(self) -> None:
        super().__post_init__()

    @abstractmethod
    async def read_list(
        self,
        ami_action: JsonDict,
        list_events: str | tuple[str, ...],
        list_end_event: str,
    ) -> list[JsonDict]:
        raise NotImplementedError()

    @abstractmethod
    async def read_scalar(self, ami_action: JsonDict, value_name: str) -> str:
        raise NotImplementedError()

    @abstractmethod
    async def read_scalars(self, ami_action: JsonDict, value_names: tuple[str, ...]) -> list[str]:
        raise NotImplementedError()

    @abstractmethod
    async def execute(self, ami_action: JsonDict) -> dict[str, str]:
        raise NotImplementedError()

    @abstractmethod
    async def get_variable(self, variable: str, channel_id: str = '') -> str:
        raise NotImplementedError()

    @abstractmethod
    async def set_variable(self, variable: str, value: str, channel_id: str = '') -> dict[str, str]:
        raise NotImplementedError()


class PostgresDriver:
    _SENTINEL_POOL: aiopg.Pool = aiopg.Pool(
        dsn = '',
        minsize = 0,
        maxsize = 0,
        timeout = 1.0,
        enable_json = False,
        enable_hstore = False,
        enable_uuid = False,
        echo = False,
        on_connect = None,
        pool_recycle = 1.0,
    )

    def __init__(self, dsn: str, retry_timer: AbstractRetryTimer, logger: StructuredLogger) -> None:
        self._dsn: str = dsn
        self._retry_timer: AbstractRetryTimer = retry_timer
        self._logger: StructuredLogger = logger
        self._pool: aiopg.Pool = self._SENTINEL_POOL
        self._ready_event = Event()
        self._rowcount: int = 0

    async def _connect(self) -> None:
        while True:
            self._ready_event.clear()
            if self._pool is not self._SENTINEL_POOL:
                self._logger.debug('Waiting for database connections to close')
                try:
                    self._pool.terminate()
                    await self._pool.wait_closed()
                except Exception:  # pylint: disable=broad-except
                    pass
                self._pool = self._SENTINEL_POOL
            try:
                self._logger.debug('Trying database connection')
                #  Use psycopg2 to test connection because repeated failed connection attempts
                #  with aiopg will cause a resource error
                with psycopg2.connect(self._dsn + ' connect_timeout=5'):
                    pass
                self._pool = await aiopg.create_pool(self._dsn + ' connect_timeout=5')
                # Test that the connection is functional
                with await self._pool.cursor() as crsr:
                    await crsr.execute('SELECT 0')
                self._logger.info('Database connection OK')
                self._retry_timer.reset()
                self._ready_event.set()  # Inform anyone interested that the database is ready
                # Any database operation that fails will clear the event and call this function
                return
            except PostgresError as err:
                self._logger.error('Could not connect to database: ' + str(err))
                if 'authentication failed' in str(err):
                    return  # Invalid credentials, no point in continuing
            except RuntimeError as err:
                self._logger.error('Runtime error while connecting to database: "%s"', str(err))
                traceback.print_exc()
            except Warning as warn:
                self._logger.warning('Warning while connecting to database: "%s"', str(warn))
            if self._logger.isEnabledFor(INFO):
                delay: float = self._retry_timer.next_delay()
                if delay > 0.0:
                    self._logger.info('Delaying next database connect attempt by %s seconds', delay)
            await self._retry_timer.wait()

    async def _db_query(self, db_coro: Awaitable[T]) -> T:
        if not self._ready_event.is_set():
            raise RuntimeError('Database not ready')

        try:
            return await db_coro
        except PostgresError as err:
            self._ready_event.clear()
            self._logger.error(
                'Database error: %s "%s"', err.diag.sqlstate, err.diag.message_primary
            )
            run_task(self._connect(), 'Database connector')
            raise

    async def _db_iterable(
        self,
        db_func: Callable[[str, Collection[JsonValue]], AsyncIterable[T]],
        query: str,
        params: Collection[JsonValue],
    ) -> AsyncIterable[T]:
        try:
            async for item in db_func(query, params):
                yield item
        except PostgresError as err:
            self._ready_event.clear()
            self._logger.error(
                'Database error: %s "%s"', err.diag.sqlstate, err.diag.message_primary
            )
            run_task(self._connect(), 'Database connector')
            raise

    async def _exec(self, query: str, params: Collection[JsonValue]) -> None:
        with await self._pool.cursor() as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            self._rowcount = crsr.rowcount
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(f'{self._rowcount} row(s) affected')

    async def _select(
        self, query: str, params: Collection[JsonValue]
    ) -> list[tuple[JsonValue, ...]]:
        with await self._pool.cursor() as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            self._rowcount = crsr.rowcount
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(f'{self._rowcount} row(s) affected')
            return await crsr.fetchall()

    async def _select_dict(self, query: str, params: Collection[JsonValue]) -> list[JsonDict]:
        with await self._pool.cursor(cursor_factory=RealDictCursor) as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            self._rowcount = crsr.rowcount
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(f'{crsr.rowcount} row(s) affected')
            return await crsr.fetchall()

    async def _yield_tuple(
        self, query: str, params: Collection[JsonValue]
    ) -> AsyncIterable[tuple[JsonValue, ...]]:
        with await self._pool.cursor() as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            async for row in crsr:
                yield row

    async def _yield_dict(
        self, query: str, params: Collection[JsonValue]
    ) -> AsyncIterable[JsonDict]:
        with await self._pool.cursor(cursor_factory=RealDictCursor) as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            async for row in crsr:
                yield row

    async def _scalar(self, query: str, params: Collection[JsonValue]) -> JsonValue:
        with await self._pool.cursor() as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            self._rowcount = crsr.rowcount
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(f'{crsr.rowcount} row(s) affected')
            record: tuple[JsonValue, ...] | None = await crsr.fetchone()
            return record[0] if record else None

    async def _scalarlist(self, query: str, params: Collection[JsonValue]) -> tuple[JsonValue, ...]:
        with await self._pool.cursor() as crsr:
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(crsr.mogrify(query, params))
            await crsr.execute(query, params)
            self._rowcount = crsr.rowcount
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace(f'{crsr.rowcount} row(s) affected')
            rows: list[tuple[JsonValue, ...]] = await crsr.fetchall()
            if not rows:
                return ()
            if len(rows) == 1:
                # If there is one row, return it
                return rows[0]
            # If there are multiple rows, return first field of each row
            return tuple(row[0] for row in rows)

    @property
    def rowcount(self) -> int:
        return self._rowcount

    @property
    def ready(self) -> Event:
        return self._ready_event

    async def cursor(self) -> _PoolCursorContextManager:
        if self._pool is self._SENTINEL_POOL:
            raise PostgresError('Database not connected')
        return await self._pool.cursor()

    async def start(self) -> None:
        run_task(self._connect(), 'Database connector')
        await self._ready_event.wait()

    async def stop(self) -> None:
        connect_task: Task[T] | None = next(
            (t for t in all_tasks() if t.get_name() == 'Database connector'), None
        )
        if connect_task:
            connect_task.cancel()
            try:
                await connect_task  # Will raise CancelledError
            except CancelledError:
                pass
        if self._pool is not self._SENTINEL_POOL:
            try:
                self._pool.terminate()
                await self._pool.wait_closed()
            except Exception:  # pylint: disable=broad-except
                pass

    # Retries operation until database is ready
    async def try_db_operation(self, coroutine: Awaitable[T]) -> T:
        while True:
            await self._ready_event.wait()
            try:
                return await coroutine
            except PostgresError:
                pass  # Error will be logged, event cleared and connection restart initiated

    async def exec(self, query: str, params: Collection[JsonValue]) -> None:
        await self._db_query(self._exec(query, params))

    async def select(
        self, query: str, params: Collection[JsonValue]
    ) -> list[tuple[JsonValue, ...]]:
        return await self._db_query(self._select(query, params))

    async def select_dict(self, query: str, params: Collection[JsonValue]) -> list[JsonDict]:
        return await self._db_query(self._select_dict(query, params))

    async def yield_tuple(
        self, query: str, params: Collection[JsonValue]
    ) -> AsyncIterable[tuple[JsonValue, ...]]:
        async for row in self._db_iterable(self._yield_tuple, query, params):
            yield row

    async def yield_dict(
        self, query: str, params: Collection[JsonValue]
    ) -> AsyncIterable[JsonDict]:
        async for row in self._db_iterable(self._yield_dict, query, params):
            yield row

    async def scalar(self, query: str, params: Collection[JsonValue]) -> JsonValue:
        return await self._db_query(self._scalar(query, params))

    async def scalarlist(self, query: str, params: Collection[JsonValue]) -> tuple[JsonValue, ...]:
        return await self._db_query(self._scalarlist(query, params))

    async def try_query(self, coro: Awaitable[T]) -> T:
        while True:
            await self._ready_event.wait()
            try:
                return await coro
            except PostgresError:
                pass


class SystemService(ABC, Generic[C]):
    def __init__(self, config: C, name: str) -> None:
        self._config: C = config
        self._name: str = name
        self._return_value: int = 0
        self._error_occured: bool = False
        self._is_shutting_down: bool = False
        self._logger: StructuredLogger = StructuredLogger(
            logger_name=name,
            level=config.log_level,
            include_timestamp=False,
        )

        uvloop.install()  # Use faster replacement for asyncio event loop
        try:
            self._loop: AbstractEventLoop = get_event_loop()
        except RuntimeError:
            self._loop = new_event_loop()
            set_event_loop(self._loop)
        self._loop.set_debug(self._config.async_debug)
        self._loop.set_exception_handler(self._handle_exception)
        self._loop.run_until_complete(self.__ainit__())
        self._attach_signal_handlers()

    def __init_subclass__(cls) -> None:
        return super().__init_subclass__()

    async def __ainit__(self) -> None:
        self._ready_event: Event = Event()

    @property
    def ready(self) -> Event:
        return self._ready_event

    def _attach_signal_handlers(self) -> None:
        """
        Attaches shutdown signal handlers to asyncio loop
        """

        def signal_handler(sig: signal.Signals) -> None:
            self._loop.create_task(self.shutdown(sig.name + ' signal'))

        signals: set[signal.Signals] = {signal.SIGTERM, signal.SIGINT, signal.SIGQUIT}
        for sig in signals:
            self._loop.add_signal_handler(sig, signal_handler, sig)

    def _handle_exception(self, loop: AbstractEventLoop, context: dict[str, Any]) -> None:
        """
        Global asyncio exception handler
        """
        err: Exception | None = context.get('exception')
        task: Task[T] | None = context.get('task')
        task_name: str = task.get_name() if task else ''
        if err:
            if isinstance(err, Warning):
                self._logger.warning('Unexpected warning', warning=str(err), task_name=task_name)
                return  # Ignore
            if isinstance(err, RuntimeError) and task:
                self._logger.debug(
                    'RuntimeError in task callback', error_message=str(err), task_name=task_name
                )
                return  # Coroutine was probably already awaited on
            if isinstance(err, CancelledError):
                if task_name:
                    self._logger.debug('%s cancelled', task_name)
                return
        self._error_occured = True
        self._return_value = 1
        self._logger.critical(
            'Unexpected exception', task_name=task_name, message=context['message']
        )
        if err and err.__traceback__:
            self._logger.critical(traceback.format_exception(err))
        elif 'source_traceback' in context:
            self._logger.critical(context['source_traceback'])
        self._ready_event.set()  # If error occured during startup, we must allow shutdown to run
        # context["message"] will always be there; but context["exception"] may not be
        msg: str = repr(err) if err else context['message']
        loop.create_task(self.shutdown('Unexpected exception ' + msg))

    @abstractmethod
    async def _start(self) -> None:
        raise NotImplementedError()

    def start(self) -> None:
        self._logger.info('The service is starting.')

        try:
            self._loop.run_until_complete(self._start())
            self._ready_event.set()
            self._logger.info('The service is running.')
            self._loop.run_forever()
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Unhandled service error.')
        finally:
            self._loop.close()
            self._logger.info('The service is shut down.')
            sys.exit(self._return_value)

    @abstractmethod
    async def _cleanup(self) -> None:
        raise NotImplementedError()

    async def shutdown(self, reason: str) -> None:
        if self._is_shutting_down:
            return  # Prevent running the function again if multiple signals are sent
        self._is_shutting_down = True
        await self._ready_event.wait()  # Wait for startup to complete
        self._logger.info('The service is shutting down', reason=reason)

        await self._cleanup()

        pending_tasks: set[Task[T]] = all_tasks()
        if pending_tasks:
            self._logger.debug('Cancelling all pending tasks')
            for task in pending_tasks:
                await end_task(task)

        # Stop event loop, thus closing the application
        self._loop.stop()


class NetService(SystemService[NetServiceConfig]):
    def __init__(self, config: NetServiceConfig, name: str) -> None:
        super().__init__(config, name)
        self._routes: Sequence[HttpRoute] = ()  # HTTP server routes
        self._web_app_runner: web.AppRunner | None = None  # Web app runner
        self._tcp_server: AbstractServer | None = None  # TCP server
        self._pre_hook: _HttpPreHook | None = None  # Hook called before handling HTTP request
        self._post_hook: _HttpPostHook | None = None  # Hook called after handling HTTP request
        self._request_counter = 0  # HTTP request counter (for logging)
        self._message_delimiter: str = '\n\n'  # Outbound TCP message delimiter
        self._data_events: dict[str, Event] = {}  # TCP client data received events
        self._reply_events: dict[str, Event] = {}  # TCP client reply received events
        self._client_queues: dict[str, Queue[JsonDict]] = {}  # TCP client outbound queues
        self._expected_replies: dict[str, str] = {}  # TCP client expected reply cache
        self._last_messages: dict[str, JsonDict] = {}  # TCP client last message cache
        self._receiving_clients: dict[str, HttpClient] = {}  # Receiving HTTP clients
        self._tcp_clients: set[str] = set()  # Active TCP clients
        self._mime_detector: magic.Magic = magic.Magic(
            mime=True
        )  # Mime detector for HTTP file response
        self._loggers_client: dict[str, StructuredLogger] = {}  # Client trace loggers
        self._create_loggers(config.clients)

    def _create_loggers(self, clients: dict[str, ClientConfig]) -> None:
        if self._logger.isEnabledFor(TRACE):
            log_dir: str = self._config.net_server_config.log_dir
            for clnt, clnt_conf in clients.items():
                if clnt_conf.comm_log:
                    logger_name: str = 'comm_' + clnt
                    self._loggers_client[clnt] = StructuredLogger(
                        logger_name=logger_name,
                        level=TRACE,
                        handler=RotatingFileHandler(
                            filename=os.path.join(log_dir, logger_name),
                            maxBytes=clnt_conf.log_max_bytes,
                            backupCount=clnt_conf.log_backup_count,
                            encoding='utf-8',
                        ),
                        include_timestamp=False,
                        include_level=False,
                    )

    async def _start(self) -> None:
        for client, client_conf in self._config.clients.items():
            await self._setup_client(client, client_conf)
        await self._start_web_app()
        await self._start_tcp_server()

    async def _start_web_app(self) -> None:
        self._logger.debug('Setting up web server')
        web_app: web.Application
        if not self._web_app_runner:
            web_app = web.Application()
            # Each is a tuple with method, path and coroutine function
            for http_method, path, handler in self._routes:
                web_app.router.add_route(
                    http_method, path, partial(self._handle_client_request, handler)
                )
            self._web_app_runner = web.AppRunner(web_app)
        await self._web_app_runner.setup()

        bind_addr: str = self._config.net_server_config.http_bind_address
        if bind_addr:
            bind_port: int = self._config.net_server_config.http_bind_port
            self._logger.debug('Starting HTTP site', address=bind_addr, port=bind_port)
            http_site: web.TCPSite = web.TCPSite(self._web_app_runner, bind_addr, bind_port)
            await http_site.start()
        bind_addr = self._config.net_server_config.https_bind_address
        if bind_addr:
            bind_port: int = self._config.net_server_config.https_bind_port
            self._logger.debug('Starting HTTPS site', address=bind_addr, port=bind_port)
            cert_file: str = self._config.net_server_config.secure_cert_file
            key_file: str = self._config.net_server_config.secure_key_file
            ssl_context: ssl.SSLContext = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            ssl_context.load_cert_chain(cert_file, key_file)
            ssl_context.minimum_version = self._config.net_server_config.min_tls_version
            https_site: web.TCPSite = web.TCPSite(
                self._web_app_runner, bind_addr, bind_port, ssl_context=ssl_context
            )
            await https_site.start()

    async def _stop_web_app(self) -> None:
        if self._web_app_runner:
            self._logger.debug('Stopping web server')
            try:
                await self._web_app_runner.cleanup()
            except Exception as err:  # pylint: disable=broad-except
                self._logger.warning('Unexpected error while stopping web server', exc_info=err)
            self._logger.debug('Web server stopped')

    async def _start_tcp_server(self) -> None:
        bind_addr: str = self._config.net_server_config.tcp_bind_address
        if not bind_addr:
            return
        bind_port: int = self._config.net_server_config.tcp_bind_port
        self._logger.debug('Starting TCP server', address=bind_addr, port=bind_port)
        server: AbstractServer = await start_server(self._handle_tcp_client, bind_addr, bind_port)
        run_task(server.serve_forever(), 'TCP server')

    async def _stop_tcp_server(self) -> None:
        await end_task('TCP server')

        # Stop client connections
        for client in self._tcp_clients:
            await end_task(f'{client} Connection monitor')
            await end_task(f'{client} TCP receiver')
            await end_task(f'{client} TCP sender')

    # Monitors TCP client connection, and exits if no data was received within predefied timeout
    async def _conn_monitor(self, client: str) -> None:
        self._logger.debug('Starting TCP client connection monitor', client=client)
        client_conf: ClientConfig = self._config.clients[client]
        data_event: Event = self._data_events[client]
        sleep_task: Task[None] | None = None
        event_task: Task[bool] | None = None
        try:
            while True:
                # Wait for interval to expire or data event to be triggered, whichever comes first
                # clients's receiver will trigger the event after data is received
                sleep_task = create_task(sleep(client_conf.idle_timeout))
                event_task = create_task(data_event.wait())
                done, _pending = await wait({sleep_task, event_task}, return_when=FIRST_COMPLETED)
                if sleep_task in done:
                    # Interval expired, break connection
                    await sleep_task
                    self._logger.info(
                        'Closing TCP client connection due to inactivity',
                        client=client,
                        timeout=client_conf.idle_timeout,
                    )
                    raise CancelledError

                # Data was received, cancel sleep task and start over
                await end_task(sleep_task)
                await event_task

                data_event.clear()
        except CancelledError:
            if sleep_task:
                await end_task(sleep_task)
            if event_task:
                await end_task(event_task)
            raise

    async def _setup_client(self, client: str, client_conf: ClientConfig) -> None:
        if client_conf.type == ClientType.TCP:
            self._client_queues[client] = Queue()
            self._last_messages[client] = {}
        elif client_conf.host:
            http_client: HttpClient = HttpClient(
                name=client,
                config=client_conf,
                queue=Queue(),
                logger=self._logger,
                retry_timer=SimpleExponentialBackoff(),
                init=self._client_init,
            )
            self._receiving_clients[client] = http_client
            run_task(http_client.start())

    async def _client_init(self, http_client: HttpClient) -> None:
        # pylint: disable=unused-argument
        # Override in subclass
        return

    async def _find_tcp_client(
        self, user: str, pswd: str, client_ip: IPv4Address
    ) -> tuple[str, ClientConfig | None]:
        client: str = ''
        client_conf: ClientConfig | None = None
        for clnt, clnt_conf in self._config.clients.items():
            if clnt_conf.type == ClientType.TCP:
                if clnt_conf.server_user == user and clnt_conf.server_pswd == pswd:
                    if not clnt_conf.allowed_ips or any(
                        client_ip in allowed_net for allowed_net in clnt_conf.allowed_ips
                    ):
                        client, client_conf = clnt, clnt_conf
                        break
                    self._logger.warning(
                        'Client passed authentication from disallowed IP.',
                        peer=str(client_ip),
                        client=clnt,
                    )
                    return '', None
        if not client:
            self._logger.warning('Client failed authentication.', peer=str(client_ip))
        elif client in self._data_events:
            # We set client, but not client_conf.
            # This informs the calling function that the client is already connected.
            client_conf = None
            self._logger.warning('Client already connected.', peer=str(client_ip), client=client)
        return client, client_conf

    async def _auth_tcp_client(
        self, reader: StreamReader, writer: StreamWriter, client_ip: IPv4Address
    ) -> tuple[str, ClientConfig | None]:
        # pylint: disable=unused-argument
        # Override in subclass
        return '', None

    async def _handle_tcp_client(self, reader: StreamReader, writer: StreamWriter) -> None:
        client: str = ''
        client_conf: ClientConfig | None = None
        peer = writer.get_extra_info('peername')
        self._logger.debug('TCP connection initiated', peer=peer)
        try:
            client_ip: IPv4Address = IPv4Address(peer[0])
            client, client_conf = await self._auth_tcp_client(reader, writer, client_ip)
            if not client_conf:
                return
            self._logger.info('Authenticated successfully', client=client)
            self._data_events[client] = Event()
            self._reply_events[client] = Event()
            self._expected_replies[client] = ''
            self._tcp_clients.add(client)
            # Wait until any task fails
            done, pending = await wait(
                {
                    run_task(self._tcp_sender(client, writer), f'{client} TCP sender'),
                    run_task(self._tcp_receiver(client, reader, writer), f'{client} TCP receiver'),
                    run_task(self._conn_monitor(client), f'{client} Connection monitor'),
                },
                return_when=FIRST_COMPLETED,
            )
            self._tcp_clients.remove(client)
            for task in done:
                await task
            for task in pending:
                await end_task(task)
        except ConnectionError:
            self._logger.error('TCP connection lost', peer=peer)
        except TimeoutError:
            self._logger.error('TCP connection timed out', peer=peer)
        except IncompleteReadError:
            self._logger.error('Incomplete read error', peer=peer)
        except OSError:
            self._logger.exception('TCP network error', peer=peer)
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Unexpected TCP client communication error', peer=peer)
        except CancelledError:
            if client:
                await end_task(f'{client} TCP receiver')
                await end_task(f'{client} TCP sender')
                await end_task(f'{client} Connection monitor')
                self._logger.debug('TCP connection handler cancelled', peer=peer, client=client)
            raise
        finally:
            if client:
                del self._data_events[client]
                del self._reply_events[client]
                del self._expected_replies[client]
                # _last_messages need to be preserved between reconnects
            if not writer.is_closing():
                writer.close()

    async def _tcp_receiver(self, client: str, reader: StreamReader, writer: StreamWriter) -> None:
        # Override in subclass
        pass

    async def _tcp_sender(self, client: str, writer: StreamWriter) -> None:
        # Override in subclass
        pass

    async def _sock_read(
        self,
        client: str,
        reader: StreamReader,
        timeout: int = 0,
        delimiter: bytes = b'\n',
        encoding: str = '',
    ) -> str | None:
        if timeout:
            data: bytes = await socket_operation(reader.readuntil(delimiter), timeout)
        else:
            data: bytes = await reader.readuntil(delimiter)
        if client:
            self._data_events[client].set()
            if not encoding:
                encoding = self._config.clients[client].encoding
        if not encoding:
            encoding = 'utf-8'  # Default
        client_logger: StructuredLogger | None = self._loggers_client.get(client)
        try:
            message: str = data.decode(encoding)
        except Exception:  # pylint: disable=broad-except
            if client_logger:
                client_logger.exception('Could not decode client message', message=data)
            return None
        if client_logger:
            client_logger.trace('RCVD', message=message)
        return message.rstrip()

    async def _sock_write(
        self, client: str, writer: StreamWriter, message: str, encoding: str = ''
    ) -> None:
        message += self._message_delimiter
        if client:
            if not encoding:
                encoding = self._config.clients[client].encoding
        if not encoding:
            encoding = 'utf-8'  # Default
        client_logger: StructuredLogger | None = self._loggers_client.get(client)
        if client_logger:
            client_logger.trace('SENT', message=message)
        writer.write(message.encode(encoding))
        await socket_operation(writer.drain())

    @staticmethod
    def _get_api_key(request: web.Request) -> str:
        key_name: str = 'X-API-KEY'
        key_headers: list[str] | None = request.headers.getall(key_name, None)
        if key_headers:
            if len(key_headers) > 1 or ' ' in key_headers[0]:
                raise ArgumentError(f'{key_name} header specified more than once')
            return key_headers[0]
        key_cookie: str | None = request.cookies.get(key_name)
        if key_cookie:
            return key_cookie
        key_params: list[str] | None = request.query.getall('apiKey', None)
        if key_params:
            if len(key_params) > 1:
                raise ArgumentError('API key query parameter specified more than once')
            return key_params[0]
        return ''

    @staticmethod
    def _http_authenticate(request: web.Request) -> tuple[str, str]:
        auth_header: str | None = request.headers.get(hdrs.AUTHORIZATION)
        if not auth_header:
            return '', ''
        try:
            auth: BasicAuth = BasicAuth.decode(auth_header=auth_header)
            return auth.login, auth.password
        except ValueError:
            return '', ''

    @staticmethod
    def _http_challenge(realm: str = '') -> web.Response:
        return web.Response(
            body=b'',
            status=401,
            reason='UNAUTHORIZED',
            headers={
                hdrs.WWW_AUTHENTICATE: f'Basic realm="{realm}"',
                hdrs.CONTENT_TYPE: 'text/html; charset=utf-8',
                hdrs.CONNECTION: 'keep-alive',
            },
        )

    async def _http_response(self, coroutine: Awaitable[JsonValue]) -> web.StreamResponse:
        """
        Executes a coroutine and returns appropriate HTTP response.
        The coroutine should raise an appropriate exception in case of an error.
        """
        try:
            result: JsonValue = await coroutine
        except ArgumentError as err:
            return web.Response(status=400, text=str(err))
        except AuthorizationError as err:
            return web.Response(status=401, text=str(err))
        except ResourceError as err:
            return web.Response(status=404, text=str(err))
        except DataIntegrityError as err:
            return web.Response(status=409, text=str(err))
        except InternalError as err:
            return web.Response(status=500, text=str(err))
        except PostgresError as err:
            # TODO self._db.ready.clear()
            return web.Response(status=500, text=str(err))
        except ValueError as err:
            self._logger.exception('Unexpected ValueError')
            return web.Response(status=400, text=str(err))
        except Exception as err:  # pylint: disable=broad-except
            self._logger.exception('Unexpected Exception')
            return web.Response(status=500, text=str(err))

        if result is None:
            return web.Response()
        if isinstance(result, web.StreamResponse):
            return result
        if isinstance(result, Path):
            response: web.FileResponse = web.FileResponse(result)
            response.content_type = self._mime_detector.from_file(str(result))
            return response
        return web.json_response(body=orjson.dumps(result))

    async def _handle_client_request(
        self, handler: HttpHandler | None, request: web.Request
    ) -> web.StreamResponse:
        seq: int = self._request_counter
        self._request_counter += 1

        async def respond(client: str, resp: web.StreamResponse) -> web.StreamResponse:
            if self._post_hook is not None:
                await self._post_hook(request, resp)
            self._logger.trace('Responding to HTTP request', seq=seq, status=resp.status)
            client_logger: StructuredLogger | None = self._loggers_client.get(client)
            if client_logger:
                if isinstance(resp, web.Response):
                    if resp.content_type == 'application/json':
                        assert isinstance(resp.body, bytes)  # For type checkers
                        json_result: JsonValue = orjson.loads(resp.body)
                        client_logger.trace(
                            'Responding with JSON',
                            seq=seq,
                            client=client,
                            status=resp.status,
                            message=json_result,
                        )
                    else:
                        text: str = resp.text or ''
                        client_logger.trace(
                            'Responding with text',
                            seq=seq,
                            client=client,
                            status=resp.status,
                            message=text,
                        )
                elif isinstance(resp, web.FileResponse):
                    # pylint: disable=protected-access; don't even know why is this protected
                    client_logger.trace(
                        'Responding with file',
                        seq=seq,
                        client=client,
                        status=resp.status,
                        path=resp._path,
                        content_type=resp.content_type,
                    )
            return resp

        rel_url: str = request.rel_url.human_repr()
        clients: dict[str, ClientConfig] = self._config.clients
        client: str = ''
        client_conf: ClientConfig | None = None
        response: web.StreamResponse | None
        ip_str: str | None = request.headers.get('X-Real-IP') or request.remote
        self._logger.trace(
            'Received HTTP request', seq=seq, method=request.method, url=rel_url, ip=ip_str
        )
        try:
            # Try to identify client by IP
            try:
                if not ip_str:
                    raise ValueError()
                remote_ip = ip_address(ip_str)
            except ValueError:
                response = web.Response(status=500, text='Could not detect client IP address')
                return await respond('', response)
            client, client_conf = next(
                (
                    (clnt, clnt_conf)
                    for clnt, clnt_conf in clients.items()
                    for allowed_net in clnt_conf.allowed_ips
                    if remote_ip in allowed_net
                ),
                ('', None),
            )

            api_key: str = self._get_api_key(request)
            if client_conf and client_conf.api_key != api_key:
                self._logger.info(
                    'Client identified by IP sent wrong API key',
                    seq=seq,
                    method=request.method,
                    url=rel_url,
                    ip=ip_str,
                )
                response = web.Response(status=401)
                return await respond(client, response)
            if api_key:
                if request.scheme != 'https':
                    if request.headers.get(hdrs.X_FORWARDED_PROTO) != 'https':
                        self._logger.info(
                            'Client tried to identify with API key over insecure connection',
                            seq=seq,
                            method=request.method,
                            url=rel_url,
                            ip=ip_str,
                        )
                        raise ArgumentError('API key authentication requires secure connection')
                client, client_conf = next(
                    (
                        (clnt, clnt_def)
                        for clnt, clnt_def in clients.items()
                        if clnt_def.api_key == api_key
                    ),
                    ('', None),
                )

            possible_clients: dict[str, ClientConfig] = {}
            if client_conf:
                if client_conf.server_user:
                    # Found client by IP and/or API key, but authentication is still required
                    possible_clients = {client: client_conf}
                    client = ''
            else:
                possible_clients = {
                    clnt: clnt_def for clnt, clnt_def in clients.items() if clnt_def.server_user
                }

            if not client_conf:
                self._logger.trace('Performing basic authentication', seq=seq)
                username, password = self._http_authenticate(request)
                client, client_conf = next(
                    (
                        (clnt, clnt_conf)
                        for clnt, clnt_conf in possible_clients.items()
                        if clnt_conf.server_user == username and clnt_conf.server_pswd == password
                    ),
                    ('', None),
                )
                if not client_conf:
                    self._logger.warning(
                        'Authentication failed',
                        seq=seq,
                        remote_ip=str(remote_ip),
                        method=request.method,
                        url=rel_url,
                    )
                    response = self._http_challenge()
                    return await respond(client, response)
            if client_conf:
                if client_conf.api_key != api_key:
                    self._logger.info(
                        'Client identified by basic auth sent wrong API key',
                        seq=seq,
                        method=request.method,
                        url=rel_url,
                        ip=ip_str,
                    )
                    response = web.Response(status=401)
                    return await respond(client, response)
                if any(pattern.match(rel_url) for pattern in client_conf.path_deny):
                    self._logger.info(
                        'HTTP path explicitly denied',
                        seq=seq,
                        method=request.method,
                        url=rel_url,
                        ip=ip_str,
                        client=client,
                    )
                    response = web.Response(status=401)
                    return await respond(client, response)
                if not any(pattern.match(rel_url) for pattern in client_conf.path_allow):
                    self._logger.info(
                        'HTTP path not allowed',
                        seq=seq,
                        method=request.method,
                        url=rel_url,
                        ip=ip_str,
                        client=client,
                    )
                    response = web.Response(status=401)
                    return await respond(client, response)
                client_logger: StructuredLogger | None = self._loggers_client.get(client)
                if client_logger:
                    payload: str
                    if request.body_exists:
                        payload = (await request.read()).decode('utf-8')
                    else:
                        payload = ''
                    client_logger.trace(
                        'Request accepted',
                        seq=seq,
                        remote_ip=str(remote_ip),
                        method=request.method,
                        url=rel_url,
                        payload=payload,
                    )
                request['client'] = client
                if self._pre_hook is not None:
                    response = await self._pre_hook(request)
                    if response:
                        return await respond(client, response)
                if not handler:
                    response = web.Response()
                else:
                    response = await self._http_response(handler(request))
                return await respond(client, response)
        except ArgumentError as err:
            response = web.Response(status=400, text=str(err))
            return await respond(client, response)
        raise InternalError('Request processing error')
