import asyncio
import os
from typing import Any
from unittest.mock import MagicMock

import pytest

from postgres_driver import PostgresDriver


class DummyRetryTimer:
    """A no-op retry timer that always reports 0 delay and waits instantly."""
    def reset(self) -> None:
        pass

    def next_delay(self) -> float:
        return 0.0

    async def wait(self) -> None:
        pass  # instantaneous, no sleep needed


@pytest.fixture
def mock_logger() -> MagicMock:
    logger = MagicMock()
    # By default disable trace logging to avoid noise in mock calls
    logger.isEnabledFor.return_value = False
    return logger


@pytest.fixture
def dummy_retry_timer() -> DummyRetryTimer:
    return DummyRetryTimer()


@pytest.fixture
async def driver(mock_logger: MagicMock, dummy_retry_timer: DummyRetryTimer) -> PostgresDriver:
    dsn = os.getenv("TEST_POSTGRES_DSN")
    if not dsn:
        pytest.skip("TEST_POSTGRES_DSN environment variable not set (example: postgresql://postgres:password@localhost:5432/postgres)")

    driver = PostgresDriver(
        dsn=dsn,
        retry_timer=dummy_retry_timer,
        logger=mock_logger,
        pool_min_size=1,      # sensible values for tests
        pool_max_size=10,
        timeout=10.0,
        command_timeout=60.0,
    )

    await driver.start()

    # Create a fresh test table for this test
    await driver.exec(
        """
        DROP TABLE IF EXISTS test_table;
        CREATE TABLE test_table (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            value INTEGER NOT NULL
        );
        """
    )

    yield driver

    # Cleanup: drop the table and shut down
    await driver.exec("DROP TABLE IF EXISTS test_table")
    await driver.stop()


@pytest.mark.asyncio
async def test_basic_exec_and_select(driver: PostgresDriver) -> None:
    # Insert data with plain positional query
    await driver.exec(
        """
        INSERT INTO test_table (name, value)
        VALUES ('alice', 100), ('bob', 200), ('charlie', 300)
        """
    )
    assert driver.rowcount == 3

    rows = await driver.select("SELECT id, name, value FROM test_table ORDER BY id")
    assert driver.rowcount == 3
    assert len(rows) == 3
    assert rows == [
        (1, "alice", 100),
        (2, "bob", 200),
        (3, "charlie", 300),
    ]


@pytest.mark.asyncio
async def test_named_parameters(driver: PostgresDriver) -> None:
    await driver.exec(
        "INSERT INTO test_table (name, value) VALUES (:name, :value)",
        {"name": "dave", "value": 400},
    )
    assert driver.rowcount == 1

    rows = await driver.select(
        "SELECT id, name, value FROM test_table WHERE name = :name",
        {"name": "dave"},
    )
    assert len(rows) == 1
    assert rows[0] == (1, "dave", 400)  # first inserted in this test


@pytest.mark.asyncio
async def test_select_dict(driver: PostgresDriver) -> None:
    await driver.exec(
        "INSERT INTO test_table (name, value) VALUES (:n1, :v1), (:n2, :v2)",
        {"n1": "emma", "v1": 500, "n2": "frank", "v2": 600},
    )

    rows = await driver.select_dict("SELECT * FROM test_table ORDER BY id")
    assert len(rows) == 2
    assert rows[0]["name"] == "emma"
    assert rows[0]["value"] == 500
    assert rows[1]["name"] == "frank"


@pytest.mark.asyncio
async def test_scalar_and_scalarlist(driver: PostgresDriver) -> None:
    await driver.exec(
        """
        INSERT INTO test_table (name, value)
        VALUES ('one', 1), ('two', 2), ('three', 3)
        """
    )

    count = await driver.scalar("SELECT COUNT(*) FROM test_table")
    assert count == 3
    assert driver.rowcount == 1  # scalar sets rowcount to 1 if value, else 0

    names = await driver.scalarlist("SELECT name FROM test_table ORDER BY id")
    assert names == ("one", "two", "three")

    single_row = await driver.scalarlist("SELECT name, value FROM test_table WHERE name = 'two'")
    assert single_row == ("two", 2)


@pytest.mark.asyncio
async def test_rowcount(driver: PostgresDriver) -> None:
    await driver.exec(
        "INSERT INTO test_table (name, value) VALUES ('test', 999)"
    )
    assert driver.rowcount == 1

    await driver.exec("UPDATE test_table SET value = 1000 WHERE name = 'test'")
    assert driver.rowcount == 1

    await driver.exec("DELETE FROM test_table WHERE name = 'test'")
    assert driver.rowcount == 1


@pytest.mark.asyncio
async def test_streaming_yield(driver: PostgresDriver) -> None:
    # Insert a few rows
    await driver.exec(
        """
        INSERT INTO test_table (name, value)
        VALUES ('a', 1), ('b', 2), ('c', 3)
        """
    )

    # Test yield_dict
    collected_dicts: list[dict[str, Any]] = []
    async for row in driver.yield_dict("SELECT * FROM test_table ORDER BY id"):
        collected_dicts.append(row)
    assert len(collected_dicts) == 3
    assert collected_dicts[0] == {"id": 1, "name": "a", "value": 1}

    # Test yield_tuple
    collected_tuples: list[tuple[Any, ...]] = []
    async for row in driver.yield_tuple("SELECT * FROM test_table ORDER BY id"):
        collected_tuples.append(row)
    assert len(collected_tuples) == 3
    assert collected_tuples[0] == (1, "a", 1)


@pytest.mark.asyncio
async def test_transaction_commit_and_rollback(driver: PostgresDriver) -> None:
    # Successful transaction (auto-commit)
    async with driver.transaction() as conn:
        await conn.execute(
            "INSERT INTO test_table (name, value) VALUES ('committed', 123)"
        )

    rows = await driver.select("SELECT value FROM test_table WHERE name = 'committed'")
    assert len(rows) == 1
    assert rows[0][0] == 123

    # Failed transaction (auto-rollback)
    with pytest.raises(RuntimeError):
        async with driver.transaction() as conn:
            await conn.execute(
                "INSERT INTO test_table (name, value) VALUES ('rolledback', 999)"
            )
            raise RuntimeError("force rollback")

    rows = await driver.select("SELECT value FROM test_table WHERE name = 'rolledback'")
    assert len(rows) == 0


@pytest.mark.asyncio
async def test_listen_notify(driver: PostgresDriver) -> None:
    received: list[str] = []

    async def callback(_conn: Any, _pid: int, _channel: str, payload: str) -> None:
        received.append(payload)

    await driver.add_listener("test_channel", callback)

    await driver.notify("test_channel", "hello_world")

    # Give the notification a moment to arrive
    for _ in range(10):
        if received:
            break
        await asyncio.sleep(0.05)

    assert received == ["hello_world"]

    await driver.remove_listener("test_channel", callback)
    