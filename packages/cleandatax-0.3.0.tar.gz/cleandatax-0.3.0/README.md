# **cleandatax

**cleandatax** is a professional Python package for **data cleaning, validation, and profiling**
built on top of **pandas**.  
It helps Data Science users clean messy datasets using a simple and configurable pipeline.


---

## **  Installation

```bash
pip install cleandatax