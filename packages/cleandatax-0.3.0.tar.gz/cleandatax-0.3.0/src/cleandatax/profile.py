from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict
import pandas as pd


@dataclass
class Profile:
    rows: int
    cols: int
    missing_cells: int
    duplicate_rows: int
    quality_score: int
    column_summary: Dict[str, Dict[str, Any]]


def profile_dataframe(df: pd.DataFrame) -> Profile:
    rows, cols = df.shape
    missing = int(df.isna().sum().sum())
    dups = int(df.duplicated().sum())

    # Simple scoring (0–100) — you can refine later
    missing_ratio = missing / max(rows * cols, 1)
    dup_ratio = dups / max(rows, 1)
    score = 100 - int(60 * missing_ratio * 100) - int(40 * dup_ratio * 100)
    score = max(0, min(100, score))

    summary: Dict[str, Dict[str, Any]] = {}
    for c in df.columns:
        s = df[c]
        info: Dict[str, Any] = {"dtype": str(s.dtype), "missing": int(s.isna().sum())}
        if pd.api.types.is_numeric_dtype(s):
            info.update(
                {
                    "min": float(s.min()) if s.notna().any() else None,
                    "max": float(s.max()) if s.notna().any() else None,
                    "mean": float(s.mean()) if s.notna().any() else None,
                }
            )
        else:
            vc = s.astype("string").value_counts(dropna=True).head(5)
            info["top_values"] = vc.to_dict()
        summary[c] = info

    return Profile(rows=rows, cols=cols, missing_cells=missing, duplicate_rows=dups, quality_score=score, column_summary=summary)