from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
import re
import numpy as np
import pandas as pd


def standardize_columns(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    before = list(df.columns)

    def snake(s: str) -> str:
        s = s.strip()
        s = re.sub(r"[^\w\s]", "", s)
        s = re.sub(r"\s+", "_", s)
        s = re.sub(r"_+", "_", s)
        return s.lower()

    df = df.copy()
    df.columns = [snake(str(c)) for c in df.columns]
    after = list(df.columns)
    changes = {b: a for b, a in zip(before, after) if b != a}
    return df, {"changed": changes, "count": len(changes)}


def trim_strings(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    df = df.copy()
    cols = df.select_dtypes(include=["object", "string"]).columns
    changed = 0
    for c in cols:
        before = df[c]
        df[c] = df[c].astype("string").str.strip().str.replace(r"\s+", " ", regex=True)
        changed += int((before.astype("string") != df[c]).sum())
    return df, {"columns": list(cols), "cells_changed": changed}


def coerce_numeric(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    df = df.copy()
    conversions = {}
    obj_cols = df.select_dtypes(include=["object", "string"]).columns
    for c in obj_cols:
        conv = pd.to_numeric(df[c], errors="coerce")
        # convert only if it actually helps (many non-NaNs)
        non_na = int(conv.notna().sum())
        if non_na > 0 and non_na >= 0.8 * len(df):  # pro heuristic
            conversions[c] = {"non_na_ratio": non_na / max(len(df), 1)}
            df[c] = conv
    return df, {"converted": conversions, "count": len(conversions)}


def coerce_dates(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    df = df.copy()
    conversions = {}
    obj_cols = df.select_dtypes(include=["object", "string"]).columns
    for c in obj_cols:
        conv = pd.to_datetime(df[c], errors="coerce", infer_datetime_format=True)
        non_na = int(conv.notna().sum())
        if non_na > 0 and non_na >= 0.8 * len(df):
            conversions[c] = {"non_na_ratio": non_na / max(len(df), 1)}
            df[c] = conv
    return df, {"converted": conversions, "count": len(conversions)}


def handle_missing(df: pd.DataFrame, strategy: str = "smart") -> Tuple[pd.DataFrame, Dict[str, Any]]:
    df = df.copy()
    missing_before = int(df.isna().sum().sum())

    if strategy == "drop_rows":
        df = df.dropna()
    elif strategy == "drop_cols":
        df = df.dropna(axis=1)
    else:  # smart
        for c in df.columns:
            if not df[c].isna().any():
                continue
            if pd.api.types.is_numeric_dtype(df[c]):
                df[c] = df[c].fillna(df[c].median())
            else:
                mode = df[c].mode(dropna=True)
                fill = mode.iloc[0] if len(mode) else "Unknown"
                df[c] = df[c].fillna(fill)

    missing_after = int(df.isna().sum().sum())
    return df, {"strategy": strategy, "missing_before": missing_before, "missing_after": missing_after}


def deduplicate(df: pd.DataFrame, subset: Optional[List[str]] = None) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    before = len(df)
    out = df.drop_duplicates(subset=subset)
    return out, {"rows_removed": before - len(out), "subset": subset}


def handle_outliers(
    df: pd.DataFrame,
    method: str = "iqr",
    action: str = "flag",
    cols: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    df = df.copy()
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    target = cols or numeric_cols
    flagged_total = 0

    for c in target:
        if c not in df.columns or not pd.api.types.is_numeric_dtype(df[c]):
            continue
        s = df[c].dropna()
        if len(s) < 10:
            continue

        if method == "zscore":
            z = (df[c] - df[c].mean()) / (df[c].std(ddof=0) + 1e-12)
            mask = z.abs() > 3
        else:  # iqr
            q1, q3 = s.quantile(0.25), s.quantile(0.75)
            iqr = q3 - q1
            lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            mask = (df[c] < lo) | (df[c] > hi)

        flagged = int(mask.sum())
        flagged_total += flagged

        if action == "drop":
            df = df.loc[~mask].copy()
        elif action == "cap":
            if method == "zscore":
                # cap using percentiles
                lo, hi = s.quantile(0.01), s.quantile(0.99)
            df.loc[df[c] < lo, c] = lo
            df.loc[df[c] > hi, c] = hi
        else:  # flag
            df[f"{c}__outlier"] = mask

    return df, {"method": method, "action": action, "flagged_total": flagged_total, "cols": target}