from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional
import pandas as pd

from .validate import ValidationResult
from .profile import Profile


@dataclass
class CleanReport:
    started_rows: int
    started_cols: int
    events: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    validation: Optional[ValidationResult] = None
    profile: Optional[Profile] = None
    finished_rows: Optional[int] = None
    finished_cols: Optional[int] = None

    @staticmethod
    def start(df: pd.DataFrame) -> "CleanReport":
        return CleanReport(started_rows=len(df), started_cols=df.shape[1])

    def add_event(self, name: str, payload: Dict[str, Any]) -> None:
        self.events[name] = payload

    def finish(self, df: pd.DataFrame) -> None:
        self.finished_rows = len(df)
        self.finished_cols = df.shape[1]

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    def to_json(self, path: str) -> None:
        import json
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    def to_html(self, path: str) -> None:
        # optional dependency
        from jinja2 import Template

        tpl = Template("""
        <html><head><meta charset="utf-8"><title>cleandatax report</title></head>
        <body style="font-family: Arial">
          <h1>Clean Report</h1>
          <p><b>Rows:</b> {{ r.started_rows }} → {{ r.finished_rows }}</p>
          <p><b>Cols:</b> {{ r.started_cols }} → {{ r.finished_cols }}</p>

          <h2>Events</h2>
          <pre>{{ r.events }}</pre>

          {% if r.profile %}
            <h2>Profile</h2>
            <p><b>Quality score:</b> {{ r.profile.quality_score }}/100</p>
          {% endif %}

          {% if r.validation %}
            <h2>Validation</h2>
            <p><b>OK:</b> {{ r.validation.ok }}</p>
            <pre>{{ r.validation.errors }}</pre>
          {% endif %}
        </body></html>
        """)
        html = tpl.render(r=self)
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)