from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Pattern, Union
import re
import pandas as pd


@dataclass
class ValidationError:
    rule: str
    column: str
    count: int
    sample_indices: List[int]


@dataclass
class ValidationResult:
    ok: bool
    errors: List[ValidationError]


@dataclass
class ValidationRule:
    column: str
    rule: str  # "range" | "regex" | "in" | "non_null" | "unique"
    min: Optional[float] = None
    max: Optional[float] = None
    pattern: Optional[str] = None
    allowed: Optional[List[Any]] = None


def validate_dataframe(df: pd.DataFrame, rules: List[ValidationRule]) -> ValidationResult:
    errors: List[ValidationError] = []

    for r in rules:
        if r.column not in df.columns:
            errors.append(ValidationError(r.rule, r.column, count=len(df), sample_indices=[0]))
            continue

        s = df[r.column]
        mask = pd.Series([False] * len(df), index=df.index)

        if r.rule == "non_null":
            mask = s.isna()
        elif r.rule == "unique":
            mask = s.duplicated(keep=False)
        elif r.rule == "range":
            if r.min is not None:
                mask = mask | (s < r.min)
            if r.max is not None:
                mask = mask | (s > r.max)
        elif r.rule == "in":
            allowed = set(r.allowed or [])
            mask = ~s.isin(allowed)
        elif r.rule == "regex":
            pat = re.compile(r.pattern or "")
            mask = ~s.astype("string").fillna("").str.match(pat)

        bad = df.index[mask].tolist()
        if bad:
            errors.append(
                ValidationError(
                    rule=r.rule,
                    column=r.column,
                    count=len(bad),
                    sample_indices=bad[:10],
                )
            )

    return ValidationResult(ok=(len(errors) == 0), errors=errors)