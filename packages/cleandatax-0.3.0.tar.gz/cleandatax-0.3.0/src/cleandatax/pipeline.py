from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd

from .steps import (
    standardize_columns,
    trim_strings,
    coerce_numeric,
    coerce_dates,
    handle_missing,
    deduplicate,
    handle_outliers,
)
from .profile import profile_dataframe
from .validate import validate_dataframe, ValidationRule
from .report import CleanReport


@dataclass
class PipelineConfig:
    standardize_column_names: bool = True
    trim_string_columns: bool = True
    numeric_coercion: bool = True
    date_coercion: bool = True
    missing_strategy: str = "smart"  # smart | drop_rows | drop_cols
    deduplicate: bool = True
    dedup_subset: Optional[List[str]] = None

    outliers: bool = False
    outlier_method: str = "iqr"      # iqr | zscore
    outlier_action: str = "flag"     # flag | cap | drop
    outlier_cols: Optional[List[str]] = None

    profiling: bool = True


def run(
    df: pd.DataFrame,
    config: PipelineConfig | None = None,
    rules: Optional[List[ValidationRule]] = None,
) -> Tuple[pd.DataFrame, CleanReport]:
    cfg = config or PipelineConfig()
    report = CleanReport.start(df)

    out = df.copy()

    if cfg.standardize_column_names:
        out, ev = standardize_columns(out)
        report.add_event("standardize_columns", ev)

    if cfg.trim_string_columns:
        out, ev = trim_strings(out)
        report.add_event("trim_strings", ev)

    if cfg.numeric_coercion:
        out, ev = coerce_numeric(out)
        report.add_event("coerce_numeric", ev)

    if cfg.date_coercion:
        out, ev = coerce_dates(out)
        report.add_event("coerce_dates", ev)

    out, ev = handle_missing(out, strategy=cfg.missing_strategy)
    report.add_event("handle_missing", ev)

    if cfg.deduplicate:
        out, ev = deduplicate(out, subset=cfg.dedup_subset)
        report.add_event("deduplicate", ev)

    if cfg.outliers:
        out, ev = handle_outliers(
            out,
            method=cfg.outlier_method,
            action=cfg.outlier_action,
            cols=cfg.outlier_cols,
        )
        report.add_event("outliers", ev)

    if rules:
        vres = validate_dataframe(out, rules)
        report.validation = vres

    if cfg.profiling:
        report.profile = profile_dataframe(out)

    report.finish(out)
    return out, report