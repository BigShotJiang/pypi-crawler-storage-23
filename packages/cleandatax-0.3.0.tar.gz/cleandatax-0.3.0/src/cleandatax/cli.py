from __future__ import annotations
import argparse
import pandas as pd

from .pipeline import run, PipelineConfig


def main() -> None:
    p = argparse.ArgumentParser(prog="cleandatax", description="Clean + profile pandas datasets.")
    sub = p.add_subparsers(dest="cmd", required=True)

    clean_p = sub.add_parser("clean", help="Clean a CSV file")
    clean_p.add_argument("input", help="Input CSV path")
    clean_p.add_argument("-o", "--output", required=True, help="Output CSV path")
    clean_p.add_argument("--report", help="Report output (json or html). Example: report.json / report.html")
    clean_p.add_argument("--outliers", action="store_true", help="Enable outlier handling")
    clean_p.add_argument("--outlier-action", default="flag", choices=["flag", "cap", "drop"])

    profile_p = sub.add_parser("profile", help="Profile a CSV file")
    profile_p.add_argument("input", help="Input CSV path")
    profile_p.add_argument("--json", required=True, help="Output JSON report path")

    args = p.parse_args()

    if args.cmd == "clean":
        df = pd.read_csv(args.input)
        cfg = PipelineConfig(outliers=args.outliers, outlier_action=args.outlier_action)
        out, rep = run(df, cfg)
        out.to_csv(args.output, index=False)

        if args.report:
            if args.report.lower().endswith(".json"):
                rep.to_json(args.report)
            elif args.report.lower().endswith(".html"):
                rep.to_html(args.report)
            else:
                raise SystemExit("Report must end with .json or .html")

    elif args.cmd == "profile":
        df = pd.read_csv(args.input)
        out, rep = run(df, PipelineConfig(profiling=True))
        rep.to_json(args.json)