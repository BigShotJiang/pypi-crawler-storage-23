"""Tests for the Qualidoo CLI."""
