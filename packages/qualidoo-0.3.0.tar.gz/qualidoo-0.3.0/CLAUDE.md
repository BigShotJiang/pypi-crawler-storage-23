# CLAUDE.md

## Git Conventions

- Do not add `Co-Authored-By` or any signature lines to commits
