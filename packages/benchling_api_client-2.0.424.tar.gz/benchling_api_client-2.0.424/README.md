# benchling-api-client
A client generated from Benchling's OpenAPI definition files using openapi-python-client.

Rather than using this package directly, we recommend using the
[Benchling SDK](https://pypi.org/project/benchling-sdk/), which has extra scaffolding to make some endpoints
easier to use and has been released to general availability.
