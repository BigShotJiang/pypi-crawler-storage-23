# This file was generated automatically. Do not edit it directly.
from typing import (
    Any,
    Dict,
    List,
    Literal,
    NotRequired,
    Optional,
    TypedDict,
    Unpack,
    cast,
)
from urllib.parse import quote

from fountain_life_service_clients._base_client import (
    AlphaConfig,
    AlphaResponse,
    BaseClient,
)


class InvokeBasicAgentRequest(TypedDict):
    input: str
    model_id: NotRequired[str]


class InvokeBasicAgentResponse(TypedDict):
    output: str


ScheduleDelayHours = int


CooldownSeconds = int


class ListIftttRulesResponseItem(TypedDict):
    id: str
    account_id: str
    channel: str
    scope: NotRequired[Optional[str]]
    condition_description: str
    evaluation_mode: Literal["llm", "static"]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: str
    action_params: Dict[str, Any]
    visibility: Literal["opaque", "transparent"]
    status: Literal["active", "inactive"]
    priority: float
    category: NotRequired[Optional[str]]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]
    created: str
    created_by: str
    edited_by: str
    last_edited: str


ListIftttRulesResponse = List[ListIftttRulesResponseItem]


class ListZoriAuditTasksParams(TypedDict):
    limit: NotRequired[int]
    agent: NotRequired[str]


class ListZoriAuditTasksResponseItem(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


ListZoriAuditTasksResponse = List[ListZoriAuditTasksResponseItem]


class ListZoriAuditRuleActionsParams(TypedDict):
    limit: NotRequired[int]


class ListZoriAuditRuleActionsResponseItem(TypedDict):
    account_id: str
    subject_id: str
    category: str
    action: str
    timestamp: str
    channel: str
    status: Literal["Queued", "Completed", "Rejected"]
    action_params: Dict[str, Any]
    rule_id: Optional[str]
    ttl: float


ListZoriAuditRuleActionsResponse = List[ListZoriAuditRuleActionsResponseItem]


class InvokeHealthSummaryAgentRequest(TypedDict):
    version: Literal["v1", "v2"]
    subject_id: str
    project_id: str
    mutate: NotRequired[bool]
    should_extract_data: NotRequired[bool]
    should_include_synopsis_layout: NotRequired[bool]


class InvokeHealthSummaryAgentResponse(TypedDict):
    task_id: str


class GetHealthSummaryInvocationsParams(TypedDict):
    subject_id: str


class GetHealthSummaryInvocationsResponseItem(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


GetHealthSummaryInvocationsResponse = List[GetHealthSummaryInvocationsResponseItem]


class GetHealthSummaryScheduledTaskResponse(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


class FlushHealthSummaryScheduledTaskRequest(TypedDict):
    pass


class ProvideMessageFeedbackRequest(TypedDict):
    agent_name: str
    trace_id: str
    feedback: NotRequired[str]
    score: NotRequired[float]
    emoji: NotRequired[str]


class InvokeActionPlanNudgeRequest(TypedDict):
    account_id: str
    project_id: str
    subject_id: str
    user_id: str
    correlation_id: NotRequired[str]


class InvokeActionPlanNudgeResponse(TypedDict):
    subject_id: str
    nudge: Dict[str, Any]


class InvokeActionPlanRequest(TypedDict):
    subject_id: str
    project_id: str


class InvokeActionPlanResponse(TypedDict):
    task_id: str


class InvokeTemplateRequest(TypedDict):
    subject_id: str
    project_id: str
    template_id: str
    instructions: NotRequired[str]


class InvokeTemplateResponse(TypedDict):
    task_id: str


class GetTemplateAgentInvocationsParams(TypedDict):
    subject_id: str


class GetTemplateAgentInvocationsResponseItem(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


GetTemplateAgentInvocationsResponse = List[GetTemplateAgentInvocationsResponseItem]


class GetTemplateAgentInvocationResponse(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


class GetAgentTokenResponse(TypedDict):
    AccessKeyId: str
    SecretAccessKey: str
    SessionToken: str
    Expiration: str


class ValidateFileOwnershipRequest(TypedDict):
    subject_id: str
    file_id: str
    project_id: str
    document_reference_id: str


class Result(TypedDict):
    status: Literal["valid", "invalid", "inconclusive"]
    reasoning: str


class ValidateFileOwnershipResponse(TypedDict):
    subject_id: str
    file_id: str
    document_reference_id: str
    result: Result


class CreateProviderTokenRequest(TypedDict):
    subject_id: str
    project_id: str
    voice_name: NotRequired[str]


class CreateProviderTokenResponse(TypedDict):
    name: str
    model: str


class Image(TypedDict):
    base64_data: str
    mime_type: str


class GetVoiceAgentImagesResponse(TypedDict):
    images: List[Image]


class GetSimpleMemberContextParams(TypedDict):
    model: str


class GetSimpleMemberContextResponse(TypedDict):
    context_text: str


class SyncRoutesRequest(TypedDict):
    pass


class SyncRoutesResponse(TypedDict):
    added: float
    removed: float


class RunRouterExperimentRequest(TypedDict):
    dataset_name: str
    experiment_name: NotRequired[str]
    run_metadata: NotRequired[Dict[str, Any]]


class RunRouterExperimentResponse(TypedDict):
    experiment_name: str
    total_items: float
    successful_items: float
    failed_items: float
    item_level_accuracy: float
    run_url: str


class AgentsApiServiceClient(BaseClient):
    def __init__(self, **cfg: Unpack[AlphaConfig]):
        kwargs = {"target": "lambda://agents-api-service-v2:deployed", **(cfg or {})}
        super().__init__(**kwargs)

    async def invoke_basic_agent(self, body: InvokeBasicAgentRequest):
        """Invoke the basic agent"""
        res = await self.client.request(
            path="/v1/agents-v2/basic/invoke", method="POST", body=cast(dict, body)
        )
        return cast(AlphaResponse[InvokeBasicAgentResponse], res)

    async def list_ifttt_rules(self):
        """List all IFTTT rules for the caller's account."""
        res = await self.client.request(path="/v1/agents-v2/ifttt/rules", method="GET")
        return cast(AlphaResponse[ListIftttRulesResponse], res)

    async def list_zori_audit_tasks(self, params: ListZoriAuditTasksParams):
        """List async tasks for account-level Zori audit (newest first)."""
        res = await self.client.request(
            path="/v1/agents-v2/zori-audit/tasks",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[ListZoriAuditTasksResponse], res)

    async def list_zori_audit_rule_actions(
        self, params: ListZoriAuditRuleActionsParams
    ):
        """List rule action records for account-level Zori audit (newest first)."""
        res = await self.client.request(
            path="/v1/agents-v2/zori-audit/rule-actions",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[ListZoriAuditRuleActionsResponse], res)

    async def invoke_health_summary_agent(self, body: InvokeHealthSummaryAgentRequest):
        """Invoke the health summary agent"""
        res = await self.client.request(
            path="/v1/agents-v2/health-summary/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeHealthSummaryAgentResponse], res)

    async def get_health_summary_invocations(
        self, params: GetHealthSummaryInvocationsParams
    ):
        """Get the health summary invocations"""
        res = await self.client.request(
            path="/v1/agents-v2/health-summary/invocations",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetHealthSummaryInvocationsResponse], res)

    async def get_health_summary_scheduled_task(self, task_id: str):
        """Get a health summary scheduled task"""
        res = await self.client.request(
            path=f"/v1/agents-v2/health-summary/invocations/{quote(task_id)}",
            method="GET",
        )
        return cast(AlphaResponse[GetHealthSummaryScheduledTaskResponse], res)

    async def flush_health_summary_scheduled_task(
        self, task_id: str, body: FlushHealthSummaryScheduledTaskRequest
    ):
        """Flush the health summary scheduled task so it is run immediately"""
        await self.client.request(
            path=f"/v1/agents-v2/health-summary/scheduled/{quote(task_id)}",
            method="PATCH",
            body=cast(dict, body),
        )

    async def provide_message_feedback(self, body: ProvideMessageFeedbackRequest):
        """Provide feedback on a message"""
        await self.client.request(
            path="/v1/agents-v2/feedback", method="POST", body=cast(dict, body)
        )

    async def invoke_action_plan_nudge(self, body: InvokeActionPlanNudgeRequest):
        """Invoke the action plan nudge agent"""
        res = await self.client.request(
            path="/v1/private/agents-v2/action-plan-nudge/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeActionPlanNudgeResponse], res)

    async def invoke_action_plan(self, body: InvokeActionPlanRequest):
        """Invoke the action plan agent"""
        res = await self.client.request(
            path="/v1/agents-v2/action-plan/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeActionPlanResponse], res)

    async def invoke_template(self, body: InvokeTemplateRequest):
        """Invoke the template agent"""
        res = await self.client.request(
            path="/v1/agents-v2/template-agent/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeTemplateResponse], res)

    async def get_template_agent_invocations(
        self, params: GetTemplateAgentInvocationsParams
    ):
        """Get template agent invocations for a subject"""
        res = await self.client.request(
            path="/v1/agents-v2/template-agent/invocations",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetTemplateAgentInvocationsResponse], res)

    async def get_template_agent_invocation(self, task_id: str):
        """Get a template agent invocation by task id"""
        res = await self.client.request(
            path=f"/v1/agents-v2/template-agent/invocations/{quote(task_id)}",
            method="GET",
        )
        return cast(AlphaResponse[GetTemplateAgentInvocationResponse], res)

    async def get_agent_token(self):
        """Get an agent token for the current user"""
        res = await self.client.request(path="/v1/agents-v2/token", method="GET")
        return cast(AlphaResponse[GetAgentTokenResponse], res)

    async def validate_file_ownership(self, body: ValidateFileOwnershipRequest):
        """Validate file ownership"""
        res = await self.client.request(
            path="/v1/private/agents-v2/validate-ownership/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[ValidateFileOwnershipResponse], res)

    async def create_provider_token(
        self, provider_id: str, body: CreateProviderTokenRequest
    ):
        """Create an ephemeral provider token for the current user"""
        res = await self.client.request(
            path=f"/v1/agents-v2/providers/{quote(provider_id)}/token",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[CreateProviderTokenResponse], res)

    async def get_voice_agent_images(self, project_id: str, subject_id: str):
        """Get images from the latest user chat message with attachments.
        Searches the first 25 messages for the most recent user message containing
        images and returns them as base64-encoded data."""
        res = await self.client.request(
            path=f"/v1/private/agents-v2/projects/{quote(project_id)}/patients/{quote(subject_id)}/voice-agent-images",
            method="GET",
        )
        return cast(AlphaResponse[GetVoiceAgentImagesResponse], res)

    async def get_simple_member_context(
        self, project_id: str, params: GetSimpleMemberContextParams
    ):
        """Get simple member context for LLM use. Returns the member
        context text formatted and truncated for the specified model. The subject_id is
        derived from the authenticated user's ID."""
        res = await self.client.request(
            path=f"/v1/agents-v2/projects/{quote(project_id)}/simple-member-context",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetSimpleMemberContextResponse], res)

    async def sync_routes(self, body: SyncRoutesRequest):
        """Sync routes in persistence storage"""
        res = await self.client.request(
            path="/v1/private/agents-v2/routing/sync",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[SyncRoutesResponse], res)

    async def run_router_experiment(self, body: RunRouterExperimentRequest):
        """Run a routing experiment against a dataset"""
        res = await self.client.request(
            path="/v1/private/agents-v2/experiments/run-router-experiment",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[RunRouterExperimentResponse], res)
