# Merchant Payment Lib

Python library for merchant payments via wallet API.

## Installation

```bash
pip install tango-merpay-lib
```

```python
from merchant_payment import MerchantPaymentService

service = MerchantPaymentService(
    url="https://api.example.com",
    addon_id="your_addon_id",
    country_id="CD",
    api_key="your_api_key"
)

data = {
    "currency": "CDF",
    "mercode": "MERCH123",
    "msisdn": "243999999999",
    "amount": "1000",
    "pin": "1234"
}

merchant_payment_response = service.do_payment(data)

merchant_payment_status = merchant_payment_response["mapping_response"]["mapping_code"]
merchant_payment_reference = merchant_payment_response["wallet_response"]["txnid"]
merchant_payment_message = merchant_payment_response["wallet_response"]["message"]

if merchant_payment_status != "SUCCESS":
    pass
```