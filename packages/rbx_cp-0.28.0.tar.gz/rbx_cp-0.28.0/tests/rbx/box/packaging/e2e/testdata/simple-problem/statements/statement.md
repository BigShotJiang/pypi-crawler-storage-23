# Simple Problem

Given $n$ pairs of integers, compute the sum of each pair.

## Input

The first line contains an integer $n$ ($1 \leq n \leq 1000$).

The next $n$ lines each contain two integers $a$ and $b$ ($1 \leq a, b \leq 10000$).

## Output

Output $n$ lines, each containing the sum of the corresponding pair.