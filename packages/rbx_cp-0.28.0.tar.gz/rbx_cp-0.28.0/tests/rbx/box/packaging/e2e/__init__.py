"""End-to-end tests for packaging functionality."""
