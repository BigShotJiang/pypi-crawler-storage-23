from blender_mcp_server.server import main

__all__ = ["main"]
