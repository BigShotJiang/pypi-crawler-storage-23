"""
AfriLink Client Module

Main entry point for the SDK. Provides a unified interface for:
- Authentication (DataSpires + CINECA)
- Job submission and management
- Data transfer
- Model/dataset registry access

This is the recommended way to use the SDK.

Authentication Flow:
1. DataSpires auth (required) - validates user account for billing
2. CINECA auth (gated by DataSpires) - gets SSH certificates
3. Telemetry starts tracking usage

The DataSpires login MUST succeed before CINECA auth is attempted.
"""

import os
import sys
import getpass
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass

# Import SDK modules
from .auth import AfriLinkAuth, authenticate, AuthResult
from .cineca_auth import CinecaDirectAuth, authenticate_cineca, CinecaAuthResult
from .finetune import finetune, FinetuneJob, FinetuneJobSpec, TrainingMode, TrainingConfig
from .slurm import SlurmJobManager, SlurmConfig
from .transfer import DataTransferManager, create_transfer_manager
from .registry import ModelRegistry, get_registry, list_models, list_datasets
from .distributed import DistributedConfig, get_optimal_strategy
from .telemetry import JobUsageTracker, TelemetryClient
from .progress import ProgressBar


@dataclass
class ClientConfig:
    """Configuration for AfriLink client"""
    # CINECA credentials (loaded from environment if not provided)
    cineca_username: str = None
    cineca_email: str = None
    cineca_password: str = None
    cineca_totp_seed: str = None

    # DataSpires credentials (required for billing/telemetry)
    dataspires_email: str = None
    dataspires_password: str = None

    # Supabase configuration for telemetry
    supabase_url: str = None
    supabase_key: str = None

    # SLURM configuration
    slurm_account: str = "aih4a_dataspire"
    slurm_partition: str = "boost_usr_prod"

    # Paths
    work_dir: str = "$WORK"

    @classmethod
    def from_env(cls) -> "ClientConfig":
        """Load configuration from environment variables"""
        return cls(
            cineca_username=os.environ.get("CINECA_USERNAME", "iomunga0"),
            cineca_email=os.environ.get("CINECA_EMAIL"),
            cineca_password=os.environ.get("CINECA_PASSWORD"),
            cineca_totp_seed=os.environ.get("CINECA_TOTP_SEED"),
            dataspires_email=os.environ.get("DATASPIRES_EMAIL"),
            dataspires_password=os.environ.get("DATASPIRES_PASSWORD"),
            supabase_url=os.environ.get("SUPABASE_URL"),
            supabase_key=os.environ.get("SUPABASE_SERVICE_KEY"),
            slurm_account=os.environ.get("SLURM_ACCOUNT", "aih4a_dataspire"),
            slurm_partition=os.environ.get("SLURM_PARTITION", "boost_usr_prod"),
        )

    @classmethod
    def from_colab_secrets(cls) -> "ClientConfig":
        """
        Load configuration from Colab secrets.
        Falls back to environment variables if not in Colab.
        """
        config = cls.from_env()

        try:
            from google.colab import userdata
            # Try to load DataSpires credentials from Colab secrets
            try:
                config.dataspires_email = userdata.get('DATASPIRES_EMAIL') or config.dataspires_email
            except Exception:
                pass
            try:
                config.dataspires_password = userdata.get('DATASPIRES_PASSWORD') or config.dataspires_password
            except Exception:
                pass
            try:
                config.supabase_key = userdata.get('SUPABASE_SERVICE_KEY') or config.supabase_key
            except Exception:
                pass
        except ImportError:
            # Not in Colab
            pass

        return config


class AfriLinkClient:
    """
    Main client for AfriLink SDK.

    Provides a unified interface for all SDK functionality.

    Authentication Flow:
    1. authenticate() first prompts for DataSpires credentials (required)
    2. Only after successful DataSpires auth, CINECA headless auth begins
    3. Telemetry is automatically started to track usage

    Usage:
        from afrilink import AfriLinkClient

        # Initialize and authenticate (will prompt for DataSpires credentials)
        client = AfriLinkClient()
        client.authenticate()  # Interactive: prompts for DataSpires email/password

        # Submit a finetune job
        job = client.finetune(
            model="qwen2.5-0.5b",
            training_mode="low",
            data=my_dataset,
            gpus=4
        )

        result = job.run(wait=True)

        # Download trained model
        client.download_model(result["job_id"], "./my_model")
    """

    def __init__(self, config: ClientConfig = None):
        """
        Initialize AfriLink client.

        Args:
            config: Client configuration (default: load from environment/Colab secrets)
        """
        self.config = config or ClientConfig.from_colab_secrets()

        # Auth clients (initialized on authenticate())
        self._cineca_auth: Optional[CinecaDirectAuth] = None
        self._dataspires_auth: Optional[AfriLinkAuth] = None
        self._dataspires_result: Optional[AuthResult] = None

        # Managers (initialized after auth)
        self._slurm_manager: Optional[SlurmJobManager] = None
        self._transfer_manager: Optional[DataTransferManager] = None

        # Telemetry (initialized after DataSpires auth)
        self._job_tracker: Optional[JobUsageTracker] = None

        # Registry
        self._registry = get_registry()

        # Track jobs
        self._jobs: Dict[str, FinetuneJob] = {}

    @property
    def is_dataspires_authenticated(self) -> bool:
        """Check if DataSpires authentication is complete"""
        return self._dataspires_auth is not None and self._dataspires_auth.is_authenticated

    @property
    def dataspires_user_id(self) -> Optional[str]:
        """Get DataSpires user ID for billing"""
        if self._dataspires_auth:
            return self._dataspires_auth.user_id
        return None

    @property
    def is_authenticated(self) -> bool:
        """Check if fully authenticated (both DataSpires and CINECA)"""
        return self._cineca_auth is not None and self._dataspires_auth is not None

    @property
    def cineca(self) -> Optional[CinecaDirectAuth]:
        """Get CINECA auth client"""
        return self._cineca_auth

    @property
    def slurm(self) -> Optional[SlurmJobManager]:
        """Get SLURM job manager"""
        return self._slurm_manager

    @property
    def transfer(self) -> Optional[DataTransferManager]:
        """Get data transfer manager"""
        return self._transfer_manager

    @property
    def registry(self) -> ModelRegistry:
        """Get model/dataset registry"""
        return self._registry

    @property
    def job_tracker(self) -> Optional[JobUsageTracker]:
        """Get job usage tracker for billing"""
        return self._job_tracker

    def _prompt_for_input(self, prompt: str, is_password: bool = False) -> str:
        """Prompt user for input, with special handling for Colab/Jupyter"""
        try:
            # Check if in IPython/Jupyter environment
            from IPython.display import display
            if is_password:
                return getpass.getpass(prompt)
            else:
                return input(prompt)
        except ImportError:
            # Standard terminal
            if is_password:
                return getpass.getpass(prompt)
            else:
                return input(prompt)

    def authenticate_dataspires(
        self,
        email: str = None,
        password: str = None,
        interactive: bool = True,
    ) -> AuthResult:
        """
        Authenticate with DataSpires platform (REQUIRED for billing).

        This MUST succeed before CINECA auth can proceed. DataSpires
        authentication links your usage to your account for billing.

        Args:
            email: DataSpires email (will prompt if not provided and interactive=True)
            password: DataSpires password (will prompt if not provided and interactive=True)
            interactive: Whether to prompt for credentials if not provided

        Returns:
            AuthResult with success status

        Raises:
            Exception: If authentication fails
        """
        email = email or self.config.dataspires_email
        password = password or self.config.dataspires_password

        # Interactive prompt if credentials not provided
        if interactive and not email:
            print("\n" + "=" * 60)
            print("DataSpires Authentication Required")
            print("=" * 60)
            print("Your DataSpires account is used for usage tracking and billing.")
            print("Don't have an account? Sign up at https://dataspires.com\n")
            email = self._prompt_for_input("DataSpires Email: ").strip()

        if interactive and not password:
            password = self._prompt_for_input("DataSpires Password: ", is_password=True)

        if not email or not password:
            raise ValueError(
                "DataSpires credentials required for authentication.\n"
                "Either provide email/password or set DATASPIRES_EMAIL and "
                "DATASPIRES_PASSWORD environment variables."
            )

        print("\nAuthenticating with DataSpires...")

        self._dataspires_auth = AfriLinkAuth(
            supabase_url=self.config.supabase_url,
            supabase_key=self.config.supabase_key,
        )

        result = self._dataspires_auth.authenticate_supabase(email, password)

        if not result.success:
            raise Exception(f"DataSpires authentication failed: {result.error}")

        self._dataspires_result = result
        print(f"  Authenticated as: {result.email}")
        print(f"  User ID: {result.user_id}")
        print(f"  Balance: ${self._dataspires_auth.balance_usd:.2f}")

        return result

    def authenticate(
        self,
        dataspires_email: str = None,
        dataspires_password: str = None,
        cineca_email: str = None,
        cineca_password: str = None,
        cineca_totp_seed: str = None,
        cineca_username: str = None,
        interactive: bool = True,
    ) -> CinecaAuthResult:
        """
        Full authentication flow: DataSpires first, then CINECA.

        IMPORTANT: DataSpires authentication is REQUIRED and must succeed
        before CINECA authentication begins. This ensures all HPC usage
        is tracked and billed to the correct account.

        The flow is:
        1. Authenticate with DataSpires (prompts for email/password if interactive)
        2. Only if DataSpires succeeds, authenticate with CINECA
        3. Initialize job tracker for usage telemetry

        Args:
            dataspires_email: DataSpires email (prompts if not provided)
            dataspires_password: DataSpires password (prompts if not provided)
            cineca_email: CINECA SSO email (default: from config/env)
            cineca_password: CINECA SSO password (default: from config/env)
            cineca_totp_seed: TOTP seed for 2FA (default: from config/env)
            cineca_username: CINECA username (default: from config/env)
            interactive: Whether to prompt for DataSpires credentials

        Returns:
            CinecaAuthResult

        Raises:
            Exception: If either authentication fails
        """
        # ═══════════════════════════════════════════════════════════════════
        # STEP 1: DataSpires Authentication (REQUIRED - gates CINECA auth)
        # ═══════════════════════════════════════════════════════════════════

        if not self.is_dataspires_authenticated:
            self.authenticate_dataspires(
                email=dataspires_email,
                password=dataspires_password,
                interactive=interactive,
            )

        # ═══════════════════════════════════════════════════════════════════
        # STEP 2: CINECA Authentication (only proceeds if DataSpires succeeded)
        # ═══════════════════════════════════════════════════════════════════

        cineca_email = cineca_email or self.config.cineca_email
        cineca_password = cineca_password or self.config.cineca_password
        cineca_totp_seed = cineca_totp_seed or self.config.cineca_totp_seed
        cineca_username = cineca_username or self.config.cineca_username or "iomunga0"

        if not cineca_email or not cineca_password or not cineca_totp_seed:
            raise ValueError(
                "CINECA credentials required. Set CINECA_EMAIL, CINECA_PASSWORD, "
                "CINECA_TOTP_SEED environment variables or pass them directly."
            )

        self._cineca_auth = CinecaDirectAuth(
            username=cineca_username,
            email=cineca_email,
            password=cineca_password,
            totp_seed=cineca_totp_seed,
        )

        result = self._cineca_auth.authenticate_headless()

        if not result.success:
            raise Exception(f"CINECA authentication failed: {result.error}")

        # Test connection (silent)
        self._cineca_auth.test_ssh_connection()

        # ═══════════════════════════════════════════════════════════════════
        # STEP 3: Initialize managers and telemetry
        # ═══════════════════════════════════════════════════════════════════

        # Initialize SLURM and transfer managers
        slurm_config = SlurmConfig(
            account=self.config.slurm_account,
            partition=self.config.slurm_partition,
        )
        self._slurm_manager = SlurmJobManager(self._cineca_auth, slurm_config)
        self._transfer_manager = create_transfer_manager(self._cineca_auth)

        # Initialize job tracker for usage telemetry (connected to DataSpires user)
        self._job_tracker = JobUsageTracker(
            auth_client=self._dataspires_auth,
            cineca_client=self._cineca_auth,
            auto_deduct_credits=True,
        )

        return result

    def finetune(
        self,
        model: str = "gpt-oss",
        training_mode: Union[str, TrainingMode] = "low",
        data: Any = None,
        dataset_path: str = None,
        gpus: int = 1,
        time_limit: str = "04:00:00",
        backend: str = "cineca",
        output_dir: str = None,
        **kwargs,
    ) -> FinetuneJob:
        """
        Create a finetuning job.

        This is the primary API for submitting finetune jobs.

        Args:
            model: Model identifier (e.g., "gpt-oss", "llama-7b", "mistral-7b")
            training_mode: Training intensity ("low", "medium", "high")
            data: Dataset object or path
            dataset_path: Explicit path to dataset
            gpus: Number of GPUs to request
            time_limit: Maximum job time (HH:MM:SS)
            backend: HPC backend ("cineca", "eversetech", "agh", "acf")
            output_dir: Output directory for results
            **kwargs: Additional job configuration

        Returns:
            FinetuneJob ready for submission

        Example:
            ft = client.finetune(
                model="qwen2.5-0.5b",
                training_mode="low",
                data=my_dataset,
                gpus=1,
                backend="cineca"
            )
            result = ft.run()
        """
        if not self.is_authenticated:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        # Create job using the finetune function
        job = finetune(
            model=model,
            training_mode=training_mode,
            data=data,
            dataset_path=dataset_path,
            gpus=gpus,
            time_limit=time_limit,
            backend=backend,
            output_dir=output_dir,
            **kwargs,
        )

        # Attach managers and billing tracker
        job.cineca_auth = self._cineca_auth
        job.slurm_manager = self._slurm_manager
        job.transfer_manager = self._transfer_manager
        job.job_tracker = self._job_tracker

        # Track job
        self._jobs[job.job_id] = job

        return job

    def list_jobs(self, include_completed: bool = False) -> List[Dict[str, Any]]:
        """
        List submitted jobs.

        Args:
            include_completed: Include completed jobs

        Returns:
            List of job info dicts
        """
        if not self._slurm_manager:
            return []

        return self._slurm_manager.list_jobs()

    def get_job(self, job_id: str) -> Optional[FinetuneJob]:
        """
        Get a tracked job by ID.

        Args:
            job_id: Job ID

        Returns:
            FinetuneJob or None
        """
        return self._jobs.get(job_id)

    def cancel_job(self, job_id: str) -> bool:
        """
        Cancel a running job.

        Args:
            job_id: Job ID or SLURM job ID

        Returns:
            True if cancelled
        """
        # Check if it's a tracked job
        if job_id in self._jobs:
            return self._jobs[job_id].cancel()

        # Try as SLURM job ID
        if self._slurm_manager:
            return self._slurm_manager.cancel_job(job_id)

        return False

    def upload_dataset(
        self,
        local_path: str,
        dataset_name: str = None,
    ):
        """
        Upload a dataset to CINECA.

        Args:
            local_path: Path to local dataset
            dataset_name: Name for the dataset on CINECA

        Returns:
            TransferResult
        """
        if not self._transfer_manager:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        return self._transfer_manager.upload_dataset(local_path, dataset_name)

    def download_model(
        self,
        job_id: str,
        local_dir: str = None,
    ):
        """
        Download trained model weights.

        Args:
            job_id: Finetune job ID
            local_dir: Local destination directory

        Returns:
            TransferResult
        """
        if not self._transfer_manager:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        return self._transfer_manager.download_model_weights(job_id, local_dir)

    def run_command(self, command: str, timeout: int = 60):
        """
        Run a command on CINECA login node.

        Args:
            command: Shell command
            timeout: Timeout in seconds

        Returns:
            Tuple of (returncode, stdout, stderr)
        """
        if not self._cineca_auth:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        return self._cineca_auth.run_ssh_command(command, timeout)

    def get_queue_status(self) -> Dict[str, Any]:
        """
        Get SLURM queue status.

        Returns:
            Dict with queue info
        """
        if not self._slurm_manager:
            return {"error": "Not authenticated"}

        return self._slurm_manager.get_queue_info()

    # Registry convenience methods

    def list_available_models(self, size: str = None) -> List[Dict[str, Any]]:
        """
        List available models for finetuning.

        Args:
            size: Filter by size (small, medium, large)

        Returns:
            List of model info dicts
        """
        return list_models(size)

    def list_available_datasets(self) -> List[Dict[str, Any]]:
        """
        List available datasets.

        Returns:
            List of dataset info dicts
        """
        return list_datasets()

    def get_model_requirements(
        self,
        model: str,
        training_mode: str = "low",
    ) -> Dict[str, Any]:
        """
        Get resource requirements for a model.

        Args:
            model: Model identifier
            training_mode: Training mode

        Returns:
            Dict with resource recommendations
        """
        return self._registry.get_resource_requirements(model, training_mode)


# Convenience function for quick setup
def create_client(
    email: str = None,
    password: str = None,
    totp_seed: str = None,
    auto_auth: bool = True,
) -> AfriLinkClient:
    """
    Create and optionally authenticate an AfriLink client.

    Args:
        email: CINECA email (or set CINECA_EMAIL env var)
        password: CINECA password (or set CINECA_PASSWORD env var)
        totp_seed: TOTP seed (or set CINECA_TOTP_SEED env var)
        auto_auth: Automatically authenticate if credentials available

    Returns:
        Configured AfriLinkClient

    Example:
        # With environment variables set:
        client = create_client()

        # Or with explicit credentials:
        client = create_client(
            email="user@example.com",
            password="...",
            totp_seed="...",
        )
    """
    config = ClientConfig(
        cineca_email=email,
        cineca_password=password,
        cineca_totp_seed=totp_seed,
    )

    client = AfriLinkClient(config)

    if auto_auth and (email or config.cineca_email):
        client.authenticate()

    return client
