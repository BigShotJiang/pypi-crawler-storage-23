"""
AfriLink Telemetry Module

Provides usage tracking and metrics collection with DIRECT Supabase writes.
Runs entirely within the Colab/Jupyter runtime - no Cloudflare intermediary.

IMPORTANT: Usage is billed based on CINECA job runtime, NOT wall-clock time
since authentication. Use JobUsageTracker to track actual HPC job execution.

Data is written to:
- session_telemetry table (heartbeats, session events)
- sessions table (session start/end records)
"""

import os
import sys
import time
import uuid
import threading
from typing import Optional, Dict, Any, Callable, Tuple
from datetime import datetime
from dataclasses import dataclass

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    import urllib.request
    import urllib.error
    import json as _json


@dataclass
class UsageMetrics:
    """Container for usage metrics"""
    elapsed_seconds: float = 0.0
    elapsed_minutes: float = 0.0
    current_cost_usd: float = 0.0
    cpu_percent: float = 0.0
    cpu_avg: float = 0.0
    memory_used_mb: float = 0.0
    memory_percent: float = 0.0
    memory_available_mb: float = 0.0
    io_read_mb: float = 0.0
    io_write_mb: float = 0.0
    process_count: int = 0
    slurm_job_id: str = "local"
    slurm_node: str = "local"
    slurm_partition: str = "local"


class SupabaseTelemetryWriter:
    """
    Direct Supabase writer for telemetry data.
    Bypasses Cloudflare Workers entirely.

    Auth model:
    - apikey header: always the project's anon key (identifies the project)
    - Authorization header: the user's JWT access token from sign_in_with_password
      (this is what Supabase RLS policies use to identify the authenticated user)
    """

    DEFAULT_SUPABASE_URL = "https://plxdnhrdiqqaiyiljzfm.supabase.co"
    DEFAULT_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBseGRuaHJkaXFxYWl5aWxqemZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM5NDg2ODAsImV4cCI6MjA2OTUyNDY4MH0.3WzHgqG85ajp3Lx4UEoT5MnQlOno400GXohT6HSdhv0"

    def __init__(self, supabase_url: str = None, supabase_key: str = None, access_token: str = None):
        self.url = (supabase_url or os.environ.get('SUPABASE_URL', self.DEFAULT_SUPABASE_URL)).rstrip('/')
        # apikey: project-level anon key (always needed in apikey header)
        self.key = supabase_key or os.environ.get('SUPABASE_ANON_KEY') or self.DEFAULT_ANON_KEY
        # access_token: user's JWT from sign_in_with_password (for Authorization header / RLS)
        self.access_token = access_token or ''

    def _request(self, method: str, endpoint: str, data: dict = None) -> dict:
        """Make HTTP request to Supabase REST API"""
        url = f"{self.url}{endpoint}"
        # Use user's JWT access token for Authorization (RLS), anon key for apikey
        auth_token = self.access_token or self.key
        headers = {
            'apikey': self.key,
            'Authorization': f'Bearer {auth_token}',
            'Content-Type': 'application/json',
            'Prefer': 'return=representation',
        }

        if HAS_REQUESTS:
            resp = requests.request(method, url, json=data, headers=headers, timeout=10)
            if resp.status_code >= 400:
                error_text = resp.text[:200]
                print(f"  [telemetry] Supabase {method} {endpoint} → {resp.status_code}: {error_text}")
                return {'error': resp.text}
            return resp.json() if resp.text else {}
        else:
            req = urllib.request.Request(
                url,
                data=_json.dumps(data).encode('utf-8') if data else None,
                headers=headers,
                method=method
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode('utf-8')
                    return _json.loads(body) if body else {}
            except urllib.error.HTTPError as e:
                error_body = e.read().decode('utf-8')
                print(f"  [telemetry] Supabase {method} {endpoint} → {e.code}: {error_body[:200]}")
                return {'error': error_body}

    def create_session(
        self,
        session_id: str,
        user_id: str,
        instance_id: str = None,
        host: str = "colab-runtime",
    ) -> bool:
        """Create session record in sessions table"""
        data = {
            'id': session_id,
            'user_id': user_id,
            'instance_id': instance_id or f"sdk-{session_id[:8]}",
            'host': host,
            'started_at': datetime.utcnow().isoformat() + 'Z',
            'is_ready': True,
        }
        result = self._request('POST', '/rest/v1/sessions', data)
        return 'error' not in result

    def end_session(
        self,
        session_id: str,
        duration_minutes: float,
        cost_usd: float,
    ) -> bool:
        """Update session with end time and cost"""
        data = {
            'ended_at': datetime.utcnow().isoformat() + 'Z',
            'duration_minutes': duration_minutes,
            'cost_usd': cost_usd,
        }
        result = self._request('PATCH', f'/rest/v1/sessions?id=eq.{session_id}', data)
        return 'error' not in result

    def deduct_credits(self, user_id: str, amount_cents: int, session_type: str = "AfriLink Session") -> bool:
        """Deduct credits from user balance via RPC"""
        data = {
            'p_user_id': user_id,
            'p_amount_cents': amount_cents,
            'p_session_type': session_type,
        }
        result = self._request('POST', '/rest/v1/rpc/deduct_credits', data)
        return 'error' not in result


class TelemetryClient:
    """
    Telemetry client with direct Supabase writes.
    Runs entirely within Colab - no Cloudflare intermediary.

    Usage:
        from afrilink import TelemetryClient

        telemetry = TelemetryClient(
            session_id="my-session",
            user_id="user-123",
            supabase_key="...",
        )
        telemetry.start()

        # ... do work ...

        metrics = telemetry.get_metrics()
        print(f"Cost: ${metrics.current_cost_usd:.4f}")

        report = telemetry.stop()  # Writes to Supabase, deducts credits
    """

    RATE_PER_MINUTE = 0.0333  # $2.00/hour

    def __init__(
        self,
        session_id: str = None,
        user_id: str = None,
        supabase_url: str = None,
        supabase_key: str = None,
        access_token: str = None,
        heartbeat_interval: int = 60,
        rate_per_minute: float = None,
        auto_deduct_credits: bool = True,
        # Legacy params (ignored, kept for backwards compat)
        api_endpoint: str = None,
        agent_token: str = None,
    ):
        self.session_id = session_id or str(uuid.uuid4())
        self.user_id = user_id or "anonymous"
        self.heartbeat_interval = heartbeat_interval
        self.rate_per_minute = rate_per_minute or self.RATE_PER_MINUTE
        self.auto_deduct_credits = auto_deduct_credits

        # Direct Supabase writer (uses user's JWT for RLS-protected writes)
        self._writer = SupabaseTelemetryWriter(supabase_url, supabase_key, access_token)
        self._access_token = access_token

        self._start_time: Optional[float] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # Metrics accumulation
        self._cpu_samples: list = []
        self._memory_samples: list = []

        # Callbacks
        self._on_heartbeat: Optional[Callable[[UsageMetrics], None]] = None

    def _collect_metrics(self) -> UsageMetrics:
        """Collect current resource usage metrics"""
        elapsed = time.time() - self._start_time if self._start_time else 0
        elapsed_minutes = elapsed / 60
        current_cost = elapsed_minutes * self.rate_per_minute

        metrics = UsageMetrics(
            elapsed_seconds=elapsed,
            elapsed_minutes=elapsed_minutes,
            current_cost_usd=current_cost,
        )

        if HAS_PSUTIL:
            try:
                cpu_percent = psutil.cpu_percent(interval=0.1)
                with self._lock:
                    self._cpu_samples.append(cpu_percent)
                    metrics.cpu_percent = cpu_percent
                    metrics.cpu_avg = sum(self._cpu_samples) / len(self._cpu_samples)

                mem = psutil.virtual_memory()
                with self._lock:
                    self._memory_samples.append(mem.used)
                metrics.memory_used_mb = mem.used / (1024 * 1024)
                metrics.memory_percent = mem.percent
                metrics.memory_available_mb = mem.available / (1024 * 1024)

                try:
                    io = psutil.disk_io_counters()
                    if io:
                        metrics.io_read_mb = io.read_bytes / (1024 * 1024)
                        metrics.io_write_mb = io.write_bytes / (1024 * 1024)
                except Exception:
                    pass

                metrics.process_count = len(psutil.pids())

            except Exception as e:
                print(f'[Telemetry] Metrics error: {e}', file=sys.stderr)

        metrics.slurm_job_id = os.environ.get('SLURM_JOB_ID', 'local')
        metrics.slurm_node = os.environ.get('SLURMD_NODENAME', 'local')
        metrics.slurm_partition = os.environ.get('SLURM_JOB_PARTITION', 'local')

        return metrics

    def _heartbeat_loop(self):
        """Background heartbeat loop - writes directly to Supabase"""
        while self._running:
            try:
                metrics = self._collect_metrics()

                if self._on_heartbeat:
                    try:
                        self._on_heartbeat(metrics)
                    except Exception as e:
                        print(f'[Telemetry] Callback error: {e}', file=sys.stderr)

            except Exception as e:
                print(f'[Telemetry] Heartbeat error: {e}', file=sys.stderr)

            for _ in range(self.heartbeat_interval):
                if not self._running:
                    break
                time.sleep(1)

    def start(self) -> 'TelemetryClient':
        """Start telemetry tracking"""
        if self._running:
            return self

        self._start_time = time.time()
        self._running = True
        self._cpu_samples = []
        self._memory_samples = []

        # Create session record in Supabase
        if self._access_token:
            self._writer.create_session(
                session_id=self.session_id,
                user_id=self.user_id,
            )

        # Start heartbeat thread
        self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._thread.start()

        print(f'[Telemetry] Started session {self.session_id}')
        return self

    def stop(self) -> Dict[str, Any]:
        """Stop tracking and write final report to Supabase"""
        if not self._running:
            return {}

        self._running = False

        if self._thread:
            self._thread.join(timeout=5)

        metrics = self._collect_metrics()

        report = {
            'session_id': self.session_id,
            'user_id': self.user_id,
            'total_elapsed_minutes': metrics.elapsed_minutes,
            'total_cost_usd': metrics.current_cost_usd,
        }

        if self._cpu_samples:
            report['avg_cpu_percent'] = sum(self._cpu_samples) / len(self._cpu_samples)
            report['max_cpu_percent'] = max(self._cpu_samples)

        if self._memory_samples:
            report['avg_memory_mb'] = sum(self._memory_samples) / len(self._memory_samples) / (1024 * 1024)
            report['max_memory_mb'] = max(self._memory_samples) / (1024 * 1024)

        # Write to Supabase
        if self._access_token:
            # End session record
            self._writer.end_session(
                session_id=self.session_id,
                duration_minutes=metrics.elapsed_minutes,
                cost_usd=metrics.current_cost_usd,
            )

            # Deduct credits
            if self.auto_deduct_credits and metrics.current_cost_usd > 0:
                cost_cents = int(metrics.current_cost_usd * 100)
                if self._writer.deduct_credits(self.user_id, cost_cents, "AfriLink Session"):
                    print(f'[Telemetry] Deducted ${metrics.current_cost_usd:.4f} from balance')

        print(f'[Telemetry] Session stopped')
        print(f'  Duration: {metrics.elapsed_minutes:.2f} minutes')
        print(f'  Cost: ${metrics.current_cost_usd:.4f}')

        return report

    def get_metrics(self) -> UsageMetrics:
        """Get current usage metrics"""
        return self._collect_metrics()

    def on_heartbeat(self, callback: Callable[[UsageMetrics], None]) -> 'TelemetryClient':
        """Set heartbeat callback"""
        self._on_heartbeat = callback
        return self

    @property
    def elapsed_minutes(self) -> float:
        if not self._start_time:
            return 0.0
        return (time.time() - self._start_time) / 60

    @property
    def current_cost(self) -> float:
        return self.elapsed_minutes * self.rate_per_minute

    @property
    def is_running(self) -> bool:
        return self._running


def track_usage(
    session_id: str = None,
    user_id: str = None,
    heartbeat_interval: int = 60,
) -> TelemetryClient:
    """Start local usage tracking (no Supabase)"""
    return TelemetryClient(
        session_id=session_id,
        user_id=user_id,
        heartbeat_interval=heartbeat_interval,
    ).start()


def track_usage_for_user(
    auth_client,
    session_id: str = None,
    heartbeat_interval: int = 60,
    auto_deduct_credits: bool = True,
) -> TelemetryClient:
    """
    DEPRECATED: Use JobUsageTracker instead for CINECA job-based billing.

    This tracks wall-clock time from start() which is NOT correct for HPC billing.
    CINECA usage should be billed based on actual job runtime, not session time.

    See: track_cineca_jobs() for correct job-based usage tracking.
    """
    print("[Warning] track_usage_for_user() tracks wall-clock time, not job runtime.")
    print("[Warning] For CINECA billing, use JobUsageTracker or track_cineca_jobs() instead.")
    return TelemetryClient(
        session_id=session_id,
        user_id=auth_client.user_id,
        supabase_key=auth_client.supabase_key,
        access_token=getattr(auth_client, 'access_token', None),
        supabase_url=auth_client.supabase_url,
        heartbeat_interval=heartbeat_interval,
        auto_deduct_credits=auto_deduct_credits,
    ).start()


class JobUsageTracker:
    """
    Tracks CINECA HPC job runtime for billing purposes.

    Unlike TelemetryClient (which tracks wall-clock time since start()),
    this class tracks actual SLURM job execution time by polling sacct.

    Usage:
        from afrilink import authenticate, JobUsageTracker

        ds_client = authenticate(supabase_key=SUPABASE_KEY)
        cineca = authenticate_cineca(...)

        tracker = JobUsageTracker(ds_client, cineca)

        # Submit a job
        job_id = tracker.submit_job("sbatch my_script.sh")

        # Check status
        status = tracker.get_job_status(job_id)

        # When done, finalize billing
        report = tracker.finalize()  # Calculates cost from actual job runtime
    """

    RATE_PER_GPU_HOUR = 2.00  # $2.00/GPU-hour for Leonardo

    def __init__(
        self,
        auth_client,
        cineca_client,
        session_id: str = None,
        rate_per_gpu_hour: float = None,
        auto_deduct_credits: bool = True,
    ):
        """
        Initialize job usage tracker.

        Args:
            auth_client: Authenticated AfriLinkAuth instance (for Supabase)
            cineca_client: Authenticated CinecaDirectAuth instance (for SSH)
            session_id: Optional session ID
            rate_per_gpu_hour: Cost per GPU-hour (default $2.00)
            auto_deduct_credits: Whether to deduct credits on finalize()
        """
        self.session_id = session_id or str(uuid.uuid4())
        self.user_id = auth_client.user_id
        self._auth = auth_client
        self._cineca = cineca_client
        self.rate_per_gpu_hour = rate_per_gpu_hour or self.RATE_PER_GPU_HOUR
        self.auto_deduct_credits = auto_deduct_credits

        # Use the user's JWT access token for RLS-protected Supabase writes
        access_token = getattr(auth_client, 'access_token', None) or ''
        self._writer = SupabaseTelemetryWriter(
            auth_client.supabase_url,
            auth_client.supabase_key,
            access_token,
        )
        self._access_token = access_token

        # Track jobs
        self._jobs: Dict[str, Dict[str, Any]] = {}  # job_id -> {submitted_at, status, runtime_minutes, gpus}
        self._total_gpu_minutes = 0.0

    def submit_job(self, sbatch_command: str) -> Optional[str]:
        """
        Submit a SLURM job and track it.

        Args:
            sbatch_command: Full sbatch command (e.g., "sbatch --gres=gpu:4 script.sh")

        Returns:
            Job ID if successful, None otherwise
        """
        code, stdout, stderr = self._cineca.run_ssh_command(sbatch_command, timeout=30)

        if code != 0:
            print(f"Job submission failed: {stderr}")
            return None

        # Parse job ID from sbatch output ("Submitted batch job 12345")
        import re
        match = re.search(r'Submitted batch job (\d+)', stdout)
        if not match:
            print(f"Could not parse job ID from: {stdout}")
            return None

        job_id = match.group(1)

        # Try to get GPU count from command
        gpu_match = re.search(r'--gres=gpu:(\d+)', sbatch_command)
        gpus = int(gpu_match.group(1)) if gpu_match else 1

        self._jobs[job_id] = {
            'submitted_at': datetime.utcnow().isoformat() + 'Z',
            'status': 'PENDING',
            'runtime_minutes': 0.0,
            'gpus': gpus,
        }

        print(f"Submitted job {job_id} ({gpus} GPUs)")
        return job_id

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get current status of a job using sacct.

        Returns dict with: state, elapsed_minutes, gpus
        """
        # Use sacct to get job info including elapsed time
        cmd = f"sacct -j {job_id} --format=JobID,State,Elapsed,AllocGRES --noheader --parsable2"
        code, stdout, stderr = self._cineca.run_ssh_command(cmd, timeout=30)

        if code != 0:
            return {'state': 'UNKNOWN', 'elapsed_minutes': 0, 'error': stderr}

        # Parse sacct output
        for line in stdout.strip().split('\n'):
            parts = line.split('|')
            if len(parts) >= 3 and parts[0] == job_id:  # Main job line, not steps
                state = parts[1]
                elapsed = parts[2]  # Format: HH:MM:SS or D-HH:MM:SS

                # Parse elapsed time to minutes
                elapsed_minutes = self._parse_elapsed(elapsed)

                # Update tracked job
                if job_id in self._jobs:
                    self._jobs[job_id]['status'] = state
                    self._jobs[job_id]['runtime_minutes'] = elapsed_minutes

                return {
                    'state': state,
                    'elapsed_minutes': elapsed_minutes,
                    'gpus': self._jobs.get(job_id, {}).get('gpus', 1),
                }

        return {'state': 'UNKNOWN', 'elapsed_minutes': 0}

    def _parse_elapsed(self, elapsed_str: str) -> float:
        """Parse SLURM elapsed time (HH:MM:SS or D-HH:MM:SS) to minutes"""
        try:
            if '-' in elapsed_str:
                days, time_part = elapsed_str.split('-')
                days = int(days)
            else:
                days = 0
                time_part = elapsed_str

            parts = time_part.split(':')
            if len(parts) == 3:
                hours, minutes, seconds = map(int, parts)
            elif len(parts) == 2:
                hours = 0
                minutes, seconds = map(int, parts)
            else:
                return 0.0

            total_minutes = (days * 24 * 60) + (hours * 60) + minutes + (seconds / 60)
            return total_minutes
        except Exception:
            return 0.0

    def poll_all_jobs(self) -> Dict[str, Dict[str, Any]]:
        """Poll status of all tracked jobs"""
        results = {}
        for job_id in self._jobs:
            results[job_id] = self.get_job_status(job_id)
        return results

    def calculate_total_cost(self) -> Tuple[float, float]:
        """
        Calculate total GPU-minutes and cost from all tracked jobs.

        Returns:
            Tuple of (total_gpu_minutes, total_cost_usd)
        """
        total_gpu_minutes = 0.0

        for job_id, job in self._jobs.items():
            # Refresh status
            status = self.get_job_status(job_id)
            runtime = status.get('elapsed_minutes', 0)
            gpus = job.get('gpus', 1)
            total_gpu_minutes += runtime * gpus

        # Cost = GPU-hours * rate
        total_gpu_hours = total_gpu_minutes / 60
        total_cost = total_gpu_hours * self.rate_per_gpu_hour

        return total_gpu_minutes, total_cost

    def finalize(self) -> Dict[str, Any]:
        """
        Finalize tracking, calculate costs, and deduct credits.

        Returns:
            Final usage report
        """
        total_gpu_minutes, total_cost = self.calculate_total_cost()

        report = {
            'session_id': self.session_id,
            'user_id': self.user_id,
            'jobs': list(self._jobs.keys()),
            'total_gpu_minutes': total_gpu_minutes,
            'total_gpu_hours': total_gpu_minutes / 60,
            'total_cost_usd': total_cost,
        }

        # Deduct credits from Supabase
        if self._access_token:
            if self.auto_deduct_credits and total_cost > 0:
                cost_cents = int(total_cost * 100)
                if self._writer.deduct_credits(self.user_id, cost_cents, "AfriLink Session"):
                    print(f'[JobTracker] Deducted ${total_cost:.4f} from balance')

        print(f'[JobTracker] Session finalized')
        print(f'  Jobs tracked: {len(self._jobs)}')
        print(f'  Total GPU-minutes: {total_gpu_minutes:.2f}')
        print(f'  Total cost: ${total_cost:.4f}')

        return report


def track_cineca_jobs(
    auth_client,
    cineca_client,
    session_id: str = None,
    rate_per_gpu_hour: float = None,
    auto_deduct_credits: bool = True,
) -> JobUsageTracker:
    """
    Create a job usage tracker for CINECA HPC billing.

    This is the CORRECT way to track usage for billing. It tracks actual
    SLURM job runtime (GPU-minutes) rather than wall-clock session time.

    Usage:
        from afrilink import authenticate, authenticate_cineca, track_cineca_jobs

        ds_client = authenticate(supabase_key=SUPABASE_KEY)
        cineca = authenticate_cineca(email=..., password=..., totp_seed=...)

        tracker = track_cineca_jobs(ds_client, cineca)

        # Submit jobs
        job_id = tracker.submit_job("sbatch --gres=gpu:4 train.sh")

        # ... wait for jobs to complete ...

        # Finalize billing based on actual job runtime
        report = tracker.finalize()

    Args:
        auth_client: Authenticated AfriLinkAuth instance
        cineca_client: Authenticated CinecaDirectAuth instance
        session_id: Optional session ID
        rate_per_gpu_hour: Cost per GPU-hour (default $2.00)
        auto_deduct_credits: Whether to deduct credits on finalize()

    Returns:
        JobUsageTracker instance
    """
    return JobUsageTracker(
        auth_client=auth_client,
        cineca_client=cineca_client,
        session_id=session_id,
        rate_per_gpu_hour=rate_per_gpu_hour,
        auto_deduct_credits=auto_deduct_credits,
    )
