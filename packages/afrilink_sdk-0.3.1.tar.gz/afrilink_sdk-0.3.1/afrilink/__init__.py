"""
AfriLink SDK — Finetune LLMs on HPC from Google Colab

Quick Start:
    from afrilink import AfriLinkClient

    client = AfriLinkClient()
    client.authenticate()

    ft = client.finetune(model="qwen2.5-0.5b", training_mode="low", data=my_dataset, gpus=1)
    result = ft.run(wait=True)

    client.download_model(result["job_id"], "./my_model")
"""

__version__ = "0.3.1"

# Credentials provisioning (auto-runs in Colab)
from .credentials import (
    provision_credentials,
    get_cineca_credentials,
    CredentialProvider,
    OrgCredentials,
)

# Core authentication
from .auth import AfriLinkAuth, authenticate, AuthResult
from .cineca_auth import CinecaDirectAuth, authenticate_cineca, CinecaAuthResult

# Telemetry
from .telemetry import TelemetryClient, JobUsageTracker, track_cineca_jobs

# Finetuning API
from .finetune import finetune, FinetuneJob, FinetuneJobSpec, TrainingMode, TrainingConfig, SUPPORTED_BACKENDS, DEFAULT_BACKEND

# SLURM job management
from .slurm import SlurmJobManager, SlurmConfig

# Distributed training
from .distributed import DistributedConfig, DistributedStrategy, get_optimal_strategy

# Model/dataset registry
from .registry import (
    ModelRegistry,
    ModelInfo,
    DatasetInfo,
    ModelSize,
    ModelType,
    get_registry,
    list_models,
    list_datasets,
)

# Vouchers
from .vouchers import generate_voucher, validate_voucher, generate_batch

# Data transfer
from .transfer import DataTransferManager, create_transfer_manager

# Main client (recommended entry point)
from .client import AfriLinkClient, ClientConfig, create_client

__all__ = [
    "__version__",
    # Main client
    "AfriLinkClient",
    "ClientConfig",
    "create_client",
    # Credentials
    "provision_credentials",
    "get_cineca_credentials",
    "CredentialProvider",
    "OrgCredentials",
    # Authentication
    "AfriLinkAuth",
    "authenticate",
    "AuthResult",
    "CinecaDirectAuth",
    "authenticate_cineca",
    "CinecaAuthResult",
    # Finetuning
    "finetune",
    "FinetuneJob",
    "FinetuneJobSpec",
    "TrainingMode",
    "TrainingConfig",
    "SUPPORTED_BACKENDS",
    "DEFAULT_BACKEND",
    # SLURM
    "SlurmJobManager",
    "SlurmConfig",
    # Distributed
    "DistributedConfig",
    "DistributedStrategy",
    "get_optimal_strategy",
    # Registry
    "ModelRegistry",
    "ModelInfo",
    "DatasetInfo",
    "ModelSize",
    "ModelType",
    "get_registry",
    "list_models",
    "list_datasets",
    # Vouchers
    "generate_voucher",
    "validate_voucher",
    "generate_batch",
    # Transfer
    "DataTransferManager",
    "create_transfer_manager",
    # Telemetry
    "TelemetryClient",
    "JobUsageTracker",
    "track_cineca_jobs",
]
