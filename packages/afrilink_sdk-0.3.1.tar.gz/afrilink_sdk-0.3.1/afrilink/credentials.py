"""
AfriLink Credentials Module

Handles secure provisioning of org-wide shared credentials to SDK users.
This module manages CINECA authentication credentials that are shared across
all users of the AfriLink SDK.

Security Model:
- Org credentials are encrypted and stored in a secure backend
- SDK fetches credentials at runtime via authenticated API call
- Credentials are injected into environment variables for the auth flow
- Users never see or handle the raw credentials directly

For development/testing, credentials can also be loaded from a config endpoint.
"""

import os
import base64
import json
from typing import Optional, Dict, Any
from dataclasses import dataclass

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


@dataclass
class OrgCredentials:
    """Organization-wide shared credentials"""
    cineca_username: str
    cineca_email: str
    cineca_password: str
    cineca_totp_seed: str

    def inject_to_env(self):
        """Inject credentials into environment variables"""
        os.environ["CINECA_USERNAME"] = self.cineca_username
        os.environ["CINECA_EMAIL"] = self.cineca_email
        os.environ["CINECA_PASSWORD"] = self.cineca_password
        os.environ["CINECA_TOTP_SEED"] = self.cineca_totp_seed

    @classmethod
    def from_env(cls) -> Optional["OrgCredentials"]:
        """Load from environment if already set"""
        username = os.environ.get("CINECA_USERNAME")
        email = os.environ.get("CINECA_EMAIL")
        password = os.environ.get("CINECA_PASSWORD")
        totp_seed = os.environ.get("CINECA_TOTP_SEED")

        if all([username, email, password, totp_seed]):
            return cls(
                cineca_username=username,
                cineca_email=email,
                cineca_password=password,
                cineca_totp_seed=totp_seed,
            )
        return None


class CredentialProvider:
    """
    Provides org-wide credentials to SDK users.

    This class handles fetching shared credentials from a secure backend
    and injecting them into the user's environment for authentication.
    """

    # Backend endpoint for credential provisioning
    # This should be a secure DataSpires endpoint that validates SDK users
    CREDENTIAL_ENDPOINT = "https://api.dataspires.com/v1/sdk/credentials"

    # Fallback: Hardcoded credentials for org (development only)
    # Maybe later we cna fetch them from secure backend endpoint
    _ORG_CREDENTIALS = OrgCredentials(
        cineca_username="iomunga0",
        cineca_email="ianomunga@gmail.com",
        cineca_password="bE-Tyz587VhU4tp",
        cineca_totp_seed="JZEE SSKU MRGF GTZQ IJJW YM3M M4YE GV3Y",
    )

    def __init__(self, api_key: str = None):
        """
        Initialize credential provider.

        Args:
            api_key: Optional DataSpires API key for authenticated access
        """
        self.api_key = api_key or os.environ.get("DATASPIRES_API_KEY")
        self._cached_credentials: Optional[OrgCredentials] = None

    def _fetch_from_backend(self) -> Optional[OrgCredentials]:
        """
        Fetch credentials from secure backend.

        Returns:
            OrgCredentials if successful, None otherwise
        """
        if not HAS_REQUESTS:
            return None

        if not self.api_key:
            # No API key - can't authenticate to backend
            return None

        try:
            response = requests.post(
                self.CREDENTIAL_ENDPOINT,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={"service": "cineca"},
                timeout=10,
            )

            if response.status_code == 200:
                data = response.json()
                return OrgCredentials(
                    cineca_username=data["username"],
                    cineca_email=data["email"],
                    cineca_password=data["password"],
                    cineca_totp_seed=data["totp_seed"],
                )
        except Exception as e:
            print(f"Warning: Could not fetch credentials from backend: {e}")

        return None

    def get_credentials(self, use_backend: bool = True) -> OrgCredentials:
        """
        Get org-wide credentials.

        Priority order:
        1. Cached credentials (if already fetched)
        2. Environment variables (if set by user/system)
        3. Backend API (if api_key available)
        4. Hardcoded org credentials (fallback for development)

        Args:
            use_backend: Whether to try fetching from backend

        Returns:
            OrgCredentials instance
        """
        # Check cache first
        if self._cached_credentials:
            return self._cached_credentials

        # Check environment
        env_creds = OrgCredentials.from_env()
        if env_creds:
            self._cached_credentials = env_creds
            return env_creds

        # Try backend
        if use_backend:
            backend_creds = self._fetch_from_backend()
            if backend_creds:
                self._cached_credentials = backend_creds
                return backend_creds

        # Fallback to hardcoded org credentials
        self._cached_credentials = self._ORG_CREDENTIALS
        return self._cached_credentials

    def provision_environment(self, use_backend: bool = True) -> bool:
        """
        Provision credentials into the current environment.

        This injects org credentials into environment variables so that
        the CinecaDirectAuth class can use them automatically.

        Args:
            use_backend: Whether to try fetching from backend

        Returns:
            True if credentials were provisioned successfully
        """
        try:
            creds = self.get_credentials(use_backend)
            creds.inject_to_env()
            print("CINECA credentials provisioned successfully")
            return True
        except Exception as e:
            print(f"Failed to provision credentials: {e}")
            return False


# Convenience functions for SDK users

def provision_credentials(api_key: str = None) -> bool:
    """
    Provision org-wide CINECA credentials into environment.

    Call this at the start of your notebook to set up authentication.

    Args:
        api_key: Optional DataSpires API key

    Returns:
        True if successful

    Example:
        from afrilink import provision_credentials

        # Provision org credentials (no user input needed)
        provision_credentials()

        # Now authenticate normally
        client = AfriLinkClient()
        client.authenticate()  # Uses provisioned credentials
    """
    provider = CredentialProvider(api_key)
    return provider.provision_environment()


def get_cineca_credentials() -> OrgCredentials:
    """
    Get org-wide CINECA credentials.

    Returns:
        OrgCredentials with username, email, password, totp_seed
    """
    provider = CredentialProvider()
    return provider.get_credentials()


# For Colab: Auto-provision on import if in Colab environment
def _auto_provision_colab():
    """
    Automatically provision credentials in Colab environment.

    This checks if we're running in Colab and provisions credentials
    automatically so users don't need to do anything special.
    """
    try:
        # Check if in Colab
        import google.colab

        # First check if user has their own secrets set
        try:
            from google.colab import userdata
            user_email = userdata.get('CINECA_EMAIL')
            if user_email:
                # User has their own credentials - don't override
                return
        except Exception:
            pass

        # Provision org credentials
        provider = CredentialProvider()
        provider.provision_environment(use_backend=False)  # Use org creds directly

    except ImportError:
        # Not in Colab - skip auto-provision
        pass
    except Exception:
        # Any other error - skip silently
        pass


# Auto-provision when module is imported in Colab
_auto_provision_colab()
