"""
AfriLink Authentication Module

Handles DataSpires platform authentication (Supabase).
This is SEPARATE from CINECA SSO credentials - users must have a
DataSpires account registered on the Webflow platform.

Usage in a Colab/Jupyter cell:
    from afrilink import authenticate
    client = authenticate()  # Prompts for DataSpires email + password
"""

import os
import sys
import getpass
import hashlib
import hmac
import struct
import time
import base64
from typing import Optional, Tuple
from dataclasses import dataclass

try:
    import requests
except ImportError:
    requests = None
    import urllib.request
    import urllib.error
    import json as _json


@dataclass
class AuthResult:
    """Result of authentication attempt"""
    success: bool
    user_id: Optional[str] = None
    email: Optional[str] = None
    access_token: Optional[str] = None
    agent_token: Optional[str] = None
    ssh_proxy_url: Optional[str] = None
    error: Optional[str] = None


class TOTPGenerator:
    """
    TOTP (Time-based One-Time Password) generator compatible with Google Authenticator.
    Implements RFC 6238 for generating 6-digit codes from a base32-encoded seed.
    """

    def __init__(self, secret_base32: str, digits: int = 6, interval: int = 30):
        """
        Initialize TOTP generator.

        Args:
            secret_base32: Base32-encoded secret key (e.g., from Google Authenticator setup)
            digits: Number of digits in OTP (default 6)
            interval: Time step in seconds (default 30)
        """
        self.secret = base64.b32decode(secret_base32.upper().replace(' ', ''))
        self.digits = digits
        self.interval = interval

    def generate(self, timestamp: Optional[float] = None) -> str:
        """
        Generate current TOTP code.

        Args:
            timestamp: Unix timestamp (default: current time)

        Returns:
            6-digit OTP code as string
        """
        if timestamp is None:
            timestamp = time.time()

        # Calculate time counter
        counter = int(timestamp) // self.interval

        # Pack counter as 8-byte big-endian
        counter_bytes = struct.pack('>Q', counter)

        # HMAC-SHA1
        hmac_hash = hmac.new(self.secret, counter_bytes, hashlib.sha1).digest()

        # Dynamic truncation (RFC 4226)
        offset = hmac_hash[-1] & 0x0f
        truncated = struct.unpack('>I', hmac_hash[offset:offset + 4])[0]
        truncated &= 0x7fffffff

        # Generate code with leading zeros
        code = truncated % (10 ** self.digits)
        return str(code).zfill(self.digits)

    def verify(self, code: str, window: int = 1) -> bool:
        """
        Verify a TOTP code with time window tolerance.

        Args:
            code: The code to verify
            window: Number of intervals to check before/after current time

        Returns:
            True if code is valid within the window
        """
        current_time = time.time()
        for offset in range(-window, window + 1):
            test_time = current_time + (offset * self.interval)
            if self.generate(test_time) == code:
                return True
        return False


class SupabaseAuth:
    """
    Supabase authentication client for DataSpires platform.
    Handles email/password login and session management.
    """

    def __init__(self, supabase_url: str, supabase_key: str):
        """
        Initialize Supabase auth client.

        Args:
            supabase_url: Supabase project URL
            supabase_key: Supabase anon key (for auth) or service key (for backend)
        """
        self.url = supabase_url.rstrip('/')
        self.key = supabase_key
        self.access_token = None
        self.refresh_token = None
        self.user = None

    def _request(self, method: str, endpoint: str, data: dict = None, auth_token: str = None) -> dict:
        """Make HTTP request to Supabase"""
        url = f"{self.url}{endpoint}"
        headers = {
            'apikey': self.key,
            'Content-Type': 'application/json',
        }
        if auth_token:
            headers['Authorization'] = f'Bearer {auth_token}'

        if requests:
            resp = requests.request(
                method,
                url,
                json=data,
                headers=headers,
                timeout=30
            )
            if resp.status_code >= 400:
                try:
                    error = resp.json()
                except Exception:
                    error = {'message': resp.text}
                raise Exception(error.get('message', error.get('error_description', str(error))))
            return resp.json() if resp.text else {}
        else:
            # urllib fallback
            req = urllib.request.Request(
                url,
                data=_json.dumps(data).encode('utf-8') if data else None,
                headers=headers,
                method=method
            )
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    body = resp.read().decode('utf-8')
                    return _json.loads(body) if body else {}
            except urllib.error.HTTPError as e:
                body = e.read().decode('utf-8')
                try:
                    error = _json.loads(body)
                except Exception:
                    error = {'message': body}
                raise Exception(error.get('message', error.get('error_description', str(error))))

    def sign_in_with_password(self, email: str, password: str) -> dict:
        """
        Sign in with email and password.

        Args:
            email: User email
            password: User password

        Returns:
            User session data including access_token, user info
        """
        data = {
            'email': email,
            'password': password,
        }
        result = self._request('POST', '/auth/v1/token?grant_type=password', data)

        self.access_token = result.get('access_token')
        self.refresh_token = result.get('refresh_token')
        self.user = result.get('user')

        return result

    def get_user(self) -> dict:
        """Get current user info"""
        if not self.access_token:
            raise Exception("Not authenticated")
        return self._request('GET', '/auth/v1/user', auth_token=self.access_token)

    def get_balance(self, user_id: str) -> float:
        """Get user's credit balance in USD"""
        result = self._request(
            'GET',
            f'/rest/v1/user_balances?id=eq.{user_id}&select=credits_cents',
            auth_token=self.access_token or self.key
        )
        if result and len(result) > 0:
            return result[0].get('credits_cents', 0) / 100.0
        return 0.0


class AfriLinkAuth:
    """
    Main authentication client for AfriLink SDK.
    Combines Supabase auth with CINECA SSH proxy access.
    """

    # Default endpoints (can be overridden)
    DEFAULT_SUPABASE_URL = "https://plxdnhrdiqqaiyiljzfm.supabase.co"
    DEFAULT_SSH_PROXY_URL = "https://africolab-ssh-proxy.fly.dev"

    # Supabase anon key for client-side authentication (email/password login)
    # This is the PUBLIC anon key - safe to include in client code
    DEFAULT_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBseGRuaHJkaXFxYWl5aWxqemZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM5NDg2ODAsImV4cCI6MjA2OTUyNDY4MH0.3WzHgqG85ajp3Lx4UEoT5MnQlOno400GXohT6HSdhv0"

    def __init__(
        self,
        supabase_url: str = None,
        supabase_key: str = None,
        ssh_proxy_url: str = None,
        agent_token: str = None,
    ):
        """
        Initialize AfriLink auth client.

        Args:
            supabase_url: Supabase project URL (default: DataSpires production)
            supabase_key: Supabase anon key for auth (default: DataSpires production anon key)
            ssh_proxy_url: SSH proxy service URL
            agent_token: Agent token for SSH proxy authentication
        """
        self.supabase_url = supabase_url or os.environ.get('SUPABASE_URL', self.DEFAULT_SUPABASE_URL)
        self.supabase_key = supabase_key or os.environ.get('SUPABASE_ANON_KEY') or os.environ.get('SUPABASE_SERVICE_KEY') or self.DEFAULT_SUPABASE_ANON_KEY
        self.ssh_proxy_url = ssh_proxy_url or os.environ.get('SSH_PROXY_URL', self.DEFAULT_SSH_PROXY_URL)
        self.agent_token = agent_token or os.environ.get('AFRICOLAB_AGENT_TOKEN', '')

        self._supabase = None
        self._authenticated = False
        self._user_id = None
        self._email = None
        self._balance = 0.0
        self._access_token = None

    @property
    def is_authenticated(self) -> bool:
        return self._authenticated

    @property
    def user_id(self) -> Optional[str]:
        return self._user_id

    @property
    def email(self) -> Optional[str]:
        return self._email

    @property
    def access_token(self) -> Optional[str]:
        """User's JWT access token from Supabase sign-in (needed for RLS writes)"""
        return self._access_token

    @property
    def balance_usd(self) -> float:
        return self._balance

    def authenticate_supabase(self, email: str, password: str) -> AuthResult:
        """
        Authenticate with DataSpires Supabase.

        Args:
            email: User email
            password: User password

        Returns:
            AuthResult with success status and user info
        """
        try:
            self._supabase = SupabaseAuth(self.supabase_url, self.supabase_key)
            result = self._supabase.sign_in_with_password(email, password)

            self._user_id = result['user']['id']
            self._email = result['user']['email']
            self._access_token = result.get('access_token')
            self._authenticated = True

            # Fetch balance
            try:
                self._balance = self._supabase.get_balance(self._user_id)
            except Exception:
                self._balance = 0.0

            return AuthResult(
                success=True,
                user_id=self._user_id,
                email=self._email,
                access_token=result.get('access_token'),
                agent_token=self.agent_token,
                ssh_proxy_url=self.ssh_proxy_url,
            )

        except Exception as e:
            return AuthResult(
                success=False,
                error=str(e)
            )

    def generate_totp(self, totp_seed: str) -> str:
        """
        Generate TOTP code for CINECA 2FA.

        Args:
            totp_seed: Base32-encoded TOTP seed

        Returns:
            6-digit OTP code
        """
        generator = TOTPGenerator(totp_seed)
        return generator.generate()

    def verify_ssh_proxy(self) -> Tuple[bool, dict]:
        """
        Verify SSH proxy is accessible and certificate is valid.

        Returns:
            Tuple of (success, status_dict)
        """
        if not self.agent_token:
            return False, {'error': 'No agent token configured'}

        url = f"{self.ssh_proxy_url}/cert-status"
        headers = {
            'X-Agent-Token': self.agent_token,
        }

        try:
            if requests:
                resp = requests.get(url, headers=headers, timeout=10)
                if resp.status_code == 200:
                    return True, resp.json()
                return False, {'error': f'HTTP {resp.status_code}'}
            else:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    return True, _json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            return False, {'error': str(e)}

    def full_authenticate(
        self,
        email: str = None,
        password: str = None,
        totp_seed: str = None,
        interactive: bool = True,
    ) -> AuthResult:
        """
        Complete authentication flow:
        1. Authenticate with Supabase (email/password)
        2. Generate TOTP for CINECA (if seed provided)
        3. Verify SSH proxy connectivity

        Args:
            email: User email (prompt if not provided and interactive=True)
            password: User password (prompt if not provided and interactive=True)
            totp_seed: CINECA TOTP seed for 2FA code generation
            interactive: Whether to prompt for missing credentials

        Returns:
            AuthResult with full authentication status
        """
        # Get credentials interactively if needed
        if interactive:
            if not email:
                email = input("DataSpires Email: ").strip()
            if not password:
                password = getpass.getpass("DataSpires Password: ")

        if not email or not password:
            return AuthResult(success=False, error="Email and password required")

        # Step 1: Supabase auth
        print("Authenticating with DataSpires...")
        auth_result = self.authenticate_supabase(email, password)

        if not auth_result.success:
            print(f"Authentication failed: {auth_result.error}")
            return auth_result

        print(f"Authenticated as: {auth_result.email}")
        print(f"User ID: {auth_result.user_id}")
        print(f"Balance: ${self._balance:.2f}")

        # Step 2: Generate TOTP if seed provided
        if totp_seed:
            otp = self.generate_totp(totp_seed)
            print(f"Generated CINECA TOTP: {otp}")
            # Note: The SSH proxy handles cert renewal automatically
            # This OTP would be used if manual renewal is needed

        # Step 3: Verify SSH proxy
        print("Verifying SSH proxy connectivity...")
        proxy_ok, proxy_status = self.verify_ssh_proxy()

        if proxy_ok:
            print(f"SSH Proxy: OK (cert expires in {proxy_status.get('expires_in_minutes', '?')} minutes)")
        else:
            print(f"SSH Proxy: Warning - {proxy_status.get('error', 'unknown error')}")
            print("HPC jobs may fail if SSH certificates are expired.")

        print("\nAuthentication complete!")
        return auth_result


def authenticate(
    email: str = None,
    password: str = None,
    supabase_url: str = None,
    supabase_key: str = None,
    ssh_proxy_url: str = None,
    agent_token: str = None,
    totp_seed: str = None,
    interactive: bool = True,
) -> AfriLinkAuth:
    """
    Convenience function to authenticate and return configured client.

    Usage in Colab:
        from afrilink import authenticate
        client = authenticate()  # Will prompt for credentials

        # Or with explicit credentials:
        client = authenticate(
            email="user@example.com",
            password="...",
            supabase_key="...",
        )

    Args:
        email: User email
        password: User password
        supabase_url: Supabase project URL
        supabase_key: Supabase service key
        ssh_proxy_url: SSH proxy URL
        agent_token: Agent token for SSH proxy
        totp_seed: TOTP seed for CINECA 2FA
        interactive: Prompt for missing credentials

    Returns:
        Configured AfriLinkAuth client
    """
    client = AfriLinkAuth(
        supabase_url=supabase_url,
        supabase_key=supabase_key,
        ssh_proxy_url=ssh_proxy_url,
        agent_token=agent_token,
    )

    result = client.full_authenticate(
        email=email,
        password=password,
        totp_seed=totp_seed,
        interactive=interactive,
    )

    if not result.success:
        raise Exception(f"Authentication failed: {result.error}")

    return client


# Quick test when run directly
if __name__ == "__main__":
    import os
    # Test TOTP generation (requires CINECA_TOTP_SEED env var)
    test_seed = os.environ.get("CINECA_TOTP_SEED")
    if test_seed:
        totp = TOTPGenerator(test_seed)
        print(f"Current TOTP: {totp.generate()}")
    else:
        print("Set CINECA_TOTP_SEED environment variable to test TOTP generation")
