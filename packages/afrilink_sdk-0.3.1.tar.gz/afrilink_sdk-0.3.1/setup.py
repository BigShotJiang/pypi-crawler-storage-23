"""
AfriLink SDK - Python library for HPC compute access
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README if it exists
readme_path = Path(__file__).parent / "README.md"
long_description = ""
if readme_path.exists():
    long_description = readme_path.read_text(encoding="utf-8")

setup(
    name="afrilink-sdk",
    version="0.3.1",
    author="DataSpires",
    author_email="info@dataspires.com",
    description="AfriLink SDK — One-line access to GPUs, models and datasets from your notebook",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/dataspires/afrilink-sdk",
    project_urls={
        "Documentation": "https://www.dataspires.com/#About-Us",
        "Bug Tracker": "https://github.com/DataSpires/afrilink-sdk/issues",
    },
    packages=find_packages(include=["afrilink*"], exclude=["container_build*", "examples*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: System :: Distributed Computing",
    ],
    python_requires=">=3.8",
    install_requires=[],
    extras_require={
        "full": [
            "requests>=2.28.0",
            "psutil>=5.9.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
    keywords=[
        "hpc", "high-performance-computing", "finetuning",
        "llm", "lora", "notebook", "gpu", "slurm", "afrilink",
    ],
)
