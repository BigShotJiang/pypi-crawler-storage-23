# Common tools

```{toctree}
---
maxdepth: 1
---

beam-center-finder
```
