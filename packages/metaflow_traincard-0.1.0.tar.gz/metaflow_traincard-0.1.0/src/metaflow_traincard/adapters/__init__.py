"""Framework adapters for TrainCard Reporter."""

from .huggingface import HFTrainCardCallback

__all__ = ["HFTrainCardCallback"]
