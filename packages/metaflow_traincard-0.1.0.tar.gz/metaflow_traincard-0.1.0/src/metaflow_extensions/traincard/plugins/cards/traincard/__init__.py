from metaflow_traincard.card import TrainCard

CARDS = [TrainCard]
