"""Architecture fitness test package."""
