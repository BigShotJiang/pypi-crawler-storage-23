#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

export MISTRAL_ENV=local
export NUAGE_LOCAL_WORKER=true
source scripts/env.sh --validate-only

ABRAXAS_DIR="../../../abraxas"

echo "Starting dev environment..."
make -C "$ABRAXAS_DIR" dev 2>&1 | tee /tmp/make-dev-output.txt || exit 1

echo "Extracting MISTRAL_API_KEY..."
MISTRAL_API_KEY=$(grep -oE 'MISTRAL_API_KEY=[^ ]+' /tmp/make-dev-output.txt | head -1 | cut -d= -f2)
if [[ -z "$MISTRAL_API_KEY" ]]; then
  echo "Failed to extract MISTRAL_API_KEY from dev environment output" >&2
  cat /tmp/make-dev-output.txt
  exit 1
fi

echo "Starting gateway..."
TEMPORAL_EXTERNAL_SERVER_URL=localhost:7443 docker compose -f "$ABRAXAS_DIR/docker-compose.yaml" up -d gateway

echo "Stopping default worker..."
docker compose -f "$ABRAXAS_DIR/docker-compose.yaml" stop worker

export MISTRAL_API_KEY
export MISTRAL_ENV=local
export NUAGE_LOCAL_WORKER=true

source scripts/env.sh --skip-validate

trap 'kill -- -$$' SIGINT SIGTERM

exec uv run watchmedo auto-restart --directory ../.. --pattern='*.py' --recursive --kill-after 1 -- \
  uv run python -m mistralai_workflows.plugins.nuage.worker
