from mistralai_workflows.plugins.nuage.workflow.workflow_models import WorkflowIntegrations


def test_workflow_integrations_accepts_lechat_key() -> None:
    integrations = WorkflowIntegrations.model_validate({"lechat": {}})
    assert integrations.chat_assistant is not None
    assert integrations.requires_secrets() is False
