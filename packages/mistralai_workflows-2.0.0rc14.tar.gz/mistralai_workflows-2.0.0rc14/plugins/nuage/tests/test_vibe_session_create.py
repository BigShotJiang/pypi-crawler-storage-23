from __future__ import annotations

from typing import Any, cast

import pytest
from pydantic import BaseModel
from vibe.core.tools.builtins.ask_user_question import AskUserQuestionResult

from mistralai_workflows.plugins.nuage import wait_for_input as nuage_wait_for_input
from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.agent.providers.vibe import vibe_patches as nuage_vibe_patches
from mistralai_workflows.plugins.nuage.agent.providers.vibe.vibe import VibeSession

from .vibe_fixtures import MockSandbox, MockWorkflowTaskRecorder, create_vibe_config


def _ask_request() -> nuage_vibe_patches.ProxyInvokeToolRequest:
    return nuage_vibe_patches.ProxyInvokeToolRequest(
        config=create_vibe_config(),
        tool_name="ask_user_question",
        tool_call_id="ask-create-1",
        tool_kwargs={
            "questions": [
                {
                    "question": "Proceed?",
                    "options": [
                        {"label": "Yes", "description": "Continue"},
                        {"label": "No", "description": "Stop"},
                    ],
                    "multi_select": False,
                    "hide_other": True,
                }
            ]
        },
        tool_state={"state": "x"},
    )


def _workflow_task_with_mock_tool_call() -> tuple[nuage_agent_task.WorkflowTask, MockWorkflowTaskRecorder]:
    workflow_task = nuage_agent_task.WorkflowTask()
    recorder = MockWorkflowTaskRecorder()
    workflow_task.tool_call = cast(Any, recorder.tool_call)
    return workflow_task, recorder


class TestVibeSessionCreateBridgeComposition:
    @pytest.mark.asyncio
    async def test_create_allows_integration_override_before_bridge(self) -> None:
        callback_called = False
        workflow_task, workflow_task_recorder = _workflow_task_with_mock_tool_call()

        async def wait_for_input(_input_model: type[BaseModel], _label: str | None) -> BaseModel:
            nonlocal callback_called
            callback_called = True
            raise AssertionError("wait_for_input must not be called when integration overrides ask_user_question")

        class IntegrationAskOverrideHook(nuage_agent_executor.AgentExecutorHook):
            async def invoke_tool(self, request: Any) -> Any:
                if (
                    isinstance(request, nuage_vibe_patches.ProxyInvokeToolRequest)
                    and request.tool_name == "ask_user_question"
                ):
                    return nuage_vibe_patches.ProxyInvokeToolResponse(
                        tool_result={
                            "cancelled": False,
                            "answers": [
                                {"question": "Proceed?", "answer": "Yes", "is_other": False},
                            ],
                        },
                        tool_state=request.tool_state,
                    )
                return await self.next.invoke_tool(request)

        session = await VibeSession.create(
            uncreated_session=VibeSession(),
            sandbox=MockSandbox(),
            workflow_task=workflow_task,
            agent_executor_hook=IntegrationAskOverrideHook(),
        )
        assert isinstance(session, VibeSession)

        executor = session._internal_state.agent_executor
        assert executor is not None

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await executor.invoke_tool(_ask_request())
        parsed = AskUserQuestionResult.model_validate(response.tool_result)

        assert parsed.answers[0].answer == "Yes"
        assert callback_called is False
        assert workflow_task_recorder.tool_call.states == []

    @pytest.mark.asyncio
    async def test_create_allows_integration_delegate_to_bridge(self) -> None:
        saw_ask = False
        callback_called = False
        workflow_task, workflow_task_recorder = _workflow_task_with_mock_tool_call()

        async def wait_for_input(input_model: type[BaseModel], label: str | None) -> BaseModel:
            nonlocal callback_called
            callback_called = True
            assert label == "ask_user_question"
            return input_model.model_validate({"question_0_answer": "Yes"})

        class IntegrationDelegatingHook(nuage_agent_executor.AgentExecutorHook):
            async def invoke_tool(self, request: Any) -> Any:
                nonlocal saw_ask
                if (
                    isinstance(request, nuage_vibe_patches.ProxyInvokeToolRequest)
                    and request.tool_name == "ask_user_question"
                ):
                    saw_ask = True
                return await self.next.invoke_tool(request)

        session = await VibeSession.create(
            uncreated_session=VibeSession(),
            sandbox=MockSandbox(),
            workflow_task=workflow_task,
            agent_executor_hook=IntegrationDelegatingHook(),
        )
        assert isinstance(session, VibeSession)

        executor = session._internal_state.agent_executor
        assert executor is not None

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await executor.invoke_tool(_ask_request())
        parsed = AskUserQuestionResult.model_validate(response.tool_result)

        assert parsed.answers[0].answer == "Yes"
        assert saw_ask is True
        assert callback_called is True
        assert len(workflow_task_recorder.tool_call.states) == 2

    @pytest.mark.asyncio
    async def test_create_without_runtime_context_returns_context_error(self) -> None:
        session = await VibeSession.create(
            uncreated_session=VibeSession(),
            sandbox=MockSandbox(),
            workflow_task=nuage_agent_task.WorkflowTask(),
            agent_executor_hook=None,
        )
        assert isinstance(session, VibeSession)

        executor = session._internal_state.agent_executor
        assert executor is not None
        assert isinstance(executor, nuage_agent_executor.AgentExecutorHook)

        response = await executor.invoke_tool(_ask_request())
        assert response.error == "ask_user_question bridge runtime context is not set"
        assert response.tool_result is None

    @pytest.mark.asyncio
    async def test_create_roundtrip_uses_runtime_context_without_rebinding(self) -> None:
        initial_workflow_task = nuage_agent_task.WorkflowTask()
        rebound_workflow_task, rebound_recorder = _workflow_task_with_mock_tool_call()

        async def wait_for_input(input_model: type[BaseModel], _label: str | None) -> BaseModel:
            return input_model.model_validate({"question_0_answer": "Yes"})

        session = await VibeSession.create(
            uncreated_session=VibeSession(),
            sandbox=MockSandbox(),
            workflow_task=initial_workflow_task,
            agent_executor_hook=None,
        )
        assert isinstance(session, VibeSession)

        restored = VibeSession.model_validate(session.model_dump())
        rebound_session = await VibeSession.create(
            uncreated_session=restored,
            sandbox=MockSandbox(),
            workflow_task=rebound_workflow_task,
            agent_executor_hook=None,
        )
        assert isinstance(rebound_session, VibeSession)

        executor = rebound_session._internal_state.agent_executor
        assert executor is not None

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await executor.invoke_tool(_ask_request())
        parsed = AskUserQuestionResult.model_validate(response.tool_result)

        assert parsed.answers[0].answer == "Yes"
        assert len(rebound_recorder.tool_call.states) == 2
