from __future__ import annotations

from typing import Any, cast

import pytest
from mistralai_workflows.testing import create_test_worker
from pydantic import Field, TypeAdapter
from pydantic_core import to_json

from mistralai_workflows import activity, workflow
from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import polymorphic as nuage_polymorphic


class Animal(nuage_polymorphic.PolymorphicModel):
    name: str


class Dog(Animal):
    breed: str


class Cat(Animal):
    indoor: bool = True


class VersionedAnimal(nuage_polymorphic.PolymorphicModel, polymorphic_type="animal"):
    name: str


class VersionedDog(VersionedAnimal, polymorphic_type="dog"):
    breed: str


class TestPolymorphicSerialization:
    def test_serialize_includes_type(self) -> None:
        dog = Dog(name="Rex", breed="German Shepherd")
        data = dog.model_dump()
        assert data["_polymorphic_type"] == f"{Dog.__module__}.Dog"
        assert data["name"] == "Rex"
        assert data["breed"] == "German Shepherd"

    def test_deserialize_via_base_class(self) -> None:
        data = {"_polymorphic_type": f"{Dog.__module__}.Dog", "name": "Rex", "breed": "German Shepherd"}
        animal = Animal.model_validate(data)
        assert isinstance(animal, Dog)
        assert animal.name == "Rex"
        assert animal.breed == "German Shepherd"

    def test_roundtrip(self) -> None:
        original = Cat(name="Mittens", indoor=False)
        data = original.model_dump()
        restored = Animal.model_validate(data)
        assert isinstance(restored, Cat)
        assert restored.name == "Mittens"
        assert restored.indoor is False

    def test_json_roundtrip(self) -> None:
        original = Dog(name="Buddy", breed="Labrador")
        json_str = original.model_dump_json()
        restored = Animal.model_validate_json(json_str)
        assert isinstance(restored, Dog)
        assert restored.name == "Buddy"
        assert restored.breed == "Labrador"

    def test_unknown_type_raises(self) -> None:
        data = {"_polymorphic_type": "nonexistent.UnknownClass", "name": "test"}
        with pytest.raises(ValueError, match="Unknown type"):
            Animal.model_validate(data)

    def test_sibling_types_distinguished(self) -> None:
        dog = Dog(name="Rex", breed="Husky")
        cat = Cat(name="Whiskers", indoor=True)
        restored_dog = Animal.model_validate(dog.model_dump())
        restored_cat = Animal.model_validate(cat.model_dump())
        assert isinstance(restored_dog, Dog)
        assert isinstance(restored_cat, Cat)
        assert not isinstance(restored_dog, Cat)
        assert not isinstance(restored_cat, Dog)


class Owner(nuage_polymorphic.PolymorphicModel):
    pet: Animal | None = None


class Shelter(nuage_polymorphic.PolymorphicModel):
    animals: list[Animal]


class Zoo(nuage_polymorphic.PolymorphicModel):
    animals_by_name: dict[str, Animal]


class TestNestedPolymorphicSerialization:
    def test_nested_field_preserves_subclass_type(self) -> None:
        owner = Owner(pet=Dog(name="Rex", breed="Husky"))
        data = owner.model_dump()
        assert data["pet"]["_polymorphic_type"].endswith(".Dog")
        assert data["pet"]["breed"] == "Husky"

    def test_nested_field_roundtrip_preserves_type(self) -> None:
        original = Owner(pet=Cat(name="Whiskers", indoor=False))
        restored = Owner.model_validate_json(original.model_dump_json())
        assert isinstance(restored.pet, Cat)
        assert restored.pet.indoor is False

    def test_nested_none_roundtrip(self) -> None:
        original = Owner(pet=None)
        restored = Owner.model_validate_json(original.model_dump_json())
        assert restored.pet is None

    def test_list_preserves_mixed_types(self) -> None:
        shelter = Shelter(animals=[Dog(name="Rex", breed="Husky"), Cat(name="Mittens", indoor=True)])
        restored = Shelter.model_validate_json(shelter.model_dump_json())
        assert isinstance(restored.animals[0], Dog)
        assert isinstance(restored.animals[1], Cat)
        assert restored.animals[0].breed == "Husky"
        assert restored.animals[1].indoor is True

    def test_list_serialization_includes_type_markers(self) -> None:
        shelter = Shelter(animals=[Dog(name="Rex", breed="Husky"), Cat(name="Mittens", indoor=True)])
        data = shelter.model_dump()
        assert "_polymorphic_type" in data["animals"][0], "List items should include _polymorphic_type"
        assert "_polymorphic_type" in data["animals"][1], "List items should include _polymorphic_type"
        assert data["animals"][0]["_polymorphic_type"].endswith(".Dog")
        assert data["animals"][1]["_polymorphic_type"].endswith(".Cat")

    def test_dict_serialization_includes_type_markers(self) -> None:
        zoo = Zoo(animals_by_name={"rex": Dog(name="Rex", breed="Husky"), "mittens": Cat(name="Mittens", indoor=True)})
        data = zoo.model_dump()
        assert "_polymorphic_type" in data["animals_by_name"]["rex"], "Dict values should include _polymorphic_type"
        assert "_polymorphic_type" in data["animals_by_name"]["mittens"], "Dict values should include _polymorphic_type"
        assert data["animals_by_name"]["rex"]["_polymorphic_type"].endswith(".Dog")
        assert data["animals_by_name"]["mittens"]["_polymorphic_type"].endswith(".Cat")

    def test_dict_roundtrip_preserves_types(self) -> None:
        zoo = Zoo(animals_by_name={"rex": Dog(name="Rex", breed="Husky"), "mittens": Cat(name="Mittens", indoor=True)})
        restored = Zoo.model_validate_json(zoo.model_dump_json())
        assert isinstance(restored.animals_by_name["rex"], Dog)
        assert isinstance(restored.animals_by_name["mittens"], Cat)
        assert restored.animals_by_name["rex"].breed == "Husky"
        assert restored.animals_by_name["mittens"].indoor is True

    def test_three_level_nesting(self) -> None:
        class Family(nuage_polymorphic.PolymorphicModel):
            owner: Owner

        family = Family(owner=Owner(pet=Dog(name="Buddy", breed="Lab")))
        restored = Family.model_validate_json(family.model_dump_json())
        assert isinstance(restored.owner.pet, Dog)
        assert restored.owner.pet.breed == "Lab"

    def test_nested_with_type_adapter(self) -> None:
        ta = TypeAdapter(Owner)
        owner = Owner(pet=Dog(name="Max", breed="Poodle"))
        data = ta.dump_python(owner)
        assert data["pet"]["_polymorphic_type"].endswith(".Dog")
        assert data["pet"]["breed"] == "Poodle"

    def test_nested_with_to_json(self) -> None:
        import json

        owner = Owner(pet=Cat(name="Luna", indoor=True))
        data = json.loads(to_json(owner))
        assert data["pet"]["_polymorphic_type"].endswith(".Cat")
        assert data["pet"]["indoor"] is True


class TestVersionedPolymorphicSerialization:
    def test_versioned_type_includes_version_suffix(self) -> None:
        dog = VersionedDog(name="Rex", breed="Husky")
        data = dog.model_dump()
        assert data["_polymorphic_type"] == "dog:v1"

    def test_versioned_type_roundtrip(self) -> None:
        original = VersionedDog(name="Rex", breed="Husky")
        data = original.model_dump()
        restored = VersionedAnimal.model_validate(data)
        assert isinstance(restored, VersionedDog)
        assert restored.breed == "Husky"

    def test_unversioned_type_name_fails_deserialization(self) -> None:
        data = {"_polymorphic_type": "dog", "name": "Rex", "breed": "Husky"}
        with pytest.raises(ValueError, match="Unknown type: dog"):
            VersionedAnimal.model_validate(data)

    def test_wrong_version_fails_deserialization(self) -> None:
        data = {"_polymorphic_type": "dog:v2", "name": "Rex", "breed": "Husky"}
        with pytest.raises(ValueError, match="Unknown type: dog:v2"):
            VersionedAnimal.model_validate(data)

    def test_explicit_version_parameter(self) -> None:
        class VersionedCatV2(VersionedAnimal, polymorphic_type="cat", polymorphic_version=2):
            indoor: bool = True

        cat = VersionedCatV2(name="Whiskers")
        data = cat.model_dump()
        assert data["_polymorphic_type"] == "cat:v2"

        restored = VersionedAnimal.model_validate(data)
        assert isinstance(restored, VersionedCatV2)


class Task(nuage_polymorphic.PolymorphicModel):
    name: str = "default"


class TaskHook(nuage_hook.Hook[Task], Task):
    pass


class StreamingTask(Task):
    streaming: bool = True


class CompositeTask(nuage_polymorphic.PolymorphicModel):
    task_a: Task = Field(default_factory=StreamingTask)
    task_b: Task = Field(default_factory=StreamingTask)


class InternalState(nuage_polymorphic.PolymorphicModel):
    sandbox_id: str | None = None


class BaseSandbox(nuage_polymorphic.PolymorphicModel):
    internal_state: InternalState = Field(default_factory=InternalState)


class SandboxHook(nuage_hook.Hook[BaseSandbox], BaseSandbox):
    pass


class TestHookPolymorphicSerialization:
    def test_hook_chain_serialization(self) -> None:
        inner = StreamingTask(name="inner", streaming=True)
        hook = TaskHook(name="hook")
        hook.next_hook = inner

        data = hook.model_dump()
        assert data["name"] == "hook"
        assert data["next_hook"]["name"] == "inner"
        assert data["next_hook"]["streaming"] is True
        assert "_polymorphic_type" in data["next_hook"]

    def test_hook_chain_roundtrip(self) -> None:
        inner = StreamingTask(name="inner", streaming=True)
        hook = TaskHook(name="hook")
        hook.next_hook = inner

        json_str = hook.model_dump_json()
        restored = Task.model_validate_json(json_str)
        assert isinstance(restored, TaskHook)
        assert restored.name == "hook"
        assert isinstance(restored.next_hook, StreamingTask)
        assert restored.next_hook.name == "inner"
        assert restored.next_hook.streaming is True

    def test_composite_with_hooks(self) -> None:
        composite = CompositeTask()
        hook = TaskHook(name="hook")
        hook.next_hook = composite.task_a
        composite.task_a = hook

        json_str = composite.model_dump_json()
        restored = CompositeTask.model_validate_json(json_str)
        assert isinstance(restored.task_a, TaskHook)
        assert isinstance(restored.task_a.next_hook, StreamingTask)
        assert isinstance(restored.task_b, StreamingTask)

    def test_multi_level_hook_chain(self) -> None:
        inner = StreamingTask(name="inner")
        hook1 = TaskHook(name="hook1")
        hook2 = TaskHook(name="hook2")
        hook2.next_hook = inner
        hook1.next_hook = hook2

        json_str = hook1.model_dump_json()
        restored = Task.model_validate_json(json_str)
        assert isinstance(restored, TaskHook)
        assert restored.name == "hook1"
        assert isinstance(restored.next_hook, TaskHook)
        assert restored.next_hook.name == "hook2"
        assert isinstance(restored.next_hook.next_hook, StreamingTask)
        assert restored.next_hook.next_hook.name == "inner"


class TemporalTestSandbox(BaseSandbox, polymorphic_type="test_concrete_sandbox"):
    extra_field: int = 99


def create_hooked_sandbox() -> SandboxHook:
    """Create a TemporalTestSandbox wrapped with SandboxHook."""
    return cast(SandboxHook, nuage_hook.with_hooks(TemporalTestSandbox(), [SandboxHook()]))


class NestedContainer(nuage_polymorphic.PolymorphicModel):
    sandbox: BaseSandbox
    label: str = "default"


@activity()
async def activity_receives_sandbox(sandbox: BaseSandbox) -> str:
    if isinstance(sandbox, SandboxHook):
        return f"sandbox_id={sandbox.next.internal_state.sandbox_id}"
    return f"sandbox_id={sandbox.internal_state.sandbox_id}"


@activity()
async def activity_receives_nested(container: NestedContainer) -> str:
    sandbox = container.sandbox
    if isinstance(sandbox, SandboxHook):
        return f"label={container.label},sandbox_id={sandbox.next.internal_state.sandbox_id}"
    return f"label={container.label},sandbox_id={sandbox.internal_state.sandbox_id}"


@workflow.define(name="test_polymorphic_temporal_workflow")
class PolymorphicTemporalWorkflow:
    @workflow.entrypoint
    async def run(self) -> str:
        sandbox = create_hooked_sandbox()
        sandbox.origin.internal_state.sandbox_id = "test-sandbox-123"
        return await activity_receives_sandbox(sandbox)


@workflow.define(name="test_nested_polymorphic_temporal_workflow")
class NestedPolymorphicTemporalWorkflow:
    @workflow.entrypoint
    async def run(self) -> str:
        sandbox = create_hooked_sandbox()
        sandbox.origin.internal_state.sandbox_id = "nested-456"
        container = NestedContainer(sandbox=sandbox, label="test-label")
        return await activity_receives_nested(container)


class TestPolymorphicTemporalSerialization:
    @pytest.mark.asyncio
    async def test_hooked_sandbox_preserves_state(self, temporal_env: Any) -> None:
        async with create_test_worker(
            temporal_env,
            workflows=[PolymorphicTemporalWorkflow],
            activities=[activity_receives_sandbox],
        ):
            handle = await temporal_env.client.start_workflow(
                "test_polymorphic_temporal_workflow",
                id="test-polymorphic-sandbox",
                task_queue="test-task-queue",
            )
            result = await handle.result()
            actual = result.get("result") if isinstance(result, dict) else result
            assert actual == "sandbox_id=test-sandbox-123"

    @pytest.mark.asyncio
    async def test_nested_polymorphic_preserves_state(self, temporal_env: Any) -> None:
        async with create_test_worker(
            temporal_env,
            workflows=[NestedPolymorphicTemporalWorkflow],
            activities=[activity_receives_nested],
        ):
            handle = await temporal_env.client.start_workflow(
                "test_nested_polymorphic_temporal_workflow",
                id="test-nested-polymorphic",
                task_queue="test-task-queue",
            )
            result = await handle.result()
            actual = result.get("result") if isinstance(result, dict) else result
            assert actual == "label=test-label,sandbox_id=nested-456"
