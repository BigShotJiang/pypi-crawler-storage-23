from __future__ import annotations

from typing import cast

import pytest
from mistralai_workflows.models import EncryptedStrField
from pydantic import Field

from mistralai_workflows.plugins.nuage.integrations.github import github_hooks, github_models
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models


def _make_token(label: str) -> EncryptedStrField:
    return EncryptedStrField(data=f"token-{label}")


def _make_hook(github_token: EncryptedStrField | None = None) -> github_hooks.GitHubSandboxHook:
    return github_hooks.GitHubSandboxHook(
        config=github_models.GitHubConfig(
            url="https://github.com/mistralai/dashboard",
            github_token=github_token,
        )
    )


class _StubSandbox(nuage_sandbox.Sandbox, polymorphic_type="stub_sandbox_test"):
    create_calls: list[dict[str, object]] = Field(default_factory=list)

    def get_info(self) -> nuage_sandbox_models.SandboxInfo:
        return nuage_sandbox_models.SandboxInfo(workspace="/tmp", created=False)

    async def create_sandbox(self, **kwargs: object) -> nuage_sandbox_models.SandboxResult:
        self.create_calls.append(kwargs)
        return nuage_sandbox_models.SandboxResult(sandbox_id="sandbox-id")

    async def execute(self, **kwargs: object) -> nuage_sandbox_models.SandboxExecuteResult:
        raise NotImplementedError

    async def delete_sandbox(self) -> None:
        raise NotImplementedError

    async def execute_python(self, **kwargs: object) -> nuage_sandbox_models.SandboxPythonExecuteResult:
        raise NotImplementedError


class TestGitHubSandboxHookEnvInjection:
    @pytest.mark.asyncio
    async def test_skips_env_injection_when_github_token_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        hook = _make_hook(github_token=None)
        stub = _StubSandbox()
        hook.next_hook = stub

        async def _fake_clone() -> None:
            pass

        monkeypatch.setattr(hook, "_clone_repo", _fake_clone)

        await hook.create_sandbox(env={"SOME_ENV": "value"})
        assert len(stub.create_calls) == 1
        env = stub.create_calls[0].get("env")
        assert env == {"SOME_ENV": "value"}

    @pytest.mark.asyncio
    async def test_injects_token_env_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        token = _make_token("test")
        hook = _make_hook(github_token=token)
        stub = _StubSandbox()
        hook.next_hook = stub

        async def _fake_clone() -> None:
            pass

        monkeypatch.setattr(hook, "_clone_repo", _fake_clone)

        await hook.create_sandbox(env={"EXISTING": "value"})
        assert len(stub.create_calls) == 1
        env = cast(dict[str, object], stub.create_calls[0].get("env"))
        assert env is not None
        assert env["EXISTING"] == "value"
        assert env["GH_TOKEN"] == token
        assert env["GITHUB_TOKEN"] == token

    @pytest.mark.asyncio
    async def test_overrides_existing_github_tokens(self, monkeypatch: pytest.MonkeyPatch) -> None:
        token = _make_token("new")
        old_token = _make_token("old")
        hook = _make_hook(github_token=token)
        stub = _StubSandbox()
        hook.next_hook = stub

        async def _fake_clone() -> None:
            pass

        monkeypatch.setattr(hook, "_clone_repo", _fake_clone)

        await hook.create_sandbox(env={"EXISTING": "value", "GH_TOKEN": old_token, "GITHUB_TOKEN": old_token})
        assert len(stub.create_calls) == 1
        env = cast(dict[str, object], stub.create_calls[0].get("env"))
        assert env is not None
        assert env["EXISTING"] == "value"
        assert env["GH_TOKEN"] == token
        assert env["GITHUB_TOKEN"] == token

    @pytest.mark.asyncio
    async def test_create_sandbox_calls_clone_and_apply_diffs_in_order(self, monkeypatch: pytest.MonkeyPatch) -> None:
        token = _make_token("github")
        hook = github_hooks.GitHubSandboxHook(
            config=github_models.GitHubConfig(
                url="https://github.com/mistralai/dashboard",
                github_token=token,
                teleported_diffs=b"diffs",
            )
        )
        stub = _StubSandbox()
        hook.next_hook = stub
        events: list[str] = []

        async def _fake_clone() -> None:
            events.append("clone")

        async def _fake_apply(diffs: bytes) -> None:
            assert diffs == b"diffs"
            events.append("apply")

        monkeypatch.setattr(hook, "_clone_repo", _fake_clone)
        monkeypatch.setattr(hook, "_apply_diffs", _fake_apply)

        result = await hook.create_sandbox(env={"X": "1"})
        assert result.sandbox_id == "sandbox-id"
        assert len(stub.create_calls) == 1
        assert events == ["clone", "apply"]

    @pytest.mark.asyncio
    async def test_create_sandbox_skips_apply_diffs_when_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        token = _make_token("github")
        hook = github_hooks.GitHubSandboxHook(
            config=github_models.GitHubConfig(
                url="https://github.com/mistralai/dashboard",
                github_token=token,
                teleported_diffs=None,
            )
        )
        stub = _StubSandbox()
        hook.next_hook = stub
        events: list[str] = []

        async def _fake_clone() -> None:
            events.append("clone")

        async def _fake_apply(_diffs: bytes) -> None:
            events.append("apply")

        monkeypatch.setattr(hook, "_clone_repo", _fake_clone)
        monkeypatch.setattr(hook, "_apply_diffs", _fake_apply)

        await hook.create_sandbox()
        assert events == ["clone"]
