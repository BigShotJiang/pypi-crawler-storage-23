from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from typing import Any, Unpack

from pydantic import BaseModel, ConfigDict
from vibe.core.config import Backend, ModelConfig, ProviderConfig, VibeConfig
from vibe.core.paths.config_paths import unlock_config_paths
from vibe.core.tools.base import BaseTool, BaseToolConfig, BaseToolState, InvokeContext
from vibe.core.types import LLMChunk, LLMMessage, Role, ToolStreamEvent

from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent.providers.vibe import vibe_patches as nuage_vibe_patches
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models


class MockAgentExecutor(nuage_agent_executor.AgentExecutor):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    complete_calls: list[nuage_vibe_patches.BackendProxyRequest] = []
    tool_calls: list[nuage_vibe_patches.ProxyInvokeToolRequest] = []
    mcp_calls: list[tuple[str, Any]] = []
    complete_response: nuage_vibe_patches.BackendProxyResponse = nuage_vibe_patches.BackendProxyResponse(
        result=LLMChunk(message=LLMMessage(role=Role.assistant, content="test"))
    )
    tool_response: nuage_vibe_patches.ProxyInvokeToolResponse = nuage_vibe_patches.ProxyInvokeToolResponse(
        tool_result={}, tool_state=None
    )

    def model_post_init(self, __context: Any) -> None:
        self.complete_calls = []
        self.tool_calls = []
        self.mcp_calls = []

    async def complete(self, request: Any) -> nuage_vibe_patches.BackendProxyResponse:
        self.complete_calls.append(request)
        return self.complete_response

    async def invoke_tool(self, request: Any) -> nuage_vibe_patches.ProxyInvokeToolResponse:
        self.tool_calls.append(request)
        return self.tool_response

    async def compute_search_paths(self, request: Any) -> nuage_vibe_patches.ProxyComputeSearchPathsResponse:
        self.mcp_calls.append(("compute_search_paths", request))
        return nuage_vibe_patches.ProxyComputeSearchPathsResponse(paths=[])

    async def iter_tool_classes(self, request: Any) -> nuage_vibe_patches.ProxyIterToolClassesResponse:
        self.mcp_calls.append(("iter_tool_classes", request))
        return nuage_vibe_patches.ProxyIterToolClassesResponse(tools=[])

    async def list_tools_http(self, request: Any) -> nuage_vibe_patches.ProxyListMcpToolsResponse:
        self.mcp_calls.append(("list_tools_http", request))
        return nuage_vibe_patches.ProxyListMcpToolsResponse(tools=[])

    async def list_tools_stdio(self, request: Any) -> nuage_vibe_patches.ProxyListMcpToolsResponse:
        self.mcp_calls.append(("list_tools_stdio", request))
        return nuage_vibe_patches.ProxyListMcpToolsResponse(tools=[])


class DummyToolArgs(BaseModel):
    input_text: str


class DummyToolResult(BaseModel):
    output_text: str


class DummyTool(BaseTool[DummyToolArgs, DummyToolResult, BaseToolConfig, BaseToolState]):
    description = "A dummy tool for testing"

    async def run(
        self, args: DummyToolArgs, ctx: InvokeContext | None = None
    ) -> AsyncGenerator[ToolStreamEvent | DummyToolResult, None]:
        yield DummyToolResult(output_text=f"processed: {args.input_text}")


class MockSandbox(nuage_sandbox.Sandbox):
    async def create_sandbox(self, **kwargs: Any) -> nuage_sandbox_models.SandboxResult:
        return nuage_sandbox_models.SandboxResult(sandbox_id="mock-sandbox-123")

    async def execute(
        self, **kwargs: Unpack[nuage_sandbox_models.ExecuteKwargs]
    ) -> nuage_sandbox_models.SandboxExecuteResult:
        return nuage_sandbox_models.SandboxExecuteResult(stdout="", stderr="", exit_code=0, execution_time=0.1)

    async def delete_sandbox(self) -> None:
        pass

    async def execute_python(
        self, **kwargs: Unpack[nuage_sandbox_models.ExecutePythonKwargs]
    ) -> nuage_sandbox_models.SandboxPythonExecuteResult:
        return nuage_sandbox_models.SandboxPythonExecuteResult(
            result=None, stdout="", stderr="", exit_code=0, execution_time=0.1
        )

    def get_info(self) -> nuage_sandbox_models.SandboxInfo:
        return nuage_sandbox_models.SandboxInfo(workspace="/workspace", created=False)


class MockToolCallRecorder:
    def __init__(self) -> None:
        self.states: list[nuage_agent_models.AgentToolCallState] = []

    async def __aenter__(self) -> MockToolCallRecorder:
        return self

    async def __aexit__(self, *args: object) -> None:
        return None

    async def set_state(self, state: nuage_agent_models.AgentToolCallState) -> None:
        self.states.append(state)


class MockWorkflowTaskRecorder:
    def __init__(self) -> None:
        self.tool_call = MockToolCallRecorder()


def create_vibe_config() -> VibeConfig:
    os.environ.setdefault("TEST_API_KEY", "test-key-value")
    unlock_config_paths()
    return VibeConfig(
        active_model="test-model",
        providers=[
            ProviderConfig(
                name="test",
                api_base="https://api.mistral.ai/v1",
                api_key_env_var="TEST_API_KEY",
                backend=Backend.MISTRAL,
            )
        ],
        models=[
            ModelConfig(
                name="test-model-name",
                provider="test",
                alias="test-model",
                temperature=0.7,
            )
        ],
        mcp_servers=[],
        auto_approve=True,
    )
