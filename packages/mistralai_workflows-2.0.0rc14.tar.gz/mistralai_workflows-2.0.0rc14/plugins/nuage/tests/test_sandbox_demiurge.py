from __future__ import annotations

from typing import Any, Generator
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import (
    demiurge as nuage_demiurge,
)
from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import (
    demiurge_constants as nuage_demiurge_constants,
)
from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import (
    demiurge_models as nuage_demiurge_models,
)


class MockDemiurgeClient:
    def __init__(self) -> None:
        self.create_sandbox = AsyncMock(
            return_value=MagicMock(sandbox_id="demiurge-sandbox-123", expires_at="2025-01-01T00:00:00Z")
        )
        self.execute = AsyncMock(return_value=MagicMock(stdout="", stderr="", exit_code=0, execution_time=0.1))
        self.delete_sandbox = AsyncMock()
        self.upload_file = AsyncMock()

    async def __aenter__(self) -> "MockDemiurgeClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass


def make_demiurge_config(
    image: str | None = None, ttl_seconds: int = 3600
) -> nuage_demiurge_models.DemiurgeSandboxConfig:
    return nuage_demiurge_models.DemiurgeSandboxConfig(
        image=image,
        ttl_seconds=ttl_seconds,
        demiurge_config=nuage_demiurge_models.DemiurgeConfig(base_url="http://test", bearer_token_secret_key=None),
    )


@pytest.fixture
def mock_demiurge_client() -> Generator[MockDemiurgeClient, None, None]:
    client = MockDemiurgeClient()
    with patch(
        "mistralai_workflows.plugins.nuage.sandbox.providers.demiurge.demiurge_activities.DemiurgeClient.from_config",
        return_value=client,
    ):
        yield client


class TestDemiurgeSandbox:
    @pytest.mark.asyncio
    async def test_create_sandbox_calls_demiurge_client(self, mock_demiurge_client: MockDemiurgeClient) -> None:
        config = make_demiurge_config(image="python:3.12", ttl_seconds=1800)
        sandbox = nuage_demiurge.DemiurgeSandbox(config=config)

        result = await sandbox.create_sandbox()

        assert result.sandbox_id == "demiurge-sandbox-123"
        mock_demiurge_client.create_sandbox.assert_called_once()
        call_kwargs = mock_demiurge_client.create_sandbox.call_args.kwargs
        assert call_kwargs["image"] == "python:3.12"
        assert call_kwargs["ttl_seconds"] == 1800

    @pytest.mark.asyncio
    async def test_create_sandbox_with_default_config(self, mock_demiurge_client: MockDemiurgeClient) -> None:
        sandbox = nuage_demiurge.DemiurgeSandbox()

        result = await sandbox.create_sandbox()

        assert result.sandbox_id == "demiurge-sandbox-123"

    @pytest.mark.asyncio
    async def test_execute_prepares_command_with_cwd_and_env(self, mock_demiurge_client: MockDemiurgeClient) -> None:
        sandbox = nuage_demiurge.DemiurgeSandbox(config=make_demiurge_config())
        await sandbox.create_sandbox()
        await sandbox.execute(
            command="echo hello",
            cwd="/custom/path",
            env={"DEBUG": "1"},
        )

        call_args, call_kwargs = mock_demiurge_client.execute.call_args
        sandbox_id, command = call_args
        assert sandbox_id == "demiurge-sandbox-123"
        assert "cd /custom/path" in command
        assert "echo hello" in command
        assert "DEBUG=" in command

    @pytest.mark.asyncio
    async def test_execute_uses_default_workspace_when_no_cwd(self, mock_demiurge_client: MockDemiurgeClient) -> None:
        sandbox = nuage_demiurge.DemiurgeSandbox(config=make_demiurge_config())
        await sandbox.create_sandbox()
        await sandbox.execute(command="ls")

        exec_args = mock_demiurge_client.execute.call_args[0]
        assert f"cd {nuage_demiurge_constants.DEFAULT_WORKSPACE}" in exec_args[1]

    @pytest.mark.asyncio
    async def test_delete_sandbox_calls_client(self, mock_demiurge_client: MockDemiurgeClient) -> None:
        sandbox = nuage_demiurge.DemiurgeSandbox(config=make_demiurge_config())
        await sandbox.create_sandbox()
        await sandbox.delete_sandbox()

        mock_demiurge_client.delete_sandbox.assert_called_once_with("demiurge-sandbox-123")
