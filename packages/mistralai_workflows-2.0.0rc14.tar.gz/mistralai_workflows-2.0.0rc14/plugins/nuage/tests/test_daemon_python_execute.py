from __future__ import annotations

import json

import pytest

from mistralai_workflows.plugins.nuage.sandbox.daemon_python import (
    daemon_python_protocol as nuage_daemon_python_protocol,
)


class TestBuildCode:
    def test_sync_function(self) -> None:
        code = nuage_daemon_python_protocol.build_function_invocation_code("def f(): pass", "f")
        assert "def f(): pass" in code
        assert "__result__ = f(**__kwargs__)" in code
        assert "asyncio" not in code

    def test_async_function(self) -> None:
        code = nuage_daemon_python_protocol.build_function_invocation_code("async def f(): pass", "f", is_async=True)
        assert "__result__ = __import__('asyncio').run(f(**__kwargs__))" in code

    def test_kwargs_serialized_as_json(self) -> None:
        code = nuage_daemon_python_protocol.build_function_invocation_code("def f(x): pass", "f", kwargs={"x": 42})
        assert "__kwargs__ = json.loads(" in code
        assert "42" in code

    def test_empty_kwargs_default(self) -> None:
        code = nuage_daemon_python_protocol.build_function_invocation_code("def f(): pass", "f")
        assert "__kwargs__ = json.loads('{}'" in code


class TestParseResult:
    def test_successful_result(self) -> None:
        stdout = json.dumps({"ok": True, "result": 42, "stdout": "out", "stderr": ""})
        result = nuage_daemon_python_protocol.parse_result(stdout, execution_time=1.5)
        assert result.result == 42
        assert result.stdout == "out"
        assert result.exit_code == 0
        assert result.execution_time == 1.5

    def test_null_result(self) -> None:
        stdout = json.dumps({"ok": True, "result": None, "stdout": "", "stderr": ""})
        result = nuage_daemon_python_protocol.parse_result(stdout)
        assert result.result is None

    def test_error_response_raises(self) -> None:
        stdout = json.dumps({"ok": False, "error": {"message": "NameError", "traceback": "line 1"}})
        with pytest.raises(RuntimeError, match="NameError"):
            nuage_daemon_python_protocol.parse_result(stdout)

    def test_error_with_string_error_field(self) -> None:
        stdout = json.dumps({"ok": False, "error": "something broke"})
        with pytest.raises(RuntimeError, match="something broke"):
            nuage_daemon_python_protocol.parse_result(stdout)

    def test_invalid_json_raises(self) -> None:
        with pytest.raises(ValueError):
            nuage_daemon_python_protocol.parse_result("not json at all")

    def test_error_with_traceback_attached_as_note(self) -> None:
        stdout = json.dumps({"ok": False, "error": {"message": "fail", "traceback": "tb details"}})
        with pytest.raises(RuntimeError) as exc_info:
            nuage_daemon_python_protocol.parse_result(stdout)
        assert any("tb details" in n for n in exc_info.value.__notes__)


class TestRedactResult:
    def test_none_passthrough(self) -> None:
        assert nuage_daemon_python_protocol.redact_result(None) is None

    def test_int_passthrough(self) -> None:
        assert nuage_daemon_python_protocol.redact_result(42) == 42

    def test_nested_dict_redacts_string_values(self) -> None:
        data = {"key": "AKIAIOSFODNN7EXAMPLE", "nested": {"inner": "safe text"}}
        result = nuage_daemon_python_protocol.redact_result(data)
        assert "AKIAIOSFODNN7EXAMPLE" not in str(result)
        assert result["nested"]["inner"] == "safe text"

    def test_list_redacts_string_elements(self) -> None:
        data = ["AKIAIOSFODNN7EXAMPLE", "safe"]
        result = nuage_daemon_python_protocol.redact_result(data)
        assert "AKIAIOSFODNN7EXAMPLE" not in str(result)
        assert result[1] == "safe"
