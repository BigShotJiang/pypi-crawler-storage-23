from __future__ import annotations

import pytest

from mistralai_workflows.plugins.nuage import utils as nuage_utils


class TestEnsure:
    def test_returns_value_when_not_none(self) -> None:
        assert nuage_utils.ensure("hello") == "hello"
        assert nuage_utils.ensure(0) == 0
        assert nuage_utils.ensure(False) is False

    def test_raises_runtime_error_when_none(self) -> None:
        with pytest.raises(RuntimeError, match="Value is required"):
            nuage_utils.ensure(None)

    def test_raises_custom_error_when_none(self) -> None:
        with pytest.raises(ValueError, match="sandbox not ready"):
            nuage_utils.ensure(None, ValueError("sandbox not ready"))

    def test_custom_error_not_raised_when_value_present(self) -> None:
        result = nuage_utils.ensure(42, ValueError("should not fire"))
        assert result == 42
