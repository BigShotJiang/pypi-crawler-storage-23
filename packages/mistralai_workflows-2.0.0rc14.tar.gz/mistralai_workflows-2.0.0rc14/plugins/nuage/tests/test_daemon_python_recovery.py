from __future__ import annotations

from collections import deque
from typing import Any, Unpack

import pytest
from pydantic import Field

from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models
from mistralai_workflows.plugins.nuage.sandbox.daemon_python import (
    daemon_python_protocol as nuage_daemon_python_protocol,
)


def _result(
    *,
    stdout: str = "",
    stderr: str = "",
    exit_code: int = 0,
    execution_time: float = 0.0,
) -> nuage_sandbox_models.SandboxExecuteResult:
    return nuage_sandbox_models.SandboxExecuteResult(
        stdout=stdout,
        stderr=stderr,
        exit_code=exit_code,
        execution_time=execution_time,
    )


class _FakeSandbox(nuage_sandbox.Sandbox, polymorphic_type="_fake_sandbox_test"):
    responses: deque[Any] = Field(default_factory=deque)
    commands: list[str] = Field(default_factory=list)

    def get_info(self) -> nuage_sandbox_models.SandboxInfo:
        return nuage_sandbox_models.SandboxInfo(workspace="/tmp", created=True, sandbox_id="fake-sandbox-id")

    async def create_sandbox(
        self, **kwargs: Unpack[nuage_sandbox_models.CreateSandboxKwargs]
    ) -> nuage_sandbox_models.SandboxResult:
        raise NotImplementedError

    async def execute(
        self, **kwargs: Unpack[nuage_sandbox_models.ExecuteKwargs]
    ) -> nuage_sandbox_models.SandboxExecuteResult:
        self.commands.append(kwargs["command"])
        if not self.responses:
            raise AssertionError("No more mocked responses available")
        response = self.responses.popleft()
        if isinstance(response, Exception):
            raise response
        return response

    async def delete_sandbox(self) -> None:
        raise NotImplementedError

    async def execute_python(
        self, **kwargs: Unpack[nuage_sandbox_models.ExecutePythonKwargs]
    ) -> nuage_sandbox_models.SandboxPythonExecuteResult:
        raise NotImplementedError


@pytest.mark.asyncio
async def test_is_daemon_down_returns_true_when_check_fails() -> None:
    sandbox = _FakeSandbox(responses=deque([_result(exit_code=1, stdout="")]))
    assert await nuage_daemon_python_protocol.is_daemon_down(sandbox) is True


@pytest.mark.asyncio
async def test_is_daemon_down_returns_false_when_daemon_ready() -> None:
    sandbox = _FakeSandbox(responses=deque([_result(exit_code=0, stdout="ok")]))
    assert await nuage_daemon_python_protocol.is_daemon_down(sandbox) is False


@pytest.mark.asyncio
async def test_is_daemon_down_returns_true_on_exception() -> None:
    sandbox = _FakeSandbox(responses=deque([TimeoutError("connection timed out")]))
    assert await nuage_daemon_python_protocol.is_daemon_down(sandbox) is True
