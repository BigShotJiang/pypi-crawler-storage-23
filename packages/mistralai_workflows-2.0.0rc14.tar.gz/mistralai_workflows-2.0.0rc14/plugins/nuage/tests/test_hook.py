from __future__ import annotations

import pytest

from mistralai_workflows.plugins.nuage import hook as nuage_hook


class SimpleHook(nuage_hook.Hook):
    name: str = "default"


class ConfiguredHook(nuage_hook.Hook):
    value: int = 0
    label: str = "test"


class SimpleExecutor(nuage_hook.Hook):
    result: str = "done"


class BaseResourceHook(nuage_hook.Hook):
    resource_id: str


class AdvancedResourceHook(BaseResourceHook):
    cpu_limit: str = "500m"


class AnotherResourceImpl(BaseResourceHook):
    region: str = "us-east-1"
    replicas: int = 1


class TestHookNavigation:
    def test_next_returns_chained_hook(self) -> None:
        h1 = SimpleHook(name="first")
        h2 = SimpleHook(name="second")
        h1.next_hook = h2
        assert h1.next is h2

    def test_next_raises_when_not_chained(self) -> None:
        hook = SimpleHook()
        with pytest.raises(RuntimeError, match="Hook not chained"):
            hook.next

    def test_origin_returns_terminal_node(self) -> None:
        executor = SimpleExecutor(result="end")
        chain = nuage_hook.with_hooks(executor, [SimpleHook(), ConfiguredHook()])
        assert chain.origin is executor

    def test_origin_on_standalone_returns_self(self) -> None:
        executor = SimpleExecutor(result="only")
        assert executor.origin is executor


class TestWithHooks:
    def test_no_hooks_returns_executor_identity(self) -> None:
        executor = SimpleExecutor(result="test")
        assert nuage_hook.with_hooks(executor, None) is executor
        assert nuage_hook.with_hooks(executor, []) is executor

    def test_single_hook_chain(self) -> None:
        handler = SimpleHook(name="h1")
        executor = SimpleExecutor(result="done")
        result = nuage_hook.with_hooks(executor, [handler])
        assert isinstance(result, SimpleHook)
        assert result.name == "h1"
        assert isinstance(result.next, SimpleExecutor)
        assert result.next.result == "done"

    def test_multiple_hooks_chain_order(self) -> None:
        h1 = SimpleHook(name="first")
        h2 = ConfiguredHook(value=42, label="second")
        executor = SimpleExecutor(result="done")
        result = nuage_hook.with_hooks(executor, [h1, h2])
        assert isinstance(result, SimpleHook)
        assert result.name == "first"
        assert isinstance(result.next, ConfiguredHook)
        assert result.next.value == 42
        assert isinstance(result.next.next, SimpleExecutor)
        assert result.next.next.result == "done"

    def test_make_hooks_rejects_invalid_spec(self) -> None:
        with pytest.raises(TypeError, match="Expected Hook class or instance"):
            nuage_hook._make_hooks(["not_a_hook"])  # type: ignore[arg-type]

    def test_make_hooks_accepts_class_specs(self) -> None:
        hooks = nuage_hook._make_hooks([SimpleHook])  # type: ignore[arg-type]
        assert len(hooks) == 1
        assert isinstance(hooks[0], SimpleHook)
        assert hooks[0].name == "default"


class TestSerialization:
    def test_chain_dump_preserves_types_and_nesting(self) -> None:
        chain = nuage_hook.with_hooks(
            SimpleExecutor(result="final"),
            [SimpleHook(name="h1"), ConfiguredHook(value=100, label="cfg")],
        )
        data = chain.model_dump()
        assert data["_polymorphic_type"].endswith("SimpleHook")
        assert data["next_hook"]["_polymorphic_type"].endswith("ConfiguredHook")
        assert data["next_hook"]["next_hook"]["_polymorphic_type"].endswith("SimpleExecutor")
        assert data["next_hook"]["next_hook"]["next_hook"] is None

    def test_chain_roundtrip_via_model_validate(self) -> None:
        original = nuage_hook.with_hooks(
            SimpleExecutor(result="done"),
            [SimpleHook(name="first"), ConfiguredHook(value=42, label="second")],
        )
        restored = nuage_hook.Hook.model_validate(original.model_dump())
        assert original.model_dump() == restored.model_dump()

    def test_json_roundtrip(self) -> None:
        original = nuage_hook.with_hooks(
            SimpleExecutor(result="completed"),
            [SimpleHook(name="a"), ConfiguredHook(value=999)],
        )
        restored = nuage_hook.Hook.model_validate_json(original.model_dump_json())
        assert isinstance(restored, SimpleHook)
        assert isinstance(restored.next, ConfiguredHook)
        assert isinstance(restored.next.next, SimpleExecutor)

    def test_unknown_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown type"):
            nuage_hook.Hook.model_validate({"_polymorphic_type": "nonexistent.Hook", "name": "x"})

    def test_unknown_nested_type_raises(self) -> None:
        data = {
            "_polymorphic_type": SimpleHook._type_name,
            "name": "test",
            "next_hook": {"_polymorphic_type": "nonexistent.X", "result": "done"},
        }
        with pytest.raises(ValueError, match="Unknown type"):
            nuage_hook.Hook.model_validate(data)


class TestWithHookPreservesInternalChain:
    def test_with_hook_attaches_single_hook_to_executor(self) -> None:
        executor = SimpleExecutor(result="done")
        hook = SimpleHook(name="single")
        result = nuage_hook.with_hook(executor, hook)
        assert isinstance(result, SimpleHook)
        assert result.name == "single"
        assert result.next_hook is executor

    def test_with_hook_preserves_prechained_hooks(self) -> None:
        executor = SimpleExecutor(result="final")
        h1 = SimpleHook(name="first")
        h2 = ConfiguredHook(value=42, label="second")
        chained = nuage_hook.chain_hooks([h1, h2])
        assert chained is h1
        assert h1.next_hook is h2

        result = nuage_hook.with_hook(executor, chained)
        assert result is h1
        assert isinstance(result, SimpleHook)
        assert result.name == "first"
        assert isinstance(result.next_hook, ConfiguredHook)
        assert result.next_hook.value == 42
        assert result.next_hook.next_hook is executor

    def test_with_hook_three_prechained_hooks(self) -> None:
        executor = SimpleExecutor(result="end")
        h1 = SimpleHook(name="h1")
        h2 = ConfiguredHook(value=1)
        h3 = SimpleHook(name="h3")
        chained = nuage_hook.chain_hooks([h1, h2, h3])

        result = nuage_hook.with_hook(executor, chained)
        assert result is h1
        assert result.next_hook is h2
        assert h2.next_hook is h3
        assert h3.next_hook is executor

    def test_with_hook_none_returns_executor(self) -> None:
        executor = SimpleExecutor(result="unchanged")
        result = nuage_hook.with_hook(executor, None)
        assert result is executor

    def test_chain_hooks_then_with_hook_roundtrip(self) -> None:
        executor = SimpleExecutor(result="final")
        h1 = SimpleHook(name="outer")
        h2 = ConfiguredHook(value=99, label="inner")
        chained = nuage_hook.chain_hooks([h1, h2])
        full_chain = nuage_hook.with_hook(executor, chained)

        dumped = full_chain.model_dump()
        restored = nuage_hook.Hook.model_validate(dumped)
        assert isinstance(restored, SimpleHook)
        assert restored.name == "outer"
        assert isinstance(restored.next_hook, ConfiguredHook)
        assert restored.next_hook.value == 99
        assert isinstance(restored.next_hook.next_hook, SimpleExecutor)
        assert restored.next_hook.next_hook.result == "final"


class TestPolymorphicHookSerialization:
    def test_sibling_implementations_distinguished(self) -> None:
        advanced = AdvancedResourceHook(resource_id="a-1", cpu_limit="500m")
        another = AnotherResourceImpl(resource_id="b-1", region="eu-west-1", replicas=3)

        r_adv = nuage_hook.Hook.model_validate(advanced.model_dump())
        r_ano = nuage_hook.Hook.model_validate(another.model_dump())
        assert isinstance(r_adv, AdvancedResourceHook)
        assert isinstance(r_ano, AnotherResourceImpl)
        assert r_adv.cpu_limit == "500m"
        assert r_ano.region == "eu-west-1"

    def test_mixed_implementation_chain_roundtrip(self) -> None:
        chain = nuage_hook.with_hooks(
            SimpleExecutor(result="end"),
            [
                AdvancedResourceHook(resource_id="first", cpu_limit="100m"),
                AnotherResourceImpl(resource_id="second", region="ap-south-1"),
            ],
        )
        restored = nuage_hook.Hook.model_validate(chain.model_dump())
        assert isinstance(restored, AdvancedResourceHook)
        assert isinstance(restored.next, AnotherResourceImpl)
        assert isinstance(restored.next.next, SimpleExecutor)
