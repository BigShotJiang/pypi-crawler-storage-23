from __future__ import annotations

from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets


def build_env_dict(data: dict[str, str]) -> nuage_env_secrets.EnvDict:
    return dict(data)  # type: ignore[return-value]
