from __future__ import annotations

import pytest
from vibe.core.agent_loop import AgentLoop
from vibe.core.config import Backend
from vibe.core.tools.base import InvokeContext
from vibe.core.tools.mcp import ToolError
from vibe.core.types import LLMChunk, LLMMessage, LLMUsage, Role

from mistralai_workflows.plugins.nuage.agent.providers.vibe import vibe_patches as nuage_vibe_patches

from .vibe_fixtures import (
    DummyTool,
    DummyToolResult,
    MockAgentExecutor,
    create_vibe_config,
)


def create_patched_loop() -> tuple[AgentLoop, MockAgentExecutor]:
    config = create_vibe_config()
    loop = AgentLoop(config=config, enable_streaming=False)
    executor = MockAgentExecutor()
    nuage_vibe_patches.patch_vibe_loop(loop, executor)
    return loop, executor


class TestBackendPatch:
    @pytest.mark.asyncio
    async def test_complete_forwards_to_executor(self) -> None:
        loop, executor = create_patched_loop()
        await loop.backend.complete(
            model=loop.config.models[0],
            messages=[],
            temperature=0.7,
            tools=None,
            max_tokens=100,
            tool_choice=None,
            extra_headers=None,
        )
        assert len(executor.complete_calls) == 1
        assert executor.complete_calls[0].method == "complete"
        assert executor.complete_calls[0].backend == Backend.MISTRAL

    @pytest.mark.asyncio
    async def test_count_tokens_forwards_to_executor(self) -> None:
        loop, executor = create_patched_loop()
        executor.complete_response = nuage_vibe_patches.BackendProxyResponse(result=42)
        result = await loop.backend.count_tokens(
            model=loop.config.models[0],
            messages=[],
            temperature=0.0,
            tools=None,
            tool_choice=None,
            extra_headers=None,
        )
        assert result == 42
        assert executor.complete_calls[0].method == "count_tokens"

    @pytest.mark.asyncio
    async def test_complete_streaming_forwards_to_executor(self) -> None:
        loop, executor = create_patched_loop()
        chunk = LLMChunk(message=LLMMessage(role=Role.assistant, content="streamed"))
        executor.complete_response = nuage_vibe_patches.BackendProxyResponse(result=chunk)

        results = []
        async for item in loop.backend.complete_streaming(
            model=loop.config.models[0],
            messages=[],
            temperature=0.7,
            tools=None,
            max_tokens=100,
            tool_choice=None,
            extra_headers=None,
        ):
            results.append(item)

        assert len(executor.complete_calls) == 1
        assert executor.complete_calls[0].method == "complete_streaming"
        assert len(results) == 1
        assert results[0].message.content == "streamed"


class TestToolManagerPatch:
    @pytest.mark.asyncio
    async def test_get_returns_tool_that_proxies_invoke(self) -> None:
        loop, executor = create_patched_loop()
        executor.tool_response = nuage_vibe_patches.ProxyInvokeToolResponse(
            tool_result={"output_text": "proxied"}, tool_state=None
        )
        loop.tool_manager._available["dummy_tool"] = DummyTool
        tool = loop.tool_manager.get("dummy_tool")
        results = [item async for item in tool.invoke(ctx=InvokeContext(tool_call_id="c1"), input_text="x")]
        assert len(results) == 1
        assert isinstance(results[0], DummyToolResult)
        assert results[0].output_text == "proxied"


class TestToolInvokePatch:
    @pytest.mark.asyncio
    async def test_invoke_forwards_to_executor_with_correct_request(self) -> None:
        loop, executor = create_patched_loop()
        executor.tool_response = nuage_vibe_patches.ProxyInvokeToolResponse(
            tool_result={"output_text": "result"}, tool_state=None
        )
        loop.tool_manager._available["dummy_tool"] = DummyTool
        tool = loop.tool_manager.get("dummy_tool")
        results = [item async for item in tool.invoke(ctx=InvokeContext(tool_call_id="call-1"), input_text="test")]

        assert len(executor.tool_calls) == 1
        call = executor.tool_calls[0]
        assert call.tool_name == "dummy_tool"
        assert call.tool_call_id == "call-1"
        assert call.tool_kwargs == {"input_text": "test"}
        result = results[0]
        assert isinstance(result, DummyToolResult)
        assert result.output_text == "result"

    @pytest.mark.asyncio
    async def test_invoke_raises_tool_error_when_executor_returns_error(self) -> None:
        loop, executor = create_patched_loop()
        executor.tool_response = nuage_vibe_patches.ProxyInvokeToolResponse(
            tool_result=None,
            tool_state=None,
            error="tool execution failed",
        )
        loop.tool_manager._available["dummy_tool"] = DummyTool
        tool = loop.tool_manager.get("dummy_tool")

        with pytest.raises(ToolError, match="tool execution failed"):
            async for _ in tool.invoke(ctx=InvokeContext(tool_call_id="call-err"), input_text="test"):
                pass


class TestAgentLoopE2E:
    @pytest.mark.asyncio
    async def test_act_triggers_backend_call(self) -> None:
        loop, executor = create_patched_loop()
        chunk = LLMChunk(
            message=LLMMessage(role=Role.assistant, content="Hello from agent!"),
            usage=LLMUsage(prompt_tokens=10, completion_tokens=5),
        )
        executor.complete_response = nuage_vibe_patches.BackendProxyResponse(result=chunk)

        events = []
        async for event in loop.act("Hello"):
            events.append(event)

        assert len(executor.complete_calls) >= 1
        assert executor.complete_calls[0].method == "complete"
        assert executor.complete_calls[0].backend == Backend.MISTRAL
        assert len(events) > 0
