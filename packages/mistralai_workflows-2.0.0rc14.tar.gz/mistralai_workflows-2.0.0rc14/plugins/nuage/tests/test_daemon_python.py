from __future__ import annotations

import json
import subprocess
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

from mistralai_workflows.plugins.nuage.sandbox.daemon_python import (
    daemon_python_commands as nuage_daemon_python_commands,
)


def run_cmd(cmd: str, cwd: str | None = None, timeout: float = 10.0) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


@pytest.mark.xdist_group("daemon")
class TestDaemonE2E:
    @pytest.fixture(autouse=True)
    def setup_daemon(self) -> Iterator[None]:
        with tempfile.TemporaryDirectory() as tmpdir:
            self._base_dir = tmpdir
            write_and_start_cmd = nuage_daemon_python_commands.build_write_and_start_cmd(base_dir=tmpdir)
            result = run_cmd(write_and_start_cmd, cwd=tmpdir, timeout=20)
            assert result.returncode == 0, f"Failed to start daemon: {result.stderr}"

            yield

            subprocess.run(f"pkill -f '{tmpdir}/_daemon.py'", shell=True, capture_output=True)

    def send_code(
        self,
        code: str,
        timeout: int = 10,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
    ) -> dict:
        cmd = nuage_daemon_python_commands.build_send_code_cmd(
            code,
            timeout=timeout,
            base_dir=self._base_dir,
            cwd=cwd,
            env=env,
        )
        result = run_cmd(cmd, timeout=timeout + 5)
        if result.returncode != 0:
            raise RuntimeError(f"send_code failed: {result.stderr}")
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Invalid JSON response: {result.stdout!r}, stderr: {result.stderr!r}") from e

    def test_daemon_starts_via_commands(self) -> None:
        ready_file = Path(self._base_dir) / "_daemon_ready"
        assert ready_file.exists()

    def test_simple_expression(self) -> None:
        result = self.send_code("__result__ = 2 + 2")
        assert result["ok"] is True
        assert result["result"] == 4

    def test_stdout_capture(self) -> None:
        result = self.send_code("print('hello world')")
        assert result["ok"] is True, f"Expected ok=True, got: {result}"
        assert "hello world" in result["stdout"]

    def test_stderr_capture(self) -> None:
        result = self.send_code("import sys; print('error msg', file=sys.stderr)")
        assert result["ok"] is True
        assert "error msg" in result["stderr"]

    def test_exception_handling(self) -> None:
        result = self.send_code("raise ValueError('test error')")
        assert result["ok"] is False
        assert "ValueError" in result["error"]["type"]
        assert "test error" in result["error"]["message"]

    def test_syntax_error(self) -> None:
        result = self.send_code("def broken(")
        assert result["ok"] is False
        assert "SyntaxError" in result["error"]["type"]

    def test_multiline_code(self) -> None:
        code = """
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

__result__ = factorial(5)
"""
        result = self.send_code(code)
        assert result["ok"] is True
        assert result["result"] == 120

    def test_state_persists_across_calls(self) -> None:
        self.send_code("counter = 0")
        self.send_code("counter += 1")
        self.send_code("counter += 1")
        result = self.send_code("__result__ = counter")
        assert result["ok"] is True
        assert result["result"] == 2

    def test_special_chars_in_code(self) -> None:
        result = self.send_code("__result__ = 'hello \"world\" with $pecial chars'")
        assert result["ok"] is True
        assert result["result"] == 'hello "world" with $pecial chars'

    def test_quotes_and_escapes(self) -> None:
        result = self.send_code('__result__ = "it\'s a test with \\\\backslash"')
        assert result["ok"] is True
        assert "it's a test" in result["result"]

    def test_unicode_handling(self) -> None:
        result = self.send_code("__result__ = '你好世界 🚀'")
        assert result["ok"] is True
        assert result["result"] == "你好世界 🚀"

    def test_large_output(self) -> None:
        result = self.send_code("__result__ = 'x' * 50000")
        assert result["ok"] is True
        assert len(result["result"]) == 50000

    def test_import_os(self) -> None:
        result = self.send_code("import os; __result__ = os.path.exists('/tmp')")
        assert result["ok"] is True
        assert result["result"] is True

    def test_newlines_in_strings(self) -> None:
        result = self.send_code("__result__ = 'line1\\nline2\\nline3'")
        assert result["ok"] is True
        assert result["result"] == "line1\nline2\nline3"

    def test_empty_code(self) -> None:
        result = self.send_code("")
        assert result["ok"] is True
        assert result["result"] is None

    def test_cwd_is_applied(self) -> None:
        result = self.send_code("import os; __result__ = os.getcwd()", cwd=self._base_dir)
        assert result["ok"] is True
        assert Path(result["result"]).resolve() == Path(self._base_dir).resolve()

    def test_env_is_applied(self) -> None:
        env_key = "NUAGE_DAEMON_TEST_ENV"
        result = self.send_code(
            f"import os; __result__ = os.environ.get('{env_key}')",
            env={env_key: "value-123"},
        )
        assert result["ok"] is True
        assert result["result"] == "value-123"

    def test_invalid_env_key_rejected(self) -> None:
        with pytest.raises(ValueError, match="Invalid environment variable name"):
            nuage_daemon_python_commands.build_send_code_cmd(
                "__result__ = 1",
                env={"BAD-KEY": "value"},
                base_dir=self._base_dir,
            )

    def test_async_code(self) -> None:
        code = """
import asyncio
async def async_add(a, b):
    await asyncio.sleep(0.01)
    return a + b
__result__ = asyncio.run(async_add(3, 4))
"""
        result = self.send_code(code)
        assert result["ok"] is True
        assert result["result"] == 7

    def test_concurrent_requests(self) -> None:
        import concurrent.futures

        def make_request(i: int) -> dict:
            return self.send_code(f"__result__ = {i} * 2")

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(make_request, i) for i in range(10)]
            results = [f.result() for f in futures]

        for i, result in enumerate(results):
            assert result["ok"] is True
            assert result["result"] == i * 2
