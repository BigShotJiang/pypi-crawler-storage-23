from __future__ import annotations

import json
import shlex
import uuid
from dataclasses import dataclass
from importlib import resources
from typing import Any

from mistralai_workflows.plugins.nuage.sandbox import sandbox_utils

from . import daemon_python_sandbox_script


@dataclass(frozen=True)
class _DaemonPaths:
    ready_file: str
    request_dir: str
    response_dir: str
    script_path: str
    log_path: str
    debug_path: str


def _daemon_paths(base_dir: str) -> _DaemonPaths:
    return _DaemonPaths(
        ready_file=f"{base_dir}/{daemon_python_sandbox_script.DAEMON_READY_FILENAME}",
        request_dir=f"{base_dir}/{daemon_python_sandbox_script.DAEMON_REQUEST_DIRNAME}",
        response_dir=f"{base_dir}/{daemon_python_sandbox_script.DAEMON_RESPONSE_DIRNAME}",
        script_path=f"{base_dir}/{daemon_python_sandbox_script.DAEMON_SCRIPT_FILENAME}",
        log_path=f"{base_dir}/{daemon_python_sandbox_script.DAEMON_LOG_FILENAME}",
        debug_path=f"{base_dir}/{daemon_python_sandbox_script.DAEMON_DEBUG_LOG_FILENAME}",
    )


def get_daemon_script() -> str:
    return resources.files(__package__).joinpath("daemon_python_sandbox_script.py").read_text()


def _validate_env(env: dict[str, str] | None) -> dict[str, str]:
    if env is None:
        return {}

    validated: dict[str, str] = {}
    for key, value in env.items():
        if not sandbox_utils.is_valid_env_key(key):
            raise ValueError(f"Invalid environment variable name: {key!r}")
        if not isinstance(value, str):
            raise ValueError(f"Invalid environment variable value for {key!r}: expected string")
        validated[key] = value
    return validated


def _build_ipc_cmd(request: dict[str, Any], timeout: int, base_dir: str) -> str:
    if timeout <= 0:
        raise ValueError("timeout must be > 0")

    paths = _daemon_paths(base_dir)
    req_id = uuid.uuid4().hex
    payload = json.dumps(request)

    req_file = f"{paths.request_dir}/{req_id}.json"
    req_tmp = f"{paths.request_dir}/{req_id}.tmp"
    resp_file = f"{paths.response_dir}/{req_id}.json"

    q_req_tmp = shlex.quote(req_tmp)
    q_req_file = shlex.quote(req_file)
    q_resp_file = shlex.quote(resp_file)

    write_request = f"printf '%s' {shlex.quote(payload)} > {q_req_tmp} && mv {q_req_tmp} {q_req_file}"
    wait_response = f'timeout {timeout + 2} sh -c "while [ ! -f {q_resp_file} ]; do sleep 0.01; done"'
    read_response = f"cat {q_resp_file} && rm -f {q_resp_file}"
    return f"{write_request} && {wait_response} && {read_response}"


def build_write_and_start_cmd(env: dict[str, str] | None = None, base_dir: str = "/tmp") -> str:
    script = get_daemon_script()
    paths = _daemon_paths(base_dir)
    env = _validate_env(dict(env) if env else {})
    env["DAEMON_BASE_DIR"] = base_dir
    parts = [f"{k}={shlex.quote(v)}" for k, v in env.items() if k]
    env_prefix = f"env {' '.join(parts)} " if parts else ""

    q_ready_file = shlex.quote(paths.ready_file)
    q_request_dir = shlex.quote(paths.request_dir)
    q_response_dir = shlex.quote(paths.response_dir)
    q_script_path = shlex.quote(paths.script_path)
    q_log_path = shlex.quote(paths.log_path)

    verify = "command -v python >/dev/null || (echo 'Missing python' >&2 && exit 1)"
    cleanup = f"rm -rf {q_ready_file} {q_request_dir} {q_response_dir}"
    write_script = f"cat > {q_script_path} << 'DAEMON_EOF'\n{script}\nDAEMON_EOF"
    start = f"nohup {env_prefix}python -u {q_script_path} > {q_log_path} 2>&1 &"
    wait = (
        f"i=0; while [ $i -lt 150 ] && [ ! -f {q_ready_file} ]; do i=$((i+1)); sleep 0.1; done; "
        f"[ -f {q_ready_file} ] || (echo 'Daemon startup timed out' >&2 && exit 1)"
    )

    return f"{verify} && {cleanup} && {write_script}\n{start}\n{wait}"


def build_send_code_cmd(
    code: str,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
    timeout: int = daemon_python_sandbox_script.DAEMON_DEFAULT_TIMEOUT,
    base_dir: str = "/tmp",
) -> str:
    request = {
        "type": "exec",
        "code": code,
        "cwd": cwd,
        "env": _validate_env(env),
        "timeout_s": timeout,
    }
    return _build_ipc_cmd(request=request, timeout=timeout, base_dir=base_dir)


def build_ping_cmd(timeout: int = 2, base_dir: str = "/tmp") -> str:
    return _build_ipc_cmd(request={"type": "ping"}, timeout=timeout, base_dir=base_dir)


def build_check_ready_cmd(base_dir: str = "/tmp") -> str:
    paths = _daemon_paths(base_dir)
    q_ready_file = shlex.quote(paths.ready_file)
    return f"test -f {q_ready_file} && echo ok"


def build_diagnostics_cmd(tail_lines: int = 50, base_dir: str = "/tmp") -> str:
    n = tail_lines
    paths = _daemon_paths(base_dir)

    q_log_path = shlex.quote(paths.log_path)
    q_debug_path = shlex.quote(paths.debug_path)
    q_ready_file = shlex.quote(paths.ready_file)
    q_request_dir = shlex.quote(paths.request_dir)
    q_response_dir = shlex.quote(paths.response_dir)
    q_script_path = shlex.quote(paths.script_path)

    return f"""
echo "=== DAEMON LOG (last {n} lines) ===" && tail -n {n} {q_log_path} 2>/dev/null || echo "(not found)"
echo ""
echo "=== DEBUG LOG (last {n} lines) ===" && tail -n {n} {q_debug_path} 2>/dev/null || echo "(not found)"
echo ""
echo "=== DAEMON PROCESS ===" && ps aux 2>/dev/null | grep -E 'python.*_daemon' | grep -v grep || echo "(not running)"
echo ""
echo "=== READY FILE ===" && cat {q_ready_file} 2>/dev/null || echo "(not found)"
echo ""
echo "=== PENDING REQUESTS ===" && ls -la {q_request_dir}/ 2>/dev/null || echo "(empty)"
echo ""
echo "=== PENDING RESPONSES ===" && ls -la {q_response_dir}/ 2>/dev/null || echo "(empty)"
echo ""
echo "=== DAEMON SCRIPT ===" && head -n 20 {q_script_path} 2>/dev/null || echo "(not found)"
"""
