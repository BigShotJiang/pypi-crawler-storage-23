import shlex


def build_clone_command(
    dest: str,
    url: str,
    auth_url: str,
    git_user_name: str,
    git_user_email: str,
    branch: str | None = None,
    commit: str | None = None,
    working_branch: str | None = None,
) -> str:
    dest = shlex.quote(dest)
    cmd = f"rm -rf {dest}/* {dest}/.[!.]* 2>/dev/null || true"
    cmd += " && git config --global --add safe.directory '*'"
    # SECURITY NOTE: Token in URL written to global git config. This persists in the sandbox
    # but is acceptable since sandboxes are ephemeral and isolated per-workflow.
    # A token-agnostic solution using authenticated proxy is in progress.
    # See: https://www.notion.so/mistralai/Nuage-Prod-Release-Plan-3046ba59a7fe8077ab2af9c6bcb3e2cb#f0e2eb59e0884e189c6c81bd08efdab4
    cmd += f" && git config --global url.{shlex.quote(auth_url)}.insteadOf {shlex.quote(url)}"
    cmd += " && git clone --progress"

    if branch:
        cmd += f" --single-branch --branch {shlex.quote(branch)}"
    cmd += f" {shlex.quote(url)} {dest}"

    if commit:
        cmd += f" && git -C {dest} checkout {shlex.quote(commit)}"

    cmd += f" && git -C {dest} config user.name {shlex.quote(git_user_name)}"
    cmd += f" && git -C {dest} config user.email {shlex.quote(git_user_email)}"
    cmd += f" && git -C {dest} config push.autoSetupRemote true"

    if working_branch:
        cmd += f" && git -C {dest} checkout -b {shlex.quote(working_branch)}"

    return cmd


def build_apply_diffs_command(diffs_b64_zstd: str) -> str:
    return (
        f"printf '%s' {shlex.quote(diffs_b64_zstd)} | base64 -d | zstd -d | (cat; echo) | git apply --whitespace=nowarn"
    )


def build_validate_state_script(github_token: str, expected_head: str) -> str:
    github_token_quoted = shlex.quote(github_token)
    expected_head_quoted = shlex.quote(expected_head)
    return f"""\
set -e
GH_TOKEN_FILE=$(mktemp)
trap 'rm -f "$GH_TOKEN_FILE"' EXIT
printf '%s' {github_token_quoted} > "$GH_TOKEN_FILE"
export GH_TOKEN=$(cat "$GH_TOKEN_FILE")
echo "[nuage-debug] pwd=$(pwd)" >&2
echo "[nuage-debug] git status:" >&2
git status --short >&2 2>&1 || echo "[nuage-debug] git status failed" >&2
echo "[nuage-debug] git rev-parse --abbrev-ref HEAD:" >&2
git rev-parse --abbrev-ref HEAD >&2 2>&1 || echo "[nuage-debug] rev-parse failed" >&2
BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")
echo "[nuage-debug] BRANCH=$BRANCH" >&2
DIRTY=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
echo "[nuage-debug] DIRTY=$DIRTY" >&2
echo "[nuage-debug] running ls-remote for BRANCH=$BRANCH" >&2
LS_REMOTE_OUT=$(git ls-remote --heads origin "$BRANCH" 2>&1 || true)
echo "[nuage-debug] ls-remote output: $LS_REMOTE_OUT" >&2
REMOTE_EXISTS=$(echo "$LS_REMOTE_OUT" | grep -q "refs/heads/$BRANCH" && echo "true" || echo "false")
echo "[nuage-debug] REMOTE_EXISTS=$REMOTE_EXISTS" >&2
if [ "$REMOTE_EXISTS" = "true" ]; then
    git fetch origin "$BRANCH" --quiet 2>/dev/null || true
    UNPUSHED=$(git rev-list "origin/$BRANCH..HEAD" --count 2>/dev/null || echo "0")
else
    UNPUSHED="0"
fi
echo "[nuage-debug] UNPUSHED=$UNPUSHED" >&2
echo "[nuage-debug] running gh pr list --head {expected_head_quoted}" >&2
PR_JSON=$(gh pr list --head {expected_head_quoted} --state open \\
    --json baseRefName,headRefName 2>/dev/null || echo "[]")
echo "[nuage-debug] PR_JSON=$PR_JSON" >&2

BRANCH_JSON=$(printf '%s' "$BRANCH" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')
cat <<EOF
{{
  "branch": $BRANCH_JSON,
  "dirty": $DIRTY,
  "remote_exists": $REMOTE_EXISTS,
  "unpushed": $UNPUSHED,
  "pr": $PR_JSON
}}
EOF
"""
