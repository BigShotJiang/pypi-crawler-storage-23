from __future__ import annotations

from typing import Any, ClassVar, Literal, TypedDict, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    create_model,
    model_validator,
)
from pydantic.config import JsonDict
from vibe.core.tools.builtins.ask_user_question import Answer, AskUserQuestionArgs, AskUserQuestionResult, Question

from mistralai_workflows.plugins.nuage import wait_for_input as nuage_wait_for_input
from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task

from . import vibe_patches

_OTHER_OPTION_DESCRIPTION = "Other (enter a custom answer in the field below)"


type _DynamicFieldDef = tuple[object, object]


class _OneOfOptionSchema(TypedDict, total=False):
    const: str
    description: str


class _SingleSelectSchema(TypedDict):
    oneOf: list[_OneOfOptionSchema]


class _ArrayItemsSchema(TypedDict):
    oneOf: list[_OneOfOptionSchema]


class _MultiSelectSchema(TypedDict):
    type: Literal["array"]
    items: _ArrayItemsSchema


class _QuestionFieldSpec(BaseModel):
    model_config = ConfigDict(frozen=True)

    index: int
    answer_field: str
    other_text_field: str | None
    multi_select: bool
    option_labels: tuple[str, ...]
    allow_other: bool
    other_option_value: str | None

    @property
    def allowed_values(self) -> tuple[str, ...]:
        if not self.allow_other or self.other_option_value is None:
            return self.option_labels
        return (*self.option_labels, self.other_option_value)


class _AskUserQuestionInputModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    _question_specs: ClassVar[tuple[_QuestionFieldSpec, ...]] = ()

    @model_validator(mode="after")
    def _validate_question_answers(self) -> _AskUserQuestionInputModel:
        payload = self.model_dump()

        for spec in self._question_specs:
            answer_value = payload.get(spec.answer_field)
            if spec.multi_select:
                _validate_multi_select_answer(spec, answer_value, payload)
            else:
                _validate_single_select_answer(spec, answer_value, payload)

        return self


def _resolve_other_option_value(option_labels: tuple[str, ...]) -> str:
    candidate = "__other__"
    suffix = 0
    while candidate in option_labels:
        suffix += 1
        candidate = f"__other_{suffix}__"
    return candidate


def _normalize_other_text(value: object) -> str:
    return value.strip() if isinstance(value, str) else ""


def _get_other_text(payload: dict[str, object], spec: _QuestionFieldSpec) -> str:
    if not spec.other_text_field:
        return ""
    return _normalize_other_text(payload.get(spec.other_text_field, ""))


def _require_other_text(payload: dict[str, object], spec: _QuestionFieldSpec) -> None:
    if _get_other_text(payload, spec):
        return
    raise ValueError(f"Question {spec.index + 1} requires custom text for the Other option")


def _validate_multi_select_answer(
    spec: _QuestionFieldSpec,
    answer_value: object,
    payload: dict[str, object],
) -> None:
    if not isinstance(answer_value, list) or not answer_value:
        raise ValueError(f"Question {spec.index + 1} requires at least one answer")

    selected_values = [str(value) for value in answer_value]
    invalid_values = [value for value in selected_values if value not in spec.allowed_values]
    if invalid_values:
        raise ValueError(f"Question {spec.index + 1} contains invalid options: {', '.join(invalid_values)}")

    has_other = bool(spec.allow_other and spec.other_option_value and spec.other_option_value in selected_values)
    if has_other:
        _require_other_text(payload, spec)


def _validate_single_select_answer(
    spec: _QuestionFieldSpec,
    answer_value: object,
    payload: dict[str, object],
) -> None:
    if not isinstance(answer_value, str) or not answer_value:
        raise ValueError(f"Question {spec.index + 1} requires an answer")

    if answer_value not in spec.allowed_values:
        raise ValueError(f"Question {spec.index + 1} has an invalid answer: {answer_value}")

    selected_other = bool(spec.allow_other and spec.other_option_value and answer_value == spec.other_option_value)
    if selected_other:
        _require_other_text(payload, spec)


def _build_option_schema(label: str, description: str = "") -> _OneOfOptionSchema:
    option_entry: _OneOfOptionSchema = {"const": label}
    if description:
        option_entry["description"] = description
    return option_entry


def _build_one_of_options(question: Question) -> tuple[tuple[str, ...], list[_OneOfOptionSchema]]:
    option_labels = tuple(choice.label for choice in question.options)
    one_of_options: list[_OneOfOptionSchema] = []
    for choice in question.options:
        one_of_options.append(_build_option_schema(choice.label, choice.description))
    return option_labels, one_of_options


def _build_answer_field(
    question_text: str,
    multi_select: bool,
    one_of_options: list[_OneOfOptionSchema],
) -> _DynamicFieldDef:
    if multi_select:
        multi_select_schema_extra: _MultiSelectSchema = {
            "type": "array",
            "items": {"oneOf": one_of_options},
        }
        return (
            list[str],
            Field(
                default_factory=list,
                min_length=1,
                description=question_text,
                json_schema_extra=cast(JsonDict, multi_select_schema_extra),
            ),
        )
    single_select_schema_extra: _SingleSelectSchema = {"oneOf": one_of_options}
    return (
        str,
        Field(
            description=question_text,
            json_schema_extra=cast(JsonDict, single_select_schema_extra),
        ),
    )


def _build_wait_for_input_model(
    args: AskUserQuestionArgs,
) -> tuple[type[_AskUserQuestionInputModel], tuple[_QuestionFieldSpec, ...]]:
    fields: dict[str, _DynamicFieldDef] = {}
    question_specs: list[_QuestionFieldSpec] = []

    for idx, question in enumerate(args.questions):
        answer_field = f"question_{idx}_answer"
        other_text_field: str | None = None

        option_labels, one_of_options = _build_one_of_options(question)

        allow_other = not question.hide_other
        other_option_value: str | None = None
        if allow_other:
            other_option_value = _resolve_other_option_value(option_labels)
            one_of_options.append(_build_option_schema(other_option_value, _OTHER_OPTION_DESCRIPTION))
            other_text_field = f"question_{idx}_other_text"

        fields[answer_field] = _build_answer_field(question.question, question.multi_select, one_of_options)

        if allow_other and other_text_field is not None:
            fields[other_text_field] = (
                str | None,
                Field(default=None, description=f"Custom answer for: {question.question}"),
            )

        question_specs.append(
            _QuestionFieldSpec.model_construct(
                index=idx,
                answer_field=answer_field,
                other_text_field=other_text_field,
                multi_select=question.multi_select,
                option_labels=option_labels,
                allow_other=allow_other,
                other_option_value=other_option_value,
            )
        )

    create_dynamic_model = cast(Any, create_model)
    model = cast(
        type[_AskUserQuestionInputModel],
        create_dynamic_model(
            "AskUserQuestionInput",
            __base__=_AskUserQuestionInputModel,
            __config__=ConfigDict(extra="forbid", title="AskUserQuestionInput"),
            **fields,
        ),
    )
    model._question_specs = tuple(question_specs)
    return model, tuple(question_specs)


def _render_multi_select_answer(
    spec: _QuestionFieldSpec,
    payload: dict[str, object],
    answer_value: object,
) -> tuple[str, bool]:
    selected_values = [str(value) for value in cast(list[object], answer_value or [])]
    rendered_values: list[str] = []
    is_other = False

    for selected in selected_values:
        if spec.allow_other and spec.other_option_value and selected == spec.other_option_value:
            rendered_values.append(_get_other_text(payload, spec))
            is_other = True
            continue
        rendered_values.append(selected)

    return ", ".join(rendered_values), is_other


def _render_single_select_answer(
    spec: _QuestionFieldSpec,
    payload: dict[str, object],
    answer_value: object,
) -> tuple[str, bool]:
    selected_value = str(answer_value)
    if spec.allow_other and spec.other_option_value and selected_value == spec.other_option_value:
        return _get_other_text(payload, spec), True
    return selected_value, selected_value not in spec.option_labels


def _to_tool_result(
    args: AskUserQuestionArgs,
    question_specs: tuple[_QuestionFieldSpec, ...],
    payload: dict[str, object],
) -> AskUserQuestionResult:
    answers: list[Answer] = []

    for spec in question_specs:
        question = args.questions[spec.index]
        answer_value = payload.get(spec.answer_field)

        if spec.multi_select:
            rendered_answer, is_other = _render_multi_select_answer(spec, payload, answer_value)
            answers.append(
                Answer(
                    question=question.question,
                    answer=rendered_answer,
                    is_other=is_other,
                )
            )
            continue

        rendered_answer, is_other = _render_single_select_answer(spec, payload, answer_value)
        answers.append(
            Answer(
                question=question.question,
                answer=rendered_answer,
                is_other=is_other,
            )
        )

    return AskUserQuestionResult(answers=answers, cancelled=False)


class VibeWaitForInputHook(nuage_agent_executor.AgentExecutorHook):
    workflow_task: nuage_agent_task.WorkflowTask

    async def invoke_tool(self, request: Any) -> Any:
        if not isinstance(request, vibe_patches.ProxyInvokeToolRequest):
            return await self.next.invoke_tool(request)

        if request.tool_name != "ask_user_question":
            return await self.next.invoke_tool(request)

        try:
            wait_for_input_callback = nuage_wait_for_input.WorkflowWaitForInputContext.get_wait_for_input()
        except RuntimeError:
            return vibe_patches.ProxyInvokeToolResponse(
                error="ask_user_question bridge runtime context is not set",
                tool_state=request.tool_state,
            )

        workflow_task = self.workflow_task
        async with workflow_task.tool_call:
            await workflow_task.tool_call.set_state(
                nuage_agent_models.AgentToolCallState(name=request.tool_name, kwargs=request.tool_kwargs)
            )

            try:
                args = AskUserQuestionArgs.model_validate(request.tool_kwargs)
                input_model, specs = _build_wait_for_input_model(args)
                user_input = await wait_for_input_callback(input_model, "ask_user_question")
                result = _to_tool_result(args, specs, user_input.model_dump())
                result_payload = result.model_dump()
                await workflow_task.tool_call.set_state(
                    nuage_agent_models.AgentToolCallState(
                        name=request.tool_name,
                        kwargs=request.tool_kwargs,
                        output=result_payload,
                    )
                )
                return vibe_patches.ProxyInvokeToolResponse(
                    tool_result=result_payload,
                    tool_state=request.tool_state,
                )
            except ValidationError as exc:
                error_msg = f"Invalid ask_user_question arguments: {exc}"
            except Exception as exc:
                error_msg = f"Failed ask_user_question wait_for_input flow: {exc}"

            await workflow_task.tool_call.set_state(
                nuage_agent_models.AgentToolCallState(
                    name=request.tool_name,
                    kwargs=request.tool_kwargs,
                    output={"error": error_msg},
                )
            )
            return vibe_patches.ProxyInvokeToolResponse(error=error_msg, tool_state=request.tool_state)
