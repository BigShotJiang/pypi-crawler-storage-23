from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel, Field

from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base


class ChatAssistantParams(nuage_integrations_base.BaseIntegrationParams):
    requires_secrets: ClassVar[bool] = False

    user_message: str | None = Field(default=None, description="User message for the chat")
    project_name: str | None = Field(default=None, description="Optional project name")


LeChatParams = ChatAssistantParams


class ChatAssistantPublicData(BaseModel):
    chat_url: str = Field(description="URL to the created chat thread")


class ChatAssistantIntegration(nuage_integrations_base.BaseIntegration[ChatAssistantPublicData]):
    pass


class CreateChatAssistantThreadParams(BaseModel):
    identity: nuage_experimental_identity.ExperimentalIdentity
    user_message: str
    chat_title: str
    workflow_version_id: str
    workflow_execution_id: str
    workflow_name: str
    workflow_params: dict[str, object]
    project_name: str | None = "Nuage"


class CreateChatAssistantThreadResult(BaseModel):
    chat_url: str


class ToolFormat(BaseModel):
    title: str
    content: str
