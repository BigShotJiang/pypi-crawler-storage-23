from __future__ import annotations

from typing import Annotated, Any, Union

from mistralai_workflows.core.config.config import PayloadEncryptionMode, config
from mistralai_workflows.models import EncryptedStrField
from pydantic import PlainValidator


def _validate_env_value(v: Any) -> str | EncryptedStrField:
    if isinstance(v, str):
        return v
    if isinstance(v, EncryptedStrField):
        return v
    if isinstance(v, dict) and v.get("field_type") == "__encrypted_str__":
        return EncryptedStrField.model_validate(v)
    raise TypeError(f"Invalid env value type: {type(v).__name__}")


EnvValue = Annotated[Union[str, EncryptedStrField], PlainValidator(_validate_env_value)]
EnvDict = dict[str, EnvValue]


def convert_env_to_dict(env: EnvDict | None) -> dict[str, str]:
    if env is None:
        return {}
    result: dict[str, str] = {}
    for key, value in env.items():
        if isinstance(value, EncryptedStrField):
            result[key] = value.data
        else:
            result[key] = value
    return result


def validate_payload_encryption() -> None:
    encryption_config = config.worker.temporal_payload_encryption
    if encryption_config.mode == PayloadEncryptionMode.NONE:
        raise ValueError(
            "MODE must be set to 'partial' or 'full'. Nuage workflows require payload encryption for security."
        )
    if not encryption_config.main_key or not encryption_config.main_key.get_secret_value():
        raise ValueError("MAIN_KEY must be set. Generate a 32-byte hex key: openssl rand -hex 32")
