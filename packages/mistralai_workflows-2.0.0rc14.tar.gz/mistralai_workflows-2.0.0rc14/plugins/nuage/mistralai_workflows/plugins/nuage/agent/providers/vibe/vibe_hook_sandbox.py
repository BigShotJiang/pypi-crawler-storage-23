from __future__ import annotations

import asyncio
from contextlib import suppress
from typing import Unpack

import structlog

import mistralai_workflows as workflows
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models
from mistralai_workflows.plugins.nuage.sandbox import sandbox_utils as nuage_sandbox_utils
from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import demiurge_constants as nuage_demiurge_constants

from . import vibe_invoke_tool_in_sandbox

logger = structlog.get_logger(__name__)


@workflows.activity()
async def warmup_vibe_sandbox(sandbox: nuage_sandbox.Sandbox) -> None:
    try:
        await sandbox.execute_python(
            **nuage_sandbox_utils.build_execute_python_kwargs(
                func=vibe_invoke_tool_in_sandbox.warmup_invoke_tool_in_sandbox,
                cwd=nuage_demiurge_constants.DEFAULT_WORKSPACE,
            )
        )
        logger.info("Completed vibe sandbox warmup")
    except asyncio.CancelledError:
        logger.info("Cancelled vibe sandbox warmup")
    except Exception as e:
        logger.warning("Failed vibe sandbox warmup", error=str(e))


class VibeSandboxHook(nuage_sandbox.SandboxHook):
    _warmup_task: asyncio.Task[None] | None = None

    def _start_warmup(self) -> None:
        if self._warmup_task and not self._warmup_task.done():
            return
        self._warmup_task = asyncio.create_task(warmup_vibe_sandbox(self.next))

    async def create_sandbox(
        self, **kwargs: Unpack[nuage_sandbox_models.CreateSandboxKwargs]
    ) -> nuage_sandbox_models.SandboxResult:
        override_env = {
            "PROD_MISTRAL_API_KEY": "not-used-in-sandbox-but-need-to-be-defined-for-vibe",
            "MISTRAL_API_KEY": "not-used-in-sandbox-but-need-to-be-defined-for-vibe",
        }
        kwargs["env"] = {**(kwargs.get("env") or {}), **override_env}

        result = await self.next.create_sandbox(**kwargs)
        self._start_warmup()
        return result

    async def delete_sandbox(self) -> None:
        if self._warmup_task:
            warmup_task = self._warmup_task
            self._warmup_task = None
            with suppress(asyncio.CancelledError, Exception):
                warmup_task.cancel()
                await warmup_task
        await self.next.delete_sandbox()
