GIT_USER_NAME = "Vibe Nuage Agent"
GIT_USER_EMAIL = "vibe@mistral.ai"
