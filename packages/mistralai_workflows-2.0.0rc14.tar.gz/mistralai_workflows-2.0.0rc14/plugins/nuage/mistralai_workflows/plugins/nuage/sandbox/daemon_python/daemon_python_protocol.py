from __future__ import annotations

import json
from typing import Any

from mistralai_workflows.plugins.nuage import redact as nuage_redact
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models

from . import daemon_python_commands, daemon_python_sandbox_script


async def is_daemon_down(sandbox: nuage_sandbox.Sandbox) -> bool:
    cmd = daemon_python_commands.build_check_ready_cmd()
    try:
        result = await sandbox.execute(command=cmd, timeout=5, skip_redact=True)
        return result.stdout.strip() != "ok"
    except Exception:
        return True


def build_send_runtime_error(details: str, diagnostics: str) -> RuntimeError:
    return RuntimeError(f"daemon_python_send failed: {details}\n\nDiagnostics:\n{diagnostics}")


async def send_code_to_daemon(
    sandbox: nuage_sandbox.Sandbox,
    code: str,
    cwd: str | None,
    env: dict[str, str] | None,
    timeout: int,
) -> nuage_sandbox_models.SandboxExecuteResult:
    cmd = daemon_python_commands.build_send_code_cmd(code, cwd=cwd, env=env, timeout=timeout)
    return await sandbox.execute(command=cmd, timeout=timeout + 3, skip_redact=True)


def build_function_invocation_code(
    function_source: str,
    function_name: str,
    kwargs: dict | None = None,
    is_async: bool = False,
) -> str:
    kwargs_json = json.dumps(kwargs or {})
    result_var = daemon_python_sandbox_script.DAEMON_RESULT_VAR
    if is_async:
        run_code = f"{result_var} = __import__('asyncio').run({function_name}(**__kwargs__))"
    else:
        run_code = f"{result_var} = {function_name}(**__kwargs__)"

    return f"""\
import json
{function_source}
__kwargs__ = json.loads({kwargs_json!r})
{run_code}
"""


def parse_result(stdout: str, execution_time: float = 0.0) -> nuage_sandbox_models.SandboxPythonExecuteResult:
    try:
        resp = json.loads(stdout)
    except json.JSONDecodeError as e:
        raise build_error(stdout=stdout, error_class=ValueError) from e

    if not resp.get("ok"):
        err = resp.get("error", {})
        msg = err.get("message", "Unknown error") if isinstance(err, dict) else str(err or "Unknown error")
        tb = err.get("traceback") if isinstance(err, dict) else None
        raise build_error(msg=msg, traceback=tb)

    return nuage_sandbox_models.SandboxPythonExecuteResult(
        result=resp.get("result"),
        stdout=resp.get("stdout", ""),
        stderr=resp.get("stderr", ""),
        exit_code=0,
        execution_time=execution_time,
    )


def build_error(
    msg: str | None = None,
    stdout: str | None = None,
    stderr: str | None = None,
    traceback: str | None = None,
    error_class: type[Exception] = RuntimeError,
) -> Exception:
    if msg is None:
        parts = []
        if stderr:
            parts.append(f"Stderr: {stderr}")
        if stdout:
            parts.append(f"Stdout: {stdout}")
        msg = "\n".join(parts) or "Unknown error"
    err = error_class(msg)
    if traceback:
        err.__notes__ = [f"Remote traceback:\n{traceback}"]
    return err


def redact_result(result: Any) -> Any:
    if result is None:
        return None
    if isinstance(result, str):
        return nuage_redact.redact(result)
    if isinstance(result, dict):
        return {k: redact_result(v) for k, v in result.items()}
    if isinstance(result, list):
        return [redact_result(v) for v in result]
    return result
