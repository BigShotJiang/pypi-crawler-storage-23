from __future__ import annotations

from . import chat_assistant_models


def _get_title(tool_name: str) -> str:
    if tool_name == "write_file":
        return "Writing file"
    return "Reading file"


def _get_content(tool_name: str, tool_kwargs: dict[str, object], tool_result: dict[str, object] | None) -> str:
    path = str(tool_kwargs.get("path", ""))
    header = f"# {path}\n\n" if path else ""

    if tool_name == "write_file":
        return f"{header}{tool_kwargs.get('content', '')}"

    if tool_result is None:
        return header.rstrip()
    if "error" in tool_result:
        return f"{header}Error: {tool_result['error']}"
    return f"{header}{tool_result.get('content', '')}"


def format_tool(
    tool_name: str, tool_kwargs: dict[str, object], tool_result: dict[str, object] | None
) -> chat_assistant_models.ToolFormat:
    return chat_assistant_models.ToolFormat(
        title=_get_title(tool_name), content=_get_content(tool_name, tool_kwargs, tool_result)
    )
