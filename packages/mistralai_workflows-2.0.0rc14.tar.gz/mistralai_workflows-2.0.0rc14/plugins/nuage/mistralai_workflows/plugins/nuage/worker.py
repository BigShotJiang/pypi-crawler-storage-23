import asyncio

import mistralai_workflows as workflows
from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets
from mistralai_workflows.plugins.nuage.workflow import workflow as nuage_workflow


async def main() -> None:
    nuage_env_secrets.validate_payload_encryption()
    await workflows.run_worker([nuage_workflow.NuageSandboxWorkflow])


if __name__ == "__main__":
    asyncio.run(main())
