from __future__ import annotations

import hashlib
from typing import Callable

from mistralai_workflows.models import EncryptedStrField

from mistralai_workflows.plugins.nuage import utils as nuage_utils
from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox

from . import github_activities, github_hooks, github_models, github_settings


async def _wait_for_github_token(
    identity: nuage_experimental_identity.ExperimentalIdentity,
) -> EncryptedStrField:
    settings = github_settings.settings
    return await nuage_utils.poll_until(
        fetch=lambda: github_activities.github_fetch_token(identity),
        timeout_seconds=settings.token_poll_timeout_seconds,
        interval_seconds=settings.token_poll_interval_seconds,
    )


def _build_integration(
    params: github_models.GitHubParams,
    sandbox: nuage_sandbox.Sandbox,
    working_branch: str,
    status: github_models.GitHubStatus,
    github_token: EncryptedStrField | None = None,
    oauth_url: str | None = None,
    error: str | None = None,
) -> github_models.GitHubIntegration:
    config = github_models.GitHubConfig(
        **params.model_dump(),
        working_branch=working_branch,
        github_token=github_token,
    )
    return github_models.GitHubIntegration(
        sandbox=github_hooks.GitHubSandboxHook(config=config),
        agent_session=github_hooks.GitHubSessionHook(config=config, raw_sandbox=sandbox),
        public_data=github_models.GitHubPublicData(
            status=status,
            oauth_url=oauth_url,
            error=error,
            working_branch=working_branch,
            repo_url=params.url,
        ),
    )


async def build_github_integration(
    params: github_models.GitHubParams,
    sandbox: nuage_sandbox.Sandbox,
    identity: nuage_experimental_identity.ExperimentalIdentity | None,
    workflow_id: str | None = None,
    on_ready: Callable[[github_models.GitHubIntegration], None] = lambda _: None,
) -> github_models.GitHubIntegration:
    digest = hashlib.sha256((workflow_id or "unknown").encode()).hexdigest()[:12]
    working_branch = f"vibe/{digest}"

    if not identity:
        return _build_integration(
            params,
            sandbox,
            working_branch,
            status=github_models.GitHubStatus.ERROR,
            error="No identity provided",
        )

    github_token = await github_activities.github_fetch_token(identity)
    if github_token:
        return _build_integration(
            params,
            sandbox,
            working_branch,
            status=github_models.GitHubStatus.CONNECTED,
            github_token=github_token,
        )

    oauth_url = await github_activities.github_fetch_oauth_url(identity)

    on_ready(
        _build_integration(
            params,
            sandbox,
            working_branch,
            status=github_models.GitHubStatus.WAITING_FOR_OAUTH,
            oauth_url=oauth_url,
        )
    )

    try:
        github_token = await _wait_for_github_token(identity)
    except nuage_utils.PollTimeout:
        return _build_integration(
            params,
            sandbox,
            working_branch,
            status=github_models.GitHubStatus.OAUTH_TIMEOUT,
            error="Timed out waiting for GitHub authorization",
        )

    return _build_integration(
        params,
        sandbox,
        working_branch,
        status=github_models.GitHubStatus.CONNECTED,
        github_token=github_token,
    )
