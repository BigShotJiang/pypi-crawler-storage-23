from __future__ import annotations

from enum import Enum
from typing import ClassVar, Generic, TypeVar

from pydantic import BaseModel

from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox

PublicDataT = TypeVar("PublicDataT", bound=BaseModel)


class IntegrationId(str, Enum):
    GITHUB = "github"
    CHAT_ASSISTANT = "chat_assistant"

    @classmethod
    def _missing_(cls, value: object) -> IntegrationId | None:
        if not isinstance(value, str):
            return None

        normalized = value.strip().lower()
        if normalized == "lechat":
            return cls.CHAT_ASSISTANT
        return None


class IntegrationHooks(BaseModel):
    sandbox: nuage_sandbox.SandboxHook | None = None
    agent_session: nuage_agent_session.SessionHook | None = None
    workflow_task: nuage_agent_task.WorkflowTaskHook | None = None
    agent_executor: nuage_agent_executor.AgentExecutorHook | None = None


class BaseIntegration(IntegrationHooks, Generic[PublicDataT]):
    public_data: PublicDataT


class BaseIntegrationParams(BaseModel):
    requires_secrets: ClassVar[bool] = False


class IntegrationsParams(BaseModel):
    def requires_secrets(self) -> bool:
        return any(
            getattr(type(v), "requires_secrets", False)
            for v in (getattr(self, f) for f in self.model_fields)
            if v is not None
        )


def merge_hooks(*hooks_list: IntegrationHooks | None) -> IntegrationHooks:
    sandboxes: list[nuage_sandbox.SandboxHook] = []
    sessions: list[nuage_agent_session.SessionHook] = []
    workflow_tasks: list[nuage_agent_task.WorkflowTaskHook] = []
    agent_executors: list[nuage_agent_executor.AgentExecutorHook] = []

    for hooks in hooks_list:
        if hooks is None:
            continue
        if hooks.sandbox:
            sandboxes.append(hooks.sandbox)
        if hooks.agent_session:
            sessions.append(hooks.agent_session)
        if hooks.workflow_task:
            workflow_tasks.append(hooks.workflow_task)
        if hooks.agent_executor:
            agent_executors.append(hooks.agent_executor)

    return IntegrationHooks(
        sandbox=nuage_hook.chain_hooks(sandboxes),
        agent_session=nuage_hook.chain_hooks(sessions),
        workflow_task=nuage_hook.chain_hooks(workflow_tasks),
        agent_executor=nuage_hook.chain_hooks(agent_executors),
    )
