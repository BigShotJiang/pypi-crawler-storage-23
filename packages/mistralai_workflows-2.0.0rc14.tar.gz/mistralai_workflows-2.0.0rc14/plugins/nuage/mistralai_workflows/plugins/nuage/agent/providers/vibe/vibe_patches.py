# TEMPORARY: This file contains monkey-patches for vibe internals.
# It will be deleted once vibe has a more modular approach to delegate executions.
from __future__ import annotations

import asyncio
import contextvars
import importlib
from collections.abc import AsyncGenerator, Awaitable, Callable
from pathlib import Path
from types import MethodType
from typing import Any, Iterator

import structlog
from pydantic import BaseModel
from vibe.core.agent_loop import AgentLoop
from vibe.core.config import Backend, ModelConfig, ProviderConfig, VibeConfig
from vibe.core.tools import mcp
from vibe.core.tools.base import BaseTool, InvokeContext
from vibe.core.tools.manager import ToolManager
from vibe.core.tools.mcp import RemoteTool, ToolError
from vibe.core.types import AvailableTool, LLMChunk, LLMMessage, StrToolChoice, ToolStreamEvent

from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor

_deferred_tasks: contextvars.ContextVar[list[Callable[[], Awaitable[Any]]] | None] = contextvars.ContextVar(
    "deferred_tasks", default=None
)


def defer_task(task_factory: Callable[[], Awaitable[Any]]) -> None:
    tasks = _deferred_tasks.get() or []
    tasks.append(task_factory)
    _deferred_tasks.set(tasks)


async def await_deferred_tasks() -> None:
    factories = _deferred_tasks.get() or []
    _deferred_tasks.set([])
    await asyncio.gather(*(factory() for factory in factories))


class BackendInitKwargs(BaseModel):
    provider: ProviderConfig
    timeout: float = 720.0


class CompleteKwargs(BaseModel):
    model: ModelConfig
    messages: list[LLMMessage]
    temperature: float
    tools: list[AvailableTool] | None
    max_tokens: int | None
    tool_choice: StrToolChoice | AvailableTool | None
    extra_headers: dict[str, str] | None


class CountTokensKwargs(BaseModel):
    model: ModelConfig
    messages: list[LLMMessage]
    temperature: float = 0.0
    tools: list[AvailableTool] | None = None
    tool_choice: StrToolChoice | AvailableTool | None = None
    extra_headers: dict[str, str] | None = None


METHOD_KWARGS_MODELS: dict[str, type[BaseModel]] = {
    "complete": CompleteKwargs,
    "complete_streaming": CompleteKwargs,
    "count_tokens": CountTokensKwargs,
}


class BackendProxyRequest(BaseModel):
    method: str
    backend: Backend
    init_kwargs: dict[str, object]
    call_kwargs: dict[str, object]


class BackendProxyResponse(BaseModel):
    result: LLMChunk | list[LLMChunk] | int


class ProxyListMcpToolsHTTPRequest(BaseModel):
    url: str
    headers: dict[str, str] | None = None


class ProxyListMcpToolsSTDIORequest(BaseModel):
    command: list[str]


class ProxyListMcpToolsResponse(BaseModel):
    tools: list[dict[str, object]]


class ProxyComputeSearchPathsRequest(BaseModel):
    config: VibeConfig


class ProxyComputeSearchPathsResponse(BaseModel):
    paths: list[str]


class ProxyIterToolClassesRequest(BaseModel):
    search_paths: list[str]


class SerializedTool(BaseModel):
    name: str
    description: str
    parameters: dict[str, object]
    class_name: str
    module_path: str


class ProxyIterToolClassesResponse(BaseModel):
    tools: list[SerializedTool]


class ProxyInvokeToolRequest(BaseModel):
    tool_name: str
    tool_call_id: str
    tool_kwargs: dict[str, object]
    tool_state: object
    config: VibeConfig


class ProxyInvokeToolResponse(BaseModel):
    tool_result: dict[str, Any] | None = None
    tool_state: object = None
    error: str | None = None


logger = structlog.get_logger(__name__)


def _serialize_kwargs(raw: dict[str, Any]) -> dict[str, object]:
    return {k: v.model_dump() if isinstance(v, BaseModel) else v for k, v in raw.items()}


def _serialize_state(state: Any) -> object:
    return state.model_dump() if isinstance(state, BaseModel) else state


def _deserialize_state(state_data: object, state_class: type) -> Any:
    if issubclass(state_class, BaseModel):
        return state_class.model_validate(state_data)
    return state_data


def _deserialize_tools(tool_dicts: list[dict[str, object]]) -> list[RemoteTool]:
    tools: list[RemoteTool] = []
    for tool_dict in tool_dicts:
        try:
            tools.append(RemoteTool.model_validate(tool_dict))
        except Exception as e:
            logger.warning("Failed to validate MCP tool", error=str(e), tool=tool_dict.get("name", "unknown"))
    return tools


def _get_tool_class(serialized: SerializedTool) -> type[BaseTool[Any, Any, Any, Any]]:
    module = importlib.import_module(serialized.module_path)
    return getattr(module, serialized.class_name)  # type: ignore[no-any-return]


class BackendPatch:
    def __init__(self, agent_executor: nuage_agent_executor.AgentExecutor, config: VibeConfig) -> None:
        self._executor = agent_executor
        provider = config.get_provider_for_model(config.get_active_model())
        self._backend_type = provider.backend
        self._init_kwargs: dict[str, object] = {"provider": provider, "timeout": config.api_timeout}

    async def _call(self, method: str, **kwargs: Any) -> Any:
        request = BackendProxyRequest(
            backend=self._backend_type,
            init_kwargs=self._init_kwargs,
            method=method,
            call_kwargs=kwargs,
        )
        response = await self._executor.complete(request)
        return response.result

    async def complete(self, **kwargs: Any) -> Any:
        return await self._call("complete", **kwargs)

    async def complete_streaming(self, **kwargs: Any) -> AsyncGenerator[Any, None]:
        yield await self._call("complete_streaming", **kwargs)

    async def count_tokens(self, **kwargs: Any) -> Any:
        return await self._call("count_tokens", **kwargs)

    def apply(self, backend: Any) -> None:
        backend.complete = MethodType(lambda _, **kw: self.complete(**kw), backend)
        backend.complete_streaming = MethodType(lambda _, **kw: self.complete_streaming(**kw), backend)
        backend.count_tokens = MethodType(lambda _, **kw: self.count_tokens(**kw), backend)


class ToolInvoker:
    def __init__(
        self,
        vibe_config: VibeConfig,
        agent_executor: nuage_agent_executor.AgentExecutor,
    ) -> None:
        self._config = vibe_config
        self._executor = agent_executor

    async def invoke(
        self, tool: BaseTool[Any, Any, Any, Any], ctx: InvokeContext | None = None, **raw: Any
    ) -> AsyncGenerator[ToolStreamEvent | Any, None]:
        _, result_model = tool._get_tool_args_results()

        try:
            response = await self._executor.invoke_tool(
                ProxyInvokeToolRequest(
                    config=self._config,
                    tool_name=tool.get_name(),
                    tool_call_id=ctx.tool_call_id if ctx else "",
                    tool_kwargs=_serialize_kwargs(raw),
                    tool_state=_serialize_state(tool.state),
                )
            )
            if response.tool_state is not None:
                tool.state = _deserialize_state(response.tool_state, type(tool.state))
            if response.error:
                raise ToolError(response.error)
            yield result_model.model_validate(response.tool_result)
        except ToolError:
            raise
        except Exception as e:
            cause = e.__cause__ if e.__cause__ else e
            raise ToolError(str(cause)) from e


class ToolManagerPatch:
    def __init__(
        self,
        tool_manager: ToolManager,
        agent_executor: nuage_agent_executor.AgentExecutor,
    ) -> None:
        self._manager = tool_manager
        self._executor = agent_executor
        self._invoker = ToolInvoker(tool_manager._config, agent_executor)

    def get(self, tool_name: str) -> BaseTool[Any, Any, Any, Any]:
        tool_cls = self._manager._available.get(tool_name)
        if tool_cls is None:
            raise KeyError(f"Tool '{tool_name}' not found")
        tool = tool_cls.from_config(self._manager.get_tool_config(tool_name))
        tool.invoke = MethodType(self._make_invoke(), tool)
        return tool

    def _make_invoke(self) -> Any:
        invoker = self._invoker

        async def invoke(
            self: BaseTool[Any, Any, Any, Any], ctx: InvokeContext | None = None, **raw: Any
        ) -> AsyncGenerator[ToolStreamEvent | Any, None]:
            async for item in invoker.invoke(self, ctx, **raw):
                yield item

        return invoke

    def compute_search_paths(self, config: VibeConfig) -> list[Path]:
        return []

    def iter_tool_classes(self, search_paths: list[Path]) -> Iterator[type[BaseTool[Any, Any, Any, Any]]]:
        return iter([])

    def integrate_mcp(self) -> None:
        defer_task(self._setup_mcp)

    async def _setup_mcp(self) -> None:
        response = await self._executor.compute_search_paths(
            ProxyComputeSearchPathsRequest(config=self._manager._config)
        )
        self._manager._search_paths = [Path(p) for p in response.paths]

        tools_response = await self._executor.iter_tool_classes(
            ProxyIterToolClassesRequest(search_paths=response.paths)
        )
        for tool in tools_response.tools:
            tool_class = _get_tool_class(tool)
            self._manager._available[tool_class.get_name()] = tool_class

        if self._manager._config.mcp_servers:
            await self._manager._integrate_mcp_async()

    async def register_http_server(self, srv: Any) -> int:
        url = (srv.url or "").strip()
        if not url:
            logger.warning("MCP server '%s' missing url for http transport", srv.name)
            return 0
        try:
            req = ProxyListMcpToolsHTTPRequest(url=url, headers=srv.http_headers())
            resp = await self._executor.list_tools_http(req)
        except Exception as exc:
            logger.warning("MCP HTTP discovery failed for %s: %s", url, exc)
            return 0
        return await self._register_mcp_server(srv, "http", url, resp)

    async def register_stdio_server(self, srv: Any) -> int:
        cmd = srv.argv()
        if not cmd:
            logger.warning("MCP stdio server '%s' has invalid/empty command", srv.name)
            return 0
        try:
            resp = await self._executor.list_tools_stdio(ProxyListMcpToolsSTDIORequest(command=cmd))
        except Exception as exc:
            logger.warning("MCP stdio discovery failed for %r: %s", cmd, exc)
            return 0
        return await self._register_mcp_server(srv, "stdio", cmd, resp)

    async def _register_mcp_server(
        self, srv: Any, transport: str, identifier: str | list[str], tools_response: Any
    ) -> int:
        added = 0
        for remote in _deserialize_tools(tools_response.tools):
            try:
                if transport == "http" and isinstance(identifier, str):
                    proxy_cls = mcp.create_mcp_http_proxy_tool_class(
                        url=identifier,
                        remote=remote,
                        alias=srv.name,
                        server_hint=srv.prompt,
                        headers=srv.http_headers(),
                        startup_timeout_sec=srv.startup_timeout_sec,
                        tool_timeout_sec=srv.tool_timeout_sec,
                    )
                elif isinstance(identifier, list):
                    proxy_cls = mcp.create_mcp_stdio_proxy_tool_class(
                        command=identifier,
                        remote=remote,
                        alias=srv.name,
                        server_hint=srv.prompt,
                        env=srv.env or None,
                        startup_timeout_sec=srv.startup_timeout_sec,
                        tool_timeout_sec=srv.tool_timeout_sec,
                    )
                else:
                    continue
                self._manager._available[proxy_cls.get_name()] = proxy_cls
                added += 1
            except Exception as exc:
                logger.warning("Failed to register MCP %s tool '%s': %r", transport, getattr(remote, "name", "?"), exc)
        return added

    def apply(self) -> None:
        tm = self._manager
        tm._compute_search_paths = MethodType(lambda _, c: self.compute_search_paths(c), tm)
        tm._iter_tool_classes = MethodType(lambda _, p: self.iter_tool_classes(p), tm)
        tm._integrate_mcp = MethodType(lambda _: self.integrate_mcp(), tm)
        tm.get = MethodType(lambda _, n: self.get(n), tm)
        tm._register_http_server = MethodType(lambda _, s: self.register_http_server(s), tm)
        tm._register_stdio_server = MethodType(lambda _, s: self.register_stdio_server(s), tm)


def _patch_agent_loop(loop: AgentLoop) -> None:
    original_act = loop.act

    async def patched_act(msg: str) -> AsyncGenerator[Any, None]:
        await await_deferred_tasks()
        async for event in original_act(msg):
            yield event

    loop.act = MethodType(lambda _, m: patched_act(m), loop)


def patch_vibe_loop(
    loop: AgentLoop,
    agent_executor: nuage_agent_executor.AgentExecutor,
) -> None:
    BackendPatch(agent_executor, loop.config).apply(loop.backend)
    ToolManagerPatch(loop.tool_manager, agent_executor).apply()
    _patch_agent_loop(loop)
