from __future__ import annotations

import mistralai_workflows.plugins.mistralai as workflows_mistralai
from mistralai_workflows.plugins.mistralai.lechat import _AssistantMessageState as AssistantMessageState
from pydantic import Field

from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task

from . import chat_assistant_models, chat_assistant_tool_format_bash, chat_assistant_tool_format_file


def _format_tool(
    tool_name: str, tool_kwargs: dict[str, object], tool_result: dict[str, object] | None
) -> chat_assistant_models.ToolFormat:
    if tool_name == "bash":
        return chat_assistant_tool_format_bash.format_tool(tool_name, tool_kwargs, tool_result)
    if tool_name in ("read_file", "write_file"):
        return chat_assistant_tool_format_file.format_tool(tool_name, tool_kwargs, tool_result)

    title = _get_default_title(tool_name)
    content = _get_default_content(tool_name, tool_kwargs, tool_result)
    return chat_assistant_models.ToolFormat(title=title, content=content)


def _get_default_title(tool_name: str) -> str:
    if tool_name == "grep":
        return "Searching files"
    if tool_name == "search_replace":
        return "Editing file"
    if tool_name == "task":
        return "Running subagent"
    return f"Executing {tool_name}"


def _get_default_content(tool_name: str, tool_kwargs: dict[str, object], tool_result: dict[str, object] | None) -> str:
    if tool_name == "search_replace":
        return str(tool_kwargs.get("content", ""))
    if tool_result is None:
        return ""
    if "error" in tool_result:
        return f"Error: {tool_result['error']}"
    if tool_name == "grep":
        return str(tool_result.get("matches", ""))
    return ""


class ChatAssistantCompletionTaskHook(
    nuage_agent_task.MappingAgentTaskHook[nuage_agent_models.AgentCompletionState, AssistantMessageState]
):
    def _map_state(self, state: nuage_agent_models.AgentCompletionState) -> AssistantMessageState | None:
        if not state.content.strip():
            return None
        return AssistantMessageState(contentChunks=[workflows_mistralai.TextOutput(text=state.content)])


class ChatAssistantToolCallTaskHook(
    nuage_agent_task.MappingAgentTaskHook[
        nuage_agent_models.AgentToolCallState, workflows_mistralai.ChatAssistantWorkingTask
    ]
):
    def _map_state(self, state: nuage_agent_models.AgentToolCallState) -> workflows_mistralai.ChatAssistantWorkingTask:
        fmt = _format_tool(state.name, state.kwargs, state.output)
        return workflows_mistralai.ChatAssistantWorkingTask(type="tool", title=fmt.title, content=fmt.content)


class ChatAssistantStartupTaskHook(
    nuage_agent_task.MappingAgentTaskHook[
        nuage_agent_models.AgentStartupState, workflows_mistralai.ChatAssistantWorkingTask
    ]
):
    def _map_state(self, state: nuage_agent_models.AgentStartupState) -> workflows_mistralai.ChatAssistantWorkingTask:
        return workflows_mistralai.ChatAssistantWorkingTask(type="tool", title="Creating sandbox", content=state.step)


class ChatAssistantWorkflowTaskHook(nuage_agent_task.WorkflowTaskHook):
    completion: nuage_agent_task.AgentTask[nuage_agent_models.AgentCompletionState] = Field(
        default_factory=ChatAssistantCompletionTaskHook
    )
    tool_call: nuage_agent_task.AgentTask[nuage_agent_models.AgentToolCallState] = Field(
        default_factory=ChatAssistantToolCallTaskHook
    )
    startup: nuage_agent_task.AgentTask[nuage_agent_models.AgentStartupState] = Field(
        default_factory=ChatAssistantStartupTaskHook
    )
