from __future__ import annotations

import structlog

from mistralai_workflows.plugins.nuage import settings as nuage_settings
from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.workflow import workflow_models as nuage_workflow_models

logger = structlog.get_logger(__name__)

EXPERIMENTAL_IDENTITY_ATTRIBUTE_NAME = "__internal_experimental_identity"


def _get_mock_identity() -> nuage_experimental_identity.ExperimentalIdentity | None:
    mock_settings = nuage_settings.settings.mock_identity
    if not mock_settings.enabled or not mock_settings.customer_id:
        return None
    return nuage_experimental_identity.ExperimentalIdentity(
        version=1,
        customer_id=mock_settings.customer_id,
        user_id=mock_settings.user_id,
        workspace_id=mock_settings.workspace_id,
        organization_id=mock_settings.organization_id,
    )


def experimental_extract_identity(
    params: nuage_workflow_models.NuageWorkflowParams,
) -> nuage_experimental_identity.ExperimentalIdentity | None:
    extra = params.extra_fields
    raw_identity = extra.get(EXPERIMENTAL_IDENTITY_ATTRIBUTE_NAME)
    if raw_identity is None:
        mock_identity = _get_mock_identity()
        if mock_identity:
            logger.debug("[EXPERIMENTAL:INJECT_IDENTITY] No identity found, using mock identity")
            return mock_identity
        logger.debug("[EXPERIMENTAL:INJECT_IDENTITY] No identity found in workflow params")
        return None

    try:
        identity = nuage_experimental_identity.ExperimentalIdentity.model_validate(raw_identity)
        logger.debug("[EXPERIMENTAL:INJECT_IDENTITY] Extracted identity", identity=identity.model_dump())
        return identity
    except Exception as e:
        logger.warning("[EXPERIMENTAL:INJECT_IDENTITY] Failed to validate identity", error=str(e))
        return None
