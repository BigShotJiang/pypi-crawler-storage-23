from __future__ import annotations

from typing import Any, cast

from pydantic import Field

from . import polymorphic


class Hook[N: polymorphic.PolymorphicModel](polymorphic.PolymorphicModel):
    next_hook: N | None = Field(default=None)

    @property
    def next(self) -> N:
        if self.next_hook is None:
            raise RuntimeError("Hook not chained")
        return self.next_hook

    @property
    def origin(self) -> N:
        current: Any = self
        while isinstance(current, Hook) and current.next_hook is not None:
            current = current.next_hook
        return cast(N, current)

    def attach_to(self, target: N) -> None:
        """Attach this hook to a target. Override to add custom chaining logic."""
        self.next_hook = target


def _chain[T: polymorphic.PolymorphicModel, M: Hook](executor: T, hooks: list[M] | None = None) -> T:
    if not hooks:
        return executor
    for i in range(len(hooks) - 1):
        hooks[i].attach_to(hooks[i + 1])
    hooks[-1].attach_to(cast(M, executor))
    return cast(T, hooks[0])


def _make_hooks[M: Hook](specs: list[M] | None, copy: bool = True) -> list[M]:
    if not specs:
        return []
    hooks: list[M] = []
    for spec in specs:
        if isinstance(spec, Hook):
            hooks.append(spec.model_copy(deep=True) if copy else spec)
        elif isinstance(spec, type) and issubclass(spec, Hook):
            hooks.append(spec())
        else:
            raise TypeError(f"Expected Hook class or instance, got {type(spec)}")
    return hooks


def with_hook[T: polymorphic.PolymorphicModel](executor: T, hook: Hook[T] | None) -> T:
    if hook is None:
        return executor
    tail: Any = hook
    while isinstance(tail, Hook) and tail.next_hook is not None:
        tail = tail.next_hook
    tail.attach_to(executor)
    return cast(T, hook)


def with_hooks[T: polymorphic.PolymorphicModel, M: Hook](
    executor: T,
    hooks: list[M] | None = None,
) -> T:
    """Chain hooks onto an executor instance."""
    return _chain(executor, _make_hooks(hooks, copy=False))


def chain_hooks[M: Hook](hooks: list[M]) -> M | None:
    if not hooks:
        return None
    prepared = _make_hooks(hooks, copy=False)
    if len(prepared) == 1:
        return prepared[0]
    for i in range(len(prepared) - 1):
        prepared[i].attach_to(prepared[i + 1])
    return prepared[0]
