from typing import Any

from mistralai_workflows.plugins.mistralai.agent import Agent as MistralAgent
from pydantic import BaseModel


class Agent(MistralAgent):
    handoffs: None = None  # pyright: ignore[reportIncompatibleVariableOverride] # no supported yet by nuage


class AgentToolCallState(BaseModel):
    name: str
    kwargs: dict[str, Any] = {}
    output: dict[str, Any] | None = None


class AgentCompletionState(BaseModel):
    content: str = ""


class AgentStartupState(BaseModel):
    step: str = ""
