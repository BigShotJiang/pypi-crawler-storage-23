from __future__ import annotations

import asyncio
import re
from typing import Any, Unpack, cast

import structlog
from pydantic import Field

from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models

from . import github_activities, github_models, github_prompts

logger = structlog.get_logger(__name__)
PR_URL_PATTERN = re.compile(r"https://github\.com/[^/\s]+/[^/\s]+/pull/\d+")


class GitHubSandboxHook(nuage_sandbox.SandboxHook):
    config: github_models.GitHubConfig = Field(...)

    async def create_sandbox(
        self, **kwargs: Unpack[nuage_sandbox_models.CreateSandboxKwargs]
    ) -> nuage_sandbox_models.SandboxResult:
        typed_kwargs = self._inject_github_token_env(cast(nuage_sandbox_models.CreateSandboxKwargs, kwargs))
        result = await self.next.create_sandbox(**typed_kwargs)
        await self._clone_repo()
        if self.config.teleported_diffs:
            await self._apply_diffs(self.config.teleported_diffs)
        return result

    def _inject_github_token_env(
        self, kwargs: nuage_sandbox_models.CreateSandboxKwargs
    ) -> nuage_sandbox_models.CreateSandboxKwargs:
        if not self.config.github_token:
            return kwargs
        existing_env = kwargs.get("env") or {}
        token = self.config.github_token
        return cast(
            nuage_sandbox_models.CreateSandboxKwargs,
            {**kwargs, "env": {**existing_env, "GH_TOKEN": token, "GITHUB_TOKEN": token}},
        )

    async def _clone_repo(self) -> None:
        if not self.config.github_token:
            raise ValueError("GitHub token required for clone")

        await github_activities.github_clone_repo(
            self.next,
            self.config.url,
            self.config.github_token,
            self.config.branch,
            self.config.commit,
            self.config.working_branch,
        )

    async def _apply_diffs(self, diffs: bytes) -> None:
        diffs_str = diffs.decode("ascii")
        await github_activities.github_apply_diffs(self.next, diffs_str)


class GitHubSessionHook(nuage_agent_session.SessionHook):
    config: github_models.GitHubConfig
    raw_sandbox: nuage_sandbox.Sandbox
    system_prompt: str = github_prompts.GITHUB_SESSION_SYSTEM_PROMPT

    async def initialize_conversation(
        self, agent: nuage_agent_session.Agent, inputs: nuage_agent_session.AgentInputs
    ) -> nuage_agent_session.AgentOutputs:
        user_request = "\n".join(str(i) for i in inputs)
        enriched: list[Any] = [self._build_system_input(user_request)]
        return await self.next.initialize_conversation(agent, enriched)

    async def process_output(self, output: str) -> list[str]:
        results, errors = await asyncio.gather(self.next.process_output(output), self._validate(output))
        if errors:
            error_message = "Fix the following issues:\n- " + "\n- ".join(errors)
            results.append(error_message)
        return results

    async def _validate(self, output: str) -> list[str]:
        if not self.config.github_token:
            return ["GitHub token is missing. Ensure the workflow was started with valid GitHub credentials."]
        working_branch = self.config.working_branch or "main"
        base_branch = self.config.branch or "main"
        errors = await github_activities.github_validate_state(
            self.raw_sandbox, self.config.github_token, working_branch, base_branch
        )
        if not PR_URL_PATTERN.search(output):
            errors.append("PR URL not found in message (expected: message contains GitHub PR URL)")
        return errors

    def _build_system_input(self, user_request: str) -> str:
        base_branch = self.config.branch or "main"
        working_branch = self.config.working_branch or "current"
        return (
            f"# Git Context\n"
            f"- Working branch: {working_branch}\n"
            f"- Base branch: {base_branch}\n"
            f"- Repository: {self.config.url}\n\n"
            f"{self.system_prompt.format(base_branch=base_branch).strip()}\n\n"
            f"# Task\n"
            "```\n"
            f"{user_request.strip()}\n"
            "```\n"
        )
