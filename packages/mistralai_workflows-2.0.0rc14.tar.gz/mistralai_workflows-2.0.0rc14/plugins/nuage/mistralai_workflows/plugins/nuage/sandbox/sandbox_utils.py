import inspect
import re
import textwrap
from typing import Any, Callable

from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets

from . import sandbox_models

_ENV_KEY_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def is_valid_env_key(key: str) -> bool:
    return isinstance(key, str) and bool(_ENV_KEY_PATTERN.fullmatch(key))


def build_execute_python_kwargs(
    func: Callable[..., Any],
    kwargs: dict[str, Any] | None = None,
    python_executable: str = "python",
    cwd: str | None = None,
    env: nuage_env_secrets.EnvDict | None = None,
    timeout: int | None = None,
    skip_redact: bool = False,
) -> sandbox_models.ExecutePythonKwargs:
    if not callable(func):
        raise ValueError("func must be callable")

    try:
        func_source = inspect.getsource(func)
    except (OSError, TypeError) as e:
        raise ValueError(f"Cannot get source code for function: {e}") from e

    func_source = textwrap.dedent(func_source)
    func_name = func.__name__
    is_async = inspect.iscoroutinefunction(func)

    result: sandbox_models.ExecutePythonKwargs = {
        "function_source": func_source,
        "function_name": func_name,
        "kwargs": kwargs or {},
        "is_async": is_async,
        "python_executable": python_executable,
        "skip_redact": skip_redact,
    }
    if cwd is not None:
        result["cwd"] = cwd
    if env is not None:
        result["env"] = env
    if timeout is not None:
        result["timeout"] = timeout
    return result
