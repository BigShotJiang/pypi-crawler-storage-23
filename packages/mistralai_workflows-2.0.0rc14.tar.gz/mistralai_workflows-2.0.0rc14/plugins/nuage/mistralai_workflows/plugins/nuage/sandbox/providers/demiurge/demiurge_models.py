from demiurge_sdk.config import DemiurgeConfig as DemiurgeSDKConfig
from pydantic import BaseModel, Field

from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets

DEFAULT_BEARER_TOKEN_SECRET_KEY = "demiurge_bearer_token"


class DemiurgeConfig(BaseModel):
    base_url: str = Field(default="http://localhost:8000/api/v1")
    customer_id: str = Field(default="00000000-0000-0000-0000-000000000000")
    workspace_id: str = Field(default="00000000-0000-0000-0000-000000000001")
    bearer_token_secret_key: str | None = Field(
        default=DEFAULT_BEARER_TOKEN_SECRET_KEY,
        description="Secret key name used to resolve Demiurge bearer token from encrypted secrets",
    )
    http_timeout_seconds: float = Field(default=180.0)
    stream_http_timeout_buffer_seconds: float = Field(
        default=30.0,
        ge=0.0,
        description="Extra HTTP timeout budget added for streamed command execution",
    )
    default_ttl_seconds: int = Field(default=600)
    default_exec_timeout_seconds: int = Field(default=300)
    default_image: str = Field(default="python:3.13-slim")
    default_setup_script: str = Field(default="")
    ca_bundle: str | None = Field(default=None)


def _default_demiurge_config() -> DemiurgeConfig:
    # Keep environment-based defaults from demiurge_sdk while avoiding storing a raw bearer token in config.
    sdk_cfg = DemiurgeSDKConfig()
    return DemiurgeConfig(
        base_url=sdk_cfg.base_url,
        customer_id=sdk_cfg.customer_id,
        workspace_id=sdk_cfg.workspace_id,
        http_timeout_seconds=sdk_cfg.http_timeout_seconds,
        default_ttl_seconds=sdk_cfg.default_ttl_seconds,
        default_exec_timeout_seconds=sdk_cfg.default_exec_timeout_seconds,
        default_image=sdk_cfg.default_image,
        default_setup_script=sdk_cfg.default_setup_script,
        ca_bundle=sdk_cfg.ca_bundle,
    )


class DemiurgeSandboxConfig(BaseModel):
    image: str | None = Field(
        default="cdn-images.mistralai.com/docker/demiurge/python-alpine-sandbox:v0.0.1-dev25",
        description="Container image",
    )
    ttl_seconds: int = Field(default=600, ge=60, le=3600, description="Time-to-live in seconds")
    setup_script: str | None = Field(default="", description="Setup script")
    demiurge_config: DemiurgeConfig = Field(default_factory=_default_demiurge_config)
    cpu_request: str | None = Field(default=None, description="CPU request (e.g., '100m')")
    cpu_limit: str | None = Field(default=None, description="CPU limit (e.g., '500m')")
    memory_request: str | None = Field(default=None, description="Memory request (e.g., '128Mi')")
    memory_limit: str | None = Field(default=None, description="Memory limit (e.g., '512Mi')")
    storage_limit: str | None = Field(default="5Gi", description="Storage limit (e.g., '1Gi')")


class DemiurgeInternalState(BaseModel):
    sandbox_id: str | None = Field(default=None, description="Sandbox ID")
    secrets: nuage_env_secrets.EnvDict | None = Field(default=None, description="Secrets")
