from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class GitHubSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="GITHUB_INTEGRATION_", env_file=".env", extra="ignore")

    api_url: str = Field(default="https://integrations-api.mistral.ai")
    connector_id: str | None = Field(default=None)
    connector_name: str = Field(default="github_oauth")
    api_timeout: int = Field(default=10, description="HTTP timeout for GitHub API calls")
    token_validation_api_version: str = Field(default="2022-11-28")
    token_poll_interval_seconds: int = Field(default=2, description="Interval between token polling attempts")
    token_poll_timeout_seconds: int = Field(default=600, description="Total timeout for token polling")
    clone_timeout_seconds: int = Field(default=600, description="Timeout for git clone command execution")
    clone_activity_timeout_buffer_seconds: int = Field(
        default=300, description="Additional activity timeout budget over clone timeout"
    )


settings = GitHubSettings()
