from __future__ import annotations

from typing import Any

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.agent.providers.vibe import vibe as nuage_vibe
from mistralai_workflows.plugins.nuage.agent.providers.vibe import vibe_models as nuage_vibe_models
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base
from mistralai_workflows.plugins.nuage.integrations.chat_assistant import (
    chat_assistant_models as nuage_chat_assistant_models,
)
from mistralai_workflows.plugins.nuage.integrations.github import github_models as nuage_github_models
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import demiurge as nuage_demiurge


class WorkflowIntegrations(nuage_integrations_base.IntegrationsParams):
    github: nuage_github_models.GitHubParams | None = Field(default=None, description="GitHub integration")
    chat_assistant: nuage_chat_assistant_models.ChatAssistantParams | None = Field(  # type: ignore[pydantic-alias]
        default=None,
        description="Chat assistant integration",
        validation_alias=AliasChoices(
            "chat_assistant",
            "lechat",  # Deprecated input key kept for backward compatibility.
        ),
    )


class WorkflowConfig(BaseModel):
    sandbox: nuage_sandbox.Sandbox = Field(
        default_factory=nuage_demiurge.DemiurgeSandbox, description="Sandbox configuration (default: Demiurge)"
    )
    agent_session: nuage_agent_session.Session = Field(
        default_factory=nuage_vibe.VibeSession, description="Agent session configuration (default: Vibe)"
    )
    agent: nuage_agent_models.Agent = Field(
        default_factory=nuage_vibe_models.VibeAgent, description="Agent configuration (default: Vibe)"
    )


class NuageWorkflowParams(BaseModel):
    model_config = ConfigDict(extra="allow")

    prompt: str = Field(description="The prompt/task for the agent")
    config: WorkflowConfig = Field(default_factory=WorkflowConfig)
    integrations: WorkflowIntegrations = Field(
        default_factory=WorkflowIntegrations, description="Integration configurations"
    )

    @property
    def extra_fields(self) -> dict[str, Any]:
        return dict(self.__pydantic_extra__) if self.__pydantic_extra__ else {}
