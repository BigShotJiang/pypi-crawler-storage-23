import asyncio
import inspect
from collections.abc import AsyncGenerator
from datetime import timedelta
from typing import Any

import structlog
from deepmerge.merger import Merger
from pydantic import BaseModel
from vibe.core.llm.backend import factory
from vibe.core.llm.types import LLMChunk
from vibe.core.tools import mcp
from vibe.core.tools.base import BaseTool, ToolError
from vibe.core.tools.manager import ToolManager

import mistralai_workflows as workflows
from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_utils as nuage_sandbox_utils
from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import demiurge_constants as nuage_demiurge_constants

from . import vibe_invoke_tool_in_sandbox, vibe_patches

logger = structlog.get_logger(__name__)

_original_backend_factory = factory.BACKEND_FACTORY.copy()
_original_list_tools_http = mcp.list_tools_http
_original_list_tools_stdio = mcp.list_tools_stdio
_original_compute_search_paths = ToolManager._compute_search_paths
_original_iter_tool_classes = ToolManager._iter_tool_classes

TOOL_TIMEOUT_SECONDS = 10 * 60


def serialize_tool_class(
    tool_cls: type[BaseTool[Any, Any, Any, Any]],
) -> vibe_patches.SerializedTool:
    return vibe_patches.SerializedTool(
        name=tool_cls.get_name(),
        description=getattr(tool_cls, "description", ""),
        parameters=tool_cls.get_parameters(),
        class_name=tool_cls.__name__,
        module_path=tool_cls.__module__,
    )


def _merge_str(_merger: Merger, path: list[str], base: str, nxt: str) -> str:
    return base + nxt if path and path[-1] == "content" else nxt


def _merge_pydantic(_merger: Merger, _path: list[str], base: BaseModel, nxt: BaseModel) -> BaseModel:
    base_dict = base.model_dump(mode="json") if isinstance(base, BaseModel) else base
    nxt_dict = nxt.model_dump(mode="json") if isinstance(nxt, BaseModel) else nxt
    return type(base).model_validate(_merger.merge(base_dict, nxt_dict))


state_merger = Merger(
    [(list, "append"), (dict, "merge"), (str, _merge_str), (BaseModel, _merge_pydantic)],
    ["override"],
    ["override"],
)


@workflows.activity()
async def compute_search_paths(
    request: vibe_patches.ProxyComputeSearchPathsRequest,
) -> vibe_patches.ProxyComputeSearchPathsResponse:
    paths = _original_compute_search_paths(request.config)
    return vibe_patches.ProxyComputeSearchPathsResponse(paths=[str(p) for p in paths])


@workflows.activity()
async def iter_tool_classes(
    request: vibe_patches.ProxyIterToolClassesRequest,
) -> vibe_patches.ProxyIterToolClassesResponse:
    from pathlib import Path

    paths = [Path(p) for p in request.search_paths]
    tool_classes = list(_original_iter_tool_classes(paths))
    serialized_tools = [serialize_tool_class(tool_cls) for tool_cls in tool_classes]
    return vibe_patches.ProxyIterToolClassesResponse(tools=serialized_tools)


@workflows.activity()
async def list_mcp_tools_http(
    request: vibe_patches.ProxyListMcpToolsHTTPRequest,
) -> vibe_patches.ProxyListMcpToolsResponse:
    tools = await _original_list_tools_http(**request.model_dump())
    return vibe_patches.ProxyListMcpToolsResponse(tools=[tool.model_dump() for tool in tools])


@workflows.activity()
async def list_mcp_tools_stdio(
    request: vibe_patches.ProxyListMcpToolsSTDIORequest,
) -> vibe_patches.ProxyListMcpToolsResponse:
    tools = await _original_list_tools_stdio(**request.model_dump())
    return vibe_patches.ProxyListMcpToolsResponse(tools=[tool.model_dump() for tool in tools])


@workflows.activity(retry_policy_max_attempts=1, start_to_close_timeout=timedelta(seconds=TOOL_TIMEOUT_SECONDS * 1.2))
async def execute_tool(
    request: vibe_patches.ProxyInvokeToolRequest,
    sandbox: nuage_sandbox.Sandbox,
    workflow_task: nuage_agent_task.WorkflowTask,
) -> vibe_patches.ProxyInvokeToolResponse:
    async with workflow_task.tool_call:
        await workflow_task.tool_call.set_state(
            nuage_agent_models.AgentToolCallState(name=request.tool_name, kwargs=request.tool_kwargs)
        )

        try:
            exec_result = await asyncio.wait_for(
                sandbox.execute_python(
                    **nuage_sandbox_utils.build_execute_python_kwargs(
                        func=vibe_invoke_tool_in_sandbox.invoke_tool_in_sandbox,
                        kwargs={"params": request.model_dump()},
                        cwd=nuage_demiurge_constants.DEFAULT_WORKSPACE,
                        timeout=int(TOOL_TIMEOUT_SECONDS),
                    )
                ),
                timeout=TOOL_TIMEOUT_SECONDS,
            )
        except RuntimeError as e:
            error_msg = str(e)
            await workflow_task.tool_call.set_state(
                nuage_agent_models.AgentToolCallState(
                    name=request.tool_name, kwargs=request.tool_kwargs, output={"error": error_msg}
                )
            )
            return vibe_patches.ProxyInvokeToolResponse(error=error_msg, tool_state=request.tool_state)
        except asyncio.TimeoutError as e:
            await workflow_task.tool_call.set_state(
                nuage_agent_models.AgentToolCallState(
                    name=request.tool_name, kwargs=request.tool_kwargs, output={"error": "Timed out"}
                )
            )
            raise ToolError(f"Tool '{request.tool_name}' timed out after {TOOL_TIMEOUT_SECONDS}s") from e
        except Exception as e:
            await workflow_task.tool_call.set_state(
                nuage_agent_models.AgentToolCallState(
                    name=request.tool_name, kwargs=request.tool_kwargs, output={"error": "Internal error"}
                )
            )
            raise ToolError(f"Error invoking tool '{request.tool_name}': Internal error") from e

        result = vibe_patches.ProxyInvokeToolResponse.model_validate(exec_result.result)
        await workflow_task.tool_call.set_state(
            nuage_agent_models.AgentToolCallState(
                name=request.tool_name,
                kwargs=request.tool_kwargs,
                output=result.tool_result if result.tool_result is not None else {"error": result.error},
            )
        )

        return result


@workflows.activity()
async def llm_completion(
    request: vibe_patches.BackendProxyRequest,
    workflow_task: nuage_agent_task.WorkflowTask,
) -> vibe_patches.BackendProxyResponse:
    backend_cls = _original_backend_factory[request.backend]

    method_kwargs_model = vibe_patches.METHOD_KWARGS_MODELS[request.method]

    init_kwargs = vars(vibe_patches.BackendInitKwargs.model_validate(request.init_kwargs))
    method_kwargs = vars(method_kwargs_model.model_validate(request.call_kwargs))

    backend = backend_cls(**init_kwargs)
    final_result: Any = None
    task_text = ""

    async with workflow_task.completion:
        async with backend:
            result = getattr(backend, request.method)(**method_kwargs)
            if isinstance(result, AsyncGenerator):
                async for chunk in result:
                    if final_result is None:
                        final_result = chunk
                    else:
                        final_result = state_merger.merge(final_result, chunk)
                    if not isinstance(chunk, LLMChunk) or chunk.message.content is None:
                        continue
                    task_text += chunk.message.content
                    if task_text.strip():
                        state = nuage_agent_models.AgentCompletionState(content=task_text)
                        await workflow_task.completion.set_state(state)
                if final_result is None:
                    raise ValueError("LLM stream yielded no chunks")
            else:
                if inspect.isawaitable(result):
                    result = await result
                if isinstance(result, LLMChunk) and result.message.content is not None:
                    task_text += result.message.content
                final_result = result

        if task_text.strip():
            await workflow_task.completion.set_state(nuage_agent_models.AgentCompletionState(content=task_text))
        return vibe_patches.BackendProxyResponse.model_validate({"result": final_result})


class VibeAgentExecutor(nuage_agent_executor.AgentExecutor):
    sandbox: nuage_sandbox.Sandbox
    workflow_task: nuage_agent_task.WorkflowTask

    async def complete(self, request: Any) -> Any:
        return await llm_completion(request, self.workflow_task)

    async def invoke_tool(self, request: Any) -> Any:
        response = await execute_tool(request, self.sandbox, self.workflow_task)
        if response.error:
            raise ToolError(response.error)
        return response

    async def list_tools_http(self, request: Any) -> Any:
        return await list_mcp_tools_http(request)

    async def list_tools_stdio(self, request: Any) -> Any:
        return await list_mcp_tools_stdio(request)

    async def compute_search_paths(self, request: Any) -> Any:
        return await compute_search_paths(request)

    async def iter_tool_classes(self, request: Any) -> Any:
        return await iter_tool_classes(request)
