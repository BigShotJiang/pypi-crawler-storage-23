from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ExperimentalIdentity(BaseModel):
    """Temporary identity model for in-cluster workers.

    This is an experimental feature that only works for in-cluster workers where
    the identity is injected by Abraxas. It will be replaced by proper RBAC once
    external workers are supported.

    Timeline: https://www.notion.so/mistralai/External-Workers-RBAC-30c6ba59a7fe80289d80c1294f5e171b
    """

    version: Literal[1] = Field(description="Identity schema version")
    customer_id: str | None = Field(default=None, description="Customer ID")
    user_id: str | None = Field(default=None, description="User ID")
    workspace_id: str | None = Field(default=None, description="Workspace ID")
    organization_id: str | None = Field(default=None, description="Organization ID")

    def build_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.customer_id:
            headers["x-consumer-custom-id"] = self.customer_id
        if self.user_id:
            headers["x-user-id"] = self.user_id
        if self.workspace_id:
            headers["x-workspace-id"] = self.workspace_id
        if self.organization_id:
            headers["x-organization-id"] = self.organization_id
        return headers
