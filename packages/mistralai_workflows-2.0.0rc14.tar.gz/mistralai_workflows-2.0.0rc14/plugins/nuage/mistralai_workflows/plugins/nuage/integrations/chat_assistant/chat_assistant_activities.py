from __future__ import annotations

import httpx
import structlog
from mistralai_workflows.core.config import config as workflows_config
from mistralai_workflows.models import WorkflowSpec

import mistralai_workflows as workflows
from mistralai_workflows.plugins.nuage.integrations.chat_assistant import (
    chat_assistant_dependencies,
    chat_assistant_models,
    chat_assistant_settings,
)

logger = structlog.get_logger(__name__)


@workflows.activity()
async def create_chat_assistant_thread(
    params: chat_assistant_models.CreateChatAssistantThreadParams,
) -> chat_assistant_models.CreateChatAssistantThreadResult:
    body = {
        "workflow": {
            "workflowVersionId": params.workflow_version_id,
            "executionId": params.workflow_execution_id,
            "name": params.workflow_name,
            "params": params.workflow_params,
        },
        "userMessage": params.user_message,
        "chatTitle": params.chat_title,
    }
    if params.project_name:
        body["projectName"] = params.project_name

    chat_settings = chat_assistant_settings.settings
    headers = params.identity.build_headers()
    headers["Content-Type"] = "application/json"
    headers["x-auth-by"] = "albe"
    if chat_settings.api_key:
        headers["x-api-key"] = chat_settings.api_key

    async with httpx.AsyncClient(timeout=30) as client:
        logger.debug("Creating chat assistant thread", api_url=chat_settings.api_url)
        response = await client.post(
            f"{chat_settings.api_url}/api/v1/chats",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

    chat_id = data["chatId"]
    chat_url = f"{chat_settings.public_url}/chat/{chat_id}"
    return chat_assistant_models.CreateChatAssistantThreadResult(chat_url=chat_url)


@workflows.activity()
async def get_workflow_version_id(
    workflow_spec: WorkflowSpec,
    client: workflows.WorkflowsClient = workflows.Depends(chat_assistant_dependencies.get_workflows_client),
) -> str:
    task_queue = workflows_config.temporal.task_queue
    response = await client.get_workflow_versions(
        workflow_name=workflow_spec.name,
        task_queue=task_queue,
        active_only=False,
        limit=250,
    )
    if not response.workflow_versions:
        raise workflows.WorkflowError(
            f"No workflow version found for '{workflow_spec.name}' in task queue '{task_queue}'"
        )
    # API returns versions in chronological order (oldest first), so last is latest
    return str(response.workflow_versions[-1].id)
