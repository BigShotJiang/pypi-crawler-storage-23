from __future__ import annotations

from typing import Any, Literal

import mistralai
import structlog
from mistralai_workflows.plugins.mistralai.session.session import FinalOutputs, Inputs, Outputs, Session
from pydantic import Field, PrivateAttr, model_serializer
from vibe.core.agent_loop import AgentLoop as VibeLoop
from vibe.core.teleport.nuage import TeleportSession
from vibe.core.types import AssistantEvent, LLMMessage

from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import utils as nuage_utils
from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox

from . import vibe_activities, vibe_hook_sandbox, vibe_hook_wait_for_input, vibe_models, vibe_patches

logger = structlog.get_logger(__name__)


def _format_session_input(agent_input: str | mistralai.TextChunk | Any) -> str:
    if isinstance(agent_input, str):
        return agent_input
    if isinstance(agent_input, mistralai.TextChunk):
        return agent_input.text
    raise ValueError(f"Unsupported input type: {type(agent_input)}")


def _export_teleported_session(agent: VibeLoop) -> TeleportSession:
    return TeleportSession(
        metadata={
            "agent": agent.agent_profile.name,
            "model": agent.config.active_model,
            "stats": agent.stats.model_dump(),
        },
        messages=[msg.model_dump(exclude_none=True) for msg in agent.messages[1:]],
    )


def _build_executor_hook_chain(
    workflow_task: nuage_agent_task.WorkflowTask,
    integration_hook: nuage_agent_executor.AgentExecutorHook | None,
) -> nuage_agent_executor.AgentExecutorHook:
    ask_hook = vibe_hook_wait_for_input.VibeWaitForInputHook(workflow_task=workflow_task)
    if integration_hook is None:
        return ask_hook

    copied_integration_hook = integration_hook.model_copy(deep=True)
    chained = nuage_hook.chain_hooks([copied_integration_hook, ask_hook])
    return nuage_utils.ensure(
        chained,
        RuntimeError("Failed to compose Vibe agent executor hooks"),
    )


class VibeSession(nuage_agent_session.Session, polymorphic_type="vibe"):
    type: Literal["vibe"] = "vibe"
    teleported_session: TeleportSession | None = Field(default=None, description="Teleported session state")
    _internal_state: vibe_models.VibeSessionInternalState = PrivateAttr(
        default_factory=vibe_models.VibeSessionInternalState
    )

    @classmethod
    def default_hooks(cls) -> nuage_integrations_base.IntegrationHooks:
        return nuage_integrations_base.IntegrationHooks(sandbox=vibe_hook_sandbox.VibeSandboxHook())

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any, info: Any) -> dict[str, Any]:
        data = super()._serialize(handler, info)
        if self._internal_state._vibe_agent is not None:
            data["teleported_session"] = _export_teleported_session(self._internal_state._vibe_agent).model_dump()
        return data

    @property
    def last_assistant_message(self) -> str:
        return self._internal_state.last_assistant_message

    def is_conversation_active(self) -> bool:
        return self._internal_state.conversation_active

    @staticmethod
    async def create(
        uncreated_session: Session,
        sandbox: nuage_sandbox.Sandbox,
        workflow_task: nuage_agent_task.WorkflowTask,
        agent_executor_hook: nuage_agent_executor.AgentExecutorHook | None = None,
    ) -> nuage_agent_session.Session:
        if not isinstance(uncreated_session, VibeSession):
            raise ValueError(f"Uncreated session of type {type(uncreated_session)}, expected {VibeSession.__name__}")

        agent_executor: nuage_agent_executor.AgentExecutor = vibe_activities.VibeAgentExecutor(
            sandbox=sandbox, workflow_task=workflow_task
        )
        final_agent_executor_hook = _build_executor_hook_chain(workflow_task, agent_executor_hook)
        agent_executor = nuage_hook.with_hook(agent_executor, final_agent_executor_hook)
        internal_state = vibe_models.VibeSessionInternalState(
            sandbox=sandbox,
            workflow_task=workflow_task,
            agent_executor=agent_executor,
        )
        session = VibeSession(teleported_session=uncreated_session.teleported_session)
        session._internal_state = internal_state
        return session

    async def initialize_conversation(self, agent: nuage_agent_session.Agent, inputs: Inputs) -> Outputs:
        if self._internal_state.conversation_active:
            raise RuntimeError("Conversation already active")

        agent_executor = nuage_utils.ensure(
            self._internal_state.agent_executor,
            RuntimeError("Agent executor is not set, call setup first"),
        )

        config = vibe_models.VibeConfig.from_agent(agent)
        self._internal_state._vibe_agent = VibeLoop(config=config, enable_streaming=True)
        vibe_patches.patch_vibe_loop(self._internal_state._vibe_agent, agent_executor)

        if self.teleported_session:
            for msg_data in self.teleported_session.messages:
                self._internal_state._vibe_agent.messages.append(LLMMessage.model_validate(msg_data))

        self._internal_state.conversation_active = True

        prompt = "\n".join(str(x) for x in inputs) if inputs else ""
        return await self._run_agent(prompt)

    async def close_conversation(self) -> None:
        if not self._internal_state.conversation_active:
            return
        self._internal_state._vibe_agent = None
        self._internal_state.conversation_active = False

    async def append_messages(self, inputs: Inputs) -> Outputs:
        if not self._internal_state.conversation_active or self._internal_state._vibe_agent is None:
            raise RuntimeError("No active conversation")

        prompt = "\n".join(_format_session_input(x) for x in inputs) if inputs else ""
        return await self._run_agent(prompt)

    async def process_output(self, output: str) -> list[str]:
        return []

    def format_final_outputs(self, outputs: list[str]) -> FinalOutputs:
        return [mistralai.TextChunk(text=output) for output in outputs]

    async def _run_agent(self, prompt: str) -> list[str]:
        vibe_agent = nuage_utils.ensure(
            self._internal_state._vibe_agent,
            RuntimeError("Vibe agent is not set, call initialize_conversation first"),
        )

        last_output = ""
        async for event in vibe_agent.act(prompt):
            match event:
                case AssistantEvent(content=content):
                    last_output = content

        self._internal_state.last_assistant_message = last_output
        return [last_output]
