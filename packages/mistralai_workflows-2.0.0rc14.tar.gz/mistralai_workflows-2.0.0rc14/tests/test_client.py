import warnings
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mistralai_workflows.client import WorkflowsClient


class TestWorkflowsClientDeprecation:
    @pytest.mark.asyncio
    async def test_get_workflow_executions_emits_deprecation_warning(self):
        """Verify get_workflow_executions emits a DeprecationWarning.

        TODO: Remove this test when get_workflow_executions is removed.
        """
        client = WorkflowsClient(base_url="http://localhost", api_key="test-key")

        mock_response = MagicMock()
        mock_response.json.return_value = {"executions": [], "next_page_token": None}

        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = mock_response

            with pytest.warns(DeprecationWarning, match="get_workflow_runs"):
                await client.get_workflow_executions()

    @pytest.mark.asyncio
    async def test_get_workflow_runs_does_not_emit_deprecation_warning(self):
        """Verify get_workflow_runs does NOT emit a DeprecationWarning.

        TODO: Remove this test when get_workflow_executions is removed.
        """
        client = WorkflowsClient(base_url="http://localhost", api_key="test-key")

        mock_response = MagicMock()
        mock_response.json.return_value = {"executions": [], "next_page_token": None}

        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = mock_response

            with warnings.catch_warnings():
                warnings.simplefilter("error")
                await client.get_workflow_runs()
