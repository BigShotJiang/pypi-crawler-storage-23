import os

import httpx
import pytest


@pytest.fixture
def api_client() -> httpx.AsyncClient:
    server_url = os.getenv("SERVER_URL", "http://localhost:7444")
    api_key = os.getenv("MISTRAL_API_KEY")

    return httpx.AsyncClient(
        base_url=server_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        timeout=120.0,
    )
