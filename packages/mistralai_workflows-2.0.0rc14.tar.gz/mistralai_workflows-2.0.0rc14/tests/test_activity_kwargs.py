"""Tests for activity **kwargs support."""

from typing import Any

import pytest

from mistralai_workflows import get_workflow_definition
from mistralai_workflows.examples.workflow_activity_kwargs import (
    BaseModelWithKwargsWorkflow,
    FlexibleSearchWorkflow,
    SearchWorkflow,
)

from .utils import create_test_worker, get_temporal_activities_by_names


class TestActivityKwargsWorkflows:
    @pytest.mark.asyncio
    async def test_activity_with_explicit_params_and_kwargs(self, temporal_env: Any) -> None:
        """Test workflow with activity that has explicit params + **kwargs."""
        activities = get_temporal_activities_by_names(["search_documents"])
        async with create_test_worker(
            temporal_env,
            workflows=[SearchWorkflow],
            activities=activities,
        ):
            workflow_def = get_workflow_definition(SearchWorkflow)
            assert workflow_def is not None

            handle = await temporal_env.client.start_workflow(
                workflow_def.name,
                {"query": "AI research papers"},
                id="test-activity-kwargs",
                task_queue="test-task-queue",
            )

            result = await handle.result()

            assert isinstance(result, dict)
            assert result["query"] == "AI research papers"
            assert "filters_applied" in result
            filters = result["filters_applied"]
            assert filters["limit"] == 5
            assert filters["category"] == "engineering"
            assert filters["author"] == "team-ai"
            assert filters["include_archived"] is False

    @pytest.mark.asyncio
    async def test_activity_with_only_kwargs(self, temporal_env: Any) -> None:
        """Test workflow with activity that only takes **kwargs."""
        activities = get_temporal_activities_by_names(["flexible_search"])
        async with create_test_worker(
            temporal_env,
            workflows=[FlexibleSearchWorkflow],
            activities=activities,
        ):
            workflow_def = get_workflow_definition(FlexibleSearchWorkflow)
            assert workflow_def is not None

            handle = await temporal_env.client.start_workflow(
                workflow_def.name,
                {"query": "test query"},
                id="test-activity-only-kwargs",
                task_queue="test-task-queue",
            )

            result = await handle.result()

            assert isinstance(result, dict)
            assert "params_received" in result
            params = result["params_received"]
            assert params["query"] == "test query"
            assert params["source"] == "workflow"
            assert params["timestamp"] == 12345
            assert params["include_metadata"] is True
            assert result["result_count"] == 4

    @pytest.mark.asyncio
    async def test_activity_with_basemodel_and_kwargs(self, temporal_env: Any) -> None:
        """Test workflow with activity that has single BaseModel param + **kwargs."""
        activities = get_temporal_activities_by_names(["process_with_basemodel"])
        async with create_test_worker(
            temporal_env,
            workflows=[BaseModelWithKwargsWorkflow],
            activities=activities,
        ):
            workflow_def = get_workflow_definition(BaseModelWithKwargsWorkflow)
            assert workflow_def is not None

            handle = await temporal_env.client.start_workflow(
                workflow_def.name,
                {"query": "basemodel test"},
                id="test-activity-basemodel-kwargs",
                task_queue="test-task-queue",
            )

            result = await handle.result()

            assert isinstance(result, dict)
            assert "model_data" in result
            assert result["model_data"]["query"] == "basemodel test"
            assert "extra_kwargs" in result
            extra = result["extra_kwargs"]
            assert extra["extra_filter"] == "important"
            assert extra["priority"] == 1
            assert extra["tags"] == ["test", "demo"]
