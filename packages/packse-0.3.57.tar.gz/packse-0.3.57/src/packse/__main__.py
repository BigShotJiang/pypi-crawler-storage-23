"""
Enables usage with `python -m packse`
"""

import packse.cli

if __name__ == "__main__":
    packse.cli.entrypoint()
