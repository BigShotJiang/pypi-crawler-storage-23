# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid jobs' namespace.

"""

from enum import Enum
from typing import Any, Optional

import typer
from qbraid_core.services.runtime.schemas import JobStatus
from rich.console import Console

from qbraid_cli.handlers import handle_error, print_formatted_data, run_progress_task

jobs_app = typer.Typer(help="Manage qBraid quantum jobs.", no_args_is_help=True)


class JobVendor(str, Enum):
    """Vendor filter for job listing."""

    AWS = "aws"
    AZURE = "azure"
    IBM = "ibm"
    IONQ = "ionq"
    QBRAID = "qbraid"


class JobProvider(str, Enum):
    """Provider filter for job listing."""

    AQT = "aqt"
    AWS = "aws"
    AZURE = "azure"
    EQUAL1 = "equal1"
    IBM = "ibm"
    IQM = "iqm"
    IONQ = "ionq"
    NEC = "nec"
    OQC = "oqc"
    PASQAL = "pasqal"
    QUANTINUUM = "quantinuum"
    QUERA = "quera"
    RIGETTI = "rigetti"
    QBRAID = "qbraid"


@jobs_app.command(name="list")
def jobs_list(
    limit: int = typer.Option(
        10, "--limit", "-l", help="Limit the maximum number of results returned"
    ),
    status: Optional[JobStatus] = typer.Option(
        None,
        "--status",
        "-s",
        help=f"Filter by status: {', '.join(e.name for e in JobStatus)}",
    ),
    vendor: Optional[JobVendor] = typer.Option(
        None,
        "--vendor",
        "-v",
        help=f"Filter by vendor: {', '.join(e.name for e in JobVendor)}",
    ),
    provider: Optional[JobProvider] = typer.Option(
        None,
        "--provider",
        "-p",
        help=f"Filter by provider: {', '.join(e.name for e in JobProvider)}",
    ),
) -> None:
    """List qBraid Quantum Jobs."""

    def fetch_jobs():
        from qbraid_core.services.runtime import QuantumRuntimeClient

        client = QuantumRuntimeClient()
        status_value = status.value if status is not None else None
        vendor_value = vendor.value if vendor is not None else None
        provider_value = provider.value if provider is not None else None
        return client.list_jobs(
            limit=limit,
            status=status_value,
            vendor=vendor_value,
            provider=provider_value,
        )

    try:
        jobs = run_progress_task(fetch_jobs)

        if not jobs:
            console = Console()
            console.print("[dim]No jobs found.[/dim]")
            return

        # Column widths: full QRN (no truncation), Submitted, Status. Equal gap between columns.
        col_gap = 3
        longest_job_id = max(len(job.jobQrn) for job in jobs)
        qrn_width = longest_job_id + col_gap
        submitted_width = 19 + col_gap  # "YYYY-MM-DD HH:MM:SS"
        status_width = 12 + col_gap  # Longest status e.g. INITIALIZING

        console = Console()
        header_1 = "Job QRN"
        header_2 = "Submitted"
        header_3 = "Status"
        console.print(
            f"[bold]{header_1.ljust(qrn_width)}{header_2.ljust(submitted_width)}{header_3.ljust(status_width)}[/bold]"
        )

        for job in jobs:
            job_status = job.status.value if hasattr(job.status, "value") else str(job.status)

            # Format timestamp
            if job.timeStamps and job.timeStamps.createdAt:
                submitted = job.timeStamps.createdAt.strftime("%Y-%m-%d %H:%M:%S")
            else:
                submitted = "N/A"

            # Color based on status
            if job_status == "COMPLETED":
                status_color = "green"
            elif job_status in ["FAILED", "CANCELLED"]:
                status_color = "red"
            elif job_status in ["INITIALIZING", "QUEUED", "VALIDATING", "RUNNING"]:
                status_color = "blue"
            else:
                status_color = "grey"

            # Full job QRN, no truncation
            job_qrn = job.jobQrn
            console.print(
                f"{job_qrn.ljust(qrn_width)}{submitted.ljust(submitted_width)}"
                f"[{status_color}]{job_status.ljust(status_width)}[/{status_color}]"
            )

        console.print(f"\n[italic]Displaying {len(jobs)} jobs[/italic]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to fetch quantum jobs: {err}")


@jobs_app.command(name="get")
def jobs_get(
    job_id: str = typer.Argument(..., help="The QRN or ID of the job to get."),
    fmt: bool = typer.Option(
        True, "--no-fmt", help="Disable rich console formatting (output raw data)"
    ),
) -> None:
    """Get a qBraid Quantum Job."""

    def get_job():
        from qbraid_core.services.runtime import QuantumRuntimeClient

        client = QuantumRuntimeClient()
        return client.get_job(job_id)

    job = run_progress_task(get_job)

    # Convert Pydantic model to dict for display
    data: dict[str, Any] = job.model_dump()

    print_formatted_data(data, fmt)


if __name__ == "__main__":
    jobs_app()
