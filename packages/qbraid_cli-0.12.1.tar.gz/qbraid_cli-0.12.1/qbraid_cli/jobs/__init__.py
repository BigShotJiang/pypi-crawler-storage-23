# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid jobs namespace

"""

from .app import jobs_app

__all__ = ["jobs_app"]
