# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid devices' namespace.

"""

from enum import Enum
from typing import Any, Optional

import typer
from qbraid_core.services.runtime.schemas import DeviceStatus
from rich.console import Console

from qbraid_cli.devices.validation import validate_type
from qbraid_cli.handlers import print_formatted_data, run_progress_task

devices_app = typer.Typer(help="Manage qBraid quantum devices.", no_args_is_help=True)


def _provider_from_qrn(qrn: str) -> str:
    """Extract provider from QRN. Format: vendor:provider:qpu|sim:name."""
    parts = qrn.split(":")
    return parts[1].lower() if len(parts) > 1 else ""


class DeviceVendor(str, Enum):
    """Vendor filter for device listing."""

    AWS = "aws"
    AZURE = "azure"
    IBM = "ibm"
    IONQ = "ionq"
    QBRAID = "qbraid"


class DeviceProvider(str, Enum):
    """Provider filter for device listing."""

    AQT = "aqt"
    AWS = "aws"
    AZURE = "azure"
    EQUAL1 = "equal1"
    IBM = "ibm"
    IQM = "iqm"
    IONQ = "ionq"
    NEC = "nec"
    OQC = "oqc"
    PASQAL = "pasqal"
    QUANTINUUM = "quantinuum"
    QUERA = "quera"
    RIGETTI = "rigetti"
    QBRAID = "qbraid"


@devices_app.command(name="list")
def devices_list(
    status: Optional[DeviceStatus] = typer.Option(
        None,
        "--status",
        "-s",
        help=f"Filter by status: {', '.join(e.name for e in DeviceStatus)}",
    ),
    device_type: Optional[str] = typer.Option(
        None, "--type", "-t", help="'QPU'|'SIMULATOR'", callback=validate_type
    ),
    vendor: Optional[DeviceVendor] = typer.Option(
        None,
        "--vendor",
        "-v",
        help=f"Filter by vendor: {', '.join(e.name for e in DeviceVendor)}",
    ),
    provider: Optional[DeviceProvider] = typer.Option(
        None,
        "--provider",
        "-p",
        help=f"Filter by provider: {', '.join(e.name for e in DeviceProvider)}",
    ),
) -> None:
    """List qBraid quantum devices."""

    def fetch_devices():
        from qbraid_core.services.runtime import QuantumRuntimeClient

        client = QuantumRuntimeClient()
        return client.list_devices()

    devices = run_progress_task(fetch_devices)

    # Apply filters (client returns all devices, we filter locally)
    if status is not None:
        devices = [d for d in devices if d.status == status]
    if device_type:
        devices = [d for d in devices if d.deviceType == device_type]
    if vendor is not None:
        devices = [d for d in devices if d.vendor.lower() == vendor.value]
    if provider is not None:
        devices = [d for d in devices if _provider_from_qrn(d.qrn) == provider.value]

    console = Console()
    # Full QRNs, no truncation; column width from longest QRN in results
    col_gap = 3
    longest_qrn = max((len(d.qrn) for d in devices), default=len("Device QRN"))
    qrn_width = longest_qrn + col_gap
    status_width = 12
    header_qrn = "Device QRN"
    header_status = "Status"
    console.print(f"[bold]{header_qrn.ljust(qrn_width)}{header_status.ljust(status_width)}[/bold]")

    for device in devices:
        device_status = device.status.value
        if device_status == "ONLINE":
            status_color = "green"
        elif device_status == "OFFLINE":
            status_color = "red"
        elif device_status == "UNAVAILABLE":
            status_color = "yellow"
        else:
            status_color = "grey"

        console.print(
            f"{device.qrn.ljust(qrn_width)}[{status_color}]{device_status.ljust(status_width)}[/{status_color}]"
        )

    console.print(f"\n[italic]Displaying {len(devices)} devices[/italic]")


@devices_app.command(name="get")
def devices_get(
    device_id: str = typer.Argument(..., help="The QRN or ID of the device to get."),
    fmt: bool = typer.Option(
        True, "--no-fmt", help="Disable rich console formatting (output raw data)"
    ),
) -> None:
    """Get a qBraid quantum device."""

    def get_device():
        from qbraid_core.services.runtime import QuantumRuntimeClient

        client = QuantumRuntimeClient()
        return client.get_device(device_id)

    device = run_progress_task(get_device)

    # Convert Pydantic model to dict for display
    data: dict[str, Any] = device.model_dump()

    print_formatted_data(data, fmt)


if __name__ == "__main__":
    devices_app()
