# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid envs' namespace.

"""

import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import typer
from qbraid_core.services.environments.exceptions import EnvironmentValidationError
from qbraid_core.services.environments.schema import EnvironmentConfig
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)

from qbraid_cli.envs.create import create_qbraid_env_assets, create_venv
from qbraid_cli.envs.data_handling import get_envs_data as installed_envs_data
from qbraid_cli.envs.data_handling import validate_env_name
from qbraid_cli.handlers import QbraidException, handle_error, run_progress_task

if TYPE_CHECKING:
    from qbraid_core.services.environments.client import EnvironmentManagerClient as EMC

envs_app = typer.Typer(help="Manage qBraid environments.", no_args_is_help=True)


@envs_app.command(name="create")
def envs_create(  # pylint: disable=too-many-statements
    name: str = typer.Option(None, "--name", "-n", help="Name of the environment to create"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Short description of the environment"
    ),
    file_path: str = typer.Option(
        None, "--file", "-f", help="Path to a .yml file containing the environment details"
    ),
    auto_confirm: bool = typer.Option(
        False, "--yes", "-y", help="Automatically answer 'yes' to all prompts"
    ),
    add_kernels: bool = typer.Option(
        False, "--add-kernels", help="Add kernel to Jupyter's global kernel registry"
    ),
) -> None:
    """Create a new qBraid environment."""
    env_description = description or ""
    if name:
        if not validate_env_name(name):
            handle_error(
                error_type="ValueError",
                include_traceback=False,
                message=f"Invalid environment name '{name}'. ",
            )

    env_details_in_cli = name is not None and env_description != ""
    env_config = None
    if env_details_in_cli and file_path:
        handle_error(
            error_type="ArgumentConflictError",
            include_traceback=False,
            message="Cannot use --file with --name or --description while creating an environment",
        )
    elif not env_details_in_cli and not file_path:
        handle_error(
            error_type="MalformedCommandError",
            include_traceback=False,
            message="Must provide either --name and --description or --file "
            "while creating an environment",
        )
    else:
        try:
            if file_path:
                env_config: EnvironmentConfig = EnvironmentConfig.from_yaml(file_path)
        except ValueError as err:
            handle_error(error_type="YamlValidationError", message=str(err))

    if not name:
        name = env_config.name

    def gather_local_data() -> tuple[Path, str]:
        """Gather local environment data for creation."""
        from qbraid_core.services.environments import get_default_envs_paths

        env_path = get_default_envs_paths()[0]

        result = subprocess.run(
            [sys.executable, "--version"],
            capture_output=True,
            text=True,
            check=True,
        )

        python_version = result.stdout or result.stderr

        return env_path, python_version

    if not env_config:
        env_config = EnvironmentConfig(
            name=name,
            description=env_description,
        )

    # NOTE: create_environment API call will be removed from CLI
    # For now, we generate env_id locally and create environment without API
    from qbraid_core.services.environments.registry import generate_env_id

    local_data_out: tuple[Path, str] = run_progress_task(
        gather_local_data,
        description="Solving environment...",
        error_message="Failed to create qBraid environment",
    )

    env_path, python_version = local_data_out

    env_config.python_version = python_version

    # Generate env_id for local environment (slug will be set when published)
    env_id = generate_env_id()
    env_id_path = env_path / env_id
    description = "None" if description == "" else description

    typer.echo("## qBraid Metadata ##\n")
    typer.echo(f"  name: {env_config.name}")
    typer.echo(f"  description: {env_config.description}")
    typer.echo(f"  tags: {env_config.tags}")
    typer.echo(f"  env_id: {env_id}")
    typer.echo(f"  shellPrompt: {env_config.shell_prompt}")
    typer.echo(f"  kernelName: {env_config.kernel_name}")

    typer.echo("\n\n## Environment Plan ##\n")
    typer.echo(f"  location: {env_id_path}")
    typer.echo(f"  version: {python_version}\n")

    user_confirmation = auto_confirm or typer.confirm("Proceed", default=True)
    typer.echo("")
    if not user_confirmation:
        typer.echo("qBraidSystemExit: Exiting.")
        raise typer.Exit()

    run_progress_task(
        create_qbraid_env_assets,
        env_id,
        env_id_path,
        env_config,
        add_kernels,
        description="Generating qBraid assets...",
        error_message="Failed to create qBraid environment",
    )

    run_progress_task(
        create_venv,
        env_id_path,
        env_config.shell_prompt,
        None,  # python_exe (use default)
        env_id,  # env_id for registry package tracking
        description="Creating virtual environment...",
        error_message="Failed to create qBraid environment",
    )

    # Install python packages if specified
    if env_config.python_packages:
        from qbraid_core.services.environments.packages import pip_install

        packages = [
            f"{pkg}{ver}" if ver else pkg for pkg, ver in env_config.python_packages.items()
        ]
        if packages:
            run_progress_task(
                pip_install,
                env_id,
                packages,
                False,  # upgrade_pip
                False,  # system_site_packages
                description="Installing Python packages...",
                error_message="Failed to install Python packages",
            )

    console = Console()
    console.print(
        f"[bold green]Successfully created qBraid environment: "
        f"[/bold green][bold magenta]{name}[/bold magenta]\n"
    )
    typer.echo("# To activate this environment, use")
    typer.echo("#")
    typer.echo(f"#     $ qbraid envs activate {name}")
    typer.echo("#")
    typer.echo("# To deactivate an active environment, use")
    typer.echo("#")
    typer.echo("#     $ deactivate")


@envs_app.command(name="remove")
def envs_remove(
    name: str = typer.Option(..., "-n", "--name", help="Name of the environment to remove"),
    auto_confirm: bool = typer.Option(
        False, "--yes", "-y", help="Automatically answer 'yes' to all prompts"
    ),
) -> None:
    """Delete a qBraid environment."""
    import asyncio

    def uninstall_environment(slug: str) -> dict:
        """Uninstall a qBraid environment using async method."""
        from qbraid_core.services.environments.client import EnvironmentManagerClient

        emc = EnvironmentManagerClient()

        # Run async uninstall method
        result = asyncio.run(
            emc.uninstall_environment_local(slug, delete_metadata=True, force=auto_confirm)
        )
        return result

    def gather_local_data(env_name: str) -> tuple[Path, str]:
        """Get environment path and env_id from name or env_id."""
        installed, aliases = installed_envs_data()
        # Try to find by name first, then by env_id
        if env_name in aliases:
            env_id = aliases[env_name]
            path = installed[env_id]
            return path, env_id
        elif env_name in installed:
            # Direct env_id lookup
            path = installed[env_name]
            return path, env_name

        raise QbraidException(
            f"Environment '{name}' not found. "
            "Use name (if unique) or env_id to reference the environment."
        )

    env_path, env_id = gather_local_data(name)

    confirmation_message = (
        f"⚠️  Warning: You are about to delete the environment '{name}' "
        f"located at '{env_path}'.\n"
        "This will remove all local packages and permanently delete all "
        "of its associated qBraid environment metadata.\n"
        "This operation CANNOT be undone.\n\n"
        "Are you sure you want to continue?"
    )

    if auto_confirm or typer.confirm(confirmation_message, abort=True):
        typer.echo("")
        result = run_progress_task(
            uninstall_environment,
            env_id,  # Can be name or env_id - method handles both
            description="Deleting environment...",
            error_message="Failed to delete qBraid environment",
        )

        if result.get("deleted_metadata"):
            typer.echo(f"✅ Environment '{name}' successfully removed (local files and metadata).")
        else:
            typer.echo(f"✅ Environment '{name}' successfully removed (local files only).")


@envs_app.command(name="list")
def envs_list():
    """List installed qBraid environments."""
    from qbraid_core.services.environments.registry import EnvironmentRegistryManager

    installed, aliases = installed_envs_data(use_registry=True)
    console = Console()

    if len(installed) == 0:
        console.print(
            "No qBraid environments installed.\n\n"
            + "Use 'qbraid envs create' to create a new environment.",
            style="yellow",
        )
        return

    # Get registry to access name and env_id
    registry_mgr = EnvironmentRegistryManager()

    # Build list of (name, env_id, path) tuples
    env_list = []
    for env_id, path in installed.items():
        try:
            entry = registry_mgr.get_environment(env_id)
            env_list.append((entry.name, env_id, path))
        except Exception:
            # Fallback if registry lookup fails
            # Try to get name from aliases
            name = None
            for alias, eid in aliases.items():
                if eid == env_id and alias != env_id:
                    name = alias
                    break
            if not name:
                name = env_id
            env_list.append((name, env_id, path))

    # Sort: default first, then by name
    sorted_env_list = sorted(
        env_list,
        key=lambda x: (x[0] != "default", str(x[2]).startswith(str(Path.home())), x[0]),
    )

    current_env_path = Path(sys.executable).parent.parent.parent

    # Calculate column widths
    max_name_length = (
        max(len(str(name)) for name, _, _ in sorted_env_list) if sorted_env_list else 0
    )
    max_env_id_length = (
        max(len(str(env_id)) for _, env_id, _ in sorted_env_list) if sorted_env_list else 0
    )
    name_width = max(max_name_length, 4)  # At least "Name"
    env_id_width = max(max_env_id_length, 6)  # At least "Env ID"

    output_lines = []
    output_lines.append("# qbraid environments:")
    output_lines.append("#")
    output_lines.append("")

    # Header
    header = f"{'Name'.ljust(name_width + 2)}{'Env ID'.ljust(env_id_width + 2)}Path"
    output_lines.append(header)
    output_lines.append("")

    # Data rows
    for name, env_id, path in sorted_env_list:
        mark = "*" if path == current_env_path else " "
        line = f"{name.ljust(name_width + 2)}{env_id.ljust(env_id_width + 2)}{mark} {path}"
        output_lines.append(line)

    final_output = "\n".join(output_lines)

    console.print(final_output)


@envs_app.command(name="activate")
def envs_activate(
    name: str = typer.Argument(
        ..., help="Name of the environment. Values from 'qbraid envs list'."
    ),
):
    """Activate qBraid environment.

    NOTE: Currently only works on qBraid Lab platform, and select few other OS types.
    """
    from qbraid_core.services.environments.registry import EnvironmentRegistryManager

    # Get environment details from registry by looking up alias
    installed, aliases = installed_envs_data(use_registry=True)
    # Find the env_id from the alias (name or env_id)
    env_id = aliases.get(name)

    if not env_id:
        raise typer.BadParameter(f"Environment '{name}' not found.")

    # Get the environment entry
    registry_mgr = EnvironmentRegistryManager()
    entry = registry_mgr.get_environment(env_id)
    env_path = Path(entry.path)

    # The venv is always at pyenv/ subdirectory
    # (shell_prompt is for the PS1 display name, not the directory)
    venv_path = env_path / "pyenv"

    from .activate import activate_pyvenv

    activate_pyvenv(venv_path)


@envs_app.command(name="available")
def envs_available():
    """List available pre-built environments for installation."""

    def get_available_environments():
        """Get available environments from the API."""
        from qbraid_core.services.environments.client import EnvironmentManagerClient

        emc = EnvironmentManagerClient()
        return emc.get_available_environments()

    try:
        result = run_progress_task(
            get_available_environments,
            description="Fetching available environments...",
            error_message="Failed to fetch available environments",
        )
    except QbraidException:
        # If API fails, show a helpful message
        console = Console()
        console.print(
            "[yellow]Unable to fetch available environments from qBraid service.[/yellow]"
        )
        console.print("This feature requires:")
        console.print("• qBraid Lab environment, or")
        console.print("• Valid qBraid API credentials configured")
        console.print("\nTo configure credentials, run: [bold]qbraid configure[/bold]")
        return

    console = Console()
    environments = result.get("environments", [])

    if not environments:
        console.print("No environments available for installation.")
        return

    # Check if we're on cloud or local
    is_cloud = any(env.get("available_for_installation", False) for env in environments)

    # Display header
    if is_cloud:
        status_text = "[bold green]✓ Available for installation[/bold green]"
    else:
        status_text = "[bold yellow]⚠ Not available (local environment)[/bold yellow]"

    console.print(f"\n# Available qBraid Environments ({status_text})")
    console.print(f"# Total: {len(environments)} environments")
    console.print("#")
    console.print("")

    # Calculate column widths
    max_name_len = max(len(env.get("displayName", env.get("name", ""))) for env in environments)
    max_slug_len = max(len(env.get("slug", "")) for env in environments)
    name_width = min(max_name_len + 2, 30)
    slug_width = min(max_slug_len + 2, 20)

    # Display environments
    for env in environments:
        name = env.get("displayName", env.get("name", "N/A"))
        slug = env.get("slug", "N/A")
        description = env.get("description", "No description")
        available = env.get("available_for_installation", False)

        # Truncate long names/slugs
        if len(name) > 28:
            name = name[:25] + "..."
        if len(slug) > 18:
            slug = slug[:15] + "..."
        if len(description) > 60:
            description = description[:57] + "..."

        status_icon = "✓" if available else "⚠"
        status_color = "green" if available else "yellow"

        console.print(
            f"[{status_color}]{status_icon}[/{status_color}] "
            f"{name.ljust(name_width)} "
            f"[dim]({slug.ljust(slug_width)})[/dim] "
            f"{description}"
        )

    # Show usage hint
    console.print("")
    if is_cloud:
        console.print("[dim]To install an environment, note its slug and use:[/dim]")
        console.print("[dim]  qbraid envs install <slug>[/dim]")
    else:
        console.print("[dim]Environment installation is only available on qBraid Lab.[/dim]")
        console.print("[dim]Create custom environments with: qbraid envs create[/dim]")


@envs_app.command(name="info")
def envs_info(
    identifier: str = typer.Argument(..., help="Environment identifier (env_id or slug)"),
):
    """
    Get detailed information about an environment.

    Accepts either a local env_id or a cloud slug. Shows information from
    both local registry and cloud catalog when available.

    Examples:
        $ qbraid envs info qiskit_1.0       # By slug (cloud + local if installed)
        $ qbraid envs info a1b2             # By env_id (local only)
        $ qbraid envs info my_custom_abc123 # Custom environment
    """
    from qbraid_core.services.environments import EnvironmentRegistryManager

    console = Console()

    # Try to find in local registry first
    local_entry = None
    local_entries = []
    slug_to_query = None

    try:
        registry = EnvironmentRegistryManager()

        # First try by env_id (exact match)
        local_entry = registry.find_by_env_id(identifier)
        if local_entry:
            local_entries = [local_entry]
            slug_to_query = local_entry.slug  # May be None for local-only envs
        else:
            # Try by slug (may return multiple installations)
            local_entries = registry.find_all_by_slug(identifier)
            if local_entries:
                slug_to_query = identifier
            else:
                # Not found locally, try cloud with this identifier as slug
                slug_to_query = identifier
    except Exception:
        # Registry not available - try cloud only
        slug_to_query = identifier

    # Try to fetch from cloud API
    cloud_env = None
    if slug_to_query:
        try:
            from qbraid_core.services.environments.client import EnvironmentManagerClient

            def get_cloud_info():
                client = EnvironmentManagerClient()
                return client.get_environment_by_slug(slug_to_query)

            cloud_env = run_progress_task(
                get_cloud_info,
                description="Fetching environment details...",
                error_message="Failed to fetch from cloud",
            )
        except Exception:
            # Cloud lookup failed - that's OK if we have local info
            pass

    # If nothing found anywhere, exit with error
    if not local_entries and not cloud_env:
        console.print(f"[red]❌ Environment not found:[/red] {identifier}")
        console.print("[dim]Not found in local registry or cloud catalog.[/dim]")
        raise typer.Exit(1)

    # --- Display Cloud Info (if available) ---
    if cloud_env:
        name = cloud_env.get("displayName") or cloud_env.get("name") or "N/A"
        description = cloud_env.get("description") or "No description"
        owner = cloud_env.get("owner") or cloud_env.get("userId") or "Unknown"
        python_version = cloud_env.get("pythonVersion") or "Unknown"
        visibility = cloud_env.get("visibility") or "private"
        tags = cloud_env.get("tags") or []
        image_tag = cloud_env.get("imageTag") or cloud_env.get("image_tag") or "N/A"
        available = cloud_env.get("available_for_installation", False)

        visibility_colors = {"public": "green", "private": "yellow", "shared": "cyan"}
        vis_color = visibility_colors.get(visibility, "white")

        console.print(f"\n📦 [bold]{name}[/bold]")
        console.print(f"   [dim]{description}[/dim]")

        console.print(f"\n[bold]☁️  Cloud Info:[/bold]")
        console.print(f"   Slug:            {slug_to_query}")
        console.print(f"   Owner:           {owner}")
        console.print(f"   Python:          {python_version}")
        console.print(f"   Visibility:      [{vis_color}]{visibility}[/{vis_color}]")
        console.print(f"   Image Tag:       {image_tag}")

        if tags:
            console.print(f"   Tags:            {', '.join(tags)}")

        # Publish status
        review_status = cloud_env.get("reviewStatus")
        if review_status:
            status_colors = {
                "none": "dim",
                "requested": "yellow",
                "pending": "cyan",
                "approved": "green",
                "denied": "red",
            }
            color = status_colors.get(review_status, "white")
            console.print(f"   Publish Status:  [{color}]{review_status}[/{color}]")

    # --- Display Local Info (if available) ---
    if local_entries:
        # If no cloud info, show header from local entry
        if not cloud_env:
            entry = local_entries[0]
            console.print(f"\n📦 [bold]{entry.name}[/bold]")
            if entry.description:
                console.print(f"   [dim]{entry.description}[/dim]")

        console.print(
            f"\n[bold]💻 Local Installation{'s' if len(local_entries) > 1 else ''}:[/bold]"
        )

        for entry in local_entries:
            kernel_status = "✓ kernel" if entry.has_kernel else "○ no kernel"
            env_type = entry.type.value if hasattr(entry.type, "value") else str(entry.type)

            console.print(f"\n   [bold]env_id:[/bold] {entry.env_id}")
            console.print(f"   Path:            {entry.path}")
            console.print(f"   Type:            {env_type}")
            if entry.python_version:
                console.print(f"   Python:          {entry.python_version}")
            if entry.python_executable:
                console.print(f"   Executable:      {entry.python_executable}")
            if entry.platform:
                console.print(f"   Platform:        {entry.platform}")
            if entry.kernel_name:
                console.print(f"   Kernel:          {entry.kernel_name} [{kernel_status}]")
            else:
                console.print(f"   Kernel:          [{kernel_status}]")
            if entry.shell_prompt:
                console.print(f"   Shell Prompt:    {entry.shell_prompt}")
            if entry.installed_at:
                console.print(f"   Installed:       {entry.installed_at}")
            elif entry.registered_at:
                console.print(f"   Registered:      {entry.registered_at}")
            if entry.slug:
                console.print(f"   Slug:            {entry.slug}")
    elif cloud_env:
        console.print(f"\n[bold]💻 Local Installation:[/bold]")
        console.print(f"   [dim]Not installed locally[/dim]")

    # --- Show Actions ---
    console.print(f"\n[bold]Actions:[/bold]")

    if cloud_env:
        available = cloud_env.get("available_for_installation", False)
        visibility = cloud_env.get("visibility", "private")

        if available and not local_entries:
            console.print(f"   Install:  [bold]qbraid envs install {slug_to_query}[/bold]")
        if visibility == "private":
            console.print(f"   Share:    [bold]qbraid envs share {slug_to_query} <email>[/bold]")
            console.print(f"   Publish:  [bold]qbraid envs publish {slug_to_query}[/bold]")

    if local_entries:
        entry = local_entries[0]
        if not entry.slug:
            # Local-only environment - can be uploaded
            console.print(f"   Upload:   [bold]qbraid envs upload {entry.env_id}[/bold]")
        if not entry.has_kernel:
            console.print(f"   Add kernel: [bold]qbraid kernels add {entry.env_id}[/bold]")
        console.print(f"   Activate: [bold]qbraid envs activate {entry.env_id}[/bold]")
        console.print(f"   Remove:   [bold]qbraid envs remove {entry.env_id}[/bold]")


@envs_app.command(name="install")
def envs_install(
    env_slug: str = typer.Argument(
        ..., help="Environment slug to install (from 'qbraid envs available')"
    ),
    temp: bool = typer.Option(
        False, "--temp", "-t", help="Install as temporary environment (faster, non-persistent)"
    ),
    target_dir: str = typer.Option(
        None,
        "--target",
        help="Custom target directory (defaults to ~/.qbraid/environments or /opt/environments)",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Automatically overwrite existing environment without prompting"
    ),
):
    """Install a pre-built environment from cloud storage."""

    async def install_environment_async():
        """Async wrapper for environment installation."""
        from pathlib import Path

        from qbraid_core.services.environments.client import EnvironmentManagerClient

        # Determine target directory
        if target_dir:
            install_dir = target_dir
        elif temp:
            install_dir = "/opt/environments"
        else:
            install_dir = str(Path.home() / ".qbraid" / "environments")

        console = Console()

        # Check if we're on qBraid Lab for non-temp installs
        emc = EnvironmentManagerClient()
        is_cloud = emc.running_in_lab()

        if not temp and not is_cloud:
            console.print(
                "[red]❌ Environment installation requires qBraid Lab or use --temp flag[/red]"
            )
            console.print("💡 Try: [bold]qbraid envs install {env_slug} --temp[/bold]")
            raise typer.Exit(1)

        if temp and not is_cloud:
            console.print(
                "[yellow]⚠️  Local temporary install - environment won't persist after restart[/yellow]"
            )

        # Install environment
        try:
            console.print(f"🚀 Installing environment: [bold]{env_slug}[/bold]")
            if temp:
                console.print(f"📂 Target: [dim]{install_dir}[/dim] (temporary)")
            else:
                console.print(f"📂 Target: [dim]{install_dir}[/dim] (persistent)")
            console.print("")

            progress_columns = (
                SpinnerColumn(),
                TextColumn("{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
                TimeElapsedColumn(),
            )

            with Progress(*progress_columns, transient=True) as progress:
                tasks: dict[str, int] = {}

                def get_task(stage: str, description: str, total: Optional[int]) -> int:
                    task_id = tasks.get(stage)
                    if task_id is None:
                        task_total = total if total and total > 0 else None
                        task_id = progress.add_task(description, total=task_total)
                        tasks[stage] = task_id
                    return task_id

                def progress_callback(stage: str, completed: int, total: int) -> None:
                    total_value = total if total and total > 0 else None
                    if stage == "download":
                        task_id = get_task("download", "Downloading environment...", total_value)
                        task = progress.tasks[task_id]
                        if total_value and (task.total is None or task.total == 0):
                            progress.update(task_id, total=total_value)
                        progress.update(task_id, completed=completed)
                    elif stage == "extract":
                        task_id = get_task("extract", "Extracting files...", total_value)
                        task = progress.tasks[task_id]
                        if total_value:
                            if task.total is None or task.total == 0:
                                progress.update(task_id, total=total_value)
                            progress.update(task_id, completed=completed)
                        else:
                            progress.update(task_id, completed=task.completed + 1)

                result = await emc.install_environment_from_storage(
                    slug=env_slug,
                    target_dir=install_dir,
                    temp=temp,
                    overwrite=yes,
                    progress_callback=progress_callback,
                )

            console.print("")
            console.print(f"[green]✅ Installation completed![/green]")
            console.print(f"📍 Location: [bold]{result['target_dir']}[/bold]")
            if "size_mb" in result:
                console.print(f"💾 Size: [dim]{result['size_mb']:.1f} MB[/dim]")
            if "env_id" in result:
                console.print(f"🆔 Env ID: [dim]{result['env_id']}[/dim]")

            if temp:
                console.print(
                    "[yellow]⚠️  Temporary environment - will be deleted on pod restart[/yellow]"
                )

            env_activation_id = result.get("env_id", env_slug)
            console.print("")
            console.print("🎯 Next steps:")
            console.print(f"• Activate: [bold]qbraid envs activate {env_activation_id}[/bold]")
            console.print(f"• List all: [bold]qbraid envs list[/bold]")

        except Exception as e:
            if isinstance(e, EnvironmentValidationError) and "already exists" in str(e):
                console.print(
                    "[yellow]⚠️ Installation skipped: Environment already exists.[/yellow]"
                )
            else:
                console.print(f"[red]❌ Installation failed: {e}[/red]")
            raise typer.Exit(1)

    # Run async function
    import asyncio

    try:
        asyncio.run(install_environment_async())
    except KeyboardInterrupt:
        console = Console()
        console.print("\n[yellow]⚠️  Installation cancelled by user[/yellow]")
        raise typer.Exit(1)


@envs_app.command(name="upload")
def envs_upload(
    identifier: str = typer.Argument(..., help="Environment name (if unique) or env_id to upload"),
    overwrite: bool = typer.Option(
        False, "--overwrite", "-o", help="Overwrite existing uploaded environment"
    ),
):
    """
    Upload environment to qBraid cloud storage (private by default).

    This uploads your local environment to make it available for sharing
    with specific users. Use 'qbraid envs publish' after upload to request
    public visibility.

    Examples:
        $ qbraid envs upload my_custom_env
        $ qbraid envs upload a1b2 --overwrite
    """
    import asyncio

    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    async def upload_environment_async():
        """Async wrapper for environment upload."""
        client = EnvironmentManagerClient()

        progress_columns = (
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
        )

        with Progress(*progress_columns, console=console, transient=False) as progress:
            tasks: dict[str, int] = {}

            def get_task(stage: str, description: str, total: Optional[int]) -> int:
                task_id = tasks.get(stage)
                if task_id is None:
                    task_total = total if total and total > 0 else 100
                    task_id = progress.add_task(description, total=task_total)
                    tasks[stage] = task_id
                return task_id

            def progress_callback(stage: str, completed: int, total: int) -> None:
                total_value = total if total and total > 0 else 100
                if stage == "prepare":
                    task_id = get_task("prepare", "📋 Preparing environment...", total_value)
                    progress.update(task_id, completed=completed, total=total_value)
                elif stage == "archive":
                    task_id = get_task("archive", "📦 Creating archive...", total_value)
                    progress.update(task_id, completed=completed, total=total_value)
                elif stage == "upload":
                    task_id = get_task("upload", "☁️  Uploading to cloud...", total_value)
                    progress.update(task_id, completed=completed, total=total_value)

            result = await client.upload_environment(
                identifier=identifier,
                overwrite=overwrite,
                progress_callback=progress_callback,
            )

        return result

    console.print(f"🚀 Uploading environment: [bold]{identifier}[/bold]\n")

    try:
        result = asyncio.run(upload_environment_async())

        console.print(f"\n[green]✅ Upload completed![/green]")
        console.print(f"📍 Slug: [bold]{result.get('slug', 'N/A')}[/bold]")
        console.print(f"🆔 Env ID: {result.get('env_id', 'N/A')}")
        if result.get("bucket"):
            console.print(f"☁️  Bucket: {result.get('bucket')}")

        console.print(f"\n🎯 Next steps:")
        console.print(
            f"   • Share privately: [bold]qbraid envs share {result.get('slug')} <email>[/bold]"
        )
        console.print(f"   • Request public: [bold]qbraid envs publish {result.get('slug')}[/bold]")

    except KeyboardInterrupt:
        console.print("\n[yellow]⚠️  Upload cancelled by user[/yellow]")
        raise typer.Exit(1)
    except Exception as err:
        console.print(f"\n[red]❌ Upload failed:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="publish")
def envs_publish(
    slug: str = typer.Argument(..., help="Environment slug (from upload)"),
):
    """
    Request to publish environment to the public catalog.

    This submits your uploaded environment for admin review. Once approved,
    it will be publicly visible and installable by all users.

    The environment must be uploaded first with 'qbraid envs upload'.

    Examples:
        $ qbraid envs publish my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def request_publish():
        client = EnvironmentManagerClient()
        return client.request_publish(slug)

    console.print(f"📤 Requesting to publish: [bold]{slug}[/bold]\n")

    try:
        result = run_progress_task(
            request_publish,
            description="Submitting publish request...",
            error_message="Failed to submit publish request",
        )

        console.print(f"\n[green]✅ Publish request submitted![/green]")
        console.print(f"📍 Slug: [bold]{slug}[/bold]")
        console.print(f"📊 Status: [yellow]requested[/yellow]")
        console.print(f"\n💡 Your request will be reviewed by qBraid admins.")
        console.print(f"   Check status with: [bold]qbraid envs publish-status {slug}[/bold]")

    except Exception as err:
        error_msg = str(err)
        if "already" in error_msg.lower():
            console.print(f"[yellow]⚠️  {error_msg}[/yellow]")
        else:
            console.print(f"[red]❌ Failed to request publish:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="publish-status")
def envs_publish_status(
    slug: str = typer.Argument(..., help="Environment slug to check"),
):
    """
    Check the publishing status of an environment.

    Status values:
        - none: Not submitted for publishing
        - requested: Waiting for admin review
        - pending: Under admin review
        - approved: Published to public catalog
        - denied: Publish request was denied

    Examples:
        $ qbraid envs publish-status my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def get_status():
        client = EnvironmentManagerClient()
        return client.get_publish_status(slug)

    try:
        status = run_progress_task(
            get_status,
            description="Checking publish status...",
            error_message="Failed to get publish status",
        )

        # Color-code status
        status_colors = {
            "none": "dim",
            "requested": "yellow",
            "pending": "cyan",
            "approved": "green",
            "denied": "red",
        }
        color = status_colors.get(status, "white")

        console.print(f"\n📊 Publish Status for [bold]{slug}[/bold]")
        console.print(f"   Status: [{color}]{status}[/{color}]")

        # Show helpful next steps
        if status == "none":
            console.print(f"\n💡 To request publishing: [bold]qbraid envs publish {slug}[/bold]")
        elif status == "requested":
            console.print(f"\n⏳ Waiting for admin review...")
            console.print(f"   To cancel: [bold]qbraid envs publish-cancel {slug}[/bold]")
        elif status == "pending":
            console.print(f"\n🔍 Currently under admin review...")
        elif status == "approved":
            console.print(f"\n🎉 Environment is publicly available!")
            console.print(f"   Install with: [bold]qbraid envs install {slug}[/bold]")
        elif status == "denied":
            console.print(f"\n❌ Publish request was denied.")
            console.print(f"   To resubmit: [bold]qbraid envs publish {slug}[/bold]")

    except Exception as err:
        console.print(f"[red]❌ Failed to get status:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="publish-cancel")
def envs_publish_cancel(
    slug: str = typer.Argument(..., help="Environment slug"),
):
    """
    Cancel a pending publish request.

    This withdraws your publish request before it's approved.
    You can resubmit later with 'qbraid envs publish'.

    Examples:
        $ qbraid envs publish-cancel my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def revoke_request():
        client = EnvironmentManagerClient()
        return client.revoke_publish_request(slug)

    console.print(f"🚫 Cancelling publish request for: [bold]{slug}[/bold]\n")

    try:
        result = run_progress_task(
            revoke_request,
            description="Cancelling publish request...",
            error_message="Failed to cancel publish request",
        )

        console.print(f"[green]✅ Publish request cancelled.[/green]")
        console.print(f"   Environment remains private/shared only.")
        console.print(f"\n💡 To resubmit: [bold]qbraid envs publish {slug}[/bold]")

    except Exception as err:
        console.print(f"[red]❌ Failed to cancel:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="publish-review")
def envs_publish_review(
    slug: str = typer.Argument(..., help="Environment slug to review"),
):
    """
    (Admin) Mark an environment as under review.

    This transitions the environment from 'requested' to 'pending' status,
    indicating an admin is actively reviewing it.

    Examples:
        $ qbraid envs publish-review my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def set_pending():
        client = EnvironmentManagerClient()
        return client.set_publish_pending(slug)

    console.print(f"🔍 Marking as under review: [bold]{slug}[/bold]\n")

    try:
        result = run_progress_task(
            set_pending,
            description="Updating status to pending...",
            error_message="Failed to update status",
        )

        console.print(f"[green]✅ Environment marked as under review.[/green]")
        console.print(f"   Status: [cyan]pending[/cyan]")
        console.print(f"\n💡 Next steps:")
        console.print(f"   • Approve: [bold]qbraid envs publish-approve {slug}[/bold]")
        console.print(f'   • Deny: [bold]qbraid envs publish-deny {slug} --message "reason"[/bold]')

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print(f"[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="publish-approve")
def envs_publish_approve(
    slug: str = typer.Argument(..., help="Environment slug to approve"),
):
    """
    (Admin) Approve and publish an environment to the public catalog.

    This makes the environment publicly visible and installable by all users.

    Examples:
        $ qbraid envs publish-approve my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def approve():
        client = EnvironmentManagerClient()
        return client.approve_publish(slug)

    console.print(f"✅ Approving environment: [bold]{slug}[/bold]\n")

    try:
        result = run_progress_task(
            approve, description="Approving and publishing...", error_message="Failed to approve"
        )

        console.print(f"[green]✅ Environment published successfully![/green]")
        console.print(f"   Slug: [bold]{slug}[/bold]")
        console.print(f"   Visibility: [green]public[/green]")
        console.print(f"\n🎉 Users can now install with:")
        console.print(f"   [bold]qbraid envs install {slug}[/bold]")

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print(f"[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="publish-deny")
def envs_publish_deny(
    slug: str = typer.Argument(..., help="Environment slug to deny"),
    message: Optional[str] = typer.Option(
        None, "--message", "-m", help="Reason for denial (sent to owner)"
    ),
):
    """
    (Admin) Deny a publish request.

    The owner will be notified with the denial reason.

    Examples:
        $ qbraid envs publish-deny my_env_abc123
        $ qbraid envs publish-deny my_env_abc123 --message "Missing documentation"
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def deny():
        client = EnvironmentManagerClient()
        return client.deny_publish(slug, message=message)

    console.print(f"❌ Denying publish request: [bold]{slug}[/bold]")
    if message:
        console.print(f"   Reason: {message}")
    console.print("")

    try:
        result = run_progress_task(
            deny, description="Denying publish request...", error_message="Failed to deny"
        )

        console.print(f"[yellow]✅ Publish request denied.[/yellow]")
        console.print(f"   Owner has been notified.")

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print(f"[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="share")
def envs_share(
    slug: str = typer.Argument(..., help="Environment slug to share"),
    email: str = typer.Argument(..., help="Email of user to share with"),
    read: bool = typer.Option(
        True, "--read/--no-read", help="Grant read permission (view environment)"
    ),
    write: bool = typer.Option(
        False, "--write", help="Grant write permission (modify environment)"
    ),
    execute: bool = typer.Option(
        True, "--execute/--no-execute", help="Grant execute permission (install environment)"
    ),
):
    """
    Share an environment with another user.

    By default, grants read and execute permissions (user can view and install).
    Use --write to also allow modifications.

    The environment must be uploaded first with 'qbraid envs upload'.

    Examples:
        $ qbraid envs share my_env_abc123 colleague@example.com
        $ qbraid envs share my_env_abc123 collaborator@example.com --write
        $ qbraid envs share my_env_abc123 viewer@example.com --no-execute
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    # Build permissions list
    permissions = []
    if read:
        permissions.append("read")
    if write:
        permissions.append("write")
    if execute:
        permissions.append("execute")

    if not permissions:
        console.print("[red]❌ Error:[/red] At least one permission must be granted.")
        raise typer.Exit(1)

    def share():
        client = EnvironmentManagerClient()
        return client.share_environment(
            slug=slug, target_type="user", email=email, permissions=permissions
        )

    console.print(f"🔗 Sharing environment: [bold]{slug}[/bold]")
    console.print(f"   With: {email}")
    console.print(f"   Permissions: {', '.join(permissions)}\n")

    try:
        result = run_progress_task(
            share, description="Sharing environment...", error_message="Failed to share environment"
        )

        console.print(f"[green]✅ Environment shared successfully![/green]")
        console.print(f"   {email} can now access [bold]{slug}[/bold]")

        if execute:
            console.print(f"\n💡 They can install with: [bold]qbraid envs install {slug}[/bold]")

    except Exception as err:
        error_msg = str(err)
        if "not found" in error_msg.lower():
            console.print(f"[red]❌ Environment not found.[/red] Make sure it's uploaded first.")
        elif "owner" in error_msg.lower():
            console.print(f"[red]❌ Only the owner can share this environment.[/red]")
        else:
            console.print(f"[red]❌ Failed to share:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="unshare")
def envs_unshare(
    slug: str = typer.Argument(..., help="Environment slug"),
    email: str = typer.Argument(..., help="Email of user to revoke access from"),
):
    """
    Revoke access to a shared environment.

    This removes all permissions for the specified user.

    Examples:
        $ qbraid envs unshare my_env_abc123 former_colleague@example.com
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    def revoke():
        client = EnvironmentManagerClient()
        # Revoke all permissions
        return client.revoke_environment_access(
            slug=slug, target_type="user", email=email, permissions=["read", "write", "execute"]
        )

    console.print(f"🚫 Revoking access to: [bold]{slug}[/bold]")
    console.print(f"   From: {email}\n")

    try:
        result = run_progress_task(
            revoke, description="Revoking access...", error_message="Failed to revoke access"
        )

        console.print(f"[green]✅ Access revoked.[/green]")
        console.print(f"   {email} no longer has access to [bold]{slug}[/bold]")

    except Exception as err:
        error_msg = str(err)
        if "not found" in error_msg.lower():
            console.print(f"[red]❌ Environment not found.[/red]")
        elif "owner" in error_msg.lower():
            console.print(f"[red]❌ Only the owner can modify sharing settings.[/red]")
        else:
            console.print(f"[red]❌ Failed to revoke:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="shared")
def envs_shared(
    slug: str = typer.Argument(..., help="Environment slug to check"),
):
    """
    List users who have access to an environment.

    Shows all users with read or write access to the specified environment.

    Examples:
        $ qbraid envs shared my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient
    from rich.table import Table

    console = Console()

    def get_shared():
        client = EnvironmentManagerClient()
        return client.get_environment_shared_with(slug)

    try:
        result = run_progress_task(
            get_shared,
            description="Fetching shared users...",
            error_message="Failed to get shared users",
        )

        read_users = result.get("readAccessUsers", [])
        write_users = result.get("writeAccessUsers", [])

        console.print(f"\n📋 Sharing info for [bold]{slug}[/bold]\n")

        if not read_users and not write_users:
            console.print("[dim]This environment is not shared with anyone.[/dim]")
            console.print(f"\n💡 Share with: [bold]qbraid envs share {slug} <email>[/bold]")
            return

        # Create table
        table = Table(show_header=True, header_style="bold")
        table.add_column("Email", style="cyan")
        table.add_column("Name", style="dim")
        table.add_column("Permissions", style="green")

        # Track users we've already added (to avoid duplicates)
        seen_emails = set()

        # Add write users first (they have more permissions)
        for user in write_users:
            email = user.get("email", "N/A")
            name = user.get("name", "")
            if email not in seen_emails:
                table.add_row(email, name, "read, write, execute")
                seen_emails.add(email)

        # Add read-only users
        for user in read_users:
            email = user.get("email", "N/A")
            name = user.get("name", "")
            if email not in seen_emails:
                table.add_row(email, name, "read, execute")
                seen_emails.add(email)

        console.print(table)
        console.print(f"\n[dim]Total: {len(seen_emails)} user(s)[/dim]")

    except Exception as err:
        error_msg = str(err)
        if "not found" in error_msg.lower():
            console.print(f"[red]❌ Environment not found.[/red]")
        elif "owner" in error_msg.lower():
            console.print(f"[red]❌ Only the owner can view sharing settings.[/red]")
        else:
            console.print(f"[red]❌ Failed to get shared users:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="add-path")
def envs_add_path(
    path: Path = typer.Argument(..., exists=True, dir_okay=True, file_okay=False),
    alias: Optional[str] = typer.Option(None, "--alias", "-a", help="Alias for the environment"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Name/slug for the environment"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y"),
):
    """
    Register an external Python environment with qBraid.

    This allows you to use existing Python environments (conda, venv, etc.)
    with qBraid commands like kernel management and activation.

    Examples:
        $ qbraid envs add-path /path/to/my_env --alias myenv
        $ qbraid envs add-path ~/conda/envs/quantum --name quantum_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def register():
        emc = EnvironmentManagerClient()
        result = emc.register_external_environment(
            path=path,
            name=alias or name or path.name,
        )
        return result

    # Get info first to show user
    try:
        emc = EnvironmentManagerClient()
        # Do a dry run to validate and get info
        from qbraid_core.system.executables import is_valid_python

        python_candidates = [
            path / "bin" / "python",
            path / "bin" / "python3",
            path / "Scripts" / "python.exe",
        ]

        python_path = None
        for candidate in python_candidates:
            if is_valid_python(candidate):
                python_path = candidate
                break

        if not python_path:
            handle_error(
                error_type="ValidationError", message=f"No valid Python executable found in {path}"
            )
            return

        # Confirm with user
        if not auto_confirm:
            console = Console()
            console.print("\n[bold]📦 Registering external environment:[/bold]")
            console.print(f"   Path: {path}")
            console.print(f"   Name: {alias or name or path.name}")
            console.print(f"   Python: {python_path}")

            if not typer.confirm("\nProceed with registration?"):
                typer.echo("❌ Registration cancelled.")
                return

        result = run_progress_task(
            register,
            description="Registering environment...",
            error_message="Failed to register environment",
        )

        typer.echo(f"\n✅ Environment '{result['name']}' registered successfully!")
        typer.echo(f"   Env ID: {result['env_id']}")
        typer.echo(f"\nYou can now:")
        typer.echo(f"   - Add kernel: qbraid kernels add {result['name']}")
        typer.echo(f"   - View in list: qbraid envs list")

    except Exception as e:
        handle_error(message=str(e))


@envs_app.command(name="remove-path")
def envs_remove_path(
    name: str = typer.Argument(..., help="Name or alias of environment to unregister"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y"),
):
    """
    Unregister an external environment from qBraid.

    This only removes the environment from qBraid's registry.
    The actual environment files are NOT deleted.
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def unregister(slug: str):
        emc = EnvironmentManagerClient()
        result = emc.unregister_external_environment(slug)
        return result

    # Find environment
    try:
        from qbraid_core.services.environments.registry import EnvironmentRegistryManager

        registry_mgr = EnvironmentRegistryManager()
        # Try to find by name first, then by env_id
        found = registry_mgr.find_by_name(name)
        if not found:
            found = registry_mgr.find_by_env_id(name)

        if not found:
            handle_error(
                error_type="NotFoundError",
                message=f"Environment '{name}' not found in registry. "
                "Use name (if unique) or env_id to reference the environment.",
            )
            return

        env_id, entry = found

        if entry.type != "external":
            console = Console()
            console.print(
                f"[yellow]⚠️  Warning: '{name}' is a qBraid-managed environment.[/yellow]"
            )
            console.print(f"   Use 'qbraid envs remove --name {name}' to fully remove it.")
            return

        if not auto_confirm:
            console = Console()
            console.print(f"\n[yellow]⚠️  Unregistering environment '{entry.name}'[/yellow]")
            console.print(f"   Env ID: {env_id}")
            console.print(f"   Path: {entry.path}")
            console.print(f"   Type: {entry.type}")
            console.print(f"\n   Note: Files at {entry.path} will NOT be deleted.")

            if not typer.confirm("\nProceed?"):
                typer.echo("❌ Unregistration cancelled.")
                return

        result = run_progress_task(
            unregister,
            env_id,  # Can be name or env_id - method handles both
            description="Unregistering environment...",
            error_message="Failed to unregister environment",
        )

        typer.echo(f"✅ Environment '{name}' unregistered from qBraid.")

    except Exception as e:
        handle_error(message=str(e))


@envs_app.command(name="sync")
def envs_sync():
    """
    Synchronize environment registry with filesystem.

    This will:
    - Remove registry entries for deleted environments
    - Auto-discover new environments in default paths
    - Verify all registered paths still exist
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def sync():
        emc = EnvironmentManagerClient()
        stats = emc.sync_registry()
        return stats

    result = run_progress_task(
        sync,
        description="Synchronizing environment registry...",
        error_message="Failed to sync registry",
    )

    console = Console()

    if result["discovered"] > 0:
        console.print(
            f"[green]✅ Registry synced: {result['discovered']} new environment(s) discovered[/green]"
        )
    elif result["removed"] > 0:
        console.print(
            f"[green]✅ Registry synced: {result['removed']} invalid entry(ies) removed[/green]"
        )
    else:
        console.print("[green]✅ Registry synced: No changes detected[/green]")

    # Show summary
    console.print(f"\n[bold]Summary:[/bold]")
    console.print(f"   Verified: {result['verified']}")
    console.print(f"   Discovered: {result['discovered']}")
    console.print(f"   Removed: {result['removed']}")


if __name__ == "__main__":
    envs_app()
