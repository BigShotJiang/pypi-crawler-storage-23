# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid envs namespace

"""

from .app import envs_app

__all__ = ["envs_app"]
