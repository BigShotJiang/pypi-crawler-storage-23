# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid user' namespace.

"""

import rich
import typer

from qbraid_cli.handlers import run_progress_task

account_app = typer.Typer(help="Manage qBraid account.", no_args_is_help=True)


@account_app.command(name="credits")
def account_credits():
    """Get number of qBraid credits remaining."""

    def get_credits() -> float:
        from qbraid_core.client import QbraidClientV1

        client = QbraidClientV1()
        return client.user_credits_value()

    qbraid_credits: float = run_progress_task(get_credits)
    typer.secho(
        f"{typer.style('qBraid credits remaining:')} "
        f"{typer.style(f'{qbraid_credits:.4f}', fg=typer.colors.MAGENTA, bold=True)}",
        nl=True,  # Ensure a newline after output (default is True)
    )
    rich.print("\nFor more information, visit: https://docs.qbraid.com/v2/home/pricing#credits")


if __name__ == "__main__":
    account_app()
