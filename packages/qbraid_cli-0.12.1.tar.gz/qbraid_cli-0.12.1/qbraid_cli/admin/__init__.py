# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid admin namespace

"""

from .app import admin_app

__all__ = ["admin_app"]
