from __future__ import annotations


MAX_STACK_VAR_SIZE = 2 * 1024 * 1024


__all__ = ("MAX_STACK_VAR_SIZE",)
