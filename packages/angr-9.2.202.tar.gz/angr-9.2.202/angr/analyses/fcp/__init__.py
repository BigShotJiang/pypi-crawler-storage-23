from __future__ import annotations
from .fcp import FastConstantPropagation

__all__ = ["FastConstantPropagation"]
