"""vibe-check: Security auditor for vibe-coded repos."""

__version__ = "0.1.0"
