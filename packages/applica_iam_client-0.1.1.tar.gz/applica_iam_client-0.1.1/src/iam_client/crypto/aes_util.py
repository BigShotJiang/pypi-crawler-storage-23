from __future__ import annotations

import base64
import os

from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Util.Padding import pad, unpad


class AesUtil:
    """AES-128-CBC encryption with PBKDF2 key derivation.

    Mirrors the TypeScript AesUtil using CryptoJS with SHA1 PBKDF2.
    """

    def __init__(self, key_size: int = 128, iteration_count: int = 1000) -> None:
        self._key_size = key_size // 8  # Convert bits to bytes
        self._iteration_count = iteration_count

    def generate_key(self, salt: str, passphrase: str) -> bytes:
        salt_bytes = bytes.fromhex(salt)
        return PBKDF2(
            passphrase,
            salt_bytes,
            dkLen=self._key_size,
            count=self._iteration_count,
            hmac_hash_module=None,  # defaults to SHA1 (matches CryptoJS)
        )

    def encrypt(self, salt: str, iv: str, passphrase: str, plain_text: str) -> str:
        key = self.generate_key(salt, passphrase)
        iv_bytes = bytes.fromhex(iv)
        cipher = AES.new(key, AES.MODE_CBC, iv_bytes)
        padded = pad(plain_text.encode("utf-8"), AES.block_size)
        encrypted = cipher.encrypt(padded)
        return base64.b64encode(encrypted).decode("utf-8")

    def decrypt(self, salt: str, iv: str, passphrase: str, cipher_text: str) -> str:
        key = self.generate_key(salt, passphrase)
        iv_bytes = bytes.fromhex(iv)
        cipher = AES.new(key, AES.MODE_CBC, iv_bytes)
        decrypted = unpad(cipher.decrypt(base64.b64decode(cipher_text)), AES.block_size)
        return decrypted.decode("utf-8")

    @staticmethod
    def random_hex(n_bytes: int = 16) -> str:
        return os.urandom(n_bytes).hex()
