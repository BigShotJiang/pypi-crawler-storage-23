from __future__ import annotations


class FailureResponse(Exception):
    """Exception raised when an IAM API call fails."""

    def __init__(self, message: str, *, handled: bool) -> None:
        super().__init__(message)
        self.message = message
        self.is_handled = handled

    @classmethod
    def handled(cls, message: str) -> FailureResponse:
        return cls(message, handled=True)

    @classmethod
    def unhandled(cls, message: str) -> FailureResponse:
        return cls(message, handled=False)

    def __repr__(self) -> str:
        kind = "handled" if self.is_handled else "unhandled"
        return f"FailureResponse({kind}, {self.message!r})"
