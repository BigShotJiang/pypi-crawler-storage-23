from __future__ import annotations

from types import TracebackType

from .http_client import HttpClient
from .services.auth import AuthService
from .services.device import DeviceService
from .services.project import ProjectService
from .services.role import RoleService
from .services.tenant import TenantService
from .services.user import UserService
from .storage.base import IStorage
from .storage.memory import MemoryStorage


class IamClient:
    """Centralized IAM client with all services."""

    def __init__(self, http: HttpClient) -> None:
        self.http = http
        self.auth = AuthService(http)
        self.users = UserService(http)
        self.tenants = TenantService(http)
        self.projects = ProjectService(http)
        self.roles = RoleService(http)
        self.devices = DeviceService(http)

    async def close(self) -> None:
        await self.http.close()

    async def __aenter__(self) -> IamClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()


def create_iam_client(
    *,
    api_url: str,
    storage: IStorage | None = None,
    api_key: str | None = None,
) -> IamClient:
    """Create an IamClient instance.

    Usage::

        async with create_iam_client(api_url="http://localhost:8081/api") as iam:
            await iam.auth.login({"username": "admin@example.com", "password": "secret"})
            tenants = await iam.tenants.search()
    """
    if storage is None:
        storage = MemoryStorage()
    http = HttpClient(api_url, storage, api_key)
    return IamClient(http)
