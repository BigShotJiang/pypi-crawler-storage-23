from __future__ import annotations


class MemoryStorage:
    """In-memory async key-value storage."""

    def __init__(self) -> None:
        self._data: dict[str, str] = {}

    async def get_item(self, key: str) -> str:
        return self._data.get(key, "")

    async def set_item(self, key: str, value: str) -> None:
        self._data[key] = str(value)

    async def remove_item(self, key: str) -> None:
        self._data.pop(key, None)
