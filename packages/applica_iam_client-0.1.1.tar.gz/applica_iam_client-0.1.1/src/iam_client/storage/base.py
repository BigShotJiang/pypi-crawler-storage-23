from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class IStorage(Protocol):
    """Async key-value storage interface."""

    async def get_item(self, key: str) -> str:
        """Return stored value or empty string if not found."""
        ...

    async def set_item(self, key: str, value: str) -> None:
        """Store a value."""
        ...

    async def remove_item(self, key: str) -> None:
        """Remove a value."""
        ...
