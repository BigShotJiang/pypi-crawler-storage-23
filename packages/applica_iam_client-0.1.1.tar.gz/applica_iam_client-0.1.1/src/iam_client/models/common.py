from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")


class BaseResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    response_code: str = Field(alias="responseCode")
    new_password: str | None = Field(default=None, alias="newPassword")


class Pageable(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    page: int | None = None
    rows_per_page: int | None = Field(default=None, alias="rowsPerPage")


class Page(BaseModel, Generic[T]):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    content: list[T] = []
    total_elements: int = Field(default=0, alias="totalElements")
    total_pages: int = Field(default=0, alias="totalPages")
    number: int = 0
    size: int = 0
