from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .common import BaseResponse, Page, Pageable


class Tenant(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = ""
    code: str = ""
    name: str = ""
    roles: list[str] | None = None
    metadata: dict[str, Any] | None = None
    domains: list[str] | None = None
    api_key: str | None = Field(default=None, alias="apiKey")


class TenantSearchRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    keyword: str | None = None
    pageable: Pageable | None = None


class TenantSearchResponse(BaseResponse):
    tenants: Page[Tenant] = Field(default_factory=lambda: Page[Tenant]())


class TenantResponse(BaseResponse):
    tenant: Tenant = Field(default_factory=Tenant)


class TenantRegisterResponse(BaseResponse):
    id: str = ""


class TenantRegisterRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    code: str
    name: str
    roles: list[str] | None = None
    metadata: dict[str, str] | None = None
    domains: list[str] | None = None


class TenantImportRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str | None = None
    code: str
    name: str
    roles: list[str] | None = None
    metadata: dict[str, str] | None = None
    domains: list[str] | None = None
    api_key: str | None = Field(default=None, alias="apiKey")


class TenantUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    tenant_id: str = Field(alias="tenantId")
    name: str | None = None
    roles: list[str] | None = None
    metadata: dict[str, str] | None = None
    domains: list[str] | None = None
