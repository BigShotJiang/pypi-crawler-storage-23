from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .common import BaseResponse, Page, Pageable


class Project(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = ""
    code: str = ""
    name: str = ""
    tenant_ids: list[str] | None = Field(default=None, alias="tenantIds")
    roles: list[str] | None = None
    metadata: dict[str, Any] | None = None
    api_key: str | None = Field(default=None, alias="apiKey")


class ProjectSearchRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    tenant_ids: list[str] | None = Field(default=None, alias="tenantIds")
    keyword: str | None = None
    pageable: Pageable | None = None


class ProjectSearchResponse(BaseResponse):
    projects: Page[Project] = Field(default_factory=lambda: Page[Project]())


class ProjectResponse(BaseResponse):
    project: Project = Field(default_factory=Project)


class ProjectRegisterResponse(BaseResponse):
    id: str | None = ""


class ProjectRegisterRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str | None = None
    tenant_ids: list[str] | None = Field(default=None, alias="tenantIds")
    code: str
    name: str
    roles: list[str] | None = None
    metadata: dict[str, str] | None = None
    api_key: str | None = Field(default=None, alias="apiKey")


class ProjectImportRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str | None = None
    tenant_ids: list[str] | None = Field(default=None, alias="tenantIds")
    code: str
    name: str
    roles: list[str] | None = None
    metadata: dict[str, str] | None = None
    api_key: str | None = Field(default=None, alias="apiKey")


class ProjectUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    project_id: str = Field(alias="projectId")
    name: str | None = None
    code: str | None = None
    roles: list[str] | None = None
    metadata: dict[str, str] | None = None
