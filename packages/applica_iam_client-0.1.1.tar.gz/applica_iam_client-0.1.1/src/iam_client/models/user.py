from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .common import BaseResponse, Page, Pageable


class User(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = ""
    email: str = ""
    name: str | None = None
    roles: list[str] | None = None
    active: bool | None = None
    profile: dict[str, Any] | None = None
    tenant_id: str | None = Field(default=None, alias="tenantId")
    project_id: str | None = Field(default=None, alias="projectId")
    tenant_ids: list[str] | None = Field(default=None, alias="tenantIds")
    project_ids: list[str] | None = Field(default=None, alias="projectIds")


class UserSearchRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    keyword: str | None = None
    username: str | None = None
    active: bool | None = None
    role: str | None = None
    profile: dict[str, str] | None = None
    pageable: Pageable | None = None


class UserSearchResponse(BaseResponse):
    users: Page[User] = Field(default_factory=lambda: Page[User]())


class UserResponse(BaseResponse):
    user: User = Field(default_factory=User)


class UserUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    user_id: str = Field(alias="userId")
    email: str | None = None
    clear_password: str | None = Field(default=None, alias="clearPassword")
    roles: list[str] | None = None
    active: bool | None = None
    finalized: bool | None = None
    profile: dict[str, str] | None = None
    replace_profile: bool | None = Field(default=None, alias="replaceProfile")
    tenant_id: str | None = Field(default=None, alias="tenantId")
    project_id: str | None = Field(default=None, alias="projectId")
    tenant_ids: list[str] | None = Field(default=None, alias="tenantIds")
    project_ids: list[str] | None = Field(default=None, alias="projectIds")


class UserUpdateRolesRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    user_id: str = Field(alias="userId")
    roles: list[str]


class UserImportRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str | None = None
    email: str
    clear_password: str | None = Field(default=None, alias="clearPassword")
    tenant_id: str | None = Field(default=None, alias="tenantId")
    project_id: str | None = Field(default=None, alias="projectId")
    roles: list[str] | None = None
    profile: dict[str, str] | None = None
    active_by_default: bool | None = Field(default=None, alias="activeByDefault")
    finalized: bool | None = None


class UserTenantRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    user_id: str = Field(alias="userId")
    tenant_id: str = Field(alias="tenantId")


class UserSetTenantsRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    user_id: str = Field(alias="userId")
    tenant_ids: list[str] = Field(alias="tenantIds")


class UserSetTenantRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    user_id: str = Field(alias="userId")
    tenant_id: str = Field(alias="tenantId")
    add_to_tenants: bool | None = Field(default=None, alias="addToTenants")


class UserSetProjectRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    user_id: str = Field(alias="userId")
    project_id: str = Field(alias="projectId")
    add_to_projects: bool | None = Field(default=None, alias="addToProjects")
