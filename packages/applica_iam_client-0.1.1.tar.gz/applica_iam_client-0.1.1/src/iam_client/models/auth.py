from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .common import BaseResponse


class AuthLogin(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    username: str
    password: str


class AuthIdentity(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    token: str = ""
    user: dict[str, Any] = {}
    permissions: Any = None


class AuthDevice(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    code: str = ""
    secret: str = ""


class AuthRegisterRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    name: str
    email: str
    password: str


class AuthRegisterResponse(BaseResponse):
    user_id: str = Field(default="", alias="userId")


class UpdateProfileRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    name: str


class AuthThirdPartyProviders(str, Enum):
    GOOGLE = "google"


class AuthThirdPartyLogin(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    provider: AuthThirdPartyProviders
    payload: Any
