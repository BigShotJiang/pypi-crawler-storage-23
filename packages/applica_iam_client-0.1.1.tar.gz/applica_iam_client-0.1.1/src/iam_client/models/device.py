from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from .common import BaseResponse, Page, Pageable


class Device(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = ""
    code: str = ""
    name: str | None = None
    secret: str | None = None
    registration_date: str | None = Field(default=None, alias="registrationDate")


class DeviceSearchRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    keyword: str | None = None
    pageable: Pageable | None = None


class DeviceSearchResponse(BaseResponse):
    devices: Page[Device] = Field(default_factory=lambda: Page[Device]())


class DeviceResponse(BaseResponse):
    device: Device = Field(default_factory=Device)


class DeviceRegisterRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    code: str


class DeviceUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    device_id: str = Field(alias="deviceId")
    code: str | None = None
    secret: str | None = None
