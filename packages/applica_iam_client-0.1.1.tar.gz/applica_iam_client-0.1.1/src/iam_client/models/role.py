from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .common import BaseResponse


class Role(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = ""
    code: str | None = ""
    name: str | None = ""
    tenant_id: str | None = Field(default=None, alias="tenantId")
    project_id: str | None = Field(default=None, alias="projectId")
    permissions: list[str] | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = Field(default=None, alias="createdAt")
    updated_at: str | None = Field(default=None, alias="updatedAt")


class RoleResponse(BaseResponse):
    role: Role = Field(default_factory=Role)


class RoleRegisterResponse(BaseResponse):
    id: str = ""
    role: Role = Field(default_factory=Role)


class RoleRegisterRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str | None = None
    tenant_id: str | None = Field(default=None, alias="tenantId")
    project_id: str | None = Field(default=None, alias="projectId")
    code: str
    name: str
    permissions: list[str] | None = None
    metadata: dict[str, str] | None = None


class RoleUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str
    tenant_id: str | None = Field(default=None, alias="tenantId")
    project_id: str | None = Field(default=None, alias="projectId")
    code: str | None = None
    name: str | None = None
    permissions: list[str] | None = None
    metadata: dict[str, str] | None = None
