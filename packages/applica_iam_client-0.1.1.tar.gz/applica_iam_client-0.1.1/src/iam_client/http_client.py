from __future__ import annotations

import json as _json
from typing import Any, Literal
from urllib.parse import urlencode

import httpx
from pydantic import BaseModel

from .errors import FailureResponse
from .models.common import BaseResponse
from .storage.base import IStorage


class HttpClient:
    """Async HTTP client for the IAM API."""

    def __init__(self, api_url: str, storage: IStorage, api_key: str | None = None) -> None:
        self._api_url = api_url.rstrip("/")
        self._storage = storage
        self._api_key = api_key
        self._http = httpx.AsyncClient(timeout=60.0)

    @property
    def api_url(self) -> str:
        return self._api_url

    @property
    def storage(self) -> IStorage:
        return self._storage

    async def get_token(self) -> str:
        return await self._storage.get_item("token")

    async def close(self) -> None:
        await self._http.aclose()

    async def request(
        self,
        path: str,
        *,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"] = "GET",
        body: Any = None,
        content_type: Literal["json", "form"] = "json",
        authenticated: bool = True,
    ) -> Any:
        url = f"{self._api_url}{path}"

        headers: dict[str, str] = {
            "Accept": "application/json",
        }

        # Set Content-Type unconditionally (matching TS behavior)
        if content_type == "json":
            headers["Content-Type"] = "application/json"
        elif content_type == "form":
            headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"

        # API key header
        if self._api_key:
            headers["x-api-key"] = self._api_key

        # Bearer token
        if authenticated:
            token = await self.get_token()
            if token:
                headers["Authorization"] = f"Bearer {token}"

        kwargs: dict[str, Any] = {"method": method, "url": url, "headers": headers}

        if body is not None:
            if content_type == "form":
                if isinstance(body, dict):
                    kwargs["content"] = urlencode(body)
                else:
                    kwargs["content"] = body
            else:
                # Manual JSON serialization (matching TS JSON.stringify behavior)
                if isinstance(body, BaseModel):
                    kwargs["content"] = body.model_dump_json(by_alias=True, exclude_none=True)
                else:
                    kwargs["content"] = _json.dumps(body)

        response = await self._http.request(**kwargs)

        if response.status_code == 401:
            raise FailureResponse.handled("iam.error.unauthorized")
        if response.status_code == 403:
            raise FailureResponse.handled("iam.error.not-authorized")
        if not response.is_success:
            raise FailureResponse.unhandled(response.reason_phrase or str(response.status_code))

        return response.json()

    async def request_and_validate(
        self,
        path: str,
        *,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"] = "GET",
        body: Any = None,
        content_type: Literal["json", "form"] = "json",
        authenticated: bool = True,
        response_model: type[BaseResponse] | None = None,
    ) -> Any:
        data = await self.request(
            path,
            method=method,
            body=body,
            content_type=content_type,
            authenticated=authenticated,
        )

        if response_model:
            result = response_model.model_validate(data)
            if result.response_code != "ok":
                raise FailureResponse.handled(result.response_code)
            return result

        response_code = data.get("responseCode", "")
        if response_code != "ok":
            raise FailureResponse.handled(response_code)

        return data
