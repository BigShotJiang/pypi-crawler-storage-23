from __future__ import annotations

from pydantic import BaseModel

from ..http_client import HttpClient
from ..models.common import BaseResponse
from ..models.role import (
    RoleRegisterRequest,
    RoleRegisterResponse,
    RoleResponse,
    RoleUpdateRequest,
)


class RoleService:
    """Role management operations."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def register(self, data: RoleRegisterRequest | dict) -> RoleRegisterResponse:
        return await self._http.request_and_validate(
            "/roles/register",
            method="POST",
            body=self._dump(data),
            response_model=RoleRegisterResponse,
        )

    async def update(self, data: RoleUpdateRequest | dict) -> RoleResponse:
        return await self._http.request_and_validate(
            "/roles/update",
            method="POST",
            body=self._dump(data),
            response_model=RoleResponse,
        )

    async def delete(self, role_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/roles/delete",
            method="POST",
            body={"id": role_id},
            response_model=BaseResponse,
        )

    async def get_by_id(self, role_id: str) -> RoleResponse:
        return await self._http.request_and_validate(
            "/roles/get-by-id",
            method="POST",
            body={"id": role_id},
            response_model=RoleResponse,
        )

    async def get_by_code(self, code: str, tenant_id: str | None = None) -> RoleResponse:
        body: dict = {"code": code}
        if tenant_id is not None:
            body["tenantId"] = tenant_id
        return await self._http.request_and_validate(
            "/roles/get-by-code",
            method="POST",
            body=body,
            response_model=RoleResponse,
        )

    @staticmethod
    def _dump(data: BaseModel | dict) -> dict:
        if isinstance(data, BaseModel):
            return data.model_dump(by_alias=True, exclude_none=True)
        return data
