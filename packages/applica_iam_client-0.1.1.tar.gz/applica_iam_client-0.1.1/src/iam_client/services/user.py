from __future__ import annotations

from pydantic import BaseModel

from ..http_client import HttpClient
from ..models.common import BaseResponse
from ..models.user import (
    UserImportRequest,
    UserResponse,
    UserSearchRequest,
    UserSearchResponse,
    UserSetProjectRequest,
    UserSetTenantRequest,
    UserSetTenantsRequest,
    UserTenantRequest,
    UserUpdateRequest,
    UserUpdateRolesRequest,
)


class UserService:
    """User management operations."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def get_by_id(self, user_id: str) -> UserResponse:
        return await self._http.request_and_validate(
            "/users/get-user-by-id",
            method="POST",
            body={"userId": user_id},
            response_model=UserResponse,
        )

    async def get_by_email(self, email: str) -> UserResponse:
        return await self._http.request_and_validate(
            "/users/get-user-by-email",
            method="POST",
            body={"email": email},
            response_model=UserResponse,
        )

    async def search(self, params: UserSearchRequest | dict | None = None) -> UserSearchResponse:
        body = self._dump(params) if params else {}
        return await self._http.request_and_validate(
            "/users/search-users",
            method="POST",
            body=body,
            response_model=UserSearchResponse,
        )

    async def update(self, data: UserUpdateRequest | dict) -> UserResponse:
        return await self._http.request_and_validate(
            "/users/update-user",
            method="POST",
            body=self._dump(data),
            response_model=UserResponse,
        )

    async def update_roles(self, data: UserUpdateRolesRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/update-user-roles",
            method="POST",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def delete(self, user_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/delete-user",
            method="POST",
            body={"userId": user_id},
            response_model=BaseResponse,
        )

    async def enable(self, user_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/enable-user",
            method="POST",
            body={"userId": user_id},
            response_model=BaseResponse,
        )

    async def disable(self, user_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/disable-user",
            method="POST",
            body={"userId": user_id},
            response_model=BaseResponse,
        )

    async def import_user(self, data: UserImportRequest | dict) -> UserResponse:
        return await self._http.request_and_validate(
            "/users/import-user",
            method="POST",
            body=self._dump(data),
            response_model=UserResponse,
        )

    async def add_to_tenant(self, data: UserTenantRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/add-user-to-tenant",
            method="POST",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def remove_from_tenant(self, data: UserTenantRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/remove-user-from-tenant",
            method="POST",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def set_tenants(self, data: UserSetTenantsRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/set-user-tenants",
            method="POST",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def set_tenant(self, data: UserSetTenantRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/set-tenant",
            method="POST",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def set_project(self, data: UserSetProjectRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/users/set-project",
            method="POST",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    @staticmethod
    def _dump(data: BaseModel | dict) -> dict:
        if isinstance(data, BaseModel):
            return data.model_dump(by_alias=True, exclude_none=True)
        return data
