from __future__ import annotations

from pydantic import BaseModel

from ..http_client import HttpClient
from ..models.common import BaseResponse
from ..models.tenant import (
    TenantImportRequest,
    TenantRegisterRequest,
    TenantRegisterResponse,
    TenantResponse,
    TenantSearchRequest,
    TenantSearchResponse,
    TenantUpdateRequest,
)


class TenantService:
    """Tenant management operations."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def search(self, params: TenantSearchRequest | dict | None = None) -> TenantSearchResponse:
        body = self._dump(params) if params else {}
        return await self._http.request_and_validate(
            "/tenants/search",
            method="POST",
            body=body,
            response_model=TenantSearchResponse,
        )

    async def get_by_id(self, tenant_id: str) -> TenantResponse:
        return await self._http.request_and_validate(
            "/tenants/by-id",
            method="POST",
            body={"tenantId": tenant_id},
            response_model=TenantResponse,
        )

    async def get_by_code(self, code: str) -> TenantResponse:
        return await self._http.request_and_validate(
            "/tenants/by-key",
            method="POST",
            body={"code": code},
            response_model=TenantResponse,
        )

    async def register(self, data: TenantRegisterRequest | dict) -> TenantRegisterResponse:
        return await self._http.request_and_validate(
            "/tenants/register",
            method="POST",
            body=self._dump(data),
            response_model=TenantRegisterResponse,
        )

    async def import_tenant(self, data: TenantImportRequest | dict) -> TenantRegisterResponse:
        return await self._http.request_and_validate(
            "/tenants/import",
            method="POST",
            body=self._dump(data),
            response_model=TenantRegisterResponse,
        )

    async def update(self, data: TenantUpdateRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/tenants",
            method="PATCH",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def delete(self, tenant_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/tenants",
            method="DELETE",
            body={"tenantId": tenant_id},
            response_model=BaseResponse,
        )

    @staticmethod
    def _dump(data: BaseModel | dict) -> dict:
        if isinstance(data, BaseModel):
            return data.model_dump(by_alias=True, exclude_none=True)
        return data
