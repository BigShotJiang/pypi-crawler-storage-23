from __future__ import annotations

import base64
import json
from typing import Any

from ..crypto.aes_util import AesUtil
from ..errors import FailureResponse
from ..http_client import HttpClient
from ..models.auth import (
    AuthDevice,
    AuthIdentity,
    AuthLogin,
    AuthRegisterRequest,
    AuthRegisterResponse,
    AuthThirdPartyLogin,
    UpdateProfileRequest,
)
from ..models.common import BaseResponse


class AuthService:
    """Authentication and session management."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    # ── Storage helpers ───────────────────────────────────────────

    @property
    def _storage(self):
        return self._http.storage

    async def _store_identity(self, identity: dict[str, Any]) -> None:
        """Persist auth data returned by login / token endpoints."""
        token = identity.get("token", "")
        if token:
            await self._storage.set_item("token", token)

        user = identity.get("user", {})
        email = user.get("email", "")
        if email:
            await self._storage.set_item("email", email)

        roles = user.get("roles", [])
        if roles:
            await self._storage.set_item("roles", json.dumps(roles))

        profile = user.get("profile", {})
        if profile:
            await self._storage.set_item("profile", json.dumps(profile))

        permissions = identity.get("permissions", [])
        if isinstance(permissions, list):
            await self._storage.set_item("permissions", ",".join(permissions))
        elif isinstance(permissions, str):
            await self._storage.set_item("permissions", permissions)

    async def _clear_auth(self) -> None:
        for key in ("token", "email", "roles", "profile", "permissions", "needToChangePassword"):
            await self._storage.remove_item(key)

    # ── Public Auth Endpoints (no Bearer) ─────────────────────────

    async def login(self, params: AuthLogin | dict) -> AuthIdentity:
        if isinstance(params, AuthLogin):
            username = params.username
            password = params.password
        else:
            username = params["username"]
            password = params["password"]

        try:
            data = await self._http.request(
                "/auth/login",
                method="POST",
                body={"mail": username, "password": password},
                content_type="form",
                authenticated=False,
            )
        except FailureResponse as exc:
            if exc.message == "iam.error.unauthorized":
                raise FailureResponse.handled("iam.error.invalid-credentials") from exc
            raise

        identity = AuthIdentity.model_validate(data)
        await self._store_identity(data)
        return identity

    async def register(self, data: AuthRegisterRequest | dict) -> AuthRegisterResponse:
        if isinstance(data, AuthRegisterRequest):
            body = data.model_dump(by_alias=True, exclude_none=True)
        else:
            body = data

        resp = await self._http.request(
            "/auth/register",
            method="POST",
            body=body,
            content_type="form",
            authenticated=False,
        )

        result = AuthRegisterResponse.model_validate(resp)
        if result.response_code != "ok":
            raise FailureResponse.handled(result.response_code)
        return result

    async def activate(self, activation_code: str) -> BaseResponse:
        resp = await self._http.request(
            "/auth/activate",
            method="POST",
            body={"activationCode": activation_code},
            content_type="form",
            authenticated=False,
        )

        result = BaseResponse.model_validate(resp)
        if result.response_code != "ok":
            raise FailureResponse.handled(result.response_code)
        return result

    async def recover(self, email: str) -> BaseResponse:
        resp = await self._http.request(
            "/auth/recover",
            method="POST",
            body={"email": email},
            content_type="form",
            authenticated=False,
        )

        result = BaseResponse.model_validate(resp)
        if result.response_code != "ok":
            raise FailureResponse.handled(result.response_code)
        return result

    async def third_party_login(self, params: AuthThirdPartyLogin | dict) -> AuthIdentity:
        if isinstance(params, AuthThirdPartyLogin):
            provider = params.provider.value
            payload = params.payload
        else:
            provider = params["provider"]
            payload = params["payload"]

        data = await self._http.request(
            "/auth/third-party-login",
            method="POST",
            body={"provider": provider, "payload": json.dumps(payload)},
            content_type="form",
            authenticated=False,
        )

        identity = AuthIdentity.model_validate(data)
        await self._store_identity(data)
        return identity

    async def validate_token(self, token: str) -> AuthIdentity:
        try:
            data = await self._http.request(
                "/auth/token-login",
                method="POST",
                body={"token": token},
                content_type="form",
                authenticated=False,
            )
        except FailureResponse:
            await self._clear_auth()
            raise

        identity = AuthIdentity.model_validate(data)
        await self._store_identity(data)
        return identity

    async def register_device(self, code: str) -> AuthDevice:
        data = await self._http.request(
            "/auth/register-device",
            method="POST",
            body={"code": code},
            content_type="json",
            authenticated=False,
        )

        response_code = data.get("responseCode", "")
        if response_code != "ok":
            raise FailureResponse.handled(response_code)

        device = AuthDevice.model_validate(data.get("device", {}))
        await self._storage.set_item("deviceCode", device.code)
        await self._storage.set_item("deviceSecret", device.secret)
        return device

    async def pin_login(self, device_code: str, pin: str) -> AuthIdentity:
        # Retrieve the device secret
        secret = await self._storage.get_item("deviceSecret")
        if not secret:
            raise FailureResponse.handled("iam.error.device-not-registered")

        # Encrypt the PIN
        aes = AesUtil(128, 1000)
        iv = AesUtil.random_hex(16)
        salt = AesUtil.random_hex(16)
        ciphertext = aes.encrypt(salt, iv, secret, pin)
        aes_password = f"{iv}::{salt}::{ciphertext}"
        encrypted_pin = base64.b64encode(aes_password.encode("utf-8")).decode("utf-8")

        data = await self._http.request(
            "/auth/pin-login",
            method="POST",
            body={"deviceCode": device_code, "encryptedPin": encrypted_pin},
            content_type="json",
            authenticated=False,
        )

        identity = AuthIdentity.model_validate(data)
        await self._store_identity(data)
        return identity

    # ── Authenticated Endpoints (Bearer) ──────────────────────────

    async def change_password(self, current_password: str, password: str) -> BaseResponse:
        resp = await self._http.request(
            "/auth/change-password",
            method="POST",
            body={"currentPassword": current_password, "password": password},
            content_type="form",
            authenticated=True,
        )

        result = BaseResponse.model_validate(resp)
        if result.response_code != "ok":
            raise FailureResponse.handled(result.response_code)
        await self._storage.remove_item("needToChangePassword")
        return result

    async def check_auth(self) -> AuthIdentity:
        token = await self._http.get_token()
        if not token:
            raise FailureResponse.handled("iam.error.unauthorized")
        return await self.validate_token(token)

    async def impersonate(self, user_id: str | int) -> AuthIdentity:
        # Save current admin state
        token = await self._storage.get_item("token")
        email = await self._storage.get_item("email")
        roles = await self._storage.get_item("roles")
        profile = await self._storage.get_item("profile")
        permissions = await self._storage.get_item("permissions")

        await self._storage.set_item("admin_token", token)
        await self._storage.set_item("admin_email", email)
        await self._storage.set_item("admin_roles", roles)
        await self._storage.set_item("admin_profile", profile)
        await self._storage.set_item("admin_permissions", permissions)

        data = await self._http.request(
            "/auth/impersonate",
            method="POST",
            body={"id": str(user_id)},
            content_type="form",
            authenticated=True,
        )

        identity = AuthIdentity.model_validate(data)
        await self._store_identity(data)
        await self._storage.set_item("impersonate", "true")
        return identity

    async def stop_impersonate(self) -> None:
        token = await self._storage.get_item("admin_token")
        email = await self._storage.get_item("admin_email")
        roles = await self._storage.get_item("admin_roles")
        profile = await self._storage.get_item("admin_profile")
        permissions = await self._storage.get_item("admin_permissions")

        await self._storage.set_item("token", token)
        await self._storage.set_item("email", email)
        await self._storage.set_item("roles", roles)
        await self._storage.set_item("profile", profile)
        await self._storage.set_item("permissions", permissions)
        await self._storage.set_item("impersonate", "false")

        for key in ("admin_token", "admin_email", "admin_roles", "admin_profile", "admin_permissions"):
            await self._storage.remove_item(key)

    async def reset_pin(self, user_id: str, pin_code: str) -> AuthIdentity:
        data = await self._http.request(
            "/auth/reset-pin",
            method="POST",
            body={"userId": user_id, "pinCode": pin_code},
            content_type="form",
            authenticated=True,
        )
        return AuthIdentity.model_validate(data)

    async def update_profile(self, profile_data: UpdateProfileRequest | dict) -> BaseResponse:
        if isinstance(profile_data, UpdateProfileRequest):
            body = {"data": profile_data.model_dump(by_alias=True, exclude_none=True)}
        else:
            body = {"data": profile_data}

        resp = await self._http.request(
            "/auth/update-profile",
            method="POST",
            body=body,
            content_type="json",
            authenticated=True,
        )

        result = BaseResponse.model_validate(resp)
        if result.response_code != "ok":
            raise FailureResponse.handled(result.response_code)
        return result

    # ── Session Helpers ───────────────────────────────────────────

    async def logout(self) -> None:
        await self._clear_auth()
        for key in (
            "impersonate",
            "admin_token",
            "admin_email",
            "admin_roles",
            "admin_profile",
            "admin_permissions",
            "deviceCode",
            "deviceSecret",
        ):
            await self._storage.remove_item(key)

    async def get_token(self) -> str:
        token = await self._http.get_token()
        if not token:
            raise FailureResponse.handled("iam.error.unauthorized")
        return token

    async def fresh_token(self) -> str:
        await self.check_auth()
        return await self.get_token()

    async def get_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        token = await self._http.get_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    async def get_permissions(self) -> list[str]:
        raw = await self._storage.get_item("permissions")
        if not raw:
            raise FailureResponse.handled("iam.error.unauthorized")
        return [p for p in raw.split(",") if p]

    async def get_roles(self) -> list[str]:
        raw = await self._storage.get_item("roles")
        if not raw:
            raise FailureResponse.handled("iam.error.unauthorized")
        return json.loads(raw)

    async def get_identity(self) -> AuthIdentity:
        email = await self._storage.get_item("email")
        if not email:
            raise FailureResponse.handled("iam.error.unauthorized")

        full_name = ""
        profile_raw = await self._storage.get_item("profile")
        if profile_raw:
            profile = json.loads(profile_raw)
            full_name = profile.get("fullName", "")

        roles_raw = await self._storage.get_item("roles")
        roles: list[dict[str, str]] = []
        if roles_raw:
            roles_list = json.loads(roles_raw)
            if isinstance(roles_list, list):
                roles = [{"id": r, "name": r} if isinstance(r, str) else r for r in roles_list]

        return AuthIdentity(
            token=await self._http.get_token(),
            user={"email": email, "fullName": full_name, "roles": roles},
        )

    async def get_device(self, code: str) -> AuthDevice:
        stored_code = await self._storage.get_item("deviceCode")
        if stored_code == code:
            secret = await self._storage.get_item("deviceSecret")
            if secret:
                return AuthDevice(code=code, secret=secret)
        return await self.register_device(code)

    async def is_impersonating(self) -> bool:
        val = await self._storage.get_item("impersonate")
        return val == "true"
