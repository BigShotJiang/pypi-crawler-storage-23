from __future__ import annotations

from pydantic import BaseModel

from ..http_client import HttpClient
from ..models.common import BaseResponse
from ..models.project import (
    ProjectImportRequest,
    ProjectRegisterRequest,
    ProjectRegisterResponse,
    ProjectResponse,
    ProjectSearchRequest,
    ProjectSearchResponse,
    ProjectUpdateRequest,
)


class ProjectService:
    """Project management operations."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def search(self, params: ProjectSearchRequest | dict | None = None) -> ProjectSearchResponse:
        body = self._dump(params) if params else {}
        return await self._http.request_and_validate(
            "/projects/search",
            method="POST",
            body=body,
            response_model=ProjectSearchResponse,
        )

    async def get_by_id(self, project_id: str, tenant_id: str | None = None) -> ProjectResponse:
        body: dict = {"projectId": project_id}
        if tenant_id is not None:
            body["tenantId"] = tenant_id
        return await self._http.request_and_validate(
            "/projects/by-id",
            method="POST",
            body=body,
            response_model=ProjectResponse,
        )

    async def get_by_code(self, code: str, tenant_id: str | None = None) -> ProjectResponse:
        body: dict = {"code": code}
        if tenant_id is not None:
            body["tenantId"] = tenant_id
        return await self._http.request_and_validate(
            "/projects/by-key",
            method="POST",
            body=body,
            response_model=ProjectResponse,
        )

    async def register(self, data: ProjectRegisterRequest | dict) -> ProjectRegisterResponse:
        return await self._http.request_and_validate(
            "/projects/register",
            method="POST",
            body=self._dump(data),
            response_model=ProjectRegisterResponse,
        )

    async def import_project(self, data: ProjectImportRequest | dict) -> ProjectRegisterResponse:
        return await self._http.request_and_validate(
            "/projects/import",
            method="POST",
            body=self._dump(data),
            response_model=ProjectRegisterResponse,
        )

    async def update(self, data: ProjectUpdateRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/projects",
            method="PATCH",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def delete(self, project_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/projects",
            method="DELETE",
            body={"projectId": project_id},
            response_model=BaseResponse,
        )

    @staticmethod
    def _dump(data: BaseModel | dict) -> dict:
        if isinstance(data, BaseModel):
            return data.model_dump(by_alias=True, exclude_none=True)
        return data
