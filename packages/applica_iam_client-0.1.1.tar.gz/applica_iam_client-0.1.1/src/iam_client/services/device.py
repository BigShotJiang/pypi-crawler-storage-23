from __future__ import annotations

from pydantic import BaseModel

from ..http_client import HttpClient
from ..models.common import BaseResponse
from ..models.device import (
    DeviceResponse,
    DeviceSearchRequest,
    DeviceSearchResponse,
    DeviceUpdateRequest,
)


class DeviceService:
    """Device management operations."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def register(self, code: str) -> DeviceResponse:
        return await self._http.request_and_validate(
            "/devices/register",
            method="POST",
            body={"code": code},
            response_model=DeviceResponse,
        )

    async def get_by_code(self, code: str) -> DeviceResponse:
        return await self._http.request_and_validate(
            "/devices/by-code",
            method="POST",
            body={"code": code},
            response_model=DeviceResponse,
        )

    async def get_by_id(self, device_id: str) -> DeviceResponse:
        return await self._http.request_and_validate(
            "/devices/by-id",
            method="POST",
            body={"deviceId": device_id},
            response_model=DeviceResponse,
        )

    async def update(self, data: DeviceUpdateRequest | dict) -> BaseResponse:
        return await self._http.request_and_validate(
            "/devices",
            method="PATCH",
            body=self._dump(data),
            response_model=BaseResponse,
        )

    async def search(self, params: DeviceSearchRequest | dict | None = None) -> DeviceSearchResponse:
        body = self._dump(params) if params else {}
        return await self._http.request_and_validate(
            "/devices/search",
            method="POST",
            body=body,
            response_model=DeviceSearchResponse,
        )

    async def delete(self, device_id: str) -> BaseResponse:
        return await self._http.request_and_validate(
            "/devices",
            method="DELETE",
            body={"deviceId": device_id},
            response_model=BaseResponse,
        )

    @staticmethod
    def _dump(data: BaseModel | dict) -> dict:
        if isinstance(data, BaseModel):
            return data.model_dump(by_alias=True, exclude_none=True)
        return data
