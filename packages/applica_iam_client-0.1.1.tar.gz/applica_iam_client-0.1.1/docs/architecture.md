# Architecture

## Overview

The `IamClient` is the central entry point. It creates a shared `HttpClient` and instantiates one service per IAM
entity:

```
IamClient
  ├── http: HttpClient          (shared httpx client + auth headers + response validation)
  ├── auth: AuthService          → /auth/*
  ├── users: UserService         → /users/*
  ├── tenants: TenantService     → /tenants/*
  ├── projects: ProjectService   → /projects/*
  ├── roles: RoleService         → /roles/*
  └── devices: DeviceService     → /devices/*
```

## HttpClient

All services share a single `HttpClient` instance that handles:

- **Automatic authentication**: reads the token from storage and adds the `Authorization: Bearer <token>` header
- **API key support**: if configured, sends the `x-api-key` header on every request
- **JSON serialization**: request body is automatically serialized; responses are parsed as JSON
- **Form encoding**: supports `application/x-www-form-urlencoded` for auth endpoints
- **Error handling**: HTTP 401/403 throw `FailureResponse.handled()`; other HTTP errors throw
  `FailureResponse.unhandled()`

### Two request methods

| Method                                  | Behavior                                                                                       |
|-----------------------------------------|------------------------------------------------------------------------------------------------|
| `request(path, **options)`              | Raw HTTP request. Returns parsed JSON. Throws on HTTP errors.                                  |
| `request_and_validate(path, **options)` | Same as `request()` but also verifies `responseCode == "ok"`. Throws `FailureResponse` if not. |

All CRUD services use `request_and_validate()`. The `AuthService` uses `request()` directly for endpoints that require
`application/x-www-form-urlencoded` content type and custom response handling.

### Request options

| Parameter       | Type                                              | Default  | Description                  |
|-----------------|---------------------------------------------------|----------|------------------------------|
| `method`        | `"GET" \| "POST" \| "PUT" \| "DELETE" \| "PATCH"` | `"GET"`  | HTTP method                  |
| `body`          | `dict \| BaseModel \| None`                       | `None`   | Request body                 |
| `content_type`  | `"json" \| "form"`                                | `"json"` | Serialization format         |
| `authenticated` | `bool`                                            | `True`   | Whether to send Bearer token |

## Project Structure

```
src/
  iam_client/
    __init__.py              # Public exports
    client.py                # IamClient class + create_iam_client() factory
    http_client.py           # Shared HttpClient (httpx)
    errors.py                # FailureResponse
    services/
      auth.py                # Authentication, session, impersonation, PIN
      user.py                # User CRUD, roles, tenant/project assignment
      tenant.py              # Tenant CRUD
      project.py             # Project CRUD
      role.py                # Role CRUD
      device.py              # Device CRUD
    models/
      common.py              # BaseResponse, Page, Pageable
      auth.py                # Auth DTOs
      user.py                # User DTOs
      tenant.py              # Tenant DTOs
      project.py             # Project DTOs
      role.py                # Role DTOs
      device.py              # Device DTOs
    storage/
      base.py                # IStorage Protocol
      memory.py              # MemoryStorage
    crypto/
      aes_util.py            # AES encryption for PIN login
```

## Pydantic Models with camelCase Aliases

The IAM server expects camelCase JSON fields (`userId`, `tenantId`, `responseCode`). Python uses snake_case. Pydantic
aliases bridge the two conventions:

```python
class BaseResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")
    response_code: str = Field(alias="responseCode")
```

Serialization always uses camelCase:

```python
model.model_dump(by_alias=True, exclude_none=True)
```

This ensures compatibility with the server while maintaining Pythonic attribute access (`response.response_code`).
