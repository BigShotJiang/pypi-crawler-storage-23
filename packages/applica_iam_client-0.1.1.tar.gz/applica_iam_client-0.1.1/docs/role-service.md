# RoleService

Accessible via `iam.roles`. Manages roles and permissions.

## Register Role

```python
resp = await iam.roles.register({
    "code": "EDITOR",
    "name": "Editor",
    "permissions": ["read", "write"],       # optional
    "tenantId": "optional-tenant-id",       # optional (scope to tenant)
    "projectId": "optional-project-id",     # optional (scope to project)
    "metadata": {"level": "2"},             # optional
})
role_id = resp.role.id
```

## Get Single Role

```python
# By ID
result = await iam.roles.get_by_id("role-id")

# By code (optionally scoped to a tenant)
result = await iam.roles.get_by_code("EDITOR", tenant_id="optional-tenant-id")

role = result.role  # Role model
```

## Update Role

```python
await iam.roles.update({
    "id": "role-id",
    "name": "Senior Editor",                   # optional
    "code": "SENIOR_EDITOR",                    # optional
    "permissions": ["read", "write", "delete"], # optional
    "tenantId": "tenant-id",                    # optional
    "projectId": "project-id",                  # optional
    "metadata": {"level": "3"},                 # optional
})
```

## Delete Role

```python
await iam.roles.delete("role-id")
```
