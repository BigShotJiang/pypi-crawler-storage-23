# Type Reference

All models are Pydantic v2 `BaseModel` subclasses, exported from `iam_client`. Fields use snake_case in Python but serialize to camelCase for the server via Pydantic aliases.

## Common Types

```python
class BaseResponse(BaseModel):
    response_code: str     # alias: "responseCode"
    new_password: str | None  # alias: "newPassword" (debug mode only)

class Pageable(BaseModel):
    page: int | None
    rows_per_page: int | None  # alias: "rowsPerPage"

class Page(BaseModel, Generic[T]):
    content: list[T]
    total_elements: int    # alias: "totalElements"
    total_pages: int       # alias: "totalPages"
    number: int
    size: int
```

## User

```python
class User(BaseModel):
    id: str
    email: str
    name: str | None
    roles: list[str] | None
    active: bool | None
    profile: dict[str, Any] | None
    tenant_id: str | None      # alias: "tenantId"
    project_id: str | None     # alias: "projectId"
    tenant_ids: list[str] | None   # alias: "tenantIds"
    project_ids: list[str] | None  # alias: "projectIds"

class UserSearchRequest(BaseModel):
    keyword: str | None
    username: str | None
    active: bool | None
    role: str | None
    profile: dict[str, str] | None
    pageable: Pageable | None

class UserSearchResponse(BaseResponse):
    users: Page[User]

class UserResponse(BaseResponse):
    user: User

class UserUpdateRequest(BaseModel):
    user_id: str               # alias: "userId"
    email: str | None
    clear_password: str | None # alias: "clearPassword"
    roles: list[str] | None
    active: bool | None
    finalized: bool | None
    profile: dict[str, str] | None
    replace_profile: bool | None   # alias: "replaceProfile"
    tenant_id: str | None      # alias: "tenantId"
    project_id: str | None     # alias: "projectId"
    tenant_ids: list[str] | None   # alias: "tenantIds"
    project_ids: list[str] | None  # alias: "projectIds"

class UserUpdateRolesRequest(BaseModel):
    user_id: str       # alias: "userId"
    roles: list[str]

class UserImportRequest(BaseModel):
    id: str | None
    email: str
    clear_password: str | None     # alias: "clearPassword"
    tenant_id: str | None          # alias: "tenantId"
    project_id: str | None         # alias: "projectId"
    roles: list[str] | None
    profile: dict[str, str] | None
    active_by_default: bool | None # alias: "activeByDefault"
    finalized: bool | None

class UserTenantRequest(BaseModel):
    user_id: str       # alias: "userId"
    tenant_id: str     # alias: "tenantId"

class UserSetTenantsRequest(BaseModel):
    user_id: str           # alias: "userId"
    tenant_ids: list[str]  # alias: "tenantIds"

class UserSetTenantRequest(BaseModel):
    user_id: str               # alias: "userId"
    tenant_id: str             # alias: "tenantId"
    add_to_tenants: bool | None    # alias: "addToTenants"

class UserSetProjectRequest(BaseModel):
    user_id: str                # alias: "userId"
    project_id: str             # alias: "projectId"
    add_to_projects: bool | None    # alias: "addToProjects"
```

## Tenant

```python
class Tenant(BaseModel):
    id: str
    code: str
    name: str
    roles: list[str] | None
    metadata: dict[str, Any] | None
    domains: list[str] | None
    api_key: str | None        # alias: "apiKey"

class TenantSearchRequest(BaseModel):
    keyword: str | None
    pageable: Pageable | None

class TenantSearchResponse(BaseResponse):
    tenants: Page[Tenant]

class TenantResponse(BaseResponse):
    tenant: Tenant

class TenantRegisterResponse(BaseResponse):
    id: str

class TenantRegisterRequest(BaseModel):
    code: str
    name: str
    roles: list[str] | None
    metadata: dict[str, str] | None
    domains: list[str] | None

class TenantImportRequest(BaseModel):
    id: str | None
    code: str
    name: str
    roles: list[str] | None
    metadata: dict[str, str] | None
    domains: list[str] | None
    api_key: str | None        # alias: "apiKey"

class TenantUpdateRequest(BaseModel):
    tenant_id: str             # alias: "tenantId"
    name: str | None
    roles: list[str] | None
    metadata: dict[str, str] | None
    domains: list[str] | None
```

## Project

```python
class Project(BaseModel):
    id: str
    code: str
    name: str
    tenant_ids: list[str] | None   # alias: "tenantIds"
    roles: list[str] | None
    metadata: dict[str, Any] | None
    api_key: str | None            # alias: "apiKey"

class ProjectSearchRequest(BaseModel):
    tenant_ids: list[str] | None   # alias: "tenantIds"
    keyword: str | None
    pageable: Pageable | None

class ProjectSearchResponse(BaseResponse):
    projects: Page[Project]

class ProjectResponse(BaseResponse):
    project: Project

class ProjectRegisterResponse(BaseResponse):
    id: str

class ProjectRegisterRequest(BaseModel):
    id: str | None
    tenant_ids: list[str] | None   # alias: "tenantIds"
    code: str
    name: str
    roles: list[str] | None
    metadata: dict[str, str] | None
    api_key: str | None            # alias: "apiKey"

class ProjectImportRequest(BaseModel):
    id: str | None
    tenant_ids: list[str] | None   # alias: "tenantIds"
    code: str
    name: str
    roles: list[str] | None
    metadata: dict[str, str] | None
    api_key: str | None            # alias: "apiKey"

class ProjectUpdateRequest(BaseModel):
    project_id: str            # alias: "projectId"
    name: str | None
    code: str | None
    roles: list[str] | None
    metadata: dict[str, str] | None
```

## Role

```python
class Role(BaseModel):
    id: str
    code: str
    name: str
    tenant_id: str | None      # alias: "tenantId"
    project_id: str | None     # alias: "projectId"
    permissions: list[str] | None
    metadata: dict[str, Any] | None
    created_at: str | None     # alias: "createdAt"
    updated_at: str | None     # alias: "updatedAt"

class RoleResponse(BaseResponse):
    role: Role

class RoleRegisterResponse(BaseResponse):
    id: str
    role: Role

class RoleRegisterRequest(BaseModel):
    id: str | None
    tenant_id: str | None      # alias: "tenantId"
    project_id: str | None     # alias: "projectId"
    code: str
    name: str
    permissions: list[str] | None
    metadata: dict[str, str] | None

class RoleUpdateRequest(BaseModel):
    id: str
    tenant_id: str | None      # alias: "tenantId"
    project_id: str | None     # alias: "projectId"
    code: str | None
    name: str | None
    permissions: list[str] | None
    metadata: dict[str, str] | None
```

## Device

```python
class Device(BaseModel):
    id: str
    code: str
    name: str | None
    secret: str | None
    registration_date: str | None  # alias: "registrationDate"

class DeviceSearchRequest(BaseModel):
    keyword: str | None
    pageable: Pageable | None

class DeviceSearchResponse(BaseResponse):
    devices: Page[Device]

class DeviceResponse(BaseResponse):
    device: Device

class DeviceRegisterRequest(BaseModel):
    code: str

class DeviceUpdateRequest(BaseModel):
    device_id: str         # alias: "deviceId"
    code: str | None
    secret: str | None
```

## Auth

```python
class AuthLogin(BaseModel):
    username: str
    password: str

class AuthIdentity(BaseModel):
    token: str
    user: dict[str, Any]
    permissions: Any

class AuthDevice(BaseModel):
    code: str
    secret: str

class AuthRegisterRequest(BaseModel):
    name: str
    email: str
    password: str

class AuthRegisterResponse(BaseResponse):
    user_id: str           # alias: "userId"

class UpdateProfileRequest(BaseModel):
    name: str

class AuthThirdPartyProviders(str, Enum):
    GOOGLE = "google"

class AuthThirdPartyLogin(BaseModel):
    provider: AuthThirdPartyProviders
    payload: Any
```
