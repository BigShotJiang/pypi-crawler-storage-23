# Getting Started

## Installation

```bash
pip install applica-iam-client
```

## Quick Start

```python
import asyncio

from iam_client import create_iam_client


async def main():
    async with create_iam_client(api_url="https://server.com/api") as iam:
        # Authentication
        await iam.auth.login({"username": "user@test.com", "password": "secret"})

        # CRUD operations (authenticated via Bearer token from login)
        user = await iam.users.get_by_id("user-id")
        await iam.roles.register({"code": "EDITOR", "name": "Editor", "permissions": ["read", "write"]})
        await iam.projects.search({"keyword": "web"})


asyncio.run(main())
```

## Configuration

```python
from iam_client import create_iam_client, MemoryStorage

iam = create_iam_client(
    # Base API URL (without trailing /auth)
    api_url="https://server.com/api",

    # Storage implementation for persisting auth data (optional).
    # Defaults to MemoryStorage.
    storage=MemoryStorage(),

    # System API key (sent as x-api-key header). Optional.
    # Required for /tenants/* (ROLE_SYSTEM).
    # Also accepted as an alternative to Bearer token for /users/*, /roles/*, /projects/*, /devices/*.
    # See README.md "Authentication" section for full details.
    api_key="your-system-api-key",
)
```

### The `api_url` parameter

The URL must point to the API root (e.g. `https://server.com/api`), **not** to `/api/auth`. Each service automatically appends its own path.

### The `api_key` parameter

The system API key grants `ROLE_SYSTEM` and is the **only** way to authenticate against `/tenants/**` endpoints. For all other endpoints (`/users/**`, `/roles/**`, `/projects/**`, `/devices/**`), you can use either the API key or a Bearer token from `iam.auth.login()`.

See the [README.md Authentication section](../README.md#authentication) for detailed scenarios and how to obtain the key.

## Async Context Manager

The client can be used as an async context manager to ensure proper cleanup of HTTP connections:

```python
async with create_iam_client(api_url="https://server.com/api") as iam:
    await iam.auth.login({"username": "user@test.com", "password": "secret"})
    # ...
# httpx client is automatically closed here
```

You can also manage the lifecycle manually:

```python
iam = create_iam_client(api_url="https://server.com/api")
try:
    await iam.auth.login({"username": "user@test.com", "password": "secret"})
finally:
    await iam.close()
```

## Synchronous Usage

All methods are `async`. If you need synchronous access (e.g. in a script), wrap with `asyncio.run()`:

```python
import asyncio

from iam_client import create_iam_client


async def main():
    async with create_iam_client(api_url="https://server.com/api", api_key="key") as iam:
        result = await iam.tenants.search({})
        for tenant in result.tenants.content:
            print(tenant.name)


asyncio.run(main())
```
