# Storage

The library requires an `IStorage` implementation to persist authentication data (token, roles, profile) across
requests.

## IStorage Protocol

```python
from typing import Protocol, runtime_checkable


@runtime_checkable
class IStorage(Protocol):
    async def get_item(self, key: str) -> str: ...

    async def set_item(self, key: str, value: str) -> None: ...

    async def remove_item(self, key: str) -> None: ...
```

**Note:** `get_item` must return an empty string (not `None`) when the key is not found.

## Built-in Implementation

### MemoryStorage (default)

In-memory storage, used by default. Suitable for server-side scripts, testing, and short-lived processes:

```python
from iam_client import create_iam_client, MemoryStorage

iam = create_iam_client(
    api_url="https://server.com/api",
    storage=MemoryStorage(),  # this is the default
)
```

Data is lost when the process exits or the instance is garbage collected.

> **Note:** Unlike the TypeScript library, there is no `LocalStorage` implementation (which is a browser concept).
`MemoryStorage` is the default for all environments.

## Custom Storage

Implement the `IStorage` protocol for custom persistence (e.g. Redis, file-based, database):

```python
import aioredis


class RedisStorage:
    def __init__(self, redis: aioredis.Redis, prefix: str = "iam:"):
        self._redis = redis
        self._prefix = prefix

    async def get_item(self, key: str) -> str:
        value = await self._redis.get(f"{self._prefix}{key}")
        return value.decode() if value else ""

    async def set_item(self, key: str, value: str) -> None:
        await self._redis.set(f"{self._prefix}{key}", value)

    async def remove_item(self, key: str) -> None:
        await self._redis.delete(f"{self._prefix}{key}")


redis = aioredis.from_url("redis://localhost")
iam = create_iam_client(
    api_url="https://server.com/api",
    storage=RedisStorage(redis),
)
```

Since `IStorage` is a `Protocol`, you do not need to inherit from it — just implement the three methods.

## Stored Keys

The `AuthService` uses the following storage keys:

| Key            | Content                                   |
|----------------|-------------------------------------------|
| `token`        | JWT auth token                            |
| `roles`        | JSON array of role strings                |
| `profile`      | JSON object with profile data             |
| `email`        | User email                                |
| `permissions`  | Comma-separated permission strings        |
| `impersonate`  | `"true"` / `"false"` impersonation flag   |
| `admin_*`      | Backup of above keys during impersonation |
| `deviceCode`   | Registered device code                    |
| `deviceSecret` | Registered device secret                  |
