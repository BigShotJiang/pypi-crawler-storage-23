# ProjectService

Accessible via `iam.projects`. Manages projects within tenants.

## Search Projects

```python
# Search all projects
result = await iam.projects.search({})

# Search filtered by tenant
result = await iam.projects.search({
    "tenantIds": ["tid1"],
    "keyword": "web",
})

# Access results
result.projects.content  # list[Project]
result.projects.total_elements  # Total number of results
result.projects.total_pages  # Total number of pages
result.projects.number  # Current page
result.projects.size  # Page size
```

### Search parameters

| Parameter   | Type        | Description            |
|-------------|-------------|------------------------|
| `tenantIds` | `list[str]` | Filter by tenant IDs   |
| `keyword`   | `str`       | Free-text search       |
| `pageable`  | `dict`      | Pagination (0-indexed) |

## Get Single Project

```python
result = await iam.projects.get_by_id("project-id")
result = await iam.projects.get_by_code("project-code", tenant_id="optional-tenant-id")

project = result.project  # Project model
```

## Register Project

```python
resp = await iam.projects.register({
    "code": "my-project",
    "name": "My Project",
    "tenantIds": ["tid1"],  # optional
    "roles": ["ROLE_USER"],  # optional
    "metadata": {"env": "production"},  # optional
    "apiKey": "project-api-key",  # optional
})
project_id = resp.id
```

## Import Project

Creates a project with an optional predefined ID.

```python
await iam.projects.import_project({
    "id": "custom-id",  # optional
    "code": "imported",
    "name": "Imported Project",
    "tenantIds": ["tid1"],  # optional
    "roles": [],  # optional
    "metadata": {},  # optional
    "apiKey": "key",  # optional
})
```

## Update Project

```python
await iam.projects.update({
    "projectId": "project-id",
    "name": "New Name",  # optional
    "code": "new-code",  # optional
    "roles": ["ROLE_USER"],  # optional
    "metadata": {"env": "staging"},  # optional
})
```

## Delete Project

```python
await iam.projects.delete("project-id")
```
