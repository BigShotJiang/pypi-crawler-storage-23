# DeviceService

Accessible via `iam.devices`. Manages devices for PIN-based authentication.

## Register Device

```python
result = await iam.devices.register("DEVICE-001")
# Returns DeviceResponse with device { id, code, secret, ... }
```

## Search Devices

```python
result = await iam.devices.search({"keyword": "DEVICE"})

# Access results
result.devices.content  # list[Device]
result.devices.total_elements  # Total number of results
result.devices.total_pages  # Total number of pages
result.devices.number  # Current page
result.devices.size  # Page size
```

### Search parameters

| Parameter  | Type   | Description            |
|------------|--------|------------------------|
| `keyword`  | `str`  | Free-text search       |
| `pageable` | `dict` | Pagination (0-indexed) |

## Get Single Device

```python
result = await iam.devices.get_by_id("device-id")
result = await iam.devices.get_by_code("DEVICE-001")

device = result.device  # Device model
```

## Update Device

```python
await iam.devices.update({
    "deviceId": "device-id",
    "code": "DEVICE-002",  # optional
    "secret": "new-secret",  # optional
})
```

## Delete Device

```python
await iam.devices.delete("device-id")
```
