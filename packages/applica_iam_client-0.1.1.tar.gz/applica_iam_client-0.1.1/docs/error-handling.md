# Error Handling and Pagination

## Error Handling

All service methods can raise `FailureResponse`:

```python
from iam_client import FailureResponse

try:
    await iam.auth.login({"username": "user@test.com", "password": "wrong"})
except FailureResponse as e:
    if e.is_handled:
        # Known application error (e.g. invalid credentials, user not active)
        print(e.message)  # "iam.error.invalid-credentials"
    else:
        # Unexpected error (network failure, server down, etc.)
        print(e.message)
```

### FailureResponse

| Property     | Type   | Description                                                                     |
|--------------|--------|---------------------------------------------------------------------------------|
| `is_handled` | `bool` | `True` if the error is a known application error; `False` for unexpected errors |
| `message`    | `str`  | Error code (e.g. `iam.error.invalid-credentials`) or error message              |

### Static constructors

```python
FailureResponse.handled("iam.error.invalid-credentials")  # known error
FailureResponse.unhandled("Internal Server Error")  # unexpected error
```

### Common Error Codes

| Code                            | Description                    |
|---------------------------------|--------------------------------|
| `iam.error.invalid-credentials` | Invalid credentials            |
| `iam.error.unauthorized`        | Missing or invalid token       |
| `iam.error.not-authorized`      | Insufficient permissions (403) |
| `iam.error.user-not-active`     | User is disabled               |
| `iam.error.bad-activation-code` | Invalid activation code        |

### HTTP status mapping

The `HttpClient` automatically maps HTTP status codes to `FailureResponse`:

| HTTP Status   | Result                                                |
|---------------|-------------------------------------------------------|
| 200-299       | Success (JSON parsed)                                 |
| 401           | `FailureResponse.handled("iam.error.unauthorized")`   |
| 403           | `FailureResponse.handled("iam.error.not-authorized")` |
| Other 4xx/5xx | `FailureResponse.unhandled(reason_phrase)`            |

After HTTP success, `request_and_validate()` also checks `response_code == "ok"` and raises
`FailureResponse.handled(response_code)` if not.

---

## Pagination

Services with search endpoints (`users`, `tenants`, `projects`, `devices`) support pagination:

```python
result = await iam.users.search({
    "keyword": "test",
    "pageable": {
        "page": 0,  # Page number (0-indexed)
        "rowsPerPage": 25,  # Items per page
    },
})

print(result.users.content)  # list[User]
print(result.users.total_elements)  # Total number of results
print(result.users.total_pages)  # Total number of pages
print(result.users.number)  # Current page number
print(result.users.size)  # Page size
```

If `pageable` is not specified, the backend returns all results (unpaged).

### Response structure

Each search response contains a paginated field named after the entity (e.g. `users`, `tenants`, `projects`, `devices`):

```python
# UserSearchResponse
{
    "responseCode": "ok",
    "users": {
        "content": [...],  # list of User dicts
        "totalElements": 42,
        "totalPages": 3,
        "number": 0,
        "size": 20,
    }
}
```

In Python, access the parsed Pydantic models:

```python
result.response_code  # "ok"
result.users.content  # list[User]
result.users.total_elements  # 42
```
