# UserService

Accessible via `iam.users`. Manages users: search, CRUD, roles, and tenant/project assignment.

## Search Users

```python
# Search all users
result = await iam.users.search({})

# Search with filters
filtered = await iam.users.search({
    "keyword": "mario",
    "active": True,
    "role": "ROLE_ADMIN",
    "pageable": {"page": 0, "rowsPerPage": 20},
})

# Access results
result.users.content  # list[User]
result.users.total_elements  # Total number of results
result.users.total_pages  # Total number of pages
result.users.number  # Current page
result.users.size  # Page size
```

### Search parameters

| Parameter  | Type             | Description              |
|------------|------------------|--------------------------|
| `keyword`  | `str`            | Free-text search         |
| `username` | `str`            | Filter by username       |
| `active`   | `bool`           | Filter by active status  |
| `role`     | `str`            | Filter by role           |
| `profile`  | `dict[str, str]` | Filter by profile fields |
| `pageable` | `dict`           | Pagination (0-indexed)   |

## Get Single User

```python
result = await iam.users.get_by_id("user-id")
result = await iam.users.get_by_email("mario@test.com")

user = result.user  # User model
```

## Update User

```python
await iam.users.update({
    "userId": "user-id",
    "profile": {"name": "Updated Name"},
    # Optional fields:
    # email, clearPassword, active, finalized,
    # roles, tenantId, projectId, tenantIds, projectIds, replaceProfile
})
```

## Update Roles

```python
await iam.users.update_roles({
    "userId": "user-id",
    "roles": ["ROLE_USER", "ROLE_ADMIN"],
})
```

## Enable / Disable

```python
await iam.users.enable("user-id")
await iam.users.disable("user-id")
```

## Delete User

```python
await iam.users.delete("user-id")
```

## Import User

Creates a user with an optional predefined ID.

```python
await iam.users.import_user({
    "email": "imported@test.com",
    "clearPassword": "password",
    "roles": ["ROLE_USER"],
    "activeByDefault": True,
    # Optional: id, tenantId, projectId, profile, finalized
})
```

## Tenant Assignment

```python
# Add user to a tenant
await iam.users.add_to_tenant({"userId": "uid", "tenantId": "tid"})

# Remove user from a tenant
await iam.users.remove_from_tenant({"userId": "uid", "tenantId": "tid"})

# Replace all user tenants
await iam.users.set_tenants({"userId": "uid", "tenantIds": ["tid1", "tid2"]})

# Set primary tenant (optionally adding to tenant list)
await iam.users.set_tenant({"userId": "uid", "tenantId": "tid", "addToTenants": True})
```

## Project Assignment

```python
# Set primary project (optionally adding to project list)
await iam.users.set_project({"userId": "uid", "projectId": "pid", "addToProjects": True})
```
