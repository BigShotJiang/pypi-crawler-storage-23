# AuthService

Accessible via `iam.auth`. Handles authentication, session management, impersonation, and device/PIN login.

## Login

```python
# Login with credentials
identity = await iam.auth.login({"username": "user@test.com", "password": "secret"})
# Returns AuthIdentity with token, user info, permissions

# Third-party login (e.g. Google)
await iam.auth.third_party_login({"provider": "google", "payload": google_auth_data})
```

## Token Management

```python
# Get current token from storage
token = await iam.auth.get_token()

# Validate a token against the server
await iam.auth.validate_token(token)

# Get a fresh token (validates current, returns new)
fresh_token = await iam.auth.fresh_token()

# Get auth headers (with Bearer token)
headers = await iam.auth.get_headers()
```

## Session

```python
# Verify that the current token is still valid
await iam.auth.check_auth()

# Logout (clears all auth data from storage)
await iam.auth.logout()
```

## Identity and Permissions

```python
# Get current user identity (profile, email, roles)
identity = await iam.auth.get_identity()

# Get permissions as list of strings
permissions = await iam.auth.get_permissions()

# Get roles as list of strings
roles = await iam.auth.get_roles()
```

## Registration and Activation

```python
# Register a new user
resp = await iam.auth.register({"name": "Mario Rossi", "email": "mario@test.com", "password": "securePassword"})
user_id = resp.user_id

# Activate account with activation code
await iam.auth.activate("activation-code")
```

## Password Recovery and Change

```python
# Send recovery email
await iam.auth.recover("user@test.com")

# Change password (requires current session)
await iam.auth.change_password("currentPassword", "newPassword")
```

## Profile Update

```python
# Update current user's profile
await iam.auth.update_profile({"name": "New Name"})
```

## Impersonation

Requires admin privileges (ROLE_ADMIN).

```python
# Start impersonating a user
await iam.auth.impersonate("user-id")

# Check if currently impersonating
is_impersonating = await iam.auth.is_impersonating()

# Stop impersonating (restores admin session)
await iam.auth.stop_impersonate()
```

## Device and PIN Login

Used for device-based authentication with PIN codes.

```python
# Register a new device
device = await iam.auth.register_device("device-code")
# Returns AuthDevice with code and secret

# Get device (registers if not already registered)
device = await iam.auth.get_device("device-code")

# Login with PIN
await iam.auth.pin_login("device-code", "1234")

# Reset a user's PIN
await iam.auth.reset_pin("user-id", "5678")
```

### PIN Encryption

The PIN is encrypted client-side using AES before transmission. The payload is sent as Base64 in the format:

```
ivHex::saltHex::ciphertextBase64
```

- Key derivation: PBKDF2 with HMAC-SHA1 (128 bit, 1000 iterations)
- Compatible with the Java server-side implementation
