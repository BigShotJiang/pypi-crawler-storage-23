# TenantService

Accessible via `iam.tenants`. Manages multi-tenancy.

> **Authentication:** All `/tenants/**` endpoints require the **system API key** (`ROLE_SYSTEM`). Bearer tokens from
> user login are **not** accepted. You must set the `api_key` option when creating the client. See
> the [README.md Authentication section](../README.md#authentication) for details.

## Search Tenants

```python
result = await iam.tenants.search({"keyword": "test"})

# Access results
result.tenants.content  # list[Tenant]
result.tenants.total_elements  # Total number of results
result.tenants.total_pages  # Total number of pages
result.tenants.number  # Current page
result.tenants.size  # Page size
```

### Search parameters

| Parameter  | Type   | Description            |
|------------|--------|------------------------|
| `keyword`  | `str`  | Free-text search       |
| `pageable` | `dict` | Pagination (0-indexed) |

## Get Single Tenant

```python
result = await iam.tenants.get_by_id("tenant-id")
result = await iam.tenants.get_by_code("tenant-code")

tenant = result.tenant  # Tenant model
```

## Register Tenant

```python
resp = await iam.tenants.register({
    "code": "my-tenant",
    "name": "My Tenant",
    "roles": ["ROLE_USER"],  # optional
    "metadata": {"region": "EU"},  # optional
    "domains": ["example.com"],  # optional
})
tenant_id = resp.id
```

## Import Tenant

Creates a tenant with an optional predefined ID.

```python
await iam.tenants.import_tenant({
    "id": "custom-id",  # optional
    "code": "imported",
    "name": "Imported Tenant",
    "roles": ["ROLE_USER"],  # optional
    "metadata": {},  # optional
    "domains": [],  # optional
    "apiKey": "tenant-api-key",  # optional
})
```

## Update Tenant

```python
await iam.tenants.update({
    "tenantId": "tenant-id",
    "name": "New Name",  # optional
    "roles": ["ROLE_USER"],  # optional
    "metadata": {"region": "US"},  # optional
    "domains": ["newdomain.com"],  # optional
})
```

## Delete Tenant

```python
await iam.tenants.delete("tenant-id")
```
