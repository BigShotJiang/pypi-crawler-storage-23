"""TenantService integration tests.

Mirrors: iam-client/src/tests/core/tenant.service.test.ts
"""

from __future__ import annotations

from iam_client import IamClient

from .conftest import random_string


class TestTenantService:
    async def test_register(self, admin_client: IamClient):
        code = f"test-tenant-{random_string(4).lower()}"
        result = await admin_client.tenants.register({
            "code": code,
            "name": f"Test Tenant ({code})",
        })
        assert result.response_code == "ok"
        assert result.id

    async def test_search(self, admin_client: IamClient):
        result = await admin_client.tenants.search({})
        assert result.response_code == "ok"

    async def test_get_by_id(self, admin_client: IamClient):
        code = f"test-tenant-{random_string(4).lower()}"
        register_result = await admin_client.tenants.register({
            "code": code,
            "name": f"Test Tenant ({code})",
        })
        tenant_id = register_result.id

        get_result = await admin_client.tenants.get_by_id(tenant_id)
        assert get_result.response_code == "ok"
        assert get_result.tenant.id == tenant_id

    async def test_get_by_code(self, admin_client: IamClient):
        code = f"test-tenant-{random_string(4).lower()}"
        await admin_client.tenants.register({
            "code": code,
            "name": f"Test Tenant ({code})",
        })

        get_result = await admin_client.tenants.get_by_code(code)
        assert get_result.response_code == "ok"
        assert get_result.tenant.code == code

    async def test_update(self, admin_client: IamClient):
        code = f"test-tenant-{random_string(4).lower()}"
        register_result = await admin_client.tenants.register({
            "code": code,
            "name": f"Original {code}",
        })
        tenant_id = register_result.id

        update_result = await admin_client.tenants.update({
            "tenantId": tenant_id,
            "name": f"Updated {code}",
        })
        assert update_result.response_code == "ok"

    async def test_delete(self, admin_client: IamClient):
        code = f"test-tenant-{random_string(4).lower()}"
        register_result = await admin_client.tenants.register({
            "code": code,
            "name": f"Test Tenant ({code})",
        })
        tenant_id = register_result.id

        delete_result = await admin_client.tenants.delete(tenant_id)
        assert delete_result.response_code == "ok"

    async def test_search_with_keyword(self, admin_client: IamClient):
        unique_code = f"unique-{random_string(6).lower()}"
        await admin_client.tenants.register({
            "code": unique_code,
            "name": f"Unique Tenant {unique_code}",
        })

        result = await admin_client.tenants.search({"keyword": unique_code})
        assert result.response_code == "ok"
