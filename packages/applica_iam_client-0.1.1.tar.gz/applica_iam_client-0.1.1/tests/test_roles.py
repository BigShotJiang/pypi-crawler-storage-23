"""RoleService integration tests."""

from __future__ import annotations

from iam_client import IamClient

from .conftest import random_string


class TestRoleService:
    async def test_crud_flow(self, admin_client: IamClient):
        code = f"ROLE_TEST_{random_string(4).upper()}"

        # Register
        register_resp = await admin_client.roles.register({
            "code": code,
            "name": f"Test Role ({code})",
            "permissions": ["read", "write"],
        })
        assert register_resp.response_code == "ok"
        role_id = register_resp.role.id
        assert role_id

        # Get by ID
        by_id = await admin_client.roles.get_by_id(role_id)
        assert by_id.role.id == role_id

        # Get by code
        by_code = await admin_client.roles.get_by_code(code)
        assert by_code.role.code == code

        # Update
        update_resp = await admin_client.roles.update({
            "id": role_id,
            "name": "Updated Role Name",
            "permissions": ["read", "write", "delete"],
        })
        assert update_resp.response_code == "ok"

        # Delete
        delete_resp = await admin_client.roles.delete(role_id)
        assert delete_resp.response_code == "ok"
