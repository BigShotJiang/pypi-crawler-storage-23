from __future__ import annotations

import random
import string

import pytest

from iam_client import IamClient, MemoryStorage, create_iam_client

API_URL = "http://localhost:8081/api"
API_KEY = "god-is-just-a-good-developer"
ADMIN_EMAIL = "admin@applica.guru"
ADMIN_PASSWORD = "applica"

RANDOM_NAMES = ["Alice", "Bob", "Charlie", "Diana", "Eve", "Frank", "Grace", "Hank"]
RANDOM_SURNAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis"]


def random_string(length: int = 10) -> str:
    chars = string.ascii_letters + string.digits
    return "".join(random.choice(chars) for _ in range(length))


def random_user() -> dict[str, str]:
    salt = random_string(4).lower()
    name = f"{random.choice(RANDOM_NAMES)} {random.choice(RANDOM_SURNAMES)} ({salt})"
    email = f"roberto.conterosito+{salt}@applica.guru"
    password = random_string(10)
    return {"name": name, "email": email, "password": password}


@pytest.fixture
def client() -> IamClient:
    """Unauthenticated client with API key."""
    return create_iam_client(api_url=API_URL, storage=MemoryStorage(), api_key=API_KEY)


@pytest.fixture
async def admin_client() -> IamClient:
    """Authenticated admin client."""
    c = create_iam_client(api_url=API_URL, storage=MemoryStorage(), api_key=API_KEY)
    await c.auth.login({"username": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    return c


async def register_and_activate(client: IamClient, user: dict | None = None) -> dict:
    """Register a random user, activate, and return user info including userId."""
    if user is None:
        user = random_user()
    resp = await client.auth.register(user)
    activation_code = resp.user_id[:6]
    await client.auth.activate(activation_code)
    return {**user, "userId": resp.user_id}
