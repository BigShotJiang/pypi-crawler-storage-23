"""AuthService integration tests."""

from __future__ import annotations

import pytest

from iam_client import FailureResponse, IamClient, MemoryStorage, create_iam_client

from .conftest import (
    ADMIN_EMAIL,
    ADMIN_PASSWORD,
    API_KEY,
    API_URL,
    random_string,
    random_user,
    register_and_activate,
)


@pytest.fixture
def fresh_client() -> IamClient:
    return create_iam_client(api_url=API_URL, storage=MemoryStorage(), api_key=API_KEY)


class TestLogin:
    async def test_login_success(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        identity = await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        assert identity.user is not None
        assert identity.token

    async def test_login_invalid_credentials(self, fresh_client: IamClient):
        with pytest.raises(FailureResponse, match="iam.error.invalid-credentials"):
            await fresh_client.auth.login({"username": "bad@example.com", "password": "wrong"})


class TestRegisterActivate:
    async def test_register_and_activate(self, fresh_client: IamClient):
        user = random_user()
        resp = await fresh_client.auth.register(user)
        assert resp.response_code == "ok"
        assert resp.user_id

        activation_code = resp.user_id[:6]
        activate_resp = await fresh_client.auth.activate(activation_code)
        assert activate_resp.response_code == "ok"


class TestCheckAuth:
    async def test_check_auth(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        identity = await fresh_client.auth.check_auth()
        assert identity.user.get("email") == user["email"]

    async def test_check_auth_no_token(self, fresh_client: IamClient):
        with pytest.raises(FailureResponse, match="iam.error.unauthorized"):
            await fresh_client.auth.check_auth()


class TestValidateToken:
    async def test_validate_token(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        login = await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        identity = await fresh_client.auth.validate_token(login.token)
        assert identity.user.get("email") == user["email"]


class TestGetToken:
    async def test_get_token(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        token = await fresh_client.auth.get_token()
        assert token

    async def test_get_token_unauthorized(self, fresh_client: IamClient):
        with pytest.raises(FailureResponse, match="iam.error.unauthorized"):
            await fresh_client.auth.get_token()


class TestGetHeaders:
    async def test_get_headers_authenticated(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        headers = await fresh_client.auth.get_headers()
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Bearer ")

    async def test_get_headers_unauthenticated(self, fresh_client: IamClient):
        headers = await fresh_client.auth.get_headers()
        assert "Authorization" not in headers


class TestGetIdentity:
    async def test_get_identity(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        identity = await fresh_client.auth.get_identity()
        assert identity.user.get("email") == user["email"]

    async def test_get_identity_unauthorized(self, fresh_client: IamClient):
        with pytest.raises(FailureResponse, match="iam.error.unauthorized"):
            await fresh_client.auth.get_identity()


class TestGetRoles:
    async def test_get_roles(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        roles = await fresh_client.auth.get_roles()
        assert isinstance(roles, list)

    async def test_get_roles_unauthorized(self, fresh_client: IamClient):
        with pytest.raises(FailureResponse, match="iam.error.unauthorized"):
            await fresh_client.auth.get_roles()


class TestGetPermissions:
    async def test_get_permissions(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        permissions = await fresh_client.auth.get_permissions()
        assert isinstance(permissions, list)

    async def test_get_permissions_unauthorized(self, fresh_client: IamClient):
        with pytest.raises(FailureResponse, match="iam.error.unauthorized"):
            await fresh_client.auth.get_permissions()


class TestLogout:
    async def test_logout(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        await fresh_client.auth.logout()
        with pytest.raises(FailureResponse, match="iam.error.unauthorized"):
            await fresh_client.auth.get_token()


class TestImpersonate:
    async def test_impersonate_and_stop(self, fresh_client: IamClient):
        login = await fresh_client.auth.login({"username": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        user_id = login.user.get("id")
        assert user_id

        await fresh_client.auth.impersonate(user_id)
        assert await fresh_client.auth.is_impersonating()

        await fresh_client.auth.stop_impersonate()
        assert not await fresh_client.auth.is_impersonating()


class TestChangePassword:
    async def test_change_password(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        new_password = random_string(10)
        resp = await fresh_client.auth.change_password(user["password"], new_password)
        assert resp.response_code == "ok"


class TestUpdateProfile:
    async def test_update_profile(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        await fresh_client.auth.login({"username": user["email"], "password": user["password"]})
        resp = await fresh_client.auth.update_profile({"name": "Updated Name"})
        assert resp.response_code == "ok"


class TestRecover:
    async def test_recover(self, fresh_client: IamClient):
        user = await register_and_activate(fresh_client)
        resp = await fresh_client.auth.recover(user["email"])
        assert resp.response_code == "ok"


class TestDeviceAndPinLogin:
    async def test_register_device(self, fresh_client: IamClient):
        code = random_string(10)
        device = await fresh_client.auth.register_device(code)
        assert device.code == code
        assert device.secret

    async def test_get_device_cached(self, fresh_client: IamClient):
        code = random_string(10)
        device1 = await fresh_client.auth.register_device(code)
        device2 = await fresh_client.auth.get_device(code)
        assert device2.secret == device1.secret

    async def test_pin_login(self, fresh_client: IamClient):
        # Register and activate a user
        user = await register_and_activate(fresh_client)

        # Admin sets PIN
        random_pin = random_string(5)
        await fresh_client.auth.login({"username": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        await fresh_client.auth.reset_pin(user["userId"], random_pin)
        await fresh_client.auth.logout()

        # Register device
        device_code = random_string(10)
        device = await fresh_client.auth.register_device(device_code)
        assert device.secret

        # Login with PIN
        identity = await fresh_client.auth.pin_login(device_code, random_pin)
        assert identity.user is not None
