"""DeviceService integration tests."""

from __future__ import annotations

from iam_client import IamClient

from .conftest import random_string


class TestDeviceService:
    async def test_crud_flow(self, admin_client: IamClient):
        code = random_string(10)

        # Register
        register_resp = await admin_client.devices.register(code)
        assert register_resp.response_code == "ok"
        device_id = register_resp.device.id
        assert device_id

        # Get by ID
        by_id = await admin_client.devices.get_by_id(device_id)
        assert by_id.device.id == device_id

        # Get by code
        by_code = await admin_client.devices.get_by_code(code)
        assert by_code.device.code == code

        # Update
        new_code = random_string(10)
        update_resp = await admin_client.devices.update({
            "deviceId": device_id,
            "code": new_code,
        })
        assert update_resp.response_code == "ok"

        # Delete
        delete_resp = await admin_client.devices.delete(device_id)
        assert delete_resp.response_code == "ok"

    async def test_search(self, admin_client: IamClient):
        result = await admin_client.devices.search({})
        assert result.response_code == "ok"
