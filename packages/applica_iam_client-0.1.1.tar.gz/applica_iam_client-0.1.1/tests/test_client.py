"""IamClient construction and auth flow tests."""

from __future__ import annotations

from iam_client import IamClient, MemoryStorage, create_iam_client

from .conftest import ADMIN_EMAIL, ADMIN_PASSWORD, API_KEY, API_URL


class TestIamClient:
    async def test_create_client(self):
        client = create_iam_client(api_url=API_URL, api_key=API_KEY)
        assert isinstance(client, IamClient)
        assert client.auth is not None
        assert client.users is not None
        assert client.tenants is not None
        assert client.projects is not None
        assert client.roles is not None
        assert client.devices is not None
        await client.close()

    async def test_create_with_custom_storage(self):
        storage = MemoryStorage()
        client = create_iam_client(api_url=API_URL, storage=storage, api_key=API_KEY)
        assert client.http.storage is storage
        await client.close()

    async def test_context_manager(self):
        async with create_iam_client(api_url=API_URL, api_key=API_KEY) as client:
            assert isinstance(client, IamClient)

    async def test_admin_login(self):
        async with create_iam_client(api_url=API_URL, api_key=API_KEY) as client:
            identity = await client.auth.login({"username": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
            assert identity.token
            assert identity.user.get("email") == ADMIN_EMAIL
