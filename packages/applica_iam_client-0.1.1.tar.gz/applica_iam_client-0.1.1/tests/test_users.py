"""UserService integration tests.

Mirrors: iam-client/src/tests/core/user.service.test.ts
"""

from __future__ import annotations

from iam_client import IamClient

from .conftest import random_string, register_and_activate


class TestUserService:
    async def test_search_users(self, admin_client: IamClient):
        result = await admin_client.users.search({})
        assert result.response_code == "ok"

    async def test_get_user_by_id(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        result = await admin_client.users.get_by_id(user["userId"])
        assert result.response_code == "ok"
        assert result.user.id == user["userId"]

    async def test_get_user_by_email(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        result = await admin_client.users.get_by_email(user["email"])
        assert result.response_code == "ok"
        assert result.user.email == user["email"]

    async def test_update_user(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        result = await admin_client.users.update({
            "userId": user["userId"],
            "profile": {"name": "Updated Name"},
        })
        assert result.response_code == "ok"

    async def test_update_user_roles(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        result = await admin_client.users.update_roles({
            "userId": user["userId"],
            "roles": ["ROLE_USER", "ROLE_ADMIN"],
        })
        assert result.response_code == "ok"

    async def test_enable_disable_user(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)

        disable_resp = await admin_client.users.disable(user["userId"])
        assert disable_resp.response_code == "ok"

        enable_resp = await admin_client.users.enable(user["userId"])
        assert enable_resp.response_code == "ok"

    async def test_search_users_with_keyword(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        result = await admin_client.users.search({"keyword": user["email"]})
        assert result.response_code == "ok"

    async def test_delete_user(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        result = await admin_client.users.delete(user["userId"])
        assert result.response_code == "ok"

    async def test_add_remove_tenant(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)
        tenant_code = f"test-tenant-{random_string(4).lower()}"
        tenant_result = await admin_client.tenants.register({
            "code": tenant_code,
            "name": f"Tenant {tenant_code}",
        })
        tenant_id = tenant_result.id

        add_result = await admin_client.users.add_to_tenant({
            "userId": user["userId"],
            "tenantId": tenant_id,
        })
        assert add_result.response_code == "ok"

        remove_result = await admin_client.users.remove_from_tenant({
            "userId": user["userId"],
            "tenantId": tenant_id,
        })
        assert remove_result.response_code == "ok"

    async def test_set_tenants(self, admin_client: IamClient):
        user = await register_and_activate(admin_client)

        code1 = f"test-tenant-{random_string(4).lower()}"
        code2 = f"test-tenant-{random_string(4).lower()}"
        tenant1 = await admin_client.tenants.register({"code": code1, "name": f"Tenant {code1}"})
        tenant2 = await admin_client.tenants.register({"code": code2, "name": f"Tenant {code2}"})

        result = await admin_client.users.set_tenants({
            "userId": user["userId"],
            "tenantIds": [tenant1.id, tenant2.id],
        })
        assert result.response_code == "ok"
