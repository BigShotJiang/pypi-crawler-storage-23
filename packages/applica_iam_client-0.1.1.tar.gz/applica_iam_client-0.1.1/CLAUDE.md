# IAM Client Python

Python client for the Applica IAM service, mirroring the TypeScript `@applica-software-guru/iam-client`.

## Quick Reference

- **Package:** `applica-iam-client`
- **Source:** `src/iam_client/`
- **Tests:** `tests/` (integration tests, require IAM server at localhost:8081)
- **Build:** `hatchling`
- **Docs:** `docs/` (mirrors the TypeScript client docs structure)

## Commands

```bash
# Install
pip install -e ".[dev]"

# Lint
ruff check src/

# Test (requires IAM server)
pytest tests/ -v

# Build
python -m build
```

## Architecture

- Async-only (httpx)
- Pydantic v2 models with camelCase aliases
- 6 services: auth, users, tenants, projects, roles, devices
- IStorage protocol with MemoryStorage default
- FailureResponse exception for error handling

## Authentication Model

Three security chains:
- `/auth/**` — public (no auth)
- `/tenants/**` — system API key only (x-api-key header)
- `/users/**`, `/roles/**`, `/projects/**`, `/devices/**` — Bearer token or API key

## Test Config

- API URL: `http://localhost:8081/api`
- API Key: `god-is-just-a-good-developer`
- Admin: `admin@applica.guru` / `applica`
