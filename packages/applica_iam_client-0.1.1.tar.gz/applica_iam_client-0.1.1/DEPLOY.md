# Deploy to PyPI

Operational guide for publishing `applica-iam-client` to PyPI.

Reference: same strategy used by `drax-sdk-py`.

---

## Prerequisites

### 1. Create a PyPI account

- Go to https://pypi.org/account/register/
- If the account already exists (e.g. the one used for `drax-sdk`), skip this step

### 2. Create a PyPI API Token

1. Login at https://pypi.org
2. Go to **Account Settings** → **API tokens**
3. Click **Add API token**
   - Name: `applica-iam-client-deploy` (or similar)
   - Scope: **Entire account** (for the first release, you can restrict to the project later)
4. Copy the token (starts with `pypi-...`) — it is shown only once

### 3. Configure the token on Bitbucket

1. Go to the Bitbucket repository for `iam-client-py`
2. **Repository settings** → **Pipelines** → **Repository variables**
3. Add:
   - **Name:** `PYPI_TOKEN`
   - **Value:** the copied token (e.g. `pypi-AgEIcH...`)
   - **Secured:** checked

---

## Automated Release (Bitbucket Pipelines)

Every push to `main` automatically publishes a new version.

The version is computed as `0.1.{BITBUCKET_BUILD_NUMBER}`, so it auto-increments
(e.g. build #1 → `0.1.1`, build #14 → `0.1.14`, build #203 → `0.1.203`).

When you want a major/minor bump, change the prefix in `bitbucket-pipelines.yml`
(e.g. from `0.1.` to `0.2.` or `1.0.`).

### Flow:

```
git push origin main
       │
       ▼
Pipeline triggers
       │
       ▼
Updates version in pyproject.toml (0.1.$BUILD_NUMBER)
       │
       ▼
Build (sdist + wheel)
       │
       ▼
Upload to PyPI via twine with $PYPI_TOKEN
       │
       ▼
Creates git tag (0.1.$BUILD_NUMBER) and pushes it
```

---

## Manual Release (from local machine)

If you want to publish without the pipeline, from your terminal:

```bash
cd /path/to/iam-client-py

# 1. Update the version in pyproject.toml
# Edit the line: version = "0.1.X"

# 2. Build
pip install build
python -m build

# 3. Upload
pip install twine
twine upload dist/* -u __token__ -p pypi-YOUR_TOKEN_HERE

# 4. Tag
git tag -a 0.1.X -m "0.1.X"
git push origin 0.1.X
```

---

## Verification

After release, verify that the package is available:

```bash
pip install applica-iam-client --upgrade
```

Or check at: https://pypi.org/project/applica-iam-client/

---

## First Release — Checklist

- [ ] PyPI account created/existing
- [ ] API Token generated on PyPI
- [ ] Token configured as `PYPI_TOKEN` in Bitbucket repository variables
- [ ] Repository created on Bitbucket
- [ ] Push to `main` → pipeline runs → package published
- [ ] `pip install applica-iam-client` works
