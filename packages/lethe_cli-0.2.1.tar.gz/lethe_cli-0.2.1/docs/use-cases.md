# Use Cases

## Development and Testing

Production databases contain real customer data: names, emails, phone numbers, addresses. Developers need realistic data to build and test features, but giving them access to real PII creates liability, violates regulations, and risks accidental exposure in logs, screenshots, or error reports.

Lethe anonymizes production database exports so developers can work with structurally identical data without ever seeing real PII.

```bash
# Export from production
pg_dump --table=customers --csv production_db > customers.csv

# Anonymize
lethe anonymize customers.csv -o customers_dev.csv --seed 42

# Import into dev database
psql dev_db < customers_dev.csv
```

The `--seed` flag ensures every developer gets the same fake data, so bug reports reference consistent names and emails across the team.

### Preserving foreign keys

When you anonymize multiple related tables in the same Lethe session, the `SessionIndex` guarantees consistency. If "john.smith@example.com" appears in both `customers.csv` and `orders.csv`, it maps to the same fake email in both outputs. Foreign key relationships survive anonymization.

```bash
lethe anonymize customers.csv -o safe_customers.csv --seed 42
lethe anonymize orders.csv -o safe_orders.csv --seed 42
```

As long as both runs use the same seed, the mapping is deterministic and consistent.

## GDPR and Privacy Compliance

Under GDPR, organizations must protect personal data and minimize its use. Lethe performs **pseudo-anonymization**, replacing PII with realistic fake values while preserving data structure and relationships. This is distinct from full anonymization, which irreversibly removes personal data (see [Architecture: Anonymization vs. Pseudo-anonymization](architecture.md#anonymization-vs-pseudo-anonymization) for details).

Pseudo-anonymized data is still considered personal data under GDPR (Article 4(5)), but benefits from relaxed requirements compared to raw personal data. The regulation explicitly encourages pseudo-anonymization as a safeguard (Recital 28) and recognizes it as an appropriate technical measure for data protection (Article 25, Article 32).

Lethe helps with several compliance scenarios:

### Right to be forgotten (Article 17)

When a user requests data deletion, you can verify your deletion process by pseudo-anonymizing a snapshot of the database before and after deletion, then comparing the outputs to confirm the user's data no longer appears. For actual deletion obligations, pseudo-anonymization is not sufficient on its own, you must delete the original data and any mapping that could re-identify the individual.

### Data minimization (Article 5)

Teams that need access to data structure but not actual PII (analytics, QA, support tooling) can work with pseudo-anonymized exports. This satisfies the principle of only using personal data when strictly necessary, while preserving the dataset's utility for development and testing.

### Data Protection Impact Assessments

When evaluating new data processing activities, pseudo-anonymized datasets let you prototype and test without involving real personal data during the assessment phase.

### When you need true anonymization

If your use case requires data that falls entirely outside GDPR scope, you need true anonymization rather than pseudo-anonymization. This means the data must be irreversibly stripped of all identifying information with no possibility of re-identification. Techniques include aggregation (replacing individual records with statistical summaries), generalization (broadening values, e.g. exact age to age range), or complete deletion of PII columns. Lethe does not perform true anonymization, it is a pseudo-anonymization tool.

## Sharing Data with Third Parties

Sharing production data with external vendors, consultants, or partners requires stripping PII. Common scenarios:

### Outsourced development

External development teams need realistic data to build integrations or features. Lethe produces anonymized exports that match the schema and data distribution of production without exposing real customers.

### Analytics and ML training

Data science teams or external analytics providers need large datasets. Anonymized data preserves statistical properties (column distributions, relationships between tables) while removing identifying information.

```bash
lethe anonymize user_events.csv -o user_events_anon.csv --model sm --chunk-size 2000
```

For large analytical datasets, `--model sm` gives significant speed improvements with acceptable accuracy.

### Demo environments

Sales demos and customer-facing sandbox environments need realistic-looking data. Anonymized production data looks convincing without the risk of showing real customer information during a live demo.

```bash
lethe anonymize customers.csv -o demo_customers.csv --locale en_US --seed 100
```

## CI/CD and Automated Testing

Lethe fits into automated pipelines where tests need realistic data fixtures.

```bash
# In your CI pipeline
lethe anonymize fixtures/production_snapshot.csv \
  -o fixtures/test_data.csv \
  --model sm \
  --seed 42

pytest tests/
```

The `sm` model keeps CI fast. The seed ensures tests are deterministic. If the production snapshot updates, the anonymized fixture updates consistently.

## Data Migration and Schema Testing

When migrating between databases, data formats, or cloud providers, you need to test the migration with realistic data. Anonymized exports let you run the full migration pipeline, validate schema compatibility, check data integrity, and measure performance without handling real PII in the migration staging environment.

## Incident Response and Debugging

When investigating production bugs, engineers often need to reproduce issues with the exact data that triggered them. Anonymizing the relevant records lets you share them in bug reports, Slack channels, and issue trackers without leaking customer information.

```bash
# Extract the problematic records
psql production -c "COPY (SELECT * FROM orders WHERE error_code IS NOT NULL) TO STDOUT CSV HEADER" > error_orders.csv

# Anonymize before sharing
lethe anonymize error_orders.csv -o error_orders_safe.csv --model sm
```

## Multi-locale Support

For international organizations, Lethe generates locale-appropriate fake data. A German subsidiary can produce German-looking test data, while the Dutch office gets Dutch names and addresses.

```bash
# German office
lethe anonymize kunden.csv --locale de_DE -o kunden_anon.csv

# Dutch office
lethe anonymize klanten.csv --locale nl_NL -o klanten_anon.csv

# Japanese office
lethe anonymize customers_jp.csv --locale ja_JP -o customers_jp_anon.csv
```

This keeps test data culturally appropriate for local teams, more useful than obviously American names in a German application.
