# CLI Reference

## Installation

```bash
pip install lethe-cli
python -m spacy download en_core_web_sm
```

For the transformer model (higher accuracy, slower):

```bash
pip install lethe-cli
python -m spacy download en_core_web_trf
```

For development from source:

```bash
pip install -e ".[dev]"
```

## Commands

### `lethe anonymize`

Anonymize PII in a CSV file.

```
lethe anonymize <INPUT_FILE> [OPTIONS]
```

**Arguments:**

| Argument | Description |
|---|---|
| `INPUT_FILE` | Path to the CSV file to anonymize. Must exist and be readable. |

**Options:**

| Option | Short | Default | Description |
|---|---|---|---|
| `--output` | `-o` | `<input>_anonymized.csv` | Output file path. When omitted, appends `_anonymized` to the input filename. |
| `--model` | `-m` | `trf` | NLP model to use. `trf` = transformer (accurate), `sm` = small (fast). |
| `--threshold` | `-t` | `0.35` | Minimum confidence score to classify a cell as PII. Lower values catch more PII but risk false positives. Higher values are more conservative. |
| `--chunk-size` | | `5000` | Number of rows per processing chunk. Controls memory usage for large files. |
| `--locale` | | `en_US` | Faker locale for generating replacement values. Affects name styles, address formats, phone patterns. |
| `--seed` | | None | Random seed for reproducible output. Same seed + same input = identical anonymized output. |

## Examples

### Basic usage

```bash
lethe anonymize customers.csv
```

Output: `customers_anonymized.csv` in the same directory.

### Specify output path

```bash
lethe anonymize customers.csv -o /tmp/safe_customers.csv
```

### Fast mode with small model

```bash
lethe anonymize customers.csv --model sm
```

Uses `en_core_web_sm` instead of the transformer model. Significantly faster, slightly less accurate on ambiguous names and locations.

### Reproducible output

```bash
lethe anonymize customers.csv --seed 42
```

Running this twice on the same input produces identical output. Useful for deterministic test pipelines.

### Tuning detection sensitivity

```bash
# Aggressive: catch anything that might be PII
lethe anonymize customers.csv --threshold 0.2

# Conservative: only replace high-confidence PII
lethe anonymize customers.csv --threshold 0.7
```

### Large files with limited memory

```bash
lethe anonymize huge_dataset.csv --chunk-size 1000
```

Processes 1000 rows at a time instead of the default 5000. Lower values use less memory, higher values are slightly faster.

### Dutch locale for replacement data

```bash
lethe anonymize klanten.csv --locale nl_NL
```

Generated fake names, addresses, and phone numbers will follow Dutch conventions.

### Combining options

```bash
lethe anonymize data/export.csv \
  -o data/export_safe.csv \
  --model sm \
  --threshold 0.3 \
  --locale de_DE \
  --seed 123
```
