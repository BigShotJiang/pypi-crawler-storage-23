-- MySQL dump for Lethe testing
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `ssn` varchar(11) DEFAULT NULL,
  `address` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `ssn`, `address`, `created_at`, `active`) VALUES (1, 'John', 'Smith', 'john.smith@example.com', '555-123-4567', '123-45-6789', '123 Main Street, New York, NY 10001', '2024-01-15 10:30:00', 1), (2, 'Jane', 'Doe', 'jane.doe@example.com', '555-987-6543', '987-65-4321', '456 Oak Avenue, Los Angeles, CA 90001', '2024-02-20 14:45:00', 1), (3, 'Robert', 'Johnson', 'bob.johnson@example.com', NULL, '456-78-9012', '789 Pine Road, Chicago, IL 60601', '2024-03-10 09:15:00', 0), (4, 'O\'Brien', 'Patrick', 'pat.obrien@example.com', '555-111-2222', NULL, '321 Elm St, Boston, MA 02101', '2024-04-01 08:00:00', 1);

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB;

INSERT INTO `orders` (`id`, `user_id`, `customer_name`, `customer_email`, `amount`, `status`) VALUES (101, 1, 'John Smith', 'john.smith@example.com', 99.99, 'completed'), (102, 2, 'Jane Doe', 'jane.doe@example.com', 149.50, 'pending'), (103, 1, 'John Smith', 'john.smith@example.com', 75.00, 'completed');

SET FOREIGN_KEY_CHECKS = 1;
