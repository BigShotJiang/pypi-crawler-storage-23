"""Integration test for the full pipeline."""

import pandas as pd
import pytest

from lethe.config import LetheConfig
from lethe.pipeline import default_output_path, run_pipeline
from pathlib import Path


class TestDefaultOutputPath:
    def test_adds_anonymized_suffix(self):
        p = default_output_path(Path("data/input.csv"))
        assert p == Path("data/input_anonymized.csv")


@pytest.mark.slow
class TestPipeline:
    def test_end_to_end(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        config = LetheConfig(model="sm", seed=42)
        run_pipeline(sample_customers_path, output, config)

        original = pd.read_csv(sample_customers_path)
        result = pd.read_csv(output)

        assert len(result) == len(original)
        assert list(result.columns) == list(original.columns)

        # PII columns should be different
        assert list(result["first_name"]) != list(original["first_name"])
        assert list(result["email"]) != list(original["email"])

        # Non-PII columns should be preserved
        assert list(result["id"]) == list(original["id"])
        assert list(result["status"]) == list(original["status"])
        assert list(result["created_at"]) == list(original["created_at"])
