"""Tests for the replacer engine."""

import pandas as pd

from lethe.mapping.session_index import SessionIndex
from lethe.replacer.engine import Replacer
from lethe.scanner.engine import CellResult, ColumnScanResult


class TestReplacer:
    def test_replaces_pii_cells(self):
        df = pd.DataFrame({"name": ["John", "Jane"], "id": [1, 2]})
        scan = {
            "name": ColumnScanResult(
                column="name",
                cell_results={
                    0: CellResult(entity_type="PERSON", score=0.9),
                    1: CellResult(entity_type="PERSON", score=0.9),
                },
            ),
            "id": ColumnScanResult(column="id", skipped=True),
        }
        idx = SessionIndex(seed=42)
        replacer = Replacer(idx)
        out = df.copy()
        out = replacer.replace_chunk(out, scan)

        assert out.at[0, "name"] != "John"
        assert out.at[1, "name"] != "Jane"
        assert out.at[0, "id"] == 1
        assert out.at[1, "id"] == 2

    def test_consistent_replacement(self):
        df = pd.DataFrame({"name": ["John", "Jane", "John"]})
        scan = {
            "name": ColumnScanResult(
                column="name",
                cell_results={
                    0: CellResult(entity_type="PERSON", score=0.9),
                    1: CellResult(entity_type="PERSON", score=0.9),
                    2: CellResult(entity_type="PERSON", score=0.9),
                },
            ),
        }
        idx = SessionIndex(seed=42)
        replacer = Replacer(idx)
        out = replacer.replace_chunk(df, scan)

        assert out.at[0, "name"] == out.at[2, "name"]  # same original -> same fake
        assert out.at[0, "name"] != out.at[1, "name"]

    def test_skipped_columns_untouched(self):
        df = pd.DataFrame({"status": ["active", "inactive"]})
        scan = {
            "status": ColumnScanResult(column="status", skipped=True),
        }
        idx = SessionIndex(seed=42)
        replacer = Replacer(idx)
        out = replacer.replace_chunk(df, scan)
        assert list(out["status"]) == ["active", "inactive"]
