"""Integration tests for freeform redact, generalize, and drop replacers."""

import pandas as pd
import pytest

from lethe.config import LetheConfig
from lethe.replacer.freeform_modes import (
    FreeformDropReplacer,
    FreeformGeneralizeReplacer,
    FreeformRedactReplacer,
)
from lethe.scanner.engine import PiiScanner


@pytest.fixture(scope="module")
def analyzer():
    config = LetheConfig(model="sm")
    scanner = PiiScanner(config)
    return scanner._analyzer


@pytest.mark.slow
class TestFreeformRedactReplacer:
    def test_replaces_spans_with_tokens(self, analyzer):
        df = pd.DataFrame({"text": ["Contact John Smith at john@example.com"]})
        replacer = FreeformRedactReplacer(analyzer, threshold=0.35)
        out = replacer.replace_chunk(df)

        text = out.at[0, "text"]
        assert "John Smith" not in text
        assert "[PERSON]" in text or "[EMAIL_ADDRESS]" in text

    def test_empty_text_unchanged(self, analyzer):
        df = pd.DataFrame({"text": ["", "  "]})
        replacer = FreeformRedactReplacer(analyzer, threshold=0.35)
        out = replacer.replace_chunk(df)

        assert out.at[0, "text"] == ""
        assert out.at[1, "text"] == "  "


@pytest.mark.slow
class TestFreeformGeneralizeReplacer:
    def test_generalizes_email_in_text(self, analyzer):
        df = pd.DataFrame({"text": ["Email us at support@example.com for help"]})
        replacer = FreeformGeneralizeReplacer(analyzer, threshold=0.35)
        out = replacer.replace_chunk(df)

        text = out.at[0, "text"]
        assert "support@example.com" not in text
        # Should keep the domain or fall back to redact token
        assert "example.com" in text or "[EMAIL_ADDRESS]" in text


@pytest.mark.slow
class TestFreeformDropReplacer:
    def test_removes_spans(self, analyzer):
        df = pd.DataFrame({"text": ["Contact John Smith for details"]})
        replacer = FreeformDropReplacer(analyzer, threshold=0.35)
        out = replacer.replace_chunk(df)

        text = out.at[0, "text"]
        assert "John Smith" not in text
        # Should not have double spaces
        assert "  " not in text
