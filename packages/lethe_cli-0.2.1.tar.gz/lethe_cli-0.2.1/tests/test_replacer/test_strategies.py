"""Tests for redact, generalize, and drop replacer strategies."""

import pandas as pd

from lethe.replacer.strategies import (
    DropReplacer,
    GeneralizeReplacer,
    RedactReplacer,
    _generalize,
)
from lethe.scanner.engine import CellResult, ColumnScanResult


class TestRedactReplacer:
    def test_replaces_cells_with_entity_tokens(self):
        df = pd.DataFrame({"name": ["John", "Jane"], "email": ["j@x.com", "j2@x.com"]})
        scan = {
            "name": ColumnScanResult(
                column="name",
                cell_results={
                    0: CellResult(entity_type="PERSON", score=0.9),
                    1: CellResult(entity_type="PERSON", score=0.9),
                },
            ),
            "email": ColumnScanResult(
                column="email",
                cell_results={
                    0: CellResult(entity_type="EMAIL_ADDRESS", score=0.9),
                    1: CellResult(entity_type="EMAIL_ADDRESS", score=0.9),
                },
            ),
        }
        replacer = RedactReplacer()
        out = replacer.replace_chunk(df, scan)

        assert out.at[0, "name"] == "[PERSON]"
        assert out.at[1, "name"] == "[PERSON]"
        assert out.at[0, "email"] == "[EMAIL_ADDRESS]"

    def test_preserves_skipped_columns(self):
        df = pd.DataFrame({"name": ["John"], "id": [1]})
        scan = {
            "name": ColumnScanResult(
                column="name",
                cell_results={0: CellResult(entity_type="PERSON", score=0.9)},
            ),
            "id": ColumnScanResult(column="id", skipped=True),
        }
        replacer = RedactReplacer()
        out = replacer.replace_chunk(df, scan)

        assert out.at[0, "name"] == "[PERSON]"
        assert out.at[0, "id"] == 1


class TestGeneralizeReplacer:
    def test_email_keeps_domain(self):
        assert _generalize("EMAIL_ADDRESS", "john@example.com") == "***@example.com"

    def test_date_extracts_year(self):
        assert _generalize("DATE_TIME", "2024-01-15") == "2024"

    def test_ip_keeps_first_two_octets(self):
        assert _generalize("IP_ADDRESS", "192.168.1.100") == "192.168.x.x"

    def test_url_keeps_scheme_and_host(self):
        assert _generalize("URL", "https://example.com/path?q=1") == "https://example.com"

    def test_credit_card_keeps_last_four(self):
        assert _generalize("CREDIT_CARD", "4532015112830366") == "************0366"

    def test_person_falls_back_to_redact(self):
        assert _generalize("PERSON", "John Smith") == "[PERSON]"

    def test_phone_falls_back_to_redact(self):
        assert _generalize("PHONE_NUMBER", "+1-555-0100") == "[PHONE_NUMBER]"

    def test_unknown_type_falls_back_to_redact(self):
        assert _generalize("UNKNOWN_ENTITY", "something") == "[UNKNOWN_ENTITY]"

    def test_replace_chunk_applies_generalization(self):
        df = pd.DataFrame({
            "email": ["john@example.com"],
            "name": ["John Smith"],
        })
        scan = {
            "email": ColumnScanResult(
                column="email",
                cell_results={0: CellResult(entity_type="EMAIL_ADDRESS", score=0.9)},
            ),
            "name": ColumnScanResult(
                column="name",
                cell_results={0: CellResult(entity_type="PERSON", score=0.9)},
            ),
        }
        replacer = GeneralizeReplacer()
        out = replacer.replace_chunk(df, scan)

        assert out.at[0, "email"] == "***@example.com"
        assert out.at[0, "name"] == "[PERSON]"

    def test_preserves_skipped_columns(self):
        df = pd.DataFrame({"status": ["active"], "email": ["a@b.com"]})
        scan = {
            "status": ColumnScanResult(column="status", skipped=True),
            "email": ColumnScanResult(
                column="email",
                cell_results={0: CellResult(entity_type="EMAIL_ADDRESS", score=0.9)},
            ),
        }
        replacer = GeneralizeReplacer()
        out = replacer.replace_chunk(df, scan)

        assert out.at[0, "status"] == "active"


class TestDropReplacer:
    def test_drops_pii_columns(self):
        df = pd.DataFrame({"name": ["John"], "id": [1], "email": ["j@x.com"]})
        scan = {
            "name": ColumnScanResult(
                column="name",
                cell_results={0: CellResult(entity_type="PERSON", score=0.9)},
            ),
            "id": ColumnScanResult(column="id", skipped=True),
            "email": ColumnScanResult(
                column="email",
                cell_results={0: CellResult(entity_type="EMAIL_ADDRESS", score=0.9)},
            ),
        }
        replacer = DropReplacer()
        out = replacer.replace_chunk(df, scan)

        assert list(out.columns) == ["id"]
        assert out.at[0, "id"] == 1

    def test_keeps_all_columns_when_no_pii(self):
        df = pd.DataFrame({"status": ["active"], "id": [1]})
        scan = {
            "status": ColumnScanResult(column="status", skipped=True),
            "id": ColumnScanResult(column="id", skipped=True),
        }
        replacer = DropReplacer()
        out = replacer.replace_chunk(df, scan)

        assert list(out.columns) == ["status", "id"]

    def test_preserves_skipped_columns(self):
        df = pd.DataFrame({"name": ["John"], "status": ["active"]})
        scan = {
            "name": ColumnScanResult(
                column="name",
                cell_results={0: CellResult(entity_type="PERSON", score=0.9)},
            ),
            "status": ColumnScanResult(column="status", skipped=True),
        }
        replacer = DropReplacer()
        out = replacer.replace_chunk(df, scan)

        assert "status" in out.columns
        assert "name" not in out.columns
