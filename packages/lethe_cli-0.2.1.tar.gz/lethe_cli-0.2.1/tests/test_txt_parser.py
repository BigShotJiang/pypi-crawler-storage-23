"""Tests for TXT-based parsers: TSV, line-per-value, and freeform."""

import pandas as pd
import pytest

from lethe.parsers.txt_parser import (
    FreeformReader,
    FreeformWriter,
    LineReader,
    LineWriter,
    TsvReader,
    TsvWriter,
)


class TestTsvRoundTrip:
    def test_read_tsv(self, sample_tsv_path):
        reader = TsvReader(sample_tsv_path)
        chunks = list(reader.read_chunks())
        assert len(chunks) == 1
        df = chunks[0]
        assert list(df.columns) == [
            "id", "first_name", "last_name", "email",
            "phone", "ssn", "address", "created_at", "status",
        ]
        assert len(df) == 5

    def test_write_then_read_tsv(self, tmp_path, sample_tsv_path):
        reader = TsvReader(sample_tsv_path)
        original = pd.concat(list(reader.read_chunks()), ignore_index=True)

        out_path = tmp_path / "output.tsv"
        writer = TsvWriter(out_path)
        writer.write_chunk(original)
        writer.close()

        roundtrip = pd.concat(list(TsvReader(out_path).read_chunks()), ignore_index=True)
        pd.testing.assert_frame_equal(original, roundtrip)

    def test_no_csv_quoting_in_output(self, tmp_path, sample_tsv_path):
        reader = TsvReader(sample_tsv_path)
        df = pd.concat(list(reader.read_chunks()), ignore_index=True)

        out_path = tmp_path / "output.tsv"
        writer = TsvWriter(out_path)
        writer.write_chunk(df)
        writer.close()

        content = out_path.read_text()
        assert '"' not in content


class TestLineRoundTrip:
    def test_read_lines(self, emails_txt_path):
        reader = LineReader(emails_txt_path)
        chunks = list(reader.read_chunks())
        assert len(chunks) == 1
        df = chunks[0]
        assert list(df.columns) == ["value"]
        assert len(df) == 5

    def test_write_then_read_lines(self, tmp_path, emails_txt_path):
        reader = LineReader(emails_txt_path)
        original = pd.concat(list(reader.read_chunks()), ignore_index=True)

        out_path = tmp_path / "output.txt"
        writer = LineWriter(out_path)
        writer.write_chunk(original)
        writer.close()

        roundtrip = pd.concat(list(LineReader(out_path).read_chunks()), ignore_index=True)
        pd.testing.assert_frame_equal(original, roundtrip)

    def test_line_reader_skips_empty_lines(self, tmp_path):
        f = tmp_path / "with_blanks.txt"
        f.write_text("alice@test.com\n\nbob@test.com\n\n\ncharlie@test.com\n")

        reader = LineReader(f)
        df = pd.concat(list(reader.read_chunks()), ignore_index=True)
        assert len(df) == 3
        assert list(df["value"]) == ["alice@test.com", "bob@test.com", "charlie@test.com"]


class TestFreeformRoundTrip:
    def test_read_freeform(self, freeform_txt_path):
        reader = FreeformReader(freeform_txt_path)
        chunks = list(reader.read_chunks())
        assert len(chunks) == 1
        df = chunks[0]
        assert list(df.columns) == ["text"]
        assert len(df) > 0

    def test_write_then_read_freeform(self, tmp_path, freeform_txt_path):
        reader = FreeformReader(freeform_txt_path)
        original = pd.concat(list(reader.read_chunks()), ignore_index=True)

        out_path = tmp_path / "output.txt"
        writer = FreeformWriter(out_path)
        writer.write_chunk(original)
        writer.close()

        roundtrip = pd.concat(list(FreeformReader(out_path).read_chunks()), ignore_index=True)
        pd.testing.assert_frame_equal(original, roundtrip)

    def test_freeform_reader_preserves_empty_lines(self, tmp_path):
        f = tmp_path / "paragraphs.txt"
        f.write_text("First paragraph.\n\nSecond paragraph.\n")

        reader = FreeformReader(f)
        df = pd.concat(list(reader.read_chunks()), ignore_index=True)
        assert len(df) == 3
        assert df["text"].iloc[0] == "First paragraph."
        assert df["text"].iloc[1] == ""
        assert df["text"].iloc[2] == "Second paragraph."


class TestChunking:
    def test_line_reader_respects_chunk_size(self, tmp_path):
        f = tmp_path / "many_lines.txt"
        lines = [f"value_{i}" for i in range(10)]
        f.write_text("\n".join(lines) + "\n")

        reader = LineReader(f, chunk_size=3)
        chunks = list(reader.read_chunks())
        assert len(chunks) == 4  # 3 + 3 + 3 + 1
        assert len(chunks[0]) == 3
        assert len(chunks[-1]) == 1

    def test_freeform_reader_respects_chunk_size(self, tmp_path):
        f = tmp_path / "many_lines.txt"
        lines = [f"Line {i}" for i in range(10)]
        f.write_text("\n".join(lines) + "\n")

        reader = FreeformReader(f, chunk_size=4)
        chunks = list(reader.read_chunks())
        assert len(chunks) == 3  # 4 + 4 + 2
        assert len(chunks[0]) == 4
        assert len(chunks[-1]) == 2
