"""Shared fixtures for Lethe tests."""

from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def sample_customers_path():
    return FIXTURES_DIR / "sample_customers.csv"


@pytest.fixture
def sample_orders_path():
    return FIXTURES_DIR / "sample_orders.csv"


@pytest.fixture
def sample_tsv_path():
    return FIXTURES_DIR / "sample.tsv"


@pytest.fixture
def emails_txt_path():
    return FIXTURES_DIR / "emails.txt"


@pytest.fixture
def freeform_txt_path():
    return FIXTURES_DIR / "freeform.txt"


@pytest.fixture
def sample_dump_path():
    return FIXTURES_DIR / "sample_dump.sql"
