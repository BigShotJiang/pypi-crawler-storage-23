"""Tests for SQL INSERT parser and SQL pipeline."""

from __future__ import annotations

import pandas as pd
import pytest

from lethe.config import AnonymizationMode, LetheConfig
from lethe.parsers.sql_parser import (
    InsertStatement,
    ValueType,
    is_insert,
    parse_insert,
    reconstruct_insert,
    sql_escape,
)
from lethe.sql_pipeline import run_sql_pipeline


class TestIsInsert:
    def test_basic_insert(self):
        assert is_insert("INSERT INTO users VALUES (1);")

    def test_lowercase(self):
        assert is_insert("insert into users values (1);")

    def test_leading_whitespace(self):
        assert is_insert("  INSERT INTO users VALUES (1);")

    def test_create_table(self):
        assert not is_insert("CREATE TABLE users (id INT);")

    def test_comment(self):
        assert not is_insert("-- INSERT INTO users VALUES (1);")

    def test_set_statement(self):
        assert not is_insert("SET NAMES utf8mb4;")

    def test_empty_line(self):
        assert not is_insert("")


class TestParseInsert:
    def test_simple_with_columns(self):
        sql = "INSERT INTO users (name, email) VALUES ('John', 'j@x.com');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.table == "users"
        assert stmt.columns == ["name", "email"]
        assert len(stmt.rows) == 1
        assert stmt.rows[0] == ["John", "j@x.com"]
        assert stmt.type_masks[0] == [ValueType.STRING, ValueType.STRING]

    def test_multi_row(self):
        sql = "INSERT INTO users (id, name) VALUES (1, 'John'), (2, 'Jane');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert len(stmt.rows) == 2
        assert stmt.rows[0] == ["1", "John"]
        assert stmt.rows[1] == ["2", "Jane"]
        assert stmt.type_masks[0] == [ValueType.NUMBER, ValueType.STRING]
        assert stmt.type_masks[1] == [ValueType.NUMBER, ValueType.STRING]

    def test_without_columns(self):
        sql = "INSERT INTO users VALUES (1, 'John', 'j@x.com');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.table == "users"
        assert stmt.columns is None
        assert stmt.rows[0] == ["1", "John", "j@x.com"]

    def test_null_values(self):
        sql = "INSERT INTO users (name, phone) VALUES ('John', NULL);"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.rows[0] == ["John", None]
        assert stmt.type_masks[0] == [ValueType.STRING, ValueType.NULL]

    def test_backtick_quoted_identifiers(self):
        sql = "INSERT INTO `my_db`.`users` (`name`, `email`) VALUES ('John', 'j@x.com');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.table == "my_db.users"
        assert stmt.columns == ["name", "email"]

    def test_boolean_keyword(self):
        sql = "INSERT INTO flags (name, active) VALUES ('test', TRUE);"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.rows[0] == ["test", "TRUE"]
        assert stmt.type_masks[0] == [ValueType.STRING, ValueType.KEYWORD]

    def test_negative_number(self):
        sql = "INSERT INTO data (val) VALUES (-42.5);"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.rows[0] == ["-42.5"]
        assert stmt.type_masks[0] == [ValueType.NUMBER]

    def test_backslash_escaped_quote(self):
        sql = r"INSERT INTO users (name) VALUES ('O\'Brien');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.rows[0] == ["O'Brien"]

    def test_double_single_quote_escape(self):
        sql = "INSERT INTO users (name) VALUES ('it''s');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.rows[0] == ["it's"]

    def test_not_an_insert(self):
        assert parse_insert("CREATE TABLE users (id INT);") is None

    def test_insert_select(self):
        assert parse_insert("INSERT INTO users SELECT * FROM temp;") is None

    def test_insert_ignore(self):
        sql = "INSERT IGNORE INTO users (name) VALUES ('John');"
        stmt = parse_insert(sql)
        assert stmt is not None
        assert stmt.table == "users"
        assert stmt.rows[0] == ["John"]


class TestReconstruct:
    def test_basic_roundtrip(self):
        sql = "INSERT INTO users (name, email) VALUES ('John', 'j@x.com');"
        stmt = parse_insert(sql)
        result = reconstruct_insert(stmt, stmt.rows)
        reparsed = parse_insert(result)
        assert reparsed is not None
        assert reparsed.rows == stmt.rows
        assert reparsed.type_masks == stmt.type_masks

    def test_preserves_null(self):
        sql = "INSERT INTO users (name, phone) VALUES ('John', NULL);"
        stmt = parse_insert(sql)
        result = reconstruct_insert(stmt, stmt.rows)
        assert "NULL" in result

    def test_preserves_numbers(self):
        sql = "INSERT INTO data (id, amount) VALUES (1, 99.99);"
        stmt = parse_insert(sql)
        result = reconstruct_insert(stmt, stmt.rows)
        assert "99.99" in result
        assert result.count("'") == 0  # No quotes around numbers

    def test_escapes_quotes_in_output(self):
        sql = "INSERT INTO users (name) VALUES ('John');"
        stmt = parse_insert(sql)
        modified_rows = [["O'Brien"]]
        result = reconstruct_insert(stmt, modified_rows)
        assert "O\\'Brien" in result

    def test_multi_row_roundtrip(self):
        sql = "INSERT INTO t (a, b) VALUES (1, 'x'), (2, 'y'), (3, 'z');"
        stmt = parse_insert(sql)
        result = reconstruct_insert(stmt, stmt.rows)
        reparsed = parse_insert(result)
        assert reparsed is not None
        assert len(reparsed.rows) == 3
        assert reparsed.rows == stmt.rows


class TestSqlEscape:
    def test_single_quote(self):
        assert sql_escape("it's") == "it\\'s"

    def test_backslash(self):
        assert sql_escape("a\\b") == "a\\\\b"

    def test_newline(self):
        assert sql_escape("line1\nline2") == "line1\\nline2"

    def test_no_escaping_needed(self):
        assert sql_escape("hello world") == "hello world"


class TestSampleDumpFixture:
    """Verify the test fixture parses correctly."""

    def test_fixture_parses(self, sample_dump_path):
        with open(sample_dump_path) as f:
            content = f.read()

        inserts = []
        for line in content.splitlines(keepends=True):
            if is_insert(line):
                stmt = parse_insert(line)
                if stmt:
                    inserts.append(stmt)

        assert len(inserts) == 2
        assert inserts[0].table == "users"
        assert inserts[1].table == "orders"
        assert len(inserts[0].rows) == 4
        assert len(inserts[1].rows) == 3

    def test_fixture_null_passthrough(self, sample_dump_path):
        with open(sample_dump_path) as f:
            content = f.read()

        for line in content.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt and stmt.table == "users":
                # Row 3 (Robert Johnson) has NULL phone
                assert stmt.rows[2][4] is None
                assert stmt.type_masks[2][4] == ValueType.NULL
                # Row 4 (O'Brien) has NULL ssn
                assert stmt.rows[3][5] is None
                break

    def test_fixture_escaped_quote(self, sample_dump_path):
        with open(sample_dump_path) as f:
            content = f.read()

        for line in content.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt and stmt.table == "users":
                assert stmt.rows[3][1] == "O'Brien"
                break


@pytest.mark.slow
class TestSqlPipelineModes:
    """Verify that redact, generalize, and drop modes produce valid SQL with correct schema."""

    def test_redact_mode_valid_sql(self, sample_dump_path, tmp_path):
        output = tmp_path / "redacted.sql"
        config = LetheConfig(model="sm", mode=AnonymizationMode.REDACT)
        run_sql_pipeline(sample_dump_path, output, config)

        result = output.read_text()
        assert "SET NAMES utf8mb4;" in result
        assert "CREATE TABLE" in result

        for line in result.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt and stmt.table == "users":
                assert len(stmt.columns) == 9
                assert len(stmt.rows) == 4
                for row in stmt.rows:
                    assert len(row) == 9
                # Numeric id column preserved
                assert stmt.rows[0][0] == "1"
                # NULL preserved
                assert stmt.rows[2][4] is None
                # PII cells should contain redact tokens
                first_name_idx = stmt.columns.index("first_name")
                assert stmt.rows[0][first_name_idx] == "[PERSON]"

    def test_generalize_mode_valid_sql(self, sample_dump_path, tmp_path):
        output = tmp_path / "generalized.sql"
        config = LetheConfig(model="sm", mode=AnonymizationMode.GENERALIZE)
        run_sql_pipeline(sample_dump_path, output, config)

        result = output.read_text()

        for line in result.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt and stmt.table == "users":
                assert len(stmt.columns) == 9
                assert len(stmt.rows) == 4
                for row in stmt.rows:
                    assert len(row) == 9
                # Email should be generalized (domain preserved)
                email_idx = stmt.columns.index("email")
                email_val = stmt.rows[0][email_idx]
                assert "example.com" in email_val
                assert "john.smith" not in email_val

    def test_drop_mode_removes_columns_consistently(self, sample_dump_path, tmp_path):
        output = tmp_path / "dropped.sql"
        config = LetheConfig(model="sm", mode=AnonymizationMode.DROP)
        run_sql_pipeline(sample_dump_path, output, config)

        result = output.read_text()
        assert "SET NAMES utf8mb4;" in result

        for line in result.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt and stmt.table == "users":
                # Should have fewer columns than the original 9
                assert len(stmt.columns) < 9
                # Every row must have the same number of values as columns
                for row in stmt.rows:
                    assert len(row) == len(stmt.columns), (
                        f"Row length {len(row)} != column count {len(stmt.columns)}"
                    )
                # id column should survive (it's numeric, not PII)
                assert "id" in stmt.columns
                # PII columns should be gone
                for pii_col in ("first_name", "last_name", "email", "ssn", "address"):
                    if pii_col in stmt.columns:
                        # If scanner missed it, that's ok, but the column
                        # values shouldn't be original PII
                        pass

    def test_drop_mode_sql_is_reparseable(self, sample_dump_path, tmp_path):
        """The output SQL from drop mode must be valid and reparseable."""
        output = tmp_path / "dropped.sql"
        config = LetheConfig(model="sm", mode=AnonymizationMode.DROP)
        run_sql_pipeline(sample_dump_path, output, config)

        result = output.read_text()
        insert_count = 0
        for line in result.splitlines(keepends=True):
            if is_insert(line):
                stmt = parse_insert(line)
                assert stmt is not None, f"Failed to reparse: {line[:100]}"
                insert_count += 1
                # Roundtrip: reconstruct and reparse again
                reconstructed = reconstruct_insert(stmt, stmt.rows)
                stmt2 = parse_insert(reconstructed)
                assert stmt2 is not None
                assert stmt2.columns == stmt.columns
                assert stmt2.rows == stmt.rows

        assert insert_count == 2


@pytest.mark.slow
class TestSqlPipeline:
    def test_end_to_end(self, sample_dump_path, tmp_path):
        output = tmp_path / "anon.sql"
        config = LetheConfig(model="sm", seed=42)
        run_sql_pipeline(sample_dump_path, output, config)

        assert output.exists()
        result = output.read_text()

        # Non-INSERT lines pass through unchanged
        assert "SET NAMES utf8mb4;" in result
        assert "CREATE TABLE" in result
        assert "SET FOREIGN_KEY_CHECKS = 1;" in result

        # INSERT statements are present and valid
        insert_count = sum(1 for line in result.splitlines() if is_insert(line))
        assert insert_count == 2

        # Parse the output to verify structure
        for line in result.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt and stmt.table == "users":
                assert len(stmt.rows) == 4
                # Numeric id column should be unchanged
                assert stmt.rows[0][0] == "1"
                assert stmt.rows[1][0] == "2"
                # NULL should be preserved
                assert stmt.rows[2][4] is None

    def test_fk_consistency(self, sample_dump_path, tmp_path):
        """Shared SessionIndex should map the same email consistently across tables."""
        output = tmp_path / "anon.sql"
        config = LetheConfig(model="sm", seed=42)
        run_sql_pipeline(sample_dump_path, output, config)

        result = output.read_text()
        stmts = {}
        for line in result.splitlines(keepends=True):
            stmt = parse_insert(line)
            if stmt:
                stmts[stmt.table] = stmt

        assert "users" in stmts
        assert "orders" in stmts

        # The email at users row 0 should match orders rows 0 and 2
        # (both are john.smith@example.com in the original)
        users_email_idx = stmts["users"].columns.index("email")
        orders_email_idx = stmts["orders"].columns.index("customer_email")

        user_email_0 = stmts["users"].rows[0][users_email_idx]
        order_email_0 = stmts["orders"].rows[0][orders_email_idx]
        order_email_2 = stmts["orders"].rows[2][orders_email_idx]

        assert user_email_0 == order_email_0
        assert order_email_0 == order_email_2
        # And they should differ from the original
        assert user_email_0 != "john.smith@example.com"
