"""Tests for SessionIndex mapping."""

from lethe.mapping.session_index import SessionIndex


class TestSessionIndex:
    def test_consistent_mapping(self):
        idx = SessionIndex(seed=42)
        fake1 = idx.get_or_create("PERSON", "John Smith")
        fake2 = idx.get_or_create("PERSON", "John Smith")
        assert fake1 == fake2

    def test_different_originals_get_different_fakes(self):
        idx = SessionIndex(seed=42)
        fake1 = idx.get_or_create("PERSON", "John Smith")
        fake2 = idx.get_or_create("PERSON", "Jane Doe")
        assert fake1 != fake2

    def test_same_value_different_type(self):
        idx = SessionIndex(seed=42)
        fake1 = idx.get_or_create("PERSON", "test")
        fake2 = idx.get_or_create("EMAIL_ADDRESS", "test")
        assert fake1 != fake2

    def test_mapping_count(self):
        idx = SessionIndex(seed=42)
        idx.get_or_create("PERSON", "A")
        idx.get_or_create("PERSON", "B")
        idx.get_or_create("PERSON", "A")  # duplicate
        assert idx.mapping_count == 2

    def test_generates_email_for_email_type(self):
        idx = SessionIndex(seed=42)
        fake = idx.get_or_create("EMAIL_ADDRESS", "test@example.com")
        assert "@" in fake

    def test_generates_ssn_format(self):
        idx = SessionIndex(seed=42)
        fake = idx.get_or_create("US_SSN", "123-45-6789")
        assert len(fake) > 0
