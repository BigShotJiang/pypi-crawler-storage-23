"""Tests for the CLI interface."""

import shutil

import pytest
from typer.testing import CliRunner

from lethe.cli import app

runner = CliRunner()


class TestCli:
    def test_no_args_shows_help(self):
        result = runner.invoke(app, [])
        assert "Usage" in result.output or "anonymize" in result.output

    def test_invalid_model(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(sample_customers_path), "-o", str(output), "--model", "invalid"],
        )
        assert result.exit_code != 0

    @pytest.mark.slow
    def test_anonymize_command(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(sample_customers_path), "-o", str(output), "--model", "sm"],
        )
        assert result.exit_code == 0
        assert output.exists()


class TestCleanFlag:
    """Tests for --clean / --confirm-clean on anonymize."""

    def test_clean_without_confirm_fails(self, sample_customers_path, tmp_path):
        input_copy = tmp_path / "input.csv"
        shutil.copy(sample_customers_path, input_copy)
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(input_copy), "-o", str(output), "--model", "sm", "--clean"],
        )
        assert result.exit_code != 0
        assert "--confirm-clean" in result.output
        assert input_copy.exists()

    @pytest.mark.slow
    def test_clean_with_confirm_deletes_input(self, sample_customers_path, tmp_path):
        input_copy = tmp_path / "input.csv"
        shutil.copy(sample_customers_path, input_copy)
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(input_copy), "-o", str(output), "--model", "sm", "--clean", "--confirm-clean"],
        )
        assert result.exit_code == 0
        assert output.exists()
        assert not input_copy.exists()

    @pytest.mark.slow
    def test_confirm_clean_without_clean_is_harmless(self, sample_customers_path, tmp_path):
        input_copy = tmp_path / "input.csv"
        shutil.copy(sample_customers_path, input_copy)
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(input_copy), "-o", str(output), "--model", "sm", "--confirm-clean"],
        )
        assert result.exit_code == 0
        assert input_copy.exists()


class TestModeFlag:
    """Tests for --mode on anonymize."""

    def test_invalid_mode_rejected(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(sample_customers_path), "-o", str(output), "--model", "sm", "--mode", "invalid"],
        )
        assert result.exit_code != 0
        assert "mode must be one of" in result.output

    @pytest.mark.slow
    def test_redact_mode_accepted(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(sample_customers_path), "-o", str(output), "--model", "sm", "--mode", "redact"],
        )
        assert result.exit_code == 0
        assert output.exists()

    @pytest.mark.slow
    def test_generalize_mode_accepted(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(sample_customers_path), "-o", str(output), "--model", "sm", "--mode", "generalize"],
        )
        assert result.exit_code == 0
        assert output.exists()

    @pytest.mark.slow
    def test_drop_mode_accepted(self, sample_customers_path, tmp_path):
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["anonymize", str(sample_customers_path), "-o", str(output), "--model", "sm", "--mode", "drop"],
        )
        assert result.exit_code == 0
        assert output.exists()


class TestMultiplyCleanFlag:
    """Tests for --clean / --confirm-clean on multiply."""

    def test_multiply_clean_without_confirm_fails(self, sample_customers_path, tmp_path):
        input_copy = tmp_path / "input.csv"
        shutil.copy(sample_customers_path, input_copy)
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["multiply", str(input_copy), "-o", str(output), "--factor", "2", "--clean"],
        )
        assert result.exit_code != 0
        assert "--confirm-clean" in result.output
        assert input_copy.exists()

    @pytest.mark.slow
    def test_multiply_clean_with_confirm_deletes_input(self, sample_customers_path, tmp_path):
        input_copy = tmp_path / "input.csv"
        shutil.copy(sample_customers_path, input_copy)
        output = tmp_path / "out.csv"
        result = runner.invoke(
            app,
            ["multiply", str(input_copy), "-o", str(output), "--factor", "2", "--clean", "--confirm-clean"],
        )
        assert result.exit_code == 0
        assert output.exists()
        assert not input_copy.exists()
