"""Tests for the multiply feature."""

import pandas as pd
import pytest
from typer.testing import CliRunner

from lethe.cli import app
from lethe.multiplier import Multiplier
from lethe.sanitizer import _sanitize_email, _sanitize_url, sanitize_dataframe

runner = CliRunner()


@pytest.fixture
def customers_df(sample_customers_path):
    return pd.read_csv(sample_customers_path)


class TestColumnClassification:
    def test_pii_columns_detected(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        assert "first_name" in m._pii_columns
        assert "last_name" in m._pii_columns
        assert "email" in m._pii_columns
        assert "phone" in m._pii_columns
        assert "ssn" in m._pii_columns
        assert "address" in m._pii_columns

    def test_id_column_detected(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        assert "id" in m._id_columns

    def test_sample_columns_detected(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        assert "status" in m._sample_columns
        assert "created_at" in m._sample_columns


class TestGenerate:
    def test_output_row_count(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        result = m.generate(factor=3)
        assert len(result) == len(customers_df) * 3

    def test_id_columns_sequential(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        result = m.generate(factor=3)
        ids = result["id"].tolist()
        # First 5 are originals (1-5), next 10 are sequential (6-15)
        assert ids[:5] == [1, 2, 3, 4, 5]
        assert ids[5:] == list(range(6, 16))

    def test_non_pii_columns_from_originals(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        result = m.generate(factor=3)
        original_statuses = set(customers_df["status"].tolist())
        result_statuses = set(result["status"].tolist())
        assert result_statuses.issubset(original_statuses)

    def test_pii_columns_differ_from_originals(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        result = m.generate(factor=3)
        original_emails = set(customers_df["email"].tolist())
        result_emails = set(result["email"].tolist())
        assert not result_emails.intersection(original_emails)

    def test_pii_columns_have_values(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        result = m.generate(factor=2)
        for col in m._pii_columns:
            assert result[col].notna().all()

    def test_factor_one_returns_anonymized_originals(self, customers_df):
        m = Multiplier(customers_df, seed=42)
        result = m.generate(factor=1)
        assert len(result) == len(customers_df)
        # PII should still be replaced
        original_names = set(customers_df["first_name"].tolist())
        result_names = set(result["first_name"].tolist())
        assert not result_names.intersection(original_names)


class TestSanitizeEmail:
    def test_valid_email_unchanged(self):
        assert _sanitize_email("user@example.com") == "user@example.com"

    def test_accented_chars_transliterated(self):
        result = _sanitize_email("cafe@example.com")
        assert result == "cafe@example.com"
        result = _sanitize_email("gerardfrederique@example.com")
        assert "@" in result
        assert all(ord(c) < 128 for c in result)

    def test_unicode_local_part(self):
        result = _sanitize_email("\u00e9l\u00e8ne@example.com")
        assert result == "elene@example.com"

    def test_spaces_replaced_with_underscores(self):
        result = _sanitize_email("john smith@example.com")
        assert result == "john_smith@example.com"

    def test_non_ascii_domain_transliterated(self):
        result = _sanitize_email("user@example.\u0443\u043a\u0440")
        # Non-ASCII domain chars get stripped, falls back to example.com
        assert "@" in result
        assert all(ord(c) < 128 for c in result)

    def test_double_dots_cleaned(self):
        result = _sanitize_email("user..name@example.com")
        assert ".." not in result


class TestSanitizeUrl:
    def test_valid_url_unchanged(self):
        assert _sanitize_url("https://example.com/") == "https://example.com/"

    def test_non_ascii_transliterated(self):
        result = _sanitize_url("https://www.konoplia.\u0443\u043a\u0440/")
        assert all(ord(c) < 128 for c in result)
        assert result.startswith("https://")

    def test_scheme_added_if_missing(self):
        result = _sanitize_url("example.com/path")
        assert result.startswith("https://")

    def test_spaces_replaced_with_dashes(self):
        result = _sanitize_url("https://example.com/my path")
        assert " " not in result


class TestSanitizeDataframe:
    def test_email_column_sanitized(self):
        df = pd.DataFrame({
            "email": ["\u00e9l\u00e8ne@example.com", "valid@example.com"],
            "name": ["Alice", "Bob"],
        })
        result = sanitize_dataframe(df, {"email": "EMAIL_ADDRESS"})
        assert result["email"].iloc[0] == "elene@example.com"
        assert result["name"].iloc[0] == "Alice"

    def test_non_pii_columns_untouched(self):
        df = pd.DataFrame({
            "email": ["user@example.com"],
            "status": ["active"],
        })
        result = sanitize_dataframe(df, {"email": "EMAIL_ADDRESS"})
        assert result["status"].iloc[0] == "active"


class TestCliMultiply:
    def test_multiply_command(self, sample_customers_path, tmp_path):
        output = tmp_path / "mult.csv"
        result = runner.invoke(
            app,
            ["multiply", str(sample_customers_path), "--factor", "3", "-o", str(output), "--seed", "42"],
        )
        assert result.exit_code == 0
        assert output.exists()
        df = pd.read_csv(output)
        assert len(df) == 15

    def test_multiply_with_sanitize(self, sample_customers_path, tmp_path):
        output = tmp_path / "mult.csv"
        result = runner.invoke(
            app,
            [
                "multiply", str(sample_customers_path),
                "--factor", "2", "-o", str(output),
                "--seed", "42", "--locale", "uk_UA", "--sanitize",
            ],
        )
        assert result.exit_code == 0
        df = pd.read_csv(output)
        for email in df["email"]:
            assert "@" in email
            assert all(ord(c) < 128 for c in email)

    def test_multiply_default_output(self, sample_customers_path, tmp_path):
        result = runner.invoke(
            app,
            ["multiply", str(sample_customers_path), "--factor", "2", "--seed", "42"],
        )
        assert result.exit_code == 0

    def test_multiply_shows_in_help(self):
        result = runner.invoke(app, [])
        assert "multiply" in result.output

    def test_output_is_quoted_csv(self, sample_customers_path, tmp_path):
        import csv

        output = tmp_path / "mult.csv"
        runner.invoke(
            app,
            ["multiply", str(sample_customers_path), "--factor", "2", "-o", str(output), "--seed", "42"],
        )
        # Verify the header line is fully quoted
        first_line = output.read_text().split("\n", 1)[0]
        assert first_line.startswith('"')
        # Verify all rows parse correctly via the csv module
        with open(output) as f:
            reader = csv.reader(f)
            rows = list(reader)
        assert len(rows) == 11  # 1 header + 10 data rows
