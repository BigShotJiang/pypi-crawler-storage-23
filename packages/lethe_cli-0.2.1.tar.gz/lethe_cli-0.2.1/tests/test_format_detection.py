"""Tests for file format detection."""

from pathlib import Path

from lethe.parsers import TextFormat, detect_format


class TestExtensionDetection:
    def test_csv_extension(self, sample_customers_path):
        assert detect_format(sample_customers_path) == TextFormat.CSV

    def test_tsv_extension(self, sample_tsv_path):
        assert detect_format(sample_tsv_path) == TextFormat.TSV

    def test_sql_extension(self, tmp_path):
        f = tmp_path / "dump.sql"
        f.write_text("INSERT INTO users VALUES (1);")
        assert detect_format(f) == TextFormat.SQL_DUMP

    def test_unknown_extension_defaults_csv(self, tmp_path):
        f = tmp_path / "data.dat"
        f.write_text("a,b,c\n1,2,3\n")
        assert detect_format(f) == TextFormat.CSV


class TestTxtHeuristics:
    def test_txt_with_tabs_detected_as_tsv(self, tmp_path):
        f = tmp_path / "data.txt"
        f.write_text("name\tage\tcity\nJohn\t30\tNY\nJane\t25\tLA\n")
        assert detect_format(f) == TextFormat.TSV

    def test_txt_with_short_values_detected_as_one_value(self, tmp_path):
        f = tmp_path / "emails.txt"
        f.write_text("john@example.com\njane@example.com\nbob@example.com\n")
        assert detect_format(f) == TextFormat.ONE_VALUE_PER_LINE

    def test_txt_with_paragraphs_detected_as_freeform(self, tmp_path):
        f = tmp_path / "letter.txt"
        f.write_text(
            "Dear John Smith, we are writing to confirm your appointment at our office.\n"
            "Please bring your ID and proof of address to 123 Main Street.\n"
            "\n"
            "You can reach us at 555-123-4567 or email support@example.com for questions.\n"
        )
        assert detect_format(f) == TextFormat.FREEFORM

    def test_empty_txt_defaults_to_freeform(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_text("")
        assert detect_format(f) == TextFormat.FREEFORM

    def test_fixture_emails_detected_as_one_value(self, emails_txt_path):
        assert detect_format(emails_txt_path) == TextFormat.ONE_VALUE_PER_LINE

    def test_fixture_freeform_detected_as_freeform(self, freeform_txt_path):
        assert detect_format(freeform_txt_path) == TextFormat.FREEFORM
