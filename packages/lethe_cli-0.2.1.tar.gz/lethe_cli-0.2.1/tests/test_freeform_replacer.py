"""Tests for FreeformReplacer: substring-aware PII replacement."""

import pandas as pd
import pytest

from lethe.mapping.session_index import SessionIndex
from lethe.replacer.freeform import FreeformReplacer
from lethe.scanner.engine import PiiScanner
from lethe.config import LetheConfig


@pytest.fixture
def freeform_replacer():
    config = LetheConfig(model="sm", threshold=0.35)
    scanner = PiiScanner(config)
    session_index = SessionIndex(locale="en_US", seed=42)
    return FreeformReplacer(scanner._analyzer, session_index, threshold=0.35)


@pytest.fixture
def session_index_for_replacer():
    return SessionIndex(locale="en_US", seed=42)


@pytest.mark.slow
class TestFreeformReplacer:
    def test_replaces_pii_preserves_surrounding_text(self, freeform_replacer):
        chunk = pd.DataFrame({"text": ["Contact John Smith for details."]})
        result = freeform_replacer.replace_chunk(chunk)
        text = result["text"].iloc[0]
        assert "John Smith" not in text
        assert "Contact" in text
        assert "for details." in text

    def test_multiple_pii_in_one_line(self, freeform_replacer):
        chunk = pd.DataFrame(
            {"text": ["Email john@example.com or call 555-123-4567."]}
        )
        result = freeform_replacer.replace_chunk(chunk)
        text = result["text"].iloc[0]
        assert "john@example.com" not in text
        assert "Email" in text

    def test_no_pii_passes_through(self, freeform_replacer):
        chunk = pd.DataFrame({"text": ["The quick brown fox jumps over the lazy dog."]})
        result = freeform_replacer.replace_chunk(chunk)
        assert result["text"].iloc[0] == "The quick brown fox jumps over the lazy dog."

    def test_empty_line_passes_through(self, freeform_replacer):
        chunk = pd.DataFrame({"text": [""]})
        result = freeform_replacer.replace_chunk(chunk)
        assert result["text"].iloc[0] == ""

    def test_consistent_replacement_across_lines(self, freeform_replacer):
        chunk = pd.DataFrame(
            {"text": [
                "Dear John Smith, welcome.",
                "John Smith has been registered.",
            ]}
        )
        result = freeform_replacer.replace_chunk(chunk)
        line1 = result["text"].iloc[0]
        line2 = result["text"].iloc[1]
        assert "John Smith" not in line1
        assert "John Smith" not in line2
