"""Tests for column heuristic classification."""

from lethe.scanner.column_heuristics import infer_pii_type


class TestSkipPatterns:
    def test_id_columns(self):
        assert infer_pii_type("id") == "SKIP"
        assert infer_pii_type("uuid") == "SKIP"
        assert infer_pii_type("pk") == "SKIP"

    def test_timestamp_columns(self):
        assert infer_pii_type("created_at") == "SKIP"
        assert infer_pii_type("updated_on") == "SKIP"
        assert infer_pii_type("timestamp") == "SKIP"

    def test_boolean_columns(self):
        assert infer_pii_type("is_active") == "SKIP"
        assert infer_pii_type("has_permission") == "SKIP"

    def test_status_columns(self):
        assert infer_pii_type("status") == "SKIP"
        assert infer_pii_type("category") == "SKIP"


class TestPiiHintPatterns:
    def test_person_columns(self):
        assert infer_pii_type("first_name") == "PERSON"
        assert infer_pii_type("last_name") == "PERSON"
        assert infer_pii_type("name") == "PERSON"
        assert infer_pii_type("customer_name") == "PERSON"

    def test_email_columns(self):
        assert infer_pii_type("email") == "EMAIL_ADDRESS"
        assert infer_pii_type("email_address") == "EMAIL_ADDRESS"

    def test_phone_columns(self):
        assert infer_pii_type("phone") == "PHONE_NUMBER"
        assert infer_pii_type("mobile") == "PHONE_NUMBER"

    def test_location_columns(self):
        assert infer_pii_type("address") == "LOCATION"
        assert infer_pii_type("city") == "LOCATION"
        assert infer_pii_type("zip") == "LOCATION"

    def test_ssn_columns(self):
        assert infer_pii_type("ssn") == "US_SSN"

    def test_unknown_columns(self):
        assert infer_pii_type("foobar") is None
        assert infer_pii_type("random_field") is None
