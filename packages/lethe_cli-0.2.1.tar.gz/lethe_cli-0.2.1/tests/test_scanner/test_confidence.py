"""Tests for confidence boosting logic."""

from presidio_analyzer import RecognizerResult

from lethe.scanner.confidence import (
    HEURISTIC_BOOST,
    HEURISTIC_SYNTHESIZE_SCORE,
    boost_heuristic_matches,
)


def _make_result(entity_type: str, score: float, length: int = 10) -> RecognizerResult:
    return RecognizerResult(entity_type=entity_type, start=0, end=length, score=score)


class TestBoostHeuristicMatches:
    def test_no_heuristic_returns_unchanged(self):
        results = [_make_result("PERSON", 0.5)]
        out = boost_heuristic_matches(results, None, "John")
        assert len(out) == 1
        assert out[0].score == 0.5

    def test_skip_returns_unchanged(self):
        results = [_make_result("PERSON", 0.5)]
        out = boost_heuristic_matches(results, "SKIP", "John")
        assert out[0].score == 0.5

    def test_matching_type_gets_boosted(self):
        results = [_make_result("PERSON", 0.5)]
        out = boost_heuristic_matches(results, "PERSON", "John Smith")
        assert out[0].score == 0.5 + HEURISTIC_BOOST

    def test_boost_capped_at_1(self):
        results = [_make_result("PERSON", 0.9)]
        out = boost_heuristic_matches(results, "PERSON", "John Smith")
        assert out[0].score == 1.0

    def test_synthesize_when_no_match(self):
        results = [_make_result("LOCATION", 0.5)]
        out = boost_heuristic_matches(results, "PERSON", "John Smith")
        assert len(out) == 2
        synthesized = [r for r in out if r.entity_type == "PERSON"]
        assert len(synthesized) == 1
        assert synthesized[0].score == HEURISTIC_SYNTHESIZE_SCORE

    def test_empty_cell_no_synthesize(self):
        results = []
        out = boost_heuristic_matches(results, "PERSON", "   ")
        assert len(out) == 0
