"""Sanitize generated values so emails and URLs are valid RFC-compliant strings."""

from __future__ import annotations

import re
import unicodedata

import pandas as pd


def _to_ascii(text: str) -> str:
    """Transliterate Unicode to closest ASCII equivalent.

    Decomposes accented characters (e.g. e with accent -> e), then strips
    anything that isn't ASCII.
    """
    nfkd = unicodedata.normalize("NFKD", text)
    return nfkd.encode("ascii", "ignore").decode("ascii")


def _sanitize_email(value: str) -> str:
    """Fix an email address so it is RFC 5321 compliant."""
    if "@" not in value:
        return value

    local, domain = value.rsplit("@", 1)

    # Transliterate to ASCII
    local = _to_ascii(local)
    domain = _to_ascii(domain)

    # Replace spaces and other whitespace with underscores
    local = re.sub(r"\s+", "_", local)
    domain = re.sub(r"\s+", "-", domain)

    # Strip characters not allowed in the local part (keep alphanum, . _ - +)
    local = re.sub(r"[^a-zA-Z0-9._+\-]", "", local)

    # Strip characters not allowed in domain (keep alphanum, . -)
    domain = re.sub(r"[^a-zA-Z0-9.\-]", "", domain)

    # Clean up edge cases: leading/trailing dots or dashes, double dots
    local = local.strip("._-")
    local = re.sub(r"\.{2,}", ".", local)
    domain = domain.strip(".-")
    domain = re.sub(r"\.{2,}", ".", domain)

    if not local:
        local = "user"
    if not domain or "." not in domain:
        domain = "example.com"

    return f"{local}@{domain}"


def _sanitize_url(value: str) -> str:
    """Fix a URL so it uses ASCII-safe characters."""
    url = _to_ascii(value)

    # Ensure scheme
    if not re.match(r"^https?://", url):
        url = "https://" + url

    # Replace spaces with dashes in the whole URL after scheme
    scheme_end = url.index("://") + 3
    rest = url[scheme_end:]
    rest = re.sub(r"\s+", "-", rest)
    # Strip characters not valid in a URL (keep alphanum and common URL chars)
    rest = re.sub(r"[^a-zA-Z0-9.\-_~:/?#\[\]@!$&'()*+,;=%]", "", rest)

    return url[:scheme_end] + rest


# Entity types that produce email-like values
_EMAIL_TYPES = {"EMAIL_ADDRESS"}

# Entity types that produce URL-like values
_URL_TYPES = {"URL"}


def sanitize_dataframe(
    df: pd.DataFrame,
    pii_columns: dict[str, str],
) -> pd.DataFrame:
    """Sanitize email and URL columns in-place so values are valid."""
    result = df.copy()

    for col, entity_type in pii_columns.items():
        if col not in result.columns:
            continue
        if entity_type in _EMAIL_TYPES:
            result[col] = result[col].apply(
                lambda v: _sanitize_email(str(v)) if pd.notna(v) else v
            )
        elif entity_type in _URL_TYPES:
            result[col] = result[col].apply(
                lambda v: _sanitize_url(str(v)) if pd.notna(v) else v
            )

    return result
