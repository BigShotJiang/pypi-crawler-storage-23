"""Chunked CSV reader and writer using pandas."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterator

import pandas as pd


class CsvReader:
    def __init__(self, path: Path, chunk_size: int = 5000) -> None:
        self.path = path
        self.chunk_size = chunk_size

    def read_chunks(self) -> Iterator[pd.DataFrame]:
        with pd.read_csv(self.path, chunksize=self.chunk_size) as reader:
            yield from reader


class CsvWriter:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._first = True

    def write_chunk(self, chunk: pd.DataFrame, *, header: bool = False) -> None:
        write_header = header or self._first
        chunk.to_csv(
            self.path,
            mode="a" if not self._first else "w",
            header=write_header,
            index=False,
            quoting=csv.QUOTE_ALL,
        )
        self._first = False

    def close(self) -> None:
        pass
