"""Protocols for chunked file I/O."""

from __future__ import annotations

from typing import Iterator, Protocol

import pandas as pd


class ChunkedReader(Protocol):
    def read_chunks(self) -> Iterator[pd.DataFrame]: ...


class ChunkedWriter(Protocol):
    def write_chunk(self, chunk: pd.DataFrame, *, header: bool = False) -> None: ...

    def close(self) -> None: ...
