"""SQL INSERT statement parser for dump anonymization."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ValueType(Enum):
    STRING = "string"
    NUMBER = "number"
    NULL = "null"
    KEYWORD = "keyword"


@dataclass
class InsertStatement:
    """Parsed representation of an INSERT statement."""

    prefix: str
    table: str
    columns: list[str] | None
    rows: list[list] = field(default_factory=list)
    type_masks: list[list[ValueType]] = field(default_factory=list)


def is_insert(line: str) -> bool:
    """Quick check if a line starts an INSERT statement."""
    return line.lstrip().upper().startswith("INSERT")


def parse_insert(line: str) -> InsertStatement | None:
    """Parse an INSERT statement into its components.

    Returns None for lines that aren't valid INSERT ... VALUES statements.
    """
    stripped = line.strip()
    upper = stripped.upper()

    if not upper.startswith("INSERT"):
        return None

    values_idx = upper.find(" VALUES")
    if values_idx == -1:
        return None

    prefix = stripped[:values_idx]
    values_part = stripped[values_idx + 7:].strip()

    if values_part.endswith(";"):
        values_part = values_part[:-1].rstrip()

    table, columns = _parse_prefix(prefix)
    if table is None:
        return None

    rows, type_masks = _tokenize_values(values_part)
    if not rows:
        return None

    return InsertStatement(
        prefix=prefix,
        table=table,
        columns=columns,
        rows=rows,
        type_masks=type_masks,
    )


def reconstruct_insert(stmt: InsertStatement, rows: list[list]) -> str:
    """Rebuild an INSERT from (possibly modified) rows, preserving the original prefix."""
    parts = [stmt.prefix, " VALUES "]

    row_strs = []
    for row, mask in zip(rows, stmt.type_masks):
        vals = []
        for val, vtype in zip(row, mask):
            if vtype == ValueType.NULL:
                vals.append("NULL")
            elif vtype == ValueType.STRING:
                vals.append("'" + sql_escape(str(val)) + "'")
            else:
                vals.append(str(val))
        row_strs.append("(" + ", ".join(vals) + ")")

    parts.append(", ".join(row_strs))
    parts.append(";\n")
    return "".join(parts)


def sql_escape(value: str) -> str:
    """Escape a string for use inside SQL single-quoted literals."""
    value = value.replace("\\", "\\\\")
    value = value.replace("'", "\\'")
    value = value.replace("\n", "\\n")
    value = value.replace("\r", "\\r")
    value = value.replace("\t", "\\t")
    value = value.replace("\0", "\\0")
    return value


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_prefix(prefix: str) -> tuple[str | None, list[str] | None]:
    """Extract table name and optional column list from the INSERT prefix."""
    rest = prefix.strip()

    if not rest.upper().startswith("INSERT"):
        return None, None
    rest = rest[6:].lstrip()

    rest_upper = rest.upper()
    for kw in ("IGNORE ", "OR REPLACE "):
        if rest_upper.startswith(kw):
            rest = rest[len(kw):].lstrip()
            rest_upper = rest.upper()

    if rest_upper.startswith("INTO"):
        rest = rest[4:].lstrip()

    table, rest = _consume_identifier(rest)
    if table is None:
        return None, None

    rest = rest.lstrip()
    if rest.startswith("."):
        rest = rest[1:]
        tbl_part, rest = _consume_identifier(rest)
        if tbl_part:
            table = table + "." + tbl_part

    rest = rest.lstrip()
    columns = None
    if rest.startswith("("):
        close = rest.find(")")
        if close != -1:
            col_str = rest[1:close]
            columns = [_unquote_identifier(c) for c in col_str.split(",")]

    return table, columns


def _consume_identifier(text: str) -> tuple[str | None, str]:
    """Consume a possibly-quoted identifier from the start of *text*."""
    text = text.lstrip()
    if not text:
        return None, ""

    if text[0] == "`":
        end = text.find("`", 1)
        if end == -1:
            return None, text
        return text[1:end], text[end + 1:]

    if text[0] == '"':
        end = text.find('"', 1)
        if end == -1:
            return None, text
        return text[1:end], text[end + 1:]

    i = 0
    while i < len(text) and text[i] not in " \t\n\r(.":
        i += 1
    if i == 0:
        return None, text
    return text[:i], text[i:]


def _unquote_identifier(ident: str) -> str:
    """Strip surrounding backticks or double-quotes from an identifier."""
    ident = ident.strip()
    if len(ident) >= 2:
        if (ident[0] == "`" and ident[-1] == "`") or (
            ident[0] == '"' and ident[-1] == '"'
        ):
            return ident[1:-1]
    return ident


def _tokenize_values(
    values_str: str,
) -> tuple[list[list], list[list[ValueType]]]:
    """Parse the VALUES portion into rows of values and parallel type masks."""
    rows: list[list] = []
    type_masks: list[list[ValueType]] = []
    current_row: list = []
    current_mask: list[ValueType] = []

    i = 0
    n = len(values_str)
    in_tuple = False

    while i < n:
        c = values_str[i]

        if c in " \t\n\r":
            i += 1
            continue

        if c == "(" and not in_tuple:
            in_tuple = True
            current_row = []
            current_mask = []
            i += 1
            continue

        if c == ")" and in_tuple:
            rows.append(current_row)
            type_masks.append(current_mask)
            in_tuple = False
            i += 1
            continue

        if c == ",":
            i += 1
            continue

        if not in_tuple:
            i += 1
            continue

        # Inside a value tuple: parse the next value
        if c == "'":
            val, end_idx = _parse_string_literal(values_str, i)
            current_row.append(val)
            current_mask.append(ValueType.STRING)
            i = end_idx

        elif values_str[i : i + 4].upper() == "NULL" and (
            i + 4 >= n or values_str[i + 4] in ",) \t\n\r"
        ):
            current_row.append(None)
            current_mask.append(ValueType.NULL)
            i += 4

        elif c in "-0123456789.":
            j = i + 1
            while j < n and values_str[j] not in ",) \t\n\r":
                j += 1
            current_row.append(values_str[i:j].strip())
            current_mask.append(ValueType.NUMBER)
            i = j

        else:
            j = i
            while j < n and values_str[j] not in ",) \t\n\r":
                j += 1
            current_row.append(values_str[i:j].strip())
            current_mask.append(ValueType.KEYWORD)
            i = j

    return rows, type_masks


def _parse_string_literal(text: str, start: int) -> tuple[str, int]:
    """Parse a SQL string literal starting at the opening quote at *start*."""
    parts: list[str] = []
    i = start + 1
    n = len(text)

    while i < n:
        c = text[i]

        if c == "\\" and i + 1 < n:
            nc = text[i + 1]
            _ESCAPE_MAP = {"n": "\n", "r": "\r", "t": "\t", "0": "\0"}
            parts.append(_ESCAPE_MAP.get(nc, nc))
            i += 2
        elif c == "'" and i + 1 < n and text[i + 1] == "'":
            parts.append("'")
            i += 2
        elif c == "'":
            return "".join(parts), i + 1
        else:
            parts.append(c)
            i += 1

    return "".join(parts), i
