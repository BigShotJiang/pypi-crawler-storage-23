"""Format detection and parser factory for supported file types."""

from __future__ import annotations

from enum import Enum
from pathlib import Path

from lethe.parsers.csv_parser import CsvReader, CsvWriter
from lethe.parsers.txt_parser import (
    FreeformReader,
    FreeformWriter,
    LineReader,
    LineWriter,
    TsvReader,
    TsvWriter,
)


class TextFormat(Enum):
    CSV = "csv"
    TSV = "tsv"
    ONE_VALUE_PER_LINE = "one_value_per_line"
    FREEFORM = "freeform"
    SQL_DUMP = "sql"


def detect_format(path: Path) -> TextFormat:
    """Detect file format from extension and content heuristics."""
    suffix = path.suffix.lower()

    if suffix == ".csv":
        return TextFormat.CSV
    if suffix == ".tsv":
        return TextFormat.TSV
    if suffix == ".sql":
        return TextFormat.SQL_DUMP

    if suffix == ".txt":
        return _detect_txt_format(path)

    return TextFormat.CSV


def _detect_txt_format(path: Path) -> TextFormat:
    """Inspect .txt file content to determine the sub-format."""
    lines: list[str] = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i >= 20:
                break
            lines.append(line.rstrip("\n\r"))

    if not lines:
        return TextFormat.FREEFORM

    non_empty = [l for l in lines if l.strip()]
    if not non_empty:
        return TextFormat.FREEFORM

    tab_counts = [l.count("\t") for l in non_empty]
    if tab_counts and min(tab_counts) >= 1:
        consistent = all(c == tab_counts[0] for c in tab_counts)
        if consistent:
            return TextFormat.TSV

    total_chars = sum(len(l) for l in non_empty)
    avg_chars = total_chars / len(non_empty) if non_empty else 0
    max_words = max((len(l.split()) for l in non_empty), default=0)

    if avg_chars < 60 and max_words <= 4:
        return TextFormat.ONE_VALUE_PER_LINE

    return TextFormat.FREEFORM


def make_reader(path: Path, fmt: TextFormat, chunk_size: int = 5000):
    """Create the appropriate reader for a given format."""
    if fmt == TextFormat.CSV:
        return CsvReader(path, chunk_size=chunk_size)
    if fmt == TextFormat.TSV:
        return TsvReader(path, chunk_size=chunk_size)
    if fmt == TextFormat.ONE_VALUE_PER_LINE:
        return LineReader(path, chunk_size=chunk_size)
    if fmt == TextFormat.FREEFORM:
        return FreeformReader(path, chunk_size=chunk_size)
    return CsvReader(path, chunk_size=chunk_size)


def make_writer(path: Path, fmt: TextFormat):
    """Create the appropriate writer for a given format."""
    if fmt == TextFormat.CSV:
        return CsvWriter(path)
    if fmt == TextFormat.TSV:
        return TsvWriter(path)
    if fmt == TextFormat.ONE_VALUE_PER_LINE:
        return LineWriter(path)
    if fmt == TextFormat.FREEFORM:
        return FreeformWriter(path)
    return CsvWriter(path)
