"""Parsers for text-based file formats: TSV, one-value-per-line, free-form."""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

import pandas as pd


class TsvReader:
    def __init__(self, path: Path, chunk_size: int = 5000) -> None:
        self.path = path
        self.chunk_size = chunk_size

    def read_chunks(self) -> Iterator[pd.DataFrame]:
        with pd.read_csv(self.path, sep="\t", chunksize=self.chunk_size) as reader:
            yield from reader


class TsvWriter:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._first = True

    def write_chunk(self, chunk: pd.DataFrame, *, header: bool = False) -> None:
        write_header = header or self._first
        chunk.to_csv(
            self.path,
            mode="a" if not self._first else "w",
            header=write_header,
            index=False,
            sep="\t",
        )
        self._first = False

    def close(self) -> None:
        pass


class LineReader:
    def __init__(self, path: Path, chunk_size: int = 5000) -> None:
        self.path = path
        self.chunk_size = chunk_size

    def read_chunks(self) -> Iterator[pd.DataFrame]:
        buf: list[str] = []
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                stripped = line.rstrip("\n\r")
                if not stripped:
                    continue
                buf.append(stripped)
                if len(buf) >= self.chunk_size:
                    yield pd.DataFrame({"value": buf})
                    buf = []
        if buf:
            yield pd.DataFrame({"value": buf})


class LineWriter:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._first = True

    def write_chunk(self, chunk: pd.DataFrame, *, header: bool = False) -> None:
        mode = "w" if self._first else "a"
        with open(self.path, mode, encoding="utf-8") as f:
            for value in chunk["value"]:
                f.write(str(value) + "\n")
        self._first = False

    def close(self) -> None:
        pass


class FreeformReader:
    def __init__(self, path: Path, chunk_size: int = 5000) -> None:
        self.path = path
        self.chunk_size = chunk_size

    def read_chunks(self) -> Iterator[pd.DataFrame]:
        buf: list[str] = []
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                text = line.rstrip("\n\r")
                buf.append(text)
                if len(buf) >= self.chunk_size:
                    yield pd.DataFrame({"text": buf})
                    buf = []
        if buf:
            yield pd.DataFrame({"text": buf})


class FreeformWriter:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._first = True

    def write_chunk(self, chunk: pd.DataFrame, *, header: bool = False) -> None:
        mode = "w" if self._first else "a"
        with open(self.path, mode, encoding="utf-8") as f:
            for text in chunk["text"]:
                f.write(str(text) + "\n")
        self._first = False

    def close(self) -> None:
        pass
