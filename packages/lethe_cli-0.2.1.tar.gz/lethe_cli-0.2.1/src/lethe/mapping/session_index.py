"""Session-scoped mapping index: original value -> consistent fake replacement."""

from __future__ import annotations

from faker import Faker


FAKER_GENERATORS: dict[str, str] = {
    "PERSON": "name",
    "EMAIL_ADDRESS": "email",
    "PHONE_NUMBER": "phone_number",
    "LOCATION": "address",
    "US_SSN": "ssn",
    "CREDIT_CARD": "credit_card_number",
    "DATE_TIME": "date",
    "IP_ADDRESS": "ipv4",
    "IBAN_CODE": "iban",
    "US_DRIVER_LICENSE": "bothify",
    "US_PASSPORT": "bothify",
    "UK_NINO": "bothify",
    "NL_BSN": "numerify",
    "URL": "url",
    "CRYPTO": "sha1",
}

FAKER_GENERATOR_KWARGS: dict[str, dict] = {
    "US_DRIVER_LICENSE": {"text": "??#######"},
    "US_PASSPORT": {"text": "#########"},
    "UK_NINO": {"text": "??######?"},
    "NL_BSN": {"text": "#########"},
}


class SessionIndex:
    """Maintains a dict mapping (entity_type, original) -> fake value.

    Ensures cross-table consistency: the same original value always maps
    to the same fake replacement within a session.
    """

    def __init__(self, locale: str = "en_US", seed: int | None = None) -> None:
        self._faker = Faker(locale)
        if seed is not None:
            Faker.seed(seed)
        self._index: dict[tuple[str, str], str] = {}

    def get_or_create(self, entity_type: str, original: str) -> str:
        key = (entity_type, original)
        if key in self._index:
            return self._index[key]

        fake_value = self._generate(entity_type)
        self._index[key] = fake_value
        return fake_value

    def _generate(self, entity_type: str) -> str:
        method_name = FAKER_GENERATORS.get(entity_type, "text")
        method = getattr(self._faker, method_name)
        kwargs = FAKER_GENERATOR_KWARGS.get(entity_type, {})
        result = method(**kwargs) if kwargs else method()
        return str(result)

    @property
    def mapping_count(self) -> int:
        return len(self._index)
