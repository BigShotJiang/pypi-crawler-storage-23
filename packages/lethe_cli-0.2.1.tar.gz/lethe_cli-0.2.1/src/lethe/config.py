"""Configuration for Lethe anonymization runs."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

SPACY_MODELS = {
    "trf": "en_core_web_trf",
    "sm": "en_core_web_sm",
}

DEFAULT_THRESHOLD = 0.35
DEFAULT_CHUNK_SIZE = 5000
DEFAULT_LOCALE = "en_US"


class AnonymizationMode(str, Enum):
    PSEUDO = "pseudo"
    REDACT = "redact"
    GENERALIZE = "generalize"
    DROP = "drop"


@dataclass(frozen=True)
class LetheConfig:
    model: str = "trf"
    threshold: float = DEFAULT_THRESHOLD
    chunk_size: int = DEFAULT_CHUNK_SIZE
    locale: str = DEFAULT_LOCALE
    seed: int | None = None
    mode: AnonymizationMode = AnonymizationMode.PSEUDO

    @property
    def spacy_model(self) -> str:
        return SPACY_MODELS[self.model]
