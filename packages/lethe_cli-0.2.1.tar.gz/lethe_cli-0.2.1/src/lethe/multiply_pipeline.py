"""Pipeline for the multiply command: read -> multiply -> write."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from rich.console import Console

from lethe.multiplier import Multiplier
from lethe.parsers import TextFormat, detect_format, make_writer
from lethe.sanitizer import sanitize_dataframe

console = Console()


def default_multiply_output(input_path: Path) -> Path:
    return input_path.with_stem(input_path.stem + "_multiplied")


def run_multiply(
    input_path: Path,
    output_path: Path | None,
    factor: int,
    locale: str = "en_US",
    seed: int | None = None,
    sanitize: bool = False,
) -> Path:
    if output_path is None:
        output_path = default_multiply_output(input_path)

    fmt = detect_format(input_path)

    if fmt in (TextFormat.FREEFORM, TextFormat.ONE_VALUE_PER_LINE):
        console.print(
            f"[red]Error:[/red] Cannot multiply {fmt.value} files. "
            "Multiply only supports CSV and TSV formats with columnar data.",
            highlight=False,
        )
        raise SystemExit(1)

    console.print(f"[bold]Lethe[/bold] multiplying [cyan]{input_path.name}[/cyan]")
    console.print(f"  Format: [yellow]{fmt.value}[/yellow]")
    console.print(f"  Factor: [yellow]{factor}x[/yellow]")
    console.print(f"  Output: [cyan]{output_path}[/cyan]")

    sep = "\t" if fmt == TextFormat.TSV else ","
    df = pd.read_csv(input_path, sep=sep)
    n_input = len(df)

    console.print(f"  Input rows: [yellow]{n_input}[/yellow]")

    multiplier = Multiplier(df, locale=locale, seed=seed)
    result = multiplier.generate(factor)

    if sanitize:
        console.print("  Sanitizing emails and URLs...", style="dim")
        result = sanitize_dataframe(result, multiplier._pii_columns)

    writer = make_writer(output_path, fmt)
    writer.write_chunk(result)
    writer.close()

    n_output = len(result)
    console.print(
        f"\n  [green]Done.[/green] {n_input} input rows -> {n_output} output rows "
        f"({factor}x multiplication)."
    )
    return output_path
