"""Anonymization replacer strategies: redact, generalize, drop."""

from __future__ import annotations

import re
from urllib.parse import urlparse

import pandas as pd

from lethe.scanner.engine import ColumnScanResult


def _generalize(entity_type: str, value: str) -> str:
    """Apply entity-type-specific generalization, fallback to redact."""
    if entity_type == "EMAIL_ADDRESS" and "@" in value:
        _, domain = value.rsplit("@", 1)
        return f"***@{domain}"

    if entity_type == "DATE_TIME":
        m = re.search(r"\b(\d{4})\b", value)
        if m:
            return m.group(1)

    if entity_type == "IP_ADDRESS":
        parts = value.split(".")
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.x.x"

    if entity_type == "URL":
        try:
            parsed = urlparse(value)
            if parsed.scheme and parsed.hostname:
                return f"{parsed.scheme}://{parsed.hostname}"
        except Exception:
            pass

    if entity_type == "CREDIT_CARD":
        digits = re.sub(r"\D", "", value)
        if len(digits) >= 4:
            return "*" * (len(digits) - 4) + digits[-4:]

    return f"[{entity_type}]"


class RedactReplacer:
    """Replaces PII cells with [ENTITY_TYPE] tokens."""

    def replace_chunk(
        self,
        chunk: pd.DataFrame,
        scan_results: dict[str, ColumnScanResult],
    ) -> pd.DataFrame:
        out = chunk.copy()

        for col, col_result in scan_results.items():
            if col_result.skipped or not col_result.cell_results:
                continue

            for row_idx, cell_result in col_result.cell_results.items():
                out.at[row_idx, col] = f"[{cell_result.entity_type}]"

        return out


class GeneralizeReplacer:
    """Applies entity-type-specific reduction, falls back to [ENTITY_TYPE]."""

    def replace_chunk(
        self,
        chunk: pd.DataFrame,
        scan_results: dict[str, ColumnScanResult],
    ) -> pd.DataFrame:
        out = chunk.copy()

        for col, col_result in scan_results.items():
            if col_result.skipped or not col_result.cell_results:
                continue

            for row_idx, cell_result in col_result.cell_results.items():
                original = str(out.at[row_idx, col])
                out.at[row_idx, col] = _generalize(
                    cell_result.entity_type, original
                )

        return out


class DropReplacer:
    """Drops entire columns where PII was detected."""

    def replace_chunk(
        self,
        chunk: pd.DataFrame,
        scan_results: dict[str, ColumnScanResult],
    ) -> pd.DataFrame:
        cols_to_drop = []
        for col, col_result in scan_results.items():
            if col_result.skipped or not col_result.cell_results:
                continue
            cols_to_drop.append(col)

        return chunk.drop(columns=cols_to_drop)
