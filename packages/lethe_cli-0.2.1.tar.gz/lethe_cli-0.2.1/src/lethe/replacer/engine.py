"""Whole-cell replacement engine for structured CSV data."""

from __future__ import annotations

import pandas as pd

from lethe.mapping.session_index import SessionIndex
from lethe.scanner.engine import ColumnScanResult


class Replacer:
    """Replaces PII cells using the session index for consistent fakes."""

    def __init__(self, session_index: SessionIndex) -> None:
        self._index = session_index

    def replace_chunk(
        self,
        chunk: pd.DataFrame,
        scan_results: dict[str, ColumnScanResult],
    ) -> pd.DataFrame:
        out = chunk.copy()

        for col, col_result in scan_results.items():
            if col_result.skipped or not col_result.cell_results:
                continue

            for row_idx, cell_result in col_result.cell_results.items():
                original = str(out.at[row_idx, col])
                fake = self._index.get_or_create(cell_result.entity_type, original)
                out.at[row_idx, col] = fake

        return out
