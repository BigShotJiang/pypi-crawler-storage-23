"""Substring-aware PII replacement for free-form text."""

from __future__ import annotations

import pandas as pd
from presidio_analyzer import AnalyzerEngine

from lethe.mapping.session_index import SessionIndex


class FreeformReplacer:
    """Replaces PII substrings within free-form text, preserving surrounding content."""

    def __init__(
        self,
        analyzer: AnalyzerEngine,
        session_index: SessionIndex,
        threshold: float = 0.35,
    ) -> None:
        self._analyzer = analyzer
        self._index = session_index
        self._threshold = threshold

    def replace_chunk(self, chunk: pd.DataFrame) -> pd.DataFrame:
        out = chunk.copy()
        out["text"] = out["text"].apply(self._replace_line)
        return out

    def _replace_line(self, text: str) -> str:
        if not text or not text.strip():
            return text

        results = self._analyzer.analyze(text=text, language="en", entities=None)

        filtered = [r for r in results if r.score >= self._threshold]
        if not filtered:
            return text

        # Deduplicate overlapping spans: keep the highest-scoring result
        filtered.sort(key=lambda r: (r.start, -r.score))
        deduped: list = []
        for r in filtered:
            if deduped and r.start < deduped[-1].end:
                if r.score > deduped[-1].score:
                    deduped[-1] = r
            else:
                deduped.append(r)

        # Replace right-to-left so character offsets remain valid
        deduped.sort(key=lambda r: r.start, reverse=True)

        for r in deduped:
            original = text[r.start : r.end]
            fake = self._index.get_or_create(r.entity_type, original)
            text = text[: r.start] + fake + text[r.end :]

        return text
