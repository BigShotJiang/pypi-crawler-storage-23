"""Freeform text replacer variants: redact, generalize, drop."""

from __future__ import annotations

import re

import pandas as pd
from presidio_analyzer import AnalyzerEngine

from lethe.replacer.strategies import _generalize


class FreeformRedactReplacer:
    """Replaces PII spans in free-form text with [ENTITY_TYPE] tokens."""

    def __init__(self, analyzer: AnalyzerEngine, threshold: float = 0.35) -> None:
        self._analyzer = analyzer
        self._threshold = threshold

    def replace_chunk(self, chunk: pd.DataFrame) -> pd.DataFrame:
        out = chunk.copy()
        out["text"] = out["text"].apply(self._replace_line)
        return out

    def _replace_line(self, text: str) -> str:
        if not text or not text.strip():
            return text

        results = self._analyzer.analyze(text=text, language="en", entities=None)
        filtered = [r for r in results if r.score >= self._threshold]
        if not filtered:
            return text

        deduped = _dedup_spans(filtered)
        deduped.sort(key=lambda r: r.start, reverse=True)

        for r in deduped:
            text = text[: r.start] + f"[{r.entity_type}]" + text[r.end :]

        return text


class FreeformGeneralizeReplacer:
    """Applies entity-type-specific generalization within free-form text."""

    def __init__(self, analyzer: AnalyzerEngine, threshold: float = 0.35) -> None:
        self._analyzer = analyzer
        self._threshold = threshold

    def replace_chunk(self, chunk: pd.DataFrame) -> pd.DataFrame:
        out = chunk.copy()
        out["text"] = out["text"].apply(self._replace_line)
        return out

    def _replace_line(self, text: str) -> str:
        if not text or not text.strip():
            return text

        results = self._analyzer.analyze(text=text, language="en", entities=None)
        filtered = [r for r in results if r.score >= self._threshold]
        if not filtered:
            return text

        deduped = _dedup_spans(filtered)
        deduped.sort(key=lambda r: r.start, reverse=True)

        for r in deduped:
            original = text[r.start : r.end]
            replacement = _generalize(r.entity_type, original)
            text = text[: r.start] + replacement + text[r.end :]

        return text


class FreeformDropReplacer:
    """Removes PII spans from free-form text, cleaning up whitespace."""

    def __init__(self, analyzer: AnalyzerEngine, threshold: float = 0.35) -> None:
        self._analyzer = analyzer
        self._threshold = threshold

    def replace_chunk(self, chunk: pd.DataFrame) -> pd.DataFrame:
        out = chunk.copy()
        out["text"] = out["text"].apply(self._replace_line)
        return out

    def _replace_line(self, text: str) -> str:
        if not text or not text.strip():
            return text

        results = self._analyzer.analyze(text=text, language="en", entities=None)
        filtered = [r for r in results if r.score >= self._threshold]
        if not filtered:
            return text

        deduped = _dedup_spans(filtered)
        deduped.sort(key=lambda r: r.start, reverse=True)

        for r in deduped:
            text = text[: r.start] + text[r.end :]

        # Clean up double/triple spaces left by removals
        text = re.sub(r"  +", " ", text)
        return text


def _dedup_spans(results: list) -> list:
    """Deduplicate overlapping spans, keeping the highest-scoring result."""
    results.sort(key=lambda r: (r.start, -r.score))
    deduped: list = []
    for r in results:
        if deduped and r.start < deduped[-1].end:
            if r.score > deduped[-1].score:
                deduped[-1] = r
        else:
            deduped.append(r)
    return deduped
