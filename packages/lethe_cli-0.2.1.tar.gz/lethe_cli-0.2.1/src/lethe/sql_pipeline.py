"""Streaming SQL dump anonymization pipeline."""

from __future__ import annotations

from pathlib import Path
from typing import IO

import pandas as pd
from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from lethe.config import AnonymizationMode, LetheConfig
from lethe.mapping.session_index import SessionIndex
from lethe.parsers.sql_parser import (
    InsertStatement,
    ValueType,
    is_insert,
    parse_insert,
    reconstruct_insert,
)
from lethe.replacer.engine import Replacer
from lethe.replacer.strategies import DropReplacer, GeneralizeReplacer, RedactReplacer
from lethe.scanner.engine import PiiScanner

console = Console()


def _make_sql_replacer(config, session_index):
    """Return the structured replacer based on mode."""
    mode = config.mode
    if mode == AnonymizationMode.PSEUDO:
        return Replacer(session_index)
    if mode == AnonymizationMode.REDACT:
        return RedactReplacer()
    if mode == AnonymizationMode.GENERALIZE:
        return GeneralizeReplacer()
    if mode == AnonymizationMode.DROP:
        return DropReplacer()
    raise ValueError(f"Unknown mode: {mode}")


def default_sql_output_path(input_path: Path) -> Path:
    return input_path.with_stem(input_path.stem + "_anonymized")


def run_sql_pipeline(
    input_path: Path,
    output_path: Path | None,
    config: LetheConfig,
) -> Path:
    if output_path is None:
        output_path = default_sql_output_path(input_path)

    console.print(f"[bold]Lethe[/bold] anonymizing SQL dump [cyan]{input_path.name}[/cyan]")
    console.print(f"  Model: [yellow]{config.spacy_model}[/yellow]")
    console.print(f"  Mode: [yellow]{config.mode.value}[/yellow]")
    console.print(f"  Output: [cyan]{output_path}[/cyan]")
    console.print("  Loading NLP engine...", style="dim")

    scanner = PiiScanner(config)
    session_index = SessionIndex(locale=config.locale, seed=config.seed)
    replacer = _make_sql_replacer(config, session_index)

    insert_count = 0
    line_count = 0

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.fields[status]}"),
        TimeElapsedColumn(),
        console=console,
    )

    with progress:
        task = progress.add_task("Processing SQL", total=None, status="")

        with open(input_path, encoding="utf-8") as fin, open(
            output_path, "w", encoding="utf-8"
        ) as fout:
            for text, is_ins in _iter_statements(fin):
                line_count += 1

                if is_ins:
                    stmt = parse_insert(text)
                    if stmt:
                        anonymized_text = _anonymize_insert(
                            stmt, scanner, replacer, config.mode
                        )
                        fout.write(anonymized_text)
                        insert_count += 1
                    else:
                        fout.write(text)
                else:
                    fout.write(text)

                progress.update(
                    task,
                    status=f"{insert_count} INSERTs | {line_count} lines",
                )

    if config.mode == AnonymizationMode.PSEUDO:
        summary = f"{session_index.mapping_count} unique PII values replaced"
    else:
        summary = f"mode={config.mode.value}"

    console.print(
        f"\n  [green]Done.[/green] {insert_count} INSERT statement(s) processed, "
        f"{summary}."
    )
    return output_path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _iter_statements(fh: IO[str]):
    """Yield (text, is_insert) tuples, buffering multi-line INSERTs."""
    buffer: list[str] = []
    in_insert = False

    for line in fh:
        if not in_insert:
            if is_insert(line):
                if line.rstrip().endswith(";"):
                    yield line, True
                else:
                    in_insert = True
                    buffer = [line]
            else:
                yield line, False
        else:
            buffer.append(line)
            if line.rstrip().endswith(";"):
                yield "".join(buffer), True
                buffer = []
                in_insert = False

    if buffer:
        yield "".join(buffer), True


def _build_dataframe(stmt: InsertStatement) -> pd.DataFrame:
    """Build a DataFrame from INSERT values with only STRING cells populated."""
    columns = stmt.columns or [f"col_{i}" for i in range(len(stmt.rows[0]))]
    data = []
    for row, mask in zip(stmt.rows, stmt.type_masks):
        row_data = {}
        for col, val, vtype in zip(columns, row, mask):
            row_data[col] = val if vtype == ValueType.STRING else pd.NA
        data.append(row_data)
    return pd.DataFrame(data, columns=columns)


def _merge_back(
    stmt: InsertStatement, df: pd.DataFrame
) -> list[list]:
    """Merge anonymized DataFrame values back into the original row structure."""
    columns = stmt.columns or [f"col_{i}" for i in range(len(stmt.rows[0]))]
    new_rows = []
    for i, (row, mask) in enumerate(zip(stmt.rows, stmt.type_masks)):
        new_row = []
        for j, (val, vtype) in enumerate(zip(row, mask)):
            if vtype == ValueType.STRING:
                col = columns[j]
                new_val = df.at[i, col]
                new_row.append(str(new_val) if pd.notna(new_val) else val)
            else:
                new_row.append(val)
        new_rows.append(new_row)
    return new_rows


def _anonymize_insert(
    stmt: InsertStatement,
    scanner: PiiScanner,
    replacer,
    mode: AnonymizationMode = AnonymizationMode.PSEUDO,
) -> str:
    """Scan and replace PII in a single INSERT statement."""
    df = _build_dataframe(stmt)
    scan_results = scanner.scan_chunk(df)
    anonymized_df = replacer.replace_chunk(df, scan_results)

    if mode == AnonymizationMode.DROP:
        dropped_cols = set(df.columns) - set(anonymized_df.columns)
        if dropped_cols:
            columns = stmt.columns or [
                f"col_{i}" for i in range(len(stmt.rows[0]))
            ]
            keep_indices = [
                i for i, c in enumerate(columns) if c not in dropped_cols
            ]
            new_columns = [columns[i] for i in keep_indices]
            new_rows = [
                [row[i] for i in keep_indices] for row in stmt.rows
            ]
            new_masks = [
                [mask[i] for i in keep_indices] for mask in stmt.type_masks
            ]
            col_list = ", ".join(f"`{c}`" for c in new_columns)
            new_prefix = f"INSERT INTO `{stmt.table}` ({col_list})"
            reduced_stmt = InsertStatement(
                prefix=new_prefix,
                table=stmt.table,
                columns=new_columns,
                rows=new_rows,
                type_masks=new_masks,
            )
            return reconstruct_insert(reduced_stmt, new_rows)

    new_rows = _merge_back(stmt, anonymized_df)
    return reconstruct_insert(stmt, new_rows)
