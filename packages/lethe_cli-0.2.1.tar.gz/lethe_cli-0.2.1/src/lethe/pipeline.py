"""Orchestrator: reader -> scanner -> replacer -> writer with progress."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from lethe.config import AnonymizationMode, LetheConfig
from lethe.mapping.session_index import SessionIndex
from lethe.parsers import TextFormat, detect_format, make_reader, make_writer
from lethe.replacer.engine import Replacer
from lethe.replacer.freeform import FreeformReplacer
from lethe.replacer.freeform_modes import (
    FreeformDropReplacer,
    FreeformGeneralizeReplacer,
    FreeformRedactReplacer,
)
from lethe.replacer.strategies import DropReplacer, GeneralizeReplacer, RedactReplacer
from lethe.scanner.engine import PiiScanner

console = Console()


def default_output_path(input_path: Path) -> Path:
    return input_path.with_stem(input_path.stem + "_anonymized")


def _make_replacers(config, session_index, analyzer):
    """Return (structured_replacer, freeform_replacer) based on mode."""
    mode = config.mode

    if mode == AnonymizationMode.PSEUDO:
        return (
            Replacer(session_index),
            FreeformReplacer(analyzer, session_index, threshold=config.threshold),
        )
    if mode == AnonymizationMode.REDACT:
        return (
            RedactReplacer(),
            FreeformRedactReplacer(analyzer, threshold=config.threshold),
        )
    if mode == AnonymizationMode.GENERALIZE:
        return (
            GeneralizeReplacer(),
            FreeformGeneralizeReplacer(analyzer, threshold=config.threshold),
        )
    if mode == AnonymizationMode.DROP:
        return (
            DropReplacer(),
            FreeformDropReplacer(analyzer, threshold=config.threshold),
        )

    raise ValueError(f"Unknown mode: {mode}")


def run_pipeline(
    input_path: Path,
    output_path: Path | None,
    config: LetheConfig,
) -> Path:
    if output_path is None:
        output_path = default_output_path(input_path)

    console.print(f"[bold]Lethe[/bold] anonymizing [cyan]{input_path.name}[/cyan]")
    console.print(f"  Model: [yellow]{config.spacy_model}[/yellow]")
    console.print(f"  Mode: [yellow]{config.mode.value}[/yellow]")
    console.print(f"  Output: [cyan]{output_path}[/cyan]")

    fmt = detect_format(input_path)
    reader = make_reader(input_path, fmt, chunk_size=config.chunk_size)
    writer = make_writer(output_path, fmt)

    console.print(f"  Format: [yellow]{fmt.value}[/yellow]")
    console.print("  Loading NLP engine...", style="dim")
    scanner = PiiScanner(config)
    session_index = SessionIndex(locale=config.locale, seed=config.seed)

    structured_replacer, freeform_replacer = _make_replacers(
        config, session_index, scanner._analyzer
    )
    is_freeform = fmt == TextFormat.FREEFORM

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    )

    with progress:
        task = progress.add_task("Processing chunks", total=None)
        chunk_count = 0

        for chunk in reader.read_chunks():
            if is_freeform:
                anonymized = freeform_replacer.replace_chunk(chunk)
            else:
                scan_results = scanner.scan_chunk(chunk)
                anonymized = structured_replacer.replace_chunk(chunk, scan_results)
            writer.write_chunk(anonymized)
            chunk_count += 1
            progress.update(task, completed=chunk_count)

    writer.close()

    if config.mode == AnonymizationMode.PSEUDO:
        summary = f"{session_index.mapping_count} unique PII values replaced"
    else:
        summary = f"mode={config.mode.value}"

    console.print(
        f"\n  [green]Done.[/green] {chunk_count} chunk(s) processed, {summary}."
    )
    return output_path
