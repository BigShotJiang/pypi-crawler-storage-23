"""Lethe CLI: data anonymization for structured files."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from lethe.config import DEFAULT_CHUNK_SIZE, DEFAULT_LOCALE, DEFAULT_THRESHOLD, AnonymizationMode, LetheConfig
from lethe.multiply_pipeline import run_multiply
from lethe.pipeline import run_pipeline
from lethe.sql_pipeline import run_sql_pipeline

app = typer.Typer(
    name="lethe",
    help="Anonymize PII in structured data files.",
    no_args_is_help=True,
    invoke_without_command=True,
)


@app.callback()
def main() -> None:
    """Lethe: data anonymization for structured files."""


@app.command()
def anonymize(
    input_file: Annotated[
        Path,
        typer.Argument(help="Input data file to anonymize (CSV, TSV, TXT, or SQL dump).", exists=True, readable=True),
    ],
    output: Annotated[
        Optional[Path],
        typer.Option("-o", "--output", help="Output file path. Defaults to <input>_anonymized.<ext>."),
    ] = None,
    model: Annotated[
        str,
        typer.Option("--model", "-m", help="spaCy model: 'trf' (transformer, default) or 'sm' (small, fast)."),
    ] = "trf",
    threshold: Annotated[
        float,
        typer.Option("--threshold", "-t", help="Minimum confidence score to treat a cell as PII."),
    ] = DEFAULT_THRESHOLD,
    chunk_size: Annotated[
        int,
        typer.Option("--chunk-size", help="Rows per chunk for streaming."),
    ] = DEFAULT_CHUNK_SIZE,
    locale: Annotated[
        str,
        typer.Option("--locale", help="Faker locale for generated replacement values."),
    ] = DEFAULT_LOCALE,
    seed: Annotated[
        Optional[int],
        typer.Option("--seed", help="Random seed for reproducible fake data."),
    ] = None,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Anonymization mode: pseudo (default), redact, generalize, or drop."),
    ] = "pseudo",
    clean: Annotated[
        bool,
        typer.Option("--clean", help="Delete the original input file after successful anonymization."),
    ] = False,
    confirm_clean: Annotated[
        bool,
        typer.Option("--confirm-clean", help="Required confirmation for --clean. Destructive actions must be explicitly confirmed."),
    ] = False,
) -> None:
    """Anonymize PII in a data file (CSV, TSV, TXT, or SQL dump)."""
    if model not in ("trf", "sm"):
        typer.echo(f"Error: model must be 'trf' or 'sm', got '{model}'", err=True)
        raise typer.Exit(1)

    valid_modes = [m.value for m in AnonymizationMode]
    if mode not in valid_modes:
        typer.echo(f"Error: mode must be one of {valid_modes}, got '{mode}'", err=True)
        raise typer.Exit(1)

    if clean and not confirm_clean:
        typer.echo("Error: --clean requires --confirm-clean to confirm deletion of the input file.", err=True)
        raise typer.Exit(1)

    config = LetheConfig(
        model=model,
        threshold=threshold,
        chunk_size=chunk_size,
        locale=locale,
        seed=seed,
        mode=AnonymizationMode(mode),
    )

    if input_file.suffix.lower() == ".sql":
        run_sql_pipeline(input_file, output, config)
    else:
        run_pipeline(input_file, output, config)

    if clean:
        input_file.unlink()
        typer.echo(f"Deleted original file: {input_file}")


@app.command()
def multiply(
    input_file: Annotated[
        Path,
        typer.Argument(help="Input data file to multiply (CSV or TSV).", exists=True, readable=True),
    ],
    factor: Annotated[
        int,
        typer.Option("--factor", "-f", help="Multiplication factor (output rows = input rows * factor)."),
    ] = 3,
    output: Annotated[
        Optional[Path],
        typer.Option("-o", "--output", help="Output file path. Defaults to <input>_multiplied.<ext>."),
    ] = None,
    locale: Annotated[
        str,
        typer.Option("--locale", help="Faker locale for generated replacement values."),
    ] = DEFAULT_LOCALE,
    seed: Annotated[
        Optional[int],
        typer.Option("--seed", help="Random seed for reproducible fake data."),
    ] = None,
    sanitize: Annotated[
        bool,
        typer.Option("--sanitize", help="Validate and fix emails and URLs to be RFC-compliant ASCII."),
    ] = False,
    clean: Annotated[
        bool,
        typer.Option("--clean", help="Delete the original input file after successful multiplication."),
    ] = False,
    confirm_clean: Annotated[
        bool,
        typer.Option("--confirm-clean", help="Required confirmation for --clean. Destructive actions must be explicitly confirmed."),
    ] = False,
) -> None:
    """Multiply a dataset with synthetic rows (CSV or TSV)."""
    if factor < 1:
        typer.echo("Error: factor must be >= 1", err=True)
        raise typer.Exit(1)

    if clean and not confirm_clean:
        typer.echo("Error: --clean requires --confirm-clean to confirm deletion of the input file.", err=True)
        raise typer.Exit(1)

    run_multiply(input_file, output, factor, locale=locale, seed=seed, sanitize=sanitize)

    if clean:
        input_file.unlink()
        typer.echo(f"Deleted original file: {input_file}")
