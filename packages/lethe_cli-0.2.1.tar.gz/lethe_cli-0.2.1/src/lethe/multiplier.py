"""Multiply datasets: produce N * factor rows with synthetic data."""

from __future__ import annotations

import random

import pandas as pd

from lethe.mapping.session_index import SessionIndex
from lethe.scanner.column_heuristics import infer_pii_type


class Multiplier:
    """Takes an input DataFrame and generates a multiplied version.

    Columns are classified using heuristics:
    - PII columns: fresh Faker values for every row
    - ID columns: sequential integers continuing from max existing value
    - Sample columns (non-PII / unknown): sampled from existing values
    """

    def __init__(
        self,
        df: pd.DataFrame,
        locale: str = "en_US",
        seed: int | None = None,
    ) -> None:
        self._df = df
        self._session = SessionIndex(locale=locale, seed=seed)
        if seed is not None:
            random.seed(seed)
        self._pii_columns: dict[str, str] = {}
        self._id_columns: list[str] = []
        self._sample_columns: list[str] = []
        self.classify_columns()

    def classify_columns(self) -> None:
        for col in self._df.columns:
            hint = infer_pii_type(col)
            if hint is None:
                self._sample_columns.append(col)
            elif hint == "SKIP":
                if self._is_id_column(col):
                    self._id_columns.append(col)
                else:
                    self._sample_columns.append(col)
            else:
                self._pii_columns[col] = hint

    def _is_id_column(self, col: str) -> bool:
        """Check if a SKIP column is specifically an ID/primary-key column."""
        series = self._df[col]
        if not pd.api.types.is_numeric_dtype(series):
            return False
        clean = series.dropna()
        if clean.empty:
            return False
        as_int = clean.astype(int)
        return as_int.is_unique and as_int.is_monotonic_increasing

    def generate(self, factor: int) -> pd.DataFrame:
        """Return a DataFrame with original_rows * factor total rows.

        Rows 0..N-1 are the originals with PII replaced (anonymized).
        Rows N..N*factor-1 are fully synthetic.
        """
        n_original = len(self._df)
        n_synthetic = n_original * (factor - 1)
        rows: dict[str, list] = {col: [] for col in self._df.columns}

        # Phase 1: anonymize original rows
        for _, row in self._df.iterrows():
            for col in self._df.columns:
                val = row[col]
                if col in self._pii_columns:
                    rows[col].append(self._session._generate(self._pii_columns[col]))
                elif col in self._id_columns:
                    rows[col].append(val)
                else:
                    rows[col].append(val)

        # Phase 2: generate synthetic rows
        id_counters: dict[str, int] = {}
        for col in self._id_columns:
            id_counters[col] = int(self._df[col].max()) + 1

        col_values: dict[str, list] = {}
        for col in self._sample_columns:
            col_values[col] = self._df[col].dropna().tolist()

        for _ in range(n_synthetic):
            for col in self._df.columns:
                if col in self._pii_columns:
                    rows[col].append(self._session._generate(self._pii_columns[col]))
                elif col in self._id_columns:
                    rows[col].append(id_counters[col])
                    id_counters[col] += 1
                else:
                    pool = col_values.get(col, [])
                    rows[col].append(random.choice(pool) if pool else None)

        return pd.DataFrame(rows)
