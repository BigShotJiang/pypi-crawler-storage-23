"""PII scanner wrapping Presidio AnalyzerEngine with column-first processing."""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd
from presidio_analyzer import AnalyzerEngine, RecognizerRegistry
from presidio_analyzer.nlp_engine import NlpEngineProvider

from lethe.config import LetheConfig
from lethe.scanner.column_heuristics import infer_pii_type
from lethe.scanner.confidence import boost_heuristic_matches
from lethe.scanner.pattern_recognizers import CUSTOM_RECOGNIZERS


@dataclass
class CellResult:
    entity_type: str
    score: float


@dataclass
class ColumnScanResult:
    column: str
    skipped: bool = False
    cell_results: dict[int, CellResult] = field(default_factory=dict)


class PiiScanner:
    def __init__(self, config: LetheConfig) -> None:
        self.config = config
        self._analyzer = self._build_analyzer()

    def _build_analyzer(self) -> AnalyzerEngine:
        configuration = {
            "nlp_engine_name": "spacy",
            "models": [
                {
                    "lang_code": "en",
                    "model_name": self.config.spacy_model,
                }
            ],
        }
        provider = NlpEngineProvider(nlp_configuration=configuration)
        nlp_engine = provider.create_engine()

        registry = RecognizerRegistry()
        registry.load_predefined_recognizers(nlp_engine=nlp_engine)
        for recognizer in CUSTOM_RECOGNIZERS:
            registry.add_recognizer(recognizer)

        return AnalyzerEngine(
            nlp_engine=nlp_engine,
            registry=registry,
            supported_languages=["en"],
        )

    def scan_column(self, column: pd.Series) -> ColumnScanResult:
        """Scan a single column and return per-cell PII results."""
        col_name = str(column.name)
        result = ColumnScanResult(column=col_name)

        heuristic = infer_pii_type(col_name)
        if heuristic == "SKIP":
            result.skipped = True
            return result

        for idx, value in column.items():
            cell_text = str(value).strip() if pd.notna(value) else ""
            if not cell_text:
                continue

            analyzer_results = self._analyzer.analyze(
                text=cell_text,
                language="en",
                entities=None,
            )

            boosted = boost_heuristic_matches(analyzer_results, heuristic, cell_text)

            best = self._pick_best(boosted)
            if best and best.score >= self.config.threshold:
                result.cell_results[idx] = CellResult(
                    entity_type=best.entity_type,
                    score=best.score,
                )

        return result

    def scan_chunk(self, chunk: pd.DataFrame) -> dict[str, ColumnScanResult]:
        """Scan all columns in a DataFrame chunk."""
        results = {}
        for col in chunk.columns:
            results[col] = self.scan_column(chunk[col])
        return results

    @staticmethod
    def _pick_best(results: list) -> CellResult | None:
        if not results:
            return None
        best = max(results, key=lambda r: r.score)
        return CellResult(entity_type=best.entity_type, score=best.score)
