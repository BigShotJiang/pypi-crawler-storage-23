"""Confidence boosting and result synthesis for PII detection."""

from __future__ import annotations

from presidio_analyzer import RecognizerResult

HEURISTIC_BOOST = 0.25
HEURISTIC_SYNTHESIZE_SCORE = 0.4


def boost_heuristic_matches(
    results: list[RecognizerResult],
    heuristic_type: str | None,
    cell_text: str,
) -> list[RecognizerResult]:
    """Boost scores of results matching the heuristic hint, or synthesize a result."""
    if not heuristic_type or heuristic_type == "SKIP":
        return results

    boosted = []
    matched_heuristic = False
    for r in results:
        if r.entity_type == heuristic_type:
            boosted.append(
                RecognizerResult(
                    entity_type=r.entity_type,
                    start=r.start,
                    end=r.end,
                    score=min(1.0, r.score + HEURISTIC_BOOST),
                )
            )
            matched_heuristic = True
        else:
            boosted.append(r)

    if not matched_heuristic and cell_text.strip():
        boosted.append(
            RecognizerResult(
                entity_type=heuristic_type,
                start=0,
                end=len(cell_text),
                score=HEURISTIC_SYNTHESIZE_SCORE,
            )
        )

    return boosted
