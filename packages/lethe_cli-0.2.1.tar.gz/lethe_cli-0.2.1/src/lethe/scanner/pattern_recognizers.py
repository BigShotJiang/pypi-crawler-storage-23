"""Custom Presidio pattern recognizers for entity types not well-covered by defaults."""

from __future__ import annotations

from presidio_analyzer import Pattern, PatternRecognizer

iban_recognizer = PatternRecognizer(
    supported_entity="IBAN_CODE",
    name="iban_recognizer",
    patterns=[
        Pattern(
            name="IBAN",
            regex=r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}([A-Z0-9]?){0,16}\b",
            score=0.7,
        ),
    ],
    context=["iban", "account", "bank"],
)

uk_nino_recognizer = PatternRecognizer(
    supported_entity="UK_NINO",
    name="uk_nino_recognizer",
    patterns=[
        Pattern(
            name="UK_NINO",
            regex=r"\b(?!BG|GB|NK|KN|TN|NT|ZZ)[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b",
            score=0.7,
        ),
    ],
    context=["nino", "national insurance", "ni number"],
)

dutch_bsn_recognizer = PatternRecognizer(
    supported_entity="NL_BSN",
    name="dutch_bsn_recognizer",
    patterns=[
        Pattern(
            name="NL_BSN",
            regex=r"\b\d{9}\b",
            score=0.3,
        ),
    ],
    context=["bsn", "burgerservicenummer", "sofi"],
)

CUSTOM_RECOGNIZERS = [
    iban_recognizer,
    uk_nino_recognizer,
    dutch_bsn_recognizer,
]
