"""Column-name heuristics to classify columns before NER scanning."""

from __future__ import annotations

import re

SKIP_PATTERNS: dict[str, re.Pattern[str]] = {
    "id": re.compile(r"^(id|_id|pk|key|uuid|guid|row_?num)$", re.I),
    "timestamp": re.compile(
        r"(created|updated|modified|deleted|timestamp|_at|_on|_date|_time)$", re.I
    ),
    "boolean": re.compile(r"^(is_|has_|was_|can_|should_|active|enabled|flag)", re.I),
    "numeric": re.compile(
        r"^(count|total|amount|quantity|price|cost|rate|score|age|size|weight|height|width|length|num_|number_of)$",
        re.I,
    ),
    "status": re.compile(r"^(status|state|type|category|tier|level|role|kind)$", re.I),
    "currency": re.compile(r"^(currency|currency_code)$", re.I),
    "country_code": re.compile(r"^(country_code|lang|language|locale)$", re.I),
}

PII_HINT_PATTERNS: dict[str, re.Pattern[str]] = {
    "PERSON": re.compile(
        r"(^name$|first_?name|last_?name|full_?name|middle_?name|surname|contact_?name|customer_?name|employee_?name|user_?name)",
        re.I,
    ),
    "EMAIL_ADDRESS": re.compile(r"(e?mail|email_?addr)", re.I),
    "PHONE_NUMBER": re.compile(r"(phone|mobile|cell|tel|fax|contact_?number)", re.I),
    "LOCATION": re.compile(
        r"(^address$|street|city|state|province|zip|postal|region|country$|^location$)",
        re.I,
    ),
    "DATE_TIME": re.compile(r"(birth|dob|date_of_birth)", re.I),
    "US_SSN": re.compile(r"(ssn|social_?security)", re.I),
    "CREDIT_CARD": re.compile(r"(credit_?card|card_?num|cc_?num|pan)", re.I),
    "US_DRIVER_LICENSE": re.compile(r"(driver.?licen[sc]e|dl_?num)", re.I),
    "IBAN_CODE": re.compile(r"(iban)", re.I),
    "IP_ADDRESS": re.compile(r"(ip_?addr|ip$|remote_?ip|client_?ip)", re.I),
    "US_PASSPORT": re.compile(r"(passport)", re.I),
}


def infer_pii_type(column_name: str) -> str | None:
    """Return a PII entity type hint, 'SKIP', or None (unknown)."""
    col = column_name.strip()
    for _category, pattern in SKIP_PATTERNS.items():
        if pattern.search(col):
            return "SKIP"
    for entity_type, pattern in PII_HINT_PATTERNS.items():
        if pattern.search(col):
            return entity_type
    return None
