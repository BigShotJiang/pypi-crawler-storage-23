# code

GitHub: [cmake-example](https://github.com/cubao/pybind11-naive-svg)
