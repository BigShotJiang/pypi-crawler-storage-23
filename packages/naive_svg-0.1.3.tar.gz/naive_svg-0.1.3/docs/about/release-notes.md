# Release Notes

---

## Upgrading

To upgrade `naive-svg` to the latest version, use pip:

```bash
pip install -U naive-svg
```

## Version 0.0.1 (2023-09-02)

*   TODO

---

You can also checkout releases on:

-   GitHub: <https://github.com/cubao/pybind11-naive-svg/releases>
-   PyPi: <https://pypi.org/project/naive-svg>
