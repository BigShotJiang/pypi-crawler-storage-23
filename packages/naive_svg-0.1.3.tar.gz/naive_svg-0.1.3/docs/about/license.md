# License

The legal stuff.

---

## Included projects

*   [pybind/pybind11](https://github.com/pybind/pybind11/blob/master/LICENSE) (BSD)

## License (BSD)

See <https://github.com/cubao/pybind11-naive-svg/blob/master/LICENSE>.
