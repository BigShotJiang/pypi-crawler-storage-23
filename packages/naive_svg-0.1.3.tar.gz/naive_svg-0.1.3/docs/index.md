# naive-svg

TODO

{%
   include-markdown "../README.md"
   start="<!--intro-start-->"
   end="<!--intro-end-->"
%}

<div class="text-center">
<a href="https://github.com/cubao/pybind11-naives-svg" class="btn btn-primary" role="button">Code on GitHub</a>
<a href="https://pypi.org/project/naive-svg" class="btn btn-primary" role="button">Package on Pypi</a>
</div>

## Related

See more projects at [cubao](https://cubao.readthedocs.io).
