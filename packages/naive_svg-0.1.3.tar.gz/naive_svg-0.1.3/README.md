# naive-svg

Upgrated version of [svg.hpp](https://github.com/cubao/naive-svg/blob/master/svg.hpp).

Online document: **[readthedocs](http://pybind11-naive-svg.readthedocs.io/)**

<!--intro-start-->

## Usage

Install:

```bash
python3 -m pip install naive-svg # install from pypi
```
