#pragma once
#define CUBAO_INLINE
