..
   SPDX-FileCopyrightText: 2026 Andrew Grimberg <tykeal@bardicgrove.org>
   SPDX-License-Identifier: Apache-2.0

Exceptions
==========

.. automodule:: pylocal_akuvox.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
