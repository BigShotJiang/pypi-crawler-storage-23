..
   SPDX-FileCopyrightText: 2026 Andrew Grimberg <tykeal@bardicgrove.org>
   SPDX-License-Identifier: Apache-2.0

API Reference
=============

.. toctree::
   :maxdepth: 2

   device
   models
   config
   auth
   exceptions
