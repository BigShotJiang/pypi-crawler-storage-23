"""Tests for gettext deprecation migration recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.gettext_deprecations import (
    ReplaceGettextDeprecations,
)


class TestReplaceGettextDeprecations:
    """Tests for the ReplaceGettextDeprecations recipe."""

    def test_replaces_lgettext(self):
        """Test that lgettext is replaced with gettext."""
        spec = RecipeSpec(recipe=ReplaceGettextDeprecations())
        spec.rewrite_run(
            python(
                """
                import gettext
                msg = gettext.lgettext("Hello")
                """,
                """
                import gettext
                msg = gettext.gettext("Hello")
                """,
            )
        )

    def test_replaces_lngettext(self):
        """Test that lngettext is replaced with ngettext."""
        spec = RecipeSpec(recipe=ReplaceGettextDeprecations())
        spec.rewrite_run(
            python(
                """
                import gettext
                msg = gettext.lngettext("item", "items", count)
                """,
                """
                import gettext
                msg = gettext.ngettext("item", "items", count)
                """,
            )
        )

    def test_replaces_ldgettext(self):
        """Test that ldgettext is replaced with dgettext."""
        spec = RecipeSpec(recipe=ReplaceGettextDeprecations())
        spec.rewrite_run(
            python(
                """
                import gettext
                msg = gettext.ldgettext("mydomain", "Hello")
                """,
                """
                import gettext
                msg = gettext.dgettext("mydomain", "Hello")
                """,
            )
        )

    def test_no_change_when_already_correct(self):
        """Test that already-correct functions are not changed."""
        spec = RecipeSpec(recipe=ReplaceGettextDeprecations())
        spec.rewrite_run(
            python(
                """
                import gettext
                msg = gettext.gettext("Hello")
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that non-gettext module calls are not changed."""
        spec = RecipeSpec(recipe=ReplaceGettextDeprecations())
        spec.rewrite_run(
            python(
                """
                class MyGettext:
                    def lgettext(self, msg):
                        return msg

                my_gt = MyGettext()
                msg = my_gt.lgettext("Hello")
                """
            )
        )
