"""Tests for unittest deprecation migration recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.unittest_deprecations import (
    ReplaceUnittestDeprecatedAliases,
)


class TestReplaceUnittestDeprecatedAliases:
    """Tests for the ReplaceUnittestDeprecatedAliases recipe."""

    def test_replaces_assertEquals(self):
        """Test that assertEquals is replaced with assertEqual."""
        spec = RecipeSpec(recipe=ReplaceUnittestDeprecatedAliases())
        spec.rewrite_run(
            python(
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertEquals(1, 1)
                """,
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertEqual(1, 1)
                """,
            )
        )

    def test_replaces_assertNotEquals(self):
        """Test that assertNotEquals is replaced with assertNotEqual."""
        spec = RecipeSpec(recipe=ReplaceUnittestDeprecatedAliases())
        spec.rewrite_run(
            python(
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertNotEquals(1, 2)
                """,
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertNotEqual(1, 2)
                """,
            )
        )

    def test_replaces_assertRegexpMatches(self):
        """Test that assertRegexpMatches is replaced with assertRegex."""
        spec = RecipeSpec(recipe=ReplaceUnittestDeprecatedAliases())
        spec.rewrite_run(
            python(
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertRegexpMatches("hello", r"h.*o")
                """,
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertRegex("hello", r"h.*o")
                """,
            )
        )

    def test_replaces_failUnless(self):
        """Test that failUnless is replaced with assertTrue."""
        spec = RecipeSpec(recipe=ReplaceUnittestDeprecatedAliases())
        spec.rewrite_run(
            python(
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.failUnless(True)
                """,
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertTrue(True)
                """,
            )
        )

    def test_no_change_when_not_self(self):
        """Test that non-self method calls are not changed."""
        spec = RecipeSpec(recipe=ReplaceUnittestDeprecatedAliases())
        spec.rewrite_run(
            python(
                """
                def assertEquals(a, b):
                    return a == b

                result = assertEquals(1, 1)
                """
            )
        )

    def test_no_change_when_already_correct(self):
        """Test that already-correct methods are not changed."""
        spec = RecipeSpec(recipe=ReplaceUnittestDeprecatedAliases())
        spec.rewrite_run(
            python(
                """
                import unittest

                class MyTest(unittest.TestCase):
                    def test_example(self):
                        self.assertEqual(1, 1)
                """
            )
        )
