"""Tests for typing.Optional and typing.Union to PEP 604 migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.typing_union_to_pipe import (
    ReplaceTypingOptionalWithUnion,
    ReplaceTypingUnionWithPipe,
)


class TestReplaceTypingOptionalWithUnion:
    """Tests for the ReplaceTypingOptionalWithUnion recipe."""

    def test_replaces_optional_simple_type(self):
        """Test replacing Optional[str] with str | None."""
        spec = RecipeSpec(recipe=ReplaceTypingOptionalWithUnion())
        spec.rewrite_run(
            python(
                """
                from typing import Optional

                name: Optional[str] = None
                """,
                """
                from typing import Optional

                name: str | None = None
                """,
            )
        )

    def test_replaces_optional_complex_type(self):
        """Test replacing Optional with a complex type argument."""
        spec = RecipeSpec(recipe=ReplaceTypingOptionalWithUnion())
        spec.rewrite_run(
            python(
                """
                from typing import Optional, List

                items: Optional[List[int]] = None
                """,
                """
                from typing import Optional, List

                items: List[int] | None = None
                """,
            )
        )

    def test_replaces_typing_dot_optional(self):
        """Test replacing typing.Optional[X] (fully qualified)."""
        spec = RecipeSpec(recipe=ReplaceTypingOptionalWithUnion())
        spec.rewrite_run(
            python(
                """
                import typing

                name: typing.Optional[str] = None
                """,
                """
                import typing

                name: str | None = None
                """,
            )
        )

    def test_no_change_when_not_optional(self):
        """Test that non-Optional types are not modified."""
        spec = RecipeSpec(recipe=ReplaceTypingOptionalWithUnion())
        spec.rewrite_run(
            python(
                """
                from typing import List

                items: List[str] = []
                """
            )
        )

    def test_replaces_optional_in_return_type(self):
        """Test replacing Optional in function return types."""
        spec = RecipeSpec(recipe=ReplaceTypingOptionalWithUnion())
        spec.rewrite_run(
            python(
                """
                from typing import Optional

                def process() -> Optional[int]:
                    return None
                """,
                """
                from typing import Optional

                def process() -> int | None:
                    return None
                """,
            )
        )

    @pytest.mark.skip(reason="Parameter type transformation requires rewrite framework enhancement")
    def test_replaces_optional_in_function_parameters(self):
        """Test replacing Optional in function parameters."""
        spec = RecipeSpec(recipe=ReplaceTypingOptionalWithUnion())
        spec.rewrite_run(
            python(
                """
                from typing import Optional

                def process(name: Optional[str]) -> Optional[int]:
                    return None
                """,
                """
                from typing import Optional

                def process(name: str | None) -> int | None:
                    return None
                """,
            )
        )


class TestReplaceTypingUnionWithPipe:
    """Tests for the ReplaceTypingUnionWithPipe recipe."""

    def test_replaces_union_two_types(self):
        """Test replacing Union[int, str] with int | str."""
        spec = RecipeSpec(recipe=ReplaceTypingUnionWithPipe())
        spec.rewrite_run(
            python(
                """
                from typing import Union

                value: Union[int, str] = 0
                """,
                """
                from typing import Union

                value: int | str = 0
                """,
            )
        )

    def test_replaces_union_three_types(self):
        """Test replacing Union[int, str, float] with int | str | float."""
        spec = RecipeSpec(recipe=ReplaceTypingUnionWithPipe())
        spec.rewrite_run(
            python(
                """
                from typing import Union

                value: Union[int, str, float] = 0
                """,
                """
                from typing import Union

                value: int | str | float = 0
                """,
            )
        )

    def test_replaces_typing_dot_union(self):
        """Test replacing typing.Union[X, Y] (fully qualified)."""
        spec = RecipeSpec(recipe=ReplaceTypingUnionWithPipe())
        spec.rewrite_run(
            python(
                """
                import typing

                value: typing.Union[int, str] = 0
                """,
                """
                import typing

                value: int | str = 0
                """,
            )
        )

    def test_no_change_when_not_union(self):
        """Test that non-Union types are not modified."""
        spec = RecipeSpec(recipe=ReplaceTypingUnionWithPipe())
        spec.rewrite_run(
            python(
                """
                from typing import List

                items: List[str] = []
                """
            )
        )

    def test_replaces_union_in_return_type(self):
        """Test replacing Union in function return types."""
        spec = RecipeSpec(recipe=ReplaceTypingUnionWithPipe())
        spec.rewrite_run(
            python(
                """
                from typing import Union

                def process() -> Union[str, None]:
                    return None
                """,
                """
                from typing import Union

                def process() -> str | None:
                    return None
                """,
            )
        )

    @pytest.mark.skip(reason="Parameter type transformation requires rewrite framework enhancement")
    def test_replaces_union_in_function_parameters(self):
        """Test replacing Union in function parameters."""
        spec = RecipeSpec(recipe=ReplaceTypingUnionWithPipe())
        spec.rewrite_run(
            python(
                """
                from typing import Union

                def process(value: Union[int, str]) -> Union[str, None]:
                    return str(value)
                """,
                """
                from typing import Union

                def process(value: int | str) -> str | None:
                    return str(value)
                """,
            )
        )
