"""Tests for sys module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.sys_deprecations import FindSysCoroutineWrapper


class TestFindSysCoroutineWrapper:
    """Tests for FindSysCoroutineWrapper recipe."""

    def test_finds_set_coroutine_wrapper(self):
        spec = RecipeSpec(recipe=FindSysCoroutineWrapper())
        spec.rewrite_run(
            python(
                "sys.set_coroutine_wrapper(wrapper)",
                "/*~~(sys.set_coroutine_wrapper() was removed in Python 3.8.)~~>*/sys.set_coroutine_wrapper(wrapper)",
            )
        )

    def test_finds_get_coroutine_wrapper(self):
        spec = RecipeSpec(recipe=FindSysCoroutineWrapper())
        spec.rewrite_run(
            python(
                "old = sys.get_coroutine_wrapper()",
                "old = /*~~(sys.get_coroutine_wrapper() was removed in Python 3.8.)~~>*/sys.get_coroutine_wrapper()",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindSysCoroutineWrapper())
        spec.rewrite_run(
            python("other.set_coroutine_wrapper(wrapper)")
        )
