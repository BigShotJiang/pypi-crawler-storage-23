"""Tests for asyncio.coroutine to async/await migration recipe."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.asyncio_coroutine_to_async import (
    MigrateAsyncioCoroutine,
)


class TestMigrateAsyncioCoroutine:
    """Tests for the MigrateAsyncioCoroutine recipe."""

    def test_migrates_simple_coroutine(self):
        """Test migration of a simple @asyncio.coroutine function."""
        spec = RecipeSpec(recipe=MigrateAsyncioCoroutine())
        spec.rewrite_run(
            python(
                """
                import asyncio

                @asyncio.coroutine
                def fetch_data():
                    result = yield from get_data()
                    return result
                """,
                """
                import asyncio

                async def fetch_data():
                    result = await get_data()
                    return result
                """,
            )
        )

    def test_migrates_coroutine_with_multiple_yield_from(self):
        """Test migration with multiple yield from expressions."""
        spec = RecipeSpec(recipe=MigrateAsyncioCoroutine())
        spec.rewrite_run(
            python(
                """
                import asyncio

                @asyncio.coroutine
                def process():
                    a = yield from first()
                    b = yield from second()
                    return a + b
                """,
                """
                import asyncio

                async def process():
                    a = await first()
                    b = await second()
                    return a + b
                """,
            )
        )

    def test_no_change_when_already_async(self):
        """Test that async def functions are not modified."""
        spec = RecipeSpec(recipe=MigrateAsyncioCoroutine())
        spec.rewrite_run(
            python(
                """
                import asyncio

                async def fetch_data():
                    result = await get_data()
                    return result
                """
            )
        )

    def test_no_change_when_no_decorator(self):
        """Test that regular functions without decorator are not modified."""
        spec = RecipeSpec(recipe=MigrateAsyncioCoroutine())
        spec.rewrite_run(
            python(
                """
                def regular_function():
                    return 42
                """
            )
        )

    def test_preserves_other_decorators(self):
        """Test that other decorators are preserved."""
        spec = RecipeSpec(recipe=MigrateAsyncioCoroutine())
        spec.rewrite_run(
            python(
                """
                import asyncio

                @some_decorator
                @asyncio.coroutine
                @another_decorator
                def fetch_data():
                    result = yield from get_data()
                    return result
                """,
                """
                import asyncio

                @some_decorator
                @another_decorator
                async def fetch_data():
                    result = await get_data()
                    return result
                """,
            )
        )

    def test_migrates_coroutine_without_yield_from(self):
        """Test migration of coroutine that doesn't use yield from."""
        spec = RecipeSpec(recipe=MigrateAsyncioCoroutine())
        spec.rewrite_run(
            python(
                """
                import asyncio

                @asyncio.coroutine
                def simple():
                    return 42
                """,
                """
                import asyncio

                async def simple():
                    return 42
                """,
            )
        )
