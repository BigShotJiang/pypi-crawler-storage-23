"""
Recipe for finding deprecated shutil.rmtree(onerror=) parameter.

The `onerror` parameter of shutil.rmtree() was deprecated in Python 3.12
in favor of the `onexc` parameter.

See: https://docs.python.org/3/whatsnew/3.12.html#deprecated
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python312)
class FindShutilRmtreeOnerror(Recipe):
    """
    Find usages of deprecated `shutil.rmtree(onerror=...)` parameter.

    The `onerror` parameter was deprecated in Python 3.12 in favor of
    the `onexc` parameter. The `onexc` callback receives the exception
    object directly rather than the exc_info tuple.

    Example:
        Before:
            import shutil
            shutil.rmtree(path, onerror=handler)

        After:
            import shutil
            shutil.rmtree(path, onexc=handler)

    Note: This is a search recipe because the callback signature differs
    between `onerror` (func, path, exc_info) and `onexc` (func, path, exc).
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindShutilRmtreeOnerror"

    @property
    def display_name(self) -> str:
        return "Find deprecated `shutil.rmtree(onerror=...)` parameter"

    @property
    def description(self) -> str:
        return (
            "The `onerror` parameter of `shutil.rmtree()` was deprecated in Python 3.12 "
            "in favor of `onexc`. The `onexc` callback receives the exception object "
            "directly rather than an exc_info tuple."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12", "shutil"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "rmtree":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "shutil":
                    return method

                # Check if any argument uses `onerror=` keyword
                # We look at the string representation of arguments for keyword args
                # Since we can't easily inspect keyword args at the AST level
                # without type attribution, we mark all shutil.rmtree() calls
                # as needing review if they have 3+ arguments (path, ignore_errors, onerror)
                if len(method.arguments) >= 3:
                    return _mark_deprecated(
                        method,
                        "shutil.rmtree() `onerror` parameter was deprecated in Python 3.12. "
                        "Use `onexc` instead. Note: the callback signature differs."
                    )

                return method

        return Visitor()
