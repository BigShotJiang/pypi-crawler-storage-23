"""
Recipes for migrating deprecated ast module node types.

Python 3.8 deprecated several specific AST node types in favor of ast.Constant:

- ast.Num -> ast.Constant (for numeric literals)
- ast.Str -> ast.Constant (for string literals)
- ast.Bytes -> ast.Constant (for bytes literals)
- ast.NameConstant -> ast.Constant (for True, False, None)
- ast.Ellipsis -> ast.Constant (for ...)

These deprecated nodes were removed in Python 3.14.

See: https://docs.python.org/3/library/ast.html#ast.Constant
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, FieldAccess

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _is_ast_attribute(field_access: FieldAccess, attr_name: str) -> bool:
    """
    Check if this is an ast.attr_name access.

    Matches patterns like:
    - ast.Num
    - ast.Str
    """
    if not isinstance(field_access.name, Identifier):
        return False
    if field_access.name.simple_name != attr_name:
        return False

    # Check if the target is 'ast'
    target = field_access.target
    if isinstance(target, Identifier) and target.simple_name == "ast":
        return True

    return False


def _replace_ast_attribute(field_access: FieldAccess, new_name: str) -> FieldAccess:
    """
    Replace the attribute name in an ast.X field access.

    Changes ast.Num to ast.Constant, etc.
    """
    # Get the current name identifier
    old_name = field_access.name
    if not isinstance(old_name, Identifier):
        return field_access

    # Create a new identifier with the new name
    new_identifier = old_name.replace(_simple_name=new_name)

    # Replace the name in the field access via padding
    return field_access.padding.replace(
        name=field_access.padding.name.replace(element=new_identifier)
    )


@categorize(_Python38)
class ReplaceAstNum(Recipe):
    """
    Replace `ast.Num` with `ast.Constant`.

    The `ast.Num` node type was deprecated in Python 3.8 and removed in
    Python 3.14. Use `ast.Constant` instead for numeric literals.

    Example:
        Before:
            import ast
            if isinstance(node, ast.Num):
                value = node.n

        After:
            import ast
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float, complex)):
                value = node.value
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceAstNum"

    @property
    def display_name(self) -> str:
        return "Replace `ast.Num` with `ast.Constant`"

    @property
    def description(self) -> str:
        return (
            "The `ast.Num` node type was deprecated in Python 3.8 and removed in Python 3.14. "
            "Replace with `ast.Constant` and check `isinstance(node.value, (int, float, complex))`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if _is_ast_attribute(field_access, "Num"):
                    return _replace_ast_attribute(field_access, "Constant")

                return field_access

        return Visitor()


@categorize(_Python38)
class ReplaceAstStr(Recipe):
    """
    Replace `ast.Str` with `ast.Constant`.

    The `ast.Str` node type was deprecated in Python 3.8 and removed in
    Python 3.14. Use `ast.Constant` instead for string literals.

    Example:
        Before:
            import ast
            if isinstance(node, ast.Str):
                value = node.s

        After:
            import ast
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                value = node.value
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceAstStr"

    @property
    def display_name(self) -> str:
        return "Replace `ast.Str` with `ast.Constant`"

    @property
    def description(self) -> str:
        return (
            "The `ast.Str` node type was deprecated in Python 3.8 and removed in Python 3.14. "
            "Replace with `ast.Constant` and check `isinstance(node.value, str)`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if _is_ast_attribute(field_access, "Str"):
                    return _replace_ast_attribute(field_access, "Constant")

                return field_access

        return Visitor()


@categorize(_Python38)
class ReplaceAstBytes(Recipe):
    """
    Replace `ast.Bytes` with `ast.Constant`.

    The `ast.Bytes` node type was deprecated in Python 3.8 and removed in
    Python 3.14. Use `ast.Constant` instead for bytes literals.

    Example:
        Before:
            import ast
            if isinstance(node, ast.Bytes):
                value = node.s

        After:
            import ast
            if isinstance(node, ast.Constant) and isinstance(node.value, bytes):
                value = node.value
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceAstBytes"

    @property
    def display_name(self) -> str:
        return "Replace `ast.Bytes` with `ast.Constant`"

    @property
    def description(self) -> str:
        return (
            "The `ast.Bytes` node type was deprecated in Python 3.8 and removed in Python 3.14. "
            "Replace with `ast.Constant` and check `isinstance(node.value, bytes)`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if _is_ast_attribute(field_access, "Bytes"):
                    return _replace_ast_attribute(field_access, "Constant")

                return field_access

        return Visitor()


@categorize(_Python38)
class ReplaceAstNameConstant(Recipe):
    """
    Replace `ast.NameConstant` with `ast.Constant`.

    The `ast.NameConstant` node type was deprecated in Python 3.8 and removed in
    Python 3.14. Use `ast.Constant` instead for True, False, and None.

    Example:
        Before:
            import ast
            if isinstance(node, ast.NameConstant):
                value = node.value  # True, False, or None

        After:
            import ast
            if isinstance(node, ast.Constant) and node.value in (True, False, None):
                value = node.value
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceAstNameConstant"

    @property
    def display_name(self) -> str:
        return "Replace `ast.NameConstant` with `ast.Constant`"

    @property
    def description(self) -> str:
        return (
            "The `ast.NameConstant` node type was deprecated in Python 3.8 and removed in Python 3.14. "
            "Replace with `ast.Constant` and check `node.value in (True, False, None)`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if _is_ast_attribute(field_access, "NameConstant"):
                    return _replace_ast_attribute(field_access, "Constant")

                return field_access

        return Visitor()


@categorize(_Python38)
class ReplaceAstEllipsis(Recipe):
    """
    Replace `ast.Ellipsis` with `ast.Constant`.

    The `ast.Ellipsis` node type was deprecated in Python 3.8 and removed in
    Python 3.14. Use `ast.Constant` instead for the ellipsis literal (...).

    Example:
        Before:
            import ast
            if isinstance(node, ast.Ellipsis):
                pass

        After:
            import ast
            if isinstance(node, ast.Constant) and node.value is ...:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceAstEllipsis"

    @property
    def display_name(self) -> str:
        return "Replace `ast.Ellipsis` with `ast.Constant`"

    @property
    def description(self) -> str:
        return (
            "The `ast.Ellipsis` node type was deprecated in Python 3.8 and removed in Python 3.14. "
            "Replace with `ast.Constant` and check `node.value is ...`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if _is_ast_attribute(field_access, "Ellipsis"):
                    return _replace_ast_attribute(field_access, "Constant")

                return field_access

        return Visitor()
