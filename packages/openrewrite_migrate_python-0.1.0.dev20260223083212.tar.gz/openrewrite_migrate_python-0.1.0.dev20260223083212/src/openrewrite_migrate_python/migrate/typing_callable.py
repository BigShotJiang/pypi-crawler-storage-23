"""
Recipe for migrating typing.Callable to collections.abc.Callable.

PEP 585 (Python 3.9+) deprecated typing.Callable in favor of
collections.abc.Callable:

- typing.Callable[[int], str] -> collections.abc.Callable[[int], str]

See: https://peps.python.org/pep-0585/
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier

# Define category path
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python39)
class ReplaceTypingCallableWithCollectionsAbcCallable(Recipe):
    """
    Find and migrate `typing.Callable` to `collections.abc.Callable`.

    PEP 585 deprecated `typing.Callable` in Python 3.9. Use
    `collections.abc.Callable` instead for type annotations.

    Example:
        Before:
            from typing import Callable
            handler: Callable[[int], str] = lambda x: str(x)

        After:
            from collections.abc import Callable
            handler: Callable[[int], str] = lambda x: str(x)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingCallableWithCollectionsAbcCallable"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Callable` with `collections.abc.Callable`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Callable` in Python 3.9. "
            "Replace with `collections.abc.Callable` for type annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                if identifier.simple_name == "Callable":
                    # Check if this is from typing module via type attribution
                    if identifier.field_type:
                        fqn = str(getattr(identifier.field_type, '_fully_qualified_name', ''))
                        if 'typing' in fqn and 'collections' not in fqn:
                            return _mark_deprecated(
                                identifier,
                                "typing.Callable is deprecated",
                                "Replace with collections.abc.Callable (PEP 585)"
                            )

                return identifier

        return Visitor()
