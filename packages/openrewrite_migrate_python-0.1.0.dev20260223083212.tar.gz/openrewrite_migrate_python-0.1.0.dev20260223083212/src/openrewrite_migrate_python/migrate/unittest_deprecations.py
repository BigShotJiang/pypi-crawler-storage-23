"""
Recipes for migrating deprecated unittest method aliases.

Several unittest.TestCase method aliases were deprecated in Python 3.1-3.2
and removed in Python 3.11/3.12:

- assertEquals → assertEqual
- assertNotEquals → assertNotEqual
- assertAlmostEquals → assertAlmostEqual
- assertNotAlmostEquals → assertNotAlmostEqual
- assertRegexpMatches → assertRegex (deprecated 3.2, removed 3.12)
- assertNotRegexpMatches → assertNotRegex (deprecated 3.2, removed 3.12)
- assertRaisesRegexp → assertRaisesRegex (deprecated 3.2, removed 3.12)

See: https://docs.python.org/3/library/unittest.html
"""

from typing import Any, Optional, Dict

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]

# Mapping of deprecated method names to their replacements
UNITTEST_ALIASES: Dict[str, str] = {
    # Deprecated in 3.1, removed in 3.11
    "assertEquals": "assertEqual",
    "assertNotEquals": "assertNotEqual",
    "assertAlmostEquals": "assertAlmostEqual",
    "assertNotAlmostEquals": "assertNotAlmostEqual",
    # Deprecated in 3.2, removed in 3.12
    "assertRegexpMatches": "assertRegex",
    "assertNotRegexpMatches": "assertNotRegex",
    "assertRaisesRegexp": "assertRaisesRegex",
    # Very old aliases (deprecated since 3.1)
    "failUnlessEqual": "assertEqual",
    "failIfEqual": "assertNotEqual",
    "failUnless": "assertTrue",
    "failIf": "assertFalse",
    "failUnlessRaises": "assertRaises",
    "failUnlessAlmostEqual": "assertAlmostEqual",
    "failIfAlmostEqual": "assertNotAlmostEqual",
}


def _rename_method(method: MethodInvocation, new_name: str) -> MethodInvocation:
    """Rename a method invocation."""
    old_name = method.name
    if not isinstance(old_name, Identifier):
        return method

    new_identifier = old_name.replace(_simple_name=new_name)
    return method.replace(_name=new_identifier)


def _is_self_method(method: MethodInvocation) -> bool:
    """Check if this is a method call on self (typical for unittest)."""
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier) and select.simple_name == "self":
        return True
    return False


@categorize(_Python311)
class ReplaceUnittestDeprecatedAliases(Recipe):
    """
    Replace deprecated unittest.TestCase method aliases with their modern equivalents.

    Several unittest method aliases were deprecated and later removed:
    - assertEquals → assertEqual
    - assertNotEquals → assertNotEqual
    - assertRegexpMatches → assertRegex
    - And many more...

    This recipe automatically renames these method calls to their non-deprecated versions.

    Example:
        Before:
            class MyTest(unittest.TestCase):
                def test_example(self):
                    self.assertEquals(1, 1)
                    self.assertRegexpMatches("hello", r"h.*o")

        After:
            class MyTest(unittest.TestCase):
                def test_example(self):
                    self.assertEqual(1, 1)
                    self.assertRegex("hello", r"h.*o")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceUnittestDeprecatedAliases"

    @property
    def display_name(self) -> str:
        return "Replace deprecated unittest method aliases"

    @property
    def description(self) -> str:
        return (
            "Replace deprecated unittest.TestCase method aliases like `assertEquals` "
            "with their modern equivalents like `assertEqual`. These aliases were "
            "removed in Python 3.11/3.12."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method

                method_name = method.name.simple_name

                # Check if this is a deprecated unittest alias
                if method_name in UNITTEST_ALIASES:
                    # Only replace if called on self (typical unittest pattern)
                    if _is_self_method(method):
                        new_name = UNITTEST_ALIASES[method_name]
                        return _rename_method(method, new_name)

                return method

        return Visitor()
