"""
Recipe for migrating deprecated Thread.isAlive() method.

Thread.isAlive() was deprecated in Python 3.1 and removed in Python 3.9.
Use Thread.is_alive() instead.

See: https://docs.python.org/3/whatsnew/3.9.html#removed
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceThreadIsAlive(Recipe):
    """
    Replace `Thread.isAlive()` with `Thread.is_alive()`.

    `Thread.isAlive()` was deprecated in Python 3.1 and removed in Python 3.9.

    Example:
        Before:
            if thread.isAlive():
                pass

        After:
            if thread.is_alive():
                pass

    Note: This matches any .isAlive() call, as it's difficult to
    determine if the object is a threading.Thread at parse time.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadIsAlive"

    @property
    def display_name(self) -> str:
        return "Replace `Thread.isAlive()` with `Thread.is_alive()`"

    @property
    def description(self) -> str:
        return (
            "Replace `isAlive()` method calls with `is_alive()`. "
            "Deprecated in Python 3.1 and removed in 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "isAlive":
                    return method

                # Replace isAlive with is_alive
                new_name = method.name.replace(_simple_name="is_alive")
                return method.replace(_name=new_name)

        return Visitor()
