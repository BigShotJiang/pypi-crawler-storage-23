"""
Recipes for migrating deprecated xml.etree.ElementTree methods.

Several Element methods were deprecated in Python 3.9:
- Element.getchildren() -> list(element)
- Element.getiterator() -> element.iter()

See: https://docs.python.org/3/library/xml.etree.elementtree.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python39)
class FindElementGetchildren(Recipe):
    """
    Find usage of `Element.getchildren()`.

    The `getchildren()` method was deprecated in Python 3.9. Instead of
    `element.getchildren()`, use `list(element)` to get child elements.

    Example:
        Before:
            children = element.getchildren()

        After:
            children = list(element)

    Note: This recipe only detects usage. Manual migration is required
    because the replacement syntax (`list(element)`) is different.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindElementGetchildren"

    @property
    def display_name(self) -> str:
        return "Find deprecated `Element.getchildren()` usage"

    @property
    def description(self) -> str:
        return (
            "Find usage of `getchildren()` method on XML Element objects. "
            "Deprecated in Python 3.9. Use `list(element)` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "xml"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getchildren":
                    return method

                return _mark_deprecated(
                    method,
                    "Element.getchildren() is deprecated. Use list(element) instead."
                )

        return Visitor()


@categorize(_Python39)
class ReplaceElementGetiterator(Recipe):
    """
    Replace `Element.getiterator()` with `Element.iter()`.

    The `getiterator()` method was deprecated in Python 3.9 and will be
    removed in a future version. Use `iter()` instead.

    Example:
        Before:
            for child in element.getiterator():
                ...
            for tag in element.getiterator('tag'):
                ...

        After:
            for child in element.iter():
                ...
            for tag in element.iter('tag'):
                ...
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceElementGetiterator"

    @property
    def display_name(self) -> str:
        return "Replace `Element.getiterator()` with `Element.iter()`"

    @property
    def description(self) -> str:
        return (
            "Replace `getiterator()` with `iter()` on XML Element objects. "
            "The getiterator() method was deprecated in Python 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "xml"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getiterator":
                    return method

                # Replace getiterator with iter
                new_name = method.name.replace(_simple_name="iter")
                return method.replace(_name=new_name)

        return Visitor()
