"""
Recipes for migrating deprecated os module functions.

Several os module functions have been deprecated in favor of subprocess:
- os.popen() deprecated since 3.6, use subprocess.Popen() instead
- os.system() is generally discouraged, use subprocess.run() instead

See: https://docs.python.org/3/library/os.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, FieldAccess, MethodInvocation

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Migrate)
class FindOsPopen(Recipe):
    """
    Find usages of deprecated `os.popen()`.

    `os.popen()` has been deprecated since Python 3.6. The subprocess module
    provides more powerful and flexible process creation capabilities.

    Example:
        Before:
            import os
            output = os.popen('ls -l').read()

        After:
            import subprocess
            output = subprocess.run(['ls', '-l'], capture_output=True, text=True).stdout
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindOsPopen"

    @property
    def display_name(self) -> str:
        return "Find deprecated `os.popen()` usage"

    @property
    def description(self) -> str:
        return (
            "`os.popen()` has been deprecated since Python 3.6. "
            "Use `subprocess.run()` or `subprocess.Popen()` instead for better "
            "control over process creation and output handling."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "subprocess"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Check for os.popen() calls
                if method.name and hasattr(method.name, 'simple_name'):
                    if method.name.simple_name == "popen":
                        select = method.select
                        if isinstance(select, Identifier) and select.simple_name == "os":
                            return _mark_deprecated(
                                method,
                                "os.popen() is deprecated since Python 3.6. "
                                "Use subprocess.run() or subprocess.Popen() instead."
                            )

                return method

        return Visitor()


@categorize(_Migrate)
class FindOsSpawn(Recipe):
    """
    Find usages of deprecated `os.spawn*()` functions.

    The `os.spawn*()` family of functions (spawnl, spawnle, spawnlp, spawnlpe,
    spawnv, spawnve, spawnvp, spawnvpe) are deprecated. Use the subprocess
    module instead.

    Example:
        Before:
            import os
            os.spawnl(os.P_WAIT, '/bin/ls', 'ls', '-l')

        After:
            import subprocess
            subprocess.run(['/bin/ls', '-l'])
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindOsSpawn"

    @property
    def display_name(self) -> str:
        return "Find deprecated `os.spawn*()` usage"

    @property
    def description(self) -> str:
        return (
            "The `os.spawn*()` family of functions are deprecated. "
            "Use `subprocess.run()` or `subprocess.Popen()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "subprocess"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        spawn_functions = {
            "spawnl", "spawnle", "spawnlp", "spawnlpe",
            "spawnv", "spawnve", "spawnvp", "spawnvpe"
        }

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if method.name and hasattr(method.name, 'simple_name'):
                    if method.name.simple_name in spawn_functions:
                        select = method.select
                        if isinstance(select, Identifier) and select.simple_name == "os":
                            return _mark_deprecated(
                                method,
                                f"os.{method.name.simple_name}() is deprecated. "
                                "Use subprocess.run() or subprocess.Popen() instead."
                            )

                return method

        return Visitor()
