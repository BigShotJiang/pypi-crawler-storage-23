## Generating Protobuf

`python -m grpc_tools.protoc --proto_path=. --python_out=. --grpc_python_out=. nedo_vision_training/protos/*.proto`

## Running

```
source /mnt/linux-data/nedo-vision/venv-training-agent/bin/activate

python3 -m nedo_vision_training.cli run --token 1f61dcf4cfa2492c9ba093e4434c4bcf --server-host be.vision.sindika.co.id --rest-api-port 80
```
