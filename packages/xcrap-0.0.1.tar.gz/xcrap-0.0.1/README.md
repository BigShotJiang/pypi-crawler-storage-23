# Xcrap for Python

Xcrap é um framework originalmente feito para Node.js, mas, digamos que eu também sou um desenvolvedor Python e, estava um pouco entediado; por isso, resolvi fazer uma versão para Python.

Ainda está em fase experimental, e muito incompleto, só vou garantir o nome no PyPI, o resto, vou fazendo aos poucos. Talvez nos tornemos uma alternativa ao Scrapy, seria ambicioso demais da minha parte? Não sei, mas, vamos tentar, sou meio doido... (me contratem, Zyte :v)

Eu não sou iniciante em web scraping, mas não posso dizer que sou um especialista também, não enfrentei muitos casos; então, peço que, se você souber de algo que eu não sei e puder me ajudar, que me ajude!

O objetivo do Xcrap é ser modular, fácil de plugar com outros clientes Http (e usar até mesmo navegadores via Selenium ou seja qual lá biblioteca existir par isso), tratar JSON, HTML, Markdown (podendo lidar bem com um documento que tenha inclusive os 3 formatos sem problemas) de forma declarativa.

Quero fazer um transformador de dados, mas, até o momento, não consegui fazer essa façanha nem no Node.js, que eu já tenho um ecossitema maior do Xcrap.

Também sou um tanto quanto leigo em testes, então, se puder me ajudar com isso, eu agradeço!

Enfim, estamos aceitando contribuições, precismos documentar tudo isso, e muito mais! :D