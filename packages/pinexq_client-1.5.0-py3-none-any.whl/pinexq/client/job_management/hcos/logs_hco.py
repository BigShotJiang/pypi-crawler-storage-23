from typing import Self

import httpx

from ...core.hco.hco_base import Hco, Property
from ...core.hco.link_hco import LinkHco
from ...core.hco.unavailable import UnavailableLink
from ..known_relations import Relations
from ..model.sirenentities import LogsEntity


class LogsLink(LinkHco):
    def navigate(self) -> "LogsHco":
        return LogsHco.from_entity(self._navigate_internal(LogsEntity), self._client)


class LogsHco(Hco[LogsEntity]):
    current: int = Property()
    total: int = Property()
    limit: int = Property()
    logs: list[dict] = Property()

    self_link: LogsLink | UnavailableLink

    @classmethod
    def from_entity(cls, entity: LogsEntity, client: httpx.Client) -> Self:
        instance = cls(client, entity)

        Hco.check_classes(instance._entity.class_, ["log"])

        instance.self_link = LogsLink.from_entity_optional(
            instance._client, instance._entity, Relations.SELF
        )

        return instance
