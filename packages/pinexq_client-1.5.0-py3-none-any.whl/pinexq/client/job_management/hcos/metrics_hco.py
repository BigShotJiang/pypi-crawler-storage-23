from typing import Self

import httpx

from ...core.hco.hco_base import Hco, Property
from ...core.hco.link_hco import LinkHco
from ..known_relations import Relations
from ..model.sirenentities import MetricsEntity


class MetricsLink(LinkHco):
    def navigate(self) -> "MetricsHco":
        return MetricsHco.from_entity(self._navigate_internal(MetricsEntity), self._client)


class MetricsHco(Hco[MetricsEntity]):
    worker: str = Property()
    metrics: dict = Property()

    self_link: MetricsLink

    @classmethod
    def from_entity(cls, entity: MetricsEntity, client: httpx.Client) -> Self:
        instance = cls(client, entity)

        Hco.check_classes(instance._entity.class_, ["metrics"])

        instance.self_link = MetricsLink.from_entity(
            instance._client, instance._entity, Relations.SELF
        )

        return instance
