from io import IOBase
from typing import Any, AsyncIterable, Iterable, Iterator, Self

import httpx
from httpx import URL

from pydantic import AnyUrl, AwareDatetime

from ...core import Link, MediaTypes
from ...core.hco.upload_action_hco import UploadParameters
from ..enterjma import enter_jma
from ..hcos import (
    EntryPointHco,
    WorkDataHco,
    WorkDataLink,
    WorkDataQueryResultHco,
    WorkDataRootHco,
)
from ..known_relations import Relations
from ..model import (
    CopyWorkDataFromUserToOrgActionParameters,
    Pagination,
    SetTagsWorkDataParameters,
    SortTypes,
    WorkDataFilterParameter,
    WorkDataKind,
    WorkDataQueryParameters,
    WorkDataSortProperties,
    WorkDataSortPropertiesSortParameter,
)


class WorkData:
    """Convenience wrapper for handling WorkDataHcos in the JobManagement-Api.
    """

    _client: httpx.Client
    _entrypoint: EntryPointHco
    _work_data_root: WorkDataRootHco
    work_data_hco: WorkDataHco | None = None # Internal hco of the wrapper. This is updated by this class. You should not take a reference to this object.

    def __init__(self, client: httpx.Client):
        """

        Args:
            client: An httpx.Client instance initialized with the api-host-url as `base_url`
        """
        self._client = client
        self._entrypoint = enter_jma(client)
        self._work_data_root = self._entrypoint.work_data_root_link.navigate()

    def create(
            self,
            *,
            filename: str,
            mediatype: str = MediaTypes.OCTET_STREAM,
            json: Any | None = None,
            file: IOBase | None = None,
            binary: str | bytes | Iterable[bytes] | AsyncIterable[bytes] | None = None
    ) -> Self:
        work_data_link = self._work_data_root.upload_action.execute(
            UploadParameters(
                filename=filename, binary=binary, json=json, file=file, mediatype=mediatype
            )
        )
        self._get_by_link(work_data_link)
        return self

    def _get_by_link(self, work_data_link: WorkDataLink):
        self.work_data_hco = work_data_link.navigate()

    @classmethod
    def from_hco(cls, work_data_hco: WorkDataHco) -> Self:
        """Initializes a `WorkData` object from an existing WorkDataHco object.

        Args:
            client: An httpx.Client instance initialized with the api-host-url as `base_url`
            work_data_hco: The WorkDataHco to initialize this WorkData from.

        Returns:
            The newly created work data as `WorkData` object.
        """

        work_data_instance = cls(work_data_hco._client)
        work_data_instance.work_data_hco = work_data_hco
        return work_data_instance

    @classmethod
    def from_url(cls, client: httpx.Client, work_data_url: URL) -> Self:
        """Initializes a `WorkData` object from an existing work data given by its link as URL.

        Args:
            client: An httpx.Client instance initialized with the api-host-url as `base_url`
            work_data_url: The URL of the work data

        Returns:
            The newly created work data as `WorkData` object
        """
        link = Link.from_url(
            work_data_url,
            [str(Relations.CREATED_RESSOURCE)],
            "Uploaded work data",
            MediaTypes.SIREN,
        )
        processing_step_instance = cls(client)
        processing_step_instance._get_by_link(WorkDataLink.from_link(client, link))
        return processing_step_instance

    def refresh(self) -> Self:
        """Updates the work data from the server

        Returns:
            This `WorkData` object, but with updated properties.
        """
        self._raise_if_no_hco()
        self.work_data_hco = self.work_data_hco.self_link.navigate()
        return self

    def set_tags(self, tags: list[str]):
        """Set tags to the processing step.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.edit_tags_action.execute(SetTagsWorkDataParameters(
            tags=tags
        ))
        self.refresh()
        return self

    def allow_deletion(self) -> Self:
        """Allow deletion.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.allow_deletion_action.execute()
        self.refresh()
        return self

    def disallow_deletion(self) -> Self:
        """Disallow deletion.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.disallow_deletion_action.execute()
        self.refresh()
        return self

    def hide(self) -> Self:
        """Hide WorkData.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.hide_action.execute()
        self.refresh()
        return self

    def unhide(self) -> Self:
        """Unhide WorkData.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.unhide_action.execute()
        self.refresh()
        return self

    def mark_as_secret(self) -> Self:
        """Mark WorkData as secret.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.mark_as_secret_action.execute()
        self.refresh()
        return self

    def delete(self) -> Self:
        """Delete WorkData.

        Returns:
            This `WorkData` object"""
        self._raise_if_no_hco()
        self.work_data_hco.delete_action.execute()
        self.work_data_hco = None
        return self

    def download(self) -> bytes:
        """Download WorkData.

        Returns:
            Downloaded WorkData in bytes
        """
        self._raise_if_no_hco()
        return self.work_data_hco.download_link.download()

    def copy_to_user(self) -> WorkDataLink:
        """Copy WorkData from organization to user.

        Returns:
            The URL of the copied WorkData
        """
        self._raise_if_no_hco()
        return self.work_data_hco.copy_org_to_user_action.execute()

    def copy_to_org(self, org_id: str) -> WorkDataLink:
        """Copy WorkData from user to organization.

        Args:
            org_id: The ID of the organization to copy the WorkData to.

        Returns:
            The URL of the copied WorkData
        """
        self._raise_if_no_hco()
        return self.work_data_hco.copy_user_to_org_action.execute(
            CopyWorkDataFromUserToOrgActionParameters(org_id=org_id)
        )

    def self_link(self) -> WorkDataLink:
        self._raise_if_no_hco()
        return self.work_data_hco.self_link

    def _raise_if_no_hco(self):
        if self.work_data_hco is None:
            raise Exception("No work data hco present. Maybe this class is used after resource deletion.")


class WorkDataQuery:
    """Convenience wrapper for querying WorkData.
    """

    _client: httpx.Client
    _entrypoint: EntryPointHco
    _work_data_root: WorkDataRootHco
    parameters: WorkDataQueryParameters

    def __init__(self, client: httpx.Client, parameters: WorkDataQueryParameters):
        self._client = client
        self._entrypoint = enter_jma(client)
        self._work_data_root = self._entrypoint.work_data_root_link.navigate()
        self.parameters = parameters

    @classmethod
    def from_parameters(cls, client: httpx.Client, parameters: WorkDataQueryParameters) -> Self:
        """Create a WorkDataQuery from a WorkDataQueryParameters object.
        """
        return cls(client, parameters)

    @classmethod
    def create(
            cls,
            client: httpx.Client,
            *,
            page_size: int | None = None,
            page_offset: int | None = None,
            sort_by_property_name: WorkDataSortProperties | None = None,
            sort_by_sort_type: SortTypes | None = None,
            include_remaining_tags: bool | None = None,
            name_contains: str | None = None,
            producer_processing_step_url: AnyUrl | None = None,
            show_hidden: bool | None = None,
            media_type_contains: str | None = None,
            tags_by_and: list[str] | None = None,
            tags_by_or: list[str] | None = None,
            tag_query_expression: str | None = None,
            is_kind: WorkDataKind | None = None,
            created_before: AwareDatetime | None = None,
            created_after: AwareDatetime | None = None,
            is_deletable: bool | None = None,
            is_used: bool | None = None
    ) -> Self:
        """Create a WorkDataQuery from flat parameters.
        """
        filter_param = WorkDataFilterParameter(
            name_contains=name_contains,
            producer_processing_step_url=producer_processing_step_url,
            show_hidden=show_hidden,
            media_type_contains=media_type_contains,
            tags_by_and=tags_by_and,
            tags_by_or=tags_by_or,
            TagQueryExpression=tag_query_expression,
            is_kind=is_kind,
            created_before=created_before,
            created_after=created_after,
            is_deletable=is_deletable,
            is_used=is_used
        )

        sort_by = None
        if sort_by_property_name is not None or sort_by_sort_type is not None:
            sort_by = WorkDataSortPropertiesSortParameter(
                property_name=sort_by_property_name,
                sort_type=sort_by_sort_type
            )

        pagination = None
        if page_size is not None or page_offset is not None:
            pagination = Pagination(page_size=page_size, page_offset=page_offset)

        parameters = WorkDataQueryParameters(
            sort_by=sort_by,
            filter=filter_param,
            pagination=pagination,
            include_remaining_tags=include_remaining_tags
        )
        return cls(client, parameters)

    def execute(self) -> WorkDataQueryResultHco:
        """Executes the query and returns a WorkDataQueryResultHco.
        """
        return self._work_data_root.query_action.execute(self.parameters)

    def count(self) -> int:
        """Returns the total number of entities matching the query.
        """
        return self.execute().total_entities

    def exists(self) -> bool:
        """Returns True if there are any entities matching the query.
        """
        return self.count() > 0

    def first(self) -> WorkData | None:
        """Returns the first entity matching the query, or None if no entities match.
        """
        result = self.execute()
        if result.workdatas:
            return WorkData.from_hco(result.workdatas[0])
        return None

    def one(self) -> WorkData:
        """Returns exactly one entity matching the query.
        Raises an exception if no entities are found or if multiple entities match.
        """
        result = self.execute()
        if result.total_entities == 0:
            raise Exception("No entities found matching the query.")
        if result.total_entities > 1:
            raise Exception(f"Expected exactly one entity, but found {result.total_entities}.")
        return WorkData.from_hco(result.workdatas[0])

    def to_list(self) -> list[WorkData]:
        """Returns all entities matching the query as a list.
        """
        return list(self.iter())

    def iter(self) -> Iterator[WorkData]:
        """
        Returns an Iterator of `WorkData` so that all work data can be processed in a loop.

        Returns:
            An iterator of `WorkData` objects
        """
        for page in self.execute().iter():
            for work_data_hco in page.workdatas:
                yield WorkData.from_hco(work_data_hco)
