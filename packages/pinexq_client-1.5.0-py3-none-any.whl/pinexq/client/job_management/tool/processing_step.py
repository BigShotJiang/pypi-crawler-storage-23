from typing import Any, Iterator, Optional, Self

import httpx
from httpx import URL

from pydantic import AnyUrl, AwareDatetime

from ...core import Link, MediaTypes
from ...core.hco.upload_action_hco import UploadParameters
from ..enterjma import enter_jma
from ..hcos import (
    EntryPointHco,
    GenericProcessingConfigureParameters,
    ProcessingStepHco,
    ProcessingStepLink,
    ProcessingStepQueryResultHco,
    ProcessingStepsRootHco,
)
from ..known_relations import Relations
from ..model import (
    AssignCodeHashParameters,
    ConfigureDeploymentParameters,
    CopyPsFromUserToOrgActionParameters,
    DeploymentResourcePresets,
    DeploymentStates,
    DeprecatePsActionParameters,
    FunctionNameMatchTypes,
    Pagination,
    ProcessingStepFilterParameter,
    ProcessingStepQueryParameters,
    ProcessingStepSortProperties,
    ProcessingStepSortPropertiesSortParameter,
    ScalingConfiguration,
    SetProcessingStepTagsParameters,
    SetProcessingStepTitleParameters,
    SortTypes,
)


class ProcessingStep:
    """Convenience wrapper for handling ProcessingStepHcos in the JobManagement-Api.
    """

    _client: httpx.Client
    _entrypoint: EntryPointHco
    _processing_steps_root: ProcessingStepsRootHco
    processing_step_hco: ProcessingStepHco | None = None # Internal hco of the wrapper. This is updated by this class. You should not take a reference to this object.


    def __init__(self, client: httpx.Client):
        """

        Args:
            client: An httpx.Client instance initialized with the api-host-url as `base_url`
        """
        self._client = client
        self._entrypoint = enter_jma(client)
        self._processing_steps_root = self._entrypoint.processing_step_root_link.navigate()

    def create(self, json_data: Any) -> Self:
        """Create a new processing step.

        Args:
            json_data: The JSON data representing the configuration of the processing step to be created.

        Returns:
            The newly created processing step as `ProcessingStep` object.
        """
        upload_parameters = UploadParameters(
            filename="processing_step.json",  # placeholder, jma does not care about filename
            mediatype=MediaTypes.APPLICATION_JSON,
            json=json_data
        )
        processing_step_link = self._processing_steps_root.register_new_action.execute(upload_parameters)
        self._get_by_link(processing_step_link)
        return self

    def _get_by_link(self, processing_step_link: ProcessingStepLink):
        self.processing_step_hco = processing_step_link.navigate()

    @classmethod
    def from_hco(cls, processing_step: ProcessingStepHco) -> Self:
        """Initializes a `ProcessingStep` object from an existing ProcessingStepHco object.

        Args:
            processing_step: The 'ProcessingStepHco' to initialize this ProcessingStep from.

        Returns:
            The newly created processing step as `ProcessingStep` object.
        """
        processing_step_instance = cls(processing_step._client)
        processing_step_instance.processing_step_hco = processing_step
        return processing_step_instance

    @classmethod
    def from_url(cls, client: httpx.Client, processing_step_url: URL) -> Self:
        """Initializes a `ProcessingStep` object from an existing processing step given by its link as URL.

        Args:
            client: An httpx.Client instance initialized with the api-host-url as `base_url`
            processing_step_url: The URL of the processing step

        Returns:
            The newly created processing step as `ProcessingStep` object
        """
        link = Link.from_url(
            processing_step_url,
            [str(Relations.CREATED_RESSOURCE)],
            "Created processing step",
            MediaTypes.SIREN,
        )
        processing_step_instance = cls(client)
        processing_step_instance._get_by_link(ProcessingStepLink.from_link(client, link))
        return processing_step_instance

    @classmethod
    def from_name(cls, client: httpx.Client, step_name: str, version: str = "0") -> Self:
        """Create a ProcessingStep object from an existing name.

        Args:
            client: Create a ProcessingStep object from an existing name.
            step_name: Name of the registered processing step.
            version: Version of the ProcessingStep to be created

        Returns:
            The newly created processing step as `ProcessingStep` object
        """

        # Attempt to find the processing step
        query_result = cls._query_processing_steps(client, step_name, version)

        # Check if exactly one result is found
        if len(query_result.processing_steps) != 1:
            # Attempt to suggest alternative steps if exact match not found
            suggested_steps = cls._processing_steps_by_name(client, step_name)
            raise NameError(
                f"No processing step with the name {step_name} and version {version} registered. "
                f"Suggestions: {suggested_steps}"
            )

        # Todo: For now we choose the first and only result. Make this more flexible?
        processing_step_hco = query_result.processing_steps[0]
        return ProcessingStep.from_hco(processing_step_hco)

    @staticmethod
    def _query_processing_steps(client: httpx.Client, step_name: str,
                                version: Optional[str] = None) -> ProcessingStepQueryResultHco:
        """
        Helper function to query processing steps based on name and optional version.

        Args:
            client: HTTP client for executing queries.
            step_name: Name of the processing step.
            version: Optional version to match.

        Returns:
            Query result object containing the matching processing steps.
        """
        query_param = ProcessingStepQueryParameters(
            Filter=ProcessingStepFilterParameter(
                FunctionName=step_name,
                FunctionNameMatchType=FunctionNameMatchTypes.match_exact,
                Version=version
            )
        )
        instance = ProcessingStep(client)
        return instance._processing_steps_root.query_action.execute(query_param)

    @staticmethod
    def _processing_steps_by_name(client: httpx.Client, step_name: str) -> list:
        """
        Suggest processing steps if the exact step is not found.

        Args:
            client: HTTP client for executing queries.
            step_name: Name of the processing step.

        Returns:
            A list of alternative processing steps matching the step name.
        """
        # Query for steps without  version to get suggestions
        instance = ProcessingStep(client)
        query_result = instance._query_processing_steps(client, step_name)

        # If no suggestions are found, raise an error
        if len(query_result.processing_steps) == 0:
            raise NameError(f"No processing steps found with the name '{step_name}'.")

        # Return list of alternative steps as suggestions
        return [f"{step.function_name}:{step.version}" for step in query_result.processing_steps]

    def refresh(self) -> Self:
        """Updates the processing step from the server

        Returns:
            This `ProcessingStep` object, but with updated properties.
        """
        self._raise_if_no_hco()
        self.processing_step_hco = self.processing_step_hco.self_link.navigate()
        return self

    def set_tags(self, tags: list[str]) -> Self:
        """Set tags to the processing step.

        Returns:
            This `ProcessingStep` object"""
        self._raise_if_no_hco()
        self.processing_step_hco.edit_tags_action.execute(SetProcessingStepTagsParameters(
            Tags=tags
        ))
        self.refresh()
        return self

    def configure_default_parameters(self, **parameters: Any) -> Self:
        """Set the parameters to run the processing step with.

        Args:
            **parameters: Any keyword parameters provided will be forwarded as parameters
                to the processing step function.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.configure_default_parameters_action.execute(
            GenericProcessingConfigureParameters.model_validate(parameters)
        )

        self.refresh()
        return self

    def clear_default_parameters(self) -> Self:
        """Clear default parameters.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.clear_default_parameters_action.execute()
        self.refresh()

        return self

    def hide(self) -> Self:
        """Hide ProcessingStep.

        Returns:
            This `ProcessingStep` object"""
        self._raise_if_no_hco()
        self.processing_step_hco.hide_action.execute()
        self.refresh()
        return self

    def unhide(self) -> Self:
        """Hide ProcessingStep.

        Returns:
            This `ProcessingStep` object"""
        self._raise_if_no_hco()
        self.processing_step_hco.unhide_action.execute()
        self.refresh()
        return self

    def delete(self) -> Self:
        """Delete ProcessingStep.

        Returns:
            This `ProcessingStep` object"""
        self._raise_if_no_hco()
        self.processing_step_hco.delete_action.execute()
        self.processing_step_hco = None
        return self

    def deprecate(self, reason: str | None = None) -> Self:
        """Deprecate ProcessingStep.

        Returns:
            This `ProcessingStep` object"""
        self._raise_if_no_hco()
        self.processing_step_hco.deprecate_ps_action.execute(
            DeprecatePsActionParameters(Reason=reason)
        )
        self.refresh()
        return self

    def is_deprecated(self) -> bool:
        """Check if ProcessingStep is deprecated.

        Returns:
            True if deprecated, False otherwise.
        """
        self._raise_if_no_hco()
        return self.processing_step_hco.is_deprecated

    def restore(self) -> Self:
        """Restore ProcessingStep.

        Returns:
            This `ProcessingStep` object"""
        self._raise_if_no_hco()
        self.processing_step_hco.restore_ps_action.execute()
        self.refresh()
        return self

    def assign_code_hash(self, code_hash: str) -> Self:
        """Assign a code hash to the ProcessingStep.

        Args:
            code_hash: The code hash to assign.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.assign_code_hash_action.execute(
            AssignCodeHashParameters(CodeHash=code_hash)
        )
        self.refresh()
        return self

    def configure_deployment(
            self,
            *,
            resource_preset: DeploymentResourcePresets,
            entrypoint: str,
            scaling: ScalingConfiguration
    ) -> Self:
        """Specify the desired deployment for this ProcessingStep.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.configure_deployment_action.execute(
            ConfigureDeploymentParameters(
                ResourcePreset = resource_preset,
                Entrypoint = entrypoint,
                Scaling = scaling
            )
        )
        self.refresh()
        return self

    def configure_external_deployment(self) -> Self:
        """Specify this ProcessingStep to have an external deployment.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.configure_external_deployment_action.execute()
        self.refresh()
        return self

    def remove_deployment(self) -> Self:
        """Remove the deployment for this ProcessingStep.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.remove_deployment_action.execute()
        self.refresh()
        return self

    def suspend_deployment(self) -> Self:
        """Suspend the deployment for this ProcessingStep.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.suspend_deployment_action.execute()
        self.refresh()
        return self

    def resume_deployment(self) -> Self:
        """Resume the deployment for this ProcessingStep.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.resume_deployment_action.execute()
        self.refresh()
        return self

    def clear_code_hash(self) -> Self:
        """Clear the code hash of the ProcessingStep.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.clear_code_hash_action.execute()
        self.refresh()
        return self

    def get_deployment_state(self) -> DeploymentStates:
        """Get the deployment state of the ProcessingStep.

        Returns:
            The deployment state
        """
        self._raise_if_no_hco()
        return self.processing_step_hco.deployment_state

    def copy_from_org_to_user(self) -> ProcessingStepLink:
        """Copy ProcessingStep from organization to user.

        Returns:
            The URL of the copied ProcessingStep
        """
        self._raise_if_no_hco()
        return self.processing_step_hco.copy_from_org_to_user_action.execute()

    def copy_from_user_to_org(self, *, org_id: str) -> ProcessingStepLink:
        """Copy ProcessingStep from user to organization.

        Args:
            org_id: The ID of the organization to copy the processing step to.
            title: New title for the copied ProcessingStep
            function_name: New function for the copied ProcessingStep
            version: New version for the copied ProcessingStep

        Returns:
            The URL of the copied ProcessingStep
        """
        self._raise_if_no_hco()
        return self.processing_step_hco.copy_from_user_to_org_action.execute(
            CopyPsFromUserToOrgActionParameters(OrgId=org_id)
        )

    def make_public(self) -> Self:
        """Make the ProcessingStep public.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.make_public_action.execute()
        self.refresh()
        return self

    def make_private(self) -> Self:
        """Make the ProcessingStep private.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.make_private_action.execute()
        self.refresh()
        return self

    def set_title(self, title: str) -> Self:
        """Set the title of the ProcessingStep.

        Args:
            title: The new title for the ProcessingStep.

        Returns:
            This `ProcessingStep` object
        """
        self._raise_if_no_hco()
        self.processing_step_hco.set_title_action.execute(
            SetProcessingStepTitleParameters(Title=title)
        )
        self.refresh()
        return self

    def self_link(self) -> ProcessingStepLink:
        self._raise_if_no_hco()
        return self.processing_step_hco.self_link

    def _raise_if_no_hco(self):
        if self.processing_step_hco is None:
            raise Exception("No processing step hco present. Maybe this class is used after resource deletion.")


class ProcessingStepQuery:
    """Convenience wrapper for querying ProcessingSteps.
    """

    _client: httpx.Client
    _entrypoint: EntryPointHco
    _processing_steps_root: ProcessingStepsRootHco
    parameters: ProcessingStepQueryParameters

    def __init__(self, client: httpx.Client, parameters: ProcessingStepQueryParameters):
        self._client = client
        self._entrypoint = enter_jma(client)
        self._processing_steps_root = self._entrypoint.processing_step_root_link.navigate()
        self.parameters = parameters

    @classmethod
    def from_parameters(cls, client: httpx.Client, parameters: ProcessingStepQueryParameters) -> Self:
        """Create a ProcessingStepQuery from a ProcessingStepQueryParameters object.
        """
        return cls(client, parameters)

    @classmethod
    def create(
            cls,
            client: httpx.Client,
            *,
            page_size: int | None = None,
            page_offset: int | None = None,
            sort_by_property_name: ProcessingStepSortProperties | None = None,
            sort_by_sort_type: SortTypes | None = None,
            include_remaining_tags: bool | None = None,
            function_name: str | None = None,
            function_name_match_type: FunctionNameMatchTypes | None = None,
            title_contains: str | None = None,
            version: str | None = None,
            description_contains: str | None = None,
            tags_by_and: list[str] | None = None,
            tags_by_or: list[str] | None = None,
            tag_query_expression: str | None = None,
            is_public: bool | None = None,
            show_hidden: bool | None = None,
            show_deprecated: bool | None = None,
            deployment_state: DeploymentStates | None = None,
            show_prerelease: bool | None = None,
            pro_con_version: str | None = None
    ) -> Self:
        """Create a ProcessingStepQuery from flat parameters.
        """
        filter_param = ProcessingStepFilterParameter(
            function_name=function_name,
            function_name_match_type=function_name_match_type,
            title_contains=title_contains,
            version=version,
            description_contains=description_contains,
            tags_by_and=tags_by_and,
            tags_by_or=tags_by_or,
            TagQueryExpression=tag_query_expression,
            is_public=is_public,
            show_hidden=show_hidden,
            show_deprecated=show_deprecated,
            deployment_state=deployment_state,
            show_prerelease=show_prerelease,
            pro_con_version=pro_con_version
        )

        sort_by = None
        if sort_by_property_name is not None or sort_by_sort_type is not None:
            sort_by = ProcessingStepSortPropertiesSortParameter(
                property_name=sort_by_property_name,
                sort_type=sort_by_sort_type
            )

        pagination = None
        if page_size is not None or page_offset is not None:
            pagination = Pagination(page_size=page_size, page_offset=page_offset)

        parameters = ProcessingStepQueryParameters(
            sort_by=sort_by,
            filter=filter_param,
            pagination=pagination,
            include_remaining_tags=include_remaining_tags
        )

        return cls(client, parameters)

    def execute(self) -> ProcessingStepQueryResultHco:
        """Executes the query and returns a ProcessingStepQueryResultHco.
        """
        return self._processing_steps_root.query_action.execute(self.parameters)

    def count(self) -> int:
        """Returns the total number of entities matching the query.
        """
        return self.execute().total_entities

    def exists(self) -> bool:
        """Returns True if there are any entities matching the query.
        """
        return self.count() > 0

    def first(self) -> ProcessingStep | None:
        """Returns the first entity matching the query, or None if no entities match.
        """
        result = self.execute()
        if result.processing_steps:
            return ProcessingStep.from_hco(result.processing_steps[0])
        return None

    def one(self) -> ProcessingStep:
        """Returns exactly one entity matching the query.
        Raises an exception if no entities are found or if multiple entities match.
        """
        result = self.execute()
        if result.total_entities == 0:
            raise Exception("No entities found matching the query.")
        if result.total_entities > 1:
            raise Exception(f"Expected exactly one entity, but found {result.total_entities}.")
        return ProcessingStep.from_hco(result.processing_steps[0])

    def to_list(self) -> list[ProcessingStep]:
        """Returns all entities matching the query as a list.
        """
        return list(self.iter())

    def iter(self) -> Iterator[ProcessingStep]:
        """
        Returns an Iterator of `ProcessingStep` so that all processing steps can be processed in a loop.

        Returns:
            An iterator of `ProcessingStep` objects
        """
        for page in self.execute().iter():
            for ps_hco in page.processing_steps:
                yield ProcessingStep.from_hco(ps_hco)
