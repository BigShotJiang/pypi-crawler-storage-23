"""Shared geo types for samgis domain."""
from typing import NamedTuple


class ImagePixelCoordinates(NamedTuple):
    x: int | float
    y: int | float


class LatLng(NamedTuple):
    lat: float
    lng: float


# 6-coefficient affine transform (GDAL convention): (origin_x, pixel_width, row_rotation, origin_y, col_rotation, pixel_height)
AffineTransform = tuple[float, float, float, float, float, float]
