"""Domain ports (ABCs) for geo operations."""
from abc import ABC, abstractmethod
from numpy import ndarray


class VectorizerPort(ABC):
    """Converts a binary mask + affine transform into a GeoJSON FeatureCollection."""

    @abstractmethod
    def vectorize(
        self,
        mask: ndarray,
        transform: tuple[float, ...],
        source_crs: str = "EPSG:3857",
        target_crs: str = "EPSG:4326",
    ) -> str:
        """
        Args:
            mask: Binary mask array (H, W), dtype uint8, values {0, 255}.
            transform: 6-coefficient affine transform (GDAL convention).
            source_crs: CRS of the mask/transform. Default EPSG:3857.
            target_crs: CRS for the output GeoJSON. Default EPSG:4326.

        Returns:
            GeoJSON FeatureCollection string.
        """
        ...
