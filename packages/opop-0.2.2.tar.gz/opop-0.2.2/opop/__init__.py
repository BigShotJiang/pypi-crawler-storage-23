"""OpOp -- The Optimizer Optimizer.

Two modes:
  1. OptBrain: wraps any existing optimizer (Adam, SGD, etc.) with a learned brain
  2. TwinCrack: gradient-free optimization via twin learned perturbation agents

OptBrain watches your training and learns what helps. Drop-in, can't make things worse.
TwinCrack replaces gradients entirely. No .backward(). No autograd. Just two forward passes.

Both brains train online via REINFORCE. Both get better with every step.
Both are ~6KB. Both transfer across models.
"""

__version__ = "0.2.2"

from opop.brain import OptBrain, Brain, TrainingObserver
from opop.twin_crack import TwinCrack, PerturbBrain, PerturbObserver

__all__ = [
    "OptBrain", "Brain", "TrainingObserver",
    "TwinCrack", "PerturbBrain", "PerturbObserver",
]
