"""AgentCompany - Spin up an AI agent company managed by you."""

__version__ = "0.1.0"
