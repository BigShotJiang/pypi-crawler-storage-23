"""Allow running as python -m agentcompany."""

from agentcompany.cli.app import app

app()
