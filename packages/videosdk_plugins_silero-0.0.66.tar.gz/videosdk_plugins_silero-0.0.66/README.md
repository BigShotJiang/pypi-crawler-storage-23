# VideoSDK Silero Plugin

Agent Framework plugin for Silero.

## Installation

```bash
pip install videosdk-plugins-silero
```