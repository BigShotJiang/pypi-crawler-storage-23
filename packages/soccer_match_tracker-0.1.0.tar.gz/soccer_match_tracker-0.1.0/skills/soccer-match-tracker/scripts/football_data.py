"""
football-data.org API integration.

Provides league standings, match fixtures, results, and team squad data
from the football-data.org free API tier (10 requests/minute).

API documentation: https://www.football-data.org/documentation/api
"""

import json
import logging
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import requests

logger = logging.getLogger(__name__)

FOOTBALL_DATA_BASE = "https://api.football-data.org/v4"
DEFAULT_TIMEOUT = 15

# League codes for football-data.org
LEAGUE_CODES = {
    "PL": "PL",        # Premier League
    "PD": "PD",        # La Liga (Primera Division)
    "CL": "CL",        # Champions League
    "MLS": "MLS",      # Major League Soccer
    # Aliases
    "premier-league": "PL",
    "la-liga": "PD",
    "champions-league": "CL",
    "epl": "PL",
    "laliga": "PD",
    "ucl": "CL",
}

# Cache settings
CACHE_DIR = os.path.expanduser("~/.soccer_match_tracker/cache")
CACHE_TTL = 300  # 5 minutes for standings/fixtures


class RateLimiter:
    """Rate limiter for football-data.org free tier (10 requests/minute)."""

    def __init__(self, max_requests: int = 10, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._timestamps: list = []

    def wait_if_needed(self):
        """Block until a request can be made within the rate limit."""
        now = time.time()

        # Remove timestamps outside the window
        self._timestamps = [
            ts for ts in self._timestamps
            if now - ts < self.window_seconds
        ]

        if len(self._timestamps) >= self.max_requests:
            # Calculate how long to wait
            oldest = self._timestamps[0]
            wait_time = self.window_seconds - (now - oldest) + 0.1
            if wait_time > 0:
                logger.info(
                    "Rate limit: waiting %.1f seconds (at %d/%d requests)",
                    wait_time, len(self._timestamps), self.max_requests,
                )
                time.sleep(wait_time)

        self._timestamps.append(time.time())


class ResponseCache:
    """File-based cache for football-data.org responses."""

    def __init__(self, cache_dir: Optional[str] = None, ttl: int = CACHE_TTL):
        self.cache_dir = Path(cache_dir or CACHE_DIR)
        self.ttl = ttl
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, key: str) -> Path:
        """Get file path for a cache key."""
        safe_key = key.replace("/", "_").replace("?", "_").replace("&", "_")
        return self.cache_dir / f"{safe_key}.json"

    def get(self, key: str) -> Optional[dict]:
        """Retrieve cached response if fresh."""
        path = self._cache_path(key)
        if not path.exists():
            return None

        try:
            with open(path, "r") as f:
                cached = json.load(f)
            cached_at = cached.get("cached_at", "")
            if cached_at:
                cached_time = datetime.fromisoformat(cached_at)
                age = (datetime.now(timezone.utc) - cached_time).total_seconds()
                if age < self.ttl:
                    logger.debug("Cache hit for %s (age: %.0fs)", key, age)
                    return cached.get("data")
        except (json.JSONDecodeError, IOError, ValueError) as e:
            logger.warning("Cache read error for %s: %s", key, e)

        return None

    def set(self, key: str, data):
        """Store response in cache."""
        path = self._cache_path(key)
        try:
            with open(path, "w") as f:
                json.dump({
                    "cached_at": datetime.now(timezone.utc).isoformat(),
                    "data": data,
                }, f)
        except IOError as e:
            logger.warning("Cache write error for %s: %s", key, e)


class FootballDataClient:
    """
    Client for the football-data.org API.

    Provides standings, matches, fixtures, and team data for Premier League,
    La Liga, Champions League, and MLS.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("FOOTBALL_DATA_API_KEY")
        if not self.api_key:
            raise ValueError(
                "FOOTBALL_DATA_API_KEY is required. Set it as an environment "
                "variable or pass it to FootballDataClient(api_key='...'). "
                "Register for a free key at https://www.football-data.org/client/register"
            )
        self.session = requests.Session()
        self.session.headers.update({
            "X-Auth-Token": self.api_key,
            "Content-Type": "application/json",
        })
        self.rate_limiter = RateLimiter()
        self.cache = ResponseCache()

    def _resolve_league(self, league_code: str) -> str:
        """Resolve a league alias to the football-data.org code."""
        resolved = LEAGUE_CODES.get(league_code, league_code)
        return resolved

    def _request(self, endpoint: str, params: Optional[dict] = None, use_cache: bool = True) -> dict:
        """
        Make an API request with rate limiting and caching.

        Args:
            endpoint: API endpoint path (e.g., '/competitions/PL/standings').
            params: Query parameters.
            use_cache: Whether to check cache first.

        Returns:
            Response JSON dict.
        """
        cache_key = f"{endpoint}_{json.dumps(params or {}, sort_keys=True)}"

        if use_cache:
            cached = self.cache.get(cache_key)
            if cached is not None:
                return cached

        # Respect rate limit
        self.rate_limiter.wait_if_needed()

        url = f"{FOOTBALL_DATA_BASE}{endpoint}"
        logger.info("Fetching %s", url)

        try:
            response = self.session.get(url, params=params, timeout=DEFAULT_TIMEOUT)

            if response.status_code == 429:
                # Rate limited by the API
                retry_after = int(response.headers.get("X-RequestCounter-Reset", 60))
                logger.warning(
                    "football-data.org rate limit hit, waiting %d seconds",
                    retry_after,
                )
                time.sleep(retry_after)
                # Retry once
                response = self.session.get(url, params=params, timeout=DEFAULT_TIMEOUT)

            response.raise_for_status()
            data = response.json()

            # Cache the response
            if use_cache:
                self.cache.set(cache_key, data)

            return data

        except requests.exceptions.HTTPError as e:
            if e.response is not None:
                if e.response.status_code == 403:
                    raise ValueError(
                        "football-data.org API key invalid or tier insufficient. "
                        "Check FOOTBALL_DATA_API_KEY."
                    ) from e
                if e.response.status_code == 404:
                    raise ValueError(
                        f"Resource not found: {endpoint}. "
                        f"Valid league codes: {list(LEAGUE_CODES.keys())}"
                    ) from e
            raise
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"football-data.org request failed: {e}") from e

    def get_standings(self, league_code: str) -> dict:
        """
        Get current league standings / table.

        Args:
            league_code: League code (PL, PD, CL, MLS) or alias.

        Returns:
            dict with 'standings' list containing table entries.
            Each entry has: position, team, playedGames, won, draw, lost,
            points, goalsFor, goalsAgainst, goalDifference.
        """
        league = self._resolve_league(league_code)
        data = self._request(f"/competitions/{league}/standings")

        standings = []
        for standing_type in data.get("standings", []):
            # Use TOTAL type for overall table
            if standing_type.get("type") == "TOTAL":
                for entry in standing_type.get("table", []):
                    team_data = entry.get("team", {})
                    standings.append({
                        "position": entry.get("position"),
                        "team": team_data.get("name"),
                        "team_id": team_data.get("id"),
                        "team_crest": team_data.get("crest"),
                        "played": entry.get("playedGames"),
                        "won": entry.get("won"),
                        "draw": entry.get("draw"),
                        "lost": entry.get("lost"),
                        "goals_for": entry.get("goalsFor"),
                        "goals_against": entry.get("goalsAgainst"),
                        "goal_difference": entry.get("goalDifference"),
                        "points": entry.get("points"),
                        "form": entry.get("form"),
                    })
                break

        # If no TOTAL type found, use first available
        if not standings and data.get("standings"):
            first = data["standings"][0]
            for entry in first.get("table", []):
                team_data = entry.get("team", {})
                standings.append({
                    "position": entry.get("position"),
                    "team": team_data.get("name"),
                    "team_id": team_data.get("id"),
                    "team_crest": team_data.get("crest"),
                    "played": entry.get("playedGames"),
                    "won": entry.get("won"),
                    "draw": entry.get("draw"),
                    "lost": entry.get("lost"),
                    "goals_for": entry.get("goalsFor"),
                    "goals_against": entry.get("goalsAgainst"),
                    "goal_difference": entry.get("goalDifference"),
                    "points": entry.get("points"),
                    "form": entry.get("form"),
                })

        competition = data.get("competition", {})
        season = data.get("season", {})

        return {
            "competition": competition.get("name"),
            "competition_code": league,
            "season": season.get("startDate", "")[:4] + "/" + season.get("endDate", "")[:4],
            "matchday": data.get("season", {}).get("currentMatchday"),
            "standings": standings,
        }

    def get_matches(self, league_code: str, status: Optional[str] = None) -> dict:
        """
        Get matches for a competition, optionally filtered by status.

        Args:
            league_code: League code or alias.
            status: Filter by status: 'LIVE', 'SCHEDULED', 'FINISHED', 'IN_PLAY'.
                   Can combine: 'LIVE,IN_PLAY' for all active.

        Returns:
            dict with 'matches' list.
        """
        league = self._resolve_league(league_code)
        params = {}
        if status:
            params["status"] = status

        data = self._request(f"/competitions/{league}/matches", params=params)

        matches = []
        for match in data.get("matches", []):
            home = match.get("homeTeam", {})
            away = match.get("awayTeam", {})
            score = match.get("score", {})
            full_time = score.get("fullTime", {})
            half_time = score.get("halfTime", {})

            matches.append({
                "match_id": match.get("id"),
                "competition": league,
                "matchday": match.get("matchday"),
                "status": match.get("status"),
                "utc_date": match.get("utcDate"),
                "home_team": home.get("name"),
                "home_team_id": home.get("id"),
                "away_team": away.get("name"),
                "away_team_id": away.get("id"),
                "home_score": full_time.get("home"),
                "away_score": full_time.get("away"),
                "ht_home": half_time.get("home"),
                "ht_away": half_time.get("away"),
                "winner": score.get("winner"),
                "duration": score.get("duration"),
                "referees": [
                    {"name": r.get("name"), "nationality": r.get("nationality")}
                    for r in match.get("referees", [])
                ],
            })

        return {
            "competition": league,
            "matches": matches,
            "count": len(matches),
        }

    def get_upcoming(self, league_code: str, days: int = 7) -> dict:
        """
        Get upcoming fixtures for the next N days.

        Args:
            league_code: League code or alias.
            days: Number of days ahead to look. Default: 7.

        Returns:
            dict with 'matches' list of upcoming fixtures.
        """
        league = self._resolve_league(league_code)
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        end = (datetime.now(timezone.utc) + timedelta(days=days)).strftime("%Y-%m-%d")

        params = {
            "dateFrom": today,
            "dateTo": end,
            "status": "SCHEDULED,TIMED",
        }

        data = self._request(f"/competitions/{league}/matches", params=params)

        matches = []
        for match in data.get("matches", []):
            home = match.get("homeTeam", {})
            away = match.get("awayTeam", {})

            matches.append({
                "match_id": match.get("id"),
                "competition": league,
                "matchday": match.get("matchday"),
                "utc_date": match.get("utcDate"),
                "home_team": home.get("name"),
                "away_team": away.get("name"),
                "venue": match.get("venue"),
            })

        # Sort by date
        matches.sort(key=lambda m: m.get("utc_date", ""))

        return {
            "competition": league,
            "date_from": today,
            "date_to": end,
            "matches": matches,
            "count": len(matches),
        }

    def get_team_squad(self, team_id: int) -> dict:
        """
        Get the squad / roster for a team.

        Args:
            team_id: The football-data.org team ID.

        Returns:
            dict with team info and 'squad' list of players.
        """
        data = self._request(f"/teams/{team_id}")

        squad = []
        for player in data.get("squad", []):
            squad.append({
                "id": player.get("id"),
                "name": player.get("name"),
                "position": player.get("position"),
                "date_of_birth": player.get("dateOfBirth"),
                "nationality": player.get("nationality"),
                "shirt_number": player.get("shirtNumber"),
            })

        return {
            "team": data.get("name"),
            "team_id": data.get("id"),
            "short_name": data.get("shortName"),
            "crest": data.get("crest"),
            "venue": data.get("venue"),
            "coach": data.get("coach", {}).get("name"),
            "squad": squad,
            "squad_size": len(squad),
        }

    def get_todays_matches(self) -> dict:
        """
        Get all matches happening today across all covered leagues.

        Returns:
            dict mapping league code to list of today's matches.
        """
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        all_matches = {}

        for league_code in ["PL", "PD", "CL", "MLS"]:
            try:
                params = {
                    "dateFrom": today,
                    "dateTo": today,
                }
                data = self._request(
                    f"/competitions/{league_code}/matches",
                    params=params,
                )
                matches = data.get("matches", [])
                if matches:
                    all_matches[league_code] = []
                    for match in matches:
                        home = match.get("homeTeam", {})
                        away = match.get("awayTeam", {})
                        score = match.get("score", {}).get("fullTime", {})
                        all_matches[league_code].append({
                            "match_id": match.get("id"),
                            "status": match.get("status"),
                            "utc_date": match.get("utcDate"),
                            "home_team": home.get("name"),
                            "away_team": away.get("name"),
                            "home_score": score.get("home"),
                            "away_score": score.get("away"),
                            "matchday": match.get("matchday"),
                        })
            except Exception as e:
                logger.warning("Failed to fetch %s matches: %s", league_code, e)

        return all_matches
