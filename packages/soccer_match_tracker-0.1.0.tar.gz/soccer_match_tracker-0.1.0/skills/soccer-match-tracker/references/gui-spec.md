# GUI Specification: soccer-match-tracker

## Design Direction
- **Style:** Match center layout with a distinctly football/soccer aesthetic. Dark green theme evoking the pitch itself. Top section features a stylized pitch visualization showing formations and key events. Below, a chronological event timeline captures goals, cards, substitutions. Sidebar provides live stats. Designed for the global football fan.
- **Inspiration:** FotMob match center interface, BBC Sport live match page on Dribbble, Opta sports data visualization on Behance
- **Mood:** Passionate, global, tactical, flowing

## Layout
- **Primary view:** Vertical three-section layout. Top section (35%) contains the match header (teams, score, time) and a simplified pitch visualization showing team formations with player dots and event markers (goal icons, card icons at positions). Middle section (40%) is the event timeline — a vertical chronological feed of match events (goals, cards, subs) with minute markers. Right sidebar (25%) shows live stats comparison (possession, shots, passes, corners) as horizontal bars.
- **Mobile:** Single column. Match header becomes a sticky compact scoreline. Pitch visualization scales down or becomes a toggleable overlay. Event timeline is the primary scrollable feed. Stats accessible via a tab toggle between "Events" and "Stats".
- **Header:** Match header bar with: home team crest + name (left), score with match minute and status indicator (center), away team crest + name (right). Background: dark green gradient. Competition name and matchday info above.

## Color Palette
- Background: #064E3B (Deep Pitch Green)
- Surface: #065F46 (Emerald Panel)
- Primary accent: #10B981 (Bright Emerald) — active states, live indicators, interactive elements
- Success: #FDE047 (Goal Gold) — goal events, key moments, match-winning highlights
- Warning: #EF4444 (Red Card Red) — red cards, sending-off events, VAR decisions
- Text primary: #ECFDF5 (Mint White)
- Text secondary: #A7F3D0 (Light Emerald)

## Component Structure
- **PitchVisualization** — Simplified top-down pitch SVG with team formations rendered as colored dots (home/away colors). Event markers (goal icon, card icon) appear at approximate pitch positions. Formations labels (e.g., 4-3-3) shown at each end.
- **MatchScoreHeader** — Prominent center-aligned score display with home and away team crests, names, current score (large type), match minute with pulsing live dot, and half-time/full-time status. Competition logo and matchday info in a sub-row.
- **EventTimeline** — Vertical timeline with minute markers on the left axis. Each event is a card: goal (gold accent, scorer name, assist), yellow card (amber), red card (red), substitution (emerald, player in/out), VAR review (blue). Half-time divider splits the timeline.
- **StatsComparison** — Horizontal bar pairs for each stat (possession, shots, shots on target, corners, fouls, offsides). Home team bar extends left, away team extends right, meeting at center. Percentages/values at ends.
- **SubstitutionCard** — Event card showing player out (red arrow) and player in (green arrow) with names and minute. Compact inline design within the event timeline.
- **FormationDisplay** — Team formation label (e.g., "4-3-3") with expandable player list by position group (GK, DEF, MID, FWD). Shown below the pitch visualization.
- **MatchStatusBadge** — Badge showing match state: "1st Half" (emerald), "HT" (amber), "2nd Half" (emerald), "FT" (grey), "ET" (red for extra time), "PEN" (gold for penalties).

## Typography
- Headings: Inter Bold, 20-28px, letter-spacing -0.02em, #ECFDF5
- Body: Inter Regular, 14-16px, line-height 1.5, #A7F3D0 for secondary, #ECFDF5 for primary
- Stats/numbers: JetBrains Mono Bold, 36-48px for match score, 14-16px for stat values and minute markers, tabular-nums enabled

## Key Interactions
- **Goal event animation:** When a goal is scored, the score display briefly scales up (1.2x) with a gold flash, the event timeline scrolls to show the goal card with a slide-in animation, and a goal icon appears on the pitch visualization at the approximate position.
- **Event timeline scroll:** Timeline auto-scrolls to the latest event during live matches. Manual scroll pauses auto-scroll and shows a "Jump to latest" floating button. Half-time divider snaps into view at the break.
- **Pitch visualization tap:** Tapping a player dot on the pitch visualization shows a tooltip with player name, position, and key stats (goals, assists, cards). Tapping an event marker shows the event detail.
- **Stats comparison animation:** Stat bars animate from 0 to their current values when first loaded or when the stat category changes, over 500ms with ease-out easing.
- **Formation toggle:** Tapping the formation label toggles between showing formation dots on the pitch and an expanded player list grouped by position.
- **Live match pulse:** During live matches, the match minute display pulses with an emerald glow every second, and the "LIVE" badge has a continuous subtle pulse animation.

## Reference Screenshots
- [FotMob Match Center on Dribbble](https://dribbble.com/search/soccer-match-tracker) — Match center with pitch visualization, event timeline, and live stats in a dark green theme
- [BBC Sport Live Match Page on Behance](https://www.behance.net/search/projects?search=football+match+live+tracker) — Event timeline with minute markers, goal/card/sub event cards, and stats comparison bars
- [Opta Data Visualization on Mobbin](https://mobbin.com/search/football-match-stats) — Pitch-based data visualization with formations and event positioning
