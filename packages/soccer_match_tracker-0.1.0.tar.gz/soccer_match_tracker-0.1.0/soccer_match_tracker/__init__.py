"""
shipp-soccer: Live soccer match tracking for Premier League, La Liga, Champions League, and MLS.
"""
__version__ = "0.1.0"
