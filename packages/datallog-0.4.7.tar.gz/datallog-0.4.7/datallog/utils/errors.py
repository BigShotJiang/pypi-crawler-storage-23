class UnsupportedSeleniumDriverError(Exception):
    """Custom exception for unsupported Selenium driver types."""

    def __init__(self, driver_type: str):
        message = f"Unsupported driver type '{driver_type}'. Please choose 'chrome' or 'firefox'."
        super().__init__(message)
        self.driver_type = driver_type
        self.message = message


class UnableToDownloadSeleniumDriverError(Exception):
    """Custom exception for errors during driver download."""

    def __init__(self, driver_type: str, details: str):
        message = f"Failed to download {driver_type} driver. Details: {details}"
        super().__init__(message)
        self.driver_type = driver_type
        self.details = details
        self.message = message


class AutomationNameCannotBeEmptyError(Exception):
    """
    Exception raised when a automation name is empty
    """

    def __init__(self, message="Automation name cannot be empty"):
        self.message = message
        super().__init__(self.message)
class InvalidAutomationError(Exception):
    """
    
    """
class AutomationDecoratorCannotBeUsedTwiceError(Exception):
    """
    Exception raised when the @automation decorator is used more than once in a file.
    """

    def __init__(self, message="The @automation decorator can only be used once per automation file."):
        self.message = message
        super().__init__(self.message)



class AutomationNotDefinedError(Exception):
    """
    Exception raised when a automation is not defined
    """

    def __init__(self, message="Automation is not defined"):
        self.message = message
        super().__init__(self.message)


class CircularAutomationDefinitionError(Exception):
    """
    Exception raised when a automation is defined circularly
    """

    def __init__(self, message="Circular automation definition"):
        self.message = message
        super().__init__(self.message)
