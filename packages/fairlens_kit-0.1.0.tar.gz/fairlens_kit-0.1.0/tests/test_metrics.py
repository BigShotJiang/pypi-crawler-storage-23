"""
Tests for FairLens metrics module.
"""

import numpy as np
import pytest
from fairlens.metrics import (
    demographic_parity_ratio,
    demographic_parity_difference,
    equalized_odds_ratio,
    equalized_odds_difference,
    true_positive_rate,
    false_positive_rate,
)


class TestGroupFairnessMetrics:
    """Tests for group fairness metrics."""
    
    def setup_method(self):
        """Set up test data."""
        # Perfect fairness case - equal positive rates for both groups
        self.y_pred_fair = np.array([1, 1, 0, 0, 1, 1, 0, 0])
        self.protected_fair = np.array(['A', 'A', 'A', 'A', 'B', 'B', 'B', 'B'])
        
        # Unfair case - group A gets more positive predictions
        self.y_pred_unfair = np.array([1, 1, 1, 1, 0, 0, 0, 0])
        self.protected_unfair = np.array(['A', 'A', 'A', 'A', 'B', 'B', 'B', 'B'])
        
        # For equalized odds tests - need y_true
        self.y_true = np.array([1, 1, 0, 0, 1, 1, 0, 0])
    
    def test_demographic_parity_ratio_fair(self):
        """Test DP ratio with fair predictions."""
        ratio = demographic_parity_ratio(
            self.y_pred_fair, 
            self.protected_fair
        )
        assert ratio == 1.0, f"Expected 1.0, got {ratio}"
    
    def test_demographic_parity_ratio_unfair(self):
        """Test DP ratio with unfair predictions."""
        ratio = demographic_parity_ratio(
            self.y_pred_unfair, 
            self.protected_unfair
        )
        assert ratio == 0.0, f"Expected 0.0, got {ratio}"
    
    def test_demographic_parity_difference_fair(self):
        """Test DP difference with fair predictions."""
        diff = demographic_parity_difference(
            self.y_pred_fair, 
            self.protected_fair
        )
        assert diff == 0.0, f"Expected 0.0, got {diff}"
    
    def test_demographic_parity_difference_unfair(self):
        """Test DP difference with unfair predictions."""
        diff = demographic_parity_difference(
            self.y_pred_unfair, 
            self.protected_unfair
        )
        assert diff == 1.0, f"Expected 1.0, got {diff}"
    
    def test_true_positive_rate(self):
        """Test TPR calculation."""
        y_true = np.array([1, 1, 1, 0, 0])
        y_pred = np.array([1, 1, 0, 0, 0])
        tpr = true_positive_rate(y_true, y_pred)
        assert abs(tpr - 2/3) < 0.001, f"Expected 0.667, got {tpr}"
    
    def test_false_positive_rate(self):
        """Test FPR calculation."""
        y_true = np.array([0, 0, 0, 1, 1])
        y_pred = np.array([1, 0, 0, 1, 1])
        fpr = false_positive_rate(y_true, y_pred)
        assert abs(fpr - 1/3) < 0.001, f"Expected 0.333, got {fpr}"
    
    def test_equalized_odds_ratio_fair(self):
        """Test EO ratio with fair predictions."""
        ratio = equalized_odds_ratio(
            self.y_true, 
            self.y_pred_fair, 
            self.protected_fair
        )
        assert ratio == 1.0, f"Expected 1.0, got {ratio}"
    
    def test_equalized_odds_difference_fair(self):
        """Test EO difference with fair predictions."""
        diff = equalized_odds_difference(
            self.y_true, 
            self.y_pred_fair, 
            self.protected_fair
        )
        assert diff == 0.0, f"Expected 0.0, got {diff}"


class TestEdgeCases:
    """Tests for edge cases."""
    
    def test_single_group(self):
        """Test with only one group (should return 1.0 for ratio)."""
        y_pred = np.array([1, 1, 0, 0])
        protected = np.array(['A', 'A', 'A', 'A'])
        
        ratio = demographic_parity_ratio(y_pred, protected)
        assert ratio == 1.0
    
    def test_all_same_predictions(self):
        """Test when all predictions are the same."""
        y_pred = np.array([1, 1, 1, 1, 1, 1])  # All positive
        protected = np.array(['A', 'A', 'A', 'B', 'B', 'B'])
        
        ratio = demographic_parity_ratio(y_pred, protected)
        assert ratio == 1.0  # Both groups have 100% positive rate


class TestNumpyPandasCompatibility:
    """Test that metrics work with both numpy and pandas inputs."""
    
    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        import pandas as pd
        
        y_pred = pd.Series([1, 1, 0, 0, 1, 1, 0, 0])
        protected = pd.Series(['A', 'A', 'A', 'A', 'B', 'B', 'B', 'B'])
        
        ratio = demographic_parity_ratio(y_pred, protected)
        assert ratio == 1.0
    
    def test_mixed_input(self):
        """Test with mixed numpy and pandas input."""
        import pandas as pd
        
        y_pred = pd.Series([1, 1, 0, 0, 1, 1, 0, 0])
        protected = np.array(['A', 'A', 'A', 'A', 'B', 'B', 'B', 'B'])
        
        ratio = demographic_parity_ratio(y_pred, protected)
        assert ratio == 1.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
