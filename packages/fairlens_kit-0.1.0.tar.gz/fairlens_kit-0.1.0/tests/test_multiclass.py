"""
Tests for multi-class fairness metrics.
"""

import numpy as np
import pytest
from fairlens.metrics import (
    compute_multiclass_fairness,
    multiclass_demographic_parity,
    demographic_parity_ratio,
)


class TestComputeMulticlassFairness:
    """Tests for compute_multiclass_fairness."""

    def setup_method(self):
        """Set up 3-class test data with per-class disparity."""
        np.random.seed(42)
        n = 300
        self.protected = np.array(['A'] * (n // 2) + ['B'] * (n // 2))

        # 3 classes: 0, 1, 2
        self.y_true = np.random.choice([0, 1, 2], n)

        # Predictions: group A favors class 1, group B favors class 2
        preds_a = np.random.choice([0, 1, 2], n // 2, p=[0.2, 0.5, 0.3])
        preds_b = np.random.choice([0, 1, 2], n // 2, p=[0.2, 0.3, 0.5])
        self.y_pred = np.concatenate([preds_a, preds_b])

    def test_three_class_returns_report(self):
        """3-class problem should return report with 3 classes."""
        report = compute_multiclass_fairness(
            self.y_true, self.y_pred, self.protected
        )
        assert len(report.classes) == 3

    def test_per_class_metrics_present(self):
        """Each class should have GroupFairnessMetrics."""
        report = compute_multiclass_fairness(
            self.y_true, self.y_pred, self.protected
        )
        for cls in report.classes:
            assert cls in report.per_class_metrics
            m = report.per_class_metrics[cls]
            assert hasattr(m, 'demographic_parity_ratio')

    def test_worst_class_identified(self):
        """Worst class should have the lowest DP ratio."""
        report = compute_multiclass_fairness(
            self.y_true, self.y_pred, self.protected
        )
        # worst_dp_ratio should be the minimum
        all_dp = [
            report.per_class_metrics[c].demographic_parity_ratio
            for c in report.classes
        ]
        assert report.worst_dp_ratio == min(all_dp)

    def test_binary_input_matches_original(self):
        """With binary labels, should match standard binary metrics."""
        y_true_bin = np.array([1, 1, 0, 0, 1, 0, 0, 1] * 10)
        y_pred_bin = np.array([1, 0, 0, 0, 1, 1, 0, 1] * 10)
        protected = np.array(['A', 'A', 'A', 'A', 'B', 'B', 'B', 'B'] * 10)

        report = compute_multiclass_fairness(
            y_true_bin, y_pred_bin, protected
        )
        # For class 1, one-vs-rest should match binary DP ratio
        dp_class1 = report.per_class_metrics['1'].demographic_parity_ratio
        dp_binary = demographic_parity_ratio(y_pred_bin, protected)
        assert abs(dp_class1 - dp_binary) < 0.001

    def test_handles_string_labels(self):
        """Should work with string class labels."""
        y_true = np.array(['cat', 'dog', 'bird'] * 20)
        y_pred = np.array(['cat', 'dog', 'bird'] * 20)
        protected = np.array(['A', 'B'] * 30)

        report = compute_multiclass_fairness(y_true, y_pred, protected)
        assert 'bird' in report.classes
        assert 'cat' in report.classes
        assert 'dog' in report.classes

    def test_single_class_edge(self):
        """Single class should still produce a valid report."""
        y_true = np.array([0, 0, 0, 0])
        y_pred = np.array([0, 0, 0, 0])
        protected = np.array(['A', 'A', 'B', 'B'])

        report = compute_multiclass_fairness(y_true, y_pred, protected)
        assert len(report.classes) == 1

    def test_macro_average_in_range(self):
        """Macro average DP ratio should be between 0 and 1."""
        report = compute_multiclass_fairness(
            self.y_true, self.y_pred, self.protected
        )
        assert 0.0 <= report.macro_avg_dp_ratio <= 1.0

    def test_summary_readable(self):
        """Summary should contain key information."""
        report = compute_multiclass_fairness(
            self.y_true, self.y_pred, self.protected
        )
        summary = report.summary()
        assert "Multi-class" in summary
        assert report.worst_class in summary


class TestMulticlassDemographicParity:
    """Tests for multiclass_demographic_parity convenience function."""

    def test_returns_dict(self):
        """Should return a dict mapping class to DP ratio."""
        y_true = np.array([0, 1, 2] * 20)
        y_pred = np.array([0, 1, 2] * 20)
        protected = np.array(['A', 'B'] * 30)

        result = multiclass_demographic_parity(y_true, y_pred, protected)
        assert isinstance(result, dict)
        assert len(result) == 3


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
