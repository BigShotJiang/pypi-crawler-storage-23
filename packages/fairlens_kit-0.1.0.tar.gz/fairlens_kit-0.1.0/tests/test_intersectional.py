"""
Tests for intersectional fairness analysis.
"""

import numpy as np
import pytest
from fairlens.metrics import (
    create_intersection_groups,
    compute_intersectional_metrics,
)


class TestCreateIntersectionGroups:
    """Tests for create_intersection_groups."""

    def test_two_binary_attrs_produce_four_groups(self):
        """Two binary attributes should produce up to 4 intersection groups."""
        attrs = {
            'gender': np.array(['M', 'M', 'F', 'F']),
            'race': np.array(['W', 'B', 'W', 'B']),
        }
        groups = create_intersection_groups(attrs)
        unique = set(groups)
        assert len(unique) == 4

    def test_single_attr_passthrough(self):
        """Single attribute should produce groups matching the attribute."""
        attrs = {'gender': np.array(['M', 'F', 'M', 'F'])}
        groups = create_intersection_groups(attrs)
        assert set(groups) == {'gender_M', 'gender_F'} or set(groups) == {'M', 'F'}
        # With sorted keys and single attr, values match original
        np.testing.assert_array_equal(groups, np.array(['M', 'F', 'M', 'F']))

    def test_custom_separator(self):
        """Custom separator should join attribute values."""
        attrs = {
            'gender': np.array(['M', 'F']),
            'race': np.array(['W', 'B']),
        }
        groups = create_intersection_groups(attrs, separator="|")
        # Sorted keys: gender, race
        assert groups[0] == "M|W"
        assert groups[1] == "F|B"

    def test_mismatched_lengths_raises(self):
        """Different length arrays should raise ValueError."""
        attrs = {
            'gender': np.array(['M', 'F', 'M']),
            'race': np.array(['W', 'B']),
        }
        with pytest.raises(ValueError, match="same length"):
            create_intersection_groups(attrs)


class TestComputeIntersectionalMetrics:
    """Tests for compute_intersectional_metrics."""

    def setup_method(self):
        """Set up test data with intersectional bias."""
        np.random.seed(42)
        n = 100

        # 4 groups: M_W, M_B, F_W, F_B with different positive rates
        self.gender = np.array(['M'] * 50 + ['F'] * 50)
        self.race = np.array(
            ['W'] * 25 + ['B'] * 25 + ['W'] * 25 + ['B'] * 25
        )
        self.y_true = np.random.choice([0, 1], n)

        # M_W: high positive rate, F_B: low positive rate
        self.y_pred = np.zeros(n, dtype=int)
        self.y_pred[:25] = np.random.choice([0, 1], 25, p=[0.2, 0.8])  # M_W
        self.y_pred[25:50] = np.random.choice([0, 1], 25, p=[0.4, 0.6])  # M_B
        self.y_pred[50:75] = np.random.choice([0, 1], 25, p=[0.5, 0.5])  # F_W
        self.y_pred[75:] = np.random.choice([0, 1], 25, p=[0.8, 0.2])   # F_B

    def test_returns_report(self):
        """Should return IntersectionalFairnessReport."""
        attrs = {'gender': self.gender, 'race': self.race}
        report = compute_intersectional_metrics(
            self.y_true, self.y_pred, attrs
        )
        assert hasattr(report, 'intersection_groups')
        assert hasattr(report, 'demographic_parity_ratio')
        assert hasattr(report, 'per_attribute_dp_ratio')

    def test_more_groups_than_single_attr(self):
        """Intersection should produce more groups than any single attribute."""
        attrs = {'gender': self.gender, 'race': self.race}
        report = compute_intersectional_metrics(
            self.y_true, self.y_pred, attrs
        )
        n_gender = len(set(self.gender))
        n_race = len(set(self.race))
        assert len(report.intersection_groups) > n_gender
        assert len(report.intersection_groups) > n_race

    def test_summary_contains_all_groups(self):
        """Summary should mention all intersection groups."""
        attrs = {'gender': self.gender, 'race': self.race}
        report = compute_intersectional_metrics(
            self.y_true, self.y_pred, attrs
        )
        summary = report.summary()
        for group in report.intersection_groups:
            assert group in summary

    def test_per_attribute_comparison_included(self):
        """Report should include per-attribute DP ratios."""
        attrs = {'gender': self.gender, 'race': self.race}
        report = compute_intersectional_metrics(
            self.y_true, self.y_pred, attrs
        )
        assert 'gender' in report.per_attribute_dp_ratio
        assert 'race' in report.per_attribute_dp_ratio
        # Each should be a valid ratio
        for ratio in report.per_attribute_dp_ratio.values():
            assert 0.0 <= ratio <= 1.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
