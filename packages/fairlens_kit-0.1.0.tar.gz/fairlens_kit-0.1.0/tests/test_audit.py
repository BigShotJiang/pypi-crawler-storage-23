"""
Tests for FairLens audit module.
"""

import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import LogisticRegression

from fairlens.audit import ModelAuditor, audit_model, AuditResult, FairnessThresholds


class TestModelAuditor:
    """Tests for ModelAuditor class."""
    
    def setup_method(self):
        """Set up test model and data."""
        np.random.seed(42)
        n = 500
        
        # Create simple dataset
        self.X = pd.DataFrame({
            'feature1': np.random.randn(n),
            'feature2': np.random.randn(n),
        })
        self.y = (self.X['feature1'] + self.X['feature2'] > 0).astype(int)
        self.protected = pd.Series(np.random.choice(['A', 'B'], n))
        
        # Train a simple model
        self.model = LogisticRegression(random_state=42)
        self.model.fit(self.X, self.y)
    
    def test_auditor_initialization(self):
        """Test ModelAuditor initialization."""
        auditor = ModelAuditor()
        assert auditor is not None
        assert auditor.thresholds is not None
    
    def test_auditor_with_custom_thresholds(self):
        """Test ModelAuditor with custom thresholds."""
        thresholds = FairnessThresholds(
            demographic_parity_ratio=0.9,
            equalized_odds_difference=0.05
        )
        auditor = ModelAuditor(thresholds=thresholds)
        
        assert auditor.thresholds.demographic_parity_ratio == 0.9
        assert auditor.thresholds.equalized_odds_difference == 0.05
    
    def test_audit_returns_result(self):
        """Test that audit returns AuditResult."""
        auditor = ModelAuditor()
        result = auditor.audit(
            model=self.model,
            X=self.X,
            y=self.y,
            protected_attribute=self.protected
        )
        
        assert isinstance(result, AuditResult)
        assert hasattr(result, 'group_fairness')
        assert hasattr(result, 'is_fair')
        assert hasattr(result, 'fairness_issues')
    
    def test_audit_model_convenience(self):
        """Test audit_model convenience function."""
        result = audit_model(
            model=self.model,
            X=self.X,
            y=self.y,
            protected=self.protected
        )
        
        assert isinstance(result, AuditResult)
    
    def test_audit_result_str(self):
        """Test AuditResult string representation."""
        result = audit_model(
            model=self.model,
            X=self.X,
            y=self.y,
            protected=self.protected
        )
        
        result_str = str(result)
        assert "FAIRNESS AUDIT" in result_str or "fairness" in result_str.lower()
    
    def test_audit_with_probabilities(self):
        """Test audit with probability predictions."""
        result = audit_model(
            model=self.model,
            X=self.X,
            y=self.y,
            protected=self.protected
        )
        
        # Model has predict_proba, so calibration should be computed
        assert result is not None
        assert result.calibration is not None


class TestFairnessThresholds:
    """Tests for FairnessThresholds."""
    
    def test_default_thresholds(self):
        """Test default threshold values."""
        thresholds = FairnessThresholds()
        
        assert thresholds.demographic_parity_ratio == 0.8
        assert thresholds.equalized_odds_difference == 0.1
    
    def test_custom_thresholds(self):
        """Test custom threshold values."""
        thresholds = FairnessThresholds(
            demographic_parity_ratio=0.9,
            equalized_odds_difference=0.05
        )
        
        assert thresholds.demographic_parity_ratio == 0.9
        assert thresholds.equalized_odds_difference == 0.05


class TestReportGeneration:
    """Tests for report generation."""
    
    def setup_method(self):
        """Set up test data."""
        np.random.seed(42)
        n = 200
        
        X = pd.DataFrame({
            'feature1': np.random.randn(n),
            'feature2': np.random.randn(n),
        })
        y = (X['feature1'] > 0).astype(int)
        protected = pd.Series(np.random.choice(['A', 'B'], n))
        
        model = LogisticRegression(random_state=42)
        model.fit(X, y)
        
        self.result = audit_model(model, X, y, protected)
    
    def test_json_report(self):
        """Test JSON report generation."""
        from fairlens.audit import generate_json_report
        import tempfile
        import json
        
        with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
            generate_json_report(self.result, f.name)
            
            with open(f.name, 'r') as rf:
                data = json.load(rf)
            
            assert 'model_name' in data or 'is_fair' in data
    
    def test_markdown_report(self):
        """Test Markdown report generation."""
        from fairlens.audit import generate_markdown_report
        import tempfile
        
        with tempfile.NamedTemporaryFile(suffix='.md', delete=False) as f:
            generate_markdown_report(self.result, f.name)
            
            with open(f.name, 'r') as rf:
                content = rf.read()
            
            assert 'Fairness' in content or 'fairness' in content


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
