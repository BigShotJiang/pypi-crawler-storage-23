"""
Tests for FairLens mitigation algorithms.
"""

import numpy as np
import pytest
from fairlens.mitigation import ThresholdOptimizer, Reweighter


class TestThresholdOptimizer:
    """Tests for ThresholdOptimizer."""

    def setup_method(self):
        """Set up test data with clear group disparity."""
        np.random.seed(42)
        n = 400

        # Group A gets higher probabilities than group B
        self.protected = np.array(['A'] * (n // 2) + ['B'] * (n // 2))
        probs_a = np.clip(np.random.normal(0.7, 0.15, n // 2), 0, 1)
        probs_b = np.clip(np.random.normal(0.3, 0.15, n // 2), 0, 1)
        self.y_prob = np.concatenate([probs_a, probs_b])
        self.y_true = (self.y_prob > 0.5).astype(int)

    def test_fit_stores_thresholds(self):
        """Fit should store per-group thresholds."""
        opt = ThresholdOptimizer()
        opt.fit(self.y_true, self.y_prob, self.protected)
        result = opt.get_results()
        assert 'A' in result.thresholds
        assert 'B' in result.thresholds

    def test_predict_reduces_disparity(self):
        """Fair predictions should have smaller DP gap than raw 0.5 threshold."""
        opt = ThresholdOptimizer()
        opt.fit(self.y_true, self.y_prob, self.protected)
        fair_preds = opt.predict(self.y_prob, self.protected)

        # Rates with naive threshold
        rate_a_naive = np.mean(self.y_prob[self.protected == 'A'] >= 0.5)
        rate_b_naive = np.mean(self.y_prob[self.protected == 'B'] >= 0.5)
        gap_naive = abs(rate_a_naive - rate_b_naive)

        # Rates with fair threshold
        rate_a_fair = np.mean(fair_preds[self.protected == 'A'])
        rate_b_fair = np.mean(fair_preds[self.protected == 'B'])
        gap_fair = abs(rate_a_fair - rate_b_fair)

        assert gap_fair < gap_naive, (
            f"Fair gap {gap_fair:.3f} should be less than naive gap {gap_naive:.3f}"
        )

    def test_predict_returns_binary(self):
        """Predictions should be 0 or 1."""
        opt = ThresholdOptimizer()
        opt.fit(self.y_true, self.y_prob, self.protected)
        preds = opt.predict(self.y_prob, self.protected)
        assert set(np.unique(preds)).issubset({0, 1})

    def test_predict_before_fit_raises(self):
        """Calling predict before fit should raise RuntimeError."""
        opt = ThresholdOptimizer()
        with pytest.raises(RuntimeError):
            opt.predict(self.y_prob, self.protected)

    def test_get_results(self):
        """get_results should return ThresholdOptimizerResult with summary."""
        opt = ThresholdOptimizer()
        opt.fit(self.y_true, self.y_prob, self.protected)
        result = opt.get_results()
        assert result.objective == 'demographic_parity'
        assert result.demographic_parity_after >= result.demographic_parity_before
        summary = result.summary()
        assert "Threshold Optimizer" in summary


class TestReweighter:
    """Tests for Reweighter."""

    def setup_method(self):
        """Set up test data with label imbalance across groups."""
        np.random.seed(42)
        # Group A: 80% positive, Group B: 30% positive
        n = 200
        self.protected = np.array(['A'] * n + ['B'] * n)
        y_a = np.random.choice([0, 1], n, p=[0.2, 0.8])
        y_b = np.random.choice([0, 1], n, p=[0.7, 0.3])
        self.y_true = np.concatenate([y_a, y_b])

    def test_fit_stores_weights(self):
        """Fit should store weight map."""
        rw = Reweighter()
        rw.fit(self.y_true, self.protected)
        result = rw.get_results()
        assert 'A' in result.group_weights
        assert 'B' in result.group_weights

    def test_transform_correct_length(self):
        """Transform should return one weight per sample."""
        rw = Reweighter()
        rw.fit(self.y_true, self.protected)
        weights = rw.transform(self.y_true, self.protected)
        assert len(weights) == len(self.y_true)

    def test_weights_positive(self):
        """All weights should be positive."""
        rw = Reweighter()
        rw.fit(self.y_true, self.protected)
        weights = rw.transform(self.y_true, self.protected)
        assert np.all(weights > 0)

    def test_weighted_rates_equalize(self):
        """Weighted label rates should be closer across groups."""
        rw = Reweighter()
        rw.fit(self.y_true, self.protected)
        weights = rw.transform(self.y_true, self.protected)

        # Unweighted rates
        rate_a = np.mean(self.y_true[self.protected == 'A'])
        rate_b = np.mean(self.y_true[self.protected == 'B'])
        gap_before = abs(rate_a - rate_b)

        # Weighted rates
        mask_a = self.protected == 'A'
        mask_b = self.protected == 'B'
        w_rate_a = np.average(self.y_true[mask_a], weights=weights[mask_a])
        w_rate_b = np.average(self.y_true[mask_b], weights=weights[mask_b])
        gap_after = abs(w_rate_a - w_rate_b)

        assert gap_after < gap_before, (
            f"Weighted gap {gap_after:.3f} should be less than unweighted {gap_before:.3f}"
        )

    def test_fit_transform_matches(self):
        """fit_transform should give same result as fit + transform."""
        rw1 = Reweighter()
        rw1.fit(self.y_true, self.protected)
        w1 = rw1.transform(self.y_true, self.protected)

        rw2 = Reweighter()
        w2 = rw2.fit_transform(self.y_true, self.protected)

        np.testing.assert_array_almost_equal(w1, w2)

    def test_get_results(self):
        """get_results should return ReweighterResult with summary."""
        rw = Reweighter()
        rw.fit(self.y_true, self.protected)
        result = rw.get_results()
        assert 'A' in result.group_sizes
        summary = result.summary()
        assert "Reweighter" in summary


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
