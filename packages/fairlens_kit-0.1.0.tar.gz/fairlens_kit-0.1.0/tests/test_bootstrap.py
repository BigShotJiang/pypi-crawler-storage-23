"""
Tests for bootstrap confidence intervals.
"""

import numpy as np
import pytest
from fairlens.metrics import (
    bootstrap_metric,
    ConfidenceInterval,
    demographic_parity_ratio,
    expected_calibration_error,
)


class TestBootstrapMetric:
    """Tests for bootstrap_metric."""

    def setup_method(self):
        """Set up test data with slight disparity (not at boundary)."""
        np.random.seed(42)
        # Group A: 60% positive, Group B: 50% positive -> DP ratio ~0.83
        self.y_pred = np.array(
            [1, 1, 1, 0, 0] * 20 +   # A: 60%
            [1, 0, 1, 0, 0] * 20      # B: 40%
        )
        self.protected = np.array(['A'] * 100 + ['B'] * 100)
        self.y_true = np.random.choice([0, 1], len(self.y_pred))
        self.y_prob = np.random.uniform(0, 1, len(self.y_pred))

    def test_returns_confidence_interval(self):
        """Should return a ConfidenceInterval dataclass."""
        ci = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=100,
            random_state=42,
        )
        assert isinstance(ci, ConfidenceInterval)

    def test_lower_le_estimate_le_upper(self):
        """Lower bound should be <= estimate <= upper bound."""
        ci = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=500,
            random_state=42,
        )
        assert ci.lower <= ci.estimate <= ci.upper

    def test_wider_ci_with_fewer_samples(self):
        """Smaller dataset should give wider confidence interval."""
        # Large sample
        ci_large = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=500,
            random_state=42,
        )

        # Small sample: 5 from A, 5 from B (indices that cross boundary)
        small_pred = np.array([1, 1, 1, 0, 0, 1, 0, 0, 0, 0])
        small_prot = np.array(['A', 'A', 'A', 'A', 'A', 'B', 'B', 'B', 'B', 'B'])
        ci_small = bootstrap_metric(
            demographic_parity_ratio,
            small_pred, small_prot,
            n_bootstrap=500,
            random_state=42,
        )

        width_large = ci_large.upper - ci_large.lower
        width_small = ci_small.upper - ci_small.lower
        assert width_small > width_large, (
            f"Small sample CI width {width_small:.3f} should exceed "
            f"large sample CI width {width_large:.3f}"
        )

    def test_reproducible_with_random_state(self):
        """Same random_state should give identical results."""
        ci1 = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=200,
            random_state=123,
        )
        ci2 = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=200,
            random_state=123,
        )
        assert ci1.lower == ci2.lower
        assert ci1.upper == ci2.upper
        assert ci1.std_error == ci2.std_error

    def test_works_with_dp_ratio(self):
        """Should work with demographic_parity_ratio."""
        ci = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=100,
            random_state=42,
        )
        assert 0.0 <= ci.estimate <= 1.0

    def test_works_with_ece(self):
        """Should work with expected_calibration_error."""
        ci = bootstrap_metric(
            expected_calibration_error,
            self.y_true, self.y_prob,
            n_bootstrap=100,
            random_state=42,
        )
        assert ci.estimate >= 0.0

    def test_contains_method(self):
        """contains() should return True for values inside interval."""
        ci = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=200,
            random_state=42,
        )
        assert ci.contains(ci.estimate)
        # A value far outside should not be contained
        assert not ci.contains(ci.upper + 100)

    def test_custom_confidence_level(self):
        """Narrower confidence level should give narrower interval."""
        ci_95 = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=500,
            confidence_level=0.95,
            random_state=42,
        )
        ci_80 = bootstrap_metric(
            demographic_parity_ratio,
            self.y_pred, self.protected,
            n_bootstrap=500,
            confidence_level=0.80,
            random_state=42,
        )
        width_95 = ci_95.upper - ci_95.lower
        width_80 = ci_80.upper - ci_80.lower
        assert width_80 <= width_95


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
