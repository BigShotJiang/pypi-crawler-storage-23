"""
Tests for FairLens datasets module.
"""

import numpy as np
import pandas as pd
import pytest
from fairlens.datasets import (
    load_adult,
    load_compas,
    load_german_credit,
    load_bank_marketing,
    FairnessDataset,
)
from fairlens.datasets.analyzer import DatasetAnalyzer, check_dataset


class TestDatasetLoaders:
    """Tests for dataset loading functions."""
    
    def test_load_adult(self):
        """Test Adult dataset loader."""
        dataset = load_adult()
        
        assert isinstance(dataset, FairnessDataset)
        assert dataset.name == "Adult Census Income"
        assert isinstance(dataset.data, pd.DataFrame)
        assert len(dataset.data) > 0
        assert dataset.target in dataset.data.columns
        assert len(dataset.protected_attributes) > 0
    
    def test_load_compas(self):
        """Test COMPAS dataset loader."""
        dataset = load_compas()
        
        assert isinstance(dataset, FairnessDataset)
        assert dataset.name == "COMPAS Recidivism"
        assert isinstance(dataset.data, pd.DataFrame)
        assert len(dataset.data) > 0
        assert dataset.target in dataset.data.columns
    
    def test_load_german_credit(self):
        """Test German Credit dataset loader."""
        dataset = load_german_credit()
        
        assert isinstance(dataset, FairnessDataset)
        assert dataset.name == "German Credit"
        assert isinstance(dataset.data, pd.DataFrame)
        assert len(dataset.data) > 0
    
    def test_load_bank_marketing(self):
        """Test Bank Marketing dataset loader."""
        dataset = load_bank_marketing()
        
        assert isinstance(dataset, FairnessDataset)
        assert dataset.name == "Bank Marketing"
        assert isinstance(dataset.data, pd.DataFrame)
        assert len(dataset.data) > 0
    
    def test_dataset_has_protected_attributes(self):
        """Test that datasets have valid protected attributes."""
        for loader in [load_adult, load_compas, load_german_credit, load_bank_marketing]:
            dataset = loader()
            
            for attr in dataset.protected_attributes:
                assert attr in dataset.data.columns, \
                    f"Protected attribute '{attr}' not found in {dataset.name}"
    
    def test_dataset_target_is_binary(self):
        """Test that target variables are binary."""
        for loader in [load_adult, load_compas, load_german_credit, load_bank_marketing]:
            dataset = loader()
            target = dataset.data[dataset.target]
            
            unique_values = target.unique()
            assert len(unique_values) == 2, \
                f"Target in {dataset.name} should be binary, got {len(unique_values)} unique values"
    
    def test_dataset_aliases(self):
        """Test that target_name and protected_attribute_names work."""
        dataset = load_adult()
        
        assert dataset.target_name == dataset.target
        assert dataset.protected_attribute_names == dataset.protected_attributes


class TestDatasetAnalyzer:
    """Tests for DatasetAnalyzer class."""
    
    def setup_method(self):
        """Set up test data."""
        np.random.seed(42)
        n = 1000
        
        self.test_data = pd.DataFrame({
            'feature1': np.random.randn(n),
            'feature2': np.random.randn(n),
            'gender': np.random.choice(['M', 'F'], n),
            'race': np.random.choice(['white', 'black', 'asian'], n),
            'target': np.random.choice([0, 1], n),
        })
    
    def test_analyzer_initialization(self):
        """Test DatasetAnalyzer initialization."""
        analyzer = DatasetAnalyzer(
            data=self.test_data,
            target='target',
            protected_attributes=['gender', 'race']
        )
        
        assert analyzer.data is not None
        assert analyzer.target == 'target'
        assert 'gender' in analyzer.protected_attributes
    
    def test_analyzer_analyze(self):
        """Test analysis method."""
        analyzer = DatasetAnalyzer(
            data=self.test_data,
            target='target',
            protected_attributes=['gender']
        )
        
        report = analyzer.analyze()
        
        assert report is not None
        assert hasattr(report, 'group_sizes')
        assert hasattr(report, 'label_rates_by_group')
    
    def test_check_dataset_convenience(self):
        """Test check_dataset convenience function."""
        report = check_dataset(
            data=self.test_data,
            target='target',
            protected=['gender']
        )
        
        assert report is not None


class TestPreprocessing:
    """Tests for preprocessing utilities."""
    
    def test_encode_categorical(self):
        """Test categorical encoding."""
        from fairlens.datasets import encode_categorical
        
        df = pd.DataFrame({
            'numeric': [1.0, 2.0, 3.0],
            'categorical': ['a', 'b', 'c']
        })
        
        encoded, encodings = encode_categorical(df)
        
        # Should return a tuple
        assert isinstance(encoded, pd.DataFrame)
        assert isinstance(encodings, dict)
        # Categorical should be encoded
        assert encoded['categorical'].dtype in [np.int64, np.int32, np.float64, object]
    
    def test_balance_dataset(self):
        """Test dataset balancing."""
        from fairlens.datasets import balance_dataset
        
        # Create imbalanced dataset
        df = pd.DataFrame({
            'feature': range(100),
            'target': [0] * 90 + [1] * 10,
            'group': ['A'] * 50 + ['B'] * 50
        })
        
        balanced = balance_dataset(df, 'target', 'group')
        
        # Should have more balanced classes
        assert isinstance(balanced, pd.DataFrame)


class TestFairnessDataset:
    """Tests for FairnessDataset dataclass."""
    
    def test_dataset_structure(self):
        """Test FairnessDataset structure."""
        data = pd.DataFrame({'a': [1, 2], 'target': [0, 1]})
        
        dataset = FairnessDataset(
            data=data,
            target='target',
            protected_attributes=['a'],
            feature_names=['a'],
            description='Test dataset',
            source='test',
            name='Test'
        )
        
        assert dataset.name == 'Test'
        assert dataset.target == 'target'
        assert len(dataset.protected_attributes) == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
