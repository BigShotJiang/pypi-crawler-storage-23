"""
Tests for real-world dataset fetchers.

Network-dependent tests are marked with @pytest.mark.skipif to handle
offline environments gracefully.
"""

import numpy as np
import pytest
import os
from unittest.mock import patch
from fairlens.datasets import FairnessDataset
from fairlens.datasets.fetchers import (
    fetch_adult,
    fetch_german_credit,
    fetch_compas,
    fetch_dataset,
)


# Check if network is available (sklearn + OpenML reachable)
def _has_network():
    try:
        import urllib.request
        urllib.request.urlopen("https://www.openml.org", timeout=3)
        return True
    except Exception:
        return False


_NETWORK = _has_network()


class TestFetchAdult:
    """Tests for fetch_adult."""

    @pytest.mark.skipif(not _NETWORK, reason="No network access")
    def test_fetch_adult_returns_dataset(self):
        """fetch_adult should return FairnessDataset."""
        dataset = fetch_adult(cache=False)
        assert isinstance(dataset, FairnessDataset)
        assert len(dataset.data) > 0

    @pytest.mark.skipif(not _NETWORK, reason="No network access")
    def test_fetch_adult_has_protected(self):
        """Fetched Adult should have sex and/or race as protected."""
        dataset = fetch_adult(cache=False)
        assert len(dataset.protected_attributes) > 0

    def test_fetch_adult_fallback(self):
        """Should fall back to synthetic on network error."""
        with patch('sklearn.datasets.fetch_openml', side_effect=Exception("no net")):
            dataset = fetch_adult(cache=False)
            assert isinstance(dataset, FairnessDataset)
            assert len(dataset.data) > 0


class TestFetchDatasetRegistry:
    """Tests for fetch_dataset registry."""

    def test_unknown_dataset_raises(self):
        """Unknown name should raise ValueError."""
        with pytest.raises(ValueError, match="Unknown dataset"):
            fetch_dataset("nonexistent")

    def test_registry_has_adult(self):
        """Registry should include 'adult'."""
        # Verify fallback works even without network
        with patch('sklearn.datasets.fetch_openml', side_effect=Exception("no net")):
            dataset = fetch_dataset("adult", cache=False)
            assert isinstance(dataset, FairnessDataset)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
