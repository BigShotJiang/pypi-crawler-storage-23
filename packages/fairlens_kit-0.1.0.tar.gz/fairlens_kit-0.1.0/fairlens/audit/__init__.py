"""
FairLens audit module.

Provides model fairness auditing and report generation.
"""

from .model_audit import (
    ModelAuditor,
    AuditResult,
    FairnessThresholds,
    audit_model,
)

from .report import (
    generate_html_report,
    generate_json_report,
    generate_markdown_report,
)


__all__ = [
    "ModelAuditor",
    "AuditResult",
    "FairnessThresholds",
    "audit_model",
    "generate_html_report",
    "generate_json_report",
    "generate_markdown_report",
]
