"""
Report generation for fairness audits.

Generates HTML and text reports from audit results.
"""

import json
from typing import Optional
from datetime import datetime

from .model_audit import AuditResult


def generate_html_report(
    audit_result: AuditResult,
    output_path: Optional[str] = None,
    include_recommendations: bool = True,
) -> str:
    """Generate an HTML fairness report.
    
    Parameters
    ----------
    audit_result : AuditResult
        Results from model audit
    output_path : str, optional
        Path to save HTML file
    include_recommendations : bool
        Whether to include recommendations section
        
    Returns
    -------
    str
        HTML content
    """
    gf = audit_result.group_fairness
    cal = audit_result.calibration
    
    # Status badge
    status_class = "fair" if audit_result.is_fair else "unfair"
    status_text = "✅ FAIR" if audit_result.is_fair else "⚠️ UNFAIR"
    
    # Build metrics table
    metrics_rows = ""
    if gf:
        metrics = [
            ("Demographic Parity Ratio", gf.demographic_parity_ratio, "≥ 0.8", gf.demographic_parity_ratio >= 0.8),
            ("Demographic Parity Difference", gf.demographic_parity_difference, "≤ 0.1", gf.demographic_parity_difference <= 0.1),
            ("Equalized Odds Ratio", gf.equalized_odds_ratio, "≥ 0.8", gf.equalized_odds_ratio >= 0.8),
            ("Equalized Odds Difference", gf.equalized_odds_difference, "≤ 0.1", gf.equalized_odds_difference <= 0.1),
        ]
        
        for name, value, threshold, is_ok in metrics:
            status = "✅" if is_ok else "❌"
            row_class = "ok" if is_ok else "fail"
            metrics_rows += f"""
            <tr class="{row_class}">
                <td>{name}</td>
                <td>{value:.4f}</td>
                <td>{threshold}</td>
                <td>{status}</td>
            </tr>
            """
    
    # Group rates table
    group_rows = ""
    if gf:
        for group in audit_result.groups:
            pos_rate = gf.positive_rate_by_group.get(group, 0)
            tpr = gf.tpr_by_group.get(group, 0)
            fpr = gf.fpr_by_group.get(group, 0)
            size = gf.group_sizes.get(group, 0)
            group_rows += f"""
            <tr>
                <td>{group}</td>
                <td>{size:,}</td>
                <td>{pos_rate:.1%}</td>
                <td>{tpr:.1%}</td>
                <td>{fpr:.1%}</td>
            </tr>
            """
    
    # Issues list
    issues_html = ""
    if audit_result.fairness_issues:
        issues_html = "<ul>" + "".join(
            f"<li>{issue}</li>" for issue in audit_result.fairness_issues
        ) + "</ul>"
    else:
        issues_html = "<p>No fairness issues detected.</p>"
    
    # Recommendations
    recs_html = ""
    if include_recommendations and audit_result.recommendations:
        recs_html = "<ul>" + "".join(
            f"<li>{rec}</li>" for rec in audit_result.recommendations
        ) + "</ul>"
    
    html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fairness Audit Report - {audit_result.model_name}</title>
    <style>
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 900px;
            margin: 0 auto;
            padding: 2rem;
            background: #f5f5f5;
        }}
        .report {{
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 2rem;
        }}
        h1 {{
            color: #1a1a2e;
            border-bottom: 2px solid #eee;
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
        }}
        h2 {{
            color: #16213e;
            margin-top: 2rem;
            margin-bottom: 1rem;
        }}
        .status {{
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            font-weight: bold;
            font-size: 1.2rem;
        }}
        .status.fair {{
            background: #d4edda;
            color: #155724;
        }}
        .status.unfair {{
            background: #f8d7da;
            color: #721c24;
        }}
        .meta {{
            color: #666;
            margin: 1rem 0;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
        }}
        th, td {{
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }}
        th {{
            background: #f8f9fa;
            font-weight: 600;
        }}
        tr.fail {{
            background: #fff5f5;
        }}
        tr.ok {{
            background: #f0fff4;
        }}
        .issues {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 4px;
            padding: 1rem;
            margin: 1rem 0;
        }}
        .recommendations {{
            background: #e7f5ff;
            border: 1px solid #339af0;
            border-radius: 4px;
            padding: 1rem;
            margin: 1rem 0;
        }}
        ul {{
            margin-left: 1.5rem;
        }}
        li {{
            margin: 0.5rem 0;
        }}
        .footer {{
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
            color: #666;
            font-size: 0.9rem;
        }}
    </style>
</head>
<body>
    <div class="report">
        <h1>🔍 Fairness Audit Report</h1>
        
        <div class="status {status_class}">{status_text}</div>
        
        <div class="meta">
            <p><strong>Model:</strong> {audit_result.model_name}</p>
            <p><strong>Protected Attribute:</strong> {audit_result.protected_attribute}</p>
            <p><strong>Groups:</strong> {', '.join(audit_result.groups)}</p>
            <p><strong>Samples:</strong> {audit_result.n_samples:,}</p>
            <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>
        
        <h2>📊 Fairness Metrics</h2>
        <table>
            <thead>
                <tr>
                    <th>Metric</th>
                    <th>Value</th>
                    <th>Threshold</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                {metrics_rows}
            </tbody>
        </table>
        
        <h2>👥 Group Performance</h2>
        <table>
            <thead>
                <tr>
                    <th>Group</th>
                    <th>Size</th>
                    <th>Positive Rate</th>
                    <th>True Positive Rate</th>
                    <th>False Positive Rate</th>
                </tr>
            </thead>
            <tbody>
                {group_rows}
            </tbody>
        </table>
        
        <h2>⚠️ Issues</h2>
        <div class="issues">
            {issues_html}
        </div>
        
        <h2>💡 Recommendations</h2>
        <div class="recommendations">
            {recs_html}
        </div>
        
        <div class="footer">
            <p>Generated by <strong>FairLens</strong> - ML Bias Detection Toolkit</p>
            <p>Learn more at <a href="https://github.com/IIIDman/fairlens">github.com/IIIDman/fairlens</a></p>
        </div>
    </div>
</body>
</html>
    """
    
    if output_path:
        with open(output_path, 'w') as f:
            f.write(html)
    
    return html


def generate_json_report(
    audit_result: AuditResult,
    output_path: Optional[str] = None,
) -> str:
    """Generate JSON fairness report.
    
    Parameters
    ----------
    audit_result : AuditResult
        Results from model audit
    output_path : str, optional
        Path to save JSON file
        
    Returns
    -------
    str
        JSON content
    """
    data = audit_result.to_dict()
    data['generated_at'] = datetime.now().isoformat()
    
    json_str = json.dumps(data, indent=2)
    
    if output_path:
        with open(output_path, 'w') as f:
            f.write(json_str)
    
    return json_str


def generate_markdown_report(
    audit_result: AuditResult,
    output_path: Optional[str] = None,
) -> str:
    """Generate Markdown fairness report.
    
    Parameters
    ----------
    audit_result : AuditResult
        Results from model audit
    output_path : str, optional
        Path to save Markdown file
        
    Returns
    -------
    str
        Markdown content
    """
    gf = audit_result.group_fairness
    
    status = "✅ FAIR" if audit_result.is_fair else "⚠️ UNFAIR"
    
    md = f"""# Fairness Audit Report

**Status:** {status}

## Overview

| Property | Value |
|----------|-------|
| Model | {audit_result.model_name} |
| Protected Attribute | {audit_result.protected_attribute} |
| Groups | {', '.join(audit_result.groups)} |
| Samples | {audit_result.n_samples:,} |

## Fairness Metrics

| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
"""
    
    if gf:
        metrics = [
            ("Demographic Parity Ratio", gf.demographic_parity_ratio, "≥ 0.8", gf.demographic_parity_ratio >= 0.8),
            ("Equalized Odds Ratio", gf.equalized_odds_ratio, "≥ 0.8", gf.equalized_odds_ratio >= 0.8),
        ]
        
        for name, value, threshold, is_ok in metrics:
            status = "✅" if is_ok else "❌"
            md += f"| {name} | {value:.4f} | {threshold} | {status} |\n"
    
    md += "\n## Group Performance\n\n"
    md += "| Group | Size | Positive Rate | TPR | FPR |\n"
    md += "|-------|------|---------------|-----|-----|\n"
    
    if gf:
        for group in audit_result.groups:
            pos_rate = gf.positive_rate_by_group.get(group, 0)
            tpr = gf.tpr_by_group.get(group, 0)
            fpr = gf.fpr_by_group.get(group, 0)
            size = gf.group_sizes.get(group, 0)
            md += f"| {group} | {size:,} | {pos_rate:.1%} | {tpr:.1%} | {fpr:.1%} |\n"
    
    if audit_result.fairness_issues:
        md += "\n## ⚠️ Issues\n\n"
        for issue in audit_result.fairness_issues:
            md += f"- {issue}\n"
    
    if audit_result.recommendations:
        md += "\n## 💡 Recommendations\n\n"
        for rec in audit_result.recommendations:
            md += f"- {rec}\n"
    
    md += f"\n---\n*Generated by FairLens on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n"
    
    if output_path:
        with open(output_path, 'w') as f:
            f.write(md)
    
    return md
