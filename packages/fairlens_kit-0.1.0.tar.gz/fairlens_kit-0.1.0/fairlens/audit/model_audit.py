"""
Model fairness auditing.

Provides fairness audits for ML models:
- Automatic metric computation
- Threshold-based fairness checks
- Detailed reporting
- Actionable recommendations
"""

import numpy as np
import pandas as pd
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, field

from ..metrics.group_fairness import (
    compute_group_fairness_metrics,
    GroupFairnessMetrics,
)
from ..metrics.calibration import (
    compute_calibration_metrics,
    CalibrationMetrics,
)


@dataclass
class FairnessThresholds:
    """Thresholds for fairness assessment."""
    demographic_parity_ratio: float = 0.8
    equalized_odds_ratio: float = 0.8
    demographic_parity_difference: float = 0.1
    equalized_odds_difference: float = 0.1
    calibration_error: float = 0.1
    
    def is_fair(
        self,
        metric_name: str,
        value: float
    ) -> bool:
        """Check if metric value meets fairness threshold."""
        if metric_name in ['demographic_parity_ratio', 'equalized_odds_ratio']:
            threshold = getattr(self, metric_name)
            return value >= threshold
        elif metric_name in ['demographic_parity_difference', 'equalized_odds_difference']:
            threshold = getattr(self, metric_name)
            return value <= threshold
        elif metric_name == 'calibration_error':
            return value <= self.calibration_error
        return True


@dataclass 
class AuditResult:
    """Complete fairness audit results."""
    model_name: str
    protected_attribute: str
    n_samples: int
    groups: List[str]
    
    # Metrics
    group_fairness: GroupFairnessMetrics = None
    calibration: CalibrationMetrics = None
    
    # Assessment
    thresholds: FairnessThresholds = None
    is_fair: bool = False
    fairness_issues: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    def summary(self) -> str:
        """Generate human-readable audit summary."""
        status = "FAIR" if self.is_fair else "UNFAIR"
        
        lines = [
            "=" * 60,
            f"FAIRNESS AUDIT REPORT - {status}",
            "=" * 60,
            "",
            f"Model: {self.model_name}",
            f"Protected Attribute: {self.protected_attribute}",
            f"Groups: {', '.join(self.groups)}",
            f"Samples: {self.n_samples:,}",
            "",
        ]
        
        # Group fairness metrics
        if self.group_fairness:
            gf = self.group_fairness
            lines.extend([
                "GROUP FAIRNESS METRICS",
                "-" * 40,
                f"Demographic Parity Ratio: {gf.demographic_parity_ratio:.3f} "
                f"(threshold: ≥{self.thresholds.demographic_parity_ratio})",
                f"Demographic Parity Difference: {gf.demographic_parity_difference:.3f} "
                f"(threshold: ≤{self.thresholds.demographic_parity_difference})",
                f"Equalized Odds Ratio: {gf.equalized_odds_ratio:.3f} "
                f"(threshold: ≥{self.thresholds.equalized_odds_ratio})",
                f"Equalized Odds Difference: {gf.equalized_odds_difference:.3f} "
                f"(threshold: ≤{self.thresholds.equalized_odds_difference})",
                "",
                "Positive Prediction Rates:",
            ])
            for group, rate in gf.positive_rate_by_group.items():
                lines.append(f"  {group}: {rate:.1%}")
            
            lines.append("")
            lines.append("True Positive Rates:")
            for group, rate in gf.tpr_by_group.items():
                lines.append(f"  {group}: {rate:.1%}")
            
            lines.append("")
            lines.append("False Positive Rates:")
            for group, rate in gf.fpr_by_group.items():
                lines.append(f"  {group}: {rate:.1%}")
        
        # Calibration metrics
        if self.calibration:
            lines.extend([
                "",
                "CALIBRATION METRICS",
                "-" * 40,
                f"Expected Calibration Error: {self.calibration.expected_calibration_error:.4f}",
                f"Brier Score: {self.calibration.brier_score:.4f}",
            ])
            
            if self.calibration.calibration_by_group:
                lines.append("")
                lines.append("Calibration Error by Group:")
                for group, error in self.calibration.calibration_by_group.items():
                    lines.append(f"  {group}: {error:.4f}")
        
        # Issues
        if self.fairness_issues:
            lines.extend([
                "",
                "FAIRNESS ISSUES DETECTED",
                "-" * 40,
            ])
            for issue in self.fairness_issues:
                lines.append(f"  • {issue}")
        
        # Recommendations
        if self.recommendations:
            lines.extend([
                "",
                "RECOMMENDATIONS",
                "-" * 40,
            ])
            for rec in self.recommendations:
                lines.append(f"  • {rec}")
        
        return "\n".join(lines)
    
    def __str__(self):
        return self.summary()
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            'model_name': self.model_name,
            'protected_attribute': self.protected_attribute,
            'n_samples': self.n_samples,
            'groups': self.groups,
            'is_fair': self.is_fair,
            'fairness_issues': self.fairness_issues,
            'recommendations': self.recommendations,
            'metrics': {
                'demographic_parity_ratio': self.group_fairness.demographic_parity_ratio if self.group_fairness else None,
                'demographic_parity_difference': self.group_fairness.demographic_parity_difference if self.group_fairness else None,
                'equalized_odds_ratio': self.group_fairness.equalized_odds_ratio if self.group_fairness else None,
                'equalized_odds_difference': self.group_fairness.equalized_odds_difference if self.group_fairness else None,
            }
        }


class ModelAuditor:
    """Audits ML models for fairness.
    
    Parameters
    ----------
    thresholds : FairnessThresholds, optional
        Custom fairness thresholds
    compute_calibration : bool
        Whether to compute calibration metrics (requires predict_proba)
        
    Examples
    --------
    >>> auditor = ModelAuditor()
    >>> result = auditor.audit(
    ...     model=clf,
    ...     X=X_test,
    ...     y=y_test,
    ...     protected_attribute=gender_column
    ... )
    >>> print(result)
    """
    
    def __init__(
        self,
        thresholds: Optional[FairnessThresholds] = None,
        compute_calibration: bool = True,
    ):
        self.thresholds = thresholds or FairnessThresholds()
        self.compute_calibration = compute_calibration
    
    def audit(
        self,
        model: Any,
        X: Union[np.ndarray, pd.DataFrame],
        y: Union[np.ndarray, pd.Series],
        protected_attribute: Union[np.ndarray, pd.Series],
        model_name: str = "Model",
    ) -> AuditResult:
        """Perform fairness audit on a model.
        
        Parameters
        ----------
        model : estimator
            Trained model with predict() method
        X : array-like
            Test features
        y : array-like
            True labels
        protected_attribute : array-like
            Protected attribute values
        model_name : str
            Name for reporting
            
        Returns
        -------
        AuditResult
            Complete audit results
        """
        # Get predictions
        y_pred = model.predict(X)
        
        # Get probabilities if available
        y_prob = None
        if self.compute_calibration and hasattr(model, 'predict_proba'):
            try:
                y_prob = model.predict_proba(X)[:, 1]
            except Exception:
                y_prob = None
        
        # Convert to numpy
        y_true = np.asarray(y).ravel()
        y_pred = np.asarray(y_pred).ravel()
        protected = np.asarray(protected_attribute).ravel()
        
        # Get groups
        groups = sorted([str(g) for g in set(protected)])
        
        # Compute group fairness metrics
        group_fairness = compute_group_fairness_metrics(y_true, y_pred, protected)
        
        # Compute calibration if probabilities available
        calibration = None
        if y_prob is not None:
            calibration = compute_calibration_metrics(y_true, y_prob, protected)
        
        # Assess fairness
        issues = []
        recommendations = []
        
        # Check demographic parity
        if group_fairness.demographic_parity_ratio < self.thresholds.demographic_parity_ratio:
            issues.append(
                f"Demographic parity ratio ({group_fairness.demographic_parity_ratio:.3f}) "
                f"below threshold ({self.thresholds.demographic_parity_ratio})"
            )
            
            # Find disadvantaged group
            rates = group_fairness.positive_rate_by_group
            min_group = min(rates, key=rates.get)
            max_group = max(rates, key=rates.get)
            gap = rates[max_group] - rates[min_group]
            
            issues.append(
                f"'{min_group}' receives positive predictions {gap:.1%} less often than '{max_group}'"
            )
            recommendations.append(
                "Consider rebalancing training data or using threshold adjustment"
            )
        
        # Check equalized odds
        if group_fairness.equalized_odds_ratio < self.thresholds.equalized_odds_ratio:
            issues.append(
                f"Equalized odds ratio ({group_fairness.equalized_odds_ratio:.3f}) "
                f"below threshold ({self.thresholds.equalized_odds_ratio})"
            )
            
            # Identify TPR/FPR disparities
            tprs = group_fairness.tpr_by_group
            fprs = group_fairness.fpr_by_group
            
            tpr_diff = max(tprs.values()) - min(tprs.values())
            fpr_diff = max(fprs.values()) - min(fprs.values())
            
            if tpr_diff > 0.1:
                issues.append(f"True positive rate varies by {tpr_diff:.1%} across groups")
            if fpr_diff > 0.1:
                issues.append(f"False positive rate varies by {fpr_diff:.1%} across groups")
            
            recommendations.append(
                "Consider post-processing calibration or equalized odds adjustment"
            )
        
        # Check calibration
        if calibration and calibration.expected_calibration_error > self.thresholds.calibration_error:
            issues.append(
                f"Expected calibration error ({calibration.expected_calibration_error:.4f}) "
                f"above threshold ({self.thresholds.calibration_error})"
            )
            recommendations.append(
                "Consider Platt scaling or isotonic regression for calibration"
            )
        
        is_fair = len(issues) == 0
        
        if is_fair:
            recommendations.append("Model meets all fairness thresholds. Continue monitoring.")
        
        return AuditResult(
            model_name=model_name,
            protected_attribute=str(protected_attribute.name if hasattr(protected_attribute, 'name') else 'protected'),
            n_samples=len(y_true),
            groups=groups,
            group_fairness=group_fairness,
            calibration=calibration,
            thresholds=self.thresholds,
            is_fair=is_fair,
            fairness_issues=issues,
            recommendations=recommendations,
        )


def audit_model(
    model: Any,
    X: Union[np.ndarray, pd.DataFrame],
    y: Union[np.ndarray, pd.Series],
    protected: Union[np.ndarray, pd.Series],
    thresholds: Optional[FairnessThresholds] = None,
) -> AuditResult:
    """Quick model fairness audit.
    
    Convenience function for one-line model auditing.
    
    Parameters
    ----------
    model : estimator
        Trained model
    X : array-like
        Test features
    y : array-like
        True labels
    protected : array-like
        Protected attribute values
    thresholds : FairnessThresholds, optional
        Custom thresholds
        
    Returns
    -------
    AuditResult
        Audit results
        
    Examples
    --------
    >>> result = audit_model(clf, X_test, y_test, protected=gender)
    >>> print(result)
    """
    auditor = ModelAuditor(thresholds=thresholds)
    return auditor.audit(model, X, y, protected)
