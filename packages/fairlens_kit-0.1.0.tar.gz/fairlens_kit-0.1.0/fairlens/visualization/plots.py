"""
Fairness visualizations.

Provides matplotlib-based visualizations for fairness analysis:
- Disparity bar charts
- ROC curves by group
- Calibration plots
- Confusion matrix comparisons
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
import warnings

try:
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


def _check_matplotlib():
    """Check if matplotlib is available."""
    if not HAS_MATPLOTLIB:
        raise ImportError(
            "matplotlib is required for visualizations. "
            "Install it with: pip install matplotlib"
        )


def plot_disparity_bars(
    positive_rates: Dict[str, float],
    title: str = "Positive Prediction Rate by Group",
    threshold: float = 0.8,
    figsize: Tuple[int, int] = (10, 6),
    save_path: Optional[str] = None,
) -> None:
    """Plot disparity bar chart showing positive rates by group.
    
    Parameters
    ----------
    positive_rates : dict
        Group name -> positive prediction rate
    title : str
        Plot title
    threshold : float
        Fairness threshold for demographic parity ratio
    figsize : tuple
        Figure size
    save_path : str, optional
        Path to save figure
    """
    _check_matplotlib()
    
    groups = list(positive_rates.keys())
    rates = list(positive_rates.values())
    
    # Calculate threshold line
    max_rate = max(rates)
    threshold_line = max_rate * threshold
    
    # Colors based on whether rate meets threshold
    colors = ['#e74c3c' if r < threshold_line else '#27ae60' for r in rates]
    
    fig, ax = plt.subplots(figsize=figsize)
    
    bars = ax.bar(groups, rates, color=colors, edgecolor='white', linewidth=1.5)
    
    # Add threshold line
    ax.axhline(y=threshold_line, color='#f39c12', linestyle='--', 
               linewidth=2, label=f'{threshold:.0%} of max rate')
    
    # Add value labels on bars
    for bar, rate in zip(bars, rates):
        height = bar.get_height()
        ax.annotate(f'{rate:.1%}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=11, fontweight='bold')
    
    ax.set_xlabel('Group', fontsize=12)
    ax.set_ylabel('Positive Prediction Rate', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_ylim(0, max(rates) * 1.2)
    ax.legend(loc='upper right')
    
    # Add disparity annotation
    disparity = max(rates) - min(rates)
    ratio = min(rates) / max(rates) if max(rates) > 0 else 1
    ax.text(0.02, 0.98, f'Disparity: {disparity:.1%}\nRatio: {ratio:.2f}',
            transform=ax.transAxes, fontsize=10,
            verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    plt.show()


def plot_metric_comparison(
    metrics_by_group: Dict[str, Dict[str, float]],
    metric_names: List[str] = None,
    title: str = "Fairness Metrics by Group",
    figsize: Tuple[int, int] = (12, 6),
    save_path: Optional[str] = None,
) -> None:
    """Plot grouped bar chart comparing metrics across groups.
    
    Parameters
    ----------
    metrics_by_group : dict
        Group name -> {metric_name: value}
    metric_names : list, optional
        Metrics to include
    title : str
        Plot title
    figsize : tuple
        Figure size
    save_path : str, optional
        Path to save figure
    """
    _check_matplotlib()
    
    groups = list(metrics_by_group.keys())
    
    if metric_names is None:
        metric_names = list(list(metrics_by_group.values())[0].keys())
    
    x = np.arange(len(groups))
    width = 0.8 / len(metric_names)
    
    fig, ax = plt.subplots(figsize=figsize)
    
    colors = plt.cm.Set2(np.linspace(0, 1, len(metric_names)))
    
    for i, metric in enumerate(metric_names):
        values = [metrics_by_group[g].get(metric, 0) for g in groups]
        offset = (i - len(metric_names)/2 + 0.5) * width
        bars = ax.bar(x + offset, values, width, label=metric, color=colors[i])
    
    ax.set_xlabel('Group', fontsize=12)
    ax.set_ylabel('Rate', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(groups)
    ax.legend(loc='upper right')
    ax.set_ylim(0, 1.1)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    plt.show()


def plot_confusion_matrices(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    protected_attribute: np.ndarray,
    figsize: Tuple[int, int] = None,
    save_path: Optional[str] = None,
) -> None:
    """Plot confusion matrices side by side for each group.
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred : array-like
        Predicted labels
    protected_attribute : array-like
        Group membership
    figsize : tuple, optional
        Figure size
    save_path : str, optional
        Path to save figure
    """
    _check_matplotlib()
    
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()
    
    groups = sorted(list(set(protected_attribute)))
    n_groups = len(groups)
    
    if figsize is None:
        figsize = (5 * n_groups, 4)
    
    fig, axes = plt.subplots(1, n_groups, figsize=figsize)
    
    if n_groups == 1:
        axes = [axes]
    
    for ax, group in zip(axes, groups):
        mask = protected_attribute == group
        y_t = y_true[mask]
        y_p = y_pred[mask]
        
        # Compute confusion matrix
        tp = np.sum((y_t == 1) & (y_p == 1))
        tn = np.sum((y_t == 0) & (y_p == 0))
        fp = np.sum((y_t == 0) & (y_p == 1))
        fn = np.sum((y_t == 1) & (y_p == 0))
        
        cm = np.array([[tn, fp], [fn, tp]])
        
        # Plot
        im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        
        # Add text annotations
        thresh = cm.max() / 2.
        for i in range(2):
            for j in range(2):
                ax.text(j, i, format(cm[i, j], 'd'),
                       ha="center", va="center",
                       color="white" if cm[i, j] > thresh else "black",
                       fontsize=14)
        
        ax.set_title(f'Group: {group}\n(n={mask.sum():,})', fontsize=12)
        ax.set_ylabel('True Label')
        ax.set_xlabel('Predicted Label')
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(['Negative', 'Positive'])
        ax.set_yticklabels(['Negative', 'Positive'])
    
    plt.suptitle('Confusion Matrices by Group', fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    plt.show()


def plot_roc_by_group(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    protected_attribute: np.ndarray,
    title: str = "ROC Curves by Group",
    figsize: Tuple[int, int] = (8, 6),
    save_path: Optional[str] = None,
) -> None:
    """Plot ROC curves for each protected group.
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_prob : array-like
        Predicted probabilities
    protected_attribute : array-like
        Group membership
    title : str
        Plot title
    figsize : tuple
        Figure size
    save_path : str, optional
        Path to save figure
    """
    _check_matplotlib()
    
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()
    
    groups = sorted(list(set(protected_attribute)))
    colors = plt.cm.tab10(np.linspace(0, 1, len(groups)))
    
    fig, ax = plt.subplots(figsize=figsize)
    
    for group, color in zip(groups, colors):
        mask = protected_attribute == group
        y_t = y_true[mask]
        y_p = y_prob[mask]
        
        # Compute ROC curve manually
        thresholds = np.linspace(0, 1, 100)
        tprs = []
        fprs = []
        
        for thresh in thresholds:
            y_pred = (y_p >= thresh).astype(int)
            
            tp = np.sum((y_t == 1) & (y_pred == 1))
            fn = np.sum((y_t == 1) & (y_pred == 0))
            fp = np.sum((y_t == 0) & (y_pred == 1))
            tn = np.sum((y_t == 0) & (y_pred == 0))
            
            tpr = tp / (tp + fn) if (tp + fn) > 0 else 0
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
            
            tprs.append(tpr)
            fprs.append(fpr)
        
        # Compute AUC (approximate)
        fprs_sorted = np.array(fprs)
        tprs_sorted = np.array(tprs)
        idx = np.argsort(fprs_sorted)
        auc = np.trapz(tprs_sorted[idx], fprs_sorted[idx])
        
        ax.plot(fprs, tprs, color=color, linewidth=2,
                label=f'{group} (AUC={auc:.3f})')
    
    # Diagonal line
    ax.plot([0, 1], [0, 1], 'k--', linewidth=1, label='Random')
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(loc='lower right')
    ax.set_xlim(-0.01, 1.01)
    ax.set_ylim(-0.01, 1.01)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    plt.show()


def plot_calibration_curve(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    protected_attribute: Optional[np.ndarray] = None,
    n_bins: int = 10,
    title: str = "Calibration Curve",
    figsize: Tuple[int, int] = (8, 6),
    save_path: Optional[str] = None,
) -> None:
    """Plot calibration curve showing predicted vs actual probabilities.
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_prob : array-like
        Predicted probabilities
    protected_attribute : array-like, optional
        Group membership for separate curves
    n_bins : int
        Number of probability bins
    title : str
        Plot title
    figsize : tuple
        Figure size
    save_path : str, optional
        Path to save figure
    """
    _check_matplotlib()
    
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    
    fig, ax = plt.subplots(figsize=figsize)
    
    # Perfect calibration line
    ax.plot([0, 1], [0, 1], 'k--', linewidth=1, label='Perfect calibration')
    
    def compute_calibration(y_t, y_p, n_bins):
        bins = np.linspace(0, 1, n_bins + 1)
        mean_predicted = []
        fraction_positives = []
        
        for i in range(n_bins):
            mask = (y_p >= bins[i]) & (y_p < bins[i + 1])
            if i == n_bins - 1:
                mask = (y_p >= bins[i]) & (y_p <= bins[i + 1])
            
            if mask.sum() > 0:
                mean_predicted.append(y_p[mask].mean())
                fraction_positives.append(y_t[mask].mean())
        
        return mean_predicted, fraction_positives
    
    if protected_attribute is not None:
        protected_attribute = np.asarray(protected_attribute).ravel()
        groups = sorted(list(set(protected_attribute)))
        colors = plt.cm.tab10(np.linspace(0, 1, len(groups)))
        
        for group, color in zip(groups, colors):
            mask = protected_attribute == group
            mean_pred, frac_pos = compute_calibration(
                y_true[mask], y_prob[mask], n_bins
            )
            ax.plot(mean_pred, frac_pos, 's-', color=color, 
                   linewidth=2, markersize=8, label=f'{group}')
    else:
        mean_pred, frac_pos = compute_calibration(y_true, y_prob, n_bins)
        ax.plot(mean_pred, frac_pos, 's-', color='#3498db',
               linewidth=2, markersize=8, label='Model')
    
    ax.set_xlabel('Mean Predicted Probability', fontsize=12)
    ax.set_ylabel('Fraction of Positives', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(loc='lower right')
    ax.set_xlim(-0.01, 1.01)
    ax.set_ylim(-0.01, 1.01)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    plt.show()


def plot_label_distribution(
    data: pd.DataFrame,
    target: str,
    protected_attribute: str,
    title: str = None,
    figsize: Tuple[int, int] = (10, 6),
    save_path: Optional[str] = None,
) -> None:
    """Plot label distribution by protected group.
    
    Parameters
    ----------
    data : DataFrame
        Dataset
    target : str
        Target column name
    protected_attribute : str
        Protected attribute column name
    title : str, optional
        Plot title
    figsize : tuple
        Figure size
    save_path : str, optional
        Path to save figure
    """
    _check_matplotlib()
    
    if title is None:
        title = f'{target} Distribution by {protected_attribute}'
    
    # Compute rates
    rates = data.groupby(protected_attribute)[target].mean()
    counts = data.groupby(protected_attribute).size()
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
    
    # Positive rate bar chart
    colors = plt.cm.Set2(np.linspace(0, 1, len(rates)))
    bars = ax1.bar(rates.index, rates.values, color=colors, edgecolor='white')
    
    for bar, rate in zip(bars, rates.values):
        ax1.annotate(f'{rate:.1%}',
                    xy=(bar.get_x() + bar.get_width() / 2, rate),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=11, fontweight='bold')
    
    ax1.set_xlabel(protected_attribute, fontsize=12)
    ax1.set_ylabel(f'{target} Rate', fontsize=12)
    ax1.set_title(f'Positive Rate by {protected_attribute}', fontsize=12)
    ax1.set_ylim(0, max(rates.values) * 1.2)
    
    # Group size pie chart
    ax2.pie(counts.values, labels=counts.index, autopct='%1.1f%%',
            colors=colors, startangle=90)
    ax2.set_title(f'Sample Distribution', fontsize=12)
    
    plt.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    plt.show()


class BiasVisualizer:
    """Visualization helper for fairness analysis.
    
    Parameters
    ----------
    style : str
        Matplotlib style ('default', 'dark', 'minimal')
        
    Examples
    --------
    >>> viz = BiasVisualizer()
    >>> viz.plot_disparity(positive_rates)
    >>> viz.plot_confusion_matrices(y_true, y_pred, protected)
    """
    
    def __init__(self, style: str = 'default'):
        _check_matplotlib()
        self.style = style
        if style == 'dark':
            plt.style.use('dark_background')
        elif style == 'minimal':
            plt.style.use('seaborn-v0_8-whitegrid')
    
    def plot_disparity(self, positive_rates: Dict[str, float], **kwargs):
        """Plot disparity bar chart."""
        plot_disparity_bars(positive_rates, **kwargs)
    
    def plot_confusion(self, y_true, y_pred, protected, **kwargs):
        """Plot confusion matrices by group."""
        plot_confusion_matrices(y_true, y_pred, protected, **kwargs)
    
    def plot_roc(self, y_true, y_prob, protected, **kwargs):
        """Plot ROC curves by group."""
        plot_roc_by_group(y_true, y_prob, protected, **kwargs)
    
    def plot_calibration(self, y_true, y_prob, protected=None, **kwargs):
        """Plot calibration curve."""
        plot_calibration_curve(y_true, y_prob, protected, **kwargs)


def plot_bias(
    data: pd.DataFrame,
    target: str,
    protected: str,
    **kwargs
) -> None:
    """Quick bias visualization.
    
    Convenience function for one-line visualization.
    
    Parameters
    ----------
    data : DataFrame
        Dataset
    target : str
        Target column
    protected : str
        Protected attribute column
    """
    plot_label_distribution(data, target, protected, **kwargs)
