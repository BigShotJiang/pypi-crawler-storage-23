"""
FairLens visualization module.

Provides matplotlib-based fairness visualizations.
"""

from .plots import (
    plot_disparity_bars,
    plot_metric_comparison,
    plot_confusion_matrices,
    plot_roc_by_group,
    plot_calibration_curve,
    plot_label_distribution,
    plot_bias,
    BiasVisualizer,
)


__all__ = [
    "plot_disparity_bars",
    "plot_metric_comparison", 
    "plot_confusion_matrices",
    "plot_roc_by_group",
    "plot_calibration_curve",
    "plot_label_distribution",
    "plot_bias",
    "BiasVisualizer",
]
