"""
FairLens: Lightweight ML Bias Detection Toolkit
==============================================

FairLens provides easy-to-use tools for detecting, measuring, and visualizing
bias in datasets and machine learning models.

Quick Start
-----------
>>> import fairlens as fl

# Check your dataset for bias
>>> report = fl.check_dataset(df, target='outcome', protected=['gender', 'race'])
>>> print(report)

# Audit your model for fairness
>>> result = fl.audit_model(model, X_test, y_test, protected=gender)
>>> print(result)

# Visualize bias
>>> fl.plot_bias(df, target='outcome', protected='gender')

Main Components
---------------
- `check_dataset`: Analyze datasets for bias
- `audit_model`: Audit ML models for fairness
- `plot_bias`: Quick bias visualization

Modules
-------
- `metrics`: Fairness metrics (demographic parity, equalized odds, etc.)
- `datasets`: Built-in fairness datasets and analyzers
- `audit`: Model auditing and report generation
- `visualization`: Bias visualization tools
- `mitigation`: Bias mitigation suggestions
"""

__version__ = "0.1.0"
__author__ = "Dmitriy Tsarev"
__license__ = "MIT"

# Simple API imports
from .datasets.analyzer import check_dataset, DatasetAnalyzer, DatasetBiasReport
from .datasets.loaders import (
    load_adult,
    load_compas,
    load_german_credit,
    load_bank_marketing,
    list_datasets,
    load_dataset,
    FairnessDataset,
)
from .datasets.fetchers import (
    fetch_adult,
    fetch_german_credit,
    fetch_compas,
    fetch_dataset,
)
from .audit.model_audit import audit_model, ModelAuditor, AuditResult, FairnessThresholds
from .audit.report import generate_html_report, generate_json_report, generate_markdown_report
from .visualization.plots import (
    plot_bias,
    plot_disparity_bars,
    plot_confusion_matrices,
    plot_roc_by_group,
    plot_calibration_curve,
    BiasVisualizer,
)
from .metrics.group_fairness import (
    demographic_parity_ratio,
    demographic_parity_difference,
    equalized_odds_ratio,
    equalized_odds_difference,
    compute_group_fairness_metrics,
)
from .metrics.calibration import (
    expected_calibration_error,
    brier_score,
    compute_calibration_metrics,
)
from .metrics.individual import (
    consistency_score,
    compute_individual_fairness_metrics,
)
from .metrics.intersectional import (
    create_intersection_groups,
    compute_intersectional_metrics,
)
from .metrics.bootstrap import bootstrap_metric, ConfidenceInterval
from .metrics.multiclass import compute_multiclass_fairness, multiclass_demographic_parity
from .mitigation.suggestions import get_suggestions, print_suggestions
from .mitigation.algorithms import ThresholdOptimizer, Reweighter


# Submodule access
from . import datasets
from . import metrics
from . import audit
from . import visualization
from . import mitigation


__all__ = [
    # Version
    "__version__",
    # Simple API
    "check_dataset",
    "audit_model", 
    "plot_bias",
    # Dataset loading (synthetic)
    "load_adult",
    "load_compas",
    "load_german_credit",
    "load_bank_marketing",
    "list_datasets",
    "load_dataset",
    "FairnessDataset",
    # Dataset fetching (real)
    "fetch_adult",
    "fetch_german_credit",
    "fetch_compas",
    "fetch_dataset",
    # Dataset analysis
    "DatasetAnalyzer",
    "DatasetBiasReport",
    # Model audit
    "ModelAuditor",
    "AuditResult",
    "FairnessThresholds",
    # Report generation
    "generate_html_report",
    "generate_json_report",
    "generate_markdown_report",
    # Visualization
    "plot_disparity_bars",
    "plot_confusion_matrices",
    "plot_roc_by_group",
    "plot_calibration_curve",
    "BiasVisualizer",
    # Metrics
    "demographic_parity_ratio",
    "demographic_parity_difference",
    "equalized_odds_ratio",
    "equalized_odds_difference",
    "compute_group_fairness_metrics",
    "expected_calibration_error",
    "brier_score",
    "compute_calibration_metrics",
    "consistency_score",
    "compute_individual_fairness_metrics",
    "create_intersection_groups",
    "compute_intersectional_metrics",
    "bootstrap_metric",
    "ConfidenceInterval",
    "compute_multiclass_fairness",
    "multiclass_demographic_parity",
    # Mitigation
    "get_suggestions",
    "print_suggestions",
    "ThresholdOptimizer",
    "Reweighter",
    # Submodules
    "datasets",
    "metrics",
    "audit",
    "visualization",
    "mitigation",
]
