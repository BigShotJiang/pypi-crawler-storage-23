"""
FairLens datasets module.

Provides access to fairness benchmark datasets and analysis tools.
"""

from .loaders import (
    load_adult,
    load_compas,
    load_german_credit,
    load_bank_marketing,
    list_datasets,
    load_dataset,
    FairnessDataset,
)

from .analyzer import (
    DatasetAnalyzer,
    DatasetBiasReport,
    ProxyVariable,
    check_dataset,
)

from .preprocessing import (
    encode_categorical,
    decode_categorical,
    balance_dataset,
    stratified_split,
    remove_protected_from_features,
    prepare_for_modeling,
)

from .fetchers import (
    fetch_adult,
    fetch_german_credit,
    fetch_compas,
    fetch_dataset,
)


__all__ = [
    # Loaders
    "load_adult",
    "load_compas",
    "load_german_credit",
    "load_bank_marketing",
    "list_datasets",
    "load_dataset",
    "FairnessDataset",
    # Analyzer
    "DatasetAnalyzer",
    "DatasetBiasReport",
    "ProxyVariable",
    "check_dataset",
    # Fetchers (real data)
    "fetch_adult",
    "fetch_german_credit",
    "fetch_compas",
    "fetch_dataset",
    # Preprocessing
    "encode_categorical",
    "decode_categorical",
    "balance_dataset",
    "stratified_split",
    "remove_protected_from_features",
    "prepare_for_modeling",
]
