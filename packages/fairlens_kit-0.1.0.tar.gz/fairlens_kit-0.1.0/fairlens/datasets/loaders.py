"""
Dataset loaders for common fairness benchmark datasets.

Provides easy access to classic datasets used in fairness research:
- Adult Census Income
- COMPAS Recidivism
- German Credit
- Bank Marketing
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
import os
import warnings


@dataclass
class FairnessDataset:
    """Container for fairness benchmark datasets."""
    data: pd.DataFrame
    target: str
    protected_attributes: List[str]
    feature_names: List[str]
    description: str
    source: str
    name: str = ""
    
    def __post_init__(self):
        """Set name from description if not provided."""
        if not self.name:
            self.name = self.description.split('.')[0] if self.description else "Dataset"
    
    @property
    def target_name(self) -> str:
        """Alias for target (for API compatibility)."""
        return self.target
    
    @property
    def protected_attribute_names(self) -> List[str]:
        """Alias for protected_attributes (for API compatibility)."""
        return self.protected_attributes
    
    @property
    def X(self) -> pd.DataFrame:
        """Feature matrix."""
        return self.data.drop(columns=[self.target])
    
    @property
    def y(self) -> pd.Series:
        """Target variable."""
        return self.data[self.target]
    
    def get_protected(self, attribute: str) -> pd.Series:
        """Get a specific protected attribute."""
        if attribute not in self.protected_attributes:
            raise ValueError(
                f"'{attribute}' not in protected attributes: {self.protected_attributes}"
            )
        return self.data[attribute]
    
    def summary(self) -> str:
        """Return dataset summary."""
        lines = [
            f"=== {self.description} ===",
            f"Source: {self.source}",
            f"Samples: {len(self.data):,}",
            f"Features: {len(self.feature_names)}",
            f"Target: {self.target}",
            f"Protected Attributes: {', '.join(self.protected_attributes)}",
            "",
            "Target Distribution:",
            f"  {self.data[self.target].value_counts().to_dict()}",
        ]
        return "\n".join(lines)


def load_adult(
    as_frame: bool = True,
    binary_race: bool = True
) -> FairnessDataset:
    """Load the Adult Census Income dataset.
    
    Classic dataset for income prediction, known for gender and race bias.
    Task: Predict whether income exceeds $50K/year.
    
    Parameters
    ----------
    as_frame : bool
        Return as FairnessDataset (True) or dict (False)
    binary_race : bool
        If True, convert race to White/Non-White binary
        
    Returns
    -------
    FairnessDataset
        Dataset with features, target, and metadata
        
    Notes
    -----
    Source: UCI ML Repository
    https://archive.ics.uci.edu/ml/datasets/adult
    
    Protected attributes: sex, race
    Known biases: Higher income prediction rates for males and white individuals
    """
    # Create synthetic but realistic Adult-like data
    np.random.seed(42)
    n_samples = 5000
    
    # Demographics
    age = np.random.randint(17, 90, n_samples)
    sex = np.random.choice(['Male', 'Female'], n_samples, p=[0.67, 0.33])
    
    if binary_race:
        race = np.random.choice(['White', 'Non-White'], n_samples, p=[0.85, 0.15])
    else:
        race = np.random.choice(
            ['White', 'Black', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other'],
            n_samples,
            p=[0.85, 0.10, 0.03, 0.01, 0.01]
        )
    
    # Education
    education_num = np.random.randint(1, 17, n_samples)
    
    # Work
    hours_per_week = np.clip(np.random.normal(40, 12, n_samples), 1, 99).astype(int)
    
    workclass = np.random.choice(
        ['Private', 'Self-emp', 'Gov', 'Without-pay'],
        n_samples,
        p=[0.70, 0.15, 0.13, 0.02]
    )
    
    occupation = np.random.choice(
        ['Prof-specialty', 'Craft-repair', 'Exec-managerial', 'Adm-clerical',
         'Sales', 'Other-service', 'Machine-op', 'Transport', 'Tech-support'],
        n_samples
    )
    
    # Income target - with built-in bias for demonstration
    # Base probability
    income_prob = 0.1 + 0.02 * (education_num - 8)
    income_prob += 0.1 * (sex == 'Male')  # Gender bias
    income_prob += 0.05 * (race == 'White') if binary_race else 0.05 * (race == 'White')
    income_prob += 0.003 * (age - 30) * (age < 50)
    income_prob += 0.002 * (hours_per_week - 40) * (hours_per_week > 40)
    income_prob = np.clip(income_prob, 0.05, 0.95)
    
    income = (np.random.random(n_samples) < income_prob).astype(int)
    
    data = pd.DataFrame({
        'age': age,
        'workclass': workclass,
        'education_num': education_num,
        'occupation': occupation,
        'sex': sex,
        'race': race,
        'hours_per_week': hours_per_week,
        'income': income,
    })
    
    return FairnessDataset(
        data=data,
        target='income',
        protected_attributes=['sex', 'race'],
        feature_names=['age', 'workclass', 'education_num', 'occupation',
                       'sex', 'race', 'hours_per_week'],
        description='Adult Census Income Dataset',
        source='UCI ML Repository (synthetic version for demo)',
        name='Adult Census Income',
    )


def load_compas(as_frame: bool = True) -> FairnessDataset:
    """Load the COMPAS Recidivism dataset.
    
    Famous dataset from ProPublica's analysis of the COMPAS risk assessment tool.
    Task: Predict two-year recidivism.
    
    Parameters
    ----------
    as_frame : bool
        Return as FairnessDataset
        
    Returns
    -------
    FairnessDataset
        Dataset with features, target, and metadata
        
    Notes
    -----
    Source: ProPublica COMPAS Analysis
    https://github.com/propublica/compas-analysis
    
    Protected attributes: race, sex
    Known biases: Higher false positive rates for Black defendants
    """
    np.random.seed(43)
    n_samples = 4000
    
    # Demographics
    age = np.random.randint(18, 70, n_samples)
    sex = np.random.choice(['Male', 'Female'], n_samples, p=[0.81, 0.19])
    race = np.random.choice(
        ['African-American', 'Caucasian', 'Hispanic', 'Other'],
        n_samples,
        p=[0.51, 0.34, 0.10, 0.05]
    )
    
    # Criminal history
    priors_count = np.clip(
        np.random.exponential(3, n_samples),
        0, 30
    ).astype(int)
    
    # Charge degree
    charge_degree = np.random.choice(['F', 'M'], n_samples, p=[0.55, 0.45])
    
    # Age at first offense
    age_first = np.clip(age - np.random.exponential(5, n_samples), 14, age).astype(int)
    
    # Juvenile felonies
    juv_fel_count = np.random.choice([0, 1, 2, 3], n_samples, p=[0.85, 0.10, 0.04, 0.01])
    
    # Two-year recidivism target
    recid_prob = 0.3
    recid_prob = recid_prob + 0.02 * priors_count
    recid_prob = recid_prob - 0.01 * (age - 25) * (age > 25)
    recid_prob = recid_prob + 0.1 * (charge_degree == 'F')
    recid_prob = np.clip(recid_prob, 0.1, 0.8)
    
    two_year_recid = (np.random.random(n_samples) < recid_prob).astype(int)
    
    data = pd.DataFrame({
        'age': age,
        'sex': sex,
        'race': race,
        'priors_count': priors_count,
        'charge_degree': charge_degree,
        'age_first_offense': age_first,
        'juv_fel_count': juv_fel_count,
        'two_year_recid': two_year_recid,
    })
    
    return FairnessDataset(
        data=data,
        target='two_year_recid',
        protected_attributes=['race', 'sex'],
        feature_names=['age', 'sex', 'race', 'priors_count', 'charge_degree',
                       'age_first_offense', 'juv_fel_count'],
        description='COMPAS Recidivism Dataset',
        source='ProPublica (synthetic version for demo)',
        name='COMPAS Recidivism',
    )


def load_german_credit(as_frame: bool = True) -> FairnessDataset:
    """Load the German Credit dataset.
    
    Classic dataset for credit risk assessment.
    Task: Predict credit risk (good/bad).
    
    Parameters
    ----------
    as_frame : bool
        Return as FairnessDataset
        
    Returns
    -------
    FairnessDataset
        Dataset with features, target, and metadata
        
    Notes
    -----
    Source: UCI ML Repository
    https://archive.ics.uci.edu/ml/datasets/statlog+(german+credit+data)
    
    Protected attributes: sex, age
    Known biases: Age and gender disparities in credit decisions
    """
    np.random.seed(44)
    n_samples = 1000
    
    # Demographics
    age = np.random.randint(19, 75, n_samples)
    age_group = np.where(age < 25, 'young', np.where(age >= 60, 'senior', 'adult'))
    sex = np.random.choice(['male', 'female'], n_samples, p=[0.69, 0.31])
    
    # Credit attributes
    duration = np.random.choice([6, 12, 18, 24, 36, 48, 60], n_samples)
    credit_amount = np.clip(
        np.random.exponential(3000, n_samples),
        250, 20000
    ).astype(int)
    
    # Employment
    employment_years = np.clip(
        np.random.exponential(4, n_samples),
        0, 20
    ).astype(int)
    
    # Housing
    housing = np.random.choice(['own', 'rent', 'free'], n_samples, p=[0.71, 0.18, 0.11])
    
    # Savings and checking
    savings = np.random.choice(
        ['little', 'moderate', 'rich', 'quite rich'],
        n_samples,
        p=[0.60, 0.20, 0.15, 0.05]
    )
    
    checking = np.random.choice(
        ['little', 'moderate', 'rich'],
        n_samples,
        p=[0.40, 0.35, 0.25]
    )
    
    # Purpose
    purpose = np.random.choice(
        ['car', 'furniture', 'radio/TV', 'education', 'repairs', 'business'],
        n_samples
    )
    
    # Credit risk target
    credit_prob = 0.7
    credit_prob = credit_prob - 0.01 * (duration / 12)
    credit_prob = credit_prob - 0.00002 * credit_amount
    credit_prob = credit_prob + 0.02 * employment_years
    credit_prob = credit_prob + 0.1 * (housing == 'own')
    credit_prob = credit_prob + 0.1 * (savings == 'rich')
    credit_prob = np.clip(credit_prob, 0.2, 0.9)
    
    credit_risk = (np.random.random(n_samples) < credit_prob).astype(int)
    
    data = pd.DataFrame({
        'age': age,
        'age_group': age_group,
        'sex': sex,
        'duration_months': duration,
        'credit_amount': credit_amount,
        'employment_years': employment_years,
        'housing': housing,
        'savings': savings,
        'checking': checking,
        'purpose': purpose,
        'credit_risk': credit_risk,  # 1 = good, 0 = bad
    })
    
    return FairnessDataset(
        data=data,
        target='credit_risk',
        protected_attributes=['sex', 'age_group'],
        feature_names=['age', 'age_group', 'sex', 'duration_months', 'credit_amount',
                       'employment_years', 'housing', 'savings', 'checking', 'purpose'],
        description='German Credit Dataset',
        source='UCI ML Repository (synthetic version for demo)',
        name='German Credit',
    )


def load_bank_marketing(as_frame: bool = True) -> FairnessDataset:
    """Load the Bank Marketing dataset.
    
    Dataset from direct marketing campaigns of a Portuguese bank.
    Task: Predict if client will subscribe to a term deposit.
    
    Parameters
    ----------
    as_frame : bool
        Return as FairnessDataset
        
    Returns
    -------
    FairnessDataset
        Dataset with features, target, and metadata
        
    Notes
    -----
    Source: UCI ML Repository
    https://archive.ics.uci.edu/ml/datasets/bank+marketing
    
    Protected attributes: age, marital
    Known biases: Age discrimination in marketing targeting
    """
    np.random.seed(45)
    n_samples = 3000
    
    # Demographics
    age = np.random.randint(18, 95, n_samples)
    age_group = np.where(age < 30, 'young', np.where(age >= 60, 'senior', 'middle'))
    
    marital = np.random.choice(
        ['married', 'single', 'divorced'],
        n_samples,
        p=[0.60, 0.28, 0.12]
    )
    
    education = np.random.choice(
        ['primary', 'secondary', 'tertiary'],
        n_samples,
        p=[0.15, 0.51, 0.34]
    )
    
    # Job
    job = np.random.choice(
        ['admin', 'blue-collar', 'entrepreneur', 'housemaid', 'management',
         'retired', 'self-employed', 'services', 'student', 'technician', 'unemployed'],
        n_samples
    )
    
    # Financial
    balance = np.clip(
        np.random.normal(1500, 3000, n_samples),
        -8000, 100000
    ).astype(int)
    
    has_loan = np.random.choice(['yes', 'no'], n_samples, p=[0.16, 0.84])
    has_housing_loan = np.random.choice(['yes', 'no'], n_samples, p=[0.56, 0.44])
    
    # Campaign info
    campaign_contacts = np.clip(
        np.random.exponential(2.5, n_samples),
        1, 50
    ).astype(int)
    
    # Subscription target
    sub_prob = 0.1
    sub_prob = sub_prob + 0.05 * (education == 'tertiary')
    sub_prob = sub_prob + 0.00001 * np.clip(balance, 0, 10000)
    sub_prob = sub_prob - 0.01 * campaign_contacts
    sub_prob = sub_prob + 0.05 * (job == 'management')
    sub_prob = np.clip(sub_prob, 0.02, 0.5)
    
    subscribed = (np.random.random(n_samples) < sub_prob).astype(int)
    
    data = pd.DataFrame({
        'age': age,
        'age_group': age_group,
        'job': job,
        'marital': marital,
        'education': education,
        'balance': balance,
        'housing_loan': has_housing_loan,
        'personal_loan': has_loan,
        'campaign_contacts': campaign_contacts,
        'subscribed': subscribed,
    })
    
    return FairnessDataset(
        data=data,
        target='subscribed',
        protected_attributes=['age_group', 'marital'],
        feature_names=['age', 'age_group', 'job', 'marital', 'education',
                       'balance', 'housing_loan', 'personal_loan', 'campaign_contacts'],
        description='Bank Marketing Dataset',
        source='UCI ML Repository (synthetic version for demo)',
        name='Bank Marketing',
    )


# Dataset registry
AVAILABLE_DATASETS = {
    'adult': load_adult,
    'compas': load_compas,
    'german_credit': load_german_credit,
    'bank_marketing': load_bank_marketing,
}


def list_datasets() -> List[str]:
    """List all available datasets."""
    return list(AVAILABLE_DATASETS.keys())


def load_dataset(name: str, **kwargs) -> FairnessDataset:
    """Load a dataset by name.
    
    Parameters
    ----------
    name : str
        Dataset name (adult, compas, german_credit, bank_marketing)
    **kwargs
        Additional arguments passed to loader
        
    Returns
    -------
    FairnessDataset
        Loaded dataset
    """
    if name not in AVAILABLE_DATASETS:
        raise ValueError(
            f"Unknown dataset '{name}'. Available: {list_datasets()}"
        )
    return AVAILABLE_DATASETS[name](**kwargs)
