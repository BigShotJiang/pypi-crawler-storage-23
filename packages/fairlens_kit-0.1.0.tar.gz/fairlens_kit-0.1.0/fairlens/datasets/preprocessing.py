"""
Data preprocessing utilities for fairness analysis.

Provides tools for preparing data for fairness evaluation:
- Encoding categorical variables
- Handling missing values
- Balancing datasets
- Train/test splitting with stratification
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union


def encode_categorical(
    data: pd.DataFrame,
    columns: Optional[List[str]] = None,
    drop_first: bool = False
) -> Tuple[pd.DataFrame, Dict[str, Dict]]:
    """Encode categorical columns as numeric.
    
    Parameters
    ----------
    data : DataFrame
        Input data
    columns : list, optional
        Columns to encode. If None, encodes all object columns.
    drop_first : bool
        Whether to drop first category (for avoiding multicollinearity)
        
    Returns
    -------
    encoded_data : DataFrame
        Data with categorical columns encoded
    encodings : dict
        Mapping from category names to numeric values for each column
    """
    data = data.copy()
    
    if columns is None:
        columns = data.select_dtypes(include=['object']).columns.tolist()
    
    encodings = {}
    
    for col in columns:
        if col in data.columns:
            categories = data[col].unique()
            mapping = {cat: i for i, cat in enumerate(sorted(categories))}
            encodings[col] = mapping
            data[col] = data[col].map(mapping)
    
    return data, encodings


def decode_categorical(
    data: pd.DataFrame,
    encodings: Dict[str, Dict],
) -> pd.DataFrame:
    """Decode numeric columns back to categorical.
    
    Parameters
    ----------
    data : DataFrame
        Encoded data
    encodings : dict
        Mappings from encode_categorical
        
    Returns
    -------
    DataFrame
        Data with original categorical values
    """
    data = data.copy()
    
    for col, mapping in encodings.items():
        if col in data.columns:
            reverse_mapping = {v: k for k, v in mapping.items()}
            data[col] = data[col].map(reverse_mapping)
    
    return data


def balance_dataset(
    data: pd.DataFrame,
    target: str,
    protected_attribute: str,
    strategy: str = 'undersample',
    random_state: int = 42
) -> pd.DataFrame:
    """Balance dataset across protected groups.
    
    Parameters
    ----------
    data : DataFrame
        Input data
    target : str
        Target column name
    protected_attribute : str
        Protected attribute column name
    strategy : str
        'undersample' to reduce majority groups,
        'oversample' to increase minority groups
    random_state : int
        Random seed
        
    Returns
    -------
    DataFrame
        Balanced dataset
    """
    np.random.seed(random_state)
    
    groups = data.groupby([protected_attribute, target])
    group_sizes = groups.size()
    
    if strategy == 'undersample':
        target_size = group_sizes.min()
    else:  # oversample
        target_size = group_sizes.max()
    
    balanced_dfs = []
    
    for (attr_val, target_val), group_df in groups:
        current_size = len(group_df)
        
        if strategy == 'undersample' and current_size > target_size:
            sampled = group_df.sample(n=target_size, random_state=random_state)
        elif strategy == 'oversample' and current_size < target_size:
            sampled = group_df.sample(n=target_size, replace=True, random_state=random_state)
        else:
            sampled = group_df
        
        balanced_dfs.append(sampled)
    
    return pd.concat(balanced_dfs, ignore_index=True).sample(frac=1, random_state=random_state)


def stratified_split(
    data: pd.DataFrame,
    target: str,
    protected_attribute: str,
    test_size: float = 0.2,
    random_state: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Split data while preserving group proportions.
    
    Parameters
    ----------
    data : DataFrame
        Input data
    target : str
        Target column name
    protected_attribute : str
        Protected attribute to stratify on
    test_size : float
        Fraction of data for test set
    random_state : int
        Random seed
        
    Returns
    -------
    train_data : DataFrame
        Training set
    test_data : DataFrame
        Test set
    """
    np.random.seed(random_state)
    
    # Create stratification key combining target and protected attribute
    data = data.copy()
    strat_key = data[target].astype(str) + '_' + data[protected_attribute].astype(str)
    
    train_indices = []
    test_indices = []
    
    for key in strat_key.unique():
        key_indices = data.index[strat_key == key].tolist()
        n_test = max(1, int(len(key_indices) * test_size))
        
        np.random.shuffle(key_indices)
        test_indices.extend(key_indices[:n_test])
        train_indices.extend(key_indices[n_test:])
    
    return data.loc[train_indices], data.loc[test_indices]


def remove_protected_from_features(
    data: pd.DataFrame,
    protected_attributes: List[str],
    target: str
) -> Tuple[pd.DataFrame, pd.Series, pd.DataFrame]:
    """Separate features, target, and protected attributes.
    
    Parameters
    ----------
    data : DataFrame
        Full dataset
    protected_attributes : list
        Protected attribute columns
    target : str
        Target column
        
    Returns
    -------
    X : DataFrame
        Features (excluding protected attributes)
    y : Series
        Target variable
    protected : DataFrame
        Protected attributes
    """
    y = data[target]
    protected = data[protected_attributes]
    X = data.drop(columns=protected_attributes + [target])
    
    return X, y, protected


def prepare_for_modeling(
    data: pd.DataFrame,
    target: str,
    protected_attributes: List[str],
    encode_categoricals: bool = True,
    remove_protected: bool = False,
) -> Dict:
    """Prepare dataset for model training and fairness analysis.
    
    Parameters
    ----------
    data : DataFrame
        Raw dataset
    target : str
        Target column
    protected_attributes : list
        Protected attribute columns
    encode_categoricals : bool
        Whether to encode categorical variables
    remove_protected : bool
        Whether to remove protected attributes from features
        
    Returns
    -------
    dict
        Contains X, y, protected, and encodings
    """
    data = data.copy()
    encodings = {}
    
    if encode_categoricals:
        data, encodings = encode_categorical(data)
    
    if remove_protected:
        X, y, protected = remove_protected_from_features(
            data, protected_attributes, target
        )
    else:
        y = data[target]
        protected = data[protected_attributes]
        X = data.drop(columns=[target])
    
    return {
        'X': X,
        'y': y,
        'protected': protected,
        'encodings': encodings,
        'feature_names': X.columns.tolist(),
    }
