"""
Dataset bias analyzer.

Analyzes datasets for potential biases before model training:
- Demographic distribution imbalances
- Label rate disparities across groups
- Proxy variable detection
- Feature correlation with protected attributes
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass, field


@dataclass
class ProxyVariable:
    """Information about a potential proxy variable."""
    feature: str
    protected_attribute: str
    correlation: float
    is_proxy: bool
    
    def __str__(self):
        status = "PROXY" if self.is_proxy else "OK"
        return f"{self.feature} ↔ {self.protected_attribute}: r={self.correlation:.3f} {status}"


@dataclass
class DatasetBiasReport:
    """Report of dataset bias analysis."""
    n_samples: int
    n_features: int
    target: str
    protected_attributes: List[str]
    
    # Distribution analysis
    group_sizes: Dict[str, Dict[str, int]] = field(default_factory=dict)
    group_proportions: Dict[str, Dict[str, float]] = field(default_factory=dict)
    
    # Label analysis
    overall_positive_rate: float = 0.0
    label_rates_by_group: Dict[str, Dict[str, float]] = field(default_factory=dict)
    label_rate_disparities: Dict[str, float] = field(default_factory=dict)
    
    # Proxy analysis
    proxy_variables: List[ProxyVariable] = field(default_factory=list)
    
    # Warnings
    warnings: List[str] = field(default_factory=list)
    
    def summary(self) -> str:
        """Generate human-readable summary."""
        lines = [
            "=" * 50,
            "DATASET BIAS ANALYSIS REPORT",
            "=" * 50,
            "",
            f"Samples: {self.n_samples:,}",
            f"Features: {self.n_features}",
            f"Target: {self.target}",
            f"Protected Attributes: {', '.join(self.protected_attributes)}",
            "",
            f"Overall Positive Rate: {self.overall_positive_rate:.1%}",
            "",
        ]
        
        # Group distributions
        lines.append("GROUP DISTRIBUTIONS")
        lines.append("-" * 30)
        for attr, sizes in self.group_sizes.items():
            lines.append(f"\n{attr}:")
            for group, size in sizes.items():
                prop = self.group_proportions[attr][group]
                lines.append(f"  {group}: {size:,} ({prop:.1%})")
        
        # Label rates
        lines.append("")
        lines.append("\nLABEL RATES BY GROUP")
        lines.append("-" * 30)
        for attr, rates in self.label_rates_by_group.items():
            lines.append(f"\n{attr}:")
            max_rate = max(rates.values())
            min_rate = min(rates.values())
            for group, rate in rates.items():
                gap = ""
                if rate == min_rate and (max_rate - min_rate) > 0.1:
                    gap = f" ({(max_rate - rate)*100:.0f}pp below max)"
                lines.append(f"  {group}: {rate:.1%}{gap}")
            
            disparity = self.label_rate_disparities.get(attr, 0)
            if disparity > 0.1:
                lines.append(f"  * Disparity: {disparity:.1%}")
        
        # Proxy variables
        if self.proxy_variables:
            lines.append("")
            lines.append("\nPOTENTIAL PROXY VARIABLES")
            lines.append("-" * 30)
            for proxy in self.proxy_variables:
                if proxy.is_proxy:
                    lines.append(f"  * '{proxy.feature}' correlated with "
                               f"'{proxy.protected_attribute}' (r={proxy.correlation:.2f})")
        
        # Warnings
        if self.warnings:
            lines.append("")
            lines.append("\nWARNINGS")
            lines.append("-" * 30)
            for warning in self.warnings:
                lines.append(f"  • {warning}")
        
        return "\n".join(lines)
    
    def __str__(self):
        return self.summary()


class DatasetAnalyzer:
    """Analyze datasets for potential biases.
    
    Parameters
    ----------
    data : DataFrame
        The dataset to analyze
    target : str
        Name of the target column
    protected_attributes : list of str
        Names of protected attribute columns
    proxy_threshold : float
        Correlation threshold for flagging proxy variables (default 0.5)
        
    Examples
    --------
    >>> analyzer = DatasetAnalyzer(
    ...     data=df,
    ...     target='hired',
    ...     protected_attributes=['gender', 'race']
    ... )
    >>> report = analyzer.analyze()
    >>> print(report.summary())
    """
    
    def __init__(
        self,
        data: pd.DataFrame,
        target: str,
        protected_attributes: Union[str, List[str]],
        proxy_threshold: float = 0.5,
    ):
        self.data = data.copy()
        self.target = target
        
        if isinstance(protected_attributes, str):
            protected_attributes = [protected_attributes]
        self.protected_attributes = protected_attributes
        self.proxy_threshold = proxy_threshold
        
        # Validate inputs
        self._validate_inputs()
    
    def _validate_inputs(self):
        """Validate that required columns exist."""
        if self.target not in self.data.columns:
            raise ValueError(f"Target column '{self.target}' not found in data")
        
        for attr in self.protected_attributes:
            if attr not in self.data.columns:
                raise ValueError(f"Protected attribute '{attr}' not found in data")
    
    def analyze(self) -> DatasetBiasReport:
        """Perform full bias analysis.
        
        Returns
        -------
        DatasetBiasReport
            Complete analysis report
        """
        report = DatasetBiasReport(
            n_samples=len(self.data),
            n_features=len(self.data.columns) - 1,  # Exclude target
            target=self.target,
            protected_attributes=self.protected_attributes,
        )
        
        # Overall positive rate
        report.overall_positive_rate = self.data[self.target].mean()
        
        # Analyze each protected attribute
        for attr in self.protected_attributes:
            # Group sizes and proportions
            sizes = self.data[attr].value_counts().to_dict()
            proportions = (self.data[attr].value_counts(normalize=True)).to_dict()
            
            report.group_sizes[attr] = sizes
            report.group_proportions[attr] = proportions
            
            # Label rates by group
            label_rates = self.data.groupby(attr)[self.target].mean().to_dict()
            report.label_rates_by_group[attr] = label_rates
            
            # Calculate disparity
            rates = list(label_rates.values())
            disparity = max(rates) - min(rates)
            report.label_rate_disparities[attr] = disparity
            
            # Check for imbalanced groups
            min_prop = min(proportions.values())
            if min_prop < 0.1:
                min_group = min(proportions, key=proportions.get)
                report.warnings.append(
                    f"Group '{min_group}' in '{attr}' is underrepresented ({min_prop:.1%})"
                )
            
            # Check for large disparities
            if disparity > 0.2:
                report.warnings.append(
                    f"Large label rate disparity ({disparity:.1%}) across '{attr}' groups"
                )
        
        # Detect proxy variables
        report.proxy_variables = self._detect_proxies()
        
        return report
    
    def _detect_proxies(self) -> List[ProxyVariable]:
        """Detect features that may be proxies for protected attributes."""
        proxies = []
        
        # Get non-protected feature columns
        feature_cols = [
            col for col in self.data.columns
            if col not in self.protected_attributes and col != self.target
        ]
        
        for feature in feature_cols:
            for attr in self.protected_attributes:
                correlation = self._compute_correlation(feature, attr)
                
                if correlation is not None:
                    is_proxy = abs(correlation) >= self.proxy_threshold
                    proxies.append(ProxyVariable(
                        feature=feature,
                        protected_attribute=attr,
                        correlation=correlation,
                        is_proxy=is_proxy,
                    ))
        
        # Sort by correlation magnitude, keep only significant ones
        proxies.sort(key=lambda x: abs(x.correlation), reverse=True)
        return [p for p in proxies if abs(p.correlation) >= 0.3]
    
    def _compute_correlation(
        self,
        feature: str,
        protected_attr: str
    ) -> Optional[float]:
        """Compute correlation between a feature and protected attribute."""
        try:
            feat_data = self.data[feature]
            attr_data = self.data[protected_attr]
            
            # Convert categorical to numeric if needed
            if feat_data.dtype == 'object':
                feat_numeric = pd.factorize(feat_data)[0]
            else:
                feat_numeric = feat_data.values
            
            if attr_data.dtype == 'object':
                attr_numeric = pd.factorize(attr_data)[0]
            else:
                attr_numeric = attr_data.values
            
            # Compute correlation
            correlation = np.corrcoef(feat_numeric, attr_numeric)[0, 1]
            
            if np.isnan(correlation):
                return None
            
            return correlation
            
        except Exception:
            return None
    
    def get_group_statistics(
        self,
        attribute: str
    ) -> pd.DataFrame:
        """Get detailed statistics for each group.
        
        Parameters
        ----------
        attribute : str
            Protected attribute to analyze
            
        Returns
        -------
        DataFrame
            Statistics for each group
        """
        stats = self.data.groupby(attribute).agg({
            self.target: ['count', 'sum', 'mean']
        })
        stats.columns = ['count', 'positive_count', 'positive_rate']
        stats['proportion'] = stats['count'] / len(self.data)
        
        return stats
    
    def compare_feature_distributions(
        self,
        feature: str,
        attribute: str
    ) -> pd.DataFrame:
        """Compare feature distributions across groups.
        
        Parameters
        ----------
        feature : str
            Feature to analyze
        attribute : str
            Protected attribute for grouping
            
        Returns
        -------
        DataFrame
            Feature statistics by group
        """
        return self.data.groupby(attribute)[feature].describe()


def check_dataset(
    data: pd.DataFrame,
    target: str,
    protected: Union[str, List[str]],
    proxy_threshold: float = 0.5,
) -> DatasetBiasReport:
    """Quick dataset bias check.
    
    Convenience function for one-line dataset analysis.
    
    Parameters
    ----------
    data : DataFrame
        Dataset to analyze
    target : str
        Target column name
    protected : str or list
        Protected attribute column(s)
    proxy_threshold : float
        Correlation threshold for proxy detection
        
    Returns
    -------
    DatasetBiasReport
        Analysis results
        
    Examples
    --------
    >>> report = check_dataset(df, target='hired', protected=['gender', 'race'])
    >>> print(report)
    """
    analyzer = DatasetAnalyzer(
        data=data,
        target=target,
        protected_attributes=protected,
        proxy_threshold=proxy_threshold,
    )
    return analyzer.analyze()
