"""
Real-world fairness dataset fetchers.

Downloads and caches real datasets from OpenML and other public sources.
Use fetch_* for real data (requires network) and load_* for synthetic
(offline, fast, for testing).
"""

import numpy as np
import pandas as pd
from typing import Optional
import warnings
import os

from .loaders import FairnessDataset


# Cache directory
_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".fairlens", "datasets")


def _ensure_cache_dir():
    """Create cache directory if it doesn't exist."""
    os.makedirs(_CACHE_DIR, exist_ok=True)


def _get_cache_path(name: str) -> str:
    """Get cache file path for a dataset."""
    return os.path.join(_CACHE_DIR, f"{name}.csv")


def fetch_adult(cache: bool = True) -> FairnessDataset:
    """Fetch the Adult Census Income dataset from OpenML.

    Downloads the real UCI Adult dataset (OpenML ID 1590) with 48,842
    samples. Falls back to synthetic version on network error.

    Parameters
    ----------
    cache : bool
        If True, cache downloaded data locally.

    Returns
    -------
    FairnessDataset
    """
    cache_path = _get_cache_path("adult")

    if cache and os.path.exists(cache_path):
        data = pd.read_csv(cache_path)
        return _build_adult_dataset(data, source="OpenML (cached)")

    try:
        from sklearn.datasets import fetch_openml
        result = fetch_openml(data_id=1590, as_frame=True, parser="auto")
        data = result.frame

        # Standardize column names
        data.columns = [c.strip().lower().replace('-', '_') for c in data.columns]

        # Convert all categorical columns to plain strings
        for col in data.columns:
            if hasattr(data[col], 'cat'):
                data[col] = data[col].astype(str)

        # Binary target: the OpenML Adult target column is 'class'
        if 'class' in data.columns:
            tc = 'class'
            data['income'] = data[tc].apply(
                lambda x: 1 if '>50K' in str(x) else 0
            )
            data = data.drop(columns=[tc])
        elif 'income' in data.columns:
            data['income'] = pd.to_numeric(data['income'], errors='coerce').fillna(0).astype(int)

        # Ensure protected attributes exist
        if 'sex' not in data.columns:
            for c in data.columns:
                if 'sex' in c.lower() or 'gender' in c.lower():
                    data = data.rename(columns={c: 'sex'})
                    break

        if 'race' not in data.columns:
            for c in data.columns:
                if 'race' in c.lower():
                    data = data.rename(columns={c: 'race'})
                    break

        if cache:
            _ensure_cache_dir()
            data.to_csv(cache_path, index=False)

        return _build_adult_dataset(data, source="OpenML (fetched)")

    except Exception as e:
        warnings.warn(
            f"Could not fetch Adult dataset from OpenML: {e}. "
            f"Falling back to synthetic version."
        )
        from .loaders import load_adult
        return load_adult()


def _build_adult_dataset(data: pd.DataFrame, source: str) -> FairnessDataset:
    """Build FairnessDataset from Adult data."""
    protected = []
    if 'sex' in data.columns:
        protected.append('sex')
    if 'race' in data.columns:
        protected.append('race')
    if not protected:
        protected = ['sex']

    feature_names = [c for c in data.columns if c != 'income']

    return FairnessDataset(
        data=data,
        target='income',
        protected_attributes=protected,
        feature_names=feature_names,
        description='Adult Census Income Dataset',
        source=source,
        name='Adult Census Income',
    )


def fetch_german_credit(cache: bool = True) -> FairnessDataset:
    """Fetch the German Credit dataset from OpenML.

    Downloads the real Statlog German Credit dataset (OpenML ID 31)
    with 1,000 samples. Falls back to synthetic on error.

    Parameters
    ----------
    cache : bool
        If True, cache downloaded data locally.

    Returns
    -------
    FairnessDataset
    """
    cache_path = _get_cache_path("german_credit")

    if cache and os.path.exists(cache_path):
        data = pd.read_csv(cache_path)
        return _build_german_dataset(data, source="OpenML (cached)")

    try:
        from sklearn.datasets import fetch_openml
        result = fetch_openml(data_id=31, as_frame=True, parser="auto")
        data = result.frame

        data.columns = [c.strip().lower().replace('-', '_') for c in data.columns]

        # Binary target
        target_col = [c for c in data.columns if 'class' in c]
        if target_col:
            tc = target_col[0]
            data['credit_risk'] = (data[tc].astype(str).str.strip().isin(['good', '1', '1.0'])).astype(int)
            if tc != 'credit_risk':
                data = data.drop(columns=[tc])

        # Add sex column from personal_status if needed
        if 'sex' not in data.columns and 'personal_status' in data.columns:
            data['sex'] = data['personal_status'].astype(str).apply(
                lambda x: 'male' if 'male' in x.lower() else 'female'
            )

        # Age group
        if 'age' in data.columns:
            data['age'] = pd.to_numeric(data['age'], errors='coerce').fillna(30).astype(int)
            data['age_group'] = np.where(
                data['age'] < 25, 'young',
                np.where(data['age'] >= 60, 'senior', 'adult')
            )

        if cache:
            _ensure_cache_dir()
            data.to_csv(cache_path, index=False)

        return _build_german_dataset(data, source="OpenML (fetched)")

    except Exception as e:
        warnings.warn(
            f"Could not fetch German Credit from OpenML: {e}. "
            f"Falling back to synthetic version."
        )
        from .loaders import load_german_credit
        return load_german_credit()


def _build_german_dataset(data: pd.DataFrame, source: str) -> FairnessDataset:
    """Build FairnessDataset from German Credit data."""
    protected = []
    if 'sex' in data.columns:
        protected.append('sex')
    if 'age_group' in data.columns:
        protected.append('age_group')
    if not protected:
        protected = ['sex']

    target = 'credit_risk' if 'credit_risk' in data.columns else data.columns[-1]
    feature_names = [c for c in data.columns if c != target]

    return FairnessDataset(
        data=data,
        target=target,
        protected_attributes=protected,
        feature_names=feature_names,
        description='German Credit Dataset',
        source=source,
        name='German Credit',
    )


def fetch_compas(cache: bool = True) -> FairnessDataset:
    """Fetch the COMPAS Recidivism dataset from ProPublica.

    Downloads the real COMPAS dataset from ProPublica's GitHub repository.
    Falls back to synthetic on error.

    Parameters
    ----------
    cache : bool
        If True, cache downloaded data locally.

    Returns
    -------
    FairnessDataset
    """
    cache_path = _get_cache_path("compas")

    if cache and os.path.exists(cache_path):
        data = pd.read_csv(cache_path)
        return _build_compas_dataset(data, source="ProPublica (cached)")

    try:
        url = (
            "https://raw.githubusercontent.com/propublica/"
            "compas-analysis/master/compas-scores-two-years.csv"
        )
        raw = pd.read_csv(url)

        # Filter and select columns (following ProPublica methodology)
        cols_keep = [
            'age', 'sex', 'race', 'priors_count', 'c_charge_degree',
            'juv_fel_count', 'two_year_recid'
        ]
        available = [c for c in cols_keep if c in raw.columns]
        data = raw[available].copy()
        data = data.dropna()

        if 'c_charge_degree' in data.columns:
            data = data.rename(columns={'c_charge_degree': 'charge_degree'})

        if cache:
            _ensure_cache_dir()
            data.to_csv(cache_path, index=False)

        return _build_compas_dataset(data, source="ProPublica (fetched)")

    except Exception as e:
        warnings.warn(
            f"Could not fetch COMPAS dataset: {e}. "
            f"Falling back to synthetic version."
        )
        from .loaders import load_compas
        return load_compas()


def _build_compas_dataset(data: pd.DataFrame, source: str) -> FairnessDataset:
    """Build FairnessDataset from COMPAS data."""
    protected = []
    if 'race' in data.columns:
        protected.append('race')
    if 'sex' in data.columns:
        protected.append('sex')
    if not protected:
        protected = ['race']

    target = 'two_year_recid'
    feature_names = [c for c in data.columns if c != target]

    return FairnessDataset(
        data=data,
        target=target,
        protected_attributes=protected,
        feature_names=feature_names,
        description='COMPAS Recidivism Dataset',
        source=source,
        name='COMPAS Recidivism',
    )


# Dataset registry for fetch_dataset
_FETCH_REGISTRY = {
    'adult': fetch_adult,
    'german_credit': fetch_german_credit,
    'compas': fetch_compas,
}


def fetch_dataset(name: str, cache: bool = True) -> FairnessDataset:
    """Fetch a real-world dataset by name.

    Parameters
    ----------
    name : str
        Dataset name ('adult', 'german_credit', 'compas').
    cache : bool
        Whether to cache downloaded data.

    Returns
    -------
    FairnessDataset
    """
    if name not in _FETCH_REGISTRY:
        available = list(_FETCH_REGISTRY.keys())
        raise ValueError(
            f"Unknown dataset '{name}'. Available: {available}"
        )
    return _FETCH_REGISTRY[name](cache=cache)
