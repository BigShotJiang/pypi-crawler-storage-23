"""
Individual fairness metrics.

Individual fairness requires that similar individuals receive similar predictions.
Unlike group fairness which looks at aggregate statistics, individual fairness
examines consistency at the individual level.
"""

import numpy as np
from typing import Callable, Optional, Tuple
from dataclasses import dataclass


@dataclass
class IndividualFairnessMetrics:
    """Container for individual fairness metrics."""
    consistency_score: float
    lipschitz_violation_rate: float
    average_inconsistency: float
    max_inconsistency: float
    
    def summary(self) -> str:
        lines = [
            "=== Individual Fairness Metrics ===",
            f"Consistency Score: {self.consistency_score:.3f}",
            f"Lipschitz Violation Rate: {self.lipschitz_violation_rate:.3f}",
            f"Average Inconsistency: {self.average_inconsistency:.4f}",
            f"Max Inconsistency: {self.max_inconsistency:.4f}",
        ]
        return "\n".join(lines)


def euclidean_distance(x1: np.ndarray, x2: np.ndarray) -> float:
    """Compute Euclidean distance between two points."""
    return np.sqrt(np.sum((x1 - x2) ** 2))


def consistency_score(
    X: np.ndarray,
    y_pred: np.ndarray,
    n_neighbors: int = 5,
    distance_fn: Optional[Callable] = None
) -> float:
    """Calculate consistency score.
    
    Measures how often similar individuals receive the same prediction.
    For each sample, check if its k nearest neighbors have the same prediction.
    
    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)
        Feature matrix
    y_pred : array-like
        Predicted labels
    n_neighbors : int
        Number of neighbors to consider
    distance_fn : callable, optional
        Distance function. Defaults to Euclidean.
        
    Returns
    -------
    float
        Consistency score between 0 and 1. Higher is better.
    """
    X = np.asarray(X)
    y_pred = np.asarray(y_pred).ravel()
    
    if distance_fn is None:
        distance_fn = euclidean_distance
    
    n_samples = len(X)
    n_neighbors = min(n_neighbors, n_samples - 1)
    
    if n_neighbors <= 0:
        return 1.0
    
    consistency_sum = 0.0
    
    for i in range(n_samples):
        # Calculate distances to all other points
        distances = []
        for j in range(n_samples):
            if i != j:
                dist = distance_fn(X[i], X[j])
                distances.append((dist, j))
        
        # Sort by distance and get k nearest neighbors
        distances.sort(key=lambda x: x[0])
        neighbors = [idx for _, idx in distances[:n_neighbors]]
        
        # Check consistency with neighbors
        same_prediction = sum(1 for j in neighbors if y_pred[j] == y_pred[i])
        consistency_sum += same_prediction / n_neighbors
    
    return consistency_sum / n_samples


def lipschitz_violations(
    X: np.ndarray,
    y_pred: np.ndarray,
    lipschitz_constant: float = 1.0,
    distance_fn: Optional[Callable] = None,
    sample_size: Optional[int] = None
) -> Tuple[float, float, float]:
    """Check for Lipschitz condition violations.
    
    Individual fairness can be formalized as requiring:
    d(f(x1), f(x2)) <= L * d(x1, x2)
    
    where L is the Lipschitz constant, d is a distance metric,
    and f is the prediction function.
    
    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)
        Feature matrix
    y_pred : array-like
        Predicted labels or probabilities
    lipschitz_constant : float
        Maximum allowed ratio of output to input distance
    distance_fn : callable, optional
        Distance function for input space
    sample_size : int, optional
        Number of pairs to sample (for efficiency)
        
    Returns
    -------
    violation_rate : float
        Fraction of pairs violating the Lipschitz condition
    avg_violation : float
        Average magnitude of violations
    max_violation : float
        Maximum violation magnitude
    """
    X = np.asarray(X)
    y_pred = np.asarray(y_pred).ravel()
    
    if distance_fn is None:
        distance_fn = euclidean_distance
    
    n_samples = len(X)
    
    # Generate pairs to check
    if sample_size is None:
        # Check all pairs (O(n^2))
        pairs = [(i, j) for i in range(n_samples) for j in range(i+1, n_samples)]
    else:
        # Random sampling for large datasets
        np.random.seed(42)
        pairs = []
        for _ in range(sample_size):
            i, j = np.random.choice(n_samples, size=2, replace=False)
            pairs.append((i, j))
    
    if len(pairs) == 0:
        return 0.0, 0.0, 0.0
    
    violations = []
    
    for i, j in pairs:
        input_dist = distance_fn(X[i], X[j])
        output_dist = abs(float(y_pred[i]) - float(y_pred[j]))
        
        if input_dist > 0:
            ratio = output_dist / input_dist
            if ratio > lipschitz_constant:
                violations.append(ratio - lipschitz_constant)
    
    if len(violations) == 0:
        return 0.0, 0.0, 0.0
    
    violation_rate = len(violations) / len(pairs)
    avg_violation = np.mean(violations)
    max_violation = max(violations)
    
    return violation_rate, avg_violation, max_violation


def counterfactual_fairness_score(
    X: np.ndarray,
    y_pred: np.ndarray,
    protected_idx: int,
    model_predict: Callable
) -> float:
    """Measure counterfactual fairness.
    
    Checks if predictions would change if we flip the protected attribute
    while keeping everything else the same.
    
    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)
        Feature matrix
    y_pred : array-like
        Original predictions
    protected_idx : int
        Index of the protected attribute column
    model_predict : callable
        Function that takes X and returns predictions
        
    Returns
    -------
    float
        Fraction of samples with same prediction under counterfactual.
        Higher is better (1.0 means perfectly counterfactually fair).
    """
    X = np.asarray(X).copy()
    y_pred = np.asarray(y_pred).ravel()
    
    # Get unique values of protected attribute
    protected_values = np.unique(X[:, protected_idx])
    
    if len(protected_values) != 2:
        raise ValueError(
            "Counterfactual fairness requires binary protected attribute"
        )
    
    # Create counterfactual by flipping protected attribute
    X_cf = X.copy()
    flip_map = {protected_values[0]: protected_values[1],
                protected_values[1]: protected_values[0]}
    
    for i in range(len(X)):
        X_cf[i, protected_idx] = flip_map[X[i, protected_idx]]
    
    # Get counterfactual predictions
    y_pred_cf = model_predict(X_cf)
    
    # Calculate fraction with same prediction
    same_prediction = np.sum(y_pred == y_pred_cf)
    return same_prediction / len(y_pred)


def compute_individual_fairness_metrics(
    X: np.ndarray,
    y_pred: np.ndarray,
    n_neighbors: int = 5,
    lipschitz_constant: float = 1.0,
    sample_size: Optional[int] = 1000
) -> IndividualFairnessMetrics:
    """Compute all individual fairness metrics.
    
    Parameters
    ----------
    X : array-like
        Feature matrix
    y_pred : array-like
        Predictions
    n_neighbors : int
        For consistency score
    lipschitz_constant : float
        For Lipschitz violations
    sample_size : int, optional
        Number of pairs to sample for Lipschitz check
        
    Returns
    -------
    IndividualFairnessMetrics
        All individual fairness metrics
    """
    cs = consistency_score(X, y_pred, n_neighbors)
    
    # Limit sample size for efficiency
    if sample_size is not None and len(X) > 100:
        actual_sample = min(sample_size, len(X) * (len(X) - 1) // 2)
    else:
        actual_sample = None
    
    violation_rate, avg_violation, max_violation = lipschitz_violations(
        X, y_pred, lipschitz_constant, sample_size=actual_sample
    )
    
    return IndividualFairnessMetrics(
        consistency_score=cs,
        lipschitz_violation_rate=violation_rate,
        average_inconsistency=avg_violation,
        max_inconsistency=max_violation,
    )
