"""
Intersectional fairness analysis.

Supports analyzing fairness across multiple protected attributes
simultaneously (e.g. gender x race), revealing disparities hidden
when attributes are examined independently.
"""

import numpy as np
from typing import Union, Dict, List, Optional
from dataclasses import dataclass, field

from .group_fairness import (
    _validate_inputs,
    _get_groups,
    positive_rate,
    true_positive_rate,
    false_positive_rate,
    demographic_parity_ratio,
    equalized_odds_ratio,
)


@dataclass
class IntersectionalFairnessReport:
    """Results from intersectional fairness analysis."""
    attributes: List[str]
    intersection_groups: List[str]
    group_sizes: Dict[str, int]
    positive_rate_by_group: Dict[str, float]
    tpr_by_group: Dict[str, float]
    fpr_by_group: Dict[str, float]
    demographic_parity_ratio: float
    demographic_parity_difference: float
    equalized_odds_ratio: float
    equalized_odds_difference: float
    per_attribute_dp_ratio: Dict[str, float]

    def summary(self) -> str:
        """Return human-readable summary."""
        lines = [
            "=== Intersectional Fairness Report ===",
            f"Attributes: {', '.join(self.attributes)}",
            f"Intersection Groups: {len(self.intersection_groups)}",
            "",
            f"Demographic Parity Ratio: {self.demographic_parity_ratio:.3f}",
            f"Demographic Parity Difference: {self.demographic_parity_difference:.3f}",
            f"Equalized Odds Ratio: {self.equalized_odds_ratio:.3f}",
            f"Equalized Odds Difference: {self.equalized_odds_difference:.3f}",
            "",
            "Per-Attribute DP Ratios:",
        ]
        for attr, ratio in self.per_attribute_dp_ratio.items():
            lines.append(f"  {attr}: {ratio:.3f}")

        lines.append("")
        lines.append("Positive Rates by Intersection Group:")
        for group in self.intersection_groups:
            rate = self.positive_rate_by_group[group]
            size = self.group_sizes[group]
            lines.append(f"  {group} (n={size}): {rate:.1%}")

        return "\n".join(lines)

    def __str__(self):
        return self.summary()


def create_intersection_groups(
    protected_attrs: Dict[str, Union[np.ndarray, 'pd.Series']],
    separator: str = "_",
) -> np.ndarray:
    """Create intersection groups from multiple protected attributes.

    Combines multiple attribute arrays into a single array where each unique
    combination becomes a group label (e.g. "Male_White", "Female_Black").

    Parameters
    ----------
    protected_attrs : dict
        Mapping of attribute name to array of values.
    separator : str
        String used to join attribute values.

    Returns
    -------
    np.ndarray
        Array of intersection group labels.

    Examples
    --------
    >>> attrs = {'gender': ['M', 'F', 'M'], 'race': ['W', 'B', 'B']}
    >>> create_intersection_groups(attrs)
    array(['M_W', 'F_B', 'M_B'], dtype='<U3')
    """
    if not protected_attrs:
        raise ValueError("protected_attrs must contain at least one attribute")

    arrays = {}
    length = None
    for name, arr in protected_attrs.items():
        arr = np.asarray(arr).ravel()
        if length is None:
            length = len(arr)
        elif len(arr) != length:
            raise ValueError(
                f"All attribute arrays must have same length. "
                f"'{name}' has length {len(arr)}, expected {length}"
            )
        arrays[name] = arr

    names = sorted(arrays.keys())
    result = np.array([
        separator.join(str(arrays[name][i]) for name in names)
        for i in range(length)
    ])
    return result


def compute_intersectional_metrics(
    y_true: Union[np.ndarray, 'pd.Series'],
    y_pred: Union[np.ndarray, 'pd.Series'],
    protected_attrs: Dict[str, Union[np.ndarray, 'pd.Series']],
    separator: str = "_",
) -> IntersectionalFairnessReport:
    """Compute fairness metrics across intersectional groups.

    Analyzes fairness using the Cartesian product of multiple protected
    attributes, revealing disparities that single-attribute analysis misses.

    Parameters
    ----------
    y_true : array-like
        True binary labels.
    y_pred : array-like
        Predicted binary labels.
    protected_attrs : dict
        Mapping of attribute name to array of values.
    separator : str
        String used to join attribute values in group labels.

    Returns
    -------
    IntersectionalFairnessReport

    Examples
    --------
    >>> attrs = {'gender': gender_arr, 'race': race_arr}
    >>> report = compute_intersectional_metrics(y_true, y_pred, attrs)
    >>> print(report)
    """
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()

    if len(y_true) != len(y_pred):
        raise ValueError(
            f"y_true and y_pred must have same length. "
            f"Got {len(y_true)} and {len(y_pred)}"
        )

    # Create intersection groups
    intersection = create_intersection_groups(protected_attrs, separator)

    if len(intersection) != len(y_true):
        raise ValueError(
            f"Protected attributes length ({len(intersection)}) must match "
            f"y_true length ({len(y_true)})"
        )

    groups = sorted(list(set(intersection)))

    # Compute per-group metrics
    group_sizes = {}
    pos_rates = {}
    tpr_rates = {}
    fpr_rates = {}

    for group in groups:
        mask = intersection == group
        group_str = str(group)
        group_sizes[group_str] = int(mask.sum())
        pos_rates[group_str] = float(positive_rate(y_pred, mask))
        tpr_rates[group_str] = float(true_positive_rate(y_true, y_pred, mask))
        fpr_rates[group_str] = float(false_positive_rate(y_true, y_pred, mask))

    # Compute aggregate DP and EO on intersection groups
    dp_ratio = demographic_parity_ratio(y_pred, intersection)
    eo_ratio = equalized_odds_ratio(y_true, y_pred, intersection)

    pos_vals = list(pos_rates.values())
    dp_diff = max(pos_vals) - min(pos_vals) if pos_vals else 0.0

    tpr_vals = list(tpr_rates.values())
    fpr_vals = list(fpr_rates.values())
    tpr_diff = max(tpr_vals) - min(tpr_vals) if tpr_vals else 0.0
    fpr_diff = max(fpr_vals) - min(fpr_vals) if fpr_vals else 0.0
    eo_diff = max(tpr_diff, fpr_diff)

    # Per-attribute DP ratios for comparison
    attr_names = sorted(protected_attrs.keys())
    per_attr_dp = {}
    for name in attr_names:
        attr_arr = np.asarray(protected_attrs[name]).ravel()
        per_attr_dp[name] = float(demographic_parity_ratio(y_pred, attr_arr))

    return IntersectionalFairnessReport(
        attributes=attr_names,
        intersection_groups=groups,
        group_sizes=group_sizes,
        positive_rate_by_group=pos_rates,
        tpr_by_group=tpr_rates,
        fpr_by_group=fpr_rates,
        demographic_parity_ratio=dp_ratio,
        demographic_parity_difference=dp_diff,
        equalized_odds_ratio=eo_ratio,
        equalized_odds_difference=eo_diff,
        per_attribute_dp_ratio=per_attr_dp,
    )
