"""
Group fairness metrics for ML models.

This module implements the core group fairness metrics used to evaluate
whether a model treats different demographic groups equitably.
"""

import numpy as np
from typing import Union, Tuple, Dict, List, Optional
from dataclasses import dataclass


@dataclass
class GroupFairnessMetrics:
    """Container for group fairness metric results."""
    demographic_parity_ratio: float
    demographic_parity_difference: float
    equalized_odds_ratio: float
    equalized_odds_difference: float
    positive_rate_by_group: Dict[str, float]
    tpr_by_group: Dict[str, float]
    fpr_by_group: Dict[str, float]
    group_sizes: Dict[str, int]
    
    def is_fair(self, threshold: float = 0.8) -> bool:
        """Check if model meets basic fairness criteria."""
        return (self.demographic_parity_ratio >= threshold and 
                self.equalized_odds_ratio >= threshold)
    
    def summary(self) -> str:
        """Return human-readable summary of metrics."""
        lines = [
            "=== Group Fairness Metrics ===",
            f"Demographic Parity Ratio: {self.demographic_parity_ratio:.3f}",
            f"Demographic Parity Difference: {self.demographic_parity_difference:.3f}",
            f"Equalized Odds Ratio: {self.equalized_odds_ratio:.3f}",
            f"Equalized Odds Difference: {self.equalized_odds_difference:.3f}",
            "",
            "Positive Prediction Rates by Group:",
        ]
        for group, rate in self.positive_rate_by_group.items():
            lines.append(f"  {group}: {rate:.1%}")
        
        lines.append("")
        lines.append("True Positive Rates by Group:")
        for group, rate in self.tpr_by_group.items():
            lines.append(f"  {group}: {rate:.1%}")
            
        lines.append("")
        lines.append("False Positive Rates by Group:")
        for group, rate in self.fpr_by_group.items():
            lines.append(f"  {group}: {rate:.1%}")
            
        return "\n".join(lines)


def _validate_inputs(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    protected_attribute: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Validate and convert inputs to numpy arrays."""
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()
    
    if len(y_true) != len(y_pred) or len(y_true) != len(protected_attribute):
        raise ValueError(
            f"Input arrays must have same length. Got y_true={len(y_true)}, "
            f"y_pred={len(y_pred)}, protected_attribute={len(protected_attribute)}"
        )
    
    if len(y_true) == 0:
        raise ValueError("Input arrays cannot be empty")
    
    return y_true, y_pred, protected_attribute


def _get_groups(protected_attribute: np.ndarray) -> List:
    """Get unique groups from protected attribute."""
    return sorted(list(set(protected_attribute)))


def positive_rate(y_pred: np.ndarray, mask: Optional[np.ndarray] = None) -> float:
    """Calculate the positive prediction rate.
    
    Parameters
    ----------
    y_pred : array-like
        Predicted labels (0 or 1)
    mask : array-like, optional
        Boolean mask to filter predictions
        
    Returns
    -------
    float
        Proportion of positive predictions
    """
    y_pred = np.asarray(y_pred)
    if mask is not None:
        y_pred = y_pred[mask]
    if len(y_pred) == 0:
        return 0.0
    return np.mean(y_pred)


def true_positive_rate(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> float:
    """Calculate true positive rate (sensitivity/recall).
    
    TPR = TP / (TP + FN) = P(Ŷ=1 | Y=1)
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred : array-like
        Predicted labels
    mask : array-like, optional
        Boolean mask to filter samples
        
    Returns
    -------
    float
        True positive rate
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    
    if mask is not None:
        y_true = y_true[mask]
        y_pred = y_pred[mask]
    
    positives = y_true == 1
    if positives.sum() == 0:
        return 0.0
    return np.mean(y_pred[positives])


def false_positive_rate(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> float:
    """Calculate false positive rate.
    
    FPR = FP / (FP + TN) = P(Ŷ=1 | Y=0)
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred : array-like
        Predicted labels
    mask : array-like, optional
        Boolean mask to filter samples
        
    Returns
    -------
    float
        False positive rate
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    
    if mask is not None:
        y_true = y_true[mask]
        y_pred = y_pred[mask]
    
    negatives = y_true == 0
    if negatives.sum() == 0:
        return 0.0
    return np.mean(y_pred[negatives])


def demographic_parity_ratio(
    y_pred: np.ndarray,
    protected_attribute: np.ndarray
) -> float:
    """Calculate demographic parity ratio.
    
    Demographic parity requires that the positive prediction rate is equal
    across all groups. The ratio is min(rate) / max(rate), where values
    closer to 1.0 indicate better fairness.
    
    Parameters
    ----------
    y_pred : array-like
        Predicted labels (0 or 1)
    protected_attribute : array-like
        Protected attribute values for each sample
        
    Returns
    -------
    float
        Ratio of minimum to maximum positive rate across groups.
        Values range from 0 to 1, with 1 being perfectly fair.
        
    Examples
    --------
    >>> y_pred = [1, 1, 0, 0, 1, 0]
    >>> protected = ['A', 'A', 'A', 'B', 'B', 'B']
    >>> demographic_parity_ratio(y_pred, protected)
    0.666...
    """
    y_pred = np.asarray(y_pred).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()
    
    groups = _get_groups(protected_attribute)
    rates = []
    
    for group in groups:
        mask = protected_attribute == group
        rate = positive_rate(y_pred, mask)
        rates.append(rate)
    
    min_rate = min(rates)
    max_rate = max(rates)
    
    if max_rate == 0:
        return 1.0  # No positive predictions in any group
    
    return min_rate / max_rate


def demographic_parity_difference(
    y_pred: np.ndarray,
    protected_attribute: np.ndarray
) -> float:
    """Calculate demographic parity difference.
    
    The absolute difference between the maximum and minimum positive
    prediction rates across groups. Values closer to 0 indicate better fairness.
    
    Parameters
    ----------
    y_pred : array-like
        Predicted labels (0 or 1)
    protected_attribute : array-like
        Protected attribute values for each sample
        
    Returns
    -------
    float
        Absolute difference between max and min positive rates.
        Values range from 0 to 1, with 0 being perfectly fair.
    """
    y_pred = np.asarray(y_pred).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()
    
    groups = _get_groups(protected_attribute)
    rates = []
    
    for group in groups:
        mask = protected_attribute == group
        rate = positive_rate(y_pred, mask)
        rates.append(rate)
    
    return max(rates) - min(rates)


def equalized_odds_ratio(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    protected_attribute: np.ndarray
) -> float:
    """Calculate equalized odds ratio.
    
    Equalized odds requires that TPR and FPR are equal across groups.
    This returns the minimum of the TPR ratio and FPR ratio across groups.
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred : array-like
        Predicted labels
    protected_attribute : array-like
        Protected attribute values for each sample
        
    Returns
    -------
    float
        Minimum of TPR ratio and FPR ratio. Values range from 0 to 1,
        with 1 being perfectly fair.
    """
    y_true, y_pred, protected_attribute = _validate_inputs(
        y_true, y_pred, protected_attribute
    )
    
    groups = _get_groups(protected_attribute)
    tprs = []
    fprs = []
    
    for group in groups:
        mask = protected_attribute == group
        tpr = true_positive_rate(y_true, y_pred, mask)
        fpr = false_positive_rate(y_true, y_pred, mask)
        tprs.append(tpr)
        fprs.append(fpr)
    
    # Calculate ratios (min/max), handling edge cases
    def safe_ratio(values):
        min_val = min(values)
        max_val = max(values)
        if max_val == 0:
            return 1.0
        return min_val / max_val
    
    tpr_ratio = safe_ratio(tprs)
    fpr_ratio = safe_ratio(fprs)
    
    return min(tpr_ratio, fpr_ratio)


def equalized_odds_difference(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    protected_attribute: np.ndarray
) -> float:
    """Calculate equalized odds difference.
    
    Returns the maximum of |TPR difference| and |FPR difference| across groups.
    Values closer to 0 indicate better fairness.
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred : array-like
        Predicted labels
    protected_attribute : array-like
        Protected attribute values for each sample
        
    Returns
    -------
    float
        Maximum of TPR difference and FPR difference.
        Values range from 0 to 1, with 0 being perfectly fair.
    """
    y_true, y_pred, protected_attribute = _validate_inputs(
        y_true, y_pred, protected_attribute
    )
    
    groups = _get_groups(protected_attribute)
    tprs = []
    fprs = []
    
    for group in groups:
        mask = protected_attribute == group
        tpr = true_positive_rate(y_true, y_pred, mask)
        fpr = false_positive_rate(y_true, y_pred, mask)
        tprs.append(tpr)
        fprs.append(fpr)
    
    tpr_diff = max(tprs) - min(tprs)
    fpr_diff = max(fprs) - min(fprs)
    
    return max(tpr_diff, fpr_diff)


def compute_group_fairness_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    protected_attribute: np.ndarray
) -> GroupFairnessMetrics:
    """Compute all group fairness metrics.
    
    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred : array-like
        Predicted labels
    protected_attribute : array-like
        Protected attribute values for each sample
        
    Returns
    -------
    GroupFairnessMetrics
        Dataclass containing all computed metrics
    """
    y_true, y_pred, protected_attribute = _validate_inputs(
        y_true, y_pred, protected_attribute
    )
    
    groups = _get_groups(protected_attribute)
    
    positive_rates = {}
    tpr_rates = {}
    fpr_rates = {}
    sizes = {}
    
    for group in groups:
        mask = protected_attribute == group
        group_str = str(group)
        positive_rates[group_str] = positive_rate(y_pred, mask)
        tpr_rates[group_str] = true_positive_rate(y_true, y_pred, mask)
        fpr_rates[group_str] = false_positive_rate(y_true, y_pred, mask)
        sizes[group_str] = int(mask.sum())
    
    return GroupFairnessMetrics(
        demographic_parity_ratio=demographic_parity_ratio(y_pred, protected_attribute),
        demographic_parity_difference=demographic_parity_difference(y_pred, protected_attribute),
        equalized_odds_ratio=equalized_odds_ratio(y_true, y_pred, protected_attribute),
        equalized_odds_difference=equalized_odds_difference(y_true, y_pred, protected_attribute),
        positive_rate_by_group=positive_rates,
        tpr_by_group=tpr_rates,
        fpr_by_group=fpr_rates,
        group_sizes=sizes,
    )
