"""
Multi-class fairness metrics.

Extends fairness analysis beyond binary classification via one-vs-rest
decomposition. For each class, binary metrics are computed by treating
that class as the positive class, then aggregated.
"""

import numpy as np
from typing import Union, Dict, List, Optional
from dataclasses import dataclass, field

from .group_fairness import (
    GroupFairnessMetrics,
    compute_group_fairness_metrics,
    demographic_parity_ratio,
)


@dataclass
class MulticlassFairnessReport:
    """Results from multi-class fairness analysis."""
    classes: List[str]
    per_class_metrics: Dict[str, GroupFairnessMetrics]
    worst_class: str
    worst_dp_ratio: float
    macro_avg_dp_ratio: float

    def summary(self) -> str:
        """Return human-readable summary."""
        lines = [
            "=== Multi-class Fairness Report ===",
            f"Classes: {len(self.classes)}",
            f"Macro-Avg DP Ratio: {self.macro_avg_dp_ratio:.3f}",
            f"Worst Class: {self.worst_class} (DP Ratio: {self.worst_dp_ratio:.3f})",
            "",
            "Per-Class Demographic Parity Ratios:",
        ]
        for cls in self.classes:
            m = self.per_class_metrics[cls]
            lines.append(f"  {cls}: {m.demographic_parity_ratio:.3f}")
        return "\n".join(lines)

    def __str__(self):
        return self.summary()


def compute_multiclass_fairness(
    y_true: Union[np.ndarray, 'pd.Series'],
    y_pred: Union[np.ndarray, 'pd.Series'],
    protected_attribute: Union[np.ndarray, 'pd.Series'],
    classes: Optional[List] = None,
) -> MulticlassFairnessReport:
    """Compute fairness metrics for multi-class classification.

    Uses one-vs-rest decomposition: for each class c, creates binary
    labels (y == c) and computes standard group fairness metrics.

    Parameters
    ----------
    y_true : array-like
        True class labels.
    y_pred : array-like
        Predicted class labels.
    protected_attribute : array-like
        Protected attribute values.
    classes : list, optional
        Class labels to evaluate. If None, inferred from y_true.

    Returns
    -------
    MulticlassFairnessReport

    Examples
    --------
    >>> report = compute_multiclass_fairness(y_true, y_pred, protected)
    >>> print(report.worst_class)
    """
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()

    if len(y_true) != len(y_pred) or len(y_true) != len(protected_attribute):
        raise ValueError(
            f"Input arrays must have same length. Got y_true={len(y_true)}, "
            f"y_pred={len(y_pred)}, protected_attribute={len(protected_attribute)}"
        )

    if len(y_true) == 0:
        raise ValueError("Input arrays cannot be empty")

    if classes is None:
        classes = sorted(list(set(y_true)))

    class_labels = [str(c) for c in classes]

    per_class = {}
    dp_ratios = {}

    for cls, cls_label in zip(classes, class_labels):
        # One-vs-rest binarization
        y_true_binary = (y_true == cls).astype(int)
        y_pred_binary = (y_pred == cls).astype(int)

        metrics = compute_group_fairness_metrics(
            y_true_binary, y_pred_binary, protected_attribute
        )
        per_class[cls_label] = metrics
        dp_ratios[cls_label] = metrics.demographic_parity_ratio

    # Find worst class
    worst_class = min(dp_ratios, key=dp_ratios.get)
    worst_dp = dp_ratios[worst_class]

    # Macro average
    macro_avg = sum(dp_ratios.values()) / len(dp_ratios)

    return MulticlassFairnessReport(
        classes=class_labels,
        per_class_metrics=per_class,
        worst_class=worst_class,
        worst_dp_ratio=worst_dp,
        macro_avg_dp_ratio=macro_avg,
    )


def multiclass_demographic_parity(
    y_true: Union[np.ndarray, 'pd.Series'],
    y_pred: Union[np.ndarray, 'pd.Series'],
    protected_attribute: Union[np.ndarray, 'pd.Series'],
    classes: Optional[List] = None,
) -> Dict[str, float]:
    """Compute per-class demographic parity ratios.

    Convenience function that returns just the DP ratio for each class
    via one-vs-rest decomposition.

    Parameters
    ----------
    y_true : array-like
        True class labels.
    y_pred : array-like
        Predicted class labels.
    protected_attribute : array-like
        Protected attribute values.
    classes : list, optional
        Class labels to evaluate.

    Returns
    -------
    dict
        Mapping of class label to demographic parity ratio.
    """
    y_pred = np.asarray(y_pred).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()

    if classes is None:
        y_true_arr = np.asarray(y_true).ravel()
        classes = sorted(list(set(y_true_arr)))

    result = {}
    for cls in classes:
        y_pred_binary = (y_pred == cls).astype(int)
        result[str(cls)] = float(
            demographic_parity_ratio(y_pred_binary, protected_attribute)
        )

    return result
