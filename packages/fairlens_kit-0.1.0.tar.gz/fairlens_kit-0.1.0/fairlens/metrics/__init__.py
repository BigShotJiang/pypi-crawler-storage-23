"""
FairLens metrics module.

Provides fairness metrics for evaluating ML models:
- Group fairness: demographic parity, equalized odds
- Calibration: expected calibration error, Brier score
- Individual fairness: consistency, Lipschitz violations
"""

from .group_fairness import (
    demographic_parity_ratio,
    demographic_parity_difference,
    equalized_odds_ratio,
    equalized_odds_difference,
    true_positive_rate,
    false_positive_rate,
    positive_rate,
    compute_group_fairness_metrics,
    GroupFairnessMetrics,
)

from .calibration import (
    expected_calibration_error,
    max_calibration_error,
    brier_score,
    calibration_curve,
    calibration_error_by_group,
    compute_calibration_metrics,
    CalibrationMetrics,
)

from .individual import (
    consistency_score,
    lipschitz_violations,
    counterfactual_fairness_score,
    compute_individual_fairness_metrics,
    IndividualFairnessMetrics,
)

from .intersectional import (
    create_intersection_groups,
    compute_intersectional_metrics,
    IntersectionalFairnessReport,
)

from .bootstrap import (
    bootstrap_metric,
    ConfidenceInterval,
)

from .multiclass import (
    compute_multiclass_fairness,
    multiclass_demographic_parity,
    MulticlassFairnessReport,
)


__all__ = [
    # Group fairness
    "demographic_parity_ratio",
    "demographic_parity_difference",
    "equalized_odds_ratio",
    "equalized_odds_difference",
    "true_positive_rate",
    "false_positive_rate",
    "positive_rate",
    "compute_group_fairness_metrics",
    "GroupFairnessMetrics",
    # Calibration
    "expected_calibration_error",
    "max_calibration_error",
    "brier_score",
    "calibration_curve",
    "calibration_error_by_group",
    "compute_calibration_metrics",
    "CalibrationMetrics",
    # Individual fairness
    "consistency_score",
    "lipschitz_violations",
    "counterfactual_fairness_score",
    "compute_individual_fairness_metrics",
    "IndividualFairnessMetrics",
    # Intersectional
    "create_intersection_groups",
    "compute_intersectional_metrics",
    "IntersectionalFairnessReport",
    # Bootstrap
    "bootstrap_metric",
    "ConfidenceInterval",
    # Multiclass
    "compute_multiclass_fairness",
    "multiclass_demographic_parity",
    "MulticlassFairnessReport",
]
