"""
Bootstrap confidence intervals for fairness metrics.

Wraps any metric function with bootstrap resampling to provide
confidence intervals and standard errors for statistical rigor.
"""

import numpy as np
from typing import Callable, Union, Optional
from dataclasses import dataclass


@dataclass
class ConfidenceInterval:
    """Bootstrap confidence interval for a metric."""
    estimate: float
    lower: float
    upper: float
    std_error: float
    confidence_level: float
    n_bootstrap: int

    def contains(self, value: float) -> bool:
        """Check whether a value falls within this interval.

        Parameters
        ----------
        value : float
            Value to check.

        Returns
        -------
        bool
        """
        return self.lower <= value <= self.upper

    def summary(self) -> str:
        """Return human-readable summary."""
        pct = int(self.confidence_level * 100)
        lines = [
            "=== Bootstrap Confidence Interval ===",
            f"Point Estimate: {self.estimate:.4f}",
            f"{pct}% CI: [{self.lower:.4f}, {self.upper:.4f}]",
            f"Std Error: {self.std_error:.4f}",
            f"Bootstrap Samples: {self.n_bootstrap}",
        ]
        return "\n".join(lines)

    def __str__(self):
        return self.summary()


def bootstrap_metric(
    metric_fn: Callable,
    *args,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    random_state: Optional[int] = None,
) -> ConfidenceInterval:
    """Compute a bootstrap confidence interval for any metric function.

    Resamples all input arrays with the same indices and computes the
    metric on each resample, then returns a percentile confidence interval.

    Parameters
    ----------
    metric_fn : callable
        Metric function that accepts array-like arguments and returns a float.
    *args : array-like
        Input arrays to pass to metric_fn. All arrays are resampled together
        using the same bootstrap indices.
    n_bootstrap : int
        Number of bootstrap resamples.
    confidence_level : float
        Confidence level for the interval (e.g. 0.95 for 95%).
    random_state : int, optional
        Random seed for reproducibility.

    Returns
    -------
    ConfidenceInterval

    Examples
    --------
    >>> from fairlens.metrics import demographic_parity_ratio
    >>> ci = bootstrap_metric(
    ...     demographic_parity_ratio,
    ...     y_pred, protected,
    ...     n_bootstrap=500,
    ...     random_state=42,
    ... )
    >>> print(ci)
    """
    # Convert all args to numpy arrays
    arrays = [np.asarray(a).ravel() for a in args]

    # Validate lengths match
    n = len(arrays[0])
    for i, arr in enumerate(arrays[1:], 1):
        if len(arr) != n:
            raise ValueError(
                f"All input arrays must have same length. "
                f"Array 0 has length {n}, array {i} has length {len(arr)}"
            )

    rng = np.random.RandomState(random_state)

    # Point estimate on original data
    estimate = float(metric_fn(*arrays))

    # Bootstrap
    bootstrap_estimates = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        indices = rng.randint(0, n, size=n)
        resampled = [arr[indices] for arr in arrays]
        bootstrap_estimates[b] = metric_fn(*resampled)

    # Percentile confidence interval
    alpha = 1.0 - confidence_level
    lower = float(np.percentile(bootstrap_estimates, 100 * alpha / 2))
    upper = float(np.percentile(bootstrap_estimates, 100 * (1 - alpha / 2)))
    std_error = float(np.std(bootstrap_estimates, ddof=1))

    return ConfidenceInterval(
        estimate=estimate,
        lower=lower,
        upper=upper,
        std_error=std_error,
        confidence_level=confidence_level,
        n_bootstrap=n_bootstrap,
    )
