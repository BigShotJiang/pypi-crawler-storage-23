"""
Calibration metrics for ML models.

Calibration measures whether predicted probabilities match actual outcome rates.
A well-calibrated model predicting 70% probability should be correct 70% of the time.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CalibrationMetrics:
    """Container for calibration metric results."""
    expected_calibration_error: float
    max_calibration_error: float
    calibration_by_group: Dict[str, float]
    brier_score: float
    brier_score_by_group: Dict[str, float]
    
    def summary(self) -> str:
        """Return human-readable summary."""
        lines = [
            "=== Calibration Metrics ===",
            f"Expected Calibration Error: {self.expected_calibration_error:.4f}",
            f"Max Calibration Error: {self.max_calibration_error:.4f}",
            f"Brier Score: {self.brier_score:.4f}",
            "",
            "Calibration Error by Group:",
        ]
        for group, error in self.calibration_by_group.items():
            lines.append(f"  {group}: {error:.4f}")
        return "\n".join(lines)


def expected_calibration_error(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
    strategy: str = 'uniform'
) -> float:
    """Calculate Expected Calibration Error (ECE).
    
    ECE measures the average gap between predicted probability and actual
    accuracy within each probability bin.
    
    Parameters
    ----------
    y_true : array-like
        True binary labels
    y_prob : array-like
        Predicted probabilities for the positive class
    n_bins : int
        Number of bins for grouping predictions
    strategy : str
        'uniform' for equal-width bins, 'quantile' for equal-size bins
        
    Returns
    -------
    float
        Expected calibration error. Lower is better (0 is perfect).
    """
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    
    if strategy == 'uniform':
        bins = np.linspace(0, 1, n_bins + 1)
    else:  # quantile
        bins = np.percentile(y_prob, np.linspace(0, 100, n_bins + 1))
        bins[0] = 0.0
        bins[-1] = 1.0
    
    ece = 0.0
    for i in range(n_bins):
        mask = (y_prob >= bins[i]) & (y_prob < bins[i + 1])
        if i == n_bins - 1:  # Include right edge in last bin
            mask = (y_prob >= bins[i]) & (y_prob <= bins[i + 1])
        
        if mask.sum() > 0:
            bin_accuracy = y_true[mask].mean()
            bin_confidence = y_prob[mask].mean()
            bin_weight = mask.sum() / len(y_true)
            ece += bin_weight * abs(bin_accuracy - bin_confidence)
    
    return ece


def max_calibration_error(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10
) -> float:
    """Calculate Maximum Calibration Error (MCE).
    
    MCE is the maximum gap between predicted probability and actual
    accuracy across all bins.
    
    Parameters
    ----------
    y_true : array-like
        True binary labels
    y_prob : array-like
        Predicted probabilities
    n_bins : int
        Number of bins
        
    Returns
    -------
    float
        Maximum calibration error across bins
    """
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    
    bins = np.linspace(0, 1, n_bins + 1)
    max_error = 0.0
    
    for i in range(n_bins):
        mask = (y_prob >= bins[i]) & (y_prob < bins[i + 1])
        if i == n_bins - 1:
            mask = (y_prob >= bins[i]) & (y_prob <= bins[i + 1])
        
        if mask.sum() > 0:
            bin_accuracy = y_true[mask].mean()
            bin_confidence = y_prob[mask].mean()
            error = abs(bin_accuracy - bin_confidence)
            max_error = max(max_error, error)
    
    return max_error


def brier_score(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Calculate Brier score.
    
    Brier score is the mean squared error between predicted probabilities
    and actual outcomes. Lower is better (0 is perfect).
    
    Parameters
    ----------
    y_true : array-like
        True binary labels
    y_prob : array-like
        Predicted probabilities
        
    Returns
    -------
    float
        Brier score
    """
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    return np.mean((y_prob - y_true) ** 2)


def calibration_curve(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute calibration curve data.
    
    Parameters
    ----------
    y_true : array-like
        True binary labels
    y_prob : array-like
        Predicted probabilities
    n_bins : int
        Number of bins
        
    Returns
    -------
    mean_predicted : ndarray
        Mean predicted probability in each bin
    fraction_positives : ndarray
        Fraction of positive samples in each bin
    bin_counts : ndarray
        Number of samples in each bin
    """
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    
    bins = np.linspace(0, 1, n_bins + 1)
    mean_predicted = []
    fraction_positives = []
    bin_counts = []
    
    for i in range(n_bins):
        mask = (y_prob >= bins[i]) & (y_prob < bins[i + 1])
        if i == n_bins - 1:
            mask = (y_prob >= bins[i]) & (y_prob <= bins[i + 1])
        
        if mask.sum() > 0:
            mean_predicted.append(y_prob[mask].mean())
            fraction_positives.append(y_true[mask].mean())
            bin_counts.append(mask.sum())
    
    return (
        np.array(mean_predicted),
        np.array(fraction_positives),
        np.array(bin_counts)
    )


def calibration_error_by_group(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    protected_attribute: np.ndarray,
    n_bins: int = 10
) -> Dict[str, float]:
    """Calculate calibration error for each group.
    
    Parameters
    ----------
    y_true : array-like
        True binary labels
    y_prob : array-like
        Predicted probabilities
    protected_attribute : array-like
        Group membership for each sample
    n_bins : int
        Number of calibration bins
        
    Returns
    -------
    dict
        ECE for each group
    """
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    protected_attribute = np.asarray(protected_attribute).ravel()
    
    groups = sorted(list(set(protected_attribute)))
    result = {}
    
    for group in groups:
        mask = protected_attribute == group
        if mask.sum() > 0:
            ece = expected_calibration_error(
                y_true[mask],
                y_prob[mask],
                n_bins=n_bins
            )
            result[str(group)] = ece
    
    return result


def compute_calibration_metrics(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    protected_attribute: Optional[np.ndarray] = None,
    n_bins: int = 10
) -> CalibrationMetrics:
    """Compute all calibration metrics.
    
    Parameters
    ----------
    y_true : array-like
        True binary labels
    y_prob : array-like
        Predicted probabilities
    protected_attribute : array-like, optional
        Group membership for fairness analysis
    n_bins : int
        Number of calibration bins
        
    Returns
    -------
    CalibrationMetrics
        All calibration metrics
    """
    y_true = np.asarray(y_true).ravel()
    y_prob = np.asarray(y_prob).ravel()
    
    ece = expected_calibration_error(y_true, y_prob, n_bins)
    mce = max_calibration_error(y_true, y_prob, n_bins)
    bs = brier_score(y_true, y_prob)
    
    calibration_by_group = {}
    brier_by_group = {}
    
    if protected_attribute is not None:
        protected_attribute = np.asarray(protected_attribute).ravel()
        calibration_by_group = calibration_error_by_group(
            y_true, y_prob, protected_attribute, n_bins
        )
        
        groups = sorted(list(set(protected_attribute)))
        for group in groups:
            mask = protected_attribute == group
            if mask.sum() > 0:
                brier_by_group[str(group)] = brier_score(
                    y_true[mask], y_prob[mask]
                )
    
    return CalibrationMetrics(
        expected_calibration_error=ece,
        max_calibration_error=mce,
        calibration_by_group=calibration_by_group,
        brier_score=bs,
        brier_score_by_group=brier_by_group,
    )
