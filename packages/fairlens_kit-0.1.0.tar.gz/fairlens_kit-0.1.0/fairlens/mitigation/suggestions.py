"""
Bias mitigation suggestions.

Provides recommendations and code snippets for addressing
detected fairness issues.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class MitigationSuggestion:
    """A suggested mitigation technique."""
    name: str
    category: str  # 'preprocessing', 'inprocessing', 'postprocessing'
    description: str
    when_to_use: str
    code_snippet: Optional[str] = None
    references: List[str] = None
    
    def __post_init__(self):
        if self.references is None:
            self.references = []
    
    def __str__(self):
        lines = [
            f"{self.name}",
            f"   Category: {self.category}",
            f"   Description: {self.description}",
            f"   When to use: {self.when_to_use}",
        ]
        if self.references:
            lines.append(f"   References: {', '.join(self.references)}")
        return "\n".join(lines)


# Mitigation technique library
MITIGATION_LIBRARY = {
    # Preprocessing techniques
    "resampling": MitigationSuggestion(
        name="Resampling",
        category="preprocessing",
        description="Balance the dataset by over/undersampling groups",
        when_to_use="When protected groups are imbalanced in training data",
        code_snippet="""
from fairlens.datasets import balance_dataset

balanced_data = balance_dataset(
    data=df,
    target='outcome',
    protected_attribute='gender',
    strategy='oversample'  # or 'undersample'
)
""",
        references=["Kamiran & Calders, 2012"]
    ),
    
    "reweighting": MitigationSuggestion(
        name="Reweighting",
        category="preprocessing",
        description="Assign weights to samples to balance group influence",
        when_to_use="When you want to keep all data but adjust importance",
        code_snippet="""
# Compute sample weights inversely proportional to group frequency
group_counts = df.groupby(['gender', 'outcome']).size()
weights = df.apply(
    lambda row: 1.0 / group_counts[(row['gender'], row['outcome'])],
    axis=1
)
model.fit(X, y, sample_weight=weights)
""",
        references=["Kamiran & Calders, 2012"]
    ),
    
    "disparate_impact_remover": MitigationSuggestion(
        name="Disparate Impact Remover",
        category="preprocessing",
        description="Edit features to remove correlation with protected attribute",
        when_to_use="When features are proxies for protected attributes",
        code_snippet="""
# Using AIF360
from aif360.algorithms.preprocessing import DisparateImpactRemover

di = DisparateImpactRemover(repair_level=1.0)
dataset_transformed = di.fit_transform(dataset)
""",
        references=["Feldman et al., 2015"]
    ),
    
    # In-processing techniques
    "threshold_adjustment": MitigationSuggestion(
        name="Group-Specific Thresholds",
        category="postprocessing",
        description="Use different classification thresholds per group",
        when_to_use="When groups have different base rates",
        code_snippet="""
# Find optimal thresholds for each group
thresholds = {}
for group in groups:
    mask = protected == group
    # Optimize threshold for equalized odds
    best_thresh = optimize_threshold(
        y_true[mask], 
        y_prob[mask],
        metric='f1'
    )
    thresholds[group] = best_thresh

# Apply group-specific thresholds
y_pred_fair = np.zeros_like(y_prob)
for group, thresh in thresholds.items():
    mask = protected == group
    y_pred_fair[mask] = (y_prob[mask] >= thresh).astype(int)
""",
        references=["Hardt et al., 2016"]
    ),
    
    "adversarial_debiasing": MitigationSuggestion(
        name="Adversarial Debiasing",
        category="inprocessing",
        description="Train with adversary trying to predict protected attribute",
        when_to_use="When using neural networks and want learned fairness",
        code_snippet="""
# Conceptual PyTorch structure
class FairClassifier(nn.Module):
    def __init__(self):
        self.encoder = Encoder()
        self.predictor = Predictor()
        self.adversary = Adversary()
    
    def forward(self, x):
        features = self.encoder(x)
        prediction = self.predictor(features)
        # Adversary tries to predict protected attribute
        adv_pred = self.adversary(features.detach())
        return prediction, adv_pred
""",
        references=["Zhang et al., 2018"]
    ),
    
    "calibrated_equalized_odds": MitigationSuggestion(
        name="Calibrated Equalized Odds",
        category="postprocessing",
        description="Post-process probabilities to satisfy equalized odds",
        when_to_use="When model is already trained and can't be retrained",
        code_snippet="""
# Using AIF360
from aif360.algorithms.postprocessing import CalibratedEqOddsPostprocessing

cpp = CalibratedEqOddsPostprocessing(
    unprivileged_groups=[{'gender': 0}],
    privileged_groups=[{'gender': 1}]
)
cpp.fit(dataset_true, dataset_pred)
dataset_fair = cpp.transform(dataset_pred)
""",
        references=["Pleiss et al., 2017"]
    ),
    
    "reject_option": MitigationSuggestion(
        name="Reject Option Classification",
        category="postprocessing",
        description="Flip predictions for uncertain samples near decision boundary",
        when_to_use="When model predictions are near threshold for disadvantaged groups",
        code_snippet="""
# Flip predictions in critical region
critical_region = (y_prob > 0.4) & (y_prob < 0.6)
disadvantaged = protected == 'minority'

# Favor positive outcomes for disadvantaged in critical region  
y_pred_fair = y_pred.copy()
flip_mask = critical_region & disadvantaged & (y_pred == 0)
y_pred_fair[flip_mask] = 1
""",
        references=["Kamiran et al., 2012"]
    ),
}


def get_suggestions(
    issues: List[str],
    include_code: bool = True
) -> List[MitigationSuggestion]:
    """Get mitigation suggestions based on detected issues.
    
    Parameters
    ----------
    issues : list of str
        Fairness issues from audit
    include_code : bool
        Whether to include code snippets
        
    Returns
    -------
    list of MitigationSuggestion
        Relevant mitigation techniques
    """
    suggestions = []
    
    # Map issues to suggestions
    for issue in issues:
        issue_lower = issue.lower()
        
        if "demographic parity" in issue_lower or "positive predictions" in issue_lower:
            suggestions.extend([
                MITIGATION_LIBRARY["resampling"],
                MITIGATION_LIBRARY["threshold_adjustment"],
            ])
        
        if "equalized odds" in issue_lower or "true positive" in issue_lower or "false positive" in issue_lower:
            suggestions.extend([
                MITIGATION_LIBRARY["calibrated_equalized_odds"],
                MITIGATION_LIBRARY["threshold_adjustment"],
            ])
        
        if "calibration" in issue_lower:
            suggestions.extend([
                MITIGATION_LIBRARY["calibrated_equalized_odds"],
            ])
        
        if "proxy" in issue_lower or "correlation" in issue_lower:
            suggestions.extend([
                MITIGATION_LIBRARY["disparate_impact_remover"],
            ])
        
        if "underrepresented" in issue_lower or "imbalanced" in issue_lower:
            suggestions.extend([
                MITIGATION_LIBRARY["resampling"],
                MITIGATION_LIBRARY["reweighting"],
            ])
    
    # Default suggestions if none matched
    if not suggestions:
        suggestions = [
            MITIGATION_LIBRARY["resampling"],
            MITIGATION_LIBRARY["threshold_adjustment"],
        ]
    
    # Remove duplicates while preserving order
    seen = set()
    unique_suggestions = []
    for s in suggestions:
        if s.name not in seen:
            seen.add(s.name)
            unique_suggestions.append(s)
    
    # Remove code if not requested
    if not include_code:
        for s in unique_suggestions:
            s.code_snippet = None
    
    return unique_suggestions


def print_suggestions(
    issues: List[str],
    include_code: bool = True
) -> None:
    """Print mitigation suggestions for detected issues.
    
    Parameters
    ----------
    issues : list of str
        Fairness issues from audit
    include_code : bool
        Whether to include code snippets
    """
    suggestions = get_suggestions(issues, include_code)
    
    print("=" * 60)
    print("MITIGATION SUGGESTIONS")
    print("=" * 60)
    print()
    
    for i, suggestion in enumerate(suggestions, 1):
        print(f"{i}. {suggestion}")
        if suggestion.code_snippet and include_code:
            print("\n   Code example:")
            for line in suggestion.code_snippet.strip().split('\n'):
                print(f"   {line}")
        print()


def list_all_techniques() -> List[str]:
    """List all available mitigation techniques."""
    return list(MITIGATION_LIBRARY.keys())


def get_technique(name: str) -> MitigationSuggestion:
    """Get a specific mitigation technique by name."""
    if name not in MITIGATION_LIBRARY:
        raise ValueError(
            f"Unknown technique '{name}'. Available: {list_all_techniques()}"
        )
    return MITIGATION_LIBRARY[name]
