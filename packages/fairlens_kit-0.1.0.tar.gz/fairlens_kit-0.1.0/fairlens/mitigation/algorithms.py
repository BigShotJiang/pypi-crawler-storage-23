"""
Bias mitigation algorithms.

Implements practical bias mitigation techniques:
- ThresholdOptimizer: Post-processing via group-specific classification thresholds
- Reweighter: Pre-processing via sample weight adjustment
"""

import numpy as np
from typing import Union, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class ThresholdOptimizerResult:
    """Results from threshold optimization."""
    thresholds: Dict[str, float]
    group_positive_rates_before: Dict[str, float]
    group_positive_rates_after: Dict[str, float]
    demographic_parity_before: float
    demographic_parity_after: float
    objective: str

    def summary(self) -> str:
        """Return human-readable summary."""
        lines = [
            "=== Threshold Optimizer Results ===",
            f"Objective: {self.objective}",
            f"Demographic Parity Ratio: {self.demographic_parity_before:.3f} -> {self.demographic_parity_after:.3f}",
            "",
            "Group Thresholds:",
        ]
        for group, thresh in self.thresholds.items():
            rate_before = self.group_positive_rates_before[group]
            rate_after = self.group_positive_rates_after[group]
            lines.append(
                f"  {group}: threshold={thresh:.3f} "
                f"(positive rate: {rate_before:.1%} -> {rate_after:.1%})"
            )
        return "\n".join(lines)

    def __str__(self):
        return self.summary()


@dataclass
class ReweighterResult:
    """Results from sample reweighting."""
    group_weights: Dict[str, Dict[str, float]]
    group_sizes: Dict[str, int]
    label_rates_before: Dict[str, float]
    label_rates_after: Dict[str, float]

    def summary(self) -> str:
        """Return human-readable summary."""
        lines = [
            "=== Reweighter Results ===",
            "",
            "Weights by (group, label):",
        ]
        for group, weight_map in self.group_weights.items():
            for label, w in weight_map.items():
                lines.append(f"  ({group}, {label}): {w:.4f}")
        lines.append("")
        lines.append("Weighted Label Rates by Group:")
        for group in self.label_rates_after:
            before = self.label_rates_before[group]
            after = self.label_rates_after[group]
            lines.append(f"  {group}: {before:.1%} -> {after:.1%}")
        return "\n".join(lines)

    def __str__(self):
        return self.summary()


class ThresholdOptimizer:
    """Post-processing bias mitigation via group-specific thresholds.

    Finds optimal classification thresholds per group to satisfy a fairness
    objective (e.g. demographic parity). Works on predicted probabilities.

    Parameters
    ----------
    objective : str
        Fairness objective. Currently supports 'demographic_parity'.
    grid_size : int
        Number of threshold candidates to evaluate per group.

    Examples
    --------
    >>> opt = ThresholdOptimizer(objective='demographic_parity')
    >>> opt.fit(y_true, y_prob, protected)
    >>> fair_preds = opt.predict(y_prob, protected)
    """

    def __init__(self, objective: str = 'demographic_parity', grid_size: int = 100):
        self.objective = objective
        self.grid_size = grid_size
        self._thresholds = None
        self._fitted = False
        self._result = None

    def fit(
        self,
        y_true: Union[np.ndarray, 'pd.Series'],
        y_prob: Union[np.ndarray, 'pd.Series'],
        protected_attribute: Union[np.ndarray, 'pd.Series'],
    ) -> 'ThresholdOptimizer':
        """Fit group-specific thresholds.

        Parameters
        ----------
        y_true : array-like
            True binary labels.
        y_prob : array-like
            Predicted probabilities.
        protected_attribute : array-like
            Protected attribute values.

        Returns
        -------
        self
        """
        y_true = np.asarray(y_true).ravel()
        y_prob = np.asarray(y_prob).ravel()
        protected_attribute = np.asarray(protected_attribute).ravel()

        if len(y_true) != len(y_prob) or len(y_true) != len(protected_attribute):
            raise ValueError(
                f"Input arrays must have same length. Got y_true={len(y_true)}, "
                f"y_prob={len(y_prob)}, protected_attribute={len(protected_attribute)}"
            )

        groups = sorted(list(set(protected_attribute)))
        candidates = np.linspace(0, 1, self.grid_size + 1)

        # Compute baseline positive rates
        rates_before = {}
        for g in groups:
            mask = protected_attribute == g
            rates_before[str(g)] = float(np.mean(y_prob[mask] >= 0.5))

        # Find target rate (overall positive rate at 0.5 threshold)
        target_rate = float(np.mean(y_prob >= 0.5))

        # For each group, find threshold that produces the closest positive rate
        # to the target rate (demographic parity)
        thresholds = {}
        rates_after = {}
        for g in groups:
            mask = protected_attribute == g
            group_probs = y_prob[mask]

            best_thresh = 0.5
            best_diff = float('inf')
            for t in candidates:
                rate = float(np.mean(group_probs >= t))
                diff = abs(rate - target_rate)
                if diff < best_diff:
                    best_diff = diff
                    best_thresh = t

            thresholds[str(g)] = best_thresh
            rates_after[str(g)] = float(np.mean(group_probs >= best_thresh))

        self._thresholds = thresholds

        # Compute DP ratios
        rates_before_vals = list(rates_before.values())
        rates_after_vals = list(rates_after.values())

        def dp_ratio(vals):
            mn, mx = min(vals), max(vals)
            return mn / mx if mx > 0 else 1.0

        self._result = ThresholdOptimizerResult(
            thresholds=thresholds,
            group_positive_rates_before=rates_before,
            group_positive_rates_after=rates_after,
            demographic_parity_before=dp_ratio(rates_before_vals),
            demographic_parity_after=dp_ratio(rates_after_vals),
            objective=self.objective,
        )
        self._fitted = True
        return self

    def predict(
        self,
        y_prob: Union[np.ndarray, 'pd.Series'],
        protected_attribute: Union[np.ndarray, 'pd.Series'],
    ) -> np.ndarray:
        """Apply group-specific thresholds to produce fair predictions.

        Parameters
        ----------
        y_prob : array-like
            Predicted probabilities.
        protected_attribute : array-like
            Protected attribute values.

        Returns
        -------
        np.ndarray
            Binary predictions using group-specific thresholds.
        """
        if not self._fitted:
            raise RuntimeError("ThresholdOptimizer must be fit before predict")

        y_prob = np.asarray(y_prob).ravel()
        protected_attribute = np.asarray(protected_attribute).ravel()
        predictions = np.zeros(len(y_prob), dtype=int)

        for g, thresh in self._thresholds.items():
            mask = protected_attribute == g
            predictions[mask] = (y_prob[mask] >= thresh).astype(int)

        return predictions

    def get_results(self) -> ThresholdOptimizerResult:
        """Return detailed results from fitting.

        Returns
        -------
        ThresholdOptimizerResult
        """
        if not self._fitted:
            raise RuntimeError("ThresholdOptimizer must be fit first")
        return self._result


class Reweighter:
    """Pre-processing bias mitigation via sample reweighting.

    Computes sample weights so that the weighted label distribution is
    independent of the protected attribute. Uses the formula:
        weight(y, g) = P(Y=y) * P(G=g) / P(Y=y, G=g)

    Examples
    --------
    >>> rw = Reweighter()
    >>> rw.fit(y_true, protected)
    >>> weights = rw.transform(y_true, protected)
    >>> model.fit(X, y, sample_weight=weights)
    """

    def __init__(self):
        self._weights_map = None
        self._fitted = False
        self._result = None

    def fit(
        self,
        y_true: Union[np.ndarray, 'pd.Series'],
        protected_attribute: Union[np.ndarray, 'pd.Series'],
    ) -> 'Reweighter':
        """Compute reweighting factors.

        Parameters
        ----------
        y_true : array-like
            True binary labels.
        protected_attribute : array-like
            Protected attribute values.

        Returns
        -------
        self
        """
        y_true = np.asarray(y_true).ravel()
        protected_attribute = np.asarray(protected_attribute).ravel()

        if len(y_true) != len(protected_attribute):
            raise ValueError(
                f"Input arrays must have same length. Got y_true={len(y_true)}, "
                f"protected_attribute={len(protected_attribute)}"
            )

        n = len(y_true)
        groups = sorted(list(set(protected_attribute)))
        labels = sorted(list(set(y_true)))

        # Compute marginals and joint probabilities
        p_y = {}
        for label in labels:
            p_y[label] = np.sum(y_true == label) / n

        p_g = {}
        group_sizes = {}
        for g in groups:
            cnt = np.sum(protected_attribute == g)
            p_g[g] = cnt / n
            group_sizes[str(g)] = int(cnt)

        # Weight map: (group, label) -> weight
        weights_map = {}
        for g in groups:
            weights_map[str(g)] = {}
            for label in labels:
                joint = np.sum((y_true == label) & (protected_attribute == g)) / n
                if joint > 0:
                    w = (p_y[label] * p_g[g]) / joint
                else:
                    w = 1.0
                weights_map[str(g)][str(label)] = w

        self._weights_map = weights_map

        # Compute label rates before and after
        rates_before = {}
        rates_after = {}
        for g in groups:
            mask = protected_attribute == g
            rates_before[str(g)] = float(np.mean(y_true[mask]))

            # Weighted rate
            group_y = y_true[mask]
            group_weights = np.array([
                weights_map[str(g)][str(int(y))] for y in group_y
            ])
            rates_after[str(g)] = float(
                np.sum(group_y * group_weights) / np.sum(group_weights)
            )

        self._result = ReweighterResult(
            group_weights=weights_map,
            group_sizes=group_sizes,
            label_rates_before=rates_before,
            label_rates_after=rates_after,
        )
        self._fitted = True
        return self

    def transform(
        self,
        y_true: Union[np.ndarray, 'pd.Series'],
        protected_attribute: Union[np.ndarray, 'pd.Series'],
    ) -> np.ndarray:
        """Apply sample weights.

        Parameters
        ----------
        y_true : array-like
            True binary labels.
        protected_attribute : array-like
            Protected attribute values.

        Returns
        -------
        np.ndarray
            Sample weights (one per sample).
        """
        if not self._fitted:
            raise RuntimeError("Reweighter must be fit before transform")

        y_true = np.asarray(y_true).ravel()
        protected_attribute = np.asarray(protected_attribute).ravel()

        weights = np.ones(len(y_true))
        for i in range(len(y_true)):
            g = str(protected_attribute[i])
            label = str(int(y_true[i]))
            if g in self._weights_map and label in self._weights_map[g]:
                weights[i] = self._weights_map[g][label]

        return weights

    def fit_transform(
        self,
        y_true: Union[np.ndarray, 'pd.Series'],
        protected_attribute: Union[np.ndarray, 'pd.Series'],
    ) -> np.ndarray:
        """Fit and transform in one step.

        Parameters
        ----------
        y_true : array-like
            True binary labels.
        protected_attribute : array-like
            Protected attribute values.

        Returns
        -------
        np.ndarray
            Sample weights.
        """
        self.fit(y_true, protected_attribute)
        return self.transform(y_true, protected_attribute)

    def get_results(self) -> ReweighterResult:
        """Return detailed results from fitting.

        Returns
        -------
        ReweighterResult
        """
        if not self._fitted:
            raise RuntimeError("Reweighter must be fit first")
        return self._result
