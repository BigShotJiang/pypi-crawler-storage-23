"""
FairLens mitigation module.

Provides bias mitigation suggestions and techniques.
"""

from .suggestions import (
    MitigationSuggestion,
    get_suggestions,
    print_suggestions,
    list_all_techniques,
    get_technique,
    MITIGATION_LIBRARY,
)

from .algorithms import (
    ThresholdOptimizer,
    ThresholdOptimizerResult,
    Reweighter,
    ReweighterResult,
)


__all__ = [
    "MitigationSuggestion",
    "get_suggestions",
    "print_suggestions",
    "list_all_techniques",
    "get_technique",
    "MITIGATION_LIBRARY",
    # Algorithms
    "ThresholdOptimizer",
    "ThresholdOptimizerResult",
    "Reweighter",
    "ReweighterResult",
]
