from collections import Counter, deque
from functools import cache
from .find_generating_subset import find_generating_subset
from .kernels import default_kernel
from .normalized_invariants import invariant_factors
from mutable_lattice import Vector, Lattice

def cover_submodule_with_actions(
    Zbasis: list[Vector],
    actions: list[Vector],
    e_to_Se: dict[int,tuple[int,...]],
    *,
    extra_greedy=False,
    ensure_minimal=False,
    verbose=False,
    sloppy_last_cover=False,
):
    """Cover a given submodule of ZSf1(+)...(+)ZSfn
    with a map out of some ZSe1(+)...(+)ZSem.
    Return the image vectors where the each ej should
    get sent for each summand, along with which idempotents
    [e1, ..., em] to use.
    """
    if not Zbasis:
        return [], []
    # This is just a wrapper around find_generating_subset
    def find_fixer_idempotent(vec):
        for e in e_to_Se:
            if vec.shuffled_by_action(actions[e]) == vec:
                return e
        raise AssertionError("Not a monoid?")
    id_to_idempotent = {id(vec): find_fixer_idempotent(vec) for vec in Zbasis}
    costs = [len(e_to_Se[id_to_idempotent[id(vec)]]) for vec in Zbasis]
    if sloppy_last_cover:
        # Don't bother shrinking anything
        generating_subset = Zbasis
    else:
        generating_subset = find_generating_subset(
            Zbasis, actions, costs,
            extra_greedy=extra_greedy,
            ensure_minimal=ensure_minimal,
            verbose=verbose)
    result_ZS_module = [id_to_idempotent[id(vec)] for vec in generating_subset]
    if verbose:
        print(f"covered rank {len(Zbasis)} with idempotents {Counter(result_ZS_module)}")
    return generating_subset, result_ZS_module

class ProjectiveResolution:
    """Data representing a projective resolution of ZZ[S]-modules for some monoid S"""
    __slots__ = [
        # the monoid multiplication table as a tuple[tuple[int]]
        "op",
        # the integer index serving as an identity element for the monoid
        "identity",
        # The multiplication table (S elements) x (Y elements) --> (Y elements), as list[Vector]
        "left_S_set_action",
        # a mapping int -> tuple[int] from idempotents e to the tuple of distinct elements op[...][e]
        "e_to_Se",
        # int -> (int -> int). This stores the index at which element in Se appears in Se, for each e.
        "e_to_s_to_ii",
        # A mapping from ResolutionNode arguments to ResolutionNode, allowing re-use
        "node_cache",
        # The ResolutionNode for dimension 0 of this resolution
        "root",
        # A function that finds the relations among a given list of Vectors.
        "kernel_implementation",
    ]

    def __init__(self, op, *, left_S_set_action=None, check=True, kernel_implementation=None):
        if left_S_set_action is None:
            left_S_set_action = [[0] for _ in range(len(op))]
        left_S_set_action = [Vector(list(act)) for act in left_S_set_action]
        op = tuple(map(tuple, op))
        S = range(len(op))
        idempotents = [e for e in S if op[e][e] == e]
        [identity] = [e for e in idempotents if all(op[x][e] == x == op[e][x] for x in S)]
        Y = range(len(left_S_set_action[0]))
        if check:
            if len(left_S_set_action) != len(op):
                raise ValueError(f"{len(left_S_set_action)=} mismatches {len(op)=}")
            if set(map(len, op)) != {len(op)}:
                raise ValueError("op was not square")
            if len(set(map(len, left_S_set_action))) != 1:
                raise ValueError("inconsistent numbers of states")
            act = left_S_set_action
            for i in S:
                for j in S:
                    ij = op[i][j]
                    for k in S:
                        jk = op[j][k]
                        if op[ij][k] != op[i][jk]:
                            raise ValueError(f"op[op[{i}][{j}]][{k}]=op[{ij}][{k}]={op[ij][k]}, but "
                                             f"op[{i}][op[{j}][{k}]]=op[{i}][{jk}]={op[i][jk]}")
                    for y in Y:
                        jy = act[j][y]
                        if act[ij][y] != act[i][jy]:
                            raise ValueError(f"act[op[{i}][{j}]][{k}]=act[{ij}][{k}]={act[ij][k]}, but "
                                             f"act[{i}][act[{j}][{k}]]=act[{i}][{jy}]={act[i][jy]}")
            if act[identity] != Vector(list(Y)):
                raise ValueError(f"act[identity]=act[{identity}]={act[identity]} was not identity")
        e_Se_pairs = [(e, sorted({op[s][e] for s in S})) for e in idempotents]
        e_to_Se = dict(sorted(e_Se_pairs, key=lambda e_Se: len(e_Se[1])))
        e_to_s_to_ii = {
            e: {x: ii for ii, x in enumerate(Se)}
            for e, Se in e_to_Se.items()
        }
        self.op = op
        self.identity = identity
        self.left_S_set_action = left_S_set_action
        self.e_to_Se = e_to_Se
        self.e_to_s_to_ii = e_to_s_to_ii
        if kernel_implementation is None:
            kernel_implementation = default_kernel
        self.kernel_implementation = kernel_implementation

        augmentation_module_Zbasis = Lattice.full(len(Y)).get_basis()
        mat0, mod0 = cover_submodule_with_actions(
            augmentation_module_Zbasis, left_S_set_action, e_to_Se,
            extra_greedy=False, ensure_minimal=True, verbose=False)
        root = ResolutionNode(self, mod0, None, mat0)
        self.root = root
        self.node_cache = {}

    def assert_exact(self):
        q = deque([self.root])
        done = set()
        while q:
            node = q.popleft()
            if node in done:
                continue
            done.add(node)
            if node.children is None:
                continue
            node.assert_exact()
            done.add(node)
            if node.children is not None:
                q.extend(node.children)

    def make_actions(self, module):
        """Given a list of idempotents [e1, ..., en] representing ZSe1(+)...(+)ZSen,
        Return a list of "action" vectors, one for each element s of S, such that
        the Z-basis element i gets sent to the Z-basis element action[i]
        under multiplication by s.
        """
        e_to_Se = self.e_to_Se
        e_to_s_to_ii = self.e_to_s_to_ii
        op = self.op
        N = sum(map(len, map(e_to_Se.get, module)))
        offset = 0
        S_action_table = [[None] * N for _ in range(len(op))]
        for e in module:
            Se = e_to_Se[e]
            se_to_ii = e_to_s_to_ii[e]
            index_se_pairs = list(enumerate(Se, offset))
            for op_s1, table_s1 in zip(op, S_action_table):
                for index, se in index_se_pairs:
                    table_s1[index] = offset + se_to_ii[op_s1[se]]
            offset += len(Se)
        return list(map(Vector, S_action_table))

    def extend_to_dimension(self, maxdim, sloppy_last_cover=False, **kwargs):
        generation = {self.root}
        for dim in range(1, maxdim + 1):
            generation = {child for node in generation for child in node.get_children(
                sloppy_last_cover=sloppy_last_cover and (dim == maxdim),
                **kwargs
            )}

    def total_cost(self, maxdim):
        # Get the total number of generators
        self.extend_to_dimension(maxdim)
        q = deque([(self.root, maxdim)])
        cost = {}
        while q:
            node, dim = q.popleft()
            if node in cost:
                continue
            cost[node] = len(node.module)
            if dim >= 1:
                for child in node.children:
                    q.append((child, dim - 1))
        return sum(cost.values())

    def homology_list(self, maxdim, *, right_S_set_action=None, check=True, **kwargs):
        self.extend_to_dimension(maxdim + 1, sloppy_last_cover=True, **kwargs)
        op = self.op
        S = range(len(op))
        if right_S_set_action is None:
            right_S_set_action = [[0] * len(op)]
        X = range(len(right_S_set_action))
        if check:
            act = right_S_set_action
            for row in right_S_set_action:
                if len(row) != len(S):
                    raise ValueError(f"len(right_S_set_action[i])={len(row)} mismatches {len(op)=}")
            for x in X:
                for i in S:
                    xi = act[x][i]
                    for j in S:
                        ij = op[i][j]
                        if act[xi][j] != act[x][ij]:
                            raise ValueError(f"act[act[{x}][{i}]][{j}]=act[{xi}][{j}]={act[xi][j]}, but"
                                             f"act[{x}][op[{i}][{j}]]=act[{x}][{ij}]={act[x][ij]}")
                if act[x][self.identity] != x:
                    raise ValueError(f"act[{x}][identity={self.identity}] was not {x}")
        e_to_Xe = {e: sorted({right_S_set_action[x][e] for x in X})
                   for e in self.e_to_Se}
        e_to_x_to_ii = {
            e: {x: ii for ii, x in enumerate(Xe)}
            for e, Xe in e_to_Xe.items()
        }

        @cache
        def outgoing_invariants(node) -> list:
            return node.outgoing_tensored_invariants(right_S_set_action, e_to_Xe, e_to_x_to_ii)

        @cache
        def homology(node) -> Counter:
            incoming = Counter()
            for child in node.children:
                incoming.update(outgoing_invariants(child))
            chains_rank = sum(map(len, map(e_to_Xe.get, node.module)))
            outgoing_rank = len(outgoing_invariants(node))
            incoming_rank = incoming.total()
            free_rank = chains_rank - outgoing_rank - incoming_rank
            result = Counter({d:count for d, count in incoming.items() if d > 1}) # torsion
            if free_rank:
                result[0] = free_rank
            return result

        # homology_with_shift[node, dim] will store the homology dim
        # dimensions higher in the resolution. This is calculated as
        # a sum of homology_with_shift[child, dim] for all children.
        # Use a stack instead of recursion so we don't blow Python's
        # recursion limit.
        homology_with_shift = {}
        stack = [(self.root, dim) for dim in reversed(range(maxdim + 1))]
        while stack:
            node, dim = stack[-1]
            if (node, dim) in homology_with_shift:
                stack.pop()
                continue
            if dim == 0:
                homology_with_shift[node, 0] = homology(node)
                stack.pop()
                continue
            children_done = True
            for child in node.children:
                if (child, dim-1) not in homology_with_shift:
                    stack.append((child, dim-1))
                    children_done = False
            if children_done:
                result = Counter()
                for child in node.children:
                    result += homology_with_shift[child, dim-1]
                homology_with_shift[node, dim] = result
                stack.pop()
        return [invariant_factors(homology_with_shift[self.root, dim])
                for dim in range(maxdim + 1)]

class ResolutionNode:
    """
    Represent a ZS-linear map ZSf1(+)...(+)ZSfn <---- ZSe1(+)...(+)ZSem
    """
    __slots__ = [
        "resolution", # The ProjectiveResolution we belong to
        "module", # a list of idempotents [e1, ..., em]: this node represents ZSe1 (+) ... (+) ZSe,
        "prev_module", # The idempotents for the node one dimension lower; the target of the outgoing map
        "e_images", # A Vector representing the image of each ei in prev_module
        "children", # A list of nodes one dimension higher used to cover the kernel of the outgoing map
        "child_gen_indexes", # list[list[int]]: for each child, the indexes of the ZSej that it covers
    ]
    def __init__(self, resolution: ProjectiveResolution, module, prev_module, e_images):
        self.resolution = resolution
        self.module = module
        self.prev_module = prev_module
        self.e_images = e_images
        self.children = None
        self.child_gen_indexes = None
        assert len(e_images) == len(module)

    def assert_exact(self):
        """For testing purposes: assert that the resolution is exact at this node."""
        assert len(self.children) == len(self.child_gen_indexes)
        gen_index_to_indexes = []
        N = 0
        for e in self.module:
            start = N
            N += len(self.resolution.e_to_Se[e])
            stop = N
            gen_index_to_indexes.append(range(start, stop))
        incoming_image = Lattice(N)
        for child, gen_indexes in zip(self.children, self.child_gen_indexes):
            assert child.prev_module == [self.module[gen_index] for gen_index in gen_indexes]
            indexes_for_summand = []
            for gen_index in gen_indexes:
                indexes_for_summand.extend(gen_index_to_indexes[gen_index])
            action = Vector(indexes_for_summand)
            for child_image_vector in child.get_Z_basis_images():
                embedded = child_image_vector.shuffled_by_action(action, N)
                incoming_image.add_vector(embedded)
        Z_basis_images = self.get_Z_basis_images()
        kernel_basis = self.resolution.kernel_implementation(Z_basis_images)
        outgoing_kernel = Lattice(N, kernel_basis)
        assert incoming_image == outgoing_kernel

    def get_Z_basis_images(self, verbose=False):
        """We only store the image of each summand generator e.
        This retrieves the image of each se in Se, so we have the image of every Z-basis vector."""
        if self.prev_module is None:
            assert self is self.resolution.root
            S_action_on_image = self.resolution.left_S_set_action
        else:
            if verbose:
                print("making actions")
            S_action_on_image = self.resolution.make_actions(self.prev_module)
        e_to_Se = self.resolution.e_to_Se
        if verbose:
            print("getting Z-basis for image")
        return [
            vec.shuffled_by_action(S_action_on_image[se])
            for vec, e in zip(self.e_images, self.module)
            for se in e_to_Se[e]
        ]

    def decompose_kernel(self, verbose=False):
        Z_basis_images = self.get_Z_basis_images(verbose=verbose)
        kernel_basis = self.resolution.kernel_implementation(Z_basis_images, verbose=verbose)
        if verbose:
            print("preparing to decompose...")
        # Conversion between Z-basis indexes and summand ZSe indexes
        index_to_gen_index = []
        gen_index_to_index_range = []
        for i, e in enumerate(self.module):
            n0 = len(index_to_gen_index)
            index_to_gen_index.extend([i] * len(self.resolution.e_to_Se[e]))
            n1 = len(index_to_gen_index)
            gen_index_to_index_range.append(list(range(n0, n1)))
        if verbose:
            print("making Lattice to decompose...")
        L = Lattice(len(Z_basis_images), kernel_basis)
        # See if the kernel splits along the given summands
        if verbose:
            print("decomposing...")
        indexes, summands = L.decompose(gen_index_to_index_range)
        if verbose:
            print(f"split into {len(indexes)} bins: {[len(x) for x in indexes]}")
        return indexes, index_to_gen_index, summands

    def get_children(self, *, verbose=False,
                     max_size_to_cache=5000,
                     max_size_for_extra_greedy=10,
                     max_size_to_ensure_minimal=500,
                     sloppy_last_cover=False):
        if self.children is not None:
            return self.children
        indexes, index_to_gen_index, summands = self.decompose_kernel(verbose=verbose)
        children = []
        child_gen_indexes = []
        for index_group, summand in zip(indexes, summands):
            if summand.rank == 0:
                continue
            gen_indexes = sorted({index_to_gen_index[ix] for ix in index_group})
            summand_gens = [self.module[gen_index] for gen_index in gen_indexes]
            split_e_images, split_next_module = cover_submodule_with_actions(
                summand.get_basis(),
                self.resolution.make_actions(summand_gens),
                self.resolution.e_to_Se,
                extra_greedy=(summand.rank <= max_size_for_extra_greedy),
                ensure_minimal=(summand.rank <= max_size_to_ensure_minimal),
                verbose=verbose,
                sloppy_last_cover=sloppy_last_cover,
            )
            if sum(map(len, split_e_images)) > max_size_to_cache:
                if verbose:
                    print("too big to cache")
                child = ResolutionNode(self.resolution, split_next_module, summand_gens, split_e_images)
            else:
                cache_key = tuple(split_next_module), tuple(summand_gens), tuple(map(tuple, split_e_images))
                node_cache = self.resolution.node_cache
                child = node_cache.get(cache_key)
                if child is None:
                    child = ResolutionNode(self.resolution, split_next_module, summand_gens, split_e_images)
                    node_cache[cache_key] = child
                    if verbose:
                        print("cache miss")
                else:
                    if verbose and len(split_next_module) > 1:
                        print(f"cache hit on {len(summand_gens)}gens <-- {len(split_next_module)}gens")
            children.append(child)
            child_gen_indexes.append(gen_indexes)
        if verbose:
            print("done making children")
        self.children = children
        self.child_gen_indexes = child_gen_indexes
        return children

    def outgoing_tensored_invariants(self, right_S_set_action, e_to_Xe, e_to_x_to_ii, verbose=False) -> list[int]:
        if self.prev_module is None:
            assert self is self.resolution.root
            # This is the root--the outgoing map is deleted.
            return []
        if verbose:
            print("tensoring...")

        X = range(len(right_S_set_action))
        e_to_Se = self.resolution.e_to_Se

        # Tensoring moves from a rank-N0 module sum(ZSej)
        #                   to a rank-N1 module sum(ZXej)
        N0 = sum(map(len, map(e_to_Se.get, self.prev_module)))
        assert set(map(len, self.e_images)) <= {N0}
        N1 = sum(map(len, map(e_to_Xe.get, self.prev_module)))

        e_images = self.e_images

        def make_X_actions():
            # "actions" to move from sum(ZSe) to sum(ZXe).
            offset0 = offset1 = 0
            # the table that takes (index in X, index in union of Se) --> index in union of Xe
            x_action_table = [[None] * N0 for x in X]
            for e in self.prev_module:
                Se = e_to_Se[e]
                Xe = e_to_Xe[e]
                x_to_ii = e_to_x_to_ii[e]
                index0_se_pairs = list(enumerate(Se, offset0))
                for act_x, table_x in zip(right_S_set_action, x_action_table):
                    for index0, se in index0_se_pairs:
                        table_x[index0] = offset1 + x_to_ii[act_x[se]]
                offset0 += len(Se)
                offset1 += len(Xe)
            return list(map(Vector, x_action_table))
        x_actions = make_X_actions()
        if verbose:
            print("made X actions.")
        def make_tensored_image():
            tensored_image = Lattice(N1, maxrank=len(X)*len(self.module))
            for e_image in e_images:
                for x_act in x_actions:
                    acted = e_image.shuffled_by_action(x_act, N1)
                    tensored_image.add_vector(acted)
            return tensored_image
        tensored_image = make_tensored_image()
        nzi = tensored_image.nonzero_invariants()
        if verbose:
            print("invariants:", Counter(nzi))
        return nzi

