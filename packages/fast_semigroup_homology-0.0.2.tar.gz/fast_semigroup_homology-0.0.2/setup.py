from setuptools import setup
setup(packages=["fast_semigroup_homology"])
