"""Test project settings modules."""
