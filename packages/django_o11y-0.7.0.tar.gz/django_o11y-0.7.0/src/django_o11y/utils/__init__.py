"""Shared internal utilities."""
