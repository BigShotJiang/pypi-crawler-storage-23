"""Observability stack configuration files."""
