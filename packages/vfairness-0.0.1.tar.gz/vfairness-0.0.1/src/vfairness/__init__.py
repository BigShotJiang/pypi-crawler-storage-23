"""vfairness — End-to-end ML fairness library.

Provides bias detection, fairness-aware training, post-processing
calibration, evaluation metrics with confidence intervals, production
drift monitoring, CI/CD deployment gates, and A/B testing for fairness
interventions.

Modules:
    preprocessing   Bias detection and fairness-aware feature engineering.
    in_processing   Fairness losses, constraints, and regularizers for training.
    post_processing Calibration, threshold optimization, and reweighting.
    evaluation      Fairness metrics, visualization, robustness, and explainability.
    operations      CI/CD gates, monitoring, reporting, and experimentation.
    rendering       SVG template engine for publication-quality reports.
"""

__version__ = "0.0.1"