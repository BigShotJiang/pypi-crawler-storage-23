"""Public package exports for Trinnov Altitude."""

from trinnov_altitude.client import TrinnovAltitudeClient

__all__ = ["TrinnovAltitudeClient"]
__version__ = "2.0.1"
