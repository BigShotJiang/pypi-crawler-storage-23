"""Prompts for text summarization."""

SYSTEM_PROMPT = """You are a professional text summarizer. Your job is to create concise, 
accurate summaries that capture the key points of the input text.

IMPORTANT:
- Create a NEW summary that is significantly shorter than the original
- Extract only the most important information
- Do NOT just copy or slightly modify the original text
- Write in a clear, structured way
- Keep the summary coherent and readable"""


def build_summary_prompt(text: str, target_length: str = "medium", tone: str = "neutral") -> str:
    """
    Build a precise summarization prompt.
    
    Args:
        text: The text to summarize
        target_length: "short" (25%), "medium" (40%), "detailed" (60%)
        tone: "neutral", "formal", "casual"
    
    Returns:
        Prompt string
    """
    
    # Length guidance
    length_guidance = {
        "short": "very concise (2-3 sentences)",
        "medium": "moderate length (1 paragraph)",
        "detailed": "thorough (2-3 paragraphs)"
    }
    
    # Tone guidance
    tone_guidance = {
        "neutral": "objective and balanced",
        "formal": "professional and structured",
        "casual": "friendly and conversational"
    }
    
    length_text = length_guidance.get(target_length, length_guidance["medium"])
    tone_text = tone_guidance.get(tone, tone_guidance["neutral"])
    
    prompt = f"""Please summarize the following text in a {length_text} summary.
Keep a {tone_text} tone.

TEXT TO SUMMARIZE:
{text}

IMPORTANT: Create a REAL summary that is much shorter and simpler than the original.
Extract only the main ideas and key information.

SUMMARY:"""
    
    return prompt
