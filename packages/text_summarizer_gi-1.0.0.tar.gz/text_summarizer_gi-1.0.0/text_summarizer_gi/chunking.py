"""Smart text chunking for large documents."""

import re
from typing import List


def chunk_text_by_sentences(text: str, max_chunk_size: int = 3000) -> List[str]:
    """
    Split text into chunks by sentences.
    This preserves context better than character chunking.
    
    Args:
        text: Text to chunk
        max_chunk_size: Maximum characters per chunk
    
    Returns:
        List of text chunks
    """
    if not text or len(text) <= max_chunk_size:
        return [text] if text else []
    
    # Split by sentence boundaries
    sentences = re.split(r'(?<=[.!?])\s+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    if not sentences:
        return [text]
    
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        # Try to add sentence to current chunk
        if current_chunk:
            candidate = current_chunk + " " + sentence
        else:
            candidate = sentence
        
        if len(candidate) <= max_chunk_size:
            current_chunk = candidate
        else:
            # Current chunk is full, start new one
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = sentence
    
    # Add remaining chunk
    if current_chunk:
        chunks.append(current_chunk)
    
    return chunks


def chunk_text(text: str, chunk_size: int = 3000) -> List[str]:
    """
    Split text into chunks by character count.
    Simple but preserves less context.
    
    Args:
        text: Text to chunk  
        chunk_size: Characters per chunk
    
    Returns:
        List of text chunks
    """
    if not text or len(text) <= chunk_size:
        return [text] if text else []
    
    chunks = []
    for i in range(0, len(text), chunk_size):
        chunks.append(text[i:i + chunk_size])
    
    return chunks
