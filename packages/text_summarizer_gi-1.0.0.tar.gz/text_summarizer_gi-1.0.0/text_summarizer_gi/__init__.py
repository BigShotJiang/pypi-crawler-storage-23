"""
Text Summarizer - Simple, focused text summarization library.

Input: Text
Output: Concise summary
"""

from .summarizer import TextSummarizer, SummaryResult
from .token_counter import count_tokens
from .chunking import chunk_text, chunk_text_by_sentences

__version__ = "1.0.0"

__all__ = [
    "TextSummarizer",
    "SummaryResult",
    "count_tokens",
    "chunk_text",
    "chunk_text_by_sentences",
]

