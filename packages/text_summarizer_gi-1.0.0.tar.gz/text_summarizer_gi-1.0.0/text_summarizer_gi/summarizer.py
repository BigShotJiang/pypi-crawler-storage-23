"""Main text summarizer using Azure OpenAI."""

import os
from dataclasses import dataclass
from typing import Optional
from openai import AzureOpenAI

from .chunking import chunk_text_by_sentences
from .prompts import SYSTEM_PROMPT, build_summary_prompt
from .token_counter import count_tokens
from .utils import validate_input, get_max_tokens, logger


@dataclass
class SummaryResult:
    """Result from summarization."""
    summary: str
    input_tokens: int
    output_tokens: int
    compression_ratio: float

    def __str__(self) -> str:
        return (
            f"{self.summary}\n\n"
            f"[Input: {self.input_tokens} tokens | "
            f"Summary: {self.output_tokens} tokens | "
            f"Reduction: {self.compression_ratio:.1%}]"
        )


class TextSummarizer:
    """Text summarizer using Azure OpenAI."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        azure_endpoint: Optional[str] = None,
        deployment_name: str = "gpt-4o-mini",
        api_version: str = "2024-02-15-preview",
    ):
        """
        Initialize TextSummarizer.
        
        Args:
            api_key: Azure OpenAI API key (or AZURE_OPENAI_API_KEY env var)
            azure_endpoint: Azure endpoint URL (or AZURE_OPENAI_ENDPOINT env var)
            deployment_name: Deployment name (or AZURE_OPENAI_DEPLOYMENT env var)
            api_version: API version to use
        """
        self.api_key = api_key or os.getenv("AZURE_OPENAI_API_KEY")
        self.azure_endpoint = azure_endpoint or os.getenv("AZURE_OPENAI_ENDPOINT")
        self.deployment_name = deployment_name or os.getenv("AZURE_OPENAI_DEPLOYMENT")
        self.api_version = api_version

        if not self.api_key or not self.azure_endpoint:
            raise ValueError(
                "Azure credentials required. Set AZURE_OPENAI_API_KEY and "
                "AZURE_OPENAI_ENDPOINT environment variables."
            )

        self.client = AzureOpenAI(
            api_key=self.api_key,
            api_version=self.api_version,
            azure_endpoint=self.azure_endpoint,
        )
        
        logger.info(f"Initialized TextSummarizer with deployment: {self.deployment_name}")

    def summarize(
        self,
        text: str,
        summary_type: str = "medium",
        tone: str = "neutral",
        chunk_size: int = 3000,
    ) -> SummaryResult:
        """
        Summarize the given text.
        
        Args:
            text: Text to summarize
            summary_type: "short" (25%), "medium" (40%), or "detailed" (60%)
            tone: "neutral", "formal", or "casual"
            chunk_size: Maximum characters per chunk
        
        Returns:
            SummaryResult with summary and metadata
        """
        # Validate input
        validate_input(text)
        
        # Count input tokens
        input_tokens = count_tokens(text)
        logger.info(f"Input: {input_tokens} tokens")
        
        # Get max tokens for output
        max_tokens = get_max_tokens(input_tokens, summary_type)
        logger.info(f"Max output tokens: {max_tokens}")
        
        # Chunk text if needed
        chunks = chunk_text_by_sentences(text, max_chunk_size=chunk_size)
        logger.info(f"Split into {len(chunks)} chunk(s)")
        
        # Summarize each chunk
        if len(chunks) == 1:
            # Single chunk - summarize directly
            summary_text = self._summarize_chunk(
                chunks[0], 
                summary_type=summary_type,
                tone=tone,
                max_tokens=max_tokens
            )
        else:
            # Multiple chunks - summarize each then combine
            logger.info("Multiple chunks detected - summarizing each chunk...")
            summaries = []
            
            for i, chunk in enumerate(chunks, 1):
                logger.info(f"Summarizing chunk {i}/{len(chunks)}...")
                chunk_summary = self._summarize_chunk(
                    chunk,
                    summary_type=summary_type,
                    tone=tone,
                    max_tokens=max_tokens
                )
                if chunk_summary:
                    summaries.append(chunk_summary)
            
            if not summaries:
                raise ValueError("Failed to summarize any chunks")
            
            # Combine summaries
            combined = "\n\n".join(summaries)
            logger.info("Combining chunk summaries...")
            
            # Re-summarize the combined summaries
            summary_text = self._summarize_chunk(
                combined,
                summary_type=summary_type,
                tone=tone,
                max_tokens=max_tokens
            )
        
        # Fallback if empty
        if not summary_text or len(summary_text.strip()) < 10:
            logger.warning("Empty response - using first sentences as fallback")
            sentences = text.split('.')[:3]
            summary_text = '. '.join(s.strip() for s in sentences if s.strip()) + '.'
        
        # Count output tokens
        output_tokens = count_tokens(summary_text)
        compression_ratio = output_tokens / input_tokens if input_tokens > 0 else 0
        
        logger.info(f"Output: {output_tokens} tokens (compression: {compression_ratio:.1%})")
        
        return SummaryResult(
            summary=summary_text,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            compression_ratio=compression_ratio,
        )

    def _summarize_chunk(
        self,
        text: str,
        summary_type: str,
        tone: str,
        max_tokens: int,
    ) -> str:
        """
        Summarize a single chunk of text.
        
        Args:
            text: Chunk to summarize
            summary_type: Type of summary
            tone: Tone for summary
            max_tokens: Maximum tokens for output
        
        Returns:
            Summarized text
        """
        # Build prompt
        prompt = build_summary_prompt(text, target_length=summary_type, tone=tone)
        
        try:
            # Call Azure OpenAI
            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                max_completion_tokens=max_tokens,
                temperature=0.5,  # Lower temperature for more focused summaries
            )
            
            summary = response.choices[0].message.content.strip()
            return summary if summary else ""
        
        except Exception as e:
            logger.error(f"Error summarizing chunk: {str(e)}")
            return ""
