"""Utility functions."""

import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("text_summarizer_gi")


def validate_input(text: str) -> bool:
    """
    Validate that input text is valid.
    
    Args:
        text: Text to validate
    
    Returns:
        True if valid
    
    Raises:
        ValueError: If text is empty or invalid
    """
    if not text or not text.strip():
        raise ValueError("Input text cannot be empty")
    return True


def get_max_tokens(text_length: int, summary_type: str = "medium") -> int:
    """
    Calculate max tokens for summary output.
    
    Args:
        text_length: Length of input text
        summary_type: "short" (25%), "medium" (40%), or "detailed" (60%)
    
    Returns:
        Max tokens for summary
    """
    ratios = {
        "short": 0.25,
        "medium": 0.40,
        "detailed": 0.60
    }
    
    ratio = ratios.get(summary_type, 0.40)
    max_tokens = max(50, int(text_length * ratio))  # Minimum 50 tokens
    return max_tokens
