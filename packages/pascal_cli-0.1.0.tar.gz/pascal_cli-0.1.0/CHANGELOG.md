# Changelog

All notable changes to pascal are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Commits follow the [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) spec.

## [Unreleased]

_No unreleased changes yet._
