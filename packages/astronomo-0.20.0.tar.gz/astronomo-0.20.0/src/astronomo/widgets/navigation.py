class Navigation:
    def compose(self):
        pass
