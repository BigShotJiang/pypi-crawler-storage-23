from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class UrlSourceOptions:
    source: str
    timeout: float = 30.0
    sheet_name: str | None = None
    client_secrets: str | None = None
    token: str = "oauth_token.json"
    port: int = 8080
    source_type: str | None = None


@dataclass
class UrlRecord:
    url: str
    html: str | None = None
    source_type: str | None = None
    source_ref: str | None = None
    metadata: dict[str, Any] | None = None
