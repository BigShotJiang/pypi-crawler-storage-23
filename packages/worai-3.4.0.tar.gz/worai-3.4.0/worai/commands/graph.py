"""CLI wrapper for graph workflows."""

from __future__ import annotations

from pathlib import Path

import typer

from worai.config import resolve_config_path
from worai.core.graph import (
    GraphSyncCreateOptions,
    GraphSyncOptions,
    PropertyDeleteOptions,
    run_graph_sync,
    run_graph_sync_create,
    run_property_delete,
)
from worai.core.wordlift import resolve_api_key
from worai.errors import UsageError

app = typer.Typer(add_completion=False, no_args_is_help=True)
sync_app = typer.Typer(add_completion=False, no_args_is_help=True)
property_app = typer.Typer(add_completion=False, no_args_is_help=True)


@sync_app.command(
    "run",
    no_args_is_help=True,
    help="Run graph sync for a configured profile.",
)
def run(
    ctx: typer.Context,
    profile: str = typer.Option(..., "--profile", help="Profile name in worai.toml."),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Write generated callback graphs to output/debug_cloud/<profile>/.",
    ),
) -> None:
    try:
        config_path = (ctx.obj or {}).get("config_path") if ctx else None
        run_graph_sync(
            GraphSyncOptions(
                profile=profile,
                config_path=config_path or resolve_config_path(None),
                debug=debug,
            )
        )
    except ValueError as exc:
        raise UsageError(str(exc)) from exc


@sync_app.command(
    "create",
    no_args_is_help=True,
    help="Create a graph sync project from a Copier template.",
)
def create(
    destination: Path | None = typer.Argument(
        None,
        metavar="DESTINATION",
        help="Output directory where the graph sync project will be created.",
    ),
    template: str = typer.Option(
        "gh:wordlift/graph-sync-template",
        "--template",
        help="Copier template source (Git URL, gh: shortcut, or local path).",
    ),
    defaults: bool = typer.Option(
        False,
        "--defaults",
        help="Use Copier default answers.",
    ),
    data_file: Path | None = typer.Option(
        None,
        "--data-file",
        help="Path to a Copier data file with pre-filled answers.",
    ),
    vcs_ref: str | None = typer.Option(
        None,
        "--vcs-ref",
        help="Template VCS ref (tag, branch, or commit).",
    ),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Disable prompts and fail if required answers are missing.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Allow writing into existing destinations.",
    ),
) -> None:
    if destination is None:
        if non_interactive:
            raise UsageError("Destination path is required when using --non-interactive.")
        destination = Path(typer.prompt("Destination directory"))

    run_graph_sync_create(
        GraphSyncCreateOptions(
            destination=destination,
            template=template,
            defaults=defaults,
            data_file=data_file,
            vcs_ref=vcs_ref,
            non_interactive=non_interactive,
            force=force,
        )
    )


app.add_typer(sync_app, name="sync", help="Run graph sync workflows.")


@property_app.command(
    "delete",
    no_args_is_help=True,
    help="Delete one predicate from all matching entities in the graph.",
)
def property_delete(
    ctx: typer.Context,
    predicate: str = typer.Argument(..., help="Predicate IRI or CURIE (for example, seovoc:html)."),
    endpoint: str = typer.Option(
        "https://api.wordlift.io/graphql", "--endpoint", help="WordLift GraphQL endpoint."
    ),
    entities_endpoint: str = typer.Option(
        "https://api.wordlift.io/entities", "--entities-endpoint", help="WordLift entities API endpoint."
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="List matches without applying changes."),
    yes: bool = typer.Option(False, "--yes", help="Skip confirmation prompt."),
    workers: int = typer.Option(4, "--workers", help="Number of concurrent PATCH requests."),
    retries: int = typer.Option(3, "--retries", help="Retries per failed PATCH request."),
    rate_delay: float = typer.Option(0.0, "--rate-delay", help="Delay in seconds after each successful PATCH."),
    limit: int = typer.Option(0, "--limit", help="Limit number of matching entities to process."),
    timeout: int = typer.Option(60, "--timeout", help="HTTP timeout in seconds."),
) -> None:
    api_key = resolve_api_key(ctx.obj.get("config") if ctx and ctx.obj else None)
    if not api_key:
        raise UsageError("WORDLIFT_KEY is required (or set wordlift.api_key in config).")

    options = PropertyDeleteOptions(
        api_key=api_key,
        predicate=predicate,
        graphql_endpoint=endpoint,
        entities_endpoint=entities_endpoint,
        dry_run=True,
        workers=workers,
        retries=retries,
        rate_delay=rate_delay,
        limit=limit,
        timeout=timeout,
    )
    try:
        summary = run_property_delete(options)
    except ValueError as exc:
        raise UsageError(str(exc)) from exc

    typer.echo(f"Predicate: {summary.predicate}")
    typer.echo(f"Matching entities: {summary.candidates}")
    if dry_run:
        return

    if summary.candidates == 0:
        return

    if not yes:
        typer.confirm(
            f"Delete predicate {summary.predicate} from {summary.candidates} entities?",
            abort=True,
        )

    execute_options = PropertyDeleteOptions(
        api_key=options.api_key,
        predicate=options.predicate,
        graphql_endpoint=options.graphql_endpoint,
        entities_endpoint=options.entities_endpoint,
        dry_run=False,
        workers=options.workers,
        retries=options.retries,
        rate_delay=options.rate_delay,
        limit=options.limit,
        timeout=options.timeout,
    )
    result = run_property_delete(execute_options)
    typer.echo(f"Attempted: {result.attempted}")
    typer.echo(f"Removed: {result.removed}")
    typer.echo(f"Failed: {result.failed}")
    if result.failed:
        raise UsageError("Some entities failed to patch. Re-run with lower --workers or higher --retries.")


app.add_typer(property_app, name="property", help="Bulk predicate operations on the graph.")
