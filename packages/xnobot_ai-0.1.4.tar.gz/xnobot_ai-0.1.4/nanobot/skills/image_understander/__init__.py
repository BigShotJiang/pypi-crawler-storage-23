# Image understander skill - OCR and image analysis
