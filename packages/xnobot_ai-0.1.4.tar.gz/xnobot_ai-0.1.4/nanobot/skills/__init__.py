# Skill definitions for nanobot agent
