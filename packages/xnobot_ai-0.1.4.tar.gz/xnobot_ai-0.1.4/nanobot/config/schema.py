"""Configuration schema using Pydantic."""

from pathlib import Path
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class WhatsAppConfig(BaseModel):
    """WhatsApp channel configuration."""
    enabled: bool = False
    bridge_url: str = "ws://localhost:3001"
    allow_from: list[str] = Field(default_factory=list)  # Allowed phone numbers


class TelegramConfig(BaseModel):
    """Telegram channel configuration."""
    enabled: bool = False
    token: str = ""  # Bot token from @BotFather
    allow_from: list[str] = Field(default_factory=list)  # Allowed user IDs or usernames
    proxy_url: str = ""  # Optional proxy for api.telegram.org (e.g. http://127.0.0.1:7890 or socks5://127.0.0.1:1080)


class WeComConfig(BaseModel):
    """企业微信 (WeCom) channel configuration."""
    enabled: bool = False
    corp_id: str = ""  # 企业 ID，在「我的企业」-「企业信息」获取
    agent_id: int = 0  # 应用 AgentId，在「应用管理」-「自建」里查看
    secret: str = ""  # 应用 Secret
    allow_from: list[str] = Field(default_factory=list)  # 允许接收消息的企业成员 UserID，空则允许全部


class ShangwangConfig(BaseModel):
    """商网办公 channel configuration (connects to shangwang-bridge WebSocket)."""
    enabled: bool = False
    bridge_url: str = "ws://localhost:3010"
    allow_from: list[str] = Field(default_factory=list)  # Allowed chat_id/sender, empty = allow all
    # 文件下载失败时从此目录复制（如 C:\Zoolo\AvicOffice Files），bridge 会优先读取 xnobot 配置
    avicoffice_cache_dir: str = ""
    # 群聊仅回复 @提及 的消息，可配置多个昵称（如 ["程昱涵"]），私聊不受影响
    mention_names: list[str] = Field(default_factory=list)
    # 群聊回复最大字数（字符），超出则截断
    group_reply_max_length: int = 200
    # 私聊中过短消息（如「好的」「1」、emoji）不回复，≤N 字符则跳过
    skip_short_replies: bool = True
    short_reply_max_length: int = 2
    # 聊天历史记录：用于学习管理员回复口吻，区分客户 vs 管理员
    chat_history_enabled: bool = True
    admin_names: list[str] = Field(default_factory=list)  # 管理员昵称
    admin_ids: list[str] = Field(default_factory=list)  # 管理员账号 ID（二选一或同时配置）


class ChannelsConfig(BaseModel):
    """Configuration for chat channels."""
    whatsapp: WhatsAppConfig = Field(default_factory=WhatsAppConfig)
    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    wecom: WeComConfig = Field(default_factory=WeComConfig)
    shangwang: ShangwangConfig = Field(default_factory=ShangwangConfig)


class AgentDefaults(BaseModel):
    """Default agent configuration."""
    workspace: str = "~/.xnobot/workspace"
    model: str = "anthropic/claude-opus-4-5"
    max_tokens: int = 8192
    temperature: float = 0.7
    max_tool_iterations: int = 20


class AgentsConfig(BaseModel):
    """Agent configuration."""
    defaults: AgentDefaults = Field(default_factory=AgentDefaults)


class ProviderConfig(BaseModel):
    """LLM provider configuration."""
    api_key: str = ""
    api_base: str | None = None


class ProvidersConfig(BaseModel):
    """Configuration for LLM providers."""
    anthropic: ProviderConfig = Field(default_factory=ProviderConfig)
    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    openrouter: ProviderConfig = Field(default_factory=ProviderConfig)
    groq: ProviderConfig = Field(default_factory=ProviderConfig)
    zhipu: ProviderConfig = Field(default_factory=ProviderConfig)
    vllm: ProviderConfig = Field(default_factory=ProviderConfig)
    gemini: ProviderConfig = Field(default_factory=ProviderConfig)


class GatewayConfig(BaseModel):
    """Gateway/server configuration."""
    host: str = "0.0.0.0"
    port: int = 18790


class WebSearchConfig(BaseModel):
    """Web search tool configuration."""
    api_key: str = ""  # Brave Search API key
    max_results: int = 5
    proxy: str = ""  # 可选，如 http://127.0.0.1:7890，国内请求 Brave API 超时时可配代理


class WebToolsConfig(BaseModel):
    """Web tools configuration."""
    search: WebSearchConfig = Field(default_factory=WebSearchConfig)


class ExecToolConfig(BaseModel):
    """Shell exec tool configuration."""
    timeout: int = 60
    restrict_to_workspace: bool = False  # If true, block commands accessing paths outside workspace


class KnowledgeConfig(BaseModel):
    """Local knowledge base (RAG) configuration."""
    enabled: bool = True
    chunk_size: int = 512  # tokens (approx chars for Chinese ~2x)
    chunk_overlap: int = 200
    top_k: int = 5  # default number of chunks to retrieve per search
    web_cache_enabled: bool = True  # save web_search/web_fetch results to 短期/_cache_web, cleared weekly
    short_term_retention_days: int = 7  # 短期知识保留天数，超期自动清理


class ToolsConfig(BaseModel):
    """Tools configuration."""
    web: WebToolsConfig = Field(default_factory=WebToolsConfig)
    exec: ExecToolConfig = Field(default_factory=ExecToolConfig)
    knowledge: KnowledgeConfig = Field(default_factory=KnowledgeConfig)


class Config(BaseSettings):
    """Root configuration for xnobot."""
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    gateway: GatewayConfig = Field(default_factory=GatewayConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    
    @property
    def workspace_path(self) -> Path:
        """Get expanded workspace path."""
        return Path(self.agents.defaults.workspace).expanduser()
    
    def get_api_key(self) -> str | None:
        """Get API key in priority order: OpenRouter > Anthropic > OpenAI > Gemini > Zhipu > Groq > vLLM."""
        return (
            self.providers.openrouter.api_key or
            self.providers.anthropic.api_key or
            self.providers.openai.api_key or
            self.providers.gemini.api_key or
            self.providers.zhipu.api_key or
            self.providers.groq.api_key or
            self.providers.vllm.api_key or
            None
        )
    
    def get_api_base(self) -> str | None:
        """Get API base URL if using OpenRouter, Zhipu or vLLM."""
        if self.providers.openrouter.api_key:
            return self.providers.openrouter.api_base or "https://openrouter.ai/api/v1"
        if self.providers.zhipu.api_key:
            return self.providers.zhipu.api_base
        if self.providers.vllm.api_base:
            return self.providers.vllm.api_base
        return None
    
    class Config:
        env_prefix = "XNOBOT_"
        env_nested_delimiter = "__"
