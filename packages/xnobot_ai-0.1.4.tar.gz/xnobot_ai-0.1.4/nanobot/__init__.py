"""
xnobot - A lightweight AI agent framework
"""

__version__ = "0.1.4"
__logo__ = "Xnobot"
