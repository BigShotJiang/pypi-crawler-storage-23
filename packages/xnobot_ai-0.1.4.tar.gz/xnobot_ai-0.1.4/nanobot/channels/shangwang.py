"""商网办公 channel: connects to shangwang-bridge via WebSocket."""

import asyncio
import json
import re
import shutil
import time
from pathlib import Path

from loguru import logger

from nanobot.bus.events import OutboundMessage
from nanobot.bus.queue import MessageBus
from nanobot.channels.base import BaseChannel
from nanobot.config.schema import ShangwangConfig

# 知识库支持的文档格式，自动保存到 workspace/knowledge/长期/来自商网
_KNOWLEDGE_EXTS = {".pdf", ".docx", ".xlsx", ".txt", ".md"}
_LONG_TERM_DIR = "长期"


def _markdown_table_to_list(text: str) -> str:
    """将 Markdown 表格转为列表形式（商网不渲染表格）。"""
    lines = text.split("\n")
    result: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        # 检测表格行：以 | 开头和结尾
        if re.match(r"^\|.+\|$", line):
            rows: list[list[str]] = []
            while i < len(lines) and re.match(r"^\|.+\|$", lines[i]):
                cells = [c.strip() for c in lines[i].split("|")[1:-1]]
                if cells:
                    rows.append(cells)
                i += 1
            if len(rows) >= 2:
                # 第一行表头，第二行分隔符（|---|），数据从第三行起
                header = rows[0]
                is_sep = len(rows) > 1 and all(
                    re.match(r"^[-:\s]+$", c) for c in rows[1]
                )
                data_start = 2 if is_sep else 1
                for row in rows[data_start:]:
                    if len(row) == len(header):
                        parts = [f"{h}：{v}" for h, v in zip(header, row) if v]
                        result.append("\n".join(f"- {p}" for p in parts))
                    elif len(row) == 1 and row[0]:
                        result.append(f"- {row[0]}")
            continue
        result.append(line)
        i += 1
    return "\n".join(result)


def _markdown_to_plain_text(text: str) -> str:
    """将 Markdown 转为纯文本，商网办公无法渲染 Markdown 时使用。"""
    if not text:
        return text
    t = text
    # 表格 -> 列表形式（需在其它替换前处理，避免 | 被破坏）
    t = _markdown_table_to_list(t)
    # 代码块 ```...``` -> 保留内容
    t = re.sub(r"```(?:[\w]*\n)?(.*?)```", r"\1", t, flags=re.DOTALL)
    # 行内代码 `...` -> 保留内容
    t = re.sub(r"`([^`]+)`", r"\1", t)
    # 链接 [text](url) -> text
    t = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", t)
    # 加粗 **text** 或 __text__
    t = re.sub(r"\*\*([^*]+)\*\*", r"\1", t)
    t = re.sub(r"__([^_]+)__", r"\1", t)
    # 斜体 *text* 或 _text_（避免误伤列表）
    t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", t)
    t = re.sub(r"(?<!_)_([^_]+)_(?!_)", r"\1", t)
    # 标题 ## -> 去掉井号，保留内容
    t = re.sub(r"^#{1,6}\s+", "", t, flags=re.MULTILINE)
    # 多余空行压缩
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


class ShangwangChannel(BaseChannel):
    """
    ‌商网 channel that connects to shangwang-bridge (Windows, China-only).
    No Windows or UI code here; protocol only.
    """

    name = "shangwang"

    def __init__(
        self,
        config: ShangwangConfig,
        bus: MessageBus,
        workspace: Path | None = None,
    ):
        super().__init__(config, bus)
        self.config: ShangwangConfig = config
        self._workspace = Path(workspace).expanduser() if workspace else None
        self._ws = None
        self._connected = False
        self._recorder = None
        if workspace and config.chat_history_enabled:
            from nanobot.chat_history.recorder import ChatHistoryRecorder
            self._recorder = ChatHistoryRecorder(
                workspace=workspace,
                admin_names=config.admin_names,
                admin_ids=config.admin_ids,
            )

    async def start(self) -> None:
        """Connect to shangwang-bridge and listen."""
        import websockets

        bridge_url = self.config.bridge_url
        logger.info("Connecting to 商网 bridge at {}...", bridge_url)

        self._running = True

        while self._running:
            try:
                async with websockets.connect(bridge_url) as ws:
                    self._ws = ws
                    self._connected = True
                    logger.info("Connected to 商网 bridge")

                    async for message in ws:
                        try:
                            await self._handle_bridge_message(message)
                        except Exception as e:
                            logger.error("Error handling 商网 bridge message: %s", e)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self._connected = False
                self._ws = None
                logger.warning("商网 bridge connection error: {}", e)
                if self._running:
                    logger.info("Reconnecting in 5 seconds...")
                    await asyncio.sleep(5)

    async def stop(self) -> None:
        """Stop the channel."""
        self._running = False
        self._connected = False
        if self._ws:
            await self._ws.close()
            self._ws = None

    def _save_docs_to_knowledge(self, raw_media: list[str], content: str) -> list[str]:
        """
        将对话中的文档自动复制到 workspace/knowledge/长期/来自商网/。
        返回供 agent 使用的路径列表：文档用 knowledge 路径，图片保留原路径。
        """
        if not raw_media or not self._workspace:
            return list(raw_media)

        knowledge_dir = self._workspace / "knowledge" / _LONG_TERM_DIR / "来自商网"
        knowledge_dir.mkdir(parents=True, exist_ok=True)
        result = []

        for path_str in raw_media:
            p = Path(path_str)
            if not p.is_file():
                result.append(path_str)
                continue

            ext = p.suffix.lower()
            if ext in _KNOWLEDGE_EXTS:
                # 文档：复制到 knowledge，避免重名加时间戳
                safe_name = re.sub(r'[<>:"/\\|?*]', "_", p.name)[:100] or f"doc{ext}"
                dest = knowledge_dir / safe_name
                if dest.exists():
                    dest = knowledge_dir / f"{p.stem[:50]}_{int(time.time())}{ext}"
                try:
                    shutil.copy2(p, dest)
                    result.append(str(dest))
                    logger.info("商网文档已自动保存到知识库: %s", dest.name)
                except OSError as e:
                    logger.warning("复制文档到知识库失败: %s", e)
                    result.append(path_str)
            else:
                # 图片等：保留原路径供 agent 使用
                result.append(path_str)

        return result

    def _is_mentioned(self, content: str) -> bool:
        """检查消息是否 @提及 了任一配置的昵称。支持 @程昱涵、@ 程昱涵 等格式。"""
        if not content or not self.config.mention_names:
            return False
        for name in self.config.mention_names:
            if not name:
                continue
            # @程昱涵 或 @ 程昱涵
            if re.search(r"@\s*" + re.escape(name), content):
                return True
        return False

    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through 商网 bridge. 商网无法渲染 Markdown，自动转为纯文本。"""
        if not self._ws or not self._connected:
            logger.warning("商网 bridge not connected")
            return
        try:
            plain = _markdown_to_plain_text(msg.content or "")
            if not plain.strip():
                plain = "处理完成，但暂无文字回复。"
            # 群聊回复截断至配置的最大字数
            if "team" in msg.chat_id:
                max_len = self.config.group_reply_max_length
                if len(plain) > max_len:
                    plain = plain[:max_len].rstrip() + "…"
                    logger.debug("群聊回复已截断至 %d 字", max_len)
            payload = {"type": "send", "chat_id": msg.chat_id, "text": plain}
            await self._ws.send(json.dumps(payload, ensure_ascii=False))
        except Exception as e:
            logger.error("Error sending 商网 message: %s", e)

    async def _handle_bridge_message(self, raw: str | bytes) -> None:
        """Handle a message from the bridge."""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Invalid JSON from 商网 bridge: %s", raw[:100])
            return

        msg_type = data.get("type")

        if msg_type == "message":
            sender = data.get("sender", "shangwang")
            sender_id = data.get("sender_id", "")
            chat_id = data.get("chat_id", "current")
            content = data.get("content", "")
            is_group = data.get("is_group", False)

            if self._recorder:
                self._recorder.record(
                    channel=self.name,
                    chat_id=chat_id,
                    sender=sender,
                    content=content,
                    sender_id=sender_id,
                    is_group=is_group,
                    timestamp=data.get("timestamp"),
                    id_client=data.get("id_client", ""),
                )

            if not self.is_allowed(sender):
                return

            # 群聊：仅当配置了 mention_names 且消息 @提及 了任一配置名时才回复
            if is_group and self.config.mention_names:
                if not self._is_mentioned(content):
                    logger.debug("群聊消息未 @提及 配置昵称，跳过: %s", content[:50])
                    return

            # 私聊：过短消息（如「好的」「1」、emoji）不回复（有文件附件时不过滤）
            raw_media = data.get("media", []) or []
            if not is_group and self.config.skip_short_replies and not raw_media:
                stripped = content.strip()
                if len(stripped) <= self.config.short_reply_max_length:
                    logger.debug("私聊消息过短，跳过: %s", repr(stripped[:20]))
                    return

            # 自动保存文档到 workspace/knowledge/来自商网，并传递最终路径给 agent
            media_paths = self._save_docs_to_knowledge(raw_media, content)

            # 将附件路径附加到 content，便于 agent 识别并执行 knowledge_ingest
            if media_paths:
                paths_desc = "\n".join(f"[附件: {p}]" for p in media_paths)
                content = f"{content}\n\n{paths_desc}" if content.strip() else paths_desc

            await self._handle_message(
                sender_id=sender,
                chat_id=chat_id,
                content=content,
                media=media_paths,
                metadata={"timestamp": data.get("timestamp"), "is_group": is_group},
            )
        elif msg_type == "status":
            logger.info("商网 bridge status: {}", data.get("status"))
            if data.get("status") == "ready":
                self._connected = True
            elif data.get("status") in ("disconnected", "sent"):
                pass
        elif msg_type == "error":
            logger.error("商网 bridge error: {}", data.get("error"))
