"""Allow ``python -m cortex`` to run the CLI."""
from cortex.cli import main

main()
