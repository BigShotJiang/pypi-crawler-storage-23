import tifffile
from cellstitch_cuda.pipeline import cellstitch_cuda

img = r'E:\1_DATA\Rheenen\tvl_jr\11237\analysis\2025-12-19_2572192_CIS_2M_ColonNormal\2025Dec19_2572192_CIS_2M_ColonNormal_tilescan-1position-2\output.tif'

masks = cellstitch_cuda(
    img,
    output_masks=True,
    verbose=True,
    seg_mode="cells",
    interpolation=False,
    n_jobs=-1,
    z_step=2,
    pixel_size=1/2.2,
    bleach_correct=False,
)

# masks = tifffile.imread(r"Z:\Rheenen\tvl_jr\SP8\2025Mar6_2516017_DiLiCre-4mg-2d_2W_Ileum\2025Mar6_2516017_DiLiCre-4mg-2d_2W_Ileum-2\cellstitch_masks_pre-correction.tif")
#
# masks = correction(masks, outpath=r"E:\Tom", n_jobs=-1)

tifffile.imwrite(r"E:\1_DATA\Rheenen\tvl_jr\11237\analysis\2025-12-19_2572192_CIS_2M_ColonNormal\2025Dec19_2572192_CIS_2M_ColonNormal_tilescan-1position-2\cellstitch_masks.tif", masks)
# tifffile.imwrite(r"E:\1_DATA\Rheenen\tvl_jr\BIF_WKS_2025_025\2024Nov22_SI_1mg_1year_3D_2D-merge\Villus_crops\2024Nov22_SI_1mg_1year_3D_2D-merge-1-2\cellstitch_masks_interp.tif", masks_interp)