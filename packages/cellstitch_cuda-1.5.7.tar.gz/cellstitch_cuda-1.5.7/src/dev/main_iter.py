import os.path
import tifffile
from cellstitch_cuda.pipeline import cellstitch_cuda

imgs = [
    r"E:\1_DATA\Rheenen\tvl_jr\temp\output.tif",
]

folders = [os.path.split(img)[0] for img in imgs]
for i, img in enumerate(imgs):
    masks = cellstitch_cuda(
        img,
        output_masks=True,
        verbose=True,
        seg_mode="cells",
        interpolation=False,
        n_jobs=-1,
        z_step=2,
        pixel_size=1/2.2,
        bleach_correct=False,
    )

    tifffile.imwrite(os.path.join(folders[i], "cellstitch_masks.tif"), masks)
