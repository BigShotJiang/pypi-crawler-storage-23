import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from prime_mcp.operations import (
    ChecklistItem,
    GuidelineItem,
    IncidentTypeItem,
)

COMPANY_GUIDELINES = Path(__file__).parent / "company_guidelines"

GUIDELINE_FILES = [
    "agent_behavior_and_autonomy_controls.json",
    "audit_logging_and_monitoring.json",
    "authentication_and_authorization.json",
    "data_protection_and_privacy.json",
    "input_validation_and_prompt_security.json",
    "mcp_supply_chain_and_third_party_risk.json",
    "mcp_transport_and_connection_security.json",
    "security_testing_requirements.json",
]


def _load_json(filename: str) -> dict[str, Any]:
    return json.loads((COMPANY_GUIDELINES / filename).read_text())


def _register_guideline_tools(mcp: FastMCP) -> None:
    for filename in GUIDELINE_FILES:
        meta = _load_json(filename)
        tool_name = Path(filename).stem
        title = meta.get("title", tool_name)
        description = meta.get("description") or title

        def _make_tool(fn: str) -> Callable[[], list[GuidelineItem]]:
            def tool() -> list[GuidelineItem]:
                data = _load_json(fn)
                return [GuidelineItem.model_validate(item) for item in data["guidelines"]]

            return tool

        tool_fn = _make_tool(filename)
        tool_fn.__name__ = tool_name
        tool_fn.__doc__ = f"{title}\n\n{description}"
        mcp.tool(name=tool_name)(tool_fn)

    @mcp.tool()
    def incident_response() -> list[IncidentTypeItem]:
        """Incident Response for MCP & AI Agent Systems

        MCP-integrated agents introduce new incident categories that traditional runbooks
        may not cover. This section defines response procedures for agent-specific security events.
        """
        data = _load_json("incident_response.json")
        return [IncidentTypeItem.model_validate(item) for item in data["incident_types"]]

    @mcp.tool()
    def developer_compliance_checklist() -> list[ChecklistItem]:
        """Developer Compliance Checklist

        Use this checklist before submitting any MCP-integrated feature for security review.
        All MUST items must be checked. SHOULD items require documented risk acceptance if skipped.
        """
        data = _load_json("developer_compliance_checklist.json")
        items: list[ChecklistItem] = []
        for category, entries in data["checklist"].items():
            items.extend(ChecklistItem(id=entry["id"], item=entry["item"], category=category) for entry in entries)
        return items


def _register_search_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def search_guidelines(query: str) -> list[GuidelineItem]:
        """Search across all security guidelines by keyword.

        Performs a case-insensitive substring search across all text fields
        (id, guideline, rationale, framework_ref, level) of every guideline.
        Use this when you need to find guidelines related to a topic without
        knowing which specific section they belong to.
        """
        query_lower = query.lower()
        results: list[GuidelineItem] = []
        for filename in GUIDELINE_FILES:
            data = _load_json(filename)
            results.extend(
                GuidelineItem.model_validate(item)
                for item in data["guidelines"]
                if any(query_lower in str(v).lower() for v in item.values())
            )
        return results

    @mcp.tool()
    def get_guideline_by_id(guideline_id: str) -> list[GuidelineItem]:
        """Look up a specific guideline by its ID.

        Returns the matching guideline for an ID such as 'AG-01', 'D-03', 'T-02', etc.
        The result is a list containing the single matching guideline, or an empty list
        if the ID is not found.
        """
        for filename in GUIDELINE_FILES:
            data = _load_json(filename)
            for item in data["guidelines"]:
                if item["id"] == guideline_id:
                    return [GuidelineItem.model_validate(item)]
        return []

    @mcp.tool()
    def get_guidelines_by_level(level: str) -> list[GuidelineItem]:
        """Filter all guidelines by compliance level.

        Accepts a level of 'MUST', 'SHOULD', or 'MAY' and returns every guideline
        across all sections that matches. Use this for compliance reporting or to
        identify all mandatory controls.
        """
        level_upper = level.upper()
        results: list[GuidelineItem] = []
        for filename in GUIDELINE_FILES:
            data = _load_json(filename)
            results.extend(
                GuidelineItem.model_validate(item)
                for item in data["guidelines"]
                if item["level"].upper() == level_upper
            )
        return results


def _register_resources(mcp: FastMCP) -> None:
    @mcp.resource("guidelines://purpose-and-scope")
    def purpose_and_scope() -> str:
        """Purpose & Scope -- document metadata, audience, compliance levels, and referenced frameworks."""
        return json.dumps(_load_json("purpose_and_scope.json"), indent=2)

    @mcp.resource("guidelines://document-governance")
    def document_governance() -> str:
        """Document Governance -- revision history, review schedule, and exception process."""
        return json.dumps(_load_json("document_governance.json"), indent=2)


def _register_prompts(mcp: FastMCP) -> None:
    @mcp.prompt()
    def security_code_review(code: str) -> str:
        """Review code against MCP security guidelines.

        Generates a structured security review prompt that instructs the reviewer
        to assess the provided code against authentication, input validation,
        data protection, and transport security guidelines.
        """
        return (
            "You are a security reviewer. Review the following code against the company's "
            "MCP security guidelines.\n\n"
            "Steps:\n"
            "1. Call the `search_guidelines` tool with relevant keywords from the code "
            "(e.g. 'authentication', 'TLS', 'PII', 'input validation').\n"
            "2. Call `get_guidelines_by_level` with level 'MUST' to get all mandatory controls.\n"
            "3. For each MUST-level guideline that is relevant to this code, assess whether "
            "the code complies. Report: PASS, FAIL, or NEEDS REVIEW.\n"
            "4. Summarize findings with a list of non-compliant items and recommended fixes.\n\n"
            f"Code to review:\n```\n{code}\n```"
        )

    @mcp.prompt()
    def compliance_assessment(feature_description: str) -> str:
        """Assess a feature against the developer compliance checklist.

        Generates a structured compliance assessment prompt that walks through
        every checklist item for the described feature.
        """
        return (
            "You are a compliance assessor. Evaluate the following feature against the "
            "company's MCP developer compliance checklist.\n\n"
            "Steps:\n"
            "1. Call the `developer_compliance_checklist` tool to retrieve all checklist items.\n"
            "2. For each checklist item, assess whether the described feature satisfies it.\n"
            "3. Report each item as: PASS, FAIL, or NEEDS REVIEW.\n"
            "4. All MUST items that FAIL are release blockers — highlight them clearly.\n"
            "5. Provide a summary with the overall compliance percentage and critical gaps.\n\n"
            f"Feature description:\n{feature_description}"
        )

    @mcp.prompt()
    def incident_triage(event_description: str) -> str:
        """Triage a security event using incident response procedures.

        Generates a structured incident triage prompt that matches the event
        to the appropriate incident type and response procedure.
        """
        return (
            "You are a security incident responder. Triage the following security event "
            "using the company's MCP incident response procedures.\n\n"
            "Steps:\n"
            "1. Call the `incident_response` tool to retrieve all incident type definitions.\n"
            "2. Match the event description to the most relevant incident type based on "
            "the detection signals.\n"
            "3. Report: the matched incident type, the detection signals that match, "
            "and the full immediate response procedure.\n"
            "4. If the event matches multiple incident types, list all of them ranked "
            "by relevance.\n"
            "5. If no incident type matches, state that clearly and recommend escalation.\n\n"
            f"Security event:\n{event_description}"
        )


async def main():
    mcp = FastMCP("Prime-MCP")
    _register_guideline_tools(mcp)
    _register_search_tools(mcp)
    _register_resources(mcp)
    _register_prompts(mcp)
    await mcp.run_stdio_async()
