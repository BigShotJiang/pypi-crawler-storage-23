import socket
import time

class JudgementClient:
    def __init__(self, host="localhost", port=12345, server_ip="127.0.0.1", server_port=12345):
        self.host = host
        self.port = port
        self.server_ip = server_ip
        self.server_port = server_port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def send_message_to_server(self, message):
        self.socket.sendall(message.encode("utf-8"))

    def receive_message_from_server(self):
        return self.socket.recv(4096).decode("utf-8")
    
    def start(self):
        self.socket.connect((self.server_ip, self.server_port))
        print("Connected to server!")
        time.sleep(0.5)
        
        # Receive greeting from server
        greeting = self.receive_message_from_server()
        print(greeting, end="")  # Show "What is your name?: "
        time.sleep(0.1)
        
        # Get user input
        name = input().strip()
        
        # Send name back to server
        self.send_message_to_server(name)
        print(f"Registered as: {name}")
        time.sleep(0.1)
        return True

    def close(self):
        self.socket.close()

    def __del__(self):
        self.close()
