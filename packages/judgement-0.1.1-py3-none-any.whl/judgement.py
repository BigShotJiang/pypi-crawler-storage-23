import argparse

from game.dealer import Game
from game.player import Player
def get_all_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="0.0.0.0", 
                       help="Server bind address. Use '0.0.0.0' to accept connections from any network interface (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=12345,
                       help="Server port number (default: 12345)")
    parser.add_argument("--server_ip", type=str, default="127.0.0.1",
                       help="IP address of the game server to connect to (for players). Use the server's network IP for remote connections.")
    parser.add_argument("--server_port", type=int, default=12345,
                       help="Port number of the game server (default: 12345)")
    parser.add_argument("--mode", type=str, default="player", choices=["player", "dealer"],
                       help="Mode: 'player' to join a game, 'dealer' to host a game")
    parser.add_argument("--players_count", type=int, default=3,
                       help="Number of players (for dealer mode, default: 3)")
    return parser.parse_args()

def setup_dealer(all_args):
    player_count = input("Enter the number of players: ")
    all_args.players_count = int(player_count)
    rounds_num = int(input("Enter the number of rounds: "))
    dealer = Game(all_args.host, all_args.port, all_args.server_ip, all_args.server_port, all_args.players_count, rounds_num)
    dealer.start_game()
    
    

def setup_player(all_args):
    print("\n\nWELCOME TO THE GAME: JUDGEMENT !!!!\n\n")
    server_ip = input("Enter room's IP address: ")
    server_port = int(input("Enter room's PIN: "))
    player = Player(all_args.host, all_args.port, all_args.server_ip, all_args.server_port)
    player.start()

def main():
    all_args = get_all_arguments()
    if all_args.mode == "player":
        setup_player(all_args)
    elif all_args.mode == "dealer":
        setup_dealer(all_args)
    else:
        print("Invalid mode")

if __name__ == "__main__":
    main()
