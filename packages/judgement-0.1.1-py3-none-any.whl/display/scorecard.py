game_state = {
    "players": {
        "Anshu": {
            "name": "Player 1",
            "scores": [10, 11, 11, 0, 0],
            "cards": [],
        },
        "Rutu": {
            "name": "Player 1",
            "scores": [10, 13, 0, 0, 13],
            "cards": [],
        },
        "Sub-Zer0": {
            "name": "Player 1",
            "scores": [10, 10, 0, 0, 0],
            "cards": [],
        },
    },
    "player_seq": ["Anshu", "Rutu", "Sub-Zer0"],
    "total_rounds": 7,
    "trump_seq": ["S", "H", "C", "D"],
    "current_round": 6,
}

suites = {
    "h": "♥",
    "d": "♦",
    "c": "♣",
    "s": "♠"
}
suite_names = {
    "♥": "Hearts",
    "♦": "Diamonds",
    "♣": "Clubs",
    "♠": "Spades"
}

def get_scorecard_str(game_state):
    column_names = f"│ ROUNDS │ Trump │"
    
    round_list = []
    trump_per_round = []
    
    for player in game_state["player_seq"]:
        column_names += f"{player:^10}│"

    for i in range(1, game_state["total_rounds"] + 1):
        round_num_display = "{} ({})".format(i, game_state["total_rounds"] - i + 1)
        _line = f"│{round_num_display:^8}│"

        total_cards = game_state["total_rounds"] - i + 1
        trump_display = suites[game_state["trump_seq"][(total_cards - 1) % 4].lower()]
        _line += f"{trump_display:^7}│"
        trump_per_round.append([trump_display, suite_names[trump_display]])

        for j in range(len(game_state["player_seq"])):
            player = game_state["player_seq"][j]
            # import pdb; pdb.set_trace()
            try:
                score = game_state["players"][player]["scores"][i - 1] if i - 1 < len(game_state["players"][player]["scores"]) else "-"
            except:
                import pdb; pdb.set_trace()
            _line += f"{score:^10}│"
        
        if i == game_state["current_round"]:
                _line += " <== Round Ended"

        round_list.append(_line)

    top_line = "┌" + "─" * (len(column_names) - 2) + "┐"
    bottom_line = "└" + "─" * (len(column_names) - 2) + "┘"
    separator_line = "├" + "─" * (len(column_names) - 2) + "┤"

    pre_seq = [top_line, column_names, separator_line]
    post_seq = [bottom_line]
    
    return "\n".join(pre_seq + round_list + post_seq), trump_per_round

if __name__ == "__main__":
    scorecard, trump_per_round = get_scorecard_str(game_state)
    print(scorecard)
    print(trump_per_round)
    