"""NadirClaw — Open-source LLM router."""

__version__ = "0.5.0"
