"""Entry point for the ``wifi-config-gui`` command.

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .wifi_config_gui import main as wifi_config_main


def main() -> None:
    """Launch the WiFi Configuration GUI."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"wifi-config-gui {__version__}")
        return
    wifi_config_main()


if __name__ == "__main__":
    main()
