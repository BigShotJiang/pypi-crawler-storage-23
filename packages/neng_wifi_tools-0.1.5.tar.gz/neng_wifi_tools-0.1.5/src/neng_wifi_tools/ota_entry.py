"""Entry point for the ``update-firmware`` command.

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .ota_client import main as ota_main


def main() -> None:
    """Launch the OTA firmware update client."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"update-firmware {__version__}")
        return
    sys.exit(ota_main())


if __name__ == "__main__":
    main()
