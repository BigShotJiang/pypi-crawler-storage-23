"""NEnG WiFi Tools — WiFi configuration, OTA updates, and device scanning.

Provides reusable modules for all NEnG instrument subprojects:
- ``device_scanner``: Fast network scanner for NEnG instruments on port 5025
- ``wifi_config_gui``: Professional WiFi Configuration GUI
- ``ota_client``: OTA firmware update client with git-aware deployment
- ``ota_manager_gui``: OTA Firmware Update Manager GUI

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

__all__ = ["__version__"]

__version__ = "0.1.5"
