"""Ingestion module for importing external data sources into memories."""

from remembra.ingestion.changelog import ChangelogParser, ChangelogRelease

__all__ = ["ChangelogParser", "ChangelogRelease"]
