from enum import Enum


class Visibility(Enum):
    PUBLIC = "pub"
    PRIVATE = "pvt"