"""Guard module unit tests."""
