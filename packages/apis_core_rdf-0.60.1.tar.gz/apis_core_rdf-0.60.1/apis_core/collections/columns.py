from apis_core.generic.tables import ActionColumn


class CollectionsColumn(ActionColumn):
    template_name = "collections/columns/collections.html"
