from .settings import *

# Disable simple history for loaddata from fixtures

SIMPLE_HISTORY_ENABLED = False
