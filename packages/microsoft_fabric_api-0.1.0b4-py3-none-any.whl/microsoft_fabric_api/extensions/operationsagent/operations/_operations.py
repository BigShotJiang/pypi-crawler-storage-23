from ....generated.operationsagent.operations import *
from ....generated.operationsagent import operations as _operations
from ....generated.operationsagent import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Operationsagent."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_operations_agent(self, workspace_id: str, create_operations_agent_request: _models.CreateOperationsAgentRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.OperationsAgent:
        """Creates a OperationsAgent in the specified workspace.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create OperationsAgent with a definition, refer to `OperationsAgent
        </rest/api/fabric/articles/item-management/definitions/operationsagent-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a OperationsAgent the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_operations_agent_request: Create item request payload. Required.
        :type create_operations_agent_request:
         ~microsoft.fabric.api.operationsagent.models.CreateOperationsAgentRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns OperationsAgent
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgent]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_operations_agent(workspace_id=workspace_id, create_operations_agent_request=create_operations_agent_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_operations_agent(self, workspace_id: str, create_operations_agent_request: _models.CreateOperationsAgentRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.OperationsAgent]:
        """Creates a OperationsAgent in the specified workspace.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create OperationsAgent with a definition, refer to `OperationsAgent
        </rest/api/fabric/articles/item-management/definitions/operationsagent-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a OperationsAgent the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_operations_agent_request: Create item request payload. Required.
        :type create_operations_agent_request:
         ~microsoft.fabric.api.operationsagent.models.CreateOperationsAgentRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns OperationsAgent
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgent]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.OperationsAgent]()

        poller = super().begin_create_operations_agent(
            workspace_id=workspace_id,
            create_operations_agent_request=create_operations_agent_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_operations_agent(self, workspace_id: str, create_operations_agent_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.OperationsAgent:
        """Creates a OperationsAgent in the specified workspace.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create OperationsAgent with a definition, refer to `OperationsAgent
        </rest/api/fabric/articles/item-management/definitions/operationsagent-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a OperationsAgent the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_operations_agent_request: Create item request payload. Required.
        :type create_operations_agent_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns OperationsAgent
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgent]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_operations_agent(workspace_id=workspace_id, create_operations_agent_request=create_operations_agent_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_operations_agent(self, workspace_id: str, create_operations_agent_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.OperationsAgent]:
        """Creates a OperationsAgent in the specified workspace.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create OperationsAgent with a definition, refer to `OperationsAgent
        </rest/api/fabric/articles/item-management/definitions/operationsagent-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a OperationsAgent the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_operations_agent_request: Create item request payload. Required.
        :type create_operations_agent_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns OperationsAgent
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgent]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.OperationsAgent]()

        poller = super().begin_create_operations_agent(
            workspace_id=workspace_id,
            create_operations_agent_request=create_operations_agent_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_operations_agent(self, workspace_id: str, create_operations_agent_request: Union[_models.CreateOperationsAgentRequest, IO[bytes]], **kwargs: Any) -> _models.OperationsAgent:
        """Creates a OperationsAgent in the specified workspace.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create OperationsAgent with a definition, refer to `OperationsAgent
        </rest/api/fabric/articles/item-management/definitions/operationsagent-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a OperationsAgent the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_operations_agent_request: Create item request payload. Is either a
         CreateOperationsAgentRequest type or a IO[bytes] type. Required.
        :type create_operations_agent_request:
         ~microsoft.fabric.api.operationsagent.models.CreateOperationsAgentRequest or IO[bytes]
        :return: An instance of LROPoller that returns OperationsAgent
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgent]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_operations_agent(workspace_id=workspace_id, create_operations_agent_request=create_operations_agent_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_operations_agent(self, workspace_id: str, create_operations_agent_request: Union[_models.CreateOperationsAgentRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.OperationsAgent]:
        """Creates a OperationsAgent in the specified workspace.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create OperationsAgent with a definition, refer to `OperationsAgent
        </rest/api/fabric/articles/item-management/definitions/operationsagent-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a OperationsAgent the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_operations_agent_request: Create item request payload. Is either a
         CreateOperationsAgentRequest type or a IO[bytes] type. Required.
        :type create_operations_agent_request:
         ~microsoft.fabric.api.operationsagent.models.CreateOperationsAgentRequest or IO[bytes]
        :return: An instance of LROPoller that returns OperationsAgent
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgent]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.OperationsAgent]()

        poller = super().begin_create_operations_agent(
            workspace_id=workspace_id,
            create_operations_agent_request=create_operations_agent_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, *, format: Optional[Union[str, _models.OperationsAgentDefinitionFormat]] = None, **kwargs: Any) -> _models.OperationsAgentDefinitionResponse:
        """Returns the specified OperationsAgent public definition.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a OperationsAgent's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :keyword format: The format of the OperationsAgent public definition. Additional ``format``
         types may be added over time. "OperationsAgentV1" Default value is None.
        :paramtype format: str or
         ~microsoft.fabric.api.operationsagent.models.OperationsAgentDefinitionFormat
        :return: An instance of LROPoller that returns OperationsAgentDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgentDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_operations_agent_definition(workspace_id=workspace_id, operations_agent_id=operations_agent_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, *, format: Optional[Union[str, _models.OperationsAgentDefinitionFormat]] = None, **kwargs: Any) -> _LROResultExtractor[_models.OperationsAgentDefinitionResponse]:
        """Returns the specified OperationsAgent public definition.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a OperationsAgent's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :keyword format: The format of the OperationsAgent public definition. Additional ``format``
         types may be added over time. "OperationsAgentV1" Default value is None.
        :paramtype format: str or
         ~microsoft.fabric.api.operationsagent.models.OperationsAgentDefinitionFormat
        :return: An instance of LROPoller that returns OperationsAgentDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.operationsagent.models.OperationsAgentDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.OperationsAgentDefinitionResponse]()

        poller = super().begin_get_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, update_operations_agent_definition_request: _models.UpdateOperationsAgentDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified OperationsAgent.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the OperationsAgent's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :param update_operations_agent_definition_request: Update OperationsAgent definition request
         payload. Required.
        :type update_operations_agent_definition_request:
         ~microsoft.fabric.api.operationsagent.models.UpdateOperationsAgentDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            update_operations_agent_definition_request=update_operations_agent_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, update_operations_agent_definition_request: _models.UpdateOperationsAgentDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified OperationsAgent.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the OperationsAgent's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :param update_operations_agent_definition_request: Update OperationsAgent definition request
         payload. Required.
        :type update_operations_agent_definition_request:
         ~microsoft.fabric.api.operationsagent.models.UpdateOperationsAgentDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            update_operations_agent_definition_request=update_operations_agent_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, update_operations_agent_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified OperationsAgent.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the OperationsAgent's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :param update_operations_agent_definition_request: Update OperationsAgent definition request
         payload. Required.
        :type update_operations_agent_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            update_operations_agent_definition_request=update_operations_agent_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, update_operations_agent_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified OperationsAgent.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the OperationsAgent's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :param update_operations_agent_definition_request: Update OperationsAgent definition request
         payload. Required.
        :type update_operations_agent_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            update_operations_agent_definition_request=update_operations_agent_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, update_operations_agent_definition_request: Union[_models.UpdateOperationsAgentDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified OperationsAgent.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the OperationsAgent's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :param update_operations_agent_definition_request: Update OperationsAgent definition request
         payload. Is either a UpdateOperationsAgentDefinitionRequest type or a IO[bytes] type. Required.
        :type update_operations_agent_definition_request:
         ~microsoft.fabric.api.operationsagent.models.UpdateOperationsAgentDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            update_operations_agent_definition_request=update_operations_agent_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_operations_agent_definition(self, workspace_id: str, operations_agent_id: str, update_operations_agent_definition_request: Union[_models.UpdateOperationsAgentDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified OperationsAgent.

        ..

           [!NOTE]
           OperationsAgent item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the OperationsAgent's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the OperationsAgent.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param operations_agent_id: The OperationsAgent ID. Required.
        :type operations_agent_id: str
        :param update_operations_agent_definition_request: Update OperationsAgent definition request
         payload. Is either a UpdateOperationsAgentDefinitionRequest type or a IO[bytes] type. Required.
        :type update_operations_agent_definition_request:
         ~microsoft.fabric.api.operationsagent.models.UpdateOperationsAgentDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_operations_agent_definition(
            workspace_id=workspace_id,
            operations_agent_id=operations_agent_id,
            update_operations_agent_definition_request=update_operations_agent_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
