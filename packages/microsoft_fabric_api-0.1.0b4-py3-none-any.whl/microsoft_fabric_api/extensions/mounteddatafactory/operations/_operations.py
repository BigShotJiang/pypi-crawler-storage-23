from ....generated.mounteddatafactory.operations import *
from ....generated.mounteddatafactory import operations as _operations
from ....generated.mounteddatafactory import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Mounteddatafactory."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_mounted_data_factory(self, workspace_id: str, create_mounted_data_factory_request: _models.CreateMountedDataFactoryRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.MountedDataFactory:
        """Creates a mounted data factory in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create MountedDataFactory with a public definition, refer to `MountedDataFactory
        </rest/api/fabric/articles/item-management/definitions/mounted-data-factory-definition>`_
        article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a MountedDataFactory the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_mounted_data_factory_request: Create item request payload. Required.
        :type create_mounted_data_factory_request:
         ~microsoft.fabric.api.mounteddatafactory.models.CreateMountedDataFactoryRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns MountedDataFactory
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactory]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_mounted_data_factory(workspace_id=workspace_id, create_mounted_data_factory_request=create_mounted_data_factory_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_mounted_data_factory(self, workspace_id: str, create_mounted_data_factory_request: _models.CreateMountedDataFactoryRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.MountedDataFactory]:
        """Creates a mounted data factory in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create MountedDataFactory with a public definition, refer to `MountedDataFactory
        </rest/api/fabric/articles/item-management/definitions/mounted-data-factory-definition>`_
        article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a MountedDataFactory the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_mounted_data_factory_request: Create item request payload. Required.
        :type create_mounted_data_factory_request:
         ~microsoft.fabric.api.mounteddatafactory.models.CreateMountedDataFactoryRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns MountedDataFactory
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactory]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.MountedDataFactory]()

        poller = super().begin_create_mounted_data_factory(
            workspace_id=workspace_id,
            create_mounted_data_factory_request=create_mounted_data_factory_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_mounted_data_factory(self, workspace_id: str, create_mounted_data_factory_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.MountedDataFactory:
        """Creates a mounted data factory in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create MountedDataFactory with a public definition, refer to `MountedDataFactory
        </rest/api/fabric/articles/item-management/definitions/mounted-data-factory-definition>`_
        article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a MountedDataFactory the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_mounted_data_factory_request: Create item request payload. Required.
        :type create_mounted_data_factory_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns MountedDataFactory
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactory]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_mounted_data_factory(workspace_id=workspace_id, create_mounted_data_factory_request=create_mounted_data_factory_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_mounted_data_factory(self, workspace_id: str, create_mounted_data_factory_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.MountedDataFactory]:
        """Creates a mounted data factory in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create MountedDataFactory with a public definition, refer to `MountedDataFactory
        </rest/api/fabric/articles/item-management/definitions/mounted-data-factory-definition>`_
        article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a MountedDataFactory the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_mounted_data_factory_request: Create item request payload. Required.
        :type create_mounted_data_factory_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns MountedDataFactory
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactory]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.MountedDataFactory]()

        poller = super().begin_create_mounted_data_factory(
            workspace_id=workspace_id,
            create_mounted_data_factory_request=create_mounted_data_factory_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_mounted_data_factory(self, workspace_id: str, create_mounted_data_factory_request: Union[_models.CreateMountedDataFactoryRequest, IO[bytes]], **kwargs: Any) -> _models.MountedDataFactory:
        """Creates a mounted data factory in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create MountedDataFactory with a public definition, refer to `MountedDataFactory
        </rest/api/fabric/articles/item-management/definitions/mounted-data-factory-definition>`_
        article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a MountedDataFactory the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_mounted_data_factory_request: Create item request payload. Is either a
         CreateMountedDataFactoryRequest type or a IO[bytes] type. Required.
        :type create_mounted_data_factory_request:
         ~microsoft.fabric.api.mounteddatafactory.models.CreateMountedDataFactoryRequest or IO[bytes]
        :return: An instance of LROPoller that returns MountedDataFactory
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactory]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_mounted_data_factory(workspace_id=workspace_id, create_mounted_data_factory_request=create_mounted_data_factory_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_mounted_data_factory(self, workspace_id: str, create_mounted_data_factory_request: Union[_models.CreateMountedDataFactoryRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.MountedDataFactory]:
        """Creates a mounted data factory in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create MountedDataFactory with a public definition, refer to `MountedDataFactory
        </rest/api/fabric/articles/item-management/definitions/mounted-data-factory-definition>`_
        article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a MountedDataFactory the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_mounted_data_factory_request: Create item request payload. Is either a
         CreateMountedDataFactoryRequest type or a IO[bytes] type. Required.
        :type create_mounted_data_factory_request:
         ~microsoft.fabric.api.mounteddatafactory.models.CreateMountedDataFactoryRequest or IO[bytes]
        :return: An instance of LROPoller that returns MountedDataFactory
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactory]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.MountedDataFactory]()

        poller = super().begin_create_mounted_data_factory(
            workspace_id=workspace_id,
            create_mounted_data_factory_request=create_mounted_data_factory_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _models.MountedDataFactoryDefinitionResponse:
        """Returns the specified mounted data factory public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a MountedDataFactory's public definition, the sensitivity label is not a part of
        the definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :keyword format: The format of the MountedDataFactory public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns MountedDataFactoryDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactoryDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_mounted_data_factory_definition(workspace_id=workspace_id, mounted_data_factory_id=mounted_data_factory_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _LROResultExtractor[_models.MountedDataFactoryDefinitionResponse]:
        """Returns the specified mounted data factory public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a MountedDataFactory's public definition, the sensitivity label is not a part of
        the definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :keyword format: The format of the MountedDataFactory public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns MountedDataFactoryDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.mounteddatafactory.models.MountedDataFactoryDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.MountedDataFactoryDefinitionResponse]()

        poller = super().begin_get_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, update_mounted_data_factory_definition_request: _models.UpdateMountedDataFactoryDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified mounted data factory.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the MountedDataFactory's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :param update_mounted_data_factory_definition_request: Update MountedDataFactory definition
         request payload. Required.
        :type update_mounted_data_factory_definition_request:
         ~microsoft.fabric.api.mounteddatafactory.models.UpdateMountedDataFactoryDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            update_mounted_data_factory_definition_request=update_mounted_data_factory_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, update_mounted_data_factory_definition_request: _models.UpdateMountedDataFactoryDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified mounted data factory.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the MountedDataFactory's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :param update_mounted_data_factory_definition_request: Update MountedDataFactory definition
         request payload. Required.
        :type update_mounted_data_factory_definition_request:
         ~microsoft.fabric.api.mounteddatafactory.models.UpdateMountedDataFactoryDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            update_mounted_data_factory_definition_request=update_mounted_data_factory_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, update_mounted_data_factory_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified mounted data factory.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the MountedDataFactory's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :param update_mounted_data_factory_definition_request: Update MountedDataFactory definition
         request payload. Required.
        :type update_mounted_data_factory_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            update_mounted_data_factory_definition_request=update_mounted_data_factory_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, update_mounted_data_factory_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified mounted data factory.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the MountedDataFactory's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :param update_mounted_data_factory_definition_request: Update MountedDataFactory definition
         request payload. Required.
        :type update_mounted_data_factory_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            update_mounted_data_factory_definition_request=update_mounted_data_factory_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, update_mounted_data_factory_definition_request: Union[_models.UpdateMountedDataFactoryDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified mounted data factory.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the MountedDataFactory's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :param update_mounted_data_factory_definition_request: Update MountedDataFactory definition
         request payload. Is either a UpdateMountedDataFactoryDefinitionRequest type or a IO[bytes]
         type. Required.
        :type update_mounted_data_factory_definition_request:
         ~microsoft.fabric.api.mounteddatafactory.models.UpdateMountedDataFactoryDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            update_mounted_data_factory_definition_request=update_mounted_data_factory_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_mounted_data_factory_definition(self, workspace_id: str, mounted_data_factory_id: str, update_mounted_data_factory_definition_request: Union[_models.UpdateMountedDataFactoryDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified mounted data factory.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the MountedDataFactory's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the mounted data factory.

        Required Delegated Scopes
        -------------------------

         MountedDataFactory.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param mounted_data_factory_id: The MountedDataFactory ID. Required.
        :type mounted_data_factory_id: str
        :param update_mounted_data_factory_definition_request: Update MountedDataFactory definition
         request payload. Is either a UpdateMountedDataFactoryDefinitionRequest type or a IO[bytes]
         type. Required.
        :type update_mounted_data_factory_definition_request:
         ~microsoft.fabric.api.mounteddatafactory.models.UpdateMountedDataFactoryDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_mounted_data_factory_definition(
            workspace_id=workspace_id,
            mounted_data_factory_id=mounted_data_factory_id,
            update_mounted_data_factory_definition_request=update_mounted_data_factory_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
