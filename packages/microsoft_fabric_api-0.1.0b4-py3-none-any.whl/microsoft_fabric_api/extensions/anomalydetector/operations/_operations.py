from ....generated.anomalydetector.operations import *
from ....generated.anomalydetector import operations as _operations
from ....generated.anomalydetector import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Anomalydetector."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_anomaly_detector(self, workspace_id: str, create_anomaly_detector_request: _models.CreateAnomalyDetectorRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.AnomalyDetector:
        """Creates a AnomalyDetector in the specified workspace.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create AnomalyDetector with a definition, refer to `AnomalyDetector
        </rest/api/fabric/articles/item-management/definitions/anomalydetector-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a AnomalyDetector the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_anomaly_detector_request: Create item request payload. Required.
        :type create_anomaly_detector_request:
         ~microsoft.fabric.api.anomalydetector.models.CreateAnomalyDetectorRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns AnomalyDetector
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetector]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_anomaly_detector(workspace_id=workspace_id, create_anomaly_detector_request=create_anomaly_detector_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_anomaly_detector(self, workspace_id: str, create_anomaly_detector_request: _models.CreateAnomalyDetectorRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.AnomalyDetector]:
        """Creates a AnomalyDetector in the specified workspace.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create AnomalyDetector with a definition, refer to `AnomalyDetector
        </rest/api/fabric/articles/item-management/definitions/anomalydetector-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a AnomalyDetector the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_anomaly_detector_request: Create item request payload. Required.
        :type create_anomaly_detector_request:
         ~microsoft.fabric.api.anomalydetector.models.CreateAnomalyDetectorRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns AnomalyDetector
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetector]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.AnomalyDetector]()

        poller = super().begin_create_anomaly_detector(
            workspace_id=workspace_id,
            create_anomaly_detector_request=create_anomaly_detector_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_anomaly_detector(self, workspace_id: str, create_anomaly_detector_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.AnomalyDetector:
        """Creates a AnomalyDetector in the specified workspace.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create AnomalyDetector with a definition, refer to `AnomalyDetector
        </rest/api/fabric/articles/item-management/definitions/anomalydetector-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a AnomalyDetector the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_anomaly_detector_request: Create item request payload. Required.
        :type create_anomaly_detector_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns AnomalyDetector
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetector]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_anomaly_detector(workspace_id=workspace_id, create_anomaly_detector_request=create_anomaly_detector_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_anomaly_detector(self, workspace_id: str, create_anomaly_detector_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.AnomalyDetector]:
        """Creates a AnomalyDetector in the specified workspace.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create AnomalyDetector with a definition, refer to `AnomalyDetector
        </rest/api/fabric/articles/item-management/definitions/anomalydetector-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a AnomalyDetector the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_anomaly_detector_request: Create item request payload. Required.
        :type create_anomaly_detector_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns AnomalyDetector
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetector]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.AnomalyDetector]()

        poller = super().begin_create_anomaly_detector(
            workspace_id=workspace_id,
            create_anomaly_detector_request=create_anomaly_detector_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_anomaly_detector(self, workspace_id: str, create_anomaly_detector_request: Union[_models.CreateAnomalyDetectorRequest, IO[bytes]], **kwargs: Any) -> _models.AnomalyDetector:
        """Creates a AnomalyDetector in the specified workspace.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create AnomalyDetector with a definition, refer to `AnomalyDetector
        </rest/api/fabric/articles/item-management/definitions/anomalydetector-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a AnomalyDetector the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_anomaly_detector_request: Create item request payload. Is either a
         CreateAnomalyDetectorRequest type or a IO[bytes] type. Required.
        :type create_anomaly_detector_request:
         ~microsoft.fabric.api.anomalydetector.models.CreateAnomalyDetectorRequest or IO[bytes]
        :return: An instance of LROPoller that returns AnomalyDetector
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetector]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_anomaly_detector(workspace_id=workspace_id, create_anomaly_detector_request=create_anomaly_detector_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_anomaly_detector(self, workspace_id: str, create_anomaly_detector_request: Union[_models.CreateAnomalyDetectorRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.AnomalyDetector]:
        """Creates a AnomalyDetector in the specified workspace.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create AnomalyDetector with a definition, refer to `AnomalyDetector
        </rest/api/fabric/articles/item-management/definitions/anomalydetector-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a AnomalyDetector the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_anomaly_detector_request: Create item request payload. Is either a
         CreateAnomalyDetectorRequest type or a IO[bytes] type. Required.
        :type create_anomaly_detector_request:
         ~microsoft.fabric.api.anomalydetector.models.CreateAnomalyDetectorRequest or IO[bytes]
        :return: An instance of LROPoller that returns AnomalyDetector
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetector]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.AnomalyDetector]()

        poller = super().begin_create_anomaly_detector(
            workspace_id=workspace_id,
            create_anomaly_detector_request=create_anomaly_detector_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, *, format: Optional[Union[str, _models.AnomalyDetectorDefinitionFormat]] = None, **kwargs: Any) -> _models.AnomalyDetectorDefinitionResponse:
        """Returns the specified AnomalyDetector definition.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a AnomalyDetector's definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :keyword format: The format of the AnomalyDetector definition. Additional ``format`` types may
         be added over time. "AnomalyDetectorV1" Default value is None.
        :paramtype format: str or
         ~microsoft.fabric.api.anomalydetector.models.AnomalyDetectorDefinitionFormat
        :return: An instance of LROPoller that returns AnomalyDetectorDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetectorDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_anomaly_detector_definition(workspace_id=workspace_id, anomaly_detector_id=anomaly_detector_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, *, format: Optional[Union[str, _models.AnomalyDetectorDefinitionFormat]] = None, **kwargs: Any) -> _LROResultExtractor[_models.AnomalyDetectorDefinitionResponse]:
        """Returns the specified AnomalyDetector definition.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a AnomalyDetector's definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :keyword format: The format of the AnomalyDetector definition. Additional ``format`` types may
         be added over time. "AnomalyDetectorV1" Default value is None.
        :paramtype format: str or
         ~microsoft.fabric.api.anomalydetector.models.AnomalyDetectorDefinitionFormat
        :return: An instance of LROPoller that returns AnomalyDetectorDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.anomalydetector.models.AnomalyDetectorDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.AnomalyDetectorDefinitionResponse]()

        poller = super().begin_get_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, update_anomaly_detector_definition_request: _models.UpdateAnomalyDetectorDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified AnomalyDetector.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the AnomalyDetector's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :param update_anomaly_detector_definition_request: Update AnomalyDetector definition request
         payload. Required.
        :type update_anomaly_detector_definition_request:
         ~microsoft.fabric.api.anomalydetector.models.UpdateAnomalyDetectorDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            update_anomaly_detector_definition_request=update_anomaly_detector_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, update_anomaly_detector_definition_request: _models.UpdateAnomalyDetectorDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified AnomalyDetector.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the AnomalyDetector's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :param update_anomaly_detector_definition_request: Update AnomalyDetector definition request
         payload. Required.
        :type update_anomaly_detector_definition_request:
         ~microsoft.fabric.api.anomalydetector.models.UpdateAnomalyDetectorDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            update_anomaly_detector_definition_request=update_anomaly_detector_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, update_anomaly_detector_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified AnomalyDetector.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the AnomalyDetector's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :param update_anomaly_detector_definition_request: Update AnomalyDetector definition request
         payload. Required.
        :type update_anomaly_detector_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            update_anomaly_detector_definition_request=update_anomaly_detector_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, update_anomaly_detector_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified AnomalyDetector.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the AnomalyDetector's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :param update_anomaly_detector_definition_request: Update AnomalyDetector definition request
         payload. Required.
        :type update_anomaly_detector_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            update_anomaly_detector_definition_request=update_anomaly_detector_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, update_anomaly_detector_definition_request: Union[_models.UpdateAnomalyDetectorDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified AnomalyDetector.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the AnomalyDetector's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :param update_anomaly_detector_definition_request: Update AnomalyDetector definition request
         payload. Is either a UpdateAnomalyDetectorDefinitionRequest type or a IO[bytes] type. Required.
        :type update_anomaly_detector_definition_request:
         ~microsoft.fabric.api.anomalydetector.models.UpdateAnomalyDetectorDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            update_anomaly_detector_definition_request=update_anomaly_detector_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_anomaly_detector_definition(self, workspace_id: str, anomaly_detector_id: str, update_anomaly_detector_definition_request: Union[_models.UpdateAnomalyDetectorDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified AnomalyDetector.

        ..

           [!NOTE]
           AnomalyDetector item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the AnomalyDetector's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the AnomalyDetector.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param anomaly_detector_id: The AnomalyDetector ID. Required.
        :type anomaly_detector_id: str
        :param update_anomaly_detector_definition_request: Update AnomalyDetector definition request
         payload. Is either a UpdateAnomalyDetectorDefinitionRequest type or a IO[bytes] type. Required.
        :type update_anomaly_detector_definition_request:
         ~microsoft.fabric.api.anomalydetector.models.UpdateAnomalyDetectorDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_anomaly_detector_definition(
            workspace_id=workspace_id,
            anomaly_detector_id=anomaly_detector_id,
            update_anomaly_detector_definition_request=update_anomaly_detector_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
