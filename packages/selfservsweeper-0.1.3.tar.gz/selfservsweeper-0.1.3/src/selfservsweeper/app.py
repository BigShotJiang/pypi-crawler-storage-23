from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import json
import os
import queue
import random
import sys
import threading
import time
import tkinter as tk
from collections import deque
from pathlib import Path
from tkinter import messagebox
from typing import Optional

from . import __version__
from .config import (
    SAVE_VERSION,
    SECRET_GESTURE,
    STEP_MAX_GAP_S,
    TOTAL_MAX_S,
    MIN_STROKE_FRAC,
    MIN_STROKE_PX_FLOOR,
    IDLE_PROMPT_AT,
    IDLE_STEALTH_AT,
    CELL_MIN, CELL_MAX, CELL_STEP,
    PAN_MOVE_PX,
    PAN_CELL_THRESHOLD,
    LONGPRESS_FLAG_MS,
    app_dir,
    save_path,
    save_bak_path,
    supervisor_script_path,
)
from .logging_setup import setup_logging
from . import startup as startup_mod
from .supervisor_client import is_supervised as _is_supervised, read_bootstrap_config, request_action
from .update import pip_latest_version
from . import win_api as w
from .win_hook import GlobalMouseHook
from .win_dpi import enable_dpi_awareness

LOG = setup_logging("selfservsweeper.app", filename="app.log")


def _bools_to_bits(bs) -> str:
    return "".join("1" if b else "0" for b in bs)


def _bits_to_bools(s: str, n: int):
    s = (s or "")
    if len(s) < n:
        s += "0" * (n - len(s))
    s = s[:n]
    return [ch == "1" for ch in s]


class MinesweeperApp(tk.Tk):
    DIFFICULTIES = {"Easy": (9, 9, 10), "Medium": (16, 16, 40), "Hard": (16, 30, 99)}
    NUM_COLORS = {
        1: "#1976D2", 2: "#2E7D32", 3: "#D32F2F", 4: "#512DA8",
        5: "#6D4C41", 6: "#00796B", 7: "#424242", 8: "#263238",
    }

    def __init__(
        self,
        *,
        health_file: Optional[Path] = None,
        start_stealth: bool = True,
        enable_hook: bool = True,
    ):
        super().__init__()

        if sys.platform != "win32" or self.tk.call("tk", "windowingsystem") != "win32":
            raise RuntimeError("Windows only (win32).")

        self._health_file = health_file
        self._start_stealth = bool(start_stealth)
        self._enable_hook = bool(enable_hook)
        self._supervised = _is_supervised()
        self._bootstrap = read_bootstrap_config() or {}

        self.resizable(False, False)
        self.configure(bg="#2b2b2b")
        self.withdraw()

        self._hwnd: Optional[wintypes.HWND] = None

        self._hook_q: "queue.SimpleQueue[tuple[int, int, int, float]]" = queue.SimpleQueue()
        self._hook: Optional[GlobalMouseHook] = None
        self._hook_pump_job = None

        self._bg_q: "queue.SimpleQueue[tuple[str, object]]" = queue.SimpleQueue()
        self._bg_pump_job = None
        self._update_check_inflight = False

        self._top_job = None
        self._idle_job = None
        self._save_job = None
        self._timer_job = None

        self._stealth = False
        self.opacity = tk.DoubleVar(value=0.92)
        self.cell_px = 28

        self._drag_off_x = 0
        self._drag_off_y = 0

        self._primary_rc, self._primary_work = self._get_primary_monitor_rects()
        self._min_stroke_px = max(
            MIN_STROKE_PX_FLOOR,
            int(min(self._primary_w(), self._primary_h()) * MIN_STROKE_FRAC),
        )

        self._g_idx = 0
        self._g_t0 = 0.0
        self._g_last = 0.0
        self._stroke_start = None

        self._press_xy = None
        self._press_cell = None
        self._pan_active = False
        self._longpress_token = 0
        self._pan_enabled = False

        self._last_activity = time.monotonic()
        self._prompt_showing = False

        self.games = {}
        self.current_mode = "Easy"
        self.game = None
        self.neighbors = None

        self.startup_var = tk.StringVar(value="Startup: ?")
        self.version_var = tk.StringVar(value=f"Version: {__version__}")
        self.update_var = tk.StringVar(value="Update: (not checked)")
        self.supervised_var = tk.StringVar(value=f"Supervisor: {'ON' if self._supervised else 'OFF'}")

        self.time_var = tk.StringVar(value="Time: 0")
        self.mines_var = tk.StringVar(value="Mines: 0")

        self._view = "game"  # "game" or "options"
        self._stats_var = tk.StringVar(value="Time: 0   Mines: 0")
        self._view_btn = None  # created in title bar

        self._load_all()

        self._build_title_bar()
        self._build_board()
        self._build_options_panel()
        self._build_idle_prompt()

        self._show_game_view(resize=False)

        self.update_idletasks()
        self.overrideredirect(True)
        self.deiconify()
        self.update_idletasks()
        self._resize_to_fit()

        self._hwnd = wintypes.HWND(self.winfo_id())

        self.attributes("-topmost", True)
        self.attributes("-alpha", float(self.opacity.get()))

        if self._enable_hook:
            try:
                self._hook = GlobalMouseHook(self._hook_q)
                ok = self._hook.start_and_wait(timeout=2.0)
                if not ok:
                    LOG.warning("Global mouse hook could not be installed (gesture restore may not work).")
            except Exception:
                LOG.exception("Failed to start global mouse hook.")
                self._hook = None

        self._hook_pump()
        self._bg_pump()

        self.select_mode(self.current_mode, reset_if_same=False)
        self._update_startup_status()

        self.after(0, self._signal_healthy)

        if self._start_stealth:
            self.after(10, self.enter_stealth)

        self._top_loop()
        self._idle_loop()
        self.protocol("WM_DELETE_WINDOW", self.destroy)

    # ---------------- supervisor/updates ----------------
    def check_updates(self):
        if self._update_check_inflight:
            return
        self._update_check_inflight = True
        self.update_var.set("Update: checking…")

        def worker():
            installed, latest, err = pip_latest_version()
            self._bg_q.put(("update_check", (installed, latest, err)))

        threading.Thread(target=worker, daemon=True, name="UpdateCheck").start()

    def _request_supervisor_action(self, action: str):
        if not self._supervised:
            messagebox.showinfo(
                "Supervisor not running",
                "Update/rollback requires supervisor mode.\n\n"
                "Run on the kiosk (one-time):\n"
                "  python -m selfservsweeper install --enable-startup",
                parent=self,
            )
            return

        try:
            request_action(action, extra={"from_version": __version__})
        except Exception as e:
            LOG.exception("Failed to write supervisor command.")
            messagebox.showerror("Failed", f"Could not request '{action}': {e}", parent=self)
            return

        self.destroy()

    def request_update(self):
        if messagebox.askyesno(
            "Update",
            "Update to the latest available version?\n\nThe app will close and restart automatically.",
            parent=self,
        ):
            self._request_supervisor_action("update")

    def request_rollback(self):
        if messagebox.askyesno(
            "Rollback",
            "Rollback to the previous known-good version?\n\nThe app will close and restart automatically.",
            parent=self,
        ):
            self._request_supervisor_action("rollback")

    def _signal_healthy(self):
        if not self._health_file:
            return
        try:
            self._health_file.parent.mkdir(parents=True, exist_ok=True)
            self._health_file.write_text("ok", encoding="utf-8")
        except Exception:
            LOG.exception("Failed to write health file: %s", self._health_file)

    # ---------------- startup controls ----------------
    def _startup_is_enabled(self) -> bool:
        return startup_mod.is_enabled()

    def _base_pythonw(self) -> Optional[str]:
        p = str(self._bootstrap.get("base_pythonw") or "")
        if p and os.path.exists(p):
            return p
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            pyw = exe[:-10] + "pythonw.exe"
            if os.path.exists(pyw):
                return pyw
        if exe.lower().endswith("pythonw.exe"):
            return exe
        return None

    def _update_startup_status(self):
        if not supervisor_script_path().exists():
            self.startup_var.set("Startup: (install first)")
            return
        self.startup_var.set(f"Startup: {'ON' if self._startup_is_enabled() else 'OFF'}")

    def enable_startup(self):
        pyw = self._base_pythonw()
        if not pyw:
            messagebox.showerror("Enable Startup", "Could not locate pythonw.exe.", parent=self)
            self._update_startup_status()
            return
        if not supervisor_script_path().exists():
            messagebox.showerror("Enable Startup", "Missing supervisor script. Run install first.", parent=self)
            self._update_startup_status()
            return
        try:
            startup_mod.enable(pyw, supervisor_script_path())
        except Exception as e:
            LOG.exception("Enable startup failed.")
            messagebox.showerror("Enable Startup", f"Failed: {e}", parent=self)
        self._update_startup_status()

    def disable_startup(self):
        try:
            startup_mod.disable()
        except Exception:
            pass
        self._update_startup_status()

    # ---------------- primary monitor ----------------
    def _get_primary_monitor_rects(self):
        hmon = w.user32.MonitorFromPoint(w.POINT(0, 0), w.MONITOR_DEFAULTTOPRIMARY)
        mi = w.MONITORINFO()
        mi.cbSize = ctypes.sizeof(mi)
        if not w.user32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            rc = w.RECT(0, 0, 1920, 1080)
            return rc, rc
        return mi.rcMonitor, mi.rcWork

    def _primary_w(self): return int(self._primary_rc.right - self._primary_rc.left)
    def _primary_h(self): return int(self._primary_rc.bottom - self._primary_rc.top)

    def _in_primary(self, x, y):
        rc = self._primary_rc
        return rc.left <= x < rc.right and rc.top <= y < rc.bottom

    # ---------------- save/load ----------------
    def _load_all(self):
        candidates = [save_path(), save_bak_path()]
        data = None
        for p in candidates:
            if not p.exists():
                continue
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                if data.get("version") == SAVE_VERSION:
                    break
            except Exception:
                data = None
        if not isinstance(data, dict):
            return

        try:
            self.opacity.set(float(data.get("opacity", 0.92)))
            self.cell_px = max(CELL_MIN, min(CELL_MAX, int(data.get("cell_px", self.cell_px))))
            self.current_mode = data.get("current_mode", self.current_mode)
            x, y = data.get("pos", [None, None])
            if isinstance(x, int) and isinstance(y, int):
                self.geometry(f"+{x}+{y}")
        except Exception:
            pass

        games = data.get("games", {})
        if not isinstance(games, dict):
            return
        for mode, g in games.items():
            if mode not in self.DIFFICULTIES or not isinstance(g, dict):
                continue
            rows, cols, mine_count = self.DIFFICULTIES[mode]
            n = rows * cols
            try:
                numbers = g.get("numbers", [0] * n)
                if not (isinstance(numbers, list) and len(numbers) == n and all(isinstance(x, int) for x in numbers)):
                    numbers = [0] * n
                self.games[mode] = {
                    "rows": rows, "cols": cols, "mine_count": mine_count,
                    "mines": _bits_to_bools(g.get("mines", ""), n),
                    "numbers": numbers,
                    "revealed": _bits_to_bools(g.get("revealed", ""), n),
                    "flagged": _bits_to_bools(g.get("flagged", ""), n),
                    "state": g.get("state", "ready"),
                    "first_click": bool(g.get("first_click", True)),
                    "elapsed": float(g.get("elapsed", 0.0)),
                    "timer_running": bool(g.get("timer_running", False)),
                    "view_x": float(g.get("view_x", 0.0)),
                    "view_y": float(g.get("view_y", 0.0)),
                }
            except Exception:
                pass

    def _schedule_save(self):
        if not self._save_job:
            self._save_job = self.after(600, self._save_all)

    def _save_all(self):
        self._save_job = None
        try:
            app_dir().mkdir(parents=True, exist_ok=True)
        except Exception:
            return

        x, y = self.winfo_x(), self.winfo_y()

        games_out = {}
        for mode, g in self.games.items():
            rows, cols, _ = self.DIFFICULTIES.get(mode, (None, None, None))
            if rows is None:
                continue
            n = rows * cols
            elapsed = self._elapsed(g) if g.get("_mono") is not None else float(g.get("elapsed", 0.0))
            games_out[mode] = {
                "mines": _bools_to_bits(g["mines"][:n]),
                "numbers": g["numbers"][:n],
                "revealed": _bools_to_bits(g["revealed"][:n]),
                "flagged": _bools_to_bits(g["flagged"][:n]),
                "state": g.get("state", "ready"),
                "first_click": bool(g.get("first_click", True)),
                "elapsed": float(elapsed),
                "timer_running": bool(g.get("timer_running", False)),
                "view_x": float(g.get("view_x", 0.0)),
                "view_y": float(g.get("view_y", 0.0)),
            }

        data = {
            "version": SAVE_VERSION,
            "opacity": float(self.opacity.get()),
            "cell_px": int(self.cell_px),
            "current_mode": self.current_mode,
            "pos": [int(x), int(y)],
            "games": games_out,
        }

        sp = save_path()
        tmp = sp.with_suffix(".tmp")
        bak = save_bak_path()

        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            if sp.exists():
                try:
                    sp.replace(bak)
                except Exception:
                    pass
            tmp.replace(sp)
        except Exception:
            LOG.exception("Failed to save state.")
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass

    # ---------------- UI ----------------
    def _build_title_bar(self):
        bar = tk.Frame(self, bg="#202020", padx=6, pady=4)
        bar.pack(fill="x")

        title = tk.Label(bar, text="Minesweeper", bg="#202020", fg="white")
        title.pack(side="left")

        # Right side controls (pack rightmost first)
        tk.Button(
            bar, text="✕", command=self.destroy,
            bg="#202020", fg="white", activebackground="#D32F2F",
            activeforeground="white", relief="flat", padx=10, pady=2
        ).pack(side="right")

        self._view_btn = tk.Button(
            bar, text="Options", command=self._toggle_view,
            bg="#202020", fg="white",
            activebackground="#303030", activeforeground="white",
            relief="flat", padx=10, pady=2
        )
        self._view_btn.pack(side="right", padx=(6, 0))

        stats = tk.Label(bar, textvariable=self._stats_var, bg="#202020", fg="#cfcfcf")
        stats.pack(side="right", padx=(10, 0))

        # Drag-move bindings (don’t bind buttons)
        for wdg in (bar, title, stats):
            wdg.bind("<ButtonPress-1>", self._start_move)
            wdg.bind("<B1-Motion>", self._do_move)

    def _build_options_panel(self):
        self.options_frame = tk.Frame(self, bg="#2b2b2b", padx=10, pady=10)

        # --- Game options ---
        game = tk.Frame(self.options_frame, bg="#2b2b2b")
        game.pack(fill="x", pady=(0, 10))

        tk.Label(game, text="Difficulty", bg="#2b2b2b", fg="white").grid(row=0, column=0, sticky="w", padx=(0, 10))
        modes = tk.Frame(game, bg="#2b2b2b")
        modes.grid(row=0, column=1, sticky="w")
        for name in ("Easy", "Medium", "Hard"):
            tk.Button(
                modes, text=name, padx=12, pady=2,
                command=lambda n=name: self.select_mode(n, reset_if_same=True)
            ).pack(side="left", padx=(0, 6))

        tk.Label(game, text="Tile", bg="#2b2b2b", fg="white").grid(row=1, column=0, sticky="w", pady=(8, 0))
        sz = tk.Frame(game, bg="#2b2b2b")
        sz.grid(row=1, column=1, sticky="w", pady=(8, 0))
        tk.Button(sz, text="−", width=3, command=self.tile_minus).pack(side="left", padx=(0, 6))
        tk.Button(sz, text="+", width=3, command=self.tile_plus).pack(side="left")

        # --- Appearance ---
        app = tk.Frame(self.options_frame, bg="#2b2b2b")
        app.pack(fill="x", pady=(0, 10))

        tk.Label(app, text="Opacity", bg="#2b2b2b", fg="white").pack(side="left", padx=(0, 10))
        tk.Scale(
            app, from_=0.20, to=1.00, resolution=0.01, orient="horizontal",
            length=220, showvalue=False, variable=self.opacity, command=self._on_opacity
        ).pack(side="left")

        # --- Startup ---
        st = tk.Frame(self.options_frame, bg="#2b2b2b")
        st.pack(fill="x", pady=(0, 10))

        tk.Label(st, textvariable=self.startup_var, bg="#2b2b2b", fg="white").pack(side="left")
        tk.Button(st, text="Enable", command=self.enable_startup, padx=12, pady=2).pack(side="right", padx=(6, 0))
        tk.Button(st, text="Disable", command=self.disable_startup, padx=12, pady=2).pack(side="right")

        # --- Updates / version ---
        up = tk.Frame(self.options_frame, bg="#2b2b2b")
        up.pack(fill="x", pady=(0, 10))

        meta = tk.Frame(up, bg="#2b2b2b")
        meta.pack(fill="x")
        tk.Label(meta, textvariable=self.version_var, bg="#2b2b2b", fg="#cfcfcf").pack(side="left")
        tk.Label(meta, textvariable=self.supervised_var, bg="#2b2b2b", fg="#cfcfcf").pack(side="left", padx=(12, 0))

        tk.Label(up, textvariable=self.update_var, bg="#2b2b2b", fg="white").pack(fill="x", pady=(6, 0))

        btns = tk.Frame(up, bg="#2b2b2b")
        btns.pack(fill="x", pady=(6, 0))
        tk.Button(btns, text="Check", command=self.check_updates, padx=12, pady=2).pack(side="right", padx=(6, 0))
        tk.Button(btns, text="Update", command=self.request_update, padx=12, pady=2).pack(side="right", padx=(6, 0))
        tk.Button(btns, text="Rollback", command=self.request_rollback, padx=12, pady=2).pack(side="right")

        # --- Close ---
        tk.Button(
            self.options_frame, text="Back to Game", command=self._show_game_view,
            padx=18, pady=6
        ).pack(pady=(6, 0))

    def _resize_to_fit(self):
        # Keep top-left corner stable while resizing
        self.update_idletasks()
        x, y = self.winfo_x(), self.winfo_y()
        w_req, h_req = self.winfo_reqwidth(), self.winfo_reqheight()
        self.geometry(f"{w_req}x{h_req}+{x}+{y}")

    def _show_game_view(self, *, resize: bool = True):
        self._view = "game"
        try:
            self.options_frame.pack_forget()
        except Exception:
            pass
        self.board_frame.pack()
        if self._view_btn:
            self._view_btn.config(text="Options")
        if resize:
            self._resize_to_fit()

    def _show_options_view(self, *, resize: bool = True):
        self._view = "options"
        try:
            self.board_frame.pack_forget()
        except Exception:
            pass
        self.options_frame.pack(fill="both", expand=True)
        if self._view_btn:
            self._view_btn.config(text="Game")
        self._update_startup_status()
        if resize:
            self._resize_to_fit()

    def _toggle_view(self):
        self._activity()
        if self._view == "game":
            self._show_options_view()
        else:
            self._show_game_view()

    def _build_board(self):
        self.board_frame = tk.Frame(self, bg="#2b2b2b", padx=8, pady=8)
        self.canvas = tk.Canvas(self.board_frame, bg="#2b2b2b", highlightthickness=0)
        self.canvas.pack()

        self.canvas.bind("<ButtonPress-1>", self._board_press)
        self.canvas.bind("<B1-Motion>", self._board_motion)
        self.canvas.bind("<ButtonRelease-1>", self._board_release)
        self.canvas.bind("<Button-3>", self._board_right)
        self.canvas.bind("<Control-Button-1>", self._board_right)

        self._cell_rect, self._cell_text = [], []

    def _build_idle_prompt(self):
        self.idle_prompt = tk.Frame(self, bg="#111111", bd=1, relief="solid")
        self.idle_label = tk.Label(self.idle_prompt, text="", bg="#111111", fg="white", padx=14, pady=10)
        self.idle_label.pack()
        tk.Button(self.idle_prompt, text="I'm here", command=self._activity, padx=24, pady=6).pack(pady=(0, 10))

    # ---------------- minesweeper state ----------------
    def _new_game_state(self, mode):
        rows, cols, mine_count = self.DIFFICULTIES[mode]
        n = rows * cols
        return {
            "rows": rows, "cols": cols, "mine_count": mine_count,
            "mines": [False] * n, "numbers": [0] * n,
            "revealed": [False] * n, "flagged": [False] * n,
            "state": "ready", "first_click": True,
            "elapsed": 0.0, "timer_running": False,
            "view_x": 0.0, "view_y": 0.0,
        }

    def select_mode(self, mode, reset_if_same: bool):
        if mode not in self.DIFFICULTIES:
            return
        if reset_if_same and mode == self.current_mode:
            self.games[mode] = self._new_game_state(mode)
        else:
            self._timer_pause(self.game)
            self._store_view()
            self._schedule_save()

        self.current_mode = mode
        if mode not in self.games:
            self.games[mode] = self._new_game_state(mode)
        self.game = self.games[mode]
        self.neighbors = self._build_neighbors(self.game["rows"], self.game["cols"])

        self._fit_canvas_to_view()
        self._rebuild_items()
        self._redraw_all()
        self._timer_ensure()
        self._activity()
        self._schedule_save()

    # ---------------- drawing/layout ----------------
    def _max_view_wh(self):
        wmax = max(420, min(980, int(self._primary_work.right - self._primary_work.left - 40)))
        hmax = max(320, min(780, int(self._primary_work.bottom - self._primary_work.top - 160)))
        return wmax, hmax

    def _fit_canvas_to_view(self):
        g = self.game
        bw, bh = g["cols"] * self.cell_px, g["rows"] * self.cell_px
        mw, mh = self._max_view_wh()
        vw, vh = min(bw, mw), min(bh, mh)
        self.canvas.config(width=vw, height=vh, scrollregion=(0, 0, bw, bh))
        self._pan_enabled = (self.cell_px >= PAN_CELL_THRESHOLD) or (bw > vw) or (bh > vh)
        try:
            self.canvas.xview_moveto(float(g.get("view_x", 0.0)))
            self.canvas.yview_moveto(float(g.get("view_y", 0.0)))
        except Exception:
            pass

    def _rebuild_items(self):
        self.canvas.delete("cell")
        g = self.game
        n = g["rows"] * g["cols"]
        self._cell_rect = [None] * n
        self._cell_text = [None] * n
        fsz = max(9, int(self.cell_px * 0.55))
        for i in range(n):
            r, c = divmod(i, g["cols"])
            x0, y0 = c * self.cell_px, r * self.cell_px
            x1, y1 = x0 + self.cell_px, y0 + self.cell_px
            self._cell_rect[i] = self.canvas.create_rectangle(
                x0, y0, x1, y1, fill="#bdbdbd", outline="#7a7a7a", tags=("cell",)
            )
            self._cell_text[i] = self.canvas.create_text(
                (x0 + x1) / 2, (y0 + y1) / 2, text="", fill="black",
                font=("Segoe UI", fsz, "bold"), tags=("cell",)
            )

    def _redraw_cell(self, i, show_all=False, hit=None):
        g = self.game
        mines, nums, rev, flg, state = g["mines"], g["numbers"], g["revealed"], g["flagged"], g["state"]
        rid, tid = self._cell_rect[i], self._cell_text[i]

        revealed = rev[i] or show_all or (state in ("lost", "won") and mines[i])
        if state == "lost" and show_all:
            revealed = True

        if not revealed:
            self.canvas.itemconfig(rid, fill="#bdbdbd", outline="#7a7a7a")
            if flg[i]:
                self.canvas.itemconfig(tid, text="⚑", fill="#D32F2F")
            else:
                self.canvas.itemconfig(tid, text="")
            return

        self.canvas.itemconfig(rid, fill=("#ffb3b3" if hit == i else "#e0e0e0"), outline="#9e9e9e")

        if mines[i]:
            self.canvas.itemconfig(tid, text="*", fill=("#D32F2F" if hit == i else "black"))
            return
        if state == "lost" and flg[i] and not mines[i]:
            self.canvas.itemconfig(tid, text="X", fill="#D32F2F")
            return
        n = nums[i]
        self.canvas.itemconfig(tid, text=(str(n) if n else ""), fill=self.NUM_COLORS.get(n, "black"))

    def _redraw_all(self):
        g = self.game
        n = g["rows"] * g["cols"]
        show_all = g["state"] == "lost"
        hit = g.get("_hit")
        for i in range(n):
            self._redraw_cell(i, show_all=show_all, hit=hit)
        self._update_labels()

    def _store_view(self):
        if not self.game:
            return
        try:
            self.game["view_x"] = float(self.canvas.xview()[0])
            self.game["view_y"] = float(self.canvas.yview()[0])
        except Exception:
            pass

    # ---------------- tile size ----------------
    def tile_plus(self):
        self._activity()
        self.cell_px = min(CELL_MAX, self.cell_px + CELL_STEP)
        self._fit_canvas_to_view()
        self._rebuild_items()
        self._redraw_all()
        self._schedule_save()

    def tile_minus(self):
        self._activity()
        self.cell_px = max(CELL_MIN, self.cell_px - CELL_STEP)
        self._fit_canvas_to_view()
        self._rebuild_items()
        self._redraw_all()
        self._schedule_save()

    # ---------------- board input ----------------
    def _cell_at_event(self, event):
        g = self.game
        x, y = int(self.canvas.canvasx(event.x)), int(self.canvas.canvasy(event.y))
        c, r = x // self.cell_px, y // self.cell_px
        if 0 <= r < g["rows"] and 0 <= c < g["cols"]:
            return r * g["cols"] + c
        return None

    def _board_press(self, event):
        if self._stealth:
            return
        self._activity()
        self._press_xy = (event.x, event.y)
        self._press_cell = self._cell_at_event(event)
        self._pan_active = False
        if self._pan_enabled:
            self.canvas.scan_mark(event.x, event.y)
        self._longpress_token += 1
        tok = self._longpress_token
        self.after(LONGPRESS_FLAG_MS, lambda: self._longpress_flag(tok))

    def _board_motion(self, event):
        if self._stealth or not self._press_xy:
            return
        dx, dy = event.x - self._press_xy[0], event.y - self._press_xy[1]
        if self._pan_enabled and not self._pan_active and (dx * dx + dy * dy) >= (PAN_MOVE_PX * PAN_MOVE_PX):
            self._pan_active = True
            self._longpress_token += 1
        if self._pan_enabled and self._pan_active:
            self.canvas.scan_dragto(event.x, event.y, gain=1)

    def _board_release(self, event):
        if self._stealth or not self._press_xy:
            return
        self._longpress_token += 1
        was_pan, cell = self._pan_active, self._press_cell
        self._press_xy = self._press_cell = None
        self._pan_active = False
        if was_pan:
            self._store_view()
            self._schedule_save()
            return
        if cell is not None:
            self._left_cell(cell)

    def _longpress_flag(self, token):
        if self._stealth or token != self._longpress_token:
            return
        if self._pan_active or self._press_cell is None:
            return
        self._right_cell(self._press_cell)

    def _board_right(self, event):
        if self._stealth:
            return
        self._activity()
        if self._pan_active:
            return
        cell = self._cell_at_event(event)
        if cell is not None:
            self._right_cell(cell)

    # ---------------- idle ----------------
    def _activity(self):
        if self._stealth:
            return
        self._last_activity = time.monotonic()
        self._hide_idle_prompt()

    def _show_idle_prompt(self, remaining_s: int):
        self.idle_label.config(text=f"Inactive. Hiding in {remaining_s}s.\nTap “I'm here” to stay visible.")
        if not self._prompt_showing:
            self._prompt_showing = True
            self.idle_prompt.place(relx=0.5, rely=0.5, anchor="center")

    def _hide_idle_prompt(self):
        if self._prompt_showing:
            self._prompt_showing = False
            self.idle_prompt.place_forget()

    def _idle_loop(self):
        if not self._stealth:
            idle = time.monotonic() - self._last_activity
            if idle >= IDLE_STEALTH_AT:
                self.enter_stealth()
            elif idle >= IDLE_PROMPT_AT:
                self._show_idle_prompt(max(0, int(IDLE_STEALTH_AT - idle)))
            else:
                self._hide_idle_prompt()
        self._idle_job = self.after(250, self._idle_loop)

    # ---------------- opacity ----------------
    def _on_opacity(self, _val=None):
        self._activity()
        if not self._stealth:
            self.attributes("-alpha", float(self.opacity.get()))
        self._schedule_save()

    # ---------------- move window ----------------
    def _start_move(self, event):
        self._activity()
        self._drag_off_x = event.x_root - self.winfo_x()
        self._drag_off_y = event.y_root - self.winfo_y()

    def _do_move(self, event):
        self._activity()
        self.geometry(f"+{event.x_root - self._drag_off_x}+{event.y_root - self._drag_off_y}")
        self._schedule_save()

    # ---------------- always-on-top ----------------
    def _top_loop(self):
        if not self._stealth and self._hwnd:
            w.user32.SetWindowPos(
                self._hwnd, w.HWND_TOPMOST, 0, 0, 0, 0,
                w.SWP_NOMOVE | w.SWP_NOSIZE | w.SWP_NOACTIVATE | w.SWP_SHOWWINDOW
            )
            try:
                self.attributes("-topmost", True)
            except tk.TclError:
                pass
        self._top_job = self.after(1500, self._top_loop)

    # ---------------- stealth / click-through ----------------
    def _set_clickthrough(self, enable: bool):
        if not self._hwnd:
            return
        ex = w.get_exstyle(self._hwnd)
        ex = (ex | w.WS_EX_TRANSPARENT) if enable else (ex & ~w.WS_EX_TRANSPARENT)
        w.set_exstyle(self._hwnd, ex)
        w.user32.SetWindowPos(
            self._hwnd, None, 0, 0, 0, 0,
            w.SWP_NOMOVE | w.SWP_NOSIZE | w.SWP_NOACTIVATE | w.SWP_FRAMECHANGED
        )

    def enter_stealth(self):
        if self._stealth:
            return
        self._show_game_view(resize=False)
        self._stealth = True
        self._hide_idle_prompt()
        self._timer_pause(self.game)
        self._store_view()
        self._schedule_save()
        try:
            self.attributes("-topmost", False)
        except tk.TclError:
            pass
        self.attributes("-alpha", 0.0)
        self._set_clickthrough(True)
        if self._hwnd:
            w.user32.SetWindowPos(self._hwnd, w.HWND_NOTOPMOST, 0, 0, 0, 0, w.SWP_NOMOVE | w.SWP_NOSIZE | w.SWP_NOACTIVATE)
            w.user32.SetWindowPos(self._hwnd, w.HWND_BOTTOM, 0, 0, 0, 0, w.SWP_NOMOVE | w.SWP_NOSIZE | w.SWP_NOACTIVATE)

    def exit_stealth(self):
        if not self._stealth:
            return
        self._stealth = False
        self._last_activity = time.monotonic()
        self._set_clickthrough(False)
        self.attributes("-alpha", float(self.opacity.get()))
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.lift()
        self._timer_ensure()

    # ---------------- global mouse pump (Tk thread) ----------------
    def _hook_pump(self):
        try:
            while True:
                msg, x, y, t_mono = self._hook_q.get_nowait()
                self._handle_global_mouse(int(msg), int(x), int(y), float(t_mono))
        except queue.Empty:
            pass
        self._hook_pump_job = self.after(25, self._hook_pump)

    def _bg_pump(self):
        try:
            while True:
                kind, payload = self._bg_q.get_nowait()
                if kind == "update_check":
                    installed, latest, err = payload
                    self._update_check_inflight = False
                    if err:
                        self.update_var.set("Update: error")
                        LOG.warning("Update check error: %s", err)
                    elif latest:
                        self.update_var.set(f"Update: {latest} available (installed {installed})")
                    else:
                        self.update_var.set(f"Update: up to date ({installed})")
        except queue.Empty:
            pass
        self._bg_pump_job = self.after(150, self._bg_pump)

    def _point_in_window(self, x, y) -> bool:
        if not self._hwnd:
            return False
        rc = w.RECT()
        if not w.user32.GetWindowRect(self._hwnd, ctypes.byref(rc)):
            return False
        return rc.left <= x < rc.right and rc.top <= y < rc.bottom

    @staticmethod
    def _stroke_dir(dx, dy):
        adx, ady = abs(dx), abs(dy)
        if adx >= 1.8 * ady:
            return "R" if dx > 0 else "L"
        if ady >= 1.8 * adx:
            return "D" if dy > 0 else "U"
        if dx > 0 and dy < 0:
            return "UR"
        if dx > 0 and dy > 0:
            return "DR"
        if dx < 0 and dy < 0:
            return "UL"
        return "DL"

    def _gesture_reset(self):
        self._g_idx = 0
        self._g_t0 = 0.0
        self._g_last = 0.0

    def _handle_global_mouse(self, msg: int, x: int, y: int, now: float):
        if not self._stealth:
            if msg == w.WM_LBUTTONDOWN and not self._point_in_window(x, y):
                self.enter_stealth()
            return

        if msg == w.WM_LBUTTONDOWN:
            self._stroke_start = (x, y) if self._in_primary(x, y) else None
            return

        if msg != w.WM_LBUTTONUP or not self._stroke_start:
            return

        if not self._in_primary(x, y):
            self._stroke_start = None
            self._gesture_reset()
            return

        sx, sy = self._stroke_start
        self._stroke_start = None
        dx, dy = x - sx, y - sy
        if (dx * dx + dy * dy) < (self._min_stroke_px * self._min_stroke_px):
            return

        if self._g_idx == 0:
            self._g_t0 = self._g_last = now
        else:
            if (now - self._g_last) > STEP_MAX_GAP_S or (now - self._g_t0) > TOTAL_MAX_S:
                self._gesture_reset()
                return
            self._g_last = now

        d = self._stroke_dir(dx, dy)
        if d == SECRET_GESTURE[self._g_idx]:
            self._g_idx += 1
            if self._g_idx >= len(SECRET_GESTURE):
                self._gesture_reset()
                self.exit_stealth()
        else:
            self._g_idx = 1 if d == SECRET_GESTURE[0] else 0
            self._g_t0 = self._g_last = (now if self._g_idx else 0.0)

    # ---------------- minesweeper core ----------------
    def _build_neighbors(self, rows, cols):
        nbr = [[] for _ in range(rows * cols)]
        for r in range(rows):
            for c in range(cols):
                i = r * cols + c
                out = []
                for rr in (r - 1, r, r + 1):
                    if 0 <= rr < rows:
                        for cc in (c - 1, c, c + 1):
                            if 0 <= cc < cols and not (rr == r and cc == c):
                                out.append(rr * cols + cc)
                nbr[i] = out
        return nbr

    def _place_mines(self, safe_i):
        g = self.game
        n = g["rows"] * g["cols"]
        safe = {safe_i, *self.neighbors[safe_i]}
        available = [i for i in range(n) if i not in safe]
        if len(available) < g["mine_count"]:
            available = [i for i in range(n) if i != safe_i]
        mines = [False] * n
        for i in random.sample(available, g["mine_count"]):
            mines[i] = True
        g["mines"] = mines
        nums = [0] * n
        for i in range(n):
            if mines[i]:
                continue
            nums[i] = sum(1 for j in self.neighbors[i] if mines[j])
        g["numbers"] = nums

    def _left_cell(self, i):
        g = self.game
        if g["state"] in ("lost", "won") or g["flagged"][i] or g["revealed"][i]:
            return
        if g["first_click"]:
            self._place_mines(i)
            g["first_click"] = False
            g["state"] = "playing"
            g["timer_running"] = True
            self._timer_ensure()
        if g["mines"][i]:
            self._lose(i)
            return
        self._reveal_from(i)
        self._check_win()
        self._redraw_all()
        self._schedule_save()

    def _right_cell(self, i):
        g = self.game
        if g["state"] in ("lost", "won") or g["revealed"][i]:
            return
        g["flagged"][i] = not g["flagged"][i]
        self._redraw_cell(i)
        self._update_labels()
        self._check_win()
        self._schedule_save()

    def _reveal_from(self, start_i):
        g = self.game
        q = deque([start_i])
        while q:
            i = q.popleft()
            if g["revealed"][i] or g["flagged"][i]:
                continue
            g["revealed"][i] = True
            self._redraw_cell(i)
            if g["numbers"][i] == 0:
                for j in self.neighbors[i]:
                    if not g["revealed"][j] and not g["mines"][j]:
                        q.append(j)

    def _lose(self, hit_i):
        g = self.game
        g["state"] = "lost"
        g["_hit"] = hit_i
        g["timer_running"] = False
        self._timer_pause(g)
        self._redraw_all()
        self._schedule_save()

    def _check_win(self):
        g = self.game
        if g["state"] in ("lost", "won"):
            return
        n = g["rows"] * g["cols"]
        if sum(1 for i in range(n) if (not g["mines"][i]) and (not g["revealed"][i])) == 0:
            g["state"] = "won"
            g["timer_running"] = False
            self._timer_pause(g)
            for i in range(n):
                if g["mines"][i]:
                    g["flagged"][i] = True
            self._redraw_all()

    # ---------------- timer ----------------
    def _elapsed(self, g):
        mono = g.get("_mono")
        if mono is None:
            return float(g.get("elapsed", 0.0))
        return float(g.get("elapsed", 0.0)) + (time.monotonic() - mono)

    def _timer_pause(self, g):
        if not g:
            return
        mono = g.get("_mono")
        if mono is None:
            return
        g["elapsed"] = self._elapsed(g)
        g.pop("_mono", None)

    def _timer_ensure(self):
        g = self.game
        if not g or self._stealth:
            return
        if g.get("state") != "playing" or not g.get("timer_running", False):
            self._timer_pause(g)
            return
        if g.get("_mono") is None:
            g["_mono"] = time.monotonic()
        if self._timer_job is None:
            self._timer_job = self.after(250, self._timer_tick)

    def _timer_tick(self):
        self._timer_job = None
        if self._stealth or not self.game:
            return
        g = self.game
        if g.get("state") != "playing" or not g.get("timer_running", False):
            return
        self._update_labels()
        self._timer_job = self.after(250, self._timer_tick)

    def _update_labels(self):
        g = self.game
        if not g:
            return
        self.time_var.set(f"Time: {int(self._elapsed(g))}")
        self.mines_var.set(f"Mines: {max(0, g['mine_count'] - sum(g['flagged']))}")
        t = int(self._elapsed(g))
        m = max(0, g["mine_count"] - sum(g["flagged"]))
        self._stats_var.set(f"Time: {t}   Mines: {m}")

    # ---------------- cleanup ----------------
    def destroy(self):
        try:
            self._timer_pause(self.game)
            self._store_view()
            self._save_all()
        except Exception:
            pass

        for job in (self._top_job, self._idle_job, self._save_job, self._timer_job, self._hook_pump_job, self._bg_pump_job):
            if job:
                try:
                    self.after_cancel(job)
                except Exception:
                    pass

        try:
            if self._hook:
                self._hook.stop()
        except Exception:
            pass

        super().destroy()


_MUTEX_NAME = r"Local\SelfServSweeper_{C7DCE7D1-3DAA-4D2B-9C38-3C7A3D43B53F}"


def run_app(*, start_stealth: bool = True, no_hook: bool = False, health_file: Optional[Path] = None) -> int:
    mutex = w.create_single_instance_mutex(_MUTEX_NAME)
    if not mutex:
        return 0
    try:
        app = MinesweeperApp(
            health_file=health_file,
            start_stealth=start_stealth,
            enable_hook=not no_hook,
        )
        app.mainloop()
        return 0
    except Exception:
        LOG.exception("App crashed.")
        return 1
    finally:
        try:
            w.kernel32.CloseHandle(mutex)
        except Exception:
            pass


def main(argv=None) -> int:
    enable_dpi_awareness()
    ap = argparse.ArgumentParser(prog="python -m selfservsweeper.app")
    ap.add_argument("--health-file")
    ap.add_argument("--visible", action="store_true")
    ap.add_argument("--no-hook", action="store_true")
    args = ap.parse_args(argv)
    health = Path(args.health_file) if args.health_file else None
    return run_app(start_stealth=not args.visible, no_hook=args.no_hook, health_file=health)


if __name__ == "__main__":
    raise NotImplementedError("This is a rollback test.")
    raise SystemExit(main())