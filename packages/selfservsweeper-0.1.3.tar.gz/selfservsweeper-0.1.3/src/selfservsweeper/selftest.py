from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path


def run_selftest() -> tuple[bool, list[str]]:
    msgs: list[str] = []

    if sys.platform != "win32":
        return False, ["Not running on Windows (win32)."]

    if sys.maxsize <= 2**32:
        msgs.append("WARNING: 32-bit Python detected. Use 64-bit Python on the kiosk.")

    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
    except Exception as e:
        return False, [f"tkinter failed to initialize: {e}"]

    try:
        d = Path(os.environ.get("LOCALAPPDATA") or Path.home())
        d.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", delete=True, dir=str(d), encoding="utf-8") as f:
            f.write("ok")
            f.flush()
    except Exception as e:
        return False, [f"Cannot write to LOCALAPPDATA/home: {e}"]

    return True, msgs