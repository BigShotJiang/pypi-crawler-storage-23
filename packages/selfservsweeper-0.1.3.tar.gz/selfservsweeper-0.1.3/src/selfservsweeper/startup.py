from __future__ import annotations

from pathlib import Path

from .config import startup_dir, startup_vbs_path


def is_enabled() -> bool:
    return startup_vbs_path().exists()


def enable(pythonw: str, script: Path, *, args: list[str] | None = None) -> None:
    args = args or []
    sd = startup_dir()
    sd.mkdir(parents=True, exist_ok=True)

    cmd_parts = [f'"{pythonw}"', f'"{str(script)}"', *[f'"{a}"' for a in args]]
    cmd = " ".join(cmd_parts)
    cmd_vbs = cmd.replace('"', '""')

    vbs = (
        'Set WshShell = CreateObject("WScript.Shell")\r\n'
        f'WshShell.Run "{cmd_vbs}", 0, False\r\n'
    )
    startup_vbs_path().write_text(vbs, encoding="utf-8")


def disable() -> None:
    try:
        startup_vbs_path().unlink(missing_ok=True)
    except Exception:
        pass