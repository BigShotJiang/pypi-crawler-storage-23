from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler

from .config import log_dir


def setup_logging(name: str, *, filename: str, level: int = logging.INFO) -> logging.Logger:
    d = log_dir()
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        logger = logging.getLogger(name)
        logger.addHandler(logging.NullHandler())
        return logger

    log_path = d / filename

    logger = logging.getLogger(name)
    logger.setLevel(level)

    if logger.handlers:
        return logger

    fmt = logging.Formatter(
        fmt="%(asctime)s.%(msecs)03d %(levelname)s [%(process)d:%(threadName)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    fh = RotatingFileHandler(str(log_path), maxBytes=512 * 1024, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(level)
    logger.addHandler(fh)

    if sys.stderr and hasattr(sys.stderr, "isatty") and sys.stderr.isatty():
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        sh.setLevel(level)
        logger.addHandler(sh)

    logger.propagate = False
    return logger