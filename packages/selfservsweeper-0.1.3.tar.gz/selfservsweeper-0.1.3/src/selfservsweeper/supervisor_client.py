from __future__ import annotations

import json
import os
import time
from typing import Optional

from .config import bootstrap_config_path, command_path


def is_supervised() -> bool:
    return os.environ.get("SELFSERVSWEEPER_SUPERVISED") == "1"


def read_bootstrap_config() -> Optional[dict]:
    p = bootstrap_config_path()
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def request_action(action: str, *, extra: dict | None = None) -> None:
    p = command_path()
    p.parent.mkdir(parents=True, exist_ok=True)

    payload = {"schema": 1, "action": action, "ts": time.time()}
    if extra:
        payload.update(extra)

    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    tmp.replace(p)