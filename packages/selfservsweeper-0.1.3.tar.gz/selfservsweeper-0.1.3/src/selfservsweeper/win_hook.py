from __future__ import annotations

import ctypes
import queue
import threading
import time
from typing import Optional

from . import win_api as w


class GlobalMouseHook(threading.Thread):
    def __init__(self, out_queue: "queue.SimpleQueue[tuple[int, int, int, float]]"):
        super().__init__(daemon=True, name="GlobalMouseHook")
        self._q = out_queue
        self._hook: Optional[w.HHOOK] = None
        self._proc = None
        self._tid: Optional[int] = None
        self._ready = threading.Event()
        self.enabled = False

    def start_and_wait(self, timeout: float = 2.0) -> bool:
        super().start()
        self._ready.wait(timeout=timeout)
        return bool(self.enabled)

    def run(self) -> None:
        self._tid = int(w.kernel32.GetCurrentThreadId())

        @w.LowLevelMouseProc
        def proc(nCode, wParam, lParam):
            try:
                if nCode == w.HC_ACTION:
                    msg = int(wParam)
                    if msg in (w.WM_LBUTTONDOWN, w.WM_LBUTTONUP):
                        ms = ctypes.cast(lParam, ctypes.POINTER(w.MSLLHOOKSTRUCT)).contents
                        self._q.put((msg, int(ms.pt.x), int(ms.pt.y), time.monotonic()))
            except Exception:
                pass
            return w.user32.CallNextHookEx(self._hook, nCode, wParam, lParam)

        self._proc = proc
        self._hook = w.user32.SetWindowsHookExW(
            w.WH_MOUSE_LL,
            self._proc,
            w.kernel32.GetModuleHandleW(None),
            0,
        )

        self.enabled = bool(self._hook)
        self._ready.set()

        if not self._hook:
            return

        msg = w.MSG()
        while True:
            r = int(w.user32.GetMessageW(ctypes.byref(msg), None, 0, 0))
            if r == 0 or r == -1:
                break
            w.user32.TranslateMessage(ctypes.byref(msg))
            w.user32.DispatchMessageW(ctypes.byref(msg))

        if self._hook:
            w.user32.UnhookWindowsHookEx(self._hook)
            self._hook = None

    def stop(self) -> None:
        if self._tid:
            w.user32.PostThreadMessageW(int(self._tid), w.WM_QUIT, 0, 0)