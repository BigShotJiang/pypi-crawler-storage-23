from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes


def enable_dpi_awareness() -> bool:
    if sys.platform != "win32":
        return False

    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        fn = user32.SetProcessDpiAwarenessContext
        fn.argtypes = [ctypes.c_void_p]
        fn.restype = wintypes.BOOL
        DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = ctypes.c_void_p(-4)
        if fn(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2):
            return True
    except Exception:
        pass

    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        fn = user32.SetProcessDPIAware
        fn.argtypes = []
        fn.restype = wintypes.BOOL
        return bool(fn())
    except Exception:
        return False