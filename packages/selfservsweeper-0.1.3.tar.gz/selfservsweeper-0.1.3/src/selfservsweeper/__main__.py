from __future__ import annotations

import argparse
import sys

from . import win_dpi
from .app import run_app
from .installer import install as install_app
from . import startup
from .selftest import run_selftest
from .config import bootstrap_config_path, supervisor_script_path
from .supervisor_client import read_bootstrap_config


def _cmd_run(args) -> int:
    return run_app(start_stealth=not args.visible, no_hook=args.no_hook)


def _cmd_install(args) -> int:
    install_app(enable_startup=args.enable_startup, clear_existing_venv=args.force, run_now=(not args.no_run))
    return 0


def _cmd_enable_startup(_args) -> int:
    cfg = read_bootstrap_config()
    if not cfg:
        print(f"Missing {bootstrap_config_path()}; run 'install' first.", file=sys.stderr)
        return 2
    startup.enable(cfg["base_pythonw"], supervisor_script_path())
    return 0


def _cmd_disable_startup(_args) -> int:
    startup.disable()
    return 0


def _cmd_selftest(_args) -> int:
    ok, msgs = run_selftest()
    for m in msgs:
        print(m)
    return 0 if ok else 1


def main(argv=None) -> int:
    win_dpi.enable_dpi_awareness()

    p = argparse.ArgumentParser(prog="selfservsweeper")
    sub = p.add_subparsers(dest="cmd")

    prun = sub.add_parser("run", help="Run the app (unsupervised).")
    prun.add_argument("--visible", action="store_true")
    prun.add_argument("--no-hook", action="store_true")
    prun.set_defaults(func=_cmd_run)

    pins = sub.add_parser("install", help="One-time install: supervisor + venv + optional startup.")
    pins.add_argument("--enable-startup", action="store_true")
    pins.add_argument("--force", action="store_true")
    pins.add_argument("--no-run", action="store_true", help="Do not launch the app immediately after install.")
    pins.set_defaults(func=_cmd_install)

    pen = sub.add_parser("enable-startup")
    pen.set_defaults(func=_cmd_enable_startup)

    pdis = sub.add_parser("disable-startup")
    pdis.set_defaults(func=_cmd_disable_startup)

    pst = sub.add_parser("selftest")
    pst.set_defaults(func=_cmd_selftest)

    args = p.parse_args(argv)
    if not getattr(args, "cmd", None):
        args = p.parse_args(["run"] + (argv or []))
    return int(args.func(args))


def gui_main() -> None:
    raise SystemExit(main())


if __name__ == "__main__":
    raise SystemExit(main())