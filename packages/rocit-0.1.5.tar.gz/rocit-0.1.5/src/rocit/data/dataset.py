import torch
import polars as pl

import torch.nn.functional as F

from datasets import Dataset as HFDataset

from torch.utils.data import Dataset as TorchDataset
from rocit.constants import HUMAN_CHROMOSOME_ENUM

from typing import Optional

from rocit.validation import (
    FLOAT_TYPES,
    INTEGER_TYPES,
    ID_TYPES,
    STRING_TYPES,
    validate_chromosome_values,
    validate_columns,
)
class EmbeddingStore:
    def __init__(self,name,embedding_df,key_cols):
        self.name = name
        self.index_col = f"{self.name}_index"
        self.key_cols = key_cols
        self.embedding_df = self._load_embedding_df(embedding_df)
        self.index_df = self._create_index_df()
        
    def __str__(self):
        return self.name
    
    def _validate_embedding_df(self,embedding_df):
        data_cols = [col for col in embedding_df.columns if not col in self.key_cols]

        if len(data_cols) ==0:
            raise ValueError(f'{self.name} has no data columns')
       
        col_format = {col:ID_TYPES for col in self.key_cols}
        col_format.update({col:FLOAT_TYPES for col in data_cols})
        
        validate_columns(embedding_df, f"embedding {self.name}", col_format)
        validate_chromosome_values(embedding_df,f"embedding {self.name}")

        if embedding_df.select(self.key_cols).is_duplicated().any():
            raise ValueError(f'{self.name} should be unique up to {"-".join(self.key_cols)}')


    def _load_embedding_df(self,embedding_df):
        embedding_df = embedding_df.drop([c for c in embedding_df.columns if c.startswith("__index_level_")])
        
        self._validate_embedding_df(embedding_df)
        embedding_df = embedding_df.with_columns(pl.col('chromosome').cast(HUMAN_CHROMOSOME_ENUM))
        embedding_df = embedding_df.sort(self.key_cols)
        embedding_df = embedding_df.with_columns(
            pl.arange(1, len(embedding_df) + 1, dtype=pl.Int32).alias(self.index_col)
        )
        return embedding_df
    def _create_index_df(self):
        return self.embedding_df.select(self.key_cols+[self.index_col])
    def _validate_read_df(self,read_df):
        for col in self.key_cols:
            if not col in read_df.columns:
                raise ValueError(f'Key column {col} for {self.name} is not in read df')
        if self.index_col in read_df.columns:
            raise ValueError(f'Read df already has index col {self.index_col} for {self.name}')
    def merge_with_read_df(self,read_df):
        self._validate_read_df(read_df)
        read_df = read_df.join(self.index_df, on=self.key_cols, how="left")
        read_df = read_df.with_columns(
        pl.col(self.index_col).fill_null(0).cast(pl.Int32)
        )
        return read_df
    def get_embedding_vector(self):
        drop_cols = self.key_cols +[self.index_col]
        embedding_vector = self.embedding_df.drop(drop_cols).to_numpy()
        embedding_vector = torch.from_numpy(embedding_vector).float()
        return embedding_vector

class ReadDatasetBuilder:

    def __init__(self, read_df_store,label_cols,key_cols,embedding_sources,max_len=511):

        
        self.label_cols = label_cols
        self.max_len = max_len
        self.key_cols = key_cols
        self.embedding_sources = embedding_sources
        self.embedding_index_cols = [embedding_source.index_col for embedding_source in embedding_sources.values()]
        self.read_df_store = read_df_store
        

    def _validate_read_df(self, read_df: pl.DataFrame):

        validate_columns(read_df, "read_dataframe", {
            "chromosome": STRING_TYPES,
            "position": INTEGER_TYPES,
            "read_position": INTEGER_TYPES,
            "methylation": INTEGER_TYPES,
            'read_index':ID_TYPES
        })
        
        validate_chromosome_values(read_df,f"read df")
        non_nullable_columns = ['read_index', 'chromosome', 'methylation', 'read_position']

        for col in non_nullable_columns:
            if read_df[col].is_null().any():
                raise ValueError(f'{col} should not have any NA values')

        if not read_df['methylation'].is_between(0, 255).all():
            raise ValueError('Methylation column should only have values between 0 and 255')

        test_cols = list(self.key_cols)
        test_cols.append('read_position')
        if read_df.select(test_cols).is_duplicated().any():
            raise ValueError(f'Read data should be unique up to {"-".join(test_cols)}')
        
    def _get_processed_read_index_data(self, read_index_df: pl.DataFrame) -> dict:
        processed = {}
        read_index_df = read_index_df.sort('read_position')
        
        
        # Access first element of a column
        for label_col in self.label_cols:
            processed[label_col.lower()] = read_index_df.get_column(label_col)[0]
        
        
        processed['n_cpgs'] = read_index_df.height
        processed['methylation'] = read_index_df.get_column('methylation').cast(pl.UInt8).to_numpy()
        
        # Direct cast and numpy conversion - missing reference positions are mapped to -1
        processed['position'] =  read_index_df.get_column('position').fill_null(-1).cast(pl.Int32).to_numpy()
       
        processed['read_position'] = read_index_df.get_column('read_position').cast(pl.Int32).to_numpy()

        for embedding_index_col in self.embedding_index_cols:
            processed[embedding_index_col.lower()] = read_index_df.get_column(embedding_index_col).cast(pl.UInt32).to_numpy()  
            
        return processed
    
        
    def _process_read_df(self,read_df:pl.DataFrame):
        read_df = read_df.collect() if isinstance(read_df, pl.LazyFrame) else read_df
        self._validate_read_df(read_df)
        read_df = read_df.with_columns(pl.col('chromosome').cast(HUMAN_CHROMOSOME_ENUM))

        drop_cols = ['supplementary_alignment','read_count','strand']
        read_df = read_df.drop(drop_cols,strict=False)
        
        for embedding_source in self.embedding_sources.values():
            read_df = embedding_source.merge_with_read_df(read_df)

        read_groups = read_df.partition_by(self.key_cols, maintain_order=False)
    
        for i, read_index_df in enumerate(read_groups):
            yield self._get_processed_read_index_data(read_index_df)
  

    def _read_generator(self):
        read_df_store = self.read_df_store if isinstance(self.read_df_store, list) else [self.read_df_store]
        
        for read_df in read_df_store:
            for read_index_data in self._process_read_df(read_df):
                yield read_index_data
        
    def build(
        self,
        cache_dir: Optional[str] = '/scratch/',
        num_proc: Optional[int] = None,
     ):

        hf_dataset =  HFDataset.from_generator(
            self._read_generator,
            cache_dir=cache_dir,
            num_proc=num_proc,
            split='reads'
        )
        return ReadDataset(
            hf_dataset=hf_dataset,
            label_cols=self.label_cols,
            embedding_index_cols=self.embedding_index_cols,
        )
    
    

class ReadDataset(TorchDataset):

    METHYLATION_SCALE = 256.0
    BASE_READ_LENGTH = 20000.0

    def __init__(self, hf_dataset,label_cols,embedding_index_cols,max_len=511):

        self.hf_dataset = hf_dataset
        self.label_cols = label_cols
        self.embedding_index_cols =embedding_index_cols
        self.max_len = max_len
        

    def __len__(self) -> int:
        return len(self.hf_dataset)
    
    def get_downsample_indices(self,seq_len: int):
        
        if seq_len > self.max_len:
            perm = torch.randperm(seq_len)
            downsample_indices = perm[:self.max_len]
            downsample_indices, _ = torch.sort(downsample_indices) # Maintain order
            #return torch.arange(self.max_len)
            return downsample_indices
        return None

    def get_attention_mask(self,seq_len: int,downsample_indices):
        
        #seq length + class token
        mask = torch.zeros(self.max_len+1, dtype=torch.bool)
        
        if downsample_indices is not None:
      
            valid_len = self.max_len
        else:
            
            valid_len = min(seq_len, self.max_len)
            
        # 3. Fill the masked area with True
        mask[(valid_len+1):] = True
        
        return mask
    
    def apply_tensor_subsample_and_pad(self,tensor: torch.Tensor, downsample_indices, pad_value=0):
        if downsample_indices is not None:
            tensor = tensor[downsample_indices]

        current_len = tensor.size(0)
        if current_len < self.max_len:
            pad_size = self.max_len - current_len
            tensor = F.pad(tensor, (0, pad_size), value=pad_value)
            
        return tensor

    def __getitem__(self, idx):
        processed_read_data = self.hf_dataset[idx]
        downsample_indices = self.get_downsample_indices(processed_read_data['n_cpgs'])
        
        attention_mask = self.get_attention_mask(processed_read_data['n_cpgs'],downsample_indices)

        item_data = {}

        for col in self.label_cols:
            item_data[col] = processed_read_data[col]
        if 'tumor_read' in item_data:
            item_data['tumor_read'] = torch.tensor(item_data['tumor_read']).float()
        tensor_cols = ['methylation','read_position','position'] + [e for e in self.embedding_index_cols]
        for col in tensor_cols:
            
            item_data[col] = self.apply_tensor_subsample_and_pad(torch.tensor(processed_read_data[col]).long(),downsample_indices)
        item_data['methylation']  = (item_data['methylation'] / self.METHYLATION_SCALE + 0.5 / self.METHYLATION_SCALE).float()
        item_data['read_position']  = ((item_data['read_position'].float() - (item_data['read_position'][0].float())) / self.BASE_READ_LENGTH - 0.5)
        mask_start = attention_mask.long().argmax().item()-1
        mask_start = mask_start if attention_mask.any() else attention_mask.numel()
        
        if mask_start <= self.max_len:
            item_data['read_position'][mask_start:] = 0.0
            item_data['methylation'][mask_start:] = 0.0
        
        item_data['attention_mask'] = attention_mask

        return item_data