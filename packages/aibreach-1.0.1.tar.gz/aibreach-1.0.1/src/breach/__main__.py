"""
BREACH - CLI Entry Point
=========================
Allows running as: python -m breach
"""

from breach.cli import app

if __name__ == "__main__":
    app()
