"""Dioptas batch processing GUI package."""

from .version import __version__

