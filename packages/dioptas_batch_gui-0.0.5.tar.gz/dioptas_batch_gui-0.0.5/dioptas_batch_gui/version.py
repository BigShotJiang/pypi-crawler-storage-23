"""Single source of truth for package version."""

__version__ = "0.0.5"

"""
0.0.5 fix resolution of cake along theta axis.  it is adjusted to show twice more in cake than chi for twotheta
0.0.4 Include XY and DAT output options
0.0.3 Improve logical flow for overwrite
0.0.2 Initial version uploaded to pip
"""