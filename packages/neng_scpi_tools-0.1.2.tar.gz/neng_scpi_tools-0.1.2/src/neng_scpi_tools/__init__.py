"""NEnG SCPI Tools — shared serial/WiFi communication and GUI widgets.

Provides reusable modules for all NEnG instrument subprojects:
- ``myserial.scpi_serial``: USB CDC serial SCPI interface
- ``myserial.scpi_universal``: Unified Serial + WiFi/TCP SCPI interface
- ``connection_panel``: Reusable tkinter ConnectionPanel widget
- ``scpi_client``: Interactive SCPI terminal with tab-completion

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

__all__ = ["__version__"]

__version__ = "0.1.2"
