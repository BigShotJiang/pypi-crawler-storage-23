"""Third-party utilities for MCPCat."""
