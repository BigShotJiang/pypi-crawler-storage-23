"""Defines how we execute a tox environment."""

from __future__ import annotations
