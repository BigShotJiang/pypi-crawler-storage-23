"""Table rendering for hedge scenarios using rich."""

from typing import List

from rich.console import Console
from rich.table import Table
from rich import box
from rich.text import Text

from bet_hedge_calculator.calculator import HedgeScenario

console = Console()


def _roi_color(roi_pct: float) -> str:
    if roi_pct < 0:
        return "red"
    if roi_pct == 0:
        return "yellow"
    if roi_pct < 50:
        return "green"
    return "bright_green"


def render_table(
    scenarios: List[HedgeScenario],
    odds_a: float,
    stake_a: float,
    currency: str = "£",
) -> None:
    """Print the hedging scenarios as a rich table to stdout."""

    table = Table(
        title=f"Hedging Calculator  —  Team A odds: [bold]{odds_a}[/bold]  |  Stake on A: [bold]{currency}{stake_a:,.2f}[/bold]",
        box=box.ROUNDED,
        header_style="bold cyan",
        show_lines=True,
    )

    table.add_column("Target ROI", justify="right", style="bold", no_wrap=True)
    table.add_column("Required Odds B", justify="center", no_wrap=True)
    table.add_column(f"Stake on B ({currency})", justify="right", no_wrap=True)
    table.add_column(f"Total Invested ({currency})", justify="right", no_wrap=True)
    table.add_column(f"Guaranteed Profit ({currency})", justify="right", no_wrap=True)
    table.add_column("Note", justify="left")

    for s in scenarios:
        roi_str = Text(f"{s.roi_pct:+.1f}%", style=_roi_color(s.roi_pct))

        if not s.valid:
            table.add_row(
                roi_str,
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("Not achievable", style="italic dim"),
            )
        else:
            profit_style = "green" if s.guaranteed_profit >= 0 else "red"
            table.add_row(
                roi_str,
                f"{s.odds_b:.4f}",
                f"{currency}{s.stake_b:,.2f}",
                f"{currency}{s.total_invested:,.2f}",
                Text(f"{currency}{s.guaranteed_profit:,.2f}", style=profit_style),
                "",
            )

    console.print()
    console.print(table)
    console.print(
        f"[dim]Note: 'Not achievable' rows require Team B odds ≤ 1.0, which implies "
        f"ROI ≥ {odds_a - 1:.2f} ({(odds_a - 1) * 100:.0f}%) is beyond what this Team A odds can hedge.[/dim]"
    )
    console.print()
