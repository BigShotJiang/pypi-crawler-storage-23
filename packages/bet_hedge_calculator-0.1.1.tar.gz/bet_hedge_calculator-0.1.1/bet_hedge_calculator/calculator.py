"""
Hedging calculator — pure math, no I/O.

For a bet already placed on Team A (odds O_A, stake S_A), computes the
Team B stake and odds required to guarantee a fixed ROI regardless of outcome.

Derivation
----------
Guaranteed profit P for any outcome requires:
    S_A * O_A - S_A - S_B = P          (A wins)
    S_B * O_B - S_B - S_A = P          (B wins)

Both equations yield  S_A * O_A = S_B * O_B,  so:
    S_B = S_A * O_A / O_B

With ROI = P / (S_A + S_B), solving for O_B:
    O_B = O_A * (1 + ROI) / (O_A - 1 - ROI)

Valid only when  O_A - 1 - ROI > 0  →  ROI < O_A - 1.
"""

from dataclasses import dataclass
from typing import List


@dataclass
class HedgeScenario:
    roi_pct: float          # target ROI in percent, e.g. 10.0
    valid: bool             # False when O_B cannot be computed
    odds_b: float | None    # required decimal odds for Team B
    stake_b: float | None   # required stake on Team B
    total_invested: float | None
    guaranteed_profit: float | None


_MIN_DENOMINATOR = 1e-9   # guard against floating-point rounding at the upper boundary

def required_odds_b(odds_a: float, roi: float) -> float | None:
    """
    Compute required Team B odds for a given ROI (as a decimal, e.g. 0.10).

    Returns None when the ROI is mathematically unachievable with these Team A odds.
    The valid ROI range is  -1/(odds_a+1) < ROI < odds_a-1  (both bounds exclusive).
    """
    denominator = odds_a - 1.0 - roi
    if denominator <= _MIN_DENOMINATOR:
        return None
    return odds_a * (1.0 + roi) / denominator


def calculate_scenario(odds_a: float, stake_a: float, roi: float) -> HedgeScenario:
    """
    Compute a single hedge scenario.

    Parameters
    ----------
    odds_a : decimal odds of Team A  (must be > 1.0)
    stake_a: amount already staked on Team A  (must be > 0)
    roi    : target ROI as a decimal (e.g. 0.10 for 10%)
    """
    roi_pct = round(roi * 100, 2)

    ob = required_odds_b(odds_a, roi)

    if ob is None or ob <= 1.0:
        return HedgeScenario(
            roi_pct=roi_pct,
            valid=False,
            odds_b=None,
            stake_b=None,
            total_invested=None,
            guaranteed_profit=None,
        )

    stake_b = stake_a * odds_a / ob
    total = stake_a + stake_b
    profit = roi * total

    return HedgeScenario(
        roi_pct=roi_pct,
        valid=True,
        odds_b=round(ob, 4),
        stake_b=round(stake_b, 2),
        total_invested=round(total, 2),
        guaranteed_profit=round(profit, 2),
    )


def calculate_scenarios(
    odds_a: float,
    stake_a: float,
    roi_min_pct: float = -20.0,
    roi_max_pct: float = 200.0,
    roi_step_pct: float = 5.0,
) -> List[HedgeScenario]:
    """
    Generate hedge scenarios for a range of target ROI values.

    Parameters
    ----------
    odds_a      : decimal odds of Team A (must be > 1.0)
    stake_a     : stake already placed on Team A (must be > 0)
    roi_min_pct : minimum ROI in percent (default -20%)
    roi_max_pct : maximum ROI in percent (default 200%)
    roi_step_pct: step size in percent (default 5%)

    Returns
    -------
    List of HedgeScenario, one per ROI step.
    """
    if odds_a <= 1.0:
        raise ValueError(f"odds_a must be greater than 1.0, got {odds_a}")
    if stake_a <= 0:
        raise ValueError(f"stake_a must be positive, got {stake_a}")
    if roi_step_pct <= 0:
        raise ValueError(f"roi_step_pct must be positive, got {roi_step_pct}")

    scenarios = []
    # Build ROI range without floating-point drift
    steps = round((roi_max_pct - roi_min_pct) / roi_step_pct)
    for i in range(steps + 1):
        roi_pct = roi_min_pct + i * roi_step_pct
        roi = roi_pct / 100.0
        scenarios.append(calculate_scenario(odds_a, stake_a, roi))

    return scenarios
