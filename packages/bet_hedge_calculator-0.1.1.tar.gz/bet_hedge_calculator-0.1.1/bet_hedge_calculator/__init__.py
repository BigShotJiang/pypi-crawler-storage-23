"""
bet-hedge-calculator — sports bet hedging calculator.

Computes the Team B odds and stake required to guarantee a fixed return
on investment regardless of which team wins.

Quick start
-----------
    from bet_hedge_calculator import calculate_scenarios, render_table

    scenarios = calculate_scenarios(odds_a=2.5, stake_a=100)
    render_table(scenarios, odds_a=2.5, stake_a=100)

For raw data without printing:
    for s in scenarios:
        if s.valid:
            print(s.roi_pct, s.odds_b, s.stake_b, s.guaranteed_profit)
"""

from bet_hedge_calculator.calculator import (
    HedgeScenario,
    calculate_scenario,
    calculate_scenarios,
    required_odds_b,
)
from bet_hedge_calculator.formatter import render_table

__all__ = [
    "HedgeScenario",
    "calculate_scenario",
    "calculate_scenarios",
    "required_odds_b",
    "render_table",
]

__version__ = "0.1.0"
