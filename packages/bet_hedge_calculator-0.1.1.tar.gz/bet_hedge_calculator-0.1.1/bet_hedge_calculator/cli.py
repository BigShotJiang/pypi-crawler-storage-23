"""
Bet Hedging Calculator — CLI entry point.

Usage
-----
  # Interactive mode (prompts for input):
  bet-hedge-calc

  # Direct mode:
  bet-hedge-calc --odds-a 2.50 --stake-a 100

  # Custom ROI range:
  bet-hedge-calc --odds-a 3.0 --stake-a 200 --roi-min -10 --roi-max 100 --roi-step 2.5
"""

import argparse
import sys

from bet_hedge_calculator.calculator import calculate_scenarios
from bet_hedge_calculator.formatter import render_table, console


def _prompt_float(prompt: str, min_val: float = None, min_exclusive: bool = False) -> float:
    while True:
        try:
            val = float(input(prompt).strip())
            if min_val is not None:
                if min_exclusive and val <= min_val:
                    console.print(f"[red]Must be greater than {min_val}. Try again.[/red]")
                    continue
                if not min_exclusive and val < min_val:
                    console.print(f"[red]Must be at least {min_val}. Try again.[/red]")
                    continue
            return val
        except ValueError:
            console.print("[red]Invalid number. Try again.[/red]")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Hedging calculator: guaranteed profit regardless of match outcome.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--odds-a", type=float, help="Decimal odds of Team A (e.g. 2.50)")
    parser.add_argument("--stake-a", type=float, help="Your stake on Team A (e.g. 100)")
    parser.add_argument("--roi-min", type=float, default=-20.0, help="Min ROI %% (default: -20)")
    parser.add_argument("--roi-max", type=float, default=200.0, help="Max ROI %% (default: 200)")
    parser.add_argument("--roi-step", type=float, default=5.0, help="ROI step %% (default: 5)")
    parser.add_argument("--currency", type=str, default="£", help="Currency symbol (default: £)")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    console.print("\n[bold cyan]═══ Bet Hedging Calculator ═══[/bold cyan]\n")

    # Gather inputs interactively if not supplied via flags
    if args.odds_a is None:
        console.print("[bold]Enter Team A decimal odds[/bold] (e.g. 2.50 means 5/2)")
        odds_a = _prompt_float("  Odds A > ", min_val=1.0, min_exclusive=True)
    else:
        odds_a = args.odds_a
        if odds_a <= 1.0:
            console.print(f"[red]--odds-a must be > 1.0, got {odds_a}[/red]")
            sys.exit(1)

    if args.stake_a is None:
        console.print("\n[bold]Enter your stake on Team A[/bold] (e.g. 100)")
        stake_a = _prompt_float("  Stake A > ", min_val=0.0, min_exclusive=True)
    else:
        stake_a = args.stake_a
        if stake_a <= 0:
            console.print(f"[red]--stake-a must be > 0, got {stake_a}[/red]")
            sys.exit(1)

    try:
        scenarios = calculate_scenarios(
            odds_a=odds_a,
            stake_a=stake_a,
            roi_min_pct=args.roi_min,
            roi_max_pct=args.roi_max,
            roi_step_pct=args.roi_step,
        )
    except ValueError as exc:
        console.print(f"[red]Error: {exc}[/red]")
        sys.exit(1)

    render_table(scenarios, odds_a=odds_a, stake_a=stake_a, currency=args.currency)


if __name__ == "__main__":
    main()
