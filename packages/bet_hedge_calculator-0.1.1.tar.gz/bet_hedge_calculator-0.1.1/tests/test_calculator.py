"""
Unit tests + stress tests for calculator.py.

Unit tests verify known mathematical outcomes.
Stress tests sweep a wide parameter space and assert invariants hold everywhere.

Key mathematical facts
----------------------
- Required O_B = O_A * (1 + ROI) / (O_A - 1 - ROI)
- At 0% ROI:  O_B = O_A / (O_A - 1)   [NOT equal to O_A except when O_A = 2.0]
- Valid range: -1/(O_A + 1) < ROI < O_A - 1
  Upper bound: denominator (O_A - 1 - ROI) must be > 0
  Lower bound: O_B must be > 1  →  ROI > -1/(O_A + 1)
- O_B is independent of stake size; all monetary values scale linearly with stake.
"""

import math
import pytest

from bet_hedge_calculator.calculator import (
    HedgeScenario,
    calculate_scenario,
    calculate_scenarios,
    required_odds_b,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

EPSILON = 1e-6          # tight tolerance for exact formula checks
MONEY_TOL = 0.02        # £0.02 tolerance for rounded monetary comparisons


def _exact_ob(odds_a: float, roi: float) -> float:
    return odds_a * (1.0 + roi) / (odds_a - 1.0 - roi)


def _valid_roi_range(odds_a: float):
    """Return (roi_lower_exclusive, roi_upper_exclusive) for the given odds."""
    return -1.0 / (odds_a + 1.0), odds_a - 1.0


def assert_hedge_invariant(odds_a: float, stake_a: float, scenario: HedgeScenario) -> None:
    """
    Verify the core invariant using exact (unrounded) formula values.
    Stored values on the scenario are rounded to 2-4 dp so we recompute
    the precise O_B and S_B internally.
    """
    if not scenario.valid:
        return

    roi = scenario.roi_pct / 100.0
    ob_exact = _exact_ob(odds_a, roi)
    sb_exact = stake_a * odds_a / ob_exact
    total_exact = stake_a + sb_exact
    profit_exact = roi * total_exact

    # Both win branches yield the same gross payout
    payout_a = stake_a * odds_a
    payout_b = sb_exact * ob_exact
    rel_tol = EPSILON * max(payout_a, 1.0)
    assert abs(payout_a - payout_b) < rel_tol, (
        f"Gross payouts differ: A={payout_a:.8f}, B={payout_b:.8f} "
        f"(odds_a={odds_a}, stake_a={stake_a}, roi={roi*100:.1f}%)"
    )

    # Stored profit should be close to exact value (within rounding of 2 dp)
    assert abs(scenario.guaranteed_profit - profit_exact) < MONEY_TOL * max(abs(profit_exact), 1.0), (
        f"Stored profit {scenario.guaranteed_profit} far from exact {profit_exact:.6f}"
    )


# ---------------------------------------------------------------------------
# Unit tests — required_odds_b
# ---------------------------------------------------------------------------

class TestRequiredOddsB:
    def test_zero_roi_evens(self):
        """At evens (O_A=2.0) and 0% ROI, O_B = O_A = 2.0."""
        assert abs(required_odds_b(2.0, 0.0) - 2.0) < EPSILON

    def test_zero_roi_formula(self):
        """At 0% ROI, O_B = O_A / (O_A - 1) for any O_A."""
        for oa in [1.5, 2.0, 3.0, 5.0, 10.0]:
            expected = oa / (oa - 1.0)
            result = required_odds_b(oa, 0.0)
            assert abs(result - expected) < EPSILON, (
                f"O_A={oa}: expected O_B={expected:.6f}, got {result:.6f}"
            )

    def test_roi_at_upper_limit_returns_none(self):
        """ROI = O_A - 1 makes denominator zero → None."""
        assert required_odds_b(2.0, 1.0) is None    # ROI = 100% = O_A - 1

    def test_roi_above_upper_limit_returns_none(self):
        """ROI > O_A - 1 → denominator negative → None."""
        assert required_odds_b(2.0, 1.5) is None

    def test_positive_roi_requires_higher_odds_b(self):
        """Higher target ROI requires higher (less available) Team B odds."""
        ob_0  = required_odds_b(3.0, 0.00)
        ob_10 = required_odds_b(3.0, 0.10)
        ob_50 = required_odds_b(3.0, 0.50)
        assert ob_0 < ob_10 < ob_50

    def test_negative_roi_lowers_odds_b(self):
        """Accepting a small loss requires lower Team B odds."""
        lb, _ = _valid_roi_range(3.0)   # lower valid boundary
        roi_neg = (lb + 0.0) / 2        # midpoint: safely in valid region
        ob_0   = required_odds_b(3.0, 0.00)
        ob_neg = required_odds_b(3.0, roi_neg)
        assert ob_neg < ob_0

    def test_known_value(self):
        """
        O_A=3.0, ROI=10%:
          O_B = 3.0 * 1.10 / (3.0 - 1 - 0.10) = 3.3 / 1.9 ≈ 1.736842
        """
        expected = 3.0 * 1.10 / (3.0 - 1.0 - 0.10)
        assert abs(required_odds_b(3.0, 0.10) - expected) < EPSILON

    def test_lower_boundary_is_minus_one_over_oa_plus_one(self):
        """
        At ROI = -1/(O_A+1), O_B = 1.0 exactly → invalid (must be > 1).
        Just below this boundary the scenario is also invalid.
        """
        for oa in [2.0, 3.0, 5.0, 10.0]:
            lb_roi = -1.0 / (oa + 1.0)
            ob_at_lb = required_odds_b(oa, lb_roi)
            # O_B should be exactly 1.0 at the lower boundary
            assert ob_at_lb is not None  # formula doesn't divide by zero here
            assert abs(ob_at_lb - 1.0) < EPSILON, (
                f"O_A={oa}: expected O_B=1.0 at lower bound ROI={lb_roi*100:.4f}%, got {ob_at_lb}"
            )


# ---------------------------------------------------------------------------
# Unit tests — calculate_scenario
# ---------------------------------------------------------------------------

class TestCalculateScenario:
    def test_evens_zero_roi_is_balanced(self):
        """Evens (2.0) + 0% ROI → equal stakes on both sides, zero profit."""
        s = calculate_scenario(2.0, 100.0, 0.0)
        assert s.valid
        assert abs(s.stake_b - 100.0) < MONEY_TOL
        assert abs(s.guaranteed_profit) < MONEY_TOL

    def test_total_invested_equals_sum_of_stakes(self):
        s = calculate_scenario(2.5, 200.0, 0.05)
        assert s.valid
        assert abs(s.total_invested - (200.0 + s.stake_b)) < MONEY_TOL

    def test_profit_equals_roi_times_total(self):
        s = calculate_scenario(3.0, 100.0, 0.10)
        assert s.valid
        expected = 0.10 * s.total_invested
        assert abs(s.guaranteed_profit - expected) < MONEY_TOL

    def test_negative_roi_valid_within_bound(self):
        """Negative ROI is valid as long as it is above -1/(O_A+1)."""
        # For O_A=3.0, lower bound = -1/4 = -25%, so -10% is valid
        s = calculate_scenario(3.0, 100.0, -0.10)
        assert s.valid
        assert s.guaranteed_profit < 0

    def test_roi_at_upper_limit_is_invalid(self):
        s = calculate_scenario(2.0, 100.0, 1.0)    # ROI = 100% = O_A - 1
        assert not s.valid

    def test_roi_above_upper_limit_is_invalid(self):
        s = calculate_scenario(2.0, 100.0, 1.5)
        assert not s.valid

    def test_roi_at_lower_boundary_is_invalid(self):
        """At exact lower boundary ROI = -1/(O_A+1), O_B = 1.0 → invalid."""
        oa = 4.0
        lb_roi = -1.0 / (oa + 1.0)     # = -0.20
        s = calculate_scenario(oa, 100.0, lb_roi)
        assert not s.valid

    def test_roi_below_lower_boundary_is_invalid(self):
        """ROI below lower boundary → O_B < 1 → invalid."""
        oa = 5.0
        lb_roi = -1.0 / (oa + 1.0)     # ≈ -16.67%
        s = calculate_scenario(oa, 100.0, lb_roi - 0.05)   # −21.67%
        assert not s.valid

    def test_invalid_odds_raises(self):
        with pytest.raises(ValueError):
            calculate_scenarios(1.0, 100.0)

    def test_invalid_stake_raises(self):
        with pytest.raises(ValueError):
            calculate_scenarios(2.0, -50.0)

    def test_invalid_step_raises(self):
        with pytest.raises(ValueError):
            calculate_scenarios(2.0, 100.0, roi_step_pct=0)

    def test_invariant_known_case(self):
        s = calculate_scenario(3.0, 100.0, 0.10)
        assert_hedge_invariant(3.0, 100.0, s)

    def test_large_stake(self):
        s = calculate_scenario(4.0, 1_000_000.0, 0.05)
        assert s.valid
        assert_hedge_invariant(4.0, 1_000_000.0, s)

    def test_fractional_stake(self):
        s = calculate_scenario(2.0, 0.50, 0.0)
        assert s.valid
        assert abs(s.stake_b - 0.50) < MONEY_TOL

    def test_high_odds_scenario(self):
        """High odds (10.0) allow high ROI targets."""
        s = calculate_scenario(10.0, 100.0, 4.0)    # 400% ROI
        assert s.valid
        assert_hedge_invariant(10.0, 100.0, s)


# ---------------------------------------------------------------------------
# Unit tests — calculate_scenarios (list generation)
# ---------------------------------------------------------------------------

class TestCalculateScenarios:
    def test_default_range_length(self):
        """Default: -20% to 200% in 5% steps = 45 scenarios."""
        scenarios = calculate_scenarios(2.5, 100.0)
        assert len(scenarios) == 45

    def test_roi_values_are_correct(self):
        scenarios = calculate_scenarios(2.5, 100.0, roi_min_pct=0.0, roi_max_pct=20.0, roi_step_pct=5.0)
        rois = [s.roi_pct for s in scenarios]
        assert rois == [0.0, 5.0, 10.0, 15.0, 20.0]

    def test_rows_above_upper_limit_are_invalid(self):
        """All rows with ROI ≥ O_A - 1 must be invalid."""
        scenarios = calculate_scenarios(2.0, 100.0)
        for s in scenarios:
            if s.roi_pct >= 100.0:
                assert not s.valid, f"Expected invalid at ROI={s.roi_pct}%"

    def test_rows_within_valid_range_are_valid(self):
        """All rows strictly inside the valid ROI range must be valid."""
        oa = 5.0
        lb_pct = -1.0 / (oa + 1.0) * 100   # ≈ -16.67%
        ub_pct = (oa - 1.0) * 100           # = 400%
        scenarios = calculate_scenarios(oa, 100.0, roi_min_pct=-10.0, roi_max_pct=50.0, roi_step_pct=5.0)
        for s in scenarios:
            if lb_pct < s.roi_pct < ub_pct:
                assert s.valid, f"Expected valid at ROI={s.roi_pct}%"

    def test_custom_step(self):
        scenarios = calculate_scenarios(3.0, 50.0, roi_min_pct=0.0, roi_max_pct=10.0, roi_step_pct=2.5)
        rois = [s.roi_pct for s in scenarios]
        assert rois == [0.0, 2.5, 5.0, 7.5, 10.0]


# ---------------------------------------------------------------------------
# Stress tests — sweep odds × stakes × roi
# ---------------------------------------------------------------------------

class TestStress:
    ODDS_RANGE  = [1.1, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 7.5, 10.0, 20.0, 50.0]
    STAKE_RANGE = [0.01, 1.0, 10.0, 100.0, 1_000.0, 100_000.0, 1_000_000.0]
    ROI_STEPS   = [-0.20, -0.10, -0.05, 0.0, 0.05, 0.10, 0.25, 0.50, 1.0, 2.0, 5.0, 10.0]

    def test_invariant_holds_across_all_combinations(self):
        """
        For every valid (odds_a, stake_a, roi) combination, the hedge invariant
        must hold to EPSILON precision on exact (unrounded) formula values.
        """
        failures = []
        for oa in self.ODDS_RANGE:
            for sa in self.STAKE_RANGE:
                for roi in self.ROI_STEPS:
                    s = calculate_scenario(oa, sa, roi)
                    try:
                        assert_hedge_invariant(oa, sa, s)
                    except AssertionError as exc:
                        failures.append(
                            f"odds_a={oa}, stake_a={sa}, roi={roi*100:.1f}%: {exc}"
                        )

        assert not failures, f"{len(failures)} invariant failures:\n" + "\n".join(failures[:10])

    def test_validity_boundary_correct(self):
        """
        Valid range is  -1/(O_A+1) < ROI < O_A-1  (both bounds exclusive).
        Check that every scenario is marked valid/invalid accordingly.

        Rows that fall within 1e-4 of either boundary are skipped because
        floating-point representation of decimal fractions can shift values
        across the boundary (e.g. 1.1 - 1.0 - 0.1 ≠ 0 in float64).
        """
        BOUNDARY_GUARD = 1e-4   # skip ROI values within this distance of a boundary
        failures = []
        for oa in self.ODDS_RANGE:
            lb, ub = _valid_roi_range(oa)
            for roi in self.ROI_STEPS:
                # Skip cases too close to either boundary
                if abs(roi - lb) < BOUNDARY_GUARD or abs(roi - ub) < BOUNDARY_GUARD:
                    continue

                s = calculate_scenario(oa, 100.0, roi)
                strictly_valid   = lb + BOUNDARY_GUARD < roi < ub - BOUNDARY_GUARD
                strictly_invalid = roi < lb - BOUNDARY_GUARD or roi > ub + BOUNDARY_GUARD

                if strictly_valid and not s.valid:
                    failures.append(
                        f"Expected valid: odds_a={oa}, roi={roi*100:.1f}% "
                        f"(valid range: {lb*100:.2f}%..{ub*100:.2f}%)"
                    )
                if strictly_invalid and s.valid:
                    failures.append(
                        f"Expected invalid: odds_a={oa}, roi={roi*100:.1f}% "
                        f"(valid range: {lb*100:.2f}%..{ub*100:.2f}%)"
                    )

        assert not failures, "\n".join(failures[:10])

    def test_stake_scaling_linearity(self):
        """
        Doubling stake_a should double stake_b, total_invested, and guaranteed_profit.
        O_B must remain identical (it is stake-independent).
        Comparison uses a relative tolerance to account for 2 dp rounding.
        """
        REL_TOL = 0.001   # 0.1% — tighter than rounding error of round(x, 2)
        failures = []
        for oa in [2.0, 3.0, 5.0]:
            for roi in [0.0, 0.10, 0.50]:
                s1 = calculate_scenario(oa, 100.0, roi)
                s2 = calculate_scenario(oa, 200.0, roi)
                if not (s1.valid and s2.valid):
                    continue
                # O_B must be identical (not stake-dependent)
                if abs(s1.odds_b - s2.odds_b) > EPSILON:
                    failures.append(f"O_B changed with stake: {s1.odds_b} vs {s2.odds_b}")
                # Monetary values should double within rounding tolerance
                for label, v1, v2 in [
                    ("stake_b",         s1.stake_b,         s2.stake_b),
                    ("total_invested",  s1.total_invested,  s2.total_invested),
                    ("profit",          s1.guaranteed_profit, s2.guaranteed_profit),
                ]:
                    if v1 == 0:
                        continue
                    ratio = v2 / v1
                    if abs(ratio - 2.0) > REL_TOL:
                        failures.append(
                            f"{label} not linear (odds_a={oa}, roi={roi*100:.0f}%): "
                            f"{v1} → {v2}, ratio={ratio:.6f}"
                        )

        assert not failures, "\n".join(failures[:10])

    def test_odds_b_monotone_in_roi(self):
        """Required O_B increases monotonically as target ROI increases (within valid range)."""
        failures = []
        for oa in self.ODDS_RANGE:
            lb, ub = _valid_roi_range(oa)
            valid_rois = sorted(r for r in self.ROI_STEPS if lb + EPSILON < r < ub - EPSILON)
            if len(valid_rois) < 2:
                continue
            prev_ob = None
            for roi in valid_rois:
                s = calculate_scenario(oa, 100.0, roi)
                if s.valid:
                    if prev_ob is not None and s.odds_b < prev_ob - EPSILON:
                        failures.append(
                            f"O_B not monotone: odds_a={oa}, roi={roi*100:.1f}%, "
                            f"O_B={s.odds_b} < prev {prev_ob}"
                        )
                    prev_ob = s.odds_b

        assert not failures, "\n".join(failures[:10])

    def test_no_nan_or_inf_in_valid_scenarios(self):
        """Valid scenarios must never contain NaN or Inf."""
        failures = []
        for oa in self.ODDS_RANGE:
            for sa in self.STAKE_RANGE:
                for roi in self.ROI_STEPS:
                    s = calculate_scenario(oa, sa, roi)
                    if not s.valid:
                        continue
                    for field, val in [
                        ("odds_b",            s.odds_b),
                        ("stake_b",           s.stake_b),
                        ("total_invested",    s.total_invested),
                        ("guaranteed_profit", s.guaranteed_profit),
                    ]:
                        if math.isnan(val) or math.isinf(val):
                            failures.append(
                                f"odds_a={oa}, sa={sa}, roi={roi*100:.1f}%: {field}={val}"
                            )
        assert not failures, "\n".join(failures[:10])

    def test_gross_payout_equality_exact(self):
        """
        Using exact (unrounded) formula values:
        S_A * O_A  must equal  S_B_exact * O_B_exact  for all valid scenarios.
        """
        failures = []
        for oa in self.ODDS_RANGE:
            for sa in self.STAKE_RANGE:
                for roi in self.ROI_STEPS:
                    s = calculate_scenario(oa, sa, roi)
                    if not s.valid:
                        continue
                    ob_exact = _exact_ob(oa, roi)
                    sb_exact = sa * oa / ob_exact
                    payout_a = sa * oa
                    payout_b = sb_exact * ob_exact
                    rel_tol = EPSILON * max(payout_a, 1.0)
                    if abs(payout_a - payout_b) >= rel_tol:
                        failures.append(
                            f"odds_a={oa}, sa={sa}, roi={roi*100:.1f}%: "
                            f"payout_a={payout_a:.8f}, payout_b={payout_b:.8f}"
                        )
        assert not failures, f"{len(failures)} payout equality failures:\n" + "\n".join(failures[:5])
