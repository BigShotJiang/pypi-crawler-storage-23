"""Unit tests - fast, isolated, no I/O."""
