"""stemtrace tests."""
