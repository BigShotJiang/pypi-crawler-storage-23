"""Integration tests - require running services (Redis, Celery)."""
