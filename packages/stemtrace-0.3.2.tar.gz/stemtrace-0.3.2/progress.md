# progress.md

Progress tracking lives in `.context/progress.md`.

See `.context/progress.md`.
