"""Library component - Celery integration."""
