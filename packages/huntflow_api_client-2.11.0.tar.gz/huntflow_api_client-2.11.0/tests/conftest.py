pytest_plugins = [
    "tests.fixtures.server",
    "tests.fixtures.tokens",
]
