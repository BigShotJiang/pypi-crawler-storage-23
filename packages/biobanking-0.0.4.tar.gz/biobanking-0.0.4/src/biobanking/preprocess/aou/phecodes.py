import os
import pandas as pd
from phetk.phecode import Phecode


def collect_phecode_info():
    from biobanking.utils.config import AllofUs
    aou = AllofUs()
    # All of Us platform
    phecode = Phecode(platform="aou")
    phecode.count_phecode(
        phecode_version="X",
        icd_version="US",
        output_file_path="aou_phecodeX_counts.tsv"
    )
    phe_df = pd.read_csv("aou_phecodeX_counts.tsv", dtype={"phecode": str}, sep="\t")
    phe_df.to_csv(f"{aou.bucket}/data/phenotypes/raw/aou_phecodeX_counts.tsv", index=False, sep="\t")
    return

def clean_phecode_info():
    from biobanking.utils.config import AllofUs
    aou = AllofUs()
    phe_df = pd.read_csv(f"{aou.bucket}/data/phenotypes/raw/aou_phecodeX_counts.tsv", sep="\t", dtype={"phecode": str})
    # Keep individual-phenotype pairs which has atleast two sources of evidence from ICD codes
    phe_df = phe_df.loc[phe_df["count"]>=2]
    # Save category wise phecodes in wide format
    for g in phe_df.groupby(phe_df.phecode.str.split("_", expand=True).iloc[:, 0]):
        gwide = g[1].pivot_table(index="person_id", columns="phecode", values="count").fillna(0.).reset_index()
        gwide.to_csv(f"{aou.bucket}/data/phenotypes/processed/aou_phecodeX_{g[0]}_counts.csv.gz", index=False)
    return

def save_phecode_info():
    from biobanking.utils.config import AllofUs
    aou = AllofUs()
    cov_df = pd.read_csv(f"{aou.bucket}/data/phenotypes/individuals.csv.gz")
    phedir = "data/phenotypes/processed"
    filepaths = aou.list_gcs_files(phedir)

    for filepath in filepaths:
        filename = os.path.basename(filepath)
        if filename.startswith("aou_phecodeX"):
            cat = filename.split("_")[2]
            phedf = pd.read_csv(f"{filepath}")
            # individuals with available EHR data
            ehr_set = set(cov_df.loc[cov_df.has_ehr_data==1, "person_id"])
            # individuals without a diagnosis within the phecode category
            no_phe_set = ehr_set.difference(set(phedf.person_id))
            no_phedf = pd.DataFrame(
                {c:list(no_phe_set) if c=="person_id" else [0. for _ in range(len(no_phe_set))] for c in phedf.columns}
            )
            # merge the two dataframes
            phedf = pd.concat((phedf, no_phedf))
            phedf = (phedf.set_index("person_id")>0).astype(int)
            phedf.to_csv(f"{aou.bucket}/data/phenotypes/aou_phecodeX_{cat}.csv.gz")
    return
