import os 
from google.cloud import storage

class AllofUs:
    def __init__(self, home_dir=""):
        self.bucket = os.getenv("WORKSPACE_BUCKET")
        self.cdr = os.environ["WORKSPACE_CDR"]
        self.google_project = os.getenv("GOOGLE_PROJECT")
        self.home_dir = home_dir

    def list_gcs_files(self, prefix):
        storage_client = storage.Client()
        bucket_obj = storage_client.bucket(self.bucket.lstrip("gs://"))
        blobs = bucket_obj.list_blobs(prefix=prefix)
        file_paths = [f"{self.bucket}/{blob.name}" for blob in blobs]
        return file_paths
