# Biobanking
Systematic collection, processing, storage, and analysis of biological samples and associated health data for medical research.

# Supported pipelines
## Preprocess

## QC (Quality Control)

## Annotation

## Association

## Summary

# Supported biobanks
## All of Us

## UK Biobank

# Internal Use
```bash
python -m pip install -U pip build
pip install twine
# linux
rm -rf dist build *.egg-info src/*.egg-info
# windows
Remove-Item -Recurse -Force dist, *.egg-info, src\*.egg-info
python -m build
pip install dist/biobanking-0.0.4-py3-none-any.whl
python -c "from biobanking.association.aou import prepare_traits, create_regenie_burden_files; from biobanking.preprocess.aou.measurements import save_measurements_in_wide_format; print('import ok')"
twine upload dist/*
```
