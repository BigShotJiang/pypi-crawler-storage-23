"""@model and @stream decorators for registering inference endpoints."""

from __future__ import annotations
