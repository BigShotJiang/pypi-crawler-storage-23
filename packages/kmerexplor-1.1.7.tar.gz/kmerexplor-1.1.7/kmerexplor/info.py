# info.py

APPNAME = "KmerExploR"
SHORTDESC = "KmerExploR provides information on RNA-sequencing datasets."
LICENCE = "GPL3"
VERSION = "1.1.7"
AUTHOR = "Benoit Guibert"
AUTHOR_EMAIL = "benoit.guibert@free.fr"
