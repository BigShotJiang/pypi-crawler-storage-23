"""
token_network: validate input and return token network config.

Usage:
    from token_network import network

    # All config for a network (config + tokens on that network)
    network.bitcoin.config
    network.bitcoin.tokens
    network.bitcoin.to_dict()   # {"config": {...}, "tokens": [...]}

    # Data for a specific token on a network
    network.bsc.usdt   # dict: network config, token info, contract_address, decimal, native
    network.ethereum.usdt
    network.tron.usdt

Unknown network or token raises token_network.TokenNetworkError.
"""

from ._accessor import TokenNetworkError, NetworkAccessor, network

__all__ = ["network", "TokenNetworkError", "NetworkAccessor"]
__version__ = "0.1.0"
