"""Attribute-based access to network and token config: network.bitcoin, network.bsc.usdt."""

from __future__ import annotations

from typing import Any

from ._loader import load_all


class TokenNetworkError(Exception):
    """Raised when a network or token is unknown or invalid."""


class _NetworkNode:
    """Represents one network. Supports .config, .tokens, and .<token_symbol> (e.g. .usdt)."""

    __slots__ = ("_net_key", "_network_tokens", "_token_on_network")

    def __init__(
        self,
        net_key: str,
        network_tokens: dict[str, dict[str, Any]],
        token_on_network: dict[tuple[str, str], dict[str, Any]],
    ) -> None:
        self._net_key = net_key
        self._network_tokens = network_tokens
        self._token_on_network = token_on_network

    @property
    def config(self) -> dict[str, Any]:
        """Network config for this network."""
        if self._net_key not in self._network_tokens:
            raise TokenNetworkError(f"Unknown network: {self._net_key!r}")
        return dict(self._network_tokens[self._net_key]["config"])

    @property
    def tokens(self) -> list[dict[str, Any]]:
        """List of token bindings on this network (each with token_info, contract_address, etc.)."""
        if self._net_key not in self._network_tokens:
            raise TokenNetworkError(f"Unknown network: {self._net_key!r}")
        return list(self._network_tokens[self._net_key]["tokens"])

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        token_sym = name.upper()
        key = (self._net_key, token_sym)
        if key not in self._token_on_network:
            raise TokenNetworkError(
                f"Token {token_sym!r} is not defined on network {self._net_key!r}. "
                f"Available tokens: {[t['token'] for t in self.tokens]}"
            )
        return dict(self._token_on_network[key])

    def to_dict(self) -> dict[str, Any]:
        """Return full network data: config and tokens (e.g. 'all bitcoin config')."""
        return {"config": self.config, "tokens": self.tokens}


class NetworkAccessor:
    """
    Attribute-based access to token network config.
    - network.bitcoin  -> network node (use .config, .tokens, or .to_dict() for full config)
    - network.bsc.usdt -> dict with network config, token info, contract_address, decimal, native
    """

    __slots__ = ("_network_tokens", "_token_on_network")

    def __init__(self) -> None:
        self._network_tokens, self._token_on_network, _ = load_all()

    def __getattr__(self, name: str) -> _NetworkNode:
        if name.startswith("_"):
            raise AttributeError(name)
        net_key = name.lower()
        if net_key not in self._network_tokens:
            known = ", ".join(sorted(self._network_tokens.keys()))
            raise TokenNetworkError(
                f"Unknown network: {name!r}. Known networks: {known}"
            )
        return _NetworkNode(
            net_key,
            self._network_tokens,
            self._token_on_network,
        )

    def __dir__(self) -> list[str]:
        return sorted(self._network_tokens.keys())


# Singleton used as `network`
network = NetworkAccessor()
