# token-network

Python library that validates input and returns token network config. Use attribute access like `network.bitcoin` or `network.bsc.usdt` to get network and token data.

## Install

From PyPI (after publishing):

```bash
pip install token-network
```

From source (development):

```bash
pip install -e .
```

## Publishing to PyPI (so others can `pip install token-network`)

1. Create an account on [pypi.org](https://pypi.org) (and optionally [test.pypi.org](https://test.pypi.org) for testing).

2. Install build and twine:
   ```bash
   pip install build twine
   ```

3. Build the package:
   ```bash
   cd /path/to/token-network
   python -m build
   ```

4. Upload to PyPI (you’ll be prompted for your PyPI username and password or token):
   ```bash
   twine upload dist/*
   ```
   To try Test PyPI first: `twine upload --repository testpypi dist/*`, then install with:
   `pip install --index-url https://test.pypi.org/simple/ token-network`

5. After that, anyone can run:
   ```bash
   pip install token-network
   ```

## Usage

```python
from token_network import network, TokenNetworkError
```

### Get all config for a network

```python
# Network config only
network.bitcoin.config
# {'network_type': 'UTXO', 'token_standard': 'BTC', 'base_token': 'BTC', ...}

# Tokens on that network (with contract_address, decimal, native, token_info)
network.bitcoin.tokens

# Full payload: config + tokens
network.bitcoin.to_dict()
# {"config": {...}, "tokens": [...]}
```

### Get data for a token on a network

```python
# All data for USDT on BSC: network config, token info, contract_address, decimal, native
network.bsc.usdt
# {
#   'network': {...},
#   'token': {'slug': 'usdt', 'symbol': 'USDT', 'name': 'tether', ...},
#   'contract_address': '0x55d398326f99059fF775485246999027B3197955',
#   'decimal': 18,
#   'native': False
# }

network.ethereum.usdt
network.tron.usdt
```

### Validation

Unknown network or token raises `TokenNetworkError`:

```python
try:
    network.unknown_chain
except TokenNetworkError as e:
    print(e)  # Unknown network: 'unknown_chain'. Known networks: bitcoin, bsc, ...

try:
    network.bsc.unknown_token
except TokenNetworkError as e:
    print(e)  # Token 'UNKNOWN_TOKEN' is not defined on network 'bsc'. Available tokens: [...]
```

## Data sources

Config is loaded from YAML inside the package:

- `networks.yaml` — chain config (network_type, token_standard, base_token, confirmation_number, …)
- `tokens.yaml` — token definitions (symbol, name, precision, factor)
- `token_networks.yaml` — which token exists on which network (contract_address, decimal, native)

To change data, edit the YAML files in `token_network/data/` (or the repo root and sync into the package).

## Development

```bash
pip install -e ".[dev]"
pytest
```
