from datetime import datetime
from typing import List
import os
import numpy as np
import pydicom
from pydicom.dataset import Dataset, FileDataset, FileMetaDataset
import pydicom.uid as uid
import matplotlib.pyplot as plt
from io import BytesIO
from SleepHarmonizer.PSGEventManager import PSGEventManager
from pyPhases.util.Logger import classLogger
from pyPhasesRecordloader import Event, Signal
from pydicom.fileset import FileSet

from SleepHarmonizer.recordwriter.RecordWriter import RecordWriter
from pathlib import Path


@classLogger
class RecordWriterDICOM(RecordWriter):

    
    def __init__(self, filePath = ".") -> None:
        super().__init__(filePath)
        self.unitMap = {}

    def _toDecimalString(self, number):
        return f"{float(number):.10g}"
    def getSubjectId(self):
        pc = self.metaData["patientCode"] if "patientCode" in self.metaData else "unknown"
        return f"sub-{pc}"

    def getSessionId(self):
        pc = self.metaData["sessionId"] if "sessionId" in self.metaData else "1"
        return f"ses-{pc}"

    def getFilePath(self, recordName):
        bids_path = os.path.join(self.filePath, self.getSubjectId(), self.getSessionId())

        return bids_path

    def getTaskFilePath(self, recordName, subject_id, session, sigType):
        basePath = self.getFilePath(recordName)
        file_name = f"{subject_id}_{session}_task-sleep_{sigType}.dcm"

        return f"{basePath}/{file_name}"

    def writeSignals(
        self, recordName, channels, events=None, startTime=None, signalIsDigital=False
    ):
        if events is None:
            events = []

        # Store study UID for SR reference
        self.study_instance_uid = pydicom.uid.generate_uid()
        
        # Store PSG signal for comprehensive SR creation
        self._current_psg_signal = type('PSGSignal', (), {'signals': channels})()

        # Split channels by modality
        channelsByType = {
            "eeg": [],
            "eog": [],
            "emg": [],
            "ecg": [],
            "sao2": [],
            "body": [],
            "effort": [],
            "flow": [],
            "mic": [],
            "resp": [],
        }

        channelMap = {
            "flow": "resp",
            "effort": "resp",
        }

        for ch in channels:
            if ch.typeStr in channelsByType:
                channel = channelMap[ch.typeStr] if ch.typeStr in channelMap else ch.typeStr
                channelsByType[channel].append(ch)

        # SOP Overview: https://dicom.nema.org/medical/dicom/current/output/chtml/part04/sect_b.5.html
        sopMap = {
            "eeg": "1.2.840.10008.5.1.4.1.1.9.7.4",
            "eog": "1.2.840.10008.5.1.4.1.1.9.7.3",
            "emg": "1.2.840.10008.5.1.4.1.1.9.7.2",
            "ecg": "1.2.840.10008.5.1.4.1.1.9.1.2",
            "body": "1.2.840.10008.5.1.4.1.1.9.8.1",
            # "effort": "1.2.840.10008.5.1.4.1.1.9.6.1",
            "resp": "1.2.840.10008.5.1.4.1.1.9.6.2",
            "mic": " 1.2.840.10008.5.1.4.1.1.9.4.1",
            "sao2": "1.2.840.10008.5.1.4.1.1.9.5.1",
        }

        subject_id = self.getSubjectId()
        session = self.getSessionId()
        fs = FileSet()
        psg_em = PSGEventManager()
        groups = psg_em.getEventGroupMap()
        for sigType, sop in sopMap.items():
            if len(channelsByType[sigType]) == 0:
                continue

            dataset = self._create_dataset(
                sop_class_uid=sop,
                channels=channelsByType[sigType],
                events=events,
                modality=sigType,
            )
            
            match sigType:
                case "eeg" | "eog":
                    sig_groups = ["sleepStage", "arousal", "grapho"]
                case "emg":
                    sig_groups = ["limb"]
                case "ecg":
                    sig_groups = ["sleepStage", "arousal", "grapho", "limb", "apnea", "spo2"]
                    # sig_groups = ["cardiac"]
                case "effort":
                    sig_groups = ["apnea"]
                case "resp":
                    sig_groups = ["apnea", "spo2"]

            sig_groups.append("light")
            dic_events = [e for e in events if groups[e["name"]] in sig_groups]
            self._add_events_to_dataset(dataset, dic_events)

            # Get BIDS-compliant file paths (requires patient info)
            file_path = self.getTaskFilePath(recordName, subject_id, session, sigType)
            if not Path(file_path).parent.exists():
                Path(file_path).parent.mkdir(parents=True)
            dataset.save_as(file_path, write_like_original=False)
            fs.add(file_path)

        # Write SR if events exist
        if events:
            sr_path = self.writeAnnotationSR(recordName, events)
            fs.add(sr_path)

        fs.write(self.getFilePath(recordName) + ".dcm")
    
    def _create_basedataset(self, sop):
        ds = Dataset()
        ds.SOPClassUID = sop
        ds.StudyInstanceUID = self.study_instance_uid
        ds.SeriesInstanceUID = pydicom.uid.generate_uid()
        ds.SOPInstanceUID = pydicom.uid.generate_uid()
        ds.StudyDate = self.metaData["start"].strftime("%Y%m%d")
        ds.StudyTime = self.metaData["start"].strftime("%H%M%S.%f")
        ds.StudyID = "acq-1"
        ds.AccessionNumber = "123456789"
        ds.SeriesNumber = 1
        ds.ReferringPhysicianName = "Unknown"
        # ds.PerformedProcedureCodeSequence = self._create_code_sequence('LN', '28633-6', ' Polysomnography (sleep) study')

        # when Content was create (after manual scoring)
        ds.ContentDate = self.metaData["start"].strftime("%Y%m%d")
        ds.ContentTime = self.metaData["start"].strftime("%H%M%S.%f")
        ds.InstanceNumber = 1

        # Patient information
        ds.PatientName = self.metaData["patient"] if "patient" in self.metaData else self.metaData["patientName"]
        ds.PatientID = self.metaData["patientCode"]
        ds.PatientBirthDate = self.metaData["birthdate"]
        ds.PatientSex = self.metaData["sex"]

        # Equipment information
        for k, v in self.metaData["dicom"].items():
            setattr(ds, k, v)

        ds.is_little_endian = True
        ds.is_implicit_VR = True
        return ds

    def _create_dataset(self, sop_class_uid, channels, events, modality):
        ds = self._create_basedataset(sop_class_uid)
        
        ds.Modality = modality.upper()

        dateTime = self.metaData["start"]
        ds.AcquisitionDateTime = dateTime
        ds.AcquisitionContextSequence = []

        # Add waveform data
        self._add_channels_to_dataset(ds, channels)

        return ds

    # def _create_sidecar_json(self, dcm_path, channels, startTime):
    #     import json

    #     sidecar = {
    #         "TaskName": "sleep",
    #         "SamplingFrequency": channels[0].frequency,
    #         "RecordingDuration": len(channels[0].signal) / channels[0].frequency,
    #         "RecordingType": "continuous",
    #         "StartTime": startTime.isoformat() if startTime else None,
    #         "Manufacturer": "SleepHarmonizer",
    #         "PowerLineFrequency": 50,
    #         "SoftwareFilters": "n/a",
    #         "HardwareFilters": "n/a",
    #         "ChannelCount": len(channels),
    #         "Channels": {
    #             ch.name: {"sampling_frequency": ch.frequency, "units": ch.dimension, "type": ch.name.split("_")[0]}
    #             for ch in channels
    #         },
    #     }

    #     json_path = dcm_path.replace(".dcm", ".json")
    #     with open(json_path, "w") as f:
    #         json.dump(sidecar, f, indent=4)

    def _add_channels_to_dataset(self, dataset, channels):
        dataset.WaveformSequence = []

        for channel in channels:
            waveform_seq = Dataset()
            waveform_seq.MultiplexGroupLabel = channel.name
            waveform_seq.MultiplexGroupTimeOffset = 0
            waveform_seq.WaveformOriginality = "ORIGINAL"
            waveform_seq.NumberOfWaveformChannels = 1
            waveform_seq.NumberOfWaveformSamples = len(channel.signal)
            waveform_seq.SamplingFrequency = channel.frequency

            # Calculate bits needed
            isDigitalSignal = channel.digitalMin
            if isDigitalSignal: 
                diff = channel.digitalMax - channel.digitalMin
                required_bits = np.ceil(np.log2(diff))

                # Set bit depth
                if required_bits <= 16:
                    bits = 16
                    sample_interp = "SS"
                elif required_bits <= 32:
                    bits = 32
                    sample_interp = "SL"
                else:
                    bits = 64
                    sample_interp = "SV"
            else: # loading float32
                if channel.signal.dtype == np.float16:
                    bits = 16
                    sample_interp = "SS"
                elif channel.signal.dtype == np.float32:
                    bits = 32
                    sample_interp = "SL"
                else:
                    bits = 64
                    sample_interp = "SV"
            # Channel Source Sequence
            chan_src_seq = Dataset()
            chan_src_seq.CodeMeaning = channel.name

            # Channel definition
            chan_def = Dataset()
            chan_def.ChannelLabel = channel.name
            chan_def.WaveformBitsStored = bits
            chan_def.ChannelSourceSequence = [chan_src_seq]

            # Add sensitivity units
            unit_map = {
                "uV": ("μV", "microvolts"),
                "μV": ("μV", "microvolts"),
                "mV": ("mV", "millivolts"),
                "%": ("%", "percent"),
                "cmH2O": ("cm[H2O]", "centimeters of water"),
                "mmHg": ("mm[Hg]", "millimeters of mercury"),
                "BPM": ("/min", "beats per minute"),
                "bpm": ("/min", "beats per minute"),
                "Hz": ("Hz", "hertz"),
                "°C": ("Cel", "degrees Celsius"),
                "celsius": ("Cel", "degrees Celsius"),
                "SpO2": ("%", "oxygen saturation percentage"),
                "L/min": ("L/min", "liters per minute"),
                "mL/min": ("mL/min", "milliliters per minute"),
                "V": ("V", "volts"),
                "A": ("A", "amperes"),
                "Ohm": ("Ohm", "ohms"),
                "g": ("g", "grams"),
                "kg": ("kg", "kilograms")
            }
            unit_map.update(self.unitMap)
            
            if channel.dimension in unit_map:
                ucum_code, description = unit_map[channel.dimension]
                chan_def.ChannelSensitivityUnitsSequence = self._create_code_sequence("UCUM", ucum_code, description)


            waveform = channel.signal
            if isDigitalSignal:
                # Calculate scaling factors
                digital_center_diff = (channel.digitalMax - channel.digitalMin + 1) / 2 + channel.digitalMin
                digital_to_physical = (channel.physicalMax - channel.physicalMin) / (channel.digitalMax - channel.digitalMin)
                baseline = (channel.physicalMax + channel.physicalMin) / 2 + digital_center_diff * digital_to_physical
                chan_def.ChannelSensitivity =  self._toDecimalString(digital_to_physical)
                chan_def.ChannelBaseline = baseline
                chan_def.ChannelSensitivityCorrectionFactor = 1
                waveform = (channel.signal - digital_center_diff).astype(f"int{bits}")

            chan_def.ChannelSampleSkew = 0

            waveform_seq.ChannelDefinitionSequence = [chan_def]
            waveform_seq.WaveformBitsAllocated = bits
            waveform_seq.WaveformSampleInterpretation = sample_interp
            waveform_seq.WaveformData = (waveform).reshape(-1, 1).tobytes()

            dataset.WaveformSequence.append(waveform_seq)

    def _add_events_to_dataset(self, dataset, events, mainCodeSeq=None):
        mainCodeSeq = ("DSM", "130860", "Pattern Event") if mainCodeSeq is None else mainCodeSeq
        dataset.WaveformAnnotationSequence = []
        for event in events:
            annotation = Dataset()
            annotation.ReferencedWaveformChannels = [0]
            if event["duration"] == 0:
                annotation.TemporalRangeType = "POINT"
                annotation.ReferencedTimeOffsets = [self._toDecimalString(event["start"])]
            else:
                annotation.TemporalRangeType = "SEGMENT"
                annotation.ReferencedTimeOffsets = [
                    self._toDecimalString(event["start"]), 
                    self._toDecimalString(event["end"])
                ]
            # annotation.ReferencedSamplePositions = [
            #     int(event["start"]), 
            #     int(event["start"] + event["duration"])
            # ]
            # annotation.ReferencedSamplePositions = [
            #     int(event["start"])
            # ]
            # annotation.TemporalRangeType = "POINT"
            # annotation.ReferencedTimeOffsets = [self._toDecimalString(event["start"])]
            # annotation.UnformattedTextValue = event["name"]
            codeSeq = self.getEventCodeSequence(event["name"])
            if codeSeq is None:
                name = event["name"]
                self.logError(f"Codesequence not found for event '{name}'")
                continue
            annotation.ConceptNameCodeSequence = self._create_code_sequence(*codeSeq)
            annotation.ConceptCodeSequence = self._create_code_sequence(*codeSeq)
            # annotation.ConceptCodeSequence = self._create_code_sequence("MDC", "10:256", "P wave")
            dataset.WaveformAnnotationSequence.append(annotation)

    def writeAnnotationSR(self, recordName, events):
        # Create SR dataset
        sr = self._create_basedataset('1.2.840.10008.5.1.4.1.1.88.22')
        
        sr.Modality = 'SR'      
        sr.CompletionFlag = "PARTIAL"
        sr.VerificationFlag = "UNVERIFIED"
        sr.ValueType = "CODE"

        sr.PerformedProcedureCodeSequence = self._create_code_sequence('LN', '28633-6', ' Polysomnography (sleep) study')
        
        sr.ConceptNameCodeSequence = self._create_code_sequence('LN', '28633-6', ' Polysomnography (sleep) study')
        sr.ConceptCodeSequence = self._create_code_sequence('DCM', '130868', ' Neurophysiology Post-hoc Review Annotations')

        # DCM 130868 Neurophysiology Post-hoc Review Annotations


        ref_proc_step = Dataset()
        ref_proc_step.ReferencedSOPClassUID = '1.2.840.10008.5.1.4.1.1.9.7.4'
        ref_proc_step.ReferencedSOPInstanceUID = uid.generate_uid()
        sr.ReferencedPerformedProcedureStepSequence = [ref_proc_step]


        sr.ContentSequence = self.getEvents(events)

        # Save SR document
        sr_path = os.path.join(self.getFilePath(recordName), f"{self.getSubjectId()}_{self.getSessionId()}_annotations.sr.dcm")
        sr.save_as(sr_path, write_like_original=False)
        return sr_path

    def _create_code_sequence(self, scheme_designator, code_value, code_meaning):
        seq = Dataset()
        seq.CodeValue = code_value
        seq.CodingSchemeDesignator = scheme_designator 
        seq.CodeMeaning = code_meaning
        return [seq]
    
    def getEvents(self, events):
        
        items = [self.create_event(e["name"], e["start"], e["duration"], i) for i, e in enumerate(events)]
        items = [item for item in items if item is not None]

        return items
    
    def getEventCodeSequence(self, name):
        cid_mapping = {
            'sleepStage': {
                'W': ('MDC', '2:23672', 'Sleep stage wake'),
                'N1': ('DCM', '130834', 'Sleep stage N1'), 
                'N2': ('DCM', '130835', 'Sleep stage N2'), 
                'N3': ('DCM', '130836', 'Sleep stage N3'), 
                # 'N1': ('MDC', '2:23696', 'Sleep stage N1'), 
                # 'N2': ('MDC', '2:23704', 'Sleep stage N2'),
                # 'N3': ('MDC', '2:23712', 'Sleep stage N3'),
                'R': ('MDC', '2:23680', '   ')
            },
            'apnea': {
                'resp_obstructiveapnea': ('MDC', '3:3072', 'Apnea (obstructive)'),
                'resp_centralapnea': ('MDC', '3:3072', 'Apnea (central)'),
                'resp_mixedapnea': ('MDC', '3:3072', 'Apnea (mixed)'),
                'resp_hypopnea': ('MDC', '3:3072', 'Hypopnea'),
                'resp_rera': ('LOINC', 'LP269357-2', 'Respiratory effort-related arousal'), # Non-standard - https://athena.ohdsi.org/search-terms/terms/37071272
                'resp_hypoventilation': ('LOINC', '68978004', 'Hypoventilation'), # SNOMED - https://athena.ohdsi.org/search-terms/terms/37071271
                'resp_cheynestokesbreath': ('LOINC', '309155007', 'Cheyne-Stokes respiration') # SNOMED - https://athena.ohdsi.org/search-terms/terms/37071273
            },
            'cardiac': {
                'sinus_tachycardia': ('MDC', '3:3262', 'Sinus tachycardia'), #SNOMED - https://athena.ohdsi.org/search-terms/terms/4140598
                'tachycardia_complex_wide': ('MDC', '3:3262', 'Tachycardia, complex, wide QRS'), # non-standard - https://athena.ohdsi.org/search-terms/terms/3357809
                'tachycardia_complex_narrow': ('LOINC', '251157009', 'Tachycardia, complex, narrow QRS'), # non-standard - https://athena.ohdsi.org/search-terms/terms/3272969
                'bradycardia': ('MDC', '3:3084', 'Bradycardia'), # SNOMED - https://athena.ohdsi.org/search-terms/terms/4169095
                'asystole': ('MDC', '3:3076', 'Asystole'), # SNOMED - 
                'atrial_fibrillation': ('MDC', '3:3128', 'Atrial fibrillation'),
                'arrhythmias': ('LOINC', '4141820', 'Cardiac arrhythmia'), # https://athena.ohdsi.org/search-terms/terms/4141820
                'ectopic_beat': ('LOINC', '4064867', 'Ectopic beat'), # non-standard - https://athena.ohdsi.org/search-terms/terms/4064867
            },
            'arousal': {
                'arousal': ('MDC', '2:23800', 'Sleep arousal'),
                'arousal_rera':  ('MDC', '2:23800', 'Sleep arousal (RERA)'),
                'arousal_plm': ('MDC', '2:23800', 'Sleep arousal (Periodic limb movement)'),
                'arousal_spontaneous': ('MDC', '2:23800', 'Sleep arousal (Spontaneous)'),
                'arousal_respiratory': ('MDC', '2:23800', 'Sleep arousal (Respiratory event)'),
            },
            'limb': {
                'LegMovement-Left': ('MDC', '2:24184', 'Periodic movements of sleep'),
                'LegMovement-Right': ('MDC', '2:24184', 'Periodic movements of sleep'),
                'LegMovement': ('MDC', '2:24184', 'Periodic movements of sleep'),
                #  Periodic movements of sleep with arousals
            },
            'light': {
                # MDC_EVT_LIGHTS_IN_ROOM_OFF
                'lightOff': ('MDC', 'MDC_EVT_LIGHTS_IN_ROOM_OFF', 'Lights off'),
                'lightOn': ('MDC', 'MDC_EVT_STAT_LIGHTS_IN_ROOM_ON', 'Lights on'),
            },
            'other': {
                'bruxism': ('LOINC', '90207007', 'Bruxism episode'), #https://athena.ohdsi.org/search-terms/terms/4234724
                'rhythmic_movement_disorder': ('LOINC', '3327571', 'Rhythmic movement disorder'), # SNOMED - https://athena.ohdsi.org/search-terms/terms/3327571
            }
        }
        psg_em = PSGEventManager()
        groups = psg_em.getEventGroupMap()
        event_type = groups[name]
        if event_type in cid_mapping and name in cid_mapping[event_type]:
            return cid_mapping[event_type][name]
        
        return None


    def create_event(self, name, start_time, duration, event_number):
        
        code_sequence = self.getEventCodeSequence(name)
        
        if code_sequence is not None:
            event_container = Dataset()
            event_container.ValueType = "CONTAINER"
            event_container.RelationshipType = "CONTAINS"
            
            event_container.ConceptNameCodeSequence = self._create_code_sequence(f"11110{event_number}", "DCM", f"Sleep Apnea Episode {event_number}")
            event_container.ConceptCodeSequence = self._create_code_sequence(f"11110{event_number}", "DCM", f"Sleep Apnea Episode {event_number}")
            event_container.ContentSequence = []

            # Event Type
            event = Dataset()
            event.ValueType = "CODE"
            event.ConceptNameCodeSequence = self._create_code_sequence(code_sequence[0], code_sequence[1], code_sequence[2])
            # event.ConceptCodeSequence = _create_code_sequence(code_sequence[0], code_sequence[1], code_sequence[2])
            event_container.ContentSequence.append(event)

            # Start Time
            start_time_ds = Dataset()
            start_time_ds.ValueType = "NUM"
            start_time_ds.ConceptNameCodeSequence = self._create_code_sequence("111400", "DCM", "Start of Event")
            start_time_ds.MeasuredValueSequence = [Dataset()]
            start_time_ds.MeasuredValueSequence[0].NumericValue = start_time
            start_time_ds.MeasuredValueSequence[0].MeasurementUnitsCodeSequence = [Dataset()]
            start_time_ds.MeasuredValueSequence[0].MeasurementUnitsCodeSequence = self._create_code_sequence("s", "UCUM", "Seconds")
            event_container.ContentSequence.append(start_time_ds)

            # Duration
            duration_ds = Dataset()
            # duration_ds.RelationshipType = "HAS_OBS_CONTEXT"
            duration_ds.ValueType = "NUM"
            duration_ds.ConceptNameCodeSequence = [Dataset()]
            duration_ds.ConceptNameCodeSequence = self._create_code_sequence( "DCM", "111401", "Duration")

            duration_ds.MeasuredValueSequence = [Dataset()]
            duration_ds.MeasuredValueSequence[0].NumericValue = duration
            duration_ds.MeasuredValueSequence[0].MeasurementUnitsCodeSequence = self._create_code_sequence("UCUM", "s", "Seconds")
            event_container.ContentSequence.append(duration_ds)

            # # Referenced Waveform
            # waveform_ref = Dataset()
            # waveform_ref.ValueType = "IMAGE"
            # waveform_ref.ConceptNameCodeSequence = [Dataset()]
            # waveform_ref.ConceptNameCodeSequence[0].CodeValue = "121020"
            # waveform_ref.ConceptNameCodeSequence[0].CodingSchemeDesignator = "DCM"
            # waveform_ref.ConceptNameCodeSequence[0].CodeMeaning = "Referenced Waveform"
            # waveform_ref.ReferencedSOPSequence = [Dataset()]
            # waveform_ref.ReferencedSOPSequence[0].ReferencedSOPClassUID = "1.2.840.10008.5.1.4.1.1.9.1"
            # waveform_ref.ReferencedSOPSequence[0].ReferencedSOPInstanceUID = sop_uid
            # event_container.ContentSequence.append(waveform_ref)
        else:
            return None
        
        return event_container
    
    # New methods for comprehensive sleep study SR functionality
    
    def _create_sr_container(self, code_value, coding_scheme, code_meaning):
        """Create a CONTAINER content item for SR"""
        container = Dataset()
        container.RelationshipType = "CONTAINS"
        container.ValueType = "CONTAINER"
        container.ConceptNameCodeSequence = self._create_code_sequence(coding_scheme, code_value, code_meaning)
        container.ContinuityOfContent = "CONTINUOUS"
        container.ContentSequence = []
        return container
    
    def _add_text_content(self, sequence, code_value, text_value):
        """Add a TEXT content item to a sequence"""
        text_ds = Dataset()
        text_ds.RelationshipType = "CONTAINS"
        text_ds.ValueType = "TEXT"
        text_ds.ConceptNameCodeSequence = self._create_code_sequence("99SLEEPLAB", code_value, code_value)
        text_ds.TextValue = text_value
        sequence.append(text_ds)
    
    def _add_num_content_sr(self, sequence, code_value, coding_scheme, concept_meaning, num_value, units=None):
        """Add a NUM content item to a sequence for SR"""
        num_ds = Dataset()
        num_ds.RelationshipType = "CONTAINS"
        num_ds.ValueType = "NUM"
        num_ds.ConceptNameCodeSequence = self._create_code_sequence(coding_scheme, code_value, concept_meaning)
        num_ds.MeasuredValueSequence = [Dataset()]
        num_ds.MeasuredValueSequence[0].NumericValue = str(num_value)
        
        if units:
            num_ds.MeasuredValueSequence[0].MeasurementUnitsCodeSequence = self._create_code_sequence("UCUM", units, units)
        
        sequence.append(num_ds)
    
    def _add_datetime_content(self, sequence, code_value, coding_scheme, concept_meaning, datetime_value):
        """Add a DATETIME content item to a sequence"""
        dt_ds = Dataset()
        dt_ds.RelationshipType = "CONTAINS"
        dt_ds.ValueType = "DATETIME"
        dt_ds.ConceptNameCodeSequence = self._create_code_sequence(coding_scheme, code_value, concept_meaning)
        dt_ds.DateTime = datetime_value.strftime('%Y%m%d%H%M%S')
        sequence.append(dt_ds)
    
    def _add_image_reference_sr(self, sequence, code_value, coding_scheme, code_meaning, referenced_sop_instance_uid):
        """Add an IMAGE content item that references another DICOM image"""
        img_ds = Dataset()
        img_ds.RelationshipType = "CONTAINS"
        img_ds.ValueType = "IMAGE"
        img_ds.ConceptNameCodeSequence = self._create_code_sequence(coding_scheme, code_value, code_meaning)
        
        img_ds.ReferencedSOPSequence = [Dataset()]
        img_ds.ReferencedSOPSequence[0].ReferencedSOPClassUID = "1.2.840.10008.5.1.4.1.1.7"  # Secondary Capture Image
        img_ds.ReferencedSOPSequence[0].ReferencedSOPInstanceUID = referenced_sop_instance_uid
        
        sequence.append(img_ds)
    
    def _calculate_sleep_metrics(self, events):
        """Calculate sleep architecture metrics from events"""
        sleep_stages = [e for e in events if any(stage in e['name'] for stage in ['W', 'N1', 'N2', 'N3', 'R'])]
        
        if not sleep_stages:
            return {}
        
        # Calculate basic metrics
        total_epochs = len(sleep_stages)
        epoch_duration = 30  # seconds
        total_time = total_epochs * epoch_duration / 60  # minutes
        
        stage_counts = {}
        for event in sleep_stages:
            stage = event['name']
            stage_counts[stage] = stage_counts.get(stage, 0) + 1
        
        # Calculate percentages and times
        metrics = {
            "Total Sleep Time": total_time,
            "Sleep Efficiency": ((total_time - stage_counts.get('W', 0) * 0.5) / total_time * 100) if total_time > 0 else 0,
            "Wake Percentage": (stage_counts.get('W', 0) / total_epochs * 100) if total_epochs > 0 else 0,
            "N1 Percentage": (stage_counts.get('N1', 0) / total_epochs * 100) if total_epochs > 0 else 0,
            "N2 Percentage": (stage_counts.get('N2', 0) / total_epochs * 100) if total_epochs > 0 else 0,
            "N3 Percentage": (stage_counts.get('N3', 0) / total_epochs * 100) if total_epochs > 0 else 0,
            "REM Percentage": (stage_counts.get('R', 0) / total_epochs * 100) if total_epochs > 0 else 0,
        }
        
        # Calculate REM latency (time to first REM)
        for i, event in enumerate(sleep_stages):
            if event['name'] == 'R':
                metrics["REM Latency"] = i * 0.5  # minutes
                break
        
        return metrics
    
    def _calculate_respiratory_metrics(self, resp_events, recording_duration_hours):
        """Calculate respiratory event metrics"""
        if not resp_events:
            return {}
        
        event_counts = {}
        for event in resp_events:
            event_type = event['name']
            event_counts[event_type] = event_counts.get(event_type, 0) + 1
        
        total_events = sum(event_counts.values())
        
        metrics = {
            "Apnea-Hypopnea Index": total_events / recording_duration_hours if recording_duration_hours > 0 else 0,
            "Total Respiratory Events": total_events,
        }
        
        # Add specific event indices
        for event_type, count in event_counts.items():
            metrics[f"{event_type} Index"] = count / recording_duration_hours if recording_duration_hours > 0 else 0
        
        return metrics
    
    def _calculate_movement_metrics(self, movement_events, recording_duration_hours):
        """Calculate movement event metrics"""
        if not movement_events:
            return {}
        
        total_movements = len(movement_events)
        
        return {
            "Periodic Limb Movement Index": total_movements / recording_duration_hours if recording_duration_hours > 0 else 0,
            "Total Limb Movements": total_movements,
        }
    
    def _calculate_arousal_metrics(self, arousal_events, recording_duration_hours):
        """Calculate arousal event metrics"""
        if not arousal_events:
            return {}
        
        total_arousals = len(arousal_events)
        
        return {
            "Arousal Index": total_arousals / recording_duration_hours if recording_duration_hours > 0 else 0,
            "Total Arousals": total_arousals,
        }
    
    def _get_metric_unit(self, metric_name):
        """Get appropriate unit for metric"""
        if "percentage" in metric_name.lower() or "%" in metric_name:
            return "%"
        elif "time" in metric_name.lower() or "latency" in metric_name.lower():
            return "min"
        elif "efficiency" in metric_name.lower():
            return "%"
        else:
            return ""
    
    def _create_hypnogram_dicom(self, events, duration_hours, recordName):
        """Create hypnogram as separate DICOM Secondary Capture"""
        try:
            # Extract sleep stages
            sleep_stages = [e for e in events if any(stage in e['name'] for stage in ['W', 'N1', 'N2', 'N3', 'R'])]
            
            if not sleep_stages:
                return None
            
            # Create hypnogram plot
            fig, ax = plt.subplots(figsize=(12, 6))
            
            # Map stages to numeric values for plotting
            stage_mapping = {'W': 0, 'N1': -1, 'N2': -2, 'N3': -3, 'R': -4}
            
            epochs = []
            values = []
            
            for i, event in enumerate(sleep_stages):
                epochs.append(i * 0.5 / 60)  # Convert to hours
                stage = event['name']
                values.append(stage_mapping.get(stage, 0))
            
            ax.step(epochs, values, where='post', linewidth=2)
            ax.set_yticks([0, -1, -2, -3, -4])
            ax.set_yticklabels(['Wake', 'N1', 'N2', 'N3', 'REM'])
            ax.set_xlabel('Time (hours)')
            ax.set_ylabel('Sleep Stage')
            ax.set_title(f'Hypnogram - {recordName}')
            ax.grid(True, alpha=0.3)
            ax.set_xlim(0, duration_hours)
            
            # Save to bytes
            buf = BytesIO()
            plt.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            img_data = buf.getvalue()
            plt.close()
            
            # Create DICOM Secondary Capture
            return self._save_image_as_dicom(img_data, f"{recordName}_hypnogram")
        except Exception as e:
            self.log(f"Error creating hypnogram: {str(e)}")
            return None
    
    def _save_image_as_dicom(self, img_data, filename):
        """Save image data as DICOM Secondary Capture"""
        try:
            from PIL import Image
            
            file_meta = FileMetaDataset()
            file_meta.MediaStorageSOPClassUID = '1.2.840.10008.5.1.4.1.1.7'
            sop_instance_uid = uid.generate_uid()
            file_meta.MediaStorageSOPInstanceUID = sop_instance_uid
            file_meta.TransferSyntaxUID = uid.ExplicitVRLittleEndian
            
            ds = FileDataset(f"{filename}.dcm", {}, file_meta=file_meta, preamble=b"\0" * 128)
            ds.is_little_endian = True
            ds.is_implicit_VR = False
            
            # Basic DICOM attributes
            ds.SOPClassUID = '1.2.840.10008.5.1.4.1.1.7'
            ds.SOPInstanceUID = sop_instance_uid
            ds.StudyInstanceUID = self.study_instance_uid
            ds.SeriesInstanceUID = uid.generate_uid()
            ds.Modality = "OT"
            ds.ConversionType = "WSD"
            
            # Convert image
            img = Image.open(BytesIO(img_data))
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            width, height = img.size
            ds.Rows = height
            ds.Columns = width
            ds.SamplesPerPixel = 3
            ds.PhotometricInterpretation = "RGB"
            ds.BitsAllocated = 8
            ds.BitsStored = 8
            ds.HighBit = 7
            ds.PixelRepresentation = 0
            ds.PlanarConfiguration = 0
            ds.PixelData = img.tobytes()
            
            # Save
            output_path = os.path.join(self.getFilePath(""), f"{filename}.dcm")
            ds.save_as(output_path, write_like_original=False)
            return sop_instance_uid
        except Exception as e:
            self.log(f"Error saving image as DICOM: {str(e)}")
            return None
    
    def _group_events_by_type(self, events):
        """Group events by type for structured annotation"""
        groups = {
            "Sleep Stages": [],
            "Respiratory Events": [],
            "Movement Events": [],
            "Arousal Events": [],
            "Other Events": []
        }
        
        for event in events:
            name = event['name'].lower()
            if any(stage in name for stage in ['w', 'n1', 'n2', 'n3', 'r', 'rem']):
                groups["Sleep Stages"].append(event)
            elif any(resp in name for resp in ['apnea', 'hypopnea', 'resp_']):
                groups["Respiratory Events"].append(event)
            elif any(move in name for move in ['movement', 'limb']):
                groups["Movement Events"].append(event)
            elif 'arousal' in name:
                groups["Arousal Events"].append(event)
            else:
                groups["Other Events"].append(event)
        
        # Remove empty groups
        return {k: v for k, v in groups.items() if v}
    
    def _create_event_annotation(self, event, index):
        """Create structured annotation for individual event according to Supplement 239"""
        event_container = Dataset()
        event_container.ValueType = "CONTAINER"
        event_container.RelationshipType = "CONTAINS"
        event_container.ConceptNameCodeSequence = self._create_code_sequence("DCM", f"121100{index}", f"Event {index + 1}")
        event_container.ContentSequence = []
        
        # Event type
        event_type = Dataset()
        event_type.ValueType = "CODE"
        event_type.RelationshipType = "CONTAINS"
        event_type.ConceptNameCodeSequence = self._create_code_sequence("DCM", "121101", "Event Type")
        
        # Map event to standard codes
        code_info = self._get_event_code_sr(event['name'])
        if code_info:
            event_type.ConceptCodeSequence = self._create_code_sequence(code_info[1], code_info[0], code_info[2])
            event_container.ContentSequence.append(event_type)
        
        # Start time
        start_time = Dataset()
        start_time.ValueType = "NUM"
        start_time.RelationshipType = "CONTAINS"
        start_time.ConceptNameCodeSequence = self._create_code_sequence("DCM", "121102", "Event Start Time")
        start_time.MeasuredValueSequence = [Dataset()]
        start_time.MeasuredValueSequence[0].NumericValue = str(event['start'])
        start_time.MeasuredValueSequence[0].MeasurementUnitsCodeSequence = self._create_code_sequence("UCUM", "s", "seconds")
        event_container.ContentSequence.append(start_time)
        
        # Duration
        if event.get('duration', 0) > 0:
            duration = Dataset()
            duration.ValueType = "NUM"
            duration.RelationshipType = "CONTAINS"
            duration.ConceptNameCodeSequence = self._create_code_sequence("DCM", "121103", "Event Duration")
            duration.MeasuredValueSequence = [Dataset()]
            duration.MeasuredValueSequence[0].NumericValue = str(event['duration'])
            duration.MeasuredValueSequence[0].MeasurementUnitsCodeSequence = self._create_code_sequence("UCUM", "s", "seconds")
            event_container.ContentSequence.append(duration)
        
        return event_container
    
    def _get_event_code_sr(self, event_name):
        """Get standardized DICOM codes for events in SR format"""
        event_codes = {
            'W': ('130834', 'DCM', 'Sleep stage wake'),
            'N1': ('130835', 'DCM', 'Sleep stage N1'),
            'N2': ('130836', 'DCM', 'Sleep stage N2'),
            'N3': ('130837', 'DCM', 'Sleep stage N3'),
            'R': ('130838', 'DCM', 'Sleep stage REM'),
            'resp_obstructiveapnea': ('130839', 'DCM', 'Obstructive apnea'),
            'resp_centralapnea': ('130840', 'DCM', 'Central apnea'),
            'resp_mixedapnea': ('130841', 'DCM', 'Mixed apnea'),
            'resp_hypopnea': ('130842', 'DCM', 'Hypopnea'),
            'arousal': ('130843', 'DCM', 'Arousal'),
            # Custom MDC codes for light events
            'lightOn': ('LIGHT_ON', 'MDC_EVT_STAT_LIGHTS_IN_ROOM_ON', 'Lights on'),
            'lightOff': ('LIGHT_OFF', 'MDC_EVT_STAT_LIGHTS_IN_ROOM_OFF', 'Lights off'),
        }
        
        return event_codes.get(event_name)
    
    def _generate_interpretation(self, sleep_metrics, resp_events, movement_events, arousal_events):
        """Generate clinical interpretation summary"""
        interpretation = []
        
        # Sleep efficiency assessment
        sleep_eff = sleep_metrics.get("Sleep Efficiency", 0)
        if sleep_eff >= 85:
            interpretation.append("Normal sleep efficiency.")
        elif sleep_eff >= 75:
            interpretation.append("Mildly reduced sleep efficiency.")
        else:
            interpretation.append("Significantly reduced sleep efficiency.")
        
        # Respiratory assessment
        if resp_events:
            ahi = len(resp_events) / (sleep_metrics.get("Total Sleep Time", 60) / 60)  # events per hour
            if ahi < 5:
                interpretation.append("No significant sleep-disordered breathing.")
            elif ahi < 15:
                interpretation.append("Mild sleep-disordered breathing.")
            elif ahi < 30:
                interpretation.append("Moderate sleep-disordered breathing.")
            else:
                interpretation.append("Severe sleep-disordered breathing.")
        
        # Movement assessment
        if movement_events:
            plmi = len(movement_events) / (sleep_metrics.get("Total Sleep Time", 60) / 60)
            if plmi > 15:
                interpretation.append("Clinically significant periodic limb movements.")
        
        return " ".join(interpretation) if interpretation else "Study completed without significant abnormalities."
    
    def _create_comprehensive_sleep_sr(self, recordName, events, psgSignal):
        """Create comprehensive sleep study SR with hypnogram and detailed metrics"""
        # Create file meta information for SR
        file_meta = FileMetaDataset()
        file_meta.MediaStorageSOPClassUID = '1.2.840.10008.5.1.4.1.1.88.22'  # Enhanced SR
        file_meta.MediaStorageSOPInstanceUID = uid.generate_uid()
        file_meta.TransferSyntaxUID = uid.ExplicitVRLittleEndian
        file_meta.ImplementationClassUID = uid.generate_uid()
        
        # Create the SR dataset
        filename = f"{recordName}_sleep_report.dcm"
        ds = FileDataset(filename, {}, file_meta=file_meta, preamble=b"\0" * 128)
        
        # Set encoding
        ds.is_little_endian = True
        ds.is_implicit_VR = False
        
        # Patient IE
        ds.PatientName = self.metaData.get("patientName", self.metaData.get("patient", "UNKNOWN"))
        ds.PatientID = self.metaData.get("patientCode", "UNKNOWN")
        ds.PatientBirthDate = self.metaData.get("birthdate", "")
        ds.PatientSex = self.metaData.get("sex", "O")
        
        # Study IE
        study_date = self.metaData["start"] if "start" in self.metaData else datetime.now()
        ds.StudyDate = study_date.strftime('%Y%m%d')
        ds.StudyTime = study_date.strftime('%H%M%S')
        ds.AccessionNumber = f"PSG-{recordName}"
        ds.ReferringPhysicianName = "SLEEP^PHYSICIAN"
        ds.StudyInstanceUID = self.study_instance_uid
        ds.StudyID = recordName
        ds.StudyDescription = "Polysomnography Sleep Study"
        
        # Series IE
        ds.Modality = "SR"
        ds.SeriesInstanceUID = uid.generate_uid()
        ds.SeriesNumber = "100"
        ds.SeriesDescription = "Sleep Study Structured Report"
        
        # Equipment IE
        ds.Manufacturer = "SleepHarmonizer"
        ds.InstitutionName = "Sleep Research Center"
        ds.SoftwareVersions = "1.0"
        
        # SOP Common Module
        ds.SOPClassUID = '1.2.840.10008.5.1.4.1.1.88.22'  # Enhanced SR
        ds.SOPInstanceUID = file_meta.MediaStorageSOPInstanceUID
        ds.InstanceNumber = "1"
        ds.ContentDate = ds.StudyDate
        ds.ContentTime = ds.StudyTime
        
        # SR Document General Module
        ds.CompletionFlag = "COMPLETE"
        ds.VerificationFlag = "UNVERIFIED"
        
        # Performed Procedure Code Sequence (Supplement 239 requirement)
        pcs = Dataset()
        pcs.CodeValue = "433188007"
        pcs.CodingSchemeDesignator = "SCT"  # SNOMED CT
        pcs.CodeMeaning = "Polysomnography"
        ds.PerformedProcedureCodeSequence = [pcs]
        
        # SR Document Content Module - Root CONTAINER
        ds.ValueType = "CONTAINER"
        ds.ConceptNameCodeSequence = self._create_code_sequence("SCT", "433188007", "Polysomnography Study Report")
        ds.ContinuityOfContent = "SEPARATE"
        
        # Build the content tree
        content_seq = []
        
        # Add title and identification
        self._add_text_content(content_seq, "TITLE", f"Sleep Study Report - {recordName}")
        self._add_text_content(content_seq, "PATIENT_ID", f"Patient: {ds.PatientID}")
        
        # Add study timing information
        timing_container = self._create_sr_container("121049", "DCM", "Study Timing")
        recording_start = self.metaData.get("start", datetime.now())
        recording_duration = len(psgSignal.signals[0].signal) / psgSignal.signals[0].frequency / 3600  # hours
        
        self._add_datetime_content(timing_container.ContentSequence, "121050", "DCM", "Recording Start Time", recording_start)
        self._add_num_content_sr(timing_container.ContentSequence, "121051", "DCM", "Recording Duration", recording_duration, "h")
        content_seq.append(timing_container)
        
        # Add sleep architecture metrics
        sleep_metrics = self._calculate_sleep_metrics(events)
        sleep_container = self._create_sr_container("121052", "DCM", "Sleep Architecture")
        
        for metric_name, value in sleep_metrics.items():
            unit = self._get_metric_unit(metric_name)
            self._add_num_content_sr(sleep_container.ContentSequence, "121053", "DCM", metric_name, value, unit)
        
        content_seq.append(sleep_container)
        
        # Add respiratory events
        resp_events = [e for e in events if 'resp_' in e['name'] or 'apnea' in e['name'].lower()]
        if resp_events:
            resp_container = self._create_sr_container("121054", "DCM", "Respiratory Events")
            resp_metrics = self._calculate_respiratory_metrics(resp_events, recording_duration)
            
            for metric_name, value in resp_metrics.items():
                unit = "events/h" if "index" in metric_name.lower() else "count"
                self._add_num_content_sr(resp_container.ContentSequence, "121055", "DCM", metric_name, value, unit)
            
            content_seq.append(resp_container)
        
        # Add movement events
        movement_events = [e for e in events if 'movement' in e['name'].lower() or 'limb' in e['name'].lower()]
        if movement_events:
            movement_container = self._create_sr_container("121056", "DCM", "Movement Events")
            movement_metrics = self._calculate_movement_metrics(movement_events, recording_duration)
            
            for metric_name, value in movement_metrics.items():
                unit = "events/h"
                self._add_num_content_sr(movement_container.ContentSequence, "121057", "DCM", metric_name, value, unit)
            
            content_seq.append(movement_container)
        
        # Add arousal events
        arousal_events = [e for e in events if 'arousal' in e['name'].lower()]
        if arousal_events:
            arousal_container = self._create_sr_container("121058", "DCM", "Arousal Events")
            arousal_metrics = self._calculate_arousal_metrics(arousal_events, recording_duration)
            
            for metric_name, value in arousal_metrics.items():
                unit = "events/h"
                self._add_num_content_sr(arousal_container.ContentSequence, "121059", "DCM", metric_name, value, unit)
            
            content_seq.append(arousal_container)
        
        # Create and reference hypnogram
        hypnogram_uid = self._create_hypnogram_dicom(events, recording_duration, recordName)
        if hypnogram_uid:
            hypno_container = self._create_sr_container("121060", "DCM", "Sleep Stage Visualization")
            self._add_image_reference_sr(hypno_container.ContentSequence, "121061", "DCM", "Hypnogram", hypnogram_uid)
            content_seq.append(hypno_container)
        
        # Add waveform annotations according to Supplement 239
        if events:
            annotations_container = self._create_sr_container("130868", "DCM", "Neurophysiology Post-hoc Review Annotations")
            
            # Group events by type for better organization
            event_groups = self._group_events_by_type(events)
            
            for group_name, group_events in event_groups.items():
                group_container = self._create_sr_container("130869", "DCM", f"{group_name} Annotations")
                
                for i, event in enumerate(group_events):
                    event_item = self._create_event_annotation(event, i)
                    if event_item:
                        group_container.ContentSequence.append(event_item)
                
                if group_container.ContentSequence:
                    annotations_container.ContentSequence.append(group_container)
            
            content_seq.append(annotations_container)
        
        # Add interpretation summary
        interpretation_container = self._create_sr_container("121062", "DCM", "Study Interpretation")
        interpretation_text = self._generate_interpretation(sleep_metrics, resp_events, movement_events, arousal_events)
        self._add_text_content(interpretation_container.ContentSequence, "121063", interpretation_text)
        content_seq.append(interpretation_container)
        
        # Set the content sequence
        ds.ContentSequence = content_seq
        
        # Save comprehensive SR document
        sr_path = os.path.join(self.getFilePath(recordName), f"{self.getSubjectId()}_{self.getSessionId()}_comprehensive_sleep_report.sr.dcm")
        ds.save_as(sr_path, write_like_original=False)
        return sr_path