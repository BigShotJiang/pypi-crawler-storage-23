#!/usr/bin/env python3
"""
NAME
    https_token_roles_ws – test /ws WebSocket over HTTPS with token and roles

SYNOPSIS
    python -m mcp_proxy_adapter.examples.ws_examples.https_token_roles_ws [--port PORT] [--token TOKEN]

DESCRIPTION
    Connects to the server's /ws endpoint over HTTPS (wss://host:port/ws) with
    API key and roles. /ws is public; token is sent for identity and role-based
    subscribe checks.

    Use when the server uses full_application/configs/https_token_roles.json
    (protocol https, token + roles).

PROTOCOL
    HTTPS. WebSocket URL: wss://localhost:PORT/ws.

SECURITY
    Server TLS + token + roles. Default token: admin-secret-key-https.

OPTIONS
    --host   Server host (default: localhost).
    --port   Server port (default: 8443).
    --token  API key (default: admin-secret-key-https).

EXIT STATUS
    0 on success, 1 on failure.

EXAMPLES
    python -m mcp_proxy_adapter.examples.ws_examples.https_token_roles_ws --port 8443

SEE ALSO
    ws_example_runner.py, https_token_ws.py, mtls_roles_ws.py,
    full_application/configs/https_token_roles.json

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.examples.ws_examples.ws_example_runner import run_ws_example_sync


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Test /ws over HTTPS with token and roles"
    )
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8443)
    parser.add_argument("--token", default="admin-secret-key-https")
    args = parser.parse_args()
    return run_ws_example_sync(
        "https",
        host=args.host,
        port=args.port,
        token=args.token,
    )


if __name__ == "__main__":
    sys.exit(main())
