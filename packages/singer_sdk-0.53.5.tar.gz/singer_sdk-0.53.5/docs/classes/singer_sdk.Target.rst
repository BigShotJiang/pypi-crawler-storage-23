﻿singer_sdk.Target
=================

.. currentmodule:: singer_sdk

.. autoclass:: Target
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__