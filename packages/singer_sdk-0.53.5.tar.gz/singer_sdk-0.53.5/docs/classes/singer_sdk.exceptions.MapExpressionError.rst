﻿singer_sdk.exceptions.MapExpressionError
========================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: MapExpressionError
    :members:
    :special-members: __init__, __call__