﻿singer_sdk.RESTStream
=====================

.. currentmodule:: singer_sdk

.. autoclass:: RESTStream
    :members:
    :show-inheritance:
    :inherited-members: Stream
    :special-members: __init__