﻿singer_sdk.sql.SQLStream
========================

.. currentmodule:: singer_sdk.sql

.. autoclass:: SQLStream
    :members:
    :show-inheritance:
    :inherited-members: Stream
    :special-members: __init__