﻿singer_sdk.sql.SQLConnector
===========================

.. currentmodule:: singer_sdk.sql

.. autoclass:: SQLConnector
    :members:
    :special-members: __init__, __call__