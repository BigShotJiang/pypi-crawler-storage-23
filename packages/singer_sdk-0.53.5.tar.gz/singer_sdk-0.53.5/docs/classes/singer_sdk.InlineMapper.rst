﻿singer_sdk.InlineMapper
=======================

.. currentmodule:: singer_sdk

.. autoclass:: InlineMapper
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__