﻿singer_sdk.typing.RegexType
===========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: RegexType
    :members:
    :special-members: __init__, __call__