﻿singer_sdk.typing.TimeType
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: TimeType
    :members:
    :special-members: __init__, __call__