﻿singer_sdk.typing.DiscriminatedUnion
====================================

.. currentmodule:: singer_sdk.typing

.. autoclass:: DiscriminatedUnion
    :members:
    :special-members: __init__, __call__