﻿singer_sdk.typing.ArrayType
===========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: ArrayType
    :members:
    :special-members: __init__, __call__