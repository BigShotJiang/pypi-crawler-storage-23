﻿singer_sdk.typing.JSONPointerType
=================================

.. currentmodule:: singer_sdk.typing

.. autoclass:: JSONPointerType
    :members:
    :special-members: __init__, __call__