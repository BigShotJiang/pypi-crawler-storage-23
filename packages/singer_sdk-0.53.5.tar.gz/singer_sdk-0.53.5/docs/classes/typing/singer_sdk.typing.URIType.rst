﻿singer_sdk.typing.URIType
=========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: URIType
    :members:
    :special-members: __init__, __call__