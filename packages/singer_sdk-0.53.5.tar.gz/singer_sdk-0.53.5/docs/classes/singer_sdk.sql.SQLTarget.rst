﻿singer_sdk.sql.SQLTarget
========================

.. currentmodule:: singer_sdk.sql

.. autoclass:: SQLTarget
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__