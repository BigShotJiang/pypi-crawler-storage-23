﻿singer_sdk.GraphQLStream
========================

.. currentmodule:: singer_sdk

.. autoclass:: GraphQLStream
    :members:
    :show-inheritance:
    :inherited-members: Stream
    :special-members: __init__