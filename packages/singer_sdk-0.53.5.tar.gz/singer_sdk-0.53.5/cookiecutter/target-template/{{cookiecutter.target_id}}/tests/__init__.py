"""Test suite for {{ cookiecutter.target_id }}."""
