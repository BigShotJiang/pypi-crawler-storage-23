"""Tap for {{ cookiecutter.source_name }}."""
