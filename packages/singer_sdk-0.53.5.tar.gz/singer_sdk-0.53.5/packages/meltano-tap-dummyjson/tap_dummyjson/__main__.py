"""DummyJSON entry point."""

from __future__ import annotations

from tap_dummyjson.tap import TapDummyJSON

TapDummyJSON.cli()
