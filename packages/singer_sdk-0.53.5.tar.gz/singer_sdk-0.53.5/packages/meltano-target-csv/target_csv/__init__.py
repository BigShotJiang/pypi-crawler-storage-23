"""Module test for target-csv functionality."""

from __future__ import annotations
