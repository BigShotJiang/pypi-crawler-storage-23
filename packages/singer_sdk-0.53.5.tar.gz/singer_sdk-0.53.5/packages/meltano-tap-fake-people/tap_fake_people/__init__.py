"""Tap for fake people."""
