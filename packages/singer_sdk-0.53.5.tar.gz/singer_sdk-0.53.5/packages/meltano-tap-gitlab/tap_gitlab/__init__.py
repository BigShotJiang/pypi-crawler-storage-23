"""Gitlab API Sample."""

from __future__ import annotations
