from .di import di

__all__ = ['di']
