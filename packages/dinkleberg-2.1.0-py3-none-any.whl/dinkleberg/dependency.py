class Dependency:
    def __init__(self, **kwargs):
        self._kwargs = kwargs
