"""
Optional helper functions for easier profiling usage.

The primary API is get_ctx().profiler().section(); these helpers are optional sugar
that delegate to that API and do not change semantics.
"""

from functools import wraps
from typing import Callable, TypeVar

from reactor_runtime.profiling.profiler import CudaTimingMode

try:
    from reactor_runtime import get_ctx
except ImportError:
    get_ctx = None

T = TypeVar("T")


def profile_fn(
    section_name: str, cuda_timing: CudaTimingMode = CudaTimingMode.NONE
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Optional decorator that profiles a function via get_ctx().profiler().section().

    Does not change profiler semantics. Use get_ctx().profiler().section() as the
    primary API; this is a thin convenience wrapper.
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            if get_ctx is None:
                return func(*args, **kwargs)
            try:
                ctx = get_ctx()
                with ctx.profiler().section(section_name, cuda_timing=cuda_timing):
                    return func(*args, **kwargs)
            except RuntimeError:
                return func(*args, **kwargs)

        return wrapper

    return decorator
