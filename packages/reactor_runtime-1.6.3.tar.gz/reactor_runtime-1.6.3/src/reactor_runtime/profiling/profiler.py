"""
Profiler implementation for measuring code section durations.

Provides a context manager-based API for profiling nested code sections:

    with get_ctx().profiler().section("inference"):
        with get_ctx().profiler().section("preprocess"):
            ...
        with get_ctx().profiler().section("model_forward"):
            ...

Supports three CUDA timing modes for GPU operations:
- NONE: CPU timing only (time.perf_counter)
- EVENT: CUDA events for single-stream GPU work (deferred sync)
- SYNC: Full device sync for multi-stream GPU work (immediate sync)
"""

from __future__ import annotations

import threading
import time
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

# Optional torch import for CUDA timing
try:
    import torch

    TORCH_AVAILABLE = True
except ImportError:
    torch = None  # type: ignore[assignment]
    TORCH_AVAILABLE = False

from reactor_runtime.utils.log import get_logger

if TYPE_CHECKING:
    from reactor_runtime.profiling.backends.base import ProfilerBackend

logger = get_logger(__name__)


class CudaTimingMode(Enum):
    """CUDA timing mode for ProfilerSection.

    Attributes:
        NONE: CPU timing only using time.perf_counter(). Use for CPU-bound
            operations where no GPU synchronization is needed.
        EVENT: CUDA events for single-stream GPU work. Events are recorded
            at section boundaries and timing is computed at flush time.
            Most efficient for single-stream GPU operations.
        SYNC: Full device synchronization at section boundaries. Use for
            multi-stream GPU work where accurate wall-clock time is needed.
    """

    NONE = "none"
    EVENT = "event"
    SYNC = "sync"


class ProfilerSection:
    """
    Context manager that measures the duration of a code section.

    Supports three timing modes:
    - NONE: CPU timing with time.perf_counter() (default)
    - EVENT: CUDA events for single-stream GPU work (deferred sync)
    - SYNC: Full synchronization for multi-stream GPU work (immediate sync)

    Used via Profiler.section() - not instantiated directly.
    """

    def __init__(
        self,
        key: str,
        profiler: Profiler,
        cuda_timing: CudaTimingMode = CudaTimingMode.NONE,
    ) -> None:
        """
        Initialize a profiler section.

        Args:
            key: The section key/name (e.g., "vae_decode").
            profiler: The parent Profiler instance.
            cuda_timing: Timing mode for CUDA operations.
                - NONE: CPU timing only (default)
                - EVENT: CUDA events for single-stream work
                - SYNC: Full sync for multi-stream work
        """
        self._key = key
        self._profiler = profiler
        self._cuda_timing = cuda_timing
        self._start_time: Optional[float] = None
        self._start_event: Optional[Any] = None  # torch.cuda.Event
        self._end_event: Optional[Any] = None  # torch.cuda.Event
        self._device: Optional[int] = None
        self._stack: Optional[List[str]] = None

    def __enter__(self) -> ProfilerSection:
        """Enter the profiled section - push to stack and record start time/event."""
        # Capture stack reference for path computation
        self._stack = self._profiler._get_stack()

        # Set up timing BEFORE modifying stack to avoid corruption if CUDA fails
        if self._cuda_timing == CudaTimingMode.EVENT:
            if TORCH_AVAILABLE and torch.cuda.is_available():
                try:
                    self._device = torch.cuda.current_device()
                    self._start_event = torch.cuda.Event(enable_timing=True)
                    self._end_event = torch.cuda.Event(enable_timing=True)
                    self._start_event.record()
                except RuntimeError:
                    # Fallback to CPU timing on CUDA errors
                    self._device = None
                    self._start_event = None
                    self._end_event = None
                    self._start_time = time.perf_counter()
            else:
                # Fallback to CPU timing if CUDA unavailable
                self._start_time = time.perf_counter()

        elif self._cuda_timing == CudaTimingMode.SYNC:
            if TORCH_AVAILABLE and torch.cuda.is_available():
                try:
                    self._device = torch.cuda.current_device()
                    torch.cuda.synchronize(self._device)  # Wait for prior work
                    self._start_time = time.perf_counter()
                except RuntimeError:
                    # Fallback to CPU timing on CUDA errors
                    self._device = None
                    self._start_time = time.perf_counter()
            else:
                # Fallback to CPU timing if CUDA unavailable
                self._start_time = time.perf_counter()

        else:  # CudaTimingMode.NONE
            self._start_time = time.perf_counter()

        # Only push to stack after timing setup succeeds
        self._stack.append(self._key)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit the profiled section - record duration and pop from stack."""
        if self._stack is None:
            return

        try:
            # Capture paths while stack is still correct
            parent_path = "/".join(self._stack[:-1]) if len(self._stack) > 1 else ""
            full_path = "/".join(self._stack)

            if (
                self._cuda_timing == CudaTimingMode.EVENT
                and self._start_event is not None
                and self._end_event is not None
                and self._device is not None
            ):
                # Deferred: record end event, compute duration at flush
                self._end_event.record()
                self._profiler._defer_cuda_measurement(
                    self._key,
                    parent_path,
                    full_path,
                    self._start_event,
                    self._end_event,
                    self._device,
                )

            elif (
                self._cuda_timing == CudaTimingMode.SYNC
                and self._device is not None
                and self._start_time is not None
            ):
                # Immediate: sync all streams, measure wall-clock time
                torch.cuda.synchronize(self._device)
                duration = time.perf_counter() - self._start_time
                self._profiler._record(self._key, parent_path, full_path, duration)

            elif self._start_time is not None:
                # CPU timing (NONE mode or fallback)
                duration = time.perf_counter() - self._start_time
                self._profiler._record(self._key, parent_path, full_path, duration)

        finally:
            # Always pop from stack, even if recording failed
            self._stack.pop()


class Profiler:
    """
    Profiler for measuring code section durations.

    Supports nested sections via a thread-local stack and multiple CUDA timing
    modes for GPU operations. Each measurement records:
    - section_key: The user-provided key (e.g., "vae_decode")
    - parent_path: Path of parent sections (e.g., "inference/diffusion")
    - full_path: Complete path including self (e.g., "inference/diffusion/vae_decode")

    Limitations:
        Multi-GPU is NOT supported. This profiler only handles single-GPU scenarios:
        - Single stream on one GPU (use EVENT mode)
        - Multiple streams on one GPU (use SYNC mode)

        Multi-GPU scenarios (DataParallel, DistributedDataParallel, pipeline/tensor
        parallelism) are out of scope and will produce inaccurate results.

    CUDA Timing Mode Selection:
        - NONE: Use for CPU-bound operations (no GPU involved)
        - EVENT: Use for single-stream GPU work (most inference). Efficient with
          minimal overhead (~1%), defers synchronization until flush.
        - SYNC: Use for multi-stream GPU work (pipelining, overlapping IO/compute).
          Higher overhead (~5-20%) but captures parallel work accurately.

    Usage:
        profiler = Profiler(backend)

        with profiler.section("outer"):
            with profiler.section("inner"):
                # This records "inner" with parent_path="outer"
                pass

        # For GPU operations:
        with profiler.section("model_forward", cuda_timing=CudaTimingMode.EVENT):
            output = model(input)
    """

    def __init__(self, backend: ProfilerBackend) -> None:
        """
        Initialize the profiler.

        Args:
            backend: The backend to use for recording measurements.
        """
        self._backend = backend
        self._local = threading.local()
        self._pending_cuda: List[Tuple[str, str, str, Any, Any, int]] = []
        self._cuda_lock = threading.Lock()

    def _get_stack(self) -> List[str]:
        """Get the thread-local section stack, creating if needed."""
        if not hasattr(self._local, "stack"):
            self._local.stack = []
        return self._local.stack

    def _push_section(self, key: str) -> None:
        """Push a section key onto the stack."""
        self._get_stack().append(key)

    def _pop_section(self) -> Optional[str]:
        """Pop a section key from the stack."""
        stack = self._get_stack()
        if stack:
            return stack.pop()
        return None

    def _get_parent_path(self) -> str:
        """Get the parent path (all sections except the current one)."""
        stack = self._get_stack()
        if len(stack) <= 1:
            return ""
        return "/".join(stack[:-1])

    def _get_current_path(self) -> str:
        """Get the full current path including the current section."""
        stack = self._get_stack()
        return "/".join(stack) if stack else ""

    def _record(
        self, key: str, parent_path: str, full_path: str, duration: float
    ) -> None:
        try:
            """Record a timing measurement to the backend."""
            self._backend.record(key, parent_path, full_path, duration)
        except Exception as e:
            logger.warning("Failed to record timing measurement", error=e)

    def _defer_cuda_measurement(
        self,
        key: str,
        parent_path: str,
        full_path: str,
        start_event: Any,
        end_event: Any,
        device: int,
    ) -> None:
        """Store CUDA events for deferred timing computation.

        Args:
            key: The section key/name.
            parent_path: Path of parent sections.
            full_path: Complete path including this section.
            start_event: CUDA event recorded at section entry.
            end_event: CUDA event recorded at section exit.
            device: CUDA device ID where events were recorded.
        """
        with self._cuda_lock:
            self._pending_cuda.append(
                (key, parent_path, full_path, start_event, end_event, device)
            )

    def _flush_cuda_measurements(self) -> None:
        """Synchronize and read all pending CUDA event timings.

        Groups events by device for efficient synchronization, syncs each
        device once, then reads all its event timings.
        """
        with self._cuda_lock:
            if not self._pending_cuda:
                return

            if not TORCH_AVAILABLE:
                logger.warning(
                    "CUDA measurements pending but torch not available, discarding"
                )
                self._pending_cuda.clear()
                return

            # Group by device for efficient synchronization
            by_device: Dict[int, List[Tuple[str, str, str, Any, Any, int]]] = {}
            for item in self._pending_cuda:
                device = item[5]
                if device not in by_device:
                    by_device[device] = []
                by_device[device].append(item)

            # Sync each device once, then read all its events
            for device, items in by_device.items():
                try:
                    torch.cuda.synchronize(device)
                except RuntimeError as e:
                    logger.warning(
                        "Failed to synchronize CUDA device, skipping measurements",
                        device=device,
                        count=len(items),
                        error=e,
                    )
                    continue

                for key, parent_path, full_path, start_evt, end_evt, _ in items:
                    try:
                        duration_ms = start_evt.elapsed_time(end_evt)
                        duration_sec = duration_ms / 1000.0
                        self._backend.record(key, parent_path, full_path, duration_sec)
                    except RuntimeError as e:
                        logger.warning(
                            "Failed to read CUDA event timing",
                            full_path=full_path,
                            error=e,
                        )

            self._pending_cuda.clear()

    def section(
        self,
        key: str,
        cuda_timing: CudaTimingMode = CudaTimingMode.NONE,
    ) -> ProfilerSection:
        """
        Create a context manager for profiling a code section.

        Args:
            key: The section key/name (e.g., "vae_decode", "inference").
            cuda_timing: Timing mode for CUDA operations.
                - NONE: CPU timing only (default)
                - EVENT: CUDA events for single-stream work (efficient)
                - SYNC: Full sync for multi-stream work (accurate)

        Returns:
            A ProfilerSection context manager.

        Example:
            # CPU-only work
            with profiler.section("json_parsing"):
                data = json.loads(response)

            # Single-stream GPU work (efficient)
            with profiler.section("model_forward", cuda_timing=CudaTimingMode.EVENT):
                output = model(input)

            # Multi-stream GPU work (accurate wall-clock time)
            with profiler.section("pipeline", cuda_timing=CudaTimingMode.SYNC):
                with torch.cuda.stream(stream1):
                    result1 = op1(data)
                with torch.cuda.stream(stream2):
                    result2 = op2(data)
        """
        return ProfilerSection(key, self, cuda_timing)

    def flush(self, output_path=None) -> None:
        """
        Flush any accumulated profiling data.

        This includes flushing any pending CUDA event measurements before
        flushing to the backend.

        Args:
            output_path: Optional path to write output to. Backend-specific.
        """
        self._flush_cuda_measurements()
        self._backend.flush(output_path)

    def shutdown(self) -> None:
        """Shutdown the profiler and release resources.

        Flushes any pending CUDA measurements before shutting down.
        """
        self._flush_cuda_measurements()
        self._backend.shutdown()


class _NoOpSection:
    """No-op context manager for when profiling is disabled."""

    def __enter__(self) -> _NoOpSection:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        pass


class NoOpProfiler:
    """
    No-op profiler implementation for when profiling is disabled.

    All methods are no-ops that return immediately, ensuring zero overhead
    when profiling is not enabled.
    """

    _section = _NoOpSection()

    def section(
        self,
        key: str,
        cuda_timing: CudaTimingMode = CudaTimingMode.NONE,
    ) -> _NoOpSection:
        """Return a no-op context manager."""
        return self._section

    def flush(self, output_path=None) -> None:
        """No-op flush."""
        pass

    def shutdown(self) -> None:
        """No-op shutdown."""
        pass


# Type alias for profiler instances
ProfilerType = Union[Profiler, NoOpProfiler]
