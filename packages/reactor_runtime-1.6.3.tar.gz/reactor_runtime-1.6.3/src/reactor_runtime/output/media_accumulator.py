"""
Thread-safe multi-track media accumulator.

The :class:`BucketAccumulator` collects data from multiple threads into
indexed buckets.  Each bucket assembles a :class:`MediaBundle` under the
hood.  When a bucket meets a model-defined completion condition it is
emitted immediately -- there is no ordering guarantee between buckets.

Each track in a bucket holds a **single** numpy array.  A subsequent
push to the same track in the same bucket **replaces** the previous
data (override semantics, not accumulation).

Typical usage (from a model with parallel audio/video generation)::

    accumulator = BucketAccumulator(
        track_configs=[
            TrackInfo("video-0", TrackKind.VIDEO, rate=30.0),
            TrackInfo("audio-0", TrackKind.AUDIO, rate=48000.0),
        ],
        is_complete=lambda b: "video-0" in b and "audio-0" in b,
        on_complete=frame_buffer.push,
    )

    # From thread 1:
    accumulator.push(bucket_idx=0, track_name="video-0", data=frame)
    # From thread 2:
    accumulator.push(bucket_idx=0, track_name="audio-0", data=samples)
    # -> bucket 0 auto-emits when is_complete returns True

Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Callable, Dict, Optional

import numpy as np

from reactor_runtime.transports.media import (
    MediaBundle,
    TrackData,
    TrackInfo,
)
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


# -----------------------------------------------------------------
# Internal bucket state
# -----------------------------------------------------------------


@dataclass
class _Bucket:
    """Per-bucket state with its own lock.

    Each bucket is independently lockable so that pushes to different
    buckets never contend with each other.

    Each track holds a single ``np.ndarray``.  A second push to the
    same track **replaces** the previous data.
    """

    lock: threading.Lock = field(default_factory=threading.Lock)
    data: Dict[str, np.ndarray] = field(default_factory=dict)
    emitted: bool = False


# -----------------------------------------------------------------
# Public API
# -----------------------------------------------------------------


class BucketAccumulator:
    """Thread-safe accumulator that collects per-track data into indexed
    buckets and emits a :class:`MediaBundle` as soon as the model-defined
    completion condition is met.

    Design decisions:

    * **Override semantics**: each track in a bucket holds a single
      numpy array.  A subsequent push to the same track replaces the
      previous value.
    * **Per-bucket locking**: each :class:`_Bucket` has its own lock.
      Only a lightweight ``_buckets_lock`` is held briefly to
      create/delete entries in the dict.  Pushes to different buckets
      never contend.
    * **Immediate emission**: buckets emit as soon as ``is_complete``
      returns ``True``.  The ``bucket_idx`` is an identifier for
      grouping related track data, not a sequencing key.
    * **Emit outside lock**: ``on_complete`` (which typically calls
      ``FrameBuffer.push``) is invoked after releasing the bucket lock
      so expensive downstream work never blocks other buckets.

    Args:
        track_configs: List of :class:`TrackInfo` describing the tracks
            this accumulator expects.
        is_complete: Callable that receives the bucket's data dict
            (``{track_name: np.ndarray}``).  Must return ``True`` when
            the bucket is ready to emit.
        on_complete: Callable invoked with the built :class:`MediaBundle`
            when a bucket is complete.
    """

    def __init__(
        self,
        track_configs: list[TrackInfo],
        is_complete: Callable[[Dict[str, np.ndarray]], bool],
        on_complete: Callable[[MediaBundle], None],
    ) -> None:
        self._track_configs: Dict[str, TrackInfo] = {t.name: t for t in track_configs}
        self._is_complete = is_complete
        self._on_complete = on_complete

        # Per-bucket state.  _buckets_lock guards creation/deletion of
        # entries; each _Bucket has its own lock for data access.
        self._buckets_lock = threading.Lock()
        self._buckets: Dict[int, _Bucket] = {}

        self._emit_lock = threading.Lock()
        self._emit_count: int = 0

    # -----------------------------------------------------------------
    # Public
    # -----------------------------------------------------------------

    def push(self, bucket_idx: int, track_name: str, data: np.ndarray) -> None:
        """Push data for a track into a bucket.  Thread-safe.

        If the track already has data in this bucket, it is **replaced**
        (override semantics).  Acquires only the per-bucket lock, so
        pushes to different buckets never contend.

        If the bucket becomes complete after this push, the built
        :class:`MediaBundle` is emitted via ``on_complete`` **outside**
        the bucket lock.

        Args:
            bucket_idx: Identifier for the bucket.  Used only for
                grouping -- not for ordering.
            track_name: Name of the track (must match a name in
                ``track_configs``).
            data: NumPy array with the track payload.
        """
        if track_name not in self._track_configs:
            logger.warning(
                "Unknown track name, ignoring push",
                track_name=track_name,
                bucket_idx=bucket_idx,
            )
            return

        bucket = self._get_or_create_bucket(bucket_idx)
        bundle: Optional[MediaBundle] = None

        with bucket.lock:
            if bucket.emitted:
                logger.warning(
                    "Push to already-emitted bucket ignored",
                    bucket_idx=bucket_idx,
                    track_name=track_name,
                )
                return

            bucket.data[track_name] = data

            if self._is_complete(bucket.data):
                bundle = self._build_bundle(bucket.data)
                bucket.emitted = True

        # Emit outside the bucket lock but serialized across threads so
        # that FrameBuffer.push() (which is single-producer) never runs
        # concurrently from two accumulator callbacks.
        if bundle is not None:
            self._remove_bucket(bucket_idx)
            with self._emit_lock:
                self._emit_count += 1
                self._on_complete(bundle)

    # -----------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------

    def _get_or_create_bucket(self, idx: int) -> _Bucket:
        with self._buckets_lock:
            if idx not in self._buckets:
                self._buckets[idx] = _Bucket()
            return self._buckets[idx]

    def _remove_bucket(self, idx: int) -> None:
        with self._buckets_lock:
            self._buckets.pop(idx, None)

    def _build_bundle(self, data: Dict[str, np.ndarray]) -> MediaBundle:
        """Assemble a :class:`MediaBundle` from the raw bucket data."""
        tracks: Dict[str, TrackData] = {}
        for track_name, arr in data.items():
            info = self._track_configs.get(track_name)
            if info is None:
                logger.warning(
                    "Unknown track in bucket, skipping",
                    track_name=track_name,
                )
                continue

            tracks[track_name] = TrackData(info=info, data=arr)

        return MediaBundle(tracks=tracks)
