from importlib.metadata import version, PackageNotFoundError

from reactor_runtime.model_api import VideoModel, command, model
from reactor_runtime.context_api import get_ctx
from reactor_runtime.transports.media import MediaBundle, TrackDirection
from reactor_runtime.tracks import (
    Track,
    OutputTrack,
    InputTrack,
    VideoOut,
    AudioOut,
    VideoIn,
    AudioIn,
)

try:
    __version__ = version("reactor_runtime")
except PackageNotFoundError:
    __version__ = "0.0.0.dev"  # Development/test mode

__all__ = [
    "VideoModel",
    "command",
    "model",
    "get_ctx",
    "MediaBundle",
    "TrackDirection",
    "Track",
    "OutputTrack",
    "InputTrack",
    "VideoOut",
    "AudioOut",
    "VideoIn",
    "AudioIn",
    "__version__",
]
