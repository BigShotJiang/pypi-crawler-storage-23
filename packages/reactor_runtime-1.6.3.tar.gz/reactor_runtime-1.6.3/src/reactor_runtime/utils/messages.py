"""
Reactor SDK Message Types (v2)

These message types are used by the runtime for data channel messaging.
All messages on the WebRTC data channel use a two-level envelope:

    { "scope": "application" | "runtime", "data": <inner_payload> }

- "application" messages carry model-defined commands (client->runtime) and
  model-emitted payloads (runtime->client, via get_ctx().send()).
- "runtime" messages carry platform-level control (e.g., requestCapabilities).
"""

from enum import Enum
from typing import Any, Dict, Literal, Union
from pydantic import BaseModel, Field


class RuntimeMessageType(str, Enum):
    """
    Known message types for the runtime control channel.

    These are the ``"type"`` values carried inside the inner payload of
    ``RuntimeMessage`` envelopes (scope = "runtime").
    """

    REQUEST_CAPABILITIES = "requestCapabilities"
    MODEL_CAPABILITIES = "modelCapabilities"
    PING = "ping"


class ApplicationMessage(BaseModel):
    """
    Envelope for user/model application messages sent over the data channel.
    """

    scope: Literal["application"] = "application"
    data: Any = Field(..., description="User application data (JSON-serializable)")


class RuntimeMessage(BaseModel):
    """
    Envelope for runtime control messages sent over the data channel.
    Used for platform-level communication (e.g., capabilities exchange).
    """

    scope: Literal["runtime"] = "runtime"
    data: Any = Field(..., description="Runtime control data (JSON-serializable)")


class WebRTCOfferMessage(BaseModel):
    """WebRTC offer message from client to server"""

    type: Literal["webrtc-offer"] = "webrtc-offer"
    data: Dict[str, Any] = Field(..., description="WebRTC offer SDP")


class WebRTCAnswerMessage(BaseModel):
    """WebRTC answer message from server to client"""

    type: Literal["webrtc-answer"] = "webrtc-answer"
    data: Dict[str, Any] = Field(..., description="WebRTC answer SDP")


# Union of all SDK message types for validation
ReactorMessage = Union[
    ApplicationMessage, RuntimeMessage, WebRTCOfferMessage, WebRTCAnswerMessage
]
