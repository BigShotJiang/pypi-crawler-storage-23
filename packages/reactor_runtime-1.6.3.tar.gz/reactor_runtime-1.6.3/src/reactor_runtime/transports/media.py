"""
Generic multi-track media types for the Reactor transport layer.

These types model N named tracks of any kind.  They are intentionally
**not** hard-wired to a specific number of video or audio tracks.  The
transport layer routes each track to the appropriate output based on its
:attr:`TrackInfo.kind`.

Typical usage::

    from reactor_runtime.transports.media import (
        TrackKind, TrackInfo, TrackData, MediaBundle,
    )

    bundle = MediaBundle(tracks={
        "video-0": TrackData(
            info=TrackInfo(name="video-0", kind=TrackKind.VIDEO, rate=30.0),
            data=video_frame,      # (H, W, 3) uint8 RGB
        ),
        "audio-0": TrackData(
            info=TrackInfo(name="audio-0", kind=TrackKind.AUDIO, rate=48000.0),
            data=audio_samples,    # (1, N) int16 mono
        ),
    })

Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

import numpy as np

# =============================================================================
# Track Kind
# =============================================================================


class TrackKind(str, Enum):
    """Identifies the kind of media a track carries.

    Using :class:`str` as a mixin so the enum serialises cleanly to JSON
    and is easy to extend in the future.
    """

    VIDEO = "video"
    AUDIO = "audio"


# =============================================================================
# Track Direction
# =============================================================================


class TrackDirection(str, Enum):
    """Direction of data flow for a track, **from the model's perspective**.

    All directions describe which way media flows relative to the model
    process, never relative to the client or the network.

    ``IN``  -- **client → model**.  The model *receives* data from the
               client on this track (e.g. a webcam feed).  Supports
               ``latest()`` to read inbound frames.
    ``OUT`` -- **model → client**.  The model *sends* data to the
               client on this track (e.g. generated video or audio).
               Supports ``emit()`` to push outbound frames.

    Bidirectional data flow is achieved by declaring two separate
    tracks — one ``IN`` and one ``OUT`` — with distinct names.
    """

    IN = "in"
    OUT = "out"


# =============================================================================
# Track Metadata
# =============================================================================


@dataclass(frozen=True)
class TrackInfo:
    """Immutable metadata describing a single media track.

    Attributes:
        name: Unique identifier for this track within a session
            (e.g. ``"main_video"``, ``"main_audio"``).
        kind: The kind of media this track carries.
        rate: Native output rate in units per second.  For video this is
            frames/sec; for audio it is samples/sec (e.g. ``48000``).
            Set to ``0`` when the rate is unknown or not applicable.
        direction: Data-flow direction **from the model's perspective**:
            ``IN`` = client → model, ``OUT`` = model → client.
    """

    name: str
    kind: TrackKind
    rate: float = 0.0
    direction: TrackDirection = TrackDirection.OUT


# =============================================================================
# Track Payload
# =============================================================================


@dataclass
class TrackData:
    """One track's payload inside a :class:`MediaBundle`.

    Attributes:
        info: Metadata for this track.
        data: NumPy array containing the track payload:

            * **Video**: ``(H, W, 3)`` ``uint8`` RGB for a single frame,
              or ``(N, H, W, 3)`` for a batch of *N* frames.
            * **Audio**: ``(1, M)`` ``int16`` mono samples.
    """

    info: TrackInfo
    data: np.ndarray


# =============================================================================
# Media Bundle
# =============================================================================


@dataclass
class MediaBundle:
    """Synchronised multi-track media unit.

    A ``MediaBundle`` groups together data from one or more named tracks
    that belong to the same logical time interval.  It flows through the
    pipeline from the model to the transport::

        Model -> BucketAccumulator -> FrameBuffer -> Runtime -> Transport

    The :attr:`tracks` dictionary is keyed by track name for O(1)
    lookup.  Helper methods provide kind-based filtering without
    hard-coding any specific track names.
    """

    tracks: Dict[str, TrackData] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Lookup helpers
    # ------------------------------------------------------------------

    def get_track(self, name: str) -> Optional[TrackData]:
        """Return the :class:`TrackData` for *name*, or ``None``."""
        return self.tracks.get(name)

    def get_tracks_by_kind(self, kind: TrackKind) -> List[TrackData]:
        """Return all tracks matching the given :class:`TrackKind`."""
        return [td for td in self.tracks.values() if td.info.kind == kind]

    # ------------------------------------------------------------------
    # Derived bundles
    # ------------------------------------------------------------------

    def video_only(self) -> "MediaBundle":
        """Return a copy containing only video tracks."""
        return MediaBundle(
            tracks={
                k: v for k, v in self.tracks.items() if v.info.kind == TrackKind.VIDEO
            }
        )

    # ------------------------------------------------------------------
    # Convenience factories
    # ------------------------------------------------------------------

    @staticmethod
    def from_video_frame(frame: np.ndarray, track_name: str = "video") -> "MediaBundle":
        """Wrap a bare video ``np.ndarray`` into a single-track bundle.

        Used internally to wrap inbound video frames from the transport
        into a ``MediaBundle`` before dispatching to the model.

        Args:
            frame: NumPy array with shape ``(H, W, 3)`` for a single
                frame or ``(N, H, W, 3)`` for a batch.
            track_name: The MID-derived track name (e.g. ``"webcam"``).

        Returns:
            A :class:`MediaBundle` with a single named track.
        """
        info = TrackInfo(
            name=track_name, kind=TrackKind.VIDEO, rate=0.0, direction=TrackDirection.IN
        )
        return MediaBundle(tracks={track_name: TrackData(info=info, data=frame)})
