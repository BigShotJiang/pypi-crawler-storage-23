"""
aiortc-based WebRTC transport implementation.

:class:`AiortcTransport` implements the
:class:`~reactor_runtime.transports.interface.WebRTCTransport` ABC using
the ``aiortc`` library.  All aiortc-specific details (peer connection,
ICE gathering, data channels, video tracks, shared-memory frame
conversion) are encapsulated here and **never** leak to runtime code.
"""

import asyncio
import json
import threading
from typing import Dict, List, Optional, Set, Tuple, Union

from aiortc import (
    RTCConfiguration,
    RTCIceServer,
    RTCPeerConnection,
    RTCSessionDescription,
)
from aiortc.rtcdatachannel import RTCDataChannel
from aioice.ice import TransportPolicy

from reactor_runtime.transports.config import DEFAULT_STUN_SERVER
from reactor_runtime.transports.events import (
    ConnectedEvent,
    DisconnectedEvent,
    MessageEvent,
    VideoFrameEvent,
    WebRTCSupersededError,
)
from reactor_runtime.transports.interface import WebRTCTransport
from reactor_runtime.transports.media import MediaBundle, TrackKind
from reactor_runtime.transports.types import (
    IceServer,
    IceTransportPolicy,
    SessionDescription,
    TransportConfig,
)

from reactor_runtime.utils.log import get_logger
from reactor_runtime.transports.aiortc.audio_track import OutputAudioTrack
from reactor_runtime.transports.aiortc.frame_conversion import (
    prewarm_frame_conversion_pipeline,
)
from reactor_runtime.transports.aiortc.ice_connection import PortRangeGathererPatch
from reactor_runtime.transports.aiortc.video_track import (
    OutputVideoTrack,
    video_frame_to_numpy,
)

logger = get_logger(__name__)


# =============================================================================
# Helpers for converting transport-agnostic types to aiortc-native types
# =============================================================================


def _to_rtc_ice_servers(
    servers: list[IceServer] | None,
) -> list[RTCIceServer] | None:
    """Convert a list of :class:`IceServer` to ``aiortc.RTCIceServer`` instances."""
    if not servers:
        return None
    result: list[RTCIceServer] = []
    for s in servers:
        kwargs: dict = {"urls": s.urls}
        if s.username:
            kwargs["username"] = s.username
        if s.credential:
            kwargs["credential"] = s.credential
        result.append(RTCIceServer(**kwargs))
    return result


def _to_aioice_transport_policy(policy: IceTransportPolicy) -> TransportPolicy:
    """Map :class:`IceTransportPolicy` to ``aioice.TransportPolicy``."""
    if policy == IceTransportPolicy.RELAY:
        return TransportPolicy.RELAY
    return TransportPolicy.ALL


_SDP_DIRECTIONS = frozenset({"sendonly", "recvonly", "sendrecv", "inactive"})


def _parse_sdp_directions(sdp: str) -> Dict[str, str]:
    """Extract a ``{mid: direction}`` mapping from an SDP offer.

    Iterates the m-sections of the SDP, collecting the ``a=mid:`` and
    ``a=sendonly`` / ``a=recvonly`` / ``a=sendrecv`` attributes.
    Returns a dict keyed by MID value with the direction string from
    the **client's perspective**.
    """
    result: Dict[str, str] = {}
    current_mid: Optional[str] = None
    current_dir: Optional[str] = None

    for line in sdp.splitlines():
        if line.startswith("m="):
            if current_mid and current_dir:
                result[current_mid] = current_dir
            current_mid = None
            current_dir = None
        elif line.startswith("a=mid:"):
            current_mid = line.split(":", 1)[1].strip()
        elif line.startswith("a=") and line[2:] in _SDP_DIRECTIONS:
            current_dir = line[2:]

    if current_mid and current_dir:
        result[current_mid] = current_dir

    return result


# =============================================================================
# AiortcTransport
# =============================================================================


class AiortcTransport(WebRTCTransport):
    """WebRTC transport backed by the ``aiortc`` library.

    Manages a single WebRTC connection lifecycle on a dedicated thread
    with its own asyncio event loop.  Cooperative shutdown via a stop
    event allows fast superseding of connections.

    Do **not** instantiate directly -- use
    :meth:`WebRTCTransport.create`.
    """

    _prewarm_done: bool = False
    _prewarm_lock: threading.Lock = threading.Lock()

    @classmethod
    def _prewarm(cls) -> None:
        """Ensure the frame-conversion worker process is warm.

        Blocks until the ``ProcessPoolExecutor`` worker has spawned and
        imported numpy/av by running a dummy conversion through the
        full SHM pipeline.  Idempotent — subsequent calls return
        immediately.
        """
        with cls._prewarm_lock:
            if cls._prewarm_done:
                return
            try:
                prewarm_frame_conversion_pipeline()
            except Exception as e:
                logger.warning("Transport prewarm failed (non-fatal)", error=e)
            finally:
                cls._prewarm_done = True

    def __init__(self) -> None:
        super().__init__()

        # Thread (event loop & stop event live in the base class)
        self._thread: Optional[threading.Thread] = None
        self._loop_ready = threading.Event()

        # WebRTC state (accessed only from _loop thread)
        self._pc: Optional[RTCPeerConnection] = None
        self._data_channel: Optional[RTCDataChannel] = None

        # Output tracks keyed by MID (which is the track name set by the
        # client SDK in its SDP offer).
        self._output_tracks: Dict[str, Union[OutputVideoTrack, OutputAudioTrack]] = {}

        # Connection state
        self._connected = threading.Event()

        # Background tasks (prevent GC of fire-and-forget coroutines)
        self._background_tasks: Set[asyncio.Task] = set()

        # Superseded flag
        self._was_superseded = False

        # Port range for ICE UDP binding
        self._port_range: Optional[Tuple[int, int]] = None

        # ICE transport policy
        self._transport_policy: TransportPolicy = TransportPolicy.ALL

    # =========================================================================
    # Factory (implements the ABC hook)
    # =========================================================================

    @classmethod
    async def _create(
        cls,
        sdp_offer: str,
        sdp_type: str,
        config: Optional[TransportConfig],
    ) -> tuple["AiortcTransport", SessionDescription]:
        """Create an :class:`AiortcTransport` and perform the SDP exchange.

        Converts the transport-agnostic :class:`TransportConfig` to
        aiortc-native types internally.
        """
        await asyncio.to_thread(cls._prewarm)
        client = cls()

        ice_servers: list[RTCIceServer] | None = None
        if config:
            ice_servers = _to_rtc_ice_servers(config.ice_servers)
            client._port_range = config.port_range
            client._transport_policy = _to_aioice_transport_policy(
                config.transport_policy
            )

        rtc_answer = await client._start_and_connect(sdp_offer, sdp_type, ice_servers)
        answer = SessionDescription(sdp=rtc_answer.sdp, type=rtc_answer.type)
        return client, answer

    # =========================================================================
    # Connection lifecycle
    # =========================================================================

    async def _start_and_connect(
        self,
        sdp_offer: str,
        sdp_type: str,
        ice_servers: Optional[List[RTCIceServer]],
    ) -> RTCSessionDescription:
        """Start the background thread and perform the SDP exchange."""
        self._thread = threading.Thread(
            target=self._run_event_loop,
            name="webrtc-client",
            daemon=False,
        )
        self._thread.start()

        # Wait for event loop readiness
        while not self._loop_ready.is_set():
            if self._stop_event.is_set():
                self._was_superseded = True
                self._join_thread()
                raise WebRTCSupersededError("Client stopped before loop ready")
            await asyncio.sleep(0.05)

        loop = self._loop
        if loop is None:
            raise RuntimeError("Event loop not initialised after _loop_ready")
        future = asyncio.run_coroutine_threadsafe(
            self._setup_connection(sdp_offer, sdp_type, ice_servers),
            loop,
        )

        async def wait_for_future():
            while True:
                if self._stop_event.is_set():
                    future.cancel()
                    self._was_superseded = True
                    self._join_thread()
                    raise WebRTCSupersededError("Client stopped during setup")
                try:
                    if future.done():
                        return future.result()
                    await asyncio.sleep(0.05)
                except asyncio.CancelledError:
                    future.cancel()
                    self._was_superseded = True
                    self._join_thread()
                    raise WebRTCSupersededError("Client setup cancelled")

        try:
            return await wait_for_future()
        except WebRTCSupersededError:
            raise
        except Exception as e:
            logger.exception("Failed to setup WebRTC connection", error=e)
            self.stop()
            raise RuntimeError(f"WebRTC connection setup failed: {e}")

    def _run_event_loop(self) -> None:
        """Run the asyncio event loop on the dedicated thread."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop_ready.set()

        try:
            self._loop.run_until_complete(self._wait_for_stop())
        except Exception as e:
            logger.warning("Event loop exited", error=e)
        finally:
            try:
                self._loop.run_until_complete(self._cleanup())
            except Exception as e:
                logger.warning("Cleanup error", error=e)

            pending = asyncio.all_tasks(self._loop)
            for task in pending:
                task.cancel()

            if pending:
                self._loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True)
                )

            self._loop.close()
            logger.debug("WebRTC client event loop closed")

    async def _wait_for_stop(self) -> None:
        """Poll for the stop signal."""
        while not self._stop_event.is_set():
            await asyncio.sleep(0.05)

    async def _cleanup(self) -> None:
        """Release WebRTC resources."""
        if self._pc is not None:
            try:
                if self._pc.connectionState != "closed":
                    await self._pc.close()
            except Exception as e:
                logger.warning("Error closing peer connection", error=e)
            self._pc = None

        self._data_channel = None

        for track in self._output_tracks.values():
            track.cleanup()
        self._output_tracks.clear()

        logger.debug("WebRTC resources cleaned up")

    # =========================================================================
    # Connection setup
    # =========================================================================

    def _check_stopped(self) -> None:
        """Raise :class:`WebRTCSupersededError` if stopped."""
        if self._stop_event.is_set():
            raise WebRTCSupersededError("Client stopped")

    async def _check_stopped_async(self) -> None:
        """Async variant of :meth:`_check_stopped`."""
        if self._stop_event.is_set():
            raise WebRTCSupersededError("Client stopped")

    async def _setup_connection(
        self,
        sdp_offer: str,
        sdp_type: str,
        ice_servers: Optional[List[RTCIceServer]],
    ) -> RTCSessionDescription:
        """Set up the peer connection with cooperative stop checks."""
        await self._check_stopped_async()

        if not ice_servers:
            ice_servers = [RTCIceServer(urls=[DEFAULT_STUN_SERVER])]

        rtc_config = RTCConfiguration(iceServers=ice_servers)

        with PortRangeGathererPatch(
            port_range=self._port_range,
            transport_policy=self._transport_policy,
        ):
            pc = RTCPeerConnection(configuration=rtc_config)
            self._pc = pc

            self._setup_pc_handlers(pc)

            await self._check_stopped_async()

            offer = RTCSessionDescription(sdp=sdp_offer, type=sdp_type)
            await pc.setRemoteDescription(offer)

            await self._check_stopped_async()

            # aiortc defaults transceiver.direction to "recvonly" for
            # all transceivers created by setRemoteDescription — that's
            # the local default, not the negotiated intent.  Parse the
            # SDP offer to learn what the *client* declared per MID.
            client_dirs = _parse_sdp_directions(sdp_offer)

            for transceiver in pc.getTransceivers():
                mid = transceiver.mid
                if mid is None:
                    continue

                client_dir = client_dirs.get(mid, "sendrecv")
                # Client recvonly → server must send  (model OUT)
                # Client sendonly → server must recv  (model IN)
                # Client sendrecv → server both       (defensive)
                needs_sender = client_dir in ("recvonly", "sendrecv")

                if needs_sender:
                    transceiver.direction = (
                        "sendrecv" if client_dir == "sendrecv" else "sendonly"
                    )
                else:
                    transceiver.direction = (
                        "inactive" if client_dir == "inactive" else "recvonly"
                    )

                if transceiver.kind == "video":
                    if needs_sender:
                        output_track = OutputVideoTrack(self._stop_event)
                        self._output_tracks[mid] = output_track
                        transceiver.sender.replaceTrack(output_track)
                elif transceiver.kind == "audio":
                    if needs_sender:
                        audio_track = OutputAudioTrack(self._stop_event)
                        self._output_tracks[mid] = audio_track
                        transceiver.sender.replaceTrack(audio_track)

                logger.debug(
                    "Transceiver configured",
                    mid=mid,
                    kind=transceiver.kind,
                    client_direction=client_dir,
                    server_direction=transceiver.direction,
                    has_output_track=needs_sender,
                )

            logger.info(
                "Transceivers configured by MID",
                tracks=list(self._output_tracks.keys()),
            )

            await self._check_stopped_async()

            answer = await pc.createAnswer()
            await pc.setLocalDescription(answer)

            await self._check_stopped_async()

            await self._gather_ice_candidates(pc)

        await self._check_stopped_async()

        local_desc = pc.localDescription
        if local_desc is None:
            raise RuntimeError("Failed to create local SDP description")

        return local_desc

    async def _gather_ice_candidates(
        self, pc: RTCPeerConnection, timeout: float = 10.0
    ) -> None:
        """Wait for ICE gathering to complete with cooperative stop checks."""
        if pc.iceGatheringState == "complete":
            return

        gathering_complete = asyncio.Event()

        @pc.on("icegatheringstatechange")
        def on_ice_gathering_state_change():
            if pc.iceGatheringState == "complete":
                gathering_complete.set()

        elapsed = 0.0
        check_interval = 0.1
        while elapsed < timeout:
            await self._check_stopped_async()
            try:
                await asyncio.wait_for(
                    gathering_complete.wait(), timeout=check_interval
                )
                return
            except asyncio.TimeoutError:
                elapsed += check_interval
                continue

        logger.warning(
            "ICE gathering timed out, proceeding with current candidates",
            timeout=f"{timeout}s",
        )

    # =========================================================================
    # Peer-connection event handlers
    # =========================================================================

    def _setup_pc_handlers(self, pc: RTCPeerConnection) -> None:
        """Wire up aiortc peer-connection callbacks."""

        @pc.on("connectionstatechange")
        async def on_connectionstatechange():
            if self._stop_event.is_set():
                logger.debug("Triggered event for dead client. Skipping")
                return
            state = pc.connectionState
            logger.info("WebRTC connection state", state=state)

            if state == "connected":
                self._connected.set()
                self._emit_event(ConnectedEvent())
            elif state in ("failed", "closed", "disconnected"):
                self._connected.clear()
                self._emit_event(DisconnectedEvent(reason=state))

        @pc.on("datachannel")
        def on_datachannel(channel: RTCDataChannel):
            if self._stop_event.is_set():
                logger.debug("Triggered event for dead client. Skipping")
                return
            logger.info("Data channel received", label=channel.label)
            self._data_channel = channel
            self._setup_data_channel_handlers(channel)

        @pc.on("track")
        def on_track(track):
            if self._stop_event.is_set():
                logger.debug("Triggered event for dead client. Skipping")
                return

            mid = None
            for t in pc.getTransceivers():
                if t.receiver and t.receiver.track == track:
                    mid = t.mid
                    break
            track_name = mid or f"unknown-{track.kind}"
            logger.info("Track received", kind=track.kind, track_name=track_name)

            if track.kind == "video":
                try:
                    task = asyncio.create_task(
                        self._process_incoming_video(track, track_name)
                    )
                    self._background_tasks.add(task)
                    task.add_done_callback(self._background_tasks.discard)
                except RuntimeError as e:
                    logger.warning("Failed to create video processing task", error=e)

    def _setup_data_channel_handlers(self, channel: RTCDataChannel) -> None:
        """Wire up data-channel callbacks."""

        @channel.on("message")
        def on_message(message):
            if not self._stop_event.is_set():
                self._emit_event(MessageEvent(data=message))

        @channel.on("open")
        def on_open():
            logger.debug("Data channel opened", label=channel.label)

        @channel.on("close")
        def on_close():
            logger.debug("Data channel closed", label=channel.label)

    async def _process_incoming_video(self, track, track_name: str) -> None:
        """Read frames from an incoming video track and emit events."""
        try:
            while not self._stop_event.is_set():
                try:
                    frame = await asyncio.wait_for(track.recv(), timeout=0.1)
                    numpy_frame = video_frame_to_numpy(frame)
                    self._emit_event(
                        VideoFrameEvent(frame=numpy_frame, track_name=track_name)
                    )
                except asyncio.TimeoutError:
                    continue
                except Exception as e:
                    if "MediaStreamError" in str(type(e).__name__):
                        logger.debug("Video track ended")
                        break
                    logger.warning("Error processing video frame", error=e)
                    break
        except Exception as e:
            logger.warning("Video processing stopped", error=e)

    # =========================================================================
    # Stats (overrides base)
    # =========================================================================

    async def _get_rtt(self) -> Optional[float]:
        """Extract RTT from aiortc's RTCP stats.

        Returns RTT in seconds from the first remote-inbound-rtp report
        that has a roundTripTime, or None if unavailable.
        """
        if not self._pc:
            return None
        stats = await self._pc.getStats()
        for report in stats.values():
            if (
                report.type == "remote-inbound-rtp"
                and hasattr(report, "roundTripTime")
                and report.roundTripTime > 0
            ):
                return report.roundTripTime
        return None

    # =========================================================================
    # Sending data (implements ABC)
    # =========================================================================

    def send_media(self, bundle: MediaBundle) -> bool:
        """Send a multi-track media bundle to the remote peer.

        Routes each track in the bundle to the matching output track by
        name (MID).  Audio tracks are pushed first (non-blocking) to
        avoid being delayed by the video colour-space conversion.

        Args:
            bundle: A :class:`MediaBundle` containing named track
                payloads.

        Returns:
            ``True`` if the bundle was processed, ``False`` if the
            transport is stopped.
        """
        if self._stop_event.is_set():
            return False

        # Audio first (non-blocking jitter buffer append).
        for td in bundle.get_tracks_by_kind(TrackKind.AUDIO):
            out = self._output_tracks.get(td.info.name)
            if out is not None and isinstance(out, OutputAudioTrack):
                out.push_samples(td.data)

        # Video second (blocks ~10 ms for SHM colour-space conversion).
        for td in bundle.get_tracks_by_kind(TrackKind.VIDEO):
            out = self._output_tracks.get(td.info.name)
            if out is not None and isinstance(out, OutputVideoTrack):
                out.push_frame(td.data)

        return True

    def send_message(self, data: Union[dict, str]) -> bool:
        """Send a message over the data channel."""
        if self._stop_event.is_set():
            return False

        loop = self._loop
        if not loop or loop.is_closed():
            return False

        try:
            asyncio.run_coroutine_threadsafe(
                self._send_message_async(data),
                loop,
            )
            return True
        except Exception as e:
            logger.warning("Failed to schedule message send", error=e)
            return False

    async def _send_message_async(self, data: Union[dict, str]) -> None:
        """Send a message on the data channel (runs on the internal loop)."""
        if self._stop_event.is_set():
            return

        if not self._data_channel:
            return

        if self._data_channel.readyState != "open":
            return

        try:
            message = json.dumps(data) if isinstance(data, dict) else data
            self._data_channel.send(message)
        except Exception as e:
            logger.warning("Failed to send data channel message", error=e)

    # =========================================================================
    # Lifecycle (implements ABC)
    # =========================================================================

    def _join_thread(self, timeout: float = 5.0) -> None:
        """Join the background thread if alive."""
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                logger.warning("WebRTC client thread did not exit cleanly")
        self._thread = None

    def stop(self, timeout: float = 5.0) -> None:
        """Cooperatively stop the transport."""
        if self._stop_event.is_set():
            self._join_thread(timeout)
            return

        logger.debug("WebRTC client stop requested")
        self._stop_event.set()
        self._join_thread(timeout)
        logger.debug("WebRTC client stopped")

    def is_connected(self) -> bool:
        """Return ``True`` if connected and not stopped."""
        return self._connected.is_set() and not self._stop_event.is_set()

    @property
    def is_stopped(self) -> bool:
        """``True`` if :meth:`stop` has been requested."""
        return self._stop_event.is_set()

    @property
    def was_superseded(self) -> bool:
        """``True`` if this transport was stopped during setup."""
        return self._was_superseded

    def __del__(self):
        """Ensure cleanup on garbage collection."""
        if not self._stop_event.is_set():
            try:
                self.stop(timeout=1.0)
            except Exception:
                pass
