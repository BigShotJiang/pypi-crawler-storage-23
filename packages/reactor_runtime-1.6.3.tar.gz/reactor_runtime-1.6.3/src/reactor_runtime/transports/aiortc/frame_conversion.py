"""
Shared-memory frame conversion for zero-copy RGB-to-YUV420p IPC.

This module offloads the expensive RGB -> YUV420p colour-space conversion
to a separate *process* (via :class:`ProcessPoolExecutor`) so that the
GIL is not held during the conversion while the inference thread is
running.

Data is transferred between the main process and the worker through POSIX
shared-memory segments, avoiding pickle serialisation overhead.

Implementation details
----------------------
* Two shared-memory blocks are maintained at module level: one for the
  input RGB frame and one for the output YUV420p frame.
* Dimensions only *grow* (never shrink) -- a smaller frame always fits
  in a larger allocation.
* A single worker process is used to avoid contention on the shared
  memory.  The executor is lazily initialised and cleaned up via
  :func:`atexit`.
"""

import atexit
import multiprocessing
import threading
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import shared_memory
from typing import Any, Optional, Tuple

from av import VideoFrame

from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

# Process pool for frame conversion (lazy init)
_frame_conversion_executor: Optional[ProcessPoolExecutor] = None
_executor_lock = threading.Lock()

# Shared memory buffers for zero-copy frame transfer
_input_shm: Optional[shared_memory.SharedMemory] = None
_output_shm: Optional[shared_memory.SharedMemory] = None
_shm_lock = threading.Lock()

# Current shared memory dimensions (can grow dynamically).
# Initial values are reasonable defaults for 720p.
_shm_width: int = 1280
_shm_height: int = 720


# ---------------------------------------------------------------------------
# Size helpers
# ---------------------------------------------------------------------------


def _get_shm_rgb_size() -> int:
    """Return the RGB24 buffer size in bytes for the current SHM dimensions."""
    return _shm_width * _shm_height * 3


def _get_shm_yuv_size() -> int:
    """Return the YUV420p buffer size in bytes for the current SHM dimensions."""
    return _shm_width * _shm_height * 3 // 2


# ---------------------------------------------------------------------------
# Shared memory management (caller must hold ``_shm_lock``)
# ---------------------------------------------------------------------------


def _resize_shared_memory_if_needed_locked(width: int, height: int) -> bool:
    """Resize the module-level shared-memory blocks if *width*/*height* exceed the current allocation.

    Dimensions only grow (never shrink) since smaller frames fit in
    larger allocations.

    .. important:: Caller **must** hold :data:`_shm_lock`.

    Args:
        width: Frame width in pixels.
        height: Frame height in pixels.

    Returns:
        ``True`` if the shared memory was reallocated, ``False``
        otherwise.
    """
    global _shm_width, _shm_height, _input_shm, _output_shm

    if width <= _shm_width and height <= _shm_height:
        return False

    new_width = max(_shm_width, width)
    new_height = max(_shm_height, height)

    logger.info(
        "Resizing shared memory",
        old_size=f"{_shm_width}x{_shm_height}",
        new_size=f"{new_width}x{new_height}",
    )

    # Clean up old shared memory
    if _input_shm is not None:
        try:
            _input_shm.close()
            _input_shm.unlink()
        except Exception:
            pass
        _input_shm = None

    if _output_shm is not None:
        try:
            _output_shm.close()
            _output_shm.unlink()
        except Exception:
            pass
        _output_shm = None

    _shm_width = new_width
    _shm_height = new_height

    new_rgb_size = _get_shm_rgb_size()
    new_yuv_size = _get_shm_yuv_size()

    _input_shm = shared_memory.SharedMemory(create=True, size=new_rgb_size)
    logger.info("Created input shared memory", name=_input_shm.name, size=new_rgb_size)

    _output_shm = shared_memory.SharedMemory(create=True, size=new_yuv_size)
    logger.info(
        "Created output shared memory", name=_output_shm.name, size=new_yuv_size
    )

    return True


def _init_shared_memory_locked() -> Tuple[str, str]:
    """Initialise input/output shared-memory blocks (idempotent).

    .. important:: Caller **must** hold :data:`_shm_lock`.

    Returns:
        ``(input_shm_name, output_shm_name)``
    """
    global _input_shm, _output_shm

    if _input_shm is None:
        rgb_size = _get_shm_rgb_size()
        _input_shm = shared_memory.SharedMemory(create=True, size=rgb_size)
        logger.info("Created input shared memory", name=_input_shm.name, size=rgb_size)
    if _output_shm is None:
        yuv_size = _get_shm_yuv_size()
        try:
            _output_shm = shared_memory.SharedMemory(create=True, size=yuv_size)
        except Exception:
            # Clean up input SHM so we don't leak it
            if _input_shm is not None:
                try:
                    _input_shm.close()
                    _input_shm.unlink()
                except Exception:
                    pass
                _input_shm = None
            raise
        logger.info(
            "Created output shared memory", name=_output_shm.name, size=yuv_size
        )

    return _input_shm.name, _output_shm.name


# ---------------------------------------------------------------------------
# Executor management
# ---------------------------------------------------------------------------


def _get_frame_conversion_executor() -> ProcessPoolExecutor:
    """Return (and lazily create) the singleton process-pool executor.

    Thread-safe via double-checked locking on :data:`_executor_lock`.
    """
    global _frame_conversion_executor
    if _frame_conversion_executor is None:
        with _executor_lock:
            if _frame_conversion_executor is None:
                ctx = multiprocessing.get_context("spawn")
                _frame_conversion_executor = ProcessPoolExecutor(
                    max_workers=1,
                    mp_context=ctx,
                )
                atexit.register(_shutdown_frame_conversion_executor)
                logger.info(
                    "Frame conversion process pool initialized (shared memory mode)"
                )
    return _frame_conversion_executor


def prewarm_frame_conversion_pipeline() -> None:
    """Eagerly spawn the frame-conversion worker and warm its imports.

    Should be called once early in the process lifetime (e.g. during
    model loading) so the worker process is already alive and has
    imported ``numpy``/``av`` before the first session.  Blocks until
    the worker has completed a dummy conversion.

    Subsequent calls are cheap no-ops (executor already exists, SHM
    already allocated, worker already warm).
    """

    with _shm_lock:
        input_name, output_name = _init_shared_memory_locked()

    executor = _get_frame_conversion_executor()
    future = executor.submit(
        _convert_frame_via_shm,
        input_name,
        output_name,
        _shm_width,
        _shm_height,
    )
    future.result(timeout=30)
    logger.info("Frame conversion pipeline pre-warmed")


def _shutdown_frame_conversion_executor() -> None:
    """Shut down the process pool and release shared memory.

    Registered as an :func:`atexit` handler by
    :func:`_get_frame_conversion_executor`.
    """
    global _frame_conversion_executor, _input_shm, _output_shm

    if _frame_conversion_executor is not None:
        _frame_conversion_executor.shutdown(wait=False)
        _frame_conversion_executor = None

    with _shm_lock:
        if _input_shm is not None:
            try:
                _input_shm.close()
                _input_shm.unlink()
            except Exception:
                pass
            _input_shm = None
        if _output_shm is not None:
            try:
                _output_shm.close()
                _output_shm.unlink()
            except Exception:
                pass
            _output_shm = None


# ---------------------------------------------------------------------------
# Worker function (runs in a *separate process*)
# ---------------------------------------------------------------------------


def _convert_frame_via_shm(
    input_shm_name: str,
    output_shm_name: str,
    width: int,
    height: int,
) -> Tuple[int, int, int]:
    """Convert an RGB frame to YUV420p via shared memory.

    This function executes in a **spawned** worker process.  All imports
    are local because the ``spawn`` context does not inherit the
    parent's module state.

    Args:
        input_shm_name: Name of the shared-memory block containing the
            RGB frame.
        output_shm_name: Name of the shared-memory block to write YUV
            data to.
        width: Frame width in pixels.
        height: Frame height in pixels.

    Returns:
        ``(y_size, u_size, v_size)`` -- byte sizes of each YUV plane.
    """
    # Local imports required for 'spawn' context
    import numpy as np
    from av import VideoFrame as VF
    from multiprocessing import shared_memory as shm_module

    input_shm = shm_module.SharedMemory(name=input_shm_name)
    output_shm = shm_module.SharedMemory(name=output_shm_name)

    try:
        frame_data: np.ndarray[Any, np.dtype[np.uint8]] = np.ndarray(
            (height, width, 3), dtype=np.uint8, buffer=input_shm.buf
        )

        video_frame = VF.from_ndarray(frame_data, format="rgb24")
        video_frame = video_frame.reformat(format="yuv420p")

        y_plane = bytes(video_frame.planes[0])
        u_plane = bytes(video_frame.planes[1])
        v_plane = bytes(video_frame.planes[2])

        y_size = len(y_plane)
        u_size = len(u_plane)
        v_size = len(v_plane)

        output_buf = output_shm.buf
        if output_buf is None:
            raise RuntimeError("Output shared memory buffer is None")
        output_buf[:y_size] = y_plane
        output_buf[y_size : y_size + u_size] = u_plane
        output_buf[y_size + u_size : y_size + u_size + v_size] = v_plane

        return y_size, u_size, v_size
    finally:
        input_shm.close()
        output_shm.close()


# ---------------------------------------------------------------------------
# Frame reconstruction helper (runs in the main process)
# ---------------------------------------------------------------------------


def _build_video_frame_from_shm(
    output_shm: shared_memory.SharedMemory,
    y_size: int,
    u_size: int,
    v_size: int,
    width: int,
    height: int,
) -> VideoFrame:
    """Build a YUV420p :class:`VideoFrame` from the output shared-memory block.

    Args:
        output_shm: The shared-memory block containing YUV plane data.
        y_size: Y plane size in bytes.
        u_size: U plane size in bytes.
        v_size: V plane size in bytes.
        width: Frame width in pixels.
        height: Frame height in pixels.

    Returns:
        A :class:`VideoFrame` in ``yuv420p`` format.
    """
    output_buf = output_shm.buf
    if output_buf is None:
        raise RuntimeError("Output shared memory buffer is None")
    frame = VideoFrame(width=width, height=height, format="yuv420p")
    frame.planes[0].update(bytes(output_buf[:y_size]))
    frame.planes[1].update(bytes(output_buf[y_size : y_size + u_size]))
    frame.planes[2].update(
        bytes(output_buf[y_size + u_size : y_size + u_size + v_size])
    )
    return frame
