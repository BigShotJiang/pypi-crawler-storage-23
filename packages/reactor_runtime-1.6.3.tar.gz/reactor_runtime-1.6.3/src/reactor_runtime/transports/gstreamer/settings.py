# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
GStreamer transport settings.

Configuration used by the GStreamer WebRTC client (e.g. supported video/audio codecs
for SDP negotiation and encoder selection).
"""

from typing import List

from reactor_runtime.transports.gstreamer.sdp.codec import CodecEntry

# Ordered list of supported video codecs for SDP offer/answer and encoder selection.
# The first entry that appears in the remote SDP offer is chosen.
# Each entry: {"codec": str, "parameters"?: dict}
SUPPORTED_VIDEO_CODECS: List[CodecEntry] = [
    {
        "codec": "H264",
        "parameters": {
            "profile-level-id": "42e01f",
            "packetization-mode": "1",
        },
    },
    {"codec": "VP9", "parameters": {"profile-id": "0"}},
    {"codec": "VP8"},
    {"codec": "AV1", "parameters": {"profile": "0"}},
]

# Ordered list of supported audio codecs for SDP filtering.
# Each entry: {"codec": str, "parameters"?: dict}
SUPPORTED_AUDIO_CODECS: List[CodecEntry] = [
    {"codec": "Opus"},
]
