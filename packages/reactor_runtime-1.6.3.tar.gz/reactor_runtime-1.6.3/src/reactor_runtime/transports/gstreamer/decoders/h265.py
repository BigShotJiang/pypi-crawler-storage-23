from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    link_many,
    make_element,
    try_set_property,
)
from .base import BaseRTPDecoderBin


class H265DecoderBin(BaseRTPDecoderBin):
    """
    RTP decoder bin implementing:

        sink (RTP H265 / HEVC) ->
        rtph265depay ->
        decoder (HW preferred, SW fallback) ->
        src (raw video)

    H265/HEVC is less commonly supported in browsers,
    but useful in controlled environments or native clients.

    Hardware acceleration is strongly preferred due to
    higher computational cost compared to H264/VP8.
    """

    def __init__(self, name: str = "h265_decoder_bin"):
        super().__init__(name=name)

        # ---------------------------------------------------------
        # RTP depayloader
        # ---------------------------------------------------------
        # Converts RTP H265 packets into H265 elementary bitstream.
        # Handles aggregation units (AP) and fragmentation units (FU).
        self._depay = make_element("rtph265depay", "rtph265depay")

        # ---------------------------------------------------------
        # Select decoder implementation
        # ---------------------------------------------------------
        # Hardware decoders reduce CPU usage significantly.
        self._dec_factory = self._pick_decoder_factory()

        self._dec = make_element(self._dec_factory, self._dec_factory)

        # ---------------------------------------------------------
        # Best-effort low-latency tuning
        # ---------------------------------------------------------
        # Decoder properties vary by implementation and platform.
        # Attempt common threading optimizations.
        try_set_property(self._dec, "max-threads", 4)
        try_set_property(self._dec, "threads", 4)

        # ---------------------------------------------------------
        # Build internal pipeline
        # ---------------------------------------------------------
        self.add(self._depay)
        self.add(self._dec)

        # Link depayloader directly to decoder.
        # No parser is used here; in some environments,
        # inserting h265parse may improve robustness.
        link_many(self._depay, self._dec)

        # ---------------------------------------------------------
        # Expose ghost pads
        # ---------------------------------------------------------
        # sink → RTP input
        # src  → raw decoded frames
        depay_sink = self._depay.get_static_pad("sink")
        dec_src = self._dec.get_static_pad("src")

        if not depay_sink or not dec_src:
            raise RuntimeError("Failed to fetch sink/src pads")

        # Ghost pads allow the bin to behave like:
        #     RTP in → raw video out
        self._create_ghost_pads(depay_sink, dec_src)

    def _pick_decoder_factory(self) -> str:
        """
        Select best available H265 decoder implementation.

        Priority:

            1) NVIDIA hardware decoders
            2) avdec_h265 (libav software decoder)
            3) libde265dec (fallback software decoder)

        Hardware decoder names vary depending on:
            - Distro
            - Plugin set
            - Driver version
        """

        # ---------------------------------------------------------
        # NVIDIA hardware decoders
        # ---------------------------------------------------------
        for f in ("nvh265dec", "nvdec_h265", "nvv4l2decoder"):
            if Gst.ElementFactory.find(f) is not None:
                return f

        # ---------------------------------------------------------
        # Software fallback (libav)
        # ---------------------------------------------------------
        if Gst.ElementFactory.find("avdec_h265") is not None:
            return "avdec_h265"

        # ---------------------------------------------------------
        # Final fallback (libde265)
        # ---------------------------------------------------------
        return "libde265dec"
