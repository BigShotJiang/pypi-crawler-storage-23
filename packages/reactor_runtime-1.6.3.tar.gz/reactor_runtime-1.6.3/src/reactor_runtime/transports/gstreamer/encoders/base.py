from typing import Protocol, Optional
from reactor_runtime.transports.gstreamer.gst import Gst


class EncoderPayloader(Protocol):
    """
    Structural typing contract (PEP 544) for encoder bins that expose:

        sink -> encoder -> payloader -> src

    This allows higher-level components (e.g., HotSwitch, WebRTC pipeline
    builders) to operate generically on different codec implementations
    (VP8, VP9, H264, AV1, H265, etc.) without depending on concrete classes.

    Any class implementing this protocol must provide:

        - pad_src(): RTP output pad
        - pad_sink(): raw input pad
        - set_target_bitrate(): runtime bitrate control

    This avoids tight coupling to specific encoder implementations.
    """

    def pad_src(self) -> Gst.Pad: ...
    def pad_sink(self) -> Gst.Pad: ...
    def set_target_bitrate(self, bitrate_bps: int) -> None: ...


class BaseEncoderBin(Gst.Bin):
    """
    Base class for encoder + payloader bins.

    Responsibilities:

        - Create and manage ghost sink/src pads
        - Provide safe property setting helpers
        - Provide unified bitrate configuration across encoders

    This class abstracts differences between various GStreamer encoders,
    which often expose different property names and units for bitrate.
    """

    def __init__(self, name: str):
        super().__init__(name=name)

        # Ghost pads expose internal pads as external pads.
        # They allow this Bin to behave like a regular element:
        #     raw video in → RTP out
        self._ghost_sink: Optional[Gst.GhostPad] = None
        self._ghost_src: Optional[Gst.GhostPad] = None

    # ---------------------------------------------------------------------
    # Ghost pad creation
    # ---------------------------------------------------------------------

    def _create_ghost_pads(self, sink_pad: Gst.Pad, src_pad: Gst.Pad) -> None:
        """
        Create and attach ghost pads to the bin.

        Ghost pads are required so external pipeline elements
        (e.g., tee, webrtcbin) can link to this bin as if it were
        a simple encoder element.

        Typical topology:
            appsrc ! BaseEncoderBin ! webrtcbin
        """
        ghost_sink = Gst.GhostPad.new("sink", sink_pad)
        ghost_src = Gst.GhostPad.new("src", src_pad)

        if not ghost_sink or not ghost_src:
            raise RuntimeError("Failed to create ghost pads")

        if not self.add_pad(ghost_sink):
            raise RuntimeError("Failed to add ghost sink pad to bin")

        if not self.add_pad(ghost_src):
            raise RuntimeError("Failed to add ghost src pad to bin")

        self._ghost_sink = ghost_sink
        self._ghost_src = ghost_src

    def pad_src(self) -> Gst.Pad:
        """
        Return RTP output pad (ghost pad).

        Used when linking encoder output to:
            - webrtcbin
            - rtpbin
            - custom RTP routing elements
        """
        if self._ghost_src is None:
            raise RuntimeError("Ghost src pad has not been created yet")
        return self._ghost_src

    def pad_sink(self) -> Gst.Pad:
        """
        Return raw video input pad (ghost pad).

        Used when linking from:
            - appsrc
            - videoconvert
            - videoscale
            - tee branches
        """
        if self._ghost_sink is None:
            raise RuntimeError("Ghost sink pad has not been created yet")
        return self._ghost_sink

    # ---------------------------------------------------------------------
    # Unified bitrate handling
    # ---------------------------------------------------------------------

    def _set_bitrate_property(
        self,
        element: Gst.Element,
        bitrate_bps: int,
        prefer_target_bitrate_bps: bool = True,
        fallback_bitrate_is_kbps: bool = True,
    ) -> None:
        """
        Attempt to set bitrate using common naming conventions.

        Different encoders use different properties:

            - target-bitrate (bps)
                Common in VP8/VP9/AV1 encoders.

            - bitrate (often kbps)
                Common in x264enc, x265enc, etc.

            - bitrate-bps
                Occasionally used by some elements.

        Parameters:
            prefer_target_bitrate_bps:
                If True, try target-bitrate first.

            fallback_bitrate_is_kbps:
                If True, convert bps → kbps when using "bitrate".

        Raises:
            RuntimeError if no known bitrate property is exposed.
        """
        if bitrate_bps <= 0:
            raise ValueError("bitrate_bps must be > 0")

        bitrate_bps = int(bitrate_bps)

        # ---------------------------------------------------------
        # Preferred: target-bitrate (in bps)
        # ---------------------------------------------------------
        if (
            prefer_target_bitrate_bps
            and element.find_property("target-bitrate") is not None
        ):
            element.set_property("target-bitrate", bitrate_bps)
            return

        # ---------------------------------------------------------
        # Fallback: bitrate (commonly in kbps)
        # ---------------------------------------------------------
        if element.find_property("bitrate") is not None:
            if fallback_bitrate_is_kbps:
                # Convert bps → kbps (minimum 1 kbps)
                element.set_property("bitrate", max(1, bitrate_bps // 1000))
            else:
                element.set_property("bitrate", bitrate_bps)
            return

        # ---------------------------------------------------------
        # Alternative: bitrate-bps
        # ---------------------------------------------------------
        if element.find_property("bitrate-bps") is not None:
            element.set_property("bitrate-bps", bitrate_bps)
            return

        # ---------------------------------------------------------
        # If we reach here, encoder does not expose known bitrate property.
        # ---------------------------------------------------------
        raise RuntimeError(
            "%s does not expose a known bitrate property" % element.get_name()
        )
