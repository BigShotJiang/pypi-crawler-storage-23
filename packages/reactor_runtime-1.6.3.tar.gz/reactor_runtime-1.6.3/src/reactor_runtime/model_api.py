from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Type, get_type_hints
from pydantic import BaseModel, create_model
import inspect
from reactor_runtime.utils.schema import simplify_schema
from reactor_runtime.registry import (
    MODEL_REGISTRY,
)
from reactor_runtime.transports.media import (
    MediaBundle,
    TrackDirection,
    TrackKind,
)
from reactor_runtime.tracks import Track, VideoOut
from reactor_cli.utils.weights import get_weights
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


def _collect_tracks(cls: type) -> List[Track]:
    """Scan a class hierarchy for :class:`Track` attributes.

    Iterates the MRO from the decorated class downward so that child
    attributes take precedence over parent ones.
    """
    tracks: List[Track] = []
    seen: set[str] = set()
    for klass in cls.__mro__:
        if klass in (object, ABC):
            continue
        for attr_name, attr_value in vars(klass).items():
            if isinstance(attr_value, Track) and attr_name not in seen:
                attr_value._name = attr_name
                tracks.append(attr_value)
                seen.add(attr_name)
    return tracks


def _resolve_default_track(tracks: List[Track]) -> Optional[Track]:
    """Pick the default track from *tracks*.

    Priority:
    1. A track explicitly marked ``default=True``.
    2. The first ``VIDEO OUT`` track.
    """
    for t in tracks:
        if t.default:
            return t
    for t in tracks:
        if t.kind == TrackKind.VIDEO and t.direction == TrackDirection.OUT:
            return t
    return None


def _resolve_emission_fps(cls: type, tracks: List[Track]) -> Optional[float]:
    """Determine the emission FPS for the FrameBuffer.

    Priority:
    1. An explicit ``emission_fps`` class attribute on the model.
    2. The default video output track's ``rate`` (if > 0).
    3. ``None`` → auto mode.
    """
    explicit = getattr(cls, "emission_fps", None)
    if isinstance(explicit, (int, float)) and explicit > 0:
        return float(explicit)
    default_track = _resolve_default_track(tracks)
    if (
        default_track is not None
        and default_track.kind == TrackKind.VIDEO
        and default_track.rate > 0
    ):
        return default_track.rate
    return None


def model(
    name: str,
    config: Optional[str] = None,
    weights: Optional[List[str]] = None,
    **metadata: Any,
):
    """Decorator for registering a VideoModel class with the Reactor runtime.

    Track topology is declared via class attributes (``VideoOut``,
    ``AudioOut``, etc.) — **not** as arguments to this decorator.
    ``@model()`` carries only model identity: *name*, *config*, and
    *weights*.

    If no track attributes are declared on the class, a single
    ``main_video = VideoOut(default=True)`` track is injected
    automatically.  This keeps the simplest video-only models
    zero-config while still allowing full multi-track declarations.

    Args:
        name: Unique name for the model (required).
        config: Path to the model config file (optional).
        weights: Weight folder names to download from S3 (optional).
        **metadata: Additional metadata to store with the model.

    Usage::

        from reactor_runtime import VideoModel, model, get_ctx
        from reactor_runtime.tracks import VideoOut, AudioOut

        @model(name="my-model", config="config.yaml")
        class MyModel(VideoModel):
            main_video = VideoOut(default=True)
            main_audio = AudioOut(rate=48000.0)

            def start_session(self):
                ctx = get_ctx()
                idx = 0
                while not ctx.should_stop():
                    ctx.get_track("main_video").emit(frame, bucket=idx)
                    ctx.get_track("main_audio").emit(audio, bucket=idx)
                    idx += 1
    """

    def decorator(cls: Type) -> Type:
        if not (isinstance(cls, type) and issubclass(cls, VideoModel)):
            raise TypeError(
                f"@model can only decorate VideoModel subclasses, got {cls}"
            )

        if name in MODEL_REGISTRY:
            existing = MODEL_REGISTRY[name]["class"]
            raise ValueError(
                f"Duplicate model name '{name}' registered. "
                f"Already registered by {existing.__module__}.{existing.__name__}"
            )

        tracks = _collect_tracks(cls)
        if not tracks:
            default_track = VideoOut(default=True)
            default_track._name = "main_video"
            setattr(cls, "main_video", default_track)
            tracks = [default_track]
            logger.debug(
                "No tracks declared; injecting default main_video=VideoOut(default=True)",
                model=name,
            )

        emission_fps = _resolve_emission_fps(cls, tracks)

        MODEL_REGISTRY[name] = {
            "class": cls,
            "name": name,
            "config": config,
            "weights": weights or [],
            "tracks": tracks,
            "emission_fps": emission_fps,
            **metadata,
        }

        logger.debug(
            "Registered model",
            name=name,
            model_class=f"{cls.__module__}.{cls.__name__}",
            tracks=[t.name for t in tracks],
            emission_fps=emission_fps,
        )
        return cls

    return decorator


# =============================================================================
# Command Registry
# =============================================================================
# This section is used for declaration and storage of annotated commands.
# Annotated commands are registered to this registry, which stores each
# command and their declared capabilities.

command_registry: Dict[str, Dict] = {}


def _create_pydantic_model_from_signature(
    func: Callable, command_name: str
) -> Type[BaseModel]:
    """Create a Pydantic model from a function signature with type annotations."""
    sig = inspect.signature(func)
    type_hints = get_type_hints(func)

    fields: Dict[str, Any] = {}
    for param_name, param in sig.parameters.items():
        # Skip 'self' parameter
        if param_name == "self":
            continue

        param_type = type_hints.get(param_name, Any)

        # Handle default values - check if it's a Pydantic Field
        if param.default != inspect.Parameter.empty:
            if (
                hasattr(param.default, "__class__")
                and param.default.__class__.__name__ == "FieldInfo"
            ):
                # This is a Pydantic Field() - use it directly
                fields[param_name] = (param_type, param.default)
            else:
                # Regular default value
                fields[param_name] = (param_type, param.default)
        else:
            # Required parameter
            fields[param_name] = (param_type, ...)

    # Create dynamic Pydantic model
    model_name = f"{command_name.title()}CommandModel"
    return create_model(model_name, **fields)


def command(name: str, description: str = ""):
    """Decorator for defining commands on VideoModel methods with automatic schema generation."""

    def decorator(func: Callable):
        if not (inspect.isfunction(func) or inspect.ismethod(func)):
            raise ValueError(f"@command can only decorate methods, got {type(func)}")

        pydantic_model = _create_pydantic_model_from_signature(func, name)
        command_registry[name] = {
            "model": pydantic_model,
            "description": description,
            "handler": func,
        }
        return func

    return decorator


class VideoModel(ABC):
    """
    A model that PRODUCES video frames and accepts command messages.

    Runtime contract:
      - The runtime will call `start(ctx, emit_frame)` in a background task.
      - The model should repeatedly call: `await emit_frame(frame)` to push frames.
      - The model should return from `start` only when stopped or on error.
      - The runtime may call `send(command, data)` at any time to control the model.
      - The runtime will call `stop()` on session teardown.

    Notes:
      - `frame` should be a NumPy ndarray (H, W, 3) in RGB.

    Registration:
      - Use the @model decorator to register your VideoModel subclass:

        @model(name="my-model", weights=["my-weights"])
        class MyModel(VideoModel):
            ...
    """

    name: str = "video-model"

    @abstractmethod
    def start_session(self) -> None:
        """
        Start producing frames and invoke `await emit_frame(frame)` for each frame.
        This method should return when the model is stopped.
        This method should NOT load from memory the model, but instead should take the already
        existing model reference (loaded in __init__) and run it.
        """
        raise NotImplementedError

    def _dispatch_media(self, bundle: MediaBundle) -> None:
        """Internal entry point called by the runtime when inbound media arrives.

        Updates all ``InputTrack`` descriptors so that
        ``get_ctx().get_track("name").latest()`` returns the most
        recent inbound data, then invokes the public ``on_media`` hook.

        Runtime code should always call this method, never ``on_media``
        directly, to guarantee track descriptors stay in sync.
        """
        from reactor_runtime.context_api import get_ctx

        get_ctx()._update_input_tracks(bundle)
        self.on_media(bundle)

    def on_media(self, bundle: MediaBundle):
        """Called when inbound media arrives from the client.

        The *bundle* contains all tracks that arrived in the same time
        window, keyed by track name.  Override this method to consume
        client input (e.g. a webcam feed).

        For a single-video-input model the typical pattern is::

            def on_media(self, bundle: MediaBundle):
                video = bundle.get_track("webcam")
                if video:
                    self._latest_frame = video.data
        """
        pass

    def send(self, cmd_name: str, args: Optional[dict] = None):
        """Dispatch a command to the model using the decorator-based command system."""
        if cmd_name not in command_registry:
            raise ValueError(f"Unknown command: {cmd_name}")

        cmd = command_registry[cmd_name]
        model_cls = cmd["model"]
        handler = cmd["handler"]

        # Validate arguments using the Pydantic model
        if args is None:
            args = {}
        validated_obj = model_cls(**args)

        # Extract validated values as kwargs
        # Access model_fields from the class, not instance (Pydantic v2.11+ deprecation)
        validated_kwargs = {
            k: getattr(validated_obj, k) for k in model_cls.model_fields.keys()
        }

        # Call the method with validated arguments
        result = handler(self, **validated_kwargs)

        return result

    @classmethod
    def get_tracks(cls) -> List[Track]:
        """Return the :class:`Track` descriptors declared as class attributes.

        Reads from ``MODEL_REGISTRY`` when available (populated by
        ``@model``), otherwise scans the class directly.
        """
        for info in MODEL_REGISTRY.values():
            if info["class"] is cls:
                return info.get("tracks", [])
        return _collect_tracks(cls)

    @classmethod
    def emission_fps_info(cls) -> Optional[float]:
        """Return the resolved emission FPS for this model.

        Priority: explicit ``emission_fps`` class attribute, then the
        default video output track's rate, then ``None`` (auto mode).
        """
        for info in MODEL_REGISTRY.values():
            if info["class"] is cls:
                return info.get("emission_fps")
        return _resolve_emission_fps(cls, _collect_tracks(cls))

    @classmethod
    def capabilities(cls) -> dict:
        """Return the full capabilities payload for this model.

        Combines commands, tracks, and emission_fps into a single dict
        suitable for sending over the data channel or printing via CLI.
        """
        tracks = {
            t.name: {
                "kind": t.kind.value,
                "rate": t.rate,
                "direction": t.direction.value,
                "default": t.default,
            }
            for t in cls.get_tracks()
        }
        return {
            **cls.commands(),
            "tracks": tracks,
            "emission_fps": cls.emission_fps_info(),
        }

    @classmethod
    def commands(cls) -> dict:
        """
        Returns the static command schema for this model.

        This method returns a dictionary describing all @command decorated methods
        and their parameter schemas. It reads from the global command_registry which
        is populated at import time by @command decorators.

        Note:
            This is a classmethod that accesses static metadata only. It does not
            depend on instance state and should not be overridden. The command
            schema is determined at class definition time by @command decorators.

        Returns:
            dict: Schema with format {"commands": {name: {"description": ..., "schema": ...}}}
        """
        return {
            "commands": {
                name: {
                    "description": meta["description"],
                    "schema": simplify_schema(meta["model"]),
                }
                for name, meta in command_registry.items()
            }
        }

    @staticmethod
    def weights(weight: str) -> Path:
        """
        Returns the path to the weights for the model.

        The weights list is defined in the @model decorator:

            @model(name="my-model", weights=["weight-folder-1", "weight-folder-2"])
            class MyModel(VideoModel):
                ...

        This method can be called on VideoModel directly or on any subclass:
            VideoModel.weights("my-weights")  # Works - looks up from MODEL_REGISTRY
            MyModel.weights("my-weights")     # Works - uses decorator metadata

        Args:
            weight: Name of the weight folder to retrieve

        Returns:
            Path to the downloaded weight folder

        Raises:
            ValueError: If the weight is not in the model's weights list
            RuntimeError: If no model is registered
        """
        # Look up weights from the registered model in MODEL_REGISTRY
        # This allows calling VideoModel.weights() without needing the subclass
        if not MODEL_REGISTRY:
            raise RuntimeError(
                "No @model decorated class found. "
                "Ensure your VideoModel subclass has the @model decorator."
            )

        # Get the single registered model's metadata
        model_info = next(iter(MODEL_REGISTRY.values()))
        weights_list = model_info.get("weights", [])

        if weight not in weights_list:
            if weights_list:
                weights_list_str = "\n- " + "\n- ".join(weights_list)
                logger.info("Available weights", list=weights_list_str)
            raise ValueError(
                f"Weight '{weight}' not found in @model decorator. "
                "Please ensure all weights used by the model are listed in the @model decorator's weights parameter."
            )

        result = get_weights(weight)
        logger.debug("Weight found", weight=weight, path=result)
        return result
