"""
Input frame feeder for the Headless Runtime.

Reads PNG images from a directory in natural-sorted order and feeds them
to a VideoModel via on_media(), simulating incoming client video in the
same way the WebRTC transport delivers frames.
"""

import argparse
import re
import shlex
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2

from reactor_runtime.model_api import VideoModel
from reactor_runtime.transports.media import MediaBundle
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


# =============================================================================
# Natural sort helper
# =============================================================================


def _natural_sort_key(path: Path):
    """Sort key that orders numeric segments by value, not lexicographically.

    e.g. frame_2.png < frame_10.png (instead of frame_10 < frame_2).
    """
    return [
        int(part) if part.isdigit() else part.lower()
        for part in re.split(r"(\d+)", path.name)
    ]


# =============================================================================
# Start command argument parsing
# =============================================================================


@dataclass
class StartSessionArgs:
    """Parsed arguments from the interactive ``start`` command."""

    input_folder: Optional[str] = None
    input_fps: Optional[float] = None


def _positive_float(value: str) -> float:
    v = float(value)
    if v <= 0:
        raise argparse.ArgumentTypeError(f"must be a positive number, got {value!r}")
    return v


def _build_start_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="start",
        description="Start a model session",
        exit_on_error=False,
        add_help=False,
    )
    parser.add_argument(
        "--input-folder",
        type=str,
        default=None,
        help="Directory containing PNG images to feed as input frames",
    )
    parser.add_argument(
        "--input-fps",
        type=_positive_float,
        default=None,
        help="Rate limit for feeding input frames (frames per second). "
        "If omitted, frames are fed as fast as the model consumes them.",
    )
    return parser


_start_parser = _build_start_parser()


def parse_start_args(args_str: str) -> Optional[StartSessionArgs]:
    """Parse optional arguments following the ``start`` command.

    Returns a ``StartSessionArgs`` on success, or ``None`` if parsing fails
    (an error message is printed to stdout).
    """
    if not args_str.strip():
        return StartSessionArgs()

    try:
        tokens = shlex.split(args_str)
    except ValueError as e:
        print(f"\n[ERROR] Bad quoting in start arguments: {e}", flush=True)
        return None

    try:
        ns = _start_parser.parse_args(tokens)
    except (argparse.ArgumentError, SystemExit) as e:
        print(f"\n[ERROR] Invalid start arguments: {e}", flush=True)
        print(
            "  Usage: start [--input-folder PATH] [--input-fps FPS]",
            flush=True,
        )
        return None

    return StartSessionArgs(
        input_folder=ns.input_folder,
        input_fps=ns.input_fps,
    )


# =============================================================================
# InputFrameFeeder
# =============================================================================


class InputFrameFeeder:
    """Reads PNGs from a folder and feeds them to a model via ``on_media``."""

    def __init__(
        self,
        input_folder: str,
        model: VideoModel,
        input_fps: Optional[float] = None,
    ):
        self._input_folder = Path(input_folder)
        self._model = model
        self._input_fps = input_fps
        self._stop_evt = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._files: list[Path] = []

    def validate(self) -> bool:
        """Check the folder exists and discover PNG files.

        Returns ``True`` if valid (even if empty -- the session still starts).
        Returns ``False`` only if the folder does not exist.
        """
        if not self._input_folder.is_dir():
            print(
                f"\n[ERROR] Input folder does not exist: {self._input_folder}",
                flush=True,
            )
            return False

        self._files = sorted(self._input_folder.glob("*.png"), key=_natural_sort_key)

        if not self._files:
            print(
                f"\n[WARN] No PNG files found in {self._input_folder}",
                flush=True,
            )
            return True

        fps_info = (
            f" at {self._input_fps} fps" if self._input_fps else " (no rate limit)"
        )
        print(
            f"\n[INFO] Input: {len(self._files)} PNG files from "
            f"{self._input_folder}{fps_info}",
            flush=True,
        )
        return True

    def start(self) -> None:
        """Launch the feeder in a background thread."""
        if not self._files:
            return

        self._thread = threading.Thread(
            target=self._run, daemon=False, name="input-frame-feeder"
        )
        self._thread.start()

    def stop(self) -> None:
        """Signal the feeder to stop and wait for it to finish."""
        self._stop_evt.set()
        self.join()

    def join(self, timeout: float = 5.0) -> None:
        """Wait for the feeder thread to finish."""
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                logger.warning("Input feeder thread did not exit within timeout")
            self._thread = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run(self) -> None:
        fed = 0
        skipped = 0
        total = len(self._files)
        interval = 1.0 / self._input_fps if self._input_fps else None

        try:
            for i, file_path in enumerate(self._files):
                if self._stop_evt.is_set():
                    logger.info(
                        "Input feeder stopped early by session stop",
                        fed=fed,
                        remaining=total - i,
                    )
                    break

                frame_bgr = cv2.imread(str(file_path))
                if frame_bgr is None:
                    logger.warning(
                        "Failed to read image, skipping", path=str(file_path)
                    )
                    skipped += 1
                    continue

                frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
                bundle = MediaBundle.from_video_frame(frame_rgb)
                self._model._dispatch_media(bundle)
                fed += 1

                logger.debug(
                    "Fed input frame",
                    index=i + 1,
                    total=total,
                    file=file_path.name,
                )

                if interval:
                    self._stop_evt.wait(timeout=interval)

        except Exception as e:
            logger.exception("Input feeder error", error=e)
        finally:
            summary = f"Input feeder finished: {fed}/{total} frames fed"
            if skipped:
                summary += f", {skipped} skipped"
            logger.info(summary)
            print(f"\n[INFO] {summary}", flush=True)
