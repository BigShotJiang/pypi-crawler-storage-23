from enum import Enum


class RunListSortMode(str, Enum):
    ACTIVITY = "activity"
    CREATED_AT_DESC = "created_at_desc"

    def __str__(self) -> str:
        return str(self.value)
