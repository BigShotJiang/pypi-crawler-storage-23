import subprocess
import os
from argparse import ArgumentParser
import sys
import tqdm
import re
import pandas as pd
from io import StringIO
import urllib.request
import glob
import gzip
import numpy as np
import time
import pickle

import pandas as pd

from collections import Counter, defaultdict

import networkx as nx



import bisect
#from numba import jit, float32, int64
import multiprocessing
from functools import partial


from commandIcmSupporting import *
from commandIcmVlsPipeliner import *


# =====================
# Instruction
# =====================
# Restrict the file name to alphanumeric only as filenames can be come pretty complicated ni later stages


# =====================
# I/O
# =====================

DIR_ICM64 = "/home/homingla/Software/icm-3.9-2b/icm64"

DIR_OverallFolder = "/mnt/orig/home/homingla/MessLab/Project-MT1/IcmPreliminaryDocking/"

User_Outputlabel = "MT1"
User_ContainerName = "ResultNew"









# ===========================
# Auto Folder structure
#=============================

DIR_Container = DIR_OverallFolder + "%s/" %(User_ContainerName)

# This is the sdf folder. All Sdf will be read here.
DIR_RawSdfFolder = DIR_OverallFolder + "Raw_SDF/"
DIR_RawPdbFolder = DIR_OverallFolder + "Raw_PDB/"



# Autoproduce folders
DIR_ProcessedSdfFolder = DIR_OverallFolder + "Icm_SDF/" # NOTE Hold sdf TODO incorporate charge enumeration
DIR_ProcessedPdbFolder = DIR_OverallFolder + "Icm_PDB/" # NOTE Hold Pdb ob
DIR_ProcessedMapFolder = DIR_OverallFolder + "Icm_MAP/" # NOTE Hold maps


Supporting_MkdirList([DIR_Container, 
                      DIR_ProcessedSdfFolder, DIR_ProcessedPdbFolder])





# ===================
# Execute
# ===============
# 0.
#dockcontainer000 = IcmPipeliner(DIR_Container = DIR_Container, ICM_Rigid = True,n_replica = 1)

# 1. Prepare all ligands
dockcontainer001 = IcmPipeliner(DIR_Container = DIR_Container, ICM_Rigid = True,n_replica = 1)
dockcontainer001.Prep_Ligand(
        DIR_RawSdfFolder = DIR_RawSdfFolder, 
        DIR_ProcessedSdfFolder = DIR_ProcessedSdfFolder)


# 2. Prepare receptor
dockcontainer001.Prep_Receptor(
        DIR_RawPdbFolder = DIR_RawPdbFolder,
        DIR_ProcessedPdbFolder = DIR_ProcessedPdbFolder)


# 3. Prepare map
dockcontainer001.Prep_Map(
        DIR_ProcessedPdbFolder = DIR_ProcessedPdbFolder)


# Set up docking and inspection per sdf
dockcontainer001.Dock_PerSdf(
        DIR_ProcessedPdbFolder = DIR_ProcessedPdbFolder, 
        DIR_ProcessedSdfFolder = DIR_ProcessedSdfFolder, 
        Outputlabel = User_Outputlabel, n_processor = 30, n_effort = 25.0)































































