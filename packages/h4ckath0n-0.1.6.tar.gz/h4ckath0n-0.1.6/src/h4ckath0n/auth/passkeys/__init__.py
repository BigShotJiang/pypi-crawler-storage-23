"""Passkey (WebAuthn) authentication – default auth method for h4ckath0n."""
