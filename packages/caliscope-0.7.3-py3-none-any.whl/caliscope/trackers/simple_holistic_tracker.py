import gc
import logging
from queue import Full, Queue
from threading import Thread

import cv2
import mediapipe as mp
import numpy as np

from caliscope.packets import PointPacket
from caliscope.tracker import Tracker
from caliscope.trackers.helper import apply_rotation, unrotate_points

logger = logging.getLogger(__name__)

MIN_DETECTION_CONFIDENCE = 0.5
MIN_TRACKING_CONFIDENCE = 0.95

# The following are from base Pose and can be ignored in favor of
# better estimated Holistic points
DRAW_IGNORE_LIST = [
    "nose",
    "left_eye_inner",
    "left_eye",
    "left_eye_outer",
    "right_eye_inner",
    "right_eye",
    "right_eye_outer",
    "left_ear",
    "right_ear",
    "mouth_left",
    "mouth_right",
    "left_wrist_pose",
    "right_wrist_pose",
    "left_pinky",
    "right_pinky",
    "left_index",
    "right_index",
    "left_thumb",
    "right_thumb",
]

POINT_NAMES = {
    # 0: "nose",
    # 1: "left_eye_inner",
    # 2: "left_eye",
    # 3: "left_eye_outer",
    # 4: "right_eye_inner",
    # 5: "right_eye",
    # 6: "right_eye_outer",
    # 7: "left_ear",
    # 8: "right_ear",
    # 9: "mouth_left",
    # 10: "mouth_right",
    11: "left_shoulder",
    12: "right_shoulder",
    13: "left_elbow",
    14: "right_elbow",
    # 15: "left_wrist_pose",
    # 16: "right_wrist_pose",
    # 17: "left_pinky",
    # 18: "right_pinky",
    # 19: "left_index",
    # 20: "right_index",
    # 21: "left_thumb",
    # 22: "right_thumb",
    23: "left_hip",
    24: "right_hip",
    25: "left_knee",
    26: "right_knee",
    27: "left_ankle",
    28: "right_ankle",
    29: "left_heel",
    30: "right_heel",
    31: "left_foot_index",
    32: "right_foot_index",
    100: "right_wrist",
    101: "right_thumb_CMC",
    102: "right_thumb_MCP",
    103: "right_thumb_IP",
    104: "right_thumb_tip",
    105: "right_index_finger_MCP",
    106: "right_index_finger_PIP",
    107: "right_index_finger_DIP",
    108: "right_index_finger_tip",
    109: "right_middle_finger_MCP",
    110: "right_middle_finger_PIP",
    111: "right_middle_finger_DIP",
    112: "right_middle_finger_tip",
    113: "right_ring_finger_MCP",
    114: "right_ring_finger_PIP",
    115: "right_ring_finger_DIP",
    116: "right_ring_finger_tip",
    117: "right_pinky_MCP",
    118: "right_pinky_PIP",
    119: "right_pinky_DIP",
    120: "right_pinky_tip",
    200: "left_wrist",
    201: "left_thumb_CMC",
    202: "left_thumb_MCP",
    203: "left_thumb_IP",
    204: "left_thumb_tip",
    205: "left_index_finger_MCP",
    206: "left_index_finger_PIP",
    207: "left_index_finger_DIP",
    208: "left_index_finger_tip",
    209: "left_middle_finger_MCP",
    210: "left_middle_finger_PIP",
    211: "left_middle_finger_DIP",
    212: "left_middle_finger_tip",
    213: "left_ring_finger_MCP",
    214: "left_ring_finger_PIP",
    215: "left_ring_finger_DIP",
    216: "left_ring_finger_tip",
    217: "left_pinky_MCP",
    218: "left_pinky_PIP",
    219: "left_pinky_DIP",
    220: "left_pinky_tip",
    # HOLISTIC FACE keypoints worth keeping...
    # this is for kinematic skull tracking, not animation.
    500: "lip_top_mid",
    504: "nose_tip",
    633: "right_inner_eye",
    699: "chin_tip",
    746: "right_outer_eye",
    862: "left_inner_eye",
    966: "left_outer_eye",
}


# keep ids in distinct ranges to avoid clashes
POSE_OFFSET = 0
RIGHT_HAND_OFFSET = 100
LEFT_HAND_OFFSET = 200
FACE_OFFSET = 500


class SimpleHolisticTracker(Tracker):
    def __init__(self) -> None:
        # Each cam_id gets its own mediapipe context manager
        # use a dictionary of queues for passing
        self.in_queues: dict[int, Queue] = {}
        self.out_queues: dict[int, Queue] = {}
        self.threads: dict[int, Thread] = {}

    @property
    def name(self):
        return "SIMPLE_HOLISTIC"

    def run_frame_processor(self, cam_id: int, rotation_count: int):
        # Create a MediaPipe pose instance
        # Mediapipe type stubs are incomplete; the holistic module exists at runtime
        with mp.solutions.holistic.Holistic(  # type: ignore[reportAttributeAccessIssue]
            min_detection_confidence=MIN_DETECTION_CONFIDENCE,
            min_tracking_confidence=MIN_TRACKING_CONFIDENCE,
        ) as holistic:
            while True:
                frame = self.in_queues[cam_id].get()

                if frame is None:  # Shutdown signal
                    logger.debug(f"SimpleHolisticTracker cam {cam_id} received shutdown signal")
                    # reset() closes the calculator graph but TFLite memory persists
                    holistic.reset()
                    break
                # apply rotation as needed
                frame = apply_rotation(frame, rotation_count)

                height, width, color = frame.shape
                # Convert the image to RGB format
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = holistic.process(frame)

                # initialize variables so none will be created if no points detected
                point_ids = []
                landmark_xy = []

                if results.pose_landmarks:
                    for landmark_id, landmark in enumerate(results.pose_landmarks.landmark):
                        # mediapipe expresses in terms of percent of frame, so must map to pixel position
                        x, y = int(landmark.x * width), int(landmark.y * height)
                        if landmark.x < 0 or landmark.x > 1 or landmark.y < 0 or landmark.y > 1:
                            # ignore
                            pass
                        else:
                            mapped_point_id = landmark_id + POSE_OFFSET
                            # some of the pose values are too noisy to bother with including considering that
                            # holistic face and hand tracking is so good
                            # ignore those points that aren't in the POINT_NAMES list
                            if mapped_point_id in POINT_NAMES:
                                point_ids.append(landmark_id + POSE_OFFSET)
                                landmark_xy.append((x, y))

                if results.right_hand_landmarks:
                    for landmark_id, landmark in enumerate(results.right_hand_landmarks.landmark):
                        # mediapipe expresses in terms of percent of frame, so must map to pixel position
                        x, y = int(landmark.x * width), int(landmark.y * height)
                        if landmark.x < 0 or landmark.x > 1 or landmark.y < 0 or landmark.y > 1:
                            # ignore
                            pass
                        else:
                            point_ids.append(landmark_id + RIGHT_HAND_OFFSET)
                            landmark_xy.append((x, y))

                if results.left_hand_landmarks:
                    for landmark_id, landmark in enumerate(results.left_hand_landmarks.landmark):
                        # mediapipe expresses in terms of percent of frame, so must map to pixel positionND_OFFSET
                        x, y = int(landmark.x * width), int(landmark.y * height)
                        if landmark.x < 0 or landmark.x > 1 or landmark.y < 0 or landmark.y > 1:
                            # ignore
                            pass
                        else:
                            point_ids.append(landmark_id + LEFT_HAND_OFFSET)
                            landmark_xy.append((x, y))

                if results.face_landmarks:
                    for landmark_id, landmark in enumerate(results.face_landmarks.landmark):
                        # mediapipe expresses in terms of percent of frame, so must map to pixel positionFSET
                        x, y = int(landmark.x * width), int(landmark.y * height)
                        if landmark.x < 0 or landmark.x > 1 or landmark.y < 0 or landmark.y > 1:
                            # ignore
                            pass
                        else:
                            face_id = landmark_id + FACE_OFFSET
                            # only track the point if it is in the list of names above
                            # this will significantly reduce the data tracked.
                            if face_id in POINT_NAMES.keys():
                                point_ids.append(landmark_id + FACE_OFFSET)
                                landmark_xy.append((x, y))

                point_ids = np.array(point_ids)
                landmark_xy = np.array(landmark_xy)

                # adjust for previous shift due to camera rotation count
                landmark_xy = unrotate_points(landmark_xy, rotation_count, width, height)
                point_packet = PointPacket(point_ids, landmark_xy)

                self.out_queues[cam_id].put(point_packet)

    def get_points(self, frame: np.ndarray, cam_id: int = 0, rotation_count: int = 0) -> PointPacket:
        """
        This is the primary method exposed to the rest of the code.
        The tracker receives frames and basic camera data from the Stream,
        then it places the frame/camera data on a queue that will hand it
        off to a context manager set up to process that stream of data.
        """

        if cam_id not in self.in_queues.keys():
            self.in_queues[cam_id] = Queue(1)
            self.out_queues[cam_id] = Queue(1)

            self.threads[cam_id] = Thread(
                target=self.run_frame_processor,
                args=(cam_id, rotation_count),
                daemon=True,
                name=f"SimpleHolisticTracker_Cam_{cam_id}",
            )

            self.threads[cam_id].start()

        self.in_queues[cam_id].put(frame)
        point_packet = self.out_queues[cam_id].get()

        return point_packet

    def get_point_name(self, point_id) -> str:
        # this if/else should be unnecessary now that only select points are being passed on up the chain.
        # if point_id < FACE_OFFSET:
        #     point_name = POINT_NAMES[point_id]
        # else:
        #     point_name = "face_" + str(point_id - FACE_OFFSET)
        return POINT_NAMES[point_id]

    def scatter_draw_instructions(self, point_id: int) -> dict:
        point_name = self.get_point_name(point_id)
        if point_name in DRAW_IGNORE_LIST:
            rules = {"radius": 0, "color": (0, 0, 0), "thickness": 0}
        elif point_name.startswith("left"):
            rules = {"radius": 5, "color": (0, 0, 220), "thickness": 3}
        elif point_name.startswith("right"):
            rules = {"radius": 5, "color": (220, 0, 0), "thickness": 3}
        else:
            rules = {"radius": 3, "color": (0, 220, 220), "thickness": 3}

        return rules

    def cleanup(self) -> None:
        """Signal threads to exit and wait for them to finish."""
        logger.debug(f"SimpleHolisticTracker cleanup: stopping {len(self.threads)} threads")

        # Send shutdown signal to all threads
        for cam_id, queue in self.in_queues.items():
            try:
                queue.put(None, timeout=1.0)
            except Full:
                logger.warning(f"SimpleHolisticTracker: timeout sending shutdown to cam {cam_id}")

        # Wait for threads to finish
        for cam_id, thread in self.threads.items():
            thread.join(timeout=2.0)
            if thread.is_alive():
                logger.warning(f"SimpleHolisticTracker: thread for cam {cam_id} did not exit in time")

        # Clear state
        self.in_queues.clear()
        self.out_queues.clear()
        self.threads.clear()

        # Hygienic gc.collect() - clears Python references but does NOT release
        # TFLite's C++ allocated memory (~500MB per tracker). Only process
        # termination releases that memory. See: multiprocessing refactor issue.
        gc.collect()

        logger.debug("SimpleHolisticTracker cleanup complete")
