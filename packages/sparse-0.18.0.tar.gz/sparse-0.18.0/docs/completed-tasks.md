[Completed tasks](roadmap.md#completed-tasks)
