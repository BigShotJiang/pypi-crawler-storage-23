"""TOML configuration loader for vauban pipelines."""

from vauban.config._loader import load_config

__all__ = [
    "load_config",
]
