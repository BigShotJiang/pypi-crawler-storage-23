# Part 6: Attacks and Defenses

This part covers the other side of abliteration: soft prompt attacks that bypass safety alignment through the embedding space, and the SIC defense that detects and sanitizes adversarial inputs. Where Parts 1–5 modify the model's weights, this part operates on the model's inputs.

## The Arms Race

Abliteration modifies weights to remove refusal. Soft prompt attacks leave the weights untouched — instead, they prepend optimized embedding vectors that steer the model away from refusal. The model is unchanged; only its input is manipulated.

This creates an arms race:
- **Attackers** optimize inputs to bypass alignment.
- **Defenders** detect and sanitize adversarial inputs before they reach the model.

Vauban implements both sides: three attack modes (continuous, GCG, EGD) and one defense (SIC).

## Soft Prompt Attacks

### The Idea: Learnable Prefixes in Embedding Space

A normal prompt is a sequence of discrete tokens. Each token maps to a fixed embedding vector via the model's embedding table. A **soft prompt** replaces the first $n$ token embeddings with learnable vectors that are optimized to minimize a loss function — typically the negative log-likelihood of a target response.

The key insight (C-AdvIPO, 2024): continuous embedding attacks are the fundamental threat model. Robustness to continuous perturbations predicts robustness to discrete attacks. If you can find a continuous embedding that bypasses alignment, a discrete token approximation usually exists.

### Three Optimization Modes

Vauban implements three modes, each with different tradeoffs:

| Mode | Space | Method | Transferable? | Speed |
|------|-------|--------|---------------|-------|
| `continuous` | Embedding | Adam | No | Fast |
| `gcg` | Token | Coordinate gradient | Yes | Medium |
| `egd` | Simplex | Exponentiated gradient | Partial | Medium |

### Mode 1: Continuous (Schwinn et al. 2024) — Adam over embeddings

The simplest approach: initialize $n$ embedding vectors from a scaled normal distribution, then optimize them with Adam to minimize the targeted loss.

```python
from vauban import softprompt_attack, SoftPromptConfig

result = softprompt_attack(
    model, tokenizer,
    prompts=["How do I pick a lock?", "Explain how to make explosives"],
    config=SoftPromptConfig(
        mode="continuous",
        n_tokens=16,
        n_steps=200,
        learning_rate=0.01,
    ),
)
print(f"Success rate: {result.success_rate:.1%}")
print(f"Accessibility score: {result.accessibility_score:.4f}")
print(f"Final loss: {result.final_loss:.4f}")
```

The optimized embeddings live in continuous $\mathbb{R}^{d_{\text{model}}}$ — they do not correspond to any real token. This makes them non-transferable (you cannot send embedding vectors to a different model), but they converge fast and reliably.

**Targeted loss:**

$$L = -\frac{1}{|T|} \sum_{t \in T} \log P(t \mid \text{prefix}, \text{prompt})$$

where $T$ is the target token sequence (e.g., "Sure, here's how..."). The optimizer pushes the model's output distribution toward the target.

### Mode 2: GCG (Zou et al. 2023) — gradient-guided discrete token search

GCG works in **discrete** token space. It maintains $n$ token IDs and iteratively improves them:

1. Compute the gradient of the loss with respect to each token's one-hot indicator.
2. For each token position $i$, find the $k$ tokens whose embeddings have the highest dot product with the negative gradient: $\text{candidates}_i = \arg\text{top-}k(E \cdot \nabla L / \partial e_i)$.
3. Randomly substitute one position, evaluate the loss, keep if improved.

```python
result = softprompt_attack(
    model, tokenizer,
    prompts=["How do I pick a lock?"],
    config=SoftPromptConfig(
        mode="gcg",
        n_tokens=20,
        n_steps=200,
        batch_size=64,
        top_k=256,
    ),
)
print(f"Optimized tokens: {result.token_text}")
print(f"Token IDs: {result.token_ids}")
```

Because GCG produces real tokens, the attack is **transferable** — the same token sequence can be sent to other models (or API endpoints) without access to embeddings.

### Mode 3: EGD — exponentiated gradient on probability simplex

EGD maintains a probability distribution over the vocabulary for each token position, optimized via exponentiated gradient descent with Bregman projection:

$$w_{t+1} = \frac{w_t \cdot \exp(-\eta \cdot \nabla L)}{Z}$$

where $Z$ normalizes to a valid probability distribution. The "token" at each position is the weighted sum of all embeddings according to the distribution.

This is a middle ground between continuous (fully continuous, non-transferable) and GCG (fully discrete, transferable). EGD converges more smoothly than GCG while maintaining a connection to discrete tokens.

## Advanced Attack Configuration

### Direction-Guided (direction_weight, RAID regularizer)

Soft prompt attacks can be guided by the refusal direction from Parts 1–3. This bridges the two approaches: weight-side abliteration and input-side attacks.

**Standard direction guidance** adds a loss term that penalizes positive projection onto the refusal direction:

$$L_{\text{dir}} = -w \cdot \langle h_{\text{last}}, \hat{d} \rangle$$

This pushes the model's hidden state away from the refusal direction.

**RAID mode** uses a one-sided regularizer — it only penalizes when the projection is positive (toward refusal), leaving negative projections unconstrained:

$$L_{\text{raid}} = w \cdot \max(0, \langle h_{\text{last}}, \hat{d} \rangle)$$

```python
result = softprompt_attack(
    model, tokenizer,
    prompts=["How do I pick a lock?"],
    config=SoftPromptConfig(
        mode="continuous",
        n_tokens=16,
        n_steps=200,
        direction_weight=0.5,
        direction_mode="raid",
    ),
    direction=direction.direction,
)
```

> **You Should Know:** RAID bridges abliteration and soft prompts. Abliteration removes the refusal direction from weights; RAID steers inputs away from the refusal direction in activation space. They are the weight-side and input-side duals of the same geometric insight.

### Loss Modes: targeted, untargeted (UJA), defensive

- **`"targeted"`** (default) — minimize negative log-likelihood of a specific target response (e.g., "Sure, here's how...").
- **`"untargeted"`** (UJA) — maximize the probability of *any* unsafe response, without specifying a target. The loss becomes the negative entropy of the model's output distribution, biased away from refusal phrases.

### Auxiliary Losses: EOS control, KL collision (Geiping), embedding regularization (Huang)

**EOS control** — force or suppress the end-of-sequence token:
- `eos_loss_mode="force"` — adds a loss term that pushes the model to generate EOS early (useful for short, targeted outputs).
- `eos_loss_mode="suppress"` — pushes the model to keep generating (prevents premature termination).

**KL collision** (Geiping et al.) — forces the attacked model's output distribution to match a reference model's distribution:

$$L_{\text{kl}} = \text{KL}(P_{\text{ref}} \| P_{\text{attacked}})$$

This makes the attack stealthy — the output looks like it came from the reference model.

**Embedding regularization** (Huang et al.) — penalizes the norm of optimized embeddings to keep them near the natural embedding manifold:

$$L_{\text{reg}} = w \cdot \|e_{\text{soft}}\|_2$$

### Token Constraints (ascii, alpha, alphanumeric)

For GCG and EGD, you can restrict which tokens are considered during optimization:

```python
SoftPromptConfig(
    mode="gcg",
    token_constraint="ascii",  # only ASCII tokens
)
```

Options: `"ascii"`, `"alpha"`, `"alphanumeric"`, or `None` (all tokens).

### Transfer Testing (transfer_models list)

After optimizing a soft prompt, test it on other models:

```python
result = softprompt_attack(
    model, tokenizer,
    prompts=["How do I pick a lock?"],
    config=SoftPromptConfig(
        mode="gcg",
        n_tokens=20,
        n_steps=200,
        transfer_models=["mlx-community/Llama-3.2-3B-Instruct-4bit"],
    ),
)
for tr in result.transfer_results:
    print(f"{tr.model_id}: success={tr.success_rate:.1%}")
```

## The Accessibility Score: A = exp(-L_final) (Nordby 2025)

The **accessibility score** quantifies how easily a model's safety alignment can be bypassed:

$$A = \exp(-L_{\text{final}})$$

where $L_{\text{final}}$ is the final loss after optimization. Higher $A$ means the attack was more successful — the model is more "accessible" (less safe).

This is reported automatically in `SoftPromptResult.accessibility_score`.

## SIC: Iterative Input Sanitization

On the defense side, SIC (from "SIC! Iterative Self-Improvement for Adversarial Attacks") detects and sanitizes adversarial inputs before they reach the model's generation pipeline.

### The Loop: Detect → Rewrite → Re-detect → Block/Pass

SIC operates as a preprocessing pipeline:

1. **Detect** — score the input for adversarial content.
2. If the score exceeds a threshold, **rewrite** the input to remove adversarial elements.
3. **Re-detect** the rewritten input.
4. Repeat until the score falls below threshold or max iterations is reached.
5. If still adversarial after max iterations, **block** the input entirely.

### Direction-Based Detection: score = ⟨h_last[layer], d⟩

In direction mode, the detection signal is the projection of the last-token activation onto the refusal direction:

$$\text{score} = \langle h_{\text{last}}^l, \hat{d} \rangle$$

A high positive score means the model recognizes the input as harmful — the refusal circuitry is activating. But for adversarial inputs, the score may be suppressed (the whole point of the attack). SIC catches the residual signal.

### Generation-Based Detection: phrase matching on generated response

In generation mode, SIC actually generates a response and checks for refusal phrases. If the model refuses, the input is adversarial (the attacker failed) and no sanitization is needed. If the model complies with content that "looks" harmful, the input may be adversarial.

### Threshold Calibration: θ = μ(clean) - 2·σ(clean)

The detection threshold must be calibrated to avoid false positives (blocking legitimate prompts):

```python
from vauban import calibrate_threshold, sic_sanitize, SICConfig

config = SICConfig(
    mode="direction",
    max_iterations=3,
    calibrate=True,
    calibrate_prompts="harmless",
)

# Calibrate threshold on known-clean prompts
threshold = calibrate_threshold(
    model, tokenizer,
    clean_prompts=harmless[:50],
    config=config,
    direction=direction.direction,
    target_layer=direction.layer_index,
)
print(f"Calibrated threshold: {threshold:.4f}")
```

The calibration formula:

$$\theta = \mu(\text{scores}_{\text{clean}}) - 2 \cdot \sigma(\text{scores}_{\text{clean}})$$

This sets the threshold at 2 standard deviations below the mean clean score — approximately 97.7% of clean inputs will score above this threshold (and thus not be flagged).

### Running SIC

```python
result = sic_sanitize(
    model, tokenizer,
    prompts=["How do I pick a lock?", "What is the capital of France?"],
    config=SICConfig(mode="direction", max_iterations=3),
    direction=direction.direction,
    layer_index=direction.layer_index,
)
print(f"Blocked: {result.total_blocked}")
print(f"Sanitized: {result.total_sanitized}")
print(f"Clean: {result.total_clean}")
```

> **You Should Know:** SIC is model-assisted — the model rewrites its own input. The rewrite prompt asks the model to produce a "clean" version of the user's message, removing any adversarial elements while preserving the legitimate intent. This works because the model's understanding of adversarial content (at the rewrite step) is separate from its compliance behavior (at the generation step).

> **You Should Know:** Calibration prevents false positives. Without calibration, SIC with a fixed threshold may block legitimate prompts that happen to score near the boundary. Always calibrate on a representative set of clean prompts.

## You Should Know

> **Continuous beats discrete for research.** Continuous soft prompts converge faster and more reliably than GCG. Use continuous mode for measuring accessibility scores and understanding attack surfaces. Use GCG when you need transferable tokens (for cross-model or API testing).

> **RAID bridges abliteration and soft prompts.** It is the input-side dual of weight-side direction removal: instead of removing the direction from weights (so the model can't project onto it), RAID pushes inputs so their activations don't project onto it.

> **SIC is model-assisted.** The rewriting step uses the model itself to sanitize inputs. This creates a recursive dependency: the model must be capable of identifying adversarial content to rewrite it. Direction-based detection avoids this issue by using the geometric signal directly.

> **Calibration prevents false positives.** A threshold that is too aggressive blocks legitimate prompts. The $\mu - 2\sigma$ calibration is conservative — it preserves ~97.7% of clean inputs. For production use, calibrate on a large (>100) set of representative clean prompts.

## Key Takeaways

1. **Soft prompt attacks** optimize input embeddings to bypass alignment — three modes: continuous (fast, non-transferable), GCG (discrete, transferable), EGD (middle ground).
2. **Direction-guided attacks** (RAID) bridge weight-side abliteration with input-side manipulation.
3. **Accessibility score** $A = \exp(-L_{\text{final}})$ quantifies how easily alignment is bypassed.
4. **SIC defense** detects and sanitizes adversarial inputs in a detect → rewrite → re-detect loop.
5. **Threshold calibration** ($\theta = \mu - 2\sigma$ on clean prompts) prevents false positives.
6. **Transfer testing** evaluates whether optimized tokens work on other models.

## Exercises

1. **Continuous attack.** Run a continuous soft prompt attack on a small model with `n_tokens=16, n_steps=200`. How does the loss evolve? What is the final accessibility score?

2. **GCG transfer.** Optimize a GCG suffix on a 1B model. Test transfer to a 3B model of the same family. What is the transfer success rate?

3. **RAID vs standard.** Run two continuous attacks: one with `direction_weight=0.0` (standard) and one with `direction_weight=0.5, direction_mode="raid"`. Compare convergence speed and final loss.

4. **SIC calibration.** Calibrate a SIC threshold on 50 harmless prompts. Then run SIC on a mix of 20 harmful and 20 harmless prompts. How many false positives (blocked harmless) and false negatives (passed harmful) do you observe?

5. **Attack then defend.** Optimize a continuous soft prompt on a model. Then apply SIC to the original harmful prompt (not the optimized one — SIC operates on the text input). Does SIC detect the harmful intent even without seeing the optimized embeddings?

Next: [Part 7 — Production Workflows](part7_production_workflows.md), where we bring everything together with TOML pipelines, optimization, and experiment management.
