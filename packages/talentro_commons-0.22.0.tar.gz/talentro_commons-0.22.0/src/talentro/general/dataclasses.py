from abc import abstractmethod, ABC
from enum import StrEnum
from typing import Optional, TypeVar, Generic
from uuid import UUID

from pydantic import BaseModel


T = TypeVar("T")


class SelectionMethod(StrEnum):
    LIST = 'list'
    ALL = 'all'
    RULES = 'rules'

class Operator(StrEnum):
    EQ = 'eq'
    NEQ = 'neq'
    GT = 'gt'
    GTE = 'gte'
    LT = 'lt'
    LTE = 'lte'
    IN = 'in'
    NIN = 'nin'
    REGEX = 'regex'
    LIKE = 'like'
    I_LIKE = 'iLike'
    EXISTS = 'exists'
    NOT_EXISTS = 'notExists'


class ResolvableModel(BaseModel, ABC):

    @staticmethod
    @abstractmethod
    async def resolve_object(object_id: UUID) -> "ResolvableModel":
        pass


class ResolvableCompanyModel(BaseModel, ABC):

    @staticmethod
    @abstractmethod
    async def resolve_object(object_id: UUID, organization_id: str) -> "ResolvableCompanyModel":
        pass


class DropdownOption(BaseModel):
    value: str
    label: str
    detail: str | None = None


class VacancySelectionRule(BaseModel):
    field: str
    operator: Operator
    value: Optional[str] = None


class VacancySelectionCriteria(BaseModel):
    method: SelectionMethod
    rules: Optional[list[VacancySelectionRule]] = None
    selected_ids: Optional[list[str]] = None


class FileData(BaseModel):
    file_name: str
    data: str
    content_type: str


class PaginatedResponse(BaseModel, Generic[T]):
    results: list[T]
    total_count: int