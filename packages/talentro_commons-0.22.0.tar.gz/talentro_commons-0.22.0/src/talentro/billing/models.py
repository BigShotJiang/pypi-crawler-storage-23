from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from sqlalchemy import Column, JSON
from sqlmodel import SQLModel, Field

from ..general.models import BaseModel


class BillingModel(BaseModel):
    pass


class BillingOrganizationModel(BillingModel):
    organization: UUID = Field(index=True)


class BillingEvent(SQLModel, table=True):
    id: int = Field(
        primary_key=True,
    )

    organization: UUID = Field(index=True)
    event_time: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    event_meter: str = Field(nullable=False)
    product_id: str = Field(nullable=False, default="product_id")
    count: int = Field(nullable=False, default=1)
    meta_data: dict = Field(sa_column=Column(JSON))
    sent_to_stripe: bool = Field(default=False)


class BillingProfile(BillingOrganizationModel, table=True):
    stripe_customer_id: str = Field(nullable=False)


class Product(BillingModel, table=True):
    key: str = Field(primary_key=True)
    stripe_product_id: str = Field(nullable=False)