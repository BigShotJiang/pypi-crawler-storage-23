import os
from enum import StrEnum


class EventMeter(StrEnum):
    SYNCED_VACANCY = 'vacancy_sync'
    ENHANCE_VACANCY = 'vacancy_enhance'
    NEW_APPLICATION = 'application_new'


class ProductId(StrEnum):
    SYNCED_VACANCY = "vacancy_sync"
    ENHANCE_VACANCY = "vacancy_enhance"
    NEW_APPLICATION = "new_application"
