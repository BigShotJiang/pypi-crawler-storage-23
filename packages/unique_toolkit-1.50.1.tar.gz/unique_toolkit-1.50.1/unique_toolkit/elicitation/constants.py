DOMAIN_NAME = "elicitation"
