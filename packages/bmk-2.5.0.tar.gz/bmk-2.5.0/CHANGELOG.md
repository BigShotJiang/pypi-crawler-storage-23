# Changelog

All notable changes to this project will be documented in this file following
the [Keep a Changelog](https://keepachangelog.com/) format.


## [Unreleased]

## [2.5.0] 2026-02-24

### Added
- **JSON mode output suppression**: stagerunner captures all tool output in JSON mode and only displays it when a stage fails — a fully passing run produces zero tool output, designed for LLM-driven workflows to minimize context window consumption
- **Makefile auto-update in JSON mode**: `check_makefile_update()` auto-accepts Makefile version updates without prompting when `BMK_OUTPUT_FORMAT` is not `text`
- **JSON mode auto-accept for dependency updates**: `_dependencies.py` runs silently in JSON mode — no report, no per-dependency output, no summary
- **Pytest concise mode**: in JSON mode, pytest runs with `--tb=short -q --no-header` and coverage report display is suppressed

## [2.4.0] 2026-02-24 11:20:14

### Added
- **JSON-by-default output**: `bmk test` and `bmk testintegration` now emit JSON output from tools (ruff, pyright, bandit, pip-audit, shellcheck, PSScriptAnalyzer) for machine-readable consumption
- **`--human` flag**: use `bmk test --human` or `bmk testintegration --human` to restore traditional text output
- **`BMK_OUTPUT_FORMAT` environment variable**: set to `json` (default) or `text` to control tool output format; `--human` flag takes precedence
- **Virtual environment isolation for uvx**: `execute_script()` now sets `VIRTUAL_ENV` to the target project's `.venv/` (if present) or unsets it, ensuring pyright, pip-audit, and other tools resolve packages from the correct environment

### Changed
- **Stage scripts read `BMK_OUTPUT_FORMAT`**: all `.sh` and `.ps1` stage scripts now read the environment variable and pass tool-specific JSON flags accordingly
- **Python helpers accept `--output-format`**: `_shellcheck.py`, `_psscriptanalyzer.py`, and `_coverage.py` accept a new `--output-format` CLI argument
- **Dependency floors updated**: `hatchling >=1.28.0 → >=1.29.0`, `hypothesis >=6.151.6 → >=6.151.9`, `lib_layered_config >=5.4.0 → >=5.4.1`, `ruff >=0.15.1 → >=0.15.2`, `textual >=7.5.0 → >=8.0.0`

### Fixed
- **CI/CD runner configuration**: fixed runner setup in GitHub Actions workflow
- **Bandit configuration**: bandit now reads settings from `pyproject.toml`
- **Clean list**: added `.venv` to clean targets; removed `.idea` directory from repository

## [2.3.3] 2026-02-13 20:23:26

### Removed
- **test_900_clean stage**: removed `test_900_clean.sh` and `test_900_clean.ps1` from the test pipeline to preserve coverage data for post-test analysis and reporting

### Changed
- **Dependency floors updated**: `lib_cli_exit_tools >=2.2.4 → >=2.3.0`, `lib_log_rich >=6.3.1 → >=6.3.3`

## [2.3.2] 2026-02-13 18:14:14

### Fixed
- **Makefile alias targets firing as prerequisites during argument forwarding**: `make push coverage test` no longer executes the real `codecov` target — alias targets (`coverage cov:`, `t:`, `bld:`, `cln cl:`, `c:`, `psh p:`, `rel r:`, `deps d:`, `testi ti:`) now use standalone recipes instead of prerequisite chains, allowing the trailing-argument no-op override block to properly suppress them; GNU Make accumulates prerequisites across rules (never overridden), but recipes follow "last rule wins"

## [2.3.1] 2026-02-13 17:59:34

### Added
- **Comprehensive makescript test coverage**: added 146 new tests across four makescript modules, raising overall project coverage from 83% to 95%
  - `test_makescripts_dependencies.py` (79 tests): version parsing, PyPI queries, dependency extraction (optional deps, build system, poetry, pdm, uv, dependency-groups), reporting, pyproject.toml updating, pip sync
  - `test_makescripts_coverage.py` (93 tests): CoverageConfig loading, file pruning, report artifacts, env building, test execution, dotenv search, codecov token discovery, git resolution, upload workflow
  - `test_makescripts_run.py` (+9 tests): `run_cli()` invocation — command construction, exit code propagation, empty project name error, default `--help`, local dependency `--with` flags
  - `test_makescripts_psscriptanalyzer.py` and `test_makescripts_shellcheck.py`: full behavioural coverage for config reading, tool detection, file discovery, and orchestration

### Changed
- **Coverage threshold raised from 70% to 80%** in `[tool.coverage.report].fail_under` to lock in test coverage gains
- **Prerequisite checker refactored**: extracted `_append_psscriptanalyzer_check()` helper to DRY the PSScriptAnalyzer module check shared between `_posix_tools()` and `_windows_tools()`
- **CI metadata extraction uses rtoml**: replaced `tomllib`/`tomli` with `rtoml` in `.github/actions/extract-metadata` and pip-audit step; removed the `Install tomli (Python < 3.11)` step
- **CI installs bash 4+ on macOS**: new step installs modern bash via Homebrew for stagerunner array feature compatibility
- **CI installs `[dev]` extras**: `uv pip install -e .` changed to `uv pip install -e .[dev]`
- **CI uses `pytest` directly**: replaced `python -m pytest` with `pytest` in test step
- **CI sets `UV_BREAK_SYSTEM_PACKAGES=1`**: allows uv to install into system Python environments without error

### Fixed
- **pip-audit CVE exclusion**: added `CVE-2026-26007` (cryptography 46.0.3) to `[tool.pip-audit].ignore-vulns`
- **pyright strict error in test file**: added `reportUnknownVariableType=false` pragma to `test_makescripts_dependencies.py` for dynamically-typed `_toml_config` imports

## [2.3.0] 2026-02-13 14:01:44

### Added
- **PSScriptAnalyzer lint stage** (`test_040_psscriptanalyzer`): new makescript that lints all `.ps1` files via PSScriptAnalyzer, with excluded rules driven by `[tool.psscriptanalyzer]` in `pyproject.toml`; auto-installs the PowerShell module if absent
- **Shell lint stage** (`test_060_shellcheck`): new makescript that runs shellcheck, shfmt, and bashate against all `.sh` files, with bashate settings driven by `[tool.bashate]` in `pyproject.toml`; Windows `.ps1` variant skips gracefully
- **Prerequisite checking on `bmk install`**: after Makefile deployment, prints a diagnostic summary showing which external tools (git, pwsh, shellcheck, shfmt, bashate, PSScriptAnalyzer) are found or missing, with platform-appropriate install hints (apt on Linux, brew on macOS, winget on Windows); report is informational only and always displays even when Makefile deployment is skipped
- **New runtime dependencies**: `shellcheck-py`, `shfmt-py`, `bashate`, `hatchling` (build system, added to runtime deps by design)
- **TOML config models**: `PSScriptAnalyzerConfig` and `BashateConfig` dataclasses in `_toml_config.py` for reading `[tool.psscriptanalyzer]` and `[tool.bashate]` sections

### Changed
- **Test clean stage renumbered**: `test_050_clean` → `test_900_clean` to make room for new lint stages (PSScriptAnalyzer at 040, shellcheck at 060)
- **PowerShell scripts require pwsh 7+**: added `#Requires -Version 7.0` to stagerunner and key makescripts; replaced PS 5.1 compat workarounds (`[char]0x1B`, `if/else` ternaries) with native pwsh 7 syntax (`` `e ``, `??`, `?:`)
- **Script executor uses `pwsh`**: `_shared.py` now invokes `.ps1` scripts via `pwsh -NoProfile -NonInteractive` instead of `powershell -ExecutionPolicy Bypass`
- **PowerShell naming conventions**: renamed `Explain-ExitCode` to `Write-ExitCodeError` (approved verb), `Get-UniqueStages` to `Get-UniqueStage` (singular); replaced `Write-Host` with `Write-Output` where appropriate
- **Commit script quoting fix**: `commit_010_commit.sh` now properly quotes `$sensitive_files` in `printf` to prevent word splitting
- **Clean warning built dynamically**: `_clean.py` replaces static `_MISSING_SECTION_WARNING` string with `_build_missing_section_warning()` generated from `_FALLBACK_PATTERNS`

### Removed
- **`hello` command and `behaviors.py` domain module**: removed `cli_hello`, `build_greeting()`, and `CANONICAL_GREETING` — template scaffolding no longer needed

## [2.2.2] 2026-02-13 11:02:42

### Changed
- **`make clean` warns on missing `[tool.clean]` config**: prints a warning with example `[tool.clean].patterns` section to stderr when `pyproject.toml` exists but has no clean patterns configured
- **Makefile update no longer aborts the command**: accepting a Makefile version update now continues running the original subcommand instead of exiting

## [2.2.1] 2026-02-13 10:35:26

### Fixed
- **`make dev` now installs `[dev]` extras**: changed `uv pip install -e "."` to `uv pip install -e ".[dev]"` so customers with a `[dev]` optional-dependencies group get those extras installed

## [2.2.0] 2026-02-11 22:09:03

### Changed
- **Extracted inline Python to standalone scripts**: moved inline `python -c` code from stagerunners and `test_040_pip_audit` into `_derive_package_name.py` and `_extract_pip_audit_ignores.py`, eliminating the temp-file write-execute-delete pattern that triggered Windows Defender false positives
- **Makefile local-dev invocation**: replaced `uvx --reinstall` (no longer supported) with `uv cache prune --quiet && uvx --refresh`

### Fixed
- **Windows Defender false positive**: the stagerunner's temp-file pattern (write Python to `.py`, execute, delete) was flagged as a malicious "script dropper"; standalone `.py` scripts eliminate the trigger entirely

## [2.1.0] 2026-02-11 21:13:49

### Added
- **Shared Python resolver for makescripts**: new `_resolve_python.ps1` and `_resolve_python.sh` helpers that all makescripts source to find the correct Python interpreter
- **`BMK_PYTHON_CMD` propagation**: the Python CLI passes `sys.executable` via `BMK_PYTHON_CMD` environment variable; all shell and PowerShell makescripts now honour it, ensuring the uvx-managed interpreter is used instead of whatever `python`/`python3` is in PATH

### Fixed
- **Windows Python detection across all PS1 makescripts**: replaced hardcoded `python3` with resolved `$BMK_PYTHON_CMD` in all 15 PowerShell stage scripts; the resolver skips the Windows Store alias stub (exit code 9009) by filtering out `Microsoft\WindowsApps` paths via `Get-Command -All`
- **Bash makescripts use resolved Python**: replaced hardcoded `python3` with `"$BMK_PYTHON_CMD"` in all 15 bash stage scripts for consistency with the PowerShell side
- **PowerShell ANSI color codes**: replaced `` `e `` escape (PowerShell 7+ only) with `[char]0x1B` for Windows PowerShell 5.1 compatibility
- **PowerShell `python -c` multiline string failure**: `test_040_pip_audit.ps1` now writes inline Python code to a temp file (same approach as stagerunner) instead of passing via `-c`
- **Stagerunner `Invoke-SingleScript` output leaking into return value**: captured stdout via `2>&1` and replayed via `Write-Host` to prevent PowerShell from including script output in the function's return value
- **Stagerunner parallel job error handling**: wrapped `Start-Job` script blocks in `try/catch` to prevent `$ErrorActionPreference = "Stop"` in child scripts from turning stderr into terminating errors in PS 5.1

## [2.0.16] 2026-02-11 19:36:31

### Fixed
- **Stagerunner Python command detection**: both `_btx_stagerunner.ps1` and `_btx_stagerunner.sh` now detect the available Python command (`python` / `python3`) instead of hardcoding `python3`, fixing failures on Windows where only `python` exists

## [2.0.15] 2026-02-11 19:03:25

### Fixed
- **Coverage threshold reverted to 70%**: Windows CI has lower coverage due to platform-specific code paths; `fail_under` set back to 70 for cross-platform compatibility

## [2.0.14] 2026-02-11 18:57:25

### Changed
- **Shared script infrastructure moved to `_shared.py`**: extracted `execute_script`, `get_script_name`, `normalize_returncode`, and `resolve_script_path` from `test_cmd.py` into `_shared.py`; all 12 command modules now import from the shared module
- **Renamed `test_cmd.py` to `testsuite_cmd.py`**: avoids confusion with test files; file now contains only `cli_test` and `cli_t` click commands
- **Eliminated `execute_custom_script` duplication**: `custom_cmd.py` now reuses `execute_script` from `_shared.py` instead of maintaining a near-identical copy
- **Coverage threshold raised**: `fail_under` increased from 70% to 73% to better guard against regressions

### Fixed
- **`install_cmd.py` missing structured logging context**: added `lib_log_rich.runtime.bind(job_id="cli-install")` for consistency with all other CLI commands
- **`build_cmd.py` phantom alias in docstring**: removed reference to nonexistent `cli_b` short alias (that alias belongs to the bump command)
- **`install_cmd.py` leaking private function in `__all__`**: removed `_extract_version` from public exports

## [2.0.13] 2026-02-11 13:15:15

### Fixed
- **Warning scanner false positives**: exclude summary lines containing `N warnings` (e.g. pyright's `0 errors, 0 warnings, 0 informations`) from stagerunner warning output in both bash and PowerShell

## [2.0.12] 2026-02-11 12:54:51

### Fixed
- **Makefile argument forwarding**: trailing words matching real target names (e.g. `make push codecov fix`) no longer execute those targets as separate commands; replaced `$(eval)` no-ops (overridden by later target definitions) with a regular rule block at end of Makefile using GNU Make's "last rule wins" behavior

## [2.0.11] 2026-02-11 12:47:59

### Changed
- **Codecov token warning color**: changed from bright red (`\033[91m`) to yellow (`\033[33m`) to match stagerunner warning styling

## [2.0.10] 2026-02-11 12:41:22

### Fixed
- **Missing codecov token not surfaced by warning scanner**: `_coverage.py` message changed from `[codecov] CODECOV_TOKEN not found` to `[codecov] warning: CODECOV_TOKEN not found` so the stagerunner warning scanner picks it up

## [2.0.9] 2026-02-11 12:28:32

### Added
- **Show warnings from passing parallel stagerunner jobs**: output from successful parallel scripts is scanned for lines containing "warning" (case-insensitive) and displayed in yellow after the pass/fail summary
- New `[bmk].show_warnings` config option (default `true`) to control warning display; set `BMK_SHOW_WARNINGS=0` or `show_warnings = false` in config to suppress
- `print_warnings_from_passed()` in bash stagerunner and `Show-WarningsFromPassed` in PowerShell stagerunner

### Fixed
- **PowerShell stagerunner exit code display bug**: failed-job output header showed raw output instead of exit code (`$failedOutput[$scriptName]` → `$exitCodes[$scriptName]`)

## [2.0.8] 2026-02-11 12:23:30

### Changed
- **Root Makefile switched to local dev source**: `BMK` variable now uses `uvx --refresh --from /path bmk` instead of `uvx bmk@latest`, and sentinel line removed to prevent `bmk install` from overwriting local changes

## [2.0.7] 2026-02-11 01:43:23

## [2.0.6] 2026-02-11 01:28:04

### Added
- **Auto-sync bundled Makefile version from `pyproject.toml`**: `_sync_initconf.py` now also patches the `# BMK MAKEFILE X.Y.Z` sentinel on line 1 of `src/<pkg>/makefile/Makefile`, keeping it in sync alongside `__init__conf__.py` after version bumps

## [2.0.5] 2026-02-11 00:39:28

### Changed
- **Stage delegator scripts show delegation flow**: replaced generic announcements with `delegator → target pipeline` messages (e.g. `push_040_commit → commit pipeline`) so pipeline nesting is visible in output

## [2.0.4] 2026-02-10 23:12:40

### Fixed
- **Duplicate log messages in stage delegator scripts**: removed redundant printf/Write-Host from 8 delegator scripts (.sh + .ps1 pairs) whose inner pipelines already print their own announcements (e.g. `test_050_clean.sh` → `clean_010_clean.sh`, `push_020_build.sh` → `bld_020_build.sh`, `push_040_commit.sh` → `commit_010_commit.sh`)

## [2.0.3] 2026-02-10 22:56:06

### Added
- **Auto-sync `__init__conf__.py` version from `pyproject.toml`**: new `_sync_initconf.py` makescript patches the `version` line after every bump and before every commit, preventing version mismatch test failures
- Stage scripts `bump_{patch,minor,major}_020_sync_initconf.{sh,ps1}` run sync immediately after version bumps
- Stage script `commit_005_sync_initconf.{sh,ps1}` runs sync as a safety net before every commit

### Fixed
- **Makefile recipe override warning**: `make push test parameters` no longer warns about overriding the `test` target recipe — extra arguments that collide with existing target names are now skipped in the no-op eval

## [2.0.2] 2026-02-10 22:35:34

### Fixed
- **Stagerunner parallel output**: announce tasks upfront (`▶ running N tasks in parallel: ...`) and print all results together after completion instead of trickling one-by-one in arbitrary order
- **Makescript Python scripts reject unknown arguments**: changed `parse_args()` to `parse_known_args()` in all 5 makescript entry points so forwarded pipeline arguments (e.g. commit messages from `bmk push`) no longer cause errors
- **pip-audit false positives**: added `CVE-2025-8869` (pip) and `PYSEC-2022-42969` (py) to ignore-vulns

## [2.0.1] - 2026-02-10

### Removed
- Unnecessary transitive CVE pins: `wheel`, `python-multipart`, `pynacl`, `virtualenv` (not in bmk's dependency tree)

## [2.0.0] - 2026-02-10

### Added
- **initial official release**

## [1.3.0] - 2026-02-01

### Added
- **File permission options for `config-deploy`**: `--permissions/--no-permissions`, `--dir-mode`, `--file-mode`
- **Configurable permission defaults** in `[lib_layered_config.default_permissions]` (app/host: 755/644, user: 700/600)
- **Octal string support** in config files (`"0o755"`, `"755"`, or decimal `493`)

### Changed
- `deploy_configuration()` accepts `set_permissions`, `dir_mode`, `file_mode` parameters
- CONFIG.md: comprehensive CLI options reference, `sudo -u` deployment examples

## [1.2.1] - 2026-02-01

### Changed
- **Profile validation** now delegates to `lib_layered_config.validate_profile_name()` with comprehensive security checks:
  - Maximum length enforcement (64 characters)
  - Empty string rejection
  - Windows reserved name rejection (CON, PRN, AUX, NUL, COM1-9, LPT1-9)
  - Leading character validation (must start with alphanumeric)
  - Path traversal prevention (/, \, ..)
- `validate_profile()` now accepts optional `max_length` parameter for customization

### Added
- `40-layered-config.toml` in `defaultconfig.d/` documenting lib_layered_config integration settings
- Profile validation tests for length limits, empty strings, Windows reserved names, and leading character rules
- Profile name requirements documentation in CONFIG.md and README.md

### Removed
- Custom `_PROFILE_PATTERN` regex — replaced by lib_layered_config's built-in validation

## [1.2.0] - 2026-01-30

### Added
- **Attachment security settings** for email configuration (`[email.attachments]` section in `50-mail.toml`)
  - `allowed_extensions` / `blocked_extensions` — whitelist/blacklist file extensions
  - `allowed_directories` / `blocked_directories` — whitelist/blacklist attachment source directories
  - `max_size_bytes` — maximum attachment file size (default 25 MiB, 0 to disable)
  - `allow_symlinks` — whether symbolic links are permitted (default false)
  - `raise_on_security_violation` — raise or skip on violations (default true)
- New `EmailConfig` fields for attachment security with Pydantic validators
- `load_email_config_from_dict()` now flattens nested `[email.attachments]` section

### Changed
- Bumped `btx_lib_mail` dependency from `>=1.2.1` to `>=1.3.0` for attachment security features

## [1.1.2] - 2026-01-28

### Fixed
- Coverage SQLite "database is locked" errors on Python 3.14 free-threaded builds and network mounts (SMB/NFS)
- Removed bogus `COVERAGE_NO_SQL=1` environment variable from `scripts/test.py` (not a real coverage.py setting)
- CI workflow now sets `COVERAGE_FILE` to `runner.temp` so coverage always writes to local disk
- **Import-linter was a silent no-op** in `make test` / `make push` — `python -m importlinter.cli lint` silently exits 0 without checking; replaced with `lint-imports` (the working console entry point)
- CI/local parameter mismatches: ruff now targets `.` (not hardcoded `src tests notebooks`), pytest uses `python -m pytest` with `--cov=src/$PACKAGE_MODULE`, `--cov-fail-under=90`, and `-vv` matching local runs
- `scripts/test.py` bandit source path now reads `src-path` from `[tool.scripts.test]` instead of hardcoding `Path("src")`
- `scripts/test.py` module-level `_default_env` now rebuilt with configured `src_path` before running checks
- `run_slow_tests()` now reads pytest verbosity from `[tool.scripts.test].pytest-verbosity` instead of hardcoding `"-vv"`

### Changed
- **pyproject.toml as single source of truth**: CI workflow extracts all tool configuration (src-path, pytest-verbosity, coverage-report-file, fail_under, bandit skips) from `pyproject.toml` via metadata step — workflow is portable across projects without editing
- `scripts/test.py` removed module-level `PACKAGE_SRC` constant; bandit source path computed from `config.src_path` inside the functions that need it
- `make push` now accepts an unquoted message as trailing words (e.g. `make push fix typo in readme`); commit message format is `<version> - <message>`, defaulting to `<version> - chores` when no message is given
- Removed interactive commit-message prompt from `push.py` — message is either provided via CLI args / `COMMIT_MESSAGE` env var, or defaults to `"chores"`

### Added
- `pytest_configure` hook in `tests/conftest.py` that redirects coverage data to `tempfile.gettempdir()` and purges stale SQLite journal files before each run

## [1.1.1] - 2026-01-28

### Fixed
- CLAUDE.md: replaced stale package name `bitranox_template_cli_app_config_log_mail` with `bmk` throughout
- Brittle SMTP mock assertions in `test_cli.py` now use structured `call_args` attributes instead of `str()` coercion
- Stale docstring in `__init__conf__.py` claiming "adapters/platform layer" — corrected to "Package-level metadata module"
- Weak OR assertion in `test_cli.py` for SMTP host display — replaced with two independent assertions
- Removed stale `# type: ignore[reportUnknownVariableType]` from `sender.py` (`btx_lib_mail.ConfMail` now has proper type annotations)
- Late function-body imports in `adapters/cli/commands/config.py` moved to module-level for consistency

### Removed
- Dead code: unused `_format_value()` and `_format_source()` wrappers in `adapters/config/display.py`

### Added
- `__all__` to `__init__conf__.py` listing all public symbols
- `tests/test_enums.py` with parametrized tests for `OutputFormat` and `DeployTarget`
- Expanded `tests/test_behaviors.py` with return type, constant value, and constant-usage checks
- Python 3.14 classifier in `pyproject.toml`
- Codecov upload step in CI workflow (gated to `ubuntu-latest` + `3.13`)
- Edge-case tests for `parse_override`: bare `=value`, bare `=`, and CLI `--set ""` empty string
- Duplication-tracking comments for CI metadata extraction scripts

### Changed
- `tests/test_display.py` rewritten to test `_format_raw_value` and `_format_source_line` directly (replacing dead wrapper tests)

## [1.1.0] - 2026-01-27

### Changed
- Replaced `MockConfig` in-memory adapter with real `Config` objects in all tests (`config_factory` / `inject_config` fixtures)
- Replaced `MagicMock` Config objects in CLI email tests with real `Config` instances
- Unified test names to BDD-style `test_when_<condition>_<behavior>` pattern in `test_cli.py`
- Email integration tests now load configuration via `lib_layered_config` instead of dedicated `TEST_SMTP_SERVER` / `TEST_EMAIL_ADDRESS` environment variables

### Added
- Cache effectiveness tests for `get_config()` and `get_default_config_path()` LRU caches (`tests/test_cache_effectiveness.py`)
- Callable Protocol definitions in `application/ports.py` for all adapter functions, with static conformance assertions and `tests/test_ports.py`
- `ExitCode` IntEnum (`adapters/cli/exit_codes.py`) with POSIX-conventional exit codes for all CLI error paths
- `logdemo` and `config-generate-examples` CLI commands
- `--set SECTION.KEY=VALUE` repeatable CLI option for runtime configuration overrides (`adapters.config.overrides` module)
- Unit tests for config overrides and display module (sensitive key matching, redaction, nested rendering)

### Removed
- Dead code: `raise_intentional_failure()`, `noop_main()`, `cli_main()`, duplicate `cli_session` orchestration, catch-log-reraise in `send_email()`
- Replaced dead `ConfigPort`/`EmailPort` protocol classes with callable Protocol definitions

### Fixed
- POSIX-conventional exit codes across all CLI error paths (replacing hardcoded `SystemExit(1)`)
- Sensitive value redaction: word-boundary matching to avoid false positives, nested dict/list redaction, TOML sub-section rendering
- Email validation: reject bogus addresses (`@`, `user@`, `@domain`); IPv6 SMTP host support; credential construction
- Profile name validation against path traversal
- Security: list-based subprocess calls in scripts, sensitive env-var redaction in test output, stale CVE exclusion cleanup
- Documentation: wrong project name references, truncated CLI command names, stale import paths, wrong layer descriptions
- CI: `actions/download-artifact` version mismatch, stale `codecov.yml` ignore patterns
- Unified `__main__.py` and `adapters/cli/main.py` error handling via delegation

### Changed
- Precompile all regex patterns in `scripts/` as module-level constants for consistent compilation
- **LIBRARIES**: Replace custom redaction/validation with `lib_layered_config` redaction API and `btx_lib_mail` validators; bump both libraries
- **LIBRARIES**: Replace stdlib `json` with `orjson`; replace `urllib` with `httpx` in scripts
- **ARCHITECTURE**: Purified domain layer — `emit_greeting()` renamed to `build_greeting()` (returns `str`, no I/O); decoupled `display.py` from Click
- **DATA ARCHITECTURE**: Consolidated `EmailConfig` into single Pydantic `BaseModel` (eliminated dataclass conversion chain)

## [1.0.0] - 2026-01-15

### Added
- Slow integration test infrastructure (`make test-slow`, `@pytest.mark.slow` marker)
- `pydantic>=2.0.0` dependency for boundary validation
- `CLIContext` dataclass replacing untyped `ctx.obj` dict
- Pydantic models: `EmailSectionModel`, `LoggingConfigModel`
- `application/ports.py` with Protocol definitions; `composition/__init__.py` wiring layer

### Changed
- **BREAKING**: Full Clean Architecture refactoring into explicit layer directories (`domain/`, `application/`, `adapters/`, `composition/`)
- CLI restructured from monolithic `cli.py` into focused `cli/` package with single-responsibility modules
- Type hints modernized to Python 3.10+ style
- Removed backward compatibility re-exports; tests import from canonical module paths
- `import-linter` contracts enforce layer dependency direction
- `make test` excludes slow tests by default

## [0.2.5] - 2026-01-01

### Changed
- Bumped `lib_log_rich` to >=6.1.0 and `lib_layered_config` to >=5.2.0

## [0.2.4] - 2025-12-27

### Fixed
- Intermittent test failures on Windows when parsing JSON config output (switched to `result.stdout`)

## [0.2.3] - 2025-12-15

### Changed
- Lowered minimum Python version from 3.13 to 3.10; expanded CI matrix accordingly

## [0.2.2] - 2025-12-15

### Added
- Global `--profile` option for profile-specific configuration across all commands

### Changed
- **BREAKING**: Configuration loaded once in root CLI command and stored in Click context for subcommands
- Subcommand `--profile` options act as overrides that reload config when specified

## [0.2.0] - 2025-12-07

### Added
- `--profile` option for `config` and `config-deploy` commands
- `OutputFormat` and `DeployTarget` enums for type-safe CLI options
- LRU caching for `get_config()` (maxsize=4) and `get_default_config_path()`

### Fixed
- UTF-8 encoding issues in subprocess calls across different locales

## [0.1.0] - 2025-12-07

### Added
- Email sending via `btx-lib-mail` integration: `send-email` and `send-notification` CLI commands
- Email configuration support with `EmailConfig` dataclass and validation
- Real SMTP integration tests using `.env` configuration

## [0.0.1] - 2025-11-11
- Bootstrap
