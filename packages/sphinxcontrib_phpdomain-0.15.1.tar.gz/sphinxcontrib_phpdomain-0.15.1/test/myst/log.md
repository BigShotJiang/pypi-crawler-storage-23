# Invalid domain type

:::{php:namespacee} Foo
:::

# Invalid signature

:::{php:method} x();
:::

# Unresolved references

- {php:class}`Foo\Aa`

- {php:meth}`Foo\A::simplifyy`

:::{php:namespace} Foo
:::

- {php:meth}`Foo\A::simplify`

:::{php:namespace} Fooo
:::

- {php:meth}`Foo\A::simplify`
