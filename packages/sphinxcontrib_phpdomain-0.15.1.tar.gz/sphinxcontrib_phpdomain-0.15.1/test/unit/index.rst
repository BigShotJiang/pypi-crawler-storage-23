Welcome to sphinxcontrib-phpdomain-acceptancetest's documentation!
===================================================================

Contents:

.. toctree::
    :maxdepth: 2
    :glob:

    *

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

