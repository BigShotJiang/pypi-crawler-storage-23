#!/usr/bin/env python

"""
Thin wrapper around the "az" command line interface (CLI) for use
with LocalStack.

The "azlocal" CLI allows you to easily interact with your local Azure services
without having to configure anything.

Example:
Instead of the following command ...
HTTPS_PROXY=... REQUESTS_CA_BUNDLE=... az storage account list
... you can simply use this:
azlocal storage account list

Options:
  Run "azlocal help" for more details on the Azure CLI subcommands.
"""

import logging
import os
import subprocess
import sys
from pathlib import Path

from .constants import AZURE_CONFIG_DIR_ENV
from .shared import (
    AZURE_CONFIG_DIR,
    get_proxy_endpoint,
    get_proxy_env_vars,
    prepare_environment,
    run_in_background,
)

DEFAULT_CLOUD_NAME = "AzureCloud"
CUSTOM_CLOUD_NAME = "LocalStack"

LOG = logging.getLogger(__name__)
logging.basicConfig(
    level=os.environ.get("LOGLEVEL", "WARNING").upper(),
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
)

# TODO
# 1. wait for new SSL certificate
# 2. Update docs to use `az` instead of `azlocal`
# 3. Use `az` instead of `azlocal` in our internal tests
# 4. Disable functionality to use `azlocal` as a replacement to `az`
#    - Can be achieved by removing `run_as_separate_process()` + everything related
#    - Update help text to reflect this
# 5. Introduce `argparse.ArgumentParser()` to handle all arguments, like --help, --endpoint, etc
# 6. Introduce new arguments: --errors-only, --verbose, ..
#

HELP_TEXT_START_INTERCEPTION = """
Command
    azlocal start-interception :
        Configure the Azure CLI to route requests to the LocalStack Emulator, instead of using the real Azure cloud.

        See also: azlocal stop-interception.

Arguments
    --endpoint -e              : The local endpoint URL of the LocalStack instance.
                                 Default: http://localhost:4566.
                                 Alternatively, use an environment variable to configure this:
                                 LOCALSTACK_HOST=http://localhost:4566

Global Arguments
    --help                     : Show this help message and exit.
"""

HELP_TEXT_STOP_INTERCEPTION = """
Command
    azlocal stop-interception :
        Restore the Azure CLI configuration to its original state.
        Disables redirection to the local emulator and re-configures the CLI to
        send commands to the official Azure platform management REST API.

        See also: azlocal start-interception.

Arguments
    None

Global Arguments
    --help                     : Show this help message and exit.
"""


def usage() -> None:
    print(__doc__.strip())


def run_in_current_process(cmd: list[str], env: dict[str, str] | None = None) -> None:
    """
    Replaces this process with the AZ CLI process, with the given command and environment
    """
    os.execvpe(cmd[0], cmd, env)  # type: ignore[arg-type]


def run(cmd: list[str]) -> tuple[int, str, str]:
    LOG.debug(f"Executing {cmd}...")
    process = subprocess.run(cmd, capture_output=True)
    if process.stdout:
        LOG.debug(f"Output of {cmd}:")
        LOG.debug(process.stdout)
    if process.stderr:
        if process.stderr.startswith(b"WARNING"):
            LOG.warning(process.stderr)
        else:
            LOG.error(f"Error while running {cmd}:")
            LOG.error(process.stderr)
    return process.returncode, process.stdout.decode(), process.stderr.decode()


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "-h":
        usage()

    if len(sys.argv) > 1 and sys.argv[1] == "start-interception":
        use_custom_cloud()
    elif len(sys.argv) > 1 and sys.argv[1] == "stop-interception":
        use_regular_cloud()
    else:
        # Backwards compatibility
        # The user could invoke the CLI as if it were an 'az' replacement:
        #    azlocal group list
        # If that's the case, we redirect the existing 'az' command via a proxy to our Emulator
        run_as_separate_process()


def use_custom_cloud() -> None:
    if len(sys.argv) > 2 and sys.argv[2] in ["--help", "-h"]:
        print(HELP_TEXT_START_INTERCEPTION)
        return
    # Create the CustomCloud first
    create_custom_cloud()
    # Configure the CLI to use our CustomCloud
    run(["az", "cloud", "set", "--name", CUSTOM_CLOUD_NAME])
    LOG.info(f"AZ CLI now uses CustomCloud={CUSTOM_CLOUD_NAME}")
    # Our endpoint is not whitelisted, so we need to disable the endpoint validation
    run(["az", "config", "set", "core.instance_discovery=false", "--only-show-errors"])
    # Login
    login_failed, _, _ = run(
        ["az", "login", "--service-principal", "-u", "any-app", "-p", "any-pass", "--tenant", "anytenant"]
    )
    # This might fail if the Emulator is not running
    # If that's the case, we should stop immediately
    if login_failed:
        exit(login_failed)
    LOG.info(f"AZ CLI is now logged in against CustomCloud={CUSTOM_CLOUD_NAME}")


def use_regular_cloud() -> None:
    if len(sys.argv) > 2 and sys.argv[2] in ["--help", "-h"]:
        print(HELP_TEXT_STOP_INTERCEPTION)
        return
    # Configure the endpoint to use the default cloud
    run(["az", "cloud", "set", "--name", DEFAULT_CLOUD_NAME])
    # Re-enable instance discovery
    run(["az", "config", "set", "core.instance_discovery=true", "--only-show-errors"])
    LOG.info(f"AZ CLI now uses Cloud={DEFAULT_CLOUD_NAME}")


def create_custom_cloud() -> None:
    _, stdout, _ = run(["az", "cloud", "list", "--query", "[].name"])
    if CUSTOM_CLOUD_NAME in stdout:
        # Exists
        return

    emulator_endpoint = "https://localhost.localstack.cloud:4566"
    if "-e" in sys.argv:
        emulator_endpoint = sys.argv[sys.argv.index("-e") + 1]
    if "--endpoint" in sys.argv:
        emulator_endpoint = sys.argv[sys.argv.index("--endpoint") + 1]
    if env_var_endpoint := os.environ.get("LOCALSTACK_HOST"):
        emulator_endpoint = env_var_endpoint
    # We currently only register the four necessary endpoints
    # We may want to expand this in the future and also register data plane endpoints
    # For example '--suffix-keyvault-dns' or '--suffix-storage-endpoint'
    run(
        [
            "az",
            "cloud",
            "register",
            "--name",
            CUSTOM_CLOUD_NAME,
            "--endpoint-resource-manager",
            emulator_endpoint,
            "--endpoint-management",
            emulator_endpoint,
            "--endpoint-active-directory",
            emulator_endpoint,
            "--endpoint-active-directory-resource-id",
            emulator_endpoint,
            "--endpoint-active-directory-graph-resource-id",
            emulator_endpoint,
        ]
    )
    LOG.info(f"Created CustomCloud={CUSTOM_CLOUD_NAME}")


def run_as_separate_process() -> None:
    """
    Constructs a command line string and calls "az" as an external process.
    """

    cmd_args = list(sys.argv)
    cmd_args[0] = "az"
    if ("--help" in cmd_args) or ("--version" in cmd_args):
        # Early exit - if we only want to know the version/help, we don't need LS to be running
        run_in_current_process(cmd_args, None)
        return

    proxy_endpoint = get_proxy_endpoint()

    env_dict = prepare_environment(proxy_endpoint)

    env_dict[AZURE_CONFIG_DIR_ENV] = AZURE_CONFIG_DIR
    if not os.path.exists(AZURE_CONFIG_DIR):
        # Create the config directory
        Path(AZURE_CONFIG_DIR).mkdir(parents=True, exist_ok=True)

        # Prepare necessary arguments to ensure `az ..` commands are run against this config directory
        az_args_list = [f"{key}={val}" for key, val in get_proxy_env_vars(proxy_endpoint).items()]
        az_args_list.append(f"{AZURE_CONFIG_DIR_ENV}={AZURE_CONFIG_DIR}")
        az_arg = " ".join(az_args_list)

        # Turn off telemetry
        survey_command = f"{az_arg} az config set output.show_survey_link=no --only-show-errors"
        run_in_background(survey_command)
        telemetry_command = f"{az_arg} az config set core.collect_telemetry=false --only-show-errors"
        run_in_background(telemetry_command)

        # Login to ensure the config directory has credentials
        login_command = f"{az_arg} az login --service-principal -u any-app -p any-pass --tenant any-tenant"
        run_in_background(login_command)

    # Hijack the login command
    # When creating our custom config dir, we automatically log in - so this is not necessary anymore
    if len(cmd_args) == 2 and cmd_args[1] == "login":
        print("Login Succeeded")
        return

    # Hijack the ACR login command
    if len(cmd_args) > 1 and cmd_args[1] == "acr" and "login" in cmd_args:
        print("Login Succeeded")
        return

    # run the command
    run_in_current_process(cmd_args, env_dict)


if __name__ == "__main__":
    main()
