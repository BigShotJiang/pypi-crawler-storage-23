"""dnsctl — Secure, version-controlled DNS management for Cloudflare."""

__version__ = "1.0.0"
