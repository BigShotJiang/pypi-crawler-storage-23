import pytest

from .credentials import SalesforceCredentials

TEST_KWARGS = {
    "username": "giphy",
    "password": "1312",
    "client_id": "degenie",
    "client_secret": "fautpasledire",
    "security_token": "yo",
    "base_url": "man",
}


def test_Credentials_Username_Password_token_request_payload():
    """
    When Username, Password, and Security_token are defined
    It should use Basic Username-Password Flow
    """
    creds = SalesforceCredentials(**TEST_KWARGS)

    payload = creds.token_request_payload()

    assert payload["grant_type"] == "password"
    assert payload["username"] == "giphy"
    assert payload["client_id"] == "degenie"
    assert payload["client_secret"] == "fautpasledire"
    assert payload["password"] == "1312yo"


def test_Credentials_Client_Flow_token_request_payload():
    """
    When Username, Password, and Security_token are undefined
    It should use Credential Client Flow
    """
    creds = SalesforceCredentials(
        client_id="degenie",
        client_secret="fautpasledire",
        base_url="man",
    )

    payload = creds.token_request_payload()

    assert payload["grant_type"] == "client_credentials"
    assert payload["client_id"] == "degenie"
    assert payload["client_secret"] == "fautpasledire"
    assert "username" not in payload
    assert "password" not in payload


def test_Credentials_Missing_Parameters_token_request_payload():
    """
    When using Basic Username-Password Flow all args are required.
    It should raise an error when missing one required arg
    """
    for key in (
        "username",
        "password",
        "security_token",
    ):
        kwargs = TEST_KWARGS.copy()
        del kwargs[key]
        creds = SalesforceCredentials(**kwargs)
        with pytest.raises(ValueError):
            creds.token_request_payload()
