from dataclasses import field

from pydantic_settings import BaseSettings, SettingsConfigDict

CASTOR_ENV_PREFIX = "CASTOR_GLUE_"


class GlueAthenaCredentials(BaseSettings):
    """
    Credentials needed by Glue/Athena client
    https://docs.coalesce.io/docs/catalog/integrations/data-warehouses/glue
    """

    access_key_id: str = field(metadata={"sensitive": True})
    access_key_secret: str = field(metadata={"sensitive": True})
    aws_account_id: str = field(metadata={"sensitive": True})
    aws_region: str

    model_config = SettingsConfigDict(
        env_prefix=CASTOR_ENV_PREFIX,
        extra="ignore",
        populate_by_name=True,
    )
