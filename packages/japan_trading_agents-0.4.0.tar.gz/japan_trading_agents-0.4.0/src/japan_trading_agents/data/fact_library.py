"""Fact library — builds source-labeled data summaries from raw adapter data.

This module extracts verifiable facts from raw data with explicit source labels.
Downstream agents (especially Trader and FactVerifier) must only cite facts
that appear in the summary produced here.
"""

from __future__ import annotations

from typing import Any


def build_verified_data_summary(data: dict[str, Any], code: str) -> str:
    """Build a source-labeled data summary for downstream agents.

    Returns a structured text where every value is tagged with its data source.
    Agents must ONLY cite facts from this summary — no filling in from training data.
    """
    sections: list[str] = [
        "## 検証済みデータ一覧",
        "**重要: key_factsの出典は必ずこの一覧から引用すること。一覧にない数値・事実の引用は禁止。**",
        "",
    ]

    # --- EDINET financial statements ---
    if statements := data.get("statements"):
        filing_date = statements.get("filing_date", "unknown")
        edinet_code = statements.get("edinet_code", "")
        company_name = statements.get("company_name", code)
        label = f"EDINET {filing_date}"
        sections.append(f"### EDINET財務データ [{company_name} / {edinet_code}]")
        sections.append(f"出典ラベル: `{label}`")

        if metrics := statements.get("metrics"):
            for k, v in metrics.items():
                if v is not None:
                    sections.append(f"- {k}: {v}")
        sections.append("")

    # --- BOJ interest rate data ---
    if boj := data.get("boj"):
        series_code = boj.get("series_code", "IR01")
        name = boj.get("name", "基本的貸出利率")
        unit = boj.get("unit", "%")
        label = f"BOJ {series_code}"
        sections.append("### 日本銀行データ (BOJ)")
        sections.append(f"出典ラベル: `{label}`")
        if latest := boj.get("latest"):
            sections.append(
                f"- {name}: {latest.get('value')} {unit} ({latest.get('date')})"
            )
        if recent := boj.get("recent"):
            # Show last 3 data points for trend
            for obs in recent[-3:]:
                sections.append(f"  - {obs.get('date')}: {obs.get('value')} {unit}")
        sections.append("")

    # --- TDNET disclosures (events only, no financial values) ---
    if disclosures := data.get("disclosures"):
        sections.append("### 適時開示 (TDNET)")
        sections.append(
            "出典ラベル: `TDNET YYYY-MM-DD` ※開示タイトルのみ引用可。TDNETは財務数値を持たない。"
        )
        for d in disclosures[:6]:
            pub = d.get("pubdate", "?")
            title = d.get("title", "?")
            cat = d.get("category", "?")
            sections.append(f"- {pub}: {title} [{cat}]  [出典: TDNET {pub}]")
        sections.append("")

    # --- Stock price (yfinance) ---
    if sp := data.get("stock_price"):
        price_date = sp.get("date", "today")
        ticker = sp.get("ticker", f"{code}.T")
        label = f"yfinance {price_date}"
        sections.append(f"### 株価データ ({ticker})")
        sections.append(f"出典ラベル: `{label}`")
        close = sp.get("close")
        sections.append(f"- 終値: ¥{close:,.0f}" if close else f"- 終値: ¥{sp.get('close', '?')}")
        sections.append(f"- 高値(当日): ¥{sp.get('high', '?')}")
        sections.append(f"- 安値(当日): ¥{sp.get('low', '?')}")
        w52h = sp.get("week52_high")
        w52l = sp.get("week52_low")
        if w52h and w52l:
            sections.append(f"- 52週高値: ¥{w52h:,.0f}")
            sections.append(f"- 52週安値: ¥{w52l:,.0f}")
            if close and w52h > w52l:
                pct = (close - w52l) / (w52h - w52l) * 100
                sections.append(f"- 52週レンジ内位置: {pct:.0f}%（0%=安値, 100%=高値）")
        vol = sp.get("volume")
        sections.append(f"- 出来高: {vol:,}" if vol else "- 出来高: N/A")
        if pe := sp.get("trailing_pe"):
            sections.append(f"- PER（実績）: {pe:.1f}x")
        if pe_fwd := sp.get("forward_pe"):
            sections.append(f"- PER（予想）: {pe_fwd:.1f}x")
        if pb := sp.get("price_to_book"):
            sections.append(f"- PBR: {pb:.2f}x")
        if mcap := sp.get("market_cap"):
            sections.append(f"- 時価総額: ¥{mcap / 1e8:,.0f}億")
        if sector := sp.get("sector"):
            sections.append(f"- セクター: {sector}")
        if eps := sp.get("trailing_eps"):
            sections.append(f"- EPS（TTM）: ¥{eps:.1f}")
        if dy := sp.get("dividend_yield"):
            sections.append(f"- 配当利回り: {dy * 100:.2f}%")
        sections.append(f"- データ期間: {sp.get('total_points', '?')} 日分（過去1年）")
        sections.append("")

    # --- e-Stat (table metadata ONLY — no actual economic values) ---
    if macro := data.get("macro"):
        sections.append("### e-Stat政府統計（テーブルメタデータのみ）")
        sections.append(
            "出典ラベル: `e-Stat` ※以下はテーブル名のみ。GDP・CPI等の具体的数値は含まれていない。"
        )
        for m in macro[:4]:
            title = m.get("title", "?")
            org = m.get("gov_org", "?")
            survey_date = m.get("survey_date", "?")
            sections.append(f"- {title} ({org}、{survey_date})")
        sections.append(
            "⚠️ GDPやCPI等のマクロ数値はこのデータから引用禁止。"
            "具体的なマクロ数値が必要な場合は「e-Stat/内閣府データ取得不可」と明記すること。"
        )
        sections.append("")

    # --- News (sentiment reference only, no financial values) ---
    if news := data.get("news"):
        sections.append("### ニュースヘッドライン（センチメント参考のみ）")
        sections.append("出典ラベル: 使用不可 ※ニュースはファクト引用の出典として使用禁止。")
        for n in news[:5]:
            title = n.get("title", "?")
            src_name = n.get("source_name", "?")
            sections.append(f"- [{src_name}] {title}")
        sections.append("")

    return "\n".join(sections)
