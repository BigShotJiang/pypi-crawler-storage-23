"""japan-trading-agents: Multi-agent AI trading analysis for Japanese stocks."""

__version__ = "0.4.0"
