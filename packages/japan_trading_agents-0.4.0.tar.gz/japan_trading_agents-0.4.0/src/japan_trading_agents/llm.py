"""LLM provider abstraction using litellm."""

from __future__ import annotations

from typing import Any

import litellm
from loguru import logger

# Suppress litellm's verbose logging
litellm.suppress_debug_info = True


class LLMClient:
    """Thin wrapper around litellm for multi-provider LLM access.

    Supports any model identifier that litellm understands:
      - "gpt-4o-mini", "gpt-4o"
      - "claude-sonnet-4-5-20250929", "claude-opus-4-6"
      - "gemini/gemini-2.0-flash"
      - "ollama/llama3.2"
    """

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        temperature: float = 0.2,
    ) -> None:
        self.model = model
        self.temperature = temperature

    async def complete(self, system: str, user: str) -> str:
        """Run a single chat completion and return the content string."""
        logger.debug(f"LLM call: model={self.model}, system={system[:60]}...")
        response = await litellm.acompletion(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=self.temperature,
        )
        content: str = response.choices[0].message.content or ""
        return content

    async def complete_json(self, system: str, user: str) -> dict[str, Any]:
        """Run a completion expecting JSON output. Returns parsed dict."""
        import json

        response = await litellm.acompletion(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=self.temperature,
            response_format={"type": "json_object"},
        )
        raw: str = response.choices[0].message.content or "{}"
        return json.loads(raw)  # type: ignore[no-any-return]
