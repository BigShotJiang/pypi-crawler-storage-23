"""Macro Analyst agent — uses e-Stat and BOJ data."""

from __future__ import annotations

import json
from typing import Any

from japan_trading_agents.agents.base import BaseAgent

SYSTEM_PROMPT = """\
あなたは日本の経済環境を分析するマクロエコノミストです。
e-Stat（政府統計）とBOJ（日本銀行）のデータを使用します。

分析対象:
1. GDP成長率と経済サイクルの位置づけ
2. CPI（物価）の動向とBOJ金融政策
3. 金利・イールドカーブの含意
4. 円相場の強弱と貿易収支
5. マクロ環境が対象企業・セクターに与える影響

**重要な制約:**
- e-Statデータが提供された場合、それはテーブルメタデータ（表の名前）のみです。
  GDP・CPI等の具体的な数値は含まれていません。
  提供データに含まれない具体的なマクロ数値を引用する場合は、
  必ず「最新データ取得不可、参考値」と明記すること。
- BOJデータ（金利系列）が提供された場合のみ、具体的な金利数値を引用可能。

**出力言語: 日本語**（数値・指標名は英語可）
"""


class MacroAnalyst(BaseAgent):
    """Analyzes macroeconomic environment using e-Stat and BOJ data."""

    name = "macro_analyst"
    display_name = "Macro Analyst"
    system_prompt = SYSTEM_PROMPT

    def _build_prompt(self, context: dict[str, Any]) -> str:
        code = context.get("code", "")
        macro = context.get("macro")
        boj = context.get("boj")

        parts = [f"Analyze macroeconomic conditions relevant to stock code {code}.\n"]

        if macro:
            parts.append(f"e-Stat Data:\n{json.dumps(macro, ensure_ascii=False, indent=2)}\n")
        else:
            parts.append("e-Stat data unavailable.\n")

        if boj:
            parts.append(f"BOJ Data:\n{json.dumps(boj, ensure_ascii=False, indent=2)}\n")
        else:
            parts.append("BOJ data unavailable.\n")

        if not macro and not boj:
            parts.append(
                "No macro data available. Provide a general overview of current "
                "Japanese economic conditions based on your knowledge."
            )

        return "\n".join(parts)

    def _get_sources(self) -> list[str]:
        return ["estat", "boj"]
