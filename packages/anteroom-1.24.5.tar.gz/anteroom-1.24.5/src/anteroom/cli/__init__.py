"""Parlor CLI - interactive agentic chat mode."""
