VERSION = (4, 0, 7)
__version__ = ".".join(map(str, VERSION))
