# Differential Privacy in Sequential Event Logging
