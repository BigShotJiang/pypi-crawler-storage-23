# Familiar Shared Responsibility Matrix

**Version:** 1.0  
**Last Updated:** January 31, 2026

---

## Overview

Familiar is **self-hosted software**. Security is a shared responsibility between Familiar (the software provider) and you (the operator).

This matrix clarifies who is responsible for each security control. Use this document to:
- Understand what Familiar provides out of the box
- Identify what you must implement for your deployment
- Support compliance audits and risk assessments

---

## Responsibility Legend

| Symbol | Meaning |
|--------|---------|
| ● | Fully responsible |
| ◐ | Shared responsibility |
| ○ | Not responsible |

---

## Security Controls Matrix

### 1. Application Security

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Secure code development | ● | ○ | We follow secure coding practices |
| Dependency management | ◐ | ◐ | We pin versions; you apply updates |
| Input validation | ● | ○ | Built into tool execution layer |
| Output encoding | ● | ○ | Handled by channel integrations |
| Security testing | ● | ○ | We test before release |
| Vulnerability patching | ◐ | ◐ | We release patches; you apply them |

### 2. Authentication & Access Control

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| User identification | ● | ○ | Via channel user IDs |
| Progressive trust model | ● | ○ | Built-in trust levels |
| Capability-based access | ● | ○ | 22 discrete capabilities |
| Trust level configuration | ○ | ● | You set thresholds |
| Manual owner grants | ○ | ● | You decide who gets OWNER |
| Channel authentication | ○ | ● | You secure bot tokens |
| MFA for admin access | ○ | ● | SSH/host access controls |

### 3. Data Protection

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Data classification | ◐ | ◐ | We document; you apply to your data |
| Encryption at rest (capability) | ● | ○ | Fernet encryption available |
| Encryption at rest (enabling) | ○ | ● | You enable and manage keys |
| Encryption in transit | ● | ○ | TLS for all external calls |
| Key generation | ● | ○ | We provide tooling |
| Key storage | ○ | ● | You secure the .env file |
| Key rotation | ○ | ● | You rotate periodically |
| Data retention policies | ◐ | ◐ | We provide config; you set values |
| Data deletion | ◐ | ◐ | We provide tools; you execute |
| Backup procedures | ◐ | ◐ | We document; you implement |

### 4. Network Security

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| No inbound ports (default) | ● | ○ | Secure by default |
| TLS for outbound connections | ● | ○ | Enforced by libraries |
| Firewall rules | ◐ | ◐ | Installer configures; you maintain |
| Network segmentation | ○ | ● | Your network architecture |
| VPN/tunnel access | ○ | ● | You implement remote access |
| DNS security | ○ | ● | Your DNS configuration |

### 5. Logging & Monitoring

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Audit logging (capability) | ● | ○ | Comprehensive event logging |
| Audit logging (enabling) | ○ | ● | You enable in config |
| Log format/structure | ● | ○ | JSON format for SIEM |
| PII redaction | ● | ○ | Automatic pattern matching |
| Log storage | ○ | ● | Your storage infrastructure |
| Log retention | ◐ | ◐ | We provide config; you set duration |
| Log monitoring | ○ | ● | Your SIEM/alerting |
| Incident alerting | ○ | ● | You configure alerts |

### 6. Infrastructure Security

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Operating system | ○ | ● | You maintain the OS |
| OS patching | ○ | ● | You apply OS updates |
| Host hardening | ◐ | ◐ | Installer helps; you verify |
| Container security (if used) | ○ | ● | Your container configuration |
| Physical security | ○ | ● | Your hardware location |
| Power/environmental | ○ | ● | Your facility |

### 7. Operational Security

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Secure defaults | ● | ○ | Security-first configuration |
| Documentation | ● | ○ | Security guides provided |
| Change management | ○ | ● | Your change process |
| Configuration management | ○ | ● | You manage config files |
| Secret management | ◐ | ◐ | We use env vars; you secure them |
| Service account security | ◐ | ◐ | We create user; you secure it |

### 8. Business Continuity

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Backup documentation | ● | ○ | We document procedures |
| Backup implementation | ○ | ● | You run backups |
| Backup testing | ○ | ● | You verify restores |
| Disaster recovery plan | ○ | ● | Your DR procedures |
| High availability | ○ | ● | Your architecture decision |

### 9. Compliance

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| Security whitepaper | ● | ○ | This and other docs |
| Compliance guides | ● | ○ | HIPAA guide provided |
| Risk assessment | ◐ | ◐ | We provide template; you complete |
| Policy development | ○ | ● | Your organizational policies |
| Audit support | ◐ | ◐ | We provide docs; you respond |
| Regulatory compliance | ○ | ● | Your compliance obligations |

### 10. Incident Response

| Control | Familiar | Operator | Notes |
|---------|:-------:|:--------:|-------|
| IR documentation | ● | ○ | Guidance in security docs |
| IR plan development | ○ | ● | Your specific procedures |
| IR execution | ○ | ● | You respond to incidents |
| Evidence preservation | ◐ | ◐ | We log; you preserve |
| Root cause analysis | ◐ | ◐ | Depends on incident type |
| Vulnerability disclosure | ● | ○ | We manage CVEs |
| Security advisories | ● | ○ | We publish advisories |
| Patch deployment | ○ | ● | You apply patches |

---

## LLM Provider Responsibilities

When using cloud LLM providers (Anthropic, OpenAI), additional responsibilities exist:

| Control | Familiar | Operator | LLM Provider |
|---------|:-------:|:--------:|:------------:|
| API security | ○ | ○ | ● |
| API key issuance | ○ | ● | ● |
| API key protection | ○ | ● | ○ |
| Data processing agreement | ○ | ● | ● |
| BAA execution (HIPAA) | ○ | ● | ● |
| Model security | ○ | ○ | ● |
| Provider compliance | ○ | ○ | ● |

---

## Summary by Role

### What Familiar Provides

✅ Secure application code  
✅ Progressive trust model  
✅ Capability-based access control  
✅ Shell command validation  
✅ Path sandboxing  
✅ Encryption at rest capability  
✅ Comprehensive audit logging  
✅ PII redaction in logs  
✅ TLS for all external connections  
✅ Security documentation  
✅ Compliance guides  
✅ Hardening recommendations  

### What You Must Provide

⚠️ Secure hosting environment  
⚠️ Operating system maintenance  
⚠️ Network security (firewall, segmentation)  
⚠️ Secret management (.env protection)  
⚠️ Encryption key management  
⚠️ Backup implementation and testing  
⚠️ Log monitoring and alerting  
⚠️ Incident response execution  
⚠️ User access decisions (OWNER grants)  
⚠️ Compliance with your regulatory requirements  
⚠️ BAAs with LLM providers (if required)  

---

## Using This Matrix for Audits

When auditors ask about specific controls:

1. **Identify the control** in this matrix
2. **Determine responsibility**:
   - If Familiar (●): Point to our documentation
   - If Operator (●): Show your implementation
   - If Shared (◐): Show both
3. **Provide evidence** as appropriate

### Example Audit Questions

**Q: "How do you control access to sensitive operations?"**  
A: Familiar implements progressive trust (see Security Whitepaper §4). We have configured trust thresholds as follows: [your config]. OWNER access is manually granted only to [list].

**Q: "How is data encrypted at rest?"**  
A: Familiar provides Fernet encryption (see Security Whitepaper §8). We have enabled it with keys stored in [your key management approach].

**Q: "How do you monitor for security incidents?"**  
A: Familiar generates audit logs in JSON format (see Security Whitepaper §7). We ship these to [your SIEM] and have alerts configured for [your alert rules].

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-31 | Initial release |

---

*For questions about Familiar's security responsibilities, see the Security Whitepaper. For deployment guidance, see the Hardening Guide.*
