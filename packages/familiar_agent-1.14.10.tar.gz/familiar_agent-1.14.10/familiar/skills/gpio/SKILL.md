# GPIO Skill

Control Raspberry Pi GPIO pins for hardware interfacing.

## Usage

Use this skill when the user wants to:
- Control LEDs, relays, or other outputs
- Read sensors or button states
- Interface with hardware connected to GPIO pins

## Safety

Always confirm before changing GPIO states that could affect physical devices.

## Available Tools

- `gpio_setup`: Configure a pin as input or output
- `gpio_write`: Set output pin high or low
- `gpio_read`: Read input pin state
- `gpio_pwm`: Set PWM duty cycle on a pin
