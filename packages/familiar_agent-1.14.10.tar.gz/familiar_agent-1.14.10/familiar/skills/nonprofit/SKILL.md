# Nonprofit Management Skill

Track donors, grants, and nonprofit-specific information.

## Usage

Use this skill when the user wants to:
- Log donor interactions or gifts
- Track grant deadlines and requirements
- Record board meeting notes
- Manage volunteer information
- Track compliance deadlines (990s, registrations, etc.)

## Important Dates for 501(c)(3)

- **Form 990**: Due 15th day of 5th month after fiscal year end
- **State registrations**: Vary by state, often annual
- **Donor acknowledgments**: Send within 30 days of gift
- **Grant reports**: Per grant agreement

## Data Privacy

Donor information is sensitive. Never share full lists externally.
