---
name: Feature request
about: Suggest an idea for AgentLint
labels: enhancement
---

## Problem / motivation

What problem does this solve? Why is it needed?

## Proposed solution

Describe your preferred approach.

## Alternatives considered

Any other approaches you've thought about and why you ruled them out.
