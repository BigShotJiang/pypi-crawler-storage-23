# synthetic-data

Synthetic powder diffraction patterns generated for testing and demonstration.

These datasets are not real experimental measurements.
They are produced using randomized peak positions, intensities, and broadenings
to validate preprocessing and refinement routines.