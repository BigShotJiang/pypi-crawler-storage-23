# 📘 PowerXRD v4.0 – Adding and Testing New Lattice Types

Hi Amanda —

PowerXRD 4.0 is now structured so that lattice geometry is isolated inside its own folder. Right now only the cubic lattice is implemented, and the system is ready to support additional crystal systems.

The lattice code lives here:

```
powerxrd/
└── lattice/
    ├── base.py
    ├── cubic.py
    ├── registry.py
```

### How it’s organized

* `base.py` defines the abstract interface (`BaseLattice`).
* `cubic.py` implements one concrete lattice.
* `registry.py` registers available lattice types.
* Everything else (structure factor, profiles, refinement) automatically uses whatever lattice is provided.

So adding new crystal systems only requires working inside this folder.

---

## 1️⃣ Use `cubic.py` as the Template

Open:

```
powerxrd/lattice/cubic.py
```

That file is the template.

Every new lattice should:

* Inherit from `BaseLattice`
* Implement:

  * `d_spacing(h, k, l)`
  * `param_names()`
  * `get_params()`
  * `set_params(values)`

The only thing that really changes is the geometry formula inside `d_spacing()` and the number of parameters.

For example, you might create:

* `tetragonal.py`
* `orthorhombic.py`
* `hexagonal.py`
* `monoclinic.py`

Each in:

```
powerxrd/lattice/
```

---

## 2️⃣ Register the New Lattice

After creating the new lattice class, open:

```
powerxrd/lattice/registry.py
```

Import your class:

```python
from .tetragonal import TetragonalLattice
```

Then add it to the registry dictionary:

```python
LATTICE_REGISTRY = {
    "cubic": CubicLattice,
    "tetragonal": TetragonalLattice,
}
```

That’s all that’s required for integration.

After that, you can create it with:

```python
create_lattice("tetragonal", a=..., c=...)
```

---

## 3️⃣ How to Test Your New Lattice

Once it’s implemented and registered, you can test it by modifying one of the example scripts.

For example, open:

```
hello_rietveld_long.py
```

Right now it probably does something like:

```python
from powerxrd.lattice import CubicLattice

lattice = CubicLattice(a=4.0)
```

Replace that with your new lattice:

```python
from powerxrd.lattice import create_lattice

lattice = create_lattice("tetragonal", a=3.9, c=4.1)
```

Then run the script and see how the generated pattern behaves.

You can:

* Compare peak positions to cubic.
* Change lattice parameters and see how peaks shift.
* Run refinement and see how it adjusts parameters.

You can also modify the synthetic pattern generation (the “made-up” curve we use for demos) and see how your lattice handles it.

The idea isn’t formal validation — just:

> Plug it in, generate peaks, and see how the geometry propagates through the full pipeline.

If the peaks shift sensibly when you change parameters, and no errors occur, the integration is working.

---

## 4️⃣ Scope for Now

Start with one lattice (tetragonal is probably the easiest next step).

Once that’s working, you can add more if you feel like it.

No need to overthink validation at this stage. The goal is just to expand the geometric coverage and get comfortable with how the lattice layer connects to the rest of the engine.

---

That’s it.


