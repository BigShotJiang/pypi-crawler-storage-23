# SPDX-License-Identifier: MIT
#
# Export helpers for burn trend pipeline.
