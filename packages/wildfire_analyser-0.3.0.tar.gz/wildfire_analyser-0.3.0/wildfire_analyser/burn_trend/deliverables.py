# SPDX-License-Identifier: MIT
#
# Deliverable definitions for burn trend pipeline.

from enum import Enum, auto


class Deliverable(Enum):
    REPORT = auto()
