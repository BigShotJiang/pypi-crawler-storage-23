# SPDX-License-Identifier: MIT
#
# Burn trend package for temporal fire-disturbance monitoring.
