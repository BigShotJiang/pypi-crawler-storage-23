"""Formatters for CLI output."""
