.. _mesomathpackage:

API Reference
=============

Module contents
---------------

.. automodule:: mesomath
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

mesomath.babn module
--------------------

.. automodule:: mesomath.babn
   :members:
   :special-members: '__init__'
   :undoc-members:
   :show-inheritance:

mesomath.hamming module
-----------------------

.. automodule:: mesomath.hamming
   :members:
   :undoc-members:
   :show-inheritance:

mesomath.npvs module
--------------------

.. automodule:: mesomath.npvs
   :members:
   :special-members:
   :show-inheritance:

