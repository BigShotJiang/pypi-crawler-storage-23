# MesoMath v{{ release }} Documentation

***Mesopotamian Calculator and Metrology Tools***


```{toctree}
:maxdepth: 1
:caption: "Contents:"

intro.md
release-notes.md
install.md
tutorial.md
progs/metrotable.md
progs/mtlookup.md
progs/multable.md
references.md
mesomath
progs/apps

```

## Indices and tables

* [General Index](genindex)
* [Module Index](modindex)
* [Search Page](search)
