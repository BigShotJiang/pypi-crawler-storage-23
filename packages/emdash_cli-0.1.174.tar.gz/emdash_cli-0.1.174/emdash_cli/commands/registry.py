"""Registry CLI commands for browsing and installing community components."""

import json
import re
import shutil
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

import click
import httpx
import yaml
from rich.console import Console

from ..design import (
    Colors,
    header,
    footer,
    SEPARATOR_WIDTH,
    STATUS_ACTIVE,
)

console = Console()

# GitHub raw URL base for the registry
GITHUB_REPO = "mendyEdri/emdash-registry"
GITHUB_BRANCH = "main"
REGISTRY_BASE_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO}/{GITHUB_BRANCH}"


ComponentType = Literal["skill", "rule", "agent", "verifier", "plugin"]


# ─────────────────────────────────────────────────────────────────────────────
# Plugin Data Structures
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PluginHook:
    """Hook configuration from a plugin manifest."""
    event: str
    command: str
    timeout: int | None = None
    working_dir: str | None = None

    def to_dict(self) -> dict[str, Any]:
        result = {"event": self.event, "command": self.command}
        if self.timeout:
            result["timeout"] = self.timeout
        if self.working_dir:
            result["working_dir"] = self.working_dir
        return result


@dataclass
class PluginComponents:
    """Components included in a plugin."""
    skills: list[str] = field(default_factory=list)
    rules: list[str] = field(default_factory=list)
    agents: list[str] = field(default_factory=list)
    verifiers: list[str] = field(default_factory=list)
    hooks: list[PluginHook] = field(default_factory=list)


@dataclass
class PluginManifest:
    """Parsed plugin manifest from PLUGIN.md frontmatter."""
    name: str
    description: str
    tags: list[str]
    components: PluginComponents
    version: str = "1.0.0"
    author: str | None = None

    @classmethod
    def from_frontmatter(cls, frontmatter: dict[str, Any]) -> "PluginManifest":
        """Create a PluginManifest from parsed YAML frontmatter."""
        components_data = frontmatter.get("components", {})
        hooks_data = components_data.get("hooks", [])

        hooks = []
        for h in hooks_data:
            if isinstance(h, dict):
                hooks.append(PluginHook(
                    event=h.get("event", ""),
                    command=h.get("command", ""),
                    timeout=h.get("timeout"),
                    working_dir=h.get("working_dir"),
                ))

        components = PluginComponents(
            skills=components_data.get("skills", []),
            rules=components_data.get("rules", []),
            agents=components_data.get("agents", []),
            verifiers=components_data.get("verifiers", []),
            hooks=hooks,
        )

        return cls(
            name=frontmatter.get("name", ""),
            description=frontmatter.get("description", ""),
            tags=frontmatter.get("tags", []),
            components=components,
            version=frontmatter.get("version", "1.0.0"),
            author=frontmatter.get("author"),
        )


@dataclass
class InstalledPlugin:
    """Represents an installed plugin with tracking information."""
    name: str
    version: str
    description: str
    installed_at: str
    components: dict[str, list[str]]  # type -> list of component names
    hook_ids: list[str]  # IDs of hooks added by this plugin

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InstalledPlugin":
        return cls(**data)


@dataclass
class PluginsFile:
    """Structure for .emdash/plugins.json."""
    plugins: dict[str, InstalledPlugin] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "plugins": {name: p.to_dict() for name, p in self.plugins.items()}
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PluginsFile":
        plugins = {}
        for name, pdata in data.get("plugins", {}).items():
            plugins[name] = InstalledPlugin.from_dict(pdata)
        return cls(plugins=plugins)


def _fetch_registry() -> dict | None:
    """Fetch the registry.json from GitHub."""
    url = f"{REGISTRY_BASE_URL}/registry.json"
    try:
        response = httpx.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Failed to fetch registry: {e}")
        return None


def _fetch_component(path: str) -> str | None:
    """Fetch a component file from GitHub."""
    url = f"{REGISTRY_BASE_URL}/{path}"
    try:
        response = httpx.get(url, timeout=10)
        response.raise_for_status()
        return response.text
    except Exception as e:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Failed to fetch component: {e}")
        return None


def _get_emdash_dir() -> Path:
    """Get the .emdash directory."""
    return Path.cwd() / ".emdash"


def _install_skill(name: str, content: str) -> bool:
    """Install a skill to .emdash/skills/."""
    skill_dir = _get_emdash_dir() / "skills" / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(content)
    return True


def _install_rule(name: str, content: str) -> bool:
    """Install a rule to .emdash/rules/."""
    rules_dir = _get_emdash_dir() / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)
    rule_file = rules_dir / f"{name}.md"
    rule_file.write_text(content)
    return True


def _install_agent(name: str, content: str) -> bool:
    """Install an agent to .emdash/agents/."""
    agents_dir = _get_emdash_dir() / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    agent_file = agents_dir / f"{name}.md"
    agent_file.write_text(content)
    return True


def _install_verifier(name: str, content: str) -> bool:
    """Install a verifier to .emdash/verifiers.json."""
    verifiers_file = _get_emdash_dir() / "verifiers.json"

    # Load or create verifiers config
    if verifiers_file.exists():
        existing = json.loads(verifiers_file.read_text())
    else:
        _get_emdash_dir().mkdir(parents=True, exist_ok=True)
        existing = {"verifiers": [], "max_attempts": 3}

    # Parse new verifier
    new_verifier = json.loads(content)

    # Check if already exists
    existing_names = [v.get("name") for v in existing.get("verifiers", [])]
    if name in existing_names:
        # Update existing
        existing["verifiers"] = [
            new_verifier if v.get("name") == name else v
            for v in existing["verifiers"]
        ]
    else:
        existing["verifiers"].append(new_verifier)

    verifiers_file.write_text(json.dumps(existing, indent=2))
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Plugin Functions
# ─────────────────────────────────────────────────────────────────────────────

def _parse_plugin_manifest(content: str) -> PluginManifest | None:
    """Parse a PLUGIN.md file and extract the manifest from frontmatter."""
    # Match YAML frontmatter between --- delimiters
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if not match:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Invalid PLUGIN.md format - missing frontmatter")
        return None

    try:
        frontmatter = yaml.safe_load(match.group(1))
        if not frontmatter:
            console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Empty frontmatter in PLUGIN.md")
            return None
        return PluginManifest.from_frontmatter(frontmatter)
    except yaml.YAMLError as e:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Failed to parse PLUGIN.md frontmatter: {e}")
        return None


def _get_plugins_file_path() -> Path:
    """Get the path to the plugins.json file."""
    return _get_emdash_dir() / "plugins.json"


def _load_plugins_file() -> PluginsFile:
    """Load the plugins.json file."""
    plugins_file = _get_plugins_file_path()
    if not plugins_file.exists():
        return PluginsFile()

    try:
        data = json.loads(plugins_file.read_text())
        return PluginsFile.from_dict(data)
    except Exception as e:
        console.print(f"  [{Colors.WARNING}]warning:[/{Colors.WARNING}] Failed to load plugins.json: {e}")
        return PluginsFile()


def _save_plugins_file(plugins_file: PluginsFile) -> None:
    """Save the plugins.json file."""
    file_path = _get_plugins_file_path()
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(json.dumps(plugins_file.to_dict(), indent=2) + "\n")


def _get_installed_plugins() -> dict[str, InstalledPlugin]:
    """Get dictionary of installed plugins."""
    return _load_plugins_file().plugins


def _add_plugin_hook(hook: PluginHook, plugin_name: str) -> str | None:
    """Add a hook from a plugin. Returns the hook ID or None on failure."""
    hooks_file = _get_emdash_dir() / "hooks.json"

    # Load or create hooks config
    if hooks_file.exists():
        try:
            hooks_data = json.loads(hooks_file.read_text())
        except json.JSONDecodeError:
            hooks_data = {"hooks": []}
    else:
        _get_emdash_dir().mkdir(parents=True, exist_ok=True)
        hooks_data = {"hooks": []}

    # Generate unique hook ID
    hook_id = f"{plugin_name}-{hook.event}-{len(hooks_data['hooks'])}"

    # Check if hook with same ID exists
    existing_ids = [h.get("id") for h in hooks_data.get("hooks", [])]
    while hook_id in existing_ids:
        hook_id = f"{plugin_name}-{hook.event}-{len(hooks_data['hooks']) + 1}"

    # Add the hook
    hook_entry = {
        "id": hook_id,
        "event": hook.event,
        "command": hook.command,
        "enabled": True,
        "plugin": plugin_name,  # Track which plugin added this hook
    }
    if hook.timeout:
        hook_entry["timeout"] = hook.timeout
    if hook.working_dir:
        hook_entry["working_dir"] = hook.working_dir

    hooks_data["hooks"].append(hook_entry)
    hooks_file.write_text(json.dumps(hooks_data, indent=2) + "\n")

    return hook_id


def _remove_plugin_hooks(hook_ids: list[str]) -> None:
    """Remove hooks by their IDs."""
    hooks_file = _get_emdash_dir() / "hooks.json"
    if not hooks_file.exists():
        return

    try:
        hooks_data = json.loads(hooks_file.read_text())
        hooks_data["hooks"] = [
            h for h in hooks_data.get("hooks", [])
            if h.get("id") not in hook_ids
        ]
        hooks_file.write_text(json.dumps(hooks_data, indent=2) + "\n")
    except Exception:
        pass  # Silently ignore errors during cleanup


def _remove_skill(name: str) -> bool:
    """Remove a skill from .emdash/skills/."""
    skill_dir = _get_emdash_dir() / "skills" / name
    if skill_dir.exists():
        shutil.rmtree(skill_dir)
        return True
    return False


def _remove_rule(name: str) -> bool:
    """Remove a rule from .emdash/rules/."""
    rule_file = _get_emdash_dir() / "rules" / f"{name}.md"
    if rule_file.exists():
        rule_file.unlink()
        return True
    return False


def _remove_agent(name: str) -> bool:
    """Remove an agent from .emdash/agents/."""
    agent_file = _get_emdash_dir() / "agents" / f"{name}.md"
    if agent_file.exists():
        agent_file.unlink()
        return True
    return False


def _remove_verifier(name: str) -> bool:
    """Remove a verifier from .emdash/verifiers.json."""
    verifiers_file = _get_emdash_dir() / "verifiers.json"
    if not verifiers_file.exists():
        return False

    try:
        existing = json.loads(verifiers_file.read_text())
        original_count = len(existing.get("verifiers", []))
        existing["verifiers"] = [
            v for v in existing.get("verifiers", [])
            if v.get("name") != name
        ]
        if len(existing["verifiers"]) < original_count:
            verifiers_file.write_text(json.dumps(existing, indent=2))
            return True
    except Exception:
        pass
    return False


def _install_plugin(name: str, registry: dict) -> bool:
    """Install a plugin and all its components.

    Args:
        name: The plugin name
        registry: The full registry data

    Returns:
        True if installation succeeded
    """
    # Get plugin info from registry
    plugins = registry.get("plugins", {})
    if name not in plugins:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Plugin '{name}' not found in registry")
        return False

    plugin_info = plugins[name]
    plugin_path = plugin_info.get("path", f"plugins/{name}/PLUGIN.md")

    # Check if already installed
    installed_plugins = _get_installed_plugins()
    if name in installed_plugins:
        console.print(f"  [{Colors.WARNING}]warning:[/{Colors.WARNING}] Plugin '{name}' is already installed. Use 'uninstall' first to reinstall.")
        return False

    # Fetch the PLUGIN.md
    console.print(f"  [{Colors.DIM}]fetching plugin manifest...[/{Colors.DIM}]")
    content = _fetch_component(plugin_path)
    if not content:
        return False

    # Parse the manifest
    manifest = _parse_plugin_manifest(content)
    if not manifest:
        return False

    console.print(f"  [{Colors.PRIMARY}]installing:[/{Colors.PRIMARY}] {manifest.name} v{manifest.version}")
    console.print(f"  [{Colors.DIM}]{manifest.description}[/{Colors.DIM}]")
    console.print()

    # Save the PLUGIN.md to .emdash/plugins/{name}/ for reference
    plugin_dir = _get_emdash_dir() / "plugins" / name
    plugin_dir.mkdir(parents=True, exist_ok=True)
    (plugin_dir / "PLUGIN.md").write_text(content)

    # Track what we install for uninstallation
    installed_components: dict[str, list[str]] = {
        "skills": [],
        "rules": [],
        "agents": [],
        "verifiers": [],
    }
    installed_hook_ids: list[str] = []
    plugin_base_path = f"plugins/{name}"

    # Install skills
    for skill_name in manifest.components.skills:
        console.print(f"  [{Colors.DIM}]installing skill: {skill_name}...[/{Colors.DIM}]", end="\r")

        # Try embedded first, then registry
        embedded_path = f"{plugin_base_path}/skills/{skill_name}/SKILL.md"
        skill_content = _fetch_component(embedded_path)

        if not skill_content:
            # Try from main registry
            skill_info = registry.get("skills", {}).get(skill_name)
            if skill_info:
                skill_content = _fetch_component(skill_info["path"])

        if skill_content:
            _install_skill(skill_name, skill_content)
            installed_components["skills"].append(skill_name)
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]skill:[/{Colors.MUTED}] {skill_name}          ")
        else:
            console.print(f"  [{Colors.WARNING}]skipped:[/{Colors.WARNING}] skill:{skill_name} (not found)          ")

    # Install rules
    for rule_name in manifest.components.rules:
        console.print(f"  [{Colors.DIM}]installing rule: {rule_name}...[/{Colors.DIM}]", end="\r")

        # Try embedded first, then registry
        embedded_path = f"{plugin_base_path}/rules/{rule_name}.md"
        rule_content = _fetch_component(embedded_path)

        if not rule_content:
            # Try from main registry
            rule_info = registry.get("rules", {}).get(rule_name)
            if rule_info:
                rule_content = _fetch_component(rule_info["path"])

        if rule_content:
            _install_rule(rule_name, rule_content)
            installed_components["rules"].append(rule_name)
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]rule:[/{Colors.MUTED}] {rule_name}          ")
        else:
            console.print(f"  [{Colors.WARNING}]skipped:[/{Colors.WARNING}] rule:{rule_name} (not found)          ")

    # Install agents
    for agent_name in manifest.components.agents:
        console.print(f"  [{Colors.DIM}]installing agent: {agent_name}...[/{Colors.DIM}]", end="\r")

        # Try embedded first, then registry
        embedded_path = f"{plugin_base_path}/agents/{agent_name}.md"
        agent_content = _fetch_component(embedded_path)

        if not agent_content:
            # Try from main registry
            agent_info = registry.get("agents", {}).get(agent_name)
            if agent_info:
                agent_content = _fetch_component(agent_info["path"])

        if agent_content:
            _install_agent(agent_name, agent_content)
            installed_components["agents"].append(agent_name)
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]agent:[/{Colors.MUTED}] {agent_name}          ")
        else:
            console.print(f"  [{Colors.WARNING}]skipped:[/{Colors.WARNING}] agent:{agent_name} (not found)          ")

    # Install verifiers
    for verifier_name in manifest.components.verifiers:
        console.print(f"  [{Colors.DIM}]installing verifier: {verifier_name}...[/{Colors.DIM}]", end="\r")

        # Try embedded first, then registry
        embedded_path = f"{plugin_base_path}/verifiers/{verifier_name}.json"
        verifier_content = _fetch_component(embedded_path)

        if not verifier_content:
            # Try from main registry
            verifier_info = registry.get("verifiers", {}).get(verifier_name)
            if verifier_info:
                verifier_content = _fetch_component(verifier_info["path"])

        if verifier_content:
            _install_verifier(verifier_name, verifier_content)
            installed_components["verifiers"].append(verifier_name)
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]verifier:[/{Colors.MUTED}] {verifier_name}          ")
        else:
            console.print(f"  [{Colors.WARNING}]skipped:[/{Colors.WARNING}] verifier:{verifier_name} (not found)          ")

    # Install hooks
    for hook in manifest.components.hooks:
        hook_id = _add_plugin_hook(hook, name)
        if hook_id:
            installed_hook_ids.append(hook_id)
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]hook:[/{Colors.MUTED}] {hook.event} → {hook.command[:40]}...")

    # Save plugin installation record
    plugins_file = _load_plugins_file()
    plugins_file.plugins[name] = InstalledPlugin(
        name=name,
        version=manifest.version,
        description=manifest.description,
        installed_at=datetime.now().isoformat(),
        components=installed_components,
        hook_ids=installed_hook_ids,
    )
    _save_plugins_file(plugins_file)

    console.print()
    total = sum(len(v) for v in installed_components.values()) + len(installed_hook_ids)
    console.print(f"  [{Colors.SUCCESS}]Plugin '{name}' installed successfully ({total} components)[/{Colors.SUCCESS}]")
    return True


def _uninstall_plugin(name: str) -> bool:
    """Uninstall a plugin and remove all its components.

    Args:
        name: The plugin name

    Returns:
        True if uninstallation succeeded
    """
    plugins_file = _load_plugins_file()

    if name not in plugins_file.plugins:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Plugin '{name}' is not installed")
        return False

    plugin = plugins_file.plugins[name]
    console.print(f"  [{Colors.PRIMARY}]uninstalling:[/{Colors.PRIMARY}] {plugin.name}")
    console.print()

    removed_count = 0

    # Remove skills
    for skill_name in plugin.components.get("skills", []):
        if _remove_skill(skill_name):
            console.print(f"  [{Colors.DIM}]removed:[/{Colors.DIM}] skill:{skill_name}")
            removed_count += 1

    # Remove rules
    for rule_name in plugin.components.get("rules", []):
        if _remove_rule(rule_name):
            console.print(f"  [{Colors.DIM}]removed:[/{Colors.DIM}] rule:{rule_name}")
            removed_count += 1

    # Remove agents
    for agent_name in plugin.components.get("agents", []):
        if _remove_agent(agent_name):
            console.print(f"  [{Colors.DIM}]removed:[/{Colors.DIM}] agent:{agent_name}")
            removed_count += 1

    # Remove verifiers
    for verifier_name in plugin.components.get("verifiers", []):
        if _remove_verifier(verifier_name):
            console.print(f"  [{Colors.DIM}]removed:[/{Colors.DIM}] verifier:{verifier_name}")
            removed_count += 1

    # Remove hooks
    if plugin.hook_ids:
        _remove_plugin_hooks(plugin.hook_ids)
        for hook_id in plugin.hook_ids:
            console.print(f"  [{Colors.DIM}]removed:[/{Colors.DIM}] hook:{hook_id}")
            removed_count += 1

    # Remove plugin directory (.emdash/plugins/{name}/)
    plugin_dir = _get_emdash_dir() / "plugins" / name
    if plugin_dir.exists():
        shutil.rmtree(plugin_dir)
        console.print(f"  [{Colors.DIM}]removed:[/{Colors.DIM}] plugin directory")

    # Remove from plugins.json
    del plugins_file.plugins[name]
    _save_plugins_file(plugins_file)

    console.print()
    console.print(f"  [{Colors.SUCCESS}]Plugin '{name}' uninstalled ({removed_count} components removed)[/{Colors.SUCCESS}]")
    return True


def _list_installed_plugins() -> None:
    """List all installed plugins."""
    plugins = _get_installed_plugins()

    console.print()
    console.print(f"[{Colors.MUTED}]{header('Installed Plugins', SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print()

    if not plugins:
        console.print(f"  [{Colors.DIM}]No plugins installed.[/{Colors.DIM}]")
        console.print(f"  [{Colors.DIM}]Use '/registry install plugin:<name>' to install one.[/{Colors.DIM}]")
    else:
        for name, plugin in plugins.items():
            component_count = sum(len(v) for v in plugin.components.values()) + len(plugin.hook_ids)
            console.print(f"  [{Colors.PRIMARY}]{name}[/{Colors.PRIMARY}] [{Colors.DIM}]v{plugin.version}[/{Colors.DIM}]")
            console.print(f"      [{Colors.MUTED}]{plugin.description}[/{Colors.MUTED}]")
            console.print(f"      [{Colors.DIM}]{component_count} components • installed {plugin.installed_at[:10]}[/{Colors.DIM}]")

    console.print()
    console.print(f"[{Colors.MUTED}]{footer(SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print()


@click.group(invoke_without_command=True)
@click.pass_context
def registry(ctx):
    """Browse and install community skills, rules, agents, and verifiers.

    Run without arguments to open the interactive wizard.
    """
    if ctx.invoked_subcommand is None:
        # Interactive wizard mode
        _show_registry_wizard()


@registry.command("list")
@click.argument("component_type", required=False,
                type=click.Choice(["skills", "rules", "agents", "verifiers", "plugins"]))
def registry_list(component_type: str | None):
    """List available components from the registry."""
    reg = _fetch_registry()
    if not reg:
        return

    types_to_show = [component_type] if component_type else ["plugins", "skills", "rules", "agents", "verifiers"]

    for ctype in types_to_show:
        components = reg.get(ctype, {})
        if not components:
            continue

        console.print()
        console.print(f"[{Colors.MUTED}]{header(ctype.title(), SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
        console.print()

        for name, info in components.items():
            tags = ", ".join(info.get("tags", []))
            desc = info.get("description", "")

            # For plugins, show component counts
            if ctype == "plugins":
                component_counts = info.get("components", {})
                count_str = ", ".join(
                    f"{v} {k}" for k, v in component_counts.items() if v > 0
                )
                console.print(f"  [{Colors.PRIMARY}]{name}[/{Colors.PRIMARY}]")
                if desc:
                    console.print(f"      [{Colors.MUTED}]{desc}[/{Colors.MUTED}]")
                if count_str:
                    console.print(f"      [{Colors.DIM}]includes: {count_str}[/{Colors.DIM}]")
                if tags:
                    console.print(f"      [{Colors.DIM}]{tags}[/{Colors.DIM}]")
            else:
                console.print(f"  [{Colors.PRIMARY}]{name}[/{Colors.PRIMARY}]")
                if desc:
                    console.print(f"      [{Colors.MUTED}]{desc}[/{Colors.MUTED}]")
                if tags:
                    console.print(f"      [{Colors.DIM}]{tags}[/{Colors.DIM}]")

        console.print()
        console.print(f"[{Colors.MUTED}]{footer(SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
        console.print()


@registry.command("show")
@click.argument("component_id")
def registry_show(component_id: str):
    """Show details of a component.

    COMPONENT_ID format: type:name (e.g., skill:frontend-design, plugin:self-improving)
    """
    if ":" not in component_id:
        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Invalid format. Use type:name (e.g., skill:frontend-design)")
        return

    ctype, name = component_id.split(":", 1)
    type_plural = ctype + "s" if not ctype.endswith("s") else ctype

    reg = _fetch_registry()
    if not reg:
        return

    components = reg.get(type_plural, {})
    if name not in components:
        console.print(f"  [{Colors.WARNING}]{ctype.title()} '{name}' not found in registry.[/{Colors.WARNING}]")
        return

    info = components[name]

    # Fetch the content
    content = _fetch_component(info["path"])
    if not content:
        return

    console.print()
    console.print(f"[{Colors.MUTED}]{header(f'{ctype}:{name}', SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print()

    if info.get('description'):
        console.print(f"  [{Colors.DIM}]desc[/{Colors.DIM}]    {info.get('description', '')}")
    if info.get('tags'):
        console.print(f"  [{Colors.DIM}]tags[/{Colors.DIM}]    {', '.join(info.get('tags', []))}")
    if info.get('path'):
        console.print(f"  [{Colors.DIM}]path[/{Colors.DIM}]    {info.get('path', '')}")

    # For plugins, show component breakdown
    if ctype == "plugin":
        manifest = _parse_plugin_manifest(content)
        if manifest:
            console.print()
            console.print(f"  [{Colors.DIM}]version[/{Colors.DIM}] {manifest.version}")
            if manifest.author:
                console.print(f"  [{Colors.DIM}]author[/{Colors.DIM}]  {manifest.author}")
            console.print()
            console.print(f"  [{Colors.PRIMARY}]components:[/{Colors.PRIMARY}]")
            if manifest.components.skills:
                console.print(f"    [{Colors.MUTED}]skills:[/{Colors.MUTED}]     {', '.join(manifest.components.skills)}")
            if manifest.components.rules:
                console.print(f"    [{Colors.MUTED}]rules:[/{Colors.MUTED}]      {', '.join(manifest.components.rules)}")
            if manifest.components.agents:
                console.print(f"    [{Colors.MUTED}]agents:[/{Colors.MUTED}]     {', '.join(manifest.components.agents)}")
            if manifest.components.verifiers:
                console.print(f"    [{Colors.MUTED}]verifiers:[/{Colors.MUTED}]  {', '.join(manifest.components.verifiers)}")
            if manifest.components.hooks:
                console.print(f"    [{Colors.MUTED}]hooks:[/{Colors.MUTED}]      {len(manifest.components.hooks)} hook(s)")
                for hook in manifest.components.hooks:
                    console.print(f"      [{Colors.DIM}]• {hook.event} → {hook.command[:50]}{'...' if len(hook.command) > 50 else ''}[/{Colors.DIM}]")

            # Check if already installed
            installed = _get_installed_plugins()
            if name in installed:
                console.print()
                console.print(f"  [{Colors.SUCCESS}]✓ installed[/{Colors.SUCCESS}] [{Colors.DIM}](v{installed[name].version}, {installed[name].installed_at[:10]})[/{Colors.DIM}]")
    else:
        console.print()
        console.print(f"  [{Colors.DIM}]content:[/{Colors.DIM}]")
        console.print()

        # Show content with indentation
        for line in content.split('\n')[:30]:  # Limit preview lines
            if line.startswith('#'):
                console.print(f"    [{Colors.PRIMARY}]{line}[/{Colors.PRIMARY}]")
            else:
                console.print(f"    [{Colors.MUTED}]{line}[/{Colors.MUTED}]")

        if len(content.split('\n')) > 30:
            console.print(f"    [{Colors.DIM}]... ({len(content.split(chr(10))) - 30} more lines)[/{Colors.DIM}]")

    console.print()
    console.print(f"[{Colors.MUTED}]{footer(SEPARATOR_WIDTH)}[/{Colors.MUTED}]")


@registry.command("install")
@click.argument("component_ids", nargs=-1)
def registry_install(component_ids: tuple[str, ...]):
    """Install components from the registry.

    COMPONENT_IDS format: type:name (e.g., skill:frontend-design rule:typescript plugin:self-improving)
    """
    if not component_ids:
        console.print()
        console.print(f"  [{Colors.WARNING}]usage:[/{Colors.WARNING}] emdash registry install type:name")
        console.print(f"  [{Colors.DIM}]example: emdash registry install skill:frontend-design plugin:self-improving[/{Colors.DIM}]")
        console.print()
        return

    reg = _fetch_registry()
    if not reg:
        return

    console.print()
    for component_id in component_ids:
        if ":" not in component_id:
            console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Invalid format: {component_id}. Use type:name")
            continue

        ctype, name = component_id.split(":", 1)

        # Handle plugin installation separately
        if ctype == "plugin":
            _install_plugin(name, reg)
            continue

        type_plural = ctype + "s" if not ctype.endswith("s") else ctype

        components = reg.get(type_plural, {})
        if name not in components:
            console.print(f"  [{Colors.WARNING}]not found:[/{Colors.WARNING}] {ctype}:{name}")
            continue

        info = components[name]
        content = _fetch_component(info["path"])
        if not content:
            continue

        # Install based on type
        installers = {
            "skill": _install_skill,
            "rule": _install_rule,
            "agent": _install_agent,
            "verifier": _install_verifier,
        }

        installer = installers.get(ctype)
        if not installer:
            console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] Unknown component type: {ctype}")
            continue

        try:
            installer(name, content)
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]installed:[/{Colors.MUTED}] {ctype}:{name}")
        except Exception as e:
            console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] {ctype}:{name} - {e}")
    console.print()


@registry.command("uninstall")
@click.argument("plugin_name")
def registry_uninstall(plugin_name: str):
    """Uninstall a plugin and all its components.

    PLUGIN_NAME: Name of the plugin to uninstall (e.g., self-improving)
    """
    console.print()
    _uninstall_plugin(plugin_name)
    console.print()


@registry.command("installed")
def registry_installed():
    """List installed plugins."""
    _list_installed_plugins()


@registry.command("search")
@click.argument("query")
@click.option("--tag", "-t", multiple=True, help="Filter by tag")
def registry_search(query: str, tag: tuple[str, ...]):
    """Search the registry by name or description."""
    reg = _fetch_registry()
    if not reg:
        return

    query_lower = query.lower()
    tags_lower = [t.lower() for t in tag]

    results = []

    for ctype in ["plugins", "skills", "rules", "agents", "verifiers"]:
        components = reg.get(ctype, {})
        for name, info in components.items():
            # Match query
            matches_query = (
                query_lower in name.lower() or
                query_lower in info.get("description", "").lower()
            )

            # Match tags
            component_tags = [t.lower() for t in info.get("tags", [])]
            matches_tags = not tags_lower or any(t in component_tags for t in tags_lower)

            if matches_query and matches_tags:
                results.append((ctype[:-1], name, info))  # Remove 's' from type

    console.print()
    if not results:
        console.print(f"  [{Colors.DIM}]no results for '{query}'[/{Colors.DIM}]")
        console.print()
        return

    console.print(f"[{Colors.MUTED}]{header(f'Search: {query}', SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print()

    for ctype, name, info in results:
        tags = ", ".join(info.get("tags", []))
        desc = info.get("description", "")
        console.print(f"  [{Colors.PRIMARY}]{ctype}:{name}[/{Colors.PRIMARY}]")
        if desc:
            console.print(f"      [{Colors.MUTED}]{desc}[/{Colors.MUTED}]")
        if tags:
            console.print(f"      [{Colors.DIM}]{tags}[/{Colors.DIM}]")

    console.print()
    console.print(f"[{Colors.MUTED}]{footer(SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print(f"  [{Colors.DIM}]{len(results)} result{'s' if len(results) != 1 else ''}[/{Colors.DIM}]")
    console.print()


def _show_registry_wizard():
    """Show interactive registry wizard."""
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    console.print()
    console.print(f"[{Colors.MUTED}]{header('Registry', SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print()
    console.print(f"  [{Colors.DIM}]browse and install community components[/{Colors.DIM}]")
    console.print()

    # Fetch registry
    console.print(f"  [{Colors.DIM}]fetching...[/{Colors.DIM}]", end="\r")
    reg = _fetch_registry()
    console.print("                    ", end="\r")  # Clear fetching message

    if not reg:
        return

    # Build menu items
    categories = [
        ("plugins", "Plugins", "bundled component packs"),
        ("skills", "Skills", "specialized capabilities"),
        ("rules", "Rules", "coding standards"),
        ("agents", "Agents", "custom configurations"),
        ("verifiers", "Verifiers", "verification configs"),
    ]

    selected_category = [0]
    result = [None]

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_category[0] = (selected_category[0] - 1) % len(categories)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_category[0] = (selected_category[0] + 1) % len(categories)

    @kb.add("enter")
    def select(event):
        result[0] = categories[selected_category[0]][0]
        event.app.exit()

    @kb.add("1")
    def select_1(event):
        result[0] = "plugins"
        event.app.exit()

    @kb.add("2")
    def select_2(event):
        result[0] = "skills"
        event.app.exit()

    @kb.add("3")
    def select_3(event):
        result[0] = "rules"
        event.app.exit()

    @kb.add("4")
    def select_4(event):
        result[0] = "agents"
        event.app.exit()

    @kb.add("5")
    def select_5(event):
        result[0] = "verifiers"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("escape")
    @kb.add("q")
    def cancel(event):
        result[0] = None
        event.app.exit()

    def get_formatted_menu():
        lines = [("class:title", f"─── Categories {'─' * 30}\n\n")]

        for i, (key, name, desc) in enumerate(categories):
            count = len(reg.get(key, {}))
            is_selected = i == selected_category[0]
            prefix = "▸ " if is_selected else "  "

            if is_selected:
                lines.append(("class:selected", f"  {prefix}{name}"))
                lines.append(("class:count-selected", f"  {count}"))
                lines.append(("class:desc-selected", f"  {desc}\n"))
            else:
                lines.append(("class:option", f"  {prefix}{name}"))
                lines.append(("class:count", f"  {count}"))
                lines.append(("class:desc", f"  {desc}\n"))

        lines.append(("class:hint", f"\n{'─' * 45}\n  ↑↓ navigate  Enter select  1-5 quick  q quit"))
        return lines

    style = Style.from_dict({
        "title": f"{Colors.MUTED}",
        "selected": f"{Colors.SUCCESS} bold",
        "count-selected": f"{Colors.SUCCESS}",
        "desc-selected": f"{Colors.SUCCESS}",
        "option": f"{Colors.PRIMARY}",
        "count": f"{Colors.MUTED}",
        "desc": f"{Colors.DIM}",
        "hint": f"{Colors.DIM}",
    })

    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_menu),
                height=len(categories) + 5,
            ),
        ])
    )

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        return

    console.print()

    if result[0] is None:
        return

    # Show components in selected category
    _show_component_picker(reg, result[0])


def _show_component_picker(reg: dict, category: str):
    """Show interactive component picker for a category."""
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    components = reg.get(category, {})
    if not components:
        console.print(f"  [{Colors.WARNING}]No {category} available.[/{Colors.WARNING}]")
        return

    # Build items list
    items = [(name, info) for name, info in components.items()]

    selected_index = [0]
    selected_items = set()  # For multi-select
    result = [None]  # "install", "back", or None

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(items)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(items)

    @kb.add("space")
    def toggle_select(event):
        name = items[selected_index[0]][0]
        if name in selected_items:
            selected_items.remove(name)
        else:
            selected_items.add(name)

    @kb.add("enter")
    def install_selected(event):
        if selected_items:
            result[0] = "install"
        else:
            # Install current item
            selected_items.add(items[selected_index[0]][0])
            result[0] = "install"
        event.app.exit()

    @kb.add("a")
    def select_all(event):
        for name, _ in items:
            selected_items.add(name)

    @kb.add("b")
    @kb.add("escape")
    def go_back(event):
        result[0] = "back"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    def cancel(event):
        result[0] = None
        event.app.exit()

    def get_formatted_menu():
        lines = [("class:title", f"─── {category.title()} {'─' * (40 - len(category))}\n\n")]

        for i, (name, info) in enumerate(items):
            is_selected = i == selected_index[0]
            is_checked = name in selected_items
            prefix = "▸ " if is_selected else "  "
            checkbox = "●" if is_checked else "○"

            desc = info.get("description", "")
            if len(desc) > 45:
                desc = desc[:42] + "..."

            if is_selected:
                lines.append(("class:selected", f"  {prefix}{checkbox} {name}"))
                lines.append(("class:desc-selected", f"  {desc}\n"))
            else:
                style_class = "class:checked" if is_checked else "class:option"
                lines.append((style_class, f"  {prefix}{checkbox} {name}"))
                lines.append(("class:desc", f"  {desc}\n"))

        selected_count = len(selected_items)
        if selected_count > 0:
            lines.append(("class:status", f"\n  {selected_count} selected"))

        lines.append(("class:hint", f"\n{'─' * 45}\n  ↑↓ navigate  Space toggle  Enter install  a all  b back"))
        return lines

    style = Style.from_dict({
        "title": f"{Colors.MUTED}",
        "selected": f"{Colors.SUCCESS} bold",
        "checked": f"{Colors.WARNING}",
        "desc-selected": f"{Colors.SUCCESS}",
        "option": f"{Colors.PRIMARY}",
        "desc": f"{Colors.DIM}",
        "status": f"{Colors.WARNING} bold",
        "hint": f"{Colors.DIM}",
    })

    height = len(items) + 6

    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_menu),
                height=height,
            ),
        ])
    )

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        return

    console.print()

    if result[0] == "back":
        _show_registry_wizard()
        return

    if result[0] == "install" and selected_items:
        singular = category[:-1]

        console.print()

        # Handle plugin installation separately
        if category == "plugins":
            for name in selected_items:
                _install_plugin(name, reg)
        else:
            component_ids = [f"{singular}:{name}" for name in selected_items]
            for cid in component_ids:
                ctype, name = cid.split(":", 1)
                info = components[name]

                console.print(f"  [{Colors.DIM}]installing {cid}...[/{Colors.DIM}]", end="\r")
                content = _fetch_component(info["path"])
                console.print("                                        ", end="\r")  # Clear

                if not content:
                    continue

                installers = {
                    "skill": _install_skill,
                    "rule": _install_rule,
                    "agent": _install_agent,
                    "verifier": _install_verifier,
                }

                installer = installers.get(ctype)
                if installer:
                    try:
                        installer(name, content)
                        console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.MUTED}]installed:[/{Colors.MUTED}] {cid}")
                    except Exception as e:
                        console.print(f"  [{Colors.ERROR}]error:[/{Colors.ERROR}] {cid} - {e}")

        console.print()
