#!/usr/bin/env node
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// dist/index.js
import { readFileSync as readFileSync3, existsSync as existsSync4 } from "node:fs";
import { join as join6 } from "node:path";
import { homedir as homedir3 } from "node:os";

// dist/app.js
import { execSync as execSync4 } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync as readFileSync2, existsSync as existsSync3, unlinkSync as unlinkSync2 } from "node:fs";
import { hostname } from "node:os";
import { join as join5, extname as extname2, isAbsolute } from "node:path";

// node_modules/@mariozechner/pi-tui/dist/autocomplete.js
import { spawnSync } from "child_process";
import { readdirSync, statSync } from "fs";
import { homedir } from "os";
import { basename, dirname, join } from "path";

// node_modules/@mariozechner/pi-tui/dist/fuzzy.js
function fuzzyMatch(query, text) {
  const queryLower = query.toLowerCase();
  const textLower = text.toLowerCase();
  const matchQuery = (normalizedQuery) => {
    if (normalizedQuery.length === 0) {
      return { matches: true, score: 0 };
    }
    if (normalizedQuery.length > textLower.length) {
      return { matches: false, score: 0 };
    }
    let queryIndex = 0;
    let score = 0;
    let lastMatchIndex = -1;
    let consecutiveMatches = 0;
    for (let i = 0; i < textLower.length && queryIndex < normalizedQuery.length; i++) {
      if (textLower[i] === normalizedQuery[queryIndex]) {
        const isWordBoundary = i === 0 || /[\s\-_./:]/.test(textLower[i - 1]);
        if (lastMatchIndex === i - 1) {
          consecutiveMatches++;
          score -= consecutiveMatches * 5;
        } else {
          consecutiveMatches = 0;
          if (lastMatchIndex >= 0) {
            score += (i - lastMatchIndex - 1) * 2;
          }
        }
        if (isWordBoundary) {
          score -= 10;
        }
        score += i * 0.1;
        lastMatchIndex = i;
        queryIndex++;
      }
    }
    if (queryIndex < normalizedQuery.length) {
      return { matches: false, score: 0 };
    }
    return { matches: true, score };
  };
  const primaryMatch = matchQuery(queryLower);
  if (primaryMatch.matches) {
    return primaryMatch;
  }
  const alphaNumericMatch = queryLower.match(/^(?<letters>[a-z]+)(?<digits>[0-9]+)$/);
  const numericAlphaMatch = queryLower.match(/^(?<digits>[0-9]+)(?<letters>[a-z]+)$/);
  const swappedQuery = alphaNumericMatch ? `${alphaNumericMatch.groups?.digits ?? ""}${alphaNumericMatch.groups?.letters ?? ""}` : numericAlphaMatch ? `${numericAlphaMatch.groups?.letters ?? ""}${numericAlphaMatch.groups?.digits ?? ""}` : "";
  if (!swappedQuery) {
    return primaryMatch;
  }
  const swappedMatch = matchQuery(swappedQuery);
  if (!swappedMatch.matches) {
    return primaryMatch;
  }
  return { matches: true, score: swappedMatch.score + 5 };
}
function fuzzyFilter(items, query, getText) {
  if (!query.trim()) {
    return items;
  }
  const tokens = query.trim().split(/\s+/).filter((t) => t.length > 0);
  if (tokens.length === 0) {
    return items;
  }
  const results = [];
  for (const item of items) {
    const text = getText(item);
    let totalScore = 0;
    let allMatch = true;
    for (const token of tokens) {
      const match = fuzzyMatch(token, text);
      if (match.matches) {
        totalScore += match.score;
      } else {
        allMatch = false;
        break;
      }
    }
    if (allMatch) {
      results.push({ item, totalScore });
    }
  }
  results.sort((a, b) => a.totalScore - b.totalScore);
  return results.map((r) => r.item);
}

// node_modules/@mariozechner/pi-tui/dist/autocomplete.js
function walkDirectoryWithFd(baseDir, fdPath, query, maxResults) {
  const args = [
    "--base-directory",
    baseDir,
    "--max-results",
    String(maxResults),
    "--type",
    "f",
    "--type",
    "d",
    "--full-path"
  ];
  if (query) {
    args.push(query);
  }
  const result = spawnSync(fdPath, args, {
    encoding: "utf-8",
    stdio: ["pipe", "pipe", "pipe"],
    maxBuffer: 10 * 1024 * 1024
  });
  if (result.status !== 0 || !result.stdout) {
    return [];
  }
  const lines = result.stdout.trim().split("\n").filter(Boolean);
  const results = [];
  for (const line of lines) {
    const isDirectory = line.endsWith("/");
    results.push({
      path: line,
      isDirectory
    });
  }
  return results;
}
var CombinedAutocompleteProvider = class {
  commands;
  basePath;
  fdPath;
  constructor(commands = [], basePath = process.cwd(), fdPath = null) {
    this.commands = commands;
    this.basePath = basePath;
    this.fdPath = fdPath;
  }
  getSuggestions(lines, cursorLine, cursorCol) {
    const currentLine = lines[cursorLine] || "";
    const textBeforeCursor = currentLine.slice(0, cursorCol);
    const atMatch = textBeforeCursor.match(/(?:^|[\s])(@[^\s]*)$/);
    if (atMatch) {
      const prefix = atMatch[1] ?? "@";
      const query = prefix.slice(1);
      const suggestions = this.getFuzzyFileSuggestions(query);
      if (suggestions.length === 0)
        return null;
      return {
        items: suggestions,
        prefix
      };
    }
    if (textBeforeCursor.startsWith("/")) {
      const spaceIndex = textBeforeCursor.indexOf(" ");
      if (spaceIndex === -1) {
        const prefix = textBeforeCursor.slice(1);
        const commandItems = this.commands.map((cmd) => ({
          name: "name" in cmd ? cmd.name : cmd.value,
          label: "name" in cmd ? cmd.name : cmd.label,
          description: cmd.description
        }));
        const filtered = fuzzyFilter(commandItems, prefix, (item) => item.name).map((item) => ({
          value: item.name,
          label: item.label,
          ...item.description && { description: item.description }
        }));
        if (filtered.length === 0)
          return null;
        return {
          items: filtered,
          prefix: textBeforeCursor
        };
      } else {
        const commandName = textBeforeCursor.slice(1, spaceIndex);
        const argumentText = textBeforeCursor.slice(spaceIndex + 1);
        const command = this.commands.find((cmd) => {
          const name = "name" in cmd ? cmd.name : cmd.value;
          return name === commandName;
        });
        if (!command || !("getArgumentCompletions" in command) || !command.getArgumentCompletions) {
          return null;
        }
        const argumentSuggestions = command.getArgumentCompletions(argumentText);
        if (!argumentSuggestions || argumentSuggestions.length === 0) {
          return null;
        }
        return {
          items: argumentSuggestions,
          prefix: argumentText
        };
      }
    }
    const pathMatch = this.extractPathPrefix(textBeforeCursor, false);
    if (pathMatch !== null) {
      const suggestions = this.getFileSuggestions(pathMatch);
      if (suggestions.length === 0)
        return null;
      if (suggestions.length === 1 && suggestions[0]?.value === pathMatch && !pathMatch.endsWith("/")) {
        return {
          items: suggestions,
          prefix: pathMatch
        };
      }
      return {
        items: suggestions,
        prefix: pathMatch
      };
    }
    return null;
  }
  applyCompletion(lines, cursorLine, cursorCol, item, prefix) {
    const currentLine = lines[cursorLine] || "";
    const beforePrefix = currentLine.slice(0, cursorCol - prefix.length);
    const afterCursor = currentLine.slice(cursorCol);
    const isSlashCommand = prefix.startsWith("/") && beforePrefix.trim() === "" && !prefix.slice(1).includes("/");
    if (isSlashCommand) {
      const newLine2 = `${beforePrefix}/${item.value} ${afterCursor}`;
      const newLines2 = [...lines];
      newLines2[cursorLine] = newLine2;
      return {
        lines: newLines2,
        cursorLine,
        cursorCol: beforePrefix.length + item.value.length + 2
        // +2 for "/" and space
      };
    }
    if (prefix.startsWith("@")) {
      const isDirectory = item.value.endsWith("/");
      const suffix = isDirectory ? "" : " ";
      const newLine2 = `${beforePrefix + item.value}${suffix}${afterCursor}`;
      const newLines2 = [...lines];
      newLines2[cursorLine] = newLine2;
      return {
        lines: newLines2,
        cursorLine,
        cursorCol: beforePrefix.length + item.value.length + suffix.length
      };
    }
    const textBeforeCursor = currentLine.slice(0, cursorCol);
    if (textBeforeCursor.includes("/") && textBeforeCursor.includes(" ")) {
      const newLine2 = beforePrefix + item.value + afterCursor;
      const newLines2 = [...lines];
      newLines2[cursorLine] = newLine2;
      return {
        lines: newLines2,
        cursorLine,
        cursorCol: beforePrefix.length + item.value.length
      };
    }
    const newLine = beforePrefix + item.value + afterCursor;
    const newLines = [...lines];
    newLines[cursorLine] = newLine;
    return {
      lines: newLines,
      cursorLine,
      cursorCol: beforePrefix.length + item.value.length
    };
  }
  // Extract a path-like prefix from the text before cursor
  extractPathPrefix(text, forceExtract = false) {
    const atMatch = text.match(/@([^\s]*)$/);
    if (atMatch) {
      return atMatch[0];
    }
    const lastDelimiterIndex = Math.max(text.lastIndexOf(" "), text.lastIndexOf("	"), text.lastIndexOf('"'), text.lastIndexOf("'"), text.lastIndexOf("="));
    const pathPrefix = lastDelimiterIndex === -1 ? text : text.slice(lastDelimiterIndex + 1);
    if (forceExtract) {
      return pathPrefix;
    }
    if (pathPrefix.includes("/") || pathPrefix.startsWith(".") || pathPrefix.startsWith("~/")) {
      return pathPrefix;
    }
    if (pathPrefix === "" && (text === "" || text.endsWith(" "))) {
      return pathPrefix;
    }
    return null;
  }
  // Expand home directory (~/) to actual home path
  expandHomePath(path2) {
    if (path2.startsWith("~/")) {
      const expandedPath = join(homedir(), path2.slice(2));
      return path2.endsWith("/") && !expandedPath.endsWith("/") ? `${expandedPath}/` : expandedPath;
    } else if (path2 === "~") {
      return homedir();
    }
    return path2;
  }
  // Get file/directory suggestions for a given path prefix
  getFileSuggestions(prefix) {
    try {
      let searchDir;
      let searchPrefix;
      let expandedPrefix = prefix;
      let isAtPrefix = false;
      if (prefix.startsWith("@")) {
        isAtPrefix = true;
        expandedPrefix = prefix.slice(1);
      }
      if (expandedPrefix.startsWith("~")) {
        expandedPrefix = this.expandHomePath(expandedPrefix);
      }
      if (expandedPrefix === "" || expandedPrefix === "./" || expandedPrefix === "../" || expandedPrefix === "~" || expandedPrefix === "~/" || expandedPrefix === "/" || prefix === "@") {
        if (prefix.startsWith("~") || expandedPrefix === "/") {
          searchDir = expandedPrefix;
        } else {
          searchDir = join(this.basePath, expandedPrefix);
        }
        searchPrefix = "";
      } else if (expandedPrefix.endsWith("/")) {
        if (prefix.startsWith("~") || expandedPrefix.startsWith("/")) {
          searchDir = expandedPrefix;
        } else {
          searchDir = join(this.basePath, expandedPrefix);
        }
        searchPrefix = "";
      } else {
        const dir = dirname(expandedPrefix);
        const file = basename(expandedPrefix);
        if (prefix.startsWith("~") || expandedPrefix.startsWith("/")) {
          searchDir = dir;
        } else {
          searchDir = join(this.basePath, dir);
        }
        searchPrefix = file;
      }
      const entries = readdirSync(searchDir, { withFileTypes: true });
      const suggestions = [];
      for (const entry of entries) {
        if (!entry.name.toLowerCase().startsWith(searchPrefix.toLowerCase())) {
          continue;
        }
        let isDirectory = entry.isDirectory();
        if (!isDirectory && entry.isSymbolicLink()) {
          try {
            const fullPath = join(searchDir, entry.name);
            isDirectory = statSync(fullPath).isDirectory();
          } catch {
          }
        }
        let relativePath;
        const name = entry.name;
        if (isAtPrefix) {
          const pathWithoutAt = expandedPrefix;
          if (pathWithoutAt.endsWith("/")) {
            relativePath = `@${pathWithoutAt}${name}`;
          } else if (pathWithoutAt.includes("/")) {
            if (pathWithoutAt.startsWith("~/")) {
              const homeRelativeDir = pathWithoutAt.slice(2);
              const dir = dirname(homeRelativeDir);
              relativePath = `@~/${dir === "." ? name : join(dir, name)}`;
            } else {
              relativePath = `@${join(dirname(pathWithoutAt), name)}`;
            }
          } else {
            if (pathWithoutAt.startsWith("~")) {
              relativePath = `@~/${name}`;
            } else {
              relativePath = `@${name}`;
            }
          }
        } else if (prefix.endsWith("/")) {
          relativePath = prefix + name;
        } else if (prefix.includes("/")) {
          if (prefix.startsWith("~/")) {
            const homeRelativeDir = prefix.slice(2);
            const dir = dirname(homeRelativeDir);
            relativePath = `~/${dir === "." ? name : join(dir, name)}`;
          } else if (prefix.startsWith("/")) {
            const dir = dirname(prefix);
            if (dir === "/") {
              relativePath = `/${name}`;
            } else {
              relativePath = `${dir}/${name}`;
            }
          } else {
            relativePath = join(dirname(prefix), name);
          }
        } else {
          if (prefix.startsWith("~")) {
            relativePath = `~/${name}`;
          } else {
            relativePath = name;
          }
        }
        suggestions.push({
          value: isDirectory ? `${relativePath}/` : relativePath,
          label: name + (isDirectory ? "/" : "")
        });
      }
      suggestions.sort((a, b) => {
        const aIsDir = a.value.endsWith("/");
        const bIsDir = b.value.endsWith("/");
        if (aIsDir && !bIsDir)
          return -1;
        if (!aIsDir && bIsDir)
          return 1;
        return a.label.localeCompare(b.label);
      });
      return suggestions;
    } catch (_e) {
      return [];
    }
  }
  // Score an entry against the query (higher = better match)
  // isDirectory adds bonus to prioritize folders
  scoreEntry(filePath, query, isDirectory) {
    const fileName = basename(filePath);
    const lowerFileName = fileName.toLowerCase();
    const lowerQuery = query.toLowerCase();
    let score = 0;
    if (lowerFileName === lowerQuery)
      score = 100;
    else if (lowerFileName.startsWith(lowerQuery))
      score = 80;
    else if (lowerFileName.includes(lowerQuery))
      score = 50;
    else if (filePath.toLowerCase().includes(lowerQuery))
      score = 30;
    if (isDirectory && score > 0)
      score += 10;
    return score;
  }
  // Fuzzy file search using fd (fast, respects .gitignore)
  getFuzzyFileSuggestions(query) {
    if (!this.fdPath) {
      return [];
    }
    try {
      const entries = walkDirectoryWithFd(this.basePath, this.fdPath, query, 100);
      const scoredEntries = entries.map((entry) => ({
        ...entry,
        score: query ? this.scoreEntry(entry.path, query, entry.isDirectory) : 1
      })).filter((entry) => entry.score > 0);
      scoredEntries.sort((a, b) => b.score - a.score);
      const topEntries = scoredEntries.slice(0, 20);
      const suggestions = [];
      for (const { path: entryPath, isDirectory } of topEntries) {
        const pathWithoutSlash = isDirectory ? entryPath.slice(0, -1) : entryPath;
        const entryName = basename(pathWithoutSlash);
        suggestions.push({
          value: `@${entryPath}`,
          label: entryName + (isDirectory ? "/" : ""),
          description: pathWithoutSlash
        });
      }
      return suggestions;
    } catch {
      return [];
    }
  }
  // Force file completion (called on Tab key) - always returns suggestions
  getForceFileSuggestions(lines, cursorLine, cursorCol) {
    const currentLine = lines[cursorLine] || "";
    const textBeforeCursor = currentLine.slice(0, cursorCol);
    if (textBeforeCursor.trim().startsWith("/") && !textBeforeCursor.trim().includes(" ")) {
      return null;
    }
    const pathMatch = this.extractPathPrefix(textBeforeCursor, true);
    if (pathMatch !== null) {
      const suggestions = this.getFileSuggestions(pathMatch);
      if (suggestions.length === 0)
        return null;
      return {
        items: suggestions,
        prefix: pathMatch
      };
    }
    return null;
  }
  // Check if we should trigger file completion (called on Tab key)
  shouldTriggerFileCompletion(lines, cursorLine, cursorCol) {
    const currentLine = lines[cursorLine] || "";
    const textBeforeCursor = currentLine.slice(0, cursorCol);
    if (textBeforeCursor.trim().startsWith("/") && !textBeforeCursor.trim().includes(" ")) {
      return false;
    }
    return true;
  }
};

// node_modules/get-east-asian-width/lookup.js
function isAmbiguous(x) {
  return x === 161 || x === 164 || x === 167 || x === 168 || x === 170 || x === 173 || x === 174 || x >= 176 && x <= 180 || x >= 182 && x <= 186 || x >= 188 && x <= 191 || x === 198 || x === 208 || x === 215 || x === 216 || x >= 222 && x <= 225 || x === 230 || x >= 232 && x <= 234 || x === 236 || x === 237 || x === 240 || x === 242 || x === 243 || x >= 247 && x <= 250 || x === 252 || x === 254 || x === 257 || x === 273 || x === 275 || x === 283 || x === 294 || x === 295 || x === 299 || x >= 305 && x <= 307 || x === 312 || x >= 319 && x <= 322 || x === 324 || x >= 328 && x <= 331 || x === 333 || x === 338 || x === 339 || x === 358 || x === 359 || x === 363 || x === 462 || x === 464 || x === 466 || x === 468 || x === 470 || x === 472 || x === 474 || x === 476 || x === 593 || x === 609 || x === 708 || x === 711 || x >= 713 && x <= 715 || x === 717 || x === 720 || x >= 728 && x <= 731 || x === 733 || x === 735 || x >= 768 && x <= 879 || x >= 913 && x <= 929 || x >= 931 && x <= 937 || x >= 945 && x <= 961 || x >= 963 && x <= 969 || x === 1025 || x >= 1040 && x <= 1103 || x === 1105 || x === 8208 || x >= 8211 && x <= 8214 || x === 8216 || x === 8217 || x === 8220 || x === 8221 || x >= 8224 && x <= 8226 || x >= 8228 && x <= 8231 || x === 8240 || x === 8242 || x === 8243 || x === 8245 || x === 8251 || x === 8254 || x === 8308 || x === 8319 || x >= 8321 && x <= 8324 || x === 8364 || x === 8451 || x === 8453 || x === 8457 || x === 8467 || x === 8470 || x === 8481 || x === 8482 || x === 8486 || x === 8491 || x === 8531 || x === 8532 || x >= 8539 && x <= 8542 || x >= 8544 && x <= 8555 || x >= 8560 && x <= 8569 || x === 8585 || x >= 8592 && x <= 8601 || x === 8632 || x === 8633 || x === 8658 || x === 8660 || x === 8679 || x === 8704 || x === 8706 || x === 8707 || x === 8711 || x === 8712 || x === 8715 || x === 8719 || x === 8721 || x === 8725 || x === 8730 || x >= 8733 && x <= 8736 || x === 8739 || x === 8741 || x >= 8743 && x <= 8748 || x === 8750 || x >= 8756 && x <= 8759 || x === 8764 || x === 8765 || x === 8776 || x === 8780 || x === 8786 || x === 8800 || x === 8801 || x >= 8804 && x <= 8807 || x === 8810 || x === 8811 || x === 8814 || x === 8815 || x === 8834 || x === 8835 || x === 8838 || x === 8839 || x === 8853 || x === 8857 || x === 8869 || x === 8895 || x === 8978 || x >= 9312 && x <= 9449 || x >= 9451 && x <= 9547 || x >= 9552 && x <= 9587 || x >= 9600 && x <= 9615 || x >= 9618 && x <= 9621 || x === 9632 || x === 9633 || x >= 9635 && x <= 9641 || x === 9650 || x === 9651 || x === 9654 || x === 9655 || x === 9660 || x === 9661 || x === 9664 || x === 9665 || x >= 9670 && x <= 9672 || x === 9675 || x >= 9678 && x <= 9681 || x >= 9698 && x <= 9701 || x === 9711 || x === 9733 || x === 9734 || x === 9737 || x === 9742 || x === 9743 || x === 9756 || x === 9758 || x === 9792 || x === 9794 || x === 9824 || x === 9825 || x >= 9827 && x <= 9829 || x >= 9831 && x <= 9834 || x === 9836 || x === 9837 || x === 9839 || x === 9886 || x === 9887 || x === 9919 || x >= 9926 && x <= 9933 || x >= 9935 && x <= 9939 || x >= 9941 && x <= 9953 || x === 9955 || x === 9960 || x === 9961 || x >= 9963 && x <= 9969 || x === 9972 || x >= 9974 && x <= 9977 || x === 9979 || x === 9980 || x === 9982 || x === 9983 || x === 10045 || x >= 10102 && x <= 10111 || x >= 11094 && x <= 11097 || x >= 12872 && x <= 12879 || x >= 57344 && x <= 63743 || x >= 65024 && x <= 65039 || x === 65533 || x >= 127232 && x <= 127242 || x >= 127248 && x <= 127277 || x >= 127280 && x <= 127337 || x >= 127344 && x <= 127373 || x === 127375 || x === 127376 || x >= 127387 && x <= 127404 || x >= 917760 && x <= 917999 || x >= 983040 && x <= 1048573 || x >= 1048576 && x <= 1114109;
}
function isFullWidth(x) {
  return x === 12288 || x >= 65281 && x <= 65376 || x >= 65504 && x <= 65510;
}
function isWide(x) {
  return x >= 4352 && x <= 4447 || x === 8986 || x === 8987 || x === 9001 || x === 9002 || x >= 9193 && x <= 9196 || x === 9200 || x === 9203 || x === 9725 || x === 9726 || x === 9748 || x === 9749 || x >= 9776 && x <= 9783 || x >= 9800 && x <= 9811 || x === 9855 || x >= 9866 && x <= 9871 || x === 9875 || x === 9889 || x === 9898 || x === 9899 || x === 9917 || x === 9918 || x === 9924 || x === 9925 || x === 9934 || x === 9940 || x === 9962 || x === 9970 || x === 9971 || x === 9973 || x === 9978 || x === 9981 || x === 9989 || x === 9994 || x === 9995 || x === 10024 || x === 10060 || x === 10062 || x >= 10067 && x <= 10069 || x === 10071 || x >= 10133 && x <= 10135 || x === 10160 || x === 10175 || x === 11035 || x === 11036 || x === 11088 || x === 11093 || x >= 11904 && x <= 11929 || x >= 11931 && x <= 12019 || x >= 12032 && x <= 12245 || x >= 12272 && x <= 12287 || x >= 12289 && x <= 12350 || x >= 12353 && x <= 12438 || x >= 12441 && x <= 12543 || x >= 12549 && x <= 12591 || x >= 12593 && x <= 12686 || x >= 12688 && x <= 12773 || x >= 12783 && x <= 12830 || x >= 12832 && x <= 12871 || x >= 12880 && x <= 42124 || x >= 42128 && x <= 42182 || x >= 43360 && x <= 43388 || x >= 44032 && x <= 55203 || x >= 63744 && x <= 64255 || x >= 65040 && x <= 65049 || x >= 65072 && x <= 65106 || x >= 65108 && x <= 65126 || x >= 65128 && x <= 65131 || x >= 94176 && x <= 94180 || x >= 94192 && x <= 94198 || x >= 94208 && x <= 101589 || x >= 101631 && x <= 101662 || x >= 101760 && x <= 101874 || x >= 110576 && x <= 110579 || x >= 110581 && x <= 110587 || x === 110589 || x === 110590 || x >= 110592 && x <= 110882 || x === 110898 || x >= 110928 && x <= 110930 || x === 110933 || x >= 110948 && x <= 110951 || x >= 110960 && x <= 111355 || x >= 119552 && x <= 119638 || x >= 119648 && x <= 119670 || x === 126980 || x === 127183 || x === 127374 || x >= 127377 && x <= 127386 || x >= 127488 && x <= 127490 || x >= 127504 && x <= 127547 || x >= 127552 && x <= 127560 || x === 127568 || x === 127569 || x >= 127584 && x <= 127589 || x >= 127744 && x <= 127776 || x >= 127789 && x <= 127797 || x >= 127799 && x <= 127868 || x >= 127870 && x <= 127891 || x >= 127904 && x <= 127946 || x >= 127951 && x <= 127955 || x >= 127968 && x <= 127984 || x === 127988 || x >= 127992 && x <= 128062 || x === 128064 || x >= 128066 && x <= 128252 || x >= 128255 && x <= 128317 || x >= 128331 && x <= 128334 || x >= 128336 && x <= 128359 || x === 128378 || x === 128405 || x === 128406 || x === 128420 || x >= 128507 && x <= 128591 || x >= 128640 && x <= 128709 || x === 128716 || x >= 128720 && x <= 128722 || x >= 128725 && x <= 128728 || x >= 128732 && x <= 128735 || x === 128747 || x === 128748 || x >= 128756 && x <= 128764 || x >= 128992 && x <= 129003 || x === 129008 || x >= 129292 && x <= 129338 || x >= 129340 && x <= 129349 || x >= 129351 && x <= 129535 || x >= 129648 && x <= 129660 || x >= 129664 && x <= 129674 || x >= 129678 && x <= 129734 || x === 129736 || x >= 129741 && x <= 129756 || x >= 129759 && x <= 129770 || x >= 129775 && x <= 129784 || x >= 131072 && x <= 196605 || x >= 196608 && x <= 262141;
}

// node_modules/get-east-asian-width/index.js
function validate(codePoint) {
  if (!Number.isSafeInteger(codePoint)) {
    throw new TypeError(`Expected a code point, got \`${typeof codePoint}\`.`);
  }
}
function eastAsianWidth(codePoint, { ambiguousAsWide = false } = {}) {
  validate(codePoint);
  if (isFullWidth(codePoint) || isWide(codePoint) || ambiguousAsWide && isAmbiguous(codePoint)) {
    return 2;
  }
  return 1;
}

// node_modules/@mariozechner/pi-tui/dist/utils.js
var segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
function getSegmenter() {
  return segmenter;
}
function couldBeEmoji(segment) {
  const cp = segment.codePointAt(0);
  return cp >= 126976 && cp <= 130047 || // Emoji and Pictograph
  cp >= 8960 && cp <= 9215 || // Misc technical
  cp >= 9728 && cp <= 10175 || // Misc symbols, dingbats
  cp >= 11088 && cp <= 11093 || // Specific stars/circles
  segment.includes("\uFE0F") || // Contains VS16 (emoji presentation selector)
  segment.length > 2;
}
var zeroWidthRegex = new RegExp("^(?:\\p{Default_Ignorable_Code_Point}|\\p{Control}|\\p{Mark}|\\p{Surrogate})+$", "v");
var leadingNonPrintingRegex = new RegExp("^[\\p{Default_Ignorable_Code_Point}\\p{Control}\\p{Format}\\p{Mark}\\p{Surrogate}]+", "v");
var rgiEmojiRegex = new RegExp("^\\p{RGI_Emoji}$", "v");
var WIDTH_CACHE_SIZE = 512;
var widthCache = /* @__PURE__ */ new Map();
function graphemeWidth(segment) {
  if (zeroWidthRegex.test(segment)) {
    return 0;
  }
  if (couldBeEmoji(segment) && rgiEmojiRegex.test(segment)) {
    return 2;
  }
  const base = segment.replace(leadingNonPrintingRegex, "");
  const cp = base.codePointAt(0);
  if (cp === void 0) {
    return 0;
  }
  let width = eastAsianWidth(cp);
  if (segment.length > 1) {
    for (const char of segment.slice(1)) {
      const c = char.codePointAt(0);
      if (c >= 65280 && c <= 65519) {
        width += eastAsianWidth(c);
      }
    }
  }
  return width;
}
function visibleWidth(str) {
  if (str.length === 0) {
    return 0;
  }
  let isPureAscii = true;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    if (code < 32 || code > 126) {
      isPureAscii = false;
      break;
    }
  }
  if (isPureAscii) {
    return str.length;
  }
  const cached = widthCache.get(str);
  if (cached !== void 0) {
    return cached;
  }
  let clean = str;
  if (str.includes("	")) {
    clean = clean.replace(/\t/g, "   ");
  }
  if (clean.includes("\x1B")) {
    clean = clean.replace(/\x1b\[[0-9;]*[mGKHJ]/g, "");
    clean = clean.replace(/\x1b\]8;;[^\x07]*\x07/g, "");
    clean = clean.replace(/\x1b_[^\x07\x1b]*(?:\x07|\x1b\\)/g, "");
  }
  let width = 0;
  for (const { segment } of segmenter.segment(clean)) {
    width += graphemeWidth(segment);
  }
  if (widthCache.size >= WIDTH_CACHE_SIZE) {
    const firstKey = widthCache.keys().next().value;
    if (firstKey !== void 0) {
      widthCache.delete(firstKey);
    }
  }
  widthCache.set(str, width);
  return width;
}
function extractAnsiCode(str, pos) {
  if (pos >= str.length || str[pos] !== "\x1B")
    return null;
  const next = str[pos + 1];
  if (next === "[") {
    let j = pos + 2;
    while (j < str.length && !/[mGKHJ]/.test(str[j]))
      j++;
    if (j < str.length)
      return { code: str.substring(pos, j + 1), length: j + 1 - pos };
    return null;
  }
  if (next === "]") {
    let j = pos + 2;
    while (j < str.length) {
      if (str[j] === "\x07")
        return { code: str.substring(pos, j + 1), length: j + 1 - pos };
      if (str[j] === "\x1B" && str[j + 1] === "\\")
        return { code: str.substring(pos, j + 2), length: j + 2 - pos };
      j++;
    }
    return null;
  }
  if (next === "_") {
    let j = pos + 2;
    while (j < str.length) {
      if (str[j] === "\x07")
        return { code: str.substring(pos, j + 1), length: j + 1 - pos };
      if (str[j] === "\x1B" && str[j + 1] === "\\")
        return { code: str.substring(pos, j + 2), length: j + 2 - pos };
      j++;
    }
    return null;
  }
  return null;
}
var AnsiCodeTracker = class {
  // Track individual attributes separately so we can reset them specifically
  bold = false;
  dim = false;
  italic = false;
  underline = false;
  blink = false;
  inverse = false;
  hidden = false;
  strikethrough = false;
  fgColor = null;
  // Stores the full code like "31" or "38;5;240"
  bgColor = null;
  // Stores the full code like "41" or "48;5;240"
  process(ansiCode) {
    if (!ansiCode.endsWith("m")) {
      return;
    }
    const match = ansiCode.match(/\x1b\[([\d;]*)m/);
    if (!match)
      return;
    const params = match[1];
    if (params === "" || params === "0") {
      this.reset();
      return;
    }
    const parts = params.split(";");
    let i = 0;
    while (i < parts.length) {
      const code = Number.parseInt(parts[i], 10);
      if (code === 38 || code === 48) {
        if (parts[i + 1] === "5" && parts[i + 2] !== void 0) {
          const colorCode = `${parts[i]};${parts[i + 1]};${parts[i + 2]}`;
          if (code === 38) {
            this.fgColor = colorCode;
          } else {
            this.bgColor = colorCode;
          }
          i += 3;
          continue;
        } else if (parts[i + 1] === "2" && parts[i + 4] !== void 0) {
          const colorCode = `${parts[i]};${parts[i + 1]};${parts[i + 2]};${parts[i + 3]};${parts[i + 4]}`;
          if (code === 38) {
            this.fgColor = colorCode;
          } else {
            this.bgColor = colorCode;
          }
          i += 5;
          continue;
        }
      }
      switch (code) {
        case 0:
          this.reset();
          break;
        case 1:
          this.bold = true;
          break;
        case 2:
          this.dim = true;
          break;
        case 3:
          this.italic = true;
          break;
        case 4:
          this.underline = true;
          break;
        case 5:
          this.blink = true;
          break;
        case 7:
          this.inverse = true;
          break;
        case 8:
          this.hidden = true;
          break;
        case 9:
          this.strikethrough = true;
          break;
        case 21:
          this.bold = false;
          break;
        // Some terminals
        case 22:
          this.bold = false;
          this.dim = false;
          break;
        case 23:
          this.italic = false;
          break;
        case 24:
          this.underline = false;
          break;
        case 25:
          this.blink = false;
          break;
        case 27:
          this.inverse = false;
          break;
        case 28:
          this.hidden = false;
          break;
        case 29:
          this.strikethrough = false;
          break;
        case 39:
          this.fgColor = null;
          break;
        // Default fg
        case 49:
          this.bgColor = null;
          break;
        // Default bg
        default:
          if (code >= 30 && code <= 37 || code >= 90 && code <= 97) {
            this.fgColor = String(code);
          } else if (code >= 40 && code <= 47 || code >= 100 && code <= 107) {
            this.bgColor = String(code);
          }
          break;
      }
      i++;
    }
  }
  reset() {
    this.bold = false;
    this.dim = false;
    this.italic = false;
    this.underline = false;
    this.blink = false;
    this.inverse = false;
    this.hidden = false;
    this.strikethrough = false;
    this.fgColor = null;
    this.bgColor = null;
  }
  /** Clear all state for reuse. */
  clear() {
    this.reset();
  }
  getActiveCodes() {
    const codes = [];
    if (this.bold)
      codes.push("1");
    if (this.dim)
      codes.push("2");
    if (this.italic)
      codes.push("3");
    if (this.underline)
      codes.push("4");
    if (this.blink)
      codes.push("5");
    if (this.inverse)
      codes.push("7");
    if (this.hidden)
      codes.push("8");
    if (this.strikethrough)
      codes.push("9");
    if (this.fgColor)
      codes.push(this.fgColor);
    if (this.bgColor)
      codes.push(this.bgColor);
    if (codes.length === 0)
      return "";
    return `\x1B[${codes.join(";")}m`;
  }
  hasActiveCodes() {
    return this.bold || this.dim || this.italic || this.underline || this.blink || this.inverse || this.hidden || this.strikethrough || this.fgColor !== null || this.bgColor !== null;
  }
  /**
   * Get reset codes for attributes that need to be turned off at line end,
   * specifically underline which bleeds into padding.
   * Returns empty string if no problematic attributes are active.
   */
  getLineEndReset() {
    if (this.underline) {
      return "\x1B[24m";
    }
    return "";
  }
};
function updateTrackerFromText(text, tracker) {
  let i = 0;
  while (i < text.length) {
    const ansiResult = extractAnsiCode(text, i);
    if (ansiResult) {
      tracker.process(ansiResult.code);
      i += ansiResult.length;
    } else {
      i++;
    }
  }
}
function splitIntoTokensWithAnsi(text) {
  const tokens = [];
  let current = "";
  let pendingAnsi = "";
  let inWhitespace = false;
  let i = 0;
  while (i < text.length) {
    const ansiResult = extractAnsiCode(text, i);
    if (ansiResult) {
      pendingAnsi += ansiResult.code;
      i += ansiResult.length;
      continue;
    }
    const char = text[i];
    const charIsSpace = char === " ";
    if (charIsSpace !== inWhitespace && current) {
      tokens.push(current);
      current = "";
    }
    if (pendingAnsi) {
      current += pendingAnsi;
      pendingAnsi = "";
    }
    inWhitespace = charIsSpace;
    current += char;
    i++;
  }
  if (pendingAnsi) {
    current += pendingAnsi;
  }
  if (current) {
    tokens.push(current);
  }
  return tokens;
}
function wrapTextWithAnsi(text, width) {
  if (!text) {
    return [""];
  }
  const inputLines = text.split("\n");
  const result = [];
  const tracker = new AnsiCodeTracker();
  for (const inputLine of inputLines) {
    const prefix = result.length > 0 ? tracker.getActiveCodes() : "";
    result.push(...wrapSingleLine(prefix + inputLine, width));
    updateTrackerFromText(inputLine, tracker);
  }
  return result.length > 0 ? result : [""];
}
function wrapSingleLine(line, width) {
  if (!line) {
    return [""];
  }
  const visibleLength = visibleWidth(line);
  if (visibleLength <= width) {
    return [line];
  }
  const wrapped = [];
  const tracker = new AnsiCodeTracker();
  const tokens = splitIntoTokensWithAnsi(line);
  let currentLine = "";
  let currentVisibleLength = 0;
  for (const token of tokens) {
    const tokenVisibleLength = visibleWidth(token);
    const isWhitespace = token.trim() === "";
    if (tokenVisibleLength > width && !isWhitespace) {
      if (currentLine) {
        const lineEndReset = tracker.getLineEndReset();
        if (lineEndReset) {
          currentLine += lineEndReset;
        }
        wrapped.push(currentLine);
        currentLine = "";
        currentVisibleLength = 0;
      }
      const broken = breakLongWord(token, width, tracker);
      wrapped.push(...broken.slice(0, -1));
      currentLine = broken[broken.length - 1];
      currentVisibleLength = visibleWidth(currentLine);
      continue;
    }
    const totalNeeded = currentVisibleLength + tokenVisibleLength;
    if (totalNeeded > width && currentVisibleLength > 0) {
      let lineToWrap = currentLine.trimEnd();
      const lineEndReset = tracker.getLineEndReset();
      if (lineEndReset) {
        lineToWrap += lineEndReset;
      }
      wrapped.push(lineToWrap);
      if (isWhitespace) {
        currentLine = tracker.getActiveCodes();
        currentVisibleLength = 0;
      } else {
        currentLine = tracker.getActiveCodes() + token;
        currentVisibleLength = tokenVisibleLength;
      }
    } else {
      currentLine += token;
      currentVisibleLength += tokenVisibleLength;
    }
    updateTrackerFromText(token, tracker);
  }
  if (currentLine) {
    wrapped.push(currentLine);
  }
  return wrapped.length > 0 ? wrapped.map((line2) => line2.trimEnd()) : [""];
}
var PUNCTUATION_REGEX = /[(){}[\]<>.,;:'"!?+\-=*/\\|&%^$#@~`]/;
function isWhitespaceChar(char) {
  return /\s/.test(char);
}
function isPunctuationChar(char) {
  return PUNCTUATION_REGEX.test(char);
}
function breakLongWord(word, width, tracker) {
  const lines = [];
  let currentLine = tracker.getActiveCodes();
  let currentWidth = 0;
  let i = 0;
  const segments = [];
  while (i < word.length) {
    const ansiResult = extractAnsiCode(word, i);
    if (ansiResult) {
      segments.push({ type: "ansi", value: ansiResult.code });
      i += ansiResult.length;
    } else {
      let end = i;
      while (end < word.length) {
        const nextAnsi = extractAnsiCode(word, end);
        if (nextAnsi)
          break;
        end++;
      }
      const textPortion = word.slice(i, end);
      for (const seg of segmenter.segment(textPortion)) {
        segments.push({ type: "grapheme", value: seg.segment });
      }
      i = end;
    }
  }
  for (const seg of segments) {
    if (seg.type === "ansi") {
      currentLine += seg.value;
      tracker.process(seg.value);
      continue;
    }
    const grapheme = seg.value;
    if (!grapheme)
      continue;
    const graphemeWidth2 = visibleWidth(grapheme);
    if (currentWidth + graphemeWidth2 > width) {
      const lineEndReset = tracker.getLineEndReset();
      if (lineEndReset) {
        currentLine += lineEndReset;
      }
      lines.push(currentLine);
      currentLine = tracker.getActiveCodes();
      currentWidth = 0;
    }
    currentLine += grapheme;
    currentWidth += graphemeWidth2;
  }
  if (currentLine) {
    lines.push(currentLine);
  }
  return lines.length > 0 ? lines : [""];
}
function applyBackgroundToLine(line, width, bgFn) {
  const visibleLen = visibleWidth(line);
  const paddingNeeded = Math.max(0, width - visibleLen);
  const padding = " ".repeat(paddingNeeded);
  const withPadding = line + padding;
  return bgFn(withPadding);
}
function truncateToWidth(text, maxWidth, ellipsis = "...", pad = false) {
  const textVisibleWidth = visibleWidth(text);
  if (textVisibleWidth <= maxWidth) {
    return pad ? text + " ".repeat(maxWidth - textVisibleWidth) : text;
  }
  const ellipsisWidth = visibleWidth(ellipsis);
  const targetWidth = maxWidth - ellipsisWidth;
  if (targetWidth <= 0) {
    return ellipsis.substring(0, maxWidth);
  }
  let i = 0;
  const segments = [];
  while (i < text.length) {
    const ansiResult = extractAnsiCode(text, i);
    if (ansiResult) {
      segments.push({ type: "ansi", value: ansiResult.code });
      i += ansiResult.length;
    } else {
      let end = i;
      while (end < text.length) {
        const nextAnsi = extractAnsiCode(text, end);
        if (nextAnsi)
          break;
        end++;
      }
      const textPortion = text.slice(i, end);
      for (const seg of segmenter.segment(textPortion)) {
        segments.push({ type: "grapheme", value: seg.segment });
      }
      i = end;
    }
  }
  let result = "";
  let currentWidth = 0;
  for (const seg of segments) {
    if (seg.type === "ansi") {
      result += seg.value;
      continue;
    }
    const grapheme = seg.value;
    if (!grapheme)
      continue;
    const graphemeWidth2 = visibleWidth(grapheme);
    if (currentWidth + graphemeWidth2 > targetWidth) {
      break;
    }
    result += grapheme;
    currentWidth += graphemeWidth2;
  }
  const truncated = `${result}\x1B[0m${ellipsis}`;
  if (pad) {
    const truncatedWidth = visibleWidth(truncated);
    return truncated + " ".repeat(Math.max(0, maxWidth - truncatedWidth));
  }
  return truncated;
}
function sliceByColumn(line, startCol, length, strict = false) {
  return sliceWithWidth(line, startCol, length, strict).text;
}
function sliceWithWidth(line, startCol, length, strict = false) {
  if (length <= 0)
    return { text: "", width: 0 };
  const endCol = startCol + length;
  let result = "", resultWidth = 0, currentCol = 0, i = 0, pendingAnsi = "";
  while (i < line.length) {
    const ansi = extractAnsiCode(line, i);
    if (ansi) {
      if (currentCol >= startCol && currentCol < endCol)
        result += ansi.code;
      else if (currentCol < startCol)
        pendingAnsi += ansi.code;
      i += ansi.length;
      continue;
    }
    let textEnd = i;
    while (textEnd < line.length && !extractAnsiCode(line, textEnd))
      textEnd++;
    for (const { segment } of segmenter.segment(line.slice(i, textEnd))) {
      const w = graphemeWidth(segment);
      const inRange = currentCol >= startCol && currentCol < endCol;
      const fits = !strict || currentCol + w <= endCol;
      if (inRange && fits) {
        if (pendingAnsi) {
          result += pendingAnsi;
          pendingAnsi = "";
        }
        result += segment;
        resultWidth += w;
      }
      currentCol += w;
      if (currentCol >= endCol)
        break;
    }
    i = textEnd;
    if (currentCol >= endCol)
      break;
  }
  return { text: result, width: resultWidth };
}
var pooledStyleTracker = new AnsiCodeTracker();
function extractSegments(line, beforeEnd, afterStart, afterLen, strictAfter = false) {
  let before = "", beforeWidth = 0, after = "", afterWidth = 0;
  let currentCol = 0, i = 0;
  let pendingAnsiBefore = "";
  let afterStarted = false;
  const afterEnd = afterStart + afterLen;
  pooledStyleTracker.clear();
  while (i < line.length) {
    const ansi = extractAnsiCode(line, i);
    if (ansi) {
      pooledStyleTracker.process(ansi.code);
      if (currentCol < beforeEnd) {
        pendingAnsiBefore += ansi.code;
      } else if (currentCol >= afterStart && currentCol < afterEnd && afterStarted) {
        after += ansi.code;
      }
      i += ansi.length;
      continue;
    }
    let textEnd = i;
    while (textEnd < line.length && !extractAnsiCode(line, textEnd))
      textEnd++;
    for (const { segment } of segmenter.segment(line.slice(i, textEnd))) {
      const w = graphemeWidth(segment);
      if (currentCol < beforeEnd) {
        if (pendingAnsiBefore) {
          before += pendingAnsiBefore;
          pendingAnsiBefore = "";
        }
        before += segment;
        beforeWidth += w;
      } else if (currentCol >= afterStart && currentCol < afterEnd) {
        const fits = !strictAfter || currentCol + w <= afterEnd;
        if (fits) {
          if (!afterStarted) {
            after += pooledStyleTracker.getActiveCodes();
            afterStarted = true;
          }
          after += segment;
          afterWidth += w;
        }
      }
      currentCol += w;
      if (afterLen <= 0 ? currentCol >= beforeEnd : currentCol >= afterEnd)
        break;
    }
    i = textEnd;
    if (afterLen <= 0 ? currentCol >= beforeEnd : currentCol >= afterEnd)
      break;
  }
  return { before, beforeWidth, after, afterWidth };
}

// node_modules/@mariozechner/pi-tui/dist/keys.js
var _kittyProtocolActive = false;
function setKittyProtocolActive(active) {
  _kittyProtocolActive = active;
}
var SYMBOL_KEYS = /* @__PURE__ */ new Set([
  "`",
  "-",
  "=",
  "[",
  "]",
  "\\",
  ";",
  "'",
  ",",
  ".",
  "/",
  "!",
  "@",
  "#",
  "$",
  "%",
  "^",
  "&",
  "*",
  "(",
  ")",
  "_",
  "+",
  "|",
  "~",
  "{",
  "}",
  ":",
  "<",
  ">",
  "?"
]);
var MODIFIERS = {
  shift: 1,
  alt: 2,
  ctrl: 4
};
var LOCK_MASK = 64 + 128;
var CODEPOINTS = {
  escape: 27,
  tab: 9,
  enter: 13,
  space: 32,
  backspace: 127,
  kpEnter: 57414
  // Numpad Enter (Kitty protocol)
};
var ARROW_CODEPOINTS = {
  up: -1,
  down: -2,
  right: -3,
  left: -4
};
var FUNCTIONAL_CODEPOINTS = {
  delete: -10,
  insert: -11,
  pageUp: -12,
  pageDown: -13,
  home: -14,
  end: -15
};
var LEGACY_KEY_SEQUENCES = {
  up: ["\x1B[A", "\x1BOA"],
  down: ["\x1B[B", "\x1BOB"],
  right: ["\x1B[C", "\x1BOC"],
  left: ["\x1B[D", "\x1BOD"],
  home: ["\x1B[H", "\x1BOH", "\x1B[1~", "\x1B[7~"],
  end: ["\x1B[F", "\x1BOF", "\x1B[4~", "\x1B[8~"],
  insert: ["\x1B[2~"],
  delete: ["\x1B[3~"],
  pageUp: ["\x1B[5~", "\x1B[[5~"],
  pageDown: ["\x1B[6~", "\x1B[[6~"],
  clear: ["\x1B[E", "\x1BOE"],
  f1: ["\x1BOP", "\x1B[11~", "\x1B[[A"],
  f2: ["\x1BOQ", "\x1B[12~", "\x1B[[B"],
  f3: ["\x1BOR", "\x1B[13~", "\x1B[[C"],
  f4: ["\x1BOS", "\x1B[14~", "\x1B[[D"],
  f5: ["\x1B[15~", "\x1B[[E"],
  f6: ["\x1B[17~"],
  f7: ["\x1B[18~"],
  f8: ["\x1B[19~"],
  f9: ["\x1B[20~"],
  f10: ["\x1B[21~"],
  f11: ["\x1B[23~"],
  f12: ["\x1B[24~"]
};
var LEGACY_SHIFT_SEQUENCES = {
  up: ["\x1B[a"],
  down: ["\x1B[b"],
  right: ["\x1B[c"],
  left: ["\x1B[d"],
  clear: ["\x1B[e"],
  insert: ["\x1B[2$"],
  delete: ["\x1B[3$"],
  pageUp: ["\x1B[5$"],
  pageDown: ["\x1B[6$"],
  home: ["\x1B[7$"],
  end: ["\x1B[8$"]
};
var LEGACY_CTRL_SEQUENCES = {
  up: ["\x1BOa"],
  down: ["\x1BOb"],
  right: ["\x1BOc"],
  left: ["\x1BOd"],
  clear: ["\x1BOe"],
  insert: ["\x1B[2^"],
  delete: ["\x1B[3^"],
  pageUp: ["\x1B[5^"],
  pageDown: ["\x1B[6^"],
  home: ["\x1B[7^"],
  end: ["\x1B[8^"]
};
var matchesLegacySequence = (data, sequences) => sequences.includes(data);
var matchesLegacyModifierSequence = (data, key, modifier) => {
  if (modifier === MODIFIERS.shift) {
    return matchesLegacySequence(data, LEGACY_SHIFT_SEQUENCES[key]);
  }
  if (modifier === MODIFIERS.ctrl) {
    return matchesLegacySequence(data, LEGACY_CTRL_SEQUENCES[key]);
  }
  return false;
};
var _lastEventType = "press";
function isKeyRelease(data) {
  if (data.includes("\x1B[200~")) {
    return false;
  }
  if (data.includes(":3u") || data.includes(":3~") || data.includes(":3A") || data.includes(":3B") || data.includes(":3C") || data.includes(":3D") || data.includes(":3H") || data.includes(":3F")) {
    return true;
  }
  return false;
}
function parseEventType(eventTypeStr) {
  if (!eventTypeStr)
    return "press";
  const eventType = parseInt(eventTypeStr, 10);
  if (eventType === 2)
    return "repeat";
  if (eventType === 3)
    return "release";
  return "press";
}
function parseKittySequence(data) {
  const csiUMatch = data.match(/^\x1b\[(\d+)(?::(\d*))?(?::(\d+))?(?:;(\d+))?(?::(\d+))?u$/);
  if (csiUMatch) {
    const codepoint = parseInt(csiUMatch[1], 10);
    const shiftedKey = csiUMatch[2] && csiUMatch[2].length > 0 ? parseInt(csiUMatch[2], 10) : void 0;
    const baseLayoutKey = csiUMatch[3] ? parseInt(csiUMatch[3], 10) : void 0;
    const modValue = csiUMatch[4] ? parseInt(csiUMatch[4], 10) : 1;
    const eventType = parseEventType(csiUMatch[5]);
    _lastEventType = eventType;
    return { codepoint, shiftedKey, baseLayoutKey, modifier: modValue - 1, eventType };
  }
  const arrowMatch = data.match(/^\x1b\[1;(\d+)(?::(\d+))?([ABCD])$/);
  if (arrowMatch) {
    const modValue = parseInt(arrowMatch[1], 10);
    const eventType = parseEventType(arrowMatch[2]);
    const arrowCodes = { A: -1, B: -2, C: -3, D: -4 };
    _lastEventType = eventType;
    return { codepoint: arrowCodes[arrowMatch[3]], modifier: modValue - 1, eventType };
  }
  const funcMatch = data.match(/^\x1b\[(\d+)(?:;(\d+))?(?::(\d+))?~$/);
  if (funcMatch) {
    const keyNum = parseInt(funcMatch[1], 10);
    const modValue = funcMatch[2] ? parseInt(funcMatch[2], 10) : 1;
    const eventType = parseEventType(funcMatch[3]);
    const funcCodes = {
      2: FUNCTIONAL_CODEPOINTS.insert,
      3: FUNCTIONAL_CODEPOINTS.delete,
      5: FUNCTIONAL_CODEPOINTS.pageUp,
      6: FUNCTIONAL_CODEPOINTS.pageDown,
      7: FUNCTIONAL_CODEPOINTS.home,
      8: FUNCTIONAL_CODEPOINTS.end
    };
    const codepoint = funcCodes[keyNum];
    if (codepoint !== void 0) {
      _lastEventType = eventType;
      return { codepoint, modifier: modValue - 1, eventType };
    }
  }
  const homeEndMatch = data.match(/^\x1b\[1;(\d+)(?::(\d+))?([HF])$/);
  if (homeEndMatch) {
    const modValue = parseInt(homeEndMatch[1], 10);
    const eventType = parseEventType(homeEndMatch[2]);
    const codepoint = homeEndMatch[3] === "H" ? FUNCTIONAL_CODEPOINTS.home : FUNCTIONAL_CODEPOINTS.end;
    _lastEventType = eventType;
    return { codepoint, modifier: modValue - 1, eventType };
  }
  return null;
}
function matchesKittySequence(data, expectedCodepoint, expectedModifier) {
  const parsed = parseKittySequence(data);
  if (!parsed)
    return false;
  const actualMod = parsed.modifier & ~LOCK_MASK;
  const expectedMod = expectedModifier & ~LOCK_MASK;
  if (actualMod !== expectedMod)
    return false;
  if (parsed.codepoint === expectedCodepoint)
    return true;
  if (parsed.baseLayoutKey !== void 0 && parsed.baseLayoutKey === expectedCodepoint)
    return true;
  return false;
}
function matchesModifyOtherKeys(data, expectedKeycode, expectedModifier) {
  const match = data.match(/^\x1b\[27;(\d+);(\d+)~$/);
  if (!match)
    return false;
  const modValue = parseInt(match[1], 10);
  const keycode = parseInt(match[2], 10);
  const actualMod = modValue - 1;
  return keycode === expectedKeycode && actualMod === expectedModifier;
}
function rawCtrlChar(key) {
  const char = key.toLowerCase();
  const code = char.charCodeAt(0);
  if (code >= 97 && code <= 122 || char === "[" || char === "\\" || char === "]" || char === "_") {
    return String.fromCharCode(code & 31);
  }
  if (char === "-") {
    return String.fromCharCode(31);
  }
  return null;
}
function parseKeyId(keyId) {
  const parts = keyId.toLowerCase().split("+");
  const key = parts[parts.length - 1];
  if (!key)
    return null;
  return {
    key,
    ctrl: parts.includes("ctrl"),
    shift: parts.includes("shift"),
    alt: parts.includes("alt")
  };
}
function matchesKey(data, keyId) {
  const parsed = parseKeyId(keyId);
  if (!parsed)
    return false;
  const { key, ctrl, shift, alt } = parsed;
  let modifier = 0;
  if (shift)
    modifier |= MODIFIERS.shift;
  if (alt)
    modifier |= MODIFIERS.alt;
  if (ctrl)
    modifier |= MODIFIERS.ctrl;
  switch (key) {
    case "escape":
    case "esc":
      if (modifier !== 0)
        return false;
      return data === "\x1B" || matchesKittySequence(data, CODEPOINTS.escape, 0);
    case "space":
      if (!_kittyProtocolActive) {
        if (ctrl && !alt && !shift && data === "\0") {
          return true;
        }
        if (alt && !ctrl && !shift && data === "\x1B ") {
          return true;
        }
      }
      if (modifier === 0) {
        return data === " " || matchesKittySequence(data, CODEPOINTS.space, 0);
      }
      return matchesKittySequence(data, CODEPOINTS.space, modifier);
    case "tab":
      if (shift && !ctrl && !alt) {
        return data === "\x1B[Z" || matchesKittySequence(data, CODEPOINTS.tab, MODIFIERS.shift);
      }
      if (modifier === 0) {
        return data === "	" || matchesKittySequence(data, CODEPOINTS.tab, 0);
      }
      return matchesKittySequence(data, CODEPOINTS.tab, modifier);
    case "enter":
    case "return":
      if (shift && !ctrl && !alt) {
        if (matchesKittySequence(data, CODEPOINTS.enter, MODIFIERS.shift) || matchesKittySequence(data, CODEPOINTS.kpEnter, MODIFIERS.shift)) {
          return true;
        }
        if (matchesModifyOtherKeys(data, CODEPOINTS.enter, MODIFIERS.shift)) {
          return true;
        }
        if (_kittyProtocolActive) {
          return data === "\x1B\r" || data === "\n";
        }
        return false;
      }
      if (alt && !ctrl && !shift) {
        if (matchesKittySequence(data, CODEPOINTS.enter, MODIFIERS.alt) || matchesKittySequence(data, CODEPOINTS.kpEnter, MODIFIERS.alt)) {
          return true;
        }
        if (matchesModifyOtherKeys(data, CODEPOINTS.enter, MODIFIERS.alt)) {
          return true;
        }
        if (!_kittyProtocolActive) {
          return data === "\x1B\r";
        }
        return false;
      }
      if (modifier === 0) {
        return data === "\r" || !_kittyProtocolActive && data === "\n" || data === "\x1BOM" || // SS3 M (numpad enter in some terminals)
        matchesKittySequence(data, CODEPOINTS.enter, 0) || matchesKittySequence(data, CODEPOINTS.kpEnter, 0);
      }
      return matchesKittySequence(data, CODEPOINTS.enter, modifier) || matchesKittySequence(data, CODEPOINTS.kpEnter, modifier);
    case "backspace":
      if (alt && !ctrl && !shift) {
        if (data === "\x1B\x7F" || data === "\x1B\b") {
          return true;
        }
        return matchesKittySequence(data, CODEPOINTS.backspace, MODIFIERS.alt);
      }
      if (modifier === 0) {
        return data === "\x7F" || data === "\b" || matchesKittySequence(data, CODEPOINTS.backspace, 0);
      }
      return matchesKittySequence(data, CODEPOINTS.backspace, modifier);
    case "insert":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.insert) || matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.insert, 0);
      }
      if (matchesLegacyModifierSequence(data, "insert", modifier)) {
        return true;
      }
      return matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.insert, modifier);
    case "delete":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.delete) || matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.delete, 0);
      }
      if (matchesLegacyModifierSequence(data, "delete", modifier)) {
        return true;
      }
      return matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.delete, modifier);
    case "clear":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.clear);
      }
      return matchesLegacyModifierSequence(data, "clear", modifier);
    case "home":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.home) || matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.home, 0);
      }
      if (matchesLegacyModifierSequence(data, "home", modifier)) {
        return true;
      }
      return matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.home, modifier);
    case "end":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.end) || matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.end, 0);
      }
      if (matchesLegacyModifierSequence(data, "end", modifier)) {
        return true;
      }
      return matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.end, modifier);
    case "pageup":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.pageUp) || matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.pageUp, 0);
      }
      if (matchesLegacyModifierSequence(data, "pageUp", modifier)) {
        return true;
      }
      return matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.pageUp, modifier);
    case "pagedown":
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.pageDown) || matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.pageDown, 0);
      }
      if (matchesLegacyModifierSequence(data, "pageDown", modifier)) {
        return true;
      }
      return matchesKittySequence(data, FUNCTIONAL_CODEPOINTS.pageDown, modifier);
    case "up":
      if (alt && !ctrl && !shift) {
        return data === "\x1Bp" || matchesKittySequence(data, ARROW_CODEPOINTS.up, MODIFIERS.alt);
      }
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.up) || matchesKittySequence(data, ARROW_CODEPOINTS.up, 0);
      }
      if (matchesLegacyModifierSequence(data, "up", modifier)) {
        return true;
      }
      return matchesKittySequence(data, ARROW_CODEPOINTS.up, modifier);
    case "down":
      if (alt && !ctrl && !shift) {
        return data === "\x1Bn" || matchesKittySequence(data, ARROW_CODEPOINTS.down, MODIFIERS.alt);
      }
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.down) || matchesKittySequence(data, ARROW_CODEPOINTS.down, 0);
      }
      if (matchesLegacyModifierSequence(data, "down", modifier)) {
        return true;
      }
      return matchesKittySequence(data, ARROW_CODEPOINTS.down, modifier);
    case "left":
      if (alt && !ctrl && !shift) {
        return data === "\x1B[1;3D" || !_kittyProtocolActive && data === "\x1BB" || data === "\x1Bb" || matchesKittySequence(data, ARROW_CODEPOINTS.left, MODIFIERS.alt);
      }
      if (ctrl && !alt && !shift) {
        return data === "\x1B[1;5D" || matchesLegacyModifierSequence(data, "left", MODIFIERS.ctrl) || matchesKittySequence(data, ARROW_CODEPOINTS.left, MODIFIERS.ctrl);
      }
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.left) || matchesKittySequence(data, ARROW_CODEPOINTS.left, 0);
      }
      if (matchesLegacyModifierSequence(data, "left", modifier)) {
        return true;
      }
      return matchesKittySequence(data, ARROW_CODEPOINTS.left, modifier);
    case "right":
      if (alt && !ctrl && !shift) {
        return data === "\x1B[1;3C" || !_kittyProtocolActive && data === "\x1BF" || data === "\x1Bf" || matchesKittySequence(data, ARROW_CODEPOINTS.right, MODIFIERS.alt);
      }
      if (ctrl && !alt && !shift) {
        return data === "\x1B[1;5C" || matchesLegacyModifierSequence(data, "right", MODIFIERS.ctrl) || matchesKittySequence(data, ARROW_CODEPOINTS.right, MODIFIERS.ctrl);
      }
      if (modifier === 0) {
        return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES.right) || matchesKittySequence(data, ARROW_CODEPOINTS.right, 0);
      }
      if (matchesLegacyModifierSequence(data, "right", modifier)) {
        return true;
      }
      return matchesKittySequence(data, ARROW_CODEPOINTS.right, modifier);
    case "f1":
    case "f2":
    case "f3":
    case "f4":
    case "f5":
    case "f6":
    case "f7":
    case "f8":
    case "f9":
    case "f10":
    case "f11":
    case "f12": {
      if (modifier !== 0) {
        return false;
      }
      const functionKey = key;
      return matchesLegacySequence(data, LEGACY_KEY_SEQUENCES[functionKey]);
    }
  }
  if (key.length === 1 && (key >= "a" && key <= "z" || SYMBOL_KEYS.has(key))) {
    const codepoint = key.charCodeAt(0);
    const rawCtrl = rawCtrlChar(key);
    if (ctrl && alt && !shift && !_kittyProtocolActive && rawCtrl) {
      return data === `\x1B${rawCtrl}`;
    }
    if (alt && !ctrl && !shift && !_kittyProtocolActive && key >= "a" && key <= "z") {
      if (data === `\x1B${key}`)
        return true;
    }
    if (ctrl && !shift && !alt) {
      if (rawCtrl && data === rawCtrl)
        return true;
      return matchesKittySequence(data, codepoint, MODIFIERS.ctrl);
    }
    if (ctrl && shift && !alt) {
      return matchesKittySequence(data, codepoint, MODIFIERS.shift + MODIFIERS.ctrl);
    }
    if (shift && !ctrl && !alt) {
      if (data === key.toUpperCase())
        return true;
      return matchesKittySequence(data, codepoint, MODIFIERS.shift);
    }
    if (modifier !== 0) {
      return matchesKittySequence(data, codepoint, modifier);
    }
    return data === key || matchesKittySequence(data, codepoint, 0);
  }
  return false;
}

// node_modules/@mariozechner/pi-tui/dist/keybindings.js
var DEFAULT_EDITOR_KEYBINDINGS = {
  // Cursor movement
  cursorUp: "up",
  cursorDown: "down",
  cursorLeft: "left",
  cursorRight: "right",
  cursorWordLeft: ["alt+left", "ctrl+left"],
  cursorWordRight: ["alt+right", "ctrl+right"],
  cursorLineStart: ["home", "ctrl+a"],
  cursorLineEnd: ["end", "ctrl+e"],
  pageUp: "pageUp",
  pageDown: "pageDown",
  // Deletion
  deleteCharBackward: "backspace",
  deleteCharForward: "delete",
  deleteWordBackward: ["ctrl+w", "alt+backspace"],
  deleteWordForward: ["alt+d", "alt+delete"],
  deleteToLineStart: "ctrl+u",
  deleteToLineEnd: "ctrl+k",
  // Text input
  newLine: "shift+enter",
  submit: "enter",
  tab: "tab",
  // Selection/autocomplete
  selectUp: "up",
  selectDown: "down",
  selectPageUp: "pageUp",
  selectPageDown: "pageDown",
  selectConfirm: "enter",
  selectCancel: ["escape", "ctrl+c"],
  // Clipboard
  copy: "ctrl+c",
  // Kill ring
  yank: "ctrl+y",
  yankPop: "alt+y",
  // Undo
  undo: "ctrl+-",
  // Tool output
  expandTools: "ctrl+o"
};
var EditorKeybindingsManager = class {
  actionToKeys;
  constructor(config = {}) {
    this.actionToKeys = /* @__PURE__ */ new Map();
    this.buildMaps(config);
  }
  buildMaps(config) {
    this.actionToKeys.clear();
    for (const [action, keys] of Object.entries(DEFAULT_EDITOR_KEYBINDINGS)) {
      const keyArray = Array.isArray(keys) ? keys : [keys];
      this.actionToKeys.set(action, [...keyArray]);
    }
    for (const [action, keys] of Object.entries(config)) {
      if (keys === void 0)
        continue;
      const keyArray = Array.isArray(keys) ? keys : [keys];
      this.actionToKeys.set(action, keyArray);
    }
  }
  /**
   * Check if input matches a specific action.
   */
  matches(data, action) {
    const keys = this.actionToKeys.get(action);
    if (!keys)
      return false;
    for (const key of keys) {
      if (matchesKey(data, key))
        return true;
    }
    return false;
  }
  /**
   * Get keys bound to an action.
   */
  getKeys(action) {
    return this.actionToKeys.get(action) ?? [];
  }
  /**
   * Update configuration.
   */
  setConfig(config) {
    this.buildMaps(config);
  }
};
var globalEditorKeybindings = null;
function getEditorKeybindings() {
  if (!globalEditorKeybindings) {
    globalEditorKeybindings = new EditorKeybindingsManager();
  }
  return globalEditorKeybindings;
}

// node_modules/@mariozechner/pi-tui/dist/components/text.js
var Text = class {
  text;
  paddingX;
  // Left/right padding
  paddingY;
  // Top/bottom padding
  customBgFn;
  // Cache for rendered output
  cachedText;
  cachedWidth;
  cachedLines;
  constructor(text = "", paddingX = 1, paddingY = 1, customBgFn) {
    this.text = text;
    this.paddingX = paddingX;
    this.paddingY = paddingY;
    this.customBgFn = customBgFn;
  }
  setText(text) {
    this.text = text;
    this.cachedText = void 0;
    this.cachedWidth = void 0;
    this.cachedLines = void 0;
  }
  setCustomBgFn(customBgFn) {
    this.customBgFn = customBgFn;
    this.cachedText = void 0;
    this.cachedWidth = void 0;
    this.cachedLines = void 0;
  }
  invalidate() {
    this.cachedText = void 0;
    this.cachedWidth = void 0;
    this.cachedLines = void 0;
  }
  render(width) {
    if (this.cachedLines && this.cachedText === this.text && this.cachedWidth === width) {
      return this.cachedLines;
    }
    if (!this.text || this.text.trim() === "") {
      const result2 = [];
      this.cachedText = this.text;
      this.cachedWidth = width;
      this.cachedLines = result2;
      return result2;
    }
    const normalizedText = this.text.replace(/\t/g, "   ");
    const contentWidth = Math.max(1, width - this.paddingX * 2);
    const wrappedLines = wrapTextWithAnsi(normalizedText, contentWidth);
    const leftMargin = " ".repeat(this.paddingX);
    const rightMargin = " ".repeat(this.paddingX);
    const contentLines = [];
    for (const line of wrappedLines) {
      const lineWithMargins = leftMargin + line + rightMargin;
      if (this.customBgFn) {
        contentLines.push(applyBackgroundToLine(lineWithMargins, width, this.customBgFn));
      } else {
        const visibleLen = visibleWidth(lineWithMargins);
        const paddingNeeded = Math.max(0, width - visibleLen);
        contentLines.push(lineWithMargins + " ".repeat(paddingNeeded));
      }
    }
    const emptyLine = " ".repeat(width);
    const emptyLines = [];
    for (let i = 0; i < this.paddingY; i++) {
      const line = this.customBgFn ? applyBackgroundToLine(emptyLine, width, this.customBgFn) : emptyLine;
      emptyLines.push(line);
    }
    const result = [...emptyLines, ...contentLines, ...emptyLines];
    this.cachedText = this.text;
    this.cachedWidth = width;
    this.cachedLines = result;
    return result.length > 0 ? result : [""];
  }
};

// node_modules/@mariozechner/pi-tui/dist/tui.js
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

// node_modules/@mariozechner/pi-tui/dist/terminal-image.js
var cachedCapabilities = null;
var cellDimensions = { widthPx: 9, heightPx: 18 };
function getCellDimensions() {
  return cellDimensions;
}
function setCellDimensions(dims) {
  cellDimensions = dims;
}
function detectCapabilities() {
  const termProgram = process.env.TERM_PROGRAM?.toLowerCase() || "";
  const term = process.env.TERM?.toLowerCase() || "";
  const colorTerm = process.env.COLORTERM?.toLowerCase() || "";
  if (process.env.KITTY_WINDOW_ID || termProgram === "kitty") {
    return { images: "kitty", trueColor: true, hyperlinks: true };
  }
  if (termProgram === "ghostty" || term.includes("ghostty") || process.env.GHOSTTY_RESOURCES_DIR) {
    return { images: "kitty", trueColor: true, hyperlinks: true };
  }
  if (process.env.WEZTERM_PANE || termProgram === "wezterm") {
    return { images: "kitty", trueColor: true, hyperlinks: true };
  }
  if (process.env.ITERM_SESSION_ID || termProgram === "iterm.app") {
    return { images: "iterm2", trueColor: true, hyperlinks: true };
  }
  if (termProgram === "vscode") {
    return { images: null, trueColor: true, hyperlinks: true };
  }
  if (termProgram === "alacritty") {
    return { images: null, trueColor: true, hyperlinks: true };
  }
  const trueColor = colorTerm === "truecolor" || colorTerm === "24bit";
  return { images: null, trueColor, hyperlinks: true };
}
function getCapabilities() {
  if (!cachedCapabilities) {
    cachedCapabilities = detectCapabilities();
  }
  return cachedCapabilities;
}
function encodeKitty(base64Data, options3 = {}) {
  const CHUNK_SIZE = 4096;
  const params = ["a=T", "f=100", "q=2"];
  if (options3.columns)
    params.push(`c=${options3.columns}`);
  if (options3.rows)
    params.push(`r=${options3.rows}`);
  if (options3.imageId)
    params.push(`i=${options3.imageId}`);
  if (base64Data.length <= CHUNK_SIZE) {
    return `\x1B_G${params.join(",")};${base64Data}\x1B\\`;
  }
  const chunks = [];
  let offset = 0;
  let isFirst = true;
  while (offset < base64Data.length) {
    const chunk = base64Data.slice(offset, offset + CHUNK_SIZE);
    const isLast = offset + CHUNK_SIZE >= base64Data.length;
    if (isFirst) {
      chunks.push(`\x1B_G${params.join(",")},m=1;${chunk}\x1B\\`);
      isFirst = false;
    } else if (isLast) {
      chunks.push(`\x1B_Gm=0;${chunk}\x1B\\`);
    } else {
      chunks.push(`\x1B_Gm=1;${chunk}\x1B\\`);
    }
    offset += CHUNK_SIZE;
  }
  return chunks.join("");
}
function encodeITerm2(base64Data, options3 = {}) {
  const params = [`inline=${options3.inline !== false ? 1 : 0}`];
  if (options3.width !== void 0)
    params.push(`width=${options3.width}`);
  if (options3.height !== void 0)
    params.push(`height=${options3.height}`);
  if (options3.name) {
    const nameBase64 = Buffer.from(options3.name).toString("base64");
    params.push(`name=${nameBase64}`);
  }
  if (options3.preserveAspectRatio === false) {
    params.push("preserveAspectRatio=0");
  }
  return `\x1B]1337;File=${params.join(";")}:${base64Data}\x07`;
}
function calculateImageRows(imageDimensions, targetWidthCells, cellDimensions2 = { widthPx: 9, heightPx: 18 }) {
  const targetWidthPx = targetWidthCells * cellDimensions2.widthPx;
  const scale = targetWidthPx / imageDimensions.widthPx;
  const scaledHeightPx = imageDimensions.heightPx * scale;
  const rows = Math.ceil(scaledHeightPx / cellDimensions2.heightPx);
  return Math.max(1, rows);
}
function getPngDimensions(base64Data) {
  try {
    const buffer = Buffer.from(base64Data, "base64");
    if (buffer.length < 24) {
      return null;
    }
    if (buffer[0] !== 137 || buffer[1] !== 80 || buffer[2] !== 78 || buffer[3] !== 71) {
      return null;
    }
    const width = buffer.readUInt32BE(16);
    const height = buffer.readUInt32BE(20);
    return { widthPx: width, heightPx: height };
  } catch {
    return null;
  }
}
function getJpegDimensions(base64Data) {
  try {
    const buffer = Buffer.from(base64Data, "base64");
    if (buffer.length < 2) {
      return null;
    }
    if (buffer[0] !== 255 || buffer[1] !== 216) {
      return null;
    }
    let offset = 2;
    while (offset < buffer.length - 9) {
      if (buffer[offset] !== 255) {
        offset++;
        continue;
      }
      const marker = buffer[offset + 1];
      if (marker >= 192 && marker <= 194) {
        const height = buffer.readUInt16BE(offset + 5);
        const width = buffer.readUInt16BE(offset + 7);
        return { widthPx: width, heightPx: height };
      }
      if (offset + 3 >= buffer.length) {
        return null;
      }
      const length = buffer.readUInt16BE(offset + 2);
      if (length < 2) {
        return null;
      }
      offset += 2 + length;
    }
    return null;
  } catch {
    return null;
  }
}
function getGifDimensions(base64Data) {
  try {
    const buffer = Buffer.from(base64Data, "base64");
    if (buffer.length < 10) {
      return null;
    }
    const sig = buffer.slice(0, 6).toString("ascii");
    if (sig !== "GIF87a" && sig !== "GIF89a") {
      return null;
    }
    const width = buffer.readUInt16LE(6);
    const height = buffer.readUInt16LE(8);
    return { widthPx: width, heightPx: height };
  } catch {
    return null;
  }
}
function getWebpDimensions(base64Data) {
  try {
    const buffer = Buffer.from(base64Data, "base64");
    if (buffer.length < 30) {
      return null;
    }
    const riff = buffer.slice(0, 4).toString("ascii");
    const webp = buffer.slice(8, 12).toString("ascii");
    if (riff !== "RIFF" || webp !== "WEBP") {
      return null;
    }
    const chunk = buffer.slice(12, 16).toString("ascii");
    if (chunk === "VP8 ") {
      if (buffer.length < 30)
        return null;
      const width = buffer.readUInt16LE(26) & 16383;
      const height = buffer.readUInt16LE(28) & 16383;
      return { widthPx: width, heightPx: height };
    } else if (chunk === "VP8L") {
      if (buffer.length < 25)
        return null;
      const bits = buffer.readUInt32LE(21);
      const width = (bits & 16383) + 1;
      const height = (bits >> 14 & 16383) + 1;
      return { widthPx: width, heightPx: height };
    } else if (chunk === "VP8X") {
      if (buffer.length < 30)
        return null;
      const width = (buffer[24] | buffer[25] << 8 | buffer[26] << 16) + 1;
      const height = (buffer[27] | buffer[28] << 8 | buffer[29] << 16) + 1;
      return { widthPx: width, heightPx: height };
    }
    return null;
  } catch {
    return null;
  }
}
function getImageDimensions(base64Data, mimeType) {
  if (mimeType === "image/png") {
    return getPngDimensions(base64Data);
  }
  if (mimeType === "image/jpeg") {
    return getJpegDimensions(base64Data);
  }
  if (mimeType === "image/gif") {
    return getGifDimensions(base64Data);
  }
  if (mimeType === "image/webp") {
    return getWebpDimensions(base64Data);
  }
  return null;
}
function renderImage(base64Data, imageDimensions, options3 = {}) {
  const caps = getCapabilities();
  if (!caps.images) {
    return null;
  }
  const maxWidth = options3.maxWidthCells ?? 80;
  const rows = calculateImageRows(imageDimensions, maxWidth, getCellDimensions());
  if (caps.images === "kitty") {
    const sequence = encodeKitty(base64Data, { columns: maxWidth, rows });
    return { sequence, rows };
  }
  if (caps.images === "iterm2") {
    const sequence = encodeITerm2(base64Data, {
      width: maxWidth,
      height: "auto",
      preserveAspectRatio: options3.preserveAspectRatio ?? true
    });
    return { sequence, rows };
  }
  return null;
}
function imageFallback(mimeType, dimensions, filename) {
  const parts = [];
  if (filename)
    parts.push(filename);
  parts.push(`[${mimeType}]`);
  if (dimensions)
    parts.push(`${dimensions.widthPx}x${dimensions.heightPx}`);
  return `[Image: ${parts.join(" ")}]`;
}

// node_modules/@mariozechner/pi-tui/dist/tui.js
function isFocusable(component) {
  return component !== null && "focused" in component;
}
var CURSOR_MARKER = "\x1B_pi:c\x07";
function parseSizeValue(value, referenceSize) {
  if (value === void 0)
    return void 0;
  if (typeof value === "number")
    return value;
  const match = value.match(/^(\d+(?:\.\d+)?)%$/);
  if (match) {
    return Math.floor(referenceSize * parseFloat(match[1]) / 100);
  }
  return void 0;
}
var Container = class {
  children = [];
  addChild(component) {
    this.children.push(component);
  }
  removeChild(component) {
    const index = this.children.indexOf(component);
    if (index !== -1) {
      this.children.splice(index, 1);
    }
  }
  clear() {
    this.children = [];
  }
  invalidate() {
    for (const child of this.children) {
      child.invalidate?.();
    }
  }
  render(width) {
    const lines = [];
    for (const child of this.children) {
      lines.push(...child.render(width));
    }
    return lines;
  }
};
var TUI = class _TUI extends Container {
  terminal;
  previousLines = [];
  previousWidth = 0;
  focusedComponent = null;
  /** Global callback for debug key (Shift+Ctrl+D). Called before input is forwarded to focused component. */
  onDebug;
  renderRequested = false;
  cursorRow = 0;
  // Logical cursor row (end of rendered content)
  hardwareCursorRow = 0;
  // Actual terminal cursor row (may differ due to IME positioning)
  inputBuffer = "";
  // Buffer for parsing terminal responses
  cellSizeQueryPending = false;
  showHardwareCursor = process.env.PI_HARDWARE_CURSOR === "1";
  maxLinesRendered = 0;
  // Track terminal's working area (max lines ever rendered)
  // Overlay stack for modal components rendered on top of base content
  overlayStack = [];
  constructor(terminal, showHardwareCursor) {
    super();
    this.terminal = terminal;
    if (showHardwareCursor !== void 0) {
      this.showHardwareCursor = showHardwareCursor;
    }
  }
  getShowHardwareCursor() {
    return this.showHardwareCursor;
  }
  setShowHardwareCursor(enabled) {
    if (this.showHardwareCursor === enabled)
      return;
    this.showHardwareCursor = enabled;
    if (!enabled) {
      this.terminal.hideCursor();
    }
    this.requestRender();
  }
  setFocus(component) {
    if (isFocusable(this.focusedComponent)) {
      this.focusedComponent.focused = false;
    }
    this.focusedComponent = component;
    if (isFocusable(component)) {
      component.focused = true;
    }
  }
  /**
   * Show an overlay component with configurable positioning and sizing.
   * Returns a handle to control the overlay's visibility.
   */
  showOverlay(component, options3) {
    const entry = { component, options: options3, preFocus: this.focusedComponent, hidden: false };
    this.overlayStack.push(entry);
    if (this.isOverlayVisible(entry)) {
      this.setFocus(component);
    }
    this.terminal.hideCursor();
    this.requestRender();
    return {
      hide: () => {
        const index = this.overlayStack.indexOf(entry);
        if (index !== -1) {
          this.overlayStack.splice(index, 1);
          if (this.focusedComponent === component) {
            const topVisible = this.getTopmostVisibleOverlay();
            this.setFocus(topVisible?.component ?? entry.preFocus);
          }
          if (this.overlayStack.length === 0)
            this.terminal.hideCursor();
          this.requestRender();
        }
      },
      setHidden: (hidden) => {
        if (entry.hidden === hidden)
          return;
        entry.hidden = hidden;
        if (hidden) {
          if (this.focusedComponent === component) {
            const topVisible = this.getTopmostVisibleOverlay();
            this.setFocus(topVisible?.component ?? entry.preFocus);
          }
        } else {
          if (this.isOverlayVisible(entry)) {
            this.setFocus(component);
          }
        }
        this.requestRender();
      },
      isHidden: () => entry.hidden
    };
  }
  /** Hide the topmost overlay and restore previous focus. */
  hideOverlay() {
    const overlay = this.overlayStack.pop();
    if (!overlay)
      return;
    const topVisible = this.getTopmostVisibleOverlay();
    this.setFocus(topVisible?.component ?? overlay.preFocus);
    if (this.overlayStack.length === 0)
      this.terminal.hideCursor();
    this.requestRender();
  }
  /** Check if there are any visible overlays */
  hasOverlay() {
    return this.overlayStack.some((o) => this.isOverlayVisible(o));
  }
  /** Check if an overlay entry is currently visible */
  isOverlayVisible(entry) {
    if (entry.hidden)
      return false;
    if (entry.options?.visible) {
      return entry.options.visible(this.terminal.columns, this.terminal.rows);
    }
    return true;
  }
  /** Find the topmost visible overlay, if any */
  getTopmostVisibleOverlay() {
    for (let i = this.overlayStack.length - 1; i >= 0; i--) {
      if (this.isOverlayVisible(this.overlayStack[i])) {
        return this.overlayStack[i];
      }
    }
    return void 0;
  }
  invalidate() {
    super.invalidate();
    for (const overlay of this.overlayStack)
      overlay.component.invalidate?.();
  }
  start() {
    this.terminal.start((data) => this.handleInput(data), () => this.requestRender());
    this.terminal.hideCursor();
    this.queryCellSize();
    this.requestRender();
  }
  queryCellSize() {
    if (!getCapabilities().images) {
      return;
    }
    this.cellSizeQueryPending = true;
    this.terminal.write("\x1B[16t");
  }
  stop() {
    if (this.previousLines.length > 0) {
      const targetRow = this.previousLines.length;
      const lineDiff = targetRow - this.hardwareCursorRow;
      if (lineDiff > 0) {
        this.terminal.write(`\x1B[${lineDiff}B`);
      } else if (lineDiff < 0) {
        this.terminal.write(`\x1B[${-lineDiff}A`);
      }
      this.terminal.write("\r\n");
    }
    this.terminal.showCursor();
    this.terminal.stop();
  }
  requestRender(force = false) {
    if (force) {
      this.previousLines = [];
      this.previousWidth = -1;
      this.cursorRow = 0;
      this.hardwareCursorRow = 0;
      this.maxLinesRendered = 0;
    }
    if (this.renderRequested)
      return;
    this.renderRequested = true;
    process.nextTick(() => {
      this.renderRequested = false;
      this.doRender();
    });
  }
  handleInput(data) {
    if (this.cellSizeQueryPending) {
      this.inputBuffer += data;
      const filtered = this.parseCellSizeResponse();
      if (filtered.length === 0)
        return;
      data = filtered;
    }
    if (matchesKey(data, "shift+ctrl+d") && this.onDebug) {
      this.onDebug();
      return;
    }
    const focusedOverlay = this.overlayStack.find((o) => o.component === this.focusedComponent);
    if (focusedOverlay && !this.isOverlayVisible(focusedOverlay)) {
      const topVisible = this.getTopmostVisibleOverlay();
      if (topVisible) {
        this.setFocus(topVisible.component);
      } else {
        this.setFocus(focusedOverlay.preFocus);
      }
    }
    if (this.focusedComponent?.handleInput) {
      if (isKeyRelease(data) && !this.focusedComponent.wantsKeyRelease) {
        return;
      }
      this.focusedComponent.handleInput(data);
      this.requestRender();
    }
  }
  parseCellSizeResponse() {
    const responsePattern = /\x1b\[6;(\d+);(\d+)t/;
    const match = this.inputBuffer.match(responsePattern);
    if (match) {
      const heightPx = parseInt(match[1], 10);
      const widthPx = parseInt(match[2], 10);
      if (heightPx > 0 && widthPx > 0) {
        setCellDimensions({ widthPx, heightPx });
        this.invalidate();
        this.requestRender();
      }
      this.inputBuffer = this.inputBuffer.replace(responsePattern, "");
      this.cellSizeQueryPending = false;
    }
    const partialCellSizePattern = /\x1b(\[6?;?[\d;]*)?$/;
    if (partialCellSizePattern.test(this.inputBuffer)) {
      const lastChar = this.inputBuffer[this.inputBuffer.length - 1];
      if (!/[a-zA-Z~]/.test(lastChar)) {
        return "";
      }
    }
    const result = this.inputBuffer;
    this.inputBuffer = "";
    this.cellSizeQueryPending = false;
    return result;
  }
  containsImage(line) {
    return line.includes("\x1B_G") || line.includes("\x1B]1337;File=");
  }
  /**
   * Resolve overlay layout from options.
   * Returns { width, row, col, maxHeight } for rendering.
   */
  resolveOverlayLayout(options3, overlayHeight, termWidth, termHeight) {
    const opt = options3 ?? {};
    const margin = typeof opt.margin === "number" ? { top: opt.margin, right: opt.margin, bottom: opt.margin, left: opt.margin } : opt.margin ?? {};
    const marginTop = Math.max(0, margin.top ?? 0);
    const marginRight = Math.max(0, margin.right ?? 0);
    const marginBottom = Math.max(0, margin.bottom ?? 0);
    const marginLeft = Math.max(0, margin.left ?? 0);
    const availWidth = Math.max(1, termWidth - marginLeft - marginRight);
    const availHeight = Math.max(1, termHeight - marginTop - marginBottom);
    let width = parseSizeValue(opt.width, termWidth) ?? Math.min(80, availWidth);
    if (opt.minWidth !== void 0) {
      width = Math.max(width, opt.minWidth);
    }
    width = Math.max(1, Math.min(width, availWidth));
    let maxHeight = parseSizeValue(opt.maxHeight, termHeight);
    if (maxHeight !== void 0) {
      maxHeight = Math.max(1, Math.min(maxHeight, availHeight));
    }
    const effectiveHeight = maxHeight !== void 0 ? Math.min(overlayHeight, maxHeight) : overlayHeight;
    let row;
    let col;
    if (opt.row !== void 0) {
      if (typeof opt.row === "string") {
        const match = opt.row.match(/^(\d+(?:\.\d+)?)%$/);
        if (match) {
          const maxRow = Math.max(0, availHeight - effectiveHeight);
          const percent = parseFloat(match[1]) / 100;
          row = marginTop + Math.floor(maxRow * percent);
        } else {
          row = this.resolveAnchorRow("center", effectiveHeight, availHeight, marginTop);
        }
      } else {
        row = opt.row;
      }
    } else {
      const anchor = opt.anchor ?? "center";
      row = this.resolveAnchorRow(anchor, effectiveHeight, availHeight, marginTop);
    }
    if (opt.col !== void 0) {
      if (typeof opt.col === "string") {
        const match = opt.col.match(/^(\d+(?:\.\d+)?)%$/);
        if (match) {
          const maxCol = Math.max(0, availWidth - width);
          const percent = parseFloat(match[1]) / 100;
          col = marginLeft + Math.floor(maxCol * percent);
        } else {
          col = this.resolveAnchorCol("center", width, availWidth, marginLeft);
        }
      } else {
        col = opt.col;
      }
    } else {
      const anchor = opt.anchor ?? "center";
      col = this.resolveAnchorCol(anchor, width, availWidth, marginLeft);
    }
    if (opt.offsetY !== void 0)
      row += opt.offsetY;
    if (opt.offsetX !== void 0)
      col += opt.offsetX;
    row = Math.max(marginTop, Math.min(row, termHeight - marginBottom - effectiveHeight));
    col = Math.max(marginLeft, Math.min(col, termWidth - marginRight - width));
    return { width, row, col, maxHeight };
  }
  resolveAnchorRow(anchor, height, availHeight, marginTop) {
    switch (anchor) {
      case "top-left":
      case "top-center":
      case "top-right":
        return marginTop;
      case "bottom-left":
      case "bottom-center":
      case "bottom-right":
        return marginTop + availHeight - height;
      case "left-center":
      case "center":
      case "right-center":
        return marginTop + Math.floor((availHeight - height) / 2);
    }
  }
  resolveAnchorCol(anchor, width, availWidth, marginLeft) {
    switch (anchor) {
      case "top-left":
      case "left-center":
      case "bottom-left":
        return marginLeft;
      case "top-right":
      case "right-center":
      case "bottom-right":
        return marginLeft + availWidth - width;
      case "top-center":
      case "center":
      case "bottom-center":
        return marginLeft + Math.floor((availWidth - width) / 2);
    }
  }
  /** Composite all overlays into content lines (in stack order, later = on top). */
  compositeOverlays(lines, termWidth, termHeight) {
    if (this.overlayStack.length === 0)
      return lines;
    const result = [...lines];
    const rendered = [];
    let minLinesNeeded = result.length;
    for (const entry of this.overlayStack) {
      if (!this.isOverlayVisible(entry))
        continue;
      const { component, options: options3 } = entry;
      const { width, maxHeight } = this.resolveOverlayLayout(options3, 0, termWidth, termHeight);
      let overlayLines = component.render(width);
      if (maxHeight !== void 0 && overlayLines.length > maxHeight) {
        overlayLines = overlayLines.slice(0, maxHeight);
      }
      const { row, col } = this.resolveOverlayLayout(options3, overlayLines.length, termWidth, termHeight);
      rendered.push({ overlayLines, row, col, w: width });
      minLinesNeeded = Math.max(minLinesNeeded, row + overlayLines.length);
    }
    while (result.length < minLinesNeeded) {
      result.push("");
    }
    const viewportStart = Math.max(0, result.length - termHeight);
    const modifiedLines = /* @__PURE__ */ new Set();
    for (const { overlayLines, row, col, w } of rendered) {
      for (let i = 0; i < overlayLines.length; i++) {
        const idx = viewportStart + row + i;
        if (idx >= 0 && idx < result.length) {
          const truncatedOverlayLine = visibleWidth(overlayLines[i]) > w ? sliceByColumn(overlayLines[i], 0, w, true) : overlayLines[i];
          result[idx] = this.compositeLineAt(result[idx], truncatedOverlayLine, col, w, termWidth);
          modifiedLines.add(idx);
        }
      }
    }
    for (const idx of modifiedLines) {
      const lineWidth = visibleWidth(result[idx]);
      if (lineWidth > termWidth) {
        result[idx] = sliceByColumn(result[idx], 0, termWidth, true);
      }
    }
    return result;
  }
  static SEGMENT_RESET = "\x1B[0m\x1B]8;;\x07";
  applyLineResets(lines) {
    const reset = _TUI.SEGMENT_RESET;
    return lines.map((line) => this.containsImage(line) ? line : line + reset);
  }
  /** Splice overlay content into a base line at a specific column. Single-pass optimized. */
  compositeLineAt(baseLine, overlayLine, startCol, overlayWidth, totalWidth) {
    if (this.containsImage(baseLine))
      return baseLine;
    const afterStart = startCol + overlayWidth;
    const base = extractSegments(baseLine, startCol, afterStart, totalWidth - afterStart, true);
    const overlay = sliceWithWidth(overlayLine, 0, overlayWidth, true);
    const beforePad = Math.max(0, startCol - base.beforeWidth);
    const overlayPad = Math.max(0, overlayWidth - overlay.width);
    const actualBeforeWidth = Math.max(startCol, base.beforeWidth);
    const actualOverlayWidth = Math.max(overlayWidth, overlay.width);
    const afterTarget = Math.max(0, totalWidth - actualBeforeWidth - actualOverlayWidth);
    const afterPad = Math.max(0, afterTarget - base.afterWidth);
    const r = _TUI.SEGMENT_RESET;
    const result = base.before + " ".repeat(beforePad) + r + overlay.text + " ".repeat(overlayPad) + r + base.after + " ".repeat(afterPad);
    const resultWidth = visibleWidth(result);
    if (resultWidth <= totalWidth) {
      return result;
    }
    return sliceByColumn(result, 0, totalWidth, true);
  }
  /**
   * Find and extract cursor position from rendered lines.
   * Searches for CURSOR_MARKER, calculates its position, and strips it from the output.
   * @returns Cursor position { row, col } or null if no marker found
   */
  extractCursorPosition(lines) {
    for (let row = 0; row < lines.length; row++) {
      const line = lines[row];
      const markerIndex = line.indexOf(CURSOR_MARKER);
      if (markerIndex !== -1) {
        const beforeMarker = line.slice(0, markerIndex);
        const col = visibleWidth(beforeMarker);
        lines[row] = line.slice(0, markerIndex) + line.slice(markerIndex + CURSOR_MARKER.length);
        return { row, col };
      }
    }
    return null;
  }
  doRender() {
    const width = this.terminal.columns;
    const height = this.terminal.rows;
    let newLines = this.render(width);
    if (this.overlayStack.length > 0) {
      newLines = this.compositeOverlays(newLines, width, height);
    }
    const cursorPos = this.extractCursorPosition(newLines);
    newLines = this.applyLineResets(newLines);
    const widthChanged = this.previousWidth !== 0 && this.previousWidth !== width;
    const fullRender = (clear) => {
      let buffer2 = "\x1B[?2026h";
      if (clear)
        buffer2 += "\x1B[3J\x1B[2J\x1B[H";
      for (let i = 0; i < newLines.length; i++) {
        if (i > 0)
          buffer2 += "\r\n";
        buffer2 += newLines[i];
      }
      buffer2 += "\x1B[?2026l";
      this.terminal.write(buffer2);
      this.cursorRow = Math.max(0, newLines.length - 1);
      this.hardwareCursorRow = this.cursorRow;
      if (clear) {
        this.maxLinesRendered = newLines.length;
      } else {
        this.maxLinesRendered = Math.max(this.maxLinesRendered, newLines.length);
      }
      this.positionHardwareCursor(cursorPos, newLines.length);
      this.previousLines = newLines;
      this.previousWidth = width;
    };
    if (this.previousLines.length === 0 && !widthChanged) {
      fullRender(false);
      return;
    }
    if (widthChanged) {
      fullRender(true);
      return;
    }
    let firstChanged = -1;
    let lastChanged = -1;
    const maxLines = Math.max(newLines.length, this.previousLines.length);
    for (let i = 0; i < maxLines; i++) {
      const oldLine = i < this.previousLines.length ? this.previousLines[i] : "";
      const newLine = i < newLines.length ? newLines[i] : "";
      if (oldLine !== newLine) {
        if (firstChanged === -1) {
          firstChanged = i;
        }
        lastChanged = i;
      }
    }
    if (firstChanged === -1) {
      this.positionHardwareCursor(cursorPos, newLines.length);
      return;
    }
    if (firstChanged >= newLines.length) {
      if (this.previousLines.length > newLines.length) {
        let buffer2 = "\x1B[?2026h";
        const targetRow = Math.max(0, newLines.length - 1);
        const lineDiff2 = targetRow - this.hardwareCursorRow;
        if (lineDiff2 > 0)
          buffer2 += `\x1B[${lineDiff2}B`;
        else if (lineDiff2 < 0)
          buffer2 += `\x1B[${-lineDiff2}A`;
        buffer2 += "\r";
        const extraLines = this.previousLines.length - newLines.length;
        if (extraLines > height) {
          fullRender(true);
          return;
        }
        if (extraLines > 0) {
          buffer2 += "\x1B[1B";
        }
        for (let i = 0; i < extraLines; i++) {
          buffer2 += "\r\x1B[2K";
          if (i < extraLines - 1)
            buffer2 += "\x1B[1B";
        }
        if (extraLines > 0) {
          buffer2 += `\x1B[${extraLines}A`;
        }
        buffer2 += "\x1B[?2026l";
        this.terminal.write(buffer2);
        this.cursorRow = targetRow;
        this.hardwareCursorRow = targetRow;
      }
      this.positionHardwareCursor(cursorPos, newLines.length);
      this.previousLines = newLines;
      this.previousWidth = width;
      return;
    }
    const viewportTop = Math.max(0, this.maxLinesRendered - height);
    if (firstChanged < viewportTop) {
      fullRender(true);
      return;
    }
    let buffer = "\x1B[?2026h";
    const lineDiff = firstChanged - this.hardwareCursorRow;
    if (lineDiff > 0) {
      buffer += `\x1B[${lineDiff}B`;
    } else if (lineDiff < 0) {
      buffer += `\x1B[${-lineDiff}A`;
    }
    buffer += "\r";
    const renderEnd = Math.min(lastChanged, newLines.length - 1);
    for (let i = firstChanged; i <= renderEnd; i++) {
      if (i > firstChanged)
        buffer += "\r\n";
      buffer += "\x1B[2K";
      const line = newLines[i];
      const isImageLine = this.containsImage(line);
      if (!isImageLine && visibleWidth(line) > width) {
        const crashLogPath = path.join(os.homedir(), ".pi", "agent", "pi-crash.log");
        const crashData = [
          `Crash at ${(/* @__PURE__ */ new Date()).toISOString()}`,
          `Terminal width: ${width}`,
          `Line ${i} visible width: ${visibleWidth(line)}`,
          "",
          "=== All rendered lines ===",
          ...newLines.map((l, idx) => `[${idx}] (w=${visibleWidth(l)}) ${l}`),
          ""
        ].join("\n");
        fs.mkdirSync(path.dirname(crashLogPath), { recursive: true });
        fs.writeFileSync(crashLogPath, crashData);
        this.stop();
        const errorMsg = [
          `Rendered line ${i} exceeds terminal width (${visibleWidth(line)} > ${width}).`,
          "",
          "This is likely caused by a custom TUI component not truncating its output.",
          "Use visibleWidth() to measure and truncateToWidth() to truncate lines.",
          "",
          `Debug log written to: ${crashLogPath}`
        ].join("\n");
        throw new Error(errorMsg);
      }
      buffer += line;
    }
    let finalCursorRow = renderEnd;
    if (this.previousLines.length > newLines.length) {
      if (renderEnd < newLines.length - 1) {
        const moveDown = newLines.length - 1 - renderEnd;
        buffer += `\x1B[${moveDown}B`;
        finalCursorRow = newLines.length - 1;
      }
      const extraLines = this.previousLines.length - newLines.length;
      for (let i = newLines.length; i < this.previousLines.length; i++) {
        buffer += "\r\n\x1B[2K";
      }
      buffer += `\x1B[${extraLines}A`;
    }
    buffer += "\x1B[?2026l";
    if (process.env.PI_TUI_DEBUG === "1") {
      const debugDir = "/tmp/tui";
      fs.mkdirSync(debugDir, { recursive: true });
      const debugPath = path.join(debugDir, `render-${Date.now()}-${Math.random().toString(36).slice(2)}.log`);
      const debugData = [
        `firstChanged: ${firstChanged}`,
        `viewportTop: ${viewportTop}`,
        `cursorRow: ${this.cursorRow}`,
        `height: ${height}`,
        `lineDiff: ${lineDiff}`,
        `hardwareCursorRow: ${this.hardwareCursorRow}`,
        `renderEnd: ${renderEnd}`,
        `finalCursorRow: ${finalCursorRow}`,
        `cursorPos: ${JSON.stringify(cursorPos)}`,
        `newLines.length: ${newLines.length}`,
        `previousLines.length: ${this.previousLines.length}`,
        "",
        "=== newLines ===",
        JSON.stringify(newLines, null, 2),
        "",
        "=== previousLines ===",
        JSON.stringify(this.previousLines, null, 2),
        "",
        "=== buffer ===",
        JSON.stringify(buffer)
      ].join("\n");
      fs.writeFileSync(debugPath, debugData);
    }
    this.terminal.write(buffer);
    this.cursorRow = Math.max(0, newLines.length - 1);
    this.hardwareCursorRow = finalCursorRow;
    this.maxLinesRendered = Math.max(this.maxLinesRendered, newLines.length);
    this.positionHardwareCursor(cursorPos, newLines.length);
    this.previousLines = newLines;
    this.previousWidth = width;
  }
  /**
   * Position the hardware cursor for IME candidate window.
   * @param cursorPos The cursor position extracted from rendered output, or null
   * @param totalLines Total number of rendered lines
   */
  positionHardwareCursor(cursorPos, totalLines) {
    if (!cursorPos || totalLines <= 0) {
      this.terminal.hideCursor();
      return;
    }
    const targetRow = Math.max(0, Math.min(cursorPos.row, totalLines - 1));
    const targetCol = Math.max(0, cursorPos.col);
    const rowDelta = targetRow - this.hardwareCursorRow;
    let buffer = "";
    if (rowDelta > 0) {
      buffer += `\x1B[${rowDelta}B`;
    } else if (rowDelta < 0) {
      buffer += `\x1B[${-rowDelta}A`;
    }
    buffer += `\x1B[${targetCol + 1}G`;
    if (buffer) {
      this.terminal.write(buffer);
    }
    this.hardwareCursorRow = targetRow;
    if (this.showHardwareCursor) {
      this.terminal.showCursor();
    } else {
      this.terminal.hideCursor();
    }
  }
};

// node_modules/@mariozechner/pi-tui/dist/components/select-list.js
var normalizeToSingleLine = (text) => text.replace(/[\r\n]+/g, " ").trim();
var SelectList = class {
  items = [];
  filteredItems = [];
  selectedIndex = 0;
  maxVisible = 5;
  theme;
  onSelect;
  onCancel;
  onSelectionChange;
  constructor(items, maxVisible, theme) {
    this.items = items;
    this.filteredItems = items;
    this.maxVisible = maxVisible;
    this.theme = theme;
  }
  setFilter(filter) {
    this.filteredItems = this.items.filter((item) => item.value.toLowerCase().startsWith(filter.toLowerCase()));
    this.selectedIndex = 0;
  }
  setSelectedIndex(index) {
    this.selectedIndex = Math.max(0, Math.min(index, this.filteredItems.length - 1));
  }
  invalidate() {
  }
  render(width) {
    const lines = [];
    if (this.filteredItems.length === 0) {
      lines.push(this.theme.noMatch("  No matching commands"));
      return lines;
    }
    const startIndex = Math.max(0, Math.min(this.selectedIndex - Math.floor(this.maxVisible / 2), this.filteredItems.length - this.maxVisible));
    const endIndex = Math.min(startIndex + this.maxVisible, this.filteredItems.length);
    for (let i = startIndex; i < endIndex; i++) {
      const item = this.filteredItems[i];
      if (!item)
        continue;
      const isSelected = i === this.selectedIndex;
      const descriptionSingleLine = item.description ? normalizeToSingleLine(item.description) : void 0;
      let line = "";
      if (isSelected) {
        const prefixWidth = 2;
        const displayValue = item.label || item.value;
        if (descriptionSingleLine && width > 40) {
          const maxValueWidth = Math.min(30, width - prefixWidth - 4);
          const truncatedValue = truncateToWidth(displayValue, maxValueWidth, "");
          const spacing = " ".repeat(Math.max(1, 32 - truncatedValue.length));
          const descriptionStart = prefixWidth + truncatedValue.length + spacing.length;
          const remainingWidth = width - descriptionStart - 2;
          if (remainingWidth > 10) {
            const truncatedDesc = truncateToWidth(descriptionSingleLine, remainingWidth, "");
            line = this.theme.selectedText(`\u2192 ${truncatedValue}${spacing}${truncatedDesc}`);
          } else {
            const maxWidth = width - prefixWidth - 2;
            line = this.theme.selectedText(`\u2192 ${truncateToWidth(displayValue, maxWidth, "")}`);
          }
        } else {
          const maxWidth = width - prefixWidth - 2;
          line = this.theme.selectedText(`\u2192 ${truncateToWidth(displayValue, maxWidth, "")}`);
        }
      } else {
        const displayValue = item.label || item.value;
        const prefix = "  ";
        if (descriptionSingleLine && width > 40) {
          const maxValueWidth = Math.min(30, width - prefix.length - 4);
          const truncatedValue = truncateToWidth(displayValue, maxValueWidth, "");
          const spacing = " ".repeat(Math.max(1, 32 - truncatedValue.length));
          const descriptionStart = prefix.length + truncatedValue.length + spacing.length;
          const remainingWidth = width - descriptionStart - 2;
          if (remainingWidth > 10) {
            const truncatedDesc = truncateToWidth(descriptionSingleLine, remainingWidth, "");
            const descText = this.theme.description(spacing + truncatedDesc);
            line = prefix + truncatedValue + descText;
          } else {
            const maxWidth = width - prefix.length - 2;
            line = prefix + truncateToWidth(displayValue, maxWidth, "");
          }
        } else {
          const maxWidth = width - prefix.length - 2;
          line = prefix + truncateToWidth(displayValue, maxWidth, "");
        }
      }
      lines.push(line);
    }
    if (startIndex > 0 || endIndex < this.filteredItems.length) {
      const scrollText = `  (${this.selectedIndex + 1}/${this.filteredItems.length})`;
      lines.push(this.theme.scrollInfo(truncateToWidth(scrollText, width - 2, "")));
    }
    return lines;
  }
  handleInput(keyData) {
    const kb = getEditorKeybindings();
    if (kb.matches(keyData, "selectUp")) {
      this.selectedIndex = this.selectedIndex === 0 ? this.filteredItems.length - 1 : this.selectedIndex - 1;
      this.notifySelectionChange();
    } else if (kb.matches(keyData, "selectDown")) {
      this.selectedIndex = this.selectedIndex === this.filteredItems.length - 1 ? 0 : this.selectedIndex + 1;
      this.notifySelectionChange();
    } else if (kb.matches(keyData, "selectConfirm")) {
      const selectedItem = this.filteredItems[this.selectedIndex];
      if (selectedItem && this.onSelect) {
        this.onSelect(selectedItem);
      }
    } else if (kb.matches(keyData, "selectCancel")) {
      if (this.onCancel) {
        this.onCancel();
      }
    }
  }
  notifySelectionChange() {
    const selectedItem = this.filteredItems[this.selectedIndex];
    if (selectedItem && this.onSelectionChange) {
      this.onSelectionChange(selectedItem);
    }
  }
  getSelectedItem() {
    const item = this.filteredItems[this.selectedIndex];
    return item || null;
  }
};

// node_modules/@mariozechner/pi-tui/dist/components/editor.js
var segmenter2 = getSegmenter();
function wordWrapLine(line, maxWidth) {
  if (!line || maxWidth <= 0) {
    return [{ text: "", startIndex: 0, endIndex: 0 }];
  }
  const lineWidth = visibleWidth(line);
  if (lineWidth <= maxWidth) {
    return [{ text: line, startIndex: 0, endIndex: line.length }];
  }
  const chunks = [];
  const tokens = [];
  let currentToken = "";
  let tokenStart = 0;
  let inWhitespace = false;
  let charIndex = 0;
  for (const seg of segmenter2.segment(line)) {
    const grapheme = seg.segment;
    const graphemeIsWhitespace = isWhitespaceChar(grapheme);
    if (currentToken === "") {
      inWhitespace = graphemeIsWhitespace;
      tokenStart = charIndex;
    } else if (graphemeIsWhitespace !== inWhitespace) {
      tokens.push({
        text: currentToken,
        startIndex: tokenStart,
        endIndex: charIndex,
        isWhitespace: inWhitespace
      });
      currentToken = "";
      tokenStart = charIndex;
      inWhitespace = graphemeIsWhitespace;
    }
    currentToken += grapheme;
    charIndex += grapheme.length;
  }
  if (currentToken) {
    tokens.push({
      text: currentToken,
      startIndex: tokenStart,
      endIndex: charIndex,
      isWhitespace: inWhitespace
    });
  }
  let currentChunk = "";
  let currentWidth = 0;
  let chunkStartIndex = 0;
  let atLineStart = true;
  for (const token of tokens) {
    const tokenWidth = visibleWidth(token.text);
    if (atLineStart && token.isWhitespace) {
      chunkStartIndex = token.endIndex;
      continue;
    }
    atLineStart = false;
    if (tokenWidth > maxWidth) {
      if (currentChunk) {
        chunks.push({
          text: currentChunk,
          startIndex: chunkStartIndex,
          endIndex: token.startIndex
        });
        currentChunk = "";
        currentWidth = 0;
        chunkStartIndex = token.startIndex;
      }
      let tokenChunk = "";
      let tokenChunkWidth = 0;
      let tokenChunkStart = token.startIndex;
      let tokenCharIndex = token.startIndex;
      for (const seg of segmenter2.segment(token.text)) {
        const grapheme = seg.segment;
        const graphemeWidth2 = visibleWidth(grapheme);
        if (tokenChunkWidth + graphemeWidth2 > maxWidth && tokenChunk) {
          chunks.push({
            text: tokenChunk,
            startIndex: tokenChunkStart,
            endIndex: tokenCharIndex
          });
          tokenChunk = grapheme;
          tokenChunkWidth = graphemeWidth2;
          tokenChunkStart = tokenCharIndex;
        } else {
          tokenChunk += grapheme;
          tokenChunkWidth += graphemeWidth2;
        }
        tokenCharIndex += grapheme.length;
      }
      if (tokenChunk) {
        currentChunk = tokenChunk;
        currentWidth = tokenChunkWidth;
        chunkStartIndex = tokenChunkStart;
      }
      continue;
    }
    if (currentWidth + tokenWidth > maxWidth) {
      const trimmedChunk = currentChunk.trimEnd();
      if (trimmedChunk || chunks.length === 0) {
        chunks.push({
          text: trimmedChunk,
          startIndex: chunkStartIndex,
          endIndex: chunkStartIndex + currentChunk.length
        });
      }
      atLineStart = true;
      if (token.isWhitespace) {
        currentChunk = "";
        currentWidth = 0;
        chunkStartIndex = token.endIndex;
      } else {
        currentChunk = token.text;
        currentWidth = tokenWidth;
        chunkStartIndex = token.startIndex;
        atLineStart = false;
      }
    } else {
      currentChunk += token.text;
      currentWidth += tokenWidth;
    }
  }
  if (currentChunk) {
    chunks.push({
      text: currentChunk,
      startIndex: chunkStartIndex,
      endIndex: line.length
    });
  }
  return chunks.length > 0 ? chunks : [{ text: "", startIndex: 0, endIndex: 0 }];
}
var KITTY_CSI_U_REGEX = /^\x1b\[(\d+)(?::(\d*))?(?::(\d+))?(?:;(\d+))?(?::(\d+))?u$/;
var KITTY_MOD_SHIFT = 1;
var KITTY_MOD_ALT = 2;
var KITTY_MOD_CTRL = 4;
function decodeKittyPrintable(data) {
  const match = data.match(KITTY_CSI_U_REGEX);
  if (!match)
    return void 0;
  const codepoint = Number.parseInt(match[1] ?? "", 10);
  if (!Number.isFinite(codepoint))
    return void 0;
  const shiftedKey = match[2] && match[2].length > 0 ? Number.parseInt(match[2], 10) : void 0;
  const modValue = match[4] ? Number.parseInt(match[4], 10) : 1;
  const modifier = Number.isFinite(modValue) ? modValue - 1 : 0;
  if (modifier & (KITTY_MOD_ALT | KITTY_MOD_CTRL))
    return void 0;
  let effectiveCodepoint = codepoint;
  if (modifier & KITTY_MOD_SHIFT && typeof shiftedKey === "number") {
    effectiveCodepoint = shiftedKey;
  }
  if (!Number.isFinite(effectiveCodepoint) || effectiveCodepoint < 32)
    return void 0;
  try {
    return String.fromCodePoint(effectiveCodepoint);
  } catch {
    return void 0;
  }
}
var Editor = class {
  state = {
    lines: [""],
    cursorLine: 0,
    cursorCol: 0
  };
  /** Focusable interface - set by TUI when focus changes */
  focused = false;
  tui;
  theme;
  paddingX = 0;
  // Store last render width for cursor navigation
  lastWidth = 80;
  // Vertical scrolling support
  scrollOffset = 0;
  // Border color (can be changed dynamically)
  borderColor;
  // Autocomplete support
  autocompleteProvider;
  autocompleteList;
  isAutocompleting = false;
  autocompletePrefix = "";
  // Paste tracking for large pastes
  pastes = /* @__PURE__ */ new Map();
  pasteCounter = 0;
  // Bracketed paste mode buffering
  pasteBuffer = "";
  isInPaste = false;
  pendingShiftEnter = false;
  // Prompt history for up/down navigation
  history = [];
  historyIndex = -1;
  // -1 = not browsing, 0 = most recent, 1 = older, etc.
  // Kill ring for Emacs-style kill/yank operations
  // Also tracks undo coalescing: "type-word" means we're mid-word (coalescing)
  killRing = [];
  lastAction = null;
  // Undo support
  undoStack = [];
  onSubmit;
  onChange;
  disableSubmit = false;
  constructor(tui, theme, options3 = {}) {
    this.tui = tui;
    this.theme = theme;
    this.borderColor = theme.borderColor;
    const paddingX = options3.paddingX ?? 0;
    this.paddingX = Number.isFinite(paddingX) ? Math.max(0, Math.floor(paddingX)) : 0;
  }
  getPaddingX() {
    return this.paddingX;
  }
  setPaddingX(padding) {
    const newPadding = Number.isFinite(padding) ? Math.max(0, Math.floor(padding)) : 0;
    if (this.paddingX !== newPadding) {
      this.paddingX = newPadding;
      this.tui.requestRender();
    }
  }
  setAutocompleteProvider(provider) {
    this.autocompleteProvider = provider;
  }
  /**
   * Add a prompt to history for up/down arrow navigation.
   * Called after successful submission.
   */
  addToHistory(text) {
    const trimmed = text.trim();
    if (!trimmed)
      return;
    if (this.history.length > 0 && this.history[0] === trimmed)
      return;
    this.history.unshift(trimmed);
    if (this.history.length > 100) {
      this.history.pop();
    }
  }
  isEditorEmpty() {
    return this.state.lines.length === 1 && this.state.lines[0] === "";
  }
  isOnFirstVisualLine() {
    const visualLines = this.buildVisualLineMap(this.lastWidth);
    const currentVisualLine = this.findCurrentVisualLine(visualLines);
    return currentVisualLine === 0;
  }
  isOnLastVisualLine() {
    const visualLines = this.buildVisualLineMap(this.lastWidth);
    const currentVisualLine = this.findCurrentVisualLine(visualLines);
    return currentVisualLine === visualLines.length - 1;
  }
  navigateHistory(direction) {
    this.lastAction = null;
    if (this.history.length === 0)
      return;
    const newIndex = this.historyIndex - direction;
    if (newIndex < -1 || newIndex >= this.history.length)
      return;
    if (this.historyIndex === -1 && newIndex >= 0) {
      this.pushUndoSnapshot();
    }
    this.historyIndex = newIndex;
    if (this.historyIndex === -1) {
      this.setTextInternal("");
    } else {
      this.setTextInternal(this.history[this.historyIndex] || "");
    }
  }
  /** Internal setText that doesn't reset history state - used by navigateHistory */
  setTextInternal(text) {
    this.lastAction = null;
    const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    this.state.lines = lines.length === 0 ? [""] : lines;
    this.state.cursorLine = this.state.lines.length - 1;
    this.state.cursorCol = this.state.lines[this.state.cursorLine]?.length || 0;
    this.scrollOffset = 0;
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  invalidate() {
  }
  render(width) {
    const maxPadding = Math.max(0, Math.floor((width - 1) / 2));
    const paddingX = Math.min(this.paddingX, maxPadding);
    const contentWidth = Math.max(1, width - paddingX * 2);
    this.lastWidth = contentWidth;
    const horizontal = this.borderColor("\u2500");
    const layoutLines = this.layoutText(contentWidth);
    const terminalRows = this.tui.terminal.rows;
    const maxVisibleLines = Math.max(5, Math.floor(terminalRows * 0.3));
    let cursorLineIndex = layoutLines.findIndex((line) => line.hasCursor);
    if (cursorLineIndex === -1)
      cursorLineIndex = 0;
    if (cursorLineIndex < this.scrollOffset) {
      this.scrollOffset = cursorLineIndex;
    } else if (cursorLineIndex >= this.scrollOffset + maxVisibleLines) {
      this.scrollOffset = cursorLineIndex - maxVisibleLines + 1;
    }
    const maxScrollOffset = Math.max(0, layoutLines.length - maxVisibleLines);
    this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxScrollOffset));
    const visibleLines = layoutLines.slice(this.scrollOffset, this.scrollOffset + maxVisibleLines);
    const result = [];
    const leftPadding = " ".repeat(paddingX);
    const rightPadding = leftPadding;
    if (this.scrollOffset > 0) {
      const indicator = `\u2500\u2500\u2500 \u2191 ${this.scrollOffset} more `;
      const remaining = width - visibleWidth(indicator);
      result.push(this.borderColor(indicator + "\u2500".repeat(Math.max(0, remaining))));
    } else {
      result.push(horizontal.repeat(width));
    }
    const emitCursorMarker = this.focused && !this.isAutocompleting;
    for (const layoutLine of visibleLines) {
      let displayText = layoutLine.text;
      let lineVisibleWidth = visibleWidth(layoutLine.text);
      if (layoutLine.hasCursor && layoutLine.cursorPos !== void 0) {
        const before = displayText.slice(0, layoutLine.cursorPos);
        const after = displayText.slice(layoutLine.cursorPos);
        const marker = emitCursorMarker ? CURSOR_MARKER : "";
        if (after.length > 0) {
          const afterGraphemes = [...segmenter2.segment(after)];
          const firstGrapheme = afterGraphemes[0]?.segment || "";
          const restAfter = after.slice(firstGrapheme.length);
          const cursor = `\x1B[7m${firstGrapheme}\x1B[0m`;
          displayText = before + marker + cursor + restAfter;
        } else {
          if (lineVisibleWidth < contentWidth) {
            const cursor = "\x1B[7m \x1B[0m";
            displayText = before + marker + cursor;
            lineVisibleWidth = lineVisibleWidth + 1;
          } else {
            const beforeGraphemes = [...segmenter2.segment(before)];
            if (beforeGraphemes.length > 0) {
              const lastGrapheme = beforeGraphemes[beforeGraphemes.length - 1]?.segment || "";
              const cursor = `\x1B[7m${lastGrapheme}\x1B[0m`;
              const beforeWithoutLast = beforeGraphemes.slice(0, -1).map((g) => g.segment).join("");
              displayText = beforeWithoutLast + marker + cursor;
            }
          }
        }
      }
      const padding = " ".repeat(Math.max(0, contentWidth - lineVisibleWidth));
      result.push(`${leftPadding}${displayText}${padding}${rightPadding}`);
    }
    const linesBelow = layoutLines.length - (this.scrollOffset + visibleLines.length);
    if (linesBelow > 0) {
      const indicator = `\u2500\u2500\u2500 \u2193 ${linesBelow} more `;
      const remaining = width - visibleWidth(indicator);
      result.push(this.borderColor(indicator + "\u2500".repeat(Math.max(0, remaining))));
    } else {
      result.push(horizontal.repeat(width));
    }
    if (this.isAutocompleting && this.autocompleteList) {
      const autocompleteResult = this.autocompleteList.render(contentWidth);
      for (const line of autocompleteResult) {
        const lineWidth = visibleWidth(line);
        const linePadding = " ".repeat(Math.max(0, contentWidth - lineWidth));
        result.push(`${leftPadding}${line}${linePadding}${rightPadding}`);
      }
    }
    return result;
  }
  handleInput(data) {
    const kb = getEditorKeybindings();
    if (data.includes("\x1B[200~")) {
      this.isInPaste = true;
      this.pasteBuffer = "";
      data = data.replace("\x1B[200~", "");
    }
    if (this.isInPaste) {
      this.pasteBuffer += data;
      const endIndex = this.pasteBuffer.indexOf("\x1B[201~");
      if (endIndex !== -1) {
        const pasteContent = this.pasteBuffer.substring(0, endIndex);
        if (pasteContent.length > 0) {
          this.handlePaste(pasteContent);
        }
        this.isInPaste = false;
        const remaining = this.pasteBuffer.substring(endIndex + 6);
        this.pasteBuffer = "";
        if (remaining.length > 0) {
          this.handleInput(remaining);
        }
        return;
      }
      return;
    }
    if (this.pendingShiftEnter) {
      if (data === "\r") {
        this.pendingShiftEnter = false;
        this.addNewLine();
        return;
      }
      this.pendingShiftEnter = false;
      this.insertCharacter("\\");
    }
    if (data === "\\") {
      this.pendingShiftEnter = true;
      return;
    }
    if (kb.matches(data, "copy")) {
      return;
    }
    if (kb.matches(data, "undo")) {
      this.undo();
      return;
    }
    if (this.isAutocompleting && this.autocompleteList) {
      if (kb.matches(data, "selectCancel")) {
        this.cancelAutocomplete();
        return;
      }
      if (kb.matches(data, "selectUp") || kb.matches(data, "selectDown")) {
        this.autocompleteList.handleInput(data);
        return;
      }
      if (kb.matches(data, "tab")) {
        const selected = this.autocompleteList.getSelectedItem();
        if (selected && this.autocompleteProvider) {
          this.pushUndoSnapshot();
          this.lastAction = null;
          const result = this.autocompleteProvider.applyCompletion(this.state.lines, this.state.cursorLine, this.state.cursorCol, selected, this.autocompletePrefix);
          this.state.lines = result.lines;
          this.state.cursorLine = result.cursorLine;
          this.state.cursorCol = result.cursorCol;
          this.cancelAutocomplete();
          if (this.onChange)
            this.onChange(this.getText());
        }
        return;
      }
      if (kb.matches(data, "selectConfirm")) {
        const selected = this.autocompleteList.getSelectedItem();
        if (selected && this.autocompleteProvider) {
          this.pushUndoSnapshot();
          this.lastAction = null;
          const result = this.autocompleteProvider.applyCompletion(this.state.lines, this.state.cursorLine, this.state.cursorCol, selected, this.autocompletePrefix);
          this.state.lines = result.lines;
          this.state.cursorLine = result.cursorLine;
          this.state.cursorCol = result.cursorCol;
          if (this.autocompletePrefix.startsWith("/")) {
            this.cancelAutocomplete();
          } else {
            this.cancelAutocomplete();
            if (this.onChange)
              this.onChange(this.getText());
            return;
          }
        }
      }
    }
    if (kb.matches(data, "tab") && !this.isAutocompleting) {
      this.handleTabCompletion();
      return;
    }
    if (kb.matches(data, "deleteToLineEnd")) {
      this.deleteToEndOfLine();
      return;
    }
    if (kb.matches(data, "deleteToLineStart")) {
      this.deleteToStartOfLine();
      return;
    }
    if (kb.matches(data, "deleteWordBackward")) {
      this.deleteWordBackwards();
      return;
    }
    if (kb.matches(data, "deleteWordForward")) {
      this.deleteWordForward();
      return;
    }
    if (kb.matches(data, "deleteCharBackward") || matchesKey(data, "shift+backspace")) {
      this.handleBackspace();
      return;
    }
    if (kb.matches(data, "deleteCharForward") || matchesKey(data, "shift+delete")) {
      this.handleForwardDelete();
      return;
    }
    if (kb.matches(data, "yank")) {
      this.yank();
      return;
    }
    if (kb.matches(data, "yankPop")) {
      this.yankPop();
      return;
    }
    if (kb.matches(data, "cursorLineStart")) {
      this.moveToLineStart();
      return;
    }
    if (kb.matches(data, "cursorLineEnd")) {
      this.moveToLineEnd();
      return;
    }
    if (kb.matches(data, "cursorWordLeft")) {
      this.moveWordBackwards();
      return;
    }
    if (kb.matches(data, "cursorWordRight")) {
      this.moveWordForwards();
      return;
    }
    if (kb.matches(data, "newLine") || data.charCodeAt(0) === 10 && data.length > 1 || data === "\x1B\r" || data === "\x1B[13;2~" || data.length > 1 && data.includes("\x1B") && data.includes("\r") || data === "\n" && data.length === 1 || data === "\\\r") {
      this.addNewLine();
      return;
    }
    if (kb.matches(data, "submit")) {
      if (this.disableSubmit)
        return;
      let result = this.state.lines.join("\n").trim();
      for (const [pasteId, pasteContent] of this.pastes) {
        const markerRegex = new RegExp(`\\[paste #${pasteId}( (\\+\\d+ lines|\\d+ chars))?\\]`, "g");
        result = result.replace(markerRegex, pasteContent);
      }
      this.state = { lines: [""], cursorLine: 0, cursorCol: 0 };
      this.pastes.clear();
      this.pasteCounter = 0;
      this.historyIndex = -1;
      this.scrollOffset = 0;
      this.undoStack.length = 0;
      this.lastAction = null;
      if (this.onChange)
        this.onChange("");
      if (this.onSubmit)
        this.onSubmit(result);
      return;
    }
    if (kb.matches(data, "cursorUp")) {
      if (this.isEditorEmpty()) {
        this.navigateHistory(-1);
      } else if (this.historyIndex > -1 && this.isOnFirstVisualLine()) {
        this.navigateHistory(-1);
      } else {
        this.moveCursor(-1, 0);
      }
      return;
    }
    if (kb.matches(data, "cursorDown")) {
      if (this.historyIndex > -1 && this.isOnLastVisualLine()) {
        this.navigateHistory(1);
      } else {
        this.moveCursor(1, 0);
      }
      return;
    }
    if (kb.matches(data, "cursorRight")) {
      this.moveCursor(0, 1);
      return;
    }
    if (kb.matches(data, "cursorLeft")) {
      this.moveCursor(0, -1);
      return;
    }
    if (kb.matches(data, "pageUp")) {
      this.pageScroll(-1);
      return;
    }
    if (kb.matches(data, "pageDown")) {
      this.pageScroll(1);
      return;
    }
    if (matchesKey(data, "shift+space")) {
      this.insertCharacter(" ");
      return;
    }
    const kittyPrintable = decodeKittyPrintable(data);
    if (kittyPrintable !== void 0) {
      this.insertCharacter(kittyPrintable);
      return;
    }
    if (data.charCodeAt(0) >= 32) {
      this.insertCharacter(data);
    }
  }
  layoutText(contentWidth) {
    const layoutLines = [];
    if (this.state.lines.length === 0 || this.state.lines.length === 1 && this.state.lines[0] === "") {
      layoutLines.push({
        text: "",
        hasCursor: true,
        cursorPos: 0
      });
      return layoutLines;
    }
    for (let i = 0; i < this.state.lines.length; i++) {
      const line = this.state.lines[i] || "";
      const isCurrentLine = i === this.state.cursorLine;
      const lineVisibleWidth = visibleWidth(line);
      if (lineVisibleWidth <= contentWidth) {
        if (isCurrentLine) {
          layoutLines.push({
            text: line,
            hasCursor: true,
            cursorPos: this.state.cursorCol
          });
        } else {
          layoutLines.push({
            text: line,
            hasCursor: false
          });
        }
      } else {
        const chunks = wordWrapLine(line, contentWidth);
        for (let chunkIndex = 0; chunkIndex < chunks.length; chunkIndex++) {
          const chunk = chunks[chunkIndex];
          if (!chunk)
            continue;
          const cursorPos = this.state.cursorCol;
          const isLastChunk = chunkIndex === chunks.length - 1;
          let hasCursorInChunk = false;
          let adjustedCursorPos = 0;
          if (isCurrentLine) {
            if (isLastChunk) {
              hasCursorInChunk = cursorPos >= chunk.startIndex;
              adjustedCursorPos = cursorPos - chunk.startIndex;
            } else {
              hasCursorInChunk = cursorPos >= chunk.startIndex && cursorPos < chunk.endIndex;
              if (hasCursorInChunk) {
                adjustedCursorPos = cursorPos - chunk.startIndex;
                if (adjustedCursorPos > chunk.text.length) {
                  adjustedCursorPos = chunk.text.length;
                }
              }
            }
          }
          if (hasCursorInChunk) {
            layoutLines.push({
              text: chunk.text,
              hasCursor: true,
              cursorPos: adjustedCursorPos
            });
          } else {
            layoutLines.push({
              text: chunk.text,
              hasCursor: false
            });
          }
        }
      }
    }
    return layoutLines;
  }
  getText() {
    return this.state.lines.join("\n");
  }
  /**
   * Get text with paste markers expanded to their actual content.
   * Use this when you need the full content (e.g., for external editor).
   */
  getExpandedText() {
    let result = this.state.lines.join("\n");
    for (const [pasteId, pasteContent] of this.pastes) {
      const markerRegex = new RegExp(`\\[paste #${pasteId}( (\\+\\d+ lines|\\d+ chars))?\\]`, "g");
      result = result.replace(markerRegex, pasteContent);
    }
    return result;
  }
  getLines() {
    return [...this.state.lines];
  }
  getCursor() {
    return { line: this.state.cursorLine, col: this.state.cursorCol };
  }
  setText(text) {
    this.historyIndex = -1;
    if (this.getText() !== text) {
      this.pushUndoSnapshot();
    }
    this.setTextInternal(text);
    this.lastAction = null;
  }
  /**
   * Insert text at the current cursor position.
   * Used for programmatic insertion (e.g., clipboard image markers).
   * This is atomic for undo - single undo restores entire pre-insert state.
   */
  insertTextAtCursor(text) {
    if (!text)
      return;
    this.pushUndoSnapshot();
    this.lastAction = null;
    for (const char of text) {
      this.insertCharacter(char, true);
    }
  }
  // All the editor methods from before...
  insertCharacter(char, skipUndoCoalescing) {
    this.historyIndex = -1;
    if (!skipUndoCoalescing) {
      if (isWhitespaceChar(char) || this.lastAction !== "type-word") {
        this.pushUndoSnapshot();
      }
      this.lastAction = "type-word";
    }
    const line = this.state.lines[this.state.cursorLine] || "";
    const before = line.slice(0, this.state.cursorCol);
    const after = line.slice(this.state.cursorCol);
    this.state.lines[this.state.cursorLine] = before + char + after;
    this.state.cursorCol += char.length;
    if (this.onChange) {
      this.onChange(this.getText());
    }
    if (!this.isAutocompleting) {
      if (char === "/" && this.isAtStartOfMessage()) {
        this.tryTriggerAutocomplete();
      } else if (char === "@") {
        const currentLine = this.state.lines[this.state.cursorLine] || "";
        const textBeforeCursor = currentLine.slice(0, this.state.cursorCol);
        const charBeforeAt = textBeforeCursor[textBeforeCursor.length - 2];
        if (textBeforeCursor.length === 1 || charBeforeAt === " " || charBeforeAt === "	") {
          this.tryTriggerAutocomplete();
        }
      } else if (/[a-zA-Z0-9.\-_]/.test(char)) {
        const currentLine = this.state.lines[this.state.cursorLine] || "";
        const textBeforeCursor = currentLine.slice(0, this.state.cursorCol);
        if (textBeforeCursor.trimStart().startsWith("/")) {
          this.tryTriggerAutocomplete();
        } else if (textBeforeCursor.match(/(?:^|[\s])@[^\s]*$/)) {
          this.tryTriggerAutocomplete();
        }
      }
    } else {
      this.updateAutocomplete();
    }
  }
  handlePaste(pastedText) {
    this.historyIndex = -1;
    this.lastAction = null;
    this.pushUndoSnapshot();
    const cleanText = pastedText.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const tabExpandedText = cleanText.replace(/\t/g, "    ");
    let filteredText = tabExpandedText.split("").filter((char) => char === "\n" || char.charCodeAt(0) >= 32).join("");
    if (/^[/~.]/.test(filteredText)) {
      const currentLine2 = this.state.lines[this.state.cursorLine] || "";
      const charBeforeCursor = this.state.cursorCol > 0 ? currentLine2[this.state.cursorCol - 1] : "";
      if (charBeforeCursor && /\w/.test(charBeforeCursor)) {
        filteredText = ` ${filteredText}`;
      }
    }
    const pastedLines = filteredText.split("\n");
    const totalChars = filteredText.length;
    if (pastedLines.length > 10 || totalChars > 1e3) {
      this.pasteCounter++;
      const pasteId = this.pasteCounter;
      this.pastes.set(pasteId, filteredText);
      const marker = pastedLines.length > 10 ? `[paste #${pasteId} +${pastedLines.length} lines]` : `[paste #${pasteId} ${totalChars} chars]`;
      for (const char of marker) {
        this.insertCharacter(char, true);
      }
      return;
    }
    if (pastedLines.length === 1) {
      const text = pastedLines[0] || "";
      for (const char of text) {
        this.insertCharacter(char, true);
      }
      return;
    }
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    const beforeCursor = currentLine.slice(0, this.state.cursorCol);
    const afterCursor = currentLine.slice(this.state.cursorCol);
    const newLines = [];
    for (let i = 0; i < this.state.cursorLine; i++) {
      newLines.push(this.state.lines[i] || "");
    }
    newLines.push(beforeCursor + (pastedLines[0] || ""));
    for (let i = 1; i < pastedLines.length - 1; i++) {
      newLines.push(pastedLines[i] || "");
    }
    newLines.push((pastedLines[pastedLines.length - 1] || "") + afterCursor);
    for (let i = this.state.cursorLine + 1; i < this.state.lines.length; i++) {
      newLines.push(this.state.lines[i] || "");
    }
    this.state.lines = newLines;
    this.state.cursorLine += pastedLines.length - 1;
    this.state.cursorCol = (pastedLines[pastedLines.length - 1] || "").length;
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  addNewLine() {
    this.historyIndex = -1;
    this.lastAction = null;
    this.pushUndoSnapshot();
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    const before = currentLine.slice(0, this.state.cursorCol);
    const after = currentLine.slice(this.state.cursorCol);
    this.state.lines[this.state.cursorLine] = before;
    this.state.lines.splice(this.state.cursorLine + 1, 0, after);
    this.state.cursorLine++;
    this.state.cursorCol = 0;
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  handleBackspace() {
    this.historyIndex = -1;
    this.lastAction = null;
    if (this.state.cursorCol > 0) {
      this.pushUndoSnapshot();
      const line = this.state.lines[this.state.cursorLine] || "";
      const beforeCursor = line.slice(0, this.state.cursorCol);
      const graphemes = [...segmenter2.segment(beforeCursor)];
      const lastGrapheme = graphemes[graphemes.length - 1];
      const graphemeLength = lastGrapheme ? lastGrapheme.segment.length : 1;
      const before = line.slice(0, this.state.cursorCol - graphemeLength);
      const after = line.slice(this.state.cursorCol);
      this.state.lines[this.state.cursorLine] = before + after;
      this.state.cursorCol -= graphemeLength;
    } else if (this.state.cursorLine > 0) {
      this.pushUndoSnapshot();
      const currentLine = this.state.lines[this.state.cursorLine] || "";
      const previousLine = this.state.lines[this.state.cursorLine - 1] || "";
      this.state.lines[this.state.cursorLine - 1] = previousLine + currentLine;
      this.state.lines.splice(this.state.cursorLine, 1);
      this.state.cursorLine--;
      this.state.cursorCol = previousLine.length;
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
    if (this.isAutocompleting) {
      this.updateAutocomplete();
    } else {
      const currentLine = this.state.lines[this.state.cursorLine] || "";
      const textBeforeCursor = currentLine.slice(0, this.state.cursorCol);
      if (textBeforeCursor.trimStart().startsWith("/")) {
        this.tryTriggerAutocomplete();
      } else if (textBeforeCursor.match(/(?:^|[\s])@[^\s]*$/)) {
        this.tryTriggerAutocomplete();
      }
    }
  }
  moveToLineStart() {
    this.lastAction = null;
    this.state.cursorCol = 0;
  }
  moveToLineEnd() {
    this.lastAction = null;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    this.state.cursorCol = currentLine.length;
  }
  deleteToStartOfLine() {
    this.historyIndex = -1;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol > 0) {
      this.pushUndoSnapshot();
      const deletedText = currentLine.slice(0, this.state.cursorCol);
      this.addToKillRing(deletedText, true);
      this.lastAction = "kill";
      this.state.lines[this.state.cursorLine] = currentLine.slice(this.state.cursorCol);
      this.state.cursorCol = 0;
    } else if (this.state.cursorLine > 0) {
      this.pushUndoSnapshot();
      this.addToKillRing("\n", true);
      this.lastAction = "kill";
      const previousLine = this.state.lines[this.state.cursorLine - 1] || "";
      this.state.lines[this.state.cursorLine - 1] = previousLine + currentLine;
      this.state.lines.splice(this.state.cursorLine, 1);
      this.state.cursorLine--;
      this.state.cursorCol = previousLine.length;
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  deleteToEndOfLine() {
    this.historyIndex = -1;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol < currentLine.length) {
      this.pushUndoSnapshot();
      const deletedText = currentLine.slice(this.state.cursorCol);
      this.addToKillRing(deletedText, false);
      this.lastAction = "kill";
      this.state.lines[this.state.cursorLine] = currentLine.slice(0, this.state.cursorCol);
    } else if (this.state.cursorLine < this.state.lines.length - 1) {
      this.pushUndoSnapshot();
      this.addToKillRing("\n", false);
      this.lastAction = "kill";
      const nextLine = this.state.lines[this.state.cursorLine + 1] || "";
      this.state.lines[this.state.cursorLine] = currentLine + nextLine;
      this.state.lines.splice(this.state.cursorLine + 1, 1);
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  deleteWordBackwards() {
    this.historyIndex = -1;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol === 0) {
      if (this.state.cursorLine > 0) {
        this.pushUndoSnapshot();
        this.addToKillRing("\n", true);
        this.lastAction = "kill";
        const previousLine = this.state.lines[this.state.cursorLine - 1] || "";
        this.state.lines[this.state.cursorLine - 1] = previousLine + currentLine;
        this.state.lines.splice(this.state.cursorLine, 1);
        this.state.cursorLine--;
        this.state.cursorCol = previousLine.length;
      }
    } else {
      this.pushUndoSnapshot();
      const wasKill = this.lastAction === "kill";
      const oldCursorCol = this.state.cursorCol;
      this.moveWordBackwards();
      const deleteFrom = this.state.cursorCol;
      this.state.cursorCol = oldCursorCol;
      this.lastAction = wasKill ? "kill" : null;
      const deletedText = currentLine.slice(deleteFrom, this.state.cursorCol);
      this.addToKillRing(deletedText, true);
      this.lastAction = "kill";
      this.state.lines[this.state.cursorLine] = currentLine.slice(0, deleteFrom) + currentLine.slice(this.state.cursorCol);
      this.state.cursorCol = deleteFrom;
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  deleteWordForward() {
    this.historyIndex = -1;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol >= currentLine.length) {
      if (this.state.cursorLine < this.state.lines.length - 1) {
        this.pushUndoSnapshot();
        this.addToKillRing("\n", false);
        this.lastAction = "kill";
        const nextLine = this.state.lines[this.state.cursorLine + 1] || "";
        this.state.lines[this.state.cursorLine] = currentLine + nextLine;
        this.state.lines.splice(this.state.cursorLine + 1, 1);
      }
    } else {
      this.pushUndoSnapshot();
      const wasKill = this.lastAction === "kill";
      const oldCursorCol = this.state.cursorCol;
      this.moveWordForwards();
      const deleteTo = this.state.cursorCol;
      this.state.cursorCol = oldCursorCol;
      this.lastAction = wasKill ? "kill" : null;
      const deletedText = currentLine.slice(this.state.cursorCol, deleteTo);
      this.addToKillRing(deletedText, false);
      this.lastAction = "kill";
      this.state.lines[this.state.cursorLine] = currentLine.slice(0, this.state.cursorCol) + currentLine.slice(deleteTo);
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  handleForwardDelete() {
    this.historyIndex = -1;
    this.lastAction = null;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol < currentLine.length) {
      this.pushUndoSnapshot();
      const afterCursor = currentLine.slice(this.state.cursorCol);
      const graphemes = [...segmenter2.segment(afterCursor)];
      const firstGrapheme = graphemes[0];
      const graphemeLength = firstGrapheme ? firstGrapheme.segment.length : 1;
      const before = currentLine.slice(0, this.state.cursorCol);
      const after = currentLine.slice(this.state.cursorCol + graphemeLength);
      this.state.lines[this.state.cursorLine] = before + after;
    } else if (this.state.cursorLine < this.state.lines.length - 1) {
      this.pushUndoSnapshot();
      const nextLine = this.state.lines[this.state.cursorLine + 1] || "";
      this.state.lines[this.state.cursorLine] = currentLine + nextLine;
      this.state.lines.splice(this.state.cursorLine + 1, 1);
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
    if (this.isAutocompleting) {
      this.updateAutocomplete();
    } else {
      const currentLine2 = this.state.lines[this.state.cursorLine] || "";
      const textBeforeCursor = currentLine2.slice(0, this.state.cursorCol);
      if (textBeforeCursor.trimStart().startsWith("/")) {
        this.tryTriggerAutocomplete();
      } else if (textBeforeCursor.match(/(?:^|[\s])@[^\s]*$/)) {
        this.tryTriggerAutocomplete();
      }
    }
  }
  /**
   * Build a mapping from visual lines to logical positions.
   * Returns an array where each element represents a visual line with:
   * - logicalLine: index into this.state.lines
   * - startCol: starting column in the logical line
   * - length: length of this visual line segment
   */
  buildVisualLineMap(width) {
    const visualLines = [];
    for (let i = 0; i < this.state.lines.length; i++) {
      const line = this.state.lines[i] || "";
      const lineVisWidth = visibleWidth(line);
      if (line.length === 0) {
        visualLines.push({ logicalLine: i, startCol: 0, length: 0 });
      } else if (lineVisWidth <= width) {
        visualLines.push({ logicalLine: i, startCol: 0, length: line.length });
      } else {
        const chunks = wordWrapLine(line, width);
        for (const chunk of chunks) {
          visualLines.push({
            logicalLine: i,
            startCol: chunk.startIndex,
            length: chunk.endIndex - chunk.startIndex
          });
        }
      }
    }
    return visualLines;
  }
  /**
   * Find the visual line index for the current cursor position.
   */
  findCurrentVisualLine(visualLines) {
    for (let i = 0; i < visualLines.length; i++) {
      const vl = visualLines[i];
      if (!vl)
        continue;
      if (vl.logicalLine === this.state.cursorLine) {
        const colInSegment = this.state.cursorCol - vl.startCol;
        const isLastSegmentOfLine = i === visualLines.length - 1 || visualLines[i + 1]?.logicalLine !== vl.logicalLine;
        if (colInSegment >= 0 && (colInSegment < vl.length || isLastSegmentOfLine && colInSegment <= vl.length)) {
          return i;
        }
      }
    }
    return visualLines.length - 1;
  }
  moveCursor(deltaLine, deltaCol) {
    this.lastAction = null;
    const width = this.lastWidth;
    if (deltaLine !== 0) {
      const visualLines = this.buildVisualLineMap(width);
      const currentVisualLine = this.findCurrentVisualLine(visualLines);
      const currentVL = visualLines[currentVisualLine];
      const visualCol = currentVL ? this.state.cursorCol - currentVL.startCol : 0;
      const targetVisualLine = currentVisualLine + deltaLine;
      if (targetVisualLine >= 0 && targetVisualLine < visualLines.length) {
        const targetVL = visualLines[targetVisualLine];
        if (targetVL) {
          this.state.cursorLine = targetVL.logicalLine;
          const targetCol = targetVL.startCol + Math.min(visualCol, targetVL.length);
          const logicalLine = this.state.lines[targetVL.logicalLine] || "";
          this.state.cursorCol = Math.min(targetCol, logicalLine.length);
        }
      }
    }
    if (deltaCol !== 0) {
      const currentLine = this.state.lines[this.state.cursorLine] || "";
      if (deltaCol > 0) {
        if (this.state.cursorCol < currentLine.length) {
          const afterCursor = currentLine.slice(this.state.cursorCol);
          const graphemes = [...segmenter2.segment(afterCursor)];
          const firstGrapheme = graphemes[0];
          this.state.cursorCol += firstGrapheme ? firstGrapheme.segment.length : 1;
        } else if (this.state.cursorLine < this.state.lines.length - 1) {
          this.state.cursorLine++;
          this.state.cursorCol = 0;
        }
      } else {
        if (this.state.cursorCol > 0) {
          const beforeCursor = currentLine.slice(0, this.state.cursorCol);
          const graphemes = [...segmenter2.segment(beforeCursor)];
          const lastGrapheme = graphemes[graphemes.length - 1];
          this.state.cursorCol -= lastGrapheme ? lastGrapheme.segment.length : 1;
        } else if (this.state.cursorLine > 0) {
          this.state.cursorLine--;
          const prevLine = this.state.lines[this.state.cursorLine] || "";
          this.state.cursorCol = prevLine.length;
        }
      }
    }
  }
  /**
   * Scroll by a page (direction: -1 for up, 1 for down).
   * Moves cursor by the page size while keeping it in bounds.
   */
  pageScroll(direction) {
    this.lastAction = null;
    const width = this.lastWidth;
    const terminalRows = this.tui.terminal.rows;
    const pageSize = Math.max(5, Math.floor(terminalRows * 0.3));
    const visualLines = this.buildVisualLineMap(width);
    const currentVisualLine = this.findCurrentVisualLine(visualLines);
    const targetVisualLine = Math.max(0, Math.min(visualLines.length - 1, currentVisualLine + direction * pageSize));
    const targetVL = visualLines[targetVisualLine];
    if (targetVL) {
      const currentVL = visualLines[currentVisualLine];
      const visualCol = currentVL ? this.state.cursorCol - currentVL.startCol : 0;
      this.state.cursorLine = targetVL.logicalLine;
      const targetCol = targetVL.startCol + Math.min(visualCol, targetVL.length);
      const logicalLine = this.state.lines[targetVL.logicalLine] || "";
      this.state.cursorCol = Math.min(targetCol, logicalLine.length);
    }
  }
  moveWordBackwards() {
    this.lastAction = null;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol === 0) {
      if (this.state.cursorLine > 0) {
        this.state.cursorLine--;
        const prevLine = this.state.lines[this.state.cursorLine] || "";
        this.state.cursorCol = prevLine.length;
      }
      return;
    }
    const textBeforeCursor = currentLine.slice(0, this.state.cursorCol);
    const graphemes = [...segmenter2.segment(textBeforeCursor)];
    let newCol = this.state.cursorCol;
    while (graphemes.length > 0 && isWhitespaceChar(graphemes[graphemes.length - 1]?.segment || "")) {
      newCol -= graphemes.pop()?.segment.length || 0;
    }
    if (graphemes.length > 0) {
      const lastGrapheme = graphemes[graphemes.length - 1]?.segment || "";
      if (isPunctuationChar(lastGrapheme)) {
        while (graphemes.length > 0 && isPunctuationChar(graphemes[graphemes.length - 1]?.segment || "")) {
          newCol -= graphemes.pop()?.segment.length || 0;
        }
      } else {
        while (graphemes.length > 0 && !isWhitespaceChar(graphemes[graphemes.length - 1]?.segment || "") && !isPunctuationChar(graphemes[graphemes.length - 1]?.segment || "")) {
          newCol -= graphemes.pop()?.segment.length || 0;
        }
      }
    }
    this.state.cursorCol = newCol;
  }
  /**
   * Yank (paste) the most recent kill ring entry at cursor position.
   */
  yank() {
    if (this.killRing.length === 0)
      return;
    this.pushUndoSnapshot();
    const text = this.killRing[this.killRing.length - 1] || "";
    this.insertYankedText(text);
    this.lastAction = "yank";
  }
  /**
   * Cycle through kill ring (only works immediately after yank or yank-pop).
   * Replaces the last yanked text with the previous entry in the ring.
   */
  yankPop() {
    if (this.lastAction !== "yank" || this.killRing.length <= 1)
      return;
    this.pushUndoSnapshot();
    this.deleteYankedText();
    const lastEntry = this.killRing.pop();
    this.killRing.unshift(lastEntry);
    const text = this.killRing[this.killRing.length - 1];
    this.insertYankedText(text);
    this.lastAction = "yank";
  }
  /**
   * Insert text at cursor position (used by yank operations).
   */
  insertYankedText(text) {
    this.historyIndex = -1;
    const lines = text.split("\n");
    if (lines.length === 1) {
      const currentLine = this.state.lines[this.state.cursorLine] || "";
      const before = currentLine.slice(0, this.state.cursorCol);
      const after = currentLine.slice(this.state.cursorCol);
      this.state.lines[this.state.cursorLine] = before + text + after;
      this.state.cursorCol += text.length;
    } else {
      const currentLine = this.state.lines[this.state.cursorLine] || "";
      const before = currentLine.slice(0, this.state.cursorCol);
      const after = currentLine.slice(this.state.cursorCol);
      this.state.lines[this.state.cursorLine] = before + (lines[0] || "");
      for (let i = 1; i < lines.length - 1; i++) {
        this.state.lines.splice(this.state.cursorLine + i, 0, lines[i] || "");
      }
      const lastLineIndex = this.state.cursorLine + lines.length - 1;
      this.state.lines.splice(lastLineIndex, 0, (lines[lines.length - 1] || "") + after);
      this.state.cursorLine = lastLineIndex;
      this.state.cursorCol = (lines[lines.length - 1] || "").length;
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  /**
   * Delete the previously yanked text (used by yank-pop).
   * The yanked text is derived from killRing[end] since it hasn't been rotated yet.
   */
  deleteYankedText() {
    const yankedText = this.killRing[this.killRing.length - 1] || "";
    if (!yankedText)
      return;
    const yankLines = yankedText.split("\n");
    if (yankLines.length === 1) {
      const currentLine = this.state.lines[this.state.cursorLine] || "";
      const deleteLen = yankedText.length;
      const before = currentLine.slice(0, this.state.cursorCol - deleteLen);
      const after = currentLine.slice(this.state.cursorCol);
      this.state.lines[this.state.cursorLine] = before + after;
      this.state.cursorCol -= deleteLen;
    } else {
      const startLine = this.state.cursorLine - (yankLines.length - 1);
      const startCol = (this.state.lines[startLine] || "").length - (yankLines[0] || "").length;
      const afterCursor = (this.state.lines[this.state.cursorLine] || "").slice(this.state.cursorCol);
      const beforeYank = (this.state.lines[startLine] || "").slice(0, startCol);
      this.state.lines.splice(startLine, yankLines.length, beforeYank + afterCursor);
      this.state.cursorLine = startLine;
      this.state.cursorCol = startCol;
    }
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  /**
   * Add text to the kill ring.
   * If lastAction is "kill", accumulates with the previous entry.
   * @param text - The text to add
   * @param prepend - If accumulating, prepend (true) or append (false) to existing entry
   */
  addToKillRing(text, prepend) {
    if (!text)
      return;
    if (this.lastAction === "kill" && this.killRing.length > 0) {
      const lastEntry = this.killRing.pop();
      if (prepend) {
        this.killRing.push(text + lastEntry);
      } else {
        this.killRing.push(lastEntry + text);
      }
    } else {
      this.killRing.push(text);
    }
  }
  captureUndoSnapshot() {
    return structuredClone(this.state);
  }
  restoreUndoSnapshot(snapshot) {
    Object.assign(this.state, structuredClone(snapshot));
  }
  pushUndoSnapshot() {
    this.undoStack.push(this.captureUndoSnapshot());
  }
  undo() {
    this.historyIndex = -1;
    if (this.undoStack.length === 0)
      return;
    const snapshot = this.undoStack.pop();
    this.restoreUndoSnapshot(snapshot);
    this.lastAction = null;
    if (this.onChange) {
      this.onChange(this.getText());
    }
  }
  moveWordForwards() {
    this.lastAction = null;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    if (this.state.cursorCol >= currentLine.length) {
      if (this.state.cursorLine < this.state.lines.length - 1) {
        this.state.cursorLine++;
        this.state.cursorCol = 0;
      }
      return;
    }
    const textAfterCursor = currentLine.slice(this.state.cursorCol);
    const segments = segmenter2.segment(textAfterCursor);
    const iterator = segments[Symbol.iterator]();
    let next = iterator.next();
    while (!next.done && isWhitespaceChar(next.value.segment)) {
      this.state.cursorCol += next.value.segment.length;
      next = iterator.next();
    }
    if (!next.done) {
      const firstGrapheme = next.value.segment;
      if (isPunctuationChar(firstGrapheme)) {
        while (!next.done && isPunctuationChar(next.value.segment)) {
          this.state.cursorCol += next.value.segment.length;
          next = iterator.next();
        }
      } else {
        while (!next.done && !isWhitespaceChar(next.value.segment) && !isPunctuationChar(next.value.segment)) {
          this.state.cursorCol += next.value.segment.length;
          next = iterator.next();
        }
      }
    }
  }
  // Helper method to check if cursor is at start of message (for slash command detection)
  isAtStartOfMessage() {
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    const beforeCursor = currentLine.slice(0, this.state.cursorCol);
    return beforeCursor.trim() === "" || beforeCursor.trim() === "/";
  }
  // Autocomplete methods
  tryTriggerAutocomplete(explicitTab = false) {
    if (!this.autocompleteProvider)
      return;
    if (explicitTab) {
      const provider = this.autocompleteProvider;
      const shouldTrigger = !provider.shouldTriggerFileCompletion || provider.shouldTriggerFileCompletion(this.state.lines, this.state.cursorLine, this.state.cursorCol);
      if (!shouldTrigger) {
        return;
      }
    }
    const suggestions = this.autocompleteProvider.getSuggestions(this.state.lines, this.state.cursorLine, this.state.cursorCol);
    if (suggestions && suggestions.items.length > 0) {
      this.autocompletePrefix = suggestions.prefix;
      this.autocompleteList = new SelectList(suggestions.items, 5, this.theme.selectList);
      this.isAutocompleting = true;
    } else {
      this.cancelAutocomplete();
    }
  }
  handleTabCompletion() {
    if (!this.autocompleteProvider)
      return;
    const currentLine = this.state.lines[this.state.cursorLine] || "";
    const beforeCursor = currentLine.slice(0, this.state.cursorCol);
    if (beforeCursor.trimStart().startsWith("/") && !beforeCursor.trimStart().includes(" ")) {
      this.handleSlashCommandCompletion();
    } else {
      this.forceFileAutocomplete();
    }
  }
  handleSlashCommandCompletion() {
    this.tryTriggerAutocomplete(true);
  }
  /*
  https://github.com/EsotericSoftware/spine-runtimes/actions/runs/19536643416/job/559322883
  17 this job fails with https://github.com/EsotericSoftware/spine-runtimes/actions/runs/19
  536643416/job/55932288317 havea  look at .gi
   */
  forceFileAutocomplete() {
    if (!this.autocompleteProvider)
      return;
    const provider = this.autocompleteProvider;
    if (typeof provider.getForceFileSuggestions !== "function") {
      this.tryTriggerAutocomplete(true);
      return;
    }
    const suggestions = provider.getForceFileSuggestions(this.state.lines, this.state.cursorLine, this.state.cursorCol);
    if (suggestions && suggestions.items.length > 0) {
      this.autocompletePrefix = suggestions.prefix;
      this.autocompleteList = new SelectList(suggestions.items, 5, this.theme.selectList);
      this.isAutocompleting = true;
    } else {
      this.cancelAutocomplete();
    }
  }
  cancelAutocomplete() {
    this.isAutocompleting = false;
    this.autocompleteList = void 0;
    this.autocompletePrefix = "";
  }
  isShowingAutocomplete() {
    return this.isAutocompleting;
  }
  updateAutocomplete() {
    if (!this.isAutocompleting || !this.autocompleteProvider)
      return;
    const suggestions = this.autocompleteProvider.getSuggestions(this.state.lines, this.state.cursorLine, this.state.cursorCol);
    if (suggestions && suggestions.items.length > 0) {
      this.autocompletePrefix = suggestions.prefix;
      this.autocompleteList = new SelectList(suggestions.items, 5, this.theme.selectList);
    } else {
      this.cancelAutocomplete();
    }
  }
};

// node_modules/@mariozechner/pi-tui/dist/components/image.js
var Image = class {
  base64Data;
  mimeType;
  dimensions;
  theme;
  options;
  cachedLines;
  cachedWidth;
  constructor(base64Data, mimeType, theme, options3 = {}, dimensions) {
    this.base64Data = base64Data;
    this.mimeType = mimeType;
    this.theme = theme;
    this.options = options3;
    this.dimensions = dimensions || getImageDimensions(base64Data, mimeType) || { widthPx: 800, heightPx: 600 };
  }
  invalidate() {
    this.cachedLines = void 0;
    this.cachedWidth = void 0;
  }
  render(width) {
    if (this.cachedLines && this.cachedWidth === width) {
      return this.cachedLines;
    }
    const maxWidth = Math.min(width - 2, this.options.maxWidthCells ?? 60);
    const caps = getCapabilities();
    let lines;
    if (caps.images) {
      const result = renderImage(this.base64Data, this.dimensions, { maxWidthCells: maxWidth });
      if (result) {
        lines = [];
        for (let i = 0; i < result.rows - 1; i++) {
          lines.push("");
        }
        const moveUp = result.rows > 1 ? `\x1B[${result.rows - 1}A` : "";
        lines.push(moveUp + result.sequence);
      } else {
        const fallback = imageFallback(this.mimeType, this.dimensions, this.options.filename);
        lines = [this.theme.fallbackColor(fallback)];
      }
    } else {
      const fallback = imageFallback(this.mimeType, this.dimensions, this.options.filename);
      lines = [this.theme.fallbackColor(fallback)];
    }
    this.cachedLines = lines;
    this.cachedWidth = width;
    return lines;
  }
};

// node_modules/@mariozechner/pi-tui/dist/components/input.js
var segmenter3 = getSegmenter();
var Input = class {
  value = "";
  cursor = 0;
  // Cursor position in the value
  onSubmit;
  onEscape;
  /** Focusable interface - set by TUI when focus changes */
  focused = false;
  // Bracketed paste mode buffering
  pasteBuffer = "";
  isInPaste = false;
  pendingShiftEnter = false;
  getValue() {
    return this.value;
  }
  setValue(value) {
    this.value = value;
    this.cursor = Math.min(this.cursor, value.length);
  }
  handleInput(data) {
    if (data.includes("\x1B[200~")) {
      this.isInPaste = true;
      this.pasteBuffer = "";
      data = data.replace("\x1B[200~", "");
    }
    if (this.isInPaste) {
      this.pasteBuffer += data;
      const endIndex = this.pasteBuffer.indexOf("\x1B[201~");
      if (endIndex !== -1) {
        const pasteContent = this.pasteBuffer.substring(0, endIndex);
        this.handlePaste(pasteContent);
        this.isInPaste = false;
        const remaining = this.pasteBuffer.substring(endIndex + 6);
        this.pasteBuffer = "";
        if (remaining) {
          this.handleInput(remaining);
        }
      }
      return;
    }
    if (this.pendingShiftEnter) {
      if (data === "\r") {
        this.pendingShiftEnter = false;
        if (this.onSubmit)
          this.onSubmit(this.value);
        return;
      }
      this.pendingShiftEnter = false;
      this.value = `${this.value.slice(0, this.cursor)}\\${this.value.slice(this.cursor)}`;
      this.cursor += 1;
    }
    if (data === "\\") {
      this.pendingShiftEnter = true;
      return;
    }
    const kb = getEditorKeybindings();
    if (kb.matches(data, "selectCancel")) {
      if (this.onEscape)
        this.onEscape();
      return;
    }
    if (kb.matches(data, "submit") || data === "\n") {
      if (this.onSubmit)
        this.onSubmit(this.value);
      return;
    }
    if (kb.matches(data, "deleteCharBackward")) {
      if (this.cursor > 0) {
        const beforeCursor = this.value.slice(0, this.cursor);
        const graphemes = [...segmenter3.segment(beforeCursor)];
        const lastGrapheme = graphemes[graphemes.length - 1];
        const graphemeLength = lastGrapheme ? lastGrapheme.segment.length : 1;
        this.value = this.value.slice(0, this.cursor - graphemeLength) + this.value.slice(this.cursor);
        this.cursor -= graphemeLength;
      }
      return;
    }
    if (kb.matches(data, "deleteCharForward")) {
      if (this.cursor < this.value.length) {
        const afterCursor = this.value.slice(this.cursor);
        const graphemes = [...segmenter3.segment(afterCursor)];
        const firstGrapheme = graphemes[0];
        const graphemeLength = firstGrapheme ? firstGrapheme.segment.length : 1;
        this.value = this.value.slice(0, this.cursor) + this.value.slice(this.cursor + graphemeLength);
      }
      return;
    }
    if (kb.matches(data, "deleteWordBackward")) {
      this.deleteWordBackwards();
      return;
    }
    if (kb.matches(data, "deleteToLineStart")) {
      this.value = this.value.slice(this.cursor);
      this.cursor = 0;
      return;
    }
    if (kb.matches(data, "deleteToLineEnd")) {
      this.value = this.value.slice(0, this.cursor);
      return;
    }
    if (kb.matches(data, "cursorLeft")) {
      if (this.cursor > 0) {
        const beforeCursor = this.value.slice(0, this.cursor);
        const graphemes = [...segmenter3.segment(beforeCursor)];
        const lastGrapheme = graphemes[graphemes.length - 1];
        this.cursor -= lastGrapheme ? lastGrapheme.segment.length : 1;
      }
      return;
    }
    if (kb.matches(data, "cursorRight")) {
      if (this.cursor < this.value.length) {
        const afterCursor = this.value.slice(this.cursor);
        const graphemes = [...segmenter3.segment(afterCursor)];
        const firstGrapheme = graphemes[0];
        this.cursor += firstGrapheme ? firstGrapheme.segment.length : 1;
      }
      return;
    }
    if (kb.matches(data, "cursorLineStart")) {
      this.cursor = 0;
      return;
    }
    if (kb.matches(data, "cursorLineEnd")) {
      this.cursor = this.value.length;
      return;
    }
    if (kb.matches(data, "cursorWordLeft")) {
      this.moveWordBackwards();
      return;
    }
    if (kb.matches(data, "cursorWordRight")) {
      this.moveWordForwards();
      return;
    }
    const hasControlChars = [...data].some((ch) => {
      const code = ch.charCodeAt(0);
      return code < 32 || code === 127 || code >= 128 && code <= 159;
    });
    if (!hasControlChars) {
      this.value = this.value.slice(0, this.cursor) + data + this.value.slice(this.cursor);
      this.cursor += data.length;
    }
  }
  deleteWordBackwards() {
    if (this.cursor === 0) {
      return;
    }
    const oldCursor = this.cursor;
    this.moveWordBackwards();
    const deleteFrom = this.cursor;
    this.cursor = oldCursor;
    this.value = this.value.slice(0, deleteFrom) + this.value.slice(this.cursor);
    this.cursor = deleteFrom;
  }
  moveWordBackwards() {
    if (this.cursor === 0) {
      return;
    }
    const textBeforeCursor = this.value.slice(0, this.cursor);
    const graphemes = [...segmenter3.segment(textBeforeCursor)];
    while (graphemes.length > 0 && isWhitespaceChar(graphemes[graphemes.length - 1]?.segment || "")) {
      this.cursor -= graphemes.pop()?.segment.length || 0;
    }
    if (graphemes.length > 0) {
      const lastGrapheme = graphemes[graphemes.length - 1]?.segment || "";
      if (isPunctuationChar(lastGrapheme)) {
        while (graphemes.length > 0 && isPunctuationChar(graphemes[graphemes.length - 1]?.segment || "")) {
          this.cursor -= graphemes.pop()?.segment.length || 0;
        }
      } else {
        while (graphemes.length > 0 && !isWhitespaceChar(graphemes[graphemes.length - 1]?.segment || "") && !isPunctuationChar(graphemes[graphemes.length - 1]?.segment || "")) {
          this.cursor -= graphemes.pop()?.segment.length || 0;
        }
      }
    }
  }
  moveWordForwards() {
    if (this.cursor >= this.value.length) {
      return;
    }
    const textAfterCursor = this.value.slice(this.cursor);
    const segments = segmenter3.segment(textAfterCursor);
    const iterator = segments[Symbol.iterator]();
    let next = iterator.next();
    while (!next.done && isWhitespaceChar(next.value.segment)) {
      this.cursor += next.value.segment.length;
      next = iterator.next();
    }
    if (!next.done) {
      const firstGrapheme = next.value.segment;
      if (isPunctuationChar(firstGrapheme)) {
        while (!next.done && isPunctuationChar(next.value.segment)) {
          this.cursor += next.value.segment.length;
          next = iterator.next();
        }
      } else {
        while (!next.done && !isWhitespaceChar(next.value.segment) && !isPunctuationChar(next.value.segment)) {
          this.cursor += next.value.segment.length;
          next = iterator.next();
        }
      }
    }
  }
  handlePaste(pastedText) {
    const cleanText = pastedText.replace(/\r\n/g, "").replace(/\r/g, "").replace(/\n/g, "");
    this.value = this.value.slice(0, this.cursor) + cleanText + this.value.slice(this.cursor);
    this.cursor += cleanText.length;
  }
  invalidate() {
  }
  render(width) {
    const prompt = "> ";
    const availableWidth = width - prompt.length;
    if (availableWidth <= 0) {
      return [prompt];
    }
    let visibleText = "";
    let cursorDisplay = this.cursor;
    if (this.value.length < availableWidth) {
      visibleText = this.value;
    } else {
      const scrollWidth = this.cursor === this.value.length ? availableWidth - 1 : availableWidth;
      const halfWidth = Math.floor(scrollWidth / 2);
      if (this.cursor < halfWidth) {
        visibleText = this.value.slice(0, scrollWidth);
        cursorDisplay = this.cursor;
      } else if (this.cursor > this.value.length - halfWidth) {
        visibleText = this.value.slice(this.value.length - scrollWidth);
        cursorDisplay = scrollWidth - (this.value.length - this.cursor);
      } else {
        const start = this.cursor - halfWidth;
        visibleText = this.value.slice(start, start + scrollWidth);
        cursorDisplay = halfWidth;
      }
    }
    const beforeCursor = visibleText.slice(0, cursorDisplay);
    const atCursor = visibleText[cursorDisplay] || " ";
    const afterCursor = visibleText.slice(cursorDisplay + 1);
    const marker = this.focused ? CURSOR_MARKER : "";
    const cursorChar = `\x1B[7m${atCursor}\x1B[27m`;
    const textWithCursor = beforeCursor + marker + cursorChar + afterCursor;
    const visualLength = visibleWidth(textWithCursor);
    const padding = " ".repeat(Math.max(0, availableWidth - visualLength));
    const line = prompt + textWithCursor + padding;
    return [line];
  }
};

// node_modules/marked/lib/marked.esm.js
function _getDefaults() {
  return {
    async: false,
    breaks: false,
    extensions: null,
    gfm: true,
    hooks: null,
    pedantic: false,
    renderer: null,
    silent: false,
    tokenizer: null,
    walkTokens: null
  };
}
var _defaults = _getDefaults();
function changeDefaults(newDefaults) {
  _defaults = newDefaults;
}
var noopTest = { exec: () => null };
function edit(regex, opt = "") {
  let source = typeof regex === "string" ? regex : regex.source;
  const obj = {
    replace: (name, val) => {
      let valSource = typeof val === "string" ? val : val.source;
      valSource = valSource.replace(other.caret, "$1");
      source = source.replace(name, valSource);
      return obj;
    },
    getRegex: () => {
      return new RegExp(source, opt);
    }
  };
  return obj;
}
var other = {
  codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  listReplaceTabs: /^\t+/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\] /,
  listReplaceTask: /^\[[ xX]\] +/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (bull) => new RegExp(`^( {0,3}${bull})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
  hrRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
  fencesBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:\`\`\`|~~~)`),
  headingBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}#`),
  htmlBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}<(?:[a-z].*>|!--)`, "i")
};
var newline = /^(?:[ \t]*(?:\n|$))+/;
var blockCode = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/;
var fences = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/;
var hr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
var heading = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
var bullet = /(?:[*+-]|\d{1,9}[.)])/;
var lheadingCore = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/;
var lheading = edit(lheadingCore).replace(/bull/g, bullet).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex();
var lheadingGfm = edit(lheadingCore).replace(/bull/g, bullet).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex();
var _paragraph = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/;
var blockText = /^[^\n]+/;
var _blockLabel = /(?!\s*\])(?:\\.|[^\[\]\\])+/;
var def = edit(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", _blockLabel).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex();
var list = edit(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, bullet).getRegex();
var _tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
var _comment = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
var html = edit(
  "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
  "i"
).replace("comment", _comment).replace("tag", _tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
var paragraph = edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
var blockquote = edit(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", paragraph).getRegex();
var blockNormal = {
  blockquote,
  code: blockCode,
  def,
  fences,
  heading,
  hr,
  html,
  lheading,
  list,
  newline,
  paragraph,
  table: noopTest,
  text: blockText
};
var gfmTable = edit(
  "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
var blockGfm = {
  ...blockNormal,
  lheading: lheadingGfm,
  table: gfmTable,
  paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", gfmTable).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex()
};
var blockPedantic = {
  ...blockNormal,
  html: edit(
    `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
  ).replace("comment", _comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: noopTest,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " *#{1,6} *[^\n]").replace("lheading", lheading).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
};
var escape = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
var inlineCode = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
var br = /^( {2,}|\\)\n(?!\s*$)/;
var inlineText = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
var _punctuation = /[\p{P}\p{S}]/u;
var _punctuationOrSpace = /[\s\p{P}\p{S}]/u;
var _notPunctuationOrSpace = /[^\s\p{P}\p{S}]/u;
var punctuation = edit(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, _punctuationOrSpace).getRegex();
var _punctuationGfmStrongEm = /(?!~)[\p{P}\p{S}]/u;
var _punctuationOrSpaceGfmStrongEm = /(?!~)[\s\p{P}\p{S}]/u;
var _notPunctuationOrSpaceGfmStrongEm = /(?:[^\s\p{P}\p{S}]|~)/u;
var blockSkip = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g;
var emStrongLDelimCore = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/;
var emStrongLDelim = edit(emStrongLDelimCore, "u").replace(/punct/g, _punctuation).getRegex();
var emStrongLDelimGfm = edit(emStrongLDelimCore, "u").replace(/punct/g, _punctuationGfmStrongEm).getRegex();
var emStrongRDelimAstCore = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)";
var emStrongRDelimAst = edit(emStrongRDelimAstCore, "gu").replace(/notPunctSpace/g, _notPunctuationOrSpace).replace(/punctSpace/g, _punctuationOrSpace).replace(/punct/g, _punctuation).getRegex();
var emStrongRDelimAstGfm = edit(emStrongRDelimAstCore, "gu").replace(/notPunctSpace/g, _notPunctuationOrSpaceGfmStrongEm).replace(/punctSpace/g, _punctuationOrSpaceGfmStrongEm).replace(/punct/g, _punctuationGfmStrongEm).getRegex();
var emStrongRDelimUnd = edit(
  "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
  "gu"
).replace(/notPunctSpace/g, _notPunctuationOrSpace).replace(/punctSpace/g, _punctuationOrSpace).replace(/punct/g, _punctuation).getRegex();
var anyPunctuation = edit(/\\(punct)/, "gu").replace(/punct/g, _punctuation).getRegex();
var autolink = edit(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
var _inlineComment = edit(_comment).replace("(?:-->|$)", "-->").getRegex();
var tag = edit(
  "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>"
).replace("comment", _inlineComment).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
var _inlineLabel = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;
var link = edit(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", _inlineLabel).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex();
var reflink = edit(/^!?\[(label)\]\[(ref)\]/).replace("label", _inlineLabel).replace("ref", _blockLabel).getRegex();
var nolink = edit(/^!?\[(ref)\](?:\[\])?/).replace("ref", _blockLabel).getRegex();
var reflinkSearch = edit("reflink|nolink(?!\\()", "g").replace("reflink", reflink).replace("nolink", nolink).getRegex();
var inlineNormal = {
  _backpedal: noopTest,
  // only used for GFM url
  anyPunctuation,
  autolink,
  blockSkip,
  br,
  code: inlineCode,
  del: noopTest,
  emStrongLDelim,
  emStrongRDelimAst,
  emStrongRDelimUnd,
  escape,
  link,
  nolink,
  punctuation,
  reflink,
  reflinkSearch,
  tag,
  text: inlineText,
  url: noopTest
};
var inlinePedantic = {
  ...inlineNormal,
  link: edit(/^!?\[(label)\]\((.*?)\)/).replace("label", _inlineLabel).getRegex(),
  reflink: edit(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", _inlineLabel).getRegex()
};
var inlineGfm = {
  ...inlineNormal,
  emStrongRDelimAst: emStrongRDelimAstGfm,
  emStrongLDelim: emStrongLDelimGfm,
  url: edit(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
};
var inlineBreaks = {
  ...inlineGfm,
  br: edit(br).replace("{2,}", "*").getRegex(),
  text: edit(inlineGfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
};
var block = {
  normal: blockNormal,
  gfm: blockGfm,
  pedantic: blockPedantic
};
var inline = {
  normal: inlineNormal,
  gfm: inlineGfm,
  breaks: inlineBreaks,
  pedantic: inlinePedantic
};
var escapeReplacements = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
var getEscapeReplacement = (ch) => escapeReplacements[ch];
function escape2(html2, encode) {
  if (encode) {
    if (other.escapeTest.test(html2)) {
      return html2.replace(other.escapeReplace, getEscapeReplacement);
    }
  } else {
    if (other.escapeTestNoEncode.test(html2)) {
      return html2.replace(other.escapeReplaceNoEncode, getEscapeReplacement);
    }
  }
  return html2;
}
function cleanUrl(href) {
  try {
    href = encodeURI(href).replace(other.percentDecode, "%");
  } catch {
    return null;
  }
  return href;
}
function splitCells(tableRow, count) {
  const row = tableRow.replace(other.findPipe, (match, offset, str) => {
    let escaped = false;
    let curr = offset;
    while (--curr >= 0 && str[curr] === "\\") escaped = !escaped;
    if (escaped) {
      return "|";
    } else {
      return " |";
    }
  }), cells = row.split(other.splitPipe);
  let i = 0;
  if (!cells[0].trim()) {
    cells.shift();
  }
  if (cells.length > 0 && !cells.at(-1)?.trim()) {
    cells.pop();
  }
  if (count) {
    if (cells.length > count) {
      cells.splice(count);
    } else {
      while (cells.length < count) cells.push("");
    }
  }
  for (; i < cells.length; i++) {
    cells[i] = cells[i].trim().replace(other.slashPipe, "|");
  }
  return cells;
}
function rtrim(str, c, invert) {
  const l = str.length;
  if (l === 0) {
    return "";
  }
  let suffLen = 0;
  while (suffLen < l) {
    const currChar = str.charAt(l - suffLen - 1);
    if (currChar === c && !invert) {
      suffLen++;
    } else if (currChar !== c && invert) {
      suffLen++;
    } else {
      break;
    }
  }
  return str.slice(0, l - suffLen);
}
function findClosingBracket(str, b) {
  if (str.indexOf(b[1]) === -1) {
    return -1;
  }
  let level = 0;
  for (let i = 0; i < str.length; i++) {
    if (str[i] === "\\") {
      i++;
    } else if (str[i] === b[0]) {
      level++;
    } else if (str[i] === b[1]) {
      level--;
      if (level < 0) {
        return i;
      }
    }
  }
  if (level > 0) {
    return -2;
  }
  return -1;
}
function outputLink(cap, link2, raw, lexer2, rules) {
  const href = link2.href;
  const title = link2.title || null;
  const text = cap[1].replace(rules.other.outputLinkReplace, "$1");
  lexer2.state.inLink = true;
  const token = {
    type: cap[0].charAt(0) === "!" ? "image" : "link",
    raw,
    href,
    title,
    text,
    tokens: lexer2.inlineTokens(text)
  };
  lexer2.state.inLink = false;
  return token;
}
function indentCodeCompensation(raw, text, rules) {
  const matchIndentToCode = raw.match(rules.other.indentCodeCompensation);
  if (matchIndentToCode === null) {
    return text;
  }
  const indentToCode = matchIndentToCode[1];
  return text.split("\n").map((node) => {
    const matchIndentInNode = node.match(rules.other.beginningSpace);
    if (matchIndentInNode === null) {
      return node;
    }
    const [indentInNode] = matchIndentInNode;
    if (indentInNode.length >= indentToCode.length) {
      return node.slice(indentToCode.length);
    }
    return node;
  }).join("\n");
}
var _Tokenizer = class {
  options;
  rules;
  // set by the lexer
  lexer;
  // set by the lexer
  constructor(options22) {
    this.options = options22 || _defaults;
  }
  space(src) {
    const cap = this.rules.block.newline.exec(src);
    if (cap && cap[0].length > 0) {
      return {
        type: "space",
        raw: cap[0]
      };
    }
  }
  code(src) {
    const cap = this.rules.block.code.exec(src);
    if (cap) {
      const text = cap[0].replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: cap[0],
        codeBlockStyle: "indented",
        text: !this.options.pedantic ? rtrim(text, "\n") : text
      };
    }
  }
  fences(src) {
    const cap = this.rules.block.fences.exec(src);
    if (cap) {
      const raw = cap[0];
      const text = indentCodeCompensation(raw, cap[3] || "", this.rules);
      return {
        type: "code",
        raw,
        lang: cap[2] ? cap[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : cap[2],
        text
      };
    }
  }
  heading(src) {
    const cap = this.rules.block.heading.exec(src);
    if (cap) {
      let text = cap[2].trim();
      if (this.rules.other.endingHash.test(text)) {
        const trimmed = rtrim(text, "#");
        if (this.options.pedantic) {
          text = trimmed.trim();
        } else if (!trimmed || this.rules.other.endingSpaceChar.test(trimmed)) {
          text = trimmed.trim();
        }
      }
      return {
        type: "heading",
        raw: cap[0],
        depth: cap[1].length,
        text,
        tokens: this.lexer.inline(text)
      };
    }
  }
  hr(src) {
    const cap = this.rules.block.hr.exec(src);
    if (cap) {
      return {
        type: "hr",
        raw: rtrim(cap[0], "\n")
      };
    }
  }
  blockquote(src) {
    const cap = this.rules.block.blockquote.exec(src);
    if (cap) {
      let lines = rtrim(cap[0], "\n").split("\n");
      let raw = "";
      let text = "";
      const tokens = [];
      while (lines.length > 0) {
        let inBlockquote = false;
        const currentLines = [];
        let i;
        for (i = 0; i < lines.length; i++) {
          if (this.rules.other.blockquoteStart.test(lines[i])) {
            currentLines.push(lines[i]);
            inBlockquote = true;
          } else if (!inBlockquote) {
            currentLines.push(lines[i]);
          } else {
            break;
          }
        }
        lines = lines.slice(i);
        const currentRaw = currentLines.join("\n");
        const currentText = currentRaw.replace(this.rules.other.blockquoteSetextReplace, "\n    $1").replace(this.rules.other.blockquoteSetextReplace2, "");
        raw = raw ? `${raw}
${currentRaw}` : currentRaw;
        text = text ? `${text}
${currentText}` : currentText;
        const top = this.lexer.state.top;
        this.lexer.state.top = true;
        this.lexer.blockTokens(currentText, tokens, true);
        this.lexer.state.top = top;
        if (lines.length === 0) {
          break;
        }
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "code") {
          break;
        } else if (lastToken?.type === "blockquote") {
          const oldToken = lastToken;
          const newText = oldToken.raw + "\n" + lines.join("\n");
          const newToken = this.blockquote(newText);
          tokens[tokens.length - 1] = newToken;
          raw = raw.substring(0, raw.length - oldToken.raw.length) + newToken.raw;
          text = text.substring(0, text.length - oldToken.text.length) + newToken.text;
          break;
        } else if (lastToken?.type === "list") {
          const oldToken = lastToken;
          const newText = oldToken.raw + "\n" + lines.join("\n");
          const newToken = this.list(newText);
          tokens[tokens.length - 1] = newToken;
          raw = raw.substring(0, raw.length - lastToken.raw.length) + newToken.raw;
          text = text.substring(0, text.length - oldToken.raw.length) + newToken.raw;
          lines = newText.substring(tokens.at(-1).raw.length).split("\n");
          continue;
        }
      }
      return {
        type: "blockquote",
        raw,
        tokens,
        text
      };
    }
  }
  list(src) {
    let cap = this.rules.block.list.exec(src);
    if (cap) {
      let bull = cap[1].trim();
      const isordered = bull.length > 1;
      const list2 = {
        type: "list",
        raw: "",
        ordered: isordered,
        start: isordered ? +bull.slice(0, -1) : "",
        loose: false,
        items: []
      };
      bull = isordered ? `\\d{1,9}\\${bull.slice(-1)}` : `\\${bull}`;
      if (this.options.pedantic) {
        bull = isordered ? bull : "[*+-]";
      }
      const itemRegex = this.rules.other.listItemRegex(bull);
      let endsWithBlankLine = false;
      while (src) {
        let endEarly = false;
        let raw = "";
        let itemContents = "";
        if (!(cap = itemRegex.exec(src))) {
          break;
        }
        if (this.rules.block.hr.test(src)) {
          break;
        }
        raw = cap[0];
        src = src.substring(raw.length);
        let line = cap[2].split("\n", 1)[0].replace(this.rules.other.listReplaceTabs, (t) => " ".repeat(3 * t.length));
        let nextLine = src.split("\n", 1)[0];
        let blankLine = !line.trim();
        let indent = 0;
        if (this.options.pedantic) {
          indent = 2;
          itemContents = line.trimStart();
        } else if (blankLine) {
          indent = cap[1].length + 1;
        } else {
          indent = cap[2].search(this.rules.other.nonSpaceChar);
          indent = indent > 4 ? 1 : indent;
          itemContents = line.slice(indent);
          indent += cap[1].length;
        }
        if (blankLine && this.rules.other.blankLine.test(nextLine)) {
          raw += nextLine + "\n";
          src = src.substring(nextLine.length + 1);
          endEarly = true;
        }
        if (!endEarly) {
          const nextBulletRegex = this.rules.other.nextBulletRegex(indent);
          const hrRegex = this.rules.other.hrRegex(indent);
          const fencesBeginRegex = this.rules.other.fencesBeginRegex(indent);
          const headingBeginRegex = this.rules.other.headingBeginRegex(indent);
          const htmlBeginRegex = this.rules.other.htmlBeginRegex(indent);
          while (src) {
            const rawLine = src.split("\n", 1)[0];
            let nextLineWithoutTabs;
            nextLine = rawLine;
            if (this.options.pedantic) {
              nextLine = nextLine.replace(this.rules.other.listReplaceNesting, "  ");
              nextLineWithoutTabs = nextLine;
            } else {
              nextLineWithoutTabs = nextLine.replace(this.rules.other.tabCharGlobal, "    ");
            }
            if (fencesBeginRegex.test(nextLine)) {
              break;
            }
            if (headingBeginRegex.test(nextLine)) {
              break;
            }
            if (htmlBeginRegex.test(nextLine)) {
              break;
            }
            if (nextBulletRegex.test(nextLine)) {
              break;
            }
            if (hrRegex.test(nextLine)) {
              break;
            }
            if (nextLineWithoutTabs.search(this.rules.other.nonSpaceChar) >= indent || !nextLine.trim()) {
              itemContents += "\n" + nextLineWithoutTabs.slice(indent);
            } else {
              if (blankLine) {
                break;
              }
              if (line.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4) {
                break;
              }
              if (fencesBeginRegex.test(line)) {
                break;
              }
              if (headingBeginRegex.test(line)) {
                break;
              }
              if (hrRegex.test(line)) {
                break;
              }
              itemContents += "\n" + nextLine;
            }
            if (!blankLine && !nextLine.trim()) {
              blankLine = true;
            }
            raw += rawLine + "\n";
            src = src.substring(rawLine.length + 1);
            line = nextLineWithoutTabs.slice(indent);
          }
        }
        if (!list2.loose) {
          if (endsWithBlankLine) {
            list2.loose = true;
          } else if (this.rules.other.doubleBlankLine.test(raw)) {
            endsWithBlankLine = true;
          }
        }
        let istask = null;
        let ischecked;
        if (this.options.gfm) {
          istask = this.rules.other.listIsTask.exec(itemContents);
          if (istask) {
            ischecked = istask[0] !== "[ ] ";
            itemContents = itemContents.replace(this.rules.other.listReplaceTask, "");
          }
        }
        list2.items.push({
          type: "list_item",
          raw,
          task: !!istask,
          checked: ischecked,
          loose: false,
          text: itemContents,
          tokens: []
        });
        list2.raw += raw;
      }
      const lastItem = list2.items.at(-1);
      if (lastItem) {
        lastItem.raw = lastItem.raw.trimEnd();
        lastItem.text = lastItem.text.trimEnd();
      } else {
        return;
      }
      list2.raw = list2.raw.trimEnd();
      for (let i = 0; i < list2.items.length; i++) {
        this.lexer.state.top = false;
        list2.items[i].tokens = this.lexer.blockTokens(list2.items[i].text, []);
        if (!list2.loose) {
          const spacers = list2.items[i].tokens.filter((t) => t.type === "space");
          const hasMultipleLineBreaks = spacers.length > 0 && spacers.some((t) => this.rules.other.anyLine.test(t.raw));
          list2.loose = hasMultipleLineBreaks;
        }
      }
      if (list2.loose) {
        for (let i = 0; i < list2.items.length; i++) {
          list2.items[i].loose = true;
        }
      }
      return list2;
    }
  }
  html(src) {
    const cap = this.rules.block.html.exec(src);
    if (cap) {
      const token = {
        type: "html",
        block: true,
        raw: cap[0],
        pre: cap[1] === "pre" || cap[1] === "script" || cap[1] === "style",
        text: cap[0]
      };
      return token;
    }
  }
  def(src) {
    const cap = this.rules.block.def.exec(src);
    if (cap) {
      const tag2 = cap[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " ");
      const href = cap[2] ? cap[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "";
      const title = cap[3] ? cap[3].substring(1, cap[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : cap[3];
      return {
        type: "def",
        tag: tag2,
        raw: cap[0],
        href,
        title
      };
    }
  }
  table(src) {
    const cap = this.rules.block.table.exec(src);
    if (!cap) {
      return;
    }
    if (!this.rules.other.tableDelimiter.test(cap[2])) {
      return;
    }
    const headers = splitCells(cap[1]);
    const aligns = cap[2].replace(this.rules.other.tableAlignChars, "").split("|");
    const rows = cap[3]?.trim() ? cap[3].replace(this.rules.other.tableRowBlankLine, "").split("\n") : [];
    const item = {
      type: "table",
      raw: cap[0],
      header: [],
      align: [],
      rows: []
    };
    if (headers.length !== aligns.length) {
      return;
    }
    for (const align of aligns) {
      if (this.rules.other.tableAlignRight.test(align)) {
        item.align.push("right");
      } else if (this.rules.other.tableAlignCenter.test(align)) {
        item.align.push("center");
      } else if (this.rules.other.tableAlignLeft.test(align)) {
        item.align.push("left");
      } else {
        item.align.push(null);
      }
    }
    for (let i = 0; i < headers.length; i++) {
      item.header.push({
        text: headers[i],
        tokens: this.lexer.inline(headers[i]),
        header: true,
        align: item.align[i]
      });
    }
    for (const row of rows) {
      item.rows.push(splitCells(row, item.header.length).map((cell, i) => {
        return {
          text: cell,
          tokens: this.lexer.inline(cell),
          header: false,
          align: item.align[i]
        };
      }));
    }
    return item;
  }
  lheading(src) {
    const cap = this.rules.block.lheading.exec(src);
    if (cap) {
      return {
        type: "heading",
        raw: cap[0],
        depth: cap[2].charAt(0) === "=" ? 1 : 2,
        text: cap[1],
        tokens: this.lexer.inline(cap[1])
      };
    }
  }
  paragraph(src) {
    const cap = this.rules.block.paragraph.exec(src);
    if (cap) {
      const text = cap[1].charAt(cap[1].length - 1) === "\n" ? cap[1].slice(0, -1) : cap[1];
      return {
        type: "paragraph",
        raw: cap[0],
        text,
        tokens: this.lexer.inline(text)
      };
    }
  }
  text(src) {
    const cap = this.rules.block.text.exec(src);
    if (cap) {
      return {
        type: "text",
        raw: cap[0],
        text: cap[0],
        tokens: this.lexer.inline(cap[0])
      };
    }
  }
  escape(src) {
    const cap = this.rules.inline.escape.exec(src);
    if (cap) {
      return {
        type: "escape",
        raw: cap[0],
        text: cap[1]
      };
    }
  }
  tag(src) {
    const cap = this.rules.inline.tag.exec(src);
    if (cap) {
      if (!this.lexer.state.inLink && this.rules.other.startATag.test(cap[0])) {
        this.lexer.state.inLink = true;
      } else if (this.lexer.state.inLink && this.rules.other.endATag.test(cap[0])) {
        this.lexer.state.inLink = false;
      }
      if (!this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(cap[0])) {
        this.lexer.state.inRawBlock = true;
      } else if (this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(cap[0])) {
        this.lexer.state.inRawBlock = false;
      }
      return {
        type: "html",
        raw: cap[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: false,
        text: cap[0]
      };
    }
  }
  link(src) {
    const cap = this.rules.inline.link.exec(src);
    if (cap) {
      const trimmedUrl = cap[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(trimmedUrl)) {
        if (!this.rules.other.endAngleBracket.test(trimmedUrl)) {
          return;
        }
        const rtrimSlash = rtrim(trimmedUrl.slice(0, -1), "\\");
        if ((trimmedUrl.length - rtrimSlash.length) % 2 === 0) {
          return;
        }
      } else {
        const lastParenIndex = findClosingBracket(cap[2], "()");
        if (lastParenIndex === -2) {
          return;
        }
        if (lastParenIndex > -1) {
          const start = cap[0].indexOf("!") === 0 ? 5 : 4;
          const linkLen = start + cap[1].length + lastParenIndex;
          cap[2] = cap[2].substring(0, lastParenIndex);
          cap[0] = cap[0].substring(0, linkLen).trim();
          cap[3] = "";
        }
      }
      let href = cap[2];
      let title = "";
      if (this.options.pedantic) {
        const link2 = this.rules.other.pedanticHrefTitle.exec(href);
        if (link2) {
          href = link2[1];
          title = link2[3];
        }
      } else {
        title = cap[3] ? cap[3].slice(1, -1) : "";
      }
      href = href.trim();
      if (this.rules.other.startAngleBracket.test(href)) {
        if (this.options.pedantic && !this.rules.other.endAngleBracket.test(trimmedUrl)) {
          href = href.slice(1);
        } else {
          href = href.slice(1, -1);
        }
      }
      return outputLink(cap, {
        href: href ? href.replace(this.rules.inline.anyPunctuation, "$1") : href,
        title: title ? title.replace(this.rules.inline.anyPunctuation, "$1") : title
      }, cap[0], this.lexer, this.rules);
    }
  }
  reflink(src, links) {
    let cap;
    if ((cap = this.rules.inline.reflink.exec(src)) || (cap = this.rules.inline.nolink.exec(src))) {
      const linkString = (cap[2] || cap[1]).replace(this.rules.other.multipleSpaceGlobal, " ");
      const link2 = links[linkString.toLowerCase()];
      if (!link2) {
        const text = cap[0].charAt(0);
        return {
          type: "text",
          raw: text,
          text
        };
      }
      return outputLink(cap, link2, cap[0], this.lexer, this.rules);
    }
  }
  emStrong(src, maskedSrc, prevChar = "") {
    let match = this.rules.inline.emStrongLDelim.exec(src);
    if (!match) return;
    if (match[3] && prevChar.match(this.rules.other.unicodeAlphaNumeric)) return;
    const nextChar = match[1] || match[2] || "";
    if (!nextChar || !prevChar || this.rules.inline.punctuation.exec(prevChar)) {
      const lLength = [...match[0]].length - 1;
      let rDelim, rLength, delimTotal = lLength, midDelimTotal = 0;
      const endReg = match[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      endReg.lastIndex = 0;
      maskedSrc = maskedSrc.slice(-1 * src.length + lLength);
      while ((match = endReg.exec(maskedSrc)) != null) {
        rDelim = match[1] || match[2] || match[3] || match[4] || match[5] || match[6];
        if (!rDelim) continue;
        rLength = [...rDelim].length;
        if (match[3] || match[4]) {
          delimTotal += rLength;
          continue;
        } else if (match[5] || match[6]) {
          if (lLength % 3 && !((lLength + rLength) % 3)) {
            midDelimTotal += rLength;
            continue;
          }
        }
        delimTotal -= rLength;
        if (delimTotal > 0) continue;
        rLength = Math.min(rLength, rLength + delimTotal + midDelimTotal);
        const lastCharLength = [...match[0]][0].length;
        const raw = src.slice(0, lLength + match.index + lastCharLength + rLength);
        if (Math.min(lLength, rLength) % 2) {
          const text2 = raw.slice(1, -1);
          return {
            type: "em",
            raw,
            text: text2,
            tokens: this.lexer.inlineTokens(text2)
          };
        }
        const text = raw.slice(2, -2);
        return {
          type: "strong",
          raw,
          text,
          tokens: this.lexer.inlineTokens(text)
        };
      }
    }
  }
  codespan(src) {
    const cap = this.rules.inline.code.exec(src);
    if (cap) {
      let text = cap[2].replace(this.rules.other.newLineCharGlobal, " ");
      const hasNonSpaceChars = this.rules.other.nonSpaceChar.test(text);
      const hasSpaceCharsOnBothEnds = this.rules.other.startingSpaceChar.test(text) && this.rules.other.endingSpaceChar.test(text);
      if (hasNonSpaceChars && hasSpaceCharsOnBothEnds) {
        text = text.substring(1, text.length - 1);
      }
      return {
        type: "codespan",
        raw: cap[0],
        text
      };
    }
  }
  br(src) {
    const cap = this.rules.inline.br.exec(src);
    if (cap) {
      return {
        type: "br",
        raw: cap[0]
      };
    }
  }
  del(src) {
    const cap = this.rules.inline.del.exec(src);
    if (cap) {
      return {
        type: "del",
        raw: cap[0],
        text: cap[2],
        tokens: this.lexer.inlineTokens(cap[2])
      };
    }
  }
  autolink(src) {
    const cap = this.rules.inline.autolink.exec(src);
    if (cap) {
      let text, href;
      if (cap[2] === "@") {
        text = cap[1];
        href = "mailto:" + text;
      } else {
        text = cap[1];
        href = text;
      }
      return {
        type: "link",
        raw: cap[0],
        text,
        href,
        tokens: [
          {
            type: "text",
            raw: text,
            text
          }
        ]
      };
    }
  }
  url(src) {
    let cap;
    if (cap = this.rules.inline.url.exec(src)) {
      let text, href;
      if (cap[2] === "@") {
        text = cap[0];
        href = "mailto:" + text;
      } else {
        let prevCapZero;
        do {
          prevCapZero = cap[0];
          cap[0] = this.rules.inline._backpedal.exec(cap[0])?.[0] ?? "";
        } while (prevCapZero !== cap[0]);
        text = cap[0];
        if (cap[1] === "www.") {
          href = "http://" + cap[0];
        } else {
          href = cap[0];
        }
      }
      return {
        type: "link",
        raw: cap[0],
        text,
        href,
        tokens: [
          {
            type: "text",
            raw: text,
            text
          }
        ]
      };
    }
  }
  inlineText(src) {
    const cap = this.rules.inline.text.exec(src);
    if (cap) {
      const escaped = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: cap[0],
        text: cap[0],
        escaped
      };
    }
  }
};
var _Lexer = class __Lexer {
  tokens;
  options;
  state;
  tokenizer;
  inlineQueue;
  constructor(options22) {
    this.tokens = [];
    this.tokens.links = /* @__PURE__ */ Object.create(null);
    this.options = options22 || _defaults;
    this.options.tokenizer = this.options.tokenizer || new _Tokenizer();
    this.tokenizer = this.options.tokenizer;
    this.tokenizer.options = this.options;
    this.tokenizer.lexer = this;
    this.inlineQueue = [];
    this.state = {
      inLink: false,
      inRawBlock: false,
      top: true
    };
    const rules = {
      other,
      block: block.normal,
      inline: inline.normal
    };
    if (this.options.pedantic) {
      rules.block = block.pedantic;
      rules.inline = inline.pedantic;
    } else if (this.options.gfm) {
      rules.block = block.gfm;
      if (this.options.breaks) {
        rules.inline = inline.breaks;
      } else {
        rules.inline = inline.gfm;
      }
    }
    this.tokenizer.rules = rules;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block,
      inline
    };
  }
  /**
   * Static Lex Method
   */
  static lex(src, options22) {
    const lexer2 = new __Lexer(options22);
    return lexer2.lex(src);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(src, options22) {
    const lexer2 = new __Lexer(options22);
    return lexer2.inlineTokens(src);
  }
  /**
   * Preprocessing
   */
  lex(src) {
    src = src.replace(other.carriageReturn, "\n");
    this.blockTokens(src, this.tokens);
    for (let i = 0; i < this.inlineQueue.length; i++) {
      const next = this.inlineQueue[i];
      this.inlineTokens(next.src, next.tokens);
    }
    this.inlineQueue = [];
    return this.tokens;
  }
  blockTokens(src, tokens = [], lastParagraphClipped = false) {
    if (this.options.pedantic) {
      src = src.replace(other.tabCharGlobal, "    ").replace(other.spaceLine, "");
    }
    while (src) {
      let token;
      if (this.options.extensions?.block?.some((extTokenizer) => {
        if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          return true;
        }
        return false;
      })) {
        continue;
      }
      if (token = this.tokenizer.space(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (token.raw.length === 1 && lastToken !== void 0) {
          lastToken.raw += "\n";
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.code(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "paragraph" || lastToken?.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.at(-1).src = lastToken.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.fences(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.heading(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.hr(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.blockquote(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.list(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.html(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.def(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "paragraph" || lastToken?.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.raw;
          this.inlineQueue.at(-1).src = lastToken.text;
        } else if (!this.tokens.links[token.tag]) {
          this.tokens.links[token.tag] = {
            href: token.href,
            title: token.title
          };
        }
        continue;
      }
      if (token = this.tokenizer.table(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.lheading(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      let cutSrc = src;
      if (this.options.extensions?.startBlock) {
        let startIndex = Infinity;
        const tempSrc = src.slice(1);
        let tempStart;
        this.options.extensions.startBlock.forEach((getStartIndex) => {
          tempStart = getStartIndex.call({ lexer: this }, tempSrc);
          if (typeof tempStart === "number" && tempStart >= 0) {
            startIndex = Math.min(startIndex, tempStart);
          }
        });
        if (startIndex < Infinity && startIndex >= 0) {
          cutSrc = src.substring(0, startIndex + 1);
        }
      }
      if (this.state.top && (token = this.tokenizer.paragraph(cutSrc))) {
        const lastToken = tokens.at(-1);
        if (lastParagraphClipped && lastToken?.type === "paragraph") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.pop();
          this.inlineQueue.at(-1).src = lastToken.text;
        } else {
          tokens.push(token);
        }
        lastParagraphClipped = cutSrc.length !== src.length;
        src = src.substring(token.raw.length);
        continue;
      }
      if (token = this.tokenizer.text(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.pop();
          this.inlineQueue.at(-1).src = lastToken.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (src) {
        const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
        if (this.options.silent) {
          console.error(errMsg);
          break;
        } else {
          throw new Error(errMsg);
        }
      }
    }
    this.state.top = true;
    return tokens;
  }
  inline(src, tokens = []) {
    this.inlineQueue.push({ src, tokens });
    return tokens;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(src, tokens = []) {
    let maskedSrc = src;
    let match = null;
    if (this.tokens.links) {
      const links = Object.keys(this.tokens.links);
      if (links.length > 0) {
        while ((match = this.tokenizer.rules.inline.reflinkSearch.exec(maskedSrc)) != null) {
          if (links.includes(match[0].slice(match[0].lastIndexOf("[") + 1, -1))) {
            maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex);
          }
        }
      }
    }
    while ((match = this.tokenizer.rules.inline.anyPunctuation.exec(maskedSrc)) != null) {
      maskedSrc = maskedSrc.slice(0, match.index) + "++" + maskedSrc.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    }
    while ((match = this.tokenizer.rules.inline.blockSkip.exec(maskedSrc)) != null) {
      maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    }
    let keepPrevChar = false;
    let prevChar = "";
    while (src) {
      if (!keepPrevChar) {
        prevChar = "";
      }
      keepPrevChar = false;
      let token;
      if (this.options.extensions?.inline?.some((extTokenizer) => {
        if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          return true;
        }
        return false;
      })) {
        continue;
      }
      if (token = this.tokenizer.escape(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.tag(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.link(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.reflink(src, this.tokens.links)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (token.type === "text" && lastToken?.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.emStrong(src, maskedSrc, prevChar)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.codespan(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.br(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.del(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.autolink(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (!this.state.inLink && (token = this.tokenizer.url(src))) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      let cutSrc = src;
      if (this.options.extensions?.startInline) {
        let startIndex = Infinity;
        const tempSrc = src.slice(1);
        let tempStart;
        this.options.extensions.startInline.forEach((getStartIndex) => {
          tempStart = getStartIndex.call({ lexer: this }, tempSrc);
          if (typeof tempStart === "number" && tempStart >= 0) {
            startIndex = Math.min(startIndex, tempStart);
          }
        });
        if (startIndex < Infinity && startIndex >= 0) {
          cutSrc = src.substring(0, startIndex + 1);
        }
      }
      if (token = this.tokenizer.inlineText(cutSrc)) {
        src = src.substring(token.raw.length);
        if (token.raw.slice(-1) !== "_") {
          prevChar = token.raw.slice(-1);
        }
        keepPrevChar = true;
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (src) {
        const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
        if (this.options.silent) {
          console.error(errMsg);
          break;
        } else {
          throw new Error(errMsg);
        }
      }
    }
    return tokens;
  }
};
var _Renderer = class {
  options;
  parser;
  // set by the parser
  constructor(options22) {
    this.options = options22 || _defaults;
  }
  space(token) {
    return "";
  }
  code({ text, lang, escaped }) {
    const langString = (lang || "").match(other.notSpaceStart)?.[0];
    const code = text.replace(other.endingNewline, "") + "\n";
    if (!langString) {
      return "<pre><code>" + (escaped ? code : escape2(code, true)) + "</code></pre>\n";
    }
    return '<pre><code class="language-' + escape2(langString) + '">' + (escaped ? code : escape2(code, true)) + "</code></pre>\n";
  }
  blockquote({ tokens }) {
    const body = this.parser.parse(tokens);
    return `<blockquote>
${body}</blockquote>
`;
  }
  html({ text }) {
    return text;
  }
  heading({ tokens, depth }) {
    return `<h${depth}>${this.parser.parseInline(tokens)}</h${depth}>
`;
  }
  hr(token) {
    return "<hr>\n";
  }
  list(token) {
    const ordered = token.ordered;
    const start = token.start;
    let body = "";
    for (let j = 0; j < token.items.length; j++) {
      const item = token.items[j];
      body += this.listitem(item);
    }
    const type = ordered ? "ol" : "ul";
    const startAttr = ordered && start !== 1 ? ' start="' + start + '"' : "";
    return "<" + type + startAttr + ">\n" + body + "</" + type + ">\n";
  }
  listitem(item) {
    let itemBody = "";
    if (item.task) {
      const checkbox = this.checkbox({ checked: !!item.checked });
      if (item.loose) {
        if (item.tokens[0]?.type === "paragraph") {
          item.tokens[0].text = checkbox + " " + item.tokens[0].text;
          if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === "text") {
            item.tokens[0].tokens[0].text = checkbox + " " + escape2(item.tokens[0].tokens[0].text);
            item.tokens[0].tokens[0].escaped = true;
          }
        } else {
          item.tokens.unshift({
            type: "text",
            raw: checkbox + " ",
            text: checkbox + " ",
            escaped: true
          });
        }
      } else {
        itemBody += checkbox + " ";
      }
    }
    itemBody += this.parser.parse(item.tokens, !!item.loose);
    return `<li>${itemBody}</li>
`;
  }
  checkbox({ checked }) {
    return "<input " + (checked ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens }) {
    return `<p>${this.parser.parseInline(tokens)}</p>
`;
  }
  table(token) {
    let header = "";
    let cell = "";
    for (let j = 0; j < token.header.length; j++) {
      cell += this.tablecell(token.header[j]);
    }
    header += this.tablerow({ text: cell });
    let body = "";
    for (let j = 0; j < token.rows.length; j++) {
      const row = token.rows[j];
      cell = "";
      for (let k = 0; k < row.length; k++) {
        cell += this.tablecell(row[k]);
      }
      body += this.tablerow({ text: cell });
    }
    if (body) body = `<tbody>${body}</tbody>`;
    return "<table>\n<thead>\n" + header + "</thead>\n" + body + "</table>\n";
  }
  tablerow({ text }) {
    return `<tr>
${text}</tr>
`;
  }
  tablecell(token) {
    const content = this.parser.parseInline(token.tokens);
    const type = token.header ? "th" : "td";
    const tag2 = token.align ? `<${type} align="${token.align}">` : `<${type}>`;
    return tag2 + content + `</${type}>
`;
  }
  /**
   * span level renderer
   */
  strong({ tokens }) {
    return `<strong>${this.parser.parseInline(tokens)}</strong>`;
  }
  em({ tokens }) {
    return `<em>${this.parser.parseInline(tokens)}</em>`;
  }
  codespan({ text }) {
    return `<code>${escape2(text, true)}</code>`;
  }
  br(token) {
    return "<br>";
  }
  del({ tokens }) {
    return `<del>${this.parser.parseInline(tokens)}</del>`;
  }
  link({ href, title, tokens }) {
    const text = this.parser.parseInline(tokens);
    const cleanHref = cleanUrl(href);
    if (cleanHref === null) {
      return text;
    }
    href = cleanHref;
    let out = '<a href="' + href + '"';
    if (title) {
      out += ' title="' + escape2(title) + '"';
    }
    out += ">" + text + "</a>";
    return out;
  }
  image({ href, title, text, tokens }) {
    if (tokens) {
      text = this.parser.parseInline(tokens, this.parser.textRenderer);
    }
    const cleanHref = cleanUrl(href);
    if (cleanHref === null) {
      return escape2(text);
    }
    href = cleanHref;
    let out = `<img src="${href}" alt="${text}"`;
    if (title) {
      out += ` title="${escape2(title)}"`;
    }
    out += ">";
    return out;
  }
  text(token) {
    return "tokens" in token && token.tokens ? this.parser.parseInline(token.tokens) : "escaped" in token && token.escaped ? token.text : escape2(token.text);
  }
};
var _TextRenderer = class {
  // no need for block level renderers
  strong({ text }) {
    return text;
  }
  em({ text }) {
    return text;
  }
  codespan({ text }) {
    return text;
  }
  del({ text }) {
    return text;
  }
  html({ text }) {
    return text;
  }
  text({ text }) {
    return text;
  }
  link({ text }) {
    return "" + text;
  }
  image({ text }) {
    return "" + text;
  }
  br() {
    return "";
  }
};
var _Parser = class __Parser {
  options;
  renderer;
  textRenderer;
  constructor(options22) {
    this.options = options22 || _defaults;
    this.options.renderer = this.options.renderer || new _Renderer();
    this.renderer = this.options.renderer;
    this.renderer.options = this.options;
    this.renderer.parser = this;
    this.textRenderer = new _TextRenderer();
  }
  /**
   * Static Parse Method
   */
  static parse(tokens, options22) {
    const parser2 = new __Parser(options22);
    return parser2.parse(tokens);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(tokens, options22) {
    const parser2 = new __Parser(options22);
    return parser2.parseInline(tokens);
  }
  /**
   * Parse Loop
   */
  parse(tokens, top = true) {
    let out = "";
    for (let i = 0; i < tokens.length; i++) {
      const anyToken = tokens[i];
      if (this.options.extensions?.renderers?.[anyToken.type]) {
        const genericToken = anyToken;
        const ret = this.options.extensions.renderers[genericToken.type].call({ parser: this }, genericToken);
        if (ret !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(genericToken.type)) {
          out += ret || "";
          continue;
        }
      }
      const token = anyToken;
      switch (token.type) {
        case "space": {
          out += this.renderer.space(token);
          continue;
        }
        case "hr": {
          out += this.renderer.hr(token);
          continue;
        }
        case "heading": {
          out += this.renderer.heading(token);
          continue;
        }
        case "code": {
          out += this.renderer.code(token);
          continue;
        }
        case "table": {
          out += this.renderer.table(token);
          continue;
        }
        case "blockquote": {
          out += this.renderer.blockquote(token);
          continue;
        }
        case "list": {
          out += this.renderer.list(token);
          continue;
        }
        case "html": {
          out += this.renderer.html(token);
          continue;
        }
        case "paragraph": {
          out += this.renderer.paragraph(token);
          continue;
        }
        case "text": {
          let textToken = token;
          let body = this.renderer.text(textToken);
          while (i + 1 < tokens.length && tokens[i + 1].type === "text") {
            textToken = tokens[++i];
            body += "\n" + this.renderer.text(textToken);
          }
          if (top) {
            out += this.renderer.paragraph({
              type: "paragraph",
              raw: body,
              text: body,
              tokens: [{ type: "text", raw: body, text: body, escaped: true }]
            });
          } else {
            out += body;
          }
          continue;
        }
        default: {
          const errMsg = 'Token with "' + token.type + '" type was not found.';
          if (this.options.silent) {
            console.error(errMsg);
            return "";
          } else {
            throw new Error(errMsg);
          }
        }
      }
    }
    return out;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(tokens, renderer = this.renderer) {
    let out = "";
    for (let i = 0; i < tokens.length; i++) {
      const anyToken = tokens[i];
      if (this.options.extensions?.renderers?.[anyToken.type]) {
        const ret = this.options.extensions.renderers[anyToken.type].call({ parser: this }, anyToken);
        if (ret !== false || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(anyToken.type)) {
          out += ret || "";
          continue;
        }
      }
      const token = anyToken;
      switch (token.type) {
        case "escape": {
          out += renderer.text(token);
          break;
        }
        case "html": {
          out += renderer.html(token);
          break;
        }
        case "link": {
          out += renderer.link(token);
          break;
        }
        case "image": {
          out += renderer.image(token);
          break;
        }
        case "strong": {
          out += renderer.strong(token);
          break;
        }
        case "em": {
          out += renderer.em(token);
          break;
        }
        case "codespan": {
          out += renderer.codespan(token);
          break;
        }
        case "br": {
          out += renderer.br(token);
          break;
        }
        case "del": {
          out += renderer.del(token);
          break;
        }
        case "text": {
          out += renderer.text(token);
          break;
        }
        default: {
          const errMsg = 'Token with "' + token.type + '" type was not found.';
          if (this.options.silent) {
            console.error(errMsg);
            return "";
          } else {
            throw new Error(errMsg);
          }
        }
      }
    }
    return out;
  }
};
var _Hooks = class {
  options;
  block;
  constructor(options22) {
    this.options = options22 || _defaults;
  }
  static passThroughHooks = /* @__PURE__ */ new Set([
    "preprocess",
    "postprocess",
    "processAllTokens"
  ]);
  /**
   * Process markdown before marked
   */
  preprocess(markdown) {
    return markdown;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(html2) {
    return html2;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(tokens) {
    return tokens;
  }
  /**
   * Provide function to tokenize markdown
   */
  provideLexer() {
    return this.block ? _Lexer.lex : _Lexer.lexInline;
  }
  /**
   * Provide function to parse tokens
   */
  provideParser() {
    return this.block ? _Parser.parse : _Parser.parseInline;
  }
};
var Marked = class {
  defaults = _getDefaults();
  options = this.setOptions;
  parse = this.parseMarkdown(true);
  parseInline = this.parseMarkdown(false);
  Parser = _Parser;
  Renderer = _Renderer;
  TextRenderer = _TextRenderer;
  Lexer = _Lexer;
  Tokenizer = _Tokenizer;
  Hooks = _Hooks;
  constructor(...args) {
    this.use(...args);
  }
  /**
   * Run callback for every token
   */
  walkTokens(tokens, callback) {
    let values = [];
    for (const token of tokens) {
      values = values.concat(callback.call(this, token));
      switch (token.type) {
        case "table": {
          const tableToken = token;
          for (const cell of tableToken.header) {
            values = values.concat(this.walkTokens(cell.tokens, callback));
          }
          for (const row of tableToken.rows) {
            for (const cell of row) {
              values = values.concat(this.walkTokens(cell.tokens, callback));
            }
          }
          break;
        }
        case "list": {
          const listToken = token;
          values = values.concat(this.walkTokens(listToken.items, callback));
          break;
        }
        default: {
          const genericToken = token;
          if (this.defaults.extensions?.childTokens?.[genericToken.type]) {
            this.defaults.extensions.childTokens[genericToken.type].forEach((childTokens) => {
              const tokens2 = genericToken[childTokens].flat(Infinity);
              values = values.concat(this.walkTokens(tokens2, callback));
            });
          } else if (genericToken.tokens) {
            values = values.concat(this.walkTokens(genericToken.tokens, callback));
          }
        }
      }
    }
    return values;
  }
  use(...args) {
    const extensions = this.defaults.extensions || { renderers: {}, childTokens: {} };
    args.forEach((pack) => {
      const opts = { ...pack };
      opts.async = this.defaults.async || opts.async || false;
      if (pack.extensions) {
        pack.extensions.forEach((ext) => {
          if (!ext.name) {
            throw new Error("extension name required");
          }
          if ("renderer" in ext) {
            const prevRenderer = extensions.renderers[ext.name];
            if (prevRenderer) {
              extensions.renderers[ext.name] = function(...args2) {
                let ret = ext.renderer.apply(this, args2);
                if (ret === false) {
                  ret = prevRenderer.apply(this, args2);
                }
                return ret;
              };
            } else {
              extensions.renderers[ext.name] = ext.renderer;
            }
          }
          if ("tokenizer" in ext) {
            if (!ext.level || ext.level !== "block" && ext.level !== "inline") {
              throw new Error("extension level must be 'block' or 'inline'");
            }
            const extLevel = extensions[ext.level];
            if (extLevel) {
              extLevel.unshift(ext.tokenizer);
            } else {
              extensions[ext.level] = [ext.tokenizer];
            }
            if (ext.start) {
              if (ext.level === "block") {
                if (extensions.startBlock) {
                  extensions.startBlock.push(ext.start);
                } else {
                  extensions.startBlock = [ext.start];
                }
              } else if (ext.level === "inline") {
                if (extensions.startInline) {
                  extensions.startInline.push(ext.start);
                } else {
                  extensions.startInline = [ext.start];
                }
              }
            }
          }
          if ("childTokens" in ext && ext.childTokens) {
            extensions.childTokens[ext.name] = ext.childTokens;
          }
        });
        opts.extensions = extensions;
      }
      if (pack.renderer) {
        const renderer = this.defaults.renderer || new _Renderer(this.defaults);
        for (const prop in pack.renderer) {
          if (!(prop in renderer)) {
            throw new Error(`renderer '${prop}' does not exist`);
          }
          if (["options", "parser"].includes(prop)) {
            continue;
          }
          const rendererProp = prop;
          const rendererFunc = pack.renderer[rendererProp];
          const prevRenderer = renderer[rendererProp];
          renderer[rendererProp] = (...args2) => {
            let ret = rendererFunc.apply(renderer, args2);
            if (ret === false) {
              ret = prevRenderer.apply(renderer, args2);
            }
            return ret || "";
          };
        }
        opts.renderer = renderer;
      }
      if (pack.tokenizer) {
        const tokenizer = this.defaults.tokenizer || new _Tokenizer(this.defaults);
        for (const prop in pack.tokenizer) {
          if (!(prop in tokenizer)) {
            throw new Error(`tokenizer '${prop}' does not exist`);
          }
          if (["options", "rules", "lexer"].includes(prop)) {
            continue;
          }
          const tokenizerProp = prop;
          const tokenizerFunc = pack.tokenizer[tokenizerProp];
          const prevTokenizer = tokenizer[tokenizerProp];
          tokenizer[tokenizerProp] = (...args2) => {
            let ret = tokenizerFunc.apply(tokenizer, args2);
            if (ret === false) {
              ret = prevTokenizer.apply(tokenizer, args2);
            }
            return ret;
          };
        }
        opts.tokenizer = tokenizer;
      }
      if (pack.hooks) {
        const hooks = this.defaults.hooks || new _Hooks();
        for (const prop in pack.hooks) {
          if (!(prop in hooks)) {
            throw new Error(`hook '${prop}' does not exist`);
          }
          if (["options", "block"].includes(prop)) {
            continue;
          }
          const hooksProp = prop;
          const hooksFunc = pack.hooks[hooksProp];
          const prevHook = hooks[hooksProp];
          if (_Hooks.passThroughHooks.has(prop)) {
            hooks[hooksProp] = (arg) => {
              if (this.defaults.async) {
                return Promise.resolve(hooksFunc.call(hooks, arg)).then((ret2) => {
                  return prevHook.call(hooks, ret2);
                });
              }
              const ret = hooksFunc.call(hooks, arg);
              return prevHook.call(hooks, ret);
            };
          } else {
            hooks[hooksProp] = (...args2) => {
              let ret = hooksFunc.apply(hooks, args2);
              if (ret === false) {
                ret = prevHook.apply(hooks, args2);
              }
              return ret;
            };
          }
        }
        opts.hooks = hooks;
      }
      if (pack.walkTokens) {
        const walkTokens2 = this.defaults.walkTokens;
        const packWalktokens = pack.walkTokens;
        opts.walkTokens = function(token) {
          let values = [];
          values.push(packWalktokens.call(this, token));
          if (walkTokens2) {
            values = values.concat(walkTokens2.call(this, token));
          }
          return values;
        };
      }
      this.defaults = { ...this.defaults, ...opts };
    });
    return this;
  }
  setOptions(opt) {
    this.defaults = { ...this.defaults, ...opt };
    return this;
  }
  lexer(src, options22) {
    return _Lexer.lex(src, options22 ?? this.defaults);
  }
  parser(tokens, options22) {
    return _Parser.parse(tokens, options22 ?? this.defaults);
  }
  parseMarkdown(blockType) {
    const parse2 = (src, options22) => {
      const origOpt = { ...options22 };
      const opt = { ...this.defaults, ...origOpt };
      const throwError = this.onError(!!opt.silent, !!opt.async);
      if (this.defaults.async === true && origOpt.async === false) {
        return throwError(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      }
      if (typeof src === "undefined" || src === null) {
        return throwError(new Error("marked(): input parameter is undefined or null"));
      }
      if (typeof src !== "string") {
        return throwError(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(src) + ", string expected"));
      }
      if (opt.hooks) {
        opt.hooks.options = opt;
        opt.hooks.block = blockType;
      }
      const lexer2 = opt.hooks ? opt.hooks.provideLexer() : blockType ? _Lexer.lex : _Lexer.lexInline;
      const parser2 = opt.hooks ? opt.hooks.provideParser() : blockType ? _Parser.parse : _Parser.parseInline;
      if (opt.async) {
        return Promise.resolve(opt.hooks ? opt.hooks.preprocess(src) : src).then((src2) => lexer2(src2, opt)).then((tokens) => opt.hooks ? opt.hooks.processAllTokens(tokens) : tokens).then((tokens) => opt.walkTokens ? Promise.all(this.walkTokens(tokens, opt.walkTokens)).then(() => tokens) : tokens).then((tokens) => parser2(tokens, opt)).then((html2) => opt.hooks ? opt.hooks.postprocess(html2) : html2).catch(throwError);
      }
      try {
        if (opt.hooks) {
          src = opt.hooks.preprocess(src);
        }
        let tokens = lexer2(src, opt);
        if (opt.hooks) {
          tokens = opt.hooks.processAllTokens(tokens);
        }
        if (opt.walkTokens) {
          this.walkTokens(tokens, opt.walkTokens);
        }
        let html2 = parser2(tokens, opt);
        if (opt.hooks) {
          html2 = opt.hooks.postprocess(html2);
        }
        return html2;
      } catch (e) {
        return throwError(e);
      }
    };
    return parse2;
  }
  onError(silent, async) {
    return (e) => {
      e.message += "\nPlease report this to https://github.com/markedjs/marked.";
      if (silent) {
        const msg = "<p>An error occurred:</p><pre>" + escape2(e.message + "", true) + "</pre>";
        if (async) {
          return Promise.resolve(msg);
        }
        return msg;
      }
      if (async) {
        return Promise.reject(e);
      }
      throw e;
    };
  }
};
var markedInstance = new Marked();
function marked(src, opt) {
  return markedInstance.parse(src, opt);
}
marked.options = marked.setOptions = function(options22) {
  markedInstance.setOptions(options22);
  marked.defaults = markedInstance.defaults;
  changeDefaults(marked.defaults);
  return marked;
};
marked.getDefaults = _getDefaults;
marked.defaults = _defaults;
marked.use = function(...args) {
  markedInstance.use(...args);
  marked.defaults = markedInstance.defaults;
  changeDefaults(marked.defaults);
  return marked;
};
marked.walkTokens = function(tokens, callback) {
  return markedInstance.walkTokens(tokens, callback);
};
marked.parseInline = markedInstance.parseInline;
marked.Parser = _Parser;
marked.parser = _Parser.parse;
marked.Renderer = _Renderer;
marked.TextRenderer = _TextRenderer;
marked.Lexer = _Lexer;
marked.lexer = _Lexer.lex;
marked.Tokenizer = _Tokenizer;
marked.Hooks = _Hooks;
marked.parse = marked;
var options = marked.options;
var setOptions = marked.setOptions;
var use = marked.use;
var walkTokens = marked.walkTokens;
var parseInline = marked.parseInline;
var parser = _Parser.parse;
var lexer = _Lexer.lex;

// node_modules/@mariozechner/pi-tui/dist/components/markdown.js
var Markdown = class {
  text;
  paddingX;
  // Left/right padding
  paddingY;
  // Top/bottom padding
  defaultTextStyle;
  theme;
  defaultStylePrefix;
  // Cache for rendered output
  cachedText;
  cachedWidth;
  cachedLines;
  constructor(text, paddingX, paddingY, theme, defaultTextStyle) {
    this.text = text;
    this.paddingX = paddingX;
    this.paddingY = paddingY;
    this.theme = theme;
    this.defaultTextStyle = defaultTextStyle;
  }
  setText(text) {
    this.text = text;
    this.invalidate();
  }
  invalidate() {
    this.cachedText = void 0;
    this.cachedWidth = void 0;
    this.cachedLines = void 0;
  }
  render(width) {
    if (this.cachedLines && this.cachedText === this.text && this.cachedWidth === width) {
      return this.cachedLines;
    }
    const contentWidth = Math.max(1, width - this.paddingX * 2);
    if (!this.text || this.text.trim() === "") {
      const result2 = [];
      this.cachedText = this.text;
      this.cachedWidth = width;
      this.cachedLines = result2;
      return result2;
    }
    const normalizedText = this.text.replace(/\t/g, "   ");
    const tokens = marked.lexer(normalizedText);
    const renderedLines = [];
    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i];
      const nextToken = tokens[i + 1];
      const tokenLines = this.renderToken(token, contentWidth, nextToken?.type);
      renderedLines.push(...tokenLines);
    }
    const wrappedLines = [];
    for (const line of renderedLines) {
      wrappedLines.push(...wrapTextWithAnsi(line, contentWidth));
    }
    const leftMargin = " ".repeat(this.paddingX);
    const rightMargin = " ".repeat(this.paddingX);
    const bgFn = this.defaultTextStyle?.bgColor;
    const contentLines = [];
    for (const line of wrappedLines) {
      const lineWithMargins = leftMargin + line + rightMargin;
      if (bgFn) {
        contentLines.push(applyBackgroundToLine(lineWithMargins, width, bgFn));
      } else {
        const visibleLen = visibleWidth(lineWithMargins);
        const paddingNeeded = Math.max(0, width - visibleLen);
        contentLines.push(lineWithMargins + " ".repeat(paddingNeeded));
      }
    }
    const emptyLine = " ".repeat(width);
    const emptyLines = [];
    for (let i = 0; i < this.paddingY; i++) {
      const line = bgFn ? applyBackgroundToLine(emptyLine, width, bgFn) : emptyLine;
      emptyLines.push(line);
    }
    const result = [...emptyLines, ...contentLines, ...emptyLines];
    this.cachedText = this.text;
    this.cachedWidth = width;
    this.cachedLines = result;
    return result.length > 0 ? result : [""];
  }
  /**
   * Apply default text style to a string.
   * This is the base styling applied to all text content.
   * NOTE: Background color is NOT applied here - it's applied at the padding stage
   * to ensure it extends to the full line width.
   */
  applyDefaultStyle(text) {
    if (!this.defaultTextStyle) {
      return text;
    }
    let styled = text;
    if (this.defaultTextStyle.color) {
      styled = this.defaultTextStyle.color(styled);
    }
    if (this.defaultTextStyle.bold) {
      styled = this.theme.bold(styled);
    }
    if (this.defaultTextStyle.italic) {
      styled = this.theme.italic(styled);
    }
    if (this.defaultTextStyle.strikethrough) {
      styled = this.theme.strikethrough(styled);
    }
    if (this.defaultTextStyle.underline) {
      styled = this.theme.underline(styled);
    }
    return styled;
  }
  getDefaultStylePrefix() {
    if (!this.defaultTextStyle) {
      return "";
    }
    if (this.defaultStylePrefix !== void 0) {
      return this.defaultStylePrefix;
    }
    const sentinel = "\0";
    let styled = sentinel;
    if (this.defaultTextStyle.color) {
      styled = this.defaultTextStyle.color(styled);
    }
    if (this.defaultTextStyle.bold) {
      styled = this.theme.bold(styled);
    }
    if (this.defaultTextStyle.italic) {
      styled = this.theme.italic(styled);
    }
    if (this.defaultTextStyle.strikethrough) {
      styled = this.theme.strikethrough(styled);
    }
    if (this.defaultTextStyle.underline) {
      styled = this.theme.underline(styled);
    }
    const sentinelIndex = styled.indexOf(sentinel);
    this.defaultStylePrefix = sentinelIndex >= 0 ? styled.slice(0, sentinelIndex) : "";
    return this.defaultStylePrefix;
  }
  renderToken(token, width, nextTokenType) {
    const lines = [];
    switch (token.type) {
      case "heading": {
        const headingLevel = token.depth;
        const headingPrefix = `${"#".repeat(headingLevel)} `;
        const headingText = this.renderInlineTokens(token.tokens || []);
        let styledHeading;
        if (headingLevel === 1) {
          styledHeading = this.theme.heading(this.theme.bold(this.theme.underline(headingText)));
        } else if (headingLevel === 2) {
          styledHeading = this.theme.heading(this.theme.bold(headingText));
        } else {
          styledHeading = this.theme.heading(this.theme.bold(headingPrefix + headingText));
        }
        lines.push(styledHeading);
        if (nextTokenType !== "space") {
          lines.push("");
        }
        break;
      }
      case "paragraph": {
        const paragraphText = this.renderInlineTokens(token.tokens || []);
        lines.push(paragraphText);
        if (nextTokenType && nextTokenType !== "list" && nextTokenType !== "space") {
          lines.push("");
        }
        break;
      }
      case "code": {
        const indent = this.theme.codeBlockIndent ?? "  ";
        lines.push(this.theme.codeBlockBorder(`\`\`\`${token.lang || ""}`));
        if (this.theme.highlightCode) {
          const highlightedLines = this.theme.highlightCode(token.text, token.lang);
          for (const hlLine of highlightedLines) {
            lines.push(`${indent}${hlLine}`);
          }
        } else {
          const codeLines = token.text.split("\n");
          for (const codeLine of codeLines) {
            lines.push(`${indent}${this.theme.codeBlock(codeLine)}`);
          }
        }
        lines.push(this.theme.codeBlockBorder("```"));
        if (nextTokenType !== "space") {
          lines.push("");
        }
        break;
      }
      case "list": {
        const listLines = this.renderList(token, 0);
        lines.push(...listLines);
        break;
      }
      case "table": {
        const tableLines = this.renderTable(token, width);
        lines.push(...tableLines);
        break;
      }
      case "blockquote": {
        const quoteText = this.renderInlineTokens(token.tokens || []);
        const quoteLines = quoteText.split("\n");
        for (const quoteLine of quoteLines) {
          lines.push(this.theme.quoteBorder("\u2502 ") + this.theme.quote(this.theme.italic(quoteLine)));
        }
        if (nextTokenType !== "space") {
          lines.push("");
        }
        break;
      }
      case "hr":
        lines.push(this.theme.hr("\u2500".repeat(Math.min(width, 80))));
        if (nextTokenType !== "space") {
          lines.push("");
        }
        break;
      case "html":
        if ("raw" in token && typeof token.raw === "string") {
          lines.push(this.applyDefaultStyle(token.raw.trim()));
        }
        break;
      case "space":
        lines.push("");
        break;
      default:
        if ("text" in token && typeof token.text === "string") {
          lines.push(token.text);
        }
    }
    return lines;
  }
  renderInlineTokens(tokens) {
    let result = "";
    for (const token of tokens) {
      switch (token.type) {
        case "text":
          if (token.tokens && token.tokens.length > 0) {
            result += this.renderInlineTokens(token.tokens);
          } else {
            result += this.applyDefaultStyle(token.text);
          }
          break;
        case "strong": {
          const boldContent = this.renderInlineTokens(token.tokens || []);
          result += this.theme.bold(boldContent) + this.getDefaultStylePrefix();
          break;
        }
        case "em": {
          const italicContent = this.renderInlineTokens(token.tokens || []);
          result += this.theme.italic(italicContent) + this.getDefaultStylePrefix();
          break;
        }
        case "codespan":
          result += this.theme.code(token.text) + this.getDefaultStylePrefix();
          break;
        case "link": {
          const linkText = this.renderInlineTokens(token.tokens || []);
          const hrefForComparison = token.href.startsWith("mailto:") ? token.href.slice(7) : token.href;
          if (token.text === token.href || token.text === hrefForComparison) {
            result += this.theme.link(this.theme.underline(linkText)) + this.getDefaultStylePrefix();
          } else {
            result += this.theme.link(this.theme.underline(linkText)) + this.theme.linkUrl(` (${token.href})`) + this.getDefaultStylePrefix();
          }
          break;
        }
        case "br":
          result += "\n";
          break;
        case "del": {
          const delContent = this.renderInlineTokens(token.tokens || []);
          result += this.theme.strikethrough(delContent) + this.getDefaultStylePrefix();
          break;
        }
        case "html":
          if ("raw" in token && typeof token.raw === "string") {
            result += this.applyDefaultStyle(token.raw);
          }
          break;
        default:
          if ("text" in token && typeof token.text === "string") {
            result += this.applyDefaultStyle(token.text);
          }
      }
    }
    return result;
  }
  /**
   * Render a list with proper nesting support
   */
  renderList(token, depth) {
    const lines = [];
    const indent = "  ".repeat(depth);
    const startNumber = token.start ?? 1;
    for (let i = 0; i < token.items.length; i++) {
      const item = token.items[i];
      const bullet2 = token.ordered ? `${startNumber + i}. ` : "- ";
      const itemLines = this.renderListItem(item.tokens || [], depth);
      if (itemLines.length > 0) {
        const firstLine = itemLines[0];
        const isNestedList = /^\s+\x1b\[36m[-\d]/.test(firstLine);
        if (isNestedList) {
          lines.push(firstLine);
        } else {
          lines.push(indent + this.theme.listBullet(bullet2) + firstLine);
        }
        for (let j = 1; j < itemLines.length; j++) {
          const line = itemLines[j];
          const isNestedListLine = /^\s+\x1b\[36m[-\d]/.test(line);
          if (isNestedListLine) {
            lines.push(line);
          } else {
            lines.push(`${indent}  ${line}`);
          }
        }
      } else {
        lines.push(indent + this.theme.listBullet(bullet2));
      }
    }
    return lines;
  }
  /**
   * Render list item tokens, handling nested lists
   * Returns lines WITHOUT the parent indent (renderList will add it)
   */
  renderListItem(tokens, parentDepth) {
    const lines = [];
    for (const token of tokens) {
      if (token.type === "list") {
        const nestedLines = this.renderList(token, parentDepth + 1);
        lines.push(...nestedLines);
      } else if (token.type === "text") {
        const text = token.tokens && token.tokens.length > 0 ? this.renderInlineTokens(token.tokens) : token.text || "";
        lines.push(text);
      } else if (token.type === "paragraph") {
        const text = this.renderInlineTokens(token.tokens || []);
        lines.push(text);
      } else if (token.type === "code") {
        const indent = this.theme.codeBlockIndent ?? "  ";
        lines.push(this.theme.codeBlockBorder(`\`\`\`${token.lang || ""}`));
        if (this.theme.highlightCode) {
          const highlightedLines = this.theme.highlightCode(token.text, token.lang);
          for (const hlLine of highlightedLines) {
            lines.push(`${indent}${hlLine}`);
          }
        } else {
          const codeLines = token.text.split("\n");
          for (const codeLine of codeLines) {
            lines.push(`${indent}${this.theme.codeBlock(codeLine)}`);
          }
        }
        lines.push(this.theme.codeBlockBorder("```"));
      } else {
        const text = this.renderInlineTokens([token]);
        if (text) {
          lines.push(text);
        }
      }
    }
    return lines;
  }
  /**
   * Wrap a table cell to fit into a column.
   *
   * Delegates to wrapTextWithAnsi() so ANSI codes + long tokens are handled
   * consistently with the rest of the renderer.
   */
  wrapCellText(text, maxWidth) {
    return wrapTextWithAnsi(text, Math.max(1, maxWidth));
  }
  /**
   * Render a table with width-aware cell wrapping.
   * Cells that don't fit are wrapped to multiple lines.
   */
  renderTable(token, availableWidth) {
    const lines = [];
    const numCols = token.header.length;
    if (numCols === 0) {
      return lines;
    }
    const borderOverhead = 3 * numCols + 1;
    const minTableWidth = borderOverhead + numCols;
    if (availableWidth < minTableWidth) {
      const fallbackLines = token.raw ? wrapTextWithAnsi(token.raw, availableWidth) : [];
      fallbackLines.push("");
      return fallbackLines;
    }
    const naturalWidths = [];
    for (let i = 0; i < numCols; i++) {
      const headerText = this.renderInlineTokens(token.header[i].tokens || []);
      naturalWidths[i] = visibleWidth(headerText);
    }
    for (const row of token.rows) {
      for (let i = 0; i < row.length; i++) {
        const cellText = this.renderInlineTokens(row[i].tokens || []);
        naturalWidths[i] = Math.max(naturalWidths[i] || 0, visibleWidth(cellText));
      }
    }
    const totalNaturalWidth = naturalWidths.reduce((a, b) => a + b, 0) + borderOverhead;
    let columnWidths;
    if (totalNaturalWidth <= availableWidth) {
      columnWidths = naturalWidths;
    } else {
      const availableForCells = availableWidth - borderOverhead;
      if (availableForCells <= numCols) {
        columnWidths = naturalWidths.map(() => Math.max(1, Math.floor(availableForCells / numCols)));
      } else {
        const totalNatural = naturalWidths.reduce((a, b) => a + b, 0);
        columnWidths = naturalWidths.map((w) => {
          const proportion = w / totalNatural;
          return Math.max(1, Math.floor(proportion * availableForCells));
        });
        const allocated = columnWidths.reduce((a, b) => a + b, 0);
        let remaining = availableForCells - allocated;
        for (let i = 0; remaining > 0 && i < numCols; i++) {
          columnWidths[i]++;
          remaining--;
        }
      }
    }
    const topBorderCells = columnWidths.map((w) => "\u2500".repeat(w));
    lines.push(`\u250C\u2500${topBorderCells.join("\u2500\u252C\u2500")}\u2500\u2510`);
    const headerCellLines = token.header.map((cell, i) => {
      const text = this.renderInlineTokens(cell.tokens || []);
      return this.wrapCellText(text, columnWidths[i]);
    });
    const headerLineCount = Math.max(...headerCellLines.map((c) => c.length));
    for (let lineIdx = 0; lineIdx < headerLineCount; lineIdx++) {
      const rowParts = headerCellLines.map((cellLines, colIdx) => {
        const text = cellLines[lineIdx] || "";
        const padded = text + " ".repeat(Math.max(0, columnWidths[colIdx] - visibleWidth(text)));
        return this.theme.bold(padded);
      });
      lines.push(`\u2502 ${rowParts.join(" \u2502 ")} \u2502`);
    }
    const separatorCells = columnWidths.map((w) => "\u2500".repeat(w));
    lines.push(`\u251C\u2500${separatorCells.join("\u2500\u253C\u2500")}\u2500\u2524`);
    for (const row of token.rows) {
      const rowCellLines = row.map((cell, i) => {
        const text = this.renderInlineTokens(cell.tokens || []);
        return this.wrapCellText(text, columnWidths[i]);
      });
      const rowLineCount = Math.max(...rowCellLines.map((c) => c.length));
      for (let lineIdx = 0; lineIdx < rowLineCount; lineIdx++) {
        const rowParts = rowCellLines.map((cellLines, colIdx) => {
          const text = cellLines[lineIdx] || "";
          return text + " ".repeat(Math.max(0, columnWidths[colIdx] - visibleWidth(text)));
        });
        lines.push(`\u2502 ${rowParts.join(" \u2502 ")} \u2502`);
      }
    }
    const bottomBorderCells = columnWidths.map((w) => "\u2500".repeat(w));
    lines.push(`\u2514\u2500${bottomBorderCells.join("\u2500\u2534\u2500")}\u2500\u2518`);
    lines.push("");
    return lines;
  }
};

// node_modules/@mariozechner/pi-tui/dist/components/spacer.js
var Spacer = class {
  lines;
  constructor(lines = 1) {
    this.lines = lines;
  }
  setLines(lines) {
    this.lines = lines;
  }
  invalidate() {
  }
  render(_width) {
    const result = [];
    for (let i = 0; i < this.lines; i++) {
      result.push("");
    }
    return result;
  }
};

// node_modules/@mariozechner/pi-tui/dist/stdin-buffer.js
import { EventEmitter } from "events";
var ESC = "\x1B";
var BRACKETED_PASTE_START = "\x1B[200~";
var BRACKETED_PASTE_END = "\x1B[201~";
function isCompleteSequence(data) {
  if (!data.startsWith(ESC)) {
    return "not-escape";
  }
  if (data.length === 1) {
    return "incomplete";
  }
  const afterEsc = data.slice(1);
  if (afterEsc.startsWith("[")) {
    if (afterEsc.startsWith("[M")) {
      return data.length >= 6 ? "complete" : "incomplete";
    }
    return isCompleteCsiSequence(data);
  }
  if (afterEsc.startsWith("]")) {
    return isCompleteOscSequence(data);
  }
  if (afterEsc.startsWith("P")) {
    return isCompleteDcsSequence(data);
  }
  if (afterEsc.startsWith("_")) {
    return isCompleteApcSequence(data);
  }
  if (afterEsc.startsWith("O")) {
    return afterEsc.length >= 2 ? "complete" : "incomplete";
  }
  if (afterEsc.length === 1) {
    return "complete";
  }
  return "complete";
}
function isCompleteCsiSequence(data) {
  if (!data.startsWith(`${ESC}[`)) {
    return "complete";
  }
  if (data.length < 3) {
    return "incomplete";
  }
  const payload = data.slice(2);
  const lastChar = payload[payload.length - 1];
  const lastCharCode = lastChar.charCodeAt(0);
  if (lastCharCode >= 64 && lastCharCode <= 126) {
    if (payload.startsWith("<")) {
      const mouseMatch = /^<\d+;\d+;\d+[Mm]$/.test(payload);
      if (mouseMatch) {
        return "complete";
      }
      if (lastChar === "M" || lastChar === "m") {
        const parts = payload.slice(1, -1).split(";");
        if (parts.length === 3 && parts.every((p) => /^\d+$/.test(p))) {
          return "complete";
        }
      }
      return "incomplete";
    }
    return "complete";
  }
  return "incomplete";
}
function isCompleteOscSequence(data) {
  if (!data.startsWith(`${ESC}]`)) {
    return "complete";
  }
  if (data.endsWith(`${ESC}\\`) || data.endsWith("\x07")) {
    return "complete";
  }
  return "incomplete";
}
function isCompleteDcsSequence(data) {
  if (!data.startsWith(`${ESC}P`)) {
    return "complete";
  }
  if (data.endsWith(`${ESC}\\`)) {
    return "complete";
  }
  return "incomplete";
}
function isCompleteApcSequence(data) {
  if (!data.startsWith(`${ESC}_`)) {
    return "complete";
  }
  if (data.endsWith(`${ESC}\\`)) {
    return "complete";
  }
  return "incomplete";
}
function extractCompleteSequences(buffer) {
  const sequences = [];
  let pos = 0;
  while (pos < buffer.length) {
    const remaining = buffer.slice(pos);
    if (remaining.startsWith(ESC)) {
      let seqEnd = 1;
      while (seqEnd <= remaining.length) {
        const candidate = remaining.slice(0, seqEnd);
        const status = isCompleteSequence(candidate);
        if (status === "complete") {
          sequences.push(candidate);
          pos += seqEnd;
          break;
        } else if (status === "incomplete") {
          seqEnd++;
        } else {
          sequences.push(candidate);
          pos += seqEnd;
          break;
        }
      }
      if (seqEnd > remaining.length) {
        return { sequences, remainder: remaining };
      }
    } else {
      sequences.push(remaining[0]);
      pos++;
    }
  }
  return { sequences, remainder: "" };
}
var StdinBuffer = class extends EventEmitter {
  buffer = "";
  timeout = null;
  timeoutMs;
  pasteMode = false;
  pasteBuffer = "";
  constructor(options3 = {}) {
    super();
    this.timeoutMs = options3.timeout ?? 10;
  }
  process(data) {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
    let str;
    if (Buffer.isBuffer(data)) {
      if (data.length === 1 && data[0] > 127) {
        const byte = data[0] - 128;
        str = `\x1B${String.fromCharCode(byte)}`;
      } else {
        str = data.toString();
      }
    } else {
      str = data;
    }
    if (str.length === 0 && this.buffer.length === 0) {
      this.emit("data", "");
      return;
    }
    this.buffer += str;
    if (this.pasteMode) {
      this.pasteBuffer += this.buffer;
      this.buffer = "";
      const endIndex = this.pasteBuffer.indexOf(BRACKETED_PASTE_END);
      if (endIndex !== -1) {
        const pastedContent = this.pasteBuffer.slice(0, endIndex);
        const remaining = this.pasteBuffer.slice(endIndex + BRACKETED_PASTE_END.length);
        this.pasteMode = false;
        this.pasteBuffer = "";
        this.emit("paste", pastedContent);
        if (remaining.length > 0) {
          this.process(remaining);
        }
      }
      return;
    }
    const startIndex = this.buffer.indexOf(BRACKETED_PASTE_START);
    if (startIndex !== -1) {
      if (startIndex > 0) {
        const beforePaste = this.buffer.slice(0, startIndex);
        const result2 = extractCompleteSequences(beforePaste);
        for (const sequence of result2.sequences) {
          this.emit("data", sequence);
        }
      }
      this.buffer = this.buffer.slice(startIndex + BRACKETED_PASTE_START.length);
      this.pasteMode = true;
      this.pasteBuffer = this.buffer;
      this.buffer = "";
      const endIndex = this.pasteBuffer.indexOf(BRACKETED_PASTE_END);
      if (endIndex !== -1) {
        const pastedContent = this.pasteBuffer.slice(0, endIndex);
        const remaining = this.pasteBuffer.slice(endIndex + BRACKETED_PASTE_END.length);
        this.pasteMode = false;
        this.pasteBuffer = "";
        this.emit("paste", pastedContent);
        if (remaining.length > 0) {
          this.process(remaining);
        }
      }
      return;
    }
    const result = extractCompleteSequences(this.buffer);
    this.buffer = result.remainder;
    for (const sequence of result.sequences) {
      this.emit("data", sequence);
    }
    if (this.buffer.length > 0) {
      this.timeout = setTimeout(() => {
        const flushed = this.flush();
        for (const sequence of flushed) {
          this.emit("data", sequence);
        }
      }, this.timeoutMs);
    }
  }
  flush() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
    if (this.buffer.length === 0) {
      return [];
    }
    const sequences = [this.buffer];
    this.buffer = "";
    return sequences;
  }
  clear() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
    this.buffer = "";
    this.pasteMode = false;
    this.pasteBuffer = "";
  }
  getBuffer() {
    return this.buffer;
  }
  destroy() {
    this.clear();
  }
};

// node_modules/@mariozechner/pi-tui/dist/terminal.js
var ProcessTerminal = class {
  wasRaw = false;
  inputHandler;
  resizeHandler;
  _kittyProtocolActive = false;
  stdinBuffer;
  stdinDataHandler;
  get kittyProtocolActive() {
    return this._kittyProtocolActive;
  }
  start(onInput, onResize) {
    this.inputHandler = onInput;
    this.resizeHandler = onResize;
    this.wasRaw = process.stdin.isRaw || false;
    if (process.stdin.setRawMode) {
      process.stdin.setRawMode(true);
    }
    process.stdin.setEncoding("utf8");
    process.stdin.resume();
    process.stdout.write("\x1B[?2004h");
    process.stdout.on("resize", this.resizeHandler);
    if (process.platform !== "win32") {
      process.kill(process.pid, "SIGWINCH");
    }
    this.queryAndEnableKittyProtocol();
  }
  /**
   * Set up StdinBuffer to split batched input into individual sequences.
   * This ensures components receive single events, making matchesKey/isKeyRelease work correctly.
   *
   * Also watches for Kitty protocol response and enables it when detected.
   * This is done here (after stdinBuffer parsing) rather than on raw stdin
   * to handle the case where the response arrives split across multiple events.
   */
  setupStdinBuffer() {
    this.stdinBuffer = new StdinBuffer({ timeout: 10 });
    const kittyResponsePattern = /^\x1b\[\?(\d+)u$/;
    this.stdinBuffer.on("data", (sequence) => {
      if (!this._kittyProtocolActive) {
        const match = sequence.match(kittyResponsePattern);
        if (match) {
          this._kittyProtocolActive = true;
          setKittyProtocolActive(true);
          process.stdout.write("\x1B[>7u");
          return;
        }
      }
      if (this.inputHandler) {
        this.inputHandler(sequence);
      }
    });
    this.stdinBuffer.on("paste", (content) => {
      if (this.inputHandler) {
        this.inputHandler(`\x1B[200~${content}\x1B[201~`);
      }
    });
    this.stdinDataHandler = (data) => {
      this.stdinBuffer.process(data);
    };
  }
  /**
   * Query terminal for Kitty keyboard protocol support and enable if available.
   *
   * Sends CSI ? u to query current flags. If terminal responds with CSI ? <flags> u,
   * it supports the protocol and we enable it with CSI > 1 u.
   *
   * The response is detected in setupStdinBuffer's data handler, which properly
   * handles the case where the response arrives split across multiple stdin events.
   */
  queryAndEnableKittyProtocol() {
    this.setupStdinBuffer();
    process.stdin.on("data", this.stdinDataHandler);
    process.stdout.write("\x1B[?u");
  }
  stop() {
    process.stdout.write("\x1B[?2004l");
    if (this._kittyProtocolActive) {
      process.stdout.write("\x1B[<u");
      this._kittyProtocolActive = false;
      setKittyProtocolActive(false);
    }
    if (this.stdinBuffer) {
      this.stdinBuffer.destroy();
      this.stdinBuffer = void 0;
    }
    if (this.stdinDataHandler) {
      process.stdin.removeListener("data", this.stdinDataHandler);
      this.stdinDataHandler = void 0;
    }
    this.inputHandler = void 0;
    if (this.resizeHandler) {
      process.stdout.removeListener("resize", this.resizeHandler);
      this.resizeHandler = void 0;
    }
    if (process.stdin.setRawMode) {
      process.stdin.setRawMode(this.wasRaw);
    }
  }
  write(data) {
    process.stdout.write(data);
  }
  get columns() {
    return process.stdout.columns || 80;
  }
  get rows() {
    return process.stdout.rows || 24;
  }
  moveBy(lines) {
    if (lines > 0) {
      process.stdout.write(`\x1B[${lines}B`);
    } else if (lines < 0) {
      process.stdout.write(`\x1B[${-lines}A`);
    }
  }
  hideCursor() {
    process.stdout.write("\x1B[?25l");
  }
  showCursor() {
    process.stdout.write("\x1B[?25h");
  }
  clearLine() {
    process.stdout.write("\x1B[K");
  }
  clearFromCursor() {
    process.stdout.write("\x1B[J");
  }
  clearScreen() {
    process.stdout.write("\x1B[2J\x1B[H");
  }
  setTitle(title) {
    process.stdout.write(`\x1B]0;${title}\x07`);
  }
};

// dist/sse-client.js
import { EventEmitter as EventEmitter2 } from "node:events";
var SSEClient = class extends EventEmitter2 {
  baseUrl;
  agentMode;
  agentModel;
  agentType;
  maxIterations;
  abortController = null;
  _isStreaming = false;
  constructor(options3) {
    super();
    this.baseUrl = options3.baseUrl.replace(/\/$/, "");
    this.agentMode = options3.agentMode ?? "code";
    this.agentModel = options3.model ?? "";
    this.agentType = options3.agentType ?? "coding";
    this.maxIterations = options3.maxIterations ?? 100;
  }
  get isStreaming() {
    return this._isStreaming;
  }
  set mode(mode) {
    this.agentMode = mode;
  }
  get mode() {
    return this.agentMode;
  }
  set model(model) {
    this.agentModel = model;
  }
  get model() {
    return this.agentModel;
  }
  async sendMessage(message, sessionId, images) {
    if (this._isStreaming)
      return;
    this.abortController = new AbortController();
    this._isStreaming = true;
    try {
      const body = {
        message,
        ...this.agentModel ? { model: this.agentModel } : {},
        cwd: process.cwd(),
        options: {
          agent_type: this.agentType,
          mode: this.agentMode,
          max_iterations: this.maxIterations,
          verbose: true
        }
      };
      if (images && images.length > 0) {
        body.images = images;
      }
      let endpoint = `${this.baseUrl}/api/agent/chat`;
      if (sessionId) {
        endpoint = `${this.baseUrl}/api/agent/chat/${sessionId}/continue`;
      }
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: this.abortController.signal
      });
      if (!response.ok) {
        let detail = response.statusText;
        try {
          const errBody = await response.json();
          if (errBody.detail) {
            detail = typeof errBody.detail === "string" ? errBody.detail : JSON.stringify(errBody.detail);
          }
        } catch {
        }
        throw new Error(`HTTP ${response.status}: ${detail}`);
      }
      const fullResponse = await this.processSSEStream(response);
      this.emit("done", fullResponse);
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        this.emit("done", "");
      } else {
        const msg = err instanceof Error ? err.message : "Connection error";
        this.emit("error", msg);
      }
    } finally {
      this._isStreaming = false;
      this.abortController = null;
    }
  }
  /**
   * POST to an endpoint that returns an SSE stream and process it.
   * Used for approval/rejection/answer endpoints that continue the agent.
   */
  async postStream(path2, body) {
    if (this._isStreaming) {
      await this.waitForStreamEnd();
    }
    this.abortController = new AbortController();
    this._isStreaming = true;
    try {
      const response = await fetch(`${this.baseUrl}${path2}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: body !== void 0 ? JSON.stringify(body) : void 0,
        signal: this.abortController.signal
      });
      if (!response.ok) {
        let detail = response.statusText;
        try {
          const errBody = await response.json();
          if (errBody.detail) {
            detail = typeof errBody.detail === "string" ? errBody.detail : JSON.stringify(errBody.detail);
          }
        } catch {
        }
        throw new Error(`HTTP ${response.status}: ${detail}`);
      }
      const fullResponse = await this.processSSEStream(response);
      this.emit("done", fullResponse);
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        this.emit("done", "");
      } else {
        const msg = err instanceof Error ? err.message : "Connection error";
        this.emit("error", msg);
      }
    } finally {
      this._isStreaming = false;
      this.abortController = null;
    }
  }
  /**
   * Wait for the current stream to end, with a timeout.
   */
  waitForStreamEnd(timeoutMs = 5e3) {
    return new Promise((resolve) => {
      if (!this._isStreaming) {
        resolve();
        return;
      }
      const start = Date.now();
      const check = () => {
        if (!this._isStreaming || Date.now() - start > timeoutMs) {
          resolve();
        } else {
          setTimeout(check, 50);
        }
      };
      check();
    });
  }
  /**
   * Read an SSE stream from a Response, parse events, emit them, and return
   * the accumulated full response text.
   */
  async processSSEStream(response) {
    if (!response.body) {
      throw new Error("No response stream");
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    const tools = [];
    let currentEvent = "";
    let buffer = "";
    let fullResponse = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (line.startsWith("event: ")) {
          currentEvent = line.slice(7).trim();
          continue;
        }
        if (line.startsWith("data: ")) {
          try {
            const data = JSON.parse(line.slice(6));
            if (data.session_id) {
              this.emit("session_id", data.session_id);
            }
            switch (currentEvent) {
              case "partial_response":
                if (data.content) {
                  fullResponse += data.content;
                  this.emit("partial_response", data.content, fullResponse);
                }
                break;
              case "thinking":
                if (data.message) {
                  this.emit("thinking", data.message);
                }
                break;
              case "tool_start": {
                const toolName = data.name || data.tool_name || data.tool;
                if (toolName) {
                  const tool = {
                    id: `tool-${Date.now()}`,
                    name: toolName,
                    status: "running",
                    input: data.args || data.tool_input || data.input,
                    subagentId: data.subagent_id,
                    subagentType: data.subagent_type
                  };
                  tools.push(tool);
                  this.emit("tool_start", tool);
                }
                break;
              }
              case "tool_result": {
                if (data.tool && tools.length > 0) {
                  const last = tools.find((t) => t.name === data.tool && t.status === "running");
                  if (last) {
                    last.status = "complete";
                    last.output = data.result;
                    last.duration = data.duration;
                  }
                  this.emit("tool_result", last ?? tools[tools.length - 1]);
                }
                break;
              }
              case "error":
                if (data.message) {
                  this.emit("error", data.message);
                }
                break;
              case "warning":
                if (data.message) {
                  this.emit("warning", data.message);
                }
                break;
              case "progress":
                if (data.message) {
                  this.emit("progress", data.message);
                }
                break;
              case "clarification":
                this.emit("clarification", data);
                break;
              case "choice_questions":
                this.emit("choice_questions", data);
                break;
              case "plan_mode_requested":
                this.emit("plan_mode_requested", data);
                break;
              case "plan_submitted":
                this.emit("plan_submitted", data);
                break;
              case "llm_step":
                this.emit("llm_step", data);
                break;
              case "assistant_text":
                if (data.content || data.text) {
                  const text = data.content || data.text;
                  this.emit("thinking", text);
                }
                break;
              case "subagent_start":
                this.emit("subagent_start", {
                  id: data.id || data.subagent_id || `subagent-${Date.now()}`,
                  agent_type: data.agent_type || data.type || "agent",
                  description: data.description || "",
                  prompt: data.prompt || ""
                });
                break;
              case "subagent_end":
                this.emit("subagent_end", {
                  id: data.id || data.subagent_id || "",
                  agent_type: data.agent_type || data.type || "agent",
                  success: data.success ?? true,
                  execution_time: data.execution_time ?? 0
                });
                break;
            }
          } catch {
          }
        }
      }
    }
    return fullResponse;
  }
  abort() {
    if (this.abortController) {
      this.abortController.abort();
    }
  }
  async get(path2) {
    const response = await fetch(`${this.baseUrl}${path2}`, {
      headers: { "Content-Type": "application/json" }
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return response.json();
  }
  async post(path2, body) {
    const response = await fetch(`${this.baseUrl}${path2}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body !== void 0 ? JSON.stringify(body) : void 0
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return response.json();
  }
  async delete(path2) {
    const response = await fetch(`${this.baseUrl}${path2}`, {
      method: "DELETE"
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return response.json();
  }
  async approvePlanMode(sessionId) {
    await this.postStream(`/api/agent/chat/${sessionId}/planmode/approve`);
  }
  async rejectPlanMode(sessionId, feedback) {
    const qs = feedback ? `?feedback=${encodeURIComponent(feedback)}` : "";
    await this.postStream(`/api/agent/chat/${sessionId}/planmode/reject${qs}`);
  }
  async approvePlanSubmission(sessionId) {
    await this.postStream(`/api/agent/chat/${sessionId}/plan/approve`);
  }
  async rejectPlanSubmission(sessionId, feedback) {
    const qs = feedback ? `?feedback=${encodeURIComponent(feedback)}` : "";
    await this.postStream(`/api/agent/chat/${sessionId}/plan/reject${qs}`);
  }
  async answerChoices(sessionId, responses) {
    await this.postStream(`/api/agent/chat/${sessionId}/choices/answer`, { responses });
  }
  async abortSession(sessionId) {
    await fetch(`${this.baseUrl}/api/agent/chat/${sessionId}/abort`, {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
  }
};

// dist/server-manager.js
import { spawn, execSync } from "node:child_process";
import { openSync, existsSync, mkdirSync as mkdirSync2 } from "node:fs";
import { join as join3 } from "node:path";
var DEFAULT_PORT = 8765;
var HEALTH_TIMEOUT_MS = 3e4;
var HEALTH_POLL_MS = 500;
var ServerManager = class {
  port;
  host;
  childProcess = null;
  logs;
  logFile = null;
  constructor(options3 = {}) {
    this.port = options3.port ?? DEFAULT_PORT;
    this.host = options3.host ?? "127.0.0.1";
    this.logs = options3.logs ?? false;
  }
  get baseUrl() {
    return `http://${this.host}:${this.port}`;
  }
  async isServerRunning() {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 2e3);
      const response = await fetch(`${this.baseUrl}/api/health`, {
        signal: controller.signal
      });
      clearTimeout(timeout);
      return response.ok;
    } catch {
      return false;
    }
  }
  /** Spawn emdash-core and attach error/exit handlers so Node doesn't crash. */
  spawnServer() {
    const serverArgs = ["--port", String(this.port), "--repo-root", process.cwd()];
    const python = process.env.EMDASH_CORE_PYTHON;
    const command = python || "emdash-core";
    const args = python ? ["-m", "emdash_core.server", ...serverArgs] : serverArgs;
    let stdio = "ignore";
    if (this.logs) {
      const logDir = join3(process.cwd(), ".emdash", "logs");
      if (!existsSync(logDir))
        mkdirSync2(logDir, { recursive: true });
      this.logFile = join3(logDir, "server.log");
      const fd = openSync(this.logFile, "w");
      stdio = ["ignore", fd, fd];
    }
    const env2 = this.logs ? { ...process.env, LOG_LEVEL: "INFO" } : process.env;
    const child = spawn(command, args, { stdio, env: env2 });
    child.on("error", () => {
    });
    return child;
  }
  /** Wait for the port to become free (no process listening). */
  async waitForPortFree(timeoutMs = 3e3) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const pids = execSync(`lsof -ti :${this.port}`, { encoding: "utf-8", timeout: 2e3 }).trim();
        if (!pids)
          return;
      } catch {
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
  }
  async ensureServer(onTick) {
    if (await this.isServerRunning()) {
      this.killPort();
      await this.waitForPortFree();
    }
    onTick?.(0, 0);
    this.childProcess = this.spawnServer();
    const startTime = Date.now();
    const deadline = startTime + HEALTH_TIMEOUT_MS;
    let frame = 0;
    while (Date.now() < deadline) {
      if (await this.isServerRunning()) {
        return this.baseUrl;
      }
      frame++;
      const elapsed = (Date.now() - startTime) / 1e3;
      onTick?.(elapsed, frame);
      await new Promise((resolve) => setTimeout(resolve, HEALTH_POLL_MS));
    }
    throw new Error(`Server did not start within ${HEALTH_TIMEOUT_MS / 1e3}s. Run 'emdash-core --port ${this.port}' manually and try again.`);
  }
  /**
   * Check if a specific API route exists on the running server.
   * Returns true if the route responds (any status except 404).
   */
  async hasRoute(path2) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3e3);
      const response = await fetch(`${this.baseUrl}${path2}`, {
        signal: controller.signal
      });
      clearTimeout(timeout);
      return response.status !== 404;
    } catch {
      return false;
    }
  }
  /**
   * Kill whatever process is listening on our port and start a fresh server.
   */
  async forceRestart(onTick) {
    if (this.childProcess) {
      this.childProcess.kill();
      this.childProcess = null;
    }
    this.killPort();
    await this.waitForPortFree();
    this.childProcess = this.spawnServer();
    const startTime = Date.now();
    const deadline = startTime + HEALTH_TIMEOUT_MS;
    let frame = 0;
    while (Date.now() < deadline) {
      if (await this.isServerRunning()) {
        return this.baseUrl;
      }
      frame++;
      const elapsed = (Date.now() - startTime) / 1e3;
      onTick?.(elapsed, frame);
      await new Promise((resolve) => setTimeout(resolve, HEALTH_POLL_MS));
    }
    throw new Error(`Server did not start within ${HEALTH_TIMEOUT_MS / 1e3}s after restart.`);
  }
  /** Kill whatever is listening on our port (excluding our own PID). */
  killPort() {
    const myPid = process.pid;
    try {
      const pids = execSync(`lsof -ti :${this.port}`, { encoding: "utf-8", timeout: 3e3 }).trim();
      if (pids) {
        for (const pid of pids.split("\n")) {
          const pidNum = parseInt(pid, 10);
          if (pidNum === myPid)
            continue;
          try {
            process.kill(pidNum, "SIGTERM");
          } catch {
          }
        }
      }
    } catch {
    }
  }
  shutdown() {
    if (this.childProcess) {
      this.childProcess.kill();
      this.childProcess = null;
    }
    this.killPort();
  }
  /** Kill all running emdash-core server processes system-wide. */
  static killAllServers() {
    const myPid = process.pid;
    let killed = 0;
    const patterns = ["emdash-core", "emdash_core.server"];
    for (const pattern of patterns) {
      try {
        const out = execSync(`pgrep -f '${pattern}'`, {
          encoding: "utf-8",
          timeout: 3e3
        }).trim();
        if (!out)
          continue;
        for (const pid of out.split("\n")) {
          const pidNum = parseInt(pid, 10);
          if (!pidNum || pidNum === myPid)
            continue;
          try {
            process.kill(pidNum, "SIGTERM");
            killed++;
          } catch {
          }
        }
      } catch {
      }
    }
    return killed;
  }
};

// dist/autocomplete.js
import { execSync as execSync2 } from "node:child_process";
import { basename as basename2 } from "node:path";
var gitFilesCache = null;
function getGitFiles(basePath) {
  if (gitFilesCache)
    return gitFilesCache;
  try {
    const output = execSync2("git ls-files", {
      cwd: basePath,
      encoding: "utf-8",
      timeout: 5e3,
      stdio: ["pipe", "pipe", "pipe"]
    });
    gitFilesCache = output.trim().split("\n").filter(Boolean);
  } catch {
    gitFilesCache = [];
  }
  return gitFilesCache;
}
var EmdashAutocompleteProvider = class {
  inner;
  basePath;
  needsFallback;
  constructor(inner, basePath, hasFd) {
    this.inner = inner;
    this.basePath = basePath;
    this.needsFallback = !hasFd;
  }
  getSuggestions(lines, cursorLine, cursorCol) {
    const result = this.inner.getSuggestions(lines, cursorLine, cursorCol);
    if (result && result.items.length > 0)
      return result;
    if (!this.needsFallback)
      return result;
    const currentLine = lines[cursorLine] || "";
    const textBeforeCursor = currentLine.slice(0, cursorCol);
    const atMatch = textBeforeCursor.match(/(?:^|[\s])(@[^\s]*)$/);
    if (!atMatch)
      return result;
    const prefix = atMatch[1] ?? "@";
    const query = prefix.slice(1);
    const files = getGitFiles(this.basePath);
    if (files.length === 0)
      return null;
    const items = files.map((f) => ({
      path: f,
      name: basename2(f)
    }));
    const filtered = fuzzyFilter(items, query, (item) => item.path).slice(0, 20).map((item) => ({
      value: `@${item.path}`,
      label: item.name,
      description: item.path
    }));
    if (filtered.length === 0)
      return null;
    return { items: filtered, prefix };
  }
  applyCompletion(lines, cursorLine, cursorCol, item, prefix) {
    return this.inner.applyCompletion(lines, cursorLine, cursorCol, item, prefix);
  }
};

// node_modules/chalk/source/vendor/ansi-styles/index.js
var ANSI_BACKGROUND_OFFSET = 10;
var wrapAnsi16 = (offset = 0) => (code) => `\x1B[${code + offset}m`;
var wrapAnsi256 = (offset = 0) => (code) => `\x1B[${38 + offset};5;${code}m`;
var wrapAnsi16m = (offset = 0) => (red, green, blue) => `\x1B[${38 + offset};2;${red};${green};${blue}m`;
var styles = {
  modifier: {
    reset: [0, 0],
    // 21 isn't widely supported and 22 does the same thing
    bold: [1, 22],
    dim: [2, 22],
    italic: [3, 23],
    underline: [4, 24],
    overline: [53, 55],
    inverse: [7, 27],
    hidden: [8, 28],
    strikethrough: [9, 29]
  },
  color: {
    black: [30, 39],
    red: [31, 39],
    green: [32, 39],
    yellow: [33, 39],
    blue: [34, 39],
    magenta: [35, 39],
    cyan: [36, 39],
    white: [37, 39],
    // Bright color
    blackBright: [90, 39],
    gray: [90, 39],
    // Alias of `blackBright`
    grey: [90, 39],
    // Alias of `blackBright`
    redBright: [91, 39],
    greenBright: [92, 39],
    yellowBright: [93, 39],
    blueBright: [94, 39],
    magentaBright: [95, 39],
    cyanBright: [96, 39],
    whiteBright: [97, 39]
  },
  bgColor: {
    bgBlack: [40, 49],
    bgRed: [41, 49],
    bgGreen: [42, 49],
    bgYellow: [43, 49],
    bgBlue: [44, 49],
    bgMagenta: [45, 49],
    bgCyan: [46, 49],
    bgWhite: [47, 49],
    // Bright color
    bgBlackBright: [100, 49],
    bgGray: [100, 49],
    // Alias of `bgBlackBright`
    bgGrey: [100, 49],
    // Alias of `bgBlackBright`
    bgRedBright: [101, 49],
    bgGreenBright: [102, 49],
    bgYellowBright: [103, 49],
    bgBlueBright: [104, 49],
    bgMagentaBright: [105, 49],
    bgCyanBright: [106, 49],
    bgWhiteBright: [107, 49]
  }
};
var modifierNames = Object.keys(styles.modifier);
var foregroundColorNames = Object.keys(styles.color);
var backgroundColorNames = Object.keys(styles.bgColor);
var colorNames = [...foregroundColorNames, ...backgroundColorNames];
function assembleStyles() {
  const codes = /* @__PURE__ */ new Map();
  for (const [groupName, group] of Object.entries(styles)) {
    for (const [styleName, style] of Object.entries(group)) {
      styles[styleName] = {
        open: `\x1B[${style[0]}m`,
        close: `\x1B[${style[1]}m`
      };
      group[styleName] = styles[styleName];
      codes.set(style[0], style[1]);
    }
    Object.defineProperty(styles, groupName, {
      value: group,
      enumerable: false
    });
  }
  Object.defineProperty(styles, "codes", {
    value: codes,
    enumerable: false
  });
  styles.color.close = "\x1B[39m";
  styles.bgColor.close = "\x1B[49m";
  styles.color.ansi = wrapAnsi16();
  styles.color.ansi256 = wrapAnsi256();
  styles.color.ansi16m = wrapAnsi16m();
  styles.bgColor.ansi = wrapAnsi16(ANSI_BACKGROUND_OFFSET);
  styles.bgColor.ansi256 = wrapAnsi256(ANSI_BACKGROUND_OFFSET);
  styles.bgColor.ansi16m = wrapAnsi16m(ANSI_BACKGROUND_OFFSET);
  Object.defineProperties(styles, {
    rgbToAnsi256: {
      value(red, green, blue) {
        if (red === green && green === blue) {
          if (red < 8) {
            return 16;
          }
          if (red > 248) {
            return 231;
          }
          return Math.round((red - 8) / 247 * 24) + 232;
        }
        return 16 + 36 * Math.round(red / 255 * 5) + 6 * Math.round(green / 255 * 5) + Math.round(blue / 255 * 5);
      },
      enumerable: false
    },
    hexToRgb: {
      value(hex) {
        const matches = /[a-f\d]{6}|[a-f\d]{3}/i.exec(hex.toString(16));
        if (!matches) {
          return [0, 0, 0];
        }
        let [colorString] = matches;
        if (colorString.length === 3) {
          colorString = [...colorString].map((character) => character + character).join("");
        }
        const integer = Number.parseInt(colorString, 16);
        return [
          /* eslint-disable no-bitwise */
          integer >> 16 & 255,
          integer >> 8 & 255,
          integer & 255
          /* eslint-enable no-bitwise */
        ];
      },
      enumerable: false
    },
    hexToAnsi256: {
      value: (hex) => styles.rgbToAnsi256(...styles.hexToRgb(hex)),
      enumerable: false
    },
    ansi256ToAnsi: {
      value(code) {
        if (code < 8) {
          return 30 + code;
        }
        if (code < 16) {
          return 90 + (code - 8);
        }
        let red;
        let green;
        let blue;
        if (code >= 232) {
          red = ((code - 232) * 10 + 8) / 255;
          green = red;
          blue = red;
        } else {
          code -= 16;
          const remainder = code % 36;
          red = Math.floor(code / 36) / 5;
          green = Math.floor(remainder / 6) / 5;
          blue = remainder % 6 / 5;
        }
        const value = Math.max(red, green, blue) * 2;
        if (value === 0) {
          return 30;
        }
        let result = 30 + (Math.round(blue) << 2 | Math.round(green) << 1 | Math.round(red));
        if (value === 2) {
          result += 60;
        }
        return result;
      },
      enumerable: false
    },
    rgbToAnsi: {
      value: (red, green, blue) => styles.ansi256ToAnsi(styles.rgbToAnsi256(red, green, blue)),
      enumerable: false
    },
    hexToAnsi: {
      value: (hex) => styles.ansi256ToAnsi(styles.hexToAnsi256(hex)),
      enumerable: false
    }
  });
  return styles;
}
var ansiStyles = assembleStyles();
var ansi_styles_default = ansiStyles;

// node_modules/chalk/source/vendor/supports-color/index.js
import process2 from "node:process";
import os2 from "node:os";
import tty from "node:tty";
function hasFlag(flag, argv = globalThis.Deno ? globalThis.Deno.args : process2.argv) {
  const prefix = flag.startsWith("-") ? "" : flag.length === 1 ? "-" : "--";
  const position = argv.indexOf(prefix + flag);
  const terminatorPosition = argv.indexOf("--");
  return position !== -1 && (terminatorPosition === -1 || position < terminatorPosition);
}
var { env } = process2;
var flagForceColor;
if (hasFlag("no-color") || hasFlag("no-colors") || hasFlag("color=false") || hasFlag("color=never")) {
  flagForceColor = 0;
} else if (hasFlag("color") || hasFlag("colors") || hasFlag("color=true") || hasFlag("color=always")) {
  flagForceColor = 1;
}
function envForceColor() {
  if ("FORCE_COLOR" in env) {
    if (env.FORCE_COLOR === "true") {
      return 1;
    }
    if (env.FORCE_COLOR === "false") {
      return 0;
    }
    return env.FORCE_COLOR.length === 0 ? 1 : Math.min(Number.parseInt(env.FORCE_COLOR, 10), 3);
  }
}
function translateLevel(level) {
  if (level === 0) {
    return false;
  }
  return {
    level,
    hasBasic: true,
    has256: level >= 2,
    has16m: level >= 3
  };
}
function _supportsColor(haveStream, { streamIsTTY, sniffFlags = true } = {}) {
  const noFlagForceColor = envForceColor();
  if (noFlagForceColor !== void 0) {
    flagForceColor = noFlagForceColor;
  }
  const forceColor = sniffFlags ? flagForceColor : noFlagForceColor;
  if (forceColor === 0) {
    return 0;
  }
  if (sniffFlags) {
    if (hasFlag("color=16m") || hasFlag("color=full") || hasFlag("color=truecolor")) {
      return 3;
    }
    if (hasFlag("color=256")) {
      return 2;
    }
  }
  if ("TF_BUILD" in env && "AGENT_NAME" in env) {
    return 1;
  }
  if (haveStream && !streamIsTTY && forceColor === void 0) {
    return 0;
  }
  const min = forceColor || 0;
  if (env.TERM === "dumb") {
    return min;
  }
  if (process2.platform === "win32") {
    const osRelease = os2.release().split(".");
    if (Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
      return Number(osRelease[2]) >= 14931 ? 3 : 2;
    }
    return 1;
  }
  if ("CI" in env) {
    if (["GITHUB_ACTIONS", "GITEA_ACTIONS", "CIRCLECI"].some((key) => key in env)) {
      return 3;
    }
    if (["TRAVIS", "APPVEYOR", "GITLAB_CI", "BUILDKITE", "DRONE"].some((sign) => sign in env) || env.CI_NAME === "codeship") {
      return 1;
    }
    return min;
  }
  if ("TEAMCITY_VERSION" in env) {
    return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(env.TEAMCITY_VERSION) ? 1 : 0;
  }
  if (env.COLORTERM === "truecolor") {
    return 3;
  }
  if (env.TERM === "xterm-kitty") {
    return 3;
  }
  if (env.TERM === "xterm-ghostty") {
    return 3;
  }
  if (env.TERM === "wezterm") {
    return 3;
  }
  if ("TERM_PROGRAM" in env) {
    const version = Number.parseInt((env.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
    switch (env.TERM_PROGRAM) {
      case "iTerm.app": {
        return version >= 3 ? 3 : 2;
      }
      case "Apple_Terminal": {
        return 2;
      }
    }
  }
  if (/-256(color)?$/i.test(env.TERM)) {
    return 2;
  }
  if (/^screen|^xterm|^vt100|^vt220|^rxvt|color|ansi|cygwin|linux/i.test(env.TERM)) {
    return 1;
  }
  if ("COLORTERM" in env) {
    return 1;
  }
  return min;
}
function createSupportsColor(stream, options3 = {}) {
  const level = _supportsColor(stream, {
    streamIsTTY: stream && stream.isTTY,
    ...options3
  });
  return translateLevel(level);
}
var supportsColor = {
  stdout: createSupportsColor({ isTTY: tty.isatty(1) }),
  stderr: createSupportsColor({ isTTY: tty.isatty(2) })
};
var supports_color_default = supportsColor;

// node_modules/chalk/source/utilities.js
function stringReplaceAll(string, substring, replacer) {
  let index = string.indexOf(substring);
  if (index === -1) {
    return string;
  }
  const substringLength = substring.length;
  let endIndex = 0;
  let returnValue = "";
  do {
    returnValue += string.slice(endIndex, index) + substring + replacer;
    endIndex = index + substringLength;
    index = string.indexOf(substring, endIndex);
  } while (index !== -1);
  returnValue += string.slice(endIndex);
  return returnValue;
}
function stringEncaseCRLFWithFirstIndex(string, prefix, postfix, index) {
  let endIndex = 0;
  let returnValue = "";
  do {
    const gotCR = string[index - 1] === "\r";
    returnValue += string.slice(endIndex, gotCR ? index - 1 : index) + prefix + (gotCR ? "\r\n" : "\n") + postfix;
    endIndex = index + 1;
    index = string.indexOf("\n", endIndex);
  } while (index !== -1);
  returnValue += string.slice(endIndex);
  return returnValue;
}

// node_modules/chalk/source/index.js
var { stdout: stdoutColor, stderr: stderrColor } = supports_color_default;
var GENERATOR = Symbol("GENERATOR");
var STYLER = Symbol("STYLER");
var IS_EMPTY = Symbol("IS_EMPTY");
var levelMapping = [
  "ansi",
  "ansi",
  "ansi256",
  "ansi16m"
];
var styles2 = /* @__PURE__ */ Object.create(null);
var applyOptions = (object, options3 = {}) => {
  if (options3.level && !(Number.isInteger(options3.level) && options3.level >= 0 && options3.level <= 3)) {
    throw new Error("The `level` option should be an integer from 0 to 3");
  }
  const colorLevel = stdoutColor ? stdoutColor.level : 0;
  object.level = options3.level === void 0 ? colorLevel : options3.level;
};
var chalkFactory = (options3) => {
  const chalk2 = (...strings) => strings.join(" ");
  applyOptions(chalk2, options3);
  Object.setPrototypeOf(chalk2, createChalk.prototype);
  return chalk2;
};
function createChalk(options3) {
  return chalkFactory(options3);
}
Object.setPrototypeOf(createChalk.prototype, Function.prototype);
for (const [styleName, style] of Object.entries(ansi_styles_default)) {
  styles2[styleName] = {
    get() {
      const builder = createBuilder(this, createStyler(style.open, style.close, this[STYLER]), this[IS_EMPTY]);
      Object.defineProperty(this, styleName, { value: builder });
      return builder;
    }
  };
}
styles2.visible = {
  get() {
    const builder = createBuilder(this, this[STYLER], true);
    Object.defineProperty(this, "visible", { value: builder });
    return builder;
  }
};
var getModelAnsi = (model, level, type, ...arguments_) => {
  if (model === "rgb") {
    if (level === "ansi16m") {
      return ansi_styles_default[type].ansi16m(...arguments_);
    }
    if (level === "ansi256") {
      return ansi_styles_default[type].ansi256(ansi_styles_default.rgbToAnsi256(...arguments_));
    }
    return ansi_styles_default[type].ansi(ansi_styles_default.rgbToAnsi(...arguments_));
  }
  if (model === "hex") {
    return getModelAnsi("rgb", level, type, ...ansi_styles_default.hexToRgb(...arguments_));
  }
  return ansi_styles_default[type][model](...arguments_);
};
var usedModels = ["rgb", "hex", "ansi256"];
for (const model of usedModels) {
  styles2[model] = {
    get() {
      const { level } = this;
      return function(...arguments_) {
        const styler = createStyler(getModelAnsi(model, levelMapping[level], "color", ...arguments_), ansi_styles_default.color.close, this[STYLER]);
        return createBuilder(this, styler, this[IS_EMPTY]);
      };
    }
  };
  const bgModel = "bg" + model[0].toUpperCase() + model.slice(1);
  styles2[bgModel] = {
    get() {
      const { level } = this;
      return function(...arguments_) {
        const styler = createStyler(getModelAnsi(model, levelMapping[level], "bgColor", ...arguments_), ansi_styles_default.bgColor.close, this[STYLER]);
        return createBuilder(this, styler, this[IS_EMPTY]);
      };
    }
  };
}
var proto = Object.defineProperties(() => {
}, {
  ...styles2,
  level: {
    enumerable: true,
    get() {
      return this[GENERATOR].level;
    },
    set(level) {
      this[GENERATOR].level = level;
    }
  }
});
var createStyler = (open, close, parent) => {
  let openAll;
  let closeAll;
  if (parent === void 0) {
    openAll = open;
    closeAll = close;
  } else {
    openAll = parent.openAll + open;
    closeAll = close + parent.closeAll;
  }
  return {
    open,
    close,
    openAll,
    closeAll,
    parent
  };
};
var createBuilder = (self, _styler, _isEmpty) => {
  const builder = (...arguments_) => applyStyle(builder, arguments_.length === 1 ? "" + arguments_[0] : arguments_.join(" "));
  Object.setPrototypeOf(builder, proto);
  builder[GENERATOR] = self;
  builder[STYLER] = _styler;
  builder[IS_EMPTY] = _isEmpty;
  return builder;
};
var applyStyle = (self, string) => {
  if (self.level <= 0 || !string) {
    return self[IS_EMPTY] ? "" : string;
  }
  let styler = self[STYLER];
  if (styler === void 0) {
    return string;
  }
  const { openAll, closeAll } = styler;
  if (string.includes("\x1B")) {
    while (styler !== void 0) {
      string = stringReplaceAll(string, styler.close, styler.open);
      styler = styler.parent;
    }
  }
  const lfIndex = string.indexOf("\n");
  if (lfIndex !== -1) {
    string = stringEncaseCRLFWithFirstIndex(string, closeAll, openAll, lfIndex);
  }
  return openAll + string + closeAll;
};
Object.defineProperties(createChalk.prototype, styles2);
var chalk = createChalk();
var chalkStderr = createChalk({ level: stderrColor ? stderrColor.level : 0 });
var source_default = chalk;

// dist/theme.js
var colors = {
  // Primary accent
  accent: source_default.hex("#7C3AED"),
  // violet-600
  accentBright: source_default.hex("#A78BFA"),
  // violet-400
  // Status colors
  success: source_default.hex("#10B981"),
  // emerald-500
  warning: source_default.hex("#F59E0B"),
  // amber-500
  error: source_default.hex("#EF4444"),
  // red-500
  info: source_default.hex("#3B82F6"),
  // blue-500
  // Text
  text: source_default.white,
  textDim: source_default.gray,
  textMuted: source_default.hex("#6B7280"),
  // gray-500
  // Roles
  user: source_default.hex("#3B82F6"),
  // blue-500
  assistant: source_default.hex("#A78BFA"),
  // violet-400
  system: source_default.hex("#6B7280"),
  // gray-500
  thinking: source_default.hex("#F59E0B"),
  // amber-500
  // Brand
  zenOrange: source_default.hex("#F97316"),
  // orange-500
  zenOrangeBold: source_default.hex("#F97316").bold,
  // Tools
  toolRunning: source_default.hex("#F59E0B"),
  // amber-500
  toolDone: source_default.hex("#10B981"),
  // emerald-500
  toolError: source_default.hex("#EF4444"),
  // red-500
  // Modes
  modeCode: source_default.hex("#10B981"),
  modePlan: source_default.hex("#F59E0B"),
  modeResearch: source_default.hex("#3B82F6"),
  modeReview: source_default.hex("#8B5CF6")
};
var selectListTheme = {
  selectedPrefix: (text) => source_default.hex("#A78BFA")(text),
  selectedText: (text) => source_default.hex("#A78BFA")(text),
  description: (text) => source_default.gray(text),
  scrollInfo: (text) => source_default.gray(text),
  noMatch: (text) => source_default.gray(text)
};
var editorTheme = {
  borderColor: (str) => source_default.hex("#374151")(str),
  selectList: selectListTheme
};
function applyCodeHighlighting(line, lang) {
  if (lang === "diff") {
    if (line.startsWith("+"))
      return source_default.green(line);
    if (line.startsWith("-"))
      return source_default.red(line);
    if (line.startsWith("@@"))
      return source_default.cyan(line);
    return source_default.hex("#D4D4D4")(line);
  }
  const placeholders = [];
  const ph = (styled) => {
    const idx = placeholders.length;
    placeholders.push(styled);
    return `\0P${idx}P\0`;
  };
  let result = line;
  result = result.replace(/(\/\/.*$|#.*$)/g, (m) => ph(source_default.gray(m)));
  result = result.replace(/(["'])(?:(?!\1).)*?\1/g, (m) => ph(source_default.green(m)));
  result = result.replace(/\b(\d+\.?\d*)\b/g, (m) => ph(source_default.hex("#CE9178")(m)));
  const keywords = /\b(import|export|from|const|let|var|function|class|return|if|else|for|while|do|switch|case|break|continue|new|this|typeof|instanceof|async|await|yield|def|self|None|True|False|try|catch|finally|throw|extends|implements|interface|type|enum|struct|fn|pub|mut|use|mod|match|impl)\b/g;
  result = result.replace(keywords, (m) => ph(source_default.hex("#569CD6")(m)));
  result = result.replace(/\x00P(\d+)P\x00/g, (_, idx) => placeholders[parseInt(idx)]);
  return result;
}
var markdownTheme = {
  heading: (text) => source_default.hex("#A78BFA").bold(text),
  link: (text) => source_default.hex("#3B82F6")(text),
  linkUrl: (text) => source_default.hex("#3B82F6").underline(text),
  code: (text) => source_default.hex("#A78BFA").bgHex("#2D2D3F")(text),
  codeBlock: (text) => source_default.hex("#D4D4D4")(text),
  codeBlockBorder: (text) => source_default.hex("#374151")(text),
  quote: (text) => source_default.hex("#9CA3AF")(text),
  quoteBorder: (text) => source_default.hex("#7C3AED")(text),
  hr: (text) => source_default.hex("#374151")(text),
  listBullet: (text) => source_default.hex("#6B7280")(text),
  bold: (text) => source_default.bold(text),
  italic: (text) => source_default.italic(text),
  strikethrough: (text) => source_default.strikethrough(text),
  underline: (text) => source_default.underline(text),
  highlightCode: (code, lang) => {
    return code.split("\n").map((line) => applyCodeHighlighting(line, lang));
  }
};
var statusBarBg = source_default.bgHex("#2D2D3F");
function modeColor(mode) {
  switch (mode) {
    case "code":
      return (t) => colors.modeCode(t);
    case "plan":
      return (t) => colors.modePlan(t);
    case "research":
      return (t) => colors.modeResearch(t);
    case "review":
      return (t) => colors.modeReview(t);
    default:
      return (t) => colors.text(t);
  }
}

// dist/components/status-bar.js
var StatusBar = class {
  textComponent;
  state;
  spinnerFrame = 0;
  spinnerChars = ["\u280B", "\u2819", "\u2839", "\u2838", "\u283C", "\u2834", "\u2826", "\u2827", "\u2807", "\u280F"];
  constructor(initialState = {}) {
    this.state = {
      model: initialState.model ?? "default",
      mode: initialState.mode ?? "code",
      sessionId: initialState.sessionId ?? null,
      status: initialState.status ?? "Ready",
      isStreaming: initialState.isStreaming ?? false
    };
    this.textComponent = new Text("", 0, 0, (line) => statusBarBg(line));
    this.render();
  }
  get component() {
    return this.textComponent;
  }
  update(partial) {
    Object.assign(this.state, partial);
    this.render();
  }
  tick() {
    if (this.state.isStreaming) {
      this.spinnerFrame = (this.spinnerFrame + 1) % this.spinnerChars.length;
      this.render();
    }
  }
  render() {
    const { mode, sessionId, status, isStreaming } = this.state;
    const colorFn = modeColor(mode);
    const modeTag = source_default.bold(colorFn(` ${mode.toUpperCase()} `));
    const sessionStr = sessionId ? colors.textDim(` session:${sessionId.slice(0, 8)}`) : "";
    const spinner = isStreaming ? colors.accentBright(` ${this.spinnerChars[this.spinnerFrame]} `) : "";
    const statusStr = isStreaming ? colors.warning(status) : status === "Ready" ? "" : status.startsWith("Error") ? colors.error(status) : colors.textDim(status);
    const line = ` ${modeTag}${sessionStr} ${spinner}${statusStr}`;
    this.textComponent.setText(line);
  }
};

// dist/components/thinking.js
var SPINNER_FRAMES = ["\u280B", "\u2819", "\u2839", "\u2838", "\u283C", "\u2834", "\u2826", "\u2827", "\u2807", "\u280F"];
var ThinkingDisplay = class {
  message = null;
  spinnerFrame = 0;
  ticking = false;
  setThinking(message) {
    this.message = message;
  }
  get isThinking() {
    return this.message !== null;
  }
  tick() {
    this.ticking = true;
    this.spinnerFrame = (this.spinnerFrame + 1) % SPINNER_FRAMES.length;
  }
  clear() {
    this.message = null;
    this.ticking = false;
    this.spinnerFrame = 0;
  }
  renderLine() {
    if (!this.message)
      return null;
    const frame = this.ticking ? SPINNER_FRAMES[this.spinnerFrame] : SPINNER_FRAMES[0];
    const spinner = colors.accent(frame);
    const truncated = this.message.length > 80 ? this.message.slice(0, 77) + "..." : this.message;
    const msg = colors.textDim(truncated);
    return `  ${spinner} ${msg}`;
  }
};

// dist/components/tool-tracker.js
var MAX_TARGETS = 20;
var MAX_PREVIEW_LINES = 5;
var FILE_MOD_TOOLS = /* @__PURE__ */ new Set(["write_to_file", "edit_file", "apply_diff"]);
var ToolTracker = class {
  groups = [];
  subAgents = [];
  activeSubAgentId = null;
  completedLines = [];
  spinnerFrame = 0;
  spinnerChars = ["\u280B", "\u2819", "\u2839", "\u2838", "\u283C", "\u2834", "\u2826", "\u2827", "\u2807", "\u280F"];
  /** Drain completed tool lines for persisting as permanent UI elements. */
  drainCompleted() {
    const lines = [...this.completedLines];
    this.completedLines = [];
    return lines;
  }
  startSubAgent(id, type, description) {
    this.subAgents.push({
      id,
      type,
      description,
      status: "running",
      childGroups: [],
      startTime: Date.now(),
      duration: 0
    });
    this.activeSubAgentId = id;
  }
  endSubAgent(id, success, executionTime) {
    const idx = this.subAgents.findIndex((a) => a.id === id);
    if (idx < 0)
      return;
    const agent = this.subAgents[idx];
    agent.status = success ? "complete" : "error";
    agent.duration = executionTime;
    const isError = agent.status === "error";
    const icon = isError ? colors.toolError("\u2717") : colors.toolDone("\u25CF");
    const duration = agent.duration > 0 ? colors.textDim(`  ${(agent.duration / 1e3).toFixed(1)}s`) : "";
    const label = `${capitalize(agent.type)}: "${truncate(agent.description, 40)}"`;
    const nameStr = isError ? colors.toolError(label) : colors.toolDone(label);
    this.completedLines.push(`  ${icon} ${nameStr}${duration}`);
    for (const child of agent.childGroups) {
      if (child.status === "running")
        child.status = "complete";
      this.queueCompleted(child, "    ");
    }
    this.subAgents.splice(idx, 1);
    if (this.activeSubAgentId === id) {
      this.activeSubAgentId = null;
    }
  }
  addTool(tool) {
    if (tool.subagentId) {
      const agent = this.subAgents.find((a) => a.id === tool.subagentId);
      if (agent) {
        this.addToGroup(agent.childGroups, tool);
        return;
      }
    }
    this.addToGroup(this.groups, tool);
    this.flushCompletedTopLevel();
  }
  updateTool(tool) {
    if (tool.subagentId) {
      const agent = this.subAgents.find((a) => a.id === tool.subagentId);
      if (agent) {
        this.updateInGroup(agent.childGroups, tool);
        return;
      }
    }
    this.updateInGroup(this.groups, tool);
    this.flushCompletedTopLevel();
  }
  /** Complete all remaining groups and drain them (called at turn end). */
  finalizeAll() {
    for (const g of this.groups) {
      if (g.status === "running")
        g.status = "complete";
    }
    this.flushCompletedTopLevel();
    for (const agent of [...this.subAgents]) {
      if (agent.status === "running") {
        agent.status = "complete";
        agent.duration = Date.now() - agent.startTime;
        const icon = colors.toolDone("\u25CF");
        const dur = agent.duration > 0 ? colors.textDim(`  ${(agent.duration / 1e3).toFixed(1)}s`) : "";
        const label = `${capitalize(agent.type)}: "${truncate(agent.description, 40)}"`;
        this.completedLines.push(`  ${icon} ${colors.toolDone(label)}${dur}`);
        for (const child of agent.childGroups) {
          if (child.status === "running")
            child.status = "complete";
          this.queueCompleted(child, "    ");
        }
      }
    }
    this.subAgents = [];
  }
  clear() {
    this.groups = [];
    this.subAgents = [];
    this.activeSubAgentId = null;
    this.completedLines = [];
  }
  tick() {
    this.spinnerFrame = (this.spinnerFrame + 1) % this.spinnerChars.length;
  }
  /** Render only currently running tools/sub-agents for the live info section. */
  renderLines() {
    const lines = [];
    for (const group of this.groups) {
      if (group.name === "task" && this.subAgents.length > 0)
        continue;
      if (group.status === "running") {
        lines.push(this.renderRunningLine(group, "  "));
      }
    }
    for (const agent of this.subAgents) {
      if (agent.status === "running") {
        lines.push(this.renderSubAgentHeader(agent));
        for (const child of agent.childGroups) {
          lines.push(this.renderChildLine(child, "    "));
        }
      }
    }
    return lines;
  }
  // --- Private helpers ---
  addToGroup(groups, tool) {
    for (const g of groups) {
      if (g.name !== tool.name && g.status === "running") {
        g.status = "complete";
      }
    }
    const existing = groups.find((g) => g.name === tool.name && g.status === "running");
    const target = extractTarget(tool.name, tool.input);
    if (existing) {
      existing.count++;
      existing.lastInput = tool.input;
      if (target && !existing.targets.includes(target) && existing.targets.length < MAX_TARGETS) {
        existing.targets.push(target);
      }
    } else {
      groups.push({
        name: tool.name,
        count: 1,
        status: "running",
        totalDuration: 0,
        startTime: Date.now(),
        targets: target ? [target] : [],
        lastInput: tool.input
      });
    }
  }
  updateInGroup(groups, tool) {
    const group = groups.find((g) => g.name === tool.name && g.status === "running");
    if (group) {
      group.status = tool.status === "error" ? "error" : "complete";
      if (tool.duration != null) {
        group.totalDuration += tool.duration;
      }
    }
  }
  /** Move completed top-level groups to the drain queue. */
  flushCompletedTopLevel() {
    for (let i = this.groups.length - 1; i >= 0; i--) {
      const g = this.groups[i];
      if (g.status === "running")
        continue;
      if (g.name === "task" && this.subAgents.length > 0) {
        this.groups.splice(i, 1);
        continue;
      }
      this.queueCompleted(g, "  ");
      this.groups.splice(i, 1);
    }
  }
  queueCompleted(group, indent) {
    if (FILE_MOD_TOOLS.has(group.name)) {
      this.queueFileToolCompleted(group, indent);
      return;
    }
    const isError = group.status === "error";
    const icon = isError ? colors.toolError("\u2717") : colors.toolDone("\u25CF");
    const countSuffix = group.count > 1 ? ` (\xD7${group.count})` : "";
    const nameStr = isError ? colors.toolError(group.name + countSuffix) : colors.toolDone(group.name + countSuffix);
    const targetStr = group.targets.length > 0 ? colors.textDim(` ${formatTargets(group.targets, 3)}`) : "";
    const duration = group.totalDuration > 0 ? colors.textDim(`  ${(group.totalDuration / 1e3).toFixed(1)}s`) : "";
    this.completedLines.push(`${indent}${icon} ${nameStr}${targetStr}${duration}`);
  }
  /** Rich diff-view display for file modification tools. */
  queueFileToolCompleted(group, indent) {
    const isError = group.status === "error";
    const icon = isError ? colors.toolError("\u2717") : colors.toolDone("\u25CF");
    const action = fileToolAction(group.name);
    const duration = group.totalDuration > 0 ? colors.textDim(`  ${(group.totalDuration / 1e3).toFixed(1)}s`) : "";
    if (group.count === 1 && group.targets.length > 0) {
      const label = `${action}(${group.targets[0]})`;
      const nameStr = isError ? colors.toolError(label) : colors.toolDone(label);
      this.completedLines.push(`${indent}${icon} ${nameStr}${duration}`);
    } else {
      const countSuffix = group.count > 1 ? ` (\xD7${group.count})` : "";
      const nameStr = isError ? colors.toolError(action + countSuffix) : colors.toolDone(action + countSuffix);
      const targetStr = group.targets.length > 0 ? colors.textDim(` ${formatTargets(group.targets, 3)}`) : "";
      this.completedLines.push(`${indent}${icon} ${nameStr}${targetStr}${duration}`);
    }
    const stats = computeChangeStats(group.name, group.lastInput);
    if (stats) {
      this.completedLines.push(`${indent}  \u2514 ${colors.textDim(stats)}`);
    }
    const preview = getCodePreview(group.name, group.lastInput);
    for (const line of preview) {
      this.completedLines.push(`${indent}     ${line}`);
    }
  }
  renderRunningLine(group, indent) {
    const spinner = colors.toolRunning(this.spinnerChars[this.spinnerFrame] + " ");
    const countSuffix = group.count > 1 ? ` (\xD7${group.count})` : "";
    const name = colors.toolRunning(group.name + countSuffix);
    const lastTarget = group.targets.length > 0 ? group.targets[group.targets.length - 1] : null;
    const targetStr = lastTarget ? colors.textDim(` ${lastTarget}`) : "";
    const elapsed = (Date.now() - group.startTime) / 1e3;
    const elapsedStr = colors.textDim(`  ${elapsed.toFixed(1)}s`);
    return `${indent}${spinner}${name}${targetStr}${elapsedStr}`;
  }
  /** Render a sub-agent child (both running and completed states). */
  renderChildLine(group, indent) {
    if (group.status === "running") {
      return this.renderRunningLine(group, indent);
    }
    const isError = group.status === "error";
    const icon = isError ? colors.toolError("\u2717 ") : colors.toolDone("\u25CF ");
    const countSuffix = group.count > 1 ? ` (\xD7${group.count})` : "";
    const nameStr = isError ? colors.toolError(group.name + countSuffix) : colors.toolDone(group.name + countSuffix);
    const targetStr = group.targets.length > 0 ? colors.textDim(` ${formatTargets(group.targets, 3)}`) : "";
    const duration = group.totalDuration > 0 ? colors.textDim(`  ${(group.totalDuration / 1e3).toFixed(1)}s`) : "";
    return `${indent}${icon}${nameStr}${targetStr}${duration}`;
  }
  renderSubAgentHeader(agent) {
    const label = `${capitalize(agent.type)}: "${truncate(agent.description, 40)}"`;
    if (agent.status === "running") {
      const spinner = colors.toolRunning(this.spinnerChars[this.spinnerFrame] + " ");
      const elapsed = (Date.now() - agent.startTime) / 1e3;
      const elapsedStr = colors.textDim(`  ${elapsed.toFixed(1)}s`);
      return `  ${spinner}${colors.toolRunning(label)}${elapsedStr}`;
    }
    const isError = agent.status === "error";
    const icon = isError ? colors.toolError("\u2717 ") : colors.toolDone("\u25CF ");
    const duration = agent.duration > 0 ? colors.textDim(`  ${(agent.duration / 1e3).toFixed(1)}s`) : "";
    const nameStr = isError ? colors.toolError(label) : colors.toolDone(label);
    return `  ${icon}${nameStr}${duration}`;
  }
};
function capitalize(str) {
  if (!str)
    return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}
function truncate(str, maxLen) {
  if (str.length <= maxLen)
    return str;
  return str.slice(0, maxLen - 3) + "...";
}
function fileToolAction(name) {
  switch (name) {
    case "write_to_file":
      return "Write";
    case "edit_file":
      return "Edit";
    case "apply_diff":
      return "Diff";
    default:
      return name;
  }
}
function parseInput(input) {
  if (!input)
    return null;
  try {
    return typeof input === "string" ? JSON.parse(input) : input;
  } catch {
    return null;
  }
}
function computeChangeStats(toolName, input) {
  const parsed = parseInput(input);
  if (!parsed)
    return null;
  switch (toolName) {
    case "write_to_file": {
      const content = parsed.content;
      if (!content)
        return null;
      const lines = content.split("\n").length;
      return `${lines} line${lines !== 1 ? "s" : ""}`;
    }
    case "edit_file": {
      const oldStr = parsed.old_string ?? "";
      const newStr = parsed.new_string ?? "";
      const removed = oldStr ? oldStr.split("\n").length : 0;
      const added = newStr ? newStr.split("\n").length : 0;
      const parts = [];
      if (added > 0)
        parts.push(`Added ${added} line${added !== 1 ? "s" : ""}`);
      if (removed > 0)
        parts.push(`removed ${removed} line${removed !== 1 ? "s" : ""}`);
      return parts.join(", ") || null;
    }
    case "apply_diff": {
      const diff = parsed.diff;
      if (!diff)
        return null;
      let added = 0, removed = 0;
      for (const line of diff.split("\n")) {
        if (line.startsWith("+") && !line.startsWith("+++"))
          added++;
        if (line.startsWith("-") && !line.startsWith("---"))
          removed++;
      }
      const parts = [];
      if (added > 0)
        parts.push(`Added ${added} line${added !== 1 ? "s" : ""}`);
      if (removed > 0)
        parts.push(`removed ${removed} line${removed !== 1 ? "s" : ""}`);
      return parts.join(", ") || null;
    }
    default:
      return null;
  }
}
function getCodePreview(toolName, input) {
  const parsed = parseInput(input);
  if (!parsed)
    return [];
  switch (toolName) {
    case "edit_file": {
      const newStr = parsed.new_string;
      if (!newStr)
        return [];
      return formatPreviewLines(newStr, "+");
    }
    case "apply_diff": {
      const diff = parsed.diff;
      if (!diff)
        return [];
      return formatDiffPreview(diff);
    }
    case "write_to_file": {
      const content = parsed.content;
      if (!content)
        return [];
      return formatPreviewLines(content, null);
    }
    default:
      return [];
  }
}
function formatPreviewLines(content, marker) {
  const allLines = content.split("\n");
  const lines = allLines.slice(0, MAX_PREVIEW_LINES);
  const hasMore = allLines.length > MAX_PREVIEW_LINES;
  const numWidth = Math.max(String(lines.length).length, 3);
  const result = [];
  for (let i = 0; i < lines.length; i++) {
    const lineContent = truncate(lines[i], 60);
    const num = String(i + 1).padStart(numWidth);
    if (marker === "+") {
      result.push(`${colors.textDim(num)} ${colors.toolDone("+ " + lineContent)}`);
    } else if (marker === "-") {
      result.push(`${colors.textDim(num)} ${colors.toolError("- " + lineContent)}`);
    } else {
      result.push(`${colors.textDim(num + "   " + lineContent)}`);
    }
  }
  if (hasMore) {
    result.push(colors.textDim("".padStart(numWidth) + "   ..."));
  }
  return result;
}
function formatDiffPreview(diff) {
  const allLines = diff.split("\n");
  const result = [];
  let shown = 0;
  for (const line of allLines) {
    if (shown >= MAX_PREVIEW_LINES)
      break;
    if (line.startsWith("---") || line.startsWith("+++") || line.startsWith("@@"))
      continue;
    const content = truncate(line, 64);
    if (line.startsWith("+")) {
      result.push(colors.toolDone(content));
    } else if (line.startsWith("-")) {
      result.push(colors.toolError(content));
    } else {
      result.push(colors.textDim(content));
    }
    shown++;
  }
  if (allLines.length > shown) {
    result.push(colors.textDim("..."));
  }
  return result;
}
function extractTarget(toolName, input) {
  if (!input)
    return null;
  const parsed = parseInput(input);
  if (!parsed)
    return null;
  switch (toolName) {
    case "read_file":
    case "write_to_file":
    case "edit_file":
    case "apply_diff": {
      const filePath = parsed.path ?? parsed.file_path;
      if (filePath)
        return basename3(filePath);
      return null;
    }
    case "list_files": {
      const dirPath = parsed.path;
      if (dirPath) {
        const parts = dirPath.replace(/\/+$/, "").split("/");
        return parts[parts.length - 1] || dirPath;
      }
      return null;
    }
    case "grep":
    case "text_search": {
      const pattern = parsed.pattern ?? parsed.query;
      if (pattern)
        return `"${truncate(pattern, 30)}"`;
      return null;
    }
    case "semantic_search": {
      const query = parsed.query;
      if (query)
        return `"${truncate(query, 30)}"`;
      return null;
    }
    case "task": {
      const desc = parsed.description;
      if (desc)
        return truncate(desc, 30);
      return null;
    }
    default:
      return null;
  }
}
function basename3(filePath) {
  const parts = filePath.split("/");
  return parts[parts.length - 1] || filePath;
}
function formatTargets(targets, maxShow) {
  if (targets.length === 0)
    return "";
  const shown = targets.slice(0, maxShow);
  const overflow = targets.length - maxShow;
  let result = shown.join(", ");
  if (overflow > 0) {
    result += `, +${overflow} more`;
  }
  return result;
}

// dist/components/message-list.js
var MessageList = class {
  messages = [];
  components = [];
  currentStreamingId = null;
  currentStreamingComponent = null;
  thinkingDisplay = new ThinkingDisplay();
  toolTracker = new ToolTracker();
  infoText;
  _isConnecting = false;
  connectingFrame = 0;
  connectingFrames = ["\u25F0", "\u25F3", "\u25F2", "\u25F1"];
  // Banner state
  bannerText = null;
  bannerModel = "";
  bannerVersion = "";
  bannerFrame = 0;
  bannerDone = false;
  bannerTitle = "EmDash";
  constructor() {
    this.infoText = new Text("", 1, 0);
  }
  get allComponents() {
    return [...this.components];
  }
  /** Return all messages (for /copy, /export, etc.) */
  getMessages() {
    return [...this.messages];
  }
  get thinking() {
    return this.thinkingDisplay;
  }
  get tools() {
    return this.toolTracker;
  }
  get isConnecting() {
    return this._isConnecting;
  }
  clearConnecting() {
    this._isConnecting = false;
  }
  tickConnecting() {
    if (this._isConnecting) {
      this.connectingFrame = (this.connectingFrame + 1) % this.connectingFrames.length;
    }
  }
  startBanner(model, version) {
    this.bannerModel = model;
    this.bannerVersion = version;
    this.bannerFrame = 0;
    this.bannerDone = false;
    this.bannerText = new Text("", 1, 1);
    this.components.unshift(this.bannerText);
    this.updateBannerText();
  }
  tickBanner() {
    if (this.bannerDone || !this.bannerText)
      return;
    this.bannerFrame++;
    this.updateBannerText();
  }
  updateBannerText() {
    if (!this.bannerText)
      return;
    const revealed = Math.min(this.bannerFrame, this.bannerTitle.length);
    const partial = this.bannerTitle.slice(0, revealed);
    const diamond = colors.zenOrangeBold("\u25C6");
    const title = colors.zenOrangeBold(partial);
    let line1 = `  ${diamond} ${title}`;
    let lines;
    if (revealed >= this.bannerTitle.length) {
      this.bannerDone = true;
      const meta = colors.textDim(`  v${this.bannerVersion} \xB7 ${this.bannerModel}`);
      line1 = `  ${diamond} ${title}${meta}`;
      const line2 = colors.textMuted("  /help for commands \xB7 Ctrl+Q quit");
      lines = `${line1}

${line2}`;
    } else {
      lines = line1;
    }
    this.bannerText.setText(lines);
  }
  addUserMessage(content) {
    const id = `user-${Date.now()}`;
    this.messages.push({ id, role: "user", content });
    const text = new Text(`${colors.user("\u276F")} ${colors.text(content)}`, 1, 1);
    this.components.push(text);
  }
  addSystemMessage(content) {
    const id = `sys-${Date.now()}`;
    this.messages.push({ id, role: "system", content });
    const text = new Text(colors.system(content), 1, 1);
    this.components.push(text);
  }
  startAssistantMessage() {
    const id = `asst-${Date.now()}`;
    this.messages.push({ id, role: "assistant", content: "", isStreaming: true });
    const md = new Markdown("", 1, 0, markdownTheme);
    this.currentStreamingId = id;
    this.currentStreamingComponent = md;
    this.components.push(md);
    this._isConnecting = true;
    this.connectingFrame = 0;
    return id;
  }
  appendToAssistant(chunk) {
    if (!this.currentStreamingId)
      return;
    this._isConnecting = false;
    const msg = this.messages.find((m) => m.id === this.currentStreamingId);
    if (msg) {
      msg.content += chunk;
      if (this.currentStreamingComponent) {
        this.currentStreamingComponent.setText(msg.content);
      }
    }
  }
  updateAssistantFull(fullContent) {
    if (!this.currentStreamingId)
      return;
    this._isConnecting = false;
    const msg = this.messages.find((m) => m.id === this.currentStreamingId);
    if (msg) {
      msg.content = fullContent;
      if (this.currentStreamingComponent) {
        this.currentStreamingComponent.setText(fullContent);
      }
    }
  }
  /**
   * Drain completed tools from the tracker and insert them as permanent
   * bullet-point Text components above the streaming assistant response.
   */
  drainCompletedTools() {
    const completed = this.toolTracker.drainCompleted();
    if (completed.length === 0)
      return;
    for (const line of completed) {
      const comp = new Text(line, 0, 0);
      if (this.currentStreamingComponent) {
        const idx = this.components.indexOf(this.currentStreamingComponent);
        if (idx >= 0) {
          this.components.splice(idx, 0, comp);
          continue;
        }
      }
      this.components.push(comp);
    }
  }
  finalizeAssistant() {
    if (!this.currentStreamingId)
      return;
    const msg = this.messages.find((m) => m.id === this.currentStreamingId);
    if (msg) {
      msg.isStreaming = false;
    }
    this.toolTracker.finalizeAll();
    this.drainCompletedTools();
    this.currentStreamingId = null;
    this.currentStreamingComponent = null;
    this._isConnecting = false;
    this.thinkingDisplay.clear();
    this.toolTracker.clear();
  }
  clear() {
    this.messages = [];
    this.components = [];
    this.currentStreamingId = null;
    this.currentStreamingComponent = null;
    this._isConnecting = false;
    this.thinkingDisplay.clear();
    this.toolTracker.clear();
  }
  /**
   * Render an info/status section (thinking + tools) as a single Text component.
   * Returns the component to display, or null if nothing to show.
   */
  renderInfoSection() {
    const lines = [];
    if (this._isConnecting) {
      const frame = colors.accent(this.connectingFrames[this.connectingFrame]);
      lines.push(`  ${frame} ${colors.textDim("streaming...")}`);
    }
    const thinkingLine = this.thinkingDisplay.renderLine();
    if (thinkingLine) {
      lines.push(thinkingLine);
    }
    const toolLines = this.toolTracker.renderLines();
    lines.push(...toolLines);
    if (lines.length === 0) {
      return null;
    }
    this.infoText.setText(lines.join("\n"));
    return this.infoText;
  }
};

// dist/components/attachment-bar.js
import { readFileSync } from "node:fs";
import { basename as basename4, extname } from "node:path";
var IMAGE_EXTENSIONS = /* @__PURE__ */ new Set([
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".webp",
  ".bmp",
  ".svg",
  ".tiff"
]);
function mimeForExt(ext) {
  switch (ext) {
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    case ".gif":
      return "image/gif";
    case ".webp":
      return "image/webp";
    case ".bmp":
      return "image/bmp";
    case ".svg":
      return "image/svg+xml";
    case ".tiff":
      return "image/tiff";
    default:
      return "image/png";
  }
}
var AttachmentBar = class {
  attachments = [];
  addedPaths = /* @__PURE__ */ new Set();
  textComponent;
  imageComponent = null;
  constructor() {
    this.textComponent = new Text("", 1, 0);
  }
  get items() {
    return this.attachments;
  }
  get hasItems() {
    return this.attachments.length > 0;
  }
  addFile(filePath) {
    if (this.addedPaths.has(filePath))
      return false;
    const ext = extname(filePath).toLowerCase();
    const isImage = IMAGE_EXTENSIONS.has(ext);
    let base64;
    let mimeType;
    if (isImage) {
      try {
        base64 = readFileSync(filePath).toString("base64");
        mimeType = mimeForExt(ext);
      } catch {
      }
    }
    const att = {
      id: `att-${Date.now()}`,
      path: filePath,
      name: basename4(filePath),
      isImage,
      base64,
      mimeType
    };
    this.attachments.push(att);
    this.addedPaths.add(filePath);
    this.updateImageComponent();
    return true;
  }
  removeLast() {
    const removed = this.attachments.pop();
    if (removed) {
      this.addedPaths.delete(removed.path);
      this.updateImageComponent();
    }
    return removed ?? null;
  }
  clear() {
    this.attachments = [];
    this.addedPaths.clear();
    this.imageComponent = null;
  }
  /** Get image data for sending to the API. */
  getImages() {
    const images = [];
    for (const att of this.attachments) {
      if (att.isImage && att.base64) {
        const ext = extname(att.path).toLowerCase().replace(".", "");
        const format = ext === "jpg" ? "jpeg" : ext || "png";
        images.push({ data: att.base64, format });
      }
    }
    return images;
  }
  updateImageComponent() {
    const lastImage = [...this.attachments].reverse().find((a) => a.isImage && a.base64 && a.mimeType);
    if (lastImage?.base64 && lastImage.mimeType) {
      this.imageComponent = new Image(lastImage.base64, lastImage.mimeType, {
        fallbackColor: colors.textDim
      }, {
        maxHeightCells: 6,
        maxWidthCells: 40,
        filename: lastImage.name
      });
    } else {
      this.imageComponent = null;
    }
  }
  /** Return components to render (image preview + text label). */
  getComponents() {
    if (this.attachments.length === 0)
      return [];
    const parts = [];
    parts.push(colors.textDim("  Attachments: "));
    for (const att of this.attachments) {
      const name = att.name.length > 25 ? att.name.slice(0, 22) + "..." : att.name;
      if (att.isImage) {
        parts.push(colors.toolDone(name));
      } else {
        parts.push(colors.toolRunning(name));
      }
      parts.push("  ");
    }
    parts.push(colors.textDim("(Ctrl+X remove)"));
    this.textComponent.setText(parts.join(""));
    const components = [];
    if (this.imageComponent) {
      components.push(this.imageComponent);
    }
    components.push(this.textComponent);
    return components;
  }
};

// dist/components/chat-view.js
var PromptedEditor = class {
  editor;
  constructor(editor) {
    this.editor = editor;
    this.editor.setPaddingX(2);
  }
  render(width) {
    const lines = this.editor.render(width);
    if (lines.length >= 3) {
      const prompt = colors.accentBright("\u276F");
      lines[1] = prompt + lines[1].slice(1);
    }
    return lines;
  }
  invalidate() {
    this.editor.invalidate();
  }
};
var ChatView = class {
  container;
  statusBar;
  messageList;
  editor;
  attachmentBar;
  tui;
  promptedEditor;
  spacer;
  bottomSpacer;
  onSubmit;
  /** Inline picker component shown above the editor when active */
  _inlinePicker = null;
  constructor(options3) {
    this.onSubmit = options3.onSubmit;
    this.tui = options3.tui;
    this.statusBar = new StatusBar({
      model: options3.model,
      mode: options3.mode
    });
    this.messageList = new MessageList();
    this.attachmentBar = new AttachmentBar();
    this.spacer = new Spacer(0);
    this.bottomSpacer = new Spacer(0);
    this.editor = new Editor(options3.tui, editorTheme);
    this.editor.onSubmit = (text) => {
      const trimmed = text.trim();
      if (trimmed) {
        this.editor.setText("");
        this.onSubmit(trimmed);
      }
    };
    this.promptedEditor = new PromptedEditor(this.editor);
    this.container = new Container();
    this.rebuildLayout();
  }
  get inlinePicker() {
    return this._inlinePicker;
  }
  setInlinePicker(picker) {
    this._inlinePicker = picker;
  }
  rebuildLayout() {
    this.container.clear();
    const width = this.tui.terminal.columns;
    const terminalHeight = this.tui.terminal.rows;
    const topChildren = [];
    topChildren.push(this.statusBar.component);
    for (const comp of this.messageList.allComponents) {
      topChildren.push(comp);
    }
    const infoSection = this.messageList.renderInfoSection();
    if (infoSection) {
      topChildren.push(infoSection);
    }
    let topLines = 0;
    for (const child of topChildren) {
      topLines += child.render(width).length;
    }
    const attachmentComponents = this.attachmentBar.getComponents();
    let attachmentLines = 0;
    for (const comp of attachmentComponents) {
      attachmentLines += comp.render(width).length;
    }
    const pickerLines = this._inlinePicker ? this._inlinePicker.render(width).length : 0;
    const editorLines = this.promptedEditor.render(width).length;
    const bottomPadding = editorLines;
    const bottomLines = pickerLines + attachmentLines + editorLines + bottomPadding;
    const spacerLines = Math.max(0, terminalHeight - topLines - bottomLines);
    this.spacer.setLines(spacerLines);
    for (const child of topChildren) {
      this.container.addChild(child);
    }
    this.container.addChild(this.spacer);
    if (this._inlinePicker) {
      this.container.addChild(this._inlinePicker);
    }
    for (const comp of attachmentComponents) {
      this.container.addChild(comp);
    }
    this.container.addChild(this.promptedEditor);
    this.bottomSpacer.setLines(bottomPadding);
    this.container.addChild(this.bottomSpacer);
  }
};

// dist/components/monitor-view.js
var MonitorView = class {
  botUsername;
  constructor(options3 = {}) {
    this.botUsername = options3.botUsername ?? "unknown";
  }
  render(width) {
    const lines = [];
    const midWidth = Math.min(40, width - 4);
    const pad = (text) => `  ${text}`;
    const termRows = process.stdout.rows || 24;
    const cardHeight = 9;
    const topPad = Math.max(1, Math.floor((termRows - cardHeight) / 2));
    for (let i = 0; i < topPad; i++)
      lines.push("");
    const hLine = "\u2500".repeat(midWidth);
    lines.push(pad(colors.textDim(`\u256D${hLine}\u256E`)));
    lines.push(pad(colors.textDim("\u2502") + centerText(colors.accentBright("EmDash is live on Telegram"), midWidth) + colors.textDim("\u2502")));
    lines.push(pad(colors.textDim("\u2502") + centerText(`Bot: @${this.botUsername}`, midWidth) + colors.textDim("\u2502")));
    lines.push(pad(colors.textDim("\u2502") + centerText(colors.success("Status: Connected") + " " + colors.success("\u25CF"), midWidth) + colors.textDim("\u2502")));
    lines.push(pad(colors.textDim("\u2502") + " ".repeat(midWidth) + colors.textDim("\u2502")));
    lines.push(pad(colors.textDim("\u2502") + centerText(colors.textDim("Press Ctrl+Q to quit"), midWidth) + colors.textDim("\u2502")));
    lines.push(pad(colors.textDim(`\u2570${hLine}\u256F`)));
    return lines;
  }
  handleInput(data) {
  }
  invalidate() {
  }
};
function centerText(text, width) {
  const visible = stripAnsi(text).length;
  const total = Math.max(0, width - visible);
  const left = Math.floor(total / 2);
  const right = total - left;
  return " ".repeat(left) + text + " ".repeat(right);
}
function stripAnsi(str) {
  return str.replace(/\x1b\[[0-9;]*m/g, "");
}

// dist/channel-wizard.js
var pickerTheme = {
  selectedPrefix: (t) => colors.accentBright(t),
  selectedText: (t) => colors.accentBright(t),
  description: (t) => colors.textDim(t),
  scrollInfo: (t) => colors.textDim(t),
  noMatch: (t) => colors.textDim(t)
};
async function runChannelWizard(tui, sseClient, baseUrl, preselectedChannel) {
  const channel = preselectedChannel ?? await showChannelPicker(tui);
  if (channel === "cli") {
    return { channel: "cli", connected: false };
  }
  let status;
  try {
    status = await fetchJson(`${baseUrl}/api/channels/telegram/status`);
  } catch {
    return { channel: "cli", connected: false };
  }
  if (status.configured && status.connected) {
    return { channel: "telegram", connected: true, botUsername: status.bot_username ?? void 0 };
  }
  if (status.configured && !status.connected) {
    showMessage(tui, "Connecting to Telegram...");
    try {
      const connectResult = await postJson(`${baseUrl}/api/channels/telegram/connect`, { agent_type: "open" });
      clearWizard(tui);
      if (connectResult.status === "connected") {
        return { channel: "telegram", connected: true, botUsername: status.bot_username ?? void 0 };
      }
      if (connectResult.error) {
        const retry = await showRetryPrompt(tui, connectResult.error);
        if (!retry)
          return { channel: "cli", connected: false };
      }
    } catch (err) {
      clearWizard(tui);
      const retry = await showRetryPrompt(tui, err instanceof Error ? err.message : "Connection failed");
      if (!retry)
        return { channel: "cli", connected: false };
    }
  }
  const setupResult = await showSetupWizard(tui, baseUrl);
  if (!setupResult) {
    return { channel: "cli", connected: false };
  }
  showMessage(tui, `Bot @${setupResult.botUsername} verified! Connecting...`);
  try {
    await postJson(`${baseUrl}/api/channels/telegram/connect`, { agent_type: "open" });
  } catch {
  }
  clearWizard(tui);
  return { channel: "telegram", connected: true, botUsername: setupResult.botUsername };
}
function showChannelPicker(tui) {
  return new Promise((resolve) => {
    const title = new Text(colors.accentBright("  How do you want to chat?"));
    const items = [
      { value: "cli", label: "CLI", description: "Chat right here in the terminal (default)" },
      { value: "telegram", label: "Telegram", description: "Chat on Telegram via a bot" }
    ];
    const list2 = new SelectList(items, 4, pickerTheme);
    const wrapper = new Container();
    wrapper.addChild(title);
    wrapper.addChild(list2);
    list2.onSelect = (item) => {
      clearWizard(tui);
      resolve(item.value);
    };
    setWizardComponent(tui, wrapper, list2);
  });
}
async function showSetupWizard(tui, baseUrl) {
  while (true) {
    const token = await showTokenInput(tui);
    if (!token)
      return null;
    showMessage(tui, "Verifying token...");
    let result;
    try {
      result = await postJson(`${baseUrl}/api/channels/telegram/setup`, { bot_token: token });
    } catch (err) {
      result = { success: false, bot_username: null, error: err instanceof Error ? err.message : "Request failed" };
    }
    if (result.success && result.bot_username) {
      return { botUsername: result.bot_username };
    }
    clearWizard(tui);
    const retry = await showRetryPrompt(tui, result.error ?? "Verification failed");
    if (!retry)
      return null;
  }
}
function showTokenInput(tui) {
  return new Promise((resolve) => {
    const wrapper = new Container();
    wrapper.addChild(new Text(""));
    wrapper.addChild(new Text(colors.accentBright("  Telegram Setup")));
    wrapper.addChild(new Text(""));
    wrapper.addChild(new Text(colors.text("  1. Open Telegram and search for @BotFather")));
    wrapper.addChild(new Text(colors.text("  2. Send /newbot and follow the prompts")));
    wrapper.addChild(new Text(colors.text("  3. Copy the bot token and paste it below")));
    wrapper.addChild(new Text(""));
    wrapper.addChild(new Text(colors.textDim("  Paste your bot token (Esc to go back):")));
    const input = new Input();
    wrapper.addChild(input);
    input.onSubmit = (value) => {
      const trimmed = value.trim();
      clearWizard(tui);
      resolve(trimmed || null);
    };
    input.onEscape = () => {
      clearWizard(tui);
      resolve(null);
    };
    setWizardComponent(tui, wrapper, input);
  });
}
function showRetryPrompt(tui, error) {
  return new Promise((resolve) => {
    const wrapper = new Container();
    wrapper.addChild(new Text(""));
    wrapper.addChild(new Text(colors.error(`  Error: ${error}`)));
    wrapper.addChild(new Text(""));
    const items = [
      { value: "retry", label: "Try again", description: "Enter a different token" },
      { value: "cancel", label: "Cancel", description: "Use CLI instead" }
    ];
    const list2 = new SelectList(items, 4, pickerTheme);
    wrapper.addChild(list2);
    list2.onSelect = (item) => {
      clearWizard(tui);
      resolve(item.value === "retry");
    };
    setWizardComponent(tui, wrapper, list2);
  });
}
var _wizardComponent = null;
function setWizardComponent(tui, wrapper, focusTarget) {
  clearWizard(tui);
  _wizardComponent = wrapper;
  tui.addChild(wrapper);
  tui.setFocus(focusTarget);
  tui.requestRender();
}
function clearWizard(tui) {
  if (_wizardComponent) {
    tui.removeChild(_wizardComponent);
    _wizardComponent = null;
    tui.requestRender();
  }
}
function showMessage(tui, message) {
  clearWizard(tui);
  const wrapper = new Container();
  wrapper.addChild(new Text(""));
  wrapper.addChild(new Text(colors.accentBright(`  ${message}`)));
  _wizardComponent = wrapper;
  tui.addChild(wrapper);
  tui.requestRender();
}
async function fetchJson(url) {
  const resp = await fetch(url, { headers: { "Content-Type": "application/json" } });
  if (!resp.ok)
    throw new Error(`HTTP ${resp.status}`);
  return resp.json();
}
async function postJson(url, body) {
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body !== void 0 ? JSON.stringify(body) : void 0
  });
  if (!resp.ok)
    throw new Error(`HTTP ${resp.status}`);
  return resp.json();
}

// dist/models.js
var providers = [
  {
    name: "OpenAI",
    prefix: "openai:",
    models: [
      { id: "gpt-4o-mini", label: "GPT-4o Mini" }
    ]
  },
  {
    name: "Fireworks AI",
    prefix: "fireworks:",
    models: [
      { id: "minimax", label: "MiniMax M2P1" },
      { id: "glm-4p7", label: "GLM 4P7" },
      { id: "deepseek-v3p2", label: "DeepSeek V3P2" },
      { id: "kimi-k2p5", label: "Kimi K2P5" },
      { id: "kimi-k2-thinking", label: "Kimi K2 Thinking" },
      { id: "kimi-k2-instruct", label: "Kimi K2 Instruct" },
      { id: "qwen3-vl-thinking", label: "Qwen3 VL Thinking" },
      { id: "qwen3-vl-instruct", label: "Qwen3 VL Instruct" },
      { id: "qwen3-coder", label: "Qwen3 Coder 480B" },
      { id: "gpt-oss-120b", label: "GPT-OSS 120B" },
      { id: "gpt-oss-20b", label: "GPT-OSS 20B" }
    ]
  }
];

// dist/clipboard.js
import { execFileSync, execSync as execSync3 } from "node:child_process";
import { existsSync as existsSync2, unlinkSync, statSync as statSync2 } from "node:fs";
import { tmpdir } from "node:os";
import { join as join4 } from "node:path";
var TEMP_PATH = join4(tmpdir(), `clipboard-${process.pid}.png`);
function copyToClipboard(text) {
  const platform = process.platform;
  try {
    if (platform === "darwin") {
      execFileSync("pbcopy", { input: text, timeout: 3e3, stdio: ["pipe", "pipe", "pipe"] });
      return true;
    } else if (platform === "win32") {
      execFileSync("clip", { input: text, timeout: 3e3, stdio: ["pipe", "pipe", "pipe"] });
      return true;
    } else {
      for (const [cmd, ...args] of [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"]
      ]) {
        try {
          execFileSync(cmd, args, { input: text, timeout: 3e3, stdio: ["pipe", "pipe", "pipe"] });
          return true;
        } catch {
          continue;
        }
      }
    }
  } catch {
  }
  return false;
}
function getLocalIP() {
  const { networkInterfaces } = __require("node:os");
  const nets = networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] ?? []) {
      if (net.family === "IPv4" && !net.internal) {
        return net.address;
      }
    }
  }
  return "localhost";
}
function detectClipboardImage() {
  const platform = process.platform;
  if (platform === "darwin") {
    return clipboardImageMacOS();
  } else if (platform === "linux") {
    return clipboardImageLinux();
  }
  return null;
}
function clipboardImageMacOS() {
  try {
    if (existsSync2(TEMP_PATH)) {
      unlinkSync(TEMP_PATH);
    }
    const script = [
      'use framework "AppKit"',
      "set pb to current application's NSPasteboard's generalPasteboard()",
      `set imgData to pb's dataForType:"public.png"`,
      "if imgData is missing value then",
      `    set imgData to pb's dataForType:"public.tiff"`,
      "end if",
      "if imgData is not missing value then",
      `    (imgData's writeToFile:"${TEMP_PATH}" atomically:true)`,
      '    return "ok"',
      "end if",
      'return "no"'
    ].join("\n");
    const result = execFileSync("osascript", ["-"], {
      input: script,
      timeout: 5e3,
      encoding: "utf-8",
      stdio: ["pipe", "pipe", "pipe"]
    });
    if (result.includes("ok") && existsSync2(TEMP_PATH) && statSync2(TEMP_PATH).size > 0) {
      return TEMP_PATH;
    }
  } catch {
  }
  return null;
}
function clipboardImageLinux() {
  try {
    const targets = execFileSync("xclip", ["-selection", "clipboard", "-t", "TARGETS", "-o"], { timeout: 2e3, encoding: "utf-8", stdio: ["pipe", "pipe", "pipe"] });
    if (targets.includes("image/png")) {
      execSync3(`xclip -selection clipboard -t image/png -o > "${TEMP_PATH}"`, { timeout: 3e3, stdio: ["pipe", "pipe", "pipe"] });
      if (existsSync2(TEMP_PATH) && statSync2(TEMP_PATH).size > 0) {
        return TEMP_PATH;
      }
    }
  } catch {
  }
  return null;
}

// dist/app.js
var IMAGE_EXTENSIONS2 = /* @__PURE__ */ new Set([
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".webp",
  ".bmp",
  ".svg",
  ".tiff"
]);
function resolveImagePath(text) {
  const trimmed = text.trim();
  if (!trimmed)
    return null;
  let filePath = trimmed.replace(/\\ /g, " ");
  if (filePath.startsWith("~")) {
    filePath = filePath.replace(/^~/, process.env.HOME ?? "");
  }
  const ext = extname2(filePath).toLowerCase();
  if (!IMAGE_EXTENSIONS2.has(ext))
    return null;
  if (existsSync3(filePath))
    return filePath;
  return null;
}
function findFdPath() {
  for (const name of ["fd", "fdfind"]) {
    try {
      const p = execSync4(`which ${name}`, { encoding: "utf-8", timeout: 2e3 }).trim();
      if (p)
        return p;
    } catch {
    }
  }
  return null;
}
function clearConversationMemoryFiles() {
  const removed = [];
  const configuredPath = process.env.EMDASH_CONVERSATION_FILE_PATH?.trim();
  const defaultPath = join5(process.cwd(), ".emdash", "memory", "conversation.json");
  const candidatePaths = configuredPath ? [isAbsolute(configuredPath) ? configuredPath : join5(process.cwd(), configuredPath), defaultPath] : [defaultPath];
  for (const path2 of candidatePaths) {
    try {
      if (existsSync3(path2)) {
        unlinkSync2(path2);
        removed.push(path2);
      }
    } catch {
    }
  }
  return removed;
}
var RootComponent = class {
  chatView;
  onQuit;
  onCancel;
  onEscape;
  onPaste;
  getActivePicker;
  onInputIntercept;
  constructor(chatView, onQuit, onCancel, onEscape, onPaste, getActivePicker, onInputIntercept) {
    this.chatView = chatView;
    this.onQuit = onQuit;
    this.onCancel = onCancel;
    this.onEscape = onEscape;
    this.onPaste = onPaste;
    this.getActivePicker = getActivePicker;
    this.onInputIntercept = onInputIntercept;
  }
  render(width) {
    return this.chatView.container.render(width);
  }
  handleInput(data) {
    if (data === "") {
      this.onQuit();
      return;
    }
    if (data === "") {
      this.onCancel();
      return;
    }
    if (data === "") {
      this.onPaste();
      return;
    }
    if (data === "" && this.chatView.attachmentBar.hasItems) {
      this.chatView.attachmentBar.removeLast();
      this.chatView.rebuildLayout();
      return;
    }
    const picker = this.getActivePicker();
    if (picker) {
      picker.handleInput(data);
      return;
    }
    if (this.onInputIntercept(data))
      return;
    if (data === "\x1B") {
      if (this.chatView.editor.isShowingAutocomplete()) {
        this.chatView.editor.handleInput(data);
        return;
      }
      this.onEscape();
      return;
    }
    if (data.includes("\x1B[200~")) {
      const pasteContent = data.replace("\x1B[200~", "").replace("\x1B[201~", "");
      if (pasteContent.trim() === "") {
        this.onPaste();
        return;
      }
      const imagePath = resolveImagePath(pasteContent);
      if (imagePath) {
        this.chatView.attachmentBar.addFile(imagePath);
        this.chatView.rebuildLayout();
        return;
      }
    }
    this.chatView.editor.handleInput(data);
  }
  invalidate() {
    this.chatView.container.invalidate();
  }
};
var pickerTheme2 = {
  selectedPrefix: (t) => colors.accentBright(t),
  selectedText: (t) => colors.accentBright(t),
  description: (t) => colors.textDim(t),
  scrollInfo: (t) => colors.textDim(t),
  noMatch: (t) => colors.textDim(t)
};
var SLASH_COMMANDS = [
  { value: "help", label: "help", description: "Show available commands" },
  { value: "clear", label: "clear", description: "Clear chat and start new session" },
  { value: "reset", label: "reset", description: "Reset session" },
  { value: "mode", label: "mode", description: "Switch mode" },
  { value: "plan", label: "plan", description: "Switch to plan mode" },
  { value: "code", label: "code", description: "Switch to code mode" },
  { value: "model", label: "model", description: "Switch model by name" },
  { value: "models", label: "models", description: "Interactive model picker" },
  { value: "stats", label: "stats", description: "Show token usage stats" },
  { value: "todos", label: "todos", description: "List todos" },
  { value: "todo-add", label: "todo-add", description: "Add a todo item" },
  { value: "compact", label: "compact", description: "Compact session context" },
  { value: "messages", label: "messages", description: "Show recent messages" },
  { value: "context", label: "context", description: "Show session context info" },
  { value: "diff", label: "diff", description: "Show git diff stats" },
  { value: "status", label: "status", description: "Show index status" },
  { value: "doctor", label: "doctor", description: "Check backend health" },
  { value: "copy", label: "copy", description: "Copy last response to clipboard" },
  { value: "copy all", label: "copy all", description: "Copy entire conversation" },
  { value: "export", label: "export", description: "Export session data" },
  { value: "share", label: "share", description: "Create shareable session" },
  { value: "join", label: "join", description: "Join a shared session" },
  { value: "leave", label: "leave", description: "Leave shared session" },
  { value: "who", label: "who", description: "Show session participants" },
  { value: "invite", label: "invite", description: "Show invite code" },
  { value: "team", label: "team", description: "Agent Team orchestration" },
  { value: "team-old", label: "team-old", description: "Legacy team management" },
  { value: "pr", label: "pr", description: "Review a pull request" },
  { value: "research", label: "research", description: "Deep research a topic" },
  { value: "skills", label: "skills", description: "Manage skills" },
  { value: "agents", label: "agents", description: "Manage agents" },
  { value: "rules", label: "rules", description: "Manage rules" },
  { value: "hooks", label: "hooks", description: "Manage hooks" },
  { value: "verifiers", label: "verifiers", description: "Manage verifiers" },
  { value: "registry", label: "registry", description: "Browse community registry" },
  { value: "quit", label: "quit", description: "Quit the TUI" },
  { value: "exit", label: "exit", description: "Quit the TUI" }
];
function generateUserId() {
  const user = process.env.USER ?? process.env.USERNAME ?? "user";
  const host = hostname();
  const pid = process.pid;
  return createHash("sha256").update(`${user}@${host}:${pid}`).digest("hex").slice(0, 16);
}
function getDisplayName() {
  const user = process.env.USER ?? process.env.USERNAME ?? "user";
  return `${user}@${hostname()}`;
}
var App = class {
  terminal;
  tui;
  sseClient;
  serverManager;
  chatView;
  sessionId = null;
  tickInterval = null;
  options;
  activePickerList = null;
  activeInputComponent = null;
  // Multiuser state
  multiuserSessionId = null;
  multiuserUserId = null;
  multiuserServerUrl = null;
  multiuserIsOwner = false;
  constructor(options3 = {}) {
    this.options = options3;
    this.serverManager = new ServerManager({ port: options3.port, logs: options3.logs });
  }
  async run() {
    let baseUrl;
    try {
      const cols = process.stdout.columns || 80;
      const rows = process.stdout.rows || 24;
      process.stdout.write("\x1B[?25l");
      const SPINNER = ["\u280B", "\u2819", "\u2839", "\u2838", "\u283C", "\u2834", "\u2826", "\u2827", "\u2807", "\u280F"];
      const BAR_WIDTH = Math.min(32, cols - 10);
      const MAX_SECS = 15;
      baseUrl = await this.serverManager.ensureServer((elapsed, frame) => {
        const spin = colors.accent(SPINNER[frame % SPINNER.length]);
        const label = colors.accentBright("emdash");
        const status = colors.textDim(`Starting server${".".repeat(frame % 3 + 1).padEnd(3)}`);
        const time = colors.textDim(`${elapsed.toFixed(1)}s`);
        const progress = Math.min(elapsed / MAX_SECS, 1);
        const filled = Math.round(progress * BAR_WIDTH);
        const empty = BAR_WIDTH - filled;
        const bar = colors.accent("\u2501".repeat(filled)) + colors.textMuted("\u2501".repeat(empty));
        const midRow = Math.floor(rows / 2) - 1;
        const line1 = `${spin} ${label}`;
        const line2 = `  ${status} ${time}`;
        const line3 = `  ${bar}`;
        process.stdout.write(`\x1B[${midRow};1H\x1B[2K${line1}
\x1B[2K${line2}
\x1B[2K${line3}`);
      });
      process.stdout.write("\x1B[?25h\x1B[2J\x1B[H");
    } catch (err) {
      process.stdout.write("\x1B[?25h");
      console.error(`Failed to connect to emdash server: ${err instanceof Error ? err.message : err}`);
      process.exit(1);
    }
    this.sseClient = new SSEClient({
      baseUrl,
      agentMode: this.options.mode ?? "code",
      model: this.options.model ?? "",
      maxIterations: 100,
      agentType: this.options.agentType ?? "coding"
    });
    this.terminal = new ProcessTerminal();
    this.tui = new TUI(this.terminal);
    if (this.options.agentType === "open") {
      if (!await this.serverManager.hasRoute("/api/channels/telegram/status")) {
        process.stdout.write("\x1B[?25l");
        const cols = process.stdout.columns || 80;
        const rows = process.stdout.rows || 24;
        const midRow = Math.floor(rows / 2) - 1;
        process.stdout.write(`\x1B[${midRow};1H\x1B[2K  ${colors.accentBright("emdash")} ${colors.textDim("Restarting server...")}
`);
        try {
          baseUrl = await this.serverManager.forceRestart();
          this.sseClient = new SSEClient({
            baseUrl,
            agentMode: this.options.mode ?? "code",
            model: this.options.model ?? "",
            maxIterations: 100,
            agentType: this.options.agentType ?? "coding"
          });
        } catch {
        }
        process.stdout.write("\x1B[?25h\x1B[2J\x1B[H");
      }
      this.tui.start();
      const wizardResult = await runChannelWizard(this.tui, this.sseClient, baseUrl, this.options.channel);
      this.tui.stop();
      if (wizardResult.channel === "telegram" && wizardResult.connected) {
        process.stdout.write("\x1B[2J\x1B[H");
        const terminal2 = new ProcessTerminal();
        const tui2 = new TUI(terminal2);
        this.showMonitorView(tui2, wizardResult.botUsername);
        await new Promise(() => {
        });
        return;
      }
      this.terminal = new ProcessTerminal();
      this.tui = new TUI(this.terminal);
    }
    this.chatView = new ChatView({
      tui: this.tui,
      onSubmit: (text) => this.handleInput(text),
      model: this.options.model ?? "",
      mode: this.options.mode ?? "code"
    });
    const fdPath = findFdPath();
    const slashCommands = await this.loadSlashCommands();
    const inner = new CombinedAutocompleteProvider(slashCommands, process.cwd(), fdPath);
    const autocomplete = new EmdashAutocompleteProvider(inner, process.cwd(), !!fdPath);
    this.chatView.editor.setAutocompleteProvider(autocomplete);
    this.chatView.editor.onChange = (text) => {
      if (!text.includes("\n")) {
        const imagePath = resolveImagePath(text);
        if (imagePath) {
          this.chatView.attachmentBar.addFile(imagePath);
          this.chatView.editor.setText("");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
        }
      }
    };
    const root = new RootComponent(this.chatView, () => this.shutdown(), () => {
      if (this.activePickerList || this.activeInputComponent) {
        this.dismissPicker();
        return;
      }
      if (this.sseClient.isStreaming) {
        this.sseClient.abort();
        this.chatView.statusBar.update({ status: "Cancelled", isStreaming: false });
        this.chatView.messageList.finalizeAssistant();
        this.chatView.rebuildLayout();
        this.tui.requestRender();
      } else {
        this.shutdown();
      }
    }, () => {
      if (this.sseClient.isStreaming) {
        this.sseClient.abort();
        this.chatView.statusBar.update({ status: "Cancelled", isStreaming: false });
        this.chatView.messageList.finalizeAssistant();
        this.chatView.rebuildLayout();
        this.tui.requestRender();
      }
    }, () => {
      const imagePath = detectClipboardImage();
      if (imagePath) {
        this.chatView.attachmentBar.addFile(imagePath);
        this.chatView.rebuildLayout();
        this.tui.requestRender();
      } else {
        this.chatView.editor.handleInput("");
      }
    }, () => this.activePickerList ?? this.activeInputComponent, (data) => this.handleInputIntercept(data));
    this.tui.addChild(root);
    this.wireSSEEvents();
    this.tui.start();
    this.tui.setFocus(root);
    this.tickInterval = setInterval(() => {
      this.chatView.statusBar.tick();
      this.chatView.messageList.tickBanner();
      this.chatView.messageList.tickConnecting();
      this.chatView.messageList.thinking.tick();
      this.chatView.messageList.tools.tick();
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    }, 100);
    let version = "dev";
    try {
      const res = await fetch(`${baseUrl}/api/health`);
      if (res.ok) {
        const health = await res.json();
        if (health.version)
          version = health.version;
      }
    } catch {
    }
    {
      const home = process.env.HOME || process.env.USERPROFILE || "";
      const cwd = process.cwd();
      const lines = [];
      const envConfig = process.env.EMDASH_CONFIG || process.env.EMDASH_MODEL_CONFIG;
      const candidates = [
        envConfig,
        join5(cwd, ".emdash", "config.json"),
        join5(home, ".emdash", "config.json")
      ].filter(Boolean);
      let modelConfigPath = "(bundled default)";
      let modelData = null;
      for (const p of candidates) {
        if (existsSync3(p)) {
          modelConfigPath = p;
          break;
        }
      }
      try {
        const raw = readFileSync2(modelConfigPath === "(bundled default)" ? "" : modelConfigPath, "utf-8");
        modelData = JSON.parse(raw);
      } catch {
      }
      lines.push(`Model config: ${modelConfigPath}`);
      if (modelData) {
        const models = Object.keys(modelData.providers ?? {}).flatMap((p) => Object.keys(modelData.providers[p].models ?? {}));
        lines.push(`Models (${models.length}): ${models.join(", ")}`);
        if (modelData.default_model)
          lines.push(`Default: ${modelData.default_model}`);
      }
      const envPaths = [
        join5(home, ".emdash", ".env"),
        join5(cwd, ".emdash", ".env"),
        join5(cwd, ".env")
      ];
      const loadedEnvs = envPaths.filter((p) => existsSync3(p));
      lines.push(`Env: ${loadedEnvs.length > 0 ? loadedEnvs.join(", ") : "none"}`);
      const keyNames = ["FIREWORKS_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"];
      const keySources = [];
      for (const envPath of loadedEnvs) {
        try {
          const content = readFileSync2(envPath, "utf-8");
          for (const key of keyNames) {
            const match = content.match(new RegExp(`^${key}=(.+)`, "m"));
            if (match) {
              const val = match[1].trim().replace(/^["']|["']$/g, "");
              const masked = val.length > 8 ? `${val.slice(0, 4)}...${val.slice(-4)}` : "***";
              keySources.push(`${key}=${masked} (from ${envPath.split("/").slice(-2).join("/")})`);
            }
          }
        } catch {
        }
      }
      for (const key of keyNames) {
        if (process.env[key] && !keySources.some((s) => s.startsWith(key))) {
          const val = process.env[key];
          const masked = val.length > 8 ? `${val.slice(0, 4)}...${val.slice(-4)}` : "***";
          keySources.push(`${key}=${masked} (from shell env)`);
        }
      }
      lines.push(`API keys: ${keySources.length > 0 ? keySources.join(", ") : "none found"}`);
      const agentType = this.options.agentType ?? "coding";
      const emdashDir = existsSync3(join5(cwd, ".emdash")) ? join5(cwd, ".emdash") : join5(home, ".emdash");
      const convPath = join5(emdashDir, "memory", "conversation.json");
      const msgCount = existsSync3(convPath) ? (() => {
        try {
          return JSON.parse(readFileSync2(convPath, "utf-8")).message_count ?? 0;
        } catch {
          return 0;
        }
      })() : 0;
      lines.push(`Conversation: ${convPath} (${msgCount} messages)`);
      lines.push(`Mode: ${agentType}`);
      const rulesDir = join5(cwd, ".emdash", "rules");
      const globalRulesDir = join5(home, ".emdash", "rules");
      const ruleFiles = [];
      for (const dir of [globalRulesDir, rulesDir]) {
        try {
          if (existsSync3(dir)) {
            const { readdirSync: readdirSync2 } = await import("node:fs");
            for (const f of readdirSync2(dir).sort()) {
              if (f.endsWith(".md"))
                ruleFiles.push(f);
            }
          }
        } catch {
        }
      }
      lines.push(`Rules (${ruleFiles.length}): ${ruleFiles.length > 0 ? ruleFiles.join(", ") : "none"}`);
      const skillsDirs = [
        join5(home, ".emdash", "skills"),
        join5(cwd, ".emdash", "skills")
      ];
      const skillNames = [];
      for (const dir of skillsDirs) {
        try {
          if (existsSync3(dir)) {
            const { readdirSync: readdirSync2, statSync: statSync3 } = await import("node:fs");
            for (const entry of readdirSync2(dir).sort()) {
              const skillMd = join5(dir, entry, "SKILL.md");
              if (statSync3(join5(dir, entry)).isDirectory() && existsSync3(skillMd)) {
                if (!skillNames.includes(entry))
                  skillNames.push(entry);
              }
            }
          }
        } catch {
        }
      }
      lines.push(`Skills (${skillNames.length}): ${skillNames.length > 0 ? skillNames.join(", ") : "none"}`);
      if (this.serverManager.logFile) {
        lines.push(`Server logs: ${this.serverManager.logFile}`);
      }
      this.chatView.messageList.addSystemMessage(lines.join("\n"));
    }
    this.chatView.messageList.startBanner(this.sseClient.model, version);
    this.chatView.rebuildLayout();
    this.tui.requestRender();
    if (this.options.task) {
      this.handleInput(this.options.task);
    }
    await new Promise(() => {
    });
  }
  wireSSEEvents() {
    this.sseClient.on("session_id", (id) => {
      this.sessionId = id;
      this.chatView.statusBar.update({ sessionId: id });
    });
    this.sseClient.on("thinking", (message) => {
      this.chatView.messageList.clearConnecting();
      this.chatView.statusBar.update({ status: "Thinking...", isStreaming: true });
      this.chatView.messageList.thinking.setThinking(message);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("partial_response", (_chunk, fullResponse) => {
      this.chatView.messageList.thinking.clear();
      this.chatView.statusBar.update({ status: "Responding...", isStreaming: true });
      this.chatView.messageList.updateAssistantFull(fullResponse);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("tool_start", (tool) => {
      this.chatView.messageList.clearConnecting();
      if (!tool.subagentId) {
        this.chatView.statusBar.update({
          status: `Running ${tool.name}...`,
          isStreaming: true
        });
      }
      this.chatView.messageList.tools.addTool(tool);
      this.chatView.messageList.drainCompletedTools();
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("tool_result", (tool) => {
      this.chatView.messageList.tools.updateTool(tool);
      this.chatView.messageList.drainCompletedTools();
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("subagent_start", (data) => {
      this.chatView.messageList.clearConnecting();
      this.chatView.statusBar.update({
        status: `${data.agent_type}: ${data.description}`,
        isStreaming: true
      });
      this.chatView.messageList.tools.startSubAgent(data.id, data.agent_type, data.description);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("subagent_end", (data) => {
      this.chatView.messageList.tools.endSubAgent(data.id, data.success, data.execution_time);
      this.chatView.messageList.drainCompletedTools();
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("progress", (message) => {
      this.chatView.statusBar.update({ status: message });
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("error", (error) => {
      this.chatView.statusBar.update({
        status: `Error: ${error}`,
        isStreaming: false
      });
      this.chatView.messageList.addSystemMessage(colors.error(`Error: ${error}`));
      this.chatView.messageList.finalizeAssistant();
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("done", () => {
      this.chatView.statusBar.update({ status: "Ready", isStreaming: false });
      this.chatView.messageList.finalizeAssistant();
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
    this.sseClient.on("plan_mode_requested", (data) => {
      const reason = typeof data.reason === "string" ? data.reason : "The agent wants to enter plan mode.";
      this.chatView.messageList.addSystemMessage(`Plan mode requested: ${reason}`);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      this.showApprovalPicker("Plan Mode Requested", reason, [
        { value: "approve", label: "Approve", description: "Enter plan mode" },
        { value: "reject", label: "Reject", description: "Stay in current mode" },
        { value: "feedback", label: "Give Feedback", description: "Reject with feedback" }
      ]).then(async (choice) => {
        if (!this.sessionId)
          return;
        this.resumeStreaming();
        if (choice === "approve") {
          await this.sseClient.approvePlanMode(this.sessionId);
        } else if (choice === "reject") {
          await this.sseClient.rejectPlanMode(this.sessionId);
        } else if (choice === "feedback") {
          const fb = await this.showFeedbackInput("Enter feedback for plan mode rejection:");
          this.resumeStreaming();
          await this.sseClient.rejectPlanMode(this.sessionId, fb);
        }
      });
    });
    this.sseClient.on("plan_submitted", (data) => {
      const planText = typeof data.plan === "string" ? data.plan : typeof data.text === "string" ? data.text : JSON.stringify(data, null, 2);
      this.chatView.messageList.addSystemMessage(`Plan submitted:
${planText}`);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      this.showApprovalPicker("Plan Submitted", "Review the plan above and choose an action.", [
        { value: "approve", label: "Approve", description: "Implement this plan" },
        { value: "reject", label: "Reject", description: "Reject the plan" },
        { value: "feedback", label: "Give Feedback", description: "Request changes" }
      ]).then(async (choice) => {
        if (!this.sessionId)
          return;
        this.resumeStreaming();
        if (choice === "approve") {
          await this.sseClient.approvePlanSubmission(this.sessionId);
        } else if (choice === "reject") {
          await this.sseClient.rejectPlanSubmission(this.sessionId);
        } else if (choice === "feedback") {
          const fb = await this.showFeedbackInput("Enter feedback for plan revision:");
          this.resumeStreaming();
          await this.sseClient.rejectPlanSubmission(this.sessionId, fb);
        }
      });
    });
    this.sseClient.on("choice_questions", (data) => {
      const questions = Array.isArray(data.choices) ? data.choices : Array.isArray(data.questions) ? data.questions : [];
      if (questions.length === 0)
        return;
      for (const q of questions) {
        const header = q.header ? `[${q.header}] ` : "";
        this.chatView.messageList.addSystemMessage(`${header}${q.question}`);
      }
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      const responses = [];
      const processQuestion = async (index) => {
        if (index >= questions.length) {
          if (!this.sessionId)
            return;
          this.resumeStreaming();
          await this.sseClient.answerChoices(this.sessionId, responses);
          return;
        }
        const q = questions[index];
        const options3 = Array.isArray(q.options) ? q.options : [];
        const isMultiSelect = q.multiSelect === true;
        if (isMultiSelect) {
          const selected = /* @__PURE__ */ new Set();
          const buildItems = () => {
            const items = options3.map((opt) => ({
              value: opt.label,
              label: `${selected.has(opt.label) ? "[x]" : "[ ]"} ${opt.label}`,
              description: opt.description
            }));
            items.push({ value: "__submit__", label: "Submit", description: "Confirm selections" });
            return items;
          };
          const showMultiPicker = () => {
            const header = q.header ? `[${q.header}] ` : "";
            this.showApprovalPicker(`${header}${q.question}`, "Toggle options, then select Submit", buildItems()).then((choice) => {
              if (choice === "__submit__") {
                const answers = Array.from(selected);
                responses.push({
                  question: q.question,
                  answers
                });
                this.chatView.messageList.addUserMessage(answers.join(", "));
                this.chatView.rebuildLayout();
                this.tui.requestRender();
                processQuestion(index + 1);
              } else {
                if (selected.has(choice)) {
                  selected.delete(choice);
                } else {
                  selected.add(choice);
                }
                showMultiPicker();
              }
            });
          };
          showMultiPicker();
        } else {
          const header = q.header ? `[${q.header}] ` : "";
          const items = options3.map((opt) => ({
            value: opt.label,
            label: opt.label,
            description: opt.description
          }));
          items.push({ value: "__other__", label: "Other", description: "Enter custom response" });
          const choice = await this.showApprovalPicker(`${header}${q.question}`, "Select an option", items);
          if (choice === "__other__") {
            const customText = await this.showFeedbackInput("Enter your response:");
            responses.push({ question: q.question, answer: customText });
            this.chatView.messageList.addUserMessage(customText);
          } else {
            responses.push({ question: q.question, answer: choice });
            this.chatView.messageList.addUserMessage(choice);
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          await processQuestion(index + 1);
        }
      };
      processQuestion(0);
    });
  }
  async handleInput(text) {
    if (text.startsWith("/")) {
      const handled = await this.handleSlashCommand(text);
      if (handled)
        return;
    }
    const imagePath = resolveImagePath(text);
    if (imagePath) {
      this.chatView.attachmentBar.addFile(imagePath);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      return;
    }
    const images = this.chatView.attachmentBar.getImages();
    this.chatView.attachmentBar.clear();
    this.chatView.messageList.addUserMessage(text);
    this.chatView.messageList.startAssistantMessage();
    this.chatView.statusBar.update({ status: "Connecting...", isStreaming: true });
    this.chatView.rebuildLayout();
    this.tui.requestRender();
    await this.sseClient.sendMessage(text, this.sessionId, images.length > 0 ? images : void 0);
  }
  async handleSlashCommand(text) {
    const parts = text.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    switch (cmd) {
      case "/clear":
        this.chatView.messageList.clear();
        this.sessionId = null;
        this.multiuserSessionId = null;
        this.multiuserUserId = null;
        this.multiuserIsOwner = false;
        this.multiuserServerUrl = null;
        this.chatView.statusBar.update({ sessionId: null, status: "Ready" });
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      case "/reset":
        if (this.sessionId) {
          try {
            await this.sseClient.delete(`/api/agent/sessions/${this.sessionId}`);
          } catch {
          }
        }
        const removedFiles = clearConversationMemoryFiles();
        this.chatView.messageList.clear();
        this.sseClient.abort();
        this.sessionId = null;
        this.multiuserSessionId = null;
        this.multiuserUserId = null;
        this.multiuserIsOwner = false;
        this.multiuserServerUrl = null;
        this.chatView.statusBar.update({ sessionId: null, status: "Ready", isStreaming: false });
        if (removedFiles.length > 0) {
          this.chatView.messageList.addSystemMessage(`Session reset. Cleared ${removedFiles.length} conversation file(s).`);
        } else {
          this.chatView.messageList.addSystemMessage("Session reset.");
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      case "/mode": {
        const newMode = parts[1];
        if (newMode && ["code", "plan", "research", "review", "spec"].includes(newMode)) {
          this.sseClient.mode = newMode;
          this.chatView.statusBar.update({ mode: newMode });
          this.chatView.messageList.addSystemMessage(`Mode switched to ${newMode}`);
        } else {
          this.chatView.messageList.addSystemMessage("Usage: /mode <code|plan|research|review|spec>");
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/plan":
        this.sseClient.mode = "plan";
        this.chatView.statusBar.update({ mode: "plan" });
        this.chatView.messageList.addSystemMessage("Mode switched to plan");
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      case "/code":
        this.sseClient.mode = "code";
        this.chatView.statusBar.update({ mode: "code" });
        this.chatView.messageList.addSystemMessage("Mode switched to code");
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      case "/model": {
        const newModel = parts[1];
        if (newModel) {
          this.sseClient.model = newModel;
          this.chatView.statusBar.update({ model: newModel });
          this.chatView.messageList.addSystemMessage(`Model switched to ${newModel}`);
        } else {
          this.chatView.messageList.addSystemMessage("Usage: /model <model-name>");
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/models":
        this.showProviderPicker();
        return true;
      case "/quit":
      case "/exit":
      case "/q":
        this.shutdown();
        return true;
      case "/diff":
        try {
          const output = execSync4("git diff --stat", { encoding: "utf-8", timeout: 5e3 });
          this.chatView.messageList.addSystemMessage(output.trim() || "No changes.");
        } catch {
          this.chatView.messageList.addSystemMessage("Failed to run git diff.");
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      case "/stats":
        await this.runApiCommand(`/api/agent/chat/${this.sessionId}/stats`, "GET", "stats");
        return true;
      case "/todos":
        await this.runApiCommand(`/api/agent/chat/${this.sessionId}/todos`, "GET", "todos");
        return true;
      case "/todo-add": {
        const title = parts.slice(1).join(" ");
        if (!title) {
          this.chatView.messageList.addSystemMessage("Usage: /todo-add <title>");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        await this.runApiCommand(`/api/agent/chat/${this.sessionId}/todos?title=${encodeURIComponent(title)}`, "POST", "todo-add");
        return true;
      }
      case "/compact":
        await this.runApiCommand(`/api/agent/chat/${this.sessionId}/compact`, "POST", "compact");
        return true;
      case "/messages":
        await this.runApiCommand(`/api/agent/chat/${this.sessionId}/export?limit=10`, "GET", "messages");
        return true;
      case "/status":
        await this.runApiCommand("/api/index/status", "GET", "status");
        return true;
      case "/doctor":
        await this.runApiCommand("/api/health", "GET", "doctor");
        return true;
      case "/context":
        await this.runApiCommand(`/api/agent/chat/${this.sessionId}/context`, "GET", "context");
        return true;
      // ── Clipboard commands ────────────────────────────────────────────
      case "/copy": {
        const copyArg = parts[1]?.toLowerCase();
        if (copyArg === "all") {
          const allMessages = this.chatView.messageList.getMessages();
          if (allMessages.length === 0) {
            this.chatView.messageList.addSystemMessage("No messages to copy.");
          } else {
            const text2 = allMessages.map((m) => `[${m.role}]
${m.content}`).join("\n\n---\n\n");
            const copied = copyToClipboard(text2);
            this.chatView.messageList.addSystemMessage(copied ? "Conversation copied to clipboard." : "Failed to copy to clipboard.");
          }
        } else {
          const allMsgs = this.chatView.messageList.getMessages();
          const lastAssistant = [...allMsgs].reverse().find((m) => m.role === "assistant");
          if (!lastAssistant) {
            this.chatView.messageList.addSystemMessage("No assistant message to copy.");
          } else {
            const copied = copyToClipboard(lastAssistant.content);
            this.chatView.messageList.addSystemMessage(copied ? "Last response copied to clipboard." : "Failed to copy to clipboard.");
          }
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      // ── Export ─────────────────────────────────────────────────────────
      case "/export":
        if (!this.sessionId) {
          this.chatView.messageList.addSystemMessage("No active session. Send a message first.");
        } else {
          await this.runApiCommand(`/api/agent/chat/${this.sessionId}/export`, "GET", "export");
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      // ── Multiuser / Collaboration commands ────────────────────────────
      case "/share": {
        if (this.multiuserSessionId) {
          this.chatView.messageList.addSystemMessage("Already sharing session. Use /invite to see the invite code or /leave first.");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        const displayName = parts.slice(1).join(" ").trim() || getDisplayName();
        const userId = generateUserId();
        try {
          const data = await this.sseClient.post("/api/multiuser/session/create", {
            user_id: userId,
            display_name: displayName,
            model: this.sseClient.model,
            plan_mode: this.sseClient.mode === "plan"
          });
          const inviteCode = data.invite_code ?? "";
          const sharedSessionId = data.session_id ?? "";
          const useFirebase = data.use_firebase ?? false;
          this.multiuserUserId = userId;
          this.multiuserSessionId = sharedSessionId;
          this.multiuserIsOwner = true;
          this.multiuserServerUrl = this.sseClient["baseUrl"];
          let fullInvite;
          if (useFirebase) {
            fullInvite = inviteCode;
          } else {
            const localIP = getLocalIP();
            const port = new URL(this.sseClient["baseUrl"]).port;
            fullInvite = `${inviteCode}@${localIP}:${port}`;
          }
          const copied = copyToClipboard(fullInvite);
          const clipboardMsg = copied ? " (copied to clipboard)" : "";
          const modeMsg = useFirebase ? " (via Firebase \u2014 works across networks)" : " (LAN only)";
          this.chatView.messageList.addSystemMessage(`Session Shared!${modeMsg}

Invite code: ${fullInvite}${clipboardMsg}

Share this code with others to let them join.
They can join with: /join ${fullInvite}`);
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          this.chatView.messageList.addSystemMessage(`Failed to share session: ${msg}`);
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/join": {
        const rawInvite = parts.slice(1).join(" ").trim();
        if (!rawInvite) {
          this.chatView.messageList.addSystemMessage("Usage: /join <invite-code>\n\nExamples:\n  /join ABC123 (Firebase mode)\n  /join ABC123@192.168.1.5:57220 (LAN mode)");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        let inviteCode;
        let joinServerUrl;
        if (rawInvite.includes("@")) {
          const [codePart, serverPart] = rawInvite.split("@");
          inviteCode = codePart.toUpperCase();
          if (serverPart.includes(":")) {
            joinServerUrl = `http://${serverPart}`;
          } else {
            const portNum = parseInt(serverPart, 10);
            joinServerUrl = isNaN(portNum) ? this.sseClient["baseUrl"] : `http://localhost:${portNum}`;
          }
        } else {
          inviteCode = rawInvite.toUpperCase();
          joinServerUrl = this.sseClient["baseUrl"];
        }
        const joinUserId = generateUserId();
        const joinDisplayName = getDisplayName();
        try {
          const resp = await fetch(`${joinServerUrl}/api/multiuser/session/join`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              invite_code: inviteCode,
              user_id: joinUserId,
              display_name: joinDisplayName
            })
          });
          if (!resp.ok) {
            if (resp.status === 404) {
              this.chatView.messageList.addSystemMessage(`Invalid invite code: ${inviteCode}`);
            } else {
              this.chatView.messageList.addSystemMessage(`Failed to join: HTTP ${resp.status}`);
            }
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          const data = await resp.json();
          const joinedSessionId = data.session_id ?? "";
          const participants = data.participants ?? [];
          const messageCount = data.message_count ?? 0;
          this.multiuserUserId = joinUserId;
          this.multiuserSessionId = joinedSessionId;
          this.multiuserIsOwner = false;
          this.multiuserServerUrl = joinServerUrl;
          this.chatView.messageList.addSystemMessage(`Joined Session!

Session: ${joinedSessionId.slice(0, 8)}...
Participants: ${participants.length}
Messages: ${messageCount}

Use /who to see participants.`);
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          this.chatView.messageList.addSystemMessage(`Cannot connect to server at ${joinServerUrl}

Error: ${msg}

Make sure both machines are on the same network.`);
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/leave": {
        if (!this.multiuserSessionId || !this.multiuserUserId) {
          this.chatView.messageList.addSystemMessage("Not in a shared session.");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        try {
          const serverUrl = this.multiuserServerUrl ?? this.sseClient["baseUrl"];
          await fetch(`${serverUrl}/api/multiuser/session/${this.multiuserSessionId}/leave`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user_id: this.multiuserUserId })
          });
          this.multiuserSessionId = null;
          this.multiuserUserId = null;
          this.multiuserIsOwner = false;
          this.multiuserServerUrl = null;
          this.chatView.messageList.addSystemMessage("Left the shared session.");
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          this.chatView.messageList.addSystemMessage(`Failed to leave session: ${msg}`);
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/who": {
        if (!this.multiuserSessionId) {
          this.chatView.messageList.addSystemMessage("Not in a shared session. Use /share to create one or /join to join one.");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        try {
          const serverUrl = this.multiuserServerUrl ?? this.sseClient["baseUrl"];
          const resp = await fetch(`${serverUrl}/api/multiuser/session/${this.multiuserSessionId}/participants`);
          if (!resp.ok) {
            this.chatView.messageList.addSystemMessage("This is a single-user session.");
          } else {
            const data = await resp.json();
            const participants = Array.isArray(data.participants) ? data.participants : Array.isArray(data) ? data : [];
            if (participants.length === 0) {
              this.chatView.messageList.addSystemMessage("No participants found.");
            } else {
              const lines = ["Session Participants", ""];
              for (const p of participants) {
                const isOnline = p.is_online ?? p.is_active ?? false;
                const status = isOnline ? "\u{1F7E2}" : "\u26AA";
                const name = p.display_name ?? p.name ?? "Unknown";
                const role = p.role === "owner" ? "\u{1F451} Owner" : p.role ?? "editor";
                lines.push(`  ${status} ${name} \u2014 ${role}`);
              }
              this.chatView.messageList.addSystemMessage(lines.join("\n"));
            }
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          this.chatView.messageList.addSystemMessage(`Failed to get participants: ${msg}`);
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/invite": {
        if (!this.multiuserSessionId) {
          this.chatView.messageList.addSystemMessage("Not in a shared session. Use /share to create one first.");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        try {
          const serverUrl = this.multiuserServerUrl ?? this.sseClient["baseUrl"];
          const resp = await fetch(`${serverUrl}/api/multiuser/session/${this.multiuserSessionId}/state`);
          if (!resp.ok) {
            this.chatView.messageList.addSystemMessage("This session is not shared. Use /share first.");
          } else {
            const data = await resp.json();
            const inviteCode = data.invite_code ?? "";
            if (inviteCode) {
              const localIP = getLocalIP();
              const port = new URL(serverUrl).port;
              const fullInvite = `${inviteCode}@${localIP}:${port}`;
              const copied = copyToClipboard(fullInvite);
              const clipboardMsg = copied ? " (copied to clipboard)" : "";
              this.chatView.messageList.addSystemMessage(`Invite Code: ${fullInvite}${clipboardMsg}

Share this code so others can join with /join ${fullInvite}`);
            } else {
              this.chatView.messageList.addSystemMessage("This session is not shared. Use /share first.");
            }
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          this.chatView.messageList.addSystemMessage(`Failed to get invite code: ${msg}`);
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      }
      case "/team": {
        const teamSub = parts[1]?.toLowerCase() || "";
        const teamArgs = parts.slice(2).join(" ").trim();
        if (teamSub === "create") {
          if (!teamArgs) {
            this.chatView.messageList.addSystemMessage("Usage: /team create <name>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const data = await this.sseClient.post("/api/agent-teams/teams", {
              name: teamArgs,
              lead_agent_id: this.sessionId || "tui-lead"
            });
            const formatted = JSON.stringify(data, null, 2);
            this.chatView.messageList.addSystemMessage(`[agent-teams] Team '${teamArgs}' created
${formatted}`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team create failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "spawn") {
          const spawnParts = teamArgs.split(/\s+/, 1);
          const spawnName = spawnParts[0];
          const spawnPrompt = teamArgs.slice(spawnName?.length || 0).trim();
          if (!spawnName || !spawnPrompt) {
            this.chatView.messageList.addSystemMessage("Usage: /team spawn <name> <instructions>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team. Create one first: /team create <name>");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            const data = await this.sseClient.post(`/api/agent-teams/teams/${teamName}/teammates`, {
              name: spawnName,
              prompt: spawnPrompt
            });
            const formatted = JSON.stringify(data, null, 2);
            this.chatView.messageList.addSystemMessage(`[agent-teams] Spawned '${spawnName}'
${formatted}`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team spawn failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "shutdown") {
          if (!teamArgs) {
            this.chatView.messageList.addSystemMessage("Usage: /team shutdown <name>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            const data = await this.sseClient.post(`/api/agent-teams/teams/${teamName}/teammates/${teamArgs}/shutdown`);
            const formatted = JSON.stringify(data, null, 2);
            this.chatView.messageList.addSystemMessage(`[agent-teams] Shutdown '${teamArgs}'
${formatted}`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team shutdown failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "message" || teamSub === "msg") {
          const msgParts = teamArgs.split(/\s+/, 1);
          const toName = msgParts[0];
          const msgContent = teamArgs.slice(toName?.length || 0).trim();
          if (!toName || !msgContent) {
            this.chatView.messageList.addSystemMessage("Usage: /team message <name> <message>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            await this.sseClient.post(`/api/agent-teams/teams/${teamName}/messages`, {
              from_agent: "user",
              to_agent: toName,
              content: msgContent
            });
            this.chatView.messageList.addSystemMessage(`[agent-teams] Message sent to ${toName}`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team message failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "broadcast") {
          if (!teamArgs) {
            this.chatView.messageList.addSystemMessage("Usage: /team broadcast <message>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            await this.sseClient.post(`/api/agent-teams/teams/${teamName}/messages`, {
              from_agent: "user",
              to_agent: "all",
              content: teamArgs
            });
            this.chatView.messageList.addSystemMessage(`[agent-teams] Broadcast sent`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team broadcast failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "cleanup") {
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active teams to clean up.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            const force = teamArgs.toLowerCase().includes("force");
            const data = await this.sseClient.delete(`/api/agent-teams/teams/${teamName}?force=${force}`);
            this.chatView.messageList.addSystemMessage(`[agent-teams] Team '${teamName}' cleaned up`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team cleanup failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "delegate") {
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            const current = teams[0].delegate_mode || false;
            const data = await this.sseClient.post(`/api/agent-teams/teams/${teamName}/delegate-mode`, {
              enabled: !current
            });
            this.chatView.messageList.addSystemMessage(`[agent-teams] Delegate mode: ${!current ? "ON" : "OFF"}`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team delegate failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "approve") {
          if (!teamArgs) {
            this.chatView.messageList.addSystemMessage("Usage: /team approve <name>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            await this.sseClient.post(`/api/agent-teams/teams/${teamName}/teammates/${teamArgs}/plan`, { approved: true });
            this.chatView.messageList.addSystemMessage(`[agent-teams] Plan approved for '${teamArgs}'`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team approve failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        if (teamSub === "reject") {
          const rejectParts = teamArgs.split(/\s+/, 1);
          const rejectName = rejectParts[0];
          const feedback = teamArgs.slice(rejectName?.length || 0).trim();
          if (!rejectName || !feedback) {
            this.chatView.messageList.addSystemMessage("Usage: /team reject <name> <feedback>");
            this.chatView.rebuildLayout();
            this.tui.requestRender();
            return true;
          }
          try {
            const teamsData = await this.sseClient.get("/api/agent-teams/teams");
            const teams = teamsData?.teams || [];
            if (!teams.length) {
              this.chatView.messageList.addSystemMessage("No active team.");
              this.chatView.rebuildLayout();
              this.tui.requestRender();
              return true;
            }
            const teamName = teams[0].team_name;
            await this.sseClient.post(`/api/agent-teams/teams/${teamName}/teammates/${rejectName}/plan`, {
              approved: false,
              feedback
            });
            this.chatView.messageList.addSystemMessage(`[agent-teams] Plan rejected for '${rejectName}'`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`/team reject failed: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        await this.runApiCommand("/api/agent-teams/teams", "GET", "agent-teams");
        return true;
      }
      case "/team-old":
        await this.runApiCommand("/api/teams", "GET", "team");
        return true;
      // ── PR Review & Research (SSE streaming) ──────────────────────────
      case "/pr": {
        const prUrl = parts.slice(1).join(" ").trim();
        if (!prUrl) {
          this.chatView.messageList.addSystemMessage("Usage: /pr <url or pr-number>");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        this.chatView.messageList.addSystemMessage(`Reviewing PR: ${prUrl}`);
        this.chatView.messageList.startAssistantMessage();
        this.chatView.statusBar.update({ status: "Reviewing PR...", isStreaming: true });
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        await this.sseClient.postStream("/api/review", { pr_url: prUrl.trim() });
        return true;
      }
      case "/research": {
        const goal = parts.slice(1).join(" ").trim();
        if (!goal) {
          this.chatView.messageList.addSystemMessage("Usage: /research <goal>");
          this.chatView.rebuildLayout();
          this.tui.requestRender();
          return true;
        }
        this.chatView.messageList.addSystemMessage(`Researching: ${goal}`);
        this.chatView.messageList.startAssistantMessage();
        this.chatView.statusBar.update({ status: "Researching...", isStreaming: true });
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        await this.sseClient.postStream("/api/research", { goal });
        return true;
      }
      // ── Configuration wizards ─────────────────────────────────────────
      case "/skills":
        this.showConfigWizard({
          title: "Skills",
          listEndpoint: "/api/skills",
          extractItems: (d) => d.skills?.map((s) => ({ value: s.name, label: s.name, description: s.description })) ?? [],
          detailEndpoint: (n) => `/api/skills/${n}`,
          deleteEndpoint: (n) => `/api/skills/${n}`
        });
        return true;
      case "/agents":
        this.showConfigWizard({
          title: "Agents",
          listEndpoint: "/api/agents",
          extractItems: (d) => d.agents?.map((a) => ({ value: a.name, label: a.name, description: a.path })) ?? [],
          detailEndpoint: (n) => `/api/agents/${n}`,
          deleteEndpoint: (n) => `/api/agents/${n}`
        });
        return true;
      case "/rules":
        this.showConfigWizard({
          title: "Rules",
          listEndpoint: "/api/rules/list",
          extractItems: (d) => d.templates?.map((t) => ({ value: t.name, label: t.name, description: `[${t.source}] ${t.description || ""}` })) ?? [],
          detailEndpoint: (n) => `/api/rules/${n}`
        });
        return true;
      case "/hooks":
      case "/verifiers":
        return false;
      case "/registry":
        this.showRegistryWizard();
        return true;
      case "/help":
        this.chatView.messageList.addSystemMessage([
          "Commands:",
          "  /clear             \u2014 Clear chat and start new session",
          "  /reset             \u2014 Clear chat, cancel streams, and reset session",
          "  /mode <mode>       \u2014 Switch mode (code, plan, research, review, spec)",
          "  /plan              \u2014 Switch to plan mode",
          "  /code              \u2014 Switch to code mode",
          "  /model <name>      \u2014 Switch model by name",
          "  /models            \u2014 Interactive model picker",
          "  /stats             \u2014 Show token usage stats",
          "  /todos             \u2014 List todos for current session",
          "  /todo-add <title>  \u2014 Add a todo item",
          "  /compact           \u2014 Compact session context",
          "  /messages          \u2014 Show recent messages",
          "  /context           \u2014 Show session context info",
          "  /diff              \u2014 Show git diff stats",
          "  /status            \u2014 Show index status",
          "  /doctor            \u2014 Check backend health",
          "  /copy              \u2014 Copy last response to clipboard",
          "  /copy all          \u2014 Copy entire conversation",
          "  /export            \u2014 Export session data",
          "  /quit, /exit, /q   \u2014 Quit the TUI",
          "  /help              \u2014 Show this help",
          "",
          "Collaboration:",
          "  /share [name]      \u2014 Create shareable session",
          "  /join <code>       \u2014 Join a shared session",
          "  /leave             \u2014 Leave shared session",
          "  /who               \u2014 Show session participants",
          "  /invite            \u2014 Show invite code",
          "  /team              \u2014 Agent Team orchestration",
          "  /team-old          \u2014 Legacy team management",
          "",
          "Advanced:",
          "  /pr <url>          \u2014 Review a pull request",
          "  /research <topic>  \u2014 Deep research a topic",
          "",
          "Configuration:",
          "  /skills            \u2014 Manage skills (list, view, create, delete)",
          "  /agents            \u2014 Manage agents (list, view, create, delete)",
          "  /rules             \u2014 Manage rules (list, view, create)",
          "  /hooks             \u2014 Manage hooks (via agent)",
          "  /verifiers         \u2014 Manage verifiers (via agent)",
          "  /registry          \u2014 Browse & install from community registry",
          "",
          "Shortcuts:",
          "  Ctrl+C             \u2014 Cancel current request / dismiss picker",
          "  Ctrl+V             \u2014 Paste clipboard image",
          "  Ctrl+Q             \u2014 Quit"
        ].join("\n"));
        this.chatView.rebuildLayout();
        this.tui.requestRender();
        return true;
      default:
        return false;
    }
  }
  /** Fetch user-invocable skills from the server and merge with built-in slash commands. */
  async loadSlashCommands() {
    try {
      const data = await this.sseClient.get("/api/skills");
      const skills = (data.skills ?? []).filter((s) => s.user_invocable);
      const existing = new Set(SLASH_COMMANDS.map((c) => c.value));
      const skillItems = skills.filter((s) => !existing.has(s.name)).map((s) => ({ value: s.name, label: s.name, description: s.description }));
      return [...SLASH_COMMANDS, ...skillItems];
    } catch {
      return SLASH_COMMANDS;
    }
  }
  async runApiCommand(path2, method, label) {
    if (path2.includes("/chat/") && !this.sessionId) {
      this.chatView.messageList.addSystemMessage("No active session. Send a message first.");
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      return;
    }
    try {
      const data = method === "GET" ? await this.sseClient.get(path2) : await this.sseClient.post(path2);
      const formatted = typeof data === "string" ? data : JSON.stringify(data, null, 2);
      this.chatView.messageList.addSystemMessage(`[${label}]
${formatted}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.chatView.messageList.addSystemMessage(colors.error(`/${label} failed: ${msg}`));
    }
    this.chatView.rebuildLayout();
    this.tui.requestRender();
  }
  handleInputIntercept(_data) {
    return false;
  }
  showProviderPicker() {
    const items = providers.map((p) => ({
      value: p.name,
      label: p.name,
      description: `${p.models.length} models`
    }));
    const title = new Text(colors.accentBright("  Select Provider"));
    const list2 = new SelectList(items, 10, pickerTheme2);
    const wrapper = new Container();
    wrapper.addChild(title);
    wrapper.addChild(list2);
    list2.onSelect = (item) => {
      this.dismissPicker();
      const provider = providers.find((p) => p.name === item.value);
      if (provider) {
        this.showModelPicker(provider.name, provider.prefix, provider.models);
      }
    };
    list2.onCancel = () => {
      this.dismissPicker();
    };
    this.activePickerList = list2;
    this.chatView.setInlinePicker(wrapper);
    this.chatView.rebuildLayout();
    this.tui.requestRender();
  }
  showModelPicker(providerName, prefix, models) {
    const items = models.map((m) => ({
      value: m.id,
      label: m.label,
      description: m.id
    }));
    const title = new Text(colors.accentBright(`  ${providerName} Models`));
    const list2 = new SelectList(items, 12, pickerTheme2);
    const wrapper = new Container();
    wrapper.addChild(title);
    wrapper.addChild(list2);
    list2.onSelect = (item) => {
      this.dismissPicker();
      const fullModel = `${prefix}${item.value}`;
      this.sseClient.model = fullModel;
      this.chatView.statusBar.update({ model: fullModel });
      this.chatView.messageList.addSystemMessage(`Model switched to ${fullModel}`);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    };
    list2.onCancel = () => {
      this.dismissPicker();
      this.showProviderPicker();
    };
    this.activePickerList = list2;
    this.chatView.setInlinePicker(wrapper);
    this.chatView.rebuildLayout();
    this.tui.requestRender();
  }
  dismissPicker() {
    this.activePickerList = null;
    this.activeInputComponent = null;
    this.chatView.setInlinePicker(null);
    this.chatView.rebuildLayout();
    this.tui.requestRender();
  }
  /**
   * Shared interactive wizard for /skills, /agents, /rules.
   * Fetches a list, shows a picker, then allows View/Delete/Create actions.
   */
  async showConfigWizard(opts) {
    let data;
    try {
      data = await this.sseClient.get(opts.listEndpoint);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.chatView.messageList.addSystemMessage(colors.error(`Failed to fetch ${opts.title.toLowerCase()}: ${msg}`));
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      return;
    }
    const items = opts.extractItems(data);
    const pickerItems = [
      ...items,
      { value: "__create__", label: "\u271A Create new", description: `Create a new ${opts.title.toLowerCase().replace(/s$/, "")}` },
      { value: "__back__", label: "\u2190 Back", description: "Return to chat" }
    ];
    const choice = await this.showApprovalPicker(opts.title, `${items.length} ${opts.title.toLowerCase()} found`, pickerItems);
    if (choice === "__back__" || !choice)
      return;
    if (choice === "__create__") {
      const name = await this.showFeedbackInput(`New ${opts.title.toLowerCase().replace(/s$/, "")} name:`);
      if (name) {
        await this.handleInput(`/${opts.title.toLowerCase()} create ${name}`);
      }
      return;
    }
    const actions = [];
    if (opts.detailEndpoint) {
      actions.push({ value: "view", label: "View Details", description: `View ${choice} details` });
    }
    if (opts.deleteEndpoint) {
      actions.push({ value: "delete", label: "Delete", description: `Delete ${choice}` });
    }
    actions.push({ value: "__back__", label: "\u2190 Back", description: "Return to list" });
    const action = await this.showApprovalPicker(choice, "Choose an action", actions);
    if (action === "view" && opts.detailEndpoint) {
      try {
        const detail = await this.sseClient.get(opts.detailEndpoint(choice));
        const formatted = typeof detail === "string" ? detail : JSON.stringify(detail, null, 2);
        this.chatView.messageList.addSystemMessage(`[${choice}]
${formatted}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        this.chatView.messageList.addSystemMessage(colors.error(`Failed to fetch details: ${msg}`));
      }
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    } else if (action === "delete" && opts.deleteEndpoint) {
      const confirm = await this.showApprovalPicker(`Delete ${choice}?`, "This action cannot be undone.", [
        { value: "yes", label: "Yes, delete", description: `Permanently delete ${choice}` },
        { value: "no", label: "Cancel", description: "Go back" }
      ]);
      if (confirm === "yes") {
        try {
          await this.sseClient.delete(opts.deleteEndpoint(choice));
          this.chatView.messageList.addSystemMessage(`Deleted ${choice}`);
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          this.chatView.messageList.addSystemMessage(colors.error(`Failed to delete: ${msg}`));
        }
        this.chatView.rebuildLayout();
        this.tui.requestRender();
      }
    } else if (action === "__back__") {
      await this.showConfigWizard(opts);
    }
  }
  /**
   * Two-level interactive browser for the community registry.
   * Category picker → item picker → install/view details.
   *
   * Registry API returns: { plugins: {name: {path, description}}, skills: {...}, ... }
   * Install API expects: { component_type: "plugin"|"skill"|..., name: string }
   */
  async showRegistryWizard() {
    let data;
    try {
      data = await this.sseClient.get("/api/registry");
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.chatView.messageList.addSystemMessage(colors.error(`Failed to fetch registry: ${msg}`));
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      return;
    }
    const categoryOrder = ["plugins", "skills", "rules", "agents", "verifiers"];
    const categories = [];
    for (const key of categoryOrder) {
      const value = data[key];
      if (value && typeof value === "object" && !Array.isArray(value)) {
        const entries = Object.entries(value);
        if (entries.length > 0) {
          const singular = key.replace(/s$/, "");
          categories.push({
            key,
            label: key.charAt(0).toUpperCase() + key.slice(1),
            singular,
            entries
          });
        }
      }
    }
    const categoryItems = [
      ...categories.map((c) => ({
        value: c.key,
        label: c.label,
        description: `${c.entries.length} ${c.key}`
      })),
      { value: "__installed__", label: "Installed", description: "View installed components" },
      { value: "__back__", label: "\u2190 Back", description: "Return to chat" }
    ];
    const categoryChoice = await this.showApprovalPicker("Registry", "Browse community components", categoryItems);
    if (categoryChoice === "__back__" || !categoryChoice)
      return;
    if (categoryChoice === "__installed__") {
      await this.showInstalledRegistry();
      return;
    }
    const category = categories.find((c) => c.key === categoryChoice);
    if (!category)
      return;
    const itemPickerItems = [
      ...category.entries.map(([name, info]) => ({
        value: name,
        label: name,
        description: info.description || ""
      })),
      { value: "__back__", label: "\u2190 Back", description: "Return to categories" }
    ];
    const itemChoice = await this.showApprovalPicker(category.label, `${category.entries.length} ${category.key}`, itemPickerItems);
    if (itemChoice === "__back__" || !itemChoice) {
      await this.showRegistryWizard();
      return;
    }
    const actions = [
      { value: "view", label: "View Details", description: `View ${itemChoice} details` },
      { value: "install", label: "Install", description: `Install ${itemChoice}` },
      { value: "__back__", label: "\u2190 Back", description: "Return to list" }
    ];
    const action = await this.showApprovalPicker(itemChoice, "Choose an action", actions);
    if (action === "view") {
      try {
        const detail = await this.sseClient.get(`/api/registry/component/${category.singular}/${itemChoice}`);
        const formatted = typeof detail === "string" ? detail : JSON.stringify(detail, null, 2);
        this.chatView.messageList.addSystemMessage(`[${itemChoice}]
${formatted}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        this.chatView.messageList.addSystemMessage(colors.error(`Failed to fetch details: ${msg}`));
      }
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    } else if (action === "install") {
      try {
        const result = await this.sseClient.post("/api/registry/install", { component_type: category.singular, name: itemChoice });
        this.chatView.messageList.addSystemMessage(result.message || `Installed ${itemChoice}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        this.chatView.messageList.addSystemMessage(colors.error(`Failed to install: ${msg}`));
      }
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    } else if (action === "__back__") {
      await this.showRegistryWizard();
    }
  }
  /**
   * Show installed registry components with uninstall option.
   *
   * Installed API returns:
   *   { plugins: { name: { name, version, description, ... } },
   *     skills: ["name", ...], rules: [...], agents: [...], verifiers: [...] }
   */
  async showInstalledRegistry() {
    let data;
    try {
      data = await this.sseClient.get("/api/registry/installed");
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.chatView.messageList.addSystemMessage(colors.error(`Failed to fetch installed components: ${msg}`));
      this.chatView.rebuildLayout();
      this.tui.requestRender();
      return;
    }
    const items = [];
    const plugins = data.plugins || {};
    for (const [name, info] of Object.entries(plugins)) {
      items.push({
        value: `plugin:${name}`,
        label: name,
        description: `[plugin] ${info.description || info.version || ""}`
      });
    }
    for (const type of ["skills", "rules", "agents", "verifiers"]) {
      const list2 = data[type];
      if (Array.isArray(list2)) {
        for (const name of list2) {
          items.push({
            value: `${type}:${name}`,
            label: name,
            description: `[${type.replace(/s$/, "")}]`
          });
        }
      }
    }
    const pickerItems = [
      ...items,
      { value: "__back__", label: "\u2190 Back", description: "Return to categories" }
    ];
    const choice = await this.showApprovalPicker("Installed", `${items.length} installed components`, pickerItems);
    if (choice === "__back__" || !choice) {
      await this.showRegistryWizard();
      return;
    }
    const colonIdx = choice.indexOf(":");
    const itemType = choice.slice(0, colonIdx);
    const itemName = choice.slice(colonIdx + 1);
    if (itemType === "plugin") {
      const actions = [
        { value: "uninstall", label: "Uninstall", description: `Uninstall plugin ${itemName} and its components` },
        { value: "__back__", label: "\u2190 Back", description: "Return to list" }
      ];
      const action = await this.showApprovalPicker(itemName, "Choose an action", actions);
      if (action === "uninstall") {
        const confirm = await this.showApprovalPicker(`Uninstall ${itemName}?`, "This will remove the plugin and all its components.", [
          { value: "yes", label: "Yes, uninstall", description: `Remove ${itemName}` },
          { value: "no", label: "Cancel", description: "Go back" }
        ]);
        if (confirm === "yes") {
          try {
            const result = await this.sseClient.delete(`/api/registry/uninstall/${itemName}`);
            this.chatView.messageList.addSystemMessage(result.message || `Uninstalled ${itemName}`);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.chatView.messageList.addSystemMessage(colors.error(`Failed to uninstall: ${msg}`));
          }
          this.chatView.rebuildLayout();
          this.tui.requestRender();
        }
      } else if (action === "__back__") {
        await this.showInstalledRegistry();
      }
    } else {
      this.chatView.messageList.addSystemMessage(`${itemName} [${itemType.replace(/s$/, "")}] \u2014 installed`);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    }
  }
  /**
   * Show an inline approval picker with the given title, description, and choice items.
   * Returns a promise that resolves with the selected item value.
   */
  showApprovalPicker(title, description, choices) {
    return new Promise((resolve) => {
      const titleText = new Text(colors.accentBright(`  ${title}`));
      const descText = new Text(colors.textDim(`  ${description}`));
      const items = choices.map((c) => ({
        value: c.value,
        label: c.label,
        description: c.description
      }));
      const list2 = new SelectList(items, 8, pickerTheme2);
      const wrapper = new Container();
      wrapper.addChild(titleText);
      wrapper.addChild(descText);
      wrapper.addChild(list2);
      list2.onSelect = (item) => {
        this.dismissPicker();
        resolve(item.value);
      };
      list2.onCancel = () => {
        this.dismissPicker();
      };
      this.activePickerList = list2;
      this.chatView.setInlinePicker(wrapper);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
  }
  /**
   * Show a single-line text input for feedback. Resolves with the entered text.
   * Escape dismisses without resolving.
   */
  showFeedbackInput(prompt) {
    return new Promise((resolve) => {
      const titleText = new Text(colors.accentBright(`  ${prompt}`));
      const input = new Input();
      const wrapper = new Container();
      wrapper.addChild(titleText);
      wrapper.addChild(input);
      input.onSubmit = (value) => {
        const text = value.trim();
        this.dismissPicker();
        if (text) {
          resolve(text);
        }
      };
      input.onEscape = () => {
        this.dismissPicker();
      };
      this.activeInputComponent = input;
      this.chatView.setInlinePicker(wrapper);
      this.chatView.rebuildLayout();
      this.tui.requestRender();
    });
  }
  /**
   * Set UI to streaming state after calling an approval endpoint.
   */
  resumeStreaming() {
    this.chatView.messageList.startAssistantMessage();
    this.chatView.statusBar.update({ status: "Resuming...", isStreaming: true });
    this.chatView.rebuildLayout();
    this.tui.requestRender();
  }
  showMonitorView(tui, botUsername) {
    const monitor = new MonitorView({ botUsername });
    const self = this;
    const wrapper = {
      render(width) {
        return monitor.render(width);
      },
      handleInput(data) {
        if (data === "" || data === "") {
          tui.stop();
          self.serverManager.shutdown();
          process.exit(0);
        }
      },
      invalidate() {
        monitor.invalidate();
      }
    };
    tui.addChild(wrapper);
    tui.setFocus(wrapper);
    tui.start();
  }
  shutdown() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
    }
    this.sseClient.abort();
    this.tui.stop();
    this.serverManager.shutdown();
    process.exit(0);
  }
};

// dist/index.js
process.stdout.write("\x1B[2J\x1B[H");
function loadEnvFile(filePath, override = false) {
  if (!existsSync4(filePath))
    return;
  try {
    const content = readFileSync3(filePath, "utf-8");
    for (const line of content.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#"))
        continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx < 0)
        continue;
      const key = trimmed.slice(0, eqIdx).trim();
      let value = trimmed.slice(eqIdx + 1).trim();
      if (value.length >= 2 && value[0] === value[value.length - 1] && (value[0] === '"' || value[0] === "'")) {
        value = value.slice(1, -1);
      }
      if (override || !(key in process.env)) {
        process.env[key] = value;
      }
    }
  } catch {
  }
}
loadEnvFile(join6(homedir3(), ".emdash", ".env"));
loadEnvFile(join6(process.cwd(), ".emdash", ".env"), true);
loadEnvFile(join6(process.cwd(), ".env"), true);
function parseArgs(argv) {
  const args = argv.slice(2);
  const options3 = {};
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    if (arg === "--model" || arg === "-m") {
      options3.model = args[++i];
    } else if (arg === "--mode") {
      options3.mode = args[++i];
    } else if (arg === "--agent-type") {
      options3.agentType = args[++i];
    } else if (arg === "--port" || arg === "-p") {
      options3.port = parseInt(args[++i], 10);
    } else if (arg === "--channel") {
      options3.channel = args[++i];
    } else if (arg === "--logs") {
      options3.logs = true;
    } else if (arg === "--kill") {
      options3.kill = true;
    } else if (arg === "--help" || arg === "-h") {
      printUsage();
      process.exit(0);
    } else if (!arg.startsWith("-")) {
      options3.task = arg;
    }
    i++;
  }
  return options3;
}
function printUsage() {
  console.log(`
emdash-tui \u2014 Terminal UI for emdash

Usage:
  emdash-tui [task] [options]

Options:
  --model, -m <model>   Model to use (default: server configured)
  --mode <mode>         Starting mode: code, plan, research, review, spec (default: code)
  --port, -p <port>     Server port (default: 8765)
  --logs                Write server logs to .emdash/logs/server.log
  --kill                Kill all running emdash-core server processes and exit
  --help, -h            Show this help

Examples:
  emdash-tui                        # Interactive mode
  emdash-tui "Fix the login bug"    # Run a single task
  emdash-tui --mode plan            # Start in plan mode
`);
}
var options2 = parseArgs(process.argv);
if (options2.kill) {
  const count = ServerManager.killAllServers();
  console.log(`Killed ${count} emdash-core process${count === 1 ? "" : "es"}.`);
  process.exit(0);
}
var app = new App(options2);
app.run().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
