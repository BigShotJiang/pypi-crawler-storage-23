"""Telegram-EmDash bridge for SSE streaming.

Connects Telegram messages to the EmDash agent and streams
SSE responses back to Telegram as message updates.
"""

import asyncio
import base64
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import httpx

from .bot import TelegramBot, TelegramMessage, TelegramUpdate
from .config import TelegramConfig, TelegramSettings, delete_config, save_config
from .formatter import SSEEventFormatter, TelegramMessage as FormattedMessage
from ..providers import TelegramCommandProvider
from ..providers.modes import ModeDefinition


# Default EmDash server URL
DEFAULT_SERVER_URL = "http://localhost:8765"

# Command provider for Telegram — single source of truth for which
# commands are local, which are forwarded, aliases, etc.
_provider = TelegramCommandProvider()


@dataclass
class PendingInteraction:
    """Tracks a pending interaction requiring user response."""

    type: str  # "clarification", "plan_approval", "planmode_request"
    data: dict = field(default_factory=dict)
    options: list = field(default_factory=list)


@dataclass
class BridgeState:
    """Tracks the state of the bridge."""

    # Current session ID (one per chat)
    sessions: dict[int, str] = field(default_factory=dict)

    # Last message ID sent to each chat (for editing)
    last_message_ids: dict[int, int] = field(default_factory=dict)

    # Timestamp of last message sent to each chat (for rate limiting)
    last_message_times: dict[int, float] = field(default_factory=dict)

    # Whether we're currently processing a request for each chat
    processing: dict[int, bool] = field(default_factory=dict)

    # Pending interactions requiring user response (per chat)
    pending: dict[int, PendingInteraction] = field(default_factory=dict)

    # Current mode per chat (e.g. "code", "plan", "open")
    modes: dict[int, str] = field(default_factory=dict)


class TelegramBridge:
    """Bridge between Telegram and EmDash agent.

    Receives messages from Telegram, sends them to the EmDash agent,
    and streams SSE responses back as Telegram messages.
    """

    # Interval between typing indicator refreshes (Telegram expires after ~5s)
    _TYPING_INTERVAL = 4.0

    def __init__(
        self,
        config: TelegramConfig,
        server_url: str | None = None,
        on_message: Any = None,
        agent_type: str = "open",
    ):
        """Initialize the bridge.

        Args:
            config: Telegram configuration
            server_url: EmDash server URL (default: localhost:8765)
            on_message: Optional callback for logging/debugging
            agent_type: Agent type to use for chat requests (default: "open")
        """
        self.config = config
        self.server_url = server_url or os.getenv("EMDASH_SERVER_URL", DEFAULT_SERVER_URL)
        self.on_message = on_message
        self.agent_type = agent_type

        self.state = BridgeState()
        self._running = False
        self._bot: TelegramBot | None = None
        self._http_client: httpx.AsyncClient | None = None

    async def _typing_loop(self, chat_id: int) -> None:
        """Continuously send typing indicator until cancelled.

        Telegram's typing indicator expires after ~5 seconds, so this
        loop refreshes it every few seconds to keep it active while
        the agent is working.

        Args:
            chat_id: Telegram chat ID to show typing in
        """
        try:
            while True:
                if self._bot:
                    try:
                        await self._bot.send_chat_action(chat_id, "typing")
                    except Exception:
                        pass
                await asyncio.sleep(self._TYPING_INTERVAL)
        except asyncio.CancelledError:
            pass

    async def start(self) -> None:
        """Start the bridge.

        Begins listening for Telegram messages and processing them.
        """
        if not self.config.bot_token:
            raise ValueError("Bot token not configured")

        self._running = True
        self._bot = TelegramBot(self.config.bot_token)
        # Timeout for SSE streaming - 5 minutes max per request
        self._http_client = httpx.AsyncClient(timeout=httpx.Timeout(300.0, connect=30.0))

        await self._bot.__aenter__()

        # Get bot info
        bot_info = await self._bot.get_me()
        if self.on_message:
            self.on_message("bridge_started", {"bot": bot_info.username})

        # Register slash commands so they appear in Telegram's command menu
        try:
            bot_commands = [
                {"command": cmd, "description": desc}
                for cmd, desc in _provider.format_command_list()
            ]
            if not bot_commands:
                if self.on_message:
                    self.on_message("error", {"error": "setMyCommands: command list is empty"})
            else:
                await self._bot.set_my_commands(bot_commands)
                # Verify commands were actually registered
                registered = await self._bot.get_my_commands()
                if self.on_message:
                    self.on_message(
                        "commands_registered",
                        {"count": len(registered), "sent": len(bot_commands)},
                    )
        except Exception as exc:
            if self.on_message:
                self.on_message("error", {"error": f"setMyCommands failed: {exc}"})

        # Start polling loop
        try:
            async for update in self._bot.poll_updates(
                offset=self.config.state.last_update_id
            ):
                if not self._running:
                    break

                # Update offset and persist to disk
                self.config.state.last_update_id = update.update_id
                save_config(self.config)

                # Process the update
                await self._handle_update(update)

        finally:
            await self.stop()

    async def stop(self) -> None:
        """Stop the bridge."""
        self._running = False

        if self._bot:
            await self._bot.__aexit__(None, None, None)
            self._bot = None

        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def _handle_update(self, update: TelegramUpdate) -> None:
        """Handle an incoming Telegram update.

        Args:
            update: The Telegram update to process
        """
        if not update.message:
            return

        msg = update.message
        chat_id = msg.chat.id
        user = msg.from_user

        # Build content from text, caption, or media
        text = (msg.effective_text or "").strip()

        # Skip completely empty messages (no text, no media)
        if not text and not msg.has_media:
            return

        # Download images if present
        images: list[dict[str, str]] = []
        if msg.photo and self._bot:
            try:
                best = max(msg.photo, key=lambda p: p.file_size or (p.width * p.height))
                raw = await self._bot.download_file_by_id(best.file_id)
                encoded = base64.b64encode(raw).decode("ascii")
                images.append({"data": encoded, "format": "jpg"})
            except Exception as e:
                if self.on_message:
                    self.on_message("media_error", {"error": f"Failed to download photo: {e}"})

        # Handle voice — download and transcribe
        if msg.voice and self._bot:
            try:
                raw_audio = await self._bot.download_file_by_id(msg.voice.file_id)
                from emdash_core.channels.telegram.voice import transcribe_voice
                transcribed = await transcribe_voice(
                    raw_audio, mime_type=msg.voice.mime_type or "audio/ogg"
                )
                if transcribed:
                    voice_note = f"[Voice message ({msg.voice.duration}s) transcription]: {transcribed}"
                else:
                    voice_note = f"[Voice message ({msg.voice.duration}s) — transcription unavailable]"
            except Exception as e:
                if self.on_message:
                    self.on_message("media_error", {"error": f"Failed to process voice: {e}"})
                voice_note = f"[Voice message ({msg.voice.duration}s) — download failed]"
            text = f"{voice_note}\n{text}" if text else voice_note

        # Skip if still nothing useful
        if not text and not images:
            return

        # Log the incoming message
        if self.on_message:
            user_name = user.display_name if user else "Unknown"
            media_info = ""
            if images:
                media_info = f" [+{len(images)} image(s)]"
            if msg.voice:
                media_info += f" [+voice {msg.voice.duration}s]"
            self.on_message("message_received", {
                "chat_id": chat_id,
                "user": user_name,
                "text": (text[:100] + media_info) if text else media_info,
            })

        # Check authorization
        if not self.config.is_chat_authorized(chat_id):
            await self._send_message(chat_id, "Sorry, this chat is not authorized.")
            return

        # Check if already processing
        if self.state.processing.get(chat_id):
            await self._send_message(chat_id, "Please wait, still processing previous request...")
            return

        # Check if there's a pending interaction waiting for response
        pending = self.state.pending.get(chat_id)
        if pending:
            await self._handle_pending_response(chat_id, text, pending)
            return

        # Handle special commands (only for text messages)
        if text.startswith("/"):
            await self._handle_command(chat_id, text, images=images)
            return

        # Process as agent message (with optional images)
        await self._process_agent_message(chat_id, text, images=images)

    async def _handle_command(
        self, chat_id: int, text: str, images: list[dict[str, str]] | None = None,
    ) -> None:
        """Handle slash commands.

        Telegram-specific commands (in TELEGRAM_COMMANDS) are handled locally.
        All other slash commands are forwarded to the EmDash agent.

        Args:
            chat_id: Chat ID
            text: Command text (e.g., "/plan" or "/todo_add Fix tests")
            images: Optional list of base64-encoded image dicts
        """
        parts = text.split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        # Handle local commands (Telegram-specific + locally-handled CLI commands)
        if _provider.is_local_command(command):
            await self._handle_telegram_command(chat_id, command, args)
            return

        # Apply command aliases (platform format -> canonical CLI format)
        command = _provider.resolve_alias(command)

        # Forward to agent as a slash command
        message = f"{command} {args}".strip() if args else command
        await self._process_agent_message(chat_id, message, images=images)

    async def _handle_telegram_command(self, chat_id: int, command: str, args: str) -> None:
        """Handle Telegram-specific commands.

        Mode-switch commands (``/plan``, ``/code``, ``/open``, …) are
        resolved via the provider's mode registry so new modes are picked
        up automatically.  Non-mode commands are handled individually.

        Args:
            chat_id: Chat ID
            command: Command name (e.g., "/start")
            args: Command arguments
        """
        # ── Mode-switch commands (data-driven) ──────────────────────
        mode_def = _provider.get_mode_for_command(command)
        if mode_def:
            await self._handle_mode_switch(chat_id, mode_def)
            return

        if command == "/mode":
            await self._handle_mode_display(chat_id)
            return

        # ── Non-mode local commands ─────────────────────────────────
        if command == "/start":
            mode_lines = "\n".join(_provider.format_mode_help_lines())
            await self._send_message(
                chat_id,
                "*EmDash Bot*\n\n"
                "Send me a message and I'll process it with the EmDash agent.\n\n"
                f"*Mode commands:*\n"
                f"{mode_lines}\n"
                "/mode - Show current mode\n"
                "/reset - Reset session\n\n"
                "*Telegram-only commands:*\n"
                "/stop - Cancel current operation\n"
                "/cancel - Cancel pending interaction\n"
                "/tgstatus - Show bot connection status\n"
                "/tgsettings - Show display settings\n"
                "/thinking - Toggle showing agent thinking\n"
                "/tools - Toggle showing tool calls\n"
                "/update - Update emdash and restart\n"
                "/tglogout - Remove bot config and logout\n"
                "/tghelp - Show this help",
            )

        elif command == "/tgstatus":
            session_id = self.state.sessions.get(chat_id)
            pending = self.state.pending.get(chat_id)
            current_mode_name = self.state.modes.get(chat_id, "code")
            status = "Connected" if session_id else "No active session"
            pending_status = f"\n*Pending:* {pending.type}" if pending else ""
            mode_def = self._resolve_mode(current_mode_name)
            await self._send_message(
                chat_id,
                f"*Status:* {status}\n"
                f"*Mode:* {mode_def.emoji} {mode_def.name}\n"
                f"*Server:* `{self.server_url}`"
                f"{pending_status}",
            )

        elif command == "/stop":
            if self.state.processing.get(chat_id):
                self.state.processing[chat_id] = False
                await self._send_message(chat_id, "Operation cancelled.")
            else:
                await self._send_message(chat_id, "No operation in progress.")

        elif command == "/cancel":
            if chat_id in self.state.pending:
                del self.state.pending[chat_id]
                await self._send_message(chat_id, "Pending interaction cancelled.")
            else:
                await self._send_message(chat_id, "No pending interaction.")

        elif command == "/thinking":
            self.config.settings.show_thinking = not self.config.settings.show_thinking
            status = "enabled" if self.config.settings.show_thinking else "disabled"
            await self._send_message(chat_id, f"Show thinking {status}.")

        elif command == "/tools":
            self.config.settings.show_tool_calls = not self.config.settings.show_tool_calls
            status = "enabled" if self.config.settings.show_tool_calls else "disabled"
            await self._send_message(chat_id, f"Show tool calls {status}.")

        elif command == "/tgcommands":
            try:
                registered = await self._bot.get_my_commands()
                if registered:
                    lines = [f"/{c['command']} - {c['description']}" for c in registered]
                    text = f"*Registered commands ({len(registered)}):*\n\n" + "\n".join(lines)
                else:
                    text = "No commands registered with Telegram."
            except Exception as exc:
                text = f"Failed to fetch commands: {exc}"
            await self._send_message(chat_id, text)

        elif command == "/tgsettings":
            await self._send_message(
                chat_id,
                "*Telegram Display Settings:*\n\n"
                f"Show thinking: `{self.config.settings.show_thinking}`\n"
                f"Show tools: `{self.config.settings.show_tool_calls}`\n"
                f"Compact mode: `{self.config.settings.compact_mode}`\n"
                f"Update interval: `{self.config.settings.update_interval_ms}ms`",
            )

        elif command == "/tghelp":
            mode_lines = "\n".join(_provider.format_mode_help_lines())
            await self._send_message(
                chat_id,
                "*EmDash Telegram Bot*\n\n"
                "Send any message or slash command to interact with the EmDash agent.\n\n"
                f"*Mode commands:*\n"
                f"{mode_lines}\n"
                "/mode - Show current mode\n"
                "/reset - Reset session\n\n"
                "*Agent commands (forwarded):*\n"
                "/todos - Show todo list\n"
                "/status - Show project status\n"
                "/help - Show all agent commands\n\n"
                "*Telegram-only commands:*\n"
                "/stop - Cancel current operation\n"
                "/cancel - Cancel pending interaction\n"
                "/tgstatus - Bot connection status\n"
                "/tgsettings - Display settings\n"
                "/thinking - Toggle thinking display\n"
                "/tools - Toggle tool calls display\n"
                "/update - Update emdash and restart\n"
                "/tglogout - Remove bot config and logout\n"
                "/tghelp - This help message\n\n"
                "*Responding to questions:*\n"
                "Reply with option number (1, 2, 3...) or type your answer.\n\n"
                "*Plan approval:*\n"
                'Reply "yes" to approve, "no" to reject, or type feedback.',
            )

        elif command == "/reset":
            # Reset session for this chat
            if chat_id in self.state.sessions:
                del self.state.sessions[chat_id]
            await self._send_message(chat_id, "\U0001f504 Session reset.")

        elif command == "/tglogout":
            await self._send_message(
                chat_id,
                "\U0001f6aa Logging out\u2026\n\n"
                "Bot configuration has been removed. "
                "Run `em --open --channel telegram` again to set up a new bot.",
            )
            delete_config()
            await self.stop()

        elif command == "/update":
            await self._handle_update_command(chat_id)

    # ─────────────────────────────────────────────────────────────────
    # Mode switching (data-driven via ModeDefinition)
    # ─────────────────────────────────────────────────────────────────

    def _resolve_mode(self, mode_name: str) -> ModeDefinition:
        """Look up a ModeDefinition by name, falling back to 'code'."""
        registry = _provider.get_mode_registry()
        return registry.get(mode_name, registry["code"])

    def _resolve_agent_type(self, chat_id: int) -> str:
        """Resolve the effective agent_type for a chat.

        If the current mode defines an ``agent_type`` override, use it.
        Otherwise fall back to the bridge-level default.
        """
        current_mode_name = self.state.modes.get(chat_id, "code")
        mode_def = self._resolve_mode(current_mode_name)
        return mode_def.agent_type or self.agent_type

    async def _handle_mode_switch(self, chat_id: int, mode_def: ModeDefinition) -> None:
        """Switch the chat to a new mode.

        Updates the per-chat mode, optionally resets the session, and
        sends a confirmation message.  Works for any mode registered in
        the provider's mode registry.

        Args:
            chat_id: Telegram chat ID.
            mode_def: The mode to switch to.
        """
        self.state.modes[chat_id] = mode_def.name

        session_reset = ""
        if mode_def.resets_session and chat_id in self.state.sessions:
            del self.state.sessions[chat_id]
            session_reset = " (session reset)"

        await self._send_message(
            chat_id,
            f"\u2705 Switched to *{mode_def.label}*{session_reset}\n\n"
            f"_{mode_def.description}_",
        )

    async def _handle_mode_display(self, chat_id: int) -> None:
        """Display the current mode and list alternatives.

        Args:
            chat_id: Telegram chat ID.
        """
        current_mode_name = self.state.modes.get(chat_id, "code")
        mode_def = self._resolve_mode(current_mode_name)

        # Build hints for other available modes
        registry = _provider.get_mode_registry()
        other_modes = [m for m in registry.values() if m.name != current_mode_name]
        hints = ", ".join(f"{m.command} for {m.label}" for m in other_modes)

        await self._send_message(
            chat_id,
            f"{mode_def.emoji} Current mode: *{mode_def.name}*\n\n"
            f"_Use {hints}._",
        )

    async def _handle_update_command(self, chat_id: int) -> None:
        """Handle /update command — update emdash and signal restart.

        Args:
            chat_id: Telegram chat ID
        """
        await self._send_message(chat_id, "⬆️ Updating emdash... this may take a moment.")

        try:
            import subprocess

            install_url = "https://raw.githubusercontent.com/mendyEdri/emdash.dev/main/scripts/install.sh"
            result = subprocess.run(
                f"curl -sSL {install_url} | bash",
                shell=True,
                executable="/bin/bash",
                capture_output=True,
                text=True,
                timeout=300,
            )

            if result.returncode == 0:
                await self._send_message(
                    chat_id,
                    "✅ Update complete! Restarting...",
                )
                # Signal the process to restart by exiting —
                # the wrapper script (em-daemon) will restart us
                self._running = False
                os._exit(42)  # Special exit code for "restart requested"
            else:
                error_tail = (result.stderr or result.stdout or "unknown error")[-500:]
                await self._send_message(
                    chat_id,
                    f"❌ Update failed:\n```\n{error_tail}\n```",
                )
        except subprocess.TimeoutExpired:
            await self._send_message(chat_id, "❌ Update timed out after 5 minutes.")
        except Exception as e:
            await self._send_message(chat_id, f"❌ Update error: {e}")

    async def _process_agent_message(
        self, chat_id: int, message: str, images: list[dict[str, str]] | None = None,
    ) -> None:
        """Process a message through the EmDash agent.

        Args:
            chat_id: Telegram chat ID
            message: User message to process
            images: Optional list of base64-encoded image dicts
        """
        self.state.processing[chat_id] = True

        # Get or create session
        session_id = self.state.sessions.get(chat_id)

        # Create formatter with settings
        formatter = SSEEventFormatter(
            show_thinking=self.config.settings.show_thinking,
            show_tools=self.config.settings.show_tool_calls,
            compact=self.config.settings.compact_mode,
        )

        # Start continuous typing indicator (refreshes every few seconds)
        typing_task = asyncio.create_task(self._typing_loop(chat_id))

        try:
            # Stream from agent
            last_update_time = 0.0
            update_interval = self.config.settings.update_interval_ms / 1000.0
            has_sent_response = False

            # Get current mode and effective agent type for this chat
            current_mode = self.state.modes.get(chat_id, "code")
            agent_type = self._resolve_agent_type(chat_id)

            async for event_type, data in self._stream_agent_chat(
                message, session_id, current_mode, agent_type=agent_type, images=images,
            ):
                # Check if cancelled
                if not self.state.processing.get(chat_id):
                    break

                # Update session ID if provided (don't send session_start as separate message)
                if event_type == "session_start" and data.get("session_id"):
                    self.state.sessions[chat_id] = data["session_id"]
                    continue  # Skip sending session_start notification

                # Skip session_end notifications (clutters the chat)
                if event_type == "session_end":
                    continue

                # Handle interactive events - store pending state
                if event_type == "clarification":
                    await self._handle_clarification_event(chat_id, data)
                    continue

                if event_type == "plan_submitted":
                    await self._handle_plan_submitted_event(chat_id, data)
                    continue

                if event_type == "plan_mode_requested":
                    await self._handle_plan_mode_event(chat_id, data)
                    continue

                # Handle browser session events directly
                if event_type == "browser_session":
                    await self._handle_browser_session_event(chat_id, data)
                    continue

                # Detect browser session creation from tool results
                # Supports both legacy Firecrawl and Browserbase MCP tool names
                if event_type == "tool_result":
                    tool_name = data.get("name", data.get("tool_name", ""))
                    result_data = data.get("result") or data.get("data") or {}
                    if isinstance(result_data, dict):
                        live_url = result_data.get("live_view_url") or result_data.get("liveUrl")
                        if tool_name in ("browser_session_create", "browserbase_session_create") and live_url:
                            await self._handle_browser_session_event(chat_id, {
                                "action": "created",
                                "session_id": result_data.get("session_id") or result_data.get("sessionId", ""),
                                "live_view_url": live_url,
                                "expires_at": result_data.get("expires_at"),
                            })
                        elif tool_name in ("browser_session_delete", "browserbase_session_close") and result_data.get("success"):
                            await self._handle_browser_session_event(chat_id, {
                                "action": "closed",
                                "session_id": result_data.get("session_id") or result_data.get("sessionId", ""),
                            })

                # Format the event
                formatted = formatter.format_event(event_type, data)

                # Track if we've sent a response (to avoid duplicates)
                if event_type == "response":
                    has_sent_response = True

                # Send formatted message
                if formatted:
                    now = time.time()

                    # Rate limit updates
                    if formatted.is_update and (now - last_update_time) < update_interval:
                        continue

                    last_update_time = now

                    # Edit or send new message
                    if formatted.is_update and chat_id in self.state.last_message_ids:
                        await self._edit_message(
                            chat_id,
                            self.state.last_message_ids[chat_id],
                            formatted.text,
                            formatted.parse_mode,
                        )
                    else:
                        msg = await self._send_message(
                            chat_id, formatted.text, formatted.parse_mode
                        )
                        if msg:
                            self.state.last_message_ids[chat_id] = msg.message_id

            # Flush any pending partial content (only if we haven't sent a full response)
            if not has_sent_response:
                pending_content = formatter.get_pending_content()
                if pending_content:
                    await self._send_message(chat_id, pending_content.text, pending_content.parse_mode)

        except Exception as e:
            if self.on_message:
                self.on_message("error", {"error": str(e)})
            await self._send_message(chat_id, f"Error: {str(e)}")

        finally:
            typing_task.cancel()
            self.state.processing[chat_id] = False

    async def _stream_agent_chat(
        self,
        message: str,
        session_id: str | None = None,
        mode: str = "code",
        *,
        agent_type: str | None = None,
        images: list[dict[str, str]] | None = None,
    ) -> AsyncIterator[tuple[str, dict]]:
        """Stream agent chat response via SSE.

        Args:
            message: User message
            session_id: Optional session ID for continuity
            mode: Agent mode (code, plan, or open)
            agent_type: Agent type override (resolved per-chat). Falls
                back to the bridge-level default if ``None``.
            images: Optional list of base64-encoded image dicts

        Yields:
            Tuples of (event_type, data)
        """
        if not self._http_client:
            return

        payload: dict[str, Any] = {
            "message": message,
            "options": {
                "max_iterations": 50,
                "verbose": True,
                "mode": mode,
                "agent_type": agent_type or self.agent_type,
            },
        }

        if images:
            payload["images"] = images

        if session_id:
            payload["session_id"] = session_id

        url = f"{self.server_url}/api/agent/chat"

        try:
            async with self._http_client.stream("POST", url, json=payload) as response:
                response.raise_for_status()

                current_event = None

                async for line in response.aiter_lines():
                    line = line.strip()

                    if line.startswith("event: "):
                        current_event = line[7:]
                    elif line.startswith("data: "):
                        if current_event:
                            try:
                                data = json.loads(line[6:])
                                if data is None:
                                    data = {}
                                yield current_event, data
                            except json.JSONDecodeError:
                                pass
                    elif line == ": ping":
                        # Keep-alive ping
                        pass

        except httpx.HTTPError as e:
            yield "error", {"message": f"HTTP error: {str(e)}"}
        except Exception as e:
            yield "error", {"message": str(e)}

    async def _send_message(
        self,
        chat_id: int,
        text: str,
        parse_mode: str | None = "Markdown",
    ) -> TelegramMessage | None:
        """Send a message to a chat.

        Args:
            chat_id: Target chat ID
            text: Message text
            parse_mode: Parse mode for formatting

        Returns:
            Sent message, or None on error
        """
        if not self._bot:
            return None

        try:
            return await self._bot.send_message(
                chat_id, text, parse_mode=parse_mode
            )
        except Exception as e:
            # Try sending without parse mode if Markdown fails
            if parse_mode:
                try:
                    return await self._bot.send_message(
                        chat_id, text, parse_mode=None
                    )
                except Exception:
                    pass

            if self.on_message:
                self.on_message("send_error", {"error": str(e)})
            return None

    async def _edit_message(
        self,
        chat_id: int,
        message_id: int,
        text: str,
        parse_mode: str | None = "Markdown",
    ) -> None:
        """Edit an existing message.

        Args:
            chat_id: Chat containing the message
            message_id: Message ID to edit
            text: New text
            parse_mode: Parse mode for formatting
        """
        if not self._bot:
            return

        try:
            await self._bot.edit_message_text(
                chat_id, message_id, text, parse_mode=parse_mode
            )
        except Exception:
            # Editing can fail if message is identical - ignore
            pass

    async def _send_long_message(self, chat_id: int, text: str) -> None:
        """Send a long message, splitting if necessary.

        Args:
            chat_id: Target chat ID
            text: Message text (can be longer than 4096 chars)
        """
        max_len = self.config.settings.max_message_length

        # If short enough, send as-is
        if len(text) <= max_len:
            await self._send_message(chat_id, text)
            return

        # Split into chunks at paragraph boundaries
        chunks = []
        current_chunk = ""

        paragraphs = text.split("\n\n")
        for para in paragraphs:
            if len(current_chunk) + len(para) + 2 <= max_len:
                if current_chunk:
                    current_chunk += "\n\n"
                current_chunk += para
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                # If paragraph itself is too long, split it
                if len(para) > max_len:
                    words = para.split()
                    current_chunk = ""
                    for word in words:
                        if len(current_chunk) + len(word) + 1 <= max_len:
                            if current_chunk:
                                current_chunk += " "
                            current_chunk += word
                        else:
                            chunks.append(current_chunk)
                            current_chunk = word
                else:
                    current_chunk = para

        if current_chunk:
            chunks.append(current_chunk)

        # Send each chunk
        for i, chunk in enumerate(chunks):
            if len(chunks) > 1:
                chunk = f"*({i + 1}/{len(chunks)})*\n\n{chunk}"
            await self._send_message(chat_id, chunk)
            # Small delay between chunks to avoid rate limits
            if i < len(chunks) - 1:
                await asyncio.sleep(0.5)

    # ─────────────────────────────────────────────────────────────────────────────
    # Interactive event handlers
    # ─────────────────────────────────────────────────────────────────────────────

    async def _handle_browser_session_event(self, chat_id: int, data: dict) -> None:
        """Handle browser session event - send live view URL to user.

        When a shared browser session is created, sends the live view URL
        as a prominent message so the Telegram user can open it in their
        mobile/desktop browser and see what the agent is doing.

        Args:
            chat_id: Telegram chat ID
            data: Browser session event data
        """
        action = data.get("action", "")
        live_view_url = data.get("live_view_url", "")
        session_id = data.get("session_id", "")

        if action == "created" and live_view_url:
            text = (
                "🌐 *Shared Browser Session*\n\n"
                "Tap the link below to see and control the browser "
                "together with the agent:\n\n"
                f"👉 {live_view_url}\n\n"
                f"_Session: `{session_id[:12]}...`_"
            )
            if data.get("expires_at"):
                text += f"\n_Expires: {data['expires_at']}_"
            await self._send_message(chat_id, text)

        elif action == "closed":
            await self._send_message(chat_id, "🌐 Browser session ended.")

    async def _handle_clarification_event(self, chat_id: int, data: dict) -> None:
        """Handle clarification event - prompt user for response.

        Args:
            chat_id: Telegram chat ID
            data: Clarification event data
        """
        question = data.get("question", "")
        options = data.get("options", [])
        context = data.get("context", "")

        # Ensure options is a list
        if isinstance(options, str):
            options = [options] if options else []

        # Store pending interaction
        self.state.pending[chat_id] = PendingInteraction(
            type="clarification",
            data=data,
            options=options,
        )

        # Build message
        text = f"❓ *Question:*\n{question}"

        if options:
            text += "\n\n*Options:*"
            for i, opt in enumerate(options, 1):
                text += f"\n{i}. {opt}"
            text += "\n\n_Reply with option number (1-{}) or type your answer_".format(len(options))
        else:
            text += "\n\n_Type your answer_"

        await self._send_message(chat_id, text)

    async def _handle_plan_submitted_event(self, chat_id: int, data: dict) -> None:
        """Handle plan submitted event - prompt user for approval.

        Args:
            chat_id: Telegram chat ID
            data: Plan submitted event data
        """
        plan = data.get("plan", "")

        # Store pending interaction
        self.state.pending[chat_id] = PendingInteraction(
            type="plan_approval",
            data=data,
        )

        # Build message
        text = f"📋 *Plan Submitted:*\n\n{plan}"
        text += "\n\n_Reply:_"
        text += '\n• "approve" or "yes" to proceed'
        text += '\n• "reject" or "no" to cancel'
        text += "\n• Or type feedback to request changes"

        await self._send_long_message(chat_id, text)

    async def _handle_plan_mode_event(self, chat_id: int, data: dict) -> None:
        """Handle plan mode request event - prompt user for approval.

        Args:
            chat_id: Telegram chat ID
            data: Plan mode request event data
        """
        reason = data.get("reason", "")

        # Store pending interaction
        self.state.pending[chat_id] = PendingInteraction(
            type="planmode_request",
            data=data,
        )

        # Build message
        text = "🗺️ *Plan Mode Requested*"
        if reason:
            text += f"\n\n{reason}"
        text += "\n\n_Reply:_"
        text += '\n• "approve" or "yes" to enter plan mode'
        text += '\n• "reject" or "no" to continue without plan'

        await self._send_message(chat_id, text)

    async def _handle_pending_response(
        self, chat_id: int, text: str, pending: PendingInteraction,
    ) -> None:
        """Handle user response to a pending interaction.

        Args:
            chat_id: Telegram chat ID
            text: User's response text
            pending: The pending interaction
        """
        # Clear pending state
        del self.state.pending[chat_id]

        if pending.type == "clarification":
            await self._process_clarification_answer(chat_id, text, pending)
        elif pending.type == "plan_approval":
            await self._process_plan_approval(chat_id, text, pending)
        elif pending.type == "planmode_request":
            await self._process_planmode_approval(chat_id, text, pending)

    async def _process_clarification_answer(
        self, chat_id: int, text: str, pending: PendingInteraction,
    ) -> None:
        """Process clarification answer and continue agent.

        Args:
            chat_id: Telegram chat ID
            text: User's answer
            pending: The pending clarification
        """
        session_id = self.state.sessions.get(chat_id)
        if not session_id:
            await self._send_message(chat_id, "Error: No active session")
            return

        # Check if user replied with option number
        answer = text.strip()
        if pending.options and answer.isdigit():
            idx = int(answer) - 1
            if 0 <= idx < len(pending.options):
                answer = pending.options[idx]

        await self._send_message(chat_id, f"✅ Selected: {answer}\nContinuing...")

        # Call continuation endpoint and stream response
        await self._stream_continuation(
            chat_id,
            f"{self.server_url}/api/agent/chat/{session_id}/clarification/answer",
            params={"answer": answer},
        )

    async def _process_plan_approval(
        self, chat_id: int, text: str, pending: PendingInteraction
    ) -> None:
        """Process plan approval/rejection and continue agent.

        Args:
            chat_id: Telegram chat ID
            text: User's response
            pending: The pending plan approval
        """
        session_id = self.state.sessions.get(chat_id)
        if not session_id:
            await self._send_message(chat_id, "Error: No active session")
            return

        response = text.strip().lower()

        if response in ("approve", "yes", "y", "ok", "proceed"):
            await self._send_message(chat_id, "✅ Plan approved. Executing...")
            await self._stream_continuation(
                chat_id,
                f"{self.server_url}/api/agent/chat/{session_id}/plan/approve",
            )
        elif response in ("reject", "no", "n", "cancel"):
            await self._send_message(chat_id, "❌ Plan rejected.")
            await self._stream_continuation(
                chat_id,
                f"{self.server_url}/api/agent/chat/{session_id}/plan/reject",
                params={"feedback": ""},
            )
        else:
            # Treat as feedback
            await self._send_message(chat_id, f"📝 Feedback sent: {text[:50]}...")
            await self._stream_continuation(
                chat_id,
                f"{self.server_url}/api/agent/chat/{session_id}/plan/reject",
                params={"feedback": text},
            )

    async def _process_planmode_approval(
        self, chat_id: int, text: str, pending: PendingInteraction
    ) -> None:
        """Process plan mode approval/rejection and continue agent.

        Args:
            chat_id: Telegram chat ID
            text: User's response
            pending: The pending plan mode request
        """
        session_id = self.state.sessions.get(chat_id)
        if not session_id:
            await self._send_message(chat_id, "Error: No active session")
            return

        response = text.strip().lower()

        if response in ("approve", "yes", "y", "ok"):
            await self._send_message(chat_id, "✅ Entering plan mode...")
            await self._stream_continuation(
                chat_id,
                f"{self.server_url}/api/agent/chat/{session_id}/planmode/approve",
            )
        else:
            await self._send_message(chat_id, "Continuing without plan mode...")
            await self._stream_continuation(
                chat_id,
                f"{self.server_url}/api/agent/chat/{session_id}/planmode/reject",
                params={"feedback": text if response not in ("reject", "no", "n") else ""},
            )

    async def _stream_continuation(
        self,
        chat_id: int,
        url: str,
        params: dict | None = None,
    ) -> None:
        """Stream a continuation endpoint response.

        Args:
            chat_id: Telegram chat ID
            url: API endpoint URL
            params: Optional query parameters
        """
        if not self._http_client:
            return

        self.state.processing[chat_id] = True

        # Create formatter with settings
        formatter = SSEEventFormatter(
            show_thinking=self.config.settings.show_thinking,
            show_tools=self.config.settings.show_tool_calls,
            compact=self.config.settings.compact_mode,
        )

        # Start continuous typing indicator
        typing_task = asyncio.create_task(self._typing_loop(chat_id))

        try:
            response_content = ""
            last_update_time = 0.0
            update_interval = self.config.settings.update_interval_ms / 1000.0

            async with self._http_client.stream("POST", url, params=params) as response:
                response.raise_for_status()

                current_event = None

                async for line in response.aiter_lines():
                    # Check if cancelled
                    if not self.state.processing.get(chat_id):
                        break

                    line = line.strip()

                    if line.startswith("event: "):
                        current_event = line[7:]
                    elif line.startswith("data: "):
                        if current_event:
                            try:
                                data = json.loads(line[6:])
                                if data is None:
                                    data = {}

                                # Handle interactive events recursively
                                if current_event == "clarification":
                                    await self._handle_clarification_event(chat_id, data)
                                    continue
                                if current_event == "plan_submitted":
                                    await self._handle_plan_submitted_event(chat_id, data)
                                    continue
                                if current_event == "plan_mode_requested":
                                    await self._handle_plan_mode_event(chat_id, data)
                                    continue

                                # Handle browser session events
                                if current_event == "browser_session":
                                    await self._handle_browser_session_event(chat_id, data)
                                    continue

                                # Detect browser session from tool results
                                # Supports both legacy Firecrawl and Browserbase MCP tool names
                                if current_event == "tool_result":
                                    tool_name = data.get("name", data.get("tool_name", ""))
                                    result_data = data.get("result") or data.get("data") or {}
                                    if isinstance(result_data, dict):
                                        live_url = result_data.get("live_view_url") or result_data.get("liveUrl")
                                        if tool_name in ("browser_session_create", "browserbase_session_create") and live_url:
                                            await self._handle_browser_session_event(chat_id, {
                                                "action": "created",
                                                "session_id": result_data.get("session_id") or result_data.get("sessionId", ""),
                                                "live_view_url": live_url,
                                                "expires_at": result_data.get("expires_at"),
                                            })
                                        elif tool_name in ("browser_session_delete", "browserbase_session_close") and result_data.get("success"):
                                            await self._handle_browser_session_event(chat_id, {
                                                "action": "closed",
                                                "session_id": result_data.get("session_id") or result_data.get("sessionId", ""),
                                            })

                                # Format the event
                                formatted = formatter.format_event(current_event, data)

                                if current_event == "response":
                                    response_content = data.get("content", "")

                                if formatted:
                                    now = time.time()
                                    if formatted.is_update and (now - last_update_time) < update_interval:
                                        continue
                                    last_update_time = now

                                    msg = await self._send_message(
                                        chat_id, formatted.text, formatted.parse_mode
                                    )
                                    if msg:
                                        self.state.last_message_ids[chat_id] = msg.message_id

                            except json.JSONDecodeError:
                                pass

            # Send final response if we have one
            if response_content and chat_id not in self.state.pending:
                await self._send_long_message(chat_id, response_content)

        except Exception as e:
            if self.on_message:
                self.on_message("error", {"error": str(e)})
            await self._send_message(chat_id, f"Error: {str(e)}")

        finally:
            typing_task.cancel()
            self.state.processing[chat_id] = False
