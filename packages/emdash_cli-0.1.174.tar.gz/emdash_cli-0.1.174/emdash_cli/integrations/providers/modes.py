"""Agent mode definitions for messaging providers.

Defines mode metadata (emoji, description, agent_type) as structured data
so bridges can handle mode switching generically instead of hardcoding
per-mode logic.  Any platform (Telegram, Slack, etc.) can consume the
mode registry through CommandProvider.get_mode_registry().
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModeDefinition:
    """Platform-agnostic definition of an agent mode.

    Each mode maps a slash command to the behaviour the bridge should
    apply when the user switches to it: which emoji to display, what
    description to show, whether to override the agent type, and whether
    switching resets the current session.

    Attributes:
        name: Mode identifier (e.g., "plan", "code", "open").
        command: Slash command that activates this mode (e.g., "/plan").
        emoji: Display emoji for this mode.
        label: Human-readable label (e.g., "plan mode").
        description: Short description shown when switching.
        agent_type: Agent type override, or ``None`` to keep the
            bridge's default agent type.
        resets_session: Whether switching to this mode resets the chat
            session (default ``True``).
    """

    name: str
    command: str
    emoji: str
    label: str
    description: str
    agent_type: str | None = None
    resets_session: bool = True


# Default mode registry — all known agent modes.
# Providers can extend or override this via get_mode_registry().
DEFAULT_MODE_REGISTRY: dict[str, ModeDefinition] = {
    "plan": ModeDefinition(
        name="plan",
        command="/plan",
        emoji="\U0001f4cb",  # 📋
        label="plan mode",
        description="Plan mode explores the codebase and creates plans without making changes.",
    ),
    "code": ModeDefinition(
        name="code",
        command="/code",
        emoji="\U0001f4bb",  # 💻
        label="code mode",
        description="Code mode can execute changes and modify files.",
    ),
    "open": ModeDefinition(
        name="open",
        command="/open",
        emoji="\U0001f9e0",  # 🧠
        label="open mode",
        description="Open mode is a personal assistant that learns from you.",
        agent_type="open",
    ),
}
