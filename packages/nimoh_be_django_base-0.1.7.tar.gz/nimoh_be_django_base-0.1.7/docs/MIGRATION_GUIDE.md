# Migration Guide: Adopting nimoh-be-django-base

This guide covers two scenarios:

1. **[New project](#new-project)** — starting a fresh Django project
2. **[Existing project](#existing-project)** — converting a project that already
   has its own `core`, `authentication`, `monitoring`, or `privacy` apps

---

## New Project

The fastest path is the interactive CLI:

```bash
mkdir my-new-app && cd my-new-app   
python3 -m venv .venv
source .venv/bin/activate   
pip install "nimoh-be-django-base[cli]"
nimoh-base init
```

If you prefer a manual setup, follow Quick Start steps 1–5 in the
[README](../README.md#quick-start).

---

## Existing Project

This section documents how to migrate a project that previously contained
standalone `apps/core`, `apps/authentication`, `apps/monitoring`, and/or
`apps/privacy` apps (the pattern used by the original `tast-be-app` before
Phase 7 of the extraction project).

### Prerequisites

- Python ≥ 3.12
- Django ≥ 5.1
- An existing Django project with a git history you want to keep
- Access to the `nimoh-be-django-base` package (PyPI or git+ssh)

---

### Step 1 — Install the package

```bash
# requirements.txt or pyproject.toml [dependencies]
nimoh-be-django-base @ git+ssh://git@github.com/ThriledLokki983/nimoh-be-django-base.git

# Or from PyPI once published:
# nimoh-be-django-base>=0.1.0
```

```bash
pip install -r requirements.txt
```

For Docker with git+ssh:

```dockerfile
RUN --mount=type=ssh pip install -r requirements.txt
```

---

### Step 2 — Create your concrete User model migration directory

Before restructuring anything, **create a new migration directory** to hold the
package's app migrations on behalf of your project:

```
<project_root>/
└── appname_migrations/
    ├── __init__.py
    ├── nimoh_auth/
    │   └── __init__.py
    ├── nimoh_monitoring/
    │   └── __init__.py
    └── nimoh_privacy/
        └── __init__.py
```

Register these with `MIGRATION_MODULES`:

```python
# config/settings/base.py
MIGRATION_MODULES = {
    "nimoh_auth": "appname_migrations.nimoh_auth",
    "nimoh_monitoring": "appname_migrations.nimoh_monitoring",
    "nimoh_privacy": "appname_migrations.nimoh_privacy",
}
```

---

### Step 3 — Update `INSTALLED_APPS`

Replace your old app references with the package helpers:

```python
# Before
INSTALLED_APPS = [
    ...
    "apps.core",
    "apps.authentication",
    "apps.monitoring",
    "apps.privacy",
    ...
]

# After
from nimoh_base.conf import NimohBaseSettings

INSTALLED_APPS = NimohBaseSettings.get_base_apps() + [
    ...
    "myproject.profiles",
    "myproject.onboarding",
    ...
]
```

---

### Step 4 — Add `NIMOH_BASE` config

```python
NIMOH_BASE = {
    "SITE_NAME": "Your App Name",
    "SUPPORT_EMAIL": "support@yourapp.com",
    "NOREPLY_EMAIL": "noreply@yourapp.com",
    # keep remaining keys at defaults for now
}
```

---

### Step 5 — Update middleware and REST_FRAMEWORK

```python
# Before (manual list)
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "apps.core.middleware.SecurityHeadersMiddleware",
    ...
]

# After
MIDDLEWARE = NimohBaseSettings.get_base_middleware()
REST_FRAMEWORK = NimohBaseSettings.get_base_rest_framework()
```

---

### Step 6 — Update `AUTH_USER_MODEL`

If your old project defined `AUTH_USER_MODEL = "authentication.User"`, keep the
model pointing at the **same table** by subclassing `AbstractNimohUser`:

```python
# profiles/models.py  (your user model)
from nimoh_base.auth.models import AbstractNimohUser

class User(AbstractNimohUser):
    # copy over any extra fields from your old User model
    class Meta(AbstractNimohUser.Meta):
        swappable = "AUTH_USER_MODEL"
```

```python
# settings
AUTH_USER_MODEL = "profiles.User"
```

---

### Step 7 — Update all imports across the codebase

Search and replace import paths:

| Old import | New import |
|-----------|-----------|
| `from apps.core.models import TimeStampedModel` | `from nimoh_base.core.models import TimeStampedModel` |
| `from apps.core.exceptions import …` | `from nimoh_base.core.exceptions import …` |
| `from apps.authentication.models import AbstractUser` | `from nimoh_base.auth.models import AbstractNimohUser` |
| `from apps.authentication.serializers import …` | `from nimoh_base.auth.serializers import …` |
| `from apps.monitoring.models import …` | `from nimoh_base.monitoring.models import …` |
| `from apps.privacy.models import …` | `from nimoh_base.privacy.models import …` |
| `from apps.privacy.services import …` | `from nimoh_base.privacy.services import …` |

```bash
# Quick grep to find remaining old imports
grep -r "from apps\.\(core\|authentication\|monitoring\|privacy\)" . \
     --include="*.py" -l
```

---

### Step 8 — Update URL configuration

```python
# config/urls.py
from nimoh_base.conf.urls import nimoh_base_urlpatterns

urlpatterns = [
    path("admin/", admin.site.urls),
    *nimoh_base_urlpatterns(api_prefix="api/v1/"),
    # project-specific routes
]
```

---

### Step 9 — Handle existing migration history

If your database already has tables created by the **old** apps, you need to
point Django at the new package migrations without losing row data.

**Option A — Fresh database (dev / new deployments)**

Simply run:

```bash
python manage.py migrate
```

**Option B — Existing database with data to preserve**

The old apps used different table names (e.g. `authentication_user` vs
`nimoh_auth_user`).  You have two choices:

_Sub-option B1: Fake the initial migration_

```bash
# Tell Django the nimoh_auth initial migration has already been applied
python manage.py migrate nimoh_auth --fake-initial
python manage.py migrate nimoh_monitoring --fake-initial
python manage.py migrate nimoh_privacy --fake-initial
```

Only works if the table schema matches exactly (same columns, same constraints).

_Sub-option B2: Write a data migration_

Create a custom migration that renames the old tables to the new names:

```python
# appname_migrations/nimoh_auth/0001_rename_tables.py
from django.db import migrations

class Migration(migrations.Migration):
    dependencies = []

    operations = [
        migrations.RunSQL(
            "ALTER TABLE authentication_user RENAME TO nimoh_auth_user;",
            reverse_sql="ALTER TABLE nimoh_auth_user RENAME TO authentication_user;",
        ),
        # … repeat for other tables
    ]
```

Then fake the package's own initial migration:

```bash
python manage.py migrate nimoh_auth --fake-initial
```

See `scripts/migrate_to_nimoh_base.sh` in the `tast-be-app` repo for a
worked example covering all four apps.

---

### Step 10 — Remove the old apps

Once migrations and imports are updated and your test suite passes:

```bash
git rm -r apps/core apps/authentication apps/monitoring apps/privacy
git commit -m "chore: remove extracted apps — now consumed from nimoh-be-django-base"
```

---

### Step 11 — Run the test suite

```bash
pytest tests/ -v
```

Address any remaining import errors or missing fixtures before committing.

---

## Common Pitfalls

| Symptom | Cause | Fix |
|---------|-------|-----|
| `ImproperlyConfigured: NIMOH_BASE is missing required key 'SITE_NAME'` | `NIMOH_BASE` dict not in settings | Add the `NIMOH_BASE = {…}` block to `base.py` |
| `LookupError: No installed app with label 'nimoh_auth'` | Package apps not in `INSTALLED_APPS` | Use `NimohBaseSettings.get_base_apps()` |
| `InconsistentMigrationHistory` | Migration modules not registered | Add `MIGRATION_MODULES` pointing to your migration dirs |
| `django.db.utils.ProgrammingError: relation "nimoh_auth_user" does not exist` | Old table not renamed | Use `--fake-initial` or write a rename migration |
| JWT tokens rejected after migration | JWT secret changed / `AUTH_USER_MODEL` changed | Re-issue tokens; do not change `AUTH_USER_MODEL` post-initial-migration |
