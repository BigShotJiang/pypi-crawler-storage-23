"""
Core health check utilities.

Provides a single source of truth for dependency health checks
(database, cache, email, Celery) used across the application.
"""

import logging
import time
from typing import Any

from django.core.cache import cache
from django.db import connections

logger = logging.getLogger(__name__)


def check_database(alias: str = "default") -> dict[str, Any]:
    """
    Check database connectivity and measure response time.

    Args:
        alias: Database alias to check (default: 'default').

    Returns:
        Dict with 'status', 'response_time_ms', and 'details'.
    """
    start = time.perf_counter()
    try:
        db_conn = connections[alias]
        with db_conn.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return {
            "status": "healthy",
            "response_time_ms": elapsed,
            "details": f"{db_conn.vendor.title()} connection successful",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.error("Database health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "details": f"Database connection failed: {type(e).__name__}",
        }


def check_cache() -> dict[str, Any]:
    """
    Check Redis cache connectivity with a write/read/delete cycle.

    Returns:
        Dict with 'status', 'response_time_ms', and 'details'.
    """
    start = time.perf_counter()
    try:
        test_key = f"health_check_{int(time.time())}"
        test_value = "ok"
        cache.set(test_key, test_value, timeout=10)
        retrieved = cache.get(test_key)
        cache.delete(test_key)
        if retrieved != test_value:
            raise ValueError("Cache write/read mismatch")
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return {
            "status": "healthy",
            "response_time_ms": elapsed,
            "details": "Redis cache connection successful",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.warning("Cache health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "details": f"Cache connection failed: {type(e).__name__}",
        }


def check_email() -> dict[str, Any]:
    """
    Check email backend connectivity.

    Returns:
        Dict with 'status', 'response_time_ms', and 'details'.
    """
    start = time.perf_counter()
    try:
        from django.core.mail import get_connection

        conn = get_connection()
        conn.open()
        conn.close()
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return {
            "status": "healthy",
            "response_time_ms": elapsed,
            "details": "Email service connection successful",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.warning("Email health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "details": f"Email service connection failed: {type(e).__name__}",
        }


def check_celery(timeout: float = 2.0) -> dict[str, Any]:
    """
    Check Celery worker availability.

    Args:
        timeout: Seconds to wait for worker response.

    Returns:
        Dict with 'status', 'response_time_ms', 'workers', and optionally 'error'.
    """
    start = time.perf_counter()
    try:
        from celery import current_app

        inspect = current_app.control.inspect(timeout=timeout)
        active_workers = inspect.active()
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        if active_workers:
            return {
                "status": "healthy",
                "response_time_ms": elapsed,
                "workers": len(active_workers),
                "details": f"{len(active_workers)} active worker(s)",
            }
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "workers": 0,
            "details": "No active Celery workers found",
        }
    except Exception as e:
        elapsed = round((time.perf_counter() - start) * 1000, 2)
        logger.error("Celery health check failed", exc_info=e)
        return {
            "status": "unhealthy",
            "response_time_ms": elapsed,
            "workers": 0,
            "details": f"Celery check failed: {type(e).__name__}",
        }
