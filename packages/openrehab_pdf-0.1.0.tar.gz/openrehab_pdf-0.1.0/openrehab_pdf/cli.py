import sys
import argparse
from pathlib import Path

from openrehab_pdf import Config, PDFProcessor


def main():
    parser = argparse.ArgumentParser(
        description="OpenRehab PDF - PDF to Markdown Conversion for Rehabilitation Medicine"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    convert_parser = subparsers.add_parser("convert", help="Convert a single PDF file")
    convert_parser.add_argument("pdf_file", help="Path to PDF file")
    convert_parser.add_argument("-o", "--output", help="Output Markdown file")
    convert_parser.add_argument("-e", "--extractor", default="pymupdf", help="Extractor type (pymupdf, pdfplumber)")
    
    batch_parser = subparsers.add_parser("batch", help="Batch convert PDF files")
    batch_parser.add_argument("-i", "--input", help="Input directory", action="append", default=[])
    batch_parser.add_argument("-o", "--output", default="./output", help="Output directory")
    batch_parser.add_argument("-c", "--config", help="Path to config YAML file")
    batch_parser.add_argument("-e", "--extractor", help="Extractor type")
    
    args = parser.parse_args()
    
    if args.command == "convert":
        config = Config()
        if args.extractor:
            config.process_extractor = args.extractor
        
        pdf_path = Path(args.pdf_file)
        output_path = Path(args.output) if args.output else Path(args.pdf_file).with_suffix(".md")
        
        processor = PDFProcessor(config)
        success, message = processor.process_single_pdf(pdf_path, output_path.parent)
        
        if success:
            print("Success:", message)
            return 0
        else:
            print("Error:", message)
            return 1
    
    elif args.command == "batch":
        if args.config:
            config = Config.from_yaml(args.config)
        else:
            config = Config()
            if args.input:
                config.input_directories = args.input
            config.output_base_dir = args.output
            if args.extractor:
                config.process_extractor = args.extractor
        
        processor = PDFProcessor(config)
        
        total_success = 0
        total_fail = 0
        
        output_dir = Path(config.output_base_dir)
        
        for input_dir_str in config.input_directories:
            input_dir = Path(input_dir_str)
            if not input_dir.is_absolute():
                input_dir = Path.cwd() / input_dir
            
            if not input_dir.exists():
                print("Warning: Directory not found -", input_dir)
                continue
            
            success, fail, results = processor.process_directory(input_dir, output_dir)
            total_success += success
            total_fail += fail
        
        print("\n" + "=" * 60)
        print("OpenRehab PDF - Batch processing complete!")
        print("Success:", total_success)
        print("Failed:", total_fail)
        print("=" * 60)
        
        return 0 if total_fail == 0 else 1
    
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
