
from pathlib import Path
import abc


class BaseExtractor(abc.ABC):
    def __init__(self, pdf_path):
        self.pdf_path = Path(pdf_path)
        self.pages_data = []
    
    @abc.abstractmethod
    def extract_text(self):
        pass
    
    @abc.abstractmethod
    def extract_tables(self):
        pass
    
    @abc.abstractmethod
    def get_metadata(self):
        pass


class PyMuPDFExtractor(BaseExtractor):
    def __init__(self, pdf_path):
        super().__init__(pdf_path)
    
    def extract_text(self):
        import fitz
        
        full_text = []
        page_count = 0
        
        doc = fitz.open(self.pdf_path)
        page_count = len(doc)
        
        for i, page in enumerate(doc):
            text = page.get_text("text")
            if text:
                full_text.append("--- Page %d ---\n\n" % (i + 1) + text)
            
            self.pages_data.append({
                "page_num": i + 1,
                "text": text,
                "has_text": bool(text)
            })
        
        doc.close()
        return "\n\n".join(full_text), page_count
    
    def extract_tables(self):
        tables = []
        
        try:
            import pdfplumber
            with pdfplumber.open(self.pdf_path) as pdf:
                for i, page in enumerate(pdf.pages):
                    page_tables = page.find_tables()
                    if page_tables:
                        for table_idx, table in enumerate(page_tables):
                            data = table.extract()
                            if data:
                                tables.append({
                                    "page_num": i + 1,
                                    "table_idx": table_idx,
                                    "data": data
                                })
        except ImportError:
            pass
        except Exception as e:
            print("表格提取警告:", e)
        
        return tables
    
    def get_metadata(self):
        import fitz
        doc = fitz.open(self.pdf_path)
        metadata = {
            "filename": self.pdf_path.name,
            "stem": self.pdf_path.stem,
            "total_pages": len(doc),
            "metadata": doc.metadata
        }
        doc.close()
        return metadata


class PDFPlumberExtractor(BaseExtractor):
    def __init__(self, pdf_path):
        super().__init__(pdf_path)
    
    def extract_text(self):
        import pdfplumber
        
        full_text = []
        page_count = 0
        
        with pdfplumber.open(self.pdf_path) as pdf:
            page_count = len(pdf.pages)
            
            for i, page in enumerate(pdf.pages):
                text = page.extract_text()
                if text:
                    full_text.append("--- Page %d ---\n\n" % (i + 1) + text)
                
                self.pages_data.append({
                    "page_num": i + 1,
                    "text": text,
                    "has_text": bool(text)
                })
        
        return "\n\n".join(full_text), page_count
    
    def extract_tables(self):
        tables = []
        
        try:
            import pdfplumber
            with pdfplumber.open(self.pdf_path) as pdf:
                for i, page in enumerate(pdf.pages):
                    page_tables = page.extract_tables()
                    if page_tables:
                        for table_idx, table in enumerate(page_tables):
                            tables.append({
                                "page_num": i + 1,
                                "table_idx": table_idx,
                                "data": table
                            })
        except Exception as e:
            print("表格提取警告:", e)
        
        return tables
    
    def get_metadata(self):
        import pdfplumber
        with pdfplumber.open(self.pdf_path) as pdf:
            return {
                "filename": self.pdf_path.name,
                "stem": self.pdf_path.stem,
                "total_pages": len(pdf.pages),
                "metadata": pdf.metadata
            }


_extractor_registry = {
    "pymupdf": PyMuPDFExtractor,
    "pdfplumber": PDFPlumberExtractor,
}


def register_extractor(name, extractor_class):
    _extractor_registry[name.lower()] = extractor_class


def create_extractor(extractor_type, pdf_path):
    extractor_class = _extractor_registry.get(extractor_type.lower())
    if extractor_class is None:
        raise ValueError("Unknown extractor type: %s" % extractor_type)
    return extractor_class(pdf_path)

