class PhErrorHandlingModes:
    STOP_ON_ERROR = 1
    CONTINUE_ON_ERROR = 2
