"""
Provides play_helpers name, title & package information.
"""
TOOL_NAME = 'playhelpers'
TOOL_TITLE = 'Play Helpers'
TOOL_PACKAGE_NAME = 'play_helpers'
TOOL_TEST_PACKAGE_NAME = 'play_helpers.test'
