class PhModules:
    PLAY_HELPERS = 'playhelpers'
    PYCRATE = 'pycrate'
    PYCRATE_VERSION_SUPPORTING_MULTI_LINE_COMMENTS = '0.5.4'
    SEGNO = 'segno'
