from __future__ import annotations

import os
from dataclasses import dataclass

from simplicity_cli.errors import CliError, ExitCode
from simplicity_cli.models import GlobalOptions

DEFAULT_BASE_URL = "https://api.simplicity.ai"
API_KEY_ENV_VAR = "SIMPLICITY_AI_API_KEY"


@dataclass(frozen=True)
class RuntimeConfig:
    api_key: str
    base_url: str
    request_timeout_seconds: float
    json_output: bool


def resolve_runtime_config(options: GlobalOptions) -> RuntimeConfig:
    if options.request_timeout_seconds <= 0:
        raise CliError(
            "request timeout must be greater than 0 seconds.",
            exit_code=ExitCode.USAGE_ERROR,
            code="invalid_timeout",
        )

    api_key = (options.api_key or os.getenv(API_KEY_ENV_VAR, "")).strip()
    if not api_key:
        raise CliError(
            f"missing API key. Set --api-key or {API_KEY_ENV_VAR}.",
            exit_code=ExitCode.USAGE_ERROR,
            code="missing_api_key",
        )

    return RuntimeConfig(
        api_key=api_key,
        base_url=DEFAULT_BASE_URL,
        request_timeout_seconds=options.request_timeout_seconds,
        json_output=options.json_output,
    )
