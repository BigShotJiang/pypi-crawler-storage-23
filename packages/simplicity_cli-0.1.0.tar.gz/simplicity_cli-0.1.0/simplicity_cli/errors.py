from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any


class ExitCode(IntEnum):
    SUCCESS = 0
    USAGE_ERROR = 2
    AUTH_ERROR = 3
    API_ERROR = 4
    TASK_FAILED = 5
    TIMEOUT = 6
    DOWNLOAD_ERROR = 7


@dataclass
class CliError(Exception):
    message: str
    exit_code: ExitCode = ExitCode.API_ERROR
    code: str = "api_error"
    details: Any = None

    def __str__(self) -> str:
        return self.message
