import { CommunityInvitationsModal } from "@js/communities_components";

const mapping = {
  "InvenioCommunities.CommunityProfileForm.GridRow.DangerZone": () => null,
  "InvenioCommunities.CommunityMembers.InvitationsModal":
    CommunityInvitationsModal,
};

export default mapping;
