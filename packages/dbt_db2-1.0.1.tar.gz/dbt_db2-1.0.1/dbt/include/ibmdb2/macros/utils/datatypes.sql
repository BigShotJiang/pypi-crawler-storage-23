{% macro ibmdb2__type_string() %}
  VARCHAR
{% endmacro %}
