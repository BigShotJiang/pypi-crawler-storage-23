from .cli import main

if __name__ == "main":
    main()
