import os
from pathlib import Path
import sys
import shutil
from importlib.metadata import version, PackageNotFoundError

import argparse

from .logs import configure_logger
from .converter.utils import backup_directory, create_target_directory
from .conf.settings import Settings


def get_version():
    try:
        # distinct_package_name must match the "name" in your pyproject.toml
        return version("zoommap-converter")
    except PackageNotFoundError:
        return "unknown"


def build_parser() -> argparse.ArgumentParser:
    """Parse Zoommap-converter arguments."""
    parser = argparse.ArgumentParser(
        prog="zoommap-converter",
        description="Convert Zoommap configs in an Obsidian vault",
    )
    parser.add_argument("--settings", default=os.getenv("SETTINGS"), type=Path)
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {get_version()}",
        help="Show the version and exit.",
    )
    parser.add_argument(
        "--no-backup",
        help="do not create a backup of original vault before conversion",
        action="store_true",
    )
    parser.add_argument(
        "-v", "--verbose", help="increase output verbosity", action="store_true"
    )
    parser.add_argument(
        "--in-place",
        help="does not create a duplicate vault, converts the vault in-place",
        action="store_true",
    )
    parser.add_argument(
        "--log-level",
        default=os.getenv("LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Logging level",
    )
    parser.add_argument(
        "--merge-by-image",
        help="""
            merges markers into a single JSON file when the same image is used across multiple
            Leaflet codeblocks. Useful if you use markerTags or similar Leaflet functionality.
            NOTE: This completely disregards maps which are distinguished by the `id` field.""",
        action="store_true",
    )
    parser.add_argument(
        "--ignore-marker-tags",
        help="ignore merging by marker tags, instead merge by map id",
        action="store_true",
    )
    return parser


def main():
    # --- Phase 0: Parse arguments
    parser = build_parser()
    args = parser.parse_args()

    settings = Settings(settings_path=args.settings).settings
    no_backup = settings.get("no_backup") or args.no_backup
    in_place = settings.get("in_place") or args.in_place
    verbose = args.verbose
    log_level = "DEBUG" if verbose else args.log_level
    merge_by_image = settings.get("merge_by_image") or args.merge_by_image
    ignore_marker_tags = settings.get("ignore_marker_tags") or args.ignore_marker_tags

    logger = configure_logger(log_level)

    def _exit_program(error_msg: str, exit_code: int = 1, *args):
        logger.critical(error_msg, *args)
        sys.exit(exit_code)

    if all([in_place, no_backup]):
        logger.warning(
            "Dangerous Flags: --in-place and --no-backup are both set. Risk of data loss is present."
        )
        confirmation = (
            input(
                "Do you wish to continue? Your data may not be recoverable if lost! [y/N]: "
            )
            .strip()
            .lower()
        )

        if confirmation != "y":
            logger.info("Operation aborted by user.")
            sys.exit(1)

    logger.debug("Settings: %s", settings)
    VAULT_PATH = Path(settings.get("vault_path", None))
    if not VAULT_PATH:
        _exit_program(
            error_msg="No Vault Path defined in Settings. Please check settings includes: vault_path: /path/to/vault"
        )
    if not VAULT_PATH.exists():
        _exit_program(error_msg=f"Vault path does not exist: {VAULT_PATH}")

    TARGET_PATH = Path(settings.get("target_path", None))
    if not TARGET_PATH and not in_place:
        _exit_program(
            error_msg="No Target Vault Path defined in Settings. Please check settings includes: target_path: /path/to/target"
        )

    if not TARGET_PATH.parent.exists():
        _exit_program(
            error_msg=f"Target parent path does not exist: {TARGET_PATH.parent}"
        )

    if not no_backup:
        backup_path = backup_directory(VAULT_PATH, VAULT_PATH.as_posix() + "_backup")
        logger.info("Backup created at: %s", backup_path)

    # --- Phase 1: Create Target Directory
    try:
        vault_path = (
            VAULT_PATH
            if in_place
            else create_target_directory(source_dir=VAULT_PATH, target_dir=TARGET_PATH)
        )
    except Exception as e:
        logger.critical(
            "Exception occurred when creating Target Directory '%s' - %s",
            TARGET_PATH,
            e,
        )
        sys.exit(1)

    if not vault_path.exists():
        logger.critical("Target directory not found: %s", vault_path)
        sys.exit(1)

    if not os.listdir(vault_path):
        logger.critical("Target directory is empty: %s", vault_path)
        sys.exit(1)

    # --- Phase 2: Load settings from Vault
    from .bootstrap.loader import bootstrap_vault_defaults

    bootstrap_vault_defaults(
        vault_path=vault_path,
        source_path=vault_path
        / ".obsidian"
        / "plugins"
        / "obsidian-leaflet-plugin"
        / "data.json",
        target_path=vault_path / ".obsidian" / "plugins" / "zoom-map" / "data.json",
    )

    # --- Phase 3: Import and Run
    from zoommap_converter.app import run

    FILTERS = settings.get("filters", None)
    LEAFLET_JSON_PATH = (
        Path(".obsidian") / "plugins" / "obsidian-leaflet-plugin" / "data.json"
    )

    logger.debug("Starting conversion process...")
    logger.debug("Source vault: %s", VAULT_PATH)
    logger.debug("Target vault: %s", TARGET_PATH)
    logger.debug("Filters: %s", FILTERS)

    try:
        run(
            vault_path=vault_path,
            filters=FILTERS,
            json_path=LEAFLET_JSON_PATH,
            merge_by_image=merge_by_image,
            ignore_marker_tags=ignore_marker_tags,
        )
    except Exception as e:
        logger.error("Conversion failed: %s", e)
        # Cleanup
        if in_place and not no_backup:
            if backup_path and backup_path.exists():
                logger.warning("Attempting to restore original vault from backup...")
                try:
                    # 1. Clear the corrupted 'in-place' directory
                    shutil.rmtree(vault_path)

                    # 2. Move the backup back to the original location
                    shutil.move(backup_path, vault_path)
                    logger.info("Restore complete. Vault reverted to original state.")
                except Exception as restore_err:
                    logger.critical(
                        "RESTORE FAILED: Manual intervention required! %s", restore_err
                    )
        else:
            # If not in_place, the 'vault_path' is actually TARGET_PATH
            logger.info("Cleaning up failed target directory...")
            if vault_path.exists():
                shutil.rmtree(vault_path)
        sys.exit(1)
