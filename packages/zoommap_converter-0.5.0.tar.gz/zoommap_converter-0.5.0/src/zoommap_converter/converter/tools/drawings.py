import logging

from ...models.zoommap import (
    ZoommapDrawShape,
    ZoommapShapeStyle,
    ZoommapPolyShape,
    ZoommapRectShape,
)
from ...models.leaflet import LeafletMapMarker, LeafletShape
from ..utils import generate_uuid
from .scale import calculate_position

logger = logging.getLogger(__name__)


def convert_drawings(
    leaflet_marker: LeafletMapMarker, layer_id: str, bounds
) -> list[ZoommapDrawShape]:
    """Convert shapes/drawings to be zoommap-compatible."""
    logger.debug("Converting Drawings")

    # Validate size parameter
    if bounds is None:
        logger.error("Bounds parameter cannot be None")
        raise ValueError("Bounds parameter cannot be None")

    if not isinstance(bounds, dict):
        logger.error("Bounds parameter must be a dictionary")
        raise TypeError("Bounds parameter must be a dictionary")

    required_bounds_keys = {"w", "h"}
    if not required_bounds_keys.issubset(bounds.keys()):
        missing_keys = required_bounds_keys - bounds.keys()
        logger.error("Bounds dictionary missing required keys: %s", missing_keys)
        raise KeyError(f"Bounds dictionary missing required keys: {missing_keys}")

    if bounds["w"] <= 0 or bounds["h"] <= 0:
        logger.error("Bounds dimensions must be positive: %s", bounds)
        raise ValueError(f"Bounds dimensions must be positive: {bounds}")

    zoommap_shapes = []
    if leaflet_marker:
        for shape_data in leaflet_marker.shapes:
            shape = LeafletShape(**shape_data)
            shape_type = shape.type.lower().strip()

            # Skip unsupported shape types with warning
            supported_types = {"rectangle", "polygon", "polyline"}
            if shape_type not in supported_types:
                logger.warning(
                    "Unsupported shape type '%s' encountered, skipping shape",
                    shape.type,
                )
                continue

            # Validate vertices
            if not shape.vertices:
                logger.warning(
                    "Shape with ID %s has no vertices, skipping",
                    shape_data.get("id", "unknown"),
                )
                continue

            # Generate ID and create base style
            shape_id = f"draw_{generate_uuid()}"
            style = ZoommapShapeStyle(
                strokeColor=shape.color,
                strokeWidth=2,
                fillColor=shape.color if shape_type != "polyline" else None,
                fillOpacity=0.15 if shape_type != "polyline" else None,
                fillPattern="solid" if shape_type != "polyline" else None,
            )
            # Initialize shape-specific data
            shape_specific_data = {
                "polygon": None,
                "polyline": None,
                "rect": None,
                "circle": None,
            }

            # Process based on shape type
            if shape_type == "rectangle":
                shape_type = "rect"

                # Validate we have enough vertices for a rectangle
                if len(shape.vertices) < 2:
                    logger.warning(
                        "Rectangle shape requires at least 2 vertices, found %d, skipping",
                        len(shape.vertices),
                    )
                    continue

                coords = [
                    calculate_position(x=vertex.lng, y=vertex.lat, bounds=bounds)
                    for vertex in shape.vertices
                ]

                x_coords = sorted({sublist[0] for sublist in coords})
                y_coords = sorted({sublist[1] for sublist in coords})

                # Handle degenerate rectangles (all vertices at same position)
                if len(x_coords) < 2 or len(y_coords) < 2:
                    logger.warning(
                        "Rectangle has degenerate coordinates (zero width/height), skipping"
                    )
                    continue

                shape_specific_data["rect"] = ZoommapRectShape(
                    **{
                        "x0": x_coords[0],
                        "x1": x_coords[1],
                        "y0": y_coords[0],
                        "y1": y_coords[1],
                    }
                )

            elif shape_type == "polygon":
                # Validate we have enough vertices for a polygon
                if len(shape.vertices) < 3:
                    logger.warning(
                        "Polygon shape requires at least 3 vertices, found %d, skipping",
                        len(shape.vertices),
                    )
                    continue

                coords = [
                    calculate_position(x=vertex.lng, y=vertex.lat, bounds=bounds)
                    for vertex in shape.vertices
                ]

                shape_specific_data["polygon"] = [
                    ZoommapPolyShape(x=coord[0], y=coord[1]) for coord in coords
                ]

            elif shape_type == "polyline":
                style.arrowEnd = shape.arrows
                style.distanceLabel = False

                # Validate we have enough vertices for a polyline
                if len(shape.vertices) < 2:
                    logger.warning(
                        "Polyline shape requires at least 2 vertices, found %d, skipping",
                        len(shape.vertices),
                    )
                    continue

                coords = [
                    calculate_position(x=vertex.lng, y=vertex.lat, bounds=bounds)
                    for vertex in shape.vertices
                ]

                polyline_vertices = [
                    ZoommapPolyShape(x=coord[0], y=coord[1]) for coord in coords
                ]

                if shape.reversed:
                    polyline_vertices = polyline_vertices[::-1]

                shape_specific_data["polyline"] = polyline_vertices

            # Add the shape to results
            zoommap_shapes.append(
                ZoommapDrawShape(
                    id=shape_id,
                    layerId=layer_id,
                    kind=shape_type,
                    visible=True,
                    style=style,
                    **shape_specific_data,
                )
            )

    return zoommap_shapes
