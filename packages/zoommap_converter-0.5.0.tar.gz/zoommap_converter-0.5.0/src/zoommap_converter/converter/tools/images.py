import logging
from pathlib import Path
from PIL import Image
import re

from ...models.zoommap import ZoommapMeasurement
from ..utils import clean_image_name

logger = logging.getLogger(__name__)

METER_CONVERSION = {
    "m": 1,
    "meters": 1,
    "kilometers": 1000,
    "km": 1000,
    "mi": 1609.34,
    "miles": 1609.34,
    "ft": 0.3048,
    "feet": 0.3048,
}


def process_leaflet_images(
    image_wikilinks: list, non_note_files: list, vault_path: Path
):
    """Processes the sizes of each image in the leaflet codeblock."""
    images = []
    logger.debug("Leaflet Image Wikilinks: %s", image_wikilinks)
    for image_link in image_wikilinks:
        pattern = r"\[\[(.*?)(?:\|(.*?))?\]\]"
        match = re.search(pattern, image_link)

        if match:
            image_name = match.group(1)
            # If group 2 is None (no pipe found), fallback to using image_name as the label
            image_label = match.group(2) or clean_image_name(image_name)
            images.append(
                {
                    "path": get_image_path(
                        file_list=non_note_files,
                        image_name=image_name,
                        vault_path=vault_path,
                    ),
                    "name": image_label,
                }
            )
            logger.debug("Image Name: %s, Image Label: %s", image_name, image_label)
        else:
            # Handle cases where the string isn't a valid wiki-link
            logger.debug("No match found")
    return images


def get_image_path(
    file_list: list, image_name: str, vault_path: str | Path
) -> Path | str:
    """Fetches the full path for the image from the wikilink."""
    logger.debug("Fetching full path for image: %s", image_name)
    vault_path = Path(vault_path)
    try:
        if "/" in image_name:
            image_path = next(
                path for path in file_list if image_name in path.as_posix()
            )
        else:
            image_path = next(
                path
                for path in file_list
                if image_name in path.as_posix().split("/")[-1]
            )
    except StopIteration:
        logger.error("Image not found: %s", image_name)
        raise FileNotFoundError(f"Image '{image_name}' not found in vault")

    # Convert to relative path
    try:
        relative_path = image_path.relative_to(vault_path)
        return relative_path
    except ValueError:
        # Fallback to absolute path if relative conversion fails
        logger.warning(f"Could not make path relative to vault: {image_path}")
        return image_path


def get_image_measurements(
    images: list, id: str, scale: float, unit: str, vault_path: Path
):
    """Calculates the image measurements."""
    size = None
    measurement_scales = {}
    meters_per_px = None
    try:
        for image in images:
            width, height = get_image_dimensions(image_path=vault_path / image["path"])
            if width is None or height is None:
                logger.error("Invalid image dimensions for %s", image["path"])
                raise ValueError(f"Invalid image dimensions for {image['path']}")

            if not size:
                size = {"w": width, "h": height}
                logger.debug("Image Size: %s", size)

                meters_per_px = convert_scale(scale, unit)
                measurement_scales[image["path"]] = meters_per_px
            else:
                if size["w"] == 0 or size["h"] == 0:
                    logger.error("Invalid base image dimensions: %s", size)
                    raise ValueError("Invalid base image dimensions")
                measurement_scales[image["path"]] = meters_per_px * (size["w"] / width)
    except (ValueError, KeyError, TypeError) as e:
        logger.error("Scale conversion failed for Map ID '%s': %s", id, e)
        raise  # Re-raise to let caller handle the error

    if meters_per_px is None:
        logger.error("Meters per pixel not calculated for Map ID '%s'", id)
        raise ValueError("Failed to calculate meters per pixel")

    return size, ZoommapMeasurement(
        **{
            "scales": measurement_scales,
            "travelDaysEnabled": False,
            "displayUnit": unit,
            "metersPerPixel": meters_per_px,
        }
    )


def get_image_dimensions(image_path: str | Path) -> tuple[int, int]:
    """Quickly reads image metadata to get dimensions."""
    logger.debug("Reading image dimensions for path: %s", image_path)
    try:
        with Image.open(image_path) as img:
            return img.size
    except (FileNotFoundError, ValueError) as e:
        logger.error("Error getting image dimensions: %s", e)
        return None, None


def convert_scale(scale_value: str | float, scale_unit: str) -> float:
    """Converts Leaflet's units/px to Zoommap's meters/px."""
    logger.debug("Converting Scale")
    try:
        # Convert scale_value to float to handle string inputs
        scale_float = float(scale_value)
        return scale_float * METER_CONVERSION[scale_unit]
    except KeyError as e:
        logger.error("Invalid scale unit '%s': %s", scale_unit, e)
        raise ValueError(f"Invalid scale unit: {scale_unit}") from e
    except (ValueError, TypeError) as e:
        logger.error("Invalid scale value type: %s", e)
        raise ValueError(f"Invalid scale value: {scale_value}") from e
