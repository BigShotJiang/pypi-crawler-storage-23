from ..models.zoommap import ZoommapJsonData


def merge_zoommap_jsons(json_list: list[ZoommapJsonData]) -> list[ZoommapJsonData]:
    """Merges multiple Zoommap JSON objects into one, deduplicating layers by name."""
    if not json_list:
        return None

    # Deep copy base to avoid mutating the very first item in the input array
    base = json_list[0].model_copy(deep=True)

    # Sanitize lists: ensure they are lists and completely strip out any `None` elements
    base.markers = [marker for marker in (base.markers or []) if marker]
    base.drawings = [drawing for drawing in (base.drawings or []) if drawing]
    base.layers = [layer for layer in (base.layers or []) if layer]
    base.drawLayers = [layer for layer in (base.drawLayers or []) if layer]

    # Track layers by name to avoid duplicates and map old IDs to new ones
    layer_map = {layer.name: layer.id for layer in base.layers}
    draw_layer_map = {layer.name: layer.id for layer in base.drawLayers}

    # Helper: Pass the mapped layer explicitly so we don't mutate `m` before copying
    def get_marker_key(m, layer_id):
        return (round(m.x, 8), round(m.y, 8), layer_id, m.link, m.iconKey, m.type)

    marker_keys = {get_marker_key(m, m.layer) for m in base.markers}

    # Helper for deterministic drawing keys
    def get_draw_key(d, layer_id):
        # 1. Lists of Pydantic models: Iterate and convert to a hashable tuple of JSON strings
        poly_key = tuple(p.model_dump_json() for p in d.polygon) if d.polygon else None
        line_key = (
            tuple(p.model_dump_json() for p in d.polyline) if d.polyline else None
        )

        # 2. Singular Pydantic models: Directly dump to JSON string
        rect_key = d.rect.model_dump_json() if d.rect else None
        circ_key = d.circle.model_dump_json() if d.circle else None

        return (layer_id, d.kind, poly_key, line_key, rect_key, circ_key)

    draw_keys = {get_draw_key(d, d.layerId) for d in base.drawings}

    for extra in json_list[1:]:
        # 1. Merge Layers
        id_remapping = {}
        for layer in extra.layers or []:
            if not layer:
                continue
            if layer.name in layer_map:
                id_remapping[layer.id] = layer_map[layer.name]
            else:
                new_layer = layer.model_copy(deep=True)
                base.layers.append(new_layer)
                layer_map[new_layer.name] = new_layer.id
                id_remapping[layer.id] = new_layer.id

        # 2. Merge Markers and fix Layer IDs
        for marker in extra.markers or []:
            if not marker:
                continue
            mapped_layer = id_remapping.get(marker.layer, marker.layer)
            m_key = get_marker_key(marker, mapped_layer)

            if m_key not in marker_keys:
                # Deep copy BEFORE mutating to prevent side-effects on the inputs
                new_marker = marker.model_copy(deep=True)
                new_marker.layer = mapped_layer
                base.markers.append(new_marker)
                marker_keys.add(m_key)

        # 3. Merge Drawings Layers
        draw_id_remapping = {}
        for draw_layer in extra.drawLayers or []:
            if not draw_layer:
                continue
            if draw_layer.name in draw_layer_map:
                draw_id_remapping[draw_layer.id] = draw_layer_map[draw_layer.name]
            else:
                new_draw_layer = draw_layer.model_copy(deep=True)
                base.drawLayers.append(new_draw_layer)
                draw_layer_map[new_draw_layer.name] = new_draw_layer.id
                draw_id_remapping[draw_layer.id] = new_draw_layer.id

        # 4. Merge Drawings
        for drawing in extra.drawings or []:
            if not drawing:
                continue
            mapped_draw_layer = draw_id_remapping.get(drawing.layerId, drawing.layerId)
            d_key = get_draw_key(drawing, mapped_draw_layer)

            if d_key not in draw_keys:
                new_drawing = drawing.model_copy(deep=True)
                new_drawing.layerId = mapped_draw_layer
                base.drawings.append(new_drawing)
                draw_keys.add(d_key)

    return base
