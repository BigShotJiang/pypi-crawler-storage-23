import ast
from collections import defaultdict
import logging
import re
from typing import Any

from obsidian_parser import Note
from pydantic import ValidationError

from ..models.models import ParsedBlock, ParsedNote, LeafletYamlBlock
from ..models.leaflet import LeafletJsonData, LeafletMapMarker, LeafletMarker
from .utils import generate_uuid

logger = logging.getLogger(__name__)


def parse_leaflet_notes(notes: list) -> list[ParsedNote]:
    """Parses Leaflet Codeblocks from notes."""
    logger.debug("Parsing Leaflet Notes")
    return [parse_note(note) for note in notes]


def parse_note(note: Note) -> ParsedNote:
    """Scrape note for leaflet code blocks.

    :param note: Description
    :type note: Note
    """
    logger.debug("Parsing Note: %s", note.name)
    pattern = r"(^\s*(?:>+\s*)?```leaflet[\s\S]*?^\s*(?:>+\s*)?```)"

    matches = re.findall(pattern, note.content, re.DOTALL | re.MULTILINE)

    parsed_codeblocks = [parse_leaflet_block(item) for item in matches]

    logger.debug(
        "Number of Parsed Codeblocks for %s: %s", note.name, len(parsed_codeblocks)
    )

    return ParsedNote(note=note, leaflet_blocks=parsed_codeblocks)


def parse_leaflet_block(raw_block: str) -> ParsedBlock:
    """Parse Leaflet Code Block for parameters.

    :param text: Description
    :type text: str
    :return: Description
    :rtype: dict
    """
    lines = raw_block.splitlines()
    try:
        first_content_line = next(line for line in lines if line.strip())
    except StopIteration:
        return ParsedBlock({}, False, 0, raw_block)
    callout_depth = get_callout_depth(first_content_line)
    in_callout = callout_depth > 0
    logger.debug("Callout Depth: %s", callout_depth)
    data = {}
    current_key = None
    collecting_list = False

    # Regex to identify quoted strings OR comments
    # Group 1: Double or Single quoted strings (e.g., "#tag", 'val')
    # Group 2: The comment starting with #
    comment_pattern = r'("[^"]*"|\'[^\']*\')|(#.*)'

    for raw_line in lines:
        line = re.sub(rf"^\s*>{{0,{callout_depth}}}\s?", "", raw_line)
        line = line.strip()

        # skip blanks
        if not line or line.startswith("```"):
            continue

        # remove comments
        def replace_comment(match):
            # If group 2 matches (the comment part), return empty string
            if match.group(2):
                return ""
            # Otherwise, it matched a quoted string (Group 1), so return it as is
            return match.group(1)

        line = re.sub(comment_pattern, replace_comment, line)

        if not line.strip() or line.strip().startswith("```"):
            continue

        if collecting_list and re.match(r"^\s*-\s+", line):
            item = line.lstrip()[2:].strip()
            data[current_key].append(parse_value(item))
            continue

        # skip malformed lines
        # if ":" not in line:
        #     continue

        if ":" in line:
            key, value = map(str.strip, line.split(":", 1))

            # Collect list of items, such as image layers
            if value == "":
                data[key] = []
                current_key = key
                collecting_list = True
                continue

            data[key] = parse_value(value)
            collecting_list = False
            current_key = None
            continue

    logger.debug("Data: %s", data)

    try:
        block_data = LeafletYamlBlock(**data)
        error_msg = None
    except Exception as e:
        logger.error("Validation failed for block: %s", e)
        block_data = None
        error_msg = str(e)

    return ParsedBlock(
        data=block_data,
        in_callout=in_callout,
        callout_depth=callout_depth,
        raw_block=raw_block,
        error=error_msg,
    )


def parse_value(value: str) -> Any:
    """
    Parse values in for a given key.

    :param value: Description
    :type value: str
    """
    # Remove non-standard whitespace characters (like hair spaces) that break ast.literal_eval
    value = re.sub(r"[\u2000-\u200b\u200e\u200f\uFEFF]", "", value).strip()

    # booleans
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False

    # try number
    try:
        if "." in value:
            return float(value)
        return int(value)
    except ValueError:
        pass

    # list / array syntax (e.g. [[0,0], [6600, 10200]])
    try:
        return ast.literal_eval(value)
    except Exception:
        pass

    # fallback: string
    return value


def get_callout_depth(line: str) -> int:
    """
    Count leading Markdown blockquote markers.
    """
    return len(re.findall(r"^\s*(>+)", line)[0]) if re.match(r"^\s*>", line) else 0


def associate_notes_to_maps(
    parsed_notes: list[ParsedNote], all_notes: list[Note], leaflet_json: Any
) -> LeafletJsonData:
    """
    Efficiently maps notes to maps based on tag intersection using an inverted index.

    Args:
        parsed_notes: List of all parsed notes.
        all_notes: List of all notes in the vault.

    Returns:
        Dict: Keys are map IDs, values are lists of matching NoteEntity objects.
    """
    logger.debug("Associated Map Locations with MarkerTag Notes.")
    # 1. Inverted Index Construction: Tag -> Set[Map_ID]
    # Reduces lookup complexity to O(1) per tag
    tag_to_map_ids: dict[str, set[str]] = defaultdict(set)
    map_info: dict[str, str] = {}
    valid_map_ids: set[str] = set()
    new_markers: dict[str, LeafletMarker] = defaultdict(set)

    for parsed_note in parsed_notes:
        for map_data in parsed_note.leaflet_blocks:
            try:
                logger.debug("Indexing %s", parsed_note.note.name)
                logger.debug("Map Data: %s", map_data)
                map_obj = map_data.data
                if not map_obj or not map_obj.markerTag:
                    continue
                logger.debug(
                    "markerTag field found in %s: %s", map_obj.id, map_obj.markerTag
                )
                valid_map_ids.add(map_obj.id)
                map_info[map_obj.id] = map_obj.image[0] if map_obj.image else ""
                for tag in map_obj.markerTag:
                    logger.debug("New Tag added: %s", tag)
                    tag_to_map_ids[tag.replace("#", "")].add(map_obj.id)
            except ValidationError as e:
                logger.error(
                    "Skipping invalid map structure: %s | Error: %s", map_obj, e
                )
                continue
            except Exception as e:
                logger.error(
                    "Error encountered during marker_tag check for map %s: %s",
                    map_obj.id,
                    e,
                )

    # 2. Note Processing & Association
    # Structure: {map_id: [Note, ...]}
    logger.debug("Dictionary 'tag_to_map_ids': %s", tag_to_map_ids)
    searchable_tags = set(tag_to_map_ids.keys())
    logger.debug("Searchable Tags: %s", searchable_tags)
    new_markers: dict[str, list[LeafletMarker]] = defaultdict(list)

    for note_obj in all_notes:
        fm = note_obj.frontmatter
        loc = fm.get("location")
        marker_type = fm.get("mapmarker")
        note_tags = [t.name if hasattr(t, "name") else str(t) for t in note_obj.tags]
        note_name = note_obj.name
        logger.debug("Note Tags: %s", note_tags)

        if not searchable_tags.intersection(note_tags):
            continue
        if not loc or not marker_type:
            continue
        # Identify all unique maps this note belongs to via tag intersection
        # Flatten all map IDs into a unique set for this note
        target_maps = {
            m_id
            for tag in note_tags
            if tag in tag_to_map_ids
            for m_id in tag_to_map_ids[tag]
        }
        # Aggregation
        logger.debug("Aggregating Map Markers")
        for map_id in target_maps:
            logger.debug(
                "Creating new marker: %s",
                {
                    "id": f"ID_{generate_uuid()}",
                    "type": marker_type,
                    "loc": loc,
                    "link": note_name,
                    "layer": map_info.get(map_id, ""),
                },
            )
            new_markers[map_id].append(
                LeafletMarker(
                    id=f"ID_{generate_uuid()}",
                    type=marker_type,
                    loc=loc,
                    link=note_name,
                    layer=map_info.get(map_id, ""),
                )
            )
    # 3. Merging into leaflet_json
    existing_maps = {m.id: m for m in leaflet_json.mapMarkers}

    for map_id, markers in new_markers.items():
        if map_id in existing_maps:
            existing_maps[map_id].markers.extend(markers)
        else:
            leaflet_json.mapMarkers.append(
                LeafletMapMarker(
                    id=map_id,
                    lastAccessed=1766541419839,
                    markers=markers,
                    overlays=[],
                    shapes=[],
                    files=[],
                )
            )

    logger.info("Mapped markers for %d maps", len(new_markers))
    return leaflet_json
