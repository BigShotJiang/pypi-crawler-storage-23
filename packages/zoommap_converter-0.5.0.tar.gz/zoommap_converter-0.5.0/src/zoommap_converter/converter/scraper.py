import logging
import re

from obsidian_parser import Vault, Note

logger = logging.getLogger(__name__)


def scrape_vault(vault: Vault, filters: dict) -> list[Note]:
    """Scrape Obsidian Vault for notes containing leaflet blocks.

    :param vault: Vault Object
    """
    logger.debug("Scraping Vault for leaflet codeblocks.")
    logger.debug("Pre-filter note count: %s", len(vault.notes))
    if filters:
        valid_notes = remove_excluded_notes(vault.notes, filters=filters)
    else:
        valid_notes = vault.notes
    logger.debug("Valid Notes: %s", [note.name for note in valid_notes])
    return scrape_for_leafblocks(valid_notes)


def remove_excluded_notes(vault: Vault, filters: dict[str, list[str]]) -> list[Note]:
    """Removes notes which contain paths matching the exclusion filter.

    :param vault: Vault
    """
    folder_filters = filters.get("folders", ())
    pattern_filters = filters.get("notes_patterns", ())
    specific_filters = filters.get("specific_notes", ())

    def _is_allowed(note):
        path = note.path.as_posix()
        parent = note.path.parent.as_posix()

        return not (
            any(f in parent for f in folder_filters)
            or any(f in path for f in pattern_filters)
            or any(f in path for f in specific_filters)
        )

    return [note for note in vault if _is_allowed(note)]


def scrape_for_leafblocks(notes: list) -> list[Note]:
    """Scrapes notes to find notes which contain leaflet codeblocks.

    :param notes: Description
    :type notes: Vault
    """
    return [note for note in notes if check_leafblock_exists(note)]


def check_leafblock_exists(note: Note) -> bool:
    """Checks note for a leaflet codeblock."""
    PATTERN = r"```leaflet\s*[\s\S]*?```"

    return True if re.findall(PATTERN, note.content) else False
