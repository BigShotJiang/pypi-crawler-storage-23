import logging
import os

from obsidian_parser import Note
from pathlib import Path

from ..models.models import (
    ParsedBlock,
    ZoommapBlock,
    ParsedNote,
    ZoommapConversion,
    ZoommapView,
)
from ..models.leaflet import (
    LeafletJsonData,
    LeafletMarkerIcon,
)
from ..models.zoommap import (
    ZoommapJsonData,
    ZoommapMarker,
    ZoommapImage,
    ZoommapMeasurement,
    ZoommapDrawShape,
    ZoommapLayer,
)
from .tools import (
    process_leaflet_images,
    get_image_measurements,
    determine_bounds,
    convert_markers,
    convert_drawings,
    create_layer,
    calculate_zoom_level,
    calculate_position,
)
from ..conf.settings import Settings

settings = Settings(settings_path=os.getenv("SETTINGS")).settings

logger = logging.getLogger(__name__)


def convert_note(
    leaflet_note: ParsedNote,
    leaflet_data: LeafletJsonData,
    non_note_files: list,
    vault_path: Path,
) -> list[ZoommapConversion]:
    """Convert Leaflet blocks in Obsidian Note to Zoommap."""
    logger.debug("Executing Conversion Process for Leaflet to Zoommap...")
    # leaflet_data = LeafletJsonData(**leaflet_data)
    leaflet_marker_icons = leaflet_data.markerIcons
    leaflet_marker_icons.append(leaflet_data.defaultMarker)
    conversions = []
    for leaflet_block in leaflet_note.leaflet_blocks:
        try:
            conversion = convert_leaflet_to_zoommap(
                leaflet_block=leaflet_block,
                leaflet_data=leaflet_data,
                leaflet_marker_icons=leaflet_marker_icons,
                non_note_files=non_note_files,
                note=leaflet_note.note,
                vault_path=vault_path,
            )
            if conversion:
                conversions.append(conversion)
        except Exception as e:
            logger.error("Failed to convert block in %s: %s", leaflet_note.note.name, e)

    return conversions


def convert_leaflet_to_zoommap(
    leaflet_block: ParsedBlock,
    leaflet_data: LeafletJsonData,
    leaflet_marker_icons: list[LeafletMarkerIcon],
    non_note_files: list,
    note: Note,
    vault_path: Path,
) -> ZoommapConversion:
    """Processes Leaflet codeblock and converts it to an equivalent Zoommap block."""
    logger.debug("Converting Leaflet to Zoommap for Note: %s", note.name)

    # Handle Images
    logger.debug("Converting Leaflet Block: %s", leaflet_block)
    images = process_leaflet_images(
        image_wikilinks=leaflet_block.data.image,
        non_note_files=non_note_files,
        vault_path=vault_path,
    )

    # Image Size for base Layer
    logger.debug("Calculating measurements")
    size, measurement = get_image_measurements(
        images,
        id=leaflet_block.data.id,
        scale=leaflet_block.data.scale,
        unit=leaflet_block.data.unit,
        vault_path=vault_path,
    )
    logger.debug("Measurement calcuated: %s", measurement)

    # Handle Markers and Marker Layers
    leaflet_markers = next(
        (
            markers
            for markers in leaflet_data.mapMarkers
            if markers.id == leaflet_block.data.id
        ),
        None,
    )
    if not leaflet_markers:
        logger.info(
            "No markers found in %s for map id: %s", note.name, leaflet_block.data.id
        )
        # Initialize empty lists for markers and drawings
        zoommap_drawings = []
    else:
        logger.debug("Leaflet Markers: %s", leaflet_markers)
        logger.debug("Size of Image (%s): %s", leaflet_markers.id, size)

    # Determine the bounds of the map
    bounds = {}
    has_custom_bounds = False
    bounds_list = []
    if leaflet_block.data.bounds:
        bounds_list = leaflet_block.data.bounds
        has_custom_bounds = True
    logger.debug("Leaflet Max Zoom: %s", leaflet_block.data.maxZoom)
    max_zoom = (
        leaflet_block.data.maxZoom if leaflet_block.data.maxZoom is not None else None
    )
    logger.debug("Bounds: %s", bounds_list)
    logger.debug("Has Custom Bounds: %s", has_custom_bounds)
    logger.debug("Max Zoom: %s", max_zoom)
    bounds = determine_bounds(bounds_list, image_size=size, max_zoom=max_zoom)

    zoommap_markers, zoommap_layers = convert_markers(
        leaflet_markers=leaflet_markers,
        marker_icons=leaflet_marker_icons,
        bounds=bounds,
    )

    # Calculate center from latitude and longitude
    logger.debug("Calculating Center from Lat & Long")
    center_x, center_y = None, None
    logger.debug("Lat: %s | Long: %s", leaflet_block.data.lat, leaflet_block.data.long)
    logger.debug(
        "lat value: %r (type: %s)", leaflet_block.data.lat, type(leaflet_block.data.lat)
    )
    logger.debug(
        "long value: %r (type: %s)",
        leaflet_block.data.long,
        type(leaflet_block.data.long),
    )
    logger.debug("lat truthy: %s", bool(leaflet_block.data.lat))
    logger.debug("long truthy: %s", bool(leaflet_block.data.long))
    if leaflet_block.data.lat is not None and leaflet_block.data.long is not None:
        logger.debug("Lat & Long populated")
        center_x, center_y = calculate_position(
            y=leaflet_block.data.lat, x=leaflet_block.data.long, bounds=bounds
        )
        logger.debug("Center Values | X: %s | Y: %s", center_x, center_y)

    # Handle Zoom Levels
    logger.debug("Calculating Zoom Levels")
    min_zoom = (
        leaflet_block.data.minZoom if leaflet_block.data.minZoom is not None else None
    )
    zoom_constants = {
        "max_zoom": max_zoom,
        "min_zoom": min_zoom,
        "has_custom_bounds": has_custom_bounds,
    }

    default_zoom = (
        calculate_zoom_level(
            zoom_level=leaflet_block.data.defaultZoom, **zoom_constants
        )
        if leaflet_block.data.defaultZoom is not None
        else None
    )
    min_zoom = (
        calculate_zoom_level(zoom_level=min_zoom, **zoom_constants)
        if min_zoom is not None
        else None
    )
    max_zoom = (
        calculate_zoom_level(zoom_level=max_zoom, **zoom_constants)
        if max_zoom is not None
        else None
    )
    logger.debug(
        "Zoom Levels: | Max Zoom: %s | Min Zoom: %s | Default Zoom: %s",
        max_zoom,
        min_zoom,
        default_zoom,
    )
    view = None
    if default_zoom is not None and center_x is not None and center_y is not None:
        logger.debug("Zoommap View can be created")
        view = ZoommapView(zoom=default_zoom, centerX=center_x, centerY=center_y)
        logger.debug("Zoommap View (Center): %s", view)

    # Handle Drawings
    if hasattr(leaflet_markers, "shapes") and leaflet_markers.shapes:
        logger.debug("Note '%s' has shapes: %s", note, leaflet_markers.shapes)
        drawing_layer = create_layer(layer_type="draw", name="Region Layer")
        zoommap_drawings = convert_drawings(
            leaflet_markers, layer_id=drawing_layer.id, size=size
        )
    else:
        drawing_layer = None
        zoommap_drawings = []
        logger.debug("No shapes found for map id: %s", leaflet_block.data.id)

    # Now create the Zoommap Codeblock object
    zoommap_block = process_leafblock(
        leaflet_block=leaflet_block,
        images=images,
        layers=[layer.name for layer in zoommap_layers],
        max_zoom=max_zoom,
        min_zoom=min_zoom,
        view=view,
    )

    logger.debug("Zoommap Block: %s", zoommap_block)

    # Create the Zoommap JSON object
    zoommap_json = build_zoommap_json(
        zoommap_block=zoommap_block,
        markers=zoommap_markers,
        measurement=measurement,
        layers=zoommap_layers,
        drawing_layers=[drawing_layer],
        drawings=zoommap_drawings,
        size=size,
    )

    # Create the file paths for the JSON
    base_image_path = zoommap_block.imageBases[0]["path"]
    json_path = base_image_path.with_name(
        f"{base_image_path.name}_{zoommap_block.id}.markers.json"
    )

    zoommap_block.markers = json_path

    return ZoommapConversion(
        **{
            "note": note,
            "leaflet_block": leaflet_block,
            "zoommap_block": zoommap_block,
            "zoommap_json": zoommap_json,
            "marker_json_path": vault_path / json_path,
            "marker_tag": leaflet_block.data.markerTag,
        }
    )


def build_zoommap_json(
    zoommap_block: ZoommapBlock,
    markers: list[ZoommapMarker],
    measurement: ZoommapMeasurement,
    layers: list[ZoommapLayer],
    drawing_layers: list[ZoommapLayer],
    drawings: list[ZoommapDrawShape],
    size: dict,
) -> ZoommapJsonData:
    """Builds the Zoommap JSON for the corresponding block."""
    logger.debug(
        "Building Zoommap JSON file for image: %s", zoommap_block.imageBases[0]
    )

    logger.debug("Zoommap Image Bases: %s", zoommap_block.imageBases)

    bases = [
        ZoommapImage(
            path=str(base["path"]) if isinstance(base["path"], Path) else base["path"],
            name=base["name"],
        )
        for base in zoommap_block.imageBases
    ]

    if not all(draw_layer is None for draw_layer in drawing_layers):
        logger.debug("Drawing Layers populated: %s", drawing_layers)
    else:
        logger.warning(
            "No drawing layers found for %s: %s", zoommap_block.id, drawing_layers
        )
        drawing_layers = []

    return ZoommapJsonData(
        size=size,
        layers=layers,
        markers=markers,
        bases=bases,
        overlays=[],  # TODO
        activeBase=bases[0].path,
        measurement=measurement,
        pinSizeOverrides={},
        panClamp=False,
        drawLayers=drawing_layers,
        drawings=drawings,
        textLayers=None,
    )


def process_leafblock(
    leaflet_block: ParsedBlock,
    layers: list,
    images: list,
    max_zoom: float | None = None,
    min_zoom: float | None = None,
    view: ZoommapView | None = None,
) -> ZoommapBlock:
    """Extracts incompatible elements from Leaflet codeblock to be Zoommap-compatible."""
    logger.debug(
        "Converting Leaflet to Zoommap Codeblock for block ID: %s",
        leaflet_block.data.id,
    )
    # Create a dictionary excluding the fields we don't want
    # Use model_dump() to get dictionary representation of the Pydantic model
    block_data = {
        k: v
        for k, v in leaflet_block.data.model_dump().items()
        if k not in ["image", "minZoom", "maxZoom"] and v is not None
    }
    if max_zoom is not None:
        block_data["maxZoom"] = max_zoom
    if min_zoom is not None:
        block_data["minZoom"] = min_zoom
    logger.debug("Block Data: %s", block_data)
    logger.debug("Block Data Type: %s", type(block_data))
    image = images[0]

    return ZoommapBlock(
        imageBases=images,
        markerLayers=layers,
        imageOverlays=None,
        image=image["path"].as_posix(),
        view=view,
        **block_data,
    )
