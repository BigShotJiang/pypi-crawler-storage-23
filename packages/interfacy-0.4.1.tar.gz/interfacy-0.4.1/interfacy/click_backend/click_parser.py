from __future__ import annotations

from interfacy.click_backend.core import ClickParser

__all__ = ["ClickParser"]
