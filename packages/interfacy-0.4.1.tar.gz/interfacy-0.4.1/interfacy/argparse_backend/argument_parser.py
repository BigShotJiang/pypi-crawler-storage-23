import argparse
import re
import sys
from argparse import Namespace
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any, Literal, cast

from objinspect.typing import type_name
from typing_extensions import Never

from interfacy.appearance.renderer import SchemaHelpRenderer
from interfacy.argparse_backend.help_formatter import InterfacyHelpFormatter
from interfacy.logger import get_logger

if TYPE_CHECKING:
    from interfacy.appearance.layout import HelpLayout
    from interfacy.schema.schema import Command, ParserSchema

logger = get_logger(__name__)


DEST_KEY = "dest"
ActionType = Callable[[str], Any] | type[Any] | str | None
NargsPattern = Literal["?", "*", "+"]
_SUBPARSERS_ACTION_ATTR = "_SubParsersAction"
_CONTAINER_DEFAULTS_ATTR = "_defaults"
_CONTAINER_ACTIONS_ATTR = "_actions"
_ARGPARSE_SUBPARSERS_ACTION = cast(
    type[argparse.Action], getattr(argparse, _SUBPARSERS_ACTION_ATTR)
)


def _uses_template_layout(layout: "HelpLayout | None") -> bool:
    if layout is None:
        return False
    use_template_layout = getattr(layout, "_use_template_layout", None)
    if not callable(use_template_layout):
        return False
    return bool(use_template_layout())


def namespace_to_dict(namespace: Namespace) -> dict[str, Any]:
    """
    Convert an argparse Namespace into a nested dictionary.

    Args:
        namespace (Namespace): Parsed namespace to convert.
    """
    result = {}
    for k, v in vars(namespace).items():
        if isinstance(v, Namespace):
            result[k] = namespace_to_dict(v)
        else:
            result[k] = v
    return result


class NestedSubParsersAction(_ARGPARSE_SUBPARSERS_ACTION):  # type: ignore[type-arg,misc]
    """
    Subparser action that supports nested destination paths.

    Args:
        option_strings (list[str]): Option strings that trigger the action.
        prog (str): Program name for help output.
        base_nest_path (list[str]): Base nesting path components.
        nest_separator (str): Separator for nested destination keys.
        parser_class (type[ArgumentParser] | None): Parser class for children.
        dest (str): Destination key for the subparser.
        required (bool): Whether a subcommand is required.
        help (str | None): Help text for the action.
        metavar (str | None): Metavar for help output.
        formatter_class (type[argparse.HelpFormatter] | None): Formatter class for children.
        help_layout (Any | None): Layout configuration passed to children.
    """

    def __init__(
        self,
        option_strings: list[str],
        prog: str,
        base_nest_path: list[str],
        nest_separator: str,
        parser_class: type["ArgumentParser"] | None = None,
        dest: str = argparse.SUPPRESS,
        required: bool = False,
        help: str | None = None,  # noqa: A002 - argparse API compatibility
        metavar: str | None = None,
        formatter_class: type[argparse.HelpFormatter] | None = None,
        help_layout: "HelpLayout | None" = None,
    ) -> None:
        super().__init__(
            option_strings,
            prog,
            parser_class or ArgumentParser,
            dest=dest,
            required=required,
            help=help,
            metavar=metavar,
        )
        self.base_nest_path_components = base_nest_path
        self.nest_separator = nest_separator
        self._child_formatter_class = formatter_class or InterfacyHelpFormatter
        self._child_help_layout = help_layout

    def add_parser(  # type: ignore[override]
        self,
        name: str,
        *,
        help: str | None = None,  # noqa: A002 - argparse API compatibility
        aliases: Sequence[str] = (),
        prog: str | None = None,
        usage: str | None = None,
        description: str | None = None,
        epilog: str | None = None,
        parents: Sequence[argparse.ArgumentParser] = (),
        formatter_class: type[argparse.HelpFormatter] | None = None,
        prefix_chars: str = "-",
        fromfile_prefix_chars: str | None = None,
        argument_default: object = None,
        conflict_handler: str = "error",
        add_help: bool = True,
        allow_abbrev: bool = True,
        exit_on_error: bool = True,
        nest_dir: str | None = None,
        **kwargs: object,
    ) -> "ArgumentParser":
        """
        Creates and returns a new parser for a subcommand with nesting support.

        Args:
            name (str): Name of the subcommand.
            help (str | None, optional): Help message for the subcommand. Defaults to None.
            aliases (Sequence[str], optional): Alternative names for the subcommand. Defaults to ().
            prog (str | None, optional): Program name. Defaults to None.
            usage (str | None, optional): Usage message. Defaults to None.
            description (str | None, optional): Description of the subcommand. Defaults to None.
            epilog (str | None, optional): Text following the argument descriptions. Defaults to None.
            parents (Sequence[ArgumentParser], optional): Parent parsers. Defaults to ().
            formatter_class (Type[HelpFormatter], optional): Help message formatter. Defaults to HelpFormatter.
            prefix_chars (str, optional): Characters that prefix optional arguments. Defaults to "-".
            fromfile_prefix_chars (str | None, optional): Characters prefixing files with arguments. Defaults to None.
            argument_default (Any, optional): Default value for all arguments. Defaults to None.
            conflict_handler (str, optional): How to handle conflicts. Defaults to "error".
            add_help (bool, optional): Add a --help option. Defaults to True.
            allow_abbrev (bool, optional): Allow abbreviated long options. Defaults to True.
            exit_on_error (bool, optional): Exit with error info on error. Defaults to True.
            nest_dir (str | None, optional): Custom nesting directory name. Defaults to name if not provided.
            **kwargs: Additional arguments passed to parent class.

        Returns:
            NestedArgumentParser: A new parser for the subcommand.
        """
        kwargs.setdefault("help_layout", self._child_help_layout)

        return cast(
            ArgumentParser,
            super().add_parser(
                name,
                help=help,
                aliases=aliases,
                prog=prog,
                usage=usage,
                description=description,
                epilog=epilog,
                parents=parents,
                formatter_class=formatter_class or self._child_formatter_class,
                prefix_chars=prefix_chars,
                fromfile_prefix_chars=fromfile_prefix_chars,
                argument_default=argument_default,
                conflict_handler=conflict_handler,
                add_help=add_help,
                allow_abbrev=allow_abbrev,
                nest_path=[*self.base_nest_path_components, nest_dir or name],
                nest_separator=self.nest_separator,
                exit_on_error=exit_on_error,
                **kwargs,
            ),
        )


class ArgumentParser(argparse.ArgumentParser):
    """
    ArgumentParser with nested destinations and custom help formatting.

    Args:
        prog (str | None): Program name used in help output.
        usage (str | None): Custom usage string.
        description (str | None): Description text shown in help.
        epilog (str | None): Epilog text shown after help.
        parents (list[argparse.ArgumentParser] | None): Parent parsers to inherit args.
        formatter_class (type[argparse.HelpFormatter]): Help formatter class.
        prefix_chars (str): Prefix characters for options.
        fromfile_prefix_chars (str | None): Prefix for args-from-file.
        argument_default (Any): Default value for all arguments.
        conflict_handler (str): Conflict resolution strategy.
        add_help (bool): Whether to add a help option.
        allow_abbrev (bool): Whether to allow abbreviations of long options.
        nest_dir (str | None): Base nesting directory label.
        nest_separator (str): Separator for nested destinations.
        nest_path (list[str] | None): Explicit nesting path components.
        exit_on_error (bool): Whether to exit on parse errors.
        help_layout (Any | None): Layout configuration for help rendering.
        color (bool | None): Force colorized help output when supported.
    """

    def __init__(
        self,
        prog: str | None = None,
        usage: str | None = None,
        description: str | None = None,
        epilog: str | None = None,
        parents: list[argparse.ArgumentParser] | None = None,
        formatter_class: type[argparse.HelpFormatter] = InterfacyHelpFormatter,
        prefix_chars: str = "-",
        fromfile_prefix_chars: str | None = None,
        argument_default: object = None,
        conflict_handler: str = "error",
        add_help: bool = True,
        allow_abbrev: bool = True,
        nest_dir: str | None = None,
        nest_separator: str = "__",
        nest_path: list[str] | None = None,
        exit_on_error: bool = True,
        *,
        help_layout: "HelpLayout | None" = None,
        color: bool | None = None,
    ) -> None:
        if parents is None:
            parents = []
        self.nest_path_components = nest_path or ([nest_dir] if nest_dir else [])
        self.nest_dir = self.nest_path_components[-1] if self.nest_path_components else None
        self.nest_separator = nest_separator
        self._original_destinations: dict[str, str] = {}  # nested_dest: original_dest

        base_init_kwargs: dict[str, Any] = {
            "prog": prog,
            "usage": usage,
            "description": description,
            "epilog": epilog,
            "parents": parents,
            "formatter_class": formatter_class,
            "prefix_chars": prefix_chars,
            "fromfile_prefix_chars": fromfile_prefix_chars,
            "argument_default": argument_default,
            "conflict_handler": conflict_handler,
            "add_help": False,
            "exit_on_error": exit_on_error,
            "allow_abbrev": allow_abbrev,
        }

        if color is None and sys.version_info >= (3, 14):
            color = False
        if color is not None:
            base_init_kwargs["color"] = color

        try:
            super().__init__(**base_init_kwargs)
        except TypeError as exc:
            if "color" not in base_init_kwargs or "color" not in str(exc):
                raise
            base_init_kwargs.pop("color")
            super().__init__(**base_init_kwargs)
        self._interfacy_help_layout = help_layout
        self._schema_command: Command | None = None
        self._schema: ParserSchema | None = None
        self.add_help = add_help
        if add_help:
            if "-" in self.prefix_chars:
                help_flags = ["--help"]
            else:
                default_prefix = self.prefix_chars[0]
                help_flags = [default_prefix * 2 + "help"]

            self.add_argument(
                *help_flags,
                action="help",
                default=argparse.SUPPRESS,
                help=argparse._("Show this help message and exit"),
            )
        self.register("action", "parsers", NestedSubParsersAction)

    def _get_formatter(self) -> argparse.HelpFormatter:  # type: ignore[override]
        formatter = self.formatter_class(str(self.prog))
        set_help_layout = getattr(formatter, "set_help_layout", None)
        if callable(set_help_layout):
            try:
                set_help_layout(self._interfacy_help_layout)
            except TypeError:
                logger.debug("Formatter rejected help layout", exc_info=True)
        return formatter

    def format_help(self) -> str:
        layout = self._interfacy_help_layout
        if layout is None:
            return super().format_help()
        if not _uses_template_layout(layout):
            return super().format_help()

        renderer = SchemaHelpRenderer(layout)

        if self._schema is not None:
            return renderer.render_parser_help(self._schema, self.prog)

        if self._schema_command is not None:
            return renderer.render_command_help(self._schema_command, self.prog)

        return super().format_help()

    def set_schema_command(self, command: "Command | None") -> None:
        self._schema_command = command

    def set_schema(self, schema: "ParserSchema | None") -> None:
        self._schema = schema

    def add_subparsers(self, **kwargs: object) -> NestedSubParsersAction:
        """
        Create a nested subparser group with remapped destinations.

        Args:
            **kwargs (Any): Arguments forwarded to argparse add_subparsers.
        """
        logger.info("Adding subparsers with kwargs=%s", kwargs)
        if DEST_KEY in kwargs:
            dest = kwargs[DEST_KEY]
            nested_dest = self._get_nested_destination(dest.replace("-", "_"), store=True)
            kwargs[DEST_KEY] = nested_dest

        kwargs.update(
            {
                "base_nest_path": self.nest_path_components,
                "nest_separator": self.nest_separator,
                "formatter_class": self.formatter_class,
                "help_layout": self._interfacy_help_layout,
            }
        )
        return cast(NestedSubParsersAction, super().add_subparsers(**kwargs))

    def parse_known_args(  # type: ignore[override]
        self,
        args: Sequence[str] | None = None,
        namespace: Namespace | None = None,
    ) -> tuple[Namespace, list[str]]:
        """
        Parse known args and deflatten nested destinations.

        Args:
            args (Sequence[str] | None): Argument list to parse. Defaults to sys.argv.
            namespace (Namespace | None): Optional namespace to populate.
        """
        parsed_args, unknown_args = super().parse_known_args(args=args, namespace=namespace)
        logger.info("Initial parse result: %s, unknown=%s", vars(parsed_args), unknown_args)
        if parsed_args is None:
            raise ValueError("No parsed arguments found.")

        deflattened_args = self._deflatten_namespace(parsed_args)
        logger.info("Deflattened result:   %s", vars(deflattened_args))
        return deflattened_args, unknown_args

    def set_defaults(self, **kwargs: object) -> None:
        """
        Set defaults while respecting nested destinations.

        Args:
            **kwargs (Any): Default values keyed by original destination names.
        """
        nested_kwargs = {
            self._get_nested_destination(dest, store=True): value for dest, value in kwargs.items()
        }
        logger.info("Nested defaults: %s", nested_kwargs)
        super().set_defaults(**nested_kwargs)

    def get_default(self, dest: str) -> object:
        """
        Return the default value for a destination name.

        Args:
            dest (str): Original destination name.
        """
        nested_dest = self._get_nested_destination(dest)
        value = super().get_default(nested_dest)
        return value

    def _add_container_actions(self, container: argparse._ActionsContainer) -> None:
        self._remap_container_destinations(container)
        return super()._add_container_actions(container)

    def _get_positional_kwargs(self, dest: str, **kwargs: object) -> dict[str, Any]:
        logger.debug("Getting positional kwargs for dest='%s'", dest)
        nested_dest = self._get_nested_destination(dest.replace("-", "_"), store=True)
        kwargs = self._edit_arguments(dest, **kwargs)
        return super()._get_positional_kwargs(nested_dest, **kwargs)

    def _get_optional_kwargs(self, *args: str, **kwargs: object) -> dict[str, Any]:
        logger.debug("Getting optional kwargs for args=%s", args)
        dest = self._extract_destination(*args, **kwargs)
        nested_dest = self._get_nested_destination(dest.replace("-", "_"), store=True)
        kwargs[DEST_KEY] = nested_dest
        kwargs = self._edit_arguments(dest, **kwargs)
        return super()._get_optional_kwargs(*args, **kwargs)

    def _deflatten_namespace(self, namespace: Namespace) -> Namespace:
        root = Namespace()

        for key, value in vars(namespace).items():
            components = key.split(self.nest_separator)
            current = root

            # Navigate through component hierarchy
            for component in components[:-1]:
                if not hasattr(current, component):
                    logger.debug("Creating new namespace for '%s'", component)
                    setattr(current, component, Namespace())
                current = getattr(current, component)

            # Set or merge final value
            final_component = components[-1]
            if hasattr(current, final_component):
                logger.debug("Merging nested namespaces at %s", final_component)
                existing_value = getattr(current, final_component)
                if isinstance(existing_value, Namespace) and isinstance(value, Namespace):
                    self._recursively_merge_namespaces(existing_value, value)
                else:
                    raise ValueError(f'Cannot merge namespaces due to conflict at key "{key}"')
            else:
                setattr(current, final_component, value)

        return root

    def _recursively_merge_namespaces(self, destination: Namespace, source: Namespace) -> Namespace:
        for name, value in vars(source).items():
            if hasattr(destination, name):
                dest_value = getattr(destination, name)
                if isinstance(dest_value, Namespace) and isinstance(value, Namespace):
                    logger.info("Recursively merging at attribute: %s", name)
                    self._recursively_merge_namespaces(dest_value, value)
                else:
                    raise ValueError(
                        f'Cannot merge namespaces due to conflict at attribute "{name}".'
                    )
            else:
                logger.info("Setting new attribute: %s=%s", name, value)
                setattr(destination, name, value)
        return destination

    @staticmethod
    def _container_defaults(container: argparse._ActionsContainer) -> dict[str, object]:
        defaults = getattr(container, _CONTAINER_DEFAULTS_ATTR, None)
        if isinstance(defaults, dict):
            return defaults
        return {}

    @staticmethod
    def _set_container_defaults(
        container: argparse._ActionsContainer, defaults: dict[str, object]
    ) -> None:
        setattr(container, _CONTAINER_DEFAULTS_ATTR, defaults)

    @staticmethod
    def _iter_container_actions(container: argparse._ActionsContainer) -> list[argparse.Action]:
        actions = getattr(container, _CONTAINER_ACTIONS_ATTR, ())
        if not isinstance(actions, list):
            actions = list(actions)
        return [action for action in actions if isinstance(action, argparse.Action)]

    def _remap_container_destinations(self, container: argparse._ActionsContainer) -> None:
        defaults = self._container_defaults(container)
        logger.info("Remapping container destinations: %s", defaults)
        remapped_defaults = {
            self._get_nested_destination(dest): value for dest, value in defaults.items()
        }
        self._set_container_defaults(container, remapped_defaults)
        logger.info("Remapped container destinations: %s", remapped_defaults)

        for action in self._iter_container_actions(container):
            self._remap_action_destinations(action)

    def _remap_action_destinations(self, action: argparse.Action) -> None:
        logger.info("Remapping action: %s", action)

        if action.dest is not None:
            old_dest = action.dest
            action.dest = self._get_nested_destination(action.dest, store=True)
            logger.info("Remapped action dest from %s to %s", old_dest, action.dest)

        if isinstance(action, NestedSubParsersAction) and action.choices is not None:
            for subparser in action.choices.values():
                if isinstance(subparser, ArgumentParser):
                    self._remap_container_destinations(subparser)

    def _extract_destination(self, *args: str, **kwargs: object) -> str:
        if DEST_KEY in kwargs and kwargs[DEST_KEY] is not None:
            return str(kwargs[DEST_KEY])
        # Find first long option string, falling back to first short option
        option_strings = ((s, len(s) > 2) for s in args if s[0] in self.prefix_chars)
        for option_string, is_long in option_strings:
            if is_long and option_string[1] in self.prefix_chars:
                logger.debug("Using long option string for dest: %s", option_string)
                return option_string.lstrip(self.prefix_chars)
        # If no long option found, use first short option
        dest = next(s.lstrip(self.prefix_chars) for s in args if s[0] in self.prefix_chars)
        logger.debug("Using short option string for dest: %s", dest)
        return dest

    def _get_nested_destination(self, dest: str, *, store: bool = False) -> str:
        if not self.nest_path_components:
            return dest
        nested = f"{self.nest_separator.join(self.nest_path_components)}{self.nest_separator}{dest}"
        logger.info("Generated nested dest: %s -> %s", nested, dest)
        if store:
            self._original_destinations[nested] = dest
        return nested

    def _edit_arguments(self, original_dest: str, **kwargs: object) -> dict[str, Any]:
        action = kwargs.get("action", "store")
        action_name = action if isinstance(action, str) else getattr(action, "__name__", "")
        no_metavar_actions = {
            "store_true",
            "store_false",
            "store_const",
            "append_const",
            "count",
            "help",
            "version",
            "BooleanOptionalAction",
        }

        if action_name not in no_metavar_actions and "metavar" not in kwargs:
            dest_for_metavar = original_dest
            if self.nest_separator in dest_for_metavar:
                dest_for_metavar = dest_for_metavar.split(self.nest_separator)[-1]
            kwargs["metavar"] = dest_for_metavar.replace("_", "-").upper()
        return kwargs

    def _get_value(self, action: argparse.Action, arg_string: str) -> object:
        parse_func = self._registry_get("type", action.type, action.type)
        if not callable(parse_func):
            raise argparse.ArgumentError(action, f"{parse_func!r} is not callable")
        try:
            result = parse_func(arg_string)

        except argparse.ArgumentTypeError as exc:
            getattr(action.type, "__name__", repr(action.type))
            msg = str(sys.exc_info()[1])
            raise argparse.ArgumentError(action, msg) from exc

        except (TypeError, ValueError) as exc:
            t = None
            keywords = getattr(parse_func, "keywords", None)
            if isinstance(keywords, dict):
                t = keywords.get("t")
            if t is None:
                t = action.type if action.type is not None else "value"
            t_name = type_name(str(t))
            raise argparse.ArgumentError(action, f"invalid {t_name} value: '{arg_string}'") from exc
        return result

    def error(self, message: str) -> Never:
        """
        Override argparse's default error output for missing required subcommands.

        By default, argparse prints only a short usage line on errors. For CLIs built
        around subcommands, a missing subcommand is much more useful when the full help is displayed.
        """
        marker = "the following arguments are required:"
        if marker in message:
            subparser_actions = [
                action
                for action in self._actions
                if isinstance(action, _ARGPARSE_SUBPARSERS_ACTION)
            ]
            subparser_dests: set[str] = {action.dest for action in subparser_actions}
            subparser_choices: set[str] = set()
            for action in subparser_actions:
                subparser_choices.update(action.choices.keys())

            if subparser_dests:
                missing_part = message.split(marker, 1)[1].strip()
                missing_names = [name.strip() for name in missing_part.split(",") if name.strip()]
                denested_missing = [
                    self._original_destinations.get(name, name) for name in missing_names
                ]
                denested_subparser_dests = {
                    self._original_destinations.get(dest, dest) for dest in subparser_dests
                }
                brace_choices: set[str] = set()
                for grouped in re.findall(r"\{([^}]*)\}", missing_part):
                    brace_choices.update(choice.strip() for choice in grouped.split(",") if choice)

                is_missing_subcommand = any(
                    name in denested_subparser_dests for name in denested_missing
                ) or bool(brace_choices & subparser_choices)

                if is_missing_subcommand:
                    self.print_help(sys.stderr)
                    raise SystemExit(0)

        super().error(message)


__all__ = [
    "DEST_KEY",
    "ActionType",
    "ArgumentParser",
    "NargsPattern",
    "NestedSubParsersAction",
    "namespace_to_dict",
]
