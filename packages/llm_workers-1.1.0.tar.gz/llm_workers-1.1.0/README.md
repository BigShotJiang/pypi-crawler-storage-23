Core `llm-workers` library.

See https://mrbagheera.github.io/llm-workers/ for more information.