from v2sim.gui.parabox import *

def main():
    app = ParaBox()
    app.mainloop()

if __name__ == "__main__":
    main()