"""
Basic layout algorithms.

Simple utility layouts that serve as baselines or starting points.
"""

from .random import RandomLayout

__all__ = ["RandomLayout"]
