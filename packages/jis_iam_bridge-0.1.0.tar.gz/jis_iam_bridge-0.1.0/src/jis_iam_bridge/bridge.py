"""
IAM Bridge — the core identity bridge engine.

Every legacy IAM user gets a deterministic JIS identity.
No central registry. Same input = same JIS identity.
Both systems work in parallel until full migration.
"""

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .provenance import BridgeProvenance


VALID_SOURCE_TYPES = ("active_directory", "ldap", "saml", "oauth", "local")


@dataclass
class IAMSource:
    """
    A legacy IAM system registered as an identity source.

    Represents an Active Directory domain, LDAP server, SAML IdP,
    or OAuth provider that contains user identities to bridge.
    """
    name: str
    source_type: str  # active_directory, ldap, saml, oauth, local
    endpoint: str = ""
    domain: str = ""
    total_users: int = 0
    mapped_users: int = 0
    last_sync: str = ""

    def __post_init__(self) -> None:
        if self.source_type not in VALID_SOURCE_TYPES:
            raise ValueError(
                f"Invalid source_type '{self.source_type}'. "
                f"Must be one of: {', '.join(VALID_SOURCE_TYPES)}"
            )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "source_type": self.source_type,
            "endpoint": self.endpoint,
            "domain": self.domain,
            "total_users": self.total_users,
            "mapped_users": self.mapped_users,
            "last_sync": self.last_sync,
        }


@dataclass
class IdentityMapping:
    """
    A mapping between a legacy IAM user and a JIS cryptographic identity.

    The jis_id is deterministic: same source_type + domain + user_id
    always produces the same JIS identity.
    """
    jis_id: str  # jis:{hash} URI
    iam_user_id: str
    source_type: str
    source_domain: str
    display_name: str = ""
    email: str = ""
    groups: list[str] = field(default_factory=list)
    mapped_at: str = ""
    last_verified: str = ""
    active: bool = True
    tibet_token_id: str = ""

    def to_dict(self) -> dict:
        return {
            "jis_id": self.jis_id,
            "iam_user_id": self.iam_user_id,
            "source_type": self.source_type,
            "source_domain": self.source_domain,
            "display_name": self.display_name,
            "email": self.email,
            "groups": self.groups,
            "mapped_at": self.mapped_at,
            "last_verified": self.last_verified,
            "active": self.active,
            "tibet_token_id": self.tibet_token_id,
        }


def _derive_jis_id(source_type: str, domain: str, user_id: str) -> str:
    """
    Derive a deterministic JIS identity from IAM coordinates.

    Input:  jis:{source_type}:{domain}:{user_id}
    Output: jis:{sha256[:16]}

    Same input always produces the same JIS identity.
    No central registry needed.
    """
    canonical = f"jis:{source_type}:{domain}:{user_id}"
    digest = hashlib.sha256(canonical.encode()).hexdigest()[:16]
    return f"jis:{digest}"


def _groups_to_capabilities(groups: list[str]) -> list[str]:
    """
    Map AD/LDAP groups to JIS capability names.

    Strips common prefixes (cn=, CN=, ou=, OU=) and normalises
    the group name to a lowercase capability identifier.
    """
    capabilities = []
    for group in groups:
        # Strip LDAP-style prefixes
        name = group
        for prefix in ("cn=", "CN=", "ou=", "OU="):
            if name.startswith(prefix):
                name = name[len(prefix):]
                # Take only the first RDN component
                if "," in name:
                    name = name.split(",")[0]
                break

        # Normalise: spaces to underscores, lowercase
        cap = name.strip().replace(" ", "_").lower()
        if cap:
            capabilities.append(cap)
    return capabilities


class IAMBridge:
    """
    Bridge between legacy IAM systems and JIS cryptographic identity.

    Register IAM sources (Active Directory, LDAP, SAML, OAuth),
    map users to deterministic JIS identities, and track migration
    progress with TIBET provenance.

    Usage::

        bridge = IAMBridge()
        bridge.add_source(IAMSource(
            name="Corp AD",
            source_type="active_directory",
            endpoint="ldaps://dc01.corp.example.com",
            domain="corp.example.com",
        ))

        mapping = bridge.map_identity("jvandemeent", "active_directory")
        print(mapping.jis_id)  # jis:a3f8c91b2d4e7063
    """

    def __init__(self, actor: str = "jis-iam-bridge"):
        self.provenance = BridgeProvenance(actor=actor)
        self._sources: dict[str, IAMSource] = {}
        self._mappings_by_jis: dict[str, IdentityMapping] = {}
        self._mappings_by_iam: dict[str, IdentityMapping] = {}  # key: "{source_type}:{user_id}"
        self._stats = {
            "maps": 0,
            "resolves": 0,
            "syncs": 0,
            "verifications": 0,
        }

    def add_source(self, source: IAMSource) -> None:
        """
        Register an IAM source (AD, LDAP, SAML, OAuth).

        Each source_type can only be registered once. Adding a source
        with the same source_type replaces the previous one.
        """
        self._sources[source.source_type] = source

    def get_sources(self) -> list[IAMSource]:
        """Return all registered IAM sources."""
        return list(self._sources.values())

    def map_identity(
        self,
        iam_user_id: str,
        source_type: str,
        display_name: str = "",
        email: str = "",
        groups: list[str] | None = None,
    ) -> IdentityMapping:
        """
        Create a JIS identity from an IAM user.

        The JIS identity is deterministic: same source_type + domain + user_id
        always produces the same JIS identity. If already mapped, returns
        the existing mapping (updated with any new metadata).

        Args:
            iam_user_id: The user ID in the IAM source
            source_type: The IAM source type (active_directory, ldap, saml, oauth, local)
            display_name: Optional display name
            email: Optional email address
            groups: Optional list of group memberships

        Returns:
            IdentityMapping with the deterministic JIS identity
        """
        if source_type not in self._sources:
            raise ValueError(
                f"No IAM source registered for '{source_type}'. "
                f"Call add_source() first."
            )

        source = self._sources[source_type]
        domain = source.domain
        groups = groups or []

        jis_id = _derive_jis_id(source_type, domain, iam_user_id)
        now = datetime.now(timezone.utc).isoformat()
        iam_key = f"{source_type}:{iam_user_id}"

        # Check if already mapped
        if iam_key in self._mappings_by_iam:
            existing = self._mappings_by_iam[iam_key]
            # Update metadata if provided
            if display_name:
                existing.display_name = display_name
            if email:
                existing.email = email
            if groups:
                existing.groups = groups
            existing.last_verified = now
            return existing

        # Create TIBET provenance token
        token = self.provenance.create_token(
            action="map",
            iam_user_id=iam_user_id,
            jis_id=jis_id,
            source_type=source_type,
            domain=domain,
            groups=groups,
        )

        mapping = IdentityMapping(
            jis_id=jis_id,
            iam_user_id=iam_user_id,
            source_type=source_type,
            source_domain=domain,
            display_name=display_name,
            email=email,
            groups=groups,
            mapped_at=now,
            last_verified=now,
            active=True,
            tibet_token_id=token.token_id,
        )

        self._mappings_by_jis[jis_id] = mapping
        self._mappings_by_iam[iam_key] = mapping
        source.mapped_users += 1
        self._stats["maps"] += 1
        return mapping

    def resolve(self, jis_id: str) -> list[IdentityMapping]:
        """
        Resolve a JIS identity back to its IAM source(s).

        A JIS identity maps to exactly one IAM user per source,
        but could theoretically exist in multiple sources.

        Returns:
            List of IdentityMapping objects for this JIS identity
        """
        self._stats["resolves"] += 1
        results = []
        for mapping in self._mappings_by_iam.values():
            if mapping.jis_id == jis_id:
                results.append(mapping)
        return results

    def resolve_iam(
        self, iam_user_id: str, source_type: str
    ) -> IdentityMapping | None:
        """
        Find the JIS identity for an IAM user.

        Args:
            iam_user_id: The user ID in the IAM source
            source_type: The IAM source type

        Returns:
            IdentityMapping if found, None otherwise
        """
        self._stats["resolves"] += 1
        iam_key = f"{source_type}:{iam_user_id}"
        return self._mappings_by_iam.get(iam_key)

    def sync(self, source_type: str) -> list[IdentityMapping]:
        """
        Sync all identities from a source.

        In a real implementation this would connect to the IAM source
        and enumerate users. Here we re-verify all existing mappings
        for the given source type and create a sync provenance token.

        Returns:
            List of all mappings for this source type
        """
        if source_type not in self._sources:
            raise ValueError(f"No IAM source registered for '{source_type}'.")

        source = self._sources[source_type]
        now = datetime.now(timezone.utc).isoformat()
        synced = []

        for mapping in self._mappings_by_iam.values():
            if mapping.source_type == source_type:
                mapping.last_verified = now
                synced.append(mapping)

        source.last_sync = now

        # Create a sync provenance token
        self.provenance.create_token(
            action="sync",
            iam_user_id="*",
            jis_id=f"jis:sync:{source_type}",
            source_type=source_type,
            domain=source.domain,
            context=f"Bulk sync: {len(synced)} identities",
        )

        self._stats["syncs"] += 1
        return synced

    def verify(self, jis_id: str) -> bool:
        """
        Verify a JIS identity is still valid in its source IAM.

        In a real implementation this would check the IAM source
        to confirm the user still exists and is active.

        Returns:
            True if the identity is active and verified
        """
        self._stats["verifications"] += 1
        mappings = self.resolve(jis_id)

        if not mappings:
            return False

        now = datetime.now(timezone.utc).isoformat()
        all_valid = True

        for mapping in mappings:
            mapping.last_verified = now

            self.provenance.create_token(
                action="verify",
                iam_user_id=mapping.iam_user_id,
                jis_id=jis_id,
                source_type=mapping.source_type,
                domain=mapping.source_domain,
                groups=mapping.groups,
            )

            if not mapping.active:
                all_valid = False

        return all_valid

    def migration_status(self) -> dict[str, dict]:
        """
        Migration status: percentage of users with JIS identities per source.

        Returns:
            Dict keyed by source_type with total, mapped, and percentage
        """
        result = {}
        for source_type, source in self._sources.items():
            total = source.total_users
            mapped = source.mapped_users
            percentage = round(mapped / total * 100, 1) if total > 0 else 0.0
            result[source_type] = {
                "name": source.name,
                "total": total,
                "mapped": mapped,
                "percentage": percentage,
            }
        return result

    def stats(self) -> dict:
        """Bridge statistics."""
        total_mappings = len(self._mappings_by_iam)
        active_mappings = sum(
            1 for m in self._mappings_by_iam.values() if m.active
        )
        return {
            "sources": len(self._sources),
            "source_types": list(self._sources.keys()),
            "total_mappings": total_mappings,
            "active_mappings": active_mappings,
            "maps": self._stats["maps"],
            "resolves": self._stats["resolves"],
            "syncs": self._stats["syncs"],
            "verifications": self._stats["verifications"],
            "tibet_tokens": len(self.provenance.chain()),
        }
