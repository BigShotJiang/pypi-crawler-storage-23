"""
jis-iam-bridge CLI — Bridge Legacy IAM to JIS Cryptographic Identity.

Usage::

    jis-iam-bridge info       Concept overview (middleman problem, gradual migration)
    jis-iam-bridge demo       Demo: simulate AD with 50 users, map to JIS, verify
    jis-iam-bridge status     Bridge statistics
    jis-iam-bridge sources    Show configured IAM sources
"""

import argparse
import json
import sys

from .bridge import IAMBridge, IAMSource


def _create_demo_bridge() -> IAMBridge:
    """Create a bridge with demo sources and 50 simulated AD users."""
    bridge = IAMBridge()

    bridge.add_source(IAMSource(
        name="Corp Active Directory",
        source_type="active_directory",
        endpoint="ldaps://dc01.corp.example.com",
        domain="corp.example.com",
        total_users=50,
    ))
    bridge.add_source(IAMSource(
        name="Engineering LDAP",
        source_type="ldap",
        endpoint="ldaps://ldap.eng.example.com",
        domain="eng.example.com",
        total_users=25,
    ))
    bridge.add_source(IAMSource(
        name="SSO Portal",
        source_type="saml",
        endpoint="https://sso.example.com/saml/metadata",
        domain="sso.example.com",
        total_users=80,
    ))
    bridge.add_source(IAMSource(
        name="Google Workspace",
        source_type="oauth",
        endpoint="https://accounts.google.com",
        domain="example.com",
        total_users=60,
    ))

    return bridge


def _populate_demo_users(bridge: IAMBridge) -> None:
    """Map 50 simulated Active Directory users."""
    departments = [
        ("engineering", ["CN=Engineering,OU=Groups,DC=corp,DC=example,DC=com",
                         "CN=VPN Users,OU=Groups,DC=corp,DC=example,DC=com"]),
        ("sales", ["CN=Sales,OU=Groups,DC=corp,DC=example,DC=com"]),
        ("operations", ["CN=Operations,OU=Groups,DC=corp,DC=example,DC=com",
                        "CN=Server Admins,OU=Groups,DC=corp,DC=example,DC=com"]),
        ("finance", ["CN=Finance,OU=Groups,DC=corp,DC=example,DC=com"]),
        ("management", ["CN=Management,OU=Groups,DC=corp,DC=example,DC=com",
                        "CN=Domain Admins,OU=Groups,DC=corp,DC=example,DC=com"]),
    ]

    first_names = [
        "jan", "pieter", "klaas", "maria", "anna",
        "sophie", "lucas", "emma", "daan", "julia",
    ]
    last_names = [
        "devries", "jansen", "bakker", "visser", "smit",
        "meijer", "dekoning", "peters", "mulder", "bos",
    ]

    count = 0
    for dept_idx, (dept_name, dept_groups) in enumerate(departments):
        for name_idx, first in enumerate(first_names):
            if count >= 50:
                break
            last = last_names[name_idx % len(last_names)]
            # Unique user_id: include department index for uniqueness
            suffix = f"{dept_idx}" if dept_idx > 0 else ""
            user_id = f"{first}.{last}{suffix}"
            display = f"{first.capitalize()} {last.capitalize()}"
            email = f"{first}.{last}{suffix}@corp.example.com"

            bridge.map_identity(
                iam_user_id=user_id,
                source_type="active_directory",
                display_name=display,
                email=email,
                groups=dept_groups,
            )
            count += 1


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  jis-iam-bridge -- Bridge Legacy IAM to JIS Identity")
    print("=" * 64)
    print()
    print("The Middleman Problem:")
    print("  Your identity lives on someone else's server.")
    print("  Active Directory, LDAP, SAML, OAuth -- every one is")
    print("  a centralized middleman. Server down? Identity gone.")
    print("  Breach? Everyone exposed.")
    print()
    print("  Enterprises have millions of users in these systems.")
    print("  You can't rip-and-replace overnight.")
    print()
    print("The JIS Answer:")
    print("  JIS (Jasper Identity Scheme) uses cryptographic identity.")
    print("  Your identity is derived from keys you control.")
    print("  Verifiable by anyone. Dependent on no server.")
    print()
    print("The Bridge:")
    print("  Keep your legacy IAM. Add JIS on top.")
    print()
    print("  [Active Directory] <-> [jis-iam-bridge] <-> [JIS Identity]")
    print("  [LDAP Server]      <-> [jis-iam-bridge] <-> [JIS Identity]")
    print("  [SAML IdP]         <-> [jis-iam-bridge] <-> [JIS Identity]")
    print("  [OAuth Provider]   <-> [jis-iam-bridge] <-> [JIS Identity]")
    print()
    print("How It Works:")
    print("  1. Register your IAM sources")
    print("  2. Each user gets a deterministic jis: identity")
    print("     AD user 'jvandemeent@corp.example.com'")
    print("     -> jis:a3f8c91b2d4e7063")
    print("  3. Both systems work in parallel")
    print("  4. Migrate workloads to JIS at your own pace")
    print("  5. TIBET audit trail for every mapping")
    print()
    print("  Same input = same JIS identity. Always.")
    print("  No central registry needed.")
    print()
    print("=" * 64)
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print()
    print("  jis-iam-bridge Demo: Enterprise IAM Migration")
    print()

    bridge = _create_demo_bridge()

    # Step 1: Show sources
    print("  Step 1: Registered IAM Sources")
    print("  " + "-" * 56)
    for source in bridge.get_sources():
        print(f"    {source.name:<28} {source.source_type:<20} {source.total_users:>4} users")
    print()

    # Step 2: Map 50 AD users
    print("  Step 2: Mapping 50 Active Directory users to JIS...")
    _populate_demo_users(bridge)
    print(f"    Mapped {bridge.stats()['total_mappings']} users")
    print()

    # Step 3: Show sample mappings
    print("  Step 3: Sample Identity Mappings")
    print("  " + "-" * 56)
    print(f"    {'IAM User':<24} {'JIS Identity':<22} {'Groups'}")
    print("  " + "-" * 56)

    shown = 0
    for mapping in list(bridge._mappings_by_iam.values())[:8]:
        groups_str = ", ".join(mapping.groups[:2])
        if len(groups_str) > 30:
            groups_str = groups_str[:27] + "..."
        print(f"    {mapping.iam_user_id:<24} {mapping.jis_id:<22} {groups_str}")
        shown += 1
    print(f"    ... and {bridge.stats()['total_mappings'] - shown} more")
    print()

    # Step 4: Resolve demo
    print("  Step 4: Identity Resolution")
    print("  " + "-" * 56)

    sample_mapping = list(bridge._mappings_by_iam.values())[0]
    resolved = bridge.resolve(sample_mapping.jis_id)
    if resolved:
        r = resolved[0]
        print(f"    Resolve JIS -> IAM:")
        print(f"      {r.jis_id} -> {r.iam_user_id}@{r.source_domain}")
    print()

    iam_resolved = bridge.resolve_iam(sample_mapping.iam_user_id, "active_directory")
    if iam_resolved:
        print(f"    Resolve IAM -> JIS:")
        print(f"      {iam_resolved.iam_user_id} -> {iam_resolved.jis_id}")
    print()

    # Step 5: Verify
    print("  Step 5: Identity Verification")
    print("  " + "-" * 56)
    verified = bridge.verify(sample_mapping.jis_id)
    print(f"    Verify {sample_mapping.jis_id}: {'VALID' if verified else 'INVALID'}")
    print()

    # Step 6: Sync
    print("  Step 6: Source Sync")
    print("  " + "-" * 56)
    synced = bridge.sync("active_directory")
    print(f"    Synced {len(synced)} identities from active_directory")
    print()

    # Step 7: Migration status
    print("  Step 7: Migration Status")
    print("  " + "-" * 56)
    status = bridge.migration_status()
    for source_type, info in status.items():
        bar_len = int(info["percentage"] / 5)
        bar = "#" * bar_len + "." * (20 - bar_len)
        print(
            f"    {info['name']:<28} [{bar}] "
            f"{info['mapped']:>3}/{info['total']:<3} "
            f"({info['percentage']}%)"
        )
    print()

    # Step 8: Stats
    stats = bridge.stats()
    print("  Bridge Statistics:")
    print("  " + "-" * 56)
    print(f"    Sources:        {stats['sources']}")
    print(f"    Total mappings: {stats['total_mappings']}")
    print(f"    Active:         {stats['active_mappings']}")
    print(f"    TIBET tokens:   {stats['tibet_tokens']}")
    print()

    return 0


def cmd_status(args: argparse.Namespace) -> int:
    bridge = _create_demo_bridge()
    _populate_demo_users(bridge)

    stats = bridge.stats()

    if args.json:
        print(json.dumps(stats, indent=2))
    else:
        print()
        print("  jis-iam-bridge Status")
        print("  " + "-" * 40)
        print(f"    Sources:         {stats['sources']}")
        print(f"    Source types:     {', '.join(stats['source_types'])}")
        print(f"    Total mappings:  {stats['total_mappings']}")
        print(f"    Active mappings: {stats['active_mappings']}")
        print(f"    Map operations:  {stats['maps']}")
        print(f"    Resolves:        {stats['resolves']}")
        print(f"    Syncs:           {stats['syncs']}")
        print(f"    Verifications:   {stats['verifications']}")
        print(f"    TIBET tokens:    {stats['tibet_tokens']}")
        print()

    return 0


def cmd_sources(args: argparse.Namespace) -> int:
    bridge = _create_demo_bridge()
    _populate_demo_users(bridge)
    sources = bridge.get_sources()

    if args.json:
        print(json.dumps([s.to_dict() for s in sources], indent=2))
    else:
        print()
        print(f"  {'Name':<28} {'Type':<20} {'Domain':<24} {'Users':<8} {'Mapped'}")
        print("  " + "-" * 88)
        for s in sources:
            print(
                f"  {s.name:<28} {s.source_type:<20} "
                f"{s.domain:<24} {s.total_users:<8} {s.mapped_users}"
            )
        print()

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="jis-iam-bridge",
        description="Bridge Legacy IAM to JIS Cryptographic Identity",
    )
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("info", help="Concept overview")
    sub.add_parser("demo", help="Demo: simulate AD with 50 users, map to JIS")

    p_status = sub.add_parser("status", help="Bridge statistics")
    p_status.add_argument("-j", "--json", action="store_true")

    p_sources = sub.add_parser("sources", help="Show configured IAM sources")
    p_sources.add_argument("-j", "--json", action="store_true")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "info": cmd_info,
        "demo": cmd_demo,
        "status": cmd_status,
        "sources": cmd_sources,
    }
    sys.exit(commands[args.command](args))
