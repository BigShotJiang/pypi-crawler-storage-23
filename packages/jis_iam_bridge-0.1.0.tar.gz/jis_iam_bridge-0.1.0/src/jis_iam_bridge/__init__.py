"""
jis-iam-bridge — Bridge Legacy IAM to JIS Cryptographic Identity
=================================================================

Keep your enterprise IAM (Active Directory, LDAP, SAML, OAuth).
Add JIS on top. Every legacy user gets a deterministic cryptographic
identity. No rip-and-replace. Gradual migration. Both systems in parallel.

TIBET audit trail for every identity mapping.

Usage::

    from jis_iam_bridge import IAMBridge, IAMSource

    bridge = IAMBridge()
    bridge.add_source(IAMSource(
        name="Corp AD",
        source_type="active_directory",
        endpoint="ldaps://dc01.corp.example.com",
        domain="corp.example.com",
    ))

    mapping = bridge.map_identity("jvandemeent", "active_directory")
    print(mapping.jis_id)  # jis:a3f8c91b2d4e7063

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica 2025
"""

from .bridge import IAMBridge, IdentityMapping, IAMSource
from .provenance import BridgeProvenance

__version__ = "0.1.0"

__all__ = [
    "IAMBridge",
    "IdentityMapping",
    "IAMSource",
    "BridgeProvenance",
]
