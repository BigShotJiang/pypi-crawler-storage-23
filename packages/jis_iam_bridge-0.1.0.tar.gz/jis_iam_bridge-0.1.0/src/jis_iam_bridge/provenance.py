"""
TIBET provenance for IAM-to-JIS identity bridge operations.

Every identity mapping, every sync, every verification is recorded
as a TIBET token. The chain is the migration audit trail.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class BridgeToken:
    token_id: str
    timestamp: str
    action: str
    iam_user_id: str
    jis_id: str
    source_type: str
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "iam_bridge",
            "action": self.action,
            "iam_user_id": self.iam_user_id,
            "jis_id": self.jis_id,
            "source_type": self.source_type,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class BridgeProvenance:
    def __init__(self, actor: str = "jis-iam-bridge"):
        self.actor = actor
        self.tokens: list[BridgeToken] = []
        self._last_id: str | None = None

    def create_token(
        self,
        action: str,
        iam_user_id: str,
        jis_id: str,
        source_type: str,
        domain: str = "",
        groups: list[str] | None = None,
        context: str = "",
    ) -> BridgeToken:
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "action": action,
            "iam_user_id": iam_user_id,
            "jis_id": jis_id,
            "source_type": source_type,
        }
        eraan = {
            "parent_token": self._last_id,
            "iam_source": source_type,
            "domain": domain,
            "groups": groups or [],
        }
        eromheen = {
            "bridge_node": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
            "sync_context": context,
        }

        if action == "sync":
            intent_text = f"Migration sync: {domain}"
        elif action == "verify":
            intent_text = f"Identity verify: {iam_user_id} ({source_type})"
        else:
            intent_text = f"Identity bridge: {source_type} → JIS"

        erachter = {
            "intent": intent_text,
            "migration_action": True,
            "decision": action.upper(),
        }

        content = json.dumps({"erin": erin}, sort_keys=True)
        token_id = hashlib.sha256(
            f"{iam_user_id}:{jis_id}:{now}".encode()
        ).hexdigest()[:16]
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = BridgeToken(
            token_id=token_id,
            timestamp=now,
            action=action,
            iam_user_id=iam_user_id,
            jis_id=jis_id,
            source_type=source_type,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        return [t.to_dict() for t in self.tokens]
