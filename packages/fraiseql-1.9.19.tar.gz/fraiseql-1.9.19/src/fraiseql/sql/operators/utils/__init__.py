"""Utility functions for operator strategies."""
