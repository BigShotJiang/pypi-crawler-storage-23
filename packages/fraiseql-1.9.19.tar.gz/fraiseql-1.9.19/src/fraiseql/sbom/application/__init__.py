"""SBOM Application Layer.

Application services orchestrate domain operations and coordinate
between domain and infrastructure layers.
"""
