"""
RLAgent: Policy-driven executor for workflow discovery.

The RLAgent consults a learned PolicyInterface to decide which action pair
to execute next, building a workflow dynamically from the policy's learned
strategy. The trained policy IS the workflow — it encodes which action pairs
to select in which order.

Contrast with DualStateAgent + Workflow, which follow a fixed step graph
defined in a JSON config. The RLAgent replaces that fixed graph with a
learned policy that may discover the same sequence, a better one, or an
entirely different approach.

The RLAgent operates at the workflow level: it holds the full pool of
available action pairs and uses the policy to select which one to execute
next. Each action pair handles its own internal retries (via DualStateAgent
or similar). The RLAgent only sees whether the AP succeeded or failed as
a whole.

When ``enable_backtracking`` is True and the policy re-selects a satisfied
AP, cascade invalidation (Def 47) removes that AP and its transitive
dependents from satisfied, failure context is injected (Def 48), and the
AP re-executes with fresh context.

Raises RuntimeError when the step budget is exhausted without satisfying
all action pairs.
"""

from __future__ import annotations

import logging
from collections import deque
from typing import TYPE_CHECKING

from atomicguard.domain.interfaces import (
    ActionPairPoolInterface,
    PolicyInterface,
)
from atomicguard.domain.models import AmbientEnvironment, Artifact, Context
from atomicguard.domain.rl.state import State

if TYPE_CHECKING:
    from atomicguard.domain.interfaces import ArtifactDAGInterface

logger = logging.getLogger(__name__)

_MAX_FEEDBACK_ENTRIES = 3


class RLAgent:
    """
    Policy-driven workflow executor that selects action pairs.

    The trained policy IS the workflow. At inference time, the policy
    maps state (which APs are satisfied, which are available) to
    the next action pair index to execute — replacing the hand-crafted
    step graph with a learned strategy.

    Each action pair handles its own internal retry logic. The RLAgent
    only observes whether the AP succeeded (guard passed) or failed
    (guard failed after all internal retries).

    When ``enable_backtracking`` is True, the agent can re-select a
    satisfied AP to trigger cascade invalidation and re-execution with
    failure context from downstream failures.
    """

    def __init__(
        self,
        action_pair_pool: ActionPairPoolInterface,
        policy: PolicyInterface,
        specification: str,
        max_steps: int | None = None,
        artifact_dag: ArtifactDAGInterface | None = None,
        enable_backtracking: bool = True,
    ):
        """
        Args:
            action_pair_pool: Pool of available action pairs to choose from.
            policy: Learned policy for action pair selection.
            specification: Task specification for context construction.
            max_steps: Maximum execution steps. Defaults to 2 * num_action_pairs.
            artifact_dag: Injected artifact DAG for context construction.
            enable_backtracking: When True, re-selecting a satisfied AP triggers
                cascade invalidation and failure context injection.
        """
        self._pool = action_pair_pool
        self._policy = policy
        self._specification = specification
        self._artifact_dag = artifact_dag
        self._enable_backtracking = enable_backtracking

        self._action_pairs = self._pool.get_available_action_pairs()
        self._ap_ids = tuple(ap.action_pair_id for ap in self._action_pairs)
        self._max_steps = max_steps or max(2 * len(self._action_pairs), 1)

        # Build requires map for dependency checking
        self._requires_map: dict[str, tuple[str, ...]] = {
            ap.action_pair_id: ap.requires for ap in self._action_pairs
        }

        # Build reverse dependency map for cascade invalidation
        self._dependents_map: dict[str, set[str]] = {
            ap_id: set() for ap_id in self._ap_ids
        }
        for ap in self._action_pairs:
            for dep in ap.requires:
                if dep in self._dependents_map:
                    self._dependents_map[dep].add(ap.action_pair_id)

        # Escalation routing from ActionPairInfo metadata
        self._escalate_feedback_to: dict[str, tuple[str, ...]] = {
            ap.action_pair_id: ap.escalate_feedback_to for ap in self._action_pairs
        }

    def execute(self) -> list[Artifact]:
        """Execute the workflow using the learned policy.

        The policy selects which action pair to execute next based on the
        current state (which APs are satisfied). Each selected AP is
        executed (internally handling retries). If the AP's guard passes,
        it becomes satisfied. The process continues until all APs are
        satisfied or the step budget is exhausted.

        Returns:
            List of artifacts from successfully executed action pairs.

        Raises:
            RuntimeError: If the step budget is exhausted without
                satisfying all action pairs.
        """
        satisfied: frozenset[str] = frozenset()
        available: frozenset[str] = frozenset(self._ap_ids)
        artifacts: list[Artifact] = []
        artifact_map: dict[str, Artifact] = {}  # AP ID → produced artifact
        guard_feedback: dict[str, list[str]] = {}  # AP ID → guard feedback history
        escalation_feedback: dict[
            str, list[str]
        ] = {}  # AP ID → injected failure context
        steps_taken = 0

        # Ensure a DAG exists for context construction
        if self._artifact_dag is not None:
            dag = self._artifact_dag
        else:
            from atomicguard.infrastructure.persistence.memory import (
                InMemoryArtifactDAG,
            )

            dag = InMemoryArtifactDAG()

        while steps_taken < self._max_steps:
            # Check if all APs are satisfied
            if satisfied == available:
                logger.info(
                    "Inference complete: all %d action pairs satisfied in %d steps",
                    len(self._ap_ids),
                    steps_taken,
                )
                return artifacts

            state = State(satisfied=satisfied, available=available)
            action_idx = self._policy.select_action(state)

            # Validate action index
            if action_idx < 0 or action_idx >= len(self._action_pairs):
                logger.warning("Invalid action index %d, skipping", action_idx)
                steps_taken += 1
                continue

            selected_ap = self._action_pairs[action_idx]
            ap_id = selected_ap.action_pair_id

            # Handle already-satisfied APs
            if ap_id in satisfied:
                if self._enable_backtracking:
                    # Backtracking: cascade invalidation + failure context injection
                    to_invalidate = self._get_transitive_dependents(ap_id)
                    to_invalidate.add(ap_id)

                    # Find failed downstream for context injection
                    failed_downstream = None
                    for inv_id in to_invalidate:
                        if inv_id != ap_id and inv_id in guard_feedback:
                            failed_downstream = inv_id

                    logger.info(
                        "[%s] Backtracking: cascade invalidation of %s",
                        ap_id,
                        to_invalidate,
                    )

                    for inv_id in to_invalidate:
                        satisfied = satisfied - {inv_id}
                        artifact_map.pop(inv_id, None)

                    # Inject failure context
                    if failed_downstream:
                        summary = self._build_failure_summary(
                            failed_downstream, guard_feedback[failed_downstream]
                        )
                        targets = self._escalate_feedback_to.get(failed_downstream, ())
                        if not targets:
                            targets = (ap_id,)
                        for target_id in targets:
                            if target_id not in escalation_feedback:
                                escalation_feedback[target_id] = []
                            escalation_feedback[target_id].append(summary)
                    # Fall through to execute
                else:
                    logger.debug("AP %s already satisfied, skipping", ap_id)
                    steps_taken += 1
                    continue

            # Execute the action pair
            try:
                logger.info(
                    "[%s] Executing (step %d/%d, satisfied=%d/%d)",
                    ap_id,
                    steps_taken + 1,
                    self._max_steps,
                    len(satisfied),
                    len(self._ap_ids),
                )

                # Build Context (mirrors TrainingEnvironment pattern)
                dep_artifacts = tuple(
                    (dep_id, artifact_map[dep_id].artifact_id)
                    for dep_id in selected_ap.requires
                    if dep_id in artifact_map
                )
                esc_entries = escalation_feedback.get(ap_id, [])
                if esc_entries:
                    logger.info(
                        "[%s] Executing with escalation feedback (%d entries)",
                        ap_id,
                        len(esc_entries),
                    )
                context = Context(
                    ambient=AmbientEnvironment(repository=dag, constraints=""),
                    specification=self._specification,
                    dependency_artifacts=dep_artifacts,
                    escalation_feedback=tuple(esc_entries),
                )
                # Build dependencies dict for guard validation (keyed by AP ID)
                dep_dict = {
                    dep_id: artifact_map[dep_id]
                    for dep_id in selected_ap.requires
                    if dep_id in artifact_map
                }
                artifact, result = selected_ap.action_pair.execute(
                    context, dep_dict, ap_id, "inference"
                )

                if result.passed:
                    satisfied = satisfied | {ap_id}
                    artifact_map[ap_id] = artifact
                    artifacts.append(artifact)
                    dag.store(artifact)
                    logger.info(
                        "[%s] Guard passed (step %d, satisfied=%d/%d)",
                        ap_id,
                        steps_taken + 1,
                        len(satisfied),
                        len(self._ap_ids),
                    )
                else:
                    # Track guard feedback for backtracking context injection
                    if result.feedback:
                        logger.info("[%s] Guard FAILED: %r", ap_id, result.feedback)
                        if ap_id not in guard_feedback:
                            guard_feedback[ap_id] = []
                        guard_feedback[ap_id].append(result.feedback)
                        # Pre-stage failure context into escalation targets
                        # so it's available when the policy backtracks
                        self._inject_failure_feedback(
                            ap_id, guard_feedback[ap_id], escalation_feedback
                        )

            except Exception:
                logger.exception("AP %s raised exception (step %d)", ap_id, steps_taken)

            steps_taken += 1

        # Budget exhausted
        unsatisfied = available - satisfied
        logger.info(
            "Inference failed: budget exhausted after %d steps, satisfied=%d/%d",
            self._max_steps,
            len(satisfied),
            len(self._ap_ids),
        )
        raise RuntimeError(
            f"Step budget exhausted ({self._max_steps} steps). "
            f"Unsatisfied APs: {unsatisfied}"
        )

    def _inject_failure_feedback(
        self,
        ap_id: str,
        feedback_entries: list[str],
        escalation_feedback: dict[str, list[str]],
    ) -> None:
        """Pre-stage failure context into escalation targets on AP failure.

        Routes guard feedback to configured escalate_feedback_to targets
        (or direct dependencies as fallback) so the context is available
        when the policy backtracks to those APs.

        Args:
            ap_id: The failed AP.
            feedback_entries: Guard feedback accumulated for this AP.
            escalation_feedback: Mutable dict to inject feedback into.
        """
        summary = self._build_failure_summary(ap_id, feedback_entries)

        targets = self._escalate_feedback_to.get(ap_id, ())
        if not targets:
            targets = self._requires_map.get(ap_id, ())

        for target_id in targets:
            if target_id not in escalation_feedback:
                escalation_feedback[target_id] = []
            escalation_feedback[target_id].append(summary)
            logger.debug(
                "[%s] Failure feedback pre-staged into %s",
                ap_id,
                target_id,
            )

    def _get_transitive_dependents(self, target_id: str) -> set[str]:
        """Find all APs that transitively depend on target_id (Def 47).

        Uses BFS over the reverse dependency map.

        Args:
            target_id: The AP ID to find dependents for.

        Returns:
            Set of AP IDs that depend on target (directly or transitively).
        """
        dependents: set[str] = set()
        queue: deque[str] = deque([target_id])

        while queue:
            current = queue.popleft()
            for dep_id in self._dependents_map.get(current, set()):
                if dep_id not in dependents:
                    dependents.add(dep_id)
                    queue.append(dep_id)

        return dependents

    @staticmethod
    def _build_failure_summary(ap_id: str, feedback_entries: list[str]) -> str:
        """Build a concise failure summary from recent guard feedback.

        Args:
            ap_id: The AP that failed.
            feedback_entries: Guard feedback strings from failed attempts.

        Returns:
            Formatted failure summary string.
        """
        recent = feedback_entries[-_MAX_FEEDBACK_ENTRIES:]
        entries = "\n".join(f"  - {fb}" for fb in recent)
        return f"Downstream AP '{ap_id}' failed. Recent feedback:\n{entries}"
