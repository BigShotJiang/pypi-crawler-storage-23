"""
Generic training loop for workflow discovery via RL.

The Trainer drives the state-action-reward loop: the agent observes which
action pairs are satisfied, selects which action pair index to execute
next, receives reward from guards, and updates its policy. Over many
episodes, the policy converges to a workflow — a mapping from state to
"which action pair to run next" that solves the task.

The output of training is a trained PolicyInterface that any agent can
follow as a workflow without the RL loop.

Consumes domain interfaces (TrainablePolicyInterface, EnvironmentInterface,
ExperienceBufferInterface) via dependency injection. No concrete infrastructure
references — all dependencies are domain ports.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from atomicguard.domain.rl.transitions import Transition

if TYPE_CHECKING:
    from atomicguard.domain.interfaces import (
        EnvironmentInterface,
        ExperienceBufferInterface,
        TrainablePolicyInterface,
    )

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StepInfo:
    """Per-step data passed to the on_step callback.

    Provides enough context to reconstruct the episode's action pair
    execution sequence, including which APs were satisfied before/after
    and whether the guard passed.
    """

    episode: int
    step: int
    max_steps: int
    action: int  # index into AP pool
    reward_value: float
    guard_passed: bool
    terminal: bool
    satisfied_before: frozenset[str]
    satisfied_after: frozenset[str]
    available_after: frozenset[str]
    step_duration_ms: float = 0.0


@dataclass(frozen=True)
class EpisodeMetrics:
    """Per-episode metrics passed to the on_episode callback.

    Replaces the growing positional argument list with a single
    structured object.  Fields that depend on the environment
    (tokens_used, backtrack_count) come from
    ``EnvironmentInterface.get_episode_stats()``.
    """

    episode: int
    reward: float
    steps: int
    satisfied_count: int
    total_aps: int
    all_satisfied: bool
    duration_secs: float
    tokens_used: int
    backtrack_count: int
    execution_duration_ms: float = 0.0
    started_at: str = ""
    finished_at: str = ""


@dataclass(frozen=True)
class TrainingConfig:
    """Training hyperparameters.

    Note on exploration decay: the Trainer does not call
    ``policy.decay_epsilon()`` directly. Epsilon scheduling is the
    caller's responsibility via the ``on_checkpoint`` callback — this
    keeps the Trainer agnostic to the policy's exploration strategy.
    For example, the RL training CLI decays epsilon at each checkpoint::

        def on_checkpoint(episode, mean_reward):
            policy.decay_epsilon(epsilon_decay ** checkpoint_interval)
            policy.save(checkpoint_dir)
    """

    num_episodes: int = 1000
    max_steps_per_episode: int = 100
    batch_size: int = 32
    learning_rate: float = 3e-4
    gamma: float = 0.99  # Discount factor
    checkpoint_interval: int = 100  # Save every N episodes
    rmax_per_ap: int = (
        2  # Max retries within DualStateAgent per RL step (3 total attempts)
    )


class Trainer:
    """Training loop for workflow discovery.

    Runs episodes where the agent selects action pair indices, guards
    evaluate, and Q-values update. Over many episodes, the policy
    converges to a workflow — the output is a trained PolicyInterface
    that maps states to action pair selections and can be saved/loaded
    for inference by any agent.

    Receives all dependencies via constructor — environment, policy,
    and experience buffer are all injected as domain interfaces.
    """

    def __init__(
        self,
        environment: EnvironmentInterface,
        policy: TrainablePolicyInterface,
        replay_buffer: ExperienceBufferInterface,
        config: TrainingConfig | None = None,
    ) -> None:
        """
        Args:
            environment: RL environment implementing EnvironmentInterface.
            policy: Trainable policy implementing TrainablePolicyInterface.
            replay_buffer: Experience storage implementing ExperienceBufferInterface.
            config: Training hyperparameters.
        """
        self._env = environment
        self._policy = policy
        self._buffer = replay_buffer
        self._config = config or TrainingConfig()

    def train(
        self,
        on_checkpoint: Callable[[int, float], None] | None = None,
        on_episode: Callable[[EpisodeMetrics], None] | None = None,
        on_step: Callable[[StepInfo], None] | None = None,
        start_episode: int = 0,
    ) -> dict[str, Any]:
        """Run the training loop.

        Uses TD(0) Q-learning:
            Q(s,a) += alpha * (R + gamma * max_Q(s',a') - Q(s,a))

        The policy.update() method receives the TD target,
        implementing: Q(s,a) += alpha * (td_target - Q(s,a))

        Args:
            on_checkpoint: Optional callback invoked every
                ``config.checkpoint_interval`` episodes with
                ``(episode_number, mean_recent_reward)``.  The caller
                can use this to save checkpoints without the Trainer
                importing infrastructure.
            on_episode: Optional callback invoked after every episode with
                an ``EpisodeMetrics`` instance containing reward, steps,
                satisfaction, duration, tokens, and backtrack count.
            on_step: Optional callback invoked after every step with a
                ``StepInfo`` instance containing action index, reward,
                guard result, and satisfied sets.  Useful for writing
                live progress files and per-step logs.
            start_episode: Episode to start from (for resuming training).
                Episodes before this are skipped.

        Returns:
            Training metrics (episodes, mean_reward, episode_rewards).
        """
        config = self._config
        episode_rewards: list[float] = []

        logger.info(
            "Training started: %d episodes, max_steps=%d",
            config.num_episodes,
            config.max_steps_per_episode,
        )

        for episode in range(start_episode, config.num_episodes):
            t0 = time.perf_counter()
            started_at = datetime.now(tz=UTC).isoformat()
            state = self._env.reset()
            env_stats_init = self._env.get_episode_stats()
            total_aps = env_stats_init.get(
                "total_aps", len(state.satisfied) + len(state.available)
            )
            required_aps = env_stats_init.get("required_aps", total_aps)
            episode_reward = 0.0

            done = False
            steps_taken = 0
            for step in range(config.max_steps_per_episode):
                satisfied_before = state.satisfied
                action = self._policy.select_action(state)
                next_state, reward_signal, done = self._env.execute_step(action)

                # TD(0) Q-learning update via domain port
                state_idx = self._policy.encode_state(state)
                action_idx = action  # Action is already an int index

                if done:
                    td_target = reward_signal.value
                else:
                    next_state_idx = self._policy.encode_state(next_state)
                    td_target = (
                        reward_signal.value
                        + config.gamma * self._policy.get_max_q_value(next_state_idx)
                    )

                self._policy.update(state_idx, action_idx, td_target)

                # Store transition in replay buffer
                self._buffer.push(
                    Transition(
                        state=state,
                        action=action,
                        reward=reward_signal,
                        next_state=next_state,
                        done=done,
                    )
                )

                episode_reward += reward_signal.value
                state = next_state
                steps_taken = step + 1

                if on_step:
                    step_stats = self._env.get_episode_stats()
                    on_step(
                        StepInfo(
                            episode=episode + 1,
                            step=steps_taken,
                            max_steps=config.max_steps_per_episode,
                            action=action,
                            reward_value=reward_signal.value,
                            guard_passed=len(next_state.satisfied)
                            > len(satisfied_before),
                            terminal=done,
                            satisfied_before=satisfied_before,
                            satisfied_after=next_state.satisfied,
                            available_after=next_state.available,
                            step_duration_ms=step_stats.get(
                                "last_step_duration_ms", 0.0
                            ),
                        )
                    )

                if done:
                    break

            # Experience replay: sample a batch from the buffer and
            # perform additional Q-learning updates.  This stabilises
            # learning by re-visiting past transitions.
            if len(self._buffer) >= config.batch_size:
                batch = self._buffer.sample(config.batch_size)
                for t in batch:
                    s_idx = self._policy.encode_state(t.state)
                    if t.done:
                        target = t.reward.value
                    else:
                        ns_idx = self._policy.encode_state(t.next_state)
                        target = (
                            t.reward.value
                            + config.gamma * self._policy.get_max_q_value(ns_idx)
                        )
                    self._policy.update(s_idx, t.action, target)

            episode_rewards.append(episode_reward)

            logger.info(
                "Episode %d/%d: reward=%.2f, steps=%d",
                episode + 1,
                config.num_episodes,
                episode_reward,
                steps_taken,
            )

            if on_episode:
                duration_secs = time.perf_counter() - t0
                finished_at = datetime.now(tz=UTC).isoformat()
                env_stats = self._env.get_episode_stats()
                satisfied_count = len(state.satisfied)
                all_satisfied = done and satisfied_count >= required_aps
                on_episode(
                    EpisodeMetrics(
                        episode=episode + 1,
                        reward=episode_reward,
                        steps=steps_taken,
                        satisfied_count=satisfied_count,
                        total_aps=required_aps,
                        all_satisfied=all_satisfied,
                        duration_secs=duration_secs,
                        tokens_used=env_stats.get("tokens", 0),
                        backtrack_count=env_stats.get("backtracks", 0),
                        execution_duration_ms=env_stats.get(
                            "episode_execution_ms", 0.0
                        ),
                        started_at=started_at,
                        finished_at=finished_at,
                    )
                )

            if (episode + 1) % 100 == 0:
                recent = episode_rewards[-100:]
                mean_recent = sum(recent) / len(recent)
                logger.info(
                    "Episode %d/%d — mean reward (last 100): %.3f",
                    episode + 1,
                    config.num_episodes,
                    mean_recent,
                )

            # Checkpoint callback
            if on_checkpoint and (episode + 1) % config.checkpoint_interval == 0:
                recent = episode_rewards[-config.checkpoint_interval :]
                mean_recent = sum(recent) / len(recent)
                on_checkpoint(episode + 1, mean_recent)

        mean_reward = (
            sum(episode_rewards) / len(episode_rewards) if episode_rewards else 0.0
        )

        logger.info("Training complete: mean_reward=%.2f", mean_reward)

        return {
            "episodes": config.num_episodes,
            "mean_reward": mean_reward,
            "episode_rewards": episode_rewards,
        }

    def evaluate(self, num_episodes: int = 10) -> dict[str, Any]:
        """Evaluate current policy without training.

        Disables exploration, runs episodes, then restores exploration.

        Args:
            num_episodes: Number of evaluation episodes.

        Returns:
            Evaluation metrics (episodes, mean_reward, success_rate).
        """
        config = self._config
        self._policy.set_exploration(False)

        try:
            episode_rewards: list[float] = []
            successes = 0

            for _episode in range(num_episodes):
                state = self._env.reset()
                episode_reward = 0.0
                episode_success = False

                for _step in range(config.max_steps_per_episode):
                    action = self._policy.select_action(state)
                    next_state, reward_signal, done = self._env.execute_step(action)

                    episode_reward += reward_signal.value
                    state = next_state

                    if done:
                        # Success if final reward is positive
                        if reward_signal.value > 0:
                            episode_success = True
                        break

                episode_rewards.append(episode_reward)
                if episode_success:
                    successes += 1

            mean_reward = (
                sum(episode_rewards) / len(episode_rewards) if episode_rewards else 0.0
            )
            success_rate = successes / max(num_episodes, 1)

            logger.info(
                "Evaluation: mean_reward=%.2f, success_rate=%.1f%% (%d episodes)",
                mean_reward,
                success_rate * 100,
                num_episodes,
            )

            return {
                "episodes": num_episodes,
                "mean_reward": mean_reward,
                "success_rate": success_rate,
            }
        finally:
            self._policy.set_exploration(True)
