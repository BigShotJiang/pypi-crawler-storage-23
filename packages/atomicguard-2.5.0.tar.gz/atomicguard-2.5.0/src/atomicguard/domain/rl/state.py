"""
RL state representation for workflow discovery.

The state encodes which action pairs have been satisfied (guards passed)
and which are available to execute. The policy maps State → action pair
index, discovering the optimal sequence. Pure data — no framework deps.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class State:
    """The RL agent's view of the world when deciding which action pair to execute next.

    This is the complete state for workflow discovery via Q-learning:
    - S = set of satisfied action pairs (guards passed)
    - Available = set of action pairs eligible to run
    - backtrack_active = whether backtracking targets are in available

    The policy mapping State → action_pair_index IS the workflow.
    S' after executing action pair i:
    - Success: S' = S ∪ {i} (new state)
    - Failure: S' = S (state unchanged, budget consumed)

    When an AP exhausts its retries, its upstream dependencies (backtrack
    targets) are added to ``available`` even though they're in ``satisfied``.
    The ``backtrack_active`` flag lets the policy distinguish "normal mode"
    from "backtracking mode" for the same satisfaction state.
    """

    satisfied: frozenset[str]  # Action pair IDs whose guards have passed
    available: frozenset[str]  # Action pair IDs eligible to execute
    backtrack_active: bool = False  # True when backtrack targets are in available
    strategy_recommendation: int = 0  # 0=UNKNOWN, 1=MINIMAL, 2=COMPREHENSIVE, 3=DIRECT
