"""
RL reward signal contracts.

Defines the reward structure and the interface for computing rewards.
Guards provide the primary reward signal: did the action pair's guard
pass? The reward function shapes this into a scalar that teaches the
agent which action pair sequences (i.e., which workflows) solve the
task efficiently. Pure data and ABCs — no framework deps.

Concrete implementations live in ``infrastructure/rl/rewards.py``.

Reward strategies (from sparse to dense signal):

1. **Sparse Binary** — +1 when all APs satisfied at episode end,
   -1 on timeout. Unbiased baseline but very slow to learn from.

2. **Step Reward** — +r each time an AP is newly satisfied, small
   -p per step (time cost). Dense signal, learns faster, but can
   bias toward greedy local picks.

3. **Efficiency Penalty** — Like Step Reward plus penalties for
   waste: attempting already-satisfied APs, invalid actions,
   failed guard checks. Teaches the agent what *not* to do.

4. **Order-Shaped** — Bonus for following the expert workflow
   ordering (from JSON workflow configs). Leverages hand-crafted
   workflows as expert demonstrations. Risk: over-constrains
   exploration.

5. **Potential-Based Shaping** — Reward includes Φ(s') - Φ(s)
   where Φ(s) = |satisfied| / |total|. Mathematically guaranteed
   to preserve the optimal policy (Ng et al., 1999). The
   theoretically "correct" way to add dense signal.

6. **Curiosity/Novelty** — Extra reward for attempting APs the
   agent hasn't tried in this episode. Encourages broad
   exploration early in training. Needs episode-level tracking.

Start with strategies 1 + 5 (baseline + principled shaping), then
add 2 + 3 for faster signal. Use 4 only to bootstrap from known
expert workflows. Use 6 for cold-start with large AP vocabularies.

See ``docs/design/plans/the_policy_is_planning.md`` §4 for full
design rationale and selection guidance.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True)
class RewardSignal:
    """Reward returned after an agent action.

    Separates the scalar reward from diagnostic metadata
    so training can log/analyze reward components.
    """

    value: float  # Scalar reward
    guard_passed: bool  # Whether the guard accepted the artifact
    tokens_used: int  # LLM tokens consumed in this step
    retries_used: int  # Number of retries before this outcome
    terminal: bool  # Whether the episode ended


class RewardFunctionInterface(ABC):
    """Contract for computing rewards from workflow outcomes.

    Implementations define what "good" means for a specific domain
    (e.g., SWE-Bench resolution, token efficiency, retry minimization).
    """

    @abstractmethod
    def compute(
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        """Compute reward for a single agent action outcome.

        Args:
            guard_passed: Whether the guard accepted the artifact.
            tokens_used: LLM tokens consumed in this step.
            retries_used: Number of retries before this outcome.
            terminal: Whether the episode ended (success or exhaustion).
            action: The action that was taken (for action-aware reward shaping).
            satisfied: AP IDs whose guards have passed (current state).
            available: AP IDs eligible to execute (full vocabulary).

        Returns:
            RewardSignal with scalar value and diagnostics.
        """
        pass
