"""
Tabular policy implementation — a learned workflow as a Q-table.

Maps discretised states (bitmask of satisfied action pairs) to action
pair selection values via Q(s,a). The converged Q-table encodes a
workflow: for each state (which APs have been satisfied), it assigns
values to each possible action pair to execute next. The greedy policy
over this Q-table IS the learned workflow that agents follow at
inference time.

Concrete implementation of PersistablePolicyInterface using a Q-table.
No neural network, no torch dependency.

Requires: numpy (already a transitive dep via matplotlib)
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from atomicguard.domain.interfaces import PersistablePolicyInterface

if TYPE_CHECKING:
    from atomicguard.domain.rl.state import State


class TabularPolicy(PersistablePolicyInterface):
    """Q-table policy — a learned workflow stored as a value table.

    Each entry Q(s,a) encodes "how good is it to select action pair a
    when the satisfied set is s?" The greedy policy (argmax_a Q(s,a))
    defines a workflow: for each state of satisfied APs, it picks the
    best next action pair. Epsilon-greedy exploration during training
    lets the agent discover novel action pair sequences.

    State encoding: the satisfied frozenset is mapped to a bitmask
    integer using a fixed ordering of action pair IDs. With N action
    pairs, there are 2^N possible states.

    Action space: integers 0..N-1, each selecting an action pair.
    """

    def __init__(
        self,
        num_action_pairs: int,
        action_pair_ids: tuple[str, ...] | None = None,
        epsilon: float = 0.1,
        alpha: float = 0.1,
    ) -> None:
        """
        Args:
            num_action_pairs: Number of action pairs in the pool (N).
                Q-table has 2^N states and N actions.
            action_pair_ids: Ordered tuple of AP IDs for bitmask encoding.
                If None, uses ("ap_0", "ap_1", ...) as placeholders.
            epsilon: Exploration rate for epsilon-greedy.
            alpha: Learning rate for Q-value updates.
        """
        self._num_action_pairs = num_action_pairs
        self._num_states = 2 ** (num_action_pairs + 3)  # +1 backtrack + 2 strategy bits
        self._num_actions = num_action_pairs

        if action_pair_ids is not None:
            if len(action_pair_ids) != num_action_pairs:
                raise ValueError(
                    f"action_pair_ids length ({len(action_pair_ids)}) "
                    f"must match num_action_pairs ({num_action_pairs})"
                )
            self._ap_ids = action_pair_ids
        else:
            self._ap_ids = tuple(f"ap_{i}" for i in range(num_action_pairs))

        # Map AP ID → bit position for bitmask encoding
        self._id_to_bit: dict[str, int] = {
            ap_id: i for i, ap_id in enumerate(self._ap_ids)
        }

        self.Q = np.zeros((self._num_states, self._num_actions), dtype=np.float64)
        self.visit_count = np.zeros(
            (self._num_states, self._num_actions), dtype=np.int64
        )
        self.epsilon = epsilon
        self.alpha = alpha
        self._base_epsilon = epsilon

    # -- PolicyInterface (inference) --

    def select_action(self, state: State) -> int:
        """Select which action pair to execute next.

        Uses epsilon-greedy over valid (available, not yet satisfied)
        action pairs. With probability epsilon, pick a random valid AP;
        otherwise pick the one with highest Q-value.

        Args:
            state: Current workflow state (satisfied + available APs).

        Returns:
            Index into the action pair pool.
        """
        state_idx = self.encode_state(state)
        valid_indices = self._valid_action_indices(state)

        if not valid_indices:
            # No valid actions — return 0 as fallback
            return 0

        if np.random.random() < self.epsilon:
            return int(np.random.choice(valid_indices))
        else:
            # Greedy among valid actions
            q_values = self.Q[state_idx]
            best_idx = valid_indices[0]
            best_q = q_values[best_idx]
            for idx in valid_indices[1:]:
                if q_values[idx] > best_q:
                    best_q = q_values[idx]
                    best_idx = idx
            return best_idx

    # -- TrainablePolicyInterface (training) --

    def encode_state(self, state: State) -> int:
        """Encode State into a bitmask integer.

        Layout (LSB to MSB):
          bits [0..N-1]  : satisfied AP bitmask (one bit per AP)
          bit  [N]       : backtrack_active flag
          bits [N+1..N+2]: strategy_recommendation (2 bits, 0-3)

        With N APs, the state index is in [0, 2^(N+3)).

        Args:
            state: Current workflow state.

        Returns:
            Integer bitmask encoding satisfied + backtrack + strategy.
        """
        bitmask = 0
        for ap_id in state.satisfied:
            bit = self._id_to_bit.get(ap_id)
            if bit is not None:
                bitmask |= 1 << bit
        if state.backtrack_active:
            bitmask |= 1 << self._num_action_pairs
        # Encode 2 strategy bits above the backtrack bit
        bitmask |= (state.strategy_recommendation & 0x3) << (self._num_action_pairs + 1)
        return int(bitmask % self._num_states)

    def get_max_q_value(self, state_idx: int) -> float:
        """Return the maximum Q-value for a given state."""
        return float(np.max(self.Q[state_idx]))

    def update(self, state_idx: int, action_idx: int, td_target: float) -> None:
        """Update Q-value for a (state, action) pair.

        Q(s,a) <- Q(s,a) + alpha * (td_target - Q(s,a))

        Args:
            state_idx: Bitmask state index.
            action_idx: Action pair index.
            td_target: The TD target value (R + gamma * max_Q(s')).
        """
        self.Q[state_idx, action_idx] += self.alpha * (
            td_target - self.Q[state_idx, action_idx]
        )
        self.visit_count[state_idx, action_idx] += 1

    def set_exploration(self, enabled: bool) -> None:
        """Toggle exploration on or off.

        Args:
            enabled: True for exploration mode, False for greedy mode.
        """
        if enabled:
            self.epsilon = self._base_epsilon
        else:
            self._base_epsilon = self.epsilon
            self.epsilon = 0.0

    def get_exploration_rate(self) -> float:
        """Return current exploration rate."""
        return self.epsilon

    # -- Utility --

    def greedy_action(self, state_idx: int) -> int:
        """Return the action index with highest Q-value for a state."""
        return int(np.argmax(self.Q[state_idx]))

    def _valid_action_indices(self, state: State) -> list[int]:
        """Return indices of APs that are available for selection.

        Includes both normal APs (available and not satisfied) and
        backtracking targets (available AND satisfied, added by the
        environment when an AP exhausts its retries).
        """
        valid = []
        for i, ap_id in enumerate(self._ap_ids):
            if ap_id in state.available:
                valid.append(i)
        return valid

    def decay_epsilon(self, decay_rate: float, min_epsilon: float = 0.01) -> None:
        """Decay exploration rate multiplicatively.

        ``epsilon *= decay_rate``, floored at ``min_epsilon``.

        Args:
            decay_rate: Multiplicative decay factor (e.g. 0.995).
            min_epsilon: Minimum exploration rate.
        """
        self.epsilon = max(self.epsilon * decay_rate, min_epsilon)
        self._base_epsilon = self.epsilon

    def save(self, path: Path) -> None:
        """Save Q-table, visit counts, and epsilon to .npz file.

        Args:
            path: Directory to save into.
        """
        path.mkdir(parents=True, exist_ok=True)
        np.savez(
            path / "qtable.npz",
            Q=self.Q,
            visit_count=self.visit_count,
            ap_ids=np.array(self._ap_ids),
            epsilon=np.array(self.epsilon),
        )

    def load(self, path: Path) -> None:
        """Load Q-table, visit counts, and epsilon from .npz file.

        Handles backwards compatibility: old checkpoints with 2^N states
        are expanded to 2^(N+1) states by zero-filling the backtrack-active
        half of the Q-table.

        Args:
            path: Path to checkpoint directory or .npz file.
        """
        npz_path = path / "qtable.npz" if path.is_dir() else path
        data = np.load(npz_path, allow_pickle=True)
        loaded_q = data["Q"]
        loaded_vc = data["visit_count"]
        if "ap_ids" in data:
            self._ap_ids = tuple(str(x) for x in data["ap_ids"])
            self._id_to_bit = {ap_id: i for i, ap_id in enumerate(self._ap_ids)}
            self._num_action_pairs = len(self._ap_ids)
        self._num_actions = loaded_q.shape[1]
        expected_states = 2 ** (self._num_action_pairs + 3)

        if loaded_q.shape[0] < expected_states:
            # Old checkpoint with fewer state bits — expand (zero-fill)
            self.Q = np.zeros((expected_states, self._num_actions), dtype=np.float64)
            self.Q[: loaded_q.shape[0]] = loaded_q
            self.visit_count = np.zeros(
                (expected_states, self._num_actions), dtype=np.int64
            )
            self.visit_count[: loaded_vc.shape[0]] = loaded_vc
        else:
            self.Q = loaded_q
            self.visit_count = loaded_vc

        self._num_states = self.Q.shape[0]

        if "epsilon" in data:
            self.epsilon = float(data["epsilon"])
            self._base_epsilon = self.epsilon
