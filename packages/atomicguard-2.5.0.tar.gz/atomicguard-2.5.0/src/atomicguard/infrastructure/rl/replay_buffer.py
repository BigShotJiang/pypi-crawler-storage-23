"""
Experience replay buffer for RL training.

Stores (state, action, reward, next_state) transitions via the
Transition dataclass for off-policy training algorithms.
"""

from __future__ import annotations

import random

from atomicguard.domain.interfaces import ExperienceBufferInterface
from atomicguard.domain.rl.transitions import Transition

# Re-export Transition for backward compatibility
__all__ = ["ReplayBuffer", "Transition"]


class ReplayBuffer(ExperienceBufferInterface):
    """Fixed-size circular buffer for experience storage.

    Supports uniform random sampling for training batches.
    Implements ExperienceBufferInterface domain port.
    """

    def __init__(self, capacity: int = 10_000) -> None:
        """
        Args:
            capacity: Maximum number of transitions to store.
        """
        self._capacity = capacity
        self._buffer: list[Transition] = []
        self._position = 0

    def push(self, transition: Transition) -> None:
        """Store a transition in the buffer.

        Args:
            transition: Experience tuple to store.
        """
        if len(self._buffer) < self._capacity:
            self._buffer.append(transition)
        else:
            self._buffer[self._position] = transition
        self._position = (self._position + 1) % self._capacity

    def sample(self, batch_size: int) -> list[Transition]:
        """Sample a random batch of transitions.

        Args:
            batch_size: Number of transitions to sample.

        Returns:
            List of randomly sampled transitions.

        Raises:
            ValueError: If batch_size exceeds buffer size.
        """
        if batch_size > len(self._buffer):
            raise ValueError(
                f"Cannot sample {batch_size} from buffer of size {len(self._buffer)}"
            )
        indices = random.sample(range(len(self._buffer)), batch_size)
        return [self._buffer[i] for i in indices]

    def __len__(self) -> int:
        return len(self._buffer)
