"""Packaged Projection schema resources for gtaf_runtime."""
