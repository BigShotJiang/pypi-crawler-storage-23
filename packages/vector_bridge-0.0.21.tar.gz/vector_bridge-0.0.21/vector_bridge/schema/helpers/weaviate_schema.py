from pydantic import BaseModel, Field
from weaviate.classes.config import DataType, Tokenization


class Sorting(BaseModel):
    supported: bool = Field(default=False)


class Property(BaseModel):
    name: str
    description: str
    data_type: DataType | str  # Object is not supported
    tokenization: Tokenization = Field(default=Tokenization.WORD)
    sorting: Sorting = Field(default_factory=Sorting)
    returned: bool = Field(default=False)
    index_filterable: bool = Field(default=False)
    index_searchable: bool = Field(default=False)
    index_range: bool = Field(default=False)


class Schema(BaseModel):
    name: str
    description: str
    properties: list[Property] = Field(default_factory=list)
    deleted_properties: list[Property] = Field(default_factory=list)
    vectorizer: str = Field(default="text2vec-openai")
    shards: int = Field(default=1)
    vectors: dict[str, list[str]] = Field(default_factory=lambda: {"default": ["content"]})
    vectorize_collection_name: bool = Field(default=True)

    def get_property_by_name(self, name: str):
        for _property in self.properties:
            if _property.name == name:
                return _property
        return None


class WeaviateInternals(BaseModel):
    schemas: list[Schema] = Field(default_factory=list)
    other: dict = Field(default_factory=dict)

    def get_schema_by_name(self, name: str):
        for schema in self.schemas:
            if schema.name == name:
                return schema
