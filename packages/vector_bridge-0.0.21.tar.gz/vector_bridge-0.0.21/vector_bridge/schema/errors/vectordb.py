class VectorDBError(Exception):
    """Base class for VectorDB-related errors."""


def raise_for_vectordb_detail(detail: str) -> None:
    """
    Raises the corresponding VectorDBError based on the given error detail string.
    """
    raise VectorDBError(detail)
