"""Tests for the Ollama/remote API client module."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import httpx

from natshell.inference.ollama import (
    _get_running_context,
    _model_matches,
    ensure_model_context,
    get_model_context_length,
    list_models,
    normalize_base_url,
    ping_server,
)

# ─── normalize_base_url ─────────────────────────────────────────────────────


class TestNormalizeBaseUrl:
    def test_strips_v1_suffix(self):
        assert normalize_base_url("http://localhost:11434/v1") == "http://localhost:11434"

    def test_strips_v1_with_trailing_slash(self):
        assert normalize_base_url("http://localhost:11434/v1/") == "http://localhost:11434"

    def test_no_v1_unchanged(self):
        assert normalize_base_url("http://localhost:11434") == "http://localhost:11434"

    def test_strips_trailing_slash(self):
        assert normalize_base_url("http://localhost:11434/") == "http://localhost:11434"

    def test_custom_host_and_port(self):
        assert normalize_base_url("http://192.168.1.5:8080/v1") == "http://192.168.1.5:8080"

    def test_bare_url(self):
        assert normalize_base_url("http://myhost") == "http://myhost"


# ─── ping_server ────────────────────────────────────────────────────────────


class TestPingServer:
    async def test_success_ollama_running(self):
        mock_response = httpx.Response(200, text="Ollama is running")
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=mock_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ping_server("http://localhost:11434")
            assert result is True

    async def test_success_non_ollama_200(self):
        mock_response = httpx.Response(200, text="OK")
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=mock_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ping_server("http://localhost:8080")
            assert result is True

    async def test_connection_failure(self):
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(side_effect=httpx.ConnectError("connection refused"))
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ping_server("http://badhost:11434")
            assert result is False

    async def test_strips_v1_before_ping(self):
        mock_response = httpx.Response(200, text="Ollama is running")
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=mock_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ping_server("http://localhost:11434/v1")
            assert result is True
            # Should have pinged the root, not /v1/
            instance.get.assert_called_with("http://localhost:11434/")


# ─── list_models ────────────────────────────────────────────────────────────


class TestListModels:
    async def test_ollama_api_tags(self):
        """list_models parses Ollama /api/tags response."""
        ollama_response = httpx.Response(
            200,
            json={
                "models": [
                    {
                        "name": "qwen3:4b",
                        "size": 2684354560,
                        "details": {"parameter_size": "4B", "family": "qwen3"},
                    },
                    {
                        "name": "llama3:8b",
                        "size": 5368709120,
                        "details": {"parameter_size": "8B", "family": "llama"},
                    },
                ]
            },
        )

        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=ollama_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            models = await list_models("http://localhost:11434")

        assert len(models) == 2
        assert models[0].name == "qwen3:4b"
        assert models[0].size_gb == 2.5
        assert models[0].parameter_size == "4B"
        assert models[1].name == "llama3:8b"

    async def test_openai_v1_models_fallback(self):
        """list_models falls back to /v1/models when /api/tags fails."""
        tags_404 = httpx.Response(404, text="Not Found")
        openai_response = httpx.Response(
            200,
            json={
                "data": [
                    {"id": "gpt-4"},
                    {"id": "gpt-3.5-turbo"},
                ]
            },
        )

        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(side_effect=[tags_404, openai_response])
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            models = await list_models("http://localhost:8080")

        assert len(models) == 2
        assert models[0].name == "gpt-4"
        assert models[1].name == "gpt-3.5-turbo"

    async def test_connection_failure_returns_empty(self):
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.__aenter__ = AsyncMock(side_effect=httpx.ConnectError("refused"))
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            models = await list_models("http://badhost:11434")
            assert models == []


# ─── ensure_model_context ──────────────────────────────────────────────────


class TestEnsureModelContext:
    async def test_already_loaded_at_sufficient_context(self):
        """Returns True immediately when model is loaded with enough context."""
        with patch(
            "natshell.inference.ollama._get_running_context",
            new_callable=AsyncMock,
            return_value=131072,
        ):
            result = await ensure_model_context(
                "http://localhost:11434", "qwen3:4b", 131072
            )
            assert result is True

    async def test_already_loaded_at_larger_context(self):
        """Returns True when loaded context exceeds requested."""
        with patch(
            "natshell.inference.ollama._get_running_context",
            new_callable=AsyncMock,
            return_value=262144,
        ):
            result = await ensure_model_context(
                "http://localhost:11434", "qwen3:4b", 131072
            )
            assert result is True

    async def test_preloads_when_context_too_small(self):
        """Sends /api/generate with num_ctx when loaded context is insufficient."""
        generate_response = httpx.Response(200, json={"done": True})
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=32768,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=generate_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ensure_model_context(
                "http://localhost:11434", "qwen3:4b", 131072
            )
            assert result is True
            instance.post.assert_called_once()
            call_args = instance.post.call_args
            assert call_args[1]["json"]["options"]["num_ctx"] == 131072

    async def test_preloads_when_model_not_loaded(self):
        """Sends preload when model is not loaded at all."""
        generate_response = httpx.Response(200, json={"done": True})
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=generate_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ensure_model_context(
                "http://localhost:11434", "qwen3:4b", 65536
            )
            assert result is True

    async def test_returns_false_on_connection_failure(self):
        """Returns False when server is unreachable."""
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.__aenter__ = AsyncMock(
                side_effect=httpx.ConnectError("refused")
            )
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ensure_model_context(
                "http://badhost:11434", "qwen3:4b", 131072
            )
            assert result is False

    async def test_returns_false_on_non_200(self):
        """Returns False when server returns an error."""
        error_response = httpx.Response(500, text="Internal Server Error")
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=error_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await ensure_model_context(
                "http://localhost:11434", "qwen3:4b", 131072
            )
            assert result is False

    async def test_strips_v1_from_url(self):
        """URL with /v1 suffix is normalized before calling Ollama API."""
        with patch(
            "natshell.inference.ollama._get_running_context",
            new_callable=AsyncMock,
            return_value=131072,
        ) as mock_ctx:
            await ensure_model_context(
                "http://localhost:11434/v1", "qwen3:4b", 131072
            )
            # _get_running_context should receive the normalized URL
            mock_ctx.assert_called_with("http://localhost:11434", "qwen3:4b")


# ─── _model_matches ─────────────────────────────────────────────────────────


class TestModelMatches:
    def test_exact_match_name(self):
        assert _model_matches("qwen3:4b", "qwen3:4b", "qwen3:4b") is True

    def test_exact_match_model_field(self):
        assert _model_matches("qwen3:4b", "other", "qwen3:4b") is True

    def test_no_match(self):
        assert _model_matches("qwen3:4b", "llama3:8b", "llama3:8b") is False

    def test_implicit_latest_tag(self):
        """Query without tag matches entry with :latest."""
        assert _model_matches("qwen3", "qwen3:latest", "qwen3:latest") is True

    def test_implicit_latest_no_false_positive(self):
        """Query without tag should not match a different tag."""
        assert _model_matches("qwen3", "qwen3:4b", "qwen3:4b") is False


# ─── _get_running_context ───────────────────────────────────────────────────


class TestGetRunningContext:
    async def test_model_loaded_returns_context_length(self):
        """Returns context_length when model is loaded in /api/ps."""
        ps_response = httpx.Response(
            200,
            json={
                "models": [
                    {
                        "name": "qwen3:4b",
                        "model": "qwen3:4b",
                        "context_length": 32768,
                        "size_vram": 2684354560,
                    }
                ]
            },
        )
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=ps_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await _get_running_context("http://localhost:11434", "qwen3:4b")
            assert result == 32768

    async def test_model_not_loaded_returns_none(self):
        """Returns None when model is not in /api/ps results."""
        ps_response = httpx.Response(
            200,
            json={
                "models": [
                    {
                        "name": "llama3:8b",
                        "model": "llama3:8b",
                        "context_length": 8192,
                    }
                ]
            },
        )
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=ps_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await _get_running_context("http://localhost:11434", "qwen3:4b")
            assert result is None

    async def test_non_ollama_server_returns_none(self):
        """Non-Ollama server (404 on /api/ps) returns None."""
        ps_response = httpx.Response(404, text="Not Found")
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=ps_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await _get_running_context("http://localhost:8080", "gpt-4")
            assert result is None

    async def test_connection_failure_returns_none(self):
        """Connection failure returns None."""
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.__aenter__ = AsyncMock(side_effect=httpx.ConnectError("refused"))
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await _get_running_context("http://badhost:11434", "qwen3:4b")
            assert result is None

    async def test_empty_models_returns_none(self):
        """Empty models list returns None."""
        ps_response = httpx.Response(200, json={"models": []})
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=ps_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await _get_running_context("http://localhost:11434", "qwen3:4b")
            assert result is None

    async def test_implicit_latest_tag_match(self):
        """Query "qwen3" matches entry with name "qwen3:latest"."""
        ps_response = httpx.Response(
            200,
            json={
                "models": [
                    {
                        "name": "qwen3:latest",
                        "model": "qwen3:latest",
                        "context_length": 4096,
                    }
                ]
            },
        )
        with patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=ps_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await _get_running_context("http://localhost:11434", "qwen3")
            assert result == 4096


# ─── get_model_context_length ────────────────────────────────────────────────


class TestGetModelContextLength:
    async def test_prefers_api_ps_over_api_show(self):
        """When model is running, uses /api/ps context instead of /api/show metadata."""
        with patch(
            "natshell.inference.ollama._get_running_context",
            new_callable=AsyncMock,
            return_value=32768,
        ):
            result = await get_model_context_length("http://localhost:11434", "qwen3:4b")
            assert result == 32768

    async def test_falls_back_to_api_show_when_not_running(self):
        """When model is not in /api/ps, falls back to /api/show metadata."""
        show_response = httpx.Response(
            200,
            json={"model_info": {"qwen2.context_length": 262144}},
        )
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=show_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://localhost:11434", "qwen3:4b")
            assert result == 262144

    async def test_returns_context_length_from_model_info(self):
        """Successful /api/show query returns context length from architecture-prefixed key."""
        show_response = httpx.Response(
            200,
            json={
                "model_info": {
                    "general.architecture": "qwen2",
                    "qwen2.context_length": 32768,
                    "qwen2.embedding_length": 3584,
                }
            },
        )
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=show_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://localhost:11434", "qwen3:32b")
            assert result == 32768

    async def test_returns_llama_context_length(self):
        """Works with llama architecture prefix."""
        show_response = httpx.Response(
            200,
            json={
                "model_info": {
                    "general.architecture": "llama",
                    "llama.context_length": 8192,
                }
            },
        )
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=show_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://localhost:11434", "llama3:8b")
            assert result == 8192

    async def test_non_ollama_server_returns_zero(self):
        """Non-Ollama server (404 on both endpoints) returns 0."""
        show_response = httpx.Response(404, text="Not Found")
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=show_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://localhost:8080", "gpt-4")
            assert result == 0

    async def test_connection_failure_returns_zero(self):
        """Connection failure returns 0."""
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.__aenter__ = AsyncMock(side_effect=httpx.ConnectError("refused"))
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://badhost:11434", "qwen3:4b")
            assert result == 0

    async def test_missing_model_info_returns_zero(self):
        """Response without model_info key returns 0."""
        show_response = httpx.Response(
            200,
            json={
                "license": "apache-2.0",
                "modelfile": "FROM qwen3:4b",
            },
        )
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=show_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://localhost:11434", "qwen3:4b")
            assert result == 0

    async def test_strips_v1_from_url(self):
        """URL with /v1 suffix is normalized before querying."""
        show_response = httpx.Response(200, json={"model_info": {"qwen2.context_length": 4096}})
        with (
            patch(
                "natshell.inference.ollama._get_running_context",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch("natshell.inference.ollama.httpx.AsyncClient") as MockClient,
        ):
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=show_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            result = await get_model_context_length("http://localhost:11434/v1", "qwen3:4b")
            assert result == 4096
            # Should have posted to the normalized URL
            instance.post.assert_called_with(
                "http://localhost:11434/api/show",
                json={"model": "qwen3:4b"},
            )


# ─── OllamaEngine uses native /api/chat with num_ctx ─────────────────────────


class TestOllamaEngine:
    def _make_ollama_response(self):
        return httpx.Response(
            200,
            json={
                "message": {"role": "assistant", "content": "hi"},
                "done": True,
                "done_reason": "stop",
                "prompt_eval_count": 10,
                "eval_count": 5,
            },
            request=httpx.Request("POST", "http://localhost:11434/api/chat"),
        )

    def _make_ollama_tool_response(self):
        return httpx.Response(
            200,
            json={
                "message": {
                    "role": "assistant",
                    "content": "",
                    "tool_calls": [
                        {
                            "function": {
                                "name": "execute_shell",
                                "arguments": {"command": "ls -la"},
                            }
                        }
                    ],
                },
                "done": True,
                "done_reason": "stop",
                "prompt_eval_count": 20,
                "eval_count": 15,
            },
            request=httpx.Request("POST", "http://localhost:11434/api/chat"),
        )

    async def test_uses_native_api_url(self):
        """OllamaEngine sends requests to /api/chat, not /v1/chat/completions."""
        from natshell.inference.ollama_engine import OllamaEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test", n_ctx=131072)
        engine.client.post = AsyncMock(return_value=self._make_ollama_response())
        await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        call_args = engine.client.post.call_args
        url = call_args[0][0] if call_args[0] else call_args[1].get("url", "")
        assert url == "http://localhost:11434/api/chat"
        await engine.close()

    async def test_includes_num_ctx_in_options(self):
        """OllamaEngine includes num_ctx in options for every request."""
        from natshell.inference.ollama_engine import OllamaEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test", n_ctx=131072)
        engine.client.post = AsyncMock(return_value=self._make_ollama_response())
        await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        call_kwargs = engine.client.post.call_args
        payload = call_kwargs[1]["json"] if "json" in call_kwargs[1] else call_kwargs[0][1]
        assert payload["options"]["num_ctx"] == 131072
        await engine.close()

    async def test_maps_temperature_and_max_tokens(self):
        """OllamaEngine maps temperature and max_tokens to options."""
        from natshell.inference.ollama_engine import OllamaEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test", n_ctx=0)
        engine.client.post = AsyncMock(return_value=self._make_ollama_response())
        await engine.chat_completion(
            messages=[{"role": "user", "content": "hi"}],
            temperature=0.7,
            max_tokens=4096,
        )

        call_kwargs = engine.client.post.call_args
        payload = call_kwargs[1]["json"]
        assert payload["options"]["temperature"] == 0.7
        assert payload["options"]["num_predict"] == 4096
        # temperature and max_tokens should not be top-level
        assert "temperature" not in payload
        assert "max_tokens" not in payload
        await engine.close()

    async def test_omits_num_ctx_when_zero(self):
        """OllamaEngine omits num_ctx from options when n_ctx=0."""
        from natshell.inference.ollama_engine import OllamaEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test", n_ctx=0)
        engine.client.post = AsyncMock(return_value=self._make_ollama_response())
        await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        call_kwargs = engine.client.post.call_args
        payload = call_kwargs[1]["json"]
        assert "num_ctx" not in payload["options"]
        await engine.close()

    async def test_parses_text_response(self):
        """OllamaEngine parses text content from native response."""
        from natshell.inference.ollama_engine import OllamaEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test")
        engine.client.post = AsyncMock(return_value=self._make_ollama_response())
        result = await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        assert result.content == "hi"
        assert result.tool_calls == []
        assert result.finish_reason == "stop"
        assert result.prompt_tokens == 10
        assert result.completion_tokens == 5
        await engine.close()

    async def test_parses_tool_call_response(self):
        """OllamaEngine parses tool calls with dict arguments."""
        from natshell.inference.ollama_engine import OllamaEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test")
        engine.client.post = AsyncMock(return_value=self._make_ollama_tool_response())
        result = await engine.chat_completion(messages=[{"role": "user", "content": "list files"}])

        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "execute_shell"
        assert result.tool_calls[0].arguments == {"command": "ls -la"}
        assert result.prompt_tokens == 20
        assert result.completion_tokens == 15
        await engine.close()

    async def test_strips_think_tags(self):
        """OllamaEngine strips <think> tags from Qwen3 output."""
        from natshell.inference.ollama_engine import OllamaEngine

        response = httpx.Response(
            200,
            json={
                "message": {
                    "role": "assistant",
                    "content": "<think>reasoning here</think>The answer is 42.",
                },
                "done": True,
                "done_reason": "stop",
            },
            request=httpx.Request("POST", "http://localhost:11434/api/chat"),
        )
        engine = OllamaEngine(base_url="http://localhost:11434", model="test")
        engine.client.post = AsyncMock(return_value=response)
        result = await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        assert result.content == "The answer is 42."
        await engine.close()

    async def test_is_subclass_of_remote_engine(self):
        """OllamaEngine is a RemoteEngine subclass (fallback detection works)."""
        from natshell.inference.ollama_engine import OllamaEngine
        from natshell.inference.remote import RemoteEngine

        engine = OllamaEngine(base_url="http://localhost:11434", model="test")
        assert isinstance(engine, RemoteEngine)
        await engine.close()


# ─── RemoteEngine (OpenAI-compatible) does NOT include options ────────────────


class TestRemoteEngineNoOptions:
    def _make_chat_response(self):
        return httpx.Response(
            200,
            json={
                "choices": [{"message": {"content": "hi"}, "finish_reason": "stop"}],
                "usage": {},
            },
            request=httpx.Request("POST", "http://localhost:11434/v1/chat/completions"),
        )

    async def test_no_options_in_payload(self):
        """RemoteEngine does not include options in OpenAI-format payload."""
        from natshell.inference.remote import RemoteEngine

        engine = RemoteEngine(base_url="http://localhost:11434/v1", model="test", n_ctx=131072)
        engine.client.post = AsyncMock(return_value=self._make_chat_response())
        await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        call_kwargs = engine.client.post.call_args
        payload = call_kwargs[1]["json"]
        assert "options" not in payload
        await engine.close()

    async def test_uses_v1_url(self):
        """RemoteEngine sends requests to /chat/completions under base_url."""
        from natshell.inference.remote import RemoteEngine

        engine = RemoteEngine(base_url="http://localhost:11434/v1", model="test")
        engine.client.post = AsyncMock(return_value=self._make_chat_response())
        await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])

        call_args = engine.client.post.call_args
        url = call_args[0][0]
        assert url == "http://localhost:11434/v1/chat/completions"
        await engine.close()


# ─── ContextOverflowError detection in RemoteEngine ──────────────────────────


class TestContextOverflowDetection:
    async def test_400_context_length_raises_overflow(self):
        """HTTP 400 with context-length body raises ContextOverflowError."""
        from natshell.inference.remote import ContextOverflowError, RemoteEngine

        engine = RemoteEngine(base_url="http://localhost:11434", model="test")
        mock_response = httpx.Response(
            status_code=400,
            text="model requires more context length",
            request=httpx.Request("POST", "http://localhost:11434/chat/completions"),
        )
        engine.client.post = AsyncMock(
            side_effect=httpx.HTTPStatusError(
                "bad request", request=mock_response.request, response=mock_response
            )
        )
        try:
            await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])
            assert False, "Should have raised"
        except ContextOverflowError as e:
            assert "context" in str(e).lower()
        finally:
            await engine.close()

    async def test_413_raises_overflow(self):
        """HTTP 413 with known pattern raises ContextOverflowError."""
        from natshell.inference.remote import ContextOverflowError, RemoteEngine

        engine = RemoteEngine(base_url="http://localhost:11434", model="test")
        mock_response = httpx.Response(
            status_code=413,
            text="request too large: prompt exceeds token limit",
            request=httpx.Request("POST", "http://localhost:11434/chat/completions"),
        )
        engine.client.post = AsyncMock(
            side_effect=httpx.HTTPStatusError(
                "too large", request=mock_response.request, response=mock_response
            )
        )
        try:
            await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])
            assert False, "Should have raised"
        except ContextOverflowError as e:
            assert "token limit" in str(e).lower() or "request too large" in str(e).lower()
        finally:
            await engine.close()

    async def test_400_non_context_raises_connection_error(self):
        """HTTP 400 with unrelated body raises regular ConnectionError."""
        from natshell.inference.remote import ContextOverflowError, RemoteEngine

        engine = RemoteEngine(base_url="http://localhost:11434", model="test")
        mock_response = httpx.Response(
            status_code=400,
            text="invalid model format",
            request=httpx.Request("POST", "http://localhost:11434/chat/completions"),
        )
        engine.client.post = AsyncMock(
            side_effect=httpx.HTTPStatusError(
                "bad request", request=mock_response.request, response=mock_response
            )
        )
        try:
            await engine.chat_completion(messages=[{"role": "user", "content": "hi"}])
            assert False, "Should have raised"
        except ContextOverflowError:
            assert False, "Should not be ContextOverflowError"
        except ConnectionError as e:
            assert "400" in str(e)
        finally:
            await engine.close()
