"""Ollama-native inference backend — uses /api/chat with options.num_ctx.

Unlike RemoteEngine (which uses the OpenAI-compatible /v1/chat/completions
endpoint), this engine talks directly to Ollama's native API.  The key
advantage is that /api/chat supports ``options.num_ctx`` in every request,
ensuring the model stays loaded at the configured context window size.
Ollama's /v1 endpoint silently ignores this field, causing the model to
reload at its default (usually 2048 or 32768) context.
"""

from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Any

from natshell.inference.engine import CompletionResult, ToolCall
from natshell.inference.remote import RemoteEngine

logger = logging.getLogger(__name__)


class OllamaEngine(RemoteEngine):
    """LLM inference via Ollama's native /api/chat endpoint.

    Subclasses RemoteEngine to reuse the retry logic, httpx client management,
    and engine_info/close methods.  Overrides payload construction, URL, and
    response parsing for Ollama's native format.
    """

    def _build_payload(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        """Build an Ollama-native /api/chat payload."""
        options: dict[str, Any] = {
            "temperature": temperature,
            "num_predict": max_tokens,
        }
        if self.n_ctx > 0:
            options["num_ctx"] = self.n_ctx

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": options,
        }
        if tools:
            payload["tools"] = tools
        return payload

    def _get_url(self) -> str:
        """Return the Ollama native chat URL."""
        return f"{self.base_url}/api/chat"

    def _parse_response(self, data: dict) -> CompletionResult:
        """Parse Ollama-native /api/chat response.

        Key differences from OpenAI format:
        - Top-level ``message`` instead of ``choices[0].message``
        - ``done_reason`` instead of ``finish_reason``
        - ``tool_calls[].function.arguments`` is a dict, not a JSON string
        - Token counts: ``prompt_eval_count`` / ``eval_count``
        """
        message = data.get("message", {})
        content = message.get("content")
        tool_calls: list[ToolCall] = []

        if message.get("tool_calls"):
            for tc in message["tool_calls"]:
                func = tc.get("function", {})
                args = func.get("arguments", {})
                # Ollama returns arguments as a dict, but handle string just in case
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}

                tool_calls.append(
                    ToolCall(
                        id=str(uuid.uuid4())[:8],
                        name=func.get("name", ""),
                        arguments=args,
                    )
                )

        # Strip <think> tags from content (Qwen3 models produce these)
        if content:
            content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip() or None

        finish_reason = data.get("done_reason", "stop")
        return CompletionResult(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            prompt_tokens=data.get("prompt_eval_count", 0),
            completion_tokens=data.get("eval_count", 0),
        )
