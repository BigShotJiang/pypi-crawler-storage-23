"""Core orchestration logic."""

from __future__ import annotations

import os
from pathlib import Path

from pbr.phases import PHASE_ORDER, get_context_files, get_default_template
from pbr.state import PBRState, detect_stale, advance_phase


def determine_next_phase(state: PBRState) -> str | None:
    """Returns the next phase to run, or None if pipeline is done."""
    # Check for stale running phase
    stale = detect_stale(state)
    if stale:
        retries = state.config.get("retries", 1)
        pr = state.phases[stale]
        if pr.attempt <= retries:
            # Can retry
            state = advance_phase(state, stale, "failed", error="Stale: exceeded 2x timeout")
            return stale
        else:
            state = advance_phase(state, stale, "failed", error="Stale: exceeded 2x timeout, no retries left")
            return None

    # If something is currently running, don't advance
    if state.current_phase is not None:
        return state.current_phase

    for phase in PHASE_ORDER:
        pr = state.phases[phase]
        if pr.status == "pending":
            return phase
        if pr.status == "failed":
            retries = state.config.get("retries", 1)
            if pr.attempt <= retries:
                return phase
            # Failed with no retries left - halt
            return None
        if pr.status in ("completed", "skipped"):
            continue
        if pr.status == "running":
            return phase

    return None  # All done


def build_phase_prompt(
    state: PBRState,
    phase: str,
    workspace: Path,
    custom_prompt: str | None = None,
) -> str:
    """Assemble the full prompt for a phase with context injected."""
    template = custom_prompt or get_default_template(phase)
    context = get_context_files(phase, workspace)

    # Build substitutions
    cwd = os.getcwd()
    plan_content = context.get("PLAN.md", "(No plan found)")

    # Build file listing for review
    file_listing = ""
    for fname, content in sorted(context.items()):
        if fname != "PLAN.md":
            file_listing += f"\n### {fname}\n```python\n{content}\n```\n"

    prompt = template
    prompt = prompt.replace("{{task}}", state.task)
    prompt = prompt.replace("{{workspace}}", str(workspace))
    prompt = prompt.replace("{{cwd}}", cwd)
    prompt = prompt.replace("{{plan_content}}", plan_content)
    prompt = prompt.replace("{{file_listing}}", file_listing or "(No implementation files found)")

    return prompt


def collect_artifacts(workspace: Path, phase: str) -> list[str]:
    """Scan workspace for artifacts from a phase."""
    artifacts: list[str] = []
    if phase == "plan":
        plan = workspace / "PLAN.md"
        if plan.exists():
            artifacts.append("PLAN.md")
    elif phase == "build":
        for f in workspace.rglob("*.py"):
            rel = f.relative_to(workspace)
            parts = rel.parts
            if any(p.startswith(".") or p == "__pycache__" for p in parts):
                continue
            artifacts.append(str(rel))
    elif phase == "review":
        review = workspace / "REVIEW.md"
        if review.exists():
            artifacts.append("REVIEW.md")
    return sorted(artifacts)


def generate_report(state: PBRState, workspace: Path) -> str:
    """Generate a summary report of the pipeline."""
    lines = ["# PBR Pipeline Report", f"**Task:** {state.task}", f"**Workspace:** {state.workspace}", ""]

    all_success = True
    total_duration = 0.0

    for phase in PHASE_ORDER:
        pr = state.phases[phase]
        status_icon = {"completed": "✅", "failed": "❌", "skipped": "⏭️", "pending": "⏳", "running": "🔄"}.get(pr.status, "?")
        lines.append(f"## {phase.capitalize()} {status_icon} {pr.status}")
        if pr.duration_seconds is not None:
            lines.append(f"  Duration: {pr.duration_seconds:.1f}s")
            total_duration += pr.duration_seconds
        if pr.artifacts:
            lines.append(f"  Artifacts: {', '.join(pr.artifacts)}")
        if pr.error:
            lines.append(f"  Error: {pr.error}")
            all_success = False
        if pr.status == "failed":
            all_success = False
        lines.append("")

    lines.append(f"**Total duration:** {total_duration:.1f}s")
    lines.append(f"**Result:** {'✅ Success' if all_success else '❌ Partial/Failed'}")

    return "\n".join(lines)
