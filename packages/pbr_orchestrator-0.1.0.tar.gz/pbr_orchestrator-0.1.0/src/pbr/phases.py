"""Phase definitions and prompt templates."""

from __future__ import annotations

from pathlib import Path

PHASE_ORDER: list[str] = ["plan", "build", "review"]

TEMPLATES_DIR = Path(__file__).parent / "templates"

DEFAULT_MODELS = {
    "plan": "anthropic/claude-opus-4-6",
    "build": "anthropic/claude-sonnet-4-6",
    "review": "anthropic/claude-sonnet-4-6",
}


def get_model_for_phase(phase: str, config: dict) -> str:
    """Get the model to use for a given phase."""
    models = config.get("models", {})
    return models.get(phase, DEFAULT_MODELS.get(phase, "anthropic/claude-sonnet-4-6"))


def get_default_template(phase: str) -> str:
    """Read the default template for a phase."""
    template_file = TEMPLATES_DIR / f"{phase_to_template_name(phase)}.md"
    if template_file.exists():
        return template_file.read_text()
    # Fallback inline templates
    return _fallback_template(phase)


def phase_to_template_name(phase: str) -> str:
    """Map phase name to template filename."""
    mapping = {"plan": "planner", "build": "builder", "review": "reviewer"}
    return mapping.get(phase, phase)


def get_context_files(phase: str, workspace: Path) -> dict[str, str]:
    """Return {filename: content} of context files for a phase."""
    context: dict[str, str] = {}

    if phase in ("build", "review"):
        plan_file = workspace / "PLAN.md"
        if plan_file.exists():
            context["PLAN.md"] = plan_file.read_text()

    if phase == "review":
        # Collect all Python files
        for py_file in sorted(workspace.rglob("*.py")):
            rel = py_file.relative_to(workspace)
            # Skip hidden dirs and __pycache__
            parts = rel.parts
            if any(p.startswith(".") or p == "__pycache__" for p in parts):
                continue
            try:
                context[str(rel)] = py_file.read_text()
            except OSError:
                pass

    return context


def _fallback_template(phase: str) -> str:
    if phase == "plan":
        return """## Planner: {{task}}

You are the Planner. Produce a detailed technical spec. Do NOT write code.

### Task
{{task}}

### Deliver
Write the plan to `{{workspace}}/PLAN.md` containing:
1. Architecture overview + data flow
2. File structure with exact function signatures
3. Interface definitions (API, CLI, config)
4. Data models and schemas
5. Error handling strategy
6. Test plan
7. Constraints and assumptions

Be specific. The Builder will implement exactly what you specify.
Working directory: {{cwd}}"""
    elif phase == "build":
        return """## Builder: {{task}}

You are the Builder. Implement the plan below. Write production-quality code.

### Task
{{task}}

### Plan
{{plan_content}}

### Rules
- Follow the plan exactly — file structure, function signatures, types
- Write tests alongside implementation
- All code must be type-annotated
- Create pyproject.toml if needed
- Run tests before declaring done

Working directory: {{workspace}}"""
    else:  # review
        return """## Reviewer: {{task}}

You are the Reviewer. QA the implementation against the plan.

### Task
{{task}}

### Plan
{{plan_content}}

### Implementation Files
{{file_listing}}

### Review Checklist
1. Does the implementation match the plan?
2. Are all function signatures correct?
3. Are there tests? Do they pass?
4. Type annotations present and correct?
5. Edge cases handled?
6. Security issues?
7. Documentation present?

### Deliver
1. Run all tests, report results
2. Fix any bugs you find
3. Write `{{workspace}}/REVIEW.md`

Working directory: {{workspace}}"""
