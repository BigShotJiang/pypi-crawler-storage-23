"""State management for PBR pipeline."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pbr.phases import PHASE_ORDER

STATE_FILENAME = ".pbr-state.json"


@dataclass
class PhaseRecord:
    name: str
    status: str = "pending"  # pending | running | completed | failed | skipped
    started_at: str | None = None
    completed_at: str | None = None
    duration_seconds: float | None = None
    artifacts: list[str] = field(default_factory=list)
    attempt: int = 0
    error: str | None = None


@dataclass
class PBRState:
    task: str
    workspace: str
    created_at: str
    phases: dict[str, PhaseRecord]
    current_phase: str | None = None
    config: dict = field(default_factory=dict)
    version: int = 1


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_state(workspace: Path) -> PBRState | None:
    """Load state from workspace, returns None if not found."""
    state_file = workspace / STATE_FILENAME
    if not state_file.exists():
        return None
    try:
        data = json.loads(state_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    phases = {}
    for name, pdata in data.get("phases", {}).items():
        phases[name] = PhaseRecord(**pdata)

    return PBRState(
        task=data["task"],
        workspace=data["workspace"],
        created_at=data["created_at"],
        phases=phases,
        current_phase=data.get("current_phase"),
        config=data.get("config", {}),
        version=data.get("version", 1),
    )


def save_state(workspace: Path, state: PBRState) -> None:
    """Atomically save state to workspace."""
    state_file = workspace / STATE_FILENAME
    tmp_file = workspace / f"{STATE_FILENAME}.tmp"

    data = {
        "version": state.version,
        "task": state.task,
        "workspace": state.workspace,
        "created_at": state.created_at,
        "current_phase": state.current_phase,
        "config": state.config,
        "phases": {name: asdict(pr) for name, pr in state.phases.items()},
    }

    tmp_file.write_text(json.dumps(data, indent=2))
    os.replace(str(tmp_file), str(state_file))


def init_state(workspace: Path, task: str, **config: Any) -> PBRState:
    """Initialize a new pipeline state."""
    phases = {}
    for name in PHASE_ORDER:
        phases[name] = PhaseRecord(name=name)

    state = PBRState(
        task=task,
        workspace=str(workspace),
        created_at=_now_iso(),
        phases=phases,
        config=config,
    )

    save_state(workspace, state)
    return state


def advance_phase(
    state: PBRState,
    phase: str,
    status: str,
    *,
    artifacts: list[str] | None = None,
    error: str | None = None,
) -> PBRState:
    """Advance a phase to a new status."""
    pr = state.phases[phase]
    now = _now_iso()

    if status == "running":
        pr.status = "running"
        pr.started_at = now
        pr.attempt += 1
        pr.error = None
        state.current_phase = phase
    elif status == "completed":
        pr.status = "completed"
        pr.completed_at = now
        if pr.started_at:
            start = datetime.fromisoformat(pr.started_at)
            end = datetime.fromisoformat(now)
            pr.duration_seconds = (end - start).total_seconds()
        if artifacts:
            pr.artifacts = artifacts
        state.current_phase = None
    elif status == "failed":
        pr.status = "failed"
        pr.completed_at = now
        pr.error = error
        if pr.started_at:
            start = datetime.fromisoformat(pr.started_at)
            end = datetime.fromisoformat(now)
            pr.duration_seconds = (end - start).total_seconds()
        state.current_phase = None
    elif status == "skipped":
        pr.status = "skipped"
        state.current_phase = None

    return state


def detect_stale(state: PBRState) -> str | None:
    """Check if current running phase is stale (>2x timeout). Returns phase name or None."""
    if state.current_phase is None:
        return None

    pr = state.phases[state.current_phase]
    if pr.status != "running" or pr.started_at is None:
        return None

    timeout = state.config.get("timeout", 600)
    start = datetime.fromisoformat(pr.started_at)
    now = datetime.now(timezone.utc)
    elapsed = (now - start).total_seconds()

    if elapsed > 2 * timeout:
        return state.current_phase
    return None
