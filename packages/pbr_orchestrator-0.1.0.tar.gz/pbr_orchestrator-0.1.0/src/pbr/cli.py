"""CLI for PBR orchestrator."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pbr.state import load_state, save_state
from pbr.spawner import SpawnInstruction, DoneResult
from pbr.phases import PHASE_ORDER


def _output_json(obj: SpawnInstruction | DoneResult) -> None:
    """Print a spawn instruction or done result as JSON."""
    if isinstance(obj, SpawnInstruction):
        data = {"action": obj.action, "label": obj.label, "model": obj.model, "task": obj.task, "timeout_seconds": obj.timeout_seconds}
    else:
        data = {"action": obj.action, "summary": obj.summary}
    print(json.dumps(data, indent=2))


def cmd_run(args: argparse.Namespace) -> None:
    """Initialize pipeline and output first instruction."""
    from pbr import init_pipeline

    skip: list[str] = []
    if args.skip_plan:
        skip.append("plan")
    if args.skip_review:
        skip.append("review")

    result = init_pipeline(
        task=args.task,
        workspace=args.workspace,
        planner_model=args.planner_model,
        builder_model=args.builder_model,
        reviewer_model=args.reviewer_model,
        skip_phases=skip or None,
        timeout=args.timeout,
        retries=args.retries,
    )
    _output_json(result)


def cmd_next(args: argparse.Namespace) -> None:
    """Get next spawn instruction."""
    from pbr import next_phase
    result = next_phase(args.workspace)
    _output_json(result)


def cmd_complete(args: argparse.Namespace) -> None:
    """Mark current phase as completed."""
    from pbr import complete_phase
    complete_phase(
        args.workspace,
        artifacts=args.artifacts or [],
        error=args.error,
    )
    print(json.dumps({"status": "ok"}))


def cmd_status(args: argparse.Namespace) -> None:
    """Show pipeline status."""
    state = load_state(Path(args.workspace))
    if state is None:
        print("No pipeline found.")
        return

    print(f"Task: {state.task}")
    print(f"Current phase: {state.current_phase or 'none'}")
    print()
    for phase in PHASE_ORDER:
        pr = state.phases[phase]
        icon = {"completed": "✅", "failed": "❌", "skipped": "⏭️", "pending": "⏳", "running": "🔄"}.get(pr.status, "?")
        line = f"  {icon} {phase}: {pr.status}"
        if pr.attempt > 0:
            line += f" (attempt {pr.attempt})"
        if pr.error:
            line += f" — {pr.error}"
        print(line)


def cmd_reset(args: argparse.Namespace) -> None:
    """Reset phase or entire pipeline."""
    ws = Path(args.workspace)
    state = load_state(ws)
    if state is None:
        print("No pipeline found.")
        return

    if args.all:
        from pbr.state import PhaseRecord
        for name in PHASE_ORDER:
            state.phases[name] = PhaseRecord(name=name)
        state.current_phase = None
    elif args.phase:
        from pbr.state import PhaseRecord
        if args.phase in state.phases:
            state.phases[args.phase] = PhaseRecord(name=args.phase)
            if state.current_phase == args.phase:
                state.current_phase = None
    save_state(ws, state)
    print(json.dumps({"status": "ok"}))


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="pbr", description="PBR Orchestrator")
    sub = parser.add_subparsers(dest="command")

    # run
    p_run = sub.add_parser("run")
    p_run.add_argument("--task", required=True)
    p_run.add_argument("--workspace", required=True)
    p_run.add_argument("--planner-model", default="anthropic/claude-opus-4-6")
    p_run.add_argument("--builder-model", default="anthropic/claude-sonnet-4-6")
    p_run.add_argument("--reviewer-model", default="anthropic/claude-sonnet-4-6")
    p_run.add_argument("--skip-plan", action="store_true")
    p_run.add_argument("--skip-review", action="store_true")
    p_run.add_argument("--timeout", type=int, default=600)
    p_run.add_argument("--retries", type=int, default=1)
    p_run.set_defaults(func=cmd_run)

    # next
    p_next = sub.add_parser("next")
    p_next.add_argument("--workspace", required=True)
    p_next.set_defaults(func=cmd_next)

    # complete
    p_complete = sub.add_parser("complete")
    p_complete.add_argument("--workspace", required=True)
    p_complete.add_argument("--artifacts", nargs="*")
    p_complete.add_argument("--error")
    p_complete.set_defaults(func=cmd_complete)

    # status
    p_status = sub.add_parser("status")
    p_status.add_argument("--workspace", required=True)
    p_status.set_defaults(func=cmd_status)

    # reset
    p_reset = sub.add_parser("reset")
    p_reset.add_argument("--workspace", required=True)
    p_reset.add_argument("--phase", choices=PHASE_ORDER)
    p_reset.add_argument("--all", action="store_true")
    p_reset.set_defaults(func=cmd_reset)

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
