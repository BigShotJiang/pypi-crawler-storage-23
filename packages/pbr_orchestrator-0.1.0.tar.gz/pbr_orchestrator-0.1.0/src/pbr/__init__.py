"""PBR Orchestrator — Plan → Build → Review pipeline."""

from __future__ import annotations

from pathlib import Path
from pbr.state import init_state, load_state, save_state, advance_phase
from pbr.pipeline import determine_next_phase, build_phase_prompt, generate_report
from pbr.spawner import SpawnInstruction, DoneResult, create_spawn_instruction
from pbr.phases import PHASE_ORDER
from pbr.state import PBRState

__all__ = [
    "run_pipeline",
    "next_phase",
    "init_pipeline",
    "complete_phase",
    "PipelineResult",
    "PHASE_ORDER",
    "PBRState",
]


class PipelineResult:
    def __init__(self, success: bool, phases: dict, summary: str, total_duration_seconds: float, artifacts: list[str]):
        self.success = success
        self.phases = phases
        self.summary = summary
        self.total_duration_seconds = total_duration_seconds
        self.artifacts = artifacts


def init_pipeline(
    task: str,
    workspace: str | Path,
    *,
    planner_model: str = "anthropic/claude-opus-4-6",
    builder_model: str = "anthropic/claude-sonnet-4-6",
    reviewer_model: str = "anthropic/claude-sonnet-4-6",
    skip_phases: list[str] | None = None,
    timeout: int = 600,
    retries: int = 1,
) -> SpawnInstruction | DoneResult:
    """Initialize a new pipeline and return the first spawn instruction."""
    ws = Path(workspace)
    ws.mkdir(parents=True, exist_ok=True)

    config = {
        "models": {
            "plan": planner_model,
            "build": builder_model,
            "review": reviewer_model,
        },
        "timeout": timeout,
        "retries": retries,
    }

    state = init_state(ws, task, **config)

    # Handle skipped phases
    if skip_phases:
        for phase in skip_phases:
            if phase in state.phases:
                state = advance_phase(state, phase, "skipped")
        save_state(ws, state)

    return next_phase(workspace)


def next_phase(workspace: str | Path) -> SpawnInstruction | DoneResult:
    """Determine and return the next spawn instruction, or done if complete."""
    ws = Path(workspace)
    state = load_state(ws)
    if state is None:
        return DoneResult(summary="No pipeline state found. Run init first.")

    phase = determine_next_phase(state)
    if phase is None:
        summary = generate_report(state, ws)
        return DoneResult(summary=summary, state=state)

    # Mark phase as running
    state = advance_phase(state, phase, "running")
    save_state(ws, state)

    prompt = build_phase_prompt(state, phase, ws)
    return create_spawn_instruction(state, phase, prompt)


def complete_phase(
    workspace: str | Path,
    *,
    artifacts: list[str] | None = None,
    error: str | None = None,
) -> None:
    """Mark the current running phase as completed or failed."""
    ws = Path(workspace)
    state = load_state(ws)
    if state is None:
        raise ValueError("No pipeline state found")

    if state.current_phase is None:
        raise ValueError("No phase currently running")

    phase = state.current_phase
    status = "failed" if error else "completed"
    state = advance_phase(state, phase, status, artifacts=artifacts, error=error)
    save_state(ws, state)


def run_pipeline(
    task: str,
    workspace: str | Path,
    *,
    planner_model: str = "anthropic/claude-opus-4-6",
    builder_model: str = "anthropic/claude-sonnet-4-6",
    reviewer_model: str = "anthropic/claude-sonnet-4-6",
    skip_phases: list[str] | None = None,
    custom_prompts: dict[str, str] | None = None,
    create_repo: str | None = None,
    timeout: int = 600,
    retries: int = 1,
    api_mode: bool = False,
) -> PipelineResult:
    """Run the full pipeline. In instruction mode, returns after init."""
    instruction = init_pipeline(
        task, workspace,
        planner_model=planner_model,
        builder_model=builder_model,
        reviewer_model=reviewer_model,
        skip_phases=skip_phases,
        timeout=timeout,
        retries=retries,
    )

    ws = Path(workspace)
    state = load_state(ws)
    all_artifacts: list[str] = []
    if state:
        for pr in state.phases.values():
            all_artifacts.extend(pr.artifacts)

    success = isinstance(instruction, DoneResult)
    summary = instruction.summary if isinstance(instruction, DoneResult) else "Pipeline initialized, awaiting agent execution."

    return PipelineResult(
        success=success,
        phases={name: pr for name, pr in (state.phases.items() if state else {})},
        summary=summary,
        total_duration_seconds=0.0,
        artifacts=all_artifacts,
    )
