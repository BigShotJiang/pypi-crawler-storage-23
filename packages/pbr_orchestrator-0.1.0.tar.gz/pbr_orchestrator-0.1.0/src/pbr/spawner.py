"""Spawn instruction generation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from pbr.phases import get_model_for_phase

if TYPE_CHECKING:
    from pbr.state import PBRState


@dataclass
class SpawnInstruction:
    action: str = "spawn"
    label: str = ""
    model: str = ""
    task: str = ""
    timeout_seconds: int = 600


@dataclass
class DoneResult:
    action: str = "done"
    summary: str = ""
    state: object = None  # PBRState, but optional


def create_spawn_instruction(state: PBRState, phase: str, prompt: str) -> SpawnInstruction:
    """Create a spawn instruction for a given phase."""
    model = get_model_for_phase(phase, state.config)
    timeout = state.config.get("timeout", 600)

    # Build a label from task
    task_slug = state.task.lower().replace(" ", "-")[:30]
    label = f"pbr-{phase}-{task_slug}"

    return SpawnInstruction(
        action="spawn",
        label=label,
        model=model,
        task=prompt,
        timeout_seconds=timeout,
    )
