# Este archivo hace que Python trate el directorio 'visor-vari' como un paquete.
""" Paquete visor_vari - Visor de variables para debugging """

from visor_vari.viendo import gentil, encadena, faseypulso, ultimate, borratodo, guia
from visor_vari.mas_bajo_nivel.see import refer_0, refer_1, refer_2, refer_3, refer_4, refer_5, refer_6, refer_7, refer_8, refer_9

__all__ = ['gentil', 'encadena', 'faseypulso', 'ultimate', 'borratodo', 'guia', 
           'refer_0', 'refer_1', 'refer_2', 'refer_3', 'refer_4', 'refer_5', 'refer_6', 'refer_7', 'refer_8', 'refer_9']
