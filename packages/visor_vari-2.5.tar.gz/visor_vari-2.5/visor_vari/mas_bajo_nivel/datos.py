
""" Datos para algunas cuestiones """


class Numero_y_orden:
    
    def __init__(self):
        
        self.ola_numero= 1
        self.ola_reajustada= False
        self.numero_de_ventana= 0
        
        self.posible_tk= None
        self.nombre_de_ventana= "Referencia_0"
        
        self.permanece_con_toplevel= True
        self.pausado= True
                
coloco= Numero_y_orden()


class Estados_de_refer:
    
    def __init__(self):
        
        self.estado_refer_0= True
        self.estado_refer_1= False
        self.estado_refer_2= False
        self.estado_refer_3= False
        self.estado_refer_4= False
        self.estado_refer_5= False
        self.estado_refer_6= False
        self.estado_refer_7= False
        self.estado_refer_8= False
        self.estado_refer_9= False

verifico= Estados_de_refer()

