
""" Modulo que almacena todas las variables que se quieran ver,
    y que posteriormente se pueden visualizar con la libreria 'vari-vari'. """


"==============================="
#   Variables que se muestran por la ventana de visualizacion
#################################

class Super_tabla:

    def __init__(self):
        
        "0"
        self.selda_0= 0
        self.selda_1= 0
        self.selda_2= 0
        
        self.selda_3= 0
        self.selda_4= 0
        self.selda_5= 0
        
        self.selda_6= 0
        self.selda_7= 0
        self.selda_8= 0
        
        "1"
        self.selda_9= 0
        self.selda_10= 0
        self.selda_11= 0
        
        self.selda_12= 0
        self.selda_13= 0
        self.selda_14= 0
        
        self.selda_15= 0
        self.selda_16= 0
        self.selda_17= 0
        
        "2"
        self.selda_18= 0
        self.selda_19= 0
        self.selda_20= 0
        
        self.selda_21= 0
        self.selda_22= 0
        self.selda_23= 0

        self.selda_24= 0
        self.selda_25= 0
        self.selda_26= 0
        
        "3"
        self.selda_27= 0
        self.selda_28= 0
        self.selda_29= 0
        
        self.selda_30= 0
        self.selda_31= 0
        self.selda_32= 0
        
        self.selda_33= 0
        self.selda_34= 0
        self.selda_35= 0
        
        "4"
        self.selda_36= 0
        self.selda_37= 0
        self.selda_38= 0
        
        self.selda_39= 0
        self.selda_40= 0
        self.selda_41= 0
        
        self.selda_42= 0
        self.selda_43= 0
        self.selda_44= 0
        
        "5"
        self.selda_45= 0
        self.selda_46= 0
        self.selda_47= 0
        
        self.selda_48= 0
        self.selda_49= 0
        self.selda_50= 0
        
        self.selda_51= 0
        self.selda_52= 0
        self.selda_53= 0
        
        "6"
        self.selda_54= 0
        self.selda_55= 0
        self.selda_56= 0
        
        self.selda_57= 0
        self.selda_58= 0
        self.selda_59= 0
        
        self.selda_60= 0
        self.selda_61= 0
        self.selda_62= 0
        
        "7"
        self.selda_63= 0
        self.selda_64= 0
        self.selda_65= 0
        
        self.selda_66= 0
        self.selda_67= 0
        self.selda_68= 0
        
        self.selda_69= 0
        self.selda_70= 0
        self.selda_71= 0
        
        "8"
        self.selda_72= 0
        self.selda_73= 0
        self.selda_74= 0
        
        self.selda_75= 0
        self.selda_76= 0
        self.selda_77= 0
        
        self.selda_78= 0
        self.selda_79= 0
        self.selda_80= 0

# al menos la primera para la ejecuciones mas simples.
refer_0= Super_tabla()

# mas tablas para ejecuciones mas complejas.
refer_1= Super_tabla()
refer_2= Super_tabla()
refer_3= Super_tabla()
refer_4= Super_tabla()

refer_5= Super_tabla()
refer_6= Super_tabla()
refer_7= Super_tabla()
refer_8= Super_tabla()
refer_9= Super_tabla()

"==============================="
#   Proceso que limpia las tablas de visualizacion
##################################

class Clear_tabla:
    
    def __init__(self):
        
        self.ima= None
        self.num= 0
        self.all= None
        self.lateral= 0
        
    def bidiverso(self):
    
        if (self.num == 0) or (self.lateral == 10):
            
            self.ima.selda_0= 0
            self.ima.selda_1= 0
            self.ima.selda_2= 0
            
            self.ima.selda_3= 0
            self.ima.selda_4= 0
            self.ima.selda_5= 0
            
            self.ima.selda_6= 0
            self.ima.selda_7= 0
            self.ima.selda_8= 0
        
        if (self.num == 1) or (self.lateral == 10):

            self.ima.selda_9= 0
            self.ima.selda_10= 0
            self.ima.selda_11= 0
            
            self.ima.selda_12= 0
            self.ima.selda_13= 0
            self.ima.selda_14= 0
            
            self.ima.selda_15= 0
            self.ima.selda_16= 0
            self.ima.selda_17= 0

        if (self.num == 2) or (self.lateral == 10):

            self.ima.selda_18= 0
            self.ima.selda_19= 0
            self.ima.selda_20= 0
            
            self.ima.selda_21= 0
            self.ima.selda_22= 0
            self.ima.selda_23= 0
            
            self.ima.selda_24= 0
            self.ima.selda_25= 0
            self.ima.selda_26= 0


        if (self.num == 3) or (self.lateral == 10):

            self.ima.selda_27= 0
            self.ima.selda_28= 0
            self.ima.selda_29= 0
            
            self.ima.selda_30= 0
            self.ima.selda_31= 0
            self.ima.selda_32= 0
            
            self.ima.selda_33= 0
            self.ima.selda_34= 0
            self.ima.selda_35= 0

        if (self.num == 4) or (self.lateral == 10):

            self.ima.selda_36= 0
            self.ima.selda_37= 0
            self.ima.selda_38= 0
            
            self.ima.selda_39= 0
            self.ima.selda_40= 0
            self.ima.selda_41= 0
            
            self.ima.selda_42= 0
            self.ima.selda_43= 0
            self.ima.selda_44= 0

        if (self.num == 5) or (self.lateral == 10):

            self.ima.selda_45= 0
            self.ima.selda_46= 0
            self.ima.selda_47= 0
            
            self.ima.selda_48= 0
            self.ima.selda_49= 0
            self.ima.selda_50= 0
            
            self.ima.selda_51= 0
            self.ima.selda_52= 0
            self.ima.selda_53= 0


        if (self.num == 6) or (self.lateral == 10):

            self.ima.selda_54= 0
            self.ima.selda_55= 0
            self.ima.selda_56= 0
            
            self.ima.selda_57= 0
            self.ima.selda_58= 0
            self.ima.selda_59= 0
            
            self.ima.selda_60= 0
            self.ima.selda_61= 0
            self.ima.selda_62= 0

        if (self.num == 7) or (self.lateral == 10):

            self.ima.selda_63= 0
            self.ima.selda_64= 0
            self.ima.selda_65= 0
            
            self.ima.selda_66= 0
            self.ima.selda_67= 0
            self.ima.selda_68= 0
            
            self.ima.selda_69= 0
            self.ima.selda_70= 0
            self.ima.selda_71= 0

        if (self.num == 8) or (self.lateral == 10):

            self.ima.selda_72= 0
            self.ima.selda_73= 0
            self.ima.selda_74= 0
            
            self.ima.selda_75= 0
            self.ima.selda_76= 0
            self.ima.selda_77= 0
            
            self.ima.selda_78= 0
            self.ima.selda_79= 0
            self.ima.selda_80= 0

    def serial(self):
        
        if self.num >= 0:
            
            self.ima.selda_0= 0
            self.ima.selda_1= 0
            self.ima.selda_2= 0
            
            self.ima.selda_3= 0
            self.ima.selda_4= 0
            self.ima.selda_5= 0
            
            self.ima.selda_6= 0
            self.ima.selda_7= 0
            self.ima.selda_8= 0
        
        if self.num >= 1:

            self.ima.selda_9= 0
            self.ima.selda_10= 0
            self.ima.selda_11= 0
            
            self.ima.selda_12= 0
            self.ima.selda_13= 0
            self.ima.selda_14= 0
            
            self.ima.selda_15= 0
            self.ima.selda_16= 0
            self.ima.selda_17= 0

        if self.num >= 2:

            self.ima.selda_18= 0
            self.ima.selda_19= 0
            self.ima.selda_20= 0
            
            self.ima.selda_21= 0
            self.ima.selda_22= 0
            self.ima.selda_23= 0
            
            self.ima.selda_24= 0
            self.ima.selda_25= 0
            self.ima.selda_26= 0


        if self.num >= 3:

            self.ima.selda_27= 0
            self.ima.selda_28= 0
            self.ima.selda_29= 0
            
            self.ima.selda_30= 0
            self.ima.selda_31= 0
            self.ima.selda_32= 0
            
            self.ima.selda_33= 0
            self.ima.selda_34= 0
            self.ima.selda_35= 0

        if self.num >= 4:

            self.ima.selda_36= 0
            self.ima.selda_37= 0
            self.ima.selda_38= 0
            
            self.ima.selda_39= 0
            self.ima.selda_40= 0
            self.ima.selda_41= 0
            
            self.ima.selda_42= 0
            self.ima.selda_43= 0
            self.ima.selda_44= 0

        if self.num >= 5:

            self.ima.selda_45= 0
            self.ima.selda_46= 0
            self.ima.selda_47= 0
            
            self.ima.selda_48= 0
            self.ima.selda_49= 0
            self.ima.selda_50= 0
            
            self.ima.selda_51= 0
            self.ima.selda_52= 0
            self.ima.selda_53= 0


        if self.num >= 6:

            self.ima.selda_54= 0
            self.ima.selda_55= 0
            self.ima.selda_56= 0
            
            self.ima.selda_57= 0
            self.ima.selda_58= 0
            self.ima.selda_59= 0
            
            self.ima.selda_60= 0
            self.ima.selda_61= 0
            self.ima.selda_62= 0

        if self.num >= 7:

            self.ima.selda_63= 0
            self.ima.selda_64= 0
            self.ima.selda_65= 0
            
            self.ima.selda_66= 0
            self.ima.selda_67= 0
            self.ima.selda_68= 0
            
            self.ima.selda_69= 0
            self.ima.selda_70= 0
            self.ima.selda_71= 0

        if self.num >= 8:

            self.ima.selda_72= 0
            self.ima.selda_73= 0
            self.ima.selda_74= 0
            
            self.ima.selda_75= 0
            self.ima.selda_76= 0
            self.ima.selda_77= 0
            
            self.ima.selda_78= 0
            self.ima.selda_79= 0
            self.ima.selda_80= 0

    def limpiar(self, ima, num= None, all= None):
        
        self.ima= ima
        self.num= num
        self.all= all
        
        if self.all == None:
            
            if self.num == None:
                self.lateral= 10
                        
            if (-1 < self.num) and (self.num < 9):  # para borrar uno especifico.
                self.bidiverso()
            elif self.num == 10:                    # para borrar todos.
                self.bidiverso()
        
        elif  (self.all == "super") or (self.all == "Super") or (self.all == "SUPER") or (self.all == "s") or (self.all == "S"):
            
            if self.num != None:    # ''supe'' siendo un numero...
                if (-1 < self.num) and (self.num < 9): # del 0 al 8.
                    self.serial()                   # para borrar hasta ese numero.

limpieza= Clear_tabla()

"==============================="
#   Deside cuales objetos se van a borrar.
################################

def aborrar(numero, all, lista):
    
    if (numero == None) and (all == None) and (lista == None):
        limpieza.limpiar(refer_0, numero, all) # esto borra todo (del refer_0)
        
    if (numero != None) and (all != None) and (lista == None):
        limpieza.limpiar(refer_0, numero, all) # actua normalmente para refer_0
        
    if lista != None: # se replica 'numero' y 'all' en todos los refers.
        if 0 in lista:
            limpieza.limpiar(refer_0, numero, all)
        if 1 in lista:
            limpieza.limpiar(refer_1, numero, all)
        if 2 in lista:
            limpieza.limpiar(refer_2, numero, all)
        if 3 in lista:
            limpieza.limpiar(refer_3, numero, all)
        if 4 in lista:
            limpieza.limpiar(refer_4, numero, all)
        if 5 in lista:
            limpieza.limpiar(refer_5, numero, all)
        if 6 in lista:
            limpieza.limpiar(refer_6, numero, all)
        if 7 in lista:
            limpieza.limpiar(refer_7, numero, all)
        if 8 in lista:
            limpieza.limpiar(refer_8, numero, all)
        if 9 in lista:
            limpieza.limpiar(refer_9, numero, all)
    
"==============================="

