# visor_vari

**Librería que Permite la visualización de grandes conjuntos de datos en sistemas**

`visor_vari` es una herramienta de debugging que permite monitorear el estado de las variables durante la ejecución de un programa Python, ofreciendo una alternativa visual y organizada. Pero ademas de ser una herramienta de debugging, es una herramienta de apoyo, en el desarrollo de sistemas de software.

## Forma simple de uso:

```python
from visor-vari import *
```

## Actualización

febrero de 2026.
Versión: 2.5 
(modificaciones para poder usar la libreria, 
aunque el usuario este empleando una ventana tkinter, personal, 
para su aplicacion.)

## Nuevas funciones

- **guia (definiciones para tkinter, modificacion del numero de ola, lista de refers habilitados)**
- **borratodo (cantidad de seldas, limite a borrar si se pretende, cuales refers)**
- **el metodo 'en_cadena' pasa a ser 'encadena' (hace lo mismo)**

## Explicación de guia:

`guia` es una funcion que le ingresan tres argumentos. El primero es el Tk con que usted, usuario, se encuentre utilizando en su aplicacion, ejemplo:
```python
import tkinter as tk
guia(tkin= tk)
ventana_del_usuario= tk.Tk()
# ...
ventana_del_usuario.mainloop()
```
El segundo argumento que se pasa es un reajuste para que en el titulo de la ventana (donde se visualizan los valores guardados... en la libreria...) el numero de olas empiece a contar desde 0 (si es True= desde 0, si es False= desde 1). Por defecto este argumento es False, para no divergir tanto de la version anterior.
```python
guia(tkin= tk, reajusteola= False)
```
El tercer y ultimo argumento se trata de una lista, la lista que indica cuales refer_x se estaran ejecutando (recuerde ingresar los valores para estos refers). la lista es una lista simple `[0, 1, 2, 3 ...]` y deben aparecer segun los refers que quiera ver. cero (0) para refer_0, uno (1) para refer_1, dos (2) para refer_2, etc. No necesariamente tendrian que aparecer en orden.
```python
lista_de_refers= [0, 1, 2]
guia(tkin= tk, reajusteola= False, lista= lista_de_refers)
```
- **...** Ademas debo indicarle que podria ingresar exclusivamente tk:
`guia(tk)` o reajuste... unicamente: `guia(reajusteola= False)` o la lista... exclusivamente: `guia(lista= lista_de_refers)` tambien puede ingresar el primero y el ultimo: `guia(tk, lista_de_refers)` directamente sin nombrarlos.

- **...** tenga en cuenta que la funcion 'guia' busca que los refers (las ventanas que muestran los valores) se abran en una subventana cuando se le pasa tk. sin embargo, cuando a la libreria no se le pasa tk procura abrir los valores, de refer, en una ventana principal.

## Explicación de borratodo:

`borratodo` tambien tiene tres argumentos de entrada, el primero es: `numero` que señala el conjunto de seldas a borrar (las 9 primeras o las otras). Si usted ingresa el numero diez (10) se borraran todas las seldas. El segundo argumento es `limit` que es una indicacion que se coloca, si lo que se quiere es, que se borren desde la cero (0) hasta el 'numero' (el primer argumento). Para este segundo argumento, hay que ingresar el string 'super' o simplemente la letra 's', si se quiere activar, esta forma de borrado de las seldas. por ultimo el tercer argumento es `lista`, que indica los refers que usted quiere que se borren (seborraran como se lo indican los dos primeros argumentos). Ejemplo:
```python
lista_de_refers= [0, 2, 3]
borratodo(3, 's', lista_de_refers)
# Se han borrado en: refer_0, refer_2 y refer_3 las primeras 27 (3x9) seldas.
```
Por defecto se señala a `refer_0` por lo que usted puede escribir lo siguiente:
```python
borratodo(3)
# En este caso, se borrara unicamente, desde la selda 18 hasta la 27 de refer_0
```

## Uso Básico

```python
from visor_vari import refer_0, gentil

# Asigna tus variables a las celdas del visor
a = 10
b = 15

refer_0.selda_0 = a
refer_0.selda_1 = b

# Visualiza los valores
gentil()

# Las variables pueden cambiar durante la ejecución
refer_0.selda_0 = 43

c = 17
refer_0.selda_41 = c

# Visualiza los nuevos valores
gentil()
```

## Características

- **81 celdas de almacenamiento**: `selda_0` hasta `selda_80` para monitorear múltiples variables. cada refer_x tiene esta cantidad de celdas
- **Seguimiento en tiempo real**: Detecta y muestra cambios en las variables durante la ejecución
- **Fácil integración**: Solo necesitas importar y usar

## Modos de Operación

1. **Modo simple** : Muestra variables una a una. La funcion 'gentil' puede recibir como argumento 'pausado'. pausado esta por defecto en= True
```python
gentil()
```

2. **Modo encadena** : Solo muestra los numeros que coinciden con `encadena`.
Para la 'lista', cada 'gentil' tiene una posicion (indice). comenzando desde cero.
```python
en_cadena(n, lista, pausado)
gentil(n)
```

3. **Modo fase y pulso** : No los primeros (profundidad), sino los indicados en las listas de los diccionarios dentro de 'lista' [ {0: [n_numeros]}, {1: [n_numeros]} ...] las llaves (de los diccionarios) representan a las veces que el flujo entra (olas). 
La 'lista' es innecesaria si el primer argumento que se pasa a 'faseypulso' es: False, este primer argumento se llama 'bajada'. Por otro lado, `ultimate` es necesario para que la libreria identifique las olas en este modo (fase y pulso).
```python
faseypulso(True, lista, pausado)
gentil(n)
ultimate()
```

4. **nota adicional** : como puede notar... en los dos ultimos modos, pausado es controlado directamente desde las definiciones, previas, `encadena` y `faseypulso`. por lo que en 'gentil' solo ingresa el numero.

## Ejemplo Completo

Puede copiar el siguiente codigo para que usted mismo haga la prueba de este ejemplo.

```python
""" Comprobando el funcionamiento de la libreria visor_vari
    version 2.5 """


"==================================="

from visor_vari.viendo import gentil, encadena, faseypulso, ultimate
from visor_vari.mas_bajo_nivel.see import refer_0

"==================================="

class Numeros:
    def __init__(self):
        self.valor_x= 0
        self.valor_y= 20

abaco= Numeros()

def suma_valores():
    suma= abaco.valor_x + abaco.valor_y
    
    refer_0.selda_0= abaco.valor_x
    refer_0.selda_1= abaco.valor_y
    refer_0.selda_2= suma
    
    abaco.valor_x += 1
    
    return suma

"==================================="

"""# agrega el carapter numeral (#) al comienzo de esta linea para activar el bloque de codigo.
suma_valores()
gentil()
suma_valores()
gentil()
suma_valores()
gentil()
suma_valores()
gentil()

ultimate() # no trabaja qui, ya que solo lo hace en faseypulso.
#"""

"==================================="

#""" suprime o elimina el carapter numeral (#) al comienzo de esta linea para desactivar el bloque de codigo.
suma_valores() # para que empiece a sumar desde 1 (abaco.valor_x o refer_0.selda_0).
listando_los_gentiles_que_quiero_ver= [0, 2]
encadena(2)

suma_valores()
gentil(0)
suma_valores()
gentil(1)
suma_valores()
gentil(2)
suma_valores()
gentil(1)
suma_valores()
gentil(2)
suma_valores()
gentil(1)
suma_valores()
gentil(2)

ultimate() # no trabaja qui, ya que solo lo hace en faseypulso.
#"""

"==================================="

"""

lista_1= []
lista_2= [0, 1]
lista_3= [0, 1]

tu= 1
listando_los_gentiles_que_quiero_ver= [{0: lista_1}, {1: lista_2}, {2: lista_3}]
faseypulso(True, listando_los_gentiles_que_quiero_ver)
suma_valores() # para que empiece a sumar desde 1 (abaco.valor_x o refer_0.selda_0).

while tu < 8:
    
    print("Ciclo numero: ", tu)
    
    suma_valores()
    gentil(0)
    suma_valores()
    gentil(1)
    suma_valores()
    gentil(2)
    gentil(1)
    suma_valores()
    gentil(3)
    suma_valores()
    gentil(4)
    gentil(3)
    suma_valores()
    gentil(2)
    suma_valores()
    gentil(6)

    ultimate()
    tu += 1
#"""

print("fin de la prueva")
```

## Requisitos

- Python 3.6+
- tkinter (incluido con Python)

## Licencia

Licencia pública de Mozilla versión 2.0

## Codigo fuente en github

https://github.com/Jesu-super-galactico/visor-vari

## Documentación Adicional

Para más información sobre los modos de visualización, consulta:

```python
from visor_vari.readme_visor import readme, readme_tipos
```