"""
Setup configuration for visor_vari package.
0
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="visor_vari",
    version="2.5",
    author="El señor es el único eterno. Que la ciencia lo honre a Él",
    author_email="from.colombia.to.all@gmail.com",
    
    description="Permite la visualización de grandes conjuntos de datos en sistemas (software) complejos",
    long_description=long_description,
    long_description_content_type= "text/markdown",
    
    url="https://github.com/Jesu-super-galactico/visor-vari",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Mozilla Public License 2.0 (MPL 2.0)",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Debuggers",
    ],
    python_requires=">=3.6",
    install_requires=[
        # tkinter viene incluido con Python.
    ]
)
