#!/usr/bin/env python3
"""ClawMesh Admin Setup - Generate bot configurations for your team.

Usage:
    python scripts/admin_setup.py --server nats://your-server:4222

This generates:
    1. A token for NATS authorization
    2. A config directory with per-bot config files
    3. A shell script each person can run to set up their bot

Edit the TEAM list below to match your organization.
"""

from __future__ import annotations

import argparse
import secrets
import sys
from pathlib import Path

import yaml

TEAM = [
    {"id": "bot_zhangsan", "dept": "rd", "name": "Zhang San"},
    {"id": "bot_lisi", "dept": "rd", "name": "Li Si"},
    {"id": "bot_wangwu", "dept": "qa", "name": "Wang Wu"},
    {"id": "bot_zhaoliu", "dept": "pm", "name": "Zhao Liu"},
]


def main():
    parser = argparse.ArgumentParser(description="Generate ClawMesh bot configs")
    parser.add_argument(
        "--server",
        default="nats://localhost:4222",
        help="NATS server URL",
    )
    parser.add_argument(
        "--output",
        default="./bot-configs",
        help="Output directory for configs",
    )
    parser.add_argument(
        "--token",
        default="",
        help="Shared auth token (generated if empty)",
    )
    args = parser.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    token = args.token or secrets.token_urlsafe(32)

    print(f"Server:  {args.server}")
    print(f"Token:   {token}")
    print(f"Output:  {output}")
    print(f"Bots:    {len(TEAM)}")
    print()

    nats_conf = output / "nats-server-auth.conf"
    nats_conf.write_text(
        f"# Add this to your nats-server.conf\n"
        f"authorization {{\n"
        f'    token: "{token}"\n'
        f"}}\n"
    )
    print(f"  [+] {nats_conf}")

    for member in TEAM:
        bot_id = member["id"]
        dept = member["dept"]
        name = member["name"]

        config = {
            "server": args.server,
            "bot_id": bot_id,
            "department": dept,
            "token": token,
        }

        config_file = output / f"{bot_id}.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True)

        setup_script = output / f"setup_{bot_id}.sh"
        setup_script.write_text(
            f"#!/bin/bash\n"
            f"# Setup script for {name}'s bot ({bot_id})\n"
            f"# Run: bash {setup_script.name}\n\n"
            f"clawmesh login "
            f"--server {args.server} "
            f"--id {bot_id} "
            f"--dept {dept} "
            f"--token {token}\n\n"
            f'echo "Done! {bot_id} is ready."\n'
            f'echo "Start daemon: clawmesh daemon start"\n'
            f'echo "Test: clawmesh shout org.dept.{dept} '
            f"'Hello from {name}!'\"\n"
        )
        setup_script.chmod(0o755)

        print(f"  [+] {config_file}")
        print(f"  [+] {setup_script}")

    print()
    print("=== Next Steps ===")
    print()
    print(f"1. Add token auth to NATS: see {nats_conf}")
    print(f"2. Distribute setup scripts to each person")
    print(f"3. Each person runs: bash setup_<bot_id>.sh")
    print(f"4. Then: clawmesh daemon start")
    print()
    print(
        "Tip: Edit the TEAM list in this script to match your org,"
        " then re-run."
    )


if __name__ == "__main__":
    main()
