"""NATS client wrapper for ClawMesh bus communication."""

from __future__ import annotations

import nats
from nats.aio.client import Client as NATSClient
from nats.js.client import JetStreamContext

from clawmesh.config import ClawMeshConfig
from clawmesh.protocol.message import Message


class BusClient:
    """High-level wrapper around nats-py for ClawMesh operations.

    Handles connection lifecycle, publishing, and fetching via JetStream.
    """

    STREAM_NAME = "CLAWMESH"
    STREAM_SUBJECTS = ["org.>"]

    def __init__(self, config: ClawMeshConfig | None = None):
        self._config = config or ClawMeshConfig.load()
        self._nc: NATSClient | None = None
        self._js: JetStreamContext | None = None

    @property
    def is_connected(self) -> bool:
        return self._nc is not None and self._nc.is_connected

    async def connect(self) -> None:
        connect_opts: dict = {"servers": [self._config.server]}
        if self._config.token:
            connect_opts["token"] = self._config.token
        self._nc = await nats.connect(**connect_opts)
        self._js = self._nc.jetstream()
        await self._ensure_stream()

    async def close(self) -> None:
        if self._nc and not self._nc.is_closed:
            await self._nc.close()
            self._nc = None
            self._js = None

    async def _ensure_stream(self) -> None:
        """Create or update the ClawMesh JetStream stream."""
        try:
            await self._js.find_stream_name_by_subject("org.global")
        except Exception:
            await self._js.add_stream(
                name=self.STREAM_NAME,
                subjects=self.STREAM_SUBJECTS,
            )

    async def publish(self, message: Message) -> None:
        if not self._js:
            raise RuntimeError("Not connected to NATS. Call connect() first.")
        await self._js.publish(message.to, message.to_nats_payload())

    async def fetch_messages(
        self,
        subject: str,
        limit: int = 10,
    ) -> list[Message]:
        """Fetch recent messages from a channel via JetStream ordered consumer."""
        if not self._js:
            raise RuntimeError("Not connected to NATS. Call connect() first.")

        messages: list[Message] = []
        sub = await self._js.subscribe(subject, ordered_consumer=True)
        try:
            while len(messages) < limit:
                try:
                    msg = await sub.next_msg(timeout=2.0)
                    messages.append(Message.from_nats_payload(msg.data))
                except TimeoutError:
                    break
        finally:
            await sub.unsubscribe()

        if len(messages) > limit:
            messages = messages[-limit:]
        return messages

    async def __aenter__(self) -> BusClient:
        await self.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()
