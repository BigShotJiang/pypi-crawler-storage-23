"""ClawMesh Archiver - Message archival and search service.

Subscribes to all org.> messages, stores them in SQLite with FTS5,
and exposes an HTTP API for historical search.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
from pathlib import Path

from clawmesh.archiver.storage import ArchiveStorage
from clawmesh.archiver.subscriber import ArchiveSubscriber
from clawmesh.config import ClawMeshConfig


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    logger = logging.getLogger("clawmesh.archiver")

    config = ClawMeshConfig.load()
    nats_url = os.environ.get("CLAWMESH_NATS_URL", config.server)
    default_db = str(Path.home() / ".clawmesh" / "archive.db")
    db_path = Path(os.environ.get("CLAWMESH_DB_PATH", default_db))
    api_port = int(os.environ.get("CLAWMESH_API_PORT", "8383"))

    config_override = ClawMeshConfig(
        server=nats_url,
        bot_id=config.bot_id or "archiver",
        token=config.token,
    )

    storage = ArchiveStorage(db_path)
    storage.open()
    logger.info("Archive DB: %s", db_path)

    subscriber = ArchiveSubscriber(config_override, storage)

    async def run_all() -> None:
        stop_event = asyncio.Event()
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop_event.set)

        sub_task = asyncio.create_task(subscriber.run())

        try:
            from aiohttp import web

            from clawmesh.archiver.api import create_app

            app = await create_app(storage)
            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, "0.0.0.0", api_port)
            await site.start()
            logger.info("Archiver HTTP API on http://0.0.0.0:%d", api_port)
        except ImportError:
            logger.warning(
                "aiohttp not installed, HTTP API disabled. "
                "Install with: pip install clawmesh[archiver]"
            )

        await stop_event.wait()

        logger.info("Shutting down archiver...")
        subscriber.stop()
        sub_task.cancel()
        try:
            await sub_task
        except asyncio.CancelledError:
            pass
        storage.close()
        logger.info("Archiver stopped. Total archived: %d", subscriber.archived_count)

    asyncio.run(run_all())


if __name__ == "__main__":
    main()
