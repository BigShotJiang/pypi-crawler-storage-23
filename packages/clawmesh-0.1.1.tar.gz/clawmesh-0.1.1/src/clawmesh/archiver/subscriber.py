"""NATS subscriber for message archival.

Subscribes to all org.> messages and feeds them into the storage layer.
"""

from __future__ import annotations

import asyncio
import logging

import nats

from clawmesh.archiver.storage import ArchiveStorage
from clawmesh.config import ClawMeshConfig
from clawmesh.protocol.message import Message

logger = logging.getLogger("clawmesh.archiver")


class ArchiveSubscriber:
    """Subscribes to NATS and archives all messages to SQLite."""

    def __init__(self, config: ClawMeshConfig, storage: ArchiveStorage):
        self._config = config
        self._storage = storage
        self._running = False
        self._archived_count = 0

    async def run(self) -> None:
        connect_opts: dict = {"servers": [self._config.server]}
        if self._config.token:
            connect_opts["token"] = self._config.token

        nc = await nats.connect(**connect_opts)
        js = nc.jetstream()

        try:
            await js.find_stream_name_by_subject("org.global")
        except Exception:
            await js.add_stream(name="CLAWMESH", subjects=["org.>"])

        sub = await js.subscribe("org.>", ordered_consumer=True)
        self._running = True

        logger.info(
            "Archiver subscribing to org.> on %s (db: %s)",
            self._config.server,
            self._storage._db_path,
        )

        try:
            while self._running:
                try:
                    msg = await sub.next_msg(timeout=5.0)
                    parsed = Message.from_nats_payload(msg.data)
                    self._storage.insert(parsed)
                    self._archived_count += 1
                    if self._archived_count % 100 == 0:
                        logger.info("Archived %d messages", self._archived_count)
                except TimeoutError:
                    continue
                except Exception as e:
                    logger.error("Archive error: %s", e)
                    await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        finally:
            await sub.unsubscribe()
            await nc.close()
            self._running = False

    def stop(self) -> None:
        self._running = False

    @property
    def archived_count(self) -> int:
        return self._archived_count
