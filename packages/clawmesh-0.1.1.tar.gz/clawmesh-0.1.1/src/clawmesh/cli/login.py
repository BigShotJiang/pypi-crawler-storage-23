"""clawmesh login - Configure bot identity and server connection."""

from __future__ import annotations

import typer
from rich.console import Console

from clawmesh.config import CONFIG_PATH, ClawMeshConfig

console = Console()


def login(
    server: str = typer.Option("nats://localhost:4222", "--server", "-s", help="NATS server URL"),
    bot_id: str = typer.Option(..., "--id", "-i", help="Bot identity name"),
    token: str = typer.Option("", "--token", "-t", help="Authentication token"),
    department: str = typer.Option("", "--dept", "-d", help="Department name"),
) -> None:
    """Configure ClawMesh identity and server connection."""
    config = ClawMeshConfig(
        server=server,
        bot_id=bot_id,
        token=token,
        department=department,
    )
    config.save()
    console.print(f"[green]Logged in as [bold]{bot_id}[/bold][/green]")
    console.print(f"  Server: {server}")
    if department:
        console.print(f"  Department: {department}")
    console.print(f"  Config: {CONFIG_PATH}")
