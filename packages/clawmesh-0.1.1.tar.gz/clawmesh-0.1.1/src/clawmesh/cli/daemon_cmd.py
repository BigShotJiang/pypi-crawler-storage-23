"""clawmesh daemon - Manage the background sidecar daemon."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console
from rich.table import Table

from clawmesh.daemon.client import DaemonClient
from clawmesh.daemon.process import (
    get_log_path,
    get_sock_path,
    is_running,
    read_pid,
    start_daemon,
    stop_daemon,
)

console = Console()

daemon_app = typer.Typer(
    name="daemon",
    help="Manage the ClawMesh daemon sidecar.",
    no_args_is_help=True,
)


@daemon_app.command()
def start() -> None:
    """Start the daemon background process."""
    if is_running():
        console.print(f"[yellow]Daemon already running (PID {read_pid()})[/yellow]")
        return

    console.print("[dim]Starting daemon...[/dim]")
    pid = start_daemon()
    if pid:
        console.print(f"[green]Daemon started (PID {pid})[/green]")
        console.print(f"  Socket: {get_sock_path()}")
        console.print(f"  Logs:   {get_log_path()}")
    else:
        console.print("[red]Failed to start daemon. Check logs:[/red]")
        console.print(f"  {get_log_path()}")
        raise typer.Exit(1)


@daemon_app.command()
def stop() -> None:
    """Stop the running daemon."""
    if not is_running():
        console.print("[yellow]Daemon is not running.[/yellow]")
        return

    pid = read_pid()
    if stop_daemon():
        console.print(f"[green]Daemon stopped (was PID {pid})[/green]")
    else:
        console.print("[red]Failed to stop daemon.[/red]")
        raise typer.Exit(1)


@daemon_app.command()
def status() -> None:
    """Show daemon status and statistics."""
    pid = read_pid()
    if not pid:
        console.print("[yellow]Daemon is not running.[/yellow]")
        console.print("[dim]Start with: clawmesh daemon start[/dim]")
        return

    client = DaemonClient()
    try:
        resp = asyncio.run(client.status())
    except Exception:
        console.print(f"[yellow]Daemon process exists (PID {pid}) but not responding.[/yellow]")
        return

    if not resp.ok:
        console.print(f"[red]Daemon error: {resp.error}[/red]")
        return

    info = resp.result
    table = Table(title="ClawMesh Daemon Status", show_header=False)
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("PID", str(pid))
    table.add_row("Bot ID", info.get("bot_id", "?"))
    table.add_row("Server", info.get("server", "?"))
    table.add_row("Connected", "[green]yes[/green]" if info.get("connected") else "[red]no[/red]")
    table.add_row("Uptime", f"{info.get('uptime_seconds', 0)}s")
    table.add_row("Cached Channels", str(info.get("cached_channels", 0)))
    table.add_row("Cached Messages", str(info.get("cached_messages", 0)))

    console.print(table)
