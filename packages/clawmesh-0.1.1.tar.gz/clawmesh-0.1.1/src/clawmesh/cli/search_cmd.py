"""clawmesh search - Search message history via archiver."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from clawmesh.archiver.storage import ArchiveStorage
from clawmesh.protocol.message import Message

console = Console()


def search(
    query: str = typer.Argument(help="Search query"),
    channel: str | None = typer.Option(None, "--channel", "-c", help="Filter by channel"),
    from_id: str | None = typer.Option(None, "--from", "-f", help="Filter by sender"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results"),
    raw: bool = typer.Option(False, "--raw", help="Output raw JSON"),
    api_url: str | None = typer.Option(None, "--api", help="Archiver API URL (e.g. http://localhost:8383)"),
) -> None:
    """Search message history in the archive."""
    if api_url:
        asyncio.run(_search_api(api_url, query, channel, from_id, limit, raw))
    else:
        _search_local(query, channel, from_id, limit, raw)


def _search_local(
    query: str,
    channel: str | None,
    from_id: str | None,
    limit: int,
    raw: bool,
) -> None:
    """Search the local SQLite archive directly."""
    try:
        with ArchiveStorage() as storage:
            messages = storage.search(query=query, channel=channel, from_id=from_id, limit=limit)
    except Exception as e:
        console.print(f"[red]Search failed: {e}[/red]")
        console.print(
            "[dim]Make sure the archiver has been running. Check ~/.clawmesh/archive.db[/dim]"
        )
        raise typer.Exit(1)

    _display_results(messages, query, raw)


async def _search_api(
    api_url: str,
    query: str,
    channel: str | None,
    from_id: str | None,
    limit: int,
    raw: bool,
) -> None:
    """Search via the archiver HTTP API."""
    try:
        from aiohttp import ClientSession
    except ImportError:
        console.print(
            "[red]aiohttp required for API search. Install: pip install clawmesh[archiver][/red]"
        )
        raise typer.Exit(1)

    params = {"q": query, "limit": str(limit)}
    if channel:
        params["channel"] = channel
    if from_id:
        params["from"] = from_id

    async with ClientSession() as session:
        async with session.get(f"{api_url.rstrip('/')}/search", params=params) as resp:
            if resp.status != 200:
                console.print(f"[red]API error: {resp.status}[/red]")
                raise typer.Exit(1)
            data = await resp.json()

    messages = [Message.model_validate(m) for m in data.get("messages", [])]
    _display_results(messages, query, raw)


def _display_results(messages: list[Message], query: str, raw: bool) -> None:
    if not messages:
        console.print(f"[dim]No results for '{query}'[/dim]")
        return

    if raw:
        for msg in messages:
            console.print(msg.model_dump_json())
    else:
        console.print(f"[bold]Search: '{query}'[/bold] ({len(messages)} results)\n")
        for msg in messages:
            channel_tag = f"[dim]#{msg.to}[/dim] "
            console.print(f"  {channel_tag}{msg.short_display()}")
