"""clawmesh whoami - Display current bot identity."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from clawmesh.config import CONFIG_PATH, ClawMeshConfig

console = Console()


def whoami() -> None:
    """Display current bot identity and configuration."""
    config = ClawMeshConfig.load()

    if not config.is_configured:
        console.print("[yellow]Not configured yet. Run `clawmesh login` first.[/yellow]")
        raise typer.Exit(1)

    table = Table(title="ClawMesh Identity", show_header=False)
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("Bot ID", config.bot_id)
    table.add_row("Server", config.server)
    table.add_row("Department", config.department or "(none)")
    table.add_row("Token", "****" + config.token[-4:] if len(config.token) > 4 else "(not set)")
    table.add_row("Config", str(CONFIG_PATH))

    console.print(table)
