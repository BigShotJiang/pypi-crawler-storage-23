"""clawmesh who - Show online bots in the organization."""

from __future__ import annotations

import asyncio
import time

import typer
from rich.console import Console
from rich.table import Table

from clawmesh.config import ClawMeshConfig

console = Console()

ONLINE_THRESHOLD_SEC = 90


def who(
    timeout: int = typer.Option(
        ONLINE_THRESHOLD_SEC,
        "--timeout",
        "-t",
        help="Seconds since last heartbeat to consider a bot online",
    ),
) -> None:
    """Show online bots based on recent heartbeats."""
    config = ClawMeshConfig.load()
    if not config.is_configured:
        console.print("[red]Not configured. Run `clawmesh login` first.[/red]")
        raise typer.Exit(1)

    asyncio.run(_who(config, timeout))


async def _who(config: ClawMeshConfig, threshold: int) -> None:
    from clawmesh.bus.client import BusClient

    try:
        async with BusClient(config) as bus:
            heartbeats = await bus.fetch_messages("org.sys.heartbeat", limit=200)
            presences = await bus.fetch_messages("org.sys.presence", limit=100)
    except Exception as e:
        console.print(f"[red]Failed to query: {e}[/red]")
        raise typer.Exit(1)

    now_ms = int(time.time() * 1000)
    threshold_ms = threshold * 1000

    bots: dict[str, dict] = {}

    for msg in presences:
        bot_id = msg.from_id
        if bot_id not in bots or msg.timestamp > bots[bot_id].get("ts", 0):
            bots[bot_id] = {
                "dept": msg.metadata.get("department", ""),
                "status": msg.content,
                "ts": msg.timestamp,
            }

    for msg in heartbeats:
        bot_id = msg.from_id
        age = now_ms - msg.timestamp
        if age <= threshold_ms:
            existing = bots.get(bot_id, {})
            if msg.timestamp >= existing.get("ts", 0):
                bots[bot_id] = {
                    "dept": msg.metadata.get("department", ""),
                    "status": "online",
                    "ts": msg.timestamp,
                }

    for bot_id, info in bots.items():
        if info["status"] == "online":
            age = now_ms - info["ts"]
            if age > threshold_ms:
                info["status"] = "offline"

    online = {k: v for k, v in bots.items() if v["status"] == "online"}
    offline = {k: v for k, v in bots.items() if v["status"] != "online"}

    table = Table(title=f"ClawMesh Roster ({len(online)} online)")
    table.add_column("Bot ID", style="bold")
    table.add_column("Department")
    table.add_column("Status")
    table.add_column("Last Seen")

    for bot_id, info in sorted(online.items()):
        age_sec = (now_ms - info["ts"]) // 1000
        table.add_row(
            bot_id,
            info["dept"] or "-",
            "[green]online[/green]",
            f"{age_sec}s ago",
        )

    for bot_id, info in sorted(offline.items()):
        age_sec = (now_ms - info["ts"]) // 1000
        if age_sec < 3600:
            seen = f"{age_sec}s ago"
        else:
            seen = f"{age_sec // 3600}h ago"
        table.add_row(
            bot_id,
            info["dept"] or "-",
            "[dim]offline[/dim]",
            seen,
        )

    console.print(table)

    if not bots:
        console.print(
            "[dim]No bots detected. Make sure daemon is running (clawmesh daemon start)[/dim]"
        )
