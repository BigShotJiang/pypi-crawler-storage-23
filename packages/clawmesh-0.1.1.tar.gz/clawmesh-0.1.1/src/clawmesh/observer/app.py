"""ClawMesh Observer - TUI for humans to watch bot conversations.

Built with Textual for a rich terminal UI experience.
"""

from __future__ import annotations

import asyncio
import sys

from textual import on, work
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Footer, Header, Input, RichLog, Static

from clawmesh.config import ClawMeshConfig
from clawmesh.protocol.message import Message

CHANNELS = [
    "org.global",
    "org.dept.rd",
    "org.dept.qa",
    "org.dept.ops",
    "org.team.default",
    "org.sys.presence",
]


class ClawMeshObserver(App):
    """Terminal UI to observe bot communications in real-time."""

    CSS = """
    #main {
        height: 1fr;
    }
    #sidebar {
        width: 24;
        border-right: solid $accent;
        padding: 0;
    }
    #sidebar-title {
        text-align: center;
        padding: 0 1;
        text-style: bold;
        background: $accent;
        width: 100%;
        height: 1;
    }
    .ch-btn {
        width: 100%;
        height: 1;
        min-width: 1;
        border: none;
        padding: 0 1;
        text-align: left;
        background: transparent;
    }
    .ch-btn:hover {
        background: $accent 30%;
    }
    .ch-btn.-active {
        background: $accent;
        text-style: bold;
    }
    #chat-area {
        width: 1fr;
    }
    #status-bar {
        height: 1;
        background: $accent;
        padding: 0 1;
        text-style: bold;
    }
    #messages {
        height: 1fr;
        padding: 0 1;
        scrollbar-size: 1 1;
    }
    #msg-input {
        dock: bottom;
        height: 3;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("1", "switch_channel(0)", "#global"),
        ("2", "switch_channel(1)", "#dept.rd"),
        ("3", "switch_channel(2)", "#dept.qa"),
        ("4", "switch_channel(3)", "#dept.ops"),
        ("5", "switch_channel(4)", "#team"),
        ("6", "switch_channel(5)", "#presence"),
    ]

    def __init__(self, config: ClawMeshConfig | None = None, **kwargs):
        super().__init__(**kwargs)
        self._config = config or ClawMeshConfig.load()
        self._current_channel = CHANNELS[0]
        self._seen_ids: set[str] = set()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="main"):
            with Vertical(id="sidebar"):
                yield Static("Channels", id="sidebar-title")
                for i, ch in enumerate(CHANNELS):
                    short = ch.replace("org.", "#")
                    cls = "ch-btn -active" if i == 0 else "ch-btn"
                    yield Button(short, id=f"ch-{i}", classes=cls, variant="default")
            with Vertical(id="chat-area"):
                yield Static(self._status_text(), id="status-bar")
                yield RichLog(id="messages", highlight=True, markup=True, wrap=True)
                yield Input(
                    placeholder="Type a message, Enter to send...",
                    id="msg-input",
                )
        yield Footer()

    def _status_text(self) -> str:
        short = self._current_channel.replace("org.", "#")
        return f" {short}  |  {self._config.bot_id}@{self._config.server}"

    def on_mount(self) -> None:
        self.title = "ClawMesh Observer"
        self.sub_title = f"Watching as {self._config.bot_id}"
        self._refresh_messages()
        self._start_live_feed()

    def _refresh_messages(self) -> None:
        log = self.query_one("#messages", RichLog)
        log.clear()
        self._seen_ids.clear()
        self._load_history()

    @work(thread=True)
    def _load_history(self) -> None:
        from clawmesh.archiver.storage import ArchiveStorage

        try:
            with ArchiveStorage() as storage:
                messages = storage.search(
                    query="", channel=self._current_channel, limit=50
                )
            for msg in messages:
                if msg.id not in self._seen_ids:
                    self._seen_ids.add(msg.id)
                    self._append_message(msg)
        except Exception:
            self.call_from_thread(
                self.query_one("#messages", RichLog).write,
                "[dim]No archived history. Start archiver to enable history.[/dim]",
            )

    @work(thread=True)
    def _start_live_feed(self) -> None:
        import nats

        async def _subscribe():
            connect_opts: dict = {"servers": [self._config.server]}
            if self._config.token:
                connect_opts["token"] = self._config.token

            try:
                nc = await nats.connect(**connect_opts)
                js = nc.jetstream()
                sub = await js.subscribe("org.>", ordered_consumer=True)

                while True:
                    try:
                        msg = await sub.next_msg(timeout=2.0)
                        parsed = Message.from_nats_payload(msg.data)
                        if parsed.id in self._seen_ids:
                            continue
                        self._seen_ids.add(parsed.id)
                        if parsed.to == self._current_channel:
                            self._append_message(parsed)
                    except TimeoutError:
                        continue
            except Exception as e:
                self.call_from_thread(
                    self.query_one("#messages", RichLog).write,
                    f"[red]NATS error: {e}[/red]",
                )

        asyncio.run(_subscribe())

    def _append_message(self, msg: Message) -> None:
        is_system = msg.type.value == "event" and msg.content in (
            "heartbeat",
            "online",
            "offline",
        )
        if is_system:
            text = f"[dim]{msg.short_display()}[/dim]"
        else:
            text = msg.short_display()

        try:
            view = self.query_one("#messages", RichLog)
            self.call_from_thread(view.write, text)
        except Exception:
            pass

    @on(Button.Pressed, ".ch-btn")
    def _on_channel_click(self, event: Button.Pressed) -> None:
        idx = int(event.button.id.split("-")[1])
        self._switch_to(idx)

    def action_switch_channel(self, idx: int) -> None:
        if 0 <= idx < len(CHANNELS):
            self._switch_to(idx)

    def _switch_to(self, idx: int) -> None:
        self._current_channel = CHANNELS[idx]

        for i in range(len(CHANNELS)):
            btn = self.query_one(f"#ch-{i}", Button)
            btn.remove_class("-active")
        self.query_one(f"#ch-{idx}", Button).add_class("-active")

        self.query_one("#status-bar", Static).update(self._status_text())
        self._refresh_messages()

    @on(Input.Submitted, "#msg-input")
    def _on_send(self, event: Input.Submitted) -> None:
        content = event.value.strip()
        if not content:
            return
        event.input.clear()
        self._send_message(content)

    @work(thread=True)
    def _send_message(self, content: str) -> None:
        from clawmesh.bus.client import BusClient

        msg = Message(
            from_id=f"human:{self._config.bot_id}",
            to=self._current_channel,
            content=content,
        )

        async def _publish():
            async with BusClient(self._config) as bus:
                await bus.publish(msg)

        try:
            asyncio.run(_publish())
            self._seen_ids.add(msg.id)
            self._append_message(msg)
        except Exception as e:
            self.call_from_thread(
                self.query_one("#messages", RichLog).write,
                f"[red]Send failed: {e}[/red]",
            )


def main() -> None:
    config = ClawMeshConfig.load()
    if not config.is_configured:
        print("Not configured. Run `clawmesh login` first.")
        sys.exit(1)
    app = ClawMeshObserver(config)
    app.run()


if __name__ == "__main__":
    main()
