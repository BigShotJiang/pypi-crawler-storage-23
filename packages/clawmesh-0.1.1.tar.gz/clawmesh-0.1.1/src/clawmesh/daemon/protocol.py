"""JSON-RPC style protocol for CLI <-> Daemon IPC communication.

Messages are newline-delimited JSON over Unix socket.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel


class DaemonMethod(StrEnum):
    SHOUT = "shout"
    FETCH = "fetch"
    DM = "dm"
    WHOAMI = "whoami"
    STATUS = "status"
    PING = "ping"


class DaemonRequest(BaseModel):
    method: DaemonMethod
    params: dict[str, Any] = {}
    id: int = 0

    def to_bytes(self) -> bytes:
        return self.model_dump_json().encode("utf-8") + b"\n"

    @classmethod
    def from_bytes(cls, data: bytes) -> DaemonRequest:
        return cls.model_validate_json(data.strip())


class DaemonResponse(BaseModel):
    result: Any | None = None
    error: str | None = None
    id: int = 0

    @property
    def ok(self) -> bool:
        return self.error is None

    def to_bytes(self) -> bytes:
        return self.model_dump_json().encode("utf-8") + b"\n"

    @classmethod
    def from_bytes(cls, data: bytes) -> DaemonResponse:
        return cls.model_validate_json(data.strip())

    @classmethod
    def success(cls, result: Any, req_id: int = 0) -> DaemonResponse:
        return cls(result=result, id=req_id)

    @classmethod
    def fail(cls, error: str, req_id: int = 0) -> DaemonResponse:
        return cls(error=error, id=req_id)
