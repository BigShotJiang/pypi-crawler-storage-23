"""Local message cache for the daemon.

Maintains a bounded deque per channel for fast local access,
avoiding repeated JetStream fetches for recent messages.
"""

from __future__ import annotations

from collections import defaultdict, deque

from clawmesh.protocol.message import Message

DEFAULT_MAX_PER_CHANNEL = 200


class MessageCache:
    """In-memory bounded cache of recent messages per channel."""

    def __init__(self, max_per_channel: int = DEFAULT_MAX_PER_CHANNEL):
        self._max = max_per_channel
        self._channels: dict[str, deque[Message]] = defaultdict(
            lambda: deque(maxlen=self._max)
        )

    def push(self, channel: str, message: Message) -> None:
        self._channels[channel].append(message)

    def get(self, channel: str, limit: int = 10) -> list[Message]:
        msgs = self._channels.get(channel)
        if not msgs:
            return []
        if limit >= len(msgs):
            return list(msgs)
        return list(msgs)[-limit:]

    def channel_count(self) -> int:
        return len(self._channels)

    def total_messages(self) -> int:
        return sum(len(q) for q in self._channels.values())

    def clear(self) -> None:
        self._channels.clear()
