"""Request handler for daemon IPC commands.

Routes JSON-RPC requests to the appropriate bus operations.
"""

from __future__ import annotations

import time

from clawmesh.bus.client import BusClient
from clawmesh.config import ClawMeshConfig
from clawmesh.daemon.cache import MessageCache
from clawmesh.daemon.protocol import DaemonMethod, DaemonRequest, DaemonResponse
from clawmesh.protocol.channels import Channel, validate_channel
from clawmesh.protocol.message import Message, MessageType


class RequestHandler:
    """Processes incoming daemon requests against the bus and cache."""

    def __init__(self, bus: BusClient, config: ClawMeshConfig, cache: MessageCache):
        self._bus = bus
        self._config = config
        self._cache = cache
        self._start_time = time.time()

    async def handle(self, request: DaemonRequest) -> DaemonResponse:
        try:
            match request.method:
                case DaemonMethod.SHOUT:
                    return await self._handle_shout(request)
                case DaemonMethod.FETCH:
                    return await self._handle_fetch(request)
                case DaemonMethod.DM:
                    return await self._handle_dm(request)
                case DaemonMethod.STATUS:
                    return self._handle_status(request)
                case DaemonMethod.PING:
                    return DaemonResponse.success("pong", request.id)
                case _:
                    return DaemonResponse.fail(f"Unknown method: {request.method}", request.id)
        except Exception as e:
            return DaemonResponse.fail(str(e), request.id)

    async def _handle_shout(self, req: DaemonRequest) -> DaemonResponse:
        channel = req.params.get("channel", "")
        content = req.params.get("content", "")
        msg_type = req.params.get("type", "chat")

        if not validate_channel(channel):
            return DaemonResponse.fail(f"Invalid channel: {channel}", req.id)

        msg = Message(
            from_id=self._config.bot_id,
            to=channel,
            type=MessageType(msg_type),
            content=content,
            metadata={"department": self._config.department} if self._config.department else {},
        )
        await self._bus.publish(msg)
        self._cache.push(channel, msg)
        return DaemonResponse.success({"status": "ok", "msg_id": msg.id}, req.id)

    async def _handle_fetch(self, req: DaemonRequest) -> DaemonResponse:
        channel = req.params.get("channel", "")
        limit = req.params.get("limit", 10)

        if not validate_channel(channel):
            return DaemonResponse.fail(f"Invalid channel: {channel}", req.id)

        cached = self._cache.get(channel, limit)
        if len(cached) >= limit:
            messages = [m.model_dump() for m in cached[-limit:]]
        else:
            fetched = await self._bus.fetch_messages(channel, limit=limit)
            for m in fetched:
                self._cache.push(channel, m)
            messages = [m.model_dump() for m in fetched]

        return DaemonResponse.success({"messages": messages}, req.id)

    async def _handle_dm(self, req: DaemonRequest) -> DaemonResponse:
        target = req.params.get("target", "")
        content = req.params.get("content", "")

        channel = Channel.dm(self._config.bot_id, target)
        msg = Message(
            from_id=self._config.bot_id,
            to=channel.subject,
            type=MessageType.CHAT,
            content=content,
        )
        await self._bus.publish(msg)
        self._cache.push(channel.subject, msg)
        return DaemonResponse.success({"status": "ok", "msg_id": msg.id}, req.id)

    def _handle_status(self, req: DaemonRequest) -> DaemonResponse:
        uptime = int(time.time() - self._start_time)
        return DaemonResponse.success(
            {
                "bot_id": self._config.bot_id,
                "server": self._config.server,
                "connected": self._bus.is_connected,
                "uptime_seconds": uptime,
                "cached_channels": self._cache.channel_count(),
                "cached_messages": self._cache.total_messages(),
            },
            req.id,
        )
