"""Daemon process lifecycle management.

Handles PID file, socket path, and process start/stop operations.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from clawmesh.config import ensure_clawmesh_dir

DAEMON_PID_FILE = "daemon.pid"
DAEMON_SOCK_FILE = "daemon.sock"
DAEMON_LOG_FILE = "daemon.log"


def get_pid_path() -> Path:
    return ensure_clawmesh_dir() / DAEMON_PID_FILE


def get_sock_path() -> Path:
    return ensure_clawmesh_dir() / DAEMON_SOCK_FILE


def get_log_path() -> Path:
    return ensure_clawmesh_dir() / DAEMON_LOG_FILE


def read_pid() -> int | None:
    pid_path = get_pid_path()
    if not pid_path.exists():
        return None
    try:
        pid = int(pid_path.read_text().strip())
        os.kill(pid, 0)
        return pid
    except (ValueError, ProcessLookupError, PermissionError):
        pid_path.unlink(missing_ok=True)
        return None


def write_pid(pid: int) -> None:
    get_pid_path().write_text(str(pid))


def is_running() -> bool:
    return read_pid() is not None


def is_socket_available() -> bool:
    sock = get_sock_path()
    return sock.exists()


def start_daemon() -> int | None:
    """Start daemon as a detached subprocess. Returns PID if successful."""
    if is_running():
        return read_pid()

    get_sock_path().unlink(missing_ok=True)

    log_path = get_log_path()
    log_file = open(log_path, "a")

    proc = subprocess.Popen(
        [sys.executable, "-m", "clawmesh.daemon.server"],
        stdout=log_file,
        stderr=log_file,
        start_new_session=True,
    )

    for _ in range(30):
        time.sleep(0.2)
        if get_sock_path().exists():
            return proc.pid
        if proc.poll() is not None:
            return None

    return proc.pid if proc.poll() is None else None


def stop_daemon() -> bool:
    """Stop the running daemon. Returns True if stopped successfully."""
    pid = read_pid()
    if pid is None:
        return False

    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(25):
            time.sleep(0.2)
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
        else:
            os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass

    get_pid_path().unlink(missing_ok=True)
    get_sock_path().unlink(missing_ok=True)
    return True
