"""ClawMesh message protocol definition."""

from __future__ import annotations

import time
from datetime import UTC
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field
from uuid_extensions import uuid7


class MessageType(StrEnum):
    """Types of messages that can flow through the bus."""

    CHAT = "chat"
    TASK = "task"
    EVENT = "event"
    ACK = "ack"
    QUERY = "query"


class Message(BaseModel):
    """Core message structure for all ClawMesh communications.

    Uses UUID v7 for time-ordered IDs, enabling natural chronological sorting
    without relying solely on timestamps.
    """

    id: str = Field(default_factory=lambda: str(uuid7()))
    from_id: str = Field(description="Sender bot ID")
    to: str = Field(description="Target channel or bot ID")
    type: MessageType = MessageType.CHAT
    content: str = ""
    reply_to: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: int = Field(default_factory=lambda: int(time.time() * 1000))

    def to_nats_payload(self) -> bytes:
        return self.model_dump_json().encode("utf-8")

    @classmethod
    def from_nats_payload(cls, data: bytes) -> Message:
        return cls.model_validate_json(data)

    def short_display(self) -> str:
        """Format for CLI output: [time] sender > content"""
        from datetime import datetime

        dt = datetime.fromtimestamp(self.timestamp / 1000, tz=UTC)
        time_str = dt.strftime("%H:%M:%S")
        return f"[{time_str}] {self.from_id} > {self.content}"
