"""
WMO BUFR4 Code/Flag Mappings for SIGWX XML Parsing.
Provides offline, in-memory lookups to dynamically append human-readable
weather phenomena data into dictionaries without making network calls.
"""

WMO_TABLE_KEYS = {
    "0-20-041": "degree_of_icing",
    "0-11-030": "extended_degree_of_turbulence",
    "0-11-031": "degree_of_turbulence",
    "0-20-012": "cloud_type",
    "0-20-008": "cloud_distribution"
}

WMO_BUFR4_MAP = {
    # ---------------------------------------------------------
    # 0-20-041: Airframe Icing
    # ---------------------------------------------------------
    "0-20-041": {
        "0": "No icing",
        "1": "Light icing",
        "2": "Light icing in cloud",
        "3": "Light icing in precipitation",
        "4": "Moderate icing",
        "5": "Moderate icing in cloud",
        "6": "Moderate icing in precipitation",
        "7": "Severe icing",
        "8": "Severe icing in cloud",
        "9": "Severe icing in precipitation",
        "10": "Trace of icing",
        "11": "Trace of icing in cloud",
        "12": "Trace of icing in precipitation",
        "15": "Missing value"
    },

    # ---------------------------------------------------------
    # 0-11-030: Extended Degree of Turbulence
    # ---------------------------------------------------------
    "0-11-030": {
        "0": "Nil",
        "1": "Light",
        "2": "Moderate",
        "3": "Severe",
        "12": "Extreme, in clear air",
        "13": "Extreme, in cloud",
        "14": "Extreme, cloud/clear air not specified",
        "15": "Light, isolated moderate",
        "16": "Light, occasional moderate",
        "17": "Light, frequently moderate",
        "18": "Moderate, isolated severe",
        "19": "Moderate, occasional severe",
        "31": "Missing value"
    },

    # ---------------------------------------------------------
    # 0-11-031: Degree of Turbulence
    # ---------------------------------------------------------
    "0-11-031": {
        "0": "Nil, in cloud",
        "1": "Light, in cloud",
        "2": "Moderate, in cloud",
        "3": "Severe, in cloud",
        "4": "Nil, in clear air",
        "5": "Light, in clear air",
        "6": "Moderate, in clear air",
        "7": "Severe, in clear air",
        "8": "Nil, cloud/clear air not specified",
        "9": "Light, cloud/clear air not specified",
        "10": "Moderate, cloud/clear air not specified",
        "11": "Severe, cloud/clear air not specified",
        "12": "Extreme, in clear air",
        "13": "Extreme, in cloud",
        "14": "Extreme, cloud/clear air not specified",
        "15": "Missing value"
    },

    # ---------------------------------------------------------
    # 0-20-012: Cloud Types (Significant Aviation & Genus list)
    # ---------------------------------------------------------
    "0-20-012": {
        "0": "Cirrus (Ci)",
        "1": "Cirrocumulus (Cc)",
        "2": "Cirrostratus (Cs)",
        "3": "Altocumulus (Ac)",
        "4": "Altostratus (As)",
        "5": "Nimbostratus (Ns)",
        "6": "Stratocumulus (Sc)",
        "7": "Stratus (St)",
        "8": "Cumulus (Cu)",
        "9": "Cumulonimbus (Cb)",
        "10": "Cirrus fibratus, sometimes uncinus",
        "11": "Cirrus spissatus, in patches or entangled sheaves",
        "12": "Cirrus spissatus cumulonimbogenitus",
        "13": "Cirrus uncinus or fibratus, invading the sky",
        "14": "Cirrus and Cirrostratus, or Cirrostratus alone, < 45 degrees",
        "15": "Cirrus and Cirrostratus, or Cirrostratus alone, > 45 degrees",
        "16": "Cirrostratus covering the whole sky",
        "17": "Cirrostratus not progressively invading the sky",
        "18": "Cirrocumulus alone, or Cirrocumulus predominant",
        "20": "Altostratus translucidus",
        "21": "Altostratus opacus or Nimbostratus",
        "22": "Altocumulus translucidus at a single level",
        "23": "Altocumulus translucidus in patches (lenticular)",
        "24": "Altocumulus translucidus in bands, progressively invading",
        "25": "Altocumulus cumulogenitus (or cumulonimbogenitus)",
        "26": "Altocumulus opacus in two or more layers",
        "27": "Altocumulus castellanus or floccus",
        "28": "Altocumulus of a chaotic sky, generally with Ac",
        "30": "Cumulus humilis or fractus (no bad weather)",
        "31": "Cumulus mediocris or congestus",
        "32": "Cumulonimbus calvus",
        "33": "Stratocumulus cumulogenitus",
        "34": "Stratocumulus other than cumulogenitus",
        "35": "Stratus nebulosus or fractus",
        "36": "Stratus fractus or Cumulus fractus of bad weather",
        "37": "Cumulus and Stratocumulus (bases at different levels)",
        "38": "Cumulonimbus capillatus (often with anvil)",
        "60": "Clear sky",
        "61": "Clouds invisible (owing to darkness, fog, etc.)",
        "62": "Clouds not visible (other reasons)",
        "63": "Missing value"
    },

    # ---------------------------------------------------------
    # 0-20-008: Cloud Distribution for Aviation (SIGWX)
    # ---------------------------------------------------------
    "0-20-008": {
        "0": "Sky clear",
        "1": "Few",
        "2": "Scattered",
        "3": "Broken",
        "4": "Overcast",
        "6": "Scattered/broken",
        "7": "Broken/overcast",
        "8": "Isolated",
        "9": "Isolated embedded",
        "10": "Occasional",
        "11": "Occasional embedded",
        "12": "Frequent",
        "13": "Dense",
        "14": "Layers",
        "15": "Obscured (OBSC)",
        "16": "Embedded (EMBD)",
        "17": "Frequent embedded",
        "31": "Missing value"
    }
}


def extract_wmo_data(url: str) -> dict:
    """
    Parses a WMO URL and returns a structured dictionary for easy kwargs/dict unpacking.

    Args:
        url (str): The full or partial WMO BUFR4 codeflag URL.
                   e.g., 'http://codes.wmo.int/bufr4/codeflag/0-20-041/7'

    Returns:
        dict: A dictionary with a descriptive key and the mapped string value.
              e.g., {'degree_of_icing': 'Severe icing'}
    """
    if not url or not isinstance(url, str):
        return {"wmo_error": "Invalid or missing URL string"}

    parts = url.strip('/').split('/')

    if len(parts) >= 2:
        table_id = parts[-2]
        code = parts[-1]

        dict_key = WMO_TABLE_KEYS.get(table_id, f"wmo_unknown_{table_id.replace('-', '_')}")

        value = WMO_BUFR4_MAP.get(table_id, {}).get(code, f"Unknown Code: {code}")

        return {dict_key: value}

    return {"wmo_error": "URL format not recognized"}