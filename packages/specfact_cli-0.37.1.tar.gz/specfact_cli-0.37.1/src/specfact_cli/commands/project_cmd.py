"""Backward-compatible app shim. Implementation moved to modules/project/."""

from specfact_cli.modules.project.src.commands import app


__all__ = ["app"]
