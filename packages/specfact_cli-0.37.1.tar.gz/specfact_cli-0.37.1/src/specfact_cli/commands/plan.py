"""Backward-compatible app shim. Implementation moved to modules/plan/."""

from specfact_cli.modules.plan.src.commands import app


__all__ = ["app"]
