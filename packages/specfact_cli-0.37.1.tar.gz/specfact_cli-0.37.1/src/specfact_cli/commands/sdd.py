"""Backward-compatible app shim. Implementation moved to modules/sdd/."""

from specfact_cli.modules.sdd.src.commands import app


__all__ = ["app"]
