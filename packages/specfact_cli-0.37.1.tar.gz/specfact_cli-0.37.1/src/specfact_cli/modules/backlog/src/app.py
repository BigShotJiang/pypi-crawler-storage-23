"""backlog command entrypoint."""

from specfact_cli.modules.backlog.src.commands import app


__all__ = ["app"]
