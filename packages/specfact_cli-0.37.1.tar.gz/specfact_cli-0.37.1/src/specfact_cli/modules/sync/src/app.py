"""sync command entrypoint."""

from specfact_cli.modules.sync.src.commands import app


__all__ = ["app"]
