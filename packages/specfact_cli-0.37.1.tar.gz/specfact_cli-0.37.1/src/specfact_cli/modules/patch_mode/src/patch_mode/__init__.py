"""Patch mode: previewable and confirmable patch pipeline."""

from specfact_cli.modules.patch_mode.src.patch_mode.commands.apply import app


__all__ = ["app"]
