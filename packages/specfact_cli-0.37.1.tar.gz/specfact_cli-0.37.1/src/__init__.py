"""
SpecFact CLI - Spec→Contract→Sentinel tool for contract-driven development.
"""

# Package version: keep in sync with pyproject.toml, setup.py, src/specfact_cli/__init__.py
__version__ = "0.36.1"
