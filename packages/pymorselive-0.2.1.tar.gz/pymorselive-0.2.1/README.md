# PyMorseLive

Simple multi-channel timing-based morse decoder written in Python.

<img width="1400" height="300" alt="screenshot" src="https://github.com/user-attachments/assets/aa54e4ad-eec9-434b-9aca-ad6e9cfaa32b" />


# THIS README WILL BE REWRITTEN SOON 
This is the first release to PyPi

The video below shows a prior version

https://github.com/user-attachments/assets/5e488738-7636-4507-8d3a-ad95597822c1

## Installation
To be written but pip install PyMorseLive, open a command window and type pymorse

Alternatively download the source file (there's only one currently in the pymorse folder) and edit it as needed.
