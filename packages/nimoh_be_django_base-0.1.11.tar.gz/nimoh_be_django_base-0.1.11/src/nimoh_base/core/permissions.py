"""Custom DRF permissions"""

from rest_framework import permissions


class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    Object-level permission to only allow owners of an object to edit it.
    """

    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any request,
        # so we'll always allow GET, HEAD or OPTIONS requests.
        if request.method in permissions.SAFE_METHODS:
            return True

        # Instance must have an attribute named `owner` or `user`.
        owner = getattr(obj, "owner", None) or getattr(obj, "user", None)
        return owner == request.user


class IsAdminOrReadOnly(permissions.BasePermission):
    """
    Permission to only allow admin users to edit.
    """

    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True

        return request.user and request.user.is_staff


class IsVerifiedUser(permissions.BasePermission):
    """
    Permission to only allow verified users.
    """

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and getattr(request.user, "is_verified", True)


class CanManageDevices(permissions.BasePermission):
    """
    Permission to allow users to manage their own devices/sessions.
    Admins can manage all devices.
    """

    def has_permission(self, request, view):
        """Check if user is authenticated."""
        return request.user and request.user.is_authenticated

    def has_object_permission(self, request, view, obj):
        """Check if user owns the device/session or is admin."""
        # Admin users can manage all devices
        if request.user.is_staff or request.user.is_superuser:
            return True

        # Users can only manage their own devices/sessions
        owner = getattr(obj, "user", None)
        return owner == request.user
