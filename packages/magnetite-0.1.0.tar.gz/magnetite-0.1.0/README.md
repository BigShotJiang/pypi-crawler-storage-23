# Magnetite

WIP Rust-Python monorepo

