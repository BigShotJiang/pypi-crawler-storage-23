"""
AoJia Core Module

Provides the core AoJia class and exceptions.
"""

from typing import Any, Optional


class AoJiaError(Exception):
    """Base exception for AoJia library errors."""
    pass


class AoJiaNotInitializedError(AoJiaError):
    """Raised when AoJia object is not initialized."""
    pass


class AoJiaCOMError(AoJiaError):
    """Raised when COM operation fails."""
    pass


class AoJiaBase:
    """Base class for AoJia COM object wrapper.
    
    This class provides the foundation for all AoJia operations.
    Subclasses should implement specific functionality modules.
    """
    
    _com_obj: Optional[Any] = None
    _initialized: bool = False
    
    def __init__(self, com_obj: Optional[Any] = None):
        """Initialize AoJia object.
        
        Args:
            com_obj: Pre-existing COM object to wrap. If None, creates new instance.
        """
        if com_obj is not None:
            self._com_obj = com_obj
            self._initialized = True
    
    def _ensure_initialized(self) -> None:
        """Ensure the COM object is initialized.
        
        Raises:
            AoJiaNotInitializedError: If object is not initialized
        """
        if not self._initialized or self._com_obj is None:
            raise AoJiaNotInitializedError(
                "AoJia object not initialized. Call initialize() first."
            )
    
    def _call_method(self, method_name: str, *args) -> Any:
        """Call a method on the COM object.
        
        Args:
            method_name: Name of the method to call
            *args: Arguments to pass to the method
            
        Returns:
            Method return value
            
        Raises:
            AoJiaCOMError: If method call fails
        """
        self._ensure_initialized()
        try:
            method = getattr(self._com_obj, method_name)
            return method(*args)
        except AttributeError:
            raise AoJiaCOMError(f"Method '{method_name}' not found on COM object")
        except Exception as e:
            raise AoJiaCOMError(f"Failed to call '{method_name}': {e}")
    
    def _get_property(self, prop_name: str) -> Any:
        """Get a property value from the COM object.
        
        Args:
            prop_name: Name of the property
            
        Returns:
            Property value
            
        Raises:
            AoJiaCOMError: If property access fails
        """
        self._ensure_initialized()
        try:
            return getattr(self._com_obj, prop_name)
        except AttributeError:
            raise AoJiaCOMError(f"Property '{prop_name}' not found on COM object")
        except Exception as e:
            raise AoJiaCOMError(f"Failed to get property '{prop_name}': {e}")
    
    def _set_property(self, prop_name: str, value: Any) -> None:
        """Set a property value on the COM object.
        
        Args:
            prop_name: Name of the property
            value: Value to set
            
        Raises:
            AoJiaCOMError: If property access fails
        """
        self._ensure_initialized()
        try:
            setattr(self._com_obj, prop_name, value)
        except AttributeError:
            raise AoJiaCOMError(f"Property '{prop_name}' not found on COM object")
        except Exception as e:
            raise AoJiaCOMError(f"Failed to set property '{prop_name}': {e}")
    
    @property
    def com_object(self) -> Any:
        """Get the underlying COM object.
        
        Returns:
            The COM object instance
        """
        self._ensure_initialized()
        return self._com_obj
    
    @property
    def is_initialized(self) -> bool:
        """Check if the object is initialized.
        
        Returns:
            True if initialized, False otherwise
        """
        return self._initialized
    
    @staticmethod
    def _create_variant() -> Any:
        """Create a VARIANT object for COM calls.
        
        Returns:
            A mutable variant object
        """
        from win32com.client import VARIANT
        import pythoncom
        return VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    
    def release(self) -> None:
        """Release the COM object resources."""
        if self._com_obj is not None:
            try:
                import win32com.client
                if hasattr(self._com_obj, '_oleobj_'):
                    self._com_obj._oleobj_.Release()
            except:
                pass
            self._com_obj = None
            self._initialized = False
