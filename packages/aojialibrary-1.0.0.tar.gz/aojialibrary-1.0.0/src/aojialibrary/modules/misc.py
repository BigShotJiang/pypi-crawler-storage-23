"""
Miscellaneous Operations Module

Provides system, network, and utility operations for AoJia.
"""

from typing import Tuple
from ..core import AoJiaBase


class MiscMixin(AoJiaBase):
    """Mixin class for miscellaneous operations."""
    
    # ==================== System Information ====================
    
    def get_os(self, info_type: int = 0) -> Tuple[int, str, str, str, str]:
        """Get operating system information.
        
        Args:
            info_type: Info type
            
        Returns:
            Tuple of (result, version, version_name, build, dir)
        """
        v, vn, vbn, d = self._create_variant(), self._create_variant(), \
                        self._create_variant(), self._create_variant()
        result = self._call_method('GetOs', v, vn, vbn, d, info_type)
        return result, v.value, vn.value, vbn.value, d.value
    
    def get_cpu(self) -> Tuple[int, str, str]:
        """Get CPU information.
        
        Returns:
            Tuple of (result, cpu_type, cpu_id)
        """
        cpu_type, cpu_id = self._create_variant(), self._create_variant()
        result = self._call_method('GetCPU', cpu_type, cpu_id)
        return result, cpu_type.value, cpu_id.value
    
    def get_cpu_rate(self) -> int:
        """Get CPU usage rate.
        
        Returns:
            CPU usage percentage
        """
        return self._call_method('GetCPURate')
    
    def get_memory(self) -> Tuple[int, int, int]:
        """Get memory information.
        
        Returns:
            Tuple of (result, total_physical, available_physical)
        """
        t_phy, a_phy = self._create_variant(), self._create_variant()
        result = self._call_method('GetMemory', t_phy, a_phy)
        return result, t_phy.value, a_phy.value
    
    def get_mac(self) -> str:
        """Get MAC address.
        
        Returns:
            MAC address string
        """
        return self._call_method('GetMAC')
    
    def get_machine_code(self) -> str:
        """Get machine code for licensing.
        
        Returns:
            Machine code string
        """
        return self._call_method('GetMachineCode')
    
    def get_disk(self) -> Tuple[str, str, str]:
        """Get disk information.
        
        Returns:
            Tuple of (serial, model, revision)
        """
        model, revision = self._create_variant(), self._create_variant()
        result = self._call_method('GetDisk', model, revision)
        return result, model.value, revision.value
    
    def get_disk_size(self) -> str:
        """Get disk size.
        
        Returns:
            Disk size string
        """
        return self._call_method('GetDiskSize')
    
    def get_uac(self) -> int:
        """Get UAC status.
        
        Returns:
            UAC level
        """
        return self._call_method('GetUAC')
    
    def set_uac(self, uac_level: int) -> int:
        """Set UAC level.
        
        Args:
            uac_level: UAC level
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetUAC', uac_level)
    
    # ==================== Time Operations ====================
    
    def get_time(self) -> int:
        """Get current timestamp in milliseconds.
        
        Returns:
            Timestamp in milliseconds
        """
        return self._call_method('GetTime')
    
    def get_system_time(self) -> str:
        """Get system time string.
        
        Returns:
            Time string
        """
        return self._call_method('GetSystemTime')
    
    def set_system_time(self, time_str: str) -> int:
        """Set system time.
        
        Args:
            time_str: Time string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetSystemTime', time_str)
    
    # ==================== Power Management ====================
    
    def get_power(self) -> Tuple[int, int, int]:
        """Get power status.
        
        Returns:
            Tuple of (result, voltage, status)
        """
        vt, st = self._create_variant(), self._create_variant()
        result = self._call_method('GetPower', vt, st)
        return result, vt.value, st.value
    
    def set_power(self, voltage: int, status: int) -> int:
        """Set power state.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetPower', voltage, status)
    
    def set_power_state(self, state_type: int) -> int:
        """Set power state (sleep, hibernate, etc.).
        
        Args:
            state_type: Power state type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetPowerState', state_type)
    
    # ==================== Display Settings ====================
    
    def set_aero(self, aero_type: int) -> int:
        """Enable/disable Windows Aero.
        
        Args:
            aero_type: 1=enable, 0=disable
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetAero', aero_type)
    
    def get_font_smoothing(self) -> int:
        """Get font smoothing status.
        
        Returns:
            1=enabled, 0=disabled
        """
        return self._call_method('GetFontSmoothing')
    
    def set_font_smoothing(self, smooth_type: int) -> int:
        """Set font smoothing.
        
        Args:
            smooth_type: Smoothing type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetFontSmoothing', smooth_type)
    
    def set_screen_save(self, save_type: int) -> int:
        """Set screen saver status.
        
        Args:
            save_type: 1=enable, 0=disable
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetScreenSave', save_type)
    
    # ==================== Desktop Area ====================
    
    def set_desktop_area(self, hwnd: int, dx1: int, dy1: int,
                         dx2: int, dy2: int, flag: int,
                         area_type: int) -> int:
        """Set desktop work area.
        
        Args:
            hwnd: Window handle
            dx1: Left coordinate of area
            dy1: Top coordinate of area
            dx2: Right coordinate of area
            dy2: Bottom coordinate of area
            flag: Flag
            area_type: Area type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetDesktopArea', hwnd, dx1, dy1, dx2, dy2, flag, area_type)
    
    def set_exclude_area(self, area_type: int, area_data: str) -> int:
        """Set exclude area.
        
        Args:
            area_type: Area type
            area_data: Area data string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetExcludeArea', area_type, area_data)
    
    # ==================== Sound Operations ====================
    
    def beep(self, frequency: int, duration: int) -> int:
        """Play system beep.
        
        Args:
            frequency: Frequency in Hz
            duration: Duration in milliseconds
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('Beep', frequency, duration)
    
    def get_beep(self) -> int:
        """Get beep status.
        
        Returns:
            Beep status
        """
        return self._call_method('GetBeep')
    
    def set_beep(self, beep_type: int) -> int:
        """Set beep mode.
        
        Args:
            beep_type: Beep type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetBeep', beep_type)
    
    def play_music(self, file_path: str) -> int:
        """Play music file.
        
        Args:
            file_path: Music file path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('PlayMusic', file_path)
    
    def stop_music(self) -> int:
        """Stop music playback.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('StopMusic')
    
    # ==================== Network Operations ====================
    
    def download_file(self, url: str, save_path: str,
                      async_mode: int = 0) -> int:
        """Download file from URL.
        
        Args:
            url: Download URL
            save_path: Local save path
            async_mode: 1=async, 0=sync
            
        Returns:
            1 on success (sync) or download ID (async), 0 on failure
        """
        return self._call_method('DownloadFile', url, save_path, async_mode)
    
    def get_download_state(self) -> int:
        """Get download state.
        
        Returns:
            Download state (0=not downloading, 1=downloading, 2=complete, 3=error)
        """
        return self._call_method('GetDownloadState')
    
    def open_url(self, url: str) -> int:
        """Open URL in default browser.
        
        Args:
            url: URL to open
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('OpenURL', url)
    
    # ==================== Utility Functions ====================
    
    def random(self, min_val: int, max_val: int) -> int:
        """Generate random integer.
        
        Args:
            min_val: Minimum value
            max_val: Maximum value
            
        Returns:
            Random integer
        """
        return self._call_method('SuiJi', min_val, max_val)
    
    def random_str(self, length: int, str_type: int) -> str:
        """Generate random string.
        
        Args:
            length: String length
            str_type: String type (0=numbers, 1=letters, 2=alphanumeric)
            
        Returns:
            Random string
        """
        return self._call_method('SuiJiMZ', length, str_type)
    
    def delay(self, min_ms: int, max_ms: int) -> int:
        """Random delay.
        
        Args:
            min_ms: Minimum delay in milliseconds
            max_ms: Maximum delay in milliseconds
            
        Returns:
            1 on success
        """
        return self._call_method('YanShi', min_ms, max_ms)
    
    def msg(self, x: int, y: int, color: str, bk_color: str,
            fm_color: str, text: str, timeout: int) -> int:
        """Show message box.
        
        Args:
            x: X position
            y: Y position
            color: Text color
            bk_color: Background color
            fm_color: Frame color
            text: Message text
            timeout: Timeout in milliseconds
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('Msg', x, y, color, bk_color, fm_color, text, timeout)
    
    def t_msg(self, flag: int, title: str, text: str,
              msg_type: int) -> int:
        """Show timed message box.
        
        Args:
            flag: Flag
            title: Window title
            text: Message text
            msg_type: Message type
            
        Returns:
            Button clicked
        """
        return self._call_method('TMsg', flag, title, text, msg_type)
    
    def cmd(self, command: str, cmd_type: int) -> int:
        """Execute command.
        
        Args:
            command: Command string
            cmd_type: Command type
            
        Returns:
            Command result
        """
        return self._call_method('Cmd', command, cmd_type)
    
    def exit_os(self, exit_type: int) -> int:
        """Exit operating system.
        
        Args:
            exit_type: 0=shutdown, 1=reboot, 2=logoff
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('ExitOs', exit_type)
    
    # ==================== Simulation Mode ====================
    
    def set_sim_mode(self, mode: int) -> int:
        """Set input simulation mode.
        
        Args:
            mode: Simulation mode (0=normal, 1=hardware, etc.)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetSimMode', mode)
    
    def gai_lu(self, probability: int) -> int:
        """Set probability for random operations.
        
        Args:
            probability: Probability percentage
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('GaiLu', probability)
    
    # ==================== Error Handling ====================
    
    def get_last_error(self) -> int:
        """Get last error code.
        
        Returns:
            Last error code
        """
        return self._call_method('GetLastError')
    
    def set_error_msg(self, msg_type: int) -> int:
        """Set error message mode.
        
        Args:
            msg_type: 1=show message, 0=hide
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetErrorMsg', msg_type)
    
    # ==================== Version ====================
    
    def ver_s(self) -> str:
        """Get plugin version.
        
        Returns:
            Version string
        """
        return self._call_method('VerS')
    
    def get_ao_jia_id(self) -> int:
        """Get AoJia ID.
        
        Returns:
            AoJia ID
        """
        return self._call_method('GetAoJiaID')
    
    def get_ao_jia_num(self) -> int:
        """Get AoJia number.
        
        Returns:
            AoJia number
        """
        return self._call_method('GetAoJiaNum')
    
    def reg_d(self, reg_code: str, reg_type: int) -> int:
        """Register AoJia.
        
        Args:
            reg_code: Registration code
            reg_type: Registration type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('RegD', reg_code, reg_type)
    
    def get_gc(self) -> str:
        """Get garbage collection info.
        
        Returns:
            GC info string
        """
        return self._call_method('GetGc')
    
    def set_thread(self, thread_num: int) -> int:
        """Set thread number.
        
        Args:
            thread_num: Thread number
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetThread', thread_num)
    
    # ==================== Assembly ====================
    
    def asm(self, asm_str: str) -> str:
        """Execute assembly code.
        
        Args:
            asm_str: Assembly code string
            
        Returns:
            Result string
        """
        return self._call_method('Asm', asm_str)
    
    def asm_add(self, asm_str: str) -> int:
        """Add assembly instruction.
        
        Args:
            asm_str: Assembly instruction string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('AsmAdd', asm_str)
    
    def asm_call(self, pid: int, hwnd: int) -> int:
        """Call assembled code.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            
        Returns:
            Call result
        """
        return self._call_method('AsmCall', pid, hwnd)
    
    def asm_clear(self) -> int:
        """Clear assembly buffer.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('AsmClear')
    
    def dis_asm(self, asm_str: str) -> str:
        """Disassemble code.
        
        Args:
            asm_str: Code string
            
        Returns:
            Disassembly string
        """
        return self._call_method('DisAsm', asm_str)
    
    # ==================== Error Property ====================
    
    @property
    def aj_error(self) -> int:
        """Get last AoJia error code.
        
        Returns:
            Error code
        """
        return self._get_property('AJError')
