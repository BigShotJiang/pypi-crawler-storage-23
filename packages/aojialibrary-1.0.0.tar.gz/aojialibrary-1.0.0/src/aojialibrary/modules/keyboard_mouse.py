"""
Keyboard and Mouse Operations Module

Provides keyboard and mouse simulation operations for AoJia.
"""

from typing import Tuple
from ..core import AoJiaBase


class KeyboardMouseMixin(AoJiaBase):
    """Mixin class for keyboard and mouse operations."""
    
    # ==================== Mouse Position ====================
    
    def get_mouse_pos(self, pos_type: int = 0) -> Tuple[int, int]:
        """Get current mouse position.
        
        Args:
            pos_type: 0=screen, 1=window
            
        Returns:
            Tuple of (x, y)
        """
        x, y = self._create_variant(), self._create_variant()
        self._call_method('GetMousePos', x, y, pos_type)
        return x.value, y.value
    
    def set_mouse_pos(self, sx1: int, sy1: int, sx2: int, sy2: int,
                      sdxy: int, dx1: int, dy1: int, dx2: int, dy2: int,
                      r_min: int, r_max: int, speed: int, pos_type: int) -> int:
        """Set mouse position range.
        
        Args:
            sx1: Source X1
            sy1: Source Y1
            sx2: Source X2
            sy2: Source Y2
            sdxy: Source delta XY
            dx1: Destination X1
            dy1: Destination Y1
            dx2: Destination X2
            dy2: Destination Y2
            r_min: Minimum random range
            r_max: Maximum random range
            speed: Movement speed
            pos_type: Position type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetMousePos', sx1, sy1, sx2, sy2, sdxy,
                                 dx1, dy1, dx2, dy2, r_min, r_max, speed, pos_type)
    
    def get_mouse_shape(self, shape_type: int, flag: int) -> str:
        """Get current mouse cursor shape.
        
        Args:
            shape_type: Type of shape info
            flag: Additional flags
            
        Returns:
            Mouse shape identifier string
        """
        return self._call_method('GetMouseShape', shape_type, flag)
    
    def get_mouse_hotspot(self, pos_type: int = 0) -> Tuple[int, int]:
        """Get mouse cursor hotspot.
        
        Args:
            pos_type: Position type
            
        Returns:
            Tuple of (x, y) hotspot offset
        """
        x, y = self._create_variant(), self._create_variant()
        self._call_method('GetMouseHotspot', x, y, pos_type)
        return x.value, y.value
    
    # ==================== Mouse Movement ====================
    
    def move_to(self, x: int, y: int) -> int:
        """Move mouse to absolute position.
        
        Args:
            x: Target X coordinate
            y: Target Y coordinate
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveTo', x, y)
    
    def move_to_d(self, x: int, y: int, xr_min: int, xr_max: int,
                  yr_min: int, yr_max: int, r_min: int, r_max: int,
                  speed: int) -> int:
        """Move mouse with random deviation.
        
        Args:
            x: Target X coordinate
            y: Target Y coordinate
            xr_min: X random min deviation
            xr_max: X random max deviation
            yr_min: Y random min deviation
            yr_max: Y random max deviation
            r_min: Minimum random range
            r_max: Maximum random range
            speed: Movement speed
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveToD', x, y, xr_min, xr_max, yr_min, yr_max,
                                 r_min, r_max, speed)
    
    def move_to_q(self, x: int, y: int, xr_min: int, xr_max: int,
                  yr_min: int, yr_max: int, r_min: int, r_max: int,
                  speed: int) -> int:
        """Move mouse with curve trajectory.
        
        Args:
            x: Target X coordinate
            y: Target Y coordinate
            xr_min: X random min deviation
            xr_max: X random max deviation
            yr_min: Y random min deviation
            yr_max: Y random max deviation
            r_min: Minimum random range
            r_max: Maximum random range
            speed: Movement speed
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveToQ', x, y, xr_min, xr_max, yr_min, yr_max,
                                 r_min, r_max, speed)
    
    def move_r(self, rx: int, ry: int) -> int:
        """Move mouse relative to current position.
        
        Args:
            rx: Relative X offset
            ry: Relative Y offset
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveR', rx, ry)
    
    def move_r_d(self, rx: int, ry: int, xr_min: int, xr_max: int,
                 yr_min: int, yr_max: int, r_min: int, r_max: int,
                 speed: int) -> int:
        """Move mouse relative with random deviation.
        
        Args:
            rx: Relative X offset
            ry: Relative Y offset
            xr_min: X random min deviation
            xr_max: X random max deviation
            yr_min: Y random min deviation
            yr_max: Y random max deviation
            r_min: Minimum random range
            r_max: Maximum random range
            speed: Movement speed
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveRD', rx, ry, xr_min, xr_max, yr_min, yr_max,
                                 r_min, r_max, speed)
    
    def move_r_q(self, rx: int, ry: int, xr_min: int, xr_max: int,
                 yr_min: int, yr_max: int, r_min: int, r_max: int,
                 speed: int) -> int:
        """Move mouse relative with curve trajectory.
        
        Args:
            rx: Relative X offset
            ry: Relative Y offset
            xr_min: X random min deviation
            xr_max: X random max deviation
            yr_min: Y random min deviation
            yr_max: Y random max deviation
            r_min: Minimum random range
            r_max: Maximum random range
            speed: Movement speed
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveRQ', rx, ry, xr_min, xr_max, yr_min, yr_max,
                                 r_min, r_max, speed)
    
    # ==================== Mouse Clicks ====================
    
    def left_click(self) -> int:
        """Perform left mouse button click.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LeftClick')
    
    def left_click_d(self, r_min: int, r_max: int,
                     rd_min: int, rd_max: int) -> int:
        """Left click with random delay.
        
        Args:
            r_min: Min click duration (ms)
            r_max: Max click duration (ms)
            rd_min: Min delay after click (ms)
            rd_max: Max delay after click (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LeftClickD', r_min, r_max, rd_min, rd_max)
    
    def left_down(self) -> int:
        """Press left mouse button down.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LeftDown')
    
    def left_up(self) -> int:
        """Release left mouse button.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LeftUp')
    
    def left_double_click(self) -> int:
        """Perform left mouse button double click.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LeftDoubleClick')
    
    def left_double_click_d(self, r_min: int, r_max: int,
                            rd_min: int, rd_max: int,
                            rdr_min: int, rdr_max: int) -> int:
        """Left double click with random delays.
        
        Args:
            r_min: Min first click duration (ms)
            r_max: Max first click duration (ms)
            rd_min: Min delay between clicks (ms)
            rd_max: Max delay between clicks (ms)
            rdr_min: Min second click duration (ms)
            rdr_max: Max second click duration (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LeftDoubleClickD', r_min, r_max, rd_min, rd_max,
                                 rdr_min, rdr_max)
    
    def right_click(self) -> int:
        """Perform right mouse button click.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('RightClick')
    
    def right_click_d(self, r_min: int, r_max: int,
                      rd_min: int, rd_max: int) -> int:
        """Right click with random delay.
        
        Args:
            r_min: Min click duration (ms)
            r_max: Max click duration (ms)
            rd_min: Min delay after click (ms)
            rd_max: Max delay after click (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('RightClickD', r_min, r_max, rd_min, rd_max)
    
    def right_down(self) -> int:
        """Press right mouse button down.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('RightDown')
    
    def right_up(self) -> int:
        """Release right mouse button.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('RightUp')
    
    def right_double_click_d(self, r_min: int, r_max: int,
                             rd_min: int, rd_max: int,
                             rdr_min: int, rdr_max: int) -> int:
        """Right double click with random delays.
        
        Args:
            r_min: Min first click duration (ms)
            r_max: Max first click duration (ms)
            rd_min: Min delay between clicks (ms)
            rd_max: Max delay between clicks (ms)
            rdr_min: Min second click duration (ms)
            rdr_max: Max second click duration (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('RightDoubleClickD', r_min, r_max, rd_min, rd_max,
                                 rdr_min, rdr_max)
    
    def middle_click(self) -> int:
        """Perform middle mouse button click.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MiddleClick')
    
    def middle_click_d(self, r_min: int, r_max: int,
                       rd_min: int, rd_max: int) -> int:
        """Middle click with random delay.
        
        Args:
            r_min: Min click duration (ms)
            r_max: Max click duration (ms)
            rd_min: Min delay after click (ms)
            rd_max: Max delay after click (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MiddleClickD', r_min, r_max, rd_min, rd_max)
    
    def middle_down(self) -> int:
        """Press middle mouse button down.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MiddleDown')
    
    def middle_up(self) -> int:
        """Release middle mouse button.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MiddleUp')
    
    def middle_double_click_d(self, r_min: int, r_max: int,
                              rd_min: int, rd_max: int,
                              rdr_min: int, rdr_max: int) -> int:
        """Middle double click with random delays.
        
        Args:
            r_min: Min first click duration (ms)
            r_max: Max first click duration (ms)
            rd_min: Min delay between clicks (ms)
            rd_max: Max delay between clicks (ms)
            rdr_min: Min second click duration (ms)
            rdr_max: Max second click duration (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MiddleDoubleClickD', r_min, r_max, rd_min, rd_max,
                                 rdr_min, rdr_max)
    
    # ==================== Mouse Wheel ====================
    
    def wheel_up(self) -> int:
        """Scroll mouse wheel up.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WheelUp')
    
    def wheel_up_d(self, num: int, r_min: int, r_max: int,
                   rd_min: int, rd_max: int) -> int:
        """Scroll wheel up with random delay.
        
        Args:
            num: Number of scrolls
            r_min: Minimum random range
            r_max: Maximum random range
            rd_min: Minimum random delay
            rd_max: Maximum random delay
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WheelUpD', num, r_min, r_max, rd_min, rd_max)
    
    def wheel_down(self) -> int:
        """Scroll mouse wheel down.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WheelDown')
    
    def wheel_down_d(self, num: int, r_min: int, r_max: int,
                     rd_min: int, rd_max: int) -> int:
        """Scroll wheel down with random delay.
        
        Args:
            num: Number of scrolls
            r_min: Minimum random range
            r_max: Maximum random range
            rd_min: Minimum random delay
            rd_max: Maximum random delay
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WheelDownD', num, r_min, r_max, rd_min, rd_max)
    
    # ==================== Mouse Settings ====================
    
    def get_mouse_speed(self) -> int:
        """Get mouse movement speed.
        
        Returns:
            Current mouse speed
        """
        return self._call_method('GetMouseSpeed')
    
    def set_mouse_speed(self, speed: int) -> int:
        """Set mouse movement speed.
        
        Args:
            speed: Speed value
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetMouseSpeed', speed)
    
    def set_mouse_accuracy(self, accuracy: int) -> int:
        """Set mouse accuracy.
        
        Args:
            accuracy: Accuracy level
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetMouseAccuracy', accuracy)
    
    # ==================== Keyboard Input ====================
    
    def key_down(self, key_code: int) -> int:
        """Press a key down (virtual key code).
        
        Args:
            key_code: Virtual key code
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyDown', key_code)
    
    def key_down_s(self, key_str: str) -> int:
        """Press a key down (string key).
        
        Args:
            key_str: Key string (e.g., "a", "enter", "ctrl")
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyDownS', key_str)
    
    def key_up(self, key_code: int) -> int:
        """Release a key (virtual key code).
        
        Args:
            key_code: Virtual key code
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyUp', key_code)
    
    def key_up_s(self, key_str: str) -> int:
        """Release a key (string key).
        
        Args:
            key_str: Key string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyUpS', key_str)
    
    def key_press(self, key_code: int) -> int:
        """Press and release a key (virtual key code).
        
        Args:
            key_code: Virtual key code
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyPress', key_code)
    
    def key_press_s(self, key_str: str) -> int:
        """Press and release a key (string key).
        
        Args:
            key_str: Key string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyPressS', key_str)
    
    def key_press_d(self, key_code: int, r_min: int, r_max: int,
                    rd_min: int, rd_max: int) -> int:
        """Press key with random delay (virtual key code).
        
        Args:
            key_code: Virtual key code
            r_min: Min press duration (ms)
            r_max: Max press duration (ms)
            rd_min: Min delay after (ms)
            rd_max: Max delay after (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyPressD', key_code, r_min, r_max, rd_min, rd_max)
    
    def key_press_sd(self, key_str: str, r_min: int, r_max: int,
                     rd_min: int, rd_max: int) -> int:
        """Press key with random delay (string key).
        
        Args:
            key_str: Key string
            r_min: Min press duration (ms)
            r_max: Max press duration (ms)
            rd_min: Min delay after (ms)
            rd_max: Max delay after (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyPressSD', key_str, r_min, r_max, rd_min, rd_max)
    
    def key_press_z(self, key_str: str, r_min: int, r_max: int) -> int:
        """Press key combination (like Ctrl+C).
        
        Args:
            key_str: Key combination string
            r_min: Min delay between keys (ms)
            r_max: Max delay between keys (ms)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KeyPressZ', key_str, r_min, r_max)
    
    # ==================== Keyboard State ====================
    
    def get_key_d_state(self, key_code: int) -> int:
        """Get key state (pressed or not).
        
        Args:
            key_code: Virtual key code
            
        Returns:
            1 if pressed, 0 if not
        """
        return self._call_method('GetKeyDState', key_code)
    
    def wait_key_d(self, key_code: int, timeout: int = 0) -> int:
        """Wait for a key to be pressed.
        
        Args:
            key_code: Virtual key code to wait for
            timeout: Timeout in milliseconds (0 = infinite)
            
        Returns:
            1 if key pressed, 0 if timeout
        """
        return self._call_method('WaitKeyD', key_code, timeout)
    
    # ==================== Text Input ====================
    
    def send_string(self, hwnd: int, text: str, r_min: int, r_max: int,
                    send_type: int, flag: int) -> int:
        """Send string to window.
        
        Args:
            hwnd: Window handle
            text: String to send
            r_min: Min delay between chars (ms)
            r_max: Max delay between chars (ms)
            send_type: Send method
            flag: Additional flags
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SendString', hwnd, text, r_min, r_max, send_type, flag)
    
    # ==================== Clipboard ====================
    
    def get_clipboard(self) -> str:
        """Get clipboard text content.
        
        Returns:
            Clipboard text
        """
        return self._call_method('GetClipboard')
    
    def set_clipboard(self, text: str) -> int:
        """Set clipboard text content.
        
        Args:
            text: Text to set
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetClipboard', text)
    
    # ==================== Double Click Settings ====================
    
    def get_double_click_time(self) -> int:
        """Get double click time interval.
        
        Returns:
            Double click time in milliseconds
        """
        return self._call_method('GetDoubleClickTime')
    
    def set_double_click_time(self, time_ms: int) -> int:
        """Set double click time interval.
        
        Args:
            time_ms: Double click time in milliseconds
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetDoubleClickTime', time_ms)
    
    # ==================== Input Blocking ====================
    
    def block_input(self, block_type: int) -> int:
        """Block or unblock keyboard and mouse input.
        
        Args:
            block_type: 1=block, 0=unblock
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('BlockInput', block_type)
