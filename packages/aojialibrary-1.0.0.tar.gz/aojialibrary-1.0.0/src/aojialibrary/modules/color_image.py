"""
Color and Image Operations Module

Provides screen capture, color finding, and image matching operations.
"""

from typing import Tuple

from ..core import AoJiaBase


class ColorImageMixin(AoJiaBase):
    """Mixin class for color and image operations."""
    
    # ==================== Screen Information ====================
    
    def get_screen(self) -> Tuple[int, int]:
        """Get screen resolution.
        
        Returns:
            Tuple of (width, height)
        """
        width, height = self._create_variant(), self._create_variant()
        self._call_method('GetScreen', width, height)
        return width.value, height.value
    
    def get_screen_s(self) -> Tuple[str, int, int]:
        """Get screen scale information.
        
        Returns:
            Tuple of (scale_str, x_scale, y_scale)
        """
        xs, ys = self._create_variant(), self._create_variant()
        result = self._call_method('GetScreenS', xs, ys)
        return result, xs.value, ys.value
    
    def get_dpi(self) -> int:
        """Get screen DPI.
        
        Returns:
            DPI value
        """
        return self._call_method('GetDPI')
    
    def set_screen(self, width: int, height: int) -> int:
        """Set screen resolution.
        
        Args:
            width: Screen width
            height: Screen height
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetScreen', width, height)
    
    # ==================== Color Operations ====================
    
    def get_color(self, x: int, y: int, color_type: int = 0, 
                  type_d: int = 0) -> str:
        """Get color at specified position.
        
        Args:
            x: X coordinate
            y: Y coordinate
            color_type: Color format (0=BGR, 1=RGB)
            type_d: Additional type
            
        Returns:
            Color string (hex format)
        """
        result = self._call_method('GetColor', x, y, color_type, type_d)
        return str(result) if result is not None else ""
    
    def cmp_color(self, x: int, y: int, color: str, sim: float,
                  color_type: int) -> int:
        """Compare color at position.
        
        Args:
            x: X coordinate
            y: Y coordinate
            color: Target color (hex string)
            sim: Similarity (0.0-1.0)
            color_type: Color format
            
        Returns:
            1 if match, 0 if not match
        """
        return self._call_method('CmpColor', x, y, color, sim, color_type)
    
    def get_color_num(self, x1: int, y1: int, x2: int, y2: int,
                      color: str, sim: float) -> int:
        """Count pixels matching color in region.
        
        Args:
            x1: Left coordinate of region
            y1: Top coordinate of region
            x2: Right coordinate of region
            y2: Bottom coordinate of region
            color: Target color
            sim: Similarity
            
        Returns:
            Number of matching pixels
        """
        return self._call_method('GetColorNum', x1, y1, x2, y2, color, sim)
    
    def get_color_ave(self, x1: int, y1: int, x2: int, y2: int,
                      color_type: int) -> str:
        """Get average color in region.
        
        Returns:
            Average color string
        """
        result = self._call_method('GetColorAve', x1, y1, x2, y2, color_type)
        return str(result) if result is not None else ""
    
    # ==================== Find Color ====================
    
    def find_color(self, x1: int, y1: int, x2: int, y2: int,
                   color: str, sim: float, direction: int) -> Tuple[int, int, int]:
        """Find a color in region.
        
        Args:
            x1: Left coordinate of search region
            y1: Top coordinate of search region
            x2: Right coordinate of search region
            y2: Bottom coordinate of search region
            color: Target color
            sim: Similarity (0.0-1.0)
            direction: Search direction
            
        Returns:
            Tuple of (found, x, y) - found is 1 if success
        """
        x, y = self._create_variant(), self._create_variant()
        result = self._call_method('FindColor', x1, y1, x2, y2, color, sim, direction, x, y)
        return result, x.value, y.value
    
    def find_color_ex(self, x1: int, y1: int, x2: int, y2: int,
                      color: str, sim: float, direction: int) -> str:
        """Find all occurrences of color in region.
        
        Returns:
            String of coordinates "x1,y1|x2,y2|..."
        """
        return self._call_method('FindColorEx', x1, y1, x2, y2, color, sim, direction)
    
    def find_color_m(self, x1: int, y1: int, x2: int, y2: int,
                     color: str, sim: float, count: int) -> int:
        """Check if color appears at least count times.
        
        Returns:
            1 if count met, 0 if not
        """
        return self._call_method('FindColorM', x1, y1, x2, y2, color, sim, count)
    
    def find_color_squ(self, x1: int, y1: int, x2: int, y2: int,
                       color: str, sim: float, sim_d: float, direction: int,
                       width: int, height: int) -> Tuple[int, int, int]:
        """Find color square/block in region.
        
        Returns:
            Tuple of (found, x, y)
        """
        x, y = self._create_variant(), self._create_variant()
        result = self._call_method('FindColorSqu', x1, y1, x2, y2, color, sim, sim_d,
                                   direction, width, height, x, y)
        return result, x.value, y.value
    
    def find_color_squ_ex(self, x1: int, y1: int, x2: int, y2: int,
                          color: str, sim: float, sim_d: float, direction: int,
                          width: int, height: int) -> str:
        """Find all color squares in region.
        
        Returns:
            String of coordinates
        """
        return self._call_method('FindColorSquEx', x1, y1, x2, y2, color, sim, sim_d,
                                 direction, width, height)
    
    # ==================== Multi-Color Finding ====================
    
    def find_multi_color(self, x1: int, y1: int, x2: int, y2: int,
                         first_color: str, color_offset: str, sim: float,
                         direction: int, sim_p: float, sim_d: float) -> Tuple[int, int, int]:
        """Find multi-color pattern.
        
        Args:
            x1: Left coordinate of search region
            y1: Top coordinate of search region
            x2: Right coordinate of search region
            y2: Bottom coordinate of search region
            first_color: First color to find
            color_offset: Offset colors string "offset_x|offset_y|color|..."
            sim: Similarity for first color
            direction: Search direction
            sim_p: Similarity for pattern
            sim_d: Deviation similarity
            
        Returns:
            Tuple of (found, x, y)
        """
        x, y = self._create_variant(), self._create_variant()
        result = self._call_method('FindMultiColor', x1, y1, x2, y2, first_color,
                                   color_offset, sim, direction, sim_p, sim_d, x, y)
        return result, x.value, y.value
    
    def find_multi_color_ex(self, x1: int, y1: int, x2: int, y2: int,
                            first_color: str, color_offset: str, sim: float,
                            direction: int, sim_p: float, sim_d: float) -> str:
        """Find all multi-color patterns.
        
        Returns:
            String of coordinates
        """
        return self._call_method('FindMultiColorEx', x1, y1, x2, y2, first_color,
                                 color_offset, sim, direction, sim_p, sim_d)
    
    # ==================== Shape Finding ====================
    
    def find_shape(self, x1: int, y1: int, x2: int, y2: int,
                   color_offset: str, direction: int, sim_p: float,
                   sim_d: float) -> Tuple[int, int, int]:
        """Find shape pattern.
        
        Returns:
            Tuple of (found, x, y)
        """
        x, y = self._create_variant(), self._create_variant()
        result = self._call_method('FindShape', x1, y1, x2, y2, color_offset,
                                   direction, sim_p, sim_d, x, y)
        return result, x.value, y.value
    
    def find_shape_ex(self, x1: int, y1: int, x2: int, y2: int,
                      color_offset: str, direction: int, sim_p: float,
                      sim_d: float) -> str:
        """Find all shape patterns.
        
        Returns:
            String of coordinates
        """
        return self._call_method('FindShapeEx', x1, y1, x2, y2, color_offset,
                                 direction, sim_p, sim_d)
    
    # ==================== Image Finding ====================
    
    def find_pic(self, x1: int, y1: int, x2: int, y2: int,
                 pic_name: str, delta_color: str, sim: float,
                 direction: int, pic_type: int) -> Tuple[int, int, int, int]:
        """Find picture in region.
        
        Args:
            x1: Left coordinate of search region
            y1: Top coordinate of search region
            x2: Right coordinate of search region
            y2: Bottom coordinate of search region
            pic_name: Picture file path/name
            delta_color: Color tolerance string
            sim: Similarity (0.0-1.0)
            direction: Search direction
            pic_type: Picture type
            
        Returns:
            Tuple of (found, pic_index, x, y)
        """
        pic, x, y = self._create_variant(), self._create_variant(), self._create_variant()
        result = self._call_method('FindPic', x1, y1, x2, y2, pic_name, delta_color,
                                   sim, direction, pic_type, pic, x, y)
        return result, pic.value, x.value, y.value
    
    def find_pic_ex(self, x1: int, y1: int, x2: int, y2: int,
                    pic_name: str, delta_color: str, sim: float,
                    direction: int, pic_type: int, type_t: int) -> str:
        """Find all pictures in region.
        
        Returns:
            String of results
        """
        return self._call_method('FindPicEx', x1, y1, x2, y2, pic_name, delta_color,
                                 sim, direction, pic_type, type_t)
    
    def find_pic_d(self, x1: int, y1: int, x2: int, y2: int,
                   pic_name: str, delta_color: str, sim: float, sim_d: float,
                   direction: int, pic_type: int) -> Tuple[int, int, int, int]:
        """Find picture with deviation.
        
        Returns:
            Tuple of (found, pic_index, x, y)
        """
        pic, x, y = self._create_variant(), self._create_variant(), self._create_variant()
        result = self._call_method('FindPicD', x1, y1, x2, y2, pic_name, delta_color,
                                   sim, sim_d, direction, pic_type, pic, x, y)
        return result, pic.value, x.value, y.value
    
    def find_pic_d_ex(self, x1: int, y1: int, x2: int, y2: int,
                      pic_name: str, delta_color: str, sim: float, sim_d: float,
                      direction: int, pic_type: int, type_t: int) -> str:
        """Find all pictures with deviation.
        
        Returns:
            String of results
        """
        return self._call_method('FindPicDEx', x1, y1, x2, y2, pic_name, delta_color,
                                 sim, sim_d, direction, pic_type, type_t)
    
    # ==================== Picture Management ====================
    
    def load_pic(self, pic_name: str) -> int:
        """Load picture into memory.
        
        Args:
            pic_name: Picture file path (can use | for multiple)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LoadPic', pic_name)
    
    def free_pic(self, pic_name: str) -> int:
        """Free picture from memory.
        
        Args:
            pic_name: Picture name to free (empty for all)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('FreePic', pic_name)
    
    def get_pic_size(self, pic_name: str) -> Tuple[int, int, int]:
        """Get picture dimensions.
        
        Args:
            pic_name: Picture file path
            
        Returns:
            Tuple of (success, width, height)
        """
        w, h = self._create_variant(), self._create_variant()
        result = self._call_method('GetPicSize', pic_name, w, h)
        return result, w.value, h.value
    
    def pic_to_bmp(self, pic_name: str, bmp_name: str) -> int:
        """Convert picture to BMP format.
        
        Args:
            pic_name: Source picture path
            bmp_name: Target BMP path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('PicToBmp', pic_name, bmp_name)
    
    def set_pic_pw(self, password: str) -> int:
        """Set picture password for encrypted pictures.
        
        Args:
            password: Password string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetPicPw', password)
    
    def set_pic_cache(self, cache_type: int) -> int:
        """Set picture cache mode.
        
        Args:
            cache_type: Cache type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetPicCache', cache_type)
    
    # ==================== Screen Capture ====================
    
    def screen_shot(self, x1: int, y1: int, x2: int, y2: int,
                    pic_name: str, pic_type: int = 0, quality: int = 100,
                    td: int = 0, t: int = 0, flag: int = 0, mouse: int = 0) -> int:
        """Capture screen region to file.
        
        Args:
            x1: Left coordinate of capture region
            y1: Top coordinate of capture region
            x2: Right coordinate of capture region
            y2: Bottom coordinate of capture region
            pic_name: Output file path
            pic_type: Picture format (0=bmp, 1=jpg, 2=png)
            quality: JPEG quality (1-100)
            td: Delay before capture
            t: Timeout
            flag: Capture flags
            mouse: Include mouse cursor (0=no, 1=yes)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('ScreenShot', x1, y1, x2, y2, pic_name, pic_type,
                                 quality, td, t, flag, mouse)
    
    def set_pc_data(self, data_type: int, pic_name: str) -> int:
        """Set PC data for capture.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetPCData', data_type, pic_name)
    
    # ==================== Color Conversion ====================
    
    def bgr_or_rgb(self, color: str) -> str:
        """Convert BGR to RGB or vice versa.
        
        Args:
            color: Color string in hex
            
        Returns:
            Converted color string
        """
        return self._call_method('BGRorRGB', color)
    
    def bgr_or_rgb_to_hsv(self, color: str, color_type: int) -> str:
        """Convert BGR/RGB to HSV.
        
        Args:
            color: Color string
            color_type: Source color format (0=BGR, 1=RGB)
            
        Returns:
            HSV string "h|s|v"
        """
        return self._call_method('BGRorRGBtoHSV', color, color_type)
    
    def hsv_to_bgr_or_rgb(self, color: str, color_type: int) -> str:
        """Convert HSV to BGR/RGB.
        
        Args:
            color: HSV string "h|s|v"
            color_type: Target color format (0=BGR, 1=RGB)
            
        Returns:
            Color string
        """
        return self._call_method('HSVtoBGRorRGB', color, color_type)
    
    # ==================== Screen Check ====================
    
    def is_screen_stuck(self, x1: int, y1: int, x2: int, y2: int,
                        timeout: int) -> int:
        """Check if screen region is stuck (not changing).
        
        Args:
            x1: Left coordinate of region to check
            y1: Top coordinate of region to check
            x2: Right coordinate of region to check
            y2: Bottom coordinate of region to check
            timeout: Time to wait for change
            
        Returns:
            1 if stuck, 0 if changing
        """
        return self._call_method('IsScreenStuck', x1, y1, x2, y2, timeout)
