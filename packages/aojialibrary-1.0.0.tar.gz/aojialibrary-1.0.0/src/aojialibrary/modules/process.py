"""
Process Operations Module

Provides process management operations for AoJia.
"""

from typing import Tuple
from ..core import AoJiaBase


class ProcessMixin(AoJiaBase):
    """Mixin class for process operations."""
    
    # ==================== Process Information ====================
    
    def get_current_process_id(self) -> int:
        """Get current process ID.
        
        Returns:
            Current process ID
        """
        return self._call_method('GetCurrentProcessId')
    
    def get_current_thread_id(self) -> int:
        """Get current thread ID.
        
        Returns:
            Current thread ID
        """
        return self._call_method('GetCurrentThreadId')
    
    def get_process_path(self, pid: int, path_type: int = 0) -> str:
        """Get process executable path.
        
        Args:
            pid: Process ID (0 for current)
            path_type: 0=full path, 1=filename only
            
        Returns:
            Process path string
        """
        return self._call_method('GetProcessPath', pid, path_type)
    
    def get_process_info(self, pid: int, hwnd: int) -> str:
        """Get process information.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            
        Returns:
            Process info string
        """
        return self._call_method('GetProcessInfo', pid, hwnd)
    
    def is_64_process(self, pid: int, hwnd: int) -> int:
        """Check if process is 64-bit.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            
        Returns:
            1 if 64-bit, 0 if 32-bit
        """
        return self._call_method('Is64Process', pid, hwnd)
    
    def get_command_line(self, pid: int, hwnd: int) -> str:
        """Get process command line.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            
        Returns:
            Command line string
        """
        return self._call_method('GetCommandLine', pid, hwnd)
    
    def get_pt_num(self) -> Tuple[int, int, int, int]:
        """Get process and thread count.
        
        Returns:
            Tuple of (result, process_count, handle_count, thread_count)
        """
        ps = self._create_variant()
        hc = self._create_variant()
        tc = self._create_variant()
        result = self._call_method('GetPTNum', ps, hc, tc)
        return result, ps.value, hc.value, tc.value
    
    # ==================== Process Enumeration ====================
    
    def enum_process(self, pro_name: str = "") -> str:
        """Enumerate processes.
        
        Args:
            pro_name: Filter by process name (empty for all)
            
        Returns:
            String of process info
        """
        return self._call_method('EnumProcess', pro_name)
    
    def enum_thread(self, pid: int, hwnd: int) -> str:
        """Enumerate threads in process.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            
        Returns:
            String of thread IDs
        """
        return self._call_method('EnumThread', pid, hwnd)
    
    # ==================== Process Termination ====================
    
    def terminate_process(self, pid: int, hwnd: int, pro_name: str,
                          term_type: int) -> int:
        """Terminate a process.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            pro_name: Process name
            term_type: Termination type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('TerminateProcess', pid, hwnd, pro_name, term_type)
    
    def terminate_thread(self, tid: int) -> int:
        """Terminate a thread.
        
        Args:
            tid: Thread ID
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('TerminateThread', tid)
    
    # ==================== Module Operations ====================
    
    def enum_module(self, pid: int, hwnd: int) -> str:
        """Enumerate modules in process.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            
        Returns:
            String of module info
        """
        return self._call_method('EnumModule', pid, hwnd)
    
    def get_module_base_addr(self, pid: int, hwnd: int, module_name: str) -> int:
        """Get module base address.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            module_name: Module name
            
        Returns:
            Module base address
        """
        return self._call_method('GetModuleBaseAddr', pid, hwnd, module_name)
    
    def get_module_path(self, pid: int, hwnd: int, module_name: str,
                        path_type: int) -> str:
        """Get module file path.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            module_name: Module name
            path_type: 0=full path, 1=filename only
            
        Returns:
            Module path
        """
        return self._call_method('GetModulePath', pid, hwnd, module_name, path_type)
    
    def get_module_size(self, pid: int, hwnd: int, module_name: str) -> int:
        """Get module size.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            module_name: Module name
            
        Returns:
            Module size in bytes
        """
        return self._call_method('GetModuleSize', pid, hwnd, module_name)
    
    def get_remote_proc_addr(self, pid: int, hwnd: int, module_name: str,
                             func_name: str) -> int:
        """Get remote function address.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            module_name: Module name
            func_name: Function name
            
        Returns:
            Function address
        """
        return self._call_method('GetRemoteProcAddress', pid, hwnd, module_name, func_name)
    
    # ==================== Process Execution ====================
    
    def run_app(self, path: str, run_type: int) -> int:
        """Run an application.
        
        Args:
            path: Application path
            run_type: Run type (0=normal, 1=hidden, etc.)
            
        Returns:
            Process ID on success, 0 on failure
        """
        return self._call_method('RunApp', path, run_type)
    
    # ==================== IME Operations ====================
    
    def disable_ime(self, tid: int, disable_type: int) -> int:
        """Disable IME for thread.
        
        Args:
            tid: Thread ID
            disable_type: Disable type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DisableIME', tid, disable_type)
