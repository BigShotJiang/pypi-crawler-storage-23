"""
Text and OCR Operations Module

Provides text recognition and dictionary operations for AoJia.
"""

from typing import Tuple
from ..core import AoJiaBase


class TextMixin(AoJiaBase):
    """Mixin class for text and OCR operations."""
    
    # ==================== Dictionary Operations ====================
    
    def set_dict(self, dict_num: int) -> int:
        """Set active dictionary.
        
        Args:
            dict_num: Dictionary number (0-9)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetDict', dict_num)
    
    def get_dict(self, get_type: int, dict_num: int, dict_type: int) -> int:
        """Get dictionary information.
        
        Args:
            get_type: Info type
            dict_num: Dictionary number
            dict_type: Dictionary type
            
        Returns:
            Dictionary info value
        """
        return self._call_method('GetDict', get_type, dict_num, dict_type)
    
    def load_dict(self, dict_num: int, dict_path: str) -> int:
        """Load dictionary from file.
        
        Args:
            dict_num: Dictionary number (0-9)
            dict_path: Dictionary file path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LoadDict', dict_num, dict_path)
    
    def free_dict(self, dict_num: int) -> int:
        """Free dictionary from memory.
        
        Args:
            dict_num: Dictionary number (-1 for all)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('FreeDict', dict_num)
    
    def set_dict_width(self, width: int) -> int:
        """Set dictionary character width.
        
        Args:
            width: Character width
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetDictWidth', width)
    
    def set_dict_height(self, height: int) -> int:
        """Set dictionary character height.
        
        Args:
            height: Character height
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetDictHeight', height)
    
    def set_dict_pw(self, password: str) -> int:
        """Set dictionary password.
        
        Args:
            password: Password string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetDictPw', password)
    
    def set_global_dict(self, global_type: int) -> int:
        """Set global dictionary mode.
        
        Args:
            global_type: 1=global, 0=per thread
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetGlobalDict', global_type)
    
    # ==================== OCR Operations ====================
    
    def find_str(self, x1: int, y1: int, x2: int, y2: int,
                 text: str, color: str, sim: float, direction: int,
                 color_type: int, dict_type: int) -> Tuple[int, int, int, int]:
        """Find text string in region.
        
        Args:
            x1: Left coordinate of search region
            y1: Top coordinate of search region
            x2: Right coordinate of search region
            y2: Bottom coordinate of search region
            text: Text to find
            color: Color format string
            sim: Similarity (0.0-1.0)
            direction: Search direction
            color_type: Color type
            dict_type: Dictionary type
            
        Returns:
            Tuple of (found, str_index, x, y)
        """
        str_d, x, y = self._create_variant(), self._create_variant(), self._create_variant()
        result = self._call_method('FindStr', x1, y1, x2, y2, text, color, sim,
                                   direction, color_type, dict_type, str_d, x, y)
        return result, str_d.value, x.value, y.value
    
    def find_str_m(self, x1: int, y1: int, x2: int, y2: int,
                   text: str, color: str, sim: float,
                   color_type: int, dict_type: int) -> Tuple[int, int, int, int]:
        """Find text string with multi-line support.
        
        Returns:
            Tuple of (found, str_index, x, y)
        """
        str_d, x, y = self._create_variant(), self._create_variant(), self._create_variant()
        result = self._call_method('FindStrM', x1, y1, x2, y2, text, color, sim,
                                   color_type, dict_type, str_d, x, y)
        return result, str_d.value, x.value, y.value
    
    def find_str_m_ex(self, x1: int, y1: int, x2: int, y2: int,
                      text: str, color: str, sim: float,
                      color_type: int, dict_type: int,
                      h_line: str) -> str:
        """Find all text strings with multi-line support.
        
        Returns:
            String of results
        """
        return self._call_method('FindStrMEx', x1, y1, x2, y2, text, color, sim,
                                 color_type, dict_type, h_line)
    
    def ocr(self, x1: int, y1: int, x2: int, y2: int,
            text: str, color: str, sim: float,
            color_type: int, dict_type: int,
            ocr_type: int, type_t: int,
            h_line: str, pic_name: str) -> str:
        """Perform OCR on region.
        
        Args:
            x1: Left coordinate of OCR region
            y1: Top coordinate of OCR region
            x2: Right coordinate of OCR region
            y2: Bottom coordinate of OCR region
            text: Expected text pattern (can be empty)
            color: Color format string
            sim: Similarity
            color_type: Color type
            dict_type: Dictionary type
            ocr_type: OCR type
            type_t: Result type
            h_line: Horizontal line separator
            pic_name: Picture name (if using pre-loaded image)
            
        Returns:
            Recognized text string
        """
        return self._call_method('Ocr', x1, y1, x2, y2, text, color, sim,
                                 color_type, dict_type, ocr_type, type_t, h_line, pic_name)
