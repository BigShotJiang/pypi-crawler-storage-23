"""
Background Operations Module

Provides background mode operations for AoJia.
"""

from ..core import AoJiaBase


class BackgroundMixin(AoJiaBase):
    """Mixin class for background operations."""
    
    # ==================== Background Mode ====================
    
    def kq_hou_tai(self, hwnd: int, screen: str, keyboard: str,
                   mouse: str, flag: str, bg_type: int) -> int:
        """Enable background mode for window.
        
        Args:
            hwnd: Window handle
            screen: Screen mode string
            keyboard: Keyboard mode string
            mouse: Mouse mode string
            flag: Additional flags
            bg_type: Background type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('KQHouTai', hwnd, screen, keyboard, mouse, flag, bg_type)
    
    def gb_hou_tai(self) -> int:
        """Disable background mode.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('GBHouTai')
    
    # ==================== Performance ====================
    
    def down_cpu(self, hwnd: int, cpu_time: int) -> int:
        """Reduce CPU usage of target window.
        
        Args:
            hwnd: Window handle
            cpu_time: CPU time interval
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DownCpu', hwnd, cpu_time)
    
    def get_fps(self) -> int:
        """Get current FPS.
        
        Returns:
            FPS value
        """
        return self._call_method('GetFPS')
    
    # ==================== Input Locking ====================
    
    def set_km_lock(self, lock_keyboard: int, lock_mouse: int) -> int:
        """Lock keyboard/mouse input to specific window.
        
        Args:
            lock_keyboard: 1=lock keyboard, 0=unlock
            lock_mouse: 1=lock mouse, 0=unlock
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetKMLock', lock_keyboard, lock_mouse)
    
    def set_hwnd_skm(self, hwnd_screen: int, hwnd_keyboard: int,
                     hwnd_mouse: int) -> int:
        """Set separate window handles for screen/keyboard/mouse.
        
        Args:
            hwnd_screen: Screen window handle
            hwnd_keyboard: Keyboard window handle
            hwnd_mouse: Mouse window handle
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetHwndSKM', hwnd_screen, hwnd_keyboard, hwnd_mouse)
    
    def set_km_sync(self, keyboard_sync: int, key_code: int,
                    mouse_sync: int, mouse_code: int) -> int:
        """Set keyboard/mouse synchronization.
        
        Args:
            keyboard_sync: Keyboard sync mode
            key_code: Key code
            mouse_sync: Mouse sync mode
            mouse_code: Mouse code
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetKMSync', keyboard_sync, key_code, mouse_sync, mouse_code)
    
    # ==================== Screen Locking ====================
    
    def lock_screen(self, lock_type: int) -> int:
        """Lock/unlock screen.
        
        Args:
            lock_type: 1=lock, 0=unlock
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('LockScreen', lock_type)
    
    def set_window_sna(self, sna: int) -> int:
        """Set window SNA mode.
        
        Args:
            sna: SNA value
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetWindowSNA', sna)
    
    # ==================== IME Settings ====================
    
    def set_ime(self, ime_type: int) -> int:
        """Set IME mode.
        
        Args:
            ime_type: IME type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetIme', ime_type)
    
    # ==================== Timing ====================
    
    def set_time_s(self, time_ms: int) -> int:
        """Set timing interval.
        
        Args:
            time_ms: Interval in milliseconds
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetTimeS', time_ms)
