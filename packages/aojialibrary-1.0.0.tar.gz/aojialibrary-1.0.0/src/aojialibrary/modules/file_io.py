"""
File Operations Module

Provides file and folder operations for AoJia.
"""

from typing import Tuple
from ..core import AoJiaBase


class FileMixin(AoJiaBase):
    """Mixin class for file operations."""
    
    # ==================== Path Operations ====================
    
    def get_path(self) -> str:
        """Get current working path.
        
        Returns:
            Current path string
        """
        return self._call_method('GetPath')
    
    def set_path(self, path: str) -> int:
        """Set current working path.
        
        Args:
            path: Path string
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetPath', path)
    
    def select_file_or_folder(self) -> str:
        """Open file/folder selection dialog.
        
        Returns:
            Selected path or empty string if cancelled
        """
        return self._call_method('SelectFileOrFolder')
    
    # ==================== File Information ====================
    
    def is_file_or_folder(self, path: str) -> int:
        """Check if path is file or folder.
        
        Args:
            path: Path to check
            
        Returns:
            1=file, 2=folder, 0=not exists
        """
        return self._call_method('IsFileOrFolder', path)
    
    def is_file_or_folder_e(self, path: str) -> int:
        """Check if file/folder exists.
        
        Args:
            path: Path to check
            
        Returns:
            1=exists, 0=not exists
        """
        return self._call_method('IsFileOrFolderE', path)
    
    def get_file_size(self, path: str) -> Tuple[float, int, int]:
        """Get file size.
        
        Args:
            path: File path
            
        Returns:
            Tuple of (size, size_high, size_low)
        """
        fsh, fsl = self._create_variant(), self._create_variant()
        result = self._call_method('GetFileSize', path, fsh, fsl)
        return result, fsh.value, fsl.value
    
    def get_file_attribute(self, path: str) -> Tuple[int, int, int]:
        """Get file attributes.
        
        Args:
            path: File path
            
        Returns:
            Tuple of (result, readonly, hidden)
        """
        rd, hd = self._create_variant(), self._create_variant()
        result = self._call_method('GetFileAttribute', path, rd, hd)
        return result, rd.value, hd.value
    
    def set_file_attribute(self, path: str, readonly: int, hidden: int) -> int:
        """Set file attributes.
        
        Args:
            path: File path
            readonly: 1=readonly, 0=not
            hidden: 1=hidden, 0=not
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetFileAttribute', path, readonly, hidden)
    
    def get_file_time(self, path: str) -> Tuple[int, str, str, str]:
        """Get file timestamps.
        
        Args:
            path: File path
            
        Returns:
            Tuple of (result, create_time, write_time, access_time)
        """
        ct, wt, at = self._create_variant(), self._create_variant(), self._create_variant()
        result = self._call_method('GetFileTime', path, ct, wt, at)
        return result, ct.value, wt.value, at.value
    
    def set_file_time(self, path: str, create_time: str,
                      write_time: str, access_time: str) -> int:
        """Set file timestamps.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetFileTime', path, create_time, write_time, access_time)
    
    def compare_file_data(self, path1: str, path2: str) -> int:
        """Compare two files by content.
        
        Args:
            path1: First file path
            path2: Second file path
            
        Returns:
            1=same, 0=different
        """
        return self._call_method('CompareFileData', path1, path2)
    
    def compare_file_time(self, path1: str, path2: str) -> Tuple[int, str, str, str]:
        """Compare file modification times.
        
        Returns:
            Tuple of (result, time1, time2, time_diff)
        """
        ct, wt, at = self._create_variant(), self._create_variant(), self._create_variant()
        result = self._call_method('CompareFileTime', path1, path2, ct, wt, at)
        return result, ct.value, wt.value, at.value
    
    # ==================== File Operations ====================
    
    def read_file(self, path: str, pos: int = 0, flag: int = 0,
                  size: int = 0, encoding: int = 0,
                  type_d: int = 0) -> str:
        """Read file content.
        
        Args:
            path: File path
            pos: Start position
            flag: Read flag
            size: Bytes to read (0 for all)
            encoding: Encoding type
            type_d: Additional type
            
        Returns:
            File content string
        """
        return self._call_method('ReadFile', path, pos, flag, size, encoding, type_d)
    
    def write_file(self, path: str, content: str, pos: int = 0,
                   flag: int = 0, size: int = 0, encoding: int = 0,
                   type_d: int = 0) -> int:
        """Write content to file.
        
        Args:
            path: File path
            content: Content to write
            pos: Start position
            flag: Write flag
            size: Size to write
            encoding: Encoding type
            type_d: Additional type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteFile', path, content, pos, flag, size, encoding, type_d)
    
    def copy_file(self, src: str, dst: str, overwrite: int = 0) -> int:
        """Copy file.
        
        Args:
            src: Source file path
            dst: Destination file path
            overwrite: 1=overwrite, 0=don't
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('CopyFile', src, dst, overwrite)
    
    def move_file(self, src: str, dst: str, overwrite: int = 0) -> int:
        """Move file.
        
        Args:
            src: Source file path
            dst: Destination file path
            overwrite: 1=overwrite, 0=don't
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveFile', src, dst, overwrite)
    
    def delete_file(self, path: str) -> int:
        """Delete file.
        
        Args:
            path: File path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DeleteFile', path)
    
    def rename_file(self, old_name: str, new_name: str) -> int:
        """Rename file.
        
        Args:
            old_name: Current file path
            new_name: New file path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('ReNameFile', old_name, new_name)
    
    def find_file(self, path: str) -> str:
        """Find files matching pattern.
        
        Args:
            path: Search pattern (e.g., "C:\\*.txt")
            
        Returns:
            String of file paths
        """
        return self._call_method('FindFile', path)
    
    # ==================== Folder Operations ====================
    
    def create_folder(self, path: str) -> int:
        """Create folder.
        
        Args:
            path: Folder path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('CreateFolder', path)
    
    def delete_folder(self, path: str) -> int:
        """Delete folder.
        
        Args:
            path: Folder path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DeleteFolder', path)
    
    def copy_folder(self, src: str, dst: str, overwrite: int = 0) -> int:
        """Copy folder.
        
        Args:
            src: Source folder path
            dst: Destination folder path
            overwrite: 1=overwrite, 0=don't
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('CopyFolder', src, dst, overwrite)
    
    def move_folder(self, src: str, dst: str, overwrite: int = 0) -> int:
        """Move folder.
        
        Args:
            src: Source folder path
            dst: Destination folder path
            overwrite: 1=overwrite, 0=don't
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveFolder', src, dst, overwrite)
    
    def open_folder(self, path: str) -> int:
        """Open folder in explorer.
        
        Args:
            path: Folder path
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('OpenFolder', path)
    
    # ==================== INI File Operations ====================
    
    def read_ini(self, path: str, section: str, key: str,
                 password: str = "") -> str:
        """Read value from INI file.
        
        Args:
            path: INI file path
            section: Section name
            key: Key name
            password: File password (if encrypted)
            
        Returns:
            Value string
        """
        return self._call_method('ReadIni', path, section, key, password)
    
    def write_ini(self, path: str, section: str, key: str,
                  value: str, password: str = "") -> int:
        """Write value to INI file.
        
        Args:
            path: INI file path
            section: Section name
            key: Key name
            value: Value string
            password: File password
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteIni', path, section, key, value, password)
    
    def delete_ini(self, path: str, section: str, key: str,
                   password: str = "") -> int:
        """Delete key from INI file.
        
        Args:
            path: INI file path
            section: Section name
            key: Key name (empty to delete section)
            password: File password
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DeleteIni', path, section, key, password)
    
    def enum_ini(self, path: str, section: str, password: str = "") -> str:
        """Enumerate keys in INI section.
        
        Args:
            path: INI file path
            section: Section name (empty for all sections)
            password: File password
            
        Returns:
            String of keys/sections
        """
        return self._call_method('EnumIni', path, section, password)
    
    # ==================== Compression ====================
    
    def compress_file(self, src: str, dst: str, comp_type: int = 0,
                      level: int = 6) -> int:
        """Compress file.
        
        Args:
            src: Source file path
            dst: Destination file path
            comp_type: Compression type
            level: Compression level (0-9)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('CompressFile', src, dst, comp_type, level)
    
    def uncompress_file(self, src: str, dst: str, comp_type: int = 0) -> int:
        """Decompress file.
        
        Args:
            src: Source file path
            dst: Destination file path
            comp_type: Compression type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('UnCompressFile', src, dst, comp_type)
    
    # ==================== Encryption ====================
    
    def encrypt_file(self, path: str, password: str) -> int:
        """Encrypt file.
        
        Args:
            path: File path
            password: Encryption password
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('EncryptFile', path, password)
    
    def decrypt_file(self, path: str, password: str) -> int:
        """Decrypt file.
        
        Args:
            path: File path
            password: Decryption password
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DecryptFile', path, password)
