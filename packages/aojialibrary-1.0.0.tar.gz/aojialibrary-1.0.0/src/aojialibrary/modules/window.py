"""
Window Operations Module

Provides window-related operations for AoJia.
"""

from typing import Tuple

from ..core import AoJiaBase


class WindowMixin(AoJiaBase):
    """Mixin class for window operations."""
    
    # ==================== Window Finding ====================
    
    def find_window(self, parent: int, pro_name: str, pro_id: int, 
                    class_name: str, title: str, win_type: int, 
                    timeout: int = 0) -> int:
        """Find a window by specified criteria.
        
        Args:
            parent: Parent window handle, 0 for desktop
            pro_name: Process name (empty string for any)
            pro_id: Process ID (0 for any)
            class_name: Window class name (empty string for any)
            title: Window title (empty string for any)
            win_type: Window type (0=all, 1=visible, 2=hidden)
            timeout: Timeout in milliseconds
            
        Returns:
            Window handle (HWND), 0 if not found
        """
        return self._call_method('FindWindow', parent, pro_name, pro_id, 
                                 class_name, title, win_type, timeout)
    
    def find_window_ex(self, scdt1: str, flag1: int, type1: int,
                       scdt2: str, flag2: int, type2: int,
                       scdt3: str, flag3: int, type3: int,
                       visible: int, timeout: int = 0) -> int:
        """Find window with extended criteria.
        
        Args:
            scdt1: First search criteria string
            scdt2: Second search criteria string
            scdt3: Third search criteria string
            flag1: First search flag
            flag2: Second search flag
            flag3: Third search flag
            type1: First search type
            type2: Second search type
            type3: Third search type
            visible: Visibility filter
            timeout: Timeout in milliseconds
            
        Returns:
            Window handle (HWND), 0 if not found
        """
        return self._call_method('FindWindowEx', scdt1, flag1, type1,
                                 scdt2, flag2, type2, scdt3, flag3, type3,
                                 visible, timeout)
    
    def enum_window(self, parent: int, pro_name: str, pro_id: int,
                    class_name: str, title: str, win_type: int,
                    flag: int, timeout: int = 0) -> str:
        """Enumerate all matching windows.
        
        Returns:
            Comma-separated string of window handles
        """
        return self._call_method('EnumWindow', parent, pro_name, pro_id,
                                 class_name, title, win_type, flag, timeout)
    
    def enum_window_ex(self, scdt1: str, flag1: int, type1: int,
                       scdt2: str, flag2: int, type2: int,
                       scdt3: str, flag3: int, type3: int,
                       visible: int, sort: int, timeout: int = 0) -> str:
        """Enumerate windows with extended criteria.
        
        Returns:
            Comma-separated string of window handles
        """
        return self._call_method('EnumWindowEx', scdt1, flag1, type1,
                                 scdt2, flag2, type2, scdt3, flag3, type3,
                                 visible, sort, timeout)
    
    # ==================== Window Information ====================
    
    def get_window(self, hwnd: int, win_type: int) -> int:
        """Get related window by type.
        
        Args:
            hwnd: Window handle
            win_type: Relation type (0=parent, 1=first child, 2=next, etc.)
            
        Returns:
            Related window handle
        """
        return self._call_method('GetWindow', hwnd, win_type)
    
    def get_window_rect(self, hwnd: int, rect_type: int = 0) -> Tuple[int, int, int, int]:
        """Get window rectangle.
        
        Args:
            hwnd: Window handle
            rect_type: 0=window rect, 1=client rect
            
        Returns:
            Tuple of (x1, y1, x2, y2)
        """
        x1, y1, x2, y2 = self._create_variant(), self._create_variant(), \
                          self._create_variant(), self._create_variant()
        self._call_method('GetWindowRect', hwnd, x1, y1, x2, y2, rect_type)
        return x1.value, y1.value, x2.value, y2.value
    
    def get_window_size(self, hwnd: int) -> Tuple[int, int]:
        """Get window size.
        
        Returns:
            Tuple of (width, height)
        """
        width, height = self._create_variant(), self._create_variant()
        self._call_method('GetWindowSize', hwnd, width, height)
        return width.value, height.value
    
    def get_client_rect(self, hwnd: int) -> Tuple[int, int, int, int]:
        """Get client area rectangle.
        
        Returns:
            Tuple of (x1, y1, x2, y2)
        """
        x1, y1, x2, y2 = self._create_variant(), self._create_variant(), \
                          self._create_variant(), self._create_variant()
        self._call_method('GetClientRect', hwnd, x1, y1, x2, y2)
        return x1.value, y1.value, x2.value, y2.value
    
    def get_client_size(self, hwnd: int) -> Tuple[int, int]:
        """Get client area size.
        
        Returns:
            Tuple of (width, height)
        """
        width, height = self._create_variant(), self._create_variant()
        self._call_method('GetClientSize', hwnd, width, height)
        return width.value, height.value
    
    def get_window_title(self, hwnd: int) -> str:
        """Get window title text.
        
        Args:
            hwnd: Window handle
            
        Returns:
            Window title string
        """
        return self._call_method('GetWindowTitle', hwnd)
    
    def get_window_class(self, hwnd: int) -> str:
        """Get window class name.
        
        Args:
            hwnd: Window handle
            
        Returns:
            Window class name
        """
        return self._call_method('GetWindowClass', hwnd)
    
    def get_window_state(self, hwnd: int, state_type: int) -> int:
        """Get window state.
        
        Args:
            hwnd: Window handle
            state_type: State type to check
            
        Returns:
            State value
        """
        return self._call_method('GetWindowState', hwnd, state_type)
    
    def get_window_thread_process_id(self, hwnd: int, get_type: int = 0) -> int:
        """Get window thread or process ID.
        
        Args:
            hwnd: Window handle
            get_type: 0=process ID, 1=thread ID
            
        Returns:
            Process ID or Thread ID
        """
        return self._call_method('GetWindowThreadProcessId', hwnd, get_type)
    
    def get_window_process_path(self, hwnd: int, path_type: int = 0) -> str:
        """Get window process path.
        
        Args:
            hwnd: Window handle
            path_type: 0=full path, 1=filename only
            
        Returns:
            Process path string
        """
        return self._call_method('GetWindowProcessPath', hwnd, path_type)
    
    def get_foreground_window(self) -> int:
        """Get foreground window handle.
        
        Returns:
            Foreground window handle (HWND)
        """
        return self._call_method('GetForegroundWindow')
    
    def get_focus(self) -> int:
        """Get focused window handle.
        
        Returns:
            Focused window handle (HWND)
        """
        return self._call_method('GetFocus')
    
    def get_window_from_mouse(self) -> int:
        """Get window under mouse cursor.
        
        Returns:
            Window handle (HWND)
        """
        return self._call_method('GetWindowFromMouse')
    
    def get_window_from_point(self, x: int, y: int) -> int:
        """Get window at specified point.
        
        Args:
            x: X coordinate
            y: Y coordinate
            
        Returns:
            Window handle (HWND)
        """
        return self._call_method('GetWindowFromPoint', x, y)
    
    # ==================== Window Operations ====================
    
    def set_window_size(self, hwnd: int, width: int, height: int) -> int:
        """Set window size.
        
        Args:
            hwnd: Window handle
            width: New width
            height: New height
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetWindowSize', hwnd, width, height)
    
    def set_client_size(self, hwnd: int, width: int, height: int) -> int:
        """Set client area size.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetClientSize', hwnd, width, height)
    
    def set_window_state(self, hwnd: int, state: int) -> int:
        """Set window state (minimize, maximize, etc.).
        
        Args:
            hwnd: Window handle
            state: State to set
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetWindowState', hwnd, state)
    
    def set_window_title(self, hwnd: int, title: str) -> int:
        """Set window title.
        
        Args:
            hwnd: Window handle
            title: New title text
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetWindowTitle', hwnd, title)
    
    def set_window_transparent(self, hwnd: int, color: str, 
                                transparency: int, trans_type: int) -> int:
        """Set window transparency.
        
        Args:
            hwnd: Window handle
            color: Transparency color
            transparency: Transparency level (0-255)
            trans_type: Transparency type
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetWindowTransparent', hwnd, color,
                                 transparency, trans_type)
    
    def move_window(self, hwnd: int, x: int, y: int) -> int:
        """Move window to new position.
        
        Args:
            hwnd: Window handle
            x: New X position
            y: New Y position
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('MoveWindow', hwnd, x, y)
    
    def close_window(self, hwnd: int) -> int:
        """Close a window.
        
        Args:
            hwnd: Window handle
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('CloseWindow', hwnd)
    
    # ==================== Coordinate Conversion ====================
    
    def client_to_screen(self, hwnd: int, x: int, y: int) -> Tuple[int, int]:
        """Convert client coordinates to screen coordinates.
        
        Args:
            hwnd: Window handle
            x: Client X coordinate
            y: Client Y coordinate
            
        Returns:
            Tuple of (screen_x, screen_y)
        """
        vx, vy = self._create_variant(), self._create_variant()
        vx.value = x
        vy.value = y
        self._call_method('ClientToScreen', hwnd, vx, vy)
        return vx.value, vy.value
    
    def screen_to_client(self, hwnd: int, x: int, y: int) -> Tuple[int, int]:
        """Convert screen coordinates to client coordinates.
        
        Args:
            hwnd: Window handle
            x: Screen X coordinate
            y: Screen Y coordinate
            
        Returns:
            Tuple of (client_x, client_y)
        """
        vx, vy = self._create_variant(), self._create_variant()
        vx.value = x
        vy.value = y
        self._call_method('ScreenToClient', hwnd, vx, vy)
        return vx.value, vy.value
    
    # ==================== Drawing Functions ====================
    
    def draw_text(self, hwnd: int, x1: int, y1: int, x2: int, y2: int,
                  text: str, color: str, bk_color: str, draw_type: int) -> int:
        """Draw text on window.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DrawText', hwnd, x1, y1, x2, y2,
                                 text, color, bk_color, draw_type)
    
    def draw_text_d(self, hwnd: int, text: str, color: str, bk_color: str) -> int:
        """Draw text on window (direct mode).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DrawTextD', hwnd, text, color, bk_color)
    
    def clear_text_d(self, hwnd: int) -> int:
        """Clear drawn text from window.
        
        Args:
            hwnd: Window handle
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('ClearTextD', hwnd)
    
    def set_text_d(self, hwnd: int, x1: int, y1: int, x2: int, y2: int,
                   row: int, direction: int) -> int:
        """Set text drawing area.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetTextD', hwnd, x1, y1, x2, y2, row, direction)
    
    def draw_line(self, hwnd: int, x1: int, y1: int, x2: int, y2: int,
                  color: str, width: int, style: int) -> int:
        """Draw a line on window.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DrawLine', hwnd, x1, y1, x2, y2,
                                 color, width, style)
    
    def fill_rect(self, hwnd: int, x1: int, y1: int, x2: int, y2: int,
                  color: str) -> int:
        """Fill a rectangle on window.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('FillRect', hwnd, x1, y1, x2, y2, color)
    
    def draw_pic(self, hwnd: int, x: int, y: int, color: str,
                 pic_name: str) -> int:
        """Draw a picture on window.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DrawPic', hwnd, x, y, color, pic_name)
    
    def draw_gif(self, hwnd: int, x: int, y: int, pic_name: str,
                 delay: int, num: int) -> int:
        """Draw a GIF animation on window.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('DrawGif', hwnd, x, y, pic_name, delay, num)
    
    def stop_gif(self, hwnd: int, x: int, y: int, pic_name: str) -> int:
        """Stop GIF animation.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('StopGif', hwnd, x, y, pic_name)
    
    def set_font(self, hwnd: int, name: str, size: int, weight: int,
                 italic: int, underline: int, strike_out: int) -> int:
        """Set font for text drawing.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetFont', hwnd, name, size, weight,
                                 italic, underline, strike_out)
    
    def create_windows(self, x: int, y: int, width: int, height: int,
                       e_width: int, e_height: int, win_type: int) -> int:
        """Create a new window.
        
        Returns:
            Window handle (HWND)
        """
        return self._call_method('CreateWindows', x, y, width, height,
                                 e_width, e_height, win_type)
    
    def set_create_windows(self, win_type: int) -> int:
        """Set create window parameters.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetCreateWindows', win_type)
    
    def set_chwnd_size(self, hwnd: int, width: int, height: int) -> int:
        """Set child window size.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetCHwndSize', hwnd, width, height)