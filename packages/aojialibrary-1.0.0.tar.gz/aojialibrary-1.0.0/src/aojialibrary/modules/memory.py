"""
Memory Operations Module

Provides memory read/write operations for AoJia.
"""

from typing import Optional, Tuple
from ..core import AoJiaBase


class MemoryMixin(AoJiaBase):
    """Mixin class for memory operations."""
    
    # ==================== Memory Mode ====================
    
    def set_memory_mode(self, mode: int) -> int:
        """Set memory operation mode.
        
        Args:
            mode: Memory mode (0=kernel, 1=user, etc.)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetMemoryMode', mode)
    
    # ==================== Read Memory ====================
    
    def read_int_l(self, pid: int, hwnd: int, addr: int, 
                   data_type: int, mem_type: Optional[int] = None) -> int:
        """Read integer from address (long format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address (64-bit)
            data_type: Data size (0=byte, 1=word, 2=dword, 3=qword)
            mem_type: Memory type variant
            
        Returns:
            Integer value read
        """
        if mem_type is not None:
            vtype = self._create_variant()
            vtype.value = mem_type
            result = self._call_method('ReadIntL', pid, hwnd, addr, data_type, vtype)
            return result
        vtype = self._create_variant()
        result = self._call_method('ReadIntL', pid, hwnd, addr, data_type, vtype)
        return result
    
    def read_int_s(self, pid: int, hwnd: int, addr_str: str,
                   data_type: int, mem_type: Optional[int] = None) -> int:
        """Read integer from address (string format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr_str: Memory address string (can include offsets)
            data_type: Data size
            mem_type: Memory type variant
            
        Returns:
            Integer value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadIntS', pid, hwnd, addr_str, data_type, vtype)
        return result
    
    def read_float_l(self, pid: int, hwnd: int, addr: int,
                     mem_type: Optional[int] = None) -> float:
        """Read float from address (long format).
        
        Returns:
            Float value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadFloatL', pid, hwnd, addr, vtype)
        return result
    
    def read_float_s(self, pid: int, hwnd: int, addr_str: str,
                     mem_type: Optional[int] = None) -> float:
        """Read float from address (string format).
        
        Returns:
            Float value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadFloatS', pid, hwnd, addr_str, vtype)
        return result
    
    def read_double_l(self, pid: int, hwnd: int, addr: int,
                      mem_type: Optional[int] = None) -> float:
        """Read double from address (long format).
        
        Returns:
            Double value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadDoubleL', pid, hwnd, addr, vtype)
        return result
    
    def read_double_s(self, pid: int, hwnd: int, addr_str: str,
                      mem_type: Optional[int] = None) -> float:
        """Read double from address (string format).
        
        Returns:
            Double value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadDoubleS', pid, hwnd, addr_str, vtype)
        return result
    
    def read_string_l(self, pid: int, hwnd: int, addr: int, length: int,
                      encoding: int, mem_type: Optional[int] = None) -> str:
        """Read string from address (long format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address
            length: String length
            encoding: String encoding (0=ANSI, 1=Unicode)
            mem_type: Memory type
            
        Returns:
            String value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadStringL', pid, hwnd, addr, length, encoding, vtype)
        return result
    
    def read_string_s(self, pid: int, hwnd: int, addr_str: str, length: int,
                      encoding: int, mem_type: Optional[int] = None) -> str:
        """Read string from address (string format).
        
        Returns:
            String value read
        """
        vtype = self._create_variant()
        result = self._call_method('ReadStringS', pid, hwnd, addr_str, length, encoding, vtype)
        return result
    
    def read_data_l(self, pid: int, hwnd: int, addr: int, length: int) -> str:
        """Read binary data from address (long format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address
            length: Data length
            
        Returns:
            Hex string of data
        """
        return self._call_method('ReadDataL', pid, hwnd, addr, length)
    
    def read_data_s(self, pid: int, hwnd: int, addr_str: str, length: int) -> str:
        """Read binary data from address (string format).
        
        Returns:
            Hex string of data
        """
        return self._call_method('ReadDataS', pid, hwnd, addr_str, length)
    
    def read_data_la(self, pid: int, hwnd: int, addr: int, length: int) -> int:
        """Read binary data to address (long format).
        
        Returns:
            Address of data
        """
        return self._call_method('ReadDataLA', pid, hwnd, addr, length)
    
    def read_data_sa(self, pid: int, hwnd: int, addr_str: str, length: int) -> int:
        """Read binary data to address (string format).
        
        Returns:
            Address of data
        """
        return self._call_method('ReadDataSA', pid, hwnd, addr_str, length)
    
    # ==================== Write Memory ====================
    
    def write_int_l(self, pid: int, hwnd: int, addr: int,
                    value: int, data_type: int) -> int:
        """Write integer to address (long format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address
            value: Value to write
            data_type: Data size
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteIntL', pid, hwnd, addr, value, data_type)
    
    def write_int_s(self, pid: int, hwnd: int, addr_str: str,
                    value: int, data_type: int) -> int:
        """Write integer to address (string format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteIntS', pid, hwnd, addr_str, value, data_type)
    
    def write_float_l(self, pid: int, hwnd: int, addr: int, value: float) -> int:
        """Write float to address (long format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteFloatL', pid, hwnd, addr, value)
    
    def write_float_s(self, pid: int, hwnd: int, addr_str: str, value: float) -> int:
        """Write float to address (string format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteFloatS', pid, hwnd, addr_str, value)
    
    def write_double_l(self, pid: int, hwnd: int, addr: int, value: float) -> int:
        """Write double to address (long format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteDoubleL', pid, hwnd, addr, value)
    
    def write_double_s(self, pid: int, hwnd: int, addr_str: str, value: float) -> int:
        """Write double to address (string format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteDoubleS', pid, hwnd, addr_str, value)
    
    def write_string_l(self, pid: int, hwnd: int, addr: int,
                       text: str, encoding: int) -> int:
        """Write string to address (long format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address
            text: String to write
            encoding: String encoding (0=ANSI, 1=Unicode)
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteStringL', pid, hwnd, addr, text, encoding)
    
    def write_string_s(self, pid: int, hwnd: int, addr_str: str,
                       text: str, encoding: int) -> int:
        """Write string to address (string format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteStringS', pid, hwnd, addr_str, text, encoding)
    
    def write_data_l(self, pid: int, hwnd: int, addr: int, data: str) -> int:
        """Write binary data to address (long format).
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address
            data: Hex string data
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteDataL', pid, hwnd, addr, data)
    
    def write_data_s(self, pid: int, hwnd: int, addr_str: str, data: str) -> int:
        """Write binary data to address (string format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteDataS', pid, hwnd, addr_str, data)
    
    def write_data_la(self, pid: int, hwnd: int, addr: int,
                      data: int, length: int) -> int:
        """Write data from address (long format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteDataLA', pid, hwnd, addr, data, length)
    
    def write_data_sa(self, pid: int, hwnd: int, addr_str: str,
                      data: int, length: int) -> int:
        """Write data from address (string format).
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('WriteDataSA', pid, hwnd, addr_str, data, length)
    
    # ==================== Find Memory ====================
    
    def find_int(self, pid: int, hwnd: int, addr_start: str,
                 min_val: int, max_val: int, data_type: int,
                 step: int, find_type: int, process_num: int,
                 thread_num: int, filename: str) -> str:
        """Find integer values in memory range.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr_start: Start address or range string
            min_val: Minimum value
            max_val: Maximum value
            data_type: Data size type
            step: Search step
            find_type: Find type
            process_num: Number of processes
            thread_num: Number of threads
            filename: Output file path (empty for string result)
            
        Returns:
            Result string or empty if written to file
        """
        return self._call_method('FindInt', pid, hwnd, addr_start, min_val, max_val,
                                 data_type, step, find_type, process_num, thread_num, filename)
    
    def find_float(self, pid: int, hwnd: int, addr_start: str,
                   min_val: float, max_val: float, step: int,
                   find_type: int, process_num: int, thread_num: int,
                   filename: str) -> str:
        """Find float values in memory range.
        
        Returns:
            Result string
        """
        return self._call_method('FindFloat', pid, hwnd, addr_start, min_val, max_val,
                                 step, find_type, process_num, thread_num, filename)
    
    def find_double(self, pid: int, hwnd: int, addr_start: str,
                    min_val: float, max_val: float, step: int,
                    find_type: int, process_num: int, thread_num: int,
                    filename: str) -> str:
        """Find double values in memory range.
        
        Returns:
            Result string
        """
        return self._call_method('FindDouble', pid, hwnd, addr_start, min_val, max_val,
                                 step, find_type, process_num, thread_num, filename)
    
    def find_string(self, pid: int, hwnd: int, addr_start: str,
                    search_str: str, encoding: int, null_char: int,
                    step: int, find_type: int, process_num: int,
                    thread_num: int, filename: str) -> str:
        """Find string in memory.
        
        Returns:
            Result string
        """
        return self._call_method('FindString', pid, hwnd, addr_start, search_str,
                                 encoding, null_char, step, find_type,
                                 process_num, thread_num, filename)
    
    def find_data(self, pid: int, hwnd: int, addr_start: str,
                  data: str, step: int, find_type: int,
                  process_num: int, thread_num: int, filename: str) -> str:
        """Find binary data pattern in memory.
        
        Returns:
            Result string
        """
        return self._call_method('FindData', pid, hwnd, addr_start, data, step,
                                 find_type, process_num, thread_num, filename)
    
    # ==================== Data Conversion ====================
    
    def int_to_data(self, value: int, data_type: int) -> str:
        """Convert integer to hex data string.
        
        Args:
            value: Integer value
            data_type: Data type (0-3)
            
        Returns:
            Hex string
        """
        return self._call_method('IntToData', value, data_type)
    
    def int64_to_data(self, value: int, data_type: int) -> str:
        """Convert 64-bit integer to hex data string.
        
        Returns:
            Hex string
        """
        return self._call_method('Int64ToData', value, data_type)
    
    def float_to_data(self, value: float) -> str:
        """Convert float to hex data string.
        
        Returns:
            Hex string
        """
        return self._call_method('FloatToData', value)
    
    def double_to_data(self, value: float) -> str:
        """Convert double to hex data string.
        
        Returns:
            Hex string
        """
        return self._call_method('DoubleToData', value)
    
    def string_to_data(self, text: str, encoding: int, null_char: int) -> str:
        """Convert string to hex data string.
        
        Returns:
            Hex string
        """
        return self._call_method('StringToData', text, encoding, null_char)
    
    # ==================== Memory Allocation ====================
    
    def virtual_alloc_ex(self, pid: int, hwnd: int, addr: int,
                         size: int, alloc_type: int) -> int:
        """Allocate memory in remote process.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Preferred address (0 for auto)
            size: Size to allocate
            alloc_type: Allocation type
            
        Returns:
            Allocated memory address
        """
        return self._call_method('VirtualAllocEx', pid, hwnd, addr, size, alloc_type)
    
    def virtual_free_ex(self, pid: int, hwnd: int, addr: int) -> int:
        """Free memory in remote process.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Address to free
            
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('VirtualFreeEx', pid, hwnd, addr)
    
    def virtual_protect_ex(self, pid: int, hwnd: int, addr: int,
                           size: int, flags: int, protect: int) -> Tuple[int, int]:
        """Change memory protection in remote process.
        
        Args:
            pid: Process ID
            hwnd: Window handle
            addr: Memory address
            size: Region size
            flags: Protection flags
            protect: New protection
            
        Returns:
            Tuple of (old_protection, result)
        """
        vtype = self._create_variant()
        result = self._call_method('VirtualProtectEx', pid, hwnd, addr, size,
                                   flags, protect, vtype)
        return vtype.value, result
    
    def virtual_query_ex(self, pid: int, hwnd: int, addr: int) -> Tuple[str, int, int, int, int]:
        """Query memory information.
        
        Returns:
            Tuple of (info_string, a_protect, protect, state, mem_type)
        """
        a_protect = self._create_variant()
        protect = self._create_variant()
        state = self._create_variant()
        mem_type = self._create_variant()
        result = self._call_method('VirtualQueryEx', pid, hwnd, addr,
                                   a_protect, protect, state, mem_type)
        return result, a_protect.value, protect.value, state.value, mem_type.value
    
    def free_process_memory(self, pid: int, hwnd: int) -> int:
        """Free process memory.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('FreeProcessMemory', pid, hwnd)
    
    def set_param_64_to_addr(self) -> int:
        """Set 64-bit parameter to address mode.
        
        Returns:
            1 on success, 0 on failure
        """
        return self._call_method('SetParam64ToAddr')
