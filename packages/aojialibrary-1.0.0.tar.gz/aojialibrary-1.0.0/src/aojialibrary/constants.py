"""
AoJia Library Constants

CLSID and other constants for AoJia COM objects.
"""

# AoJiaD main object CLSID
AOJIA_CLSID = "{4f27e588-5b1e-45b4-ad67-e32d45c4e9ca}"

# CompReg CLSID (for component registration)
COMPREG_CLSID = "{0ad9d0f8-9a12-4300-881a-b9f220463b02}"

# ProgID for easier access
AOJIA_PROGID = "AoJia.D"

# DLL filenames
AOJIA_DLL_64 = "AoJia64.dll"
AREGJ_DLL_64 = "ARegJ64.dll"
