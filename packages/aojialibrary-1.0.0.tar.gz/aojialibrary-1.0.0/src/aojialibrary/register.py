"""
AoJia DLL Registration Module

Provides methods to register AoJia DLLs using ARegJ64.dll.
Two registration methods are available:
1. SetDllPath: Set DLL path without modifying registry (recommended)
2. RegA/RegW: Register COM to system registry
"""

import ctypes
import os
from pathlib import Path
from typing import Optional

from .constants import AOJIA_DLL_64, AREGJ_DLL_64


def get_dll_path(dll_name: str = AOJIA_DLL_64) -> Path:
    """Get the absolute path to a DLL file in the package.
    
    Args:
        dll_name: Name of the DLL file (default: AoJia64.dll)
        
    Returns:
        Path object pointing to the DLL file
    """
    dll_dir = Path(__file__).parent / "dll"
    return dll_dir / dll_name


def get_aregj_path() -> Path:
    """Get the absolute path to ARegJ64.dll.
    
    Returns:
        Path object pointing to ARegJ64.dll
    """
    return get_dll_path(AREGJ_DLL_64)


def set_dll_path(dll_path: Optional[str] = None, use_unicode: bool = True) -> bool:
    """Set AoJia DLL path using ARegJ64.dll.
    
    This method allows using AoJia DLL without modifying system registry.
    It loads the DLL directly into the current process memory.
    
    Args:
        dll_path: Path to AoJia64.dll. If None, uses the bundled DLL.
        use_unicode: Whether to use Unicode version (SetDllPathW). Default True.
        
    Returns:
        True if successful, False otherwise
        
    Raises:
        FileNotFoundError: If ARegJ64.dll or AoJia64.dll not found
        OSError: If DLL loading fails
    """
    if dll_path is None:
        dll_path = str(get_dll_path(AOJIA_DLL_64))
    
    aregj_path = get_aregj_path()
    if not aregj_path.exists():
        raise FileNotFoundError(f"ARegJ64.dll not found at: {aregj_path}")
    
    if not Path(dll_path).exists():
        raise FileNotFoundError(f"AoJia64.dll not found at: {dll_path}")
    
    try:
        aregj = ctypes.CDLL(str(aregj_path))
        
        if use_unicode:
            set_dll_path_func = aregj.SetDllPathW
            path_arg = ctypes.c_wchar_p(dll_path)
        else:
            set_dll_path_func = aregj.SetDllPathA
            path_arg = ctypes.c_char_p(dll_path.encode('ansi'))
        
        # Type: LONG WINAPI SetDllPathA(LPCSTR DllPath, LONG Type)
        set_dll_path_func.argtypes = [type(path_arg), ctypes.c_long]
        set_dll_path_func.restype = ctypes.c_long
        
        result = set_dll_path_func(path_arg, 0)
        return result == 1
    except Exception as e:
        raise OSError(f"Failed to set DLL path: {e}")


def register_com(dll_path: Optional[str] = None, use_unicode: bool = True) -> bool:
    """Register AoJia COM component to system registry.
    
    This method writes COM registration information to the Windows registry.
    Requires administrator privileges.
    
    Args:
        dll_path: Path to AoJia64.dll. If None, uses the bundled DLL.
        use_unicode: Whether to use Unicode version (RegW). Default True.
        
    Returns:
        True if successful, False otherwise
        
    Raises:
        FileNotFoundError: If ARegJ64.dll or AoJia64.dll not found
        OSError: If registration fails
    """
    if dll_path is None:
        dll_path = str(get_dll_path(AOJIA_DLL_64))
    
    aregj_path = get_aregj_path()
    if not aregj_path.exists():
        raise FileNotFoundError(f"ARegJ64.dll not found at: {aregj_path}")
    
    if not Path(dll_path).exists():
        raise FileNotFoundError(f"AoJia64.dll not found at: {dll_path}")
    
    try:
        aregj = ctypes.CDLL(str(aregj_path))
        
        if use_unicode:
            reg_func = aregj.RegW
            path_arg = ctypes.c_wchar_p(dll_path)
        else:
            reg_func = aregj.RegA
            path_arg = ctypes.c_char_p(dll_path.encode('ansi'))
        
        reg_func.argtypes = [type(path_arg)]
        reg_func.restype = ctypes.c_long
        
        result = reg_func(path_arg)
        return result == 1
    except Exception as e:
        raise OSError(f"Failed to register COM: {e}")


def unregister_com(dll_path: Optional[str] = None, use_unicode: bool = True) -> bool:
    """Unregister AoJia COM component from system registry.
    
    This method removes COM registration information from the Windows registry.
    Requires administrator privileges.
    
    Args:
        dll_path: Path to AoJia64.dll. If None, uses the bundled DLL.
        use_unicode: Whether to use Unicode version (UnRegW). Default True.
        
    Returns:
        True if successful, False otherwise
        
    Raises:
        FileNotFoundError: If ARegJ64.dll or AoJia64.dll not found
        OSError: If unregistration fails
    """
    if dll_path is None:
        dll_path = str(get_dll_path(AOJIA_DLL_64))
    
    aregj_path = get_aregj_path()
    if not aregj_path.exists():
        raise FileNotFoundError(f"ARegJ64.dll not found at: {aregj_path}")
    
    if not Path(dll_path).exists():
        raise FileNotFoundError(f"AoJia64.dll not found at: {dll_path}")
    
    try:
        aregj = ctypes.CDLL(str(aregj_path))
        
        if use_unicode:
            unreg_func = aregj.UnRegW
            path_arg = ctypes.c_wchar_p(dll_path)
        else:
            unreg_func = aregj.UnRegA
            path_arg = ctypes.c_char_p(dll_path.encode('ansi'))
        
        unreg_func.argtypes = [type(path_arg)]
        unreg_func.restype = ctypes.c_long
        
        result = unreg_func(path_arg)
        return result == 1
    except Exception as e:
        raise OSError(f"Failed to unregister COM: {e}")


def register_with_pywin32(dll_path: Optional[str] = None) -> bool:
    """Register AoJia COM using pywin32.
    
    Alternative registration method using pywin32's COM registration.
    Requires pywin32 and administrator privileges.
    
    Args:
        dll_path: Path to AoJia64.dll. If None, uses the bundled DLL.
        
    Returns:
        True if successful, False otherwise
    """
    try:
        import win32api
        import pythoncom
    except ImportError:
        raise ImportError("pywin32 is required for this method. Install with: pip install pywin32")
    
    if dll_path is None:
        dll_path = str(get_dll_path(AOJIA_DLL_64))
    
    if not Path(dll_path).exists():
        raise FileNotFoundError(f"AoJia64.dll not found at: {dll_path}")
    
    try:
        # Load the DLL and call DllRegisterServer
        dll_handle = win32api.LoadLibrary(dll_path)
        
        # Get DllRegisterServer function
        dll = ctypes.CDLL(dll_path)
        dll_register = dll.DllRegisterServer
        dll_register.restype = ctypes.c_long
        
        result = dll_register()
        win32api.FreeLibrary(dll_handle)
        
        return result == 0  # S_OK = 0
    except Exception as e:
        raise OSError(f"Failed to register with pywin32: {e}")


def unregister_with_pywin32(dll_path: Optional[str] = None) -> bool:
    """Unregister AoJia COM using pywin32.
    
    Args:
        dll_path: Path to AoJia64.dll. If None, uses the bundled DLL.
        
    Returns:
        True if successful, False otherwise
    """
    try:
        import win32api
    except ImportError:
        raise ImportError("pywin32 is required for this method. Install with: pip install pywin32")
    
    if dll_path is None:
        dll_path = str(get_dll_path(AOJIA_DLL_64))
    
    if not Path(dll_path).exists():
        raise FileNotFoundError(f"AoJia64.dll not found at: {dll_path}")
    
    try:
        dll = ctypes.CDLL(dll_path)
        dll_unregister = dll.DllUnregisterServer
        dll_unregister.restype = ctypes.c_long
        
        result = dll_unregister()
        return result == 0  # S_OK = 0
    except Exception as e:
        raise OSError(f"Failed to unregister with pywin32: {e}")
