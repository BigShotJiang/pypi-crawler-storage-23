"""
AoJia Main Class

Provides the main AoJia class that combines all functionality modules.
"""

from typing import Optional

from .constants import AOJIA_CLSID
from .core import AoJiaBase, AoJiaError, AoJiaCOMError
from .modules import (
    WindowMixin,
    KeyboardMouseMixin,
    ColorImageMixin,
    MemoryMixin,
    ProcessMixin,
    FileMixin,
    TextMixin,
    BackgroundMixin,
    MiscMixin,
)


class AoJia(
    WindowMixin,
    KeyboardMouseMixin,
    ColorImageMixin,
    MemoryMixin,
    ProcessMixin,
    FileMixin,
    TextMixin,
    BackgroundMixin,
    MiscMixin,
    AoJiaBase
):
    """
    AoJia COM Object Wrapper
    
    This class provides a Pythonic interface to the AoJia automation library.
    It wraps all AoJia COM methods and provides convenient Python-style access.
    
    Usage:
        # Simple initialization (auto-registers DLL)
        from aojialibrary import AoJia
        
        aj = AoJia()
        aj.initialize()
        
        # Use the library
        hwnd = aj.find_window(0, "notepad", 0, "", "", 1, 0)
        aj.move_to(100, 100)
        aj.left_click()
        
        # Clean up
        aj.release()
        
        # Or use as context manager
        with AoJia() as aj:
            aj.move_to(100, 100)
            aj.left_click()
    """

    def __init__(self, auto_register: bool = True, dll_path: Optional[str] = None):
        """Initialize AoJia object.
        
        Args:
            auto_register: If True, automatically register DLL on first use
            dll_path: Custom path to AoJia64.dll (uses bundled DLL if None)
        """
        super().__init__()
        self._auto_register = auto_register
        self._dll_path = dll_path
        self._registered = False

    def initialize(self) -> bool:
        """Initialize the AoJia COM object.
        
        This method must be called before using any AoJia functions.
        It will automatically register the DLL if auto_register is True.
        
        Returns:
            True if initialization successful, False otherwise
            
        Raises:
            AoJiaError: If initialization fails
        """
        if self._initialized:
            return True

        try:
            # Try to create COM object directly first (if already registered)
            self._create_com_object()
            return True
        except Exception:
            # COM object creation failed, try to register
            if self._auto_register:
                try:
                    from .register import set_dll_path
                    if set_dll_path(self._dll_path):
                        self._registered = True
                        self._create_com_object()
                        return True
                except Exception as e:
                    raise AoJiaError(f"Failed to register DLL: {e}")

            raise AoJiaError(
                "Failed to initialize AoJia. The DLL may not be registered. "
                "Try calling aojialibrary.register.set_dll_path() manually."
            )

    def _create_com_object(self) -> None:
        """Create the COM object instance."""
        try:
            import win32com.client
            self._com_obj = win32com.client.Dispatch(AOJIA_CLSID)
            self._initialized = True
        except Exception as e:
            raise AoJiaCOMError(f"Failed to create COM object: {e}")

    def __enter__(self) -> 'AoJia':
        """Context manager entry."""
        self.initialize()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.release()

    def __del__(self):
        """Destructor to ensure resources are released."""
        self.release()

    # Convenience method aliases for common operations

    def click(self, x: int, y: int) -> int:
        """Move to position and click (convenience method).
        
        Args:
            x: X coordinate
            y: Y coordinate
            
        Returns:
            1 on success
        """
        self.move_to(x, y)
        return self.left_click()

    def find_and_click(self, x1: int, y1: int, x2: int, y2: int,
                       pic_name: str, sim: float = 0.9) -> bool:
        """Find picture and click it (convenience method).
        
        Args:
            x1: Left coordinate of search region
            y1: Top coordinate of search region
            x2: Right coordinate of search region
            y2: Bottom coordinate of search region
            pic_name: Picture to find
            sim: Similarity threshold
            
        Returns:
            True if found and clicked, False otherwise
        """
        found, pic_idx, x, y = self.find_pic(x1, y1, x2, y2, pic_name, "000000", sim, 0, 0)
        if found:
            self.move_to(x, y)
            self.left_click()
            return True
        return False

    def wait_for_color(self, x: int, y: int, color: str,
                       timeout: int = 5000, interval: int = 100) -> bool:
        """Wait for specific color at position.
        
        Args:
            x: X coordinate
            y: Y coordinate
            color: Target color
            timeout: Timeout in milliseconds
            interval: Check interval in milliseconds
            
        Returns:
            True if color found, False if timeout
        """
        import time
        start = time.time() * 1000
        while (time.time() * 1000 - start) < timeout:
            if self.cmp_color(x, y, color, 1.0, 0):
                return True
            time.sleep(interval / 1000)
        return False

    def type_text(self, text: str, interval_min: int = 50,
                  interval_max: int = 100) -> None:
        """Type text with random intervals (convenience method).
        
        Args:
            text: Text to type
            interval_min: Minimum interval between keystrokes (ms)
            interval_max: Maximum interval between keystrokes (ms)
        """
        for char in text:
            self.key_press_s(char)
            self.delay(interval_min, interval_max)


# Create a module-level function for quick access
_aojia_instance: Optional[AoJia] = None


def get_aojia() -> AoJia:
    """Get or create a singleton AoJia instance.
    
    Returns:
        AoJia instance
    """
    global _aojia_instance
    if _aojia_instance is None or not _aojia_instance.is_initialized:
        _aojia_instance = AoJia()
        _aojia_instance.initialize()
    return _aojia_instance
