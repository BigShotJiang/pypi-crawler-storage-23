# AoJia Library

Python wrapper for AoJia Windows automation library.

A powerful Windows automation library providing screen capture, color/image finding, keyboard/mouse simulation, memory operations, OCR, and more.

## Features

- **Window Operations**: Find, move, resize, close windows
- **Keyboard Simulation**: Key press, text input with random delays
- **Mouse Simulation**: Move, click, drag with human-like behavior
- **Screen Capture**: Capture screen regions to files
- **Color Finding**: Find colors and multi-color patterns
- **Image Matching**: Find images on screen with similarity matching
- **OCR**: Text recognition using dictionary files
- **Memory Operations**: Read/write process memory
- **Process Management**: Enumerate, terminate processes
- **File Operations**: Read, write, copy, move files
- **Background Mode**: Send input to background windows

## Requirements

- Windows OS (64-bit)
- Python 3.8+
- pywin32

## Installation

```bash
pip install aojialibrary
```

## Quick Start

```python
from aojialibrary import AoJia

# Create and initialize
aj = AoJia()
aj.initialize()

# Find a window
hwnd = aj.find_window(0, "notepad", 0, "", "", 1, 0)
print(f"Found window: {hwnd}")

# Get window info
title = aj.get_window_title(hwnd)
print(f"Window title: {title}")

# Mouse operations
aj.move_to(100, 100)
aj.left_click()

# Screen capture
aj.screen_shot(0, 0, 800, 600, "screenshot.png", 2)  # PNG format

# Find color
found, x, y = aj.find_color(0, 0, 1920, 1080, "FF0000", 0.9, 0)
if found:
    print(f"Found red at ({x}, {y})")

# Find image
found, idx, x, y = aj.find_pic(0, 0, 1920, 1080, "target.png", "000000", 0.9, 0, 0)

# Type text
aj.type_text("Hello, World!")

# Clean up
aj.release()
```

## Context Manager

```python
from aojialibrary import AoJia

with AoJia() as aj:
    # Move mouse and click
    aj.move_to(100, 100)
    aj.left_click()
    
    # Find and click image
    if aj.find_and_click(0, 0, 1920, 1080, "button.png", 0.9):
        print("Clicked button!")
```

## API Reference

### Initialization

```python
from aojialibrary import AoJia, set_dll_path

# Use bundled DLL (recommended)
aj = AoJia()
aj.initialize()

# Or use custom DLL path
set_dll_path(r"C:\path\to\AoJia64.dll")
aj = AoJia(auto_register=False)
aj.initialize()
```

### Window Operations

```python
# Find window by criteria
hwnd = aj.find_window(
    parent=0,           # Parent window handle
    pro_name="notepad", # Process name
    pro_id=0,           # Process ID (0 for any)
    class_name="",      # Window class (empty for any)
    title="",           # Window title (empty for any)
    win_type=1,         # 0=all, 1=visible, 2=hidden
    timeout=0           # Timeout in ms
)

# Get window information
title = aj.get_window_title(hwnd)
rect = aj.get_window_rect(hwnd)  # Returns (x1, y1, x2, y2)
size = aj.get_window_size(hwnd)  # Returns (width, height)
class_name = aj.get_window_class(hwnd)

# Window operations
aj.move_window(hwnd, x, y)
aj.set_window_size(hwnd, width, height)
aj.close_window(hwnd)

# Coordinate conversion
screen_x, screen_y = aj.client_to_screen(hwnd, client_x, client_y)
client_x, client_y = aj.screen_to_client(hwnd, screen_x, screen_y)
```

### Mouse Operations

```python
# Basic movements
aj.move_to(x, y)           # Move to absolute position
aj.move_r(dx, dy)          # Move relative to current position

# With randomization (human-like)
aj.move_to_d(x, y, xr_min, xr_max, yr_min, yr_max, r_min, r_max, speed)

# Clicks
aj.left_click()
aj.right_click()
aj.middle_click()

# Clicks with random delay
aj.left_click_d(r_min=50, r_max=100, rd_min=100, rd_max=200)

# Drag operations
aj.left_down()
aj.move_to(x, y)
aj.left_up()

# Mouse wheel
aj.wheel_up()
aj.wheel_down()

# Get mouse position
x, y = aj.get_mouse_pos()
```

### Keyboard Operations

```python
# Key press (virtual key code)
aj.key_press(0x41)  # 'A' key

# Key press (string)
aj.key_press_s("a")
aj.key_press_s("enter")
aj.key_press_s("ctrl")

# Key combinations
aj.key_press_z("ctrl+c", 50, 100)  # Ctrl+C with random delay

# Text input with random delays
aj.type_text("Hello, World!", interval_min=50, interval_max=100)

# Key state
if aj.get_key_d_state(0x41):  # Check if 'A' is pressed
    print("A is pressed")
```

### Color and Image Finding

```python
# Get color at position
color = aj.get_color(x, y)

# Compare color
if aj.cmp_color(x, y, "FF0000", 0.9, 0):
    print("Color matches!")

# Find color in region
found, x, y = aj.find_color(
    x1=0, y1=0, x2=1920, y2=1080,
    color="FF0000",
    sim=0.9,      # Similarity (0.0-1.0)
    direction=0   # Search direction
)

# Find all color occurrences
results = aj.find_color_ex(0, 0, 1920, 1080, "FF0000", 0.9, 0)
# Returns "x1,y1|x2,y2|..."

# Find image
found, idx, x, y = aj.find_pic(
    x1=0, y1=0, x2=1920, y2=1080,
    pic_name="target.png",
    delta_color="000000",  # Color tolerance
    sim=0.9,
    direction=0,
    pic_type=0
)

# Load pictures for faster matching
aj.load_pic("image1.png|image2.png")
found, idx, x, y = aj.find_pic(0, 0, 1920, 1080, "image1.png|image2.png", "000000", 0.9, 0, 0)
aj.free_pic("")  # Free all loaded pictures
```

### Screen Capture

```python
# Capture screen region
aj.screen_shot(
    x1=0, y1=0, x2=800, y2=600,
    pic_name="screenshot.png",
    pic_type=2,    # 0=BMP, 1=JPG, 2=PNG
    quality=100    # For JPG (1-100)
)
```

### OCR Text Recognition

```python
# Load dictionary
aj.load_dict(0, "dict.txt")

# Find text
found, idx, x, y = aj.find_str(
    x1=0, y1=0, x2=1920, y2=1080,
    text="Hello",
    color="FFFFFF-000000",
    sim=0.9,
    direction=0,
    color_type=0,
    dict_type=0
)

# OCR (recognize all text in region)
text = aj.ocr(
    x1=0, y1=0, x2=800, y2=600,
    text="",
    color="FFFFFF-000000",
    sim=0.9,
    color_type=0, dict_type=0,
    ocr_type=0, type_t=0,
    h_line="",
    pic_name=""
)
print(f"Recognized: {text}")

# Free dictionary
aj.free_dict(0)
```

### Memory Operations

```python
# Get process ID from window
pid = aj.get_window_thread_process_id(hwnd, 0)

# Read integer
value = aj.read_int_l(pid, hwnd, address, 2, None)  # 2=dword

# Read float
value = aj.read_float_l(pid, hwnd, address)

# Read string
text = aj.read_string_l(pid, hwnd, address, 100, 0, None)  # 100 chars, ANSI

# Write integer
aj.write_int_l(pid, hwnd, address, 12345, 2)

# Find value in memory
results = aj.find_int(pid, hwnd, "0-7FFFFFFFFFFFFFFF", 100, 200, 2, 4096, 0, 1, 1, "")
```

### Background Mode

```python
# Enable background mode
aj.kq_hou_tai(
    hwnd=hwnd,
    screen="gdi",     # Screen capture mode
    keyboard="normal", # Keyboard mode
    mouse="normal",    # Mouse mode
    flag="",
    bg_type=0
)

# Now you can send input to background window
aj.move_to(100, 100)
aj.left_click()

# Disable background mode
aj.gb_hou_tai()
```

### File Operations

```python
# Read/write file
content = aj.read_file("test.txt")
aj.write_file("test.txt", "Hello")

# File management
aj.copy_file("src.txt", "dst.txt", 1)  # Overwrite
aj.move_file("old.txt", "new.txt", 1)
aj.delete_file("temp.txt")

# INI file operations
value = aj.read_ini("config.ini", "Section", "Key")
aj.write_ini("config.ini", "Section", "Key", "Value")

# Check file/folder
if aj.is_file_or_folder("path") == 1:
    print("It's a file")
```

### Process Operations

```python
# Get current process info
pid = aj.get_current_process_id()
tid = aj.get_current_thread_id()

# Enumerate processes
processes = aj.enum_process("notepad")  # Filter by name

# Terminate process
aj.terminate_process(pid, 0, "", 0)

# Module info
base = aj.get_module_base_addr(pid, hwnd, "kernel32.dll")
size = aj.get_module_size(pid, hwnd, "kernel32.dll")
```

### Utility Functions

```python
# Random numbers and strings
rand_int = aj.random(1, 100)
rand_str = aj.random_str(10, 2)  # 10 chars, alphanumeric

# Delay
aj.delay(100, 200)  # Random delay 100-200ms

# System info
version = aj.ver_s()  # Plugin version
os_info = aj.get_os()  # OS information

# Error handling
error_code = aj.get_last_error()
```

## DLL Registration

The library includes the necessary DLL files. Registration is automatic on first use.

For manual registration:

```python
from aojialibrary import register

# Set DLL path (recommended - no registry modification)
register.set_dll_path()

# Or register COM to system registry (requires admin)
register.register_com()

# Unregister
register.unregister_com()
```

## License

MIT License

## Credits

This library wraps the AoJia automation library for Windows.
