"""
Core module - Base classes and configurations.
"""

from torchagentic.models.base import BaseAgentModel, ModelConfig

__all__ = ["BaseAgentModel", "ModelConfig"]
