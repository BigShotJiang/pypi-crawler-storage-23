# -*- coding: utf-8 -*-
""" ResearchFieldClassifier package. """

from orkgnlp.annotation.rfclf.classifier import ResearchFieldClassifier

__all__ = ["ResearchFieldClassifier"]
