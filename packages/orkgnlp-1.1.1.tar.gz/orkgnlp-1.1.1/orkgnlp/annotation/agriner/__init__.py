# -*- coding: utf-8 -*-
""" Agri-NER package. """

from orkgnlp.annotation.agriner.annotator import AgriNer

__all__ = ["AgriNer"]
