# -*- coding: utf-8 -*-
"""
Utility package that provides a set of different helper functions and classes.
"""
