# -*- coding: utf-8 -*-
""" Package for the templates recommendation service. """

from orkgnlp.nli.templates.recommender import TemplatesRecommender

__all__ = ["TemplatesRecommender"]
