# -*- coding: utf-8 -*-
from typing import Any

from overrides import overrides

from orkgnlp.common.service.base import ORKGNLPBaseDecoder


class DeepResearchDecoder(ORKGNLPBaseDecoder):
    """
    The DeepResearchDecoder decodes the CS-NER service model's output
    to a user-friendly one.
    """

    def __init__(self):
        super().__init__()

    @overrides(check_signature=False)
    def decode(self, model_output: Any, **kwargs: Any) -> Any:
        return model_output
