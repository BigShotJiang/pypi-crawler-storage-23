# -*- coding: utf-8 -*-
"""
Deep-research services.
"""

from orkgnlp.deepresearch.deepresearch import DeepResearch

__all__ = ["DeepResearch"]
