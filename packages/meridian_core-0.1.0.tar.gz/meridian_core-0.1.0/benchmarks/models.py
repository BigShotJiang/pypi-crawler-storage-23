from typing import Optional

from pydantic import BaseModel, Field


class User(BaseModel):
    id: int
    name: str
    email: str
    age: int = Field(ge=0, le=150)
    active: bool = True


class UserCreate(BaseModel):
    name: str
    email: str
    age: int = Field(ge=18, le=150)


class Post(BaseModel):
    id: int
    user_id: int
    title: str
    content: str
    likes: int = 0


class PostCreate(BaseModel):
    title: str
    content: str


class FilterRequest(BaseModel):
    search: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    category: Optional[str] = None


class BulkItem(BaseModel):
    name: str
    value: int
    tags: list[str] = Field(default_factory=list)


class DeepNestedModel(BaseModel):
    name: str
    child: Optional["DeepNestedModel"] = None


DeepNestedModel.model_rebuild()
