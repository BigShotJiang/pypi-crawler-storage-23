import json


async def app(scope, receive, send):
    if scope["type"] != "http":
        return

    method = scope["method"]
    path = scope["path"]

    if path == "/bare" and method == "GET":
        body = json.dumps({"message": "hello"}).encode()

    elif path.startswith("/path/") and method == "GET":
        segment = path.split("/")[2]
        item_id = int(segment)
        body = json.dumps({"id": item_id}).encode()

    elif path == "/query" and method == "GET":
        qs = scope.get("query_string", b"").decode()
        params = dict(p.split("=") for p in qs.split("&") if "=" in p)
        name = params.get("name", "world")
        count = int(params.get("count", "1"))
        body = json.dumps({"name": name, "count": count}).encode()

    elif path == "/body" and method == "POST":
        chunks = []
        while True:
            msg = await receive()
            chunks.append(msg.get("body", b""))
            if not msg.get("more_body", False):
                break
        data = json.loads(b"".join(chunks))
        body = json.dumps({"echo": data.get("value")}).encode()

    elif path == "/middleware" and method == "GET":
        body = json.dumps({"message": "hello"}).encode()

    else:
        body = json.dumps({"detail": "not found"}).encode()
        await send(
            {
                "type": "http.response.start",
                "status": 404,
                "headers": [(b"content-type", b"application/json")],
            }
        )
        await send({"type": "http.response.body", "body": body})
        return

    await send(
        {
            "type": "http.response.start",
            "status": 200,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode()),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})
