from benchmarks.db import Database
from benchmarks.models import (
    UserCreate,
    PostCreate,
    FilterRequest,
    BulkItem,
    DeepNestedModel,
    User,
)
from benchmarks.repositories import PostRepository, UserRepository

from meridian import (
    Meridian,
    Path,
    Query,
    Body,
    Inject,
    middleware,
    ValidationConfig,
    OperationalConfig,
    JSONResponse,
)
from meridian.di import Container, SINGLETON, REQUEST
from typing import Optional, AsyncGenerator


@middleware
async def mw_one(request, next_handler):
    return await next_handler(request)


@middleware
async def mw_two(request, next_handler):
    return await next_handler(request)


@middleware
async def mw_three(request, next_handler):
    return await next_handler(request)


async def init_db():
    db = Database()
    await db.connect()
    return db


async def close_db(db: Database):
    await db.close()


container = Container()
container.register(Database, factory=init_db, teardown=close_db, scope=SINGLETON)
container.register(UserRepository, scope=REQUEST)
container.register(PostRepository, scope=REQUEST)


class Level5:
    pass


class Level4:
    def __init__(self, l5: Inject[Level5]):
        self.l5 = l5


class Level3:
    def __init__(self, l4: Inject[Level4]):
        self.l4 = l4


class Level2:
    def __init__(self, l3: Inject[Level3]):
        self.l3 = l3


class Level1:
    def __init__(self, l2: Inject[Level2]):
        self.l2 = l2


container.register(Level5, scope=REQUEST)
container.register(Level4, scope=REQUEST)
container.register(Level3, scope=REQUEST)
container.register(Level2, scope=REQUEST)
container.register(Level1, scope=REQUEST)


@container.provider(scope=REQUEST)
async def yield_provider() -> AsyncGenerator[str, None]:
    yield "yielded_value"


app = Meridian(
    name="meridian-benchmark",
    validation=ValidationConfig(
        mode="strict", validate_responses=True, ignore_unknown_query_params=True
    ),
    operational=OperationalConfig(
        max_concurrent_requests=1000, request_deadline_ms=5000, max_body_size=1_048_576
    ),
    debug=False,
).with_di(container)


@app.get("/bare")
async def bare() -> dict:
    """Simple JSON response"""
    return {"message": "hello"}


@app.get("/path/{item_id}")
async def path_param(item_id: Path[int]) -> dict:
    """Path parameter extraction"""
    return {"id": item_id}


@app.get("/query")
async def query_params(
    name: Query[str] = "world",
    count: Query[int] = 1,
) -> dict:
    """Query parameter extraction with defaults"""
    return {"name": name, "count": count}


@app.post("/body")
async def json_body(body: Body[dict]) -> dict:
    """JSON body parsing"""
    return {"echo": body.get("value")}


@app.get("/middleware")
async def with_middleware() -> dict:
    """Endpoint with middleware processing"""
    return {"message": "hello"}


@app.get("/users/{user_id}")
async def get_user(user_id: Path[int], repo: Inject[UserRepository]) -> dict:
    user = await repo.get_user(user_id)
    if user:
        return dict(user)
    return {"error": "not found"}


@app.post("/users")
async def create_user(
    body: Body[UserCreate], repo: Inject[UserRepository]
) -> User | JSONResponse:
    try:
        data = await repo.create_user(body.name, body.email, body.age)
        return User(**data)
    except Exception as e:
        from meridian import JSONResponse

        return JSONResponse({"error": str(e)}, status_code=400)


@app.get("/users")
async def list_users(
    limit: Query[int] = 10, offset: Query[int] = 0, repo: Inject[UserRepository] = None
) -> dict:
    users = await repo.list_users(limit, offset) if repo else []
    return {"users": users, "limit": limit, "offset": offset, "total": len(users)}


@app.get("/users/{user_id}/posts")
async def get_user_posts(
    user_id: Path[int],
    limit: Query[int] = 10,
    offset: Query[int] = 0,
    repo: Inject[PostRepository] = None,
) -> dict:
    posts = await repo.get_user_posts(user_id, limit, offset) if repo else []
    return {
        "user_id": user_id,
        "posts": posts,
        "total": len(posts),
        "limit": limit,
        "offset": offset,
    }


@app.post("/users/{user_id}/posts")
async def create_post(
    user_id: Path[int], body: Body[PostCreate], repo: Inject[PostRepository] = None
) -> dict:
    if not repo:
        return {}
    return await repo.create_post(user_id, body.title, body.content)


@app.get("/search")
async def search_items(
    q: Query[str],
    category: Query[Optional[str]] = "general",
    sort: Query[str] = "relevance",
    limit: Query[int] = 20,
) -> dict:
    """Search with multiple query parameters and filters"""
    return {
        "query": q,
        "category": category,
        "sort": sort,
        "limit": limit,
        "results": [
            {"id": i, "title": f"Result {i}: {q}", "category": category or "general"}
            for i in range(1, min(limit + 1, 6))
        ],
        "total": 100,
    }


@app.post("/filter")
async def filter_products(body: Body[FilterRequest]) -> dict:
    """Complex filtering with multiple optional criteria"""
    return {
        "search": body.search,
        "min_price": body.min_price,
        "max_price": body.max_price,
        "category": body.category,
        "results": [
            {
                "id": i,
                "name": f"Product {i}",
                "price": 10.99 * i,
                "category": body.category or "all",
            }
            for i in range(1, 6)
        ],
        "total_found": 45,
    }


@app.post("/posts/{post_id}/comments")
async def add_comment(post_id: Path[int], body: Body[dict]) -> dict:
    """Nested resource with path and body parameters"""
    return {
        "post_id": post_id,
        "comment_id": 5001,
        "author": body.get("author", "anonymous"),
        "content": body.get("content", ""),
        "created_at": "2026-02-26T10:00:00Z",
    }


@app.get("/products/{product_id}/reviews")
async def get_product_reviews(
    product_id: Path[int], min_rating: Query[int] = 1, max_rating: Query[int] = 5
) -> dict:
    """Filtered list with path and query parameters"""
    return {
        "product_id": product_id,
        "min_rating": min_rating,
        "max_rating": max_rating,
        "reviews": [
            {
                "id": i,
                "rating": min_rating + i,
                "author": f"User {i}",
                "text": f"Review {i}",
            }
            for i in range(min(3, max_rating - min_rating + 1))
        ],
        "average_rating": (min_rating + max_rating) / 2,
    }


@app.post("/bulk/create")
async def bulk_create(body: Body[dict]) -> dict:
    """Bulk operation with large payload"""
    items = body.get("items", [])
    return {
        "created": len(items),
        "ids": list(range(1001, 1001 + len(items))),
        "status": "success",
    }


@app.get("/stats")
async def get_stats(
    metric: Query[str] = "all",
    granularity: Query[str] = "daily",
    limit: Query[int] = 30,
) -> dict:
    """Complex aggregated response with multiple dimensions"""
    return {
        "metric": metric,
        "granularity": granularity,
        "limit": limit,
        "data": [
            {"timestamp": f"2026-02-{i:02d}", "value": 100 + i * 10, "variance": i * 2}
            for i in range(1, limit + 1)
        ],
        "summary": {
            "total": 3000 + limit * 10,
            "average": 100 + limit / 2,
            "min": 100,
            "max": 100 + limit * 10,
        },
    }


@app.post("/validate")
async def validate_data(body: Body[dict]) -> dict:
    """Data validation and transformation"""
    data = body.get("data", {})
    return {
        "original": data,
        "validated": True,
        "transformed": {
            "name": (data.get("name", "") or "").upper(),
            "age": int(data.get("age", 0)) if data.get("age") else None,
            "email": (data.get("email", "") or "").lower(),
        },
    }


@app.get("/nested/{category}/{subcategory}/{item_id}")
async def get_nested_resource(
    category: Path[str],
    subcategory: Path[str],
    item_id: Path[int],
    detail: Query[bool] = False,
) -> dict:
    """Deeply nested resource path"""
    result = {
        "category": category,
        "subcategory": subcategory,
        "item_id": item_id,
        "name": f"{category}/{subcategory}/{item_id}",
    }

    if detail:
        result["details"] = {
            "description": f"Detailed info for {category}/{subcategory}/{item_id}",
            "metadata": {"created": "2026-02-26", "updated": "2026-02-26"},
            "tags": ["tag1", "tag2", "tag3"],
        }

    return result


@app.get("/ping")
async def ping() -> str:
    return "pong"


@app.get("/di/deep")
async def di_deep(root: Inject[Level1]) -> str:
    return "ok"


@app.get("/di/yield")
async def di_yield(val: Inject[str]) -> str:
    return val


@app.post("/payload/large")
async def payload_large(body: Body[list[BulkItem]]) -> dict:
    return {"count": len(body)}


@app.post("/payload/deep")
async def payload_deep(body: Body[DeepNestedModel]) -> dict:
    return {"ok": True}


@app.get("/sleep")
async def sleep_task(seconds: Query[float] = 0.1) -> dict:
    import anyio

    await anyio.sleep(seconds)
    return {"slept": seconds}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="warning")
