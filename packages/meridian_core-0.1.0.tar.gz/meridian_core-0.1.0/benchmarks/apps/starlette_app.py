"""
Starlette benchmark app.

Starlette is FastAPI's foundation. Comparing FastAPI vs Starlette
shows how much FastAPI's validation layer (Pydantic) costs.
Comparing Starlette vs raw ASGI shows Starlette's routing overhead.
"""

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware


class NoopMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        return await call_next(request)


async def bare(request: Request):
    return JSONResponse({"message": "hello"})


async def path_param(request: Request):
    item_id = int(request.path_params["item_id"])
    return JSONResponse({"id": item_id})


async def query_params(request: Request):
    name = request.query_params.get("name", "world")
    count = int(request.query_params.get("count", "1"))
    return JSONResponse({"name": name, "count": count})


async def json_body(request: Request):
    data = await request.json()
    return JSONResponse({"echo": data.get("value")})


async def with_middleware(request: Request):
    return JSONResponse({"message": "hello"})


app = Starlette(
    routes=[
        Route("/bare", bare),
        Route("/path/{item_id}", path_param),
        Route("/query", query_params),
        Route("/body", json_body, methods=["POST"]),
        Route("/middleware", with_middleware),
    ],
    middleware=[
        Middleware(NoopMiddleware),
        Middleware(NoopMiddleware),
        Middleware(NoopMiddleware),
    ],
)
