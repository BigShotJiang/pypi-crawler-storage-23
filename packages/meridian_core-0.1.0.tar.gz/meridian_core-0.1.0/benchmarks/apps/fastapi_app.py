from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


from starlette.middleware.base import BaseHTTPMiddleware


class NoopMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        return await call_next(request)


app.add_middleware(NoopMiddleware)
app.add_middleware(NoopMiddleware)
app.add_middleware(NoopMiddleware)


@app.get("/bare")
async def bare():
    return {"message": "hello"}


@app.get("/path/{item_id}")
async def path_param(item_id: int):
    return {"id": item_id}


@app.get("/query")
async def query_params(name: str = "world", count: int = 1):
    return {"name": name, "count": count}


class BodyPayload(BaseModel):
    value: str = ""


@app.post("/body")
async def json_body(payload: BodyPayload):
    return {"echo": payload.value}


@app.get("/middleware")
async def with_middleware():
    return {"message": "hello"}
