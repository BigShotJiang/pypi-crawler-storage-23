import string

from locust import HttpUser, task, between
import random
import uuid


class BaselineUser(HttpUser):
    """Pure ASGI overhead - minimal framework interaction"""

    wait_time = between(0, 0)

    @task
    def ping(self):
        self.client.get("/ping")


class DIHeavyUser(HttpUser):
    """Stress testing the Scoped DI resolution"""

    wait_time = between(0, 0)

    @task(weight=5)
    def deep_resolution(self):
        """Resolving a 5-level deep dependency tree"""
        self.client.get("/di/deep")

    @task(weight=2)
    def yield_provider(self):
        """Testing the new async yield provider overhead"""
        self.client.get("/di/yield")


class PayloadUser(HttpUser):
    """Stress testing JSON parsing and Pydantic validation (M1/M6)"""

    wait_time = between(0, 0)

    @task(weight=3)
    def large_payload(self):
        """Bulk list of items"""
        count = random.randint(10, 5000)
        items = [
            {"name": f"Item {i}", "value": i, "tags": list(string.ascii_letters)}
            for i in range(count)
        ]
        self.client.post("/payload/large", json=items)

    @task(weight=1)
    def deep_nested_payload(self):
        """Deeply nested recursive model"""

        def build_nested(depth):
            if depth == 0:
                return {"name": "leaf"}
            return {"name": f"node_{depth}", "child": build_nested(depth - 1)}

        payload = build_nested(15)
        self.client.post("/payload/deep", json=payload)


class ConcurrencyUser(HttpUser):
    """Stress testing backpressure and structured concurrency (M1)"""

    wait_time = between(0, 0)

    @task
    def trigger_backpressure(self):
        """Simulate slow requests to hit max_concurrent_requests"""
        self.client.get("/sleep?seconds=0.2")


class LegacyUser(HttpUser):
    """Original comprehensive benchmark tasks"""

    wait_time = between(0.1, 0.5)

    @task(weight=3)
    def bare(self):
        self.client.get("/bare")

    @task(weight=2)
    def path_param(self):
        item_id = random.randint(1, 100)
        self.client.get(f"/path/{item_id}")

    @task(weight=2)
    def create_user(self):
        user_id = str(uuid.uuid4())[:8]
        self.client.post(
            "/users",
            data={
                "name": f"User {user_id}",
                "email": f"user_{user_id}@example.com",
                "age": random.randint(18, 80),
            },
        )
