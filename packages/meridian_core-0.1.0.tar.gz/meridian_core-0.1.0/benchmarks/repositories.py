import sqlite3
from benchmarks.db import Database
from typing import Optional


class UserRepository:
    def __init__(self, db: Database):
        if db is None:
            raise ValueError("Database instance cannot be None")
        if db.conn is None:
            raise RuntimeError(
                "Database connection not initialized. Call db.connect() first."
            )
        self.db = db

    async def get_user(self, user_id: int) -> Optional[dict]:
        try:
            cursor = self.db.conn.execute(
                "SELECT id, name, email, age, active FROM users WHERE id = ?",
                (user_id,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            raise RuntimeError(f"Failed to get user {user_id}: {e}")

    async def create_user(self, name: str, email: str, age: int) -> dict:
        try:
            cursor = self.db.conn.execute(
                "INSERT INTO users (name, email, age, active) VALUES (?, ?, ?, 1)",
                (name, email, age),
            )
            self.db.conn.commit()
            return {
                "id": cursor.lastrowid,
                "name": name,
                "email": email,
                "age": age,
                "active": True,
            }
        except sqlite3.IntegrityError as e:
            raise ValueError(f"User creation failed: {e}")
        except Exception as e:
            raise RuntimeError(f"Database error during user creation: {e}")

    async def update_user(self, user_id: int, **kwargs) -> Optional[dict]:
        allowed_fields = {"name", "email", "age", "active"}
        update_fields = {k: v for k, v in kwargs.items() if k in allowed_fields}

        if not update_fields:
            return await self.get_user(user_id)

        try:
            set_clause = ", ".join(f"{k} = ?" for k in update_fields.keys())
            values = list(update_fields.values()) + [user_id]

            self.db.conn.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
            self.db.conn.commit()
            return await self.get_user(user_id)
        except Exception as e:
            raise RuntimeError(f"Failed to update user {user_id}: {e}")

    async def delete_user(self, user_id: int) -> bool:
        try:
            cursor = self.db.conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
            self.db.conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            raise RuntimeError(f"Failed to delete user {user_id}: {e}")

    async def list_users(self, limit: int = 10, offset: int = 0) -> list[dict]:
        try:
            if limit <= 0:
                limit = 10
            if offset < 0:
                offset = 0

            cursor = self.db.conn.execute(
                "SELECT id, name, email, age, active FROM users LIMIT ? OFFSET ?",
                (limit, offset),
            )
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            raise RuntimeError(f"Failed to list users: {e}")

    async def get_total_users(self) -> int:
        try:
            cursor = self.db.conn.execute("SELECT COUNT(*) FROM users")
            row = cursor.fetchone()
            return row[0] if row else 0
        except Exception as e:
            raise RuntimeError(f"Failed to count users: {e}")

    async def search_users(self, query: str) -> list[dict]:
        try:
            search_pattern = f"%{query}%"
            cursor = self.db.conn.execute(
                "SELECT id, name, email, age, active FROM users WHERE name LIKE ? OR email LIKE ?",
                (search_pattern, search_pattern),
            )
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            raise RuntimeError(f"Failed to search users: {e}")

    async def user_exists(self, user_id: int) -> bool:
        try:
            cursor = self.db.conn.execute(
                "SELECT 1 FROM users WHERE id = ? LIMIT 1", (user_id,)
            )
            return cursor.fetchone() is not None
        except Exception as e:
            raise RuntimeError(f"Failed to check user existence: {e}")

    async def email_exists(self, email: str) -> bool:
        try:
            cursor = self.db.conn.execute(
                "SELECT 1 FROM users WHERE email = ? LIMIT 1", (email,)
            )
            return cursor.fetchone() is not None
        except Exception as e:
            raise RuntimeError(f"Failed to check email existence: {e}")


class PostRepository:
    def __init__(self, db: Database):
        if db is None:
            raise ValueError("Database instance cannot be None")
        if db.conn is None:
            raise RuntimeError(
                "Database connection not initialized. Call db.connect() first."
            )
        self.db = db

    async def get_post(self, post_id: int) -> Optional[dict]:
        try:
            cursor = self.db.conn.execute(
                "SELECT id, user_id, title, content, likes FROM posts WHERE id = ?",
                (post_id,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            raise RuntimeError(f"Failed to get post {post_id}: {e}")

    async def create_post(self, user_id: int, title: str, content: str) -> dict:
        try:
            cursor = self.db.conn.execute(
                "INSERT INTO posts (user_id, title, content, likes) VALUES (?, ?, ?, 0)",
                (user_id, title, content),
            )
            self.db.conn.commit()
            return {
                "id": cursor.lastrowid,
                "user_id": user_id,
                "title": title,
                "content": content,
                "likes": 0,
            }
        except sqlite3.IntegrityError as e:
            raise ValueError(f"Post creation failed: {e}")
        except Exception as e:
            raise RuntimeError(f"Database error during post creation: {e}")

    async def update_post(self, post_id: int, **kwargs) -> Optional[dict]:
        allowed_fields = {"title", "content", "likes"}
        update_fields = {k: v for k, v in kwargs.items() if k in allowed_fields}

        if not update_fields:
            return await self.get_post(post_id)

        try:
            set_clause = ", ".join(f"{k} = ?" for k in update_fields.keys())
            values = list(update_fields.values()) + [post_id]

            self.db.conn.execute(f"UPDATE posts SET {set_clause} WHERE id = ?", values)
            self.db.conn.commit()
            return await self.get_post(post_id)
        except Exception as e:
            raise RuntimeError(f"Failed to update post {post_id}: {e}")

    async def delete_post(self, post_id: int) -> bool:
        try:
            cursor = self.db.conn.execute("DELETE FROM posts WHERE id = ?", (post_id,))
            self.db.conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            raise RuntimeError(f"Failed to delete post {post_id}: {e}")

    async def get_user_posts(
        self, user_id: int, limit: int = 10, offset: int = 0
    ) -> list[dict]:
        try:
            if limit <= 0:
                limit = 10
            if offset < 0:
                offset = 0

            cursor = self.db.conn.execute(
                "SELECT id, user_id, title, content, likes FROM posts WHERE user_id = ? LIMIT ? OFFSET ?",
                (user_id, limit, offset),
            )
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            raise RuntimeError(f"Failed to list posts for user {user_id}: {e}")

    async def get_user_post_count(self, user_id: int) -> int:
        try:
            cursor = self.db.conn.execute(
                "SELECT COUNT(*) FROM posts WHERE user_id = ?", (user_id,)
            )
            row = cursor.fetchone()
            return row[0] if row else 0
        except Exception as e:
            raise RuntimeError(f"Failed to count posts for user {user_id}: {e}")

    async def like_post(self, post_id: int) -> Optional[dict]:
        try:
            self.db.conn.execute(
                "UPDATE posts SET likes = likes + 1 WHERE id = ?", (post_id,)
            )
            self.db.conn.commit()
            return await self.get_post(post_id)
        except Exception as e:
            raise RuntimeError(f"Failed to like post {post_id}: {e}")

    async def unlike_post(self, post_id: int) -> Optional[dict]:
        try:
            self.db.conn.execute(
                "UPDATE posts SET likes = MAX(0, likes - 1) WHERE id = ?", (post_id,)
            )
            self.db.conn.commit()
            return await self.get_post(post_id)
        except Exception as e:
            raise RuntimeError(f"Failed to unlike post {post_id}: {e}")

    async def search_posts(self, query: str) -> list[dict]:
        try:
            search_pattern = f"%{query}%"
            cursor = self.db.conn.execute(
                "SELECT id, user_id, title, content, likes FROM posts WHERE title LIKE ? OR content LIKE ?",
                (search_pattern, search_pattern),
            )
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            raise RuntimeError(f"Failed to search posts: {e}")

    async def get_trending_posts(self, limit: int = 10) -> list[dict]:
        try:
            cursor = self.db.conn.execute(
                "SELECT id, user_id, title, content, likes FROM posts ORDER BY likes DESC LIMIT ?",
                (limit,),
            )
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            raise RuntimeError(f"Failed to get trending posts: {e}")
