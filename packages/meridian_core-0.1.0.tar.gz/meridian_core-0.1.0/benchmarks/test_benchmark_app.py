import asyncio
import time
import uuid
import pytest
from meridian.testing import AsyncTestClient
from benchmarks.apps.meridian_app import app, container, Database, UserRepository


@pytest.fixture
async def client():
    if not container.is_built:
        container.build()

    db = Database(":memory:")
    await db.connect()
    container._singletons[Database] = db

    async with AsyncTestClient(app) as test_client:
        yield test_client

    await db.close()


class TestDIScopeBehavior:
    @pytest.mark.asyncio
    async def test_singleton_db_instance_shared(self, client):
        db_instance = container._singletons.get(Database)
        assert db_instance is not None

        db_again = container._singletons.get(Database)
        assert id(db_instance) == id(db_again)

    @pytest.mark.asyncio
    async def test_request_scope_repo_isolation(self):
        scope1 = container.request_scope()
        scope2 = container.request_scope()

        repo1 = await scope1.resolve(UserRepository)
        repo2 = await scope2.resolve(UserRepository)

        assert id(repo1) != id(repo2)
        assert id(repo1.db) == id(repo2.db)

    @pytest.mark.asyncio
    async def test_request_scope_repo_cache_within_scope(self):
        scope = container.request_scope()

        repo1 = await scope.resolve(UserRepository)
        repo2 = await scope.resolve(UserRepository)

        assert id(repo1) == id(repo2)


class TestDIDatabaseOperations:
    @pytest.mark.asyncio
    async def test_create_user_via_di(self, client):
        email = f"alice_{uuid.uuid4().hex[:8]}@example.com"
        resp = await client.post(
            "/users", body={"name": "Alice", "email": email, "age": 28}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "Alice"
        assert data["email"] == email

    @pytest.mark.asyncio
    async def test_get_user_via_di(self, client):
        email = f"bob_{uuid.uuid4().hex[:8]}@example.com"
        create_resp = await client.post(
            "/users", body={"name": "Bob", "email": email, "age": 30}
        )
        user_id = create_resp.json()["id"]

        get_resp = await client.get(f"/users/{user_id}")
        assert get_resp.status_code == 200
        data = get_resp.json()
        assert data["name"] == "Bob"
        assert data["id"] == user_id
        assert data["email"] == email

    @pytest.mark.asyncio
    async def test_list_users_via_di(self, client):
        await client.post(
            "/users",
            body={
                "name": "User1",
                "email": f"test1_{uuid.uuid4().hex[:8]}@example.com",
                "age": 25,
            },
        )
        await client.post(
            "/users",
            body={
                "name": "User2",
                "email": f"test2_{uuid.uuid4().hex[:8]}@example.com",
                "age": 26,
            },
        )

        resp = await client.get("/users?limit=10&offset=0")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["users"]) >= 2

    @pytest.mark.asyncio
    async def test_create_post_via_di(self, client):
        user_resp = await client.post(
            "/users",
            body={
                "name": "Charlie",
                "email": f"charlie_{uuid.uuid4().hex[:8]}@example.com",
                "age": 32,
            },
        )
        user_id = user_resp.json()["id"]

        post_resp = await client.post(
            f"/users/{user_id}/posts",
            body={"title": "First Post", "content": "Hello World"},
        )
        assert post_resp.status_code == 200
        data = post_resp.json()
        assert data["title"] == "First Post"
        assert data["user_id"] == user_id

    @pytest.mark.asyncio
    async def test_get_user_posts_via_di(self, client):
        user_resp = await client.post(
            "/users",
            body={
                "name": "Diana",
                "email": f"diana_{uuid.uuid4().hex[:8]}@example.com",
                "age": 29,
            },
        )
        data = user_resp.json()
        if "id" not in data:
            pytest.fail(f"User creation failed: {data}")
        user_id = data["id"]

        await client.post(
            f"/users/{user_id}/posts", body={"title": "Post 1", "content": "Content 1"}
        )
        await client.post(
            f"/users/{user_id}/posts", body={"title": "Post 2", "content": "Content 2"}
        )

        resp = await client.get(f"/users/{user_id}/posts?limit=10&offset=0")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["posts"]) == 2


class TestObservabilityOverhead:
    @pytest.mark.asyncio
    async def test_bare_endpoint_latency(self, client):
        times = []
        for _ in range(100):
            start = time.perf_counter()
            await client.get("/bare")
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 50

    @pytest.mark.asyncio
    async def test_di_endpoint_latency(self, client):
        await client.post(
            "/users",
            body={
                "name": "Test",
                "email": f"test_{uuid.uuid4().hex[:8]}@example.com",
                "age": 25,
            },
        )

        times = []
        for _ in range(50):
            start = time.perf_counter()
            await client.get("/users/1")
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 100

    @pytest.mark.asyncio
    async def test_path_param_extraction_overhead(self, client):
        times = []
        for i in range(100):
            start = time.perf_counter()
            await client.get(f"/path/{i}")
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 50

    @pytest.mark.asyncio
    async def test_query_param_extraction_overhead(self, client):
        times = []
        for i in range(100):
            start = time.perf_counter()
            await client.get(f"/query?name=test{i}&count={i}")
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 50

    @pytest.mark.asyncio
    async def test_body_parsing_overhead(self, client):
        times = []
        for i in range(50):
            start = time.perf_counter()
            await client.post("/body", body={"value": f"test{i}"})
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 100

    @pytest.mark.asyncio
    async def test_middleware_chain_overhead(self, client):
        times = []
        for _ in range(100):
            start = time.perf_counter()
            await client.get("/middleware")
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 50

    @pytest.mark.asyncio
    async def test_database_read_latency(self, client):
        email = f"test_{uuid.uuid4().hex[:8]}@example.com"
        create_resp = await client.post(
            "/users", body={"name": "PerfTest", "email": email, "age": 25}
        )
        data = create_resp.json()
        if "id" not in data:
            pytest.fail(f"User creation failed: {data}")
        user_id = data["id"]

        times = []
        for _ in range(50):
            start = time.perf_counter()
            await client.get(f"/users/{user_id}")
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 100

    @pytest.mark.asyncio
    async def test_database_write_latency(self, client):
        times = []
        for i in range(50):
            email = f"user{i}_{uuid.uuid4().hex[:8]}@example.com"
            start = time.perf_counter()
            await client.post(
                "/users", body={"name": f"User{i}", "email": email, "age": 25 + i % 30}
            )
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

        avg_latency = sum(times) / len(times)
        assert avg_latency < 150


class TestDIConcurrency:
    @pytest.mark.asyncio
    async def test_concurrent_user_creation(self, client):
        tasks = []
        for i in range(20):
            task = client.post(
                "/users",
                body={
                    "name": f"Concurrent{i}",
                    "email": f"conc{i}_{i}_{time.time_ns()}@example.com",
                    "age": 25,
                },
            )
            tasks.append(task)

        responses = await asyncio.gather(*tasks)

        for resp in responses:
            assert resp.status_code == 200
            assert "id" in resp.json()

    @pytest.mark.asyncio
    async def test_concurrent_user_reads(self, client):
        create_resp = await client.post(
            "/users",
            body={
                "name": "ReadTest",
                "email": f"readtest_{time.time_ns()}@example.com",
                "age": 25,
            },
        )
        user_id = create_resp.json()["id"]

        tasks = []
        for _ in range(20):
            task = client.get(f"/users/{user_id}")
            tasks.append(task)

        responses = await asyncio.gather(*tasks)

        for resp in responses:
            assert resp.status_code == 200
            assert resp.json()["id"] == user_id

    @pytest.mark.asyncio
    async def test_concurrent_mixed_operations(self, client):
        tasks = []

        for i in range(10):
            tasks.append(
                client.post(
                    "/users",
                    body={
                        "name": f"Mixed{i}",
                        "email": f"mixed{i}_{i}_{time.time_ns()}@example.com",
                        "age": 25,
                    },
                )
            )

        responses = await asyncio.gather(*tasks, return_exceptions=True)

        for r in responses:
            assert not isinstance(r, Exception)
            assert r.status_code == 200

        read_tasks = [client.get(f"/users/{i}") for i in range(1, 6)]
        read_responses = await asyncio.gather(*read_tasks)

        for r in read_responses:
            assert r.status_code == 200
