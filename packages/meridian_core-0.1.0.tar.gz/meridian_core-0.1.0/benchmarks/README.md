# Meridian Benchmark Suite

This directory contains the performance testing suite for the Meridian framework.

## Test Personas (Segmented Analysis)

The suite uses specialized Locust User classes to isolate different framework overheads:

| Persona | Focus Area      | Description |
|---------|-----------------|-------------|
| **BaselineUser** | Gateway         | Minimal ASGI logic. Measures the raw overhead of the routing and request/response abstraction. |
| **DIHeavyUser** | DI              | Resolves a 5-level deep dependency graph and exercises `async yield` providers with teardown logic. |
| **PayloadUser** | Validation      | Processes large bulk lists and deeply nested recursive JSON models using Pydantic `TypeAdapter`. |
| **ConcurrencyUser** | Backpressure    | Simulates slow I/O (sleep) to test structured concurrency and worker utilization under load. |

## Local Execution

### 1. Start the Benchmark App
The target application is optimized for benchmarking with an in-memory database and Uvicorn.
```bash
uv run python -m benchmarks.apps.meridian_app
```

### 2. Run Locust
**Interactive Web UI:**
```bash
uv run locust -f benchmarks/locustfile.py -H http://localhost:8000
```

**Headless (60s run with report):**
```bash
uv run locust -f benchmarks/locustfile.py --headless -u 20 -r 5 -t 60s -H http://localhost:8000 --html benchmark_report.html
```

**Targeting a Specific Scenario:**
To test only DI overhead:
```bash
uv run locust -f benchmarks/locustfile.py DIHeavyUser --headless -u 20 -r 5 -t 30s
```

## Distributed Benchmarking in Kubernetes

For high-scale testing, deploy Locust in a Master/Worker configuration.

### 1. Master Strategy
The Master node manages the UI and coordinates workers but does not generate load itself.
```yaml
# locust-master-deployment.yaml
containers:
- name: master
  image: your-repo/meridian-benchmarks:latest
  args: ["locust", "-f", "benchmarks/locustfile.py", "--master", "-H", "http://meridian-app-svc"]
  ports:
  - containerPort: 8089  # Web UI
  - containerPort: 5557  # Worker communication
```

### 2. Worker Strategy (Scalable)
Workers scale horizontally to generate the actual traffic.
```yaml
# locust-worker-deployment.yaml
replicas: 10
containers:
- name: worker
  image: your-repo/meridian-benchmarks:latest
  args: ["locust", "-f", "benchmarks/locustfile.py", "--worker", "--master-host", "locust-master-svc"]
```

### 3. Target App
Ensure your Meridian app is deployed with enough replicas and resources to handle the distributed load from all workers.

> [!TIP]
> Use the environment variable `LOCUST_AUTOSTART=true` and `LOCUST_RUN_TIME=5m` in K8s deployments to run automated CI/CD performance gates without manual UI intervention.
