"""
Radix Tree — Full Test Suite

Tests are organised into sections. Each test has a comment explaining
WHAT is being tested and WHY it's a distinct case worth covering.

The Router contract being tested:
  - router.add(method, path, handler, name=None) → Route
  - router.match(method, path) → Match(route, path_params)
  - raises NotFound on unmatched path
  - raises MethodNotAllowed on matched path, wrong method
  - raises ConfigurationError on duplicate registration

Run with: pytest tests/test_router.py
"""

from __future__ import annotations
import pytest
from meridian.router import Router
from meridian.exceptions import NotFound, MethodNotAllowed, ConfigurationError


def h(name: str):
    async def handler(): ...

    handler.__name__ = name
    return handler


def test_static_root_path_matches():
    """Static: root path '/' matches"""
    r = Router()
    r.add("GET", "/", h("root"))
    m = r.match("GET", "/")
    assert m.path_params == {}


def test_static_single_segment():
    """Static: single segment '/users'"""
    r = Router()
    r.add("GET", "/users", h("users"))
    m = r.match("GET", "/users")
    assert m.path_params == {}


def test_static_deeply_nested():
    """Static: deeply nested '/a/b/c/d/e'"""
    r = Router()
    r.add("GET", "/a/b/c/d/e", h("deep"))
    m = r.match("GET", "/a/b/c/d/e")
    assert m.path_params == {}


def test_static_multiple_siblings():
    """Static: multiple sibling routes at same depth"""
    r = Router()
    r.add("GET", "/users", h("users"), name="users")
    r.add("GET", "/posts", h("posts"), name="posts")
    r.add("GET", "/comments", h("comments"), name="comments")
    assert r.match("GET", "/users").route.name == "users"
    assert r.match("GET", "/posts").route.name == "posts"
    assert r.match("GET", "/comments").route.name == "comments"


def test_static_parent_and_child_both_registered():
    """Static: route registered at parent and child both match independently"""
    r = Router()
    r.add("GET", "/users", h("list"), name="list")
    r.add("GET", "/users/active", h("active"), name="active")
    assert r.match("GET", "/users").route.name == "list"
    assert r.match("GET", "/users/active").route.name == "active"


def test_param_single_param_extracts_value():
    """Param: single param '/users/{id}' extracts value"""
    r = Router()
    r.add("GET", "/users/{id}", h("get_user"))
    m = r.match("GET", "/users/42")
    assert m.path_params == {"id": "42"}


def test_param_value_is_string():
    """Param: value is always a string — not coerced"""
    r = Router()
    r.add("GET", "/items/{id}", h("item"))
    m = r.match("GET", "/items/99")
    assert isinstance(m.path_params["id"], str), "Router must return raw strings"


def test_param_multiple_params():
    """Param: multiple params in one path"""
    r = Router()
    r.add("GET", "/orgs/{org}/repos/{repo}", h("repo"))
    m = r.match("GET", "/orgs/anthropic/repos/meridian")
    assert m.path_params == {"org": "anthropic", "repo": "meridian"}


def test_param_three_params():
    """Param: three params in one path"""
    r = Router()
    r.add("GET", "/a/{x}/b/{y}/c/{z}", h("three"))
    m = r.match("GET", "/a/1/b/2/c/3")
    assert m.path_params == {"x": "1", "y": "2", "z": "3"}


def test_param_at_root_level():
    """Param: param at root level '/{id}'"""
    r = Router()
    r.add("GET", "/{id}", h("root_param"))
    m = r.match("GET", "/hello")
    assert m.path_params == {"id": "hello"}


def test_param_matches_special_characters():
    """Param: param matches segment with special characters"""
    r = Router()
    r.add("GET", "/users/{id}", h("user"))
    m = r.match("GET", "/users/user-name_v2.0")
    assert m.path_params["id"] == "user-name_v2.0"


def test_param_matches_numeric_string():
    """Param: param matches numeric-looking string"""
    r = Router()
    r.add("GET", "/users/{id}", h("user"))
    m = r.match("GET", "/users/007")
    assert m.path_params["id"] == "007"


def test_param_empty_value_does_not_match():
    """Param: empty param value does NOT match — segment must be non-empty"""
    r = Router()
    r.add("GET", "/users/{id}", h("user"))

    try:
        m = r.match("GET", "/users/")
        assert m.path_params.get("id") != "", (
            "Empty string should not be a valid param value"
        )
    except NotFound:
        pass


def test_priority_static_beats_param_static_first():
    """Priority: static beats param — static registered first"""
    r = Router()
    r.add("GET", "/users/me", h("me"), name="static")
    r.add("GET", "/users/{id}", h("user"), name="param")
    assert r.match("GET", "/users/me").route.name == "static"


def test_priority_static_beats_param_param_first():
    """Priority: static beats param — param registered first"""
    r = Router()
    r.add("GET", "/users/{id}", h("user"), name="param")
    r.add("GET", "/users/me", h("me"), name="static")
    assert r.match("GET", "/users/me").route.name == "static"


def test_priority_param_still_matches():
    """Priority: param still matches when static doesn't"""
    r = Router()
    r.add("GET", "/users/me", h("me"), name="static")
    r.add("GET", "/users/{id}", h("user"), name="param")
    assert r.match("GET", "/users/42").route.name == "param"
    assert r.match("GET", "/users/42").path_params == {"id": "42"}


def test_priority_multiple_static_siblings():
    """Priority: multiple static siblings, param catches the rest"""
    r = Router()
    r.add("GET", "/users/me", h("me"), name="me")
    r.add("GET", "/users/active", h("active"), name="active")
    r.add("GET", "/users/deleted", h("deleted"), name="deleted")
    r.add("GET", "/users/{id}", h("user"), name="param")

    assert r.match("GET", "/users/me").route.name == "me"
    assert r.match("GET", "/users/active").route.name == "active"
    assert r.match("GET", "/users/deleted").route.name == "deleted"
    assert r.match("GET", "/users/99").route.name == "param"
    assert r.match("GET", "/users/99").path_params == {"id": "99"}


def test_priority_static_at_deeper_level():
    """Priority: static at deeper level beats param at same level"""
    r = Router()
    r.add("GET", "/users/{id}/settings", h("user_settings"), name="param")
    r.add("GET", "/users/me/settings", h("me_settings"), name="static")
    assert r.match("GET", "/users/me/settings").route.name == "static"
    assert r.match("GET", "/users/42/settings").route.name == "param"
    assert r.match("GET", "/users/42/settings").path_params == {"id": "42"}


def test_wildcard_captures_single_segment():
    """Wildcard: captures single remaining segment"""
    r = Router()
    r.add("GET", "/files/{path:rest}", h("files"))
    m = r.match("GET", "/files/readme.txt")
    assert m.path_params == {"path": "readme.txt"}


def test_wildcard_captures_multiple_segments():
    """Wildcard: captures multiple remaining segments with slashes"""
    r = Router()
    r.add("GET", "/files/{path:rest}", h("files"))
    m = r.match("GET", "/files/docs/api/users.md")
    assert m.path_params == {"path": "docs/api/users.md"}


def test_wildcard_static_prefix_honoured():
    """Wildcard: static prefix is honoured before capture begins"""
    r = Router()
    r.add("GET", "/static/{path:rest}", h("static"))
    m = r.match("GET", "/static/css/main.css")
    assert m.path_params["path"] == "css/main.css"


def test_wildcard_static_beats_wildcard():
    """Wildcard: static beats wildcard at same prefix"""
    r = Router()
    r.add("GET", "/files/{path:rest}", h("wildcard"), name="wildcard")
    r.add("GET", "/files/README.md", h("readme"), name="static")
    assert r.match("GET", "/files/README.md").route.name == "static"
    assert r.match("GET", "/files/other.txt").route.name == "wildcard"
    assert r.match("GET", "/files/a/b/c").path_params["path"] == "a/b/c"


def test_wildcard_param_beats_wildcard():
    """Wildcard: param beats wildcard at same level"""
    r = Router()
    r.add("GET", "/things/{path:rest}", h("wildcard"), name="wildcard")
    r.add("GET", "/things/{id}", h("item"), name="param")
    assert r.match("GET", "/things/42").route.name == "param"
    assert r.match("GET", "/things/a/b").route.name == "wildcard"


def test_method_same_path_multiple_methods():
    """Method: same path, multiple methods all resolve"""
    r = Router()
    r.add("GET", "/users", h("list"), name="list")
    r.add("POST", "/users", h("create"), name="create")
    r.add("DELETE", "/users", h("clear"), name="clear")

    assert r.match("GET", "/users").route.name == "list"
    assert r.match("POST", "/users").route.name == "create"
    assert r.match("DELETE", "/users").route.name == "clear"


def test_method_405_carries_allowed_methods():
    """Method: 405 carries allowed methods"""
    r = Router()
    r.add("GET", "/users", h("list"))
    r.add("POST", "/users", h("create"))
    with pytest.raises(MethodNotAllowed) as exc_info:
        r.match("PUT", "/users")
    e = exc_info.value
    assert "GET" in e.allowed, f"GET missing from allowed: {e.allowed}"
    assert "POST" in e.allowed, f"POST missing from allowed: {e.allowed}"


def test_method_405_not_404():
    """Method: 405 not 404 — path exists, method doesn't"""
    r = Router()
    r.add("GET", "/users", h("list"))
    with pytest.raises(MethodNotAllowed):
        r.match("PATCH", "/users")


def test_method_case_insensitive():
    """Method: case-insensitive method normalisation"""
    r = Router()
    r.add("GET", "/users", h("list"))
    m = r.match("get", "/users")
    assert m is not None


def test_method_head_no_implicit_fallback():
    """Method: HEAD raises MethodNotAllowed if not registered — no implicit fallback"""
    r = Router()
    r.add("GET", "/users", h("list"))
    with pytest.raises(MethodNotAllowed) as exc_info:
        r.match("HEAD", "/users")
    e = exc_info.value
    assert "GET" in e.allowed, "Allowed list should still include GET"


def test_404_completely_unregistered_path():
    """404: completely unregistered path"""
    r = Router()
    r.add("GET", "/users", h("users"))
    with pytest.raises(NotFound):
        r.match("GET", "/posts")


def test_404_path_is_prefix_of_registered_route():
    """404: path is prefix of registered route"""
    r = Router()
    r.add("GET", "/users/settings", h("settings"))
    with pytest.raises(NotFound):
        r.match("GET", "/users")


def test_404_path_extends_beyond_registered_route():
    """404: path extends beyond registered route"""
    r = Router()
    r.add("GET", "/users", h("users"))
    with pytest.raises(NotFound):
        r.match("GET", "/users/extra")


def test_404_param_route_does_not_match_two_segment_value():
    """404: param route does not match two-segment value"""
    r = Router()
    r.add("GET", "/users/{id}", h("user"))
    with pytest.raises(NotFound):
        r.match("GET", "/users/42/extra")


def test_404_empty_router():
    """404: empty router returns NotFound for everything"""
    r = Router()
    with pytest.raises(NotFound):
        r.match("GET", "/")


def test_config_exact_duplicate_path_and_method_raises():
    """ConfigError: exact duplicate path + method raises"""
    r = Router()
    r.add("GET", "/users", h("first"))
    with pytest.raises(ConfigurationError):
        r.add("GET", "/users", h("second"))


def test_config_same_path_different_methods_do_not_conflict():
    """ConfigError: same path different methods do NOT conflict"""
    r = Router()
    r.add("GET", "/users", h("list"))
    r.add("POST", "/users", h("create"))


def test_config_duplicate_param_route_raises_same_method():
    """ConfigError: duplicate param route raises — same method"""
    r = Router()
    r.add("GET", "/users/{id}", h("by_id"))
    with pytest.raises(ConfigurationError):
        r.add("GET", "/users/{name}", h("by_name"))


def test_config_duplicate_param_route_raises_different_methods():
    """ConfigError: duplicate param route raises — DIFFERENT methods"""
    r = Router()
    r.add("GET", "/users/{id}", h("by_id"))
    with pytest.raises(ConfigurationError):
        r.add("POST", "/users/{name}", h("by_name"))


def test_config_silent_param_name_merge_corrupts_match():
    """ConfigError: conflicting param names now caught during registration"""
    r = Router()
    r.add("GET", "/users/{id}", h("by_id"))
    with pytest.raises(ConfigurationError):
        r.add("POST", "/users/{name}", h("by_name"))


def test_normalisation_trailing_slash_on_registration_matches_without():
    """Normalisation: trailing slash on registration matches without"""
    r = Router()
    r.add("GET", "/users/", h("users"))
    try:
        m = r.match("GET", "/users")
        assert m is not None
    except NotFound:
        pass


def test_normalisation_trailing_slash_on_match_normalised():
    """Normalisation: trailing slash on match normalised"""
    r = Router()
    r.add("GET", "/users", h("users"))
    try:
        m = r.match("GET", "/users/")
        assert m is not None
    except NotFound:
        pass


def test_normalisation_double_slashes_collapsed_or_rejected():
    """Normalisation: double slashes are collapsed or rejected"""
    r = Router()
    r.add("GET", "/users/{id}", h("user"))
    try:
        m = r.match("GET", "/users//42")
        if m.path_params.get("id") == "":
            raise AssertionError("Empty string matched as param — should not happen")
    except NotFound:
        pass


def test_regex_constraint_matches_pattern():
    """Regex: constraint matches only values that satisfy the pattern"""
    r = Router()
    r.add("GET", "/users/{id:[0-9]+}", h("user_by_id"))
    m = r.match("GET", "/users/42")
    assert m.path_params == {"id": "42"}


def test_regex_constraint_rejects_non_matching():
    """Regex: constraint rejects values that don't match the pattern"""
    r = Router()
    r.add("GET", "/users/{id:[0-9]+}", h("user_by_id"))
    with pytest.raises(NotFound):
        r.match("GET", "/users/abc")


def test_regex_constraint_fallback_to_other_route():
    """Regex: non-matching values fall through to wildcard"""
    r = Router()
    r.add("GET", "/users/{id:[0-9]+}", h("by_id"), name="by_id")
    r.add("GET", "/users/{path:rest}", h("fallback"), name="fallback")

    m = r.match("GET", "/users/42")
    assert m.route.name == "by_id"
    assert m.path_params == {"id": "42"}

    m = r.match("GET", "/users/john")
    assert m.route.name == "fallback"
    assert m.path_params == {"path": "john"}


def test_regex_constraint_complex_pattern():
    """Regex: supports complex regex patterns"""
    r = Router()
    r.add("GET", "/files/{name:[a-zA-Z0-9._-]+}", h("file"))
    m = r.match("GET", "/files/my-document_v2.pdf")
    assert m.path_params == {"name": "my-document_v2.pdf"}

    with pytest.raises(NotFound):
        r.match("GET", "/files/invalid@name.txt")


def test_regex_constraint_with_static_sibling():
    """Regex: static routes still beat constrained params"""
    r = Router()
    r.add("GET", "/users/admin", h("admin"), name="admin")
    r.add("GET", "/users/{id:[0-9]+}", h("user_by_id"), name="by_id")

    assert r.match("GET", "/users/admin").route.name == "admin"
    assert r.match("GET", "/users/123").route.name == "by_id"


def test_regex_constraint_invalid_pattern_raises():
    """Regex: invalid regex pattern raises error during registration"""
    r = Router()
    with pytest.raises(ValueError) as exc_info:
        r.add("GET", "/users/{id:[0-9+}", h("user"))
    assert "Invalid regex pattern" in str(exc_info.value)


def test_regex_constraint_conflicting_patterns_raises():
    """Regex: conflicting constraints at same level raises error"""
    r = Router()
    r.add("GET", "/items/{id:[0-9]+}", h("item_by_id"))
    with pytest.raises(ConfigurationError):
        r.add("POST", "/items/{id:[a-z]+}", h("item_by_slug"))


def test_real_world_full_rest_route_table_resolves_correctly():
    """Real-world: full REST route table resolves correctly"""
    r = Router()

    r.add("GET", "/users", h("list_users"), name="list_users")
    r.add("POST", "/users", h("create_user"), name="create_user")
    r.add("GET", "/users/me", h("get_me"), name="get_me")
    r.add("GET", "/users/{id}", h("get_user"), name="get_user")
    r.add("PUT", "/users/{id}", h("update_user"), name="update_user")
    r.add("DELETE", "/users/{id}", h("delete_user"), name="delete_user")
    r.add("GET", "/users/{id}/posts", h("user_posts"), name="user_posts")
    r.add("GET", "/users/{id}/avatar", h("user_avatar"), name="user_avatar")

    r.add("GET", "/posts", h("list_posts"), name="list_posts")
    r.add("POST", "/posts", h("create_post"), name="create_post")
    r.add("GET", "/posts/{id}", h("get_post"), name="get_post")
    r.add("PATCH", "/posts/{id}", h("patch_post"), name="patch_post")

    r.add("GET", "/orgs/{org}/repos", h("list_repos"), name="list_repos")
    r.add("GET", "/orgs/{org}/repos/{repo}", h("get_repo"), name="get_repo")
    r.add(
        "GET",
        "/orgs/{org}/repos/{repo}/issues/{issue}",
        h("get_issue"),
        name="get_issue",
    )

    r.add("GET", "/static/{path:rest}", h("static"), name="static")

    assert r.match("GET", "/users").route.name == "list_users"
    assert r.match("POST", "/users").route.name == "create_user"

    assert r.match("GET", "/users/me").route.name == "get_me"

    m = r.match("GET", "/users/42")
    assert m.route.name == "get_user"
    assert m.path_params == {"id": "42"}

    assert r.match("PUT", "/users/42").route.name == "update_user"
    assert r.match("DELETE", "/users/42").route.name == "delete_user"

    m = r.match("GET", "/users/42/posts")
    assert m.route.name == "user_posts"
    assert m.path_params == {"id": "42"}

    assert r.match("GET", "/posts").route.name == "list_posts"
    assert r.match("POST", "/posts").route.name == "create_post"
    assert r.match("PATCH", "/posts/7").route.name == "patch_post"

    m = r.match("GET", "/orgs/anthropic/repos/meridian")
    assert m.route.name == "get_repo"
    assert m.path_params == {"org": "anthropic", "repo": "meridian"}

    m = r.match("GET", "/orgs/anthropic/repos/meridian/issues/99")
    assert m.route.name == "get_issue"
    assert m.path_params == {"org": "anthropic", "repo": "meridian", "issue": "99"}

    m = r.match("GET", "/static/css/main.css")
    assert m.route.name == "static"
    assert m.path_params["path"] == "css/main.css"

    with pytest.raises(MethodNotAllowed):
        r.match("DELETE", "/users/me")

    with pytest.raises(NotFound):
        r.match("GET", "/unknown")
