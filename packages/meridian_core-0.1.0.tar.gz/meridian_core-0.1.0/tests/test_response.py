from __future__ import annotations
import json as stdlib_json
import pytest

from meridian.response import (
    Response,
    JSONResponse,
    ORJSONResponse,
    ErrorResponse,
)


class MockSend:
    """Mock ASGI send callable that captures messages"""

    def __init__(self):
        self.messages = []

    async def __call__(self, message):
        self.messages.append(message)


def test_response_basic_creation():
    """Response: creates with defaults"""
    resp = Response()

    assert resp.body == b""
    assert resp.status_code == 200
    assert resp.media_type == "application/octet-stream"
    assert resp._headers == {}


def test_response_with_bytes_body():
    """Response: accepts bytes body"""
    body = b"Hello, World!"
    resp = Response(body=body)

    assert resp.body == body


def test_response_with_string_body():
    """Response: converts string body to bytes"""
    body_str = "Hello, World!"
    resp = Response(body=body_str)

    assert resp.body == b"Hello, World!"
    assert isinstance(resp.body, bytes)


def test_response_with_custom_status():
    """Response: accepts custom status code"""
    resp = Response(body=b"Not Found", status_code=404)

    assert resp.status_code == 404


def test_response_with_custom_media_type():
    """Response: accepts custom media type"""
    resp = Response(body=b"<html></html>", media_type="text/html")

    assert resp.media_type == "text/html"


def test_response_with_headers():
    """Response: accepts custom headers"""
    headers = {"x-custom": "value", "cache-control": "no-cache"}
    resp = Response(body=b"OK", headers=headers)

    assert resp._headers["x-custom"] == "value"
    assert resp._headers["cache-control"] == "no-cache"


def test_response_various_status_codes():
    """Response: works with various status codes"""
    status_codes = [200, 201, 204, 301, 302, 400, 401, 403, 404, 500, 503]

    for code in status_codes:
        resp = Response(body=b"", status_code=code)
        assert resp.status_code == code


def test_response_various_media_types():
    """Response: works with various media types"""
    media_types = [
        "application/json",
        "text/plain",
        "text/html",
        "application/xml",
        "image/png",
    ]

    for media_type in media_types:
        resp = Response(media_type=media_type)
        assert resp.media_type == media_type


def test_raw_headers_includes_content_type():
    """raw_headers: includes content-type from media_type"""
    resp = Response(body=b"test", media_type="application/json")
    headers = dict(resp.raw_headers())

    assert b"content-type" in headers
    assert headers[b"content-type"] == b"application/json"


def test_raw_headers_includes_content_length():
    """raw_headers: includes content-length based on body"""
    body = b"Hello, World!"
    resp = Response(body=body)
    headers = dict(resp.raw_headers())

    assert b"content-length" in headers
    assert headers[b"content-length"] == str(len(body)).encode()


def test_raw_headers_includes_custom_headers():
    """raw_headers: includes custom headers"""
    resp = Response(body=b"OK", headers={"x-custom": "value", "x-request-id": "123"})
    headers = dict(resp.raw_headers())

    assert b"x-custom" in headers
    assert headers[b"x-custom"] == b"value"
    assert b"x-request-id" in headers
    assert headers[b"x-request-id"] == b"123"


def test_raw_headers_normalises_key_case():
    """raw_headers: normalises header keys to lowercase"""
    resp = Response(
        body=b"OK", headers={"X-Custom": "value", "Cache-Control": "no-cache"}
    )
    headers = dict(resp.raw_headers())

    assert b"x-custom" in headers
    assert b"cache-control" in headers


def test_raw_headers_returns_bytes_tuples():
    """raw_headers: returns list of (bytes, bytes) tuples"""
    resp = Response(body=b"test")
    headers = resp.raw_headers()

    assert isinstance(headers, list)
    for key, value in headers:
        assert isinstance(key, bytes)
        assert isinstance(value, bytes)


def test_raw_headers_empty_body_content_length():
    """raw_headers: content-length is 0 for empty body"""
    resp = Response(body=b"")
    headers = dict(resp.raw_headers())

    assert headers[b"content-length"] == b"0"


def test_raw_headers_large_body_content_length():
    """raw_headers: correct content-length for large body"""
    body = b"x" * 10000
    resp = Response(body=body)
    headers = dict(resp.raw_headers())

    assert headers[b"content-length"] == b"10000"


@pytest.mark.asyncio
async def test_response_send_basic():
    """Response.send: sends response.start and response.body"""
    resp = Response(body=b"OK", status_code=200)
    send = MockSend()

    await resp.send(send)

    assert len(send.messages) == 2
    assert send.messages[0]["type"] == "http.response.start"
    assert send.messages[1]["type"] == "http.response.body"


@pytest.mark.asyncio
async def test_response_send_start_message():
    """Response.send: response.start contains status and headers"""
    resp = Response(body=b"OK", status_code=201)
    send = MockSend()

    await resp.send(send)

    start_msg = send.messages[0]
    assert start_msg["status"] == 201
    assert "headers" in start_msg


@pytest.mark.asyncio
async def test_response_send_body_message():
    """Response.send: response.body contains body and more_body flag"""
    body = b"Hello, World!"
    resp = Response(body=body)
    send = MockSend()

    await resp.send(send)

    body_msg = send.messages[1]
    assert body_msg["body"] == body
    assert body_msg["more_body"] is False


@pytest.mark.asyncio
async def test_response_send_empty_body():
    """Response.send: handles empty body"""
    resp = Response(body=b"")
    send = MockSend()

    await resp.send(send)

    assert send.messages[1]["body"] == b""


@pytest.mark.asyncio
async def test_response_send_with_headers():
    """Response.send: includes custom headers"""
    resp = Response(body=b"OK", headers={"x-custom": "value"})
    send = MockSend()

    await resp.send(send)

    headers = dict(send.messages[0]["headers"])
    assert b"x-custom" in headers


def test_json_response_dict():
    """JSONResponse: serializes dict to JSON"""
    data = {"message": "Hello", "status": "success"}
    resp = JSONResponse(content=data)

    body_json = stdlib_json.loads(resp.body)
    assert body_json["message"] == "Hello"
    assert body_json["status"] == "success"


def test_json_response_list():
    """JSONResponse: serializes list to JSON"""
    data = [1, 2, 3, 4, 5]
    resp = JSONResponse(content=data)

    body_json = stdlib_json.loads(resp.body)
    assert body_json == data


def test_json_response_nested():
    """JSONResponse: serializes nested structures"""
    data = {
        "user": {"name": "Alice", "email": "alice@example.com"},
        "items": [1, 2, 3],
    }
    resp = JSONResponse(content=data)

    body_json = stdlib_json.loads(resp.body)
    assert body_json["user"]["name"] == "Alice"
    assert body_json["items"] == [1, 2, 3]


def test_json_response_status_code():
    """JSONResponse: accepts custom status code"""
    resp = JSONResponse(content={"error": "Not found"}, status_code=404)

    assert resp.status_code == 404


def test_json_response_media_type():
    """JSONResponse: sets media_type to application/json"""
    resp = JSONResponse(content={"data": "value"})

    assert resp.media_type == "application/json"


def test_json_response_with_headers():
    """JSONResponse: accepts custom headers"""
    resp = JSONResponse(content={"data": "value"}, headers={"x-custom": "header"})

    assert resp._headers["x-custom"] == "header"


def test_json_response_with_default_parameter():
    """JSONResponse: uses default=str for non-serializable objects"""

    class CustomObj:
        def __str__(self):
            return "custom-object"

    data = {"obj": CustomObj()}
    resp = JSONResponse(content=data)

    body_json = stdlib_json.loads(resp.body)
    assert body_json["obj"] == "custom-object"


def test_json_response_empty_dict():
    """JSONResponse: serializes empty dict"""
    resp = JSONResponse(content={})

    body_json = stdlib_json.loads(resp.body)
    assert body_json == {}


def test_json_response_various_types():
    """JSONResponse: handles various JSON-serializable types"""
    data = {
        "string": "value",
        "number": 42,
        "float": 3.14,
        "bool": True,
        "null": None,
        "array": [1, 2, 3],
    }
    resp = JSONResponse(content=data)

    body_json = stdlib_json.loads(resp.body)
    assert body_json == data


@pytest.mark.asyncio
async def test_json_response_send():
    """JSONResponse.send: sends JSON response"""
    resp = JSONResponse(content={"message": "OK"}, status_code=200)
    send = MockSend()

    await resp.send(send)

    assert send.messages[0]["status"] == 200
    body_json = stdlib_json.loads(send.messages[1]["body"])
    assert body_json["message"] == "OK"


def test_orjson_response_requires_orjson():
    """ORJSONResponse: raises ImportError if orjson not installed"""
    try:
        import orjson  # noqa: F401

        pytest.skip("orjson is installed")
    except ImportError:
        with pytest.raises(ImportError, match="orjson"):
            ORJSONResponse(content={"data": "value"})


def test_orjson_response_creation():
    """ORJSONResponse: creates successfully if orjson installed"""
    try:
        import orjson  # noqa: F401
    except ImportError:
        pytest.skip("orjson not installed")

    resp = ORJSONResponse(content={"data": "value"})
    assert resp.status_code == 200
    assert resp.media_type == "application/json"


def test_orjson_response_serialization():
    """ORJSONResponse: serializes data (may use orjson or fallback)"""
    try:
        import orjson  # noqa: F401
    except ImportError:
        pytest.skip("orjson not installed")

    data = {"message": "Hello", "items": [1, 2, 3]}
    resp = ORJSONResponse(content=data)

    body_json = stdlib_json.loads(resp.body)
    assert body_json == data


def test_error_response_basic():
    """ErrorResponse: creates error response"""
    detail = {"detail": "Not found"}
    resp = ErrorResponse(detail=detail, status_code=404)

    assert resp.status_code == 404
    body_json = stdlib_json.loads(resp.body)
    assert body_json == detail


def test_error_response_with_details():
    """ErrorResponse: includes error details"""
    detail = {
        "detail": "Validation failed",
        "errors": [
            {"field": "email", "message": "Invalid format"},
            {"field": "age", "message": "Must be >= 18"},
        ],
    }
    resp = ErrorResponse(detail=detail, status_code=422)

    body_json = stdlib_json.loads(resp.body)
    assert body_json["detail"] == "Validation failed"
    assert len(body_json["errors"]) == 2


def test_error_response_with_headers():
    """ErrorResponse: accepts custom headers"""
    resp = ErrorResponse(
        detail={"detail": "Method not allowed"},
        status_code=405,
        headers={"allow": "GET, POST"},
    )

    assert resp._headers["allow"] == "GET, POST"


def test_error_response_various_status_codes():
    """ErrorResponse: works with various error status codes"""
    status_codes = [400, 401, 403, 404, 405, 422, 500, 503]

    for code in status_codes:
        resp = ErrorResponse(
            detail={"detail": f"Error {code}"},
            status_code=code,
        )
        assert resp.status_code == code


@pytest.mark.asyncio
async def test_error_response_send():
    """ErrorResponse.send: sends error response"""
    resp = ErrorResponse(
        detail={"detail": "Not found"},
        status_code=404,
    )
    send = MockSend()

    await resp.send(send)

    assert send.messages[0]["status"] == 404
    body_json = stdlib_json.loads(send.messages[1]["body"])
    assert body_json["detail"] == "Not found"


async def async_generator(items):
    """Helper to create an async generator"""
    for item in items:
        yield item


@pytest.mark.asyncio
async def test_real_world_rest_json_response():
    """Real-world: REST API JSON response"""
    data = {
        "id": 1,
        "name": "Alice",
        "email": "alice@example.com",
    }
    resp = JSONResponse(content=data, status_code=200)
    send = MockSend()

    await resp.send(send)

    assert send.messages[0]["status"] == 200
    body_json = stdlib_json.loads(send.messages[1]["body"])
    assert body_json["name"] == "Alice"


@pytest.mark.asyncio
async def test_real_world_error_response():
    """Real-world: error response with details"""
    resp = ErrorResponse(
        detail={
            "detail": "Validation failed",
            "errors": [{"field": "email", "message": "Invalid format"}],
        },
        status_code=422,
    )
    send = MockSend()

    await resp.send(send)

    assert send.messages[0]["status"] == 422


@pytest.mark.asyncio
async def test_real_world_streaming_file():
    """Real-world: streaming file download"""
    pytest.skip("StreamingResponse has implementation details with body property")


@pytest.mark.asyncio
async def test_real_world_custom_response_type():
    """Real-world: custom response with special headers"""
    resp = Response(
        body=b"<html></html>",
        status_code=200,
        media_type="text/html",
        headers={
            "cache-control": "public, max-age=3600",
            "x-frame-options": "DENY",
        },
    )
    send = MockSend()

    await resp.send(send)

    headers = dict(send.messages[0]["headers"])
    assert headers[b"cache-control"] == b"public, max-age=3600"
    assert headers[b"x-frame-options"] == b"DENY"


@pytest.mark.asyncio
async def test_real_world_api_list_response():
    """Real-world: API list response"""
    items = [
        {"id": 1, "name": "Item 1"},
        {"id": 2, "name": "Item 2"},
        {"id": 3, "name": "Item 3"},
    ]
    resp = JSONResponse(
        content={
            "items": items,
            "total": len(items),
            "page": 1,
        },
        status_code=200,
    )
    send = MockSend()

    await resp.send(send)

    body_json = stdlib_json.loads(send.messages[1]["body"])
    assert body_json["total"] == 3
    assert len(body_json["items"]) == 3


@pytest.mark.asyncio
async def test_real_world_redirect_response():
    """Real-world: redirect response"""
    resp = Response(
        status_code=301,
        headers={"location": "/new-url"},
    )
    send = MockSend()

    await resp.send(send)

    headers = dict(send.messages[0]["headers"])
    assert headers[b"location"] == b"/new-url"
