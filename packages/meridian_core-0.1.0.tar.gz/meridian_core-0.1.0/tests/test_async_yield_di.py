from __future__ import annotations
import pytest
from typing import AsyncGenerator
from meridian.di import Container, REQUEST, SINGLETON
from meridian.extractors import Inject


class Database:
    def __init__(self):
        self.closed = False

    async def close(self):
        self.closed = True


class Session:
    def __init__(self, db: Database):
        self.db = db
        self.closed = False

    async def close(self):
        self.closed = True


@pytest.mark.asyncio
async def test_request_scoped_async_yield():
    container = Container()
    container.register(Database, scope=SINGLETON)

    @container.provider(scope=REQUEST)
    async def get_session(db: Inject[Database]) -> AsyncGenerator[Session, None]:
        session = Session(db)
        try:
            yield session
        finally:
            await session.close()

    container.build()

    scope = container.request_scope()
    db = await scope.resolve(Database)
    session = await scope.resolve(Session)

    assert session.db is db
    assert not session.closed

    await scope.teardown()
    assert session.closed


@pytest.mark.asyncio
async def test_singleton_async_yield():
    container = Container()

    @container.provider(scope=SINGLETON)
    async def get_db() -> AsyncGenerator[Database, None]:
        db = Database()
        try:
            yield db
        finally:
            await db.close()

    container.build()

    scope = container.request_scope()
    db = await scope.resolve(Database)
    assert not db.closed

    await scope.teardown()
    assert not db.closed

    await container.shutdown()
    assert db.closed


@pytest.mark.asyncio
async def test_provider_no_type_inference_from_annotation():
    container = Container()

    @container.provider()
    async def get_something() -> str:
        return "val"

    container.build()
    scope = container.request_scope()
    assert await scope.resolve(str) == "val"
