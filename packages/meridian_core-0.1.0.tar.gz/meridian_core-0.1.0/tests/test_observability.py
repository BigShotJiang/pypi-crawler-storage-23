from __future__ import annotations

import pytest
from typing import Any

from meridian import Meridian
from meridian.observability.backends import ObservabilityBackend
from meridian.testing import AsyncTestClient


class MockSpan:
    """Mock Span object for testing."""

    def __init__(self, trace_id: str, span_id: str, name: str):
        self.trace_id = trace_id
        self.span_id = span_id
        self.name = name
        self.status = "unknown"
        self.error = None


class MockObservabilityBackend(ObservabilityBackend):
    """Mock observability backend for testing."""

    def __init__(self):
        self.spans_started: list[MockSpan] = []
        self.spans_ended: list[MockSpan] = []
        self.spans_errored: list[tuple[MockSpan, Exception]] = []

    async def on_span_start(self, span: MockSpan) -> None:
        """Record span start."""
        self.spans_started.append(span)

    async def on_span_end(self, span: MockSpan) -> None:
        """Record span end."""
        self.spans_ended.append(span)

    async def on_span_error(self, span: MockSpan, error: Exception) -> None:
        """Record span error."""
        self.spans_errored.append((span, error))

    def clear(self) -> None:
        """Clear all recorded spans."""
        self.spans_started.clear()
        self.spans_ended.clear()
        self.spans_errored.clear()


class TestObservabilityBackendProtocol:
    """Test the ObservabilityBackend protocol and interface."""

    def test_backend_implements_protocol(self):
        """Test that MockObservabilityBackend implements the protocol."""
        backend = MockObservabilityBackend()
        assert isinstance(backend, ObservabilityBackend)

    def test_backend_has_required_methods(self):
        """Test that backend has all required async methods."""
        backend = MockObservabilityBackend()
        assert hasattr(backend, "on_span_start")
        assert hasattr(backend, "on_span_end")
        assert hasattr(backend, "on_span_error")

    @pytest.mark.asyncio
    async def test_on_span_start_is_awaitable(self):
        """Test that on_span_start is awaitable."""
        backend = MockObservabilityBackend()
        span = MockSpan("trace-123", "span-456", "test.request")

        await backend.on_span_start(span)
        assert span in backend.spans_started

    @pytest.mark.asyncio
    async def test_on_span_end_is_awaitable(self):
        """Test that on_span_end is awaitable."""
        backend = MockObservabilityBackend()
        span = MockSpan("trace-123", "span-456", "test.request")

        await backend.on_span_end(span)
        assert span in backend.spans_ended

    @pytest.mark.asyncio
    async def test_on_span_error_is_awaitable(self):
        """Test that on_span_error is awaitable."""
        backend = MockObservabilityBackend()
        span = MockSpan("trace-123", "span-456", "test.request")
        error = ValueError("test error")

        await backend.on_span_error(span, error)
        assert (span, error) in backend.spans_errored


class TestBackendRegistration:
    """Test registering observability backends with the app."""

    def test_app_accepts_observability_config(self):
        """Test that Meridian app can be created with observability config."""
        app = Meridian()
        assert hasattr(app, "with_observability")

    def test_multiple_backends_can_be_configured(self):
        """Test that multiple backends can be registered."""
        backend1 = MockObservabilityBackend()
        backend2 = MockObservabilityBackend()

        assert backend1 is not backend2
        assert backend1.spans_started == []
        assert backend2.spans_started == []


class TestSpanLifecycle:
    """Test the span lifecycle (start → end/error)."""

    @pytest.mark.asyncio
    async def test_span_lifecycle_on_success(self):
        """Test span lifecycle for successful request."""
        backend = MockObservabilityBackend()
        span = MockSpan("trace-123", "span-456", "test.request")

        await backend.on_span_start(span)
        assert len(backend.spans_started) == 1

        await backend.on_span_end(span)
        assert len(backend.spans_ended) == 1
        assert len(backend.spans_errored) == 0

    @pytest.mark.asyncio
    async def test_span_lifecycle_on_error(self):
        """Test span lifecycle for failed request."""
        backend = MockObservabilityBackend()
        span = MockSpan("trace-123", "span-456", "test.request")
        error = RuntimeError("handler failed")

        await backend.on_span_start(span)
        assert len(backend.spans_started) == 1

        await backend.on_span_error(span, error)
        assert len(backend.spans_errored) == 1
        assert backend.spans_errored[0] == (span, error)

    @pytest.mark.asyncio
    async def test_span_can_have_multiple_backends(self):
        """Test that a span is reported to all backends."""
        backend1 = MockObservabilityBackend()
        backend2 = MockObservabilityBackend()

        span = MockSpan("trace-123", "span-456", "test.request")

        await backend1.on_span_start(span)
        await backend2.on_span_start(span)

        assert span in backend1.spans_started
        assert span in backend2.spans_started


class TestBackendErrorHandling:
    """Test that backend errors don't break the request."""

    class FailingBackend(ObservabilityBackend):
        """Backend that raises errors."""

        def __init__(self, fail_on: str = "start"):
            self.fail_on = fail_on

        async def on_span_start(self, span: Any) -> None:
            if self.fail_on == "start":
                raise RuntimeError("backend start failed")

        async def on_span_end(self, span: Any) -> None:
            if self.fail_on == "end":
                raise RuntimeError("backend end failed")

        async def on_span_error(self, span: Any, error: Exception) -> None:
            if self.fail_on == "error":
                raise RuntimeError("backend error handler failed")

    @pytest.mark.asyncio
    async def test_backend_start_error_doesnt_crash_request(self):
        """Test that a failing on_span_start doesn't crash the request."""
        backend = self.FailingBackend(fail_on="start")
        span = MockSpan("trace-123", "span-456", "test.request")

        try:
            await backend.on_span_start(span)
        except RuntimeError as e:
            assert str(e) == "backend start failed"

    @pytest.mark.asyncio
    async def test_backend_end_error_doesnt_crash_response(self):
        """Test that a failing on_span_end doesn't crash the response."""
        backend = self.FailingBackend(fail_on="end")
        span = MockSpan("trace-123", "span-456", "test.request")

        try:
            await backend.on_span_end(span)
        except RuntimeError as e:
            assert str(e) == "backend end failed"

    @pytest.mark.asyncio
    async def test_backend_error_handler_error_is_handled(self):
        """Test that error in error handler is handled gracefully."""
        backend = self.FailingBackend(fail_on="error")
        span = MockSpan("trace-123", "span-456", "test.request")
        error = ValueError("original error")

        try:
            await backend.on_span_error(span, error)
        except RuntimeError as e:
            assert str(e) == "backend error handler failed"


class TestSpanMetadata:
    """Test span properties and metadata."""

    def test_span_has_trace_id(self):
        """Test that spans have trace IDs."""
        span = MockSpan("trace-abc123", "span-def456", "request")
        assert span.trace_id == "trace-abc123"

    def test_span_has_span_id(self):
        """Test that spans have their own IDs."""
        span = MockSpan("trace-123", "span-456", "request")
        assert span.span_id == "span-456"

    def test_span_has_operation_name(self):
        """Test that spans have operation names."""
        span = MockSpan("trace-123", "span-456", "GET /users/{id}")
        assert span.name == "GET /users/{id}"

    def test_span_has_status(self):
        """Test that spans track status."""
        span = MockSpan("trace-123", "span-456", "request")
        assert hasattr(span, "status")
        span.status = "success"
        assert span.status == "success"

    def test_span_can_record_error(self):
        """Test that spans can record errors."""
        span = MockSpan("trace-123", "span-456", "request")
        error = ValueError("test error")
        span.error = error
        assert span.error is error


class TestDistributedTracing:
    """Test distributed tracing across requests."""

    def test_traces_share_trace_id(self):
        """Test that spans in the same trace share a trace ID."""
        trace_id = "trace-distributed-123"

        span1 = MockSpan(trace_id, "span-1", "service-a")
        span2 = MockSpan(trace_id, "span-2", "service-b")

        assert span1.trace_id == span2.trace_id

    def test_spans_have_unique_ids(self):
        """Test that different spans have different IDs."""
        trace_id = "trace-123"
        span1 = MockSpan(trace_id, "span-1", "op1")
        span2 = MockSpan(trace_id, "span-2", "op2")

        assert span1.span_id != span2.span_id
        assert span1.trace_id == span2.trace_id


class TestObservabilityIntegration:
    """Test observability integration with the app and gateway."""

    @pytest.mark.asyncio
    async def test_backend_receives_request_span(self):
        """Test that a backend receives a span for each request."""
        backend = MockObservabilityBackend()

        async def handler(request):
            from meridian.response import Response

            return Response(b"OK", 200)

        span = MockSpan("trace-req-1", "span-req-1", "GET /test")
        await backend.on_span_start(span)
        await backend.on_span_end(span)

        assert len(backend.spans_started) == 1
        assert len(backend.spans_ended) == 1

    @pytest.mark.asyncio
    async def test_backend_is_notified_of_request_errors(self):
        """Test that backend is notified when handler raises an error."""
        backend = MockObservabilityBackend()
        span = MockSpan("trace-err-1", "span-err-1", "GET /error")
        error = ValueError("handler error")

        await backend.on_span_start(span)
        await backend.on_span_error(span, error)

        assert len(backend.spans_started) == 1
        assert len(backend.spans_errored) == 1
        assert backend.spans_errored[0][1] is error

    def test_observability_disabled_by_default(self):
        """Test that observability doesn't break app when not configured."""
        app = Meridian(debug=False)
        assert app is not None


class TestObservabilityWithRealRequests:
    """Test observability with actual HTTP requests."""

    @pytest.mark.asyncio
    async def test_simple_request_without_observability(self):
        """Test that requests work without observability enabled."""
        app = Meridian()

        @app.get("/test")
        async def handler() -> dict:
            return {"message": "hello"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/test")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_error_request_without_observability(self):
        """Test that error requests work without observability."""
        from meridian.exceptions import BadRequest

        app = Meridian()

        @app.get("/error")
        async def handler():
            raise BadRequest("test error")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400


class TestSlowRequestDetection:
    """Test that slow requests are reported to observability backends."""

    class SlowRequestBackend(ObservabilityBackend):
        """Backend that tracks slow requests."""

        def __init__(self, slow_threshold_ms: int = 100):
            self.slow_threshold_ms = slow_threshold_ms
            self.slow_requests: list[MockSpan] = []

        async def on_span_end(self, span: MockSpan) -> None:
            if hasattr(span, "duration_ms"):
                if span.duration_ms > self.slow_threshold_ms:
                    self.slow_requests.append(span)

    @pytest.mark.asyncio
    async def test_slow_request_is_detected(self):
        """Test that slow requests are flagged."""
        backend = self.SlowRequestBackend(slow_threshold_ms=50)
        span = MockSpan("trace-slow", "span-slow", "GET /slow")
        span.duration_ms = 150

        await backend.on_span_end(span)
        assert span in backend.slow_requests

    @pytest.mark.asyncio
    async def test_fast_request_is_not_flagged(self):
        """Test that fast requests are not flagged as slow."""
        backend = self.SlowRequestBackend(slow_threshold_ms=100)
        span = MockSpan("trace-fast", "span-fast", "GET /fast")
        span.duration_ms = 50

        await backend.on_span_end(span)
        assert span not in backend.slow_requests
