from __future__ import annotations
import json as stdlib_json
import pytest
from meridian.request import Headers, QueryParams, Request


def test_headers_get_single_value():
    """Headers: get() returns single header value"""
    headers = Headers([(b"content-type", b"application/json")])
    assert headers.get("content-type") == "application/json"


def test_headers_get_case_insensitive():
    """Headers: get() is case-insensitive"""
    headers = Headers([(b"content-type", b"application/json")])
    assert headers.get("Content-Type") == "application/json"
    assert headers.get("CONTENT-TYPE") == "application/json"
    assert headers.get("content-TYPE") == "application/json"


def test_headers_get_missing_returns_default():
    """Headers: get() returns default for missing key"""
    headers = Headers([])
    assert headers.get("missing") is None
    assert headers.get("missing", "default") == "default"


def test_headers_get_first_of_multiple_values():
    """Headers: get() returns first value when multiple exist"""
    headers = Headers(
        [
            (b"set-cookie", b"session=abc"),
            (b"set-cookie", b"token=xyz"),
        ]
    )
    value = headers.get("set-cookie")
    assert value == "session=abc"


def test_headers_get_all_returns_all_values():
    """Headers: get_all() returns all values for a key"""
    headers = Headers(
        [
            (b"set-cookie", b"session=abc"),
            (b"set-cookie", b"token=xyz"),
            (b"set-cookie", b"preference=dark"),
        ]
    )
    values = headers.get_all("set-cookie")
    assert values == ["session=abc", "token=xyz", "preference=dark"]


def test_headers_get_all_empty_for_missing_key():
    """Headers: get_all() returns empty list for missing key"""
    headers = Headers([])
    assert headers.get_all("missing") == []


def test_headers_get_all_case_insensitive():
    """Headers: get_all() is case-insensitive"""
    headers = Headers(
        [
            (b"Set-Cookie", b"session=abc"),
            (b"set-cookie", b"token=xyz"),
        ]
    )
    values = headers.get_all("SET-COOKIE")
    assert len(values) == 2
    assert "session=abc" in values
    assert "token=xyz" in values


def test_headers_contains_operator():
    """Headers: __contains__ ('in' operator) works"""
    headers = Headers(
        [
            (b"content-type", b"application/json"),
            (b"authorization", b"Bearer token"),
        ]
    )
    assert "content-type" in headers
    assert "Content-Type" in headers
    assert "authorization" in headers
    assert "missing" not in headers


def test_headers_getitem_returns_value():
    """Headers: __getitem__ ([]) returns value"""
    headers = Headers([(b"content-type", b"application/json")])
    assert headers["content-type"] == "application/json"


def test_headers_getitem_case_insensitive():
    """Headers: __getitem__ is case-insensitive"""
    headers = Headers([(b"content-type", b"application/json")])
    assert headers["Content-Type"] == "application/json"
    assert headers["CONTENT-TYPE"] == "application/json"


def test_headers_getitem_raises_keyerror_for_missing():
    """Headers: __getitem__ raises KeyError for missing key"""
    headers = Headers([])
    with pytest.raises(KeyError):
        _ = headers["missing"]


def test_headers_items_returns_all_pairs():
    """Headers: items() returns all header key-value pairs"""
    raw = [
        (b"content-type", b"application/json"),
        (b"authorization", b"Bearer token"),
        (b"set-cookie", b"session=abc"),
    ]
    headers = Headers(raw)
    items = headers.items()
    assert len(items) == 3
    assert ("content-type", "application/json") in items
    assert ("authorization", "Bearer token") in items
    assert ("set-cookie", "session=abc") in items


def test_headers_items_normalises_keys_to_lowercase():
    """Headers: items() returns keys in lowercase"""
    headers = Headers(
        [
            (b"Content-Type", b"application/json"),
            (b"Authorization", b"Bearer token"),
        ]
    )
    items = headers.items()
    assert ("content-type", "application/json") in items
    assert ("authorization", "Bearer token") in items


def test_headers_empty_headers_list():
    """Headers: empty header list works"""
    headers = Headers([])
    assert headers.get("any") is None
    assert headers.get_all("any") == []
    assert "any" not in headers
    assert headers.items() == []


def test_headers_special_characters_in_value():
    """Headers: handles special characters in header values"""
    headers = Headers(
        [
            (b"user-agent", b"Mozilla/5.0 (X11; Linux x86_64)"),
            (b"accept", b"text/html,application/xhtml+xml;q=0.9"),
        ]
    )
    assert "Mozilla/5.0" in headers.get("user-agent")
    assert "text/html" in headers.get("accept")


def test_headers_unicode_in_values():
    """Headers: handles UTF-8 encoded values"""
    headers = Headers(
        [
            (b"x-custom-name", "José García".encode("utf-8")),
        ]
    )
    assert headers.get("x-custom-name") == "José García"


def test_headers_hyphens_in_key_names():
    """Headers: handles hyphenated header names"""
    headers = Headers(
        [
            (b"x-request-id", b"123-456-789"),
            (b"x-forwarded-for", b"192.168.1.1"),
        ]
    )
    assert headers.get("x-request-id") == "123-456-789"
    assert headers.get("X-Request-ID") == "123-456-789"
    assert headers.get("x-forwarded-for") == "192.168.1.1"


def test_query_params_single_parameter():
    """QueryParams: single parameter parsed correctly"""
    qp = QueryParams(b"key=value")
    assert qp.get("key") == "value"


def test_query_params_multiple_parameters():
    """QueryParams: multiple parameters parsed correctly"""
    qp = QueryParams(b"name=John&age=30&city=NYC")
    assert qp.get("name") == "John"
    assert qp.get("age") == "30"
    assert qp.get("city") == "NYC"


def test_query_params_get_missing_returns_default():
    """QueryParams: get() returns default for missing key"""
    qp = QueryParams(b"key=value")
    assert qp.get("missing") is None
    assert qp.get("missing", "default") == "default"


def test_query_params_get_first_of_multiple_values():
    """QueryParams: get() returns first value when multiple exist"""
    qp = QueryParams(b"tag=python&tag=rust&tag=go")
    assert qp.get("tag") == "python"


def test_query_params_get_all_returns_all_values():
    """QueryParams: get_all() returns all values for a key"""
    qp = QueryParams(b"tag=python&tag=rust&tag=go")
    values = qp.get_all("tag")
    assert values == ["python", "rust", "go"]


def test_query_params_get_all_empty_for_missing_key():
    """QueryParams: get_all() returns empty list for missing key"""
    qp = QueryParams(b"key=value")
    assert qp.get_all("missing") == []


def test_query_params_contains_operator():
    """QueryParams: __contains__ ('in' operator) works"""
    qp = QueryParams(b"name=John&age=30")
    assert "name" in qp
    assert "age" in qp
    assert "missing" not in qp


def test_query_params_empty_query_string():
    """QueryParams: empty query string handled correctly"""
    qp = QueryParams(b"")
    assert qp.get("any") is None
    assert qp.get_all("any") == []
    assert "any" not in qp


def test_query_params_url_encoded_values():
    """QueryParams: URL-encoded values decoded correctly"""
    qp = QueryParams(b"name=John+Doe&email=test%40example.com")
    assert qp.get("name") == "John Doe"
    assert qp.get("email") == "test@example.com"


def test_query_params_special_characters():
    """QueryParams: special characters in values handled correctly"""
    qp = QueryParams(b"search=hello%20world&filter=%21%40%23%24")
    assert qp.get("search") == "hello world"
    assert qp.get("filter") == "!@#$"


def test_query_params_blank_values_preserved():
    """QueryParams: blank values are preserved (keep_blank_values=True)"""
    qp = QueryParams(b"key1=&key2=value&key3=")
    assert qp.get("key1") == ""
    assert qp.get("key2") == "value"
    assert qp.get("key3") == ""
    assert "key1" in qp
    assert "key3" in qp


def test_query_params_key_without_equals():
    """QueryParams: key without '=' is treated as key with empty value"""
    qp = QueryParams(b"key1&key2=value")
    assert "key1" in qp
    assert qp.get("key1") == ""


def test_query_params_ampersand_separated():
    """QueryParams: ampersand-separated parameters parsed correctly"""
    qp = QueryParams(b"a=1&b=2&c=3")
    assert qp.get("a") == "1"
    assert qp.get("b") == "2"
    assert qp.get("c") == "3"


def test_query_params_unicode_values():
    """QueryParams: UTF-8 encoded query parameters decoded correctly"""
    qp = QueryParams("name=José&city=São+Paulo".encode("utf-8"))
    assert qp.get("name") == "José"
    assert qp.get("city") == "São Paulo"


def test_query_params_numeric_string_values():
    """QueryParams: numeric values remain as strings"""
    qp = QueryParams(b"id=123&count=456")
    assert qp.get("id") == "123"
    assert qp.get("count") == "456"
    assert isinstance(qp.get("id"), str)
    assert isinstance(qp.get("count"), str)


def test_query_params_array_like_keys():
    """QueryParams: array-like repeated keys work with get_all()"""
    qp = QueryParams(b"ids=1&ids=2&ids=3&ids=4")
    ids = qp.get_all("ids")
    assert ids == ["1", "2", "3", "4"]


async def mock_receive_empty():
    """Mock receive that returns empty body immediately"""
    return {"type": "http.request", "body": b"", "more_body": False}


def test_request_method_property():
    """Request: method property returns uppercase method"""
    scope = {"type": "http", "method": "get", "path": "/users"}
    request = Request(scope, mock_receive_empty)
    assert request.method == "GET"


def test_request_method_normalised_to_uppercase():
    """Request: method is normalised to uppercase"""
    scope = {"type": "http", "method": "post", "path": "/users"}
    request = Request(scope, mock_receive_empty)
    assert request.method == "POST"


def test_request_path_property():
    """Request: path property returns request path"""
    scope = {"type": "http", "method": "GET", "path": "/users/42"}
    request = Request(scope, mock_receive_empty)
    assert request.path == "/users/42"


def test_request_scope_property():
    """Request: scope property returns raw ASGI scope"""
    scope = {"type": "http", "method": "GET", "path": "/users"}
    request = Request(scope, mock_receive_empty)
    assert request.scope is scope


def test_request_headers_initialised():
    """Request: headers are initialised from scope"""
    scope = {
        "type": "http",
        "method": "GET",
        "path": "/",
        "headers": [(b"content-type", b"application/json")],
    }
    request = Request(scope, mock_receive_empty)
    assert request.headers.get("content-type") == "application/json"


def test_request_headers_empty_when_missing_in_scope():
    """Request: headers default to empty when missing in scope"""
    scope = {"type": "http", "method": "GET", "path": "/"}
    request = Request(scope, mock_receive_empty)
    assert request.headers.get("any") is None


def test_request_query_params_initialised():
    """Request: query_params are initialised from scope"""
    scope = {
        "type": "http",
        "method": "GET",
        "path": "/search",
        "query_string": b"q=python&limit=10",
    }
    request = Request(scope, mock_receive_empty)
    assert request.query_params.get("q") == "python"
    assert request.query_params.get("limit") == "10"


def test_request_query_params_empty_when_missing_in_scope():
    """Request: query_params default to empty when missing in scope"""
    scope = {"type": "http", "method": "GET", "path": "/"}
    request = Request(scope, mock_receive_empty)
    assert request.query_params.get("any") is None


def test_request_path_params_initialised_empty():
    """Request: path_params initialised as empty dict (set by Router later)"""
    scope = {"type": "http", "method": "GET", "path": "/users/42"}
    request = Request(scope, mock_receive_empty)
    assert request.path_params == {}


def test_request_path_params_can_be_set():
    """Request: path_params can be set by Router"""
    scope = {"type": "http", "method": "GET", "path": "/users/42"}
    request = Request(scope, mock_receive_empty)
    request.path_params = {"id": "42"}
    assert request.path_params == {"id": "42"}


def test_request_repr():
    """Request: __repr__ shows method and path"""
    scope = {"type": "http", "method": "GET", "path": "/users/42"}
    request = Request(scope, mock_receive_empty)
    repr_str = repr(request)
    assert "GET" in repr_str
    assert "/users/42" in repr_str


@pytest.mark.asyncio
async def test_request_body_reads_single_chunk():
    """Request.body(): reads single-chunk body"""

    async def receive():
        return {"type": "http.request", "body": b"hello", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)
    body = await request.body()
    assert body == b"hello"


@pytest.mark.asyncio
async def test_request_body_reads_multiple_chunks():
    """Request.body(): reads and concatenates multiple chunks"""
    chunks = [b"hello", b" ", b"world"]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(chunks):
            chunk = chunks[chunk_index]
            more = chunk_index < len(chunks) - 1
            chunk_index += 1
            return {"type": "http.request", "body": chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)
    body = await request.body()
    assert body == b"hello world"


@pytest.mark.asyncio
async def test_request_body_empty_body():
    """Request.body(): handles empty body"""

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "GET", "path": "/"}
    request = Request(scope, receive)
    body = await request.body()
    assert body == b""


@pytest.mark.asyncio
async def test_request_body_caches_result():
    """Request.body(): caches result — multiple calls don't re-read"""
    call_count = 0

    async def receive():
        nonlocal call_count
        call_count += 1
        return {"type": "http.request", "body": b"cached", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    body1 = await request.body()
    body2 = await request.body()
    body3 = await request.body()

    assert body1 == b"cached"
    assert body2 == b"cached"
    assert body3 == b"cached"
    assert call_count == 1, "receive() should only be called once due to caching"


@pytest.mark.asyncio
async def test_request_body_after_stream_returns_empty():
    """Request.body(): returns empty bytes after stream() consumes receive"""

    async def receive():
        return {"type": "http.request", "body": b"data", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    chunks = []
    async for chunk in request.stream():
        chunks.append(chunk)

    body = await request.body()
    assert body == b""


@pytest.mark.asyncio
async def test_request_body_large_payload():
    """Request.body(): handles large multi-chunk payload"""
    chunk_size = 1024
    num_chunks = 100
    chunks = [b"x" * chunk_size for _ in range(num_chunks)]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(chunks):
            chunk = chunks[chunk_index]
            more = chunk_index < len(chunks) - 1
            chunk_index += 1
            return {"type": "http.request", "body": chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/upload"}
    request = Request(scope, receive)
    body = await request.body()

    assert len(body) == chunk_size * num_chunks


@pytest.mark.asyncio
async def test_request_json_parses_valid_json():
    """Request.json(): parses valid JSON body"""
    data = {"name": "John", "age": 30}
    body_bytes = stdlib_json.dumps(data).encode()

    async def receive():
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)
    parsed = await request.json()

    assert parsed == data


@pytest.mark.asyncio
async def test_request_json_nested_structure():
    """Request.json(): parses nested JSON structures"""
    data = {
        "user": {"name": "Alice", "email": "alice@example.com"},
        "items": [1, 2, 3],
        "metadata": {"version": "1.0", "tags": ["a", "b"]},
    }
    body_bytes = stdlib_json.dumps(data).encode()

    async def receive():
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)
    parsed = await request.json()

    assert parsed == data
    assert parsed["user"]["name"] == "Alice"
    assert parsed["items"] == [1, 2, 3]


@pytest.mark.asyncio
async def test_request_json_empty_object():
    """Request.json(): parses empty JSON object"""

    async def receive():
        return {"type": "http.request", "body": b"{}", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)
    parsed = await request.json()

    assert parsed == {}


@pytest.mark.asyncio
async def test_request_json_array():
    """Request.json(): parses JSON array"""
    data = [1, 2, 3, 4, 5]
    body_bytes = stdlib_json.dumps(data).encode()

    async def receive():
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)
    parsed = await request.json()

    assert parsed == data


@pytest.mark.asyncio
async def test_request_json_invalid_raises_error():
    """Request.json(): raises error for invalid JSON"""

    async def receive():
        return {"type": "http.request", "body": b"not json", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    with pytest.raises(stdlib_json.JSONDecodeError):
        await request.json()


@pytest.mark.asyncio
async def test_request_json_uses_body_cache():
    """Request.json(): uses body() caching mechanism"""
    data = {"cached": True}
    body_bytes = stdlib_json.dumps(data).encode()
    call_count = 0

    async def receive():
        nonlocal call_count
        call_count += 1
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    parsed1 = await request.json()
    parsed2 = await request.json()

    assert parsed1 == data
    assert parsed2 == data
    assert call_count == 1, "receive() should only be called once"


@pytest.mark.asyncio
async def test_request_json_and_body_share_cache():
    """Request.json(): json() and body() share the same cache"""
    data = {"shared": "cache"}
    body_bytes = stdlib_json.dumps(data).encode()
    call_count = 0

    async def receive():
        nonlocal call_count
        call_count += 1
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    body = await request.body()
    parsed = await request.json()

    assert body == body_bytes
    assert parsed == data
    assert call_count == 1, "receive() should only be called once"


@pytest.mark.asyncio
async def test_request_stream_single_chunk():
    """Request.stream(): yields single chunk"""

    async def receive():
        return {"type": "http.request", "body": b"hello", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    chunks = []
    async for chunk in request.stream():
        chunks.append(chunk)

    assert chunks == [b"hello"]


@pytest.mark.asyncio
async def test_request_stream_multiple_chunks():
    """Request.stream(): yields multiple chunks without buffering"""
    data = [b"chunk1", b"chunk2", b"chunk3"]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(data):
            chunk = data[chunk_index]
            more = chunk_index < len(data) - 1
            chunk_index += 1
            return {"type": "http.request", "body": chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    chunks = []
    async for chunk in request.stream():
        chunks.append(chunk)

    assert chunks == data


@pytest.mark.asyncio
async def test_request_stream_empty_chunks_not_yielded():
    """Request.stream(): empty chunks are not yielded"""
    data = [b"hello", b"", b"world", b""]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(data):
            chunk = data[chunk_index]
            more = chunk_index < len(data) - 1
            chunk_index += 1
            return {"type": "http.request", "body": chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    chunks = []
    async for chunk in request.stream():
        chunks.append(chunk)

    assert chunks == [b"hello", b"world"]


@pytest.mark.asyncio
async def test_request_stream_marks_body_consumed():
    """Request.stream(): marks body as consumed"""

    async def receive():
        return {"type": "http.request", "body": b"data", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    async for _ in request.stream():
        pass

    body = await request.body()
    assert body == b""


@pytest.mark.asyncio
async def test_request_stream_large_payload():
    """Request.stream(): handles large streaming payload efficiently"""
    chunk_size = 8192
    num_chunks = 50
    chunks_data = [b"x" * chunk_size for _ in range(num_chunks)]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(chunks_data):
            _chunk = chunks_data[chunk_index]
            more = chunk_index < len(chunks_data) - 1
            chunk_index += 1
            return {"type": "http.request", "body": _chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/upload"}
    request = Request(scope, receive)

    received_chunks = []
    async for chunk in request.stream():
        received_chunks.append(chunk)

    assert len(received_chunks) == num_chunks
    total_size = sum(len(chunk) for chunk in received_chunks)
    assert total_size == chunk_size * num_chunks


@pytest.mark.asyncio
async def test_request_stream_before_body_prevents_caching():
    """Request.stream(): calling stream() before body() prevents body caching"""
    data = [b"part1", b"part2"]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(data):
            _chunk = data[chunk_index]
            more = chunk_index < len(data) - 1
            chunk_index += 1
            return {"type": "http.request", "body": _chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {"type": "http", "method": "POST", "path": "/"}
    request = Request(scope, receive)

    chunks = []
    async for chunk in request.stream():
        chunks.append(chunk)

    body = await request.body()

    assert chunks == data
    assert body == b"", "body() should return empty after stream()"


@pytest.mark.asyncio
async def test_real_world_post_with_json_and_headers():
    """Real-world: POST request with JSON body and headers"""
    payload = {"username": "alice", "email": "alice@example.com"}
    body_bytes = stdlib_json.dumps(payload).encode()

    async def receive():
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    scope = {
        "type": "http",
        "method": "post",
        "path": "/users",
        "query_string": b"",
        "headers": [
            (b"content-type", b"application/json"),
            (b"authorization", b"Bearer token123"),
            (b"user-agent", b"TestClient/1.0"),
        ],
    }

    request = Request(scope, receive)

    assert request.method == "POST"
    assert request.path == "/users"
    assert request.headers.get("content-type") == "application/json"
    assert request.headers.get("authorization") == "Bearer token123"

    parsed = await request.json()
    assert parsed["username"] == "alice"
    assert parsed["email"] == "alice@example.com"


@pytest.mark.asyncio
async def test_real_world_get_with_query_params_and_headers():
    """Real-world: GET request with query params and headers"""

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/search",
        "query_string": b"q=python&category=web&limit=20",
        "headers": [
            (b"accept", b"application/json"),
            (b"x-api-key", b"secret123"),
        ],
    }

    request = Request(scope, receive)

    assert request.method == "GET"
    assert request.path == "/search"
    assert request.query_params.get("q") == "python"
    assert request.query_params.get("category") == "web"
    assert request.query_params.get("limit") == "20"
    assert request.headers.get("accept") == "application/json"
    assert request.headers.get("x-api-key") == "secret123"


@pytest.mark.asyncio
async def test_real_world_multipart_form_simulation_via_stream():
    """Real-world: streaming multipart form data"""
    chunks = [
        b"--boundary\r\n",
        b'Content-Disposition: form-data; name="file"\r\n\r\n',
        b"file content here\r\n",
        b"--boundary--\r\n",
    ]
    chunk_index = 0

    async def receive():
        nonlocal chunk_index
        if chunk_index < len(chunks):
            chunk = chunks[chunk_index]
            more = chunk_index < len(chunks) - 1
            chunk_index += 1
            return {"type": "http.request", "body": chunk, "more_body": more}
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {
        "type": "http",
        "method": "POST",
        "path": "/upload",
        "query_string": b"",
        "headers": [
            (b"content-type", b"multipart/form-data; boundary=boundary"),
        ],
    }

    request = Request(scope, receive)

    received = []
    async for chunk in request.stream():
        received.append(chunk)

    assert len(received) == len(chunks)
    full_body = b"".join(received)
    assert b"file content here" in full_body


@pytest.mark.asyncio
async def test_real_world_path_params_set_by_router():
    """Real-world: path params set by Router after matching"""

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/users/42/posts/99",
        "query_string": b"sort=date",
        "headers": [],
    }

    request = Request(scope, receive)

    request.path_params = {"user_id": "42", "post_id": "99"}

    assert request.path_params["user_id"] == "42"
    assert request.path_params["post_id"] == "99"
    assert request.query_params.get("sort") == "date"


@pytest.mark.asyncio
async def test_real_world_multiple_cookie_headers():
    """Real-world: multiple Set-Cookie headers handled correctly"""

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/",
        "query_string": b"",
        "headers": [
            (b"cookie", b"session=abc123"),
            (b"cookie", b"preferences=dark_mode"),
            (b"cookie", b"tracking=disabled"),
        ],
    }

    request = Request(scope, receive)

    cookies = request.headers.get_all("cookie")
    assert len(cookies) == 3
    assert "session=abc123" in cookies
    assert "preferences=dark_mode" in cookies
    assert "tracking=disabled" in cookies


@pytest.mark.asyncio
async def test_real_world_empty_path_root_request():
    """Real-world: root path '/' request"""

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/",
        "query_string": b"",
        "headers": [(b"host", b"example.com")],
    }

    request = Request(scope, receive)

    assert request.method == "GET"
    assert request.path == "/"
    assert request.headers.get("host") == "example.com"
