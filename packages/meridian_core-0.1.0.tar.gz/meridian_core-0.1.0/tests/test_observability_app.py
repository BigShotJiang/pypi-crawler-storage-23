from __future__ import annotations

import pytest
from meridian import Meridian


class TestWithObservabilityMethod:
    """Test the Meridian.with_observability() method."""

    def test_with_observability_returns_self(self):
        """Test that with_observability() returns the app for chaining."""
        app = Meridian()
        result = app.with_observability()
        assert result is app

    def test_with_observability_can_be_chained(self):
        """Test that with_observability() can be chained with other methods."""
        app = Meridian().with_observability()

        assert hasattr(app, "use")
        assert hasattr(app, "get")
        assert hasattr(app, "post")

    def test_with_observability_without_config(self):
        """Test with_observability() without passing a config."""
        app = Meridian()
        result = app.with_observability()
        assert result is app

    def test_multiple_with_observability_calls(self):
        """Test calling with_observability() multiple times."""
        app = Meridian()

        result1 = app.with_observability()
        result2 = result1.with_observability()

        assert result1 is app
        assert result2 is app

    def test_with_observability_does_not_affect_routing(self):
        """Test that with_observability() doesn't interfere with routing."""
        app = Meridian().with_observability()

        @app.get("/test")
        async def handler() -> dict:
            return {"message": "hello"}

        assert app._router is not None


class TestObservabilityConfiguration:
    """Test observability configuration through app constructor."""

    def test_app_with_observability_in_constructor(self):
        """Test passing observability config to Meridian constructor."""
        app = Meridian(observability=None)
        assert app is not None

    def test_app_without_observability_parameter(self):
        """Test that observability parameter is optional."""
        app = Meridian()
        assert app is not None
        app.with_observability()


class TestObservabilityWithHandlers:
    """Test observability integration with actual handlers."""

    @pytest.mark.asyncio
    async def test_observability_with_simple_handler(self):
        """Test observability with a simple request handler."""
        from meridian.testing import AsyncTestClient

        app = Meridian().with_observability()

        @app.get("/simple")
        async def handler() -> dict:
            return {"status": "ok"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/simple")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_observability_with_path_parameters(self):
        """Test observability with simple path route."""
        from meridian.testing import AsyncTestClient

        app = Meridian().with_observability()

        @app.get("/users/list")
        async def get_users() -> dict:
            return {"users": []}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/users/list")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_observability_with_query_parameters(self):
        """Test observability with query parameters."""
        from meridian.testing import AsyncTestClient

        app = Meridian().with_observability()

        @app.get("/search")
        async def search() -> dict:
            return {"query": "test"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/search?q=test")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_observability_with_middleware(self):
        """Test observability with middleware stack."""
        from meridian import middleware
        from meridian.testing import AsyncTestClient

        app = Meridian().with_observability()

        @middleware
        async def test_mw(request, next_handler):
            return await next_handler(request)

        app.use(test_mw)

        @app.get("/with-mw")
        async def handler() -> dict:
            return {"message": "hello"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/with-mw")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_observability_does_not_prevent_error_handling(self):
        """Test that observability doesn't break error handling."""
        from meridian.exceptions import BadRequest
        from meridian.testing import AsyncTestClient

        app = Meridian().with_observability()

        @app.get("/error")
        async def handler():
            raise BadRequest("test error")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400


class TestObservabilityDisabled:
    """Test that observability can be disabled or omitted."""

    def test_app_without_with_observability_call(self):
        """Test that app works fine without calling with_observability()."""

        app = Meridian()

        @app.get("/test")
        async def handler() -> dict:
            return {"status": "ok"}

        assert app is not None

    @pytest.mark.asyncio
    async def test_request_succeeds_without_observability(self):
        """Test that requests succeed without observability."""
        from meridian.testing import AsyncTestClient

        app = Meridian()

        @app.get("/test")
        async def handler() -> dict:
            return {"status": "ok"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/test")
            assert resp.status_code == 200


class TestObservabilityEdgeCases:
    """Test edge cases in observability integration."""

    def test_with_observability_then_register_routes(self):
        """Test registering routes after with_observability()."""
        app = Meridian().with_observability()

        @app.get("/route-after-obs")
        async def handler() -> dict:
            return {"ok": True}

        assert app._router is not None

    def test_register_routes_then_with_observability(self):
        """Test calling with_observability() after registering routes."""
        app = Meridian()

        @app.get("/route-before-obs")
        async def handler() -> dict:
            return {"ok": True}

        app.with_observability()

        assert app._router is not None

    def test_with_observability_with_middleware_stack(self):
        """Test with_observability() with complete middleware stack."""
        from meridian import middleware

        app = Meridian()

        @middleware
        async def mw1(request, next_handler):
            return await next_handler(request)

        @middleware
        async def mw2(request, next_handler):
            return await next_handler(request)

        app.use(mw1)
        app.use(mw2)
        app.with_observability()

        @app.get("/complex")
        async def handler() -> dict:
            return {"status": "ok"}

        assert app is not None


class TestObservabilityTraceLogging:
    """Test that traces are actually logged/captured by backends."""

    class LoggingBackend:
        """Backend that logs spans to a list for verification."""

        def __init__(self):
            self.logged_spans: list[dict] = []

        async def on_span_start(self, span) -> None:
            """Log span start."""
            self.logged_spans.append(
                {
                    "event": "start",
                    "trace_id": span.trace_id,
                    "span_id": span.span_id,
                    "name": span.name,
                    "timestamp": "start",
                }
            )

        async def on_span_end(self, span) -> None:
            """Log span end."""
            self.logged_spans.append(
                {
                    "event": "end",
                    "trace_id": span.trace_id,
                    "span_id": span.span_id,
                    "name": span.name,
                    "status": getattr(span, "status", "unknown"),
                }
            )

        async def on_span_error(self, span, error: Exception) -> None:
            """Log span error."""
            self.logged_spans.append(
                {
                    "event": "error",
                    "trace_id": span.trace_id,
                    "span_id": span.span_id,
                    "name": span.name,
                    "error_type": type(error).__name__,
                    "error_message": str(error),
                }
            )

        def get_trace_count(self) -> int:
            """Count number of unique traces logged."""
            trace_ids = {span["trace_id"] for span in self.logged_spans}
            return len(trace_ids)

        def get_span_count(self) -> int:
            """Count total spans logged."""
            return len(self.logged_spans)

        def get_span_names(self) -> list[str]:
            """Get all span names."""
            return [span["name"] for span in self.logged_spans]

        def has_logged_start(self, trace_id: str, span_id: str) -> bool:
            """Check if a span start was logged."""
            return any(
                s["event"] == "start"
                and s["trace_id"] == trace_id
                and s["span_id"] == span_id
                for s in self.logged_spans
            )

        def has_logged_end(self, trace_id: str, span_id: str) -> bool:
            """Check if a span end was logged."""
            return any(
                s["event"] == "end"
                and s["trace_id"] == trace_id
                and s["span_id"] == span_id
                for s in self.logged_spans
            )

        def has_logged_error(self, trace_id: str, error_message: str) -> bool:
            """Check if an error was logged."""
            return any(
                s["event"] == "error"
                and s["trace_id"] == trace_id
                and s["error_message"] == error_message
                for s in self.logged_spans
            )

    @pytest.mark.asyncio
    async def test_successful_request_is_logged(self):
        """Test that a successful request start and end are logged."""
        backend = self.LoggingBackend()
        trace_id = "trace-success-001"
        span_id = "span-001"

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name
                self.status = "unknown"

        span = SimpleSpan(trace_id, span_id, "GET /test")

        await backend.on_span_start(span)
        span.status = "success"
        await backend.on_span_end(span)

        assert backend.has_logged_start(trace_id, span_id)
        assert backend.has_logged_end(trace_id, span_id)
        assert backend.get_span_count() == 2

    @pytest.mark.asyncio
    async def test_error_request_is_logged(self):
        """Test that error requests are logged."""
        backend = self.LoggingBackend()
        trace_id = "trace-error-001"
        span_id = "span-err-001"
        error = ValueError("test error")

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name

        span = SimpleSpan(trace_id, span_id, "GET /error")

        await backend.on_span_start(span)
        await backend.on_span_error(span, error)

        assert backend.has_logged_start(trace_id, span_id)
        assert backend.has_logged_error(trace_id, "test error")
        assert backend.get_span_count() == 2

    @pytest.mark.asyncio
    async def test_multiple_spans_in_trace_are_logged(self):
        """Test that multiple spans in the same trace are all logged."""
        backend = self.LoggingBackend()
        trace_id = "trace-multi-001"

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name

        span1 = SimpleSpan(trace_id, "span-1", "middleware-1")
        span2 = SimpleSpan(trace_id, "span-2", "handler")
        span3 = SimpleSpan(trace_id, "span-3", "middleware-2")

        await backend.on_span_start(span1)
        await backend.on_span_start(span2)
        await backend.on_span_start(span3)

        await backend.on_span_end(span1)
        await backend.on_span_end(span2)
        await backend.on_span_end(span3)

        assert backend.get_trace_count() == 1
        assert backend.get_span_count() == 6
        assert "middleware-1" in backend.get_span_names()
        assert "handler" in backend.get_span_names()
        assert "middleware-2" in backend.get_span_names()

    @pytest.mark.asyncio
    async def test_span_metadata_is_logged(self):
        """Test that span metadata is correctly logged."""
        backend = self.LoggingBackend()
        trace_id = "trace-meta-001"
        span_id = "span-meta-001"
        operation = "GET /users/{id}"

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name
                self.status = "unknown"

        span = SimpleSpan(trace_id, span_id, operation)
        span.status = "success"

        await backend.on_span_start(span)
        await backend.on_span_end(span)
        logged_start = [s for s in backend.logged_spans if s["event"] == "start"][0]
        logged_end = [s for s in backend.logged_spans if s["event"] == "end"][0]

        assert logged_start["trace_id"] == trace_id
        assert logged_start["span_id"] == span_id
        assert logged_start["name"] == operation

        assert logged_end["trace_id"] == trace_id
        assert logged_end["span_id"] == span_id
        assert logged_end["status"] == "success"

    @pytest.mark.asyncio
    async def test_error_details_are_logged(self):
        """Test that error details are fully logged."""
        backend = self.LoggingBackend()
        trace_id = "trace-err-detail"
        span_id = "span-err-detail"
        error = RuntimeError("database connection failed")

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name

        span = SimpleSpan(trace_id, span_id, "db-query")

        await backend.on_span_start(span)
        await backend.on_span_error(span, error)

        error_log = [s for s in backend.logged_spans if s["event"] == "error"][0]

        assert error_log["error_type"] == "RuntimeError"
        assert error_log["error_message"] == "database connection failed"
        assert error_log["trace_id"] == trace_id
        assert error_log["span_id"] == span_id

    @pytest.mark.asyncio
    async def test_parallel_traces_are_logged_separately(self):
        """Test that different traces don't interfere with logging."""
        backend = self.LoggingBackend()

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name

        trace1_id = "trace-001"
        trace2_id = "trace-002"

        span1a = SimpleSpan(trace1_id, "span-1a", "request-1")
        span1b = SimpleSpan(trace1_id, "span-1b", "handler-1")

        span2a = SimpleSpan(trace2_id, "span-2a", "request-2")
        span2b = SimpleSpan(trace2_id, "span-2b", "handler-2")

        await backend.on_span_start(span1a)
        await backend.on_span_start(span2a)
        await backend.on_span_start(span1b)
        await backend.on_span_start(span2b)

        await backend.on_span_end(span1b)
        await backend.on_span_end(span2b)
        await backend.on_span_end(span1a)
        await backend.on_span_end(span2a)

        assert backend.get_trace_count() == 2
        assert backend.get_span_count() == 8

        trace1_spans = [s for s in backend.logged_spans if s["trace_id"] == trace1_id]
        trace2_spans = [s for s in backend.logged_spans if s["trace_id"] == trace2_id]

        assert len(trace1_spans) == 4
        assert len(trace2_spans) == 4

    @pytest.mark.asyncio
    async def test_span_order_is_preserved_in_log(self):
        """Test that spans are logged in the order they occur."""
        backend = self.LoggingBackend()
        trace_id = "trace-order"

        class SimpleSpan:
            def __init__(self, trace_id, span_id, name):
                self.trace_id = trace_id
                self.span_id = span_id
                self.name = name

        span = SimpleSpan(trace_id, "span-1", "operation")

        await backend.on_span_start(span)
        start_index = len(backend.logged_spans) - 1

        await backend.on_span_end(span)
        end_index = len(backend.logged_spans) - 1

        assert start_index < end_index
        assert backend.logged_spans[start_index]["event"] == "start"
        assert backend.logged_spans[end_index]["event"] == "end"
