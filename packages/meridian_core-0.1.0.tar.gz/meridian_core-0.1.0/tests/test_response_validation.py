import pytest
from typing import Optional
from meridian import Meridian, ValidationConfig, Response, JSONResponse
from meridian.testing import AsyncTestClient


@pytest.mark.asyncio
async def test_response_validation_disabled():
    """Response validation: disabled when validate_responses=False"""
    app = Meridian(validation=ValidationConfig(validate_responses=False))

    @app.get("/data")
    async def get_data() -> dict:
        return {"message": "hello"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_passthrough_mode():
    """Response validation: disabled in passthrough mode"""
    app = Meridian(
        validation=ValidationConfig(mode="passthrough", validate_responses=True)
    )

    @app.get("/data")
    async def get_data() -> int:
        return {"message": "hello"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_dict():
    """Response validation: dict return type"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def get_data() -> dict:
        return {"message": "hello", "count": 42}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200
        assert resp.json() == {"message": "hello", "count": 42}


@pytest.mark.asyncio
async def test_response_validation_dict_wrong_type():
    """Response validation: dict return type with wrong data raises error"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def get_data() -> dict:
        return "not a dict"

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 500


@pytest.mark.asyncio
async def test_response_validation_list():
    """Response validation: list return type"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/items")
    async def get_items() -> list:
        return [1, 2, 3]

    async with AsyncTestClient(app) as client:
        resp = await client.get("/items")
        assert resp.status_code == 200
        assert resp.json() == [1, 2, 3]


@pytest.mark.asyncio
async def test_response_validation_string():
    """Response validation: string return type"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/message")
    async def get_message() -> str:
        return "hello world"

    async with AsyncTestClient(app) as client:
        resp = await client.get("/message")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_optional_dict_with_value():
    """Response validation: Optional[dict] with actual dict"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def get_data() -> Optional[dict]:
        return {"key": "value"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_optional_dict_with_none():
    """Response validation: Optional[dict] with None"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def get_data() -> Optional[dict]:
        return None

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 204


@pytest.mark.asyncio
async def test_response_validation_none_type():
    """Response validation: None return type"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/action")
    async def perform_action() -> None:
        return None

    async with AsyncTestClient(app) as client:
        resp = await client.get("/action")
        assert resp.status_code == 204


@pytest.mark.asyncio
async def test_response_validation_none_when_dict_returned():
    """Response validation: None return type when dict returned raises error"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/action")
    async def perform_action() -> None:
        return {"error": "should not return dict"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/action")
        assert resp.status_code == 500


@pytest.mark.asyncio
async def test_response_validation_list_of_dicts():
    """Response validation: list[dict] return type"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/items")
    async def get_items() -> list[dict]:
        return [{"id": 1}, {"id": 2}]

    async with AsyncTestClient(app) as client:
        resp = await client.get("/items")
        assert resp.status_code == 200
        assert resp.json() == [{"id": 1}, {"id": 2}]


@pytest.mark.asyncio
async def test_response_validation_list_of_dicts_wrong_element():
    """Response validation: list[dict] with non-dict element raises error"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/items")
    async def get_items() -> list[dict]:
        return [{"id": 1}, "not a dict"]

    async with AsyncTestClient(app) as client:
        resp = await client.get("/items")
        assert resp.status_code == 500


@pytest.mark.asyncio
async def test_response_validation_dict_of_strings():
    """Response validation: dict[str, str] return type"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/mapping")
    async def get_mapping() -> dict[str, str]:
        return {"key1": "value1", "key2": "value2"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/mapping")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_dict_wrong_value_type():
    """Response validation: dict[str, str] with int value raises error"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/mapping")
    async def get_mapping() -> dict[str, str]:
        return {"key1": "value1", "key2": 123}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/mapping")
        assert resp.status_code == 500


@pytest.mark.asyncio
async def test_response_validation_response_subclass_always_passes():
    """Response validation: Response subclass always passes validation"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def get_data() -> dict:
        return JSONResponse({"data": "value"})

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_custom_response():
    """Response validation: custom Response instance passes"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/custom")
    async def get_custom() -> Response:
        return Response(b"custom", status_code=201, media_type="text/plain")

    async with AsyncTestClient(app) as client:
        resp = await client.get("/custom")
        assert resp.status_code == 201


@pytest.mark.asyncio
async def test_response_validation_no_annotation():
    """Response validation: handler with no return annotation skips validation"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def handler():
        return {"message": "hello"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_response_validation_with_request_validation():
    """Response validation: works alongside request validation"""
    from meridian import Query

    app = Meridian(
        validation=ValidationConfig(
            mode="strict", validate_responses=True, ignore_unknown_query_params=False
        )
    )

    @app.get("/process")
    async def process(limit: Query[int] = 10) -> dict:
        return {"result": "ok", "limit": limit}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/process")
        assert resp.status_code == 200

        resp = await client.get("/process?limit=5")
        assert resp.status_code == 200

        resp = await client.get("/process?unknown=value")
        assert resp.status_code == 422


@pytest.mark.asyncio
async def test_response_validation_multiple_handlers():
    """Response validation: different return types for different endpoints"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/dict")
    async def get_dict() -> dict:
        return {"type": "dict"}

    @app.get("/list")
    async def get_list() -> list:
        return ["item1", "item2"]

    @app.get("/none")
    async def get_none() -> None:
        return None

    async with AsyncTestClient(app) as client:
        resp = await client.get("/dict")
        assert resp.status_code == 200
        assert resp.json() == {"type": "dict"}

        resp = await client.get("/list")
        assert resp.status_code == 200
        assert resp.json() == ["item1", "item2"]

        resp = await client.get("/none")
        assert resp.status_code == 204


@pytest.mark.asyncio
async def test_response_validation_skip_when_none_annotation():
    """Response validation: handlers with no return annotation skip validation"""
    app = Meridian(validation=ValidationConfig(mode="strict", validate_responses=True))

    @app.get("/data")
    async def get_data():
        return {"message": "hello"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/data")
        assert resp.status_code == 200
        assert resp.json() == {"message": "hello"}
