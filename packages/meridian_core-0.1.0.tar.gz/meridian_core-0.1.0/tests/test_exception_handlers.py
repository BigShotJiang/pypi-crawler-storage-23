"""
Tests for custom exception handlers and default_response_class features.
"""

import json as stdlib_json
import pytest

from meridian import Meridian
from meridian.response import Response, JSONResponse, ErrorResponse
from meridian.exceptions import BadRequest, NotFound, MeridianError
from meridian.testing import AsyncTestClient


class TestExceptionHandlers:
    """Test custom exception handler functionality."""

    @pytest.mark.asyncio
    async def test_custom_handler_for_meridian_error(self):
        """Exception handler: custom handler for MeridianError subclass"""

        async def custom_handler(request, exc):
            return JSONResponse(
                {"custom": "error", "detail": exc.detail}, status_code=400
            )

        app = Meridian(exception_handlers={BadRequest: custom_handler})

        @app.get("/error")
        async def handler():
            raise BadRequest("Invalid input")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            data = resp.json()
            assert data["custom"] == "error"
            assert data["detail"] == "Invalid input"

    @pytest.mark.asyncio
    async def test_custom_handler_for_generic_exception(self):
        """Exception handler: custom handler for generic Exception"""

        async def custom_handler(request, exc):
            return JSONResponse(
                {"error": "value error", "message": str(exc)}, status_code=400
            )

        app = Meridian(exception_handlers={ValueError: custom_handler})

        @app.get("/error")
        async def handler():
            raise ValueError("Invalid value provided")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            data = resp.json()
            assert data["error"] == "value error"
            assert data["message"] == "Invalid value provided"

    @pytest.mark.asyncio
    async def test_handler_returns_none_falls_back_to_default(self):
        """Exception handler: if handler returns None, use default error response"""
        handler_called = False

        async def custom_handler(request, exc):
            nonlocal handler_called
            handler_called = True
            return None  # Fall back to default

        app = Meridian(exception_handlers={BadRequest: custom_handler})

        @app.get("/error")
        async def handler():
            raise BadRequest("Invalid input")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            assert handler_called is True
            data = resp.json()
            # Should get default error response
            assert "detail" in data

    @pytest.mark.asyncio
    async def test_handler_exception_falls_back_to_default(self):
        """Exception handler: if handler raises, use default error response"""

        async def failing_handler(request, exc):
            raise RuntimeError("Handler failed")

        app = Meridian(exception_handlers={BadRequest: failing_handler})

        @app.get("/error")
        async def handler():
            raise BadRequest("Invalid input")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            data = resp.json()
            # Should get default error response
            assert "detail" in data

    @pytest.mark.asyncio
    async def test_handler_respects_exception_inheritance(self):
        """Exception handler: handler for parent exception catches subclass"""

        async def parent_handler(request, exc):
            return JSONResponse(
                {"handler": "parent", "type": type(exc).__name__},
                status_code=exc.status_code,
            )

        app = Meridian(exception_handlers={MeridianError: parent_handler})

        @app.get("/bad-request")
        async def bad_request_handler():
            raise BadRequest("Bad request")

        @app.get("/not-found")
        async def not_found_handler():
            raise NotFound("Not found")

        async with AsyncTestClient(app) as client:
            # Both should be caught by the MeridianError handler
            resp = await client.get("/bad-request")
            assert resp.status_code == 400
            data = resp.json()
            assert data["handler"] == "parent"
            assert data["type"] == "BadRequest"

            resp = await client.get("/not-found")
            assert resp.status_code == 404
            data = resp.json()
            assert data["handler"] == "parent"
            assert data["type"] == "NotFound"

    @pytest.mark.asyncio
    async def test_specific_handler_takes_precedence(self):
        """Exception handler: specific handler takes precedence over parent"""

        async def specific_handler(request, exc):
            return JSONResponse({"handler": "specific"}, status_code=400)

        async def parent_handler(request, exc):
            return JSONResponse({"handler": "parent"}, status_code=exc.status_code)

        app = Meridian(
            exception_handlers={
                BadRequest: specific_handler,
                MeridianError: parent_handler,
            }
        )

        @app.get("/error")
        async def handler():
            raise BadRequest("Invalid input")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            data = resp.json()
            assert data["handler"] == "specific"

    @pytest.mark.asyncio
    async def test_unhandled_exception_type_uses_default(self):
        """Exception handler: unregistered exception types use default handling"""

        async def bad_request_handler(request, exc):
            return JSONResponse({"handler": "badrequest"}, status_code=400)

        app = Meridian(exception_handlers={BadRequest: bad_request_handler})

        @app.get("/error")
        async def handler():
            raise ValueError("Unhandled exception")

        async with AsyncTestClient(app) as client:
            # Unhandled exceptions are re-raised after 500 response
            with pytest.raises(ValueError):
                await client.get("/error")

    @pytest.mark.asyncio
    async def test_handler_can_access_request(self):
        """Exception handler: handler receives Request object"""

        async def custom_handler(request, exc):
            return JSONResponse(
                {
                    "path": request.path,
                    "method": request.method,
                    "error": str(exc),
                },
                status_code=400,
            )

        app = Meridian(exception_handlers={BadRequest: custom_handler})

        @app.post("/api/data")
        async def handler():
            raise BadRequest("Bad data")

        async with AsyncTestClient(app) as client:
            resp = await client.post("/api/data")
            assert resp.status_code == 400
            data = resp.json()
            assert data["path"] == "/api/data"
            assert data["method"] == "POST"
            assert data["error"] == "Bad data"

    @pytest.mark.asyncio
    async def test_handler_can_return_custom_response(self):
        """Exception handler: handler can return any Response subclass"""

        async def custom_handler(request, exc):
            return Response(
                b"Custom error message", status_code=400, media_type="text/plain"
            )

        app = Meridian(exception_handlers={BadRequest: custom_handler})

        @app.get("/error")
        async def handler():
            raise BadRequest("Invalid input")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            assert resp.text() == "Custom error message"
            assert resp.headers["content-type"] == "text/plain"

    @pytest.mark.asyncio
    async def test_multiple_exception_handlers(self):
        """Exception handler: multiple handlers for different exception types"""

        async def bad_request_handler(request, exc):
            return JSONResponse({"type": "bad_request"}, status_code=400)

        async def not_found_handler(request, exc):
            return JSONResponse({"type": "not_found"}, status_code=404)

        async def value_error_handler(request, exc):
            return JSONResponse({"type": "value_error"}, status_code=400)

        app = Meridian(
            exception_handlers={
                BadRequest: bad_request_handler,
                NotFound: not_found_handler,
                ValueError: value_error_handler,
            }
        )

        @app.get("/bad")
        async def bad():
            raise BadRequest("Bad")

        @app.get("/missing")
        async def missing():
            raise NotFound("Missing")

        @app.get("/invalid")
        async def invalid():
            raise ValueError("Invalid")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/bad")
            assert resp.json()["type"] == "bad_request"
            assert resp.status_code == 400

            resp = await client.get("/missing")
            assert resp.json()["type"] == "not_found"
            assert resp.status_code == 404

            resp = await client.get("/invalid")
            assert resp.json()["type"] == "value_error"
            assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_handler_does_not_affect_error_hooks(self):
        """Exception handler: error hooks still fire after custom handler"""
        error_hook_called = False
        error_hook_exception = None

        async def on_error(ctx, exc):
            nonlocal error_hook_called, error_hook_exception
            error_hook_called = True
            error_hook_exception = exc

        from meridian.config import LifeCycleHooks

        lifecycle = LifeCycleHooks(on_request_error=[on_error])

        async def custom_handler(request, exc):
            return JSONResponse({"handled": True}, status_code=400)

        app = Meridian(
            lifecycle=lifecycle, exception_handlers={BadRequest: custom_handler}
        )

        @app.get("/error")
        async def handler():
            raise BadRequest("Test error")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            assert error_hook_called is True
            assert isinstance(error_hook_exception, BadRequest)

    @pytest.mark.asyncio
    async def test_empty_exception_handlers(self):
        """Exception handler: empty handlers dict works fine"""
        app = Meridian(exception_handlers={})

        @app.get("/error")
        async def handler():
            raise BadRequest("Test error")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            data = resp.json()
            assert "detail" in data

    @pytest.mark.asyncio
    async def test_none_exception_handlers(self):
        """Exception handler: None exception_handlers works fine"""
        app = Meridian(exception_handlers=None)

        @app.get("/error")
        async def handler():
            raise BadRequest("Test error")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/error")
            assert resp.status_code == 400
            data = resp.json()
            assert "detail" in data


class TestDefaultResponseClass:
    """Test default_response_class functionality."""

    @pytest.mark.asyncio
    async def test_default_response_class_wraps_dict(self):
        """Response class: custom class wraps dict returns"""
        app = Meridian(default_response_class=JSONResponse)

        @app.get("/data")
        async def handler() -> dict:
            return {"message": "hello"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/data")
            assert resp.status_code == 200
            assert resp.json() == {"message": "hello"}

    @pytest.mark.asyncio
    async def test_default_response_class_wraps_list(self):
        """Response class: custom class wraps list returns"""
        app = Meridian(default_response_class=JSONResponse)

        @app.get("/items")
        async def handler() -> list:
            return [1, 2, 3]

        async with AsyncTestClient(app) as client:
            resp = await client.get("/items")
            assert resp.status_code == 200
            assert resp.json() == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_default_response_class_wraps_pydantic(self):
        """Response class: custom class wraps Pydantic models"""
        from pydantic import BaseModel

        class User(BaseModel):
            name: str
            age: int

        app = Meridian(default_response_class=JSONResponse)

        @app.get("/user")
        async def handler() -> User:
            return User(name="Alice", age=30)

        async with AsyncTestClient(app) as client:
            resp = await client.get("/user")
            assert resp.status_code == 200
            data = resp.json()
            assert data["name"] == "Alice"
            assert data["age"] == 30

    @pytest.mark.asyncio
    async def test_response_pass_through_not_affected(self):
        """Response class: Response subclasses pass through unchanged"""
        app = Meridian(default_response_class=JSONResponse)

        @app.get("/custom")
        async def handler() -> Response:
            return Response(b"custom content", status_code=201, media_type="text/plain")

        async with AsyncTestClient(app) as client:
            resp = await client.get("/custom")
            assert resp.status_code == 201
            assert resp.text() == "custom content"

    @pytest.mark.asyncio
    async def test_none_return_unaffected(self):
        """Response class: None returns always 204 No Content"""
        app = Meridian(default_response_class=JSONResponse)

        @app.get("/none")
        async def handler() -> None:
            return None

        async with AsyncTestClient(app) as client:
            resp = await client.get("/none")
            assert resp.status_code == 204
            assert resp.text() == ""

    @pytest.mark.asyncio
    async def test_string_return_unaffected(self):
        """Response class: str returns always text/plain"""
        app = Meridian(default_response_class=JSONResponse)

        @app.get("/text")
        async def handler() -> str:
            return "Hello, World!"

        async with AsyncTestClient(app) as client:
            resp = await client.get("/text")
            assert resp.status_code == 200
            assert resp.text() == "Hello, World!"
            assert "text/plain" in resp.headers["content-type"]

    @pytest.mark.asyncio
    async def test_custom_response_class_with_orjson(self):
        """Response class: can use ORJSONResponse if available"""
        pytest.importorskip("orjson")
        from meridian.response import ORJSONResponse

        app = Meridian(default_response_class=ORJSONResponse)

        @app.get("/data")
        async def handler() -> dict:
            return {"message": "hello", "count": 42}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/data")
            assert resp.status_code == 200
            data = resp.json()
            assert data["message"] == "hello"
            assert data["count"] == 42

    @pytest.mark.asyncio
    async def test_custom_response_class_created_correctly(self):
        """Response class: custom class receives correct arguments"""

        class TrackedResponse(JSONResponse):
            """Custom response class to track instantiation"""

            instances = []

            def __init__(self, content, status_code=200, headers=None):
                TrackedResponse.instances.append(
                    {
                        "content": content,
                        "status_code": status_code,
                    }
                )
                super().__init__(content, status_code, headers)

        TrackedResponse.instances.clear()
        app = Meridian(default_response_class=TrackedResponse)

        @app.get("/tracked")
        async def handler() -> dict:
            return {"key": "value"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/tracked")
            assert resp.status_code == 200
            assert len(TrackedResponse.instances) > 0
            # Check that the response class was instantiated with correct data
            assert any(
                inst["content"] == {"key": "value"} and inst["status_code"] == 200
                for inst in TrackedResponse.instances
            )

    @pytest.mark.asyncio
    async def test_default_response_class_with_multiple_handlers(self):
        """Response class: applies to all handlers using default class"""
        app = Meridian(default_response_class=JSONResponse)

        @app.get("/dict")
        async def get_dict() -> dict:
            return {"type": "dict"}

        @app.get("/list")
        async def get_list() -> list:
            return [1, 2, 3]

        @app.post("/data")
        async def post_data() -> dict:
            return {"posted": True}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/dict")
            assert resp.json() == {"type": "dict"}

            resp = await client.get("/list")
            assert resp.json() == [1, 2, 3]

            resp = await client.post("/data")
            assert resp.json() == {"posted": True}

    @pytest.mark.asyncio
    async def test_default_response_class_defaults_to_json_response(self):
        """Response class: defaults to JSONResponse if not specified"""
        app = Meridian()  # No default_response_class specified

        @app.get("/default")
        async def handler() -> dict:
            return {"message": "default"}

        async with AsyncTestClient(app) as client:
            resp = await client.get("/default")
            assert resp.status_code == 200
            assert resp.headers["content-type"] == "application/json"
            assert resp.json() == {"message": "default"}


class TestExceptionHandlersAndResponseClass:
    """Test interaction between exception_handlers and default_response_class."""

    @pytest.mark.asyncio
    async def test_exception_handler_with_custom_response_class(self):
        """Both features: exception handler and custom response class"""

        async def custom_error(request, exc):
            return JSONResponse({"error": str(exc)}, status_code=400)

        app = Meridian(
            default_response_class=JSONResponse,
            exception_handlers={BadRequest: custom_error},
        )

        @app.get("/error")
        async def error_handler():
            raise BadRequest("Test error")

        @app.get("/success")
        async def success_handler() -> dict:
            return {"status": "ok"}

        async with AsyncTestClient(app) as client:
            # Test exception handling
            resp = await client.get("/error")
            assert resp.status_code == 400
            assert resp.json()["error"] == "Test error"

            # Test default response class
            resp = await client.get("/success")
            assert resp.status_code == 200
            assert resp.json() == {"status": "ok"}
