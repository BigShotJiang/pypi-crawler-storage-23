from __future__ import annotations
import time
import pytest
from meridian.context import (
    RequestContext,
    get_request_context,
    _set_request_context,
    _reset_request_context,
    make_request_context,
)


def test_request_context_basic_creation():
    """RequestContext: creates with required fields"""
    now = time.monotonic()
    ctx = RequestContext(
        request_id="req-123",
        received_at=now,
        method="GET",
        path="/api/users",
        deadline_at=None,
    )

    assert ctx.request_id == "req-123"
    assert ctx.received_at == now
    assert ctx.method == "GET"
    assert ctx.path == "/api/users"
    assert ctx.deadline_at is None


def test_request_context_with_deadline():
    """RequestContext: can have a deadline"""
    now = time.monotonic()
    deadline = now + 5.0
    ctx = RequestContext(
        request_id="req-456",
        received_at=now,
        method="POST",
        path="/api/data",
        deadline_at=deadline,
    )

    assert ctx.deadline_at == deadline


def test_request_context_route_field():
    """RequestContext: route field defaults to None"""
    ctx = RequestContext(
        request_id="req-789",
        received_at=time.monotonic(),
        method="GET",
        path="/users",
        deadline_at=None,
    )

    assert ctx.route is None


def test_request_context_route_can_be_set():
    """RequestContext: route field can be set"""
    ctx = RequestContext(
        request_id="req-111",
        received_at=time.monotonic(),
        method="GET",
        path="/users",
        deadline_at=None,
        route="get_user",
    )

    assert ctx.route == "get_user"


def test_request_context_extras_field():
    """RequestContext: extras field defaults to empty dict"""
    ctx = RequestContext(
        request_id="req-222",
        received_at=time.monotonic(),
        method="GET",
        path="/",
        deadline_at=None,
    )

    assert ctx.extras == {}


def test_request_context_extras_can_be_set():
    """RequestContext: extras field can store additional data"""
    ctx = RequestContext(
        request_id="req-333",
        received_at=time.monotonic(),
        method="GET",
        path="/",
        deadline_at=None,
        extras={"user_id": "42", "token": "abc123"},
    )

    assert ctx.extras["user_id"] == "42"
    assert ctx.extras["token"] == "abc123"


def test_request_context_multiple_http_methods():
    """RequestContext: works with all HTTP methods"""
    now = time.monotonic()
    methods = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]

    for method in methods:
        ctx = RequestContext(
            request_id="req",
            received_at=now,
            method=method,
            path="/",
            deadline_at=None,
        )
        assert ctx.method == method


def test_request_context_various_paths():
    """RequestContext: handles various path formats"""
    now = time.monotonic()
    paths = [
        "/",
        "/users",
        "/api/v1/users/42/posts",
        "/api/search?q=python",
        "/path/with%20spaces",
    ]

    for path in paths:
        ctx = RequestContext(
            request_id="req",
            received_at=now,
            method="GET",
            path=path,
            deadline_at=None,
        )
        assert ctx.path == path


def test_elapsed_ms_zero():
    """elapsed_ms: returns ~0 immediately after creation"""
    now = time.monotonic()
    ctx = RequestContext(
        request_id="req",
        received_at=now,
        method="GET",
        path="/",
        deadline_at=None,
    )

    elapsed = ctx.elapsed_ms()
    assert elapsed >= 0
    assert elapsed < 10


def test_elapsed_ms_after_delay():
    """elapsed_ms: increases over time"""
    now = time.monotonic()
    ctx = RequestContext(
        request_id="req",
        received_at=now,
        method="GET",
        path="/",
        deadline_at=None,
    )

    elapsed_before = ctx.elapsed_ms()
    time.sleep(0.05)
    elapsed_after = ctx.elapsed_ms()

    assert elapsed_after > elapsed_before
    assert elapsed_after >= 50


def test_elapsed_ms_many_calls():
    """elapsed_ms: can be called multiple times"""
    now = time.monotonic()
    ctx = RequestContext(
        request_id="req",
        received_at=now,
        method="GET",
        path="/",
        deadline_at=None,
    )

    elapsed1 = ctx.elapsed_ms()
    time.sleep(0.01)
    elapsed2 = ctx.elapsed_ms()
    time.sleep(0.01)
    elapsed3 = ctx.elapsed_ms()

    assert elapsed1 < elapsed2 < elapsed3


def test_is_deadline_exceeded_no_deadline():
    """is_deadline_exceeded: returns False when no deadline"""
    ctx = RequestContext(
        request_id="req",
        received_at=time.monotonic(),
        method="GET",
        path="/",
        deadline_at=None,
    )

    assert ctx.is_deadline_exceeded() is False


def test_is_deadline_exceeded_future_deadline():
    """is_deadline_exceeded: returns False for future deadline"""
    now = time.monotonic()
    future = now + 10.0
    ctx = RequestContext(
        request_id="req",
        received_at=now,
        method="GET",
        path="/",
        deadline_at=future,
    )

    assert ctx.is_deadline_exceeded() is False


def test_is_deadline_exceeded_past_deadline():
    """is_deadline_exceeded: returns True for past deadline"""
    now = time.monotonic()
    past = now - 1.0
    ctx = RequestContext(
        request_id="req",
        received_at=now,
        method="GET",
        path="/",
        deadline_at=past,
    )

    assert ctx.is_deadline_exceeded() is True


def test_is_deadline_exceeded_almost_expired():
    """is_deadline_exceeded: works near deadline"""
    now = time.monotonic()
    deadline = now + 0.01
    ctx = RequestContext(
        request_id="req",
        received_at=now,
        method="GET",
        path="/",
        deadline_at=deadline,
    )

    assert ctx.is_deadline_exceeded() is False

    time.sleep(0.02)
    assert ctx.is_deadline_exceeded() is True


def test_get_request_context_raises_when_not_set():
    """get_request_context: raises LookupError when context not set"""
    with pytest.raises(LookupError, match="called outside a request"):
        get_request_context()


def test_get_request_context_returns_set_context():
    """get_request_context: returns the set context"""
    now = time.monotonic()
    original_ctx = RequestContext(
        request_id="req-123",
        received_at=now,
        method="POST",
        path="/api/data",
        deadline_at=None,
    )

    token = _set_request_context(original_ctx)
    try:
        retrieved_ctx = get_request_context()
        assert retrieved_ctx is original_ctx
        assert retrieved_ctx.request_id == "req-123"
        assert retrieved_ctx.method == "POST"
    finally:
        _reset_request_context(token)


def test_get_request_context_isolation():
    """get_request_context: each context is isolated in its ContextVar"""
    now = time.monotonic()
    ctx1 = RequestContext(
        request_id="req-1",
        received_at=now,
        method="GET",
        path="/path1",
        deadline_at=None,
    )
    ctx2 = RequestContext(
        request_id="req-2",
        received_at=now,
        method="POST",
        path="/path2",
        deadline_at=None,
    )

    token1 = _set_request_context(ctx1)
    try:
        assert get_request_context().request_id == "req-1"

        token2 = _set_request_context(ctx2)
        try:
            assert get_request_context().request_id == "req-2"
        finally:
            _reset_request_context(token2)

        assert get_request_context().request_id == "req-1"
    finally:
        _reset_request_context(token1)


def test_set_request_context_returns_token():
    """_set_request_context: returns a token for resetting"""
    ctx = RequestContext(
        request_id="req",
        received_at=time.monotonic(),
        method="GET",
        path="/",
        deadline_at=None,
    )

    token = _set_request_context(ctx)
    assert token is not None

    _reset_request_context(token)


def test_reset_request_context_clears_context():
    """_reset_request_context: clears context when called"""
    ctx = RequestContext(
        request_id="req",
        received_at=time.monotonic(),
        method="GET",
        path="/",
        deadline_at=None,
    )

    token = _set_request_context(ctx)
    assert get_request_context().request_id == "req"

    _reset_request_context(token)

    with pytest.raises(LookupError):
        get_request_context()


def test_set_and_reset_multiple_times():
    """_set_request_context: can be set and reset multiple times"""
    now = time.monotonic()

    for i in range(3):
        ctx = RequestContext(
            request_id=f"req-{i}",
            received_at=now,
            method="GET",
            path=f"/path{i}",
            deadline_at=None,
        )

        token = _set_request_context(ctx)
        assert get_request_context().request_id == f"req-{i}"
        _reset_request_context(token)

        with pytest.raises(LookupError):
            get_request_context()


def test_reset_with_invalid_token_doesnt_crash():
    """_reset_request_context: handles invalid token gracefully"""
    ctx = RequestContext(
        request_id="req",
        received_at=time.monotonic(),
        method="GET",
        path="/",
        deadline_at=None,
    )

    token = _set_request_context(ctx)
    fake_token = "invalid-token"

    try:
        _reset_request_context(fake_token)
    except (TypeError, ValueError, AttributeError):
        pass


def test_make_request_context_no_deadline():
    """make_request_context: creates context without deadline"""
    ctx = make_request_context(
        method="GET",
        path="/api/users",
        deadline_ms=None,
    )

    assert ctx.method == "GET"
    assert ctx.path == "/api/users"
    assert ctx.deadline_at is None
    assert ctx.request_id is not None
    assert ctx.received_at is not None


def test_make_request_context_with_deadline():
    """make_request_context: creates context with deadline"""
    before = time.monotonic()
    ctx = make_request_context(
        method="POST",
        path="/api/data",
        deadline_ms=5000,
    )
    after = time.monotonic()

    assert ctx.deadline_at is not None
    deadline_delta = ctx.deadline_at - before
    assert 4.9 < deadline_delta < 5.1


def test_make_request_context_generates_unique_request_ids():
    """make_request_context: generates unique request IDs"""
    ctx1 = make_request_context("GET", "/", deadline_ms=None)
    ctx2 = make_request_context("GET", "/", deadline_ms=None)

    assert ctx1.request_id != ctx2.request_id


def test_make_request_context_request_id_is_valid_uuid():
    """make_request_context: request_id is a valid UUID string"""
    ctx = make_request_context("GET", "/", deadline_ms=None)

    import uuid

    uuid_obj = uuid.UUID(ctx.request_id)
    assert str(uuid_obj) == ctx.request_id


def test_make_request_context_received_at_is_recent():
    """make_request_context: received_at is set to current time"""
    before = time.monotonic()
    ctx = make_request_context("GET", "/", deadline_ms=None)
    after = time.monotonic()

    assert before <= ctx.received_at <= after


def test_make_request_context_zero_deadline():
    """make_request_context: deadline_ms=0 is treated as no deadline"""
    before = time.monotonic()
    ctx = make_request_context("GET", "/", deadline_ms=0)
    after = time.monotonic()

    assert ctx.deadline_at is None


def test_make_request_context_large_deadline():
    """make_request_context: handles large deadline values"""
    ctx = make_request_context("GET", "/", deadline_ms=3600000)

    deadline_delta = ctx.deadline_at - ctx.received_at
    assert 3599 < deadline_delta < 3601


def test_make_request_context_negative_deadline_ignored():
    """make_request_context: negative deadline_ms is treated as None"""
    ctx = make_request_context("GET", "/", deadline_ms=-1000)

    assert ctx.is_deadline_exceeded() is True


def test_real_world_request_lifecycle():
    """Real-world: complete request lifecycle with context"""
    ctx = make_request_context(
        method="GET",
        path="/api/users/42",
        deadline_ms=5000,
    )

    token = _set_request_context(ctx)

    try:
        current = get_request_context()
        assert current.method == "GET"
        assert current.path == "/api/users/42"

        elapsed = current.elapsed_ms()
        assert elapsed >= 0

        assert not current.is_deadline_exceeded()

    finally:
        _reset_request_context(token)


def test_real_world_request_with_extras():
    """Real-world: storing request-scoped data in extras"""
    ctx = make_request_context("GET", "/api/data", deadline_ms=None)

    ctx.extras["user_id"] = "user-123"
    ctx.extras["trace_id"] = "trace-abc"
    ctx.route = "get_data"

    token = _set_request_context(ctx)
    try:
        retrieved = get_request_context()
        assert retrieved.extras["user_id"] == "user-123"
        assert retrieved.extras["trace_id"] == "trace-abc"
        assert retrieved.route == "get_data"
    finally:
        _reset_request_context(token)


def test_real_world_deadline_exceeded_detection():
    """Real-world: detecting when deadline has been exceeded"""
    ctx = make_request_context("POST", "/api/process", deadline_ms=100)

    token = _set_request_context(ctx)
    try:
        assert not ctx.is_deadline_exceeded()

        time.sleep(0.15)

        assert ctx.is_deadline_exceeded()
    finally:
        _reset_request_context(token)


def test_real_world_context_with_all_features():
    """Real-world: using all context features together"""
    ctx = make_request_context("PATCH", "/api/users/42", deadline_ms=10000)
    ctx.route = "update_user"
    ctx.extras = {
        "user_id": 42,
        "authenticated": True,
        "permissions": ["edit:user"],
    }

    token = _set_request_context(ctx)
    try:
        current = get_request_context()

        assert current.method == "PATCH"
        assert current.path == "/api/users/42"
        assert current.route == "update_user"
        assert current.extras["user_id"] == 42
        assert current.extras["authenticated"] is True
        assert "edit:user" in current.extras["permissions"]

        elapsed = current.elapsed_ms()
        assert 0 <= elapsed < 100

        assert not current.is_deadline_exceeded()

    finally:
        _reset_request_context(token)


def test_real_world_sequential_requests():
    """Real-world: handling multiple sequential requests"""
    requests_data = [
        ("GET", "/api/users", 5000),
        ("POST", "/api/users", 5000),
        ("DELETE", "/api/users/1", 3000),
    ]

    for method, path, deadline_ms in requests_data:
        ctx = make_request_context(method, path, deadline_ms)
        token = _set_request_context(ctx)

        try:
            current = get_request_context()
            assert current.method == method
            assert current.path == path
            assert not current.is_deadline_exceeded()
        finally:
            _reset_request_context(token)

        try:
            get_request_context()
        except LookupError:
            pass
