from __future__ import annotations
import asyncio
import pytest

from meridian.di import Container, SINGLETON, REQUEST, TRANSIENT
from meridian.di.exceptions import ScopeViolationError, CycleError, MissingBindingError


class Config:
    def __init__(self):
        self.db_url = "sqlite:///:memory:"


class Database:
    def __init__(self, config: Config):
        self.config = config
        self.closed = False

    async def close(self):
        self.closed = True


class UserRepository:
    def __init__(self, db: Database):
        self.db = db


class UserService:
    def __init__(self, repo: UserRepository):
        self.repo = repo


class SimpleService:
    pass


class AsyncService:
    def __init__(self, value: str):
        self.value = value

    async def close(self):
        pass


class _CycleA:
    def __init__(self, b: "_CycleB"): ...


class _CycleB:
    def __init__(self, a: _CycleA): ...


class TestRegister:
    @pytest.mark.asyncio
    async def test_basic_registration(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON)
        c.register(UserRepository, scope=REQUEST)
        c.register(UserService, scope=REQUEST)
        c.build()

    @pytest.mark.asyncio
    async def test_instance_registration_implies_singleton(self):
        c = Container()
        cfg = Config()
        c.register(Config, instance=cfg)
        c.build()
        from meridian.di.binding import Scope

        assert c._bindings[Config].scope == Scope.SINGLETON

    @pytest.mark.asyncio
    async def test_cannot_register_after_build(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.build()
        with pytest.raises(RuntimeError):
            c.register(Database, scope=SINGLETON)

    @pytest.mark.asyncio
    async def test_sync_factory_called_eagerly(self):
        created = []

        def make_config():
            cfg = Config()
            created.append(cfg)
            return cfg

        c = Container()
        c.register(Config, factory=make_config, scope=SINGLETON)
        c.build()
        assert len(created) == 1

    @pytest.mark.asyncio
    async def test_async_factory_deferred_until_resolve(self):
        created = []

        async def make_service():
            svc = SimpleService()
            created.append(svc)
            return svc

        c = Container()
        c.register(SimpleService, factory=make_service, scope=SINGLETON)
        c.build()
        assert len(created) == 0


class TestGraph:
    @pytest.mark.asyncio
    async def test_cycle_detection_raises_cycle_error(self):
        c = Container()
        c.register(_CycleA, scope=REQUEST)
        c.register(_CycleB, scope=REQUEST)
        with pytest.raises(CycleError) as exc_info:
            c.build()
        assert _CycleA in exc_info.value.cycle or _CycleB in exc_info.value.cycle

    @pytest.mark.asyncio
    async def test_missing_dependency_raises_missing_binding_error(self):
        class Orphan:
            def __init__(self, missing: Database): ...

        c = Container()
        c.register(Orphan, scope=REQUEST)
        with pytest.raises(MissingBindingError) as exc_info:
            c.build()
        assert exc_info.value.type_ == Database
        assert exc_info.value.required_by == Orphan

    @pytest.mark.asyncio
    async def test_singleton_depending_on_request_raises_scope_violation(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON)
        c.register(UserRepository, scope=REQUEST)
        c.register(UserService, scope=SINGLETON)
        with pytest.raises(ScopeViolationError) as exc_info:
            c.build()
        assert exc_info.value.dependent == UserService
        assert exc_info.value.dependency == UserRepository

    @pytest.mark.asyncio
    async def test_singleton_depending_on_singleton_valid(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON)
        c.build()

    @pytest.mark.asyncio
    async def test_request_depending_on_singleton_valid(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON)
        c.register(UserRepository, scope=REQUEST)
        c.build()

    @pytest.mark.asyncio
    async def test_transitive_scope_violation_detected(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON)
        c.register(UserRepository, scope=REQUEST)
        c.register(UserService, scope=SINGLETON)
        with pytest.raises(ScopeViolationError):
            c.build()


class TestSingleton:
    @pytest.mark.asyncio
    async def test_singleton_built_eagerly_for_sync_factories(self):
        built_at = []

        def make_svc():
            built_at.append("build")
            return SimpleService()

        c = Container()
        c.register(SimpleService, factory=make_svc, scope=SINGLETON)
        c.build()

        assert "build" in built_at

    @pytest.mark.asyncio
    async def test_singleton_instance_shared_across_scopes(self):
        c = Container()
        c.register(SimpleService, scope=SINGLETON)
        c.build()

        scope1 = c.request_scope()
        scope2 = c.request_scope()

        instance1 = await scope1.resolve(SimpleService)
        instance2 = await scope2.resolve(SimpleService)

        assert id(instance1) == id(instance2)


class TestRequest:
    @pytest.mark.asyncio
    async def test_different_instance_per_scope(self):
        c = Container()
        c.register(SimpleService, scope=REQUEST)
        c.build()

        scope1 = c.request_scope()
        scope2 = c.request_scope()

        instance1 = await scope1.resolve(SimpleService)
        instance2 = await scope2.resolve(SimpleService)

        assert id(instance1) != id(instance2)

    @pytest.mark.asyncio
    async def test_same_instance_within_one_scope(self):
        c = Container()
        c.register(SimpleService, scope=REQUEST)
        c.build()

        scope = c.request_scope()
        instance1 = await scope.resolve(SimpleService)
        instance2 = await scope.resolve(SimpleService)

        assert id(instance1) == id(instance2)

    @pytest.mark.asyncio
    async def test_request_instance_cache_per_scope(self):
        c = Container()
        c.register(Config, instance=Config())
        c.register(Database, scope=REQUEST)
        c.register(UserRepository, scope=REQUEST)
        c.build()

        scope = c.request_scope()
        repo1 = await scope.resolve(UserRepository)
        repo2 = await scope.resolve(UserRepository)

        assert id(repo1) == id(repo2)
        assert id(repo1.db) == id(repo2.db)


class TestTransient:
    @pytest.mark.asyncio
    async def test_new_instance_on_every_resolution(self):
        c = Container()
        c.register(SimpleService, scope=TRANSIENT)
        c.build()

        scope = c.request_scope()
        instance1 = await scope.resolve(SimpleService)
        instance2 = await scope.resolve(SimpleService)

        assert id(instance1) != id(instance2)


class TestTeardown:
    @pytest.mark.asyncio
    async def test_request_teardown_called_after_scope_cleanup(self):
        torn_down = []

        c = Container()
        c.register(
            SimpleService,
            scope=REQUEST,
            factory=lambda: SimpleService(),
            teardown=lambda svc: torn_down.append(svc),
        )
        c.build()

        scope = c.request_scope()
        svc = await scope.resolve(SimpleService)
        await scope.teardown()

        assert len(torn_down) == 1

    @pytest.mark.asyncio
    async def test_teardown_reverse_resolution_order(self):
        order = []

        class ServiceA:
            pass

        class ServiceB:
            pass

        c = Container()
        c.register(
            ServiceA,
            scope=REQUEST,
            factory=lambda: ServiceA(),
            teardown=lambda _: order.append("A"),
        )
        c.register(
            ServiceB,
            scope=REQUEST,
            factory=lambda: ServiceB(),
            teardown=lambda _: order.append("B"),
        )
        c.build()

        scope = c.request_scope()
        await scope.resolve(ServiceA)
        await scope.resolve(ServiceB)
        await scope.teardown()

        assert order == ["B", "A"]

    @pytest.mark.asyncio
    async def test_async_teardown_supported(self):
        torn_down = []

        async def async_teardown(svc):
            await asyncio.sleep(0)
            torn_down.append(svc)

        c = Container()
        c.register(
            SimpleService,
            scope=REQUEST,
            factory=lambda: SimpleService(),
            teardown=async_teardown,
        )
        c.build()

        scope = c.request_scope()
        await scope.resolve(SimpleService)
        await scope.teardown()

        assert len(torn_down) == 1

    @pytest.mark.asyncio
    async def test_singleton_teardown_on_shutdown(self):
        torn_down = []

        async def shutdown_db(db):
            torn_down.append(db)

        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON, teardown=shutdown_db)
        c.build()

        await c.shutdown()

        assert len(torn_down) == 1


class TestInject:
    @pytest.mark.asyncio
    async def test_resolves_in_request_scope(self):
        c = Container()
        c.register(Config, instance=Config())
        c.build()

        scope = c.request_scope()
        cfg = await scope.resolve(Config)

        assert cfg.db_url == "sqlite:///:memory:"

    @pytest.mark.asyncio
    async def test_resolves_with_dependencies(self):
        c = Container()
        c.register(Config, scope=SINGLETON)
        c.register(Database, scope=SINGLETON)
        c.register(UserRepository, scope=REQUEST)
        c.build()

        scope = c.request_scope()
        repo = await scope.resolve(UserRepository)

        assert repo.db is not None
        assert repo.db.config is not None

    @pytest.mark.asyncio
    async def test_configuration_error_without_binding(self):
        from meridian.di.exceptions import InjectionError

        c = Container()
        c.build()

        scope = c.request_scope()
        with pytest.raises(InjectionError):
            await scope.resolve(SimpleService)


class TestOverride:
    @pytest.mark.asyncio
    async def test_returns_new_container(self):
        original = Container()
        original.register(Config, scope=SINGLETON)
        original.build()

        test_cfg = Config()
        test_cfg.db_url = "test://override"

        overridden = original.override(Config, instance=test_cfg)
        overridden.build()

        assert overridden is not original
        assert original._bindings[Config].instance is None

    @pytest.mark.asyncio
    async def test_overridden_container_resolves_new_binding(self):
        test_cfg = Config()
        test_cfg.db_url = "test://override"

        c = Container()
        c.register(Config, instance=test_cfg)
        c.build()

        scope = c.request_scope()
        cfg = await scope.resolve(Config)

        assert cfg.db_url == "test://override"
